"""Catalog/query operations for dataset metadata and feature catalogs."""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from .client import KWSClient


def _extract_items(payload: Any, keys: Tuple[str, ...]) -> List[Dict[str, Any]]:
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if not isinstance(payload, dict):
        return []
    for key in keys:
        data = payload.get(key)
        if isinstance(data, list):
            return [item for item in data if isinstance(item, dict)]
        if isinstance(data, dict):
            nested_items = data.get("items")
            if isinstance(nested_items, list):
                return [item for item in nested_items if isinstance(item, dict)]
    return []


def _coerce_dict(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            return {}
    return {}


def _extract_n_mels_from_feature_type(row: pd.Series) -> Optional[int]:
    for source_key in ("params", "feature_config"):
        source = _coerce_dict(row.get(source_key))
        n_mels = source.get("n_mels")
        if n_mels is None:
            continue
        try:
            return int(n_mels)
        except (TypeError, ValueError):
            continue
    return None


class DatasetCatalogService:
    """Dataset listing/query service that returns notebook-friendly DataFrames."""

    def __init__(self, api: KWSClient):
        self._api = api

    def list_dataset_versions_df(
        self,
        dataset_type: Optional[str] = None,
        page: int = 1,
        page_size: int = 100,
        only_active: bool = True,
    ) -> pd.DataFrame:
        rows: List[Dict[str, Any]] = []
        datasets_resp = self._api.datasets.list(type=dataset_type, page=page, page_size=page_size)
        datasets = _extract_items(datasets_resp, ("items", "datasets", "data"))

        for dataset in datasets:
            dataset_id = dataset.get("dataset_id") or dataset.get("datasets_id") or dataset.get("id")
            if dataset_id is None:
                continue

            active_version: Optional[Dict[str, Any]] = None
            if only_active:
                try:
                    active_version = self._api.datasets.get_active_version(dataset_id=int(dataset_id))
                except Exception:
                    active_version = None

            versions: List[Dict[str, Any]]
            if active_version is not None:
                versions = [active_version]
            else:
                versions_resp = self._api.datasets.list_versions(
                    dataset_id=int(dataset_id),
                    page=1,
                    page_size=page_size,
                )
                versions = _extract_items(versions_resp, ("items", "versions", "data"))
                if only_active:
                    versions = [v for v in versions if bool(v.get("is_active"))]

            for version in versions:
                dataset_version_id = (
                    version.get("dataset_versions_id")
                    or version.get("dataset_version_id")
                    or version.get("version_id")
                    or version.get("id")
                )
                rows.append(
                    {
                        "dataset_version_id": dataset_version_id,
                        "dataset_name": dataset.get("name"),
                        "dataset_type": dataset.get("type"),
                        "dataset_description": dataset.get("description"),
                        "version": version.get("version"),
                    }
                )

        columns = [
            "dataset_version_id",
            "dataset_name",
            "dataset_type",
            "dataset_description",
            "version",
        ]
        df = pd.DataFrame(rows, columns=columns)
        if df.empty:
            return df

        return df.sort_values(
            by=["dataset_name", "version"],
            ascending=[True, False],
            na_position="last",
        ).reset_index(drop=True)

    def get_dataset_version_split_df(
        self,
        dataset_version_id: int,
        feature_type_id: int,
    ) -> pd.DataFrame:
        df = self._api.dataset_splits.get_mfcc_files(
            dataset_version_id=dataset_version_id,
            feature_type_id=feature_type_id,
        )
        if df.empty:
            raise ValueError(f"No feature data found for dataset_version_id={dataset_version_id}")

        if "derivative_label" not in df.columns:
            df["derivative_label"] = df["keyword_name"]

        columns = [
            "feature_id",
            "sample_id",
            "keyword_id",
            "keyword_name",
            "derivative_label",
        ]
        existing_columns = [col for col in columns if col in df.columns]
        return (
            df[existing_columns]
            .sort_values(by=["keyword_name", "sample_id"], na_position="last")
            .reset_index(drop=True)
        )

    def list_dataset_version_feature_extractions_df(
        self,
        dataset_version_id: int,
    ) -> pd.DataFrame:
        mfcc_df = self._api.dataset_splits.get_mfcc_files(dataset_version_id=dataset_version_id)
        if mfcc_df.empty:
            return pd.DataFrame(
                columns=[
                    "feature_type_id",
                    "feature_type_name",
                    "feature_type_description",
                    "feature_dim",
                    "n_mels",
                    "total_features",
                    "total_keywords",
                ]
            )

        grouped = (
            mfcc_df.groupby("feature_type_id", dropna=False)
            .agg(
                total_features=("feature_id", "count"),
                total_keywords=("keyword_id", "nunique"),
            )
            .reset_index()
        )

        feature_types_resp = self._api.features.list_feature_types(page=1, page_size=100)
        feature_type_items = _extract_items(feature_types_resp, ("items", "feature_types", "data"))
        ft_df = pd.DataFrame(feature_type_items)
        if not ft_df.empty:
            ft_df["feature_type_id"] = ft_df.get("feature_types_id")
            ft_df = ft_df.rename(
                columns={
                    "name": "feature_type_name",
                    "description": "feature_type_description",
                    "dim": "feature_dim",
                }
            )
            ft_df["n_mels"] = ft_df.apply(_extract_n_mels_from_feature_type, axis=1)
            grouped = grouped.merge(
                ft_df[["feature_type_id", "feature_type_name", "feature_type_description", "feature_dim", "n_mels"]],
                on="feature_type_id",
                how="left",
            )
        else:
            grouped["feature_type_name"] = None
            grouped["feature_type_description"] = None
            grouped["feature_dim"] = None
            grouped["n_mels"] = None

        columns = [
            "feature_type_id",
            "feature_type_name",
            "feature_type_description",
            "feature_dim",
            "n_mels",
            "total_features",
            "total_keywords",
        ]
        return grouped[columns].sort_values(
            by=["total_features", "feature_type_id"],
            ascending=[False, True],
            na_position="last",
        ).reset_index(drop=True)


def list_dataset_versions_df(
    api: KWSClient,
    dataset_type: Optional[str] = None,
    page: int = 1,
    page_size: int = 100,
    only_active: bool = True,
) -> pd.DataFrame:
    return DatasetCatalogService(api).list_dataset_versions_df(
        dataset_type=dataset_type,
        page=page,
        page_size=page_size,
        only_active=only_active,
    )


def get_dataset_version_split_df(
    api: KWSClient,
    dataset_version_id: int,
    feature_type_id: int,
) -> pd.DataFrame:
    return DatasetCatalogService(api).get_dataset_version_split_df(
        dataset_version_id=dataset_version_id,
        feature_type_id=feature_type_id,
    )


def list_dataset_version_feature_extractions_df(
    api: KWSClient,
    dataset_version_id: int,
) -> pd.DataFrame:
    return DatasetCatalogService(api).list_dataset_version_feature_extractions_df(
        dataset_version_id=dataset_version_id,
    )


__all__ = [
    "DatasetCatalogService",
    "list_dataset_versions_df",
    "get_dataset_version_split_df",
    "list_dataset_version_feature_extractions_df",
]
