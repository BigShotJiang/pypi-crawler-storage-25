"""
KWS Library - Python client for KWS Platform API

Design note:
- Keep package import lightweight. Some optional modules (e.g. TensorFlow models)
  are heavy; we lazy-load them via __getattr__ so that "smoke" / client usage
  doesn't pull ML stacks unnecessarily.
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("kwslib")
except PackageNotFoundError:
    # Source checkout without installed package metadata.
    __version__ = "0.0.0+local"


_LAZY_ATTRS = {
    # Core lightweight pieces
    "KWSClient": ("kwslib.client", "KWSClient"),
    "DatasetSplitFilesClient": ("kwslib.minio_client", "DatasetSplitFilesClient"),
    "SplitFilesClient": ("kwslib.minio_client", "SplitFilesClient"),
    "EpisodeDataset": ("kwslib.training", "EpisodeDataset"),
    "build_class_prototypes": ("kwslib.training", "build_class_prototypes"),
    "compute_prototypes": ("kwslib.training", "compute_prototypes"),
    "ProtoNetOps": ("kwslib.training", "ProtoNetOps"),
    "PrototypeBuilder": ("kwslib.training", "PrototypeBuilder"),
    "proto_loss": ("kwslib.training", "proto_loss"),
    "save_prototypes_npz": ("kwslib.training", "save_prototypes_npz"),
    "TelegramNotifier": ("kwslib.telegram_notifier", "TelegramNotifier"),
    # Standards (lightweight)
    "STANDARD_METRIC_KEYS": ("kwslib.standards.metrics", "STANDARD_METRIC_KEYS"),
    "build_metrics_payload": ("kwslib.standards.metrics", "build_metrics_payload"),
    "metrics_from_sklearn": ("kwslib.standards.metrics", "metrics_from_sklearn"),
    # High-level API
    "KWSSession": ("kwslib.split_ops", "KWSSession"),
    "DatasetPipeline": ("kwslib.split_ops", "DatasetPipeline"),
    "ModelManager": ("kwslib.model_ops", "ModelManager"),
    "PayloadUtils": ("kwslib.split_ops", "PayloadUtils"),
    "DatasetCatalogService": ("kwslib.catalog_ops", "DatasetCatalogService"),
    "SplitDataService": ("kwslib.split_ops", "SplitDataService"),
    "FeatureArrayOps": ("kwslib.split_ops", "FeatureArrayOps"),
    "list_dataset_versions_df": ("kwslib.catalog_ops", "list_dataset_versions_df"),
    "get_dataset_version_split_df": ("kwslib.catalog_ops", "get_dataset_version_split_df"),
    "list_dataset_version_feature_extractions_df": ("kwslib.catalog_ops", "list_dataset_version_feature_extractions_df"),
    "push_dataset_split_df": ("kwslib.split_ops", "push_dataset_split_df"),
    "download_split_npz": ("kwslib.split_ops", "download_split_npz"),
    "load_split_npz_arrays": ("kwslib.split_ops", "load_split_npz_arrays"),
    "to_mel_time": ("kwslib.split_ops", "to_mel_time"),
    "arrays_by_class": ("kwslib.split_ops", "arrays_by_class"),
}

__all__ = ["__version__", *_LAZY_ATTRS.keys()]


def __getattr__(name: str):
    if name not in _LAZY_ATTRS:
        raise AttributeError(name)
    module_name, attr_name = _LAZY_ATTRS[name]
    import importlib

    mod = importlib.import_module(module_name)
    return getattr(mod, attr_name)
