"""Backward-compatible high-level facade.

Preferred implementation modules:
- kwslib.catalog_ops
- kwslib.split_ops
- kwslib.model_ops
"""

from .catalog_ops import (
    DatasetCatalogService,
    get_dataset_version_split_df,
    list_dataset_version_feature_extractions_df,
    list_dataset_versions_df,
)
from .model_ops import ModelManager
from .split_ops import (
    DatasetPipeline,
    FeatureArrayOps,
    KWSSession,
    PayloadUtils,
    SplitDataService,
    arrays_by_class,
    download_split_npz,
    load_split_npz_arrays,
    push_dataset_split_df,
    to_mel_time,
)

__all__ = [
    "PayloadUtils",
    "DatasetCatalogService",
    "SplitDataService",
    "FeatureArrayOps",
    "KWSSession",
    "DatasetPipeline",
    "ModelManager",
    "list_dataset_versions_df",
    "get_dataset_version_split_df",
    "list_dataset_version_feature_extractions_df",
    "push_dataset_split_df",
    "download_split_npz",
    "load_split_npz_arrays",
    "to_mel_time",
    "arrays_by_class",
]
