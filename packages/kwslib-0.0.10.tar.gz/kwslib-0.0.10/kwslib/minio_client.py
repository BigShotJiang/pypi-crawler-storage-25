"""
Dataset split file client.

Despite historical naming, this module does not access MinIO directly.
All file operations go through KWS Server API endpoints.
"""

from __future__ import annotations

import logging
import tempfile
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests

logger = logging.getLogger(__name__)


class SplitFilesClient:
    """Download and list split files through `dataset_splits` API endpoints."""

    def __init__(self, api_client: Any):
        self.api = api_client

    def list_files(self, split_id: int, file_type: Optional[str] = None) -> Dict[str, Any]:
        return self.api.dataset_splits.list_files(split_id=split_id, file_type=file_type)

    def download_wav(self, split_id: int, file_id: int, output_path: str) -> str:
        return self.api.dataset_splits.download_file(
            split_id=split_id,
            file_id=file_id,
            file_type="wav",
            output_path=output_path,
        )

    def download_npz(
        self,
        split_id: int,
        file_id: int,
        output_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Download one NPZ file and return all arrays as a dictionary."""
        import numpy as np
        if output_path:
            npz_path = self.api.dataset_splits.download_file(
                split_id=split_id,
                file_id=file_id,
                file_type="npz",
                output_path=output_path,
            )
            with np.load(npz_path) as data:
                return {key: data[key] for key in data.files}

        with tempfile.NamedTemporaryFile(delete=False, suffix=".npz") as tmp_file:
            npz_path = self.api.dataset_splits.download_file(
                split_id=split_id,
                file_id=file_id,
                file_type="npz",
                output_path=tmp_file.name,
            )

        try:
            with np.load(npz_path) as data:
                return {key: data[key] for key in data.files}
        finally:
            Path(npz_path).unlink(missing_ok=True)

    def download_all_wav(self, split_id: int, output_dir: str) -> List[str]:
        return self._download_all_by_type(split_id=split_id, file_type="wav", output_dir=output_dir)

    def download_all_npz(
        self,
        split_id: int,
        output_dir: str,
        skip_existing: bool = True,
        max_workers: int = 8,
        strategy: str = "auto",
        zip_threshold: int = 300,
        keep_zip: bool = False,
    ) -> List[str]:
        return self._download_all_by_type(
            split_id=split_id,
            file_type="npz",
            output_dir=output_dir,
            skip_existing=skip_existing,
            max_workers=max_workers,
            strategy=strategy,
            zip_threshold=zip_threshold,
            keep_zip=keep_zip,
        )

    def download_all_files_zip(self, split_id: int, file_type: str, output_path: str) -> str:
        return self.api.dataset_splits.download_all_files(
            split_id=split_id,
            file_type=file_type,
            format="zip",
            output_path=output_path,
        )

    def get_file_urls(self, split_id: int, file_type: str) -> Dict[str, Any]:
        # Kept for backward compatibility. Returns metadata, not direct URLs.
        return self.list_files(split_id=split_id, file_type=file_type)

    def get_file_metadata(self, split_id: int, file_type: str) -> Dict[str, Any]:
        return self.list_files(split_id=split_id, file_type=file_type)

    def _download_all_by_type(
        self,
        split_id: int,
        file_type: str,
        output_dir: str,
        skip_existing: bool = True,
        max_workers: int = 8,
        strategy: str = "parallel",
        zip_threshold: int = 300,
        keep_zip: bool = False,
    ) -> List[str]:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        files_info = self.list_files(split_id=split_id, file_type=file_type)
        source_files = [item for item in files_info.get("files", []) if item.get("file_type") == file_type]

        if file_type == "npz":
            selected_strategy = strategy
            if strategy == "auto":
                selected_strategy = "zip" if len(source_files) >= max(1, zip_threshold) else "parallel"
            if selected_strategy == "zip":
                return self._download_all_by_zip(
                    split_id=split_id,
                    file_type=file_type,
                    output_dir=output_dir,
                    keep_zip=keep_zip,
                )
            if selected_strategy not in {"parallel", "sequential"}:
                raise ValueError(f"Unsupported download strategy: {selected_strategy}")
            strategy = selected_strategy
        elif strategy == "auto":
            strategy = "parallel"

        if strategy == "sequential":
            max_workers = 1
        else:
            max_workers = max(1, int(max_workers))

        downloaded: List[str] = []
        skipped_count = 0
        jobs: List[Tuple[str, int, Path]] = []
        for item in source_files:
            file_name = item.get("file_name")
            if not file_name:
                continue

            local_file = output_path / file_name
            if skip_existing and local_file.exists():
                downloaded.append(str(local_file))
                skipped_count += 1
                continue

            file_id = self._resolve_file_id(item=item, file_type=file_type)
            if file_id is None:
                logger.warning("Skip %s: no file id in payload", file_name)
                continue
            jobs.append((file_name, file_id, local_file))

        if jobs:
            if max_workers == 1:
                for file_name, file_id, local_file in jobs:
                    if self._download_single_file(split_id, file_id, file_type, local_file):
                        downloaded.append(str(local_file))
                    else:
                        logger.error("Download failed for %s (split=%s)", file_name, split_id)
            else:
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = {
                        executor.submit(
                            self._download_single_file,
                            split_id,
                            file_id,
                            file_type,
                            local_file,
                        ): (file_name, local_file)
                        for file_name, file_id, local_file in jobs
                    }
                    for future in as_completed(futures):
                        file_name, local_file = futures[future]
                        try:
                            if future.result():
                                downloaded.append(str(local_file))
                            else:
                                logger.error("Download failed for %s (split=%s)", file_name, split_id)
                        except Exception as exc:  # pragma: no cover - safeguard
                            logger.error("Download failed for %s (split=%s): %s", file_name, split_id, exc)

        if skipped_count:
            logger.info(
                "Split %s (%s): downloaded=%s, skipped_existing=%s",
                split_id,
                file_type,
                len(downloaded) - skipped_count,
                skipped_count,
            )
        else:
            logger.info("Split %s (%s): downloaded=%s", split_id, file_type, len(downloaded))

        return downloaded

    def _download_single_file(
        self,
        split_id: int,
        file_id: int,
        file_type: str,
        local_file: Path,
    ) -> bool:
        try:
            self.api.dataset_splits.download_file(
                split_id=split_id,
                file_id=file_id,
                file_type=file_type,
                output_path=str(local_file),
            )
            return True
        except requests.RequestException as exc:
            logger.error("Download failed for file_id=%s (split=%s): %s", file_id, split_id, exc)
            return False

    def _download_all_by_zip(
        self,
        split_id: int,
        file_type: str,
        output_dir: str,
        keep_zip: bool = False,
    ) -> List[str]:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        zip_path = output_path / f"split_{split_id}_{file_type}.zip"
        self.download_all_files_zip(split_id=split_id, file_type=file_type, output_path=str(zip_path))
        try:
            with zipfile.ZipFile(zip_path, "r") as zip_file:
                zip_file.extractall(output_path)
        finally:
            if not keep_zip:
                zip_path.unlink(missing_ok=True)

        extension = ".npz" if file_type == "npz" else ".wav"
        return [str(path) for path in output_path.glob(f"*{extension}")]

    @staticmethod
    def _resolve_file_id(item: Dict[str, Any], file_type: str) -> Optional[int]:
        candidates: List[Any]
        if file_type == "wav":
            candidates = [
                item.get("file_id"),
                item.get("id"),
                item.get("keyword_audio_sample_id"),
                item.get("sample_id"),
            ]
        else:
            candidates = [
                item.get("file_id"),
                item.get("id"),
                item.get("keyword_audio_feature_id"),
                item.get("feature_id"),
            ]

        for candidate in candidates:
            if candidate is None:
                continue
            try:
                return int(candidate)
            except (TypeError, ValueError):
                continue
        return None


# Backward-compatible alias
DatasetSplitFilesClient = SplitFilesClient
