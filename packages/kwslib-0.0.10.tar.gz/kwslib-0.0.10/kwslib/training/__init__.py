"""Backward-compatible entrypoints for split/data-loading + few-shot helpers."""

from .create_dataset_split import get_split_data, push_splits
from .data_loader import DataLoader, SplitDataLoader
from .episode_dataset import EpisodeDataset
from .protonet import ProtoNetOps, compute_prototypes, proto_loss
from .prototypes import PrototypeBuilder, build_class_prototypes, save_prototypes_npz

__all__ = [
    "build_class_prototypes",
    "compute_prototypes",
    "DataLoader",
    "EpisodeDataset",
    "PrototypeBuilder",
    "ProtoNetOps",
    "proto_loss",
    "save_prototypes_npz",
    "SplitDataLoader",
    "get_split_data",
    "push_splits",
]
