"""ProtoNet core math helpers."""

from __future__ import annotations

from typing import Tuple

import torch
from torch import nn


class ProtoNetOps:
    """ProtoNet tensor operations."""

    @staticmethod
    def compute_prototypes(
        emb: torch.Tensor,
        labels: torch.Tensor,
        n_way: int,
    ) -> torch.Tensor:
        """Compute class prototypes from support embeddings."""
        protos = []
        for k in range(n_way):
            mask = labels == k
            if not torch.any(mask):
                raise ValueError(f"Class {k} has no support samples")
            protos.append(emb[mask].mean(0))
        return torch.stack(protos, dim=0)

    @staticmethod
    def proto_loss(
        support_emb: torch.Tensor,
        support_y: torch.Tensor,
        query_emb: torch.Tensor,
        query_y: torch.Tensor,
        n_way: int,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Compute ProtoNet loss and logits."""
        protos = ProtoNetOps.compute_prototypes(support_emb, support_y, n_way)
        logits = query_emb @ protos.t()
        loss = nn.functional.cross_entropy(logits, query_y)
        return loss, logits


def compute_prototypes(
    emb: torch.Tensor,
    labels: torch.Tensor,
    n_way: int,
) -> torch.Tensor:
    """Backward-compatible wrapper."""
    return ProtoNetOps.compute_prototypes(emb=emb, labels=labels, n_way=n_way)


def proto_loss(
    support_emb: torch.Tensor,
    support_y: torch.Tensor,
    query_emb: torch.Tensor,
    query_y: torch.Tensor,
    n_way: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Backward-compatible wrapper."""
    return ProtoNetOps.proto_loss(
        support_emb=support_emb,
        support_y=support_y,
        query_emb=query_emb,
        query_y=query_y,
        n_way=n_way,
    )
