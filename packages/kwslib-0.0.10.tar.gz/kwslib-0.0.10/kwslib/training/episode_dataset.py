"""Deterministic episodic dataset for few-shot training."""

from __future__ import annotations

from typing import Dict, List

import numpy as np
import torch
from torch.utils.data import Dataset


class EpisodeDataset(Dataset):
    """Create deterministic N-way K-shot episodes from class-wise arrays."""

    def __init__(
        self,
        class_arrays: Dict[str, np.ndarray],
        class_list: List[str],
        n_way: int,
        k_shot: int,
        n_query: int,
        n_episodes: int,
        seed: int = 42,
    ):
        self.class_arrays = class_arrays
        self.class_list = [
            c
            for c in class_list
            if c in class_arrays and class_arrays[c].shape[0] >= (k_shot + n_query)
        ]
        if len(self.class_list) < n_way:
            raise ValueError(f"Not enough classes for n_way={n_way}. available={self.class_list}")

        self.n_way = n_way
        self.k_shot = k_shot
        self.n_query = n_query
        self.n_episodes = n_episodes
        self.seed = int(seed)

    def __len__(self) -> int:
        return self.n_episodes

    def __getitem__(self, idx: int):
        rng = np.random.default_rng(self.seed + int(idx))

        chosen_idx = rng.choice(len(self.class_list), size=self.n_way, replace=False)
        chosen = [self.class_list[i] for i in chosen_idx]

        support_x, support_y = [], []
        query_x, query_y = [], []

        for epi_label, cls in enumerate(chosen):
            arr = self.class_arrays[cls]
            perm = rng.permutation(arr.shape[0])
            s_idx = perm[: self.k_shot]
            q_idx = perm[self.k_shot : self.k_shot + self.n_query]

            support_x.append(arr[s_idx])
            support_y.extend([epi_label] * len(s_idx))
            query_x.append(arr[q_idx])
            query_y.extend([epi_label] * len(q_idx))

        sx = torch.from_numpy(np.concatenate(support_x, axis=0)).float()
        sy = torch.tensor(support_y, dtype=torch.long)
        qx = torch.from_numpy(np.concatenate(query_x, axis=0)).float()
        qy = torch.tensor(query_y, dtype=torch.long)

        return {
            "support_x": sx,
            "support_y": sy,
            "query_x": qx,
            "query_y": qy,
            "n_way": torch.tensor(self.n_way, dtype=torch.long),
        }
