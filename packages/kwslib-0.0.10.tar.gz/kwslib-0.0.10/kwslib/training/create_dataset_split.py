"""
Utilities to create dataset splits using pandas, exposed as part of kwslib.training.

This is essentially the same logic as the top-level create_dataset_split.py script,
but packaged inside kwslib so that code running only with "pip install kwslib"
can import:

    from kwslib.training.create_dataset_split import get_split_data, push_splits
"""

import logging
from typing import Optional, Dict, List, cast

import pandas as pd

from ..client import KWSClient
from ..split_ops import SplitDataService

logger = logging.getLogger(__name__)


def get_split_data(
    api: KWSClient,
    dataset_version_id: int,
    feature_type_id: Optional[int] = None,
    keyword_ids: Optional[List[int]] = None,
) -> pd.DataFrame:
    """
    Get data for creating dataset splits.

    Returns a DataFrame with columns:
    - feature_id: Feature ID (keyword_audio_features.id)
    - sample_id: Audio sample ID (keyword_audio_samples.id)
    - keyword_id: Keyword ID
    - keyword_name: Keyword name (label)
    - file_name: Feature file name
    - minio_path: MinIO path to feature file
    - feature_type_id: Feature type ID
    """
    logger.info(f"Fetching data for dataset version {dataset_version_id}...")

    df = api.dataset_splits.get_mfcc_files(
        dataset_version_id=dataset_version_id,
        feature_type_id=feature_type_id,
        keyword_ids=keyword_ids,
    )

    if df.empty:
        raise ValueError("No data found for the specified criteria")

    logger.info(f"Retrieved {len(df)} records")
    logger.info(f"Keywords: {df['keyword_name'].unique().tolist()}")
    logger.info(f"Keyword counts:\n{df['keyword_name'].value_counts()}")

    return df


def push_splits(
    api: KWSClient,
    dataset_version_id: int,
    config_name: str,
    splits: Dict[str, pd.DataFrame],
    create_merged_keywords: Optional[Dict[str, List[int]]] = None,
    auto_detect_merged_keywords: bool = True,
    batch_size: int = 1000,
) -> Dict[str, int]:
    """
    Push split assignments to the database.

    Args:
        api: KWSClient instance (must be authenticated)
        dataset_version_id: Dataset version ID
        config_name: Configuration name (e.g., "config_70_15_15")
        splits: Dictionary mapping split names to DataFrames.
                Each DataFrame MUST have 'feature_id', 'keyword_id', and 'derivative_label' columns.
        create_merged_keywords: Optional dict mapping new keyword names to
            list of source keyword IDs to merge.
        auto_detect_merged_keywords: If True, automatically detect merged keywords.
        batch_size: Number of files to send per batch.
    """
    service = SplitDataService(api)
    original_timeout = api.timeout
    total_files = sum(len(df) for df in splits.values() if not df.empty)
    try:
        if total_files > 1000:
            api.timeout = max(api.timeout, max(60, (total_files // 100) + 30))
        return service.push_named_splits(
            dataset_version_id=dataset_version_id,
            config_name=config_name,
            splits=splits,
            batch_size=batch_size,
            create_merged_keywords=create_merged_keywords,
            auto_detect_merged_keywords=auto_detect_merged_keywords,
        )
    finally:
        api.timeout = original_timeout


def create_class_splits_with_cap(
    api: KWSClient,
    dataset_version_id: int,
    feature_type_id: Optional[int],
    config_name: str,
    max_per_class: int = 1000,
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    class_names: Optional[List[str]] = None,
) -> Dict[str, int]:
    """
    Wrapper high-level:

    1. Gọi get_split_data(...) để lấy DataFrame feature/keyword.
    2. Giới hạn tối đa max_per_class mẫu / keyword (derivative_label).
    3. Chia class thành train/val/test theo tỷ lệ train_ratio/val_ratio/test_ratio.
    4. Gọi push_splits(...) để tạo split trên server.

    Trả về:
        {"train": train_split_id, "val": val_split_id, "test": test_split_id}
    """
    if abs(train_ratio + val_ratio + test_ratio - 1.0) > 1e-6:
        raise ValueError("train_ratio + val_ratio + test_ratio must equal 1.0")

    df = get_split_data(
        api=api,
        dataset_version_id=dataset_version_id,
        feature_type_id=feature_type_id,
        keyword_ids=None,
    )

    # Áp dụng class_names nếu có
    if class_names:
        df = cast(pd.DataFrame, df[df["keyword_name"].isin(class_names)].copy())
        logger.info("Filtered to %d classes from CLASS_NAMES", len(class_names))

    # derivative_label mặc định = keyword_name
    if "derivative_label" not in df.columns:
        df["derivative_label"] = df["keyword_name"]

    # Giới hạn số mẫu mỗi class
    df = (
        df.sort_values("sample_id")
        .groupby("derivative_label", group_keys=False)
        .head(max_per_class)
    )
    logger.info("After cap %d samples/class:", max_per_class)
    logger.info("%s", df["derivative_label"].value_counts())

    # Chia class thành train/val/test
    unique_classes = df["derivative_label"].unique().tolist()
    n_total = len(unique_classes)
    n_train = max(1, int(n_total * train_ratio))
    n_val = max(1, int(n_total * val_ratio))
    n_test = max(1, n_total - n_train - n_val)

    train_classes = unique_classes[:n_train]
    val_classes = unique_classes[n_train : n_train + n_val]
    test_classes = unique_classes[n_train + n_val : n_train + n_val + n_test]

    train_df = df[df["derivative_label"].isin(train_classes)].copy()
    val_df = df[df["derivative_label"].isin(val_classes)].copy()
    test_df = df[df["derivative_label"].isin(test_classes)].copy()

    logger.info("Train classes (%d): %s", len(train_classes), train_classes)
    logger.info("Val classes   (%d): %s", len(val_classes), val_classes)
    logger.info("Test classes  (%d): %s", len(test_classes), test_classes)

    created = push_splits(
        api=api,
        dataset_version_id=dataset_version_id,
        config_name=config_name,
        splits={"train": train_df, "val": val_df, "test": test_df},
    )
    return created
