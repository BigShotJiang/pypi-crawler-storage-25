"""Utilities for building and saving class prototypes."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from torch import nn


class PrototypeBuilder:
    """Prototype construction and persistence helpers."""

    @staticmethod
    def build_class_prototypes(
        model: nn.Module,
        class_arrays: Dict[str, np.ndarray],
        device: torch.device,
        *,
        method: str = "mean",
        max_per_class: int = 300,
        seed: int = 42,
        batch_size: int = 256,
    ) -> Tuple[np.ndarray, List[str]]:
        """
        Build class-level prototypes from embeddings.
        """
        rng = np.random.default_rng(seed)
        labels = sorted(class_arrays.keys())
        if not labels:
            raise ValueError("class_arrays is empty; cannot build prototypes")

        embs: List[np.ndarray] = []
        model.eval()
        with torch.no_grad():
            for cls_name in labels:
                cls_x_np = class_arrays[cls_name]
                if cls_x_np.shape[0] == 0:
                    raise ValueError(f"class '{cls_name}' has no samples")

                if cls_x_np.shape[0] > max_per_class:
                    idx = rng.choice(cls_x_np.shape[0], size=max_per_class, replace=False)
                    cls_x_np = cls_x_np[idx]

                cls_emb_chunks: List[np.ndarray] = []
                chunk = max(1, batch_size)
                if method == "mean":
                    running_sum: Optional[np.ndarray] = None
                    n_items = 0
                    for start in range(0, cls_x_np.shape[0], chunk):
                        batch_np = cls_x_np[start:start + chunk]
                        batch_tensor = torch.from_numpy(batch_np).float().to(device)
                        batch_emb = model(batch_tensor).detach().cpu().numpy().astype(np.float32)
                        batch_sum = batch_emb.sum(axis=0, dtype=np.float64)
                        if running_sum is None:
                            running_sum = batch_sum
                        else:
                            running_sum += batch_sum
                        n_items += batch_emb.shape[0]
                    if running_sum is None or n_items == 0:
                        raise ValueError(f"class '{cls_name}' produced no embeddings")
                    proto = (running_sum / float(n_items)).astype(np.float32)
                elif method == "median":
                    for start in range(0, cls_x_np.shape[0], chunk):
                        batch_np = cls_x_np[start:start + chunk]
                        batch_tensor = torch.from_numpy(batch_np).float().to(device)
                        batch_emb = model(batch_tensor).detach().cpu().numpy().astype(np.float32)
                        cls_emb_chunks.append(batch_emb)
                    cls_emb = np.concatenate(cls_emb_chunks, axis=0)
                    proto = np.median(cls_emb, axis=0)
                else:
                    raise ValueError(f"Unsupported prototype method: {method}")

                embs.append(proto.astype(np.float32))

        return np.stack(embs, axis=0), labels

    @staticmethod
    def save_prototypes_npz(
        path: Path,
        embeddings: np.ndarray,
        labels: List[str],
    ) -> Path:
        """Save prototypes to `.npz` with keys: `embeddings`, `labels`."""
        path.parent.mkdir(parents=True, exist_ok=True)
        np.savez(path, embeddings=embeddings.astype(np.float32), labels=np.array(labels, dtype=str))
        return path


def build_class_prototypes(
    model: nn.Module,
    class_arrays: Dict[str, np.ndarray],
    device: torch.device,
    *,
    method: str = "mean",
    max_per_class: int = 300,
    seed: int = 42,
    batch_size: int = 256,
) -> Tuple[np.ndarray, List[str]]:
    """Backward-compatible wrapper."""
    return PrototypeBuilder.build_class_prototypes(
        model=model,
        class_arrays=class_arrays,
        device=device,
        method=method,
        max_per_class=max_per_class,
        seed=seed,
        batch_size=batch_size,
    )


def save_prototypes_npz(
    path: Path,
    embeddings: np.ndarray,
    labels: List[str],
) -> Path:
    """Backward-compatible wrapper."""
    return PrototypeBuilder.save_prototypes_npz(path=path, embeddings=embeddings, labels=labels)
