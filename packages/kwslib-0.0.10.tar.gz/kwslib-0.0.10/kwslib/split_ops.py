"""Split operations, data loading orchestration, and feature-array utilities."""

from __future__ import annotations

import logging
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, cast

import numpy as np
import pandas as pd
import requests

from .client import KWSClient
from .data_loading import SplitDataLoader
from .minio_client import SplitFilesClient
from .utils.load_npz_files import load_npz_files

logger = logging.getLogger(__name__)


class PayloadUtils:
    """Helpers for normalizing split payload data."""

    @staticmethod
    def _normalize_label_value(value: Any) -> Optional[str]:
        if value is None or value is pd.NA:
            return None
        if isinstance(value, str):
            stripped = value.strip()
            return stripped if stripped else None
        if isinstance(value, float) and math.isnan(value):
            return None
        if pd.isna(value):
            return None
        stripped = str(value).strip()
        return stripped if stripped else None

    @staticmethod
    def build_split_files(split_df: pd.DataFrame) -> List[Dict[str, Any]]:
        if split_df.empty:
            raise ValueError("split_df is empty")

        df = split_df.copy()
        if "derivative_label" not in df.columns:
            if "keyword_name" not in df.columns:
                raise ValueError("split_df must have 'derivative_label' or 'keyword_name'")
            df["derivative_label"] = df["keyword_name"]

        required_columns = ["feature_id", "keyword_id", "derivative_label"]
        missing = [col for col in required_columns if col not in df.columns]
        if missing:
            raise ValueError(f"split_df missing required columns: {missing}")

        payload_df = cast(pd.DataFrame, df[required_columns])
        feature_ids = payload_df["feature_id"].to_numpy(dtype=np.int64, copy=False)
        keyword_ids = payload_df["keyword_id"].to_numpy(dtype=np.int64, copy=False)
        raw_labels = payload_df["derivative_label"].to_numpy(dtype=object, copy=False)
        norm_labels = [PayloadUtils._normalize_label_value(value) for value in raw_labels]

        files: List[Dict[str, Any]] = []
        for feature_id, keyword_id, normalized_label in zip(feature_ids, keyword_ids, norm_labels):
            files.append(
                {
                    "feature_id": int(feature_id),
                    "keyword_id": int(keyword_id),
                    "derivative_label": normalized_label,
                }
            )
        return files


class SplitDataService:
    """Upload/download split artifacts and load NPZ arrays."""

    def __init__(self, api: KWSClient, files_client: Optional[SplitFilesClient] = None):
        self._api = api
        self._files_client = files_client or SplitFilesClient(api)

    @staticmethod
    def _extract_records_from_list_response(response: Any) -> List[Dict[str, Any]]:
        if isinstance(response, list):
            return [item for item in response if isinstance(item, dict)]
        if not isinstance(response, dict):
            return []
        for key in ("items", "data", "splits", "results"):
            value = response.get(key)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]
        return []

    @staticmethod
    def _parse_split_id(item: Dict[str, Any]) -> Optional[int]:
        raw_id = item.get("dataset_splits_id")
        if raw_id is None:
            raw_id = item.get("id")
        if raw_id is None:
            return None
        try:
            return int(raw_id)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _should_continue_paging(
        response: Any,
        page: int,
        page_size: int,
        records_count: int,
    ) -> bool:
        if isinstance(response, dict):
            total_pages = response.get("total_pages")
            try:
                if total_pages is not None and page < int(total_pages):
                    return True
            except (TypeError, ValueError):
                pass

            total = response.get("total")
            page_size_raw = response.get("page_size", page_size)
            try:
                if total is not None and (page * int(page_size_raw)) < int(total):
                    return True
            except (TypeError, ValueError):
                pass

            next_page = response.get("next_page")
            if next_page not in (None, False, "", 0):
                return True

            next_value = response.get("next")
            if next_value not in (None, False, "", 0):
                return True

        return records_count >= page_size

    def _delete_existing_split_versions(
        self,
        dataset_version_id: int,
        split_name: str,
        config_name: str,
    ) -> bool:
        page = 1
        page_size = 100
        matched_ids: List[int] = []
        has_conflict = False

        while True:
            response = self._api.dataset_splits.list(
                dataset_version_id=dataset_version_id,
                config_name=config_name,
                name=split_name,
                page=page,
                page_size=page_size,
            )
            records = self._extract_records_from_list_response(response)
            for item in records:
                item_name = str(item.get("name") or item.get("split_name") or "").strip()
                item_config = str(item.get("config_name") or "").strip()
                item_dataset_version = item.get("dataset_version_id")
                if item_dataset_version is not None:
                    try:
                        if int(item_dataset_version) != dataset_version_id:
                            continue
                    except (TypeError, ValueError):
                        continue
                if item_name != split_name or item_config != config_name:
                    continue
                split_id = self._parse_split_id(item)
                if split_id is not None:
                    matched_ids.append(split_id)

            if not self._should_continue_paging(response, page=page, page_size=page_size, records_count=len(records)):
                break
            page += 1

        for split_id in sorted(set(matched_ids)):
            try:
                self._api.dataset_splits.delete_split(split_id=split_id)
                logger.info(
                    "Deleted existing split id=%s for dataset_version_id=%s name=%s config=%s",
                    split_id,
                    dataset_version_id,
                    split_name,
                    config_name,
                )
            except requests.HTTPError as exc:
                status_code = exc.response.status_code if exc.response is not None else None
                if status_code == 409:
                    has_conflict = True
                    logger.warning(
                        "Cannot delete split id=%s (409 conflict). It may be referenced by experiment runs.",
                        split_id,
                    )
                    continue
                raise
        return has_conflict

    def push_dataset_split_df(
        self,
        dataset_version_id: int,
        split_name: str,
        config_name: str,
        split_df: pd.DataFrame,
        batch_size: int = 1000,
        create_merged_keywords: Optional[Dict[str, List[int]]] = None,
    ) -> int:
        # Force a brand-new split each run: remove older versions that share
        # the same dataset_version_id + split_name + config_name.
        has_delete_conflict = self._delete_existing_split_versions(
            dataset_version_id=dataset_version_id,
            split_name=split_name,
            config_name=config_name,
        )
        effective_split_name = split_name
        if has_delete_conflict:
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            effective_split_name = f"{split_name}__fresh_{stamp}"
            logger.warning(
                "Using a new split name due to locked previous split(s): %s",
                effective_split_name,
            )

        files = PayloadUtils.build_split_files(split_df)

        split_id: Optional[int] = None
        chunk_size = max(1, batch_size)
        for start in range(0, len(files), chunk_size):
            batch_files = files[start:start + chunk_size]
            response = self._api.dataset_splits.create_split_from_list(
                dataset_version_id=dataset_version_id,
                split_name=effective_split_name,
                config_name=config_name,
                files=batch_files,
                create_merged_keywords=create_merged_keywords if start == 0 else None,
            )
            if split_id is None:
                split_id_raw = response.get("dataset_splits_id") or response.get("id")
                if split_id_raw is None:
                    raise ValueError("Missing split ID in API response")
                split_id = int(split_id_raw)

        if split_id is None:
            raise ValueError("No split_id returned from API")
        return split_id

    def push_named_splits(
        self,
        dataset_version_id: int,
        config_name: str,
        splits: Dict[str, pd.DataFrame],
        *,
        batch_size: int = 1000,
        create_merged_keywords: Optional[Dict[str, List[int]]] = None,
        auto_detect_merged_keywords: bool = True,
    ) -> Dict[str, int]:
        if not splits:
            return {}

        required = ["feature_id", "keyword_id", "derivative_label"]
        for name, frame in splits.items():
            if frame.empty:
                continue
            missing = [c for c in required if c not in frame.columns]
            if missing:
                raise ValueError(f"Split '{name}' thiếu cột: {missing}")

        merged = create_merged_keywords
        if auto_detect_merged_keywords and merged is None:
            first_name = next(iter(splits))
            first_df = splits[first_name]
            if not first_df.empty and "keyword_name" in first_df.columns:
                groups = first_df.groupby("keyword_name")["keyword_id"].unique()
                merged = {
                    str(k): [int(x) for x in sorted(v.tolist())]
                    for k, v in groups.items()
                    if len(v) > 1
                }
                if merged:
                    logger.info("Auto-detected merged keywords: %s", list(merged))

        first_split_name = next(iter(splits))
        created_splits: Dict[str, int] = {}
        for split_name, split_df in splits.items():
            if split_df.empty:
                continue
            files = PayloadUtils.build_split_files(split_df)
            split_id: Optional[int] = None
            chunk_size = max(1, batch_size)
            for start in range(0, len(files), chunk_size):
                batch_files = files[start:start + chunk_size]
                response = self._api.dataset_splits.create_split_from_list(
                    dataset_version_id=dataset_version_id,
                    split_name=split_name,
                    config_name=config_name,
                    files=batch_files,
                    create_merged_keywords=(
                        merged
                        if split_name == first_split_name and start == 0
                        else None
                    ),
                )
                if split_id is None:
                    split_id_raw = response.get("dataset_splits_id") or response.get("id")
                    if split_id_raw is None:
                        raise ValueError(f"API did not return split id for '{split_name}'")
                    split_id = int(split_id_raw)
            if split_id is None:
                continue
            created_splits[split_name] = split_id
            logger.info("Đã tạo split '%s' (ID: %s).", split_name, created_splits[split_name])
        return created_splits

    @staticmethod
    def _count_local_npz(output_dir: Path) -> int:
        return sum(1 for _ in output_dir.glob("*.npz"))

    def download_split_npz(
        self,
        split_id: int,
        output_dir: Path,
        skip_existing: bool = True,
    ) -> Dict[str, Any]:
        output_dir.mkdir(parents=True, exist_ok=True)
        file_info = self._files_client.list_files(split_id=split_id, file_type="npz")
        files = file_info.get("files", [])
        if not files:
            raise ValueError(f"Split {split_id} has no npz files")

        expected_count = len(files)
        current_count = self._count_local_npz(output_dir)
        if current_count >= expected_count:
            return {
                "split_id": split_id,
                "expected_npz_files": expected_count,
                "downloaded_local_npz_files": current_count,
                "output_dir": str(output_dir),
                "skipped_download": True,
            }

        self._files_client.download_all_npz(
            split_id=split_id,
            output_dir=str(output_dir),
            skip_existing=skip_existing,
        )

        return {
            "split_id": split_id,
            "expected_npz_files": expected_count,
            "downloaded_local_npz_files": self._count_local_npz(output_dir),
            "output_dir": str(output_dir),
            "skipped_download": False,
        }

    def load_split_npz_arrays(
        self,
        split_id: int,
        out_dir: Path,
        label_to_id: Optional[Dict[str, int]] = None,
    ) -> Tuple[np.ndarray, np.ndarray, Dict[str, int]]:
        out_dir.mkdir(parents=True, exist_ok=True)
        file_info = self._files_client.list_files(split_id=split_id, file_type="npz")
        files = file_info.get("files", [])
        if not files:
            raise ValueError(f"Split {split_id} has no npz files")

        X, y, label_map = load_npz_files(
            data_dir=str(out_dir),
            api_client=self._api,
            file_info_map=files,
            label_to_id=label_to_id,
        )
        return X, y, label_map


class FeatureArrayOps:
    """Helpers for ndarray post-processing in training pipeline."""

    @staticmethod
    def to_mel_time(x: np.ndarray, n_mels: int = 40) -> np.ndarray:
        if x.ndim != 3:
            raise ValueError(f"Expected 3D array, got shape {x.shape}")

        if x.shape[1] == n_mels:
            return x
        if x.shape[2] == n_mels:
            return np.transpose(x, (0, 2, 1))

        out = x
        if out.shape[1] > n_mels:
            out = out[:, :n_mels, :]
        elif out.shape[1] < n_mels:
            pad = np.zeros((out.shape[0], n_mels - out.shape[1], out.shape[2]), dtype=out.dtype)
            out = np.concatenate([out, pad], axis=1)
        return out

    @staticmethod
    def arrays_by_class(
        X: np.ndarray,
        y: np.ndarray,
        id_to_label: Dict[int, str],
    ) -> Dict[str, np.ndarray]:
        if X.shape[0] != y.shape[0]:
            raise ValueError(f"X and y length mismatch: {X.shape[0]} vs {y.shape[0]}")
        if y.size == 0:
            return {}

        order = np.argsort(y, kind="stable")
        sorted_y = y[order]
        sorted_X = X[order]
        unique_ids, starts = np.unique(sorted_y, return_index=True)
        ends = np.append(starts[1:], len(sorted_y))

        out: Dict[str, np.ndarray] = {}
        for cls_id, start, end in zip(unique_ids, starts, ends):
            out[id_to_label[int(cls_id)]] = sorted_X[start:end]
        return out


class KWSSession:
    """KWS session wrapper for API and split file operations."""

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        *,
        token: Optional[str] = None,
        api_key: Optional[str] = None,
    ):
        self._client = KWSClient(base_url=base_url, token=token, api_key=api_key)
        self._files_client = SplitFilesClient(self._client)

    @property
    def api(self) -> KWSClient:
        return self._client

    @property
    def client(self) -> KWSClient:
        return self._client

    @property
    def files_client(self) -> SplitFilesClient:
        return self._files_client

class DatasetPipeline:
    """Pipeline: fetch data -> filter classes -> split/push -> download/load arrays."""

    def __init__(self, session: KWSSession):
        self._session = session
        self._api = session.api
        self._data_loader = SplitDataLoader(self._api, session.files_client)
        self._split_service = SplitDataService(self._api, session.files_client)

    def get_data(
        self,
        dataset_version_id: int,
        feature_type_id: Optional[int] = None,
        keyword_ids: Optional[List[int]] = None,
    ) -> pd.DataFrame:
        df = self._api.dataset_splits.get_mfcc_files(
            dataset_version_id=dataset_version_id,
            feature_type_id=feature_type_id,
            keyword_ids=keyword_ids,
        )
        logger.info("Lấy dữ liệu: %s mẫu.", len(df))
        return df

    def filter_classes(
        self,
        df: pd.DataFrame,
        class_names: List[str],
        label_column: str = "derivative_label",
    ) -> pd.DataFrame:
        out = cast(pd.DataFrame, df[df["keyword_name"].isin(class_names)].copy())
        out[label_column] = out["keyword_name"]
        logger.info("Sau lọc %s class: %s mẫu.", len(class_names), len(out))
        return out

    def split_and_push(
        self,
        df: pd.DataFrame,
        config_name: str,
        dataset_version_id: int,
        train_size: float = 0.8,
        test_size: float = 0.2,
        val_size: float = 0.0,
        random_state: int = 42,
        stratify: bool = True,
        batch_size: int = 1000,
        create_merged_keywords: Optional[Dict[str, List[int]]] = None,
        auto_detect_merged_keywords: bool = True,
    ) -> Dict[str, int]:
        if abs(train_size + test_size + val_size - 1.0) > 1e-6:
            raise ValueError("train_size + test_size + val_size phải bằng 1.0")

        stratify_col = df["derivative_label"] if stratify else None
        from sklearn.model_selection import train_test_split  # type: ignore[import-untyped]

        if val_size <= 0:
            train_df, test_df = train_test_split(
                df,
                train_size=train_size,
                test_size=test_size,
                random_state=random_state,
                stratify=stratify_col,
            )
            splits = {"train": train_df, "test": test_df}
        else:
            train_df, rest_df = train_test_split(
                df,
                train_size=train_size,
                test_size=(val_size + test_size),
                random_state=random_state,
                stratify=stratify_col,
            )
            rest_stratify = rest_df["derivative_label"] if stratify else None
            val_ratio = val_size / (val_size + test_size) if (val_size + test_size) > 0 else 0
            val_df, test_df = train_test_split(
                rest_df,
                train_size=val_ratio,
                test_size=(1 - val_ratio),
                random_state=random_state,
                stratify=rest_stratify,
            )
            splits = {"train": train_df, "val": val_df, "test": test_df}

        return self._split_service.push_named_splits(
            dataset_version_id=dataset_version_id,
            config_name=config_name,
            splits=splits,
            batch_size=batch_size,
            create_merged_keywords=create_merged_keywords,
            auto_detect_merged_keywords=auto_detect_merged_keywords,
        )

    def load_arrays(
        self,
        train_split_id: int,
        test_split_id: int,
        base_dir: str = "data",
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[str, int]]:
        return self._data_loader.download_and_load_data(
            train_split_id=train_split_id,
            test_split_id=test_split_id,
            base_dir=base_dir,
        )

    def run(
        self,
        dataset_version_id: int,
        config_name: str,
        class_names: List[str],
        feature_type_id: Optional[int] = None,
        train_size: float = 0.8,
        test_size: float = 0.2,
        val_size: float = 0.0,
        random_state: int = 42,
        base_dir: str = "data",
        max_samples_per_class: Optional[int] = None,
        max_total_samples: Optional[int] = None,
        split_ids: Optional[Dict[str, int]] = None,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[str, int], Dict[str, int]]:
        if split_ids is not None:
            if "train" not in split_ids or "test" not in split_ids:
                raise ValueError("split_ids phải có key 'train' và 'test'")
            train_id = split_ids["train"]
            test_id = split_ids["test"]
            logger.info("Dùng split có sẵn: train=%s, test=%s. Chỉ tải file thiếu.", train_id, test_id)
        else:
            df = self.get_data(dataset_version_id, feature_type_id=feature_type_id)
            df = self.filter_classes(df, class_names)
            if max_samples_per_class is not None and max_samples_per_class > 0 and "derivative_label" in df.columns:
                sampled = [
                    grp.sample(
                        n=min(len(grp), max_samples_per_class),
                        random_state=random_state,
                    )
                    for _, grp in df.groupby("derivative_label", sort=False)
                ]
                df = pd.concat(sampled, ignore_index=True) if sampled else df.iloc[0:0].copy()
                logger.info("Giới hạn tối đa %s mẫu/class -> %s mẫu.", max_samples_per_class, len(df))
            if max_total_samples is not None and max_total_samples > 0 and len(df) > max_total_samples:
                df = df.sample(n=max_total_samples, random_state=random_state).reset_index(drop=True)
                logger.info("Giới hạn tổng %s mẫu -> %s mẫu.", max_total_samples, len(df))
            split_ids = self.split_and_push(
                df,
                config_name,
                dataset_version_id,
                train_size=train_size,
                test_size=test_size,
                val_size=val_size,
                random_state=random_state,
            )
            train_id = split_ids["train"]
            test_id = split_ids["test"]

        X_train, y_train, X_test, y_test, label_to_id = self.load_arrays(
            train_id,
            test_id,
            base_dir=base_dir,
        )
        if split_ids is None:
            raise ValueError("split_ids is missing after split creation")
        return X_train, y_train, X_test, y_test, label_to_id, split_ids

    def fetch_feature_catalog(
        self,
        dataset_version_id: int,
        feature_type_id: Optional[int] = None,
        keyword_ids: Optional[List[int]] = None,
    ) -> pd.DataFrame:
        return self.get_data(
            dataset_version_id=dataset_version_id,
            feature_type_id=feature_type_id,
            keyword_ids=keyword_ids,
        )

    def select_classes(
        self,
        df: pd.DataFrame,
        class_names: List[str],
        label_column: str = "derivative_label",
    ) -> pd.DataFrame:
        return self.filter_classes(df=df, class_names=class_names, label_column=label_column)


def push_dataset_split_df(
    api: KWSClient,
    dataset_version_id: int,
    split_name: str,
    config_name: str,
    split_df: pd.DataFrame,
    batch_size: int = 1000,
    create_merged_keywords: Optional[Dict[str, List[int]]] = None,
) -> int:
    return SplitDataService(api).push_dataset_split_df(
        dataset_version_id=dataset_version_id,
        split_name=split_name,
        config_name=config_name,
        split_df=split_df,
        batch_size=batch_size,
        create_merged_keywords=create_merged_keywords,
    )


def download_split_npz(
    api: KWSClient,
    split_id: int,
    output_dir: Path,
    skip_existing: bool = True,
) -> Dict[str, Any]:
    return SplitDataService(api).download_split_npz(
        split_id=split_id,
        output_dir=output_dir,
        skip_existing=skip_existing,
    )


def load_split_npz_arrays(
    api: KWSClient,
    split_id: int,
    out_dir: Path,
    label_to_id: Optional[Dict[str, int]] = None,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, int]]:
    return SplitDataService(api).load_split_npz_arrays(
        split_id=split_id,
        out_dir=out_dir,
        label_to_id=label_to_id,
    )


def to_mel_time(x: np.ndarray, n_mels: int = 40) -> np.ndarray:
    return FeatureArrayOps.to_mel_time(x=x, n_mels=n_mels)


def arrays_by_class(
    X: np.ndarray,
    y: np.ndarray,
    id_to_label: Dict[int, str],
) -> Dict[str, np.ndarray]:
    return FeatureArrayOps.arrays_by_class(X=X, y=y, id_to_label=id_to_label)


__all__ = [
    "PayloadUtils",
    "SplitDataService",
    "FeatureArrayOps",
    "KWSSession",
    "DatasetPipeline",
    "push_dataset_split_df",
    "download_split_npz",
    "load_split_npz_arrays",
    "to_mel_time",
    "arrays_by_class",
]
