import argparse
import os
import sys
from typing import List, Optional

from .client import KWSClient


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="KWS smoke checks (Research quick start).")
    parser.add_argument(
        "--base-url",
        default=os.getenv("KWS_SERVER_URL", "http://127.0.0.1:8000"),
        help="KWS_Server base URL (default: env KWS_SERVER_URL or http://127.0.0.1:8000)",
    )
    args = parser.parse_args(argv)

    try:
        client = KWSClient(base_url=args.base_url)
        api = client.health()
        root = client.health_root()
    except Exception as e:
        print(f"smoke=FAIL base_url={args.base_url} error={e}", file=sys.stderr)
        return 2

    print(f"base_url={args.base_url}")
    print(f"/api/health={api.get('status')}")
    print(f"/health={root.get('status')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
