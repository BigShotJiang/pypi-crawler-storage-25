#!/usr/bin/env python
# coding: utf-8
from __future__ import print_function, unicode_literals

import argparse
import codecs
import difflib
import json
import os
import sys
import tempfile
import time
from code import InteractiveConsole
from pydoc import TextDoc
from threading import Lock, Thread

from ctypes_unicode_proclaunch import launch as ctypes_unicode_launch
from ctypes_unicode_proclaunch import terminate as ctypes_unicode_terminate
from ctypes_unicode_proclaunch import wait as ctypes_unicode_wait
from escape_nt_command_line_argument import escape_nt_command_line_argument
from get_unicode_multiline_input_with_editor import (
    get_unicode_multiline_input_with_editor,
)
from get_unicode_shell import get_unicode_shell
from live_tee_and_capture import live_tee_and_capture
from posix_or_nt import posix_or_nt
from textcompat import get_stdout_encoding, stdin_str_to_text
from typing import IO, Text

POSIX_OR_NT = posix_or_nt()

if sys.version_info < (3,):
    from urllib2 import Request, urlopen, HTTPError, URLError

    SYS_STDOUT_BUFFER = sys.stdout

    def post_request_instance(url, data, headers):
        # type: (Text, bytes, dict) -> Request
        return Request(url, data=data, headers=headers)
else:
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError

    SYS_STDOUT_BUFFER = sys.stdout.buffer

    def post_request_instance(url, data, headers):
        # type: (Text, bytes, dict) -> Request
        return Request(url, data=data, headers=headers, method="POST")

def fputs(file, text):
    # type: (IO, Text) -> None
    encoded = text.encode(get_stdout_encoding(), errors="ignore")
    file.write(encoded)

DEFAULT_MAX_LINES = 2000
DEFAULT_MAX_BYTES = 50 * 1024
DEFAULT_BASH_TIMEOUT = 30
MAX_AGENT_STEPS = 32
CONTEXT_FILE_NAMES = ("AGENTS.md", "CLAUDE.md")

SYSTEM_PROMPT = """You are a minimal coding agent with four tools: read, write, edit, bash (%s).

Tool rules:
- Use read to inspect files.
- Use write only for creating new files or completely rewriting files.
- Use edit for precise changes to existing files.
- For edit, every edits[].oldText must match exactly once in the original file.
- All edits in one call are matched against the original file, not incrementally.
- Do not create overlapping edits.
- Use bash for shell commands, search, git status, running linters, etc.
- Prefer short, safe bash commands.
- If a file is large, use read with offset/limit.
- Be concise and technical.
""" % get_unicode_shell()

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read",
            "description": (
                "Read the contents of a file. Supports text files. "
                "Output is truncated to 2000 lines or 50KB. "
                "Use offset/limit for large files."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file to read",
                    },
                    "offset": {
                        "type": "integer",
                        "description": "Line number to start reading from (1-indexed)",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of lines to read",
                    },
                },
                "required": ["path"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write",
            "description": (
                "Write content to a file. Creates the file if it does not exist, "
                "overwrites if it does. Automatically creates parent directories."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file to write",
                    },
                    "content": {
                        "type": "string",
                        "description": "Content to write to the file",
                    },
                },
                "required": ["path", "content"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "edit",
            "description": (
                "Edit a single file using exact text replacement. "
                "Each edits[].oldText must match a unique, non-overlapping region "
                "of the original file."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file to edit",
                    },
                    "edits": {
                        "type": "array",
                        "description": "List of exact replacements",
                        "items": {
                            "type": "object",
                            "properties": {
                                "oldText": {"type": "string"},
                                "newText": {"type": "string"},
                            },
                            "required": ["oldText", "newText"],
                            "additionalProperties": False,
                        },
                    },
                },
                "required": ["path", "edits"],
                "additionalProperties": False,
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "bash",
            "description": (
                "Execute a bash command in the current working directory. "
                "Returns stdout and stderr combined. Output is truncated to the last "
                "2000 lines or 50KB. Optional timeout in seconds."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "Bash command to execute",
                    },
                    "timeout": {
                        "type": "integer",
                        "description": "Timeout in seconds",
                    },
                },
                "required": ["command"],
                "additionalProperties": False,
            },
        },
    },
]


def to_utf8_bytes(text):
    # type: (Text) -> bytes
    if sys.version_info >= (3,):
        return text.encode("utf-8")
    else:
        return text


def resolve_path(path, cwd):
    # type: (Text, Text) -> Text
    expanded = os.path.expanduser(path)
    if not os.path.isabs(expanded):
        expanded = os.path.join(cwd, expanded)
    return os.path.realpath(expanded)


def read_binary_file(path):
    # type: (Text) -> bytes
    with open(path, "rb") as handle:
        return handle.read()


def write_text_file(path, content):
    # type: (Text, Text) -> None
    with codecs.open(path, "w", encoding="utf-8") as handle:
        handle.write(content)


def read_text_file(path):
    # type: (Text) -> Text
    with codes.open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def find_context_file_paths(cwd):
    # type: (Text) -> list
    resolved_cwd = resolve_path(cwd, os.getcwd())
    directories = []
    current = resolved_cwd
    while True:
        directories.append(current)
        parent = os.path.dirname(current)
        if parent == current:
            break
        current = parent

    directories.reverse()
    paths = []
    for directory in directories:
        for file_name in CONTEXT_FILE_NAMES:
            path = os.path.join(directory, file_name)
            if os.path.isfile(path):
                paths.append(path)
    return paths


def build_context_prompt(context_file_paths):
    # type: (list) -> Text
    if not context_file_paths:
        return ""

    sections = [
        "The following project instruction files were discovered from the working directory to the filesystem root.",
        "Follow them in addition to the base system prompt.",
        "",
    ]
    for path in context_file_paths:
        try:
            content = read_text_file(path)
        except Exception as exc:
            content = "[Failed to read context file: %s]" % exc
        sections.extend(
            [
                "--- %s ---" % path,
                content,
                "",
            ]
        )
    return "\n".join(sections).rstrip()


def compose_system_prompt(base_system_prompt, cwd, context_files_enabled):
    # type: (Text, Text, bool) -> tuple
    if not context_files_enabled:
        return base_system_prompt, []

    context_file_paths = find_context_file_paths(cwd)
    if not context_file_paths:
        return base_system_prompt, []

    context_prompt = build_context_prompt(context_file_paths)
    if not context_prompt:
        return base_system_prompt, context_file_paths

    return "%s\n\n%s" % (base_system_prompt, context_prompt), context_file_paths


def estimate_tokens(text):
    # type: (object) -> int
    value = Text(text)
    if not value:
        return 0
    return max(1, (len(value) + 3) // 4)


def estimate_message_tokens(messages):
    # type: (list) -> int
    total = 0
    for message in messages:
        total += estimate_tokens(extract_text_content(message.get("content")))
        tool_calls = message.get("tool_calls") or []
        if tool_calls:
            total += estimate_tokens(json.dumps(tool_calls))
        tool_call_id = message.get("tool_call_id")
        if tool_call_id:
            total += estimate_tokens(tool_call_id)
        role = message.get("role")
        if role:
            total += estimate_tokens(role)
    return total


def parse_usage(usage, messages, content):
    # type: (object, list, Text) -> dict
    prompt_tokens = None
    completion_tokens = None
    if isinstance(usage, dict):
        prompt_tokens = usage.get("prompt_tokens")
        if prompt_tokens is None:
            prompt_tokens = usage.get("input_tokens")
        completion_tokens = usage.get("completion_tokens")
        if completion_tokens is None:
            completion_tokens = usage.get("output_tokens")

    if prompt_tokens is None:
        prompt_tokens = estimate_message_tokens(messages)
    if completion_tokens is None:
        completion_tokens = estimate_tokens(content)

    return {
        "prompt_tokens": int(prompt_tokens),
        "completion_tokens": int(completion_tokens),
    }


def format_token_summary(
    prompt_tokens, completion_tokens, total_prompt_tokens, total_completion_tokens
):
    # type: (int, int, int, int) -> Text
    return "[tokens in=%s out=%s total_in=%s total_out=%s]" % (
        prompt_tokens,
        completion_tokens,
        total_prompt_tokens,
        total_completion_tokens,
    )


def resolve_chat_completions_url(base_url):
    # type: (Text) -> Text
    url = (base_url or "").rstrip("/")
    if url.endswith("/chat/completions"):
        return url
    return url + "/chat/completions"


def json_post(url, api_key, payload):
    # type: (Text, Text, dict) -> dict
    data = to_utf8_bytes(json.dumps(payload))
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = "Bearer %s" % api_key

    request = post_request_instance(url, data=data, headers=headers)
    try:
        response = urlopen(request)
        body = response.read().decode("utf-8", "replace")
        return json.loads(body)
    except HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")
        raise RuntimeError("HTTP %s: %s" % (getattr(exc, "code", "?"), body))
    except URLError as exc:
        raise RuntimeError("Request failed: %s" % exc)


def open_sse_stream(url, api_key, payload):
    # type: (Text, Text, dict) -> object
    data = to_utf8_bytes(json.dumps(payload))
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = "Bearer %s" % api_key

    request = post_request_instance(url, data=data, headers=headers)
    try:
        return urlopen(request)
    except HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")
        raise RuntimeError("HTTP %s: %s" % (getattr(exc, "code", "?"), body))
    except URLError as exc:
        raise RuntimeError("Request failed: %s" % exc)


def extract_text_content(content):
    # type: (object) -> Text
    if content is None:
        return ""
    if isinstance(content, Text):
        return content
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, Text):
                parts.append(item)
            elif isinstance(item, dict):
                if item.get("type") == "text" and isinstance(item.get("text"), Text):
                    parts.append(item.get("text"))
        return "".join(parts)
    return Text(content)


def truncate_head_lines(lines):
    # type: (list) -> tuple
    output_lines = []
    used_bytes = 0
    index = 0
    for line in lines:
        piece = line if index == 0 else "\n" + line
        piece_bytes = len(to_utf8_bytes(piece))
        if index >= DEFAULT_MAX_LINES or used_bytes + piece_bytes > DEFAULT_MAX_BYTES:
            break
        output_lines.append(line)
        used_bytes += piece_bytes
        index += 1
    truncated = len(output_lines) < len(lines)
    return "\n".join(output_lines), truncated, len(output_lines)


def truncate_tail_text(text):
    # type: (Text) -> tuple
    lines = text.splitlines()
    if not lines and not text:
        return "", False, None

    kept = lines[-DEFAULT_MAX_LINES:]
    joined = "\n".join(kept)
    encoded = to_utf8_bytes(joined)
    if len(encoded) > DEFAULT_MAX_BYTES:
        encoded = encoded[-DEFAULT_MAX_BYTES:]
        joined = encoded.decode("utf-8", "replace")

    original_bytes = len(to_utf8_bytes(text))
    truncated = len(kept) < len(lines) or original_bytes > DEFAULT_MAX_BYTES
    temp_path = None
    if truncated:
        handle = tempfile.NamedTemporaryFile(
            prefix="pi-bash-", suffix=".log", delete=False
        )
        try:
            handle.write(to_utf8_bytes(text))
        finally:
            handle.close()
        temp_path = Text(handle.name)
    return joined, truncated, temp_path


def tool_read(arguments, cwd):
    # type: (dict, Text) -> Text
    path = resolve_path(arguments["path"], cwd)
    raw_offset = arguments.get("offset", 1)
    try:
        if raw_offset is None or raw_offset == "":
            offset = 1
        else:
            offset = int(raw_offset)
    except (TypeError, ValueError):
        return "Error: offset must be an integer"
    limit = arguments.get("limit")

    if offset < 1:
        return "Error: offset must be >= 1"

    try:
        raw = read_binary_file(path)
    except Exception as exc:
        return "Error reading %s: %s" % (path, exc)

    if b"\x00" in raw[:8192]:
        return "Binary file not displayed: %s" % path

    text = raw.decode("utf-8", "replace")
    all_lines = text.split("\n")
    total_lines = len(all_lines)
    start = offset - 1
    if start >= total_lines:
        return "Error: offset %s is beyond end of file (%s lines total)" % (
            offset,
            total_lines,
        )

    selected = all_lines[start:]
    if limit is not None:
        try:
            limit = int(limit)
        except (TypeError, ValueError):
            return "Error: limit must be an integer"
        if limit < 0:
            return "Error: limit must be >= 0"
        selected = selected[:limit]

    truncated_text, truncated, shown_lines = truncate_head_lines(selected)
    end_line = start + shown_lines

    if truncated:
        return "%s\n\n[Showing lines %s-%s of %s. Use offset=%s to continue.]" % (
            truncated_text,
            offset,
            end_line,
            total_lines,
            end_line + 1,
        )

    if limit is not None and end_line < total_lines:
        return "%s\n\n[%s more lines in file. Use offset=%s to continue.]" % (
            truncated_text,
            total_lines - end_line,
            end_line + 1,
        )

    return truncated_text


def ensure_parent_dir(path):
    # type: (Text) -> None
    directory = os.path.dirname(path)
    if directory and not os.path.isdir(directory):
        os.makedirs(directory)


def tool_write(arguments, cwd):
    # type: (dict, Text) -> Text
    path = resolve_path(arguments["path"], cwd)
    content = arguments["content"]
    try:
        ensure_parent_dir(path)
        write_text_file(path, content)
        return "Successfully wrote %s bytes to %s" % (len(to_utf8_bytes(content)), path)
    except Exception as exc:
        return "Error writing %s: %s" % (path, exc)


def find_all_occurrences(haystack, needle):
    # type: (Text, Text) -> list
    if needle == "":
        return []
    positions = []
    start = 0
    while True:
        index = haystack.find(needle, start)
        if index == -1:
            break
        positions.append(index)
        start = index + 1
    return positions


def apply_exact_edits(original, edits):
    # type: (Text, list) -> Text
    spans = []
    edit_index = 0
    for edit in edits:
        old_text = edit["oldText"]
        new_text = edit["newText"]
        if old_text == "":
            raise ValueError("Edit %s: oldText must not be empty" % edit_index)
        positions = find_all_occurrences(original, old_text)
        if len(positions) == 0:
            raise ValueError("Edit %s: oldText not found" % edit_index)
        if len(positions) > 1:
            raise ValueError(
                "Edit %s: oldText matched %s times, must match exactly once"
                % (edit_index, len(positions))
            )
        start = positions[0]
        end = start + len(old_text)
        spans.append((start, end, new_text))
        edit_index += 1

    spans.sort(key=lambda item: item[0])
    index = 1
    while index < len(spans):
        previous_end = spans[index - 1][1]
        current_start = spans[index][0]
        if current_start < previous_end:
            raise ValueError("Edits overlap. Merge nearby changes into a single edit.")
        index += 1

    output = []
    cursor = 0
    for start, end, new_text in spans:
        output.append(original[cursor:start])
        output.append(new_text)
        cursor = end
    output.append(original[cursor:])
    return "".join(output)


def unified_diff(old_text, new_text, path):
    # type: (Text, Text, Text) -> Text
    diff_lines = difflib.unified_diff(
        old_text.splitlines(),
        new_text.splitlines(),
        fromfile=path,
        tofile=path,
        lineterm="",
    )
    return "\n".join(diff_lines)


def tool_edit(arguments, cwd):
    # type: (dict, Text) -> Text
    path = resolve_path(arguments["path"], cwd)
    edits = arguments["edits"]

    try:
        original = read_text_file(path)
    except Exception as exc:
        return "Error reading %s for edit: %s" % (path, exc)

    try:
        updated = apply_exact_edits(original, edits)
    except Exception as exc:
        return "Edit failed: %s" % exc

    if updated == original:
        return "No changes made."

    try:
        write_text_file(path, updated)
    except Exception as exc:
        return "Error writing edited file %s: %s" % (path, exc)

    diff = unified_diff(original, updated, path)
    return "Applied %s edit(s) to %s\n\n%s" % (len(edits), path, diff)


def shell_quote(text):
    # type: (Text) -> Text
    value = Text(text)
    if POSIX_OR_NT == "nt":
        return escape_nt_command_line_argument(value)
    return "'" + value.replace("'", "'\\''") + "'"


def get_shell_command_prefix(cwd):
    # type: (Text) -> list
    if POSIX_OR_NT == "nt":
        return ["cmd.exe", "/c"]
    shell = get_unicode_shell() or "/bin/sh"
    return [shell, "-lc"]


def build_live_bash_command(command, cwd):
    # type: (Text, Text) -> list
    shell_command = "cd %s && %s" % (shell_quote(cwd), command)
    return get_shell_command_prefix(cwd) + [shell_command]


class LaunchedProcess(object):
    __slots__ = ("pid", "stdout", "stderr", "returncode", "_wait_thread")

    def __init__(self, pid, stdout, stderr):
        # type: (object, object, object) -> None
        self.pid = pid
        self.stdout = stdout
        self.stderr = stderr
        self.returncode = None
        self._wait_thread = Thread(target=self._wait_worker)
        self._wait_thread.daemon = True
        self._wait_thread.start()

    def _wait_worker(self):
        # type: () -> None
        try:
            self.returncode = ctypes_unicode_wait(self.pid)
        except Exception:
            self.returncode = None

    def poll(self):
        # type: () -> object
        return self.returncode

    def wait(self):
        # type: () -> object
        self._wait_thread.join()
        return self.returncode

    def close_streams(self):
        # type: () -> None
        for stream in (self.stdout, self.stderr):
            if stream is not None:
                try:
                    stream.close()
                except Exception:
                    pass


def start_bash_process(command, cwd):
    # type: (Text, Text) -> object
    command_parts = build_live_bash_command(command, cwd)
    stdout_read_fd = None
    stdout_write_fd = None
    stderr_read_fd = None
    stderr_write_fd = None
    try:
        stdout_read_fd, stdout_write_fd = os.pipe()
        stderr_read_fd, stderr_write_fd = os.pipe()
        pid = ctypes_unicode_launch(
            command_parts,
            stdout_file_descriptor=stdout_write_fd,
            stderr_file_descriptor=stderr_write_fd,
        )
        os.close(stdout_write_fd)
        stdout_write_fd = None
        os.close(stderr_write_fd)
        stderr_write_fd = None
        stdout_stream = os.fdopen(stdout_read_fd, "rb")
        stdout_read_fd = None
        stderr_stream = os.fdopen(stderr_read_fd, "rb")
        stderr_read_fd = None
        return LaunchedProcess(pid, stdout_stream, stderr_stream)
    except Exception:
        for file_descriptor in (
            stdout_read_fd,
            stdout_write_fd,
            stderr_read_fd,
            stderr_write_fd,
        ):
            if file_descriptor is not None:
                try:
                    os.close(file_descriptor)
                except Exception:
                    pass
        raise


def terminate_process(process):
    # type: (object) -> None
    try:
        ctypes_unicode_terminate(process.pid)
    except Exception:
        pass


def live_capture_reader_worker(
    readable, buffer, tee_fd, combined_buffer=None, combined_lock=None
):
    # type: (object, bytearray, object, object, object) -> None
    while True:
        chunk = readable.read(1)
        if not chunk:
            break
        buffer.extend(chunk)
        if combined_buffer is not None:
            if combined_lock is not None:
                combined_lock.acquire()
            try:
                combined_buffer.extend(chunk)
            finally:
                if combined_lock is not None:
                    combined_lock.release()
        if tee_fd is not None:
            try:
                os.write(tee_fd, chunk)
            except Exception:
                pass


def communicate_with_timeout(process, timeout, live_output=False):
    # type: (object, int, bool) -> tuple
    deadline = None
    if timeout is not None and timeout > 0:
        deadline = time.time() + timeout

    stdout_thread = None
    stderr_thread = None
    SYS_STDOUT_BUFFER = bytearray()
    stderr_buffer = bytearray()
    combined_buffer = bytearray()
    combined_lock = Lock()

    if process.stdout is not None:
        stdout_tee_fd = None
        if live_output:
            try:
                stdout_tee_fd = SYS_STDOUT_BUFFER.fileno()
            except Exception:
                stdout_tee_fd = None
        stdout_thread = Thread(
            target=live_capture_reader_worker,
            args=(
                process.stdout,
                SYS_STDOUT_BUFFER,
                stdout_tee_fd,
                combined_buffer,
                combined_lock,
            ),
        )
        stdout_thread.daemon = True
        stdout_thread.start()

    if process.stderr is not None:
        stderr_tee_fd = None
        if live_output:
            try:
                stderr_tee_fd = sys.stderr.fileno()
            except Exception:
                stderr_tee_fd = None
        stderr_thread = Thread(
            target=live_capture_reader_worker,
            args=(
                process.stderr,
                stderr_buffer,
                stderr_tee_fd,
                combined_buffer,
                combined_lock,
            ),
        )
        stderr_thread.daemon = True
        stderr_thread.start()

    while True:
        if process.poll() is not None:
            if stdout_thread is not None:
                stdout_thread.join()
            if stderr_thread is not None:
                stderr_thread.join()
            process.close_streams()
            return combined_buffer, process.returncode, False
        if deadline is not None and time.time() >= deadline:
            terminate_process(process)
            if stdout_thread is not None:
                stdout_thread.join()
            if stderr_thread is not None:
                stderr_thread.join()
            process.close_streams()
            return combined_buffer, None, True
        time.sleep(0.05)


def run_bash_with_package(command, cwd):
    # type: (Text, Text) -> tuple
    command_parts = build_live_bash_command(command, cwd)
    exit_code, SYS_STDOUT_BUFFER, stderr_buffer = live_tee_and_capture(
        command_parts, tee_stdout=True, tee_stderr=True
    )
    combined = bytearray()
    combined.extend(SYS_STDOUT_BUFFER)
    combined.extend(stderr_buffer)
    return combined, exit_code, False


def tool_bash(arguments, cwd):
    # type: (dict, Text) -> Text
    command = arguments["command"]
    raw_timeout = arguments.get("timeout")
    try:
        if raw_timeout is None or raw_timeout == "":
            timeout = DEFAULT_BASH_TIMEOUT
        else:
            timeout = int(raw_timeout)
    except (TypeError, ValueError):
        return "Error: timeout must be an integer"

    fputs(SYS_STDOUT_BUFFER, "$ %s\n" % command)

    try:
        if timeout is None or timeout <= 0:
            output, exit_code, timed_out = run_bash_with_package(command, cwd)
        else:
            process = start_bash_process(command, cwd)
            output, exit_code, timed_out = communicate_with_timeout(
                process, timeout, live_output=True
            )
        text_output = output.decode("utf-8", "replace")
        truncated_output, truncated, temp_path = truncate_tail_text(text_output)

        if timed_out:
            result = ["Command timed out after %ss" % timeout]
        else:
            result = ["Exit code: %s" % exit_code]

        if truncated_output:
            result.extend(["", truncated_output])
        if truncated and temp_path:
            result.extend(
                [
                    "",
                    "[Output truncated to last %s lines / %s bytes. Full output saved to: %s]"
                    % (DEFAULT_MAX_LINES, DEFAULT_MAX_BYTES, temp_path),
                ]
            )
        return "\n".join(result)
    except Exception as exc:
        return "Error executing bash command: %s" % exc


def run_tool(name, arguments, cwd):
    # type: (Text, dict, Text) -> Text
    if name == "read":
        return tool_read(arguments, cwd)
    if name == "write":
        return tool_write(arguments, cwd)
    if name == "edit":
        return tool_edit(arguments, cwd)
    if name == "bash":
        return tool_bash(arguments, cwd)
    return "Unknown tool: %s" % name


def format_tool_result_for_display(name, tool_result):
    # type: (Text, Text) -> Text
    if name != "bash":
        return tool_result

    lines = tool_result.splitlines()
    if not lines:
        return tool_result

    display_lines = [lines[0]]
    note_lines = []
    for line in lines[1:]:
        if line.startswith("[") and line.endswith("]"):
            note_lines.append(line)

    if len(lines) > 1:
        display_lines.append(
            "[live output streamed above; full bash output kept in tool result]"
        )
    display_lines.extend(note_lines)
    return "\n".join(display_lines)


def append_tool_call_delta(tool_calls, delta):
    # type: (list, dict) -> None
    index = delta.get("index", 0)
    while len(tool_calls) <= index:
        tool_calls.append(
            {"id": "", "type": "function", "function": {"name": "", "arguments": ""}}
        )

    current = tool_calls[index]
    if delta.get("id"):
        current["id"] = delta.get("id")
    if delta.get("type"):
        current["type"] = delta.get("type")

    function_delta = delta.get("function") or {}
    current_function = current.setdefault("function", {"name": "", "arguments": ""})
    if function_delta.get("name"):
        current_function["name"] = current_function.get(
            "name", ""
        ) + function_delta.get("name")
    if function_delta.get("arguments"):
        current_function["arguments"] = current_function.get(
            "arguments", ""
        ) + function_delta.get("arguments")


def finalize_tool_calls(tool_calls):
    # type: (list) -> list
    finalized = []
    for call in tool_calls:
        function_data = call.get("function") or {}
        if (
            call.get("id")
            or function_data.get("name")
            or function_data.get("arguments")
        ):
            finalized.append(call)
    return finalized


def stream_chat_once(base_url, api_key, model, messages):
    # type: (Text, Text, Text, list) -> dict
    payload = {
        "model": model,
        "messages": messages,
        "tools": TOOLS,
        "tool_choice": "auto",
        "stream": True,
    }
    response = open_sse_stream(resolve_chat_completions_url(base_url), api_key, payload)
    content_parts = []
    tool_calls = []
    usage = None

    for raw_line in response:
        line = raw_line.decode("utf-8", "replace").strip()
        if not line:
            continue
        if not line.startswith("data: "):
            continue

        chunk_data = line[6:].strip()
        if chunk_data == "[DONE]":
            break

        chunk = json.loads(chunk_data)
        if isinstance(chunk.get("usage"), dict):
            usage = chunk.get("usage")
        choices = chunk.get("choices") or []
        if not choices:
            continue

        delta = choices[0].get("delta") or {}
        content_piece = delta.get("content")
        if content_piece:
            text_piece = extract_text_content(content_piece)
            if text_piece:
                content_parts.append(text_piece)
                fputs(SYS_STDOUT_BUFFER, text_piece)

        for tool_call_delta in delta.get("tool_calls") or []:
            append_tool_call_delta(tool_calls, tool_call_delta)

    if content_parts:
        fputs(SYS_STDOUT_BUFFER, "\n")

    content = "".join(content_parts)
    token_usage = parse_usage(usage, messages, content)
    return {
        "content": content,
        "tool_calls": finalize_tool_calls(tool_calls),
        "usage": token_usage,
    }


def chat_once(base_url, api_key, model, messages):
    # type: (Text, Text, Text, list) -> dict
    payload = {
        "model": model,
        "messages": messages,
        "tools": TOOLS,
        "tool_choice": "auto",
    }
    response = json_post(resolve_chat_completions_url(base_url), api_key, payload)
    choices = response.get("choices") or []
    if not choices:
        raise RuntimeError("Invalid response: %s" % json.dumps(response, indent=2))
    message = choices[0].get("message") or {}
    content = extract_text_content(message.get("content"))
    token_usage = parse_usage(response.get("usage"), messages, content)
    return {
        "content": content,
        "tool_calls": message.get("tool_calls") or [],
        "usage": token_usage,
    }


class AgentConversation(object):
    __slots__ = (
        "api_key",
        "base_url",
        "model",
        "cwd",
        "base_system_prompt",
        "system_prompt",
        "messages",
        "stream",
        "context_files_enabled",
        "context_file_paths",
        "total_prompt_tokens",
        "total_completion_tokens",
        "last_prompt_tokens",
        "last_completion_tokens",
    )

    def __init__(
        self,
        api_key,
        base_url,
        model,
        cwd,
        system_prompt=SYSTEM_PROMPT,
        stream=True,
        context_files_enabled=True,
    ):
        # type: (Text, Text, Text, Text, Text, bool, bool) -> None
        self.api_key = api_key
        self.base_url = base_url
        self.model = model
        self.cwd = cwd
        self.base_system_prompt = system_prompt
        self.system_prompt = self.base_system_prompt
        self.messages = []
        self.stream = bool(stream)
        self.context_files_enabled = bool(context_files_enabled)
        self.context_file_paths = []
        self.total_prompt_tokens = 0
        self.total_completion_tokens = 0
        self.last_prompt_tokens = 0
        self.last_completion_tokens = 0
        self.refresh_system_prompt(update_messages=False)
        self.reset()

    def refresh_system_prompt(self, update_messages=True):
        # type: (bool) -> Text
        self.system_prompt, self.context_file_paths = compose_system_prompt(
            self.base_system_prompt,
            self.cwd,
            self.context_files_enabled,
        )
        if update_messages and self.messages:
            first_message = self.messages[0]
            if first_message.get("role") == "system":
                first_message["content"] = self.system_prompt
        return self.system_prompt

    def reset(self):
        # type: () -> None
        self.refresh_system_prompt(update_messages=False)
        self.messages = [{"role": "system", "content": self.system_prompt}]

    def append_user_message(self, text):
        # type: (Text) -> None
        self.messages.append({"role": "user", "content": text})

    def save_to_json_file(self, path):
        # type: (Text) -> None
        payload = {
            "api_key": self.api_key,
            "base_url": self.base_url,
            "model": self.model,
            "cwd": self.cwd,
            "base_system_prompt": self.base_system_prompt,
            "system_prompt": self.system_prompt,
            "stream": self.stream,
            "context_files_enabled": self.context_files_enabled,
            "context_file_paths": self.context_file_paths,
            "total_prompt_tokens": self.total_prompt_tokens,
            "total_completion_tokens": self.total_completion_tokens,
            "last_prompt_tokens": self.last_prompt_tokens,
            "last_completion_tokens": self.last_completion_tokens,
            "messages": self.messages,
        }
        kwargs = {}
        if sys.version_info >= (3,):
            kwargs["encoding"] = "utf-8"
        with open(path, "w", **kwargs) as handle:
            json.dump(payload, handle, indent=2, ensure_ascii=False)

    def load_from_json_file(self, path):
        # type: (Text) -> None
        kwargs = {}
        if sys.version_info >= (3,):
            kwargs["encoding"] = "utf-8"
        with open(path, "r", **kwargs) as handle:
            payload = json.load(handle)
        self.api_key = payload.get("api_key", self.api_key)
        self.base_url = payload.get("base_url", self.base_url)
        self.model = payload.get("model", self.model)
        self.cwd = payload.get("cwd", self.cwd)
        self.base_system_prompt = payload.get(
            "base_system_prompt", payload.get("system_prompt", self.base_system_prompt)
        )
        self.stream = bool(payload.get("stream", self.stream))
        self.context_files_enabled = bool(
            payload.get("context_files_enabled", self.context_files_enabled)
        )
        self.refresh_system_prompt(update_messages=False)
        self.system_prompt = payload.get("system_prompt", self.system_prompt)
        self.context_file_paths = payload.get(
            "context_file_paths", self.context_file_paths
        )
        self.total_prompt_tokens = int(
            payload.get("total_prompt_tokens", self.total_prompt_tokens)
        )
        self.total_completion_tokens = int(
            payload.get("total_completion_tokens", self.total_completion_tokens)
        )
        self.last_prompt_tokens = int(
            payload.get("last_prompt_tokens", self.last_prompt_tokens)
        )
        self.last_completion_tokens = int(
            payload.get("last_completion_tokens", self.last_completion_tokens)
        )
        messages = payload.get("messages")
        if not isinstance(messages, list) or not messages:
            raise ValueError(
                "Invalid conversation JSON: messages must be a non-empty list"
            )
        self.messages = messages

    def export_to_markdown(self):
        # type: () -> Text
        lines = [
            "# Conversation with %s" % self.model,
            "",
            "- cwd: `%s`" % self.cwd,
            "",
        ]
        for message in self.messages:
            role = message.get("role", "unknown")
            lines.append("## %s" % role)
            lines.append("")
            lines.append(extract_text_content(message.get("content")))
            tool_calls = message.get("tool_calls")
            if tool_calls:
                lines.extend(["", "```json", json.dumps(tool_calls, indent=2), "```"])
            tool_call_id = message.get("tool_call_id")
            if tool_call_id:
                lines.extend(["", "tool_call_id: `%s`" % tool_call_id])
            lines.append("")
        return "\n".join(lines).rstrip() + "\n"

    def correct_last_response(self, corrected):
        # type: (Text) -> bool
        index = len(self.messages) - 1
        while index >= 0:
            message = self.messages[index]
            if message.get("role") == "assistant":
                message["content"] = corrected
                return True
            index -= 1
        return False

    def show(self):
        # type: () -> None
        index = 0
        for message in self.messages:
            fputs(SYS_STDOUT_BUFFER, "[%s] %s\n" % (index, message.get("role", "unknown")))
            content = extract_text_content(message.get("content"))
            if content:
                fputs(SYS_STDOUT_BUFFER, content)
                fputs(SYS_STDOUT_BUFFER, "\n")
            tool_calls = message.get("tool_calls")
            if tool_calls:
                fputs(SYS_STDOUT_BUFFER, json.dumps(tool_calls, indent=2))
                fputs(SYS_STDOUT_BUFFER, "\n")
            tool_call_id = message.get("tool_call_id")
            if tool_call_id:
                fputs(SYS_STDOUT_BUFFER, "tool_call_id: %s\n" % tool_call_id)
            fputs(SYS_STDOUT_BUFFER, "\n")
            index += 1

    def set_stream(self, enabled=None):
        # type: (object) -> bool
        if enabled is not None:
            self.stream = bool(enabled)
        return self.stream

    def request_assistant_message(self):
        # type: () -> dict
        if self.stream:
            return stream_chat_once(
                self.base_url, self.api_key, self.model, self.messages
            )
        return chat_once(self.base_url, self.api_key, self.model, self.messages)

    def send(self, text=""):
        # type: (Text) -> None
        if text:
            self.append_user_message(text)

        current_prompt_tokens = 0
        current_completion_tokens = 0
        step = 0
        while step < MAX_AGENT_STEPS:
            assistant_message = self.request_assistant_message()
            usage = assistant_message.get("usage") or {}
            prompt_tokens = int(usage.get("prompt_tokens") or 0)
            completion_tokens = int(usage.get("completion_tokens") or 0)
            current_prompt_tokens += prompt_tokens
            current_completion_tokens += completion_tokens
            content = assistant_message.get("content") or ""
            tool_calls = assistant_message.get("tool_calls") or []

            stored_message = {"role": "assistant", "content": content}
            if tool_calls:
                stored_message["tool_calls"] = tool_calls
            self.messages.append(stored_message)

            if (not self.stream) and content.strip():
                fputs(SYS_STDOUT_BUFFER, content)
                fputs(SYS_STDOUT_BUFFER, "\n")

            if not tool_calls:
                self.last_prompt_tokens = current_prompt_tokens
                self.last_completion_tokens = current_completion_tokens
                self.total_prompt_tokens += current_prompt_tokens
                self.total_completion_tokens += current_completion_tokens
                fputs(
                    SYS_STDOUT_BUFFER,
                    format_token_summary(
                        self.last_prompt_tokens,
                        self.last_completion_tokens,
                        self.total_prompt_tokens,
                        self.total_completion_tokens,
                    ),
                )
                fputs(SYS_STDOUT_BUFFER, "\n")
                return

            for call in tool_calls:
                call_id = call.get("id") or ""
                function_data = call.get("function") or {}
                name = function_data.get("name")
                raw_args = function_data.get("arguments") or "{}"

                fputs(SYS_STDOUT_BUFFER, "\n[tool %s]\n" % name)
                try:
                    parsed_args = json.loads(raw_args)
                except Exception as exc:
                    tool_result = (
                        "Tool argument JSON parse error: %s\nRaw arguments: %s"
                        % (exc, raw_args)
                    )
                else:
                    tool_result = run_tool(name, parsed_args, self.cwd)

                fputs(
                    SYS_STDOUT_BUFFER,
                    format_tool_result_for_display(name, tool_result),
                )
                fputs(SYS_STDOUT_BUFFER, "\n")
                self.messages.append(
                    {"role": "tool", "tool_call_id": call_id, "content": tool_result}
                )
                fputs(SYS_STDOUT_BUFFER, "\n")

            step += 1

        raise RuntimeError("Agent exceeded max tool-call steps")


def get_multiline_input(initial_lines=None):
    # type: (object) -> Text
    if initial_lines is None:
        initial_lines = []
    return "".join(get_unicode_multiline_input_with_editor(initial_lines, None))


def print_banner(conversation, functions):
    # type: (AgentConversation, list) -> Text
    banner_lines = [
        "Welcome to chatrepl. Use one of the following commands to interact with %s:"
        % conversation.model,
        "",
    ]

    if conversation.context_files_enabled:
        if conversation.context_file_paths:
            banner_lines.append("Loaded context files:")
            for path in conversation.context_file_paths:
                banner_lines.append("- %s" % path)
        else:
            banner_lines.append("Loaded context files: none")
        banner_lines.append("")
    else:
        banner_lines.extend(["Context files disabled.", ""])

    text_doc = TextDoc()
    for function in functions:
        banner_lines.append(text_doc.document(function))
    return "\n".join(banner_lines)


def build_namespace(conversation):
    # type: (AgentConversation) -> dict
    def send(text=""):
        # type: (Text) -> None
        """Send a message and let the agent complete tool calls."""
        conversation.send(text)

    def append(text):
        # type: (Text) -> None
        """Append text to the conversation as a user message without sending it."""
        conversation.append_user_message(text)

    def multiline():
        # type: () -> None
        """Append multiline input via your editor without sending it."""
        conversation.append_user_message(get_multiline_input())

    def txt(txt_file_path):
        # type: (Text) -> None
        """Append a UTF-8 text file as a user message without sending it."""
        conversation.append_user_message(read_text_file(txt_file_path))

    def load(json_file_path):
        # type: (Text) -> None
        """Load a conversation from JSON."""
        conversation.load_from_json_file(json_file_path)

    def save(json_file_path):
        # type: (Text) -> None
        """Save the current conversation to JSON."""
        conversation.save_to_json_file(json_file_path)

    def export(md_file_path):
        # type: (Text) -> None
        """Export the current conversation to Markdown."""
        write_text_file(md_file_path, conversation.export_to_markdown())

    def correct():
        # type: () -> bool
        """Edit the last assistant response in your editor."""
        index = len(conversation.messages) - 1
        while index >= 0:
            message = conversation.messages[index]
            if message.get("role") == "assistant":
                corrected = get_multiline_input(
                    [extract_text_content(message.get("content"))]
                )
                return conversation.correct_last_response(corrected)
            index -= 1
        return False

    def show():
        # type: () -> None
        """Print the current conversation messages."""
        conversation.show()

    def reset():
        # type: () -> None
        """Reset the conversation to the system prompt only."""
        conversation.reset()

    def cwd(path=None):
        # type: (object) -> Text
        """Show or change the tool working directory."""
        if path is not None:
            conversation.cwd = resolve_path(path, os.getcwd())
            conversation.refresh_system_prompt(update_messages=True)
        return conversation.cwd

    def model(name=None):
        # type: (object) -> Text
        """Show or change the model ID."""
        if name is not None:
            conversation.model = name
        return conversation.model

    def base_url(url=None):
        # type: (object) -> Text
        """Show or change the base URL."""
        if url is not None:
            conversation.base_url = url
        return conversation.base_url

    def stream(enabled=None):
        # type: (object) -> bool
        """Show or change whether assistant responses stream."""
        if enabled is not None:
            conversation.set_stream(enabled)
        return conversation.stream

    def context_files(enabled=None):
        # type: (object) -> bool
        """Show or change whether AGENTS.md and CLAUDE.md context files are loaded."""
        if enabled is not None:
            conversation.context_files_enabled = bool(enabled)
            conversation.refresh_system_prompt(update_messages=True)
        return conversation.context_files_enabled

    def context_paths():
        # type: () -> list
        """Return the currently discovered AGENTS.md and CLAUDE.md files."""
        return list(conversation.context_file_paths)

    functions = [
        send,
        append,
        multiline,
        txt,
        load,
        save,
        export,
        correct,
        show,
        reset,
        cwd,
        model,
        base_url,
        stream,
        context_files,
        context_paths,
    ]
    namespace = {}
    for function in functions:
        namespace[function.__name__] = function
    namespace["conversation"] = conversation
    namespace["TOOLS"] = TOOLS
    namespace["SYSTEM_PROMPT"] = SYSTEM_PROMPT
    namespace["help_text"] = print_banner(conversation, functions)
    return namespace


def main():
    # type: () -> int
    parser = argparse.ArgumentParser(
        description="Single-file minimal pi-like coding agent with a chatrepl-style interface"
    )
    parser.add_argument(
        "-k",
        "--api-key",
        required=True,
        help="API key for the OpenAI-compatible endpoint",
    )
    parser.add_argument(
        "-u",
        "--base-url",
        required=True,
        help="Base API URL or full chat completions endpoint, e.g. http://localhost:11434/v1",
    )
    parser.add_argument("-m", "--model", required=True, help="Model ID")
    parser.add_argument(
        "-l",
        "--load",
        metavar="JSON_FILE_PATH",
        help="Load a conversation from JSON_FILE_PATH",
    )
    parser.add_argument(
        "--no-stream",
        action="store_true",
        help="Disable streaming and use regular responses",
    )
    parser.add_argument(
        "--no-context-files",
        action="store_true",
        help="Disable AGENTS.md and CLAUDE.md discovery",
    )
    parser.add_argument("prompt", nargs="*", help="Optional initial prompt")
    args = parser.parse_args()

    api_key = stdin_str_to_text(args.api_key)
    base_url = stdin_str_to_text(args.base_url)
    model = stdin_str_to_text(args.model)
    load = args.load
    no_stream = args.no_stream
    no_context_files = args.no_context_files
    prompt = map(
        lambda component: stdin_str_to_text(component), args.prompt
    )

    conversation = AgentConversation(
        api_key=api_key,
        base_url=base_url,
        model=model,
        cwd=os.getcwd(),
        stream=not no_stream,
        context_files_enabled=not no_context_files,
    )

    if load:
        conversation.load_from_json_file(load)

    initial_prompt = " ".join(prompt).strip()

    if not sys.stdin.isatty() and not initial_prompt:
        conversation.send(stdin_str_to_text(sys.stdin.read()))
        return 0

    if initial_prompt:
        conversation.send(initial_prompt)
        return 0

    is_interactive = sys.stdin.isatty()
    readline_module = None
    history_path = None

    if is_interactive:
        try:
            import readline as readline_module  # noqa: F401
        except ImportError:
            readline_module = None

    if readline_module is not None:
        history_path = os.path.join(os.path.expanduser("~"), ".chatrepl_history")
        try:
            readline_module.read_history_file(history_path)
        except Exception:
            pass

    namespace = build_namespace(conversation)
    interactive_console = InteractiveConsole(namespace)
    interactive_console.interact(namespace["help_text"])

    if readline_module is not None and history_path is not None:
        try:
            readline_module.write_history_file(history_path)
        except Exception:
            pass

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
