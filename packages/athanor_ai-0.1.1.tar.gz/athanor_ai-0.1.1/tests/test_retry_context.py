"""Tests for Environment._build_retry_context — ensures feedback is safe and useful."""

from athanor.types import ScoreResult
from athanor.env import Environment


def _make_env():
    """Create an Environment without actually discovering tasks from Docker."""
    env = object.__new__(Environment)
    env.env_name = "test"
    env.image = "test"
    env.task = "task_a"
    env.timeout = 30
    env.tasks = ["task_a"]
    env._workdir = None
    env._task_configs = {}
    return env


class TestBuildRetryContext:
    """_build_retry_context returns a string with scoring feedback."""

    def test_basic_score(self):
        env = _make_env()
        prev = ScoreResult(score=0.42)
        ctx = env._build_retry_context(prev)
        assert isinstance(ctx, str)
        assert "0.42" in ctx

    def test_includes_checks(self):
        env = _make_env()
        prev = ScoreResult(
            score=0.6,
            metadata={"checks_passed": 5, "checks_total": 8},
        )
        ctx = env._build_retry_context(prev)
        assert "5/8" in ctx

    def test_includes_lean_status(self):
        env = _make_env()
        prev = ScoreResult(
            score=0.3,
            metadata={"lean_status": "error", "lean_error": "unknown id `Real`"},
        )
        ctx = env._build_retry_context(prev)
        assert "lean_status: error" in ctx
        assert "unknown id" in ctx

    def test_includes_student_files_truncated(self):
        env = _make_env()
        long_code = "x = 1\n" * 2000  # ~12000 chars
        prev = ScoreResult(score=0.1, student_files={"sol.py": long_code})
        ctx = env._build_retry_context(prev)
        # Should be truncated to 8000 chars per file
        assert len(ctx) < len(long_code)
        assert "sol.py" in ctx

    def test_no_reference_values_leaked(self):
        """Retry context must not contain reference answers or scoring internals."""
        env = _make_env()
        prev = ScoreResult(
            score=0.5,
            metadata={
                "checks_passed": 3,
                "checks_total": 5,
                "lean_status": "ok",
                "reference_values": {"spike_count": 4},
                "sigmoid_center": 0.55,
            },
        )
        ctx = env._build_retry_context(prev)
        # Reference values and sigmoid params must not appear
        assert "reference_values" not in ctx
        assert "spike_count" not in ctx
        assert "sigmoid_center" not in ctx

    def test_includes_scoring_error(self):
        env = _make_env()
        prev = ScoreResult(score=0.0, metadata={"error": "Container timeout"})
        ctx = env._build_retry_context(prev)
        assert "Container timeout" in ctx

    def test_header_line(self):
        env = _make_env()
        prev = ScoreResult(score=0.0)
        ctx = env._build_retry_context(prev)
        assert "PREVIOUS ATTEMPT" in ctx
