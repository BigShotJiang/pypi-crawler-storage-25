"""Tests for athanor.types — ScoreResult and TaskConfig."""

from athanor.types import ScoreResult, TaskConfig


class TestScoreResult:
    """ScoreResult dataclass properties."""

    def test_default_score(self):
        r = ScoreResult(score=0.75)
        assert r.score == 0.75
        assert r.metadata == {}
        assert r.student_files == {}

    def test_lean_status_present(self):
        r = ScoreResult(score=0.5, metadata={"lean_status": "ok"})
        assert r.lean_status == "ok"

    def test_lean_status_absent(self):
        r = ScoreResult(score=0.5)
        assert r.lean_status is None

    def test_checks_passed_present(self):
        r = ScoreResult(score=0.8, metadata={"checks_passed": 7, "checks_total": 10})
        assert r.checks_passed == 7
        assert r.checks_total == 10

    def test_checks_passed_default(self):
        r = ScoreResult(score=0.0)
        assert r.checks_passed == 0
        assert r.checks_total == 0

    def test_student_files(self):
        files = {"solution.py": "print('hello')"}
        r = ScoreResult(score=1.0, student_files=files)
        assert r.student_files == files

    def test_metadata_does_not_share_between_instances(self):
        a = ScoreResult(score=0.0)
        b = ScoreResult(score=0.0)
        a.metadata["key"] = "val"
        assert "key" not in b.metadata

    def test_student_files_does_not_share_between_instances(self):
        a = ScoreResult(score=0.0)
        b = ScoreResult(score=0.0)
        a.student_files["f.py"] = "code"
        assert "f.py" not in b.student_files


class TestTaskConfig:
    """TaskConfig dataclass fields."""

    def test_required_fields(self):
        tc = TaskConfig(
            task_id="hodgkin_huxley",
            description="Implement HH model",
            difficulty="hard",
            solution_file="hh.py",
        )
        assert tc.task_id == "hodgkin_huxley"
        assert tc.description == "Implement HH model"
        assert tc.difficulty == "hard"
        assert tc.solution_file == "hh.py"
        assert tc.lean_file is None

    def test_lean_file(self):
        tc = TaskConfig(
            task_id="hh_with_proof",
            description="HH with proof",
            difficulty="hard",
            solution_file="hh.py",
            lean_file="hh_proof.lean",
        )
        assert tc.lean_file == "hh_proof.lean"
