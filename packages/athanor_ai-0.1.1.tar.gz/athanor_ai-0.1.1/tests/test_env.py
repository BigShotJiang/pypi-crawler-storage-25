"""Tests for athanor.env — Environment init and task discovery."""

from unittest.mock import patch, MagicMock
from pathlib import Path

from athanor.env import Environment
from athanor.types import ScoreResult, TaskConfig


class TestEnvironmentInit:
    """Environment construction and defaults."""

    @patch("athanor.env.Environment._discover_tasks", return_value=[])
    def test_init_defaults(self, mock_discover):
        env = Environment("my-env")
        assert env.env_name == "my-env"
        assert env.image == "my-env"
        assert env.task is None
        assert env.timeout == 300
        assert env.tasks == []

    @patch("athanor.env.Environment._discover_tasks", return_value=[])
    def test_init_custom_image(self, mock_discover):
        env = Environment("my-env", image="custom:latest", timeout=60)
        assert env.image == "custom:latest"
        assert env.timeout == 60

    @patch("athanor.env.Environment._discover_tasks", return_value=[])
    def test_init_with_task(self, mock_discover):
        env = Environment("my-env", task="task_a")
        assert env.task == "task_a"

    @patch("athanor.env.Environment._discover_tasks", return_value=[])
    def test_repr(self, mock_discover):
        env = Environment("neuroscience", task="hodgkin_huxley")
        assert "neuroscience" in repr(env)
        assert "hodgkin_huxley" in repr(env)


class TestTaskDiscovery:
    """Task discovery via mocked Docker calls."""

    @patch("athanor.env._find_docker", return_value="/usr/bin/docker")
    @patch("subprocess.run")
    def test_discover_tasks_parses_filenames(self, mock_run, mock_docker):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="/root_data/eval/configs/task_a.json\n/root_data/eval/configs/task_b.json\n",
        )
        env = Environment("test-env")
        assert env.tasks == ["task_a", "task_b"]

    @patch("athanor.env._find_docker", return_value="/usr/bin/docker")
    @patch("subprocess.run")
    def test_discover_tasks_empty_on_failure(self, mock_run, mock_docker):
        mock_run.return_value = MagicMock(returncode=1, stdout="")
        env = Environment("test-env")
        assert env.tasks == []

    @patch("athanor.env._find_docker", return_value="/usr/bin/docker")
    @patch("subprocess.run", side_effect=FileNotFoundError)
    def test_discover_tasks_handles_missing_docker(self, mock_run, mock_docker):
        env = Environment("test-env")
        assert env.tasks == []


class TestTaskIds:
    """task_ids property."""

    @patch("athanor.env.Environment._discover_tasks", return_value=["a", "b", "c"])
    def test_task_ids(self, mock_discover):
        env = Environment("test-env")
        assert env.task_ids == ["a", "b", "c"]


class TestGetTaskConfig:
    """get_task_config returns TaskConfig from cached container data."""

    @patch("athanor.env.Environment._discover_tasks", return_value=["t1"])
    def test_get_task_config(self, mock_discover):
        env = Environment("test-env")
        env._task_configs["t1"] = {
            "description": "Implement a thing",
            "difficulty": "medium",
            "solution_file": "solution.py",
            "lean_file": "proof.lean",
        }
        tc = env.get_task_config("t1")
        assert isinstance(tc, TaskConfig)
        assert tc.task_id == "t1"
        assert tc.description == "Implement a thing"
        assert tc.difficulty == "medium"
        assert tc.solution_file == "solution.py"
        assert tc.lean_file == "proof.lean"

    @patch("athanor.env.Environment._discover_tasks", return_value=["t1"])
    def test_get_task_config_no_lean(self, mock_discover):
        env = Environment("test-env")
        env._task_configs["t1"] = {
            "description": "Simple task",
            "difficulty": "easy",
            "kernel_file": "kernel.py",
        }
        tc = env.get_task_config("t1")
        assert tc.solution_file == "kernel.py"
        assert tc.lean_file is None
