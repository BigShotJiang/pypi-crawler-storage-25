"""Gym-like environment interface for Athanor scoring containers."""

from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from pathlib import Path

from athanor.scoring import score as _score_container, _find_docker
from athanor.types import ScoreResult, TaskConfig


class Environment:
    """OpenAI Gym-compatible interface to an Athanor scoring container.

    Usage::

        env = Environment("neuron-nki-kernels", task="batched_matmul_accumulate")
        prompt = env.reset()
        result = env.score({"batched_matmul_accumulate_kernel.py": my_code})
        print(result.score)
    """

    def __init__(
        self,
        env_name: str,
        task: str | None = None,
        *,
        image: str | None = None,
        timeout: int = 300,
    ):
        self.env_name = env_name
        self.image = image or env_name
        self.task = task
        self.timeout = timeout
        self.tasks: list[str] = self._discover_tasks()
        self._workdir: Path | None = None
        self._task_configs: dict[str, dict] = {}

    def _discover_tasks(self) -> list[str]:
        """List available task IDs by reading config filenames from the container."""
        docker_bin = _find_docker()
        cmd = [
            docker_bin, "run", "--rm", "--user", "root",
            self.image, "bash", "-c",
            "ls /root_data/eval/configs/*.json 2>/dev/null",
        ]
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=30,
            )
            if result.returncode != 0:
                return []
            lines = result.stdout.strip().splitlines()
            return [Path(line).stem for line in lines if line.strip()]
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return []

    def _load_task_config(self, task_id: str) -> dict:
        """Read a task's config JSON from the container."""
        if task_id in self._task_configs:
            return self._task_configs[task_id]

        docker_bin = _find_docker()
        cmd = [
            docker_bin, "run", "--rm", "--user", "root",
            self.image, "bash", "-c",
            f"cat /root_data/eval/configs/{task_id}.json",
        ]
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0 and result.stdout.strip():
                config = json.loads(result.stdout.strip())
                self._task_configs[task_id] = config
                return config
        except (subprocess.TimeoutExpired, json.JSONDecodeError):
            pass
        return {}

    def _extract_student_stubs(self, task_id: str) -> dict[str, str]:
        """Extract student stub files from the container for a given task."""
        config = self._load_task_config(task_id)
        stub_file = config.get("kernel_file") or config.get("solution_file", "")
        if not stub_file:
            return {}

        docker_bin = _find_docker()
        cmd = [
            docker_bin, "run", "--rm",
            self.image, "bash", "-c",
            f"cat /workdir/data/{stub_file} 2>/dev/null",
        ]
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0 and result.stdout:
                return {stub_file: result.stdout}
        except subprocess.TimeoutExpired:
            pass
        return {}

    def reset(self, task: str | None = None) -> dict:
        """Set up a fresh working directory with student stubs.

        Args:
            task: Task ID to reset to. Uses self.task if not provided.

        Returns:
            Dict with keys:
                - task_id: the active task
                - description: task prompt/description
                - files: dict of filename -> stub content
                - difficulty: task difficulty level
                - lean_file: Lean proof file if applicable
        """
        if task is not None:
            self.task = task

        if self.task is None:
            if self.tasks:
                self.task = self.tasks[0]
            else:
                raise ValueError(
                    "No task specified and no tasks discovered. "
                    "Pass task= to reset() or the constructor."
                )

        # Clean up previous workdir
        if self._workdir and self._workdir.exists():
            shutil.rmtree(self._workdir, ignore_errors=True)

        # Create fresh tempdir
        self._workdir = Path(tempfile.mkdtemp(prefix=f"athanor_{self.task}_"))
        data_dir = self._workdir / "data"
        data_dir.mkdir()

        # Extract stub files
        stubs = self._extract_student_stubs(self.task)
        for filename, content in stubs.items():
            (data_dir / filename).write_text(content)

        # Load config for the prompt
        config = self._load_task_config(self.task)

        return {
            "task_id": self.task,
            "description": config.get("description", ""),
            "files": stubs,
            "difficulty": config.get("difficulty", ""),
            "lean_file": config.get("lean_file"),
        }

    def score(self, files: dict[str, str]) -> ScoreResult:
        """Write files to the working directory and run scoring.

        Args:
            files: Dict of filename -> file content to write before scoring.

        Returns:
            ScoreResult with score and metadata.
        """
        if self._workdir is None or self.task is None:
            raise RuntimeError("Call reset() before score().")

        data_dir = self._workdir / "data"
        data_dir.mkdir(exist_ok=True)

        # Write student files
        for filename, content in files.items():
            filepath = data_dir / filename
            filepath.parent.mkdir(parents=True, exist_ok=True)
            filepath.write_text(content)

        return _score_container(
            image=self.image,
            task_id=self.task,
            workdir=self._workdir,
            timeout=self.timeout,
        )

    def score_file(self, path: str) -> ScoreResult:
        """Score a single file (convenience for simple tasks).

        Reads the file at the given path and submits it under its basename.

        Args:
            path: Path to the file to score.

        Returns:
            ScoreResult with score and metadata.
        """
        p = Path(path)
        content = p.read_text()
        return self.score({p.name: content})

    @property
    def task_ids(self) -> list[str]:
        """List of available task IDs in this environment."""
        return self.tasks

    def get_task_config(self, task_id: str) -> TaskConfig:
        """Load full task configuration as a TaskConfig dataclass."""
        config = self._load_task_config(task_id)
        return TaskConfig(
            task_id=task_id,
            description=config.get("description", ""),
            difficulty=config.get("difficulty", ""),
            solution_file=config.get("kernel_file") or config.get("solution_file", ""),
            lean_file=config.get("lean_file"),
        )

    def run(
        self,
        model: str,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
        max_retries: int = 0,
        target_score: float = 0.95,
        platform_url: str | None = None,
        sync_token: str | None = None,
        on_score: callable | None = None,
    ) -> list[ScoreResult]:
        """Run a full evaluation loop: agent attempts the task, scores, optionally retries.

        This is the high-level "Solve" interface. The agent (specified by model)
        reads the task, writes code, and gets scored. If max_retries > 0 and
        score < target_score, the scoring feedback is fed back and the agent
        tries again.

        Args:
            model: LiteLLM model string (e.g., "anthropic/claude-sonnet-4-6")
            api_key: API key for the model provider
            api_base: Optional API base URL override
            max_retries: Number of retry-with-feedback attempts (0 = single attempt)
            target_score: Stop retrying once this score is reached
            platform_url: Athanor platform URL for trace streaming (optional)
            sync_token: Sync token for trace streaming (optional)
            on_score: Callback called with ScoreResult after each attempt

        Returns:
            List of ScoreResult for each attempt (1 + retries)
        """
        import os

        # Find evaluate.py — shipped in the tarball alongside the container
        eval_script = self._find_evaluate_script()
        if not eval_script:
            raise FileNotFoundError(
                "evaluate.py not found. Ensure the environment tarball is extracted "
                "in the current directory or a parent directory."
            )

        results: list[ScoreResult] = []
        task = self.task or (self.tasks[0] if self.tasks else None)
        if not task:
            raise ValueError("No task specified")

        env_vars = dict(os.environ)
        if api_key:
            # Detect provider from model string
            if "anthropic" in model or "claude" in model:
                env_vars["ANTHROPIC_API_KEY"] = api_key
            elif "gemini" in model:
                env_vars["GOOGLE_API_KEY"] = api_key
            else:
                env_vars["OPENAI_API_KEY"] = api_key
        if api_base:
            env_vars["OPENAI_API_BASE"] = api_base
        if platform_url:
            env_vars["ATHANOR_PLATFORM_URL"] = platform_url
        if sync_token:
            env_vars["ATHANOR_SYNC_TOKEN"] = sync_token

        for attempt in range(1 + max_retries):
            # Build evaluate.py command
            output_file = self._workdir / f"result_attempt{attempt}.json" if self._workdir else Path(f"/tmp/athanor_result_{attempt}.json")
            cmd = [
                "python3", str(eval_script), ".",
                "--tasks", task,
                "--model", model,
                "-o", str(output_file),
                "--max-workers", "1",
            ]

            # For retries, add previous scoring feedback as context
            if attempt > 0 and results:
                prev = results[-1]
                context_file = self._workdir / "student_data" / "RETRY_CONTEXT.md" if self._workdir else Path(f"/tmp/retry_context_{attempt}.md")
                context_file.parent.mkdir(parents=True, exist_ok=True)
                context_file.write_text(self._build_retry_context(prev))

            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=3600,
                env=env_vars,
                cwd=str(eval_script.parent.parent),
            )

            # Parse result
            try:
                data = json.loads(output_file.read_text())
                for r in data.get("results", []):
                    if r.get("task") == task:
                        result = ScoreResult(
                            score=r.get("score", 0),
                            metadata=r.get("scoring_metadata", {}),
                            student_files=r.get("student_files", {}),
                        )
                        results.append(result)
                        if on_score:
                            on_score(result)
                        break
            except (json.JSONDecodeError, FileNotFoundError):
                results.append(ScoreResult(score=0, metadata={"error": "Failed to parse results"}))

            # Clean up retry context
            if attempt > 0:
                context_file = self._workdir / "student_data" / "RETRY_CONTEXT.md" if self._workdir else Path(f"/tmp/retry_context_{attempt}.md")
                context_file.unlink(missing_ok=True)

            # Check if we've reached the target
            if results and results[-1].score >= target_score:
                break

        return results

    def _find_evaluate_script(self) -> Path | None:
        """Search for evaluate.py in common locations."""
        candidates = [
            Path("scripts/evaluate.py"),
            Path("evaluate.py"),
            Path(f"../{self.env_name}/scripts/evaluate.py"),
        ]
        for c in candidates:
            if c.exists():
                return c.resolve()
        return None

    def _build_retry_context(self, prev: ScoreResult) -> str:
        """Build minimal retry context from previous attempt."""
        lines = ["PREVIOUS ATTEMPT — VERIFIER OUTPUT (deterministic):\n"]
        lines.append(f"score: {prev.score}")
        meta = prev.metadata
        if meta.get("checks_passed") is not None:
            lines.append(f"property_tests: {meta['checks_passed']}/{meta.get('checks_total', '?')}")
        if meta.get("lean_status"):
            lines.append(f"lean_status: {meta['lean_status']}")
            lines.append(f"lean_multiplier: {meta.get('lean_multiplier', 'n/a')}")
        if meta.get("lean_error"):
            lines.append(f"lean_error: {meta['lean_error']}")
        if meta.get("error"):
            lines.append(f"scoring_error: {meta['error']}")
        for name, content in (prev.student_files or {}).items():
            lines.append(f"\n--- {name} ---")
            lines.append(content[:8000])
        return "\n".join(lines)

    def reward_fn(self, completions: list[str], filename: str = "solution.py") -> list[float]:
        """TRL-compatible reward function.

        Args:
            completions: List of model completions (code strings)
            filename: Filename to submit each completion as

        Returns:
            List of float scores
        """
        scores = []
        for code in completions:
            self.reset(self.task)
            result = self.score({filename: code})
            scores.append(result.score)
        return scores

    def cleanup(self):
        """Remove the temporary working directory."""
        if self._workdir and self._workdir.exists():
            shutil.rmtree(self._workdir, ignore_errors=True)
            self._workdir = None

    def __del__(self):
        self.cleanup()

    def __repr__(self) -> str:
        return f"Environment({self.env_name!r}, task={self.task!r})"
