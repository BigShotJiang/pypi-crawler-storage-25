"""Docker container scoring wrapper.

Runs the environment's scoring container against student files and returns
a ScoreResult. The container is sandboxed: no network, capped memory/PIDs,
all capabilities dropped.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

from athanor.types import ScoreResult


def _find_docker() -> str:
    """Locate docker or podman binary."""
    for name in ("docker", "podman"):
        path = shutil.which(name)
        if path:
            return path
    raise FileNotFoundError(
        "Neither docker nor podman found on PATH. "
        "Install Docker: https://docs.docker.com/get-docker/"
    )


def score(
    image: str,
    task_id: str,
    workdir: Path,
    *,
    timeout: int = 300,
    memory: str = "4g",
    pids_limit: int = 256,
) -> ScoreResult:
    """Run scoring container and return result.

    Args:
        image: Docker image name (e.g. 'neuron-nki-kernels').
        task_id: Task identifier matching a config JSON in the container.
        workdir: Local directory containing 'data/' (student files) and
                 optionally 'shared/' (read-only reference data).
        timeout: Container execution timeout in seconds.
        memory: Container memory limit.
        pids_limit: Container PID limit.

    Returns:
        ScoreResult with score and metadata from the container.
    """
    docker_bin = _find_docker()

    data_dir = workdir / "data"
    shared_dir = workdir / "shared"

    cmd = [
        docker_bin, "run", "--rm", "--user", "root",
        "--network=none",
        f"--memory={memory}",
        f"--pids-limit={pids_limit}",
        "--cap-drop=ALL",
        "-v", f"{data_dir}:/workdir/data",
    ]

    # Mount shared data read-only if it exists
    if shared_dir.is_dir():
        cmd += ["-v", f"{shared_dir}:/workdir/shared:ro"]

    cmd += [
        image, "bash", "-c",
        (
            f"/root/.venv/bin/python /root_data/eval/scoring.py "
            f"/root_data/eval/configs/{task_id}.json /tmp/score.json "
            f">/dev/null 2>&1; cat /tmp/score.json"
        ),
    ]

    result = subprocess.run(
        cmd, capture_output=True, text=True, timeout=timeout,
    )

    stdout = result.stdout.strip()
    if not stdout:
        return ScoreResult(
            score=0.0,
            metadata={"error": f"Container produced no output (exit {result.returncode})"},
        )

    try:
        data = json.loads(stdout)
    except json.JSONDecodeError:
        return ScoreResult(
            score=0.0,
            metadata={"error": f"Invalid JSON from container: {stdout[:200]}"},
        )

    return ScoreResult(
        score=data.get("score", 0.0),
        metadata=data.get("metadata", {}),
    )
