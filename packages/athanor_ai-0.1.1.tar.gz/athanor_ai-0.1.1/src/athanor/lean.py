"""Lean 4 proof verification utilities.

Helpers for domain engineers who want verifiable proofs on their code
without needing to build full RL environments.

Usage:
    from athanor.lean import verify_proof, check_sorry, score_proof

    # Verify a Lean 4 proof compiles
    result = verify_proof("theorem add_comm (a b : Nat) : a + b = b + a := by omega")

    # Check for sorry (incomplete proof markers)
    has_sorry, count = check_sorry(proof_code)

    # Score a proof: 1.0 (full), 0.35 (sorry), 0.25 (broken), 0.0 (banned)
    score = score_proof(proof_code)
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ProofResult:
    """Result of verifying a Lean 4 proof."""
    compiles: bool
    has_sorry: bool = False
    sorry_count: int = 0
    score: float = 0.0
    errors: list[str] = field(default_factory=list)
    banned: str | None = None

    @property
    def status(self) -> str:
        if self.banned:
            return "banned"
        if self.compiles and not self.has_sorry:
            return "full_proof"
        if self.compiles and self.has_sorry:
            return "partial_proof"
        return "compile_error"


# Banned constructs that bypass proof obligations
BANNED_PATTERNS = [
    (r"^\s*(?:private\s+|protected\s+)?axiom\s", "axiom declarations bypass proof"),
    (r"^import\s+Mathlib\b", "Mathlib imports can bring uncontrolled axioms"),
    (r"^import\s+Lean\b", "Lean meta-programming imports"),
    (r"unsafe\s+def", "unsafe definitions bypass type checking"),
    (r"@\[init\]", "init attributes execute at import time"),
]

# Proof multipliers matching the three-layer scoring
MULTIPLIERS = {
    "full_proof": 1.0,
    "partial_proof": 0.35,
    "compile_error": 0.25,
    "banned": 0.0,
    "no_proof": 0.15,
}


def check_banned(code: str) -> str | None:
    """Check for banned constructs. Returns the reason or None."""
    for pattern, reason in BANNED_PATTERNS:
        if re.search(pattern, code, re.MULTILINE):
            return reason
    return None


def check_sorry(code: str) -> tuple[bool, int]:
    """Check for sorry in proof code.

    Returns:
        (has_sorry, count) — whether sorry appears and how many times.
    """
    # Match 'sorry' as a standalone tactic, not inside strings or comments
    matches = re.findall(r'\bsorry\b', code)
    return (len(matches) > 0, len(matches))


def verify_proof(
    code: str,
    *,
    timeout: int = 120,
    lean_bin: str | None = None,
) -> ProofResult:
    """Verify a Lean 4 proof compiles.

    Writes the code to a temp file and runs the Lean compiler.
    Requires Lean 4 to be installed (or available in a Docker container).

    Args:
        code: Lean 4 source code
        timeout: Max seconds to wait for compilation
        lean_bin: Path to lean binary (auto-detected if None)

    Returns:
        ProofResult with compilation status, sorry detection, and score.
    """
    # Check banned constructs first
    banned = check_banned(code)
    if banned:
        return ProofResult(
            compiles=False,
            banned=banned,
            score=MULTIPLIERS["banned"],
            errors=[f"Banned construct: {banned}"],
        )

    # Check sorry
    has_sorry, sorry_count = check_sorry(code)

    # Find lean binary
    if lean_bin is None:
        lean_bin = shutil.which("lean")
    if lean_bin is None:
        # Try inside a Docker container
        docker_bin = shutil.which("docker") or shutil.which("podman")
        if docker_bin:
            return _verify_in_container(code, timeout, docker_bin, has_sorry, sorry_count)
        return ProofResult(
            compiles=False,
            has_sorry=has_sorry,
            sorry_count=sorry_count,
            score=0.0,
            errors=["Lean 4 not found. Install Lean or use Docker."],
        )

    # Write to temp file and compile
    with tempfile.NamedTemporaryFile(suffix=".lean", mode="w", delete=False) as f:
        f.write(code)
        f.flush()
        lean_file = f.name

    try:
        result = subprocess.run(
            [lean_bin, lean_file],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        compiles = result.returncode == 0
        errors = []
        if not compiles:
            err_text = (result.stderr or result.stdout)[:500]
            errors = [line for line in err_text.split("\n") if line.strip()]

        # Also check compiler output for sorry warnings
        if "sorry" in (result.stdout + result.stderr).lower():
            has_sorry = True

        status = "full_proof" if compiles and not has_sorry else \
                 "partial_proof" if compiles else "compile_error"

        return ProofResult(
            compiles=compiles,
            has_sorry=has_sorry,
            sorry_count=sorry_count,
            score=MULTIPLIERS[status],
            errors=errors,
        )
    except subprocess.TimeoutExpired:
        return ProofResult(
            compiles=False,
            has_sorry=has_sorry,
            sorry_count=sorry_count,
            score=MULTIPLIERS["compile_error"],
            errors=[f"Compilation timed out ({timeout}s)"],
        )
    finally:
        Path(lean_file).unlink(missing_ok=True)


def _verify_in_container(
    code: str,
    timeout: int,
    docker_bin: str,
    has_sorry: bool,
    sorry_count: int,
) -> ProofResult:
    """Verify proof using a Lean Docker container."""
    with tempfile.NamedTemporaryFile(suffix=".lean", mode="w", delete=False) as f:
        f.write(code)
        f.flush()
        lean_file = Path(f.name)

    try:
        result = subprocess.run(
            [
                docker_bin, "run", "--rm",
                "--network=none",
                "-v", f"{lean_file}:/tmp/proof.lean:ro",
                "ghcr.io/leanprover/lean4:latest",
                "lean", "/tmp/proof.lean",
            ],
            capture_output=True,
            text=True,
            timeout=timeout + 30,  # extra time for container startup
        )
        compiles = result.returncode == 0
        errors = []
        if not compiles:
            err_text = (result.stderr or result.stdout)[:500]
            errors = [line for line in err_text.split("\n") if line.strip()]

        if "sorry" in (result.stdout + result.stderr).lower():
            has_sorry = True

        status = "full_proof" if compiles and not has_sorry else \
                 "partial_proof" if compiles else "compile_error"

        return ProofResult(
            compiles=compiles,
            has_sorry=has_sorry,
            sorry_count=sorry_count,
            score=MULTIPLIERS[status],
            errors=errors,
        )
    except subprocess.TimeoutExpired:
        return ProofResult(
            compiles=False,
            has_sorry=has_sorry,
            sorry_count=sorry_count,
            score=MULTIPLIERS["compile_error"],
            errors=["Container verification timed out"],
        )
    finally:
        lean_file.unlink(missing_ok=True)


def score_proof(code: str, *, timeout: int = 120) -> float:
    """Convenience: verify and return just the score float.

    Returns:
        Float in [0, 1]. Full proof = 1.0, sorry = 0.35, broken = 0.25, banned = 0.0.
    """
    if not code or not code.strip():
        return MULTIPLIERS["no_proof"]
    return verify_proof(code, timeout=timeout).score
