"""Athanor AI — Lean 4 proof verification as RL training signal."""

from athanor.env import Environment
from athanor.types import ScoreResult, TaskConfig
from athanor.lean import verify_proof, check_sorry, score_proof, ProofResult

__version__ = "0.1.1"


def make(env_name: str, task: str | None = None, **kwargs) -> Environment:
    """Create an Athanor environment.

    Args:
        env_name: Environment image name (e.g. 'neuron-nki-kernels').
        task: Optional task ID to start with.
        **kwargs: Passed to Environment (image=, timeout=).

    Returns:
        Environment instance ready for reset()/score() calls.
    """
    return Environment(env_name, task=task, **kwargs)


__all__ = [
    "make", "Environment", "ScoreResult", "TaskConfig",
    "verify_proof", "check_sorry", "score_proof", "ProofResult",
    "__version__",
]
