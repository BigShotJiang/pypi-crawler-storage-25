"""Athanor SDK data types."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ScoreResult:
    """Result from scoring a student submission against a task."""

    score: float
    metadata: dict = field(default_factory=dict)
    student_files: dict = field(default_factory=dict)

    @property
    def lean_status(self) -> str | None:
        """Lean proof verification status, if applicable."""
        return self.metadata.get("lean_status")

    @property
    def checks_passed(self) -> int:
        """Number of correctness checks passed."""
        return self.metadata.get("checks_passed", 0)

    @property
    def checks_total(self) -> int:
        """Total number of correctness checks."""
        return self.metadata.get("checks_total", 0)


@dataclass
class TaskConfig:
    """Metadata for a single task within an environment."""

    task_id: str
    description: str
    difficulty: str
    solution_file: str
    lean_file: str | None = None
