from __future__ import annotations

import numpy as np

from simweave.continuous.solver import DynamicSystem
from simweave.units.si import Mass, SpringStiffness, Damping, Distance, Velocity


class QuarterCarModel(DynamicSystem):
    """Two degree-of-freedom quarter-car suspension model.

    State vector x = [z_s, z_s_dot, z_u, z_u_dot]
    where:
        z_s: sprung mass displacement
        z_u: unsprung mass displacement
    """

    STATE_UNITS = {
        "z_s": Distance,
        "z_s_dot": Velocity,
        "z_u": Distance,
        "z_u_dot": Velocity,        
    }

    def __init__(
        self,
        sprung_mass: float | Mass,
        unsprung_mass: float | Mass,
        suspension_stiffness: float | SpringStiffness,
        damping: float | Damping,
        tyre_stiffness: float | SpringStiffness,
        x0: tuple[float, float, float, float] = (0.0, 0.0, 0.0, 0.0),
        controller = None
    ):
        if self._val(sprung_mass) <= 0 or self._val(unsprung_mass) <= 0:
            raise ValueError("Masses must be positive")
        self.m_s = self._val(sprung_mass)
        self.m_u = self._val(unsprung_mass)
        self.k_s = self._val(suspension_stiffness)
        self.c_s = self._val(damping)
        self.k_t = self._val(tyre_stiffness)
        self._x0 = np.asarray([self._val(v) for v in x0], dtype=float)
        self.controller = controller

    def initial_state(self) -> np.ndarray:
        return self._x0.copy()

    def state_labels(self) -> tuple[str, str, str, str]:
        return ("z_s", "z_s_dot", "z_u", "z_u_dot")

    def derivatives(
        self, t: float, state: np.ndarray, inputs: float | int | None = None
    ) -> np.ndarray:
        z_s, z_s_dot, z_u, z_u_dot = state
        z_r = 0.0 if inputs is None else float(inputs)

        suspension_deflection = z_s - z_u
        suspension_velocity = z_s_dot - z_u_dot

        # calculate forces, whether passive or active
        F_passive = (
            -self.k_s * suspension_deflection
            - self.c_s * suspension_velocity
        )

        F_control = 0.0
        if self.controller is not None:
            F_control = self.controller.force(
                body_velocity=z_s_dot,
                wheel_velocity=z_u_dot,
            )

        F_s = F_passive + F_control

        z_s_ddot = F_s / self.m_s

        z_u_ddot = (
            -F_s
            - self.k_t * (z_u - z_r)
        ) / self.m_u

        return np.array([z_s_dot, z_s_ddot, z_u_dot, z_u_ddot], dtype=float)
