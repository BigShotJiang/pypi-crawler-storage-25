"""Graph-constrained scenario planning input preparation."""

from __future__ import annotations

from typing import Any

import networkx as nx

from omen.scenario.models import ScenarioPlanningRuleTemplateModel, StrategyActorPlanningQueryResultModel


def _normalize_similarity_scores(scores: dict[str, float], *, source: str) -> list[dict[str, Any]]:
    normalized_items: list[tuple[str, float]] = [
        (key, max(0.0, float(value)))
        for key, value in sorted(scores.items())
    ]
    total = sum(score for _, score in normalized_items)
    if total <= 0.0 and normalized_items:
        fallback = round(1.0 / len(normalized_items), 6)
        return [
            {
                "scenario_key": key,
                "score": fallback,
                "source": f"{source}_uniform_fallback",
            }
            for key, _ in normalized_items
        ]
    return [
        {
            "scenario_key": key,
            "score": round(score / total, 6),
            "source": source,
        }
        for key, score in normalized_items
    ]


def _build_template_default_similarity_scores(template: ScenarioPlanningRuleTemplateModel) -> list[dict[str, Any]]:
    default_scores = {
        slot.scenario_key: float(slot.default_prior)
        for slot in sorted(template.slot_policy, key=lambda item: item.scenario_key)
    }
    return _normalize_similarity_scores(default_scores, source="planning_template_default")


def _normalize_signal_query_payload(signal: dict[str, Any]) -> dict[str, Any]:
    name = str(signal.get("name") or "").strip()
    payload: dict[str, Any] = {
        "name": name,
        "kind": "signal",
    }

    signal_id = str(signal.get("signal_id") or name).strip()
    if signal_id:
        payload["signal_id"] = signal_id

    for field_name in ("domain", "direction", "mechanism_note", "impact_summary"):
        value = str(signal.get(field_name) or "").strip()
        if value:
            payload[field_name] = value

    strength = signal.get("strength")
    if strength is not None:
        payload["strength"] = float(strength)

    mapped_targets = [item for item in list(signal.get("mapped_targets") or []) if isinstance(item, dict)]
    if mapped_targets:
        payload["mapped_targets"] = mapped_targets

    cascade_rules = [item for item in list(signal.get("cascade_rules") or []) if isinstance(item, dict)]
    if cascade_rules:
        payload["cascade_rules"] = cascade_rules

    market_constraints = [item for item in list(signal.get("market_constraints") or []) if isinstance(item, dict)]
    if market_constraints:
        payload["market_constraints"] = market_constraints

    return payload


def build_planning_query(
    *,
    situation_artifact: dict[str, Any],
    actor_ref: str,
    template: ScenarioPlanningRuleTemplateModel,
) -> dict[str, Any]:
    situation_id = str(situation_artifact.get("id") or "unknown")
    graph = nx.DiGraph()
    graph.add_node(f"situation::{situation_id}", kind="situation")
    graph.add_node(f"actor::{actor_ref}", kind="actor")
    graph.add_edge(f"actor::{actor_ref}", f"situation::{situation_id}", relation="influences")

    space_inputs: list[dict[str, Any]] = []
    for signal in list(situation_artifact.get("signals") or []):
        if not isinstance(signal, dict):
            continue
        name = str(signal.get("name") or "").strip()
        if not name:
            continue
        signal_node = f"signal::{name}"
        graph.add_node(signal_node, kind="signal")
        graph.add_edge(signal_node, f"situation::{situation_id}", relation="describes")
        space_inputs.append(_normalize_signal_query_payload(signal))

    if not space_inputs:
        space_inputs.append({"name": "fallback_signal", "kind": "signal"})

    constraints = list((situation_artifact.get("context") or {}).get("hard_constraints") or [])
    constraint_signals = [{"name": str(item), "kind": "constraint"} for item in constraints if str(item).strip()]
    similarity_scores = _build_template_default_similarity_scores(template)

    query = StrategyActorPlanningQueryResultModel(
        situation_id=situation_id,
        actor_ref=actor_ref,
        space_inputs=space_inputs,
        constraint_signals=constraint_signals,
        similarity_scores=similarity_scores,
        query_version="planning_query_v1",
    )
    payload = query.model_dump()
    payload["graph_stats"] = {
        "nodes": graph.number_of_nodes(),
        "edges": graph.number_of_edges(),
    }
    return payload
