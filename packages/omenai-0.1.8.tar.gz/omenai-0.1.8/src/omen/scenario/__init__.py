"""Scenario loading and validation."""
