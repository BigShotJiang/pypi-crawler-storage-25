"""CLI entrypoint for Omen."""

from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path
from typing import Any

from omen.cli.case import handle_case_command, register_case_commands
from omen.cli.actor import (
    handle_analyze_command,
    handle_validate_command,
    register_analyze_commands,
    register_validate_commands,
)
from omen.cli.situation import (
    handle_scenario_command,
    handle_situation_analyze_command,
    register_situation_analyze_commands,
    register_scenario_command,
)
from omen.explain.precision_report import build_precision_report
from omen.explain.generator import generate_deterministic_explanation
from omen.explain.report import build_explanation_report
from omen.ingest.synthesizer.builders.assertion import build_assertions_from_candidates
from omen.ingest.synthesizer.builders.candidate import build_candidates_from_text
from omen.ingest.processor import build_source_inventory, extract_pdf_pages
from omen.ingest.synthesizer.services.scenario import (
    load_case_package_from_scenario,
    load_scenario_with_ontology,
)
from omen.ingest.synthesizer.builders.scenario import load_ontology_input
from omen.scenario.ingest_validator import validate_extracted_entity_candidates_or_raise
from omen.scenario.ingest_validator import validate_ontology_assertion_candidates_or_raise
from omen.scenario.ingest_validator import validate_precision_profile_or_raise
from omen.scenario.ingest_validator import DeferredScopeFeatureError
from omen.simulation.replay import (
    compare_run_results,
    create_counterfactual_config,
    load_run_result,
    run_counterfactual,
)
from omen.simulation.engine import run_simulation
from omen.simulation.deterministic import (
    run_compare,
    run_simulate_with_actor,
)
from omen.simulation.precision_gate import evaluate_precision_gates
from omen.simulation.precision_metrics import evaluate_repeatability


def _with_timestamp_suffix(path: Path) -> Path:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    if path.suffix:
        return path.with_name(f"{path.stem}_{timestamp}{path.suffix}")
    return path.with_name(f"{path.name}_{timestamp}")


def _write_output(
    rendered: str,
    requested_path: str | None,
    default_filename: str,
    incremental: bool,
) -> Path:
    if requested_path:
        output_path = Path(requested_path)
    else:
        default_path = Path(default_filename)
        output_path = (
            default_path
            if default_path.is_absolute() or len(default_path.parts) > 1
            else Path("output") / default_path
        )
    if incremental:
        output_path = _with_timestamp_suffix(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(rendered, encoding="utf-8")
    return output_path


def _default_pack_output(pack_id: str, filename: str) -> Path:
    normalized = str(pack_id or "unknown_pack").strip() or "unknown_pack"
    return Path("output") / normalized / filename


def _print_llm_check_result(report: dict[str, Any]) -> None:
    ok = bool(report.get("ok", False))
    if ok:
        print("LLM connectivity check: SUCCESS")
        return

    failed_steps = [
        str(step.get("name", "unknown"))
        for step in report.get("steps", [])
        if step.get("status") != "passed"
    ]
    if failed_steps:
        print(f"LLM connectivity check: FAILURE ({', '.join(failed_steps)})")
    else:
        print("LLM connectivity check: FAILURE")


def main() -> None:
    parser = argparse.ArgumentParser(prog="omen", description="Omen strategic simulation CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    simulate = sub.add_parser("simulate", help="run one scenario simulation")
    simulate.add_argument("--scenario", required=True, help="Path to scenario JSON")
    simulate.add_argument(
        "--ontology-input",
        required=False,
        help="Optional ontology input JSON path for battlefield setup metadata",
    )
    simulate.add_argument(
        "--seed",
        required=False,
        type=int,
        help="Optional stable seed. If omitted, simulate uses randomized seed each run.",
    )
    simulate.add_argument("--output", required=False, help="Optional output JSON path")
    simulate.add_argument(
        "--actor-profile-ref",
        required=False,
        default="actor_profile_v1",
        help="Actor profile version reference used in deterministic artifact",
    )
    simulate.add_argument(
        "--calc-policy-version",
        required=False,
        default="deterministic_v1",
        help="Calculation policy version used in deterministic artifact",
    )
    simulate.add_argument(
        "--incremental",
        action="store_true",
        help="Add timestamp suffix to output filename to avoid overwrite",
    )
    simulate.add_argument(
        "--workshop-ui-mode",
        action="store_true",
        help="Emit reason-chain view model artifact for workshop DAG rendering",
    )
    simulate.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logs for reason-chain LLM output under generation/output.txt",
    )

    explain = sub.add_parser("explain", help="generate explanation from a saved run result")
    explain_target = explain.add_mutually_exclusive_group(required=True)
    explain_target.add_argument("--input", required=False, help="Path to saved run result JSON")
    explain_target.add_argument(
        "--pack-id",
        required=False,
        help="Pack id. Input defaults to output/<pack-id>/result.json",
    )
    explain.add_argument("--output", required=False, help="Optional output JSON path")
    explain.add_argument(
        "--incremental",
        action="store_true",
        help="Add timestamp suffix to output filename to avoid overwrite",
    )

    compare = sub.add_parser("compare", help="run counterfactual and compare with baseline")
    compare.add_argument("--scenario", required=True, help="Path to scenario JSON")
    compare.add_argument(
        "--ontology-input",
        required=False,
        help="Optional ontology input JSON path for battlefield setup metadata",
    )
    compare.add_argument(
        "--overrides",
        required=False,
        help=(
            "JSON object of dotted-path overrides, "
            'e.g. {"user_overlap_threshold": 0.9}'
        ),
    )
    compare.add_argument(
        "--budget-actor",
        required=False,
        help="Actor id for budget shock entry (commercial primary parameter)",
    )
    compare.add_argument(
        "--budget-delta",
        required=False,
        type=float,
        help="Budget delta applied to --budget-actor in variation run",
    )
    compare.add_argument("--output", required=False, help="Optional comparison JSON path")
    compare.add_argument(
        "--actor-profile-ref",
        required=False,
        default="actor_profile_v1",
        help="Actor profile version reference used in deterministic artifact",
    )
    compare.add_argument(
        "--calc-policy-version",
        required=False,
        default="deterministic_v1",
        help="Calculation policy version used in deterministic artifact",
    )
    compare.add_argument(
        "--incremental",
        action="store_true",
        help="Add timestamp suffix to output filename to avoid overwrite",
    )
    compare.add_argument(
        "--workshop-ui-mode",
        action="store_true",
        help="Emit reason-chain view model artifact for workshop DAG rendering",
    )
    compare.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logs for reason-chain LLM output under generation/output.txt",
    )

    precision_eval = sub.add_parser(
        "precision-eval",
        help="run repeated simulations and report repeatability metrics",
    )
    precision_eval.add_argument("--scenario", required=True, help="Path to scenario JSON")
    precision_eval.add_argument(
        "--ontology-input",
        required=False,
        help="Optional ontology input JSON path for battlefield setup metadata",
    )
    precision_eval.add_argument(
        "--runs",
        required=False,
        type=int,
        default=5,
        help="Number of repeated runs (default: 5)",
    )
    precision_eval.add_argument(
        "--seed",
        required=False,
        type=int,
        help="Optional fixed seed used for each run",
    )
    precision_eval.add_argument("--output", required=False, help="Optional output JSON path")
    precision_eval.add_argument(
        "--incremental",
        action="store_true",
        help="Add timestamp suffix to output filename to avoid overwrite",
    )

    ingest_dry_run = sub.add_parser(
        "ingest-dry-run",
        help="build mapped ingest candidates from text/pdf without runtime integration",
    )
    ingest_dry_run.add_argument("--scenario", required=True, help="Path to scenario JSON")
    ingest_dry_run.add_argument(
        "--ontology-input",
        required=False,
        help="Optional ontology input JSON path; defaults to scenario file when ontology is embedded",
    )
    ingest_dry_run.add_argument("--text-file", required=False, help="Path to input text file")
    ingest_dry_run.add_argument("--pdf-file", required=False, help="Path to input PDF file")
    ingest_dry_run.add_argument("--pdf-start-page", required=False, type=int, default=1)
    ingest_dry_run.add_argument("--pdf-end-page", required=False, type=int)
    ingest_dry_run.add_argument(
        "--build-assertions",
        action="store_true",
        help="Generate ontology assertion candidates from extracted candidates",
    )
    ingest_dry_run.add_argument(
        "--auto-approve-mapped",
        action="store_true",
        help="Allow auto-approval only for mapped high-confidence candidates",
    )
    ingest_dry_run.add_argument(
        "--auto-approve-threshold",
        required=False,
        type=float,
        default=0.9,
        help="Confidence threshold for auto-approval when --auto-approve-mapped is enabled",
    )
    ingest_dry_run.add_argument("--output", required=False, help="Optional output JSON path")
    ingest_dry_run.add_argument(
        "--incremental",
        action="store_true",
        help="Add timestamp suffix to output filename to avoid overwrite",
    )

    precision_gate = sub.add_parser(
        "precision-gate",
        help="evaluate precision release gates with profile + precision artifacts",
    )
    precision_gate.add_argument("--profile-json", required=True, help="Path to precision profile JSON")
    precision_gate.add_argument(
        "--precision-json",
        required=False,
        help="Optional precision-eval output JSON path",
    )
    precision_gate.add_argument(
        "--comparison-json",
        required=False,
        help="Optional compare output JSON path with precision_summary",
    )
    precision_gate.add_argument("--output", required=False, help="Optional output JSON path")
    precision_gate.add_argument(
        "--incremental",
        action="store_true",
        help="Add timestamp suffix to output filename to avoid overwrite",
    )

    case_replay_generate = sub.add_parser(
        "case-replay-generate",
        help="generate Strategy Ontology from case document using local LLM config",
    )
    case_replay_generate.add_argument("--document", required=True, help="Path to case document")
    case_replay_generate.add_argument("--case-id", required=True, help="Case identifier")
    case_replay_generate.add_argument("--title", required=True, help="Case title")
    case_replay_generate.add_argument(
        "--strategy",
        required=False,
        help="Optional reusable strategy family label, e.g. new_tech_market_entry",
    )
    case_replay_generate.add_argument(
        "--known-outcome",
        required=True,
        help="Known historical outcome for replay anchoring",
    )
    case_replay_generate.add_argument(
        "--config",
        required=False,
        default="config/llm.toml",
        help="Path to local LLM config TOML",
    )
    case_replay_generate.add_argument("--output", required=False, help="Optional output ontology JSON")
    case_replay_generate.add_argument(
        "--reuse-if-valid",
        action="store_true",
        help="Reuse existing ontology artifact if it already exists and passes validation",
    )
    case_replay_generate.add_argument(
        "--incremental",
        action="store_true",
        help="Add timestamp suffix to output filename to avoid overwrite",
    )

    case_replay_baseline = sub.add_parser(
        "case-replay-baseline",
        help="run baseline replay from generated ontology JSON",
    )
    case_replay_baseline.add_argument("--case-id", required=True, help="Case identifier")
    case_replay_baseline.add_argument(
        "--ontology",
        required=True,
        help="Path to generated Strategy Ontology JSON",
    )
    case_replay_baseline.add_argument(
        "--output-dir",
        required=False,
        default="output/case_replay",
        help="Root output directory",
    )
    case_replay_baseline.add_argument("--output", required=False, help="Optional output summary JSON")
    case_replay_baseline.add_argument(
        "--incremental",
        action="store_true",
        help="Add timestamp suffix to output filename to avoid overwrite",
    )

    check_llm = sub.add_parser(
        "check-llm",
        help="run generic LLM connectivity check with default sample case file",
    )
    check_llm.add_argument(
        "--config",
        required=False,
        default="config/llm.toml",
        help="Path to local LLM config TOML",
    )
    check_llm.add_argument(
        "--case-file",
        required=False,
        default="cases/x-developer.md",
        help="Default case file used to build connectivity probe text",
    )
    check_llm.add_argument(
        "--sample-text",
        required=False,
        help="Optional probe text override; if omitted, read from --case-file",
    )

    analyze_sub = register_analyze_commands(sub)
    register_situation_analyze_commands(analyze_sub)
    register_validate_commands(sub)
    register_case_commands(sub)
    register_scenario_command(sub)

    args = parser.parse_args()

    def _print_deferred_scope_message(exc: Exception) -> None:
        print(f"Deferred scope: {exc}")
        print(
            "This release supports deterministic A/B/C packs only. "
            "Dynamic scenario authoring and enterprise resistance extensions are deferred."
        )

    if args.command == "simulate":
        try:
            deterministic_payload = run_simulate_with_actor(
                scenario_path=args.scenario,
                actor_profile_ref=args.actor_profile_ref,
                calculation_policy_version=args.calc_policy_version,
                debug=bool(args.debug),
                workshop_ui_mode=bool(args.workshop_ui_mode),
            )
            if deterministic_payload is not None:
                pack_id = str(deterministic_payload.get("scenario_pack_ref") or "").strip() or "unknown_pack"
                rendered = json.dumps(deterministic_payload, ensure_ascii=False, indent=2)
                output_path = _write_output(
                    rendered,
                    args.output,
                    str(_default_pack_output(pack_id, "result.json")),
                    args.incremental,
                )
                print(f"Saved deterministic simulation result to {output_path}")
                return
        except DeferredScopeFeatureError as exc:
            _print_deferred_scope_message(exc)
            raise SystemExit(2) from exc
        except Exception as exc:
            print(f"Deterministic simulate failed: {exc}")
            raise SystemExit(2) from exc

        load_case_package_from_scenario(args.scenario)
        config, ontology_setup = load_scenario_with_ontology(args.scenario, args.ontology_input)
        if args.seed is None:
            config = create_counterfactual_config(config, {"seed": None})
        else:
            config = create_counterfactual_config(config, {"seed": args.seed})
        result = run_simulation(config, ontology_setup=ontology_setup)
        rendered = json.dumps(result, ensure_ascii=False, indent=2)
        output_path = _write_output(rendered, args.output, "result.json", args.incremental)
        print(f"Saved simulation result to {output_path}")
    elif args.command == "explain":
        input_path = Path(args.input) if getattr(args, "input", None) else _default_pack_output(args.pack_id, "result.json")
        result = load_run_result(input_path)
        if "scenario_pack_ref" in result and "scenario_results" in result:
            explanation = generate_deterministic_explanation(
                result_payload=result,
                result_path=input_path,
            )
            default_output = str(_default_pack_output(str(result.get("scenario_pack_ref") or args.pack_id or "unknown_pack"), "explanation.json"))
        else:
            explanation = build_explanation_report(result)
            default_output = "explanation.json"
        rendered = json.dumps(explanation, ensure_ascii=False, indent=2)
        output_path = _write_output(rendered, args.output, default_output, args.incremental)
        print(f"Saved explanation to {output_path}")
    elif args.command == "compare":
        try:
            deterministic_payload = run_compare(
                scenario_path=args.scenario,
                actor_profile_ref=args.actor_profile_ref,
                calculation_policy_version=args.calc_policy_version,
                debug=bool(args.debug),
                workshop_ui_mode=bool(args.workshop_ui_mode),
            )
            if deterministic_payload is not None:
                pack_id = str(deterministic_payload.get("scenario_pack_ref") or "").strip() or "unknown_pack"
                rendered = json.dumps(deterministic_payload, ensure_ascii=False, indent=2)
                output_path = _write_output(
                    rendered,
                    args.output,
                    str(_default_pack_output(pack_id, "comparison.json")),
                    args.incremental,
                )
                print(f"Saved deterministic comparison to {output_path}")
                return
        except DeferredScopeFeatureError as exc:
            _print_deferred_scope_message(exc)
            raise SystemExit(2) from exc
        except Exception as exc:
            print(f"Deterministic compare failed: {exc}")
            raise SystemExit(2) from exc

        load_case_package_from_scenario(args.scenario)
        config, ontology_setup = load_scenario_with_ontology(args.scenario, args.ontology_input)
        baseline = run_simulation(config, ontology_setup=ontology_setup)
        overrides: dict[str, Any] = {}
        conditions: list[dict[str, Any]] = []

        if args.overrides:
            try:
                overrides = json.loads(args.overrides)
            except json.JSONDecodeError as exc:
                parser.error(f"invalid --overrides JSON: {exc}")
                return

            if not isinstance(overrides, dict):
                parser.error("--overrides must be a JSON object")
                return
            for key, value in sorted(overrides.items()):
                conditions.append(
                    {
                        "type": "override",
                        "key": key,
                        "value": value,
                        "description": f"override `{key}` -> {value}",
                    }
                )

        has_budget_actor = args.budget_actor is not None
        has_budget_delta = args.budget_delta is not None
        if has_budget_actor != has_budget_delta:
            parser.error("--budget-actor and --budget-delta must be provided together")
            return

        if has_budget_actor and has_budget_delta:
            actor_index = next(
                (idx for idx, actor in enumerate(config.actors) if actor.actor_id == args.budget_actor),
                None,
            )
            if actor_index is None:
                parser.error(f"unknown --budget-actor: {args.budget_actor}")
                return
            original_budget = config.actors[actor_index].budget
            overrides[f"actors.{actor_index}.budget"] = original_budget + args.budget_delta
            conditions.append(
                {
                    "type": "budget_delta",
                    "actor_id": args.budget_actor,
                    "delta": args.budget_delta,
                    "new_budget": original_budget + args.budget_delta,
                    "description": (
                        f"budget shock for `{args.budget_actor}`: "
                        f"{original_budget} -> {original_budget + args.budget_delta} "
                        f"(delta {args.budget_delta})"
                    ),
                }
            )

        if not overrides:
            parser.error("provide --overrides and/or --budget-actor with --budget-delta")
            return

        _, variation = run_counterfactual(config, overrides, ontology_setup=ontology_setup)
        comparison = compare_run_results(baseline, variation, conditions=conditions)
        rendered = json.dumps(comparison, ensure_ascii=False, indent=2)
        output_path = _write_output(rendered, args.output, "comparison.json", args.incremental)
        print(f"Saved comparison to {output_path}")
    elif args.command == "precision-eval":
        if args.runs < 1:
            parser.error("--runs must be >= 1")
            return

        load_case_package_from_scenario(args.scenario)
        config, ontology_setup = load_scenario_with_ontology(args.scenario, args.ontology_input)

        results: list[dict[str, Any]] = []
        for _ in range(args.runs):
            if args.seed is None:
                run_config = create_counterfactual_config(config, {"seed": None})
            else:
                run_config = create_counterfactual_config(config, {"seed": args.seed})
            results.append(run_simulation(run_config, ontology_setup=ontology_setup))

        repeatability = evaluate_repeatability(results)
        payload = {
            "scenario_id": config.scenario_id,
            "runs": args.runs,
            "seed": args.seed,
            "repeatability": repeatability,
        }
        rendered = json.dumps(payload, ensure_ascii=False, indent=2)
        output_path = _write_output(rendered, args.output, "precision.json", args.incremental)
        print(f"Saved precision evaluation to {output_path}")
    elif args.command == "ingest-dry-run":
        load_case_package_from_scenario(args.scenario)
        has_text = bool(args.text_file)
        has_pdf = bool(args.pdf_file)
        if has_text == has_pdf:
            parser.error("provide exactly one of --text-file or --pdf-file")
            return

        ontology_path = args.ontology_input or args.scenario
        ontology = load_ontology_input(ontology_path)
        concept_names = [concept.name for concept in ontology.tbox.concepts]
        print(f"DEBUG: Loaded {len(concept_names)} concepts: {concept_names}")

        if has_text:
            text_path = Path(args.text_file)
            if not text_path.exists():
                parser.error(f"--text-file not found: {text_path}")
                return
            raw_text = text_path.read_text(encoding="utf-8")
            document_id = text_path.stem
            source_type = "text"
            source_path = str(text_path)
        else:
            pdf_path = Path(args.pdf_file)
            raw_text = extract_pdf_pages(
                pdf_path,
                start_page=args.pdf_start_page,
                end_page=args.pdf_end_page,
            )
            document_id = pdf_path.stem
            source_type = "pdf"
            source_path = str(pdf_path)

        candidates = build_candidates_from_text(
            raw_text,
            document_id=document_id,
            concept_names=concept_names,
        )
        validate_extracted_entity_candidates_or_raise(candidates)

        assertion_candidates: list[dict[str, Any]] = []
        if args.build_assertions:
            assertion_candidates = build_assertions_from_candidates(
                candidates,
                auto_approve_mapped=args.auto_approve_mapped,
                auto_approve_threshold=args.auto_approve_threshold,
            )
            validate_ontology_assertion_candidates_or_raise(assertion_candidates)

        assertion_review_summary = {
            "pending": sum(1 for item in assertion_candidates if item.get("review_state") == "pending"),
            "approved": sum(1 for item in assertion_candidates if item.get("review_state") == "approved"),
            "rejected": sum(1 for item in assertion_candidates if item.get("review_state") == "rejected"),
        }

        payload = {
            "document": {
                "document_id": document_id,
                "source_type": source_type,
                "source_path": source_path,
            },
            "source_inventory": build_source_inventory(),
            "candidate_count": len(candidates),
            "mapped_count": sum(1 for item in candidates if item.get("mapping_status") == "mapped"),
            "candidates": candidates,
            "assertion_count": len(assertion_candidates),
            "assertion_review_summary": assertion_review_summary,
            "assertions": assertion_candidates,
        }
        rendered = json.dumps(payload, ensure_ascii=False, indent=2)
        output_path = _write_output(rendered, args.output, "ingest_candidates.json", args.incremental)
        print(f"Saved ingest dry-run candidates to {output_path}")
    elif args.command == "precision-gate":
        profile_payload = json.loads(Path(args.profile_json).read_text(encoding="utf-8"))
        profile = validate_precision_profile_or_raise(profile_payload)

        precision_payload = None
        if args.precision_json:
            precision_payload = json.loads(Path(args.precision_json).read_text(encoding="utf-8"))

        comparison_payload = None
        if args.comparison_json:
            comparison_payload = json.loads(Path(args.comparison_json).read_text(encoding="utf-8"))

        if not precision_payload and not comparison_payload:
            parser.error("provide --precision-json and/or --comparison-json")
            return

        directional_metrics = (
            ((comparison_payload or {}).get("precision_summary", {}) or {}).get(
                "directional_correctness", {}
            )
        )
        trace_metrics = (
            ((comparison_payload or {}).get("precision_summary", {}) or {}).get(
                "trace_completeness", {}
            )
        )
        repeatability_metrics = (precision_payload or {}).get("repeatability", {})

        gate_evaluation = evaluate_precision_gates(
            profile,
            repeatability_metrics=repeatability_metrics,
            directional_metrics=directional_metrics,
            trace_metrics=trace_metrics,
        )
        report = build_precision_report(
            gate_evaluation=gate_evaluation,
            profile_payload=profile_payload,
            precision_payload=precision_payload,
            comparison_payload=comparison_payload,
        )
        rendered = json.dumps(report, ensure_ascii=False, indent=2)
        output_path = _write_output(rendered, args.output, "precision_gate_report.json", args.incremental)
        print(f"Saved precision gate report to {output_path}")
    elif args.command == "case-replay-generate":
        from omen.ingest.synthesizer.services.strategy import generate_strategy_ontology_from_document
        from omen.scenario.case_replay_loader import save_strategy_ontology
        from omen.ingest.validators.strategy import validate_ontology_input_or_raise
        from omen.ui.artifacts import ensure_case_output_dir

        def _step_logger(step: str, status: str, message: str) -> None:
            print(f"[CASE-REPLAY-GEN][{step}][{status}] {message}", flush=True)

        case_dir = ensure_case_output_dir(args.case_id)
        output_path = args.output
        if not output_path:
            output_path = str(case_dir / "strategy_ontology.json")

        if args.reuse_if_valid:
            existing_path = Path(output_path)
            if existing_path.exists():
                try:
                    existing_payload = json.loads(existing_path.read_text(encoding="utf-8"))
                    validate_ontology_input_or_raise(existing_payload)
                    _step_logger("reuse", "PASSED", f"reusing valid ontology at {existing_path}")
                    payload = {
                        "case_id": args.case_id,
                        "strategy_ontology": existing_payload,
                        "validation_passed": True,
                        "validation_issues": [],
                        "ontology_path": str(existing_path),
                        "reused_existing": True,
                    }
                    rendered = json.dumps(payload, ensure_ascii=False, indent=2, default=str)
                    report_output_path = _write_output(
                        rendered,
                        args.output or str(case_dir / "generation.json"),
                        "generation.json",
                        args.incremental,
                    )
                    print(f"Reused ontology at {existing_path}")
                    print(f"Saved generation report to {report_output_path}")
                    return
                except Exception as exc:
                    _step_logger("reuse", "FAILED", f"existing ontology invalid, regenerating: {exc}")

        _step_logger("generation", "STARTED", "starting document -> ontology workflow")
        generation = generate_strategy_ontology_from_document(
            document_path=args.document,
            case_id=args.case_id,
            title=args.title,
            strategy=args.strategy,
            known_outcome=args.known_outcome,
            config_path=args.config,
            logger=_step_logger,
        )

        _step_logger("artifact", "RUNNING", "persisting ontology artifact")
        ontology_path = save_strategy_ontology(generation.strategy_ontology, output_path)
        _step_logger("artifact", "PASSED", f"saved ontology to {ontology_path}")
        payload = generation.model_dump(mode="python")
        payload["ontology_path"] = str(ontology_path)
        payload["validation_passed"] = bool(payload.get("validation_passed"))

        _step_logger("report", "RUNNING", "writing generation summary report")
        rendered = json.dumps(payload, ensure_ascii=False, indent=2, default=str)
        report_output_path = _write_output(
            rendered,
            args.output or str(case_dir / "generation.json"),
            "generation.json",
            args.incremental,
        )
        _step_logger("report", "PASSED", f"saved generation report to {report_output_path}")

        if payload["validation_passed"]:
            _step_logger("generation", "DONE", "workflow completed successfully")
        else:
            _step_logger("generation", "DONE", "workflow completed with validation issues")
        print(f"Saved ontology to {ontology_path}")
        print(f"Saved generation report to {report_output_path}")
        if not payload["validation_passed"]:
            raise SystemExit(2)
    elif args.command == "case-replay-baseline":
        from omen.ui.artifacts import ensure_case_output_dir
        from omen.simulation.case_replay import run_case_replay_baseline

        payload = run_case_replay_baseline(
            case_id=args.case_id,
            ontology_path=args.ontology,
            output_root=args.output_dir,
        )
        case_dir = ensure_case_output_dir(args.case_id, output_root=args.output_dir)
        rendered = json.dumps(payload, ensure_ascii=False, indent=2)
        output_path = _write_output(
            rendered,
            args.output or str(case_dir / "baseline_summary.json"),
            "baseline_summary.json",
            args.incremental,
        )
        print(f"Saved baseline summary to {output_path}")
    elif args.command == "check-llm":
        from omen.ingest.synthesizer.healthcheck import run_llm_healthcheck

        def _step_logger(step: str, status: str, message: str) -> None:
            print(f"[LLM-CHECK][{step}][{status}] {message}", flush=True)

        sample_text = args.sample_text
        if not sample_text:
            case_file = Path(args.case_file)
            if case_file.exists():
                sample_text = case_file.read_text(encoding="utf-8")[:1000]
            else:
                sample_text = "omen connectivity probe"

        report = run_llm_healthcheck(
            config_path=args.config,
            sample_text=sample_text,
            logger=_step_logger,
        )
        print(json.dumps(report, ensure_ascii=False, indent=2))
        _print_llm_check_result(report)
        if not report.get("ok", False):
            raise SystemExit(2)
    elif args.command == "case":
        raise SystemExit(handle_case_command(args))
    elif args.command == "analyze":
        if getattr(args, "analyze_object", None) == "situation":
            raise SystemExit(handle_situation_analyze_command(args))
        raise SystemExit(handle_analyze_command(args))
    elif args.command == "scenario":
        raise SystemExit(handle_scenario_command(args))
    elif args.command == "validate":
        raise SystemExit(handle_validate_command(args))


if __name__ == "__main__":
    main()
