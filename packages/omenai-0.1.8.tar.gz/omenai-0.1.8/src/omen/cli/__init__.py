"""CLI package for Omen."""
