# Copyright 2026 Luminary Cloud, Inc. All Rights Reserved.

from typing import Any


def validate_defaults(defaults: dict[str, Any]) -> None:
    assert "LC_DOMAIN" in defaults, "LC_DOMAIN must be defined"
    if "LC_PRIMARY_DOMAIN" in defaults:
        assert isinstance(defaults["LC_PRIMARY_DOMAIN"], str)

    assert "INTERACTIVE_AUTH_ENABLED" in defaults, "INTERACTIVE_AUTH_ENABLED must be defined"
    assert isinstance(defaults["INTERACTIVE_AUTH_ENABLED"], bool)
    if defaults["INTERACTIVE_AUTH_ENABLED"]:
        msg = "Auth0 information must be defined if interactive auth is enabled"
        assert "LC_AUTH_DOMAIN" in defaults, msg
        assert "LC_AUTH_CLIENT_ID" in defaults, msg
        assert "LC_AUTH_SERVICE_ID" in defaults, msg
        assert "ALLOWED_CALLBACK_PORTS" in defaults, msg
