"""
Structlog-based logging for canvod-auxiliary package.

Provides consistent logging with the main canvodpy package.
"""

import structlog


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    """Get a structlog logger instance.

    Parameters
    ----------
    name : str, optional
        Logger name, typically __name__ of the module.
        If None, uses "canvod.auxiliary".

    Returns
    -------
    structlog.stdlib.BoundLogger
        Configured structlog logger.

    Examples
    --------
    >>> log = get_logger(__name__)
    >>> log.info("aux_pipeline_initialized", date="2025001")
    """
    if name is None:
        name = "canvod.auxiliary"
    return structlog.get_logger(name)
