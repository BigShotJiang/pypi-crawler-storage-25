from setuptools import setup, find_packages

setup(
    name="mcpcat_api",
    version="0.1.9",
    packages=find_packages(),
    install_requires=[
        "urllib3>=2.1.0,<3.0.0",
        "python-dateutil",
        "pydantic>=2.0.0,<3",
    ],
)
