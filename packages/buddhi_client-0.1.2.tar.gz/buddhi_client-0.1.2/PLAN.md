# Buddhi SDK — Implementation Plan

## Overview
Single Python package (`buddhi-client`) that wraps the Buddhi Engine API.
Customers install via `pip install buddhi-client` and get guardrail validation
in 3 lines of code. Server-side tier gating — one package, all tiers.

---

## Phase 1: Backend — API Key Auth Dependency + Quota Enforcement ✅ DONE

**Status:** Implemented and tested.

**Files:**
- `backend/platform_api/middleware/api_key_auth.py` (NEW)
- `backend/platform_api/database/mysql.py` (add `get_monthly_call_count`)

**What it does:**
1. `get_current_user_by_api_key(authorization)` dependency
2. Hashes incoming `be_*` key → `db.validate_api_key()` → `{user_id, email, tier}`
3. Checks subscription: `current_period_end >= NOW()` — 403 if expired
4. Checks monthly quota: counts usage_metrics for current month vs plan limit
5. Starter: hard block at 500 (429 + upgrade message)
6. Professional/Business: allow overage, return `X-Overage: true` header
7. Enterprise: unlimited
8. Returns `X-RateLimit-Limit`, `X-RateLimit-Remaining` on every response

**Plan limits:**
| Plan         | Monthly calls | Overage          |
|--------------|--------------|------------------|
| Starter/Free | 500          | Blocked (429)    |
| Professional | 10,000       | $0.012/call      |
| Business     | 100,000      | $0.006/call      |
| Enterprise   | Unlimited    | Negotiated       |

---

## Phase 2: Backend — SDK Endpoints ✅ DONE

**Status:** All 7 endpoints implemented, tested, passing (11/11 tests).

**File:** `backend/platform_api/endpoints/sdk_evaluate.py` (NEW)

| Endpoint                      | Method | Auth    | Tier         | Purpose                             |
|-------------------------------|--------|---------|--------------|-------------------------------------|
| `/api/v1/sdk/evaluate`        | POST   | API Key | All          | Validate text against 1 or all policies |
| `/api/v1/sdk/evaluate/batch`  | POST   | API Key | Professional+| Batch validate up to 100 items      |
| `/api/v1/sdk/policies`        | GET    | API Key | All          | List customer's active policies     |
| `/api/v1/sdk/policies/{id}`   | GET    | API Key | All          | Get single policy detail            |
| `/api/v1/sdk/usage`           | GET    | API Key | All          | Month call count + remaining quota  |
| `/api/v1/sdk/instances`       | GET    | API Key | All          | List customer's running instances   |
| `/api/v1/sdk/health`          | GET    | None    | All          | Platform status                     |

**Evaluate request:**
```json
{
  "text": "...",
  "policy_id": "hipaa-v2",
  "context": {"user_role": "nurse"},
  "instance_id": "aerm_001033_xyz",
  "include_trace": false
}
```
- `policy_id` optional — null = run ALL attached policies
- `instance_id` optional — null = most recently deployed running instance
- `context` optional — extra fields for rule condition evaluation

**Instance selection logic:**
1. If `instance_id` provided → use it (verify ownership)
2. If omitted + user has instances → most recently deployed running one
3. If omitted + free tier → shared instance (aerm_shared_free)
4. If no running instance found → 503 with clear message

---

## Phase 3: SDK Python Package ✅ DONE

**Status:** Package structure created, sync + async clients working, example.py tested live.

**Location:** `Budhhi_Prod_Deployment/buddhi-sdk/`

```
buddhi-sdk/
├── pyproject.toml
├── README.md
├── LICENSE
├── src/buddhi/
│   ├── __init__.py
│   ├── client.py          # RakshaClient (sync) + AsyncRakshaClient
│   ├── models.py          # Pydantic v2 response models
│   └── exceptions.py      # BuddhiError hierarchy
└── tests/
    ├── test_client.py
    └── test_integration.py
```

**Dependencies:** httpx>=0.24.0, pydantic>=2.0.0

**Customer usage:**
```python
from buddhi import RakshaClient

client = RakshaClient(api_key="be_abc123...")
result = client.validate("Can you share patient lab results?")

# Multi-instance (Pro/Business)
client = RakshaClient(api_key="be_abc123...", instance_id="aerm_005_prod")

# Self-hosted Enterprise
client = RakshaClient(api_key="be_abc123...", base_url="https://guardrails.acme.internal")
```

---

## Phase 4: Subscription Enforcement Cron ✅ DONE

**Status:** Background task running in main.py lifespan, 6-hour interval, tested on startup.

- Background task in `main.py` lifespan — runs every 6 hours
- Marks expired subscriptions, revokes licenses
- API key auth dependency checks status → expired users get 403

---

## Phase 5: Dashboard Integration 🟡 IN PROGRESS

**Status:** Customer-facing frontend cleanup completed for SDK experience and naming consistency.

- ✅ Replaced customer dashboard/API key/instance pages from legacy GhostMind SDK references to Buddhi SDK usage examples
- ✅ Updated install guidance from `ghostmind-client` to `buddhi-client` references in customer UI flows
- ✅ Removed customer dashboard "coming soon" click stubs by routing to existing pages (usage/instances)
- ✅ Fixed public customer-facing repo/discussion links away from GhostMind SDK references
- ⏳ Remaining: expiry warning banner (7-day amber, expired red)
- ⏳ Remaining: real-time usage progress bar refinement

---

## Phase 6: End-to-End Tests ✅ DONE

**Status:** test_sdk_api.py (11/11 pass), test_sdk_client.py, example.py all working.

| Test | Validates |
|------|-----------|
| test_evaluate_with_api_key | Full flow: key → user → instance → result |
| test_evaluate_specific_policy | policy_id routes to correct YAML |
| test_evaluate_all_policies | null policy_id runs all attached |
| test_evaluate_specific_instance | instance_id routes correctly |
| test_quota_starter_blocked | 501st call → 429 |
| test_overage_professional | 10,001st call → success + X-Overage header |
| test_expired_subscription | 403 with message |
| test_batch_tier_gate | Starter → 403 on /batch |
| test_sdk_client_e2e | Python SDK → server → correct result |

---

## Decisions

- **Starter overage:** Hard block at 500 → 429 + "Upgrade to Professional"
- **Default instance:** Most recently deployed running instance
- **Package name:** `buddhi-client` (import as `from buddhi import RakshaClient`)
- **Self-hosted base_url:** Supported in v1 via `base_url` parameter
