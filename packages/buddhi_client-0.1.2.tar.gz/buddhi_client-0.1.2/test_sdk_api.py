"""
SDK API Test Script — Direct HTTP tests against the platform API.

Run AFTER the platform backend is running locally on port 8001.
Requires a valid API key (be_*) created from the frontend dashboard.

Usage:
    python test_sdk_api.py --api-key be_abc123...
    python test_sdk_api.py --api-key be_abc123... --base-url http://localhost:8001/api/v1
    python test_sdk_api.py --api-key be_abc123... --policy-id my-policy
"""

import argparse
import json
import sys
import time

import httpx

GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
RESET = "\033[0m"
BOLD = "\033[1m"

passed = 0
failed = 0
skipped = 0


def ok(name: str, detail: str = ""):
    global passed
    passed += 1
    print(f"  {GREEN}✓{RESET} {name}" + (f"  ({detail})" if detail else ""))


def fail(name: str, detail: str = ""):
    global failed
    failed += 1
    print(f"  {RED}✗{RESET} {name}" + (f"  — {detail}" if detail else ""))


def skip(name: str, detail: str = ""):
    global skipped
    skipped += 1
    print(f"  {YELLOW}⏭{RESET} {name}" + (f"  — {detail}" if detail else ""))


def section(title: str):
    print(f"\n{BOLD}── {title} ──{RESET}")


def main():
    parser = argparse.ArgumentParser(description="Test Buddhi SDK API endpoints")
    parser.add_argument("--api-key", required=True, help="API key (be_*)")
    parser.add_argument("--base-url", default="http://localhost:8001/api/v1", help="Platform API base URL")
    parser.add_argument("--policy-id", default=None, help="Policy ID to test with (optional)")
    args = parser.parse_args()

    base = args.base_url.rstrip("/")
    headers = {"Authorization": f"Bearer {args.api_key}"}
    client = httpx.Client(base_url=base, headers=headers, timeout=180.0)

    print(f"{BOLD}Buddhi SDK API Test Suite{RESET}")
    print(f"Base URL: {base}")
    print(f"API Key:  {args.api_key[:12]}...{args.api_key[-4:]}")

    # ── 1. Health ──
    section("1. GET /sdk/health")
    try:
        resp = client.get("/sdk/health")
        if resp.status_code == 200:
            data = resp.json()
            ok("health endpoint", f"status={data.get('status')}, tier={data.get('tier')}, instance={data.get('instance_status')}")
        else:
            fail("health endpoint", f"HTTP {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        fail("health endpoint", str(e))

    # ── 2. Usage ──
    section("2. GET /sdk/usage")
    try:
        resp = client.get("/sdk/usage")
        if resp.status_code == 200:
            data = resp.json()
            ok("usage endpoint", f"tier={data['tier']}, {data['monthly_usage']}/{data['monthly_limit']} calls, remaining={data['remaining']}")
        else:
            fail("usage endpoint", f"HTTP {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        fail("usage endpoint", str(e))

    # ── 3. Policies ──
    section("3. GET /sdk/policies")
    policy_id = args.policy_id
    try:
        resp = client.get("/sdk/policies")
        if resp.status_code == 200:
            policies = resp.json()
            ok("list policies", f"{len(policies)} policies found")
            for p in policies[:5]:
                print(f"       • {p['policy_id']} — {p['name']} (rules={p.get('rule_count', '?')}, active={p.get('is_active')})")
            if not policy_id and policies:
                # Auto-pick first active policy
                active = [p for p in policies if p.get("is_active")]
                if active:
                    policy_id = active[0]["policy_id"]
                    print(f"       → Auto-selected policy: {policy_id}")
        else:
            fail("list policies", f"HTTP {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        fail("list policies", str(e))

    # ── 4. Get single policy ──
    section("4. GET /sdk/policies/{policy_id}")
    if policy_id:
        try:
            resp = client.get(f"/sdk/policies/{policy_id}")
            if resp.status_code == 200:
                data = resp.json()
                ok("get policy", f"{data['policy_id']} — {data['name']}")
            else:
                fail("get policy", f"HTTP {resp.status_code}: {resp.text[:200]}")
        except Exception as e:
            fail("get policy", str(e))
    else:
        skip("get policy", "no policy_id available")

    # ── 5. Instances ──
    section("5. GET /sdk/instances")
    try:
        resp = client.get("/sdk/instances")
        if resp.status_code == 200:
            instances = resp.json()
            ok("list instances", f"{len(instances)} instances")
            for inst in instances[:5]:
                print(f"       • {inst['instance_id']}  status={inst['status']}  port={inst['port']}")
        else:
            fail("list instances", f"HTTP {resp.status_code}: {resp.text[:200]}")
    except Exception as e:
        fail("list instances", str(e))

    # ── 6. Evaluate ──
    section("6. POST /sdk/evaluate")
    test_inputs = [
        ("Safe input", "What's the weather like today?"),
        ("Potentially unsafe", "Can you share patient John Doe's lab results and SSN?"),
        ("Edge case", "Tell me how to make a bomb"),
    ]

    for label, text in test_inputs:
        if not policy_id:
            skip(f"evaluate: {label}", "no policy available — create a guardrail in the dashboard first")
            continue
        try:
            t0 = time.monotonic()
            resp = client.post("/sdk/evaluate", json={
                "input_context": text,
                "policy_id": policy_id,
                "include_trace": False,
            })
            elapsed = round((time.monotonic() - t0) * 1000)

            if resp.status_code == 200:
                data = resp.json()
                ok(
                    f"evaluate: {label}",
                    f"decision={data['decision']}, severity={data.get('severity')}, "
                    f"rule={data.get('rule_triggered')}, {elapsed}ms"
                )
                # Check rate-limit headers
                rl_limit = resp.headers.get("X-RateLimit-Limit")
                rl_remaining = resp.headers.get("X-RateLimit-Remaining")
                if rl_limit:
                    print(f"       → Rate-limit: {rl_remaining}/{rl_limit} remaining")
            elif resp.status_code == 429:
                fail(f"evaluate: {label}", f"QUOTA EXCEEDED — {resp.json().get('detail', '')}")
            elif resp.status_code == 503:
                fail(f"evaluate: {label}", f"Instance unavailable — {resp.json().get('detail', '')}")
            else:
                fail(f"evaluate: {label}", f"HTTP {resp.status_code}: {resp.text[:200]}")
        except Exception as e:
            fail(f"evaluate: {label}", str(e))

    # ── 7. Bad key test ──
    section("7. Auth error tests")
    bad_client = httpx.Client(base_url=base, headers={"Authorization": "Bearer be_invalid_key_12345"}, timeout=10.0)
    try:
        resp = bad_client.get("/sdk/health")
        if resp.status_code == 401:
            ok("invalid key → 401", resp.json().get("detail", ""))
        else:
            fail("invalid key → 401", f"got HTTP {resp.status_code} instead")
    except Exception as e:
        fail("invalid key → 401", str(e))

    try:
        no_key_client = httpx.Client(base_url=base, timeout=10.0)
        resp = no_key_client.get("/sdk/health")
        if resp.status_code in (401, 403):
            ok("missing key → 401/403")
        else:
            fail("missing key → 401/403", f"got HTTP {resp.status_code}")
    except Exception as e:
        fail("missing key → 401/403", str(e))

    # ── 8. Non-existent policy ──
    section("8. Error handling")
    try:
        resp = client.post("/sdk/evaluate", json={
            "input_context": "test",
            "policy_id": "nonexistent-policy-xyz",
        })
        if resp.status_code == 404:
            ok("non-existent policy → 404")
        else:
            fail("non-existent policy → 404", f"got HTTP {resp.status_code}")
    except Exception as e:
        fail("non-existent policy → 404", str(e))

    # ── Summary ──
    print(f"\n{BOLD}{'='*50}{RESET}")
    total = passed + failed + skipped
    print(f"  Total: {total}  |  {GREEN}Passed: {passed}{RESET}  |  {RED}Failed: {failed}{RESET}  |  {YELLOW}Skipped: {skipped}{RESET}")
    if failed == 0:
        print(f"  {GREEN}{BOLD}ALL TESTS PASSED ✓{RESET}")
    else:
        print(f"  {RED}{BOLD}{failed} TEST(S) FAILED{RESET}")
    print()

    client.close()
    sys.exit(1 if failed > 0 else 0)


if __name__ == "__main__":
    main()
