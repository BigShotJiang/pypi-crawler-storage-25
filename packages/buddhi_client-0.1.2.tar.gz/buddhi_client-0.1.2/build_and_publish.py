"""
Build & Publish Script for Buddhi-client
=========================================

This script handles building the wheel/sdist and publishing to PyPI.

Usage:
    # 1. Build wheel + sdist (local only, no upload)
    python build_and_publish.py build

    # 2. Upload to TEST PyPI (for testing)
    python build_and_publish.py test

    # 3. Upload to REAL PyPI (production release)
    python build_and_publish.py publish

    # 4. Full flow: build → test upload → real upload
    python build_and_publish.py all

Prerequisites:
    pip install build twine

PyPI setup:
    1. Create account at https://pypi.org/account/register/
    2. Create API token at https://pypi.org/manage/account/token/
    3. Save token in ~/.pypirc or pass via --token flag

    For test PyPI:
    1. Create account at https://test.pypi.org/account/register/
    2. Create API token at https://test.pypi.org/manage/account/token/
"""

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

# This script lives in Buddhi-sdk/
ROOT = Path(__file__).parent.resolve()
DIST_DIR = ROOT / "dist"


def run(cmd: list, **kwargs):
    """Run a command and exit on failure."""
    print(f"\n> {' '.join(cmd)}")
    result = subprocess.run(cmd, cwd=str(ROOT), **kwargs)
    if result.returncode != 0:
        print(f"\nERROR: Command failed with code {result.returncode}")
        sys.exit(result.returncode)
    return result


def step_clean():
    """Remove old build artifacts."""
    print("\n=== Cleaning old builds ===")
    for d in ["dist", "build", "src/Buddhi.egg-info", "src/buddhi_client.egg-info"]:
        target = ROOT / d
        if target.exists():
            shutil.rmtree(target)
            print(f"  Removed {d}/")
    print("  Clean.")


def step_build():
    """Build wheel and sdist using PEP 517 (build module)."""
    print("\n=== Building wheel + sdist ===")
    step_clean()
    run([sys.executable, "-m", "build"])

    # List built files
    print("\nBuilt artifacts:")
    for f in sorted(DIST_DIR.iterdir()):
        size_kb = f.stat().st_size / 1024
        print(f"  {f.name}  ({size_kb:.1f} KB)")


def step_check():
    """Validate the built package with twine check."""
    print("\n=== Checking package ===")
    run([sys.executable, "-m", "twine", "check", "dist/*"])
    print("  Package valid.")


def get_token(prompt_msg: str = "Enter PyPI API token: ") -> str:
    """Prompt for API token from CLI or return from env var."""
    token = os.environ.get("PYPI_TOKEN") or os.environ.get("TWINE_PASSWORD")
    if token:
        return token
    # Prompt interactively
    import getpass
    return getpass.getpass(prompt_msg)


def step_upload_test(token: str = None):
    """Upload to Test PyPI."""
    print("\n=== Uploading to TEST PyPI ===")
    if not token:
        token = get_token("Enter Test PyPI API token: ")
    cmd = [
        sys.executable, "-m", "twine", "upload",
        "--repository-url", "https://test.pypi.org/legacy/",
        "dist/*",
    ]
    cmd.extend(["--username", "__token__", "--password", token])
    run(cmd)
    print("\n  Uploaded to test.pypi.org!")
    print("  Install with: pip install --index-url https://test.pypi.org/simple/ Buddhi-client")


def step_upload_prod(token: str = None):
    """Upload to real PyPI."""
    print("\n=== Uploading to PyPI (PRODUCTION) ===")
    confirm = input("  Are you sure you want to publish to PyPI? (yes/no): ")
    if confirm.strip().lower() != "yes":
        print("  Aborted.")
        return

    if not token:
        token = get_token("Enter PyPI API token: ")
    cmd = [sys.executable, "-m", "twine", "upload", "dist/*"]
    cmd.extend(["--username", "__token__", "--password", token])
    run(cmd)
    print("\n  Published to pypi.org!")
    print("  Install with: pip install Buddhi-client")


def step_verify_install():
    """Quick verify the built wheel can be imported."""
    print("\n=== Verifying package import ===")
    whl = list(DIST_DIR.glob("*.whl"))
    if not whl:
        print("  No wheel found, skipping.")
        return

    result = subprocess.run(
        [sys.executable, "-c",
         "import importlib.metadata; "
         "v = importlib.metadata.version('Buddhi-client'); "
         "print(f'Buddhi-client v{v} OK')"],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        print(f"  {result.stdout.strip()}")
    else:
        # Package not installed yet — install from wheel and test
        print("  Installing wheel for verification...")
        run([sys.executable, "-m", "pip", "install", str(whl[0]), "--force-reinstall", "--quiet"])
        run([sys.executable, "-c",
             "from Buddhi import RakshaClient, __version__; "
             f"print(f'Buddhi-client v{{__version__}} - import OK')"])


def main():
    parser = argparse.ArgumentParser(description="Build and publish Buddhi-client to PyPI")
    parser.add_argument(
        "action",
        choices=["build", "test", "publish", "all", "clean", "check", "verify"],
        help="build=wheel+sdist, test=upload to test.pypi.org, "
             "publish=upload to pypi.org, all=build+test+publish, "
             "clean=remove artifacts, check=twine check, verify=test import"
    )
    parser.add_argument("--token", default=None, help="PyPI API token (or set PYPI_TOKEN/TWINE_PASSWORD env var, or will prompt)")
    args = parser.parse_args()

    if args.action == "clean":
        step_clean()

    elif args.action == "build":
        step_build()
        step_check()

    elif args.action == "check":
        step_check()

    elif args.action == "verify":
        step_verify_install()

    elif args.action == "test":
        if not DIST_DIR.exists() or not list(DIST_DIR.iterdir()):
            step_build()
            step_check()
        step_upload_test(args.token)

    elif args.action == "publish":
        if not DIST_DIR.exists() or not list(DIST_DIR.iterdir()):
            step_build()
            step_check()
        step_upload_prod(args.token)

    elif args.action == "all":
        step_build()
        step_check()
        step_verify_install()
        step_upload_test(args.token)
        step_upload_prod(args.token)

    print("\nDone.")


if __name__ == "__main__":
    main()
