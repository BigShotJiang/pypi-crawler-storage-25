"""Pydantic v2 response models for the Buddhi SDK."""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel


class EvaluateResult(BaseModel):
    """Result of a guardrail evaluation."""
    decision: str  # "BLOCK", "CONTINUE", "WARN", "ERROR"
    reason: Optional[str] = None
    severity: Optional[str] = None
    rule_triggered: Optional[str] = None
    policy_id: Optional[str] = None
    evaluated_rules: int = 0
    execution_time_ms: float = 0.0
    trace: Optional[Dict[str, Any]] = None
    usage: Optional[Dict[str, Any]] = None

    @property
    def is_blocked(self) -> bool:
        return self.decision in ("BLOCK", "BLOCKED", "REJECT")

    @property
    def is_allowed(self) -> bool:
        return self.decision in ("CONTINUE", "APPROVE")


class BatchResult(BaseModel):
    """Result of a batch evaluation."""
    results: List[EvaluateResult]
    total_time_ms: float


class PolicyInfo(BaseModel):
    """Guardrail policy summary."""
    policy_id: str
    name: str
    description: Optional[str] = None
    is_active: bool = True
    rule_count: int = 0
    version: str = "1"
    attached_instances: Optional[str] = None


class UsageInfo(BaseModel):
    """Current month usage information."""
    tier: str
    monthly_limit: int
    monthly_usage: int
    remaining: int
    overage_allowed: bool
    period: str


class InstanceInfo(BaseModel):
    """AERM instance summary."""
    instance_id: str
    status: str
    port: int
    deployed_at: Optional[str] = None


class HealthInfo(BaseModel):
    """Platform health status."""
    status: str
    tier: str
    instance_status: Optional[str] = None
