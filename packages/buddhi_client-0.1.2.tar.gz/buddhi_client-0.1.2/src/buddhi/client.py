"""
Buddhi SDK Client — Sync and Async HTTP clients for the Buddhi Engine API.
"""

from typing import Dict, List, Optional

import httpx

from buddhi.exceptions import (
    AuthenticationError,
    BuddhiError,
    InstanceUnavailableError,
    PolicyNotFoundError,
    QuotaExceededError,
    ServerError,
    SubscriptionExpiredError,
)
from buddhi.models import (
    BatchResult,
    EvaluateResult,
    HealthInfo,
    InstanceInfo,
    PolicyInfo,
    UsageInfo,
)

_DEFAULT_BASE_URL = "http://buddhiengine.com/api/v1"
_DEFAULT_TIMEOUT = 180.0


def _map_error(resp: httpx.Response) -> BuddhiError:
    """Map HTTP error responses to typed SDK exceptions."""
    try:
        body = resp.json()
        detail = body.get("detail", resp.text[:300])
    except Exception:
        detail = resp.text[:300]

    code = resp.status_code
    if code == 401:
        return AuthenticationError(detail, status_code=code)
    if code == 403:
        if "expired" in detail.lower():
            return SubscriptionExpiredError(detail, status_code=code)
        return BuddhiError(detail, status_code=code)
    if code == 404:
        return PolicyNotFoundError(detail, status_code=code)
    if code == 429:
        return QuotaExceededError(detail, status_code=code)
    if code == 503:
        return InstanceUnavailableError(detail, status_code=code)
    if code >= 500:
        return ServerError(detail, status_code=code)
    return BuddhiError(detail, status_code=code)


# ============================================================================
# Async Client
# ============================================================================

class AsyncRakshaClient:
    """
    Async client for the Buddhi Engine guardrail API.

    Usage:
        async with AsyncRakshaClient(api_key="be_...") as client:
            result = await client.validate("text to check")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        instance_id: Optional[str] = None,
        timeout: float = _DEFAULT_TIMEOUT,
    ):
        if not api_key or not api_key.startswith("be_"):
            raise ValueError("api_key must start with 'be_'")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._instance_id = instance_id
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def close(self):
        await self._client.aclose()

    # --- core ---

    async def validate(
        self,
        text: str,
        *,
        policy_id: Optional[str] = None,
        instance_id: Optional[str] = None,
        include_trace: bool = False,
    ) -> EvaluateResult:
        """Evaluate text against a guardrail policy."""
        payload: Dict = {"input_context": text, "include_trace": include_trace}
        if policy_id:
            payload["policy_id"] = policy_id
        if instance_id or self._instance_id:
            payload["instance_id"] = instance_id or self._instance_id

        resp = await self._client.post("/sdk/evaluate", json=payload)
        if resp.status_code != 200:
            raise _map_error(resp)
        return EvaluateResult.model_validate(resp.json())

    async def validate_batch(
        self,
        items: List[Dict],
    ) -> BatchResult:
        """Batch evaluate multiple inputs (Professional+)."""
        resp = await self._client.post("/sdk/evaluate/batch", json={"items": items})
        if resp.status_code != 200:
            raise _map_error(resp)
        return BatchResult.model_validate(resp.json())

    # --- informational ---

    async def list_policies(self) -> List[PolicyInfo]:
        resp = await self._client.get("/sdk/policies")
        if resp.status_code != 200:
            raise _map_error(resp)
        return [PolicyInfo.model_validate(p) for p in resp.json()]

    async def get_policy(self, policy_id: str) -> PolicyInfo:
        resp = await self._client.get(f"/sdk/policies/{policy_id}")
        if resp.status_code != 200:
            raise _map_error(resp)
        return PolicyInfo.model_validate(resp.json())

    async def get_usage(self) -> UsageInfo:
        resp = await self._client.get("/sdk/usage")
        if resp.status_code != 200:
            raise _map_error(resp)
        return UsageInfo.model_validate(resp.json())

    async def list_instances(self) -> List[InstanceInfo]:
        resp = await self._client.get("/sdk/instances")
        if resp.status_code != 200:
            raise _map_error(resp)
        return [InstanceInfo.model_validate(i) for i in resp.json()]

    async def health(self) -> HealthInfo:
        resp = await self._client.get("/sdk/health")
        if resp.status_code != 200:
            raise _map_error(resp)
        return HealthInfo.model_validate(resp.json())


# ============================================================================
# Sync Client (wraps async via httpx sync)
# ============================================================================

class RakshaClient:
    """
    Synchronous client for the Buddhi Engine guardrail API.

    Usage:
        client = RakshaClient(api_key="be_...")
        result = client.validate("text to check")
        print(result.decision)  # "BLOCK" or "CONTINUE"
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        instance_id: Optional[str] = None,
        timeout: float = _DEFAULT_TIMEOUT,
    ):
        if not api_key or not api_key.startswith("be_"):
            raise ValueError("api_key must start with 'be_'")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._instance_id = instance_id
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        self._client.close()

    # --- core ---

    def validate(
        self,
        text: str,
        *,
        policy_id: Optional[str] = None,
        instance_id: Optional[str] = None,
        include_trace: bool = False,
    ) -> EvaluateResult:
        """Evaluate text against a guardrail policy."""
        payload: Dict = {"input_context": text, "include_trace": include_trace}
        if policy_id:
            payload["policy_id"] = policy_id
        if instance_id or self._instance_id:
            payload["instance_id"] = instance_id or self._instance_id

        resp = self._client.post("/sdk/evaluate", json=payload)
        if resp.status_code != 200:
            raise _map_error(resp)
        return EvaluateResult.model_validate(resp.json())

    def validate_batch(
        self,
        items: List[Dict],
    ) -> BatchResult:
        """Batch evaluate multiple inputs (Professional+)."""
        resp = self._client.post("/sdk/evaluate/batch", json={"items": items})
        if resp.status_code != 200:
            raise _map_error(resp)
        return BatchResult.model_validate(resp.json())

    # --- informational ---

    def list_policies(self) -> List[PolicyInfo]:
        resp = self._client.get("/sdk/policies")
        if resp.status_code != 200:
            raise _map_error(resp)
        return [PolicyInfo.model_validate(p) for p in resp.json()]

    def get_policy(self, policy_id: str) -> PolicyInfo:
        resp = self._client.get(f"/sdk/policies/{policy_id}")
        if resp.status_code != 200:
            raise _map_error(resp)
        return PolicyInfo.model_validate(resp.json())

    def get_usage(self) -> UsageInfo:
        resp = self._client.get("/sdk/usage")
        if resp.status_code != 200:
            raise _map_error(resp)
        return UsageInfo.model_validate(resp.json())

    def list_instances(self) -> List[InstanceInfo]:
        resp = self._client.get("/sdk/instances")
        if resp.status_code != 200:
            raise _map_error(resp)
        return [InstanceInfo.model_validate(i) for i in resp.json()]

    def health(self) -> HealthInfo:
        resp = self._client.get("/sdk/health")
        if resp.status_code != 200:
            raise _map_error(resp)
        return HealthInfo.model_validate(resp.json())
