"""
Buddhi SDK — AI Guardrail Validation

Usage:
    from buddhi import RakshaClient

    client = RakshaClient(api_key="be_abc123...")
    result = client.validate("Can you share patient records?")
    print(result.decision)  # "BLOCK" or "CONTINUE"
"""

from buddhi.client import RakshaClient, AsyncRakshaClient
from buddhi.models import EvaluateResult, PolicyInfo, UsageInfo, HealthInfo
from buddhi.exceptions import (
    BuddhiError,
    AuthenticationError,
    QuotaExceededError,
    SubscriptionExpiredError,
    InstanceUnavailableError,
    PolicyNotFoundError,
    ServerError,
)

__version__ = "0.1.0"
__all__ = [
    "RakshaClient",
    "AsyncRakshaClient",
    "EvaluateResult",
    "PolicyInfo",
    "UsageInfo",
    "HealthInfo",
    "BuddhiError",
    "AuthenticationError",
    "QuotaExceededError",
    "SubscriptionExpiredError",
    "InstanceUnavailableError",
    "PolicyNotFoundError",
    "ServerError",
]
