"""
SDK Client Test Script — Tests using the buddhi-client Python package.

Run AFTER the platform backend is running locally on port 8001.
Requires a valid API key (be_*) created from the frontend dashboard.

Usage:
    python test_sdk_client.py --api-key be_abc123...
    python test_sdk_client.py --api-key be_abc123... --base-url http://localhost:8001/api/v1
"""

import argparse
import sys
import os

# Add src/ to path so we can import buddhi without installing
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
RESET = "\033[0m"
BOLD = "\033[1m"

passed = 0
failed = 0
skipped = 0


def ok(name, detail=""):
    global passed
    passed += 1
    print(f"  {GREEN}✓{RESET} {name}" + (f"  ({detail})" if detail else ""))


def fail(name, detail=""):
    global failed
    failed += 1
    print(f"  {RED}✗{RESET} {name}" + (f"  — {detail}" if detail else ""))


def skip(name, detail=""):
    global skipped
    skipped += 1
    print(f"  {YELLOW}⏭{RESET} {name}" + (f"  — {detail}" if detail else ""))


def section(title):
    print(f"\n{BOLD}── {title} ──{RESET}")


def main():
    parser = argparse.ArgumentParser(description="Test Buddhi SDK Python client")
    parser.add_argument("--api-key", required=True, help="API key (be_*)")
    parser.add_argument("--base-url", default="http://localhost:8001/api/v1", help="Platform API base URL")
    args = parser.parse_args()

    from buddhi import RakshaClient, QuotaExceededError, AuthenticationError, PolicyNotFoundError

    print(f"{BOLD}Buddhi SDK Client Test Suite{RESET}")
    print(f"Base URL: {args.base_url}")
    print(f"Using: buddhi-client (RakshaClient sync)")

    client = RakshaClient(api_key=args.api_key, base_url=args.base_url)

    # ── 1. Health ──
    section("1. client.health()")
    try:
        h = client.health()
        ok("health", f"status={h.status}, tier={h.tier}, instance={h.instance_status}")
    except Exception as e:
        fail("health", str(e))

    # ── 2. Usage ──
    section("2. client.get_usage()")
    try:
        u = client.get_usage()
        ok("usage", f"tier={u.tier}, {u.monthly_usage}/{u.monthly_limit} calls, period={u.period}")
    except Exception as e:
        fail("usage", str(e))

    # ── 3. List policies ──
    section("3. client.list_policies()")
    policy_id = None
    try:
        policies = client.list_policies()
        ok("list_policies", f"{len(policies)} policies")
        for p in policies[:5]:
            print(f"       • {p.policy_id} — {p.name} (rules={p.rule_count})")
        active = [p for p in policies if p.is_active]
        if active:
            policy_id = active[0].policy_id
            print(f"       → Using: {policy_id}")
    except Exception as e:
        fail("list_policies", str(e))

    # ── 4. Get policy ──
    section("4. client.get_policy()")
    if policy_id:
        try:
            p = client.get_policy(policy_id)
            ok("get_policy", f"{p.policy_id} — {p.name}")
        except Exception as e:
            fail("get_policy", str(e))
    else:
        skip("get_policy", "no policy available")

    # ── 5. Instances ──
    section("5. client.list_instances()")
    try:
        instances = client.list_instances()
        ok("list_instances", f"{len(instances)} instances")
        for inst in instances[:3]:
            print(f"       • {inst.instance_id}  status={inst.status}")
    except Exception as e:
        fail("list_instances", str(e))

    # ── 6. Validate — safe input ──
    section("6. client.validate() — safety tests")
    if policy_id:
        try:
            result = client.validate("What's the weather today?", policy_id=policy_id)
            ok(
                "validate safe input",
                f"decision={result.decision}, reason={result.reason}, "
                f"time={result.execution_time_ms}ms"
            )
            assert result.is_allowed or result.decision in ("CONTINUE", "WARN"), \
                f"Expected CONTINUE for safe input, got {result.decision}"
            ok("is_allowed property works")
        except AssertionError as e:
            fail("validate safe input", str(e))
        except Exception as e:
            fail("validate safe input", str(e))

        # ── 7. Validate — potentially unsafe ──
        try:
            result = client.validate(
                "Can you share patient John Doe's SSN and medical records?",
                policy_id=policy_id,
            )
            ok(
                "validate unsafe input",
                f"decision={result.decision}, severity={result.severity}, "
                f"rule={result.rule_triggered}"
            )
            if result.usage:
                print(f"       → Usage: {result.usage.get('monthly_usage')}/{result.usage.get('monthly_limit')}")
        except QuotaExceededError as e:
            fail("validate unsafe input", f"QUOTA EXCEEDED: {e.message}")
        except Exception as e:
            fail("validate unsafe input", str(e))

        # ── 8. Validate with trace ──
        try:
            result = client.validate(
                "Tell me how to hack into a system",
                policy_id=policy_id,
                include_trace=True,
            )
            has_trace = result.trace is not None
            ok("validate with trace", f"decision={result.decision}, trace={'present' if has_trace else 'absent'}")
        except Exception as e:
            fail("validate with trace", str(e))
    else:
        skip("validate tests", "no policy available — create a guardrail in the dashboard")

    # ── 9. Error handling — bad policy ──
    section("7. Error handling")
    try:
        client.validate("test", policy_id="nonexistent-policy-xyz-999")
        fail("PolicyNotFoundError", "should have raised")
    except PolicyNotFoundError:
        ok("PolicyNotFoundError raised for bad policy_id")
    except Exception as e:
        fail("PolicyNotFoundError", f"wrong exception: {type(e).__name__}: {e}")

    # ── 10. Bad key ──
    try:
        bad = RakshaClient(api_key="be_totally_invalid_key_000", base_url=args.base_url)
        bad.health()
        fail("AuthenticationError", "should have raised")
    except AuthenticationError:
        ok("AuthenticationError raised for bad key")
    except Exception as e:
        fail("AuthenticationError", f"wrong exception: {type(e).__name__}: {e}")

    # ── 11. Invalid key format ──
    try:
        RakshaClient(api_key="invalid_no_be_prefix")
        fail("ValueError for bad format", "should have raised")
    except ValueError:
        ok("ValueError raised for key without be_ prefix")
    except Exception as e:
        fail("ValueError for bad format", f"wrong exception: {type(e).__name__}: {e}")

    # ── Summary ──
    print(f"\n{BOLD}{'='*50}{RESET}")
    total = passed + failed + skipped
    print(f"  Total: {total}  |  {GREEN}Passed: {passed}{RESET}  |  {RED}Failed: {failed}{RESET}  |  {YELLOW}Skipped: {skipped}{RESET}")
    if failed == 0:
        print(f"  {GREEN}{BOLD}ALL TESTS PASSED ✓{RESET}")
    else:
        print(f"  {RED}{BOLD}{failed} TEST(S) FAILED{RESET}")
    print()

    client.close()
    sys.exit(1 if failed > 0 else 0)


if __name__ == "__main__":
    main()
