import json
import struct
import time
import threading
from pathlib import Path
from opensynaptic.utils import (
    get_registry_path,
    read_json,
    write_json,
    os_log,
    LogMsg,
    derive_session_key,
)

_RETRY = object()  # extract_fn 返回此哨兵表示"忽略本次响应，继续循环"

class CMD:
    DATA_FULL = 63
    DATA_FULL_SEC = 64
    DATA_DIFF = 170
    DATA_DIFF_SEC = 171
    DATA_HEART = 127
    DATA_HEART_SEC = 128
    ID_REQUEST = 1
    ID_ASSIGN = 2
    ID_POOL_REQ = 3
    ID_POOL_RES = 4
    HANDSHAKE_ACK = 5
    HANDSHAKE_NACK = 6
    PING = 9
    PONG = 10
    TIME_REQUEST = 11
    TIME_RESPONSE = 12
    SECURE_DICT_READY = 13
    SECURE_CHANNEL_ACK = 14
    DATA_CMDS = {DATA_FULL, DATA_FULL_SEC, DATA_DIFF, DATA_DIFF_SEC, DATA_HEART, DATA_HEART_SEC}
    PLAIN_DATA_CMDS = {DATA_FULL, DATA_DIFF, DATA_HEART}
    SECURE_DATA_CMDS = {DATA_FULL_SEC, DATA_DIFF_SEC, DATA_HEART_SEC}
    CTRL_CMDS = {ID_REQUEST, ID_ASSIGN, ID_POOL_REQ, ID_POOL_RES, HANDSHAKE_ACK, HANDSHAKE_NACK, PING, PONG, TIME_REQUEST, TIME_RESPONSE, SECURE_DICT_READY, SECURE_CHANNEL_ACK}
    BASE_DATA_CMD = {DATA_FULL_SEC: DATA_FULL, DATA_DIFF_SEC: DATA_DIFF, DATA_HEART_SEC: DATA_HEART}
    SECURE_DATA_CMD = {DATA_FULL: DATA_FULL_SEC, DATA_DIFF: DATA_DIFF_SEC, DATA_HEART: DATA_HEART_SEC}

class OSHandshakeManager:

    # 有效角色名及其允许处理的 CMD 集合
    # 'duplex' : 默认双向，无限制
    # 'tx_only': 仅发送 — 只处理自身发起的 CTRL 响应（ID_ASSIGN/ID_POOL_RES/TIME_RESPONSE/ACK/NACK/PONG/SECURE_*）
    # 不解析入向 DATA，不分配 ID，不回复不相关的 CTRL
    # 'rx_only': 仅接收 — 只处理入向 DATA 和服务端 CTRL（TIME_REQUEST/PING）
    # 不发起 ID_REQUEST/TIME_REQUEST，不再连接远端检测
    ROLE_TX_ONLY_CMDS = {
        CMD.ID_ASSIGN, CMD.ID_POOL_RES,
        CMD.HANDSHAKE_ACK, CMD.HANDSHAKE_NACK,
        CMD.PONG, CMD.TIME_RESPONSE,
        CMD.SECURE_DICT_READY, CMD.SECURE_CHANNEL_ACK,
    }
    ROLE_RX_ONLY_CMDS = (
        CMD.DATA_CMDS |
        {CMD.PING, CMD.TIME_REQUEST, CMD.HANDSHAKE_ACK, CMD.HANDSHAKE_NACK}
    )

    def __init__(self, target_sync_count=3, registry_dir=None, expire_seconds=86400, secure_store_path=None, device_role='duplex'):
        self.target_sync_count = target_sync_count
        self.registry_dir = registry_dir
        self.expire_seconds = expire_seconds
        self.registry_status = {}
        self.secure_sessions = {}
        self._lock = threading.Lock()
        self._seq_counter = 0
        self.id_allocator = None
        self.parser = None
        self.min_valid_timestamp = 1000000
        self.last_server_time = 0
        self.cleanup_interval = max(15, int(min(self.expire_seconds, 300)))
        self._last_cleanup = 0
        self.secure_store_path = secure_store_path or str(Path(self.registry_dir or '.') / 'secure_sessions.json')
        self._secure_dirty = False
        self._secure_last_persist = 0
        self._secure_persist_interval = 5
        # 角色：'duplex' | 'tx_only' | 'rx_only'
        _role = str(device_role or 'duplex').lower().strip()
        self.device_role = _role if _role in ('duplex', 'tx_only', 'rx_only') else 'duplex'
        self._load_secure_sessions()

    def _session_to_json(self, session):
        out = dict(session or {})
        key = out.get('key')
        pending_key = out.get('pending_key')
        out['key_hex'] = key.hex() if isinstance(key, (bytes, bytearray)) else out.get('key_hex')
        out['pending_key_hex'] = pending_key.hex() if isinstance(pending_key, (bytes, bytearray)) else out.get('pending_key_hex')
        out.pop('key', None)
        out.pop('pending_key', None)
        return out

    def _session_from_json(self, session):
        out = dict(session or {})
        key_hex = out.get('key_hex')
        pending_hex = out.get('pending_key_hex')
        try:
            out['key'] = bytes.fromhex(key_hex) if isinstance(key_hex, str) and key_hex else None
        except Exception:
            out['key'] = None
        try:
            out['pending_key'] = bytes.fromhex(pending_hex) if isinstance(pending_hex, str) and pending_hex else None
        except Exception:
            out['pending_key'] = None
        return out

    def _mark_secure_dirty(self):
        self._secure_dirty = True

    def _save_secure_sessions(self, force=False):
        if not self._secure_dirty and (not force):
            return
        now = int(time.time())
        if (not force) and (now - int(self._secure_last_persist or 0) < self._secure_persist_interval):
            return
        try:
            p = Path(self.secure_store_path)
            p.parent.mkdir(parents=True, exist_ok=True)
            with self._lock:
                payload = {
                    'updated_at': now,
                    'sessions': {k: self._session_to_json(v) for k, v in self.secure_sessions.items()},
                }
            write_json(str(p), payload, indent=2)
            self._secure_last_persist = now
            self._secure_dirty = False
        except Exception as e:
            os_log.err('HND', 'SECURE_SAVE', e, {'path': self.secure_store_path})

    def _load_secure_sessions(self):
        p = Path(self.secure_store_path)
        if not p.exists():
            return
        try:
            raw = read_json(str(p)) or {}
            sessions = raw.get('sessions', {}) if isinstance(raw.get('sessions', {}), dict) else {}
            with self._lock:
                for key, val in sessions.items():
                    self.secure_sessions[str(key)] = self._session_from_json(val)
        except Exception as e:
            os_log.err('HND', 'SECURE_LOAD', e, {'path': self.secure_store_path})

    def _default_secure_session(self):
        return {'last': int(time.time()), 'peer_addr': None, 'first_plaintext_ts': None, 'pending_timestamp': None, 'pending_key': None, 'pending_key_hex': None, 'key': None, 'key_hex': None, 'dict_ready': False, 'decrypt_confirmed': False, 'state': 'INIT'}

    def _get_secure_session(self, aid=None, addr=None, create=True):
        key, _ = self._normalize_aid(aid)
        if not key:
            return None
        self._cleanup_expired()
        _session_updated = False
        with self._lock:
            session = self.secure_sessions.get(key)
            if not session and create:
                session = self._default_secure_session()
                self.secure_sessions[key] = session
                self._mark_secure_dirty()
            if session:
                session['last'] = int(time.time())
                if addr:
                    session['peer_addr'] = str(addr)
                self._mark_secure_dirty()
                _session_updated = True
        # save outside the lock to avoid re-entrancy deadlock with threading.Lock
        if _session_updated:
            self._save_secure_sessions()
        return session

    def get_session_key(self, aid):
        session = self._get_secure_session(aid, create=False)
        if not session:
            return None
        return session.get('key')

    def has_secure_dict(self, aid):
        session = self._get_secure_session(aid, create=False)
        return bool(session and session.get('dict_ready'))

    def should_encrypt_outbound(self, aid):
        session = self._get_secure_session(aid, create=False)
        return bool(session and session.get('dict_ready') and session.get('key'))

    def note_local_plaintext_sent(self, aid, timestamp_raw, addr=None):
        session = self._get_secure_session(aid, addr=addr, create=True)
        if not session or session.get('key') or session.get('pending_key'):
            return session
        key = derive_session_key(int(aid), int(timestamp_raw or 0))
        session['pending_timestamp'] = int(timestamp_raw or 0)
        session['pending_key'] = key
        session['pending_key_hex'] = key.hex()
        session['state'] = 'PLAINTEXT_SENT'
        self._mark_secure_dirty()
        self._save_secure_sessions()
        return session

    def establish_remote_plaintext(self, aid, timestamp_raw, addr=None):
        session = self._get_secure_session(aid, addr=addr, create=True)
        if not session:
            return None
        ts_int = int(timestamp_raw or 0)
        if not session.get('key') and ts_int > self.min_valid_timestamp:
            key = derive_session_key(int(aid), ts_int)
            session['key'] = key
            session['key_hex'] = key.hex()
            session['first_plaintext_ts'] = ts_int
        session['dict_ready'] = True
        session['state'] = 'DICT_READY'
        self._mark_secure_dirty()
        self._save_secure_sessions()
        return session

    def confirm_secure_dict(self, aid, timestamp_raw=None, addr=None):
        session = self._get_secure_session(aid, addr=addr, create=True)
        if not session:
            return False
        if not session.get('key'):
            if session.get('pending_key'):
                session['key'] = session['pending_key']
                session['key_hex'] = session.get('pending_key_hex')
                session['first_plaintext_ts'] = int(session.get('pending_timestamp') or 0)
            elif timestamp_raw is not None:
                ts_c = int(timestamp_raw or 0)
                if ts_c > self.min_valid_timestamp:  # 与 establish_remote_plaintext 保持一致
                    key = derive_session_key(int(aid), ts_c)
                    session['key'] = key
                    session['key_hex'] = key.hex()
                    session['first_plaintext_ts'] = ts_c
        session['dict_ready'] = bool(session.get('key'))
        if session['dict_ready']:
            session['state'] = 'DICT_READY'
        self._mark_secure_dirty()
        self._save_secure_sessions()
        return session['dict_ready']

    def mark_secure_channel(self, aid, addr=None):
        session = self._get_secure_session(aid, addr=addr, create=True)
        if not session:
            return None
        session['decrypt_confirmed'] = True
        session['state'] = 'SECURE'
        self._mark_secure_dirty()
        self._save_secure_sessions()
        return session

    def note_server_time(self, server_time):
        try:
            t = int(server_time or 0)
            if t > self.min_valid_timestamp:
                self.last_server_time = t
        except Exception:
            pass

    def is_secure_data_cmd(self, cmd):
        return cmd in CMD.SECURE_DATA_CMDS

    def normalize_data_cmd(self, cmd):
        return CMD.BASE_DATA_CMD.get(cmd, cmd)

    def secure_variant_cmd(self, cmd):
        return CMD.SECURE_DATA_CMD.get(cmd, cmd)

    def classify_and_dispatch(self, packet, addr=None):
        if not packet or len(packet) < 1:
            return {'type': 'ERROR', 'cmd': 0, 'result': {'error': 'Empty packet'}, 'response': None}
        cmd = packet[0]
        # 角色过滤：不属于本角色允许范围的 CMD 直接丢弃
        if self.device_role == 'tx_only' and cmd in CMD.DATA_CMDS:
            return {'type': 'IGNORED', 'cmd': cmd, 'result': {'reason': 'tx_only: inbound DATA ignored'}, 'response': None}
        if self.device_role == 'tx_only' and cmd in CMD.CTRL_CMDS and cmd not in self.ROLE_TX_ONLY_CMDS:
            return {'type': 'IGNORED', 'cmd': cmd, 'result': {'reason': f'tx_only: CTRL 0x{cmd:02X} ignored'}, 'response': None}
        if self.device_role == 'rx_only' and cmd in CMD.CTRL_CMDS and cmd not in self.ROLE_RX_ONLY_CMDS:
            return {'type': 'IGNORED', 'cmd': cmd, 'result': {'reason': f'rx_only: CTRL 0x{cmd:02X} ignored'}, 'response': None}
        if cmd in CMD.DATA_CMDS:
            result = None
            response = None
            if self.parser:
                result = self.parser.decompress(packet)
            else:
                result = {'error': 'No parser attached', 'raw_hex': packet.hex()}
            meta = result.get('__packet_meta__', {}) if isinstance(result, dict) else {}
            src_aid = meta.get('source_aid')
            ts_raw = meta.get('timestamp_raw')
            is_secure = bool(meta.get('secure'))
            if meta.get('crc16_ok') is False:
                return {'type': 'DATA', 'cmd': cmd, 'result': result, 'response': None}
            if src_aid is not None and (not result.get('error')):
                if self.id_allocator:
                    try:
                        self.id_allocator.touch(int(src_aid), meta={'last_addr': str(addr) if addr else '', 'last_seen_from_data': int(time.time())})
                    except Exception:
                        pass
                if not is_secure:
                    session = self._get_secure_session(src_aid, addr=addr, create=False)
                    if not (session and session.get('dict_ready')):
                        self.establish_remote_plaintext(src_aid, ts_raw, addr=addr)
                        if meta.get('server_stamped'):
                            # RTC-less 设备：返回当前服务器时间，客户端收到后更新 last_server_time
                            # 避免与任何加密会话绑定（ts=0 未派生密鑰）
                            response = self._build_time_response(0, ts_raw)
                        else:
                            response = self._build_secure_dict_ready(src_aid, ts_raw)
                elif is_secure:
                    session = self._get_secure_session(src_aid, addr=addr, create=False)
                    if not (session and session.get('decrypt_confirmed')):
                        self.mark_secure_channel(src_aid, addr=addr)
                        response = self._build_secure_channel_ack(src_aid)
            return {'type': 'DATA', 'cmd': cmd, 'result': result, 'response': response}
        if cmd in CMD.CTRL_CMDS:
            return self._handle_ctrl(cmd, packet, addr)
        return {'type': 'UNKNOWN', 'cmd': cmd, 'result': {'error': f'Unknown command 0x{cmd:02X}'}, 'response': self._build_nack(reason=f'Unknown CMD 0x{cmd:02X}')}

    _CTRL_DISPATCH = {
        CMD.ID_REQUEST: '_on_id_request',
        CMD.ID_ASSIGN: '_on_id_assign',
        CMD.ID_POOL_REQ: '_on_id_pool_request',
        CMD.ID_POOL_RES: '_on_id_pool_response',
        CMD.HANDSHAKE_ACK: '_on_ack',
        CMD.HANDSHAKE_NACK: '_on_nack',
        CMD.PING: '_on_ping',
        CMD.PONG: '_on_pong',
        CMD.TIME_REQUEST: '_on_time_request',
        CMD.TIME_RESPONSE: '_on_time_response',
        CMD.SECURE_DICT_READY: '_on_secure_dict_ready',
        CMD.SECURE_CHANNEL_ACK: '_on_secure_channel_ack',
    }

    def _handle_ctrl(self, cmd, packet, addr):
        name = self._CTRL_DISPATCH.get(cmd)
        if name:
            return getattr(self, name)(packet, addr)
        return {'type': 'CTRL', 'cmd': cmd, 'result': {'error': 'Unhandled CTRL'}, 'response': None}

    def _on_id_request(self, packet, addr):
        seq = 0
        meta = {}
        try:
            if len(packet) >= 3:
                seq = struct.unpack('>H', packet[1:3])[0]
            if len(packet) > 3:
                meta_raw = packet[3:].decode('utf-8', errors='ignore')
                meta = json.loads(meta_raw) if meta_raw.strip() else {}
        except Exception as e:
            os_log.err('HND', 'PARSE', e, {'stage': 'id_request'})
        assigned_id = None
        if self.id_allocator:
            try:
                assigned_id = self.id_allocator.allocate_id(meta={'addr': str(addr) if addr else 'unknown', 'device_meta': meta, 'device_id': meta.get('device_id') if isinstance(meta, dict) else None, 'ts': int(time.time())})
            except RuntimeError:
                return {'type': 'CTRL', 'cmd': CMD.ID_REQUEST, 'result': {'status': 'REJECTED', 'reason': 'ID pool exhausted'}, 'response': self._build_nack(seq=seq, reason='ID_POOL_EXHAUSTED')}
        if assigned_id is not None:
            response = self._build_id_assign(seq, assigned_id, server_time=int(time.time()))
            os_log.log_with_const('info', LogMsg.ID_ASSIGNED, addr=addr, assigned=assigned_id)
            return {'type': 'CTRL', 'cmd': CMD.ID_REQUEST, 'result': {'status': 'ASSIGNED', 'assigned_id': assigned_id, 'addr': addr}, 'response': response}
        else:
            return {'type': 'CTRL', 'cmd': CMD.ID_REQUEST, 'result': {'status': 'REJECTED', 'reason': 'No allocator'}, 'response': self._build_nack(seq=seq, reason='NO_ALLOCATOR')}

    def _on_id_assign(self, packet, addr):
        seq = 0
        assigned_id = None
        server_time = None
        try:
            if len(packet) >= 3:
                seq = struct.unpack('>H', packet[1:3])[0]
            if len(packet) >= 7:
                assigned_id = struct.unpack('>I', packet[3:7])[0]
            if len(packet) >= 15:  # 可选的损带时间字段
                server_time = struct.unpack('>Q', packet[7:15])[0]
        except Exception as e:
            os_log.err('HND', 'PARSE', e, {'stage': 'id_assign'})
        if assigned_id is not None and assigned_id != 0:
            self.note_server_time(server_time)  # 损带时间可省去独立 TIME_REQUEST 往返
            ack = self._build_ack(seq)
            os_log.log_with_const('info', LogMsg.ID_RECEIVED, assigned=assigned_id)
            return {'type': 'CTRL', 'cmd': CMD.ID_ASSIGN, 'result': {'status': 'RECEIVED', 'assigned_id': assigned_id, 'seq': seq, 'server_time': server_time}, 'response': ack}
        else:
            return {'type': 'CTRL', 'cmd': CMD.ID_ASSIGN, 'result': {'status': 'INVALID', 'raw': packet.hex(), 'seq': seq}, 'response': self._build_nack(seq=seq, reason='INVALID_ID')}

    def _on_id_pool_request(self, packet, addr):
        seq = 0
        count = 1
        meta = {}
        try:
            if len(packet) >= 3:
                seq = struct.unpack('>H', packet[1:3])[0]
            if len(packet) >= 5:
                count = struct.unpack('>H', packet[3:5])[0]
            if len(packet) > 5:
                meta = json.loads(packet[5:].decode('utf-8', errors='ignore'))
        except Exception as e:
            os_log.err('HND', 'PARSE', e, {'stage': 'pool_req'})
        count = min(count, 256)
        pool = []
        if self.id_allocator:
            pool = self.id_allocator.allocate_pool(count, meta={'addr': str(addr) if addr else 'unknown', 'pool_request': True, 'ts': int(time.time())})
        if pool:
            response = self._build_id_pool_response(seq, pool)
            os_log.log_with_const('info', LogMsg.ID_POOL_ISSUED, addr=addr, count=len(pool))
            return {'type': 'CTRL', 'cmd': CMD.ID_POOL_REQ, 'result': {'status': 'POOL_ASSIGNED', 'pool': pool, 'count': len(pool)}, 'response': response}
        else:
            return {'type': 'CTRL', 'cmd': CMD.ID_POOL_REQ, 'result': {'status': 'REJECTED', 'reason': 'Cannot allocate pool'}, 'response': self._build_nack(seq=seq, reason='POOL_ALLOC_FAILED')}

    def _on_id_pool_response(self, packet, addr):
        seq = 0
        pool = []
        try:
            if len(packet) >= 3:
                seq = struct.unpack('>H', packet[1:3])[0]
            if len(packet) >= 5:
                count = struct.unpack('>H', packet[3:5])[0]
                offset = 5
                for _ in range(count):
                    if offset + 4 <= len(packet):
                        pool.append(struct.unpack('>I', packet[offset:offset + 4])[0])
                        offset += 4
        except Exception as e:
            os_log.err('HND', 'PARSE', e, {'stage': 'pool_res'})
        if pool:
            ack = self._build_ack(seq)
            os_log.log_with_const('info', LogMsg.ID_POOL_RECEIVED, count=len(pool), pool=pool)
            return {'type': 'CTRL', 'cmd': CMD.ID_POOL_RES, 'result': {'status': 'POOL_RECEIVED', 'pool': pool}, 'response': ack}
        return {'type': 'CTRL', 'cmd': CMD.ID_POOL_RES, 'result': {'status': 'EMPTY_POOL'}, 'response': None}

    def _on_ack(self, packet, addr):
        seq = struct.unpack('>H', packet[1:3])[0] if len(packet) >= 3 else 0
        return {'type': 'CTRL', 'cmd': CMD.HANDSHAKE_ACK, 'result': {'status': 'ACK_RECEIVED', 'seq': seq}, 'response': None}

    def _on_nack(self, packet, addr):
        seq = struct.unpack('>H', packet[1:3])[0] if len(packet) >= 3 else 0
        reason = ''
        if len(packet) > 3:
            reason = packet[3:].decode('utf-8', errors='ignore')
        return {'type': 'CTRL', 'cmd': CMD.HANDSHAKE_NACK, 'result': {'status': 'NACK_RECEIVED', 'seq': seq, 'reason': reason}, 'response': None}

    def _on_ping(self, packet, addr):
        seq = struct.unpack('>H', packet[1:3])[0] if len(packet) >= 3 else 0
        return {'type': 'CTRL', 'cmd': CMD.PING, 'result': {'status': 'PING', 'seq': seq}, 'response': self._build_pong(seq)}

    def _on_pong(self, packet, addr):
        seq = struct.unpack('>H', packet[1:3])[0] if len(packet) >= 3 else 0
        return {'type': 'CTRL', 'cmd': CMD.PONG, 'result': {'status': 'PONG', 'seq': seq}, 'response': None}

    def _on_time_request(self, packet, addr):
        seq = struct.unpack('>H', packet[1:3])[0] if len(packet) >= 3 else 0
        server_time = int(time.time())
        return {'type': 'CTRL', 'cmd': CMD.TIME_REQUEST, 'result': {'status': 'TIME_REQUEST', 'seq': seq, 'server_time': server_time}, 'response': self._build_time_response(seq, server_time)}

    def _on_time_response(self, packet, addr):
        seq = struct.unpack('>H', packet[1:3])[0] if len(packet) >= 3 else 0
        server_time = 0
        if len(packet) >= 11:
            server_time = struct.unpack('>Q', packet[3:11])[0]
        self.note_server_time(server_time)
        return {'type': 'CTRL', 'cmd': CMD.TIME_RESPONSE, 'result': {'status': 'TIME_RESPONSE', 'seq': seq, 'server_time': server_time}, 'response': None}

    def _on_secure_dict_ready(self, packet, addr):
        aid = 0
        timestamp_raw = None
        if len(packet) >= 5:
            aid = struct.unpack('>I', packet[1:5])[0]
        if len(packet) >= 13:
            timestamp_raw = struct.unpack('>Q', packet[5:13])[0]
        ready = self.confirm_secure_dict(aid, timestamp_raw=timestamp_raw, addr=addr)
        return {'type': 'CTRL', 'cmd': CMD.SECURE_DICT_READY, 'result': {'status': 'DICT_READY' if ready else 'DICT_PENDING', 'assigned_id': aid, 'timestamp_raw': timestamp_raw}, 'response': None}

    def _on_secure_channel_ack(self, packet, addr):
        aid = 0
        if len(packet) >= 5:
            aid = struct.unpack('>I', packet[1:5])[0]
        self.mark_secure_channel(aid, addr=addr)
        return {'type': 'CTRL', 'cmd': CMD.SECURE_CHANNEL_ACK, 'result': {'status': 'SECURE_CHANNEL_ACK', 'assigned_id': aid}, 'response': None}

    def _next_seq(self):
        with self._lock:
            self._seq_counter = self._seq_counter + 1 & 65535
            return self._seq_counter

    def build_id_request(self, device_meta=None):
        seq = self._next_seq()
        payload = json.dumps(device_meta or {}, ensure_ascii=False).encode('utf-8')
        return struct.pack('>BH', CMD.ID_REQUEST, seq) + payload

    def build_id_pool_request(self, count=10, meta=None):
        seq = self._next_seq()
        payload = json.dumps(meta or {}, ensure_ascii=False).encode('utf-8')
        return struct.pack('>BHH', CMD.ID_POOL_REQ, seq, count) + payload

    def build_ping(self):
        """Build a 0x09 PING packet."""
        seq = self._next_seq()
        return struct.pack('>BH', CMD.PING, seq)

    def build_time_request(self):
        seq = self._next_seq()
        return struct.pack('>BH', CMD.TIME_REQUEST, seq)

    def _build_id_assign(self, seq, assigned_id, server_time=None):
        # 格式：[CMD:1][seq:2][aid:4]  延伸字段（向后兼容，旧客户端只读前 7 字节）：
        #           [server_time:8]
        base = struct.pack('>BHI', CMD.ID_ASSIGN, seq, assigned_id)
        if server_time is not None:
            base += struct.pack('>Q', int(server_time))
        return base

    def _build_id_pool_response(self, seq, pool):
        header = struct.pack('>BHH', CMD.ID_POOL_RES, seq, len(pool))
        body = b''
        for pid in pool:
            body += struct.pack('>I', int(pid) & 0xFFFFFFFF)
        return header + body

    def _build_ack(self, seq=0):
        return struct.pack('>BH', CMD.HANDSHAKE_ACK, seq)

    def _build_nack(self, seq=0, reason=''):
        return struct.pack('>BH', CMD.HANDSHAKE_NACK, seq) + reason.encode('utf-8')

    def _build_pong(self, seq=0):
        return struct.pack('>BH', CMD.PONG, seq)

    def _build_time_response(self, seq=0, server_time=0):
        return struct.pack('>BHQ', CMD.TIME_RESPONSE, seq, int(server_time or 0))

    def _build_secure_dict_ready(self, assigned_id, timestamp_raw):
        return struct.pack('>BIQ', CMD.SECURE_DICT_READY, int(assigned_id or 0), int(timestamp_raw or 0))

    def _build_secure_channel_ack(self, assigned_id):
        return struct.pack('>BI', CMD.SECURE_CHANNEL_ACK, int(assigned_id or 0))

    def _normalize_aid(self, aid):
        if isinstance(aid, int):
            return (str(aid), aid)
        s = str(aid)
        if s.isdigit():
            return (s, int(s))
        return (s, None)

    def get_strategy(self, aid, has_template):
        self._cleanup_expired()
        key, int_val = self._normalize_aid(aid)
        with self._lock:
            if key not in self.registry_status:
                if self._check_persistence(aid) or has_template:
                    self.registry_status[key] = {'count': self.target_sync_count, 'last': int(time.time()), 'state': 'SYNCED'}
                else:
                    self.registry_status[key] = {'count': 0, 'last': int(time.time()), 'state': 'HANDSHAKING'}
            entry = self.registry_status[key]
        session = self._get_secure_session(aid, create=False)
        if has_template and session and session.get('dict_ready'):
            return 'DIFF_PACKET'
        if not has_template or entry['count'] < self.target_sync_count:
            return 'FULL_PACKET'
        return 'DIFF_PACKET'

    def commit_success(self, aid):
        key, _ = self._normalize_aid(aid)
        now = int(time.time())
        with self._lock:
            if key in self.registry_status:
                self.registry_status[key]['count'] += 1
                self.registry_status[key]['last'] = now
                if self.registry_status[key]['count'] >= self.target_sync_count:
                    self.registry_status[key]['state'] = 'SYNCED'
            else:
                self.registry_status[key] = {'count': 1, 'last': now, 'state': 'HANDSHAKING'}

    def _check_persistence(self, aid):
        key, int_val = self._normalize_aid(aid)
        if int_val is not None:
            path = get_registry_path(int_val)
            if path and read_json(path):
                return True
        path = get_registry_path(key)
        if path and read_json(path):
            return True
        return False

    def _cleanup_expired(self):
        now = int(time.time())
        if now - int(self._last_cleanup or 0) < self.cleanup_interval:
            return
        with self._lock:
            expired = [k for k, v in self.registry_status.items() if now - v.get('last', 0) > self.expire_seconds]
            for k in expired:
                del self.registry_status[k]
            expired_sessions = [k for k, v in self.secure_sessions.items() if now - v.get('last', 0) > self.expire_seconds]
            for k in expired_sessions:
                del self.secure_sessions[k]
                self._mark_secure_dirty()
            self._last_cleanup = now
        self._save_secure_sessions()

    def _run_transport_loop(self, req_packet, send_fn, recv_fn,
                            success_cmd, extract_fn, fail_default,
                            log_tag, timeout, nack_log=False):
        """发送/重发/接收公共骨架。extract_fn(result)->value，返回 _RETRY 则继续等待。"""
        start = time.time()
        last_send = start - timeout  # 触发循环内立即首次发送
        resend_interval = max(1.0, timeout / 2.0)
        while time.time() - start < timeout:
            now = time.time()
            remaining = timeout - (now - start)
            if now - last_send >= resend_interval:
                try:
                    send_fn(req_packet)
                    last_send = now
                except Exception as e:
                    os_log.err(log_tag, 'SEND_FAILED', e, {})
                    if now - start >= resend_interval:
                        return fail_default
            try:
                resp = recv_fn(timeout=min(0.5, remaining))
                if resp and len(resp) >= 1:
                    result = self.classify_and_dispatch(resp)
                    if result['cmd'] == success_cmd:
                        val = extract_fn(result)
                        if val is _RETRY:
                            continue
                        return val
                    if result['cmd'] == CMD.HANDSHAKE_NACK:
                        if nack_log:
                            os_log.err(log_tag, 'REJECTED', result['result'].get('reason'), {})
                        return fail_default
            except Exception as e:
                os_log.err(log_tag, 'RECV_FAILED', e, {})
                time.sleep(0.05)
        os_log.err(log_tag, f'TIMEOUT ({timeout}s)', None, {})
        return fail_default

    def request_id_via_transport(self, transport_send_fn, transport_recv_fn, device_meta=None, timeout=5.0):
        req_packet = self.build_id_request(device_meta)
        req_seq = struct.unpack('>H', req_packet[1:3])[0]
        def _extract(result):
            if result['result'].get('seq', req_seq) != req_seq:
                return _RETRY  # 延迟ID_ASSIGN，seq 不匹配，继续等待
            return result['result'].get('assigned_id')
        return self._run_transport_loop(
            req_packet, transport_send_fn, transport_recv_fn,
            CMD.ID_ASSIGN, _extract, None, 'ID_REQUEST', timeout, nack_log=True,
        )

    def request_id_pool_via_transport(self, transport_send_fn, transport_recv_fn, count=10, meta=None, timeout=5.0):
        req_packet = self.build_id_pool_request(count, meta)
        return self._run_transport_loop(
            req_packet, transport_send_fn, transport_recv_fn,
            CMD.ID_POOL_RES, lambda r: r['result'].get('pool', []), [], 'ID_POOL_REQUEST', timeout,
        )

    def request_time_via_transport(self, transport_send_fn, transport_recv_fn, timeout=3.0):
        req_packet = self.build_time_request()
        req_seq = struct.unpack('>H', req_packet[1:3])[0]
        def _extract(result):
            if result['result'].get('seq', req_seq) != req_seq:
                return _RETRY  # 旧超时响应，不更新时间
            return result['result'].get('server_time')
        return self._run_transport_loop(
            req_packet, transport_send_fn, transport_recv_fn,
            CMD.TIME_RESPONSE, _extract, None, 'TIME', timeout,
        )
