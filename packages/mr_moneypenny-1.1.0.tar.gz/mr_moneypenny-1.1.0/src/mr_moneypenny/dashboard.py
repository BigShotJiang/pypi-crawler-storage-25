"""Read-only HTTP dashboard for budget-bot.

Bound to 127.0.0.1 only. SQLite opened in read-only URI mode so the dashboard
literally cannot mutate data even if a query is malformed. The bot remains the
single write path.

Reuses src.config for config + envelope rules.
"""
from __future__ import annotations

import csv
import io
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Iterator
from zoneinfo import ZoneInfo

from flask import Flask, Response, abort, render_template, request

from . import paths
from .config import Config, load_config


# Templates and static assets live alongside the package code so they ship as
# wheel data when pip-installed.
PACKAGE_DIR = Path(__file__).parent
TEMPLATES_DIR = PACKAGE_DIR / "templates"
STATIC_DIR = PACKAGE_DIR / "static"


def create_app() -> Flask:
    app = Flask(
        __name__,
        template_folder=str(TEMPLATES_DIR),
        static_folder=str(STATIC_DIR),
    )

    @app.route("/")
    def index():
        cfg = load_config(paths.config_path())
        tz = ZoneInfo(cfg.timezone)

        start, end, is_current = _resolve_month(request.args.get("month"), tz)
        search = (request.args.get("q") or "").strip()

        # Pace and the daily cumulative chart both use variable categories only,
        # so fixed bumps (rent on the 1st) don't distort the picture.
        variable_cats = set(cfg.variable_categories())

        with _ro_conn() as conn:
            spent_by_cat = _spent_by_cat(conn, start, end)
            entries = _entries(conn, start, end, search, cfg)
            per_person = _per_person(conn, start, end, cfg)
            daily = _daily_cumulative(conn, start, end, tz, is_current,
                                      include_categories=variable_cats)
            available_months = _available_months(conn, tz)

        cat_status = _cat_status(cfg, spent_by_cat)
        total_spent = sum(spent_by_cat.values())
        days_in_month = (end - start).days

        variable_spent = sum(v for k, v in spent_by_cat.items() if k in variable_cats)
        variable_cap = cfg.variable_cap_cents()
        pace = _pace(start, end, variable_spent, variable_cap, tz) if is_current else None

        return render_template(
            "dashboard.html",
            cfg=cfg,
            month_label=start.strftime("%B %Y"),
            month_value=start.strftime("%Y-%m"),
            available_months=available_months,
            is_current=is_current,
            cat_status=cat_status,
            total_spent=total_spent,
            total_cap=cfg.total_cap_cents,
            variable_cap=variable_cap,
            days_in_month=days_in_month,
            pace=pace,
            entries=entries,
            search=search,
            per_person=per_person,
            daily=daily,
        )

    @app.route("/export.csv")
    def export_csv():
        cfg = load_config(paths.config_path())
        tz = ZoneInfo(cfg.timezone)
        start, end, _ = _resolve_month(request.args.get("month"), tz)
        with _ro_conn() as conn:
            entries = _entries(conn, start, end, search="", cfg=cfg)

        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(["id", "timestamp", "user", "amount_dollars", "category", "merchant", "raw_message"])
        for e in entries:
            writer.writerow([
                e["id"],
                e["timestamp"],
                e["user"],
                f"{e['amount_cents']/100:.2f}",
                e["category"],
                e["merchant"] or "",
                e["raw_message"],
            ])
        return Response(
            buf.getvalue(),
            mimetype="text/csv",
            headers={"Content-Disposition": f'attachment; filename=budget-{start.strftime("%Y-%m")}.csv'},
        )

    return app


# ---------- helpers ----------

def _resolve_month(month_arg: str | None, tz: ZoneInfo) -> tuple[datetime, datetime, bool]:
    """Return (start, end, is_current_month) for the YYYY-MM arg, defaulting to now."""
    now = datetime.now(tz)
    if month_arg:
        try:
            year, month = map(int, month_arg.split("-"))
            start = datetime(year, month, 1, tzinfo=tz)
        except ValueError:
            abort(400, "month must be in YYYY-MM format")
    else:
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    end = (start.replace(year=start.year + 1, month=1)
           if start.month == 12 else start.replace(month=start.month + 1))
    is_current = (start.year == now.year and start.month == now.month)
    return start, end, is_current


@contextmanager
def _ro_conn() -> Iterator[sqlite3.Connection]:
    conn = sqlite3.connect(f"file:{paths.db_path()}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def _spent_by_cat(conn: sqlite3.Connection, start: datetime, end: datetime) -> dict[str, int]:
    rows = conn.execute(
        """SELECT category, SUM(amount_cents) AS total
           FROM entries WHERE timestamp >= ? AND timestamp < ?
           GROUP BY category""",
        (start.isoformat(), end.isoformat()),
    ).fetchall()
    return {r["category"]: int(r["total"]) for r in rows}


def _entries(conn: sqlite3.Connection, start: datetime, end: datetime,
             search: str, cfg: Config) -> list[dict]:
    rows = conn.execute(
        """SELECT id, timestamp, user_id, amount_cents, category, merchant, raw_message
           FROM entries WHERE timestamp >= ? AND timestamp < ?
           ORDER BY timestamp DESC""",
        (start.isoformat(), end.isoformat()),
    ).fetchall()
    needle = search.lower()
    out = []
    for r in rows:
        e = dict(r)
        e["user"] = cfg.user_name(e["user_id"]) or f"uid:{e['user_id']}"
        if needle:
            hay = " ".join(str(e[k] or "") for k in ("merchant", "category", "raw_message", "user"))
            if needle not in hay.lower():
                continue
        out.append(e)
    return out


def _per_person(conn: sqlite3.Connection, start: datetime, end: datetime,
                cfg: Config) -> list[dict]:
    rows = conn.execute(
        """SELECT user_id, SUM(amount_cents) AS total, COUNT(*) AS count
           FROM entries WHERE timestamp >= ? AND timestamp < ?
           GROUP BY user_id""",
        (start.isoformat(), end.isoformat()),
    ).fetchall()
    return [
        {
            "name": cfg.user_name(r["user_id"]) or f"uid:{r['user_id']}",
            "total": int(r["total"]),
            "count": int(r["count"]),
        }
        for r in rows
    ]


def _daily_cumulative(conn: sqlite3.Connection, start: datetime, end: datetime,
                      tz: ZoneInfo, is_current: bool,
                      include_categories: set[str] | None = None) -> list[dict]:
    """Cumulative spend per day. Truncated to today for the current month so the
    chart doesn't show a flat line stretching into future days. If
    `include_categories` is given, only entries in that set are summed."""
    if include_categories is not None:
        if not include_categories:
            return []
        placeholders = ",".join("?" * len(include_categories))
        params = [start.isoformat(), end.isoformat(), *include_categories]
        rows = conn.execute(
            f"""SELECT timestamp, amount_cents FROM entries
                WHERE timestamp >= ? AND timestamp < ?
                  AND category IN ({placeholders})
                ORDER BY timestamp ASC""",
            params,
        ).fetchall()
    else:
        rows = conn.execute(
            """SELECT timestamp, amount_cents FROM entries
               WHERE timestamp >= ? AND timestamp < ?
               ORDER BY timestamp ASC""",
            (start.isoformat(), end.isoformat()),
        ).fetchall()
    by_day: dict[int, int] = {}
    for r in rows:
        ts = datetime.fromisoformat(r["timestamp"]).astimezone(tz)
        by_day[ts.day] = by_day.get(ts.day, 0) + int(r["amount_cents"])
    days_in_month = (end - start).days
    upper = min(datetime.now(tz).day, days_in_month) if is_current else days_in_month
    out = []
    cumulative = 0
    for d in range(1, upper + 1):
        cumulative += by_day.get(d, 0)
        out.append({"day": d, "cumulative_cents": cumulative})
    return out


def _available_months(conn: sqlite3.Connection, tz: ZoneInfo) -> list[str]:
    """YYYY-MM strings, descending. Always includes the current month."""
    rows = conn.execute(
        "SELECT DISTINCT substr(timestamp, 1, 7) AS m FROM entries"
    ).fetchall()
    months = {r["m"] for r in rows}
    months.add(datetime.now(tz).strftime("%Y-%m"))
    return sorted(months, reverse=True)


def _cat_status(cfg: Config, spent_by_cat: dict[str, int]) -> list[dict]:
    out = []
    for name in cfg.categories():
        cap = cfg.category_caps_cents[name]
        spent = spent_by_cat.get(name, 0)
        remaining = cap - spent
        pct = (spent / cap) if cap > 0 else 0.0
        if cfg.is_savings(name):
            # Hitting/exceeding the cap is the goal — never warn, just deepen.
            color = "deepgreen" if pct >= 0.95 else "green"
        elif pct < 0.70:
            color = "green"
        elif pct < 0.95:
            color = "yellow"
        else:
            color = "red"
        out.append({
            "name": name,
            "spent_cents": spent,
            "cap_cents": cap,
            "remaining_cents": remaining,
            "pct": pct,
            "color": color,
        })
    return out


def _pace(start: datetime, end: datetime, spent_cents: int,
          total_cap_cents: int, tz: ZoneInfo) -> dict:
    now = datetime.now(tz)
    day = now.day
    days_in_month = (end - start).days
    ideal_pct = day / days_in_month
    actual_pct = (spent_cents / total_cap_cents) if total_cap_cents else 0.0
    delta = actual_pct - ideal_pct
    if abs(delta) < 0.05:
        label = "on pace"
    elif delta < -0.10:
        label = "well under pace"
    elif delta < 0:
        label = "slightly under pace"
    elif delta < 0.10:
        label = "slightly over pace"
    else:
        label = "significantly over pace"
    return {
        "day": day,
        "days_in_month": days_in_month,
        "ideal_pct": ideal_pct,
        "actual_pct": actual_pct,
        "label": label,
    }


def main() -> None:
    paths.ensure_dirs()
    paths.migrate_from_legacy()
    app = create_app()
    port = int(os.environ.get("DASHBOARD_PORT", "8765"))
    app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
