"""Mr. Moneypenny entry point — relay mode (v0.7+).

Connects to the project relay over a WebSocket. The relay receives Telegram
webhooks centrally and forwards each user's updates to the bound local
instance. As of v0.7 outbound replies (sendMessage, getMe, etc.) also flow
through the relay over `tg_call` frames, so the bot token only ever lives
on the relay's secret store. Local installs no longer need
TELEGRAM_BOT_TOKEN.

Auth precedence:
  1. ~/.config/mr-moneypenny/identity.json (post-OAuth pairing) — single user.
  2. RELAY_TOKEN env var (legacy shared-secret mode) — accepts the
     telegram_ids listed in config.yaml.

Required env (in the OS-appropriate .env):
  ANTHROPIC_API_KEY    — your Anthropic key (or run with Ollama, future)
  RELAY_URL            — e.g. wss://mr-moneypenny-relay.fly.dev/ws
  RELAY_TOKEN          — only when identity.json is absent (legacy mode)
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import sys
from logging.handlers import RotatingFileHandler

from dotenv import load_dotenv
from telegram import Update
from telegram.ext import Application

from . import paths
from .bot import BudgetBot
from .config import ConfigError, load_config
from .db import DB
from .llm import LLMClient
from .relay_client import RelayClient, RelayClientError
from .relay_request import RelayRequest


# python-telegram-bot validates token format `<digits>:<rest>`. The bot's real
# id and username are populated from the relay-routed getMe call during
# Application.initialize(), so the placeholder here only has to parse.
_PLACEHOLDER_TOKEN = "1:relay-routes-everything"


def _resolve_relay_auth(log: logging.Logger, config) -> tuple[str, list[int], str]:
    """Pick the relay credential for this run.

    Returns (relay_token, bound_telegram_ids, mode_label).
      v2 identity.json    -> household token, bind owner+all members
      v1 identity.json    -> per-user token, single bind
      RELAY_TOKEN env var -> legacy shared mode, IDs from config.allowed_users
    """
    identity_file = paths.identity_path()
    if identity_file.exists():
        try:
            data = json.loads(identity_file.read_text())
        except Exception as e:
            log.error("identity.json unreadable (%s); move it aside or re-pair.", e)
            sys.exit(1)
        version = int(data.get("version", 1))
        try:
            if version == 2:
                token = str(data["relay_token"])
                ids = [int(data["owner"]["telegram_id"])]
                ids += [int(m["telegram_id"]) for m in data.get("members", [])]
                ids = sorted(set(ids))
                if not token or not ids:
                    raise ValueError("identity.json v2 missing relay_token or ids")
                mode = f"identity.json v2 (household, {len(ids)} member{'s' if len(ids) != 1 else ''})"
                return token, ids, mode
            if version == 1:
                owner = data["owner"]
                tid = int(owner["telegram_id"])
                token = str(owner["relay_token"])
                if not tid or not token:
                    raise ValueError("identity.json v1 has empty fields")
                return token, [tid], "identity.json v1"
            raise ValueError(f"unsupported identity.json version {version}")
        except Exception as e:
            log.error("identity.json malformed (%s); move it aside or re-pair.", e)
            sys.exit(1)

    relay_token = os.environ.get("RELAY_TOKEN", "").strip()
    if not relay_token or relay_token.startswith("paste"):
        log.error(
            "No identity.json and RELAY_TOKEN env var not set. Either run "
            "`mr-moneypenny pair` to pair via OAuth, or set RELAY_TOKEN in .env."
        )
        sys.exit(1)
    telegram_ids = [u.telegram_id for u in config.allowed_users if u.telegram_id > 0]
    if not telegram_ids:
        log.error(
            "Legacy-mode relay needs at least one telegram_id in config.yaml's "
            "allowed_users. Either fill one in or run `mr-moneypenny pair`."
        )
        sys.exit(1)
    return relay_token, telegram_ids, "legacy-shared-token"


def _setup_logging() -> None:
    paths.log_path().parent.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")

    file_handler = RotatingFileHandler(paths.log_path(), maxBytes=10_000_000, backupCount=5)
    file_handler.setFormatter(fmt)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(fmt)

    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(file_handler)
    root.addHandler(stream_handler)

    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.WARNING)
    logging.getLogger("websockets").setLevel(logging.WARNING)


async def _send_startup_notice(app: Application, bot: BudgetBot) -> None:
    log = logging.getLogger("startup")
    if bot.owner_user_id <= 0:
        return
    used = bot.db.distinct_categories()
    configured = set(bot.config.categories())
    orphans = sorted(used - configured)

    lines = ["Mr. Moneypenny is up (relay mode)."]
    if orphans:
        lines += [
            "",
            "Config drift: these categories appear in old entries but not in config.yaml:",
            *(f"  - {c}" for c in orphans),
            "",
            "To migrate, send: rename <old> to <new>  "
            "(the new category must exist in config.yaml first).",
        ]
    try:
        await app.bot.send_message(chat_id=bot.owner_user_id, text="\n".join(lines))
    except Exception:
        log.exception("failed to send startup notice")


async def _run() -> None:
    paths.ensure_dirs()
    paths.migrate_from_legacy()
    _setup_logging()
    log = logging.getLogger("main_relay")

    env_file = paths.env_path()
    if env_file.exists():
        load_dotenv(env_file)

    api_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    relay_url = os.environ.get("RELAY_URL", "").strip()
    for name, value in [("ANTHROPIC_API_KEY", api_key), ("RELAY_URL", relay_url)]:
        if not value or value.startswith("paste"):
            log.error("%s not set", name)
            sys.exit(1)

    config_file = paths.config_path()
    if not config_file.exists():
        log.error("Missing config.yaml at %s", config_file)
        sys.exit(1)
    try:
        config = load_config(config_file)
    except ConfigError as e:
        log.error("Config error: %s", e)
        sys.exit(2)

    db = DB(paths.db_path())
    llm = LLMClient(api_key=api_key, config=config)

    relay_token, telegram_ids, auth_mode = _resolve_relay_auth(log, config)
    owner_id = telegram_ids[0]
    bot = BudgetBot(config=config, db=db, llm=llm, owner_user_id=owner_id)

    log.info(
        "starting (relay mode, %s, outbound->relay) — categories=%d total_cap=$%.2f relay=%s ids=%s",
        auth_mode, len(config.categories()),
        config.total_cap_cents / 100, relay_url, telegram_ids,
    )

    # Lifecycle:
    # 1. Build relay client; start its run loop in the background.
    # 2. Wait until the WebSocket is bound (so getMe via tg_call succeeds).
    # 3. Build Application with RelayRequest pointed at the client.
    # 4. Initialize + start the app. Updates that arrive between steps 1 and 4
    #    block on app_ready until handlers are wired.
    app_ready = asyncio.Event()
    app_box: list[Application] = []

    async def on_update(update_dict: dict) -> None:
        await app_ready.wait()
        if not app_box:
            return
        application = app_box[0]
        upd = Update.de_json(update_dict, application.bot)
        if upd is not None:
            await application.process_update(upd)

    client = RelayClient(
        relay_url=relay_url,
        relay_token=relay_token,
        telegram_ids=telegram_ids,
        on_update=on_update,
    )

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, client.stop)

    runner_task = asyncio.create_task(client.run_forever(), name="relay_runner")
    try:
        await asyncio.wait_for(client.wait_connected(), timeout=30.0)
    except asyncio.TimeoutError:
        log.error("relay never connected within 30s")
        runner_task.cancel()
        sys.exit(3)
    except RelayClientError as e:
        log.error("relay handshake failed: %s", e)
        sys.exit(3)

    relay_request = RelayRequest(client)
    application: Application = (
        Application.builder()
        .token(_PLACEHOLDER_TOKEN)
        .request(relay_request)
        .get_updates_request(relay_request)
        .build()
    )
    application.bot_data["budget_bot"] = bot
    bot.install(application)
    app_box.append(application)

    try:
        await application.initialize()  # routes getMe through the relay
        await application.start()
        app_ready.set()
        await _send_startup_notice(application, bot)

        # Block on the WebSocket runner; SIGTERM → client.stop() → return.
        await runner_task
    except RelayClientError:
        sys.exit(3)
    finally:
        log.info("shutting down")
        try:
            await application.stop()
            await application.shutdown()
        except Exception:
            pass


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
