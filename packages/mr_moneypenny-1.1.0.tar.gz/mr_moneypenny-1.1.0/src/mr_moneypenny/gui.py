"""Native window wrapping the dashboard.

`mr-moneypenny gui` opens a borderless 1100x820 native window pointed at
http://127.0.0.1:8765/. If the dashboard isn't already running (systemd
service, manual launch, etc.), it gets spun up in a background thread for
the lifetime of the window.

Backend: pywebview, opt-in via `pip install mr-moneypenny[gui]`. Without
the extra, this module imports fine but `cmd_gui` fails with a clear
hint to install the extra.
"""
from __future__ import annotations

import logging
import os
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path


_DASHBOARD_HOST = "127.0.0.1"
_DASHBOARD_PORT = int(os.environ.get("DASHBOARD_PORT", "8765"))
_DASHBOARD_URL = f"http://{_DASHBOARD_HOST}:{_DASHBOARD_PORT}/"


def _dashboard_alive(timeout: float = 1.0) -> bool:
    try:
        urllib.request.urlopen(_DASHBOARD_URL, timeout=timeout).read(0)
        return True
    except (urllib.error.URLError, TimeoutError, OSError):
        return False


def _spawn_dashboard_thread(log: logging.Logger) -> None:
    """Start the Flask dashboard in a daemon thread so it dies with the GUI."""
    from .dashboard import create_app

    def runner() -> None:
        app = create_app()
        # use_reloader=False because we're inside a thread; debug=False
        # because this is end-user-facing; threaded=True so the dashboard
        # can serve favicon + chart.js + the page concurrently.
        app.run(
            host=_DASHBOARD_HOST, port=_DASHBOARD_PORT,
            debug=False, use_reloader=False, threaded=True,
        )

    log.info("starting embedded dashboard thread on %s", _DASHBOARD_URL)
    t = threading.Thread(target=runner, daemon=True, name="mr-moneypenny-dashboard")
    t.start()
    # Spin until the socket accepts a request, give up after 10s.
    deadline = time.time() + 10
    while time.time() < deadline:
        if _dashboard_alive(timeout=0.3):
            return
        time.sleep(0.1)
    raise RuntimeError("embedded dashboard didn't come up within 10s")


def _icon_path() -> Path | None:
    """Locate the bundled app icon (the polished circle-background variant)
    for the window/taskbar. Falls back to the silhouette logo if missing."""
    here = Path(__file__).parent / "static"
    for name in ("icon.png", "logo.png"):
        candidate = here / name
        if candidate.exists():
            return candidate
    return None


def open_window(*, title: str = "Mr. Moneypenny", width: int = 1100, height: int = 820) -> None:
    """Block until the user closes the window. Raises ImportError if pywebview
    isn't installed (i.e. the user didn't `pip install mr-moneypenny[gui]`)."""
    try:
        import webview
    except ImportError as e:
        raise ImportError(
            "GUI requires the optional `gui` extra. Install with:\n"
            "  pip install 'mr-moneypenny[gui]'\n"
            "(adds pywebview + PyQt6, which brings Qt + WebEngine)."
        ) from e

    log = logging.getLogger("gui")
    if not _dashboard_alive():
        _spawn_dashboard_thread(log)

    # Tell Qt our application name + class so Wayland/X11 window managers
    # associate the running window with the .desktop entry (matches
    # StartupWMClass=mr-moneypenny in the .desktop file). Must be set before
    # webview.start() instantiates QApplication.
    os.environ.setdefault("QT_WAYLAND_RECONNECT", "1")
    try:
        from PyQt6.QtCore import QCoreApplication
        from PyQt6.QtGui import QGuiApplication
        QCoreApplication.setApplicationName("Mr. Moneypenny")
        QCoreApplication.setOrganizationName("Mr. Moneypenny")
        QGuiApplication.setDesktopFileName("mr-moneypenny")
    except Exception:
        # PyQt6 is part of the [gui] extra; if missing, pywebview's import
        # above would already have failed. Still defensive.
        pass

    icon = _icon_path()
    log.info("opening native window -> %s (icon=%s)", _DASHBOARD_URL, icon or "default")
    webview.create_window(title, _DASHBOARD_URL, width=width, height=height,
                          min_size=(720, 480))
    if icon is not None:
        webview.start(icon=str(icon))
    else:
        webview.start()
    log.info("window closed")
