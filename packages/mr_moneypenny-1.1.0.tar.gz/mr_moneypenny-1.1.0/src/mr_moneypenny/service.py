"""Cross-platform service installer for mr-moneypenny.

Detects the current OS and writes the appropriate background-service config:
  Linux  -> systemd user unit at ~/.config/systemd/user/
  macOS  -> launchd plist at ~/Library/LaunchAgents/
  Windows-> manual instructions (Task Scheduler integration is v1.0+)

The bot and dashboard each get their own unit so they can be enabled/disabled
independently. Unit names match the legacy v0.6 conventions (`budget-bot`,
`budget-dashboard`) so existing Linux installs upgrade in place.

Pure logic — `install_for_current_platform()` is callable from a future GUI
without going through argparse.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from . import paths


@dataclass(frozen=True)
class ServiceUnit:
    """One installable service (the bot or the dashboard)."""
    key: str           # short id used in unit/plist names: "bot" | "dashboard"
    legacy_name: str   # "budget-bot" — the unit name we keep for backward compat
    label: str         # human-friendly description
    cli_args: tuple[str, ...]  # mr-moneypenny subcommand and its flags


BOT = ServiceUnit("bot", "budget-bot",
                  "Mr. Moneypenny — Telegram budget bot",
                  ("run",))
DASHBOARD = ServiceUnit("dashboard", "budget-dashboard",
                        "Mr. Moneypenny dashboard (read-only, localhost-only)",
                        ("dashboard",))
ALL_UNITS = (BOT, DASHBOARD)


def resolve_invocation() -> list[str]:
    """Return the command prefix that runs `mr-moneypenny` on this system.

    Tries `which mr-moneypenny` first (pip install on PATH), falls back to
    invoking the running interpreter via `python -m mr_moneypenny.cli`.
    """
    on_path = shutil.which("mr-moneypenny")
    if on_path:
        return [on_path]
    return [sys.executable, "-m", "mr_moneypenny.cli"]


# ============================================================
# Linux / systemd
# ============================================================

_SYSTEMD_TEMPLATE = """\
[Unit]
Description={label}
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={exec_start}
Restart=on-failure
RestartSec=10s
TimeoutStopSec=15s
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=default.target
"""


class SystemdInstaller:
    name = "systemd (Linux)"
    available_on = ("linux",)

    def __init__(self) -> None:
        self.unit_dir = Path.home() / ".config/systemd/user"

    @staticmethod
    def is_available() -> bool:
        return sys.platform == "linux" and bool(shutil.which("systemctl"))

    def unit_path(self, unit: ServiceUnit) -> Path:
        return self.unit_dir / f"{unit.legacy_name}.service"

    def install(self, units: list[ServiceUnit], *, enable: bool = True) -> list[Path]:
        self.unit_dir.mkdir(parents=True, exist_ok=True)
        invocation = resolve_invocation()
        written: list[Path] = []
        for u in units:
            args = invocation + list(u.cli_args)
            content = _SYSTEMD_TEMPLATE.format(
                label=u.label,
                exec_start=_systemd_quote(args),
            )
            path = self.unit_path(u)
            path.write_text(content)
            written.append(path)
        subprocess.run(["systemctl", "--user", "daemon-reload"], check=True)
        if enable:
            names = [u.legacy_name for u in units]
            subprocess.run(["systemctl", "--user", "enable", *names], check=True)
            # restart (not just start) so the change in unit content takes effect
            # when the service was already running with the previous file.
            subprocess.run(["systemctl", "--user", "restart", *names], check=True)
        return written

    def uninstall(self, units: list[ServiceUnit]) -> list[Path]:
        names = [u.legacy_name for u in units if self.unit_path(u).exists()]
        if names:
            subprocess.run(["systemctl", "--user", "disable", "--now", *names], check=False)
        removed: list[Path] = []
        for u in units:
            p = self.unit_path(u)
            if p.exists():
                p.unlink()
                removed.append(p)
        subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
        return removed

    def status(self, units: list[ServiceUnit]) -> dict[str, str]:
        out: dict[str, str] = {}
        for u in units:
            r = subprocess.run(
                ["systemctl", "--user", "is-active", u.legacy_name],
                capture_output=True, text=True,
            )
            out[u.key] = (r.stdout.strip() or "unknown")
        return out


# ============================================================
# macOS / launchd
# ============================================================

_LAUNCHD_TEMPLATE = """\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{label_id}</string>
    <key>ProgramArguments</key>
    <array>
{program_args}
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{stdout_path}</string>
    <key>StandardErrorPath</key>
    <string>{stderr_path}</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>{env_path}</string>
    </dict>
</dict>
</plist>
"""


class LaunchdInstaller:
    name = "launchd (macOS)"
    available_on = ("darwin",)

    def __init__(self) -> None:
        self.agent_dir = Path.home() / "Library" / "LaunchAgents"

    @staticmethod
    def is_available() -> bool:
        return sys.platform == "darwin" and bool(shutil.which("launchctl"))

    def label(self, unit: ServiceUnit) -> str:
        return f"net.mrmoneypenny.{unit.key}"

    def plist_path(self, unit: ServiceUnit) -> Path:
        return self.agent_dir / f"{self.label(unit)}.plist"

    def install(self, units: list[ServiceUnit], *, enable: bool = True) -> list[Path]:
        self.agent_dir.mkdir(parents=True, exist_ok=True)
        invocation = resolve_invocation()
        log_dir = paths.log_path().parent
        log_dir.mkdir(parents=True, exist_ok=True)

        written: list[Path] = []
        for u in units:
            args = invocation + list(u.cli_args)
            program_args = "\n".join(f"        <string>{_xml(a)}</string>" for a in args)
            stdout = log_dir / f"{u.key}.stdout.log"
            stderr = log_dir / f"{u.key}.stderr.log"
            content = _LAUNCHD_TEMPLATE.format(
                label_id=self.label(u),
                program_args=program_args,
                stdout_path=_xml(str(stdout)),
                stderr_path=_xml(str(stderr)),
                env_path=_xml(os.environ.get("PATH", "/usr/bin:/bin:/usr/local/bin")),
            )
            path = self.plist_path(u)
            path.write_text(content)
            written.append(path)

        if enable:
            for u in units:
                subprocess.run(["launchctl", "unload", str(self.plist_path(u))], check=False,
                               capture_output=True)
                subprocess.run(["launchctl", "load", "-w", str(self.plist_path(u))], check=True)
        return written

    def uninstall(self, units: list[ServiceUnit]) -> list[Path]:
        removed: list[Path] = []
        for u in units:
            p = self.plist_path(u)
            if p.exists():
                subprocess.run(["launchctl", "unload", str(p)], check=False, capture_output=True)
                p.unlink()
                removed.append(p)
        return removed

    def status(self, units: list[ServiceUnit]) -> dict[str, str]:
        out: dict[str, str] = {}
        for u in units:
            r = subprocess.run(
                ["launchctl", "list", self.label(u)],
                capture_output=True, text=True,
            )
            out[u.key] = "loaded" if r.returncode == 0 else "not loaded"
        return out


def _systemd_quote(args: list[str]) -> str:
    """Render a command list for systemd's ExecStart= line.

    systemd splits on whitespace unless arguments are double-quoted; embedded
    double quotes get escaped with backslash. Always quote so paths with
    spaces ('/home/.../Budget Project/...') survive intact.
    """
    out = []
    for a in args:
        out.append('"' + a.replace('\\', '\\\\').replace('"', '\\"') + '"')
    return " ".join(out)


_DESKTOP_TEMPLATE = """\
[Desktop Entry]
Type=Application
Name=Mr. Moneypenny
GenericName=Personal budget
Comment=Self-hosted Telegram budgeting assistant
Exec={exec_cmd}
Icon={icon_path}
Terminal=false
Categories=Office;Finance;
Keywords=budget;finance;money;telegram;
StartupNotify=true
StartupWMClass=mr-moneypenny
"""


def install_linux_launcher() -> Path:
    """Write ~/.local/share/applications/mr-moneypenny.desktop pointing at
    `mr-moneypenny gui` with the project logo as the icon. Refreshes the
    desktop database so KDE/GNOME pick it up immediately."""
    if sys.platform != "linux":
        raise NotInstallableError(
            f"install_linux_launcher only runs on Linux (sys.platform={sys.platform!r})"
        )
    apps_dir = Path.home() / ".local/share/applications"
    apps_dir.mkdir(parents=True, exist_ok=True)
    target = apps_dir / "mr-moneypenny.desktop"

    invocation = resolve_invocation() + ["gui"]
    exec_cmd = " ".join('"' + a + '"' if " " in a else a for a in invocation)

    # Icon install: write the polished circle-background icon to every
    # standard freedesktop hicolor size. Multi-size matters because Plasma
    # picks a size based on context (16 for systray, 48 for menu, 128/256
    # for Alt-Tab); without all of them, missing sizes fall back to a
    # generic "white sheet" placeholder. Sizes are pre-generated in
    # static/icon-{N}.png so we don't need Pillow as a runtime dep.
    try:
        from . import dashboard
        static = dashboard.STATIC_DIR
    except Exception:
        static = None

    icon_path = ""
    if static is not None:
        # Map shipped file -> hicolor directory size.
        installed = 0
        plan = [
            ("icon-16.png",  16),
            ("icon-48.png",  48),
            ("icon-128.png", 128),
            ("icon-256.png", 256),
            ("icon.png",     512),
        ]
        for filename, size in plan:
            src = static / filename
            if not src.exists():
                continue
            d = Path.home() / f".local/share/icons/hicolor/{size}x{size}/apps"
            d.mkdir(parents=True, exist_ok=True)
            (d / "mr-moneypenny.png").write_bytes(src.read_bytes())
            installed += 1
        if installed:
            icon_path = "mr-moneypenny"

    target.write_text(_DESKTOP_TEMPLATE.format(exec_cmd=exec_cmd, icon_path=icon_path))
    target.chmod(0o644)

    # Refresh the desktop database (kbuildsycoca6 for KDE 6, update-desktop-database for the freedesktop spec)
    for cmd in (["update-desktop-database", str(apps_dir)],
                ["kbuildsycoca6", "--noincremental"],
                ["gtk-update-icon-cache", "-q", str(Path.home() / ".local/share/icons/hicolor")]):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, check=False, capture_output=True)
    return target


def uninstall_linux_launcher() -> list[Path]:
    """Remove the .desktop file + every installed icon size."""
    removed: list[Path] = []
    target = Path.home() / ".local/share/applications/mr-moneypenny.desktop"
    if target.exists():
        target.unlink()
        removed.append(target)
    for size in (16, 48, 128, 256, 512):
        p = Path.home() / f".local/share/icons/hicolor/{size}x{size}/apps/mr-moneypenny.png"
        if p.exists():
            p.unlink()
            removed.append(p)
    apps_dir = Path.home() / ".local/share/applications"
    for cmd in (["update-desktop-database", str(apps_dir)],
                ["kbuildsycoca6", "--noincremental"],
                ["gtk-update-icon-cache", "-q",
                 str(Path.home() / ".local/share/icons/hicolor")]):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, check=False, capture_output=True)
    return removed


def _xml(s: str) -> str:
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
             .replace('"', "&quot;").replace("'", "&apos;"))


# ============================================================
# Windows / Task Scheduler  (v1.0+ — manual for now)
# ============================================================

class WindowsInstaller:
    name = "Windows Task Scheduler"
    available_on = ("win32",)

    @staticmethod
    def is_available() -> bool:
        return sys.platform == "win32"

    def install(self, units: list[ServiceUnit], *, enable: bool = True) -> list[Path]:
        invocation = resolve_invocation()
        cmd = " ".join('"' + a + '"' if " " in a else a for a in invocation)
        raise NotInstallableError(
            "Automatic Task Scheduler integration lands in v1.0. To run "
            "Mr. Moneypenny in the background today on Windows, run this "
            "manually in PowerShell (replace the path if you have it elsewhere):\n\n"
            "  $action = New-ScheduledTaskAction -Execute '" + invocation[0] + "' "
            f"-Argument '{' '.join(invocation[1:] + list(BOT.cli_args))}'\n"
            "  $trigger = New-ScheduledTaskTrigger -AtLogOn\n"
            "  Register-ScheduledTask -TaskName 'MrMoneypennyBot' "
            "-Action $action -Trigger $trigger\n\n"
            "Or just leave a terminal open with `mr-moneypenny run`."
        )

    def uninstall(self, units: list[ServiceUnit]) -> list[Path]:
        raise NotInstallableError(
            "On Windows, remove the scheduled task with: "
            "schtasks.exe /Delete /TN MrMoneypennyBot /F"
        )

    def status(self, units: list[ServiceUnit]) -> dict[str, str]:
        return {u.key: "n/a (manual on Windows)" for u in units}


class NotInstallableError(RuntimeError):
    """Raised when this platform's installer can't proceed without manual steps."""


# ============================================================
# Public factory
# ============================================================

def for_current_platform():
    if SystemdInstaller.is_available():
        return SystemdInstaller()
    if LaunchdInstaller.is_available():
        return LaunchdInstaller()
    if WindowsInstaller.is_available():
        return WindowsInstaller()
    raise NotInstallableError(
        f"unsupported platform: sys.platform={sys.platform!r}. "
        "Run `mr-moneypenny run` and `mr-moneypenny dashboard` manually."
    )
