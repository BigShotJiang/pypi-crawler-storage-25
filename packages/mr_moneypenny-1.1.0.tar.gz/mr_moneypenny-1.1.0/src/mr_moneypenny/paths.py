"""Cross-platform path resolution for Mr. Moneypenny.

All persistent state lives under platform-specific dirs:
  Linux:  ~/.config/mr-moneypenny/, ~/.local/share/mr-moneypenny/, ~/.cache/mr-moneypenny/log/
  macOS:  ~/Library/Application Support/mr-moneypenny/, ~/Library/Logs/mr-moneypenny/
  Win:    %APPDATA%\\mr-moneypenny\\, %LOCALAPPDATA%\\mr-moneypenny\\

migrate_from_legacy() handles the upgrade from the original PROJECT_DIR layout
where config.yaml, .env, budget.db, and logs/ all sat in the repo root. It runs
on every startup but is a no-op once the move has happened.
"""
from __future__ import annotations

import logging
import shutil
from pathlib import Path

from platformdirs import PlatformDirs


APP_NAME = "mr-moneypenny"
_dirs = PlatformDirs(APP_NAME, appauthor=False, roaming=False)


def config_dir() -> Path:
    return Path(_dirs.user_config_dir)


def data_dir() -> Path:
    return Path(_dirs.user_data_dir)


def log_dir() -> Path:
    return Path(_dirs.user_log_dir)


def config_path() -> Path:
    return config_dir() / "config.yaml"


def env_path() -> Path:
    return config_dir() / ".env"


def identity_path() -> Path:
    return config_dir() / "identity.json"


def db_path() -> Path:
    return data_dir() / "budget.db"


def log_path() -> Path:
    return log_dir() / "bot.log"


def ensure_dirs() -> None:
    for d in (config_dir(), data_dir(), log_dir()):
        d.mkdir(parents=True, exist_ok=True)


# ---- Legacy migration ----
# The original layout kept everything in the repo root. This block teaches
# Mr. Moneypenny to discover that layout once, move it under XDG, and never
# look back. Drop this whole section after every install has been migrated
# (target: v1.0).

# Anchored at the project root from src/mr_moneypenny/paths.py: parent is the
# package dir, parent.parent is `src/`, parent.parent.parent is the repo root
# where the original layout kept config.yaml/.env/budget.db/logs.
LEGACY_PROJECT_DIR = Path(__file__).parent.parent.parent


def _legacy_map() -> dict[Path, Path]:
    return {
        LEGACY_PROJECT_DIR / "config.yaml": config_path(),
        LEGACY_PROJECT_DIR / ".env":        env_path(),
        LEGACY_PROJECT_DIR / "budget.db":   db_path(),
    }


def migrate_from_legacy(*, log: logging.Logger | None = None) -> None:
    """Move files from PROJECT_DIR to XDG locations if they exist there.

    Idempotent. Per file: if legacy exists and destination doesn't, move.
    Otherwise leave both untouched. Logs are migrated as a directory.
    """
    log = log or logging.getLogger("paths.migrate")
    for legacy, dest in _legacy_map().items():
        if legacy.exists() and not dest.exists():
            dest.parent.mkdir(parents=True, exist_ok=True)
            log.info("migrating %s -> %s", legacy, dest)
            shutil.move(str(legacy), str(dest))

    legacy_logs = LEGACY_PROJECT_DIR / "logs"
    if legacy_logs.exists() and legacy_logs.is_dir():
        new_logs = log_dir()
        new_logs.mkdir(parents=True, exist_ok=True)
        for f in legacy_logs.iterdir():
            if not f.is_file():
                continue
            target = new_logs / f.name
            if target.exists():
                continue
            log.info("migrating log %s -> %s", f, target)
            shutil.move(str(f), str(target))
        try:
            legacy_logs.rmdir()
        except OSError:
            pass
