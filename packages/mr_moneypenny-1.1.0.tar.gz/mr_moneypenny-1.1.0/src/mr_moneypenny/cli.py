"""Mr. Moneypenny CLI.

Single entry point exposed by `[project.scripts]` in pyproject.toml. Pip-
installs of this package put a `mr-moneypenny` shell command on PATH that
dispatches to the subcommands below.

Subcommands
  init               Interactive first-run wizard.
  run                Start the bot in the foreground (relay mode).
  dashboard          Start the dashboard at 127.0.0.1:8765.
  gui                Open the dashboard in a native window (extras: gui).
  pair               Re-pair this device with Telegram (writes identity.json).
  invite             Mint a household-invite URL for another Telegram user.
  install-service    Install bot + dashboard as background services on this OS.
  uninstall-service  Remove the installed services.
  service-status     Show whether the installed services are running.
  version            Print the package version.

The wizard's heavy lifting lives in `init_flow.py` as pure functions so a
future GUI can call them directly; this module is the CLI shell.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
import webbrowser
from importlib import metadata
from pathlib import Path

from dotenv import load_dotenv

from . import init_flow, paths


def _v() -> str:
    try:
        return metadata.version("mr-moneypenny")
    except metadata.PackageNotFoundError:
        return "0.6.0-dev"


# ---------- subcommands ----------

def cmd_version(_args: argparse.Namespace) -> int:
    print(f"mr-moneypenny {_v()}")
    return 0


def cmd_run(_args: argparse.Namespace) -> int:
    from .main_relay import main as run_main
    run_main()
    return 0


def cmd_dashboard(_args: argparse.Namespace) -> int:
    from .dashboard import main as dash_main
    dash_main()
    return 0


def cmd_gui(_args: argparse.Namespace) -> int:
    """Open the dashboard inside a native window. Requires the `gui` extra."""
    from . import gui
    try:
        gui.open_window()
    except ImportError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    return 0


def _select_units(args: argparse.Namespace):
    from . import service
    if getattr(args, "bot_only", False):
        return [service.BOT]
    if getattr(args, "dashboard_only", False):
        return [service.DASHBOARD]
    return list(service.ALL_UNITS)


def cmd_install_service(args: argparse.Namespace) -> int:
    from . import service
    try:
        installer = service.for_current_platform()
    except service.NotInstallableError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    units = _select_units(args)
    print(f"Installing services via {installer.name}...")
    try:
        written = installer.install(units, enable=not args.no_enable)
    except service.NotInstallableError as e:
        print(str(e), file=sys.stderr)
        return 1
    except subprocess.CalledProcessError as e:
        print(f"error: command failed ({e.cmd!r}, exit {e.returncode})", file=sys.stderr)
        return 2
    for p in written:
        print(f"  wrote {p}")
    if not args.no_enable:
        print()
        statuses = installer.status(units)
        for k, v in statuses.items():
            print(f"  {k}: {v}")
    print()
    print("Done. Logs: journalctl --user -u budget-bot   (Linux)")
    print("           tail -f ~/Library/Logs/  or your log_dir              (macOS — see paths)")
    return 0


def cmd_uninstall_service(args: argparse.Namespace) -> int:
    from . import service
    try:
        installer = service.for_current_platform()
    except service.NotInstallableError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    units = _select_units(args)
    print(f"Removing services via {installer.name}...")
    try:
        removed = installer.uninstall(units)
    except service.NotInstallableError as e:
        print(str(e), file=sys.stderr)
        return 1
    for p in removed:
        print(f"  removed {p}")
    if not removed:
        print("  (nothing to remove)")
    return 0


def cmd_install_launcher(_args: argparse.Namespace) -> int:
    from . import service
    if sys.platform != "linux":
        print(f"error: --install-launcher is Linux-only (your platform: {sys.platform})",
              file=sys.stderr)
        return 1
    try:
        target = service.install_linux_launcher()
    except service.NotInstallableError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"  wrote {target}")
    print()
    print("Mr. Moneypenny should now appear in your application menu.")
    print("If it doesn't show right away, log out and back in once.")
    return 0


def cmd_uninstall_launcher(_args: argparse.Namespace) -> int:
    from . import service
    if sys.platform != "linux":
        print(f"error: --uninstall-launcher is Linux-only", file=sys.stderr)
        return 1
    removed = service.uninstall_linux_launcher()
    for p in removed:
        print(f"  removed {p}")
    if not removed:
        print("  (nothing to remove)")
    return 0


def cmd_service_status(args: argparse.Namespace) -> int:
    from . import service
    try:
        installer = service.for_current_platform()
    except service.NotInstallableError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    statuses = installer.status(_select_units(args))
    print(f"{installer.name}:")
    for k, v in statuses.items():
        print(f"  {k:<10} {v}")
    return 0


def _inv_args(a: argparse.Namespace) -> argparse.Namespace:
    """Reconcile positional `name` and --name flag into a single field."""
    if getattr(a, "name_flag", None):
        a.name = a.name_flag
    return a


def cmd_invite(args: argparse.Namespace) -> int:
    """Mint an invite URL for adding a household member."""
    paths.ensure_dirs()
    paths.migrate_from_legacy()

    if paths.env_path().exists():
        load_dotenv(paths.env_path())
    relay_url = os.environ.get("RELAY_URL", "").strip() or init_flow.DEFAULT_RELAY_WS_URL

    identity = init_flow.read_identity()
    if identity is None:
        print("error: no identity.json. Run `mr-moneypenny pair` (or `mr-moneypenny init`) first.",
              file=sys.stderr)
        return 1

    relay_token = identity["relay_token"]
    owner_label = identity["owner"]["name"] or "the owner"
    invitee_name = (args.name or "").strip()
    if not invitee_name:
        print("error: --name (or positional NAME) is required.", file=sys.stderr)
        return 2

    try:
        handle = init_flow.mint_invite(
            relay_token=relay_token,
            invitee_name=invitee_name,
            owner_label=owner_label,
            relay_ws_url=relay_url,
        )
    except init_flow.InitFlowError as e:
        print(f"error: {e}", file=sys.stderr)
        return 3

    print(f"Invite minted for '{invitee_name}'.")
    print(f"Send this URL to them — it expires in 1 hour:")
    print()
    print(f"  {handle.join_url}")
    print()
    print("Waiting for them to accept (Ctrl+C to give up — re-run to claim later).")

    last_status: str | None = None
    deadline = time.time() + (handle.expires_at - int(time.time()) if handle.expires_at else 3600)
    while time.time() < deadline:
        status, payload = init_flow.poll_invite_status(handle, relay_token=relay_token)
        if status == "joined":
            assert payload is not None
            joined = payload["joined"]
            new_token = payload["relay_token"]

            # Build the new members list = previous members + the new joiner.
            existing_members = list(identity.get("members", []))
            owner_id = int(identity["owner"]["telegram_id"])
            joined_id = int(joined["telegram_id"])
            if joined_id != owner_id and not any(int(m["telegram_id"]) == joined_id for m in existing_members):
                existing_members.append({"telegram_id": joined_id, "name": joined["name"]})

            target = init_flow.write_identity_v2(
                owner=identity["owner"],
                members=existing_members,
                relay_token=new_token,
            )
            print()
            print(f"{joined['name']} (telegram_id={joined_id}) joined.")
            print(f"Wrote {target}")
            print()
            print("Restart the bot to pick up the new household:")
            print("  systemctl --user restart budget-bot   # Linux")
            return 0
        if status == "expired":
            print("error: invite expired before anyone accepted. Re-run to mint a new one.",
                  file=sys.stderr)
            return 4
        if status == "not_found":
            print("error: invite no longer pending (already claimed?).", file=sys.stderr)
            return 4
        if status != last_status:
            last_status = status
        time.sleep(3)

    print("error: invite window expired waiting for accept.", file=sys.stderr)
    return 4


def cmd_pair(args: argparse.Namespace) -> int:
    from .pair import main as pair_main
    # pair.main() reads its own argv, so swap in flags it understands.
    saved = sys.argv
    try:
        sys.argv = [sys.argv[0]]
        if args.out is not None:
            sys.argv += ["--out", str(args.out)]
        pair_main()
    finally:
        sys.argv = saved
    return 0


def cmd_init(args: argparse.Namespace) -> int:
    """Interactive first-run wizard. CLI shell over init_flow."""
    if not sys.stdin.isatty():
        print(
            "error: `mr-moneypenny init` is interactive and needs a real terminal.\n"
            "       Open a regular terminal (Konsole, Terminal.app, etc.) and run it there.\n"
            "       If you are scripting setup, call mr_moneypenny.init_flow directly.",
            file=sys.stderr,
        )
        return 4

    print(f"Mr. Moneypenny — first-run setup ({_v()})")
    print()

    paths.ensure_dirs()
    state = init_flow.existing_state()
    overwrite = bool(args.force)

    if any(state.values()) and not overwrite:
        print("Existing configuration detected:")
        for k, v in state.items():
            print(f"  {k:<10} {'present' if v else 'missing'}")
        print()
        ans = input("Continue and overwrite? [y/N] ").strip().lower()
        if ans != "y":
            print("Aborted. Re-run with --force to skip this prompt.")
            return 1
        overwrite = True

    # Step 1: Anthropic key
    print("Step 1/3: Anthropic API key")
    print("  Sign up at https://console.anthropic.com/ if you don't have one.")
    print("  At typical use the bot costs ~$0.50–2/month.")
    key = input("  Paste your key (sk-ant-...): ").strip()
    if not key:
        print("error: no key entered.", file=sys.stderr)
        return 2
    print("  Verifying with Anthropic...")
    ok, msg = init_flow.verify_anthropic_key(key)
    print(f"  {msg}")
    if not ok:
        return 2

    # Step 2: Telegram pairing (browser flow)
    print()
    print("Step 2/3: Telegram identity")
    print("  A browser window will open. Tap 'Log in with Telegram'. That's it.")
    input("  Press Enter to continue. ")
    handle = init_flow.start_pairing()
    print(f"  Opening: {handle.connect_url}")
    try:
        webbrowser.open(handle.connect_url, new=2)
    except Exception:
        print("  (couldn't open the browser automatically — open the URL manually)")

    print("  Waiting for sign-in...", end="", flush=True)
    payload: dict | None = None
    deadline = time.time() + 300
    while time.time() < deadline:
        status, payload = init_flow.poll_pairing(handle)
        if status == "claimed":
            print(" done.")
            break
        if status == "expired":
            print(" expired.")
            print("error: pairing window closed. Re-run `mr-moneypenny init`.", file=sys.stderr)
            return 3
        print(".", end="", flush=True)
        time.sleep(2)
    else:
        print(" timed out.")
        print("error: pairing timed out. Re-run.", file=sys.stderr)
        return 3
    assert payload is not None

    identity_path = init_flow.write_identity(payload)
    print(f"  Paired as {payload['name']} (telegram_id={payload['telegram_id']})")
    print(f"  Wrote {identity_path}")

    # Step 3: Total cap → starter config
    print()
    print("Step 3/3: Budget setup")
    print("  Enter your monthly net pay. Mr. Moneypenny enforces zero-based")
    print("  budgeting — every dollar gets allocated to a category.")
    while True:
        raw = input("  Monthly net pay (e.g. 4000): ").strip()
        try:
            total_cents = init_flow.parse_total_cap(raw)
            break
        except init_flow.InitFlowError as e:
            print(f"  {e}")

    config_path = init_flow.write_starter_config(total_cents)
    env_path = init_flow.write_env(anthropic_key=key)
    print(f"  Wrote {config_path}")
    print(f"  Wrote {env_path}")

    # Closing message
    print()
    print("Setup complete. Optionally tune categories in:")
    print(f"  {config_path}")
    print("  (caps must sum to total_cap or the bot won't start).")
    print()
    print("Then run: mr-moneypenny run        (and in another terminal)")
    print("          mr-moneypenny dashboard")
    return 0


# ---------- entry ----------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="mr-moneypenny",
        description="Self-hosted Telegram budgeting assistant.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    p_init = sub.add_parser("init", help="Interactive first-run setup wizard.")
    p_init.add_argument("--force", action="store_true",
                        help="Overwrite existing config without prompting.")
    p_init.set_defaults(func=cmd_init)

    p_run = sub.add_parser("run", help="Start the bot (foreground, relay mode).")
    p_run.set_defaults(func=cmd_run)

    p_dash = sub.add_parser("dashboard", help="Start the dashboard at 127.0.0.1:8765.")
    p_dash.set_defaults(func=cmd_dashboard)

    p_gui = sub.add_parser(
        "gui",
        help="Open the dashboard in a native window (requires the `gui` extra).",
    )
    p_gui.set_defaults(func=cmd_gui)

    p_pair = sub.add_parser("pair", help="Re-pair this device with Telegram.")
    p_pair.add_argument("--out", type=Path, default=None,
                        help="Write identity.json here instead of the default location.")
    p_pair.set_defaults(func=cmd_pair)

    p_inv = sub.add_parser(
        "invite",
        help="Mint a household-invite URL for adding another Telegram user.",
    )
    p_inv.add_argument("name", nargs="?", default="",
                       help="Display name for the invitee (e.g. \"Vitoria\").")
    p_inv.add_argument("--name", dest="name_flag", default=None,
                       help="Alternative way to pass the invitee name.")
    p_inv.set_defaults(func=lambda a: cmd_invite(_inv_args(a)))

    def _add_unit_filters(parser: argparse.ArgumentParser) -> None:
        g = parser.add_mutually_exclusive_group()
        g.add_argument("--bot-only", action="store_true",
                       help="Only operate on the bot service (skip dashboard).")
        g.add_argument("--dashboard-only", action="store_true",
                       help="Only operate on the dashboard service (skip bot).")

    p_install = sub.add_parser("install-service",
                               help="Install bot + dashboard as background services.")
    _add_unit_filters(p_install)
    p_install.add_argument("--no-enable", action="store_true",
                           help="Write unit files but don't start/enable the services.")
    p_install.set_defaults(func=cmd_install_service)

    p_uninstall = sub.add_parser("uninstall-service",
                                 help="Remove the installed services.")
    _add_unit_filters(p_uninstall)
    p_uninstall.set_defaults(func=cmd_uninstall_service)

    p_status = sub.add_parser("service-status",
                              help="Show whether the installed services are running.")
    _add_unit_filters(p_status)
    p_status.set_defaults(func=cmd_service_status)

    p_inst_l = sub.add_parser("install-launcher",
                              help="(Linux) Add Mr. Moneypenny to your application menu.")
    p_inst_l.set_defaults(func=cmd_install_launcher)

    p_uninst_l = sub.add_parser("uninstall-launcher",
                                help="(Linux) Remove the menu entry.")
    p_uninst_l.set_defaults(func=cmd_uninstall_launcher)

    p_ver = sub.add_parser("version", help="Print package version.")
    p_ver.set_defaults(func=cmd_version)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args) or 0)


if __name__ == "__main__":
    sys.exit(main())
