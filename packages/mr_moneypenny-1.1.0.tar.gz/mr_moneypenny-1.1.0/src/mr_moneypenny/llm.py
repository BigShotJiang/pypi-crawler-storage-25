"""LLM wrappers and tool definitions.

Two paths, hard-routed by keyword:

- Action path (Haiku 4.5): logs expenses/refunds, deletes entries.
  Returns structured actions for bot.py to execute.

- Insights path (Sonnet 4.6): answers natural-language questions about
  spending vs caps. Returns plain text.

System prompts and tool definitions are marked with cache_control so they're
cached server-side; subsequent calls only pay full price for the user message.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

from anthropic import Anthropic

from .config import Config
from .db import Entry


HAIKU_MODEL = "claude-haiku-4-5-20251001"
SONNET_MODEL = "claude-sonnet-4-6"


# -------- Returned action types --------

@dataclass
class LogAction:
    type: Literal["log"] = "log"
    amount_cents: int = 0
    category: str = ""
    merchant: str | None = None
    is_refund: bool = False


@dataclass
class DeleteAction:
    type: Literal["delete"] = "delete"
    entry_id: int = 0


@dataclass
class TextReply:
    type: Literal["text"] = "text"
    message: str = ""


Action = LogAction | DeleteAction | TextReply


# -------- Routing --------

_INSIGHT_RE = re.compile(
    r"\bhow\s+much\b|\bhow\s+am\s+i\b|\bwhat'?s\s+left\b|\bwhat\s+have\s+i\b|"
    r"\bwhere\s+am\s+i\b|\bshow\b|\bsummary\b|\bstatus\b|\bremaining\b|"
    r"\bbudget\b|\bspent\b|\bhow\s+is\b|\?",
    re.IGNORECASE,
)


def looks_like_insight(message: str) -> bool:
    return bool(_INSIGHT_RE.search(message))


# -------- LLM client --------

class LLMClient:
    def __init__(self, api_key: str, config: Config) -> None:
        self.client = Anthropic(api_key=api_key)
        self.config = config

    # ---- Action path ----

    def parse_actions(
        self,
        message: str,
        today_entries: list[Entry],
        user_name: str,
    ) -> list[Action]:
        """Send the message to Haiku and turn its response into Actions."""
        ctx = self._format_today_block(today_entries)
        user_content = f"{ctx}\n\n<message from=\"{user_name}\">{message}</message>"

        response = self.client.messages.create(
            model=HAIKU_MODEL,
            max_tokens=1024,
            system=[
                {
                    "type": "text",
                    "text": self._action_system_prompt(),
                    "cache_control": {"type": "ephemeral"},
                },
            ],
            tools=self._action_tools(),
            messages=[{"role": "user", "content": user_content}],
        )

        actions: list[Action] = []
        text_parts: list[str] = []
        for block in response.content:
            if block.type == "tool_use":
                actions.append(self._tool_use_to_action(block.name, block.input))
            elif block.type == "text" and block.text.strip():
                text_parts.append(block.text)

        if not actions and text_parts:
            actions.append(TextReply(message=" ".join(text_parts).strip()))
        elif not actions:
            actions.append(TextReply(message="OK."))
        return actions

    # ---- Insights path ----

    def insight_reply(
        self,
        question: str,
        period_label: str,
        spending_by_cat_cents: dict[str, int],
        recent_entries: list[Entry],
    ) -> str:
        rows = []
        for name in self.config.categories():
            cap_c = self.config.category_caps_cents[name]
            spent_c = spending_by_cat_cents.get(name, 0)
            remaining_c = cap_c - spent_c
            tag = " [fixed]" if self.config.is_fixed(name) else ""
            rows.append(
                f"  {name}{tag}: spent ${spent_c/100:.2f} / cap ${cap_c/100:.2f} / "
                f"remaining ${remaining_c/100:.2f}"
            )
        cats_block = "\n".join(rows)
        entries_block = self._format_entries_with_ids(recent_entries)

        user_content = (
            f"Period: {period_label}\n\n"
            f"Category status (envelope budget — every dollar allocated):\n{cats_block}\n\n"
            f"Recent entries (newest first):\n{entries_block}\n\n"
            f"User question: {question}"
        )

        response = self.client.messages.create(
            model=SONNET_MODEL,
            max_tokens=1024,
            system=[
                {
                    "type": "text",
                    "text": self._insight_system_prompt(),
                    "cache_control": {"type": "ephemeral"},
                },
            ],
            messages=[{"role": "user", "content": user_content}],
        )
        return "".join(b.text for b in response.content if b.type == "text").strip()

    # ---- Prompts ----

    def _action_system_prompt(self) -> str:
        cats = "\n".join(f"  - {name}" for name in self.config.categories())
        fallback = self.config.fallback_category()
        fallback_rule = (
            f'- If a purchase doesn\'t fit any specific category, use "{fallback}"\n'
            f"  as the catch-all. Don't shoehorn into a poor-fit category just to\n"
            f"  avoid it.\n"
        ) if fallback else ""
        return f"""You are a budget-tracking assistant. The user sends short messages
about purchases (or refunds) and occasionally asks to delete a recent entry.
Your job is to call the right tool for what they said.

VALID CATEGORIES (must pick one of these for every log_entry call):
{cats}

RULES:
- Every spend message MUST be logged via log_entry.
- A single message with ONE dollar amount + description is ONE entry, even
  if it contains commas. "$20, claude API credits" is ONE entry: $20.00 in
  the catch-all category (since "claude API credits" doesn't fit anywhere
  specific). Do NOT split on commas.
- A message contains MULTIPLE entries ONLY when it has multiple distinct
  dollar amounts (e.g. "$5 coffee, $10 lunch" → two entries).
- If the message uses words like "refund", "refunded", "return", "returned",
  set is_refund=true. Pass amount_cents as a positive integer; the flag
  carries the sign.
- If a message has no parseable dollar amount at all (e.g. "lunch at chipotle"),
  DO NOT log a guess. Reply in plain text asking the user for the amount.
- For deletion requests, you'll be given today's entries with IDs in the
  context. Pick the right ID and call delete_entry. If unclear which one,
  reply asking for clarification.
- **NEVER ask the user "which category should this be?" or "where should I
  log this?".** You pick the category yourself, every time. The user has
  explicitly asked for fire-and-forget logging — asking back is a bug.
- For ambiguous categorization (e.g. "$40 Target" — could be Groceries,
  Personal Care, or Clothing), pick your best guess silently.
- Common synonyms (always apply):
    - "gas" or "gasoline" -> **Fuel**  (NOT any heating/utility category)
{fallback_rule}- Amounts are USD. Pass amount_cents as integer cents (e.g. $12.50 -> 1250).
- Merchant is the place/vendor if mentioned (e.g. "Chipotle", "Target"),
  null otherwise.
"""

    def _insight_system_prompt(self) -> str:
        return """You are a budget-tracking assistant for a single household running an
envelope-style monthly budget. The user is asking about their spending.
Reply briefly in plain text (chat replies, not paragraphs).

GUIDELINES:
- Lead with REMAINING budget, not amount spent (envelope mindset).
- All amounts USD, formatted with two decimals.
- The current calendar month resets on the 1st. Use the period given.
- Show entry IDs (e.g. #42) when listing entries so the user can delete by ID.
- Refunds appear as negative amounts in the data — reflect them as such.
- If the user asks "how am I doing", give a one-line per-category summary
  for the categories that have any spending, plus a one-line overall take.
- Categories tagged [fixed] (e.g. Rent, Electric, Savings/Investments) are
  auto-paid and predictable. **NEVER frame them as "ahead/behind pace"** —
  rent on the 1st isn't a pacing issue, it's just rent. When the user asks
  about pace or "how am I doing this month" overall, calculate based on
  variable (non-[fixed]) categories only.
"""

    # ---- Tools ----

    def _action_tools(self) -> list[dict]:
        return [
            {
                "name": "log_entry",
                "description": "Log a spend or refund entry to the budget.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "amount_cents": {
                            "type": "integer",
                            "description": "Positive integer cents. e.g. $12.50 -> 1250.",
                        },
                        "category": {
                            "type": "string",
                            "enum": self.config.categories(),
                            "description": "Must be one of the listed categories.",
                        },
                        "merchant": {
                            "type": ["string", "null"],
                            "description": "Vendor/place if mentioned, else null.",
                        },
                        "is_refund": {
                            "type": "boolean",
                            "description": "True iff the user said refund/return.",
                            "default": False,
                        },
                    },
                    "required": ["amount_cents", "category"],
                },
            },
            {
                "name": "delete_entry",
                "description": "Delete a logged entry by its ID. Use only when an ID is identifiable from context.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "entry_id": {"type": "integer"},
                    },
                    "required": ["entry_id"],
                },
                "cache_control": {"type": "ephemeral"},
            },
        ]

    # ---- Formatting helpers ----

    def _format_today_block(self, entries: list[Entry]) -> str:
        if not entries:
            return "<today_entries>(none yet today)</today_entries>"
        lines = []
        for e in entries:
            sign = "-" if e.amount_cents < 0 else ""
            amt = abs(e.amount_cents) / 100
            t = e.timestamp.strftime("%I:%M%p")
            who = self.config.user_name(e.user_id) or f"uid:{e.user_id}"
            merch = f" {e.merchant}" if e.merchant else ""
            lines.append(f"  #{e.id} {t}: {sign}${amt:.2f} {e.category}{merch} ({who})")
        return "<today_entries>\n" + "\n".join(lines) + "\n</today_entries>"

    def _format_entries_with_ids(self, entries: list[Entry]) -> str:
        if not entries:
            return "  (none)"
        lines = []
        for e in reversed(entries):
            sign = "-" if e.amount_cents < 0 else ""
            amt = abs(e.amount_cents) / 100
            t = e.timestamp.strftime("%m/%d %I:%M%p")
            who = self.config.user_name(e.user_id) or f"uid:{e.user_id}"
            merch = f" {e.merchant}" if e.merchant else ""
            lines.append(f"  #{e.id} {t}: {sign}${amt:.2f} {e.category}{merch} ({who})")
        return "\n".join(lines)

    def _tool_use_to_action(self, name: str, input_data: dict) -> Action:
        if name == "log_entry":
            return LogAction(
                amount_cents=int(input_data["amount_cents"]),
                category=str(input_data["category"]),
                merchant=(input_data.get("merchant") or None),
                is_refund=bool(input_data.get("is_refund", False)),
            )
        if name == "delete_entry":
            return DeleteAction(entry_id=int(input_data["entry_id"]))
        return TextReply(message=f"(internal: unknown tool {name})")
