"""python-telegram-bot BaseRequest that funnels API calls through the relay.

Replaces the default HTTPXRequest. Every Bot API call (sendMessage, getMe,
etc.) becomes a `tg_call` over the existing WebSocket; the relay holds the
real bot token and makes the actual HTTPS call to api.telegram.org.

Result: the local install no longer needs TELEGRAM_BOT_TOKEN. The token
only ever lives on the relay's Fly secret store. New users skip the
@BotFather walkthrough entirely.

Limitation (v0.7): file uploads (multipart) are not routed. Mr.
Moneypenny only sends text replies, so this hasn't bitten anything; if a
future feature needs sendPhoto/sendDocument, extend the protocol.
"""
from __future__ import annotations

import json
import logging

from telegram.request import BaseRequest, RequestData

from .relay_client import RelayCallError, RelayClient


class RelayRequest(BaseRequest):
    def __init__(self, relay_client: RelayClient, *, log: logging.Logger | None = None,
                 read_timeout: float | None = 30.0) -> None:
        super().__init__()
        self._relay = relay_client
        self._read_timeout = read_timeout
        self.log = log or logging.getLogger("relay_request")

    @property
    def read_timeout(self) -> float | None:
        return self._read_timeout

    async def initialize(self) -> None:
        # The relay client's run_forever() owns the WebSocket lifecycle; we
        # just block until it's connected so the first tg_call (typically
        # getMe during Application.initialize) doesn't race the handshake.
        await self._relay.wait_connected()

    async def shutdown(self) -> None:
        # The relay client is shut down separately from main_relay.
        return

    async def do_request(
        self,
        url: str,
        method: str,
        request_data: RequestData | None = None,
        read_timeout=None,
        write_timeout=None,
        connect_timeout=None,
        pool_timeout=None,
    ) -> tuple[int, bytes]:
        api_method = url.rsplit("/", 1)[-1]
        if request_data is not None and request_data.multipart_data:
            body = b'{"ok":false,"error_code":501,"description":"file uploads not yet supported via the relay"}'
            return 501, body

        params = dict(request_data.parameters) if request_data is not None else {}

        try:
            await self._relay.wait_connected(timeout=10.0)
        except Exception as e:
            return 502, json.dumps({
                "ok": False, "error_code": 502,
                "description": f"relay not ready: {type(e).__name__}",
            }).encode()

        try:
            result = await self._relay.tg_call(api_method, **params)
            return 200, json.dumps(result).encode()
        except RelayCallError as e:
            body = json.dumps({"ok": False, "error_code": e.error_code, "description": e.description}).encode()
            return e.error_code or 500, body
        except Exception as e:
            self.log.exception("tg_call failed for %s", api_method)
            body = json.dumps({
                "ok": False, "error_code": 500,
                "description": f"relay client error: {type(e).__name__}: {e}",
            }).encode()
            return 500, body
