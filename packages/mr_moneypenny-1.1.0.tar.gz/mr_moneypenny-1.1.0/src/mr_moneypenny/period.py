"""Calendar-month and day-bound helpers, anchored to a configured timezone.

All bounds are returned as `(start, end)` tuples where `end` is exclusive,
suitable for `WHERE timestamp >= start AND timestamp < end` queries.
"""
from __future__ import annotations

from datetime import datetime, timedelta
from zoneinfo import ZoneInfo


def _zone(tz: str) -> ZoneInfo:
    return ZoneInfo(tz)


def now(tz: str) -> datetime:
    return datetime.now(_zone(tz))


def current_month_bounds(tz: str, ref: datetime | None = None) -> tuple[datetime, datetime]:
    z = _zone(tz)
    n = (ref or datetime.now(z)).astimezone(z)
    start = n.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    end = start.replace(year=start.year + 1, month=1) if start.month == 12 \
        else start.replace(month=start.month + 1)
    return start, end


def today_bounds(tz: str, ref: datetime | None = None) -> tuple[datetime, datetime]:
    z = _zone(tz)
    n = (ref or datetime.now(z)).astimezone(z)
    start = n.replace(hour=0, minute=0, second=0, microsecond=0)
    return start, start + timedelta(days=1)


def yesterday_bounds(tz: str, ref: datetime | None = None) -> tuple[datetime, datetime]:
    today_start, _ = today_bounds(tz, ref)
    return today_start - timedelta(days=1), today_start


def last_n_days_bounds(tz: str, n: int, ref: datetime | None = None) -> tuple[datetime, datetime]:
    """Inclusive-of-today window: covers the last n calendar days."""
    if n < 1:
        raise ValueError("n must be >= 1")
    today_start, today_end = today_bounds(tz, ref)
    return today_start - timedelta(days=n - 1), today_end
