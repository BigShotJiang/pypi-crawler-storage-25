"""Schema migrations for budget.db.

Each migration is a small function that mutates the schema (adds a column,
creates a new table, backfills data). The runner uses SQLite's built-in
PRAGMA user_version to track which migrations have run, so there's no
external migration table to maintain.

To add a new migration:
  1. Write a function that does the change. Idempotent if you can manage it.
  2. Append `(N, your_function)` to the _MIGRATIONS list. N must be the
     next integer in sequence.
  3. Don't edit older migrations — once shipped they are immutable. If the
     change is wrong, write a new migration that corrects it.

The runner is invoked from `DB.__init__` so every bot/dashboard start checks
and applies anything pending.
"""
from __future__ import annotations

import logging
import sqlite3
from typing import Callable


def _migration_001_initial(conn: sqlite3.Connection) -> None:
    """v1: entries table + indexes. Idempotent so existing DBs are no-ops."""
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS entries (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp    TEXT    NOT NULL,
            user_id      INTEGER NOT NULL,
            amount_cents INTEGER NOT NULL,
            category     TEXT    NOT NULL,
            merchant     TEXT,
            raw_message  TEXT    NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_entries_timestamp ON entries(timestamp);
        CREATE INDEX IF NOT EXISTS idx_entries_user_id ON entries(user_id);
        """
    )


# Ordered list. The integer is the user_version the DB will hold *after* the
# migration runs. Always strictly increasing, contiguous from 1.
_MIGRATIONS: list[tuple[int, Callable[[sqlite3.Connection], None]]] = [
    (1, _migration_001_initial),
]


CURRENT_SCHEMA_VERSION: int = max(v for v, _ in _MIGRATIONS)


def run_migrations(conn: sqlite3.Connection, *, log: logging.Logger | None = None) -> int:
    """Apply any pending migrations to `conn`. Returns the post-run version.

    Safe to call on every startup: if user_version already matches the latest,
    this is a no-op pragma read.
    """
    log = log or logging.getLogger("migrations")
    current = int(conn.execute("PRAGMA user_version").fetchone()[0])
    if current == CURRENT_SCHEMA_VERSION:
        return current
    if current > CURRENT_SCHEMA_VERSION:
        log.warning(
            "DB user_version=%d is ahead of code's CURRENT_SCHEMA_VERSION=%d. "
            "You're probably running an old version of Mr. Moneypenny against a "
            "newer DB. Upgrade the code or restore an older DB snapshot.",
            current, CURRENT_SCHEMA_VERSION,
        )
        return current
    for version, migrate in _MIGRATIONS:
        if version <= current:
            continue
        log.info("applying schema migration -> v%d", version)
        migrate(conn)
        # PRAGMA user_version doesn't accept parameter binding; inline an int.
        conn.execute(f"PRAGMA user_version = {int(version)}")
    return CURRENT_SCHEMA_VERSION
