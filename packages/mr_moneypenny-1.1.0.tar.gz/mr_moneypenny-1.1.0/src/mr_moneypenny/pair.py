"""Mr. Moneypenny pairing CLI.

Run as: `uv run python -m src.pair`

Generates a fresh pairing code, opens the browser to the relay's /connect
page, and polls /pair/{code} until the user signs in via the Telegram
Login Widget. Writes the resulting per-user token + telegram_id to
~/.config/mr-moneypenny/identity.json.

After pairing, src.main_relay reads identity.json and uses the per-user
token instead of the legacy shared RELAY_TOKEN env var.

Flags:
  --out PATH   Write identity.json to PATH instead of the default location.
               Useful for testing without touching a working config.
"""
from __future__ import annotations

import argparse
import json
import os
import secrets
import sys
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

from dotenv import load_dotenv

from . import paths


def _https_base_from_ws(ws_url: str) -> str:
    """ wss://host[:port]/ws  ->  https://host[:port]
        ws://host[:port]/ws   ->  http://host[:port]
    Anything else: raise.
    """
    if ws_url.startswith("wss://"):
        scheme = "https://"
        rest = ws_url[len("wss://"):]
    elif ws_url.startswith("ws://"):
        scheme = "http://"
        rest = ws_url[len("ws://"):]
    else:
        raise ValueError(f"RELAY_URL must start with ws:// or wss://, got {ws_url!r}")
    host = rest.split("/", 1)[0]
    return f"{scheme}{host}"


def _poll_once(base_url: str, code: str) -> tuple[str, dict | None]:
    """One claim attempt. Returns:
      ("claimed", payload) — pairing complete
      ("not_yet", None)    — keep polling
      ("expired", None)    — pairing window closed; user must restart
      ("error",   None)    — transient error; retry next tick
    """
    try:
        req = urllib.request.Request(f"{base_url}/pair/{code}", method="GET")
        with urllib.request.urlopen(req, timeout=10) as r:
            if r.status == 200:
                return "claimed", json.loads(r.read())
            return "not_yet", None
    except urllib.error.HTTPError as e:
        if e.code == 410:
            return "expired", None
        return "error", None
    except (urllib.error.URLError, TimeoutError, OSError):
        return "error", None


def _write_identity(payload: dict[str, object], target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    body = {
        "version": 1,
        "owner": {
            "telegram_id": int(payload["telegram_id"]),  # type: ignore[arg-type]
            "name": str(payload.get("name") or f"user_{payload['telegram_id']}"),
            "relay_token": str(payload["relay_token"]),
        },
    }
    target.write_text(json.dumps(body, indent=2) + "\n")
    try:
        os.chmod(target, 0o600)
    except OSError:
        # On Windows chmod is a partial no-op; that's fine.
        pass


def main() -> None:
    parser = argparse.ArgumentParser(description="Pair this device with Mr. Moneypenny via Telegram OAuth.")
    parser.add_argument(
        "--out",
        type=Path,
        default=None,
        help="Write identity.json here instead of the default ~/.config/mr-moneypenny/identity.json",
    )
    args = parser.parse_args()
    out_path: Path = args.out or paths.identity_path()

    paths.ensure_dirs()
    paths.migrate_from_legacy()
    if paths.env_path().exists():
        load_dotenv(paths.env_path())

    relay_ws = os.environ.get("RELAY_URL", "").strip()
    if not relay_ws:
        print("error: RELAY_URL not set in ~/.config/mr-moneypenny/.env", file=sys.stderr)
        print("       e.g. RELAY_URL=wss://mr-moneypenny-relay.fly.dev/ws", file=sys.stderr)
        sys.exit(1)

    try:
        base = _https_base_from_ws(relay_ws)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(1)

    code = secrets.token_urlsafe(12)
    connect_url = f"{base}/connect?pairing_code={code}"

    print(f"Opening browser to: {connect_url}")
    print("Sign in with Telegram in the browser. This terminal will pick up the pairing automatically.")
    print()

    try:
        webbrowser.open(connect_url, new=2)
    except Exception:
        # webbrowser failures are fine; user can copy the URL.
        pass

    deadline = time.time() + 300  # 5 min (matches relay's _PAIRING_TTL)
    last_status = "not_yet"
    while time.time() < deadline:
        status, payload = _poll_once(base, code)
        if status == "claimed":
            assert payload is not None
            _write_identity(payload, out_path)
            print(f"Paired as {payload.get('name')} (telegram_id={payload.get('telegram_id')})")
            print(f"Wrote {out_path}")
            if out_path == paths.identity_path():
                print()
                print("Restart the bot to pick up the new identity:")
                print("  systemctl --user restart budget-bot")
            return
        if status == "expired":
            print("error: pairing window expired before sign-in completed. Re-run this command.",
                  file=sys.stderr)
            sys.exit(2)
        if status != last_status:
            last_status = status
        time.sleep(2)

    print("error: pairing timed out after 5 minutes.", file=sys.stderr)
    sys.exit(2)


if __name__ == "__main__":
    main()
