"""budget-bot entry point.

Loads .env + config.yaml, initializes DB + LLM client, starts Telegram polling.
On startup, telegram-messages the owner with a "bot is up" notice plus any
config-drift warnings (orphan categories in DB that no longer match config).
"""
from __future__ import annotations

import logging
import os
import sys
from logging.handlers import RotatingFileHandler

from dotenv import load_dotenv
from telegram.ext import Application

from . import paths
from .bot import BudgetBot
from .config import ConfigError, load_config
from .db import DB
from .llm import LLMClient


def _setup_logging() -> None:
    paths.log_path().parent.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")

    file_handler = RotatingFileHandler(paths.log_path(), maxBytes=10_000_000, backupCount=5)
    file_handler.setFormatter(fmt)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(fmt)

    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(file_handler)
    root.addHandler(stream_handler)

    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.WARNING)


async def _post_init(app: Application) -> None:
    log = logging.getLogger("startup")
    bot: BudgetBot = app.bot_data["budget_bot"]
    owner_id = bot.owner_user_id

    if owner_id <= 0:
        log.warning(
            "No real telegram_id configured. Messages will be dropped until "
            "you message the bot, find your ID in this log, and update config.yaml."
        )
        return

    used = bot.db.distinct_categories()
    configured = set(bot.config.categories())
    orphans = sorted(used - configured)

    lines = ["Mr. Moneypenny is up."]
    if orphans:
        lines.append("")
        lines.append("Config drift: these categories appear in old entries but not in config.yaml:")
        for c in orphans:
            lines.append(f"  - {c}")
        lines.append("")
        lines.append(
            "To migrate, send: rename <old> to <new>  "
            "(the new category must exist in config.yaml first)."
        )

    try:
        await app.bot.send_message(chat_id=owner_id, text="\n".join(lines))
    except Exception:
        log.exception("failed to send startup notice to owner")


def main() -> None:
    paths.ensure_dirs()
    paths.migrate_from_legacy()
    _setup_logging()
    log = logging.getLogger("main")

    env_file = paths.env_path()
    config_file = paths.config_path()

    if not env_file.exists():
        log.error("Missing .env at %s — copy .env.example and fill it in.", env_file)
        sys.exit(1)
    load_dotenv(env_file)

    tg_token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
    api_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not tg_token or tg_token.startswith("paste"):
        log.error("TELEGRAM_BOT_TOKEN not set in .env")
        sys.exit(1)
    if not api_key or api_key.startswith("paste"):
        log.error("ANTHROPIC_API_KEY not set in .env")
        sys.exit(1)

    if not config_file.exists():
        log.error("Missing config.yaml at %s — copy config.example.yaml and edit.", config_file)
        sys.exit(1)
    try:
        config = load_config(config_file)
    except ConfigError as e:
        log.error("Config error: %s", e)
        sys.exit(2)

    db = DB(paths.db_path())
    llm = LLMClient(api_key=api_key, config=config)

    owner_id = next((u.telegram_id for u in config.allowed_users if u.telegram_id > 0), 0)
    bot = BudgetBot(config=config, db=db, llm=llm, owner_user_id=owner_id)

    log.info(
        "starting bot — categories=%d total_cap=$%.2f tz=%s users=%s",
        len(config.categories()),
        config.total_cap_cents / 100,
        config.timezone,
        [(u.name, u.telegram_id) for u in config.allowed_users],
    )
    if not config.has_real_users():
        log.warning(
            "BOOTSTRAP: no real telegram_id in config.yaml yet. Message the bot once "
            "and your ID will appear in this log."
        )

    app = Application.builder().token(tg_token).post_init(_post_init).build()
    app.bot_data["budget_bot"] = bot
    bot.install(app)
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
