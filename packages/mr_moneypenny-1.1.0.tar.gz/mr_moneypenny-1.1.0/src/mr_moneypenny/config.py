"""Config loader for budget-bot.

Validates the YAML at load time and enforces the envelope invariant:
sum of category caps must equal total_cap (down to the cent). Money is
parsed into integer cents internally to avoid float drift.

Editing the config and restarting the bot is the only refinement workflow.
The validator's job is to refuse to start with an inconsistent config so
budget discipline is enforced mechanically rather than by good intentions.

`config_version` is the schema version of config.yaml itself. It defaults
to 1 if absent so existing installs keep working. Future config-shape
changes will bump this and bring a corresponding migration path.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import yaml


CURRENT_CONFIG_VERSION: int = 1


@dataclass(frozen=True)
class AllowedUser:
    telegram_id: int
    name: str


@dataclass(frozen=True)
class Config:
    config_version: int
    total_cap_cents: int
    timezone: str
    allowed_users: tuple[AllowedUser, ...]
    category_caps_cents: dict[str, int]
    fixed_categories: tuple[str, ...]
    savings_categories: tuple[str, ...]

    def categories(self) -> list[str]:
        return list(self.category_caps_cents.keys())

    def variable_categories(self) -> list[str]:
        fixed = set(self.fixed_categories)
        return [c for c in self.category_caps_cents if c not in fixed]

    def variable_cap_cents(self) -> int:
        return sum(self.category_caps_cents[c] for c in self.variable_categories())

    def is_fixed(self, category: str) -> bool:
        return category in self.fixed_categories

    def is_savings(self, category: str) -> bool:
        return category in self.savings_categories

    def is_user_allowed(self, telegram_id: int) -> bool:
        return any(u.telegram_id == telegram_id for u in self.allowed_users if u.telegram_id > 0)

    def user_name(self, telegram_id: int) -> str | None:
        for u in self.allowed_users:
            if u.telegram_id == telegram_id and u.telegram_id > 0:
                return u.name
        return None

    def has_real_users(self) -> bool:
        return any(u.telegram_id > 0 for u in self.allowed_users)

    def fallback_category(self) -> str | None:
        """Name of the catch-all category (Miscellaneous/Misc), or None if none configured."""
        for c in self.category_caps_cents:
            if c.lower() in {"miscellaneous", "misc"}:
                return c
        return None


class ConfigError(ValueError):
    """Raised when config.yaml is malformed or violates an invariant."""


def _to_cents(value: object) -> int:
    """Convert a dollar amount (any reasonable form) to integer cents."""
    d = Decimal(str(value))
    cents = (d * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return int(cents)


def load_config(path: str | Path) -> Config:
    p = Path(path)
    if not p.exists():
        raise ConfigError(f"Config file not found: {p}")

    raw = yaml.safe_load(p.read_text())
    if not isinstance(raw, dict):
        raise ConfigError("Config root must be a YAML mapping")

    config_version = raw.get("config_version", 1)
    if not isinstance(config_version, int) or config_version < 1:
        raise ConfigError(f"'config_version' must be a positive integer, got {config_version!r}")
    if config_version > CURRENT_CONFIG_VERSION:
        raise ConfigError(
            f"config_version {config_version} is newer than this version of "
            f"Mr. Moneypenny supports (max {CURRENT_CONFIG_VERSION}). "
            f"Upgrade the package."
        )

    if "total_cap" not in raw:
        raise ConfigError("Missing 'total_cap' at root")
    total_cap_cents = _to_cents(raw["total_cap"])
    if total_cap_cents <= 0:
        raise ConfigError(f"total_cap must be positive, got {raw['total_cap']}")

    timezone = raw.get("timezone", "America/New_York")
    if not isinstance(timezone, str):
        raise ConfigError("'timezone' must be a string")

    raw_users = raw.get("allowed_users")
    if not isinstance(raw_users, list) or not raw_users:
        raise ConfigError("'allowed_users' must be a non-empty list")
    users: list[AllowedUser] = []
    for i, u in enumerate(raw_users):
        if not isinstance(u, dict):
            raise ConfigError(f"allowed_users[{i}] must be a mapping")
        tid = u.get("telegram_id")
        name = u.get("name", f"User{i}")
        if not isinstance(tid, int):
            raise ConfigError(f"allowed_users[{i}].telegram_id must be an integer (use 0 as placeholder)")
        users.append(AllowedUser(telegram_id=tid, name=str(name)))

    raw_cats = raw.get("categories")
    if not isinstance(raw_cats, dict) or not raw_cats:
        raise ConfigError("'categories' must be a non-empty mapping")

    category_caps_cents: dict[str, int] = {}
    for name, cap in raw_cats.items():
        if not isinstance(name, str) or not name.strip():
            raise ConfigError(f"Category name must be a non-empty string, got {name!r}")
        try:
            cents = _to_cents(cap)
        except Exception as e:
            raise ConfigError(f"Category '{name}' has invalid cap {cap!r}: {e}")
        if cents < 0:
            raise ConfigError(f"Category '{name}' has negative cap {cap}")
        category_caps_cents[name] = cents

    sum_cents = sum(category_caps_cents.values())
    if sum_cents != total_cap_cents:
        diff = (Decimal(sum_cents) - Decimal(total_cap_cents)) / 100
        raise ConfigError(
            f"Category caps sum to ${sum_cents/100:.2f} but total_cap is "
            f"${total_cap_cents/100:.2f} (off by ${abs(diff):.2f}). "
            f"Every dollar must be allocated — adjust caps to match."
        )

    def _parse_category_list(key: str) -> list[str]:
        raw_list = raw.get(key, [])
        if not isinstance(raw_list, list):
            raise ConfigError(f"'{key}' must be a list of category names")
        out: list[str] = []
        for name in raw_list:
            if not isinstance(name, str):
                raise ConfigError(f"{key} contains a non-string: {name!r}")
            if name not in category_caps_cents:
                raise ConfigError(
                    f"{key} references '{name}' which is not a defined category. "
                    f"Add it to categories or remove it from {key}."
                )
            out.append(name)
        return out

    fixed = _parse_category_list("fixed_categories")
    savings = _parse_category_list("savings_categories")

    return Config(
        config_version=config_version,
        total_cap_cents=total_cap_cents,
        timezone=timezone,
        allowed_users=tuple(users),
        category_caps_cents=category_caps_cents,
        fixed_categories=tuple(fixed),
        savings_categories=tuple(savings),
    )
