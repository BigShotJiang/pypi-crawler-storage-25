"""Telegram message handlers.

The whitelist gate runs before any LLM call so unauthorized users never
trigger paid API traffic. Logging is fire-and-forget; deletion is too.
The single message handler routes between the insight path (Sonnet) and the
action path (Haiku). A small "rename X to Y" intent is handled directly,
without an LLM call, since it's destructive and well-defined.
"""
from __future__ import annotations

import logging
import re

from telegram import Update
from telegram.ext import Application, ContextTypes, MessageHandler, filters

from .config import Config
from .db import DB
from .llm import (
    Action,
    DeleteAction,
    LLMClient,
    LogAction,
    TextReply,
    looks_like_insight,
)
from .period import (
    current_month_bounds,
    last_n_days_bounds,
    now,
    today_bounds,
    yesterday_bounds,
)


log = logging.getLogger(__name__)

_RENAME_RE = re.compile(r"^\s*rename\s+(.+?)\s+to\s+(.+?)\s*$", re.IGNORECASE)


class BudgetBot:
    def __init__(
        self,
        config: Config,
        db: DB,
        llm: LLMClient,
        owner_user_id: int,
    ) -> None:
        self.config = config
        self.db = db
        self.llm = llm
        self.owner_user_id = owner_user_id  # used for error notifications

    def install(self, app: Application) -> None:
        app.add_handler(
            MessageHandler(
                filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE,
                self._on_message,
            )
        )

    async def _on_message(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None or update.effective_user is None:
            return
        uid = update.effective_user.id
        text = (update.message.text or "").strip()
        if not text:
            return

        if not self.config.is_user_allowed(uid):
            log.warning(
                "dropped message from non-whitelisted user telegram_id=%s name=%r text=%r",
                uid,
                update.effective_user.full_name,
                text[:120],
            )
            return

        user_name = self.config.user_name(uid) or f"uid:{uid}"
        log.info("inbound from %s (uid=%s): %r", user_name, uid, text[:200])

        try:
            reply = self._dispatch(text, uid, user_name)
        except Exception as e:
            log.exception("error handling message from %s", user_name)
            reply = "Something broke handling that. Check the log."
            if uid != self.owner_user_id and self.owner_user_id > 0:
                try:
                    await ctx.bot.send_message(
                        chat_id=self.owner_user_id,
                        text=f"⚠️ Mr. Moneypenny hit an error handling a message from {user_name}: {e!r}",
                    )
                except Exception:
                    log.exception("failed to send error notification to owner")

        if reply:
            await update.message.reply_text(reply)

    def _dispatch(self, text: str, uid: int, user_name: str) -> str:
        rename_reply = self._try_rename(text)
        if rename_reply is not None:
            return rename_reply

        if looks_like_insight(text):
            return self._handle_insight(text)
        return self._handle_action(text, uid, user_name)

    def _try_rename(self, text: str) -> str | None:
        m = _RENAME_RE.match(text)
        if not m:
            return None
        old = m.group(1).strip()
        new = m.group(2).strip()
        if new not in self.config.categories():
            return (
                f"⚠️ '{new}' is not a category in your current config.yaml. "
                f"Add it (and rebalance caps) first, then resend."
            )
        rows = self.db.rename_category(old, new)
        if rows == 0:
            return f"No entries matched '{old}'. Nothing renamed."
        return f"✓ renamed '{old}' → '{new}' on {rows} entries"

    def _handle_action(self, text: str, uid: int, user_name: str) -> str:
        tz = self.config.timezone
        today_start, today_end = today_bounds(tz)
        today_entries = self.db.list_in_range(today_start, today_end)

        actions = self.llm.parse_actions(text, today_entries, user_name)
        replies = [self._execute(a, uid, user_name, raw=text) for a in actions]
        return "\n".join(r for r in replies if r)

    def _execute(self, a: Action, uid: int, user_name: str, raw: str) -> str:
        if isinstance(a, LogAction):
            return self._handle_log(a, uid, user_name, raw)

        if isinstance(a, DeleteAction):
            existing = self.db.get_entry(a.entry_id)
            if existing is None:
                return f"⚠️ no entry #{a.entry_id} to delete"
            self.db.delete_entry(a.entry_id)
            sign = "-" if existing.amount_cents < 0 else ""
            display = abs(existing.amount_cents) / 100
            return f"✓ removed #{a.entry_id}: {sign}${display:.2f} {existing.category}"

        if isinstance(a, TextReply):
            return a.message

        return ""

    def _handle_log(self, a: LogAction, uid: int, user_name: str, raw: str) -> str:
        """Insert an entry, splitting any over-cap portion into the fallback (Miscellaneous).

        Refunds and direct-to-fallback entries skip the overflow check.
        """
        ts = now(self.config.timezone)

        if a.is_refund or a.amount_cents <= 0:
            return self._insert_and_reply(
                uid, user_name, raw, ts,
                amount_cents=-a.amount_cents if a.is_refund else a.amount_cents,
                category=a.category, merchant=a.merchant, verb="refund" if a.is_refund else "logged",
            )

        fallback = self.config.fallback_category()
        if fallback is None or a.category == fallback:
            return self._insert_and_reply(
                uid, user_name, raw, ts,
                amount_cents=a.amount_cents, category=a.category,
                merchant=a.merchant, verb="logged",
            )

        cap = self.config.category_caps_cents.get(a.category, 0)
        m_start, m_end = current_month_bounds(self.config.timezone)
        spent = self.db.spending_by_category(m_start, m_end).get(a.category, 0)
        headroom = max(0, cap - spent)

        if a.amount_cents <= headroom:
            return self._insert_and_reply(
                uid, user_name, raw, ts,
                amount_cents=a.amount_cents, category=a.category,
                merchant=a.merchant, verb="logged",
            )

        # Overflow: fits portion → original category, excess → fallback
        fits = headroom
        excess = a.amount_cents - fits
        replies: list[str] = []
        if fits > 0:
            replies.append(self._insert_and_reply(
                uid, user_name, raw, ts,
                amount_cents=fits, category=a.category,
                merchant=a.merchant, verb="logged",
            ))
        replies.append(self._insert_and_reply(
            uid, user_name, raw, ts,
            amount_cents=excess, category=fallback,
            merchant=a.merchant, verb=f"overflow from {a.category}", warn=True,
        ))
        return "\n".join(replies)

    def _insert_and_reply(
        self, uid: int, user_name: str, raw: str, ts,
        *, amount_cents: int, category: str, merchant: str | None,
        verb: str, warn: bool = False,
    ) -> str:
        entry_id = self.db.insert_entry(
            timestamp=ts, user_id=uid, amount_cents=amount_cents,
            category=category, merchant=merchant, raw_message=raw,
        )
        sign = "-" if amount_cents < 0 else ""
        display = abs(amount_cents) / 100
        merch = f" ({merchant})" if merchant else ""
        icon = "⚠️" if warn else "✓"
        return f"{icon} {verb} {sign}${display:.2f} {category}{merch} — {user_name} #{entry_id}"

    def _handle_insight(self, text: str) -> str:
        tz = self.config.timezone
        text_lower = text.lower()
        if "yesterday" in text_lower:
            start, end = yesterday_bounds(tz)
            label = "yesterday"
        elif "today" in text_lower:
            start, end = today_bounds(tz)
            label = "today"
        elif (
            "last 7" in text_lower
            or "past 7" in text_lower
            or "this week" in text_lower
            or "past week" in text_lower
        ):
            start, end = last_n_days_bounds(tz, 7)
            label = "last 7 days"
        else:
            start, end = current_month_bounds(tz)
            label = start.strftime("%B %Y") + " (current month)"

        spending = self.db.spending_by_category(start, end)
        entries = self.db.list_in_range(start, end)
        return self.llm.insight_reply(
            question=text,
            period_label=label,
            spending_by_cat_cents=spending,
            recent_entries=entries,
        )
