"""SQLite persistence for budget-bot.

One table, two indexes. Money stored as integer cents to avoid float drift.
Timestamps stored as ISO 8601 strings with timezone offset.

Schema changes are managed by `src.migrations`, which uses SQLite's built-in
PRAGMA user_version to track applied migrations. The DB() constructor runs
any pending migrations on every startup.
"""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterator

from .migrations import run_migrations


@dataclass(frozen=True)
class Entry:
    id: int
    timestamp: datetime
    user_id: int
    amount_cents: int
    category: str
    merchant: str | None
    raw_message: str


class DB:
    def __init__(self, path: str | Path) -> None:
        self.path = str(path)
        with self._conn() as c:
            run_migrations(c)

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, isolation_level=None)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()

    def insert_entry(
        self,
        *,
        timestamp: datetime,
        user_id: int,
        amount_cents: int,
        category: str,
        merchant: str | None,
        raw_message: str,
    ) -> int:
        with self._conn() as c:
            cur = c.execute(
                """INSERT INTO entries
                   (timestamp, user_id, amount_cents, category, merchant, raw_message)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (timestamp.isoformat(), user_id, amount_cents, category, merchant, raw_message),
            )
            return int(cur.lastrowid)

    def delete_entry(self, entry_id: int) -> bool:
        with self._conn() as c:
            cur = c.execute("DELETE FROM entries WHERE id = ?", (entry_id,))
            return cur.rowcount > 0

    def get_entry(self, entry_id: int) -> Entry | None:
        with self._conn() as c:
            row = c.execute("SELECT * FROM entries WHERE id = ?", (entry_id,)).fetchone()
        return _row_to_entry(row) if row else None

    def list_in_range(self, start: datetime, end: datetime) -> list[Entry]:
        with self._conn() as c:
            rows = c.execute(
                """SELECT * FROM entries
                   WHERE timestamp >= ? AND timestamp < ?
                   ORDER BY timestamp ASC""",
                (start.isoformat(), end.isoformat()),
            ).fetchall()
        return [_row_to_entry(r) for r in rows]

    def spending_by_category(self, start: datetime, end: datetime) -> dict[str, int]:
        with self._conn() as c:
            rows = c.execute(
                """SELECT category, SUM(amount_cents) AS total
                   FROM entries
                   WHERE timestamp >= ? AND timestamp < ?
                   GROUP BY category""",
                (start.isoformat(), end.isoformat()),
            ).fetchall()
        return {r["category"]: int(r["total"]) for r in rows}

    def distinct_categories(self) -> set[str]:
        """Every category name that appears in any historical entry."""
        with self._conn() as c:
            rows = c.execute("SELECT DISTINCT category FROM entries").fetchall()
        return {r["category"] for r in rows}

    def rename_category(self, old: str, new: str) -> int:
        """Migrate all entries with category=old to category=new. Returns rows affected."""
        with self._conn() as c:
            cur = c.execute(
                "UPDATE entries SET category = ? WHERE category = ?",
                (new, old),
            )
            return cur.rowcount


def _row_to_entry(row: sqlite3.Row) -> Entry:
    return Entry(
        id=row["id"],
        timestamp=datetime.fromisoformat(row["timestamp"]),
        user_id=row["user_id"],
        amount_cents=row["amount_cents"],
        category=row["category"],
        merchant=row["merchant"],
        raw_message=row["raw_message"],
    )
