"""WebSocket client that connects a local Mr. Moneypenny instance to the relay.

The relay is a thin router: it forwards Telegram updates addressed to one of
our `telegram_ids` over a single persistent WebSocket. We pass each update
into python-telegram-bot's `Application.process_update()` so the existing
handler stack works unchanged.

As of v0.7 the same WebSocket carries outbound Bot API calls (sendMessage
etc.) over `tg_call` frames so the bot token only ever lives on the relay.

See relay/PROTOCOL.md for the wire format.
"""
from __future__ import annotations

import asyncio
import json
import logging
import random
import secrets
from typing import Any, Awaitable, Callable

import websockets
from websockets.asyncio.client import ClientConnection


UpdateHandler = Callable[[dict], Awaitable[None]]


class RelayClientError(RuntimeError):
    pass


class RelayCallError(RuntimeError):
    """Raised when the relay returns ok=false for a tg_call."""

    def __init__(self, error_code: int, description: str) -> None:
        super().__init__(f"{error_code}: {description}")
        self.error_code = error_code
        self.description = description


class RelayClient:
    def __init__(
        self,
        *,
        relay_url: str,
        relay_token: str,
        telegram_ids: list[int],
        on_update: UpdateHandler,
        call_timeout_s: float = 30.0,
        log: logging.Logger | None = None,
    ) -> None:
        if not relay_url:
            raise ValueError("relay_url required")
        if not relay_token:
            raise ValueError("relay_token required")
        if not telegram_ids:
            raise ValueError("telegram_ids must be non-empty")
        self.relay_url = relay_url
        self.relay_token = relay_token
        self.telegram_ids = list(telegram_ids)
        self.on_update = on_update
        self.call_timeout_s = call_timeout_s
        self.log = log or logging.getLogger("relay_client")
        self._stop = asyncio.Event()
        self._connected = asyncio.Event()
        self._ws: ClientConnection | None = None
        self._pending_calls: dict[str, asyncio.Future[dict[str, Any]]] = {}

    # ---------- public ----------

    def stop(self) -> None:
        self._stop.set()

    async def wait_connected(self, timeout: float | None = None) -> None:
        """Block until the WebSocket is bound and ready for tg_call."""
        if timeout is None:
            await self._connected.wait()
        else:
            await asyncio.wait_for(self._connected.wait(), timeout=timeout)

    async def tg_call(self, method: str, **params: Any) -> dict[str, Any]:
        """Call a Telegram Bot API method through the relay. Returns the
        full Telegram response dict (`{"ok": True, "result": ...}` shape) or
        raises RelayCallError on `ok: false`."""
        if not self._connected.is_set() or self._ws is None:
            raise RelayClientError("relay not connected")
        request_id = secrets.token_urlsafe(8)
        loop = asyncio.get_running_loop()
        fut: asyncio.Future[dict[str, Any]] = loop.create_future()
        self._pending_calls[request_id] = fut
        try:
            await self._ws.send(json.dumps({
                "type": "tg_call",
                "method": method,
                "params": params,
                "request_id": request_id,
            }))
            result = await asyncio.wait_for(fut, timeout=self.call_timeout_s)
        finally:
            self._pending_calls.pop(request_id, None)
        if not result.get("ok"):
            raise RelayCallError(
                int(result.get("error_code") or 0),
                str(result.get("description") or "tg_call failed"),
            )
        return result

    # ---------- run loop ----------

    async def run_forever(self) -> None:
        attempt = 0
        while not self._stop.is_set():
            try:
                await self._run_once()
                attempt = 0
            except RelayClientError as e:
                self.log.error("fatal relay error: %s", e)
                raise
            except Exception as e:
                attempt += 1
                delay = min(60.0, 2.0 ** attempt) + random.uniform(0, 1.0)
                self.log.warning("relay disconnected (%s); reconnecting in %.1fs", e, delay)
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=delay)
                except asyncio.TimeoutError:
                    pass

    async def _run_once(self) -> None:
        # ping_interval/ping_timeout shorter than the default 20/20 so a silent
        # dead connection is detected and torn down before tg_call's 30s
        # timeout fires. Without this, calls in flight when TCP goes deaf
        # surface as TimeoutError instead of the more accurate "connection
        # lost" path that retries cleanly.
        async with websockets.connect(
            self.relay_url, max_size=8 * 1024 * 1024,
            ping_interval=10, ping_timeout=10,
        ) as ws:
            await ws.send(json.dumps({
                "type": "hello",
                "relay_token": self.relay_token,
                "telegram_ids": self.telegram_ids,
            }))
            ack = json.loads(await ws.recv())
            if ack.get("type") == "hello_error":
                raise RelayClientError(f"relay rejected hello: {ack.get('reason')}")
            if ack.get("type") != "hello_ack":
                raise RelayClientError(f"unexpected first message from relay: {ack}")
            self.log.info("relay bound for telegram_ids=%s", ack.get("bound"))

            self._ws = ws
            self._connected.set()
            try:
                await self._dispatch_loop(ws)
            finally:
                self._connected.clear()
                self._ws = None
                self._fail_pending("connection lost")

    async def _dispatch_loop(self, ws: ClientConnection) -> None:
        # Race recv() against the stop event so SIGTERM breaks out promptly
        # instead of blocking on the next message indefinitely.
        stop_task = asyncio.create_task(self._stop.wait(), name="stop")
        try:
            while not self._stop.is_set():
                recv_task = asyncio.create_task(ws.recv(), name="recv")
                done, _ = await asyncio.wait(
                    {recv_task, stop_task},
                    return_when=asyncio.FIRST_COMPLETED,
                )
                if stop_task in done:
                    recv_task.cancel()
                    return
                try:
                    raw = recv_task.result()
                except Exception:
                    return  # connection closed; outer loop will reconnect
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    self.log.warning("non-JSON frame from relay; ignoring")
                    continue
                t = msg.get("type")
                if t == "tg_update":
                    update = msg.get("update")
                    if isinstance(update, dict):
                        try:
                            await self.on_update(update)
                        except Exception:
                            self.log.exception("on_update raised")
                elif t == "tg_call_result":
                    self._resolve_call(msg)
                elif t == "displaced":
                    self.log.warning("relay displaced this connection: %s", msg.get("reason"))
                    self._stop.set()
                    return
                elif t == "pong":
                    pass
                else:
                    self.log.warning("unknown relay message type: %r", t)
        finally:
            stop_task.cancel()

    def _resolve_call(self, msg: dict[str, Any]) -> None:
        req_id = msg.get("request_id")
        if not isinstance(req_id, str):
            self.log.warning("tg_call_result without request_id; dropping")
            return
        fut = self._pending_calls.get(req_id)
        if fut is None or fut.done():
            return  # late or duplicate
        # Strip the protocol envelope; pass the Telegram-shaped body.
        result = {k: v for k, v in msg.items() if k not in ("type", "request_id")}
        fut.set_result(result)

    def _fail_pending(self, reason: str) -> None:
        if not self._pending_calls:
            return
        for fut in list(self._pending_calls.values()):
            if not fut.done():
                fut.set_exception(RelayClientError(reason))
        self._pending_calls.clear()
