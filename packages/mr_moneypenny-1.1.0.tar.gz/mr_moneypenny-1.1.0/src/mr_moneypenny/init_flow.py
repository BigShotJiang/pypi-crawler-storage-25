"""Pure logic for the first-run wizard.

Each step is a small callable that does one concrete thing and returns
data. The CLI shell (cli.py) prompts the user and threads the results
together; a future GUI can call the same functions from form handlers.
No interactive I/O lives here.

Functions raise InitFlowError on user-fixable problems (bad input, bad
key) and let unexpected exceptions propagate.
"""
from __future__ import annotations

import json
import os
import secrets
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

import yaml

from . import paths


DEFAULT_RELAY_WS_URL = "wss://mr-moneypenny-relay.fly.dev/ws"


class InitFlowError(Exception):
    """Wizard step failed in a way the user should see and fix."""


# ---------- Anthropic key ----------

def verify_anthropic_key(key: str) -> tuple[bool, str]:
    """Returns (ok, message). False only when the key is *definitely* invalid.
    Transient errors (network, server) are reported but treated as 'ok' so
    the wizard doesn't block on a flaky network."""
    key = (key or "").strip()
    if not key.startswith("sk-ant-"):
        return False, "Anthropic keys start with 'sk-ant-'. Double-check the paste."
    try:
        # Lazy import so the wizard doesn't pull anthropic at module load
        # if it's not actually used.
        import anthropic
    except ImportError:
        return True, "anthropic SDK not installed; skipping verification"
    try:
        client = anthropic.Anthropic(api_key=key)
        client.messages.create(
            model="claude-haiku-4-5-20251001",
            max_tokens=1,
            messages=[{"role": "user", "content": "."}],
        )
        return True, "Anthropic accepted the key."
    except Exception as e:
        # The SDK exposes AuthenticationError; we duck-type to avoid a hard
        # type dependency on a specific SDK version.
        cls = type(e).__name__
        if cls in ("AuthenticationError", "PermissionDeniedError"):
            return False, f"Anthropic rejected the key ({cls})."
        return True, f"Couldn't verify ({cls}); proceeding anyway."


# ---------- Telegram pairing ----------

@dataclass(frozen=True)
class PairingHandle:
    code: str
    connect_url: str
    relay_https_base: str


def start_pairing(relay_ws_url: str = DEFAULT_RELAY_WS_URL) -> PairingHandle:
    base = _https_base_from_ws(relay_ws_url)
    code = secrets.token_urlsafe(12)
    return PairingHandle(
        code=code,
        connect_url=f"{base}/connect?pairing_code={code}",
        relay_https_base=base,
    )


def poll_pairing(handle: PairingHandle) -> tuple[str, dict | None]:
    """One claim attempt. Returns:
      ("claimed", payload) — pairing complete (telegram_id, name, relay_token)
      ("not_yet", None)    — keep polling
      ("expired", None)    — pairing window closed
      ("error",   None)    — transient; retry
    """
    try:
        req = urllib.request.Request(
            f"{handle.relay_https_base}/pair/{handle.code}", method="GET",
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            if r.status == 200:
                return "claimed", json.loads(r.read())
            return "not_yet", None
    except urllib.error.HTTPError as e:
        if e.code == 410:
            return "expired", None
        return "error", None
    except (urllib.error.URLError, TimeoutError, OSError):
        return "error", None


def write_identity(payload: dict[str, object], target: Path | None = None) -> Path:
    """Write identity.json v1 (single-user, post-pairing). Mode 600."""
    target = target or paths.identity_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    body = {
        "version": 1,
        "owner": {
            "telegram_id": int(payload["telegram_id"]),  # type: ignore[arg-type]
            "name": str(payload.get("name") or f"user_{payload['telegram_id']}"),
            "relay_token": str(payload["relay_token"]),
        },
    }
    target.write_text(json.dumps(body, indent=2) + "\n")
    try:
        os.chmod(target, 0o600)
    except OSError:
        pass
    return target


def write_identity_v2(*, owner: dict[str, object], members: list[dict[str, object]],
                      relay_token: str, target: Path | None = None) -> Path:
    """Write identity.json v2 (household). The relay_token authorizes binding
    owner_id plus every member_id. Mode 600.
    """
    target = target or paths.identity_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    body: dict[str, Any] = {
        "version": 2,
        "owner": {
            "telegram_id": int(owner["telegram_id"]),  # type: ignore[arg-type]
            "name": str(owner.get("name") or f"user_{owner['telegram_id']}"),
        },
        "members": [
            {
                "telegram_id": int(m["telegram_id"]),  # type: ignore[arg-type]
                "name": str(m.get("name") or f"user_{m['telegram_id']}"),
            }
            for m in members
        ],
        "relay_token": relay_token,
    }
    target.write_text(json.dumps(body, indent=2) + "\n")
    try:
        os.chmod(target, 0o600)
    except OSError:
        pass
    return target


def read_identity(source: Path | None = None) -> dict[str, Any] | None:
    """Read identity.json, returning a normalized v2-shaped dict, or None if absent."""
    source = source or paths.identity_path()
    if not source.exists():
        return None
    raw = json.loads(source.read_text())
    version = int(raw.get("version", 1))
    if version == 1:
        owner = raw["owner"]
        return {
            "version": 1,
            "owner": {"telegram_id": int(owner["telegram_id"]), "name": str(owner.get("name") or "")},
            "members": [],
            "relay_token": str(owner["relay_token"]),
        }
    if version == 2:
        return {
            "version": 2,
            "owner": {
                "telegram_id": int(raw["owner"]["telegram_id"]),
                "name": str(raw["owner"].get("name") or ""),
            },
            "members": [
                {"telegram_id": int(m["telegram_id"]), "name": str(m.get("name") or "")}
                for m in raw.get("members", [])
            ],
            "relay_token": str(raw["relay_token"]),
        }
    raise InitFlowError(f"identity.json version {version} not understood")


# ---------- Household invites ----------

@dataclass(frozen=True)
class InviteHandle:
    invite_code: str
    join_url: str
    expires_at: int
    relay_https_base: str


def mint_invite(*, relay_token: str, invitee_name: str, owner_label: str = "",
                relay_ws_url: str = DEFAULT_RELAY_WS_URL) -> InviteHandle:
    """Owner mints a new invite code for invitee_name. Returns the join URL the
    owner should send to the invitee. Raises InitFlowError on relay failures."""
    base = _https_base_from_ws(relay_ws_url)
    body = json.dumps({
        "relay_token": relay_token,
        "invitee_name": invitee_name,
        "owner_label": owner_label,
    }).encode()
    req = urllib.request.Request(
        f"{base}/invite/mint", data=body, method="POST",
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            payload = json.loads(r.read())
    except urllib.error.HTTPError as e:
        detail = e.read().decode(errors="replace")
        raise InitFlowError(f"relay rejected invite mint: HTTP {e.code} {detail}") from e
    except (urllib.error.URLError, OSError) as e:
        raise InitFlowError(f"couldn't reach relay: {e}") from e
    return InviteHandle(
        invite_code=str(payload["invite_code"]),
        join_url=str(payload["join_url"] or f"{base}/invite/{payload['invite_code']}/join"),
        expires_at=int(payload.get("expires_at") or 0),
        relay_https_base=base,
    )


def poll_invite_status(handle: InviteHandle, *, relay_token: str) -> tuple[str, dict | None]:
    """One status check. Returns:
      ('joined',   payload) — invitee accepted; payload has new household relay_token
      ('not_yet',  None)    — still pending
      ('expired',  None)    — invite TTL elapsed; owner must re-mint
      ('error',    None)    — transient
      ('not_found', None)   — invite consumed by an earlier successful poll
    """
    body = json.dumps({"relay_token": relay_token}).encode()
    req = urllib.request.Request(
        f"{handle.relay_https_base}/invite/{handle.invite_code}/status",
        data=body, method="POST",
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            if r.status == 200:
                return "joined", json.loads(r.read())
            return "not_yet", None
    except urllib.error.HTTPError as e:
        if e.code == 410:
            return "expired", None
        if e.code == 404:
            return "not_found", None
        return "error", None
    except (urllib.error.URLError, TimeoutError, OSError):
        return "error", None


# ---------- Total cap parsing ----------

def parse_total_cap(value: str) -> int:
    """Accepts '4000', '$4,000', '4000.00', etc. Returns integer cents."""
    s = (value or "").strip().replace("$", "").replace(",", "")
    if not s:
        raise InitFlowError("Enter a number, e.g. 4000 or 4000.00")
    try:
        d = Decimal(s)
    except InvalidOperation as e:
        raise InitFlowError(f"Couldn't parse {value!r} as a dollar amount") from e
    if d <= 0:
        raise InitFlowError("Total cap must be positive")
    cents = int((d * 100).quantize(Decimal("1")))
    return cents


# ---------- Starter config scaffolding ----------

# Fixed proportions for a generic envelope budget. These sum to 1.0 and are
# tuned to roughly match what most US households spend on each bucket. Misc
# absorbs the rounding remainder so the envelope invariant always holds.
_BUDGET_TEMPLATE: list[tuple[str, float, str]] = [
    # (category, fraction_of_total, kind: "fixed" | "variable" | "savings" | "misc")
    ("Rent",                 0.375, "fixed"),
    ("Utilities",            0.050, "fixed"),
    ("Internet",             0.019, "fixed"),
    ("Renters Insurance",    0.006, "fixed"),
    ("Groceries",            0.125, "variable"),
    ("Dining",               0.050, "variable"),
    ("Transport",            0.050, "variable"),
    ("Personal Care",        0.025, "variable"),
    ("Subscriptions",        0.013, "variable"),
    ("Clothing",             0.025, "variable"),
    ("Savings/Investments",  0.125, "savings"),
    ("Miscellaneous",        0.137, "misc"),  # absorbs remainder
]


def scaffold_config(total_cap_cents: int, timezone: str = "America/New_York") -> dict[str, object]:
    """Build a YAML-ready config dict scaled to the user's total_cap. The Misc
    bucket absorbs the rounding remainder so sum(caps) == total_cap exactly."""
    if total_cap_cents <= 0:
        raise InitFlowError("total_cap_cents must be positive")
    categories: dict[str, float] = {}
    fixed: list[str] = []
    savings: list[str] = []
    running_cents = 0
    misc_name: str | None = None
    for name, fraction, kind in _BUDGET_TEMPLATE:
        if kind == "misc":
            misc_name = name
            continue
        cents = round(total_cap_cents * fraction / 100) * 100  # round to whole dollars
        categories[name] = cents / 100
        running_cents += cents
        if kind == "fixed":
            fixed.append(name)
        elif kind == "savings":
            fixed.append(name)  # savings are also "fixed" w.r.t. pace
            savings.append(name)
    misc_cents = total_cap_cents - running_cents
    assert misc_name is not None
    categories[misc_name] = misc_cents / 100

    return {
        "config_version": 1,
        "total_cap": total_cap_cents / 100,
        "timezone": timezone,
        "fixed_categories": fixed,
        "savings_categories": savings,
        "allowed_users": [
            {"telegram_id": 0, "name": "You"},
        ],
        "categories": categories,
    }


def write_starter_config(total_cap_cents: int, target: Path | None = None,
                         timezone: str = "America/New_York") -> Path:
    """Render the starter config to YAML (preserves dict order via sort_keys=False)."""
    target = target or paths.config_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    body = scaffold_config(total_cap_cents, timezone=timezone)
    yaml_text = yaml.safe_dump(body, sort_keys=False, default_flow_style=False)
    target.write_text(yaml_text)
    return target


# ---------- .env scaffolding ----------

def write_env(*, anthropic_key: str, relay_ws_url: str = DEFAULT_RELAY_WS_URL,
              target: Path | None = None) -> Path:
    """Scaffold ~/.config/mr-moneypenny/.env (mode 600).

    As of v0.7 the local install does not need TELEGRAM_BOT_TOKEN — outbound
    replies are routed through the relay (see relay_request.py).
    """
    target = target or paths.env_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Mr. Moneypenny credentials. mode 600. Do not commit.",
        f"ANTHROPIC_API_KEY={anthropic_key}",
        f"RELAY_URL={relay_ws_url}",
        "",
    ]
    target.write_text("\n".join(lines))
    try:
        os.chmod(target, 0o600)
    except OSError:
        pass
    return target


# ---------- helpers ----------

def _https_base_from_ws(ws_url: str) -> str:
    if ws_url.startswith("wss://"):
        scheme = "https://"
        rest = ws_url[len("wss://"):]
    elif ws_url.startswith("ws://"):
        scheme = "http://"
        rest = ws_url[len("ws://"):]
    else:
        raise InitFlowError(f"RELAY_URL must start with ws:// or wss://, got {ws_url!r}")
    host = rest.split("/", 1)[0]
    return f"{scheme}{host}"


def existing_state() -> dict[str, bool]:
    """Snapshot of which config files already exist. The wizard uses this to
    skip steps that are already set, or to warn before overwriting."""
    return {
        "env": paths.env_path().exists(),
        "config": paths.config_path().exists(),
        "identity": paths.identity_path().exists(),
        "db": paths.db_path().exists(),
    }
