<div align="center">
  <img src="src/mr_moneypenny/static/logo.png" alt="Mr. Moneypenny" width="160">
  <h1>Mr. Moneypenny</h1>
  <p><em>Self-hosted Telegram budgeting assistant. Local data, envelope discipline, one-tap onboarding.</em></p>

  <p>
    <a href="https://github.com/wyattts/mr-moneypenny/actions/workflows/ci.yml"><img src="https://github.com/wyattts/mr-moneypenny/actions/workflows/ci.yml/badge.svg" alt="CI"></a>
    <a href="LICENSE"><img src="https://img.shields.io/badge/license-AGPL--3.0--or--later-2f8a4a" alt="AGPL-3.0-or-later"></a>
    <img src="https://img.shields.io/badge/python-3.13%2B-blue" alt="Python 3.13+">
    <img src="https://img.shields.io/badge/platforms-linux%20%7C%20macOS-2f8a4a" alt="Linux + macOS">
  </p>
</div>

Tell `@Mr_Moneypenny_bot` what you spent. It logs the entry, picks a category, applies envelope-budget rules, and shows you a localhost dashboard. Your data lives on your computer.

## What it does

- **Chat with a Telegram bot to log expenses.** "$8 coffee at Starbucks" → entry recorded, category inferred.
- **Envelope budgeting, enforced mechanically.** Sum of category caps must equal your total cap. If a category overflows, the excess auto-spills to a fallback category. The config validator refuses to start if the budget is unbalanced.
- **Calendar-month reset.** Each month is a fresh envelope; old entries stay in the database but fall outside the current-month query window.
- **Per-person attribution in shared households.** One bot, multiple Telegram accounts, one shared budget. Per-person breakdowns on the dashboard.
- **Insights on demand.** Ask "how am I doing this month?" or "what's left in groceries?" and get a budget-aware reply.
- **Local SQLite, local Flask dashboard at `127.0.0.1:8765`.** No cloud dependency for your data.
- **LLM-pluggable.** Bring your own Anthropic API key, or run locally with Ollama.

## What it isn't

- Not a bank-syncing finance app. No account aggregation, no Plaid, no scraping.
- Not a multi-tenant SaaS. There is no "Mr. Moneypenny account." You run an instance.
- Not zero-friction yet — see the roadmap.

## Architecture (target — v1.0)

```
                      ┌──────────────────────┐
                      │  @MrMoneypennyBot    │
                      │  (one shared bot)    │
                      └──────────┬───────────┘
                                 │ webhook
                                 ▼
   household members            ┌──────────────────────┐         your machine
   ◄────────────────────────►   │  Stateless relay     │ ◄─────────────────►
   (chat the same bot via       │  - routes by         │   - WebSocket client
    their own Telegram)         │    telegram_id       │   - SQLite (local)
                                │  - Telegram OAuth    │   - Anthropic key
                                │  - no data storage   │   - localhost dashboard
                                └──────────────────────┘
```

**Locally hosted, with one piece of always-on infrastructure (the relay) that you can also self-host.** The relay is stateless: it receives Telegram webhooks, looks up the user's open WebSocket, forwards. No message bodies are stored. You can point your client at a different relay via `mr-moneypenny relay-config --url=https://my-relay.example.com` if you'd rather not trust the default one.

## Install

**Linux + macOS** are supported as of v0.6. Windows should work (the package is pure Python and `platformdirs` handles the path differences) but hasn't been smoke-tested — stories welcome in [issues](https://github.com/wyattts/mr-moneypenny/issues).

You'll need [uv](https://docs.astral.sh/uv/) and Python 3.13+.

```bash
git clone https://github.com/wyattts/mr-moneypenny.git
cd mr-moneypenny
uv sync

# Interactive first-run wizard:
uv run mr-moneypenny init
```

The wizard walks you through three steps:

1. **Anthropic API key** — paste it; the wizard verifies the key works against the Claude API. Get one at [console.anthropic.com](https://console.anthropic.com/) (~$0.50–2/month at typical use).
2. **Telegram identity** — a browser tab opens; tap **Log in with Telegram**; the wizard binds your account to this device. No `@BotFather` walkthrough.
3. **Total cap** — enter your monthly net pay; the wizard scaffolds a starter `config.yaml` whose category caps sum exactly to that number. Edit categories and caps as you like.

The wizard writes everything to OS-appropriate locations: `~/.config/mr-moneypenny/` (Linux) or `~/Library/Application Support/mr-moneypenny/` (macOS), etc. As of v0.7, outbound replies are routed through the relay too — there's no `@BotFather` step, no Telegram Bot Token to paste, no manual config to edit before the bot can reply.

### Run it

```bash
uv run mr-moneypenny run         # the bot (foreground)
uv run mr-moneypenny dashboard   # the dashboard at http://127.0.0.1:8765
```

### Have it run in the background

```bash
mr-moneypenny install-service
```

That's it. The installer detects your OS and writes the appropriate config:

- **Linux** — `~/.config/systemd/user/{budget-bot,budget-dashboard}.service`, then `systemctl --user enable --now`.
- **macOS** — `~/Library/LaunchAgents/net.mrmoneypenny.{bot,dashboard}.plist`, then `launchctl load`.
- **Windows** — prints a PowerShell `Register-ScheduledTask` snippet for you to run; full automation in v1.0.

To remove: `mr-moneypenny uninstall-service`. To check: `mr-moneypenny service-status`.

## Roadmap

- **v0.2** — XDG paths, AGPL license, public repo. ✅
- **v0.3** — Schema migrations (`PRAGMA user_version`) + `config_version` field, so future upgrades don't require manual fixes. ✅
- **v0.4** — WebSocket relay client + minimal relay service deployed on Fly.io. Local instances connect via WebSocket; relay receives Telegram webhooks centrally. See [`relay/`](relay/) for the relay service and [`relay/PROTOCOL.md`](relay/PROTOCOL.md) for the wire format. ✅
- **v0.5** — Telegram Login Widget OAuth for one-click identity binding. New users run `mr-moneypenny pair`, click "Log in with Telegram," and `~/.config/mr-moneypenny/identity.json` gets populated automatically. ✅
- **v0.6** — Real pip-installable package (`mr_moneypenny`) with a unified `mr-moneypenny` CLI. New `mr-moneypenny init` wizard collapses Anthropic-key entry, Telegram pairing, and budget scaffolding into a single guided flow. ✅
- **v0.7** — Outbound Bot API calls (`sendMessage`, `getMe`, etc.) now route through the relay over `tg_call` frames. The bot token only ever lives on the relay. Local installs no longer need `TELEGRAM_BOT_TOKEN`. ✅
- **v0.8** — Household invite flow. Owner runs `mr-moneypenny invite "Vitoria"` → gets a shareable join URL → invitee taps "Log in with Telegram" → relay mints a household-signed token authorizing both `telegram_id`s. ✅
- **v0.9 (you are here)** — Cross-platform service automation: `mr-moneypenny install-service` writes a systemd user unit on Linux, a launchd plist on macOS, or prints a PowerShell `Register-ScheduledTask` snippet on Windows. Same command, three platforms. ✅
- **v1.0** — PyPI release, public docs, stable.

Full design notes live in the project's planning docs (not in this repo — those track personal scope decisions).

## Contributing

Solo project, but PRs are welcome. Two things are non-negotiable for any change:

1. **Envelope invariant.** `sum(category_caps) == total_cap`. The validator enforces it; don't soften it.
2. **Low friction.** This tool exists to *reduce* friction. Don't add steps that need ongoing user attention (confirmation prompts, manual rollovers, etc.).

A `CONTRIBUTING.md` will land before v1. For now, open an issue to discuss before you start coding.

## License

[GNU Affero General Public License v3.0 or later](LICENSE).

The AGPL choice matters here: if anyone runs a hosted Mr. Moneypenny relay or service for users, their modifications must be open. This protects the decentralization-friendly intent of the architecture.

## Acknowledgements

Built with [Claude Code](https://claude.com/claude-code), [python-telegram-bot](https://docs.python-telegram-bot.org/), [Anthropic's API](https://docs.anthropic.com/), and [Flask](https://flask.palletsprojects.com/).
