# Mr. Moneypenny Relay

Stateless WebSocket router between Telegram's webhook and locally-running
Mr. Moneypenny instances. See [`PROTOCOL.md`](PROTOCOL.md) for wire format.

## Run locally (for development)

```bash
cd relay
uv sync                       # picks up aiohttp from pyproject.toml
export TELEGRAM_BOT_TOKEN=...  # from @BotFather
export RELAY_TOKEN=$(openssl rand -hex 32)
export WEBHOOK_SECRET=$(openssl rand -hex 16)
# PUBLIC_URL only needed if you want the relay to call setWebhook itself.
python main.py
```

The relay listens on `0.0.0.0:8080`. To make Telegram reach it during local
dev, you'll need a tunnel — `cloudflared tunnel --url http://localhost:8080`
or `ngrok http 8080`. Then set `PUBLIC_URL` to the tunnel URL and restart,
or call `setWebhook` manually:

```bash
curl "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook" \
  -d "url=${TUNNEL_URL}/telegram/webhook/${WEBHOOK_SECRET}"
```

## Deploy to Fly.io

```bash
cd relay
fly launch --no-deploy           # accepts fly.toml; creates the app
fly secrets set \
  TELEGRAM_BOT_TOKEN=... \
  RELAY_TOKEN=... \
  WEBHOOK_SECRET=... \
  PUBLIC_URL=https://mr-moneypenny-relay.fly.dev
fly deploy
```

After deploy, `https://mr-moneypenny-relay.fly.dev/healthz` should return
`ok`. The Fly app will register the Telegram webhook on startup using
`PUBLIC_URL` + `WEBHOOK_SECRET`.

## Operational notes

- The routing table is in-memory. Restarting the relay drops every connection;
  clients reconnect with backoff.
- 256 MB / shared CPU is plenty for hundreds of users — this is I/O-bound.
- No persistence, no logs of message content. The `access_log=None` in
  `main.py` keeps even URL paths out of stdout.
- A failure here doesn't lose data, only delivery: the local instance still
  has the SQLite DB and dashboard. If the relay is down, Telegram retries
  webhook deliveries on its own schedule (a few minutes), so a brief outage
  is recoverable.
