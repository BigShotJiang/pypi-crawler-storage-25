"""File IO primitives for Markdown-OS."""

from __future__ import annotations

import os
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

import portalocker


class FileReadError(RuntimeError):
    """Raised when reading markdown content fails."""


class FileWriteError(RuntimeError):
    """Raised when writing markdown content fails."""


class FileHandler:
    """Coordinate safe markdown file access for the HTTP server."""

    def __init__(self, filepath: Path) -> None:
        """
        Create a file handler for a single markdown file.

        Args:
        - filepath (Path): Absolute or relative path to the markdown file.

        Returns:
        - None: This initializer stores normalized paths for later operations.
        """

        self._filepath = filepath.expanduser().resolve()
        self._lock_path = self._filepath.with_suffix(f"{self._filepath.suffix}.lock")
        self._lock_created = False

    @property
    def filepath(self) -> Path:
        """
        Expose the markdown file path served by this handler.

        Args:
        - None (None): This property does not accept arguments.

        Returns:
        - Path: The resolved markdown file path for read and write operations.
        """

        return self._filepath

    def read(self) -> str:
        """
        Read markdown content from disk using a shared lock.

        Args:
        - None (None): This method reads from the configured path only.

        Returns:
        - str: UTF-8 decoded markdown content currently stored on disk.
        """

        if not self._filepath.exists():
            raise FileReadError(f"File does not exist: {self._filepath}")

        try:
            with self._acquire_lock(exclusive=False):
                return self._read_text_from_disk()
        except FileWriteError:
            # Some network-backed filesystems, including WSL shares opened from
            # Windows, can reject advisory locks even though normal reads work.
            return self._read_text_from_disk()

    def write(self, content: str) -> bool:
        """
        Persist markdown content atomically using an exclusive lock.

        Args:
        - content (str): Full markdown document content to save.

        Returns:
        - bool: True when content is written and moved into place successfully.
        """

        try:
            with self._acquire_lock(exclusive=True):
                return self._write_without_lock(content)
        except FileWriteError:
            # Some network-backed filesystems, including WSL shares opened from
            # Windows, can reject advisory locks even though normal writes work.
            return self._write_without_lock(content)

    def get_metadata(self) -> dict[str, Any]:
        """
        Return current file metadata used by API responses.

        Args:
        - None (None): This method inspects the configured markdown file only.

        Returns:
        - dict[str, Any]: File size and timestamp metadata for the markdown file.
        """

        if not self._filepath.exists():
            raise FileReadError(f"File does not exist: {self._filepath}")

        try:
            stat_result = self._filepath.stat()
        except OSError as exc:
            raise FileReadError(f"Failed to inspect file: {self._filepath}") from exc

        return {
            "path": str(self._filepath),
            "size_bytes": stat_result.st_size,
            "modified_at": stat_result.st_mtime,
            "created_at": stat_result.st_ctime,
        }

    def cleanup(self) -> None:
        """
        Remove the lock file created by this handler instance.

        Args:
        - None (None): This method operates on the handler's tracked lock path.

        Returns:
        - None: Cleanup has best-effort semantics and never raises.
        """

        if not self._lock_created:
            return

        try:
            if self._lock_path.exists():
                self._lock_path.unlink()
        except OSError:
            return

    def _read_text_from_disk(self) -> str:
        """
        Read and decode the markdown file from disk without lock handling.

        Args:
        - None (None): This helper reads the configured file path only.

        Returns:
        - str: UTF-8 decoded markdown content from disk.
        """

        try:
            return self._filepath.read_text(encoding="utf-8")
        except UnicodeDecodeError as exc:
            raise FileReadError(
                f"File is not valid UTF-8 text: {self._filepath}"
            ) from exc
        except OSError as exc:
            raise FileReadError(f"Failed to read file: {self._filepath}") from exc

    def _write_without_lock(self, content: str) -> bool:
        """
        Persist markdown content atomically without acquiring a file lock.

        Args:
        - content (str): Full markdown document content to save.

        Returns:
        - bool: True when content is written and moved into place successfully.
        """

        temp_path = self._write_temporary_file(content)
        try:
            os.replace(temp_path, self._filepath)
        except OSError as exc:
            self._safe_remove(temp_path)
            raise FileWriteError(f"Failed to replace file: {self._filepath}") from exc
        return True

    @contextmanager
    def _acquire_lock(self, exclusive: bool) -> Iterator[None]:
        """
        Acquire and release a cross-platform file lock around an operation.

        Args:
        - exclusive (bool): True for write locks, False for shared read locks.

        Returns:
        - Iterator[None]: Context manager yielding control while the lock is held.
        """

        try:
            self._lock_path.parent.mkdir(parents=True, exist_ok=True)
            lock_file_context = self._lock_path.open("a+", encoding="utf-8")
        except OSError as exc:
            raise FileWriteError(f"Failed to open lock file: {self._lock_path}") from exc

        with lock_file_context as lock_file:
            self._lock_created = True
            lock_flags = portalocker.LOCK_EX if exclusive else portalocker.LOCK_SH
            try:
                portalocker.lock(lock_file, lock_flags)
            except portalocker.LockException as exc:
                raise FileWriteError(f"Failed to acquire lock: {self._lock_path}") from exc
            try:
                yield
            finally:
                portalocker.unlock(lock_file)

    def _write_temporary_file(self, content: str) -> Path:
        """
        Write content to a temporary file and fsync it.

        Args:
        - content (str): Markdown content to stage before atomic replacement.

        Returns:
        - Path: Temporary file path that contains the full staged content.
        """

        self._filepath.parent.mkdir(parents=True, exist_ok=True)
        file_descriptor, temp_name = tempfile.mkstemp(
            prefix=f".{self._filepath.name}.",
            suffix=".tmp",
            dir=str(self._filepath.parent),
        )
        temp_path = Path(temp_name)

        try:
            with os.fdopen(file_descriptor, "w", encoding="utf-8") as temp_file:
                temp_file.write(content)
                temp_file.flush()
                os.fsync(temp_file.fileno())
        except OSError as exc:
            self._safe_remove(temp_path)
            raise FileWriteError(
                f"Failed to write temporary file for: {self._filepath}"
            ) from exc

        return temp_path

    def _safe_remove(self, path: Path) -> None:
        """
        Remove a temporary file while suppressing cleanup failures.

        Args:
        - path (Path): Temporary path that should be removed if it exists.

        Returns:
        - None: Cleanup has best-effort semantics and never raises.
        """

        try:
            if path.exists():
                path.unlink()
        except OSError:
            return
