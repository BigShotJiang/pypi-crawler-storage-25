"""Command-line interface for Agent Berlin SDK.

This module provides CLI commands for managing workflows and reports through
a manifest-driven surface. Workflows share apply/publish/run; reports share
apply/get/publish (bundle-based — the whole report directory is the unit of
publish).
"""

import io
import json
import os
import sys
import tarfile
from pathlib import Path
from typing import Any, Optional

import click
import requests

from . import __version__
from .config import DEFAULT_BASE_URL
from .session import configure_session as _configure_session
from .session import load_session_config


@click.group()
@click.version_option(version=__version__, prog_name="agentberlin")
def main() -> None:
    """Agent Berlin CLI - manage workflows and reports."""
    pass


@main.command(hidden=True)
@click.option("--otp", required=True, help="One-time password from the MCP get_setup_instructions response")
@click.option("--domain", "-d", required=True, help="Project domain (e.g., example.com)")
@click.option("--title", required=True, help="Short description of what this session is for, inferred from the user's request")
@click.option("--config-path", help="Custom config file path")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def configure(otp: str, domain: str, title: str, config_path: Optional[str], base_url: str) -> None:
    """Exchange an OTP for a session token and persist it for subsequent CLI use.

    Hidden by design: this command is invoked indirectly by the MCP client
    bootstrap flow, not by humans typing it from --help.
    """
    # The exchange endpoint lives at /cli/exchange-otp on the API root, while
    # the SDK base URL is rooted at /sdk. Strip the /sdk suffix when present
    # so a non-default --base-url (local dev, staging) keeps working.
    api_root = base_url.rstrip("/")
    if api_root.endswith("/sdk"):
        api_root = api_root[: -len("/sdk")]
    exchange_url = f"{api_root}/cli/exchange-otp"

    try:
        resp = requests.post(
            exchange_url,
            json={"otp": otp, "project_domain": domain, "title": title},
            timeout=30,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to reach exchange endpoint: {e}")

    if resp.status_code != 200:
        # Surface the server's message verbatim when it returned JSON, else
        # fall back to the status text. Echo's CustomHTTPErrorHandler returns
        # {"message": "..."} for HTTPError; tolerate either shape.
        try:
            body = resp.json()
            detail = body.get("message") or body.get("error") or resp.text
        except ValueError:
            detail = resp.text or resp.reason
        raise click.ClickException(f"OTP exchange failed ({resp.status_code}): {detail}")

    token = resp.json().get("token")
    if not token:
        raise click.ClickException("Exchange response did not include a token")

    _configure_session(token, domain, config_path=config_path)
    click.echo(f"Session configured for domain: {domain}")


def _resolve_project_domain(project_domain: Optional[str]) -> str:
    """Resolve project_domain from CLI arg or session config."""
    if project_domain:
        return project_domain
    config = load_session_config()
    resolved = config.get("project_domain")
    if not resolved:
        raise click.ClickException(
            "No project domain found. Use --project-domain or configure session first."
        )
    return resolved


@main.group("brand")
def brand_group() -> None:
    """Inspect the project's brand profile and fetch brand context files."""
    pass


def _fetch_brand_profile(
    base_url: str, headers: dict[str, str], project_domain: str
) -> dict[str, Any]:
    try:
        resp = requests.post(
            f"{base_url}/brand/profile",
            headers=headers,
            json={"project_domain": project_domain},
            timeout=30,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Brand profile")
    return resp.json()


def _fetch_brand_files(
    base_url: str, headers: dict[str, str], project_domain: str
) -> list[dict[str, Any]]:
    try:
        resp = requests.post(
            f"{base_url}/brand/files/list",
            headers=headers,
            json={"project_domain": project_domain},
            timeout=30,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Brand file list")
    return resp.json().get("files", []) or []


@brand_group.command("info")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON instead of a key-value table")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def brand_info(
    project_domain: Optional[str],
    token: Optional[str],
    as_json: bool,
    base_url: str,
) -> None:
    """Print the brand profile and the catalog of brand context files.

    File contents aren't fetched here — use `agentberlin brand get <file_id>`
    to pull a specific file's bytes onto disk.
    """
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    profile = _fetch_brand_profile(base_url, headers, project_domain)
    files = _fetch_brand_files(base_url, headers, project_domain)

    if as_json:
        click.echo(json.dumps({"profile": profile, "files": files}, indent=2))
        return

    def _fmt_list(values: Any) -> str:
        if not values:
            return "(none)"
        return ", ".join(str(v) for v in values)

    rows: list[tuple[str, str]] = [
        ("domain", profile.get("domain") or "(empty)"),
        ("name", profile.get("name") or "(empty)"),
        ("industries", _fmt_list(profile.get("industries"))),
        ("business_models", _fmt_list(profile.get("business_models"))),
        ("company_size", profile.get("company_size") or "(empty)"),
        ("target_customer_segments", _fmt_list(profile.get("target_customer_segments"))),
        ("geographies", _fmt_list(profile.get("geographies"))),
        ("competitors", _fmt_list(profile.get("competitors"))),
        ("domain_authority", str(profile.get("domain_authority")) if profile.get("domain_authority") else "(none)"),
        ("sitemaps", _fmt_list(profile.get("sitemaps"))),
        ("profile_urls", _fmt_list(profile.get("profile_urls"))),
    ]
    key_w = max(len(k) for k, _ in rows)
    for key, val in rows:
        click.echo(f"{key:<{key_w}}  {val}")

    topics = profile.get("topics") or []
    click.echo(f"{'topics':<{key_w}}  {f'{len(topics)} tracked' if topics else '(none)'}")
    for t in topics:
        value = t.get("value", "")
        extras: list[str] = []
        if t.get("pillar_page_url"):
            extras.append(f"pillar={t['pillar_page_url']}")
        if t.get("landing_page_url"):
            extras.append(f"landing={t['landing_page_url']}")
        line = f"  - {value}"
        if extras:
            line += f"  ({', '.join(extras)})"
        click.echo(line)

    context = profile.get("brand_context")
    if context:
        click.echo("brand_context:")
        # The brand context is multi-section markdown that can run to several KB.
        # Truncate in CLI to keep terminal output scannable; use the API for full content.
        if len(context) > 500:
            click.echo(context[:500] + "\n… (truncated, use API for full content)")
        else:
            click.echo(context)

    click.echo("")
    if not files:
        click.echo("brand files: (none)")
        return

    click.echo(f"brand files ({len(files)}):")
    id_w = max(len("ID"), max(len(f["id"]) for f in files))
    name_w = max(len("FILENAME"), max(len(f["filename"]) for f in files))
    click.echo(f"  {'ID':<{id_w}}  {'FILENAME':<{name_w}}  {'SIZE':>10}  DESCRIPTION")
    for f in files:
        size_kb = f.get("size_bytes", 0) / 1024
        size_str = f"{size_kb:.1f} KB"
        desc = f.get("description", "") or ""
        click.echo(f"  {f['id']:<{id_w}}  {f['filename']:<{name_w}}  {size_str:>10}  {desc}")


@brand_group.command("get")
@click.argument("file_id")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    help="Output file path. Defaults to the original filename in the current directory.",
)
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def brand_get(
    file_id: str,
    project_domain: Optional[str],
    token: Optional[str],
    output: Optional[str],
    base_url: str,
) -> None:
    """Download a brand file's contents by its ID.

    FILE_ID is the file identifier shown by `agentberlin brand info`.
    """
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/brand/files/content",
            headers=headers,
            json={"project_domain": project_domain, "file_id": file_id},
            timeout=120,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Brand file '{file_id}' not found.")
    _handle_api_error(resp, "Brand file download")

    if output:
        out_path = Path(output)
    else:
        # Extract filename from Content-Disposition, fall back to file_id.
        disposition = resp.headers.get("Content-Disposition", "")
        filename = file_id
        if "filename=" in disposition:
            filename = disposition.split("filename=", 1)[1].strip().strip('"')
        out_path = Path.cwd() / filename

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(resp.content)
    click.echo(f"Downloaded: {out_path} ({len(resp.content)} bytes)")


@main.group("findings")
def findings_group() -> None:
    """Save and fetch research/analysis findings for a project."""
    pass


def _infer_finding_artifact_type(file_path: Path, override: Optional[str]) -> str:
    """Resolve a finding's artifact_type from explicit override or file extension."""
    if override:
        return override
    ext = file_path.suffix.lower()
    if ext in (".md", ".markdown"):
        return "markdown"
    if ext == ".json":
        return "json"
    raise click.ClickException(
        f"Cannot infer artifact_type from extension '{ext}'. "
        "Pass --type markdown or --type json, or rename the file."
    )


@findings_group.command("save")
@click.argument("file_path", type=click.Path(exists=True, dir_okay=False))
@click.option("--title", required=True, help="Human-readable title for the finding.")
@click.option("--description", default=None, help="Optional one-line summary.")
@click.option("--source", default=None, help="Optional attribution (e.g. 'MCP research session').")
@click.option("--generated-by", default=None, help="Optional operator name or email.")
@click.option(
    "--type",
    "artifact_type",
    type=click.Choice(["markdown", "json"]),
    default=None,
    help="Inferred from the file extension if omitted.",
)
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def findings_save(
    file_path: str,
    title: str,
    description: Optional[str],
    source: Optional[str],
    generated_by: Optional[str],
    artifact_type: Optional[str],
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Upload a markdown or JSON file as a new finding for the given project."""
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)
    path = Path(file_path)
    resolved_type = _infer_finding_artifact_type(path, artifact_type)

    headers = {"Authorization": f"Bearer {token}"}
    data: dict[str, str] = {
        "project_domain": project_domain,
        "title": title,
        "artifact_type": resolved_type,
    }
    if description:
        data["description"] = description
    if source:
        data["source"] = source
    if generated_by:
        data["generated_by"] = generated_by

    with path.open("rb") as fp:
        files = {"file": (path.name, fp, "application/octet-stream")}
        try:
            resp = requests.post(
                f"{base_url}/findings/save",
                headers=headers,
                data=data,
                files=files,
                timeout=120,
            )
        except requests.RequestException as e:
            raise click.ClickException(f"Failed to connect to API: {e}")

    _handle_api_error(resp, "Finding save")
    body = resp.json()
    click.echo(f"Saved finding {body['id']} (\"{body['title']}\") for {project_domain}")


@findings_group.command("list")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON instead of a table")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def findings_list(
    project_domain: Optional[str],
    token: Optional[str],
    as_json: bool,
    base_url: str,
) -> None:
    """List findings for the given project."""
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/findings/list",
            headers=headers,
            json={"project_domain": project_domain},
            timeout=30,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Findings list")

    findings = resp.json().get("findings", []) or []
    if as_json:
        click.echo(json.dumps(findings, indent=2))
        return

    if not findings:
        click.echo("findings: (none)")
        return

    click.echo(f"findings ({len(findings)}):")
    id_w = max(len("ID"), max(len(f["id"]) for f in findings))
    type_w = max(len("TYPE"), max(len(f.get("artifact_type", "")) for f in findings))
    title_w = max(len("TITLE"), max(len(f["title"]) for f in findings))
    click.echo(f"  {'ID':<{id_w}}  {'TYPE':<{type_w}}  {'TITLE':<{title_w}}  GENERATED BY")
    for f in findings:
        click.echo(
            f"  {f['id']:<{id_w}}  "
            f"{f.get('artifact_type', ''):<{type_w}}  "
            f"{f['title']:<{title_w}}  "
            f"{f.get('generated_by', '') or '—'}"
        )


@findings_group.command("get")
@click.argument("finding_id")
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    help="Output file path. Defaults to <slug>.<ext> in the current directory.",
)
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def findings_get(
    finding_id: str,
    project_domain: Optional[str],
    token: Optional[str],
    output: Optional[str],
    base_url: str,
) -> None:
    """Download a finding's contents by its ID.

    FINDING_ID is the identifier shown by `agentberlin findings list`.
    """
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/findings/get",
            headers=headers,
            json={"project_domain": project_domain, "finding_id": finding_id},
            timeout=120,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Finding '{finding_id}' not found.")
    _handle_api_error(resp, "Finding download")

    if output:
        out_path = Path(output)
    else:
        disposition = resp.headers.get("Content-Disposition", "")
        filename = finding_id
        if "filename=" in disposition:
            filename = disposition.split("filename=", 1)[1].strip().strip('"')
        out_path = Path.cwd() / filename

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(resp.content)
    click.echo(f"Downloaded: {out_path} ({len(resp.content)} bytes)")


@findings_group.command("update")
@click.argument("finding_id")
@click.option("--file", "file_path", type=click.Path(exists=True, dir_okay=False), default=None, help="Replace the finding's content with this file.")
@click.option("--title", default=None, help="New title.")
@click.option("--description", default=None, help="New description.")
@click.option("--source", default=None, help="New source attribution.")
@click.option("--generated-by", default=None, help="New operator attribution.")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def findings_update(
    finding_id: str,
    file_path: Optional[str],
    title: Optional[str],
    description: Optional[str],
    source: Optional[str],
    generated_by: Optional[str],
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Update an existing finding's metadata and/or content."""
    if not any([file_path, title, description, source, generated_by]):
        raise click.ClickException("Nothing to update. Pass --file and/or one of --title/--description/--source/--generated-by.")

    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}"}
    data: dict[str, str] = {
        "project_domain": project_domain,
        "finding_id": finding_id,
    }
    if title:
        data["title"] = title
    if description:
        data["description"] = description
    if source:
        data["source"] = source
    if generated_by:
        data["generated_by"] = generated_by

    files = None
    fp = None
    try:
        if file_path:
            path = Path(file_path)
            fp = path.open("rb")
            files = {"file": (path.name, fp, "application/octet-stream")}
        try:
            resp = requests.post(
                f"{base_url}/findings/update",
                headers=headers,
                data=data,
                files=files,
                timeout=120,
            )
        except requests.RequestException as e:
            raise click.ClickException(f"Failed to connect to API: {e}")
    finally:
        if fp is not None:
            fp.close()

    if resp.status_code == 404:
        raise click.ClickException(f"Finding '{finding_id}' not found.")
    _handle_api_error(resp, "Finding update")
    body = resp.json()
    click.echo(f"Updated finding {body['id']} (\"{body['title']}\")")


WORKFLOW_GROUP_HELP = """Manage workflows (list, get, apply, validate, publish, submit).

A workflow is one Python script that runs on a cadence and writes
output.json. Lifecycle: `apply` upserts metadata → `validate` then `publish`
upload the built artefacts → the runtime processor calls `submit` after each
run.

\b
Commands:
  list      Print every workflow in the project as a markdown table (id,
            name, cadence, last run).
  get       Download a workflow's synthesized manifest, spec.json, and
            latest output.json into <output-dir> (defaults to
            workflows/<id>/).
  apply     Upsert metadata from a manifest. POST if the manifest has no `id`,
            PATCH otherwise. Editing `details` bumps the version and triggers
            a rebuild.
  validate  Run py_compile + mypy + OutputSchema(BaseModel) checks on a
            main.py and emit a JSON pass/fail report. Run before publish.
  publish   Upload built artefacts (main.py + spec.json + api_estimate.json)
            onto the latest version.
  submit    Upload a run's output.json (and stdout/stderr) to the artifacts
            endpoint. Invoked by the runtime processor; rare for direct use.

MANIFEST FORMAT
===============

\b
{
  "kind": "workflow",
  "id": "wfl_abc123xyz",
  "name": "My Workflow",
  "description": "Optional description",
  "details": "Natural-language spec describing what the workflow does",
  "schedule": {"cadence": "weekly"}
}

\b
Required: kind ("workflow"), name (first apply), id (subsequent calls — CLI
writes it back after the first POST).

\b
schedule.cadence is one of: daily, weekly, monthly, quarterly, manual.
Omit `schedule` (or use "manual") for run-on-demand workflows. The concrete
day/hour is chosen server-side per workflow so runs spread across the
calendar; re-applying the same cadence is stable. Schedules stay disabled
until the workflow reaches the "ready" phase.
"""


REPORT_GROUP_HELP = """Manage the report (apply, get, publish, list, design).

A report is a directory of pages on S3. The report root carries a
`structure.json` listing every page, and each page is its own sub-directory
holding an `index.html` (+ optional `spec.json`, `data.json`). The viewer
renders one page at a time; navigation between pages is done by the
workspace around the iframe.

LIFECYCLE
=========
  - `apply` upserts metadata (including `details`, a free-text brief of the
    report's intended data shape). Persists the row only — does NOT push any
    files.
  - `get` downloads the current bundle as a tarball; after editing files
    locally, `publish` uploads the whole directory back as a new bundle.
    There is no per-file or per-page verb.

\b
Commands:
  list      Print the project's report as a markdown table (name, last
            updated).
  get       Download the report's bundle (synthesized manifest.json +
            structure.json + every page's files) as a directory tree into
            <output-dir>. On a freshly-applied row with no published bundle
            yet, get returns an empty-scaffold structure.json so the
            workflow is uniform.
  apply     Upsert metadata from a manifest. POST if the manifest has no `id`,
            PATCH otherwise. Persists `details`/title/description on the row
            without pushing any files.
  publish   Tar the directory at --dir and upload it as the report's new
            bundle. structure.json is committed last server-side so partial
            failures leave the prior shape in place.
  design    Print the authoritative report design guide (CSS tokens, type
            ramp, component recipes). Read this before authoring or editing
            any report HTML.

MANIFEST FILE FORMAT
====================

The manifest is row-identity only. The page list lives in `structure.json`
inside the bundle directory, not in the manifest.

\b
{
  "kind": "report",
  "id": "rpt_abc123xyz",
  "name": "Audit",
  "description": "Optional description",
  "details": "Free-text brief describing the report's intended data shape."
}

REQUIRED FIELDS
===============
  kind  - Must be "report"
  id    - Absent on first apply (CLI writes it back); required to look the
          row up on apply later.

OPTIONAL FIELDS
===============
  name        - Display title (maps to the report's `title` column)
  description - Report description
  details     - Free-text brief describing the report's intended data shape.
                Required on first apply.

BUNDLE LAYOUT (under --dir for publish, written by get)
=======================================================

\b
<bundle-dir>/
├── manifest.json           (synthesized; agent ignores this on edit)
├── structure.json          (source of truth for which pages exist)
├── <page_slug>/
│   ├── index.html
│   ├── spec.json           (optional)
│   └── data.json           (optional)
└── ...

structure.json shape (version 1):
\b
{
  "version": 1,
  "default_page": "overview",
  "pages": [
    {"slug": "overview", "title": "Overview"},
    {"slug": "keywords", "title": "Keywords"}
  ]
}

BEHAVIOR
========
  - `publish` re-validates structure.json against the directories present in
    the bundle; orphan directories or missing page index.html files are
    rejected with 400.
"""


ACTION_GROUP_HELP = """Manage actions (create).

An action is a single todo item attached to a project's task list. Each
action has a category — a stable key that classifies it for scoring and
filtering. The wire field is `template_key`; the CLI surfaces it as
`--category`.

\b
Commands:
  create   Create a new action with a title, description, and category.

AVAILABLE CATEGORIES (--category)
=================================

\b
Citation family — off-site authority:
  citation_create_post            Forum/Community Post
  citation_comment                Thread/Video/Social Comment
  citation_post_question          Q&A Question
  citation_post_answer            Q&A Answer
  citation_publish_review         Review/Rating
  citation_update_review          Review Update
  citation_respond_feedback       Feedback Response
  citation_directory_submit       Directory Submission
  citation_backlink_email         Backlink Outreach
  citation_wiki_edit_request      Wiki Edit
  citation_profile_page_create    Profile Page
  citation_social_media_activity  Social Media Activity

\b
Content Create family — net-new assets:
  content_create_blog_post        Blog Post
  content_create_pillar_page      Pillar Page
  content_create_landing_page     Landing Page
  content_create_video            Video
  content_create_free_tool        Free Tool

\b
Content Update family — refresh existing assets:
  content_update_internal_links   Internal Link
  content_update_metadata         Metadata Update
  content_update_header_structure Header Structure Update
  content_update_expand_post      Post Expansion
  content_update_republish        Content Republishing

\b
Technical family:
  technical_add_schema            Schema/Structured Data
  technical_fix_404               404 Error Fix
  technical_fix_robots            Robots.txt Fix
  technical_better_bot_access     Bot Access Improvement
  technical_improve_performance   Performance Improvement
  technical_sitemap_audit         Sitemap Audit
  technical_accessibility_audit   Accessibility Audit

\b
Validation family:
  validation_verify_topic_pages   Topic Page Verification

\b
Custom family:
  custom_uncategorized            Uncategorized Action

EXAMPLE
=======

\b
agentberlin action create \\
    --title "Publish Q3 backlink outreach email" \\
    --description "Send template B to 12 SaaS reviewers" \\
    --category citation_backlink_email
"""


def _handle_api_error(resp: requests.Response, context: str = "API request") -> None:
    """Handle API error responses with appropriate messages."""
    if resp.status_code == 401:
        raise click.ClickException("Authentication failed. Check your token.")
    if resp.status_code == 400:
        error_data = resp.json()
        # Check for validation errors (syntax/type check failures)
        if "validation_errors" in error_data:
            click.echo("Script validation failed:", err=True)
            for err in error_data["validation_errors"]:
                click.echo(f"  - {err}", err=True)
            raise click.ClickException("Fix the errors above and try again")
        error_msg = error_data.get("error", "Bad request")
        raise click.ClickException(f"{context} failed: {error_msg}")
    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise click.ClickException(f"{context} failed: {e}")


def _resolve_token(token: Optional[str]) -> str:
    """Resolve API token from CLI arg, env, or session config."""
    if token:
        return token
    config = load_session_config()
    resolved = config.get("token")
    if not resolved:
        raise click.ClickException("No API token found. Set AGENTBERLIN_TOKEN or configure session first.")
    return resolved


def _load_manifest(manifest: str, expected_kind: str) -> tuple[dict[str, Any], Path]:
    """Load and validate a manifest JSON file for the given kind.

    Validates `kind` matches the calling CLI group, and rejects fields that
    don't apply to that kind (schedule on report). Does NOT enforce id
    presence — callers decide whether id is required (e.g. publish requires
    it; apply does not).
    """
    manifest_path = Path(manifest)
    try:
        data = json.loads(manifest_path.read_text())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"Invalid manifest JSON: {e}")
    if not isinstance(data, dict):
        raise click.ClickException("Manifest must be a JSON object")

    kind = data.get("kind")
    if kind != expected_kind:
        if kind is None:
            raise click.ClickException(
                f"manifest is missing 'kind'. Add `\"kind\": \"{expected_kind}\"`."
            )
        raise click.ClickException(
            f"manifest kind is {kind!r}; this command requires kind={expected_kind!r}."
        )

    if expected_kind == "report":
        if "schedule" in data:
            raise click.ClickException(
                "'schedule' is a workflow-only field. Remove it from a report manifest."
            )
        if "slug" in data:
            raise click.ClickException(
                "'slug' is no longer a manifest field. Remove it from the report manifest."
            )

    return data, manifest_path


def _build_workflow_payload(manifest_data: dict[str, Any]) -> dict[str, Any]:
    """Extract workflow metadata fields (name, description, details, schedule)
    from a manifest. Only includes keys present and non-empty.

    Used as the body for POST /workflows and PATCH /workflows/:id.
    """
    if not manifest_data.get("name"):
        raise click.ClickException("workflow manifest must include 'name'.")
    payload: dict[str, Any] = {"name": manifest_data["name"]}
    description = manifest_data.get("description")
    if description:
        payload["description"] = description
    details = manifest_data.get("details")
    if details:
        payload["details"] = details
    schedule = manifest_data.get("schedule")
    if schedule:
        payload["schedule"] = schedule
    return payload


def _build_report_create_payload(manifest_data: dict[str, Any], project_domain: str) -> dict[str, Any]:
    """Build the JSON body for POST /reports from a report manifest.

    Includes project_domain (route resolution) and any of name→title,
    description, details that the manifest carries. The report DB column is
    `title`; the manifest field is `name` (so both kinds share one
    human-readable label key). Maps name → title here.
    """
    payload: dict[str, Any] = {
        "slug": _REPORT_SLUG,
        "project_domain": project_domain,
    }
    if title := manifest_data.get("name"):
        payload["title"] = title
    if description := manifest_data.get("description"):
        payload["description"] = description
    if details := manifest_data.get("details"):
        payload["details"] = details
    return payload


def _build_report_metadata_update_payload(manifest_data: dict[str, Any]) -> dict[str, Any]:
    """Build the content fields for PATCH /reports/:slug from a manifest.

    Returns only title/description/details that the manifest carries —
    pointer-presence on the backend leaves omitted columns alone, so callers
    can refresh a single field without re-sending the rest. Returns an empty
    dict when the manifest carries no metadata changes; the verb layer treats
    that as a no-op. project_domain (routing) is added by the helper, not
    here — the builder owns content, the helper owns the wire payload.
    """
    payload: dict[str, Any] = {}
    if title := manifest_data.get("name"):
        payload["title"] = title
    if description := manifest_data.get("description"):
        payload["description"] = description
    if details := manifest_data.get("details"):
        payload["details"] = details
    return payload


def _post_create_workflow(base_url: str, headers: dict[str, str], payload: dict[str, Any]) -> str:
    """Call POST /workflows. Returns the new workflow_id."""
    try:
        resp = requests.post(f"{base_url}/workflows", headers=headers, json=payload, timeout=60)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Workflow creation")
    return resp.json()["workflow_id"]


def _patch_workflow(
    base_url: str, headers: dict[str, str], workflow_id: str, payload: dict[str, Any]
) -> dict[str, Any]:
    """Call PATCH /workflows/:id. Returns the response JSON."""
    try:
        resp = requests.patch(f"{base_url}/workflows/{workflow_id}", headers=headers, json=payload, timeout=60)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 404:
        raise click.ClickException(f"Workflow '{workflow_id}' not found.")
    _handle_api_error(resp, "Workflow update")
    return resp.json()


def _post_publish_workflow_version(
    base_url: str,
    headers: dict[str, str],
    workflow_id: str,
    files_map: dict[str, str],
    cost_estimate: Optional[dict[str, Any]],
) -> dict[str, Any]:
    """Call POST /workflows/:id/versions/current/files. Returns the response JSON."""
    body: dict[str, Any] = {"files": files_map}
    if cost_estimate is not None:
        body["cost_estimate"] = cost_estimate
    try:
        resp = requests.post(
            f"{base_url}/workflows/{workflow_id}/versions/current/files",
            headers=headers,
            json=body,
            timeout=60,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 404:
        raise click.ClickException(
            f"Workflow '{workflow_id}' not found, or no version exists yet."
        )
    _handle_api_error(resp, "Workflow publish")
    return resp.json()


def _raise_report_not_found_if_404(resp: requests.Response, slug: str) -> None:
    """If `resp` is a 404, raise a friendly ClickException pointing the
    caller at the upstream verb that should have created the row.

    Centralised so all three of metadata/layout/submit surface the same
    message — they all assume the row was persisted by `report apply`."""
    if resp.status_code == 404:
        raise click.ClickException(
            f"Report '{slug}' not found. Run `agentberlin report apply -m manifest.json` first."
        )


def _post_create_report(
    base_url: str, headers: dict[str, str], payload: dict[str, Any]
) -> dict[str, Any]:
    """Call POST /reports with a JSON body. Returns the response JSON
    (includes report_id, url)."""
    try:
        resp = requests.post(f"{base_url}/reports", headers=headers, json=payload, timeout=120)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 409:
        error_msg = resp.json().get("error", "Report already exists")
        raise click.ClickException(error_msg)
    _handle_api_error(resp, "Report create")
    return resp.json()


def _patch_report_metadata(
    base_url: str,
    headers: dict[str, str],
    slug: str,
    project_domain: str,
    content: dict[str, Any],
) -> dict[str, Any]:
    """Call PATCH /reports/:slug with a JSON body. `content` carries the
    title/description/details fields the caller wants to update; the helper
    adds project_domain (routing) and ships them as a single body. Used by
    `report apply` against an existing row."""
    body = {"project_domain": project_domain, **content}
    try:
        resp = requests.patch(
            f"{base_url}/reports/{slug}",
            headers=headers,
            json=body,
            timeout=120,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _raise_report_not_found_if_404(resp, slug)
    _handle_api_error(resp, "Report update")
    return resp.json()


def _put_report_bundle(
    base_url: str,
    headers: dict[str, str],
    slug: str,
    project_domain: str,
    tarball_bytes: bytes,
) -> dict[str, Any]:
    """Call PUT /reports/:slug/bundle with a multipart body carrying the
    gzipped tarball of the report directory as `file`. Used by
    `report publish`. Server validates the bundle (structure.json present,
    pages line up with directories, no path escapes) and replaces the live
    tree atomically (structure.json commits last)."""
    try:
        files = {"file": (f"{slug}.tar.gz", tarball_bytes, "application/gzip")}
        resp = requests.put(
            f"{base_url}/reports/{slug}/bundle",
            headers=headers,
            data={"project_domain": project_domain},
            files=files,
            timeout=300,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _raise_report_not_found_if_404(resp, slug)
    _handle_api_error(resp, "Report publish")
    return resp.json()


def _get_report_bundle(
    base_url: str,
    headers: dict[str, str],
    slug: str,
    project_domain: str,
) -> bytes:
    """Call GET /reports/:slug/bundle?project_domain=... and return the raw
    tarball body. Used by `report get`."""
    try:
        resp = requests.get(
            f"{base_url}/reports/{slug}/bundle",
            headers=headers,
            params={"project_domain": project_domain},
            timeout=300,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 404:
        raise click.ClickException(f"Report '{slug}' not found.")
    _handle_api_error(resp, "Report get")
    return resp.content


def _write_id_to_manifest(manifest_path: Path, manifest_data: dict[str, Any], new_id: str) -> None:
    """Persist the assigned id back to the manifest file (workflow or report)."""
    manifest_data["id"] = new_id
    manifest_path.write_text(json.dumps(manifest_data, indent=2))


def _load_json_file(path: str, field_name: str, require_object: bool) -> None:
    """Validate a path is a readable JSON file (and optionally a top-level object).

    Raises click.ClickException with a friendly message on failure. Does not
    return the parsed JSON — callers upload the raw bytes, this is only a
    fail-fast check before hitting the network.
    """
    p = Path(path)
    if p.suffix.lower() != ".json":
        raise click.ClickException(f"--{field_name} must be a .json file")
    try:
        parsed = json.loads(p.read_bytes())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"--{field_name} is not valid JSON: {e}")
    if require_object and not isinstance(parsed, dict):
        raise click.ClickException(f"--{field_name} must be a JSON object at the top level")


@main.group("workflow", help=WORKFLOW_GROUP_HELP)
def workflow_group() -> None:
    pass


_WORKFLOW_APPLY_HELP = """Upsert workflow metadata from a manifest.

If the manifest has no `id`, POSTs a new workflow row and writes the assigned
`id` back to the manifest file. If the manifest already has an `id`, PATCHes
the existing row. Subsequent calls (apply, publish, submit, run) all require
the manifest to carry an `id`.

Editing `details` bumps the workflow version and flags it for rebuild.

See `agentberlin workflow --help` for the manifest format reference.
"""


@workflow_group.command("apply", help=_WORKFLOW_APPLY_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_apply(manifest: str, token: Optional[str], base_url: str) -> None:
    token = _resolve_token(token)
    manifest_data, manifest_path = _load_manifest(manifest, "workflow")
    payload = _build_workflow_payload(manifest_data)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    workflow_id = manifest_data.get("id")
    if workflow_id:
        result = _patch_workflow(base_url, headers, workflow_id, payload)
        click.echo(f"Workflow updated: {result.get('name', payload['name'])} ({workflow_id})")
        phase = result.get("phase")
        if phase:
            click.echo(f"Phase: {phase}")
    else:
        new_id = _post_create_workflow(base_url, headers, payload)
        _write_id_to_manifest(manifest_path, manifest_data, new_id)
        click.echo(f"Created workflow: {payload['name']} ({new_id})")


_WORKFLOW_VALIDATE_HELP = """Validate a workflow main.py before publishing.

Runs three checks against the file at PATH:
  1. py_compile — syntax.
  2. mypy       — types.
  3. OutputSchema — asserts a module-level `class OutputSchema(BaseModel)`,
                    the contract the build pipeline reads to derive spec.json.

Output is JSON: `{"valid": true}` on success, or `{"valid": false, "errors":
[{"tool": "...", "message": "..."}]}` listing every failing check. Exit code
is 0 on success, 1 on validation failure.

The build agent runs this automatically before `agentberlin workflow publish`;
humans editing main.py locally should run it too."""

# outputSchemaPattern matches a module-level `class OutputSchema(BaseModel)`
# declaration. Tolerates `pydantic.BaseModel`, multiple bases, and trailing
# whitespace; rejects indented declarations (must start at column 0). Mirrors
# the previous Go validator's regex exactly so the contract is unchanged.
_OUTPUT_SCHEMA_PATTERN = r"(?m)^class\s+OutputSchema\s*\(\s*([A-Za-z_][\w.]*\s*,\s*)*(?:pydantic\.)?BaseModel\b"

_VALIDATION_TIMEOUT_SECONDS = 30


def _run_validation_subprocess(cmd: list[str], timeout: int) -> tuple[int, str]:
    """Run a validation subprocess and return (returncode, combined_output).

    On timeout, returns a non-zero return code with an explanatory message in
    place of stdout/stderr. On missing executable (FileNotFoundError) the same
    pattern applies — surfaced as a normal validation error so the agent gets
    actionable JSON instead of a stack trace.
    """
    import subprocess

    try:
        completed = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout
        )
    except subprocess.TimeoutExpired:
        return 1, f"{cmd[0]} timed out after {timeout}s"
    except FileNotFoundError:
        return 1, f"{cmd[0]} not found on PATH"
    output = (completed.stdout + completed.stderr).strip()
    return completed.returncode, output


def _has_module_level_output_schema(path: str) -> bool:
    """Read PATH and assert a module-level `class OutputSchema(BaseModel)`."""
    import re

    try:
        content = Path(path).read_text()
    except OSError:
        return False
    return re.search(_OUTPUT_SCHEMA_PATTERN, content) is not None


@workflow_group.command("validate", help=_WORKFLOW_VALIDATE_HELP)
@click.argument("path", type=click.Path(exists=True, dir_okay=False, readable=True))
def workflow_validate(path: str) -> None:
    errors: list[dict[str, str]] = []

    rc, out = _run_validation_subprocess(
        ["python3", "-m", "py_compile", path], _VALIDATION_TIMEOUT_SECONDS
    )
    if rc != 0:
        errors.append({"tool": "py_compile", "message": out.replace(path, "main.py")})

    rc, out = _run_validation_subprocess(
        ["mypy", path, "--no-error-summary"], _VALIDATION_TIMEOUT_SECONDS
    )
    if rc != 0:
        errors.append({"tool": "mypy", "message": out.replace(path, "main.py")})

    if not _has_module_level_output_schema(path):
        errors.append(
            {
                "tool": "output_schema",
                "message": (
                    "no module-level `class OutputSchema(BaseModel)` found; "
                    "the workflow contract requires a Pydantic OutputSchema "
                    "at the top level of main.py"
                ),
            }
        )

    if errors:
        click.echo(json.dumps({"valid": False, "errors": errors}))
        sys.exit(1)
    click.echo(json.dumps({"valid": True}))


_WORKFLOW_PUBLISH_HELP = """Publish built workflow files to the latest version.

Pass either --file (single file) or --dir (every regular file in the
directory). Workflow id is read from the manifest's `id` field. The server
stores files under their basename.

When --dir is used, dotfiles, __pycache__, and *.pyc are skipped.

--cost-estimate-file is required and points to a JSON file carrying the
per-resource SDK call estimate (must be a JSON object containing an
`estimates` array). Its parsed contents are sent in the request body as
`cost_estimate`; if the file lives inside --dir, its basename is dropped
from the files map so it isn't double-shipped. The manifest file itself,
if it lives inside --dir, is also dropped from the files map.

\b
Example:
    agentberlin workflow publish -m manifest.json --dir . --cost-estimate-file api_estimate.json
"""


def _load_cost_estimate(path: str) -> dict[str, Any]:
    """Read & parse the cost-estimate JSON file. Validates the top-level shape.

    The contract: a JSON object with an `estimates` array. Server-side
    parsing is strict-typed, so failing fast here gives the agent a clear
    error before the network round-trip.
    """
    try:
        parsed = json.loads(Path(path).read_text())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"--cost-estimate-file is not valid JSON: {e}")
    if not isinstance(parsed, dict):
        raise click.ClickException("--cost-estimate-file must be a JSON object")
    if not isinstance(parsed.get("estimates"), list):
        raise click.ClickException(
            "--cost-estimate-file must contain an 'estimates' array"
        )
    return parsed


def _collect_dir_files(dir_path: Path) -> dict[str, str]:
    """Read every regular file in dir_path (non-recursive) into a basename→content map.

    Skips dotfiles, __pycache__ entries, and *.pyc — these would never be
    intentional build artefacts and trip up server-side validation.
    """
    files_map: dict[str, str] = {}
    for entry in sorted(dir_path.iterdir()):
        if not entry.is_file():
            continue
        if entry.name.startswith(".") or entry.name == "__pycache__" or entry.suffix == ".pyc":
            continue
        try:
            files_map[entry.name] = entry.read_text()
        except OSError as e:
            raise click.ClickException(f"Failed to read {entry}: {e}")
    if not files_map:
        raise click.ClickException(f"No publishable files found in {dir_path}.")
    return files_map


@workflow_group.command("publish", help=_WORKFLOW_PUBLISH_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file (kind=workflow, id required).",
)
@click.option(
    "--file",
    "-f",
    "file_path",
    type=click.Path(exists=True, dir_okay=False),
    help="Path to a single file to publish (e.g. main.py).",
)
@click.option(
    "--dir",
    "-d",
    "dir_path",
    type=click.Path(exists=True, file_okay=False),
    help="Directory whose regular files (non-recursive) should be published together.",
)
@click.option(
    "--cost-estimate-file",
    "cost_estimate_path",
    type=click.Path(exists=True, dir_okay=False),
    required=True,
    help=(
        "Path to a JSON file with the workflow's per-resource SDK cost estimate. "
        "Sent in the request body as cost_estimate; excluded from the files map "
        "when --dir is used."
    ),
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_publish(
    manifest: str,
    file_path: Optional[str],
    dir_path: Optional[str],
    cost_estimate_path: str,
    token: Optional[str],
    base_url: str,
) -> None:
    if bool(file_path) == bool(dir_path):
        raise click.ClickException("Pass exactly one of --file or --dir.")
    manifest_data, manifest_path = _load_manifest(manifest, "workflow")
    workflow_id = manifest_data.get("id")
    if not workflow_id:
        raise click.ClickException(
            "manifest must include 'id'. Run `agentberlin workflow apply -m manifest.json` first."
        )
    token = _resolve_token(token)

    cost_estimate = _load_cost_estimate(cost_estimate_path)

    if file_path:
        path = Path(file_path)
        try:
            content = path.read_text()
        except OSError as e:
            raise click.ClickException(f"Failed to read {file_path}: {e}")
        files_map = {path.name: content}
        label = path.name
    else:
        assert dir_path is not None  # for type checker; click guarantees one of the two
        files_map = _collect_dir_files(Path(dir_path))
        # The cost estimate is published via its own column, not as a file —
        # drop it from the files map if it happened to live in --dir. Same for
        # the manifest file: a sibling concern, not a build artefact.
        files_map.pop(Path(cost_estimate_path).name, None)
        files_map.pop(manifest_path.name, None)
        if not files_map:
            raise click.ClickException(f"No publishable files found in {dir_path}.")
        label = f"{len(files_map)} files from {dir_path}"

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    result = _post_publish_workflow_version(
        base_url, headers, workflow_id, files_map, cost_estimate
    )
    version = result.get("version")
    if version is not None:
        click.echo(f"Published {label} to workflow {workflow_id} (version {version})")
    else:
        click.echo(f"Published {label} to workflow {workflow_id}")


_WORKFLOW_SUBMIT_HELP = """Upload a workflow run's output.json (and optional logs) artefacts.

Auto-invoked by `workflow run` after the script exits. Standalone use is rare.
"""


def _post_workflow_run_artifacts(
    base_url: str,
    token: str,
    output_bytes: Optional[bytes],
    stdout_bytes: bytes,
    stderr_bytes: bytes,
    exit_code: int,
) -> None:
    """POST stdout/stderr/output to /workflow-runs/artifacts.

    Shared by `workflow run` (in-process buffers from the script subprocess)
    and `workflow submit` (bytes read from disk). Failures print a warning
    but do not raise — the caller decides the process exit code.
    """
    files: dict[str, tuple[str, bytes, str]] = {
        "stdout": ("stdout.log", stdout_bytes, "text/plain"),
        "stderr": ("stderr.log", stderr_bytes, "text/plain"),
    }
    if output_bytes is not None:
        files["output"] = ("output.json", output_bytes, "application/json")

    headers = {"Authorization": f"Bearer {token}"}
    try:
        resp = requests.post(
            f"{base_url}/workflow-runs/artifacts",
            headers=headers,
            files=files,
            data={"exit_code": str(exit_code)},
            timeout=60,
        )
    except requests.RequestException as e:
        click.echo(f"warning: artifact upload failed (network): {e}", err=True)
        return

    if resp.status_code != 200:
        try:
            err_msg = resp.json().get("error", resp.text)
        except ValueError:
            err_msg = resp.text
        click.echo(
            f"warning: artifact upload failed (HTTP {resp.status_code}): {err_msg}",
            err=True,
        )


@workflow_group.command("submit", help=_WORKFLOW_SUBMIT_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file (kind=workflow, id required).",
)
@click.option(
    "--file",
    "output_path",
    type=click.Path(exists=True, dir_okay=False),
    required=True,
    help="Path to the run's output.json.",
)
@click.option(
    "--stdout-file",
    "stdout_path",
    type=click.Path(exists=True, dir_okay=False),
    help="Path to the run's stdout log. Defaults to empty bytes.",
)
@click.option(
    "--stderr-file",
    "stderr_path",
    type=click.Path(exists=True, dir_okay=False),
    help="Path to the run's stderr log. Defaults to empty bytes.",
)
@click.option(
    "--exit-code",
    type=int,
    default=0,
    show_default=True,
    help="Script exit code to record on the run row.",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="Sandbox token.")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_submit(
    manifest: str,
    output_path: str,
    stdout_path: Optional[str],
    stderr_path: Optional[str],
    exit_code: int,
    token: Optional[str],
    base_url: str,
) -> None:
    _load_manifest(manifest, "workflow")  # kind validation only
    token = _resolve_token(token)
    try:
        output_bytes = Path(output_path).read_bytes()
    except OSError as e:
        raise click.ClickException(f"Failed to read --file {output_path}: {e}")
    stdout_bytes = Path(stdout_path).read_bytes() if stdout_path else b""
    stderr_bytes = Path(stderr_path).read_bytes() if stderr_path else b""

    _post_workflow_run_artifacts(base_url, token, output_bytes, stdout_bytes, stderr_bytes, exit_code)
    click.echo(f"Submitted output.json ({len(output_bytes)} bytes)")


def _stream_tee(
    src: Any, sink: Any, buf: bytearray, lock: Any
) -> None:
    """Read bytes from src line-by-line, append to buf, and mirror to sink.

    Runs in a daemon thread per stream so the parent can wait on the
    process while output flows live. Bytes (not str) keep encoding
    clean for non-UTF-8 script output.
    """
    while True:
        chunk = src.readline()
        if not chunk:
            return
        with lock:
            buf.extend(chunk)
        try:
            sink.write(chunk)
            sink.flush()
        except (OSError, ValueError):
            # Parent's stdout/stderr was closed — keep buffering.
            pass


@workflow_group.command("run", hidden=True)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
)
@click.option(
    "--main",
    "main_path",
    type=click.Path(exists=True),
    default="main.py",
    show_default=True,
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_run(manifest: str, main_path: str, token: Optional[str], base_url: str) -> None:
    import subprocess
    import threading

    _load_manifest(manifest, "workflow")  # kind validation only
    token = _resolve_token(token)
    main_resolved = Path(main_path).resolve()
    cwd = main_resolved.parent

    stdout_buf = bytearray()
    stderr_buf = bytearray()
    stdout_lock = threading.Lock()
    stderr_lock = threading.Lock()

    # `-u` forces the child's stdout/stderr to be unbuffered. Without it,
    # CPython block-buffers writes to a pipe and we'd see nothing live —
    # output would only appear when the buffer filled or the process
    # exited. PYTHONUNBUFFERED is set as a belt-and-braces in case the
    # script re-execs or spawns its own python helpers.
    child_env = os.environ.copy()
    child_env["PYTHONUNBUFFERED"] = "1"
    proc = subprocess.Popen(
        [sys.executable, "-u", str(main_resolved)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd),
        env=child_env,
    )

    stdout_thread = threading.Thread(
        target=_stream_tee,
        args=(proc.stdout, sys.stdout.buffer, stdout_buf, stdout_lock),
        daemon=True,
    )
    stderr_thread = threading.Thread(
        target=_stream_tee,
        args=(proc.stderr, sys.stderr.buffer, stderr_buf, stderr_lock),
        daemon=True,
    )
    stdout_thread.start()
    stderr_thread.start()

    return_code = proc.wait()
    stdout_thread.join()
    stderr_thread.join()

    output_path = cwd / "output.json"
    output_bytes: Optional[bytes] = None
    if output_path.is_file():
        try:
            output_bytes = output_path.read_bytes()
        except OSError as e:
            click.echo(f"warning: failed to read output.json: {e}", err=True)

    _post_workflow_run_artifacts(
        base_url, token, output_bytes, bytes(stdout_buf), bytes(stderr_buf), return_code
    )
    sys.exit(return_code)


def _format_schedule_cell(schedule: Optional[dict[str, Any]]) -> str:
    """Render a manifest-shaped schedule block as a single-cell summary."""
    if not schedule:
        return "manual"
    return schedule.get("cadence") or "manual"


def _format_optional_ts(ts: Optional[str]) -> str:
    if not ts:
        return "-"
    return ts


@workflow_group.command("list")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set).")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON instead of a markdown table.")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_list(project_domain: Optional[str], token: Optional[str], as_json: bool, base_url: str) -> None:
    """List every workflow in the project as a markdown table."""
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/workflows/list",
            headers=headers,
            json={"project_domain": project_domain},
            timeout=60,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Workflow list")

    payload = resp.json()
    if as_json:
        click.echo(json.dumps(payload, indent=2))
        return

    items = payload.get("workflows", []) or []
    if not items:
        click.echo("No workflows found.")
        return

    click.echo("| ID | Name | Cadence | Last run | Last status |")
    click.echo("|---|---|---|---|---|")
    for w in items:
        name = (w.get("name") or "").replace("|", "\\|")
        schedule_cell = _format_schedule_cell(w.get("schedule"))
        last_run = _format_optional_ts(w.get("last_run_at"))
        last_status = w.get("last_run_status") or "-"
        click.echo(f"| {w['id']} | {name} | {schedule_cell} | {last_run} | {last_status} |")


@workflow_group.command("get")
@click.argument("workflow_id")
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(file_okay=False),
    help="Directory to write manifest.json + spec.json + output.json into. Defaults to workflows/<id>/.",
)
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set).")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_get(
    workflow_id: str,
    output_dir: Optional[str],
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Download a workflow's manifest + spec.json + last output.json onto disk."""
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/workflows/get",
            headers=headers,
            json={"project_domain": project_domain, "id": workflow_id},
            timeout=60,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Workflow '{workflow_id}' not found.")
    _handle_api_error(resp, "Workflow get")

    payload = resp.json()
    target = Path(output_dir) if output_dir else Path("workflows") / workflow_id
    target.mkdir(parents=True, exist_ok=True)

    manifest = payload.get("manifest")
    if manifest is None:
        raise click.ClickException("Server response missing 'manifest'.")
    (target / "manifest.json").write_text(json.dumps(manifest, indent=2))
    written = ["manifest.json"]

    spec = payload.get("spec")
    if isinstance(spec, str) and spec:
        (target / "spec.json").write_text(spec)
        written.append("spec.json")

    output = payload.get("output")
    if isinstance(output, str) and output:
        (target / "output.json").write_text(output)
        written.append("output.json")

    click.echo(f"Wrote {', '.join(written)} to {target}")


@main.group("report", help=REPORT_GROUP_HELP)
def report_group() -> None:
    pass


# ---------------------------------------------------------------------------
# Bundle helpers — local validation, pack, and safe extract for `report
# publish` / `report get`.
# ---------------------------------------------------------------------------

# Allowed file names under any page directory in a bundle. Mirrors the
# server-side allowlist; checked client-side for fast-fail feedback.
_REPORT_BUNDLE_ALLOWED_PAGE_FILES = {"index.html", "spec.json", "data.json"}

# Slug pattern shared with the backend; used to validate page slugs inside
# structure.json. Matches what `reports.SlugPattern` enforces server-side.
_REPORT_SLUG_RE = __import__("re").compile(r"^[a-z0-9][a-z0-9-]{0,63}$")

# The CLI currently targets a single report. The slug is fixed on the wire
# and never exposed through CLI args, manifest fields, or output.
_REPORT_SLUG = "audit"


def _validate_report_bundle_dir(dir_path: Path) -> dict[str, Any]:
    """Local pre-flight: ensure structure.json parses, every page in it has
    a directory with index.html under --dir, and there are no orphan files
    or invalid slugs. Returns the parsed structure dict so the caller can
    surface the page list in its progress message.

    The server re-validates these rules; this is purely a fast-feedback
    layer that catches the common typos before the upload."""
    structure_path = dir_path / "structure.json"
    if not structure_path.is_file():
        raise click.ClickException(
            f"structure.json not found at {structure_path}. A bundle must declare its pages there."
        )
    try:
        structure = json.loads(structure_path.read_text())
    except json.JSONDecodeError as exc:
        raise click.ClickException(f"structure.json is not valid JSON: {exc}")
    if not isinstance(structure, dict):
        raise click.ClickException("structure.json must be a JSON object.")
    if structure.get("version") != 1:
        raise click.ClickException("structure.json: only version=1 is supported.")

    pages = structure.get("pages")
    if not isinstance(pages, list) or len(pages) == 0:
        raise click.ClickException("structure.json: pages must be a non-empty list.")

    declared_slugs: set[str] = set()
    for i, page in enumerate(pages):
        if not isinstance(page, dict):
            raise click.ClickException(f"structure.json: pages[{i}] must be an object.")
        slug = page.get("slug")
        if not isinstance(slug, str) or not _REPORT_SLUG_RE.match(slug):
            raise click.ClickException(
                f"structure.json: pages[{i}].slug {slug!r} is not a valid slug (lowercase alphanumerics and hyphens, max 64 chars)."
            )
        if slug in declared_slugs:
            raise click.ClickException(f"structure.json: pages[{i}].slug {slug!r} is duplicated.")
        declared_slugs.add(slug)
        if not (dir_path / slug / "index.html").is_file():
            raise click.ClickException(
                f"Page {slug!r} has no {slug}/index.html under {dir_path}."
            )
        for entry in (dir_path / slug).iterdir():
            if entry.name not in _REPORT_BUNDLE_ALLOWED_PAGE_FILES:
                raise click.ClickException(
                    f"Unexpected file {entry.name!r} under page {slug!r} — only index.html, spec.json, data.json are allowed."
                )

    default_page = structure.get("default_page")
    if default_page is not None and default_page not in declared_slugs:
        raise click.ClickException(
            f"structure.json: default_page {default_page!r} is not one of the declared page slugs."
        )

    for entry in dir_path.iterdir():
        if entry.name in ("structure.json", "manifest.json"):
            continue
        if entry.is_file():
            raise click.ClickException(
                f"Unexpected file {entry.name!r} at the bundle root — only structure.json (and the synthesized manifest.json) belong here."
            )
        if entry.is_dir() and entry.name not in declared_slugs:
            raise click.ClickException(
                f"Directory {entry.name!r} is not declared in structure.pages — remove it or add it."
            )

    return structure


def _pack_report_bundle(dir_path: Path) -> bytes:
    """Tar+gzip the report directory at dir_path. structure.json + every
    page directory (with the three allowed files) is included; manifest.json
    is skipped (row-derived; server ignores any uploaded copy)."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        # structure.json first so a list of the archive shows it at the top.
        tar.add(str(dir_path / "structure.json"), arcname="structure.json")
        for entry in sorted(dir_path.iterdir()):
            if not entry.is_dir():
                continue
            for fname in _REPORT_BUNDLE_ALLOWED_PAGE_FILES:
                fp = entry / fname
                if fp.is_file():
                    tar.add(str(fp), arcname=f"{entry.name}/{fname}")
    return buf.getvalue()


def _extract_report_bundle(tarball: bytes, target: Path) -> list[str]:
    """Extract a downloaded report tarball into target/, with safe-extract
    semantics (no absolute paths, no .. traversal, regular files only).
    Returns the list of written file paths (relative to target) for the
    success message."""
    target.mkdir(parents=True, exist_ok=True)
    written: list[str] = []
    with tarfile.open(fileobj=io.BytesIO(tarball), mode="r:gz") as tar:
        for member in tar.getmembers():
            if not member.isreg():
                continue
            name = member.name
            if name.startswith("/") or ".." in Path(name).parts:
                raise click.ClickException(f"Unsafe path in bundle: {name!r}")
            dest = target / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            extracted = tar.extractfile(member)
            if extracted is None:
                continue
            dest.write_bytes(extracted.read())
            written.append(name)
    return written


_REPORT_APPLY_HELP = """Upsert report metadata from a manifest.

If the manifest has no `id`, POSTs a new report row and writes the assigned
id back to the manifest. First apply requires `details` in the manifest
(a free-text brief describing the report's intended data shape).

If the manifest has an `id`, PATCHes the existing row.

This is metadata only — it does NOT push any files. To author the report's
pages, use `agentberlin report publish` once the row exists.

See `agentberlin report --help` for the manifest format reference.
"""


@report_group.command("apply", help=_REPORT_APPLY_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file (kind=report).",
)
@click.option(
    "--project-domain",
    envvar="PROJECT_DOMAIN",
    help="Project domain (reads from PROJECT_DOMAIN env or config if not set).",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_apply(
    manifest: str,
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)
    manifest_data, manifest_path = _load_manifest(manifest, "report")
    headers = {"Authorization": f"Bearer {token}"}

    report_id = manifest_data.get("id")
    if report_id:
        content = _build_report_metadata_update_payload(manifest_data)
        if not content:
            raise click.ClickException(
                "manifest has no fields to update. Add a name/description/details change first."
            )
        result = _patch_report_metadata(base_url, headers, _REPORT_SLUG, project_domain, content)
        click.echo(f"Report metadata applied ({result.get('report_id', '')})")
    else:
        payload = _build_report_create_payload(manifest_data, project_domain)
        if not payload.get("details"):
            raise click.ClickException(
                "first apply requires 'details' in the manifest (a free-text brief describing the report's intended data shape)."
            )
        result = _post_create_report(base_url, headers, payload)
        new_id = result.get("report_id", "")
        if new_id:
            _write_id_to_manifest(manifest_path, manifest_data, new_id)
        click.echo(f"Report metadata applied ({new_id})")


_REPORT_PUBLISH_HELP = """Publish the report's bundle (whole directory of pages).

Reads --dir, validates structure.json against the directories present
(every declared page slug must have an index.html; no orphan files or
directories), and tars+gzips the result. The bundle goes up as one
multipart PUT. The server commits structure.json last so partial failures
leave the prior shape in place.

The CLI excludes manifest.json from the bundle if present — manifest is
derived from the DB row and is never persisted to S3.
"""


@report_group.command("publish", help=_REPORT_PUBLISH_HELP)
@click.option(
    "--dir",
    "-d",
    "dir_path",
    type=click.Path(exists=True, file_okay=False),
    required=True,
    help="Directory containing structure.json and one sub-directory per page.",
)
@click.option(
    "--project-domain",
    envvar="PROJECT_DOMAIN",
    help="Project domain (reads from PROJECT_DOMAIN env or config if not set).",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_publish(
    dir_path: str,
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    dir_p = Path(dir_path)
    structure = _validate_report_bundle_dir(dir_p)

    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)
    headers = {"Authorization": f"Bearer {token}"}
    tarball = _pack_report_bundle(dir_p)

    result = _put_report_bundle(base_url, headers, _REPORT_SLUG, project_domain, tarball)

    page_count = len(structure.get("pages") or [])
    click.echo(f"Published report bundle ({page_count} page(s))")
    if result.get("url"):
        click.echo(f"URL: {result['url']}")


@report_group.command("list")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set).")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON instead of a markdown table.")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_list(project_domain: Optional[str], token: Optional[str], as_json: bool, base_url: str) -> None:
    """List the project's report as a markdown table."""
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/reports/list",
            headers=headers,
            json={"project_domain": project_domain},
            timeout=60,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Report list")

    payload = resp.json()
    if as_json:
        click.echo(json.dumps(payload, indent=2))
        return

    items = payload.get("reports", []) or []
    if not items:
        click.echo("No report found.")
        return

    click.echo("| Name | Updated at |")
    click.echo("|---|---|")
    for r in items:
        name = (r.get("name") or "").replace("|", "\\|")
        updated = r.get("updated_at") or "-"
        click.echo(f"| {name} | {updated} |")


@report_group.command("get")
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(file_okay=False),
    help="Directory to extract the bundle into. Defaults to reports/audit/.",
)
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set).")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_get(
    output_dir: Optional[str],
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Download the report's bundle (manifest.json + structure.json + every
    page's files) and extract it onto disk.

    On a freshly-applied row with no published bundle, the server returns a
    scaffold (manifest.json + empty structure.json) so the workflow is
    uniform — the agent always has a directory to edit from.
    """
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)
    headers = {"Authorization": f"Bearer {token}"}

    tarball = _get_report_bundle(base_url, headers, _REPORT_SLUG, project_domain)
    target = Path(output_dir) if output_dir else Path("reports") / _REPORT_SLUG
    written = _extract_report_bundle(tarball, target)
    if not written:
        raise click.ClickException("Server returned an empty bundle.")
    click.echo(f"Wrote {len(written)} file(s) to {target}: {', '.join(sorted(written))}")


@report_group.command("design")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_design(token: Optional[str], base_url: str) -> None:
    """Print the report design guide (CSS tokens, type ramp, component recipes).

    Read this before authoring or editing any report HTML — it is the
    authoritative styling contract every report bundle must follow.
    """
    token = _resolve_token(token)
    headers = {"Authorization": f"Bearer {token}"}
    try:
        resp = requests.get(
            f"{base_url}/reports/design-guide",
            headers=headers,
            timeout=30,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Report design guide")
    click.echo(resp.text)


@main.group("action", help=ACTION_GROUP_HELP)
def action_group() -> None:
    pass


@action_group.command("create")
@click.option("--title", required=True, help="Short action title.")
@click.option("--description", required=True, help="Action description / brief.")
@click.option(
    "--category",
    required=True,
    help="Action category. See `agentberlin action --help` for the full list.",
)
@click.option(
    "--project-domain",
    envvar="PROJECT_DOMAIN",
    help="Project domain (reads from PROJECT_DOMAIN env or config if not set).",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def action_create(
    title: str,
    description: str,
    category: str,
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Create a new action in the project's todo list."""
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    payload = {
        "project_domain": project_domain,
        "title": title,
        "description": description,
        "template_key": category,
    }
    try:
        resp = requests.post(f"{base_url}/actions", headers=headers, json=payload, timeout=60)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Action create")
    body = resp.json()
    click.echo(f"Created action: {body.get('title', title)} ({body.get('id', '')})")


@main.group("strategies")
def strategies_group() -> None:
    """List and inspect SEO strategies from the curated catalog."""
    pass


def _format_strategy_markdown(s: dict[str, Any]) -> str:
    """Render a strategy as markdown.

    Mirrors backend/internal/strategies/tool.go's formatStrategyDetails so
    output stays byte-compatible with the legacy in-process tool.
    """
    parts: list[str] = []
    parts.append(f"# {s['name']}\n")
    parts.append(f"ID: {s['id']}\nCategory: {s['category']}\nIntent: {s['intent']}\n")
    parts.append(f"## Summary\n{s['summary']}\n")
    caps = s.get("required_capabilities") or []
    if caps:
        parts.append(f"## Required capabilities\n{', '.join(caps)}\n")
    parts.append(f"## Cadence guidance\n{(s.get('cadence') or '').strip()}\n")
    parts.append(f"## Details\n{(s.get('details') or '').strip()}")
    return "\n".join(parts)


@strategies_group.command("list")
@click.option(
    "--shortlist",
    is_flag=True,
    default=False,
    help="Narrow to strategies whose required capabilities and applicability already fit this project.",
)
@click.option(
    "--project-domain",
    envvar="PROJECT_DOMAIN",
    help="Project domain (reads from PROJECT_DOMAIN env or config if not set). Required with --shortlist.",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def strategies_list(
    shortlist: bool,
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """List strategies from the catalog as a markdown table.

    By default returns every strategy. Pass --shortlist to receive only the
    strategies whose required capabilities are satisfied by this project's
    connected integrations and whose applicable business_models / industries
    match the brand profile.
    """
    token = _resolve_token(token)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    payload: dict[str, Any] = {}
    if shortlist:
        payload = {
            "shortlist": True,
            "project_domain": _resolve_project_domain(project_domain),
        }
    try:
        resp = requests.post(f"{base_url}/strategies/list", headers=headers, json=payload, timeout=30)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Strategy list")

    items = resp.json().get("strategies", [])
    if not items:
        click.echo("No strategies found.")
        return

    click.echo("| ID | Name | Category | Intent | Summary |")
    click.echo("|---|---|---|---|---|")
    for s in items:
        summary = (s.get("summary") or "").replace("|", "\\|").replace("\n", " ")
        click.echo(
            f"| {s['id']} | {s['name']} | {s.get('category', '')} | {s.get('intent', '')} | {summary} |"
        )


@strategies_group.command("get")
@click.argument("strategy_id")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def strategies_get(strategy_id: str, token: Optional[str], base_url: str) -> None:
    """Fetch the full body of one strategy as markdown.

    STRATEGY_ID is the kebab-case identifier shown by `agentberlin strategies list`.
    """
    token = _resolve_token(token)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/strategies/get",
            headers=headers,
            json={"id": strategy_id},
            timeout=30,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Strategy '{strategy_id}' not found.")
    _handle_api_error(resp, "Strategy get")

    click.echo(_format_strategy_markdown(resp.json()))


if __name__ == "__main__":
    main()
