"""commiter — AI-powered git commit grouping."""

__version__ = "0.1.0"
