import os
import subprocess
from dataclasses import dataclass
from typing import List

# Safe environment for all git subprocess calls.
# GIT_TERMINAL_PROMPT=0 prevents git from hanging on auth prompts (non-interactive TUI).
# GIT_ASKPASS=echo silently fails credential requests instead of blocking.
# This is the same approach used by VS Code and GitHub Desktop.
_GIT_ENV = {
    **os.environ,
    "GIT_TERMINAL_PROMPT": "0",
    "GIT_ASKPASS": "echo",
}

@dataclass
class GitFile:
    status: str
    path: str

def is_git_repository() -> bool:
    """Check if the current directory is a git repository."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            env=_GIT_ENV,
            check=False
        )
        return result.returncode == 0
    except FileNotFoundError:
        return False

def get_changed_files(paths: List[str] = None) -> List[GitFile]:
    """Get list of changed files from git status, optionally filtered by paths.

    Uses git ls-files to show untracked files rather than 'git add -N .',
    which would mutate the index and cause pathspec errors on deleted files.
    """
    # -c must come before the subcommand: "git -c key=val status ..."
    cmd = ["git", "-c", "core.quotePath=false", "status", "--porcelain"]
    if paths:
        cmd += ["--"] + paths

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        env=_GIT_ENV,
        check=False
    )

    files = []
    seen_paths = set()
    for line in result.stdout.splitlines():
        if len(line) < 4:
            continue
        status = line[:2]
        path = line[3:].strip()
        files.append(GitFile(status=status, path=path))
        seen_paths.add(path)

    # Collect untracked files without touching the index (VS Code approach)
    ls_cmd = ["git", "-c", "core.quotePath=false", "ls-files", "--others", "--exclude-standard"]
    if paths:
        ls_cmd += ["--"] + paths
    ls_result = subprocess.run(
        ls_cmd,
        capture_output=True, text=True, encoding="utf-8", env=_GIT_ENV, check=False
    )
    for upath in ls_result.stdout.splitlines():
        upath = upath.strip()
        if upath and upath not in seen_paths:
            files.append(GitFile(status="??", path=upath))

    return sorted(files, key=lambda f: f.status)


def optimize_diff(raw_diff: str) -> str:
    """Optimize diff length by truncating new files to 10 lines and modified to 50."""
    if not raw_diff.strip():
        return ""
        
    parts = raw_diff.split("diff --git ")
    optimized = []
    
    for part in parts:
        if not part.strip(): continue
        file_diff = "diff --git " + part
        lines = file_diff.splitlines()
        
        is_new = any(line.startswith("new file mode") for line in lines[:15])
        
        if is_new:
            kept_lines = []
            additions = 0
            for line in lines:
                if additions >= 10 and line.startswith('+') and not line.startswith('+++'):
                    continue
                kept_lines.append(line)
                if line.startswith('+') and not line.startswith('+++'):
                    additions += 1
                if additions >= 10:
                    kept_lines.append("... [File truncated: New file, showing only first 10 lines to AI]")
                    break
            optimized.append("\n".join(kept_lines))
        else:
            if len(lines) > 50:
                kept = lines[:50]
                kept.append("... [File truncated: Modification exceeds 50 lines, there is more to this change]")
                optimized.append("\n".join(kept))
            else:
                optimized.append(file_diff)
                
    return "\n".join(optimized)

def get_git_diff(optimize: bool = True, paths: List[str] = None) -> str:
    """Get the full git diff for all changed files (cached and uncached)."""
    # For untracked files: use git diff --diff-filter=A with ls-files rather
    # than 'git add -N .' so we don't mutate the index.
    # For new files not yet staged, add them temporarily as intent-to-add.
    add_cmd = ["git", "add", "-N", "."]
    if paths:
        add_cmd = ["git", "add", "-N"] + paths
    subprocess.run(add_cmd, capture_output=True, encoding="utf-8", env=_GIT_ENV, check=False)

    # Diff for unstaged changes (--no-pager prevents blocking)
    diff_cmd = ["git", "--no-pager", "diff"]
    if paths:
        diff_cmd += ["--"] + paths

    result_unstaged = subprocess.run(
        diff_cmd,
        capture_output=True, text=True, encoding="utf-8", env=_GIT_ENV, check=False
    )

    # Diff for staged changes
    staged_cmd = ["git", "--no-pager", "diff", "--cached"]
    if paths:
        staged_cmd += ["--"] + paths

    result_staged = subprocess.run(
        staged_cmd,
        capture_output=True, text=True, encoding="utf-8", env=_GIT_ENV, check=False
    )

    staged_out = result_staged.stdout or ""
    unstaged_out = result_unstaged.stdout or ""
    raw_combined = staged_out + "\n" + unstaged_out

    if optimize:
        return optimize_diff(raw_combined)
    return raw_combined

def execute_commit(files: List[str], message: str) -> str:
    """Execute a git commit with the given files and message."""
    if not files:
        raise ValueError("No files provided for commit.")

    # Only add files that still have pending changes in the working tree / index.
    # If a previous commit already processed a file, git add would fail with
    # "pathspec did not match any files".
    status_result = subprocess.run(
        ["git", "status", "--porcelain"],
        capture_output=True, text=True, encoding="utf-8", env=_GIT_ENV, check=False
    )
    changed_paths = set()
    for line in status_result.stdout.splitlines():
        if len(line) >= 4:
            changed_paths.add(line[3:].strip())

    pending_files = [f for f in files if f in changed_paths]

    if not pending_files:
        return "SKIPPED_NO_CHANGES"

    # Stage each file using 'git add -A -- <file>' (the VS Code approach).
    # -A handles new files, modifications, AND deletions in one command.
    # If a file was never committed and is now gone (never-tracked intent-to-add),
    # git returns 'pathspec not matched' — we skip those silently.
    errors = []
    for f in pending_files:
        result = subprocess.run(
            ["git", "add", "-A", "--", f],
            capture_output=True, text=True, encoding="utf-8", env=_GIT_ENV
        )
        if result.returncode != 0:
            err = (result.stderr or result.stdout or "").strip()
            if "did not match any files" not in err:
                errors.append(f"{f}: {err}")

    if errors:
        raise RuntimeError("failed to stage files:\n" + "\n".join(errors))

    # Check if anything is actually staged
    status = subprocess.run(
        ["git", "status", "--porcelain"],
        capture_output=True, text=True, encoding="utf-8", env=_GIT_ENV
    )
    if not status.stdout.strip() or not any(
        line.startswith(('A', 'M', 'D', 'R', 'C')) for line in status.stdout.splitlines()
    ):
        return "SKIPPED_NO_CHANGES"

    # git commit
    try:
        subprocess.run(
            ["git", "commit", "-m", message],
            capture_output=True, text=True, encoding="utf-8",
            env=_GIT_ENV, check=True
        )
        rev_parse = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True, encoding="utf-8",
            env=_GIT_ENV, check=True
        )
        return rev_parse.stdout.strip()
    except subprocess.CalledProcessError as e:
        err_msg = e.stderr or e.stdout or ""
        if "nothing to commit" in err_msg.lower():
            return "SKIPPED_NO_CHANGES"
        raise RuntimeError(f"failed to commit: {err_msg}")


def execute_push() -> str:
    """Execute git push to the default remote/branch."""
    try:
        result = subprocess.run(
            ["git", "push"],
            capture_output=True, text=True, encoding="utf-8",
            env=_GIT_ENV, check=True
        )
        return result.stderr.strip() or result.stdout.strip()
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"failed to push: {e.stderr}")

def create_and_checkout_branch(name: str) -> None:
    """Create and checkout a new git branch."""
    try:
        subprocess.run(
            ["git", "checkout", "-b", name],
            capture_output=True, text=True, encoding="utf-8",
            env=_GIT_ENV, check=True
        )
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"failed to create branch '{name}': {e.stderr}")

def has_unmerged_paths() -> bool:
    """Check if there are any unmerged paths (merge conflicts)."""
    result = subprocess.run(
        ["git", "--no-pager", "diff", "--name-only", "--diff-filter=U"],
        capture_output=True, text=True, encoding="utf-8", env=_GIT_ENV
    )
    return bool(result.stdout.strip())

def is_behind_remote() -> bool:
    """Check if the current branch is behind its remote tracking branch."""
    try:
        result = subprocess.run(
            ["git", "rev-list", "--count", "HEAD..@{u}"],
            capture_output=True, text=True, env=_GIT_ENV, check=True
        )
        count = int(result.stdout.strip())
        return count > 0
    except Exception:
        # If no upstream or error, assume not behind
        return False
