import pytest
from commiter.ai import post_process_commits
from commiter.cli import filter_files

def test_post_process_commits_deduplication():
    """Test that files are only added to the first commit that mentions them."""
    proposed = [
        {"message": "feat: add user login", "files": ["src/login.py", "src/auth.py"]},
        {"message": "refactor: login logic", "files": ["src/login.py", "src/utils.py"]}
    ]
    
    processed = post_process_commits(proposed)
    
    # First commit should keep both
    assert "src/login.py" in processed[0]["files"]
    assert "src/auth.py" in processed[0]["files"]
    
    # Second commit should have src/login.py removed
    assert "src/login.py" not in processed[1]["files"]
    assert "src/utils.py" in processed[1]["files"]

def test_post_process_commits_empty_removal():
    """Test that commits with no files left are removed."""
    proposed = [
        {"message": "feat: a", "files": ["a.py"]},
        {"message": "feat: b", "files": ["a.py"]}
    ]
    
    processed = post_process_commits(proposed)
    assert len(processed) == 1
    assert processed[0]["message"] == "feat: a"

def test_filter_files_include():
    """Test glob include filtering."""
    files = ["src/main.py", "src/utils.py", "readme.md"]
    include = "*.py"
    
    filtered = filter_files(files, include, None)
    assert "src/main.py" in filtered
    assert "src/utils.py" in filtered
    assert "readme.md" not in filtered

def test_filter_files_exclude():
    """Test glob exclude filtering."""
    files = ["src/main.py", "src/utils.py", "readme.md"]
    exclude = "readme.md"
    
    filtered = filter_files(files, None, exclude)
    assert "src/main.py" in filtered
    assert "readme.md" not in filtered
