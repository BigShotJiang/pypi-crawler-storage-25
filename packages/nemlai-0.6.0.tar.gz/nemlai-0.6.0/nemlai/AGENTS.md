# SDK AGENTS.md

## OVERVIEW
Published Python SDK (`nemlai`) for the NemlAI platform (PyPI, Homebrew, AUR, PPA).

## STRUCTURE
- `sdk/nemlai/` — Package source
- `sdk/tests/` — SDK-specific tests (client & REPL)
- `sdk/pyproject.toml` — Build config (hatchling)

## MODULE MAP
| Module | Role |
|--------|------|
| `__init__.py` | Version string (0.5.3) |
| `__main__.py` | `python -m nemlai` entry point |
| `cli.py` | Interactive REPL (100+ commands, readline) |
| `client.py` | HTTP client for FastAPI service |
| `models.py` | Shared Pydantic/dataclass types |
| `auth.py` | Login flow & token management |
| `basket.py` | Basket operations (build, clear, list) |
| `orders.py` | Order history retrieval |
| `household.py` | Household/user mapping |
| `settings.py` | User-specific configuration |

## CONVENTIONS
- **Thin Client**: Logic stays on server (`nemligbot/service_api.py`).
- **REPL**: Uses `readline` for history and tab-completion.
- **Auth**: Tokens stored locally, sent as `Bearer` header.
- **Version Bump**: Update BOTH `sdk/pyproject.toml` AND `sdk/nemlai/__init__.py`.
- **Tests**: Use mock tokens (`abc123`, `test-token`) in `test_sdk.py`.

## NOTES
- **Release**: Triggers 5 parallel CI workflows (PyPI, PPA, Homebrew, AUR, GHCR).
- **Dependency**: Strict `httpx>=0.25,<1.0` requirement.
- **CLI Entry**: `nemlai = "nemlai.cli:main"` in `pyproject.toml`.
- **REPL History**: Persists to `~/.nemlai_history`.
- **Base URL**: Defaults to `https://nemlai.milops.org`.
