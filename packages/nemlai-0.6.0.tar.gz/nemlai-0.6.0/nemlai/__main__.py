"""Allow running the NemlAI CLI with ``python -m nemlai``."""

from nemlai.cli import main

main()
