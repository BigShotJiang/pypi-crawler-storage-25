#!/usr/bin/env python
# @Project ：django_base_ai
# @File    : folder_list.py
# @Author  : cx
# @Time    : 11/2/2025
# @Desc    : 文件夹列表与上传管理接口
import logging

from django_base_ai.system.models import FolderList
from django_base_ai.utils.serializers import CustomModelSerializer
from django_base_ai.utils.viewset import CustomModelViewSet

logger = logging.getLogger(__name__)


class FolderSerializer(CustomModelSerializer):
    class Meta:
        model = FolderList
        fields = "__all__"


class FolderViewSet(CustomModelViewSet):
    """
    文件夹管理接口
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """

    queryset = FolderList.objects.all()
    serializer_class = FolderSerializer
    filter_fields = [
        "name",
    ]
    permission_classes = []
