#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import logging
import os
import sys

import django

# 设置 Django 环境
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "DjangoBaseAi.settings")
django.setup()

# 获取 logger，使用模块路径作为 logger 名称
logger = logging.getLogger("django_base_ai.system.tests")


def test_log_format():
    """测试日志格式"""
    logger.info("登录成功")
    logger.debug("调试信息")
    logger.warning("警告信息")
    logger.error("错误信息")
    logger.critical("严重错误")


if __name__ == "__main__":
    test_log_format()
