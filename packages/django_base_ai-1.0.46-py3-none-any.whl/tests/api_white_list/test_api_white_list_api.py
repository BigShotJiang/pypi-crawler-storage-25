"""接口白名单 ApiWhiteListViewSet 单元测试。"""

import pytest
from rest_framework import status

from tests.assertions import assert_unauthorized

pytestmark = [pytest.mark.django_db]

API = "/base/api/system/api_white_list"


def test_api_white_list_list_requires_auth(api_client):
    """GET /api_white_list/ 未认证返回 401。"""
    response = api_client.get(API + "/")
    assert_unauthorized(response)


def test_api_white_list_list_ok(authenticated_client):
    """GET /api_white_list/ 已认证返回 200。"""
    response = authenticated_client.get(API + "/")
    assert response.status_code == status.HTTP_200_OK
    assert response.json().get("code") == 2000
