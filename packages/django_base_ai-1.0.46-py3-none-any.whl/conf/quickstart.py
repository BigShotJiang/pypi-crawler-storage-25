#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
快速开始配置：无需 MySQL/Redis，使用 SQLite + 内存缓存，克隆后即可运行。
用法：ENV=quickstart python manage.py runserver
首次使用请阅读 help/QUICKSTART.md。
"""
import os

APPID = "Django 基座（快速开始）"

# ---------- 数据库：SQLite（无需安装 MySQL）----------
DATABASE_ENGINE = "django.db.backends.sqlite3"
# 数据库文件放在项目根目录
DATABASE_NAME = os.path.join(os.path.dirname(__file__), "..", "db.sqlite3")
DATABASE_HOST = ""
DATABASE_PORT = ""
DATABASE_USER = ""
DATABASE_PASSWORD = ""

TABLE_PREFIX = "base_"

# ---------- 缓存与配置：内存（无需 Redis）----------
REDIS_MODE = "memory"
REDIS_URL = ""
REDIS_PASSWORD = ""
REDIS_HOST = ""
REDIS_HOSTS = []
DISPATCH_DB_TYPE = "memory"

# ---------- 功能开关：便于本地体验 ----------
DEBUG = True
LOGIN_NO_CAPTCHA_AUTH = True
ENABLE_LOGIN_ANALYSIS_LOG = False
API_LOG_ENABLE = True
API_LOG_METHODS = ["POST", "UPDATE", "DELETE", "PUT"]

ALLOWED_HOSTS = ["*"]
ENVIRONMENT = "local"

# ---------- AI：仅占位，使用前请在 conf/env.py 或环境变量中配置真实 Key ----------
AI_DEFAULT_PROVIDER = "deepseek"
AI_DEEPSEEK_API_KEY = os.environ.get("AI_DEEPSEEK_API_KEY", "")
AI_DEEPSEEK_DEFAULT_MODEL = "deepseek-chat"
AI_TENCENT_API_KEY = ""
AI_OPENAI_API_KEY = ""
AI_OPENAI_BASE_URL = ""
AI_OPENAI_CUSTOM_API_KEY = ""
AI_OPENAI_CUSTOM_BASE_URL = ""
AI_WANXIANG_API_KEY = ""
