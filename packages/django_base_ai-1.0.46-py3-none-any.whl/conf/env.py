#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
开发环境配置：数据库(MySQL)、Redis、API 日志、登录验证码、AI 供应商等。
被 settings 在 ENV 非 test/pro 时加载；敏感信息勿提交，可参考 .env.example。
"""

APPID = "Django 基座"
# ================================================= #
# *************** mysql数据库 配置  *************** #
# ================================================= #

# 使用mysql时，改为此配置
DATABASE_ENGINE = "django.db.backends.mysql"
DATABASE_NAME = "django_base_ai"  # mysql 时使用

# 数据库地址 改为自己数据库地址
DATABASE_HOST = "127.0.0.1"
# # 数据库端口
DATABASE_PORT = 3306
# # 数据库用户名
DATABASE_USER = "root"
# # 数据库密码
DATABASE_PASSWORD = "p@ssw0rdwcx"

# 表前缀
TABLE_PREFIX = "base_"
# ================================================= #
# ******** redis配置，无redis 可不进行配置  ******** #
# ================================================= #
REDIS_MODE = 0  # redis 模式: 0=单机, 1=集群, 2=哨兵
REDIS_PASSWORD = "Cx199394"
REDIS_HOST = "127.0.0.1"
REDIS_URL = f"redis://:{REDIS_PASSWORD or ''}@{REDIS_HOST}:6379"
# Redis集群
REDIS_PASSWORDS = "Cx199394"
REDIS_HOSTS = [
    f"redis://:{REDIS_PASSWORDS}@127.0.0.1:6371/0",
    f"redis://:{REDIS_PASSWORDS}@127.0.0.1:6372/0",
    f"redis://:{REDIS_PASSWORDS}@127.0.0.1:6373/0",
    f"redis://:{REDIS_PASSWORDS}@127.0.0.1:6374/0",
    f"redis://:{REDIS_PASSWORDS}@127.0.0.1:6375/0",
    f"redis://:{REDIS_PASSWORDS}@127.0.0.1:6376/0",
]
# Redis哨兵模式
MASTER_NAME = "mymaster"
SENTINELS_HOSTS = [("127.0.0.1", 37376), ("127.0.0.1", 37377), ("127.0.0.1", 37378)]
SENTINELS_LOCATION = [
    f"redis://{MASTER_NAME}:37376/0",
    f"redis://{MASTER_NAME}:37377/0",
    f"redis://{MASTER_NAME}:37378/0",
]
MASTER_PASSWORDS = "Cx199394"
SENTINELS_PASSWORDS = "Cx199394"
# ================================================= #
# ****************** 功能 启停  ******************* #
# ================================================= #
DEBUG = True
# 启动登录详细概略获取(通过调用api获取ip详细地址。如果是内网，关闭即可)
ENABLE_LOGIN_ANALYSIS_LOG = True
# 登录接口 /base/api/token/ 是否需要验证码认证，用于测试，正式环境建议取消
LOGIN_NO_CAPTCHA_AUTH = True
# 是否启动API日志记录
API_LOG_ENABLE = locals().get("API_LOG_ENABLE", True)
# API 日志记录的请求方式
API_LOG_METHODS = locals().get("API_LOG_METHODS", ["POST", "UPDATE", "DELETE", "PUT"])
# API_LOG_METHODS = 'ALL' # ['POST', 'DELETE']
# ================================================= #
# ****************** AI 供应商 配置  **************** #
# ================================================= #
# 默认使用的供应商（不传 provider 时生效）：deepseek / tencent / openai / openai_custom
AI_DEFAULT_PROVIDER = "deepseek"
# DeepSeek：https://platform.deepseek.com
AI_DEEPSEEK_API_KEY = "sk-7755f99dea24462ca11ac856cddb888e"
AI_DEEPSEEK_DEFAULT_MODEL = "deepseek-chat"
# 腾讯云混元
AI_TENCENT_API_KEY = ""
AI_TENCENT_DEFAULT_MODEL = "hunyuan-lite"
# OpenAI 或
AI_OPENAI_API_KEY = ""
AI_OPENAI_BASE_URL = ""
AI_OPENAI_DEFAULT_MODEL = "gpt-3.5-turbo"
# 自定义AI 目前使用玄算科技
AI_OPENAI_CUSTOM_API_KEY = "sk-0oL3Pfi2QcYXxWVCYKmOhZLjxlkkrG4qQuJvBGWmHM2sXXPf"
AI_OPENAI_CUSTOM_BASE_URL = "https://api.xuansuan.top/v1"
AI_OPENAI_CUSTOM_DEFAULT_MODEL = "deepseek-v3.2"
# 通义万相（阿里云 DashScope 文生图，与通义千问同 key 可复用）
AI_WANXIANG_API_KEY = "sk-cca67a90066e409db2a610c39989d39f"
AI_WANXIANG_DEFAULT_MODEL = "wanx2.1-t2i-turbo"
# ================================================= #
# ****************** 其他 配置  ******************* #
# ================================================= #
ENVIRONMENT = "local"  # 环境，test 测试环境;prod线上环境;local本地环境
ALLOWED_HOSTS = ["*"]
# 系统配置存放位置：redis/memory(默认)
DISPATCH_DB_TYPE = "redis"
