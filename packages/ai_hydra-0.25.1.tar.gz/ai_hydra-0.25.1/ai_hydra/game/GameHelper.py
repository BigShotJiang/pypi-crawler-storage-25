# ai_hydra/game/MoveResult.py
#
#    AI Hydra
#    Author: Nadim-Daniel Ghaznavi
#    Copyright: (c) 2025-2026 Nadim-Daniel Ghaznavi
#    GitHub: https://github.com/NadimGhaznavi/ai_hydra
#    Website: https://ai-hydra.readthedocs.io/en/latest
#    License: GPL 3.0

from __future__ import annotations
from dataclasses import dataclass

from ai_hydra.game.GameBoard import GameBoard  # adjust path to your real one
from ai_hydra.constants.DGame import DGameField


@dataclass(frozen=True)
class MoveResult:
    new_board: GameBoard
    reward: int
    outcome: str
    is_terminal: bool

    def is_collision(self) -> bool:
        return self.outcome in (DGameField.WALL, DGameField.SNAKE)

    def is_food_eaten(self) -> bool:
        return self.outcome == DGameField.FOOD


@dataclass(frozen=True)
class RewardCfg:
    values: dict[str, float]

    def __post_init__(self):
        clean = {}
        for k, v in self.values.items():
            if v is None:
                raise ValueError(f"Reward {k} is None")
            clean[k] = float(v)
        object.__setattr__(self, "values", clean)

    def get(self, field: str) -> float:
        if field not in self.values:
            raise KeyError(f"Missing reward field: {field}")
        return self.values[field]
