from typing import Self

from beanie import Document, PydanticObjectId
from beanie.operators import Eq
from pydantic import Field

from vibetuner.provider import OauthProviderModel as OauthProviderModel  # re-export

from .mixins import TimeStampMixin


class OAuthAccountModel(Document, TimeStampMixin):
    provider: str = Field(
        ...,
        description="OAuth provider name (google, github, twitter, etc.)",
    )
    provider_user_id: str = Field(
        ...,
        description="Unique user identifier from the OAuth provider",
    )
    email: str | None = Field(
        default=None,
        description="Email address retrieved from OAuth provider profile",
    )
    name: str | None = Field(
        default=None,
        description="Full display name retrieved from OAuth provider profile",
    )
    picture: str | None = Field(
        default=None,
        description="Profile picture URL retrieved from OAuth provider",
    )
    app_id: PydanticObjectId | None = Field(
        default=None,
        description="References the OAuthProviderAppModel used during the OAuth flow",
    )

    class Settings:
        name = "oauth_accounts"
        indexes = [
            [("provider", 1), ("provider_user_id", 1)],
        ]

    @classmethod
    async def get_by_provider_and_id(
        cls,
        provider: str,
        provider_user_id: str,
    ) -> Self | None:
        return await cls.find_one(
            Eq(cls.provider, provider),
            Eq(cls.provider_user_id, provider_user_id),
        )
