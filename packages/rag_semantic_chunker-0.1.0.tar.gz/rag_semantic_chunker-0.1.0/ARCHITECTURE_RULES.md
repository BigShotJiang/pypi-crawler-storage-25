# Architecture Rules & Conventions

This document defines architectural rules, conventions, and tooling requirements for the Semantic Code Chunker project.

---

## Tooling Requirements

### Package Manager: uv

**This project uses `uv` as its primary package manager and Python runner.**

All commands must use `uv`:

```bash
# Running Python scripts
uv run python tests/cli_test.py
uv run python -m tests.cli_test

# Installing dependencies
uv add <package-name>
uv sync

# Creating virtual environment (if needed)
uv venv

# Managing projects
uv init <project-name>
```

**Never use plain `python` or `pip` commands directly.** Always prefix with `uv run`.

---

## Project Structure

```
semantic-chunker/
├── src/
│   └── semantic_chunker/
│       ├── __init__.py          # Package exports
│       ├── __main__.py          # CLI entry point (python -m semantic_chunker)
│       ├── cli.py               # CLI argument parsing and command handlers
│       ├── chunker.py           # Main SemanticCodeChunker class
│       ├── parser.py            # ASTParser, ChunkExtractor, factory functions
│       ├── config.py            # Configuration management, PolicyConfig
│       └── policy.yaml          # Default language policies
├── tests/
│   ├── __init__.py
│   ├── cli_test.py              # Legacy CLI test script
│   └── test_*.py                # pytest test modules
├── pyproject.toml               # Project configuration (uv/hatch)
├── ARCHITECTURE_RULES.md        # This file
└── README.md
```

---

## Key Architectural Patterns

### 1. Factory Pattern for Parsers

Always use the factory function instead of direct instantiation:

```python
# ✅ CORRECT - Use factory
from semantic_chunker.parser import create_parser, parse_and_chunk

parser = create_parser("python")
chunks = parse_and_chunk(source_code, "python", target_nodes)

# ❌ WRONG - Direct instantiation
from semantic_chunker.parser import ASTParser
parser = ASTParser("python")  # Avoid this pattern
```

### 2. Convenience Functions Over Manual Assembly

The `parse_and_chunk` function handles the complete pipeline:

```python
# ✅ CORRECT - One call does everything
chunks = parse_and_chunk(
    source_code=code,
    language="python",
    target_nodes=["function_definition", "class_definition"],
    max_context_size=2048
)

# ❌ WRONG - Manual assembly (unless you need fine-grained control)
parser = create_parser("python")
extractor = ChunkExtractor(parser, max_context_size=2048)
chunks = extractor.extract_chunks(code, target_nodes)
```

### 3. Configuration Loading

Always load policy from the YAML file:

```python
from semantic_chunker.config import load_policy

policy_path = "src/semantic_chunker/policy.yaml"
config = load_policy(policy_path)
```

---

## Testing Conventions

### Running Tests

```bash
# Full pytest suite
uv run pytest tests/ -v

# Legacy test scripts
uv run python tests/cli_test.py
```

### Test Structure

Tests should validate:
1. **Module Imports** - All public APIs are importable
2. **Config Loading** - Policy files load correctly
3. **Chunker Functionality** - `parse_and_chunk` works end-to-end
4. **Parser Factory** - `create_parser` creates valid instances

---

## CLI Module Conventions

The CLI is implemented across two files:

- `src/semantic_chunker/__main__.py` — Minimal entry point, just calls `cli.main()`
- `src/semantic_chunker/cli.py` — All argument parsing (using `argparse` from stdlib) and command handlers

The CLI is invoked via:
```bash
uv run python -m semantic_chunker <args>
```

Use `argparse` from the standard library — no external CLI framework needed.

---

## Custom Language Support via Policy

Users can add languages through the policy YAML without modifying library source code. A custom language entry follows the same schema as built-in languages, with an optional `fallback_patterns` field:

```yaml
languages:
  rust:
    parser_name: "rust"
    target_nodes:
      - "function_item"
      - "struct_item"
      - "impl_item"
    metadata_fields:
      - "node_type"
      - "line_number"
      - "function_name"
    fallback_patterns:
      function_item: '\bfn\s+(\w+)\s*\('
      struct_item: '\bstruct\s+(\w+)'
      impl_item: '\bimpl\s+'
```

- If tree-sitter has a grammar for the `parser_name`, it will be used automatically.
- If not, the `fallback_patterns` regex map is used instead.
- If neither is available, the generic default fallback pattern is applied.
- Policy file definitions merge over built-in defaults (policy takes precedence).

---

## Testing Conventions

### Framework: pytest

Use `pytest` for all new tests. The legacy `cli_test.py` and `simple_cli_test.py` scripts remain for backward compatibility but new tests should be pytest modules.

```bash
# Run all pytest tests
uv run pytest tests/ -v

# Run a specific test file
uv run pytest tests/test_chunker.py -v

# Run legacy CLI tests
uv run python tests/cli_test.py
```

### Test File Naming

- New test files: `tests/test_<module>.py` (e.g., `test_chunker.py`, `test_parser.py`, `test_cli.py`)
- Test functions: `test_<description>()` following pytest conventions

---

## Error Handling Philosophy

1. **Graceful Degradation**: When tree-sitter is unavailable, fall back to regex-based parsing
2. **Warning Over Failure**: Log warnings for missing features, don't crash
3. **Clear Error Messages**: Always include context in error messages

Example:
```python
if not TREE_SITTER_AVAILABLE:
    logger.warning("tree-sitter not available. Using fallback mode.")
    return None  # Don't raise exception
```

---

## Language Support Matrix

| Language | Parser Name | Status |
|----------|-------------|--------|
| Python | python | ✅ Full |
| Java | java | ✅ Full |
| JavaScript | javascript | ✅ Full |
| TypeScript | typescript | ✅ Full |
| C | c | ✅ Full |
| C++ | cpp | ✅ Full |
| C# | c_sharp | ✅ Full |
| COBOL | cobol | ⚠️ Fallback |
| JCL | jcl | ⚠️ Fallback |
| CLIST | clist | ⚠️ Fallback |
| VB.NET | vbnet | ⚠️ Fallback |
| Elixir | elixir | ✅ Full |

---

## Quick Reference for Agents

When working on this project:

1. **Always use `uv run`** for executing Python code
2. **Use factory functions**: `create_parser()`, `parse_and_chunk()`
3. **Import from correct modules**:
   - `from semantic_chunker.parser import create_parser, parse_and_chunk`
   - `from semantic_chunker.config import load_policy, get_default_languages`
4. **Policy file location**: `src/semantic_chunker/policy.yaml`
5. **Test file location**: `tests/test_*.py` (pytest), `tests/cli_test.py` (legacy)
6. **CLI entry point**: `src/semantic_chunker/__main__.py` → `cli.py`
7. **Custom languages**: Add to policy YAML with `parser_name`, `target_nodes`, and optional `fallback_patterns`

---

## Version Requirements

- Python: >= 3.9 (as defined in pyproject.toml)
- tree-sitter: Latest stable (for full AST parsing)
- tree-sitter-languages: Latest stable (language bindings)
- PyYAML: For policy file parsing
- pytest: >= 7.0 (dev dependency, for testing)

Install with:
```bash
uv add tree-sitter tree-sitter-languages pyyaml
```

---

*Last Updated: 2024*