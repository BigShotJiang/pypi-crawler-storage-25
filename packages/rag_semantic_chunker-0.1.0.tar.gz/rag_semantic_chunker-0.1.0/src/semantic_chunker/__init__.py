"""
Semantic Code Chunker - Main Package

A Python library that intelligently splits source code into meaningful chunks
based on Abstract Syntax Tree (AST) analysis.
"""

from __future__ import annotations

# Version
__version__ = "0.1.0"
__author__ = "Thanos Zikas"

# Main classes
from .chunker import SemanticCodeChunker
from .config import (
    PolicyConfig,
    LanguageConfig,
    SpecialRules,
    AdvancedConfig,
    DebugConfig,
    OverlapStrategy,
    MergeStrategy,
)
from .parser import (
    ASTParser,
    ChunkExtractor,
    ParsedChunk,
    ChunkMetadata,
    NodeInfo,
    parse_and_chunk,
    create_parser,
)

# Utility functions from config
from .config import (
    load_policy,
    load_default_policy,
    get_supported_languages,
    get_default_languages,
)

# Public API
__all__ = [
    # Version info
    "__version__",
    "__author__",
    
    # Main classes
    "SemanticCodeChunker",
    "PolicyConfig",
    "LanguageConfig",
    "SpecialRules",
    "AdvancedConfig",
    "DebugConfig",
    "ASTParser",
    "ChunkExtractor",
    
    # Data classes
    "ParsedChunk",
    "ChunkMetadata",
    "NodeInfo",
    
    # Enums
    "OverlapStrategy",
    "MergeStrategy",
    
    # Functions
    "parse_and_chunk",
    "create_parser",
    "load_policy",
    "load_default_policy",
    "get_supported_languages",
    "get_default_languages",
]

# Hello function for testing imports
def hello() -> str:
    """Return a greeting message."""
    return f"Hello from semantic-chunker v{__version__}!"