"""Entry point for `python -m semantic_chunker`."""

from semantic_chunker.cli import main

main()
