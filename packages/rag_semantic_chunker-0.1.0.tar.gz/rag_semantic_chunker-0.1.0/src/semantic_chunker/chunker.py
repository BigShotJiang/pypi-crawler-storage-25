﻿"""
Semantic Code Chunker - Main Chunker Module

High-level entry point that delegates parsing and chunking to the parser module.
Configuration is loaded from the config module.
"""

from __future__ import annotations

import yaml
from typing import List

from .config import PolicyConfig, load_policy, load_default_policy
from .parser import create_parser, ChunkExtractor


class SemanticCodeChunker:
    """
    High-level semantic code chunker.

    Accepts either a YAML policy file path or a PolicyConfig object.
    Delegates all parsing and chunk extraction to the parser module.
    """

    def __init__(
        self,
        policy_path: str | None = None,
        config: PolicyConfig | None = None,
    ) -> None:
        """
        Initialize the chunker.

        Args:
            policy_path: Path to a YAML policy file.
            config: A PolicyConfig object.

        Raises:
            ValueError: If both policy_path and config are provided.
            FileNotFoundError: If policy_path does not exist.
            yaml.YAMLError: If the YAML file is invalid.
        """
        if policy_path is not None and config is not None:
            raise ValueError(
                "Only one configuration source is allowed: "
                "provide either policy_path or config, not both."
            )

        if policy_path is not None:
            self._config = load_policy(policy_path)
        elif config is not None:
            self._config = config
        else:
            self._config = load_default_policy()

    def chunk_code(
        self,
        language: str,
        source_code: str,
        context_size: int | None = None,
    ) -> List[str]:
        """
        Split source code into semantic chunks.

        Args:
            language: Language identifier (e.g. 'python', 'java').
            source_code: The source code to chunk.
            context_size: Max characters per chunk. Falls back to the
                PolicyConfig value for the language when None.

        Returns:
            List of code chunk strings.

        Raises:
            ValueError: If the language is not found in the PolicyConfig.
        """
        lang_config = self._config.get_language_config(language)
        if lang_config is None:
            raise ValueError(f"Language '{language}' not found in policy configuration.")

        if context_size is None:
            context_size = self._config.get_context_size(language)

        target_nodes = lang_config.target_nodes
        fallback_patterns = lang_config.fallback_patterns or None

        parser = create_parser(language, fallback_patterns=fallback_patterns)
        extractor = ChunkExtractor(
            parser,
            max_context_size=context_size,
            min_chunk_size=self._config.min_chunk_size,
            include_comments=self._config.include_comments,
            include_docstrings=self._config.include_docstrings,
        )

        chunks = extractor.extract_chunks(source_code, target_nodes)
        return [chunk.code for chunk in chunks]
