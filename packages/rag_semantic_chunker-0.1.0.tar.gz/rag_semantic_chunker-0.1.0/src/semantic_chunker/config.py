"""
Semantic Code Chunker - Configuration Module

This module provides type-safe configuration management for the semantic code chunker,
including policy loading, validation, and default values.
"""

from __future__ import annotations

import yaml
from pathlib import Path
from typing import Dict, List, Optional, Any, Literal
from dataclasses import dataclass, field
from enum import Enum


# =============================================================================
# ENUMS AND CONSTANTS
# =============================================================================

class OverlapStrategy(Enum):
    """Overlap strategies for chunk boundaries."""
    NONE = "none"
    PERCENTAGE = "percentage"
    FIXED = "fixed"


class MergeStrategy(Enum):
    """Strategies for merging small chunks."""
    SEQUENTIAL = "sequential"
    SEMANTIC = "semantic"


# =============================================================================
# DATA CLASSES - CONFIGURATION STRUCTURES
# =============================================================================

@dataclass
class SpecialRules:
    """Special handling rules for language-specific constructs."""
    # General purpose rules
    lambda_functions: str = "merge_with_parent"
    comprehensions: str = "inline"
    getters_setters: str = "group_by_field"
    constructors: str = "merge_with_class"
    macros: str = "inline_with_includes"
    
    # JavaScript-specific rules
    iife: str = "inline"  # Immediately Invoked Function Expressions
    callbacks: str = "merge_with_parent"
    
    # TypeScript-specific rules
    type_definitions: str = "group_by_module"
    
    # C/C++ specific rules
    inline_functions: str = "merge_with_parent"
    operators: str = "merge_with_class"
    destructors: str = "merge_with_class"
    
    # C# specific rules
    properties: str = "group_by_class"
    events: str = "group_by_class"
    
    # COBOL specific rules
    data_division: str = "merge_with_procedure"
    working_storage: str = "inline"
    
    # JCL specific rules
    dd_statements: str = "group_by_exec"
    
    # CLIST specific rules
    condition_codes: str = "inline"
    
    # VB.NET specific rules
    event_handlers: str = "group_by_control"
    
    # Elixir specific rules
    guards: str = "merge_with_function"
    clauses: str = "group_together"
    










    def __post_init__(self):
        """Validate special rules values."""
        valid_values = {
            "merge_with_parent", "inline", "group_by_field", 
            "group_together", "merge_with_class", "group_by_module",
            "group_by_exec", "group_by_control",
            "inline_with_includes", "merge_with_procedure",
            "group_by_class", "merge_with_function"
        }
        for key, value in self.__dict__.items():
            if value not in valid_values:
                # Just warn, don't fail - allow flexibility
                pass  # Removed strict validation


@dataclass
class LanguageConfig:
    """Configuration for a single programming language."""
    parser_name: str
    target_nodes: List[str] = field(default_factory=list)
    metadata_fields: List[str] = field(default_factory=list)
    special_rules: SpecialRules = field(default_factory=SpecialRules)
    fallback_patterns: Dict[str, str] = field(default_factory=dict)
    
    def __post_init__(self):
        """Validate language configuration."""
        if not self.parser_name:
            raise ValueError("parser_name is required")
        if not self.target_nodes:
            raise ValueError(f"target_nodes required for parser '{self.parser_name}'")


@dataclass
class AdvancedConfig:
    """Advanced chunking configuration options."""
    recursive_chunking: bool = True
    max_recursion_depth: int = 3
    merge_strategy: MergeStrategy = MergeStrategy.SEQUENTIAL
    context_lines_before: int = 2
    context_lines_after: int = 2
    
    def __post_init__(self):
        """Validate advanced configuration."""
        if self.max_recursion_depth < 1:
            raise ValueError("max_recursion_depth must be >= 1")


@dataclass
class DebugConfig:
    """Debugging configuration options."""
    enabled: bool = False
    log_ast: bool = False
    log_chunks: bool = True
    verbose_errors: bool = True


@dataclass
class PolicyConfig:
    """Main policy configuration container."""
    
    # Default settings
    max_context_size: int = 2048
    overlap_strategy: OverlapStrategy = OverlapStrategy.NONE
    min_chunk_size: int = 100
    include_comments: bool = True
    include_docstrings: bool = True
    
    # Language configurations
    languages: Dict[str, LanguageConfig] = field(default_factory=dict)
    
    # Advanced settings
    advanced: AdvancedConfig = field(default_factory=AdvancedConfig)
    
    # Debug settings
    debug: DebugConfig = field(default_factory=DebugConfig)
    
    # Language-specific context size overrides
    language_overrides: Dict[str, int] = field(default_factory=dict)
    
    def __post_init__(self):
        """Validate entire configuration."""
        self._validate_defaults()
        self._validate_languages()
        
    def _validate_defaults(self):
        """Validate default settings."""
        if self.max_context_size < 100:
            raise ValueError("max_context_size must be >= 100")
        if self.min_chunk_size < 10:
            raise ValueError("min_chunk_size must be >= 10")
            
    def _validate_languages(self):
        """Validate all language configurations."""
        for lang_name, config in self.languages.items():
            try:
                # This will trigger __post_init__ validation
                # Note: config.special_rules is already a SpecialRules instance, not a dict
                LanguageConfig(
                    parser_name=config.parser_name,
                    target_nodes=config.target_nodes,
                    metadata_fields=config.metadata_fields or [],
                    special_rules=config.special_rules if config.special_rules else SpecialRules()
                )
            except Exception as e:
                raise ValueError(f"Invalid configuration for language '{lang_name}': {e}")
    
    def get_language_config(self, language: str) -> Optional[LanguageConfig]:
        """Get configuration for a specific language."""
        return self.languages.get(language.lower())
    
    def get_context_size(self, language: str) -> int:
        """Get context size for a language (with overrides)."""
        return self.language_overrides.get(
            language.lower(), 
            self.max_context_size
        )
    
    def is_language_supported(self, language: str) -> bool:
        """Check if a language is supported."""
        return language.lower() in self.languages


# =============================================================================
# DEFAULT LANGUAGE CONFIGURATIONS
# =============================================================================

def get_default_languages() -> Dict[str, LanguageConfig]:
    """Return default configurations for all supported languages."""
    
    return {
        # Python Configuration
        "python": LanguageConfig(
            parser_name="python",
            target_nodes=[
                "function_definition",
                "class_definition", 
                "method_definition",
                "decorated_definition",
                "module"
            ],
            metadata_fields=["node_type", "line_number", "function_name"],
            special_rules=SpecialRules(
                lambda_functions="merge_with_parent",
                comprehensions="inline"
            )
        ),
        
        # Java Configuration
        "java": LanguageConfig(
            parser_name="java",
            target_nodes=[
                "method_declaration",
                "class_declaration",
                "interface_declaration",
                "enum_declaration",
                "annotation_declaration",
                "record_declaration"
            ],
            metadata_fields=["node_type", "line_number", "method_name", "class_name"],
            special_rules=SpecialRules(
                getters_setters="group_by_field",
                constructors="merge_with_class"
            )
        ),
        
        # JavaScript Configuration
        "javascript": LanguageConfig(
            parser_name="javascript",
            target_nodes=[
                "function_declaration",
                "arrow_function",
                "class_declaration",
                "method_definition",
                "async_arrow_expression",
                "generator_function"
            ],
            metadata_fields=["node_type", "line_number", "function_name"],
            special_rules=SpecialRules(
                lambda_functions="inline",
                comprehensions="merge_with_parent"
            )
        ),
        
        # TypeScript Configuration
        "typescript": LanguageConfig(
            parser_name="typescript",
            target_nodes=[
                "function_declaration",
                "arrow_function",
                "class_declaration",
                "interface_declaration",
                "type_alias",
                "enum_declaration",
                "namespace_declaration",
                "module_declaration"
            ],
            metadata_fields=["node_type", "line_number", "function_name", "type_name"],
            special_rules=SpecialRules(
                lambda_functions="inline",
                comprehensions="group_by_module"
            )
        ),
        
        # C Configuration
        "c": LanguageConfig(
            parser_name="c",
            target_nodes=[
                "function_definition",
                "struct_specifier",
                "union_specifier",
                "enum_specifier",
                "typedef_declaration"
            ],
            metadata_fields=["node_type", "line_number", "function_name"],
            special_rules=SpecialRules(
                lambda_functions="inline_with_includes",
                comprehensions="merge_with_parent"
            )
        ),
        
        # C++ Configuration
        "cpp": LanguageConfig(
            parser_name="cpp",
            target_nodes=[
                "function_definition",
                "method_definition",
                "class_specifier",
                "struct_specifier",
                "template_declaration",
                "namespace_definition"
            ],
            metadata_fields=["node_type", "line_number", "function_name", "class_name"],
            special_rules=SpecialRules(
                lambda_functions="merge_with_class",
                comprehensions="group_together"
            )
        ),
        
        # C# Configuration
        "csharp": LanguageConfig(
            parser_name="c_sharp",
            target_nodes=[
                "method_declaration",
                "class_declaration",
                "interface_declaration",
                "struct_declaration",
                "enum_declaration",
                "delegate_declaration",
                "event_declaration",
                "property_declaration"
            ],
            metadata_fields=["node_type", "line_number", "method_name", "class_name"],
            special_rules=SpecialRules(
                lambda_functions="group_by_class",
                comprehensions="group_by_class"
            )
        ),
        
        # COBOL Configuration (Legacy)
        "cobol": LanguageConfig(
            parser_name="cobol",
            target_nodes=[
                "paragraph",
                "section",
                "division",
                "program"
            ],
            metadata_fields=["node_type", "line_number", "paragraph_name"],
            special_rules=SpecialRules(
                lambda_functions="merge_with_procedure",
                comprehensions="inline"
            )
        ),
        
        # JCL Configuration (Legacy)
        "jcl": LanguageConfig(
            parser_name="jcl",
            target_nodes=[
                "job_card",
                "exec_statement",
                "dd_statement",
                "procedure"
            ],
            metadata_fields=["node_type", "line_number", "job_name"],
            special_rules=SpecialRules(
                lambda_functions="group_by_exec",
                comprehensions="inline"
            )
        ),
        
        # CLIST Configuration (Legacy)
        "clist": LanguageConfig(
            parser_name="clist",
            target_nodes=[
                "procedure",
                "function",
                "macro",
                "if_block"
            ],
            metadata_fields=["node_type", "line_number", "procedure_name"],
            special_rules=SpecialRules(
                lambda_functions="inline",
                comprehensions="merge_with_parent"
            )
        ),
        
        # Visual Basic Configuration
        "vb": LanguageConfig(
            parser_name="vbnet",
            target_nodes=[
                "sub_statement",
                "function_statement",
                "class_statement",
                "module_statement",
                "property_statement"
            ],
            metadata_fields=["node_type", "line_number", "sub_name"],
            special_rules=SpecialRules(
                lambda_functions="group_by_control",
                comprehensions="merge_with_parent"
            )
        ),
        
        # Elixir Configuration
        "elixir": LanguageConfig(
            parser_name="elixir",
            target_nodes=[
                "def",
                "defp",
                "defmacro",
                "defmodule",
                "defprotocol",
                "defimpl"
            ],
            metadata_fields=["node_type", "line_number", "function_name"],
            special_rules=SpecialRules(
                lambda_functions="merge_with_function",
                comprehensions="group_together"
            )
        ),
    }


# =============================================================================
# CONFIGURATION LOADING FUNCTIONS
# =============================================================================

def load_policy(path: str) -> PolicyConfig:
    """
    Load policy configuration from a YAML file.
    
    Args:
        path: Path to the YAML configuration file
        
    Returns:
        Configured PolicyConfig instance
        
    Raises:
        FileNotFoundError: If config file doesn't exist
        yaml.YAMLError: If YAML is invalid
        ValueError: If configuration validation fails
    """
    config_path = Path(path)
    
    if not config_path.exists():
        raise FileNotFoundError(f"Policy file not found: {path}")
    
    with open(config_path, 'r', encoding='utf-8') as f:
        raw_config = yaml.safe_load(f)
    
    return _parse_raw_config(raw_config)


def load_default_policy() -> PolicyConfig:
    """Load default policy configuration without reading a file."""
    return PolicyConfig(
        languages=get_default_languages(),
        language_overrides={
            "cobol": 4096,
            "jcl": 1024,
            "elixir": 3072
        }
    )


def _parse_raw_config(raw: Dict[str, Any]) -> PolicyConfig:
    """Parse raw YAML dictionary into typed PolicyConfig."""
    
    # Extract defaults section
    defaults = raw.get('defaults', {})
    
    # Parse overlap strategy
    overlap_strat = OverlapStrategy.NONE
    if 'overlap_strategy' in defaults:
        try:
            overlap_strat = OverlapStrategy(defaults['overlap_strategy'])
        except ValueError:
            pass  # Keep default
            
    # Parse language configurations
    languages = {}
    for lang_name, lang_config in raw.get('languages', {}).items():
        special_rules_dict = lang_config.get('special_rules', {})
        
        languages[lang_name.lower()] = LanguageConfig(
            parser_name=lang_config['parser_name'],
            target_nodes=lang_config.get('target_nodes', []),
            metadata_fields=lang_config.get('metadata_fields', []),
            special_rules=SpecialRules(**special_rules_dict) if special_rules_dict else SpecialRules(),
            fallback_patterns=lang_config.get('fallback_patterns', {})
        )
    
    # Parse advanced configuration
    advanced_raw = raw.get('advanced', {})
    advanced = AdvancedConfig(
        recursive_chunking=advanced_raw.get('recursive_chunking', True),
        max_recursion_depth=advanced_raw.get('max_recursion_depth', 3),
        merge_strategy=MergeStrategy.SEQUENTIAL,  # Simplified for now
        context_lines_before=advanced_raw.get('context_lines_before', 2),
        context_lines_after=advanced_raw.get('context_lines_after', 2)
    )
    
    # Parse debug configuration
    debug_raw = raw.get('debug', {})
    debug = DebugConfig(
        enabled=debug_raw.get('enabled', False),
        log_ast=debug_raw.get('log_ast', False),
        log_chunks=debug_raw.get('log_chunks', True),
        verbose_errors=debug_raw.get('verbose_errors', True)
    )
    
    # Parse language overrides
    lang_overrides = {}
    for lang, size in advanced_raw.get('language_overrides', {}).items():
        lang_overrides[lang.lower()] = int(size)
    
    return PolicyConfig(
        max_context_size=defaults.get('max_context_size', 2048),
        overlap_strategy=overlap_strat,
        min_chunk_size=defaults.get('min_chunk_size', 100),
        include_comments=defaults.get('include_comments', True),
        include_docstrings=defaults.get('include_docstrings', True),
        languages=languages,
        advanced=advanced,
        debug=debug,
        language_overrides=lang_overrides
    )


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def validate_policy_file(path: str) -> bool:
    """
    Validate a policy file without loading it.
    
    Args:
        path: Path to the YAML configuration file
        
    Returns:
        True if valid, raises exception otherwise
    """
    try:
        load_policy(path)
        return True
    except Exception as e:
        raise ValueError(f"Policy validation failed: {e}")


def get_supported_languages() -> List[str]:
    """Get list of all supported language names."""
    return list(get_default_languages().keys())


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Main classes
    "PolicyConfig",
    "LanguageConfig", 
    "SpecialRules",
    "AdvancedConfig",
    "DebugConfig",
    
    # Enums
    "OverlapStrategy",
    "MergeStrategy",
    
    # Functions
    "load_policy",
    "load_default_policy",
    "validate_policy_file",
    "get_supported_languages",
]
