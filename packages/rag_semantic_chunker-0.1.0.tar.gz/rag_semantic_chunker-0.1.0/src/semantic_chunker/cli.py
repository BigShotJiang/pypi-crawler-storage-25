"""
Semantic Code Chunker - Command-Line Interface

Provides an argparse-based CLI invocable via ``python -m semantic_chunker``.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import List


def _build_parser() -> argparse.ArgumentParser:
    """Build and return the argument parser."""
    parser = argparse.ArgumentParser(
        prog="semantic_chunker",
        description="Split source code into semantic chunks based on AST analysis.",
    )

    # Standalone flags (don't require positional args) ----------------------
    parser.add_argument(
        "--list-languages",
        action="store_true",
        default=False,
        help="Print all supported language names and exit.",
    )
    parser.add_argument(
        "--validate-policy",
        metavar="PATH",
        default=None,
        help="Validate a policy YAML file, print result, and exit.",
    )

    # Positional arguments --------------------------------------------------
    parser.add_argument(
        "file",
        nargs="?",
        default=None,
        help="Path to the source file to chunk.",
    )
    parser.add_argument(
        "language",
        nargs="?",
        default=None,
        help="Language identifier (e.g. python, java, javascript).",
    )

    # Optional flags --------------------------------------------------------
    parser.add_argument(
        "--context-size",
        type=int,
        default=None,
        help="Override the default max context size (characters per chunk).",
    )
    parser.add_argument(
        "--policy",
        default=None,
        help="Path to a custom policy YAML file.",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Write results to this file instead of stdout.",
    )
    parser.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        dest="fmt",
        help="Output format: text (default) or json.",
    )

    return parser


def _load_policy_config(policy_path: str | None):
    """Load policy config from path or use defaults."""
    from semantic_chunker.config import load_default_policy, load_policy

    if policy_path is not None:
        return load_policy(policy_path)
    return load_default_policy()


def _handle_list_languages(policy_path: str | None) -> None:
    """Print supported languages and exit."""
    config = _load_policy_config(policy_path)
    for lang in sorted(config.languages):
        print(lang)
    sys.exit(0)


def _handle_validate_policy(path: str) -> None:
    """Validate a policy file, print result, and exit with 0 or 1."""
    from semantic_chunker.config import load_policy

    try:
        load_policy(path)
        print(f"Policy file is valid: {path}")
        sys.exit(0)
    except Exception as exc:
        print(f"Policy validation failed: {exc}", file=sys.stderr)
        sys.exit(1)


def _format_text(chunks: List[str]) -> str:
    """Format chunks as text separated by ``---`` delimiter lines."""
    return "\n---\n".join(chunks)


def _format_json(source_code: str, language: str, config, context_size: int | None) -> str:
    """Format chunks as a JSON array with code and metadata fields."""
    from semantic_chunker.parser import ChunkExtractor, create_parser

    lang_config = config.get_language_config(language)
    target_nodes = lang_config.target_nodes
    fallback_patterns = lang_config.fallback_patterns or None

    effective_size = context_size if context_size is not None else config.get_context_size(language)

    parser = create_parser(language, fallback_patterns=fallback_patterns)
    extractor = ChunkExtractor(
        parser,
        max_context_size=effective_size,
        min_chunk_size=config.min_chunk_size,
        include_comments=config.include_comments,
        include_docstrings=config.include_docstrings,
    )
    parsed_chunks = extractor.extract_chunks(source_code, target_nodes)
    return json.dumps([chunk.to_dict() for chunk in parsed_chunks], indent=2)


def main(argv: List[str] | None = None) -> None:
    """CLI entry point."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    # --- standalone flags ---------------------------------------------------
    if args.list_languages:
        _handle_list_languages(args.policy)
        return  # pragma: no cover – sys.exit above

    if args.validate_policy is not None:
        _handle_validate_policy(args.validate_policy)
        return  # pragma: no cover

    # --- positional args required from here ---------------------------------
    if args.file is None or args.language is None:
        parser.error("the following arguments are required: file, language")

    # Validate source file exists
    source_path = Path(args.file)
    if not source_path.exists():
        print(f"Error: source file not found: {args.file}", file=sys.stderr)
        sys.exit(1)

    # Load policy
    config = _load_policy_config(args.policy)

    # Validate language
    language = args.language.lower()
    if not config.is_language_supported(language):
        available = ", ".join(sorted(config.languages))
        print(
            f"Error: unsupported language '{args.language}'. "
            f"Available languages: {available}",
            file=sys.stderr,
        )
        sys.exit(1)

    # Read source file
    source_code = source_path.read_text(encoding="utf-8")

    # Produce output
    if args.fmt == "json":
        output = _format_json(source_code, language, config, args.context_size)
    else:
        from semantic_chunker.chunker import SemanticCodeChunker

        chunker = SemanticCodeChunker(config=config)
        chunks = chunker.chunk_code(language, source_code, context_size=args.context_size)
        output = _format_text(chunks)

    # Write output
    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
    else:
        print(output)
