"""
Semantic Code Chunker - Parser Module

This module provides AST parsing capabilities using tree-sitter, with support
for multiple programming languages and fallback mechanisms for legacy systems.
"""

from __future__ import annotations

import re
import logging
from typing import List, Dict, Any, Optional, Tuple, Iterator
from dataclasses import dataclass, field
from pathlib import Path

try:
    from tree_sitter import Parser as TsParser
    import tree_sitter_languages as tsl
    TREE_SITTER_AVAILABLE = True
except ImportError:
    TREE_SITTER_AVAILABLE = False


# =============================================================================
# LOGGING CONFIGURATION
# =============================================================================

logger = logging.getLogger(__name__)


# =============================================================================
# DATA CLASSES - PARSER OUTPUT STRUCTURES
# =============================================================================

@dataclass
class NodeInfo:
    """Information about a parsed AST node."""
    node_type: str
    start_byte: int
    end_byte: int
    start_line: int
    end_line: int
    text: str = ""
    parent_node: Optional['NodeInfo'] = None
    
    def __post_init__(self):
        """Calculate derived properties."""
        self.length = self.end_byte - self.start_byte
        self.line_range = (self.start_line, self.end_line)


@dataclass  
class ChunkMetadata:
    """Metadata associated with a code chunk."""
    node_type: str
    line_number: int
    end_line: int
    length: int
    language: str
    
    # Language-specific metadata
    function_name: Optional[str] = None
    class_name: Optional[str] = None
    module_name: Optional[str] = None
    namespace: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert metadata to dictionary."""
        return {k: v for k, v in self.__dict__.items() if v is not None}


@dataclass
class ParsedChunk:
    """A complete parsed chunk with code and metadata."""
    code: str
    metadata: ChunkMetadata
    node_info: Optional[NodeInfo] = None
    
    def __len__(self) -> int:
        return len(self.code)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert chunk to dictionary for serialization."""
        return {
            "code": self.code,
            "metadata": self.metadata.to_dict()
        }


# =============================================================================
# AST PARSER CLASS
# =============================================================================

class ASTParser:
    """
    Main AST parser class using tree-sitter.
    
    Provides semantic parsing of source code into structured chunks based on
    language-specific AST nodes (functions, classes, methods, etc.).
    """
    
    # Language to parser name mapping
    LANGUAGE_PARSERS = {
        "python": "python",
        "java": "java", 
        "javascript": "javascript",
        "typescript": "typescript",
        "c": "c",
        "cpp": "cpp",
        "csharp": "c_sharp",
        "cobol": "cobol",
        "jcl": "jcl",
        "clist": "clist",
        "vb": "vbnet",
        "elixir": "elixir",
    }
    
    def __init__(self, language: str, fallback_patterns: Dict[str, str] | None = None):
        """
        Initialize parser for a specific language.
        
        Args:
            language: Language identifier (e.g., 'python', 'java')
            fallback_patterns: Optional custom regex patterns for fallback parsing
            
        Raises:
            ValueError: If language is not supported and no fallback_patterns provided
            RuntimeError: If tree-sitter parser cannot be loaded
        """
        self.language = language.lower()
        self.parser_name = self.LANGUAGE_PARSERS.get(language.lower())
        self._custom_fallback_patterns = fallback_patterns
        
        if not self.parser_name and not fallback_patterns:
            raise ValueError(f"Unsupported language: {language}")
            
        self._parser_instance = None
        self._fallback_mode = False

    @property
    def parser(self) -> Any:
        """Lazy-load the tree-sitter parser."""
        if self._parser_instance is None:
            # Check if tree-sitter is available first
            if not TREE_SITTER_AVAILABLE:
                logger.warning(
                    f"tree-sitter not available for {self.language}. "
                    f"Falling back to regex-based parsing."
                )
                self._fallback_mode = True
                return None
                
            try:
                # Create a new Parser instance (not passing language here)
                parser_instance = TsParser()
                # Get the language using tree_sitter_languages
                lang = tsl.get_language(self.parser_name)
                # Set the language on the parser
                parser_instance.set_language(lang)
                self._parser_instance = parser_instance
                logger.debug(f"Loaded tree-sitter parser for {self.language}")
            except Exception as e:
                logger.warning(
                    f"Failed to load tree-sitter parser for {self.language}: {e}. "
                    f"Falling back to regex-based parsing."
                )
                self._fallback_mode = True
                
        return self._parser_instance
    
    def parse(self, source_code: str) -> Any:
        """
        Parse source code into an AST.
        
        Args:
            source_code: The source code string to parse
            
        Returns:
            tree_sitter.Tree object (or None in fallback mode)
        """
        if self._fallback_mode:
            return None

        parser_inst = self.parser  # may trigger fallback mode
        if self._fallback_mode or parser_inst is None:
            return None

        try:
            tree = parser_inst.parse(source_code.encode('utf-8'))
            return tree
        except Exception as e:
            logger.error(f"Parse error for {self.language}: {e}")
            return None
    
    def build_query(self, target_nodes: List[str]) -> str:
        """
        Build a tree-sitter query string from target node types.
        
        Args:
            target_nodes: List of AST node type names to capture
            
        Returns:
            Query string for tree-sitter
        """
        # Format: (node_type) @capture_name (node_type2) @capture_name2 ...
        queries = [f"({node}) @{node}" for node in target_nodes]
        return " ".join(queries)
    
    def execute_query(self, tree: Any, query_str: str) -> List[Any]:
        """
        Execute a query on the parsed AST.
        
        Args:
            tree: Parsed tree object
            query_str: Query string
            
        Returns:
            List of captured nodes
        """
        if not tree:
            return []
            
        try:
            query = self.parser.query(query_str)
            captures = query.captures(tree.root_node)
            # captures is a dict mapping capture names to lists of nodes; flatten
            flat_nodes = []
            for node_list in captures.values():
                flat_nodes.extend(node_list)
            return flat_nodes
        except Exception as e:
            logger.error(f"Query execution error: {e}")
            return []
    
    def extract_nodes(
        self, 
        source_code: str, 
        target_nodes: List[str]
    ) -> List[NodeInfo]:
        """
        Extract all matching nodes from source code.
        
        Args:
            source_code: Source code string
            target_nodes: List of node types to extract
            
        Returns:
            List of NodeInfo objects with extracted information
        """
        if self._fallback_mode:
            return self._extract_nodes_fallback(source_code, target_nodes)
            
        tree = self.parse(source_code)
        if not tree:
            # parse() may have triggered fallback mode via the parser property
            if self._fallback_mode:
                return self._extract_nodes_fallback(source_code, target_nodes)
            return []
            
        query_str = self.build_query(target_nodes)
        nodes = self.execute_query(tree, query_str)
        
        node_infos = []
        for node in nodes:
            # Get text content from source code using byte offsets
            start_byte = node.start_byte if hasattr(node, 'start_byte') else 0
            end_byte = node.end_byte if hasattr(node, 'end_byte') else len(source_code)
            
            try:
                text = source_code.encode('utf-8')[start_byte:end_byte].decode('utf-8')
            except:
                text = ""
                
            node_info = NodeInfo(
                node_type=node.type if hasattr(node, 'type') else "unknown",
                start_byte=start_byte,
                end_byte=end_byte,
                start_line=node.start_point[0] if hasattr(node, 'start_point') else 0,
                end_line=node.end_point[0] if hasattr(node, 'end_point') else 1,
                text=text
            )
            node_infos.append(node_info)
            
        return sorted(node_infos, key=lambda n: n.start_byte)
    
    def _extract_nodes_fallback(
        self, 
        source_code: str, 
        target_nodes: List[str]
    ) -> List[NodeInfo]:
        """
        Fallback regex-based node extraction for unsupported languages.
        
        Searches the entire source code with re.MULTILINE, computes byte
        offsets relative to the start of the source, and determines multi-line
        spans by scanning forward to the next match or end of file.
        
        Args:
            source_code: Source code string
            target_nodes: Target node types (used to select regex patterns)
            
        Returns:
            List of NodeInfo objects
        """
        logger.info(f"Using fallback regex parsing for {self.language}")
        
        # Language-specific regex patterns
        patterns = self._get_fallback_patterns()
        
        # Collect all match start positions across all patterns
        raw_matches: list[tuple[int, str, re.Match]] = []
        for pattern_name, pattern in patterns.items():
            for match in re.finditer(pattern, source_code, re.MULTILINE):
                raw_matches.append((match.start(), pattern_name, match))
        
        # Sort by start position
        raw_matches.sort(key=lambda x: x[0])
        
        # Pre-compute line start offsets for line number calculation
        source_bytes = source_code.encode('utf-8')
        line_starts = [0]
        for i, ch in enumerate(source_bytes):
            if ch == ord('\n'):
                line_starts.append(i + 1)
        
        def byte_offset_to_line(offset: int) -> int:
            """Convert a byte offset to a 0-indexed line number."""
            lo, hi = 0, len(line_starts) - 1
            while lo <= hi:
                mid = (lo + hi) // 2
                if line_starts[mid] <= offset:
                    lo = mid + 1
                else:
                    hi = mid - 1
            return hi
        
        node_infos = []
        for idx, (start_pos, pattern_name, match) in enumerate(raw_matches):
            start_byte = len(source_code[:start_pos].encode('utf-8'))
            
            # end_byte: scan forward to the next match start or end of file
            if idx + 1 < len(raw_matches):
                next_start_pos = raw_matches[idx + 1][0]
                end_byte = len(source_code[:next_start_pos].encode('utf-8'))
            else:
                end_byte = len(source_bytes)
            
            # Strip trailing whitespace from the span
            while end_byte > start_byte and source_bytes[end_byte - 1:end_byte] in (b' ', b'\n', b'\r', b'\t'):
                end_byte -= 1
            
            start_line = byte_offset_to_line(start_byte)
            end_line = byte_offset_to_line(max(start_byte, end_byte - 1))
            
            try:
                text = source_bytes[start_byte:end_byte].decode('utf-8')
            except Exception:
                text = ""
            
            node_infos.append(NodeInfo(
                node_type=pattern_name,
                start_byte=start_byte,
                end_byte=end_byte,
                start_line=start_line,
                end_line=end_line,
                text=text,
            ))
        
        return node_infos
    
    def _get_fallback_patterns(self) -> Dict[str, str]:
        """Get regex patterns for fallback parsing.
        
        Returns custom patterns if provided, then built-in patterns,
        then the generic default.
        """
        # Use custom fallback patterns if provided
        if self._custom_fallback_patterns:
            return self._custom_fallback_patterns
        
        # Python fallback patterns
        if self.language == "python":
            return {
                "function_definition": r'\bdef\s+(\w+)\s*\(',
                "class_definition": r'\bclass\s+(\w+)',
            }
            
        # Java fallback patterns  
        elif self.language == "java":
            return {
                "method_declaration": r'(public|private|protected)?\s*(static)?\s*\w+\s+(\w+)\s*\([^)]*\)\s*{',
                "class_declaration": r'\bclass\s+(\w+)',
                "interface_declaration": r'\binterface\s+(\w+)',
            }
            
        # JavaScript fallback patterns
        elif self.language == "javascript":
            return {
                "function_declaration": r'\bfunction\s+(\w+)\s*\(',
                "arrow_function": r'(\w+)\s*=\s*(async\s*)?\([^)]*\)\s*=>',
                "class_declaration": r'\bclass\s+(\w+)',
            }
            
        # COBOL fallback patterns (very simplified)
        elif self.language == "cobol":
            return {
                "paragraph": r'^\s*(\w+)\.\s*',
                "section": r'^\s*\d+\s+(.+)\s+SECTION',
                "division": r'\bDIVISION\b',
            }
            
        # JCL fallback patterns
        elif self.language == "jcl":
            return {
                "job_card": r'//\s*(\w+)\s*JOB',
                "exec_statement": r'//\s*\w+\s*EXEC\s+PGM=(.+)',
                "dd_statement": r'//\s*\w+\s*DD',
            }

        # TypeScript fallback patterns
        elif self.language == "typescript":
            return {
                "function_declaration": r'\bfunction\s+(\w+)\s*[<(]',
                "arrow_function": r'(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*(?::\s*\w[^=]*)?\s*=>',
                "class_declaration": r'\bclass\s+(\w+)',
                "interface_declaration": r'\binterface\s+(\w+)',
                "enum_declaration": r'\benum\s+(\w+)',
                "type_alias_declaration": r'\btype\s+(\w+)\s*=',
            }

        # C fallback patterns
        elif self.language == "c":
            return {
                "function_definition": r'\b(\w+)\s+(\w+)\s*\([^)]*\)\s*\{',
                "struct_specifier": r'\bstruct\s+(\w+)',
                "union_specifier": r'\bunion\s+(\w+)',
                "enum_specifier": r'\benum\s+(\w+)',
                "typedef": r'\btypedef\s+',
            }

        # C++ fallback patterns
        elif self.language == "cpp":
            return {
                "function_definition": r'\b(\w+)\s+(\w+)\s*\([^)]*\)\s*(?:const\s*)?\{',
                "method_definition": r'\b(\w+)::(\w+)\s*\([^)]*\)',
                "class_specifier": r'\bclass\s+(\w+)',
                "struct_specifier": r'\bstruct\s+(\w+)',
                "template_declaration": r'\btemplate\s*<[^>]*>',
                "namespace_definition": r'\bnamespace\s+(\w+)',
            }

        # C# fallback patterns
        elif self.language == "csharp":
            return {
                "method_declaration": r'(?:public|private|protected|internal)?\s*(?:static\s+)?(?:async\s+)?\w+\s+(\w+)\s*\([^)]*\)',
                "class_declaration": r'\bclass\s+(\w+)',
                "interface_declaration": r'\binterface\s+(\w+)',
                "struct_declaration": r'\bstruct\s+(\w+)',
                "enum_declaration": r'\benum\s+(\w+)',
                "delegate_declaration": r'\bdelegate\s+\w+\s+(\w+)\s*\(',
                "event_declaration": r'\bevent\s+\w+\s+(\w+)',
                "property_declaration": r'(?:public|private|protected|internal)\s+(?:static\s+)?(?!class\b|interface\b|struct\b|enum\b|delegate\b|event\b|void\b)\w+\s+(\w+)\s*\{',
            }

        # Elixir fallback patterns
        elif self.language == "elixir":
            return {
                "def": r'\bdef\s+(\w+)',
                "defp": r'\bdefp\s+(\w+)',
                "defmacro": r'\bdefmacro\s+(\w+)',
                "defmodule": r'\bdefmodule\s+(\w+)',
                "defprotocol": r'\bdefprotocol\s+(\w+)',
                "defimpl": r'\bdefimpl\s+(\w+)',
            }

        # CLIST fallback patterns
        elif self.language == "clist":
            return {
                "procedure": r'\bPROC\s+\d+',
                "function": r'\bSYSCALL\s+(\w+)',
                "macro": r'\b(\w+)\s+MACRO',
                "if_block": r'\bIF\s+',
            }

        # VB.NET fallback patterns
        elif self.language in ("vb", "vbnet"):
            return {
                "sub_statement": r'(?<!\bEnd\s)(?:Public\s+|Private\s+|Protected\s+|Friend\s+)?Sub\s+(\w+)',
                "function_statement": r'(?<!\bEnd\s)(?:Public\s+|Private\s+|Protected\s+|Friend\s+)?Function\s+(\w+)',
                "class_statement": r'(?<!\bEnd\s)(?:Public\s+|Private\s+|Protected\s+|Friend\s+)?Class\s+(\w+)',
                "module_statement": r'(?<!\bEnd\s)\bModule\s+(\w+)',
                "property_statement": r'(?<!\bEnd\s)(?:Public\s+|Private\s+|Protected\s+|Friend\s+)?Property\s+(\w+)',
            }

        # Default fallback - try to find any function-like pattern
        return {
            "function_like": r'\b(?:def|func|fn|function)\s+(\w+)\s*[({]',
        }


# =============================================================================
# CHUNK EXTRACTOR CLASS  
# =============================================================================

class ChunkExtractor:
    """
    Extracts code chunks from parsed AST nodes.
    
    Handles chunk size limits, merging, and metadata extraction.
    """
    
    def __init__(
        self, 
        parser: ASTParser,
        max_context_size: int = 2048,
        min_chunk_size: int = 100,
        include_comments: bool = True,
        include_docstrings: bool = True
    ):
        """
        Initialize chunk extractor.
        
        Args:
            parser: ASTParser instance for the language
            max_context_size: Maximum characters per chunk
            min_chunk_size: Minimum characters per chunk  
            include_comments: Whether to include comments in chunks
            include_docstrings: Whether to include docstrings
        """
        self.parser = parser
        self.max_context_size = max_context_size
        self.min_chunk_size = min_chunk_size
        self.include_comments = include_comments
        self.include_docstrings = include_docstrings
        
    def extract_chunks(
        self, 
        source_code: str,
        target_nodes: List[str]
    ) -> List[ParsedChunk]:
        """
        Extract chunks from source code based on AST nodes.
        
        Args:
            source_code: Source code string
            target_nodes: Target node types to extract
            
        Returns:
            List of ParsedChunk objects with code and metadata
        """
        # Extract all matching nodes
        nodes = self.parser.extract_nodes(source_code, target_nodes)
        
        if not nodes:
            # Fallback: return entire source as single chunk
            logger.warning(f"No nodes found for {self.parser.language}, returning full source")
            return [ParsedChunk(
                code=source_code.strip(),
                metadata=ChunkMetadata(
                    node_type="full_source",
                    line_number=1,
                    end_line=len(source_code.split('\n')),
                    length=len(source_code),
                    language=self.parser.language
                )
            )]
            
        # Group nodes into chunks respecting size limits
        chunks = self._group_nodes_into_chunks(nodes, source_code)
        
        return chunks
    
    def _group_nodes_into_chunks(
        self, 
        nodes: List[NodeInfo], 
        source_code: str
    ) -> List[ParsedChunk]:
        """Group nodes into size-respecting chunks."""
        
        chunks = []
        current_chunk_content = ""
        current_chunk_metadata = None
        
        for node in nodes:
            # Extract text from source code
            try:
                chunk_text = source_code[node.start_byte:node.end_byte]
            except Exception as e:
                logger.warning(f"Failed to extract text from node at {node.start_byte}: {e}")
                continue
                
            # Calculate if adding this node exceeds max size
            new_size = len(current_chunk_content) + len(chunk_text) + 2  # +2 for separator
            
            if new_size > self.max_context_size and current_chunk_content:
                # Save current chunk and start new one
                chunks.append(ParsedChunk(
                    code=current_chunk_content.strip(),
                    metadata=current_chunk_metadata,
                    node_info=node.parent_node if hasattr(node, 'parent_node') else None
                ))
                current_chunk_content = ""
                current_chunk_metadata = None
                
            # Add to current chunk with separator
            if current_chunk_content:
                current_chunk_content += "\n\n" + chunk_text
            else:
                current_chunk_content = chunk_text
                
            # Update metadata (use first node's info as representative)
            if not current_chunk_metadata:
                current_chunk_metadata = self._extract_metadata(node, source_code)
                
        # Add final chunk if exists
        if current_chunk_content.strip():
            chunks.append(ParsedChunk(
                code=current_chunk_content.strip(),
                metadata=current_chunk_metadata
            ))
            
        return chunks
    
    def _extract_metadata(self, node: NodeInfo, source_code: str) -> ChunkMetadata:
        """Extract metadata from a node."""
        
        # Try to extract function/class names based on language
        func_name = None
        class_name = None
        
        if self.parser.language == "python":
            func_name = self._extract_python_identifier(node.text, r'def\s+(\w+)')
            class_name = self._extract_python_identifier(node.text, r'class\s+(\w+)')
            
        elif self.parser.language in ["java", "csharp"]:
            func_name = self._extract_java_identifier(node.text)
            class_name = self._extract_class_identifier(node.text)
            
        return ChunkMetadata(
            node_type=node.node_type,
            line_number=node.start_line + 1,  # Convert to 1-indexed
            end_line=node.end_line + 1,
            length=len(node.text),
            language=self.parser.language,
            function_name=func_name,
            class_name=class_name
        )
    
    def _extract_python_identifier(self, text: str, pattern: str) -> Optional[str]:
        """Extract identifier from Python code."""
        match = re.search(pattern, text)
        return match.group(1) if match else None
    
    def _extract_java_identifier(self, text: str) -> Optional[str]:
        """Extract method name from Java declaration."""
        # Pattern: returnType methodName(params)
        pattern = r'\w+\s+(\w+)\s*\('
        match = re.search(pattern, text)
        return match.group(1) if match else None
    
    def _extract_class_identifier(self, text: str) -> Optional[str]:
        """Extract class name from declaration."""
        pattern = r'(?:class|interface)\s+(\w+)'
        match = re.search(pattern, text)
        return match.group(1) if match else None


# =============================================================================
# FACTORY FUNCTION
# =============================================================================

def create_parser(language: str, fallback_patterns: Dict[str, str] | None = None) -> ASTParser:
    """
    Factory function to create an AST parser for a language.
    
    Args:
        language: Language identifier
        fallback_patterns: Optional custom regex patterns for fallback parsing
        
    Returns:
        Configured ASTParser instance
    """
    return ASTParser(language, fallback_patterns=fallback_patterns)


def parse_and_chunk(
    source_code: str,
    language: str,
    target_nodes: List[str],
    max_context_size: int = 2048
) -> List[ParsedChunk]:
    """
    Convenience function to parse and chunk in one call.
    
    Args:
        source_code: Source code string
        language: Language identifier
        target_nodes: Target node types
        max_context_size: Maximum chunk size
        
    Returns:
        List of ParsedChunk objects
    """
    parser = create_parser(language)
    extractor = ChunkExtractor(parser, max_context_size=max_context_size)
    
    return extractor.extract_chunks(source_code, target_nodes)


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Main classes
    "ASTParser",
    "ChunkExtractor",
    
    # Data classes  
    "NodeInfo",
    "ChunkMetadata",
    "ParsedChunk",
    
    # Factory functions
    "create_parser",
    "parse_and_chunk",
    
    # Constants
    "TREE_SITTER_AVAILABLE",
]
