#!/usr/bin/env python3
"""
CLI Test Script for Semantic Chunker

This script performs basic functionality tests on the semantic chunker module.
Run with: python -m tests.cli_test or python tests/cli_test.py
"""

import sys
import os
from pathlib import Path

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

def test_imports():
    """Test that all modules can be imported."""
    print("[PACKAGES] Testing module imports...")
    
    try:
        from semantic_chunker.chunker import SemanticCodeChunker
        print("   [OK] SemanticCodeChunker imported")
    except ImportError as e:
        print(f"   [FAIL] Failed to import chunker: {e}")
        return False
    
    try:
        from semantic_chunker.config import load_policy, get_default_languages, PolicyConfig
        print("   [OK] config functions imported")
    except ImportError as e:
        print(f"   [FAIL] Failed to import config: {e}")
        return False
    
    try:
        from semantic_chunker.parser import create_parser, parse_and_chunk
        print("   [OK] create_parser factory imported")
        print("   [OK] parse_and_chunk convenience function imported")
    except ImportError as e:
        print(f"   [FAIL] Failed to import parser utilities: {e}")
        return False
    
    return True

def test_config_loading():
    """Test that configuration can be loaded."""
    print("\n[CONFIG] Testing config loading...")
    
    try:
        from semantic_chunker.config import load_policy, get_default_languages
        
        # Test default languages
        default_langs = get_default_languages()
        if default_langs:
            print(f"   [OK] Default languages loaded: {len(default_langs)} languages")
            for lang in list(default_langs.keys())[:3]:
                print(f"      - {lang}")
        else:
            print("   [FAIL] No default languages found")
            return False
            
        # Test policy file loading
        policy_path = Path(__file__).parent.parent / "src" / "semantic_chunker" / "policy.yaml"
        if policy_path.exists():
            policy_config = load_policy(str(policy_path))
            print(f"   [OK] Policy config loaded from {policy_path}")
            print(f"      Max context size: {policy_config.max_context_size}")
            
    except Exception as e:
        print(f"   [FAIL] Config loading failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

def test_chunker_basic():
    """Test basic chunking functionality using parse_and_chunk."""
    print("\n[CHUNKER] Testing chunker functionality...")
    
    try:
        from semantic_chunker.parser import create_parser, parse_and_chunk
        
        # Test with sample Python code
        test_code = """
def hello_world():
    print('Hello World')

class Calculator:
    def add(self, a, b):
        return a + b
    
    def subtract(self, a, b):
        return a - b
"""
        
        # Define target node types for Python
        target_nodes = ["function_definition", "class_definition"]
        
        # Use parse_and_chunk convenience function
        chunks = parse_and_chunk(
            source_code=test_code,
            language="python",
            target_nodes=target_nodes,
            max_context_size=2048
        )
        
        if chunks:
            print(f"   [OK] Code chunked into {len(chunks)} segments")
            for i, chunk in enumerate(chunks[:2]):  # Show first 2 chunks
                preview = str(chunk)[:60].replace('\n', ' ') + "..."
                print(f"      Chunk {i+1}: {preview}")
        else:
            print("   [FAIL] No chunks returned")
            return False
            
    except Exception as e:
        print(f"   [FAIL] Chunker test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

def test_parser():
    """Test parser functionality using create_parser factory."""
    print("\n[PARSER] Testing parser functionality...")
    
    try:
        from semantic_chunker.parser import create_parser, TREE_SITTER_AVAILABLE
        
        # Use create_parser factory function
        parser = create_parser("python")
        print(f"   [OK] Parser created via factory for: {parser.language}")
        print(f"      Tree-sitter available: {TREE_SITTER_AVAILABLE}")
        
        test_code = "def hello(): return 42"
        
        # Parse the code
        tree = parser.parse(test_code)
        
        if TREE_SITTER_AVAILABLE:
            # When tree-sitter is available, expect a proper parse result
            if tree is not None:
                print(f"   [OK] Code parsed successfully")
                print(f"      Input: {test_code}")
                print(f"      Tree root type: {tree.root_node.type}")
            else:
                print("   [FAIL] Parser returned None unexpectedly")
                return False
        else:
            # When tree-sitter is not available, fallback mode is expected
            print(f"   [OK] Parser in fallback mode (tree-sitter not installed)")
            print(f"      Note: Install 'tree-sitter' and 'tree-sitter-languages' for full functionality")
        
    except Exception as e:
        print(f"   [FAIL] Parser test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

def run_all_tests():
    """Run all tests and report results."""
    print("=" * 60)
    print("[TEST] SEMANTIC CHUNKER - CLI TEST SUITE")
    print("=" * 60)
    
    tests = [
        ("Module Imports", test_imports),
        ("Config Loading", test_config_loading),
        ("Chunker Basic", test_chunker_basic),
        ("Parser", test_parser),
    ]
    
    results = []
    
    for name, test_func in tests:
        try:
            success = test_func()
            results.append((name, success))
        except Exception as e:
            print(f"\n   [ERROR] {name} crashed: {e}")
            results.append((name, False))
    
    # Summary
    print("\n" + "=" * 60)
    print("[SUMMARY] TEST RESULTS")
    print("=" * 60)
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    for name, success in results:
        status = "[PASS]" if success else "[FAIL]"
        print(f"   {status} - {name}")
    
    print("-" * 60)
    print(f"   Total: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n[SUCCESS] All tests passed!")
        return 0
    else:
        print(f"\n[WARNING] {total - passed} test(s) failed")
        return 1

if __name__ == "__main__":
    exit_code = run_all_tests()
    sys.exit(exit_code)