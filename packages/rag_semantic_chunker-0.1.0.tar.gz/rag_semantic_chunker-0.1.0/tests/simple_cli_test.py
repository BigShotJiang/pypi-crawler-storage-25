#!/usr/bin/env python3
"""
Simple CLI Test Script for Semantic Chunker
Basic smoke tests that work independently of codebase bugs.
Run with: uv run python tests/simple_cli_test.py
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


def test_policy_file_exists():
    """Test that policy.yaml exists and is valid YAML."""
    print("[FILE] Testing policy.yaml...")
    
    try:
        import yaml
        
        policy_path = Path(__file__).parent.parent / "src" / "semantic_chunker" / "policy.yaml"
        
        if not policy_path.exists():
            print(f"   [FAIL] Policy file not found at {policy_path}")
            return False
            
        with open(policy_path, 'r', encoding='utf-8') as f:
            policy = yaml.safe_load(f)
            
        if policy and 'languages' in policy:
            langs = list(policy['languages'].keys())
            print(f"   [OK] Policy loaded - {len(langs)} languages configured")
            for lang in langs[:3]:
                print(f"      - {lang}")
            return True
        else:
            print("   [FAIL] Invalid policy structure")
            return False
            
    except Exception as e:
        print(f"   [FAIL] Error reading policy: {e}")
        return False


def test_modules_structure():
    """Test that module files exist and have correct structure."""
    print("\n[STRUCTURE] Testing module structure...")
    
    src_path = Path(__file__).parent.parent / "src" / "semantic_chunker"
    
    expected_files = [
        "__init__.py",
        "chunker.py", 
        "config.py",
        "parser.py",
        "policy.yaml"
    ]
    
    all_exist = True
    for filename in expected_files:
        filepath = src_path / filename
        if filepath.exists():
            size = filepath.stat().st_size
            print(f"   [OK] {filename} ({size} bytes)")
        else:
            print(f"   [FAIL] {filename} NOT FOUND")
            all_exist = False
            
    return all_exist


def test_basic_python_syntax():
    """Test that Python files have valid syntax."""
    print("\n[SYNTAX] Testing Python file syntax...")
    
    src_path = Path(__file__).parent.parent / "src" / "semantic_chunker"
    
    python_files = ["chunker.py", "config.py", "parser.py"]
    
    all_valid = True
    for filename in python_files:
        filepath = src_path / filename
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                compile(f.read(), str(filepath), 'exec')
            print(f"   [OK] {filename} - valid syntax")
        except SyntaxError as e:
            print(f"   [FAIL] {filename} - SYNTAX ERROR: {e}")
            all_valid = False
            
    return all_valid


def test_config_dataclass():
    """Test that config dataclasses can be instantiated."""
    print("\n[CONFIG] Testing config dataclasses...")
    
    try:
        # Import just the dataclass without loading full module
        from semantic_chunker.config import PolicyConfig, LanguageConfig
        
        # Create minimal config
        config = PolicyConfig(
            max_context_size=2048,
            languages={}
        )
        
        print(f"   [OK] PolicyConfig created")
        print(f"      max_context_size: {config.max_context_size}")
        return True
        
    except Exception as e:
        print(f"   [FAIL] Config test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def run_all_tests():
    """Run all tests and report results."""
    print("=" * 60)
    print("[TEST] SEMANTIC CHUNKER - SIMPLE CLI TEST SUITE")
    print("=" * 60)
    
    tests = [
        ("Policy File", test_policy_file_exists),
        ("Module Structure", test_modules_structure),
        ("Python Syntax", test_basic_python_syntax),
        ("Config Dataclass", test_config_dataclass),
    ]
    
    results = []
    
    for name, test_func in tests:
        try:
            success = test_func()
            results.append((name, success))
        except Exception as e:
            print(f"\n   [ERROR] {name} crashed: {e}")
            results.append((name, False))
    
    # Summary
    print("\n" + "=" * 60)
    print("[SUMMARY] TEST RESULTS")
    print("=" * 60)
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    for name, success in results:
        status = "[PASS]" if success else "[FAIL]"
        print(f"   {status} - {name}")
    
    print("-" * 60)
    print(f"   Total: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n[SUCCESS] All tests passed!")
        return 0
    else:
        print(f"\n[WARNING] {total - passed} test(s) failed")
        return 1


if __name__ == "__main__":
    exit_code = run_all_tests()
    sys.exit(exit_code)