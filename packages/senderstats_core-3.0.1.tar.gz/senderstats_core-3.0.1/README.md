# senderstats-core

Core processing engine for SenderStats.

This library provides the underlying logic for analyzing outbound email traffic, identifying top senders, and generating structured reporting data from Proofpoint Smart Search exports or CSV datasets.

---

## Installation

```bash
pip install senderstats-core