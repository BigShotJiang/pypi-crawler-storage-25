"""YADE documentation knowledge system."""
