"""Text preprocessing for search."""
