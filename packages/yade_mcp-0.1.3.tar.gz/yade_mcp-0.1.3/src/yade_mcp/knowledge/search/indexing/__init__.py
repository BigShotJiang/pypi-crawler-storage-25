"""BM25 indexing."""
