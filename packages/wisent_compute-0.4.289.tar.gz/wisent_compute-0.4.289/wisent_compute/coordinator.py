"""Coordinator daemon - the same scheduling tick the GCP Cloud Function runs,
as a long-lived local process so the system can run without GCP CF / Cloud
Scheduler.

Reads the named coordinator entry from the registry (default: the one whose
active=true), constructs the same JobStorage + GCP provider + scheduler call
chain monitor_jobs uses, and loops on the configured interval_seconds.

--once runs a single tick and exits (cron-driven runtimes).

State stays in the registry-declared state_uri (currently always GCS), so
swapping coordinator from GCF to a daemon on the Mac doesn't change which
queue the agents see.
"""
from __future__ import annotations

import os
import sys
import time
from typing import Optional

from .config import BUCKET, WC_PROVIDERS
from .monitor import check_running_jobs, reap_dead_agents
from .providers import get_provider
from .queue.storage import JobStorage
from .scheduler import schedule_queued_jobs
from .targets import Coordinator, load_coordinators, lookup_coordinator


def _log(msg: str) -> None:
    sys.stderr.write(f"[tick] {msg}\n")
    sys.stderr.flush()


def _resolve_coordinator(target: Optional[str]) -> Coordinator:
    """Pick the coordinator entry: explicit --target, or the active one."""
    if target:
        c = lookup_coordinator(target)
        if c is None:
            raise SystemExit(f"coordinator '{target}' not found in registry")
        return c
    active = [c for c in load_coordinators() if c.active]
    if not active:
        raise SystemExit(
            "no active coordinator in registry. Set active=true on one entry "
            "or pass --target NAME explicitly."
        )
    if len(active) > 1:
        names = ", ".join(c.name for c in active)
        raise SystemExit(f"multiple active coordinators ({names}); set active=true on exactly one")
    return active[0]


def _bucket_from_state_uri(state_uri: str) -> str:
    """Strip 'gs://' prefix to get the bucket name JobStorage expects."""
    if state_uri.startswith("gs://"):
        return state_uri[len("gs://"):].split("/", 1)[0]
    return state_uri


def _assign_jobs_to_agents(store: JobStorage) -> int:
    """Centralized makespan-minimizing matcher. Runs every coordinator tick.

    Body lives in scheduler/makespan: estimates per-job runtime from
    completed-job history (TTL-cached), seeds each live agent's
    projection with its in-flight running/ jobs, then assigns each
    queued job (sorted longest-runtime-first within priority) to the
    eligible agent that will finish it earliest under a VRAM-
    concurrency model. Writes assigned_to back to the queue blob; the
    agent side (providers/local/helpers/_job_eligible) refuses jobs
    pinned to a different agent. Priority stays user-controlled — it's
    a queue-order knob, not a fleet-routing one.
    """
    from .scheduler.makespan import assign_jobs
    return assign_jobs(store, log_fn=_log)


def _run_tick(store: JobStorage, secrets: dict) -> int:
    """One scheduling cycle across every provider in WC_PROVIDERS.

    Each provider gets its own check_running_jobs + schedule_queued_jobs
    pass; the queue is shared (state lives in JobStorage), so a
    pin_to_provider job lands wherever its provider field points and an
    unpinned job is offered to whichever provider claims first. A
    constructor failure (e.g. AzureProvider when AZURE_SUBSCRIPTION_ID is
    empty) is logged and skipped so a misconfigured provider never blocks
    the primary one.
    """
    # Coordinator-authoritative sizing: re-zero any queued job whose model
    # has no measured peak (stamp the measured peak if one exists) BEFORE
    # assignment. A pre-0.4.237 agent that requeues a job writes the old
    # hardcoded estimate_gpu_memory value back; makespan's assigned_to-only
    # write then preserves it. Correcting it here each tick makes the
    # coordinator the single sizing authority instead of waiting for
    # fleet-wide drift.
    from .sizing import normalize_queue_sizing
    n_sized = normalize_queue_sizing(store, log_fn=_log)
    if n_sized:
        _log(f"sizing: corrected {n_sized} stale queue gpu_mem_gb values")
    n_assigned = _assign_jobs_to_agents(store)
    if n_assigned:
        _log(f"assignment: matched {n_assigned} queued jobs to agents")
    total = 0
    for name in WC_PROVIDERS:
        provider = get_provider(name)
        check_running_jobs(store, provider, publisher=None)
        reaped = reap_dead_agents(store, provider, kind=name)
        if reaped:
            _log(f"{name}: reaped {reaped} dead-agent VM(s)")
        total += schedule_queued_jobs(store, provider, name, secrets)
    # By-run reaper: drop per-job blobs once a run is fully terminal so
    # completed/+failed/ stop accumulating thousands of orphaned records.
    # Capped per tick to bound work on a large backlog.
    from .monitor.reap.run_reaper import reap_terminal_runs
    from .config import RUN_REAP_PER_TICK
    summary = reap_terminal_runs(store, limit=RUN_REAP_PER_TICK)
    if summary["reaped_runs"]:
        _log(f"run-reaper: reaped {summary['reaped_runs']} run(s), "
             f"deleted {summary['deleted_jobs']} job blob(s)")
    return total


def run(target: Optional[str] = None, once: bool = False) -> int:
    """Coordinator daemon entry point. Used by `wc coordinator`."""
    coord = _resolve_coordinator(target)
    if coord.runtime == "gcp_cloud_function":
        _log(
            f"coordinator '{coord.name}' runtime=gcp_cloud_function: tick is "
            f"driven by Cloud Scheduler, this daemon is a no-op. Use --target "
            f"to point at a runtime=daemon entry instead."
        )
        return 0

    bucket = _bucket_from_state_uri(coord.state_uri) or BUCKET
    store = JobStorage(bucket)
    interval = max(15, int(coord.interval_seconds))
    _log(f"coordinator '{coord.name}' runtime={coord.runtime} interval={interval}s state={coord.state_uri}")

    # Populate the secrets dict that dispatch_agent_vms uses to fill
    # ${KEY} placeholders in startup_gpu_agent.sh. Without this, the
    # rendered script keeps a literal ${HF_TOKEN}; with `set -u` at the
    # top of the template, line 50 (`export HF_TOKEN="${HF_TOKEN}"`)
    # crashes on unbound variable, the agent never starts, and the VM
    # sits idle until manually deleted. We saw 37 such orphan VMs
    # accumulate over ~24h on 2026-05-09 -> 2026-05-10 because secrets
    # had been an empty dict here forever.
    secrets: dict = {}
    for key in ("HF_TOKEN", "HUGGING_FACE_HUB_TOKEN"):
        val = os.environ.get(key, "").strip()
        if val:
            secrets[key] = val
    if "HF_TOKEN" in secrets and "HUGGING_FACE_HUB_TOKEN" not in secrets:
        secrets["HUGGING_FACE_HUB_TOKEN"] = secrets["HF_TOKEN"]
    # Supabase Management API token goes to a distinct placeholder
    # (WC_SUPABASE_TOKEN) so the startup template can use bash empty-
    # default expansion without conflicting with python's literal-string
    # substitution. dispatched VMs export SUPABASE_ACCESS_TOKEN in their
    # env when this is populated.
    supa = os.environ.get("SUPABASE_ACCESS_TOKEN", "").strip()
    if supa:
        secrets["WC_SUPABASE_TOKEN"] = supa
    if not secrets.get("HF_TOKEN"):
        _log(
            "WARN: HF_TOKEN not in coordinator env; dispatched VMs will "
            "fail their startup script on `set -u` line 50. Set HF_TOKEN "
            "in the LaunchAgent's EnvironmentVariables and reload."
        )
    # Drift-detect + in-process pip-upgrade-and-exec for the coordinator
    # itself. Agents already have this via version_check.maybe_drain_or_upgrade
    # but the coordinator had no such loop, so new wisent-compute releases
    # never reached the running mac-mini coordinator without manual
    # LaunchAgent restart. Now: each tick, check PyPI versions; if drift
    # detected, pip install --upgrade and os.execv into the freshly
    # installed entry point. No systemd dependency.
    from .providers.local.version_check import detect_drift, pip_upgrade_and_exec
    while True:
        drift = detect_drift()
        if drift:
            _log(f"coordinator drift detected {drift}; pip_upgrade_and_exec")
            pip_upgrade_and_exec(_log)
        # Re-resolve the coordinator entry from the registry each tick. The
        # initial _resolve_coordinator(target) at process start captures the
        # entry once and never re-checks; if an operator pushes a new
        # registry that removes/renames the entry to stop a racing daemon,
        # the running process keeps reaping VMs forever using the cached
        # entry. Confirmed live 2026-05-15: a stale mac mini daemon kept
        # deleting fresh-heartbeat Llama/Qwen3 VMs for 4+ hours after the
        # registry entry was removed because pip drift never fired (the
        # daemon was already on the latest published version). Re-resolving
        # each tick means a registry change takes effect within one
        # interval_seconds without depending on a PyPI publish.
        if target:
            from .targets import lookup_coordinator as _lookup
            # source="gcs": the GCS registry is the ONLY authority for the
            # self-survival check. The default source="auto" also consults
            # the package-shipped registry.json when the GCS read returns
            # None, and that bundled file still lists local-mac, so a stale
            # daemon whose GCS fetch momentarily fails (or whose _GCS_CACHE
            # is empty) resurrects itself off the bundled copy and keeps
            # reaping fresh training VMs. Confirmed live 2026-05-15: the
            # mac mini daemon returned 3+ times after local-mac was removed
            # from GCS because the bundled registry.json still listed it.
            # GCS-only means: operator removes local-mac from GCS -> daemon
            # exits next tick, with no local escape hatch.
            still_there = _lookup(target, source="gcs")
            if still_there is None:
                _log(
                    f"coordinator '{target}' not in GCS registry; exiting. "
                    f"Operator removed/renamed the entry — daemon stops here so "
                    f"launchd/supervisor backs off and stale code stops issuing "
                    f"GCE mutations."
                )
                raise SystemExit(0)
        n = _run_tick(store, secrets)
        _log(f"tick scheduled={n}")
        if once:
            return 0
        time.sleep(interval)
