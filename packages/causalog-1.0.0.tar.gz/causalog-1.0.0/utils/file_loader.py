import json


def load_logs(uploaded_file):
    """
    Load logs from a Streamlit UploadedFile object.

    Supports:
    - Plain .log / .txt  → list of lines
    - JSON array          → each element converted to string
    - JSON object with a 'logs' key
    """
    content = uploaded_file.read().decode("utf-8", errors="replace")

    # Try JSON first
    stripped = content.strip()
    if stripped.startswith(("[", "{")):
        try:
            data = json.loads(stripped)
            if isinstance(data, list):
                return [str(entry) for entry in data]
            if isinstance(data, dict) and "logs" in data:
                return [str(entry) for entry in data["logs"]]
        except json.JSONDecodeError:
            pass

    # Plain text: split on newlines, drop blank lines
    return [line for line in content.splitlines() if line.strip()]
