import logging
import sys

_logger = logging.getLogger("causaLog")
if not _logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("[%(levelname)s] %(name)s: %(message)s"))
    _logger.addHandler(handler)
    _logger.setLevel(logging.DEBUG)


def log(message, level="debug"):
    """Thin wrapper: log(message) or log(message, level='info')"""
    getattr(_logger, level.lower(), _logger.debug)(message)
