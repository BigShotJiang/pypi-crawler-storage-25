"""
setup.py — thin compatibility shim.

All real configuration lives in pyproject.toml.
This file exists only so that `pip install -e .` works with older pip (<21.3)
and so that `python setup.py --version` still works.
"""
from setuptools import setup

# Everything is declared in pyproject.toml.
# setuptools reads it automatically; we just need this file to exist.
if __name__ == "__main__":
    setup()
