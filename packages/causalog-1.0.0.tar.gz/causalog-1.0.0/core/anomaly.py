"""
anomly.py  (filename kept as-is to match original; canonical name is anomaly.py)
Also create anomaly.py as an alias so pipeline.py import works.
"""
import numpy as np
from sklearn.ensemble import IsolationForest
from config.settings import ANOMALY_CONTAMINATION, CRITICAL_LEVELS


def detect_anomalies(logs_df):
    """
    Detect anomalous log entries using IsolationForest.

    Features used (numeric, derived from the log itself):
    - message length        — very long messages often carry stack traces
    - is_error              — ERROR / CRITICAL flag
    - cluster id            — rare clusters score higher

    Returns the DataFrame with an 'anomaly' column:
        1  = anomaly
        0  = normal
    """
    logs_df = logs_df.copy()

    # --- Build a numeric feature matrix ----------------------------------------
    features = np.column_stack([
        logs_df["message"].str.len().fillna(0).values,
        logs_df["level"].isin(CRITICAL_LEVELS).astype(int).values,
        logs_df.get("cluster", 0) if "cluster" in logs_df.columns
            else np.zeros(len(logs_df)),
    ])

    # IsolationForest returns -1 (anomaly) or +1 (normal); remap to 1 / 0
    if len(features) >= 2:
        model = IsolationForest(
            contamination=ANOMALY_CONTAMINATION,
            random_state=42,
            n_estimators=100,
        )
        raw = model.fit_predict(features)
        logs_df["anomaly"] = (raw == -1).astype(int)
    else:
        logs_df["anomaly"] = 0

    return logs_df
