import spacy

# Load once at module level — avoids reloading on every call
try:
    _nlp = spacy.load("en_core_web_sm")
except OSError:
    # Fallback: blank English model if the small model isn't installed
    _nlp = spacy.blank("en")


def extract_keywords(logs_df):
    """
    Extract meaningful keywords from each log message using spaCy.

    Filters:
    - alphabetic tokens only
    - not a stop-word
    - length ≥ 3 characters
    - returns lemmatised, lower-cased tokens
    """
    keywords_list = []

    for text in logs_df["message"]:
        doc = _nlp(str(text))
        tokens = [
            token.lemma_.lower()
            for token in doc
            if token.is_alpha
            and not token.is_stop
            and len(token.text) >= 3
        ]
        keywords_list.append(tokens)

    logs_df = logs_df.copy()
    logs_df["keywords"] = keywords_list
    return logs_df
