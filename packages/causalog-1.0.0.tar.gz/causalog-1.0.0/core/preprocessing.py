import pandas as pd
import re


def preprocess_logs(logs):
    """
    Parse raw log lines into a structured DataFrame.

    Extracts: timestamp, log level, service/component, and cleaned message.
    Lines that look like stack-trace continuations are skipped.
    """
    data = []

    # Matches: 2026-04-08 10:15:23[,ms]  LEVEL  [Service]  message
    pattern = re.compile(
        r'(?P<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})'
        r'[,\.]?\d*\s+'
        r'(?P<level>ERROR|WARN(?:ING)?|INFO|DEBUG|CRITICAL|TRACE)\s+'
        r'(?:\[(?P<service>[^\]]+)\]\s*)?'
        r'(?P<message>.*)'
    )

    for line in logs:
        line = line.strip()
        if not line:
            continue
        # Skip stack-trace lines (start with whitespace or "Traceback" etc.)
        if line.startswith(('Traceback', 'File ', '  File', 'raise ', 'Exception', 'Error:')):
            continue

        m = pattern.match(line)
        if m:
            level = m.group('level').upper()
            # Normalise WARN → WARNING
            if level == 'WARN':
                level = 'WARNING'
            data.append({
                "raw":       line,
                "timestamp": pd.to_datetime(m.group('timestamp')),
                "level":     level,
                "service":   m.group('service') or 'Unknown',
                "message":   m.group('message').strip(),
            })
        else:
            # Keep unparseable lines with NaN fields so nothing is silently lost
            data.append({
                "raw":       line,
                "timestamp": None,
                "level":     "UNKNOWN",
                "service":   "Unknown",
                "message":   line,
            })

    df = pd.DataFrame(data)

    # Sort by timestamp (NaT rows go to the bottom)
    if not df.empty and df['timestamp'].notna().any():
        df = df.sort_values('timestamp', na_position='last').reset_index(drop=True)

    return df
