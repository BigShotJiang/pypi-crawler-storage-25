def generate_explanations(logs_df):
    """
    Generate a human-readable explanation sentence for every log row.

    Format: "<level> from <service> — <cause>. [⚠ Anomaly detected.]"
    """
    explanations = []

    for _, row in logs_df.iterrows():
        level   = row.get("level", "Log entry")
        service = row.get("service", "an unknown service")
        cause   = row.get("cause", "an unknown issue")
        anomaly = bool(row.get("anomaly", 0))

        sentence = f"{level} from {service} — likely caused by {cause}."
        if anomaly:
            sentence += " ⚠ This entry was flagged as anomalous."

        explanations.append(sentence)

    return explanations
