def root_cause(logs_df):
    """
    Root Cause Analysis engine.

    Returns:
        summary  – dict  {cause_label: count}   (overall frequency)
        details  – list of dicts, one per ERROR/CRITICAL log with context
    """
    from config.settings import CRITICAL_LEVELS

    summary = logs_df["cause"].value_counts().to_dict()

    # Detailed breakdown: only surface actionable (error-level) rows
    critical = logs_df[logs_df["level"].isin(CRITICAL_LEVELS)].copy()

    details = []
    for _, row in critical.iterrows():
        details.append({
            "timestamp": str(row.get("timestamp", "N/A")),
            "service":   row.get("service", "Unknown"),
            "level":     row.get("level", ""),
            "cause":     row.get("cause", "Unknown"),
            "message":   row.get("message", row.get("raw", "")),
            "anomaly":   bool(row.get("anomaly", 0)),
            "cluster":   row.get("cluster_label", f"Cluster-{row.get('cluster', '?')}"),
        })

    return {"summary": summary, "details": details}
