"""
insight_engine.py
─────────────────
Generates human-readable, dashboard-ready insights by synthesising signals
from validated hypotheses, temporal analysis, and feature data.

Each insight is structured for direct rendering in the React Quick Insights
Sidebar (visible in the dashboard mockup):

    {
        "id":         "ins_001",
        "timestamp":  "14:32",
        "severity":   "HIGH" | "MEDIUM" | "LOW",
        "title":      "High API failures in `auth-service`",
        "detail":     "Probable Cause: Token validation timeout (92% confidence).",
        "cause":      "High Traffic / Gateway Timeout",
        "confidence": 0.92,
        "tags":       ["spike", "auth-service", "timeout"],
        "action_hint":"[Explore Causal Path]",
    }
"""

from __future__ import annotations
from datetime import datetime
from typing import Any, Dict, List


def generate_insights(
    validated_hypotheses: List[Dict[str, Any]],
    temporal:             Dict[str, Any],
    features:             Dict[str, Any],
) -> List[Dict[str, Any]]:
    """
    Generate a ranked list of insights for the dashboard.

    Parameters
    ----------
    validated_hypotheses : list  — output of validator.validate_hypotheses()
    temporal             : dict  — output of temporal_analysis.analyse_temporal()
    features             : dict  — output of feature_builder.build_features()

    Returns
    -------
    list of insight dicts, sorted by severity then confidence.
    """
    insights: List[Dict[str, Any]] = []
    counter = [0]

    def _next_id():
        counter[0] += 1
        return f"ins_{counter[0]:03d}"

    now_str = datetime.now().strftime("%H:%M")

    # ── Insight 1: Top hypothesis ─────────────────────────────────────────
    if validated_hypotheses:
        top = validated_hypotheses[0]
        conf_pct = int(top["confidence"] * 100)
        severity = "HIGH" if conf_pct >= 75 else "MEDIUM" if conf_pct >= 50 else "LOW"
        # Find the worst-offending service for this cause
        svc = _service_for_cause(top["cause"], features)
        insights.append({
            "id":         _next_id(),
            "timestamp":  now_str,
            "severity":   severity,
            "title":      f"High {_cause_short(top['cause'])} failures"
                          + (f" in `{svc}`" if svc else ""),
            "detail":     f"Probable Cause: {top['cause']} ({conf_pct}% confidence).",
            "cause":      top["cause"],
            "confidence": top["confidence"],
            "tags":       _tags(top, svc),
            "action_hint":"[Explore Causal Path]",
        })

    # ── Insight 2: Temporal spike ─────────────────────────────────────────
    high_spikes = [s for s in temporal.get("spikes", []) if s["severity"] == "HIGH"]
    if high_spikes:
        spike = high_spikes[0]
        svc   = _most_active_service(features)
        insights.append({
            "id":         _next_id(),
            "timestamp":  spike["minute"][-5:],   # HH:MM portion
            "severity":   "HIGH",
            "title":      f"Spike detected: {spike['errors']} errors/min",
            "detail":     f"Error spike at {spike['minute']} ({spike['errors']} errors). "
                          f"Signature: HIGH_LATENCY_SPIKE",
            "cause":      validated_hypotheses[0]["cause"] if validated_hypotheses else "Unknown",
            "confidence": 0.85,
            "tags":       ["spike", "latency", svc] if svc else ["spike"],
            "action_hint":"[Create Rule]",
        })

    # ── Insight 3: Increasing trend ───────────────────────────────────────
    if temporal.get("trend") == "increasing":
        insights.append({
            "id":         _next_id(),
            "timestamp":  now_str,
            "severity":   "MEDIUM",
            "title":      "Error rate trending upward",
            "detail":     temporal.get("summary", "Error rate is increasing."),
            "cause":      validated_hypotheses[0]["cause"] if validated_hypotheses else "Unknown",
            "confidence": min(0.75, features.get("error_rate", 0) + 0.4),
            "tags":       ["trend", "increasing"],
            "action_hint":"[View Timeline]",
        })

    # ── Insight 4: Multi-cause divergence ─────────────────────────────────
    if len(validated_hypotheses) >= 2:
        top2 = validated_hypotheses[:2]
        gap  = top2[0]["confidence"] - top2[1]["confidence"]
        if gap < 0.15:   # two causes are close — ambiguous
            insights.append({
                "id":         _next_id(),
                "timestamp":  now_str,
                "severity":   "MEDIUM",
                "title":      "Multiple probable root causes",
                "detail":     (f"'{top2[0]['cause']}' ({int(top2[0]['confidence']*100)}%) and "
                               f"'{top2[1]['cause']}' ({int(top2[1]['confidence']*100)}%) "
                               f"are both plausible. Further investigation recommended."),
                "cause":      top2[0]["cause"],
                "confidence": top2[0]["confidence"],
                "tags":       ["multi-cause", "ambiguous"],
                "action_hint":"[Compare Hypotheses]",
            })

    # ── Insight 5: High anomaly ratio ─────────────────────────────────────
    if features.get("anomaly_ratio", 0) > 0.1:
        ratio_pct = int(features["anomaly_ratio"] * 100)
        svc = _most_anomalous_service(features)
        insights.append({
            "id":         _next_id(),
            "timestamp":  now_str,
            "severity":   "MEDIUM",
            "title":      f"Novel anomaly cluster detected"
                          + (f" in `{svc}`" if svc else ""),
            "detail":     (f"{ratio_pct}% of log entries are anomalous. "
                           f"Signature: UNHANDLED_EXCEPTION"),
            "cause":      "Unhandled Exception",
            "confidence": min(0.90, features["anomaly_ratio"] * 2),
            "tags":       ["anomaly", svc] if svc else ["anomaly"],
            "action_hint":"[Create Rule]",
        })

    # Sort: HIGH first, then by confidence desc
    _severity_order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    insights.sort(key=lambda i: (_severity_order.get(i["severity"], 3), -i["confidence"]))

    return insights


# ── Helpers ───────────────────────────────────────────────────────────────────

def _service_for_cause(cause: str, features: Dict) -> str:
    """Return the service with the highest error rate as the likely culprit."""
    services = features.get("services", {})
    if not services:
        return ""
    # Prefer services with errors
    errored = {s: d for s, d in services.items() if d.get("errors", 0) > 0}
    if not errored:
        return ""
    return max(errored, key=lambda s: errored[s]["error_rate"])


def _most_active_service(features: Dict) -> str:
    services = features.get("services", {})
    if not services:
        return ""
    return max(services, key=lambda s: services[s].get("total", 0))


def _most_anomalous_service(features: Dict) -> str:
    services = features.get("services", {})
    if not services:
        return ""
    return max(services, key=lambda s: services[s].get("anomalies", 0))


def _cause_short(cause: str) -> str:
    """Shorten long cause names for titles."""
    mapping = {
        "High Traffic / Gateway Timeout": "API timeout",
        "Database Failure":               "database",
        "Network / Connection Issue":     "network",
        "Memory Exhaustion":              "memory",
        "CPU Overload":                   "CPU",
        "Authentication Failure":         "auth",
        "Payment Service Failure":        "payment",
        "Unhandled Exception":            "exception",
    }
    return mapping.get(cause, cause.lower())


def _tags(hypothesis: Dict, service: str) -> List[str]:
    tags = []
    if service:
        tags.append(service)
    cause = hypothesis.get("cause", "")
    if "timeout" in cause.lower() or "traffic" in cause.lower():
        tags.append("timeout")
    if "database" in cause.lower() or "db" in cause.lower():
        tags.append("db")
    if "auth" in cause.lower():
        tags.append("auth")
    if hypothesis.get("confidence", 0) > 0.8:
        tags.append("high-confidence")
    return tags
