"""
feature_builder.py
──────────────────
Builds structured numeric/statistical signals from the enriched log DataFrame.
These signals feed the hypothesis engine and validator — they are NOT used for
display directly, but every downstream module draws from this single source of
truth so features are computed once and shared.

Output contract (all keys always present, values JSON-serializable):
    {
        "total_logs":        int,
        "error_count":       int,
        "warning_count":     int,
        "anomaly_count":     int,
        "error_rate":        float,   # 0-1
        "anomaly_ratio":     float,   # 0-1
        "services":          {svc: {"total":int,"errors":int,"error_rate":float}},
        "cause_distribution":{cause: {"count":int,"proportion":float}},
        "time_series":       [{"minute": str, "errors":int, "warnings":int, "total":int}],
        "top_keywords":      [{"keyword":str,"count":int}],
    }
"""

from __future__ import annotations
from collections import Counter
from typing import Any, Dict, List


def build_features(df) -> Dict[str, Any]:
    """
    Build feature signals from an enriched log DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain columns: level, service, cause, anomaly, keywords, timestamp, message.

    Returns
    -------
    dict – fully JSON-serializable feature dict.
    """
    if df is None or df.empty:
        return _empty_features()

    df = df.copy()

    total        = len(df)
    error_count  = int(df["level"].isin({"ERROR", "CRITICAL"}).sum())
    warning_count= int((df["level"] == "WARNING").sum())
    anomaly_count= int(df["anomaly"].sum()) if "anomaly" in df.columns else 0

    error_rate   = round(error_count  / total, 4) if total else 0.0
    anomaly_ratio= round(anomaly_count / total, 4) if total else 0.0

    # ── Per-service aggregation ───────────────────────────────────────────
    services: Dict[str, Dict] = {}
    for svc, grp in df.groupby("service"):
        svc_total  = len(grp)
        svc_errors = int(grp["level"].isin({"ERROR", "CRITICAL"}).sum())
        services[str(svc)] = {
            "total":      svc_total,
            "errors":     svc_errors,
            "warnings":   int((grp["level"] == "WARNING").sum()),
            "anomalies":  int(grp["anomaly"].sum()) if "anomaly" in grp.columns else 0,
            "error_rate": round(svc_errors / svc_total, 4) if svc_total else 0.0,
        }

    # ── Cause distribution ────────────────────────────────────────────────
    cause_counts = df["cause"].value_counts().to_dict()
    cause_distribution: Dict[str, Dict] = {}
    for cause, count in cause_counts.items():
        cause_distribution[str(cause)] = {
            "count":      int(count),
            "proportion": round(int(count) / total, 4) if total else 0.0,
        }

    # ── Time series (per-minute buckets) ──────────────────────────────────
    time_series: List[Dict] = []
    ts_col = df["timestamp"] if "timestamp" in df.columns else None
    if ts_col is not None and ts_col.notna().any():
        import pandas as pd
        tdf = df[df["timestamp"].notna()].copy()
        tdf["minute"] = tdf["timestamp"].dt.floor("1min")
        grouped = tdf.groupby("minute")
        for minute, grp in grouped:
            time_series.append({
                "minute":   minute.strftime("%Y-%m-%dT%H:%M"),
                "total":    len(grp),
                "errors":   int(grp["level"].isin({"ERROR","CRITICAL"}).sum()),
                "warnings": int((grp["level"] == "WARNING").sum()),
                "anomalies":int(grp["anomaly"].sum()) if "anomaly" in grp.columns else 0,
            })

    # ── Top keywords ──────────────────────────────────────────────────────
    all_kw: List[str] = []
    if "keywords" in df.columns:
        for kws in df["keywords"]:
            if isinstance(kws, list):
                all_kw.extend(kws)
    top_keywords = [
        {"keyword": kw, "count": cnt}
        for kw, cnt in Counter(all_kw).most_common(20)
    ]

    return {
        "total_logs":         total,
        "error_count":        error_count,
        "warning_count":      warning_count,
        "anomaly_count":      anomaly_count,
        "error_rate":         error_rate,
        "anomaly_ratio":      anomaly_ratio,
        "services":           services,
        "cause_distribution": cause_distribution,
        "time_series":        time_series,
        "top_keywords":       top_keywords,
    }


def _empty_features() -> Dict[str, Any]:
    return {
        "total_logs": 0, "error_count": 0, "warning_count": 0,
        "anomaly_count": 0, "error_rate": 0.0, "anomaly_ratio": 0.0,
        "services": {}, "cause_distribution": {}, "time_series": [],
        "top_keywords": [],
    }
