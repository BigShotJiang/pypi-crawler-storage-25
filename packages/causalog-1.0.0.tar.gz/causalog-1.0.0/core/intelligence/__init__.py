"""
CausaLog Intelligence Layer
────────────────────────────
Exposes the 5 intelligence modules as a clean package API.
Import pattern:
    from core.intelligence.feature_builder  import build_features
    from core.intelligence.hypothesis_engine import generate_hypotheses
    from core.intelligence.validator         import validate_hypotheses
    from core.intelligence.temporal_analysis import analyse_temporal
    from core.intelligence.insight_engine    import generate_insights
    from core.intelligence.debug_assistant   import generate_debug_suggestions
"""
