"""
temporal_analysis.py
────────────────────
Detects trends and spikes in the log time series without any heavy
statistical libraries — pure Python arithmetic on the bucketed time series
produced by feature_builder.

Trend detection: linear regression slope over error counts per minute.
    slope > +threshold → "increasing"
    slope < -threshold → "decreasing"
    otherwise          → "stable"

Spike detection: a minute is a spike when its error count exceeds
    mean + (spike_z × std_dev) of the whole series.

Output contract:
    {
        "trend":         "increasing" | "decreasing" | "stable",
        "slope":         float,          # errors/minute rate of change
        "spikes":        [               # minutes with unusual error counts
            {"minute": "2026-04-08T10:35", "errors": 12, "severity": "HIGH"}
        ],
        "service_trends":{               # per-service trend
            "PaymentService": {"trend":"increasing","slope":0.4}
        },
        "summary":       str,            # one human-readable sentence
    }
"""

from __future__ import annotations
from typing import Any, Dict, List


_SPIKE_Z        = 1.5   # z-score threshold for spike detection
_TREND_MIN_SLOPE= 0.05  # minimum |slope| to call a trend


def analyse_temporal(features: Dict[str, Any], df=None) -> Dict[str, Any]:
    """
    Analyse time-series trends and spikes from pre-built features.

    Parameters
    ----------
    features : dict  — output of feature_builder.build_features()
    df       : pd.DataFrame or None — enriched log DataFrame (for per-service trends)

    Returns
    -------
    dict matching the output contract above.
    """
    time_series = features.get("time_series", [])

    if len(time_series) < 2:
        return {
            "trend": "stable", "slope": 0.0,
            "spikes": [], "service_trends": {},
            "summary": "Insufficient data for temporal analysis.",
        }

    error_counts = [b["errors"] for b in time_series]

    # Global trend
    slope = _linear_slope(error_counts)
    if slope > _TREND_MIN_SLOPE:
        trend = "increasing"
    elif slope < -_TREND_MIN_SLOPE:
        trend = "decreasing"
    else:
        trend = "stable"

    # Spike detection
    spikes = _detect_spikes(time_series, error_counts)

    # Per-service trends (if df is provided)
    service_trends: Dict[str, Dict] = {}
    if df is not None and not df.empty and "timestamp" in df.columns:
        service_trends = _per_service_trends(df)

    # Human-readable summary
    summary = _make_summary(trend, slope, spikes, features)

    return {
        "trend":          trend,
        "slope":          round(slope, 4),
        "spikes":         spikes,
        "service_trends": service_trends,
        "summary":        summary,
    }


# ── Internal helpers ──────────────────────────────────────────────────────────

def _linear_slope(values: List[float]) -> float:
    """Least-squares slope (rise per unit x)."""
    n = len(values)
    if n < 2:
        return 0.0
    x_mean = (n - 1) / 2.0
    y_mean = sum(values) / n
    num = sum((i - x_mean) * (v - y_mean) for i, v in enumerate(values))
    den = sum((i - x_mean) ** 2 for i in range(n))
    return num / den if den else 0.0


def _detect_spikes(
    time_series: List[Dict],
    error_counts: List[int],
) -> List[Dict]:
    """Return minutes whose error count exceeds mean + z×std."""
    if not error_counts:
        return []
    n     = len(error_counts)
    mean  = sum(error_counts) / n
    var   = sum((v - mean) ** 2 for v in error_counts) / n
    std   = var ** 0.5

    threshold = mean + _SPIKE_Z * std
    spikes = []
    for bucket, count in zip(time_series, error_counts):
        if count > threshold and count > 0:
            severity = "HIGH" if count > mean + 2.5 * std else "MEDIUM"
            spikes.append({
                "minute":   bucket["minute"],
                "errors":   count,
                "total":    bucket["total"],
                "severity": severity,
            })
    return spikes


def _per_service_trends(df) -> Dict[str, Dict]:
    """Compute error slope per service from the DataFrame."""
    import pandas as pd
    result: Dict[str, Dict] = {}
    tdf = df[df["timestamp"].notna()].copy()
    if tdf.empty:
        return result
    tdf["minute"] = tdf["timestamp"].dt.floor("1min")

    for svc, grp in tdf.groupby("service"):
        counts_per_min = (
            grp[grp["level"].isin({"ERROR","CRITICAL"})]
            .groupby("minute").size()
            .reindex(tdf["minute"].unique(), fill_value=0)
            .sort_index()
            .tolist()
        )
        if len(counts_per_min) < 2:
            result[str(svc)] = {"trend": "stable", "slope": 0.0}
            continue
        s = _linear_slope(counts_per_min)
        result[str(svc)] = {
            "trend": "increasing" if s > _TREND_MIN_SLOPE
                     else "decreasing" if s < -_TREND_MIN_SLOPE
                     else "stable",
            "slope": round(s, 4),
        }
    return result


def _make_summary(
    trend: str,
    slope: float,
    spikes: List[Dict],
    features: Dict[str, Any],
) -> str:
    error_rate = features.get("error_rate", 0.0)
    parts = []

    if trend == "increasing":
        parts.append(f"Error rate is increasing (slope: {slope:+.2f} errors/min).")
    elif trend == "decreasing":
        parts.append(f"Error rate is decreasing (slope: {slope:+.2f} errors/min).")
    else:
        parts.append("Error rate is stable.")

    if spikes:
        high_spikes = [s for s in spikes if s["severity"] == "HIGH"]
        if high_spikes:
            parts.append(f"{len(high_spikes)} HIGH-severity spike(s) detected.")
        else:
            parts.append(f"{len(spikes)} spike(s) detected.")

    if error_rate > 0.5:
        parts.append(f"Overall error rate is critically high ({error_rate*100:.0f}%).")
    elif error_rate > 0.2:
        parts.append(f"Overall error rate is elevated ({error_rate*100:.0f}%).")

    return " ".join(parts) if parts else "No significant temporal patterns detected."
