"""
hypothesis_engine.py
────────────────────
Generates multiple root-cause hypotheses with prior probabilities derived
purely from the observed cause distribution in the log data.

No ML model is used — this is intentionally interpretable Bayesian-style
reasoning so the outputs are fully explainable to end users.

Output contract:
    [
        {"cause": "Database Failure",              "prior": 0.45, "evidence": [...] },
        {"cause": "High Traffic / Gateway Timeout","prior": 0.30, "evidence": [...] },
        ...
    ]
    Sorted descending by prior. Priors sum to 1.0.
"""

from __future__ import annotations
from typing import Any, Dict, List


# Evidence tags attached to each hypothesis for transparency in the UI
_EVIDENCE_TAGS: Dict[str, List[str]] = {
    "Database Failure":                ["db_keyword", "connection_error"],
    "High Traffic / Gateway Timeout":  ["timeout_keyword", "high_error_rate"],
    "Network / Connection Issue":      ["connection_keyword", "retry_pattern"],
    "Memory Exhaustion":               ["memory_keyword", "oom_pattern"],
    "CPU Overload":                    ["cpu_keyword", "latency_spike"],
    "Authentication Failure":          ["auth_keyword", "401_pattern"],
    "Payment Service Failure":         ["payment_keyword", "gateway_error"],
    "Sync / Scheduling Failure":       ["sync_keyword", "scheduler_pattern"],
    "Transient Failure (Retry triggered)": ["retry_keyword", "intermittent_error"],
    "Unhandled Exception":             ["exception_keyword", "stack_trace"],
    "Disk I/O Issue":                  ["disk_keyword", "io_error"],
    "Authorization / Permission Error":["permission_keyword", "403_pattern"],
    "Null Pointer / Missing Data":     ["null_keyword", "missing_field"],
    "Unknown":                         ["no_matching_keyword"],
}


def generate_hypotheses(features: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Generate ranked root-cause hypotheses from pre-built feature signals.

    Parameters
    ----------
    features : dict
        Output of feature_builder.build_features().

    Returns
    -------
    list of hypothesis dicts, sorted by prior descending.
    """
    cause_dist = features.get("cause_distribution", {})

    if not cause_dist:
        return []

    total_logs = features.get("total_logs", 1) or 1
    hypotheses: List[Dict[str, Any]] = []

    for cause, stats in cause_dist.items():
        prior = round(stats["proportion"], 4)
        if prior <= 0:
            continue

        # Gather supporting evidence signals
        evidence = list(_EVIDENCE_TAGS.get(cause, ["observed_in_logs"]))

        # Add error-rate evidence if this cause co-occurs with high error rate
        if stats["count"] > 0 and features.get("error_rate", 0) > 0.3:
            evidence.append("elevated_error_rate")

        # Add anomaly evidence if anomalies were detected in this run
        if features.get("anomaly_ratio", 0) > 0.05:
            evidence.append("anomaly_detected")

        hypotheses.append({
            "cause":    cause,
            "prior":    prior,
            "count":    stats["count"],
            "evidence": evidence,
        })

    # Normalise priors (they already sum to 1 via proportions, but float
    # arithmetic may cause tiny drift — force exact sum)
    total_prior = sum(h["prior"] for h in hypotheses)
    if total_prior > 0:
        for h in hypotheses:
            h["prior"] = round(h["prior"] / total_prior, 4)

    hypotheses.sort(key=lambda h: h["prior"], reverse=True)
    return hypotheses
