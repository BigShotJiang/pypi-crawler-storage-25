"""
validator.py
────────────
Converts raw hypotheses (priors) into calibrated confidence scores by
multiplying in signal boosts from:

    1. error_rate     — high error rate boosts timeout/db causes
    2. anomaly_ratio  — anomaly presence boosts all causes slightly
    3. service_signal — cause concentrated in one service = more confident
    4. temporal_spike — if time series shows a spike, boost top cause

Formula (interpretable, no ML):
    raw_score = prior
                × (1 + error_boost)
                × (1 + anomaly_boost)
                × (1 + concentration_boost)

Final confidence = softmax-normalised raw_score, clamped to [0.01, 0.99].

Output contract:
    [
        {"cause": "...", "confidence": 0.92, "prior": 0.45, "evidence": [...] },
        ...
    ]
    Sorted descending by confidence.
"""

from __future__ import annotations
import math
from typing import Any, Dict, List


# Causes that are directly boosted by high error rates
_ERROR_SENSITIVE = {
    "High Traffic / Gateway Timeout",
    "Database Failure",
    "Network / Connection Issue",
    "Payment Service Failure",
}

# Causes boosted when anomalies are present
_ANOMALY_SENSITIVE = {
    "Memory Exhaustion",
    "CPU Overload",
    "Unhandled Exception",
    "Disk I/O Issue",
}


def validate_hypotheses(
    hypotheses: List[Dict[str, Any]],
    features:   Dict[str, Any],
) -> List[Dict[str, Any]]:
    """
    Compute confidence scores for each hypothesis.

    Parameters
    ----------
    hypotheses : list
        Output of hypothesis_engine.generate_hypotheses().
    features : dict
        Output of feature_builder.build_features().

    Returns
    -------
    list of dicts with 'confidence' field added, sorted by confidence desc.
    """
    if not hypotheses:
        return []

    error_rate    = features.get("error_rate",    0.0)
    anomaly_ratio = features.get("anomaly_ratio", 0.0)
    services      = features.get("services",      {})

    # Service concentration: if one service has >60% of all errors, +boost
    max_svc_error_rate = max(
        (s["error_rate"] for s in services.values()), default=0.0
    )
    concentration_boost = 0.15 if max_svc_error_rate > 0.6 else 0.0

    scored: List[Dict[str, Any]] = []

    for h in hypotheses:
        cause = h["cause"]
        prior = h["prior"]

        # 1. Error rate boost (0 – 0.25)
        error_boost = 0.0
        if cause in _ERROR_SENSITIVE:
            error_boost = round(min(error_rate * 0.5, 0.25), 4)

        # 2. Anomaly boost (0 – 0.15)
        anomaly_boost = 0.0
        if cause in _ANOMALY_SENSITIVE:
            anomaly_boost = round(min(anomaly_ratio * 0.3, 0.15), 4)

        # 3. Concentration boost (shared, 0 or 0.15)
        raw = prior * (1 + error_boost) * (1 + anomaly_boost) * (1 + concentration_boost)

        entry = dict(h)          # shallow copy, preserve evidence/count
        entry["raw_score"]       = round(raw, 6)
        entry["error_boost"]     = error_boost
        entry["anomaly_boost"]   = anomaly_boost
        scored.append(entry)

    # Softmax normalisation → confidence values that sum to ~1
    raw_scores = [s["raw_score"] for s in scored]
    confidences = _softmax(raw_scores)

    for entry, conf in zip(scored, confidences):
        # Clamp to avoid 0% / 100% which are never truly certain
        entry["confidence"] = round(max(0.01, min(0.99, conf)), 4)

    scored.sort(key=lambda x: x["confidence"], reverse=True)
    return scored


def _softmax(values: List[float]) -> List[float]:
    """Numerically stable softmax."""
    if not values:
        return []
    max_v = max(values)
    exps  = [math.exp(v - max_v) for v in values]
    total = sum(exps)
    return [e / total for e in exps] if total > 0 else [1.0 / len(values)] * len(values)
