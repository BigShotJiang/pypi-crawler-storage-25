"""
debug_assistant.py
──────────────────
Maps validated root-cause hypotheses to concrete, actionable debugging
suggestions. Each suggestion is structured for the React Debug Suggestions
Panel shown in the dashboard mockup.

No ML — pure rule-based lookup with priority ordering.

Output contract per item:
    {
        "cause":       "Database Failure",
        "confidence":  0.88,
        "priority":    "P1" | "P2" | "P3",
        "actions": [
            {
                "step":        1,
                "title":       "Check DB connection pool",
                "description": "Inspect max_connections and active_connections...",
                "command":     "psql -c 'SELECT count(*) FROM pg_stat_activity;'",
                "docs_link":   "https://www.postgresql.org/docs/current/monitoring.html",
            },
            ...
        ],
        "estimated_impact": "HIGH" | "MEDIUM" | "LOW",
    }
"""

from __future__ import annotations
from typing import Any, Dict, List


# ── Action library (cause → ordered action steps) ────────────────────────────
_ACTIONS: Dict[str, List[Dict]] = {

    "High Traffic / Gateway Timeout": [
        {
            "step": 1,
            "title": "Check upstream gateway logs",
            "description": "Review API gateway error logs for repeated timeout patterns.",
            "command": "grep -i 'timeout\\|gateway' /var/log/api-gateway/error.log | tail -50",
            "docs_link": "https://nginx.org/en/docs/http/ngx_http_upstream_module.html",
        },
        {
            "step": 2,
            "title": "Inspect connection pool / rate limits",
            "description": "Verify that connection pool size and rate limits are not exhausted.",
            "command": "curl -s http://localhost:9090/metrics | grep -i 'connections_active'",
            "docs_link": "",
        },
        {
            "step": 3,
            "title": "Scale horizontally or increase timeout threshold",
            "description": "If traffic spike is confirmed, add instances or raise gateway timeout.",
            "command": "kubectl scale deployment api-gateway --replicas=5",
            "docs_link": "https://kubernetes.io/docs/concepts/workloads/controllers/deployment/",
        },
    ],

    "Database Failure": [
        {
            "step": 1,
            "title": "Verify DB connectivity",
            "description": "Ping the database host and check if port 5432 is reachable.",
            "command": "psql -h $DB_HOST -U $DB_USER -c 'SELECT 1;'",
            "docs_link": "https://www.postgresql.org/docs/current/",
        },
        {
            "step": 2,
            "title": "Check active connections and locks",
            "description": "Look for connection saturation or long-running queries blocking others.",
            "command": "psql -c \"SELECT pid, state, wait_event, query FROM pg_stat_activity WHERE state != 'idle';\"",
            "docs_link": "https://www.postgresql.org/docs/current/monitoring-stats.html",
        },
        {
            "step": 3,
            "title": "Review DB slow query log",
            "description": "Identify queries exceeding the slow_query_time threshold.",
            "command": "tail -100 /var/log/postgresql/postgresql-slow.log",
            "docs_link": "",
        },
        {
            "step": 4,
            "title": "Restart connection pool if saturated",
            "description": "If pgBouncer or similar is in use, recycle stale connections.",
            "command": "sudo systemctl restart pgbouncer",
            "docs_link": "https://www.pgbouncer.org/",
        },
    ],

    "Network / Connection Issue": [
        {
            "step": 1,
            "title": "Test network path to failing host",
            "description": "Run traceroute/mtr to confirm packet loss or routing issues.",
            "command": "mtr --report --report-cycles 5 $TARGET_HOST",
            "docs_link": "",
        },
        {
            "step": 2,
            "title": "Check firewall and security group rules",
            "description": "Ensure required ports are open between services.",
            "command": "aws ec2 describe-security-groups --group-ids $SG_ID",
            "docs_link": "https://docs.aws.amazon.com/vpc/latest/userguide/VPC_SecurityGroups.html",
        },
        {
            "step": 3,
            "title": "Review DNS resolution",
            "description": "Confirm service discovery endpoints resolve correctly.",
            "command": "dig +short $SERVICE_HOSTNAME",
            "docs_link": "",
        },
    ],

    "Memory Exhaustion": [
        {
            "step": 1,
            "title": "Check memory usage on affected hosts",
            "description": "Identify processes consuming excessive memory.",
            "command": "ps aux --sort=-%mem | head -20",
            "docs_link": "",
        },
        {
            "step": 2,
            "title": "Look for memory leak patterns",
            "description": "Review heap dumps or memory profiler output.",
            "command": "jmap -heap $PID",
            "docs_link": "https://docs.oracle.com/javase/8/docs/technotes/tools/unix/jmap.html",
        },
        {
            "step": 3,
            "title": "Increase memory limits or add swap",
            "description": "As a short-term fix, raise container/VM memory limits.",
            "command": "kubectl set resources deployment $APP --limits=memory=2Gi",
            "docs_link": "",
        },
    ],

    "Authentication Failure": [
        {
            "step": 1,
            "title": "Check auth service health",
            "description": "Confirm the identity provider / auth service is reachable.",
            "command": "curl -s -o /dev/null -w '%{http_code}' $AUTH_SERVICE_URL/health",
            "docs_link": "",
        },
        {
            "step": 2,
            "title": "Verify token expiry and clock skew",
            "description": "JWT failures are often caused by clock drift between services.",
            "command": "timedatectl status && ntpq -p",
            "docs_link": "",
        },
        {
            "step": 3,
            "title": "Rotate and re-issue credentials if compromised",
            "description": "If brute-force or credential leak is suspected, rotate secrets.",
            "command": "kubectl create secret generic app-credentials --from-literal=key=$NEW_KEY --dry-run=client -o yaml | kubectl apply -f -",
            "docs_link": "",
        },
    ],

    "Payment Service Failure": [
        {
            "step": 1,
            "title": "Check payment gateway status page",
            "description": "Confirm whether the 3rd-party payment provider is experiencing an outage.",
            "command": "curl -s https://status.stripe.com/api/v2/summary.json | jq '.status.description'",
            "docs_link": "https://stripe.com/docs/error-codes",
        },
        {
            "step": 2,
            "title": "Review payment service error codes",
            "description": "Map PMT-5xx error codes to specific gateway failure modes.",
            "command": "grep 'PMT-' /var/log/payment-service/app.log | sort | uniq -c",
            "docs_link": "",
        },
        {
            "step": 3,
            "title": "Enable retry with exponential back-off",
            "description": "Transient gateway errors should be retried with increasing delay.",
            "command": "",
            "docs_link": "https://stripe.com/docs/error-handling#retrying-requests",
        },
    ],

    "Unhandled Exception": [
        {
            "step": 1,
            "title": "Locate and review stack traces",
            "description": "Search logs for Traceback / Exception lines near the failure.",
            "command": "grep -A 10 'Traceback\\|Exception' /var/log/app/app.log | tail -60",
            "docs_link": "",
        },
        {
            "step": 2,
            "title": "Add exception handling around the failing call",
            "description": "Wrap the identified code path with try/except and proper logging.",
            "command": "",
            "docs_link": "",
        },
        {
            "step": 3,
            "title": "Enable Sentry or equivalent error tracking",
            "description": "Capture unhandled exceptions automatically in production.",
            "command": "pip install sentry-sdk",
            "docs_link": "https://docs.sentry.io/platforms/python/",
        },
    ],
}

# Default fallback actions
_DEFAULT_ACTIONS = [
    {
        "step": 1,
        "title": "Collect recent log context",
        "description": "Gather the last 200 lines of logs around the failure time.",
        "command": "tail -200 /var/log/app/app.log",
        "docs_link": "",
    },
    {
        "step": 2,
        "title": "Check system resource utilisation",
        "description": "Review CPU, memory, and disk metrics at the time of failure.",
        "command": "top -b -n1 && df -h && free -m",
        "docs_link": "",
    },
]

# Priority thresholds (confidence-based)
def _priority(confidence: float) -> str:
    if confidence >= 0.75:
        return "P1"
    if confidence >= 0.50:
        return "P2"
    return "P3"


def generate_debug_suggestions(
    validated_hypotheses: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Generate actionable debug suggestions for the top validated hypotheses.

    Parameters
    ----------
    validated_hypotheses : list — output of validator.validate_hypotheses()

    Returns
    -------
    list of suggestion dicts, one per hypothesis (top 3 max), sorted by
    confidence descending.
    """
    if not validated_hypotheses:
        return []

    suggestions: List[Dict[str, Any]] = []

    for hyp in validated_hypotheses[:3]:    # top 3 only
        cause      = hyp.get("cause",      "Unknown")
        confidence = hyp.get("confidence", 0.0)
        actions    = _ACTIONS.get(cause, _DEFAULT_ACTIONS)

        estimated_impact = (
            "HIGH"   if confidence >= 0.75 else
            "MEDIUM" if confidence >= 0.45 else
            "LOW"
        )

        suggestions.append({
            "cause":            cause,
            "confidence":       confidence,
            "confidence_pct":   int(confidence * 100),
            "priority":         _priority(confidence),
            "actions":          actions,
            "estimated_impact": estimated_impact,
            "evidence":         hyp.get("evidence", []),
        })

    return suggestions
