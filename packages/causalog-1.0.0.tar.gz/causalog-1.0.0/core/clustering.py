from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from config.settings import N_CLUSTERS, MIN_CLUSTER_LOGS


def cluster_logs(logs_df):
    """
    Cluster logs by text similarity using TF-IDF + KMeans.

    - Falls back gracefully when there are fewer rows than N_CLUSTERS.
    - Clusters on the cleaned 'message' column (not raw, which has noise).
    - Adds a human-readable 'cluster_label' by picking the most common keyword.
    """
    logs_df = logs_df.copy()

    if len(logs_df) < MIN_CLUSTER_LOGS:
        logs_df["cluster"] = 0
        logs_df["cluster_label"] = "single-group"
        return logs_df

    n = min(N_CLUSTERS, len(logs_df))

    vectorizer = TfidfVectorizer(
        stop_words="english",
        max_features=500,
        ngram_range=(1, 2),   # unigrams + bigrams catch "connection timeout" etc.
    )
    X = vectorizer.fit_transform(logs_df["message"].fillna(""))

    kmeans = KMeans(n_clusters=n, random_state=42, n_init=10)
    logs_df["cluster"] = kmeans.fit_predict(X)

    # Build a readable label per cluster using top TF-IDF term
    feature_names = vectorizer.get_feature_names_out()
    labels = {}
    for cluster_id in range(n):
        center = kmeans.cluster_centers_[cluster_id]
        top_term = feature_names[center.argmax()]
        labels[cluster_id] = f"Cluster-{cluster_id}: {top_term}"

    logs_df["cluster_label"] = logs_df["cluster"].map(labels)
    return logs_df
