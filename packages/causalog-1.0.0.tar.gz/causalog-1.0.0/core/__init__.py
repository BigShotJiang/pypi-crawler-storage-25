"""
CausaLog core package.

Import pattern — always use explicit submodule imports:

    from core.pipeline import run_pipeline

Do NOT import pipeline at package level — it triggers spaCy + sklearn
loading at import time, which breaks test stubs and slows cold starts.
"""
