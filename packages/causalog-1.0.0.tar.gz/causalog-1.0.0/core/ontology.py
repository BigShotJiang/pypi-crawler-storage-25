from config.settings import ONTOLOGY


def map_ontology(logs_df):
    """
    Map each log's raw text to a root-cause category using the ontology
    keyword dictionary defined in config/settings.py.

    Priority: first matching keyword wins (ordered by dict insertion).
    Result is stored in the 'cause' column.
    """
    logs_df = logs_df.copy()
    causes = []

    for text in logs_df["raw"].str.lower():
        found = "Unknown"
        for keyword, label in ONTOLOGY.items():
            if keyword in text:
                found = label
                break
        causes.append(found)

    logs_df["cause"] = causes
    return logs_df
