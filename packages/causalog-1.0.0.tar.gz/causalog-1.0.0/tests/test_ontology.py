"""Tests for core/ontology.py"""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pandas as pd
from core.ontology import map_ontology

def _make_df(raws):
    return pd.DataFrame({"raw": raws, "message": raws, "level": ["ERROR"]*len(raws)})

class TestOntology(unittest.TestCase):

    def test_timeout_maps_to_high_traffic(self):
        result = map_ontology(_make_df(["Gateway timeout error after 30s"]))
        self.assertEqual(result["cause"].iloc[0], "High Traffic / Gateway Timeout")

    def test_database_keyword(self):
        result = map_ontology(_make_df(["Database connection failed"]))
        self.assertEqual(result["cause"].iloc[0], "Database Failure")

    def test_connection_keyword(self):
        result = map_ontology(_make_df(["Lost connection to host"]))
        self.assertEqual(result["cause"].iloc[0], "Network / Connection Issue")

    def test_unknown_for_no_match(self):
        result = map_ontology(_make_df(["Everything looks totally fine here"]))
        self.assertEqual(result["cause"].iloc[0], "Unknown")

    def test_case_insensitive(self):
        result = map_ontology(_make_df(["TIMEOUT occurred in service"]))
        self.assertNotEqual(result["cause"].iloc[0], "Unknown")

    def test_cause_column_added(self):
        self.assertIn("cause", map_ontology(_make_df(["some log"])).columns)

    def test_multiple_rows(self):
        df = _make_df(["timeout connecting to API", "database is unreachable",
                       "memory usage exceeded limit", "completely normal startup log"])
        result = map_ontology(df)
        self.assertEqual(result["cause"].iloc[0], "High Traffic / Gateway Timeout")
        self.assertEqual(result["cause"].iloc[1], "Database Failure")
        self.assertEqual(result["cause"].iloc[2], "Memory Exhaustion")
        self.assertEqual(result["cause"].iloc[3], "Unknown")

    def test_does_not_mutate_input(self):
        df = _make_df(["timeout error"])
        original_cols = set(df.columns)
        map_ontology(df)
        self.assertEqual(set(df.columns), original_cols)

if __name__ == "__main__":
    unittest.main()
