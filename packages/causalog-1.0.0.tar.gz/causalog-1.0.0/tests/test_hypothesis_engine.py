import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from core.intelligence.hypothesis_engine import generate_hypotheses

def _features(causes, total=100, error_rate=0.3, anomaly_ratio=0.05):
    dist = {c: {"count": n, "proportion": round(n/total, 4)}
            for c, n in causes.items()}
    return {"total_logs": total, "error_rate": error_rate,
            "anomaly_ratio": anomaly_ratio, "cause_distribution": dist}

class TestHypothesisEngine(unittest.TestCase):

    def test_returns_list(self):
        self.assertIsInstance(generate_hypotheses(_features({"DB Failure": 50})), list)

    def test_empty_features_returns_empty(self):
        self.assertEqual(generate_hypotheses({"cause_distribution": {}}), [])

    def test_sorted_by_prior_desc(self):
        h = generate_hypotheses(_features({"A": 60, "B": 30, "C": 10}))
        priors = [x["prior"] for x in h]
        self.assertEqual(priors, sorted(priors, reverse=True))

    def test_priors_sum_to_one(self):
        h = generate_hypotheses(_features({"A": 40, "B": 35, "C": 25}))
        self.assertAlmostEqual(sum(x["prior"] for x in h), 1.0, places=2)

    def test_each_has_evidence_list(self):
        for h in generate_hypotheses(_features({"Database Failure": 70, "Unknown": 30})):
            self.assertIsInstance(h["evidence"], list)
            self.assertGreater(len(h["evidence"]), 0)

    def test_cause_key_present(self):
        for h in generate_hypotheses(_features({"DB": 100})):
            self.assertIn("cause", h)

    def test_prior_values_between_0_and_1(self):
        for h in generate_hypotheses(_features({"X": 50, "Y": 50})):
            self.assertGreaterEqual(h["prior"], 0)
            self.assertLessEqual(h["prior"], 1)

    def test_zero_proportion_excluded(self):
        h = generate_hypotheses(_features({"Real": 100, "Ghost": 0}))
        causes = [x["cause"] for x in h]
        self.assertNotIn("Ghost", causes)

if __name__ == "__main__":
    unittest.main()
