"""Tests for core/anomaly.py"""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pandas as pd
from core.anomaly import detect_anomalies

def _make_df(messages, levels, clusters=None):
    n = len(messages)
    return pd.DataFrame({"raw": messages, "message": messages, "level": levels,
                         "cluster": clusters or [0]*n})

class TestAnomalyDetection(unittest.TestCase):

    def test_adds_anomaly_column(self):
        df = _make_df(["normal log"]*10, ["INFO"]*10)
        self.assertIn("anomaly", detect_anomalies(df).columns)

    def test_anomaly_values_are_0_or_1(self):
        df = _make_df(["log"]*12, ["INFO"]*10 + ["ERROR", "ERROR"])
        result = detect_anomalies(df)
        self.assertTrue(set(result["anomaly"].unique()).issubset({0, 1}))

    def test_single_row_does_not_crash(self):
        df = _make_df(["single line"], ["ERROR"])
        result = detect_anomalies(df)
        self.assertIn("anomaly", result.columns)
        self.assertEqual(result["anomaly"].iloc[0], 0)

    def test_does_not_mutate_input(self):
        df = _make_df(["log"]*8, ["INFO"]*8)
        original_cols = set(df.columns)
        detect_anomalies(df)
        self.assertEqual(set(df.columns), original_cols)

    def test_output_length_matches_input(self):
        df = _make_df(["log"]*15, ["INFO"]*13 + ["ERROR", "ERROR"])
        result = detect_anomalies(df)
        self.assertEqual(len(result), 15)

    def test_no_crash_on_two_rows(self):
        df = _make_df(["log a", "log b"], ["INFO", "ERROR"])
        result = detect_anomalies(df)
        self.assertEqual(len(result), 2)

if __name__ == "__main__":
    unittest.main()
