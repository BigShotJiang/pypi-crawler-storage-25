import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from core.intelligence.validator         import validate_hypotheses
from core.intelligence.hypothesis_engine import generate_hypotheses

def _features(causes, error_rate=0.4, anomaly_ratio=0.1):
    total = sum(causes.values()) or 1
    dist = {c: {"count": n, "proportion": round(n/total,4)}
            for c, n in causes.items()}
    services = {"SVC": {"total": total, "errors": int(total*error_rate),
                        "error_rate": error_rate, "anomalies": 2, "warnings": 1}}
    return {"total_logs": total, "error_rate": error_rate,
            "anomaly_ratio": anomaly_ratio, "cause_distribution": dist,
            "services": services}

class TestValidator(unittest.TestCase):

    def _run(self, causes, **kw):
        f = _features(causes, **kw)
        h = generate_hypotheses(f)
        return validate_hypotheses(h, f)

    def test_returns_list(self):
        self.assertIsInstance(self._run({"Database Failure": 80}), list)

    def test_empty_hypotheses(self):
        self.assertEqual(validate_hypotheses([], {}), [])

    def test_confidence_between_0_and_1(self):
        for v in self._run({"DB": 50, "Network": 30, "Unknown": 20}):
            self.assertGreater(v["confidence"], 0)
            self.assertLess(v["confidence"],    1)

    def test_sorted_by_confidence_desc(self):
        result = self._run({"Database Failure": 70, "Unknown": 30})
        confs = [v["confidence"] for v in result]
        self.assertEqual(confs, sorted(confs, reverse=True))

    def test_all_original_keys_preserved(self):
        result = self._run({"Database Failure": 100})
        for v in result:
            self.assertIn("cause",      v)
            self.assertIn("prior",      v)
            self.assertIn("confidence", v)
            self.assertIn("evidence",   v)

    def test_high_error_rate_boosts_timeout_cause(self):
        low  = self._run({"High Traffic / Gateway Timeout": 60, "Unknown": 40}, error_rate=0.05)
        high = self._run({"High Traffic / Gateway Timeout": 60, "Unknown": 40}, error_rate=0.80)
        top_low  = next(v for v in low  if "Timeout" in v["cause"] or "Traffic" in v["cause"])
        top_high = next(v for v in high if "Timeout" in v["cause"] or "Traffic" in v["cause"])
        self.assertGreaterEqual(top_high["confidence"], top_low["confidence"])

    def test_deterministic(self):
        f = _features({"DB": 50, "Network": 30, "Unknown": 20})
        h = generate_hypotheses(f)
        r1 = validate_hypotheses(h, f)
        r2 = validate_hypotheses(h, f)
        self.assertEqual([v["confidence"] for v in r1],
                         [v["confidence"] for v in r2])

if __name__ == "__main__":
    unittest.main()
