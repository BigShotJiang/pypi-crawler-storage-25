"""Tests for core/rca_engine.py"""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pandas as pd
from core.rca_engine import root_cause

def _make_df(levels, causes, services=None, anomalies=None):
    n = len(levels)
    return pd.DataFrame({
        "level":         levels,
        "cause":         causes,
        "service":       services  or ["SVC"] * n,
        "anomaly":       anomalies or [0] * n,
        "message":       ["msg"] * n,
        "timestamp":     [None] * n,
        "cluster_label": ["Cluster-0: test"] * n,
    })

class TestRCAEngine(unittest.TestCase):

    def test_returns_dict_with_summary_and_details(self):
        result = root_cause(_make_df(["ERROR"], ["DB Failure"]))
        self.assertIn("summary", result)
        self.assertIn("details", result)

    def test_summary_is_dict(self):
        result = root_cause(_make_df(["ERROR", "INFO"], ["DB Failure", "Unknown"]))
        self.assertIsInstance(result["summary"], dict)

    def test_summary_counts_correctly(self):
        result = root_cause(_make_df(
            ["ERROR", "ERROR", "INFO"],
            ["Database Failure", "Database Failure", "Unknown"]
        ))
        self.assertEqual(result["summary"]["Database Failure"], 2)
        self.assertEqual(result["summary"]["Unknown"], 1)

    def test_details_excludes_info(self):
        result = root_cause(_make_df(
            ["INFO", "ERROR", "WARNING", "CRITICAL"],
            ["Unknown", "DB Failure", "High Traffic", "Memory"]
        ))
        detail_levels = {d["level"] for d in result["details"]}
        self.assertNotIn("INFO", detail_levels)
        self.assertTrue("ERROR" in detail_levels or "CRITICAL" in detail_levels)

    def test_details_contains_required_keys(self):
        result = root_cause(_make_df(["ERROR"], ["DB Failure"]))
        required = {"timestamp", "service", "level", "cause", "message", "anomaly", "cluster"}
        for d in result["details"]:
            missing = required - d.keys()
            self.assertFalse(missing, f"Missing keys: {missing}")

    def test_empty_dataframe_returns_empty(self):
        df = pd.DataFrame({
            "level":[], "cause":[], "service":[],
            "anomaly":[], "message":[], "timestamp":[], "cluster_label":[]
        })
        result = root_cause(df)
        self.assertEqual(result["summary"], {})
        self.assertEqual(result["details"], [])

    def test_no_errors_gives_empty_details(self):
        result = root_cause(_make_df(["INFO", "INFO", "DEBUG"],
                                     ["Unknown", "Unknown", "Unknown"]))
        self.assertEqual(result["details"], [])

if __name__ == "__main__":
    unittest.main()
