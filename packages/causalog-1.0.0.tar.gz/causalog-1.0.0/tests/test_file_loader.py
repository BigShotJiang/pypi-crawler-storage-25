"""Tests for utils/file_loader.py"""
import sys, os, unittest, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from utils.file_loader import load_logs

class FakeUpload:
    def __init__(self, content): self._c = content
    def read(self): return self._c

class TestFileLoader(unittest.TestCase):

    def test_plain_text_log(self):
        r = load_logs(FakeUpload(b"line one\nline two\n"))
        self.assertEqual(len(r), 2)

    def test_blank_lines_stripped(self):
        r = load_logs(FakeUpload(b"line one\n\n\nline two\n\n"))
        self.assertEqual(len(r), 2)

    def test_json_array(self):
        r = load_logs(FakeUpload(json.dumps(["a","b","c"]).encode()))
        self.assertEqual(r, ["a","b","c"])

    def test_json_object_with_logs_key(self):
        r = load_logs(FakeUpload(json.dumps({"logs":["x","y"]}).encode()))
        self.assertEqual(r, ["x","y"])

    def test_invalid_json_falls_back(self):
        r = load_logs(FakeUpload(b"{ not json\nbut two lines\n"))
        self.assertEqual(len(r), 2)

    def test_encoding_errors_handled(self):
        r = load_logs(FakeUpload(b"valid\n\xff\xfe bad\nother\n"))
        self.assertGreaterEqual(len(r), 2)

    def test_empty_file(self):
        self.assertEqual(load_logs(FakeUpload(b"")), [])

    def test_only_whitespace(self):
        self.assertEqual(load_logs(FakeUpload(b"   \n\t\n")), [])

if __name__ == "__main__":
    unittest.main()
