import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from core.intelligence.insight_engine import generate_insights

def _hyps(causes_conf):
    return [{"cause": c, "confidence": conf, "prior": conf,
             "count": 10, "evidence": ["test"]}
            for c, conf in causes_conf]

def _temporal(trend="stable", spikes=None):
    return {"trend": trend, "slope": 0.1 if trend == "increasing" else 0.0,
            "spikes": spikes or [],
            "service_trends": {}, "summary": "Test summary."}

def _features(error_rate=0.3, anomaly_ratio=0.05):
    return {"total_logs": 100, "error_rate": error_rate,
            "anomaly_ratio": anomaly_ratio,
            "services": {"PaymentService": {"total":50,"errors":20,"error_rate":0.4,
                                            "anomalies":2,"warnings":3}},
            "cause_distribution": {"Database Failure": {"count":60,"proportion":0.6}},
            "time_series": [], "top_keywords": []}

class TestInsightEngine(unittest.TestCase):

    def test_returns_list(self):
        self.assertIsInstance(
            generate_insights(_hyps([("DB", 0.8)]), _temporal(), _features()), list)

    def test_empty_hypotheses_still_works(self):
        result = generate_insights([], _temporal(), _features())
        self.assertIsInstance(result, list)

    def test_each_insight_has_required_keys(self):
        required = {"id","timestamp","severity","title","detail","cause","confidence","tags","action_hint"}
        for ins in generate_insights(_hyps([("Database Failure", 0.88)]), _temporal(), _features()):
            self.assertFalse(required - ins.keys(), f"Missing keys: {required - ins.keys()}")

    def test_severity_values_valid(self):
        valid = {"HIGH", "MEDIUM", "LOW"}
        for ins in generate_insights(_hyps([("DB", 0.9), ("Net", 0.5)]), _temporal(), _features()):
            self.assertIn(ins["severity"], valid)

    def test_high_confidence_gives_high_severity(self):
        result = generate_insights(_hyps([("Database Failure", 0.95)]), _temporal(), _features())
        self.assertTrue(any(i["severity"] == "HIGH" for i in result))

    def test_spike_generates_insight(self):
        spikes = [{"minute":"2026-04-08T10:35","errors":15,"total":20,"severity":"HIGH"}]
        result = generate_insights(
            _hyps([("Database Failure", 0.85)]),
            _temporal(trend="increasing", spikes=spikes),
            _features())
        self.assertTrue(any("spike" in i["tags"] or "Spike" in i["title"] for i in result))

    def test_multi_cause_insight_when_close_confidences(self):
        hyps = _hyps([("Database Failure", 0.52), ("Network Issue", 0.48)])
        result = generate_insights(hyps, _temporal(), _features())
        self.assertTrue(any("multi-cause" in i["tags"] for i in result))

    def test_increasing_trend_generates_insight(self):
        result = generate_insights(
            _hyps([("DB", 0.7)]),
            _temporal(trend="increasing"),
            _features(error_rate=0.5))
        self.assertTrue(any("trend" in i["tags"] for i in result))

    def test_ids_are_unique(self):
        result = generate_insights(
            _hyps([("A", 0.9), ("B", 0.6)]),
            _temporal(trend="increasing", spikes=[{"minute":"T","errors":10,"total":20,"severity":"HIGH"}]),
            _features(anomaly_ratio=0.2))
        ids = [i["id"] for i in result]
        self.assertEqual(len(ids), len(set(ids)))

    def test_confidence_values_valid(self):
        for ins in generate_insights(_hyps([("DB", 0.8)]), _temporal(), _features()):
            self.assertGreaterEqual(ins["confidence"], 0)
            self.assertLessEqual(ins["confidence"],    1)

if __name__ == "__main__":
    unittest.main()
