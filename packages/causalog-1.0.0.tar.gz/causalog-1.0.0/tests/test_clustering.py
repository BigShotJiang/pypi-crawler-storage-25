"""Tests for core/clustering.py"""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pandas as pd
from core.clustering import cluster_logs

def _make_df(messages):
    return pd.DataFrame({"raw": messages, "message": messages,
                         "level": ["ERROR"]*len(messages), "service": ["SVC"]*len(messages)})

class TestClustering(unittest.TestCase):

    def test_adds_cluster_column(self):
        df = _make_df(["db error occurred"]*5 + ["api timeout issue"]*5)
        self.assertIn("cluster", cluster_logs(df).columns)

    def test_adds_cluster_label_column(self):
        df = _make_df(["db error occurred"]*5 + ["api timeout issue"]*5)
        self.assertIn("cluster_label", cluster_logs(df).columns)

    def test_cluster_labels_are_strings(self):
        df = _make_df(["payment failed gateway"]*4 + ["disk read error"]*4)
        for label in cluster_logs(df)["cluster_label"]:
            self.assertIsInstance(label, str)

    def test_fewer_rows_than_clusters(self):
        df = _make_df(["single log line"])
        result = cluster_logs(df)
        self.assertIn("cluster", result.columns)
        self.assertEqual(result["cluster"].iloc[0], 0)

    def test_exactly_min_cluster_logs(self):
        df = _make_df(["log one", "log two"])
        self.assertIn("cluster", cluster_logs(df).columns)

    def test_empty_dataframe(self):
        df = pd.DataFrame({"raw": [], "message": [], "level": [], "service": []})
        result = cluster_logs(df)
        self.assertTrue(result.empty or "cluster" in result.columns)

    def test_does_not_mutate_input(self):
        df = _make_df(["timeout error"]*6)
        original_cols = set(df.columns)
        cluster_logs(df)
        self.assertEqual(set(df.columns), original_cols)

if __name__ == "__main__":
    unittest.main()
