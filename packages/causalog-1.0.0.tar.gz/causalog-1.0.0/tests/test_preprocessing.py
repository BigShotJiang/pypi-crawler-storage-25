"""Tests for core/preprocessing.py"""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pandas as pd
from core.preprocessing import preprocess_logs

SAMPLE_LINES = [
    "2026-04-08 10:15:23,112 INFO  [AuthService] User login attempt: user_id=10234",
    "2026-04-08 10:15:25,102 ERROR [PaymentService] Payment failed: error_code=PMT-502, message=Gateway timeout",
    "2026-04-08 10:16:02,876 ERROR [Database] Connection timeout: db_host=10.0.0.5",
    "2026-04-08 10:15:24,450 WARN  [InventoryService] Low stock warning: product_id=PRD3321",
    '  File "/app/services/order_service.py", line 214, in get_order',
    "some random non-log line without a timestamp",
    "",
]

class TestPreprocessing(unittest.TestCase):

    def test_returns_dataframe(self):
        df = preprocess_logs(SAMPLE_LINES)
        self.assertIsInstance(df, pd.DataFrame)

    def test_expected_columns(self):
        df = preprocess_logs(SAMPLE_LINES)
        for col in ("raw", "timestamp", "level", "service", "message"):
            self.assertIn(col, df.columns, f"Missing column: {col}")

    def test_parses_levels_correctly(self):
        df = preprocess_logs(SAMPLE_LINES)
        levels = set(df["level"].tolist())
        self.assertIn("INFO",  levels)
        self.assertIn("ERROR", levels)
        self.assertIn("WARNING", levels)
        self.assertNotIn("WARN", levels)

    def test_parses_service_names(self):
        df = preprocess_logs(SAMPLE_LINES)
        services = set(df["service"].tolist())
        self.assertIn("AuthService",    services)
        self.assertIn("PaymentService", services)
        self.assertIn("Database",       services)

    def test_stack_trace_lines_skipped(self):
        df = preprocess_logs(SAMPLE_LINES)
        for raw in df["raw"]:
            self.assertFalse(raw.strip().startswith('File "'), "Stack trace line was not filtered")

    def test_empty_lines_skipped(self):
        df = preprocess_logs(SAMPLE_LINES)
        for raw in df["raw"]:
            self.assertNotEqual(raw.strip(), "", "Empty line was not filtered")

    def test_timestamps_are_parsed(self):
        df = preprocess_logs(SAMPLE_LINES)
        valid_ts = df[df["timestamp"].notna()]
        self.assertGreaterEqual(len(valid_ts), 4)

    def test_sorted_by_timestamp(self):
        shuffled = SAMPLE_LINES[:4][::-1]
        df = preprocess_logs(shuffled)
        ts = df["timestamp"].dropna().tolist()
        self.assertEqual(ts, sorted(ts), "DataFrame should be sorted by timestamp")

    def test_empty_input(self):
        df = preprocess_logs([])
        self.assertTrue(df.empty)

    def test_only_blank_lines(self):
        df = preprocess_logs(["", "   ", "\t"])
        self.assertTrue(df.empty)

if __name__ == "__main__":
    unittest.main()
