"""Tests for core/explanation.py"""
import sys, os, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pandas as pd
from core.explanation import generate_explanations

def _make_df(levels, causes, services=None, anomalies=None):
    n = len(levels)
    return pd.DataFrame({
        "level":   levels,
        "cause":   causes,
        "service": services  or ["TestService"] * n,
        "anomaly": anomalies or [0] * n,
        "message": ["some message"] * n,
    })

class TestExplanation(unittest.TestCase):

    def test_returns_list(self):
        self.assertIsInstance(generate_explanations(_make_df(["ERROR"], ["DB Failure"])), list)

    def test_one_explanation_per_row(self):
        df = _make_df(["INFO", "ERROR", "WARNING"],
                      ["Unknown", "DB Failure", "High Traffic"])
        self.assertEqual(len(generate_explanations(df)), 3)

    def test_explanation_contains_level(self):
        result = generate_explanations(_make_df(["ERROR"], ["DB Failure"]))
        self.assertIn("ERROR", result[0])

    def test_explanation_contains_service(self):
        df = _make_df(["ERROR"], ["DB Failure"], services=["PaymentService"])
        self.assertIn("PaymentService", generate_explanations(df)[0])

    def test_explanation_contains_cause(self):
        result = generate_explanations(_make_df(["ERROR"], ["Database Failure"]))
        self.assertIn("Database Failure", result[0])

    def test_anomaly_flag_appended(self):
        result = generate_explanations(_make_df(["ERROR"], ["DB Failure"], anomalies=[1]))
        self.assertTrue("anomal" in result[0].lower() or "⚠" in result[0])

    def test_no_anomaly_flag_for_normal_row(self):
        result = generate_explanations(_make_df(["INFO"], ["Unknown"], anomalies=[0]))
        self.assertNotIn("⚠", result[0])

    def test_empty_dataframe(self):
        df = pd.DataFrame({"level":[], "cause":[], "service":[], "anomaly":[], "message":[]})
        self.assertEqual(generate_explanations(df), [])

if __name__ == "__main__":
    unittest.main()
