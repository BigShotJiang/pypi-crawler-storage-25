# ── CausaLog Global Settings ────────────────────────────────────────────────

# Clustering
N_CLUSTERS = 3                # number of log clusters for KMeans
MIN_CLUSTER_LOGS = 2          # minimum logs required to run clustering

# Anomaly Detection
ANOMALY_CONTAMINATION = 0.1   # expected fraction of anomalies (IsolationForest)

# NLP
MIN_TOKEN_LENGTH = 3          # ignore tokens shorter than this (removes "is", "at" etc.)

# Ontology keywords → root cause labels
ONTOLOGY = {
    "timeout":    "High Traffic / Gateway Timeout",
    "gateway":    "High Traffic / Gateway Timeout",
    "database":   "Database Failure",
    "connection": "Network / Connection Issue",
    "memory":     "Memory Exhaustion",
    "cpu":        "CPU Overload",
    "disk":       "Disk I/O Issue",
    "auth":       "Authentication Failure",
    "permission": "Authorization / Permission Error",
    "null":       "Null Pointer / Missing Data",
    "exception":  "Unhandled Exception",
    "payment":    "Payment Service Failure",
    "sync":       "Sync / Scheduling Failure",
    "retry":      "Transient Failure (Retry triggered)",
}

# Log levels to treat as critical (for anomaly severity colouring)
CRITICAL_LEVELS = {"ERROR", "CRITICAL"}
