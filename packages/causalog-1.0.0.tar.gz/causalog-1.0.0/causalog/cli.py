"""causalog CLI — entry point for `causalog run`"""
from __future__ import annotations
import argparse, json, sys, threading, time, webbrowser
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent
for _p in [str(_ROOT), str(_HERE)]:
    if _p not in sys.path: sys.path.insert(0, _p)

_R="\033[0;31m"; _G="\033[0;32m"; _Y="\033[0;33m"; _B="\033[0;34m"
_C="\033[0;36m"; _W="\033[0;37m"; _BO="\033[1m"; _DI="\033[2m"; _RS="\033[0m"

def _banner():
    print(f"""
{_B}{_BO}  ██████╗ █████╗ ██╗   ██╗███████╗ █████╗ ██╗      ██████╗  ██████╗{_RS}
{_B}{_BO} ██╔════╝██╔══██╗██║   ██║██╔════╝██╔══██╗██║     ██╔═══██╗██╔════╝{_RS}
{_B}{_BO} ██║     ███████║██║   ██║███████╗███████║██║     ██║   ██║██║  ███╗{_RS}
{_B}{_BO} ██║     ██╔══██║██║   ██║╚════██║██╔══██║██║     ██║   ██║██║   ██║{_RS}
{_B}{_BO} ╚██████╗██║  ██║╚██████╔╝███████║██║  ██║███████╗╚██████╔╝╚██████╔╝{_RS}
{_B}{_BO}  ╚═════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝╚══════╝ ╚═════╝  ╚═════╝{_RS}
{_DI}  Intelligent Log Root Cause Analysis  —  v1.0.0{_RS}
""")

_SKIP = {"node_modules","__pycache__",".git",".tox","venv",".venv","dist","build"}

def _find_log(path):
    def _cands(root):
        found = []
        for pat in ("*.log","*.json"):
            for p in root.rglob(pat):
                if any(b in p.parts for b in _SKIP): continue
                if p.suffix==".json" and p.stat().st_size<300: continue
                found.append(p)
        found.sort(key=lambda f: f.stat().st_size, reverse=True)
        return found
    if path:
        p = Path(path)
        if p.is_dir():
            c = _cands(p)
            if not c: _die(f"No .log/.json in {p}")
            if len(c)>1: print(f"{_Y}Found {len(c)} files — using largest: {_BO}{c[0].name}{_RS}")
            return c[0]
        if p.exists(): return p
        _die(f"File not found: {path}")
    c = _cands(Path.cwd())
    if not c:
        print(f"{_R}✗ No .log/.json found.{_RS}\n  Usage: {_BO}causalog run <file.log>{_RS}")
        sys.exit(1)
    if len(c)>1: print(f"{_Y}Auto-discovered {len(c)} files — using: {_BO}{c[0].name}{_RS}")
    else:        print(f"{_G}✓ Found: {_BO}{c[0].name}{_RS}")
    return c[0]

def _die(msg):
    print(f"{_R}✗ {msg}{_RS}"); sys.exit(1)

def _run_pipeline(fp):
    from utils.file_loader import load_logs
    from core.pipeline import run_pipeline
    print(f"{_DI}  Loading…{_RS}")
    raw = fp.read_bytes()
    class _FH:
        def read(self): return raw
    logs = load_logs(_FH())
    if not logs: _die("No parseable log lines found.")
    print(f"{_G}  ✓ Loaded {_BO}{len(logs):,}{_RS}{_G} lines{_RS}")
    print(f"{_DI}  Running pipeline: preprocessing → NLP → clustering → anomaly → ontology → RCA → intelligence…{_RS}")
    return run_pipeline(logs)

def _print_report(results, fp):
    f=results["features"]; hyp=results["hypotheses"]
    ins=results["insights"]; tmp=results["temporal"]; dbg=results["debug_suggestions"]
    def sec(t=""):
        W=62
        if t: pad=max(0,(W-len(t)-2)//2); print(f"\n{_DI}{'─'*pad}{_RS} {_BO}{t}{_RS} {_DI}{'─'*pad}{_RS}")
        else: print(f"{_DI}{'─'*W}{_RS}")
    sec("📊  Overview")
    print(f"  {_W}File       :{_RS}  {_BO}{fp.name}{_RS}")
    print(f"  {_W}Total      :{_RS}  {_BO}{f['total_logs']:>10,}{_RS}")
    print(f"  {_R}Errors     :{_RS}  {_BO}{f['error_count']:>10}{_RS}  ({f['error_rate']*100:.1f}%)")
    print(f"  {_Y}Warnings   :{_RS}  {_BO}{f['warning_count']:>10}{_RS}")
    print(f"  {_C}Anomalies  :{_RS}  {_BO}{f['anomaly_count']:>10}{_RS}  ({f['anomaly_ratio']*100:.1f}%)")
    print(f"  {_B}Services   :{_RS}  {', '.join(f['services'].keys()) or '—'}")
    sec("🧠  Root Cause Hypotheses")
    for h in (hyp or [])[:6]:
        pct=h["confidence"]*100; bar=int(pct*30/100)
        col=_R if pct>=70 else _Y if pct>=45 else _W
        print(f"  {col}{_BO}{pct:>5.1f}%{_RS}  {'█'*bar}{_DI}{'░'*(30-bar)}{_RS}  {h['cause']}")
    sec("💡  AI Insights")
    for i in (ins or []):
        sc=_R if i["severity"]=="HIGH" else _Y if i["severity"]=="MEDIUM" else _G
        print(f"  {sc}{_BO}[{i['severity']:<6}]{_RS}  {_C}{i['timestamp']}{_RS}  {i['title']}")
        print(f"            {_DI}{i['detail']}{_RS}")
    sec("⏱   Temporal")
    tc=_R if tmp["trend"]=="increasing" else _G if tmp["trend"]=="decreasing" else _W
    print(f"  Trend  : {tc}{_BO}{tmp['trend'].upper()}{_RS}  (slope {tmp['slope']:+.2f} err/min)")
    print(f"  Spikes : {len(tmp.get('spikes',[]))}")
    print(f"  {_DI}{tmp['summary']}{_RS}")
    sec("🔧  Debug Suggestions")
    for s in (dbg or [])[:3]:
        pc=_R if s["priority"]=="P1" else _Y
        print(f"\n  {pc}{_BO}[{s['priority']}]{_RS} {_BO}{s['cause']}{_RS}  ({s['confidence_pct']}%)")
        for a in s["actions"][:2]:
            print(f"    Step {a['step']}: {a['title']}")
            if a.get("command"): print(f"      {_G}$ {a['command']}{_RS}")
    sec()

def _save_report(results, outpath):
    out = {}
    for k,v in results.items():
        if k=="data": continue
        try: json.dumps(v); out[k]=v
        except: out[k]=str(v)
    with open(outpath,"w",encoding="utf-8") as fh:
        json.dump(out, fh, indent=2, default=str)
    print(f"\n{_G}✓ Report → {_BO}{outpath}{_RS}")

def _start_server(results, filename, port, open_browser):
    from causalog.server import app, _state
    _state["results"]  = results
    _state["filename"] = filename
    url = f"http://localhost:{port}"
    if open_browser:
        def _open():
            time.sleep(1.4)
            webbrowser.open(url)
            print(f"\n{_G}✓ Dashboard → {_BO}{url}{_RS}")
            print(f"{_DI}  Press Ctrl+C to stop.{_RS}\n")
        threading.Thread(target=_open, daemon=True).start()
    print(f"\n{_B}Starting CausaLog dashboard on {_BO}{url}{_RS} …")
    print(f"{_DI}  (data pre-loaded from {filename}){_RS}\n")
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="warning")

def _cmd_run(args):
    _banner()
    fp = _find_log(args.file)
    print(f"\n{_B}Analysing:{_RS} {_BO}{fp}{_RS}\n")
    t0 = time.perf_counter()
    results = _run_pipeline(fp)
    print(f"{_G}  ✓ Done in {time.perf_counter()-t0:.1f}s{_RS}\n")
    _print_report(results, fp)
    if args.report: _save_report(results, args.report)
    if args.no_server: return
    try:
        _start_server(results, fp.name, args.port, not args.no_browser)
    except KeyboardInterrupt:
        print(f"\n{_Y}Server stopped.{_RS}")

def _cmd_version(_):
    from causalog import __version__
    print(f"causalog {__version__}")

def main():
    p = argparse.ArgumentParser(prog="causalog",
        description="CausaLog — Intelligent Log Root Cause Analysis",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="  causalog run\n  causalog run app.log\n  causalog run logs/\n  causalog run app.log --port 9000 --no-browser\n  causalog run app.log --no-server --report r.json")
    s = p.add_subparsers(dest="command")
    r = s.add_parser("run", help="Analyse a log file and open the dashboard")
    r.add_argument("file", nargs="?", help=".log/.json file or directory (auto-detected if omitted)")
    r.add_argument("--port",       type=int, default=8000, help="Port (default 8000)")
    r.add_argument("--no-browser", action="store_true",    help="Don't open browser")
    r.add_argument("--no-server",  action="store_true",    help="Terminal report only, no web server")
    r.add_argument("--report",     metavar="FILE",         help="Save JSON report to FILE")
    s.add_parser("version", help="Print version")
    args = p.parse_args()
    if   args.command=="run":     _cmd_run(args)
    elif args.command=="version": _cmd_version(args)
    else: _banner(); p.print_help()

if __name__ == "__main__":
    main()
