"""
CausaLog — Intelligent Log Root Cause Analysis
===============================================

Quick start after `pip install causalog`:

    causalog run                     # auto-discover .log in cwd
    causalog run /path/to/app.log    # explicit file
    causalog run logs/               # scan a directory

Python API:

    from causalog.server import app           # FastAPI app (for custom deploy)
    from core.pipeline import run_pipeline    # pipeline only (no server)
"""
__version__ = "1.0.0"
__author__  = "CausaLog Team"
__email__   = "hello@causalog.dev"
__all__     = ["__version__"]
