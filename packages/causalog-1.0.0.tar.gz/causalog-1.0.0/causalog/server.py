"""
causalog/server.py
──────────────────
FastAPI application.  Imported by the CLI; also runnable directly:

    uvicorn causalog.server:app --reload

Serves:
  GET  /                  → pre-built React SPA (index.html)
  GET  /health            → liveness + has_data flag
  POST /api/analyze       → upload .log/.json, run pipeline, cache results
  GET  /api/features      → feature signals
  GET  /api/hypotheses    → confidence-ranked root cause hypotheses
  GET  /api/insights      → AI insight cards (for Quick Insights sidebar)
  GET  /api/temporal      → trend / spike analysis
  GET  /api/debug         → per-cause debug runbooks
  GET  /api/causes        → raw RCA summary + per-error details
  GET  /api/logs          → paginated + filtered log rows
  GET  /api/clusters      → cluster summary with sparkline data
"""
from __future__ import annotations
import json
import sys
from pathlib import Path
from collections import Counter
from typing import Optional

# ── sys.path: let this file be importable from any working directory ──────────
_HERE = Path(__file__).resolve().parent   # …/site-packages/causalog/
_ROOT = _HERE.parent                      # …/site-packages/
for _p in (str(_ROOT), str(_HERE)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import pandas as pd
from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title       = "CausaLog",
    version     = "1.0.0",
    description = "Intelligent Log Root Cause Analysis API",
    docs_url    = "/api/docs",
    redoc_url   = "/api/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins     = ["*"],
    allow_credentials = True,
    allow_methods     = ["*"],
    allow_headers     = ["*"],
)

# ── In-memory state ───────────────────────────────────────────────────────────
_state: dict = {"results": None, "filename": None}

# ── Pre-load the SPA HTML once at import time ─────────────────────────────────
_SPA_HTML: str = (_HERE / "static" / "index.html").read_text(encoding="utf-8")


# ── Serialisation helper ──────────────────────────────────────────────────────
def _safe(obj):
    """Recursively convert any pipeline output to a JSON-serialisable type."""
    if obj is None:                       return None
    if isinstance(obj, bool):             return obj
    if isinstance(obj, (int, float, str)):return obj
    if isinstance(obj, dict):
        return {str(k): _safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_safe(i) for i in obj]
    if isinstance(obj, pd.DataFrame):
        df2 = obj.copy()
        for col in df2.columns:
            try:
                df2[col] = df2[col].astype(str)
            except Exception:
                pass
        return df2.to_dict(orient="records")
    if isinstance(obj, pd.Series):
        return _safe(obj.to_dict())
    if hasattr(obj, "item"):              # numpy scalar
        return obj.item()
    if hasattr(obj, "isoformat"):         # datetime / Timestamp
        return str(obj)
    try:
        json.dumps(obj)
        return obj
    except (TypeError, ValueError):
        return str(obj)


def _require():
    """Return cached results or raise 404."""
    if _state["results"] is None:
        raise HTTPException(
            status_code = 404,
            detail      = "No analysis available yet. POST /api/analyze first.",
        )
    return _state["results"]


# ═══════════════════════════════════════════════════════════════════════════════
# API routes  (must be registered BEFORE the catch-all SPA route)
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/health", tags=["meta"])
def health():
    """Liveness probe — also reports whether analysis data is loaded."""
    return {
        "status":   "ok",
        "has_data": _state["results"] is not None,
        "filename": _state["filename"],
    }


@app.post("/api/analyze", tags=["pipeline"])
async def analyze(file: UploadFile = File(...)):
    """
    Upload a .log or .json file, run the full CausaLog pipeline,
    cache results server-side, and return a summary.
    """
    content = await file.read()

    class _FH:
        def read(self): return content

    try:
        from utils.file_loader import load_logs
        from core.pipeline     import run_pipeline

        logs = load_logs(_FH())
        if not logs:
            raise HTTPException(400, "No parseable log lines found in the uploaded file.")

        results = run_pipeline(logs)
        _state["results"]  = results
        _state["filename"] = file.filename

        f = results["features"]
        return JSONResponse({
            "status":   "ok",
            "filename": file.filename,
            "summary": {
                "total_logs":    _safe(f.get("total_logs",    0)),
                "error_count":   _safe(f.get("error_count",   0)),
                "warning_count": _safe(f.get("warning_count", 0)),
                "anomaly_count": _safe(f.get("anomaly_count", 0)),
                "error_rate":    _safe(f.get("error_rate",    0.0)),
            },
        })
    except HTTPException:
        raise
    except Exception as exc:
        import traceback
        traceback.print_exc()
        raise HTTPException(500, f"Pipeline error: {exc}")


@app.get("/api/features", tags=["results"])
def get_features():
    """Feature signals: counts, rates, per-service stats, time series, keywords."""
    return JSONResponse(_safe(_require()["features"]))


@app.get("/api/hypotheses", tags=["results"])
def get_hypotheses():
    """Confidence-ranked root cause hypotheses."""
    return JSONResponse(_safe(_require()["hypotheses"]))


@app.get("/api/insights", tags=["results"])
def get_insights():
    """AI insight cards for the Quick Insights sidebar."""
    return JSONResponse(_safe(_require()["insights"]))


@app.get("/api/temporal", tags=["results"])
def get_temporal():
    """Trend direction, slope, spike list, per-service trends."""
    return JSONResponse(_safe(_require()["temporal"]))


@app.get("/api/debug", tags=["results"])
def get_debug():
    """Per-cause debug runbooks with shell commands."""
    return JSONResponse(_safe(_require()["debug_suggestions"]))


@app.get("/api/causes", tags=["results"])
def get_causes():
    """Raw RCA output: summary dict + per-error detail list."""
    return JSONResponse(_safe(_require()["causes"]))


@app.get("/api/logs", tags=["results"])
def get_logs(
    page:     int            = Query(1,   ge=1,        description="Page number"),
    per_page: int            = Query(60,  ge=1, le=500, description="Rows per page"),
    level:    Optional[str]  = Query(None, description="Comma-separated log levels, e.g. ERROR,WARNING"),
    service:  Optional[str]  = Query(None, description="Filter by service name"),
    search:   Optional[str]  = Query(None, description="Substring search on message field"),
):
    """Paginated, filterable log rows."""
    r  = _require()
    df = r["data"].copy()

    # ── Filtering ─────────────────────────────────────────────────────────────
    if level:
        wanted = {lv.strip().upper() for lv in level.split(",")}
        if "WARN" in wanted:
            wanted.add("WARNING")       # treat WARN as alias
        df = df[df["level"].isin(wanted)]

    if service and service != "all":
        df = df[df["service"] == service]

    if search:
        mask = df["message"].str.contains(search, case=False, na=False)
        df   = df[mask]

    total   = len(df)
    page_df = df.iloc[(page - 1) * per_page : page * per_page]

    rows = [
        {
            "timestamp": str(row.get("timestamp", ""))[:19],
            "level":     str(row.get("level",          "")),
            "service":   str(row.get("service",        "")),
            "host":      "aws-us-east-1a",
            "message":   str(row.get("message",        ""))[:200],
            "cause":     str(row.get("cause",          "")),
            "anomaly":   bool(row.get("anomaly",        0)),
            "cluster":   str(row.get("cluster_label",  "")),
        }
        for _, row in page_df.iterrows()
    ]

    all_services = sorted(r["data"]["service"].dropna().unique().tolist())

    return JSONResponse({
        "total":    total,
        "page":     page,
        "per_page": per_page,
        "rows":     rows,
        "services": all_services,
    })


@app.get("/api/clusters", tags=["results"])
def get_clusters():
    """Cluster summary cards with severity, keywords, and 8-point sparklines."""
    r  = _require()
    df = r["data"]

    if "cluster_label" not in df.columns:
        return JSONResponse([])

    clusters = []
    for label, grp in df.groupby("cluster_label"):
        n   = len(grp)
        err = int(grp["level"].isin({"ERROR", "CRITICAL"}).sum())
        wrn = int((grp["level"] == "WARNING").sum())

        sev = (
            "HIGH"   if err / max(n, 1) > 0.40 else
            "MEDIUM" if err / max(n, 1) > 0.15 else
            "INFO"
        )

        # Keyword extraction
        all_kw: list = []
        if "keywords" in grp.columns:
            for ks in grp["keywords"]:
                if isinstance(ks, list):
                    all_kw.extend(ks)
        kws = [k for k, _ in Counter(all_kw).most_common(5)]

        # 8-bucket sparkline (error count per bucket)
        chunk = max(1, n // 8)
        trend = [
            int(grp.iloc[i:i + chunk]["level"].isin({"ERROR", "CRITICAL"}).sum())
            for i in range(0, n, chunk)
        ][:8]

        clusters.append({
            "label":    str(label),
            "count":    n,
            "errors":   err,
            "warnings": wrn,
            "severity": sev,
            "keywords": kws,
            "trend":    trend,
        })

    clusters.sort(key=lambda c: c["errors"], reverse=True)
    return JSONResponse(clusters)


# ═══════════════════════════════════════════════════════════════════════════════
# SPA catch-all — MUST be last so it doesn't shadow /api/* or /health
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/{full_path:path}", response_class=HTMLResponse, include_in_schema=False)
def serve_spa(full_path: str = ""):
    """Serve the bundled React SPA for every non-API route."""
    return HTMLResponse(_SPA_HTML)
