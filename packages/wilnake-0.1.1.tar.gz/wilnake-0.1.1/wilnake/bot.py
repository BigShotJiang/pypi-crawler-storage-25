from __future__ import annotations

import asyncio
import contextlib
import inspect
import shlex
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable, Iterable

import aiohttp

from .command import (
    Callback,
    CheckCallback,
    CheckFailure,
    Cog,
    Command,
    CommandOnCooldown,
    DisabledCommand,
    MemberNotMuted,
    SlashCommand,
    SlashOption,
    normalize_aliases,
)
from .components import ButtonListener
from .context import ComponentContext, MessageContext, ModalContext, SlashContext
from .http import DiscordHTTPClient
from .intents import Intents
from .modal import Modal, combine_text_inputs


EventCallback = Callable[..., Awaitable[None]]

OP_DISPATCH = 0
OP_HEARTBEAT = 1
OP_IDENTIFY = 2
OP_HELLO = 10
OP_HEARTBEAT_ACK = 11

INTERACTION_APPLICATION_COMMAND = 2
INTERACTION_MESSAGE_COMPONENT = 3
INTERACTION_MODAL_SUBMIT = 5


@dataclass(slots=True)
class BotUser:
    id: int
    username: str
    discriminator: str | None = None
    avatar: str | None = None


class Bot:
    def __init__(
        self,
        *,
        prefix: str = "!",
        status: str = "online",
        activity: str | None = None,
        intents: int | Intents | None = None,
        case_insensitive: bool = False,
        strip_after_prefix: bool = True,
    ) -> None:
        self.prefix = prefix
        self.status = status
        self.activity = activity
        self.case_insensitive = case_insensitive
        self.strip_after_prefix = strip_after_prefix
        self.intents = Intents.default() if intents is None else Intents(int(intents))
        self.http: DiscordHTTPClient | None = None
        self.ws: aiohttp.ClientWebSocketResponse | None = None
        self.session: aiohttp.ClientSession | None = None
        self.token: str | None = None
        self.application_id: int | None = None
        self.user: BotUser | None = None
        self.latency: float = 0.0
        self._last_heartbeat_at: float | None = None
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._sequence: int | None = None
        self._ready = asyncio.Event()
        self._closed = False
        self._events: dict[str, list[EventCallback]] = {}
        self._commands: dict[str, Command] = {}
        self._slash_commands: dict[str, SlashCommand] = {}
        self._modals: dict[str, Modal] = {}
        self._button_listeners: dict[str, ButtonListener] = {}
        self._cogs: dict[str, Cog] = {}
        self._before_invoke: EventCallback | None = None
        self._after_invoke: EventCallback | None = None
        self._checks: list[CheckCallback] = []

    @property
    def latency_ms(self) -> int:
        if self.latency > 0:
            return round(self.latency * 1000)
        if self.http is not None and self.http.last_latency > 0:
            return round(self.http.last_latency * 1000)
        return 0

    @property
    def username(self) -> str | None:
        return self.user.username if self.user is not None else None

    @property
    def avatar_url(self) -> str | None:
        if self.user is None:
            return None
        return self.get_user_avatar_url({"id": self.user.id, "avatar": self.user.avatar})

    @property
    def mention(self) -> str | None:
        if self.user is None:
            return None
        return f"<@{self.user.id}>"

    @property
    def commands(self) -> list[Command]:
        unique: dict[int, Command] = {}
        for command in self._commands.values():
            unique[id(command)] = command
        return list(unique.values())

    @property
    def slash_commands(self) -> list[SlashCommand]:
        unique: dict[int, SlashCommand] = {}
        for command in self._slash_commands.values():
            unique[id(command)] = command
        return list(unique.values())

    @property
    def modals(self) -> list[Modal]:
        return list(self._modals.values())

    @property
    def button_listeners(self) -> list[ButtonListener]:
        return list(self._button_listeners.values())

    def event(self, callback: EventCallback) -> EventCallback:
        self._events.setdefault(callback.__name__, []).append(callback)
        return callback

    def before_invoke(self, callback: EventCallback) -> EventCallback:
        self._before_invoke = callback
        return callback

    def after_invoke(self, callback: EventCallback) -> EventCallback:
        self._after_invoke = callback
        return callback

    def check(self, callback: CheckCallback) -> CheckCallback:
        self._checks.append(callback)
        return callback

    def add_command(self, command: Command) -> None:
        for name in command.all_names:
            self._commands[self._command_key(name)] = command

    def add_slash_command(self, command: SlashCommand) -> None:
        self._slash_commands[self._command_key(command.name)] = command

    def add_modal(self, modal: Modal) -> None:
        self._modals[modal.custom_id] = modal

    def get_modal(self, custom_id: str) -> Modal | None:
        return self._modals.get(custom_id)

    def remove_modal(self, custom_id: str) -> Modal | None:
        return self._modals.pop(custom_id, None)

    def add_button_listener(self, listener: ButtonListener) -> None:
        self._button_listeners[listener.custom_id] = listener

    def get_button_listener(self, custom_id: str) -> ButtonListener | None:
        return self._button_listeners.get(custom_id)

    def remove_button_listener(self, custom_id: str) -> ButtonListener | None:
        return self._button_listeners.pop(custom_id, None)

    def button(
        self,
        *,
        custom_id: str,
        **metadata: Any,
    ) -> Callable[[Callback], Callback]:
        def decorator(callback: Callback) -> Callback:
            self.add_button_listener(
                ButtonListener(custom_id=custom_id, callback=callback, metadata=metadata)
            )
            return callback

        return decorator

    def modal(
        self,
        *,
        custom_id: str,
        title: str,
        components: Iterable[Any],
        **metadata: Any,
    ) -> Callable[[Callback], Callback]:
        def decorator(callback: Callback) -> Callback:
            self.add_modal(
                Modal(
                    custom_id=custom_id,
                    title=title,
                    components=combine_text_inputs(components),
                    callback=callback,
                    metadata=metadata,
                )
            )
            return callback

        return decorator

    def add_cog(self, cog: Cog) -> Cog:
        loaded = self._register_cog(cog)
        load_hook = getattr(loaded, "cog_load", None)
        if load_hook is not None:
            if inspect.iscoroutinefunction(load_hook):
                raise RuntimeError("Use 'await bot.add_cog_async(...)' for async cog_load")
            load_hook()
        return loaded

    async def add_cog_async(self, cog: Cog) -> Cog:
        loaded = self._register_cog(cog)
        load_hook = getattr(loaded, "cog_load", None)
        if load_hook is not None:
            if inspect.iscoroutinefunction(load_hook):
                await load_hook()
            else:
                load_hook()
        return loaded

    def get_cog(self, name: str) -> Cog | None:
        return self._cogs.get(name)

    def remove_cog(self, name: str) -> Cog | None:
        removed = self._unregister_cog(name)
        if removed is None:
            return None
        unload_hook = getattr(removed, "cog_unload", None)
        if unload_hook is not None:
            if inspect.iscoroutinefunction(unload_hook):
                raise RuntimeError("Use 'await bot.remove_cog_async(...)' for async cog_unload")
            unload_hook()
        return removed

    async def remove_cog_async(self, name: str) -> Cog | None:
        removed = self._unregister_cog(name)
        if removed is None:
            return None
        unload_hook = getattr(removed, "cog_unload", None)
        if unload_hook is not None:
            if inspect.iscoroutinefunction(unload_hook):
                await unload_hook()
            else:
                unload_hook()
        return removed

    def _register_cog(self, cog: Cog) -> Cog:
        cog.bot = self
        if cog.cog_name in self._cogs:
            raise ValueError(f"Cog '{cog.cog_name}' is already loaded")

        command_names: list[str] = []
        slash_command_names: list[str] = []
        modal_ids: list[str] = []
        button_listener_ids: list[str] = []
        listeners: list[tuple[str, EventCallback]] = []

        for attribute_name in dir(cog):
            member = getattr(cog, attribute_name)
            target = getattr(member, "__func__", member)

            command_spec = getattr(target, "__wilnake_command__", None)
            if command_spec is not None:
                command = Command(
                    name=command_spec["name"],
                    callback=member,
                    description=command_spec["description"],
                    aliases=command_spec["aliases"],
                    usage=command_spec["usage"],
                    cooldown=command_spec["cooldown"],
                    checks=command_spec["checks"],
                    hidden=command_spec["hidden"],
                    enabled=command_spec["enabled"],
                    metadata={**command_spec["metadata"], "cog": cog.cog_name},
                )
                self.add_command(command)
                command_names.append(command.name)

            slash_spec = getattr(target, "__wilnake_slash_command__", None)
            if slash_spec is not None:
                slash_command = SlashCommand(
                    name=slash_spec["name"],
                    callback=member,
                    description=slash_spec["description"],
                    options=slash_spec["options"],
                    guild_id=slash_spec["guild_id"],
                    dm_permission=slash_spec["dm_permission"],
                    default_member_permissions=slash_spec["default_member_permissions"],
                    nsfw=slash_spec["nsfw"],
                    metadata={**slash_spec["metadata"], "cog": cog.cog_name},
                )
                self.add_slash_command(slash_command)
                slash_command_names.append(slash_command.name)

            modal_spec = getattr(target, "__wilnake_modal__", None)
            if modal_spec is not None:
                modal = Modal(
                    custom_id=modal_spec["custom_id"],
                    title=modal_spec["title"],
                    components=modal_spec["components"],
                    callback=member,
                    metadata={**modal_spec["metadata"], "cog": cog.cog_name},
                )
                self.add_modal(modal)
                modal_ids.append(modal.custom_id)

            button_spec = getattr(target, "__wilnake_button__", None)
            if button_spec is not None:
                listener = ButtonListener(
                    custom_id=button_spec["custom_id"],
                    callback=member,
                    metadata={**button_spec["metadata"], "cog": cog.cog_name},
                )
                self.add_button_listener(listener)
                button_listener_ids.append(listener.custom_id)

            listener_name = getattr(target, "__wilnake_listener__", None)
            if listener_name is not None:
                self._events.setdefault(listener_name, []).append(member)
                listeners.append((listener_name, member))

        cog.__wilnake_command_names__ = command_names
        cog.__wilnake_slash_command_names__ = slash_command_names
        cog.__wilnake_modal_ids__ = modal_ids
        cog.__wilnake_button_listener_ids__ = button_listener_ids
        cog.__wilnake_listeners__ = listeners
        self._cogs[cog.cog_name] = cog
        return cog

    def _unregister_cog(self, name: str) -> Cog | None:
        cog = self._cogs.pop(name, None)
        if cog is None:
            return None

        for command_name in getattr(cog, "__wilnake_command_names__", []):
            self.remove_command(command_name)

        for command_name in getattr(cog, "__wilnake_slash_command_names__", []):
            self._slash_commands.pop(self._command_key(command_name), None)

        for modal_id in getattr(cog, "__wilnake_modal_ids__", []):
            self._modals.pop(modal_id, None)

        for button_id in getattr(cog, "__wilnake_button_listener_ids__", []):
            self._button_listeners.pop(button_id, None)

        for event_name, listener in getattr(cog, "__wilnake_listeners__", []):
            listeners = self._events.get(event_name, [])
            if listener in listeners:
                listeners.remove(listener)
            if not listeners and event_name in self._events:
                self._events.pop(event_name, None)
        return cog

    def remove_command(self, name: str) -> Command | None:
        command = self.get_command(name)
        if command is None:
            return None
        for command_name in command.all_names:
            self._commands.pop(self._command_key(command_name), None)
        return command

    def get_command(self, name: str) -> Command | None:
        return self._commands.get(self._command_key(name))

    def has_command(self, name: str) -> bool:
        return self.get_command(name) is not None

    def command(
        self,
        *alias_args: str,
        name: str | None = None,
        description: str = "No description provided.",
        aliases: str | Iterable[str] | None = None,
        usage: str | None = None,
        cooldown: float | None = None,
        checks: Iterable[CheckCallback] | None = None,
        hidden: bool = False,
        enabled: bool = True,
        **metadata: Any,
    ) -> Callable[[Callback], Callback]:
        def decorator(callback: Callback) -> Callback:
            command_name = name or callback.__name__
            command = Command(
                name=command_name,
                callback=callback,
                description=description,
                aliases=normalize_aliases(*alias_args, aliases_value=aliases),
                usage=usage,
                cooldown=cooldown,
                checks=tuple(checks or ()),
                hidden=hidden,
                enabled=enabled,
                metadata=metadata,
            )
            self.add_command(command)
            return callback

        return decorator

    def slash_command(
        self,
        *,
        name: str,
        description: str,
        options: Iterable[SlashOption] | None = None,
        guild_id: int | None = None,
        dm_permission: bool = True,
        default_member_permissions: int | str | None = None,
        nsfw: bool = False,
        **metadata: Any,
    ) -> Callable[[Callback], Callback]:
        def decorator(callback: Callback) -> Callback:
            command = SlashCommand(
                name=name,
                callback=callback,
                description=description,
                options=tuple(options or ()),
                guild_id=guild_id,
                dm_permission=dm_permission,
                default_member_permissions=(
                    str(default_member_permissions)
                    if default_member_permissions is not None
                    else None
                ),
                nsfw=nsfw,
                metadata=metadata,
            )
            self.add_slash_command(command)
            return callback

        return decorator

    async def dispatch(self, event_name: str, *args: Any) -> None:
        callbacks = self._events.get(event_name, [])
        for callback in list(callbacks):
            await self._invoke(callback, *args)

    async def wait_until_ready(self) -> None:
        await self._ready.wait()

    async def start(self, token: str) -> None:
        self._closed = False
        self._ready.clear()
        self.token = token
        self.http = DiscordHTTPClient(token)
        await self.http.open()
        try:
            gateway = await self.http.get_gateway()
            app = await self.http.get_current_application()
            self.application_id = int(app["id"])
            await self._connect_gateway(gateway["url"])
        finally:
            await self.close()

    def run(self, token: str) -> None:
        try:
            asyncio.run(self.start(token))
        except KeyboardInterrupt:
            pass

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True

        if self._heartbeat_task is not None:
            self._heartbeat_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._heartbeat_task
            self._heartbeat_task = None

        if self.ws is not None:
            await self.ws.close()
            self.ws = None

        if self.http is not None:
            await self.http.close()
            self.http = None

        if self.session is not None:
            await self.session.close()
            self.session = None

    async def fetch_user(self, user_id: int | str) -> dict[str, Any]:
        return await self._require_http().get_user(int(user_id))

    async def fetch_member(self, guild_id: int, user_id: int | str) -> dict[str, Any]:
        return await self._require_http().get_member(guild_id, int(user_id))

    def get_user_avatar_url(self, user: dict[str, Any]) -> str:
        avatar_hash = user.get("avatar")
        if avatar_hash:
            ext = "gif" if avatar_hash.startswith("a_") else "png"
            return f"https://cdn.discordapp.com/avatars/{user['id']}/{avatar_hash}.{ext}?size=4096"
        return self.get_default_avatar_url(int(user["id"]))

    def get_default_avatar_url(self, user_id: int) -> str:
        return f"https://cdn.discordapp.com/embed/avatars/{(user_id >> 22) % 6}.png"

    async def sync_commands(self) -> None:
        await self._sync_slash_commands()

    def is_member_timed_out(self, member: dict[str, Any]) -> bool:
        until = member.get("communication_disabled_until")
        if not until:
            return False
        try:
            timeout_until = datetime.fromisoformat(until.replace("Z", "+00:00"))
        except ValueError:
            return False
        return timeout_until > datetime.now(timezone.utc)

    async def kick(self, guild_id: int, user_id: int, *, reason: str | None = None) -> None:
        await self._require_http().kick_member(guild_id, user_id, reason=reason)

    async def ban(
        self,
        guild_id: int,
        user_id: int,
        *,
        reason: str | None = None,
        delete_message_seconds: int = 0,
    ) -> None:
        await self._require_http().ban_member(
            guild_id,
            user_id,
            reason=reason,
            delete_message_seconds=delete_message_seconds,
        )

    async def unban(self, guild_id: int, user_id: int, *, reason: str | None = None) -> None:
        await self._require_http().unban_member(guild_id, user_id, reason=reason)

    async def mute(
        self,
        guild_id: int,
        user_id: int,
        *,
        minutes: int,
        reason: str | None = None,
    ) -> None:
        until = datetime.now(timezone.utc) + timedelta(minutes=max(1, minutes))
        await self._require_http().edit_member(
            guild_id,
            user_id,
            {"communication_disabled_until": until.isoformat().replace("+00:00", "Z")},
            reason=reason,
        )

    async def unmute(self, guild_id: int, user_id: int, *, reason: str | None = None) -> None:
        member = await self.fetch_member(guild_id, user_id)
        if not self.is_member_timed_out(member):
            raise MemberNotMuted(f"User {user_id} does not have an active timeout")
        await self._require_http().edit_member(
            guild_id,
            user_id,
            {"communication_disabled_until": None},
            reason=reason,
        )

    async def set_nickname(
        self,
        guild_id: int,
        user_id: int,
        nickname: str | None,
        *,
        reason: str | None = None,
    ) -> None:
        await self._require_http().edit_member(
            guild_id,
            user_id,
            {"nick": nickname},
            reason=reason,
        )

    async def set_slowmode(self, channel_id: int, seconds: int) -> dict[str, Any]:
        return await self._require_http().modify_channel(
            channel_id,
            {"rate_limit_per_user": max(0, min(seconds, 21600))},
        )

    async def purge_messages(
        self,
        channel_id: int,
        *,
        limit: int = 50,
        before: int | None = None,
    ) -> int:
        messages = await self._require_http().get_channel_messages(
            channel_id,
            limit=max(2, min(limit, 100)),
            before=before,
        )
        deletable_ids = [int(message["id"]) for message in messages if not message.get("pinned")]
        if len(deletable_ids) < 2:
            return 0
        await self._require_http().bulk_delete_messages(channel_id, deletable_ids[:100])
        return min(len(deletable_ids), 100)

    async def process_commands(self, message_or_ctx: dict[str, Any] | MessageContext) -> None:
        ctx = message_or_ctx if isinstance(message_or_ctx, MessageContext) else MessageContext(self, message_or_ctx)
        if ctx.author.get("bot"):
            return

        content = ctx.content
        if not content.startswith(self.prefix):
            return

        without_prefix = content[len(self.prefix) :]
        if self.strip_after_prefix:
            without_prefix = without_prefix.strip()
        if not without_prefix:
            return

        try:
            parts = shlex.split(without_prefix)
        except ValueError:
            parts = without_prefix.split()
        if not parts:
            return

        command_name = parts[0]
        args = parts[1:]
        command = self.get_command(command_name)
        if command is None:
            return

        ctx.command = command
        ctx.invoked_with = command_name
        ctx.args = args
        ctx.command_failed = False

        try:
            await self._ensure_command_can_run(command, ctx)
            if self._before_invoke is not None:
                await self._invoke(self._before_invoke, ctx)
            await self.dispatch("on_command", ctx)
            await self._invoke(command.callback, ctx, *args)
            if command.cooldown is not None:
                command.update_cooldown(ctx.author_id)
            if self._after_invoke is not None:
                await self._invoke(self._after_invoke, ctx)
            await self.dispatch("on_command_completion", ctx)
        except Exception as error:
            ctx.command_failed = True
            await self.dispatch("on_command_error", ctx, error)

    async def _connect_gateway(self, url: str) -> None:
        self.session = aiohttp.ClientSession()
        self.ws = await self.session.ws_connect(f"{url}?v=10&encoding=json")

        try:
            async for message in self.ws:
                if message.type != aiohttp.WSMsgType.TEXT:
                    continue
                payload = message.json()
                await self._handle_gateway_payload(payload)
        except asyncio.CancelledError:
            pass

    async def _handle_gateway_payload(self, payload: dict[str, Any]) -> None:
        op = payload["op"]
        data = payload.get("d")
        self._sequence = payload.get("s", self._sequence)

        if op == OP_HELLO:
            interval = data["heartbeat_interval"] / 1000
            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop(interval))
            await self._identify()
            return

        if op == OP_HEARTBEAT_ACK:
            if self._last_heartbeat_at is not None:
                self.latency = time.perf_counter() - self._last_heartbeat_at
            return

        if op != OP_DISPATCH:
            return

        event_name = payload["t"]
        if event_name == "READY":
            user = data["user"]
            self.user = BotUser(
                id=int(user["id"]),
                username=user["username"],
                discriminator=user.get("discriminator"),
                avatar=user.get("avatar"),
            )
            await self._sync_slash_commands()
            self._ready.set()
            await self.dispatch("on_ready")
            return

        if event_name == "MESSAGE_CREATE":
            ctx = MessageContext(self, data)
            await self.dispatch("on_message", ctx)
            await self.process_commands(ctx)
            return

        if event_name == "INTERACTION_CREATE":
            await self._handle_interaction_create(data)
            return

        await self.dispatch(f"on_{event_name.lower()}", data)

    async def _identify(self) -> None:
        await self._send_gateway(
            {
                "op": OP_IDENTIFY,
                "d": {
                    "token": self.token,
                    "intents": int(self.intents),
                    "properties": {
                        "os": "windows",
                        "browser": "wilnake",
                        "device": "wilnake",
                    },
                    "presence": {
                        "status": self.status,
                        "since": None,
                        "afk": False,
                        "activities": self._build_activities(),
                    },
                },
            }
        )

    def _build_activities(self) -> list[dict[str, Any]]:
        if not self.activity:
            return []
        return [{"name": self.activity, "type": 0}]

    async def _heartbeat_loop(self, interval: float) -> None:
        while True:
            self._last_heartbeat_at = time.perf_counter()
            await self._send_gateway({"op": OP_HEARTBEAT, "d": self._sequence})
            await asyncio.sleep(interval)

    async def _send_gateway(self, payload: dict[str, Any]) -> None:
        if self.ws is None or self.ws.closed:
            return
        await self.ws.send_json(payload)

    async def _handle_interaction_create(self, interaction: dict[str, Any]) -> None:
        interaction_type = interaction.get("type")

        if interaction_type == INTERACTION_APPLICATION_COMMAND:
            ctx = SlashContext(self, interaction)
            await self.dispatch("on_interaction", ctx)
            command_name = ctx.command_name
            if not command_name:
                return

            command = self._slash_commands.get(self._command_key(command_name))
            if command is None:
                return

            ctx.command = command
            try:
                await self.dispatch("on_slash_command", ctx)
                await self._invoke(command.callback, ctx)
                await self.dispatch("on_slash_command_completion", ctx)
            except Exception as error:
                await self.dispatch("on_slash_command_error", ctx, error)
                if not self._events.get("on_slash_command_error") and not ctx.responded:
                    await ctx.send_error(str(error))
            return

        if interaction_type == INTERACTION_MODAL_SUBMIT:
            ctx = ModalContext(self, interaction)
            await self.dispatch("on_interaction", ctx)
            await self.dispatch("on_modal_submit", ctx)
            modal = self.get_modal(ctx.custom_id or "")
            if modal is None or modal.callback is None:
                return

            ctx.modal = modal
            try:
                await self._invoke(modal.callback, ctx)
                await self.dispatch("on_modal_completion", ctx)
            except Exception as error:
                await self.dispatch("on_modal_error", ctx, error)
                if not self._events.get("on_modal_error") and not ctx.responded:
                    await ctx.send_error(str(error))
            return

        if interaction_type == INTERACTION_MESSAGE_COMPONENT:
            ctx = ComponentContext(self, interaction)
            await self.dispatch("on_interaction", ctx)
            await self.dispatch("on_component", ctx)
            listener = self.get_button_listener(ctx.custom_id or "")
            if listener is None:
                return

            ctx.listener = listener
            try:
                await self._invoke(listener.callback, ctx)
                await self.dispatch("on_component_completion", ctx)
            except Exception as error:
                await self.dispatch("on_component_error", ctx, error)
                if not self._events.get("on_component_error") and not ctx.responded:
                    await ctx.send_error(str(error))
            return

    async def _invoke(self, callback: EventCallback | Callback | CheckCallback, *args: Any) -> Any:
        if inspect.iscoroutinefunction(callback):
            return await callback(*args)
        result = callback(*args)
        if inspect.isawaitable(result):
            return await result
        return result

    async def _ensure_command_can_run(self, command: Command, ctx: MessageContext) -> None:
        if not command.enabled:
            raise DisabledCommand(f"Command '{command.name}' is disabled")

        for check in self._checks:
            if not await self._invoke_check(check, ctx):
                raise CheckFailure(f"Global check failed for command '{command.name}'")

        for check in command.checks:
            if not await self._invoke_check(check, ctx):
                raise CheckFailure(f"Check failed for command '{command.name}'")

        retry_after = command.get_retry_after(ctx.author_id)
        if retry_after > 0:
            raise CommandOnCooldown(retry_after)

    async def _invoke_check(self, check: CheckCallback, ctx: MessageContext) -> bool:
        result = await self._invoke(check, ctx)
        return bool(result)

    async def _sync_slash_commands(self) -> None:
        if not self._slash_commands or self.http is None or self.application_id is None:
            return

        global_commands = []
        guild_commands: dict[int, list[dict[str, Any]]] = {}

        unique: dict[int, SlashCommand] = {}
        for command in self._slash_commands.values():
            unique[id(command)] = command

        for command in unique.values():
            payload = command.to_dict()
            if command.guild_id is None:
                global_commands.append(payload)
            else:
                guild_commands.setdefault(command.guild_id, []).append(payload)

        if global_commands:
            await self.http.bulk_overwrite_global_commands(self.application_id, global_commands)

        for guild_id, commands in guild_commands.items():
            await self.http.bulk_overwrite_guild_commands(self.application_id, guild_id, commands)

    def _command_key(self, name: str) -> str:
        key = str(name)
        return key.casefold() if self.case_insensitive else key

    def _require_http(self) -> DiscordHTTPClient:
        if self.http is None:
            raise RuntimeError("HTTP client is not ready")
        return self.http
