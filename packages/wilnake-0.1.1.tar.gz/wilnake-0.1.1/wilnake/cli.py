import argparse
import os
import sys
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="wilnake",
        description="Wilnake CLI - утилита для создания Discord ботов",
        add_help=False
    )
    
    parser.add_argument("--help", action="store_true", help="Показать справку")
    subparsers = parser.add_subparsers(dest="command", help="Доступные команды")
    
    # version command
    subparsers.add_parser("version", help="Показать версию")
    
    # init command
    init_parser = subparsers.add_parser("init", help="Создать новый проект бота")
    init_parser.add_argument("--name", required=True, help="Имя бота")
    init_parser.add_argument("--prefix", required=True, help="Префикс команд")
    
    args = parser.parse_args()
    
    if args.help or len(sys.argv) == 1:
        print_help()
        return
    
    if args.command == "version":
        print_version()
    elif args.command == "init":
        init_project(args.name, args.prefix)
    else:
        print_help()


def print_help() -> None:
    print("""
Wilnake CLI - утилита для создания Discord ботов

Использование:
  wilnake --help              Показать эту справку
  wilnake version             Показать версию
  wilnake init --name NAME --prefix PREFIX   Создать новый проект

Пример:
  wilnake init --name my_bot --prefix .
""")


def print_version() -> None:
    try:
        from wilnake import __version__
        print(__version__)
    except ImportError:
        print("0.1.1")


def init_project(name: str, prefix: str) -> None:
    project_dir = Path.cwd() / name
    if project_dir.exists():
        print(f"Ошибка: Папка '{name}' уже существует")
        sys.exit(1)
    
    project_dir.mkdir()
    
    bot_file = project_dir / "bot.py"
    bot_code = f'''from wilnake import Bot, Intents

bot = Bot(
    prefix="{prefix}",
    status="online",
    activity="wilnake bot",
    intents=Intents.default()
)

@bot.event
async def on_ready():
    print(f"⧉ Бот {{bot.username}} запущен!")

@bot.slash_command(name="ping", description="Проверка связи")
async def ping(ctx):
    await ctx.respond("Pong!")

if __name__ == "__main__":
    bot.run("YOUR_TOKEN_HERE")
'''
    
    bot_file.write_text(bot_code)
    
    env_file = project_dir / ".env"
    env_file.write_text("DISCORD_TOKEN=your_token_here\n")
    
    readme = project_dir / "README.md"
    readme.write_text(f"# {name}\n\nDiscord бот созданный с помощью Wilnake\n\n## Установка\n\n```bash\npip install wilnake\n```\n\n## Запуск\n\n```bash\npython bot.py\n```\n")
    
    print(f"✓ Проект '{name}' создан в {project_dir}")
    print(f"\nДалее:")
    print(f"  1. Перейдите в папку: cd {name}")
    print(f"  2. Отредактируйте {name}/.env и добавьте токен бота")
    print(f"  3. Запустите бота: python bot.py")


if __name__ == "__main__":
    main()