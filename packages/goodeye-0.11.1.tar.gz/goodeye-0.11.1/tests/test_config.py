"""Tests for goodeye_cli.config."""

from __future__ import annotations

import json
import os
import stat
import tomllib
from pathlib import Path

import pytest

from goodeye_cli.config import (
    DEFAULT_REQUEST_TIMEOUT_SECONDS,
    DEFAULT_SERVER,
    ConfigPaths,
    delete_credentials,
    get_api_key,
    get_config_paths,
    get_request_timeout_seconds,
    get_server,
    load_client_config,
    load_credentials,
    save_client_config,
    save_credentials,
)


def test_get_config_paths_uses_xdg(tmp_path: Path) -> None:
    paths = get_config_paths({"XDG_CONFIG_HOME": str(tmp_path)})
    assert paths.config_dir == tmp_path / "goodeye"
    assert paths.credentials_file == tmp_path / "goodeye" / "credentials.json"
    assert paths.config_file == tmp_path / "goodeye" / "config.json"
    assert paths.update_check_file == tmp_path / "goodeye" / "update-check.json"


def test_get_config_paths_defaults_to_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("XDG_CONFIG_HOME", raising=False)
    monkeypatch.setenv("HOME", str(tmp_path))
    paths = get_config_paths({})
    assert paths.config_dir == tmp_path / ".config" / "goodeye"


def test_save_credentials_writes_0600(tmp_config_paths: ConfigPaths) -> None:
    path = save_credentials(
        {"api_key": "good_live_EXAMPLE", "server": "https://x"}, tmp_config_paths
    )
    assert path.exists()
    mode = stat.S_IMODE(os.stat(path).st_mode)
    assert mode == 0o600
    with path.open() as fh:
        data = json.load(fh)
    assert data == {"api_key": "good_live_EXAMPLE", "server": "https://x"}


def test_load_credentials_missing_returns_none(tmp_config_paths: ConfigPaths) -> None:
    assert load_credentials(tmp_config_paths) is None


def test_load_credentials_roundtrip(tmp_config_paths: ConfigPaths) -> None:
    save_credentials({"api_key": "k", "server": "s"}, tmp_config_paths)
    assert load_credentials(tmp_config_paths) == {"api_key": "k", "server": "s"}


def test_delete_credentials(tmp_config_paths: ConfigPaths) -> None:
    assert delete_credentials(tmp_config_paths) is False
    save_credentials({"api_key": "k"}, tmp_config_paths)
    assert delete_credentials(tmp_config_paths) is True
    assert not tmp_config_paths.credentials_file.exists()


def test_client_config_roundtrip(tmp_config_paths: ConfigPaths) -> None:
    payload = {
        "workos_client_id": "client_X",
        "workos_device_authorization_uri": "https://api.workos.com/user_management/authorize/device",
        "workos_token_uri": "https://api.workos.com/user_management/authenticate",
    }
    save_client_config(payload, tmp_config_paths)
    assert load_client_config(tmp_config_paths) == payload


def test_get_server_env_beats_credentials(
    tmp_config_paths: ConfigPaths,
) -> None:
    save_credentials({"api_key": "k", "server": "https://fromfile"}, tmp_config_paths)
    env = {"GOODEYE_SERVER": "https://fromenv"}
    assert get_server(tmp_config_paths, env) == "https://fromenv"
    assert get_server(tmp_config_paths, {}) == "https://fromfile"


def test_get_server_falls_back_to_default(tmp_config_paths: ConfigPaths) -> None:
    assert get_server(tmp_config_paths, {}) == DEFAULT_SERVER


def test_get_api_key_precedence(tmp_config_paths: ConfigPaths) -> None:
    save_credentials({"api_key": "from_file"}, tmp_config_paths)
    assert get_api_key(tmp_config_paths, {"GOODEYE_API_KEY": "from_env"}) == "from_env"
    assert get_api_key(tmp_config_paths, {}) == "from_file"


def test_get_api_key_none_when_no_source(tmp_config_paths: ConfigPaths) -> None:
    assert get_api_key(tmp_config_paths, {}) is None


def test_get_server_strips_trailing_slash(tmp_config_paths: ConfigPaths) -> None:
    assert get_server(tmp_config_paths, {"GOODEYE_SERVER": "https://x/"}) == "https://x"


def test_get_request_timeout_seconds_uses_default() -> None:
    assert get_request_timeout_seconds({}) == DEFAULT_REQUEST_TIMEOUT_SECONDS
    assert get_request_timeout_seconds({}, default=300.0) == 300.0


def test_get_request_timeout_seconds_env_overrides_default() -> None:
    env = {"GOODEYE_TIMEOUT_SECONDS": "45.5"}
    assert get_request_timeout_seconds(env) == 45.5
    assert get_request_timeout_seconds(env, default=300.0) == 45.5


def test_load_credentials_migrates_legacy_server_pin(
    tmp_config_paths: ConfigPaths, capsys: pytest.CaptureFixture[str]
) -> None:
    """Old default ``api.goodeyelabs.com`` is rewritten to the canonical host."""
    save_credentials(
        {"api_key": "good_live_EXAMPLE", "server": "https://api.goodeyelabs.com"},
        tmp_config_paths,
    )
    creds = load_credentials(tmp_config_paths)
    assert creds is not None
    assert creds["server"] == DEFAULT_SERVER
    assert creds["api_key"] == "good_live_EXAMPLE"
    # Notice goes to stderr; api_key never appears in the announcement.
    captured = capsys.readouterr()
    assert "api.goodeyelabs.com" in captured.err
    assert DEFAULT_SERVER in captured.err
    assert "good_live_EXAMPLE" not in captured.err
    # The on-disk file was rewritten, not just the in-memory dict.
    with tmp_config_paths.credentials_file.open() as fh:
        on_disk = json.load(fh)
    assert on_disk["server"] == DEFAULT_SERVER
    # And it kept the 0600 mode that save_credentials sets.
    mode = stat.S_IMODE(os.stat(tmp_config_paths.credentials_file).st_mode)
    assert mode == 0o600


def test_load_credentials_migration_handles_trailing_slash_and_case(
    tmp_config_paths: ConfigPaths, capsys: pytest.CaptureFixture[str]
) -> None:
    save_credentials(
        {"api_key": "k", "server": "HTTPS://API.GOODEYELABS.COM/"},
        tmp_config_paths,
    )
    creds = load_credentials(tmp_config_paths)
    assert creds is not None
    assert creds["server"] == DEFAULT_SERVER
    assert "migrated CLI server pin" in capsys.readouterr().err


def test_load_credentials_migration_is_idempotent(
    tmp_config_paths: ConfigPaths, capsys: pytest.CaptureFixture[str]
) -> None:
    save_credentials({"api_key": "k", "server": DEFAULT_SERVER}, tmp_config_paths)
    load_credentials(tmp_config_paths)
    assert capsys.readouterr().err == ""


def test_load_credentials_leaves_custom_servers_alone(
    tmp_config_paths: ConfigPaths, capsys: pytest.CaptureFixture[str]
) -> None:
    """Anything other than the historical default is treated as a deliberate override."""
    save_credentials({"api_key": "k", "server": "http://localhost:8000"}, tmp_config_paths)
    creds = load_credentials(tmp_config_paths)
    assert creds is not None
    assert creds["server"] == "http://localhost:8000"
    assert capsys.readouterr().err == ""


def test_version_fallback_reads_pyproject_version() -> None:
    """``importlib.metadata`` can be absent in some dev setups; fallback must match pyproject."""
    from goodeye_cli import _version_from_source_tree

    root = Path(__file__).resolve().parents[1]
    with (root / "pyproject.toml").open("rb") as fh:
        expected = tomllib.load(fh)["project"]["version"]
    assert isinstance(expected, str)
    assert _version_from_source_tree() == expected
