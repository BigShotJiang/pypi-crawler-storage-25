"""Tests for the `goodeye teams ...` subcommand group.

Covers happy-path create/list/delete and two error surfaces
(``handle_not_claimed`` on create, missing credentials) to confirm the
CLI forwards the server's structured errors.
"""

from __future__ import annotations

import json

import httpx
import respx
from typer.testing import CliRunner

from goodeye_cli.app import app
from goodeye_cli.config import ConfigPaths

SERVER = "https://example.test"
_TEAM_ID = "11111111-1111-1111-1111-111111111111"
_USER_ID = "22222222-2222-2222-2222-222222222222"


def _env(monkeypatch, tmp_config_paths: ConfigPaths, *, api_key: str | None) -> None:
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_config_paths.config_dir.parent))
    monkeypatch.setenv("GOODEYE_SERVER", SERVER)
    if api_key is not None:
        monkeypatch.setenv("GOODEYE_API_KEY", api_key)
    else:
        monkeypatch.delenv("GOODEYE_API_KEY", raising=False)


@respx.mock
def test_teams_create_success(tmp_config_paths: ConfigPaths, monkeypatch) -> None:
    _env(monkeypatch, tmp_config_paths, api_key="good_live_EXAMPLE")
    respx.post(f"{SERVER}/v1/teams").mock(
        return_value=httpx.Response(201, json={"team_id": _TEAM_ID, "handle": "acme"})
    )
    runner = CliRunner()
    result = runner.invoke(app, ["teams", "create", "acme"])
    assert result.exit_code == 0, result.output
    assert "acme" in result.output


@respx.mock
def test_teams_create_handle_not_claimed(tmp_config_paths: ConfigPaths, monkeypatch) -> None:
    _env(monkeypatch, tmp_config_paths, api_key="good_live_EXAMPLE")
    respx.post(f"{SERVER}/v1/teams").mock(
        return_value=httpx.Response(
            409,
            json={
                "error": "handle_not_claimed",
                "message": "claim a handle before performing this action",
            },
        )
    )
    runner = CliRunner()
    result = runner.invoke(app, ["teams", "create", "acme"])
    assert result.exit_code != 0


@respx.mock
def test_teams_list_prints_table(tmp_config_paths: ConfigPaths, monkeypatch) -> None:
    _env(monkeypatch, tmp_config_paths, api_key="good_live_EXAMPLE")
    respx.get(f"{SERVER}/v1/teams").mock(
        return_value=httpx.Response(
            200,
            json={
                "items": [
                    {
                        "team_id": _TEAM_ID,
                        "handle": "acme",
                        "owner_user_id": _USER_ID,
                        "role": "owner",
                    }
                ]
            },
        )
    )
    runner = CliRunner()
    result = runner.invoke(app, ["teams", "list", "--table"])
    assert result.exit_code == 0, result.output
    assert "acme" in result.output


@respx.mock
def test_teams_list_defaults_to_compact_json_envelope(
    tmp_config_paths: ConfigPaths, monkeypatch
) -> None:
    _env(monkeypatch, tmp_config_paths, api_key="good_live_EXAMPLE")
    respx.get(f"{SERVER}/v1/teams").mock(
        return_value=httpx.Response(
            200,
            json={
                "items": [
                    {
                        "team_id": _TEAM_ID,
                        "handle": "acme",
                        "owner_user_id": _USER_ID,
                        "role": "owner",
                    }
                ]
            },
        )
    )
    runner = CliRunner()
    result = runner.invoke(app, ["teams", "list"])
    assert result.exit_code == 0, result.output
    assert result.output == (
        f'{{"items":[{{"team_id":"{_TEAM_ID}","handle":"acme",'
        f'"owner_user_id":"{_USER_ID}","role":"owner","created_at":null,'
        '"updated_at":null}]}\n'
    )


def test_teams_list_does_not_expose_pagination_flags(
    tmp_config_paths: ConfigPaths, monkeypatch
) -> None:
    _env(monkeypatch, tmp_config_paths, api_key="good_live_EXAMPLE")
    runner = CliRunner()
    result = runner.invoke(app, ["teams", "list", "--limit", "25"])
    assert result.exit_code != 0
    assert "No such option" in result.output


@respx.mock
def test_teams_delete_success(tmp_config_paths: ConfigPaths, monkeypatch) -> None:
    _env(monkeypatch, tmp_config_paths, api_key="good_live_EXAMPLE")
    respx.delete(f"{SERVER}/v1/teams/{_TEAM_ID}").mock(
        return_value=httpx.Response(200, json={"team_id": _TEAM_ID, "deleted": True})
    )
    runner = CliRunner()
    result = runner.invoke(app, ["teams", "delete", _TEAM_ID, "--yes"])
    assert result.exit_code == 0, result.output


def test_teams_create_without_credentials_errors(
    tmp_config_paths: ConfigPaths, monkeypatch
) -> None:
    _env(monkeypatch, tmp_config_paths, api_key=None)
    runner = CliRunner()
    result = runner.invoke(app, ["teams", "create", "acme"])
    assert result.exit_code != 0


@respx.mock
def test_teams_members_renders_table(tmp_config_paths: ConfigPaths, monkeypatch) -> None:
    """Server returns `{items: [...]}`; the CLI must unwrap before validating rows."""
    _env(monkeypatch, tmp_config_paths, api_key="good_live_EXAMPLE")
    respx.get(f"{SERVER}/v1/teams/{_TEAM_ID}/members").mock(
        return_value=httpx.Response(
            200,
            json={
                "items": [
                    {
                        "user_id": _USER_ID,
                        "email": "owner@example.com",
                        "handle": "ownerhandle",
                        "role": "owner",
                    },
                    {
                        "user_id": "33333333-3333-3333-3333-333333333333",
                        "email": "member@example.com",
                        "handle": None,
                        "role": "member",
                    },
                ]
            },
        )
    )
    runner = CliRunner()
    result = runner.invoke(app, ["teams", "members", _TEAM_ID, "--table"])
    assert result.exit_code == 0, result.output
    assert "ownerhandle" in result.output
    assert "owner" in result.output
    assert "member" in result.output


@respx.mock
def test_teams_members_defaults_to_compact_json_envelope(
    tmp_config_paths: ConfigPaths, monkeypatch
) -> None:
    _env(monkeypatch, tmp_config_paths, api_key="good_live_EXAMPLE")
    respx.get(f"{SERVER}/v1/teams/{_TEAM_ID}/members").mock(
        return_value=httpx.Response(
            200,
            json={
                "items": [
                    {
                        "user_id": _USER_ID,
                        "email": "owner@example.com",
                        "handle": "ownerhandle",
                        "role": "owner",
                    }
                ]
            },
        )
    )
    runner = CliRunner()
    result = runner.invoke(app, ["teams", "members", _TEAM_ID])
    assert result.exit_code == 0, result.output
    assert json.loads(result.output) == {
        "items": [
            {
                "user_id": _USER_ID,
                "email": "owner@example.com",
                "handle": "ownerhandle",
                "role": "owner",
            }
        ]
    }


@respx.mock
def test_teams_commands_pass_handles_through(tmp_config_paths: ConfigPaths, monkeypatch) -> None:
    _env(monkeypatch, tmp_config_paths, api_key="good_live_EXAMPLE")
    respx.get(f"{SERVER}/v1/teams/analytics/members").mock(
        return_value=httpx.Response(
            200,
            json={
                "items": [
                    {
                        "user_id": _USER_ID,
                        "email": "owner@example.com",
                        "handle": "ownerhandle",
                        "role": "owner",
                    }
                ]
            },
        )
    )
    add_route = respx.post(f"{SERVER}/v1/teams/analytics/members").mock(
        return_value=httpx.Response(201, json={"team_id": _TEAM_ID, "user_id": _USER_ID})
    )
    remove_route = respx.delete(f"{SERVER}/v1/teams/analytics/members/memberhandle").mock(
        return_value=httpx.Response(
            200,
            json={"team_id": _TEAM_ID, "user_id": _USER_ID, "removed": True},
        )
    )
    transfer_route = respx.post(f"{SERVER}/v1/teams/analytics/transfer-ownership").mock(
        return_value=httpx.Response(200, json={"team_id": _TEAM_ID, "owner_user_id": _USER_ID})
    )

    runner = CliRunner()
    members = runner.invoke(app, ["teams", "members", "analytics"])
    add = runner.invoke(app, ["teams", "add-member", "analytics", "memberhandle"])
    remove = runner.invoke(app, ["teams", "remove-member", "analytics", "memberhandle"])
    transfer = runner.invoke(app, ["teams", "transfer-ownership", "analytics", "memberhandle"])

    assert members.exit_code == 0, members.output
    assert add.exit_code == 0, add.output
    assert remove.exit_code == 0, remove.output
    assert transfer.exit_code == 0, transfer.output

    import json as _json

    add_body = _json.loads(add_route.calls.last.request.content.decode())
    assert add_body == {"user_identifier": "memberhandle"}
    transfer_body = _json.loads(transfer_route.calls.last.request.content.decode())
    assert transfer_body == {"new_owner_user_identifier": "memberhandle"}
    assert remove_route.called
