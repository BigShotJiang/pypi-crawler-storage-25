import logging
import psycopg2
from airflow.models import Variable, DagModel
from airflow.plugins_manager import AirflowPlugin
from airflow.settings import Session

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Shared helpers (used by both Flask and FastAPI)
# ---------------------------------------------------------------------------

def _has_db_config():
    try:
        Variable.get("EXTRACTION_CONFIG", deserialize_json=True)
        return True
    except Exception:
        return False


def _get_db_conn():
    config = Variable.get("EXTRACTION_CONFIG", deserialize_json=True)
    return psycopg2.connect(
        host=config["DATABASE_HOST"],
        user=config["DATABASE_USER"],
        dbname=config["DATABASE_NAME"],
        password=config["DATABASE_PASSWORD"],
        port=config["DATABASE_PORT"],
    )


def _get_airflow_dags():
    session = Session()
    try:
        dags = session.query(DagModel).filter(
            DagModel.is_active == True,
            DagModel.schedule_interval.isnot(None),
        ).all()
        result = []
        for dag in dags:
            cron = None
            schedule = dag.schedule_interval
            if isinstance(schedule, str):
                parts = schedule.strip().split()
                if len(parts) == 5:
                    cron = schedule.strip()
            elif isinstance(schedule, dict):
                cron = schedule.get("value") or schedule.get("__var")
                if cron and len(cron.strip().split()) != 5:
                    cron = None
            if cron:
                result.append({
                    "name": dag.dag_id,
                    "cron": cron,
                    "owner": dag.owners or "",
                    "cmd": "",
                    "type": "DAG",
                    "batch": "",
                })
        return result
    finally:
        session.close()


def _fetch_slots():
    if _has_db_config():
        conn = _get_db_conn()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT "DAG_NAME", "SCHEDULE_TIME", "OWNER", "COMMAND_NAME", "TYPE", "BATCHES"
            FROM "TEST"."DAG_SCHEDULE_CONFIG"
            WHERE "IS_ACTIVE" = 'TRUE'
        """)
        rows = cursor.fetchall()
        cursor.close()
        conn.close()
        return [
            {"name": r[0], "cron": r[1], "owner": r[2],
             "cmd": r[3], "type": r[4], "batch": r[5]}
            for r in rows if r[1]
        ]
    return _get_airflow_dags()


def _fetch_batches():
    if not _has_db_config():
        return [], "batch_1"
    conn = _get_db_conn()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT "BATCHES", COUNT(*) as cnt
        FROM "TEST"."DAG_SCHEDULE_CONFIG"
        WHERE "IS_ACTIVE" = 'TRUE'
          AND "BATCHES" IS NOT NULL
          AND "BATCHES" != ''
        GROUP BY "BATCHES"
        ORDER BY "BATCHES"
    """)
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    MAX_PER_BATCH = 5
    batches = []
    max_num = 0
    for batch_name, count in rows:
        try:
            num = int(batch_name.rsplit('_', 1)[-1])
            if num > max_num:
                max_num = num
        except (ValueError, IndexError):
            pass
        if count < MAX_PER_BATCH:
            batches.append({"name": batch_name, "count": count,
                            "available": MAX_PER_BATCH - count})
    return batches, f"batch_spider_{max_num + 1}"


def _do_book(dag_name, owner, dag_type, cron, batch, cmd, selenium):
    MAX_DAGS_PER_SLOT = 5
    conn = _get_db_conn()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT COUNT(*) FROM "TEST"."DAG_SCHEDULE_CONFIG"
        WHERE "SCHEDULE_TIME" = %s AND "IS_ACTIVE" = 'TRUE'
    """, (cron,))
    count = cursor.fetchone()[0]
    if count >= MAX_DAGS_PER_SLOT:
        cursor.close()
        conn.close()
        raise ValueError(f"Slot full — maximum {MAX_DAGS_PER_SLOT} DAGs per time slot")
    cursor.execute("""
        INSERT INTO "TEST"."DAG_SCHEDULE_CONFIG"
            ("DAG_NAME", "SELENIUM", "SCHEDULE_TIME", "BATCHES",
             "OWNER", "COMMAND_NAME", "TYPE", "IS_ACTIVE")
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """, (dag_name, 'TRUE' if selenium else '', cron, batch, owner, cmd, dag_type, 'TRUE'))
    conn.commit()
    cursor.close()
    conn.close()


def _do_cancel(dag_name):
    conn = _get_db_conn()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE "TEST"."DAG_SCHEDULE_CONFIG"
        SET "IS_ACTIVE" = 'FALSE'
        WHERE "DAG_NAME" = %s
    """, (dag_name,))
    conn.commit()
    cursor.close()
    conn.close()


# ---------------------------------------------------------------------------
# Detect Airflow major version
# ---------------------------------------------------------------------------
import airflow
_AIRFLOW_MAJOR = int(airflow.__version__.split(".")[0])


# ===========================================================================
# AIRFLOW 3.x  — FastAPI
# ===========================================================================
if _AIRFLOW_MAJOR >= 3:
    from pathlib import Path
    from fastapi import FastAPI, Request
    from fastapi.responses import HTMLResponse, JSONResponse
    from pydantic import BaseModel
    from typing import Optional
    import json as _json

    _TEMPLATE_PATH = Path(__file__).parent / "templates" / "dag_slot_booking" / "index.html"

    dag_slot_app = FastAPI(docs_url=None, redoc_url=None)

    @dag_slot_app.get("/", response_class=HTMLResponse)
    async def index(request: Request):
        # Read the static HTML file
        html = _TEMPLATE_PATH.read_text(encoding="utf-8")
        # Build config — injected as a plain <script> block so no Jinja needed
        user_name = ""
        try:
            from airflow.www.app import cached_app
            app = cached_app()
            with app.test_request_context():
                from flask_login import current_user
                user_name = getattr(current_user, "first_name", "") or \
                            getattr(current_user, "username", "") or ""
        except Exception:
            pass
        config = _json.dumps({"db_mode": _has_db_config(), "user_name": user_name})
        inject = f"<script>window.__DAG_SLOT_CONFIG__ = {config};</script>"
        # Insert config script just before </head>
        html = html.replace("</head>", inject + "\n</head>")
        return HTMLResponse(content=html)

    @dag_slot_app.get("/slots")
    async def get_slots():
        try:
            return JSONResponse({"status": "ok", "dags": _fetch_slots(),
                                 "mode": "db" if _has_db_config() else "airflow"})
        except Exception as e:
            log.exception("get_slots failed")
            return JSONResponse({"status": "error", "message": str(e)}, status_code=500)

    @dag_slot_app.get("/batches")
    async def get_batches():
        try:
            batches, next_batch = _fetch_batches()
            return JSONResponse({"status": "ok", "batches": batches,
                                 "next_batch": next_batch})
        except Exception as e:
            log.exception("get_batches failed")
            return JSONResponse({"status": "error", "message": str(e)}, status_code=500)

    class BookRequest(BaseModel):
        dag_name: str
        owner: str
        type: str = "Scrapy"
        cron: str
        batch: Optional[str] = None
        cmd: Optional[str] = None
        selenium: bool = False

    @dag_slot_app.post("/book")
    async def book_slot(payload: BookRequest):
        if not _has_db_config():
            return JSONResponse({"status": "error",
                                 "message": "Booking requires EXTRACTION_CONFIG Variable."},
                                status_code=400)
        if not payload.dag_name or not payload.owner or not payload.cron:
            return JSONResponse({"status": "error",
                                 "message": "dag_name, owner and cron are required"},
                                status_code=400)
        try:
            _do_book(payload.dag_name, payload.owner, payload.type,
                     payload.cron, payload.batch, payload.cmd, payload.selenium)
            return JSONResponse({"status": "ok",
                                 "message": f"{payload.dag_name} booked successfully"})
        except ValueError as e:
            return JSONResponse({"status": "error", "message": str(e)}, status_code=400)
        except Exception as e:
            log.exception("book_slot failed")
            return JSONResponse({"status": "error", "message": str(e)}, status_code=500)

    class CancelRequest(BaseModel):
        dag_name: str

    @dag_slot_app.post("/cancel")
    async def cancel_slot(payload: CancelRequest):
        if not _has_db_config():
            return JSONResponse({"status": "error",
                                 "message": "Cancel requires EXTRACTION_CONFIG Variable."},
                                status_code=400)
        try:
            _do_cancel(payload.dag_name)
            return JSONResponse({"status": "ok",
                                 "message": f"{payload.dag_name} cancelled"})
        except Exception as e:
            log.exception("cancel_slot failed")
            return JSONResponse({"status": "error", "message": str(e)}, status_code=500)

    class DagSlotBookingPlugin(AirflowPlugin):
        name = "dag_slot_booking"
        fastapi_apps = [
            {
                "app": dag_slot_app,
                "url_prefix": "/dag_slot_booking",
                "name": "DAG Slot Booking",
            }
        ]


# ===========================================================================
# AIRFLOW 2.x  — Flask Blueprint (unchanged)
# ===========================================================================
else:
    from flask import Blueprint, render_template, request, jsonify
    from flask_login import current_user

    dag_slot_bp = Blueprint(
        "dag_slot_booking",
        __name__,
        template_folder="templates",
    )

    @dag_slot_bp.record_once
    def _exempt_from_csrf(state):
        csrf = state.app.extensions.get("csrf")
        if csrf:
            csrf.exempt(dag_slot_bp)

    @dag_slot_bp.route("/dag_slot_booking", methods=["GET"])
    def index():
        user_name, user_email = "", ""
        try:
            user_name = current_user.first_name or current_user.username or ""
            user_email = current_user.email or ""
        except Exception:
            pass
        return render_template("dag_slot_booking/index.html",
                               user_name=user_name, user_email=user_email,
                               db_mode=_has_db_config())

    @dag_slot_bp.route("/dag_slot_booking/slots", methods=["GET"])
    def get_slots():
        try:
            return jsonify({"status": "ok", "dags": _fetch_slots(),
                            "mode": "db" if _has_db_config() else "airflow"})
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500

    @dag_slot_bp.route("/dag_slot_booking/batches", methods=["GET"])
    def get_batches():
        try:
            batches, next_batch = _fetch_batches()
            return jsonify({"status": "ok", "batches": batches,
                            "next_batch": next_batch})
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500

    @dag_slot_bp.route("/dag_slot_booking/book", methods=["POST"])
    def book_slot():
        if not _has_db_config():
            return jsonify({"status": "error",
                            "message": "Booking requires EXTRACTION_CONFIG Variable."}), 400
        data = request.get_json()
        dag_name = data.get("dag_name", "").strip()
        owner    = data.get("owner", "").strip()
        dag_type = data.get("type", "Scrapy")
        cron     = data.get("cron", "")
        batch    = data.get("batch") or None
        cmd      = data.get("cmd")   or None
        selenium = data.get("selenium", False)
        if not dag_name or not owner or not cron:
            return jsonify({"status": "error",
                            "message": "dag_name, owner and cron are required"}), 400
        try:
            _do_book(dag_name, owner, dag_type, cron, batch, cmd, selenium)
            return jsonify({"status": "ok",
                            "message": f"{dag_name} booked successfully"})
        except ValueError as e:
            return jsonify({"status": "error", "message": str(e)}), 400
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500

    @dag_slot_bp.route("/dag_slot_booking/cancel", methods=["POST"])
    def cancel_slot():
        if not _has_db_config():
            return jsonify({"status": "error",
                            "message": "Cancel requires EXTRACTION_CONFIG Variable."}), 400
        data = request.get_json()
        dag_name = data.get("dag_name", "").strip()
        try:
            _do_cancel(dag_name)
            return jsonify({"status": "ok", "message": f"{dag_name} cancelled"})
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500

    class DagSlotBookingPlugin(AirflowPlugin):
        name = "dag_slot_booking"
        flask_blueprints = [dag_slot_bp]
