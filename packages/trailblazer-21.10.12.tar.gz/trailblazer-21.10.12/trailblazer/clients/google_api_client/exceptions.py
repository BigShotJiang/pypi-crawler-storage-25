class GoogleAPIClientError(Exception):
    pass
