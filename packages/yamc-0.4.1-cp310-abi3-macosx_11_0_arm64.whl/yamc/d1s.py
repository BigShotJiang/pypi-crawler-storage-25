"""D1S (Direct 1-Step) shutdown dose rate post-processing.

This module provides functions for the D1S method, which calculates
shutdown dose rates from a single transport simulation by:
1. Replacing prompt photons with decay photons from activated products
2. Applying time correction factors (TCFs) in post-processing
"""

from yamc._core._d1s import (
    get_radionuclides_from_chain as _get_radionuclides_from_chain,
    time_correction_factors as _time_correction_factors,
    apply_time_correction as _apply_time_correction,
)


def get_radionuclides(model, transmutation_file=None):
    """Find unstable activation products reachable from model nuclides via chain reactions.

    For each nuclide in the model materials, looks up its chain reactions and
    collects all unstable targets (those with a finite half-life and decay
    photon sources).

    Args:
        model: A yamc.Model instance with materials containing nuclides.
        transmutation_file (str, optional): Path to the transmutation network
            (arrow directory or OpenMC chain XML).
            Defaults to ``yamc.transmutation_data``.

    Returns:
        list[str]: Sorted list of unique radionuclide names that can produce
            decay photons from activation of model nuclides.
    """
    model_nuclides = set()
    for cell in model.geometry.cells:
        if cell.material is not None:
            for name, _fraction in cell.material.nuclides:
                model_nuclides.add(name)
    return _get_radionuclides_from_chain(sorted(model_nuclides), transmutation_file)


def get_radionuclides_from_chain(nuclide_names, transmutation_file=None):
    """Find unstable activation products from a list of nuclide names.

    Like :func:`get_radionuclides` but takes an explicit list of nuclide names
    instead of extracting them from a model. Useful when tallies must be set up
    before the model is constructed.

    Args:
        nuclide_names (list[str]): Nuclide names present in the model materials.
        transmutation_file (str, optional): Path to the transmutation network
            (arrow directory or OpenMC chain XML).
            Defaults to ``yamc.transmutation_data``.

    Returns:
        list[str]: Sorted list of unique radionuclide names.
    """
    return _get_radionuclides_from_chain(list(nuclide_names), transmutation_file)


def time_correction_factors(nuclides, timesteps, source_rates, transmutation_file=None):
    """Compute time correction factors for D1S post-processing.

    For each nuclide, the TCF accounts for buildup during irradiation and
    decay during cooling, using the recurrence relation:

        h[i+1] = S[i] * (1 - exp(-lambda * dt)) + h[i] * exp(-lambda * dt)

    where lambda = ln(2) / half_life, S[i] is the source rate in step i,
    and dt is the timestep duration.

    The returned array has length ``len(timesteps) + 1``.  Index 0 is
    always 0 (no activation before the first step), and index *i* gives
    the TCF at the end of step *i - 1*.

    Args:
        nuclides (list[str]): List of radionuclide names.
        timesteps (list[float]): Duration of each timestep in seconds.
        source_rates (list[float]): Neutron source rate in each timestep (n/s).
            Use 0.0 for cooling steps.
        transmutation_file (str, optional): Path to the transmutation network
            (arrow directory or OpenMC chain XML).
            Defaults to ``yamc.transmutation_data``.

    Returns:
        dict[str, list[float]]: Mapping of nuclide name to list of TCF
            values with length ``len(timesteps) + 1``.

    Raises:
        ValueError: If timesteps and source_rates have different lengths.
        ValueError: If any nuclide is not found in the transmutation network.
    """
    return _time_correction_factors(
        list(nuclides), list(timesteps), list(source_rates), transmutation_file
    )


def apply_time_correction(tally_result, tcf, index=-1, sum_nuclides=True):
    """Apply time correction factors to D1S tally results.

    Scales per-nuclide tally contributions by their respective TCF values
    and optionally sums over all nuclides to get the total dose rate.

    Args:
        tally_result: A ``TallyResult`` from ``simulation_results[tally]``
            after a D1S run.
        tcf (dict[str, list[float]]): TCF values from
            :func:`time_correction_factors`.
        index (int): Which timestep's TCF to apply. Default -1 (last step).
        sum_nuclides (bool): If True, sum over all nuclides to return a single
            corrected result. If False, return per-nuclide results.

    Returns:
        dict: Result dictionary with keys:
            - 'mean': Corrected mean values (list)
            - 'standard_deviation': Corrected standard deviation values (list)
    """
    tally = tally_result.tally
    nuclides = tally.parent_nuclides
    if nuclides is None:
        raise ValueError(
            "Tally does not have parent_nuclides set. "
            "Pass parent_nuclides=... when constructing the Tally."
        )
    n_scores = len(tally.scores)

    # Convert any numpy arrays in tcf to plain lists for Rust
    tcf_lists = {name: list(arr) for name, arr in tcf.items()}

    corrected_mean, corrected_std = _apply_time_correction(
        list(tally_result.mean),
        list(tally_result.standard_deviation),
        nuclides,
        n_scores,
        tcf_lists,
        index,
        sum_nuclides,
    )

    return {"mean": corrected_mean, "standard_deviation": corrected_std}
