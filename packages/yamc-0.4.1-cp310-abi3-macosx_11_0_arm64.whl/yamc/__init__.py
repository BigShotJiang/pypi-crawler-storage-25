"""yamc — Yet Another Monte Carlo code."""

import sys
import types
from dataclasses import dataclass

from yamc._core import *  # noqa: F401,F403

# Re-export submodules
from yamc._core import data  # noqa: F401
from yamc import d1s  # noqa: F401

# Explicit imports for names used below (silences ruff F405)
from yamc._core import (  # noqa: F811
    Cell,
    Geometry,
    Halfspace,
    Model,
    NeutronSource,
    PhotonSource,
    Region,
    get_transmutation_data as _get_transmutation_data,
    get_transport_data as _get_transport_data,
    lookup_transport_data,  # noqa: F401  (public helper)
    set_transmutation_data as _set_transmutation_data,
    set_transport_data as _set_transport_data,
    set_transport_data_entry,  # noqa: F401  (public helper)
)


# ---------------------------------------------------------------------------
# Module-level properties for transport and transmutation data
# ---------------------------------------------------------------------------

class _YamcModule(types.ModuleType):
    """Module subclass that exposes transport_data / transmutation_data as properties."""

    @property
    def transport_data(self):
        return _get_transport_data()

    @transport_data.setter
    def transport_data(self, value):
        _set_transport_data(value)

    @property
    def transmutation_data(self):
        return _get_transmutation_data()

    @transmutation_data.setter
    def transmutation_data(self, value):
        _set_transmutation_data(value)


sys.modules[__name__].__class__ = _YamcModule



# ---------------------------------------------------------------------------
# Enriched helper for Material composition dicts
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Enriched:
    """Enrichment specification for use in Material composition dicts."""

    fraction: float
    target: str
    percent: float
    type: str = "atom"


def enriched(fraction, *, target, percent, type="atom"):
    """Create an enrichment specification for a Material composition entry.

    Args:
        fraction: Fraction of this component in the material.
        target: Target nuclide for enrichment (e.g. "Li6").
        percent: Enrichment percentage of the target isotope.
        type: "atom" for atom percent or "mass" for weight percent.

    Returns:
        Enriched: An enrichment specification.
    """
    return Enriched(fraction=fraction, target=target, percent=percent, type=type)


# ---------------------------------------------------------------------------
# write_vtkhdf methods (lazy-imported to avoid hard h5py/numpy dependency)
# ---------------------------------------------------------------------------

def _geometry_write_vtkhdf(self, filename, **kwargs):
    """Write geometry to a VTK-HDF ImageData file with material and cell IDs.

    Requires ``h5py`` (install with ``pip install yamc[viz]``).

    Args:
        filename (str): Output file path (recommended: ``.vtkhdf``).
        **kwargs: Keyword arguments forwarded to
            ``yamc.vtkhdf.write_geometry_vtkhdf`` (``pixels``, ``datasets``).
    """
    from yamc.vtkhdf import write_geometry_vtkhdf
    write_geometry_vtkhdf(filename, self, **kwargs)


def _cell_write_vtkhdf(self, filename, **kwargs):
    """Write cell to a VTK-HDF ImageData file with material and cell IDs.

    Requires ``h5py`` (install with ``pip install yamc[viz]``).

    Args:
        filename (str): Output file path (recommended: ``.vtkhdf``).
        **kwargs: Keyword arguments forwarded to
            ``yamc.vtkhdf.write_cell_vtkhdf`` (``pixels``, ``datasets``).
    """
    from yamc.vtkhdf import write_cell_vtkhdf
    write_cell_vtkhdf(filename, self, **kwargs)


def _region_write_vtkhdf(self, filename, *, pixels=10000):
    """Write region to a VTK-HDF ImageData file.

    Requires ``h5py`` (install with ``pip install yamc[viz]``).

    Args:
        filename (str): Output file path (recommended: ``.vtkhdf``).
        pixels (int): Approximate total number of voxels (default 10 000).
    """
    from yamc.vtkhdf import write_region_vtkhdf
    write_region_vtkhdf(filename, self, pixels=pixels)


def _model_write_vtkhdf(self, filename, **kwargs):
    """Write model geometry to a VTK-HDF ImageData file with material and cell IDs.

    Requires ``h5py`` (install with ``pip install yamc[viz]``).

    Args:
        filename (str): Output file path (recommended: ``.vtkhdf``).
        **kwargs: Keyword arguments forwarded to
            ``yamc.vtkhdf.write_geometry_vtkhdf`` (``pixels``, ``datasets``).
    """
    from yamc.vtkhdf import write_geometry_vtkhdf
    write_geometry_vtkhdf(filename, self.geometry, **kwargs)


def _model_write_source_vtkhdf(self, filename, **kwargs):
    """Write sampled source points to a VTK-HDF file for ParaView visualization.

    Requires ``h5py`` (install with ``pip install yamc[viz]``).

    Args:
        filename (str): Output file path (recommended extension: ``.vtkhdf``)
        **kwargs: Keyword arguments forwarded to
            ``yamc.vtkhdf.write_source_vtkhdf`` (``samples``).
    """
    from yamc.vtkhdf import write_source_vtkhdf
    write_source_vtkhdf(filename, self.source, **kwargs)


def _source_write_vtkhdf(self, filename, **kwargs):
    """Write sampled source points to a VTK-HDF file for ParaView visualization.

    Requires ``h5py`` (install with ``pip install yamc[viz]``).

    Args:
        filename (str): Output file path (recommended extension: ``.vtkhdf``)
        **kwargs: Keyword arguments forwarded to
            ``yamc.vtkhdf.write_source_vtkhdf`` (``samples``).
    """
    from yamc.vtkhdf import write_source_vtkhdf
    write_source_vtkhdf(filename, self, **kwargs)


Geometry.write_vtkhdf = _geometry_write_vtkhdf
Cell.write_vtkhdf = _cell_write_vtkhdf
Region.write_vtkhdf = _region_write_vtkhdf
Halfspace.write_vtkhdf = _region_write_vtkhdf
Model.write_vtkhdf = _model_write_vtkhdf
Model.write_source_vtkhdf = _model_write_source_vtkhdf
NeutronSource.write_vtkhdf = _source_write_vtkhdf
PhotonSource.write_vtkhdf = _source_write_vtkhdf
