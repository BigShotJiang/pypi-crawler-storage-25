"""CAD meshing pipeline — requires cadquery."""

# Rust CDT functions (always available, no cadquery needed)
from yamc._core import mesh_face, mesh_faces, export_arrow

# High-level API (cadquery imported lazily at class instantiation)
from .mesher import CadToYamc, SurfaceMesh
from .assembly_processor import ProcessedAssembly

__all__ = [
    "mesh_face", "mesh_faces", "export_arrow",
    "CadToYamc", "SurfaceMesh", "ProcessedAssembly",
]
