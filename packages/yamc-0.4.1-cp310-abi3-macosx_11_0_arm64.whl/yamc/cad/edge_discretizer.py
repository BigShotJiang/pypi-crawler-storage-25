"""Edge discretization using OCC geometry evaluation.

Discretizes BRep edges into UV-space polylines on a given face.
"""

from OCP.BRepAdaptor import BRepAdaptor_Curve, BRepAdaptor_Curve2d
from OCP.GCPnts import GCPnts_TangentialDeflection, GCPnts_UniformAbscissa


def discretize_edge_uv(edge, face, mode="coarse", target_length=None, tolerance=0.1, angular_tolerance=0.1):
    """Discretize a BRep edge into UV-space polyline points on a face.

    Args:
        edge: OCC TopoDS_Edge (the .wrapped from cadquery)
        face: OCC TopoDS_Face (the .wrapped from cadquery)
        mode: "coarse" for minimal points, "fine" for controlled density
        target_length: target edge length in 3D space (for fine mode)
        tolerance: chordal tolerance for curve discretization
        angular_tolerance: angular tolerance for curve discretization

    Returns:
        List of [u, v] points in the face's parametric space.
    """
    # Get both 2D and 3D curve representations
    curve2d = BRepAdaptor_Curve2d(edge, face)
    u_first = curve2d.FirstParameter()
    u_last = curve2d.LastParameter()

    if mode == "coarse":
        # Discretize the 3D curve to capture the actual geometric curvature,
        # then sample UV coordinates at those parameters.  Using the 2D curve
        # instead would miss 3D curvature on surfaces like spheres where UV
        # curves are straight lines.
        curve3d = BRepAdaptor_Curve(edge)
        disc = GCPnts_TangentialDeflection(curve3d, tolerance, angular_tolerance)
        points = []
        for i in range(1, disc.NbPoints() + 1):
            param = disc.Parameter(i)
            pnt2d = curve2d.Value(param)
            points.append([pnt2d.X(), pnt2d.Y()])
        return points

    elif mode == "fine" and target_length is not None:
        # For fine mode, distribute points uniformly by arc length
        # First estimate total length
        from OCP.GCPnts import GCPnts_AbscissaPoint

        curve3d = BRepAdaptor_Curve(edge)
        total_length = GCPnts_AbscissaPoint.Length_s(curve3d)
        n_segments = max(1, int(total_length / target_length))
        n_points = n_segments + 1

        disc = GCPnts_UniformAbscissa(curve2d, n_points)
        points = []
        if disc.IsDone():
            for i in range(1, disc.NbPoints() + 1):
                param = disc.Parameter(i)
                pnt2d = curve2d.Value(param)
                points.append([pnt2d.X(), pnt2d.Y()])
        else:
            # Fallback: just use endpoints
            p_first = curve2d.Value(u_first)
            p_last = curve2d.Value(u_last)
            points = [[p_first.X(), p_first.Y()], [p_last.X(), p_last.Y()]]
        return points

    else:
        # Default: just endpoints
        p_first = curve2d.Value(u_first)
        p_last = curve2d.Value(u_last)
        return [[p_first.X(), p_first.Y()], [p_last.X(), p_last.Y()]]
