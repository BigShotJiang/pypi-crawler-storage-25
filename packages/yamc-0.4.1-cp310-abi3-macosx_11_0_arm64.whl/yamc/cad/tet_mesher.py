"""Tetrahedral volume meshing via netgen-mesher.

Uses netgen's OCCGeometry integration to mesh OCC solids directly,
producing high-quality, uniform tetrahedra.
"""

import os
import tempfile

import numpy as np


def tet_mesh_volume(solid_shape, target_edge_length=None, grading=0.05,
                    optsteps3d=5, optimize3d="cmdDmstmstm",
                    elsizeweight=0.0):
    """Generate a tetrahedral mesh for an OCC solid via netgen.

    Args:
        solid_shape: CadQuery Shape or OCC TopoDS_Shape to tet-mesh.
        target_edge_length: Target edge length (absolute, 3D units).
            Controls both maxh and minh for uniform sizing.
        grading: Mesh grading (0 to 1).  Lower values produce more
            uniform tet sizes.  Default 0.05.
        optsteps3d: Number of 3D optimization passes.  Default 5.
        optimize3d: Optimization strategy string.  Default includes
            Jacobian smoothing passes for equilateral tets.
        elsizeweight: Weight of size conformity vs shape quality in
            optimization (0 = pure shape).  Default 0.0.

    Returns:
        (tet_vertices, tet_connectivity, surface_tris, surface_face_indices):
        - tet_vertices: numpy array of shape (N, 3), float64
        - tet_connectivity: numpy array of shape (M, 4), int32
        - surface_tris: numpy array of shape (S, 3), int32
            Boundary triangles (indices into tet_vertices)
        - surface_face_indices: numpy array of shape (S,), int32
            Netgen face index for each boundary triangle
    """
    try:
        from netgen.occ import OCCGeometry
    except ImportError:
        raise ImportError(
            "netgen-mesher is required for tet meshing. "
            "Install it with: pip install netgen-mesher"
        ) from None

    # Serialize the OCC shape to BREP (netgen bundles its own OCC,
    # so we can't pass CadQuery/OCP shapes directly)
    from OCP.BRepTools import BRepTools

    occ_shape = solid_shape.wrapped if hasattr(solid_shape, 'wrapped') else solid_shape

    fd, brep_path = tempfile.mkstemp(suffix='.brep')
    os.close(fd)
    try:
        BRepTools.Write_s(occ_shape, brep_path)

        geo = OCCGeometry(brep_path, dim=3)

        mesh_kwargs = {
            "grading": grading,
            "optsteps3d": optsteps3d,
            "optimize3d": optimize3d,
            "elsizeweight": elsizeweight,
        }
        if target_edge_length is not None:
            # Scale maxh down by 0.8 so that actual edge lengths stay
            # close to the target.  Netgen's maxh is a soft target and
            # edges routinely exceed it; the 0.8 factor compensates,
            # producing more equilateral tets.
            h = float(target_edge_length) * 0.8
            mesh_kwargs["maxh"] = h
            mesh_kwargs["minh"] = h

        ngmesh = geo.GenerateMesh(**mesh_kwargs)

        # Extract vertices and tet connectivity
        points = ngmesh.Points()
        verts = np.array([[p[0], p[1], p[2]] for p in points], dtype=np.float64)
        tets = np.array(
            [[v.nr - 1 for v in el.vertices] for el in ngmesh.Elements3D()],
            dtype=np.int32,
        )

        # Fix orientation: netgen's winding convention is opposite to yamc's
        # (all tets have negative signed volume without this swap)
        tets[:, [0, 1]] = tets[:, [1, 0]]

        # Extract surface elements with their face indices.
        # These are the boundary faces of the tet mesh — each triangle
        # lies on one CAD face.  el.index gives netgen's face descriptor
        # index (1-based).
        surf_tri_list = []
        surf_idx_list = []
        for el in ngmesh.Elements2D():
            surf_tri_list.append([v.nr - 1 for v in el.vertices])
            surf_idx_list.append(el.index)

        if surf_tri_list:
            surface_tris = np.array(surf_tri_list, dtype=np.int32)
            surface_face_indices = np.array(surf_idx_list, dtype=np.int32)
        else:
            surface_tris = np.empty((0, 3), dtype=np.int32)
            surface_face_indices = np.empty((0,), dtype=np.int32)

        return verts, tets, surface_tris, surface_face_indices
    finally:
        os.unlink(brep_path)
