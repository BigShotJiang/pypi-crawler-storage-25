"""UV to 3D coordinate evaluation using OCC BRepAdaptor_Surface."""

from OCP.BRepAdaptor import BRepAdaptor_Surface


def evaluate_uv_to_3d(occ_face, uv_points):
    """Evaluate a list of UV points to 3D coordinates on a face.

    Args:
        occ_face: OCC TopoDS_Face.
        uv_points: List of [u, v] pairs.

    Returns:
        List of [x, y, z] coordinates.
    """
    surface = BRepAdaptor_Surface(occ_face)
    result = []
    for u, v in uv_points:
        pnt = surface.Value(u, v)
        result.append([pnt.X(), pnt.Y(), pnt.Z()])
    return result
