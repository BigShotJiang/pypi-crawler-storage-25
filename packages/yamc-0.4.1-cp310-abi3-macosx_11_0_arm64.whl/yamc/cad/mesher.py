"""Main CadToYamc class — end-to-end surface meshing pipeline.

Takes a CadQuery assembly, imprints it, meshes each face via OCC's
BRepMesh_IncrementalMesh, and produces a global vertex + triangle mesh
with per-face and per-volume metadata.
"""

from dataclasses import dataclass, field

import json
import os

from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRep import BRep_Tool
from OCP.TopLoc import TopLoc_Location

from .assembly_processor import process_assembly
from . import export_arrow as _export_arrow


@dataclass
class SurfaceMesh:
    """Result of surface meshing an assembly."""
    vertices: list  # list of [x, y, z]
    triangles: list  # list of [v0, v1, v2] (indices into vertices)
    triangle_face_ids: list  # face_id for each triangle
    triangle_surface_ids: list  # surface_id for each triangle (1-indexed)
    face_to_surface_id: dict  # face_id -> surface_id
    solid_faces: dict  # solid_id -> list of face_ids
    shared_faces: dict  # face_id -> [solid_id, solid_id]
    material_tags: list  # ordered material tags
    num_solids: int
    num_faces: int
    face_solid_reversed: dict = field(default_factory=dict)
    # (solid_id, face_id) -> bool: True when face is REVERSED in that solid
    # (UV surface normal points inward to the solid)


def _get_leaf_children(assembly):
    """Yield all leaf children (parts without sub-children) of an assembly."""
    for child in assembly.children:
        if hasattr(child, "children") and len(child.children) > 0:
            yield from _get_leaf_children(child)
        else:
            yield child


def _resolve_material_tags(assembly, shortcut):
    """Resolve a string shortcut into a list of material tag strings.

    Supported shortcuts:
        ``"assembly_names"``      — use each part's ``.name``
        ``"assembly_materials"``  — use each part's ``.material.name``
    """
    if shortcut == "assembly_names":
        return [child.name for child in _get_leaf_children(assembly)]

    if shortcut == "assembly_materials":
        tags = []
        for child in _get_leaf_children(assembly):
            if child.material is not None and child.material.name is not None:
                tags.append(str(child.material.name))
            else:
                raise ValueError(
                    f"Part {child.name!r} has no material assigned. "
                    "Assign materials with cq.Material('name') or provide "
                    "an explicit material_tags list."
                )
        return tags

    raise ValueError(
        f"material_tags string must be 'assembly_names' or "
        f"'assembly_materials', got {shortcut!r}"
    )


def _map_netgen_faces(tet_verts, surf_tris, surf_face_indices,
                      face_ids, face_to_occ):
    """Map netgen face indices to assembly face_ids.

    Groups boundary triangles by netgen face index, picks one sample
    centroid per group, and finds the nearest CAD face using OCC distance
    queries.  Only *F* distance checks are needed (one per netgen face
    group), not one per triangle.
    """
    from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
    from OCP.BRepExtrema import BRepExtrema_DistShapeShape
    from OCP.gp import gp_Pnt

    # Group triangle indices by netgen face index
    groups = {}
    for i, nf_idx in enumerate(surf_face_indices):
        groups.setdefault(int(nf_idx), []).append(i)

    netgen_to_fid = {}
    for nf_idx, tri_indices in groups.items():
        # Sample centroid from the first triangle in this group
        tri = surf_tris[tri_indices[0]]
        centroid = (
            tet_verts[tri[0]] + tet_verts[tri[1]] + tet_verts[tri[2]]
        ) / 3.0
        pnt = gp_Pnt(
            float(centroid[0]), float(centroid[1]), float(centroid[2])
        )
        vertex = BRepBuilderAPI_MakeVertex(pnt).Vertex()

        best_fid = None
        best_dist = float("inf")
        for fid in face_ids:
            extrema = BRepExtrema_DistShapeShape(vertex, face_to_occ[fid])
            if extrema.IsDone():
                dist = extrema.Value()
                if dist < best_dist:
                    best_dist = dist
                    best_fid = fid

        netgen_to_fid[nf_idx] = best_fid

    return netgen_to_fid


# Tet face vertex ordering matching yamt's TET_FACE_VERTICES
_TET_FACE_VERTICES = [
    [1, 2, 3],  # Face 0: opposite vertex 0
    [0, 3, 2],  # Face 1: opposite vertex 1
    [0, 1, 3],  # Face 2: opposite vertex 2
    [0, 2, 1],  # Face 3: opposite vertex 3
]


def _compute_tet_adjacency(flat_tets):
    """Compute tet-to-tet adjacency from flat tet connectivity.

    Returns flat list of i32: [n0,n1,n2,n3, ...] per tet, -1 = boundary.
    """
    if not flat_tets:
        return []
    n_tets = len(flat_tets) // 4
    adjacency = [-1] * (n_tets * 4)
    face_map = {}  # sorted (v0,v1,v2) -> (tet_idx, face_idx)

    for tet_idx in range(n_tets):
        base = tet_idx * 4
        verts = [flat_tets[base], flat_tets[base + 1],
                 flat_tets[base + 2], flat_tets[base + 3]]
        for face_idx, fv in enumerate(_TET_FACE_VERTICES):
            key = tuple(sorted([verts[fv[0]], verts[fv[1]], verts[fv[2]]]))
            if key in face_map:
                other_tet, other_face = face_map.pop(key)
                adjacency[tet_idx * 4 + face_idx] = other_tet
                adjacency[other_tet * 4 + other_face] = tet_idx
            else:
                face_map[key] = (tet_idx, face_idx)

    return adjacency


def _compute_tri_aabbs(flat_vertices, flat_triangles):
    """Compute per-triangle AABBs from flat vertex/triangle data.

    Returns flat list of f64: [min_x,min_y,min_z,max_x,max_y,max_z, ...].
    """
    if not flat_triangles:
        return []
    n_tris = len(flat_triangles) // 3
    aabbs = []
    for i in range(n_tris):
        base = i * 3
        i0, i1, i2 = flat_triangles[base], flat_triangles[base + 1], flat_triangles[base + 2]
        v0x, v0y, v0z = flat_vertices[i0 * 3], flat_vertices[i0 * 3 + 1], flat_vertices[i0 * 3 + 2]
        v1x, v1y, v1z = flat_vertices[i1 * 3], flat_vertices[i1 * 3 + 1], flat_vertices[i1 * 3 + 2]
        v2x, v2y, v2z = flat_vertices[i2 * 3], flat_vertices[i2 * 3 + 1], flat_vertices[i2 * 3 + 2]
        aabbs.extend([
            min(v0x, v1x, v2x), min(v0y, v1y, v2y), min(v0z, v1z, v2z),
            max(v0x, v1x, v2x), max(v0y, v1y, v2y), max(v0z, v1z, v2z),
        ])
    return aabbs


def _compute_tet_aabbs(flat_vertices, flat_tets):
    """Compute per-tet AABBs from flat vertex/tet data.

    Returns flat list of f64: [min_x,min_y,min_z,max_x,max_y,max_z, ...].
    """
    if not flat_tets:
        return []
    n_tets = len(flat_tets) // 4
    aabbs = []
    for i in range(n_tets):
        base = i * 4
        i0, i1, i2, i3 = flat_tets[base], flat_tets[base + 1], flat_tets[base + 2], flat_tets[base + 3]
        v0x, v0y, v0z = flat_vertices[i0 * 3], flat_vertices[i0 * 3 + 1], flat_vertices[i0 * 3 + 2]
        v1x, v1y, v1z = flat_vertices[i1 * 3], flat_vertices[i1 * 3 + 1], flat_vertices[i1 * 3 + 2]
        v2x, v2y, v2z = flat_vertices[i2 * 3], flat_vertices[i2 * 3 + 1], flat_vertices[i2 * 3 + 2]
        v3x, v3y, v3z = flat_vertices[i3 * 3], flat_vertices[i3 * 3 + 1], flat_vertices[i3 * 3 + 2]
        aabbs.extend([
            min(v0x, v1x, v2x, v3x), min(v0y, v1y, v2y, v3y), min(v0z, v1z, v2z, v3z),
            max(v0x, v1x, v2x, v3x), max(v0y, v1y, v2y, v3y), max(v0z, v1z, v2z, v3z),
        ])
    return aabbs


class CadToYamc:
    """Convert CadQuery assemblies to surface/volume meshes."""

    def __init__(self):
        """Initialize an empty CadToYamc converter."""
        self._assembly = None
        self._material_tags = None
        self._processed = None
        self._surface_mesh = None
        self._tet_data = {}  # solid_id -> (tet_vertices, tet_connectivity)
        self._tet_surface_data = {}  # solid_id -> (surface_tris, surface_face_indices)
        self._tet_vertex_offsets = {}  # solid_id -> offset into mesh.vertices

    def add_cadquery_object(self, assembly, material_tags):
        """Add a CadQuery assembly with material tags.

        Args:
            assembly: CadQuery Assembly with named parts.
            material_tags: List of material tag strings, one per solid,
                or the string ``"assembly_names"`` to use each part's
                name, or ``"assembly_materials"`` to use each part's
                ``cq.Material`` name.
        """
        if isinstance(material_tags, str):
            material_tags = _resolve_material_tags(assembly, material_tags)

        self._assembly = assembly
        self._material_tags = material_tags

    def mesh(self, tet_volumes=None, target_edge_length=None,
             tolerance=0.1, angular_tolerance=0.1, grading=0.05,
             optsteps3d=5, optimize3d="cmdDmstmstm",
             elsizeweight=0.0):
        """Mesh the assembly: surfaces + optional tet volumes.

        Surfaces are meshed using OCC's BRepMesh with the given tolerance.
        Volumes listed in *tet_volumes* are then filled with tetrahedra
        via netgen.

        Args:
            tet_volumes: List of material tag names to tet-mesh, or None
                for surface-only meshing.
            target_edge_length: Target edge length for tets (3D units).
                Required when *tet_volumes* is not None.
            tolerance: Chordal deflection tolerance for surface meshing
                (3D units).  Smaller values produce more triangles on
                curved surfaces.  Default 0.1.
            angular_tolerance: Angular deflection tolerance for surface
                meshing (radians).  Default 0.1 (~5.7 degrees).
            grading: Mesh grading for netgen tet meshing (0 to 1).
                Lower values produce more uniform tet sizes.
                Default 0.05.
            optsteps3d: Number of netgen 3D optimization passes.
                Default 5.
            optimize3d: Netgen optimization strategy string.
                Default includes Jacobian smoothing for equilateral tets.
            elsizeweight: Weight of size conformity vs shape quality
                (0 = pure shape optimization).  Default 0.0.

        Returns:
            SurfaceMesh with global vertex/triangle arrays.
        """
        if self._assembly is None:
            raise RuntimeError("No assembly added. Call add_cadquery_object first.")

        if tet_volumes and target_edge_length is None:
            raise ValueError(
                "target_edge_length is required when tet_volumes is specified"
            )

        self._mesh_surfaces(
            tolerance=tolerance,
            angular_tolerance=angular_tolerance,
        )

        if tet_volumes:
            solids_to_tet = set()
            for i, tag in enumerate(self._material_tags):
                if tag in tet_volumes:
                    solids_to_tet.add(i + 1)  # solid IDs are 1-indexed

            self._mesh_volumes(
                solids_to_tet,
                tet_target_edge_length=target_edge_length,
                grading=grading,
                optsteps3d=optsteps3d,
                optimize3d=optimize3d,
                elsizeweight=elsizeweight,
            )
            self._replace_tet_surfaces()

        return self._surface_mesh

    # ------------------------------------------------------------------
    # Lower-level methods (kept for backward compatibility)
    # ------------------------------------------------------------------

    def mesh_surfaces(self, mode="coarse", target_edge_length=None,
                      tolerance=0.1, angular_tolerance=0.1):
        """Mesh all surfaces of the assembly.

        Args:
            mode: Ignored (kept for backward compatibility).  Mesh
                density is controlled by *tolerance* and
                *angular_tolerance*.
            target_edge_length: Ignored (kept for backward compatibility).
            tolerance: Chordal deflection tolerance for BRepMesh (3D units).
            angular_tolerance: Angular deflection tolerance (radians).

        Returns:
            SurfaceMesh with global vertex/triangle arrays.
        """
        if self._assembly is None:
            raise RuntimeError("No assembly added. Call add_cadquery_object first.")

        return self._mesh_surfaces(
            tolerance=tolerance,
            angular_tolerance=angular_tolerance,
        )

    def mesh_volumes(self, volumes_to_tet=None, tet_target_edge_length=None,
                     grading=0.05, optsteps3d=5,
                     optimize3d="cmdDmstmstm", elsizeweight=0.0):
        """Generate tetrahedral meshes for selected volumes.

        Args:
            volumes_to_tet: List of material tag names to tet-mesh.
                If None, tet-meshes all volumes.
            tet_target_edge_length: Target edge length for tets.
            grading: Mesh grading for netgen (0 to 1).  Lower = more
                uniform.  Default 0.05.
            optsteps3d: Number of netgen 3D optimization passes.
                Default 5.
            optimize3d: Netgen optimization strategy string.
            elsizeweight: Weight of size conformity vs shape quality.
                Default 0.0.

        Returns:
            Dict mapping solid_id -> (tet_vertices, tet_connectivity).
        """
        if self._surface_mesh is None:
            raise RuntimeError("No surface mesh. Call mesh() or mesh_surfaces() first.")

        # Determine which solids to tet-mesh
        solids_to_tet = set()
        mesh = self._surface_mesh
        for solid_id in mesh.solid_faces:
            tag_idx = solid_id - 1
            if tag_idx < len(mesh.material_tags):
                tag = mesh.material_tags[tag_idx]
            else:
                tag = None
            if volumes_to_tet is None or tag in volumes_to_tet:
                solids_to_tet.add(solid_id)

        self._mesh_volumes(
            solids_to_tet,
            tet_target_edge_length=tet_target_edge_length,
            grading=grading,
            optsteps3d=optsteps3d,
            optimize3d=optimize3d,
            elsizeweight=elsizeweight,
        )
        self._replace_tet_surfaces()
        return self._tet_data

    # ------------------------------------------------------------------
    # Internal implementation
    # ------------------------------------------------------------------

    def _mesh_surfaces(self, tolerance=0.1, angular_tolerance=0.1):
        """Mesh surfaces using OCC's BRepMesh_IncrementalMesh.

        Imprints the assembly, runs BRepMesh on the compound, and extracts
        triangulations per face.
        """
        self._processed = process_assembly(self._assembly, self._material_tags)
        pa = self._processed

        # Run BRepMesh on the imprinted compound
        BRepMesh_IncrementalMesh(
            pa.imprinted_compound, tolerance, False, angular_tolerance
        )

        # Extract triangulations per face
        vertices = []
        triangles = []
        triangle_face_ids = []
        triangle_surface_ids = []
        face_to_surface_id = {}

        surface_id_counter = 1
        for fid, face_info in pa.faces.items():
            occ_face = pa.face_to_occ[fid]
            loc = TopLoc_Location()
            tri = BRep_Tool.Triangulation_s(occ_face, loc)

            if tri is None:
                continue

            # Assign a surface ID
            sid = surface_id_counter
            surface_id_counter += 1
            face_to_surface_id[fid] = sid

            base_idx = len(vertices)

            # Extract vertices (apply location transform if present)
            transform = loc.Transformation()
            has_transform = not loc.IsIdentity()
            face_verts = []
            for i in range(1, tri.NbNodes() + 1):
                pnt = tri.Node(i)
                if has_transform:
                    pnt = pnt.Transformed(transform)
                face_verts.append([pnt.X(), pnt.Y(), pnt.Z()])
            vertices.extend(face_verts)

            # Extract triangles (skip degenerate ones at poles/singularities)
            for i in range(1, tri.NbTriangles() + 1):
                t = tri.Triangle(i)
                i1, i2, i3 = t.Get()
                # Skip if two node indices are the same
                if i1 == i2 or i2 == i3 or i1 == i3:
                    continue
                # Skip if triangle area is effectively zero
                v0 = face_verts[i1 - 1]
                v1 = face_verts[i2 - 1]
                v2 = face_verts[i3 - 1]
                e1 = [v1[j] - v0[j] for j in range(3)]
                e2 = [v2[j] - v0[j] for j in range(3)]
                cross_sq = (
                    (e1[1] * e2[2] - e1[2] * e2[1]) ** 2
                    + (e1[2] * e2[0] - e1[0] * e2[2]) ** 2
                    + (e1[0] * e2[1] - e1[1] * e2[0]) ** 2
                )
                if cross_sq < 1e-24:
                    continue
                # Convert from 1-indexed to 0-indexed, add base offset
                triangles.append([
                    i1 - 1 + base_idx,
                    i2 - 1 + base_idx,
                    i3 - 1 + base_idx,
                ])
                triangle_face_ids.append(fid)
                triangle_surface_ids.append(sid)

        self._surface_mesh = SurfaceMesh(
            vertices=vertices,
            triangles=triangles,
            triangle_face_ids=triangle_face_ids,
            triangle_surface_ids=triangle_surface_ids,
            face_to_surface_id=face_to_surface_id,
            solid_faces=pa.solid_faces,
            shared_faces=pa.shared_faces,
            material_tags=pa.material_tags,
            num_solids=len(pa.solid_faces),
            num_faces=len(pa.faces),
            face_solid_reversed=pa.face_solid_reversed,
        )

        return self._surface_mesh

    def _mesh_volumes(self, solids_to_tet, tet_target_edge_length=None,
                      grading=0.05, optsteps3d=5,
                      optimize3d="cmdDmstmstm", elsizeweight=0.0):
        """Run netgen on the specified solid IDs."""
        from .tet_mesher import tet_mesh_volume

        pa = self._processed

        for solid_id in solids_to_tet:
            solid_shape = pa.solid_shapes.get(solid_id)
            if solid_shape is None:
                continue

            tet_v, tet_t, surf_tris, surf_fi = tet_mesh_volume(
                solid_shape,
                target_edge_length=tet_target_edge_length,
                grading=grading,
                optsteps3d=optsteps3d,
                optimize3d=optimize3d,
                elsizeweight=elsizeweight,
            )
            self._tet_data[solid_id] = (tet_v, tet_t)
            self._tet_surface_data[solid_id] = (surf_tris, surf_fi)

    def _replace_tet_surfaces(self):
        """Replace BRepMesh surface triangles with tet boundary faces.

        For each tet-meshed volume, the coarse BRepMesh triangulation is
        replaced by the boundary triangles from netgen's tet mesh.  This
        makes the surface mesh and tet mesh conformal — the surface
        triangles are exactly the outer faces of the tetrahedra.
        """
        if not self._tet_data:
            return

        pa = self._processed
        mesh = self._surface_mesh

        # Collect all face_ids that belong to tet-meshed volumes
        tet_face_ids = set()
        for solid_id in self._tet_data:
            tet_face_ids.update(pa.solid_faces[solid_id])

        # Filter out old BRepMesh triangles for tet-meshed faces
        new_triangles = []
        new_tri_face_ids = []
        new_tri_surface_ids = []
        for i, tri in enumerate(mesh.triangles):
            if mesh.triangle_face_ids[i] not in tet_face_ids:
                new_triangles.append(tri)
                new_tri_face_ids.append(mesh.triangle_face_ids[i])
                new_tri_surface_ids.append(mesh.triangle_surface_ids[i])

        # For each tet-meshed volume, add tet boundary triangles
        for solid_id, (tet_v, _tet_t) in self._tet_data.items():
            surf_tris, surf_fi = self._tet_surface_data[solid_id]
            if len(surf_tris) == 0:
                continue

            # Map netgen face indices to our face_ids
            netgen_to_fid = _map_netgen_faces(
                tet_v, surf_tris, surf_fi,
                pa.solid_faces[solid_id], pa.face_to_occ,
            )

            # Add tet vertices to the global vertex array.
            # Record the offset so export_arrow() can reference the same
            # vertices for tet connectivity (no duplication).
            tet_base_idx = len(mesh.vertices)
            self._tet_vertex_offsets[solid_id] = tet_base_idx
            for v in tet_v:
                mesh.vertices.append(
                    [float(v[0]), float(v[1]), float(v[2])]
                )

            # Add boundary triangles with correct face/surface IDs
            for i, tri in enumerate(surf_tris):
                nf_idx = int(surf_fi[i])
                fid = netgen_to_fid.get(nf_idx)
                if fid is None:
                    continue
                sid = mesh.face_to_surface_id.get(fid)
                if sid is None:
                    continue
                new_triangles.append([
                    int(tri[0]) + tet_base_idx,
                    int(tri[1]) + tet_base_idx,
                    int(tri[2]) + tet_base_idx,
                ])
                new_tri_face_ids.append(fid)
                new_tri_surface_ids.append(sid)

        mesh.triangles = new_triangles
        mesh.triangle_face_ids = new_tri_face_ids
        mesh.triangle_surface_ids = new_tri_surface_ids

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export_arrow(self, path, boundary_tags=None):
        """Export the mesh to an Arrow IPC file.

        Args:
            path: Output file path (e.g. "model.arrow").
            boundary_tags: Optional dict of face_name -> boundary.
        """
        if self._surface_mesh is None:
            raise RuntimeError("No surface mesh. Call mesh() first.")

        mesh = self._surface_mesh

        # Build physical groups: one per material (dim=3)
        physical_groups = {}
        pg_id = 1

        material_pg_ids = {}
        for i, tag in enumerate(mesh.material_tags):
            physical_groups[str(pg_id)] = {"name": f"mat:{tag}", "dim": 3}
            material_pg_ids[i + 1] = pg_id  # solid_id -> pg_id
            pg_id += 1

        # Flatten vertices
        flat_vertices = []
        for v in mesh.vertices:
            flat_vertices.extend(v)

        # Flatten triangles and build physical group assignments
        flat_triangles = []
        tri_surface_ids = []
        tri_physical_groups = []
        for i, tri in enumerate(mesh.triangles):
            flat_triangles.extend([int(t) for t in tri])
            tri_surface_ids.append(mesh.triangle_surface_ids[i])
            # Assign physical group based on which solid owns this face
            fid = mesh.triangle_face_ids[i]
            pg = -1
            for solid_id, face_ids in mesh.solid_faces.items():
                if fid in face_ids:
                    pg = material_pg_ids.get(solid_id, -1)
                    break
            tri_physical_groups.append(pg)

        # Flatten tet data if available.
        # Tet vertices are already in mesh.vertices (added by
        # _replace_tet_surfaces), so we just offset the connectivity.
        flat_tets = []
        tet_volume_ids = []
        tet_physical_groups = []

        if self._tet_data:
            for solid_id, (tet_v, tet_t) in self._tet_data.items():
                offset = self._tet_vertex_offsets.get(solid_id, 0)

                for t in tet_t:
                    flat_tets.extend([
                        int(t[0]) + offset,
                        int(t[1]) + offset,
                        int(t[2]) + offset,
                        int(t[3]) + offset,
                    ])
                    tet_volume_ids.append(solid_id)
                    tet_physical_groups.append(material_pg_ids.get(solid_id, -1))

        # Build surface_volumes topology metadata
        # Convention: surface_volumes[i] = [fwd_vol, rev_vol]
        #   fwd_vol (index 0): volume whose outward normal = triangle normal
        #                      (face is FORWARD in this solid)
        #   rev_vol (index 1): volume whose outward normal = -triangle normal
        #                      (face is REVERSED in this solid)
        num_surfaces = max(mesh.face_to_surface_id.values()) if mesh.face_to_surface_id else 0
        surface_volumes_list = [[None, None] for _ in range(num_surfaces)]

        for fid, sid in mesh.face_to_surface_id.items():
            idx = sid - 1  # 0-based index
            for solid_id, face_ids in mesh.solid_faces.items():
                if fid not in face_ids:
                    continue
                vol_id = solid_id - 1  # 0-based volume ID
                is_reversed = mesh.face_solid_reversed.get(
                    (solid_id, fid), False
                )
                if is_reversed:
                    surface_volumes_list[idx][1] = vol_id
                else:
                    surface_volumes_list[idx][0] = vol_id

        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)

        # Precompute tet adjacency
        tet_adjacency = _compute_tet_adjacency(flat_tets)

        # Precompute triangle AABBs
        tri_aabbs = _compute_tri_aabbs(flat_vertices, flat_triangles)

        # Precompute tet AABBs
        tet_aabbs = _compute_tet_aabbs(flat_vertices, flat_tets)

        _export_arrow(
            path=str(path),
            vertices=flat_vertices,
            triangles=flat_triangles,
            triangle_surface_ids=tri_surface_ids,
            triangle_physical_groups=tri_physical_groups,
            tetrahedra=flat_tets,
            tet_volume_ids=tet_volume_ids,
            tet_physical_groups=tet_physical_groups,
            tet_adjacency=tet_adjacency,
            tri_aabbs=tri_aabbs,
            tet_aabbs=tet_aabbs,
            physical_groups_json=json.dumps(physical_groups),
            surface_volumes_json=json.dumps(surface_volumes_list),
        )

    def export_vtkhdf(self, path):
        """Export mesh to VTKHDF v2.1 UnstructuredGrid for ParaView.

        Args:
            path: Output file path (e.g. "model.vtkhdf").
        """
        if self._surface_mesh is None:
            raise RuntimeError("No surface mesh. Call mesh() first.")

        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)

        from .vtkhdf_writer import (
            write_surface_vtkhdf,
            write_mixed_vtkhdf,
        )

        mesh = self._surface_mesh

        # Build volume_id per triangle
        volume_ids = [-1] * len(mesh.triangles)
        for i, fid in enumerate(mesh.triangle_face_ids):
            for solid_id, face_ids in mesh.solid_faces.items():
                if fid in face_ids:
                    volume_ids[i] = solid_id
                    break

        # Build material label per triangle
        material_ids = [-1] * len(mesh.triangles)
        for i, fid in enumerate(mesh.triangle_face_ids):
            for solid_id, face_ids in mesh.solid_faces.items():
                if fid in face_ids:
                    tag_idx = solid_id - 1
                    material_ids[i] = tag_idx
                    break

        if self._tet_data:
            # Mixed mesh: tris + tets.
            # Tet vertices are already in mesh.vertices (conformal).
            all_verts = list(mesh.vertices)
            all_tris = mesh.triangles
            all_tets = []
            tet_volume_ids = []

            for solid_id, (tet_v, tet_t) in self._tet_data.items():
                offset = self._tet_vertex_offsets.get(solid_id, 0)
                for t in tet_t:
                    all_tets.append([
                        int(t[0]) + offset,
                        int(t[1]) + offset,
                        int(t[2]) + offset,
                        int(t[3]) + offset,
                    ])
                    tet_volume_ids.append(solid_id)

            # Cell data: volume_id for tris, then tets
            all_volume_ids = volume_ids + tet_volume_ids

            write_mixed_vtkhdf(
                str(path),
                all_verts,
                all_tris,
                all_tets,
                cell_data={"volume_id": all_volume_ids},
            )
        else:
            # Surface-only mesh
            write_surface_vtkhdf(
                str(path),
                mesh.vertices,
                mesh.triangles,
                cell_data={
                    "volume_id": volume_ids,
                    "material_id": material_ids,
                },
            )
