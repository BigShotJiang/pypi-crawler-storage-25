"""NetSight — Read-only multi-vendor network device query SDK.

The importable Python package is ``netsight`` (unchanged). The PyPI
distribution that ships this package is ``netsight-sdk``. Other
distributions — ``netsight-ops`` (runtime service platform) and
vendor packs such as ``netsight-pack-paloalto-firewall-xml`` —
depend on this core via standard pip dependencies.

The ``__version__`` string below is read from the installed
distribution metadata at import time, so it always matches what
``pip show netsight-sdk`` reports. A source-tree import without an
install (e.g. during bootstrap of a fresh checkout) falls back to
the compile-time default declared in ``pyproject.toml``.
"""

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__: str = _pkg_version("netsight-sdk")
except PackageNotFoundError:  # pragma: no cover — source tree without install
    __version__ = "1.1.1"

from netsight._features import DEV_EXTRAS_INSTALLED
from netsight.config import DeviceConfig
from netsight.data.models import DiffResult, QueryResult, Snapshot
from netsight.exceptions import (
    AuthenticationError,
    CommandDeniedError,
    ConfigValidationError,
    DeviceConnectionError,
    NetSightError,
    PluginNotFoundError,
    RateLimitError,
    ResponseSizeError,
)
from netsight.sdk.client import NetSight


def bootstrap() -> None:
    """Discover and register every installed NetSight pack.

    Idempotent public entry point for pack discovery. Call this from any
    embedding that does not go through :class:`~netsight.sdk.local.LocalBackend`,
    the dev MCP server, or the ``netsight`` CLI — typically a custom
    script that imports :class:`NetSight` and wants installed packs to be
    usable before the first device query.

    The underlying :meth:`netsight.packs.registry.PackRegistry.ensure_loaded`
    uses double-checked locking and the ``_loaded`` flag to guarantee that
    entry-point discovery runs exactly once per process, so calling
    ``bootstrap()`` multiple times (from multiple entry points) is cheap
    and safe. Per-pack registration errors are absorbed and surfaced via
    :meth:`PackRegistry.load_errors` rather than raised.
    """
    from netsight.packs import pack_registry

    pack_registry.ensure_loaded()


__all__ = [
    "__version__",
    "DEV_EXTRAS_INSTALLED",
    "NetSight",
    "DeviceConfig",
    "QueryResult",
    "Snapshot",
    "DiffResult",
    "AuthenticationError",
    "CommandDeniedError",
    "ConfigValidationError",
    "DeviceConnectionError",
    "NetSightError",
    "PluginNotFoundError",
    "RateLimitError",
    "ResponseSizeError",
    "bootstrap",
]
