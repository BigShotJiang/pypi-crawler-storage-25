"""Grep-based validation engine for pattern matching checks."""

from __future__ import annotations

import logging
import re

from netsight.standards.registry import Finding

logger = logging.getLogger(__name__)


class GrepEngine:
    """Validates code by searching for forbidden or required patterns."""

    def check(
        self, *, rule: dict, scope: dict, path: str | None, severity: str
    ) -> list[Finding]:
        check_type = rule.get("check", "")

        if check_type == "file-contains":
            return self._check_file_contains(rule=rule, scope=scope, severity=severity)
        elif check_type == "forbidden-patterns" or "patterns" in rule:
            return self._check_forbidden_patterns(rule=rule, scope=scope, severity=severity)
        else:
            logger.warning("Unknown grep check type: %s", check_type)
            return []

    def _check_file_contains(
        self, *, rule: dict, scope: dict, severity: str
    ) -> list[Finding]:
        """Check that every file in scope contains a required pattern."""
        findings: list[Finding] = []
        pattern = rule.get("pattern", "")
        message = rule.get("message", f"Missing required pattern: {pattern}")

        from netsight.mcp_dev.path_security import PROJECT_ROOT

        for glob_pattern in scope.get("paths", []):
            for py_file in PROJECT_ROOT.glob(glob_pattern):
                rel = str(py_file.relative_to(PROJECT_ROOT))
                if self._is_excluded(rel, scope):
                    continue
                content = py_file.read_text(encoding="utf-8")
                if pattern not in content:
                    findings.append(Finding(
                        file=rel, line=None, message=message, severity=severity,
                    ))

        return findings

    def _check_forbidden_patterns(
        self, *, rule: dict, scope: dict, severity: str
    ) -> list[Finding]:
        """Check that no file contains forbidden patterns."""
        findings: list[Finding] = []
        patterns = rule.get("patterns", [])
        exclude_patterns = set(rule.get("exclude_patterns", []))

        from netsight.mcp_dev.path_security import PROJECT_ROOT

        for glob_pattern in scope.get("paths", []):
            for py_file in PROJECT_ROOT.glob(glob_pattern):
                rel = str(py_file.relative_to(PROJECT_ROOT))
                if self._is_excluded(rel, scope):
                    continue

                content = py_file.read_text(encoding="utf-8")
                for line_no, line in enumerate(content.splitlines(), 1):
                    # Skip excluded patterns
                    if any(ep in line for ep in exclude_patterns):
                        continue

                    for pat_entry in patterns:
                        if isinstance(pat_entry, dict):
                            regex = pat_entry.get("pattern", "")
                            msg = pat_entry.get("message", f"Forbidden pattern: {regex}")
                        else:
                            regex = str(pat_entry)
                            msg = f"Forbidden pattern: {regex}"

                        try:
                            if re.search(regex, line):
                                findings.append(Finding(
                                    file=rel, line=line_no, message=msg, severity=severity,
                                ))
                        except re.error:
                            pass

        return findings

    @staticmethod
    def _is_excluded(rel_path: str, scope: dict) -> bool:
        exclude_paths = scope.get("exclude_paths", [])
        for ep in exclude_paths:
            clean = ep.rstrip("*").rstrip("/")
            if rel_path.startswith(clean):
                return True
        return False
