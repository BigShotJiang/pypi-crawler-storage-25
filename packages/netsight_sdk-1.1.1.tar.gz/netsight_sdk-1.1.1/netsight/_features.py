"""Feature flags derived from which optional extras are installed.

The ``[dev]`` extra (``pip install netsight-sdk[dev]``) pulls in testing,
linting, typing, and the dev MCP server runtime (watchdog). When those
packages are absent, dev-only functionality (standards engine, TOOLS
scripts, .mcp.json validation) is gracefully skipped rather than failed.

Usage::

    from netsight._features import DEV_EXTRAS_INSTALLED

    if DEV_EXTRAS_INSTALLED:
        ...  # dev-only logic
"""

from __future__ import annotations


def _probe_dev_extras() -> bool:
    """Return True when the key ``[dev]`` dependency is importable."""
    try:
        import watchdog  # noqa: F401
        return True
    except ImportError:
        return False


DEV_EXTRAS_INSTALLED: bool = _probe_dev_extras()
