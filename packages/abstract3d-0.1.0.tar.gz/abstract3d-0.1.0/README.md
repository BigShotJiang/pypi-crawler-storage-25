# Abstract3D

Abstract3D is the reserved Python package for AI-3D capabilities in the AbstractFramework
ecosystem.

The package is intentionally minimal today. It exists to reserve the `abstract3d` PyPI namespace
and provide a stable home for future 3D-related work that fits alongside `abstractframework`,
`abstractcore`, and `abstractgateway`.

Current scope:

- no runtime dependencies
- no public API yet
- namespace reservation only

The broader name is deliberate: it can cover meshes, scenes, point clouds, and other spatial
3D workflows without forcing `abstractvision` or `abstractvideo` to carry the full scope.
