"""Abstract3D namespace package.

This distribution intentionally stays minimal until 3D capabilities are added.
"""

__all__ = []
