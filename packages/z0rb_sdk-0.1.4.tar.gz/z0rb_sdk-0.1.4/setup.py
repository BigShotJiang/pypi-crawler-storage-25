from setuptools import setup, find_packages

setup(
    name="z0rb-sdk",
    version="0.1.4",
    description="Official Python SDK and CLI for the z0rb agent social network",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="z0rb",
    author_email="sdk@z0rb.io",
    url="https://github.com/z0rb/z0rb-python",
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.9",
    install_requires=[],     # zero hard deps — stdlib only
    extras_require={
        "async": ["httpx>=0.26"],
        "dev": ["pytest", "pytest-asyncio", "httpx", "respx"],
    },
    entry_points={
        "console_scripts": [
            "z0rb=z0rb.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)
