"""
fawp_index.state — FAWPState enum and zone classification (v4.0.0)

Replaces bare bool fawp_found with a proper five-state machine:

    OK          I_steer high, I_pred normal — no anomaly
    APPROACHING I_steer ≤ αA (Practical Steering Wall) — early warning
    FAWP        ODW detected — steering gone, prediction persists
    GHOST       I_pred > ε AND I_steer < αA — pred survives, steering gone (SPHERE_36 §3.1)
    MIRAGE      Display readout coherent, true readout integrity failed (SPHERE_36 §3.2)

Zone strings map to dashboard colours:
    GREEN   — OK
    YELLOW  — APPROACHING
    RED     — FAWP
    PURPLE  — GHOST
    BLACK   — MIRAGE  (most dangerous)
"""
from __future__ import annotations
from enum import Enum


class FAWPState(Enum):
    """Five-state operational classification for a FAWP scan result."""
    OK          = "OK"
    APPROACHING = "APPROACHING"
    FAWP        = "FAWP"
    GHOST       = "GHOST"
    MIRAGE      = "MIRAGE"

    # ── Convenience properties ────────────────────────────────────────────────
    @property
    def zone(self) -> str:
        """Dashboard zone colour string."""
        return {
            "OK":          "GREEN",
            "APPROACHING": "YELLOW",
            "FAWP":        "RED",
            "GHOST":       "PURPLE",
            "MIRAGE":      "BLACK",
        }[self.value]

    @property
    def severity(self) -> int:
        """Numeric severity 0–4 (higher = worse)."""
        return {"OK": 0, "APPROACHING": 1, "FAWP": 2, "GHOST": 3, "MIRAGE": 4}[self.value]

    @property
    def emoji(self) -> str:
        return {"OK": "✅", "APPROACHING": "🟡", "FAWP": "🔴",
                "GHOST": "👻", "MIRAGE": "🪞"}[self.value]

    @property
    def is_anomalous(self) -> bool:
        return self != FAWPState.OK

    @property
    def requires_intervention(self) -> bool:
        return self.severity >= 2


def classify_state(
    fawp_found: bool,
    steer_mi: float,
    pred_mi: float,
    epsilon: float = 0.01,
    alpha_a: float = 0.007297,
    g_read: float | None = None,
    g_read_threshold: float = 0.5,
) -> FAWPState:
    """
    Classify a scan result into a FAWPState.

    Parameters
    ----------
    fawp_found  : bool   — ODW detected by the FAWP detector
    steer_mi    : float  — current steering MI (I_steer at relevant τ)
    pred_mi     : float  — current predictive MI (I_pred at relevant τ)
    epsilon     : float  — detectability threshold
    alpha_a     : float  — Practical Steering Wall (SPHERE_23 constant)
    g_read      : float  — Readout Integrity Gap G_read (None if unknown)
    g_read_threshold : float — G_read above which Mirage is flagged
    """
    # Mirage: display readout coherent while true readout integrity failed
    if g_read is not None and g_read >= g_read_threshold:
        return FAWPState.MIRAGE

    # Ghost Zone: prediction detectable, steering below αA (SPHERE_36 §3.1)
    if pred_mi > epsilon and steer_mi <= alpha_a:
        return FAWPState.GHOST

    # FAWP: full ODW detected
    if fawp_found:
        return FAWPState.FAWP

    # Approaching: steering crossing Practical Steering Wall
    if steer_mi <= alpha_a:
        return FAWPState.APPROACHING

    return FAWPState.OK
