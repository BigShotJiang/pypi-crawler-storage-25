"""
fawp_index.odi — Operational Decoupling Index (ODI) scalar (v4.0.0)

Compresses the full leverage-gap picture into one number:

    Z_P(τ) = max(0,  (P(τ) − μ₀(τ)) / (σ₀(τ) + 1e-12) )

    ODI = max_τ { Z_P(τ) · [S(τ) ≤ ε] }

Activates only when:
  1. Prediction exceeds the null baseline (null-corrected)
  2. Steering is at or below the detectability threshold ε
  3. The ratio is sharp (Z_P high)

ODI = 0      → no decoupling detected
ODI ∈ (0,1]  → mild decoupling
ODI > 1      → significant FAWP signal
ODI > 2      → strong / flagship-level FAWP (E8 reference ≈ 2.23)

References: E8 paper §8 Operational Decoupling Index.
"""
from __future__ import annotations
import numpy as np
from typing import Sequence


def compute_odi(
    tau: Sequence[int | float],
    pred_mi: Sequence[float],
    steer_mi: Sequence[float],
    null_pred_mean: Sequence[float] | None = None,
    null_pred_std: Sequence[float] | None = None,
    epsilon: float = 0.01,
    alpha_a: float = 0.007297,
) -> tuple[float, int | None]:
    """
    Compute the Operational Decoupling Index.

    Parameters
    ----------
    tau           : delay array
    pred_mi       : corrected predictive MI at each τ
    steer_mi      : corrected steering MI at each τ
    null_pred_mean: null distribution mean for pred_mi (per τ). If None, uses 0.
    null_pred_std : null distribution std for pred_mi (per τ). If None, uses 1.
    epsilon       : steering detectability floor
    alpha_a       : Practical Steering Wall constant (αA)

    Returns
    -------
    odi     : float — the ODI scalar
    odi_tau : int or None — τ at which ODI peaks
    """
    pred_mi  = np.asarray(pred_mi,  dtype=float)
    steer_mi = np.asarray(steer_mi, dtype=float)
    tau_arr  = np.asarray(tau,      dtype=float)

    mu0  = np.zeros_like(pred_mi)  if null_pred_mean is None else np.asarray(null_pred_mean, dtype=float)
    sig0 = np.ones_like(pred_mi)   if null_pred_std  is None else np.asarray(null_pred_std,  dtype=float)

    # Z_P: null-normalised predictive score
    z_p = np.maximum(0.0, (pred_mi - mu0) / (sig0 + 1e-12))

    # ODI active only where steering ≤ ε (operationally absent)
    active = steer_mi <= epsilon
    odi_arr = z_p * active.astype(float)

    if odi_arr.max() == 0:
        return 0.0, None

    peak_idx = int(np.argmax(odi_arr))
    return float(odi_arr[peak_idx]), int(tau_arr[peak_idx])


def odi_from_odw_result(odw_result) -> tuple[float, int | None]:
    """
    Convenience wrapper: compute ODI from an ODWResult object.
    Falls back to peak_gap_bits if raw arrays unavailable.
    """
    pred_mi  = getattr(odw_result, "pred_mi",  None)
    steer_mi = getattr(odw_result, "steer_mi", None)
    tau      = getattr(odw_result, "tau",      None)

    if pred_mi is None or steer_mi is None or tau is None:
        # Fallback: use peak_gap_bits as a proxy
        pgb = float(getattr(odw_result, "peak_gap_bits", 0) or 0)
        pgt = getattr(odw_result, "peak_gap_tau", None)
        return pgb, pgt

    return compute_odi(tau, pred_mi, steer_mi)


__all__ = ["compute_odi", "odi_from_odw_result"]
