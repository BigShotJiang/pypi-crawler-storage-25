"""
fawp_index.compat — v3 compatibility shim (v4.0.0)

Provides backward-compatible wrappers so v3.x code continues to work
without modification after upgrading to v4.0.0.

Usage
-----
    # v3 code: result.fawp_found (bool) still works
    # v4 code: result.state (FAWPState) is the canonical field

    from fawp_index.compat import v3_result, ensure_v3_fields
"""
from __future__ import annotations
from typing import Any


def ensure_v3_fields(result: Any) -> Any:
    """
    Ensure a v4 result object exposes v3-compatible fields.

    Adds `fawp_found` (bool) as a derived property if only `state` is present.
    Safe to call on v3 results — it is a no-op if fields already exist.
    """
    if not hasattr(result, "fawp_found") and hasattr(result, "state"):
        from fawp_index.state import FAWPState
        result.fawp_found = result.state in (
            FAWPState.FAWP, FAWPState.GHOST, FAWPState.MIRAGE
        )
    if not hasattr(result, "peak_gap_bits") and hasattr(result, "odi"):
        result.peak_gap_bits = result.odi
    return result


def v3_result(result: Any) -> Any:
    """
    Wrap a v4 result so all v3 attribute access works unchanged.

    Returns the same object with v3 aliases attached — does not copy.
    """
    return ensure_v3_fields(result)


class V3ResultProxy:
    """
    Proxy that exposes v3 field names on top of a v4 result object.

    Usage::

        from fawp_index.compat import V3ResultProxy
        safe = V3ResultProxy(v4_result)
        safe.fawp_found   # bool (derived from state)
        safe.peak_gap_bits  # float (may be ODI in v4)
    """
    __slots__ = ("_inner",)

    def __init__(self, inner: Any) -> None:
        object.__setattr__(self, "_inner", inner)

    def __getattr__(self, name: str) -> Any:
        inner = object.__getattribute__(self, "_inner")
        # v3→v4 field mappings
        if name == "fawp_found":
            from fawp_index.state import FAWPState
            state = getattr(inner, "state", None)
            if state is not None:
                return state in (FAWPState.FAWP, FAWPState.GHOST, FAWPState.MIRAGE)
            return getattr(inner, "fawp_found", False)
        if name == "peak_gap_bits":
            return getattr(inner, "peak_gap_bits", None) or getattr(inner, "odi", 0.0)
        return getattr(inner, name)

    def __repr__(self) -> str:
        return f"V3ResultProxy({object.__getattribute__(self, '_inner')!r})"


# Re-export for convenience
__all__ = ["ensure_v3_fields", "v3_result", "V3ResultProxy"]
