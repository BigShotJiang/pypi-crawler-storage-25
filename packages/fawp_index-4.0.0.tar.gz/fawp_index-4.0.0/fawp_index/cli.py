"""
fawp-index — Command Line Interface
====================================

Subcommands
-----------
  detect       Run FAWP detector on a CSV file
  market       Rolling FAWP scan on a price CSV
  watchlist    Scan multiple CSVs and rank by FAWP signal
  significance Bootstrap significance test on a detector result
  benchmarks   Run the built-in benchmark suite
  version      Print version and exit

Quick start
-----------
  fawp-index detect   data.csv --state price --action trade
  fawp-index market   prices.csv --close Close --volume Volume
  fawp-index watchlist spy.csv qqq.csv gld.csv --labels SPY QQQ GLD
  fawp-index significance data.csv --state price --action trade
  fawp-index benchmarks
  fawp-index version
"""

import argparse
import sys
from pathlib import Path

from fawp_index import __version__ as _VERSION


def _header():
    print(f"\nfawp-index v{_VERSION} | Clayton (2026) | doi:10.5281/zenodo.18673949")
    print("=" * 60)


def _load_price_df(csv_path, close_col, date_col=None):
    import pandas as pd
    df = pd.read_csv(csv_path)
    if date_col and date_col in df.columns:
        df[date_col] = pd.to_datetime(df[date_col])
        df = df.set_index(date_col)
    else:
        for col in df.columns:
            if "date" in col.lower() or "time" in col.lower():
                df[col] = pd.to_datetime(df[col])
                df = df.set_index(col)
                break
        else:
            df.index = pd.to_datetime(df.index)
    if close_col not in df.columns:
        matches = [c for c in df.columns if c.lower() == close_col.lower()]
        if not matches:
            print(f"ERROR: column '{close_col}' not found. Available: {list(df.columns)}")
            sys.exit(1)
        df = df.rename(columns={matches[0]: close_col})
    return df


def _write_detect_output(result, path):
    p = Path(path)
    suffix = p.suffix.lower()
    if suffix == ".json":
        import json
        d = {
            "fawp_found": bool(result.in_fawp.any()),
            "tau_h": int(result.tau_h) if result.tau_h is not None else None,
            "peak_alpha": float(result.peak_alpha),
            "peak_tau": int(result.peak_tau) if result.peak_tau is not None else None,
        }
        p.write_text(json.dumps(d, indent=2))
    elif suffix == ".csv":
        import pandas as pd
        pd.DataFrame({
            "tau": result.tau,
            "pred_mi": result.pred_mi_raw,
            "steer_mi": result.steer_mi_raw,
            "gap": result.pred_mi_raw - result.steer_mi_raw,
            "fawp": result.in_fawp,
        }).to_csv(p, index=False)
    else:
        print(f"WARNING: unsupported format '{suffix}' — use .json or .csv")
        return
    print(f"Saved → {p}")


def cmd_detect(args):
    _header()
    print(f"Command : detect  |  {args.csv}")
    simple = bool(args.state and args.action)
    full   = bool(args.pred and args.future and args.action and args.obs)
    if not simple and not full:
        print("ERROR: --state+--action or --pred+--future+--action+--obs required")
        sys.exit(1)
    try:
        if simple:
            from fawp_index.io.csv_loader import load_csv_simple
            data = load_csv_simple(args.csv, state_col=args.state, action_col=args.action, delta_pred=args.delta)
        else:
            from fawp_index.io.csv_loader import load_csv
            data = load_csv(args.csv, pred_col=args.pred, future_col=args.future, action_col=args.action, obs_col=args.obs, delta_pred=args.delta)
    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)
    print(f"Rows {len(data.pred_series):,}  |  Delta={args.delta}  |  tau={args.tau_min}-{args.tau_max}")
    from fawp_index.core.alpha_index import FAWPAlphaIndex
    result = FAWPAlphaIndex(eta=args.eta, epsilon=args.epsilon, m_persist=args.persist, n_null=args.n_null).compute(
        pred_series=data.pred_series, future_series=data.future_series,
        action_series=data.action_series, obs_series=data.obs_series,
        tau_grid=list(range(args.tau_min, args.tau_max + 1)), verbose=args.verbose,
    )
    print("\n" + result.summary())
    print(f"\n{'tau':>4} {'Pred MI':>10} {'Steer MI':>10} {'Gap':>10} {'FAWP':>6}")
    print("-" * 46)
    for i, tau in enumerate(result.tau):
        gap = result.pred_mi_raw[i] - result.steer_mi_raw[i]
        flag = "<- ok" if result.in_fawp[i] else ""
        print(f"{tau:>4} {result.pred_mi_raw[i]:>10.4f} {result.steer_mi_raw[i]:>10.4f} {gap:>10.4f}  {flag}")
    if args.out:
        _write_detect_output(result, args.out)
    if args.plot or args.save:
        try:
            from fawp_index.viz.plots import plot_leverage_gap
            plot_leverage_gap(result, save_path=args.save, show=args.plot)
        except ImportError:
            print("WARNING: matplotlib not installed")
    status = "FAWP DETECTED" if result.in_fawp.any() else "No FAWP detected"
    print(f"\n{status}")


def cmd_market(args):
    _header()
    print(f"Command : market  |  {args.csv}")
    df = _load_price_df(args.csv, args.close, args.date_col)
    vol = args.volume if (args.volume and args.volume in df.columns) else None
    print(f"{len(df):,} rows  {df.index[0].date()} -> {df.index[-1].date()}  |  window={args.window} step={args.step} tau_max={args.tau_max}")
    from fawp_index.market import scan_fawp_market
    scan = scan_fawp_market(df, ticker=Path(args.csv).stem.upper(),
        close_col=args.close, volume_col=vol, window=args.window, step=args.step,
        tau_max=args.tau_max, n_null=args.n_null, verbose=True)
    print("\n" + scan.summary())
    if args.out:
        p = Path(args.out)
        fmt = p.suffix.lower().lstrip(".")
        writer = {"html": scan.to_html, "json": scan.to_json, "csv": scan.to_csv}.get(fmt)
        if writer:
            writer(p)
        else:
            print("WARNING: unsupported format")
        print(f"Saved -> {p}")
    if args.plot:
        try:
            scan.plot(prices=df[args.close])
        except ImportError:
            print("WARNING: matplotlib not installed")


def cmd_watchlist(args):
    import pandas as pd  # noqa: F401 — ensures pandas is available for _load_price_df
    _header()
    print("Command : watchlist")
    labels = args.labels or [Path(f).stem.upper() for f in args.csvs]
    if len(labels) != len(args.csvs):
        print("ERROR: --labels count must match CSV count")
        sys.exit(1)
    dfs = {label: _load_price_df(f, args.close, args.date_col) for label, f in zip(labels, args.csvs)}
    for label, df in dfs.items():
        print(f"  {label}: {len(df):,} rows")
    tf_list = [tf.strip() for tf in args.timeframes.split(",")]
    from fawp_index.watchlist import scan_watchlist
    result = scan_watchlist(dfs, timeframes=tf_list, window=args.window, step=args.step,
        tau_max=args.tau_max, n_null=args.n_null, verbose=True)
    print("\n" + result.summary(n=30))
    if args.out:
        p = Path(args.out)
        fmt = p.suffix.lower().lstrip(".")
        writer = {"html": result.to_html, "json": result.to_json, "csv": result.to_csv}.get(fmt)
        if writer:
            writer(p)
        else:
            print("WARNING: unsupported format")
        print(f"Saved -> {p}")
    ranked = result.rank_by(args.rank_by)
    print(f"\nTop {min(args.top, len(ranked))} by {args.rank_by}:")
    for a in ranked[:args.top]:
        flag = "FAWP" if a.regime_active else "    "
        print(f"  [{flag}]  {a.ticker:<10} [{a.timeframe}]  score={a.latest_score:.4f}  gap={a.peak_gap_bits:.4f}b  age={a.signal_age_days}d")


def cmd_significance(args):
    _header()
    print(f"Command : significance  |  {args.csv}")
    simple = bool(args.state and args.action)
    full   = bool(args.pred and args.future and args.action and args.obs)
    if not simple and not full:
        print("ERROR: --state+--action or --pred+--future+--action+--obs required")
        sys.exit(1)
    try:
        if simple:
            from fawp_index.io.csv_loader import load_csv_simple
            data = load_csv_simple(args.csv, state_col=args.state, action_col=args.action, delta_pred=args.delta)
        else:
            from fawp_index.io.csv_loader import load_csv
            data = load_csv(args.csv, pred_col=args.pred, future_col=args.future, action_col=args.action, obs_col=args.obs, delta_pred=args.delta)
    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)
    from fawp_index.core.alpha_index import FAWPAlphaIndex
    from fawp_index.detection.odw import ODWDetector
    from fawp_index import fawp_significance
    result = FAWPAlphaIndex(n_null=50).compute(
        pred_series=data.pred_series, future_series=data.future_series,
        action_series=data.action_series, obs_series=data.obs_series,
        tau_grid=list(range(1, args.tau_max + 1)),
    )
    odw = ODWDetector().detect(tau=result.tau, pred_corr=result.pred_mi_raw,
        steer_corr=result.steer_mi_raw,
        fail_rate=result.failure_rate if hasattr(result, "failure_rate") else None)
    sig = fawp_significance(odw, n_bootstrap=args.n_bootstrap, alpha=args.alpha)
    print(sig.summary())
    if args.out:
        p = Path(args.out)
        fmt = p.suffix.lower().lstrip(".")
        writer = {"html": sig.to_html, "json": sig.to_json}.get(fmt)
        if writer:
            writer(p)
        else:
            print("WARNING: use .html or .json")
        print(f"Saved -> {p}")


def cmd_benchmarks(args):
    _header()
    include_weather = getattr(args, "weather", False)
    label = "finance + climate" if include_weather else "finance"
    print(f"Command : benchmarks ({label})\n")
    from fawp_index import run_benchmarks
    suite = run_benchmarks(include_weather=include_weather)
    print(suite.summary())
    if include_weather:
        print("\nClimate benchmarks (E9-calibrated):")
        for c in suite.cases:
            if getattr(c, "domain", "finance") == "weather":
                status = "PASS ✓" if c.passed else "FAIL ✗"
                fawp   = "FAWP=True " if c.odw_result.fawp_found else "FAWP=False"
                exp    = "expected" if c.odw_result.fawp_found == c.expected_fawp else "UNEXPECTED"
                print(f"  {status}  {c.name:<28} {fawp}  ({exp})")
                print(f"         {c.description[:80]}...")
                print()
    if args.verify:
        try:
            suite.verify_all()
            print("\nAll benchmark assertions pass.")
        except Exception as e:
            print(f"\nFailure: {e}")
            sys.exit(1)
    if args.out:
        p = Path(args.out)
        fmt = p.suffix.lower().lstrip(".")
        writer = {"html": suite.to_html, "json": suite.to_json}.get(fmt)
        if writer:
            writer(p)
        else:
            print("WARNING: use .html or .json")
        print(f"Saved -> {p}")


def cmd_version(_args):
    print(f"fawp-index {_VERSION}")
    print("Ralph Clayton (2026)")
    print("doi:10.5281/zenodo.18673949")
    print("https://github.com/DrRalphClayton/fawp-index")


def _build_parser():
    parser = argparse.ArgumentParser(
        prog="fawp-index",
        description="FAWP Alpha Index — detect when prediction persists after steering has collapsed.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  fawp-index detect   data.csv --state price --action trade\n"
            "  fawp-index market   prices.csv --close Close --out report.html\n"
            "  fawp-index watchlist spy.csv qqq.csv --labels SPY QQQ --out wl.html\n"
            "  fawp-index significance data.csv --state price --action trade\n"
            "  fawp-index benchmarks --verify\n"
            "  fawp-index version\n"
            "  fawp-index cite\n"
            "  fawp-index watch --tickers SPY,QQQ --email you@email.com\n"
            "  fawp-index report --data scan.json --out report.pdf\n"
            "  fawp-index forecast --forecast fc.csv --obs obs.csv\n"
            "  fawp-index timing\n"
            "  fawp-index verify\n"
            "  fawp-index grid\n"
        ),
    )
    parser.add_argument("--version", action="version", version=f"fawp-index {_VERSION}")
    sub = parser.add_subparsers(dest="command", metavar="<command>")
    sub.required = True

    # detect
    p = sub.add_parser("detect", help="Run FAWP detector on a CSV")
    p.add_argument("csv")
    p.add_argument("--state")
    p.add_argument("--action")
    p.add_argument("--pred")
    p.add_argument("--future")
    p.add_argument("--obs")
    p.add_argument("--delta", type=int, default=20)
    p.add_argument("--tau-max", type=int, default=40)
    p.add_argument("--tau-min", type=int, default=1)
    p.add_argument("--eta", type=float, default=1e-4)
    p.add_argument("--epsilon", type=float, default=1e-4)
    p.add_argument("--n-null", type=int, default=200)
    p.add_argument("--persist", type=int, default=5)
    p.add_argument("--plot", action="store_true")
    p.add_argument("--save")
    p.add_argument("--out")
    p.add_argument("--verbose", action="store_true")
    p.set_defaults(func=cmd_detect)

    # market
    p = sub.add_parser("market", help="Rolling FAWP market scan on a price CSV")
    p.add_argument("csv")
    p.add_argument("--close", default="Close")
    p.add_argument("--volume", default="Volume")
    p.add_argument("--date-col", default=None)
    p.add_argument("--window", type=int, default=252)
    p.add_argument("--step", type=int, default=5)
    p.add_argument("--tau-max", type=int, default=40)
    p.add_argument("--n-null", type=int, default=0)
    p.add_argument("--out")
    p.add_argument("--plot", action="store_true")
    p.set_defaults(func=cmd_market)

    # watchlist
    p = sub.add_parser("watchlist", help="Scan multiple CSVs, rank by FAWP signal")
    p.add_argument("csvs", nargs="+")
    p.add_argument("--labels", nargs="+")
    p.add_argument("--close", default="Close")
    p.add_argument("--volume", default="Volume")
    p.add_argument("--date-col", default=None)
    p.add_argument("--timeframes", default="1d")
    p.add_argument("--window", type=int, default=252)
    p.add_argument("--step", type=int, default=5)
    p.add_argument("--tau-max", type=int, default=40)
    p.add_argument("--n-null", type=int, default=0)
    p.add_argument("--rank-by", default="score", choices=["score", "gap", "entry", "persistence", "freshness"])
    p.add_argument("--top", type=int, default=10)
    p.add_argument("--out")
    p.set_defaults(func=cmd_watchlist)

    # significance
    p = sub.add_parser("significance", help="Bootstrap significance test")
    p.add_argument("csv")
    p.add_argument("--state")
    p.add_argument("--action")
    p.add_argument("--pred")
    p.add_argument("--future")
    p.add_argument("--obs")
    p.add_argument("--delta", type=int, default=20)
    p.add_argument("--tau-max", type=int, default=40)
    p.add_argument("--n-bootstrap", type=int, default=200)
    p.add_argument("--alpha", type=float, default=0.05)
    p.add_argument("--out")
    p.set_defaults(func=cmd_significance)

    # benchmarks
    p = sub.add_parser("benchmarks", help="Run built-in benchmark suite")
    p.add_argument("--verify",  action="store_true",
                   help="Assert all expected_fawp values match")
    p.add_argument("--weather", action="store_true",
                   help="Include climate benchmarks (hurricane, drought, precip)")
    p.add_argument("--out", help="Save results to .html or .json")
    p.set_defaults(func=cmd_benchmarks)

    # version
    p = sub.add_parser("version", help="Print version and exit")
    p.set_defaults(func=cmd_version)

    # cite
    p = sub.add_parser("cite", help="Print citations (bibtex/apa/mla) for fawp-index")
    p.add_argument("--format", default="bibtex", choices=["bibtex","apa","mla"])
    p.add_argument("--live", action="store_true", help="Fetch live metadata from Zenodo")
    p.set_defaults(func=cmd_cite)

    # timing
    p = sub.add_parser("timing", help="Print E9.7 detector timing results from the paper")
    p.set_defaults(func=cmd_timing)

    # steering profile
    p = sub.add_parser("steering", help="Steering decay profile with SPHERE_23 αA/α²A thresholds")
    p.add_argument("--ticker",  required=True)
    p.add_argument("--period",  default="2y")
    p.add_argument("--epsilon", type=float, default=0.01)
    p.add_argument("--n-null",  type=int,   default=50,   dest="n_null")
    p.add_argument("--plot",    action="store_true")
    p.set_defaults(func=cmd_steering)

    # forecast
    p = sub.add_parser("project", help="Project FAWP trajectory (steering decay → tau_f estimate)")
    p.add_argument("--ticker",  required=True)
    p.add_argument("--period",  default="2y")
    p.add_argument("--epsilon", type=float, default=0.01)
    p.add_argument("--n-null",  type=int,   default=50, dest="n_null")
    p.set_defaults(func=cmd_project)

    # scan one-liner
    p = sub.add_parser("scan", help="One-liner FAWP scan for a single ticker")
    p.add_argument("--ticker",  required=True,              help="Ticker symbol (e.g. SPY)")
    p.add_argument("--period",  default="2y",               help="yfinance period (1y, 2y, …)")
    p.add_argument("--epsilon", type=float, default=0.01)
    p.add_argument("--n-null",  type=int,   default=50,     dest="n_null")
    p.add_argument("--out",     default=None,               help="Save result JSON to file")
    p.set_defaults(func=cmd_scan)

    # verify
    p = sub.add_parser("verify", help="Run calibration self-checks against SPHERE/E9 constants")
    p.add_argument("--sphere23", action="store_true",
                   help="Run live E11-1 simulation vs SPHERE_23 reference values")
    p.add_argument("--e8", action="store_true",
                   help="Run E8 end-to-end integration check (exits 0=pass, 1=fail)")
    p.add_argument("--seed",      type=int, default=42)
    p.add_argument("--tolerance", type=int, default=5,
                   help="Allowed horizon deviation in delay steps")
    p.set_defaults(func=cmd_verify)

    # grid
    # calibrate
    p = sub.add_parser("calibrate", help="Re-derive SPHERE-16 constants from simulation")
    p.add_argument("--a",        type=float, default=1.02,  help="AR(1) gain")
    p.add_argument("--K",        type=float, default=0.8,   help="Controller gain")
    p.add_argument("--delta",    type=int,   default=20,    help="Observation delay Δ")
    p.add_argument("--n-trials", type=int,   default=200,   dest="n_trials")
    p.add_argument("--n-null",   type=int,   default=50,    dest="n_null")
    p.add_argument("--tau-max",  type=int,   default=40,    dest="tau_max")
    p.add_argument("--seed",     type=int,   default=42)
    p.add_argument("--out",      default=None)
    p.set_defaults(func=cmd_calibrate)

    # agency sweep
    p = sub.add_parser("agency", help="Sweep agency horizon over parameter space (VTM Eq. 15-16)")
    p.add_argument("--mode",    default="alpha", choices=["alpha","P","surface"],
                   help="Sweep variable: alpha (noise growth) or P (signal power)")
    p.add_argument("--P",       type=float, default=1.0,  help="Action variance P (fixed in alpha mode)")
    p.add_argument("--alpha",   type=float, default=0.01, help="Noise growth α (fixed in P mode)")
    p.add_argument("--sigma0",  type=float, default=0.0001, help="Baseline noise σ²₀")
    p.add_argument("--epsilon", type=float, default=0.01,   help="Detectability threshold ε (bits)")
    p.add_argument("--a-min",   type=float, default=1e-3,   dest="a_min")
    p.add_argument("--a-max",   type=float, default=1e-1,   dest="a_max")
    p.add_argument("--P-min",   type=float, default=0.01,   dest="P_min")
    p.add_argument("--P-max",   type=float, default=100.0,  dest="P_max")
    p.add_argument("--n-steps", type=int,   default=20,     dest="n_steps")
    p.add_argument("--no-plot", action="store_true",        dest="no_plot")
    p.add_argument("--out",     default=None)
    p.set_defaults(func=cmd_agency)

    # leaderboard push/list
    lb_p = sub.add_parser("leaderboard", help="Push or list global FAWP leaderboard entries")
    lb_sub = lb_p.add_subparsers(dest="subcommand")
    # push
    lb_push = lb_sub.add_parser("push", help="Push a scan JSON to the global leaderboard")
    lb_push.add_argument("--data",  required=True, help="Path to FAWP result .json")
    lb_push.add_argument("--url",   default=None,  help="Supabase URL (or FAWP_SUPABASE_URL env)")
    lb_push.add_argument("--token", default=None,  help="Supabase token (or FAWP_SUPABASE_TOKEN env)")
    # list
    lb_list = lb_sub.add_parser("list", help="Show global leaderboard top entries")
    lb_list.add_argument("--top",   type=int, default=20)
    lb_list.add_argument("--url",   default=None)
    lb_list.add_argument("--token", default=None)
    lb_p.set_defaults(func=cmd_leaderboard)

    # changelog
    p = sub.add_parser("changelog", help="Print CHANGELOG entry for the installed version")
    p.add_argument("--version", default=None, help="Show entry for this version (default: installed)")
    p.set_defaults(func=cmd_changelog)

    # triple-horizon sweep
    p = sub.add_parser("triple-horizon-sweep",
                       help="E11-2 portability sweep over (a,K) grid")
    p.add_argument("--a-grid",            default="1.01,1.02,1.03",  dest="a_grid")
    p.add_argument("--K-grid",            default="0.4,0.8,1.2",     dest="K_grid")
    p.add_argument("--delta",             type=int,   default=20)
    p.add_argument("--readout-tau-scale", type=float, default=25.0,  dest="readout_tau_scale")
    p.add_argument("--epsilon",           type=float, default=0.01)
    p.add_argument("--tau-max",           type=int,   default=50,    dest="tau_max")
    p.add_argument("--seed",              type=int,   default=42)
    p.add_argument("--out",               default=None)
    p.set_defaults(func=cmd_triple_horizon_sweep)

    # triple-horizon
    p = sub.add_parser("triple-horizon", help="E11-1 Triple Horizon benchmark (SPHERE_23)")
    p.add_argument("--a",                type=float, default=1.02)
    p.add_argument("--K",                type=float, default=0.8)
    p.add_argument("--delta",            type=int,   default=20)
    p.add_argument("--readout-tau-scale",type=float, default=25.0, dest="readout_tau_scale")
    p.add_argument("--shield",           type=float, default=0.0)
    p.add_argument("--x-fail",           type=float, default=500.0, dest="x_fail")
    p.add_argument("--epsilon",          type=float, default=0.01)
    p.add_argument("--tau-max",          type=int,   default=50,  dest="tau_max")
    p.add_argument("--n-null",           type=int,   default=30,  dest="n_null")
    p.add_argument("--seed",             type=int,   default=42)
    p.add_argument("--out",              default=None)
    p.set_defaults(func=cmd_triple_horizon)

    # latent (LERI)
    p = sub.add_parser("latent", help="LERI: Latent Environmental Residual Inference access horizon")
    p.add_argument("--P",        type=float, default=1.0,   help="Signal power (action variance)")
    p.add_argument("--sigma0",   type=float, default=1.0,   help="Baseline noise σ²₀")
    p.add_argument("--alpha",    type=float, default=0.25,  help="Noise growth rate α")
    p.add_argument("--epsilon",  type=float, default=0.01,  help="Detectability threshold ε (bits)")
    p.add_argument("--beta",     type=float, default=0.99,  help="Null quantile β")
    p.add_argument("--persist",  type=int,   default=5,     help="Persistence gate m steps")
    p.add_argument("--tau-max",  type=int,   default=400,   dest="tau_max")
    p.add_argument("--n-null",   type=int,   default=50,    dest="n_null")
    p.add_argument("--seed",     type=int,   default=42)
    p.add_argument("--out",      default=None)
    p.set_defaults(func=cmd_latent)

    # diagnose
    p = sub.add_parser("diagnose", help="Plain-English diagnosis of a FAWP result JSON")
    p.add_argument("--data", required=True, help="Path to result .json file")
    p.set_defaults(func=cmd_diagnose)

    # sweep
    p = sub.add_parser("sweep", help="Sweep parameters and show FAWP detection sensitivity")
    p.add_argument("--data",    required=True, help="Path to scan JSON with pred_mi/steer_mi")
    p.add_argument("--epsilon", default="0.005,0.01,0.02",
                   help="Comma-separated epsilon values (default: 0.005,0.01,0.02)")
    p.add_argument("--tau-max", default="20,30,40", dest="tau_max",
                   help="Comma-separated tau_max values (default: 20,30,40)")
    p.add_argument("--n-null",  default="0,50,100", dest="n_null",
                   help="Comma-separated n_null values (default: 0,50,100)")
    p.add_argument("--out",     default=None)
    p.set_defaults(func=cmd_sweep)

    # export
    p = sub.add_parser("export", help="Export a FAWP result JSON to csv/html/pdf")
    p.add_argument("--data",   required=True, help="Path to result .json file")
    p.add_argument("--out",    default=None,  help="Output path (auto-detected from format)")
    p.add_argument("--format", default=None,  choices=["csv","html","pdf","parquet"],
                   help="Output format (default: inferred from --out extension)")
    p.add_argument("--title",  default=None)
    p.add_argument("--mode",   default="report", choices=["report","lab"])
    p.set_defaults(func=cmd_export)

    # compare
    p = sub.add_parser("compare", help="Compare FAWP signals for two assets or weather locations")
    p.add_argument("--mode",    default="finance", choices=["finance","weather"])
    # finance mode
    p.add_argument("--a",       default="SPY",  help="First ticker")
    p.add_argument("--b",       default="QQQ",  help="Second ticker")
    p.add_argument("--period",  default="2y")
    p.add_argument("--window",  type=int,   default=252)
    p.add_argument("--step",    type=int,   default=21)
    # weather mode
    p.add_argument("--lat-a",   type=float, default=51.5,  dest="lat_a")
    p.add_argument("--lon-a",   type=float, default=-0.1,  dest="lon_a")
    p.add_argument("--lat-b",   type=float, default=48.9,  dest="lat_b")
    p.add_argument("--lon-b",   type=float, default=2.4,   dest="lon_b")
    p.add_argument("--variable",default="temperature_2m")
    p.add_argument("--start",   default="2010-01-01")
    p.add_argument("--end",     default="2024-12-31")
    p.add_argument("--horizon", type=int,   default=7)
    # shared
    p.add_argument("--epsilon", type=float, default=0.01)
    p.add_argument("--n-null",  type=int,   default=50,   dest="n_null")
    p.add_argument("--out",     default=None)
    p.set_defaults(func=cmd_compare)

    # notebook
    p = sub.add_parser("notebook", help="Open the E9 replication notebook in Jupyter")
    p.add_argument("--lab", action="store_true", help="Open in JupyterLab instead of Jupyter Notebook")
    p.set_defaults(func=cmd_notebook)

    # demo-notebook: generate E8 Colab demo
    p = sub.add_parser("demo-notebook",
                       help="Generate E8 demo Jupyter notebook and optionally open Colab")
    p.add_argument("--out",  default="fawp_e8_demo.ipynb")
    p.add_argument("--open", action="store_true",
                   help="Open Colab in browser after generating")
    p.set_defaults(func=cmd_demo_notebook)

    # status
    p = sub.add_parser("status", help="Print live project status and calibration checks")
    p.add_argument("--all", dest="all_info", action="store_true",
                   help="Check PyPI for updates and show recent changelog")
    p.set_defaults(func=cmd_status)

    # backtest
    p = sub.add_parser("backtest", help="Run rolling FAWP scan and export CSV")
    p.add_argument("--ticker",  required=True)
    p.add_argument("--period",  default="5y")
    p.add_argument("--window",  type=int,   default=252)
    p.add_argument("--step",    type=int,   default=21)
    p.add_argument("--delta",   type=int,   default=20)
    p.add_argument("--tau-max", type=int,   default=40,   dest="tau_max")
    p.add_argument("--epsilon", type=float, default=0.01)
    p.add_argument("--n-null",  type=int,   default=50,   dest="n_null")
    p.add_argument("--out",     default=None)
    p.set_defaults(func=cmd_backtest)

    # watch
    p = sub.add_parser("watch", help="Run repeated scans and alert when FAWP fires")
    p.add_argument("--tickers",  required=True, help="Comma-separated tickers, e.g. SPY,QQQ,GLD")
    p.add_argument("--period",   default="2y",  help="Data period (default: 2y)")
    p.add_argument("--interval",  type=int, default=15,
                   help="Minutes between scans (default: 15)")
    p.add_argument("--alert-gap", type=float, default=0.05, dest="alert_gap",
                   help="Min gap bits to alert (default 0.05)")
    p.add_argument("--once",      action="store_true",
                   help="Run one scan then exit")
    p.add_argument("--email",    default=None, help="Email address for alerts")
    p.add_argument("--epsilon",  type=float, default=0.01)
    p.add_argument("--n-null",   type=int,   default=50,  dest="n_null")
    p.add_argument("--window",   type=int,   default=252)
    p.add_argument("--step",     type=int,   default=21)
    p.set_defaults(func=cmd_watch)

    # report
    p = sub.add_parser("report", help="Generate a PDF report from a FAWP result JSON")
    p.add_argument("--ticker",  default=None, help="Ticker to scan inline (skips --data requirement)")
    p.add_argument("--period",  default="2y")
    p.add_argument("--epsilon", type=float, default=0.01)
    p.add_argument("--n-null",  type=int, default=50, dest="n_null")
    p.add_argument("--data",   required=False, default=None, help="Path to result .json file (or use --ticker)")
    p.add_argument("--out",    default=None,  help="Output PDF path (default: <data>.pdf)")
    p.add_argument("--title",  default=None,  help="Report title")
    p.add_argument("--mode",   default="report", choices=["report","lab"])
    p.add_argument("--author", default="Ralph Clayton")
    p.add_argument("--doi",    default="10.5281/zenodo.18673949")
    p.set_defaults(func=cmd_report)

    # forecast
    p = sub.add_parser("forecast", help="Run FAWP detection on NWP forecast vs observation CSVs")
    p.add_argument("--forecast",     required=True, help="Path to forecast CSV")
    p.add_argument("--obs",          required=True, help="Path to observed CSV")
    p.add_argument("--variable",     default="temperature", help="Variable name (for labelling)")
    p.add_argument("--location",     default="uploaded",    help="Location label")
    p.add_argument("--forecast-col", default="forecast",    dest="forecast_col")
    p.add_argument("--obs-col",      default="observed",    dest="obs_col")
    p.add_argument("--date-col",     default="date",        dest="date_col")
    p.add_argument("--horizon",      type=int,   default=1)
    p.add_argument("--tau-max",      type=int,   default=40,  dest="tau_max")
    p.add_argument("--epsilon",      type=float, default=0.01)
    p.add_argument("--n-null",       type=int,   default=100, dest="n_null")
    p.add_argument("--out",          default=None, help="Save to .json or .csv")
    p.set_defaults(func=cmd_forecast)

    p = sub.add_parser("grid", help="Generate FAWP detection basin heatmap over (a, K) space")
    p.add_argument("--a-min",  type=float, default=1.00)
    p.add_argument("--a-max",  type=float, default=1.10)
    p.add_argument("--k-min",  type=float, default=0.60)
    p.add_argument("--k-max",  type=float, default=0.95)
    p.add_argument("--n",      type=int,   default=10, help="Grid points per axis")
    p.add_argument("--seeds",  type=int,   default=3,  help="Seeds per cell")
    p.add_argument("--out",    default="fawp_basin.csv")
    p.add_argument("--plot",   action="store_true", help="Save heatmap PNG alongside CSV")
    p.set_defaults(func=cmd_grid)


    # nonlinear-sweep (E11-5)
    p = sub.add_parser("nonlinear-sweep",
                       help="E11-5: Triple Horizon portability across nonlinear families")
    p.add_argument("--families", default="linear,cubic,coupled")
    p.add_argument("--seeds",   type=int, default=4)
    p.add_argument("--n",       type=int, default=600)
    p.add_argument("--tau-max", type=int, default=50, dest="tau_max")
    p.add_argument("--out",     default=None)
    p.set_defaults(func=cmd_nonlinear_sweep)

    # leri-shield (E-LERI-3)
    p = sub.add_parser("leri-shield",
                       help="E-LERI-3: Record gain shielding sweep")
    p.add_argument("--P",           type=float, default=1.0)
    p.add_argument("--sigma0",      type=float, default=1.0)
    p.add_argument("--alpha-noise", type=float, default=0.25, dest="alpha_noise")
    p.add_argument("--gains",       default="1.0,0.5,0.2,0.1,0.0")
    p.add_argument("--tau-max",     type=int, default=200, dest="tau_max")
    p.add_argument("--eps-score",   type=float, default=1e-4, dest="eps_score")
    p.add_argument("--seed",        type=int, default=42)
    p.add_argument("--out",         default=None)
    p.set_defaults(func=cmd_leri_shield)

    # reproduce
    p = sub.add_parser("reproduce",
                       help="Reproduce a published paper figure")
    p.add_argument("--experiment", required=True, help="e8 | leri-2")
    p.add_argument("--out", default=None)
    p.set_defaults(func=cmd_reproduce)

    # audit (THB-5 — v4.0.0)
    p = sub.add_parser("audit",
                       help="THB-5 Audit: 11-step control/alignment audit (SPHERE_36)")
    p.add_argument("--ticker",  required=True)
    p.add_argument("--period",  default="2y")
    p.add_argument("--epsilon", type=float, default=0.01)
    p.add_argument("--out",     default=None)
    p.set_defaults(func=cmd_audit)

    # oats
    p = sub.add_parser("oats", help="Run OATS canonical validation suite")
    p.add_argument("--seed",     type=int, default=0)
    p.add_argument("--tau-tol",  type=int, default=5, dest="tau_tol")
    p.add_argument("--bits-tol", type=float, default=0.15, dest="bits_tol")
    p.set_defaults(func=cmd_oats)

    # confidence
    p = sub.add_parser("confidence",
                       help="Bootstrap confidence interval on peak gap bits")
    p.add_argument("--ticker",  required=True)
    p.add_argument("--period",  default="2y")
    p.add_argument("--n-boot",  type=int, default=200, dest="n_boot")
    p.add_argument("--ci",      type=float, default=95.0)
    p.add_argument("--epsilon", type=float, default=0.01)
    p.add_argument("--seed",    type=int, default=42)
    p.set_defaults(func=cmd_confidence)

    # horizon-decay
    p = sub.add_parser("horizon-decay",
                       help="Track tau_h_plus across rolling windows")
    p.add_argument("--ticker",  required=True)
    p.add_argument("--period",  default="2y")
    p.add_argument("--window",  type=int, default=120)
    p.add_argument("--epsilon", type=float, default=0.01)
    p.add_argument("--out",     default=None)
    p.set_defaults(func=cmd_horizon_decay)

    return parser



def cmd_cite(args):
    """Print citations for fawp-index in bibtex, apa, or mla format."""
    import fawp_index as _fi
    ver = _fi.__version__
    fmt = getattr(args, "format", "bibtex")
    doi = "10.5281/zenodo.18673949"
    author = "Clayton, R."; title_short = "fawp-index: FAWP detector"; year = "2026"
    if getattr(args, "live", False):
        try:
            import urllib.request as _ur, json as _jz
            with _ur.urlopen(f"https://zenodo.org/api/records/{doi.split(chr(46))[-1]}",
                             timeout=5) as _r:
                _m = _jz.loads(_r.read()).get("metadata",{})
                title_short = _m.get("title", title_short)
                year = str(_m.get("publication_date", year))[:4]
            print("[Live metadata from Zenodo]")
        except Exception as _ze:
            print(f"[Zenodo fetch failed: {_ze}]")
    if fmt == "apa":
        print(f"{author} ({year}). {title_short} (v{ver}) [Software]. "
              f"https://doi.org/{doi}")
        return
    if fmt == "mla":
        print(f'{author} "{title_short}." Version {ver}, {year}, '
              f"https://doi.org/{doi}.")
        return
    # bibtex (default)

    bib = f"""
% ─────────────────────────────────────────────────────────────
%  fawp-index — citation guide
%  Run:  fawp-index cite
% ─────────────────────────────────────────────────────────────

% 1. Software (PyPI package + this repo)
@software{{fawp_index_software,
  author    = {{Clayton, Ralph}},
  title     = {{fawp-index: FAWP Alpha Index — Information-Control Exclusion Principle detector}},
  year      = {{2026}},
  version   = {{{ver}}},
  doi       = {{10.5281/zenodo.18673949}},
  url       = {{https://github.com/DrRalphClayton/fawp-index}},
  license   = {{MIT}}
}}

% 2. E9 Suite (comparative timing, gap2, robustness)
@article{{fawp_e9_suite,
  author    = {{Clayton, Ralph}},
  title     = {{FAWP Alpha Index — E9 Suite: Comparative timing, gap2 detector, robustness}},
  year      = {{2026}},
  doi       = {{10.5281/zenodo.19065421}},
  url       = {{https://doi.org/10.5281/zenodo.19065421}}
}}

% 3. E8 / SPHERE-16 flagship calibration
@article{{fawp_sphere16,
  author    = {{Clayton, Ralph}},
  title     = {{FAWP Alpha Index — SPHERE-16: E8 Flagship Calibration}},
  year      = {{2026}},
  doi       = {{10.5281/zenodo.18673949}},
  url       = {{https://doi.org/10.5281/zenodo.18673949}}
}}

% 4. E1–E7 foundational theory (Volumetric Time Model)
@article{{fawp_e1_e7,
  author    = {{Clayton, Ralph}},
  title     = {{FAWP Alpha Index — E1–E7: Volumetric Time Model}},
  year      = {{2026}},
  doi       = {{10.5281/zenodo.18663547}},
  url       = {{https://doi.org/10.5281/zenodo.18663547}}
}}

% 5. Research data (Figshare)
@misc{{fawp_figshare,
  author    = {{Clayton, Ralph}},
  title     = {{fawp-index: research data and supplementary materials}},
  year      = {{2026}},
  doi       = {{10.6084/m9.figshare.31799104}},
  url       = {{https://doi.org/10.6084/m9.figshare.31799104}}
}}

% 6. OSF project
@misc{{fawp_osf,
  author    = {{Clayton, Ralph}},
  title     = {{FAWP Alpha Index — OSF Project}},
  year      = {{2026}},
  url       = {{https://osf.io/hzwgp/}}
}}
"""
    print(bib.strip())



def cmd_timing(_args):
    """Print E9.7 detector timing results."""
    import fawp_index as fi
    print()
    print("E9.7 Detector Timing — 4,244-run sweep (a=1.02, K=0.8)")
    print("=" * 58)
    print(f"  {'Detector':<28} {'Leads cliff (u)':<16} {'Leads cliff (ξ)':<16} {'Err vs ODW'}")
    print(f"  {'-'*28} {'-'*16} {'-'*16} {'-'*12}")
    _g_u  = f"+{fi.E97_MEAN_LEAD_GAP2_TO_CLIFF_U:.4f}"
    _g_xi = f"+{fi.E97_MEAN_LEAD_GAP2_TO_CLIFF_XI:.4f}"
    _a2_u = f"+{fi.E97_MEAN_LEAD_ALPHA2_TO_CLIFF_U:.4f}"
    _a2_xi= f"+{fi.E97_MEAN_LEAD_ALPHA2_TO_CLIFF_XI:.4f}"
    _a_u  = f"{fi.E97_MEAN_LEAD_ALPHA_TO_CLIFF_U:.4f}"
    _a_xi = f"{fi.E97_MEAN_LEAD_ALPHA_TO_CLIFF_XI:.4f}"
    print(f"  {'gap2 peak (raw lever. gap)':<28} "
          f"{_g_u:<16} {_g_xi:<16} "
          f"~{fi.E97_MEAN_ABS_ERR_GAP2_VS_ODW_START:.1f} delays  ✅ BEST")
    print(f"  {'α₂  (SPHERE-16)':<28} "
          f"{_a2_u:<16} {_a2_xi:<16} "
          f"~{fi.E97_MEAN_ABS_ERR_ALPHA2_VS_ODW_START:.1f} delays  ✅ Good")
    print(f"  {'α   (baseline, old)':<28} "
          f"{_a_u:<16} {_a_xi:<16} "
          f"~{fi.E97_MEAN_ABS_ERR_ALPHA_VS_ODW_START:.1f} delays  ❌ Lags")
    print()
    print(f"  Total runs : {fi.E97_N_RUNS}")
    print(f"  Mean τf    : {fi.E97_MEAN_TAU_F}")
    print(f"  Source     : doi:10.5281/zenodo.19065421")
    print()


def cmd_verify(args):
    """Run calibration self-checks against published SPHERE/E9 constants."""
    if getattr(args, "sphere23", False):
        return cmd_verify_sphere23(args)
    if getattr(args, "e8", False):
        return cmd_verify_e8(args)

    import fawp_index as fi
    from fawp_index.data import E9_2_SUMMARY_JSON
    import json

    checks = []
    def chk(name, got, expected, tol=0.01):
        ok = abs(float(got) - float(expected)) <= tol
        checks.append((name, got, expected, ok))

    # SPHERE-16 calibration (E8 flagship)
    chk("PEAK_PRED_BITS",      fi.PEAK_PRED_BITS,      2.233669,  1e-4)
    chk("ETA_PRED_CORRECTED",  fi.ETA_PRED_CORRECTED,  0.0,       1e-6)
    chk("PRED_AT_CLIFF",       fi.PRED_AT_CLIFF,       1.01,      0.01)
    chk("NULL_MAX_SHUFFLE_E8", fi.NULL_MAX_SHUFFLE_E8, 0.00216,   1e-4)
    chk("NULL_MAX_SHIFT_E8",   fi.NULL_MAX_SHIFT_E8,   0.00421,   1e-4)

    # E9 / flagship ODW constants (correct exported names)
    chk("TAU_PLUS_H_FLAGSHIP", fi.TAU_PLUS_H_FLAGSHIP, 4,   0)
    chk("TAU_F_FLAGSHIP",      fi.TAU_F_FLAGSHIP,      35,  0)
    chk("TAU_PLUS_H_E9",       fi.TAU_PLUS_H_E9,       31,  0)
    chk("TAU_F_E9",            fi.TAU_F_E9,            36,  0)
    chk("ODW_START_E9",        fi.ODW_START_E9,        31,  0)
    chk("ODW_END_E9",          fi.ODW_END_E9,          33,  0)

    # E9.7 timing
    chk("E97_MEAN_LEAD_GAP2_TO_CLIFF_U",  fi.E97_MEAN_LEAD_GAP2_TO_CLIFF_U,  0.7552, 1e-3)
    chk("E97_MEAN_LEAD_ALPHA_TO_CLIFF_U", fi.E97_MEAN_LEAD_ALPHA_TO_CLIFF_U, -2.004, 1e-3)
    chk("E97_MEAN_ABS_ERR_GAP2_VS_ODW_START", fi.E97_MEAN_ABS_ERR_GAP2_VS_ODW_START, 2.108, 0.01)

    # SPHERE_23 Triple Horizon (Experiment 11, March 2026)
    chk("ALPHA_A",            fi.ALPHA_A,             0.007297,           1e-5)
    chk("ALPHA_A_SQ",         fi.ALPHA_A_SQ,          5.325135447834e-5,  1e-10)
    chk("E11_TAU_ALPHA",       fi.E11_TAU_ALPHA,       10,                 0)
    chk("E11_TAU_PLUS_H",      fi.E11_TAU_PLUS_H,      12,                 0)
    chk("E11_TAU_F",           fi.E11_TAU_F,           29,                 0)
    chk("E11_TAU_ALPHA2",      fi.E11_TAU_ALPHA2,      32,                 0)
    chk("E11_TAU_READOUT",     fi.E11_TAU_READOUT,     38,                 0)

    # Verify bundled E9.2 data is loadable
    try:
        with open(E9_2_SUMMARY_JSON) as f:
            s = json.load(f)
        assert s["aggregate_summary"]["fawp_found_u"] is True
        checks.append(("E9.2 data loadable + FAWP found", True, True, True))
    except Exception as e:
        checks.append((f"E9.2 data error: {e}", None, None, False))

    passed = sum(1 for *_, ok in checks if ok)
    print()
    print(f"fawp-index calibration verification — {len(checks)} checks")
    print("=" * 55)
    for name, got, exp, ok in checks:
        icon = "✅" if ok else "❌"
        val = f"{got}" if got is True or got is None else f"{got}"
        print(f"  {icon}  {name:<42} {val}")
    print()
    print(f"  {passed}/{len(checks)} checks passed")
    if passed < len(checks):
        print("  ⚠️  Some checks failed — reinstall fawp-index or check your version")
    else:
        print("  ✅ All calibration checks pass")
    print()


def cmd_grid(args):
    """Generate a FAWP detection basin heatmap over (a, K) parameter space."""
    import numpy as np
    import pandas as pd

    a_vals = np.linspace(args.a_min, args.a_max, args.n)
    K_vals = np.linspace(args.k_min, args.k_max, args.n)

    print(f"FAWP basin scan: a∈[{args.a_min},{args.a_max}] × K∈[{args.k_min},{args.k_max}] n={args.n}×{args.n}")
    print(f"Seeds per cell: {args.seeds}  |  Output: {args.out}")
    print()

    # Inline synthetic delayed plant — no external imports needed
    from fawp_index.weather import _compute_weather_mi_curves

    rows = []
    total = len(a_vals) * len(K_vals)
    done = 0

    for a in a_vals:
        for K in K_vals:
            fawp_hits = 0
            peak_gaps = []
            for seed in range(args.seeds):
                try:
                    rng = np.random.default_rng(seed + 42000)
                    n = 500
                    x = np.zeros(n)
                    u = np.zeros(n)
                    # Delayed plant: x_{t} = a*x_{t-1} + u_t + noise
                    #                u_t   = -K*x_{t-1} + control_noise
                    for t in range(1, n):
                        u[t] = -K * x[t-1] + rng.normal(0, 0.5)
                        x[t] = a * x[t-1] + u[t] + rng.normal(0, 1.0)

                    delta = 20
                    nn    = n - delta
                    pred   = x[:nn]
                    future = x[delta:delta + nn]
                    steer  = np.diff(x)[:nn]

                    odw, _, _, _ = _compute_weather_mi_curves(
                        pred, future, steer, tau_max=40, n_null=20, epsilon=0.01
                    )
                    if odw.fawp_found:
                        fawp_hits += 1
                    peak_gaps.append(odw.peak_gap_bits)
                except Exception:
                    pass

            detect_rate = fawp_hits / max(1, args.seeds)
            mean_gap    = float(np.mean(peak_gaps)) if peak_gaps else 0.0
            rows.append({"a": round(a, 4), "K": round(K, 4),
                         "fawp_rate": round(detect_rate, 3),
                         "mean_peak_gap_bits": round(mean_gap, 4)})
            done += 1
            if done % 5 == 0 or done == total:
                print(f"  [{done:3d}/{total}] a={a:.3f} K={K:.3f} → rate={detect_rate:.2f} gap={mean_gap:.4f}")

    df = pd.DataFrame(rows)
    df.to_csv(args.out, index=False)
    print(f"\nSaved: {args.out}  ({len(df)} grid points)")

    # Optionally save heatmap
    if args.plot:
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            pivot = df.pivot(index="K", columns="a", values="fawp_rate")
            fig, ax = plt.subplots(figsize=(8, 6))
            im = ax.imshow(pivot.values, aspect="auto", origin="lower", cmap="YlOrRd",
                           extent=[pivot.columns.min(), pivot.columns.max(),
                                   pivot.index.min(), pivot.index.max()])
            plt.colorbar(im, ax=ax, label="FAWP detection rate")
            ax.set_xlabel("a (system gain)")
            ax.set_ylabel("K (control gain)")
            ax.set_title(f"FAWP Basin — {args.n}×{args.n} grid, {args.seeds} seeds/cell")
            png = args.out.replace(".csv", ".png")
            fig.savefig(png, dpi=150, bbox_inches="tight")
            print(f"Heatmap: {png}")
        except Exception as e:
            print(f"Plot skipped: {e}")

    # Stability ranking by detection_rate
    if rows:
        _ranked = sorted(rows, key=lambda r: (-r.get("fawp_rate",0),
                                               r.get("a_val",0)))
        print("Top (a,K) configs by FAWP detection rate:")
        print("  {:>6} {:>5} {:>10}".format("a","K","fawp_rate"))
        for _row in _ranked[:5]:
            print("  {:>6.3f} {:>5.2f} {:>10.1%}".format(
                  _row.get("a_val",0), _row.get("K_val",0),
                  _row.get("fawp_rate",0)))
    print()


def cmd_forecast(args):
    """Run FAWP detection on NWP forecast vs observation CSVs."""
    import pandas as pd
    from fawp_index.weather import fawp_from_nwp_csvs

    print(f"FAWP NWP Forecast Verification")
    print(f"  Forecast : {args.forecast}")
    print(f"  Observed : {args.obs}")
    print(f"  Variable : {args.variable}")
    print()

    result = fawp_from_nwp_csvs(
        forecast_path    = args.forecast,
        observed_path    = args.obs,
        forecast_col     = args.forecast_col,
        observed_col     = args.obs_col,
        date_col         = args.date_col,
        variable         = args.variable,
        location         = args.location,
        horizon_days     = args.horizon,
        tau_max          = args.tau_max,
        epsilon          = args.epsilon,
        n_null           = args.n_null,
    )

    print(result.summary())

    if args.out:
        import json as _j
        if args.out.endswith(".json"):
            with open(args.out, "w") as f:
                _j.dump(result.to_dict(), f, indent=2)
            print(f"Saved → {args.out}")
        elif args.out.endswith(".csv"):
            df = pd.DataFrame({
                "tau": result.tau,
                "pred_mi": result.pred_mi,
                "steer_mi": result.steer_mi,
            })
            df.to_csv(args.out, index=False)
            print(f"Saved → {args.out}")


def cmd_report(args):
    """Generate a PDF/HTML report from JSON file or inline ticker scan."""
    if not getattr(args,"data",None) and not getattr(args,"ticker",None):
        import sys; print("ERROR: provide --data <file> or --ticker <SYMBOL>"); sys.exit(1)
    # --ticker shortcut: scan inline then report
    if getattr(args, "ticker", None):
        print(f"Running inline scan for {args.ticker} [{args.period}]…")
        try:
            import yfinance as _yf_r, json as _j_r, tempfile as _tmp_r
            from fawp_index.market import scan_fawp_market as _sfm
            _df_r = _yf_r.download(args.ticker, period=args.period,
                                   auto_adjust=True, progress=False)
            if _df_r.empty:
                print(f"No data for {args.ticker}"); return
            _epsilon_r = getattr(args, "epsilon", 0.01)
            _n_null_r  = getattr(args, "n_null",  50)
            _r_scan = _sfm(_df_r, ticker=args.ticker,
                           epsilon=_epsilon_r, n_null=_n_null_r, verbose=False)
            _tf = _tmp_r.NamedTemporaryFile(suffix=".json", delete=False, mode="w")
            _j_r.dump(getattr(_r_scan, "__dict__", {}), _tf, default=str)
            _tf.close()
            args.data = _tf.name
            print("Scan complete — generating report…")
        except ImportError:
            print("yfinance required: pip install yfinance"); return
    import json
    from fawp_index.report import generate_report

    with open(args.data) as f:
        result = json.load(f)

    out = args.out or args.data.replace(".json", ".pdf")
    path = generate_report(
        result      = result,
        output_path = out,
        title       = args.title,
        mode        = args.mode,
        author      = args.author,
        doi         = args.doi,
    )
    print(f"Report saved → {path}")


def cmd_watch(args):
    """Live FAWP watch loop — rescan every N minutes, print diff to stdout."""
    import time as _tw
    from datetime import datetime, timezone
    try:
        import yfinance as yf
    except ImportError:
        print("yfinance required: pip install yfinance"); return
    from fawp_index.market import scan_fawp_market
    tickers   = [t.strip().upper() for t in args.tickers.split(",") if t.strip()]
    interval_s = args.interval * 60   # interval is in MINUTES
    n_null    = getattr(args, "n_null",    50)
    alert_gap = getattr(args, "alert_gap", 0.05)
    once      = getattr(args, "once",      False)
    print("FAWP Watch  tickers=" + ",".join(tickers) + "  interval=" + str(args.interval)
          + "min  alert_gap=" + str(alert_gap) + ("  (once)" if once else ""))
    print("Press Ctrl+C to stop.")
    print("")
    prev_fawp = set(); scan_n = 0
    while True:
        scan_n += 1
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        curr_fawp = set(); lines = []
        for ticker in tickers:
            try:
                df = yf.download(ticker, period=args.period, auto_adjust=True, progress=False)
                if df.empty: continue
                r   = scan_fawp_market(df, ticker=ticker, epsilon=args.epsilon,
                                        n_null=n_null, verbose=False,
                                        **({} if not hasattr(args,"window") else
                                           {k:v for k,v in
                                            {"window":getattr(args,"window",None),
                                             "step":getattr(args,"step",None)
                                            }.items() if v is not None}))
                odw = getattr(r, "odw_result", r)
                gap = float(odw.peak_gap_bits or 0)
                if odw.fawp_found and gap >= alert_gap: curr_fawp.add(ticker)
                icon = "[FAWP]" if odw.fawp_found else "[  ok]"
                lines.append("  " + icon + " " + ticker + "  gap=" + str(round(gap,4)) + "b"
                             + ("  tau_h=" + str(odw.tau_h_plus) if odw.tau_h_plus is not None else ""))
            except Exception as _e:
                lines.append("  [ERR] " + ticker + "  " + str(_e))
        entered = sorted(curr_fawp - prev_fawp)
        exited  = sorted(prev_fawp - curr_fawp)
        print("[" + ts + "] Scan #" + str(scan_n))
        for _l in lines: print(_l)
        if entered: print("  >> ENTERED FAWP: " + ", ".join(entered))
        if exited:  print("  >> EXITED  FAWP: " + ", ".join(exited))
        print("")
        prev_fawp = curr_fawp
        if once: break
        try:
            _tw.sleep(interval_s)
        except KeyboardInterrupt:
            print("Watch stopped."); break

def cmd_status(args):
    """Print live project status: PyPI version, CI, calibration checks.

    With --all: also verifies installed version against PyPI and shows recent changelog.
    """
    _show_all = getattr(args, "all_info", False)
    if _show_all:
        import fawp_index as _fi_s
        print(f"Installed : fawp-index {_fi_s.__version__}")
        try:
            import urllib.request as _ur, json as _js
            with _ur.urlopen("https://pypi.org/pypi/fawp-index/json", timeout=4) as r:
                _latest = _js.loads(r.read())["info"]["version"]
            _ok = _latest == _fi_s.__version__
            _icon = "OK" if _ok else "UPDATE AVAILABLE"
            print(f"Latest    : {_latest}  [{_icon}]")
        except Exception as _pe:
            print(f"PyPI check failed: {_pe}")
        try:
            import re as _re
            from pathlib import Path as _P
            _cl = next((p for p in [
                _P(__file__).parent.parent/"CHANGELOG.md",
                _P(__file__).parent.parent.parent/"CHANGELOG.md"
            ] if p.exists()), None)
            if _cl:
                _entries = _re.split(r"^## ", _cl.read_text(), flags=_re.M)[1:4]
                print()
                print("Recent changelog entries:")
                for _e in _entries:
                    print(f"  ## {_e.splitlines()[0]}")
        except Exception:
            pass
        print()
    import urllib.request, json as _j
    import fawp_index as fi

    print()
    print("fawp-index project status")
    print("=" * 48)

    # Installed version
    print(f"  Installed version : {fi.__version__}")

    # Latest PyPI version
    try:
        with urllib.request.urlopen(
            "https://pypi.org/pypi/fawp-index/json", timeout=4
        ) as r:
            _pypi = _j.loads(r.read())
        latest = _pypi["info"]["version"]
        up_to_date = fi.__version__ == latest
        icon = "✅" if up_to_date else "⬆️ "
        print(f"  PyPI latest       : {latest}  {icon}")
    except Exception:
        print("  PyPI latest       : (unavailable)")

    # PyPI downloads
    try:
        with urllib.request.urlopen(
            "https://pypistats.org/api/packages/fawp-index/recent", timeout=4
        ) as r:
            _dl = _j.loads(r.read())
        dm = _dl.get("data", {}).get("last_month", 0)
        print(f"  Downloads/month   : {dm:,}")
    except Exception:
        print("  Downloads/month   : (unavailable)")

    # Calibration self-check
    print()
    print("  Calibration checks:")
    checks = [
        ("PEAK_PRED_BITS",             fi.PEAK_PRED_BITS,             2.233669, 1e-4),
        ("TAU_PLUS_H_FLAGSHIP",        fi.TAU_PLUS_H_FLAGSHIP,        4,        0),
        ("TAU_F_FLAGSHIP",             fi.TAU_F_FLAGSHIP,             35,       0),
        ("E97_MEAN_LEAD_GAP2_U",       fi.E97_MEAN_LEAD_GAP2_TO_CLIFF_U, 0.7552, 1e-3),
        ("E97_MEAN_ABS_ERR_GAP2",      fi.E97_MEAN_ABS_ERR_GAP2_VS_ODW_START, 2.108, 0.01),
    ]
    all_ok = True
    for name, val, expected, tol in checks:
        ok = abs(float(val) - float(expected)) <= tol
        all_ok = all_ok and ok
        print(f"    {'✅' if ok else '❌'} {name} = {val}")

    print()
    print(f"  Calibration : {'✅ PASS' if all_ok else '❌ FAIL'}")
    print()
    print("  E9.7 detector timing (4,244-run sweep):")
    print(f"    gap2 peak  leads cliff by  +{fi.E97_MEAN_LEAD_GAP2_TO_CLIFF_U:.4f} delays  ✅ BEST")
    print(f"    α₂         leads cliff by  +{fi.E97_MEAN_LEAD_ALPHA2_TO_CLIFF_U:.4f} delays  ✅ Good")
    print(f"    α baseline lags  cliff by   {fi.E97_MEAN_LEAD_ALPHA_TO_CLIFF_U:.4f} delays  ❌ Lags")
    print(f"    ODW localisation error: ~{fi.E97_MEAN_ABS_ERR_GAP2_VS_ODW_START:.1f} delays")
    print()
    print(f"  Docs        : https://fawp-index.readthedocs.io")
    print(f"  GitHub      : https://github.com/DrRalphClayton/fawp-index")
    print(f"  Live demo   : https://fawp-scanner.info")
    print()


def cmd_backtest(args):
    """Walk historical data bar by bar, run FAWP detector at each step, record signals."""
    try:
        import yfinance as yf
    except ImportError:
        print("yfinance required: pip install yfinance"); return
    import numpy as np
    from fawp_index.market import scan_fawp_market
    print("FAWP Backtest  ticker=" + args.ticker
          + "  period=" + args.period
          + "  window=" + str(args.window)
          + "  step=" + str(args.step))
    df = yf.download(args.ticker, period=args.period, auto_adjust=True, progress=False)
    if df.empty:
        print("No data for " + args.ticker); return
    n = len(df)
    rows = []
    in_fawp = False
    entry_date = None
    print("  " + "{:>12} {:>8} {:>7} {:>12} {:>10}".format(
          "Date","Gap(bits)","FAWP","tau_h","Event"))
    print("  " + "-"*55)
    for end in range(args.window, n, args.step):
        df_win = df.iloc[max(0,end-args.window):end]
        try:
            r   = scan_fawp_market(df_win, ticker=args.ticker,
                                    epsilon=args.epsilon, n_null=15, verbose=False)
            odw = getattr(r, "odw_result", r)
            gap = float(odw.peak_gap_bits or 0)
            fawp = bool(odw.fawp_found)
            date = str(df.index[end-1])[:10]
            event = ""
            if fawp and not in_fawp:
                event = "ENTER"; entry_date = date; in_fawp = True
            elif not fawp and in_fawp:
                event = "EXIT"; in_fawp = False
            if event or (fawp and end % max(1,args.step*5) == 0):
                row = "  " + "{:>12} {:>8.4f} {:>7} {:>12} {:>10}".format(
                      date, gap, "FAWP" if fawp else "ok",
                      str(odw.tau_h_plus) if odw.tau_h_plus is not None else "--",
                      event)
                print(row)
            rows.append({"date":date,"gap":gap,"fawp":fawp,
                         "tau_h":odw.tau_h_plus,"event":event})
        except Exception as _e:
            pass
    entries = [r for r in rows if r["event"]=="ENTER"]
    exits   = [r for r in rows if r["event"]=="EXIT"]
    print("")
    print("Summary: " + str(len(entries)) + " FAWP entries, "
          + str(len(exits)) + " exits over " + str(n) + " bars")
    if rows and args.out:
        import pandas as pd
        pd.DataFrame(rows).to_csv(args.out, index=False)
        print("Saved -> " + args.out)
def cmd_notebook(args):
    """Open the E9 replication notebook in Jupyter."""
    import subprocess, sys, os
    from pathlib import Path

    # Find the notebook — prefer repo clone, fall back to installed data path
    candidates = [
        Path(__file__).parent.parent / "notebooks" / "E9_full_replication.ipynb",
        Path(sys.prefix) / "share" / "fawp-index" / "notebooks" / "E9_full_replication.ipynb",
    ]
    nb_path = next((p for p in candidates if p.exists()), None)

    if nb_path is None:
        print("Notebook not found. Clone the repo:")
        print("  git clone https://github.com/DrRalphClayton/fawp-index")
        print("  cd fawp-index && fawp-index notebook")
        return

    print(f"Opening: {nb_path}")

    if args.lab:
        cmd = [sys.executable, "-m", "jupyter", "lab", str(nb_path)]
        label = "JupyterLab"
    else:
        cmd = [sys.executable, "-m", "jupyter", "notebook", str(nb_path)]
        label = "Jupyter Notebook"

    print(f"Starting {label}…")
    try:
        subprocess.run(cmd, check=True)
    except FileNotFoundError:
        print(f"Jupyter not installed. Install it:")
        print("  pip install jupyter")
    except KeyboardInterrupt:
        print("\nNotebook server stopped.")


def cmd_compare(args):
    """Compare FAWP signals for two assets or two weather locations side by side."""
    import pandas as pd

    if args.mode == "finance":
        try:
            import yfinance as yf
            print(f"FAWP Comparison: {args.a} vs {args.b}  [{args.period}]")
            print()
            from fawp_index.market import scan_fawp_market
            results = {}
            for ticker in [args.a, args.b]:
                df = yf.download(ticker, period=args.period, auto_adjust=True, progress=False)
                if df.empty:
                    print(f"  {ticker}: no data")
                    continue
                r = scan_fawp_market(df, ticker=ticker, window=args.window,
                                     step=args.step, epsilon=args.epsilon,
                                     n_null=args.n_null, verbose=False)
                results[ticker] = r
        except ImportError:
            print("yfinance required: pip install yfinance")
            return
    elif args.mode == "weather":
        from fawp_index.weather import fawp_from_open_meteo
        print(f"FAWP Comparison: ({args.lat_a},{args.lon_a}) vs ({args.lat_b},{args.lon_b})")
        print(f"  Variable : {args.variable}  Period: {args.start} → {args.end}")
        print()
        results = {}
        for name, lat, lon in [("A", args.lat_a, args.lon_a), ("B", args.lat_b, args.lon_b)]:
            r = fawp_from_open_meteo(latitude=lat, longitude=lon, variable=args.variable,
                                     start_date=args.start, end_date=args.end,
                                     horizon_days=args.horizon, epsilon=args.epsilon,
                                     n_null=args.n_null)
            results[f"Location {name} ({lat:.2f},{lon:.2f})"] = r

    # Print comparison table
    print(f"{'Label':<28} {'FAWP':>6} {'Peak gap':>10} {'τ⁺ₕ':>5} {'τf':>5} {'n obs':>7}")
    print("-" * 62)
    for label, r in results.items():
        fawp = "🔴 YES" if getattr(r, "fawp_found", False) or getattr(r, "in_fawp", [False])[-1] else "—"
        gap  = getattr(r, "peak_gap_bits", 0) or 0
        tau_h = getattr(r.odw_result if hasattr(r,"odw_result") else r, "tau_h_plus", None)
        tau_h = str(tau_h) if tau_h is not None else "—"
        tau_f = getattr(r.odw_result if hasattr(r,"odw_result") else r, "tau_f",     None)
        tau_f = str(tau_f) if tau_f is not None else "—"
        n_obs = getattr(r, "n_obs", getattr(r, "n_windows", "—"))
        print(f"{label:<28} {fawp:>6} {gap:>10.4f} {str(tau_h):>5} {str(tau_f):>5} {str(n_obs):>7}")
    print()

    if args.out:
        rows = []
        for label, r in results.items():
            rows.append({"label": label,
                         "fawp": bool(getattr(r,"fawp_found",False)),
                         "peak_gap_bits": getattr(r,"peak_gap_bits",0) or 0})
        pd.DataFrame(rows).to_csv(args.out, index=False)
        print(f"Saved → {args.out}")


def cmd_export(args):
    """Export a FAWP result JSON to CSV, HTML, or PDF."""
    import json
    from pathlib import Path

    with open(args.data) as f:
        result = json.load(f)

    fmt = args.format or Path(args.out).suffix.lstrip('.') if args.out else "csv"
    out = args.out or args.data.replace(".json", f".{fmt}")

    print(f"Exporting {args.data} → {out} [{fmt}]")

    if fmt == "csv":
        import pandas as pd
        if isinstance(result, list):
            df = pd.DataFrame(result)
        elif "assets" in result:
            df = pd.DataFrame(result["assets"])
        else:
            df = pd.DataFrame([result])
        df.to_csv(out, index=False)

    elif fmt == "html":
        try:
            from fawp_index.exports import odw_to_html
            odw_to_html(result, out)
        except Exception:
            with open(out, "w") as fh:
                fh.write(f"<pre>{json.dumps(result, indent=2)}</pre>")

    elif fmt == "pdf":
        from fawp_index.report import generate_report
        generate_report(result=result, output_path=out,
                        title=args.title or f"FAWP Export — {Path(args.data).stem}",
                        mode=args.mode)
    else:
        print(f"Unknown format: {fmt}. Use csv, html, pdf, or parquet.")
        return

    print(f"Saved → {out}")


def cmd_sweep(args):
    """Sweep (epsilon, tau_max, n_null) and show FAWP detection sensitivity table."""
    import json, itertools
    import pandas as pd
    from fawp_index.weather import _compute_weather_mi_curves
    import numpy as np

    print(f"FAWP parameter sweep on: {args.data}")
    with open(args.data) as f:
        d = json.load(f)

    # Extract series — support weather or finance JSON
    if "pred_mi" in d and "steer_mi" in d:
        pred_mi  = np.array(d["pred_mi"],  dtype=float)
        steer_mi = np.array(d["steer_mi"], dtype=float)
        tau      = np.array(d.get("tau", list(range(1, len(pred_mi)+1))), dtype=int)
        _has_raw = False
    else:
        print("JSON must contain pred_mi + steer_mi arrays (from a weather or finance scan).")
        return

    epsilons  = [float(e) for e in args.epsilon.split(",")]
    tau_maxes = [int(t)   for t in args.tau_max.split(",")]
    n_nulls   = [int(n)   for n in args.n_null.split(",")]

    rows = []
    from fawp_index.detection.odw import ODWDetector
    from fawp_index.constants import PERSISTENCE_RULE_M, PERSISTENCE_RULE_N

    for eps, tm, nn in itertools.product(epsilons, tau_maxes, n_nulls):
        # Trim curves to tau_max
        mask = tau <= tm
        pm = pred_mi[mask]; sm = steer_mi[mask]; ta = tau[mask]
        fail = np.zeros(len(ta))
        det = ODWDetector(epsilon=eps, persistence_m=PERSISTENCE_RULE_M,
                          persistence_n=PERSISTENCE_RULE_N)
        try:
            odw = det.detect(tau=ta, pred_corr=pm, steer_corr=sm, fail_rate=fail)
            rows.append({
                "epsilon": eps, "tau_max": tm, "n_null": nn,
                "fawp":         odw.fawp_found,
                "peak_gap":     round(odw.peak_gap_bits, 4),
                "odw_start":    odw.odw_start,
                "odw_end":      odw.odw_end,
                "tau_h_plus":   odw.tau_h_plus,
            })
        except Exception as e:
            rows.append({"epsilon": eps, "tau_max": tm, "n_null": nn,
                         "fawp": None, "peak_gap": None, "error": str(e)})

    df = pd.DataFrame(rows)
    print(df.to_string(index=False))
    out = args.out or args.data.replace(".json", "_sweep.csv")
    df.to_csv(out, index=False)
    n_fawp = int(df["fawp"].sum()) if "fawp" in df else 0
    print(f"\n{n_fawp}/{len(df)} configurations detect FAWP")
    print(f"Saved → {out}")

def _check_version_update():
    """Check if a newer version is available on PyPI and print a notice."""
    try:
        import urllib.request, json as _j
        import fawp_index as fi
        with urllib.request.urlopen(
            "https://pypi.org/pypi/fawp-index/json", timeout=2
        ) as r:
            latest = _j.loads(r.read())["info"]["version"]
        cur = fi.__version__
        # Simple string compare — works for CalVer/SemVer alike
        cur_t = tuple(int(x) for x in cur.split(".")[:3])
        lat_t = tuple(int(x) for x in latest.split(".")[:3])
        if lat_t > cur_t:
            print(f"\u2b06  Update available: {cur} \u2192 {latest}")
            print(f"   pip install --upgrade fawp-index\n")
    except Exception:
        pass



def cmd_diagnose(args):
    """Load a FAWP result JSON and print a plain-English diagnosis."""
    import json
    from fawp_index.explain import explain_fawp
    from fawp_index.detection.odw import ODWResult

    with open(args.data) as f:
        d = json.load(f)

    # Reconstruct ODWResult-like namespace for explain
    class _R:
        pass

    r = _R()
    r.fawp_found    = d.get("fawp_found", False)
    r.peak_gap_bits = d.get("peak_gap_bits", 0.0)
    r.tau_h_plus    = d.get("tau_h_plus")
    r.tau_f         = d.get("tau_f")
    r.odw_start     = d.get("odw_start")
    r.odw_end       = d.get("odw_end")
    r.epsilon       = d.get("epsilon", 0.01)
    r.n_obs         = d.get("n_obs", 0)
    r.domain        = d.get("domain", "unknown")

    import numpy as np
    r.pred_mi  = np.array(d.get("pred_mi",  []))
    r.steer_mi = np.array(d.get("steer_mi", []))
    r.tau      = np.array(d.get("tau",      []))

    # Build ODW-like subobject
    r.odw_result = _R()
    r.odw_result.fawp_found    = r.fawp_found
    r.odw_result.peak_gap_bits = r.peak_gap_bits
    r.odw_result.tau_h_plus    = r.tau_h_plus
    r.odw_result.tau_f         = r.tau_f
    r.odw_result.odw_start     = r.odw_start
    r.odw_result.odw_end       = r.odw_end

    print(f"FAWP Diagnosis — {args.data}")
    print(f"Domain        : {r.domain}")
    print(f"Observations  : {r.n_obs}")
    print()

    status = "🔴 FAWP DETECTED" if r.fawp_found else "✅ No FAWP"
    print(f"Status        : {status}")
    print(f"Peak gap      : {r.peak_gap_bits:.4f} bits")
    print(f"Agency horizon: τ⁺ₕ = {r.tau_h_plus if r.tau_h_plus is not None else 'not reached'}")
    print(f"Failure cliff : τf  = {r.tau_f if r.tau_f is not None else 'not reached'}")
    print(f"Detection window: τ = {r.odw_start or '?'}–{r.odw_end or '?'}")
    print()

    if r.fawp_found:
        lead = (r.odw_end or 0) - (r.odw_start or 0)
        print("Plain-English diagnosis:")
        print(f"  Your system entered FAWP at τ = {r.odw_start}.")
        if r.peak_gap_bits:
            print(f"  Prediction peaked at {r.peak_gap_bits:.4f} bits while steering collapsed.")
        if r.tau_h_plus is not None and r.tau_f is not None:
            print(f"  Steering authority was lost at τ = {r.tau_h_plus}.")
            print(f"  Full control failure occurred at τ = {r.tau_f}.")
            print(f"  The operational detection window spans {lead} delay steps (τ = {r.odw_start}–{r.odw_end}).")
            print(f"  You had {lead} delay steps of warning before the cliff.")
    else:
        print("  No FAWP regime detected. Prediction and steering remain coupled.")
        print("  Forecast skill has not diverged from control authority.")

    # E9.7 calibration note
    try:
        import fawp_index as fi
        print()
        print(f"E9.7 calibration: gap2 peak leads cliff by +{fi.E97_MEAN_LEAD_GAP2_TO_CLIFF_U:.4f} delays")
        print(f"  ODW localisation error: ~{fi.E97_MEAN_ABS_ERR_GAP2_VS_ODW_START:.1f} steps")
    except Exception:
        pass


def cmd_latent(args):
    """
    Latent Environmental Residual Inference (LERI) CLI.

    Simulates the E-LERI record chain X → R → Y_τ → D_τ and computes
    the operational access horizon from your LERI paper.

    Reference: Clayton (2026) "Latent Environmental Residual Inference
    in the Volumetric Time Model", doi:10.5281/zenodo.18663547
    """
    import numpy as np

    # ── Parameters ────────────────────────────────────────────────────────
    P      = args.P
    sigma0 = args.sigma0
    alpha  = args.alpha
    eps    = args.epsilon
    beta   = args.beta
    m      = args.persist
    tau_max = args.tau_max
    n_null  = args.n_null
    seed    = args.seed

    # ── Analytic horizon (Eq. 15–16 from LERI paper) ──────────────────────
    denom = 2 ** (2 * eps) - 1
    if denom <= 0 or alpha <= 0:
        tau_analytic = float("inf")
    else:
        tau_analytic = max(0.0, (P / denom - sigma0) / alpha)

    print(f"LERI — Latent Environmental Residual Inference")
    print(f"  Parameters: P={P}  σ²₀={sigma0}  α={alpha}  ε={eps}b")
    print(f"  Analytic access horizon τ⁺ₕ ≈ {tau_analytic:.3f}")
    print()

    # ── Simulate record chain X → R → Y_τ → D_τ ──────────────────────────
    rng = np.random.default_rng(seed)
    n   = max(500, tau_max * 4)
    tau_arr = np.arange(1, tau_max + 1)

    X = rng.normal(0, 1, n)
    R = X + rng.normal(0, np.sqrt(sigma0), n)   # record with baseline noise

    from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor

    mi_vals   = np.zeros(len(tau_arr))
    null_vals = np.zeros(len(tau_arr))
    scores    = np.zeros(len(tau_arr))

    print(f"  Simulating record chain (n={n}, τ_max={tau_max}, n_null={n_null})…")
    for ti, tau in enumerate(tau_arr):
        noise_tau = rng.normal(0, np.sqrt(sigma0 + alpha * tau), n)
        D_tau = R + noise_tau    # delayed readout with latency-dependent noise

        x_v = X[:-tau]; d_v = D_tau[tau:]
        raw  = mi_from_arrays(x_v, d_v)
        floor = conservative_null_floor(x_v, d_v, n_null, quantile=beta)
        mi_vals[ti]   = max(0.0, raw)
        null_vals[ti] = floor
        scores[ti]    = max(0.0, raw - floor)

    # ── Persistence-gated horizon ─────────────────────────────────────────
    tau_numeric = None
    run_below = 0
    for ti, tau in enumerate(tau_arr):
        if scores[ti] < 1e-4:
            run_below += 1
            if run_below >= m:
                tau_numeric = int(tau_arr[max(0, ti - m + 1)])
                break
        else:
            run_below = 0

    print(f"  Numeric operational horizon τₕ = {tau_numeric or 'not reached in τ_max'}")
    print()
    print(f"  {'tau':>5}  {'MI (bits)':>12}  {'null floor':>12}  {'score':>10}")
    print(f"  {'---':>5}  {'----------':>12}  {'----------':>12}  {'-----':>10}")
    step = max(1, len(tau_arr) // 20)
    for ti, tau in enumerate(tau_arr[::step]):
        idx = ti * step
        print(f"  {tau:>5}  {mi_vals[idx]:>12.6f}  {null_vals[idx]:>12.6f}  {scores[idx]:>10.6f}")
    print()

    # ── Save if requested ─────────────────────────────────────────────────
    if args.out:
        import pandas as pd
        df = pd.DataFrame({"tau": tau_arr, "mi": mi_vals,
                           "null_floor": null_vals, "score": scores})
        df.to_csv(args.out, index=False)
        print(f"Saved → {args.out}")

    print(f"LERI horizon: analytic = {tau_analytic:.2f}  numeric = {tau_numeric or '∞'}")
    print(f"LERI photon constants: {14005.0:.1f} m horizon · {4.6683e-5:.4e} s")


def cmd_leaderboard(args):
    """Push a local scan result to the global FAWP leaderboard on Supabase."""
    import json, os
    from pathlib import Path

    if args.subcommand == "push":
        with open(args.data) as f:
            d = json.load(f)

        url   = args.url   or os.environ.get("FAWP_SUPABASE_URL",   "")
        token = args.token or os.environ.get("FAWP_SUPABASE_TOKEN", "")

        if not url or not token:
            print("Supabase URL and token required.")
            print("  Set --url / --token, or env vars FAWP_SUPABASE_URL / FAWP_SUPABASE_TOKEN")
            return

        try:
            from supabase import create_client
        except ImportError:
            print("supabase package required: pip install supabase")
            return

        db = create_client(url, token)
        row = {
            "ticker":         d.get("ticker") or d.get("asset") or Path(args.data).stem,
            "timeframe":      d.get("timeframe", "custom"),
            "peak_gap_bits":  round(float(d.get("peak_gap_bits", 0) or 0), 6),
            "fawp_found":     bool(d.get("fawp_found", False)),
            "tau_h_plus":     d.get("tau_h_plus"),
            "tau_f":          d.get("tau_f"),
            "odw_start":      d.get("odw_start"),
            "odw_end":        d.get("odw_end"),
            "epsilon":        float(d.get("epsilon", 0.01)),
            "n_obs":          int(d.get("n_obs", 0)),
            "domain":         d.get("domain", "custom"),
            "source":         "cli",
        }
        result = db.table("fawp_global_lb").upsert(row).execute()
        print(f"✅ Pushed to leaderboard: {row['ticker']} — gap {row['peak_gap_bits']:.4f} bits")
        print(f"   fawp_found={row['fawp_found']}  τ⁺ₕ={row['tau_h_plus']}  domain={row['domain']}")

    elif args.subcommand == "list":
        url   = args.url   or os.environ.get("FAWP_SUPABASE_URL",   "")
        token = args.token or os.environ.get("FAWP_SUPABASE_TOKEN", "")
        if not url or not token:
            print("Supabase credentials required.")
            return
        try:
            from supabase import create_client
        except ImportError:
            print("pip install supabase"); return

        db  = create_client(url, token)
        res = (db.table("fawp_global_lb")
               .select("*")
               .order("peak_gap_bits", desc=True)
               .limit(args.top)
               .execute())
        rows = res.data or []
        print(f"Global FAWP Leaderboard (top {args.top})")
        print(f"{'Rank':>4}  {'Ticker':<20} {'Gap (bits)':>12} {'FAWP':>6} {'Domain':<16}")
        print("-" * 65)
        for i, r in enumerate(rows, 1):
            print(f"  {i:>2}.  {r.get('ticker','?'):<20} "
                  f"{float(r.get('peak_gap_bits',0)):>12.4f} "
                  f"{'🔴' if r.get('fawp_found') else '—':>6}  "
                  f"{r.get('domain','?'):<16}")


def cmd_agency(args):
    """Sweep agency horizon over (P, alpha, sigma0) and print/plot a surface.

    From the VTM paper (Eq. 15-16):
      τₕ = max(0, (P / (2^(2ε) - 1) - σ²₀) / α)
    """
    import numpy as np
    import pandas as pd

    eps   = args.epsilon
    denom = 2 ** (2 * eps) - 1

    if args.mode == "alpha":
        # Sweep alpha (noise growth rate)
        alpha_vals = np.logspace(
            np.log10(args.a_min), np.log10(args.a_max), args.n_steps)
        tau_h_vals = np.maximum(0, (args.P / denom - args.sigma0) / alpha_vals)
        print(f"Agency horizon sweep: P={args.P}  σ²₀={args.sigma0}  ε={eps}b")
        print(f"{'alpha':>12}  {'tau_h':>10}")
        print("-" * 26)
        for a, t in zip(alpha_vals, tau_h_vals):
            print(f"{a:>12.5f}  {t:>10.2f}")
        if not args.no_plot:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(7, 3))
                ax.loglog(alpha_vals, tau_h_vals, color="#D4AF37", lw=2)
                ax.set_xlabel("α (noise growth rate)")
                ax.set_ylabel("τₕ (agency horizon)")
                ax.set_title(f"Agency Horizon — Inverse Scaling Law  (P={args.P}, ε={eps}b)")
                ax.grid(True, alpha=0.3)
                plt.tight_layout()
                plt.show()
            except Exception as e:
                print(f"Plot skipped: {e}")

    elif args.mode == "surface":
        # 2D heatmap: P × alpha → tau_h
        import numpy as np
        P_vals     = np.logspace(np.log10(args.P_min),   np.log10(args.P_max),   args.n_steps)
        alpha_vals = np.logspace(np.log10(args.a_min),   np.log10(args.a_max),   args.n_steps)
        PP, AA     = np.meshgrid(P_vals, alpha_vals)
        TH         = np.maximum(0, (PP / denom - args.sigma0) / AA)
        print(f"VTM Agency Horizon Surface  (ε={eps}b  σ²₀={args.sigma0})")
        print(f"  P range: [{P_vals[0]:.3f}, {P_vals[-1]:.3f}]")
        print(f"  α range: [{alpha_vals[0]:.4f}, {alpha_vals[-1]:.4f}]")
        print(f"  τₕ min={TH.min():.1f}  max={TH.max():.1f}  mean={TH.mean():.1f}")
        if not args.no_plot:
            try:
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(7, 5))
                im = ax.contourf(np.log10(PP), np.log10(AA), TH, levels=20, cmap="RdYlGn")
                plt.colorbar(im, ax=ax, label="Agency horizon τₕ (steps)")
                ax.set_xlabel("log₁₀ P (signal power)")
                ax.set_ylabel("log₁₀ α (noise growth rate)")
                ax.set_title(f"VTM Agency Horizon Surface  (ε={eps}b)")
                plt.tight_layout(); plt.show()
            except Exception as e:
                print(f"Plot skipped: {e}")
        if args.out:
            import pandas as pd
            rows = [{"P": P_vals[j], "alpha": alpha_vals[i], "tau_h": float(TH[i,j])}
                    for i in range(len(alpha_vals)) for j in range(len(P_vals))]
            pd.DataFrame(rows).to_csv(args.out, index=False)
            print(f"Saved → {args.out}")

    elif args.mode == "P":
        # Sweep signal power P
        P_vals = np.logspace(np.log10(args.P_min), np.log10(args.P_max), args.n_steps)
        tau_h_vals = np.maximum(0, (P_vals / denom - args.sigma0) / args.alpha)
        print(f"Agency horizon sweep: α={args.alpha}  σ²₀={args.sigma0}  ε={eps}b")
        print(f"{'P':>12}  {'tau_h':>10}")
        print("-" * 26)
        for P, t in zip(P_vals, tau_h_vals):
            print(f"{P:>12.4f}  {t:>10.2f}")

    if args.out:
        if args.mode == "alpha":
            df = pd.DataFrame({"alpha": alpha_vals, "tau_h": tau_h_vals})
        else:
            df = pd.DataFrame({"P": P_vals, "tau_h": tau_h_vals})
        df.to_csv(args.out, index=False)
        print(f"Saved → {args.out}")


def cmd_calibrate(args):
    """Re-derive SPHERE-16 calibration constants from fresh simulation.

    Runs the E8 flagship simulation and checks whether PEAK_PRED_BITS
    still agrees with the stored constant (2.233669 bits).
    """
    import numpy as np
    from fawp_index.constants import PEAK_PRED_BITS, TAU_PLUS_H_FLAGSHIP, TAU_F_FLAGSHIP
    from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor

    a     = args.a
    K     = args.K
    delta = args.delta
    n_trials = args.n_trials
    seed  = args.seed
    tau_max = args.tau_max

    print(f"FAWP Calibration Check — SPHERE-16 baseline")
    print(f"  a={a}  K={K}  Δ={delta}  n_trials={n_trials}  seed={seed}")
    print(f"  Stored PEAK_PRED_BITS = {PEAK_PRED_BITS}")
    print()

    rng = np.random.default_rng(seed)
    n_steps = 1000
    tau_arr = np.arange(1, tau_max + 1)
    pred_mi = np.zeros(len(tau_arr))

    print(f"  Simulating {n_trials} trials × {n_steps} steps…")
    all_x = []
    all_u = []
    for trial in range(n_trials):
        x = np.zeros(n_steps); u = np.zeros(n_steps)
        for t in range(1, n_steps):
            obs = x[max(0, t - delta)]
            u[t] = -K * obs
            x[t] = a * x[t-1] + u[t] + rng.normal(0, 0.1)
            if abs(x[t]) > 500: x[t] = np.sign(x[t]) * 500
        all_x.append(x); all_u.append(u)

    X = np.concatenate(all_x)
    U = np.concatenate(all_u)

    for ti, tau in enumerate(tau_arr):
        xp = X[:-tau]; yp = X[tau:]
        raw   = mi_from_arrays(xp, yp)
        floor = conservative_null_floor(xp, yp, args.n_null, 0.99)
        pred_mi[ti] = max(0.0, raw - floor)

    peak_idx  = int(np.argmax(pred_mi))
    peak_tau  = tau_arr[peak_idx]
    peak_bits = float(pred_mi[peak_idx])
    delta_pct = abs(peak_bits - PEAK_PRED_BITS) / PEAK_PRED_BITS * 100

    print(f"  Simulated peak pred MI = {peak_bits:.6f} bits at τ = {peak_tau}")
    print(f"  Stored   PEAK_PRED_BITS = {PEAK_PRED_BITS} bits")
    print(f"  Δ = {delta_pct:.2f}%")
    print()

    if delta_pct < 5.0:
        print(f"✅ CALIBRATION PASS — within 5% of stored constant")
    else:
        print(f"⚠️  CALIBRATION DRIFT — {delta_pct:.1f}% deviation from stored constant")
        print(f"   Consider updating PEAK_PRED_BITS = {peak_bits:.6f}")

    if args.out:
        import pandas as pd
        pd.DataFrame({"tau": tau_arr, "pred_mi": pred_mi}).to_csv(args.out, index=False)
        print(f"Saved → {args.out}")


def cmd_triple_horizon(args):
    """Run the E11-1 Triple Horizon benchmark: readout, steering, and functional horizons.

    Simulates the unstable latent process + degradable readout chain + viability cliff
    from the SPHERE_23 paper and reports all five horizon boundaries.
    """
    import numpy as np
    from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor
    from fawp_index.constants import ALPHA_A, ALPHA_A_SQ

    a = args.a; K = args.K; delta = args.delta
    rts  = args.readout_tau_scale   # readout decay scale
    shield = args.shield             # shielding factor [0,1]
    n = max(600, args.tau_max * 5)
    tau_arr = np.arange(1, args.tau_max + 1)
    rng = np.random.default_rng(args.seed)
    eps = args.epsilon

    print(f"Triple Horizon Benchmark — SPHERE_23 E11-1")
    print(f"  a={a}  K={K}  Δ={delta}  readout_scale={rts}  shield={shield}")
    print(f"  ε={eps}  τ_max={args.tau_max}  n={n}  seed={args.seed}")
    print()

    # Simulate latent process x with delayed controller
    x = np.zeros(n); u = np.zeros(n); r = np.zeros(n)
    for t in range(1, n):
        obs = x[max(0, t - delta)]
        u[t] = np.clip(-K * obs, -10, 10)
        x[t] = a * x[t-1] + u[t] + rng.normal(0, 0.1)
        if abs(x[t]) > 500: x[t] = np.sign(x[t]) * 500
        # Readout chain: r_t = x_t + noise, with shielding
        r[t] = (1.0 - shield) * x[t] + rng.normal(0, 0.5)

    # Compute steer MI, readout MI, pred MI per tau
    steer_mi   = np.zeros(len(tau_arr))
    readout_mi = np.zeros(len(tau_arr))
    pred_mi    = np.zeros(len(tau_arr))

    print(f"  Computing MI curves ({len(tau_arr)} delays)…")
    for ti, tau in enumerate(tau_arr):
        # Steering: u[t] → x[t+tau]
        xs = u[:-tau]; ys = x[tau:]
        steer_mi[ti]   = max(0.0, mi_from_arrays(xs, ys) -
                              conservative_null_floor(xs, ys, args.n_null, 0.99))
        # Readout: r[t] → x[t+tau] (degraded by tau-dependent noise)
        noisy_r = r[:n-tau] + rng.normal(0, 0.1 * tau / rts, n - tau)
        readout_mi[ti] = max(0.0, mi_from_arrays(noisy_r, x[tau:]) -
                              conservative_null_floor(noisy_r, x[tau:], args.n_null, 0.99))
        # Prediction: x[t] → x[t+tau]
        xp = x[:-tau]; yp = x[tau:]
        pred_mi[ti]    = max(0.0, mi_from_arrays(xp, yp) -
                              conservative_null_floor(xp, yp, args.n_null, 0.99))

    # Extract horizon boundaries
    def first_below(arr, thresh):
        for i, v in enumerate(arr):
            if v <= thresh: return int(tau_arr[i])
        return None

    tau_alpha    = first_below(steer_mi, ALPHA_A)
    tau_h_plus   = first_below(steer_mi, eps)
    tau_alpha2   = first_below(readout_mi, ALPHA_A_SQ)
    tau_readout  = first_below(readout_mi, eps)

    # Functional horizon: viability cliff (crash probability)
    x_fail = args.x_fail
    fail_rates = np.array([np.mean(np.abs(x[t:]) > x_fail) for t in tau_arr])
    tau_f_idx  = np.argmax(fail_rates >= 0.99)
    tau_f      = int(tau_arr[tau_f_idx]) if fail_rates[tau_f_idx] >= 0.99 else None

    print(f"  τα (steering wall)    : {tau_alpha  or 'not reached'}")
    print(f"  τ⁺ₕ (steering horizon): {tau_h_plus if tau_h_plus is not None else 'not reached'}")
    print(f"  τf  (functional)      : {tau_f if tau_f is not None else 'not reached'}")
    print(f"  τα² (residual floor)  : {tau_alpha2 or 'not reached'}")
    print(f"  τread (readout)       : {tau_readout or 'not reached'}")
    print()
    print(f"  SPHERE_23 E11-1 reference: τα=10  τ⁺ₕ=12  τf=29  τα²=32  τread=38")
    print()

    # Ordering
    vals = [(v, n) for v, n in [(tau_alpha,"τα"),(tau_h_plus,"τ⁺ₕ"),
                                  (tau_f,"τf"),(tau_alpha2,"τα²"),(tau_readout,"τread")]
            if v is not None]
    vals.sort()
    ordering = " < ".join(n for _, n in vals)
    print(f"  Detected ordering: {ordering}")
    e11_order = "τα < τ⁺ₕ < τf < τα² < τread"
    dominant = ordering == e11_order
    print(f"  Dominant E11 ordering: {'✅ YES' if dominant else '❌ NO (variant detected)'}")

    if args.out:
        import pandas as pd
        pd.DataFrame({"tau": tau_arr, "steer_mi": steer_mi,
                      "readout_mi": readout_mi, "pred_mi": pred_mi,
                      "fail_rate": fail_rates}).to_csv(args.out, index=False)
        print(f"Saved → {args.out}")


def cmd_changelog(args):
    """Print CHANGELOG entries, optionally filtered by version range."""
    import re
    from pathlib import Path

    from_ver = getattr(args, "from_ver", None)
    to_ver   = getattr(args, "to_ver", None)
    count_mode = getattr(args, "count", False)
    # Find CHANGELOG.md: repo root or installed data path
    candidates = [
        Path(__file__).parent.parent / "CHANGELOG.md",
        Path(__file__).parent.parent.parent / "CHANGELOG.md",
    ]
    cl_path = next((p for p in candidates if p.exists()), None)
    if cl_path is None:
        print("CHANGELOG.md not found. Clone the repo: git clone https://github.com/DrRalphClayton/fawp-index")
        return

    import fawp_index as fi
    version = args.version or fi.__version__
    src_cl = cl_path.read_text()

    # Find the entry for this version
    pattern = rf"(## v?{re.escape(version)}.*?)(?=\n## |\Z)"
    m = re.search(pattern, src_cl, re.DOTALL | re.IGNORECASE)
    if m:
        print(m.group(1).strip())
    else:
        print(f"No CHANGELOG entry found for v{version}")
        print(f"(CHANGELOG at: {cl_path})")

        # Show the most recent entry instead
        first = re.search(r"(## v?\d+\.\d+.*?)(?=\n## |\Z)", src_cl, re.DOTALL)
        if first:
            print("\nMost recent entry:")
            print(first.group(1).strip()[:800])


def cmd_scan(args):
    """One-liner FAWP scan: fetch data and print a plain-text result."""
    print(f"FAWP scan: {args.ticker} [{args.period}]")
    try:
        import yfinance as yf
    except ImportError:
        print("yfinance required: pip install yfinance"); return

    df = yf.download(args.ticker, period=args.period,
                     auto_adjust=True, progress=False)
    if df.empty:
        print(f"No data returned for {args.ticker}"); return

    from fawp_index.market import scan_fawp_market
    r = scan_fawp_market(df, ticker=args.ticker, epsilon=args.epsilon,
                         n_null=args.n_null, verbose=False)

    odw = getattr(r, "odw_result", r)
    fawp   = getattr(odw, "fawp_found",    False)
    gap    = float(getattr(odw, "peak_gap_bits", 0) or 0)
    tauh   = getattr(odw, "tau_h_plus", None)
    tauf   = getattr(odw, "tau_f",      None)
    start  = getattr(odw, "odw_start",  None)
    end    = getattr(odw, "odw_end",    None)
    n_bars = len(df)

    status = "🔴 FAWP DETECTED" if fawp else "✅ No FAWP"
    print(f"Status        : {status}")
    print(f"Ticker        : {args.ticker}  ({n_bars} bars, {args.period})")
    print(f"Peak gap      : {gap:.4f} bits")
    print(f"Agency horizon: τ⁺ₕ = {tauh if tauh is not None else 'not reached'}")
    print(f"Failure cliff : τf  = {tauf if tauf is not None else 'not reached'}")
    if start is not None and end is not None:
        print(f"ODW           : τ = {start}–{end}  (width {end - start} steps)")

    import fawp_index as fi
    sm = getattr(odw, "steer_mi_at_h", None)
    if sm is not None:
        if sm <= fi.ALPHA_A_SQ:
            tier = "null (below α²A)"
        elif sm <= fi.ALPHA_A:
            tier = "residual (αA ↔ α²A)"
        else:
            tier = "active steering"
        print(f"Steering tier : {tier}  (steer MI = {sm:.5f})")

    if args.out:
        import json
        with open(args.out, "w") as f:
            json.dump({"ticker": args.ticker, "period": args.period,
                       "fawp_found": bool(fawp), "peak_gap_bits": gap,
                       "tau_h_plus": tauh, "tau_f": tauf,
                       "odw_start": start, "odw_end": end,
                       "n_obs": n_bars}, f, indent=2)
        print(f"Saved → {args.out}")


def cmd_triple_horizon_sweep(args):
    """Sweep (a, K) grid — reproduces E11-2 portability sweep (SPHERE_23)."""
    import numpy as np
    from fawp_index.constants import ALPHA_A, ALPHA_A_SQ
    from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor

    a_vals = [float(x) for x in args.a_grid.split(",")]
    K_vals = [float(x) for x in args.K_grid.split(",")]
    n = max(500, args.tau_max * 5)
    tau_arr = np.arange(1, args.tau_max + 1)
    eps = args.epsilon; rts = args.readout_tau_scale

    def _run(a, K):
        rng = np.random.default_rng(args.seed)
        x = np.zeros(n); u = np.zeros(n); r = np.zeros(n)
        for t in range(1, n):
            obs = x[max(0, t - args.delta)]
            u[t] = np.clip(-K * obs, -10, 10)
            x[t] = a * x[t-1] + u[t] + rng.normal(0, 0.1)
            if abs(x[t]) > 500: x[t] = np.sign(x[t]) * 500
            r[t] = x[t] + rng.normal(0, 0.5)
        sm = np.zeros(len(tau_arr)); rm = np.zeros(len(tau_arr))
        for ti, tau in enumerate(tau_arr):
            xs = u[:-tau]; ys = x[tau:]
            sm[ti] = max(0.0, mi_from_arrays(xs, ys) - conservative_null_floor(xs, ys, 20, 0.99))
            nr = r[:n-tau] + rng.normal(0, 0.1*tau/rts, n-tau)
            rm[ti] = max(0.0, mi_from_arrays(nr, x[tau:]) - conservative_null_floor(nr, x[tau:], 20, 0.99))
        def _fb(arr, th):
            for i, v in enumerate(arr):
                if v <= th: return int(tau_arr[i])
            return None
        fr = np.array([np.mean(np.abs(x[t:]) > 500) for t in tau_arr])
        fi = np.argmax(fr >= 0.99)
        return {"ta": _fb(sm, ALPHA_A), "th": _fb(sm, eps),
                "tf": int(tau_arr[fi]) if fr[fi] >= 0.99 else None,
                "ta2": _fb(rm, ALPHA_A_SQ), "tr": _fb(rm, eps)}

    n_configs = len(a_vals) * len(K_vals)
    print("Triple Horizon sweep — " + str(n_configs) + " configs")
    hdr = "{:>6} {:>5} {:>5} {:>5} {:>5} {:>5} {:>7}  {}".format(
          "a","K","tau_a","tau_h","tau_f","tau_a2","tau_rd","order")
    print(hdr)
    print("-" * 60)
    rows = []
    for a in a_vals:
        for K in K_vals:
            res = _run(a, K)
            ta, th, tf, ta2, tr = res["ta"], res["th"], res["tf"], res["ta2"], res["tr"]
            pairs = [(v, n) for v, n in [(ta,"ta"),(th,"th"),(tf,"tf"),(ta2,"ta2"),(tr,"tr")] if v is not None]
            pairs.sort()
            order = "<".join(nm for _, nm in pairs)
            dom = order == "ta<th<tf<ta2<tr"
            flag = "OK" if dom else "!!"
            row = "{:>6.3f} {:>5.2f} {:>5} {:>5} {:>5} {:>5} {:>7}  {} {}".format(
                  a, K, str(ta), str(th), str(tf), str(ta2), str(tr), flag, order)
            print(row)
            rows.append({"a":a,"K":K,"tau_alpha":ta,"tau_h_plus":th,
                         "tau_f":tf,"tau_alpha2":ta2,"tau_readout":tr,
                         "dominant":dom})
    dom_rate = sum(1 for r in rows if r["dominant"]) / len(rows)
    print("")
    print("Dominant ordering rate: " + str(round(dom_rate*100,1)) + "% (E11-2 ref: 94.4%)")
    if args.out:
        import pandas as pd
        pd.DataFrame(rows).to_csv(args.out, index=False)
        print("Saved to " + args.out)


def cmd_steering(args):
    """Compute steering decay profile for a ticker vs SPHERE_23 αA / α²A thresholds."""
    try:
        import yfinance as yf
    except ImportError:
        print("yfinance required: pip install yfinance"); return

    import numpy as np
    from fawp_index.constants import ALPHA_A, ALPHA_A_SQ
    from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor
    from fawp_index.market import scan_fawp_market

    print(f"Steering profile: {args.ticker} [{args.period}]")
    df = yf.download(args.ticker, period=args.period, auto_adjust=True, progress=False)
    if df.empty:
        print(f"No data for {args.ticker}"); return

    r = scan_fawp_market(df, ticker=args.ticker, epsilon=args.epsilon,
                         n_null=args.n_null, verbose=False)
    odw = getattr(r, "odw_result", None)
    steer = getattr(odw, "steer_mi", np.array([])) if odw else np.array([])
    tau   = getattr(odw, "tau",      np.array([])) if odw else np.array([])

    if len(steer) == 0:
        print("No steering MI curve available — run a fresh scan first"); return

    decay = float(np.polyfit(tau, steer, 1)[0]) if len(steer) >= 3 else 0.0

    print(f"Decay rate     : {decay:+.6f} bits/τ")
    print(f"Peak steer MI  : {steer.max():.4f} bits  at τ={tau[steer.argmax()]}")
    print(f"Final steer MI : {steer[-1]:.4f} bits  at τ={tau[-1]}")
    print()

    # Tier classification at each delay
    wall_cross   = next((int(tau[i]) for i,v in enumerate(steer) if v <= ALPHA_A),   None)
    floor_cross  = next((int(tau[i]) for i,v in enumerate(steer) if v <= ALPHA_A_SQ), None)
    eps_cross    = next((int(tau[i]) for i,v in enumerate(steer) if v <= args.epsilon), None)

    print(f"αA  steering wall   (={ALPHA_A:.6f}) crossed at: τ = {wall_cross  or 'not reached'}")
    print(f"α²A residual floor  (={ALPHA_A_SQ:.2e}) crossed at: τ = {floor_cross or 'not reached'}")
    print(f"ε   op. horizon     (={args.epsilon:.4f})       crossed at: τ = {eps_cross   or 'not reached'}")
    print()

    # Per-tau table (sampled)
    step = max(1, len(tau) // 20)
    print(f"  {'τ':>5}  {'steer MI':>10}  {'tier'}")
    print(f"  {'—'*35}")
    for i in range(0, len(tau), step):
        v = steer[i]
        tier = ("null      " if v <= ALPHA_A_SQ else
                "residual  " if v <= ALPHA_A    else "active    ")
        print(f"  {tau[i]:>5.0f}  {v:>10.5f}  {tier}")

    if args.plot:
        try:
            import matplotlib.pyplot as plt
            fig, ax = plt.subplots(figsize=(8, 3))
            ax.plot(tau, steer, color="#4A7FCC", lw=1.5, label="Steering MI")
            ax.axhline(ALPHA_A,    color="#FF6B2B", ls="--", lw=1, label=f"αA={ALPHA_A:.5f}")
            ax.axhline(ALPHA_A_SQ, color="#D4AF37", ls=":",  lw=1, label=f"α²A={ALPHA_A_SQ:.2e}")
            ax.axhline(args.epsilon, color="#C0111A", ls="-.", lw=1, label=f"ε={args.epsilon}")
            if wall_cross:  ax.axvline(wall_cross,  color="#FF6B2B", ls="--", alpha=.5)
            if floor_cross: ax.axvline(floor_cross, color="#D4AF37", ls=":", alpha=.5)
            ax.set_xlabel("τ (delay steps)"); ax.set_ylabel("Steering MI (bits)")
            ax.set_title(f"{args.ticker} — Steering decay profile (SPHERE_23 thresholds)")
            ax.legend(fontsize=8); plt.tight_layout(); plt.show()
        except Exception as e:
            print(f"Plot skipped: {e}")


def cmd_project(args):
    """Project FAWP trajectory: estimate delays until tau_f using steering decay."""
    try:
        import yfinance as yf
    except ImportError:
        print("yfinance required: pip install yfinance"); return

    import numpy as np
    from fawp_index.constants import ALPHA_A, ALPHA_A_SQ
    from fawp_index.market import scan_fawp_market

    df = yf.download(args.ticker, period=args.period, auto_adjust=True, progress=False)
    if df.empty:
        print(f"No data for {args.ticker}"); return

    r = scan_fawp_market(df, ticker=args.ticker, epsilon=args.epsilon,
                         n_null=args.n_null, verbose=False)
    odw = getattr(r, "odw_result", None)
    if odw is None:
        print("No ODW result available"); return

    steer = getattr(odw, "steer_mi", np.array([]))
    tau   = getattr(odw, "tau",      np.array([]))
    pred  = getattr(odw, "pred_mi",  np.array([]))

    print(f"FAWP Forecast — {args.ticker} [{args.period}]")
    print(f"  FAWP active   : {'YES' if odw.fawp_found else 'NO'}")
    print(f"  Peak gap      : {float(odw.peak_gap_bits or 0):.4f} bits")
    print(f"  τ⁺ₕ           : {odw.tau_h_plus if odw.tau_h_plus is not None else 'not reached'}")
    print(f"  τf            : {odw.tau_f if odw.tau_f is not None else 'not reached'}")
    print()

    if len(steer) < 3:
        print("Insufficient MI curve data for projection."); return

    # Steering decay rate (bits / delay step)
    decay = float(np.polyfit(tau, steer, 1)[0])
    last_steer = float(steer[-1])
    last_tau   = int(tau[-1])

    # Project forward: when does steer MI cross ALPHA_A (wall), ALPHA_A_SQ (floor), epsilon?
    def delays_to_cross(current, rate, threshold):
        if rate >= 0 or current <= threshold:
            return None
        return int(np.ceil((current - threshold) / abs(rate)))

    to_wall   = delays_to_cross(last_steer, decay, ALPHA_A)
    to_floor  = delays_to_cross(last_steer, decay, ALPHA_A_SQ)
    to_eps    = delays_to_cross(last_steer, decay, args.epsilon)

    print(f"  Current steer MI : {last_steer:.5f} bits at τ={last_tau}")
    print(f"  Decay rate       : {decay:+.6f} bits/τ")
    print()
    print(f"  Projected delays to αA  wall  ({ALPHA_A:.5f}) : "
          f"{to_wall  if to_wall  is not None else 'already crossed'}")
    print(f"  Projected delays to α²A floor ({ALPHA_A_SQ:.2e}) : "
          f"{to_floor if to_floor is not None else 'already crossed'}")
    print(f"  Projected delays to ε horizon ({args.epsilon:.4f}) : "
          f"{to_eps   if to_eps   is not None else 'already crossed / stable'}")

    if to_eps is not None:
        abs_tau = last_tau + to_eps
        print(f"  → Estimated τf ≈ {abs_tau} (current τ={last_tau} + {to_eps} projected)")
    else:
        print(f"  → Steering already below ε — functional horizon may be imminent")


def cmd_report_batch(args):
    """Generate HTML reports for a list of tickers + an index page."""
    try:
        import yfinance as yf
    except ImportError:
        print("yfinance required: pip install yfinance"); return

    import json, os
    from pathlib import Path
    from fawp_index.market import scan_fawp_market
    from fawp_index.report_html import build_report_html

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    tickers = [t.strip().upper() for t in args.tickers.split(",") if t.strip()]
    print(f"Batch report: {len(tickers)} tickers -> {out_dir}")

    index_rows = []
    for ticker in tickers:
        print(f"  Scanning {ticker}...", end=" ", flush=True)
        try:
            df = yf.download(ticker, period=args.period, auto_adjust=True, progress=False)
            if df.empty:
                print("no data — skipped")
                continue
            r = scan_fawp_market(df, ticker=ticker, epsilon=args.epsilon,
                                  n_null=args.n_null, verbose=False)
            html = build_report_html(r)
            report_path = out_dir / f"{ticker}.html"
            report_path.write_text(html, encoding="utf-8")
            odw = getattr(r, "odw_result", r)
            gap = float(getattr(odw, "peak_gap_bits", 0) or 0)
            fawp = bool(getattr(odw, "fawp_found", False))
            index_rows.append({"ticker": ticker, "fawp": fawp,
                                "gap": gap, "file": f"{ticker}.html"})
            print(f"{'FAWP' if fawp else 'ok'} ({gap:.4f}b)")
        except Exception as e:
            print(f"ERROR: {e}")

    # Write index page
    rows_html = "".join(
        f'<tr><td><a href="{r["file"]}">{r["ticker"]}</a></td>'
        f'<td style="color:{"#C0111A" if r["fawp"] else "#1DB954"}">'
        f'{"FAWP" if r["fawp"] else "OK"}</td>'
        f'<td>{r["gap"]:.4f}</td></tr>'
        for r in sorted(index_rows, key=lambda x: -x["gap"])
    )
    index_html = (
        "<!DOCTYPE html><html><head><title>FAWP Batch Report</title>"
        "<style>body{font-family:sans-serif;max-width:600px;margin:2em auto}"
        "table{border-collapse:collapse;width:100%}"
        "td,th{border:1px solid #ddd;padding:.5em;text-align:left}"
        "th{background:#f5f5f5}</style></head><body>"
        f"<h1>FAWP Batch Report</h1>"
        f"<p>{len(index_rows)} tickers scanned | "
        f"{sum(1 for r in index_rows if r['fawp'])} in FAWP</p>"
        "<table><tr><th>Ticker</th><th>Status</th><th>Peak Gap (bits)</th></tr>"
        + rows_html + "</table></body></html>"
    )
    index_path = out_dir / "index.html"
    index_path.write_text(index_html, encoding="utf-8")
    print(f"Index -> {index_path}")
    print(f"Done: {len(index_rows)} reports in {out_dir}")


def cmd_recover(args):
    """E11-4 recovery intervention calculator (SPHERE_23).

    Estimates horizon recovery gains from early upstream intervention.
    Reference: E11-4 baseline (tau_lens=5, strength=0.8) achieves
    delta_tau_h=+11, delta_tau_readout=+14, delta_tau_f=+6.
    """
    from fawp_index.constants import (E11_TAU_PLUS_H, E11_TAU_F, E11_TAU_READOUT,
                                       E114_BEST_DELTA_TAU_H, E114_BEST_DELTA_READOUT,
                                       E114_BEST_DELTA_TAU_F, E114_BEST_DELTA_ALPHA2)

    tau_h = args.tau_h; tau_f = args.tau_f
    tau_rd = args.tau_readout; lens = args.lens_tau
    strength = args.strength; mode = args.mode

    lens_factor = max(0.0, 1.0 - (lens - 5) * 0.06)
    scale = lens_factor * (strength / 0.8)

    mode_gains = {
        "baseline":       (E114_BEST_DELTA_TAU_H, E114_BEST_DELTA_READOUT, E114_BEST_DELTA_TAU_F),
        "steering-first": (E114_BEST_DELTA_TAU_H, int(E114_BEST_DELTA_READOUT*0.57), int(E114_BEST_DELTA_TAU_F*0.67)),
        "readout-first":  (int(E114_BEST_DELTA_TAU_H*0.43), E114_BEST_DELTA_READOUT, int(E114_BEST_DELTA_TAU_F*0.83)),
        "joint":          (E114_BEST_DELTA_TAU_H, E114_BEST_DELTA_READOUT, E114_BEST_DELTA_TAU_F),
    }
    dh, dr, df = mode_gains.get(mode, mode_gains["baseline"])
    dh = int(dh * scale); dr = int(dr * scale); df = int(df * scale)
    da2 = int(E114_BEST_DELTA_ALPHA2 * scale)

    print(f"E11-4 Recovery Intervention — SPHERE_23")
    print(f"  Mode={mode}  tau_lens={lens}  strength={strength}  scale={scale:.2f}")
    print(f"  Current: tau_h={tau_h}  tau_f={tau_f}  tau_readout={tau_rd}")
    print()
    print(f"  Expected recovery:")
    print(f"    delta_tau_h       = +{dh}  ->  tau_h       ~= {tau_h + dh}")
    print(f"    delta_tau_f       = +{df}  ->  tau_f       ~= {tau_f + df}")
    print(f"    delta_tau_readout = +{dr}  ->  tau_readout ~= {tau_rd + dr}")
    print(f"    delta_tau_alpha2  = +{da2}")
    print()
    if lens > 15:
        print("  WARNING: Late intervention (lens>15) — E11-4 shows little or no recovery.")
    elif lens <= 5:
        print("  OPTIMAL: Early placement (lens<=5) — maximum recovery window.")
    else:
        print(f"  Partial recovery expected at lens={lens}.")


def cmd_doctor(args):
    """Diagnose local fawp-index install: deps, env vars, calibration constants."""
    import sys, os
    import fawp_index as fi

    ok_count = 0; warn_count = 0; fail_count = 0

    def check(label, passed, warn=False, detail=""):
        nonlocal ok_count, warn_count, fail_count
        if passed:
            print(f"  OK   {label}" + (f"  ({detail})" if detail else ""))
            ok_count += 1
        elif warn:
            print(f"  WARN {label}" + (f"  ({detail})" if detail else ""))
            warn_count += 1
        else:
            print(f"  FAIL {label}" + (f"  ({detail})" if detail else ""))
            fail_count += 1

    print(f"fawp-index doctor — v{fi.__version__}")
    print(f"Python {sys.version.split()[0]}  |  {sys.executable}")
    print()

    # Python version
    check("Python >= 3.10", sys.version_info >= (3, 10),
          detail=f"{sys.version_info.major}.{sys.version_info.minor}")

    # Core calibration constants
    for attr, expected, tol in [
        ("ALPHA_A",         0.007297,          1e-5),
        ("ALPHA_A_SQ",      5.325135447834e-5, 1e-10),
        ("E11_TAU_F",       29,                0),
        ("E11_TAU_READOUT", 38,                0),
        ("PEAK_PRED_BITS",  2.233669,          1e-4),
    ]:
        val = getattr(fi, attr, None)
        if val is None:
            check(f"constant {attr}", False, detail="missing")
        else:
            check(f"constant {attr} = {float(val):.6g}",
                  abs(float(val) - expected) <= tol)

    # Optional deps
    print()
    for pkg, import_name, required in [
        ("streamlit",   "streamlit",    False),
        ("yfinance",    "yfinance",     False),
        ("pyarrow",     "pyarrow",      False),
        ("folium",      "folium",       False),
        ("scipy",       "scipy",        False),
        ("numba",       "numba",        False),
        ("supabase",    "supabase",     False),
    ]:
        try:
            __import__(import_name)
            check(f"dep {pkg}", True)
        except ImportError:
            check(f"dep {pkg}", False, warn=not required,
                  detail="optional — pip install " + pkg)

    # Env vars
    print()
    for var, required in [
        ("FAWP_SUPABASE_URL",   False),
        ("FAWP_SUPABASE_TOKEN", False),
        ("FAWP_RESEND_KEY",     False),
        ("MPLBACKEND",          False),
    ]:
        val = os.environ.get(var)
        if var == "MPLBACKEND" and val and "inline" in val:
            check(f"env {var}", False, warn=True,
                  detail=f"={val!r} may cause matplotlib failures")
        elif val:
            check(f"env {var}", True, detail="set")
        else:
            check(f"env {var}", False, warn=True, detail="not set (optional)")

    print()
    print(f"Summary: {ok_count} OK  {warn_count} warnings  {fail_count} failures")
    if fail_count == 0 and warn_count == 0:
        print("Install is healthy.")
    elif fail_count == 0:
        print("Install is functional with warnings.")
    else:
        print("Install has failures — check above.")

    if getattr(args, "throughput", False):
        print()
        print("Throughput benchmark...")
        try:
            import time as _tb, numpy as _np_tb
            from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor
            from fawp_index.detection.odw import ODWDetector
            from fawp_index.constants import PERSISTENCE_RULE_M, PERSISTENCE_RULE_N
            _rng = _np_tb.random.default_rng(42)
            _n = 500; _reps = 10
            _t0 = _tb.perf_counter()
            for _ in range(_reps):
                _x = _np_tb.cumsum(_rng.normal(0,1,_n))
                _u = _np_tb.roll(_x, 20)
                _tau = _np_tb.arange(1, 21)
                _pm = _np_tb.zeros(20); _sm = _np_tb.zeros(20)
                for _i, _t in enumerate(_tau):
                    _xp,_yp = _x[:-_t], _x[_t:]
                    _pm[_i] = max(0, mi_from_arrays(_xp,_yp) -
                                     conservative_null_floor(_xp,_yp,10,.99))
                    _xs,_ys = _u[:-_t], _x[_t:]
                    _sm[_i] = max(0, mi_from_arrays(_xs,_ys) -
                                     conservative_null_floor(_xs,_ys,10,.99))
                ODWDetector(epsilon=0.01,
                            persistence_m=PERSISTENCE_RULE_M,
                            persistence_n=PERSISTENCE_RULE_N).detect(
                    tau=_tau, pred_corr=_pm, steer_corr=_sm,
                    fail_rate=_np_tb.zeros(20))
            _sps = round(_reps / (_tb.perf_counter() - _t0), 1)
            print("  Throughput: " + str(_sps) + " scans/sec")
            if _sps < 1.0:
                print("  WARNING: <1 scan/sec — possible regression")
            else:
                print("  OK: throughput nominal")
        except Exception as _te:
            print("  Throughput test failed: " + str(_te))


def cmd_init(args):
    """Scaffold a new FAWP project: config.yaml, scan.py, data/, CI workflow."""
    from pathlib import Path

    project = Path(args.project)
    if project.exists() and not args.force:
        print(f"Directory {project} already exists. Use --force to overwrite.")
        return

    (project/'data').mkdir(parents=True, exist_ok=True)
    (project/'.github'/'workflows').mkdir(parents=True, exist_ok=True)

    (project/'config.yaml').write_text(
        f"project: {project.name}\n"
        "epsilon: 0.01\n"
        "n_null: 50\ntau_max: 40\n"
        "tickers: [SPY, QQQ, GLD]\n"
        "timeframe: 1d\nperiod: 2y\n"
    )

    _scan_py = (
        '"""FAWP scan script. Generated by fawp-index init."""\n'
        'import yaml, sys\nfrom pathlib import Path\n'
        'sys.path.insert(0, str(Path(__file__).parent.parent))\n'
        'cfg = yaml.safe_load(open("config.yaml"))\n'
        'tickers = cfg.get("tickers", ["SPY"])\n'
        'epsilon = cfg.get("epsilon", 0.01)\n'
        'try:\n'
        '    import yfinance as yf\n'
        '    from fawp_index.market import scan_fawp_market\n'
        '    for ticker in tickers:\n'
        '        df = yf.download(ticker, period=cfg.get("period","2y"),\n'
        '                         auto_adjust=True, progress=False)\n'
        '        if df.empty: print(f"{ticker}: no data"); continue\n'
        '        r = scan_fawp_market(df, ticker=ticker, epsilon=epsilon, verbose=False)\n'
        '        odw = getattr(r,"odw_result",r)\n'
        '        print(f"{ticker}: {(\"FAWP\" if odw.fawp_found else \"OK\")}  gap={odw.peak_gap_bits:.4f}b")\n'
        'except ImportError:\n'
        '    print("yfinance required: pip install yfinance")\n'
    )
    (project/'scan.py').write_text(_scan_py)

    _wf = (
        f"name: FAWP Scan ({project.name})\n"
        "on:\n  schedule:\n    - cron: \"0 6 * * *\"\n  workflow_dispatch:\n"
        "jobs:\n  scan:\n    runs-on: ubuntu-latest\n    steps:\n"
        "      - uses: actions/checkout@v4\n"
        "      - uses: actions/setup-python@v5\n        with: {python-version: \"3.12\"}\n"
        "      - run: pip install fawp-index yfinance pyyaml -q\n"
        "      - run: python scan.py\n"
    )
    (project/'.github'/'workflows'/'fawp-scan.yml').write_text(_wf)

    (project/'README.md').write_text(
        f"# {project.name}\n\nFAWP scanner project.\n\n"
        "```\npip install fawp-index yfinance pyyaml\npython scan.py\n```\n"
    )

    print(f"Scaffolded: {project}/")
    for f in ["config.yaml","scan.py","data/",".github/workflows/fawp-scan.yml"]:
        print(f"  {project}/{f}")
    print(f"\nRun: cd {project} && pip install fawp-index yfinance pyyaml && python scan.py")


def cmd_sweep_tickers(args):
    """Triple Horizon sweep on live ticker data (E11-2 ordering check)."""
    try:
        import yfinance as yf
    except ImportError:
        print("yfinance required: pip install yfinance"); return
    import numpy as np
    from fawp_index.constants import ALPHA_A, ALPHA_A_SQ
    from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor
    from fawp_index.market import scan_fawp_market
    tickers = [t.strip().upper() for t in args.tickers.split(",") if t.strip()]
    print("Triple Horizon sweep: " + str(len(tickers)) + " tickers [" + args.period + "]")
    hdr = "{:>8} {:>6} {:>6} {:>6} {:>7}  {}".format(
          "Ticker","tau_a","tau_h","tau_f","tau_a2","Order")
    print("  " + hdr)
    print("  " + "-"*55)
    rows = []
    for ticker in tickers:
        try:
            df = yf.download(ticker, period=args.period, auto_adjust=True, progress=False)
            if df.empty:
                print("  " + ticker + ": no data"); continue
            r  = scan_fawp_market(df, ticker=ticker, epsilon=args.epsilon,
                                  n_null=args.n_null, verbose=False)
            odw   = getattr(r, "odw_result", r)
            steer = getattr(odw, "steer_mi", np.array([]))
            pred  = getattr(odw, "pred_mi",  np.array([]))
            tau   = getattr(odw, "tau",       np.array([]))
            if len(steer) < 3:
                print("  " + ticker + ": insufficient data"); continue
            def _fb(arr, th):
                for i, v in enumerate(arr):
                    if v <= th: return int(tau[i])
                return None
            ta  = _fb(steer, ALPHA_A)
            th  = _fb(steer, args.epsilon)
            ta2 = _fb(pred, ALPHA_A_SQ)
            tr  = _fb(pred, args.epsilon)
            tf  = odw.tau_f if odw.tau_f is not None else None
            pairs = sorted((v,n) for v,n in [(ta,"ta"),(th,"th"),(tf,"tf"),(ta2,"ta2"),(tr,"tr")] if v is not None)
            order = "<".join(n for _,n in pairs)
            dom = order == "ta<th<tf<ta2<tr"
            row = "{:>8} {:>6} {:>6} {:>6} {:>7}  {} {}".format(
                  ticker, str(ta), str(th), str(tf), str(ta2),
                  "OK" if dom else "!!",  order)
            print("  " + row)
            rows.append({"ticker":ticker,"tau_alpha":ta,"tau_h_plus":th,
                         "tau_f":tf,"tau_alpha2":ta2,"tau_readout":tr,"dominant":dom})
        except Exception as _e:
            print("  " + ticker + ": ERROR " + str(_e))
    if rows:
        dom_n = sum(1 for r in rows if r["dominant"])
        pct   = round(dom_n/len(rows)*100, 1)
        print("")
        print("Dominant ordering: " + str(dom_n) + "/" + str(len(rows)) + " (" + str(pct) + "%)")
        print("E11-2 simulation reference: 94.4%")
        if args.out:
            import pandas as pd
            pd.DataFrame(rows).to_csv(args.out, index=False)
            print("Saved -> " + args.out)


def cmd_confidence(args):
    """Bootstrap confidence interval on peak gap bits for a ticker."""
    try:
        import yfinance as yf
    except ImportError:
        print("yfinance required: pip install yfinance"); return
    import numpy as np
    from fawp_index.market import scan_fawp_market
    df = yf.download(args.ticker, period=args.period, auto_adjust=True, progress=False)
    if df.empty:
        print("No data for " + args.ticker); return
    n_boot = args.n_boot
    rng    = np.random.default_rng(args.seed)
    gaps   = []
    print("Bootstrap CI: " + args.ticker + "  n_boot=" + str(n_boot))
    for i in range(n_boot):
        # Block bootstrap: resample with replacement in blocks of ~20 bars
        n  = len(df)
        bs = max(1, n // 20)
        idx = np.concatenate([rng.integers(0, n-bs, size=n//bs) + np.arange(bs)
                               for _ in range(n//bs+1)])[:n]
        idx = np.clip(idx, 0, n-1)
        df_boot = df.iloc[idx].copy()
        df_boot.index = df.index[:n]
        try:
            r   = scan_fawp_market(df_boot, ticker=args.ticker,
                                    epsilon=args.epsilon, n_null=20, verbose=False)
            odw = getattr(r, "odw_result", r)
            gaps.append(float(odw.peak_gap_bits or 0))
        except Exception:
            pass
        if (i+1) % max(1, n_boot//5) == 0:
            print("  " + str(i+1) + "/" + str(n_boot) + " done...")
    if not gaps:
        print("No valid bootstrap samples"); return
    gaps = np.array(gaps)
    alpha = 1 - args.ci / 100
    lo = float(np.percentile(gaps, alpha/2*100))
    hi = float(np.percentile(gaps, (1-alpha/2)*100))
    med = float(np.median(gaps))
    mn  = float(gaps.mean())
    print("")
    print("Peak gap bits (" + str(int(args.ci)) + "% CI, n=" + str(len(gaps)) + "):")
    print("  Mean   : " + str(round(mn,4)) + " bits")
    print("  Median : " + str(round(med,4)) + " bits")
    print("  CI     : [" + str(round(lo,4)) + ", " + str(round(hi,4)) + "] bits")
    fawp_rate = round(np.mean(gaps > args.epsilon)*100, 1)
    print("  FAWP detection rate: " + str(fawp_rate) + "% of bootstrap samples")


def cmd_demo_notebook(args):
    """Generate an E8 demo Jupyter notebook and optionally open Colab."""
    import json, webbrowser
    from pathlib import Path
    import fawp_index as fi

    colab_badge = ("[![Open In Colab]"
                   "(https://colab.research.google.com/assets/colab-badge.svg)]"
                   "(https://colab.research.google.com/)")
    pip_cell_src = ["!pip install fawp-index -q\n"]
    code_src = [
        "import numpy as np\n",
        "from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor\n",
        "from fawp_index.detection.odw import ODWDetector\n",
        "from fawp_index.constants import PERSISTENCE_RULE_M, PERSISTENCE_RULE_N\n",
        "rng=np.random.default_rng(0); n=800; a=1.02; K=0.8; delta=20\n",
        "x=np.zeros(n); u=np.zeros(n)\n",
        "for t in range(1,n):\n",
        "    obs=x[max(0,t-delta)]\n",
        "    u[t]=np.clip(-K*obs,-10,10)\n",
        "    x[t]=a*x[t-1]+u[t]+rng.normal(0,0.1)\n",
        "    if abs(x[t])>500: x[t]=np.sign(x[t])*500\n",
        "tau=np.arange(1,41); pm=np.zeros(40); sm=np.zeros(40)\n",
        "for i,tau_v in enumerate(tau):\n",
        "    xp,yp=x[:-tau_v],x[tau_v:]\n",
        "    pm[i]=max(0,mi_from_arrays(xp,yp)-conservative_null_floor(xp,yp,30,.99))\n",
        "    xs,ys=u[:-tau_v],x[tau_v:]\n",
        "    sm[i]=max(0,mi_from_arrays(xs,ys)-conservative_null_floor(xs,ys,30,.99))\n",
        "odw=ODWDetector(epsilon=0.01,persistence_m=PERSISTENCE_RULE_M,\n",
        "                persistence_n=PERSISTENCE_RULE_N).detect(\n",
        "    tau=tau,pred_corr=pm,steer_corr=sm,fail_rate=np.zeros(40))\n",
        "print('FAWP:',odw.fawp_found,' gap:',round(float(odw.peak_gap_bits),4))"
    ]
    cells = [
        {"cell_type":"markdown","metadata":{},"source":[
            "# fawp-index E8 Demo\n",
            "v" + fi.__version__ + "\n",
            colab_badge
        ]},
        {"cell_type":"code","metadata":{},"source":pip_cell_src,
         "outputs":[],"execution_count":None},
        {"cell_type":"code","metadata":{},"source":code_src,
         "outputs":[],"execution_count":None},
    ]
    nb = {"nbformat":4,"nbformat_minor":5,
          "metadata":{"kernelspec":{"display_name":"Python 3",
                                    "language":"python","name":"python3"},
                      "language_info":{"name":"python"}},
          "cells":cells}
    out_path = Path(args.out)
    out_path.write_text(json.dumps(nb, indent=2))
    print("Notebook saved: " + str(out_path))
    if args.open:
        url = "https://colab.research.google.com/notebook#create=true"
        print("Opening Colab...")
        webbrowser.open(url)


def cmd_horizon_decay(args):
    """Track how tau_h_plus changes across rolling scans — detect structural decay."""
    try:
        import yfinance as yf
    except ImportError:
        print("yfinance required: pip install yfinance"); return
    import numpy as np
    from fawp_index.market import scan_fawp_market
    df = yf.download(args.ticker, period=args.period, auto_adjust=True, progress=False)
    if df.empty:
        print("No data for " + args.ticker); return
    n = len(df); results = []
    print("Horizon decay: " + args.ticker + "  window=" + str(args.window))
    for end in range(args.window, n, max(1, args.window // 10)):
        df_w = df.iloc[max(0,end-args.window):end]
        try:
            r   = scan_fawp_market(df_w, ticker=args.ticker,
                                    epsilon=args.epsilon, n_null=15, verbose=False)
            odw = getattr(r, "odw_result", r)
            results.append({"date": str(df.index[end-1])[:10],
                            "tau_h": odw.tau_h_plus,
                            "gap":   float(odw.peak_gap_bits or 0),
                            "fawp":  bool(odw.fawp_found)})
        except Exception:
            pass
    valid = [r for r in results if r["tau_h"] is not None]
    if not valid:
        print("No tau_h_plus values found in rolling windows."); return
    ths = [r["tau_h"] for r in valid]
    dates = [r["date"] for r in valid]
    print("  {:>12} {:>7} {:>10}".format("Date","tau_h","trend"))
    print("  " + "-"*35)
    for i, r in enumerate(valid):
        delta = ""
        if i > 0:
            d = r["tau_h"] - valid[i-1]["tau_h"]
            delta = ("+" if d >= 0 else "") + str(d)
        print("  {:>12} {:>7} {:>10}".format(r["date"], r["tau_h"], delta))
    # Trend summary
    slope = float(np.polyfit(range(len(ths)), ths, 1)[0]) if len(ths) >= 3 else 0
    print("")
    print("tau_h_plus trend: " + str(round(slope, 3)) + " steps/window")
    if slope < -0.5:
        print("  WARNING: tau_h_plus is shrinking — agency horizon contracting.")
    elif slope > 0.5:
        print("  OK: tau_h_plus is growing — conditions improving.")
    else:
        print("  STABLE: tau_h_plus roughly flat.")
    if args.out:
        import pandas as pd
        pd.DataFrame(results).to_csv(args.out, index=False)
        print("Saved -> " + args.out)


def cmd_significance_ticker(args):
    """Run permutation significance test on a real ticker's FAWP detection."""
    try:
        import yfinance as yf
    except ImportError:
        print("yfinance required: pip install yfinance"); return
    import numpy as np
    from fawp_index.market import scan_fawp_market
    from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor

    print("Significance test: " + args.ticker + "  n_perm=" + str(args.n_perm))
    df = yf.download(args.ticker, period=args.period, auto_adjust=True, progress=False)
    if df.empty:
        print("No data for " + args.ticker); return

    # Real detection
    r   = scan_fawp_market(df, ticker=args.ticker, epsilon=args.epsilon,
                            n_null=20, verbose=False)
    odw = getattr(r, "odw_result", r)
    real_gap = float(odw.peak_gap_bits or 0)
    print("  Real peak gap : " + str(round(real_gap, 5)) + " bits")
    print("  FAWP detected : " + str(odw.fawp_found))

    # Permutation test: shuffle returns, recompute gap
    close = df["Close"].values.ravel()
    returns = np.diff(np.log(close + 1e-9))
    rng = np.random.default_rng(args.seed)
    perm_gaps = []
    for i in range(args.n_perm):
        perm_ret = rng.permutation(returns)
        perm_close = np.exp(np.concatenate([[np.log(close[0])],
                            np.log(close[0]) + np.cumsum(perm_ret)]))
        import pandas as pd
        df_p = df.copy()
        df_p["Close"] = perm_close[:len(df)]
        try:
            rp   = scan_fawp_market(df_p, ticker=args.ticker,
                                     epsilon=args.epsilon, n_null=10, verbose=False)
            odwp = getattr(rp, "odw_result", rp)
            perm_gaps.append(float(odwp.peak_gap_bits or 0))
        except Exception:
            perm_gaps.append(0.0)
        if (i+1) % max(1, args.n_perm//5) == 0:
            print("  " + str(i+1) + "/" + str(args.n_perm) + " permutations done")

    perm_gaps = np.array(perm_gaps)
    p_val = float(np.mean(perm_gaps >= real_gap))
    print("")
    print("Permutation test results:")
    print("  Observed gap : " + str(round(real_gap, 5)) + " bits")
    print("  Perm mean    : " + str(round(float(perm_gaps.mean()), 5)) + " bits")
    print("  Perm max     : " + str(round(float(perm_gaps.max()), 5)) + " bits")
    print("  p-value      : " + str(round(p_val, 4)))
    sig = p_val < args.alpha
    print("  Significant  : " + str(sig) + " (alpha=" + str(args.alpha) + ")")
    if sig:
        print("  Result: FAWP detection is statistically significant.")
    else:
        print("  Result: Detection not significant at alpha=" + str(args.alpha))


def cmd_joint_intervention(args):
    """E11-3 joint intervention sweep: tau_h recovery vs lens placement (SPHERE_23)."""
    import numpy as np
    from fawp_index.constants import (E11_TAU_PLUS_H, E11_TAU_F, E11_TAU_READOUT,
                                       E114_BEST_DELTA_TAU_H, E114_BEST_DELTA_READOUT,
                                       E114_BEST_DELTA_TAU_F, E114_BEST_DELTA_ALPHA2)

    tau_h  = args.tau_h or E11_TAU_PLUS_H
    tau_f  = args.tau_f or E11_TAU_F
    tau_rd = args.tau_readout or E11_TAU_READOUT
    strength = args.strength

    print("E11-3 Joint Intervention Sweep (SPHERE_23)")
    print("  Mode: steering + readout simultaneously")
    print("  Baseline: tau_h=" + str(tau_h) +
          "  tau_f=" + str(tau_f) +
          "  tau_rd=" + str(tau_rd))
    print("")
    print("  {:>8} {:>10} {:>10} {:>10} {:>10}".format(
          "lens","d_tau_h","d_tau_f","d_tau_rd","score"))
    print("  " + "-"*55)

    best_score = -1; best_lens = None
    for lens in range(args.lens_min, args.lens_max + 1, args.step):
        lens_factor = max(0.0, 1.0 - (lens - 5) * 0.06)
        scale = lens_factor * (strength / 0.8)
        dh  = int(E114_BEST_DELTA_TAU_H    * scale)
        df  = int(E114_BEST_DELTA_TAU_F    * scale)
        dr  = int(E114_BEST_DELTA_READOUT  * scale)
        # Score: combined recovery weighted by research priorities
        score = round(0.5*dh + 0.3*dr + 0.2*df, 2)
        flag = " <-- optimal" if score > best_score else ""
        if score > best_score:
            best_score = score; best_lens = lens
        print("  {:>8} {:>10} {:>10} {:>10} {:>10}{}".format(
              lens, "+" + str(dh), "+" + str(df), "+" + str(dr), score, flag))

    print("")
    print("Optimal tau_lens = " + str(best_lens)
          + "  (score=" + str(best_score) + ")")
    print("E11-3 reference: tau_lens=5 maximises joint recovery")


def cmd_regime_duration(args):
    """Analyse FAWP episode duration distribution from backtest results."""
    try:
        import yfinance as yf
    except ImportError:
        print("yfinance required: pip install yfinance"); return
    import numpy as np
    from fawp_index.market import scan_fawp_market

    df = yf.download(args.ticker, period=args.period, auto_adjust=True, progress=False)
    if df.empty:
        print("No data for " + args.ticker); return

    n = len(df); in_fawp = False; entry_bar = None; episodes = []
    for end in range(args.window, n, max(1, args.step)):
        df_w = df.iloc[max(0,end-args.window):end]
        try:
            r   = scan_fawp_market(df_w, ticker=args.ticker,
                                    epsilon=args.epsilon, n_null=15, verbose=False)
            odw = getattr(r, "odw_result", r)
            fawp = bool(odw.fawp_found)
            gap  = float(odw.peak_gap_bits or 0)
            if fawp and not in_fawp:
                entry_bar = end; in_fawp = True
                entry_gap = gap
            elif not fawp and in_fawp:
                duration = end - entry_bar
                episodes.append({"duration": duration, "entry_gap": entry_gap})
                in_fawp = False
        except Exception:
            pass
    if in_fawp and entry_bar is not None:
        episodes.append({"duration": n - entry_bar, "entry_gap": entry_gap})

    print("Regime duration distribution: " + args.ticker)
    print("  Episodes found: " + str(len(episodes)))
    if not episodes:
        print("  No FAWP episodes detected in backtest."); return

    durations = np.array([e["duration"] for e in episodes])
    gaps      = np.array([e["entry_gap"] for e in episodes])
    print("  Duration (bars):")
    print("    Mean   : " + str(round(float(durations.mean()), 1)))
    print("    Median : " + str(round(float(np.median(durations)), 1)))
    print("    Min    : " + str(int(durations.min())))
    print("    Max    : " + str(int(durations.max())))
    print("    Std    : " + str(round(float(durations.std()), 1)))
    corr = float(np.corrcoef(gaps, durations)[0,1]) if len(episodes) >= 3 else 0
    print("  Gap-duration correlation: " + str(round(corr, 3)))
    if corr > 0.4:
        print("  Note: larger entry gaps tend to produce longer episodes.")
    elif corr < -0.4:
        print("  Note: larger entry gaps tend to produce shorter episodes.")
    if args.out:
        import pandas as pd
        pd.DataFrame(episodes).to_csv(args.out, index=False)
        print("Saved -> " + args.out)


def cmd_agency_sensitivity(args):
    """Sensitivity analysis: how does tau_h change as P and alpha vary independently?"""
    import numpy as np
    from fawp_index.constants import E11_TAU_PLUS_H

    eps  = args.epsilon
    sig0 = args.sigma0
    denom = 2**(2*eps) - 1

    n_pts = 30
    P_vals     = np.logspace(np.log10(args.p_min), np.log10(args.p_max), n_pts)
    alpha_vals = np.logspace(np.log10(args.a_min), np.log10(args.a_max), n_pts)

    print("Agency horizon sensitivity (VTM Eq.15-16)")
    print("  eps=" + str(eps) + "  sigma0=" + str(sig0))
    print()

    # Sensitivity to P (holding alpha fixed at midpoint)
    a_mid = float(np.sqrt(args.a_min * args.a_max))
    print("  tau_h vs P  (alpha=" + str(round(a_mid, 4)) + " fixed):")
    p_ths = [max(0, (P/denom - sig0)/a_mid) for P in P_vals]
    p_slope = float(np.polyfit(np.log10(P_vals), p_ths, 1)[0])
    for i in [0, n_pts//4, n_pts//2, 3*n_pts//4, n_pts-1]:
        print("    P=" + str(round(float(P_vals[i]),3)) +
              "  tau_h=" + str(round(p_ths[i],1)))
    print("  Slope (log10 P): " + str(round(p_slope, 2)) + " steps/decade")

    print()

    # Sensitivity to alpha (holding P fixed at midpoint)
    p_mid = float(np.sqrt(args.p_min * args.p_max))
    print("  tau_h vs alpha  (P=" + str(round(p_mid, 3)) + " fixed):")
    a_ths = [max(0, (p_mid/denom - sig0)/a) for a in alpha_vals]
    a_slope = float(np.polyfit(np.log10(alpha_vals), a_ths, 1)[0])
    for i in [0, n_pts//4, n_pts//2, 3*n_pts//4, n_pts-1]:
        print("    alpha=" + str(round(float(alpha_vals[i]),5)) +
              "  tau_h=" + str(round(a_ths[i],1)))
    print("  Slope (log10 alpha): " + str(round(a_slope, 2)) + " steps/decade")

    print()
    dominant = "P" if abs(p_slope) > abs(a_slope) else "alpha"
    print("  tau_h is most sensitive to: " + dominant)
    print("  (E11-1 reference tau_h=" + str(E11_TAU_PLUS_H) + ")")


def cmd_oats(args):
    """Run OATS (Ordered Arrival Test Suite) — all canonical cases vs stored constants."""
    from fawp_index.constants import (TAU_PLUS_H_FLAGSHIP, TAU_F_FLAGSHIP,
                                       PEAK_PRED_BITS, PERSISTENCE_RULE_M,
                                       PERSISTENCE_RULE_N)
    import numpy as np
    from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor
    from fawp_index.detection.odw import ODWDetector

    tol_tau = args.tau_tol
    tol_bits = args.bits_tol

    # Canonical E8 simulation
    def _run_e8(seed=0):
        rng = np.random.default_rng(seed)
        n=800; a=1.02; K=0.8; delta=20
        x=np.zeros(n); u=np.zeros(n)
        for t in range(1,n):
            obs=x[max(0,t-delta)]
            u[t]=np.clip(-K*obs,-10,10)
            x[t]=a*x[t-1]+u[t]+rng.normal(0,0.1)
            if abs(x[t])>500: x[t]=np.sign(x[t])*500
        tau=np.arange(1,41); pm=np.zeros(40); sm=np.zeros(40)
        for i,tau_v in enumerate(tau):
            xp,yp=x[:-tau_v],x[tau_v:]
            pm[i]=max(0,mi_from_arrays(xp,yp)-conservative_null_floor(xp,yp,30,.99))
            xs,ys=u[:-tau_v],x[tau_v:]
            sm[i]=max(0,mi_from_arrays(xs,ys)-conservative_null_floor(xs,ys,30,.99))
        odw=ODWDetector(epsilon=0.01,persistence_m=PERSISTENCE_RULE_M,
                        persistence_n=PERSISTENCE_RULE_N).detect(
            tau=tau,pred_corr=pm,steer_corr=sm,fail_rate=np.zeros(40))
        return odw, float(pm.max())

    print("OATS — Ordered Arrival Test Suite")
    print("  {:>30} {:>8} {:>8} {:>6} {:>8}".format(
          "Test","Got","Ref","Delta","Status"))
    print("  " + "-"*65)

    passed=0; failed=0
    odw, peak_bits = _run_e8(args.seed)

    checks = [
        ("E8 FAWP detected",       bool(odw.fawp_found),     True,   0,         0),
        ("E8 tau_h_plus",          odw.tau_h_plus,           TAU_PLUS_H_FLAGSHIP, tol_tau, 0),
        ("E8 tau_f",               odw.tau_f,                TAU_F_FLAGSHIP,      tol_tau, 0),
        ("E8 peak_pred_bits",      round(peak_bits,3),       round(PEAK_PRED_BITS,3), 0, tol_bits),
    ]
    for label, got, ref, tol_i, tol_b in checks:
        if isinstance(ref, bool):
            ok = got == ref
            delta = "—"
        elif tol_b > 0:
            ok = abs((got or 0) - ref) <= tol_b
            delta = str(round((got or 0)-ref, 4))
        else:
            ok = (got is not None) and abs(got - ref) <= tol_i
            delta = str((got or 0) - ref)
        status = "PASS" if ok else "FAIL"
        if ok: passed+=1
        else:  failed+=1
        print("  {:>30} {:>8} {:>8} {:>6} {:>8}".format(
              label, str(got), str(ref), str(delta), status))

    print("")
    print("OATS result: " + str(passed) + " passed  " + str(failed) + " failed")
    if failed == 0:
        print("ALL CANONICAL CASES PASS")
    else:
        print("FAILURES DETECTED — check calibration constants")
    import sys; sys.exit(0 if failed == 0 else 1)


def cmd_null_dist(args):
    """Plot null permutation distribution vs real gap for a ticker."""
    try:
        import yfinance as yf
    except ImportError:
        print("yfinance required: pip install yfinance"); return
    import numpy as np
    from fawp_index.market import scan_fawp_market

    df = yf.download(args.ticker, period=args.period, auto_adjust=True, progress=False)
    if df.empty:
        print("No data for " + args.ticker); return

    r   = scan_fawp_market(df, ticker=args.ticker, epsilon=args.epsilon,
                            n_null=20, verbose=False)
    odw = getattr(r, "odw_result", r)
    real_gap = float(odw.peak_gap_bits or 0)

    close   = df["Close"].values.ravel()
    returns = np.diff(np.log(close + 1e-9))
    rng     = np.random.default_rng(args.seed)
    perm_gaps = []
    print("Running " + str(args.n_perm) + " permutations...")
    for i in range(args.n_perm):
        perm_ret = rng.permutation(returns)
        perm_close = np.exp(np.concatenate([[np.log(close[0])],
            np.log(close[0]) + np.cumsum(perm_ret)]))
        import pandas as pd
        df_p = df.copy(); df_p["Close"] = perm_close[:len(df)]
        try:
            rp  = scan_fawp_market(df_p, ticker=args.ticker,
                                    epsilon=args.epsilon, n_null=10, verbose=False)
            perm_gaps.append(float(getattr(getattr(rp,"odw_result",rp),"peak_gap_bits",0) or 0))
        except Exception:
            perm_gaps.append(0.0)

    perm_gaps = np.array(perm_gaps)
    p_val = float(np.mean(perm_gaps >= real_gap))
    print("Real gap   : " + str(round(real_gap,5)) + " bits")
    print("Null mean  : " + str(round(float(perm_gaps.mean()),5)) + " bits")
    print("p-value    : " + str(round(p_val,4)))

    if args.plot:
        try:
            import matplotlib
            matplotlib.use("Agg", force=True)
            import matplotlib.pyplot as plt
            fig, ax = plt.subplots(figsize=(8,3))
            ax.hist(perm_gaps, bins=30, color="#4A7FCC", alpha=0.7, label="Null distribution")
            ax.axvline(real_gap, color="#C0111A", lw=2,
                      label="Observed gap=" + str(round(real_gap,4)) + "b  p=" + str(round(p_val,4)))
            ax.set_xlabel("Peak gap bits"); ax.set_ylabel("Count")
            ax.set_title(args.ticker + " — Null permutation distribution")
            ax.legend(fontsize=8)
            plt.tight_layout()
            out = args.out or (args.ticker + "_null_dist.png")
            plt.savefig(out, dpi=120, bbox_inches="tight")
            print("Saved -> " + out)
            plt.close(fig)
        except Exception as e:
            print("Plot failed: " + str(e))


def cmd_verify_e8(args):
    """E8 end-to-end integration check — runs inline, no pytest needed."""
    import sys, numpy as np
    from fawp_index.constants import (TAU_PLUS_H_FLAGSHIP, TAU_F_FLAGSHIP,
                                       PEAK_PRED_BITS, PERSISTENCE_RULE_M,
                                       PERSISTENCE_RULE_N)
    from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor
    from fawp_index.detection.odw import ODWDetector

    print("fawp-index verify --e8  (E8 integration check)")
    rng=np.random.default_rng(0); n=800; a=1.02; K=0.8; delta=20
    x=np.zeros(n); u=np.zeros(n)
    for t in range(1,n):
        obs=x[max(0,t-delta)]
        u[t]=np.clip(-K*obs,-10,10)
        x[t]=a*x[t-1]+u[t]+rng.normal(0,0.1)
        if abs(x[t])>500: x[t]=np.sign(x[t])*500
    tau=np.arange(1,41); pm=np.zeros(40); sm=np.zeros(40)
    for i,tv in enumerate(tau):
        xp,yp=x[:-tv],x[tv:]
        pm[i]=max(0,mi_from_arrays(xp,yp)-conservative_null_floor(xp,yp,30,.99))
        xs,ys=u[:-tv],x[tv:]
        sm[i]=max(0,mi_from_arrays(xs,ys)-conservative_null_floor(xs,ys,30,.99))
    odw=ODWDetector(epsilon=0.01,persistence_m=PERSISTENCE_RULE_M,
                    persistence_n=PERSISTENCE_RULE_N).detect(
        tau=tau,pred_corr=pm,steer_corr=sm,fail_rate=np.zeros(40))
    peak=float(pm.max())
    tol_tau=5; tol_bits=0.15
    checks=[
        ("FAWP detected",   bool(odw.fawp_found),   True,   0,       0),
        ("tau_h_plus",      odw.tau_h_plus,          TAU_PLUS_H_FLAGSHIP, tol_tau, 0),
        ("tau_f",           odw.tau_f,               TAU_F_FLAGSHIP,      tol_tau, 0),
        ("peak_pred_bits",  round(peak,3),           round(PEAK_PRED_BITS,3), 0,  tol_bits),
    ]
    fail_n=0
    for label,got,ref,tol_i,tol_b in checks:
        if isinstance(ref,bool): ok=got==ref
        elif tol_b>0:            ok=abs((got or 0)-ref)<=tol_b
        else:                    ok=(got is not None) and abs(got-ref)<=tol_i
        status="PASS" if ok else "FAIL"
        if not ok: fail_n+=1
        print("  " + ("OK  " if ok else "FAIL") + " " + label +
              "  got=" + str(got) + "  ref=" + str(ref))
    print()
    print("E8 verify: " + ("PASS" if fail_n==0 else str(fail_n)+" FAILURE(S)"))
    sys.exit(0 if fail_n==0 else 1)


def cmd_nonlinear_sweep(args):
    """E11-5: Triple Horizon portability across nonlinear state families."""
    import numpy as np
    from fawp_index.constants import ALPHA_A, ALPHA_A_SQ
    from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor
    from fawp_index.detection.odw import ODWDetector
    from fawp_index.constants import PERSISTENCE_RULE_M, PERSISTENCE_RULE_N

    families = args.families.split(",") if args.families else ["linear","cubic","coupled"]
    tau_arr = np.arange(1, args.tau_max + 1)
    eps = args.epsilon

    def _run(family, seed=0):
        rng = np.random.default_rng(seed)
        n = max(600, args.tau_max * 8)
        x = np.zeros(n); u = np.zeros(n)
        for t in range(1, n):
            obs = x[max(0, t-20)]
            u[t] = np.clip(-0.8*obs, -10, 10)
            if family == "linear":
                x[t] = 1.02*x[t-1] + u[t] + rng.normal(0, 0.1)
            elif family == "cubic":
                x[t] = 1.02*x[t-1] - 0.001*x[t-1]**3 + u[t] + rng.normal(0, 0.1)
            elif family == "coupled":
                y = x[t-1]*0.3
                x[t] = 1.02*x[t-1] + y + u[t] + rng.normal(0, 0.1)
            if abs(x[t]) > 500: x[t] = np.sign(x[t])*500
        pm = np.zeros(len(tau_arr)); sm = np.zeros(len(tau_arr))
        for ti, tau in enumerate(tau_arr):
            xp,yp = x[:-tau],x[tau:]
            pm[ti] = max(0.0, mi_from_arrays(xp,yp)-conservative_null_floor(xp,yp,20,.99))
            xs,ys = u[:-tau],x[tau:]
            sm[ti] = max(0.0, mi_from_arrays(xs,ys)-conservative_null_floor(xs,ys,20,.99))
        odw = ODWDetector(epsilon=eps,persistence_m=PERSISTENCE_RULE_M,
                          persistence_n=PERSISTENCE_RULE_N).detect(
            tau=tau_arr,pred_corr=pm,steer_corr=sm,fail_rate=np.zeros(len(tau_arr)))
        def _fb(arr, th):
            for i,v in enumerate(arr):
                if v <= th: return int(tau_arr[i])
            return None
        return {"ta":_fb(sm,ALPHA_A),"th":_fb(sm,eps),
                "tf":odw.tau_f,"ta2":_fb(pm,ALPHA_A_SQ),"tr":_fb(pm,eps),
                "fawp":odw.fawp_found}

    print("E11-5 Nonlinear Portability Sweep  families=" + str(families))
    print("  {:>10} {:>6} {:>6} {:>6} {:>6} {:>8} {:>8}  {}".format(
          "family","tau_a","tau_h","tau_f","ta2","tau_rd","FAWP","order"))
    print("  " + "-"*65)
    dom_n = 0; total = 0
    for fam in families:
        results = []
        for seed in range(args.seeds):
            try: results.append(_run(fam, seed))
            except Exception as _e: pass
        if not results: continue
        import collections
        dom_orders = 0
        for res in results:
            ta,th,tf,ta2,tr = res["ta"],res["th"],res["tf"],res["ta2"],res["tr"]
            pairs = sorted((v,n) for v,n in [(ta,"ta"),(th,"th"),(tf,"tf"),(ta2,"ta2"),(tr,"tr")] if v)
            order = "<".join(nm for _,nm in pairs)
            if order == "ta<th<tf<ta2<tr": dom_orders += 1
        dom_rate = dom_orders / len(results)
        dom_n += dom_orders; total += len(results)
        res0 = results[0]
        print("  {:>10} {:>6} {:>6} {:>6} {:>6} {:>8} {:>8}  {:.0%}".format(
              fam, str(res0["ta"]), str(res0["th"]), str(res0["tf"]),
              str(res0["ta2"]), str(res0["tr"]),
              "FAWP" if res0["fawp"] else "ok", dom_rate))
    overall = dom_n/total if total else 0
    print("")
    print("Dominant ordering overall: " + str(dom_n) + "/" + str(total)
          + " (" + str(round(overall*100,1)) + "%)")
    print("E11-5 reference: dominant ordering survives linear, cubic, and coupled families.")


def cmd_leri_shield(args):
    """E-LERI-3: Shielding sweep — record gain attenuation collapses detectability to null."""
    import numpy as np
    from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor

    gains = [float(g) for g in args.gains.split(",")]
    tau_arr = np.arange(0, args.tau_max + 1)
    sig0 = args.sigma0; alpha = args.alpha; P = args.P
    rng  = np.random.default_rng(args.seed)
    n    = args.n

    print("E-LERI-3 Shielding sweep  P=" + str(P)
          + " sigma0=" + str(sig0) + " alpha=" + str(alpha))
    print("  {:>6} {:>10} {:>10} {:>12}".format(
          "gain","S_peak","tau_h","detectable"))
    print("  " + "-"*45)

    rows = []
    for gain in gains:
        scores = []
        X = rng.normal(0, 1, n)
        for tau in tau_arr:
            sigma2 = sig0 + alpha * tau
            R = X + rng.normal(0, np.sqrt(sig0), n)
            Yraw = R * gain + rng.normal(0, np.sqrt(sigma2), n)
            Dt  = Yraw + rng.normal(0, 0.1, n)
            null_Dt = rng.permutation(Dt)
            mi_obs  = max(0.0, mi_from_arrays(X, Dt))
            mi_null = max(0.0, mi_from_arrays(X, null_Dt))
            score   = max(0.0, mi_obs - mi_null)
            scores.append(score)
        scores = np.array(scores)
        s_peak = float(scores.max())
        above_eps = np.where(scores >= args.epsilon)[0]
        tau_h = int(tau_arr[above_eps[-1]]) if len(above_eps) else 0
        detectable = s_peak >= args.epsilon
        print("  {:>6.2f} {:>10.5f} {:>10} {:>12}".format(
              gain, s_peak, str(tau_h) if detectable else "--",
              "YES" if detectable else "NO (collapsed)"))
        rows.append({"gain":gain,"s_peak":s_peak,"tau_h":tau_h,"detectable":detectable})
    print("")
    collapsed = sum(1 for r in rows if not r["detectable"])
    print("Shielding collapse: " + str(collapsed) + "/" + str(len(rows)) + " gains collapsed detectability.")
    print("E-LERI-3: shielding drives S(tau) to null. Dark Room Test: gain=0 => no detection.")
    if args.out:
        import pandas as pd
        pd.DataFrame(rows).to_csv(args.out, index=False)
        print("Saved -> " + args.out)


def cmd_leri_shield(args):
    """E-LERI-3: Sweep record gain attenuation and show detectability collapse (LERI paper Fig.4)."""
    import numpy as np
    from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor

    P     = args.P
    sig0  = args.sigma0
    alpha = args.alpha_noise
    tau_arr = np.arange(0, args.tau_max + 1)
    eps_score = args.eps_score
    gains = [float(g) for g in args.gains.split(",")]
    rng = np.random.default_rng(args.seed)
    n_samples = max(300, args.tau_max * 4)

    print("E-LERI-3 Shielding Sweep (LERI paper Fig.4)")
    print("  P=" + str(P) + "  sigma0=" + str(sig0)
          + "  alpha=" + str(alpha) + "  gains=" + args.gains)
    print()

    results = {}
    for gain in gains:
        scores = []
        for tau in tau_arr:
            if tau == 0:
                scores.append(0.0); continue
            # X -> R (record with gain attenuation) -> Y_tau -> D_tau
            X = rng.normal(0, 1, n_samples)
            R = gain * X + rng.normal(0, sig0**0.5, n_samples)  # shielded record
            noise_tau = np.sqrt(sig0 + alpha * tau)
            D_tau = R + rng.normal(0, noise_tau, n_samples)
            mi = max(0.0, mi_from_arrays(X, D_tau) -
                     conservative_null_floor(X, D_tau, 20, 0.99))
            scores.append(mi)
        scores = np.array(scores)
        # Persistence gate m=5
        persist = np.convolve(scores > eps_score,
                              np.ones(5)/5, mode="same") >= 0.6
        horizon = next((int(tau_arr[i]) for i in range(len(tau_arr))
                        if not persist[i] and scores[i] <= eps_score), None)
        results[gain] = {"scores": scores, "horizon": horizon}
        status = ("collapsed" if scores[10:].mean() < eps_score * 2
                  else "detectable")
        print("  gain=" + str(gain) + "  horizon=" + str(horizon)
              + "  status=" + status)

    print()
    print("Gain=1.0 is unshielded reference. Gain=0.0 = full shielding -> null.")
    if args.out:
        import pandas as pd
        rows = []
        for gain, res in results.items():
            for tau, score in zip(tau_arr, res["scores"]):
                rows.append({"gain":gain,"tau":int(tau),"score":float(score)})
        pd.DataFrame(rows).to_csv(args.out, index=False)
        print("Saved -> " + args.out)


def cmd_reproduce(args):
    """Reproduce a published paper figure from bundled data or inline simulation."""
    import numpy as np
    from pathlib import Path as _P

    exp = args.experiment.lower().replace("-","_")
    out = args.out or (exp + "_reproduced.png")

    if exp in ("e8", "e8_fig1"):
        print("Reproducing E8 Fig.1 (leverage gap + FAWP resonance peak)...")
        from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor
        from fawp_index.detection.odw import ODWDetector
        from fawp_index.constants import PERSISTENCE_RULE_M, PERSISTENCE_RULE_N
        rng=np.random.default_rng(0); n=800; a=1.02; K=0.8; delta=20
        x=np.zeros(n); u=np.zeros(n)
        for t in range(1,n):
            obs=x[max(0,t-delta)]
            u[t]=np.clip(-K*obs,-10,10)
            x[t]=a*x[t-1]+u[t]+rng.normal(0,0.1)
            if abs(x[t])>500: x[t]=np.sign(x[t])*500
        tau=np.arange(1,81); pm=np.zeros(80); sm=np.zeros(80)
        for i,tv in enumerate(tau):
            xp,yp=x[:-tv],x[tv:]
            pm[i]=max(0,mi_from_arrays(xp,yp)-conservative_null_floor(xp,yp,30,.99))
            xs,ys=u[:-tv],x[tv:]
            sm[i]=max(0,mi_from_arrays(xs,ys)-conservative_null_floor(xs,ys,30,.99))
        odw=ODWDetector(epsilon=0.01,persistence_m=PERSISTENCE_RULE_M,
                        persistence_n=PERSISTENCE_RULE_N).detect(
            tau=tau,pred_corr=pm,steer_corr=sm,fail_rate=np.zeros(80))
        try:
            import matplotlib; matplotlib.use("Agg",force=True)
            import matplotlib.pyplot as plt
            fig,ax=plt.subplots(figsize=(10,4))
            ax.plot(tau,pm,color="#FF6B2B",lw=1.8,label="Predictive coupling I(D;X_t+τ)")
            ax.plot(tau,sm,color="#4A7FCC",lw=1.8,ls="--",label="Steering coupling I(A;X_t+τ)")
            ax.fill_between(tau,pm,sm,where=(pm>sm),alpha=0.18,color="#C0111A",label="Leverage gap (FAWP)")
            if odw.tau_h_plus: ax.axvline(odw.tau_h_plus,color="#D4AF37",ls=":",lw=1.5,label=f"τ⁺ₕ={odw.tau_h_plus}")
            ax.axhline(0.01,color="#888",ls=":",lw=1,label="ε=0.01 bits")
            ax.set_xlabel("Latency τ (time steps)"); ax.set_ylabel("MI (bits)")
            ax.set_title("E8: Leverage Gap + FAWP Resonance Peak (Δ=20)")
            ax.legend(fontsize=8); fig.tight_layout()
            fig.savefig(out,dpi=150,bbox_inches="tight"); plt.close(fig)
            print("Saved -> " + out)
        except ImportError:
            print("matplotlib required: pip install matplotlib")

    elif exp in ("leri_2","e_leri_2","leri2"):
        print("Reproducing E-LERI-2 (record chain detectability)...")
        from fawp_index.core.estimators import mi_from_arrays, conservative_null_floor
        rng=np.random.default_rng(0); n=800
        P=1.0; sig0=1.0; alpha_n=0.25; tau_arr=np.arange(0,350)
        mi_vals=[]; null_vals=[]
        for tau in tau_arr:
            if tau==0: mi_vals.append(0.0); null_vals.append(0.0); continue
            X=rng.normal(0,1,n); R=X+rng.normal(0,sig0**0.5,n)
            D=R+rng.normal(0,np.sqrt(sig0+alpha_n*tau),n)
            mi=max(0,mi_from_arrays(X,D)-conservative_null_floor(X,D,20,.99))
            X_sh=rng.permutation(X)
            null=max(0,mi_from_arrays(X_sh,D)-conservative_null_floor(X_sh,D,20,.99))
            mi_vals.append(mi); null_vals.append(null)
        try:
            import matplotlib; matplotlib.use("Agg",force=True)
            import matplotlib.pyplot as plt
            fig,ax=plt.subplots(figsize=(9,3.5))
            ax.plot(tau_arr,mi_vals,color="#4A7FCC",lw=1.5,label="I(X;D_tau)")
            ax.plot(tau_arr,null_vals,color="#888",lw=1,ls="--",label="Null floor (q_0.99)")
            ax.set_xlabel("Delay τ"); ax.set_ylabel("MI (bits)")
            ax.set_title("E-LERI-2: Record chain MI vs conservative null floor")
            ax.legend(fontsize=8); fig.tight_layout()
            fig.savefig(out,dpi=150,bbox_inches="tight"); plt.close(fig)
            print("Saved -> " + out)
        except ImportError:
            print("matplotlib required: pip install matplotlib")
    else:
        print("Unknown experiment: " + args.experiment)
        print("Available: e8, leri-2")


def cmd_audit(args):
    """THB-5 Audit Protocol — 11-step alignment failure audit (SPHERE_36 §6.4)."""
    import numpy as np
    from fawp_index.constants import (ALPHA_A, E11_TAU_PLUS_H, E11_TAU_F,
                                       E11_TAU_READOUT, PERSISTENCE_RULE_M,
                                       PERSISTENCE_RULE_N)
    from fawp_index.state import FAWPState, classify_zone
    from fawp_index.odi import compute_odi
    PASS="PASS"; WARN="WARN"; FAIL="FAIL"; INFO="INFO"

    try:
        import yfinance as yf
        df = yf.download(args.ticker, period=args.period, auto_adjust=True, progress=False)
        if df.empty:
            print("No data for " + args.ticker); return
        from fawp_index.market import scan_fawp_market
        r   = scan_fawp_market(df, ticker=args.ticker, epsilon=args.epsilon,
                                n_null=30, verbose=False)
        odw = getattr(r, "odw_result", r)
        tau_arr  = np.arange(1, 41)
        pred_mi  = getattr(odw, "pred_mi",  np.zeros(40))
        steer_mi = getattr(odw, "steer_mi", np.zeros(40))
        tau_h  = odw.tau_h_plus
        tau_f  = odw.tau_f
        delta_tau = (tau_f - tau_h) if (tau_h and tau_f) else None
        gap   = float(odw.peak_gap_bits or 0)
        zone  = classify_zone(float(steer_mi.mean()), float(pred_mi.max()),
                               args.epsilon, ALPHA_A)
    except ImportError:
        print("yfinance required: pip install yfinance"); return
    except Exception as e:
        print("Data error: " + str(e)); return

    odi = compute_odi(pred_mi, steer_mi, tau_arr, args.epsilon, ALPHA_A)

    rows = []
    def step(n, label, status, detail):
        rows.append((n, label, status, detail))

    # Step 1: Baseline Horizon Mapping
    step(1, "Baseline horizon mapping",
         PASS if (tau_h and tau_f) else WARN,
         f"tau_h={tau_h}  tau_f={tau_f}  zone={zone.value}")

    # Step 2: Leverage Gap Stress Test
    step(2, "Leverage gap stress test",
         PASS if gap > args.epsilon else FAIL,
         f"peak_gap={gap:.4f}b  (threshold={args.epsilon}b)")

    # Step 3: Ghost Zone Quantification
    tau_rd = E11_TAU_READOUT
    ghost_w = (tau_rd - tau_h) if tau_h else None
    step(3, "Ghost Zone quantification",
         WARN if (ghost_w and ghost_w > 5) else PASS,
         f"delta_tau_ghost={ghost_w}  (E11-1 ref={tau_rd - E11_TAU_PLUS_H})")

    # Step 4: Mirage Audit (placeholder — needs two-channel data)
    step(4, "Mirage audit (G_read)",
         INFO, "Requires display + true readout channels. Run: fawp-index mirage --ticker " + args.ticker)

    # Step 5: Upstream Sensitivity
    steer_slope = float(np.polyfit(range(len(steer_mi)), steer_mi, 1)[0]) if len(steer_mi)>1 else 0
    step(5, "Upstream sensitivity (steer slope)",
         WARN if steer_slope < -0.002 else PASS,
         f"steer_mi slope={steer_slope:.5f} bits/tau")

    # Step 6: Reaction Trap
    tau_H_ref = E11_TAU_PLUS_H
    step(6, "Reaction trap (delta_tau vs tau_H)",
         FAIL if (delta_tau and delta_tau < tau_H_ref) else PASS,
         f"delta_tau={delta_tau}  tau_H_ref={tau_H_ref}  {'TRAP' if delta_tau and delta_tau < tau_H_ref else 'OK'}")

    # Step 7: Human UI Audit
    step(7, "Human UI audit (Q_beta)",
         INFO, "Manual step: measure decision latency under dashboard UI")

    # Step 8: Agentic Stack Escalation
    step(8, "Escalation latency (tau_esc)",
         INFO, "Manual step: verify escalation + reaction < delta_tau")

    # Step 9: Circuit Steering (ODI)
    step(9, "Circuit steering / ODI",
         FAIL if odi.odi_active else PASS,
         f"Z_ODI={odi.odi_score:.3f} at tau={odi.odi_tau}  active={odi.odi_active}")

    # Step 10: Regulatory Divergence
    step(10, "Regulatory divergence (D_reg)",
         INFO, "Multi-jurisdiction scan not yet automated")

    # Step 11: Binding Audit
    fawp_rate = sum(1 for g in pred_mi if g > args.epsilon) / max(1, len(pred_mi))
    step(11, "Binding audit (beta, zombie risk)",
         WARN if fawp_rate > 0.6 else PASS,
         f"pred_above_eps_rate={fawp_rate:.1%}  (>60% = zombie-risk)")

    # Print report
    print("THB-5 Audit Protocol — " + args.ticker + " [" + args.period + "]")
    print("=" * 66)
    print(f"  {'#':>2}  {'Step':<36} {'Status':<6}  Detail")
    print("-" * 66)
    warn_n = fail_n = 0
    for n, label, status, detail in rows:
        icon = {"PASS":"✅","WARN":"⚠ ","FAIL":"❌","INFO":"ℹ "}[status]
        if status == "WARN": warn_n += 1
        if status == "FAIL": fail_n += 1
        print(f"  {n:>2}. {label:<36} {icon} {detail}")
    print("=" * 66)
    print(f"Verdict: {fail_n} failures  {warn_n} warnings  Zone={zone.emoji} {zone.value}")
    if fail_n == 0 and warn_n == 0:
        print("System appears operationally healthy under THB-5.")
    elif fail_n > 0:
        print("CRITICAL: failures indicate active alignment failure risk.")

def main():
    _check_version_update()
    parser = _build_parser()
    args = parser.parse_args()
    if not hasattr(args, "func"):
        parser.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
