"""
fawp_index.mirage — Mirage System detector and Readout Integrity Gap (v4.0.0)

From SPHERE_36 §3.2:

    Readout Integrity Gap:
        G_read(t) = I_disp_read(t) − I_true_read(t)

    Dark System:   both display and true readout collapse
    Mirage System: I_disp_read remains high while I_true_read has already failed

A Co-opted Readout Regime is present when:
    I_disp_read > η_disp
    I_true_read ≤ ε_read
    I_steer ≤ ε

This module provides:
  - MirageResult dataclass
  - detect_mirage() — two-channel MI estimator
  - g_read() — scalar readout integrity gap
"""
from __future__ import annotations
import numpy as np
from typing import Sequence
from dataclasses import dataclass, field


@dataclass
class MirageResult:
    """
    Output of detect_mirage().

    Attributes
    ----------
    g_read          : Readout Integrity Gap G_read = I_disp - I_true
    i_disp_read     : Display-channel MI (what supervisors see)
    i_true_read     : True-channel MI (actual internal state coupling)
    is_mirage       : G_read ≥ g_read_threshold — Mirage System flag
    is_dark         : both I_disp and I_true near zero — Dark System flag
    is_ghost        : I_steer ≤ ε while I_pred > ε — Ghost Zone flag
    system_class    : "MIRAGE" | "DARK" | "GHOST" | "FAWP" | "OK"
    tau_mirage_peak : τ at which G_read peaks
    """
    g_read:          float
    i_disp_read:     float
    i_true_read:     float
    is_mirage:       bool
    is_dark:         bool
    is_ghost:        bool
    system_class:    str
    tau_mirage_peak: int | None = None
    g_read_series:   list[float] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            "=" * 55,
            "  Mirage System Detector (SPHERE_36 §3.2)",
            "=" * 55,
            f"System class    : {self.system_class}",
            f"G_read (peak)   : {self.g_read:.4f}",
            f"I_disp_read     : {self.i_disp_read:.4f} bits",
            f"I_true_read     : {self.i_true_read:.4f} bits",
            f"Is Mirage       : {self.is_mirage}",
            f"Is Dark         : {self.is_dark}",
            f"Is Ghost Zone   : {self.is_ghost}",
        ]
        if self.tau_mirage_peak is not None:
            lines.append(f"G_read peaks at : τ = {self.tau_mirage_peak}")
        lines.append("=" * 55)
        return "\n".join(lines)


def detect_mirage(
    tau: Sequence[int | float],
    pred_mi: Sequence[float],
    steer_mi: Sequence[float],
    disp_mi: Sequence[float] | None = None,
    true_mi: Sequence[float] | None = None,
    epsilon: float = 0.01,
    alpha_a: float = 0.007297,
    eta_disp: float = 0.05,
    epsilon_read: float = 0.01,
    g_read_threshold: float = 0.5,
) -> MirageResult:
    """
    Detect Mirage System conditions.

    Parameters
    ----------
    tau       : delay array
    pred_mi   : corrected predictive MI (display channel proxy if disp_mi absent)
    steer_mi  : corrected steering MI
    disp_mi   : explicit display-readout channel (optional — uses pred_mi if None)
    true_mi   : explicit true-readout channel (optional — uses steer_mi if None)
    epsilon   : steering detectability threshold
    alpha_a   : Practical Steering Wall
    eta_disp  : display readout "still active" threshold
    epsilon_read : true readout "failed" threshold
    g_read_threshold : G_read above which Mirage is flagged
    """
    pred  = np.asarray(pred_mi,  dtype=float)
    steer = np.asarray(steer_mi, dtype=float)
    disp  = np.asarray(disp_mi,  dtype=float) if disp_mi  is not None else pred.copy()
    true  = np.asarray(true_mi,  dtype=float) if true_mi  is not None else steer.copy()
    tau_a = np.asarray(tau,      dtype=float)

    g_series = np.maximum(0.0, disp - true)
    peak_idx = int(np.argmax(g_series))
    g_peak   = float(g_series[peak_idx])
    tau_peak = int(tau_a[peak_idx]) if g_peak > 0 else None

    i_disp = float(disp.max())
    i_true = float(true.max())

    is_ghost  = bool((pred > epsilon).any() and (steer <= alpha_a).any())
    is_mirage = bool(g_peak >= g_read_threshold
                     and i_disp > eta_disp
                     and i_true <= epsilon_read)
    is_dark   = bool(i_disp <= epsilon_read and i_true <= epsilon_read)

    if is_mirage:
        cls = "MIRAGE"
    elif is_dark:
        cls = "DARK"
    elif is_ghost:
        cls = "GHOST"
    elif (pred > epsilon).any() and (steer <= epsilon).any():
        cls = "FAWP"
    else:
        cls = "OK"

    return MirageResult(
        g_read=g_peak,
        i_disp_read=i_disp,
        i_true_read=i_true,
        is_mirage=is_mirage,
        is_dark=is_dark,
        is_ghost=is_ghost,
        system_class=cls,
        tau_mirage_peak=tau_peak,
        g_read_series=g_series.tolist(),
    )


def g_read(disp_mi: float, true_mi: float) -> float:
    """Scalar Readout Integrity Gap for a single τ."""
    return max(0.0, float(disp_mi) - float(true_mi))


__all__ = ["MirageResult", "detect_mirage", "g_read"]
