"""
FAWP AI System Scanner — 5th scanner (v4.0.0)

Applies the Triple Horizon Framework to AI/LLM systems.
Maps:  prediction → response coherence / perplexity
       steering   → prompt/instruction effectiveness

Reference: SPHERE_36 §3 — Operationalization in AI Contexts

FAWP signature for LLMs:
  - model remains fluent and coherent (pred high)
  - prompt control weakens or becomes inconsistent (steer low)
"""
from __future__ import annotations
import streamlit as st
import numpy as np

def render_ai_scanner():
    """Render the AI System FAWP scanner tab."""
    st.markdown("## \U0001f916 AI System FAWP Scanner")
    st.caption(
        "Detect Triple Horizon collapse in AI/LLM systems. "
        "Prediction (coherence) vs Steering (instruction effectiveness). "
        "SPHERE_36 §3."
    )

    st.info(
        "**How it works:** The scanner probes an LLM endpoint at increasing "
        "prompt strengths (τ = instruction specificity). It measures whether "
        "prediction (fluency) persists while steering (instruction compliance) "
        "collapses — the FAWP signature for AI systems."
    )

    with st.expander("⚙ Configuration", expanded=True):
        col1, col2 = st.columns(2)
        with col1:
            endpoint = st.text_input(
                "API endpoint (OpenAI-compatible)",
                "https://api.openai.com/v1/chat/completions",
                help="Any OpenAI-compatible chat endpoint"
            )
            api_key = st.text_input("API key", type="password",
                                     help="Not stored — used only for this scan")
            model = st.text_input("Model", "gpt-3.5-turbo")
        with col2:
            tau_min   = st.slider("τ min (prompt strength)", 1, 5, 1)
            tau_max   = st.slider("τ max (prompt strength)", 5, 20, 12)
            n_probes  = st.slider("Probes per τ", 2, 10, 3)
            epsilon   = st.number_input("ε (bits)", value=0.01, step=0.001, format="%.4f")

    st.markdown("---")
    st.markdown("**Probe templates** — scaled by τ (instruction specificity)")
    probe_template = st.text_area(
        "Steering probe (instruction)",
        "Respond with exactly {tau} words. Be precise. {tau} words only.",
        help="Use {tau} as placeholder for specificity level"
    )
    pred_template = st.text_area(
        "Prediction probe (coherence check)",
        "Continue this sentence naturally: The weather today is",
        help="Fixed prompt measuring fluency/coherence"
    )

    if st.button("▶ Run AI FAWP Scan", type="primary", key="ai_scan_run"):
        if not api_key:
            st.error("API key required"); return
        try:
            import requests, json
            headers = {"Authorization": f"Bearer {api_key}",
                       "Content-Type": "application/json"}
            tau_range  = list(range(tau_min, tau_max + 1))
            pred_scores  = []
            steer_scores = []
            prog = st.progress(0.0, text="Probing AI system...")

            for i, tau in enumerate(tau_range):
                p_scores = []; s_scores = []
                for _ in range(n_probes):
                    # Steering probe
                    steer_prompt = probe_template.format(tau=tau)
                    r_st = requests.post(endpoint, headers=headers,
                        json={"model": model, "max_tokens": 80,
                              "messages": [{"role":"user","content":steer_prompt}]},
                        timeout=15)
                    if r_st.ok:
                        resp = r_st.json()["choices"][0]["message"]["content"]
                        word_count = len(resp.split())
                        # Steering score: how close to requested τ words
                        s_scores.append(max(0.0, 1.0 - abs(word_count - tau) / max(tau, 1)))

                    # Prediction probe (fixed)
                    r_pr = requests.post(endpoint, headers=headers,
                        json={"model": model, "max_tokens": 30,
                              "messages": [{"role":"user","content":pred_template}],
                              "logprobs": True},
                        timeout=15)
                    if r_pr.ok:
                        rj = r_pr.json()
                        lp = rj.get("choices",[{}])[0].get("logprobs") or {}
                        tokens = lp.get("token_logprobs") or []
                        mean_lp = np.mean([t for t in tokens if t is not None]) if tokens else -3.0
                        p_scores.append(max(0.0, (mean_lp + 5) / 5))  # normalise to [0,1]

                pred_scores.append(float(np.mean(p_scores)) if p_scores else 0.5)
                steer_scores.append(float(np.mean(s_scores)) if s_scores else 0.5)
                prog.progress((i+1)/len(tau_range), text=f"τ={tau} done...")

            prog.empty()
            pred_arr  = np.array(pred_scores)
            steer_arr = np.array(steer_scores)
            tau_arr   = np.array(tau_range)

            from fawp_index.state import classify_zone, FAWPState
            from fawp_index.odi   import compute_odi
            zone = classify_zone(float(steer_arr.mean()), float(pred_arr.max()),
                                  epsilon=0.1)  # adjusted for 0-1 scale
            odi  = compute_odi(pred_arr, steer_arr, tau_arr,
                                epsilon=0.1, alpha_A=0.15)

            st.markdown(f"### Result: {zone.emoji} **{zone.value}**")
            st.caption(f"Z_ODI = {odi.odi_score:.3f}  |  ODI active: {odi.odi_active}")

            col1, col2, col3 = st.columns(3)
            col1.metric("Peak pred score",  f"{pred_arr.max():.3f}")
            col2.metric("Min steer score",  f"{steer_arr.min():.3f}")
            col3.metric("ODI score",        f"{odi.odi_score:.3f}")

            try:
                import matplotlib
                matplotlib.use("Agg", force=True)
                import matplotlib.pyplot as plt
                fig, ax = plt.subplots(figsize=(9, 3.5), facecolor="#0D1729")
                ax.set_facecolor("#07101E")
                ax.plot(tau_range, pred_arr,  color="#FF6B2B", lw=2, label="Prediction (coherence)")
                ax.plot(tau_range, steer_arr, color="#4A7FCC", lw=2, ls="--", label="Steering (compliance)")
                ax.fill_between(tau_range, pred_arr, steer_arr,
                                where=(np.array(pred_arr)>np.array(steer_arr)),
                                alpha=0.18, color="#C0111A", label="Leverage gap (FAWP)")
                ax.axhline(0.15, color="#D4AF37", ls=":", lw=1, label="αA (steering wall)")
                for sp in ax.spines.values(): sp.set_edgecolor("#3A4E70")
                ax.tick_params(colors="#7A90B8", labelsize=8)
                ax.set_xlabel("τ (instruction specificity)", fontsize=9, color="#7A90B8")
                ax.set_ylabel("Score (0–1)", fontsize=9, color="#7A90B8")
                ax.set_title(f"AI FAWP scan: {model} — {zone.emoji} {zone.value}",
                             color="#D4AF37", fontsize=10)
                ax.legend(fontsize=8, framealpha=0.2, facecolor="#0D1729")
                fig.tight_layout()
                st.pyplot(fig, use_container_width=True)
                plt.close(fig)
            except Exception:
                st.dataframe({"tau":tau_range,"pred":pred_arr,"steer":steer_arr})

        except Exception as e:
            st.error(f"AI scan error: {e}")

    st.markdown("---")
    st.markdown("**FAWP signature for AI systems** (SPHERE_36 §3.5):")
    st.markdown(
        "- 🔴 **FAWP**: model fluent and coherent, but prompt control weakens or becomes inconsistent\n"
        "- 👻 **GHOST**: model remains readable/legible, steerability already failed\n"
        "- 🪞 **MIRAGE**: compliance dashboard smooth, safety-relevant steering already degraded"
    )
