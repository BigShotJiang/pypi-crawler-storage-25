"""
fawp-index live /status endpoint for Render deployment.

Mount this alongside app.py or deploy as a separate Render service.
Returns JSON: version, last_scan_ts, fawp_active, fawp_tickers, uptime_s.

Usage (Render start command):
    uvicorn dashboard.status_app:app --host 0.0.0.0 --port $PORT

Or integrate into the Streamlit app via st.components if uvicorn is available.
"""
from __future__ import annotations
import time
import json
import threading
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler

import fawp_index as fi

_START_TS = time.time()
_STATE: dict = {
    "last_scan_ts": None,
    "fawp_active": False,
    "fawp_tickers": [],
}
_LOCK = threading.Lock()


def update_status(last_scan_ts: str | None = None,
                  fawp_active: bool = False,
                  fawp_tickers: list[str] | None = None) -> None:
    """Call this from the dashboard after each scan to update the status cache."""
    with _LOCK:
        _STATE["last_scan_ts"] = last_scan_ts
        _STATE["fawp_active"]  = fawp_active
        _STATE["fawp_tickers"] = fawp_tickers or []


def _build_payload() -> dict:
    with _LOCK:
        return {
            "version":       fi.__version__,
            "uptime_s":      round(time.time() - _START_TS, 1),
            "last_scan_ts":  _STATE["last_scan_ts"],
            "fawp_active":   _STATE["fawp_active"],
            "fawp_tickers":  _STATE["fawp_tickers"],
            "status":        "ok",
        }


class _Handler(BaseHTTPRequestHandler):
    def do_GET(self):                          # noqa: N802
        if self.path in ("/status", "/status/"):
            body = json.dumps(_build_payload(), indent=2).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, fmt, *args):         # suppress default logging
        pass


def run_status_server(host: str = "0.0.0.0", port: int = 8501) -> None:
    """Run a minimal HTTP server that serves /status JSON."""
    server = HTTPServer((host, port), _Handler)
    print(f"fawp-index status server on {host}:{port}/status")
    server.serve_forever()


# FastAPI / uvicorn integration (optional — only if fastapi installed)
try:
    from fastapi import FastAPI
    from fastapi.responses import JSONResponse

    app = FastAPI(title="fawp-index status", version=fi.__version__)

    @app.get("/status")
    def status_endpoint():
        return JSONResponse(_build_payload())

    @app.get("/health")
    def health():
        return {"ok": True}

except ImportError:
    app = None   # uvicorn not available — use run_status_server() instead


if __name__ == "__main__":
    import sys
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8501
    run_status_server(port=port)
