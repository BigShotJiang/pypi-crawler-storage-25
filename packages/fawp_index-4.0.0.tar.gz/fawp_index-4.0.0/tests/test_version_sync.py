"""
Version sync regression test — v3.7.33+

Asserts that __version__, pyproject.toml, dashboard/requirements.txt,
and CITATION.cff all agree. Run in CI to catch version drift immediately.
"""
import sys, re, tomllib
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))


def _pyproject_ver():
    return tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]["version"]


def _requirements_pin():
    for line in (ROOT / "dashboard" / "requirements.txt").read_text().splitlines():
        if line.startswith("fawp-index=="):
            return line.split("==")[1].strip()
    return None


def _cff_ver():
    m = re.search(r'version:\s*"([^"]+)"', (ROOT / "CITATION.cff").read_text())
    return m.group(1) if m else None


def test_init_matches_pyproject():
    import fawp_index
    assert fawp_index.__version__ == _pyproject_ver(), (
        f"__version__={fawp_index.__version__!r} != pyproject={_pyproject_ver()!r}. "
        f"Update fawp_index/__init__.py"
    )


def test_requirements_pin_matches_pyproject():
    pin = _requirements_pin()
    ver = _pyproject_ver()
    assert pin == ver, (
        f"dashboard/requirements.txt pins fawp-index=={pin} "
        f"but pyproject.toml says {ver}. "
        f"Run: sed -i s/fawp-index==.*/fawp-index=={ver}/ dashboard/requirements.txt"
    )


def test_cff_matches_pyproject():
    cff = _cff_ver()
    ver = _pyproject_ver()
    assert cff == ver, (
        f"CITATION.cff version={cff!r} != pyproject={ver!r}. "
        f"Update CITATION.cff"
    )


def test_all_three_agree():
    """Single test that checks all four sources match — easiest to run manually."""
    import fawp_index
    ver  = _pyproject_ver()
    init = fawp_index.__version__
    pin  = _requirements_pin()
    cff  = _cff_ver()
    mismatches = [k for k,v in {
        "__init__.__version__":      init,
        "requirements.txt pin":      pin,
        "CITATION.cff":              cff,
    }.items() if v != ver]
    assert not mismatches, (
        f"Version drift detected (pyproject={ver}): "
        + ", ".join(f"{k}={globals().get(k, '?')} should be {ver}"
                    for k in mismatches)
    )
