# conda-lockfiles

`conda-lockfiles` provides support in `conda` for many types of lockfiles in the conda ecosystem.

:::{warning}
This project is still in early stages of development. Don't use it in production (yet).
We do welcome feedback on what the expected behaviour should have been if something doesn't work!

Please submit bug reports or feature requests [here](https://github.com/conda-incubator/conda-lockfiles).
:::

```{include} ../README.md
:start-after: <!-- docs-index-content-start -->
:end-before: <!-- docs-index-content-end -->
```

## Learning more

::::{grid} 2

:::{grid-item-card} 🏡 Getting started
:link: getting-started
:link-type: doc
New to `conda-lockfiles`? Start here to learn the essentials
:::

:::{grid-item-card} 🏷️ Format aliases
:link: format-aliases
:link-type: doc
Canonical names vs. short aliases, re-export tutorial
:::

:::{grid-item-card} 💡 Motivation and vision
:link: motivation
:link-type: doc
Read about why `conda-lockfiles` exists and when you should use it
:::

::::

```{toctree}
:hidden:

getting-started
format-aliases
motivation
```

```{toctree}
:caption: Developer
:hidden:

developer/contributing
developer/maintaining
```
