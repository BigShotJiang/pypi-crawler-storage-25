"""Type stubs for kctsb.encode Product Quantization primitives."""

from __future__ import annotations

from typing import Any, Tuple, overload

import numpy as np
import numpy.typing as npt


class PQConfig:
    """Product Quantization configuration."""

    dimension: int
    subquantizers: int
    centroids_per_subquantizer: int
    max_iterations: int
    seed: int
    convergence_epsilon: float

    @overload
    def __init__(
        self,
        dimension: int = 512,
        subquantizers: int = 32,
        centroids: int = 256,
        max_iterations: int = 20,
        seed: int = 0,
        convergence_epsilon: float = 1.0e-4,
    ) -> None: ...

    @overload
    def __init__(
        self,
        *,
        dim: int,
        subquantizers: int = 32,
        centroids: int = 256,
        iterations: int = 20,
        seed: int = 0,
        convergence_epsilon: float = 1.0e-4,
    ) -> None: ...

    @property
    def code_size_bytes(self) -> int: ...

    @property
    def codebook_size_floats(self) -> int: ...

    def validate(self) -> bool: ...


def train_pq(
    vectors: npt.ArrayLike,
    subquantizers: int = 32,
    centroids: int = 256,
    max_iterations: int = 20,
    seed: int = 0,
    convergence_epsilon: float = 1.0e-4,
) -> npt.NDArray[np.float32]: ...


@overload
def train_pq(
    vectors: npt.ArrayLike,
    config: PQConfig,
) -> npt.NDArray[np.float32]: ...


def encode_pq(
    vectors: npt.ArrayLike,
    codebook: npt.ArrayLike,
    config: PQConfig | None = None,
) -> npt.NDArray[np.uint8]: ...


def decode_pq(
    codes: npt.ArrayLike,
    codebook: npt.ArrayLike,
    config: PQConfig | None = None,
) -> npt.NDArray[np.float32]: ...


def adc_lookup(
    query: npt.ArrayLike,
    codebook: npt.ArrayLike,
    config: PQConfig | None = None,
) -> npt.NDArray[np.float32]: ...


def adc_topk(
    codes: npt.ArrayLike,
    lookup: npt.ArrayLike,
    top_k: int = 10,
    config: PQConfig | None = None,
) -> Tuple[npt.NDArray[np.uint32], npt.NDArray[np.float32]]: ...
