"""Type stubs for ``kctsb.ac_pir`` composition helpers."""

from __future__ import annotations

from dataclasses import dataclass

from . import pir, voprf


@dataclass(frozen=True)
class AnonymousEntitlementCredential:
    entitlement_message: bytes
    signature: bytes
    issuer_public_key: bytes


@dataclass(frozen=True)
class AccessTagTranscript:
    access_tag: bytes
    blinded_element: bytes
    evaluated_element: bytes
    proof_c: bytes
    proof_s: bytes
    verify_ok: bool


@dataclass(frozen=True)
class ACPIRResult:
    target_index: int
    key_handle: int
    communication_bytes: int
    access_tag_hex: str
    entitlement_verified: bool
    voprf_verified: bool
    latency_ms: float


def build_entitlement_message(
    *,
    policy_scope: str,
    policy_epoch: str,
    entitlement_secret: bytes,
) -> bytes: ...


def issue_anonymous_entitlement(
    *,
    issuer_seed: bytes,
    entitlement_message: bytes,
) -> AnonymousEntitlementCredential: ...


def verify_anonymous_entitlement(credential: AnonymousEntitlementCredential) -> bool: ...


def derive_access_tag(
    *,
    voprf_sk: bytes,
    voprf_pk: bytes,
    entitlement_message: bytes,
    mode: voprf.Mode = ...,
) -> AccessTagTranscript: ...


def ac_pir_query(
    *,
    credential: AnonymousEntitlementCredential,
    voprf_sk: bytes,
    voprf_pk: bytes,
    target_index: int,
    key_database: list[int],
    config: pir.PIRConfig,
) -> ACPIRResult: ...


__all__: list[str]
