"""Type stubs for ``kctsb.zk_membership`` — ZK 集合成员证明独立 API."""

from __future__ import annotations

class MembershipProof:
    """Merkle 树集合成员证明。

    Attributes:
        leaf_hash: 元素的叶节点哈希（SHA-256(\\x00 || element)）。
        root: Merkle 树根哈希（32 字节）。
        path: 从叶节点到根的辅助哈希（兄弟节点哈希列表）。
        directions: 每层路径方向：0 = 当前节点在左，1 = 当前节点在右。
        set_size: 集合元素数。
        proof_bytes: 证明序列化字节数。
    """

    leaf_hash: bytes
    root: bytes
    path: list[bytes]
    directions: list[int]
    set_size: int

    @property
    def proof_bytes(self) -> int:
        """证明结构序列化字节数。"""
        ...

    def verify(self) -> bool:
        """验证本证明是否有效。"""
        ...


class MembershipProofWithTag:
    """集合成员证明 + VOPRF 可验证 access tag 的组合结构。

    Attributes:
        membership_proof: Merkle 树集合成员证明。
        access_tag: 从 VOPRF 派生的匿名 access tag（32 字节）。
        blinded_element: VOPRF 客户端盲化元素。
        evaluated_element: VOPRF 服务端评估结果。
        proof_c: DLEQ 证明的挑战值。
        proof_s: DLEQ 证明的响应值。
        voprf_ok: VOPRF DLEQ 验证结果。
        total_bytes: 完整证明序列化大小（字节）。
    """

    membership_proof: MembershipProof
    access_tag: bytes
    blinded_element: bytes
    evaluated_element: bytes
    proof_c: bytes
    proof_s: bytes
    voprf_ok: bool
    total_bytes: int

    def verify(self, root: bytes, voprf_pk: bytes) -> bool:
        """验证组合证明（成员证明 + VOPRF 可验证 tag）。

        Args:
            root: 期望的 Merkle root（32 字节）。
            voprf_pk: VOPRF 公钥字节。

        Returns:
            True 如果所有验证通过，False 否则。
        """
        ...


class MerkleSetAccumulator:
    """基于 SHA-256 的 Merkle 集合累加器。

    Args:
        elements: 元素列表（字节串列表）。
    """

    def __init__(self, elements: list[bytes]) -> None: ...

    @property
    def root(self) -> bytes:
        """Merkle 树根哈希（32 字节）。"""
        ...

    @property
    def depth(self) -> int:
        """树深度（叶层到根的层数）。"""
        ...

    @property
    def size(self) -> int:
        """集合中的元素数量。"""
        ...

    def contains(self, element: bytes) -> bool:
        """检查元素是否在集合中。"""
        ...

    def prove(self, element: bytes) -> MembershipProof:
        """为指定元素生成 Merkle 成员证明。

        Args:
            element: 要证明其成员资格的元素（字节串）。

        Returns:
            MembershipProof 实例。

        Raises:
            KeyError: 如果元素不在集合中。
        """
        ...


def prove_membership(element: bytes, element_set: list[bytes]) -> MembershipProof:
    """为元素生成集合成员证明（一次性便捷接口）。

    Args:
        element: 要证明成员资格的元素（字节串）。
        element_set: 集合元素列表。

    Returns:
        MembershipProof 实例。

    Raises:
        KeyError: 如果 element 不在 element_set 中。
        ValueError: 如果 element_set 为空。
    """
    ...


def verify_membership(proof: MembershipProof) -> bool:
    """验证 Merkle 集合成员证明。

    Args:
        proof: 要验证的 MembershipProof 实例。

    Returns:
        True 如果证明有效，False 否则。
    """
    ...


def prove_membership_with_voprf(
    element: bytes,
    element_set: list[bytes],
    voprf_sk: bytes,
    voprf_pk: bytes,
) -> MembershipProofWithTag:
    """生成集合成员证明 + VOPRF 可验证 access tag 的组合证明。

    Args:
        element: 要证明成员资格的元素（字节串）。
        element_set: 集合元素列表。
        voprf_sk: VOPRF 服务端私钥字节。
        voprf_pk: VOPRF 服务端公钥字节。

    Returns:
        MembershipProofWithTag 实例。

    Raises:
        KeyError: 如果 element 不在 element_set 中。
        ValueError: 如果参数无效。
    """
    ...


def verify_membership_with_voprf(
    proof: MembershipProofWithTag,
    root: bytes,
    voprf_pk: bytes,
) -> bool:
    """验证组合成员证明（Merkle + VOPRF 可验证 access tag）。

    Args:
        proof: MembershipProofWithTag 实例。
        root: 期望的 Merkle root（32 字节）。
        voprf_pk: VOPRF 公钥字节。

    Returns:
        True 如果所有验证通过，False 否则。
    """
    ...


def accumulator_info(acc: MerkleSetAccumulator) -> dict:
    """返回累加器的统计信息字典。

    Args:
        acc: MerkleSetAccumulator 实例。

    Returns:
        包含 root_hex、depth、size、proof_bytes_per_element 的字典。
    """
    ...
