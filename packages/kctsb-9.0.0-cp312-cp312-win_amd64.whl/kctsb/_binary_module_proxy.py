"""Runtime proxy helpers for binary submodules exposed by ``_kctsb_core``.

These wrappers exist so that both Python runtime import resolution and
static analyzers (for example Pylance in notebooks) can resolve top-level
modules such as ``kctsb.encode`` and ``kctsb.pir`` as real package modules
instead of attributes re-exported only from ``kctsb.__init__``.
"""

from __future__ import annotations

from importlib import import_module
from types import ModuleType


def bind_binary_module(module_name: str) -> tuple[ModuleType, object, object, list[str]]:
    """Bind a ``_kctsb_core`` binary submodule into a regular Python module.

    Parameters
    ----------
    module_name:
        Name of the submodule exposed by ``kctsb._kctsb_core``.
    """

    core = import_module("._kctsb_core", __package__.rsplit(".", 1)[0])
    impl = getattr(core, module_name)

    def __getattr__(name: str) -> object:
        return getattr(impl, name)

    def __dir__() -> list[str]:
        return sorted(set(globals()) | set(dir(impl)))

    exported = getattr(impl, "__all__", None)
    if exported is None:
        exported = [name for name in dir(impl) if not name.startswith("_")]

    return impl, __getattr__, __dir__, list(exported)