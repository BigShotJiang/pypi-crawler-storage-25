"""Anonymous credential + Access-Controlled PIR composition helpers.

This module composes existing high-performance primitives in ``kctsb``:

- ``kctsb.ecc_blind_sign`` for unlinkable anonymous entitlement credentials
- ``kctsb.voprf`` (RFC 9497) for verifiable blinded access-tag derivation
- ``kctsb.pir`` for private key-handle retrieval

It is intentionally lightweight and notebook-friendly, providing an
engineering-grade local validation path for AC-PIR workflows.
"""

from __future__ import annotations

from dataclasses import dataclass
import time

from . import ecc_blind_sign, pir, voprf
from .crypto import sha256


@dataclass(frozen=True)
class AnonymousEntitlementCredential:
    """Unlinkable entitlement credential issued via blind signature."""

    entitlement_message: bytes
    signature: bytes
    issuer_public_key: bytes


@dataclass(frozen=True)
class AccessTagTranscript:
    """Transcript of a VOPRF-based access-tag derivation."""

    access_tag: bytes
    blinded_element: bytes
    evaluated_element: bytes
    proof_c: bytes
    proof_s: bytes
    verify_ok: bool


@dataclass(frozen=True)
class ACPIRResult:
    """Result of a complete local AC-PIR validation flow."""

    target_index: int
    key_handle: int
    communication_bytes: int
    access_tag_hex: str
    entitlement_verified: bool
    voprf_verified: bool
    latency_ms: float


def _msg_digest_hex(entitlement_secret: bytes) -> str:
    digest = sha256(entitlement_secret).hex()
    return digest[:32]


def build_entitlement_message(
    *,
    policy_scope: str,
    policy_epoch: str,
    entitlement_secret: bytes,
) -> bytes:
    """Build a privacy-preserving entitlement message.

    The message binds scope and epoch, but does not include ``theme_id``
    directly to avoid disclosing a concrete item in the credential layer.
    """

    digest = _msg_digest_hex(entitlement_secret)
    return f"ac-pir-entitlement:v1:{policy_scope}:{policy_epoch}:{digest}".encode("utf-8")


def issue_anonymous_entitlement(
    *,
    issuer_seed: bytes,
    entitlement_message: bytes,
) -> AnonymousEntitlementCredential:
    """Issue an unlinkable entitlement credential via blind signature."""

    issuer_sk, issuer_pk = ecc_blind_sign.keygen(issuer_seed)
    commit_state, commit_pub = ecc_blind_sign.signer_commit()
    blind_state, challenge = ecc_blind_sign.client_blind(commit_pub, issuer_pk, entitlement_message)
    response = ecc_blind_sign.signer_sign(issuer_sk, commit_state, challenge)
    signature = ecc_blind_sign.client_unblind(blind_state, response)
    return AnonymousEntitlementCredential(
        entitlement_message=entitlement_message,
        signature=signature,
        issuer_public_key=issuer_pk,
    )


def verify_anonymous_entitlement(credential: AnonymousEntitlementCredential) -> bool:
    """Verify the blind-signature entitlement credential."""

    return bool(
        ecc_blind_sign.verify(
            credential.issuer_public_key,
            credential.entitlement_message,
            credential.signature,
        )
    )


def derive_access_tag(
    *,
    voprf_sk: bytes,
    voprf_pk: bytes,
    entitlement_message: bytes,
    mode: voprf.Mode = voprf.Mode.VOPRF,
) -> AccessTagTranscript:
    """Derive a verifiable blinded access tag from entitlement material."""

    blind_scalar, blinded_element = voprf.blind(entitlement_message, mode)
    evaluated_element, proof_c, proof_s = voprf.voprf_evaluate_blinded(
        voprf_sk,
        voprf_pk,
        blinded_element,
        mode,
    )
    verify_ok = bool(
        voprf.verify_proof(
            voprf_pk,
            blinded_element,
            evaluated_element,
            proof_c,
            proof_s,
            mode,
        )
    )
    access_tag = voprf.oprf_finalize(entitlement_message, blind_scalar, evaluated_element)
    return AccessTagTranscript(
        access_tag=access_tag,
        blinded_element=blinded_element,
        evaluated_element=evaluated_element,
        proof_c=proof_c,
        proof_s=proof_s,
        verify_ok=verify_ok,
    )


def ac_pir_query(
    *,
    credential: AnonymousEntitlementCredential,
    voprf_sk: bytes,
    voprf_pk: bytes,
    target_index: int,
    key_database: list[int],
    config: pir.PIRConfig,
) -> ACPIRResult:
    """Run local AC-PIR flow: entitlement verify -> VOPRF tag -> PIR query."""

    t0 = time.perf_counter()
    entitlement_verified = verify_anonymous_entitlement(credential)
    if not entitlement_verified:
        raise ValueError("anonymous entitlement verification failed")

    tag_tx = derive_access_tag(
        voprf_sk=voprf_sk,
        voprf_pk=voprf_pk,
        entitlement_message=credential.entitlement_message,
        mode=voprf.Mode.VOPRF,
    )
    if not tag_tx.verify_ok:
        raise ValueError("VOPRF DLEQ verification failed")

    engine = pir.NativePIR(config, key_database)
    result = engine.query(target_index)
    key_handle = int(result.retrieved_int64)

    latency_ms = (time.perf_counter() - t0) * 1000.0
    return ACPIRResult(
        target_index=target_index,
        key_handle=key_handle,
        communication_bytes=int(result.communication_bytes),
        access_tag_hex=tag_tx.access_tag.hex(),
        entitlement_verified=entitlement_verified,
        voprf_verified=tag_tx.verify_ok,
        latency_ms=latency_ms,
    )


__all__ = [
    "AnonymousEntitlementCredential",
    "AccessTagTranscript",
    "ACPIRResult",
    "build_entitlement_message",
    "issue_anonymous_entitlement",
    "verify_anonymous_entitlement",
    "derive_access_tag",
    "ac_pir_query",
]
