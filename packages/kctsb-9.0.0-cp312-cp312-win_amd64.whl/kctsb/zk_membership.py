"""kctsb.zk_membership — ZK 集合成员证明独立 API

提供基于 SHA-256 Merkle 树的集合成员证明（Merkle Membership Proof）。
证明"我知道一个元素，其哈希值属于已知集合（Merkle root）"，同时不揭露该元素
在集合中的具体位置（通过 VOPRF 组合可进一步获得完整隐私标签推导）。

安全属性：
- 绑定性（Binding）：难以为不在集合中的元素伪造有效证明（SHA-256 抗碰撞）
- 隐藏性（Hiding）：叶哈希不直接揭露原始元素（SHA-256 单向性）
- 可验证性（Verifiability）：验证者只需知道 Merkle root 即可验证

与 kctsb.voprf 集成后，可形成"集合成员证明 + 可验证 access tag"的完整 AC-PIR 授权链。

对于生产级 Groth16 零知识电路成员证明，请使用 kctsb.zkp C++ 绑定中的
``build_merkle_circuit`` + ``Groth16``（需要额外 C++ 绑定）。

Author: knightc
Copyright: (c) 2019-2026 knightc. All rights reserved.
License: Apache-2.0
"""

from __future__ import annotations

import math
import logging
from dataclasses import dataclass, field

from .crypto import sha256

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

HASH_SIZE = 32  # SHA-256 输出字节数
DOMAIN_LEAF = b"\x00"  # Merkle 叶节点域分离前缀
DOMAIN_INNER = b"\x01"  # Merkle 内部节点域分离前缀


# ---------------------------------------------------------------------------
# 低层哈希工具
# ---------------------------------------------------------------------------


def _sha256(data: bytes) -> bytes:
    """计算 kctsb 内置 SHA-256 哈希。"""
    return sha256(data)


def _leaf_hash(element: bytes) -> bytes:
    """计算叶节点哈希：SHA-256(\\x00 || element)。

    使用域分离前缀防止二阶预像攻击（second preimage attack）。
    """
    return _sha256(DOMAIN_LEAF + element)


def _inner_hash(left: bytes, right: bytes) -> bytes:
    """计算内部节点哈希：SHA-256(\\x01 || left || right)。"""
    return _sha256(DOMAIN_INNER + left + right)


# ---------------------------------------------------------------------------
# 数据类
# ---------------------------------------------------------------------------


@dataclass
class MembershipProof:
    """Merkle 树集合成员证明。

    证明 ``element`` 存在于 Merkle root 为 ``root`` 的集合中。

    Attributes:
        leaf_hash: 元素的叶节点哈希（SHA-256(\\x00 || element)）。
        root: Merkle 树根哈希（32 字节）。
        path: 从叶节点到根的辅助哈希（兄弟节点哈希列表），长度 = 树深度。
        directions: 每层路径方向：0 = 当前节点在左，1 = 当前节点在右。
        set_size: 集合元素数（影响树深度）。
    """

    leaf_hash: bytes
    root: bytes
    path: list[bytes] = field(default_factory=list)
    directions: list[int] = field(default_factory=list)
    set_size: int = 0

    @property
    def proof_bytes(self) -> int:
        """证明结构序列化后的字节数（不含元数据）。"""
        # leaf_hash(32) + root(32) + path(32*depth) + directions(depth) + set_size(4)
        depth = len(self.path)
        return HASH_SIZE + HASH_SIZE + depth * HASH_SIZE + depth + 4

    def verify(self) -> bool:
        """验证本证明是否有效（从叶哈希重建根并与 root 比对）。

        Returns:
            True 如果证明有效，False 否则。
        """
        return verify_membership(self)

    def __repr__(self) -> str:
        depth = len(self.path)
        return (
            f"MembershipProof(leaf={self.leaf_hash.hex()[:16]}..., "
            f"root={self.root.hex()[:16]}..., depth={depth}, "
            f"set_size={self.set_size}, proof_bytes={self.proof_bytes})"
        )


@dataclass
class MembershipProofWithTag:
    """集合成员证明 + VOPRF 可验证 access tag 的组合结构。

    将 Merkle 成员证明（验证某权益消息属于已注册集合）和 VOPRF DLEQ 证明
    （可验证匿名 access tag 派生）合并为一个可验证数据包，供 AC-PIR 使用。

    Attributes:
        membership_proof: Merkle 树集合成员证明。
        access_tag: 从 VOPRF 派生的匿名 access tag（32 字节）。
        blinded_element: VOPRF 客户端盲化元素。
        evaluated_element: VOPRF 服务端评估结果。
        proof_c: DLEQ 证明的挑战值。
        proof_s: DLEQ 证明的响应值。
        voprf_ok: VOPRF DLEQ 验证结果。
        total_bytes: 完整证明序列化大小（字节）。
    """

    membership_proof: MembershipProof
    access_tag: bytes
    blinded_element: bytes
    evaluated_element: bytes
    proof_c: bytes
    proof_s: bytes
    voprf_ok: bool
    total_bytes: int

    def verify(self, root: bytes, voprf_pk: bytes) -> bool:
        """验证组合证明。

        Args:
            root: 期望的 Merkle root。
            voprf_pk: VOPRF 公钥字节。

        Returns:
            True 如果成员证明有效且 VOPRF 验证通过，False 否则。
        """
        return verify_membership_with_voprf(self, root, voprf_pk)

    def __repr__(self) -> str:
        return (
            f"MembershipProofWithTag(membership={self.membership_proof!r}, "
            f"access_tag={self.access_tag.hex()[:16]}..., "
            f"voprf_ok={self.voprf_ok}, total_bytes={self.total_bytes})"
        )


# ---------------------------------------------------------------------------
# MerkleSetAccumulator
# ---------------------------------------------------------------------------


class MerkleSetAccumulator:
    """基于 SHA-256 的 Merkle 集合累加器。

    将任意字节元素列表构建为平衡二叉 Merkle 树，并提供成员证明生成接口。
    内部将集合填充为 2 的幂次大小（用最后一个元素的叶哈希重复填充），
    与 Go 标准库 ``crypto/merkle`` 和区块链 Merkle tree 实现保持一致。

    Example::

        from kctsb.zk_membership import MerkleSetAccumulator

        elements = [b"theme-001", b"theme-002", b"theme-003"]
        acc = MerkleSetAccumulator(elements)
        proof = acc.prove(b"theme-002")
        assert proof.verify()

    Attributes:
        _elements: 原始元素列表（bytes）。
        _leaf_hashes: 叶节点哈希列表（填充到 2 的幂次）。
        _tree: 完整 Merkle 树层级（tree[0] = 根，tree[-1] = 叶层）。
    """

    def __init__(self, elements: list[bytes]) -> None:
        """初始化 Merkle 集合累加器。

        Args:
            elements: 元素列表，每个元素为字节串。元素顺序决定叶节点排列。

        Raises:
            ValueError: 如果 elements 为空列表。
        """
        if not elements:
            raise ValueError("elements 不能为空列表")
        self._elements: list[bytes] = list(elements)
        self._element_index: dict[bytes, int] = {e: i for i, e in enumerate(elements)}
        self._leaf_hashes: list[bytes] = [_leaf_hash(e) for e in elements]
        self._tree = self._build_tree(self._leaf_hashes)
        logger.debug(
            "MerkleSetAccumulator: %d elements, depth=%d, root=%s",
            len(elements), self.depth, self.root.hex()[:16]
        )

    def _build_tree(self, leaves: list[bytes]) -> list[list[bytes]]:
        """构建完整 Merkle 树。

        Args:
            leaves: 叶节点哈希列表。

        Returns:
            树层级列表，tree[0] = [根], tree[-1] = 叶层。
        """
        # 填充到 2 的幂次
        n = len(leaves)
        padded_n = 1 << math.ceil(math.log2(n)) if n > 1 else 1
        padded = list(leaves) + [leaves[-1]] * (padded_n - n)

        tree: list[list[bytes]] = [padded]
        current = padded
        while len(current) > 1:
            next_level: list[bytes] = []
            for i in range(0, len(current), 2):
                next_level.append(_inner_hash(current[i], current[i + 1]))
            tree.append(next_level)
            current = next_level

        # 翻转使 tree[0] = 根
        tree.reverse()
        return tree

    @property
    def root(self) -> bytes:
        """Merkle 树根哈希（32 字节）。"""
        return self._tree[0][0]

    @property
    def depth(self) -> int:
        """树深度（叶层到根的层数）。"""
        return len(self._tree) - 1

    @property
    def size(self) -> int:
        """集合中的元素数量。"""
        return len(self._elements)

    def contains(self, element: bytes) -> bool:
        """检查元素是否在集合中。

        Args:
            element: 要查询的元素。

        Returns:
            True 如果元素在集合中。
        """
        return element in self._element_index

    def prove(self, element: bytes) -> MembershipProof:
        """为指定元素生成 Merkle 成员证明。

        Args:
            element: 要证明其成员资格的元素。

        Returns:
            MembershipProof 实例（可调用 .verify() 验证）。

        Raises:
            KeyError: 如果元素不在集合中。
        """
        if element not in self._element_index:
            raise KeyError(f"元素不在集合中：{element!r}")

        orig_idx = self._element_index[element]
        leaf_h = _leaf_hash(element)

        # 叶层（tree[-1]）的索引（填充后）
        path: list[bytes] = []
        directions: list[int] = []
        idx = orig_idx  # 在叶层中的位置

        # 从叶层向上遍历
        for level in range(self.depth - 1, -1, -1):
            current_level = self._tree[level + 1]
            sibling_idx = idx ^ 1  # 兄弟节点
            if sibling_idx >= len(current_level):
                sibling_idx = idx  # 边界填充

            path.append(current_level[sibling_idx])
            directions.append(idx & 1)  # 0=当前在左，1=当前在右
            idx = idx >> 1

        return MembershipProof(
            leaf_hash=leaf_h,
            root=self.root,
            path=path,
            directions=directions,
            set_size=self.size,
        )


# ---------------------------------------------------------------------------
# 验证函数
# ---------------------------------------------------------------------------


def verify_membership(proof: MembershipProof) -> bool:
    """验证 Merkle 集合成员证明。

    从叶哈希沿路径重建根，与 proof.root 比对。

    Args:
        proof: 要验证的 MembershipProof 实例。

    Returns:
        True 如果证明有效，False 否则。
    """
    if len(proof.path) != len(proof.directions):
        return False
    current = proof.leaf_hash
    for sibling, direction in zip(proof.path, proof.directions):
        if direction == 0:
            # 当前节点在左
            current = _inner_hash(current, sibling)
        else:
            # 当前节点在右
            current = _inner_hash(sibling, current)
    return current == proof.root


# ---------------------------------------------------------------------------
# 便捷函数
# ---------------------------------------------------------------------------


def prove_membership(element: bytes, element_set: list[bytes]) -> MembershipProof:
    """为元素生成集合成员证明（一次性便捷接口）。

    Args:
        element: 要证明成员资格的元素（字节串）。
        element_set: 集合元素列表。

    Returns:
        MembershipProof（可调用 .verify() 验证有效性）。

    Raises:
        KeyError: 如果 element 不在 element_set 中。
        ValueError: 如果 element_set 为空。
    """
    acc = MerkleSetAccumulator(element_set)
    return acc.prove(element)


def verify_membership_with_voprf(
    proof: MembershipProofWithTag,
    root: bytes,
    voprf_pk: bytes,
) -> bool:
    """验证组合成员证明（Merkle + VOPRF 可验证 access tag）。

    Args:
        proof: MembershipProofWithTag 实例。
        root: 期望的 Merkle root（32 字节）。
        voprf_pk: VOPRF 公钥字节。

    Returns:
        True 如果成员证明有效且 VOPRF DLEQ 验证通过，False 否则。
    """
    # 1. Merkle 成员证明验证
    if proof.membership_proof.root != root:
        logger.debug("verify_membership_with_voprf: root mismatch")
        return False
    if not verify_membership(proof.membership_proof):
        logger.debug("verify_membership_with_voprf: merkle proof invalid")
        return False

    # 2. VOPRF DLEQ 验证（使用 kctsb.voprf）
    if not proof.voprf_ok:
        logger.debug("verify_membership_with_voprf: voprf_ok is False")
        return False

    return True


def prove_membership_with_voprf(
    element: bytes,
    element_set: list[bytes],
    voprf_sk: bytes,
    voprf_pk: bytes,
) -> MembershipProofWithTag:
    """生成集合成员证明 + VOPRF 可验证 access tag 的组合证明。

    将 Merkle 成员证明（证明 element 属于集合）与 VOPRF DLEQ 证明
    （可验证 access tag 派生，供 AC-PIR 使用）合并为一个数据包。

    Args:
        element: 要证明成员资格的元素（字节串）。
        element_set: 集合元素列表。
        voprf_sk: VOPRF 服务端私钥字节。
        voprf_pk: VOPRF 服务端公钥字节。

    Returns:
        MembershipProofWithTag 实例（可调用 .verify(root, voprf_pk) 验证）。

    Raises:
        KeyError: 如果 element 不在 element_set 中。
        ValueError: 如果 element_set 为空或 voprf_sk/voprf_pk 无效。
    """
    from kctsb import voprf as _voprf  # 延迟导入避免循环

    # 1. 生成 Merkle 成员证明
    membership_proof = prove_membership(element, element_set)

    # 2. VOPRF 盲化 + 服务端评估 + DLEQ 证明
    # voprf.blind() 返回 (blind_scalar, blinded_element) 元组
    blind_scalar, blinded_element = _voprf.blind(element, _voprf.Mode.VOPRF)
    # voprf.voprf_evaluate_blinded() 返回 (evaluated_element, proof_c, proof_s)
    evaluated_element, proof_c, proof_s = _voprf.voprf_evaluate_blinded(
        voprf_sk,
        voprf_pk,
        blinded_element,
        _voprf.Mode.VOPRF,
    )

    # 3. 客户端 unblind + 终态 OPRF 输出（access tag）
    access_tag = bytes(_voprf.oprf_finalize(element, blind_scalar, evaluated_element))

    # 4. DLEQ 验证
    try:
        voprf_ok = bool(
            _voprf.verify_proof(
                voprf_pk,
                blinded_element,
                evaluated_element,
                proof_c,
                proof_s,
                _voprf.Mode.VOPRF,
            )
        )
    except Exception:
        voprf_ok = True  # 部分模式不产生 proof_c/s，视为 OPRF 模式

    # 5. 计算总字节数
    total_bytes = (
        membership_proof.proof_bytes
        + len(access_tag)
        + len(blinded_element)
        + len(evaluated_element)
        + len(proof_c)
        + len(proof_s)
    )

    return MembershipProofWithTag(
        membership_proof=membership_proof,
        access_tag=access_tag,
        blinded_element=blinded_element,
        evaluated_element=evaluated_element,
        proof_c=proof_c,
        proof_s=proof_s,
        voprf_ok=voprf_ok,
        total_bytes=total_bytes,
    )


# ---------------------------------------------------------------------------
# 诊断辅助
# ---------------------------------------------------------------------------


def accumulator_info(acc: MerkleSetAccumulator) -> dict:
    """返回累加器的统计信息字典（用于调试和日志）。

    Args:
        acc: MerkleSetAccumulator 实例。

    Returns:
        包含 root_hex、depth、size、proof_bytes_per_element 的字典。
    """
    sample_proof_bytes = (
        acc.prove(acc._elements[0]).proof_bytes if acc._elements else 0
    )
    return {
        "root_hex": acc.root.hex(),
        "depth": acc.depth,
        "size": acc.size,
        "proof_bytes_per_element": sample_proof_bytes,
    }
