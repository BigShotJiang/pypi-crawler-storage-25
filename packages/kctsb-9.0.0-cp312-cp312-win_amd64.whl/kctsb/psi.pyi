"""Type stubs for ``kctsb.psi`` — Private Set Intersection (OT-PSI / Piano-PSI)."""
from __future__ import annotations

from typing import Sequence

__all__: list[str]


class OTVariant:
    """Oblivious Transfer protocol variant."""
    BASE: OTVariant
    IKNP_OT_EXTENSION: OTVariant
    SILENT_OT: OTVariant
    @property
    def value(self) -> int: ...


class OTConfig:
    """Configuration for OT-based PSI."""
    variant: OTVariant
    security_bits: int
    def __init__(self, variant: OTVariant = ..., security_bits: int = ...) -> None: ...


class OTResult:
    """OT-PSI computation result with per-stage timing."""
    intersection: list[int]
    setup_ms: float
    online_ms: float
    bytes_sent: int
    bytes_received: int


class OTPSI:
    """OT-based Private Set Intersection.

    Examples
    --------
    >>> from kctsb import psi
    >>> p = psi.OTPSI(psi.OTConfig(variant=psi.OTVariant.IKNP_OT_EXTENSION))
    >>> r = p.run([1,2,3], [2,3,4])
    >>> sorted(r.intersection)
    [2, 3]
    """
    def __init__(self, config: OTConfig) -> None: ...
    def run(self, client_set: Sequence[int], server_set: Sequence[int]) -> OTResult: ...


def ot_psi(
    client_set: Sequence[int],
    server_set: Sequence[int],
    config: OTConfig | None = ...,
) -> OTResult: ...


class PianoConfig:
    """Configuration for Piano-PSI (sublinear-comm.) protocol."""
    expansion_factor: int
    def __init__(self, expansion_factor: int = ...) -> None: ...


class PianoResult:
    """Piano-PSI result with timing & comm metrics."""
    intersection: list[int]
    online_ms: float
    bytes_sent: int


class PianoPSI:
    """Piano-PSI: sublinear-communication PSI."""
    def __init__(self, config: PianoConfig) -> None: ...
    def run(self, client_set: Sequence[int], server_set: Sequence[int]) -> PianoResult: ...


def piano_psi(
    client_set: Sequence[int],
    server_set: Sequence[int],
    config: PianoConfig | None = ...,
) -> PianoResult: ...


def simple_intersection(set1: Sequence[int], set2: Sequence[int]) -> list[int]:
    """Compatibility token-based intersection using domain-separated SHA-256."""
