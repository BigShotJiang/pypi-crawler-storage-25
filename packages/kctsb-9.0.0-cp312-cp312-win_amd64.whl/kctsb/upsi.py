"""Runtime wrapper for ``kctsb.upsi`` binary bindings."""

from ._binary_module_proxy import bind_binary_module

_impl, __getattr__, __dir__, __all__ = bind_binary_module("upsi")
__doc__ = getattr(_impl, "__doc__", __doc__)