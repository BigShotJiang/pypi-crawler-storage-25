"""Runtime wrapper for ``kctsb.pir`` binary bindings."""

from ._binary_module_proxy import bind_binary_module

_impl, __getattr__, __dir__, __all__ = bind_binary_module("pir")
__doc__ = getattr(_impl, "__doc__", __doc__)