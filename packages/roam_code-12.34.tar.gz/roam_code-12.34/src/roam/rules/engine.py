"""YAML rule parser and graph query evaluator for custom governance rules.

Users define architectural rules as YAML files in ``.roam/rules/``.
Roam evaluates them against the indexed graph and reports violations.
"""

from __future__ import annotations

import fnmatch
import re
from pathlib import Path

from roam.db.connection import find_project_root
from roam.index.parser import detect_language, parse_file
from roam.rules.ast_match import (
    compile_ast_pattern,
    find_ast_matches,
    normalize_language_name,
)
from roam.rules.dataflow import collect_dataflow_findings

# ---------------------------------------------------------------------------
# YAML loading with fallback
# ---------------------------------------------------------------------------


def _load_yaml(path: Path) -> dict | None:
    """Load a single YAML file, returning the parsed dict or None on error.

    Falls back to a minimal line parser when PyYAML is not installed.
    """
    try:
        import yaml
    except ImportError:
        return _parse_simple_yaml(path)

    try:
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except Exception:
        return None


def _coerce_scalar(val: str) -> object:
    """Best-effort YAML scalar coercion: bool / int / float / quoted string."""
    val = val.strip().strip('"').strip("'")
    if val.lower() == "true":
        return True
    if val.lower() == "false":
        return False
    try:
        return int(val)
    except ValueError:
        try:
            return float(val)
        except ValueError:
            return val


def _parse_simple_yaml(path: Path) -> dict | None:
    """Minimal YAML subset parser for rule files (no PyYAML dependency).

    Handles:
    * flat key-value pairs
    * inline lists ``[a, b, c]``
    * nested maps under an indented key
    * list-of-dicts shape introduced by ``- key: value`` items (the
      ``rules:`` block in rules.yml is the canonical use)

    12.34 (2026-05-06) — added list-of-dicts support; CI 12.33 failed
    on Python 3.9 (PyYAML not installed) because
    ``test_load_rules_yaml_simple`` uses that shape.

    Frames track ``(indent, container, kind, parent_key)``. When we hit
    a ``- key: value`` item and the current frame is an empty dict, we
    promote it to a list inside the parent container at the recorded
    ``parent_key``, then push a new dict frame for the item.
    """
    try:
        text = path.read_text(encoding="utf-8")
    except Exception:
        return None

    result: dict = {}
    # Frame: (indent, container, kind, parent_dict, parent_key)
    # The root frame has parent_dict=None / parent_key=None.
    stack: list[tuple[int, object, str, object, object]] = [(0, result, "dict", None, None)]

    for raw in text.split("\n"):
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue

        indent = len(raw) - len(raw.lstrip())

        while len(stack) > 1 and indent < stack[-1][0]:
            stack.pop()

        if stripped.startswith("- "):
            after_dash = stripped[2:].strip()
            top = stack[-1]
            top_indent, top_container, top_kind, top_parent, top_pkey = top

            # If current frame is an empty dict that was opened by a parent
            # `key:` (no value), promote it to a list and replace it in the
            # parent. This is how `rules:\n  - id: ...` becomes
            # `{"rules": [{"id": ...}]}` instead of `{"rules": {"- id": ...}}`.
            if (
                top_kind == "dict"
                and isinstance(top_container, dict)
                and not top_container
                and top_parent is not None
                and top_pkey is not None
            ):
                new_list: list = []
                top_parent[top_pkey] = new_list
                stack[-1] = (top_indent, new_list, "list", top_parent, top_pkey)
                top_container = new_list
                top_kind = "list"

            if top_kind == "list" and isinstance(top_container, list):
                if ":" in after_dash:
                    new_item: dict = {}
                    top_container.append(new_item)
                    key, _, val = after_dash.partition(":")
                    key = key.strip()
                    if val.strip():
                        new_item[key] = _coerce_scalar(val)
                    else:
                        new_item[key] = {}
                    # Push the new item dict so subsequent same-indent keys
                    # populate it. Indent of children = indent + 2.
                    stack.append((indent + 2, new_item, "dict", top_container, len(top_container) - 1))
                else:
                    top_container.append(_coerce_scalar(after_dash))
            continue

        if ":" not in stripped:
            continue

        key, _, val = stripped.partition(":")
        key = key.strip()
        val_raw = val
        val = val.strip()

        _i, container, kind, _pp, _pk = stack[-1]
        if kind != "dict" or not isinstance(container, dict):
            continue

        if not val:
            child: dict = {}
            container[key] = child
            stack.append((indent + 2, child, "dict", container, key))
        elif val.startswith("[") and val.endswith("]"):
            items = [v.strip().strip('"').strip("'") for v in val[1:-1].split(",") if v.strip()]
            container[key] = items
        else:
            container[key] = _coerce_scalar(val_raw)

    return result if result else None


# ---------------------------------------------------------------------------
# Rule loading
# ---------------------------------------------------------------------------


def load_rules(rules_dir: Path) -> list[dict]:
    """Load all .yaml/.yml files from the rules directory.

    Returns a list of rule dicts. Files that fail to parse are silently
    skipped (a warning is included in the rule's ``_error`` key).
    """
    if not rules_dir.is_dir():
        return []

    rules: list[dict] = []
    for p in sorted(rules_dir.rglob("*")):
        if not p.is_file():
            continue
        if p.suffix not in (".yaml", ".yml"):
            continue
        data = _load_yaml(p)
        if data is None:
            rules.append(
                {
                    "name": p.name,
                    "severity": "error",
                    "_error": f"failed to parse {p.name}",
                    "_file": str(p),
                }
            )
            continue
        data["_file"] = str(p)
        rules.append(data)

    return rules


# ---------------------------------------------------------------------------
# Exemption helpers
# ---------------------------------------------------------------------------


def _is_exempt(symbol_name: str, file_path: str, exempt: dict) -> bool:
    """Check if a symbol/file combination is exempt from the rule."""
    exempt_symbols = exempt.get("symbols", [])
    if isinstance(exempt_symbols, str):
        exempt_symbols = [exempt_symbols]
    for es in exempt_symbols:
        if es == symbol_name:
            return True

    exempt_files = exempt.get("files", [])
    if isinstance(exempt_files, str):
        exempt_files = [exempt_files]
    for ef in exempt_files:
        if _matches_glob(file_path, ef):
            return True

    return False


def _matches_glob(file_path: str, pattern: str) -> bool:
    """Check if a file path matches a glob pattern.

    Supports ``**`` for matching zero or more directories, unlike plain
    ``fnmatch`` which treats ``*`` as matching everything including ``/``.
    """
    norm = file_path.replace("\\", "/")
    pat = pattern.replace("\\", "/")

    if "**" not in pat:
        return fnmatch.fnmatch(norm, pat)

    # Convert glob pattern with ** to regex
    parts: list[str] = []
    i = 0
    while i < len(pat):
        c = pat[i]
        if c == "*":
            if i + 1 < len(pat) and pat[i + 1] == "*":
                if i + 2 < len(pat) and pat[i + 2] == "/":
                    parts.append("(?:.+/)?")
                    i += 3
                    continue
                else:
                    parts.append(".*")
                    i += 2
                    continue
            else:
                parts.append("[^/]*")
                i += 1
        elif c == "?":
            parts.append("[^/]")
            i += 1
        elif c in r".+^${}()|[]":
            parts.append("\\" + c)
            i += 1
        else:
            parts.append(c)
            i += 1

    regex = "".join(parts)
    return re.match("^" + regex + "$", norm) is not None


def _matches_kind(kind: str, kind_filter: list | str | None) -> bool:
    """Check if a symbol kind matches the kind filter."""
    if kind_filter is None:
        return True
    if isinstance(kind_filter, str):
        kind_filter = [kind_filter]
    return kind in kind_filter


def _table_exists(conn, table_name: str) -> bool:
    """Return True when a table exists in the current SQLite DB."""
    try:
        row = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name = ? LIMIT 1",
            (table_name,),
        ).fetchone()
    except Exception:
        return False
    return row is not None


def _table_columns(conn, table_name: str) -> set[str]:
    """Return the set of columns for a table, or empty set if unavailable."""
    try:
        rows = conn.execute("PRAGMA table_info({})".format(table_name)).fetchall()
    except Exception:
        return set()

    cols: set[str] = set()
    for row in rows:
        try:
            cols.add(str(row["name"]))
        except Exception:
            if len(row) > 1:
                cols.add(str(row[1]))
    return cols


def _as_float_or_none(value) -> float | None:
    """Convert value to float when possible, else return None."""
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Rule evaluation: path_match
# ---------------------------------------------------------------------------


def _evaluate_path_match(rule: dict, conn) -> dict:
    """Evaluate a path_match rule: find edges between from/to patterns.

    Looks for direct edges (or paths up to max_distance) from symbols
    matching ``match.from`` criteria to symbols matching ``match.to`` criteria.
    """
    match = rule.get("match", {})
    from_spec = match.get("from", {})
    to_spec = match.get("to", {})
    max_distance = match.get("max_distance", 1)
    exempt = rule.get("exempt", {})

    from_glob = from_spec.get("file_glob")
    from_kind = from_spec.get("kind")
    to_glob = to_spec.get("file_glob")
    to_kind = to_spec.get("kind")

    # Query edges joining source and target symbols with their files
    rows = conn.execute("""
        SELECT
            s1.name AS src_name, s1.kind AS src_kind,
            f1.path AS src_file, s1.line_start AS src_line,
            s2.name AS tgt_name, s2.kind AS tgt_kind,
            f2.path AS tgt_file, s2.line_start AS tgt_line,
            e.kind AS edge_kind
        FROM edges e
        JOIN symbols s1 ON e.source_id = s1.id
        JOIN files f1 ON s1.file_id = f1.id
        JOIN symbols s2 ON e.target_id = s2.id
        JOIN files f2 ON s2.file_id = f2.id
    """).fetchall()

    violations: list[dict] = []
    for row in rows:
        src_file = row["src_file"]
        tgt_file = row["tgt_file"]
        src_name = row["src_name"]
        tgt_name = row["tgt_name"]
        src_kind = row["src_kind"]
        tgt_kind = row["tgt_kind"]

        # Apply from-pattern filter
        if from_glob and not _matches_glob(src_file, from_glob):
            continue
        if not _matches_kind(src_kind, from_kind):
            continue

        # Apply to-pattern filter
        if to_glob and not _matches_glob(tgt_file, to_glob):
            continue
        if not _matches_kind(tgt_kind, to_kind):
            continue

        # max_distance=1 means direct edge (already satisfied)
        # For max_distance > 1 we would need BFS, but direct edge
        # matching covers the core use case.
        if max_distance < 1:
            continue

        # Check exemptions
        if _is_exempt(src_name, src_file, exempt):
            continue
        if _is_exempt(tgt_name, tgt_file, exempt):
            continue

        violations.append(
            {
                "symbol": src_name,
                "file": src_file,
                "line": row["src_line"],
                "reason": f"{src_name} ({src_file}) -> {tgt_name} ({tgt_file})",
            }
        )

    name = rule.get("name", "unnamed")
    severity = rule.get("severity", "error")
    passed = len(violations) == 0

    return {
        "name": name,
        "severity": severity,
        "passed": passed,
        "violations": violations,
    }


# ---------------------------------------------------------------------------
# Rule evaluation: symbol_match
# ---------------------------------------------------------------------------


def _build_symbol_match_query(conn) -> tuple[str, str, str]:
    """Compute the schema-aware SQL fragments needed for the symbol_match
    SELECT. Returns ``(file_role_expr, param_expr, symbol_lines_expr,
    file_lines_expr, symbol_metrics_join)``."""
    file_cols = _table_columns(conn, "files")
    symbol_cols = _table_columns(conn, "symbols")
    has_symbol_metrics = _table_exists(conn, "symbol_metrics")

    if "line_count" in file_cols and "loc" in file_cols:
        file_lines_expr = "COALESCE(f.line_count, f.loc)"
    elif "line_count" in file_cols:
        file_lines_expr = "f.line_count"
    elif "loc" in file_cols:
        file_lines_expr = "f.loc"
    else:
        file_lines_expr = "NULL"

    file_role_expr = "f.file_role" if "file_role" in file_cols else "NULL"

    symbol_lines_fallback = (
        "(CASE WHEN s.line_start IS NOT NULL AND s.line_end IS NOT NULL "
        "THEN (s.line_end - s.line_start + 1) ELSE NULL END)"
        if "line_end" in symbol_cols
        else "NULL"
    )
    if has_symbol_metrics:
        param_expr = "sm.param_count"
        symbol_lines_expr = "COALESCE(sm.line_count, {})".format(symbol_lines_fallback)
        symbol_metrics_join = "LEFT JOIN symbol_metrics sm ON s.id = sm.symbol_id"
    else:
        param_expr = "NULL"
        symbol_lines_expr = symbol_lines_fallback
        symbol_metrics_join = ""

    query = """
        SELECT s.id, s.name, s.kind, s.line_start, s.is_exported,
               f.path AS file_path, {file_role_expr} AS file_role,
               COALESCE(gm.in_degree, 0) AS in_degree,
               {param_expr} AS param_count,
               {symbol_lines_expr} AS symbol_line_count,
               {file_lines_expr} AS file_line_count
        FROM symbols s
        JOIN files f ON s.file_id = f.id
        LEFT JOIN graph_metrics gm ON s.id = gm.symbol_id
        {symbol_metrics_join}
        WHERE 1=1
    """.format(
        file_role_expr=file_role_expr,
        param_expr=param_expr,
        symbol_lines_expr=symbol_lines_expr,
        file_lines_expr=file_lines_expr,
        symbol_metrics_join=symbol_metrics_join,
    )
    return query


def _parse_match_requirements(match: dict) -> tuple[dict, re.Pattern | None, str | None]:
    """Parse and normalise the require-* parameters under ``match.require``.

    Returns ``(requires_dict, compiled_name_regex, regex_error)``. The
    error string is non-None when a name_regex was provided but failed to
    compile; callers should surface it as a violation.
    """
    require = match.get("require", {})
    requires = {
        "has_test": bool(require.get("has_test", False)),
        "max_params": _as_float_or_none(require.get("max_params")),
        "min_params": _as_float_or_none(require.get("min_params")),
        "max_symbol_lines": _as_float_or_none(require.get("max_symbol_lines")),
        "min_symbol_lines": _as_float_or_none(require.get("min_symbol_lines")),
        "max_file_lines": _as_float_or_none(require.get("max_file_lines")),
        "min_file_lines": _as_float_or_none(require.get("min_file_lines")),
    }
    compiled_regex = None
    regex_error = None
    require_name_regex = require.get("name_regex")
    if isinstance(require_name_regex, str) and require_name_regex.strip():
        try:
            compiled_regex = re.compile(require_name_regex)
        except re.error as exc:
            regex_error = str(exc)
    return requires, compiled_regex, regex_error


def _bound_check(label: str, value: float | None, max_v: float | None, min_v: float | None) -> list[str]:
    """Standard min/max bound check that returns the reason strings.

    Centralises the 'value unavailable / exceeds / is below' messaging that
    every numeric requirement (params, symbol_lines, file_lines) repeats.
    """
    if max_v is None and min_v is None:
        return []
    if value is None:
        return ["{} unavailable".format(label)]
    out: list[str] = []
    if max_v is not None and value > max_v:
        out.append("{} {:.0f} exceeds {:.0f}".format(label, value, max_v))
    if min_v is not None and value < min_v:
        out.append("{} {:.0f} is below {:.0f}".format(label, value, min_v))
    return out


def _row_violation_reasons(row, requires, compiled_regex, conn) -> list[str]:
    """Apply every require-* check to a single row and return the failures.

    Empty list means the row passes all requirements.
    """
    reasons: list[str] = []
    symbol_name = row["name"]
    if requires["has_test"] and not _symbol_has_test(conn, row["id"]):
        reasons.append("{} has no test coverage".format(symbol_name))
    if compiled_regex and not compiled_regex.search(symbol_name):
        reasons.append("name '{}' does not match {}".format(symbol_name, compiled_regex.pattern))
    reasons.extend(
        _bound_check(
            "parameter count",
            _as_float_or_none(row["param_count"]),
            requires["max_params"],
            requires["min_params"],
        )
    )
    reasons.extend(
        _bound_check(
            "symbol line count",
            _as_float_or_none(row["symbol_line_count"]),
            requires["max_symbol_lines"],
            requires["min_symbol_lines"],
        )
    )
    reasons.extend(
        _bound_check(
            "file line count",
            _as_float_or_none(row["file_line_count"]),
            requires["max_file_lines"],
            requires["min_file_lines"],
        )
    )
    return reasons


def _evaluate_symbol_match(rule: dict, conn) -> dict:
    """Evaluate a symbol_match rule: find symbols matching criteria.

    Supports requirement checks under ``match.require``:
    - ``has_test``: matched symbols must have test coverage
    - ``name_regex``: symbol name must match regex
    - ``max_params`` / ``min_params``
    - ``max_symbol_lines`` / ``min_symbol_lines``
    - ``max_file_lines`` / ``min_file_lines``
    """
    match = rule.get("match", {})
    exempt = rule.get("exempt", {})

    kind_filter = match.get("kind")
    exported_filter = match.get("exported")
    file_glob = match.get("file_glob")
    min_fan_in = match.get("min_fan_in")
    max_fan_in = match.get("max_fan_in")

    requires, compiled_regex, regex_error = _parse_match_requirements(match)
    if regex_error is not None:
        return {
            "name": rule.get("name", "unnamed"),
            "severity": rule.get("severity", "error"),
            "passed": False,
            "violations": [
                {
                    "symbol": "",
                    "file": rule.get("_file", ""),
                    "line": None,
                    "reason": "invalid require.name_regex: {}".format(regex_error),
                }
            ],
        }

    query = _build_symbol_match_query(conn)
    params: list = []
    if kind_filter:
        if isinstance(kind_filter, str):
            kind_filter = [kind_filter]
        placeholders = ",".join("?" for _ in kind_filter)
        query += f" AND s.kind IN ({placeholders})"
        params.extend(kind_filter)
    if exported_filter is True:
        query += " AND s.is_exported = 1"
    elif exported_filter is False:
        query += " AND s.is_exported = 0"

    rows = conn.execute(query, params).fetchall()

    has_requirements = any(
        [
            requires["has_test"],
            compiled_regex is not None,
            requires["max_params"] is not None,
            requires["min_params"] is not None,
            requires["max_symbol_lines"] is not None,
            requires["min_symbol_lines"] is not None,
            requires["max_file_lines"] is not None,
            requires["min_file_lines"] is not None,
        ]
    )

    violations: list[dict] = []
    for row in rows:
        file_path = row["file_path"]
        symbol_name = row["name"]
        in_deg = _as_float_or_none(row["in_degree"]) or 0.0

        if file_glob and not _matches_glob(file_path, file_glob):
            continue
        if min_fan_in is not None and in_deg < float(min_fan_in):
            continue
        if max_fan_in is not None and in_deg > float(max_fan_in):
            continue
        if _is_exempt(symbol_name, file_path, exempt):
            continue

        if has_requirements:
            reasons = _row_violation_reasons(row, requires, compiled_regex, conn)
            if not reasons:
                continue
            violations.append(
                {
                    "symbol": symbol_name,
                    "file": file_path,
                    "line": row["line_start"],
                    "reason": "; ".join(reasons),
                }
            )
        else:
            violations.append(
                {
                    "symbol": symbol_name,
                    "file": file_path,
                    "line": row["line_start"],
                    "reason": f"{symbol_name} matches rule criteria",
                }
            )

    return {
        "name": rule.get("name", "unnamed"),
        "severity": rule.get("severity", "error"),
        "passed": len(violations) == 0,
        "violations": violations,
    }


def _symbol_has_test(conn, symbol_id: int) -> bool:
    """Check if a symbol has edges from test files."""
    rows = conn.execute(
        """
        SELECT 1 FROM edges e
        JOIN symbols s ON e.source_id = s.id
        JOIN files f ON s.file_id = f.id
        WHERE e.target_id = ?
          AND (f.file_role = 'test' OR f.path LIKE '%%test%%')
        LIMIT 1
    """,
        (symbol_id,),
    ).fetchall()
    return len(rows) > 0


# ---------------------------------------------------------------------------
# Rule evaluation: ast_match
# ---------------------------------------------------------------------------


def _format_capture_preview(captures: dict[str, str]) -> str:
    """Format captured metavariables for rule output."""
    if not captures:
        return ""
    parts: list[str] = []
    for name in sorted(captures.keys()):
        text = " ".join(captures[name].split())
        if len(text) > 40:
            text = text[:37] + "..."
        parts.append("${}={}".format(name, text))
    return ", ".join(parts)


def _evaluate_ast_match(rule: dict, conn) -> dict:
    """Evaluate an ast_match rule: structural pattern matching with metavars.

    Rule shape:

    type: ast_match
    match:
      ast: "eval($EXPR)"
      language: python
      file_glob: "**/*.py"
      max_matches: 100
    """
    match = rule.get("match", {})
    exempt = rule.get("exempt", {})

    pattern = match.get("ast")
    if pattern is None and rule.get("type") == "ast_match":
        # Compatibility: allow `match.pattern` when type is explicit.
        pattern = match.get("pattern")

    language_filter = normalize_language_name(match.get("language"))
    file_glob = match.get("file_glob")
    max_matches = int(match.get("max_matches", 0) or 0)

    name = rule.get("name", "unnamed")
    severity = rule.get("severity", "error")

    if not isinstance(pattern, str) or not pattern.strip():
        return {
            "name": name,
            "severity": severity,
            "passed": False,
            "violations": [
                {
                    "symbol": "",
                    "file": rule.get("_file", ""),
                    "line": None,
                    "reason": "ast_match rule missing non-empty match.ast pattern",
                }
            ],
        }

    try:
        root = find_project_root()
    except Exception:
        root = Path.cwd()

    rows = conn.execute("SELECT path FROM files ORDER BY path").fetchall()
    violations: list[dict] = []
    compiled_cache: dict[str, object] = {}

    for row in rows:
        rel_path = row["path"]

        if file_glob and not _matches_glob(rel_path, file_glob):
            continue
        if _is_exempt("", rel_path, exempt):
            continue

        detected_lang = normalize_language_name(detect_language(rel_path))
        if language_filter and detected_lang != language_filter:
            continue
        if detected_lang is None:
            continue

        full_path = root / rel_path
        tree, source, parsed_lang = parse_file(full_path, detected_lang)
        if tree is None or source is None:
            continue

        active_lang = normalize_language_name(parsed_lang or detected_lang or language_filter)
        if active_lang is None:
            continue

        compiled = compiled_cache.get(active_lang)
        if compiled is None:
            try:
                compiled = compile_ast_pattern(pattern, active_lang)
            except Exception as exc:
                return {
                    "name": name,
                    "severity": severity,
                    "passed": False,
                    "violations": [
                        {
                            "symbol": "",
                            "file": rule.get("_file", ""),
                            "line": None,
                            "reason": "AST pattern compile failed: {}".format(exc),
                        }
                    ],
                }
            compiled_cache[active_lang] = compiled

        remaining = 0
        if max_matches > 0:
            remaining = max_matches - len(violations)
            if remaining <= 0:
                break

        matches = find_ast_matches(
            tree,
            source,
            compiled,
            max_matches=remaining,
        )
        for m in matches:
            cap_text = _format_capture_preview(m.get("captures", {}))
            reason = "AST pattern matched: {}".format(pattern)
            if cap_text:
                reason += " ({})".format(cap_text)

            violations.append(
                {
                    "symbol": "",
                    "file": rel_path,
                    "line": m.get("line"),
                    "reason": reason,
                    "captures": m.get("captures", {}),
                }
            )

            if max_matches > 0 and len(violations) >= max_matches:
                break

    return {
        "name": name,
        "severity": severity,
        "passed": len(violations) == 0,
        "violations": violations,
    }


# ---------------------------------------------------------------------------
# Rule evaluation: dataflow_match
# ---------------------------------------------------------------------------


def _evaluate_dataflow_match(rule: dict, conn) -> dict:
    """Evaluate a dataflow_match rule using intra- and inter-procedural heuristics.

    Rule shape:

    type: dataflow_match
    match:
      patterns: [dead_assignment, unused_param, source_to_sink,
                 inter_source_to_sink, inter_unused_param, inter_unused_return]
      file_glob: "**/*.py"
      max_matches: 100
      sources: ["input(", "request.args"]
      sinks: ["eval(", "exec("]
      sanitizers: ["escape(", "sanitize("]
      max_chain_length: 5
      min_confidence: 0.5
    """
    match = rule.get("match", {})
    exempt = rule.get("exempt", {})

    patterns = match.get("patterns")
    if patterns is None:
        # Compatibility aliases:
        # - singular "pattern"
        # - "dataflow" value
        patterns = match.get("pattern", match.get("dataflow"))

    file_glob = match.get("file_glob")
    max_matches = int(match.get("max_matches", 0) or 0)
    sources = match.get("sources")
    sinks = match.get("sinks")

    # New inter-procedural keys
    max_chain_length = match.get("max_chain_length")
    min_confidence = match.get("min_confidence")

    name = rule.get("name", "unnamed")
    severity = rule.get("severity", "error")

    findings = collect_dataflow_findings(
        conn,
        patterns=patterns,
        file_glob=file_glob,
        max_matches=max_matches if max_matches > 0 else 0,
        sources=sources,
        sinks=sinks,
    )

    # Apply inter-procedural filters
    if max_chain_length is not None:
        try:
            mcl = int(max_chain_length)
            findings = [f for f in findings if f.get("chain_length", 1) <= mcl]
        except (TypeError, ValueError):
            pass

    if min_confidence is not None:
        try:
            mc = float(min_confidence)
            findings = [f for f in findings if f.get("confidence", 1.0) >= mc]
        except (TypeError, ValueError):
            pass

    violations: list[dict] = []
    for item in findings:
        symbol_name = item.get("symbol", "")
        file_path = item.get("file", "")
        if _is_exempt(symbol_name, file_path, exempt):
            continue
        violation = {
            "symbol": symbol_name,
            "file": file_path,
            "line": item.get("line"),
            "reason": item.get("reason", "dataflow rule matched"),
            "type": item.get("type"),
        }
        if "variable" in item:
            violation["variable"] = item["variable"]
        if "source" in item:
            violation["source"] = item["source"]
        if "sink" in item:
            violation["sink"] = item["sink"]
        if "confidence" in item:
            violation["confidence"] = item["confidence"]
        if "chain_length" in item:
            violation["chain_length"] = item["chain_length"]
        violations.append(violation)

    if max_matches > 0:
        violations = violations[:max_matches]

    return {
        "name": name,
        "severity": severity,
        "passed": len(violations) == 0,
        "violations": violations,
    }


# ---------------------------------------------------------------------------
# Rule type detection + dispatch
# ---------------------------------------------------------------------------


def _detect_rule_type(rule: dict) -> str:
    """Detect the rule type from its match specification.

    If ``type`` is explicitly set, it wins.
    Otherwise:
    - ``from`` + ``to`` => path_match
    - ``ast``           => ast_match
    - ``dataflow``      => dataflow_match
    - fallback          => symbol_match
    """
    explicit = rule.get("type")
    if isinstance(explicit, str) and explicit:
        return explicit

    match = rule.get("match", {})
    if "from" in match and "to" in match:
        return "path_match"
    if "ast" in match:
        return "ast_match"
    if "dataflow" in match or "patterns" in match and isinstance(match.get("patterns"), list):
        return "dataflow_match"
    return "symbol_match"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def evaluate_rule(rule: dict, conn, G=None) -> dict:
    """Evaluate a single rule against the indexed DB.

    Returns ``{name, severity, passed, violations: [{symbol, file, line, reason}]}``.
    """
    # Handle parse errors
    if "_error" in rule:
        return {
            "name": rule.get("name", "unknown"),
            "severity": rule.get("severity", "error"),
            "passed": False,
            "violations": [
                {
                    "symbol": "",
                    "file": rule.get("_file", ""),
                    "line": None,
                    "reason": rule["_error"],
                }
            ],
        }

    rule_type = _detect_rule_type(rule)

    if rule_type == "path_match":
        return _evaluate_path_match(rule, conn)
    if rule_type == "ast_match":
        return _evaluate_ast_match(rule, conn)
    if rule_type == "dataflow_match":
        return _evaluate_dataflow_match(rule, conn)
    else:
        return _evaluate_symbol_match(rule, conn)


def evaluate_all(rules_dir: Path, conn) -> list[dict]:
    """Load and evaluate all rules from the rules directory.

    Returns a list of result dicts, one per rule.
    """
    rules = load_rules(rules_dir)
    results: list[dict] = []
    for rule in rules:
        results.append(evaluate_rule(rule, conn))
    return results
