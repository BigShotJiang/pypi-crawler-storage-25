# src/rhosocial/activerecord/testsuite/feature/relation/fixtures/models.py
"""
Relation model fixtures for the testsuite.
"""
from typing import Optional, ClassVar

from rhosocial.activerecord.model import ActiveRecord
from rhosocial.activerecord.relation.descriptors import BelongsTo, HasMany, HasOne


class Employee(ActiveRecord):
    __table_name__ = "employees"

    id: Optional[int] = None
    username: str
    department_id: int

    # Define the relation to department
    department: ClassVar[BelongsTo["Department"]] = BelongsTo(
        foreign_key="department_id",
        inverse_of="employees"
    )


class Department(ActiveRecord):
    __table_name__ = "departments"

    id: Optional[int] = None
    name: str
    description: str = ""

    # Define the relation to employees
    employees: ClassVar[HasMany["Employee"]] = HasMany(
        foreign_key="department_id",
        inverse_of="department"
    )


class Author(ActiveRecord):
    __table_name__ = "authors"

    id: Optional[int] = None
    name: str

    # Relations
    books: ClassVar[HasMany["Book"]] = HasMany(
        foreign_key="author_id",
        inverse_of="author"
    )
    profile: ClassVar[HasOne["Profile"]] = HasOne(
        foreign_key="author_id",
        inverse_of="author"
    )


class Book(ActiveRecord):
    __table_name__ = "books"

    id: Optional[int] = None
    title: str
    author_id: int

    # Relations
    author: ClassVar[BelongsTo["Author"]] = BelongsTo(
        foreign_key="author_id",
        inverse_of="books"
    )
    chapters: ClassVar[HasMany["Chapter"]] = HasMany(
        foreign_key="book_id",
        inverse_of="book"
    )


class Chapter(ActiveRecord):
    __table_name__ = "chapters"

    id: Optional[int] = None
    title: str
    book_id: int

    # Relations
    book: ClassVar[BelongsTo["Book"]] = BelongsTo(
        foreign_key="book_id",
        inverse_of="chapters"
    )


class Profile(ActiveRecord):
    __table_name__ = "profiles"

    id: Optional[int] = None
    bio: str
    author_id: int

    # Relations
    author: ClassVar[BelongsTo["Author"]] = BelongsTo(
        foreign_key="author_id",
        inverse_of="profile"
    )
