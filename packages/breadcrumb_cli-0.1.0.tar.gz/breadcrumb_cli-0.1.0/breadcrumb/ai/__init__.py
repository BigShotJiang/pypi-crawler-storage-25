"""AI package initialization."""
