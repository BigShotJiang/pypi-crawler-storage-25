"""Cheqpoint Python SDK — human-in-the-loop approval queues for AI agents."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Optional

import requests as _requests

__version__ = "0.1.1"

DEFAULT_BASE_URL = "https://app.cheqpoint.co"
DEFAULT_POLL_INTERVAL = 3  # seconds
DEFAULT_TIMEOUT = 300  # seconds (5 minutes)


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass
class CheckpointResult:
    id: str
    status: str  # "APPROVED" | "REJECTED"
    details: dict[str, Any]
    modified_details: Optional[dict[str, Any]]
    response_notes: Optional[str]

    @property
    def effective_details(self) -> dict[str, Any]:
        """Return modified_details if set, otherwise the original details."""
        return self.modified_details if self.modified_details is not None else self.details


@dataclass
class RequestStatus:
    id: str
    status: str  # "PENDING" | "APPROVED" | "REJECTED"
    details: dict[str, Any]
    modified_details: Optional[dict[str, Any]]
    response_notes: Optional[str]
    decision_reason_code: Optional[str]
    decision_note: Optional[str]
    auto_decided: bool
    auto_decision_rule_name: Optional[str]
    decided_at: Optional[str]


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class CheqpointError(Exception):
    """Raised when the Cheqpoint API returns an error response."""

    def __init__(self, message: str, status_code: int, response_body: Any = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class RejectedError(Exception):
    """Raised when a checkpoint request is rejected by a reviewer."""

    def __init__(self, request_id: str, response_notes: Optional[str]) -> None:
        note = f": {response_notes}" if response_notes else ""
        super().__init__(f"Cheqpoint request {request_id} was rejected{note}")
        self.request_id = request_id
        self.response_notes = response_notes


class TimeoutError(Exception):
    """Raised when polling exceeds the configured timeout."""

    def __init__(self, request_id: str, timeout: float) -> None:
        super().__init__(
            f"Cheqpoint request {request_id} timed out after {timeout}s waiting for a decision"
        )
        self.request_id = request_id
        self.timeout = timeout


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class CheqpointClient:
    """Client for the Cheqpoint human-in-the-loop approval API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.default_timeout = timeout
        self._session = _requests.Session()
        self._session.headers.update(
            {
                "Content-Type": "application/json",
                "User-Agent": f"cheqpoint-python/{__version__}",
                "x-api-key": api_key,
            }
        )

    # ------------------------------------------------------------------
    # Public methods
    # ------------------------------------------------------------------

    def checkpoint(
        self,
        *,
        action: str,
        risk_score: Optional[float] = None,
        summary: str,
        details: dict[str, Any],
        justification: Optional[str] = None,
        webhook_url: Optional[str] = None,
        trace: Optional[dict[str, Any]] = None,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        timeout: Optional[float] = None,
    ) -> CheckpointResult:
        """Create an approval request and block until a human reviewer decides.

        Each call creates one billable approval event: Cheqpoint pauses the AI
        Assistant and routes it to the approval inbox.

        Args:
            action: Action type (e.g. "send_email", "process_refund", "deploy_code").
            risk_score: Optional float 0.0–1.0. Default: 0.5 (medium).
            summary: One-sentence description shown to reviewers.
            details: Structured payload for the action.
            justification: Optional agent reasoning shown to reviewers.
            webhook_url: URL for Cheqpoint to POST the decision to.
            poll_interval: Seconds between status polls. Default 3.
            timeout: Max seconds to wait. Default is client-level default (300).

        Returns:
            CheckpointResult with status "APPROVED".

        Raises:
            RejectedError: If the request is rejected.
            TimeoutError: If no decision within `timeout` seconds.
            CheqpointError: On API errors.
        """
        effective_timeout = timeout if timeout is not None else self.default_timeout

        result = self.create_request(
            action=action,
            risk_score=risk_score,
            summary=summary,
            details=details,
            justification=justification,
            webhook_url=webhook_url,
            trace=trace,
        )
        request_id = result["id"]
        deadline = time.monotonic() + effective_timeout

        while time.monotonic() < deadline:
            status = self.get_request(request_id)

            if status.status == "APPROVED":
                return CheckpointResult(
                    id=status.id,
                    status="APPROVED",
                    details=status.details,
                    modified_details=status.modified_details,
                    response_notes=status.response_notes,
                )

            if status.status == "REJECTED":
                raise RejectedError(request_id, status.response_notes)

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            time.sleep(min(poll_interval, remaining))

        raise TimeoutError(request_id, effective_timeout)

    def create_request(
        self,
        *,
        action: str,
        risk_score: Optional[float] = None,
        summary: str,
        details: dict[str, Any],
        justification: Optional[str] = None,
        webhook_url: Optional[str] = None,
        trace: Optional[dict[str, Any]] = None,
    ) -> dict[str, str]:
        """Create an approval request and return immediately with its ID.

        This creates one billable approval event: Cheqpoint pauses the AI
        Assistant and routes it to the approval inbox. Poll ``get_request(id)``
        to check for a decision, or supply ``webhook_url`` to receive it via
        callback.

        Returns:
            dict with "id" key containing the request ID.
        """
        body: dict[str, Any] = {
            "apiKey": self.api_key,
            "action": action,
            "riskScore": risk_score,
            "summary": summary,
            "details": details,
        }
        if justification is not None:
            body["justification"] = justification
        if webhook_url is not None:
            body["webhookUrl"] = webhook_url
        if trace is not None:
            body["trace"] = trace

        data = self._post("/api/approvals/request", body)
        return {"id": data["id"]}

    def request_sync(self,*,action:str,summary:str,details:dict,justification:str|None=None,timeout_ms:int=30_000)->dict:
        """Create an approval request and poll until decided or timeout_ms elapses."""
        server_wait=min(timeout_ms,10_000)
        body={"action":action,"summary":summary,"details":details,"maxWaitMs":server_wait}
        if justification is not None:body["justification"]=justification
        data=self._post("/api/webhooks/inbound",body)
        if data.get("status")in("approved","rejected"):return data
        approval_id=data.get("approvalId")or data.get("id","")
        deadline=time.monotonic()+timeout_ms/1000.0
        while time.monotonic()<deadline:
            time.sleep(min(1.0,max(0.0,deadline-time.monotonic())))
            s=self.get_request(approval_id)
            if s.status!="PENDING":return{"status":s.status.lower(),"approvalId":approval_id,"modifiedDetails":s.modified_details,"decisionNote":s.decision_note}
        return{"status":"pending","approvalId":approval_id,"modifiedDetails":None,"decisionNote":None}

    def request_async(self,*,action:str,summary:str,details:dict,justification:str|None=None,callback_url:str|None=None)->dict:
        """Create an approval request and return immediately without blocking."""
        body={"action":action,"summary":summary,"details":details}
        if justification is not None:body["justification"]=justification
        if callback_url is not None:body["callbackUrl"]=callback_url
        return self._post("/api/webhooks/inbound",body)

    def get_request(self, request_id: str) -> RequestStatus:
        """Fetch the current status of a request by its ID."""
        data = self._get(f"/api/approvals/{request_id}")
        return RequestStatus(
            id=data["id"],
            status=data["status"],
            details=data["details"],
            modified_details=data.get("modifiedDetails"),
            response_notes=data.get("responseNotes"),
            decision_reason_code=data.get("decisionReasonCode"),
            decision_note=data.get("decisionNote"),
            auto_decided=data.get("autoDecided", False),
            auto_decision_rule_name=data.get("autoDecisionRuleName"),
            decided_at=data.get("decidedAt"),
        )

    # ------------------------------------------------------------------
    # Instrumentation wrappers
    # ------------------------------------------------------------------

    def wrap_openai(self, openai_client: Any) -> tuple[Any, "TraceCollector"]:
        """Wrap an OpenAI client to auto-capture traces.

        Usage::

            client, collector = cheq.wrap_openai(OpenAI(api_key=...))
            response = client.chat.completions.create(model="gpt-4o", messages=[...])
            cheq.checkpoint(..., trace=collector.get_trace())
        """
        return _wrap_openai(openai_client)

    def wrap_anthropic(self, anthropic_client: Any) -> tuple[Any, "TraceCollector"]:
        """Wrap an Anthropic client to auto-capture traces.

        Usage::

            client, collector = cheq.wrap_anthropic(Anthropic(api_key=...))
            response = client.messages.create(model="claude-opus-4-6", messages=[...])
            cheq.checkpoint(..., trace=collector.get_trace())
        """
        return _wrap_anthropic(anthropic_client)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _post(self, path: str, body: dict[str, Any]) -> Any:
        url = f"{self.base_url}{path}"
        resp = self._session.post(url, json=body)
        return self._handle_response(resp)

    def _get(self, path: str) -> Any:
        url = f"{self.base_url}{path}"
        resp = self._session.get(url)
        return self._handle_response(resp)

    def _handle_response(self, resp: _requests.Response) -> Any:
        if not resp.ok:
            body: Any = None
            message = f"HTTP {resp.status_code}"
            try:
                body = resp.json()
                if isinstance(body, dict) and "error" in body:
                    message = body["error"]
            except Exception:
                pass
            raise CheqpointError(message, resp.status_code, body)
        return resp.json()


# ---------------------------------------------------------------------------
# Trace instrumentation helpers
# ---------------------------------------------------------------------------


from datetime import datetime, timezone


class TraceCollector:
    """Accumulates trace steps; call get_trace() to build the TraceData dict."""

    def __init__(self) -> None:
        self._steps: list[dict[str, str]] = []
        self._model: str = ""
        self._total_tokens: int = 0

    def _now(self) -> str:
        return datetime.now(tz=timezone.utc).isoformat()

    def add_step(self, type: str, content: str) -> None:
        self._steps.append({"type": type, "content": content, "timestamp": self._now()})

    def get_trace(self) -> dict[str, Any]:
        trace: dict[str, Any] = {"steps": list(self._steps)}
        if self._model:
            trace["model"] = self._model
        if self._total_tokens:
            trace["totalTokens"] = self._total_tokens
        return trace


class _OpenAIWrapper:
    """Thin proxy around an OpenAI client that records chat completions."""

    def __init__(self, client: Any, collector: TraceCollector) -> None:
        self._client = client
        self._collector = collector

    def __getattr__(self, name: str) -> Any:
        if name == "chat":
            return _OpenAIChatProxy(self._client.chat, self._collector)
        return getattr(self._client, name)


class _OpenAIChatProxy:
    def __init__(self, chat: Any, collector: TraceCollector) -> None:
        self._chat = chat
        self._collector = collector

    @property
    def completions(self) -> "_OpenAICompletionsProxy":
        return _OpenAICompletionsProxy(self._chat.completions, self._collector)


class _OpenAICompletionsProxy:
    def __init__(self, completions: Any, collector: TraceCollector) -> None:
        self._completions = completions
        self._collector = collector

    def create(self, **kwargs: Any) -> Any:
        if "model" in kwargs:
            self._collector._model = kwargs["model"]
        for msg in kwargs.get("messages", []):
            role = msg.get("role", "")
            content = msg.get("content", "")
            if role == "assistant":
                self._collector.add_step("thought", str(content))
            elif role == "tool":
                self._collector.add_step("observation", str(content))
        if "tools" in kwargs:
            self._collector.add_step("tool_call", str(kwargs["tools"])[:200])

        result = self._completions.create(**kwargs)

        usage = getattr(result, "usage", None)
        if usage and hasattr(usage, "total_tokens") and usage.total_tokens:
            self._collector._total_tokens += usage.total_tokens

        choices = getattr(result, "choices", []) or []
        if choices:
            msg = getattr(choices[0], "message", None)
            if msg:
                if getattr(msg, "content", None):
                    self._collector.add_step("thought", msg.content)
                tool_calls = getattr(msg, "tool_calls", None) or []
                for tc in tool_calls:
                    fn = getattr(tc, "function", None)
                    name = getattr(fn, "name", "tool") if fn else "tool"
                    args = getattr(fn, "arguments", "") if fn else ""
                    self._collector.add_step("tool_call", f"{name}({args})")

        return result


class _AnthropicWrapper:
    """Thin proxy around an Anthropic client that records message calls."""

    def __init__(self, client: Any, collector: TraceCollector) -> None:
        self._client = client
        self._collector = collector

    def __getattr__(self, name: str) -> Any:
        if name == "messages":
            return _AnthropicMessagesProxy(self._client.messages, self._collector)
        return getattr(self._client, name)


class _AnthropicMessagesProxy:
    def __init__(self, messages: Any, collector: TraceCollector) -> None:
        self._messages = messages
        self._collector = collector

    def create(self, **kwargs: Any) -> Any:
        if "model" in kwargs:
            self._collector._model = kwargs["model"]
        for msg in kwargs.get("messages", []):
            role = msg.get("role", "")
            content = msg.get("content", "")
            if role == "assistant":
                self._collector.add_step("thought", str(content))
            elif role == "user":
                self._collector.add_step("observation", str(content))

        result = self._messages.create(**kwargs)

        usage = getattr(result, "usage", None)
        if usage:
            inp = getattr(usage, "input_tokens", 0) or 0
            out = getattr(usage, "output_tokens", 0) or 0
            self._collector._total_tokens += inp + out

        for block in getattr(result, "content", []) or []:
            btype = getattr(block, "type", "")
            if btype == "text":
                self._collector.add_step("thought", getattr(block, "text", ""))
            elif btype == "tool_use":
                name = getattr(block, "name", "tool")
                inp = getattr(block, "input", {})
                self._collector.add_step("tool_call", f"{name}({inp})")

        return result


def _wrap_openai(client: Any) -> tuple[Any, TraceCollector]:
    collector = TraceCollector()
    return _OpenAIWrapper(client, collector), collector


def _wrap_anthropic(client: Any) -> tuple[Any, TraceCollector]:
    collector = TraceCollector()
    return _AnthropicWrapper(client, collector), collector
