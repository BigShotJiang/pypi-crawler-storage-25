"""Cheqpoint LangChain integration — human-in-the-loop approval tool."""

from __future__ import annotations

from typing import Any, Optional, Type

from .client import CheqpointClient

try:
    from langchain.tools import BaseTool
    from pydantic import BaseModel, Field
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "langchain is required for CheqpointApprovalTool. "
        "Install it with: pip install cheqpoint[langchain]"
    ) from e


class _CheqpointInput(BaseModel):
    action: str = Field(
        description="Category of the action requiring approval (e.g. 'send_email', 'process_refund', 'deploy_code')"
    )
    summary: str = Field(
        description="One-sentence description shown to the human reviewer"
    )
    details: dict[str, Any] = Field(
        description="Structured payload describing the action in detail"
    )
    risk_score: float = Field(
        default=0.5,
        ge=0.0,
        le=1.0,
        description="Risk score from 0.0 (low) to 1.0 (critical). Default: 0.5",
    )
    justification: Optional[str] = Field(
        default=None,
        description="Optional agent reasoning shown to the reviewer",
    )


class CheqpointApprovalTool(BaseTool):
    """LangChain tool that pauses agent execution and waits for human approval.

    Usage::

        from langchain_openai import ChatOpenAI
        from langchain.agents import create_tool_calling_agent, AgentExecutor
        from cheqpoint.langchain_tool import CheqpointApprovalTool

        tool = CheqpointApprovalTool(api_key="ck_...")
        llm = ChatOpenAI(model="gpt-4o")
        agent = create_tool_calling_agent(llm, [tool], prompt)
        executor = AgentExecutor(agent=agent, tools=[tool])
    """

    name: str = "request_human_approval"
    description: str = (
        "Request human approval before taking a consequential action. "
        "Use this tool when the action could have significant impact and requires "
        "a human reviewer to approve before you proceed. "
        "The tool blocks until a decision is made."
    )
    args_schema: Type[BaseModel] = _CheqpointInput

    # Pydantic excludes the client field from serialisation
    _client: CheqpointClient

    def __init__(self, api_key: str, base_url: str = "https://app.cheqpoint.co", **kwargs: Any) -> None:
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", CheqpointClient(api_key=api_key, base_url=base_url))

    def _run(
        self,
        action: str,
        summary: str,
        details: dict[str, Any],
        risk_score: float = 0.5,
        justification: Optional[str] = None,
    ) -> str:
        """Synchronous execution — submits the request and polls for decision."""
        try:
            result = self._client.checkpoint(
                action=action,
                summary=summary,
                details=details,
                risk_score=risk_score,
                justification=justification,
            )
            notes = result.response_notes or "Approved by reviewer"
            return f"APPROVED: {notes}"
        except Exception as exc:
            return f"REJECTED: {exc}"

    async def _arun(
        self,
        action: str,
        summary: str,
        details: dict[str, Any],
        risk_score: float = 0.5,
        justification: Optional[str] = None,
    ) -> str:
        """Async execution delegates to the sync implementation (polling is blocking)."""
        return self._run(
            action=action,
            summary=summary,
            details=details,
            risk_score=risk_score,
            justification=justification,
        )
