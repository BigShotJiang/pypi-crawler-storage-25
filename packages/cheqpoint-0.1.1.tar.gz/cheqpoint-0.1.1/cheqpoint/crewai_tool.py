"""Cheqpoint CrewAI integration — human-in-the-loop approval tool."""

from __future__ import annotations

from typing import Any, Optional

from .client import CheqpointClient

try:
    from crewai.tools import BaseTool
    from pydantic import BaseModel, Field
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "crewai is required for CheqpointApprovalTool. "
        "Install it with: pip install cheqpoint[crewai]"
    ) from e


class _ApprovalInput(BaseModel):
    action: str = Field(
        description="Category of the action (e.g. 'send_email', 'process_refund', 'deploy_code')"
    )
    summary: str = Field(description="One-sentence description shown to the reviewer")
    details: dict[str, Any] = Field(description="Full structured payload for the action")
    risk_score: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Risk score 0.0–1.0"
    )
    justification: Optional[str] = Field(
        default=None, description="Optional agent reasoning for the reviewer"
    )


class CheqpointApprovalTool(BaseTool):
    """CrewAI tool that pauses agent execution and waits for human approval.

    Usage::

        from crewai import Agent, Task, Crew
        from cheqpoint.crewai_tool import CheqpointApprovalTool

        approval_tool = CheqpointApprovalTool(api_key="ck_...")

        agent = Agent(
            role="Financial Analyst",
            goal="Process refunds with human oversight",
            backstory="You process refunds and escalate risky ones for approval.",
            tools=[approval_tool],
        )
    """

    name: str = "request_human_approval"
    description: str = (
        "Request human approval before taking a consequential action. "
        "Call this tool when an action needs human review before execution. "
        "Provide action type, a clear summary, and full details. "
        "The tool blocks until a human approves or rejects the request."
    )
    args_schema: type[BaseModel] = _ApprovalInput

    _client: CheqpointClient

    def __init__(self, api_key: str, base_url: str = "https://app.cheqpoint.co", **kwargs: Any) -> None:
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", CheqpointClient(api_key=api_key, base_url=base_url))

    def _run(
        self,
        action: str,
        summary: str,
        details: dict[str, Any],
        risk_score: float = 0.5,
        justification: Optional[str] = None,
    ) -> str:
        """Execute the approval request and return the decision as a string."""
        try:
            result = self._client.checkpoint(
                action=action,
                summary=summary,
                details=details,
                risk_score=risk_score,
                justification=justification,
            )
            notes = result.response_notes or "Approved by reviewer"
            return f"APPROVED: {notes}"
        except Exception as exc:
            return f"REJECTED: {exc}"
