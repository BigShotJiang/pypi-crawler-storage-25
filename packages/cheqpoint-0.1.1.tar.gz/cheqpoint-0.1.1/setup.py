from setuptools import setup, find_packages

setup(
    name="cheqpoint",
    version="0.1.1",
    description="Human-in-the-loop approval SDK for AI agents",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Cheqpoint",
    url="https://cheqpoint.io",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "requests>=2.28.0",
    ],
    keywords=["cheqpoint", "human-in-the-loop", "ai", "agents", "approval"],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)
