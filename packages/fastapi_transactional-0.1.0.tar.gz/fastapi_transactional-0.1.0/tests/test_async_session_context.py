from unittest.mock import MagicMock

from fastapi_transactional import (
    clear_current_async_session,
    get_current_async_session,
    set_current_async_session,
)


def test_default_async_session_is_none():
    assert get_current_async_session() is None


def test_set_and_get_async_session():
    session = MagicMock()
    set_current_async_session(session)

    assert get_current_async_session() is session


def test_clear_async_session():
    set_current_async_session(MagicMock())
    clear_current_async_session()

    assert get_current_async_session() is None
