"""Shared test fixtures: ContextVar reset, mock session factories, real SQLite engines."""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from unittest.mock import MagicMock

import pytest
import pytest_asyncio
from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import sessionmaker

import fastapi_transactional
from fastapi_transactional import (
    clear_current_async_session,
    clear_current_session,
    configure,
)
from fastapi_transactional._config import _config


@pytest.fixture(autouse=True)
def _reset_context_and_config() -> Iterator[None]:
    """Ensure no leaks between tests: clear both ContextVars and clear configuration."""
    clear_current_session()
    clear_current_async_session()
    fastapi_transactional.reset()
    yield
    clear_current_session()
    clear_current_async_session()
    fastapi_transactional.reset()


# ---- Mock-based fixtures (unit tests) ----


@pytest.fixture
def mock_session() -> MagicMock:
    return MagicMock()


@pytest.fixture
def mock_session_factory(mock_session: MagicMock) -> MagicMock:
    factory = MagicMock(return_value=mock_session)
    configure(session_factory=factory)
    return factory


@pytest.fixture
def mock_async_session() -> MagicMock:
    session = MagicMock()

    async def _commit() -> None:
        return None

    async def _rollback() -> None:
        return None

    async def _close() -> None:
        return None

    session.commit.side_effect = _commit
    session.rollback.side_effect = _rollback
    session.close.side_effect = _close
    return session


@pytest.fixture
def mock_async_session_factory(mock_async_session: MagicMock) -> MagicMock:
    factory = MagicMock(return_value=mock_async_session)
    configure(async_session_factory=factory)
    return factory


# ---- Real-engine fixtures (integration tests) ----


@pytest.fixture
def sqlite_session_factory() -> Iterator[sessionmaker]:
    engine = create_engine("sqlite:///:memory:", future=True)
    factory = sessionmaker(bind=engine, autocommit=False, autoflush=False, future=True)
    _config.session_factory = factory
    yield factory
    engine.dispose()


@pytest_asyncio.fixture
async def aiosqlite_session_factory() -> AsyncIterator[async_sessionmaker[AsyncSession]]:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    factory = async_sessionmaker(bind=engine, autocommit=False, autoflush=False, expire_on_commit=False)
    _config.async_session_factory = factory
    yield factory
    await engine.dispose()
