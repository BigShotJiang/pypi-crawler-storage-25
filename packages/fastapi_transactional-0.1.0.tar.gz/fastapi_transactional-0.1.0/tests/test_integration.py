"""End-to-end tests against in-memory SQLite (sync) and aiosqlite (async).

These verify the full transactional contract — commit, rollback, nested
reuse, and ContextVar isolation — against a real database instead of mocks.
"""

from __future__ import annotations

import pytest
from sqlalchemy import Column, Integer, String, select
from sqlalchemy.orm import DeclarativeBase

from fastapi_transactional import (
    AsyncDatabaseRepository,
    DatabaseRepository,
    async_session_manager,
    session_manager,
    with_async_transaction,
    with_transaction,
)


class Base(DeclarativeBase):
    pass


class Widget(Base):
    __tablename__ = "widgets"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)


# ---- Sync ----


class WidgetRepo(DatabaseRepository):
    def add(self, name: str) -> None:
        assert self.db is not None
        self.db.add(Widget(name=name))


@pytest.fixture
def widget_tables(sqlite_session_factory):
    engine = sqlite_session_factory.kw["bind"]
    Base.metadata.create_all(engine)
    yield
    Base.metadata.drop_all(engine)


def test_sync_commit_persists_rows(sqlite_session_factory, widget_tables):
    class CreateWidget:
        def __init__(self):
            self.repo = WidgetRepo()

        @with_transaction
        def execute(self, name: str) -> None:
            self.repo.add(name)

    CreateWidget().execute("alpha")
    CreateWidget().execute("beta")

    with session_manager() as session:
        names = {w.name for w in session.scalars(select(Widget)).all()}

    assert names == {"alpha", "beta"}


def test_sync_rollback_discards_changes(sqlite_session_factory, widget_tables):
    class CreateThenFail:
        def __init__(self):
            self.repo = WidgetRepo()

        @with_transaction
        def execute(self) -> None:
            self.repo.add("ghost")
            raise RuntimeError("boom")

    with pytest.raises(RuntimeError):
        CreateThenFail().execute()

    with session_manager() as session:
        assert session.query(Widget).count() == 0


def test_sync_nested_use_cases_share_transaction_rollback(sqlite_session_factory, widget_tables):
    """If the outer fails after the inner succeeds, inner's changes also roll back."""

    class Inner:
        def __init__(self):
            self.repo = WidgetRepo()

        @with_transaction
        def execute(self) -> None:
            self.repo.add("inner")

    class Outer:
        def __init__(self):
            self.repo = WidgetRepo()
            self.inner = Inner()

        @with_transaction
        def execute(self) -> None:
            self.inner.execute()
            self.repo.add("outer")
            raise RuntimeError("boom")

    with pytest.raises(RuntimeError):
        Outer().execute()

    with session_manager() as session:
        assert session.query(Widget).count() == 0


# ---- Async ----


class AsyncWidgetRepo(AsyncDatabaseRepository):
    async def add(self, name: str) -> None:
        assert self.db is not None
        self.db.add(Widget(name=name))


@pytest.fixture
async def async_widget_tables(aiosqlite_session_factory):
    engine = aiosqlite_session_factory.kw["bind"]
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


async def test_async_commit_persists_rows(aiosqlite_session_factory, async_widget_tables):
    class CreateWidget:
        def __init__(self):
            self.repo = AsyncWidgetRepo()

        @with_async_transaction
        async def execute(self, name: str) -> None:
            await self.repo.add(name)

    await CreateWidget().execute("alpha")
    await CreateWidget().execute("beta")

    async with async_session_manager() as session:
        result = await session.scalars(select(Widget))
        names = {w.name for w in result.all()}

    assert names == {"alpha", "beta"}


async def test_async_rollback_discards_changes(aiosqlite_session_factory, async_widget_tables):
    class CreateThenFail:
        def __init__(self):
            self.repo = AsyncWidgetRepo()

        @with_async_transaction
        async def execute(self) -> None:
            await self.repo.add("ghost")
            raise RuntimeError("boom")

    with pytest.raises(RuntimeError):
        await CreateThenFail().execute()

    async with async_session_manager() as session:
        result = await session.scalars(select(Widget))
        assert len(result.all()) == 0


async def test_async_nested_use_cases_share_transaction_rollback(aiosqlite_session_factory, async_widget_tables):
    class Inner:
        def __init__(self):
            self.repo = AsyncWidgetRepo()

        @with_async_transaction
        async def execute(self) -> None:
            await self.repo.add("inner")

    class Outer:
        def __init__(self):
            self.repo = AsyncWidgetRepo()
            self.inner = Inner()

        @with_async_transaction
        async def execute(self) -> None:
            await self.inner.execute()
            await self.repo.add("outer")
            raise RuntimeError("boom")

    with pytest.raises(RuntimeError):
        await Outer().execute()

    async with async_session_manager() as session:
        result = await session.scalars(select(Widget))
        assert len(result.all()) == 0
