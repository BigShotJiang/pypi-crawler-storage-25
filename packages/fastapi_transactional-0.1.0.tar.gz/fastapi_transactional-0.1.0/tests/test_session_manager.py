import pytest

from fastapi_transactional import (
    DatabaseRepository,
    get_current_session,
    session_manager,
    with_transaction,
)


def test_session_manager_commits_on_success(mock_session_factory, mock_session):
    with session_manager() as session:
        assert session is mock_session

    mock_session.commit.assert_called_once()
    mock_session.close.assert_called_once()
    mock_session.rollback.assert_not_called()


def test_session_manager_rollbacks_on_exception(mock_session_factory, mock_session):
    with pytest.raises(ValueError):
        with session_manager():
            raise ValueError("boom")

    mock_session.rollback.assert_called_once()
    mock_session.close.assert_called_once()
    mock_session.commit.assert_not_called()


def test_session_manager_clears_context_after_use(mock_session_factory, mock_session):
    with session_manager():
        assert get_current_session() is mock_session

    assert get_current_session() is None


def test_session_manager_reuses_existing_session(mock_session_factory):
    with session_manager() as outer:
        with session_manager() as inner:
            assert inner is outer

    mock_session_factory.assert_called_once()


def test_session_manager_raises_when_unconfigured():
    # Autouse fixture resets config, so this should raise.
    with pytest.raises(RuntimeError, match="not configured for sync"):
        with session_manager():
            pass


def test_with_transaction_injects_session_into_repositories(mock_session_factory, mock_session):
    class Repo(DatabaseRepository):
        pass

    class UseCase:
        def __init__(self):
            self.repo = Repo()

        @with_transaction
        def execute(self):
            return self.repo.db

    result = UseCase().execute()

    assert result is mock_session
    mock_session.commit.assert_called_once()


def test_with_transaction_rollbacks_on_exception(mock_session_factory, mock_session):
    class UseCase:
        @with_transaction
        def execute(self):
            raise RuntimeError("boom")

    with pytest.raises(RuntimeError):
        UseCase().execute()

    mock_session.rollback.assert_called_once()
    mock_session.commit.assert_not_called()


def test_with_transaction_returns_method_result(mock_session_factory):
    class UseCase:
        @with_transaction
        def execute(self, n):
            return n * 2

    assert UseCase().execute(21) == 42


def test_with_transaction_nested_use_cases_share_session(mock_session_factory, mock_session):
    class InnerRepo(DatabaseRepository):
        pass

    class OuterRepo(DatabaseRepository):
        pass

    class Inner:
        def __init__(self):
            self.repo = InnerRepo()

        @with_transaction
        def execute(self):
            return self.repo.db

    class Outer:
        def __init__(self):
            self.repo = OuterRepo()
            self.inner = Inner()

        @with_transaction
        def execute(self):
            return self.repo.db, self.inner.execute()

    outer_db, inner_db = Outer().execute()

    assert outer_db is mock_session
    assert inner_db is mock_session
    # Only one session ever opened.
    mock_session_factory.assert_called_once()
    # And only one commit at the end.
    mock_session.commit.assert_called_once()
