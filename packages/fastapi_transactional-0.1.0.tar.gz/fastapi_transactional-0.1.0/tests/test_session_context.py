from unittest.mock import MagicMock

from fastapi_transactional import (
    clear_current_session,
    get_current_session,
    set_current_session,
)


def test_default_session_is_none():
    assert get_current_session() is None


def test_set_and_get_session():
    session = MagicMock()
    set_current_session(session)

    assert get_current_session() is session


def test_clear_session():
    set_current_session(MagicMock())
    clear_current_session()

    assert get_current_session() is None


def test_overwrite_session():
    s1, s2 = MagicMock(), MagicMock()

    set_current_session(s1)
    assert get_current_session() is s1

    set_current_session(s2)
    assert get_current_session() is s2
