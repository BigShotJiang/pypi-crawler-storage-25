from unittest.mock import MagicMock

import pytest

import fastapi_transactional
from fastapi_transactional import configure
from fastapi_transactional._config import (
    _config,
    _get_async_session_factory,
    _get_session_factory,
)


def test_configure_sync_factory_sets_it():
    factory = MagicMock()
    configure(session_factory=factory)
    assert _get_session_factory() is factory


def test_configure_async_factory_sets_it():
    factory = MagicMock()
    configure(async_session_factory=factory)
    assert _get_async_session_factory() is factory


def test_configure_both_factories():
    sync, async_ = MagicMock(), MagicMock()
    configure(session_factory=sync, async_session_factory=async_)
    assert _get_session_factory() is sync
    assert _get_async_session_factory() is async_


def test_configure_with_neither_raises():
    with pytest.raises(ValueError):
        configure()


def test_get_sync_factory_when_unconfigured_raises():
    with pytest.raises(RuntimeError, match="not configured for sync"):
        _get_session_factory()


def test_get_async_factory_when_unconfigured_raises():
    with pytest.raises(RuntimeError, match="not configured for async"):
        _get_async_session_factory()


def test_reset_clears_factories():
    configure(session_factory=MagicMock(), async_session_factory=MagicMock())
    fastapi_transactional.reset()
    assert _config.session_factory is None
    assert _config.async_session_factory is None
