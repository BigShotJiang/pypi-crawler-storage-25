from unittest.mock import MagicMock

from fastapi_transactional import AsyncDatabaseRepository, DatabaseRepository


def test_sync_repository_initializes_with_none_db():
    class Repo(DatabaseRepository):
        pass

    assert Repo().db is None


def test_sync_repository_set_session():
    class Repo(DatabaseRepository):
        pass

    repo = Repo()
    session = MagicMock()
    repo.set_session(session)

    assert repo.db is session


def test_async_repository_initializes_with_none_db():
    class Repo(AsyncDatabaseRepository):
        pass

    assert Repo().db is None


def test_async_repository_set_session():
    class Repo(AsyncDatabaseRepository):
        pass

    repo = Repo()
    session = MagicMock()
    repo.set_session(session)

    assert repo.db is session
