import pytest

from fastapi_transactional import (
    AsyncDatabaseRepository,
    async_session_manager,
    get_current_async_session,
    with_async_transaction,
)


async def test_async_session_manager_commits_on_success(mock_async_session_factory, mock_async_session):
    async with async_session_manager() as session:
        assert session is mock_async_session

    mock_async_session.commit.assert_called_once()
    mock_async_session.close.assert_called_once()
    mock_async_session.rollback.assert_not_called()


async def test_async_session_manager_rollbacks_on_exception(mock_async_session_factory, mock_async_session):
    with pytest.raises(ValueError):
        async with async_session_manager():
            raise ValueError("boom")

    mock_async_session.rollback.assert_called_once()
    mock_async_session.close.assert_called_once()
    mock_async_session.commit.assert_not_called()


async def test_async_session_manager_clears_context_after_use(mock_async_session_factory, mock_async_session):
    async with async_session_manager():
        assert get_current_async_session() is mock_async_session

    assert get_current_async_session() is None


async def test_async_session_manager_reuses_existing_session(mock_async_session_factory):
    async with async_session_manager() as outer:
        async with async_session_manager() as inner:
            assert inner is outer

    mock_async_session_factory.assert_called_once()


async def test_async_session_manager_raises_when_unconfigured():
    with pytest.raises(RuntimeError, match="not configured for async"):
        async with async_session_manager():
            pass


async def test_with_async_transaction_injects_session_into_repositories(mock_async_session_factory, mock_async_session):
    class Repo(AsyncDatabaseRepository):
        pass

    class UseCase:
        def __init__(self):
            self.repo = Repo()

        @with_async_transaction
        async def execute(self):
            return self.repo.db

    result = await UseCase().execute()

    assert result is mock_async_session
    mock_async_session.commit.assert_called_once()


async def test_with_async_transaction_rollbacks_on_exception(mock_async_session_factory, mock_async_session):
    class UseCase:
        @with_async_transaction
        async def execute(self):
            raise RuntimeError("boom")

    with pytest.raises(RuntimeError):
        await UseCase().execute()

    mock_async_session.rollback.assert_called_once()
    mock_async_session.commit.assert_not_called()


async def test_with_async_transaction_returns_method_result(mock_async_session_factory):
    class UseCase:
        @with_async_transaction
        async def execute(self, n):
            return n * 2

    assert await UseCase().execute(21) == 42


async def test_with_async_transaction_nested_use_cases_share_session(mock_async_session_factory, mock_async_session):
    class InnerRepo(AsyncDatabaseRepository):
        pass

    class OuterRepo(AsyncDatabaseRepository):
        pass

    class Inner:
        def __init__(self):
            self.repo = InnerRepo()

        @with_async_transaction
        async def execute(self):
            return self.repo.db

    class Outer:
        def __init__(self):
            self.repo = OuterRepo()
            self.inner = Inner()

        @with_async_transaction
        async def execute(self):
            inner_db = await self.inner.execute()
            return self.repo.db, inner_db

    outer_db, inner_db = await Outer().execute()

    assert outer_db is mock_async_session
    assert inner_db is mock_async_session
    mock_async_session_factory.assert_called_once()
    mock_async_session.commit.assert_called_once()
