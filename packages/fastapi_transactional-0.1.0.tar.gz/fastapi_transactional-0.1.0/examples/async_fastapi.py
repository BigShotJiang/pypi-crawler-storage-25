"""FastAPI app using fastapi-transactional with an async SQLAlchemy session.

Run with:
    pip install fastapi uvicorn aiosqlite fastapi-transactional
    python examples/async_fastapi.py
"""

from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from pydantic import BaseModel
from sqlalchemy import Column, Integer, String, select
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from fastapi_transactional import (
    AsyncDatabaseRepository,
    async_session_manager,
    configure,
    with_async_transaction,
)


class Base(DeclarativeBase):
    pass


class Widget(Base):
    __tablename__ = "widgets"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)


engine = create_async_engine("sqlite+aiosqlite:///./widgets_async.db")
AsyncSessionLocal = async_sessionmaker(bind=engine, expire_on_commit=False)
configure(async_session_factory=AsyncSessionLocal)


class WidgetRepository(AsyncDatabaseRepository):
    async def save(self, widget: Widget) -> None:
        assert self.db is not None
        self.db.add(widget)

    async def list_all(self) -> list[Widget]:
        assert self.db is not None
        result = await self.db.scalars(select(Widget))
        return list(result.all())


class CreateWidget:
    def __init__(self) -> None:
        self.repo = WidgetRepository()

    @with_async_transaction
    async def execute(self, name: str) -> None:
        await self.repo.save(Widget(name=name))


class CreateWidgetThenFail:
    def __init__(self) -> None:
        self.repo = WidgetRepository()

    @with_async_transaction
    async def execute(self, name: str) -> None:
        await self.repo.save(Widget(name=name))
        raise RuntimeError("intentional failure")


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    await engine.dispose()


app = FastAPI(lifespan=lifespan)


class WidgetIn(BaseModel):
    name: str


@app.post("/widgets")
async def create(payload: WidgetIn) -> dict[str, str]:
    await CreateWidget().execute(payload.name)
    return {"status": "ok"}


@app.post("/widgets/fail")
async def create_and_fail(payload: WidgetIn) -> dict[str, str]:
    try:
        await CreateWidgetThenFail().execute(payload.name)
    except RuntimeError as exc:
        return {"status": "rolled-back", "error": str(exc)}
    return {"status": "ok"}


@app.get("/widgets")
async def list_widgets() -> list[dict[str, object]]:
    async with async_session_manager() as session:
        result = await session.scalars(select(Widget))
        return [{"id": w.id, "name": w.name} for w in result.all()]


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000)
