"""FastAPI app using fastapi-transactional with a sync SQLite session.

Run with:
    pip install fastapi uvicorn fastapi-transactional
    python examples/sync_fastapi.py
"""

from __future__ import annotations

from fastapi import FastAPI
from pydantic import BaseModel
from sqlalchemy import Column, Integer, String, create_engine, select
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from fastapi_transactional import (
    DatabaseRepository,
    configure,
    session_manager,
    with_transaction,
)


class Base(DeclarativeBase):
    pass


class Widget(Base):
    __tablename__ = "widgets"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)


engine = create_engine("sqlite:///./widgets.db", future=True)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False, future=True)
Base.metadata.create_all(engine)
configure(session_factory=SessionLocal)


class WidgetRepository(DatabaseRepository):
    def save(self, widget: Widget) -> None:
        assert self.db is not None
        self.db.add(widget)

    def list_all(self) -> list[Widget]:
        assert self.db is not None
        return list(self.db.scalars(select(Widget)).all())


class CreateWidget:
    def __init__(self) -> None:
        self.repo = WidgetRepository()

    @with_transaction
    def execute(self, name: str) -> None:
        self.repo.save(Widget(name=name))


class CreateWidgetThenFail:
    """Demonstrates rollback: save succeeds, then we raise — the row never persists."""

    def __init__(self) -> None:
        self.repo = WidgetRepository()

    @with_transaction
    def execute(self, name: str) -> None:
        self.repo.save(Widget(name=name))
        raise RuntimeError("intentional failure")


app = FastAPI()


class WidgetIn(BaseModel):
    name: str


@app.post("/widgets")
def create(payload: WidgetIn) -> dict[str, str]:
    CreateWidget().execute(payload.name)
    return {"status": "ok"}


@app.post("/widgets/fail")
def create_and_fail(payload: WidgetIn) -> dict[str, str]:
    try:
        CreateWidgetThenFail().execute(payload.name)
    except RuntimeError as exc:
        return {"status": "rolled-back", "error": str(exc)}
    return {"status": "ok"}


@app.get("/widgets")
def list_widgets() -> list[dict[str, object]]:
    # Read-only — wrap in session_manager for context.
    with session_manager() as session:
        rows = session.scalars(select(Widget)).all()
        return [{"id": w.id, "name": w.name} for w in rows]


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000)
