# Examples

Runnable mini-apps showing `fastapi-transactional` end to end.

## Sync — `sync_fastapi.py`

A FastAPI app backed by SQLite that creates `Widget` rows inside a transaction.
The `/widgets/fail` endpoint demonstrates that an exception rolls back the
whole transaction even after a successful `repo.save()` call.

```bash
pip install fastapi uvicorn fastapi-transactional
python examples/sync_fastapi.py
# Then in another terminal:
curl -X POST localhost:8000/widgets -d '{"name":"alpha"}' -H content-type:application/json
curl -X POST localhost:8000/widgets/fail -d '{"name":"ghost"}' -H content-type:application/json
curl localhost:8000/widgets
```

## Async — `async_fastapi.py`

Same app, async stack (`AsyncSession` + aiosqlite).

```bash
pip install fastapi uvicorn aiosqlite fastapi-transactional
python examples/async_fastapi.py
```
