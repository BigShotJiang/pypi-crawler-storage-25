# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] — 2026-05-12

### Added

- Initial public release.
- Sync transactional API: `session_manager`, `with_transaction`, `DatabaseRepository`.
- Async transactional API: `async_session_manager`, `with_async_transaction`, `AsyncDatabaseRepository`.
- `ContextVar`-based session storage with `get/set/clear_current_session` and the async equivalents.
- `configure(session_factory=..., async_session_factory=...)` to wire SQLAlchemy session factories at startup.
- Nested-transaction support: nested use cases reuse the outermost session.
- PEP 561 type information (`py.typed`).

[Unreleased]: https://github.com/oviladrosa/fastapi-transactional/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/oviladrosa/fastapi-transactional/releases/tag/v0.1.0
