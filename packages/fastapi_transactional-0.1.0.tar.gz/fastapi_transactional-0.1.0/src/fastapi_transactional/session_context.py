"""Per-context storage for the active sync SQLAlchemy session.

Backed by ``ContextVar`` so each thread / asyncio task sees its own value,
which makes the session implicitly shared across repositories that run
inside the same transactional scope without having to pass it around.
"""

from __future__ import annotations

from contextvars import ContextVar

from sqlalchemy.orm import Session

_current_session: ContextVar[Session | None] = ContextVar("current_session", default=None)


def get_current_session() -> Session | None:
    """Return the session bound to the current context, or ``None``."""
    return _current_session.get()


def set_current_session(session: Session) -> None:
    """Bind ``session`` to the current context."""
    _current_session.set(session)


def clear_current_session() -> None:
    """Remove any session bound to the current context."""
    _current_session.set(None)
