"""Sync transactional scope: ``session_manager`` and ``@with_transaction``.

Open a new SQLAlchemy session, bind it to the context, commit on clean exit,
roll back on exception, and clear the context on the way out. Nested calls
reuse the outer session instead of opening a new one, which is what enables
composition between use cases.
"""

from __future__ import annotations

from collections.abc import Callable, Iterator
from contextlib import contextmanager
from functools import wraps
from typing import Any, TypeVar

from sqlalchemy.orm import Session

from ._config import _get_session_factory
from .repository import DatabaseRepository
from .session_context import (
    clear_current_session,
    get_current_session,
    set_current_session,
)

F = TypeVar("F", bound=Callable[..., Any])


@contextmanager
def session_manager() -> Iterator[Session]:
    """Provide a transactional scope around a series of operations.

    If a session is already bound to the current context (i.e. we are nested
    inside another ``session_manager`` block), that session is yielded as-is
    and the outer block stays responsible for commit / rollback / close.
    """
    existing_session = get_current_session()
    if existing_session is not None:
        yield existing_session
        return

    session_factory = _get_session_factory()
    session: Session = session_factory()
    try:
        set_current_session(session)
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        clear_current_session()
        session.close()


def _inject_session_into_instance(instance: Any, session: Session) -> None:
    """Set ``session`` on every :class:`DatabaseRepository` attribute of ``instance``."""
    for attr_name in dir(instance):
        if attr_name.startswith("__"):
            continue
        try:
            attr = getattr(instance, attr_name)
        except AttributeError:
            continue
        if isinstance(attr, DatabaseRepository):
            attr.set_session(session)


def with_transaction(func: F) -> F:
    """Wrap a method so it runs inside :func:`session_manager`.

    Before the wrapped method runs, every :class:`DatabaseRepository`
    attribute on ``self`` has its session set to the active one, so
    repositories can do ``self.db.add(...)`` etc. without any plumbing.
    """

    @wraps(func)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        with session_manager() as session:
            _inject_session_into_instance(self, session)
            return func(self, *args, **kwargs)

    return wrapper  # type: ignore[return-value]
