"""Per-context storage for the active async SQLAlchemy session.

Separate ``ContextVar`` from the sync one so that an application using both
sync and async sessions never accidentally cross-wires them.
"""

from __future__ import annotations

from contextvars import ContextVar

from sqlalchemy.ext.asyncio import AsyncSession

_current_async_session: ContextVar[AsyncSession | None] = ContextVar("current_async_session", default=None)


def get_current_async_session() -> AsyncSession | None:
    """Return the async session bound to the current context, or ``None``."""
    return _current_async_session.get()


def set_current_async_session(session: AsyncSession) -> None:
    """Bind ``session`` to the current context."""
    _current_async_session.set(session)


def clear_current_async_session() -> None:
    """Remove any async session bound to the current context."""
    _current_async_session.set(None)
