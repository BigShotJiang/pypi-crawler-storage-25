"""Module-level configuration for session factories.

Users call ``configure()`` once at application startup to wire in the
SQLAlchemy session factory the rest of the library should use. The library
keeps no global state beyond what is set here, and configuration can be
reset (useful in tests).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker
    from sqlalchemy.orm import Session, sessionmaker


class _Config:
    __slots__ = ("session_factory", "async_session_factory")

    def __init__(self) -> None:
        self.session_factory: sessionmaker[Session] | None = None
        self.async_session_factory: async_sessionmaker[AsyncSession] | None = None


_config = _Config()


def configure(
    *,
    session_factory: sessionmaker[Session] | None = None,
    async_session_factory: async_sessionmaker[AsyncSession] | None = None,
) -> None:
    """Register the session factory (sync, async, or both).

    Call this once at startup, after creating your SQLAlchemy engine(s).

    Example:
        from sqlalchemy import create_engine
        from sqlalchemy.orm import sessionmaker
        from fastapi_transactional import configure

        engine = create_engine("postgresql://...")
        SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
        configure(session_factory=SessionLocal)
    """
    if session_factory is None and async_session_factory is None:
        raise ValueError("configure() requires at least one of session_factory or async_session_factory.")
    if session_factory is not None:
        _config.session_factory = session_factory
    if async_session_factory is not None:
        _config.async_session_factory = async_session_factory


def reset() -> None:
    """Clear the registered session factories. Mostly useful in tests."""
    _config.session_factory = None
    _config.async_session_factory = None


def _get_session_factory() -> sessionmaker[Session]:
    if _config.session_factory is None:
        raise RuntimeError(
            "fastapi_transactional is not configured for sync sessions. "
            "Call configure(session_factory=...) at application startup."
        )
    return _config.session_factory


def _get_async_session_factory() -> async_sessionmaker[AsyncSession]:
    if _config.async_session_factory is None:
        raise RuntimeError(
            "fastapi_transactional is not configured for async sessions. "
            "Call configure(async_session_factory=...) at application startup."
        )
    return _config.async_session_factory
