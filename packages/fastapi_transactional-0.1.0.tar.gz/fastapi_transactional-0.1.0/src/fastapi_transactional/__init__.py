"""fastapi-transactional — transactional session management for SQLAlchemy.

Public API:
    Configuration
        configure, reset

    Sync
        session_manager, with_transaction
        get_current_session, set_current_session, clear_current_session
        DatabaseRepository

    Async
        async_session_manager, with_async_transaction
        get_current_async_session, set_current_async_session, clear_current_async_session
        AsyncDatabaseRepository
"""

from ._config import configure, reset
from .async_session_context import (
    clear_current_async_session,
    get_current_async_session,
    set_current_async_session,
)
from .async_session_manager import async_session_manager, with_async_transaction
from .repository import AsyncDatabaseRepository, DatabaseRepository
from .session_context import (
    clear_current_session,
    get_current_session,
    set_current_session,
)
from .session_manager import session_manager, with_transaction

__version__ = "0.1.0"

__all__ = [
    "__version__",
    "configure",
    "reset",
    # Sync
    "session_manager",
    "with_transaction",
    "get_current_session",
    "set_current_session",
    "clear_current_session",
    "DatabaseRepository",
    # Async
    "async_session_manager",
    "with_async_transaction",
    "get_current_async_session",
    "set_current_async_session",
    "clear_current_async_session",
    "AsyncDatabaseRepository",
]
