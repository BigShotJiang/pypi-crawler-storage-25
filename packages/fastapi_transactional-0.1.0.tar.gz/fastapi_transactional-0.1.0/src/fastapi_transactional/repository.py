"""Base classes for repositories that participate in a managed transaction.

A repository inheriting from :class:`DatabaseRepository` (sync) or
:class:`AsyncDatabaseRepository` (async) exposes a ``self.db`` session
slot. When the repository instance is an attribute of an object whose
method is decorated with ``@with_transaction`` / ``@with_async_transaction``,
the active session is injected into ``self.db`` for the duration of the call.
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session


class DatabaseRepository:
    """Base class for sync repositories backed by a SQLAlchemy session."""

    def __init__(self) -> None:
        self.db: Session | None = None

    def set_session(self, db: Session) -> None:
        self.db = db


class AsyncDatabaseRepository:
    """Base class for async repositories backed by an AsyncSession."""

    def __init__(self) -> None:
        self.db: AsyncSession | None = None

    def set_session(self, db: AsyncSession) -> None:
        self.db = db
