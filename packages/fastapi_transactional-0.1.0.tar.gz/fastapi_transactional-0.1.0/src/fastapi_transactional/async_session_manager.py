"""Async transactional scope: ``async_session_manager`` + ``@with_async_transaction``."""

from __future__ import annotations

from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from functools import wraps
from typing import Any, TypeVar

from sqlalchemy.ext.asyncio import AsyncSession

from ._config import _get_async_session_factory
from .async_session_context import (
    clear_current_async_session,
    get_current_async_session,
    set_current_async_session,
)
from .repository import AsyncDatabaseRepository

F = TypeVar("F", bound=Callable[..., Awaitable[Any]])


@asynccontextmanager
async def async_session_manager() -> AsyncIterator[AsyncSession]:
    """Async counterpart to :func:`session_manager`.

    Yields an :class:`AsyncSession`, commits on clean exit, rolls back on
    exception, and clears the context on the way out. Nested calls reuse the
    outer session.
    """
    existing_session = get_current_async_session()
    if existing_session is not None:
        yield existing_session
        return

    session_factory = _get_async_session_factory()
    session: AsyncSession = session_factory()
    try:
        set_current_async_session(session)
        yield session
        await session.commit()
    except Exception:
        await session.rollback()
        raise
    finally:
        clear_current_async_session()
        await session.close()


def _inject_async_session_into_instance(instance: Any, session: AsyncSession) -> None:
    """Set ``session`` on every :class:`AsyncDatabaseRepository` attribute of ``instance``."""
    for attr_name in dir(instance):
        if attr_name.startswith("__"):
            continue
        try:
            attr = getattr(instance, attr_name)
        except AttributeError:
            continue
        if isinstance(attr, AsyncDatabaseRepository):
            attr.set_session(session)


def with_async_transaction(func: F) -> F:
    """Async counterpart to :func:`with_transaction`.

    Wrap a coroutine method so it runs inside :func:`async_session_manager`,
    injecting the active session into every :class:`AsyncDatabaseRepository`
    attribute of ``self`` before the method body runs.
    """

    @wraps(func)
    async def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        async with async_session_manager() as session:
            _inject_async_session_into_instance(self, session)
            return await func(self, *args, **kwargs)

    return wrapper  # type: ignore[return-value]
