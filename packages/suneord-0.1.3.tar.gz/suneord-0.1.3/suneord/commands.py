from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any


class Commands:
    def __init__(self, bot: Any) -> None:
        self.bot = bot

    def command(self, name: str | None = None) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
        return self.bot.command(name=name)

    def event(self, coro: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
        return self.bot.event(coro)
