from __future__ import annotations

import asyncio
import contextlib
import inspect
import json
import time
from collections.abc import Awaitable, Callable, Mapping
from typing import Any

import aiohttp

from .context import Context

DISCORD_API_BASE = "https://discord.com/api/v10"
DISCORD_GATEWAY_URL = "wss://gateway.discord.gg/?v=10&encoding=json"
DEFAULT_INTENTS = (1 << 0) | (1 << 9) | (1 << 15)


class Bot:
    def __init__(
        self,
        prefix: str,
        intents: int = DEFAULT_INTENTS,
        *,
        status: str = "online",
        status_text: str | None = None,
    ) -> None:
        self.prefix = prefix
        self.intents = intents
        self.status = status
        self.status_text = status_text
        self.token: str | None = None
        self.user: Mapping[str, Any] | None = None
        self.session: aiohttp.ClientSession | None = None
        self.ws: aiohttp.ClientWebSocketResponse | None = None
        self.sequence: int | None = None
        self.session_id: str | None = None
        self._events: dict[str, Callable[..., Awaitable[Any]]] = {}
        self._commands: dict[str, Callable[..., Awaitable[Any]]] = {}
        self._heartbeat_interval: float | None = None
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._heartbeat_ack = True
        self._last_heartbeat_sent_at: float | None = None
        self.latency: float = 0.0

    def event(self, coro: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
        if not inspect.iscoroutinefunction(coro):
            raise TypeError("Event handler must be async.")
        self._events[coro.__name__] = coro
        return coro

    def command(self, name: str | None = None) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
        def decorator(coro: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
            if not inspect.iscoroutinefunction(coro):
                raise TypeError("Command handler must be async.")
            command_name = (name or coro.__name__).lower()
            self._commands[command_name] = coro
            return coro

        return decorator

    def run(self, token: str) -> None:
        asyncio.run(self.start(token))

    async def start(self, token: str) -> None:
        self.token = token
        headers = {
            "Authorization": f"Bot {token}",
            "User-Agent": "suneord (https://github.com/example/suneord, 0.1.1)",
        }
        async with aiohttp.ClientSession(
            headers=headers,
            json_serialize=lambda data: json.dumps(data, ensure_ascii=False),
        ) as session:
            self.session = session
            try:
                async with session.ws_connect(DISCORD_GATEWAY_URL) as ws:
                    self.ws = ws
                    await self._gateway_loop()
            finally:
                await self.close()

    async def http_request(self, method: str, path: str, **kwargs: Any) -> Any:
        if self.session is None:
            raise RuntimeError("HTTP session is not started.")

        async with self.session.request(method, f"{DISCORD_API_BASE}{path}", **kwargs) as response:
            if response.status >= 400:
                text = await response.text()
                raise RuntimeError(f"Discord API error {response.status}: {text}")
            if response.content_type == "application/json":
                return await response.json()
            return await response.text()

    async def _gateway_loop(self) -> None:
        if self.ws is None:
            raise RuntimeError("Gateway websocket is not started.")

        async for message in self.ws:
            if message.type == aiohttp.WSMsgType.TEXT:
                await self._handle_gateway_payload(json.loads(message.data))
                continue
            if message.type == aiohttp.WSMsgType.CLOSED:
                break
            if message.type == aiohttp.WSMsgType.ERROR:
                raise RuntimeError("Discord gateway websocket error.")

    async def _handle_gateway_payload(self, payload: Mapping[str, Any]) -> None:
        op = payload.get("op")
        event_name = payload.get("t")
        data = payload.get("d")
        self.sequence = payload.get("s", self.sequence)

        if op == 10:
            self._heartbeat_interval = data["heartbeat_interval"] / 1000
            await self._start_heartbeat()
            await self._identify()
            return

        if op == 11:
            self._heartbeat_ack = True
            if self._last_heartbeat_sent_at is not None:
                self.latency = time.perf_counter() - self._last_heartbeat_sent_at
            return

        if op == 0 and event_name is not None:
            if event_name == "READY":
                self.session_id = data["session_id"]
                self.user = data["user"]
            await self._dispatch(event_name, data)
            return

        if op == 7:
            raise RuntimeError("Discord gateway requested reconnect.")

        if op == 9:
            raise RuntimeError("Discord gateway invalid session.")

    async def _start_heartbeat(self) -> None:
        if self._heartbeat_interval is None:
            return
        if self._heartbeat_task is not None and not self._heartbeat_task.done():
            return
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

    async def _heartbeat_loop(self) -> None:
        assert self.ws is not None
        assert self._heartbeat_interval is not None

        while True:
            await asyncio.sleep(self._heartbeat_interval)
            if not self._heartbeat_ack:
                raise RuntimeError("Discord gateway heartbeat was not acknowledged.")
            self._heartbeat_ack = False
            self._last_heartbeat_sent_at = time.perf_counter()
            await self.ws.send_json({"op": 1, "d": self.sequence})

    async def _identify(self) -> None:
        if self.ws is None or self.token is None:
            raise RuntimeError("Bot is not ready to identify.")

        await self.ws.send_json(
            {
                "op": 2,
                "d": {
                    "token": self.token,
                    "intents": self.intents,
                    "properties": {
                        "os": "windows",
                        "browser": "suneord",
                        "device": "suneord",
                    },
                    "presence": self._presence_payload(),
                },
            }
        )

    def _presence_payload(self) -> dict[str, Any]:
        activities: list[dict[str, Any]] = []
        if self.status_text:
            activities.append(
                {
                    "name": "Custom Status",
                    "type": 4,
                    "state": self.status_text,
                }
            )
        return {
            "since": None,
            "activities": activities,
            "status": self.status,
            "afk": False,
        }

    async def set_presence(self, *, status: str | None = None, text: str | None = None) -> None:
        if status is not None:
            self.status = status
        self.status_text = text
        if self.ws is not None:
            await self.ws.send_json({"op": 3, "d": self._presence_payload()})

    async def _dispatch(self, event_name: str, data: Mapping[str, Any]) -> None:
        handler = self._events.get(f"on_{event_name.lower()}")
        if handler is not None:
            await handler(*self._build_event_args(event_name, data))

        if event_name == "MESSAGE_CREATE":
            await self._process_message(data)

    def _build_event_args(self, event_name: str, data: Mapping[str, Any]) -> tuple[Any, ...]:
        if event_name == "READY":
            return ()
        return (data,)

    async def _process_message(self, message: Mapping[str, Any]) -> None:
        author = message.get("author", {})
        if author.get("bot"):
            return

        content = message.get("content", "")
        if not content.startswith(self.prefix):
            return

        parts = content[len(self.prefix) :].strip().split()
        if not parts:
            return

        command_name = parts[0].lower()
        command = self._commands.get(command_name)
        if command is None:
            return

        ctx = Context(self, message, command_name, parts[1:])
        await command(ctx, *ctx.args)

    async def close(self) -> None:
        if self._heartbeat_task is not None:
            self._heartbeat_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._heartbeat_task
        if self.ws is not None and not self.ws.closed:
            await self.ws.close()
