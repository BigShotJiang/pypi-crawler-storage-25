from __future__ import annotations

from datetime import datetime
from typing import Any


class Embed:
    def __init__(
        self,
        *,
        title: str | None = None,
        description: str | None = None,
        colour: int | None = None,
        color: int | None = None,
    ) -> None:
        self.title = title
        self.description = description
        self.colour = colour if colour is not None else color
        self.footer: dict[str, Any] | None = None
        self.timestamp: datetime | None = None

    def set_footer(self, *, text: str | None = None, icon_url: str | None = None) -> None:
        self.footer = {}
        if text is not None:
            self.footer["text"] = text
        if icon_url is not None:
            self.footer["icon_url"] = icon_url

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if self.title is not None:
            payload["title"] = self.title
        if self.description is not None:
            payload["description"] = self.description
        if self.colour is not None:
            payload["color"] = self.colour
        if self.footer:
            payload["footer"] = self.footer
        if self.timestamp is not None:
            payload["timestamp"] = self.timestamp.isoformat()
        return payload
