from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .embeds import Embed


class _Asset:
    def __init__(self, url: str | None) -> None:
        self.url = url


class _Author:
    def __init__(self, data: Mapping[str, Any]) -> None:
        self._data = data
        avatar_hash = data.get("avatar")
        user_id = data.get("id")
        avatar_url = None
        if avatar_hash and user_id:
            avatar_url = f"https://cdn.discordapp.com/avatars/{user_id}/{avatar_hash}.png"
        self.avatar = _Asset(avatar_url)

    @property
    def id(self) -> str | None:
        return self._data.get("id")

    @property
    def name(self) -> str | None:
        return self._data.get("username")

    @property
    def mention(self) -> str:
        return f"<@{self.id}>"


class Context:
    def __init__(self, bot: Any, message: Mapping[str, Any], command_name: str, args: list[str]) -> None:
        self.bot = bot
        self.message = message
        self.command_name = command_name
        self.args = args

    @property
    def author(self) -> _Author:
        return _Author(self.message["author"])

    @property
    def channel_id(self) -> str:
        return self.message["channel_id"]

    @property
    def content(self) -> str:
        return self.message.get("content", "")

    async def send(self, content: str | None = None, *, embed: Embed | None = None) -> Mapping[str, Any]:
        payload: dict[str, Any] = {}
        if content is not None:
            payload["content"] = content
        if embed is not None:
            payload["embeds"] = [embed.to_dict()]
        return await self.bot.http_request(
            "POST",
            f"/channels/{self.channel_id}/messages",
            json=payload,
        )

    async def reply(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        mention_author: bool = True,
    ) -> Mapping[str, Any]:
        payload: dict[str, Any] = {
            "message_reference": {"message_id": self.message["id"]},
            "allowed_mentions": {"replied_user": mention_author},
        }
        if content is not None:
            payload["content"] = content
        if embed is not None:
            payload["embeds"] = [embed.to_dict()]
        return await self.bot.http_request(
            "POST",
            f"/channels/{self.channel_id}/messages",
            json=payload,
        )
