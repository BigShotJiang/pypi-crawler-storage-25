# suneord

Minimal Python library for Discord bots with direct Discord REST API and Gateway usage.

## Install

```bash
pip install .
```

## Example

```python
import suneord
from suneord import Bot

bot = Bot(prefix="!", status="idle", status_text="проверяет пинги")


@bot.event
async def on_ready():
    print("Bot is ready")


@bot.command()
async def ping(ctx):
    embed = suneord.Embed(
        title="🏓 Понг!",
        description=f"Задержка: {round(bot.latency * 1000)}ms",
        colour=0x57F287,
    )
    embed.set_footer(text=f"Запросил {ctx.author.name}", icon_url=ctx.author.avatar.url)
    embed.timestamp = suneord.utils.utcnow()
    await ctx.reply(embed=embed, mention_author=False)


bot.run("TOKEN")
```
