"""
Yoro Maps Django integration.

Add to your settings::

    import yoromaps

    INSTALLED_APPS = [..., "yoromaps.django"]

    DATABASES = {
        "default": { ... },
        "maps": yoromaps.db_config("/path/to/country.yoromaps"),
    }

    DATABASE_ROUTERS = ["yoromaps.django.router.YoroMapsRouter"]
"""

default_app_config = "yoromaps.django.apps.YoroMapsConfig"
