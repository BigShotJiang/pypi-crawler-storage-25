#!/usr/bin/env python3
"""
tofu-assist REPL — Interactive session for natural language infrastructure management.

Entry point:
    tofu-assist (no args, TTY) → run_repl()

Exposed for testing:
    run_repl()
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from display import (
    print_generation_result, print_security_scan,
    print_plan_result, print_error, print_approval_prompt, print_step,
)


@dataclass
class SessionState:
    provider: str = ""
    region: str = ""
    tf_dir: str = ""
    files: dict = field(default_factory=dict)
    last_plan: Any = None
    last_cost: str = ""
    security_findings: list = field(default_factory=list)
    running: bool = True


def intent_router(user_input: str) -> str:
    text = user_input.lower().strip()

    if text in ("exit", "quit", "bye"):
        return "exit"

    if text in ("help", "what can i do"):
        return "help"

    plan_kw = ["show plan", "summary", "overview", "what changed", "whats in the plan"]
    if any(kw in text for kw in plan_kw):
        return "plan"

    edit_kw = ["change", "make it", "actually", "modify", "update", "switch", "instead", "replace"]
    if any(kw in text for kw in edit_kw):
        return "edit"

    cost_kw = ["cost", "how much", "pricing", "what will this cost"]
    if any(kw in text for kw in cost_kw):
        return "cost"

    security_kw = ["security", "scan", "vulnerabilities", "risks", "show me the risks"]
    if any(kw in text for kw in security_kw):
        return "security"

    apply_kw = ["apply", "ship it", "deploy", "provision", "go"]
    if any(kw in text for kw in apply_kw):
        return "apply"

    explain_kw = ["explain", "what does this do", "describe", "tell me about"]
    if any(kw in text for kw in explain_kw):
        return "explain"

    return "generate"


def handle_generate(state: SessionState, user_input: str) -> None:
    from generate import detect_provider, generate_tf
    from explain import analyze_plan, load_plan_json, validate_schema, run_security_scan
    from tofu_assist import run_tofu_plan

    if not state.provider:
        state.provider, state.region = detect_provider()

    if state.provider == "unknown":
        print_error(
            "Could not detect cloud provider.\n"
            "  Set AWS_PROFILE, GOOGLE_APPLICATION_CREDENTIALS, or ARM_SUBSCRIPTION_ID."
        )
        return

    print_step("Generating configuration...")
    print()

    result = generate_tf(user_input, state.provider, state.region)

    if not result.success:
        print_generation_result(False, result.files, result.pending_dir, result.error)
        return

    print_generation_result(True, result.files)
    state.files = result.files
    state.tf_dir = result.pending_dir

    security = run_security_scan(state.tf_dir)
    tool_status = [f for f in security.findings
                   if "unavailable" in f.lower() or "timed out" in f.lower()]
    real_findings = [f for f in security.findings if f not in tool_status]
    state.security_findings = security.findings
    print_security_scan(security.findings, tool_status)

    print_step("Running tofu plan...")
    success, plan_json, error = run_tofu_plan(state.tf_dir)

    if not success:
        print_error(f"{error}\n  Files saved to: {state.tf_dir}")
        return

    plan_path = Path(state.tf_dir) / "plan.json"
    plan_path.write_text(plan_json)

    plan = load_plan_json(plan_json)
    if plan is None:
        print_error("Could not parse plan output")
        return

    schema_error = validate_schema(plan)
    if schema_error:
        print_error(schema_error)
        return

    explain_result = analyze_plan(plan)

    if real_findings:
        explain_result.attention_items = real_findings + explain_result.attention_items

    state.last_plan = explain_result
    print()
    print_plan_result(explain_result, str(plan_path), tf_dir=state.tf_dir)


def handle_edit(state: SessionState, user_input: str) -> None:
    if not state.tf_dir:
        print_error("Nothing to edit yet. Try generating something first.")
        return

    from edit import edit_existing, show_diff
    from explain import analyze_plan, load_plan_json
    from tofu_assist import run_tofu_plan

    print_step("Editing configuration...")
    print()

    result = edit_existing(user_input, state.tf_dir)

    if not result.success:
        print_error(f"Edit failed: {result.error}")
        return

    diff = show_diff(result.original_files, result.modified_files)
    if diff.strip():
        print("Changes:")
        print(diff)
        print()

    state.tf_dir = result.pending_dir
    state.files = result.modified_files

    print_step("Running tofu plan...")
    success, plan_json, error = run_tofu_plan(state.tf_dir)

    if not success:
        print_error(f"{error}\n  Files saved to: {state.tf_dir}")
        return

    plan_path = Path(state.tf_dir) / "plan.json"
    plan_path.write_text(plan_json)

    plan = load_plan_json(plan_json)
    if plan is None:
        print_error("Could not parse plan output")
        return

    explain_result = analyze_plan(plan)
    state.last_plan = explain_result
    print()
    print_plan_result(explain_result, str(plan_path), tf_dir=state.tf_dir)


def handle_plan(state: SessionState) -> None:
    if not state.tf_dir:
        print_error("No plan available. Generate something first.")
        return

    from explain import analyze_plan, load_plan_json
    from tofu_assist import run_tofu_plan

    print_step("Running tofu plan...")
    success, plan_json, error = run_tofu_plan(state.tf_dir)

    if not success:
        print_error(error)
        return

    plan_path = Path(state.tf_dir) / "plan.json"
    plan_path.write_text(plan_json)

    plan = load_plan_json(plan_json)
    if plan is None:
        print_error("Could not parse plan output")
        return

    explain_result = analyze_plan(plan)
    state.last_plan = explain_result
    print()
    print_plan_result(explain_result, str(plan_path), tf_dir=state.tf_dir)


def handle_cost(state: SessionState) -> None:
    if not state.tf_dir:
        print_error("No infrastructure to estimate. Generate something first.")
        return

    from explain import get_cost_estimate

    plan_path = Path(state.tf_dir) / "plan.json"
    if not plan_path.exists():
        print_error("No plan JSON found. Run a plan first.")
        return

    cost = get_cost_estimate(str(plan_path))
    state.last_cost = cost
    print(f"Estimated cost: {cost}")


def handle_security(state: SessionState) -> None:
    if not state.tf_dir:
        print_error("No files to scan. Generate something first.")
        return

    from explain import run_security_scan

    security = run_security_scan(state.tf_dir)
    tool_status = [f for f in security.findings
                   if "unavailable" in f.lower() or "timed out" in f.lower()]
    state.security_findings = security.findings
    print_security_scan(security.findings, tool_status)


def handle_explain(state: SessionState) -> None:
    if state.last_plan is None:
        print_error("No plan to explain. Generate something first.")
        return

    from explain import render_plain

    plan_path = str(Path(state.tf_dir) / "plan.json") if state.tf_dir else None
    output = render_plain(state.last_plan, plan_path)
    print(output)


def handle_apply(state: SessionState) -> None:
    if not state.tf_dir or state.last_plan is None:
        print_error("No plan to apply. Generate something first.")
        return

    from tofu_assist import run_tofu_apply
    from generate import archive_applied

    print()
    print_plan_result(state.last_plan, tf_dir=state.tf_dir)

    critical_risks = [a for a in state.last_plan.attention_items if a.startswith("\u26db")]
    choice = print_approval_prompt(bool(critical_risks), critical_risks)

    if choice is None:
        print(f"Files saved to: {state.tf_dir}")
        return

    if choice in ("y", "yes"):
        print_step("Applying...")
        success, output = run_tofu_apply(state.tf_dir)
        if success:
            print("\u2713 Infrastructure provisioned successfully.")
            applied = archive_applied(state.tf_dir)
            if applied:
                print(f"  Config archived to: {applied}")
            state.tf_dir = ""
            state.files = {}
            state.last_plan = None
        else:
            print_error(f"Apply failed:\n{output}")
    else:
        print(f"Files saved to: {state.tf_dir}")


def handle_help() -> None:
    from display import is_plain_mode

    if is_plain_mode():
        print("Available commands:")
        print("  describe what you want     Generate infrastructure config")
        print("  change/modify/update ...    Edit existing config")
        print("  show plan/summary           Show plan summary")
        print("  cost/how much               Show cost estimate")
        print("  security/scan               Run security scan")
        print("  explain                     Explain the current plan")
        print("  apply/deploy/ship it        Apply the plan")
        print("  help                        Show this help")
        print("  exit/quit/bye               Exit REPL")
        return

    from rich.panel import Panel
    from rich.console import Console
    from rich.table import Table

    console = Console()
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan")
    grid.add_column()

    grid.add_row("describe what you want", "   Generate infrastructure config")
    grid.add_row("change/modify/update ...", "  Edit existing config")
    grid.add_row("show plan/summary", "         Show plan summary")
    grid.add_row("cost/how much", "             Show cost estimate")
    grid.add_row("security/scan", "             Run security scan")
    grid.add_row("explain", "                   Explain the current plan")
    grid.add_row("apply/deploy/ship it", "      Apply the plan")
    grid.add_row("help", "                      Show this help")
    grid.add_row("exit/quit/bye", "             Exit REPL")

    panel = Panel(grid, title="REPL Commands", border_style="cyan")
    console.print(panel)


def run_repl() -> None:
    """Main REPL entry point. Called from tofu_assist.main() when no args and TTY."""
    import os
    from importlib.metadata import version as pkg_version
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    from generate import detect_provider
    from llm_utils import MODEL

    state = SessionState()
    console = Console()

    # ── Codex-style banner ──────────────────────────────────────────
    try:
        ver = pkg_version("tofu-assist")
    except Exception:
        ver = "0.2.1"

    header = Text()
    header.append(">_ tofu-assist", style="bold white")
    header.append(f" (v{ver})", style="dim")

    provider, region = detect_provider()
    if provider != "unknown":
        state.provider = provider
        state.region = region

    body = Text()
    body.append(f"model:     {MODEL}", style="dim")
    if state.provider != "unknown":
        body.append("   /model to change", style="dim italic")
    body.append("\n")
    cwd = os.getcwd()
    home = os.path.expanduser("~")
    if cwd.startswith(home):
        cwd = "~" + cwd[len(home):]
    body.append(f"provider:  {state.provider} ({state.region})", style="dim")
    body.append("\n")
    body.append(f"directory: {cwd}", style="dim")

    panel = Panel(body, title=header, border_style="cyan", title_align="left")
    console.print(panel)

    tip = Text("\n  Tip: type 'help' for commands, 'exit' to quit.\n", style="dim italic")
    console.print(tip)

    # ── REPL loop ────────────────────────────────────────────────────
    while state.running:
        try:
            user_input = console.input("› ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break

        if not user_input:
            continue

        action = intent_router(user_input)

        if action == "exit":
            state.running = False
            break
        elif action == "help":
            handle_help()
        elif action == "generate":
            handle_generate(state, user_input)
        elif action == "edit":
            handle_edit(state, user_input)
        elif action == "plan":
            handle_plan(state)
        elif action == "cost":
            handle_cost(state)
        elif action == "security":
            handle_security(state)
        elif action == "explain":
            handle_explain(state)
        elif action == "apply":
            handle_apply(state)

        print()

    exit_msg = "Session ended."
    if state.tf_dir:
        exit_msg += f" Files saved to: {state.tf_dir}"
    console.print(Text(exit_msg, style="dim"))
