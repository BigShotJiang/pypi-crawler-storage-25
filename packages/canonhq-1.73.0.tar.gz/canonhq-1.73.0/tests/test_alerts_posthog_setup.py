"""Tests for PostHog alert setup and SRE dashboard configuration."""

from __future__ import annotations

import sys
from unittest.mock import MagicMock, patch

import pytest


class TestAlertDefinitions:
    """Verify the ALERT_DEFINITIONS constant has expected structure."""

    def test_alert_definitions_not_empty(self):
        from canon.alerts.posthog_setup import ALERT_DEFINITIONS

        assert len(ALERT_DEFINITIONS) > 0

    def test_alert_definitions_have_required_keys(self):
        from canon.alerts.posthog_setup import ALERT_DEFINITIONS

        required_keys = {"name", "description", "severity", "event", "threshold", "window_minutes"}
        for alert in ALERT_DEFINITIONS:
            missing = required_keys - set(alert.keys())
            assert not missing, f"Alert {alert.get('name', '?')} missing keys: {missing}"

    def test_alert_severities_are_valid(self):
        from canon.alerts.posthog_setup import ALERT_DEFINITIONS

        valid = {"low", "medium", "high", "critical"}
        for alert in ALERT_DEFINITIONS:
            assert alert["severity"] in valid, (
                f"Alert {alert['name']} has invalid severity: {alert['severity']}"
            )

    def test_alert_thresholds_are_positive(self):
        from canon.alerts.posthog_setup import ALERT_DEFINITIONS

        for alert in ALERT_DEFINITIONS:
            assert alert["threshold"] > 0
            assert alert["window_minutes"] > 0


class TestDashboardPanels:
    """Verify the DASHBOARD_PANELS constant has expected structure."""

    def test_dashboard_panels_not_empty(self):
        from canon.alerts.posthog_setup import DASHBOARD_PANELS

        assert len(DASHBOARD_PANELS) > 0

    def test_dashboard_panels_have_required_keys(self):
        from canon.alerts.posthog_setup import DASHBOARD_PANELS

        required_keys = {"name", "event", "viz"}
        for panel in DASHBOARD_PANELS:
            missing = required_keys - set(panel.keys())
            assert not missing, f"Panel {panel.get('name', '?')} missing keys: {missing}"

    def test_dashboard_panel_names_are_unique(self):
        from canon.alerts.posthog_setup import DASHBOARD_PANELS

        names = [p["name"] for p in DASHBOARD_PANELS]
        assert len(names) == len(set(names)), "Dashboard panel names must be unique"


class TestHeaders:
    def test_headers_include_authorization(self):
        with patch("canon.alerts.posthog_setup.POSTHOG_KEY", "phx_test_key_123"):
            from canon.alerts.posthog_setup import _headers

            h = _headers()
            assert h["Authorization"] == "Bearer phx_test_key_123"
            assert h["Content-Type"] == "application/json"


class TestPrintAlertConfig:
    def test_prints_all_alerts(self, capsys):
        from canon.alerts.posthog_setup import ALERT_DEFINITIONS, print_alert_config

        print_alert_config()
        captured = capsys.readouterr()
        assert "PostHog Alert Configuration" in captured.out
        for alert in ALERT_DEFINITIONS:
            assert alert["name"] in captured.out
            assert alert["description"] in captured.out


class TestSetupDashboard:
    def test_exits_when_key_missing(self):
        """setup_dashboard should sys.exit(1) when POSTHOG_KEY is empty."""
        with (
            patch("canon.alerts.posthog_setup.POSTHOG_KEY", ""),
            patch("canon.alerts.posthog_setup.POSTHOG_PROJECT_ID", ""),
            pytest.raises(SystemExit, match="1"),
        ):
            from canon.alerts.posthog_setup import setup_dashboard

            setup_dashboard()

    def test_exits_when_project_id_missing(self):
        """setup_dashboard should sys.exit(1) when POSTHOG_PROJECT_ID is empty."""
        with (
            patch("canon.alerts.posthog_setup.POSTHOG_KEY", "phx_test"),
            patch("canon.alerts.posthog_setup.POSTHOG_PROJECT_ID", ""),
            pytest.raises(SystemExit, match="1"),
        ):
            from canon.alerts.posthog_setup import setup_dashboard

            setup_dashboard()

    def test_creates_new_dashboard_and_panels(self):
        """When no existing dashboard, creates one and adds all panels."""
        mock_client = MagicMock()

        # List dashboards - empty
        list_resp = MagicMock()
        list_resp.json.return_value = {"results": []}
        list_resp.raise_for_status = MagicMock()

        # Create dashboard
        create_resp = MagicMock()
        create_resp.json.return_value = {"id": 99, "name": "Canon SRE Dashboard"}
        create_resp.raise_for_status = MagicMock()

        # Get dashboard details (no existing tiles)
        dash_detail_resp = MagicMock()
        dash_detail_resp.json.return_value = {"tiles": []}
        dash_detail_resp.raise_for_status = MagicMock()

        # Insight creation responses
        insight_resp = MagicMock()
        insight_resp.json.return_value = {"id": 1}
        insight_resp.raise_for_status = MagicMock()

        mock_client.get.side_effect = [list_resp, dash_detail_resp]
        mock_client.post.side_effect = [create_resp] + [insight_resp] * 20
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with (
            patch("canon.alerts.posthog_setup.POSTHOG_KEY", "phx_test"),
            patch("canon.alerts.posthog_setup.POSTHOG_PROJECT_ID", "12345"),
            patch("canon.alerts.posthog_setup.httpx.Client", return_value=mock_client),
        ):
            from canon.alerts.posthog_setup import DASHBOARD_PANELS, setup_dashboard

            setup_dashboard()

        # Should have created the dashboard + one insight per panel
        assert mock_client.post.call_count == 1 + len(DASHBOARD_PANELS)

    def test_updates_existing_dashboard(self):
        """When dashboard exists, skips creation and only adds missing panels."""
        mock_client = MagicMock()

        # List dashboards - one exists
        list_resp = MagicMock()
        list_resp.json.return_value = {"results": [{"id": 50, "name": "Canon SRE Dashboard"}]}
        list_resp.raise_for_status = MagicMock()

        # Get dashboard details - has one existing panel
        dash_detail_resp = MagicMock()
        dash_detail_resp.json.return_value = {"tiles": [{"insight": {"name": "Error rate"}}]}
        dash_detail_resp.raise_for_status = MagicMock()

        insight_resp = MagicMock()
        insight_resp.json.return_value = {"id": 2}
        insight_resp.raise_for_status = MagicMock()

        mock_client.get.side_effect = [list_resp, dash_detail_resp]
        # Only insights for panels that don't exist yet (no dashboard create call)
        mock_client.post.side_effect = [insight_resp] * 20
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with (
            patch("canon.alerts.posthog_setup.POSTHOG_KEY", "phx_test"),
            patch("canon.alerts.posthog_setup.POSTHOG_PROJECT_ID", "12345"),
            patch("canon.alerts.posthog_setup.httpx.Client", return_value=mock_client),
        ):
            from canon.alerts.posthog_setup import DASHBOARD_PANELS, setup_dashboard

            setup_dashboard()

        # No dashboard create, and "Error rate" was skipped
        expected_panels = len(DASHBOARD_PANELS) - 1  # minus "Error rate"
        assert mock_client.post.call_count == expected_panels


class TestMain:
    def test_main_with_dashboard_flag(self):
        with (
            patch("canon.alerts.posthog_setup.setup_dashboard") as mock_setup,
            patch.object(sys, "argv", ["posthog_setup", "--dashboard"]),
        ):
            from canon.alerts.posthog_setup import main

            main()
            mock_setup.assert_called_once()

    def test_main_with_alerts_flag(self):
        with (
            patch("canon.alerts.posthog_setup.print_alert_config") as mock_print,
            patch.object(sys, "argv", ["posthog_setup", "--alerts"]),
        ):
            from canon.alerts.posthog_setup import main

            main()
            mock_print.assert_called_once()

    def test_main_with_no_flag_exits(self):
        with (
            patch.object(sys, "argv", ["posthog_setup"]),
            pytest.raises(SystemExit, match="1"),
        ):
            from canon.alerts.posthog_setup import main

            main()

    def test_main_prints_usage_on_no_flag(self, capsys):
        with (
            patch.object(sys, "argv", ["posthog_setup"]),
            pytest.raises(SystemExit),
        ):
            from canon.alerts.posthog_setup import main

            main()
        captured = capsys.readouterr()
        assert "--dashboard" in captured.out
        assert "--alerts" in captured.out
