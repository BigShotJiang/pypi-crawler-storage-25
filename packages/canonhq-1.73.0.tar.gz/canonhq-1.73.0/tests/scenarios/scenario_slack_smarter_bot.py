"""Scenario: a small org adopts the smarter-bot feature.

This scenario documents the intended end-to-end adoption lifecycle for
the smarter-bot feature (sub-project A from slack-app-enhancements).
Most assertions are lightweight here because:
- 4 of 6 source loaders are stubs in v1 (defer to follow-up PR)
- Full E2E with FastAPI + Postgres stack lives in the integration
  test suite (see tests/test_slack_smarter_bot_integration.py)

Future expansion (when GitHubClient + adapter APIs are extended):
- Day 1: User links GitHub identity via /canon link → slack_identity_linked event
- Day 2: User mentions @canon with discussion intent → coordinator runs all 6 sources
- Day 3: User DMs "what should I work on" → personal context loads owned specs
- Day 4: A source fails → answer still posts, telemetry shows degraded
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def main():
    logger.info(
        "smarter-bot scenario: deferred until source loaders are activated. "
        "See tests/test_slack_smarter_bot_integration.py for current coverage."
    )


if __name__ == "__main__":
    main()
