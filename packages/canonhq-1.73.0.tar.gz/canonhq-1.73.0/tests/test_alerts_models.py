"""Tests for SRE alert data models."""

from __future__ import annotations

from canon.alerts.models import AlertMessage, AlertSeverity


class TestAlertSeverity:
    def test_severity_ordering(self):
        assert AlertSeverity.CRITICAL.value > AlertSeverity.HIGH.value
        assert AlertSeverity.HIGH.value > AlertSeverity.MEDIUM.value
        assert AlertSeverity.MEDIUM.value > AlertSeverity.LOW.value

    def test_severity_emoji(self):
        assert AlertSeverity.CRITICAL.emoji == "\U0001f534"
        assert AlertSeverity.HIGH.emoji == "\U0001f7e0"
        assert AlertSeverity.MEDIUM.emoji == "\U0001f7e1"
        assert AlertSeverity.LOW.emoji == "\U0001f535"

    def test_severity_color(self):
        assert AlertSeverity.CRITICAL.color == "#e74c3c"
        assert AlertSeverity.HIGH.color == "#e67e22"
        assert AlertSeverity.MEDIUM.color == "#f1c40f"
        assert AlertSeverity.LOW.color == "#3498db"


class TestAlertMessage:
    def test_create_alert_message(self):
        msg = AlertMessage(
            severity=AlertSeverity.HIGH,
            title="Exception spike",
            summary="15 exceptions in 5 minutes",
            endpoint="/webhook",
            posthog_url="https://us.posthog.com/project/1/error/abc",
        )
        assert msg.severity == AlertSeverity.HIGH
        assert msg.title == "Exception spike"
        assert msg.endpoint == "/webhook"

    def test_alert_message_optional_fields(self):
        msg = AlertMessage(
            severity=AlertSeverity.MEDIUM,
            title="New error",
            summary="KeyError in handler",
        )
        assert msg.endpoint is None
        assert msg.posthog_url is None
        assert msg.spec_link is None

    def test_to_slack_block(self):
        msg = AlertMessage(
            severity=AlertSeverity.HIGH,
            title="Exception spike",
            summary="15 exceptions in 5 minutes",
            endpoint="/webhook",
            posthog_url="https://us.posthog.com/project/1/error/abc",
        )
        blocks = msg.to_slack_blocks()
        assert isinstance(blocks, list)
        assert len(blocks) >= 1
        header_text = blocks[0]["text"]["text"]
        assert "Exception spike" in header_text

    def test_to_slack_blocks_includes_endpoint_and_time_window(self):
        msg = AlertMessage(
            severity=AlertSeverity.MEDIUM,
            title="Webhook slow",
            summary="p95 > 30s",
            endpoint="/api/webhook",
            time_window="15 minutes",
        )
        blocks = msg.to_slack_blocks()
        detail_text = blocks[1]["text"]["text"]
        assert "`/api/webhook`" in detail_text
        assert "15 minutes" in detail_text

    def test_to_slack_blocks_includes_context_links(self):
        msg = AlertMessage(
            severity=AlertSeverity.HIGH,
            title="Error spike",
            summary="Many errors",
            posthog_url="https://posthog.com/error/1",
            spec_link="https://github.com/org/repo/blob/main/docs/specs/sre.md",
        )
        blocks = msg.to_slack_blocks()
        # Should have header, detail, and context blocks
        assert len(blocks) == 3
        context_block = blocks[2]
        assert context_block["type"] == "context"
        context_text = context_block["elements"][0]["text"]
        assert "View in PostHog" in context_text
        assert "Related Spec" in context_text

    def test_to_slack_blocks_no_context_when_no_links(self):
        msg = AlertMessage(
            severity=AlertSeverity.LOW,
            title="Info",
            summary="Just info",
        )
        blocks = msg.to_slack_blocks()
        # Only header and detail blocks, no context
        assert len(blocks) == 2
        assert blocks[0]["type"] == "section"
        assert blocks[1]["type"] == "section"

    def test_to_slack_blocks_with_only_spec_link(self):
        msg = AlertMessage(
            severity=AlertSeverity.LOW,
            title="Info",
            summary="Info",
            spec_link="https://github.com/org/repo/specs/x.md",
        )
        blocks = msg.to_slack_blocks()
        assert len(blocks) == 3
        context_text = blocks[2]["elements"][0]["text"]
        assert "Related Spec" in context_text
        assert "View in PostHog" not in context_text
