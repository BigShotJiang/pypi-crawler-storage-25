"""Tests for Slack webhook delivery."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from canon.alerts.models import AlertMessage, AlertSeverity
from canon.alerts.slack import SlackAlerter


class TestSlackAlerter:
    def test_init_disabled_without_url(self):
        alerter = SlackAlerter(webhook_url="")
        assert alerter.enabled is False

    def test_init_enabled_with_url(self):
        alerter = SlackAlerter(webhook_url="https://hooks.slack.com/services/T/B/x")
        assert alerter.enabled is True

    @pytest.mark.asyncio
    async def test_send_does_nothing_when_disabled(self):
        alerter = SlackAlerter(webhook_url="")
        msg = AlertMessage(severity=AlertSeverity.HIGH, title="Test", summary="Test")
        await alerter.send(msg)

    @pytest.mark.asyncio
    async def test_send_posts_to_webhook(self):
        alerter = SlackAlerter(webhook_url="https://hooks.slack.com/services/T/B/x")
        msg = AlertMessage(severity=AlertSeverity.HIGH, title="Test", summary="Test alert")

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()

        alerter._http = AsyncMock()
        alerter._http.post.return_value = mock_response

        await alerter.send(msg)

        alerter._http.post.assert_called_once()
        call_args = alerter._http.post.call_args
        assert call_args[0][0] == "https://hooks.slack.com/services/T/B/x"
        payload = call_args[1]["json"]
        assert "blocks" in payload

    @pytest.mark.asyncio
    async def test_send_logs_on_failure(self):
        alerter = SlackAlerter(webhook_url="https://hooks.slack.com/services/T/B/x")
        msg = AlertMessage(severity=AlertSeverity.HIGH, title="Test", summary="Test")

        alerter._http = AsyncMock()
        alerter._http.post.side_effect = Exception("Connection refused")

        await alerter.send(msg)

    @pytest.mark.asyncio
    async def test_send_text_posts_simple_message(self):
        alerter = SlackAlerter(webhook_url="https://hooks.slack.com/services/T/B/x")

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()

        alerter._http = AsyncMock()
        alerter._http.post.return_value = mock_response

        await alerter.send_text("Hello from Canon SRE")

        alerter._http.post.assert_called_once()
        payload = alerter._http.post.call_args[1]["json"]
        assert payload["text"] == "Hello from Canon SRE"

    @pytest.mark.asyncio
    async def test_send_text_raises_on_failure(self):
        alerter = SlackAlerter(webhook_url="https://hooks.slack.com/services/T/B/x")

        alerter._http = AsyncMock()
        alerter._http.post.side_effect = Exception("Connection refused")

        with pytest.raises(Exception, match="Connection refused"):
            await alerter.send_text("Hello")

    @pytest.mark.asyncio
    async def test_send_text_noop_when_disabled(self):
        alerter = SlackAlerter(webhook_url="")
        # Should not raise or do anything
        await alerter.send_text("Hello")

    @pytest.mark.asyncio
    async def test_close_closes_http_client(self):
        alerter = SlackAlerter(webhook_url="https://hooks.slack.com/services/T/B/x")
        mock_http = AsyncMock()
        alerter._http = mock_http

        await alerter.close()

        mock_http.aclose.assert_called_once()
        assert alerter._http is None

    @pytest.mark.asyncio
    async def test_close_noop_when_no_client(self):
        alerter = SlackAlerter(webhook_url="")
        assert alerter._http is None
        # Should not raise
        await alerter.close()

    @pytest.mark.asyncio
    async def test_post_noop_when_http_is_none(self):
        alerter = SlackAlerter(webhook_url="https://hooks.slack.com/services/T/B/x")
        alerter._http = None
        # _post should silently return when _http is None
        await alerter._post({"text": "test"})
