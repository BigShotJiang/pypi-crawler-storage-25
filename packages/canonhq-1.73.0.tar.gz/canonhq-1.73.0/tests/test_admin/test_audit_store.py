"""Tests for AuditStore data access layer."""

from __future__ import annotations

from contextlib import asynccontextmanager
from unittest.mock import AsyncMock, MagicMock

from canon.admin.audit import AuditStore


def _mock_pool_with_conn(mock_conn: AsyncMock) -> MagicMock:
    """Create a mock pool whose acquire() returns an async context manager."""
    mock_pool = MagicMock()

    @asynccontextmanager
    async def _acquire():
        yield mock_conn

    mock_pool.acquire = _acquire
    return mock_pool


class TestLog:
    async def test_log_calls_execute_with_insert(self):
        mock_conn = AsyncMock()
        mock_conn.execute = AsyncMock()
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        await store.log(
            actor_id=1,
            org="my-org",
            event_type="user.role_changed",
            resource_type="user",
            resource_id="42",
            detail={"old_role": "editor", "new_role": "admin"},
            ip_address="1.2.3.4",
        )

        mock_conn.execute.assert_awaited_once()
        sql, *_args = mock_conn.execute.call_args[0]
        assert "INSERT INTO audit_events" in sql

    async def test_log_passes_correct_values(self):
        mock_conn = AsyncMock()
        mock_conn.execute = AsyncMock()
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        detail = {"key": "value"}
        await store.log(
            actor_id=7,
            org="acme",
            event_type="org.deleted",
            resource_type="org",
            resource_id="acme",
            detail=detail,
            ip_address="10.0.0.1",
        )

        _, *args = mock_conn.execute.call_args[0]
        assert 7 in args
        assert "acme" in args
        assert "org.deleted" in args
        assert "org" in args
        assert "10.0.0.1" in args

    async def test_log_works_without_optional_fields(self):
        """log() must work with only the required fields."""
        mock_conn = AsyncMock()
        mock_conn.execute = AsyncMock()
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        # actor_id, org, detail, ip_address are all optional
        await store.log(
            event_type="platform.settings_changed",
            resource_type="settings",
            resource_id="global",
        )

        mock_conn.execute.assert_awaited_once()

    async def test_log_passes_detail_as_dict(self):
        # With the pool-wide JSONB codec, dicts go straight to asyncpg — no
        # manual json.dumps in the store. Pre-codec we used to double-encode.
        mock_conn = AsyncMock()
        mock_conn.execute = AsyncMock()
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        detail = {"nested": {"a": 1}}
        await store.log(
            event_type="x",
            resource_type="y",
            resource_id="z",
            detail=detail,
        )

        _, *args = mock_conn.execute.call_args[0]
        assert detail in args


class TestList:
    async def test_list_returns_events_as_dicts(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(
            return_value=[
                {
                    "id": "uuid-1",
                    "event_type": "user.created",
                    "resource_type": "user",
                    "resource_id": "1",
                    "org": "acme",
                    "actor_id": 1,
                    "detail": '{"foo": "bar"}',
                    "ip_address": "1.2.3.4",
                    "created_at": "2026-01-01T00:00:00Z",
                },
            ]
        )
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        results = await store.list()

        assert len(results) == 1
        assert results[0]["event_type"] == "user.created"

    async def test_list_no_filters_uses_base_query(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        await store.list()

        sql = mock_conn.fetch.call_args[0][0]
        assert "SELECT" in sql
        assert "FROM audit_events" in sql
        assert "ORDER BY created_at DESC" in sql

    async def test_list_applies_org_filter(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        await store.list(org="my-org")

        sql = mock_conn.fetch.call_args[0][0]
        args = mock_conn.fetch.call_args[0][1:]
        assert "org" in sql
        assert "my-org" in args

    async def test_list_applies_event_type_filter(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        await store.list(event_type="user.deleted")

        sql = mock_conn.fetch.call_args[0][0]
        args = mock_conn.fetch.call_args[0][1:]
        assert "event_type" in sql
        assert "user.deleted" in args

    async def test_list_applies_actor_id_filter(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        await store.list(actor_id=99)

        sql = mock_conn.fetch.call_args[0][0]
        args = mock_conn.fetch.call_args[0][1:]
        assert "actor_id" in sql
        assert 99 in args

    async def test_list_applies_resource_type_filter(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        await store.list(resource_type="org")

        sql = mock_conn.fetch.call_args[0][0]
        args = mock_conn.fetch.call_args[0][1:]
        assert "resource_type" in sql
        assert "org" in args

    async def test_list_applies_limit_and_offset(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        await store.list(limit=25, offset=50)

        sql = mock_conn.fetch.call_args[0][0]
        args = mock_conn.fetch.call_args[0][1:]
        assert "LIMIT" in sql
        assert "OFFSET" in sql
        assert 25 in args
        assert 50 in args

    async def test_list_multiple_filters(self):
        mock_conn = AsyncMock()
        mock_conn.fetch = AsyncMock(return_value=[])
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        await store.list(org="acme", event_type="user.created", actor_id=5)

        sql = mock_conn.fetch.call_args[0][0]
        args = mock_conn.fetch.call_args[0][1:]
        assert "org" in sql
        assert "event_type" in sql
        assert "actor_id" in sql
        assert "acme" in args
        assert "user.created" in args
        assert 5 in args


class TestDeleteOlderThan:
    async def test_returns_count_deleted(self):
        mock_conn = AsyncMock()
        mock_conn.execute = AsyncMock(return_value="DELETE 7")
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        count = await store.delete_older_than(days=90)

        assert count == 7

    async def test_returns_zero_when_nothing_deleted(self):
        mock_conn = AsyncMock()
        mock_conn.execute = AsyncMock(return_value="DELETE 0")
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        count = await store.delete_older_than(days=30)

        assert count == 0

    async def test_uses_days_in_query(self):
        mock_conn = AsyncMock()
        mock_conn.execute = AsyncMock(return_value="DELETE 0")
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        await store.delete_older_than(days=180)

        sql = mock_conn.execute.call_args[0][0]
        args = mock_conn.execute.call_args[0][1:]
        assert "DELETE FROM audit_events" in sql
        # days should be parameterised, not interpolated
        assert 180 in args

    async def test_delete_query_references_created_at(self):
        mock_conn = AsyncMock()
        mock_conn.execute = AsyncMock(return_value="DELETE 0")
        pool = _mock_pool_with_conn(mock_conn)
        store = AuditStore(pool)

        await store.delete_older_than(days=90)

        sql = mock_conn.execute.call_args[0][0]
        assert "created_at" in sql
