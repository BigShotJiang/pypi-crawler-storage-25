"""Tests for AdminStore billing, AI ops, integrations, and Auth0 enrichment methods."""

from __future__ import annotations

from contextlib import asynccontextmanager
from unittest.mock import AsyncMock, MagicMock

from canon.admin.store import AdminStore


def _mock_pool(conn: AsyncMock) -> MagicMock:
    pool = MagicMock()

    @asynccontextmanager
    async def _acquire():
        yield conn

    pool.acquire = _acquire
    return pool


# ------------------------------------------------------------------
# Billing
# ------------------------------------------------------------------


class TestListSubscriptions:
    async def test_returns_list_of_dicts(self):
        conn = AsyncMock()
        conn.fetch = AsyncMock(
            return_value=[
                {
                    "org_login": "acme",
                    "plan": "team",
                    "billing_cycle": "monthly",
                    "status": "active",
                    "seat_count": 5,
                    "stripe_customer_id": "cus_abc",
                    "current_period_start": None,
                    "current_period_end": None,
                    "created_at": None,
                }
            ]
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.list_subscriptions()

        assert len(result) == 1
        assert result[0]["org_login"] == "acme"
        assert result[0]["plan"] == "team"

    async def test_passes_limit_and_offset(self):
        conn = AsyncMock()
        conn.fetch = AsyncMock(return_value=[])
        store = AdminStore(_mock_pool(conn))

        await store.list_subscriptions(limit=10, offset=20)

        sql = conn.fetch.call_args[0][0]
        args = conn.fetch.call_args[0][1:]
        assert "LIMIT" in sql
        assert "OFFSET" in sql
        assert 10 in args
        assert 20 in args

    async def test_orders_by_created_at(self):
        conn = AsyncMock()
        conn.fetch = AsyncMock(return_value=[])
        store = AdminStore(_mock_pool(conn))

        await store.list_subscriptions()

        sql = conn.fetch.call_args[0][0]
        assert "ORDER BY created_at DESC" in sql

    async def test_returns_empty_list_when_no_data(self):
        conn = AsyncMock()
        conn.fetch = AsyncMock(return_value=[])
        store = AdminStore(_mock_pool(conn))

        result = await store.list_subscriptions()

        assert result == []


class TestGetOrgBilling:
    async def test_returns_subscription_with_usage(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            side_effect=[
                {
                    "org_login": "acme",
                    "plan": "team",
                    "status": "active",
                    "seat_count": 5,
                },
                {
                    "ops_used": 150,
                    "ops_included": 1000,
                },
            ]
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.get_org_billing("acme")

        assert result is not None
        assert result["plan"] == "team"
        assert result["ai_ops_used"] == 150
        assert result["ai_ops_included"] == 1000

    async def test_returns_none_when_no_subscription(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(side_effect=[None, None])
        store = AdminStore(_mock_pool(conn))

        result = await store.get_org_billing("ghost")

        assert result is None

    async def test_returns_subscription_without_usage(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            side_effect=[
                {
                    "org_login": "acme",
                    "plan": "free",
                    "status": "active",
                    "seat_count": 1,
                },
                None,  # no usage row
            ]
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.get_org_billing("acme")

        assert result is not None
        assert result["plan"] == "free"
        assert "ai_ops_used" not in result


# ------------------------------------------------------------------
# AI Operations
# ------------------------------------------------------------------


class TestGetAiOpsSummary:
    async def test_returns_aggregate_metrics(self):
        conn = AsyncMock()
        conn.fetchval = AsyncMock(side_effect=[42, 1200])
        conn.fetch = AsyncMock(
            return_value=[
                {"org_login": "acme", "ops_count": 800},
                {"org_login": "beta", "ops_count": 400},
            ]
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.get_ai_ops_summary()

        assert result["ops_today"] == 42
        assert result["ops_this_month"] == 1200
        assert len(result["orgs"]) == 2
        assert result["orgs"][0]["org_login"] == "acme"

    async def test_returns_zeros_when_no_data(self):
        conn = AsyncMock()
        conn.fetchval = AsyncMock(return_value=0)
        conn.fetch = AsyncMock(return_value=[])
        store = AdminStore(_mock_pool(conn))

        result = await store.get_ai_ops_summary()

        assert result["ops_today"] == 0
        assert result["ops_this_month"] == 0
        assert result["orgs"] == []

    async def test_handles_none_fetchval(self):
        conn = AsyncMock()
        conn.fetchval = AsyncMock(return_value=None)
        conn.fetch = AsyncMock(return_value=[])
        store = AdminStore(_mock_pool(conn))

        result = await store.get_ai_ops_summary()

        assert result["ops_today"] == 0
        assert result["ops_this_month"] == 0


class TestGetOrgAiUsage:
    async def test_returns_org_usage(self):
        conn = AsyncMock()
        conn.fetchval = AsyncMock(side_effect=[10, 300])
        conn.fetchrow = AsyncMock(return_value={"ops_included": 1000, "ops_used": 300})
        store = AdminStore(_mock_pool(conn))

        result = await store.get_org_ai_usage("acme")

        assert result["org"] == "acme"
        assert result["ops_today"] == 10
        assert result["ops_this_month"] == 300
        assert result["ops_included"] == 1000

    async def test_returns_without_summary_row(self):
        conn = AsyncMock()
        conn.fetchval = AsyncMock(return_value=0)
        conn.fetchrow = AsyncMock(return_value=None)
        store = AdminStore(_mock_pool(conn))

        result = await store.get_org_ai_usage("acme")

        assert result["org"] == "acme"
        assert result["ops_today"] == 0
        assert "ops_included" not in result

    async def test_handles_none_fetchval(self):
        conn = AsyncMock()
        conn.fetchval = AsyncMock(return_value=None)
        conn.fetchrow = AsyncMock(return_value=None)
        store = AdminStore(_mock_pool(conn))

        result = await store.get_org_ai_usage("acme")

        assert result["ops_today"] == 0
        assert result["ops_this_month"] == 0


# ------------------------------------------------------------------
# Integrations
# ------------------------------------------------------------------


class TestListIntegrations:
    async def test_returns_list_of_dicts(self):
        conn = AsyncMock()
        conn.fetch = AsyncMock(
            return_value=[
                {
                    "org_login": "acme",
                    "provider": "jira",
                    "display_name": "Jira Cloud",
                    "status": "active",
                    "connected_by": "auth0|admin",
                    "connected_at": None,
                }
            ]
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.list_integrations()

        assert len(result) == 1
        assert result[0]["provider"] == "jira"

    async def test_applies_provider_filter(self):
        conn = AsyncMock()
        conn.fetch = AsyncMock(return_value=[])
        store = AdminStore(_mock_pool(conn))

        await store.list_integrations(provider="linear")

        sql = conn.fetch.call_args[0][0]
        args = conn.fetch.call_args[0][1:]
        assert "provider" in sql
        assert "linear" in args

    async def test_no_provider_filter_no_where(self):
        conn = AsyncMock()
        conn.fetch = AsyncMock(return_value=[])
        store = AdminStore(_mock_pool(conn))

        await store.list_integrations()

        sql = conn.fetch.call_args[0][0]
        assert "WHERE" not in sql

    async def test_passes_limit_and_offset(self):
        conn = AsyncMock()
        conn.fetch = AsyncMock(return_value=[])
        store = AdminStore(_mock_pool(conn))

        await store.list_integrations(limit=25, offset=50)

        args = conn.fetch.call_args[0][1:]
        assert 25 in args
        assert 50 in args

    async def test_orders_by_connected_at(self):
        conn = AsyncMock()
        conn.fetch = AsyncMock(return_value=[])
        store = AdminStore(_mock_pool(conn))

        await store.list_integrations()

        sql = conn.fetch.call_args[0][0]
        assert "ORDER BY connected_at" in sql


# ------------------------------------------------------------------
# Auth0 enrichment in get_org
# ------------------------------------------------------------------


class TestGetOrgAuth0Enrichment:
    async def test_enriches_with_members_from_auth0(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "login": "acme",
                "installation_id": "1",
                "created_at": None,
                "status": "active",
                "repos_count": 5,
                "oidc_org_id": "org_abc",
                "primary_contact_email": None,
                "primary_contact_name": None,
                "support_notes": None,
            }
        )
        pool = _mock_pool(conn)

        provider = AsyncMock()
        provider.get_org_members = AsyncMock(
            return_value=[{"user_id": "auth0|1"}, {"user_id": "auth0|2"}]
        )
        provider.list_organizations = AsyncMock(
            return_value=[{"name": "acme", "id": "org_abc", "display_name": "Acme Corp"}]
        )
        cache = MagicMock()
        cache.get = MagicMock(return_value=None)

        store = AdminStore(pool, provider=provider, cache=cache)
        result = await store.get_org("acme")

        assert result is not None
        assert result["members"] == [{"user_id": "auth0|1"}, {"user_id": "auth0|2"}]
        assert result["display_name"] == "Acme Corp"

    async def test_returns_empty_members_when_no_oidc_org_id(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "login": "acme",
                "installation_id": "1",
                "created_at": None,
                "status": "active",
                "repos_count": 5,
                "oidc_org_id": "",
                "primary_contact_email": None,
                "primary_contact_name": None,
                "support_notes": None,
            }
        )
        pool = _mock_pool(conn)

        provider = AsyncMock()
        provider.list_organizations = AsyncMock(return_value=[])
        cache = MagicMock()
        cache.get = MagicMock(return_value=None)

        store = AdminStore(pool, provider=provider, cache=cache)
        result = await store.get_org("acme")

        assert result is not None
        assert result["members"] == []
        # Should not call get_org_members when there's no oidc_org_id
        provider.get_org_members.assert_not_called()

    async def test_get_org_members_failure_logged_and_skipped(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "login": "acme",
                "installation_id": "1",
                "created_at": None,
                "status": "active",
                "repos_count": 5,
                "oidc_org_id": "org_abc",
                "primary_contact_email": None,
                "primary_contact_name": None,
                "support_notes": None,
            }
        )
        pool = _mock_pool(conn)

        provider = AsyncMock()
        provider.get_org_members = AsyncMock(side_effect=RuntimeError("rate limited"))
        provider.list_organizations = AsyncMock(
            return_value=[{"name": "acme", "id": "org_abc", "display_name": "Acme"}]
        )
        cache = MagicMock()
        cache.get = MagicMock(return_value=None)

        store = AdminStore(pool, provider=provider, cache=cache)
        result = await store.get_org("acme")

        # Should not raise; members defaults to empty from cache miss
        assert result is not None

    async def test_get_org_uses_cache_for_members(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "login": "acme",
                "installation_id": "1",
                "created_at": None,
                "status": "active",
                "repos_count": 5,
                "oidc_org_id": "org_abc",
                "primary_contact_email": None,
                "primary_contact_name": None,
                "support_notes": None,
            }
        )
        pool = _mock_pool(conn)

        cached_members = [{"user_id": "auth0|cached"}]
        provider = AsyncMock()
        provider.list_organizations = AsyncMock(return_value=[])
        cache = MagicMock()
        cache.get = MagicMock(side_effect=lambda k: cached_members if "org_members" in k else None)

        store = AdminStore(pool, provider=provider, cache=cache)
        result = await store.get_org("acme")

        assert result is not None
        assert result["members"] == cached_members
        provider.get_org_members.assert_not_called()


# ------------------------------------------------------------------
# Auth0 enrichment in get_user
# ------------------------------------------------------------------


class TestGetUserAuth0Enrichment:
    async def test_enriches_with_auth0_profile(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "name": "Alice",
                "email": "alice@example.com",
                "role": "editor",
                "created_at": None,
                "last_login_at": None,
            }
        )
        pool = _mock_pool(conn)

        provider = AsyncMock()
        provider.get_user = AsyncMock(
            return_value={
                "last_login": "2026-01-01T00:00:00Z",
                "logins_count": 42,
                "email_verified": True,
                "identities": [{"provider": "google-oauth2"}],
                "picture": "https://example.com/avatar.png",
                "app_metadata": {"tier": "pro"},
            }
        )
        cache = MagicMock()
        cache.get = MagicMock(return_value=None)

        store = AdminStore(pool, provider=provider, cache=cache)
        result = await store.get_user(1)

        assert result is not None
        assert result["last_login"] == "2026-01-01T00:00:00Z"
        assert result["login_count"] == 42
        assert result["email_verified"] is True
        assert result["app_metadata"]["tier"] == "pro"

    async def test_skips_enrichment_when_no_oidc_sub(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "",
                "name": "Bob",
                "email": "bob@example.com",
                "role": "viewer",
                "created_at": None,
                "last_login_at": None,
            }
        )
        pool = _mock_pool(conn)

        provider = AsyncMock()
        cache = MagicMock()
        cache.get = MagicMock(return_value=None)

        store = AdminStore(pool, provider=provider, cache=cache)
        result = await store.get_user(1)

        assert result is not None
        provider.get_user.assert_not_called()

    async def test_uses_cache_for_auth0_user(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "name": "Alice",
                "email": "alice@example.com",
                "role": "editor",
                "created_at": None,
                "last_login_at": None,
            }
        )
        pool = _mock_pool(conn)

        cached_user = {
            "last_login": "2026-01-01",
            "logins_count": 10,
            "email_verified": True,
        }
        provider = AsyncMock()
        cache = MagicMock()
        cache.get = MagicMock(side_effect=lambda k: cached_user if "auth0:users:" in k else None)

        store = AdminStore(pool, provider=provider, cache=cache)
        result = await store.get_user(1)

        assert result is not None
        assert result["login_count"] == 10
        provider.get_user.assert_not_called()

    async def test_auth0_failure_gracefully_skipped(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "name": "Alice",
                "email": "alice@example.com",
                "role": "editor",
                "created_at": None,
                "last_login_at": None,
            }
        )
        pool = _mock_pool(conn)

        provider = AsyncMock()
        provider.get_user = AsyncMock(side_effect=RuntimeError("auth0 down"))
        cache = MagicMock()
        cache.get = MagicMock(return_value=None)

        store = AdminStore(pool, provider=provider, cache=cache)
        result = await store.get_user(1)

        # Should not raise; enrichment fields are just missing
        assert result is not None
        assert "last_login" not in result


# ------------------------------------------------------------------
# Auth0 enrichment in list_users
# ------------------------------------------------------------------


class TestListUsersAuth0Enrichment:
    async def test_enriches_users_with_auth0_data(self):
        conn = AsyncMock()
        conn.fetch = AsyncMock(
            return_value=[
                {
                    "id": 1,
                    "oidc_sub": "auth0|abc",
                    "name": "Alice",
                    "email": "alice@example.com",
                    "role": "editor",
                    "created_at": None,
                    "last_login_at": None,
                }
            ]
        )
        pool = _mock_pool(conn)

        provider = AsyncMock()
        provider.get_user = AsyncMock(
            return_value={
                "last_login": "2026-01-01",
                "logins_count": 5,
                "email_verified": True,
                "picture": "https://example.com/pic.png",
                "identities": [],
            }
        )
        cache = MagicMock()
        cache.get = MagicMock(return_value=None)

        store = AdminStore(pool, provider=provider, cache=cache)
        result = await store.list_users()

        assert len(result) == 1
        assert result[0]["last_login"] == "2026-01-01"
        assert result[0]["login_count"] == 5

    async def test_skips_enrichment_for_users_without_sub(self):
        conn = AsyncMock()
        conn.fetch = AsyncMock(
            return_value=[
                {
                    "id": 1,
                    "oidc_sub": "",
                    "name": "NoSub",
                    "email": "nosub@example.com",
                    "role": "viewer",
                    "created_at": None,
                    "last_login_at": None,
                }
            ]
        )
        pool = _mock_pool(conn)

        provider = AsyncMock()
        cache = MagicMock()

        store = AdminStore(pool, provider=provider, cache=cache)
        result = await store.list_users()

        assert len(result) == 1
        provider.get_user.assert_not_called()

    async def test_login_falls_back_to_email(self):
        """When name is None/empty, login should fall back to email."""
        conn = AsyncMock()
        conn.fetch = AsyncMock(
            return_value=[
                {
                    "id": 1,
                    "oidc_sub": "auth0|abc",
                    "name": "",
                    "email": "alice@example.com",
                    "role": "editor",
                    "created_at": None,
                    "last_login_at": None,
                }
            ]
        )
        store = AdminStore(_mock_pool(conn))

        result = await store.list_users()

        assert result[0]["login"] == "alice@example.com"
