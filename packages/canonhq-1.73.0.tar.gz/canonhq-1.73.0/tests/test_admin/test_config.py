import pytest

from canon.admin.config import AdminConfig, AdminFeatures, get_admin_config
from canon.settings import Settings


class TestDeploymentMode:
    def test_default_is_development(self):
        s = Settings(deployment_mode="development")
        assert s.deployment_mode == "development"

    def test_cloud_mode(self):
        s = Settings(deployment_mode="cloud")
        assert s.deployment_mode == "cloud"

    def test_self_hosted_mode(self):
        s = Settings(deployment_mode="self_hosted")
        assert s.deployment_mode == "self_hosted"

    def test_invalid_mode_raises(self):
        with pytest.raises(ValueError):
            Settings(deployment_mode="invalid")

    def test_audit_retention_default(self):
        s = Settings()
        assert s.admin_audit_retention_days == 90


class TestGetAdminConfig:
    def test_cloud_mode_enables_all_features(self):
        settings = Settings(deployment_mode="cloud")
        config = get_admin_config(settings)

        assert config.mode == "cloud"
        assert config.features.billing is True
        assert config.features.cross_org is True
        assert config.features.impersonation is True

    def test_self_hosted_mode_disables_cloud_features(self):
        settings = Settings(deployment_mode="self_hosted")
        config = get_admin_config(settings)

        assert config.mode == "self_hosted"
        assert config.features.billing is False
        assert config.features.cross_org is False
        assert config.features.impersonation is False

    def test_development_mode_disables_cloud_features(self):
        settings = Settings(deployment_mode="development")
        config = get_admin_config(settings)

        assert config.mode == "development"
        assert config.features.billing is False
        assert config.features.cross_org is False
        assert config.features.impersonation is False

    def test_returns_admin_config_instance(self):
        settings = Settings(deployment_mode="cloud")
        config = get_admin_config(settings)

        assert isinstance(config, AdminConfig)
        assert isinstance(config.features, AdminFeatures)

    def test_config_is_serialisable(self):
        settings = Settings(deployment_mode="cloud")
        config = get_admin_config(settings)
        dumped = config.model_dump()

        assert dumped["mode"] == "cloud"
        assert dumped["features"]["billing"] is True
