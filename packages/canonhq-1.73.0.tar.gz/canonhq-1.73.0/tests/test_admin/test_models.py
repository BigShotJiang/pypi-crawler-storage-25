"""Tests for admin Pydantic response/request models."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest
from pydantic import ValidationError

from canon.admin.models import (
    AuditEventResponse,
    DashboardResponse,
    HealthSubsystem,
    IntegrationSummary,
    KPIStats,
    OrgMetadataUpdate,
    OrgSummary,
    RoleUpdate,
    SubscriptionSummary,
    UserDeleteConfirm,
    UserOrgMembership,
    UserOrgMembershipAdd,
    UserSummary,
)


class TestKPIStats:
    def test_defaults_to_zeros(self):
        kpi = KPIStats()
        assert kpi.org_count == 0
        assert kpi.user_count == 0
        assert kpi.spec_count == 0
        assert kpi.avg_coverage_pct == 0.0

    def test_accepts_values(self):
        kpi = KPIStats(org_count=10, user_count=50, spec_count=100, avg_coverage_pct=75.5)
        assert kpi.org_count == 10
        assert kpi.avg_coverage_pct == 75.5


class TestOrgSummary:
    def test_defaults(self):
        org = OrgSummary()
        assert org.login == ""
        assert org.installation_id is None
        assert org.user_count == 0
        assert org.status == "active"
        assert org.display_name == ""
        assert org.primary_contact_email is None

    def test_with_all_fields(self):
        now = datetime.now(tz=UTC)
        org = OrgSummary(
            login="acme",
            installation_id="42",
            user_count=5,
            created_at=now,
            status="suspended",
            display_name="Acme Corp",
            member_count=3,
            primary_contact_email="ops@acme.com",
            primary_contact_name="Ops Team",
            support_notes="VIP customer",
            oidc_org_id="org_xyz",
        )
        assert org.login == "acme"
        assert org.installation_id == "42"
        assert org.status == "suspended"
        assert org.member_count == 3
        assert org.oidc_org_id == "org_xyz"


class TestOrgMetadataUpdate:
    def test_all_fields_optional(self):
        update = OrgMetadataUpdate()
        assert update.display_name is None
        assert update.primary_contact_email is None
        assert update.primary_contact_name is None
        assert update.support_notes is None

    def test_partial_update(self):
        update = OrgMetadataUpdate(primary_contact_email="ops@acme.com")
        assert update.primary_contact_email == "ops@acme.com"
        assert update.display_name is None

    def test_model_dump_exclude_unset(self):
        update = OrgMetadataUpdate(support_notes="test")
        dumped = update.model_dump(exclude_unset=True)
        assert "support_notes" in dumped
        assert "display_name" not in dumped

    def test_empty_string_clears_field(self):
        update = OrgMetadataUpdate(primary_contact_email="")
        assert update.primary_contact_email == ""


class TestUserSummary:
    def test_defaults(self):
        user = UserSummary()
        assert user.id == 0
        assert user.login == ""
        assert user.role == ""
        assert user.status == "active"
        assert user.last_login is None
        assert user.login_count is None
        assert user.email_verified is None
        assert user.picture is None
        assert user.identities is None

    def test_with_auth0_enrichment_fields(self):
        user = UserSummary(
            id=1,
            login="alice",
            email="alice@example.com",
            role="editor",
            last_login="2026-01-01T00:00:00Z",
            login_count=42,
            email_verified=True,
            picture="https://example.com/avatar.png",
            identities=[{"provider": "google-oauth2"}],
        )
        assert user.login_count == 42
        assert user.email_verified is True
        assert len(user.identities) == 1


class TestRoleUpdate:
    def test_valid_roles(self):
        for role in ("viewer", "editor", "admin", "super_admin"):
            update = RoleUpdate(role=role)
            assert update.role == role

    def test_invalid_role_raises(self):
        with pytest.raises(ValidationError):
            RoleUpdate(role="owner")

    def test_empty_role_raises(self):
        with pytest.raises(ValidationError):
            RoleUpdate(role="")


class TestUserDeleteConfirm:
    def test_accepts_confirm_string(self):
        confirm = UserDeleteConfirm(confirm="user@example.com")
        assert confirm.confirm == "user@example.com"

    def test_empty_confirm_is_valid_pydantic_level(self):
        """Empty string is accepted by the model; the route enforces non-empty."""
        confirm = UserDeleteConfirm(confirm="")
        assert confirm.confirm == ""


class TestUserOrgMembershipAdd:
    def test_with_org_login(self):
        body = UserOrgMembershipAdd(org_login="acme")
        assert body.org_login == "acme"
        assert body.oidc_org_id is None

    def test_with_oidc_org_id(self):
        body = UserOrgMembershipAdd(oidc_org_id="org_xyz")
        assert body.oidc_org_id == "org_xyz"
        assert body.org_login is None

    def test_with_both_fields(self):
        body = UserOrgMembershipAdd(org_login="acme", oidc_org_id="org_xyz")
        assert body.org_login == "acme"
        assert body.oidc_org_id == "org_xyz"

    def test_empty_body_raises_validation_error(self):
        with pytest.raises(ValidationError, match="At least one"):
            UserOrgMembershipAdd()

    def test_both_none_raises_validation_error(self):
        with pytest.raises(ValidationError, match="At least one"):
            UserOrgMembershipAdd(org_login=None, oidc_org_id=None)

    def test_empty_strings_treated_as_falsy(self):
        """Empty strings should also trigger the validator."""
        with pytest.raises(ValidationError, match="At least one"):
            UserOrgMembershipAdd(org_login="", oidc_org_id="")


class TestUserOrgMembership:
    def test_required_and_optional_fields(self):
        membership = UserOrgMembership(
            oidc_org_id="org_xyz",
            name="acme",
            display_name="Acme Corp",
            org_login="acme",
        )
        assert membership.oidc_org_id == "org_xyz"
        assert membership.org_login == "acme"

    def test_defaults(self):
        membership = UserOrgMembership(oidc_org_id="org_xyz", name="acme")
        assert membership.display_name == ""
        assert membership.org_login is None


class TestHealthSubsystem:
    def test_required_fields(self):
        health = HealthSubsystem(name="database", healthy=True)
        assert health.name == "database"
        assert health.healthy is True
        assert health.detail == ""

    def test_with_detail(self):
        health = HealthSubsystem(name="indexing", healthy=False, detail="5 failures in 24h")
        assert not health.healthy
        assert "5 failures" in health.detail


class TestDashboardResponse:
    def test_defaults(self):
        dashboard = DashboardResponse()
        assert dashboard.kpis.org_count == 0
        assert dashboard.health == []
        assert dashboard.recent_events == []

    def test_with_populated_fields(self):
        dashboard = DashboardResponse(
            kpis=KPIStats(org_count=5),
            health=[HealthSubsystem(name="db", healthy=True)],
            recent_events=[AuditEventResponse(event_type="user.created")],
        )
        assert dashboard.kpis.org_count == 5
        assert len(dashboard.health) == 1
        assert len(dashboard.recent_events) == 1


class TestAuditEventResponse:
    def test_defaults(self):
        event = AuditEventResponse()
        assert event.id == ""
        assert event.event_type == ""
        assert event.actor_id is None
        assert event.detail is None
        assert event.created_at is None

    def test_with_all_fields(self):
        now = datetime.now(tz=UTC)
        event = AuditEventResponse(
            id="uuid-1",
            event_type="user.deleted",
            resource_type="user",
            resource_id="42",
            actor_id=7,
            org="acme",
            detail={"reason": "gdpr"},
            ip_address="10.0.0.1",
            created_at=now,
        )
        assert event.actor_id == 7
        assert event.detail["reason"] == "gdpr"


class TestSubscriptionSummary:
    def test_defaults(self):
        sub = SubscriptionSummary()
        assert sub.org_login == ""
        assert sub.plan == ""
        assert sub.seat_count == 0
        assert sub.stripe_customer_id is None

    def test_with_values(self):
        now = datetime.now(tz=UTC)
        sub = SubscriptionSummary(
            org_login="acme",
            plan="team",
            status="active",
            seat_count=10,
            billing_cycle="monthly",
            stripe_customer_id="cus_abc",
            current_period_start=now,
            current_period_end=now,
        )
        assert sub.plan == "team"
        assert sub.stripe_customer_id == "cus_abc"


class TestIntegrationSummary:
    def test_defaults(self):
        integration = IntegrationSummary()
        assert integration.org_login == ""
        assert integration.provider == ""
        assert integration.connected_by is None

    def test_with_values(self):
        now = datetime.now(tz=UTC)
        integration = IntegrationSummary(
            org_login="acme",
            provider="jira",
            display_name="Jira Cloud",
            status="active",
            connected_by="auth0|admin",
            connected_at=now,
        )
        assert integration.provider == "jira"
        assert integration.connected_by == "auth0|admin"
