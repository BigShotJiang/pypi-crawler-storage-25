"""Tests for admin route private helpers and uncovered route branches."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest
from httpx import ASGITransport, AsyncClient

from canon.admin.middleware import require_super_admin
from canon.admin.models import AuditEventResponse
from canon.admin.routes import (
    _audit_row_to_response,
    _client_ip,
    _coerce_integration,
    _coerce_org,
    _coerce_subscription,
    _coerce_user,
)
from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission
from canon.main import app
from canon.settings import Settings

# ------------------------------------------------------------------
# _client_ip
# ------------------------------------------------------------------


class TestClientIp:
    def test_prefers_x_real_ip(self):
        request = MagicMock()
        request.headers = {"x-real-ip": "1.2.3.4", "x-forwarded-for": "10.0.0.1, 5.6.7.8"}
        request.client = MagicMock(host="127.0.0.1")

        assert _client_ip(request) == "1.2.3.4"

    def test_falls_back_to_x_forwarded_for(self):
        request = MagicMock()
        request.headers = {"x-forwarded-for": "10.0.0.1, 5.6.7.8"}
        request.client = MagicMock(host="127.0.0.1")

        # nginx-ingress: rightmost entry is the real client IP
        assert _client_ip(request) == "5.6.7.8"

    def test_single_forwarded_for(self):
        request = MagicMock()
        request.headers = {"x-forwarded-for": "10.0.0.1"}
        request.client = MagicMock(host="127.0.0.1")

        assert _client_ip(request) == "10.0.0.1"

    def test_falls_back_to_client_host(self):
        request = MagicMock()
        request.headers = {}
        request.client = MagicMock(host="192.168.1.1")

        assert _client_ip(request) == "192.168.1.1"

    def test_returns_none_when_no_client(self):
        request = MagicMock()
        request.headers = {}
        request.client = None

        assert _client_ip(request) is None

    def test_strips_whitespace_from_real_ip(self):
        request = MagicMock()
        request.headers = {"x-real-ip": "  1.2.3.4  "}
        request.client = None

        assert _client_ip(request) == "1.2.3.4"

    def test_strips_whitespace_from_forwarded_for(self):
        request = MagicMock()
        request.headers = {"x-forwarded-for": "10.0.0.1,  5.6.7.8 "}
        request.client = None

        assert _client_ip(request) == "5.6.7.8"


# ------------------------------------------------------------------
# _audit_row_to_response
# ------------------------------------------------------------------


class TestAuditRowToResponse:
    def test_converts_basic_row(self):
        row = {
            "id": "uuid-1",
            "event_type": "user.created",
            "resource_type": "user",
            "resource_id": "42",
            "actor_id": 7,
            "org": "acme",
            "detail": None,
            "ip_address": "10.0.0.1",
            "created_at": None,
        }
        result = _audit_row_to_response(row)

        assert isinstance(result, AuditEventResponse)
        assert result.id == "uuid-1"
        assert result.event_type == "user.created"
        assert result.actor_id == 7
        assert result.ip_address == "10.0.0.1"

    def test_parses_json_string_detail(self):
        row = {
            "id": "uuid-2",
            "event_type": "org.updated",
            "resource_type": "org",
            "resource_id": "acme",
            "actor_id": None,
            "org": "acme",
            "detail": json.dumps({"old_name": "A", "new_name": "B"}),
            "ip_address": None,
            "created_at": None,
        }
        result = _audit_row_to_response(row)

        assert result.detail == {"old_name": "A", "new_name": "B"}

    def test_handles_dict_detail_directly(self):
        row = {
            "id": "uuid-3",
            "event_type": "x",
            "resource_type": "y",
            "resource_id": "z",
            "detail": {"already": "parsed"},
        }
        result = _audit_row_to_response(row)

        assert result.detail == {"already": "parsed"}

    def test_handles_invalid_json_detail(self):
        row = {
            "id": "uuid-4",
            "event_type": "x",
            "resource_type": "y",
            "resource_id": "z",
            "detail": "not valid json {",
        }
        result = _audit_row_to_response(row)

        assert result.detail is None

    def test_handles_empty_row(self):
        row = {}
        result = _audit_row_to_response(row)

        assert result.id == ""
        assert result.event_type == ""
        assert result.ip_address is None

    def test_converts_ip_address_to_string(self):
        row = {
            "id": "1",
            "event_type": "x",
            "resource_type": "y",
            "resource_id": "z",
            "ip_address": "::1",
        }
        result = _audit_row_to_response(row)

        assert result.ip_address == "::1"

    def test_none_ip_stays_none(self):
        row = {
            "id": "1",
            "event_type": "x",
            "resource_type": "y",
            "resource_id": "z",
            "ip_address": None,
        }
        result = _audit_row_to_response(row)

        assert result.ip_address is None


# ------------------------------------------------------------------
# _coerce_org
# ------------------------------------------------------------------


class TestCoerceOrg:
    def test_basic_coercion(self):
        row = {
            "login": "acme",
            "installation_id": 42,
            "created_at": None,
            "status": "active",
        }
        result = _coerce_org(row)

        assert result["login"] == "acme"
        assert result["installation_id"] == "42"
        assert result["status"] == "active"

    def test_none_installation_id(self):
        row = {"login": "acme", "installation_id": None}
        result = _coerce_org(row)

        assert result["installation_id"] is None

    def test_derives_member_count_from_members_list(self):
        row = {
            "login": "acme",
            "members": [{"user_id": "u1"}, {"user_id": "u2"}, {"user_id": "u3"}],
        }
        result = _coerce_org(row)

        assert result["member_count"] == 3

    def test_preserves_explicit_member_count_over_members_list(self):
        row = {
            "login": "acme",
            "member_count": 5,
            "members": [{"user_id": "u1"}],  # len is 1 but member_count=5 wins
        }
        result = _coerce_org(row)

        assert result["member_count"] == 5

    def test_empty_row_defaults(self):
        result = _coerce_org({})

        assert result["login"] == ""
        assert result["status"] == "active"
        assert result["display_name"] == ""
        assert result["member_count"] is None

    def test_metadata_fields(self):
        row = {
            "login": "acme",
            "primary_contact_email": "ops@acme.com",
            "primary_contact_name": "Ops",
            "support_notes": "VIP",
            "oidc_org_id": "org_xyz",
        }
        result = _coerce_org(row)

        assert result["primary_contact_email"] == "ops@acme.com"
        assert result["oidc_org_id"] == "org_xyz"


# ------------------------------------------------------------------
# _coerce_user
# ------------------------------------------------------------------


class TestCoerceUser:
    def test_basic_coercion(self):
        row = {
            "id": 1,
            "login": "alice",
            "email": "alice@example.com",
            "role": "editor",
            "created_at": None,
        }
        result = _coerce_user(row)

        assert result["id"] == 1
        assert result["login"] == "alice"
        assert result["status"] == "active"

    def test_empty_row_defaults(self):
        result = _coerce_user({})

        assert result["id"] == 0
        assert result["login"] == ""
        assert result["role"] == ""
        assert result["status"] == "active"

    def test_auth0_enrichment_fields(self):
        row = {
            "id": 1,
            "login": "alice",
            "email": "alice@example.com",
            "role": "editor",
            "last_login": "2026-01-01",
            "login_count": 42,
            "email_verified": True,
            "picture": "https://example.com/pic.png",
            "identities": [{"provider": "google"}],
        }
        result = _coerce_user(row)

        assert result["last_login"] == "2026-01-01"
        assert result["login_count"] == 42
        assert result["email_verified"] is True
        assert result["identities"] == [{"provider": "google"}]


# ------------------------------------------------------------------
# _coerce_subscription
# ------------------------------------------------------------------


class TestCoerceSubscription:
    def test_basic_coercion(self):
        row = {
            "org_login": "acme",
            "plan": "team",
            "status": "active",
            "seat_count": 5,
            "billing_cycle": "monthly",
            "stripe_customer_id": "cus_abc",
            "current_period_start": None,
            "current_period_end": None,
        }
        result = _coerce_subscription(row)

        assert result["org_login"] == "acme"
        assert result["plan"] == "team"
        assert result["stripe_customer_id"] == "cus_abc"

    def test_empty_row_defaults(self):
        result = _coerce_subscription({})

        assert result["org_login"] == ""
        assert result["plan"] == ""
        assert result["seat_count"] == 0
        assert result["stripe_customer_id"] is None


# ------------------------------------------------------------------
# _coerce_integration
# ------------------------------------------------------------------


class TestCoerceIntegration:
    def test_basic_coercion(self):
        row = {
            "org_login": "acme",
            "provider": "jira",
            "display_name": "Jira Cloud",
            "status": "active",
            "connected_by": "auth0|admin",
            "connected_at": None,
        }
        result = _coerce_integration(row)

        assert result["provider"] == "jira"
        assert result["connected_by"] == "auth0|admin"

    def test_empty_row_defaults(self):
        result = _coerce_integration({})

        assert result["org_login"] == ""
        assert result["provider"] == ""
        assert result["connected_by"] is None


# ------------------------------------------------------------------
# Route-level tests for uncovered branches
# ------------------------------------------------------------------


def _super_admin_user() -> CurrentUser:
    return CurrentUser(
        sub="admin-1",
        email="admin@canonhq.co",
        name="Admin User",
        org_login="canonhq",
        permissions=frozenset(Permission),
        auth_method="session",
    )


@pytest.fixture(autouse=True)
def _setup_app_state():
    user = _super_admin_user()
    app.dependency_overrides[require_super_admin] = lambda: user
    app.state.settings = Settings(deployment_mode="cloud")
    app.state.admin_store = AsyncMock()
    app.state.audit_store = AsyncMock()
    app.state.session_store = AsyncMock()
    app.state.user_store = AsyncMock()
    app.state.db_pool = None
    app.state.registry = None
    app.state.cache = MagicMock()
    app.state.github_client = MagicMock()
    yield
    app.dependency_overrides.pop(require_super_admin, None)
    app.state.admin_store = None
    app.state.audit_store = None
    app.state.search_index = None
    app.state.opensearch_client = None
    app.state.embed_client = None


@pytest.fixture
def client():
    return AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test", follow_redirects=False
    )


class TestDashboardAuditEvents:
    """Dashboard route coverage for audit event rendering."""

    async def test_dashboard_with_audit_events(self, client: AsyncClient):
        app.state.admin_store.get_kpis = AsyncMock(
            return_value={"org_count": 1, "user_count": 2, "spec_count": 3, "avg_coverage_pct": 0}
        )
        app.state.admin_store.get_health_summary = AsyncMock(return_value=[])
        app.state.audit_store.list = AsyncMock(
            return_value=[
                {
                    "id": "uuid-1",
                    "event_type": "user.created",
                    "resource_type": "user",
                    "resource_id": "1",
                    "actor_id": None,
                    "org": "acme",
                    "detail": json.dumps({"key": "value"}),
                    "ip_address": "10.0.0.1",
                    "created_at": None,
                }
            ]
        )

        resp = await client.get("/api/admin/dashboard")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data["recent_events"]) == 1
        assert data["recent_events"][0]["event_type"] == "user.created"
        assert data["recent_events"][0]["detail"] == {"key": "value"}

    async def test_dashboard_kpi_failure_returns_defaults(self, client: AsyncClient):
        app.state.admin_store.get_kpis = AsyncMock(side_effect=RuntimeError("db error"))
        app.state.admin_store.get_health_summary = AsyncMock(return_value=[])
        app.state.audit_store.list = AsyncMock(return_value=[])

        resp = await client.get("/api/admin/dashboard")

        assert resp.status_code == 200
        data = resp.json()
        assert data["kpis"]["org_count"] == 0

    async def test_dashboard_health_failure_returns_empty(self, client: AsyncClient):
        app.state.admin_store.get_kpis = AsyncMock(
            return_value={"org_count": 0, "user_count": 0, "spec_count": 0, "avg_coverage_pct": 0}
        )
        app.state.admin_store.get_health_summary = AsyncMock(side_effect=RuntimeError("db error"))
        app.state.audit_store.list = AsyncMock(return_value=[])

        resp = await client.get("/api/admin/dashboard")

        assert resp.status_code == 200
        data = resp.json()
        assert data["health"] == []

    async def test_dashboard_audit_failure_returns_empty_events(self, client: AsyncClient):
        app.state.admin_store.get_kpis = AsyncMock(
            return_value={"org_count": 0, "user_count": 0, "spec_count": 0, "avg_coverage_pct": 0}
        )
        app.state.admin_store.get_health_summary = AsyncMock(return_value=[])
        app.state.audit_store.list = AsyncMock(side_effect=RuntimeError("db error"))

        resp = await client.get("/api/admin/dashboard")

        assert resp.status_code == 200
        data = resp.json()
        assert data["recent_events"] == []


class TestBillingOrgDetail:
    async def test_billing_org_returns_detail(self, client: AsyncClient):
        app.state.admin_store.get_org_billing = AsyncMock(
            return_value={
                "org_login": "acme",
                "plan": "team",
                "status": "active",
                "seat_count": 5,
                "billing_cycle": "monthly",
                "ai_ops_used": 150,
                "ai_ops_included": 1000,
            }
        )

        resp = await client.get("/api/admin/billing/acme")

        assert resp.status_code == 200
        data = resp.json()
        assert data["plan"] == "team"
        assert data["ai_ops_used"] == 150
        assert data["ai_ops_included"] == 1000

    async def test_billing_org_not_found(self, client: AsyncClient):
        app.state.admin_store.get_org_billing = AsyncMock(return_value=None)

        resp = await client.get("/api/admin/billing/ghost")

        assert resp.status_code == 404

    async def test_billing_org_503_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.get("/api/admin/billing/acme")

        assert resp.status_code == 503

    async def test_billing_list_empty_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.get("/api/admin/billing")

        assert resp.status_code == 200
        assert resp.json() == []


class TestBillingList:
    async def test_returns_subscription_list(self, client: AsyncClient):
        app.state.admin_store.list_subscriptions = AsyncMock(
            return_value=[
                {
                    "org_login": "acme",
                    "plan": "team",
                    "status": "active",
                    "seat_count": 5,
                    "billing_cycle": "monthly",
                    "stripe_customer_id": "cus_abc",
                    "current_period_start": None,
                    "current_period_end": None,
                }
            ]
        )

        resp = await client.get("/api/admin/billing")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["org_login"] == "acme"


class TestHealthException:
    async def test_health_exception_returns_empty(self, client: AsyncClient):
        app.state.admin_store.get_health_summary = AsyncMock(side_effect=RuntimeError("db error"))

        resp = await client.get("/api/admin/health")

        assert resp.status_code == 200
        assert resp.json() == []


class TestIntegrationsRoute:
    async def test_returns_formatted_list(self, client: AsyncClient):
        app.state.admin_store.list_integrations = AsyncMock(
            return_value=[
                {
                    "org_login": "acme",
                    "provider": "jira",
                    "display_name": "Jira Cloud",
                    "status": "active",
                    "connected_by": "auth0|admin",
                    "connected_at": None,
                }
            ]
        )

        resp = await client.get("/api/admin/integrations")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["provider"] == "jira"

    async def test_passes_provider_filter(self, client: AsyncClient):
        app.state.admin_store.list_integrations = AsyncMock(return_value=[])

        resp = await client.get("/api/admin/integrations?provider=linear")

        assert resp.status_code == 200
        app.state.admin_store.list_integrations.assert_awaited_once()
        call_kwargs = app.state.admin_store.list_integrations.call_args.kwargs
        assert call_kwargs["provider"] == "linear"

    async def test_empty_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.get("/api/admin/integrations")

        assert resp.status_code == 200
        assert resp.json() == []


class TestAuditRoute:
    async def test_audit_passes_all_filters(self, client: AsyncClient):
        app.state.audit_store.list = AsyncMock(return_value=[])

        resp = await client.get(
            "/api/admin/audit?org=acme&event_type=user.created&actor_id=7&limit=10&offset=5"
        )

        assert resp.status_code == 200
        call_kwargs = app.state.audit_store.list.call_args.kwargs
        assert call_kwargs["org"] == "acme"
        assert call_kwargs["event_type"] == "user.created"
        assert call_kwargs["actor_id"] == 7
        assert call_kwargs["limit"] == 10
        assert call_kwargs["offset"] == 5


class TestAIRoutes:
    async def test_ai_overview_empty_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.get("/api/admin/ai")

        assert resp.status_code == 200
        data = resp.json()
        assert data["ops_today"] == 0
        assert data["orgs"] == []

    async def test_ai_overview_handles_exception(self, client: AsyncClient):
        app.state.admin_store.get_ai_ops_summary = AsyncMock(side_effect=RuntimeError("db error"))

        resp = await client.get("/api/admin/ai")

        assert resp.status_code == 200
        data = resp.json()
        assert data["ops_today"] == 0

    async def test_ai_overview_handles_non_dict_result(self, client: AsyncClient):
        app.state.admin_store.get_ai_ops_summary = AsyncMock(return_value="unexpected")

        resp = await client.get("/api/admin/ai")

        assert resp.status_code == 200
        data = resp.json()
        assert data["ops_today"] == 0

    async def test_ai_org_empty_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.get("/api/admin/ai/acme")

        assert resp.status_code == 200
        data = resp.json()
        assert data["org"] == "acme"
        assert data["ops_today"] == 0

    async def test_ai_org_handles_exception(self, client: AsyncClient):
        app.state.admin_store.get_org_ai_usage = AsyncMock(side_effect=RuntimeError("db error"))

        resp = await client.get("/api/admin/ai/acme")

        assert resp.status_code == 200
        data = resp.json()
        assert data["org"] == "acme"

    async def test_ai_org_handles_non_dict_result(self, client: AsyncClient):
        app.state.admin_store.get_org_ai_usage = AsyncMock(return_value=None)

        resp = await client.get("/api/admin/ai/acme")

        assert resp.status_code == 200
        data = resp.json()
        assert data["org"] == "acme"
        assert data["ops_today"] == 0


class TestOrgGetWithMembers:
    """Coverage for get_org route including members list passthrough."""

    async def test_includes_members_in_response(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(
            return_value={
                "login": "acme",
                "installation_id": "42",
                "user_count": 5,
                "created_at": None,
                "members": [{"user_id": "auth0|1"}, {"user_id": "auth0|2"}],
            }
        )

        resp = await client.get("/api/admin/orgs/acme")

        assert resp.status_code == 200
        data = resp.json()
        assert "members" in data
        assert len(data["members"]) == 2

    async def test_503_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.get("/api/admin/orgs/acme")

        assert resp.status_code == 503


class TestOrgListWithSearch:
    async def test_passes_search_param(self, client: AsyncClient):
        app.state.admin_store.list_orgs = AsyncMock(return_value=[])

        resp = await client.get("/api/admin/orgs?search=acme&limit=10&offset=5")

        assert resp.status_code == 200
        call_kwargs = app.state.admin_store.list_orgs.call_args.kwargs
        assert call_kwargs["search"] == "acme"
        assert call_kwargs["limit"] == 10
        assert call_kwargs["offset"] == 5


class TestUserListFilters:
    async def test_passes_all_filter_params(self, client: AsyncClient):
        app.state.admin_store.list_users = AsyncMock(return_value=[])

        resp = await client.get(
            "/api/admin/users?org=acme&role=admin&search=alice&limit=10&offset=5"
        )

        assert resp.status_code == 200
        call_kwargs = app.state.admin_store.list_users.call_args.kwargs
        assert call_kwargs["org"] == "acme"
        assert call_kwargs["role"] == "admin"
        assert call_kwargs["search"] == "alice"

    async def test_returns_empty_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.get("/api/admin/users")

        assert resp.status_code == 200
        assert resp.json() == []


class TestUpdateUserRoleNotFound:
    async def test_update_role_returns_404_when_update_returns_none(self, client: AsyncClient):
        """Covers the second 404 branch: get_user succeeds but update_user_role returns None."""
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "role": "editor", "email": "u@e.com"}
        )
        app.state.admin_store.update_user_role = AsyncMock(return_value=None)

        resp = await client.patch("/api/admin/users/1", json={"role": "admin"})

        assert resp.status_code == 404


class TestDeactivateUserConcurrent:
    async def test_409_on_concurrent_deactivation(self, client: AsyncClient):
        """Covers the 409 branch when deactivate_user returns None."""
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "role": "editor", "status": "active", "email": "u@e.com"}
        )
        app.state.admin_store.deactivate_user = AsyncMock(return_value=None)

        resp = await client.post("/api/admin/users/1/deactivate")

        assert resp.status_code == 409

    async def test_503_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.post("/api/admin/users/1/deactivate")

        assert resp.status_code == 503


class TestReactivateUserConcurrent:
    async def test_409_on_concurrent_reactivation(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "role": "editor", "status": "deactivated", "email": "u@e.com"}
        )
        app.state.admin_store.reactivate_user = AsyncMock(return_value=None)

        resp = await client.post("/api/admin/users/1/reactivate")

        assert resp.status_code == 409

    async def test_503_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.post("/api/admin/users/1/reactivate")

        assert resp.status_code == 503


class TestReindexAuditFailure:
    async def test_reindex_still_succeeds_on_audit_failure(self, client: AsyncClient):
        app.state.audit_store.log = AsyncMock(side_effect=RuntimeError("audit db down"))

        resp = await client.post("/api/admin/orgs/acme/reindex")

        assert resp.status_code == 200
        assert resp.json()["org"] == "acme"

    async def test_reindex_without_audit_store(self, client: AsyncClient):
        app.state.audit_store = None

        resp = await client.post("/api/admin/orgs/acme/reindex")

        assert resp.status_code == 200


class TestSuspendOrgNoStore:
    async def test_503_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.post("/api/admin/orgs/acme/suspend")

        assert resp.status_code == 503


class TestReactivateOrgNoStore:
    async def test_503_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.post("/api/admin/orgs/acme/reactivate")

        assert resp.status_code == 503


class TestRepairAuth0EdgeCases:
    async def test_400_when_no_installation_id(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(
            return_value={
                "login": "acme",
                "installation_id": None,
                "status": "active",
            }
        )
        app.state.registry = AsyncMock()
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/orgs/acme/repair-auth0")

        assert resp.status_code == 400
        assert "installation" in resp.json()["detail"].lower()

    async def test_500_when_installation_id_non_numeric(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(
            return_value={
                "login": "acme",
                "installation_id": "not-a-number",
                "status": "active",
            }
        )
        app.state.registry = AsyncMock()
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/orgs/acme/repair-auth0")

        assert resp.status_code == 500
        assert "not numeric" in resp.json()["detail"]

    async def test_503_when_required_services_missing(self, client: AsyncClient):
        app.state.admin_store = None
        app.state.registry = None
        app.state.oidc_provider = None

        resp = await client.post("/api/admin/orgs/acme/repair-auth0")

        assert resp.status_code == 503


class TestUpdateOrgAuth0Failure:
    async def test_502_when_auth0_update_organization_fails(self, client: AsyncClient):
        existing = {
            "login": "acme",
            "installation_id": 123,
            "status": "active",
            "display_name": "Old Name",
            "oidc_org_id": "org_xyz",
            "primary_contact_email": None,
            "primary_contact_name": None,
            "support_notes": None,
            "user_count": 5,
            "created_at": None,
        }
        app.state.admin_store.get_org = AsyncMock(return_value=existing)
        provider = AsyncMock()
        provider.update_organization = AsyncMock(side_effect=RuntimeError("auth0 down"))
        app.state.oidc_provider = provider

        resp = await client.patch("/api/admin/orgs/acme", json={"display_name": "New Name"})

        assert resp.status_code == 502
        assert "Auth0 update failed" in resp.json()["detail"]

    async def test_400_display_name_in_self_hosted_mode(self, client: AsyncClient):
        app.state.settings = Settings(deployment_mode="self_hosted")
        existing = {
            "login": "acme",
            "installation_id": 123,
            "status": "active",
            "display_name": "Old Name",
            "oidc_org_id": "org_xyz",
            "primary_contact_email": None,
            "primary_contact_name": None,
            "support_notes": None,
            "user_count": 5,
            "created_at": None,
        }
        app.state.admin_store.get_org = AsyncMock(return_value=existing)

        resp = await client.patch("/api/admin/orgs/acme", json={"display_name": "New Name"})

        assert resp.status_code == 400
        assert "cloud" in resp.json()["detail"].lower()


class TestResendInviteEdgeCases:
    async def test_502_on_get_user_orgs_failure(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@example.com",
                "status": "active",
            }
        )
        provider = AsyncMock()
        provider.get_user_orgs = AsyncMock(side_effect=RuntimeError("auth0 down"))
        app.state.oidc_provider = provider

        resp = await client.post("/api/admin/users/1/resend-invite")

        assert resp.status_code == 502

    async def test_502_on_create_invitation_failure(self, client: AsyncClient):
        from canon.auth.providers.protocol import OrgInfo

        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@example.com",
                "status": "active",
            }
        )
        provider = AsyncMock()
        provider.get_user_orgs = AsyncMock(return_value=[OrgInfo(id="org_xyz", name="acme")])
        provider.create_invitation = AsyncMock(side_effect=RuntimeError("auth0 down"))
        app.state.oidc_provider = provider

        resp = await client.post("/api/admin/users/1/resend-invite")

        assert resp.status_code == 502

    async def test_502_when_invitation_url_missing(self, client: AsyncClient):
        from canon.auth.providers.protocol import OrgInfo

        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@example.com",
                "status": "active",
            }
        )
        provider = AsyncMock()
        provider.get_user_orgs = AsyncMock(return_value=[OrgInfo(id="org_xyz", name="acme")])
        provider.create_invitation = AsyncMock(return_value={})  # no invitation_url
        app.state.oidc_provider = provider

        resp = await client.post("/api/admin/users/1/resend-invite")

        assert resp.status_code == 502

    async def test_400_when_user_has_no_email(self, client: AsyncClient):
        from canon.auth.providers.protocol import OrgInfo

        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "",
                "status": "active",
            }
        )
        provider = AsyncMock()
        provider.get_user_orgs = AsyncMock(return_value=[OrgInfo(id="org_xyz", name="acme")])
        app.state.oidc_provider = provider

        resp = await client.post("/api/admin/users/1/resend-invite")

        assert resp.status_code == 400
        assert "email" in resp.json()["detail"].lower()

    async def test_404_when_user_not_found(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=None)
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/users/1/resend-invite")

        assert resp.status_code == 404

    async def test_503_when_services_missing(self, client: AsyncClient):
        app.state.admin_store = None
        app.state.oidc_provider = None

        resp = await client.post("/api/admin/users/1/resend-invite")

        assert resp.status_code == 503


class TestPasswordResetEdgeCases:
    async def test_502_on_auth0_failure(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@example.com",
                "status": "active",
            }
        )
        provider = AsyncMock()
        provider.create_password_change_ticket = AsyncMock(side_effect=RuntimeError("auth0 down"))
        app.state.oidc_provider = provider

        resp = await client.post("/api/admin/users/1/password-reset")

        assert resp.status_code == 502

    async def test_502_when_ticket_url_missing(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "oidc_sub": "auth0|abc",
                "email": "u@example.com",
                "status": "active",
            }
        )
        provider = AsyncMock()
        provider.create_password_change_ticket = AsyncMock(return_value={})  # no ticket
        app.state.oidc_provider = provider

        resp = await client.post("/api/admin/users/1/password-reset")

        assert resp.status_code == 502

    async def test_404_when_user_not_found(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=None)
        app.state.oidc_provider = AsyncMock()

        resp = await client.post("/api/admin/users/1/password-reset")

        assert resp.status_code == 404

    async def test_503_when_services_missing(self, client: AsyncClient):
        app.state.admin_store = None
        app.state.oidc_provider = None

        resp = await client.post("/api/admin/users/1/password-reset")

        assert resp.status_code == 503


class TestUserSessionsEdgeCases:
    async def test_503_when_no_stores(self, client: AsyncClient):
        app.state.admin_store = None
        app.state.session_store = None

        resp = await client.get("/api/admin/users/1/sessions")

        assert resp.status_code == 503

    async def test_revoke_503_when_no_stores(self, client: AsyncClient):
        app.state.admin_store = None
        app.state.session_store = None
        app.state.user_store = None

        resp = await client.delete("/api/admin/users/1/sessions/sess-1")

        assert resp.status_code == 503


class TestUserApiKeysEdgeCases:
    async def test_503_when_no_stores(self, client: AsyncClient):
        app.state.admin_store = None
        app.state.user_store = None

        resp = await client.get("/api/admin/users/1/api-keys")

        assert resp.status_code == 503

    async def test_404_when_user_not_found(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=None)

        resp = await client.get("/api/admin/users/1/api-keys")

        assert resp.status_code == 404

    async def test_revoke_503_when_no_stores(self, client: AsyncClient):
        app.state.admin_store = None
        app.state.user_store = None

        resp = await client.delete("/api/admin/users/1/api-keys/7")

        assert resp.status_code == 503

    async def test_revoke_404_when_user_not_found(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=None)

        resp = await client.delete("/api/admin/users/1/api-keys/7")

        assert resp.status_code == 404


class TestDeleteUserEdgeCases:
    async def test_503_when_services_missing(self, client: AsyncClient):
        app.state.admin_store = None
        app.state.user_store = None
        app.state.oidc_provider = None

        resp = await client.request("DELETE", "/api/admin/users/1", json={"confirm": "anything"})

        assert resp.status_code == 503


class TestRemoveUserOrgEdgeCases:
    async def test_400_when_user_has_no_oidc_sub(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "oidc_sub": "", "email": "u@e.com"}
        )
        app.state.registry = AsyncMock()
        app.state.oidc_provider = AsyncMock()

        resp = await client.delete("/api/admin/users/1/orgs/org_acme")

        assert resp.status_code == 400

    async def test_503_when_services_missing(self, client: AsyncClient):
        app.state.admin_store = None
        app.state.registry = None
        app.state.oidc_provider = None

        resp = await client.delete("/api/admin/users/1/orgs/org_acme")

        assert resp.status_code == 503

    async def test_404_in_self_hosted(self, client: AsyncClient):
        app.state.settings = Settings(deployment_mode="self_hosted")

        resp = await client.delete("/api/admin/users/1/orgs/org_acme")

        assert resp.status_code == 404


class TestListUserOrgsEdgeCases:
    async def test_503_when_services_missing(self, client: AsyncClient):
        app.state.admin_store = None
        app.state.registry = None
        app.state.oidc_provider = None

        resp = await client.get("/api/admin/users/1/orgs")

        assert resp.status_code == 503

    async def test_502_on_auth0_failure(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={"id": 1, "oidc_sub": "auth0|abc", "email": "u@e.com"}
        )
        provider = AsyncMock()
        provider.get_user_orgs = AsyncMock(side_effect=RuntimeError("auth0 down"))
        app.state.oidc_provider = provider
        app.state.registry = AsyncMock()

        resp = await client.get("/api/admin/users/1/orgs")

        assert resp.status_code == 502
