"""Tests for error triage (error → GitHub issue creation)."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from canon.alerts.triage import ErrorInfo, ErrorTriager


class TestErrorTriager:
    def _make_triager(
        self, auto_triage_enabled: bool = True
    ) -> tuple[ErrorTriager, AsyncMock, AsyncMock]:
        mock_error_store = AsyncMock()
        mock_github_client = AsyncMock()
        triager = ErrorTriager(
            error_store=mock_error_store,
            github_client=mock_github_client,
            repo="org/repo",
            auto_triage_enabled=auto_triage_enabled,
        )
        return triager, mock_error_store, mock_github_client

    @pytest.mark.asyncio
    async def test_creates_new_issue_for_new_error(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = None
        mock_gh.create_issue.return_value = {
            "number": 42,
            "html_url": "https://github.com/org/repo/issues/42",
        }

        error = ErrorInfo(
            fingerprint="fp123",
            exception_type="KeyError",
            message="'user_id'",
            stack_trace="Traceback...",
            endpoint="/webhook",
            count=5,
            first_seen="2026-03-20T10:00:00Z",
            last_seen="2026-03-20T10:05:00Z",
            posthog_url="https://us.posthog.com/error/abc",
        )

        result = await triager.triage(error)

        assert result.action == "created"
        assert result.issue_number == 42
        mock_store.create.assert_called_once()
        mock_gh.create_issue.assert_called_once()
        mock_gh.ensure_label.assert_called()

    @pytest.mark.asyncio
    async def test_skips_existing_open_issue(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = MagicMock(
            issue_number=42,
            resolved_at=None,
        )

        error = ErrorInfo(
            fingerprint="fp123",
            exception_type="KeyError",
            message="'user_id'",
        )

        result = await triager.triage(error)

        assert result.action == "deduplicated"
        assert result.issue_number == 42
        mock_store.increment_occurrence.assert_called_once()
        mock_gh.create_issue.assert_not_called()

    @pytest.mark.asyncio
    async def test_reopens_resolved_issue(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = MagicMock(
            issue_number=42,
            issue_url="https://github.com/org/repo/issues/42",
            resolved_at="2026-03-19T00:00:00Z",
        )

        error = ErrorInfo(
            fingerprint="fp123",
            exception_type="KeyError",
            message="'user_id'",
        )

        result = await triager.triage(error)

        assert result.action == "reopened"
        assert result.issue_number == 42
        mock_gh.update_issue.assert_called_once_with("org", "repo", 42, state="open")
        mock_gh.create_comment.assert_called_once()
        mock_store.clear_resolved.assert_called_once()

    @pytest.mark.asyncio
    async def test_creates_issue_with_severity_labels(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = None
        mock_store.create.return_value = MagicMock(id=1)
        mock_gh.create_issue.return_value = {
            "number": 99,
            "html_url": "https://github.com/org/repo/issues/99",
        }

        error = ErrorInfo(
            fingerprint="fp-critical",
            exception_type="DatabaseError",
            message="connection lost",
            severity="critical",
        )

        result = await triager.triage(error)

        assert result.action == "created"
        # Verify severity label was included
        create_call = mock_gh.create_issue.call_args
        labels = create_call[1]["labels"]
        assert "severity:critical" in labels
        # Verify ensure_label was called for the severity label
        ensure_calls = [c[0] for c in mock_gh.ensure_label.call_args_list]
        label_names = [c[2] for c in ensure_calls]
        assert "severity:critical" in label_names

    @pytest.mark.asyncio
    async def test_reopens_with_posthog_url_in_comment(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = MagicMock(
            issue_number=42,
            issue_url="https://github.com/org/repo/issues/42",
            resolved_at="2026-03-19T00:00:00Z",
        )

        error = ErrorInfo(
            fingerprint="fp123",
            exception_type="KeyError",
            message="'user_id'",
            count=3,
            posthog_url="https://us.posthog.com/error/abc",
        )

        result = await triager.triage(error)

        assert result.action == "reopened"
        comment_body = mock_gh.create_comment.call_args[0][3]
        assert "Error recurrence detected" in comment_body
        assert "KeyError" in comment_body
        assert "View in PostHog" in comment_body
        assert "https://us.posthog.com/error/abc" in comment_body

    @pytest.mark.asyncio
    async def test_create_conflict_returns_deduplicated(self):
        triager, mock_store, mock_gh = self._make_triager()
        mock_store.get_by_fingerprint.return_value = None
        mock_store.create.return_value = None  # conflict
        mock_gh.create_issue.return_value = {
            "number": 42,
            "html_url": "https://github.com/org/repo/issues/42",
        }

        error = ErrorInfo(
            fingerprint="fp-race",
            exception_type="KeyError",
            message="test",
        )

        result = await triager.triage(error)
        assert result.action == "deduplicated"
        assert result.issue_number == 42

    @pytest.mark.asyncio
    async def test_auto_triage_disabled_returns_none(self):
        triager, mock_store, _mock_gh = self._make_triager(auto_triage_enabled=False)
        error = ErrorInfo(fingerprint="fp123", exception_type="KeyError", message="test")
        result = await triager.triage(error)
        assert result is None
        mock_store.get_by_fingerprint.assert_not_called()


class TestFormatIssueBody:
    """Tests for the _format_issue_body method."""

    def _make_triager(self) -> ErrorTriager:
        return ErrorTriager(
            error_store=AsyncMock(),
            github_client=AsyncMock(),
            repo="org/repo",
        )

    def test_basic_error_body(self):
        triager = self._make_triager()
        error = ErrorInfo(
            fingerprint="fp1",
            exception_type="ValueError",
            message="invalid input",
            severity="medium",
        )
        body = triager._format_issue_body(error)
        assert "Auto-Triaged Error" in body
        assert "`ValueError: invalid input`" in body
        assert "**Severity:** medium" in body
        assert "Auto-created by Canon SRE alerting" in body

    def test_body_includes_endpoint(self):
        triager = self._make_triager()
        error = ErrorInfo(
            fingerprint="fp1",
            exception_type="KeyError",
            message="key",
            endpoint="/api/webhook",
        )
        body = triager._format_issue_body(error)
        assert "`/api/webhook`" in body

    def test_body_includes_occurrence_count(self):
        triager = self._make_triager()
        error = ErrorInfo(
            fingerprint="fp1",
            exception_type="KeyError",
            message="key",
            count=10,
        )
        body = triager._format_issue_body(error)
        assert "**Occurrences:** 10" in body

    def test_body_omits_occurrences_when_count_is_one(self):
        triager = self._make_triager()
        error = ErrorInfo(
            fingerprint="fp1",
            exception_type="KeyError",
            message="key",
            count=1,
        )
        body = triager._format_issue_body(error)
        assert "Occurrences" not in body

    def test_body_includes_timestamps(self):
        triager = self._make_triager()
        error = ErrorInfo(
            fingerprint="fp1",
            exception_type="KeyError",
            message="key",
            first_seen="2026-05-01T10:00:00Z",
            last_seen="2026-05-01T10:30:00Z",
        )
        body = triager._format_issue_body(error)
        assert "2026-05-01T10:00:00Z" in body
        assert "2026-05-01T10:30:00Z" in body

    def test_body_includes_stack_trace(self):
        triager = self._make_triager()
        error = ErrorInfo(
            fingerprint="fp1",
            exception_type="KeyError",
            message="key",
            stack_trace="Traceback (most recent call last):\n  File ...",
        )
        body = triager._format_issue_body(error)
        assert "### Stack Trace" in body
        assert "```" in body
        assert "Traceback" in body
        assert "sensitive information" in body

    def test_body_truncates_long_stack_trace(self):
        triager = self._make_triager()
        long_trace = "x" * 5000
        error = ErrorInfo(
            fingerprint="fp1",
            exception_type="KeyError",
            message="key",
            stack_trace=long_trace,
        )
        body = triager._format_issue_body(error)
        assert "... (truncated)" in body

    def test_body_includes_posthog_url(self):
        triager = self._make_triager()
        error = ErrorInfo(
            fingerprint="fp1",
            exception_type="KeyError",
            message="key",
            posthog_url="https://us.posthog.com/error/abc",
        )
        body = triager._format_issue_body(error)
        assert "View in PostHog" in body
        assert "https://us.posthog.com/error/abc" in body


class TestAddSpecContextComment:
    """Tests for the _add_spec_context_comment method."""

    def _make_triager(self, agent_client=None) -> tuple[ErrorTriager, AsyncMock]:
        mock_gh = AsyncMock()
        triager = ErrorTriager(
            error_store=AsyncMock(),
            github_client=mock_gh,
            repo="org/repo",
            agent_client=agent_client,
        )
        return triager, mock_gh

    @pytest.mark.asyncio
    async def test_noop_when_no_agent_client(self):
        triager, mock_gh = self._make_triager(agent_client=None)
        error = ErrorInfo(fingerprint="fp1", exception_type="KeyError", message="key")
        await triager._add_spec_context_comment(42, error)
        mock_gh.create_comment.assert_not_called()

    @pytest.mark.asyncio
    async def test_noop_when_agent_not_available(self):
        mock_agent = MagicMock()
        mock_agent.is_available = False
        triager, mock_gh = self._make_triager(agent_client=mock_agent)
        error = ErrorInfo(fingerprint="fp1", exception_type="KeyError", message="key")
        await triager._add_spec_context_comment(42, error)
        mock_gh.create_comment.assert_not_called()

    @pytest.mark.asyncio
    async def test_swallows_exceptions(self):
        """Failures in spec context comment should be logged, not raised."""
        mock_agent = MagicMock()
        mock_agent.is_available = True
        mock_agent.complete.side_effect = RuntimeError("API error")
        triager, _mock_gh = self._make_triager(agent_client=mock_agent)
        error = ErrorInfo(fingerprint="fp1", exception_type="KeyError", message="key")
        # Should not raise
        await triager._add_spec_context_comment(42, error)


class TestErrorInfoDefaults:
    def test_default_values(self):
        error = ErrorInfo(
            fingerprint="fp1",
            exception_type="KeyError",
            message="missing key",
        )
        assert error.stack_trace == ""
        assert error.endpoint == ""
        assert error.count == 1
        assert error.first_seen == ""
        assert error.last_seen == ""
        assert error.posthog_url == ""
        assert error.severity == "medium"


class TestTriageResult:
    def test_triage_result_defaults(self):
        from canon.alerts.triage import TriageResult

        result = TriageResult(action="created", issue_number=42)
        assert result.issue_url == ""

    def test_triage_result_with_url(self):
        from canon.alerts.triage import TriageResult

        result = TriageResult(
            action="reopened",
            issue_number=42,
            issue_url="https://github.com/org/repo/issues/42",
        )
        assert result.issue_url == "https://github.com/org/repo/issues/42"
