"""Integration tests for TicketRefStatusStore against real PostgreSQL.

The unit tests at ``tests/test_db/test_ticket_ref_status_store.py`` use a
mock asyncpg pool and assert on SQL substrings, which is brittle for the
durability/concurrency guarantees the store actually promises:

  * Two concurrent ``record_failure`` calls with the same key must
    produce ``N+1`` and ``N+2`` (the threshold-flip is single-statement
    INSERT … ON CONFLICT, but a future refactor could split into
    SELECT+UPDATE and silently lose monotonicity).
  * ``record_failure`` and ``mark_ok`` must preserve a ``'dismissed'``
    row's status — operator-driven dismissal is sticky and the cron's
    failure/recovery paths cannot un-dismiss.

These integration tests pin those invariants against real Postgres
semantics. Skipped unless ``DATABASE_URL`` points at a live test DB
(provided by ``docker-compose.test.yml``).

Run with::

    uv run pytest -m integration tests/integration/test_ticket_ref_status_store.py -v
"""

from __future__ import annotations

import asyncio
import os

import asyncpg
import pytest

from canon.db.migrate import run_upgrade
from canon.db.ticket_ref_status_store import TicketRefStatusStore

pytestmark = pytest.mark.integration

DATABASE_URL = os.environ.get(
    "DATABASE_URL",
    "postgresql://canon:testpass@localhost:15432/canon_test",
)


def _can_connect() -> bool:
    try:
        loop = asyncio.new_event_loop()
        try:

            async def _check() -> None:
                conn = await asyncpg.connect(DATABASE_URL, timeout=5)
                await conn.close()

            loop.run_until_complete(_check())
        finally:
            loop.close()
        return True
    except Exception:
        return False


_DB_AVAILABLE = _can_connect()

skip_no_db = pytest.mark.skipif(
    not _DB_AVAILABLE,
    reason="Test database not available (set DATABASE_URL or start docker-compose.test.yml)",
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


async def _drop_all_tables() -> None:
    conn = await asyncpg.connect(DATABASE_URL, timeout=5)
    try:
        await conn.execute("DROP TABLE IF EXISTS alembic_version CASCADE")
        rows = await conn.fetch(
            "SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname = 'public'"
        )
        for row in rows:
            await conn.execute(f'DROP TABLE IF EXISTS "{row["tablename"]}" CASCADE')
    finally:
        await conn.close()


@pytest.fixture(scope="module")
def _migrated_db():
    """Run migrations once for the module — schema doesn't change between tests."""
    if not _DB_AVAILABLE:
        pytest.skip("test DB unavailable")
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(_drop_all_tables())
    finally:
        loop.close()
    run_upgrade(DATABASE_URL, revision="head")
    yield
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(_drop_all_tables())
    finally:
        loop.close()


@pytest.fixture
async def store(_migrated_db):
    """Build a fresh store each test, but truncate the table to stay isolated."""
    pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=4)
    async with pool.acquire() as conn:
        await conn.execute("TRUNCATE ticket_ref_status RESTART IDENTITY")
    yield TicketRefStatusStore(pool)
    await pool.close()


# ---------------------------------------------------------------------------
# Threshold flip
# ---------------------------------------------------------------------------


@skip_no_db
class TestRecordFailureThreshold:
    async def test_three_failures_flip_to_broken(self, store):
        for _ in range(3):
            await store.record_failure(
                installation_id=1,
                system="github",
                ticket_ref="o/r#1",
                error_kind="not_found",
                error_message="not found",
            )
        row = await store.get(1, "github", "o/r#1")
        assert row is not None
        assert row["status"] == "broken"
        assert row["consecutive_failures"] == 3

    async def test_two_failures_stay_ok(self, store):
        for _ in range(2):
            await store.record_failure(
                installation_id=1,
                system="github",
                ticket_ref="o/r#2",
                error_kind="not_found",
                error_message="not found",
            )
        row = await store.get(1, "github", "o/r#2")
        assert row is not None
        assert row["status"] == "ok"
        assert row["consecutive_failures"] == 2

    async def test_first_failure_creates_row(self, store):
        result = await store.record_failure(
            installation_id=1,
            system="github",
            ticket_ref="o/r#3",
            error_kind="not_found",
            error_message="not found",
        )
        assert result["status"] == "ok"
        assert result["consecutive_failures"] == 1
        row = await store.get(1, "github", "o/r#3")
        assert row is not None
        assert row["last_error_kind"] == "not_found"
        assert row["first_failure_at"] is not None


# ---------------------------------------------------------------------------
# Concurrency
# ---------------------------------------------------------------------------


@skip_no_db
class TestConcurrency:
    async def test_two_concurrent_failures_produce_n_plus_one_then_n_plus_two(self, store):
        """Two simultaneous record_failure calls must NOT race to the same
        counter value — Postgres's row-level lock on the conflicting row
        serializes the UPDATE clause inside ON CONFLICT.

        If a future refactor splits this into SELECT-then-UPDATE without
        an explicit row lock, both calls would read 0 and write 1, and
        we'd lose count. This test pins the invariant.
        """
        # Issue 5 concurrent calls; final consecutive_failures must be 5.
        results = await asyncio.gather(
            *(
                store.record_failure(
                    installation_id=1,
                    system="github",
                    ticket_ref="o/r#concurrent",
                    error_kind="not_found",
                    error_message="not found",
                )
                for _ in range(5)
            )
        )
        # Every result must report a unique consecutive_failures from 1..5
        counters = sorted(r["consecutive_failures"] for r in results)
        assert counters == [1, 2, 3, 4, 5], (
            f"Expected counters [1,2,3,4,5] but got {counters} — concurrency invariant broken"
        )
        row = await store.get(1, "github", "o/r#concurrent")
        assert row is not None
        assert row["consecutive_failures"] == 5
        assert row["status"] == "broken"  # threshold (3) crossed


# ---------------------------------------------------------------------------
# Dismissed-stickiness
# ---------------------------------------------------------------------------


@skip_no_db
class TestDismissedStickiness:
    async def test_record_failure_does_not_unflip_dismissed(self, store):
        """User dismissed a ref; cron sees N more 404s; row must stay dismissed."""
        # Set up: get the row to broken, then dismiss it
        for _ in range(3):
            await store.record_failure(
                installation_id=1,
                system="github",
                ticket_ref="o/r#dismissed",
                error_kind="not_found",
                error_message="not found",
            )
        await store.dismiss(
            installation_id=1,
            system="github",
            ticket_ref="o/r#dismissed",
            dismissed_by="auth0|admin",
        )
        row = await store.get(1, "github", "o/r#dismissed")
        assert row["status"] == "dismissed"

        # Now simulate the cron seeing more 404s on this ref
        for _ in range(5):
            await store.record_failure(
                installation_id=1,
                system="github",
                ticket_ref="o/r#dismissed",
                error_kind="not_found",
                error_message="not found",
            )
        row = await store.get(1, "github", "o/r#dismissed")
        # Status MUST remain dismissed — user explicitly said "leave it"
        assert row["status"] == "dismissed"
        # dismissed_by stays — not overwritten by record_failure
        assert row["dismissed_by"] == "auth0|admin"

    async def test_mark_ok_does_not_unflip_dismissed(self, store):
        """User dismissed a ref; ticket comes back; row must stay dismissed
        until the user explicitly un-dismisses (manual recheck or remove)."""
        # Set up: dismissed row
        await store.record_failure(
            installation_id=1,
            system="github",
            ticket_ref="o/r#mark-ok",
            error_kind="not_found",
            error_message="not found",
        )
        await store.dismiss(
            installation_id=1,
            system="github",
            ticket_ref="o/r#mark-ok",
            dismissed_by="auth0|admin",
        )
        row = await store.get(1, "github", "o/r#mark-ok")
        assert row["status"] == "dismissed"

        # Cron sees a successful re-check
        await store.mark_ok(installation_id=1, system="github", ticket_ref="o/r#mark-ok")
        row = await store.get(1, "github", "o/r#mark-ok")
        # Status MUST remain dismissed — operator-driven state is sticky
        assert row["status"] == "dismissed"
        assert row["dismissed_by"] == "auth0|admin"


# ---------------------------------------------------------------------------
# mark_ok recovery
# ---------------------------------------------------------------------------


@skip_no_db
class TestMarkOkRecovery:
    async def test_mark_ok_clears_broken_atomically(self, store):
        """Successful re-check after a broken streak resets counter to 0
        AND flips status to 'ok'."""
        for _ in range(3):
            await store.record_failure(
                installation_id=1,
                system="github",
                ticket_ref="o/r#recover",
                error_kind="not_found",
                error_message="not found",
            )
        row = await store.get(1, "github", "o/r#recover")
        assert row["status"] == "broken"
        assert row["consecutive_failures"] == 3

        await store.mark_ok(installation_id=1, system="github", ticket_ref="o/r#recover")
        row = await store.get(1, "github", "o/r#recover")
        assert row["status"] == "ok"
        assert row["consecutive_failures"] == 0
        assert row["last_error_kind"] is None
        assert row["first_failure_at"] is None
        assert row["last_recheck_at"] is None
