"""Tests for startup observability hardening (C1+C2+I1 from PR review).

These tests verify the three behaviours added to make config-drift bugs
visible at startup:

- C1: Python logging is actually configured (not silently dropped at the
  default WARNING root level).
- C2: A missing SLACK_BOT_TOKEN/SLACK_SIGNING_SECRET in production raises
  a startup error rather than silently degrading to /slack/events 503s.
- I1: SlackAlerter being disabled in production warns loudly so a future
  on-call can see SRE alerting is offline.
"""

from __future__ import annotations

import logging
from unittest.mock import patch


class TestLoggingConfiguration:
    def test_canon_logger_emits_info_messages(self, caplog):
        """canon.main configures basicConfig so logger.info() reaches handlers.

        Regression: before PR for C1, every logger.info('Slack bot mounted...')
        and similar startup line was silently dropped because the root logger
        defaulted to WARNING.
        """
        # Importing canon.main has the side effect of running basicConfig at
        # module load, which is exactly the behaviour we want to assert.
        import canon.main  # noqa: F401

        canon_logger = logging.getLogger("canon.test_basic_config")
        with caplog.at_level(logging.INFO, logger="canon.test_basic_config"):
            canon_logger.info("startup-line-should-be-visible")

        assert any("startup-line-should-be-visible" in r.message for r in caplog.records), (
            "logger.info() messages must reach handlers — basicConfig was "
            "missing before C1, which silently dropped every startup log"
        )

    def test_noisy_third_party_loggers_clamped_to_warning(self):
        """httpx/httpcore/asyncpg/urllib3/slack_bolt should not spam INFO logs."""
        import canon.main  # noqa: F401  (triggers config)

        for name in ("httpx", "httpcore", "asyncpg", "urllib3", "slack_bolt"):
            assert logging.getLogger(name).level >= logging.WARNING, (
                f"{name} logger should be clamped to WARNING+ to avoid noise"
            )


class TestSlackStartupHardFail:
    """C2: Production must hard-fail when slack bot is unconfigured.

    These tests exercise the conditional inside the lifespan's else branch
    in src/canon/main.py without running the full lifespan (which would
    require a live FastAPI app + DB). We verify the logic by reading the
    relevant source and asserting the behaviour is in place. A full
    end-to-end test would require integration test infrastructure that
    doesn't currently exist for the lifespan.
    """

    def test_production_environment_with_empty_slack_token_raises_at_startup(
        self,
    ):
        """The else branch must raise RuntimeError in production."""
        from canon.settings import Settings

        # Simulate production with empty slack tokens
        with patch.dict(
            "os.environ",
            {
                "ENVIRONMENT": "production",
                "SLACK_BOT_TOKEN": "",
                "SLACK_SIGNING_SECRET": "",
            },
            clear=False,
        ):
            settings = Settings()
            assert settings.environment == "production"
            assert settings.slack_bot_enabled is False

        # Inspect the source to verify the hard-fail conditional is in place.
        # This is a structural test — if someone removes the conditional, this
        # test fails and forces them to think about the implication.
        from pathlib import Path

        main_py = Path("src/canon/main.py").read_text()
        assert 'settings.environment == "production"' in main_py, (
            "Production hard-fail conditional missing from main.py — "
            "without it, missing slack tokens silently degrade to 503s"
        )
        assert "refusing to start in production" in main_py, (
            "Production hard-fail RuntimeError message missing from main.py"
        )

    def test_non_production_environment_does_not_raise(self):
        """Dev/FOSS/self-hosted keep the soft fall-through."""
        from canon.settings import Settings

        with patch.dict(
            "os.environ",
            {
                "ENVIRONMENT": "development",
                "SLACK_BOT_TOKEN": "",
                "SLACK_SIGNING_SECRET": "",
            },
            clear=False,
        ):
            settings = Settings()
            assert settings.environment == "development"
            assert settings.slack_bot_enabled is False
            # Non-production must NOT take the raise branch.

        from pathlib import Path

        main_py = Path("src/canon/main.py").read_text()
        # The else branch must still log the warning + emit telemetry for
        # non-production observability
        assert "slack_bot_disabled_at_startup" in main_py, (
            "Non-production must emit a PostHog event for the disabled-at-"
            "startup case so dashboards can detect skipped notifications"
        )


class TestSlackAlerterSymmetricLogging:
    """I1: SlackAlerter being silently disabled in production is the worst-case
    observability failure (no way to alert that alerts are broken)."""

    def test_warning_logged_when_alerter_disabled_in_production(self):
        """The else branch in the SlackAlerter init must log a warning."""
        from pathlib import Path

        main_py = Path("src/canon/main.py").read_text()
        # Verify the symmetric warning is in place
        assert "SlackAlerter disabled" in main_py, (
            "I1: missing the symmetric warning for SlackAlerter being disabled in production"
        )
        assert "SRE alerting is offline" in main_py, (
            "I1: warning message should call out the consequence (SRE "
            "alerting offline) so the on-call has actionable context"
        )
