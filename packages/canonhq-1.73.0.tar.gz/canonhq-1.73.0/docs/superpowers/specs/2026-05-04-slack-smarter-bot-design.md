# Slack Smarter Bot — Sub-Project A Design

Make `@canon` aware of ongoing work — PRs, commits, tickets, Slack discussion, prior agent analysis — not just specs. Ship in one PR alongside the in-flight personal DM context (`slack-product-experience.md` §3.4) and Slack telemetry (`slack-product-experience.md` §10).

## Background

Today's `@canon` mention handler in `extensions/canon-slack/src/canon_slack/mentions.py` loads up to 5 relevant specs via `SpecLoader.search()` and passes them to Claude. It's spec-aware but unaware of the work surrounding those specs — open PRs, recent commits, related tickets, prior agent analyses, and Slack discussion the user could see anyway.

The user-described enhancement is "just chatting with @canon on Slack and discussing work that is happening and context around it to inform." This spec turns the bot from a spec-context responder into a work-context responder while keeping the existing fast paths intact.

This design also captures the in-flight work from `slack-product-experience.md` §3.4 (Personalized DM Context) and §10 (Telemetry) because they ship together — the coordinator built here is the natural injection point for both.

## Goals

- `@canon` answers questions about ongoing work using GitHub PRs/commits, tickets, the user's Slack threads, and Canon's own spec/PR-analysis data
- DM-only personal context (owned specs, team coverage, follow/mute) is injected when the user is identity-linked
- All slack-side actions emit PostHog telemetry so we can measure adoption and §9 phase validation
- The architecture supports a future tool-using agent mode without a refactor

## Non-Goals

- Tool-using agent mode (Approach 3) is **deferred to v2** — the stub interface ships in v1 so adding it later is a drop-in
- No retries, circuit breakers, or per-source resilience plumbing in v1 — telemetry will tell us what's needed
- No cross-channel Slack search beyond the asking user's channels — privacy-conservative default
- No per-user permission filtering for GitHub/tickets — org-scoped only, matching Canon's web UI posture
- No streamed-token UX in the answer — progressive `:thought_balloon:` updates only

---

## Locked-in design decisions (from brainstorming)

| Decision | Choice | Reasoning |
|---|---|---|
| Data sources | GitHub PRs + GitHub commits + tickets (Linear/Jira/GH Issues) + user's Slack channels + Canon spec data + Canon PR-analysis data | Most comprehensive — matches Canon's "broad context" product story |
| Trigger model | Intent-based (lookup → fast path; discussion/investigation → coordinator; default for unclassified → discussion) | Existing fast paths preserved; full context only when warranted |
| Slack thread scope | Current thread + channels the asking user is a member of | Matches user's mental model of Slack visibility; no cross-team leakage |
| GitHub/ticket scope | Org-scoped (Canon org boundary, no per-user filtering) | Matches Canon web UI posture; avoids per-PR permission API calls |
| Recency window | Hybrid — 7d for "what's happening" intents, 90d for "why did" intents, mixed for unclassified | Different question shapes need different windows |
| Per-source caps | Yes — top N per source after recency window, ranked by relevance × recency | Bounds token budget |
| Latency UX | Progressive `:thought_balloon:` updates as sources complete | Cheap to add; signals bot is alive |

---

## 1. Architecture

```
                       @canon mention / DM
                              │
                              ▼
                   mentions.handle_mention()
                              │
                              ▼
                  IntentClassifier.classify(query)
                              │
              ┌───────────────┼────────────────┐
              ▼               ▼                ▼
        lookup intent   discussion intent   investigation intent
        (existing       (NEW: deterministic   (NEW: agent mode —
         shortcuts)      mode)                 v2; falls back to
              │              │                 deterministic for now)
              │              ▼
              │       WorkContextCoordinator
              │              │
              │              ├─ runs in parallel:
              │              │   GitHubPRSource
              │              │   GitHubCommitSource
              │              │   TicketSource (Linear/Jira/GH Issues)
              │              │   SlackThreadSource
              │              │   CanonSpecSource
              │              │   CanonPRAnalysisSource
              │              │
              │              ├─ applies per-source caps + recency
              │              ├─ emits progressive :thought_balloon: updates
              │              └─ assembles ContextBundle
              │                     │
              ▼                     ▼
        SpecLoader            ClaudeClient.complete()
        (today's path)              │
              │                     ▼
              └────────────────► Slack response
                                  + telemetry events
```

**New module tree** under `extensions/canon-slack/src/canon_slack/work_context/`:

```
work_context/
  __init__.py
  coordinator.py          # parallel fetch + ranking + token budget + progress UI
  intent.py               # regex-first classifier with LLM fallback
  agent.py                # v2 agent stub; v1 delegates to coordinator
  models.py               # WorkContextItem, ContextBundle, RecencyProfile
  ranking.py              # cross-source relevance × recency × source-weight
  sources/
    __init__.py
    base.py               # WorkContextSource Protocol
    github_prs.py
    github_commits.py
    tickets.py
    slack_threads.py
    canon_specs.py
    canon_pr_analysis.py
```

**Modified files / new top-level modules** in `extensions/canon-slack/src/canon_slack/`:
- `mentions.py` — handler shrinks; assembles personal context (when DM), calls `WorkContextCoordinator.load()`, no inline spec loading
- `identity_store.py` — adds methods for personal context resolution (owned specs, team)
- New `personal_context.py` (sibling to `mentions.py`) — `build_personal_context(user_id, org_id) -> PersonalContext | None`. Pure function: returns personal context block if user is identity-linked, else None. Coordinator-agnostic.
- New `prompt_store.py` (sibling to `mentions.py`) — tracks "have we sent the link-your-identity nudge to this user already" via `slack_dm_prompts` table

---

## 2. Components

### `work_context/sources/base.py`

```python
class WorkContextItem(BaseModel):
    source: str           # "github_pr", "linear_ticket", etc.
    title: str
    summary: str          # 1-3 sentence summary, ranking-ready
    url: str              # original-system link
    timestamp: datetime
    relevance_score: float = 0.0  # set by ranker, 0-1
    metadata: dict[str, Any] = {}

class WorkContextSource(Protocol):
    name: str
    def enabled_for_org(org_id: str) -> bool: ...
    async def fetch(query: str, recency_days: int, cap: int) -> list[WorkContextItem]: ...
```

Each source self-reports its name (used in telemetry props), checks if it's available for the org (e.g., `LinearTicketSource` returns False if Linear isn't connected), and returns a capped list. Failures inside `fetch` are caught at the source boundary and reported via `WorkContextItem` metadata when partial; complete failures return `[]`.

### Concrete loaders

| File | What it pulls | Underlying API | Default cap |
|---|---|---|---|
| `github_prs.py` | Open + recently merged PRs in org-mapped repos matching query keywords | `GitHubClient` (existing) | 10 |
| `github_commits.py` | Commits to default branch in last N days touching files matching keywords | `GitHubClient` | 10 |
| `tickets.py` | Tickets from connected adapters matching keywords or related specs | Existing sync adapters (`canon.sync.adapters`) | 10 |
| `slack_threads.py` | Messages from user's channels matching keywords | Slack `users.conversations` + `search.messages` | 15 |
| `canon_specs.py` | Specs matching query — wraps existing `SpecLoader.search()` | `SpecLoader` | 5 |
| `canon_pr_analysis.py` | Recent PR analysis summaries the agent has produced for matching specs | DB / spec store | 5 |

### `work_context/intent.py`

```python
class Intent(StrEnum):
    LOOKUP = "lookup"          # existing shortcuts: status, list, coverage, my_specs
    DISCUSSION = "discussion"  # "what's happening with X" — full work context
    INVESTIGATION = "investigation"  # "why did X take so long" — agent mode (v2)

class RecencyProfile(StrEnum):
    RECENT = "recent"          # 7d
    HISTORICAL = "historical"  # 90d
    MIXED = "mixed"            # 7d for messages, 90d for PRs/tickets/specs

def classify(query: str) -> tuple[Intent, RecencyProfile, float]:
    """Returns (intent, recency_profile, confidence)."""
```

**v1 implementation:**
- Regex-first for `LOOKUP` (extends today's `_INTENT_STATUS`, `_INTENT_LIST_STATUS`, `_INTENT_COVERAGE` patterns plus new `_INTENT_MY_SPECS`, `_INTENT_MY_TEAM`)
- For everything else, a small Claude call with ~200-token classification prompt (claude-haiku, low temp) returning `{intent, recency_profile, confidence}` as JSON
- ~500ms added latency when LLM-classify path is taken (vs 0ms for regex hit) — acceptable within the existing 8-15s overall budget

### `work_context/coordinator.py`

```python
class WorkContextCoordinator:
    async def load(
        query: str,
        org_id: str,
        intent: Intent,
        recency: RecencyProfile,
        personal_context: PersonalContext | None = None,
        progress_callback: Callable[[str], Awaitable[None]] | None = None,
    ) -> ContextBundle: ...
```

Responsibilities (in order):
1. Determine which sources to enable for this org via `enabled_for_org`
2. Run all enabled sources via `asyncio.gather(return_exceptions=True)` with per-source 5s timeout
3. As each source completes, fire `progress_callback(status_string)` and emit `work_context_source_fetched` telemetry
4. Apply cross-source ranking via `ranking.score_items()` — `relevance_score = recency_weight × keyword_overlap × source_weight`
5. Truncate to fit token budget (~6K tokens reserved for work context)
6. Build `ContextBundle` with grouped sections — when `personal_context is not None`, prepend it as the first section with high-priority slot
7. Emit `work_context_assembled` telemetry with totals (including `personal_context_injected` derived from parameter)

The coordinator does NOT look up identity itself. The caller (`mentions.py`) assembles personal context via `personal_context.build_personal_context(user_id, org_id)` and passes the result in. This keeps the coordinator focused on source orchestration and avoids coupling it to identity resolution.

### `work_context/agent.py` (stub for v2)

```python
class WorkContextAgent:
    """Tool-using agent mode. v1 delegates to deterministic coordinator."""
    async def investigate(query: str, ...) -> ContextBundle:
        # v1: log telemetry that agent mode was requested,
        # then delegate to WorkContextCoordinator.load(...)
        # v2: actual tool-calling loop using the same loaders
```

Exists so v1 codepaths reference it consistently — making v2 a one-file replacement rather than a refactor.

### `mentions.py` changes

The existing `handle_mention` and `handle_dm` shrink:
- Lines 211-218 (current: load spec context, call NL processor) → replaced with `coordinator.load(...)` then `_process_nl_query(query, thread_history, bundle.format_for_claude())`
- DM-specific personal context (§3.4) is handled inside the coordinator, not in `mentions.py`
- Existing `:thought_balloon:` thinking message becomes the progress target for `progress_callback`

---

## 3. Data Flow

### Trace A: Channel mention with discussion intent

User in `#eng-platform`: `@canon what's going on with the auth-hardening work?`

```
T+0ms     Bolt receives app_mention event → mentions.handle_mention()
T+5ms     extract_query() strips @canon → "what's going on with the auth-hardening work?"
T+5ms     RateLimiter.check(user_id) → ok
T+10ms    intent.classify(query)
            - regex match → no LOOKUP shortcut
            - LLM classifier called (small claude-haiku call, low temp)
T+450ms   classified: (DISCUSSION, RECENT, confidence=0.87)
            - track("work_context_intent_classified", {intent, confidence, classifier="llm"})
T+450ms   client.reactions_add(eyes)
T+460ms   chat.postMessage(":thought_balloon: Thinking...")  → thinking_ts
T+465ms   personal_context = None  # channel mention, not DM — skip identity lookup entirely
T+470ms   coordinator.load(query, org_id, DISCUSSION, RECENT, personal_context=None, progress_callback=...)

          # In coordinator:
T+475ms   asyncio.gather(
            github_prs.fetch(query, recency_days=7, cap=10),       ──┐
            github_commits.fetch(query, recency_days=7, cap=10),   ──┤
            tickets.fetch(query, recency_days=7, cap=10),          ──┤  parallel
            slack_threads.fetch(query, recency_days=7, cap=15),    ──┤
            canon_specs.fetch(query, recency_days=7, cap=5),       ──┤
            canon_pr_analysis.fetch(query, recency_days=7, cap=5), ──┘
          )

T+800ms   canon_specs returns 3 items → progress_callback("specs ✓")
                                      → chat.update(thinking_ts, ":thought_balloon: specs ✓ — loading PRs, tickets, threads...")
T+1.1s    canon_pr_analysis returns 1 item → progress_callback("specs ✓ analysis ✓")
T+1.4s    github_prs returns 4 items → progress_callback("specs ✓ analysis ✓ PRs ✓")
T+1.8s    tickets returns 6 items → progress_callback adds "tickets ✓"
T+2.1s    github_commits returns 12 items → progress_callback adds "commits ✓"
T+2.6s    slack_threads returns 8 items → progress_callback adds "threads ✓"
T+2.6s    track("work_context_source_fetched", ...) × 6 with success/duration/items per source
T+2.6s    rank items: relevance_score = recency_weight × keyword_overlap × source_weight
T+2.65s   apply token budget: top 28 items totalling ~5.8K tokens
T+2.7s    bundle.format_for_claude() → grouped sections
T+2.7s    track("work_context_assembled", {sources_succeeded, total_items, total_tokens})

          # Back in mentions:
T+2.7s    chat.update(thinking_ts, ":thought_balloon: thinking with full context...")
T+2.7s    _process_nl_query(query, thread_history, bundle) → claude.complete(...)
T+11.4s   Claude returns response
T+11.5s   chat.update(thinking_ts, response)
T+11.5s   reactions: eyes → white_check_mark
T+11.5s   track("slack_mention_handled", {intent="discussion", personal_context_injected=false, claude_called=true, success=true, duration_ms=11500})
```

Total: ~11.5s end-to-end. ~3s of that is context loading (parallel-bound by slowest source), ~8s is the Claude call.

### Trace B: DM with lookup intent (existing fast path, with new telemetry)

User DMs the bot: `status of auth-hardening`

```
T+0ms     handle_dm → handle_mention (channel_type="im")
T+5ms     extract_query → "status of auth-hardening"
T+10ms    intent.classify → regex hit on _INTENT_STATUS → (LOOKUP, RECENT, 1.0)
T+10ms    track("work_context_intent_classified", {intent="lookup", confidence=1.0, classifier="regex"})
T+15ms    Existing _try_intent_shortcut path — direct SpecLoader.get_by_slug("auth-hardening")
T+250ms   format spec status response
T+260ms   say(text=response, thread_ts=...)
T+270ms   reactions: zap (no eyes/checkmark dance for fast path)
T+270ms   track("slack_mention_handled", {intent="lookup", personal_context_injected=false, claude_called=false, rate_limited=false, success=true, duration_ms=270})
```

Total: ~270ms. Coordinator is bypassed — lookup intent never enters the work-context flow.

### Trace C: DM with discussion intent (personal context path)

User DMs the bot: `what should I work on?`

```
T+10ms    intent.classify → no LOOKUP regex hit; LLM classifier called
T+450ms   classified: (DISCUSSION, RECENT, 0.91)
T+460ms   chat.postMessage(":thought_balloon: Thinking...")  → thinking_ts

          # mentions.py assembles personal context BEFORE coordinator call
T+465ms   personal_context = await build_personal_context(user_id, org_id)
            - IdentityStore.get_github_login(user_id) → "ngerner"
            - Load owned specs (frontmatter owner=ngerner), team, follow/mute state
            - Returns PersonalContext object (~500 tokens)
T+540ms   coordinator.load(query, org_id, DISCUSSION, RECENT, personal_context=pc, progress_callback=...)

          # If get_github_login returns None (unlinked):
T+475ms   personal_context = None
T+480ms   prompt_store.has_been_prompted(workspace_id, user_id, "link_identity") → False
T+490ms   client.chat_postEphemeral(... "💡 link your GitHub via /canon link <username> for personalized answers")
T+540ms   prompt_store.mark_prompted(workspace_id, user_id, "link_identity")
T+545ms   coordinator.load(... personal_context=None ...)
          # On next unlinked-DM mention, the prompt is skipped (has_been_prompted=True)
```

Personal context costs ~500 tokens (small) but its content (owned specs) gets a relevance boost in the ranking step, which makes those specs more likely to land in the final bundle.

---

## 4. Error Handling

Failure principle: **a slow or partial answer is always better than no answer.** Every failure mode degrades to "answer with what we got" rather than crashing.

### Per-source failures

Every loader's `fetch()` is wrapped by the coordinator in `try/except + asyncio.wait_for(timeout=5s)`.

| Failure | Loader behavior | Coordinator behavior | User sees |
|---|---|---|---|
| GitHub 5xx / rate limit | log warning, return `[]` | source counted as 0 items | Answer based on remaining sources; progress shows "PRs ✗" |
| Linear / Jira not connected | `enabled_for_org()` returns False | source skipped entirely | No mention of the source |
| Slack `search.messages` 429 | log, return `[]`, mark `slack_unavailable` in metadata | source counted as 0 | "threads ✗" in progress; bundle excludes thread section |
| Source timeout (5s default) | `asyncio.wait_for` raises `TimeoutError` | source counted as 0, telemetry records `timeout=true` | "PRs ✗ (slow)" in progress |
| Source returns malformed data | Pydantic validation error in `WorkContextItem`, item dropped | item-level skip, source returns valid items only | Bundle slightly smaller; not surfaced to user |

Telemetry for every fetch: `work_context_source_fetched` with `success`, `error_type`, `duration_ms`, `items_returned`.

### Coordinator failures

| Failure | Behavior |
|---|---|
| All sources return `[]` | Bundle is empty. Claude prompt explicitly says "no specific work context found." Claude answers based on conversation alone. Honest low-quality answer. Track `work_context_assembled` with `total_items=0`. |
| Token budget exceeded after capping | Hard-truncate lowest-ranked items until under budget. Log warning event so we can tune caps. |
| `asyncio.gather` itself fails (rare) | Top-level catch in `coordinator.load`; return empty bundle, log error event, let mentions.py continue |
| Progress callback fails (Slack `chat.update` errored) | Wrapped in `contextlib.suppress(Exception)` — never blocks fetch flow. The `eyes` reaction is the persistent "bot is processing" signal. |

### Intent classifier failures

| Failure | Behavior |
|---|---|
| Regex doesn't match (normal case) | Fall through to LLM classifier |
| LLM classifier API call fails | Default to `(DISCUSSION, MIXED, confidence=0.0)` — safest fallback (loads everything, no investigation mode) |
| LLM returns malformed JSON | Same as API failure — default to discussion intent |
| LLM classifier exceeds 1s soft timeout | Cancel the classifier task, default to discussion intent. Telemetry `intent_classifier_timeout=true`. |

### Identity / personal context failures

| Failure | Behavior |
|---|---|
| `IdentityStore.get_github_login` raises | Treat user as unlinked. No personal context. No prompt to user (avoid spam). Log debug. |
| User unlinked (returns None) | Skip personal context block. **First time per user (per workspace):** post one-time ephemeral prompt suggesting `/canon link <github-username>`. State stored in `slack_dm_prompts` table (see Section 9, item 2) to prevent repeat prompts. Failure to post the prompt is itself swallowed. |
| User linked but owner-spec lookup fails | Fall back to identity-only block (login + team if known); skip owned-specs section. |

### Claude API failures (work context generation)

Existing pattern in `mentions.py:235-243` is preserved:
- Rate limit / 5xx → update thinking message to `:x: I couldn't answer that right now. Please try again later.`
- `eyes` reaction removed (no checkmark)
- `track("slack_mention_handled", {success=false, error_type="claude_api"})`
- Stack trace logged via `logger.error(... exc_info=True)`

### Slack-side edge cases

| Edge case | Behavior |
|---|---|
| User edits mention message before bot responds | Bot answers the original text. (Slack `message_changed` events not handled.) |
| User deletes mention before bot responds | Bot's response posts anyway. (Future enhancement — not v1.) |
| User mentions bot multiple times rapidly | Rate limiter (`mentions.py:50`) returns 429-style ephemeral. Each mention is independent — no de-duplication. |
| Channel archived during processing | Final `chat.update` fails silently. Progress + answer lost. Rare, not handled specially. |
| Bot lacks `channels:history` scope on a user channel during slack_threads fetch | Source's per-channel try/except catches it, channel skipped, telemetry records `auth_error_count`. |

### What we explicitly do NOT do in v1

- **No retries on source failures** — best-effort; retry would compound latency budget. Telemetry will tell us if any source has failure rate worth retrying.
- **No circuit breaker per source** — premature optimization. Add if telemetry shows persistent failures.
- **No user-visible "this answer is degraded" warning** — progress UI `✗` marks are sufficient signal.
- **No agent mode** — `WorkContextAgent.investigate()` exists as a stub that delegates to deterministic mode. Investigation-classified queries get the same treatment as discussion-classified ones in v1, with telemetry to track frequency for v2 sizing.

---

## 5. Testing

Aligned with the existing test layout (`tests/` mirrors `src/`, with `tests/integration/`, `tests/scenarios/`, and `tests/mocks/wiremock/`).

### Unit tests — one per loader

`tests/extensions/canon-slack/work_context/sources/`:

| Test file | What it covers |
|---|---|
| `test_github_prs.py` | PR keyword matching, recency window enforcement, cap enforcement, empty result, GitHub API error → `[]`, malformed PR → dropped, repos-not-installed → `enabled_for_org` False |
| `test_github_commits.py` | File-path matching, default-branch filter, recency window, cap, error paths |
| `test_tickets.py` | Multi-adapter fanout, per-adapter failure isolation, ticket→spec relevance scoring |
| `test_slack_threads.py` | User's-channels-only filter (mocking `users.conversations`), keyword search, mute/private channel skip, search API rate limit → `[]` |
| `test_canon_specs.py` | Wraps existing `SpecLoader.search()` — thin adapter test |
| `test_canon_pr_analysis.py` | DB query for recent analyses, joins to spec metadata |

Each loader test uses **WireMock fixtures** (existing `tests/mocks/wiremock/` pattern) for external APIs. No real network calls in unit tests.

### Coordinator tests

`tests/extensions/canon-slack/work_context/test_coordinator.py`:

- All sources succeed → bundle assembly correct, items ranked
- One source fails → bundle excludes that source, telemetry fired with `success=false`
- All sources fail → empty bundle, Claude prompt notes "no work context"
- Token budget exceeded → lowest-ranked items dropped first
- Progress callback fires per-source completion in order of completion (controlled via `asyncio.sleep`)
- Progress callback failure doesn't abort the load
- DM channel + linked user → personal context block included
- DM channel + unlinked user → first-time prompt sent, second time silent
- Channel mention → no personal context regardless of identity link state
- 5s per-source timeout enforced

### Intent classifier tests

`tests/extensions/canon-slack/work_context/test_intent.py`:

- Regex hits for all existing LOOKUP patterns return high confidence + lookup intent (no LLM call)
- New regexes (`_INTENT_MY_SPECS`, `_INTENT_MY_TEAM`) hit correctly
- LLM classifier called for non-regex queries; mock the Claude response
- Malformed JSON from LLM → defaults to (DISCUSSION, MIXED, 0.0)
- LLM call timeout → defaults to (DISCUSSION, MIXED, 0.0) within 1s
- **Eval set** (separate file): ~50 hand-labeled queries with expected intent. Run as part of unit tests with a 90% accuracy threshold gate. Real (recorded) LLM responses, not live calls. Revise threshold based on initial run.

### Integration tests

`tests/integration/test_slack_work_context.py`:

End-to-end on a real FastAPI + Postgres + WireMock stack:

- `@canon` mention with discussion query → coordinator runs against WireMock'd APIs, Claude is mocked, full Slack response posted to a mock workspace
- DM with `/canon link <username>` → personal context appears on next mention
- DM by unlinked user → one-time prompt appears, second mention has no prompt
- Channel mention with no LOOKUP regex hit → LLM classifier called, intent recorded in telemetry capture
- All Slack telemetry events emitted with expected properties (PostHog mock validates schema)

### Scenario test extension

`tests/scenarios/scenario_slack_smarter_bot.py` — Simulates a small org over a week:
- Day 1: User links GitHub identity via `/canon link`
- Day 2: User asks `@canon what's happening with auth-hardening` → coordinator pulls 3 PRs + 2 tickets + 1 thread, Claude summarizes
- Day 3: User DMs `what should I work on` → personal context loads owned specs, returns ranked list
- Day 4: A source fails (Linear webhook 500) → answer still posts, telemetry shows degraded
- Validates: §10 telemetry events fire with correct counts, intent classification is correct, no regressions in the existing slack scenario test

### Test fixtures

New under `tests/fixtures/work_context/`:
- `github_prs/sample_response.json` — 25 sample PRs across 3 repos with varied labels, dates, bodies
- `linear_tickets/sample_response.json` — 15 sample tickets with realistic states
- `slack_search/sample_response.json` — 30 sample messages across 5 channels with thread depths
- `intent_eval/queries.jsonl` — 50 labeled queries for classifier evaluation

### What we explicitly skip in v1 testing

- Live API tests — never. All external APIs mocked.
- Visual regression for the progress UI — Slack Block Kit doesn't lend itself to visual tests; manual smoke is sufficient.
- Load tests — premature; latency is bounded by per-source timeouts, not traffic.
- A/B testing infra — not needed; ship behind a feature flag (see Rollout).

---

## 6. Telemetry Event Catalog (extends `slack-product-experience.md` §10)

The 8 events spec'd in §10 are unchanged. This sub-project adds 3 events specific to work context:

### `work_context_intent_classified`
Fired by `IntentClassifier.classify()` for every mention/DM that reaches the classifier.
- `intent` (string): lookup, discussion, investigation
- `recency_profile` (string): recent, historical, mixed
- `confidence` (number, 0-1)
- `classifier` (string): regex, llm
- `duration_ms` (number)

### `work_context_source_fetched`
Fired by `WorkContextCoordinator` for every source attempt.
- `source` (string): github_pr, github_commit, ticket, slack_thread, canon_spec, canon_pr_analysis
- `success` (bool)
- `error_type` (string|null): timeout, api_error, auth_error, validation_error, null
- `duration_ms` (number)
- `items_returned` (number)
- `recency_days` (number)
- `cap` (number)

### `work_context_assembled`
Fired by `WorkContextCoordinator` once per top-level call.
- `sources_attempted` (number)
- `sources_succeeded` (number)
- `total_items_before_cap` (number)
- `total_items_after_cap` (number)
- `total_tokens` (number)
- `personal_context_injected` (bool)
- `intent` (string)
- `duration_ms` (number)

### Updates to existing §10 events

The `slack_mention_handled` event spec'd in §10 gains additional properties:
- `work_context_loaded` (bool): true when coordinator was invoked (any non-LOOKUP intent)
- `work_context_sources_succeeded` (number): pass-through from `work_context_assembled`

---

## 7. Rollout Plan

### Feature flag

Coordinator-driven path is gated by a single boolean in `CANON.yaml`:

```yaml
slack:
  work_context:
    enabled: false   # default false, ship enabled per-customer
```

When `enabled: false`, mentions.py uses today's behavior (spec context only via `SpecLoader.search`). When `enabled: true`, the coordinator runs and the new flow applies.

This lets us:
- Merge the PR without forcing immediate behavioral change
- Enable on Canon's own org first (dogfood)
- Expand to design partners after telemetry validates baseline performance
- Roll back instantly per customer if a regression appears

### Per-customer enablement sequence

1. **Internal (Canon's own canon org)** — Enable on merge. Dogfood for 1 week.
2. **2-3 design partner orgs** — Enable manually, monitor telemetry for 1 week each.
3. **Default `enabled: true`** — Flip the default in a separate PR after 2-3 weeks of clean telemetry from design partners.

### Validation criteria for default-on flip

- p95 end-to-end latency < 15s
- p95 source fetch latency < 4s
- `work_context_assembled.total_items > 0` for >80% of discussion-intent queries
- `slack_mention_handled.success=false` rate stays under existing baseline (~2%)
- Zero customer reports of cross-channel/cross-user data leakage

---

## 8. v2 Deferred Items

Captured here so they aren't lost; out of scope for the v1 PR.

- **Agent mode** — `WorkContextAgent.investigate()` graduates from stub to real tool-calling loop. Loaders already implement the `WorkContextSource` Protocol that the agent will use as tools.
- **Per-user permission filtering** for GitHub/tickets — adds Slack→GitHub identity check + per-PR collaborator check. Org-scoped is sufficient for v1 per Canon's existing posture.
- **Cross-channel discoverable context** (Approach 3 from Q3) — a `slack.work_context.discoverable_channels` allowlist letting orgs explicitly opt channels into broader discoverability.
- **Streamed answer tokens** (Question 6 Option C) — UX upgrade if Slack rate limits become tractable for token-streaming use cases.
- **Two-stage answer** (Question 6 Option D) — fast spec-only first response, then enriched update with work context.
- **Retry / circuit breaker per source** — add only if telemetry shows persistent failures from a single source.
- **Work context surfacing in proactive notifications** — when `NotificationDispatcher` posts a coverage regression alert, append "Recently active PRs in this area: …" using the same loaders.

---

## 9. Open Questions for Implementation Phase

These came up during design and should be resolved during the writing-plans step or early in implementation:

1. **Source weighting in ranking** — what `source_weight` values produce a good answer mix? Likely needs an empirical pass: ship with equal weights, tune based on which sources Claude cites in answers.
2. **Personal context one-time-prompt state storage** — new table (`slack_dm_prompts (workspace_id, user_id, prompt_type, sent_at)`) vs reusing the existing `slack_installations` row with a JSON column. Lean toward new table (simple shape).
3. **LLM classifier model choice** — claude-haiku is the default; verify it's fast enough (<500ms p95) and accurate enough on the eval set. Fall back to claude-sonnet if accuracy is too low.
4. **Intent eval set authorship** — who labels the 50 queries? Self-label first, then ask 1-2 design partners to relabel as a sanity check.
5. **Personal context tokens budget** — design says "~500 tokens." Need to validate by measuring real users with 5+ owned specs and 2+ teams. Adjust cap if it bleeds the work-context budget.
