# Broken ticket reference UI — design

**Status:** draft
**Author:** Nick Gerner (with Claude)
**Date:** 2026-05-04

## Problem

`reverse_sync` (the `canon-sync` cron, every 15 min) calls
`adapter.get_ticket_status(ticket_id)` for every spec section that has a
`ticket_link`. When the ticket no longer exists — deleted GitHub issue,
moved Jira ticket, revoked permission — the adapter raises an exception
and the section's error is appended to the cron's per-run total.

Today the cron has no memory of which refs are persistently broken, so
on each run it re-asks the ticket system about every dead ref. With
`sys.exit(1)` on `total_errors > 0` and `restartPolicy: OnFailure +
backoffLimit: 6`, a single cron run can replay the full ~300-call sync
up to 7 times — burning ~2,100 GitHub calls per cron run. Users have
no surface to discover or clean up the bad refs.

This spec covers the long-term fix: track broken refs in their own
table, surface them in the UI, give users one-click cleanup, and stop
the cron from re-checking refs we already know are dead.

## Goals

1. Stop the cron from re-checking durably-broken refs every 15 min.
2. Make broken refs visible in the dashboard and inline on the spec
   view so users can clean them up without grepping logs.
3. Provide low-friction actions: dismiss, force re-check, or open a
   doc PR to remove the bad reference.
4. Self-heal — if a ticket gets restored, the dashboard should reflect
   that without requiring user action.

## Non-goals

- Replacing the existing `sys.exit(1)` behaviour in the cron. Once
  broken refs are filtered out, per-section error counts in steady
  state drop to near-zero, and the residual issue (transient 5xx
  storms still triggering retries) is a smaller follow-up best handled
  separately.
- Redesigning the ticket adapter interface. We add a single
  `classify_exception` classmethod to `TicketAdapter`; everything else
  about the adapter contract is unchanged.
- Inline editing of broken refs (replacing one ticket-id with another).
  v1 only supports removing the ref entirely; replacing happens via
  the existing spec-edit flow.

## Decisions made during brainstorming

| # | Question                                              | Decision                                                                 |
|---|-------------------------------------------------------|--------------------------------------------------------------------------|
| 1 | What counts as "broken"?                              | 404 + 401 + 403 from the ticket system                                   |
| 2 | When do we flip the broken flag?                      | After 3 consecutive failures (≈ 30–45 min at the */15 cadence)           |
| 3 | Per-section row or per-ticket row?                    | Per-ticket sidecar table — multiple sections referencing the same ticket share state and the cron deduplicates calls |
| 4 | Where does it surface?                                | Inline badge on `SpecView` + dashboard panel on `DashboardView` (skip the per-spec banner) |
| 5 | What does the cron do once a ref is broken?           | Skip every cycle except a daily 24 h re-check that auto-clears on success |
| 6 | What can the user do?                                 | Flag + dismiss + auto-PR-to-remove (full polish)                         |

## Architecture

```
canon-sync (every 15 min)
  └─ for each section with ticket_link:
       ├─ check ticket_ref_status row
       │    ├─ broken & last_recheck_at < 24h ago  → SKIP, no adapter call
       │    ├─ broken & last_recheck_at ≥ 24h     → re-check; on OK, mark_ok
       │    └─ ok                                  → call get_ticket_status
       └─ on exception:
            ├─ classify(exc) ∈ {not_found, forbidden, unauthorized}
            │     → record_failure (increments counter; flips status at 3)
            └─ otherwise (5xx, timeout, network)
                 → log; do not mutate the row

web/services
  ├─ get_org_overview         → joins ticket_ref_status,
  │                            populates RepoSummary.broken_refs_count
  │                            and OrgOverview.total_broken_refs
  └─ get_spec_detail          → adds SpecDetail.broken_sections

frontend
  ├─ DashboardView.vue        → BrokenRefsPanel below the repo list
  │                            (v-if dashboard.total_broken_refs > 0)
  ├─ SpecView.vue             → BrokenRefBadge inline next to broken refs
  └─ RemoveTicketRefModal     → confirms before opening the doc PR
```

Three layers, no cycles:

- **DB layer** — `TicketRefStatusStore` (mirrors `ContentCacheStore`,
  `IntegrationStore`).
- **Engine layer** — `reverse_sync` consults the store before calling
  the adapter; classifies exceptions; updates the store.
- **API + UI** — read-only join for display; mutating endpoints for
  dismiss / re-check / remove.

## Schema

New migration `0015_ticket_ref_status.py`:

```sql
CREATE TABLE ticket_ref_status (
    id              BIGSERIAL PRIMARY KEY,
    installation_id BIGINT NOT NULL,
    system          TEXT   NOT NULL,        -- 'jira' | 'linear' | 'github'

    -- Fully-qualified ticket reference. Format depends on system:
    --   github : 'org/repo#123'
    --   jira   : 'PROJ-123'
    --   linear : 'TEAM-123'
    -- Always assembled via canon.sync.ticket_ref.qualify(system, repo,
    -- ticket_id) so callers don't have to remember which systems need
    -- the repo prefix.
    ticket_ref      TEXT   NOT NULL,

    status               TEXT   NOT NULL DEFAULT 'ok',
                                            -- 'ok' | 'broken' | 'dismissed'
    consecutive_failures INT   NOT NULL DEFAULT 0,
    last_error_kind      TEXT,              -- 'not_found' | 'forbidden' | 'unauthorized'
    last_error_message   TEXT,              -- truncated, for the dashboard tooltip

    first_failure_at TIMESTAMPTZ,           -- set on the first failure that began a 'broken' streak; cleared by mark_ok
    last_check_at    TIMESTAMPTZ,           -- bumped on every adapter call (success or failure)
    last_recheck_at  TIMESTAMPTZ,           -- bumped ONLY when due_for_recheck() forced a 24h re-check; used to gate the next one
    dismissed_at     TIMESTAMPTZ,
    dismissed_by     TEXT,                  -- jwt.sub of the dismissing user

    UNIQUE (installation_id, system, ticket_ref)
);

CREATE INDEX ticket_ref_status_broken_idx
    ON ticket_ref_status (installation_id, status)
    WHERE status IN ('broken', 'dismissed');

CREATE INDEX ticket_ref_status_recheck_idx
    ON ticket_ref_status (status, last_recheck_at)
    WHERE status = 'broken';
```

Notes:

- **`dismissed` is a status, not a separate flag.** The cron treats
  `broken` and `dismissed` identically (skip). The UI distinguishes
  them so dismissed refs are visually muted and don't appear in the
  "needs attention" count.
- **No FK to `spec_sections` / `spec_documents`.** Ticket-id is
  independent of which sections cite it; sections come and go via
  spec edits, but the ticket's broken-ness is durable.
- **`installation_id` keying** matches `repo_configs` and
  `repo_sync_state`. The repo prefix lives inside `ticket_ref` for
  GitHub; Jira/Linear ticket IDs already encode the project.

## Detection (in `canon/sync/engine.py::reverse_sync`)

Two new modules support the engine changes:

### `canon/sync/ticket_ref.py`

```python
def qualify(system: str, repo: str | None, ticket_id: str) -> str:
    """Build the fully-qualified ticket_ref used as the
    ticket_ref_status key.

    GitHub issues are repo-scoped, so #123 in org/repo-a and
    org/repo-b are different tickets and need different rows.
    Jira/Linear ticket IDs already encode the project so the repo is
    irrelevant.
    """
    if system == "github":
        if not repo:
            raise ValueError("repo is required for github ticket refs")
        return f"{repo}#{ticket_id.lstrip('#')}"
    return ticket_id


def due_for_recheck(row) -> bool:
    """True iff status == 'broken' and the 24h re-check window has
    elapsed. Dismissed rows are never re-checked automatically."""
    if row.status != "broken":
        return False
    if row.last_recheck_at is None:
        return True
    return (datetime.now(UTC) - row.last_recheck_at) >= timedelta(hours=24)
```

### `canon/sync/ticket_error.py`

```python
ErrorKind = Literal["not_found", "forbidden", "unauthorized", "transient"]

def classify_error(exc: Exception) -> ErrorKind:
    """Map an adapter exception to an error_kind.

    Adapters can override via TicketAdapter.classify_exception(exc);
    the default classifier handles httpx.HTTPStatusError generically.
    """
    if isinstance(exc, httpx.HTTPStatusError):
        code = exc.response.status_code
        if code == 404: return "not_found"
        if code == 403: return "forbidden"
        if code == 401: return "unauthorized"
    return "transient"
```

`TicketAdapter` gets a single new optional classmethod:

```python
@classmethod
def classify_exception(cls, exc: Exception) -> ErrorKind | None:
    """Override to add system-specific exception types
    (Linear's GraphQL NotFoundError, Jira's domain errors, etc.).
    Return None to fall through to the default classifier."""
    return None
```

### Engine changes

The per-section block in `reverse_sync` (currently around lines
845–888) becomes:

```python
ticket_ref = qualify(section.ticket_link.system, repo,
                     section.ticket_link.ticket_id)
ref_row = await ref_store.get(installation_id,
                              section.ticket_link.system, ticket_ref)

if ref_row and ref_row.status in ("broken", "dismissed"):
    if not due_for_recheck(ref_row):
        continue  # cron skips entirely

try:
    ticket_status = await adapter.get_ticket_status(
        section.ticket_link.ticket_id
    )
    if ref_row and ref_row.status == "broken":
        await ref_store.mark_ok(installation_id,
                                section.ticket_link.system, ticket_ref)
    # … existing status_changed / updates logic unchanged …
except Exception as err:
    kind = (adapter.classify_exception(err)
            or classify_error(err))
    if kind in ("not_found", "forbidden", "unauthorized"):
        await ref_store.record_failure(
            installation_id, section.ticket_link.system,
            ticket_ref, kind, str(err)
        )
    result.errors.append(
        SyncError(section_id=section.id, error=str(err))
    )
```

Threshold: `record_failure` is `INSERT … ON CONFLICT DO UPDATE`,
incrementing `consecutive_failures` and flipping `status` to
`'broken'` once the counter hits 3. `mark_ok` resets the counter to
0 and sets `status='ok'`. Dismissed rows are NOT touched by `mark_ok`.

## API surface

Read endpoints (existing, augmented):

| Endpoint                                 | Change                                                                 |
|------------------------------------------|------------------------------------------------------------------------|
| `GET /{org}/api/dashboard`               | `OrgOverview` gains `total_broken_refs` and per-repo `broken_refs_count` |
| `GET /{org}/api/specs/{owner}/{repo}/{file_path}` | `SpecDetail` gains `broken_sections: list[BrokenRef]`                  |

Read endpoints (new):

| Endpoint                                 | Purpose                                                                 |
|------------------------------------------|-------------------------------------------------------------------------|
| `GET /{org}/api/broken-refs?status=broken&system=&repo=&limit=50&offset=0` | Paginated cross-spec list for the dashboard panel        |
| `GET /{org}/api/broken-refs/count`       | Cheap count for navbar badge polling                                    |

Mutating endpoints (new, all gated on `Permission.SPECS_WRITE`):

```
POST /{org}/api/broken-refs/dismiss
     body: { system, ticket_ref }
       → status = 'dismissed', dismissed_by = jwt.sub, dismissed_at = now()

POST /{org}/api/broken-refs/recheck
     body: { system, ticket_ref }
       → clears last_recheck_at; next cron run forces a fresh check

POST /{org}/api/specs/{owner}/{repo}/{file_path:path}/sections/{section_id}/remove-ticket-ref
       → opens a doc PR via client.create_doc_pr that deletes the
         `Ticket: …` line from that section
       → returns { pr_url, pr_number }
       → 409 with the existing pr_url if a PR for this section already exists
       → 410 if the section has been re-pointed since the last sync
```

`BrokenRef` Pydantic model in `web/models.py`:

```python
class BrokenRef(BaseModel):
    system: Literal["jira", "linear", "github"]
    ticket_ref: str
    spec_path: str            # repo + file_path, for navigation
    section_id: str
    section_heading: str
    error_kind: Literal["not_found", "forbidden", "unauthorized"]
    first_failure_at: datetime
    last_check_at: datetime
    dismissed: bool
    dismissed_by: str | None
```

## UI / Vue

Three new components:

- **`frontend/src/components/BrokenRefBadge.vue`** — small red `BROKEN`
  chip rendered inline next to a section's ticket reference. Click
  toggles a popover with: error kind, first-failed / last-checked
  timestamps, and stacked `Remove ref (opens PR)` / `Dismiss` /
  `Re-check now` buttons.

- **`frontend/src/components/BrokenRefsPanel.vue`** — dashboard panel.
  Paginated table (default 10 rows, "View all" expands), filters by
  system and status (Active / Dismissed), per-row Remove / Dismiss
  buttons. Click row navigates to
  `/spec/{owner}/{repo}/{file_path}#{section_id}` (uses the existing
  scroll-to-section anchor in `SpecView`).

- **`frontend/src/components/RemoveTicketRefModal.vue`** —
  confirmation modal. Body: "This opens a PR removing line N from
  spec X. Continue?". On confirm, POST `remove-ticket-ref`; on
  success show toast with PR link; on 409 show toast with the
  existing PR link.

Edits to existing views:

- **`SpecView.vue`** — when `spec_detail.broken_sections` is non-empty,
  the section renderer mounts a `<BrokenRefBadge>` next to any section
  whose `section_id` matches.
- **`DashboardView.vue`** — `<BrokenRefsPanel>` below the repo list,
  guarded by `v-if="dashboard.total_broken_refs > 0"` so healthy orgs
  don't see an empty panel. Top-of-dashboard metric chips include a
  `⚠ N broken refs` chip when the count is non-zero.

State management stays consistent with the existing pattern (no
Vuex/Pinia for this domain; each component fetches via the existing
`useApi` helper; refetch after mutation; no realtime/websockets).

## Error handling

**Inside the cron (`reverse_sync`):**
- `ref_store.get()` raises → log warning, treat as `row=None`, fall
  through to the adapter call. Same fail-open principle as the
  content cache fix in PR #663 — the broken-ref store going down
  must never abort the cron.
- `ref_store.record_failure()` / `mark_ok()` raises → log warning,
  continue. We lose the increment for this run but don't crash.
- `qualify()` raises (`github` ref with no repo) → log error, count
  as a section error, continue. This is a programming bug, not a
  runtime issue.

**API endpoints:**
- `dismiss` / `recheck` on a non-existent row → 404 with a clear
  message. Only the cron creates rows.
- `remove-ticket-ref` collisions: branch
  `canon-bot/remove-ref-{section_id}` already has an open PR → 409
  with the existing pr_url; UI shows "There's already an open PR to
  remove this ref → {link}".
- `remove-ticket-ref` on a re-pointed section → re-parse the spec at
  request time; if the section's `ticket_link.ticket_id` no longer
  matches the broken `ticket_ref`, return 410 Gone with "this section
  was already updated, refresh the dashboard".

**`create_doc_pr` failures:**
- GitHub 5xx / network → 502 from the endpoint, no row written.
- GitHub auth (App installation revoked) → existing
  `InstallationNotFound` propagates; surfaces as 502.

**Idempotency:**
- `record_failure` is `INSERT … ON CONFLICT DO UPDATE`. Concurrent
  cron retries can't create duplicates.
- `mark_ok` is also upsert; safe to call repeatedly.
- `dismiss` is a no-op when the row is already `dismissed`.

## Testing

Five layers, mirroring the existing test layout:

**Unit (pure):**
- `tests/test_sync/test_ticket_ref.py` — `qualify` per system, error
  cases, `due_for_recheck` truth table.
- `tests/test_sync/test_ticket_error.py` — `classify_error` per
  status code, generic exception fall-through, adapter override
  precedence.

**Store (asyncpg with the existing `pgtest` fixture):**
- `tests/test_db/test_ticket_ref_status_store.py` — round-trip
  insert/get/mark_ok/record_failure/dismiss; UNIQUE constraint
  enforcement; the two indexes get hit by the queries the API uses
  (verify with EXPLAIN).

**Engine (with the existing `mock_adapter` pattern):**
- `tests/test_sync/test_engine_broken_refs.py` —
  - 3 consecutive 404s → row flips to `broken`
  - 1 success after broken → cleared to `ok`
  - dismissed → cron skips, no adapter call
  - 5xx during recovery → counter doesn't increment
  - re-check after 24h reopens the call

**Routes (FastAPI TestClient):**
- `tests/test_web/test_broken_refs_routes.py` — happy path +
  permission checks + 404/409/410 cases for each new endpoint.
- The dashboard-augmentation tests live alongside the existing
  `test_routes.py::TestDashboard` so the response-shape change is
  covered there too.

**Frontend (Vitest, existing pattern under
`frontend/src/components/__tests__/`):**
- `BrokenRefBadge.spec.ts` — renders only when broken, popover
  toggles, action callbacks fire.
- `BrokenRefsPanel.spec.ts` — renders rows, filters mutate query
  params, paging.
- `RemoveTicketRefModal.spec.ts` — confirm calls API, error toasts
  on 409.

**One integration test:**
- `tests/integration/test_broken_refs_e2e.py` — starts the FastAPI
  app + Postgres + WireMock for GitHub, simulates 3 cron cycles with
  a failing ticket, asserts the dashboard endpoint shows the broken
  ref and the cron stops calling GitHub for it on cycle 4.

## Rollout

1. Land the migration, store, and engine changes behind no flag —
   the feature is "we now write rows when refs fail". Pre-existing
   `broken` rows accumulate immediately on the next cron cycle.
2. Land the read endpoints + dashboard panel + inline badge. As soon
   as this deploys, users see the existing 178 broken refs in the
   dashboard.
3. Land the mutating endpoints (`dismiss`, `recheck`,
   `remove-ticket-ref`) and the modal.

Each step is independently shippable and a strong candidate for its
own implementation plan. The engine change in step 1 by itself
eliminates the rate-limit waste (no more 178 errors per run);
steps 2 and 3 add the UX. If we ship step 1 alone for now, broken
refs stop being a rate-limit problem even before the UI lands.

The web routes resolve `installation_id` from the URL `{org}` via
the existing `_get_client_for_org(request, org)` helper used by
every other read endpoint — no new auth/registry plumbing required.

## Open questions / follow-ups

- The `sys.exit(1)` issue (Option A from earlier brainstorming) is
  not addressed here; it becomes lower-priority once broken refs
  filter out, but should still be cleaned up in a separate PR.
- Notification when a ref auto-heals (24h re-check returns OK) — not
  in v1, but worth considering if users find it surprising that
  flags disappear without action.
- Bulk operations on the dashboard panel (dismiss-all, remove-all)
  — explicitly out of scope for v1 since 178 is a one-time backlog
  and steady-state volume is unknown.
