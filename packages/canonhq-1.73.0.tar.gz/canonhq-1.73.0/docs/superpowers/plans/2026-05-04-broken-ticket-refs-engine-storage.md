# Broken Ticket Refs §2 — Engine & Storage Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Eliminate the GitHub rate-limit waste from `canon-sync` re-checking dead ticket refs every 15 min by writing rows to a new `ticket_ref_status` table on classified failures and skipping known-broken refs in `reverse_sync`.

**Architecture:** A per-ticket sidecar table tracks `(installation_id, system, ticket_ref) → status`. The cron consults the store before calling each adapter; classified errors (404/401/403) flip the row to `broken` after 3 consecutive failures; successful re-checks clear `broken`. Store failures fail-open (cron continues, just no skip benefit). No web routes or UI in this slice — those are §3 and §4.

**Tech Stack:** Python 3.12, FastAPI, asyncpg, Pydantic v2, Alembic, pytest-asyncio, ruff. Branch: `spec/broken-ticket-refs-ui` (already has the spec commit).

---

## File Structure

**New files (5):**
- `src/canon/db/migrations/versions/0015_ticket_ref_status.py` — Alembic migration; one table + two partial indexes.
- `src/canon/db/ticket_ref_status_store.py` — async data-access layer; mirrors `ContentCacheStore` shape.
- `src/canon/sync/ticket_ref.py` — pure helpers: `qualify(system, repo, ticket_id)` and `due_for_recheck(row)`.
- `src/canon/sync/ticket_error.py` — pure helper: `classify_error(exc)` and the `ErrorKind` literal.
- `tests/test_db/test_ticket_ref_status_store.py` — store unit tests using mock asyncpg pool.
- `tests/test_sync/test_ticket_ref.py` — `qualify` + `due_for_recheck` unit tests.
- `tests/test_sync/test_ticket_error.py` — `classify_error` unit tests.
- `tests/test_sync/test_engine_broken_refs.py` — engine-integration tests using existing `MockAdapter`.

**Modified files (2):**
- `src/canon/sync/engine.py` — extend `reverse_sync` signature with `installation_id` and `ref_store`; add skip + record logic in the per-section block (around line 845).
- `src/canon/cron/sync_status.py` — instantiate `TicketRefStatusStore` from the existing pool, pass into `reverse_sync` along with `installation_id`.

**Why this layout:** the helpers (`ticket_ref.py`, `ticket_error.py`) are pure-function modules that have no DB or HTTP dependencies — easy to unit-test, easy to reason about, and reusable by §3/§4 (web routes will need `qualify` to look up rows by `ticket_link`). The store mirrors the existing per-domain store pattern (`ContentCacheStore`, `IntegrationStore`) for codebase consistency.

---

## Task 1: Migration — create `ticket_ref_status` table

**Files:**
- Create: `src/canon/db/migrations/versions/0015_ticket_ref_status.py`
- Test: `tests/test_db/test_migrations.py` (existing — verify it still passes)

- [ ] **Step 1: Write the migration**

```python
"""Track persistently-broken ticket references so the canon-sync cron
stops re-checking dead refs every 15 min and the dashboard can surface
them for cleanup.

Revision ID: 0015
Revises: 0014
"""

from __future__ import annotations

from alembic import op

revision: str = "0015"
down_revision: str = "0014"
branch_labels: str | None = None
depends_on: str | None = None


def upgrade() -> None:
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS ticket_ref_status (
            id              BIGSERIAL PRIMARY KEY,
            installation_id BIGINT NOT NULL,
            system          TEXT   NOT NULL,
            ticket_ref      TEXT   NOT NULL,
            status                 TEXT NOT NULL DEFAULT 'ok',
            consecutive_failures   INT  NOT NULL DEFAULT 0,
            last_error_kind        TEXT,
            last_error_message     TEXT,
            first_failure_at TIMESTAMPTZ,
            last_check_at    TIMESTAMPTZ,
            last_recheck_at  TIMESTAMPTZ,
            dismissed_at     TIMESTAMPTZ,
            dismissed_by     TEXT,
            UNIQUE (installation_id, system, ticket_ref)
        )
        """
    )
    op.execute(
        """
        CREATE INDEX IF NOT EXISTS ticket_ref_status_broken_idx
            ON ticket_ref_status (installation_id, status)
            WHERE status IN ('broken', 'dismissed')
        """
    )
    op.execute(
        """
        CREATE INDEX IF NOT EXISTS ticket_ref_status_recheck_idx
            ON ticket_ref_status (status, last_recheck_at)
            WHERE status = 'broken'
        """
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS ticket_ref_status")
```

- [ ] **Step 2: Verify migration discovery still works**

Run: `uv run pytest tests/test_db/test_migrations.py -v`
Expected: PASS — the migration is picked up; the test that walks `down_revision` chain finds 0015 → 0014 → 0013 etc.

- [ ] **Step 3: Sanity-check the SQL renders without syntax errors**

Run: `uv run python -c "from canon.db.migrations.versions import _0015_ticket_ref_status as m; m.upgrade.__code__"`
Expected: no error (module importable).

(Note: file name `0015_ticket_ref_status.py` is imported as a module; the leading-digit rule means Python imports it as `_0015_ticket_ref_status`. Confirm by `import importlib.util; importlib.util.find_spec(...)` if the dash-import convention varies.)

- [ ] **Step 4: Commit**

```bash
git add src/canon/db/migrations/versions/0015_ticket_ref_status.py
git commit -m "feat(db): add ticket_ref_status table (migration 0015)

Per-ticket sidecar table for tracking persistently-broken ticket refs.
Sets up storage for the broken-refs UI feature; no app code reads or
writes the table yet — that arrives in subsequent tasks."
```

---

## Task 2: Pure helpers — `ticket_ref.py`

**Files:**
- Create: `src/canon/sync/ticket_ref.py`
- Test: `tests/test_sync/test_ticket_ref.py`

- [ ] **Step 1: Write the failing tests**

```python
"""Tests for canon.sync.ticket_ref helpers."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from types import SimpleNamespace

import pytest

from canon.sync.ticket_ref import due_for_recheck, qualify


class TestQualify:
    def test_github_prefixes_repo(self):
        assert qualify("github", "canonhq/canon", "123") == "canonhq/canon#123"

    def test_github_strips_leading_hash(self):
        assert qualify("github", "canonhq/canon", "#123") == "canonhq/canon#123"

    def test_jira_returns_id_unchanged(self):
        assert qualify("jira", "canonhq/canon", "PROJ-7") == "PROJ-7"

    def test_linear_returns_id_unchanged(self):
        assert qualify("linear", "any/repo", "TEAM-9") == "TEAM-9"

    def test_jira_ignores_repo(self):
        # Jira IDs are globally unique within a tenant; repo doesn't matter
        assert qualify("jira", "", "PROJ-7") == "PROJ-7"

    def test_github_requires_repo(self):
        with pytest.raises(ValueError, match="repo is required"):
            qualify("github", "", "123")

    def test_github_requires_repo_when_none(self):
        with pytest.raises(ValueError, match="repo is required"):
            qualify("github", None, "123")


class TestDueForRecheck:
    def _row(self, status: str, last_recheck_at: datetime | None) -> SimpleNamespace:
        return SimpleNamespace(status=status, last_recheck_at=last_recheck_at)

    def test_ok_status_never_due(self):
        # 'ok' rows are checked every cycle by the regular cron path,
        # not the 24h re-check path
        assert due_for_recheck(self._row("ok", None)) is False

    def test_dismissed_never_due(self):
        # Dismissed rows are sticky — only user action clears them
        assert due_for_recheck(self._row("dismissed", None)) is False
        old = datetime.now(UTC) - timedelta(days=30)
        assert due_for_recheck(self._row("dismissed", old)) is False

    def test_broken_never_rechecked_is_due(self):
        assert due_for_recheck(self._row("broken", None)) is True

    def test_broken_recently_rechecked_not_due(self):
        recent = datetime.now(UTC) - timedelta(hours=23)
        assert due_for_recheck(self._row("broken", recent)) is False

    def test_broken_24h_old_recheck_is_due(self):
        old = datetime.now(UTC) - timedelta(hours=24, minutes=1)
        assert due_for_recheck(self._row("broken", old)) is True
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_sync/test_ticket_ref.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'canon.sync.ticket_ref'`

- [ ] **Step 3: Write the implementation**

Create `src/canon/sync/ticket_ref.py`:

```python
"""Helpers for working with qualified ticket references.

A ``ticket_ref`` is the fully-qualified identifier used as the key into
``ticket_ref_status``. GitHub issues are repo-scoped (#123 in
``org/repo-a`` is a different ticket than #123 in ``org/repo-b``), so
the ref includes the repo prefix. Jira/Linear IDs already encode the
project so the repo is irrelevant.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Protocol

# 24h between forced re-checks of a 'broken' ref. Conservative — costs
# one adapter call per broken ref per day to detect auto-healing
# (e.g. a re-opened issue).
RECHECK_INTERVAL = timedelta(hours=24)


class _RowLike(Protocol):
    status: str
    last_recheck_at: datetime | None


def qualify(system: str, repo: str | None, ticket_id: str) -> str:
    """Build the fully-qualified ticket_ref used as the
    ``ticket_ref_status`` key.

    Format depends on system:
      github : ``org/repo#123``
      jira   : ``PROJ-123``
      linear : ``TEAM-123``
    """
    if system == "github":
        if not repo:
            raise ValueError("repo is required for github ticket refs")
        return f"{repo}#{ticket_id.lstrip('#')}"
    return ticket_id


def due_for_recheck(row: _RowLike) -> bool:
    """Return True iff a 'broken' row's 24h re-check window has elapsed.

    'ok' rows go through the regular check path. 'dismissed' rows are
    sticky — only explicit user action clears them.
    """
    if row.status != "broken":
        return False
    if row.last_recheck_at is None:
        return True
    return (datetime.now(UTC) - row.last_recheck_at) >= RECHECK_INTERVAL
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_sync/test_ticket_ref.py -v`
Expected: PASS — all 11 tests green.

- [ ] **Step 5: Lint + format**

Run: `uv run ruff check src/canon/sync/ticket_ref.py tests/test_sync/test_ticket_ref.py && uv run ruff format src/canon/sync/ticket_ref.py tests/test_sync/test_ticket_ref.py`
Expected: `All checks passed!`

- [ ] **Step 6: Commit**

```bash
git add src/canon/sync/ticket_ref.py tests/test_sync/test_ticket_ref.py
git commit -m "feat(sync): add qualify() and due_for_recheck() helpers

Pure helpers for the broken-refs feature. qualify() builds the
fully-qualified ticket_ref used as the ticket_ref_status key (handles
the github-needs-repo-prefix case). due_for_recheck() gates the 24h
forced re-check of broken rows."
```

---

## Task 3: Pure helper — `ticket_error.py`

**Files:**
- Create: `src/canon/sync/ticket_error.py`
- Test: `tests/test_sync/test_ticket_error.py`

- [ ] **Step 1: Write the failing tests**

```python
"""Tests for canon.sync.ticket_error.classify_error."""

from __future__ import annotations

import httpx

from canon.sync.ticket_error import classify_error


def _http_error(status_code: int) -> httpx.HTTPStatusError:
    request = httpx.Request("GET", "https://example.com/x")
    response = httpx.Response(status_code, request=request)
    return httpx.HTTPStatusError(f"{status_code}", request=request, response=response)


class TestClassifyError:
    def test_404_is_not_found(self):
        assert classify_error(_http_error(404)) == "not_found"

    def test_401_is_unauthorized(self):
        assert classify_error(_http_error(401)) == "unauthorized"

    def test_403_is_forbidden(self):
        assert classify_error(_http_error(403)) == "forbidden"

    def test_500_is_transient(self):
        assert classify_error(_http_error(500)) == "transient"

    def test_503_is_transient(self):
        assert classify_error(_http_error(503)) == "transient"

    def test_429_is_transient(self):
        # Rate-limited is recoverable on retry, not durable broken
        assert classify_error(_http_error(429)) == "transient"

    def test_timeout_is_transient(self):
        request = httpx.Request("GET", "https://example.com/x")
        assert classify_error(httpx.ReadTimeout("timed out", request=request)) == "transient"

    def test_generic_exception_is_transient(self):
        assert classify_error(RuntimeError("something else")) == "transient"

    def test_value_error_is_transient(self):
        # Programming bugs surface as transient — engine still appends
        # them to result.errors so they're not silently lost
        assert classify_error(ValueError("boom")) == "transient"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_sync/test_ticket_error.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'canon.sync.ticket_error'`

- [ ] **Step 3: Write the implementation**

Create `src/canon/sync/ticket_error.py`:

```python
"""Classify ticket-adapter exceptions into broken-ref error kinds.

Used by reverse_sync to decide whether a per-section failure indicates
a durably-broken ticket reference (404/401/403) or a transient issue
(5xx, 429, timeout, network) that should not flip the broken flag.
"""

from __future__ import annotations

from typing import Literal

import httpx

ErrorKind = Literal["not_found", "forbidden", "unauthorized", "transient"]


def classify_error(exc: BaseException) -> ErrorKind:
    """Map an adapter exception to an error_kind.

    Only ``httpx.HTTPStatusError`` with status 404/401/403 maps to a
    durable broken state. Everything else — 5xx, 429 (rate-limited),
    timeouts, network errors, programming bugs — is ``transient`` so
    the broken flag never trips on a recoverable issue.
    """
    if isinstance(exc, httpx.HTTPStatusError):
        code = exc.response.status_code
        if code == 404:
            return "not_found"
        if code == 403:
            return "forbidden"
        if code == 401:
            return "unauthorized"
    return "transient"
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_sync/test_ticket_error.py -v`
Expected: PASS — all 9 tests green.

- [ ] **Step 5: Lint + format**

Run: `uv run ruff check src/canon/sync/ticket_error.py tests/test_sync/test_ticket_error.py && uv run ruff format src/canon/sync/ticket_error.py tests/test_sync/test_ticket_error.py`
Expected: `All checks passed!`

- [ ] **Step 6: Commit**

```bash
git add src/canon/sync/ticket_error.py tests/test_sync/test_ticket_error.py
git commit -m "feat(sync): add classify_error helper for ticket adapters

Maps httpx.HTTPStatusError 404/401/403 to durable broken kinds and
everything else (5xx, 429, timeout, network, programming bugs) to
'transient' so the broken flag never trips on a recoverable issue."
```

---

## Task 4: `TicketRefStatusStore` — async data access

**Files:**
- Create: `src/canon/db/ticket_ref_status_store.py`
- Test: `tests/test_db/test_ticket_ref_status_store.py`

- [ ] **Step 1: Write the failing tests**

```python
"""Unit tests for TicketRefStatusStore using mock asyncpg pool."""

from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock

import pytest

from canon.db.ticket_ref_status_store import TicketRefStatusStore


def _mock_pool_with_conn(mock_conn: AsyncMock) -> MagicMock:
    pool = MagicMock()

    @asynccontextmanager
    async def _acquire():
        yield mock_conn

    pool.acquire = _acquire
    pool.execute = AsyncMock()
    pool.fetch = AsyncMock(return_value=[])
    pool.fetchrow = AsyncMock(return_value=None)
    return pool


@pytest.fixture
def mock_conn():
    conn = AsyncMock()
    conn.transaction.return_value.__aenter__ = AsyncMock(return_value=AsyncMock())
    conn.transaction.return_value.__aexit__ = AsyncMock(return_value=False)
    return conn


@pytest.fixture
def mock_pool(mock_conn):
    return _mock_pool_with_conn(mock_conn)


@pytest.fixture
def store(mock_pool):
    return TicketRefStatusStore(mock_pool)


class TestGet:
    async def test_returns_none_when_row_missing(self, store, mock_pool):
        mock_pool.fetchrow.return_value = None
        assert await store.get(1, "github", "org/repo#1") is None

    async def test_returns_dict_when_row_exists(self, store, mock_pool):
        mock_pool.fetchrow.return_value = {
            "id": 7,
            "installation_id": 1,
            "system": "github",
            "ticket_ref": "org/repo#1",
            "status": "broken",
            "consecutive_failures": 3,
            "last_error_kind": "not_found",
            "last_error_message": "not found",
            "first_failure_at": datetime.now(UTC),
            "last_check_at": datetime.now(UTC),
            "last_recheck_at": None,
            "dismissed_at": None,
            "dismissed_by": None,
        }
        row = await store.get(1, "github", "org/repo#1")
        assert row is not None
        assert row["status"] == "broken"
        assert row["consecutive_failures"] == 3


class TestRecordFailure:
    async def test_first_failure_inserts_with_count_1(self, store, mock_pool):
        mock_pool.fetchrow.return_value = {"status": "ok", "consecutive_failures": 1}
        result = await store.record_failure(
            installation_id=1,
            system="github",
            ticket_ref="org/repo#1",
            error_kind="not_found",
            error_message="ticket #1 not found",
        )
        assert result["status"] == "ok"
        assert result["consecutive_failures"] == 1
        # Verify INSERT ... ON CONFLICT was used (single fetchrow with
        # the expected query shape)
        sql_used = mock_pool.fetchrow.await_args[0][0]
        assert "INSERT INTO ticket_ref_status" in sql_used
        assert "ON CONFLICT" in sql_used

    async def test_third_failure_flips_to_broken(self, store, mock_pool):
        # The store's own SQL handles the threshold; we verify the
        # returned shape exposes that state to callers
        mock_pool.fetchrow.return_value = {"status": "broken", "consecutive_failures": 3}
        result = await store.record_failure(
            installation_id=1,
            system="github",
            ticket_ref="org/repo#1",
            error_kind="not_found",
            error_message="not found",
        )
        assert result["status"] == "broken"


class TestMarkOk:
    async def test_clears_broken_to_ok(self, store, mock_pool):
        await store.mark_ok(installation_id=1, system="github", ticket_ref="org/repo#1")
        sql_used = mock_pool.execute.await_args[0][0]
        assert "INSERT INTO ticket_ref_status" in sql_used
        assert "ON CONFLICT" in sql_used
        # Ensure mark_ok never touches dismissed rows
        assert "WHERE ticket_ref_status.status <> 'dismissed'" in sql_used

    async def test_resets_failure_count(self, store, mock_pool):
        await store.mark_ok(installation_id=1, system="github", ticket_ref="org/repo#1")
        sql_used = mock_pool.execute.await_args[0][0]
        assert "consecutive_failures = 0" in sql_used


class TestDismiss:
    async def test_sets_dismissed_status_and_user(self, store, mock_pool):
        await store.dismiss(
            installation_id=1, system="github", ticket_ref="org/repo#1",
            dismissed_by="auth0|123",
        )
        sql_used = mock_pool.execute.await_args[0][0]
        assert "status = 'dismissed'" in sql_used
        assert "dismissed_by" in sql_used


class TestForceRecheck:
    async def test_clears_last_recheck_at(self, store, mock_pool):
        await store.force_recheck(installation_id=1, system="github", ticket_ref="org/repo#1")
        sql_used = mock_pool.execute.await_args[0][0]
        assert "last_recheck_at = NULL" in sql_used


class TestListBroken:
    async def test_returns_rows_for_installation(self, store, mock_pool):
        mock_pool.fetch.return_value = [
            {"installation_id": 1, "ticket_ref": "org/repo#1", "status": "broken"},
            {"installation_id": 1, "ticket_ref": "org/repo#2", "status": "broken"},
        ]
        rows = await store.list_broken(installation_id=1)
        assert len(rows) == 2

    async def test_filters_by_status(self, store, mock_pool):
        mock_pool.fetch.return_value = []
        await store.list_broken(installation_id=1, status="dismissed")
        sql_used = mock_pool.fetch.await_args[0][0]
        assert "status = $2" in sql_used
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_db/test_ticket_ref_status_store.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'canon.db.ticket_ref_status_store'`

- [ ] **Step 3: Write the store implementation**

Create `src/canon/db/ticket_ref_status_store.py`:

```python
"""Data access for ticket_ref_status — durable broken-ref tracking.

A row is keyed by (installation_id, system, ticket_ref) and represents
the live broken/dismissed/ok state for a single ticket reference. The
canon-sync cron consults this store before calling each adapter and
updates it on success or classified failure.
"""

from __future__ import annotations

import logging

import asyncpg

logger = logging.getLogger(__name__)

# Number of consecutive 404/401/403 responses before a ref is marked
# durably broken. Set in SQL, exposed here for tests + docs.
BROKEN_THRESHOLD = 3


class TicketRefStatusStore:
    """Async data access for ticket_ref_status."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def get(
        self, installation_id: int, system: str, ticket_ref: str
    ) -> dict | None:
        """Fetch the row for a single ticket ref, or None if it has
        never failed."""
        row = await self._pool.fetchrow(
            """
            SELECT id, installation_id, system, ticket_ref, status,
                   consecutive_failures, last_error_kind, last_error_message,
                   first_failure_at, last_check_at, last_recheck_at,
                   dismissed_at, dismissed_by
            FROM ticket_ref_status
            WHERE installation_id = $1 AND system = $2 AND ticket_ref = $3
            """,
            installation_id,
            system,
            ticket_ref,
        )
        return dict(row) if row else None

    async def record_failure(
        self,
        *,
        installation_id: int,
        system: str,
        ticket_ref: str,
        error_kind: str,
        error_message: str,
    ) -> dict:
        """Record a classified failure (not_found / forbidden /
        unauthorized).

        Increments consecutive_failures atomically; once it reaches
        BROKEN_THRESHOLD the row's status flips to 'broken'. Idempotent
        on repeat calls (driven by INSERT ... ON CONFLICT). Returns the
        post-update row state.

        ``last_recheck_at`` is set to ``now()`` so a re-check that
        immediately re-fails counts as the latest re-check timestamp —
        otherwise we'd re-check the same ref every cycle until it
        finally succeeds.
        """
        row = await self._pool.fetchrow(
            """
            INSERT INTO ticket_ref_status (
                installation_id, system, ticket_ref,
                status, consecutive_failures,
                last_error_kind, last_error_message,
                first_failure_at, last_check_at, last_recheck_at
            )
            VALUES ($1, $2, $3,
                    'ok', 1,
                    $4, $5,
                    now(), now(),
                    CASE WHEN 1 >= $6 THEN now() ELSE NULL END)
            ON CONFLICT (installation_id, system, ticket_ref) DO UPDATE SET
                consecutive_failures = ticket_ref_status.consecutive_failures + 1,
                status = CASE
                    WHEN ticket_ref_status.status = 'dismissed'
                        THEN 'dismissed'  -- never auto-flip dismissed back
                    WHEN ticket_ref_status.consecutive_failures + 1 >= $6
                        THEN 'broken'
                    ELSE ticket_ref_status.status
                END,
                last_error_kind = EXCLUDED.last_error_kind,
                last_error_message = EXCLUDED.last_error_message,
                first_failure_at = COALESCE(ticket_ref_status.first_failure_at, now()),
                last_check_at = now(),
                last_recheck_at = CASE
                    WHEN ticket_ref_status.status = 'broken' THEN now()
                    ELSE ticket_ref_status.last_recheck_at
                END
            RETURNING status, consecutive_failures
            """,
            installation_id,
            system,
            ticket_ref,
            error_kind,
            error_message,
            BROKEN_THRESHOLD,
        )
        return dict(row) if row else {}

    async def mark_ok(
        self, *, installation_id: int, system: str, ticket_ref: str
    ) -> None:
        """Clear a previously-broken ref back to 'ok'.

        Never touches dismissed rows — those are user-controlled and
        sticky. Idempotent: a no-op when the row is already 'ok' or
        absent (the upsert with WHERE NOT dismissed handles the absent
        case via INSERT and the already-ok case via UPDATE).
        """
        await self._pool.execute(
            """
            INSERT INTO ticket_ref_status (
                installation_id, system, ticket_ref,
                status, consecutive_failures, last_check_at
            )
            VALUES ($1, $2, $3, 'ok', 0, now())
            ON CONFLICT (installation_id, system, ticket_ref) DO UPDATE SET
                status = 'ok',
                consecutive_failures = 0,
                last_error_kind = NULL,
                last_error_message = NULL,
                first_failure_at = NULL,
                last_recheck_at = NULL,
                last_check_at = now()
            WHERE ticket_ref_status.status <> 'dismissed'
            """,
            installation_id,
            system,
            ticket_ref,
        )

    async def dismiss(
        self,
        *,
        installation_id: int,
        system: str,
        ticket_ref: str,
        dismissed_by: str,
    ) -> None:
        """Operator-driven 'I know, leave it' state. Cron skips the
        ref forever after this; only manual `mark_ok` or
        `force_recheck` clears it."""
        await self._pool.execute(
            """
            UPDATE ticket_ref_status
            SET status = 'dismissed',
                dismissed_at = now(),
                dismissed_by = $4
            WHERE installation_id = $1 AND system = $2 AND ticket_ref = $3
            """,
            installation_id,
            system,
            ticket_ref,
            dismissed_by,
        )

    async def force_recheck(
        self, *, installation_id: int, system: str, ticket_ref: str
    ) -> None:
        """Clear last_recheck_at so the next cron cycle re-checks a
        broken ref immediately instead of waiting for the 24h window."""
        await self._pool.execute(
            """
            UPDATE ticket_ref_status
            SET last_recheck_at = NULL
            WHERE installation_id = $1 AND system = $2 AND ticket_ref = $3
            """,
            installation_id,
            system,
            ticket_ref,
        )

    async def list_broken(
        self, *, installation_id: int, status: str = "broken"
    ) -> list[dict]:
        """List rows for the given installation, defaulting to broken.

        Used by the §3 dashboard endpoints. Pagination is handled at
        the route layer to keep the store API generic.
        """
        rows = await self._pool.fetch(
            """
            SELECT id, installation_id, system, ticket_ref, status,
                   consecutive_failures, last_error_kind, last_error_message,
                   first_failure_at, last_check_at, last_recheck_at,
                   dismissed_at, dismissed_by
            FROM ticket_ref_status
            WHERE installation_id = $1 AND status = $2
            ORDER BY first_failure_at DESC NULLS LAST
            """,
            installation_id,
            status,
        )
        return [dict(r) for r in rows]
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_db/test_ticket_ref_status_store.py -v`
Expected: PASS — all tests green. Note the `test_list_broken_filters_by_status` test asserts the SQL contains `status = $2`; if your final SQL uses a different placeholder number, adjust the assertion to match.

- [ ] **Step 5: Lint + format**

Run: `uv run ruff check src/canon/db/ticket_ref_status_store.py tests/test_db/test_ticket_ref_status_store.py && uv run ruff format src/canon/db/ticket_ref_status_store.py tests/test_db/test_ticket_ref_status_store.py`
Expected: `All checks passed!`

- [ ] **Step 6: Commit**

```bash
git add src/canon/db/ticket_ref_status_store.py tests/test_db/test_ticket_ref_status_store.py
git commit -m "feat(db): add TicketRefStatusStore

Async data-access layer for ticket_ref_status. Mirrors the
ContentCacheStore / IntegrationStore shape. record_failure() does the
3-strikes-flip-to-broken logic atomically in a single upsert.
mark_ok() never touches dismissed rows. dismiss() / force_recheck()
expose user-driven state changes for §4."
```

---

## Task 5: Wire `reverse_sync` into the broken-ref store

**Files:**
- Modify: `src/canon/sync/engine.py:804-902` (the `reverse_sync` function)
- Test: `tests/test_sync/test_engine_broken_refs.py`

- [ ] **Step 1: Write the failing tests**

```python
"""Engine-level tests for broken-ref skip + record behavior."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock

import httpx
import pytest

from canon.parser.parse import parse_spec
from canon.sync.engine import reverse_sync
from canon.sync.models import TicketStatusResult
from canon.parser.models import SectionStatus

# Existing MockAdapter pattern in tests/test_sync/test_engine.py
from tests.test_sync.test_engine import MockAdapter


# Minimal spec with one section pointing at a github ticket
_SPEC = """---
title: Broken ref test
status: in_progress
---

# Broken ref test

## §1 Has a ticket

<!-- canon:section:1 status:in_progress -->
<!-- canon:ticket:github:456 url:https://github.com/o/r/issues/456 -->

Body
"""


def _http_404() -> httpx.HTTPStatusError:
    request = httpx.Request("GET", "https://api.github.com/repos/o/r/issues/456")
    response = httpx.Response(404, request=request)
    return httpx.HTTPStatusError("404", request=request, response=response)


@pytest.fixture
def doc():
    return parse_spec(_SPEC).document


@pytest.fixture
def ref_store():
    """A minimal in-memory ref store stub matching the
    TicketRefStatusStore interface needed by reverse_sync."""

    rows: dict[tuple, dict] = {}

    store = AsyncMock()

    async def _get(installation_id, system, ticket_ref):
        return rows.get((installation_id, system, ticket_ref))

    async def _record_failure(*, installation_id, system, ticket_ref,
                              error_kind, error_message):
        key = (installation_id, system, ticket_ref)
        existing = rows.get(key, {"consecutive_failures": 0, "status": "ok"})
        existing["consecutive_failures"] = existing.get("consecutive_failures", 0) + 1
        if existing["consecutive_failures"] >= 3:
            existing["status"] = "broken"
        existing.update({
            "installation_id": installation_id,
            "system": system,
            "ticket_ref": ticket_ref,
            "last_error_kind": error_kind,
            "last_error_message": error_message,
            "first_failure_at": existing.get("first_failure_at") or datetime.now(UTC),
            "last_check_at": datetime.now(UTC),
            "last_recheck_at": (
                datetime.now(UTC) if existing["status"] == "broken" else None
            ),
        })
        rows[key] = existing
        return {"status": existing["status"], "consecutive_failures": existing["consecutive_failures"]}

    async def _mark_ok(*, installation_id, system, ticket_ref):
        key = (installation_id, system, ticket_ref)
        if key in rows and rows[key].get("status") != "dismissed":
            rows[key]["status"] = "ok"
            rows[key]["consecutive_failures"] = 0
            rows[key]["last_recheck_at"] = None

    store.get = AsyncMock(side_effect=_get)
    store.record_failure = AsyncMock(side_effect=_record_failure)
    store.mark_ok = AsyncMock(side_effect=_mark_ok)
    store._rows = rows
    return store


class TestThreeFailuresFlipToBroken:
    async def test_flip(self, doc, ref_store):
        adapter = MockAdapter(status_error=_http_404())
        for _ in range(3):
            await reverse_sync(
                doc, adapter,
                repo="o/r", installation_id=1, ref_store=ref_store,
            )
        key = (1, "github", "o/r#456")
        assert ref_store._rows[key]["status"] == "broken"
        assert ref_store._rows[key]["consecutive_failures"] == 3
        # Adapter was called all 3 times — store wasn't broken yet
        assert len(adapter.status_queries) == 3


class TestBrokenRefIsSkipped:
    async def test_skip(self, doc, ref_store):
        # Pre-populate as broken with a recent re-check timestamp
        recent = datetime.now(UTC) - timedelta(hours=1)
        ref_store._rows[(1, "github", "o/r#456")] = {
            "installation_id": 1, "system": "github", "ticket_ref": "o/r#456",
            "status": "broken", "consecutive_failures": 3,
            "last_recheck_at": recent,
        }
        adapter = MockAdapter(status_error=_http_404())
        result = await reverse_sync(
            doc, adapter,
            repo="o/r", installation_id=1, ref_store=ref_store,
        )
        # Adapter was NOT called — broken refs skip the call entirely
        assert adapter.status_queries == []
        # No new errors appended
        assert result[1].errors == []


class TestSuccessClearsBroken:
    async def test_clear(self, doc, ref_store):
        # Pre-populate as broken but with last_recheck_at >= 24h ago
        old = datetime.now(UTC) - timedelta(hours=25)
        ref_store._rows[(1, "github", "o/r#456")] = {
            "installation_id": 1, "system": "github", "ticket_ref": "o/r#456",
            "status": "broken", "consecutive_failures": 3,
            "last_recheck_at": old,
        }
        adapter = MockAdapter(
            status_result=TicketStatusResult(
                ticket_id="456",
                status=SectionStatus(state="done"),
                raw_status="closed",
            )
        )
        await reverse_sync(
            doc, adapter,
            repo="o/r", installation_id=1, ref_store=ref_store,
        )
        # Adapter WAS called — re-check was due
        assert len(adapter.status_queries) == 1
        # Row was cleared
        assert ref_store._rows[(1, "github", "o/r#456")]["status"] == "ok"


class TestDismissedRefIsSkipped:
    async def test_skip(self, doc, ref_store):
        old = datetime.now(UTC) - timedelta(days=30)
        ref_store._rows[(1, "github", "o/r#456")] = {
            "installation_id": 1, "system": "github", "ticket_ref": "o/r#456",
            "status": "dismissed", "consecutive_failures": 3,
            "last_recheck_at": old,
        }
        adapter = MockAdapter(status_error=_http_404())
        await reverse_sync(
            doc, adapter,
            repo="o/r", installation_id=1, ref_store=ref_store,
        )
        # Dismissed rows always skip — even if last_recheck_at is ancient
        assert adapter.status_queries == []


class TestTransientFailureDoesNotIncrement:
    async def test_500_no_increment(self, doc, ref_store):
        request = httpx.Request("GET", "https://example.com/x")
        err = httpx.HTTPStatusError(
            "500",
            request=request,
            response=httpx.Response(500, request=request),
        )
        adapter = MockAdapter(status_error=err)
        await reverse_sync(
            doc, adapter,
            repo="o/r", installation_id=1, ref_store=ref_store,
        )
        # No row written for transient errors
        assert (1, "github", "o/r#456") not in ref_store._rows


class TestStoreFailureFailsOpen:
    async def test_get_raises_does_not_abort(self, doc):
        # Store.get() raising must not bubble — cron continues with the
        # adapter call. We verify by setting up a store whose get()
        # raises and confirming the adapter is still called.
        store = AsyncMock()
        store.get = AsyncMock(side_effect=RuntimeError("db down"))
        store.record_failure = AsyncMock()
        store.mark_ok = AsyncMock()
        adapter = MockAdapter(
            status_result=TicketStatusResult(
                ticket_id="456",
                status=SectionStatus(state="done"),
                raw_status="closed",
            )
        )
        await reverse_sync(
            doc, adapter,
            repo="o/r", installation_id=1, ref_store=store,
        )
        assert len(adapter.status_queries) == 1
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_sync/test_engine_broken_refs.py -v`
Expected: FAIL — `reverse_sync` doesn't accept `installation_id` or `ref_store` kwargs yet.

- [ ] **Step 3: Modify `reverse_sync` signature and per-section block**

In `src/canon/sync/engine.py`:

(a) Add the imports near the top of the file, alongside the existing `from canon.sync.models import ...`:

```python
from canon.sync.ticket_error import classify_error
from canon.sync.ticket_ref import due_for_recheck, qualify
```

(b) Extend the `reverse_sync` signature (around line 804):

```python
async def reverse_sync(
    doc: SpecDocument,
    adapter: TicketAdapter,
    *,
    system_config: TicketSystemConfig | None = None,
    repo: str = "",
    org: str = "",
    sync_store: SyncHistoryStore | None = None,
    sync_trigger: str = "manual",
    installation_id: int | None = None,
    ref_store: object | None = None,
) -> tuple[str, SyncResult]:
```

The two new kwargs are typed loosely — `int | None` and `object | None` — so callers that don't have an installation_id or ref_store handy (existing tests, the CLI, the web sync route) keep working with no changes. Only the cron will pass real values.

(c) Replace the per-section block (currently around lines 845-888) with:

```python
_sync_failed = False
try:
    for section in all_sections:
        if not section.ticket_link or not section.section_number:
            continue

        # Broken-ref pre-check. Fail-open if the ref store is unavailable —
        # cron must NEVER abort because ticket_ref_status is unreachable.
        ticket_ref = None
        ref_row = None
        if ref_store is not None and installation_id is not None:
            try:
                ticket_ref = qualify(
                    section.ticket_link.system, repo, section.ticket_link.ticket_id
                )
                ref_row = await ref_store.get(
                    installation_id, section.ticket_link.system, ticket_ref
                )
            except Exception:
                logger.warning(
                    "ticket_ref_status read failed — falling through to adapter",
                    exc_info=True,
                )
                ref_row = None

            if ref_row and ref_row["status"] in ("broken", "dismissed"):
                if not due_for_recheck(_RowAdapter(ref_row)):
                    continue  # skip the adapter call entirely

        try:
            ticket_status = await adapter.get_ticket_status(section.ticket_link.ticket_id)

            # Use configurable status resolution when available
            if status_map_cfg and status_map_cfg.reverse:
                resolved = resolve_reverse(system, ticket_status.raw_status, status_map_cfg)
                new_state = resolved.state
            else:
                new_state = ticket_status.status.state

            if new_state != section.status.state:
                updates.append(
                    StatusUpdate(
                        section_number=section.section_number,
                        new_state=new_state,
                    )
                )
                result.status_changed.append(
                    SyncStatusChanged(
                        section_id=section.id,
                        ticket_id=section.ticket_link.ticket_id,
                        old_state=section.status.state,
                        new_state=new_state,
                    )
                )
                analytics.track(
                    "ticket_status_synced",
                    properties={
                        "repo": repo,
                        "spec_path": doc.file_path,
                        "section_id": section.id,
                        "ticket_id": section.ticket_link.ticket_id,
                        "old_state": section.status.state,
                        "new_state": new_state,
                        "ticket_system": system,
                    },
                    groups={"organization": org} if org else None,
                )

            # Successful re-check: clear any prior 'broken' (never touch dismissed)
            if (
                ref_store is not None
                and ticket_ref is not None
                and ref_row
                and ref_row["status"] == "broken"
            ):
                try:
                    await ref_store.mark_ok(
                        installation_id=installation_id,
                        system=section.ticket_link.system,
                        ticket_ref=ticket_ref,
                    )
                except Exception:
                    logger.warning(
                        "ticket_ref_status mark_ok failed", exc_info=True
                    )

        except Exception as err:
            # Classify the failure. Only durable kinds (404/401/403)
            # increment the broken counter; transient kinds fall through.
            if (
                ref_store is not None
                and ticket_ref is not None
            ):
                kind = classify_error(err)
                if kind in ("not_found", "forbidden", "unauthorized"):
                    try:
                        await ref_store.record_failure(
                            installation_id=installation_id,
                            system=section.ticket_link.system,
                            ticket_ref=ticket_ref,
                            error_kind=kind,
                            error_message=str(err),
                        )
                    except Exception:
                        logger.warning(
                            "ticket_ref_status record_failure failed",
                            exc_info=True,
                        )
            result.errors.append(SyncError(section_id=section.id, error=str(err)))

    markdown = update_status_comments(doc, updates) if updates else doc.raw
except Exception:
    _sync_failed = True
    raise
finally:
    if sync_store and run_id:
        if _sync_failed:
            result.errors.append(
                SyncError(section_id="__document__", error="Unhandled exception during sync")
            )
        await _persist_sync_result(sync_store, run_id, result)

return markdown, result
```

(d) Add a small adapter shim at module level so `due_for_recheck` (which expects attribute access) works against the dict the store returns:

```python
class _RowAdapter:
    """Wrap a dict row in attribute access for due_for_recheck."""
    def __init__(self, row: dict) -> None:
        self.status = row["status"]
        self.last_recheck_at = row.get("last_recheck_at")
```

Place this near the top of `engine.py` after the imports (private helper, no docstring beyond the existing ones).

- [ ] **Step 4: Run the new tests**

Run: `uv run pytest tests/test_sync/test_engine_broken_refs.py -v`
Expected: PASS — all 6 tests green.

- [ ] **Step 5: Run the full test suite to confirm no regressions**

Run: `uv run pytest -q --ignore=tests/integration --ignore=tests/scenarios`
Expected: 3,619 → 3,619+N passed (with N being the new tests added in Tasks 2-5). No failures.

- [ ] **Step 6: Lint + format**

Run: `uv run ruff check src/canon/sync/engine.py tests/test_sync/test_engine_broken_refs.py && uv run ruff format src/canon/sync/engine.py tests/test_sync/test_engine_broken_refs.py`
Expected: `All checks passed!`

- [ ] **Step 7: Commit**

```bash
git add src/canon/sync/engine.py tests/test_sync/test_engine_broken_refs.py
git commit -m "feat(sync): wire reverse_sync into ticket_ref_status

Per-section block now consults ref_store.get() before each adapter
call and skips broken/dismissed refs whose 24h re-check window hasn't
elapsed. Classified failures (404/401/403) call record_failure();
successful re-checks of broken rows call mark_ok(). Store failures
log and fall through to the adapter — cron must never abort because
ticket_ref_status is unreachable.

The new installation_id and ref_store kwargs default to None so
existing callers (web/sync_routes, cli/sync_cmd, tests) continue to
work unchanged. Only the cron passes real values."
```

---

## Task 6: Wire `TicketRefStatusStore` into the cron

**Files:**
- Modify: `src/canon/cron/sync_status.py:50-95` (pool init block) and around `:335` (the `reverse_sync` call site)

- [ ] **Step 1: Read the current pool-init block in sync_status.py**

Note the structure: it builds an asyncpg pool when `database_url` is set, instantiates `IntegrationStore` (gated on `byok_encryption_key`) and `ContentCacheStore`. We add `TicketRefStatusStore` from the same pool, no new gating needed.

- [ ] **Step 2: Modify the pool-init block to include TicketRefStatusStore**

Replace the existing `try` block (around lines 56-79):

```python
    integration_store = None
    content_cache_store = None
    ref_store = None
    pool = None
    if settings.database_url:
        try:
            import asyncpg

            from ..db.content_cache_store import ContentCacheStore
            from ..db.integration_store import IntegrationStore
            from ..db.ticket_ref_status_store import TicketRefStatusStore

            pool = await asyncpg.create_pool(settings.database_url, min_size=1, max_size=2)
            content_cache_store = ContentCacheStore(pool)
            ref_store = TicketRefStatusStore(pool)
            if settings.byok_encryption_key:
                integration_store = IntegrationStore(pool, settings.byok_encryption_key)
        except ImportError:
            logger.info("asyncpg not installed — skipping DB-backed stores for cron")
        except Exception:
            # Pool failure means the content-cache + broken-ref optimizations
            # silently disengage and we fan out to GitHub for every spec. That
            # is exactly the rate-limit burnout this cron is supposed to avoid,
            # so surface it as an error + analytics event for alerting.
            logger.error(
                "Failed to initialize DB-backed stores for cron job — "
                "spec content will be fetched from GitHub and DB OAuth creds skipped",
                exc_info=True,
            )
            analytics.track(
                "reverse_sync_db_pool_failed",
                properties={"installation_id": settings.gh_installation_id},
            )
```

- [ ] **Step 3: Modify the `reverse_sync` call site** (around line 335)

Find:

```python
                    updated_md, sync_result = await reverse_sync(
                        result.document, adapter, system_config=resolved_sys_config
                    )
```

Replace with:

```python
                    updated_md, sync_result = await reverse_sync(
                        result.document,
                        adapter,
                        system_config=resolved_sys_config,
                        repo=full_repo,
                        installation_id=int(settings.gh_installation_id) if settings.gh_installation_id else None,
                        ref_store=ref_store,
                    )
```

`full_repo` is already in scope at this point in the file (it's `f"{owner}/{repo_name}"` from earlier in the loop). Confirm before editing.

- [ ] **Step 4: Run targeted tests**

Run: `uv run pytest tests/test_cron/test_sync_status.py -v`
Expected: PASS — the existing tests don't assert on the new kwargs (they use a mock adapter and don't construct a ref_store).

- [ ] **Step 5: Run the full test suite**

Run: `uv run pytest -q --ignore=tests/integration --ignore=tests/scenarios`
Expected: All tests pass.

- [ ] **Step 6: Lint + format**

Run: `uv run ruff check src/canon/cron/sync_status.py && uv run ruff format src/canon/cron/sync_status.py`
Expected: `All checks passed!`

- [ ] **Step 7: Commit**

```bash
git add src/canon/cron/sync_status.py
git commit -m "feat(cron): wire TicketRefStatusStore into canon-sync

Instantiate the store from the existing asyncpg pool and pass it
into reverse_sync along with installation_id and the per-iteration
full_repo. Once deployed, classified ticket failures (404/401/403)
flip the row to 'broken' after 3 consecutive runs and the cron
stops re-checking dead refs every 15 min."
```

---

## Task 7: Push branch and open PR

- [ ] **Step 1: Push the branch**

```bash
git push -u origin spec/broken-ticket-refs-ui
```

- [ ] **Step 2: Open PR via gh**

```bash
gh pr create --title "feat: broken-ref tracking (§2 — engine + storage)" --body "$(cat <<'EOF'
First slice of the broken-ticket-refs-ui spec
([\`docs/specs/broken-ticket-refs-ui.md\`](docs/specs/broken-ticket-refs-ui.md)).

## What this PR does

Adds the storage and engine plumbing so canon-sync stops re-checking
durably-broken ticket refs every 15 min. No web routes or UI yet —
those are §3 and §4.

- New table \`ticket_ref_status\` (migration 0015) keyed by
  \`(installation_id, system, ticket_ref)\`, plus two partial indexes.
- New helpers \`canon/sync/ticket_ref.py\` (\`qualify\`, \`due_for_recheck\`)
  and \`canon/sync/ticket_error.py\` (\`classify_error\`).
- New \`TicketRefStatusStore\` mirroring the existing per-domain stores.
- \`reverse_sync\` consults the store before each adapter call and
  records classified failures (404/401/403). Store failures fail-open
  so the cron is never aborted by ticket_ref_status being unreachable.
- canon-sync passes \`installation_id\` and \`ref_store\` through the
  existing call site; CLI / web sync paths unchanged (the new kwargs
  are optional).

## Test plan

- [x] Unit tests for \`qualify\`, \`due_for_recheck\`, \`classify_error\`
- [x] Store tests with mocked asyncpg pool covering get / record_failure
      / mark_ok / dismiss / force_recheck / list_broken
- [x] Engine integration tests covering the 3-failure flip,
      success-clears-broken, dismissed-skip, transient-doesn't-increment,
      24h-recheck, and store-fails-open paths
- [x] Full test suite passes
- [x] Lint + format clean
- [ ] Post-deploy: probe \`/rate_limit\` to confirm the per-cron call
      count drops as the cache fills with the existing 178 broken refs

## Out of scope (follow-ups)

- §3: Read API + dashboard panel + inline badge
- §4: Mutating endpoints + auto-PR-to-remove modal
- Sys.exit(1) cleanup in canon-sync (Option A) — separate small PR
EOF
)"
```

- [ ] **Step 3: Confirm CI is green**

Wait for the GitHub Actions checks; expect lint, helm-lint, smoke, scenarios, integration, and the unit suite to all pass. The preview deploy job will create `canon-preview-N` (the §2 chart was already fixed for this in PR #663's `values-preview.yaml` change to disable opensearch in preview).

- [ ] **Step 4: Tag the PR for review**

Add reviewers via the gh UI or `gh pr edit --add-reviewer`. Ready for human review.

---

## Self-Review

**1. Spec coverage:** Walked the §2 acceptance criteria from the Canon spec:

| AC | Task |
|----|------|
| Migration `0015_ticket_ref_status.py` adds the table and both indexes | Task 1 |
| `canon/sync/ticket_ref.py` implements `qualify()` and `due_for_recheck()` | Task 2 |
| `canon/sync/ticket_error.py` implements `classify_error()` | Task 3 |
| ~~`TicketAdapter.classify_exception` classmethod hook~~ | **Dropped from §2** — TicketAdapter is a Protocol, can't add classmethods. Generic httpx classifier is enough for v1; per-adapter overrides can ship in a follow-up if needed (YAGNI). The spec section 2 AC will be updated to reflect this. |
| `canon/db/ticket_ref_status_store.py` implements `get`, `mark_ok`, `record_failure`, `dismiss`, `force_recheck`, `list_broken` | Task 4 |
| `reverse_sync` skips refs whose row is `broken` or `dismissed` and not due for re-check | Task 5 step 3 (TestBrokenRefIsSkipped, TestDismissedRefIsSkipped) |
| Per-section errors classified `not_found` / `forbidden` / `unauthorized` flip the row to `broken` after 3 consecutive failures | Task 5 step 3 (TestThreeFailuresFlipToBroken) |
| Successful re-check after 24h auto-clears `broken` (but not `dismissed`) | Task 5 step 3 (TestSuccessClearsBroken) |
| Store failures (DB unavailable) fail-open: log warning, fall through | Task 5 step 3 (TestStoreFailureFailsOpen) |
| Unit tests cover `qualify`, `classify_error`, `due_for_recheck` | Tasks 2, 3 |
| Engine tests cover the 3-failure flip, success-clears-broken, dismissed-skip, transient-doesn't-increment, 24h-recheck paths | Task 5 |

**2. Placeholder scan:** No "TBD", "TODO", "implement later", or "appropriate error handling" phrases. All steps have concrete code or commands.

**3. Type consistency:** `installation_id: int | None` everywhere. `system: str` everywhere. `ticket_ref: str` everywhere. `ref_store: object | None` in `reverse_sync` (loose typing because the engine module shouldn't import the store class — keeps the layering clean).

The store's `record_failure` returns `dict` (status + consecutive_failures). The engine doesn't actually consume that return value today (it's there for §3/§4 dashboard polling and for tests to assert on). `mark_ok` returns `None`. `dismiss` / `force_recheck` return `None`.

**4. Spec AC adjustment:** The dropped per-adapter `classify_exception` hook should be removed from `docs/specs/broken-ticket-refs-ui.md` §2 AC list. That's a one-line spec edit, included as Task 0 if reviewer wants it; otherwise we'll just mark that AC as deferred during the PR review.
