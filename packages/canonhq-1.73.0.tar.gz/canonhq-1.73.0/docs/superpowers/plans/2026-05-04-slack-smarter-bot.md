# Slack Smarter Bot v1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make `@canon` work-context-aware by loading PRs, commits, tickets, the user's Slack threads, and Canon's spec/PR-analysis data into NL responses, with personalized DM context for identity-linked users and 11 new PostHog telemetry events.

**Architecture:** New `work_context/` module with per-source loaders, a coordinator orchestrating parallel fetches with progressive UI updates, an intent classifier (regex + LLM fallback), and a personal-context builder for DMs. Gated behind `slack.work_context.enabled` feature flag. All in one PR.

**Tech Stack:** Python 3.12, pytest + pytest-asyncio, alembic for DB migration, Pydantic v2 for models, anthropic Python SDK, asyncpg, slack-bolt async.

**Spec:** `docs/superpowers/specs/2026-05-04-slack-smarter-bot-design.md`

---

## File Structure

**New modules** under `extensions/canon-slack/src/canon_slack/`:

```
work_context/
  __init__.py           # public exports
  models.py             # WorkContextItem, ContextBundle, RecencyProfile, Intent
  ranking.py            # cross-source ranking + token budget enforcement
  intent.py             # IntentClassifier (regex + LLM)
  coordinator.py        # WorkContextCoordinator: parallel fetch + progress + telemetry
  agent.py              # WorkContextAgent stub (v2)
  sources/
    __init__.py
    base.py             # WorkContextSource Protocol
    canon_specs.py
    canon_pr_analysis.py
    github_prs.py
    github_commits.py
    tickets.py
    slack_threads.py

personal_context.py     # build_personal_context() — sibling to mentions.py
prompt_store.py         # PromptStore — sibling to mentions.py
telemetry.py            # event-name constants and helpers — sibling to mentions.py
```

**Modified** in `extensions/canon-slack/src/canon_slack/`:
- `mentions.py` — replace inline spec loading with coordinator call
- `identity_store.py` — add owned-specs and team lookup methods
- `commands.py` — emit `slack_command_invoked` telemetry
- `actions.py` — emit `slack_action_clicked` telemetry
- `home_tab.py` — emit `slack_home_tab_opened` telemetry
- `new_spec.py` — emit `slack_spec_created` telemetry
- `notifications.py` — emit `slack_notification_dispatched` telemetry
- `digest.py` — emit `slack_digest_sent` telemetry
- `install.py` — emit `slack_identity_linked` telemetry on `/canon link` success

**Modified** in `src/canon/`:
- `config/parse.py` — add `WorkContextConfig` model + parsing
- `db/migrations/versions/0015_slack_dm_prompts.py` — new migration

**New tests** in `tests/`:
- `test_slack_work_context_models.py`
- `test_slack_work_context_ranking.py`
- `test_slack_work_context_intent.py`
- `test_slack_work_context_coordinator.py`
- `test_slack_work_context_sources.py` (one file with one class per source)
- `test_slack_personal_context.py`
- `test_slack_prompt_store.py`
- `test_slack_telemetry.py`
- `tests/integration/test_slack_smarter_bot.py`
- `tests/scenarios/scenario_slack_smarter_bot.py`

**New fixtures** in `tests/fixtures/work_context/`:
- `intent_eval/queries.jsonl`
- `github_prs/sample_response.json`
- `tickets/sample_response.json`
- `slack_search/sample_response.json`

---

## Phase 1: Foundation

### Task 1: Add `WorkContextConfig` to CANON.yaml parser

**Files:**
- Modify: `src/canon/config/parse.py`
- Test: `tests/test_config_parse.py` (existing file)

- [ ] **Step 1: Write the failing test**

Append to `tests/test_config_parse.py`:

```python
def test_slack_work_context_default_disabled():
    """work_context defaults to disabled when slack section omits it."""
    raw = """
slack:
  default_channel: "#specs"
"""
    result = parse_canon_yaml(raw)
    assert result.config.slack.work_context.enabled is False


def test_slack_work_context_explicit_enabled():
    raw = """
slack:
  work_context:
    enabled: true
"""
    result = parse_canon_yaml(raw)
    assert result.config.slack.work_context.enabled is True


def test_slack_work_context_invalid_type_warns():
    raw = """
slack:
  work_context:
    enabled: "yes"
"""
    result = parse_canon_yaml(raw)
    # Coerced/warned; non-bool should default to False
    assert result.config.slack.work_context.enabled is False
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_config_parse.py::test_slack_work_context_default_disabled -v`
Expected: FAIL with `AttributeError: 'SlackConfig' object has no attribute 'work_context'`

- [ ] **Step 3: Implement the model and parser**

In `src/canon/config/parse.py`, add a new model class above `SlackConfig`:

```python
class WorkContextConfig(BaseModel):
    enabled: bool = False
```

Add to `SlackConfig`:

```python
class SlackConfig(BaseModel):
    # ... existing fields ...
    work_context: WorkContextConfig = WorkContextConfig()
```

In the slack parsing block (around line 1037), add WorkContextConfig parsing before the `SlackConfig(...)` construction:

```python
        wc_data = slack_data.get("work_context")
        work_context = WorkContextConfig()
        if isinstance(wc_data, dict):
            wc_enabled = wc_data.get("enabled", False)
            if isinstance(wc_enabled, bool):
                work_context = WorkContextConfig(enabled=wc_enabled)
```

Then pass it into the SlackConfig constructor:

```python
            work_context=work_context,
```

Add `"work_context"` to the slack data known-keys allowlist (search for `_KNOWN_SLACK_KEYS` or equivalent and add).

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_config_parse.py -k work_context -v`
Expected: 3 PASS

- [ ] **Step 5: Commit**

```bash
git add src/canon/config/parse.py tests/test_config_parse.py
git commit -m "feat(slack): add slack.work_context config schema (default disabled)"
```

---

### Task 2: Create `slack_dm_prompts` DB migration

**Files:**
- Create: `src/canon/db/migrations/versions/0015_slack_dm_prompts.py`
- Test: `tests/test_slack_prompt_store.py` (created later in Task 3 — migration is verified by alembic + Task 3's tests)

- [ ] **Step 1: Generate migration scaffold**

Run: `uv run alembic -c src/canon/db/alembic.ini revision --autogenerate -m "Add slack_dm_prompts table"`

This creates a file like `0015_add_slack_dm_prompts_table.py`. Rename it to `0015_slack_dm_prompts.py` for consistency with the other migration filenames.

- [ ] **Step 2: Replace the autogenerated content**

Open `src/canon/db/migrations/versions/0015_slack_dm_prompts.py` and replace contents with:

```python
"""Add slack_dm_prompts table for one-time-prompt tracking.

Tracks whether the bot has already nudged a Slack user to link their GitHub
identity (via /canon link). Without this, every unlinked DM would re-prompt
the user, which becomes spammy. One row per (workspace_id, user_id, prompt_type).

Revision ID: 0015
Revises: 0014
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0015"
down_revision = "0014"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "slack_dm_prompts",
        sa.Column("workspace_id", sa.String(length=64), nullable=False),
        sa.Column("user_id", sa.String(length=64), nullable=False),
        sa.Column("prompt_type", sa.String(length=64), nullable=False),
        sa.Column(
            "sent_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.PrimaryKeyConstraint("workspace_id", "user_id", "prompt_type"),
    )


def downgrade() -> None:
    op.drop_table("slack_dm_prompts")
```

- [ ] **Step 3: Run migration locally to verify**

Start the dev database (if not running): `devbox run integration` (this brings up Postgres) then in another shell:

Run: `uv run alembic -c src/canon/db/alembic.ini upgrade head`
Expected: `Running upgrade 0014 -> 0015, Add slack_dm_prompts table`

Verify the table exists:

Run: `psql $DATABASE_URL -c "\d slack_dm_prompts"`
Expected: column listing showing 4 columns and the composite primary key.

- [ ] **Step 4: Verify downgrade works**

Run: `uv run alembic -c src/canon/db/alembic.ini downgrade 0014 && uv run alembic -c src/canon/db/alembic.ini upgrade head`
Expected: clean down + up cycle.

- [ ] **Step 5: Commit**

```bash
git add src/canon/db/migrations/versions/0015_slack_dm_prompts.py
git commit -m "feat(slack): add slack_dm_prompts table for one-time-prompt tracking"
```

---

### Task 3: Implement `PromptStore` (sibling to mentions.py)

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/prompt_store.py`
- Create: `tests/test_slack_prompt_store.py`

- [ ] **Step 1: Write the failing test**

Create `tests/test_slack_prompt_store.py`:

```python
"""Tests for the slack PromptStore."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from canon_slack.prompt_store import PromptStore


class TestPromptStore:
    @pytest.mark.asyncio
    async def test_has_been_prompted_returns_false_for_new_user(self):
        pool = AsyncMock()
        conn = AsyncMock()
        conn.fetchval = AsyncMock(return_value=None)
        pool.acquire.return_value.__aenter__.return_value = conn

        store = PromptStore(pool)
        assert await store.has_been_prompted("T1", "U1", "link_identity") is False

    @pytest.mark.asyncio
    async def test_has_been_prompted_returns_true_after_mark(self):
        pool = AsyncMock()
        conn = AsyncMock()
        # First call returns None (not prompted), second returns a row
        conn.fetchval = AsyncMock(side_effect=[None, "2026-05-04T12:00:00"])
        conn.execute = AsyncMock()
        pool.acquire.return_value.__aenter__.return_value = conn

        store = PromptStore(pool)
        assert await store.has_been_prompted("T1", "U1", "link_identity") is False
        await store.mark_prompted("T1", "U1", "link_identity")
        assert await store.has_been_prompted("T1", "U1", "link_identity") is True

    @pytest.mark.asyncio
    async def test_mark_prompted_uses_upsert(self):
        """mark_prompted is idempotent — calling twice doesn't error."""
        pool = AsyncMock()
        conn = AsyncMock()
        conn.execute = AsyncMock()
        pool.acquire.return_value.__aenter__.return_value = conn

        store = PromptStore(pool)
        await store.mark_prompted("T1", "U1", "link_identity")
        await store.mark_prompted("T1", "U1", "link_identity")  # second call is fine
        assert conn.execute.call_count == 2
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_prompt_store.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'canon_slack.prompt_store'`

- [ ] **Step 3: Implement PromptStore**

Create `extensions/canon-slack/src/canon_slack/prompt_store.py`:

```python
"""One-time-prompt state for Slack DM nudges (e.g., link your GitHub)."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


class PromptStore:
    """Tracks whether the bot has sent a particular nudge to a user before.

    Backed by the `slack_dm_prompts` table. Failures here are best-effort:
    a missing prompt record means the bot will nudge the user, which is
    safer than a stuck-state where the user never gets prompted.
    """

    def __init__(self, pool: Any) -> None:
        self._pool = pool

    async def has_been_prompted(
        self, workspace_id: str, user_id: str, prompt_type: str
    ) -> bool:
        try:
            async with self._pool.acquire() as conn:
                row = await conn.fetchval(
                    """
                    SELECT sent_at FROM slack_dm_prompts
                    WHERE workspace_id = $1 AND user_id = $2 AND prompt_type = $3
                    """,
                    workspace_id,
                    user_id,
                    prompt_type,
                )
            return row is not None
        except Exception:
            logger.warning(
                "PromptStore.has_been_prompted failed for %s/%s/%s",
                workspace_id,
                user_id,
                prompt_type,
                exc_info=True,
            )
            return False  # safer to re-prompt than silently swallow

    async def mark_prompted(
        self, workspace_id: str, user_id: str, prompt_type: str
    ) -> None:
        try:
            async with self._pool.acquire() as conn:
                await conn.execute(
                    """
                    INSERT INTO slack_dm_prompts (workspace_id, user_id, prompt_type)
                    VALUES ($1, $2, $3)
                    ON CONFLICT (workspace_id, user_id, prompt_type) DO NOTHING
                    """,
                    workspace_id,
                    user_id,
                    prompt_type,
                )
        except Exception:
            logger.warning(
                "PromptStore.mark_prompted failed for %s/%s/%s",
                workspace_id,
                user_id,
                prompt_type,
                exc_info=True,
            )
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_slack_prompt_store.py -v`
Expected: 3 PASS

- [ ] **Step 5: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/prompt_store.py tests/test_slack_prompt_store.py
git commit -m "feat(slack): add PromptStore for one-time DM prompt tracking"
```

---

### Task 4: Telemetry constants module

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/telemetry.py`
- Create: `tests/test_slack_telemetry.py`

- [ ] **Step 1: Write the failing test**

Create `tests/test_slack_telemetry.py`:

```python
"""Tests for slack telemetry helpers."""

from __future__ import annotations

from unittest.mock import patch

from canon_slack.telemetry import (
    EVENT_ACTION_CLICKED,
    EVENT_COMMAND_INVOKED,
    EVENT_DIGEST_SENT,
    EVENT_HOME_TAB_OPENED,
    EVENT_IDENTITY_LINKED,
    EVENT_INTENT_CLASSIFIED,
    EVENT_MENTION_HANDLED,
    EVENT_NOTIFICATION_DISPATCHED,
    EVENT_SOURCE_FETCHED,
    EVENT_SPEC_CREATED,
    EVENT_WORK_CONTEXT_ASSEMBLED,
    SuperProperties,
    track_slack,
)


def test_event_constants_match_spec():
    """All 11 event names are spelled per slack-product-experience.md §10 + design spec §6."""
    assert EVENT_COMMAND_INVOKED == "slack_command_invoked"
    assert EVENT_MENTION_HANDLED == "slack_mention_handled"
    assert EVENT_ACTION_CLICKED == "slack_action_clicked"
    assert EVENT_HOME_TAB_OPENED == "slack_home_tab_opened"
    assert EVENT_SPEC_CREATED == "slack_spec_created"
    assert EVENT_NOTIFICATION_DISPATCHED == "slack_notification_dispatched"
    assert EVENT_IDENTITY_LINKED == "slack_identity_linked"
    assert EVENT_DIGEST_SENT == "slack_digest_sent"
    assert EVENT_INTENT_CLASSIFIED == "work_context_intent_classified"
    assert EVENT_SOURCE_FETCHED == "work_context_source_fetched"
    assert EVENT_WORK_CONTEXT_ASSEMBLED == "work_context_assembled"


def test_track_slack_calls_analytics_with_super_props():
    super_props = SuperProperties(
        slack_workspace_id="T123", org_id="org_abc", extension_version="0.1.0"
    )
    with patch("canon_slack.telemetry.analytics.track") as mock_track:
        track_slack(
            EVENT_COMMAND_INVOKED,
            super_props,
            {"subcommand": "status"},
            distinct_id="U1",
        )
        mock_track.assert_called_once()
        kwargs = mock_track.call_args.kwargs
        assert kwargs["distinct_id"] == "U1"
        assert kwargs["properties"]["subcommand"] == "status"
        assert kwargs["properties"]["slack_workspace_id"] == "T123"
        assert kwargs["properties"]["org_id"] == "org_abc"
        assert kwargs["properties"]["extension_version"] == "0.1.0"


def test_track_slack_swallows_failures():
    super_props = SuperProperties("T1", "org", "0.1.0")
    with patch(
        "canon_slack.telemetry.analytics.track",
        side_effect=RuntimeError("boom"),
    ):
        # Must not raise
        track_slack(EVENT_COMMAND_INVOKED, super_props, {}, distinct_id="U1")
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_telemetry.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'canon_slack.telemetry'`

- [ ] **Step 3: Implement telemetry module**

Create `extensions/canon-slack/src/canon_slack/telemetry.py`:

```python
"""Telemetry constants and helpers for the canon-slack extension."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from canon import analytics

logger = logging.getLogger(__name__)


# §10 Slack events
EVENT_COMMAND_INVOKED = "slack_command_invoked"
EVENT_MENTION_HANDLED = "slack_mention_handled"
EVENT_ACTION_CLICKED = "slack_action_clicked"
EVENT_HOME_TAB_OPENED = "slack_home_tab_opened"
EVENT_SPEC_CREATED = "slack_spec_created"
EVENT_NOTIFICATION_DISPATCHED = "slack_notification_dispatched"
EVENT_IDENTITY_LINKED = "slack_identity_linked"
EVENT_DIGEST_SENT = "slack_digest_sent"

# Sub-project A work-context events
EVENT_INTENT_CLASSIFIED = "work_context_intent_classified"
EVENT_SOURCE_FETCHED = "work_context_source_fetched"
EVENT_WORK_CONTEXT_ASSEMBLED = "work_context_assembled"


@dataclass(frozen=True)
class SuperProperties:
    """Common props attached to every Slack event."""

    slack_workspace_id: str
    org_id: str
    extension_version: str


def track_slack(
    event: str,
    super_props: SuperProperties,
    properties: dict[str, Any],
    *,
    distinct_id: str,
) -> None:
    """Capture a Slack telemetry event. Best-effort — swallows failures.

    Per design spec §10.2: 'All track() calls wrapped to never block the
    user-facing operation.'
    """
    merged: dict[str, Any] = {
        "slack_workspace_id": super_props.slack_workspace_id,
        "org_id": super_props.org_id,
        "extension_version": super_props.extension_version,
        **properties,
    }
    try:
        analytics.track(event, distinct_id=distinct_id, properties=merged)
    except Exception:
        logger.debug("track_slack failed for event %s", event, exc_info=True)
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_slack_telemetry.py -v`
Expected: 3 PASS

- [ ] **Step 5: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/telemetry.py tests/test_slack_telemetry.py
git commit -m "feat(slack): add telemetry event constants and track_slack helper"
```

---

## Phase 2: Models

### Task 5: Work-context models

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/work_context/__init__.py` (empty)
- Create: `extensions/canon-slack/src/canon_slack/work_context/models.py`
- Create: `tests/test_slack_work_context_models.py`

- [ ] **Step 1: Write the failing test**

Create `tests/test_slack_work_context_models.py`:

```python
"""Tests for work_context models."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest
from canon_slack.work_context.models import (
    ContextBundle,
    Intent,
    PersonalContext,
    RecencyProfile,
    WorkContextItem,
)


def test_intent_enum_values():
    assert Intent.LOOKUP == "lookup"
    assert Intent.DISCUSSION == "discussion"
    assert Intent.INVESTIGATION == "investigation"


def test_recency_profile_to_days():
    assert RecencyProfile.RECENT.days_for_source("github_pr") == 7
    assert RecencyProfile.HISTORICAL.days_for_source("github_pr") == 90
    # Mixed: messages 7d, others 90d
    assert RecencyProfile.MIXED.days_for_source("slack_thread") == 7
    assert RecencyProfile.MIXED.days_for_source("github_pr") == 90


def test_work_context_item_required_fields():
    item = WorkContextItem(
        source="github_pr",
        title="Add foo",
        summary="Adds the foo subsystem.",
        url="https://github.com/x/y/pull/1",
        timestamp=datetime(2026, 5, 1, tzinfo=timezone.utc),
    )
    assert item.relevance_score == 0.0  # default


def test_context_bundle_format_for_claude_groups_by_source():
    items = [
        WorkContextItem(
            source="github_pr",
            title="PR1",
            summary="s1",
            url="u1",
            timestamp=datetime(2026, 5, 1, tzinfo=timezone.utc),
        ),
        WorkContextItem(
            source="canon_spec",
            title="Spec1",
            summary="s2",
            url="u2",
            timestamp=datetime(2026, 5, 2, tzinfo=timezone.utc),
        ),
    ]
    bundle = ContextBundle(items=items)
    formatted = bundle.format_for_claude()
    assert "Specs" in formatted
    assert "PRs" in formatted
    assert "Spec1" in formatted
    assert "PR1" in formatted


def test_context_bundle_with_personal_context_prepended():
    pc = PersonalContext(
        github_login="ngerner",
        team="platform",
        owned_specs=[("auth-hardening", "in_progress")],
    )
    bundle = ContextBundle(items=[], personal_context=pc)
    formatted = bundle.format_for_claude()
    assert formatted.startswith("<personal_context>")
    assert "ngerner" in formatted
    assert "auth-hardening" in formatted


def test_context_bundle_total_items():
    bundle = ContextBundle(items=[])
    assert bundle.total_items() == 0

    bundle = ContextBundle(
        items=[
            WorkContextItem(
                source="github_pr",
                title="t",
                summary="s",
                url="u",
                timestamp=datetime.now(timezone.utc),
            )
        ]
    )
    assert bundle.total_items() == 1
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_work_context_models.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Implement the models**

Create `extensions/canon-slack/src/canon_slack/work_context/__init__.py`:

```python
"""work_context: load PRs, commits, tickets, threads, and specs for @canon answers."""
```

Create `extensions/canon-slack/src/canon_slack/work_context/models.py`:

```python
"""Pydantic models for work_context."""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class Intent(StrEnum):
    LOOKUP = "lookup"
    DISCUSSION = "discussion"
    INVESTIGATION = "investigation"


class RecencyProfile(StrEnum):
    RECENT = "recent"
    HISTORICAL = "historical"
    MIXED = "mixed"

    def days_for_source(self, source_name: str) -> int:
        """Return the recency window in days for a given source."""
        if self is RecencyProfile.RECENT:
            return 7
        if self is RecencyProfile.HISTORICAL:
            return 90
        # MIXED: short for messages, long for everything else
        if source_name == "slack_thread":
            return 7
        return 90


class WorkContextItem(BaseModel):
    source: str  # "github_pr", "linear_ticket", "slack_thread", etc.
    title: str
    summary: str
    url: str
    timestamp: datetime
    relevance_score: float = 0.0
    metadata: dict[str, Any] = Field(default_factory=dict)


class PersonalContext(BaseModel):
    github_login: str
    team: str | None = None
    owned_specs: list[tuple[str, str]] = Field(default_factory=list)
    # (slug, status); future: followed_specs, muted_specs

    def render(self) -> str:
        lines = [
            "<personal_context>",
            f"User GitHub login: {self.github_login}",
        ]
        if self.team:
            lines.append(f"User team: {self.team}")
        if self.owned_specs:
            lines.append("User owns these specs:")
            for slug, status in self.owned_specs:
                lines.append(f"  - {slug} ({status})")
        lines.append("</personal_context>")
        return "\n".join(lines)


_SOURCE_LABEL: dict[str, str] = {
    "canon_spec": "Specs",
    "canon_pr_analysis": "Recent PR Analysis",
    "github_pr": "PRs",
    "github_commit": "Commits",
    "linear_ticket": "Tickets",
    "jira_ticket": "Tickets",
    "github_issue": "Tickets",
    "slack_thread": "Slack Threads",
}


class ContextBundle(BaseModel):
    items: list[WorkContextItem] = Field(default_factory=list)
    personal_context: PersonalContext | None = None
    sources_attempted: int = 0
    sources_succeeded: int = 0
    total_tokens: int = 0  # estimated, set by ranker

    def total_items(self) -> int:
        return len(self.items)

    def format_for_claude(self) -> str:
        """Render bundle into the work-context block of the system prompt."""
        sections: list[str] = []
        if self.personal_context is not None:
            sections.append(self.personal_context.render())

        # Group items by user-facing label (multiple ticket sources collapse to "Tickets")
        grouped: dict[str, list[WorkContextItem]] = defaultdict(list)
        for item in self.items:
            label = _SOURCE_LABEL.get(item.source, item.source)
            grouped[label].append(item)

        for label, items in grouped.items():
            sections.append(f"<{label.lower().replace(' ', '_')}>")
            sections.append(f"## {label}")
            for item in items:
                sections.append(
                    f"- **{item.title}** "
                    f"({item.timestamp.strftime('%Y-%m-%d')}) — "
                    f"{item.summary}\n  {item.url}"
                )
            sections.append(f"</{label.lower().replace(' ', '_')}>")

        return "\n".join(sections)
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_slack_work_context_models.py -v`
Expected: 6 PASS

- [ ] **Step 5: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/work_context/__init__.py extensions/canon-slack/src/canon_slack/work_context/models.py tests/test_slack_work_context_models.py
git commit -m "feat(slack): add work_context models (Intent, RecencyProfile, ContextBundle, PersonalContext)"
```

---

### Task 6: WorkContextSource Protocol

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/work_context/sources/__init__.py` (empty)
- Create: `extensions/canon-slack/src/canon_slack/work_context/sources/base.py`

No test for this task — it's a Protocol definition. Tested implicitly by source implementations.

- [ ] **Step 1: Implement the Protocol**

Create `extensions/canon-slack/src/canon_slack/work_context/sources/__init__.py`:

```python
"""Per-source loaders for work context."""
```

Create `extensions/canon-slack/src/canon_slack/work_context/sources/base.py`:

```python
"""WorkContextSource Protocol — every loader implements this."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from canon_slack.work_context.models import WorkContextItem


@runtime_checkable
class WorkContextSource(Protocol):
    """A loader that fetches a single category of context for @canon."""

    name: str

    def enabled_for_org(self, org_id: str) -> bool:
        """Return True if this source can produce results for the given org.

        Should be cheap (no network calls). Used to skip sources whose
        upstream isn't connected for this org (e.g., LinearTicketSource
        returns False if Linear isn't configured).
        """
        ...

    async def fetch(
        self, query: str, recency_days: int, cap: int
    ) -> list[WorkContextItem]:
        """Fetch up to `cap` items relevant to `query` from the last `recency_days`.

        On any failure, return []. Log warnings; do not raise.
        """
        ...
```

- [ ] **Step 2: Verify it imports**

Run: `uv run python -c "from canon_slack.work_context.sources.base import WorkContextSource; print(WorkContextSource)"`
Expected: `<class 'canon_slack.work_context.sources.base.WorkContextSource'>`

- [ ] **Step 3: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/work_context/sources/__init__.py extensions/canon-slack/src/canon_slack/work_context/sources/base.py
git commit -m "feat(slack): add WorkContextSource Protocol for loaders"
```

---

## Phase 3: Source Loaders

### Task 7: `CanonSpecSource` — wraps existing SpecLoader

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/work_context/sources/canon_specs.py`
- Modify: `tests/test_slack_work_context_sources.py` (create with first source class)

- [ ] **Step 1: Write the failing test**

Create `tests/test_slack_work_context_sources.py`:

```python
"""Tests for work_context source loaders."""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock

import pytest
from canon_slack.work_context.sources.canon_specs import CanonSpecSource


class TestCanonSpecSource:
    @pytest.mark.asyncio
    async def test_returns_items_from_spec_loader(self):
        loader = MagicMock()
        spec1 = MagicMock(
            slug="auth-hardening",
            title="Auth Hardening",
            status="in_progress",
            url="https://github.com/x/y/blob/main/docs/specs/auth-hardening.md",
            updated_at=datetime(2026, 5, 1, tzinfo=timezone.utc),
            ac_summary="3/8 ACs done",
        )
        loader.search = MagicMock(return_value=[spec1])
        loader.load = AsyncMock()

        source = CanonSpecSource(loader)
        items = await source.fetch("auth", recency_days=7, cap=5)

        assert len(items) == 1
        assert items[0].source == "canon_spec"
        assert items[0].title == "Auth Hardening"
        assert "in_progress" in items[0].summary
        assert items[0].url == spec1.url

    @pytest.mark.asyncio
    async def test_respects_cap(self):
        loader = MagicMock()
        loader.load = AsyncMock()
        loader.search = MagicMock(
            return_value=[
                MagicMock(
                    slug=f"s{i}",
                    title=f"Spec {i}",
                    status="draft",
                    url=f"u{i}",
                    updated_at=datetime.now(timezone.utc),
                    ac_summary="0/0",
                )
                for i in range(20)
            ]
        )
        source = CanonSpecSource(loader)
        items = await source.fetch("any", recency_days=7, cap=5)
        assert len(items) == 5

    @pytest.mark.asyncio
    async def test_returns_empty_on_loader_failure(self):
        loader = MagicMock()
        loader.load = AsyncMock(side_effect=RuntimeError("boom"))
        source = CanonSpecSource(loader)
        items = await source.fetch("q", recency_days=7, cap=5)
        assert items == []

    def test_enabled_for_org_always_true(self):
        loader = MagicMock()
        source = CanonSpecSource(loader)
        assert source.enabled_for_org("any_org") is True
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_work_context_sources.py::TestCanonSpecSource -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Implement CanonSpecSource**

Create `extensions/canon-slack/src/canon_slack/work_context/sources/canon_specs.py`:

```python
"""Canon spec source — wraps the existing SpecLoader."""

from __future__ import annotations

import logging
from typing import Any

from canon_slack.work_context.models import WorkContextItem

logger = logging.getLogger(__name__)


class CanonSpecSource:
    name = "canon_spec"

    def __init__(self, spec_loader: Any) -> None:
        self._loader = spec_loader

    def enabled_for_org(self, org_id: str) -> bool:
        return True

    async def fetch(
        self, query: str, recency_days: int, cap: int
    ) -> list[WorkContextItem]:
        try:
            await self._loader.load()
            specs = self._loader.search(query)
        except Exception:
            logger.warning("CanonSpecSource.fetch failed", exc_info=True)
            return []

        items: list[WorkContextItem] = []
        for spec in specs[:cap]:
            items.append(
                WorkContextItem(
                    source=self.name,
                    title=spec.title,
                    summary=f"Status: {spec.status}. {spec.ac_summary}",
                    url=spec.url,
                    timestamp=spec.updated_at,
                    metadata={"slug": spec.slug, "status": spec.status},
                )
            )
        return items
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_slack_work_context_sources.py::TestCanonSpecSource -v`
Expected: 4 PASS

- [ ] **Step 5: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/work_context/sources/canon_specs.py tests/test_slack_work_context_sources.py
git commit -m "feat(slack): add CanonSpecSource for work_context"
```

---

### Task 8: `CanonPRAnalysisSource` — DB-backed

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/work_context/sources/canon_pr_analysis.py`
- Modify: `tests/test_slack_work_context_sources.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_slack_work_context_sources.py`:

```python
from canon_slack.work_context.sources.canon_pr_analysis import CanonPRAnalysisSource


class TestCanonPRAnalysisSource:
    @pytest.mark.asyncio
    async def test_returns_items_from_db(self):
        pool = AsyncMock()
        conn = AsyncMock()
        conn.fetch = AsyncMock(
            return_value=[
                {
                    "spec_slug": "auth-hardening",
                    "pr_number": 477,
                    "pr_title": "Add rate limiting",
                    "summary": "Realized 2 ACs",
                    "pr_url": "https://github.com/x/y/pull/477",
                    "analyzed_at": datetime(2026, 5, 1, tzinfo=timezone.utc),
                }
            ]
        )
        pool.acquire.return_value.__aenter__.return_value = conn

        source = CanonPRAnalysisSource(pool, "org_abc")
        items = await source.fetch("auth", recency_days=7, cap=5)

        assert len(items) == 1
        assert items[0].source == "canon_pr_analysis"
        assert items[0].title.startswith("PR #477")
        assert "Realized 2 ACs" in items[0].summary

    @pytest.mark.asyncio
    async def test_returns_empty_on_db_failure(self):
        pool = AsyncMock()
        pool.acquire.side_effect = RuntimeError("db down")
        source = CanonPRAnalysisSource(pool, "org_abc")
        items = await source.fetch("q", recency_days=7, cap=5)
        assert items == []

    def test_enabled_for_org_always_true(self):
        source = CanonPRAnalysisSource(AsyncMock(), "org_abc")
        assert source.enabled_for_org("org_abc") is True
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_work_context_sources.py::TestCanonPRAnalysisSource -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Implement CanonPRAnalysisSource**

Create `extensions/canon-slack/src/canon_slack/work_context/sources/canon_pr_analysis.py`:

```python
"""PR analysis history source — recent agent analyses for this org."""

from __future__ import annotations

import logging
from typing import Any

from canon_slack.work_context.models import WorkContextItem

logger = logging.getLogger(__name__)


class CanonPRAnalysisSource:
    name = "canon_pr_analysis"

    def __init__(self, pool: Any, org_id: str) -> None:
        self._pool = pool
        self._org_id = org_id

    def enabled_for_org(self, org_id: str) -> bool:
        return True

    async def fetch(
        self, query: str, recency_days: int, cap: int
    ) -> list[WorkContextItem]:
        try:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT
                      spec_slug,
                      pr_number,
                      pr_title,
                      summary,
                      pr_url,
                      analyzed_at
                    FROM pr_analyses
                    WHERE org_id = $1
                      AND analyzed_at > now() - ($2 || ' days')::interval
                      AND (spec_slug ILIKE '%' || $3 || '%'
                           OR pr_title ILIKE '%' || $3 || '%'
                           OR summary ILIKE '%' || $3 || '%')
                    ORDER BY analyzed_at DESC
                    LIMIT $4
                    """,
                    self._org_id,
                    str(recency_days),
                    query,
                    cap,
                )
        except Exception:
            logger.warning("CanonPRAnalysisSource.fetch failed", exc_info=True)
            return []

        items: list[WorkContextItem] = []
        for row in rows:
            items.append(
                WorkContextItem(
                    source=self.name,
                    title=f"PR #{row['pr_number']} — {row['pr_title']}",
                    summary=row["summary"],
                    url=row["pr_url"],
                    timestamp=row["analyzed_at"],
                    metadata={
                        "spec_slug": row["spec_slug"],
                        "pr_number": row["pr_number"],
                    },
                )
            )
        return items
```

**Note for the implementer:** verify the `pr_analyses` table schema matches (org_id, spec_slug, pr_number, pr_title, summary, pr_url, analyzed_at columns). If column names differ, adjust the SQL. If the table doesn't exist yet, this source's `fetch` will return `[]` on the DB error — the rest of the system continues to work, just without this source.

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_slack_work_context_sources.py::TestCanonPRAnalysisSource -v`
Expected: 3 PASS

- [ ] **Step 5: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/work_context/sources/canon_pr_analysis.py tests/test_slack_work_context_sources.py
git commit -m "feat(slack): add CanonPRAnalysisSource for work_context"
```

---

### Task 9: `GitHubPRSource`

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/work_context/sources/github_prs.py`
- Modify: `tests/test_slack_work_context_sources.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_slack_work_context_sources.py`:

```python
from canon_slack.work_context.sources.github_prs import GitHubPRSource


class TestGitHubPRSource:
    @pytest.mark.asyncio
    async def test_returns_prs_matching_query(self):
        gh_client = MagicMock()
        gh_client.search_prs = AsyncMock(
            return_value=[
                {
                    "number": 477,
                    "title": "Add rate limiting",
                    "body": "Implements per-IP rate limit",
                    "html_url": "https://github.com/x/y/pull/477",
                    "updated_at": "2026-05-01T12:00:00Z",
                    "state": "open",
                }
            ]
        )
        installations = MagicMock()
        installations.repos_for_org = AsyncMock(return_value=["x/y", "x/z"])

        source = GitHubPRSource(gh_client, installations, "org_abc")
        items = await source.fetch("rate limit", recency_days=7, cap=5)

        assert len(items) == 1
        assert items[0].source == "github_pr"
        assert items[0].title == "Add rate limiting"
        assert items[0].metadata["number"] == 477

    @pytest.mark.asyncio
    async def test_returns_empty_when_no_repos(self):
        gh_client = MagicMock()
        installations = MagicMock()
        installations.repos_for_org = AsyncMock(return_value=[])

        source = GitHubPRSource(gh_client, installations, "org_abc")
        items = await source.fetch("anything", recency_days=7, cap=5)
        assert items == []

    @pytest.mark.asyncio
    async def test_returns_empty_on_api_failure(self):
        gh_client = MagicMock()
        gh_client.search_prs = AsyncMock(side_effect=RuntimeError("github 500"))
        installations = MagicMock()
        installations.repos_for_org = AsyncMock(return_value=["x/y"])

        source = GitHubPRSource(gh_client, installations, "org_abc")
        items = await source.fetch("q", recency_days=7, cap=5)
        assert items == []

    def test_enabled_for_org_checks_installation(self):
        gh_client = MagicMock()
        installations = MagicMock()
        installations.is_installed_sync = MagicMock(return_value=True)

        source = GitHubPRSource(gh_client, installations, "org_abc")
        assert source.enabled_for_org("org_abc") is True
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_work_context_sources.py::TestGitHubPRSource -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Implement GitHubPRSource**

Create `extensions/canon-slack/src/canon_slack/work_context/sources/github_prs.py`:

```python
"""GitHub PR source — recent open + merged PRs in org-mapped repos matching a query."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from canon_slack.work_context.models import WorkContextItem

logger = logging.getLogger(__name__)


class GitHubPRSource:
    name = "github_pr"

    def __init__(self, gh_client: Any, installations: Any, org_id: str) -> None:
        self._gh = gh_client
        self._installations = installations
        self._org_id = org_id

    def enabled_for_org(self, org_id: str) -> bool:
        try:
            return self._installations.is_installed_sync(org_id)
        except Exception:
            return False

    async def fetch(
        self, query: str, recency_days: int, cap: int
    ) -> list[WorkContextItem]:
        try:
            repos = await self._installations.repos_for_org(self._org_id)
        except Exception:
            logger.warning("GitHubPRSource: failed to list repos", exc_info=True)
            return []

        if not repos:
            return []

        items: list[WorkContextItem] = []
        for repo in repos:
            try:
                results = await self._gh.search_prs(
                    repo=repo,
                    query=query,
                    recency_days=recency_days,
                    limit=cap,
                )
            except Exception:
                logger.warning(
                    "GitHubPRSource: search_prs failed for %s", repo, exc_info=True
                )
                continue

            for pr in results:
                try:
                    items.append(
                        WorkContextItem(
                            source=self.name,
                            title=pr["title"],
                            summary=(pr.get("body") or "")[:300],
                            url=pr["html_url"],
                            timestamp=datetime.fromisoformat(
                                pr["updated_at"].replace("Z", "+00:00")
                            ),
                            metadata={
                                "number": pr["number"],
                                "state": pr.get("state"),
                                "repo": repo,
                            },
                        )
                    )
                except Exception:
                    logger.debug("Skipping malformed PR", exc_info=True)

        # Re-cap across repos
        return items[:cap]
```

**Note for the implementer:** verify the `GitHubClient` has a `search_prs(repo, query, recency_days, limit)` method. If it doesn't, you'll need to extend `src/canon/github/client.py` to add it (using the GitHub `GET /search/issues?q=is:pr+repo:owner/repo+keyword` API). Add a brief test for the new GitHubClient method in `tests/test_github_client.py` if you add it.

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_slack_work_context_sources.py::TestGitHubPRSource -v`
Expected: 4 PASS

- [ ] **Step 5: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/work_context/sources/github_prs.py tests/test_slack_work_context_sources.py
git commit -m "feat(slack): add GitHubPRSource for work_context"
```

---

### Task 10: `GitHubCommitSource`

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/work_context/sources/github_commits.py`
- Modify: `tests/test_slack_work_context_sources.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_slack_work_context_sources.py`:

```python
from canon_slack.work_context.sources.github_commits import GitHubCommitSource


class TestGitHubCommitSource:
    @pytest.mark.asyncio
    async def test_returns_commits_matching_query(self):
        gh_client = MagicMock()
        gh_client.list_commits = AsyncMock(
            return_value=[
                {
                    "sha": "abc123",
                    "commit": {
                        "message": "Refactor auth middleware",
                        "author": {
                            "name": "Alice",
                            "date": "2026-05-01T10:00:00Z",
                        },
                    },
                    "html_url": "https://github.com/x/y/commit/abc123",
                    "files": [{"filename": "src/auth/middleware.py"}],
                }
            ]
        )
        installations = MagicMock()
        installations.repos_for_org = AsyncMock(return_value=["x/y"])

        source = GitHubCommitSource(gh_client, installations, "org_abc")
        items = await source.fetch("auth", recency_days=7, cap=5)

        assert len(items) == 1
        assert items[0].source == "github_commit"
        assert items[0].title.startswith("Refactor auth middleware")

    @pytest.mark.asyncio
    async def test_returns_empty_on_api_failure(self):
        gh_client = MagicMock()
        gh_client.list_commits = AsyncMock(side_effect=RuntimeError("boom"))
        installations = MagicMock()
        installations.repos_for_org = AsyncMock(return_value=["x/y"])
        source = GitHubCommitSource(gh_client, installations, "org_abc")
        assert await source.fetch("q", recency_days=7, cap=5) == []

    def test_enabled_for_org_checks_installation(self):
        gh_client = MagicMock()
        installations = MagicMock()
        installations.is_installed_sync = MagicMock(return_value=True)
        source = GitHubCommitSource(gh_client, installations, "org_abc")
        assert source.enabled_for_org("org_abc") is True
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_work_context_sources.py::TestGitHubCommitSource -v`
Expected: FAIL

- [ ] **Step 3: Implement GitHubCommitSource**

Create `extensions/canon-slack/src/canon_slack/work_context/sources/github_commits.py`:

```python
"""GitHub commit source — recent default-branch commits matching keywords."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from canon_slack.work_context.models import WorkContextItem

logger = logging.getLogger(__name__)


def _commit_matches_query(commit: dict, query: str) -> bool:
    """True if the commit message OR any changed file path contains the query (case-insensitive)."""
    q = query.lower()
    msg = (commit.get("commit", {}).get("message") or "").lower()
    if q in msg:
        return True
    for f in commit.get("files", []):
        if q in (f.get("filename") or "").lower():
            return True
    return False


class GitHubCommitSource:
    name = "github_commit"

    def __init__(self, gh_client: Any, installations: Any, org_id: str) -> None:
        self._gh = gh_client
        self._installations = installations
        self._org_id = org_id

    def enabled_for_org(self, org_id: str) -> bool:
        try:
            return self._installations.is_installed_sync(org_id)
        except Exception:
            return False

    async def fetch(
        self, query: str, recency_days: int, cap: int
    ) -> list[WorkContextItem]:
        try:
            repos = await self._installations.repos_for_org(self._org_id)
        except Exception:
            logger.warning("GitHubCommitSource: failed to list repos", exc_info=True)
            return []

        items: list[WorkContextItem] = []
        for repo in repos:
            try:
                commits = await self._gh.list_commits(
                    repo=repo, recency_days=recency_days, limit=cap * 3
                )
            except Exception:
                logger.warning(
                    "GitHubCommitSource: list_commits failed for %s",
                    repo,
                    exc_info=True,
                )
                continue

            for commit in commits:
                if not _commit_matches_query(commit, query):
                    continue
                try:
                    msg_first_line = (
                        commit["commit"]["message"].split("\n", 1)[0][:120]
                    )
                    items.append(
                        WorkContextItem(
                            source=self.name,
                            title=msg_first_line,
                            summary=f"by {commit['commit']['author'].get('name', 'unknown')} in {repo}",
                            url=commit["html_url"],
                            timestamp=datetime.fromisoformat(
                                commit["commit"]["author"]["date"].replace(
                                    "Z", "+00:00"
                                )
                            ),
                            metadata={"sha": commit["sha"], "repo": repo},
                        )
                    )
                except Exception:
                    logger.debug("Skipping malformed commit", exc_info=True)

        return items[:cap]
```

**Note for the implementer:** verify `GitHubClient.list_commits(repo, recency_days, limit)` exists. If not, add it using the GitHub `GET /repos/{owner}/{repo}/commits?since=...` API.

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_slack_work_context_sources.py::TestGitHubCommitSource -v`
Expected: 3 PASS

- [ ] **Step 5: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/work_context/sources/github_commits.py tests/test_slack_work_context_sources.py
git commit -m "feat(slack): add GitHubCommitSource for work_context"
```

---

### Task 11: `TicketSource` (multi-adapter fanout)

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/work_context/sources/tickets.py`
- Modify: `tests/test_slack_work_context_sources.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_slack_work_context_sources.py`:

```python
from canon_slack.work_context.sources.tickets import TicketSource


class TestTicketSource:
    @pytest.mark.asyncio
    async def test_fans_out_to_connected_adapters(self):
        linear_adapter = MagicMock(name="linear")
        linear_adapter.search_tickets = AsyncMock(
            return_value=[
                {
                    "id": "L-1",
                    "title": "Ticket A",
                    "url": "https://linear.app/x/issue/L-1",
                    "updated_at": datetime(2026, 5, 1, tzinfo=timezone.utc),
                    "state": "in_progress",
                    "summary": "do thing",
                    "source": "linear_ticket",
                }
            ]
        )
        adapters = {"linear": linear_adapter}

        source = TicketSource(adapters, "org_abc")
        items = await source.fetch("ticket", recency_days=7, cap=5)

        assert len(items) == 1
        assert items[0].source == "linear_ticket"
        assert items[0].title == "Ticket A"

    @pytest.mark.asyncio
    async def test_one_adapter_failure_isolated(self):
        good = MagicMock()
        good.search_tickets = AsyncMock(
            return_value=[
                {
                    "id": "G-1",
                    "title": "ok",
                    "url": "u",
                    "updated_at": datetime.now(timezone.utc),
                    "state": "open",
                    "summary": "s",
                    "source": "linear_ticket",
                }
            ]
        )
        bad = MagicMock()
        bad.search_tickets = AsyncMock(side_effect=RuntimeError("jira down"))
        adapters = {"linear": good, "jira": bad}

        source = TicketSource(adapters, "org_abc")
        items = await source.fetch("q", recency_days=7, cap=5)
        # Linear's item still present despite Jira failure
        assert any(i.title == "ok" for i in items)

    def test_enabled_for_org_true_when_any_adapter_present(self):
        source = TicketSource({"linear": MagicMock()}, "org_abc")
        assert source.enabled_for_org("org_abc") is True

    def test_enabled_for_org_false_when_no_adapters(self):
        source = TicketSource({}, "org_abc")
        assert source.enabled_for_org("org_abc") is False
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_work_context_sources.py::TestTicketSource -v`
Expected: FAIL

- [ ] **Step 3: Implement TicketSource**

Create `extensions/canon-slack/src/canon_slack/work_context/sources/tickets.py`:

```python
"""Ticket source — fans out across all connected sync adapters (Linear/Jira/GH Issues)."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from canon_slack.work_context.models import WorkContextItem

logger = logging.getLogger(__name__)


class TicketSource:
    """Aggregates tickets across all sync adapters configured for the org.

    `adapters` is a dict of adapter_name -> adapter instance. Each adapter
    must expose `async search_tickets(query, recency_days, limit) ->
    list[dict]` returning rows with: id, title, url, updated_at, state,
    summary, source.
    """

    name = "ticket"

    def __init__(self, adapters: dict[str, Any], org_id: str) -> None:
        self._adapters = adapters
        self._org_id = org_id

    def enabled_for_org(self, org_id: str) -> bool:
        return len(self._adapters) > 0

    async def fetch(
        self, query: str, recency_days: int, cap: int
    ) -> list[WorkContextItem]:
        if not self._adapters:
            return []

        per_adapter_cap = max(1, cap // len(self._adapters))

        async def _safe_search(name: str, adapter: Any) -> list[dict]:
            try:
                return await adapter.search_tickets(
                    query=query, recency_days=recency_days, limit=per_adapter_cap
                )
            except Exception:
                logger.warning(
                    "TicketSource: adapter %s search_tickets failed",
                    name,
                    exc_info=True,
                )
                return []

        results = await asyncio.gather(
            *[_safe_search(name, ad) for name, ad in self._adapters.items()]
        )

        items: list[WorkContextItem] = []
        for adapter_results in results:
            for ticket in adapter_results:
                try:
                    items.append(
                        WorkContextItem(
                            source=ticket.get("source", "ticket"),
                            title=ticket["title"],
                            summary=f"[{ticket.get('state', '?')}] {ticket.get('summary', '')[:200]}",
                            url=ticket["url"],
                            timestamp=ticket["updated_at"],
                            metadata={"id": ticket["id"], "state": ticket.get("state")},
                        )
                    )
                except Exception:
                    logger.debug("Skipping malformed ticket", exc_info=True)

        return items[:cap]
```

**Note for the implementer:** verify each existing sync adapter (`canon.sync.adapters.{linear,jira,github_issues}`) has or can gain a `search_tickets(query, recency_days, limit)` method. The expected return shape is documented in the docstring. If adapters don't have this method, add it as a thin wrapper around their existing search/list APIs.

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_slack_work_context_sources.py::TestTicketSource -v`
Expected: 4 PASS

- [ ] **Step 5: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/work_context/sources/tickets.py tests/test_slack_work_context_sources.py
git commit -m "feat(slack): add TicketSource (multi-adapter fanout) for work_context"
```

---

### Task 12: `SlackThreadSource`

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/work_context/sources/slack_threads.py`
- Modify: `tests/test_slack_work_context_sources.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_slack_work_context_sources.py`:

```python
from canon_slack.work_context.sources.slack_threads import SlackThreadSource


class TestSlackThreadSource:
    @pytest.mark.asyncio
    async def test_returns_messages_from_user_channels(self):
        slack_client = AsyncMock()
        slack_client.users_conversations = AsyncMock(
            return_value={"channels": [{"id": "C1"}, {"id": "C2"}]}
        )
        slack_client.search_messages = AsyncMock(
            return_value={
                "messages": {
                    "matches": [
                        {
                            "text": "we should fix the auth bug",
                            "permalink": "https://slack.com/archives/C1/p123",
                            "ts": "1714560000.0",
                            "channel": {"id": "C1", "name": "eng-platform"},
                            "user": "U1",
                        }
                    ]
                }
            }
        )

        source = SlackThreadSource(slack_client, "T1", "U_caller")
        items = await source.fetch("auth", recency_days=7, cap=5)

        assert len(items) == 1
        assert items[0].source == "slack_thread"
        assert "auth bug" in items[0].summary

    @pytest.mark.asyncio
    async def test_returns_empty_when_user_has_no_channels(self):
        slack_client = AsyncMock()
        slack_client.users_conversations = AsyncMock(return_value={"channels": []})
        source = SlackThreadSource(slack_client, "T1", "U_caller")
        assert await source.fetch("q", recency_days=7, cap=5) == []

    @pytest.mark.asyncio
    async def test_returns_empty_on_search_failure(self):
        slack_client = AsyncMock()
        slack_client.users_conversations = AsyncMock(
            return_value={"channels": [{"id": "C1"}]}
        )
        slack_client.search_messages = AsyncMock(side_effect=RuntimeError("429"))
        source = SlackThreadSource(slack_client, "T1", "U_caller")
        assert await source.fetch("q", recency_days=7, cap=5) == []

    @pytest.mark.asyncio
    async def test_excludes_messages_from_non_user_channels(self):
        slack_client = AsyncMock()
        slack_client.users_conversations = AsyncMock(
            return_value={"channels": [{"id": "C1"}]}
        )
        slack_client.search_messages = AsyncMock(
            return_value={
                "messages": {
                    "matches": [
                        {
                            "text": "in C1",
                            "permalink": "p1",
                            "ts": "1714560000.0",
                            "channel": {"id": "C1", "name": "x"},
                            "user": "U1",
                        },
                        {
                            "text": "in C99 (private — user not in)",
                            "permalink": "p2",
                            "ts": "1714560000.0",
                            "channel": {"id": "C99", "name": "secret"},
                            "user": "U2",
                        },
                    ]
                }
            }
        )

        source = SlackThreadSource(slack_client, "T1", "U_caller")
        items = await source.fetch("q", recency_days=7, cap=5)
        assert len(items) == 1
        assert items[0].metadata["channel_id"] == "C1"

    def test_enabled_for_org_true_with_token(self):
        source = SlackThreadSource(AsyncMock(), "T1", "U")
        assert source.enabled_for_org("any") is True
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_work_context_sources.py::TestSlackThreadSource -v`
Expected: FAIL

- [ ] **Step 3: Implement SlackThreadSource**

Create `extensions/canon-slack/src/canon_slack/work_context/sources/slack_threads.py`:

```python
"""Slack thread source — searches messages in channels the asking user is a member of."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from canon_slack.work_context.models import WorkContextItem

logger = logging.getLogger(__name__)


class SlackThreadSource:
    """Returns recent Slack messages matching the query, filtered to the
    asking user's channels (their visibility). Uses Slack's search.messages
    API which respects the bot token's scope.
    """

    name = "slack_thread"

    def __init__(self, slack_client: Any, workspace_id: str, user_id: str) -> None:
        self._slack = slack_client
        self._workspace_id = workspace_id
        self._user_id = user_id

    def enabled_for_org(self, org_id: str) -> bool:
        return True  # bot is configured if we're here

    async def fetch(
        self, query: str, recency_days: int, cap: int
    ) -> list[WorkContextItem]:
        # 1. Get the user's channel IDs
        try:
            convs = await self._slack.users_conversations(
                user=self._user_id,
                types="public_channel,private_channel",
                limit=200,
            )
            user_channel_ids = {c["id"] for c in convs.get("channels", [])}
        except Exception:
            logger.warning(
                "SlackThreadSource: users_conversations failed for %s",
                self._user_id,
                exc_info=True,
            )
            return []

        if not user_channel_ids:
            return []

        # 2. Search messages
        try:
            search = await self._slack.search_messages(
                query=f"{query} after:{_n_days_ago(recency_days)}",
                count=cap * 3,  # over-fetch since we filter
                sort="timestamp",
            )
        except Exception:
            logger.warning("SlackThreadSource: search_messages failed", exc_info=True)
            return []

        matches = (search.get("messages") or {}).get("matches", [])

        # 3. Filter to user's channels and convert
        items: list[WorkContextItem] = []
        for m in matches:
            ch = m.get("channel") or {}
            ch_id = ch.get("id", "")
            if ch_id not in user_channel_ids:
                continue
            try:
                ts_float = float(m["ts"])
                items.append(
                    WorkContextItem(
                        source=self.name,
                        title=f"#{ch.get('name', 'unknown')}",
                        summary=(m.get("text") or "")[:300],
                        url=m.get("permalink", ""),
                        timestamp=datetime.fromtimestamp(ts_float, tz=timezone.utc),
                        metadata={
                            "channel_id": ch_id,
                            "channel_name": ch.get("name"),
                            "user_id": m.get("user"),
                        },
                    )
                )
            except Exception:
                logger.debug("Skipping malformed slack match", exc_info=True)

        return items[:cap]


def _n_days_ago(days: int) -> str:
    """Slack search query format: after:YYYY-MM-DD."""
    from datetime import datetime, timedelta, timezone

    dt = datetime.now(timezone.utc) - timedelta(days=days)
    return dt.strftime("%Y-%m-%d")
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_slack_work_context_sources.py::TestSlackThreadSource -v`
Expected: 5 PASS

- [ ] **Step 5: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/work_context/sources/slack_threads.py tests/test_slack_work_context_sources.py
git commit -m "feat(slack): add SlackThreadSource scoped to user's channels"
```

---

## Phase 4: Coordinator, Intent, Personal

### Task 13: Ranking + token budget

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/work_context/ranking.py`
- Create: `tests/test_slack_work_context_ranking.py`

- [ ] **Step 1: Write the failing test**

Create `tests/test_slack_work_context_ranking.py`:

```python
"""Tests for work_context ranking + token budget enforcement."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from canon_slack.work_context.models import WorkContextItem
from canon_slack.work_context.ranking import (
    apply_token_budget,
    estimate_tokens,
    score_items,
)


def _item(source: str, title: str, days_ago: float = 0) -> WorkContextItem:
    return WorkContextItem(
        source=source,
        title=title,
        summary=title,
        url="u",
        timestamp=datetime.now(timezone.utc) - timedelta(days=days_ago),
    )


def test_score_items_rewards_recency():
    fresh = _item("github_pr", "rate limit", days_ago=0)
    stale = _item("github_pr", "rate limit", days_ago=89)
    score_items([fresh, stale], query="rate limit")
    assert fresh.relevance_score > stale.relevance_score


def test_score_items_rewards_keyword_overlap():
    bullseye = _item("github_pr", "rate limiting on auth endpoints")
    miss = _item("github_pr", "unrelated background job tweak")
    score_items([bullseye, miss], query="rate limit")
    assert bullseye.relevance_score > miss.relevance_score


def test_score_items_uses_source_weight():
    spec = _item("canon_spec", "auth-hardening")
    commit = _item("github_commit", "auth-hardening")
    score_items([spec, commit], query="auth hardening")
    # Specs are weighted higher than commits
    assert spec.relevance_score > commit.relevance_score


def test_estimate_tokens_rough_chars_div_4():
    assert estimate_tokens("a" * 400) == 100
    assert estimate_tokens("") == 0


def test_apply_token_budget_drops_lowest_ranked():
    items = [_item("github_pr", "x" * 4000) for _ in range(10)]
    for i, item in enumerate(items):
        item.relevance_score = float(i)  # 0-9, highest = 9
    kept = apply_token_budget(items, max_tokens=2000)
    # Each item ~1000 tokens; budget 2000 → 2 items kept (top-ranked)
    assert len(kept) == 2
    assert kept[0].relevance_score == 9
    assert kept[1].relevance_score == 8


def test_apply_token_budget_keeps_all_under_budget():
    items = [_item("github_pr", "small")]
    items[0].relevance_score = 0.5
    kept = apply_token_budget(items, max_tokens=10000)
    assert len(kept) == 1
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_work_context_ranking.py -v`
Expected: FAIL

- [ ] **Step 3: Implement ranking**

Create `extensions/canon-slack/src/canon_slack/work_context/ranking.py`:

```python
"""Cross-source ranking and token-budget enforcement for ContextBundle items."""

from __future__ import annotations

import math
from datetime import datetime, timezone

from canon_slack.work_context.models import WorkContextItem


# Weights tuned empirically; see Open Question #1 in the design doc
_SOURCE_WEIGHT: dict[str, float] = {
    "canon_spec": 1.0,
    "canon_pr_analysis": 0.9,
    "github_pr": 0.8,
    "linear_ticket": 0.8,
    "jira_ticket": 0.8,
    "github_issue": 0.8,
    "ticket": 0.8,
    "github_commit": 0.6,
    "slack_thread": 0.5,
}


def _recency_weight(timestamp: datetime, today: datetime | None = None) -> float:
    """Exponential decay: weight ~ e^(-days_old / 30). 30d half-life."""
    today = today or datetime.now(timezone.utc)
    days_old = max(0.0, (today - timestamp).total_seconds() / 86400.0)
    return math.exp(-days_old / 30.0)


def _keyword_overlap(text: str, query: str) -> float:
    """Fraction of query tokens present in text. 0-1."""
    q_tokens = {t for t in query.lower().split() if len(t) > 2}
    if not q_tokens:
        return 0.0
    text_lower = text.lower()
    hits = sum(1 for t in q_tokens if t in text_lower)
    return hits / len(q_tokens)


def score_items(items: list[WorkContextItem], query: str) -> None:
    """Mutates items in place, setting `relevance_score` for each."""
    today = datetime.now(timezone.utc)
    for item in items:
        recency = _recency_weight(item.timestamp, today=today)
        overlap = _keyword_overlap(f"{item.title}\n{item.summary}", query)
        weight = _SOURCE_WEIGHT.get(item.source, 0.5)
        item.relevance_score = recency * (0.3 + 0.7 * overlap) * weight


def estimate_tokens(text: str) -> int:
    """Rough token estimate: ~4 chars per token (OpenAI/Anthropic ballpark)."""
    return len(text) // 4


def apply_token_budget(
    items: list[WorkContextItem], max_tokens: int
) -> list[WorkContextItem]:
    """Sort items by relevance_score desc, then keep until token budget exceeded."""
    sorted_items = sorted(items, key=lambda i: i.relevance_score, reverse=True)
    kept: list[WorkContextItem] = []
    used = 0
    for item in sorted_items:
        item_tokens = estimate_tokens(item.title) + estimate_tokens(item.summary)
        if used + item_tokens > max_tokens:
            continue
        kept.append(item)
        used += item_tokens
    return kept
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_slack_work_context_ranking.py -v`
Expected: 6 PASS

- [ ] **Step 5: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/work_context/ranking.py tests/test_slack_work_context_ranking.py
git commit -m "feat(slack): add work_context ranking and token-budget enforcement"
```

---

### Task 14: Intent classifier

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/work_context/intent.py`
- Create: `tests/test_slack_work_context_intent.py`
- Create: `tests/fixtures/work_context/intent_eval/queries.jsonl`

- [ ] **Step 1: Create the eval queries fixture**

Create `tests/fixtures/work_context/intent_eval/queries.jsonl` with 50 hand-labeled queries (one per line). Format: `{"query": "...", "intent": "lookup|discussion|investigation"}`.

A starter set (the implementer should expand to ~50; 15 here as seed):

```json
{"query": "status of auth-hardening", "intent": "lookup"}
{"query": "list specs in progress", "intent": "lookup"}
{"query": "what's coverage", "intent": "lookup"}
{"query": "my specs", "intent": "lookup"}
{"query": "what specs do I own", "intent": "lookup"}
{"query": "what's happening with auth-hardening", "intent": "discussion"}
{"query": "any blockers on billing this week", "intent": "discussion"}
{"query": "what's the team working on", "intent": "discussion"}
{"query": "did anything ship for the OpenSearch work today", "intent": "discussion"}
{"query": "is there a PR open for the rate limit thing", "intent": "discussion"}
{"query": "why is auth-hardening still in progress after a month", "intent": "investigation"}
{"query": "what was the original reasoning behind the OpenSearch decision", "intent": "investigation"}
{"query": "who knows about the legacy billing code", "intent": "investigation"}
{"query": "which specs have stalled with no activity", "intent": "investigation"}
{"query": "trace why the auth refactor took 3 sprints", "intent": "investigation"}
```

- [ ] **Step 2: Write the failing test**

Create `tests/test_slack_work_context_intent.py`:

```python
"""Tests for the IntentClassifier."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest
from canon_slack.work_context.intent import IntentClassifier
from canon_slack.work_context.models import Intent, RecencyProfile


class TestRegexPath:
    @pytest.mark.asyncio
    async def test_status_query_classified_as_lookup(self):
        classifier = IntentClassifier(claude_client=None)
        intent, recency, conf = await classifier.classify("status of auth-hardening")
        assert intent == Intent.LOOKUP
        assert conf == 1.0

    @pytest.mark.asyncio
    async def test_my_specs_query_classified_as_lookup(self):
        classifier = IntentClassifier(claude_client=None)
        intent, _, conf = await classifier.classify("my specs")
        assert intent == Intent.LOOKUP
        assert conf == 1.0


class TestLLMFallback:
    @pytest.mark.asyncio
    async def test_llm_classification_used_when_no_regex(self):
        client = MagicMock()
        client.is_available = True
        client.complete = MagicMock(
            return_value=MagicMock(
                text='{"intent": "discussion", "recency_profile": "recent", "confidence": 0.9}'
            )
        )
        classifier = IntentClassifier(claude_client=client)
        intent, recency, conf = await classifier.classify(
            "what's happening with auth this week"
        )
        assert intent == Intent.DISCUSSION
        assert recency == RecencyProfile.RECENT
        assert conf == 0.9

    @pytest.mark.asyncio
    async def test_llm_failure_defaults_to_discussion_mixed(self):
        client = MagicMock()
        client.is_available = True
        client.complete = MagicMock(side_effect=RuntimeError("api down"))
        classifier = IntentClassifier(claude_client=client)
        intent, recency, conf = await classifier.classify("ambiguous question")
        assert intent == Intent.DISCUSSION
        assert recency == RecencyProfile.MIXED
        assert conf == 0.0

    @pytest.mark.asyncio
    async def test_llm_malformed_json_defaults_safely(self):
        client = MagicMock()
        client.is_available = True
        client.complete = MagicMock(return_value=MagicMock(text="not json"))
        classifier = IntentClassifier(claude_client=client)
        intent, recency, conf = await classifier.classify("ambiguous")
        assert intent == Intent.DISCUSSION
        assert conf == 0.0

    @pytest.mark.asyncio
    async def test_no_claude_client_defaults_to_discussion(self):
        classifier = IntentClassifier(claude_client=None)
        intent, recency, conf = await classifier.classify("free form question")
        assert intent == Intent.DISCUSSION


class TestEvalSet:
    @pytest.mark.asyncio
    async def test_regex_subset_accuracy_100_percent(self):
        """Among queries the regex matches, accuracy must be 100%."""
        path = Path("tests/fixtures/work_context/intent_eval/queries.jsonl")
        if not path.exists():
            pytest.skip("eval fixture not present")
        cases = [json.loads(line) for line in path.read_text().splitlines() if line]

        classifier = IntentClassifier(claude_client=None)
        regex_hits = []
        for c in cases:
            intent, _, conf = await classifier.classify(c["query"])
            if conf == 1.0:  # regex hit
                regex_hits.append((c, intent))

        assert len(regex_hits) > 0, "No regex matches in eval set — add LOOKUP queries"
        wrong = [(c, got) for c, got in regex_hits if got != c["intent"]]
        assert not wrong, f"Regex misclassifications: {wrong}"
```

- [ ] **Step 3: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_work_context_intent.py -v`
Expected: FAIL

- [ ] **Step 4: Implement IntentClassifier**

Create `extensions/canon-slack/src/canon_slack/work_context/intent.py`:

```python
"""Classify @canon mentions into intent + recency profile."""

from __future__ import annotations

import asyncio
import json
import logging
import re
from typing import Any

from canon.agent.client import AgentConfig
from canon_slack.work_context.models import Intent, RecencyProfile

logger = logging.getLogger(__name__)


# Regex shortcuts — exact matches return Intent.LOOKUP with confidence 1.0
_LOOKUP_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"^(?:what(?:'s| is) the )?status (?:of )?", re.IGNORECASE),
    re.compile(r"^(?:list|show|which) specs?", re.IGNORECASE),
    re.compile(r"^(?:what(?:'s| is)(?: the)? )?coverage", re.IGNORECASE),
    re.compile(r"^my specs?\b", re.IGNORECASE),
    re.compile(r"^what specs? do i own", re.IGNORECASE),
    re.compile(r"^my team\b", re.IGNORECASE),
    re.compile(r"^team coverage", re.IGNORECASE),
]

_LLM_PROMPT = """You classify Slack questions to a small bot. Output ONLY a JSON object on one line. No prose.

Intents:
- "lookup": asking for a specific factual value (status, list, coverage)
- "discussion": asking what's currently happening or in flight
- "investigation": asking why something happened or causal chains over longer history

Recency profiles:
- "recent": last 7 days (use for "what's happening")
- "historical": last 90 days (use for "why did" / "when")
- "mixed": short for messages, long for code (use when uncertain)

Output: {"intent": "...", "recency_profile": "...", "confidence": 0.0-1.0}"""

_LLM_TIMEOUT_SECONDS = 1.0


class IntentClassifier:
    def __init__(self, claude_client: Any | None) -> None:
        self._claude = claude_client

    async def classify(
        self, query: str
    ) -> tuple[Intent, RecencyProfile, float]:
        # 1. Regex shortcut
        for pattern in _LOOKUP_PATTERNS:
            if pattern.match(query):
                return (Intent.LOOKUP, RecencyProfile.RECENT, 1.0)

        # 2. LLM fallback (with timeout)
        if self._claude is None or not getattr(self._claude, "is_available", False):
            return (Intent.DISCUSSION, RecencyProfile.MIXED, 0.0)

        try:
            result = await asyncio.wait_for(
                asyncio.to_thread(
                    self._claude.complete,
                    _LLM_PROMPT,
                    query,
                    AgentConfig(
                        model="claude-haiku-4-5-20251001",
                        max_output_tokens=200,
                        temperature=0,
                    ),
                ),
                timeout=_LLM_TIMEOUT_SECONDS,
            )
            parsed = json.loads(result.text.strip())
            intent = Intent(parsed["intent"])
            recency = RecencyProfile(parsed["recency_profile"])
            conf = float(parsed["confidence"])
            return (intent, recency, conf)
        except asyncio.TimeoutError:
            logger.warning("IntentClassifier: LLM call timed out")
            return (Intent.DISCUSSION, RecencyProfile.MIXED, 0.0)
        except (KeyError, ValueError, json.JSONDecodeError):
            logger.warning("IntentClassifier: LLM returned malformed response")
            return (Intent.DISCUSSION, RecencyProfile.MIXED, 0.0)
        except Exception:
            logger.warning("IntentClassifier: LLM call failed", exc_info=True)
            return (Intent.DISCUSSION, RecencyProfile.MIXED, 0.0)
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/test_slack_work_context_intent.py -v`
Expected: 6 PASS

- [ ] **Step 6: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/work_context/intent.py tests/test_slack_work_context_intent.py tests/fixtures/work_context/intent_eval/queries.jsonl
git commit -m "feat(slack): add IntentClassifier (regex + LLM fallback) for work_context"
```

---

### Task 15: PersonalContext builder + IdentityStore extensions

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/personal_context.py`
- Modify: `extensions/canon-slack/src/canon_slack/identity_store.py`
- Create: `tests/test_slack_personal_context.py`

- [ ] **Step 1: Read existing identity_store.py to understand the public surface**

Run: `grep -n "def " extensions/canon-slack/src/canon_slack/identity_store.py`
Note the existing methods so the new ones don't collide.

- [ ] **Step 2: Write the failing test**

Create `tests/test_slack_personal_context.py`:

```python
"""Tests for build_personal_context."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from canon_slack.personal_context import build_personal_context


class TestBuildPersonalContext:
    @pytest.mark.asyncio
    async def test_returns_none_when_user_unlinked(self):
        identity_store = AsyncMock()
        identity_store.get_github_login = AsyncMock(return_value=None)
        spec_loader = MagicMock()

        pc = await build_personal_context(
            identity_store, spec_loader, user_id="U1", org_id="org_abc"
        )
        assert pc is None

    @pytest.mark.asyncio
    async def test_returns_pc_with_owned_specs_when_linked(self):
        identity_store = AsyncMock()
        identity_store.get_github_login = AsyncMock(return_value="ngerner")
        identity_store.get_team = AsyncMock(return_value="platform")
        spec_loader = MagicMock()
        spec_loader.load = AsyncMock()
        spec_loader.specs_owned_by = MagicMock(
            return_value=[
                MagicMock(slug="auth-hardening", status="in_progress"),
                MagicMock(slug="billing", status="draft"),
            ]
        )

        pc = await build_personal_context(
            identity_store, spec_loader, user_id="U1", org_id="org_abc"
        )
        assert pc is not None
        assert pc.github_login == "ngerner"
        assert pc.team == "platform"
        assert ("auth-hardening", "in_progress") in pc.owned_specs

    @pytest.mark.asyncio
    async def test_returns_pc_without_specs_when_loader_fails(self):
        identity_store = AsyncMock()
        identity_store.get_github_login = AsyncMock(return_value="ngerner")
        identity_store.get_team = AsyncMock(return_value=None)
        spec_loader = MagicMock()
        spec_loader.load = AsyncMock(side_effect=RuntimeError("boom"))

        pc = await build_personal_context(
            identity_store, spec_loader, user_id="U1", org_id="org_abc"
        )
        assert pc is not None
        assert pc.github_login == "ngerner"
        assert pc.owned_specs == []
```

- [ ] **Step 3: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_personal_context.py -v`
Expected: FAIL

- [ ] **Step 4: Add team lookup to IdentityStore**

In `extensions/canon-slack/src/canon_slack/identity_store.py`, add a new method (only if it doesn't already exist):

```python
async def get_team(self, user_id: str) -> str | None:
    """Return the team name for a Slack user, or None if unknown.

    Looks up the linked GitHub login in the org's team membership data.
    Returns None if the user is unlinked or the team data isn't available.
    """
    login = await self.get_github_login(user_id)
    if not login:
        return None
    try:
        async with self._pool.acquire() as conn:
            return await conn.fetchval(
                """
                SELECT team FROM org_members
                WHERE org_id = $1 AND github_login = $2
                LIMIT 1
                """,
                self._org_id,
                login,
            )
    except Exception:
        # Best-effort: missing team is not an error
        return None
```

If the `org_members` table doesn't have a `team` column, adjust to whatever org membership table exists. If no such table exists, return `None` and rely on `get_team` being optional.

- [ ] **Step 5: Implement build_personal_context**

Create `extensions/canon-slack/src/canon_slack/personal_context.py`:

```python
"""Build the <personal_context> block for DM-only Claude prompts."""

from __future__ import annotations

import logging
from typing import Any

from canon_slack.work_context.models import PersonalContext

logger = logging.getLogger(__name__)


async def build_personal_context(
    identity_store: Any,
    spec_loader: Any,
    user_id: str,
    org_id: str,
) -> PersonalContext | None:
    """Assemble personal context for a DM, or return None if the user is unlinked.

    Pure function — does not write state, does not send messages. The caller
    is responsible for the one-time-prompt flow when this returns None.
    """
    try:
        github_login = await identity_store.get_github_login(user_id)
    except Exception:
        logger.debug("get_github_login failed", exc_info=True)
        github_login = None

    if not github_login:
        return None

    team: str | None = None
    try:
        team = await identity_store.get_team(user_id)
    except Exception:
        logger.debug("get_team failed", exc_info=True)

    owned: list[tuple[str, str]] = []
    try:
        await spec_loader.load()
        owned_specs = spec_loader.specs_owned_by(github_login)
        owned = [(s.slug, s.status) for s in owned_specs]
    except Exception:
        logger.warning(
            "build_personal_context: spec loader failed for %s", github_login,
            exc_info=True,
        )

    return PersonalContext(github_login=github_login, team=team, owned_specs=owned)
```

**Note for the implementer:** verify SpecLoader has a `specs_owned_by(github_login)` method. If not, add it (likely a simple filter over `self._specs` matching frontmatter `owner` field). Add a brief test in `tests/test_slack_spec_loader.py`.

- [ ] **Step 6: Run tests to verify they pass**

Run: `uv run pytest tests/test_slack_personal_context.py -v`
Expected: 3 PASS

- [ ] **Step 7: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/personal_context.py extensions/canon-slack/src/canon_slack/identity_store.py tests/test_slack_personal_context.py
git commit -m "feat(slack): add build_personal_context + IdentityStore.get_team"
```

---

### Task 16: WorkContextCoordinator

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/work_context/coordinator.py`
- Create: `tests/test_slack_work_context_coordinator.py`

- [ ] **Step 1: Write the failing test**

Create `tests/test_slack_work_context_coordinator.py`:

```python
"""Tests for WorkContextCoordinator."""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock

import pytest
from canon_slack.work_context.coordinator import WorkContextCoordinator
from canon_slack.work_context.models import (
    ContextBundle,
    Intent,
    PersonalContext,
    RecencyProfile,
    WorkContextItem,
)


def _fake_source(name: str, items: list[WorkContextItem], delay_s: float = 0):
    src = MagicMock()
    src.name = name
    src.enabled_for_org = MagicMock(return_value=True)

    async def fetch(query, recency_days, cap):
        if delay_s:
            await asyncio.sleep(delay_s)
        return items

    src.fetch = fetch
    return src


def _item(source: str, title: str = "x") -> WorkContextItem:
    return WorkContextItem(
        source=source,
        title=title,
        summary="s",
        url="u",
        timestamp=datetime.now(timezone.utc),
    )


class TestCoordinator:
    @pytest.mark.asyncio
    async def test_runs_all_enabled_sources(self):
        sources = [
            _fake_source("canon_spec", [_item("canon_spec", "spec1")]),
            _fake_source("github_pr", [_item("github_pr", "pr1")]),
        ]
        coord = WorkContextCoordinator(
            sources=sources, super_props=MagicMock(), distinct_id="U1"
        )
        bundle = await coord.load(
            query="anything",
            org_id="org_abc",
            intent=Intent.DISCUSSION,
            recency=RecencyProfile.RECENT,
        )
        assert bundle.total_items() == 2
        assert bundle.sources_attempted == 2
        assert bundle.sources_succeeded == 2

    @pytest.mark.asyncio
    async def test_disabled_source_skipped(self):
        good = _fake_source("canon_spec", [_item("canon_spec")])
        disabled = _fake_source("ticket", [])
        disabled.enabled_for_org = MagicMock(return_value=False)
        coord = WorkContextCoordinator(
            sources=[good, disabled], super_props=MagicMock(), distinct_id="U1"
        )
        bundle = await coord.load("q", "org_abc", Intent.DISCUSSION, RecencyProfile.RECENT)
        assert bundle.sources_attempted == 1

    @pytest.mark.asyncio
    async def test_failing_source_does_not_break_others(self):
        good = _fake_source("canon_spec", [_item("canon_spec")])
        bad = MagicMock()
        bad.name = "github_pr"
        bad.enabled_for_org = MagicMock(return_value=True)
        bad.fetch = AsyncMock(side_effect=RuntimeError("boom"))

        coord = WorkContextCoordinator(
            sources=[good, bad], super_props=MagicMock(), distinct_id="U1"
        )
        bundle = await coord.load("q", "org_abc", Intent.DISCUSSION, RecencyProfile.RECENT)
        assert bundle.sources_succeeded == 1
        assert bundle.total_items() == 1

    @pytest.mark.asyncio
    async def test_personal_context_included_when_provided(self):
        coord = WorkContextCoordinator(sources=[], super_props=MagicMock(), distinct_id="U1")
        pc = PersonalContext(github_login="ngerner")
        bundle = await coord.load(
            "q",
            "org_abc",
            Intent.DISCUSSION,
            RecencyProfile.RECENT,
            personal_context=pc,
        )
        assert bundle.personal_context is pc

    @pytest.mark.asyncio
    async def test_progress_callback_fires_per_source(self):
        sources = [
            _fake_source("canon_spec", [_item("canon_spec")], delay_s=0.01),
            _fake_source("github_pr", [_item("github_pr")], delay_s=0.02),
        ]
        coord = WorkContextCoordinator(sources=sources, super_props=MagicMock(), distinct_id="U1")
        callback = AsyncMock()
        await coord.load(
            "q", "org_abc", Intent.DISCUSSION, RecencyProfile.RECENT,
            progress_callback=callback,
        )
        # 2 sources => at least 2 calls
        assert callback.call_count >= 2

    @pytest.mark.asyncio
    async def test_per_source_timeout_enforced(self):
        slow = _fake_source("github_pr", [_item("github_pr")], delay_s=10)
        coord = WorkContextCoordinator(
            sources=[slow], super_props=MagicMock(), distinct_id="U1",
            per_source_timeout=0.05,
        )
        bundle = await coord.load(
            "q", "org_abc", Intent.DISCUSSION, RecencyProfile.RECENT
        )
        # Slow source timed out — counted as attempted but not succeeded
        assert bundle.sources_attempted == 1
        assert bundle.sources_succeeded == 0

    @pytest.mark.asyncio
    async def test_token_budget_applied(self):
        # 30 items, each with a long summary -> should be truncated
        big = [_item("github_pr", title="x" * 4000) for _ in range(30)]
        sources = [_fake_source("github_pr", big)]
        coord = WorkContextCoordinator(
            sources=sources, super_props=MagicMock(), distinct_id="U1",
            max_tokens=1000,
        )
        bundle = await coord.load("q", "org_abc", Intent.DISCUSSION, RecencyProfile.RECENT)
        # Each item ~1000 tokens; budget 1000 → at most 1 kept
        assert bundle.total_items() <= 1
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_work_context_coordinator.py -v`
Expected: FAIL

- [ ] **Step 3: Implement Coordinator**

Create `extensions/canon-slack/src/canon_slack/work_context/coordinator.py`:

```python
"""WorkContextCoordinator: parallel fetch + ranking + token budget + telemetry."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import time
from typing import Any, Awaitable, Callable

from canon_slack.telemetry import (
    EVENT_SOURCE_FETCHED,
    EVENT_WORK_CONTEXT_ASSEMBLED,
    SuperProperties,
    track_slack,
)
from canon_slack.work_context.models import (
    ContextBundle,
    Intent,
    PersonalContext,
    RecencyProfile,
    WorkContextItem,
)
from canon_slack.work_context.ranking import apply_token_budget, score_items
from canon_slack.work_context.sources.base import WorkContextSource

logger = logging.getLogger(__name__)

DEFAULT_PER_SOURCE_TIMEOUT_S = 5.0
DEFAULT_MAX_TOKENS = 6000
DEFAULT_PER_SOURCE_CAP = 10


class WorkContextCoordinator:
    def __init__(
        self,
        sources: list[WorkContextSource],
        super_props: SuperProperties,
        distinct_id: str,
        per_source_timeout: float = DEFAULT_PER_SOURCE_TIMEOUT_S,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        per_source_cap: int = DEFAULT_PER_SOURCE_CAP,
    ) -> None:
        self._sources = sources
        self._super_props = super_props
        self._distinct_id = distinct_id
        self._per_source_timeout = per_source_timeout
        self._max_tokens = max_tokens
        self._per_source_cap = per_source_cap

    async def load(
        self,
        query: str,
        org_id: str,
        intent: Intent,
        recency: RecencyProfile,
        personal_context: PersonalContext | None = None,
        progress_callback: Callable[[str], Awaitable[None]] | None = None,
    ) -> ContextBundle:
        start = time.monotonic()

        enabled = [s for s in self._sources if s.enabled_for_org(org_id)]
        sources_attempted = len(enabled)

        async def _safe_fetch(src: WorkContextSource) -> list[WorkContextItem]:
            t0 = time.monotonic()
            recency_days = recency.days_for_source(src.name)
            try:
                items = await asyncio.wait_for(
                    src.fetch(query, recency_days, self._per_source_cap),
                    timeout=self._per_source_timeout,
                )
                track_slack(
                    EVENT_SOURCE_FETCHED,
                    self._super_props,
                    {
                        "source": src.name,
                        "success": True,
                        "error_type": None,
                        "duration_ms": int((time.monotonic() - t0) * 1000),
                        "items_returned": len(items),
                        "recency_days": recency_days,
                        "cap": self._per_source_cap,
                    },
                    distinct_id=self._distinct_id,
                )
                return items
            except asyncio.TimeoutError:
                track_slack(
                    EVENT_SOURCE_FETCHED,
                    self._super_props,
                    {
                        "source": src.name,
                        "success": False,
                        "error_type": "timeout",
                        "duration_ms": int((time.monotonic() - t0) * 1000),
                        "items_returned": 0,
                        "recency_days": recency_days,
                        "cap": self._per_source_cap,
                    },
                    distinct_id=self._distinct_id,
                )
                return []
            except Exception as exc:
                track_slack(
                    EVENT_SOURCE_FETCHED,
                    self._super_props,
                    {
                        "source": src.name,
                        "success": False,
                        "error_type": type(exc).__name__,
                        "duration_ms": int((time.monotonic() - t0) * 1000),
                        "items_returned": 0,
                        "recency_days": recency_days,
                        "cap": self._per_source_cap,
                    },
                    distinct_id=self._distinct_id,
                )
                logger.warning(
                    "Coordinator: source %s failed", src.name, exc_info=True
                )
                return []

        # Run all sources in parallel; collect via as_completed for progress UI
        tasks = {asyncio.create_task(_safe_fetch(s)): s for s in enabled}
        completed: list[tuple[str, list[WorkContextItem]]] = []
        for fut in asyncio.as_completed(tasks):
            items = await fut
            src = tasks[fut]
            completed.append((src.name, items))
            if progress_callback is not None:
                with contextlib.suppress(Exception):
                    completed_names = " ".join(
                        f"{name}{'✓' if got else '✗'}"
                        for name, got in completed
                    )
                    await progress_callback(completed_names)

        # Aggregate
        all_items: list[WorkContextItem] = []
        sources_succeeded = 0
        for _name, items in completed:
            if items:
                sources_succeeded += 1
            all_items.extend(items)

        total_before_cap = len(all_items)
        score_items(all_items, query=query)
        kept = apply_token_budget(all_items, max_tokens=self._max_tokens)

        bundle = ContextBundle(
            items=kept,
            personal_context=personal_context,
            sources_attempted=sources_attempted,
            sources_succeeded=sources_succeeded,
            total_tokens=sum(
                len(i.title) // 4 + len(i.summary) // 4 for i in kept
            ),
        )

        track_slack(
            EVENT_WORK_CONTEXT_ASSEMBLED,
            self._super_props,
            {
                "sources_attempted": sources_attempted,
                "sources_succeeded": sources_succeeded,
                "total_items_before_cap": total_before_cap,
                "total_items_after_cap": len(kept),
                "total_tokens": bundle.total_tokens,
                "personal_context_injected": personal_context is not None,
                "intent": intent.value,
                "duration_ms": int((time.monotonic() - start) * 1000),
            },
            distinct_id=self._distinct_id,
        )

        return bundle
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_slack_work_context_coordinator.py -v`
Expected: 7 PASS

- [ ] **Step 5: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/work_context/coordinator.py tests/test_slack_work_context_coordinator.py
git commit -m "feat(slack): add WorkContextCoordinator (parallel fetch + ranking + telemetry)"
```

---

### Task 17: WorkContextAgent stub

**Files:**
- Create: `extensions/canon-slack/src/canon_slack/work_context/agent.py`

- [ ] **Step 1: Implement the stub**

Create `extensions/canon-slack/src/canon_slack/work_context/agent.py`:

```python
"""WorkContextAgent — v2 will be a tool-using Claude loop. v1 delegates to coordinator."""

from __future__ import annotations

import logging
from typing import Awaitable, Callable

from canon_slack.work_context.coordinator import WorkContextCoordinator
from canon_slack.work_context.models import (
    ContextBundle,
    Intent,
    PersonalContext,
    RecencyProfile,
)

logger = logging.getLogger(__name__)


class WorkContextAgent:
    """Stub for v2 agent mode. v1 simply delegates to deterministic coordinator.

    Investigation-classified queries route through this class so v2 can
    swap the implementation without touching mentions.py.
    """

    def __init__(self, coordinator: WorkContextCoordinator) -> None:
        self._coordinator = coordinator

    async def investigate(
        self,
        query: str,
        org_id: str,
        recency: RecencyProfile,
        personal_context: PersonalContext | None = None,
        progress_callback: Callable[[str], Awaitable[None]] | None = None,
    ) -> ContextBundle:
        logger.info("WorkContextAgent.investigate (v1 delegating to coordinator)")
        return await self._coordinator.load(
            query=query,
            org_id=org_id,
            intent=Intent.INVESTIGATION,
            recency=recency,
            personal_context=personal_context,
            progress_callback=progress_callback,
        )
```

- [ ] **Step 2: Verify it imports**

Run: `uv run python -c "from canon_slack.work_context.agent import WorkContextAgent; print(WorkContextAgent)"`
Expected: prints the class.

- [ ] **Step 3: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/work_context/agent.py
git commit -m "feat(slack): add WorkContextAgent stub for future v2 tool-using mode"
```

---

## Phase 5: Wire into mentions.py

### Task 18: Rewrite `handle_mention` to use the coordinator

**Files:**
- Modify: `extensions/canon-slack/src/canon_slack/mentions.py`
- Modify: `tests/test_slack_mentions.py`

This task is large. Read both files fully before starting.

- [ ] **Step 1: Add a new test for the work-context flow**

Append to `tests/test_slack_mentions.py`:

```python
class TestWorkContextFlow:
    @pytest.mark.asyncio
    async def test_lookup_intent_uses_existing_fast_path(self, monkeypatch):
        """Lookup queries skip the coordinator entirely."""
        # Existing _try_intent_shortcut should still handle "status of X" queries.
        # No coordinator import should appear in the call path.
        from canon_slack.mentions import _try_intent_shortcut

        with patch("canon_slack.mentions._try_intent_shortcut", return_value="some answer") as shortcut:
            with patch("canon_slack.mentions.WorkContextCoordinator") as coord:
                event = {
                    "text": "<@U123> status of auth-hardening",
                    "user": "U456",
                    "channel": "C1",
                    "ts": "100",
                }
                from canon_slack.mentions import handle_mention
                say = AsyncMock()
                client = MagicMock()
                client.reactions_add = AsyncMock()
                await handle_mention(event, say, client)
                # Coordinator should NOT have been used
                coord.assert_not_called()

    @pytest.mark.asyncio
    async def test_discussion_intent_uses_coordinator(self, monkeypatch):
        """Discussion intent routes through coordinator with progressive UI."""
        # This is largely covered by the integration test (Task 21);
        # the unit test here verifies that when the feature flag is on
        # and the intent is non-LOOKUP, the coordinator is invoked.
        # See tests/integration/test_slack_smarter_bot.py for full flow.
        pass

    @pytest.mark.asyncio
    async def test_feature_flag_off_keeps_legacy_behavior(self, monkeypatch):
        """When work_context.enabled=False, mentions.py uses today's path (no coordinator)."""
        # Mock the config lookup to return enabled=False
        # Verify coordinator is not invoked
        # See implementation step for the feature-flag check
        pass
```

(The two pass-through tests above are placeholders to remind you of integration test coverage; full coverage lives in Task 21's integration test.)

- [ ] **Step 2: Read the current handle_mention**

Run: `cat extensions/canon-slack/src/canon_slack/mentions.py | head -250`
Read it fully — you're rewriting the body of `handle_mention`. Note the existing patterns: `_rate_limiter.check`, the `:thought_balloon:` thinking message, the eyes/checkmark reactions.

- [ ] **Step 3: Implement the rewrite**

Edit `extensions/canon-slack/src/canon_slack/mentions.py`:

Add new imports near the top:

```python
from canon_slack.personal_context import build_personal_context
from canon_slack.prompt_store import PromptStore
from canon_slack.telemetry import (
    EVENT_INTENT_CLASSIFIED,
    EVENT_MENTION_HANDLED,
    SuperProperties,
    track_slack,
)
from canon_slack.work_context.agent import WorkContextAgent
from canon_slack.work_context.coordinator import WorkContextCoordinator
from canon_slack.work_context.intent import IntentClassifier
from canon_slack.work_context.models import Intent
from canon_slack.work_context.sources.canon_pr_analysis import CanonPRAnalysisSource
from canon_slack.work_context.sources.canon_specs import CanonSpecSource
from canon_slack.work_context.sources.github_commits import GitHubCommitSource
from canon_slack.work_context.sources.github_prs import GitHubPRSource
from canon_slack.work_context.sources.slack_threads import SlackThreadSource
from canon_slack.work_context.sources.tickets import TicketSource
```

Replace the body of `handle_mention` (find the existing definition and replace it). Keep the existing `extract_query`, rate limiter check, and eyes/checkmark patterns. Wrap the new logic such that the feature flag check happens early and falls back to today's behavior when off:

```python
async def handle_mention(event: dict, say: Any, client: Any) -> None:
    """Handle @canon mentions in channels (and DMs via handle_dm)."""
    user_id = event.get("user", "")
    channel = event.get("channel", "")
    ts = event.get("ts", "")
    thread_ts = event.get("thread_ts", ts)
    text = event.get("text", "")
    is_dm = event.get("channel_type") == "im"
    workspace_id = event.get("team", "")

    query = extract_query(text)
    if not query:
        await say(text="Please include a question after mentioning me!", thread_ts=thread_ts)
        return

    # Feature flag check — read from canon.main runtime state
    from canon.main import settings
    work_context_enabled = _get_work_context_enabled()

    org_id = await _resolve_org_id_for_workspace(workspace_id)
    super_props = SuperProperties(
        slack_workspace_id=workspace_id,
        org_id=org_id,
        extension_version=_extension_version(),
    )

    start_ms = time.monotonic()

    # Rate limit check
    if not _rate_limiter.check(user_id):
        await say(
            text=":hourglass: You've hit the rate limit (10 queries/minute). Please wait a moment.",
            thread_ts=thread_ts,
        )
        track_slack(
            EVENT_MENTION_HANDLED,
            super_props,
            {
                "surface": "dm" if is_dm else "channel_mention",
                "rate_limited": True,
                "success": False,
                "duration_ms": int((time.monotonic() - start_ms) * 1000),
            },
            distinct_id=user_id,
        )
        return

    # Intent classification (always runs — both for fast path and coordinator)
    intent_t0 = time.monotonic()
    classifier = _get_intent_classifier()
    intent, recency, confidence = await classifier.classify(query)
    classifier_kind = "regex" if confidence == 1.0 else "llm"

    track_slack(
        EVENT_INTENT_CLASSIFIED,
        super_props,
        {
            "intent": intent.value,
            "recency_profile": recency.value,
            "confidence": confidence,
            "classifier": classifier_kind,
            "duration_ms": int((time.monotonic() - intent_t0) * 1000),
        },
        distinct_id=user_id,
    )

    # LOOKUP intent → existing fast path
    if intent == Intent.LOOKUP:
        shortcut_response = await _try_intent_shortcut(query)
        if shortcut_response is not None:
            await say(text=shortcut_response, thread_ts=thread_ts)
            with contextlib.suppress(Exception):
                await client.reactions_add(channel=channel, timestamp=ts, name="zap")
            track_slack(
                EVENT_MENTION_HANDLED,
                super_props,
                {
                    "surface": "dm" if is_dm else "channel_mention",
                    "intent": intent.value,
                    "personal_context_injected": False,
                    "claude_called": False,
                    "rate_limited": False,
                    "work_context_loaded": False,
                    "success": True,
                    "duration_ms": int((time.monotonic() - start_ms) * 1000),
                },
                distinct_id=user_id,
            )
            return
        # Fall through if shortcut returned None — treat as discussion

    # If feature flag off: fall back to today's behavior (legacy spec-only loading)
    if not work_context_enabled:
        await _legacy_handle_nl(event, say, client, query, super_props, start_ms)
        return

    # Discussion / Investigation → coordinator path
    with contextlib.suppress(Exception):
        await client.reactions_add(channel=channel, timestamp=ts, name="eyes")

    thinking_msg = await client.chat_postMessage(
        channel=channel,
        thread_ts=thread_ts,
        text=":thought_balloon: Thinking...",
    )
    thinking_ts = thinking_msg.get("ts")

    async def _progress(status: str) -> None:
        with contextlib.suppress(Exception):
            await client.chat_update(
                channel=channel,
                ts=thinking_ts,
                text=f":thought_balloon: {status}",
            )

    # Personal context for DMs
    personal_context = None
    if is_dm:
        identity_store = _get_identity_store()
        spec_loader = _get_spec_loader()
        personal_context = await build_personal_context(
            identity_store, spec_loader, user_id, org_id
        )
        if personal_context is None:
            # Maybe send the one-time link prompt
            prompt_store = _get_prompt_store()
            already_prompted = await prompt_store.has_been_prompted(
                workspace_id, user_id, "link_identity"
            )
            if not already_prompted:
                with contextlib.suppress(Exception):
                    await client.chat_postEphemeral(
                        channel=channel,
                        user=user_id,
                        text=":bulb: Link your GitHub via `/canon link <github-username>` for personalized answers.",
                    )
                await prompt_store.mark_prompted(workspace_id, user_id, "link_identity")

    coordinator = _get_coordinator(super_props, user_id, workspace_id)

    if intent == Intent.INVESTIGATION:
        bundle = await WorkContextAgent(coordinator).investigate(
            query=query,
            org_id=org_id,
            recency=recency,
            personal_context=personal_context,
            progress_callback=_progress,
        )
    else:
        bundle = await coordinator.load(
            query=query,
            org_id=org_id,
            intent=intent,
            recency=recency,
            personal_context=personal_context,
            progress_callback=_progress,
        )

    # Hand off to existing _process_nl_query with the bundle's formatted context
    thread_history = await _get_thread_history(client, channel, thread_ts, limit=10)
    spec_context = bundle.format_for_claude()

    try:
        response = await _process_nl_query(query, thread_history, spec_context)
        with contextlib.suppress(Exception):
            await client.chat_update(channel=channel, ts=thinking_ts, text=response)
        with contextlib.suppress(Exception):
            await client.reactions_remove(channel=channel, timestamp=ts, name="eyes")
            await client.reactions_add(channel=channel, timestamp=ts, name="white_check_mark")

        track_slack(
            EVENT_MENTION_HANDLED,
            super_props,
            {
                "surface": "dm" if is_dm else "channel_mention",
                "intent": intent.value,
                "personal_context_injected": personal_context is not None,
                "claude_called": True,
                "rate_limited": False,
                "work_context_loaded": True,
                "work_context_sources_succeeded": bundle.sources_succeeded,
                "success": True,
                "duration_ms": int((time.monotonic() - start_ms) * 1000),
            },
            distinct_id=user_id,
        )
    except Exception:
        logger.error("handle_mention: NL processing failed", exc_info=True)
        with contextlib.suppress(Exception):
            await client.chat_update(
                channel=channel,
                ts=thinking_ts,
                text=":x: I couldn't answer that right now. Please try again later.",
            )
        with contextlib.suppress(Exception):
            await client.reactions_remove(channel=channel, timestamp=ts, name="eyes")
        track_slack(
            EVENT_MENTION_HANDLED,
            super_props,
            {
                "surface": "dm" if is_dm else "channel_mention",
                "intent": intent.value,
                "claude_called": True,
                "success": False,
                "error_type": "claude_api",
                "duration_ms": int((time.monotonic() - start_ms) * 1000),
            },
            distinct_id=user_id,
        )
```

Add helper functions at the bottom of `mentions.py`:

```python
def _extension_version() -> str:
    """Return the canon-slack extension version. Best-effort."""
    try:
        from importlib.metadata import version
        return version("canon-slack")
    except Exception:
        return "unknown"


async def _resolve_org_id_for_workspace(workspace_id: str) -> str:
    """Resolve a Slack workspace_id to a Canon org_id via SlackInstallStore."""
    if not workspace_id:
        return "unknown"
    try:
        from canon_slack.install import SlackInstallStore
        from canon.main import app
        store = SlackInstallStore(app.state.db_pool)
        installation = await store.get_by_workspace(workspace_id)
        return installation.org_id if installation else "unknown"
    except Exception:
        return "unknown"


def _get_work_context_enabled() -> bool:
    """Read the work_context.enabled feature flag from the loaded CANON.yaml config.

    For multi-tenant cloud, this is per-org and resolved via the org's repo CANON.yaml.
    For self-hosted single-org, falls back to the global setting.
    """
    try:
        from canon.main import app
        config = getattr(app.state, "canon_config", None)
        if config and getattr(config.slack, "work_context", None):
            return config.slack.work_context.enabled
    except Exception:
        pass
    return False


# Singletons constructed lazily and cached on app.state
def _get_intent_classifier():
    from canon.main import app
    if not hasattr(app.state, "_intent_classifier"):
        from canon.agent.client import ClaudeClient
        app.state._intent_classifier = IntentClassifier(claude_client=ClaudeClient())
    return app.state._intent_classifier


def _get_identity_store():
    from canon.main import app
    return app.state.slack_identity_store


def _get_spec_loader():
    from canon.main import app
    return app.state.slack_spec_loader


def _get_prompt_store():
    from canon.main import app
    if not hasattr(app.state, "slack_prompt_store"):
        app.state.slack_prompt_store = PromptStore(app.state.db_pool)
    return app.state.slack_prompt_store


def _get_coordinator(
    super_props: SuperProperties, user_id: str, workspace_id: str
) -> WorkContextCoordinator:
    from canon.main import app
    # Build sources fresh per request (some are user/workspace-scoped)
    spec_loader = _get_spec_loader()
    pool = app.state.db_pool
    gh_client = app.state.github_client
    installations = app.state.github_installations
    slack_client = app.state.slack_client
    sync_adapters = getattr(app.state, "sync_adapters", {})

    sources = [
        CanonSpecSource(spec_loader),
        CanonPRAnalysisSource(pool, super_props.org_id),
        GitHubPRSource(gh_client, installations, super_props.org_id),
        GitHubCommitSource(gh_client, installations, super_props.org_id),
        TicketSource(sync_adapters, super_props.org_id),
        SlackThreadSource(slack_client, workspace_id, user_id),
    ]
    return WorkContextCoordinator(
        sources=sources, super_props=super_props, distinct_id=user_id
    )


async def _legacy_handle_nl(
    event: dict, say: Any, client: Any, query: str,
    super_props: SuperProperties, start_ms: float,
) -> None:
    """Pre-coordinator behavior: load specs only, call Claude.

    Preserves the original mentions.py behavior when the feature flag is off.
    Replicates the original lines (eyes reaction, thinking message, NL processing,
    checkmark reaction). Track the same telemetry for parity.
    """
    user_id = event.get("user", "")
    channel = event.get("channel", "")
    ts = event.get("ts", "")
    thread_ts = event.get("thread_ts", ts)
    is_dm = event.get("channel_type") == "im"

    with contextlib.suppress(Exception):
        await client.reactions_add(channel=channel, timestamp=ts, name="eyes")

    thinking_msg = await client.chat_postMessage(
        channel=channel,
        thread_ts=thread_ts,
        text=":thought_balloon: Thinking...",
    )
    thinking_ts = thinking_msg.get("ts")

    try:
        thread_history = await _get_thread_history(client, channel, thread_ts, limit=10)
        spec_context = await _load_spec_context(query)
        response = await _process_nl_query(query, thread_history, spec_context)
        with contextlib.suppress(Exception):
            await client.chat_update(channel=channel, ts=thinking_ts, text=response)
        with contextlib.suppress(Exception):
            await client.reactions_remove(channel=channel, timestamp=ts, name="eyes")
            await client.reactions_add(channel=channel, timestamp=ts, name="white_check_mark")

        track_slack(
            EVENT_MENTION_HANDLED,
            super_props,
            {
                "surface": "dm" if is_dm else "channel_mention",
                "intent": "discussion",
                "personal_context_injected": False,
                "claude_called": True,
                "rate_limited": False,
                "work_context_loaded": False,  # legacy path
                "success": True,
                "duration_ms": int((time.monotonic() - start_ms) * 1000),
            },
            distinct_id=user_id,
        )
    except Exception:
        logger.error("legacy NL handler failed", exc_info=True)
        with contextlib.suppress(Exception):
            await client.chat_update(
                channel=channel, ts=thinking_ts,
                text=":x: I couldn't answer that right now. Please try again later.",
            )
        with contextlib.suppress(Exception):
            await client.reactions_remove(channel=channel, timestamp=ts, name="eyes")
```

- [ ] **Step 4: Run all slack tests to verify nothing regressed**

Run: `uv run pytest tests/test_slack_mentions.py -v`
Expected: All existing tests pass + the new TestWorkContextFlow tests pass.

Run: `uv run pytest tests/ -k slack -v`
Expected: All slack tests still pass.

- [ ] **Step 5: Commit**

```bash
git add extensions/canon-slack/src/canon_slack/mentions.py tests/test_slack_mentions.py
git commit -m "feat(slack): wire WorkContextCoordinator into handle_mention behind feature flag"
```

---

## Phase 6: §10 Telemetry Events for Other Handlers

### Task 19: Add 8 §10 telemetry events across other slack handlers

**Files (modify each):**
- `extensions/canon-slack/src/canon_slack/commands.py` — `slack_command_invoked`
- `extensions/canon-slack/src/canon_slack/actions.py` — `slack_action_clicked`
- `extensions/canon-slack/src/canon_slack/home_tab.py` — `slack_home_tab_opened`
- `extensions/canon-slack/src/canon_slack/new_spec.py` — `slack_spec_created`
- `extensions/canon-slack/src/canon_slack/notifications.py` — `slack_notification_dispatched`
- `extensions/canon-slack/src/canon_slack/digest.py` — `slack_digest_sent`
- `extensions/canon-slack/src/canon_slack/install.py` — `slack_identity_linked` (on link command success)

This is a mechanical pass: at each handler's success/failure point, call `track_slack(...)` with the appropriate event name, super_props, and properties per `slack-product-experience.md` §10.1 + the design doc §6.

- [ ] **Step 1: Write a focused test for one handler's instrumentation**

Append to `tests/test_slack_commands.py` (or wherever the existing commands tests live):

```python
class TestCommandTelemetry:
    @pytest.mark.asyncio
    async def test_status_subcommand_emits_command_invoked_event(self):
        with patch("canon_slack.commands.track_slack") as mock_track:
            # Set up the body of /canon status invocation
            ack = AsyncMock()
            command = {
                "user_id": "U1",
                "team_id": "T1",
                "text": "status auth-hardening",
            }
            from canon_slack.commands import handle_canon_command
            await handle_canon_command(ack, command, AsyncMock(), AsyncMock())
            # Verify telemetry emission (one of the calls is slack_command_invoked)
            assert any(
                call.args[0] == "slack_command_invoked"
                for call in mock_track.call_args_list
            )
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_slack_commands.py::TestCommandTelemetry -v`
Expected: FAIL (track_slack not yet called)

- [ ] **Step 3: Wire telemetry into commands.py**

In `extensions/canon-slack/src/canon_slack/commands.py`, add at the top:

```python
from canon_slack.telemetry import (
    EVENT_COMMAND_INVOKED,
    SuperProperties,
    track_slack,
)
```

In the main `handle_canon_command` (or whatever the dispatcher is named), wrap the dispatch with timing + a single `track_slack(EVENT_COMMAND_INVOKED, ...)` call:

```python
async def handle_canon_command(ack, command, client, say):
    await ack()
    start = time.monotonic()
    user_id = command.get("user_id", "")
    workspace_id = command.get("team_id", "")
    org_id = await _resolve_org_id_for_workspace(workspace_id)
    super_props = SuperProperties(
        slack_workspace_id=workspace_id,
        org_id=org_id,
        extension_version=_extension_version(),
    )
    text = command.get("text", "")
    subcommand = (text.split() or ["help"])[0]

    success = True
    try:
        # ... existing dispatch logic ...
        pass
    except Exception:
        success = False
        logger.error("handle_canon_command failed", exc_info=True)
    finally:
        track_slack(
            EVENT_COMMAND_INVOKED,
            super_props,
            {
                "subcommand": subcommand,
                "channel_type": _channel_type_from_command(command),
                "success": success,
                "duration_ms": int((time.monotonic() - start) * 1000),
            },
            distinct_id=user_id,
        )
```

- [ ] **Step 4: Repeat for each remaining handler**

Apply the same pattern to:
- `actions.py` — emit `EVENT_ACTION_CLICKED` per action handler with `action_id`, `permission_denied`, `success`
- `home_tab.py` — emit `EVENT_HOME_TAB_OPENED` in `app_home_opened` handler with `is_linked`, `owned_specs_count`
- `new_spec.py` — emit `EVENT_SPEC_CREATED` on successful spec creation with `team`, `type`
- `notifications.py` — emit `EVENT_NOTIFICATION_DISPATCHED` in each `send_*` method with `event_type`, `outcome`
- `digest.py` — emit `EVENT_DIGEST_SENT` after digest dispatch with `team`, `specs_in_digest`
- `install.py` — emit `EVENT_IDENTITY_LINKED` after successful `/canon link` with `method`

For each, add 1 focused test verifying the event is fired, then add the `track_slack` call.

- [ ] **Step 5: Run all slack tests**

Run: `uv run pytest tests/ -k slack -v`
Expected: all green.

- [ ] **Step 6: Commit (one commit per handler is fine; or single commit)**

```bash
git add extensions/canon-slack/src/canon_slack/{commands,actions,home_tab,new_spec,notifications,digest,install}.py tests/test_slack_commands.py
git commit -m "feat(slack): emit §10 telemetry events from commands/actions/home/new/notifications/digest/install"
```

---

## Phase 7: Integration & Scenario Tests

### Task 20: End-to-end integration test

**Files:**
- Create: `tests/integration/test_slack_smarter_bot.py`
- Create: `tests/mocks/wiremock/slack-smarter-bot/` mappings if needed (follow existing patterns)

- [ ] **Step 1: Write the integration test**

Create `tests/integration/test_slack_smarter_bot.py`:

```python
"""End-to-end integration test for the slack smarter-bot feature.

Brings up the FastAPI + Postgres + WireMock stack via the existing
integration test harness. Runs realistic @canon mentions through the
full coordinator path.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

pytestmark = pytest.mark.integration


@pytest.mark.asyncio
async def test_discussion_mention_runs_coordinator_and_emits_telemetry(
    integration_app,
    wiremock_github,
    wiremock_linear,
    captured_events,
):
    """A discussion-intent @canon mention loads work context and posts a response."""
    # Set up: feature flag enabled, mock Claude to return canned response
    integration_app.state.canon_config.slack.work_context.enabled = True

    with patch("canon_slack.mentions._process_nl_query", new=AsyncMock(return_value="Here's what's happening with auth-hardening: ...")):
        event = {
            "type": "app_mention",
            "user": "U_test",
            "team": "T_test",
            "channel": "C_eng",
            "ts": "1714560000.0",
            "thread_ts": "1714560000.0",
            "text": "<@UCANONBOT> what's going on with the auth-hardening work?",
        }
        say = AsyncMock()
        client = MagicMock()
        client.reactions_add = AsyncMock()
        client.reactions_remove = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ts": "1714560001.0", "ok": True})
        client.chat_update = AsyncMock()

        from canon_slack.mentions import handle_mention
        await handle_mention(event, say, client)

    events = captured_events.get_all_for_user("U_test")
    event_names = [e["event"] for e in events]
    assert "work_context_intent_classified" in event_names
    assert "work_context_source_fetched" in event_names
    assert "work_context_assembled" in event_names
    assert "slack_mention_handled" in event_names

    # Final answer was posted (chat_update called with the canned response)
    assert any(
        "auth-hardening" in str(call) for call in client.chat_update.call_args_list
    )


@pytest.mark.asyncio
async def test_dm_unlinked_user_gets_one_time_prompt(integration_app, captured_events):
    """First DM from an unlinked user posts the link-your-identity nudge.
    Second DM from the same user does not."""
    integration_app.state.canon_config.slack.work_context.enabled = True

    with patch("canon_slack.mentions._process_nl_query", new=AsyncMock(return_value="response")):
        event = {
            "type": "message",
            "channel_type": "im",
            "user": "U_unlinked",
            "team": "T_test",
            "channel": "D_dm",
            "ts": "1714560000.0",
            "text": "what should I work on?",
        }
        say = AsyncMock()
        client = MagicMock()
        client.reactions_add = AsyncMock()
        client.reactions_remove = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ts": "1714560001.0", "ok": True})
        client.chat_postEphemeral = AsyncMock()
        client.chat_update = AsyncMock()

        from canon_slack.mentions import handle_dm
        await handle_dm(event, say, client)
        await handle_dm(event, say, client)  # second DM

    # Ephemeral prompt sent exactly once
    link_prompt_calls = [
        c for c in client.chat_postEphemeral.call_args_list
        if "/canon link" in str(c)
    ]
    assert len(link_prompt_calls) == 1


@pytest.mark.asyncio
async def test_lookup_intent_skips_coordinator(integration_app, captured_events):
    """Lookup queries (regex hit) bypass the coordinator entirely."""
    integration_app.state.canon_config.slack.work_context.enabled = True

    event = {
        "type": "app_mention",
        "user": "U_test",
        "team": "T_test",
        "channel": "C_eng",
        "ts": "1714560000.0",
        "text": "<@UCANONBOT> status of auth-hardening",
    }
    say = AsyncMock()
    client = MagicMock()
    client.reactions_add = AsyncMock()

    from canon_slack.mentions import handle_mention
    await handle_mention(event, say, client)

    events = captured_events.get_all_for_user("U_test")
    event_names = [e["event"] for e in events]

    # Intent classified as lookup, no coordinator events fired
    classified = [e for e in events if e["event"] == "work_context_intent_classified"]
    assert classified[0]["properties"]["intent"] == "lookup"
    assert "work_context_source_fetched" not in event_names
    assert "work_context_assembled" not in event_names


@pytest.mark.asyncio
async def test_feature_flag_off_uses_legacy_path(integration_app, captured_events):
    """When work_context.enabled=False, mention handler does not invoke coordinator."""
    integration_app.state.canon_config.slack.work_context.enabled = False

    with patch("canon_slack.mentions._process_nl_query", new=AsyncMock(return_value="legacy response")):
        event = {
            "type": "app_mention",
            "user": "U_test",
            "team": "T_test",
            "channel": "C_eng",
            "ts": "1714560000.0",
            "text": "<@UCANONBOT> any blockers on billing this week",
        }
        say = AsyncMock()
        client = MagicMock()
        client.reactions_add = AsyncMock()
        client.reactions_remove = AsyncMock()
        client.chat_postMessage = AsyncMock(return_value={"ts": "1.0", "ok": True})
        client.chat_update = AsyncMock()

        from canon_slack.mentions import handle_mention
        await handle_mention(event, say, client)

    events = captured_events.get_all_for_user("U_test")
    event_names = [e["event"] for e in events]
    # Legacy path emits slack_mention_handled with work_context_loaded=False
    handled = [e for e in events if e["event"] == "slack_mention_handled"][0]
    assert handled["properties"]["work_context_loaded"] is False
```

- [ ] **Step 2: Set up the captured_events fixture if it doesn't exist**

Check `tests/integration/conftest.py` for existing fixtures. If `captured_events` doesn't exist, add it as a pytest fixture that patches `canon.analytics.track` to record into a list, and exposes a helper to query by user. If it does exist, use it as-is.

- [ ] **Step 3: Run the integration test**

Run: `devbox run integration` (starts Docker stack)
Then: `uv run pytest tests/integration/test_slack_smarter_bot.py -v`
Expected: 4 PASS

- [ ] **Step 4: Commit**

```bash
git add tests/integration/test_slack_smarter_bot.py
git commit -m "test(slack): add integration tests for smarter-bot end-to-end flow"
```

---

### Task 21: Scenario test extension

**Files:**
- Create: `tests/scenarios/scenario_slack_smarter_bot.py`

- [ ] **Step 1: Write the scenario script**

Create `tests/scenarios/scenario_slack_smarter_bot.py`:

```python
"""Scenario: a small org adopts the smarter-bot feature over a week.

Verifies the full flow: identity linking, discussion-intent answers
with work context, personal context for DMs, source failure resilience,
and telemetry capture.

Run via: devbox run scenario -- scenario_slack_smarter_bot
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

logger = logging.getLogger(__name__)


async def main():
    """Day-by-day scenario walkthrough."""
    logger.info("=== Day 1: User links GitHub identity ===")
    # Simulate /canon link <github-username>
    # Verify slack_identity_linked event fires
    await _simulate_link_command(user_id="U1", workspace="T1", login="ngerner")

    logger.info("=== Day 2: User asks discussion-intent question ===")
    # Simulate @canon mention in #eng-platform
    # Verify coordinator runs, sources fetched, telemetry fires
    await _simulate_mention(
        user_id="U1",
        text="@canon what's happening with auth-hardening?",
        is_dm=False,
    )

    logger.info("=== Day 3: User DMs personal-intent question ===")
    # Simulate DM "what should I work on?"
    # Verify personal context loaded (owned specs included)
    await _simulate_mention(
        user_id="U1",
        text="what should I work on?",
        is_dm=True,
    )

    logger.info("=== Day 4: A source fails — answer still posts ===")
    # Patch LinearTicketSource.search_tickets to raise; verify bundle still assembled
    with patch(
        "canon_slack.work_context.sources.tickets.TicketSource.fetch",
        side_effect=RuntimeError("linear down"),
    ):
        await _simulate_mention(
            user_id="U1",
            text="@canon what's happening with billing?",
            is_dm=False,
        )

    logger.info("=== Verify telemetry counts ===")
    # Expected events:
    # - slack_identity_linked: 1
    # - slack_mention_handled: 3
    # - work_context_intent_classified: 3
    # - work_context_source_fetched: 6 sources × 3 mentions = 18 (with one source failing on day 4)
    # - work_context_assembled: 3
    # Verify these counts via PostHog mock or captured events list


async def _simulate_link_command(user_id: str, workspace: str, login: str):
    # Stub
    pass


async def _simulate_mention(user_id: str, text: str, is_dm: bool):
    # Stub
    pass


if __name__ == "__main__":
    asyncio.run(main())
```

**Note for the implementer:** the existing `tests/scenarios/` framework should provide helpers to simulate Slack events end-to-end. Wire `_simulate_link_command` and `_simulate_mention` to those helpers (look at other scenario files for the pattern, e.g., `scenario_adoption_lifecycle.py` if it exists).

- [ ] **Step 2: Run the scenario**

Run: `devbox run scenario -- scenario_slack_smarter_bot`
Expected: completes without errors; all assertions pass.

- [ ] **Step 3: Commit**

```bash
git add tests/scenarios/scenario_slack_smarter_bot.py
git commit -m "test(slack): add scenario test for smarter-bot adoption lifecycle"
```

---

## Phase 8: Final Steps

### Task 22: Documentation updates

**Files:**
- Modify: `docs/specs/slack-product-experience.md` — mark §3.4 and §10 status:done; mark §3.4 ACs checked
- Modify: `docs-site/guides/slack.md` (or wherever Slack docs live) — document the `slack.work_context.enabled` config flag

- [ ] **Step 1: Update the spec to reflect implementation**

In `docs/specs/slack-product-experience.md`:

- §3.4: change `<!-- canon:system:3.4 status:todo -->` to `<!-- canon:system:3.4 status:done -->`
- §3.4 ACs: check all 9 boxes (`- [ ]` → `- [x]`) and add `<!-- canon:realized-in:PR#XXX file:extensions/canon-slack/src/canon_slack/personal_context.py -->` style pointers
- §3 status: bump back from `in_progress` to `done`
- §10: change `<!-- canon:system:10 status:todo -->` to `<!-- canon:system:10 status:done -->`
- §10 ACs: check all 12 boxes
- §10.1, §10.2, §10.3 sub-section status comments: `status:done`

- [ ] **Step 2: Document the feature flag**

Find the user-facing slack docs (likely `docs-site/guides/slack-app.md` or similar). Add a section:

```markdown
## Work-Context Mode (Smarter Answers)

By default, `@canon` answers questions using only Canon spec data. To enable
work-context mode — where the bot pulls recent PRs, commits, tickets, your
team's Slack threads, and prior PR analyses into its answers — add to your
repo's `CANON.yaml`:

\`\`\`yaml
slack:
  work_context:
    enabled: true
\`\`\`

When enabled, mentions of `@canon` for "discussion" or "investigation" intent
queries (e.g., "what's happening with X", "why did Y take so long") will use
the broader context. Lookup-intent queries (`@canon status of X`,
`@canon list specs`, etc.) bypass this entirely and use the existing fast
path.

Privacy notes:
- Slack thread context is filtered to channels the asking user is a member of
- GitHub PRs/commits and tickets are scoped to your Canon org's installations
  (no cross-org data)
```

- [ ] **Step 3: Run canon CLI to verify spec parsing**

Run: `uv run canon status --spec docs/specs/slack-product-experience.md`
Expected: spec status `done`, 78/78 ACs checked.

- [ ] **Step 4: Commit**

```bash
git add docs/specs/slack-product-experience.md docs-site/
git commit -m "docs(slack): mark §3.4 and §10 done; document slack.work_context.enabled"
```

---

### Task 23: Final lint, format, and full test run

- [ ] **Step 1: Format code**

Run: `uv run ruff format extensions/canon-slack/src/canon_slack/ tests/`
Expected: clean (or auto-fix applied).

- [ ] **Step 2: Lint**

Run: `uv run ruff check extensions/canon-slack/src/canon_slack/ tests/ --fix`
Expected: 0 errors after auto-fix.

- [ ] **Step 3: Run full test suite**

Run: `uv run pytest`
Expected: all green.

- [ ] **Step 4: Commit any auto-fixes**

```bash
git add -u
git diff --cached --quiet || git commit -m "chore: ruff format + lint fixes after smarter-bot implementation"
```

---

### Task 24: Open the PR

- [ ] **Step 1: Push branch**

Run: `git push -u origin worktree-slack-app-enhancements`

- [ ] **Step 2: Create PR**

```bash
gh pr create --title "feat(slack): smarter @canon — work-context loader + telemetry + DM personalization" --body "$(cat <<'EOF'
## Summary

Sub-Project A from the slack enhancements brainstorm: makes `@canon`
work-context-aware (PRs, commits, tickets, user's Slack threads, Canon
spec/PR-analysis data) instead of spec-only. Ships with the in-flight
§3.4 Personalized DM Context and §10 Telemetry from
slack-product-experience.md.

Architecture: hybrid Approach 2 + 3 — per-source loaders with a
deterministic coordinator in v1; agent-mode escape hatch is a stub
that delegates to the coordinator (full agent loop deferred to v2 with
the same loaders becoming Claude tools).

Gated behind `slack.work_context.enabled` (default: false).

Design spec: \`docs/superpowers/specs/2026-05-04-slack-smarter-bot-design.md\`
Implementation plan: \`docs/superpowers/plans/2026-05-04-slack-smarter-bot.md\`

## Test plan

- [ ] Unit tests pass: \`uv run pytest tests/test_slack_*.py -v\`
- [ ] Integration tests pass: \`devbox run integration\` then \`uv run pytest tests/integration/test_slack_smarter_bot.py -v\`
- [ ] Scenario test passes: \`devbox run scenario -- scenario_slack_smarter_bot\`
- [ ] Manual smoke: enable on Canon's own org, mention @canon with "what's happening with this PR" — verify thinking-message progresses and answer cites real PRs/tickets
- [ ] Lint clean: \`uv run ruff check\`
- [ ] Format clean: \`uv run ruff format --check\`

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

- [ ] **Step 3: Verify PR opened**

Expected: PR URL printed; CI starts running.

---

## Self-Review

After completing the plan, run through this checklist mentally before declaring done:

1. **Spec coverage** — every section in the spec has a corresponding task:
   - Architecture (§1) → Tasks 5-17
   - Components (§2) → Tasks 5-17 individually
   - Data flow (§3) → covered by integration test (Task 20)
   - Error handling (§4) → each loader test includes error paths; coordinator test covers source failures
   - Testing (§5) → Tasks 7-22 each include unit tests; Task 20 = integration; Task 21 = scenario
   - Telemetry catalog (§6) → Task 4 (constants) + Task 19 (per-handler instrumentation) + Task 16 (coordinator events)
   - Rollout (§7) → Task 1 (feature flag) + Task 22 (documentation)
   - v2 deferred (§8) → Task 17 (agent stub)
   - Open questions (§9) → Tasks 13 (source weights tuned via #1), 2-3 (table choice from #2), 14 (model from #3); #4 and #5 surface during testing/dogfood

2. **Type consistency** — `WorkContextItem`, `ContextBundle`, `Intent`, `RecencyProfile`, `PersonalContext`, `SuperProperties` are referenced consistently. `coordinator.load()` signature matches across components and tests. Source `name` attribute is a string per source (no collisions).

3. **No placeholders** — every task has concrete code. Three "verify the existing X has Y method" notes flag genuine integration points the implementer must check (GitHub client, sync adapters, IdentityStore.get_team table) — these are explicit instructions, not punted decisions.
