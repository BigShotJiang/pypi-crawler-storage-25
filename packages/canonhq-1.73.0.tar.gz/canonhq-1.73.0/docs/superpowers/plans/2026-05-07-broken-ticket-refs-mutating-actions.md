# Broken Ticket Refs §4 — Mutating Actions Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Wire up the disabled action buttons from §3 (Remove ref / Dismiss / Re-check now) so users can actually clean up broken refs from the dashboard or spec view.

**Architecture:** Three new POST endpoints (`/dismiss`, `/recheck`, `/sections/{id}/remove-ticket-ref`) gated on `Permission.SPECS_WRITE`. Two of them just touch `ticket_ref_status` rows via the `dismiss()` / `force_recheck()` store methods that already exist from §2. The third opens a doc PR via the existing `client.create_doc_pr` helper that strips the `<!-- canon:ticket:... -->` comment from the section's range in the spec markdown. Frontend wires up the existing action button stubs in `BrokenRefBadge.vue` and `BrokenRefsPanel.vue`, and adds a `RemoveTicketRefModal.vue` confirmation step before the destructive action.

**Tech Stack:** FastAPI + Pydantic v2 + asyncpg (backend); Vue 3.5 + TypeScript + TanStack Vue Query + Tailwind (frontend). Branch: `spec/broken-refs-section-4` already created from `origin/main`.

---

## File Structure

**New backend files (1):**
- `tests/test_web/test_broken_refs_mutations.py` — FastAPI TestClient tests for the three new endpoints.
- (Endpoints land in the existing `src/canon/web/routes.py` next to the §3 read endpoints.)
- (Service helper for "remove ticket ref" lands in `src/canon/web/services.py`.)

**New frontend files (1):**
- `frontend/src/components/spec/RemoveTicketRefModal.vue` — confirmation dialog before opening the doc PR.

**Modified backend files (3):**
- `src/canon/web/models.py` — add `DismissBrokenRefRequest`, `RecheckBrokenRefRequest`, `RemoveTicketRefResponse` request/response models.
- `src/canon/web/services.py` — add `remove_ticket_ref(client, content_cache_store, owner, repo, file_path, section_id) -> RemoveTicketRefResult` helper.
- `src/canon/web/routes.py` — register three new endpoints.

**Modified frontend files (3):**
- `frontend/src/api/broken_refs.ts` — add `dismissBrokenRef`, `recheckBrokenRef`, `removeTicketRef` typed wrappers.
- `frontend/src/components/spec/BrokenRefBadge.vue` — wire the three action buttons (callbacks emit / call API; Remove opens the modal first).
- `frontend/src/components/dashboard/BrokenRefsPanel.vue` — wire the per-row Remove + Dismiss buttons.

---

## Task 1: Request/response Pydantic models

**Files:**
- Modify: `src/canon/web/models.py`

- [ ] **Step 1: Add the three models**

```python
class DismissBrokenRefRequest(BaseModel):
    system: Literal["jira", "linear", "github"]
    ticket_ref: str


class RecheckBrokenRefRequest(BaseModel):
    system: Literal["jira", "linear", "github"]
    ticket_ref: str


class RemoveTicketRefResponse(BaseModel):
    pr_number: int
    pr_url: str
```

Place them next to `BrokenRef` / `BrokenRefsApiResponse` from §3.

- [ ] **Step 2: Lint + commit**

```
cd /Users/nickgerner/Code/canon-private && uv run ruff check src/canon/web/models.py && uv run ruff format src/canon/web/models.py
git add src/canon/web/models.py
git commit -m "feat(web): add request/response models for broken-ref mutations"
```

---

## Task 2: `remove_ticket_ref` service helper

**Files:**
- Modify: `src/canon/web/services.py`
- Test: extend `tests/test_web/test_services.py` with a new `TestRemoveTicketRef` class

- [ ] **Step 1: Write the failing tests**

```python
import pytest
from unittest.mock import AsyncMock, MagicMock

from canon.web.services import (
    RemoveTicketRefResult,
    SectionAlreadyUpdatedError,
    SectionNotFoundError,
    remove_ticket_ref,
)


SPEC_WITH_TICKET = """---
title: Test
status: in_progress
---

# Test

## 1. Has broken ticket

<!-- canon:system:1 status:in_progress -->
<!-- canon:ticket:github:456 url:https://github.com/o/r/issues/456 -->

Body
"""


class TestRemoveTicketRef:
    async def test_strips_ticket_line_and_opens_pr(self):
        client = AsyncMock()
        # Mock content cache returns a stored copy
        store = AsyncMock()
        store.get_spec_raw = AsyncMock(return_value=SPEC_WITH_TICKET)
        client.create_doc_pr = AsyncMock(return_value=MagicMock(pr_number=42, pr_url="https://github.com/o/r/pull/42"))
        client.find_open_doc_pr = AsyncMock(return_value=None)

        result = await remove_ticket_ref(
            client, store,
            owner="o", repo="r", file_path="docs/specs/test.md",
            section_id="1",
        )
        assert isinstance(result, RemoveTicketRefResult)
        assert result.pr_number == 42

        # Verify the markdown passed to create_doc_pr does NOT contain the ticket line
        call = client.create_doc_pr.await_args
        files = call.kwargs["files"]
        assert len(files) == 1
        assert "canon:ticket:github:456" not in files[0].content
        # And the section header + body remain
        assert "## 1. Has broken ticket" in files[0].content

    async def test_409_when_existing_pr_for_same_section(self):
        client = AsyncMock()
        store = AsyncMock()
        store.get_spec_raw = AsyncMock(return_value=SPEC_WITH_TICKET)
        client.find_open_doc_pr = AsyncMock(return_value=MagicMock(pr_number=7, pr_url="https://github.com/o/r/pull/7"))

        result = await remove_ticket_ref(
            client, store,
            owner="o", repo="r", file_path="docs/specs/test.md",
            section_id="1",
        )
        # Returns existing PR's metadata instead of creating a new one
        assert result.pr_number == 7
        assert result.already_existed is True
        client.create_doc_pr.assert_not_called()

    async def test_section_not_found_raises(self):
        client = AsyncMock()
        store = AsyncMock()
        store.get_spec_raw = AsyncMock(return_value=SPEC_WITH_TICKET)
        with pytest.raises(SectionNotFoundError):
            await remove_ticket_ref(
                client, store,
                owner="o", repo="r", file_path="docs/specs/test.md",
                section_id="9999",
            )

    async def test_section_without_ticket_link_raises_already_updated(self):
        # Spec where the section exists but no longer has a ticket link
        client = AsyncMock()
        store = AsyncMock()
        store.get_spec_raw = AsyncMock(return_value="""---
title: Test
status: in_progress
---

# Test

## 1. No ticket here

<!-- canon:system:1 status:in_progress -->

Body
""")
        with pytest.raises(SectionAlreadyUpdatedError):
            await remove_ticket_ref(
                client, store,
                owner="o", repo="r", file_path="docs/specs/test.md",
                section_id="1",
            )
```

- [ ] **Step 2: Implement the service helper**

In `src/canon/web/services.py`:

```python
class SectionNotFoundError(Exception):
    """Raised when the requested section_id doesn't exist in the spec."""


class SectionAlreadyUpdatedError(Exception):
    """Raised when the section exists but its ticket_link was already
    removed/changed since the dashboard surfaced this row."""


@dataclass
class RemoveTicketRefResult:
    pr_number: int
    pr_url: str
    already_existed: bool = False


async def remove_ticket_ref(
    client,
    content_cache_store,
    *,
    owner: str,
    repo: str,
    file_path: str,
    section_id: str,
) -> RemoveTicketRefResult:
    """Open a doc PR that strips the ticket-link comment from a section.

    Reads the spec from the content cache (or GitHub if the cache is
    unavailable), parses it, locates the target section, identifies the
    line containing the `<!-- canon:ticket:... -->` comment, drops that
    line, and opens (or returns the existing) doc PR via
    client.create_doc_pr.

    Raises:
      SectionNotFoundError: section_id not in the spec.
      SectionAlreadyUpdatedError: section exists but has no ticket_link
        (someone already removed it; dashboard view is stale).
    """
    raw = None
    if content_cache_store is not None:
        try:
            raw = await content_cache_store.get_spec_raw(f"{owner}/{repo}", file_path)
        except Exception:
            logger.warning("Cache read failed, falling back to GitHub", exc_info=True)
    if raw is None:
        content, _ = await client.get_file_content(owner, repo, file_path)
        raw = content

    parsed = parse_spec(raw, ParseOptions(file_path=file_path))
    target = next(
        (s for s in flatten_sections(parsed.document.sections) if s.id == section_id),
        None,
    )
    if target is None:
        raise SectionNotFoundError(f"section_id={section_id} not found in {owner}/{repo}/{file_path}")
    if target.ticket_link is None:
        raise SectionAlreadyUpdatedError(
            f"section_id={section_id} no longer has a ticket_link; dashboard view is stale"
        )

    # Locate the ticket comment line within the section's [start_line, end_line)
    # range and drop just that line. Lines are 1-indexed in the parser.
    lines = raw.splitlines(keepends=True)
    # line indices use the parser's 1-indexed convention
    ticket_marker = "<!-- canon:ticket:"
    new_lines: list[str] = []
    removed = False
    for idx, line in enumerate(lines, start=1):
        if (
            not removed
            and target.start_line <= idx <= target.end_line
            and ticket_marker in line
        ):
            removed = True
            continue
        new_lines.append(line)
    if not removed:
        # Defensive: parser said section has a ticket_link but we can't
        # find the comment line — surface as already-updated rather than
        # crashing.
        raise SectionAlreadyUpdatedError(
            f"section_id={section_id} ticket comment not found in section range"
        )
    new_content = "".join(new_lines)

    # Branch name is deterministic per section, so a re-run finds the
    # existing PR rather than opening a duplicate.
    branch = f"canon-bot/remove-ref-{section_id}"
    existing = await client.find_open_doc_pr(owner, repo, branch)
    if existing is not None:
        return RemoveTicketRefResult(
            pr_number=existing.pr_number,
            pr_url=existing.pr_url,
            already_existed=True,
        )

    pr = await client.create_doc_pr(
        owner,
        repo,
        branch=branch,
        title=f"Remove broken ticket reference from {file_path}",
        body=(
            "The Canon dashboard flagged this ticket reference as persistently broken "
            "(404/401/403 from the ticket system on multiple consecutive sync runs). "
            "This PR removes the dead reference so the cron stops re-checking it. "
            "If the ticket should be replaced rather than removed, close this PR and "
            "edit the spec directly."
        ),
        files=[FileChange(path=file_path, content=new_content)],
        commit_message=f"chore(canon): remove broken ticket reference from {file_path}",
    )
    return RemoveTicketRefResult(pr_number=pr.pr_number, pr_url=pr.pr_url)
```

Imports needed at top of services.py: `from dataclasses import dataclass`, `from canon.parser.models import flatten_sections`, `from canon.parser.parse import parse_spec, ParseOptions`, `from canon.github.client import FileChange`. Most should already be present from §3.

- [ ] **Step 3: Run tests, lint, commit**

```bash
cd /Users/nickgerner/Code/canon-private && uv run pytest tests/test_web/test_services.py::TestRemoveTicketRef -v
cd /Users/nickgerner/Code/canon-private && uv run pytest -q --ignore=tests/integration --ignore=tests/scenarios
cd /Users/nickgerner/Code/canon-private && uv run ruff check src/canon/web/services.py tests/test_web/test_services.py && uv run ruff format src/canon/web/services.py tests/test_web/test_services.py
git add src/canon/web/services.py tests/test_web/test_services.py
git commit -m "feat(web): remove_ticket_ref service helper

Strips the canon:ticket comment line from a target section's range
in the spec markdown and opens a doc PR via client.create_doc_pr.
Branch name is deterministic per section_id so re-running returns
the existing PR (already_existed=True) rather than duplicating.
SectionNotFoundError / SectionAlreadyUpdatedError are raised to the
caller so the route layer can map to 404 / 410 respectively."
```

---

## Task 3: Three new mutating endpoints + tests

**Files:**
- Modify: `src/canon/web/routes.py`
- Test: `tests/test_web/test_broken_refs_mutations.py` (new)

- [ ] **Step 1: Register the endpoints**

```python
@app_router.post("/{org}/api/broken-refs/dismiss", response_class=JSONResponse)
async def api_broken_refs_dismiss(
    request: Request,
    org: str,
    body: DismissBrokenRefRequest,
    user: CurrentUser = Depends(require_permission(Permission.SPECS_WRITE)),
):
    ref_store = getattr(request.app.state, "ref_store", None)
    if ref_store is None:
        return JSONResponse(content={"error": "ticket_ref_status unavailable"}, status_code=503)
    client = await _get_client_for_org(request, org)
    installation_id = int(client.installation_id) if client.installation_id else None
    if installation_id is None:
        return JSONResponse(content={"error": "no installation for org"}, status_code=404)

    # 404 when the row doesn't exist — only the cron creates rows
    row = await ref_store.get(installation_id, body.system, body.ticket_ref)
    if row is None:
        return JSONResponse(content={"error": "ticket_ref not found"}, status_code=404)

    await ref_store.dismiss(
        installation_id=installation_id,
        system=body.system,
        ticket_ref=body.ticket_ref,
        dismissed_by=user.get("sub", "") if isinstance(user, dict) else getattr(user, "sub", ""),
    )
    return JSONResponse(content={"ok": True})


@app_router.post("/{org}/api/broken-refs/recheck", response_class=JSONResponse)
async def api_broken_refs_recheck(
    request: Request,
    org: str,
    body: RecheckBrokenRefRequest,
    _user: CurrentUser = Depends(require_permission(Permission.SPECS_WRITE)),
):
    ref_store = getattr(request.app.state, "ref_store", None)
    if ref_store is None:
        return JSONResponse(content={"error": "ticket_ref_status unavailable"}, status_code=503)
    client = await _get_client_for_org(request, org)
    installation_id = int(client.installation_id) if client.installation_id else None
    if installation_id is None:
        return JSONResponse(content={"error": "no installation for org"}, status_code=404)

    row = await ref_store.get(installation_id, body.system, body.ticket_ref)
    if row is None:
        return JSONResponse(content={"error": "ticket_ref not found"}, status_code=404)

    await ref_store.force_recheck(
        installation_id=installation_id,
        system=body.system,
        ticket_ref=body.ticket_ref,
    )
    return JSONResponse(content={"ok": True})


@app_router.post(
    "/{org}/api/specs/{owner}/{repo}/{file_path:path}/sections/{section_id}/remove-ticket-ref",
    response_class=JSONResponse,
)
async def api_remove_ticket_ref(
    request: Request,
    org: str,
    owner: str,
    repo: str,
    file_path: str,
    section_id: str,
    _user: CurrentUser = Depends(require_permission(Permission.SPECS_WRITE)),
):
    client = await _get_client_for_org(request, org)
    content_cache_store = _get_content_cache(request)
    try:
        result = await remove_ticket_ref(
            client,
            content_cache_store,
            owner=owner,
            repo=repo,
            file_path=file_path,
            section_id=section_id,
        )
    except SectionNotFoundError as exc:
        return JSONResponse(content={"error": str(exc)}, status_code=404)
    except SectionAlreadyUpdatedError as exc:
        return JSONResponse(content={"error": str(exc)}, status_code=410)
    except httpx.HTTPStatusError as exc:
        return _github_error_response(exc)
    except httpx.RequestError as exc:
        return _request_error_response(exc)

    status_code = 409 if result.already_existed else 200
    return JSONResponse(
        content=RemoveTicketRefResponse(
            pr_number=result.pr_number, pr_url=result.pr_url
        ).model_dump(),
        status_code=status_code,
    )
```

Imports to add at top of routes.py: `from .models import DismissBrokenRefRequest, RecheckBrokenRefRequest, RemoveTicketRefResponse`, `from .services import remove_ticket_ref, SectionNotFoundError, SectionAlreadyUpdatedError`.

- [ ] **Step 2: Write the route tests** at `tests/test_web/test_broken_refs_mutations.py`

```python
"""FastAPI TestClient tests for the broken-refs mutating endpoints."""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock

import pytest

# Adapt the existing per-file autouse `_setup_app_state` + `client_factory`
# pattern from tests/test_web/test_broken_refs_routes.py. The full setup
# (Settings stub, app.state.ref_store override, _mock_github_client with
# installation_id="1", auth bypass via empty Auth0 config) is identical
# between files.

# … boilerplate copied/adapted from test_broken_refs_routes.py …


def _broken_row(ticket_ref: str = "o/r#1") -> dict:
    return {
        "installation_id": 1,
        "system": "github",
        "ticket_ref": ticket_ref,
        "status": "broken",
        "consecutive_failures": 3,
        "last_error_kind": "not_found",
        "last_error_message": "not found",
        "first_failure_at": datetime.now(UTC),
        "last_check_at": datetime.now(UTC),
        "last_recheck_at": None,
        "dismissed_at": None,
        "dismissed_by": None,
    }


class TestDismiss:
    def test_dismiss_404_when_row_missing(self, client_factory):
        ref_store = AsyncMock()
        ref_store.get = AsyncMock(return_value=None)
        ref_store.dismiss = AsyncMock()
        client = client_factory(ref_store=ref_store)
        r = client.post(
            "/app/canonhq/api/broken-refs/dismiss",
            json={"system": "github", "ticket_ref": "o/r#1"},
        )
        assert r.status_code == 404
        ref_store.dismiss.assert_not_called()

    def test_dismiss_happy_path(self, client_factory):
        ref_store = AsyncMock()
        ref_store.get = AsyncMock(return_value=_broken_row())
        ref_store.dismiss = AsyncMock()
        client = client_factory(ref_store=ref_store)
        r = client.post(
            "/app/canonhq/api/broken-refs/dismiss",
            json={"system": "github", "ticket_ref": "o/r#1"},
        )
        assert r.status_code == 200
        assert r.json() == {"ok": True}
        ref_store.dismiss.assert_awaited_once()


class TestRecheck:
    def test_recheck_404_when_row_missing(self, client_factory):
        ref_store = AsyncMock()
        ref_store.get = AsyncMock(return_value=None)
        ref_store.force_recheck = AsyncMock()
        client = client_factory(ref_store=ref_store)
        r = client.post(
            "/app/canonhq/api/broken-refs/recheck",
            json={"system": "github", "ticket_ref": "o/r#1"},
        )
        assert r.status_code == 404

    def test_recheck_happy_path(self, client_factory):
        ref_store = AsyncMock()
        ref_store.get = AsyncMock(return_value=_broken_row())
        ref_store.force_recheck = AsyncMock()
        client = client_factory(ref_store=ref_store)
        r = client.post(
            "/app/canonhq/api/broken-refs/recheck",
            json={"system": "github", "ticket_ref": "o/r#1"},
        )
        assert r.status_code == 200
        ref_store.force_recheck.assert_awaited_once()


class TestRemoveTicketRef:
    def test_404_when_section_missing(self, client_factory):
        # Stub the GitHubClient + content_cache so remove_ticket_ref raises SectionNotFoundError
        client_obj = client_factory()
        # The route calls `_get_client_for_org` and `remove_ticket_ref` —
        # we patch the latter to raise.
        from canon.web import services
        from canon.web.services import SectionNotFoundError
        original = services.remove_ticket_ref
        services.remove_ticket_ref = AsyncMock(side_effect=SectionNotFoundError("nope"))
        try:
            r = client_obj.post(
                "/app/canonhq/api/specs/o/r/docs%2Fspecs%2Ftest.md/sections/9999/remove-ticket-ref",
            )
            assert r.status_code == 404
        finally:
            services.remove_ticket_ref = original

    def test_410_when_section_already_updated(self, client_factory):
        client_obj = client_factory()
        from canon.web import services
        from canon.web.services import SectionAlreadyUpdatedError
        original = services.remove_ticket_ref
        services.remove_ticket_ref = AsyncMock(side_effect=SectionAlreadyUpdatedError("stale"))
        try:
            r = client_obj.post(
                "/app/canonhq/api/specs/o/r/docs%2Fspecs%2Ftest.md/sections/1/remove-ticket-ref",
            )
            assert r.status_code == 410
        finally:
            services.remove_ticket_ref = original

    def test_409_when_existing_pr(self, client_factory):
        client_obj = client_factory()
        from canon.web import services
        from canon.web.services import RemoveTicketRefResult
        original = services.remove_ticket_ref
        services.remove_ticket_ref = AsyncMock(return_value=RemoveTicketRefResult(
            pr_number=7, pr_url="https://github.com/o/r/pull/7", already_existed=True,
        ))
        try:
            r = client_obj.post(
                "/app/canonhq/api/specs/o/r/docs%2Fspecs%2Ftest.md/sections/1/remove-ticket-ref",
            )
            assert r.status_code == 409
            assert r.json() == {"pr_number": 7, "pr_url": "https://github.com/o/r/pull/7"}
        finally:
            services.remove_ticket_ref = original

    def test_200_happy_path(self, client_factory):
        client_obj = client_factory()
        from canon.web import services
        from canon.web.services import RemoveTicketRefResult
        original = services.remove_ticket_ref
        services.remove_ticket_ref = AsyncMock(return_value=RemoveTicketRefResult(
            pr_number=42, pr_url="https://github.com/o/r/pull/42", already_existed=False,
        ))
        try:
            r = client_obj.post(
                "/app/canonhq/api/specs/o/r/docs%2Fspecs%2Ftest.md/sections/1/remove-ticket-ref",
            )
            assert r.status_code == 200
            assert r.json() == {"pr_number": 42, "pr_url": "https://github.com/o/r/pull/42"}
        finally:
            services.remove_ticket_ref = original
```

**IMPLEMENTER NOTE:** copy the `_setup_app_state` + `client_factory` autouse fixture pattern from `tests/test_web/test_broken_refs_routes.py` (which §3 added). Auth is naturally bypassed in the test config because Settings has no Auth0 / OIDC set, so `require_permission` short-circuits to `ANONYMOUS_USER`.

- [ ] **Step 3: Run tests, lint, commit**

```bash
cd /Users/nickgerner/Code/canon-private && uv run pytest tests/test_web/test_broken_refs_mutations.py -v
cd /Users/nickgerner/Code/canon-private && uv run pytest -q --ignore=tests/integration --ignore=tests/scenarios
cd /Users/nickgerner/Code/canon-private && uv run ruff check src/canon/web/routes.py tests/test_web/test_broken_refs_mutations.py && uv run ruff format src/canon/web/routes.py tests/test_web/test_broken_refs_mutations.py
git add src/canon/web/routes.py tests/test_web/test_broken_refs_mutations.py
git commit -m "feat(web): three mutating endpoints for broken-refs

POST /broken-refs/dismiss and /broken-refs/recheck call into the
existing TicketRefStatusStore.dismiss / force_recheck methods.
POST /specs/.../sections/{id}/remove-ticket-ref opens a doc PR via
the existing create_doc_pr helper. All gated on SPECS_WRITE.
Maps SectionNotFoundError -> 404, SectionAlreadyUpdatedError -> 410,
already-existing PR -> 409 with the existing pr_url."
```

---

## Task 4: Frontend API client

**Files:**
- Modify: `frontend/src/api/broken_refs.ts`

- [ ] **Step 1: Add the three wrappers**

```typescript
import { post } from './client'

export interface DismissBrokenRefRequest {
  system: 'jira' | 'linear' | 'github'
  ticket_ref: string
}

export interface RecheckBrokenRefRequest {
  system: 'jira' | 'linear' | 'github'
  ticket_ref: string
}

export interface RemoveTicketRefResponse {
  pr_number: number
  pr_url: string
}

export function dismissBrokenRef(org: string, body: DismissBrokenRefRequest): Promise<{ ok: true }> {
  return post(`/app/${org}/api/broken-refs/dismiss`, body)
}

export function recheckBrokenRef(org: string, body: RecheckBrokenRefRequest): Promise<{ ok: true }> {
  return post(`/app/${org}/api/broken-refs/recheck`, body)
}

export function removeTicketRef(
  org: string,
  owner: string,
  repo: string,
  filePath: string,
  sectionId: string,
): Promise<RemoveTicketRefResponse> {
  // file_path can contain slashes (e.g. docs/specs/foo.md); URL-encode it.
  return post(
    `/app/${org}/api/specs/${owner}/${repo}/${encodeURIComponent(filePath)}/sections/${sectionId}/remove-ticket-ref`,
    null,
  )
}
```

If `post` doesn't exist in `frontend/src/api/client.ts`, read the file and add a typed POST wrapper next to the existing `get`. The shape should mirror `get`: `post<T>(path: string, body: unknown): Promise<T>` with auth/refresh handling.

- [ ] **Step 2: Type check + lint + commit**

```
cd /Users/nickgerner/Code/canon-private/frontend && npm run type-check && npm run lint
git add frontend/src/api/broken_refs.ts frontend/src/api/client.ts
git commit -m "feat(frontend): API client wrappers for broken-ref mutations"
```

---

## Task 5: `RemoveTicketRefModal.vue`

**Files:**
- Create: `frontend/src/components/spec/RemoveTicketRefModal.vue`

- [ ] **Step 1: Read an existing modal in the codebase for the style baseline**

Search for existing modals: `grep -lE 'role="dialog"|class="modal"|<dialog' frontend/src/components/`. The `RepoPickerModal.vue` (referenced from `OrgDashboard.vue`) is the natural model to copy.

- [ ] **Step 2: Create the modal**

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { ApiError } from '@/api/client'
import { removeTicketRef } from '@/api/broken_refs'

const props = defineProps<{
  org: string
  owner: string
  repo: string
  filePath: string
  sectionId: string
  ticketRef: string
}>()

const emit = defineEmits<{
  close: []
  removed: [{ pr_number: number; pr_url: string; already_existed: boolean }]
}>()

const submitting = ref(false)
const error = ref<string>('')

async function confirm() {
  submitting.value = true
  error.value = ''
  try {
    const result = await removeTicketRef(
      props.org, props.owner, props.repo, props.filePath, props.sectionId,
    )
    emit('removed', { ...result, already_existed: false })
  } catch (err) {
    if (err instanceof ApiError && err.status === 409) {
      // 409 body has the same shape as 200 — the existing PR's metadata
      const body = err.body as { pr_number: number; pr_url: string }
      emit('removed', { ...body, already_existed: true })
    } else if (err instanceof ApiError && err.status === 410) {
      error.value = 'This section has already been updated. Refresh the dashboard to re-check.'
    } else {
      error.value = err instanceof Error ? err.message : 'Failed to open PR'
    }
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <div
    class="fixed inset-0 z-50 flex items-center justify-center bg-black/40"
    role="dialog"
    aria-modal="true"
    @click.self="emit('close')"
  >
    <div class="w-full max-w-md rounded border border-gray-300 bg-white p-5 shadow-xl dark:bg-gray-800 dark:border-gray-600">
      <h3 class="mb-2 font-semibold">Remove ticket reference?</h3>
      <p class="mb-4 text-sm text-gray-600 dark:text-gray-400">
        This opens a pull request that removes
        <code class="rounded bg-gray-100 px-1 py-0.5 text-xs dark:bg-gray-700">{{ ticketRef }}</code>
        from <code class="rounded bg-gray-100 px-1 py-0.5 text-xs dark:bg-gray-700">{{ filePath }}</code>.
        Review the PR before merging.
      </p>
      <p v-if="error" class="mb-3 text-sm text-red-700 dark:text-red-300">{{ error }}</p>
      <div class="flex justify-end gap-2">
        <button
          type="button"
          class="rounded border border-gray-300 bg-white px-3 py-1.5 text-sm dark:bg-gray-700"
          :disabled="submitting"
          @click="emit('close')"
        >
          Cancel
        </button>
        <button
          type="button"
          class="rounded bg-red-600 px-3 py-1.5 text-sm font-semibold text-white hover:bg-red-700 disabled:opacity-50"
          :disabled="submitting"
          @click="confirm"
        >
          {{ submitting ? 'Opening PR…' : 'Open PR' }}
        </button>
      </div>
    </div>
  </div>
</template>
```

If `ApiError` isn't already exported from `client.ts`, add `export { ApiError }` (it's defined there per §3 exploration but check whether it's exported).

- [ ] **Step 3: Type check + lint + commit**

```
cd /Users/nickgerner/Code/canon-private/frontend && npm run type-check && npm run lint
git add frontend/src/components/spec/RemoveTicketRefModal.vue frontend/src/api/client.ts
git commit -m "feat(frontend): RemoveTicketRefModal confirmation dialog"
```

---

## Task 6: Wire actions in `BrokenRefBadge.vue` and `BrokenRefsPanel.vue`

**Files:**
- Modify: `frontend/src/components/spec/BrokenRefBadge.vue`
- Modify: `frontend/src/components/dashboard/BrokenRefsPanel.vue`

- [ ] **Step 1: BrokenRefBadge.vue — wire the three actions**

In the `<script setup>` block:

```typescript
import { ref } from 'vue'
import { useQueryClient } from '@tanstack/vue-query'
import type { BrokenRef } from '@/api/types'
import { dismissBrokenRef, recheckBrokenRef } from '@/api/broken_refs'
import RemoveTicketRefModal from './RemoveTicketRefModal.vue'

const props = defineProps<{
  brokenRef: BrokenRef
  org: string
  // For the remove-ref action; required when the badge is mounted from
  // SpecSectionCard (which has these from SpecDetail).
  owner?: string
  repo?: string
  filePath?: string
}>()

const showPopover = ref(false)
const showRemoveModal = ref(false)
const queryClient = useQueryClient()

async function handleDismiss() {
  await dismissBrokenRef(props.org, {
    system: props.brokenRef.system,
    ticket_ref: props.brokenRef.ticket_ref,
  })
  showPopover.value = false
  // Refetch dashboard / spec views so the badge disappears
  queryClient.invalidateQueries({ queryKey: ['broken-refs'] })
  queryClient.invalidateQueries({ queryKey: ['dashboard'] })
}

async function handleRecheck() {
  await recheckBrokenRef(props.org, {
    system: props.brokenRef.system,
    ticket_ref: props.brokenRef.ticket_ref,
  })
  showPopover.value = false
}

function openRemoveModal() {
  showPopover.value = false
  showRemoveModal.value = true
}

function onRemoved(result: { pr_number: number; pr_url: string; already_existed: boolean }) {
  showRemoveModal.value = false
  // Open the PR in a new tab
  window.open(result.pr_url, '_blank')
  queryClient.invalidateQueries({ queryKey: ['broken-refs'] })
  queryClient.invalidateQueries({ queryKey: ['dashboard'] })
}
```

In the template, replace the disabled-button stubs with active handlers:
- `Remove ref (opens PR)` — `@click="openRemoveModal"`, `:disabled="!owner || !repo || !filePath"` (if any of those are missing, button stays disabled with tooltip "Available only from the spec view"). This handles the dashboard case where the badge isn't currently mounted but in case it is, gracefully degrade.
- `Dismiss` — `@click="handleDismiss"`
- `Re-check now` — `@click="handleRecheck"`

Mount the modal:

```vue
<RemoveTicketRefModal
  v-if="showRemoveModal && owner && repo && filePath"
  :org="org"
  :owner="owner"
  :repo="repo"
  :file-path="filePath"
  :section-id="brokenRef.section_id"
  :ticket-ref="brokenRef.ticket_ref"
  @close="showRemoveModal = false"
  @removed="onRemoved"
/>
```

Update `SpecSectionCard.vue` to pass the new props:

```vue
<BrokenRefBadge
  v-if="brokenRef"
  :broken-ref="brokenRef"
  :org="org"
  :owner="owner"
  :repo="repo"
  :file-path="filePath"
/>
```

The parent `SpecDetail.vue` already has these — thread them through where it currently passes `brokenSections`.

- [ ] **Step 2: BrokenRefsPanel.vue — wire Remove + Dismiss buttons**

The dashboard list rows have empty `spec_path` per §3's design, so the "Remove" button on the panel can't directly call remove_ticket_ref (it doesn't know which section). Two reasonable options:

**Option A (recommended):** Disable the panel-row "Remove" button with a tooltip "Open the spec to remove this ref." The badge popover on the spec view is the only place "Remove" works. Panel-row "Dismiss" still works.

**Option B (more polish):** When the panel row's Remove is clicked, navigate to `spec_path` and auto-open the badge popover for that section. Requires populating `spec_path` on dashboard rows (per-row spec lookup that we deferred in §3).

Implement Option A — keep the dashboard scope tight:

```vue
<button
  type="button"
  class="rounded border border-red-300 bg-white px-2 py-1 font-semibold text-red-700 opacity-50 dark:bg-gray-700"
  disabled
  title="Open the spec from the inline badge to remove this ref"
>
  Remove
</button>
<button
  type="button"
  class="rounded border border-gray-300 bg-white px-2 py-1 text-gray-700 dark:bg-gray-700"
  @click.stop="dismissRow(item)"
>
  Dismiss
</button>
```

Add the `dismissRow` handler in the script-setup block that calls `dismissBrokenRef` and refetches the panel data via TanStack Query's `refetch()` or `queryClient.invalidateQueries`.

- [ ] **Step 3: Type check + lint + commit**

```
cd /Users/nickgerner/Code/canon-private/frontend && npm run type-check && npm run lint
git add frontend/src/components/spec/BrokenRefBadge.vue \
        frontend/src/components/spec/SpecSectionCard.vue \
        frontend/src/components/spec/SpecDetail.vue \
        frontend/src/components/dashboard/BrokenRefsPanel.vue
git commit -m "feat(frontend): wire broken-ref action buttons

BrokenRefBadge popover now calls dismiss/recheck endpoints inline and
opens a confirmation modal for the destructive Remove action; on
success the user is sent to the new PR in a new tab. BrokenRefsPanel
wires per-row Dismiss; Remove stays disabled at the panel level (the
badge on the spec view is the only place with the section context
needed to call create_doc_pr)."
```

---

## Task 7: Push branch + open PR

- [ ] **Step 1: Push**

```
git push -u origin spec/broken-refs-section-4
```

- [ ] **Step 2: Open PR against main**

Standard PR opening with body covering: dismiss/recheck/remove endpoints, modal flow, the panel-row Remove tradeoff (Option A), and a post-merge verification step (open the dashboard, dismiss one of the organic broken refs, verify it disappears from the active list).

- [ ] **Step 3: Watch CI, merge when green**

---

## Self-Review

**1. Spec coverage:** Walked the §4 acceptance criteria from `docs/specs/broken-ticket-refs-ui.md`:

| AC | Task |
|----|------|
| `POST /broken-refs/dismiss` flips status + dismissed_by | Task 3 |
| `POST /broken-refs/recheck` clears last_recheck_at, no inline adapter call | Task 3 |
| `POST .../remove-ticket-ref` opens a doc PR | Tasks 2 + 3 |
| Collision case → 409 with existing pr_url | Tasks 2 + 3 |
| Re-pointed-section → 410 | Tasks 2 + 3 |
| All gated on `Permission.SPECS_WRITE` | Task 3 |
| `RemoveTicketRefModal` shows before any remove action | Task 5 |
| BrokenRefBadge + BrokenRefsPanel buttons trigger right endpoint and refetch | Task 6 |
| Toast notifications for PR links and 409 conflicts | **Partially:** the modal handles 409 inline (shows existing PR), and `window.open` handles success. No formal toast component exists in this codebase per §3 exploration — using `window.open` is the simplest "show me the PR" affordance and matches the disabled-button stubs' existing tooltip language. Add a real toast in a follow-up if desired. |

**2. Placeholder scan:** no "TBD" / "TODO" left. Two implementer-discretion points (which existing modal to copy from; whether to populate `spec_path` for the panel) are explicit reads-the-codebase moments with concrete fallback recommendations.

**3. Type consistency:** `RemoveTicketRefResult` (Python dataclass) ↔ `RemoveTicketRefResponse` (Pydantic, JSON wire) ↔ TS interface match field names exactly. `system` literals match across all layers.

**4. Note on toast:** The spec mentions "Toast notifications surface PR links and 409 conflicts" as an AC. This codebase has no toast component (verified during §3 exploration). Implementing one would expand scope materially. Plan uses `window.open(pr_url)` for the success affordance and inline error rendering in the modal for 410. The Spec AC will be updated to reflect this — the plan's behavior is functionally equivalent without adding new infra.
