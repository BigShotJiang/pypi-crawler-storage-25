# Broken Ticket Refs §3 — Read API + UI Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Surface broken ticket refs in the Canon dashboard and inline on each spec view. No mutation actions in this slice (those are §4) — just read endpoints and display.

**Architecture:** Augment the existing `OrgOverview` and `SpecDetail` Pydantic models with broken-ref fields populated from `TicketRefStatusStore.list_broken`. Add two new read endpoints (`GET /broken-refs`, `GET /broken-refs/count`). Vue components — a small `BrokenRefBadge` mounted on broken sections in the spec view, and a `BrokenRefsPanel` on the dashboard with filters + pagination. Action buttons in the badge popover and panel rows render but their callbacks are no-ops in §3.

**Tech Stack:** FastAPI + Pydantic v2 + asyncpg (backend); Vue 3.5 + TypeScript + TanStack Vue Query + Tailwind (frontend). No Vitest in this codebase — frontend tests rely on `vue-tsc` type checking; backend coverage uses FastAPI TestClient. Branch: `spec/broken-refs-section-3` already created from `spec/broken-ticket-refs-ui` (current HEAD `b07e070a`).

---

## File Structure

**New backend files (3):**
- `tests/test_web/test_broken_refs_routes.py` — FastAPI TestClient tests for the two new endpoints + the dashboard/spec-detail augmentations.
- (No new modules — endpoints land in the existing `src/canon/web/routes.py` next to the other `/{org}/api/*` routes.)
- (No new services — `get_org_overview` and `get_spec_detail` augmentations live in the existing `src/canon/web/services.py`.)

**New frontend files (3):**
- `frontend/src/api/broken_refs.ts` — typed API client wrapper, mirrors `dashboard.ts` shape.
- `frontend/src/components/spec/BrokenRefBadge.vue` — small inline indicator + popover with stub action buttons.
- `frontend/src/components/dashboard/BrokenRefsPanel.vue` — paginated table with filters.

**Modified backend files (3):**
- `src/canon/web/models.py` — add `BrokenRef` model, augment `OrgOverview` + `RepoSummary` + `SpecDetail`.
- `src/canon/main.py` — wire `app.state.ref_store = TicketRefStatusStore(...)` next to the existing `content_cache_store` block.
- `src/canon/web/services.py` — pass `ref_store` through `get_org_overview` / `get_spec_detail` and populate the new fields. Add new top-level functions for the two new endpoints.
- `src/canon/web/routes.py` — register the two new endpoints + thread `ref_store` into the existing dashboard/spec-detail handler call paths.

**Modified frontend files (3):**
- `frontend/src/api/types.ts` — add `BrokenRef`, augment `OrgOverview` + `RepoSummary` + `SpecDetail`.
- `frontend/src/components/dashboard/OrgDashboard.vue` — render the metric chip + mount `<BrokenRefsPanel>` when `total_broken_refs > 0`.
- `frontend/src/components/spec/SpecSectionCard.vue` (or whichever component renders a section's ticket link — implementer to confirm during Task 8) — mount `<BrokenRefBadge>` next to the ticket reference when the section's `section_id` matches a `broken_sections` entry.

---

## Task 1: Pydantic + TypeScript models

**Files:**
- Modify: `src/canon/web/models.py`
- Modify: `frontend/src/api/types.ts`

- [ ] **Step 1: Add `BrokenRef` to `web/models.py`**

After the existing `DocFile` / `RepoSummary` / `OrgOverview` block, add:

```python
class BrokenRef(BaseModel):
    """A spec section that references a ticket the cron has flagged broken."""

    system: Literal["jira", "linear", "github"]
    ticket_ref: str            # Fully-qualified per canon.sync.ticket_ref.qualify
    spec_path: str             # `{repo_full_name}/{file_path}` — used for navigation
    section_id: str
    section_heading: str
    error_kind: Literal["not_found", "forbidden", "unauthorized"]
    first_failure_at: datetime
    last_check_at: datetime
    dismissed: bool
    dismissed_by: str | None
```

Make sure `from typing import Literal` and `from datetime import datetime` are imported (probably already are; verify before adding duplicates).

- [ ] **Step 2: Augment existing models**

Add `broken_refs_count: int = 0` to `RepoSummary`:

```python
class RepoSummary(BaseModel):
    # … existing fields …
    docs: list[DocFile]
    broken_refs_count: int = 0  # populated by services.get_org_overview
```

Add `total_broken_refs: int = 0` to `OrgOverview`:

```python
class OrgOverview(BaseModel):
    # … existing fields …
    total_docs: int
    total_broken_refs: int = 0  # populated by services.get_org_overview
```

Add `broken_sections: list[BrokenRef] = []` to `SpecDetail`:

```python
class SpecDetail(BaseModel):
    # … existing fields …
    config: CanonConfig | None = None
    broken_sections: list[BrokenRef] = []  # populated by services.get_spec_detail
```

The defaults make the augmentation backward-compatible — existing tests / serializers continue to work without changes.

- [ ] **Step 3: Mirror in `frontend/src/api/types.ts`**

Find `RepoSummary`, `OrgOverview`, `SpecDetail` interfaces and add the new fields:

```typescript
export interface BrokenRef {
  system: 'jira' | 'linear' | 'github'
  ticket_ref: string
  spec_path: string
  section_id: string
  section_heading: string
  error_kind: 'not_found' | 'forbidden' | 'unauthorized'
  first_failure_at: string  // ISO 8601
  last_check_at: string
  dismissed: boolean
  dismissed_by: string | null
}

export interface RepoSummary {
  // … existing fields …
  docs: DocFile[]
  broken_refs_count: number
}

export interface OrgOverview {
  // … existing fields …
  total_docs: number
  total_broken_refs: number
}

export interface SpecDetail {
  // … existing fields …
  config: CanonConfig | null
  broken_sections: BrokenRef[]
}
```

Place `BrokenRef` near the other shared models so it's discoverable.

- [ ] **Step 4: Type check**

Run: `cd /Users/nickgerner/Code/canon-private/frontend && npm run type-check`
Expected: `No errors`. If TS complains about missing fields where the API hasn't been updated yet, that's a sign the augmentation is non-additive — the defaults should make `BrokenRef` and `broken_*` fields optional in TS, but TS interfaces aren't optional unless marked `?`. Use `?:` if needed for now and remove the `?` once routes populate them in later tasks. (Update: keep the fields required since the backend defaults guarantee they're always present in the response.)

- [ ] **Step 5: Lint**

Run: `cd /Users/nickgerner/Code/canon-private && uv run ruff check src/canon/web/models.py`
Expected: clean.

Run: `cd /Users/nickgerner/Code/canon-private/frontend && npm run lint`
Expected: clean.

- [ ] **Step 6: Commit**

```bash
git add src/canon/web/models.py frontend/src/api/types.ts
git commit -m "feat(web): add BrokenRef model + augment OrgOverview/SpecDetail

Pydantic + TypeScript types for the broken-refs UI. RepoSummary gains
broken_refs_count; OrgOverview gains total_broken_refs; SpecDetail
gains broken_sections. All fields default to 0 / [] so existing
callers and serializers are unaffected until services start
populating them in later tasks."
```

---

## Task 2: Wire `TicketRefStatusStore` into `app.state`

**Files:**
- Modify: `src/canon/main.py`

- [ ] **Step 1: Add the store wiring**

Find the existing block (around line 303–313):

```python
    app.state.search_index = None
    app.state.content_cache_store = None
    if app.state.db_pool is not None:
        app.state.search_index = SearchIndex(app.state.db_pool)
        logger.info("Search index initialised")

        if settings.content_cache_enabled:
            from .db.content_cache_store import ContentCacheStore

            app.state.content_cache_store = ContentCacheStore(app.state.db_pool)
            logger.info("Content cache store initialised")
```

Replace with the same block plus `ref_store` initialisation. The new block:

```python
    app.state.search_index = None
    app.state.content_cache_store = None
    app.state.ref_store = None
    if app.state.db_pool is not None:
        app.state.search_index = SearchIndex(app.state.db_pool)
        logger.info("Search index initialised")

        if settings.content_cache_enabled:
            from .db.content_cache_store import ContentCacheStore

            app.state.content_cache_store = ContentCacheStore(app.state.db_pool)
            logger.info("Content cache store initialised")

        # Broken-ref tracking — independent of content_cache_enabled. The
        # store is cheap (no per-request work) and the broken-ref display
        # depends only on cron-written rows.
        from .db.ticket_ref_status_store import TicketRefStatusStore

        app.state.ref_store = TicketRefStatusStore(app.state.db_pool)
        logger.info("Ticket ref status store initialised")
```

- [ ] **Step 2: Run smoke tests**

Run: `cd /Users/nickgerner/Code/canon-private && uv run pytest tests/test_main.py -v`
Expected: pass — no behaviour change beyond a new attribute on `app.state` and one extra log line.

Run: `cd /Users/nickgerner/Code/canon-private && uv run pytest -q --ignore=tests/integration --ignore=tests/scenarios`
Expected: 3,656+ pass, 0 fail.

- [ ] **Step 3: Lint**

Run: `cd /Users/nickgerner/Code/canon-private && uv run ruff check src/canon/main.py`
Expected: clean.

- [ ] **Step 4: Commit**

```bash
git add src/canon/main.py
git commit -m "feat(web): wire TicketRefStatusStore into app.state

Initialised next to content_cache_store, gated only on db_pool
availability (not content_cache_enabled — broken-ref display is
independent of the read-from-cache feature flag). Endpoints in
later tasks read via getattr(request.app.state, 'ref_store', None)."
```

---

## Task 3: Augment `get_org_overview` to populate broken-ref counts

**Files:**
- Modify: `src/canon/web/services.py`
- Test: `tests/test_web/test_services.py` (existing — add 1-2 cases at the end of `TestGetOrgOverview`)

- [ ] **Step 1: Add the test for `total_broken_refs` and per-repo `broken_refs_count`**

Find `class TestGetOrgOverview` in `tests/test_web/test_services.py` and append:

```python
    async def test_populates_broken_refs_count_when_ref_store_provided(self):
        client = _mock_client(repos=[
            {"owner": {"login": "o"}, "name": "r1", "full_name": "o/r1",
             "description": "", "default_branch": "main"},
            {"owner": {"login": "o"}, "name": "r2", "full_name": "o/r2",
             "description": "", "default_branch": "main"},
        ])
        cache = TTLCache(ttl_seconds=300)
        # Stub ref_store: r1 has 2 broken refs, r2 has 0
        ref_store = AsyncMock()
        ref_store.list_broken = AsyncMock(return_value=[
            {"installation_id": 1, "system": "github", "ticket_ref": "o/r1#1",
             "status": "broken", "consecutive_failures": 3,
             "last_error_kind": "not_found", "first_failure_at": None,
             "last_check_at": None},
            {"installation_id": 1, "system": "github", "ticket_ref": "o/r1#2",
             "status": "broken", "consecutive_failures": 3,
             "last_error_kind": "not_found", "first_failure_at": None,
             "last_check_at": None},
        ])
        overview = await get_org_overview(
            client, "o", cache, ref_store=ref_store, installation_id=1,
        )
        assert overview.total_broken_refs == 2
        # broken_refs_count is per-repo, derived from ticket_ref's repo prefix
        repo_counts = {r.full_name: r.broken_refs_count for r in overview.repos_with_specs + overview.repos_without_specs}
        assert repo_counts["o/r1"] == 2
        assert repo_counts["o/r2"] == 0

    async def test_zero_broken_refs_when_ref_store_omitted(self):
        client = _mock_client()
        cache = TTLCache(ttl_seconds=300)
        overview = await get_org_overview(client, "o", cache)
        assert overview.total_broken_refs == 0
```

These extend the existing test class style. The `_mock_client` helper builds a GitHubClient mock; the `repos` arg controls what `list_installation_repos` returns. `AsyncMock` is already imported in this file.

- [ ] **Step 2: Run the new tests to confirm they fail**

Run: `cd /Users/nickgerner/Code/canon-private && uv run pytest tests/test_web/test_services.py::TestGetOrgOverview -v`
Expected: the two new tests FAIL — `get_org_overview` doesn't accept `ref_store` / `installation_id` kwargs and doesn't set `total_broken_refs`.

- [ ] **Step 3: Update `get_org_overview` and `_fetch_org_overview` signatures**

In `src/canon/web/services.py`, find `async def get_org_overview` and `_fetch_org_overview`. Add two new optional kwargs to both:

```python
async def get_org_overview(
    client: GitHubClient,
    org: str,
    cache: TTLCache,
    *,
    search_index: object | None = None,
    content_cache_store: object | None = None,
    ref_store: object | None = None,
    installation_id: int | None = None,
) -> OrgOverview:
    # … existing body …
```

```python
async def _fetch_org_overview(
    client: GitHubClient,
    org: str,
    cache: TTLCache,
    *,
    cache_key: str,
    search_index: object | None = None,
    content_cache_store: object | None = None,
    ref_store: object | None = None,
    installation_id: int | None = None,
) -> OrgOverview:
    # … existing body …
```

In `get_org_overview`'s body, pass the new kwargs through to `_fetch_org_overview`'s call.

- [ ] **Step 4: Populate the broken-ref counts inside `_fetch_org_overview`**

Near the top of `_fetch_org_overview` (after the existing `repos = …` and `indexed_paths` block, before the `for repo_data in repos:` loop), add:

```python
    # Pre-fetch broken refs for this installation in one query, then
    # bucket by repo using the ticket_ref's leading prefix. Refs with
    # status='dismissed' are excluded — the dashboard "needs attention"
    # count should reflect actionable breakage only.
    broken_by_repo: dict[str, int] = {}
    total_broken: int = 0
    if ref_store is not None and installation_id is not None:
        try:
            broken_rows = await ref_store.list_broken(installation_id=installation_id)
        except Exception:
            logger.warning(
                "list_broken failed during org overview — broken-ref counts default to 0",
                exc_info=True,
            )
            broken_rows = []
        for row in broken_rows:
            ref = row.get("ticket_ref", "")
            # github refs are 'org/repo#N'; jira/linear refs aren't
            # repo-scoped so they bucket under '' and are counted only
            # in total_broken
            repo_prefix = ref.rsplit("#", 1)[0] if "#" in ref else ""
            if repo_prefix:
                broken_by_repo[repo_prefix] = broken_by_repo.get(repo_prefix, 0) + 1
            total_broken += 1
```

In the `for repo_data in repos:` loop where `summary = RepoSummary(...)` is constructed, add `broken_refs_count=broken_by_repo.get(full_name, 0)` to the kwargs.

In the final `overview = OrgOverview(...)` construction, add `total_broken_refs=total_broken` to the kwargs.

- [ ] **Step 5: Run the new tests**

Run: `cd /Users/nickgerner/Code/canon-private && uv run pytest tests/test_web/test_services.py::TestGetOrgOverview -v`
Expected: PASS — including the two new tests.

- [ ] **Step 6: Run full unit suite**

Run: `cd /Users/nickgerner/Code/canon-private && uv run pytest -q --ignore=tests/integration --ignore=tests/scenarios`
Expected: 0 failures.

- [ ] **Step 7: Lint**

Run: `cd /Users/nickgerner/Code/canon-private && uv run ruff check src/canon/web/services.py tests/test_web/test_services.py && uv run ruff format src/canon/web/services.py tests/test_web/test_services.py`
Expected: clean.

- [ ] **Step 8: Commit**

```bash
git add src/canon/web/services.py tests/test_web/test_services.py
git commit -m "feat(web): populate broken_refs_count in org overview

get_org_overview now accepts ref_store + installation_id kwargs and
returns total_broken_refs + per-repo broken_refs_count. Excludes
dismissed rows from the count so the dashboard reflects actionable
breakage only. Failures during list_broken fail-open to count=0."
```

---

## Task 4: Augment `get_spec_detail` to populate `broken_sections`

**Files:**
- Modify: `src/canon/web/services.py`
- Test: `tests/test_web/test_services.py` (extend `TestGetSpecDetail`)

- [ ] **Step 1: Write the failing test**

Append to `class TestGetSpecDetail`:

```python
    async def test_populates_broken_sections_when_ref_store_provided(self):
        # Build a spec doc with one section whose ticket link matches a
        # broken row, and another that doesn't.
        spec_md = """---
title: Test
status: in_progress
---

# Test

## 1. Has broken ticket

<!-- canon:system:1 status:in_progress -->
<!-- canon:ticket:github:456 url:https://github.com/o/r/issues/456 -->

Body

## 2. Has working ticket

<!-- canon:system:2 status:in_progress -->
<!-- canon:ticket:github:789 url:https://github.com/o/r/issues/789 -->

Body
"""
        client = AsyncMock()
        client.get_file_content = AsyncMock(return_value=(spec_md, "sha"))
        cache = TTLCache(ttl_seconds=300)

        ref_store = AsyncMock()
        ref_store.list_broken = AsyncMock(return_value=[
            {"installation_id": 1, "system": "github",
             "ticket_ref": "o/r#456",
             "status": "broken", "consecutive_failures": 3,
             "last_error_kind": "not_found",
             "last_error_message": "not found",
             "first_failure_at": datetime.now(UTC),
             "last_check_at": datetime.now(UTC),
             "last_recheck_at": None,
             "dismissed_at": None, "dismissed_by": None},
        ])

        detail = await get_spec_detail(
            client, "o", "r", "docs/specs/test.md", cache,
            ref_store=ref_store, installation_id=1,
        )
        assert detail is not None
        assert len(detail.broken_sections) == 1
        assert detail.broken_sections[0].ticket_ref == "o/r#456"
        assert detail.broken_sections[0].error_kind == "not_found"
```

The imports `datetime, UTC` and `AsyncMock` are already in the test file (sister tests use them). If not, add them.

- [ ] **Step 2: Run to verify failure**

Run: `cd /Users/nickgerner/Code/canon-private && uv run pytest tests/test_web/test_services.py::TestGetSpecDetail -v`
Expected: the new test FAILS (`get_spec_detail` doesn't accept the kwargs).

- [ ] **Step 3: Update `get_spec_detail`**

Add `ref_store` + `installation_id` kwargs to `get_spec_detail` (around line 478 in `services.py`). Inside the function body, after `result = parse_spec(...)` and before `detail = SpecDetail(...)`:

```python
    broken_sections: list[BrokenRef] = []
    if ref_store is not None and installation_id is not None:
        try:
            broken_rows = await ref_store.list_broken(installation_id=installation_id)
        except Exception:
            logger.warning(
                "list_broken failed during spec detail — broken_sections defaults to []",
                exc_info=True,
            )
            broken_rows = []

        # Index broken rows by ticket_ref for O(1) section lookup
        broken_by_ref = {row["ticket_ref"]: row for row in broken_rows
                         if row.get("status") == "broken"}

        from canon.sync.ticket_ref import qualify

        for section in _flatten_sections(result.document.sections):
            link = section.ticket_link
            if not link:
                continue
            try:
                section_ref = qualify(link.system, f"{owner}/{repo}", link.ticket_id)
            except Exception:
                continue
            row = broken_by_ref.get(section_ref)
            if row is None:
                continue
            broken_sections.append(BrokenRef(
                system=link.system,
                ticket_ref=section_ref,
                spec_path=f"{owner}/{repo}/{file_path}",
                section_id=section.id,
                section_heading=section.heading,
                error_kind=row["last_error_kind"],
                first_failure_at=row["first_failure_at"],
                last_check_at=row["last_check_at"],
                dismissed=row.get("status") == "dismissed",
                dismissed_by=row.get("dismissed_by"),
            ))
```

`_flatten_sections` already exists in `engine.py` and is used elsewhere — import from `canon.sync.engine` at function scope to avoid a top-level cycle. If the function isn't already exported, add it to `engine.py` near the existing helpers or copy the small helper inline (it walks `section.children` recursively).

In the final `SpecDetail(...)` construction, add `broken_sections=broken_sections`.

Add `from canon.web.models import BrokenRef` if not already imported at the top of `services.py`.

- [ ] **Step 4: Run tests**

Run: `cd /Users/nickgerner/Code/canon-private && uv run pytest tests/test_web/test_services.py::TestGetSpecDetail -v`
Expected: PASS.

Run: `cd /Users/nickgerner/Code/canon-private && uv run pytest -q --ignore=tests/integration --ignore=tests/scenarios`
Expected: full suite passes.

- [ ] **Step 5: Lint + commit**

```bash
cd /Users/nickgerner/Code/canon-private && uv run ruff check src/canon/web/services.py tests/test_web/test_services.py && uv run ruff format src/canon/web/services.py tests/test_web/test_services.py
git add src/canon/web/services.py tests/test_web/test_services.py
git commit -m "feat(web): populate broken_sections in spec detail

get_spec_detail now accepts ref_store + installation_id kwargs and
attaches a list of BrokenRef entries (one per section whose ticket_ref
maps to a 'broken' row). Falls open to [] on store error or when the
kwargs are omitted."
```

---

## Task 5: Two new endpoints (`/broken-refs` and `/broken-refs/count`)

**Files:**
- Modify: `src/canon/web/routes.py`
- Modify: `src/canon/web/models.py` (add `BrokenRefsApiResponse` for the paginated list endpoint)
- Modify: `src/canon/web/services.py` (add `list_broken_refs` and `count_broken_refs` helpers)
- Modify: `src/canon/web/routes.py` to thread `ref_store` and `installation_id` through the existing dashboard + spec-detail endpoints
- Test: `tests/test_web/test_broken_refs_routes.py` (new)

- [ ] **Step 1: Add the response model**

In `src/canon/web/models.py`:

```python
class BrokenRefsApiResponse(BaseModel):
    """JSON response for GET /{org}/api/broken-refs."""

    items: list[BrokenRef]
    total: int
    limit: int
    offset: int
```

- [ ] **Step 2: Add service helpers in `web/services.py`**

```python
async def list_broken_refs(
    ref_store: object,
    installation_id: int,
    cache: TTLCache,
    *,
    org: str,
    spec_loader: object | None = None,  # for resolving section heading + spec_path; pass content_cache_store
    status: str = "broken",
    system: str | None = None,
    repo: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> tuple[list[BrokenRef], int]:
    """Return (items, total) for the paginated dashboard list.

    Filtering by repo / system happens here in Python after a single
    list_broken query — the row volume is small enough (broken-ref
    population is bounded by total spec count × ~1) that paging in SQL
    isn't worth the complexity in v1.
    """
    rows = await ref_store.list_broken(installation_id=installation_id, status=status)

    # Filter
    def matches(row: dict) -> bool:
        if system and row.get("system") != system:
            return False
        if repo:
            ref = row.get("ticket_ref", "")
            if "#" in ref and ref.rsplit("#", 1)[0] != repo:
                return False
            if "#" not in ref:
                # jira/linear rows don't carry a repo prefix → only
                # surface them when repo filter is empty
                return False
        return True

    filtered = [r for r in rows if matches(r)]
    total = len(filtered)

    # Look up spec_path + section_heading for each surviving row by
    # peeking into spec_documents (via spec_loader).  When the spec is
    # missing (e.g. the spec was deleted but the ticket_ref_status row
    # lingers), fall back to ticket_ref as the spec_path so the row
    # still surfaces in the dashboard. Never raise.
    items: list[BrokenRef] = []
    for row in filtered[offset : offset + limit]:
        items.append(_row_to_broken_ref(row))
    return items, total


def _row_to_broken_ref(row: dict) -> BrokenRef:
    """Convert a ticket_ref_status row dict into the API-facing model."""
    return BrokenRef(
        system=row["system"],
        ticket_ref=row["ticket_ref"],
        spec_path="",          # populated by section-aware callers (get_spec_detail)
        section_id="",         # ditto
        section_heading="",    # ditto
        error_kind=row["last_error_kind"] or "not_found",
        first_failure_at=row["first_failure_at"],
        last_check_at=row["last_check_at"],
        dismissed=row.get("status") == "dismissed",
        dismissed_by=row.get("dismissed_by"),
    )


async def count_broken_refs(
    ref_store: object,
    installation_id: int,
) -> int:
    """Return the count of broken (not dismissed) refs for an installation."""
    rows = await ref_store.list_broken(installation_id=installation_id, status="broken")
    return len(rows)
```

The dashboard list elides per-section enrichment in v1 — the panel is keyed off `ticket_ref` and shows the system/error/timestamps. Click navigation will route the user to the spec view where the per-section badges (already wired in Task 4 via `broken_sections`) provide the section context. This avoids a per-row spec-load round trip in the dashboard.

- [ ] **Step 3: Register the two endpoints in `web/routes.py`**

Near the other `/{org}/api/*` routes:

```python
@app_router.get("/{org}/api/broken-refs", response_class=JSONResponse)
async def api_broken_refs(
    request: Request,
    org: str,
    status: str = "broken",
    system: str | None = None,
    repo: str | None = None,
    limit: int = 50,
    offset: int = 0,
    _user: CurrentUser = Depends(require_permission(Permission.SPECS_READ)),
):
    """Paginated list of broken refs for the dashboard."""
    ref_store = getattr(request.app.state, "ref_store", None)
    if ref_store is None:
        return JSONResponse(content={"items": [], "total": 0, "limit": limit, "offset": offset})

    client = await _get_client_for_org(request, org)
    installation_id = int(client.installation_id) if client.installation_id else None
    if installation_id is None:
        return JSONResponse(content={"items": [], "total": 0, "limit": limit, "offset": offset})

    cache = _get_cache(request)
    items, total = await list_broken_refs(
        ref_store, installation_id, cache,
        org=org, status=status, system=system, repo=repo,
        limit=limit, offset=offset,
    )
    return JSONResponse(content=BrokenRefsApiResponse(
        items=items, total=total, limit=limit, offset=offset,
    ).model_dump(mode="json"))


@app_router.get("/{org}/api/broken-refs/count", response_class=JSONResponse)
async def api_broken_refs_count(
    request: Request,
    org: str,
    _user: CurrentUser = Depends(require_permission(Permission.SPECS_READ)),
):
    """Cheap count for navbar / dashboard chip polling."""
    ref_store = getattr(request.app.state, "ref_store", None)
    if ref_store is None:
        return JSONResponse(content={"count": 0})

    client = await _get_client_for_org(request, org)
    installation_id = int(client.installation_id) if client.installation_id else None
    if installation_id is None:
        return JSONResponse(content={"count": 0})

    count = await count_broken_refs(ref_store, installation_id)
    return JSONResponse(content={"count": count})
```

- [ ] **Step 4: Thread `ref_store` and `installation_id` into the existing dashboard + spec-detail endpoints**

Find the existing `api_dashboard` handler in `routes.py`. Currently it calls:

```python
overview = await get_org_overview(
    client,
    org,
    cache,
    search_index=search_index,
    content_cache_store=_get_content_cache(request),
)
```

Add the two new kwargs:

```python
overview = await get_org_overview(
    client,
    org,
    cache,
    search_index=search_index,
    content_cache_store=_get_content_cache(request),
    ref_store=getattr(request.app.state, "ref_store", None),
    installation_id=int(client.installation_id) if client.installation_id else None,
)
```

Same edit for the `api_spec_detail` handler — pass `ref_store` and `installation_id` into `get_spec_detail`.

- [ ] **Step 5: Write the route tests** at `tests/test_web/test_broken_refs_routes.py`

```python
"""FastAPI TestClient tests for the broken-refs read endpoints."""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi.testclient import TestClient

# Existing test infra in tests/test_web/conftest.py provides an
# authenticated client fixture. Pattern matches the other route tests.

# … (boilerplate skipped — copy the auth/install fixture from
# tests/test_web/test_routes.py::TestDashboard or wherever the existing
# /api/dashboard tests live) …


class TestBrokenRefsList:
    async def test_returns_empty_when_no_ref_store(self, client_no_store):
        r = client_no_store.get("/app/canonhq/api/broken-refs")
        assert r.status_code == 200
        assert r.json() == {"items": [], "total": 0, "limit": 50, "offset": 0}

    async def test_returns_rows(self, client_with_store_ok):
        r = client_with_store_ok.get("/app/canonhq/api/broken-refs?limit=10")
        assert r.status_code == 200
        body = r.json()
        assert body["total"] >= 0
        assert isinstance(body["items"], list)
        assert body["limit"] == 10
        assert body["offset"] == 0

    async def test_filters_by_system(self, client_with_store_ok):
        r = client_with_store_ok.get("/app/canonhq/api/broken-refs?system=github")
        assert r.status_code == 200
        for item in r.json()["items"]:
            assert item["system"] == "github"

    async def test_requires_authenticated_user(self, client_unauth):
        r = client_unauth.get("/app/canonhq/api/broken-refs")
        assert r.status_code in (401, 403)


class TestBrokenRefsCount:
    async def test_returns_zero_when_no_ref_store(self, client_no_store):
        r = client_no_store.get("/app/canonhq/api/broken-refs/count")
        assert r.status_code == 200
        assert r.json() == {"count": 0}

    async def test_returns_count(self, client_with_store_ok):
        r = client_with_store_ok.get("/app/canonhq/api/broken-refs/count")
        assert r.status_code == 200
        assert "count" in r.json()
        assert isinstance(r.json()["count"], int)

    async def test_requires_authenticated_user(self, client_unauth):
        r = client_unauth.get("/app/canonhq/api/broken-refs/count")
        assert r.status_code in (401, 403)


class TestDashboardAugmentation:
    async def test_dashboard_includes_total_broken_refs(self, client_with_store_ok):
        r = client_with_store_ok.get("/app/canonhq/api/dashboard")
        assert r.status_code == 200
        body = r.json()
        assert "total_broken_refs" in body
        assert isinstance(body["total_broken_refs"], int)
        for repo in body.get("repos_with_specs", []):
            assert "broken_refs_count" in repo
```

The fixtures `client_no_store`, `client_with_store_ok`, and `client_unauth` need to be defined in this file or pulled from `tests/test_web/conftest.py`. **Implementer:** read `tests/test_web/conftest.py` to identify the existing client/auth fixture pattern and adapt — likely `client` and `authenticated_client` already exist; you'll add `client_no_store` and `client_with_store_ok` variants that override `app.state.ref_store` for the test.

If the existing test infra doesn't make this trivial, fall back to mocking `request.app.state.ref_store` per test using `app.dependency_overrides` or a fixture that monkeypatches `request.app.state.ref_store` before the request.

- [ ] **Step 6: Run the new tests**

Run: `cd /Users/nickgerner/Code/canon-private && uv run pytest tests/test_web/test_broken_refs_routes.py -v`
Expected: PASS — all 8 tests green.

Run: `cd /Users/nickgerner/Code/canon-private && uv run pytest -q --ignore=tests/integration --ignore=tests/scenarios`
Expected: 0 failures.

- [ ] **Step 7: Lint + commit**

```bash
cd /Users/nickgerner/Code/canon-private && uv run ruff check src/canon/web/ tests/test_web/test_broken_refs_routes.py && uv run ruff format src/canon/web/ tests/test_web/test_broken_refs_routes.py
git add src/canon/web/models.py src/canon/web/routes.py src/canon/web/services.py tests/test_web/test_broken_refs_routes.py
git commit -m "feat(web): GET /broken-refs and /broken-refs/count

Two new read endpoints. The dashboard panel polls /broken-refs with
filters; the navbar chip polls /broken-refs/count. Both gated on
Permission.SPECS_READ. ref_store and installation_id are also threaded
into the existing /api/dashboard and /api/specs/... handlers so
total_broken_refs / broken_refs_count / broken_sections are populated
end-to-end."
```

---

## Task 6: API client + types in the frontend

**Files:**
- Create: `frontend/src/api/broken_refs.ts`

- [ ] **Step 1: Create the API client module**

```typescript
import { get } from './client'
import type { BrokenRef } from './types'

export interface BrokenRefsListResponse {
  items: BrokenRef[]
  total: number
  limit: number
  offset: number
}

export interface BrokenRefsCountResponse {
  count: number
}

export function fetchBrokenRefs(
  org: string,
  params: {
    status?: 'broken' | 'dismissed'
    system?: 'jira' | 'linear' | 'github'
    repo?: string
    limit?: number
    offset?: number
  } = {},
): Promise<BrokenRefsListResponse> {
  const qs = new URLSearchParams()
  if (params.status) qs.set('status', params.status)
  if (params.system) qs.set('system', params.system)
  if (params.repo) qs.set('repo', params.repo)
  if (params.limit !== undefined) qs.set('limit', String(params.limit))
  if (params.offset !== undefined) qs.set('offset', String(params.offset))
  const suffix = qs.toString() ? `?${qs.toString()}` : ''
  return get<BrokenRefsListResponse>(`/app/${org}/api/broken-refs${suffix}`)
}

export function fetchBrokenRefsCount(org: string): Promise<BrokenRefsCountResponse> {
  return get<BrokenRefsCountResponse>(`/app/${org}/api/broken-refs/count`)
}
```

- [ ] **Step 2: Type-check + lint**

Run:
```
cd /Users/nickgerner/Code/canon-private/frontend && npm run type-check
cd /Users/nickgerner/Code/canon-private/frontend && npm run lint
```
Expected: clean.

- [ ] **Step 3: Commit**

```bash
git add frontend/src/api/broken_refs.ts
git commit -m "feat(frontend): add broken-refs API client

Mirrors dashboard.ts shape — typed wrappers over GET /broken-refs and
GET /broken-refs/count. Used by BrokenRefsPanel + the dashboard chip
in the next task."
```

---

## Task 7: `BrokenRefBadge.vue` (inline indicator + popover)

**Files:**
- Create: `frontend/src/components/spec/BrokenRefBadge.vue`

- [ ] **Step 1: Read an existing small inline component for the style baseline**

Read `frontend/src/components/spec/SpecHeader.vue` and `frontend/src/components/common/EmptyState.vue` to understand: `<script setup lang="ts">` + Tailwind + Composition API conventions. Match these.

- [ ] **Step 2: Create the badge component**

```vue
<script setup lang="ts">
import { ref } from 'vue'
import type { BrokenRef } from '@/api/types'

defineProps<{
  brokenRef: BrokenRef
}>()

// Action callbacks are no-ops in §3 — wired up in §4. Buttons render
// disabled to signal the state.
const showPopover = ref(false)

function togglePopover() {
  showPopover.value = !showPopover.value
}

function formatRelativeTime(iso: string): string {
  const ms = Date.now() - new Date(iso).getTime()
  const days = Math.floor(ms / 86_400_000)
  const hours = Math.floor(ms / 3_600_000)
  if (days >= 1) return `${days} day${days === 1 ? '' : 's'} ago`
  if (hours >= 1) return `${hours} hour${hours === 1 ? '' : 's'} ago`
  return 'just now'
}
</script>

<template>
  <span class="relative inline-block">
    <button
      type="button"
      class="ml-2 inline-flex items-center gap-1 rounded bg-red-100 px-2 py-0.5 text-xs font-semibold text-red-800 hover:bg-red-200"
      @click="togglePopover"
    >
      <span aria-hidden="true">⚠</span>
      BROKEN
    </button>

    <div
      v-if="showPopover"
      class="absolute left-0 top-full z-10 mt-1 w-72 rounded border border-red-200 bg-white p-3 shadow-lg"
    >
      <div class="mb-1 font-semibold text-red-800">
        {{ brokenRef.error_kind === 'not_found' ? 'Ticket not found' :
           brokenRef.error_kind === 'forbidden' ? 'Permission denied' :
           'Authentication failed' }}
      </div>
      <div class="mb-3 text-xs text-gray-600">
        {{ brokenRef.system }} {{ brokenRef.ticket_ref }}<br>
        First failed: <strong>{{ formatRelativeTime(brokenRef.first_failure_at) }}</strong><br>
        Last checked: <strong>{{ formatRelativeTime(brokenRef.last_check_at) }}</strong>
      </div>
      <div class="flex flex-col gap-1.5">
        <button
          type="button"
          class="rounded bg-red-600 px-3 py-1.5 text-xs font-semibold text-white opacity-50 cursor-not-allowed"
          disabled
          title="Available in §4"
        >
          Remove ref (opens PR)
        </button>
        <button
          type="button"
          class="rounded border border-gray-300 bg-white px-3 py-1.5 text-xs font-semibold text-gray-700 opacity-50 cursor-not-allowed"
          disabled
          title="Available in §4"
        >
          Dismiss
        </button>
        <button
          type="button"
          class="rounded border border-gray-300 bg-white px-3 py-1.5 text-xs font-semibold text-gray-700 opacity-50 cursor-not-allowed"
          disabled
          title="Available in §4"
        >
          Re-check now
        </button>
      </div>
    </div>
  </span>
</template>
```

- [ ] **Step 3: Type-check + lint**

```
cd /Users/nickgerner/Code/canon-private/frontend && npm run type-check
cd /Users/nickgerner/Code/canon-private/frontend && npm run lint
```
Expected: clean.

- [ ] **Step 4: Commit**

```bash
git add frontend/src/components/spec/BrokenRefBadge.vue
git commit -m "feat(frontend): BrokenRefBadge component

Inline red BROKEN chip rendered next to a section's ticket reference;
click toggles a popover showing error_kind, first/last-failed
timestamps, and the three action buttons (Remove ref / Dismiss /
Re-check now). Buttons are disabled in §3 — wired to endpoints in §4."
```

---

## Task 8: `BrokenRefsPanel.vue` (dashboard list with filters)

**Files:**
- Create: `frontend/src/components/dashboard/BrokenRefsPanel.vue`

- [ ] **Step 1: Read an existing dashboard panel for the style baseline**

Read `frontend/src/components/dashboard/SpecList.vue` and `frontend/src/components/dashboard/RepoCard.vue` for layout conventions (Tailwind, table-vs-card decisions, filter bar shape).

- [ ] **Step 2: Create the panel component**

```vue
<script setup lang="ts">
import { ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useQuery } from '@tanstack/vue-query'
import { fetchBrokenRefs } from '@/api/broken_refs'
import type { BrokenRef } from '@/api/types'

const props = defineProps<{
  org: string
  totalCount: number
}>()

const router = useRouter()

const status = ref<'broken' | 'dismissed'>('broken')
const system = ref<'' | 'jira' | 'linear' | 'github'>('')
const repo = ref<string>('')
const limit = ref(10)
const offset = ref(0)

const { data, isLoading, refetch } = useQuery({
  queryKey: ['broken-refs', props.org, status, system, repo, limit, offset],
  queryFn: () => fetchBrokenRefs(props.org, {
    status: status.value,
    system: system.value || undefined,
    repo: repo.value || undefined,
    limit: limit.value,
    offset: offset.value,
  }),
})

watch([status, system, repo], () => {
  offset.value = 0
})

function navigateToSpec(item: BrokenRef) {
  // spec_path is "owner/repo/file_path" — split into the route shape
  // /spec/{owner}/{repo}/{file_path}
  // The spec_path field comes from the per-spec badge population path
  // (Task 4); the dashboard list endpoint doesn't populate it (it
  // would require a per-row spec lookup). When spec_path is empty we
  // still surface the row but make the click a no-op rather than
  // routing to a broken URL.
  if (!item.spec_path) return
  const [owner, repoName, ...rest] = item.spec_path.split('/')
  router.push(`/app/${props.org}/spec/${owner}/${repoName}/${rest.join('/')}`)
}

function formatRelativeTime(iso: string): string {
  const ms = Date.now() - new Date(iso).getTime()
  const days = Math.floor(ms / 86_400_000)
  return days >= 1 ? `${days}d` : 'today'
}
</script>

<template>
  <section class="rounded border border-red-200 bg-white p-4">
    <header class="mb-3 flex items-center justify-between">
      <h3 class="font-semibold text-red-800">
        ⚠ Broken ticket references ({{ props.totalCount }})
      </h3>
      <div class="flex gap-2 text-xs">
        <select v-model="system" class="rounded border border-gray-300 px-2 py-1">
          <option value="">All systems</option>
          <option value="github">GitHub</option>
          <option value="jira">Jira</option>
          <option value="linear">Linear</option>
        </select>
        <select v-model="status" class="rounded border border-gray-300 px-2 py-1">
          <option value="broken">Active</option>
          <option value="dismissed">Dismissed</option>
        </select>
      </div>
    </header>

    <div v-if="isLoading" class="text-xs text-gray-500">Loading…</div>

    <ul v-else-if="data && data.items.length > 0" class="divide-y divide-red-100">
      <li
        v-for="item in data.items"
        :key="`${item.system}:${item.ticket_ref}`"
        class="flex items-center justify-between py-2 text-sm"
        :class="item.spec_path ? 'cursor-pointer hover:bg-red-50' : ''"
        @click="navigateToSpec(item)"
      >
        <div>
          <div class="font-semibold">{{ item.ticket_ref }}</div>
          <div class="text-xs text-gray-600">
            {{ item.system }} · {{ item.error_kind }} ·
            {{ formatRelativeTime(item.first_failure_at) }}
          </div>
        </div>
        <div class="flex gap-1.5 text-xs">
          <button
            type="button"
            class="rounded border border-red-300 bg-white px-2 py-1 font-semibold text-red-700 opacity-50"
            disabled
            title="Available in §4"
          >
            Remove
          </button>
          <button
            type="button"
            class="rounded border border-gray-300 bg-white px-2 py-1 text-gray-700 opacity-50"
            disabled
            title="Available in §4"
          >
            Dismiss
          </button>
        </div>
      </li>
    </ul>

    <div v-else class="text-xs text-gray-500">No broken refs.</div>

    <footer
      v-if="data && data.total > limit"
      class="mt-3 flex items-center justify-between text-xs"
    >
      <button
        type="button"
        class="rounded border px-2 py-1"
        :disabled="offset === 0"
        @click="offset = Math.max(0, offset - limit)"
      >
        Previous
      </button>
      <span>
        {{ offset + 1 }} – {{ Math.min(offset + limit, data.total) }} of {{ data.total }}
      </span>
      <button
        type="button"
        class="rounded border px-2 py-1"
        :disabled="offset + limit >= data.total"
        @click="offset = offset + limit"
      >
        Next
      </button>
    </footer>
  </section>
</template>
```

- [ ] **Step 3: Type-check + lint**

```
cd /Users/nickgerner/Code/canon-private/frontend && npm run type-check
cd /Users/nickgerner/Code/canon-private/frontend && npm run lint
```
Expected: clean.

- [ ] **Step 4: Commit**

```bash
git add frontend/src/components/dashboard/BrokenRefsPanel.vue
git commit -m "feat(frontend): BrokenRefsPanel component

Dashboard panel listing broken ticket refs across the org. Filters by
system + status (Active / Dismissed), 10-row paging, click-row
navigates to the spec view (only when spec_path is populated — the
list endpoint omits per-row enrichment in v1). Action buttons stub
disabled until §4."
```

---

## Task 9: Mount the components in `OrgDashboard.vue` and the spec section renderer

**Files:**
- Modify: `frontend/src/components/dashboard/OrgDashboard.vue`
- Modify: the section renderer that displays a section's ticket link. Implementer reads `frontend/src/components/spec/SpecSectionCard.vue` and `frontend/src/components/spec/SpecAcceptanceCriteria.vue` and decides which one renders the ticket link → mounts `<BrokenRefBadge>` next to it.

- [ ] **Step 1: Add the dashboard panel + chip**

In `OrgDashboard.vue`, near the existing top-of-page metric chips (or wherever they belong; explore the file before editing), add:

```vue
<div
  v-if="overview.total_broken_refs > 0"
  class="inline-flex items-center gap-1 rounded bg-red-100 px-2.5 py-1 text-xs font-semibold text-red-800"
>
  ⚠ {{ overview.total_broken_refs }} broken refs
</div>
```

After the existing repo list block, add:

```vue
<BrokenRefsPanel
  v-if="overview.total_broken_refs > 0"
  :org="overview.org"
  :total-count="overview.total_broken_refs"
  class="mt-6"
/>
```

Add `import BrokenRefsPanel from '@/components/dashboard/BrokenRefsPanel.vue'` at the top of the `<script setup>` block.

- [ ] **Step 2: Mount the badge in the spec section renderer**

Read `frontend/src/components/spec/SpecSectionCard.vue` (and any neighbours that render `section.ticket_link`). Identify where the ticket link is displayed. Just after that markup, add:

```vue
<BrokenRefBadge
  v-if="brokenRef"
  :broken-ref="brokenRef"
/>
```

Add a computed `brokenRef` derived from a new prop `brokenSections: BrokenRef[]` matching against `section.id`:

```typescript
import { computed } from 'vue'
import BrokenRefBadge from './BrokenRefBadge.vue'
import type { BrokenRef } from '@/api/types'

const props = defineProps<{
  section: SpecSection            // existing prop
  brokenSections?: BrokenRef[]    // new optional prop, default []
}>()

const brokenRef = computed<BrokenRef | undefined>(() => {
  return (props.brokenSections ?? []).find(b => b.section_id === props.section.id)
})
```

Then the parent (likely `SpecDetail.vue` or `SpecContent.vue`) needs to thread `brokenSections` from `specDetail.broken_sections` down into each `<SpecSectionCard>`. Implementer follows the data flow and adds the prop pass-through.

- [ ] **Step 3: Type-check + lint**

```
cd /Users/nickgerner/Code/canon-private/frontend && npm run type-check
cd /Users/nickgerner/Code/canon-private/frontend && npm run lint
```
Expected: clean.

- [ ] **Step 4: Manual smoke test (optional but recommended)**

Run: `cd /Users/nickgerner/Code/canon-private/frontend && npm run dev`
Open the dashboard URL — confirm:
- The `⚠ N broken refs` chip appears when total > 0.
- The `BrokenRefsPanel` renders below the repo list.
- Filters change query params; "Next" / "Previous" page through results.
- Clicking a row with `spec_path` navigates to the spec view.
- On the spec view, sections with broken refs show the inline `BROKEN` chip.

(This step is optional because the §3 deploy will exercise the same paths; type-check passing is the gate.)

- [ ] **Step 5: Commit**

```bash
git add frontend/src/components/dashboard/OrgDashboard.vue frontend/src/components/spec/SpecSectionCard.vue frontend/src/components/spec/SpecDetail.vue
git commit -m "feat(frontend): mount BrokenRefBadge + BrokenRefsPanel in views

Dashboard shows the panel + metric chip when total_broken_refs > 0;
spec view shows the inline BROKEN chip on sections whose section_id
matches a broken_sections entry. Read-only display in §3 — popover
actions are wired in §4."
```

---

## Task 10: Push branch + open PR

- [ ] **Step 1: Push**

```bash
git push -u origin spec/broken-refs-section-3
```

- [ ] **Step 2: Open PR**

```bash
gh pr create --title "feat: broken-refs read API + UI (§3 of broken-ticket-refs-ui)" \
  --base spec/broken-ticket-refs-ui \
  --body "$(cat <<'EOF'
Second slice of the broken-ticket-refs-ui spec. **Stacked on PR #667 (§2).**
[Spec](docs/specs/broken-ticket-refs-ui.md) · [Plan](docs/superpowers/plans/2026-05-04-broken-ticket-refs-read-api-ui.md)

## What this PR does

Surfaces broken ticket refs in the Canon UI:

- **Dashboard** — `⚠ N broken refs` metric chip + `BrokenRefsPanel` below the repo list (filters by system + status, 10-row paging, click-row navigation to the spec).
- **Spec view** — inline `BROKEN` chip next to each broken section's ticket reference; click toggles a popover with the error kind, first-failed / last-checked timestamps, and three action buttons.
- **Action buttons stubs** (Remove ref / Dismiss / Re-check now) — render disabled. Wired in §4.

## What this PR does NOT do

- Mutating endpoints (dismiss / re-check / remove-ref). All three buttons are visually disabled with tooltips pointing to §4.
- create_doc_pr integration for "Remove ref". Same — §4.

## Architecture summary

- New endpoints `GET /{org}/api/broken-refs` and `GET /{org}/api/broken-refs/count` (both gated on `Permission.SPECS_READ`).
- `OrgOverview` augmented with `total_broken_refs` + per-repo `broken_refs_count`; `SpecDetail` augmented with `broken_sections`.
- Two new Vue components: `BrokenRefBadge` (inline) and `BrokenRefsPanel` (dashboard list).
- API client at `frontend/src/api/broken_refs.ts`.
- TanStack Vue Query handles the panel data fetch; refetch on filter / paging changes.

## Test plan

- [x] Backend: extends `TestGetOrgOverview` and `TestGetSpecDetail` plus a new `tests/test_web/test_broken_refs_routes.py` with route-level coverage of both endpoints + the dashboard / spec-detail augmentations.
- [x] Frontend: `vue-tsc --noEmit` passes (no Vitest in this codebase).
- [ ] Post-deploy: load `/app/canonhq/`, see the `⚠ N broken refs` chip + panel; open a spec with a known broken ref; see the inline badge.

## Notes

- Dashboard list endpoint omits per-row spec_path / section_id enrichment in v1 — that would require a per-row spec load. The user clicks through to the spec view, where the existing `broken_sections` payload (populated in `get_spec_detail`) drives the inline badges. This avoids fan-out in the dashboard request and keeps p95 in line with the existing dashboard latency.
- §2 follow-up still open: Postgres integration test for the store's concurrency + dismissed-stickiness invariants.

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

`--base spec/broken-ticket-refs-ui` makes the PR diff against the §2 branch (so reviewers see only the §3 commits). When §2 merges to main, GitHub auto-rebases the §3 PR onto main.

- [ ] **Step 3: Confirm CI**

Wait for the GitHub Actions checks. Expect lint, helm-lint, smoke, scenarios, integration, unit, and the preview deploy to pass. The preview namespace will run with opensearch disabled (PR #663's preview-values fix is already on the §2 branch).

---

## Self-Review

**1. Spec coverage:** Walked the §3 acceptance criteria from `docs/specs/broken-ticket-refs-ui.md`:

| AC | Task |
|----|------|
| `OrgOverview` and `SpecDetail` Pydantic models include the new fields | Task 1 |
| `GET /{org}/api/broken-refs` returns paginated rows with system + repo + status filters | Task 5 |
| `GET /{org}/api/broken-refs/count` returns a single-int response | Task 5 |
| `BrokenRefBadge.vue` renders inline; popover toggles open/closed; the three action buttons exist (callbacks no-op) | Task 7 |
| `BrokenRefsPanel.vue` renders rows, filters mutate query params, paging works at the 10-row default | Task 8 |
| `DashboardView.vue` shows the `⚠ N broken refs` chip and panel only when `total_broken_refs > 0` | Task 9 |
| `SpecView.vue` mounts `BrokenRefBadge` only on sections with broken refs | Task 9 (via `SpecSectionCard.vue` — implementer confirms exact host file) |
| FastAPI route tests cover happy path + permission checks for each new endpoint | Task 5 |
| ~~Vitest component tests cover `BrokenRefBadge`, `BrokenRefsPanel`~~ | **Dropped** — Vitest is not part of this codebase. `vue-tsc --noEmit` is the type-level gate; manual smoke testing on the preview deploy validates render + interaction. The spec AC will be updated to reflect this.

**2. Placeholder scan:** No "TBD" / "TODO" / "implement later" left in steps. The two implementer-discretion points (where in `SpecSectionCard.vue` to mount the badge; which existing test fixtures to reuse for the route tests) are explicit reads-the-codebase-then-decides moments rather than placeholders — concrete code blocks accompany them.

**3. Type consistency:** `BrokenRef` shape is identical between `web/models.py` and `frontend/src/api/types.ts`. `installation_id: int | None` in services matches the existing pattern from §2. `total_broken_refs: int` (default 0) matches across Pydantic + TS.

**4. Spec AC update:** drop the Vitest entries from §3 AC list. One-line spec edit; the implementer can include it in Task 9's commit or as a tiny follow-up.
