---
title: "CI Actions Adoption & Issue Triage Extension"
status: draft
owner: ng
team: platform
ticket_project: null
created: 2026-05-06
updated: 2026-05-06
tags: [ci, automation, github-actions, dogfooding, extensions, issue-triage, ai-agent]
depends_on: [github-actions-suite, plugin-ecosystem]
---

# CI Actions Adoption & Issue Triage Extension

Dogfood Canon's published GitHub Actions in both canon-private and the OSS repo,
and ship a new `issue-triage` extension that classifies incoming GitHub issues,
matches them to existing specs, and creates new specs when warranted.

## 1. Background

<!-- canon:system:1 status:draft -->
Canon ships 14 composite actions and 2 reusable workflows via `canonhq/canon`
(see `github-actions-suite.md`). Neither canon-private nor the OSS repo
currently *consumes* any of these actions as a user would. This creates two
problems:

1. **No dogfooding signal.** We don't experience the actions as consumers do, so
   friction and bugs go unnoticed until external users hit them.
2. **No demonstration.** The OSS repo should serve as a reference implementation
   showing how to wire Canon Actions into a real project.

Separately, Canon has no mechanism to handle *inbound* GitHub issues from OSS
users. Issues sit unlabeled, untriaged, and disconnected from specs. The
extension system (`src/canon/extensions/`) already supports skills, hooks, MCP
tools, and agents — we can build an `issue-triage` extension that brings Claude
intelligence to issue classification and spec creation.

### Existing infrastructure

- **Actions suite:** fully built and tested (per `github-actions-suite.md`)
- **Extension system:** manifest-based, supports adapters/skills/commands/hooks/
  MCP tools/agents (`src/canon/extensions/`)
- **Issue webhook handler:** `on_issues.py` handles `opened` events but only
  does reverse sync for *already-linked* issues
- **Agent infrastructure:** `ClaudeClient`, `spec_generator.py` (streaming spec
  creation from description), `ErrorTriager` (creates issues from errors with
  spec context)
- **GitHub adapter:** full CRUD for issues, labels, PRs, comments

## 2. Goals & Non-Goals

<!-- canon:system:2 status:draft -->
**Goals**

- Wire Canon Actions into canon-private's CI so we experience them as consumers.
- Wire Canon Actions into the OSS repo as a reference implementation.
- Build an `issue-triage` extension in the OSS repo that classifies issues,
  matches to specs, and optionally creates new specs.
- Ship a companion `issue-triage` composite action so consumers can enable
  triage via GitHub Actions (without the Canon GitHub App).

**Non-Goals**

- Rewriting or modifying the actions themselves (that's `github-actions-suite`).
- Full conversational issue-bot (ask clarifying questions, multi-turn). V1 is
  fire-and-forget: classify, label, comment, optionally open spec PR.
- Replacing human review of created specs. Auto-created specs are always draft
  PRs requiring approval.

## 3. Requirements

<!-- canon:system:3 status:draft -->

### 3.1 Dogfood: canon-private PR Workflow
<!-- canon:system:3.1 status:todo -->

<!-- canon:ticket:github:691 url:https://github.com/canonhq/canon-private/issues/691 -->
Wire `canonhq/canon/.github/workflows/reusable/pr-checks.yml@v1` into
canon-private's CI pipeline for all pull requests.

#### Acceptance Criteria

- [ ] `.github/workflows/canon-pr-checks.yml` exists in canon-private, triggered
  on `pull_request` targeting `main`.
- [ ] Uses `canonhq/canon/.github/workflows/reusable/pr-checks.yml@v1` with
  appropriate inputs (specs glob: `docs/specs/**`).
- [ ] PR checks appear as required status checks named "Canon / spec-lint",
  "Canon / verify", "Canon / coverage-delta".
- [ ] Coverage delta posts a sticky PR comment showing per-spec changes.
- [ ] The workflow does not duplicate checks already run by existing CI jobs.

### 3.2 Dogfood: canon-private Weekly Audit
<!-- canon:system:3.2 status:todo -->

<!-- canon:ticket:github:692 url:https://github.com/canonhq/canon-private/issues/692 -->
Wire `canonhq/canon/.github/workflows/reusable/weekly-audit.yml@v1` into
canon-private on a weekly schedule.

#### Acceptance Criteria

- [ ] `.github/workflows/canon-weekly-audit.yml` exists in canon-private,
  triggered on `schedule` (weekly, Mondays 9am UTC) and `workflow_dispatch`.
- [ ] Uses `canonhq/canon/.github/workflows/reusable/weekly-audit.yml@v1` with
  `CANON_TOKEN` from secrets.
- [ ] Creates/updates a rolling issue titled "Canon Weekly Audit" with drift
  findings.
- [ ] Coverage report updates a rolling issue titled "Canon Coverage Report".
- [ ] Stale spec check surfaces any specs older than 90 days with active code
  churn in the same rolling issue.

### 3.3 Dogfood: canon-private Release Notes
<!-- canon:system:3.3 status:todo -->

<!-- canon:ticket:github:693 url:https://github.com/canonhq/canon-private/issues/693 -->
Add spec-driven release notes generation to the release workflow.

#### Acceptance Criteria

- [ ] The existing `publish.yml` (or a new job within it) calls
  `canonhq/canon/actions/release-notes@v1` on tag push.
- [ ] Release notes appear in the GitHub Release body, grouped by spec with
  links to realization PRs.
- [ ] Does not conflict with existing changelog automation.

### 3.4 Dogfood: OSS Repo PR Checks
<!-- canon:system:3.4 status:todo -->

<!-- canon:ticket:github:694 url:https://github.com/canonhq/canon-private/issues/694 -->
Wire PR checks into the public `canonhq/canon` repo.

#### Acceptance Criteria

- [ ] `.github/workflows/canon-pr-checks.yml` exists in the OSS repo, triggered
  on `pull_request`.
- [ ] Runs `spec-lint` on any changes to `docs/` directory.
- [ ] Runs `verify` against the full spec tree.
- [ ] Posts coverage-delta comment on PRs that touch specs or source.
- [ ] Serves as the canonical example of how external consumers wire Canon
  Actions.

### 3.5 Dogfood: OSS Repo Stale Spec Check
<!-- canon:system:3.5 status:todo -->

<!-- canon:ticket:github:695 url:https://github.com/canonhq/canon-private/issues/695 -->
Run stale-spec-check on a schedule in the OSS repo.

#### Acceptance Criteria

- [ ] `.github/workflows/canon-stale-specs.yml` exists with weekly schedule.
- [ ] Opens/updates a rolling issue when specs drift.
- [ ] No `CANON_TOKEN` required (stale-spec-check is free/local).

### 3.6 Issue Triage Extension — Core Logic
<!-- canon:system:3.6 status:done -->

<!-- canon:ticket:github:696 url:https://github.com/canonhq/canon-private/issues/696 -->
Build the `issue-triage` extension that classifies incoming issues and relates
them to specs.

#### Acceptance Criteria

- [ ] Extension lives at `extensions/issue-triage/` in the OSS repo with a valid
  `canon-extension.yml` manifest.
- [ ] Provides a `triage_issue` MCP tool that accepts issue number + repo and
  returns classification + matched specs.
- [ ] Classification categories: `feature-request`, `bug-report`, `question`,
  `duplicate`, `support`.
- [ ] Matching algorithm: parse all spec files, extract titles + AC text, use
  Claude to determine relevance score (0–1) for each spec against the issue.
- [ ] Top 3 matching specs (score > 0.5) are included in the triage result.
- [ ] Extension provides a skill file (`skills/issue-triage/SKILL.md`) with
  prompt instructions for the triage agent.

### 3.7 Issue Triage Extension — GitHub Integration
<!-- canon:system:3.7 status:done -->

The extension responds to issues by labeling, commenting, and optionally
creating spec PRs.

#### Acceptance Criteria

- [ ] On triage, applies labels based on classification (`canon:feature-request`,
  `canon:bug`, `canon:question`, `canon:duplicate`, `canon:support`).
- [ ] Posts a comment on the issue with:
  - Classification result and confidence
  - Related specs (linked, with section references)
  - If feature-request with no matching spec: "I'll create a draft spec for
    this" (when auto-create is enabled)
- [ ] When `auto_create_specs: true` in config and classification is
  `feature-request` with no strong spec match (all scores < 0.3):
  - Calls `spec_generator` with the issue title + body as input
  - Creates a new branch, commits the draft spec, opens a PR
  - Links the PR back to the issue via comment
  - Adds `<!-- canon:ticket:github:<issue_number> -->` to the spec
- [ ] When classification is `duplicate`, links to the matching issue/spec and
  suggests closing.
- [ ] All GitHub API calls use the standard `GITHUB_TOKEN` (no Canon backend
  dependency for the action path).

### 3.8 Issue Triage Extension — Configuration
<!-- canon:system:3.8 status:done -->

<!-- canon:ticket:github:697 url:https://github.com/canonhq/canon-private/issues/697 -->
Configurable behavior via CANON.yaml.

#### Acceptance Criteria

- [ ] `CANON.yaml` supports a new `triage:` section:
  ```yaml
  triage:
    enabled: true
    auto_create_specs: false  # require human approval by default
    classify_labels: true
    ignore_labels: ["wontfix", "invalid"]
    ignore_authors: []  # bots, etc.
    spec_template: "docs/specs/_template.md"
    confidence_threshold: 0.7  # minimum confidence to act
  ```
- [ ] When `enabled: false`, the extension is a no-op on webhook events.
- [ ] `ignore_labels` prevents triage of issues that already have those labels.
- [ ] `ignore_authors` skips issues from bots or specific users.
- [ ] `confidence_threshold` controls how confident the classifier must be
  before applying labels or creating specs.

### 3.9 Issue Triage Action — Composite Action
<!-- canon:system:3.9 status:todo -->

<!-- canon:ticket:github:698 url:https://github.com/canonhq/canon-private/issues/698 -->
Ship a `actions/issue-triage/action.yml` composite action for consumers who
don't use the Canon GitHub App.

#### Acceptance Criteria

- [ ] `actions/issue-triage/action.yml` exists as a composite action.
- [ ] Inputs: `canon-token` (required unless `anthropic-api-key` provided),
  `anthropic-api-key` (BYOK fallback for self-hosters), `auto-create`
  (default `false`), `confidence-threshold` (default `0.7`), `specs` (glob,
  default `docs/specs/**`).
- [ ] Triggered by `issues: [opened]` events (documented in example workflow).
- [ ] Installs Canon CLI + issue-triage extension, runs
  `canon triage --issue ${{ github.event.issue.number }}`.
- [ ] Posts results as issue comment and applies labels.
- [ ] When `auto-create: true`, opens spec draft PR and links to issue.
- [ ] Action outputs: `classification`, `confidence`, `matched-specs` (JSON),
  `spec-pr-url` (if created).

### 3.10 Issue Triage CLI Command
<!-- canon:system:3.10 status:done -->

<!-- canon:ticket:github:699 url:https://github.com/canonhq/canon-private/issues/699 -->
A `canon triage` CLI command that orchestrates the triage flow locally or in CI.

#### Acceptance Criteria

- [ ] `canon triage --issue <number>` fetches the issue, classifies, matches
  specs, and prints structured output (JSON + human).
- [ ] `canon triage --issue <number> --apply` also applies labels and posts
  comment (requires GitHub token).
- [ ] `canon triage --issue <number> --create-spec` additionally creates a spec
  PR when classified as feature-request with no match.
- [ ] `--dry-run` mode prints what would happen without side effects.
- [ ] Respects `CANON.yaml` triage config when present.
- [ ] Unit tests with fixture issues cover each classification category.

### 3.11 OSS Repo Triage Workflow
<!-- canon:system:3.11 status:todo -->

<!-- canon:ticket:github:700 url:https://github.com/canonhq/canon-private/issues/700 -->
Enable the issue-triage action on the `canonhq/canon` OSS repo itself.

#### Acceptance Criteria

- [ ] `.github/workflows/issue-triage.yml` exists in the OSS repo, triggered on
  `issues: [opened]`.
- [ ] Uses `canonhq/canon/actions/issue-triage@v1` with `CANON_TOKEN` secret.
- [ ] `auto-create: false` (suggest-only mode for OSS — humans approve spec PRs).
- [ ] Serves as the reference implementation for the triage action.

## 4. Technical Design

<!-- canon:system:4 status:draft -->

### 4.1 Triage Agent Architecture

```
GitHub Issue (opened)
    │
    ▼
canon triage CLI command
    │
    ├─→ Fetch issue (title, body, labels, author)
    │
    ├─→ Load all spec files (parse titles, sections, ACs)
    │
    ├─→ Claude classification prompt:
    │     System: "You are a triage agent for Canon, a documentation platform..."
    │     User: {issue_title, issue_body, spec_summaries[]}
    │     Output: {classification, confidence, related_specs[], reasoning}
    │
    ├─→ Apply results:
    │     ├─ Label issue
    │     ├─ Post comment with analysis
    │     └─ (optional) Create spec PR via spec_generator
    │
    └─→ Return structured output for action consumption
```

### 4.2 Classification Prompt Design

The agent receives:
- Issue title and body (truncated to 4K tokens)
- A summary of each spec: title, status, section headings, first 3 ACs
- Repo context from CANON.yaml (project description, team names)

Output schema (enforced via structured output):
```json
{
  "classification": "feature-request|bug-report|question|duplicate|support",
  "confidence": 0.85,
  "reasoning": "This describes a new capability not covered by existing specs...",
  "related_specs": [
    {"path": "docs/specs/foo.md", "relevance": 0.9, "section": "3.2"},
    {"path": "docs/specs/bar.md", "relevance": 0.6, "section": null}
  ],
  "suggested_labels": ["canon:feature-request", "priority:medium"],
  "duplicate_of": null
}
```

### 4.3 Spec Generation from Issue

When auto-create is enabled and no spec matches:
1. Extract structured requirements from issue body via Claude
2. Call `spec_generator.generate_spec()` with extracted description
3. Post-process: set `status: draft`, add ticket link, set owner to issue author
4. Create branch `spec/issue-<number>-<slug>`, commit, open PR
5. Comment on issue with PR link

### 4.4 Extension Packaging

```
extensions/issue-triage/
├── canon-extension.yml       # Manifest
├── skills/
│   └── issue-triage/
│       └── SKILL.md          # Triage prompt instructions
├── src/
│   └── issue_triage/
│       ├── __init__.py
│       ├── classifier.py     # Claude classification logic
│       ├── matcher.py        # Spec matching
│       ├── responder.py      # GitHub comment/label/PR creation
│       └── tools.py          # MCP tool handlers
└── tests/
    ├── test_classifier.py
    ├── test_matcher.py
    └── fixtures/
        ├── issue_feature.json
        ├── issue_bug.json
        └── issue_question.json
```

### 4.5 Dogfooding Workflow Layout

**canon-private:**
```
.github/workflows/
├── ci.yml                    # Existing (unchanged)
├── deploy.yml                # Existing (unchanged)
├── publish.yml               # Add release-notes job
├── canon-pr-checks.yml       # NEW: uses pr-checks.yml@v1
└── canon-weekly-audit.yml    # NEW: uses weekly-audit.yml@v1
```

**canonhq/canon (OSS):**
```
.github/workflows/
├── canon-pr-checks.yml       # NEW: reference implementation
├── canon-stale-specs.yml     # NEW: weekly stale check
└── issue-triage.yml          # NEW: triage on issue open
```

## 5. Rollout Plan

<!-- canon:system:5 status:draft -->

### Phase 1 — Dogfooding (no new code, just wiring)

1. Add `canon-pr-checks.yml` to canon-private (§3.1)
2. Add `canon-weekly-audit.yml` to canon-private (§3.2)
3. Add release-notes to publish workflow (§3.3)
4. Add `canon-pr-checks.yml` to OSS repo (§3.4)
5. Add `canon-stale-specs.yml` to OSS repo (§3.5)

**Validation:** Run manually, verify outputs, then enable as required checks.

### Phase 2 — Issue Triage Extension

6. Build extension core logic (§3.6)
7. Build GitHub integration (§3.7)
8. Add configuration support (§3.8)
9. Build CLI command (§3.10)

**Validation:** Test against fixture issues, run manually on real OSS issues.

### Phase 3 — Issue Triage Action & Deployment

10. Build composite action (§3.9)
11. Enable on OSS repo (§3.11)

**Validation:** Open test issues, verify triage results, iterate on prompts.

## 6. Open Questions

<!-- canon:system:6 status:draft -->

- ~~**Token cost:**~~ **Resolved**: Backend-routed (CANON_TOKEN) by default,
  with `anthropic-api-key` input as BYOK fallback for public-repo consumers
  who want to self-host without a Canon backend.
- ~~**Auto-create default:**~~ **Resolved**: `true` for canon-private (internal),
  `false` for OSS repo (suggest-only, humans approve spec PRs).
- **Duplicate detection:** Should triage check for duplicate issues (comparing
  against open issues) or only match against specs? V1: specs only, track
  duplicate detection as a follow-up.
- **Rate limiting:** If a repo gets 50 issues in a day, should triage batch or
  process individually? V1: individual, with a configurable cooldown.
