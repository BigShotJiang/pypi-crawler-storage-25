---
title: "Settings: Documentation References & Contextual Help"
status: planned
owner: ng
team: canon
ticket_project: canonhq/canon-private
review_status: draft
tags: [settings, docs, ux, frontend, docs-site]
depends_on: []
created: "2026-05-13"
updated: "2026-05-13"
---

# Settings: Documentation References & Contextual Help

Add contextual help links, section descriptions, and info tooltips across all
settings tabs, linking to the existing docs site at `canonhq.co/docs`. Also
fill documentation gaps so the links point to accurate, complete content.

## 1. Background

<!-- canon:system:1 status:done -->

The settings UI has grown to five tabs (Integrations, API Keys, Billing, AI,
Sync) with the Sync tab alone exposing status mappings, field mappings,
hierarchy rules, routing rules, and presets. Despite this complexity, the UI
provides:

- **Zero documentation links** — no tab links to `canonhq.co/docs`
- **Minimal help text** — one-liner descriptions on some cards, nothing on
  complex editors
- **No tooltips or info icons** — users encountering the Sync editor for the
  first time have no in-context guidance

Meanwhile, the docs site has rich, relevant content that could be linked:
`/guides/ticket-sync`, `/reference/config`, `/guides/github-app`,
`/getting-started/configuration`, etc.

Additionally, several documentation gaps exist:

- **`triage` config section** — 7 fields implemented in code, completely
  missing from `reference/config.md`
- **Phantom `sync` section** — documented in `config.md` but does not exist
  in the parser (`src/canon/config/parse.py`)
- **`ticket_mapping` advanced features** — `field_map`, `templates`,
  `dedup_enabled`, `shadow_targets`, `auth_profiles`, `reverse` status maps,
  `fallback` state, `default_type` hierarchy — all undocumented

## 2. Frontend — Docs Links & Contextual Help

<!-- canon:system:2 status:done -->

Add documentation references and contextual help to all five settings tabs.
Introduce a reusable `HelpLink` component and consistent section description
pattern.

### AC 2.1 — HelpLink component

<!-- canon:ac:2.1 status:draft -->

Create a reusable `HelpLink.vue` component that renders a "Learn more →" link
styled consistently across all settings tabs. Props: `href` (required), `text`
(optional, defaults to "Learn more"). Opens in a new tab. Uses muted text
styling with hover underline.

### AC 2.2 — InfoTooltip component

<!-- canon:ac:2.2 status:draft -->

Create a reusable `InfoTooltip.vue` component that renders an ⓘ icon with a
hover tooltip. Props: `text` (required). Uses the existing tooltip primitive
if available, otherwise a simple title-attribute fallback. Used for inline
field-level help on complex editors.

### AC 2.3 — Integrations tab help

<!-- canon:ac:2.3 status:draft -->

Add to the Integrations tab (`SettingsIntegrationsTab.vue`):

- **Section header description**: "Connect Canon to your version control,
  ticketing, and notification systems."
- **GitHub section**: HelpLink → `/guides/github-app`
- **Jira/Linear/GitHub Issues section header**: HelpLink →
  `/guides/ticket-sync`
- **Slack section**: Brief note about env var configuration with HelpLink →
  `/getting-started/configuration`

### AC 2.4 — API Keys tab help

<!-- canon:ac:2.4 status:draft -->

Add to the API Keys tab (`SettingsApiKeysTab.vue`):

- **Section header description**: Updated text explaining API keys are used by
  the CLI and CI integrations.
- **HelpLink** → `/reference/cli` for CLI usage
- **HelpLink** → `/reference/api` for API reference

### AC 2.5 — Billing tab help

<!-- canon:ac:2.5 status:draft -->

Add to the Billing tab (`SettingsBillingTab.vue`):

- **AI Operations section**: InfoTooltip on "AI Ops" explaining what counts
  as an operation (PR analysis, realization checks, etc.)
- **Plan comparison**: HelpLink → pricing page (already partially present)

### AC 2.6 — AI tab help

<!-- canon:ac:2.6 status:draft -->

Add to the AI tab (`SettingsAiTab.vue`):

- **Section header description**: "Configure AI model access for Canon's
  agent features. Pro plans include AI operations; Starter plans require a
  BYOK API key."
- **BYOK section**: InfoTooltip explaining when BYOK is needed vs. included
  ops
- **HelpLink** → `/getting-started/configuration`

### AC 2.7 — Sync tab help (top-level)

<!-- canon:ac:2.7 status:draft -->

Add to the Sync tab (`SettingsSyncTab.vue`):

- **Section header description**: "Configure how Canon syncs spec sections to
  tickets in your issue tracker. Each repository can have its own mapping
  configuration stored in CANON.yaml."
- **Top-level HelpLink** → `/guides/ticket-sync`
- **"No repos" warning**: Add HelpLink → `/guides/github-app` alongside
  existing text

### AC 2.8 — Sync sub-editor help

<!-- canon:ac:2.8 status:draft -->

Add contextual help to each Sync sub-editor:

- **Status Mapping** (`StatusMapEditor.vue`): Description "Map spec section
  states to ticket statuses in your issue tracker." + InfoTooltip on
  "reverse" explaining reverse mapping. HelpLink →
  `/reference/config#status-mapping`
- **Field Mapping** (`FieldMapEditor.vue`): Description "Map spec metadata to
  ticket fields." + InfoTooltip on custom fields. HelpLink →
  `/reference/config#field-mapping`
- **Hierarchy** (`HierarchyEditor.vue`): Description "Control how spec nesting
  maps to ticket types and parent-child relationships." HelpLink →
  `/reference/config#hierarchy`
- **Routing Rules** (`RoutingRulesEditor.vue`): Description "Route tickets to
  different projects or boards based on spec metadata." + InfoTooltip on
  shadow targets. HelpLink → `/reference/config#routing`
- **Presets**: InfoTooltip explaining that presets replace current config.
  HelpLink → `/guides/ticket-sync#presets`

## 3. Docs Site — Fill Documentation Gaps

<!-- canon:system:3 status:in_progress -->

<!-- canon:ticket:github:711 url:https://github.com/canonhq/canon-private/issues/711 -->
Update `docs-site/reference/config.md` and `docs-site/guides/ticket-sync.md`
to cover all implemented configuration options accurately.

### AC 3.1 — Document `triage` section

<!-- canon:ac:3.1 status:draft -->

Add `triage` section to `reference/config.md` documenting all 7 fields from
`TriageConfig`: `enabled`, `auto_create_specs`, `classify_labels`,
`ignore_labels`, `ignore_authors`, `spec_template`, `confidence_threshold`.
Include descriptions, types, and defaults matching `parse.py`.

### AC 3.2 — Remove phantom `sync` section

<!-- canon:ac:3.2 status:draft -->

Remove the `sync` section from `reference/config.md` that documents
`sync.system`, `sync.project_key`, `sync.create_tickets`,
`sync.reverse_sync`. These fields do not exist in the parser. If the
documented behavior maps to real top-level fields (`ticket_system`,
`project_key`, `specs.auto_tickets`, `specs.lifecycle_sync`), add a note
redirecting users to those fields.

### AC 3.3 — Document `ticket_mapping` advanced features

<!-- canon:ac:3.3 status:draft -->

Add documentation for the following `ticket_mapping` features currently
missing from `reference/config.md`:

- `auth_profiles` — Named credential sets with `system`, `auth_method`,
  `env_prefix`
- `ticket_systems[].field_map` — Standard and custom field mappings with
  source validation and dotpath syntax
- `ticket_systems[].templates` — Mustache-style templates for ticket
  `summary` and `description`
- `ticket_systems[].dedup_enabled` — Dedup before creating tickets
  (default: `true`)
- `ticket_systems[].host_override` — Override host for a system connection
- `ticket_systems[].auth_profile` — Reference to a named auth profile
- `routing[].shadow_targets` — Read-only shadow sync to additional systems
- `status_map.reverse` — Reverse mapping (ticket status → spec state)
- `status_map.fallback` — Fallback spec state for unmapped statuses
  (default: `"draft"`)
- `hierarchy.default_type` — Issue type when depth not in `depth_to_type`
  (default: `"Task"`)

### AC 3.4 — Add anchor IDs to config reference sections

<!-- canon:ac:3.4 status:draft -->

Ensure `reference/config.md` has stable anchor IDs for each major section so
that settings UI links can deep-link:

- `#status-mapping`
- `#field-mapping`
- `#hierarchy`
- `#routing`
- `#triage`
- `#ticket-systems`
- `#auth-profiles`
- `#templates`

VitePress auto-generates anchors from headings; verify the generated anchors
match what the UI links expect, or add explicit `{#anchor}` overrides.

### AC 3.5 — Update ticket-sync guide

<!-- canon:ac:3.5 status:draft -->

Update `docs-site/guides/ticket-sync.md` to reference the advanced features
documented in AC 3.3, add a presets section (or link to config reference),
and ensure the guide covers the end-to-end flow of configuring sync from the
settings UI.
