---
title: "CLI UX Enhancements"
status: draft
owner: ng
team: canon
ticket_project: canonhq/canon
created: 2026-05-15
updated: 2026-05-15
tags: [cli, ux, dx, rich, output]
---

# CLI UX Enhancements

## 1. Background

<!-- canon:system:1 status:draft -->

Canon's CLI has grown to 27+ subcommands spanning authentication, spec
management, ticket sync, validation, extensions, and diagnostics. The feature
surface is comprehensive, but the user experience hasn't kept pace:

- **No visual formatting** — all output is raw `print()` with hand-built column
  alignment. No colors, no spinners, no progress bars. Competing CLIs (gh, npm,
  cargo, uv) all use rich terminal formatting.
- **Flat command hierarchy** — all 27+ commands are listed at the top level with
  no grouping. Users must read the entire list to find what they need.
- **Inconsistent error output** — some errors go to stdout, some to stderr, with
  no convention. Error messages are plain text with no visual distinction.
- **No progress feedback** — long-running operations like `canon audit` (Claude
  API calls) and `canon sync` (ticket creation) run silently for 30+ seconds.
- **Duplicated helpers** — prompt functions are copy-pasted across modules.
- **Brittle dispatch** — 78-line `if/elif` chain in `__init__.py` for command
  routing. Adding a command requires touching two separate code blocks.
- **Missing commands** — web UI has search, health scores, and dashboard views
  with no CLI equivalents.

### Goals

- Modernize CLI output with colors, tables, spinners, and progress indicators
- Organize commands into logical groups for better discoverability
- Add missing high-value commands (search, dashboard)
- Centralize shared output patterns and error handling
- Add global flags for verbosity and color control
- Maintain full backward compatibility — no breaking changes to existing
  command syntax, flags, or exit codes

### Non-Goals

- Migrating from argparse to click/typer (too disruptive for this iteration)
- Adding shell completion (argparse makes this hard; save for a future
  framework migration)
- Rewriting the guided onboarding wizard (covered by
  `cli-integrations-onboarding.md` sections 3.1-3.7)
- Web UI changes
- New ticket system adapters

### Relationship to Existing Specs

| Spec | Relationship |
|------|-------------|
| `cli-integrations-onboarding.md` | Independent. This spec improves UX of existing commands; that spec adds wizard steps. The wizard will benefit from the output module created here. |
| `setup-ux-improvements.md` | Independent. That spec's remaining items (next-steps bug, --force, naming drift, README) are orthogonal to UX modernization. |
| `enterprise-adoption-enablement.md` | Complementary. That spec mentions `canon status` hierarchy display — the rich table work here directly enables it. |

### Dependencies

- `rich` Python library (MIT license, widely used, already a transitive dep of
  many Python tools)

---

## 2. Shared Output Module

<!-- canon:system:2 status:todo -->

<!-- canon:ticket:github:742 url:https://github.com/canonhq/canon-private/issues/742 -->
Create `src/canon/cli/_output.py` — a thin wrapper around `rich` that all CLI
commands import for consistent formatting. This module centralizes all terminal
output patterns so individual commands don't need to know about `rich` internals.

### 2.1 Console & Theme

<!-- canon:system:2.1 status:todo -->

<!-- canon:ticket:github:743 url:https://github.com/canonhq/canon-private/issues/743 -->
#### Acceptance Criteria

- [ ] Module exports a singleton `console` (rich.Console) configured with Canon's color theme
- [ ] Theme defines semantic styles: `success` (green), `error` (red), `warning` (yellow), `info` (blue), `muted` (dim), `heading` (bold), `key` (cyan)
- [ ] `console` respects `NO_COLOR` env var (rich handles this natively) and a `--no-color` flag
- [ ] `console` detects non-TTY (piped output) and auto-disables formatting
- [ ] Provides `print_error(msg)` that prints styled error to stderr
- [ ] Provides `print_warning(msg)` that prints styled warning to stderr
- [ ] Provides `print_success(msg)` that prints styled success to stdout
- [ ] All three helpers accept optional `hint` kwarg for a follow-up suggestion line

### 2.2 Table Helper

<!-- canon:system:2.2 status:todo -->

<!-- canon:ticket:github:744 url:https://github.com/canonhq/canon-private/issues/744 -->
#### Acceptance Criteria

- [ ] Provides `make_table(title, columns, rows)` returning a `rich.table.Table` with Canon styling (box=SIMPLE, no_wrap on first column, muted header style)
- [ ] Columns accept a dict with `name`, `style`, `justify`, `min_width` keys
- [ ] Rows are lists of strings or `Text` objects
- [ ] Helper auto-adapts to terminal width (rich handles this)
- [ ] JSON mode bypass: when `--json` is active, table helpers are not called (commands check the flag before formatting)

### 2.3 Progress & Spinners

<!-- canon:system:2.3 status:todo -->

<!-- canon:ticket:github:745 url:https://github.com/canonhq/canon-private/issues/745 -->
#### Acceptance Criteria

- [ ] Provides `spinner(message)` context manager that shows a rich spinner during long operations
- [ ] Spinner writes to stderr so stdout remains clean for piped output
- [ ] Provides `progress_bar(total, description)` context manager for counted operations (e.g., syncing N specs)
- [ ] Progress bar updates via `bar.advance()` calls from the command
- [ ] Both spinner and progress bar gracefully degrade to plain text when `--no-color` or non-TTY

### 2.4 Status Badges

<!-- canon:system:2.4 status:todo -->

<!-- canon:ticket:github:655 url:https://github.com/canonhq/canon-private/issues/655 -->
#### Acceptance Criteria

- [ ] Provides `status_badge(status)` returning styled text: `done` → green, `in_progress` → yellow, `todo` → dim, `blocked` → red, `draft` → dim italic
- [ ] Provides `result_badge(result)` for doctor/verify results: `PASS` → green bold, `WARN` → yellow bold, `FAIL` → red bold, `SKIP` → dim
- [ ] Coverage percentage styled as: >=80% green, 50-79% yellow, <50% red
- [ ] All badge functions return `rich.text.Text` objects usable in tables and inline output

---

## 3. Global Flags & Error Handling

<!-- canon:system:3 status:todo -->

<!-- canon:ticket:github:746 url:https://github.com/canonhq/canon-private/issues/746 -->
Add global flags to the top-level parser and centralize error handling.

### 3.1 Global Flags

<!-- canon:system:3.1 status:todo -->

<!-- canon:ticket:github:747 url:https://github.com/canonhq/canon-private/issues/747 -->
#### Acceptance Criteria

- [ ] `--no-color` flag disables all rich formatting (sets `NO_COLOR=1` and configures console)
- [ ] `--quiet` / `-q` flag suppresses all non-essential output (only errors and requested data)
- [ ] `--verbose` / `-v` flag enables debug-level logging output
- [ ] `--json` flag (already exists per-command) is promoted to a global flag and passed through `args` to all commands
- [ ] Global flags are parsed before subcommand dispatch and stored on `args` namespace
- [ ] Existing per-command `--json` flags continue to work (backward compatible)

### 3.2 Centralized Error Handling

<!-- canon:system:3.2 status:todo -->

<!-- canon:ticket:github:748 url:https://github.com/canonhq/canon-private/issues/748 -->
#### Acceptance Criteria

- [ ] `main()` wraps dispatch in a try/except that catches `CanonCLIError` (new base exception) and prints formatted error to stderr
- [ ] `CanonCLIError` carries `message`, `hint` (optional suggestion), and `exit_code`
- [ ] Subclasses: `AuthRequiredError`, `ConfigError`, `SpecNotFoundError`, `NetworkError`
- [ ] Existing `sys.exit(1)` calls in commands are migrated to raise `CanonCLIError` instead (incremental — start with the most-used commands)
- [ ] Unhandled exceptions print a "This is a bug" message with traceback file location and a prompt to report
- [ ] Exit codes unchanged for all existing commands (backward compatible)

---

## 4. Command Group Organization

<!-- canon:system:4 status:todo -->

<!-- canon:ticket:github:749 url:https://github.com/canonhq/canon-private/issues/749 -->
Organize the flat command list into logical groups in help output. No changes
to actual command invocation — `canon sync` still works, it's just displayed
under a group header in `canon --help`.

### 4.1 Help Output Grouping

<!-- canon:system:4.1 status:todo -->

<!-- canon:ticket:github:750 url:https://github.com/canonhq/canon-private/issues/750 -->
Group commands in `canon --help` under these categories:

```
Canon — Spec-driven development platform

Getting Started:
  setup          Guided onboarding wizard
  login          Authenticate with Canon
  logout         Clear credentials
  doctor         Diagnose configuration issues

Spec Workflow:
  new            Create a new spec from template
  status         Show spec coverage dashboard
  tasks          List actionable work items
  plan           Generate a task plan from a spec
  start          Mark a spec section as in-progress
  done           Mark a spec section as done

Validation:
  lint           Structural validation (no network)
  verify         Check ACs against codebase
  audit          AI-powered spec status audit

Sync:
  sync           Bidirectional ticket sync
  dedup          Find and resolve duplicate tickets
  integrations   Manage ticket system connections

Reporting:
  stale          Find specs with outdated realizations
  export         Compliance audit trail (JSON/CSV)
  release-notes  Spec-driven release notes

Tools:
  search         Search specs by keyword
  dashboard      Org-level overview
  triage         AI-powered issue classification
  evidence       Session evidence pipeline
  extension      Manage extensions
  auth           Show auth status
  db             Database operations
  ide-config     Emit IDE config as JSON
```

#### Acceptance Criteria

- [ ] `canon --help` displays commands grouped under category headers as shown above
- [ ] Grouping implemented via custom `HelpFormatter` subclass — no argparse migration required
- [ ] Each group header is styled as bold when color is enabled
- [ ] Commands within each group are alphabetically sorted
- [ ] `canon <command> --help` continues to work unchanged
- [ ] Aliases (`init` for `setup`, `int` for `integrations`) are not shown in the main listing but continue to work

### 4.2 Registry-Based Dispatch

<!-- canon:system:4.2 status:todo -->

<!-- canon:ticket:github:751 url:https://github.com/canonhq/canon-private/issues/751 -->
Replace the 78-line `if/elif` chain with a command registry.

#### Acceptance Criteria

- [ ] Each command module's `register()` function returns a dict: `{"name": str, "aliases": list, "handler": callable, "group": str}`
- [ ] `__init__.py` collects all registrations into a `COMMANDS` dict keyed by name
- [ ] Dispatch is a single dict lookup: `COMMANDS[args.command]["handler"](args)` with alias resolution
- [ ] Adding a new command requires only: (1) create the module with `register()`, (2) add it to the import list
- [ ] All existing command behavior unchanged (no user-facing difference)

---

## 5. Colorized Command Output

<!-- canon:system:5 status:todo -->

<!-- canon:ticket:github:752 url:https://github.com/canonhq/canon-private/issues/752 -->
Migrate the highest-impact commands to use the shared output module. Each
command retains its exact same information content — only the presentation
changes.

### 5.1 `canon doctor` — Rich Diagnostics

<!-- canon:system:5.1 status:todo -->

<!-- canon:ticket:github:753 url:https://github.com/canonhq/canon-private/issues/753 -->
#### Acceptance Criteria

- [ ] Check results use colored badges: `PASS` (green), `WARN` (yellow), `FAIL` (red), `SKIP` (dim)
- [ ] Category headers (Config, Auth, Integrations, MCP) are bold with separator lines
- [ ] Failed checks show the error in red with a hint line in dim text
- [ ] `--fix` actions show a spinner while running
- [ ] Summary line at bottom: "N passed, N warnings, N failed" with appropriate colors
- [ ] `--json` output unchanged

### 5.2 `canon status` — Coverage Dashboard

<!-- canon:system:5.2 status:todo -->

<!-- canon:ticket:github:754 url:https://github.com/canonhq/canon-private/issues/754 -->
#### Acceptance Criteria

- [ ] Aggregate view uses a rich table with colored coverage percentages
- [ ] Per-spec detail shows sections with status badges (done=green, in_progress=yellow, todo=dim)
- [ ] Coverage bar rendered as a colored progress bar (green fill, dim background)
- [ ] Spec titles are bold, section numbers are muted
- [ ] `--json` output unchanged

### 5.3 `canon tasks` — Work Item List

<!-- canon:system:5.3 status:todo -->

<!-- canon:ticket:github:755 url:https://github.com/canonhq/canon-private/issues/755 -->
#### Acceptance Criteria

- [ ] Tasks displayed in a rich table with status badges
- [ ] Ticket links rendered as clickable URLs (terminals that support OSC 8)
- [ ] Spec name column uses muted style
- [ ] AC counts shown as "N/M" with color based on completion ratio
- [ ] Empty state shows a helpful message instead of blank output
- [ ] `--json` output unchanged

### 5.4 `canon sync` — Progress Feedback

<!-- canon:system:5.4 status:todo -->

<!-- canon:ticket:github:756 url:https://github.com/canonhq/canon-private/issues/756 -->
#### Acceptance Criteria

- [ ] Shows a progress bar: "Syncing specs [3/12]" during forward sync
- [ ] Each spec prints a one-line summary: spec name + created/updated/skipped counts
- [ ] Errors are printed in red with the spec name as context
- [ ] `--dry-run` output clearly labeled with a "DRY RUN" header badge
- [ ] Final summary line: "Created N, updated N, skipped N, errors N"
- [ ] `--json` output unchanged

### 5.5 `canon audit` — AI Audit Progress

<!-- canon:system:5.5 status:todo -->

<!-- canon:ticket:github:757 url:https://github.com/canonhq/canon-private/issues/757 -->
#### Acceptance Criteria

- [ ] Shows a spinner per spec during Claude API calls: "Auditing feature-auth.md..."
- [ ] AC evaluations use colored symbols: checkmark (green), X (red), ~ (yellow) instead of `[+]`/`[-]`/`[~]`
- [ ] Status transitions shown as "todo → done" with colored arrow
- [ ] Summary table of all status changes at the end
- [ ] `--json` output unchanged

### 5.6 `canon lint` — Validation Output

<!-- canon:system:5.6 status:todo -->

<!-- canon:ticket:github:758 url:https://github.com/canonhq/canon-private/issues/758 -->
#### Acceptance Criteria

- [ ] Errors prefixed with red "error:" and warnings with yellow "warning:"
- [ ] File paths rendered in bold
- [ ] Line/section references in muted style
- [ ] Summary: "N errors, N warnings in M files" with appropriate colors
- [ ] Clean pass shows a green checkmark: "All specs valid"
- [ ] `--json` output unchanged

### 5.7 `canon verify` — Verification Output

<!-- canon:system:5.7 status:todo -->

<!-- canon:ticket:github:759 url:https://github.com/canonhq/canon-private/issues/759 -->
#### Acceptance Criteria

- [ ] AC results use colored symbols: checkmark (green) for checked, `?` (yellow) for likely, dim dash for not started
- [ ] Spec headers are bold
- [ ] `--gate` failure message is red with clear explanation
- [ ] Summary line: "N verified, N likely, N not started" with colors
- [ ] `--json` output unchanged

---

## 6. New Commands

<!-- canon:system:6 status:todo -->

<!-- canon:ticket:github:760 url:https://github.com/canonhq/canon-private/issues/760 -->
### 6.1 `canon search`

<!-- canon:system:6.1 status:todo -->

<!-- canon:ticket:github:761 url:https://github.com/canonhq/canon-private/issues/761 -->
Local full-text search across spec files. Lightweight grep-based implementation
that doesn't require a running server.

#### Usage

```
canon search "authentication flow"
canon search "AC" --status todo
canon search "billing" --spec feature-billing.md
```

#### Acceptance Criteria

- [ ] Searches spec file content (title, body, ACs) for the given query terms
- [ ] Results show: spec title, matching section, and a snippet with highlighted matches
- [ ] `--status <status>` filters to sections with the given status
- [ ] `--spec <filename>` limits search to a specific spec
- [ ] Results sorted by relevance (number of term matches)
- [ ] `--json` flag for machine-readable output
- [ ] Exits 0 on results found, 1 on no results

### 6.2 `canon dashboard`

<!-- canon:system:6.2 status:todo -->

<!-- canon:ticket:github:762 url:https://github.com/canonhq/canon-private/issues/762 -->
A single-screen overview combining the most useful information from `status`,
`tasks`, and `stale` into one view.

#### Usage

```
canon dashboard
canon dashboard --json
```

#### Acceptance Criteria

- [ ] Top section: aggregate coverage metrics (total specs, sections, ACs, overall coverage %) with a colored coverage bar
- [ ] Middle section: up to 10 in-progress or todo tasks (same data as `canon tasks --status in_progress,todo`)
- [ ] Bottom section: up to 5 stale specs (same data as `canon stale` with default thresholds)
- [ ] Each section has a header and is visually separated
- [ ] If a section has more items than shown, prints "N more — run `canon <command>` to see all"
- [ ] `--json` flag outputs all three sections as a single JSON object
- [ ] Runs entirely local — no network calls

---

## 7. Shared Prompt Helpers

<!-- canon:system:7 status:todo -->

<!-- canon:ticket:github:763 url:https://github.com/canonhq/canon-private/issues/763 -->
Deduplicate the interactive prompt functions currently copy-pasted across
`wizard.py` and `integrations_cmd.py`.

### 7.1 Prompt Consolidation

<!-- canon:system:7.1 status:todo -->

<!-- canon:ticket:github:764 url:https://github.com/canonhq/canon-private/issues/764 -->
#### Acceptance Criteria

- [ ] Move `_prompt()`, `_prompt_confirm()`, and `_prompt_choice()` into `_output.py` (or a new `_prompts.py`)
- [ ] All callers (`wizard.py`, `integrations_cmd.py`, `setup_cmd.py`, `login.py`) import from the shared location
- [ ] Prompt styling updated: prompt text in bold, default values in dim brackets, choice numbers in cyan
- [ ] `--quiet` mode makes prompts non-interactive: use defaults or fail with error if no default
- [ ] Behavior unchanged for all interactive flows

---

## 8. Rollout Plan

<!-- canon:system:8 status:todo -->

<!-- canon:ticket:github:765 url:https://github.com/canonhq/canon-private/issues/765 -->
### Phase 1: Foundation (sections 2, 3, 7)
- Add `rich` dependency
- Create `_output.py` with console, theme, table, spinner, badge helpers
- Add global flags and error handling
- Consolidate prompt helpers
- **No visible output changes yet** — this phase is pure infrastructure

### Phase 2: High-Impact Commands (sections 5.1-5.3)
- Colorize `doctor`, `status`, `tasks` — the three most-used commands
- These serve as the template for all other command migrations

### Phase 3: Remaining Commands (sections 5.4-5.7)
- Colorize `sync`, `audit`, `lint`, `verify`
- Add progress bars and spinners for long operations

### Phase 4: Organization & New Commands (sections 4, 6)
- Implement help grouping and registry dispatch
- Add `canon search` and `canon dashboard`

#### Rollout Acceptance Criteria

- [ ] All existing tests pass after each phase
- [ ] `--json` output unchanged for every command
- [ ] Exit codes unchanged for every command
- [ ] `--no-color` produces output visually identical to pre-enhancement output
- [ ] No new required dependencies beyond `rich`
