---
title: "Broken Ticket Reference UI"
type: spec
status: draft
owner: ng
team: canon
review_status: draft
ticket_project: canonhq/canon-private
tags: [sync, github, dashboard, ui, rate-limit, tickets, ticket-status]
depends_on: []
created: 2026-05-04
updated: 2026-05-04
---

# Broken Ticket Reference UI

Track persistently-broken ticket references in their own table, surface them in
the dashboard and inline on the spec view, and stop the `canon-sync` cron from
re-checking refs we already know are dead.

Design history and full decision log:
[`docs/superpowers/specs/2026-05-04-broken-ticket-refs-ui-design.md`](../superpowers/specs/2026-05-04-broken-ticket-refs-ui-design.md).

## 1. Background

<!-- canon:system:1 status:done -->

<!-- canon:ticket:github:566 url:https://github.com/canonhq/canon-private/issues/566 -->
`reverse_sync` (the `canon-sync` cron, every 15 min) calls
`adapter.get_ticket_status(ticket_id)` for every spec section that has a
`ticket_link`. When the ticket no longer exists — deleted GitHub issue, moved
Jira ticket, revoked permission — the adapter raises an exception and the
section's error is appended to the cron's per-run total.

Today the cron has no memory of which refs are persistently broken, so on
each run it re-asks the ticket system about every dead ref. With
`sys.exit(1)` on `total_errors > 0` and `restartPolicy: OnFailure +
backoffLimit: 6`, a single cron run can replay the full ~300-call sync up
to 7 times — burning ~2,100 GitHub calls per cron run. Users have no surface
to discover or clean up the bad refs.

PR #663 capped the worst of the rate-limit damage by routing per-spec
content reads through the Postgres content cache, but the per-section
`get_ticket_status` calls still fan out on every cron cycle. This spec is
the long-term fix.

### Design Decisions

| #  | Question                                  | Decision                                                                  |
|----|-------------------------------------------|---------------------------------------------------------------------------|
| 1  | What counts as "broken"?                  | 404 + 401 + 403 from the ticket system                                    |
| 2  | When do we flip the broken flag?          | After 3 consecutive failures (≈ 30–45 min at the */15 cadence)            |
| 3  | Per-section row or per-ticket row?        | Per-ticket sidecar table; multiple sections share state and the cron deduplicates calls |
| 4  | Where does it surface?                    | Inline badge on `SpecView` + dashboard panel on `DashboardView` (skip the per-spec banner) |
| 5  | What does the cron do once a ref is broken? | Skip every cycle except a daily 24 h re-check that auto-clears on success |
| 6  | What can the user do?                     | Flag + dismiss + auto-PR-to-remove                                        |

## 2. Engine & Storage

<!-- canon:system:2 status:todo -->

<!-- canon:ticket:github:664 url:https://github.com/canonhq/canon-private/issues/664 -->
The first independently-shippable slice. Eliminates the rate-limit waste
even before the UI lands by writing rows on failure and skipping known-broken
refs in the cron.

### Schema

New migration `0015_ticket_ref_status.py`:

```sql
CREATE TABLE ticket_ref_status (
    id              BIGSERIAL PRIMARY KEY,
    installation_id BIGINT NOT NULL,
    system          TEXT   NOT NULL,        -- 'jira' | 'linear' | 'github'

    -- Fully-qualified ticket reference. Format depends on system:
    --   github : 'org/repo#123'
    --   jira   : 'PROJ-123'
    --   linear : 'TEAM-123'
    -- Always assembled via canon.sync.ticket_ref.qualify(system, repo,
    -- ticket_id) so callers don't have to remember which systems need
    -- the repo prefix.
    ticket_ref      TEXT   NOT NULL,

    status               TEXT   NOT NULL DEFAULT 'ok',  -- 'ok' | 'broken' | 'dismissed'
    consecutive_failures INT   NOT NULL DEFAULT 0,
    last_error_kind      TEXT,            -- 'not_found' | 'forbidden' | 'unauthorized'
    last_error_message   TEXT,            -- truncated, for the dashboard tooltip

    first_failure_at TIMESTAMPTZ,         -- set on the first failure that began a 'broken' streak; cleared by mark_ok
    last_check_at    TIMESTAMPTZ,         -- bumped on every adapter call (success or failure)
    last_recheck_at  TIMESTAMPTZ,         -- bumped ONLY when due_for_recheck() forced a 24h re-check
    dismissed_at     TIMESTAMPTZ,
    dismissed_by     TEXT,                -- jwt.sub of the dismissing user

    UNIQUE (installation_id, system, ticket_ref)
);

CREATE INDEX ticket_ref_status_broken_idx
    ON ticket_ref_status (installation_id, status)
    WHERE status IN ('broken', 'dismissed');

CREATE INDEX ticket_ref_status_recheck_idx
    ON ticket_ref_status (status, last_recheck_at)
    WHERE status = 'broken';
```

Notes:
- `dismissed` is a status, not a separate flag — the cron skips both
  `broken` and `dismissed` rows; the UI distinguishes them so dismissed
  refs don't appear in the "needs attention" count.
- No FK to `spec_sections` / `spec_documents` — ticket-id is independent
  of which sections cite it; sections come and go via spec edits but the
  ticket's broken-ness is durable.

### Helpers

Two new modules support the engine changes:

- `canon/sync/ticket_ref.py` — `qualify(system, repo, ticket_id) -> str`
  builds the fully-qualified ticket_ref; `due_for_recheck(row) -> bool`
  returns True iff `status == 'broken'` and `last_recheck_at` is None or
  older than 24h. Dismissed rows always return False.
- `canon/sync/ticket_error.py` — `classify_error(exc) -> ErrorKind` maps
  `httpx.HTTPStatusError` 404/401/403 to `not_found` / `unauthorized` /
  `forbidden`; everything else is `transient`. `TicketAdapter` gets an
  optional `classify_exception` classmethod for system-specific exceptions
  (Linear's GraphQL `NotFoundError`, etc.).

### Engine integration

The per-section block in `reverse_sync` (currently around lines 845–888)
becomes:

```python
ticket_ref = qualify(section.ticket_link.system, repo, section.ticket_link.ticket_id)
ref_row = await ref_store.get(installation_id, section.ticket_link.system, ticket_ref)

if ref_row and ref_row.status in ("broken", "dismissed"):
    if not due_for_recheck(ref_row):
        continue  # cron skips entirely — no adapter call

try:
    ticket_status = await adapter.get_ticket_status(section.ticket_link.ticket_id)
    if ref_row and ref_row.status == "broken":
        await ref_store.mark_ok(installation_id, section.ticket_link.system, ticket_ref)
    # … existing status_changed / updates logic unchanged …
except Exception as err:
    kind = classify_error(err)
    if kind in ("not_found", "forbidden", "unauthorized"):
        await ref_store.record_failure(
            installation_id, section.ticket_link.system, ticket_ref, kind, str(err)
        )
    result.errors.append(SyncError(section_id=section.id, error=str(err)))
```

`record_failure` is upsert with `INSERT ... ON CONFLICT DO UPDATE`, increments
`consecutive_failures`, flips `status` to `'broken'` once the counter hits 3.
`mark_ok` is also upsert and resets the counter; it never touches `dismissed`
rows.

### Acceptance Criteria

- [x] Migration `0015_ticket_ref_status.py` adds the table and both indexes
<!-- canon:realized-in:PR#667 file:src/canon/db/migrations/versions/0015_ticket_ref_status.py -->
- [x] `canon/sync/ticket_ref.py` implements `qualify()` and `due_for_recheck()`
<!-- canon:realized-in:PR#667 file:src/canon/sync/ticket_ref.py -->
- [ ] `canon/sync/ticket_error.py` implements `classify_error()`
- [x] `canon/db/ticket_ref_status_store.py` implements `get`, `mark_ok`, `record_failure`, `dismiss`, `force_recheck`, `list_broken`
<!-- canon:realized-in:PR#667 file:src/canon/db/ticket_ref_status_store.py -->
- [x] `reverse_sync` skips refs whose row is `broken` or `dismissed` and not due for re-check
<!-- canon:realized-in:PR#667 file:src/canon/sync/engine.py -->
- [x] Per-section errors classified `not_found` / `forbidden` / `unauthorized` flip the row to `broken` after 3 consecutive failures
- [x] Successful re-check after 24h auto-clears `broken` (but not `dismissed`)
- [x] Store failures (DB unavailable) fail-open: log warning, fall through to the adapter call; cron must not abort
- [x] Unit tests cover `qualify`, `classify_error`, `due_for_recheck`
<!-- canon:realized-in:PR#667 file:tests/test_sync/test_ticket_ref.py -->
<!-- canon:realized-in:PR#667 file:tests/test_sync/test_ticket_error.py -->
- [x] Engine tests cover the 3-failure flip, success-clears-broken, dismissed-skip, transient-doesn't-increment, 24h-recheck paths
<!-- canon:realized-in:PR#667 file:tests/test_sync/test_engine_broken_refs.py -->

## 3. Read API & UI

<!-- canon:system:3 status:todo -->

<!-- canon:ticket:github:665 url:https://github.com/canonhq/canon-private/issues/665 -->
The second slice. Once shipped, users immediately see existing broken refs in
the dashboard and inline on each spec.

### Read endpoints

Existing endpoints, augmented:
- `GET /{org}/api/dashboard` — `OrgOverview` gains `total_broken_refs: int`
  and per-repo `broken_refs_count: int`.
- `GET /{org}/api/specs/{owner}/{repo}/{file_path}` — `SpecDetail` gains
  `broken_sections: list[BrokenRef]` (only sections in this spec).

New endpoints:
- `GET /{org}/api/broken-refs?status=broken&system=&repo=&limit=50&offset=0`
  — paginated cross-spec list for the dashboard panel.
- `GET /{org}/api/broken-refs/count` — cheap count for navbar badge polling.

`BrokenRef` Pydantic model in `web/models.py`:

```python
class BrokenRef(BaseModel):
    system: Literal["jira", "linear", "github"]
    ticket_ref: str
    spec_path: str            # repo + file_path, for navigation
    section_id: str
    section_heading: str
    error_kind: Literal["not_found", "forbidden", "unauthorized"]
    first_failure_at: datetime
    last_check_at: datetime
    dismissed: bool
    dismissed_by: str | None
```

The web routes resolve `installation_id` from the URL `{org}` via the existing
`_get_client_for_org(request, org)` helper used by every other read endpoint —
no new auth/registry plumbing required.

### Vue components

- `frontend/src/components/BrokenRefBadge.vue` — small red `BROKEN` chip
  rendered inline next to a section's ticket reference. Click toggles a
  popover with: error kind, first-failed / last-checked timestamps, and
  stacked `Remove ref (opens PR)` / `Dismiss` / `Re-check now` buttons.
  (Buttons are inert until section 4 lands.)
- `frontend/src/components/BrokenRefsPanel.vue` — dashboard panel.
  Paginated table (default 10 rows, "View all" expands), filters by
  system and status (Active / Dismissed). Click row navigates to
  `/spec/{owner}/{repo}/{file_path}#{section_id}` (uses the existing
  scroll-to-section anchor).

Edits to existing views:
- `SpecView.vue` — when `spec_detail.broken_sections` is non-empty, the
  section renderer mounts a `<BrokenRefBadge>` next to any section whose
  `section_id` matches.
- `DashboardView.vue` — `<BrokenRefsPanel>` below the repo list, guarded
  by `v-if="dashboard.total_broken_refs > 0"` so healthy orgs don't see
  an empty panel. Top-of-dashboard metric chips include a
  `⚠ N broken refs` chip when the count is non-zero.

State stays consistent with the existing pattern — no Vuex/Pinia for this
domain; each component fetches via the existing `useApi` helper; refetch
after mutation; no realtime/websockets.

### Acceptance Criteria

- [ ] `OrgOverview` and `SpecDetail` Pydantic models include the new fields
- [ ] `GET /{org}/api/broken-refs` returns paginated rows with system + repo + status filters
- [ ] `GET /{org}/api/broken-refs/count` returns a single-int response
- [ ] `BrokenRefBadge.vue` renders inline; popover toggles open/closed; the three action buttons exist (callbacks are no-ops in this section)
- [ ] `BrokenRefsPanel.vue` renders rows, filters mutate query params, paging works at the 10-row default
- [ ] `DashboardView.vue` shows the `⚠ N broken refs` chip and panel only when `total_broken_refs > 0`; the chip is a `<button>` that smooth-scrolls to the `BrokenRefsPanel` on click
- [ ] `SpecView.vue` mounts `BrokenRefBadge` only on sections with broken refs
- [ ] FastAPI route tests cover happy path + permission checks for each new endpoint
- [ ] Vitest component tests cover `BrokenRefBadge`, `BrokenRefsPanel` rendering and interaction

## 4. Mutating Actions

<!-- canon:system:4 status:todo -->

<!-- canon:ticket:github:666 url:https://github.com/canonhq/canon-private/issues/666 -->
The third slice. Wires up dismiss / re-check / remove so users can actually
clean up the surfaced refs.

### Endpoints (all gated on `Permission.SPECS_WRITE`)

```
POST /{org}/api/broken-refs/dismiss
     body: { system, ticket_ref }
       → status = 'dismissed', dismissed_by = jwt.sub, dismissed_at = now()

POST /{org}/api/broken-refs/recheck
     body: { system, ticket_ref }
       → clears last_recheck_at; next cron run forces a fresh check
       → does NOT call the adapter inline (would tie up the request);
         caller polls the dashboard for status to flip back

POST /{org}/api/specs/{owner}/{repo}/{file_path:path}/sections/{section_id}/remove-ticket-ref
       → opens a doc PR via existing client.create_doc_pr that deletes
         the `Ticket: …` line from that section
       → returns { pr_url, pr_number }
       → 409 with the existing pr_url if a PR for this section already exists
       → 410 if the section has been re-pointed since the last sync
```

### Error handling

- `dismiss` / `recheck` on a non-existent row → 404 with a clear message.
  Only the cron creates rows.
- `remove-ticket-ref` collisions: branch
  `canon-bot/remove-ref-{section_id}` already has an open PR → 409 with the
  existing pr_url; UI shows "There's already an open PR to remove this ref → {link}".
- `remove-ticket-ref` on a re-pointed section → re-parse the spec at request
  time; if the section's `ticket_link.ticket_id` no longer matches the broken
  `ticket_ref`, return 410 Gone with "this section was already updated, refresh
  the dashboard".
- `create_doc_pr` failures (GitHub 5xx, network, revoked installation) → 502.

### Vue changes

- `frontend/src/components/RemoveTicketRefModal.vue` — confirmation modal
  shown before opening the PR. Body: "This opens a PR removing line N from
  spec X. Continue?". On confirm, POST `remove-ticket-ref`; on success show
  toast with PR link; on 409 show toast with the existing PR link.
- `BrokenRefBadge.vue` and `BrokenRefsPanel.vue` action buttons wired to
  these endpoints; buttons disabled while the request is in flight.

### Acceptance Criteria

- [ ] `POST /{org}/api/broken-refs/dismiss` flips `status` to `dismissed` and stamps `dismissed_by` from the JWT
- [ ] `POST /{org}/api/broken-refs/recheck` clears `last_recheck_at` and does NOT call the adapter inline
- [ ] `POST /.../remove-ticket-ref` opens a doc PR removing the Ticket line and returns the PR URL
- [x] Collision case returns 409 with the existing PR URL
<!-- canon:realized-in:PR#675 file:src/canon/web/routes.py -->
<!-- canon:realized-in:PR#675 file:src/canon/web/services.py -->
<!-- canon:realized-in:PR#678 file:src/canon/web/routes.py -->
<!-- canon:realized-in:PR#678 file:src/canon/web/services.py -->
- [x] Re-pointed-section case returns 410
- [ ] All three endpoints require `Permission.SPECS_WRITE`
- [ ] `RemoveTicketRefModal` shows before any remove action
- [ ] `BrokenRefBadge` and `BrokenRefsPanel` action buttons trigger the right endpoint and refetch on success
- [ ] PR links open in a new tab on success; 409 conflicts (existing PR) and 410 (section already updated) are surfaced inline in the `RemoveTicketRefModal`. Both the 200 and 409 paths also auto-dismiss the matching `ticket_ref_status` row so the dashboard count drops immediately — the user has acknowledged the ref by opening or finding a remove-PR.

## 5. Testing

<!-- canon:system:5 status:in_progress -->

<!-- canon:ticket:github:537 url:https://github.com/canonhq/canon-private/issues/537 -->
Five layers, mirroring the existing test layout. Each layer gets implemented
alongside the section that introduces its target code.

- **Unit (pure):** `tests/test_sync/test_ticket_ref.py` covers `qualify` per
  system + error cases + `due_for_recheck` truth table.
  `tests/test_sync/test_ticket_error.py` covers `classify_error` per status
  code, generic exception fall-through, adapter override precedence.
- **Store (asyncpg with the existing `pgtest` fixture):**
  `tests/test_db/test_ticket_ref_status_store.py` covers round-trip
  insert/get/mark_ok/record_failure/dismiss; UNIQUE enforcement; the two
  indexes hit by the API queries (verify with EXPLAIN).
- **Engine:** `tests/test_sync/test_engine_broken_refs.py` covers the
  3-failure flip, success-clears-broken, dismissed-skip,
  transient-doesn't-increment, 24h-recheck paths.
- **Routes (FastAPI TestClient):** `tests/test_web/test_broken_refs_routes.py`
  covers happy path + permission checks + 404/409/410 cases for each new
  endpoint.
- **Frontend (Vitest):** `BrokenRefBadge.spec.ts`, `BrokenRefsPanel.spec.ts`,
  `RemoveTicketRefModal.spec.ts` cover render, interaction, and error
  handling.

Plus one integration test:
- `tests/integration/test_broken_refs_e2e.py` — starts the FastAPI app +
  Postgres + WireMock for GitHub, simulates 3 cron cycles with a failing
  ticket, asserts the dashboard endpoint shows the broken ref and the cron
  stops calling GitHub for it on cycle 4.

### Acceptance Criteria

- [x] All five test files exist with the listed coverage
<!-- canon:realized-in:PR#667 file:tests/test_db/test_ticket_ref_status_store.py -->
<!-- canon:realized-in:PR#675 file:tests/test_web/test_broken_refs_mutations.py -->
<!-- canon:realized-in:PR#675 file:tests/test_web/test_services.py -->
<!-- canon:realized-in:PR#678 file:tests/test_web/test_broken_refs_mutations.py -->
<!-- canon:realized-in:PR#678 file:tests/test_web/test_services.py -->
- [ ] Integration test runs in CI and validates end-to-end behavior
- [ ] All new code paths are exercised by at least one test layer
- [ ] Existing test suites still pass (no regressions)

## 6. Out of scope

- Replacing the `sys.exit(1)` behavior in the cron (Option A from
  brainstorming). Once broken refs are filtered, per-section error counts
  drop to near-zero in steady state; the residual issue (transient 5xx
  storms triggering retries) becomes a smaller follow-up best handled
  separately.
- Inline editing of broken refs (replacing one ticket-id with another).
  V1 supports removing the ref entirely; replacing happens via the
  existing spec-edit flow.
- Bulk operations on the dashboard panel (dismiss-all, remove-all). 178
  is a one-time backlog and steady-state volume is unknown.
- Notifications when a ref auto-heals after the 24h re-check. Worth
  considering if users find it surprising that flags disappear without
  action.
