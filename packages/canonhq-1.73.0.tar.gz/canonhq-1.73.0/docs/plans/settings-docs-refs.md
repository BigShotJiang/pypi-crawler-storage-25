---
title: "Settings: Documentation References & Contextual Help"
spec: docs/specs/settings-docs-refs.md
status: in-progress
created: "2026-05-13"
---

# Implementation Plan: Settings Documentation References

## Task 1 — Create HelpLink and InfoTooltip components
**ACs:** 2.1, 2.2
**Files:**
- `CREATE frontend/src/components/common/HelpLink.vue`
- `CREATE frontend/src/components/common/InfoTooltip.vue`

### HelpLink.vue
Reusable "Learn more →" link. Props: `href: string` (required), `text: string`
(default: "Learn more"). Renders an `<a>` tag with `target="_blank"`
`rel="noopener noreferrer"`. Styling follows existing muted text pattern:
`text-xs text-accent-500 hover:text-accent-600 dark:text-accent-400 dark:hover:text-accent-300 hover:underline inline-flex items-center gap-1`.
Include a small external-link SVG icon (→ arrow or external link icon).

### InfoTooltip.vue
Reusable ⓘ icon with hover tooltip. Props: `text: string` (required).
Renders a `<span>` with an inline SVG info-circle icon
(`text-slate-400 dark:text-slate-500 cursor-help`) and a `title` attribute
for the tooltip. Keep it simple — no JS tooltip library, just native
`title` attr matching the existing ad-hoc tooltip pattern in the codebase
(ThemeToggle.vue, AppSidebar.vue).

**Estimated size:** ~40 lines total across both files.

---

## Task 2 — Integrations tab help text and doc links
**ACs:** 2.3
**Files:**
- `EDIT frontend/src/views/settings/SettingsIntegrationsTab.vue`

### Changes:
1. **Import** `HelpLink` from `@/components/common/HelpLink.vue` (add to
   script imports).

2. **Version Control section** (after `<h2>` at ~line 120): Insert section
   description paragraph + HelpLink:
   ```html
   <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">
     Connect Canon to your GitHub repositories for PR analysis and doc updates.
     <HelpLink href="https://canonhq.co/docs/guides/github-app" />
   </p>
   ```

3. **Ticketing section** (after `<h2>` at ~line 191): Insert section
   description + HelpLink:
   ```html
   <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">
     Connect a ticket system to sync spec sections to issues automatically.
     <HelpLink href="https://canonhq.co/docs/guides/ticket-sync" />
   </p>
   ```

4. **Notifications section** (after `<h2>` at ~line 355): Insert HelpLink to
   configuration guide:
   ```html
   <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">
     Slack integration is configured via environment variables.
     <HelpLink href="https://canonhq.co/docs/getting-started/configuration#slack" />
   </p>
   ```

---

## Task 3 — API Keys tab help text and doc links
**ACs:** 2.4
**Files:**
- `EDIT frontend/src/views/settings/SettingsApiKeysTab.vue`

### Changes:
1. **Import** `HelpLink`.

2. **Replace** existing description paragraphs (~lines 14-19) with updated
   text including doc links:
   ```html
   <p class="text-sm text-slate-500 dark:text-slate-400 mt-2">
     API keys provide programmatic access to Canon for the CLI and CI
     integrations. Keys are scoped to your organization.
   </p>
   <p class="text-sm text-slate-500 dark:text-slate-400 mt-2">
     API key management UI is being migrated here. In the meantime, use
     the <code class="text-xs">canon</code> CLI to manage keys.
   </p>
   <div class="flex gap-4 mt-3">
     <HelpLink href="https://canonhq.co/docs/reference/cli" text="CLI reference" />
     <HelpLink href="https://canonhq.co/docs/reference/api" text="API reference" />
   </div>
   ```

---

## Task 4 — Billing tab help text
**ACs:** 2.5
**Files:**
- `EDIT frontend/src/views/settings/SettingsBillingTab.vue`

### Changes:
1. **Import** `InfoTooltip`.

2. **AI Operations section header** (~line 143): Add InfoTooltip next to
   "AI Operations" heading:
   ```html
   <h3 class="...">
     AI Operations
     <InfoTooltip text="AI operations include PR analysis, realization checks, spec coverage updates, and agent-generated doc suggestions. Each action counts as one operation." />
   </h3>
   ```

---

## Task 5 — AI tab help text and doc links
**ACs:** 2.6
**Files:**
- `EDIT frontend/src/views/settings/SettingsAiTab.vue`

### Changes:
1. **Import** `HelpLink` and `InfoTooltip`.

2. **Section description** — insert before the card div (~line 77):
   ```html
   <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">
     Configure AI model access for Canon's agent features. Pro plans include
     AI operations; Starter plans require a BYOK API key.
     <HelpLink href="https://canonhq.co/docs/getting-started/configuration" />
   </p>
   ```

3. **BYOK help text** — add InfoTooltip next to "Anthropic API Key (BYOK)"
   heading:
   ```html
   <InfoTooltip text="Bring Your Own Key: provide your Anthropic API key for AI features on the Starter plan. Pro plans include AI operations and don't require a key." />
   ```

---

## Task 6 — Sync tab top-level help text and doc links
**ACs:** 2.7
**Files:**
- `EDIT frontend/src/views/settings/SettingsSyncTab.vue`

### Changes:
1. **Import** `HelpLink`.

2. **Section description** — insert after the "Sync Configuration" heading
   and before the repo selector (~line 229):
   ```html
   <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">
     Configure how Canon syncs spec sections to tickets in your issue
     tracker. Each repository can have its own mapping configuration stored
     in CANON.yaml.
     <HelpLink href="https://canonhq.co/docs/guides/ticket-sync" />
   </p>
   ```

3. **No repos warning** (~line 251): Append HelpLink to existing text:
   ```html
   <HelpLink href="https://canonhq.co/docs/guides/github-app" text="GitHub App setup" />
   ```

---

## Task 7 — Sync sub-editor help text and doc links
**ACs:** 2.8
**Files:**
- `EDIT frontend/src/components/sync/StatusMapEditor.vue`
- `EDIT frontend/src/components/sync/FieldMapEditor.vue`
- `EDIT frontend/src/components/sync/HierarchyEditor.vue`
- `EDIT frontend/src/components/sync/RoutingRulesEditor.vue`
- `EDIT frontend/src/views/settings/SettingsSyncTab.vue` (presets tooltip)

### StatusMapEditor.vue
1. **Import** `HelpLink`, `InfoTooltip`.
2. **Insert at line 64** (top of template, before Forward Map):
   ```html
   <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">
     Map spec section states to ticket statuses in your issue tracker.
     <HelpLink href="https://canonhq.co/docs/reference/config#status-mapping" />
   </p>
   ```
3. **Reverse Map heading** (~line 130): Add InfoTooltip:
   ```
   InfoTooltip text="Reverse mapping syncs ticket status changes back to spec states. When a ticket moves to 'Done', the corresponding spec section updates automatically."
   ```

### FieldMapEditor.vue
1. **Import** `HelpLink`, `InfoTooltip`.
2. **Insert at line 95** (top of template, before Standard Fields):
   ```html
   <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">
     Map spec metadata to ticket fields. Standard fields map common
     attributes; custom fields target system-specific fields.
     <HelpLink href="https://canonhq.co/docs/reference/config#field-mapping" />
   </p>
   ```
3. **Custom Fields heading** (~line 176): Add InfoTooltip:
   ```
   InfoTooltip text="Custom fields use dotpath syntax (e.g., 'customfield_10001') to target system-specific fields in Jira or Linear."
   ```

### HierarchyEditor.vue
1. **Import** `HelpLink`.
2. **Insert at line 58** (top of template):
   ```html
   <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">
     Control how spec nesting maps to ticket types and parent-child
     relationships.
     <HelpLink href="https://canonhq.co/docs/reference/config#hierarchy" />
   </p>
   ```

### RoutingRulesEditor.vue
1. **Import** `HelpLink`, `InfoTooltip`.
2. **Insert at line 137** (top of template, before warning banner):
   ```html
   <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">
     Route tickets to different projects or boards based on spec tags, team,
     or other metadata.
     <HelpLink href="https://canonhq.co/docs/reference/config#routing" />
   </p>
   ```
3. **Shadow targets** (wherever shadow_targets UI appears in rule cards):
   Add InfoTooltip:
   ```
   InfoTooltip text="Shadow targets receive read-only copies of tickets. Use this to mirror tickets to a secondary system without creating duplicates."
   ```

### SettingsSyncTab.vue — Presets
4. **Import** `InfoTooltip`.
5. **Presets label** (~line 322): Add InfoTooltip next to "Presets" heading:
   ```
   InfoTooltip text="Applying a preset replaces all current status mappings, field mappings, and routing rules with preconfigured defaults."
   ```

---

## Task 8 — Document `triage` section in config reference
**ACs:** 3.1
**Files:**
- `EDIT docs-site/reference/config.md`

### Changes:
Insert a new `### \`triage\`` section after the `sre` section (~after line
338, before `### \`slack\``). Content:

```markdown
### `triage`

Controls automatic issue triage behavior when Canon processes incoming
GitHub issues.

#### `triage.enabled`

**Type:** `boolean`
**Default:** `true`

Enable or disable automatic issue triage.

#### `triage.auto_create_specs`

**Type:** `boolean`
**Default:** `false`

Automatically create spec documents from triaged issues.

#### `triage.classify_labels`

**Type:** `boolean`
**Default:** `true`

Automatically classify and apply labels to triaged issues.

#### `triage.ignore_labels`

**Type:** `string[]`
**Default:** `[]`

Issues with any of these labels will be skipped during triage.

#### `triage.ignore_authors`

**Type:** `string[]`
**Default:** `[]`

Issues from these authors will be skipped during triage.

#### `triage.spec_template`

**Type:** `string`
**Default:** `"docs/specs/_template.md"`

Path to the spec template used when `auto_create_specs` is enabled.

#### `triage.confidence_threshold`

**Type:** `number`
**Default:** `0.7`

Minimum confidence score (0.0-1.0) for auto-classification actions.
```

Also add `triage` to the YAML schema block (~line 35 area) with a comment.

---

## Task 9 — Remove phantom `sync` section, redirect to real fields
**ACs:** 3.2
**Files:**
- `EDIT docs-site/reference/config.md`

### Changes:
Replace the `### \`sync\`` section (lines 217-245) with a redirect note:

```markdown
### `sync` (deprecated alias)

::: warning
The `sync` block is a documentation alias for top-level fields. Use the
canonical field names instead:

| `sync` field | Canonical equivalent |
|---|---|
| `sync.system` | [`ticket_system`](#ticket-system) |
| `sync.project_key` | [`project_key`](#project-key) |
| `sync.create_tickets` | [`specs.auto_tickets`](#specs-auto-tickets) |
| `sync.reverse_sync` | [`specs.lifecycle_sync`](#specs-lifecycle-sync) |
:::
```

Also update the schema block (lines 35-41) to add a comment noting these
are aliases, or remove the `sync:` block from the schema entirely and add
a note.

---

## Task 10 — Document `ticket_mapping` advanced features
**ACs:** 3.3
**Files:**
- `EDIT docs-site/reference/config.md`

### Changes:
Expand the `### \`ticket_systems\` / \`routing\`` section (~line 247) from
its current one-liner into a comprehensive reference. Replace lines 247-249
with detailed documentation covering:

1. **`ticket_systems.<name>` fields**: `system`, `project`, `status_map`,
   `hierarchy`, `auto_parent` (already in schema), plus undocumented:
   `field_map` (standard + custom), `templates` (summary, description),
   `dedup_enabled`, `host_override`, `auth_profile`

2. **`status_map` sub-fields**: Forward mapping (already shown), plus
   `reverse` (reverse mapping dict) and `fallback` (default: `"draft"`)

3. **`hierarchy` sub-fields**: `depth_to_type` mapping, `auto_parent`,
   plus `default_type` (default: `"Task"`)

4. **`routing[]` fields**: `match` (tags, team, default), `target`, plus
   `shadow_targets` (list of read-only sync targets)

5. **`auth_profiles`**: Named credential sets with `system`,
   `auth_method`, `env_prefix`

Use the same formatting pattern as other sections (Type, Default, description).

---

## Task 11 — Add stable anchor IDs to config reference
**ACs:** 3.4
**Files:**
- `EDIT docs-site/reference/config.md`

### Changes:
Verify VitePress auto-generated anchors from the new headings added in
Tasks 8-10 match the links used in the frontend (Tasks 2-7). Key anchors
needed:

- `#status-mapping` — from `### Status Mapping` or add `{#status-mapping}`
- `#field-mapping` — from `### Field Mapping` or add `{#field-mapping}`
- `#hierarchy` — from `### Hierarchy` or add `{#hierarchy}`
- `#routing` — from `### Routing Rules` or add `{#routing}`
- `#triage` — auto-generated from `### \`triage\``

If VitePress auto-generates anchors like `#ticket-systems-routing` instead
of `#routing`, add explicit `{#routing}` overrides to headings. Test by
building docs locally: `cd docs-site && npm run build`.

Structure the new `ticket_systems` / `routing` expanded section with these
sub-headings to create the needed anchors:

```markdown
### `ticket_systems` / `routing` {#ticket-systems}

#### Status Mapping {#status-mapping}
#### Field Mapping {#field-mapping}
#### Hierarchy {#hierarchy}
#### Routing Rules {#routing}
#### Auth Profiles {#auth-profiles}
#### Templates {#templates}
```

---

## Task 12 — Update ticket-sync guide
**ACs:** 3.5
**Files:**
- `EDIT docs-site/guides/ticket-sync.md`

### Changes:
1. **Add Field Mapping section** (~after line 125, after Status Mapping):
   New `### Field Mapping` section explaining standard and custom field
   mappings with a YAML example. Cross-link to
   `/reference/config#field-mapping`.

2. **Add Presets section** (~after Routing Rules, before Adapter Architecture):
   New `### Presets` section explaining what presets are, how to apply them
   from the settings UI, and how they relate to the YAML config. Mention
   that presets replace current config.

3. **Add Settings UI section** at the end (before or after Adapter
   Architecture): Brief section explaining that sync can be configured from
   the Canon web app at Settings → Sync, with a link to
   `/reference/config#ticket-systems` for full reference.

4. **Cross-reference shadow_targets** in the Routing Rules section: Add a
   note about `shadow_targets` for read-only mirroring.

---

## Execution Order

```
Task 1  (components)     ─── independent, do first
Task 8  (triage docs)    ┐
Task 9  (sync docs)      ├── docs tasks, can run in parallel
Task 10 (ticket_mapping) │
Task 11 (anchors)        ┘ depends on 8-10
Task 12 (guide update)   ─── depends on 10-11

Task 2  (integrations)   ┐
Task 3  (api keys)       │
Task 4  (billing)        ├── frontend tasks, all depend on Task 1
Task 5  (ai)             │   can run in parallel with each other
Task 6  (sync top)       │
Task 7  (sync editors)   ┘
```

**Critical path:** Task 1 → Tasks 2-7 (frontend), Tasks 8-10 → Task 11 → Task 12 (docs)

Both workstreams (frontend + docs) are independent and can execute in parallel.
