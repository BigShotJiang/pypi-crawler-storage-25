from .cmd_deploy import push
from .cmd_schema import new_schema, set_default_schema
from .cmd_init import init
from .cmd_generate import generate, run_generate
from .cmd_ping import ping
from .cmd_info import info
from .cmd_roles.main import roles
from .cmd_feed import feed
from .cmd_backup import backup
from .cmd_restore import restore
from .cmd_install import install

__all__ = [
    'new_schema',
    'set_default_schema',
    'init',
    'generate',
    'run_generate',
    'ping',
    'info',
    'push',
    # 'deploy',
    'roles',
    'feed',
    'backup',
    'restore',
    'install',
]