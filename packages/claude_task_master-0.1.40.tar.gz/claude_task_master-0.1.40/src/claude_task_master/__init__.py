"""Claude Task Master - Autonomous task orchestration system.

Uses Claude Agent SDK to keep Claude working until a goal is achieved.
"""

__version__ = "0.1.40"
__all__ = ["__version__"]
