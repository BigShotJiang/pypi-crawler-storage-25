import pytest

from openai.types.model import Model


@pytest.fixture
def mocked_client():
    """mocks openai.OpenAI to avoid network calls"""

    class Data:
        data: list[Model] = [
            Model(
                id="dummy-model",
                created="1234",
                object="model",
                owned_by="pytest",
            )
        ]

    class Models:
        def list(self):
            return Data()

    class Message:
        content = "dummy"

    class Choice:
        message = Message()

    class Response:
        choices = [Choice()]

    class MockCompletions:
        def create(self, *args, **kwargs):
            return Response()

        @property
        def models(self):
            return Models()

    class MockChat:
        completions = MockCompletions()

    class MockClient:
        chat = MockChat()
        base_url = "http://localhost:8080"

        models = Models()

    return MockClient()
