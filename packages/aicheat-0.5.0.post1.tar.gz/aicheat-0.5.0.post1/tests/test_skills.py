from aicheat.skills import SkillManager
import os

from textwrap import dedent

from aicheat.chat import Conversation
from aicheat.skills import Skill

from pathlib import Path
import pytest

from aicheat.commands import load, save
from typing import Generator
from aicheat.commands import skill as skill_command


@pytest.fixture
def skill_name() -> str:
    return "Test Skill"


@pytest.fixture
def skill_description() -> str:
    return "A test skill with YAML frontmatter"


@pytest.fixture
def skill_stem() -> str:
    return "test_skill"


@pytest.fixture
def skill_version() -> str:
    return "1.1.0"


@pytest.fixture
def skill_tags() -> list[str]:
    return ["test", "example"]


@pytest.fixture
def skill_raw(
    skill_name: str, skill_description: str, skill_version: str, skill_tags: list[str]
) -> str:
    return dedent(
        f"""
        ---
        name: {skill_name}
        description: {skill_description}
        version: {skill_version}
        tags: [{skill_tags[0]}, {skill_tags[1]}]
        ---

        # Test Skill

        This is a test skill to verify YAML frontmatter parsing.

        ## Rules

        - rule 1
        - rule 2
        """
    ).strip()


@pytest.fixture
def skill_path(
    tmp_path: Path,
    skill_raw: str,
    skill_stem: str,
) -> Generator[Path, None, None]:
    path = (tmp_path / skill_stem).with_suffix(".md")
    with path.open("w") as fh:
        fh.write(skill_raw)
    yield path


@pytest.fixture
def skill(skill_path: Path) -> Skill:
    return Skill.from_file(skill_path)


def test_skill_load(
    skill: Skill,
    skill_name: str,
    skill_description: str,
    skill_version: str | int,
    skill_path: Path,
    skill_tags: list[str],
):
    # Check basic properties
    assert skill.name == skill_name
    assert skill.description == skill_description
    assert skill.path == skill_path

    # Check metadata
    assert skill.metadata["name"] == skill_name
    assert skill.metadata["description"] == skill_description
    assert skill.metadata["version"] == skill_version
    assert skill.metadata["tags"] == skill_tags


def test_skillmanager(tmp_path, skill_path, skill):
    """Test that skills with YAML frontmatter are parsed correctly"""

    # Load the skill using SkillManager
    skill_manager = SkillManager()
    skill_manager.load([skill_path])

    # Verify the loaded skill
    assert len(skill_manager) == 1
    assert skill == list(skill_manager.values())[0]


def test_skill_parsing_without_yaml_frontmatter(tmp_path):
    """Test that skills without YAML frontmatter still work correctly"""
    # Create a temporary skill file without YAML frontmatter
    skill_content = dedent(
        """
        # Basic Skill

        This is a basic skill without YAML frontmatter.

        ## Rules

        - rule 1
        - rule 2
        """
    ).strip()

    # Write test skill to a temporary file
    test_file = tmp_path / "basic_skill.md"
    test_file.write_text(skill_content)

    # Load the skill using SkillManager
    skill_manager = SkillManager()
    skill_manager.load([test_file])

    # Verify the loaded skill
    assert len(skill_manager) == 1
    skill = list(skill_manager.values())[0]

    # Check basic properties (fallback behavior)
    assert skill.name == "Basic Skill"
    assert skill.description == "This is a basic skill without YAML frontmatter."
    assert skill.path == test_file

    # Check metadata is empty
    assert skill.metadata == {}


def test_skill_parsing_with_invalid_yaml(tmp_path, caplog):
    """Test that skills with invalid YAML frontmatter handle gracefully"""
    # Create a temporary skill file with invalid YAML frontmatter
    skill_content = dedent(
        """
        ---
        name: skill name from frontmatter
        description: A test skill with invalid YAML frontmatter
        version: !!invalid
        ---

        # Invalid YAML frontmatter Skill

        This is a test skill with invalid YAML frontmatter.

        ## Rules

        - rule 1
        - rule 2
        """
    ).strip()

    # Write test skill to a temporary file
    test_file = tmp_path / "invalid_yaml_skill.md"
    test_file.write_text(skill_content)

    # Load the skill using SkillManager
    skill_manager = SkillManager()
    skill_manager.load([test_file])
    assert "Failed to parse YAML frontmatter" in caplog.text

    # Verify the loaded skill (should still load but with warning)
    assert len(skill_manager) == 1
    skill = list(skill_manager.values())[0]

    # Should fall back to default behavior when YAML is invalid
    assert skill.name == "Invalid YAML frontmatter Skill"
    assert skill.description == "This is a test skill with invalid YAML frontmatter."


def test_memory_save_load_with_skills(tmp_path: Path, skill: Skill, mocked_client):
    """Test saving and loading conversation memory with skills."""
    os.chdir(tmp_path)

    conversation = Conversation(
        client=mocked_client,
    )
    # mock the model, which is usually populated by .start()
    conversation.model = mocked_client.models.list().data[0]

    skill_command(conversation, f"load {skill.path.as_posix()}")

    assert len(conversation.skill_manager) == 1

    memory_file = tmp_path / "memory.md"
    save(conversation, "")
    assert memory_file.exists()

    memory_content = memory_file.read_text()
    assert memory_content.startswith("---"), "Memory file should start with frontmatter"

    # fmt: off
    assert "Test Skill" in memory_content, "Memory file should contain skill information"
    assert "# Description" in memory_content, "Memory file should contain conversation description section"
    assert "## Summary" in memory_content, "Memory file should contain session summary header"
    # fmt: on

    # Create a new conversation and load the memory
    new_conversation = Conversation(
        mocked_client,
    )
    assert len(new_conversation.skill_manager) == 0, (
        "New conversation should have no skills initially"
    )

    # Load the memory (this should also load the skills)
    # Note: We're not testing the return value here, just that skills are loaded
    load(new_conversation, "")

    # Check that skills were loaded
    assert len(new_conversation.skill_manager) == 1, (
        "Skills should be loaded from memory file"
    )

    assert "Test Skill" in [
        skill.name for skill in new_conversation.skill_manager.values()
    ], "Test skill should be loaded"
