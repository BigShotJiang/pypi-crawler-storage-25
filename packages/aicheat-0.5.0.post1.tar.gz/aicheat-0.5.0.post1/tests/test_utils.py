import pytest
from aicheat.chat_utils import extract_json_from_vllm_error


def test_extract_json_from_vllm_error():
    # Example vLLM validation error with tuple and escaped single quotes inside a double‑quoted string
    error_msg = (
        "1 validation error:\n"
        "  {'type': 'literal_error', 'loc': ('body', 'reasoning_effort'), "
        "'msg': \"Input should be \\'low\\', \\'medium\\' or \\'high\\'\", "
        "'input': 'none', 'ctx': {'expected': \"'low', 'medium' or 'high'\"}}\n"
        "\n"
        '  File "/opt/vllm/lib64/python3.12/site-packages/vllm/entrypoints/utils.py", line 477, in create_chat_completion'
    )
    result = extract_json_from_vllm_error(error_msg)

    assert result["loc"] == ["body", "reasoning_effort"]
    assert result["msg"] == "Input should be 'low', 'medium' or 'high'"
    assert result["type"] == "literal_error"
    assert result["input"] == "none"
    assert result["ctx"]["expected"] == "'low', 'medium' or 'high'"


def test_extract_json_from_vllm_error_no_dict_line():
    error_msg = "This error does not contain a JSON-like dict line."
    with pytest.raises(ValueError, match="No dict line found"):
        extract_json_from_vllm_error(error_msg)
