# Using aicheat with llama.cpp

[llama.cpp](https://github.com/ggerganov/llama.cpp) is a C++ implementation of LLM inference optimized for CPU usage.

## Setup

1. Install and start llama.cpp server:

   ```bash
   # Clone and build llama.cpp
   git clone https://github.com/ggerganov/llama.cpp
   cd llama.cpp
   make

   # Start server (example with Llama 2 7B)
   ./server -m models/llama-2-7b.Q4_K_M.gguf --host 0.0.0.0 --port 8000
   ```

2. Configure aicheat:

   ```bash
   export AICHEAT_HOST="http://localhost:8000"
   # llama.cpp typically doesn't require an API key
   ```

   3. Start aicheat:

   ```bash
   aicheat
   ```

## Notes

- llama.cpp is CPU-focused and works well on machines without GPUs
- Various quantization levels are available (Q4_K_M, Q5_K_M, etc.) to balance performance and quality
- Check the [llama.cpp documentation](https://github.com/ggerganov/llama.cpp) for detailed setup instructions
