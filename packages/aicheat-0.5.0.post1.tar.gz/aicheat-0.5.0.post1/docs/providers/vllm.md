# Using aicheat with vLLM

[vLLM](https://github.com/vllm-project/vllm) is a fast and easy-to-use library for LLM inference.

## Setup

1. Install and start vLLM server:

```bash
# Install vLLM
uv pip install vllm # cuda
VLLM_TARGET_DEVICE=cpu uv pip install vllm --no-binary=vllm --torch-backend=cpu # CPU


# Start server (example with Llama 2 7B)
python -m vllm.entrypoints.api_server \
    --host 0.0.0.0 \
    --port 8000 \
    --model meta-llama/Llama-2-7b-hf
```

2. Configure aicheat:

   ```bash
   export AICHEAT_HOST="http://localhost:8000"
   # Set API key if required by your vLLM setup
   export OPENAI_API_KEY="token-abc123"
   ```

3. Start aicheat:

   ```bash
   aicheat
   ```

## Notes

- vLLM supports various quantization methods for reduced memory usage
- Check the [vLLM documentation](https://docs.vllm.ai/) for detailed setup instructions
- Model loading may take some time on first run
