# Using aicheat with OpenAI API

While aicheat is primarily designed to work with self-hosted OpenAI-compatible servers, it can also work with the official OpenAI API.

## Setup

1. Set your environment variables:

   ```bash
   export AICHEAT_HOST="https://api.openai.com"
   export OPENAI_API_KEY="your-openai-api-key"
   export AICHEAT_MODEL="gpt-4o" # optional
   ```

2. Start aicheat:

   ```bash
   aicheat
   ```

## Notes

- You'll be prompted to select from available models if AICHEAT_MODEL is not set (gpt-3.5-turbo, gpt-4, etc.)
- Be aware of costs when using OpenAI's paid API
