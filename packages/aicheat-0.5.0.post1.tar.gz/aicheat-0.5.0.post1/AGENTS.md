# aicheat

`aicheat` is a python cli-based coding assistant.

## Features

- Uses `prompt-toolkit` for input, leveraging its powerful line-editing capabilities
- Theming support using `pygments`
- Live streaming of model output using `rich.live.Live`
- Tool calling capabilities
- `AGENTS.md`/`CLAUDE.md` file support
- Skills support

## Installation

The package can be installed in editable mode.

```bash
uv pip install -e '.[dev]'
```

This will install the `aicheat` entrypoint script and make changes immediately available after modifying the code.

## Development

- New commands can be defined as functions in the `aicheat.commands` module, these should be registered using the `aicheat.commands.command_handler` decorator
- New tools can be defined as submodules in the `aicheat.tools` module. New tools:
  - Have to be registered using the `aicheat.tools.core.tool` decorator, which registers tools in the registry (`aicheat.tools.registry`)
  - Registered (and enabled) tools are made available to the model on every call
  - `aicheat.tools.get_tools` can be used to retrieve enabled tools
  - Tools can be enabled enabled/disabled at runtime by users by setting the `enabled` attribute
  - Tools/tools modules are automatically loaded from `aicheat.tools` submodules, the mechanism used to accomplish this is `aicheat.utils._init_submodules`, which needs to be invoked in every module's, see `aicheat.code`'s `__init__.py` for an example.

## Tests

A minimal set of tests is defined in the `tests` directory. These use `pytest` and can be run like so:

```bash
pytest tests
# Select tests using: -k
pytest tests -k test_skills # runs all the skills tests
pytest tests/test_skills.py # run the full skills test module
```

New features should implement unit tests and integrations tests, when possible.

## Release Process

To create release notes for a new version:

1. Check what commits have been added since the last release using the `git_updates` tool
2. Examine specific commits with `git show COMMIT_HASH` to understand the changes
3. Review previous release notes format by checking the annotated tag with `git show LAST_VERSION`
4. Create release notes following the established format (New, Fixes, Misc sections as appropriate)
5. Save the release notes in a file named after the version (e.g., `v0.2.3.md`)
6. Create a new annotated tag with `git tag -a v0.2.3 -m "$(cat v0.2.3.md)"`

This process ensures consistent documentation of changes and follows the project's established conventions.
