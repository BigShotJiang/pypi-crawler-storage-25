from __future__ import annotations

import base64
import json
import os
import sys
import textwrap
from functools import cached_property
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx
import pygments
from openai import APITimeoutError, InternalServerError, OpenAI, BadRequestError
from openai.types import ReasoningEffort
from openai.types.chat.chat_completion_chunk import (
    ChatCompletionChunk,
    ChoiceDelta,
    CompletionUsage,
)
from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import FormattedText
from prompt_toolkit.history import FileHistory
from prompt_toolkit.lexers import PygmentsLexer
from prompt_toolkit.styles import Style, merge_styles, style_from_pygments_cls
from pygments.lexers.markup import MarkdownLexer
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.prompt import Prompt
from rich.status import Status
from rich.theme import Theme

from .chat_utils import ToolCall
from .commands import get_prefixes as get_command_prefixes
from .commands import handlers as command_handlers
from .commands import match_command
from .completions import CommandPrefixCompleter
from .config import config, ModelConfig
from .keybindings import register_conversation
from .exceptions import BadRequestException, UnexpectedError
from .logger import getLogger
from .model_utils import get_model_max_context
from .prompts import default_system_prompt
from .skills import manager as skill_manager
from .tools import Tool, get_tools, registry
from .utils import choice, get_system_information

if TYPE_CHECKING:
    from openai.types import Model

    from .commands import CommandHandler
    from .config import Config

logger = getLogger(__name__)

lexer = MarkdownLexer()


class Conversation:
    default_system_prompt = default_system_prompt.format(
        system_information=get_system_information(),
        pwd=os.getcwd(),
    )

    response_start = " "
    help_text = "# Write a question. Hit ctrl-c (twice) to clear the conversation, ctrl-v to enter multiline mode, ctrl-d to exit.\n# Use ctrl-x ctrl-e (emacs) or vv (vim) to use your editor to edit the current message."
    markdown_theme_default = "gruvbox-dark"

    def __init__(
        self,
        client: OpenAI,
        config: Config,
        print_timings: bool = False,
        debug: bool = False,
        load_agent_files: bool = True,
    ):
        self.client = client
        self.config = config
        self.load_agent_files = load_agent_files
        config.init()

        self._session_default_prompt = [("class:prompt", "❯ ")]
        self._markdown_theme = next(
            (
                theme
                for theme in (
                    os.getenv(name)
                    for name in ("AICHEAT_THEME", "BAT_THEME", "PYTEST_THEME")
                )
                if theme
            ),
            self.markdown_theme_default,
        )
        self._session: PromptSession = PromptSession(
            message=self._session_default_prompt,
            vi_mode=os.getenv("EDITOR") in ("vi", "vim", "nvim"),
            enable_open_in_editor=True,
            enable_suspend=True,
            style=self._get_prompt_toolkit_style(),
            history=FileHistory(self.config.chat_history_path),
            key_bindings=register_conversation(self),
            tempfile_suffix=".md",
            completer=CommandPrefixCompleter.from_nested_dict(
                {
                    command.full_name: command.completer
                    for command in command_handlers.values()
                    if command.prefix != "!"
                }
            ),
            lexer=PygmentsLexer(
                MarkdownLexer,
                sync_from_start=True,
            ),
        )

        self._system_prompt_override: str | None = None
        self._chunks: list[ChatCompletionChunk] = []
        self.print_timings = print_timings
        self._show_reasoning = False
        self._reasoning_status: Status | None = None
        self._reasoning_effort: ReasoningEffort = "none"
        self._multiline = False
        self._status: Status | None = None
        self._tool_call_statuses: dict[int, Status] = {}
        self._debug = debug
        self.console = Console(
            theme=Theme(
                {
                    "info": "bold green",
                    "tool": "bold orange1",
                    "error": "bold red",
                    "system": "bold yellow",
                    "user": "bold cyan",
                }
            )
        )
        self.skill_manager = skill_manager
        self._agent_files_contents: dict[str, str] = {}

        self._ctrl_c_reset_counter = 0

        self._yolo_mode: dict[str, bool] = {
            # maps tool_name -> yolo mode
            "_default": False,  # default value for no tool-specific override
        }

        self.model: Model | None = None
        self._memory: str | None = None
        self._messages: list[dict[str, Any]] = []

    def _get_prompt_toolkit_style(self) -> Style:
        return merge_styles(
            [
                Style.from_dict(
                    {
                        # TODO: standardize
                        # foreground only
                        "prompt": "ansibrightgreen",
                        # foreground + background
                        "error": "ansired bg:#372525",
                        # bright + attribute
                        "warning": "ansibrightyellow bold",
                        # custom RGB
                        "info": "#00aaff",
                        # custom RGB background
                        "debug": "bg:#001122 #aabbcc",
                    }
                ),
                style_from_pygments_cls(
                    pygments.styles.get_style_by_name(self._markdown_theme),
                ),
            ]
        )

    def set_theme(self, name: str) -> None:
        try:
            pygments.styles.get_style_by_name(name)
        except pygments.util.ClassNotFound:
            raise ValueError(f"invalid pygment theme {name}")

        self._markdown_theme = name
        self._session.style = self._get_prompt_toolkit_style()

    @property
    def theme(self) -> str:
        return self._markdown_theme

    def _maybe_load_agents_files(self) -> None:
        """Check for AGENTS.md or CLAUDE.md files and prompt user for confirmation to load them."""
        if not self.load_agent_files:
            logger.info("Not checking for agent files.")
            return None

        current_dir = Path.cwd()
        agent_files = {
            (current_dir / name).resolve() for name in ("AGENTS.md", "CLAUDE.md")
        }

        for file in agent_files:
            if not file.exists():
                logger.debug("Tried to load nonexisting file: %s", file.name)
                continue

            self.console.print(
                f"Found {file.name} in current directory.", style="system"
            )

            try:
                contents = file.read_text()
            except Exception as e:
                logger.exception("Failed to load %s", file.resolve().as_posix())
                self.console.print(f"Failed to load {file.name}: {e}", style="error")
                continue

            result = ""
            while result not in ("y", "n"):
                result = choice(
                    FormattedText(
                        [("bold", f"⮕ Load {file.name}? (s to show contents)")]
                    ),
                    choices=("y", "n", "s"),
                    default="n",
                )
                if result != "s":
                    continue
                self.console.print(f"{file.name} contents:", style="system")
                self._print_markdown(contents)

            if result.lower() == "n":
                self.console.print(f"Skipping {file.name}", style="system")
                continue

            self._agent_files_contents[file.name] = contents

    def _load_memory(self) -> str | None:
        """Check for AGENTS.md or CLAUDE.md files and prompt user for confirmation to load them."""
        file = Path.cwd() / "memory.md"
        if not file.exists():
            logger.debug("No memory files available.")
            return None

        contents = file.read_text()
        result = ""
        while result not in ("y", "n"):
            result = choice(
                FormattedText(
                    [
                        (
                            "bold",
                            f"⮕ Found {file.name} in current directory. Load? (s to show contents)",
                        )
                    ]
                ),
                choices=("y", "n", "s"),
                default="n",
            )
            if result != "s":
                continue
            self.console.print(f"{file.name} contents:", style="system")
            self._print_markdown(contents)

        if result.lower() == "n":
            self.console.print(f"Not loading {file.name}", style="system")
            return None

        from .commands import load as load_memory

        return load_memory(
            self,
            file.resolve().as_posix(),
            pretty_format=False,
        )

    def _get_markdown(self, text: str, *args, **kwargs) -> Markdown:
        code_theme = kwargs.pop("code_theme", self._markdown_theme)
        return Markdown(
            text,
            *args,
            code_theme=code_theme,
            inline_code_lexer=lexer,
            **kwargs,
        )

    def _print_markdown(
        self, text: str, *args, markdown_kwargs: dict | None = None, **kwargs
    ) -> None:
        """utility wrapper around self.console.print"""
        if markdown_kwargs is None:
            markdown_kwargs = {}
        self.console.print(
            self._get_markdown(text, **markdown_kwargs),
            *args,
            **kwargs,
        )

    @cached_property
    def available_models(self) -> list[Model]:
        try:
            with self.console.status("Connecting..."):
                available_models: list[Model] = self.client.models.list().data
        except APITimeoutError:
            self.console.print(
                f"Timeout while connecting to {self.client.base_url}", style="error"
            )
            sys.exit(1)
        except Exception as exc:  # noqa: F841
            if self._debug:
                self.console.print_exception(theme=self._markdown_theme)

            self.console.print(
                f"Failed to connect to url={self.client.base_url}", style="error"
            )

            sys.exit(1)

        available_models.sort(key=lambda model: model.id)

        if len(available_models) <= 0:
            raise ValueError("No models available")

        return available_models

    def _validate_model(self, model: str | None) -> Model:
        if len(self.available_models) == 1:
            selected_model = self.available_models[0]
            assert selected_model.id

            model_formatted = f"`{selected_model.id}` (ctx={get_model_max_context(selected_model) or 'unknown'})"
            self._print_markdown(f"Inferred model {model_formatted} from server")
            self.config.model = selected_model.id
            logger.info("Overridden config.model=%s", selected_model.id)
            return selected_model

        if model and model not in map(lambda model: model.id, self.available_models):
            self._print_markdown(f"`model={model}` is not available", style="error")
            self._print_markdown(
                "Available models:\n\n".join(
                    f"- {model}" for model in self.available_models
                ),
                style="system",
            )
            sys.exit(1)

        if model:
            self._print_markdown(f"Using `{model=}`")
            return model

    def _select_model(self) -> Model:
        self.console.print("Available models", style="system", end="")
        models_formatted = (
            f"{idx + 1}) {model.id} (ctx={get_model_max_context(model) or 'unknown'})"
            for idx, model in enumerate(self.available_models)
        )
        self._print_markdown("\n".join(models_formatted))
        try:
            model_idx = (
                int(
                    Prompt.ask(
                        "Please select a model",
                        choices=list(
                            map(str, range(1, len(self.available_models) + 1))
                        ),
                        console=self.console,
                    )
                )
                - 1
            )
        except (KeyboardInterrupt, EOFError):
            self.console.print("\nQuitting", style="system")
            sys.exit(0)

        selected_model = self.available_models[int(model_idx)]

        self._print_markdown(f"Selected `{selected_model.id}`")
        return selected_model

    def _reset_conversation(self) -> None:
        self._messages[:] = []

        if self._memory and choice("Clear memory?") == "y":
            self._memory = None

        yolo_mode_config = [
            tool_name for tool_name in self._yolo_mode.keys() if tool_name != "_default"
        ]
        if self.get_yolo_mode() or yolo_mode_config:
            if choice("Clear YOLO mode config?") == "y":
                self._reset_yolo_mode()

        if not self._agent_files_contents:
            return

        agent_answer = choice(
            f"Clear agent files? Loaded: {', '.join(name for name in self._agent_files_contents)} (s to select)",
            choices=("y", "n", "s"),
            default="y",
        )

        if agent_answer not in ("y", "s"):
            return

        if agent_answer == "y":
            self._agent_files_contents.clear()
            return

        assert agent_answer == "s"
        for key in self._agent_files_contents:
            if choice(f"Clear {key}?") == "y":
                self._agent_files_contents.pop(key)

    def override_system_prompt(self, new_prompt: str) -> None:
        self._system_prompt_override = new_prompt

    @property
    def messages(self) -> list[dict[str, str]]:
        """wraps self._messages to always include the updated system prompt.

        Update self._messages when adding/removing messages to the conversation.
        """
        return [
            self.system_prompt,
            *self._messages,
        ]

    @property
    def system_prompt(self) -> dict[str, str]:
        system_prompt = {
            "role": "system",
            "content": self._system_prompt_override or self.default_system_prompt,
        }

        if self.skill_manager.has_skills():
            system_prompt["content"] += self.skill_manager.format_skills()

        if self._agent_files_contents:
            for name, contents in self._agent_files_contents.items():
                system_prompt["content"] += textwrap.dedent(
                    """
                    # Agent files: contents of {name}

                    {contents}
                    """
                ).format(name=name, contents=contents)

        if self._memory:
            system_prompt["content"] += "\n" + self._memory

        return system_prompt

    def _input(self, default: str | None = None, prompt: str | None = None) -> str:
        return self._session.prompt(
            prompt or self._session_default_prompt,
            multiline=False,
            default=default or "",
        )

    def _input_multiline(
        self, default: str | None = None, prompt: str = "(multiline) > "
    ) -> str:
        return self._session.prompt(
            prompt,
            multiline=True,
            prompt_continuation="| ",  # TODO: change color for prompt continuation
            default=default or "",
        )

    def get_input(self) -> str | None:
        try:
            prompt = self._input_multiline() if self._multiline else self._input()
        except KeyboardInterrupt:
            self._ctrl_c_reset_counter += 1
            self._multiline = False
            if self._ctrl_c_reset_counter > 1:
                self._reset_conversation()
                self.console.clear()
                self.console.print(
                    "Cleared conversation. Hit Ctrl-D to exit",
                    style="system",
                )
                self._ctrl_c_reset_counter = 0
            else:
                self.console.print(
                    f"# {'Disabled multiline, h' if self._multiline else 'H'}it Ctrl C again to clear conversation",
                    style="system",
                )

            return None
        except EOFError:
            self.console.print("Quitting", style="system")
            sys.exit(0)

        self._ctrl_c_reset_counter = 0

        return prompt

    def _handle_tool_call_chunk(
        self,
        delta: ChoiceDelta,
        current_tool_call_index: int | None = None,
    ) -> int | None:
        """returns tool call id"""
        status: Status | None = None
        if not delta.tool_calls:
            if current_tool_call_index is not None:
                logger.debug(
                    "Finished streaming tool call index=%s", current_tool_call_index
                )
                status = self._tool_call_statuses.pop(current_tool_call_index)
                status.stop()
            return None

        tool_call_delta = delta.tool_calls[0]

        status = self._tool_call_statuses.get(tool_call_delta.index)

        if status:
            logger.debug("Streaming tool call index=%s...", tool_call_delta.index)
            return tool_call_delta.index

        logger.debug("Starting streaming tool_call index=%s", tool_call_delta.index)

        status = self.console.status(
            self._get_markdown(
                f"Processing tool call `{tool_call_delta.function.name}(...)`",
            ),
            spinner="point",
            spinner_style="system",
        )
        self._tool_call_statuses[tool_call_delta.index] = status

        status.start()
        return tool_call_delta.index

    def _reassemble_chunks(
        self, clear: bool = False
    ) -> tuple[str, str, list[ToolCall]]:
        """Consumes chunks from self._chunks and returns reassembled content and tool calls if any"""
        chunks: list[ChatCompletionChunk] = self._chunks.copy()
        if clear:
            self._chunks[:] = []

        content_chunks: list[str] = []
        reasoning_chunks: list[str] = []
        tool_calls: dict[int, ToolCall] = {}
        for idx, chunk in enumerate(chunks):
            delta: ChoiceDelta = chunk.choices[0].delta

            reasoning_content = delta.reasoning if hasattr(delta, "reasoning") else None

            if not (delta.tool_calls or delta.content or reasoning_content):
                logger.trace(
                    "Got empty chunk (no content, reasoning content, nor tool calls): %s",
                    chunk,
                )
                continue

            if reasoning_content:
                logger.trace(
                    'Got chunk with reasoning content: "%s"', reasoning_content
                )
                reasoning_chunks.append(reasoning_content)
                continue

            if delta.content:
                logger.trace('Got chunk with content: "%s"', delta.content)
                content_chunks.append(delta.content)
                continue

            for tool_delta in delta.tool_calls:
                if tool_delta.index not in tool_calls:
                    logger.debug("Processing new tool call index=%d", tool_delta.index)
                    tool_calls[tool_delta.index] = ToolCall(
                        index=tool_delta.index,
                    )

                tool_call = tool_calls[tool_delta.index]
                if tool_delta.id:
                    tool_call.id = tool_delta.id
                if tool_delta.function.name:
                    tool_call.name = tool_delta.function.name
                if tool_delta.function.arguments:
                    logger.trace(
                        "Got argument chunk for tool_call index=%d, id=%s, name=%s: %s",
                        tool_call.index,
                        tool_call.id,
                        tool_call.name,
                        tool_delta.function.arguments,
                    )
                    tool_call.args_chunks.append(tool_delta.function.arguments)

        return (
            "".join(content_chunks).strip(),
            "".join(reasoning_chunks).strip(),
            list(tool_calls.values()),
        )

    def _confirm_tool_call(
        self,
        msg: str,
        tool_call: ToolCall,
        tool: Tool,
    ) -> bool:
        self.live.stop()
        markdown = self._get_markdown(msg)
        self.console.print(markdown)

        if not tool.requires_confirmation:
            logger.info("No confirmation required")
            self.live.start()
            return True
        elif self.get_yolo_mode(tool.name):
            logger.info("YOLO mode enabled for %s, skipping confirmation.", tool.name)
            self.live.start()
            return True

        updated_args_str: str | None = None
        result = ""
        while result.lower() not in ("y", "n"):
            result = choice(
                FormattedText([("bold", "⮕ Confirm?")]),
                choices=("y", "n", "e") if tool.editable_tool_args else ("y", "n"),
                default="n",
            )

            if result.lower() != "e":
                break

            # user requested an edit
            updated_args: dict[str, str] = {}
            assert tool_call.args_dict
            for key, value in tool_call.args_dict.items():
                updated_value = self._input(
                    value if key not in updated_args else updated_args[key],
                    prompt=f"Enter new value for {key}: ",
                )
                updated_args[key] = updated_value

            updated_args_str = json.dumps(updated_args, indent=2)
            try:
                # updated args sanity check
                json.loads(updated_args_str)
            except json.JSONDecodeError:
                self.live.console.print("Invalid JSON.", style="error")

                continue

            for key, new_value in updated_args.items():
                logger.info(
                    "User override for tool arg arg %s key=%s value=%s",
                    tool_call.name,
                    key,
                    new_value,
                )
        self.live.start()

        logger.info("Got user input: %s", result)
        confirmed = result.lower() == "y"
        if confirmed and updated_args_str:
            # hack: we store chunks and args is a property
            tool_call.args_chunks = list(updated_args_str)
            for saved_tool_call in self.messages[-1]["tool_calls"]:
                if saved_tool_call["id"] != tool_call.id:
                    continue

                saved_tool_call["function"]["arguments"] = updated_args_str
                break

        return confirmed

    def _execute_tool_call(self, tool_call: ToolCall) -> str:
        try:
            assert tool_call.name is not None
            tool = registry[tool_call.name]
        except KeyError:
            logger.error(f"Invalid tool, {tool_call.name=}")
            return "[INVALID TOOL NAME]"

        if tool_call.args_dict is None:
            self._maybe_debug()
            logger.error(
                "Invalid tool call arguments, ignoring tool call %s", tool_call.args
            )
            return "[INVALID TOOL CALL ARGUMENTS]"

        msg = tool.format_tool_call(tool_call.args_dict)
        self.live.update(self._get_markdown(msg))
        try:
            execute_tool_call = self._confirm_tool_call(
                msg,
                tool_call,
                tool,
            )
        except KeyboardInterrupt:
            execute_tool_call = False
            self.console.print("")

        if not execute_tool_call:
            logger.info("User did not approve tool call tool=%s", tool_call.name)

            msg = "❌ Tool call denied.\n"
            self.live.console.print(msg)

            return "[TOOL CALL INVOCATION NOT APPROVED BY USER]"

        error: str | None = None

        self.live.update(
            self.live.console.status(
                self._get_markdown(f"🔧 `{tool_call.name}` running..."),
                spinner="star",
                spinner_style="tool",
            )
        )
        try:
            result = tool(**tool_call.args_dict)
        except KeyboardInterrupt:
            logger.info(
                "Tool call invocation interrupted by user, tool_name=%s", tool_call.name
            )
            error = "[TOOL CALL INVOCATION INTERRUPTED BY USER]"
            exc = None
            result = None
        except Exception as e:
            logger.exception(
                "Tool call invocation failed, tool_name=%s", tool_call.name
            )
            error = "[TOOL CALL INVOCATION FAILED]"
            result = str(e)
            exc = e
        else:
            exc = None

        if error:
            if exc:
                import traceback

                formatted_traceback = traceback.format_exception(
                    type(exc),
                    exc,
                    exc.__traceback__.tb_next,  # skip the first frame
                )
                self.live.stop()
                self._print_markdown(f"\n```\n{''.join(formatted_traceback)}```")
                self._maybe_debug()
            self._print_markdown(error, style="error")
            if result:
                self._print_markdown(f"```\n{result}\n```")

            return error

        if result:
            logger.debug("tool call result=%s", result)
        else:
            logger.error(
                "tool %s returned nothing",
                tool_call.name,
            )
            result = "[tool call result is empty]"

        if tool.show_results:
            md = self._get_markdown(f"🔧 `{tool_call.name}` {result}")
            self.live.update(md)
            self.live.console.print(md)

        return result

    def _execute_tool_calls(self, tool_calls: list[ToolCall]) -> list[dict[str, str]]:
        results: list[dict[str, str]] = []
        for tool_call in tool_calls:
            assert tool_call.name and tool_call.id

            logger.info("Starting execution tool_call=%s", tool_call.name)
            result = self._execute_tool_call(tool_call)
            results.append(
                {
                    "role": "tool",
                    "name": tool_call.name,
                    "tool_call_id": tool_call.id,
                    "content": result,
                }
            )

        return results

    def _update_messages(
        self,
        content: str | None = None,
        tool_calls: list[ToolCall] | None = None,
        role: str = "assistant",
    ):
        if role != "assistant":
            raise ValueError("Can only use _update_messages with assistant role")

        message: dict[str, str | list[dict]] = {
            "role": "assistant",
        }
        if content:
            message["content"] = content

        if tool_calls:
            _tool_calls: list[dict] = []
            for tool_call in tool_calls:
                logger.debug(
                    "Adding tool call %s (%s) to conversation",
                    tool_call.name,
                    tool_call.id,
                )

                _tool_calls.append(
                    {
                        "type": "function",
                        "id": tool_call.id,
                        "function": {
                            "name": tool_call.name,
                            "arguments": tool_call.args,
                        },
                    }
                )
            message["tool_calls"] = _tool_calls

        logger.debug("Updated messages with msg=%s", message)
        self._messages.append(message)

    def _handle_interrupted_streaming(self) -> tuple[str, str, list[ToolCall]]:
        logger.info("request interrupted")
        message: str | None = None
        partial_content, reasoning_content, interrupted_tool_calls = (
            self._reassemble_chunks(clear=True)
        )
        if interrupted_tool_calls:
            names = ", ".join(tool.name for tool in interrupted_tool_calls if tool.name)
            interrupt_message = (
                f"[TOOL CALL GENERATION INTERRUPTED BY USER, TOOLS: {names}]"
            )

            for status in self._tool_call_statuses.values():
                status.stop()
            self._tool_call_statuses.clear()
        else:
            interrupt_message = "[GENERATION INTERRUPTED BY USER]"

        message = (
            (partial_content + "\n") if partial_content else ""
        ) + interrupt_message

        if reasoning_content and self._show_reasoning:
            self.live.console.print(
                self._get_markdown(self._format_reasoning_content(reasoning_content)),
            )

        if partial_content:
            self.live.console.print(
                self.response_start,
                self._get_markdown(partial_content),
            )
            logger.debug("Partial content: %s", partial_content)

        if interrupted_tool_calls:
            logger.info(
                "Interrupted generation for tool calls: %s",
                ", ".join(tool.name for tool in interrupted_tool_calls if tool.name),
            )

        self.live.console.print(interrupt_message, style="error")
        self.live.console.print(self.help_text.splitlines()[0], style="system")
        self._update_messages(content=message)

        return partial_content, reasoning_content, interrupted_tool_calls

    def _stream_chunks_with_status_update(
        self,
    ) -> tuple[
        Markdown,  # content
        str,  # reasoning content
        dict[str, int | float],  # timings, see below for keys
        list[ToolCall],  # tool calls
    ]:
        logger.info("Starting request chunk streaming")
        finish_reason: str | None = None
        tool_calls: list[ToolCall] = []
        text_so_far: str = ""
        md: Markdown = self._get_markdown(self.response_start)
        current_tool_call_index: int | None = None
        chunk: ChatCompletionChunk | None = None
        timings: dict[str, float | int] = {}
        for chunk in self.client.chat.completions.create(
            model=self.model.id,
            messages=self.messages,
            # temperature=0.7, # use the server's default
            stream=True,
            # TODO: handle mechanism to disable tool calling on request
            tools=get_tools(os.getcwd()) if True else [],
            timeout=httpx.Timeout(5 * 60, connect=5),
            tool_choice="auto",
            reasoning_effort=self._reasoning_effort,
        ):
            self._chunks.append(chunk)

            # FIXME currently hardcoded to only handle the first choice
            choice = chunk.choices[0]
            finish_reason = choice.finish_reason
            logger.debug("Got delta: %s", choice.delta)

            current_tool_call_index = self._handle_tool_call_chunk(
                choice.delta,
                current_tool_call_index,
            )

            if finish_reason:
                logger.info(f"Got {finish_reason=}")

            text_so_far, reasoning_content, tool_calls = self._reassemble_chunks(
                clear=finish_reason is not None
            )

            if not (reasoning_content or text_so_far):
                logger.debug("No text or reasoning content, continuing")
                continue

            # rich doesn't format markdown correctly when it starts with "`",
            # so we add a newline at the start which fixes the issue.
            if text_so_far.startswith("`"):
                text_so_far = "\n" + text_so_far

            md = self._get_markdown(f"{self.response_start}{text_so_far}")

            if reasoning_content:
                assert self._status

                status_text = self._status.renderable.text.markup  # type: ignore[union-attr]

                if not text_so_far and "Thinking" not in status_text:
                    self._status.update("Thinking...", spinner="bounce")
                elif text_so_far and status_text == "Thinking...":
                    self._status.update(
                        "Generating...",
                        spinner="dots",  # default
                    )

                if self._show_reasoning:
                    self.live.update(
                        self._get_markdown(
                            f"{self._format_reasoning_content(reasoning_content)}\n{self.response_start}{text_so_far}"
                        )
                    )
                    continue

            if text_so_far:
                self.live.update(md)

        logger.info("Ended request chunk streaming")
        if self._tool_call_statuses:
            logger.debug("Cleared tool call statuses")
            for status in self._tool_call_statuses.values():
                status.stop()
            self._tool_call_statuses.clear()

        if hasattr(chunk, "timings"):
            # llama.cpp
            # timings = {
            #  'predicted_ms': 749.572, 'predicted_n': 11, 'predicted_per_second': 14.675041223524891, 'predicted_per_token_ms': 68.14290909090909,
            #  'prompt_ms': 2100.835, 'prompt_n': 170, 'prompt_per_second': 80.92020553732206, 'prompt_per_token_ms': 12.357852941176471
            # }
            timings = chunk.timings
        elif hasattr(chunk, "usage") and chunk.usage:
            # Groq API returns timings (does OpenAI do this too?)
            # usage = {
            #   'completion_time': 0.154472667, 'completion_tokens': 46, 'prompt_time': 0.027995019, 'prompt_tokens': 1252,
            #   'prompt_tokens_details': {'cached_tokens': 1024},
            #   'queue_time': 0.036539782, 'total_time': 0.182467686, 'total_tokens': 1298
            # }
            usage: CompletionUsage = chunk.usage
            timings = {
                "predicted_ms": usage.completion_time * 1000,
                "predicted_n": usage.completion_tokens,
                "predicted_per_second": usage.completion_tokens
                / (usage.completion_time),
                "prompt_ms": usage.prompt_time * 1000,
                "prompt_n": usage.prompt_tokens,
                "prompt_per_second": usage.prompt_tokens / usage.prompt_time,
                "cache_n": usage.model_extra.get("prompt_tokens_details", {}).get(
                    "cached_tokens",
                    0,
                ),
            }
        else:
            logger.info("Timings not available")
            # timings is only defined for llama.cpp server and groq
            # timings are not returned by llama.cpp for tool calls
            timings = {}

        logger.info("got finish_reason=%s", finish_reason)
        self._chunks[:] = []  # FIXME: should not be here?

        return (
            md,
            reasoning_content,
            timings,
            tool_calls,
        )

    def _format_reasoning_content(self, reasoning_content: str) -> str:
        """indent reasoning content so that it looks like a markdown quote"""
        reasoning_formatted = textwrap.indent(
            reasoning_content,
            prefix="    ",
        )

        return reasoning_formatted

    def _process(self, prompt: str | None) -> list[ToolCall]:
        if prompt is not None:
            self._messages.append(
                {
                    "role": "user",
                    "content": prompt,
                }
            )

        self.live.update(self.response_start)
        with self.live:
            tool_calls: list[ToolCall] = []
            try:
                with self.live.console.status("Querying...") as self._status:
                    md, reasoning_content, timings, tool_calls = (
                        self._stream_chunks_with_status_update()
                    )
            except KeyboardInterrupt:
                partial_content, reasoning_content, interrupted_tool_calls = (
                    self._handle_interrupted_streaming()
                )
                return tool_calls
            except BadRequestError as exc:
                self._handle_bad_request(exc)
                raise BadRequestException
            except httpx.HTTPStatusError as exc:
                self.live.stop()
                self._maybe_debug()
                if exc.response.status_code >= 500:
                    self.console.print(
                        "Unexpected server error. Please try again later.",
                        style="error",
                    )
                else:
                    self.console.print(
                        (
                            "Bad request. Please report an issue on https://git.decapod.one/brethil/aicheat/issues\n"
                            + str(exc)
                        ),
                        style="error",
                    )
                return []
            except InternalServerError:
                self.live.stop()
                self._maybe_debug()
                self.console.print(
                    "Unexpected server error. Please try again later.",
                    style="error",
                )
                return []
            except Exception as exc:
                self.live.stop()
                self._maybe_debug()
                self.console.print(f"Unexpected error: {exc}", style="error")
                self.console.print(self.help_text, style="system")
                logger.exception("Unexpected exception while processing prompt")
                raise UnexpectedError

        content = md.markup.lstrip(self.response_start)
        assert content or tool_calls or reasoning_content
        if reasoning_content and self._show_reasoning:
            self._print_markdown(
                self._format_reasoning_content(reasoning_content),
            )
        if content:
            self.console.print(md)

        self._update_messages(content, tool_calls)
        self._chunks[:] = []

        if self.print_timings and timings:
            prompt_s = timings["prompt_ms"] / 1000
            predicted_s = timings["predicted_ms"] / 1000
            prompt_tokens = timings["prompt_n"]
            cached_tokens = timings["cache_n"]
            predicted_tokens = timings["predicted_n"]
            self.console.print(
                f"prompt={prompt_s:.2f}s, {prompt_tokens / prompt_s:.1f} tok/s ({prompt_tokens}, cached={cached_tokens}),",
                f"predicted={predicted_s:.2f}s, {predicted_tokens / predicted_s:.1f} tok/s ({predicted_tokens})",
            )
        elif self.print_timings:
            self.console.print(
                "Timings enabled but not available from the server", style="system"
            )

        if tool_calls:
            logger.info(
                "Got tool calls: %s", [tool_call.name for tool_call in tool_calls]
            )
        return tool_calls

    def _handle_bad_request(self, exc: BadRequestError) -> None:
        data = exc.response.json()

        error_message = data["error"]["message"]
        if all(
            phrase in error_message
            for phrase in ("reasoning_effort", "Input should be")
        ):
            # most likely reasoning effort is set to a wrong value
            from .chat_utils import extract_json_from_vllm_error  # assuming vLLM

            try:
                error_json = extract_json_from_vllm_error(error_message)
            except Exception as exc:
                self._print_markdown(
                    f"**Failed to query server**. Error:\n```\n{error_message}\n```"
                )
                return None

            input_value = error_json.get("input", None)
            actual_error = error_json.get("msg", None)
            if input_value and actual_error:
                self._print_markdown(
                    f"**Error:** Reasoning effort is set to `{error_json['input']}`, {error_json['msg']}",
                    style="error",
                )
            else:
                self._print_markdown(
                    f"**Error:** Reasoning effort set to an invalid value: `{self.get_reasoning_effort()}`"
                )
            return

        self._print_markdown(
            "**Error:** Sent a bad request to the server, removing the last message.",
            style="error",
        )
        self._print_markdown(f"**Error:\n```\n{error_message}\n```")
        self._messages.pop(-1)

    def get_show_reasoning(self) -> bool:
        """Returns true if reasoning content is shown"""
        return self._show_reasoning

    def show_reasoning(self, enabled: bool | None = None) -> bool:
        """Sets/toggles the showing reasoning content"""
        if enabled is None:
            self._show_reasoning = not self._show_reasoning
        else:
            self._show_reasoning = enabled
        logger.debug("Show reasoning: %s", self._show_reasoning)
        return self._show_reasoning

    def get_reasoning_effort(self) -> ReasoningEffort:
        """Gets reasoning effort"""
        logger.debug("Reasoning effort: %s", self._reasoning_effort)
        return self._reasoning_effort

    def set_reasoning_effort(self, effort: ReasoningEffort) -> None:
        """Sets/toggles the showing reasoning content"""
        self._reasoning_effort = effort
        logger.debug("Set reasoning effort to: %s", self._reasoning_effort)

    def _reset_yolo_mode(self) -> None:
        self._yolo_mode.clear()
        self._yolo_mode["_default"] = False

    def get_yolo_mode_status(self) -> dict[str, bool]:
        return {
            "default": self._yolo_mode["_default"],
            **{
                tool_name: enabled
                for tool_name, enabled in self._yolo_mode.items()
                if tool_name != "_default"
            },
        }

    def get_yolo_mode(
        self,
        tool_name: str | None = None,
    ) -> bool:
        default = self._yolo_mode.get("_default", False)
        status = self._yolo_mode.get(tool_name, default)  # type: ignore
        status_str = "enabled" if status else "disabled"

        if tool_name:
            logger.debug("YOLO mode for %s %s", tool_name, status_str)
        else:
            logger.debug("YOLO mode %s", status_str)

        return status

    def set_yolo_mode(
        self,
        status: bool | None = None,
        tool_name: str | None = None,
    ) -> None:
        current_default = self._yolo_mode.get("_default")
        current_value = self._yolo_mode.get(tool_name, current_default)  # type: ignore
        new_value = status if status is not None else not current_value

        status_str = "enabled" if new_value else "disabled"
        if tool_name:
            self._yolo_mode[tool_name] = new_value
            logger.info("Set YOLO mode %s for tool %s", status_str, tool_name)
            return

        self._yolo_mode["_default"] = new_value

        logger.info("Set YOLO mode default %s", status_str)

    def toggle_multiline(
        self, prompt: str = "", skip_input: bool = False
    ) -> str | None:
        self._multiline = not self._multiline

        enabled_text = "enabled. Use `ctrl-j` to submit, ctrl-c to reset mode."
        self.console.print(
            "# Multiline mode is now",
            enabled_text if self._multiline else "disabled.",
            style="system",
        )
        if not prompt:
            return None

        if self._multiline:
            return self._input_multiline(prompt)

        return prompt

    def _parse_prompt_and_commands(
        self, prompt: str | None
    ) -> tuple[str | None, CommandHandler | None]:
        """returns parsed prompt and/or commands"""
        if not prompt:
            return None, None

        if not any(prompt.startswith(prefix) for prefix in get_command_prefixes()):
            return prompt, None

        if command := match_command(prompt):
            return command.function(self, prompt), command

        self.console.print(f"Unknown command={prompt}", style="error")
        return None, None

    def _maybe_debug(self, arg: str = "") -> None:
        if not self._debug:
            return

        import inspect
        import pdb

        if self._status:
            self._status.stop()
        if self.console._live_stack:
            for live_obj in self.console._live_stack:
                live_obj.stop()
        for status in self._tool_call_statuses.values():
            status.stop()

        try:
            pdb.post_mortem()
        except (
            AttributeError,  # pdbpp: not handling an exception
            ValueError,  # No exception: sys.last_exc is not defined, fall back to set trace
        ):
            pdb_ = pdb.Pdb()
            # start one frame above
            curframe = inspect.currentframe()
            assert curframe
            pdb_.set_trace(curframe.f_back)

    def _handle_url_fragment(self, url: str, prompt: str | None) -> str:
        self._print_markdown(f"Retrieving content from {url=}")

        response = httpx.get(url)
        response.raise_for_status()

        try:
            text = response.content.decode()
        except UnicodeDecodeError:
            raise ValueError(
                f"Invalid file at {url=}, is it a binary file? (image or other?)"
            )

        return (f"{prompt}\n" if prompt else "") + textwrap.dedent(
            f"""
            Contents of {url=}:

            ```
            {textwrap.indent(text, prefix="            ")}
            ```
            """
        )

    def _handle_file_fragment(self, path: Path, prompt: str | None) -> str | None:
        if path.suffix in (".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff"):
            return self._handle_image_fragment(path, prompt)

        try:
            with path.open("r") as fh:
                text = fh.read()
        except UnicodeDecodeError:
            raise ValueError(f"Invalid file at {path=}, is it a binary file?")

        return (f"{prompt}\n" if prompt else "") + textwrap.dedent(
            f"""
            Contents of file at `path={path.as_posix()}`:

            ```
            {textwrap.indent(text, prefix="            ")}
            ```
            """
        )

    def _handle_image_fragment(self, path: Path, prompt: str | None) -> None:
        """This modifies self._messages including the given image into the context"""
        with path.open("rb") as fh:
            base64_image_str = base64.encodebytes(fh.read()).decode()

        default_prompt = "Here is an image"
        self._messages.append(
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt or default_prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{base64_image_str}"
                        },
                    },
                ],
            }
        )
        return None

    def _start_loop(self, prompt: str | None) -> None:
        command: CommandHandler | None = None
        tool_calls: list[ToolCall] = []
        if not prompt:
            self.console.print(
                self.help_text,
                style="system",
            )

        self.live = Live(
            self.response_start,
            transient=True,
            console=self.console,
            vertical_overflow="visible",
            # refresh_per_second=0.1,
        )
        hold: bool = False
        while True:
            if (
                not (tool_calls or prompt) and self.messages[-1]["role"] != "user"
            ) or hold:
                prompt, command = self._parse_prompt_and_commands(self.get_input())
                if hold and (prompt or command):
                    hold = False

            if (
                not (command or prompt or tool_calls)
                and self.messages[-1]["role"] != "user"
            ):
                continue

            if command and not prompt and self.messages[-1]["role"] != "user":
                command = None
                continue

            if tool_calls:
                tool_calls_results = self._execute_tool_calls(tool_calls)
                self._messages.extend(tool_calls_results)

            try:
                tool_calls = self._process(prompt=prompt)
            except KeyboardInterrupt:
                tool_calls = []
                self._maybe_debug()
                continue
            except (BadRequestException, UnexpectedError):
                hold = True
                tool_calls = []
                continue
            except Exception as exc:
                if not self._debug:
                    raise

                self.console.print(
                    f"# Caught exception [red]{exc.__class__.__name__}: {exc}[/red], entering debugging mode (/debug is on)",
                    style="system",
                )
                if choice("Enter debug?", choices=("y", "n"), default="n") == "y":
                    self._maybe_debug()
            else:
                prompt = None

    def start(
        self,
        initial_prompt: str | None = None,
        model: str | None = os.getenv("AICHEAT_MODEL"),
    ):
        selected_model = model or self.config.model
        self.model = (
            self._validate_model(selected_model)
            if selected_model or self
            else self._select_model()
        )

        assert self.config.models_config is not None

        if model_config := self.config.models_config.get(self.model.id):
            # get values from config with default fallbacks
            self.show_reasoning(
                model_config.get(
                    "show_reasoning",
                    ModelConfig.show_reasoning,
                )
            )
            self.set_reasoning_effort(
                model_config.get(
                    "reasoning_effort",
                    ModelConfig.reasoning_effort,
                )
            )
        else:
            # set defaults
            model_config = ModelConfig(
                show_reasoning=self.get_show_reasoning(),
                reasoning_effort=self.get_reasoning_effort(),
            )
            self.config.models_config[self.model.id] = model_config

        self._maybe_load_agents_files()
        self._memory = self._load_memory()

        try:
            self._start_loop(prompt=initial_prompt)
        except Exception:
            if not self._debug:
                self.console.print_exception()
                sys.exit(1)

            import pdb

            pdb.pm()


def main():
    from .cli import parse_args

    args = parse_args(sys.argv[1:])

    client = OpenAI(
        base_url=args.host,
        api_key=args.api_key,
    )

    conversation = Conversation(
        client=client,
        config=config,
        debug=args.debug,
        load_agent_files=not args.no_agent_files,
    )

    if args.show_reasoning is not None:
        conversation.show_reasoning(args.show_reasoning)
    if args.reasoning_effort is not None:
        conversation.set_reasoning_effort(args.reasoning_effort)
    if args.no_confirm:
        conversation.set_yolo_mode(True)
    if args.no_tools:
        for tool in registry.values():
            tool.enabled = False

    try:
        conversation.start(
            initial_prompt=args.prompt,
            model=args.model,
        )
    except KeyboardInterrupt:
        conversation.console.print("Interrupted, quitting.", style="error")
        sys.exit(1)
    except Exception:
        if conversation._debug:
            import pdb

            pdb.pm()
        else:
            raise
