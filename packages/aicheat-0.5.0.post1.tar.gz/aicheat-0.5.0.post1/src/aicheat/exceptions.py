class BadRequestException(Exception):
    """raised when the Conversation encounters a bad request from the server"""


class UnexpectedError(Exception):
    """raised when the Conversation encounters an unexpected error"""
