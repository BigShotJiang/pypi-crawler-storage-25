from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import os

if TYPE_CHECKING:
    from logging import Logger

BASE_FORMAT = "[%(levelname)s][%(name)s:%(funcName)s] "
MESSAGE_FORMAT = "%(message)s"
TRACE_LEVEL = 5
logging.addLevelName(TRACE_LEVEL, "TRACE")


def trace(self, message, *args, **kwargs):
    if self.isEnabledFor(TRACE_LEVEL):
        self._log(TRACE_LEVEL, message, *args, **kwargs)


logging.Logger.trace = trace  # type: ignore


def getLogger(name: str) -> Logger:
    formatter = logging.Formatter(f"{BASE_FORMAT}{MESSAGE_FORMAT}")

    handler: logging.FileHandler | logging.StreamHandler
    if name != "config":
        from .config import config  # lazy import to avoid circular imports issues

        handler = logging.FileHandler(filename=config.logfile)
    else:
        handler = logging.StreamHandler()

    handler.setFormatter(formatter)

    logger = logging.getLogger(name)
    logger.addHandler(handler)

    debug = os.getenv("AICHEAT_DEBUG", "").lower()
    trace = os.getenv("AICHEAT_TRACE", "").lower()
    if trace in ("1", "true"):
        loglevel = TRACE_LEVEL
    else:
        loglevel = logging.DEBUG if debug in ("1", "true") else logging.INFO

    logger.setLevel(loglevel)

    return logger
