from pathlib import Path


prompts = {
    file.stem: file.read_text()
    for file in Path(__file__).parent.iterdir()
    if file.suffix == ".md"
}


def __getattr__(name: str) -> str:
    return prompts[name]


def get_available_prompts() -> str:
    return list(prompts.keys())


__all__ = [
    "get_available_prompts",
    *list(prompts.keys()),
]
