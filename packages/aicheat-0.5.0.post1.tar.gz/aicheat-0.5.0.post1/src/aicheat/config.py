from __future__ import annotations
from datetime import datetime

from dataclasses import dataclass
import importlib
from functools import cached_property
from pathlib import Path
import tomlkit
from dataclasses import asdict

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .chat import Conversation

CONFIG_BASE = base = Path.home() / ".config/aicheat"
CONFIG_BASE_DATA = Path.home() / ".local/share/aicheat"


@dataclass
class ModelConfig:
    show_reasoning: bool = False
    reasoning_effort: str = "none"


@dataclass
class Config:
    base: Path = CONFIG_BASE
    base_data: Path = CONFIG_BASE_DATA

    model: str | None = None
    models_config: dict[str, ModelConfig] | None = None

    @cached_property
    def logfile(self) -> Path:
        return self.base_data / "aicheat.log"

    @property
    def config_file(self) -> Path:
        return self.base / "config.toml"

    @cached_property
    def chat_history_path(self) -> Path:
        # lazy import to avoid circular import issues
        from .logger import getLogger

        logger = getLogger(__name__)

        cwd = Path.cwd()

        try:
            path = cwd.relative_to(Path.home())
        except ValueError:
            path = cwd

        filename = path.as_posix().replace("/", "--")

        chat_history_file_path = self.base_data / f"{filename}.chatlog"
        logger.info(
            "Chat history file path: %s",
            chat_history_file_path.relative_to(Path.home()),
        )

        return chat_history_file_path

    def __post_init__(self) -> None:
        self.base.mkdir(exist_ok=True, parents=True)
        self.base_data.mkdir(exist_ok=True, parents=True)

    def init(self):
        self.read()

    def _read(self) -> None:
        from aicheat.tools import registry

        if not self.config_file.exists():
            self.save()
            return self._read()

        with self.config_file.open() as fh:
            config = tomlkit.load(fh)

        for name, enabled in config["tools"].items():  # type: ignore[union-attr]
            if name not in registry:
                import warnings

                warnings.warn(
                    f"tool {name} is in {self.config_file.relative_to(Path.home()).as_posix()},"
                    " but it's not in the registry. Consider updating your configuration.",
                    stacklevel=2,
                )
                continue

            if isinstance(enabled, bool):
                if "git" in name:
                    import warnings

                    warnings.warn(
                        f"tool {name} has a boolean value {enabled=}. Update your config with /config save to switch to dynamic activation",
                        stacklevel=2,
                    )
                    continue
                registry[name].enabled = enabled
            elif isinstance(enabled, str):
                module_name, function_name = enabled.rsplit(".", maxsplit=1)

                module = importlib.import_module(module_name)
                enabled_function = getattr(module, function_name)
                registry[name].enabled = enabled_function
            else:
                import warnings

                warnings.warn(
                    f"tool {name} has {enabled=}, which is invalid. It should be a string (import path) or a bool: ignoring",
                    stacklevel=2,
                )

        models = config.get("models")
        if models is None:
            self.models_config = {}
            self.save()
            return

        self.model = models.pop("active_model", None)
        self.models_config: dict[str, ModelConfig] = {}

        for name, modelconfig in models.items():
            show_reasoning = modelconfig.get(
                "show_reasoning",
                ModelConfig.show_reasoning,
            )
            reasoning_effort = modelconfig.get(
                "reasoning_effort",
                ModelConfig.reasoning_effort,
            )
            self.models_config[name] = asdict(
                ModelConfig(
                    show_reasoning,
                    reasoning_effort,
                )
            )

        # config restored

    def read(self) -> None:
        try:
            self._read()
        except Exception as exc:
            import pdb

            pdb.pm()
            breakpoint()
            import warnings

            ts = datetime.now()

            name = self.config_file.name + f".broken_{ts.isoformat(timespec='minutes')}"

            warnings.warn(
                f"Failed to read config from {self.config_file}, renamed to {name} and created a new config. Exception: {exc}",
                stacklevel=2,
            )
            self.config_file.move(
                self.config_file.parent / name,
            )
            return self.read()

    def save(self, conversation: Conversation | None = None) -> None:
        from aicheat.tools import registry

        tools_config: dict[str, bool | str] = {}
        for name, tool in registry.items():
            if isinstance(tool.enabled, bool):
                tools_config[name] = tool.enabled
            elif callable(tool.enabled):
                import_path = tool.enabled.__module__ + "." + tool.enabled.__qualname__

                tools_config[name] = import_path
            else:
                raise ValueError(
                    f"Unsupported value for {name} for tool.enabled={tool.enabled}"
                )

        current_config = {
            "appearance": {},
            "tools": tools_config,
            "models": {},
        }

        if conversation:
            current_config["appearance"]["theme"] = conversation.theme

            models = {}

            assert conversation.model.id

            models["active_model"] = conversation.model.id

            if conversation.config and conversation.config.models_config:
                models.update(conversation.config.models_config)

            models[self.model] = asdict(
                ModelConfig(
                    conversation.get_show_reasoning(),
                    reasoning_effort=conversation.get_reasoning_effort(),
                )
            )

            current_config["models"] = models

        with self.config_file.open("w") as fh:
            tomlkit.dump(current_config, fh)


config = Config()
