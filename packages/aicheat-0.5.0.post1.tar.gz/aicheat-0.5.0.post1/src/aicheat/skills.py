from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import re

from .logger import getLogger

from .utils import parse_frontmatter


logger = getLogger(__name__)


@dataclass(frozen=True)
class Skill:
    name: str
    description: str
    content: str
    path: Path
    metadata: dict[str, Any]

    def __hash__(self) -> int:
        return hash(self.path)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Skill):
            return NotImplemented
        return self.path == other.path

    @classmethod
    def from_file(cls, path: Path) -> Skill:
        """Parse a skill markdown file and extract metadata"""
        content = path.read_text()

        # Default values
        name: str = ""
        description = ""
        metadata: dict[str, str] = {}

        metadata, content = parse_frontmatter(path.read_text())
        name = metadata.get("name", name)
        description = metadata.get("description", description)

        if not name:
            # Use the name in the first heading  as title
            name_match = re.search(r"^#\s+(.+)$", content, re.MULTILINE)
            if name_match:
                name = name_match.group(1).strip()

        if not description:
            # Find the text after the first heading until the next heading or end of file
            desc_match = re.search(
                rf"^#\s+{re.escape(name)}\s*\n+(.*?)(?:\n#|\Z)",
                content,
                re.DOTALL | re.MULTILINE,
            )
            if desc_match:
                description = desc_match.group(1).strip()

        return cls(
            name=name or path.stem,
            description=description,
            content=content,
            path=path,
            metadata=metadata,
        )


class SkillManager(dict[Path, Skill]):
    def has_skills(self) -> bool:
        return bool(self)

    def format_skills(self) -> str:
        skills_md = []
        for skill_path, skill in self.items():
            skills_md.append(skill.content)

        header = "\n# Skills definitions\nThe user has defined the following skills for you to use. Perform the actions defined in the skill definition.\n"
        skills = "\n".join(skills_md)

        return header + skills + "\n END OF SKILLS DEFINITIONS.\n"

    def _load_skill_path(self, path: Path) -> list[Path]:
        """Load all skills recursively from the given path, returns the loaded list of skills"""
        if path.is_file():
            logger.debug("Loaded skill %s from %s", path.name, path.as_posix())
            self.update(
                {
                    path.resolve(): Skill.from_file(path),
                },
            )
            return [path.resolve()]

        if not path.is_dir():
            raise ValueError(f"Unknown file type: {path.as_posix()}")

        loaded_skills = []

        for inner_path in path.iterdir():
            logger.debug("Loading skills from %s", inner_path.as_posix())
            loaded = self._load_skill_path(inner_path)
            loaded_skills.extend(loaded)

        return loaded_skills

    def load(self, paths: list[Path]) -> list[Path]:
        loaded_skills: list[Path] = []
        for skill_path in paths:
            if not skill_path.exists():
                logger.error(f"File does not exist: {skill_path}")
                continue

            loaded = self._load_skill_path(skill_path)
            loaded_skills.extend(loaded)

        return loaded_skills

    def unload(self, name_or_path: str) -> Skill | None:
        """Unloads skill by skill name, skill file basename or path

        Returns the skill that was unloaded or None
        """
        path = Path(name_or_path).resolve()
        if path.exists() and path in self:
            logger.debug("Found skill at path: %s", path.as_posix())
            return self.pop(path.resolve())

        # match skill name or skill file basename
        for path, skill in self.items():
            if any(v == name_or_path for v in (skill.name, path.name)):
                return self.pop(path)

        logger.info("Skill %s was not found", name_or_path)
        return None

    def unload_all(self) -> None:
        self.clear()

    def values(self) -> list[Skill]:
        """Return a list of all skills"""
        return list(super().values())


manager = SkillManager()
