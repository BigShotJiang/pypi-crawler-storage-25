"""Command-line interface for aicheat using argparse.

This module handles parsing of command-line arguments and provides
configuration precedence: CLI > ENV > config file > defaults.
"""

from __future__ import annotations

import argparse
import os
import sys
import textwrap


def create_parser() -> argparse.ArgumentParser:
    """Create and configure the argument parser.

    Returns:
        Configured ArgumentParser instance
    """
    parser = argparse.ArgumentParser(
        prog="aicheat",
        description="A CLI-based AI coding assistant",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent(
            """
            Examples:

              aicheat "Explain this code"                 # Pass prompt as argument
              aicheat --no-confirm                        # Enable yolo mode (skip confirmations)
              aicheat --model Qwen/Qwen3.5-397B-A17B-FP8  # Use specific model
              aicheat --debug                             # Enable debug mode
              aicheat --host http://localhost:8000        # set custom endpoint

            Configuration precedence:
              CLI flags > Environment variables > Defaults
            """
        ).strip(),
    )

    # Core flags
    parser.add_argument(
        "--no-confirm",
        action="store_true",
        dest="no_confirm",
        default=os.getenv("AICHEAT_NO_CONFIRM", False),
        help="Enable yolo mode: skip confirmation prompts for tool calls",
    )

    # Connection/Model flags
    parser.add_argument(
        "--host",
        type=str,
        default=os.getenv("AICHEAT_HOST"),
        help="OpenAI API-compatible host or URL (env: AICHEAT_HOST)",
    )

    parser.add_argument(
        "--model",
        type=str,
        default=os.getenv("AICHEAT_MODEL"),
        help="Model to use (env: AICHEAT_MODEL)",
    )

    parser.add_argument(
        "--api-key",
        type=str,
        default=os.getenv("OPENAI_API_KEY"),
        help="API key (env: OPENAI_API_KEY)",
    )

    # Behavior/Configuration flags
    parser.add_argument(
        "--debug",
        action="store_true",
        dest="debug",
        default=os.getenv("AICHEAT_DEBUG"),
        help="Enable debug mode (env: AICHEAT_DEBUG)",
    )

    # Reasoning/Output flags
    parser.add_argument(
        "--show-reasoning",
        action="store_true",
        dest="show_reasoning",
        default=os.getenv("AICHEAT_SHOW_REASONING", False),
        help="Show reasoning content from reasoning models (env: AICHEAT_SHOW_REASONING)",
    )

    parser.add_argument(
        "--reasoning-effort",
        type=str,
        choices=["none", "low", "medium", "high"],
        default=os.getenv("AICHEAT_REASONING_EFFORT", "none"),
        help="Reasoning effort level for reasoning models (env: AICHEAT_REASONING_EFFORT)",
    )

    # Tools/Skills flags
    parser.add_argument(
        "--no-tools",
        action="store_true",
        dest="no_tools",
        default=os.getenv("AICHEAT_DISABLE_TOOLS"),
        help="Disable all tools",
    )

    # Session Management flags
    parser.add_argument(
        "--no-agent-files",
        action="store_true",
        dest="no_agent_files",
        default=os.getenv("AICHEAT_NO_AGENT_FILES", False),
        help="Skip loading AGENTS.md/CLAUDE.md files",
    )

    parser.add_argument(
        "--no-memory",
        action="store_true",
        dest="no_memory",
        default=os.getenv("AICHEAT_NO_MEMORY"),
        help="Skip loading memory.md file",
    )

    # Positional argument for prompt
    parser.add_argument(
        "prompt",
        nargs="?",
        default=None,
        help="Initial prompt to send to the assistant",
    )

    return parser


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse command-line arguments.

    Args:
        argv: Command-line arguments (defaults to sys.argv[1:])

    Returns:
        Parsed arguments namespace
    """
    parser = create_parser()
    args = parser.parse_args(argv)

    # Check if host is provided, otherwise check environment variable
    if not (args.host or args.api_key):
        print(
            (
                "Error: Please set AICHEAT_HOST environment variable or use --host flag."
                "       to specify an OpenAI API-compatible host or URL."
            ),
            file=sys.stderr,
        )
        sys.exit(1)

    # Validate URL format
    if not (args.host.startswith("http://") or args.host.startswith("https://")):
        args.host = f"http://{args.host}/v1/"
    else:
        args.host = f"{args.host}/v1/"

    # Warn about non-HTTPS
    if args.host.startswith("http://"):
        import warnings

        warnings.warn(f"URL {args.host} is not https. Your data is at risk")

    return args
