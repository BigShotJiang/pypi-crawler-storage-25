import io
import sys
import textwrap
import traceback
from typing import Any

from aicheat.logger import getLogger
from aicheat.tools.core import tool

logger = getLogger(__name__)


@tool(
    requires_confirmation=True,
    editable_tool_args=True,
    message_template=textwrap.dedent(
        """
        🐍 Executing python code:
        ```python
        {code}
        ```
        """
    ).strip(),
    show_results=True,
)
def execute_python_code(code: str) -> str | None:
    """Executes the given python code in the context of globals and locals using `exec()`

    Arguments:
        - code: code block to execute

    """
    # TODO: running this code in a subinterpreter (subprocess)
    # will minimize the chances of this breaking everything
    if not code:
        return None

    globals_: dict[str, Any] = {}

    old_stdout = sys.stdout
    old_stderr = sys.stderr

    stdout = io.StringIO()
    # stderr = io.StringIO()
    sys.stdout = stdout

    # handle stdout and stderr in a single stream to preserve ordering
    # sys.stderr = stderr
    sys.stderr = stdout

    success = False
    traceback_markdown = ""
    try:
        compiled_code = compile(code, "aicheat_execute_python_code.py", mode="exec")

        if sys.version_info >= (3, 13):
            exec(compiled_code, globals=globals_, locals=globals_)
        else:
            exec(compiled_code, globals_, globals_)
    except Exception as exc:
        assert exc.__traceback__ is not None

        formatted_traceback = traceback.format_exception(
            type(exc),
            exc,
            exc.__traceback__.tb_next,  # skip the first frame, it's always `exec(...)`
        )
        traceback_markdown = textwrap.dedent(
            """
            ```
            {traceback}
            ```
            """
        ).format(traceback="".join(formatted_traceback))
    except SystemExit:
        # ignore system exit, we don't want to exit the interpreter
        logger.exception("Ignored SystemExit while exec-ing code.")
    else:
        success = True
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr

    output = stdout.getvalue().strip()
    # TODO: handle intermediate variables in locals_ ?

    output_markdown = (
        textwrap.dedent(
            """
            ```
            {output}
            ```
            """
        ).format(output=output)
        if output
        else ""
    )

    header = ("**success**" if success else "**failure**") + (
        f" with output:{output_markdown}"
        if output
        else (" (no output)" if not traceback_markdown else ": ")
    )

    ret = (
        textwrap.dedent(
            """
            {header}

            {traceback}
            """
        )
        .strip()
        .format(
            header=header,
            output=output_markdown if output else "",
            traceback=traceback_markdown,  # can be empty
        )
        .strip()
    )
    return ret
