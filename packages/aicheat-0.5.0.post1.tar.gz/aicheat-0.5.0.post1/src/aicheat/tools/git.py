import textwrap
import pygit2

from aicheat.logger import getLogger
from aicheat.tools.core import tool

import subprocess

logger = getLogger(__name__)


def in_git_repo() -> bool:
    """Check if the current working directory is inside a git repository"""
    try:
        pygit2.Repository(".")
    except pygit2.GitError:
        return False

    return True


@tool(
    message_template=" check git status",
    enabled=in_git_repo,
)
def git_status(*args, **kwargs) -> str:
    """Runs git status and returns the current status as a git diff patch"""
    repo = pygit2.Repository(".")
    patch = repo.diff(repo.head.peel().tree).patch

    return textwrap.dedent(
        f"""Here is the current git status as a diff:

        ```diff
        {patch}
        ```
        """
    ).strip()


@tool(
    message_template=" check commits since last release/tag",
    enabled=in_git_repo,
)
def git_updates(
    from_refish: str = "",
) -> str:  # TODO: rename to git_log?
    """Get a list of "author: commit message" for all commits since the last tag/release or from the given ref-ish"""
    from pygit2 import Repository

    repo = Repository(".")
    head = repo.head.peel()

    if from_refish:
        try:
            obj = repo.revparse_single(from_refish)
        except KeyError:
            return f"Couldn't find ref: {from_refish}"

        if not isinstance(obj, pygit2.Commit):
            obj = obj.peel(pygit2.Commit)

        latest_tag_commit = obj
        tag_str = from_refish
    else:
        # Get all tags and their commit objects
        tag_commits = []
        for ref_name in repo.listall_references():
            if not ref_name.startswith("refs/tags/"):
                continue

            try:
                ref = repo.lookup_reference(ref_name)
                commit = ref.peel()  # Get the commit object

                # Handle annotated tags
                if hasattr(commit, "target"):
                    commit = repo.get(commit.target)

                tag_commits.append((commit, ref_name))
            except Exception as e:
                logger.exception(f"Skipping tag {ref_name}: {e}")
                continue

        if not tag_commits:
            return "No tags found."

        # newest first
        tag_commits.sort(key=lambda x: x[0].commit_time, reverse=True)
        latest_tag_commit, tag_str = tag_commits[0]

    walker = repo.walk(head.id)
    if latest_tag_commit:
        walker.hide(latest_tag_commit.id)

    if tag_str:
        header = f"# All commits since {tag_str} ({latest_tag_commit.id})\n"
    else:
        header = f"# All commits since {latest_tag_commit.id}\n"

    return header + "\n".join(
        f"{str(commit.id)[:8]} {commit.author.name}: {commit.message.strip()}"
        for commit in walker
    )


@tool(
    message_template=" Get patch for commit_id={commit_id}",
    enabled=in_git_repo,
)
def git_show_patch(commit_id: str) -> str | None:
    """Retrieves the the diff patch for the specified commit_id"""

    repo = pygit2.Repository(".")

    try:
        commit: pygit2.Object = repo.get(commit_id)
    except ValueError as exc:
        logger.debug(f"{commit_id=} not found {exc=}")
        # no such commit
        return None

    parent = commit.parents[0]

    patch = repo.diff(parent, commit).patch

    return patch


@tool(
    message_template=" List git-tracked files",
    enabled=in_git_repo,
)
def git_list_files() -> str:
    """List all files tracked in the git repository using `git ls-files`"""
    retcode, output = subprocess.getstatusoutput("git ls-files")

    if retcode != 0:
        return ""

    return "\n".join(f"- `{file}`" for file in output.splitlines())
