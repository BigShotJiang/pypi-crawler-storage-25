import shutil
import subprocess

import httpx

from aicheat.logger import getLogger
from aicheat.tools.core import tool
from aicheat import __version__ as version

logger = getLogger(__name__)


@tool(
    requires_confirmation=False,
    enabled=False,  # wikipedia has pretty stringent search limits for bots, which makes this fail
)
def wikipedia_search(query: str) -> str | None:
    """Search wikipedia for the given query and return an extract/summary of the first result"""  # noqa: E501
    api_base = "https://en.wikipedia.org/w/api.php"
    headers = {
        "User-Agent": f"bretellochat/v{version}"  # user agent is required by wikipedia's bot policy
    }
    response = httpx.get(
        api_base,
        params={
            "action": "opensearch",
            "search": query,  # Search query
            "limit": 1,  # Return only the first result
            "namespace": 0,  # Search only articles
            "format": "json",  # Return data in JSON format
        },
        headers=headers,
    )

    # Check if the request was successful
    if not httpx.codes.is_success(response.status_code):
        logger.error("opensearch action failed, status_code=%s", response.status_code)
        return None

    data = response.json()
    try:
        titles = data[1][0]
    except IndexError:
        logger.error("No results for query")
        return None

    response = httpx.get(
        api_base,
        params={
            "action": "query",
            "prop": "extracts",  # https://www.mediawiki.org/wiki/Extension:TextExtracts#API
            "exintro": True,
            "explaintext": True,
            "redirects": 1,
            "titles": titles,
            "format": "json",
        },
        headers=headers,
    )

    if not httpx.codes.is_success(response.status_code):
        logger.error(
            "Failed to extract summary for page, status_code=%s",
            response.status_code,
        )
        return None

    data = response.json()

    try:
        extract = list(data["query"]["pages"].values())[-1]["extract"]
    except (KeyError, IndexError):
        return None

    return extract


@tool(
    requires_confirmation=False,
    show_results=True,
)
def cheat_sh_search(program_name: str) -> str | None:
    """Search cheat.sh for a cheat sheet for a unix program

    This can be useful to quickly find common commands for linux programs and/or basic
    programming languages cheat sheets.

    E.g `program_name=ping` searches for the cheat sheet for the `ping` program and so on.
    E.g `program_name=top` searches for the cheat sheet for the `top` program and so on.
    """
    if shutil.which("cht.sh"):
        # prefer using the CLI tool, since it also works offline
        result = subprocess.check_output(
            [
                "cht.sh",
                f"{program_name}?T",  # add "?T" query parameter so that no escape sequences are printed
            ]
        ).decode()
    else:
        api_base = "https://cheat.sh"
        url = httpx.URL(
            # add "?T" query parameter so that no escape sequences are printed
            f"{api_base}/{program_name}?T"
        )
        response = httpx.get(
            url,
            params=url.params,
            headers={
                "User-Agent": "curl",  # let's fake being curl, otherwise the API will return 500
            },
        )

        if not httpx.codes.is_success(response.status_code):
            logger.error("search failed, status_code=%s", response.status_code)
            return None

        result = response.content.decode()

    if any(
        not_found in result
        for not_found in (
            "* 404 NOT FOUND",
            "Unknown topic.\nDo you mean one of these topics maybe?",
        )
    ):
        logger.info("topic not found")
        return "404 topic not found"

    return f"""\n```shell\n{result}\n```"""
