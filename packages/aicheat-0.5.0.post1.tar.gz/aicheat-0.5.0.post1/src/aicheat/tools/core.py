from __future__ import annotations


import os
from collections.abc import Callable
from functools import wraps
from logging import getLogger
from typing import Any


from aicheat.types import MarkdownStr

from dataclasses import dataclass
from functools import lru_cache

logger = getLogger(__name__)
logger.setLevel("DEBUG" if os.getenv("DEBUG") else "INFO")

registry: dict[str, Tool] = {}


@dataclass
class Tool:
    """Function and its corresponding values/option to call when a tool call is invoked"""

    # function to call
    function: Callable

    # template message to inform the user about what the tool is doing
    message_template: str | Callable[[...], str] | None = None

    # True if "function" requires confirmation (can be set to a function that is evaluated)
    requires_confirmation: bool | Callable = True

    # True if arguments to the function can be edited by the user before calling the tool (implies requires_confirmation)
    editable_tool_args: bool = True

    # True if tool must show results to the user after running
    show_results: bool = True

    # Set to false if the tool should not be used (can be a callable for dynamic checks)
    enabled: bool | Callable[[], bool] = True

    @property
    def name(self) -> str:
        return self.function.__name__

    def is_enabled(self) -> bool:
        """Check if the tool is enabled (supports dynamic checks)"""
        if callable(self.enabled):
            return self.enabled()
        return self.enabled

    def format_tool_call(self, tool_call_args: dict[str, Any]) -> MarkdownStr:
        """Formats the tool call request with the given arguments as a markdown string"""
        try:
            if callable(self.message_template):
                msg = self.message_template(**tool_call_args)
            else:
                msg = self.message_template.format(**tool_call_args)  # type: ignore[union-attr]
        except (
            AttributeError,  # message_template is None
            KeyError,  # Required arguments haven't been provided
        ):
            if self.message_template:
                logger.exception(
                    "Failed to format tool call. tool name: %s, args: %s",
                    self.name,
                    tool_call_args,
                )

            formatted_args = ", ".join(f'{k}="{v}"' for k, v in tool_call_args.items())
            formatted_tool_call_message = f"{self.name}({formatted_args})"

            return f"🔧 Calling tool `{formatted_tool_call_message}`"

        return msg

    def __call__(self, *args, **kwargs) -> Any:
        __tracebackhide__ = True
        return self.function(*args, **kwargs)


@lru_cache(maxsize=10)
def get_tools(path: str) -> list[dict]:
    """Gets a list of (enabled) tools that can be sent to the OpenAI API from the tool registry"""
    functions: list[dict] = []
    for tool_name, tool in registry.items():
        if not tool.is_enabled():
            logger.debug("Ignoring disabled tool %s", tool_name)
            continue

        function = {
            "name": tool_name,
            "description": tool.function.__doc__,
            "parameters": {
                "type": "object",
                "properties": {
                    name: {"type": type_.__name__.replace("str", "string")}
                    for name, type_ in tool.function.__annotations__.items()
                    if name != "return"  # this is the return type
                },
                # "required": ["name"], # TODO: add required parts?
            },
        }

        functions.append(
            {
                "type": "function",
                "function": function,
            }
        )
    return functions


class tool:
    """decorator to add tools into the registry"""

    def __init__(
        self,
        requires_confirmation: bool | Callable[[...], bool] = False,
        show_results: bool = False,
        message_template: str | Callable[[...], str] | None = None,
        editable_tool_args: bool = False,
        enabled: bool | Callable[[], bool] = True,
    ) -> None:
        self.requires_confirmation = requires_confirmation
        self.show_results = show_results
        self.message_template = message_template
        self.editable_tool_args = editable_tool_args
        self.enabled: bool | Callable[[], bool] = enabled

        self.module: str | None = None  # set by __call__ at registration time

    def __call__(self, func: Callable) -> Callable:
        if func.__name__ in registry:
            raise KeyError(f"{func.__name__} is already defined in the tool registry")

        if not func.__doc__:
            raise ValueError(
                f"{func.__name__} doesn't have a docstring. Please define it."
            )

        get_tools.cache_clear()

        @wraps(func)
        def tool_with_logging(*args, **kwargs):
            logger.info(
                'Invoking tool=%s with args="%s" kwargs="%s"',
                func.__name__,
                args,
                kwargs,
            )
            return func(*args, **kwargs)

        registry[func.__name__] = Tool(
            function=tool_with_logging,
            message_template=self.message_template,
            requires_confirmation=self.requires_confirmation,
            show_results=self.show_results,
            editable_tool_args=self.editable_tool_args,
            enabled=self.enabled,
        )

        return tool_with_logging
