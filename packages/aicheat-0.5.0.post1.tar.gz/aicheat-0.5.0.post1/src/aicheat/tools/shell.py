import json
import io
import signal
import os
import subprocess
import textwrap
from pathlib import Path
from shutil import which

from aicheat.tools.core import tool
from aicheat.logger import getLogger


logger = getLogger(__name__)

SEARCH_TOOL_DEFAULT_PATH = "."


@tool(
    message_template=textwrap.dedent(
        """
        Reading file `{filename}`.
        """
    ),
)
def read_file(filename: str) -> str | None:
    """Read the content of the file `filename`

    Arguments:
        - filename: name of the file to read
    """
    if not os.path.exists(filename):
        return None

    with open(filename) as f:
        return f.read()


def format_write_file_call(filename: str, content: str) -> str:
    path = Path(filename)

    if not path.exists():
        match path.suffix:
            case ".sh":
                content_type = "bash"
            case ".py":
                content_type = "python"
            case ".md":
                content_type = "markdown"
            case ".c" | ".h":
                content_type = "c"
            case ".cpp" | ".hpp":
                content_type = "cpp"
            case _:
                content_type = ""
        return (
            textwrap.dedent(
                """
                Writing `{filename}`, content:
                ```{content_type}
                {content}
                ```
                """
            )
            .strip()
            .format(
                filename=filename,
                content_type=content_type,
                content=content,
            )
        )

    current_contents = path.read_text()
    import difflib

    diff_lines = list(
        difflib.unified_diff(
            current_contents.splitlines(keepends=True),
            content.splitlines(keepends=True),
            fromfile=f"a/{filename}",
            tofile=f"b/{filename}",
        )
    )
    diff = "".join(diff_lines)

    return textwrap.dedent("""
        Updating `{filename}`, diff:
        ```diff
        {content}
        ```
        """).format(filename=filename, content=diff.rstrip())


@tool(
    requires_confirmation=True,
    message_template=format_write_file_call,
)
def write_file(filename: str, content: str):
    """Write "content" to `filename`

    Arguments:
        - filename: name of the file to write
        - content: content to write

    Warning: this will delete "filename"'s contents
    if it already exists.

    """
    with open(filename, "w") as fh:
        fh.write(content)

    return f"Wrote contents to {filename}"


@tool(
    requires_confirmation=True,
    message_template="Applying patch:\n```diff\n{patch_content}\n```",
)
def apply_patch(file_to_patch: str, patch_content: str) -> str:
    """Modifies a file by applying the given git-style patch (`diff --unified`) using the `patch -p1` command

    Args:
        patch_content: content of the patch (git-style)

    Prefer this to "write_file" when possible. The patch format *has* to be compatible with the `patch -p1` format.
    """

    if not Path(file_to_patch).is_file():
        return f"Failure: file {file_to_patch} does not exist."

    patch_io = io.StringIO(patch_content)

    # Run the patch command with the -p1 option commonly used for git patches
    # Adjust -p0 or -p1 depending on how the patch was created
    proc = subprocess.Popen(
        ["patch", "-p1", "--force", file_to_patch],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    stdout, _ = proc.communicate(  # stderr is redirected to stdout above
        input=patch_io.getvalue(),
        timeout=60,  # 60s should be enough for a patch
    )
    proc.kill()

    if proc.returncode != 0:
        raise Exception(f"Failed to apply patch: {stdout}")

    return f"Patch applied cleanly: {stdout}"


@tool(
    message_template="Calling `man {program_name}`",
)
def man(program_name: str) -> str | None:
    """Retrieve man page for the given program name

    Arguments:
        - program_name: str name of the program

    """
    # NOTE: make sure that there's nothing strange in `name` since we're piping this into check_output()
    invalid_chars = ["\\", ";", "/"]
    if any(char in program_name for char in invalid_chars):
        return f"Invalid {program_name=}"

    arg = program_name.split(" ")[0]
    retcode, man_page = subprocess.getstatusoutput(
        f"man {arg}",
        # timeout=10, # FIXME: getstatusoutput doesn't allow timeouts, but we should probably use it
    )

    if retcode != 0:
        return f"command failed with return code {retcode}:\n{man_page}"

    return man_page


def format_search_call(
    pattern: str,
    path: str | None = None,
) -> str:
    if path and path != SEARCH_TOOL_DEFAULT_PATH:
        return f"🔎 Searching for pattern: `{pattern}` in `{path}`"

    return f"🔎 Searching for pattern: `{pattern}`"


@tool(
    message_template=format_search_call,
)
def search(pattern: str, path: str = SEARCH_TOOL_DEFAULT_PATH) -> str | None:
    """Search for pattern `pattern` in the working directory using `ripgrep` (with `grep` fallback)

    Arguments:
        - pattern: name of the file to read (regex)
        - path: Path to search (default: current directory).

    Multiple paths can be provided by separating them with commas: path="dir1/path1,dir2/path2"
    """
    if not pattern:
        return None

    if not path:  # guard against empty paths
        path = "."

    # make sure that quotes are escaped properly so that the pattern is used correctly
    sanitized_pattern = json.dumps(pattern)[1:-1]
    sanitized_path = json.dumps(path)[1:-1]

    if which("rg"):
        cmd = ["rg", "--vimgrep", "-e", sanitized_pattern]
    elif which("grep"):
        import warnings

        warnings.warn(
            "ripgrep is not installed, search performance will be degraded",
            stacklevel=2,
        )
        cmd = ["grep", "-R", "-e", sanitized_pattern]
    else:
        raise RuntimeError("No search tools available (tried `rg` and `grep`)")

    if sanitized_path:
        paths = sanitized_path.split(",")
        cmd.extend(paths)

    try:
        output = subprocess.check_output(cmd, text=True)
    except subprocess.CalledProcessError as exc:
        returncode = exc.returncode
        output = exc.output
    else:
        returncode = 0

    if returncode == 0:
        return output

    # search failed
    if output:
        return f"ripgrep call failed with {returncode=}:\n{output}"

    return "ripgrep search returned no matches."


@tool(
    requires_confirmation=True,
    editable_tool_args=True,
    message_template=textwrap.dedent(
        """
         Executing shell command(s):
        ```bash
        {cmd}
        ```"""
    ).strip(),
    show_results=True,
)
def execute_shell_command(cmd: str) -> str | None:
    """Executes the given shell command using bash

    Arguments:
        - cmd: command to execute

    """
    cmd = cmd.strip()
    if not cmd:
        return None

    shell_path = os.getenv("SHELL", "/bin/bash")
    proc = subprocess.Popen(  # TODO: It'd be nice to have timeouts
        [
            shell_path,
            "-il",  # force an interactive login shell, so that login shell rc files are sourced and this behaves like the user's shell
            "-c",  # execute the given command
            cmd,
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        # start_new_session=True,  # Ctrl-C is sent to the child process if start_new_session=False
    )
    try:
        output, _ = proc.communicate()
    except KeyboardInterrupt:  # only works when start_new_session=True
        proc.send_signal(signal.SIGINT)
        output, _ = proc.communicate()
        output += "[command was interrupted by user with ctrl-c]"
    finally:
        retcode = proc.returncode
        proc.terminate()

    header = "**Success**" if retcode == 0 else f"**failure** `{retcode=}`"

    if output.strip():
        ret = (
            textwrap.dedent("""
        {header}

        ```console
        {output}
        ```
        """)
            .format(header=header, output=output)
            .strip()
        )
    else:
        ret = f"{header}. No output."

    return ret.strip()


@tool(
    requires_confirmation=False,
    message_template="📁 Getting current directory...",
    show_results=False,
)
def pwd() -> str:
    """Gets the current working directory"""
    return os.getcwd()


@tool(
    requires_confirmation=False,
    message_template=" 📁 `cd {path}`",
    show_results=False,
)
def cd(path: str) -> str:
    """Sets the current working directory"""
    if not path:
        return ""

    try:
        os.chdir(path)
    except Exception as exc:
        return f"Failed to change dir: {exc}"

    return f"Changed directory to {path}"
