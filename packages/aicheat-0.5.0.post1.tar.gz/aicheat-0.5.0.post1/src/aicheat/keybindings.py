from __future__ import annotations

from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.keys import Keys
from typing import TYPE_CHECKING
from .logger import getLogger

from prompt_toolkit.filters import IsMultiline
from prompt_toolkit.key_binding.bindings.named_commands import accept_line


logger = getLogger(__name__)

if TYPE_CHECKING:
    from .chat import Conversation

bindings = KeyBindings()
_conversation: Conversation | None = None


@bindings.add(Keys.ControlV)
def _(event):
    _conversation.toggle_multiline(skip_input=True)
    accept_line(event)
    # event.current_buffer.insert_text("\n")


@bindings.add("c-j", filter=IsMultiline())
def _(event):
    accept_line(event)
    # event.current_buffer.insert_text("\n")


@bindings.add("escape", "enter", filter=IsMultiline())
def _(event):
    logger.debug("Ignoring escape enter")
    pass  # Do nothing


def register_conversation(c: Conversation) -> KeyBindings:
    global _conversation

    _conversation = c  # noqa: F841
    logger.info("Registered conversation to keybindings module")
    return bindings
