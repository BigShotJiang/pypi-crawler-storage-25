from __future__ import annotations
import ast
import json

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolCall:
    name: str | None = None
    id: str | None = None
    index: int | None = None
    args_chunks: list[str] = field(default_factory=list)

    @property
    def args_dict(self) -> dict | None:
        try:
            return json.loads(self.args)
        except json.JSONDecodeError:
            return None

    @property
    def args(self) -> str:
        return "".join(self.args_chunks)


def filter_encoded_images(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Used to clean a message list to remove b64-encoded images, mostly for user display purposes

    Here's what the part that needs to be filtered looks like

    ```json
        [
      ...
      {
        "role": "user",
        "content": [
            {"type": "text", "text": 'this is a prompt'},
            {"type": "image_url", "image_url": {"url": "data:image..."}}
        ]
      },
      ...
    ]
    ```

    """
    assert isinstance(messages, list)

    cleaned_messages: list[dict[str, Any]] = []
    for message in messages:
        if (
            "content" not in message
            or not isinstance(message["content"], list)
            or not any(el["type"] == "image_url" for el in message["content"])
        ):
            cleaned_messages.append(message)
            continue

        cleaned_contents: list[Any] = []
        for content in message["content"]:
            if content["type"] != "image_url":
                cleaned_contents.append(content)
                continue

            if not content["image_url"]["url"].startswith("data:"):
                cleaned_contents.append(content)
                continue

            content["image_url"] = "<base64-encoded image>"
            cleaned_contents.append(content)

        message["content"] = cleaned_contents

        cleaned_messages.append(message)

    return cleaned_messages


def extract_json_from_vllm_error(error_message: str) -> dict:
    """Extract the pydantic vfalidation error from a vllm error response"""
    dict_line = None
    for line in error_message.splitlines():
        stripped = line.strip()
        if stripped.startswith("{"):
            dict_line = stripped
            break

    if dict_line is None:
        raise ValueError("No dict line found")

    # Unescape any escaped single quotes (if any)
    dict_line = dict_line.replace(r"\\'", "'")
    # Convert to Python object safely
    data = ast.literal_eval(dict_line)

    # Convert tuples to lists for JSON compatibility
    def convert(obj):
        if isinstance(obj, tuple):
            return [convert(o) for o in obj]
        if isinstance(obj, list):
            return [convert(o) for o in obj]
        if isinstance(obj, dict):
            return {k: convert(v) for k, v in obj.items()}
        return obj

    return convert(data)
