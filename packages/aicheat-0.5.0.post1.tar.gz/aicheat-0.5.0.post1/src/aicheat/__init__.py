try:
    from ._version import __version__, __version_tuple__  # noqa: F401
except ImportError:
    import warnings

    warnings.warn("Couldn't get version from _version.py", stacklevel=2)
    __version__ = "0.0.0"
