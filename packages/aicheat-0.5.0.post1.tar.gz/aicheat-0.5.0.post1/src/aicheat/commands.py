from __future__ import annotations

import datetime
import inspect
import json
import os
import re
import subprocess
import textwrap
from dataclasses import dataclass
from functools import lru_cache, wraps
from logging import getLogger
from pathlib import Path
from typing import TYPE_CHECKING, Callable

from aicheat.prompts import save_command_prompt
import yaml
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.completion.filesystem import (
    Completer,
    PathCompleter,
)
from pygments.styles import get_all_styles
from rich.text import Text

from .chat_utils import filter_encoded_images
from .completions import (
    LazyCommandsCompleter,
    LazyToolsCompleter,
    LazyYoloCompleter,
    completion_filter_invisible_files,
    get_skills_completer,
    ReasoningCompleter,
)
from .model_utils import get_model_max_context
from .tools import registry
from .utils import choice, parse_frontmatter

if TYPE_CHECKING:
    from chat import Conversation

logger = getLogger(__name__)

handlers: dict[str, CommandHandler] = {}


@dataclass
class CommandHandler:
    name: str  # name of the command (<prefix><name>)
    function: Callable  # function to execute when <prefix><name> is invoked
    rule: Callable  # custom rule to match prompts
    completer: Completer | None = None

    prefix: str = "/"  # prefix to invoke command

    @property
    def full_name(self) -> str:
        """Full name, including prefix"""
        return self.prefix + self.name


@lru_cache(maxsize=1)
def get_prefixes() -> set[str]:
    """Returns unique prefixes for registered commands"""
    return {command.prefix for command in handlers.values()}


class command_handler:
    """decorator to register commands as Conversation methods"""

    def __init__(
        self,
        prefix: str = "/",
        name: str | None = None,
        rule: Callable | None = None,
        completer: Completer | None = None,
    ):
        self.name = name
        self.prefix = prefix
        self.rule = rule
        self.completer = completer

    def __call__(self, func: Callable):
        if func.__name__ in (
            handler.function.__name__ for handler in handlers.values()
        ):
            raise ValueError(f"{func.__name__} has already been registered")

        command_name = self.name or func.__name__
        prefix = self.prefix

        @wraps(func)
        def wrapper(self, prompt: str, *args, **kwargs):
            __tracebackhide__ = True
            prompt = prompt.removeprefix(prefix + command_name).strip()
            logger.debug(
                "Calling command with args: prompt=%s, args=%s, kwargs=%s",
                prompt,
                args,
                kwargs,
            )
            return func(self, prompt, *args, **kwargs)

        logger.debug(
            "registering command: func=%s, name=%s, prefix=%s",
            func.__name__,
            self.name or "",
            self.prefix,
        )

        rule = (
            self.rule
            if self.rule
            else lambda prompt: prompt.startswith(f"{self.prefix}{command_name}")
        )

        # FIXME: we should validate that it only has one argument: the prompt
        assert callable(rule)

        handlers[command_name] = CommandHandler(
            name=command_name,
            function=wrapper,
            prefix=self.prefix,
            rule=rule,
            completer=self.completer,
        )
        get_prefixes.cache_clear()

        return wrapper


def match_command(prompt: str) -> CommandHandler | None:
    for command in handlers.values():
        if command.rule(prompt):
            return command

    return None


# FIXME: styles used in commands here are strictly dependent on how the
# theme is defined for the Console instance


@command_handler(
    prefix="!",
    rule=lambda prompt: prompt.startswith("!"),
)
def shell_command(conversation: Conversation, prompt: str) -> str:
    """Messages prefixed with `!` are interpreted as shell commands: they will be executed and output is inserted in the current context."""
    command = prompt.lstrip("!").strip()
    shell_path = os.getenv("SHELL", "/bin/bash")
    with conversation.console.status(f"Calling {command}"):
        proc = subprocess.Popen(  # TODO: It'd be nice to have timeouts
            [
                shell_path,
                "-il",  # force an interactive login shell, so that login shell rc files are sourced and this behaves like the user's shell
                "-c",  # execute the given command
                command,
            ],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        try:
            output, _ = proc.communicate()
        finally:
            retcode = proc.returncode
            proc.kill()

        if retcode != 0:
            conversation.console.print("Command failed", style="error")

    conversation._print_markdown(
        f"{command=}, return code={retcode}, output:\n```\n{output}\n```\n"
    )

    return f"User ran shell command `{command}`. return code={retcode}, output:\n```\n{output}\n```\n"


@command_handler(
    completer=LazyCommandsCompleter(),
)
def help(
    conversation,
    name: str | None,
) -> None:
    """Show a list of available commands or documentation about a specific command"""

    if name:
        # Got an explicit request, print help for given command
        if name not in handlers:
            conversation.console.print(f"No such command: {name}", style="error")
            return
        command = next(command for command in handlers.values() if name == command.name)

        if not command.function.__doc__:
            conversation.console.print(f"No help for {name}", style="system")
            return

        conversation._print_markdown(
            "\n".join(
                (f"# Help for {name}", *command.function.__doc__.splitlines()),
            ),
        )
        return

    # print help for all commands

    max_command_width = (
        max(
            (len(command.function.__name__) + len(command.prefix))
            for command in handlers.values()
        )
        + 2
    )
    max_help_width = max(
        len(
            command.function.__doc__.splitlines()[0] if command.function.__doc__ else ""
        )
        for command in handlers.values()
    )

    commands_help = []
    for command in handlers.values():
        cmd = f"`{command.prefix}{command.name}`"
        formatted_command = f"- {cmd:<{max_command_width}}"

        help_lines = (
            command.function.__doc__.splitlines() if command.function.__doc__ else []
        )
        doc, doc_detail = help_lines[0] if help_lines else "", help_lines[1:]

        formatted_doc_detail = textwrap.indent("\n".join(doc_detail), prefix="\t\t")
        formatted_command_description = f"{doc:<{max_help_width}}" + (
            ("\n" + formatted_doc_detail) if doc_detail else ""
        )

        commands_help.append(f"{formatted_command} │ {formatted_command_description}")

    conversation._print_markdown(
        "\n".join(("# Available commands", *commands_help)),
    )


@command_handler(
    completer=WordCompleter(
        ["list", *get_all_styles()],
        meta_dict={"list": "Select theme interactively."},
    ),
)
def theme(conversation, theme: str | None) -> None:
    """Show or select theme (pygments themes)"""
    if not theme:
        conversation.console.print("[system]Current theme:[/system] ", end="")
        conversation._print_markdown(
            f"`{conversation.theme}`. Use `/theme list` to list available themes.",
            end="",
        )
        return

    theme = theme.strip()

    theme_sample_template = textwrap.dedent(
        """
        # Theme: {style}

        This is an `hello_world.py`:
        ```python
        def hello_world():
            print("hello world!")
        ```
        """
    )

    all_styles = list(get_all_styles())
    if theme == "list":
        conversation.console.print("Available themes:")
        num_styles = len(all_styles)
        selected_theme = None
        for index, style in enumerate(all_styles):
            conversation._print_markdown(
                theme_sample_template.format(style=style),
                markdown_kwargs={"code_theme": style},
            )
            answer = choice(
                f"Select {style}? y to set as new theme, e to exit ({index + 1}/{num_styles})",
                choices=("y", "n", "e"),
                default="n",
            )
            if answer == "y":
                selected_theme = style
                break

            if answer == "e":
                return

        if not selected_theme:
            return
    else:
        selected_theme = theme

    if selected_theme not in all_styles:
        conversation.console.print(
            f'Style "{selected_theme}" is not available, use "/theme list" to list available themes'
        )
        return

    conversation.set_theme(selected_theme)
    conversation.console.print(f"# Set theme: {selected_theme}.", style="system")
    conversation.console.print(
        "# Use `/config save` to persist changes across sessions.", style="system"
    )


@command_handler(
    completer=PathCompleter(
        only_directories=True,
        file_filter=completion_filter_invisible_files,
    ),
)
def cd(conversation, path: str | None) -> str | None:
    """change working directory"""
    if not path:
        conversation.console.print("Must provide a path", style="info")
        return None

    p = Path(path).expanduser().resolve()

    if not p.is_dir():
        conversation.console.print(f"{path=} is not a directory")
        return None

    os.chdir(p)
    msg = f"Working directory now changed to: {p.as_posix()}"
    conversation.console.print(msg, style="info")
    return msg


@command_handler()
def cwd(conversation, _: str | None) -> str | None:
    """Get the current working directory working directory"""
    cwd = Path.cwd()
    try:
        cwd = cwd.relative_to(Path.home())
    except ValueError:
        pass

    if cwd.as_posix() == ".":
        cwd = Path.home()

    msg = f"Working directory is: {cwd.as_posix()}"
    conversation.console.print(msg, style="info")
    return msg


@command_handler()
def pwd(conversation, _: str | None) -> str | None:
    """Alias to `/cwd`"""
    return cwd(conversation, "")


@command_handler(rule=lambda prompt: prompt.startswith("/model"))
def model(conversation, arg: str, *args, **kwargs) -> None:
    """Show the currently selected model or list current models (`/models`)"""
    if not arg:
        conversation._print_markdown(
            f"💡 Current model: `{conversation.model.id}` (ctx={get_model_max_context(conversation.model) or 'unknown'})"
        )
    elif arg == "s":  # command is /models
        models_formatted = (
            f"- [code]{model.id}[/code] (ctx={get_model_max_context(model) or 'unknown'})"
            for model in conversation.available_models
        )
        conversation.console.print(
            Text("Available models:\n", style="system"),
            "\n".join(models_formatted),
        )
    else:
        raise ValueError(f"{arg=}")


@command_handler()
def prompt(conversation, new_prompt: str, *args, **kwargs) -> None:
    """Show/Set the system prompt"""
    if new_prompt:
        conversation.override_system_prompt(new_prompt)

    conversation._print_markdown(
        textwrap.dedent(
            """
            # 📜 System prompt

            ```markdown
            {md}
            ```
            """
        ).format(md=conversation.system_prompt["content"])
    )


@command_handler()
def tools(conversation, prompt: str, *args, **kwargs) -> None:
    """List available tools"""
    # FIXME: remove this assert/raise and just print a warning?
    assert prompt == ""
    if args or kwargs:
        raise ValueError("/tools does not take any arguments")

    max_tool_width = max(map(len, registry)) + 2
    max_doc_width = (
        max(
            map(
                len,
                map(
                    lambda f: f.__doc__.split("\n", maxsplit=1)[0],
                    registry.values(),
                ),
            )
        )
        + 1
    )
    tools_text = [
        "# 🛠️ Enabled tools",
    ]
    disabled_tools_text = [
        "# 🛠️ Disabled tools",
    ]

    for tool_name, tool in registry.items():
        doc_header = (
            tool.function.__doc__.split("\n", maxsplit=1)[0]
            if tool.function.__doc__
            else ""
        )
        formatted_tool_name = f"`{tool_name}`"
        formatted_description = doc_header + (
            " (__requires confirmation__)" if tool.requires_confirmation else ""
        )

        (tools_text if tool.is_enabled() else disabled_tools_text).append(
            f"- {formatted_tool_name:<{max_tool_width}} │ {formatted_description:<{max_doc_width}}"
        )

    conversation._print_markdown(
        "\n".join(tools_text) + "\n" + "\n".join(disabled_tools_text)
    )
    conversation._print_markdown("Use /tool <name> to get information about a tool")


@command_handler(
    completer=LazyToolsCompleter.from_tools_registry(),
)
def tool(conversation, args: str) -> None:
    """Get information and enable/disable a specific tool. Usage: `/tool <name> [enable|disable]`"""
    if not args:
        tools(conversation, "")
        return

    processed = args.split()

    if len(processed) > 2:
        conversation._print_markdown(
            "Invalid usage: must call /tool [tool_name] [enable|disable|toggle]",
            style="error",
        )
        return

    name = processed[0]
    status: str | None = processed[1] if len(processed) == 2 else None

    try:
        tool = registry[name]
    except KeyError:
        conversation._print_markdown(f"No tool named `{name}` exists", style="error")
        return

    if status:
        match status.lower():
            case "enabled" | "enable":
                tool.enabled = True
            case "disabled" | "disable":
                tool.enabled = False
            case "toggle":
                tool.enabled = not tool.enabled
            case _:
                conversation._print_markdown(
                    "Invalid usage: must call /tool [tool_name] [enable|disable|toggle]",
                    style="error",
                )
                return

        conversation._print_markdown(
            f"Tool `{tool.name}` is now " + ("enabled" if tool.enabled else "disabled")
        )
        conversation.console.print(
            "# Use /config save to persist configuration", style="system"
        )
        return

    tools_text = [f"# source code for {name}"]

    source = inspect.getsource(tool.function)
    formatted_source = textwrap.dedent("""
        ```python
        {code}
        ```
        """).format(code=source)

    tools_text.append(formatted_source)

    conversation._print_markdown("\n".join(tools_text))


@command_handler(
    rule=lambda prompt: prompt.startswith("/fragment "),
    completer=PathCompleter(
        file_filter=completion_filter_invisible_files,
    ),
)
def fragment(conversation, fragment: str) -> str | None:
    """Inserts a fragment into the context, reading it from a file or url"""

    res = fragment.split(" ", maxsplit=1)
    path_or_url, extra = res[0], (None if (len(res) == 1 or not res[1]) else res[1])
    if not path_or_url:
        conversation.console.print("No path or url provided", style="error")
        return None

    if re.match("https?://", path_or_url):
        return conversation._handle_url_fragment(path_or_url, extra)

    path = Path(path_or_url).expanduser()

    if not path.exists():
        conversation.console.print(f"File does not exist: {path}", style="error")
        return None

    return conversation._handle_file_fragment(path, extra)


@command_handler()
def messages(conversation, arg: str) -> None:
    """Shows the current conversation.

    Usage:
    - /messages    - Shows all messages
    - /messages 2  - Shows the second message
    - /messages 2: - Shows all messages starting from the second
    - /messages -1 - Shows the last message

    """
    cleaned = filter_encoded_images(conversation.messages)
    if not arg:
        return conversation.console.print_json(
            json.dumps(cleaned, indent=1),
        )

    to_print: str | list[dict[str, str]]
    if ":" not in arg:
        try:
            idx = int(arg)
        except ValueError:
            to_print = cleaned[1:]
        else:
            try:
                to_print = cleaned[idx]["content"]
            except IndexError:
                n_messages = len(conversation.messages)
                allowed_range = "[0]" if n_messages == 1 else f"[0-{n_messages - 1}]"
                return conversation.console.print(
                    f"index is out of range, must be in {allowed_range}",
                    style="error",
                )
            except KeyError:
                if "tool_calls" not in cleaned[idx]:
                    raise

                parts = []
                for tool_call in cleaned[idx]["tool_calls"]:
                    f = tool_call["function"]

                    formatted_args = ", ".join(
                        f'{k}="{v}"' for k, v in json.loads(f["arguments"]).items()
                    )
                    formatted_tool_call_message = f"`{f['name']}({formatted_args})`"

                    parts.append(f"🔧 tool_call: {formatted_tool_call_message}")

                return conversation._print_markdown("\n".join(parts))
            else:
                assert isinstance(to_print, str)

                return conversation._print_markdown(to_print)
    else:
        range_min_str, range_max_str = arg.split(":")
        try:
            range_min = int(range_min_str)
        except ValueError:
            range_min = None
        try:
            range_max = int(range_max_str)
        except ValueError:
            range_max = None
        if range_min is None and range_max is None:
            to_print = cleaned
        elif range_min is None:
            to_print = cleaned[:range_max]
        elif range_max is None:
            to_print = cleaned[range_min:]
        else:
            to_print = cleaned[range_min:range_max]

    return conversation.console.print_json(
        json.dumps(to_print, indent=1),
    )


@command_handler()
def multiline(conversation, arg: str = "") -> None:
    """Enables multiline mode (can be used with an inline prompt, e.g /multiline first line)"""
    return conversation.toggle_multiline(arg)


@command_handler()
def debug(conversation, arg: str = "") -> None:
    """Toggles debugging"""
    conversation._debug = not conversation._debug
    conversation.console.print(
        "# debug is now",
        ("enabled." if conversation._debug else "disabled."),
        style="system",
    )


@command_handler(
    completer=WordCompleter(
        ["save"],
        meta_dict={
            "save": "Save the current tools configuration",
        },
    )
)
def config(conversation, arg: str = "") -> None:
    """Shows the current configuration"""

    from .config import config

    lines = ["**Current Configuration:**"]

    lines.extend(
        [
            f"- configuration file: `~/{config.config_file.relative_to(Path.home())}`",
            f"- logfile: `~/{config.logfile.relative_to(Path.home())}`",
            f"- current chat prompt history: `~/{config.chat_history_path.relative_to(Path.home())}`",
            f"- active model: `{conversation.model.id}`",
            f"- show reasoning: `{conversation.get_show_reasoning()}`",
            f"- reasoning effort: `{conversation.get_reasoning_effort()}`",
        ]
    )

    if arg == "save":
        lines.append("")
        lines.append("Saved current configuration.")

        config.save(conversation)
    conversation._print_markdown("\n".join(lines))


@command_handler(
    rule=lambda prompt: prompt.startswith("/skills"),
    completer=get_skills_completer(),
)
def skills(
    conversation: Conversation,
    args: str,
) -> None:
    """Alias for /skill"""
    return skill(conversation, args)


@command_handler(
    rule=lambda prompt: prompt.startswith("/skill"),
    completer=get_skills_completer(),
)
def skill(conversation, args: str) -> None:
    """Inserts one or more skill definition into the context: reading it from files and/or directories

    Usage:
    - /skill                                 - Show all loaded skills
    - /skill load ./skill1.md [./skill2.md]  - Import skill(s)
    - /skill load ./skills/                  - Import skills from a directory recursively
    - /skill unload                          - Unload all skills
    - /skill unload myskill1 [myskill2 ...]  - Unload skill (by name, file name, or path)

    """
    if not args:
        skills = conversation.skill_manager.values()
        if not skills:
            conversation.console.print("# No loaded skills.", style="system")
        else:
            header = "# Loaded skills\n"
            conversation._print_markdown(
                header
                + "\n".join(
                    f" - `{skill.name}`"
                    + (f" - {skill.description}" if skill.description else "")
                    for skill in skills
                )
            )

        return

    try:
        action, args = args.split(maxsplit=1)
    except ValueError:
        action = args
        args = ""

    match action.lower():
        case "load":
            paths = list(map(Path, args.split()))
            if not args:
                conversation.console.print("No paths provided", style="error")
                return

            loaded_skills = conversation.skill_manager.load(paths)
            if not loaded_skills:
                conversation.console.print("No skills could be loaded.", style="error")
                return

            loaded_formatted = []
            for path in paths:
                try:
                    formatted = path.relative_to(path.cwd())
                except ValueError:
                    formatted = path
                loaded_formatted.append(formatted)

            if not loaded_formatted:
                conversation.console.print(
                    f"Couldn't load skill{'s' if len(paths) > 1 else ''}.",
                    style="error",
                )

                return

            header = f"**Loaded skills from** `{', '.join(path.as_posix() for path in loaded_formatted)}`: "
            conversation._print_markdown(
                header + ", ".join(skill.name for skill in loaded_skills)
            )
        case "unload":
            skills = set(args.split())
            if not skills:
                conversation.skill_manager.unload_all()
                conversation.console.print("# Unloaded all skills", style="system")
                return

            unloaded_skills = [
                conversation.skill_manager.unload(skill_name) for skill_name in skills
            ]

            not_found = skills - {skill.path.as_posix() for skill in unloaded_skills}

            if not_found:
                conversation.console.print(
                    f"# No such skill{'s' if len(not_found) > 1 else ''}: {', '.join(not_found)}",
                    style="system",
                )

            for unloaded_skill in unloaded_skills:
                try:
                    skill_path = unloaded_skill.path.relative_to(Path.cwd())
                except ValueError:
                    skill_path = unloaded_skill.path

                conversation._print_markdown(
                    f"**Unloaded skill:** `{unloaded_skill.name}` (`{skill_path}`)",
                    style="system",
                )
        case _:
            conversation.console.print(
                "Unknown action for /skills command", style="error"
            )


@command_handler()
def save(conversation: Conversation, filename: str = "") -> None:
    """Save the current session summary to a markdown file using the LLM.

    Usage:
    - /save            - Save to memory.md
    - /save custom.md  - Save to custom.md
    """

    messages = [
        {
            "role": "system",
            "content": save_command_prompt,
        },
        *[message for message in conversation.messages[1:]],
    ]

    with conversation.console.status("Generating session summary..."):
        try:
            response = conversation.client.chat.completions.create(
                messages=messages,
                model=conversation.model.id,
                stream=False,
                tools=None,
            )
        except KeyboardInterrupt:
            conversation._print_markdown("Interrupted", style="error")
            return
        except Exception as exc:
            logger.exception("Unexpected error during summarization")
            conversation._print_markdown(
                f"Unexpected error during summarization: {exc}", style="error"
            )
            return

    summary_md = response.choices[0].message.content

    if not summary_md:
        conversation._print_markdown("Failed to generate a summary.", style="error")
        return

    skill_info = []
    for skill_path, skill in conversation.skill_manager.items():
        try:
            path = skill_path.relative_to(Path.cwd()).as_posix()
        except ValueError:
            path = skill_path.as_posix()

        skill_info.append(
            {
                "path": path,
                "name": skill.name,
                "description": skill.description,
            }
        )

    timestamp = datetime.datetime.now().isoformat(timespec="minutes")
    frontmatter = {
        "timestamp": timestamp,
        "model": conversation.model.id,
        "skills": skill_info,
    }

    formatted_memory = (
        textwrap.dedent(
            """
            ---
            {frontmatter}
            ---
            {summary_section}
            """
        )
        .strip()
        .format(
            frontmatter=yaml.dump(frontmatter).strip(),
            summary_section=summary_md.strip(),
        )
    )

    default = "memory.md"
    memory = Path(filename or default)

    if (
        memory.exists()
        and choice(f"{memory.name} exists, overwrite?", default="n") == "n"
    ):
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        memory = memory.with_stem(f"{memory.stem}_{timestamp}")

    with memory.open("w") as f:
        f.write(formatted_memory)

    conversation._print_markdown(f"Session saved to `{memory.name}`")
    return None


@command_handler(
    completer=PathCompleter(
        file_filter=lambda file: (
            file.endswith(".md") and completion_filter_invisible_files(file)
        ),
    ),
)
def load(
    conversation: Conversation,
    filename: str = "",
    pretty_format: bool = True,
) -> str | None:
    """Load and display a saved session summary.

    Usage:
    - /load           - Load memory.md
    - /load custom.md - Load custom.md
    """
    path = Path(filename or "memory.md")
    if not path.exists():
        conversation._print_markdown(f"File `{path}` does not exist.", style="error")
        return None

    memory = path.read_text()

    frontmatter, memory = parse_frontmatter(memory)

    skills = []
    if "skills" in frontmatter:
        skills = [Path(skill["path"]) for skill in frontmatter["skills"]]

    for path in skills:
        if not path.exists():
            conversation.console.print(
                f"# Warning: Saved skill path does not exist: {path}",
                style="system",
            )
            continue

    if loaded_skills := conversation.skill_manager.load(skills):
        conversation._print_markdown(
            "Loaded skill(s) from memory file: "
            + ", ".join(skill.name for skill in loaded_skills)
        )
    elif skills:
        conversation.console.print(
            "# Warning: Couldn't load skills referenced in memory file: "
            + ", ".join(skill.name for skill in skills),
            style="system",
        )

    if not pretty_format:
        return memory

    return (
        textwrap.dedent(
            """
            User loaded a memory from a previous conversation:

            ```markdown
            {memory}
            ```
            """
        )
        .format(memory=memory)
        .strip()
    )


@command_handler(completer=ReasoningCompleter())
def reasoning(conversation, args: str = "") -> None:
    """Show reasoning content

    Usage:

    /reasoning show
    /reasoning hide
    /reasoning toggle
    """
    args_list = args.split()

    if not args_list:
        action = ""
    else:
        action = args_list[0]

    enabled: bool | None = None
    reasoning_effort: str | None = None

    match action.lower():
        case "toggle" | "":
            pass
        case "show":
            enabled = True
        case "hide":
            enabled = False
        case "effort":
            reasoning_effort = conversation.get_reasoning_effort()

            try:
                effort_action = args_list[1]
            except IndexError:
                effort_action = None
            try:
                new_reasoning_effort = args_list[2]
            except IndexError:
                new_reasoning_effort = None

            if not effort_action or effort_action == "get":
                conversation.console.print(
                    f"# Current reasoning effort: {reasoning_effort}", style="system"
                )
                return

            if effort_action not in ("set", "get"):
                conversation.console.print(
                    "Usage: /reasoning effort [get|set <value>]", style="error"
                )
                return

            if effort_action == "set" and (
                not new_reasoning_effort
                or (
                    new_reasoning_effort
                    and new_reasoning_effort
                    not in ReasoningCompleter.reasoning_effort_values
                )
            ):
                conversation.console.print(
                    f"Usage: /reasoning effort set {'|'.join(ReasoningCompleter.reasoning_effort_values)}",
                    style="error",
                )
                return

            if effort_action == "get" and new_reasoning_effort:
                conversation.console.print(
                    "Usage: /reasoning effort [get]", style="error"
                )
                return None

            if effort_action == "set":
                conversation.set_reasoning_effort(new_reasoning_effort)
        case _:
            conversation.console.print(
                "Usage: /reasoning show|hide|toggle|(effort [get|set <value>])",
                style="error",
            )
            return None

    if reasoning_effort:
        if new_reasoning_effort:
            message = f"# Set reasoning effort to {new_reasoning_effort}"
        else:
            message = f"# Reasoning effort: {reasoning_effort}"
    else:
        showing_reasoning = conversation.show_reasoning(enabled)
        message = f"# {'Showing' if showing_reasoning else 'Hiding'} reasoning content"

    conversation.console.print(message, style="system")


@command_handler(
    completer=LazyYoloCompleter.from_tools_registry(),
)
def yolo(
    conversation: Conversation,
    args: str = "",
) -> str | None:
    """Enable YOLO mode: disable confirmation dialog for all or selected tool calls

    Usage:
    - /yolo [status]                             - shows the current status
    - /yolo [enable|disable|toggle]              - Enable/Disable/Toggle YOLO mode for all tools
    - /yolo [enable|disable|toggle] [tool name]  - Enable/Disable/Toggle YOLO mode for s specific tool
    """

    try:
        action, tool_name = args.lower().split(maxsplit=1)
    except ValueError:
        action = args
        tool_name = ""

    def usage(message: str | None = None) -> None:
        if message:
            conversation._print_markdown(
                message,
                style="error",
            )

        conversation._print_markdown(
            "Invalid usage: See /help yolo for usage",
            style="error",
        )
        return None

    if action not in ("toggle", "enable", "disable", "status", ""):
        usage()
        return None

    if tool_name and tool_name not in registry:
        usage(message=f"No such tool: `{tool_name}`")
        return None

    match action:
        case "status" | "":
            md_lines = ["# YOLO mode status"]
            md_lines.append("When **enabled**, tool calls require NO approval")
            for name, enabled in conversation.get_yolo_mode_status().items():
                md_lines.append(
                    f"- `{name}`: " + ("`enabled`" if enabled else "`disabled`")
                )
            conversation._print_markdown("\n".join(md_lines))
            return None
        case "toggle":
            conversation.set_yolo_mode(tool_name=tool_name)
        case "enable":
            conversation.set_yolo_mode(True, tool_name)
        case "disable":
            conversation.set_yolo_mode(False, tool_name)
        case _:
            usage()
            return None

    yolo_status = conversation.get_yolo_mode(tool_name)

    if tool_name:
        message = (
            f"# YOLO mode enabled: no confirmation required for tool: {tool_name}"
            if yolo_status
            else f"# YOLO mode disabled for tool: {tool_name}"
        )
    else:
        message = (
            "# YOLO mode enabled: no confirmation required for tool calls."
            if yolo_status
            else "# YOLO mode disabled"
        )

    conversation.console.print(message, style="system")

    return None
