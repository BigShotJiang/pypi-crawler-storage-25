from __future__ import annotations

import os
from typing import Iterable

from prompt_toolkit.completion import (
    Completion,
    PathCompleter,
    WordCompleter,
    Completer,
    NestedCompleter,
)
from prompt_toolkit.document import Document
from prompt_toolkit.document import _FIND_WORD_RE

from .skills import manager as skill_manager
from .utils import relative_to_cwd
from .logger import getLogger

from openai.types import ReasoningEffort
from typing import TYPE_CHECKING
from functools import cache

if TYPE_CHECKING:
    from prompt_toolkit.completion import CompleteEvent


logger = getLogger(__name__)


def completion_filter_invisible_files(path: str) -> bool:
    name = path.rsplit(os.sep, maxsplit=1)[-1]
    logger.trace(f"{path=}")  # type: ignore # trace level defined in .logger
    return not name.startswith(".")


class LazyCommandsMetaDict:
    """Lazy way to get docstrings for commands after they've been registered in commands.handlers"""

    @cache
    def get(self, key: str, default: str) -> str:
        from .commands import handlers

        try:
            command = handlers[key.lstrip("/")]
        except KeyError:
            return default

        return command.function.__doc__.split("\n", maxsplit=1)[0]


class CommandPrefixCompleter(NestedCompleter):
    def get_completions(
        self, document: Document, complete_event: CompleteEvent
    ) -> Iterable[Completion]:
        # Split document.
        text = document.text_before_cursor.lstrip()
        stripped_len = len(document.text_before_cursor) - len(text)

        # If there is a space, check for the first term, and use a
        # subcompleter.
        if " " in text:
            first_term = text.split()[0]
            completer = self.options.get(first_term)

            # If we have a sub completer, use this for the completions.
            if completer is not None:
                remaining_text = text[len(first_term) :].lstrip()
                move_cursor = len(text) - len(remaining_text) + stripped_len

                new_document = Document(
                    remaining_text,
                    cursor_position=document.cursor_position - move_cursor,
                )

                yield from completer.get_completions(new_document, complete_event)

        # No space in the input: behave exactly like `WordCompleter`.
        elif text.startswith("/"):
            completer = WordCompleter(
                [key for key in self.options.keys() if key.startswith("/")],
                ignore_case=self.ignore_case,
                sentence=True,  # sentence must be set to true since the command prefix "/" counts as a word boundary
                meta_dict=LazyCommandsMetaDict(),  # type: ignore
            )
            yield from completer.get_completions(document, complete_event)
        else:
            completer = WordCompleter(
                list(self.options.keys()), ignore_case=self.ignore_case, sentence=True
            )
            yield from completer.get_completions(document, complete_event)


class LazyCommandsCompleter(WordCompleter):
    """Lazy wordcompleter to list available commands *after* they have been registered."""

    def __init__(
        self,
        *args,
        **kwargs,
    ):
        super().__init__(
            words=self.get_command_names,
            *args,
            pattern=_FIND_WORD_RE,
            meta_dict=LazyCommandsMetaDict(),
            **kwargs,
        )

    def get_command_names(self) -> list[str]:
        from .commands import handlers

        return list(handlers.keys())


class LazyToolsCompleter(NestedCompleter):
    """Lazy wordcompleter to list available tools *after* they have been registered."""

    @classmethod
    def from_tools_registry(cls) -> NestedCompleter:
        from .tools import registry

        return cls.from_nested_dict(
            {
                tool.name: WordCompleter(
                    [
                        "disable" if tool.enabled else "disabled",
                        "toggle",
                    ]
                )
                for tool in registry.values()
            }
        )


class LazyYoloCompleter(NestedCompleter):
    """Lazy wordcompleter to list tools that require confirmation  *after* they have been registered."""

    @classmethod
    def from_tools_registry(cls) -> NestedCompleter:
        from .tools import registry

        commands = ["enable", "disable", "toggle", "status"]

        tool_names = [
            tool.name for tool in registry.values() if tool.requires_confirmation
        ]

        return cls.from_nested_dict(
            {
                command: WordCompleter(
                    tool_names,
                    meta_dict=None,
                )
                for command in commands
            }
        )


class LazySkillsCompleter(WordCompleter):  # FIXME: this is unused, delete me
    """Lazy wordcompleter to list available skills *after* they have been loaded."""

    def __init__(
        self,
        *args,
        **kwargs,
    ):
        super().__init__(
            words=self.get_skills,
            *args,
            pattern=_FIND_WORD_RE,
            **kwargs,
        )

    def get_skills(self) -> list[str]:
        # Fixed method name from get_tools to get_skills
        from .skills import manager

        return [skill_name.as_posix() for skill_name in manager.keys()]


class YoloCommandCompleter(NestedCompleter):
    def get_completions(
        self, document: Document, complete_event: CompleteEvent
    ) -> Iterable[Completion]:
        # Split document.
        text = document.text_before_cursor.lstrip()
        stripped_len = len(document.text_before_cursor) - len(text)

        # If there is a space, check for the first term, and use a
        # subcompleter.
        if " " in text:
            first_term = text.split()[0]
            completer = self.options.get(first_term)

            # If we have a sub completer, use this for the completions.
            if completer is not None:
                remaining_text = text[len(first_term) :].lstrip()
                move_cursor = len(text) - len(remaining_text) + stripped_len

                new_document = Document(
                    remaining_text,
                    cursor_position=document.cursor_position - move_cursor,
                )

                yield from completer.get_completions(new_document, complete_event)

        # No space in the input: behave exactly like `WordCompleter`.
        elif text.startswith("/"):
            completer = WordCompleter(
                [key for key in self.options.keys() if key.startswith("/")],
                ignore_case=self.ignore_case,
                sentence=True,  # sentence must be set to true since the command prefix "/" counts as a word boundary
                meta_dict=LazyCommandsMetaDict(),  # type: ignore
            )
            yield from completer.get_completions(document, complete_event)
        else:
            completer = WordCompleter(
                list(self.options.keys()), ignore_case=self.ignore_case, sentence=True
            )
            yield from completer.get_completions(document, complete_event)


def get_skills_completer() -> Completer:
    def get_loaded_skill_paths() -> list[str]:
        return [relative_to_cwd(path).as_posix() for path in skill_manager]

    return NestedCompleter.from_nested_dict(
        {
            "load": PathCompleter(file_filter=completion_filter_invisible_files),
            "unload": WordCompleter(words=get_loaded_skill_paths),
        }
    )


class ReasoningCompleter(Completer):
    _meta_dict = {
        "show": "Show reasoning content",
        "hide": "Hide reasoning content",
        "toggle": "Toggle showing reasoning content",
        "effort": "Get/Set reasoning effort",
    }
    # FIXME: this actually depends on the server!
    reasoning_effort_values = ReasoningEffort.__args__[0].__args__

    def get_completions(
        self, document: Document, complete_event: CompleteEvent
    ) -> Iterable[Completion]:
        # Split document.
        text = document.text_before_cursor.lstrip()
        stripped_len = len(document.text_before_cursor) - len(text)

        completer: Completer
        if " " not in text:
            # No space in the input: behave exactly like `WordCompleter`.
            completer = WordCompleter(
                list(self._meta_dict.keys()),
                meta_dict=self._meta_dict,
            )
            yield from completer.get_completions(document, complete_event)

            return

        # If there is a space, check for the first term, and use a
        # subcompleter.
        text_list = text.split()
        first_term = text_list[0]

        logger.debug(f"{first_term=}")
        if first_term != "effort":
            return

        try:
            second_term = text_list[1]
        except IndexError:
            second_term = ""

        logger.debug(f"{second_term=}")

        if second_term == "get":
            return

        if second_term == "set":
            completer = WordCompleter(self.reasoning_effort_values)

            remaining_text = text[len(second_term) :].lstrip()
            logger.debug(f"{remaining_text=}")
            move_cursor = len(text) - len(remaining_text) + stripped_len

            new_document = Document(
                remaining_text,
                cursor_position=document.cursor_position - move_cursor,
            )

            yield from completer.get_completions(new_document, complete_event)
            return

        completer = WordCompleter(
            ["get", "set"],
            meta_dict={
                "get": "Get reasoning effort",
                "set": "Set reasoning effort",
            },
        )

        remaining_text = text[len(second_term) :].lstrip()
        move_cursor = len(text) - len(remaining_text) + stripped_len

        new_document = Document(
            remaining_text,
            cursor_position=document.cursor_position - move_cursor,
        )

        yield from completer.get_completions(new_document, complete_event)
