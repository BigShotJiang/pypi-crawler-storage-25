from typing import TypeAlias


# alias for a str containing markdown-formatted text
MarkdownStr: TypeAlias = str
