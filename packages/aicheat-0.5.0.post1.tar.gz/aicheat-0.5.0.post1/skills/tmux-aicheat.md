---
name: tmux-aicheat-agents
description: Run multiple aicheat instances in tmux panes to run multiple agents in parallel. Use when tackling complex problems which can be split in smaller tasks.
---

## Context

This skills enables running multiple aicheat AI assistant sessions in tmux split panes, creating a controller-worker architecture for parallel agents execution.

## When to use

- When the user asks for a new aicheat session/worker/agent
- When dealing with a complex task that can be split into multiple smaller subtasks
- When a long chain of operations is required to understand a task and the main session only needs a summary

## Starting a background tmux session

If you're not currently in a tmux session (`tmux` commands return: `no server running on` and the `$TMUX` environment variable is not set), you can start one in the background:

### Creating a detached tmux session for aicheat agents

```bash
# Start a new detached tmux session named 'aicheat'
tmux new-session -d -s aicheat

# Verify the session was created
tmux list-sessions

# Send commands to the session without attaching
tmux send-keys -t aicheat 'echo "Background session ready"' Enter

# Capture output from the session
tmux capture-pane -p -t aicheat
```

Once you have a background session, you can use all the standard tmux-aicheat patterns described below.

## Use Case: Background Worker Agents Pattern

Keep your main aicheat session focused on complex problems while delegating simple tasks to a background agent (worker) session.

Example workflow

1. Main session: Working on a specific feature: providing instructions and designing a plan
2. Worker session: Spawned to run quick tests, verify commands, check outputs
3. (optional) Additional agent workers: used to run smaller tasks

This uses the controller pattern: the main session sends commands to worker, captures output, learns from results. Worker sessions can also load this skill and start sub-agents.

**Benefits**:

- Main session maintains context on the primary task
- Worker session handles disposable/verification tasks
- No context switching or losing your train of thought
- Easy to spawn multiple workers for parallel testing

```bash
# Spawn a worker session
WORKER=$(tmux split-window -h -P -F '#{pane_id}')
tmux send-keys -t "$WORKER" 'aicheat' Enter
```

## ⚠️ Critical Rules

1. **ALWAYS capture the new pane ID** when splitting:

   ```bash
   NEW_PANE=$(tmux split-window -h -P -F '#{pane_id}')
   ```

   The `-P -F '#{pane_id}'` flags are MANDATORY - they return the new pane's ID.

2. **NEVER use relative pane references** like `:.+`, `:-1`, `0`, etc. These are unreliable and break when context changes.

3. **Distinguish between aicheat commands and shell commands**:
   - **aicheat commands** (like `/yolo enable`, `/help`, `/tools`) are sent as TEXT INPUT to the aicheat session using `tmux send-keys`
   - **Shell commands** (like `tmux split-window`, `ls`, `git status`) are executed using `execute_shell_command` tool
   - To run a shell command FROM aicheat, prefix with `!` (e.g., `!ls -la`)

## Quick Start

Launch aicheat worker agent in a new pane:

```bash
# Horizontal split
NEW_PANE=$(tmux split-window -h -P -F '#{pane_id}')
tmux send-keys -t "$NEW_PANE" 'aicheat' Enter
tmux select-pane -t "$NEW_PANE" -T "aicheat-1"

# Vertical split
NEW_PANE=$(tmux split-window -v -P -F '#{pane_id}')
tmux send-keys -t "$NEW_PANE" 'aicheat' Enter
tmux select-pane -t "$NEW_PANE" -T "aicheat-1"
```

Important notes:

- `-P -F '#{pane_id}'` returns the new pane's ID (e.g., `%10`)
- Always use pane IDs (e.g. `%10`) - they're globally unique and don't change
- Pane titles (`-T`) are for visual identification only

## Managing Multiple Sessions

### ❌ WRONG: Don't do this

```bash
# This will fail - you don't know which pane ID was created!
tmux split-window -h
tmux send-keys -t :.+ 'aicheat' Enter  # DON'T USE relative references!
```

### Launch additional aicheat agent sessions

```bash
# Second session
PANE2=$(tmux split-window -h -P -F '#{pane_id}')
tmux send-keys -t "$PANE2" 'aicheat' Enter
tmux select-pane -t "$PANE2" -T "aicheat-2"

# Third session
PANE3=$(tmux split-window -v -P -F '#{pane_id}')
tmux send-keys -t "$PANE3" 'aicheat' Enter
tmux select-pane -t "$PANE3" -T "aicheat-3"
```

### Find existing aicheat sessions

```bash
tmux list-panes -F "#{pane_id}: #{pane_title}" | grep aicheat
# Output: %10: aicheat-1, %11: aicheat-2
```

### Send commands to specific sessions

```bash
# Send aicheat commands (text input)
tmux send-keys -t "$PANE2" '/help' Enter
tmux send-keys -t "$PANE2" '/yolo enable' Enter

# Send questions (text input)
tmux send-keys -t %10 'Explain this code' Enter

# Find and send in one line
tmux send-keys -t $(tmux list-panes -F "#{pane_id}: #{pane_title}" | grep aicheat-1 | cut -d: -f1) '/help' Enter
```

## Interaction Patterns

### Handle confirmation prompts

aicheat might ask for confirmation for certain tasks:

- Loading `AGENTS.md`/`memory.md` files
- Invoking tool calls (`execute_shell_command`/`write_file`)

```bash
# Check contents and decide to run them if they're relevant to the task at hand (s)
tmux send-keys -t "$PANE" 's'
# load:
tmux send-keys -t "$PANE" 'y'
# refuse loading:
tmux send-keys -t "$PANE" 'n'
```

Yolo mode can be enabled to disable tool call confirmations. Use this carefully as this can run potentially destructive operations.

```bash
tmux send-keys -t "$PANE" '/yolo enable' Enter
```

This can be enabled at startup using `aicheat --no-confirm`

### Capture output

```bash
# Last 100 lines
tmux capture-pane -p -S -100 -t "$PANE"

# Full history
tmux capture-pane -p -t "$PANE"
```

### Common aicheat commands

These can be sent to `aicheat` sessions as text input:

- `/help` - Available commands
- `/config` - Show current configuration
- `/tools` - List Available tools
- `/messages` - Conversation history
- `/skill` - Load/unload skills
- `/save [filename.md]` - Save to memory.md (or `filename.md`)
- `/load [filename.md]` - Load memory.md (or `filename.md`)
- `/fragment filename.md [instructions]` - Load `filename.md` with optional instructions
- `/yolo enable` - Enable YOLO mode (no confirmations)
- `/yolo disable` - Disable YOLO mode
- `/yolo status` - Show YOLO mode status

### Running shell commands from aicheat

To run a shell command from within aicheat, prefix with `!`:

```bash
# Send to aicheat session as text input
tmux send-keys -t "$PANE" '!git status' Enter
tmux send-keys -t "$PANE" '!ls -la' Enter
```

### ⏱️ Timing Considerations

- **Always add delays** after launching aicheat before sending commands (2-3 seconds)
- **Add delays between confirmation keys** to allow processing
- Example pattern:

  ```bash
  sleep 2 && tmux capture-pane -p -S -50 -t "$PANE"
  # aicheat is waiting for confirmation, let's answer 'n'
  tmux send-keys -t "$PANE" 'n'
  ```

- Without proper delays, commands may be sent before aicheat is ready to receive them

### 🔁 Hierarchical Controller Pattern

Any aicheat session with this skill loaded can spawn and control its own worker sessions. This enables multi-level orchestration:

- **Main session** → spawns Worker 1
- **Worker 1** → can spawn Worker 2, Worker 3, etc.
- Each level uses the same `tmux send-keys` pattern to control its children

This pattern allows complex workflows where different sessions handle different aspects of a task.

## Example Workflows

### Background Testing Pattern

```bash
# Main session: Working on a complex feature
# Spawn a worker to test a simple command
WORKER=$(tmux split-window -h -P -F '#{pane_id}')
tmux send-keys -t "$WORKER" 'aicheat' Enter
tmux select-pane -t "$WORKER" -T "aicheat-worker"

# Skip prompts in worker
sleep 2 && tmux send-keys -t "$WORKER" 'n'  # Skip AGENTS.md
sleep 2 && tmux send-keys -t "$WORKER" 'n'  # Skip memory.md

# Enable YOLO mode in worker (optional, for no confirmations)
tmux send-keys -t "$WORKER" '/yolo enable' Enter

# Main session sends test command to worker
tmux send-keys -t "$WORKER" 'Test this command: !ls -la' Enter

# Capture and analyze results
tmux capture-pane -p -S -50 -t "$WORKER"

# Worker session can be closed when done, main session continues
```

### Multi-Session Orchestration

Use one session as a "controller" that orchestrates multiple worker sessions for different tasks:

- Worker 1: Code generation
- Worker 2: Testing/validation
- Worker 3: Documentation

```bash
# 1. Launch first aicheat (vertical split)
AICHEAT1=$(tmux split-window -v -P -F '#{pane_id}')
tmux send-keys -t "$AICHEAT1" 'aicheat --no-agent-files --no-memory' Enter
tmux select-pane -t "$AICHEAT1" -T "aicheat-questions"

# 2. Launch second aicheat with YOLO mode enabled (horizontal split)
AICHEAT2=$(tmux split-window -h -P -F '#{pane_id}')
tmux send-keys -t "$AICHEAT2" 'aicheat --no-confirmation' Enter
tmux select-pane -t "$AICHEAT2" -T "aicheat-coding"

# 3. Use sessions for different tasks
tmux send-keys -t "$AICHEAT1" 'Explain the architecture' Enter
tmux send-keys -t "$AICHEAT2" 'Write a function to...' Enter

# 4. Capture output when needed
tmux capture-pane -p -S -50 -t "$AICHEAT2"
```

### Returning information to the main worker

Several patterns are available:

- Use call `/save /tmp/<task name>_summary.md` pass a summary of the session to the main worker
- Ask the agent to write a report to `/tmp/<task name>_report.md` to pass its findings to the main worker
- Use the `read_file` tool to read
- Subagents can load summaries or reports with custom instructions using `/fragment load /tmp/task.md <custom instructions>`

## Troubleshooting

### Cleaning Up Workers

```bash
# Kill a specific worker
tmux kill-pane -t %PANE_ID

# Kill all workers with a specific title pattern
tmux list-panes -F "#{pane_id}: #{pane_title}" | grep worker | cut -d: -f1 | xargs -I {} tmux kill-pane -t {}

# List all panes to see what's running
tmux list-panes -F "#{pane_id}: #{pane_title}"
```

**Wrong pane selected after split:** This happens if you didn't capture the pane ID with `-P -F '#{pane_id}'`. Always store the new pane ID in a variable immediately after splitting.

**Relative references (`:.+`, `:-1`) don't work:** These are context-dependent and unreliable. Use pane IDs only.

**Pane not responding:** Verify pane ID exists

```bash
tmux list-panes -F "#{pane_id}: #{pane_title}"
```

**Can't find aicheat session:**

```bash
tmux list-panes -F "#{pane_id}: #{pane_title}" | grep aicheat
```

**Verify aicheat started:**

```bash
tmux capture-pane -p -t %10 | head -20
```

**Command sent to wrong session:** Remember:

- Use `tmux send-keys -t $PANE 'command'` for aicheat commands (text input)
- Use `execute_shell_command` for shell commands
- Use `!command` prefix to run shell commands from within aicheat

## Tips

- ✅ **Always use pane IDs** (`%10`) - never relative indices (`-1`, `0`)
- ✅ **Pane IDs work across windows** - no need to specify window_id
- ✅ **Store pane IDs in variables** for repeated use
- ✅ **Use descriptive titles** (`aicheat-questions`, `aicheat-code-review`)
- ✅ **Confirmation prompts need only the key** - no Enter
- ✅ **Enable YOLO mode** in worker sessions to skip confirmations (use `--no-confirmation` or enable at runtime suing `/yolo enable`)
- ❌ **Don't use relative indices** - they break when context changes
- ❌ **Don't send Enter after confirmation keys** (`y`, `n`, `s`)
- ❌ **Don't run aicheat commands as shell commands** - `/yolo` is not a shell command
