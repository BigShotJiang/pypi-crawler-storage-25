# Skills

## tmux integration: Multi-Session Interactive Agents

The ([`./tmux-aicheat.md`](./tmux-aicheat.md)) skill enables running multiple `aicheat` instances in `tmux` split panes, creating a **controller-worker pattern** for parallel task execution.

- Keep your main session focused on complex problems while delegating simple tasks to background workers
- No context switching or losing your train of thought
- Easy to spawn multiple workers for parallel testing and validation
- Workers can spawn their own workers for hierarchical orchestration

Quick Start:

```
❯ /skill load skills/tmux-aicheat.md
Loaded skills from skills/tmux-aicheat.md: tmux-aicheat.md
❯ Let's start a new agent session to develop a new aicheat feature
```

**Example Workflow:**

1. Main session: Working on a complex feature, maintaining context
2. Worker session: Spawned to run quick tests, verify commands, check outputs
3. Controller pattern: Main session sends commands to worker via `tmux send-keys`, captures output, learns from results

This pattern transforms `aicheat` from a single interactive agent into a **multi-agent system** where you can orchestrate parallel workflows while maintaining a clean separation of concerns.
