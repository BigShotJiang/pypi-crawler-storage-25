from __future__ import annotations

import pytest

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.completion.selection import resolve_turn_completion
from flare_kernel.runtime.llm.llm_provider import LLMCompletion


@pytest.mark.asyncio
async def test_resolve_turn_completion_prefers_guided_completion() -> None:
    guided = LLMCompletion(provider="guided", model="rule", content="guided", status="ok", details={})
    called = {"llm": False}

    async def _llm(*_args, **_kwargs):  # type: ignore[no-untyped-def]
        called["llm"] = True
        return LLMCompletion(provider="llm", model="m", content="llm", status="ok", details={})

    completion = await resolve_turn_completion(
        req=KernelRequest(payload={"message": "m"}),
        trace_id="trace-1",
        session_id="session-1",
        raw_message="m",
        resolved_mode="requirement_intake",
        mode_source="manual",
        effective_command="send_message",
        retrieved_knowledge=[],
        enriched_payload={},
        runtime_snapshot={},
        orchestration_status={},
        instance_profile=None,
        resolve_guided_orchestrated_completion_fn=lambda **_: guided,
        should_force_requirement_clarification_fn=lambda *_args, **_kwargs: False,
        build_requirement_clarification_message_fn=lambda message: f"clarify:{message}",
        build_prompt_fn=lambda *_args, **_kwargs: "prompt",
        generate_llm_completion_fn=_llm,
    )

    assert completion is guided
    assert called["llm"] is False


@pytest.mark.asyncio
async def test_resolve_turn_completion_does_not_let_guided_question_override_document_output() -> None:
    guided = LLMCompletion(provider="guided", model="rule", content="guided question", status="ok", details={})
    called = {"guided": False, "llm": False}

    async def _llm(prompt: str, **_kwargs):  # type: ignore[no-untyped-def]
        called["llm"] = True
        assert prompt == "prompt"
        return LLMCompletion(provider="llm", model="m", content="document draft", status="ok", details={})

    def _guided(**_kwargs):  # type: ignore[no-untyped-def]
        called["guided"] = True
        return guided

    completion = await resolve_turn_completion(
        req=KernelRequest(payload={"message": "请整理一份采购需求文档"}),
        trace_id="trace-doc",
        session_id="session-doc",
        raw_message="请整理一份采购需求文档",
        resolved_mode="requirement_intake",
        mode_source="intent",
        effective_command="send_message",
        retrieved_knowledge=[],
        enriched_payload={},
        runtime_snapshot={},
        orchestration_status={},
        instance_profile=None,
        resolve_guided_orchestrated_completion_fn=_guided,
        should_force_requirement_clarification_fn=lambda *_args, **_kwargs: False,
        build_requirement_clarification_message_fn=lambda message: f"clarify:{message}",
        build_prompt_fn=lambda *_args, **_kwargs: "prompt",
        generate_llm_completion_fn=_llm,
    )

    assert completion.provider == "llm"
    assert completion.content == "document draft"
    assert called["guided"] is False
    assert called["llm"] is True


@pytest.mark.asyncio
async def test_resolve_turn_completion_uses_guardrail_when_clarification_required() -> None:
    called = {"llm": False}

    async def _llm(*_args, **_kwargs):  # type: ignore[no-untyped-def]
        called["llm"] = True
        return LLMCompletion(provider="llm", model="m", content="llm", status="ok", details={})

    completion = await resolve_turn_completion(
        req=KernelRequest(payload={"message": "预算"}),
        trace_id="trace-2",
        session_id="session-2",
        raw_message="预算",
        resolved_mode="requirement_intake",
        mode_source="manual",
        effective_command="send_message",
        retrieved_knowledge=[],
        enriched_payload={},
        runtime_snapshot={},
        orchestration_status={},
        instance_profile=None,
        resolve_guided_orchestrated_completion_fn=lambda **_: None,
        should_force_requirement_clarification_fn=lambda *_args, **_kwargs: True,
        build_requirement_clarification_message_fn=lambda message: f"clarify:{message}",
        build_prompt_fn=lambda *_args, **_kwargs: "prompt",
        generate_llm_completion_fn=_llm,
    )

    assert completion.provider == "kernel_guardrail"
    assert completion.status == "guardrail"
    assert completion.content == "clarify:预算"
    assert called["llm"] is False


@pytest.mark.asyncio
async def test_resolve_turn_completion_falls_back_to_llm_generation() -> None:
    async def _llm(prompt: str, **kwargs):  # type: ignore[no-untyped-def]
        assert prompt == "prompt-x"
        assert kwargs["trace_id"] == "trace-3"
        assert kwargs["session_id"] == "session-3"
        assert kwargs["intent"] == "analysis"
        return LLMCompletion(provider="llm", model="m", content="ok", status="ok", details={})

    completion = await resolve_turn_completion(
        req=KernelRequest(payload={"message": "m"}),
        trace_id="trace-3",
        session_id="session-3",
        raw_message="m",
        resolved_mode="analysis",
        mode_source="manual",
        effective_command="generate_analysis",
        retrieved_knowledge=[],
        enriched_payload={"x": 1},
        runtime_snapshot={},
        orchestration_status={},
        instance_profile={"product_name": "p"},
        resolve_guided_orchestrated_completion_fn=lambda **_: None,
        should_force_requirement_clarification_fn=lambda *_args, **_kwargs: False,
        build_requirement_clarification_message_fn=lambda message: f"clarify:{message}",
        build_prompt_fn=lambda *_args, **_kwargs: "prompt-x",
        generate_llm_completion_fn=_llm,
    )

    assert completion.provider == "llm"
    assert completion.content == "ok"
