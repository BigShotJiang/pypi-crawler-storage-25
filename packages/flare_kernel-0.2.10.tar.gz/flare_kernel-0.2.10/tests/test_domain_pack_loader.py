from __future__ import annotations

import json
from pathlib import Path

from flare_kernel.runtime.domain.domain_pack_loader import (
    _load_domain_pack_cached,
    load_domain_pack,
    resolve_default_domain,
    resolve_domain_pack_root,
    resolve_domain_pack_domain,
)


def _write_json_yaml(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")


def _build_pack(root: Path, domain: str = "procurement", variant: str | None = None) -> Path:
    pack_root = root / domain
    if variant:
        pack_root = pack_root / variant
    _write_json_yaml(pack_root / "taxonomy.yaml", {"intent_aliases": {"芯片": "chip"}})
    _write_json_yaml(
        pack_root / "fields.yaml",
        {
            "required_fields": ["category", "budget"],
            "field_definitions": [
                {"key": "category", "label": "品类", "priority": "required", "blocker": True},
                {"key": "budget", "label": "预算", "priority": "required", "blocker": True},
                {"key": "cpu_arch", "label": "架构", "priority": "recommended", "blocker": False},
            ],
        },
    )
    _write_json_yaml(
        pack_root / "workflow.yaml",
        {
            "artifact_templates": {
                "requirements_document": {"template": "requirements-document.md"}
            },
            "blocker_policies": {"required_fields": ["category", "budget"], "chooser_on_blocking": True},
            "stages": {
                "requirement_intake": {
                    "next_actions": [
                        {"action_key": "continue_collection", "label": "继续", "priority": 1},
                    ]
                }
            },
        },
    )
    _write_json_yaml(pack_root / "search-mapping.yaml", {"field_mapping": {"cpu_arch": ["cpu 架构 证据"]}})
    _write_json_yaml(pack_root / "replace-rules.yaml", {"allow_auto_replace": True})
    (pack_root / "templates").mkdir(parents=True, exist_ok=True)
    (pack_root / "templates" / "rfx.md").write_text("# RFX", encoding="utf-8")
    (pack_root / "templates" / "requirements-document.md").write_text("# Requirements", encoding="utf-8")
    return pack_root


def test_domain_pack_loader_loads_external_pack(monkeypatch, tmp_path: Path) -> None:
    _build_pack(tmp_path)
    monkeypatch.setenv("FLARE_DOMAIN_PACK_ROOT", str(tmp_path))
    _load_domain_pack_cached.cache_clear()

    pack = load_domain_pack(instance_id="any", domain_pack_version="default", domain="procurement")

    assert pack.domain == "procurement"
    assert pack.version == "default"
    assert pack.capabilities["pack"]["enabled"] is True
    assert pack.capabilities["workflow"]["enabled"] is True
    assert pack.required_fields() == ["category", "budget"]
    assert "rfx.md" in pack.templates
    assert pack.workflow.raw["artifact_templates"]["requirements_document"]["template"] == "requirements-document.md"
    assert pack.templates["requirements-document.md"] == "# Requirements"
    assert any(item.get("layer") == "core_default" for item in pack.resolution_trace)


def test_domain_pack_loader_uses_bundled_pack_when_env_is_absent(monkeypatch) -> None:
    monkeypatch.delenv("FLARE_DOMAIN_PACK_ROOT", raising=False)
    _load_domain_pack_cached.cache_clear()

    root = resolve_domain_pack_root("any")
    pack = load_domain_pack(instance_id="any", domain_pack_version="default", domain="generic")
    field_definitions = pack.fields.get("field_definitions") if isinstance(pack.fields, dict) else []
    budget_field = next(
        (item for item in field_definitions if isinstance(item, dict) and item.get("key") == "budget"),
        {},
    )

    assert root is not None
    assert root.name == "domain-packs"
    assert pack.capabilities["pack"]["enabled"] is True
    assert pack.required_fields()
    assert [item.get("label") for item in budget_field.get("options", [])] == [
        "10万以内",
        "10万-50万",
        "50万-200万",
        "200万以上",
    ]


def test_domain_pack_loader_degrades_when_single_module_missing(monkeypatch, tmp_path: Path) -> None:
    pack_root = _build_pack(tmp_path)
    (pack_root / "search-mapping.yaml").unlink()
    monkeypatch.setenv("FLARE_DOMAIN_PACK_ROOT", str(tmp_path))
    _load_domain_pack_cached.cache_clear()

    pack = load_domain_pack(instance_id="any", domain_pack_version="default", domain="procurement")

    assert pack.capabilities["pack"]["enabled"] is True
    assert pack.capabilities["search_mapping"]["enabled"] is False
    assert "retrieval_mapping_missing" in pack.degrade_reasons


def test_domain_pack_loader_returns_pack_missing_when_variant_not_found(monkeypatch, tmp_path: Path) -> None:
    _build_pack(tmp_path, variant="custom")
    monkeypatch.setenv("FLARE_DOMAIN_PACK_ROOT", str(tmp_path))
    _load_domain_pack_cached.cache_clear()

    pack = load_domain_pack(instance_id="any", domain_pack_version="missing", domain="procurement")

    assert pack.capabilities["pack"]["enabled"] is False
    assert pack.capabilities["pack"]["missing"] is True
    assert "pack_missing" in pack.degrade_reasons


def test_resolve_default_domain_uses_env_override(monkeypatch) -> None:
    monkeypatch.setenv("FLARE_DOMAIN_PACK_DEFAULT_DOMAIN", "example_domain")
    assert resolve_default_domain() == "example_domain"


def test_resolve_domain_pack_domain_prefers_payload_then_profile_then_default(monkeypatch) -> None:
    monkeypatch.setenv("FLARE_DOMAIN_PACK_DEFAULT_DOMAIN", "generic_default")
    assert resolve_domain_pack_domain(payload={"domain_pack_domain": "payload_domain"}) == "payload_domain"
    assert resolve_domain_pack_domain(payload={"domain": "payload_alias"}) == "payload_alias"
    assert resolve_domain_pack_domain(instance_profile={"domain_pack_domain": "profile_domain"}) == "profile_domain"
    assert resolve_domain_pack_domain(instance_profile={"domain": "profile_alias"}) == "profile_alias"
    assert resolve_domain_pack_domain() == "generic_default"


def test_load_domain_pack_prefers_explicit_generic_pack_without_procurement_fallback(monkeypatch, tmp_path: Path) -> None:
    _build_pack(tmp_path, domain="generic")
    monkeypatch.setenv("FLARE_DOMAIN_PACK_ROOT", str(tmp_path))
    monkeypatch.setenv("FLARE_DOMAIN_PACK_DEFAULT_DOMAIN", "generic")
    _load_domain_pack_cached.cache_clear()

    pack = load_domain_pack(instance_id="any", domain_pack_version="default", domain="generic")

    assert pack.domain == "generic"
    assert pack.capabilities["pack"]["enabled"] is True
    assert not any(reason.startswith("legacy_domain_fallback:") for reason in pack.degrade_reasons)


def test_load_domain_pack_returns_missing_pack_when_target_domain_missing(monkeypatch, tmp_path: Path) -> None:
    _build_pack(tmp_path, domain="procurement")
    monkeypatch.setenv("FLARE_DOMAIN_PACK_ROOT", str(tmp_path))
    monkeypatch.setenv("FLARE_DOMAIN_PACK_DEFAULT_DOMAIN", "generic")
    _load_domain_pack_cached.cache_clear()

    pack = load_domain_pack(instance_id="any", domain_pack_version="default", domain="generic")

    assert pack.domain == "generic"
    assert pack.capabilities["pack"]["enabled"] is False
    assert pack.capabilities["pack"]["missing"] is True
    assert "pack_missing" in pack.degrade_reasons


def test_load_domain_pack_emits_resolution_trace_for_profile_layers(monkeypatch, tmp_path: Path) -> None:
    _build_pack(tmp_path)
    monkeypatch.setenv("FLARE_DOMAIN_PACK_ROOT", str(tmp_path))
    _load_domain_pack_cached.cache_clear()

    pack = load_domain_pack(
        instance_id="any",
        domain_pack_version="default",
        domain="procurement",
        payload={"product_profile": {"name": "product-standard"}},
        instance_profile={"tenant_override": {"flags": {"x": True}}},
        tenant_id="tenant-1",
    )

    layers = {str(item.get("layer")): bool(item.get("hit")) for item in pack.resolution_trace}
    assert layers.get("core_default") is True
    assert layers.get("product_profile") is True
    assert layers.get("tenant_override") is True
    assert "tenant_binding" in layers
