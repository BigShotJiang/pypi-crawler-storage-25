from __future__ import annotations

from flare_kernel.router.intake.status.projection import (
    build_active_checkpoint,
    build_field_label_map,
    build_fallback_active_checkpoint,
    build_round_projection,
    build_search_actions,
    build_structured_search_results,
    build_workspace_updates,
    build_workflow_checkpoint_projection,
    compute_procurement_relevance,
)


def test_build_active_checkpoint_returns_empty_without_checkpoint_id() -> None:
    assert build_active_checkpoint({"checkpoint_state": "waiting_user"}) == {}


def test_build_active_checkpoint_maps_fields() -> None:
    payload = build_active_checkpoint(
        {
            "checkpoint_id": "ckpt_1",
            "intake_session_id": "intake_1",
            "checkpoint_type": "intake_question",
            "checkpoint_state": "waiting_user",
            "current_stage": "requirement_intake.collecting",
            "question_key": "budget",
            "ready_for_submit": False,
            "decision_point_active": False,
            "updated_at": "2026-04-10T12:00:00Z",
        }
    )
    assert payload["checkpoint_id"] == "ckpt_1"
    assert payload["intake_session_id"] == "intake_1"
    assert payload["question_key"] == "budget"


def test_build_workflow_checkpoint_projection_emits_server_authority_shape() -> None:
    payload = build_workflow_checkpoint_projection(
        intake_session_id="intake_1",
        session_id="sess_1",
        mode="requirement_intake",
        current_stage="requirement_intake.collecting",
        active_collecting=True,
        ready_for_submit=False,
        decision_point_active=False,
        current_question={"field_key": "budget", "question_text": "预算范围是多少？"},
        confirmed_updates=[{"field_key": "category", "field_value": "基础设施"}],
        required_missing=["budget", "quantity"],
        blocking_reason="缺少关键字段",
        checkpoint_base={"checkpoint_id": "ckpt_1", "updated_at": "2026-04-10T12:00:00Z"},
        question_progress={"current": 1, "total": 8},
        updated_at="2026-04-10T12:00:00Z",
    )
    assert payload["workflow_id"] == "wf_intake_1"
    assert payload["active_checkpoint_id"] == "ckpt_1"
    assert payload["version"] >= 1
    assert payload["status"] in {"waiting_user", "running"}
    assert isinstance(payload["checkpoints"], list)
    assert payload["checkpoints"]
    assert isinstance(payload["checkpoints"][0]["child_tasks"], list)


def test_build_field_label_map_filters_invalid_definitions() -> None:
    mapping = build_field_label_map(
        [
            {"key": "budget", "label": "预算"},
            {"key": "quantity", "label": "数量"},
            {"key": "", "label": "空"},
            "ignored",
        ]
    )
    assert mapping == {"budget": "预算", "quantity": "数量"}


def test_build_search_actions_returns_completed_event_when_retrieval_attempted() -> None:
    actions = build_search_actions(
        retrieval_attempted=True,
        retrieval_queries=["服务器 预算"],
        retrieved_knowledge=[{"id": "k1"}, {"id": "k2"}],
    )
    assert actions == [
        {
            "action": "knowledge_search",
            "queries": ["服务器 预算"],
            "result_count": 2,
            "status": "completed",
        }
    ]


def test_build_structured_search_results_marks_target_field() -> None:
    structured = build_structured_search_results(
        results=[
            {"title": "机型A", "content": "预算20万以内", "score": 0.9, "source_type": "web"},
        ],
        open_fields=[{"field_key": "budget", "priority": "required", "is_current": True}],
    )
    assert len(structured) == 1
    assert structured[0]["matched_field"] == "budget"
    assert structured[0]["confidence"] == 0.9
    assert structured[0]["source"] == "web"
    assert structured[0]["selectable_for_replace"] is True


def test_build_structured_search_results_handles_missing_score() -> None:
    structured = build_structured_search_results(
        results=[{"source_label": "条目", "snippet": "内容"}],
        open_fields=[],
    )
    assert len(structured) == 1
    assert structured[0]["confidence"] == 0.0
    assert structured[0]["matched_field"] == ""
    assert structured[0]["selectable_for_replace"] is False


def test_build_fallback_active_checkpoint_uses_waiting_user_when_question_exists() -> None:
    checkpoint = build_fallback_active_checkpoint(
        intake_session_id="intake_1",
        current_question={"field_key": "budget"},
        ready_for_submit=False,
        decision_point_active=False,
        current_stage="requirement_intake.collecting",
        updated_at="2026-04-10T12:00:00Z",
    )
    assert checkpoint["checkpoint_state"] == "waiting_user"
    assert checkpoint["question_key"] == "budget"


def test_build_workspace_updates_projects_workspace_flags() -> None:
    updates = build_workspace_updates(
        retrieval_attempted=True,
        retrieved_knowledge_count=2,
        confirmed_updates=[{"field_key": "category"}],
        open_fields=[{"field_key": "budget"}],
    )
    assert updates["search_workspace"]["updated"] is True
    assert updates["requirement_workspace"]["pending_fields"] == ["budget"]


def test_compute_procurement_relevance_recognizes_intake_modes() -> None:
    assert compute_procurement_relevance(resolved_intent="qa_only", resolved_mode="requirement_intake") is True
    assert compute_procurement_relevance(resolved_intent="chat", resolved_mode="chat") is False


def test_build_round_projection_collecting_uses_question_progress() -> None:
    projection = build_round_projection(
        intake_session_id="intake_1",
        stage_key="requirement_intake",
        status_key="collecting",
        intake_session_state="workspace_live_updating",
        current_question={"field_key": "scope", "step_index": 2, "step_total": 4},
        checkpoint={},
        next_actions=[{"action_key": "continue_collection"}],
    )
    assert projection["round_id"] == "intake_1"
    assert projection["round_state"] == "collecting"
    assert projection["round_question_index"] == 2
    assert projection["round_question_total"] == 4
    assert projection["round_interruptible"] is True
    assert projection["round_completed"] is False


def test_build_round_projection_ready_for_submit_marks_round_completed() -> None:
    projection = build_round_projection(
        intake_session_id="intake_1",
        stage_key="requirement_intake",
        status_key="ready_for_submit",
        intake_session_state="analysis_ready",
        current_question=None,
        checkpoint={
            "checkpoints": [
                {
                    "question_progress": {
                        "current": 3,
                        "total": 3,
                    }
                }
            ]
        },
        next_actions=[{"action_key": "confirm_plan"}, {"action_key": "handoff_to_sourcing"}],
    )
    assert projection["round_state"] == "completed"
    assert projection["round_completed"] is True
    assert projection["round_question_index"] == 3
    assert projection["round_question_total"] == 3
    assert projection["next_recommendations"] == ["confirm_plan", "handoff_to_sourcing"]


def test_build_round_projection_uses_checkpoint_seq_for_round_id_and_dedupes_recommendations() -> None:
    projection = build_round_projection(
        intake_session_id="intake_1",
        stage_key="requirement_intake",
        status_key="collecting",
        intake_session_state="workspace_live_updating",
        current_question={"field_key": "scope", "step_index": 1, "step_total": 3},
        checkpoint={
            "checkpoints": [
                {
                    "seq": 2,
                }
            ]
        },
        next_actions=[
            {"action_key": "continue_collection"},
            {"action_key": "continue_collection"},
            {"action_key": "handoff_to_sourcing"},
        ],
    )
    assert projection["round_id"] == "intake_1:r2"
    assert projection["next_recommendations"] == ["continue_collection", "handoff_to_sourcing"]


def test_build_round_projection_marks_interrupted_state() -> None:
    projection = build_round_projection(
        intake_session_id="intake_1",
        stage_key="requirement_intake",
        status_key="collecting",
        intake_session_state="interrupted_by_user",
        current_question=None,
        checkpoint={},
        next_actions=[],
    )
    assert projection["round_state"] == "interrupted"
    assert projection["round_interruptible"] is False
