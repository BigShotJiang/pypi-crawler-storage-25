from __future__ import annotations

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.completion.guided import resolve_guided_orchestrated_completion


def test_resolve_guided_orchestrated_completion_allows_main_chain_in_collecting_send() -> None:
    completion = resolve_guided_orchestrated_completion(
        req=KernelRequest(payload={"message": "预算"}),
        command="send_message",
        resolved_mode="requirement_intake",
        mode_source="manual",
        runtime_snapshot={
            "mode_events": [
                {
                    "event_type": "next_actions",
                    "payload": {
                        "flow_state": "collecting",
                        "current_question": {"field_key": "budget", "question_text": "预算范围？", "step_index": 1, "step_total": 3},
                        "intake_understanding": {
                            "understood_context": {"object_type": "服务器", "use_case": "测试开发"},
                            "current_best_next_question": {"question_text": "预算范围？"},
                            "candidate_information_gaps": [{"key": "budget"}],
                            "analyzability_score": 0.35,
                            "analysis_entry_threshold": 0.8,
                        },
                    },
                }
            ]
        },
        orchestration_status={
            "current_stage": "requirement_intake.collecting",
            "current_question": {"field_key": "budget", "question_text": "预算范围？"},
            "chooser_state": {"kind": "question", "visible": True},
        },
    )
    assert completion is None


def test_guided_completion_allows_main_chain_for_info_requests_during_intake() -> None:
    completion = resolve_guided_orchestrated_completion(
        req=KernelRequest(payload={"message": "我想找上海的活动供应商，需要给你哪些数据？"}),
        command="send_message",
        resolved_mode="requirement_intake",
        mode_source="intent",
        runtime_snapshot={
            "mode_events": [
                {
                    "event_type": "next_actions",
                    "payload": {
                        "flow_state": "collecting",
                        "current_question": {
                            "field_key": "use_case",
                            "question_text": "活动类型是什么？",
                            "step_index": 1,
                            "step_total": 3,
                        },
                        "intake_understanding": {
                            "raw_user_goal": "我想找上海的活动供应商，需要给你哪些数据？",
                            "understood_context": {},
                            "current_best_next_question": {"question_text": "活动类型是什么？"},
                            "candidate_information_gaps": [{"key": "use_case"}],
                            "analyzability_score": 0.35,
                            "analysis_entry_threshold": 0.8,
                        },
                    },
                }
            ]
        },
        orchestration_status={
            "current_stage": "requirement_intake.collecting",
            "chooser_state": {"kind": "question", "visible": True},
        },
    )

    assert completion is None


def test_guided_completion_allows_main_chain_for_normal_intake_send() -> None:
    completion = resolve_guided_orchestrated_completion(
        req=KernelRequest(payload={"message": "公司20周年需要在上海办一次盛大的周年庆，除了活动还需要购买周年庆礼品。"}),
        command="send_message",
        resolved_mode="requirement_intake",
        mode_source="intent",
        runtime_snapshot={
            "mode_events": [
                {
                    "event_type": "next_actions",
                    "payload": {
                        "flow_state": "collecting",
                        "current_question": {
                            "field_key": "constraints",
                            "question_text": "你希望这次周年庆优先突出什么目标？",
                            "step_index": 1,
                            "step_total": 3,
                        },
                        "intake_understanding": {
                            "raw_user_goal": "公司20周年需要在上海办一次盛大的周年庆，除了活动还需要购买周年庆礼品。",
                            "understood_context": {},
                            "current_best_next_question": {"question_text": "你希望这次周年庆优先突出什么目标？"},
                            "candidate_information_gaps": [{"key": "constraints"}],
                            "analyzability_score": 0.35,
                            "analysis_entry_threshold": 0.8,
                        },
                    },
                }
            ]
        },
        orchestration_status={
            "current_stage": "requirement_intake.collecting",
            "chooser_state": {"kind": "question", "visible": True},
        },
    )

    assert completion is None


def test_resolve_guided_orchestrated_completion_allows_main_chain_without_visible_runtime_state() -> None:
    completion = resolve_guided_orchestrated_completion(
        req=KernelRequest(payload={"message": "预算"}),
        command="send_message",
        resolved_mode="requirement_intake",
        mode_source="manual",
        runtime_snapshot={},
        orchestration_status={
            "current_stage": "requirement_intake.collecting",
            "chooser_state": {"kind": "question", "visible": True},
        },
    )
    assert completion is None


def test_resolve_guided_orchestrated_completion_stays_patch_only_for_explicit_intake_submit() -> None:
    completion = resolve_guided_orchestrated_completion(
        req=KernelRequest(payload={"message": "预算"}),
        command="submit_intake_answer",
        resolved_mode="requirement_intake",
        mode_source="manual",
        runtime_snapshot={},
        orchestration_status={
            "current_stage": "requirement_intake.collecting",
            "chooser_state": {"kind": "question", "visible": True},
        },
    )
    assert completion is not None
    assert completion.details["reason"] == "guided_session_patch_only"
    assert completion.content == ""
    assert completion.details["patch_only_score"] > completion.details["main_chain_score"]


def test_resolve_guided_orchestrated_completion_allows_main_chain_for_empty_command_message() -> None:
    completion = resolve_guided_orchestrated_completion(
        req=KernelRequest(payload={"message": "补充：预算 80 万以内"}),
        command="",
        resolved_mode="requirement_intake",
        mode_source="manual",
        runtime_snapshot={},
        orchestration_status={
            "current_stage": "requirement_intake.blocked",
            "current_question": {"field_key": "use_case", "question_text": "主要使用场景是什么？"},
            "has_active_question": True,
        },
    )
    assert completion is None


def test_resolve_guided_orchestrated_completion_does_not_block_analysis_generation() -> None:
    completion = resolve_guided_orchestrated_completion(
        req=KernelRequest(payload={"message": "预算"}),
        command="generate_analysis",
        resolved_mode="requirement_intake",
        mode_source="manual",
        runtime_snapshot={},
        orchestration_status={
            "current_stage": "requirement_intake.collecting",
            "current_question": {"field_key": "budget", "question_text": "预算范围？"},
        },
    )
    assert completion is None


def test_resolve_guided_orchestrated_completion_ignores_legacy_requirement_intake_question_branch() -> None:
    completion = resolve_guided_orchestrated_completion(
        req=KernelRequest(payload={"message": "继续完善提示词"}),
        command="submit_intake_answer",
        resolved_mode="requirement_intake",
        mode_source="manual",
        runtime_snapshot={},
        orchestration_status={
            "current_question": {
                "field_key": "scenario",
                "question_kind": "followup",
                "question_text": "围绕“采购服务器”，这次主要面向什么场景、对象或任务范围？",
                "visible_response_text": "当前目标已确认：采购服务器。\n我先确认一个会影响后续判断的问题。\n围绕“采购服务器”，这次主要面向什么场景、对象或任务范围？\n如果选项都不贴切，直接补充你的真实情况即可。",
            },
            "removed_canvas_draft": {
                "content": "建议框架:\n- 目标：采购服务器\n- 适用场景：质量优先"
            },
            "chooser_state": {"kind": "question", "visible": True},
        },
    )
    assert completion is None


def test_resolve_guided_orchestrated_completion_requirement_intake_allows_apply_command() -> None:
    completion = resolve_guided_orchestrated_completion(
        req=KernelRequest(payload={"message": "按最新提示词执行"}),
        command="apply",
        resolved_mode="requirement_intake",
        mode_source="manual",
        runtime_snapshot={},
        orchestration_status={
            "current_question": {
                "field_key": "intake_context",
                "question_kind": "followup",
                "question_text": "请补充约束",
            },
            "chooser_state": {"kind": "question", "visible": True},
        },
    )
    assert completion is None


def test_resolve_guided_orchestrated_completion_ignores_legacy_requirement_intake_reviewing_branch() -> None:
    completion = resolve_guided_orchestrated_completion(
        req=KernelRequest(payload={"message": "按当前草稿继续"}),
        command="send_message",
        resolved_mode="requirement_intake",
        mode_source="manual",
        runtime_snapshot={},
        orchestration_status={
            "mode_state": "reviewing",
            "message_excerpt": "采购复杂活动项目",
            "removed_session_state": {"goal": "采购复杂活动项目"},
            "removed_apply_handoff": {"ready": False},
            "next_actions": [{"action_key": "implement", "label": "进入 Implement"}],
        },
    )
    assert completion is None
