from __future__ import annotations

from flare_kernel.router.intake.status.chooser_stage import (
    build_status_chooser,
    pick_next_action,
    resolve_current_stage,
)
from flare_kernel.router.orchestration.status.actions import normalize_status_stage_and_actions


def test_pick_next_action_prefers_available_item() -> None:
    result = pick_next_action(
        {
            "actions": [
                {"action_key": "handoff_to_sourcing", "status": "blocked"},
                {"action_key": "continue_collection", "status": "available", "target_field": "budget"},
            ]
        }
    )
    assert result["action_key"] == "continue_collection"
    assert result["target_field"] == "budget"


def test_build_status_chooser_includes_other_input_fallback() -> None:
    chooser = build_status_chooser(
        current_question={
            "field_key": "budget",
            "question_text": "预算范围？",
            "options": ["20万以内", "20-50万"],
        },
        next_actions_payload={
            "actions": [
                {"action_key": "continue_collection", "blocking_reason": "预算缺失"},
            ]
        },
        open_fields=[{"field_key": "budget", "priority": "required", "is_current": True}],
        retrieval_attempted=True,
        retrieval_hits=2,
    )
    assert chooser is not None
    assert chooser["target_field"] == "budget"
    assert chooser["blocking_reason"] == "预算缺失"
    assert chooser["recommended_option_key"] == "option_1"
    assert any(item["key"] == "other_input" for item in chooser["options"])


def test_resolve_current_stage_follows_requirement_intake_priority() -> None:
    assert resolve_current_stage(
        mode_key="requirement_intake",
        mode_state="drafting",
        open_fields=[],
        chooser=None,
    ) == "requirement_analysis"
    assert resolve_current_stage(
        mode_key="requirement_intake",
        mode_state="collecting",
        open_fields=[{"field_key": "budget"}],
        chooser={"target_field": "budget"},
    ) == "focused_clarifying"
    assert resolve_current_stage(
        mode_key="intelligent_sourcing",
        mode_state="running",
        open_fields=[],
        chooser=None,
    ) == "compare_replace"


def test_collecting_status_keeps_intake_optional_when_context_is_empty() -> None:
    stage, payload, actions = normalize_status_stage_and_actions(
        current_stage="requirement_intake.collecting",
        decision_payload={},
        resolved_actions=[],
        normalized_required_missing=["budget"],
        current_question={"field_key": "budget"},
    )

    assert stage == "requirement_intake.collecting"
    assert payload["chooser_required"] is False
    assert payload["auxiliary_mode_optional"] is True
    assert actions[0]["label"] == "可选梳理需求"
    assert actions[0]["optional"] is True
    assert actions[0]["readiness_level"] == "recommended"
    assert [item["action_key"] for item in actions] == ["continue_collection"]


def test_collecting_status_does_not_surface_hidden_existing_analysis_action() -> None:
    _stage, payload, actions = normalize_status_stage_and_actions(
        current_stage="requirement_intake.collecting",
        decision_payload={},
        resolved_actions=[{"action_key": "confirm_plan", "status": "available"}],
        normalized_required_missing=["budget"],
        current_question={"field_key": "budget"},
        fields={},
    )

    assert payload["analysis_entry_decision"]["entry_level"] == "hidden"
    assert [item["action_key"] for item in actions] == ["continue_collection"]


def test_collecting_status_adds_optional_analysis_and_sourcing_when_context_exists() -> None:
    _stage, _payload, actions = normalize_status_stage_and_actions(
        current_stage="requirement_intake.collecting",
        decision_payload={},
        resolved_actions=[],
        normalized_required_missing=["budget"],
        current_question={"field_key": "budget"},
        fields={"category": "服务器"},
    )

    assert [item["action_key"] for item in actions] == [
        "continue_collection",
        "confirm_plan",
        "handoff_to_sourcing",
    ]
    assert actions[1]["readiness_level"] == "available"
    assert actions[2]["source"] == "action_readiness"
