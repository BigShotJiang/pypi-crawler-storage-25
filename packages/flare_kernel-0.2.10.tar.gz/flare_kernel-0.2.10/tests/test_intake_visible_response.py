from __future__ import annotations

from flare_kernel.runtime.reasoning.intake.api import build_user_visible_intake_response


def test_visible_intake_response_structures_long_prompt_summary() -> None:
    response = build_user_visible_intake_response(
        understanding_state={
            "raw_user_goal": (
                "我想启动服务器供应商寻源，需要一份候选清单。预算大概 50 万以内，"
                "数量预计 20 台，主要用于 AI 推理测试，希望先给出可推进的需求摘要和缺口。"
            ),
            "understood_context": {"context_phrase": "服务器供应商寻源"},
            "current_best_next_question": {
                "question_key": "use_case",
                "question_text": "主要使用场景是什么？",
            },
        },
        current_question={
            "field_key": "use_case",
            "question_text": "主要使用场景是什么？",
        },
        confirmed_fields={
            "goal": "服务器供应商候选清单",
            "budget": "50 万以内",
            "quantity": "20 台",
        },
        missing_fields=["use_case", "constraints"],
        field_definitions_by_key={
            "goal": {"label": "目标"},
            "budget": {"label": "预算"},
            "quantity": {"label": "数量"},
            "use_case": {"label": "使用场景"},
            "constraints": {"label": "关键约束"},
        },
        readiness={"analysis_entry_eligible": False},
    )

    assert "已确认信息：" in response
    assert "目标：服务器供应商候选清单" in response
    assert "预算：50 万以内" in response
    assert "数量：20 台" in response
    assert "关键缺口：" in response
    assert "使用场景：待确认" in response
    assert "关键约束：待确认" in response
    assert "下一步动作：" in response
    assert "主要使用场景是什么？" in response
    assert "先给一个可推进的初步版本" not in response
