from __future__ import annotations

from flare_kernel.router.intake.workflow_checkpoint import (
    build_workflow_checkpoint_projection,
)


def test_build_workflow_checkpoint_projection_returns_empty_without_checkpoint_id_or_session() -> None:
    payload = build_workflow_checkpoint_projection(
        intake_session_id="",
        session_id="s1",
        mode="requirement_intake",
        current_stage="requirement_intake.collecting",
        active_collecting=True,
        ready_for_submit=False,
        decision_point_active=False,
        current_question=None,
        confirmed_updates=[],
        required_missing=["budget"],
        blocking_reason="",
    )

    assert payload == {}
