from __future__ import annotations

from types import SimpleNamespace

from flare_kernel.router.intake.status.schema import (
    build_confirmed_fields_schema,
    build_missing_fields_schema,
    coerce_intent_escalation_policy,
    normalize_stage_status,
    resolve_intent_escalation_policy_with_source,
)


def test_build_confirmed_and_missing_schema_outputs() -> None:
    confirmed = build_confirmed_fields_schema(
        fields={"budget": "50万"},
        field_entities={"budget": {"display_value": "50万", "confidence": 0.8}},
    )
    missing = build_missing_fields_schema(["quantity"])
    assert confirmed["budget"]["value"] == "50万"
    assert confirmed["budget"]["confidence"] == 0.8
    assert missing["required"][0]["field_key"] == "quantity"


def test_normalize_stage_status_enforces_auto_idle_state() -> None:
    stage, status = normalize_stage_status(
        current_stage="requirement_intake.collecting",
        required_missing=["budget"],
        activated_mode="auto",
        question={"field_key": "budget"},
        command="send_message",
        has_analysis_content=False,
        flow_allowed_statuses_by_stage={
            "general_chat": {"idle", "error"},
            "requirement_intake": {"collecting", "blocked", "ready_for_submit", "error"},
            "requirement_analysis": {"active", "completed", "error"},
        },
    )
    assert stage == "general_chat"
    assert status == "idle"


def test_normalize_stage_status_keeps_collecting_when_current_question_exists() -> None:
    stage, status = normalize_stage_status(
        current_stage="requirement_intake.collecting",
        required_missing=[],
        activated_mode="requirement_intake",
        question={"field_key": "use_case", "question_text": "请补充使用场景"},
        command="send_message",
        has_analysis_content=False,
        flow_allowed_statuses_by_stage={
            "general_chat": {"idle", "error"},
            "requirement_intake": {"collecting", "blocked", "ready_for_submit", "error"},
            "requirement_analysis": {"active", "completed", "error"},
        },
    )
    assert stage == "requirement_intake"
    assert status == "collecting"


def test_normalize_stage_status_allows_ready_for_submit_when_entry_is_eligible() -> None:
    stage, status = normalize_stage_status(
        current_stage="requirement_intake.collecting",
        required_missing=["parameters"],
        activated_mode="requirement_intake",
        question=None,
        command="send_message",
        has_analysis_content=False,
        analysis_entry_eligible=True,
        flow_allowed_statuses_by_stage={
            "general_chat": {"idle", "error"},
            "requirement_intake": {"collecting", "blocked", "ready_for_submit", "error"},
            "requirement_analysis": {"active", "completed", "error"},
        },
    )
    assert stage == "requirement_intake"
    assert status == "ready_for_submit"


def test_coerce_intent_escalation_policy_clamps_thresholds() -> None:
    policy = coerce_intent_escalation_policy(
        {
            "recommendation_min_confidence": 2,
            "auto_mode_override_min_confidence": -1,
        },
        default_policy={
            "enable_recommendation_trigger": True,
            "enable_auto_mode_override": True,
            "recommendation_min_confidence": 0.58,
            "auto_mode_override_min_confidence": 0.72,
            "require_domain_relevance_for_recommendation": True,
            "require_domain_relevance_for_auto_override": True,
        },
    )
    assert policy["recommendation_min_confidence"] == 1.0
    assert policy["auto_mode_override_min_confidence"] == 0.0


def test_resolve_intent_escalation_policy_with_source_prefers_payload_override() -> None:
    default_policy = {
        "enable_recommendation_trigger": True,
        "enable_auto_mode_override": True,
        "recommendation_min_confidence": 0.58,
        "auto_mode_override_min_confidence": 0.72,
        "require_domain_relevance_for_recommendation": True,
        "require_domain_relevance_for_auto_override": True,
    }
    req = SimpleNamespace(
        instance_id="demo",
        domain_pack_version="default",
        payload={
            "intent_escalation_policy": {
                "recommendation_min_confidence": 0.66,
            }
        },
    )
    domain_pack = SimpleNamespace(
        workflow=SimpleNamespace(
            raw={
                "intent_escalation_policy": {
                    "recommendation_min_confidence": 0.6,
                }
            }
        )
    )

    policy, source = resolve_intent_escalation_policy_with_source(
        req=req,
        runtime_snapshot=None,
        default_policy=default_policy,
        coerce_intent_escalation_policy_fn=lambda raw: coerce_intent_escalation_policy(
            raw,
            default_policy=default_policy,
        ),
        load_domain_pack_fn=lambda **_kwargs: domain_pack,
    )
    assert source == "payload_override"
    assert policy["recommendation_min_confidence"] == 0.66


def test_resolve_intent_escalation_policy_with_source_uses_payload_domain_hook() -> None:
    captured: dict[str, str] = {}
    default_policy = {
        "enable_recommendation_trigger": True,
        "enable_auto_mode_override": True,
        "recommendation_min_confidence": 0.58,
        "auto_mode_override_min_confidence": 0.72,
        "require_domain_relevance_for_recommendation": False,
        "require_domain_relevance_for_auto_override": False,
    }
    req = SimpleNamespace(
        instance_id="demo",
        domain_pack_version="default",
        payload={"domain_pack_domain": "custom_domain"},
    )

    def _fake_load_domain_pack(**kwargs):
        captured["domain"] = kwargs.get("domain")
        return SimpleNamespace(workflow=None)

    resolve_intent_escalation_policy_with_source(
        req=req,
        runtime_snapshot=None,
        default_policy=default_policy,
        coerce_intent_escalation_policy_fn=lambda raw: coerce_intent_escalation_policy(raw, default_policy=default_policy),
        load_domain_pack_fn=_fake_load_domain_pack,
    )
    assert captured["domain"] == "custom_domain"


def test_coerce_intent_escalation_policy_uses_domain_keys_and_accepts_legacy_input() -> None:
    policy = coerce_intent_escalation_policy(
        {
            "require_domain_relevance_for_recommendation": True,
            "require_domain_relevance_for_auto_override": False,
            "require_procurement_relevance_for_recommendation": False,
            "require_procurement_relevance_for_auto_override": True,
        },
        default_policy={
            "enable_recommendation_trigger": True,
            "enable_auto_mode_override": True,
            "recommendation_min_confidence": 0.58,
            "auto_mode_override_min_confidence": 0.72,
            "require_domain_relevance_for_recommendation": False,
            "require_domain_relevance_for_auto_override": False,
        },
    )
    assert policy["require_domain_relevance_for_recommendation"] is False
    assert policy["require_domain_relevance_for_auto_override"] is True
    assert "require_procurement_relevance_for_recommendation" not in policy
    assert "require_procurement_relevance_for_auto_override" not in policy
