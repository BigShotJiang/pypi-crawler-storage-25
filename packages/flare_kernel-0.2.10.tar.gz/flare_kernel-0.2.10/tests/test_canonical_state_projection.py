from __future__ import annotations

from flare_kernel.router.canonical.projection import (
    apply_analysis_and_retrieval_projection,
    build_checkpoint_projection,
    build_next_actions_projection,
    collect_confirmed_field_values,
    resolve_analysis_readiness_metrics,
)


def test_collect_confirmed_field_values_uses_confirmed_updates_and_entities() -> None:
    orchestration_status = {
        "confirmed_updates": [
            {"field_key": "budget", "field_value": "100w"},
        ],
        "field_entities": {
            "budget": {"display_value": "should_not_override"},
            "quantity": {"display_value": "20 台", "status": "confirmed"},
            "delivery_time": {"display_value": "Q3", "status": "draft"},
        },
    }

    fields, entities = collect_confirmed_field_values(
        orchestration_status=orchestration_status,
        is_field_entity_confirmed_fn=lambda entity: entity.get("status") == "confirmed",
    )

    assert fields == {"budget": "100w", "quantity": "20 台"}
    assert isinstance(entities, dict)


def test_resolve_analysis_readiness_metrics_uses_threshold_fallback() -> None:
    metrics = resolve_analysis_readiness_metrics(
        {
            "total_coverage": "0.91",
            "required_coverage": "0.75",
            "analysis_entry_threshold": "",
            "analyzability_score": 0.5,
        }
    )

    assert metrics["total_coverage"] == 0.91
    assert metrics["required_coverage"] == 0.75
    assert metrics["analysis_entry_threshold"] == 0.8
    assert metrics["analysis_entry_eligible"] is True


def test_build_checkpoint_projection_returns_empty_without_checkpoint_id() -> None:
    checkpoint = build_checkpoint_projection(
        orchestration_status={},
        intake_session_id="intake_1",
        status_key="collecting",
        current_question={"field_key": "budget", "question_text": "预算是多少？"},
        fields={"budget": "100w"},
        required_missing=["quantity"],
        session_id="sess_1",
        activated_mode="requirement_intake",
    )

    assert checkpoint == {}


def test_apply_analysis_and_retrieval_projection_populates_sections_and_rows() -> None:
    canonical = {
        "analysis": {"sections": []},
        "capabilities": {"field_retrieval": {"comparison_rows": [], "recommendation_summary": ""}},
    }
    apply_analysis_and_retrieval_projection(
        canonical=canonical,
        command="generate_analysis",
        can_generate=True,
        assistant_text="分析内容",
        normalized_retrieved_knowledge=[
            {"title": "证据A", "snippet": "A"},
            {"title": "证据B", "snippet": "B"},
        ],
    )

    assert len(canonical["analysis"]["sections"]) == 2
    assert len(canonical["capabilities"]["field_retrieval"]["comparison_rows"]) == 2
    assert "2 条候选证据" in canonical["capabilities"]["field_retrieval"]["recommendation_summary"]


def test_build_next_actions_projection_maps_neutral_domain_action_aliases() -> None:
    projection = build_next_actions_projection(
        orchestration_status={
            "next_actions": [
                {"action_key": "handoff_to_domain_flow", "label": "进入领域流程", "status": "available", "target_mode": "intelligent_sourcing"},
                {"action_key": "confirm_domain_flow", "label": "确认领域流程", "status": "available", "target_mode": "intelligent_sourcing"},
            ]
        },
        intake_session_id="intake_1",
        intake_session_state="collecting",
        intake_session_completed=False,
        status_key="ready_for_submit",
        map_external_mode_fn=lambda value: value,
    )
    assert projection[0]["command"] == "send_message"
    assert projection[1]["command"] == "send_message"


def test_build_next_actions_projection_preserves_action_basis_fields() -> None:
    projection = build_next_actions_projection(
        orchestration_status={
            "next_actions": [
                {
                    "action_key": "continue_collection",
                    "label": "继续补充字段",
                    "status": "available",
                    "target_mode": "requirement_intake",
                    "reason": "预算字段仍未确认",
                    "source": "intake_policy",
                    "target_field": "budget",
                    "confidence": 0.9,
                },
            ]
        },
        intake_session_id="intake_1",
        intake_session_state="collecting",
        intake_session_completed=False,
        status_key="collecting",
        map_external_mode_fn=lambda value: value,
    )

    assert projection[0]["reason"] == "预算字段仍未确认"
    assert projection[0]["source"] == "intake_policy"
    assert projection[0]["target_field"] == "budget"
    assert projection[0]["confidence"] == 0.9


def test_build_next_actions_projection_uses_readiness_not_collecting_hard_filter() -> None:
    projection = build_next_actions_projection(
        orchestration_status={
            "next_actions": [
                {
                    "action_key": "confirm_plan",
                    "label": "开始需求分析",
                    "status": "available",
                    "readiness_level": "available",
                },
                {
                    "action_key": "blocked_plan",
                    "label": "隐藏分析",
                    "status": "available",
                    "readiness_level": "hidden",
                    "command": "generate_analysis",
                },
            ]
        },
        intake_session_id="intake_1",
        intake_session_state="collecting",
        intake_session_completed=False,
        status_key="collecting",
        map_external_mode_fn=lambda value: value,
    )

    assert [item["action_key"] for item in projection] == ["confirm_plan"]
    assert projection[0]["command"] == "generate_analysis"


def test_build_next_actions_projection_stops_after_intake_completed() -> None:
    projection = build_next_actions_projection(
        orchestration_status={
            "next_actions": [
                {
                    "action_key": "continue_collection",
                    "label": "继续梳理",
                    "status": "available",
                },
                {
                    "action_key": "implement",
                    "label": "确认当前梳理",
                    "status": "available",
                },
            ]
        },
        intake_session_id="intake_1",
        intake_session_state="applied",
        intake_session_completed=True,
        status_key="applied",
        map_external_mode_fn=lambda value: value,
    )

    assert projection == []
