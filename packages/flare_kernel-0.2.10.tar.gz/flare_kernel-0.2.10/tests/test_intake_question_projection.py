from __future__ import annotations

from flare_kernel.runtime.orchestration.mode.intake_question import build_intake_question


def test_intake_question_projection_normalizes_options_and_aligns_decision() -> None:
    result = build_intake_question(
        payload={},
        intake_session_id="intake-1",
        missing=["quantity"],
        reasoning_state={"confirmed_fields": {}, "latest_input": "我要采购服务器"},
        domain_context={
            "required_fields": ["use_case", "quantity"],
            "field_definitions": [
                {"key": "use_case", "label": "使用场景", "priority": "required"},
                {
                    "key": "quantity",
                    "label": "数量",
                    "priority": "required",
                    "options": ["10台以内", "50台以上"],
                },
            ],
            "field_semantics": {"quantity": {"value_type": "quantity"}},
        },
        hypotheses=[],
        field_selection={
            "active_fields": ["use_case", "quantity"],
            "field_scores": {"use_case": 100, "quantity": 10},
        },
        structured_reasoning={
            "question_planner": {
                "next_question": {
                    "question_key": "use_case",
                    "question_text": "主要使用场景是什么？",
                    "target_field_keys": ["use_case"],
                    "why_now": "structured_model",
                }
            }
        },
        understanding_state={},
        field_definitions_by_key={
            "use_case": {"key": "use_case", "label": "使用场景", "priority": "required"},
            "quantity": {
                "key": "quantity",
                "label": "数量",
                "priority": "required",
                "options": ["10台以内", "50台以上"],
            },
        },
    )

    question = result["current_question"]
    assert question["field_key"] == "quantity"
    assert question["options"] == [
        {
            "key": "option_1",
            "label": "10台以内",
            "value": "10台以内",
            "followup_hint": "",
            "requires_custom_input": False,
            "activates_fields": [],
            "suppresses_fields": [],
        },
        {
            "key": "option_2",
            "label": "50台以上",
            "value": "50台以上",
            "followup_hint": "",
            "requires_custom_input": False,
            "activates_fields": [],
            "suppresses_fields": [],
        },
    ]
    assert result["question_decision"]["selected_field_key"] == "quantity"
