from __future__ import annotations

from flare_kernel.router.intake.status.guided_session import (
    build_confirmed_updates,
    build_guided_session_status,
    build_guided_session_summary,
    build_intake_followup_state,
    build_open_fields,
    resolve_guided_session_flags,
)


def test_build_open_fields_marks_current_field() -> None:
    result = build_open_fields(
        required_missing=["budget", "quantity"],
        current_question={"field_key": "budget"},
    )
    assert result == [
        {"field_key": "budget", "priority": "required", "is_current": True},
        {"field_key": "quantity", "priority": "required", "is_current": False},
    ]


def test_build_confirmed_updates_filters_empty_values() -> None:
    result = build_confirmed_updates(
        {
            "category": "服务器",
            "budget": "",
            "quantity": None,
            "delivery_location": "上海园区",
        }
    )
    assert result == [
        {"field_key": "category", "field_value": "服务器"},
        {"field_key": "delivery_location", "field_value": "上海园区"},
    ]


def test_build_guided_session_summary_uses_field_labels() -> None:
    summary = build_guided_session_summary(
        confirmed_updates=[{"field_key": "category", "field_value": "服务器"}],
        field_label_map={"category": "类别"},
    )
    assert "类别：服务器" in summary


def test_build_guided_session_status_sets_summary_ready() -> None:
    status = build_guided_session_status(
        resolved_mode="requirement_intake",
        current_stage="requirement_intake.ready_for_submit",
        command="send_message",
        current_question=None,
        required_fields=["category", "budget"],
        required_missing=[],
        confirmed_updates=[{"field_key": "category", "field_value": "服务器"}],
        next_actions=[{"action_key": "confirm_plan"}],
        active_collecting=False,
        ready_for_submit=True,
        decision_point_active=False,
        field_label_map={"category": "类别"},
    )
    assert status["state"] == "summary_ready"
    assert status["summary"]["ready"] is True
    assert "类别：服务器" in status["summary"]["text"]


def test_build_intake_followup_state_transitions_to_analysis_ready() -> None:
    state = build_intake_followup_state(
        trace_id="trace-1",
        intake_session_id="intake_1",
        resolved_mode="requirement_intake",
        current_stage="requirement_intake.ready_for_submit",
        current_question=None,
        required_fields=["category", "budget"],
        required_missing=[],
        fields={"category": "服务器", "budget": "20万以内"},
        next_actions=[{"action_key": "confirm_plan", "status": "available"}],
        command="send_message",
        has_analysis_content=False,
    )
    assert state["intake_session_state"] == "analysis_ready"
    assert state["analysis_ready"] is True
    assert state["followup_status"] == "converged"
    assert state["next_user_action"] == "confirm_plan"


def test_resolve_guided_session_flags_marks_ready_for_submit() -> None:
    flags = resolve_guided_session_flags(
        current_stage="requirement_intake.ready_for_submit",
        required_missing=[],
        current_question=None,
        command="send_message",
    )
    assert flags["ready_for_submit"] is True
    assert flags["decision_point_active"] is True
