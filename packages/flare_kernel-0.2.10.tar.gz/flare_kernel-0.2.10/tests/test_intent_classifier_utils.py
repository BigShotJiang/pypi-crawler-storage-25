from __future__ import annotations

from flare_kernel.router.kernel_constants import INTENT_KEYWORDS
from flare_kernel.router.intent.classifier_utils import (
    build_intent_classifier_prompt,
    build_keyword_suggestion,
    coerce_suggestable_mode,
    extract_json_object,
    infer_intent_by_keywords,
)


def test_infer_intent_by_keywords_matches_first_intent() -> None:
    intent = infer_intent_by_keywords(
        "请先检索证据",
        intent_keywords={
            "requirement_intake": ("梳理",),
            "intelligent_sourcing": ("检索", "证据"),
        },
    )
    assert intent == "intelligent_sourcing"


def test_coerce_suggestable_mode_normalizes_unknown_to_default() -> None:
    assert (
        coerce_suggestable_mode("requirement_intake", suggestable_modes={"default", "requirement_intake"})
        == "requirement_intake"
    )
    assert coerce_suggestable_mode("unknown", suggestable_modes={"default", "requirement_intake"}) == "default"


def test_extract_json_object_parses_embedded_json() -> None:
    parsed = extract_json_object('prefix {"mode":"requirement_intake","confidence":0.9} suffix')
    assert parsed.get("mode") == "requirement_intake"
    assert parsed.get("confidence") == 0.9


def test_build_prompt_and_keyword_suggestion() -> None:
    prompt = build_intent_classifier_prompt("先帮我梳理需求")
    assert "requirement_intake" in prompt
    assert "采购助手" not in prompt

    suggestion = build_keyword_suggestion(
        "先帮我梳理需求",
        resolve_requirement_intake_entry_recommendation_fn=lambda _msg: ("requirement_intake", 0.8, "", "keywords"),
        infer_intent_by_keywords_fn=lambda _msg: "",
    )
    assert suggestion[0] == "requirement_intake"


def test_core_keywords_stay_on_explicit_mode_terms() -> None:
    assert infer_intent_by_keywords("请确认预算目标和方案", intent_keywords=INTENT_KEYWORDS) == ""
    assert infer_intent_by_keywords("请梳理需求", intent_keywords=INTENT_KEYWORDS) == "requirement_intake"
    assert infer_intent_by_keywords("帮我寻源", intent_keywords=INTENT_KEYWORDS) == "intelligent_sourcing"
    assert infer_intent_by_keywords("请分析", intent_keywords=INTENT_KEYWORDS) == "analysis_mode"


def test_domain_pack_canonical_alias_can_drive_keyword_intent() -> None:
    assert (
        infer_intent_by_keywords("采购 requirement_intake", intent_keywords=INTENT_KEYWORDS)
        == "requirement_intake"
    )
