from __future__ import annotations

from flare_kernel.router.intake.state_persistence import (
    persist_authoritative_intake_state,
)


def test_persist_authoritative_intake_state_returns_empty_without_session_id() -> None:
    result = persist_authoritative_intake_state(
        trace_id="t",
        session_id="s",
        project_id="p",
        user_id="u",
        command="send_message",
        runtime_snapshot={"payload": {}},
        orchestration_status={},
        persist_intake_session_state_fn=lambda **_kwargs: {"ok": True},
        persist_intake_checkpoint_fn=lambda **_kwargs: {"ok": True},
    )
    assert result == {}


def test_persist_authoritative_intake_state_invokes_both_stores() -> None:
    result = persist_authoritative_intake_state(
        trace_id="t",
        session_id="s",
        project_id="p",
        user_id="u",
        command="send_message",
        runtime_snapshot={"payload": {"k": "v"}},
        orchestration_status={"intake_session_id": "intake_1"},
        persist_intake_session_state_fn=lambda **_kwargs: {"store": "session"},
        persist_intake_checkpoint_fn=lambda **_kwargs: {"store": "checkpoint"},
    )
    assert result["session_store"] == {"store": "session"}
    assert result["checkpoint_store"] == {"store": "checkpoint"}


def test_persist_authoritative_intake_state_merges_confirmed_updates_into_runtime_payload() -> None:
    captured: dict[str, object] = {}

    def _persist_session(**kwargs):
        captured["runtime_payload"] = kwargs.get("runtime_payload")
        return {"store": "session"}

    result = persist_authoritative_intake_state(
        trace_id="t",
        session_id="s",
        project_id="p",
        user_id="u",
        command="submit_intake_answer",
        runtime_snapshot={"payload": {"fields": {"scope": "总部一期"}}},
        orchestration_status={
            "intake_session_id": "intake_1",
            "confirmed_updates": [
                {"field_key": "constraints", "field_value": "预算上限80万"},
            ],
            "field_entities": {
                "constraints": {"display_value": "预算上限80万", "source": {"type": "question_answer"}},
            },
        },
        persist_intake_session_state_fn=_persist_session,
        persist_intake_checkpoint_fn=lambda **_kwargs: {"store": "checkpoint"},
    )
    assert result["session_store"] == {"store": "session"}
    runtime_payload = captured.get("runtime_payload")
    assert isinstance(runtime_payload, dict)
    assert runtime_payload["fields"]["scope"] == "总部一期"
    assert runtime_payload["fields"]["constraints"] == "预算上限80万"
    assert runtime_payload["field_entities"]["constraints"]["display_value"] == "预算上限80万"


def test_persist_authoritative_intake_state_preserves_terminal_applied_status() -> None:
    captured: dict[str, object] = {}

    def _persist_session(**kwargs):
        captured["session_status"] = kwargs.get("orchestration_status")
        return {
            "intake_session_state": kwargs["orchestration_status"]["intake_session_state"],
            "intake_session_completed": kwargs["orchestration_status"]["intake_session_completed"],
        }

    def _persist_checkpoint(**kwargs):
        captured["checkpoint_status"] = kwargs.get("orchestration_status")
        return {"checkpoint_state": "completed"}

    result = persist_authoritative_intake_state(
        trace_id="t",
        session_id="s",
        project_id="p",
        user_id="u",
        command="implement",
        runtime_snapshot={"payload": {"fields": {"goal": "采购服务器"}}},
        orchestration_status={
            "intake_session_id": "intake_1",
            "intake_session_state": "applied",
            "intake_session_completed": True,
            "current_question": None,
            "next_actions": [],
        },
        persist_intake_session_state_fn=_persist_session,
        persist_intake_checkpoint_fn=_persist_checkpoint,
    )

    assert result["session_store"] == {
        "intake_session_state": "applied",
        "intake_session_completed": True,
    }
    assert result["checkpoint_store"] == {"checkpoint_state": "completed"}
    assert captured["session_status"]["intake_session_state"] == "applied"
    assert captured["session_status"]["intake_session_completed"] is True
    assert captured["checkpoint_status"]["current_question"] is None
    assert captured["checkpoint_status"]["next_actions"] == []
