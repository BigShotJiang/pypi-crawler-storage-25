from __future__ import annotations

from flare_kernel.router.intake.status.core import (
    build_active_checkpoint,
    build_fallback_active_checkpoint,
    build_field_label_map,
    build_structured_search_results,
    build_workspace_updates,
    compute_procurement_relevance,
    resolve_guided_session_flags,
    build_search_actions,
    build_status_chooser,
    build_confirmed_updates,
    build_guided_session_status,
    build_intake_followup_state,
    build_workflow_checkpoint_projection,
    build_open_fields,
    pick_next_action,
    resolve_current_stage,
)


def test_build_open_fields_marks_current_field() -> None:
    result = build_open_fields(
        required_missing=["budget", "quantity"],
        current_question={"field_key": "budget"},
    )
    assert result == [
        {"field_key": "budget", "priority": "required", "is_current": True},
        {"field_key": "quantity", "priority": "required", "is_current": False},
    ]


def test_build_confirmed_updates_filters_empty_values() -> None:
    result = build_confirmed_updates(
        {
            "category": "服务器",
            "budget": "",
            "quantity": None,
            "delivery_location": "上海园区",
        }
    )
    assert result == [
        {"field_key": "category", "field_value": "服务器"},
        {"field_key": "delivery_location", "field_value": "上海园区"},
    ]


def test_build_intake_followup_state_transitions_to_analysis_ready() -> None:
    state = build_intake_followup_state(
        trace_id="trace-1",
        intake_session_id="intake_1",
        resolved_mode="requirement_intake",
        current_stage="requirement_intake.ready_for_submit",
        current_question=None,
        required_fields=["category", "budget"],
        required_missing=[],
        fields={"category": "服务器", "budget": "20万以内"},
        next_actions=[{"action_key": "confirm_plan", "status": "available"}],
        command="send_message",
        has_analysis_content=False,
    )
    assert state["intake_session_state"] == "analysis_ready"
    assert state["analysis_ready"] is True
    assert state["followup_status"] == "converged"
    assert state["next_user_action"] == "confirm_plan"


def test_build_guided_session_status_sets_summary_ready() -> None:
    status = build_guided_session_status(
        resolved_mode="requirement_intake",
        current_stage="requirement_intake.ready_for_submit",
        command="send_message",
        current_question=None,
        required_fields=["category", "budget"],
        required_missing=[],
        confirmed_updates=[{"field_key": "category", "field_value": "服务器"}],
        next_actions=[{"action_key": "confirm_plan"}],
        active_collecting=False,
        ready_for_submit=True,
        decision_point_active=False,
        field_label_map={"category": "类别"},
    )
    assert status["state"] == "summary_ready"
    assert status["summary"]["ready"] is True
    assert "类别：服务器" in status["summary"]["text"]


def test_pick_next_action_prefers_available_item() -> None:
    result = pick_next_action(
        {
            "actions": [
                {"action_key": "handoff_to_sourcing", "status": "blocked"},
                {"action_key": "continue_collection", "status": "available", "target_field": "budget"},
            ]
        }
    )
    assert result["action_key"] == "continue_collection"
    assert result["target_field"] == "budget"


def test_build_status_chooser_includes_other_input_fallback() -> None:
    chooser = build_status_chooser(
        current_question={
            "field_key": "budget",
            "question_text": "预算范围？",
            "options": ["20万以内", "20-50万"],
        },
        next_actions_payload={
            "actions": [
                {"action_key": "continue_collection", "blocking_reason": "预算缺失"},
            ]
        },
        open_fields=[{"field_key": "budget", "priority": "required", "is_current": True}],
        retrieval_attempted=True,
        retrieval_hits=2,
    )
    assert chooser is not None
    assert chooser["target_field"] == "budget"
    assert chooser["blocking_reason"] == "预算缺失"
    assert chooser["recommended_option_key"] == "option_1"
    assert any(item["key"] == "other_input" for item in chooser["options"])


def test_resolve_current_stage_follows_requirement_intake_priority() -> None:
    assert resolve_current_stage(
        mode_key="requirement_intake",
        mode_state="drafting",
        open_fields=[],
        chooser=None,
    ) == "requirement_analysis"
    assert resolve_current_stage(
        mode_key="requirement_intake",
        mode_state="collecting",
        open_fields=[{"field_key": "budget"}],
        chooser={"target_field": "budget"},
    ) == "focused_clarifying"
    assert resolve_current_stage(
        mode_key="intelligent_sourcing",
        mode_state="running",
        open_fields=[],
        chooser=None,
    ) == "compare_replace"


def test_build_active_checkpoint_returns_empty_without_checkpoint_id() -> None:
    assert build_active_checkpoint({"checkpoint_state": "waiting_user"}) == {}


def test_build_active_checkpoint_maps_fields() -> None:
    payload = build_active_checkpoint(
        {
            "checkpoint_id": "ckpt_1",
            "intake_session_id": "intake_1",
            "checkpoint_type": "intake_question",
            "checkpoint_state": "waiting_user",
            "current_stage": "requirement_intake.collecting",
            "question_key": "budget",
            "ready_for_submit": False,
            "decision_point_active": False,
            "updated_at": "2026-04-10T12:00:00Z",
        }
    )
    assert payload["checkpoint_id"] == "ckpt_1"
    assert payload["intake_session_id"] == "intake_1"
    assert payload["question_key"] == "budget"


def test_build_workflow_checkpoint_projection_emits_server_authority_shape() -> None:
    payload = build_workflow_checkpoint_projection(
        intake_session_id="intake_1",
        session_id="sess_1",
        mode="requirement_intake",
        current_stage="requirement_intake.collecting",
        active_collecting=True,
        ready_for_submit=False,
        decision_point_active=False,
        current_question={"field_key": "budget", "question_text": "预算范围是多少？"},
        confirmed_updates=[{"field_key": "category", "field_value": "基础设施"}],
        required_missing=["budget", "quantity"],
        blocking_reason="缺少关键字段",
        checkpoint_base={"checkpoint_id": "ckpt_1", "updated_at": "2026-04-10T12:00:00Z"},
        question_progress={"current": 1, "total": 8},
        updated_at="2026-04-10T12:00:00Z",
    )
    assert payload["workflow_id"] == "wf_intake_1"
    assert payload["active_checkpoint_id"] == "ckpt_1"
    assert payload["version"] >= 1
    assert payload["status"] in {"waiting_user", "running"}
    assert isinstance(payload["checkpoints"], list)
    assert payload["checkpoints"]
    assert isinstance(payload["checkpoints"][0]["child_tasks"], list)


def test_build_field_label_map_filters_invalid_definitions() -> None:
    mapping = build_field_label_map(
        [
            {"key": "budget", "label": "预算"},
            {"key": "quantity", "label": "数量"},
            {"key": "", "label": "空"},
            "ignored",
        ]
    )
    assert mapping == {"budget": "预算", "quantity": "数量"}


def test_build_search_actions_returns_completed_event_when_retrieval_attempted() -> None:
    actions = build_search_actions(
        retrieval_attempted=True,
        retrieval_queries=["服务器 预算"],
        retrieved_knowledge=[{"id": "k1"}, {"id": "k2"}],
    )
    assert actions == [
        {
            "action": "knowledge_search",
            "queries": ["服务器 预算"],
            "result_count": 2,
            "status": "completed",
        }
    ]


def test_build_structured_search_results_marks_target_field() -> None:
    structured = build_structured_search_results(
        results=[
            {"title": "机型A", "content": "预算20万以内", "score": 0.9, "source_type": "web"},
        ],
        open_fields=[{"field_key": "budget", "priority": "required", "is_current": True}],
    )
    assert len(structured) == 1
    assert structured[0]["matched_field"] == "budget"
    assert structured[0]["confidence"] == 0.9
    assert structured[0]["source"] == "web"
    assert structured[0]["selectable_for_replace"] is True


def test_build_structured_search_results_handles_missing_score() -> None:
    structured = build_structured_search_results(
        results=[{"source_label": "条目", "snippet": "内容"}],
        open_fields=[],
    )
    assert len(structured) == 1
    assert structured[0]["confidence"] == 0.0
    assert structured[0]["matched_field"] == ""
    assert structured[0]["selectable_for_replace"] is False


def test_build_fallback_active_checkpoint_uses_waiting_user_when_question_exists() -> None:
    checkpoint = build_fallback_active_checkpoint(
        intake_session_id="intake_1",
        current_question={"field_key": "budget"},
        ready_for_submit=False,
        decision_point_active=False,
        current_stage="requirement_intake.collecting",
        updated_at="2026-04-10T12:00:00Z",
    )
    assert checkpoint["checkpoint_state"] == "waiting_user"
    assert checkpoint["question_key"] == "budget"


def test_build_workspace_updates_maps_pending_and_updated_fields() -> None:
    payload = build_workspace_updates(
        retrieval_attempted=True,
        retrieved_knowledge_count=3,
        confirmed_updates=[{"field_key": "category"}, {"field_key": "budget"}],
        open_fields=[{"field_key": "quantity"}],
    )
    assert payload["search_workspace"]["updated"] is True
    assert payload["search_workspace"]["evidence_count"] == 3
    assert payload["requirement_workspace"]["updated_fields"] == ["category", "budget"]
    assert payload["requirement_workspace"]["pending_fields"] == ["quantity"]


def test_compute_procurement_relevance_matches_intent_or_mode() -> None:
    assert compute_procurement_relevance(resolved_intent="requirement_intake", resolved_mode="default") is True
    assert compute_procurement_relevance(resolved_intent="default", resolved_mode="intelligent_sourcing") is True
    assert compute_procurement_relevance(resolved_intent="default", resolved_mode="default") is False


def test_resolve_guided_session_flags_for_ready_state() -> None:
    flags = resolve_guided_session_flags(
        current_stage="requirement_intake.ready_for_submit",
        required_missing=[],
        current_question=None,
        command="send_message",
    )
    assert flags["ready_for_submit"] is True
    assert flags["decision_point_active"] is True
    assert flags["active_collecting"] is False
    assert flags["has_active_question"] is False


def test_resolve_guided_session_flags_for_collecting_state() -> None:
    flags = resolve_guided_session_flags(
        current_stage="requirement_intake.collecting",
        required_missing=["budget"],
        current_question={"field_key": "budget"},
        command="send_message",
    )
    assert flags["ready_for_submit"] is False
    assert flags["decision_point_active"] is False
    assert flags["active_collecting"] is True
    assert flags["has_active_question"] is True
