"""Resolve generic response intent for a routed turn.

DOC HELPER — OBJ-08 output-shape routing boundary.
This module only classifies the requested artifact shape (document, report,
plan, checklist, grounded answer, etc.). It must not embed business-specific
sections or template bodies; those belong to domain-pack artifact templates.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.router.response_intent.contracts import normalize_response_intent_result
from flare_kernel.router.response_intent.document_output import requests_document_output

_SOURCE_REFERENCE_TERMS = ("附件", "资料", "文件", "项目资料", "当前资料", "知识库", "证据", "引用")
_GAP_ANALYSIS_TERMS = ("还缺", "缺少", "缺失", "缺哪些", "哪些要素", "需要考虑哪些", "补充哪些", "待补充")
_COMPARISON_TERMS = ("对比", "比较", "区别", "优劣", "哪个更")
_RECOMMENDATION_TERMS = ("推荐", "建议", "优先选择", "怎么选")
_ACTION_PLAN_TERMS = ("下一步", "怎么做", "如何推进", "执行计划", "实施计划", "推进路径")
_TEMPLATE_HINT_TERMS = ("模板", "框架", "结构", "要素", "字段", "清单", "表格")


def _contains_any(text: str, terms: tuple[str, ...]) -> bool:
    return any(term for term in terms if term and term in text)


def _has_source_grounding(payload: dict[str, Any]) -> bool:
    source_grounding = payload.get("source_grounding") if isinstance(payload.get("source_grounding"), dict) else {}
    if source_grounding.get("active") is True:
        return True
    if isinstance(payload.get("source_ids"), list) and payload.get("source_ids"):
        return True
    return isinstance(payload.get("retrieved_knowledge"), list) and bool(payload.get("retrieved_knowledge"))


def _resolve_artifact_type(message: str) -> str:
    if "需求文档" in message or ("需求" in message and "文档" in message):
        return "requirements_document"
    if "报告" in message:
        return "report"
    if "清单" in message:
        return "checklist"
    if "方案" in message:
        return "plan"
    if "文档" in message or "模板" in message or "正文" in message or "草案" in message:
        return "generic_document"
    return "none"


def _resolve_document_response_intent(message: str, artifact_type: str) -> str:
    if _contains_any(message, _TEMPLATE_HINT_TERMS):
        return "document_template_output"
    if artifact_type == "requirements_document":
        return "document_template_output"
    return "document_draft_output"


def resolve_response_intent(
    *,
    message: str,
    payload: dict[str, Any] | None = None,
    resolved_mode: str = "",
    command: str = "send_message",
) -> dict[str, Any]:
    """Resolve the generic output intent for the current turn.

    DOC HELPER — response intent is a core orchestration contract. It answers
    "what output shape did the user ask for?" Domain packs should not decide
    this; they should only provide domain-specific templates/fields once the
    artifact type is known.
    """

    text = str(message or "").strip()
    source = payload if isinstance(payload, dict) else {}
    has_grounding = _has_source_grounding(source) or _contains_any(text, _SOURCE_REFERENCE_TERMS)
    artifact_type = _resolve_artifact_type(text)
    reasons: list[str] = []

    if requests_document_output(text):
        reasons.append("用户请求产出文档类成果")
        if has_grounding:
            reasons.append("用户或上下文要求结合资料")
        return normalize_response_intent_result(
            {
                "response_intent": _resolve_document_response_intent(text, artifact_type),
                "artifact_type": artifact_type,
                "detail_policy": "preserve_user_input",
                "missing_info_policy": "append_after_output",
                "grounding_policy": "use_project_sources_when_available" if has_grounding else "none",
                "confidence": 0.9,
                "source": "response_intent_rules",
                "reasons": reasons,
            }
        )

    if has_grounding:
        return normalize_response_intent_result(
            {
                "response_intent": "source_grounded_answer",
                "artifact_type": "none",
                "grounding_policy": "use_project_sources_when_available",
                "confidence": 0.82,
                "source": "response_intent_rules",
                "reasons": ["用户或上下文要求结合资料"],
            }
        )

    if _contains_any(text, _GAP_ANALYSIS_TERMS):
        return normalize_response_intent_result(
            {
                "response_intent": "gap_analysis",
                "confidence": 0.78,
                "source": "response_intent_rules",
                "reasons": ["用户询问缺口或待补充要素"],
            }
        )

    if _contains_any(text, _COMPARISON_TERMS):
        return normalize_response_intent_result(
            {"response_intent": "comparison", "confidence": 0.72, "source": "response_intent_rules"}
        )

    if _contains_any(text, _ACTION_PLAN_TERMS):
        return normalize_response_intent_result(
            {"response_intent": "action_plan", "confidence": 0.72, "source": "response_intent_rules"}
        )

    if _contains_any(text, _RECOMMENDATION_TERMS):
        return normalize_response_intent_result(
            {"response_intent": "recommendation", "confidence": 0.7, "source": "response_intent_rules"}
        )

    return normalize_response_intent_result(
        {
            "response_intent": "direct_answer",
            "confidence": 0.5,
            "source": "fallback",
            "reasons": [f"mode={resolved_mode or 'default'} command={command or 'send_message'}"],
        }
    )
