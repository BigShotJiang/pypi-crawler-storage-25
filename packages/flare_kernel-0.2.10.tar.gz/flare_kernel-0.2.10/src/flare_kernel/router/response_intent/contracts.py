"""Response-intent contract normalization for router workflows."""

from __future__ import annotations

from typing import Any

RESPONSE_INTENTS = frozenset(
    {
        "direct_answer",
        "clarification_question",
        "gap_analysis",
        "document_template_output",
        "document_draft_output",
        "source_grounded_answer",
        "recommendation",
        "comparison",
        "action_plan",
    }
)

ARTIFACT_TYPES = frozenset(
    {
        "none",
        "generic_document",
        "requirements_document",
        "report",
        "checklist",
        "plan",
    }
)

DETAIL_POLICIES = frozenset({"summarize", "preserve_user_input"})
MISSING_INFO_POLICIES = frozenset({"ask_if_blocking", "append_after_output"})
GROUNDING_POLICIES = frozenset({"none", "use_project_sources_when_available"})


def _coerce_enum(raw: Any, allowed: frozenset[str], fallback: str) -> str:
    value = str(raw or "").strip()
    return value if value in allowed else fallback


def _coerce_confidence(raw: Any) -> float:
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return 0.0
    return max(0.0, min(1.0, value))


def _coerce_reasons(raw: Any) -> list[str]:
    if not isinstance(raw, (list, tuple)):
        return []
    return [str(item).strip() for item in raw if str(item).strip()]


def normalize_response_intent_result(raw: dict[str, Any] | None) -> dict[str, Any]:
    """Normalize the response-intent result object.

    DOC HELPER — this contract describes the user's requested output shape,
    not domain-specific business content. Domain packs can later map the
    generic artifact type to their own section structure and field semantics.
    """

    source = raw if isinstance(raw, dict) else {}
    return {
        "response_intent": _coerce_enum(source.get("response_intent"), RESPONSE_INTENTS, "direct_answer"),
        "artifact_type": _coerce_enum(source.get("artifact_type"), ARTIFACT_TYPES, "none"),
        "detail_policy": _coerce_enum(source.get("detail_policy"), DETAIL_POLICIES, "summarize"),
        "missing_info_policy": _coerce_enum(
            source.get("missing_info_policy"),
            MISSING_INFO_POLICIES,
            "ask_if_blocking",
        ),
        "grounding_policy": _coerce_enum(
            source.get("grounding_policy"),
            GROUNDING_POLICIES,
            "none",
        ),
        "confidence": _coerce_confidence(source.get("confidence")),
        "source": str(source.get("source") or "").strip() or "fallback",
        "reasons": _coerce_reasons(source.get("reasons")),
    }
