"""Guided-session completion helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime.llm.llm_provider import LLMCompletion

_REQUIREMENT_INTAKE_COMMAND_SCORES = {
    "": {"main_chain": 1.0, "patch_only": 0.0},
    "send_message": {"main_chain": 1.0, "patch_only": 0.0},
    "submit_intake_answer": {"main_chain": 0.0, "patch_only": 1.0},
    "activate_requirement_intake": {"main_chain": 0.0, "patch_only": 1.0},
}
_DEFAULT_REQUIREMENT_INTAKE_COMMAND_SCORE = {"main_chain": 1.0, "patch_only": 0.0}


@dataclass(frozen=True)
class _GuidedCompletionDecision:
    action: str
    main_chain_score: float
    patch_only_score: float
    phase_score: float

    @property
    def is_patch_only(self) -> bool:
        return self.action == "patch_only"


def _is_collecting_question_phase(orchestration_status: dict[str, Any]) -> bool:
    status = orchestration_status if isinstance(orchestration_status, dict) else {}
    current_stage = str(status.get("current_stage") or "").strip().lower()
    if not current_stage.startswith("requirement_intake"):
        return False
    if current_stage == "requirement_intake.collecting":
        return True
    chooser_state = status.get("chooser_state") if isinstance(status.get("chooser_state"), dict) else {}
    chooser_kind = str(chooser_state.get("kind") or "").strip().lower()
    has_current_question = isinstance(status.get("current_question"), dict)
    if has_current_question:
        return True
    if chooser_kind == "question":
        return True
    if bool(status.get("has_active_question")):
        return True
    state = str(status.get("intake_session_state") or "").strip().lower()
    if state in {"collecting", "blocked"}:
        return True
    return False


def _resolve_requirement_intake_guided_decision(
    *,
    command: str,
    orchestration_status: dict[str, Any],
) -> _GuidedCompletionDecision:
    """Resolve requirement-intake guided completion as a scored policy decision.

    Args:
        command: Normalized kernel command for the current turn.
        orchestration_status: Canonical orchestration state for this turn.

    Returns:
        A scored decision. `main_chain` means the assistant response should continue
        through the normal LLM path; `patch_only` means this turn only emits UI/state
        patches and should not be persisted as an assistant memory record.
    """
    command_scores = _REQUIREMENT_INTAKE_COMMAND_SCORES.get(
        command,
        _DEFAULT_REQUIREMENT_INTAKE_COMMAND_SCORE,
    )
    phase_score = float(_is_collecting_question_phase(orchestration_status))
    patch_only_score = phase_score * float(command_scores["patch_only"])
    main_chain_score = float(command_scores["main_chain"])
    action = "patch_only" if patch_only_score > main_chain_score else "main_chain"
    return _GuidedCompletionDecision(
        action=action,
        main_chain_score=main_chain_score,
        patch_only_score=patch_only_score,
        phase_score=phase_score,
    )


def resolve_guided_orchestrated_completion(
    *,
    req: KernelRequest,
    command: str,
    resolved_mode: str,
    mode_source: str,
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
) -> LLMCompletion | None:
    _ = (req, mode_source)
    normalized_mode = str(resolved_mode or "").strip()
    normalized_command = str(command or "").strip()
    if normalized_mode != "requirement_intake":
        return None
    intake_decision = _resolve_requirement_intake_guided_decision(
        command=normalized_command,
        orchestration_status=orchestration_status,
    )
    if not intake_decision.is_patch_only:
        return None
    _ = req
    return LLMCompletion(
        provider="kernel_guardrail",
        model="guided_session",
        content="",
        status="orchestrated",
        details={
            "reason": "guided_session_patch_only",
            "phase": "collecting_question",
            "mode": normalized_mode,
            "command": normalized_command,
            "main_chain_score": intake_decision.main_chain_score,
            "patch_only_score": intake_decision.patch_only_score,
            "phase_score": intake_decision.phase_score,
        },
    )


def should_persist_memory_record(*, completion: LLMCompletion) -> bool:
    details = completion.details if isinstance(completion.details, dict) else {}
    if str(details.get("reason") or "").strip() == "guided_session_patch_only":
        return False
    return True
