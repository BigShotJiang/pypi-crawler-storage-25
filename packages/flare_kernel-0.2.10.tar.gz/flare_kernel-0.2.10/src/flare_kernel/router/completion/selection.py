"""Completion selection helpers shared by run/stream handlers."""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.response_intent import resolve_response_intent
from flare_kernel.runtime.llm.llm_provider import LLMCompletion


_DOCUMENT_OUTPUT_INTENTS = frozenset({"document_template_output", "document_draft_output"})


def _should_skip_guided_completion_for_output_request(
    *,
    raw_message: str,
    resolved_mode: str,
    effective_command: str,
) -> bool:
    """Keep output requests from being downgraded into guided clarification.

    DOC HELPER — guided completion is useful for active field collection, but
    it must not override an explicit request to produce a document/template.
    The LLM prompt owns the response content in that case; missing fields can
    still be surfaced as caveats inside the generated answer.
    """

    if str(resolved_mode or "").strip() != "requirement_intake":
        return False
    if str(effective_command or "").strip() != "send_message":
        return False
    response_intent_result = resolve_response_intent(
        message=raw_message,
        resolved_mode=resolved_mode,
        command=effective_command,
    )
    return str(response_intent_result.get("response_intent") or "") in _DOCUMENT_OUTPUT_INTENTS


async def resolve_turn_completion(
    *,
    req: KernelRequest,
    trace_id: str,
    session_id: str,
    raw_message: str,
    resolved_mode: str,
    mode_source: str,
    effective_command: str,
    retrieved_knowledge: list[dict[str, Any]],
    enriched_payload: dict[str, Any],
    runtime_snapshot: dict[str, Any],
    orchestration_status: dict[str, Any],
    instance_profile: dict[str, Any] | None,
    resolve_guided_orchestrated_completion_fn: Callable[..., LLMCompletion | None],
    should_force_requirement_clarification_fn: Callable[..., bool],
    build_requirement_clarification_message_fn: Callable[[str], str],
    build_prompt_fn: Callable[[KernelRequest, dict[str, Any], dict[str, Any] | None, str, str], str],
    generate_llm_completion_fn: Callable[..., Awaitable[LLMCompletion]],
    on_llm_delta_fn: Callable[[str], Any] | None = None,
) -> LLMCompletion:
    guided_completion = None
    if not _should_skip_guided_completion_for_output_request(
        raw_message=raw_message,
        resolved_mode=resolved_mode,
        effective_command=effective_command,
    ):
        guided_completion = resolve_guided_orchestrated_completion_fn(
            req=req,
            command=effective_command,
            resolved_mode=resolved_mode,
            mode_source=mode_source,
            runtime_snapshot=runtime_snapshot,
            orchestration_status=orchestration_status,
        )
    if isinstance(guided_completion, LLMCompletion):
        return guided_completion

    if should_force_requirement_clarification_fn(
        req=req,
        message=raw_message,
        retrieved_knowledge=retrieved_knowledge,
        instance_profile=instance_profile,
    ):
        return LLMCompletion(
            provider="kernel_guardrail",
            model="requirement_clarification",
            content=build_requirement_clarification_message_fn(raw_message),
            status="guardrail",
            details={"reason": "requirement_clarification_required"},
        )

    prompt = build_prompt_fn(req, enriched_payload, instance_profile, resolved_mode, effective_command)
    if on_llm_delta_fn is None:
        return await generate_llm_completion_fn(
            prompt,
            trace_id=trace_id,
            session_id=session_id,
            intent=resolved_mode,
        )
    return await generate_llm_completion_fn(
        prompt,
        trace_id=trace_id,
        session_id=session_id,
        intent=resolved_mode,
        on_delta_fn=on_llm_delta_fn,
    )
