"""Kernel /run route execution helper."""

from __future__ import annotations

from typing import Any

from flare_kernel.contracts import KernelRequest, KernelResponse
from flare_kernel.runtime import generate_llm_completion, get_logger, persist_memory_record
from flare_kernel.runtime.project_memory import persist_project_memory_from_runtime
from flare_kernel.router.completion.response_builder import (
    apply_completion_content_policy as apply_completion_content_policy_from_router,
    build_kernel_success_response as build_kernel_success_response_from_router,
    build_run_result_payload as build_run_result_payload_from_router,
)
from flare_kernel.router.completion.selection import (
    resolve_turn_completion as resolve_turn_completion_from_router,
)
from flare_kernel.router.completion.guided import (
    resolve_guided_orchestrated_completion as resolve_guided_orchestrated_completion_from_router,
    should_persist_memory_record as should_persist_memory_record_from_router,
)
from flare_kernel.router.retrieval.projection import (
    build_knowledge_citations as build_knowledge_citations_from_router,
)
from flare_kernel.router.text_safety import (
    sanitize_customer_visible_text as sanitize_customer_visible_text_from_router,
)


def _resolve_turn_value(turn: dict[str, Any], key: str, default: Any = None) -> Any:
    value = turn.get(key, default)
    return value


def _resolve_dict_value(data: dict[str, Any], key: str) -> dict[str, Any]:
    value = data.get(key)
    return value if isinstance(value, dict) else {}


def _resolve_list_value(data: dict[str, Any], key: str) -> list[Any]:
    value = data.get(key)
    return value if isinstance(value, list) else []


async def build_kernel_run_response(
    *,
    req: KernelRequest,
    turn: dict[str, Any],
    resolved_intent: str,
    intent_source: str,
    intent_confidence: float,
    intent_reason: str,
    resolved_mode: str,
    mode_source: str,
    should_force_requirement_clarification_fn,
    build_requirement_clarification_message_fn,
    build_prompt_fn,
    build_mode_switch_reason_fn,
    build_canonical_state_fn,
    sync_session_intent_stage_fn,
    persist_authoritative_intake_state_fn,
) -> KernelResponse:
    trace_id = str(_resolve_turn_value(turn, "trace_id"))
    session_id = str(_resolve_turn_value(turn, "session_id"))
    instance_profile = _resolve_turn_value(turn, "instance_profile")
    raw_message = str(_resolve_turn_value(turn, "raw_message"))
    project_id = str(_resolve_turn_value(turn, "project_id"))
    user_id = str(_resolve_turn_value(turn, "user_id"))
    retrieved_knowledge = _resolve_list_value(turn, "retrieved_knowledge")
    enriched_payload = _resolve_dict_value(turn, "enriched_payload")
    runtime_snapshot = _resolve_dict_value(turn, "runtime_snapshot")
    orchestration_status = _resolve_dict_value(turn, "orchestration_status")
    escalation_signal = _resolve_dict_value(turn, "escalation_signal")
    effective_command = str(_resolve_turn_value(turn, "effective_command"))
    structured_retrieved_knowledge = _resolve_list_value(turn, "structured_retrieved_knowledge")
    logger = get_logger("flare_kernel.router.kernel")
    logger.info(
        "kernel.run trace_id=%s session_id=%s intent=%s mode=%s mode_source=%s instance_id=%s has_instance_profile=%s",
        trace_id,
        session_id,
        resolved_intent,
        resolved_mode,
        mode_source,
        req.instance_id,
        bool(instance_profile),
    )
    completion = await resolve_turn_completion_from_router(
        req=req,
        trace_id=trace_id,
        session_id=session_id,
        raw_message=raw_message,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        effective_command=effective_command,
        retrieved_knowledge=retrieved_knowledge,
        enriched_payload=enriched_payload,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
        instance_profile=instance_profile,
        resolve_guided_orchestrated_completion_fn=resolve_guided_orchestrated_completion_from_router,
        should_force_requirement_clarification_fn=should_force_requirement_clarification_fn,
        build_requirement_clarification_message_fn=build_requirement_clarification_message_fn,
        build_prompt_fn=build_prompt_fn,
        generate_llm_completion_fn=generate_llm_completion,
    )
    content_text = sanitize_customer_visible_text_from_router(completion.content)
    memory_record = {}
    if should_persist_memory_record_from_router(completion=completion):
        memory_record = persist_memory_record(
            trace_id=trace_id,
            session_id=session_id,
            project_id=project_id,
            user_id=user_id,
            mode_key=runtime_snapshot["mode_key"],
            user_message=raw_message,
            assistant_message=content_text,
            provider=completion.provider,
            model=completion.model,
            provider_status=completion.status,
        )
    project_memory_record = persist_project_memory_from_runtime(
        project_id=project_id,
        user_id=user_id,
        source_session_id=session_id,
        runtime_snapshot=runtime_snapshot,
    )
    if project_memory_record:
        memory_record.update(project_memory_record)
    has_llm_content = bool(str(content_text or "").strip())
    apply_completion_content_policy_from_router(
        orchestration_status=orchestration_status,
        command=effective_command,
        has_llm_content=has_llm_content,
        content_text=content_text,
        runtime_snapshot=runtime_snapshot,
    )
    sync_session_intent_stage_fn(
        orchestration_status=orchestration_status,
        signal=escalation_signal,
        message=raw_message,
        command=effective_command,
    )
    persist_authoritative_intake_state_fn(
        trace_id=trace_id,
        session_id=session_id,
        project_id=project_id,
        user_id=user_id,
        command=effective_command,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
    )
    mode_switch_reason = build_mode_switch_reason_fn(
        trace_id=trace_id,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        intent_source=intent_source,
        intent_confidence=intent_confidence,
        intent_reason=intent_reason,
        req=req,
    )
    result = build_run_result_payload_from_router(
        content_text=content_text,
        completion_provider=completion.provider,
        completion_model=completion.model,
        completion_status=completion.status,
        completion_details=completion.details,
        runtime_snapshot=runtime_snapshot,
        memory_record=memory_record,
        retrieved_knowledge=retrieved_knowledge,
        structured_retrieved_knowledge=structured_retrieved_knowledge,
        orchestration_status=orchestration_status,
        mode_switch_reason=mode_switch_reason,
        build_knowledge_citations_fn=build_knowledge_citations_from_router,
    )
    result["canonical_state"] = build_canonical_state_fn(
        req=req,
        command=effective_command,
        resolved_intent=resolved_intent,
        resolved_mode=resolved_mode,
        mode_source=mode_source,
        orchestration_status=orchestration_status,
        runtime_snapshot=runtime_snapshot,
        assistant_text=content_text,
        provider_status=str(completion.status or ""),
        structured_retrieved_knowledge=structured_retrieved_knowledge,
    )
    if instance_profile:
        result["instance_profile"] = instance_profile
    return build_kernel_success_response_from_router(
        trace_id=trace_id,
        result=result,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
    )
