"""Kernel /action route execution helper."""

from __future__ import annotations

from typing import Any

from flare_kernel.contracts import KernelRequest, KernelResponse
from flare_kernel.runtime import generate_llm_completion, get_logger, persist_memory_record
from flare_kernel.router.completion.response_builder import (
    apply_completion_content_policy as apply_completion_content_policy_from_router,
    build_action_result_payload as build_action_result_payload_from_router,
    build_kernel_success_response as build_kernel_success_response_from_router,
)
from flare_kernel.router.request.identity import (
    resolve_project_id as resolve_project_id_from_router,
    resolve_user_id as resolve_user_id_from_router,
)
from flare_kernel.router.text_safety import (
    sanitize_customer_visible_text as sanitize_customer_visible_text_from_router,
)


def _resolve_turn_value(turn: dict[str, Any], key: str, default: Any = None) -> Any:
    value = turn.get(key, default)
    return value


def _resolve_dict_value(data: dict[str, Any], key: str) -> dict[str, Any]:
    value = data.get(key)
    return value if isinstance(value, dict) else {}


async def build_kernel_action_response(
    *,
    req: KernelRequest,
    action_context: dict[str, Any],
    build_prompt_fn,
    sync_session_intent_stage_fn,
    persist_authoritative_intake_state_fn,
) -> KernelResponse:
    trace_id = str(_resolve_turn_value(action_context, "trace_id"))
    instance_profile = _resolve_turn_value(action_context, "instance_profile")
    action_command = str(_resolve_turn_value(action_context, "action_command"))
    action_target_mode = str(_resolve_turn_value(action_context, "action_target_mode"))
    action_payload = _resolve_dict_value(action_context, "action_payload")
    runtime_snapshot = _resolve_dict_value(action_context, "runtime_snapshot")
    orchestration_status = _resolve_dict_value(action_context, "orchestration_status")
    action_message = str(_resolve_turn_value(action_context, "action_message"))
    escalation_signal = _resolve_dict_value(action_context, "escalation_signal")
    logger = get_logger("flare_kernel.router.kernel")
    logger.info(
        "kernel.action trace_id=%s session_id=%s intent=%s action_key=%s target_mode=%s instance_id=%s has_instance_profile=%s",
        trace_id,
        req.session_id,
        req.intent,
        req.action_key,
        action_target_mode,
        req.instance_id,
        bool(instance_profile),
    )
    completion = await generate_llm_completion(
        build_prompt_fn(req, action_payload, instance_profile, intent=action_target_mode),
        trace_id=trace_id,
        session_id=req.session_id,
        intent=action_target_mode,
    )
    content_text = sanitize_customer_visible_text_from_router(completion.content)
    memory_record = persist_memory_record(
        trace_id=trace_id,
        session_id=req.session_id,
        project_id=resolve_project_id_from_router(req, action_payload),
        user_id=resolve_user_id_from_router(req, action_payload),
        mode_key=runtime_snapshot["mode_key"],
        user_message=_resolve_turn_value(action_context, "action_message"),
        assistant_message=content_text,
        provider=completion.provider,
        model=completion.model,
        provider_status=completion.status,
    )
    has_llm_content = bool(str(content_text or "").strip())
    apply_completion_content_policy_from_router(
        orchestration_status=orchestration_status,
        command=action_command,
        has_llm_content=has_llm_content,
    )
    sync_session_intent_stage_fn(
        orchestration_status=orchestration_status,
        signal=escalation_signal,
        message=action_message,
        command=action_command,
    )
    persist_authoritative_intake_state_fn(
        trace_id=trace_id,
        session_id=req.session_id,
        project_id=resolve_project_id_from_router(req, action_payload),
        user_id=resolve_user_id_from_router(req, action_payload),
        command=action_command,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
    )
    result = build_action_result_payload_from_router(
        content_text=content_text,
        completion_provider=completion.provider,
        completion_model=completion.model,
        completion_status=completion.status,
        completion_details=completion.details,
        runtime_snapshot=runtime_snapshot,
        memory_record=memory_record,
        orchestration_status=orchestration_status,
        action_key=req.action_key,
        action_target_mode=action_target_mode,
        action_status=req.action_status,
        action_reason=req.action_reason,
    )
    if instance_profile:
        result["instance_profile"] = instance_profile
    return build_kernel_success_response_from_router(
        trace_id=trace_id,
        result=result,
        runtime_snapshot=runtime_snapshot,
        orchestration_status=orchestration_status,
    )
