"""Turn-context dependency facade for kernel handlers."""

from __future__ import annotations

from typing import Any

from flare_kernel.contracts import KernelRequest
from flare_kernel.runtime import (
    build_kernel_runtime,
    build_sqlalchemy_engine,
    generate_llm_completion,
    load_instance_profile,
    resolve_trace_id,
    search_knowledge_records,
)
from flare_kernel.runtime.infrastructure.sourcing.persistence import persist_sourcing_run_bundle
from flare_kernel.runtime.infrastructure.sourcing.instance_profile_adapter import search_instance_records
from flare_kernel.runtime.infrastructure.sourcing.provider import search_web_sources
from flare_kernel.runtime.orchestration.sourcing.search_runtime import run_sourcing_search
from flare_kernel.router.retrieval.search import (
    search_knowledge_by_queries as _search_knowledge_by_queries,
)
from flare_kernel.router.kernel_facade.dependency_resolution import (
    resolve_turn_context_dependencies,
)
from flare_kernel.router.kernel_facade.flow import prepare_kernel_turn_context_flow
from flare_kernel.router.kernel_facade.utils import (
    _kernel_attr,
    _safe_session_id,
)
from flare_kernel.router.kernel_facade.payload_enrichment import _enrich_payload
from flare_kernel.router.kernel_facade.orchestration import _build_orchestration_status
from flare_kernel.router.kernel_request_pipeline.action import (
    _resolve_command,
    _resolve_request_mode,
)
from flare_kernel.router.kernel_request_pipeline.intake import (
    _merge_intent_and_escalation_signal,
    _resolve_intent_escalation_policy_with_source,
)
from flare_kernel.router.kernel_request_pipeline.intent_query import (
    _build_retrieval_queries,
    _resolve_request_intent_with_ai,
)
from flare_kernel.router.kernel_request_pipeline.intent_signal import (
    _apply_escalation_mode_override,
    _build_intent_and_escalation_signal,
)
from flare_kernel.router.intake.status.core import (
    build_structured_search_results as build_structured_search_results_from_intake_status,
)
from flare_kernel.router.prompting import resolve_effective_command as _resolve_effective_command
from flare_kernel.router.request.identity import (
    resolve_project_id as resolve_project_id_from_router,
    resolve_user_id as resolve_user_id_from_router,
)
from flare_kernel.router.retrieval.projection import (
    resolve_retrieval_config as resolve_retrieval_config_from_router,
)
from flare_kernel.router.text_safety import (
    extract_user_message as _extract_user_message,
)
from flare_kernel.runtime.orchestration.analysis_router_runtime import (
    resolve_analysis_route as resolve_analysis_route_from_runtime,
)
from flare_kernel.runtime.project_memory import build_project_memory_context_layer


async def _prepare_kernel_turn_context(
    req: KernelRequest,
    *,
    resolve_trace_id_fn=None,
    resolve_command_fn=None,
    safe_session_id_fn=None,
    load_instance_profile_fn=None,
    resolve_intent_escalation_policy_with_source_fn=None,
    resolve_request_intent_with_ai_fn=None,
    extract_user_message_fn=None,
    build_intent_and_escalation_signal_fn=None,
    resolve_request_mode_fn=None,
    apply_escalation_mode_override_fn=None,
    resolve_project_id_fn=None,
    resolve_user_id_fn=None,
    resolve_retrieval_config_fn=None,
    build_retrieval_queries_fn=None,
    search_knowledge_by_queries_fn=None,
    enrich_payload_fn=None,
    build_kernel_runtime_fn=None,
    build_orchestration_status_fn=None,
    merge_intent_and_escalation_signal_fn=None,
    resolve_effective_command_fn=None,
    build_structured_search_results_fn=None,
    generate_llm_completion_fn=None,
    search_web_sources_fn=None,
    search_instance_records_fn=None,
    resolve_analysis_route_fn=None,
    build_project_memory_context_layer_fn=None,
    run_sourcing_search_fn=None,
    search_knowledge_records_fn=None,
    persist_sourcing_run_bundle_fn=None,
) -> dict[str, Any]:
    turn_context_deps = resolve_turn_context_dependencies(
        resolve_trace_id_fn=resolve_trace_id_fn,
        resolve_command_fn=resolve_command_fn,
        safe_session_id_fn=safe_session_id_fn,
        load_instance_profile_fn=load_instance_profile_fn,
        resolve_intent_escalation_policy_with_source_fn=resolve_intent_escalation_policy_with_source_fn,
        resolve_request_intent_with_ai_fn=resolve_request_intent_with_ai_fn,
        extract_user_message_fn=extract_user_message_fn,
        build_intent_and_escalation_signal_fn=build_intent_and_escalation_signal_fn,
        resolve_request_mode_fn=resolve_request_mode_fn,
        apply_escalation_mode_override_fn=apply_escalation_mode_override_fn,
        resolve_project_id_fn=resolve_project_id_fn,
        resolve_user_id_fn=resolve_user_id_fn,
        resolve_retrieval_config_fn=resolve_retrieval_config_fn,
        build_retrieval_queries_fn=build_retrieval_queries_fn,
        search_knowledge_by_queries_fn=search_knowledge_by_queries_fn,
        enrich_payload_fn=enrich_payload_fn,
        build_kernel_runtime_fn=build_kernel_runtime_fn,
        build_orchestration_status_fn=build_orchestration_status_fn,
        merge_intent_and_escalation_signal_fn=merge_intent_and_escalation_signal_fn,
        resolve_effective_command_fn=resolve_effective_command_fn,
        build_structured_search_results_fn=build_structured_search_results_fn,
        generate_llm_completion_fn=generate_llm_completion_fn,
        resolve_analysis_route_fn=resolve_analysis_route_fn,
        build_project_memory_context_layer_fn=build_project_memory_context_layer_fn,
        run_sourcing_search_fn=run_sourcing_search_fn,
        search_knowledge_records_fn=search_knowledge_records_fn,
        search_web_sources_fn=search_web_sources_fn,
        search_instance_records_fn=search_instance_records_fn,
        persist_sourcing_run_bundle_fn=persist_sourcing_run_bundle_fn,
        kernel_attr_fn=_kernel_attr,
        defaults={
            "resolve_trace_id_fn": resolve_trace_id,
            "resolve_command_fn": _resolve_command,
            "safe_session_id_fn": _safe_session_id,
            "load_instance_profile_fn": load_instance_profile,
            "resolve_intent_escalation_policy_with_source_fn": _resolve_intent_escalation_policy_with_source,
            "resolve_request_intent_with_ai_fn": _resolve_request_intent_with_ai,
            "extract_user_message_fn": _extract_user_message,
            "build_intent_and_escalation_signal_fn": _build_intent_and_escalation_signal,
            "resolve_request_mode_fn": _resolve_request_mode,
            "apply_escalation_mode_override_fn": _apply_escalation_mode_override,
            "resolve_project_id_fn": resolve_project_id_from_router,
            "resolve_user_id_fn": resolve_user_id_from_router,
            "resolve_retrieval_config_fn": resolve_retrieval_config_from_router,
            "build_retrieval_queries_fn": _build_retrieval_queries,
            "search_knowledge_by_queries_fn": _search_knowledge_by_queries,
            "enrich_payload_fn": _enrich_payload,
            "build_kernel_runtime_fn": build_kernel_runtime,
            "build_orchestration_status_fn": _build_orchestration_status,
            "merge_intent_and_escalation_signal_fn": _merge_intent_and_escalation_signal,
            "resolve_effective_command_fn": _resolve_effective_command,
            "build_structured_search_results_fn": build_structured_search_results_from_intake_status,
            "generate_llm_completion_fn": generate_llm_completion,
            "resolve_analysis_route_fn": resolve_analysis_route_from_runtime,
            "build_project_memory_context_layer_fn": build_project_memory_context_layer,
            "run_sourcing_search_fn": run_sourcing_search,
            "search_knowledge_records_fn": search_knowledge_records,
            "search_web_sources_fn": search_web_sources,
            "search_instance_records_fn": search_instance_records,
            "persist_sourcing_run_bundle_fn": (
                lambda **kwargs: persist_sourcing_run_bundle(
                    **kwargs,
                    build_sqlalchemy_engine_fn=build_sqlalchemy_engine,
                )
            ),
        },
    )
    return await prepare_kernel_turn_context_flow(
        req=req,
        resolve_trace_id_fn=turn_context_deps["resolve_trace_id_fn"],
        resolve_command_fn=turn_context_deps["resolve_command_fn"],
        safe_session_id_fn=turn_context_deps["safe_session_id_fn"],
        load_instance_profile_fn=turn_context_deps["load_instance_profile_fn"],
        resolve_intent_escalation_policy_with_source_fn=turn_context_deps["resolve_intent_escalation_policy_with_source_fn"],
        resolve_request_intent_with_ai_fn=turn_context_deps["resolve_request_intent_with_ai_fn"],
        extract_user_message_fn=turn_context_deps["extract_user_message_fn"],
        build_intent_and_escalation_signal_fn=turn_context_deps["build_intent_and_escalation_signal_fn"],
        resolve_request_mode_fn=turn_context_deps["resolve_request_mode_fn"],
        apply_escalation_mode_override_fn=turn_context_deps["apply_escalation_mode_override_fn"],
        resolve_project_id_fn=turn_context_deps["resolve_project_id_fn"],
        resolve_user_id_fn=turn_context_deps["resolve_user_id_fn"],
        resolve_retrieval_config_fn=turn_context_deps["resolve_retrieval_config_fn"],
        build_retrieval_queries_fn=turn_context_deps["build_retrieval_queries_fn"],
        search_knowledge_by_queries_fn=turn_context_deps["search_knowledge_by_queries_fn"],
        enrich_payload_fn=turn_context_deps["enrich_payload_fn"],
        build_kernel_runtime_fn=turn_context_deps["build_kernel_runtime_fn"],
        build_orchestration_status_fn=turn_context_deps["build_orchestration_status_fn"],
        merge_intent_and_escalation_signal_fn=turn_context_deps["merge_intent_and_escalation_signal_fn"],
        resolve_effective_command_fn=turn_context_deps["resolve_effective_command_fn"],
        build_structured_search_results_fn=turn_context_deps["build_structured_search_results_fn"],
        generate_llm_completion_fn=turn_context_deps["generate_llm_completion_fn"],
        search_web_sources_fn=turn_context_deps["search_web_sources_fn"],
        search_instance_records_fn=turn_context_deps["search_instance_records_fn"],
        resolve_analysis_route_fn=turn_context_deps["resolve_analysis_route_fn"],
        build_project_memory_context_layer_fn=turn_context_deps["build_project_memory_context_layer_fn"],
        run_sourcing_search_fn=turn_context_deps["run_sourcing_search_fn"],
        search_knowledge_records_fn=turn_context_deps["search_knowledge_records_fn"],
        persist_sourcing_run_bundle_fn=turn_context_deps["persist_sourcing_run_bundle_fn"],
    )


__all__ = ["prepare_kernel_turn_context_flow", "_prepare_kernel_turn_context"]
