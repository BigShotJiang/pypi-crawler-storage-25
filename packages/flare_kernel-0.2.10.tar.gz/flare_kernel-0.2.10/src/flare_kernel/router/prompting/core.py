"""Prompt and command shaping helpers for router orchestration."""

from __future__ import annotations

import json
from typing import Any, Callable

from flare_kernel.contracts import KernelRequest
from flare_kernel.router.prompting.artifact_template import append_artifact_template_prompt_parts
from flare_kernel.router.prompting.context_blocks import (
    _append_active_task_boundary_prompt_part,
    _append_project_memory_prompt_parts,
    _append_session_context_prompt_parts,
    _append_track_prompt_parts,
    _append_understanding_summary_prompt_part,
)
from flare_kernel.router.prompting.requirement_intake import append_requirement_intake_prompt_parts
from flare_kernel.router.prompting.response_strategy import append_response_strategy_prompt_parts
from flare_kernel.router.response_intent import normalize_response_intent_result, resolve_response_intent


_DOCUMENT_OUTPUT_INTENTS = frozenset({"document_template_output", "document_draft_output"})


def _normalize_prompt_intent(value: str | None) -> str:
    return str(value or "").strip().lower().replace("-", "_").replace(" ", "_")


def _is_sourcing_analysis_context(intent: str | None, payload: dict[str, Any], command: str) -> bool:
    if str(command or "").strip() != "generate_analysis":
        return False
    if str(intent or "").strip() == "intelligent_sourcing":
        return True
    analysis_route = payload.get("analysis_route")
    if isinstance(analysis_route, dict):
        if str(analysis_route.get("analysis_type") or "").strip().lower() == "sourcing":
            return True
    sourcing_candidates = payload.get("sourcing_candidates")
    if isinstance(sourcing_candidates, list) and sourcing_candidates:
        return True
    return False


def _build_analysis_instruction(*, use_sourcing_template: bool) -> str:
    context_hint = "候选池与当前上下文" if use_sourcing_template else "当前上下文"
    return (
        f"analysis_instruction: 请基于{context_hint}动态生成结构化分析正文；"
        "template_id 或模板内容只能作为结构参考和权重，不得覆盖最新上下文、候选、证据或用户已编辑内容；"
        "优先保留已确认信息、可追溯证据、当前候选与约束；信息不足时用假设、待验证项和建议补充项标注；"
        "不要再反问模板化问题。"
    )

def resolve_effective_command(
    *,
    command: str,
    resolved_mode: str,
    orchestration_status: dict[str, Any],
    message: str = "",
) -> str:
    # Analysis must only start through explicit action commands (e.g. generate_analysis).
    # Never auto-promote a plain send_message based on message text.
    _ = orchestration_status
    _ = message
    normalized_command = str(command or "").strip() or "send_message"
    if normalized_command != "send_message":
        return normalized_command
    if str(resolved_mode or "").strip() != "requirement_intake":
        return normalized_command
    return normalized_command


def build_prompt(
    req: KernelRequest,
    payload: dict[str, Any],
    instance_profile: dict[str, object] | None,
    *,
    intent: str | None = None,
    command: str | None = None,
    resolve_command: Callable[[KernelRequest], str],
    extract_user_message: Callable[[dict[str, Any] | None], str],
    sanitize_product_name_for_prompt: Callable[[str], str],
    extract_quoted_terms: Callable[[str], list[str]],
) -> str:
    effective_intent = _normalize_prompt_intent(intent or req.intent)
    message = extract_user_message(payload)
    normalized_command = str(command or "").strip()
    effective_command = normalized_command or resolve_command(req)
    # DOC HELPER — response_intent_result is the generic output-shape contract
    # exposed to the model. Domain packs may add templates later, but this core
    # prompt must not hardcode business sections or silently downgrade output.
    response_intent_result = normalize_response_intent_result(payload.get("response_intent_result"))
    if response_intent_result.get("source") == "fallback":
        response_intent_result = resolve_response_intent(
            message=message,
            payload=payload,
            resolved_mode=effective_intent,
            command=effective_command,
        )
    document_output_requested = (
        str(response_intent_result.get("response_intent") or "") in _DOCUMENT_OUTPUT_INTENTS
    )

    product_name = ""
    if instance_profile and isinstance(instance_profile.get("product_name"), str):
        product_name = sanitize_product_name_for_prompt(instance_profile.get("product_name", ""))

    prompt_parts = [
        f"intent: {effective_intent}",
        f"command: {effective_command}",
        f"session_id: {req.session_id}",
        f"response_intent_result: {json.dumps(response_intent_result, ensure_ascii=False)}",
    ]
    if isinstance(req.project_id, str) and req.project_id.strip():
        prompt_parts.append(f"project_id: {req.project_id.strip()}")
    if isinstance(req.user_id, str) and req.user_id.strip():
        prompt_parts.append(f"user_id: {req.user_id.strip()}")
    retrieved_knowledge = payload.get("retrieved_knowledge")
    if isinstance(retrieved_knowledge, list) and retrieved_knowledge:
        knowledge_text = "; ".join(
            str(item.get("content") or "").strip()
            for item in retrieved_knowledge[:3]
            if isinstance(item, dict)
        ).strip()
        if knowledge_text:
            prompt_parts.append(f"retrieved_knowledge: {knowledge_text}")
    if product_name:
        prompt_parts.append(f"product_name: {product_name}")
    _append_active_task_boundary_prompt_part(prompt_parts, payload, message)
    _append_track_prompt_parts(prompt_parts, payload)
    _append_session_context_prompt_parts(prompt_parts, payload)
    # Keep memory/context separate from citeable evidence. Only retrieved
    # knowledge/source IDs may justify source wording in the visible answer.
    prompt_parts.append(
        "context_display_rule: session_context 和 project_memory 只能作为背景信号；"
        "只有 retrieved_knowledge/source_ids 提供可追溯证据时，才展示来源依据或引用；"
        "不要因为 context 存在就把它当作引用依据。"
    )
    _append_project_memory_prompt_parts(prompt_parts, payload)
    append_response_strategy_prompt_parts(prompt_parts, payload)
    append_artifact_template_prompt_parts(prompt_parts, payload)
    _append_understanding_summary_prompt_part(prompt_parts, payload)
    if message:
        prompt_parts.append(f"user_message: {message}")
        if document_output_requested:
            prompt_parts.append("document_output_request: true")
        quoted_terms = extract_quoted_terms(message)
        if quoted_terms:
            prompt_parts.append(f"quoted_terms: {', '.join(quoted_terms)}")
    retrieval_hit_count = len(retrieved_knowledge) if isinstance(retrieved_knowledge, list) else 0
    prompt_parts.append(f"retrieval_hit_count: {retrieval_hit_count}")
    source_grounding = payload.get("source_grounding") if isinstance(payload.get("source_grounding"), dict) else {}
    if source_grounding.get("active") is True:
        prompt_parts.append(f"source_grounding: {json.dumps(source_grounding, ensure_ascii=False)}")
        prompt_parts.append(
            "source_grounded_instruction: 用户正在询问当前项目资料/附件/文件中的线索；"
            "必须直接基于 retrieved_knowledge 和 source_ids 回答，不要进入需求收集、梳理模式追问或阻塞式确认；"
            "如果用户要求整理、撰写、生成文档/模板/清单/方案/报告，先输出一版可直接使用的正文或标准结构，"
            "再补充资料命中情况、证据来源、仍缺信息与待验证项；"
            "文档/模板产出时，用户原话中的已给定细节必须作为正文种子逐项保留，不得被概括成一句“已涵盖基础内容”；"
            "如果用户只要求检查资料线索，回复结构使用：资料命中情况、已发现线索、对当前需求的影响、仍缺信息；"
            "仅当 retrieved_knowledge/source_ids 存在可引用命中时才补充来源依据；"
            "如果 retrieved_knowledge 为空或证据不足，明确说明当前资料中未找到可支撑结论的证据，并给出下一步检索/补充建议；"
            "证据不足时也不要只解释缺口；应基于用户目标给出可推进的结构化草案，并清楚标注哪些内容是待补充或待验证；"
            "不要反问‘附件中是否提到...’，因为本轮任务就是先检查附件证据。"
        )
    if effective_intent == "requirement_intake":
        # Requirement-intake prompt assembly is delegated so this facade keeps
        # orchestration shape only and does not accumulate domain content.
        append_requirement_intake_prompt_parts(
            prompt_parts,
            payload,
            document_output_requested=document_output_requested,
            effective_command=effective_command,
            build_analysis_instruction=lambda use_sourcing_template: _build_analysis_instruction(
                use_sourcing_template=use_sourcing_template
            ),
            is_sourcing_analysis_context=lambda source_payload, source_command: _is_sourcing_analysis_context(
                intent=effective_intent,
                payload=source_payload,
                command=source_command,
            ),
        )
    if effective_intent == "intelligent_sourcing":
        if isinstance(retrieved_knowledge, list) and retrieved_knowledge:
            sourcing_refs: list[str] = []
            for item in retrieved_knowledge[:3]:
                if not isinstance(item, dict):
                    continue
                title = str(item.get("title") or "").strip() or "候选线索"
                url = str(item.get("url") or "").strip()
                try:
                    score = float(item.get("score") or 0.0)
                except (TypeError, ValueError):
                    score = 0.0
                line = f"{title} | score={score:.2f}"
                if url:
                    line += f" | {url}"
                sourcing_refs.append(line)
            if sourcing_refs:
                prompt_parts.append(f"sourcing_preview_refs: {'; '.join(sourcing_refs)}")
        prompt_parts.append(
            "sourcing_instruction: 你是智能寻源助手。"
            "即使处于收集信息阶段，也必须先给 1-3 条参考候选（含来源与置信度），再追问关键缺口；"
            "不要只给问题清单；"
            "当字段不完整时，明确标注这些候选是“预检索参考”，并说明补充字段后会重排。"
        )
        if effective_command == "generate_analysis":
            prompt_parts.append(_build_analysis_instruction(use_sourcing_template=True))
    return "\n".join(prompt_parts)
