"""Field extraction helpers for requirement-intake messages."""

from __future__ import annotations

import re
from typing import Any, Callable

from flare_kernel.router.intake.canonicalization import (
    canonicalize_delivery_time_value,
    parse_simple_chinese_number,
)
from flare_kernel.router.text_safety import (
    contains_any_text,
    normalize_message_text,
)

_INTAKE_SINGLE_BUDGET_HINTS = ("单个", "单台", "每台")
_INTAKE_TOTAL_BUDGET_HINTS = ("总", "整体", "总计")
_INTAKE_BUDGET_UNSET_HINTS = ("预算还没定", "预算未定", "预算待定", "预算不确定", "预算暂不确定", "预算没有定")
_INTAKE_CONTROL_MESSAGES = (
    "继续",
    "确认提交",
    "提交",
    "开始分析",
    "开始需求分析",
    "进入智能寻源",
)
_INTAKE_INSTRUCTION_ACTION_HINTS = (
    "梳理",
    "整理",
    "生成",
    "输出",
    "总结",
    "确认",
)
_INTAKE_INSTRUCTION_CONTEXT_HINTS = (
    "当前会话",
    "当前已知",
    "已知信息",
    "关键缺口",
    "下一步",
    "待确认",
)


def is_intake_control_message(message: str) -> bool:
    """Return whether a message is an intake control action, not a field answer.

    Args:
        message: Raw user or UI-submitted text to classify.

    Returns:
        True when the normalized text is an intake control action token; otherwise False.
    """
    normalized = normalize_message_text(message)
    if normalized in _INTAKE_CONTROL_MESSAGES:
        return True
    if not normalized.startswith(("请", "帮我", "请帮我")):
        return False
    has_action = contains_any_text(normalized, _INTAKE_INSTRUCTION_ACTION_HINTS)
    has_context = contains_any_text(normalized, _INTAKE_INSTRUCTION_CONTEXT_HINTS)
    return has_action and has_context


def extract_intake_goal(message: str) -> str:
    if not message:
        return ""
    normalized = normalize_message_text(message)
    if is_intake_control_message(normalized):
        return ""
    matched = re.search(r"(?:目标|目的|希望|想要|打算)(?:是|为)?\s*([^，。；,.]{2,48})", message)
    if matched:
        goal = str(matched.group(1) or "").strip()
        if goal:
            return goal
    first_sentence = re.split(r"[，。；,.]", message, maxsplit=1)[0]
    first_sentence_text = str(first_sentence or "").strip()
    if is_intake_control_message(first_sentence_text):
        return ""
    return first_sentence_text


def extract_intake_use_case(message: str) -> str:
    if not message:
        return ""
    matched = re.search(r"(?:用于|应用于|主要用于|场景是|场景为)([^，。；,.]{2,32})", message)
    if matched:
        fallback = str(matched.group(1) or "").strip()
        return fallback
    return ""


def extract_intake_budget(message: str) -> str:
    if not message:
        return ""
    if "预算" in message and contains_any_text(message, _INTAKE_BUDGET_UNSET_HINTS):
        return ""
    matched = re.search(
        r"(?:(单个|单台|每台|总|整体|总计)\s*)?预算[^\d一二两三四五六七八九十百千万\.]{0,6}([\d一二两三四五六七八九十百千万\.]+)\s*(万|千|百|元)?",
        message,
    )
    if not matched:
        return ""
    qualifier = str(matched.group(1) or "").strip()
    raw_number = str(matched.group(2) or "").strip()
    unit = str(matched.group(3) or "").strip()
    if not raw_number:
        return ""
    prefix = ""
    if qualifier in _INTAKE_SINGLE_BUDGET_HINTS:
        prefix = "单个"
    elif qualifier in _INTAKE_TOTAL_BUDGET_HINTS:
        prefix = "总"
    if prefix:
        return f"{prefix}预算{raw_number}{unit}"
    return f"预算{raw_number}{unit}"


def extract_intake_quantity(message: str) -> str:
    if not message:
        return ""
    matched = re.search(r"(?:要|需要|预计|约|大概|采购)?\s*([\d一二两三四五六七八九十百千万]+)\s*(台|套|个|部|件|张)", message)
    if not matched:
        return ""
    raw_number = str(matched.group(1) or "").strip()
    unit = str(matched.group(2) or "").strip()
    if not raw_number or not unit:
        return ""
    normalized_number = parse_simple_chinese_number(raw_number)
    if normalized_number is None:
        return ""
    return f"{normalized_number}{unit}"


def extract_intake_constraints(message: str) -> str:
    if not message:
        return ""
    matched = re.search(r"(?:约束|限制|要求|前提)(?:是|为)?\s*([^，。；,.]{2,48})", message)
    if matched:
        return str(matched.group(1) or "").strip()
    return ""


def extract_intake_delivery_time(message: str) -> str:
    if not message:
        return ""
    canonical = canonicalize_delivery_time_value(message)
    if not isinstance(canonical, dict):
        return ""
    return str(canonical.get("display_value") or "").strip()


def resolve_intake_extraction_scope(context: dict[str, Any] | None = None) -> set[str]:
    if not isinstance(context, dict):
        return set()
    allowed_fields = context.get("allowed_fields")
    if not isinstance(allowed_fields, (list, tuple, set)):
        return set()
    normalized = {str(item or "").strip() for item in allowed_fields if str(item or "").strip()}
    return normalized


def extract_intake_fields_from_message(
    message: str,
    context: dict[str, Any] | None = None,
    *,
    normalize_message_text_fn: Callable[[str], str] = normalize_message_text,
    resolve_intake_extraction_scope_fn: Callable[[dict[str, Any] | None], set[str]] = resolve_intake_extraction_scope,
    extract_intake_goal_fn: Callable[[str], str] = extract_intake_goal,
    extract_intake_use_case_fn: Callable[[str], str] = extract_intake_use_case,
    extract_intake_budget_fn: Callable[[str], str] = extract_intake_budget,
    extract_intake_quantity_fn: Callable[[str], str] = extract_intake_quantity,
    extract_intake_constraints_fn: Callable[[str], str] = extract_intake_constraints,
    extract_intake_delivery_time_fn: Callable[[str], str] = extract_intake_delivery_time,
) -> dict[str, Any]:
    normalized_message = normalize_message_text_fn(message)
    if not normalized_message:
        return {"fields": {}, "supplementary_fields": {}, "inferred_requirements": []}
    if is_intake_control_message(normalized_message):
        return {"fields": {}, "supplementary_fields": {}, "inferred_requirements": []}
    extraction_scope = resolve_intake_extraction_scope_fn(context)
    fields: dict[str, Any] = {}
    if "goal" in extraction_scope:
        goal = extract_intake_goal_fn(normalized_message)
        if goal:
            fields["goal"] = goal
    if "use_case" in extraction_scope:
        use_case = extract_intake_use_case_fn(normalized_message)
        if use_case:
            fields["use_case"] = use_case
    if "budget" in extraction_scope:
        budget = extract_intake_budget_fn(normalized_message)
        if budget:
            fields["budget"] = budget
    if "quantity" in extraction_scope:
        quantity = extract_intake_quantity_fn(normalized_message)
        if quantity:
            fields["quantity"] = quantity
    if "constraints" in extraction_scope:
        constraints = extract_intake_constraints_fn(normalized_message)
        if constraints:
            fields["constraints"] = constraints
    if "delivery_time" in extraction_scope:
        delivery_time = extract_intake_delivery_time_fn(normalized_message)
        if delivery_time:
            fields["delivery_time"] = delivery_time

    return {
        "fields": fields,
        "supplementary_fields": {},
        "inferred_requirements": [],
    }
