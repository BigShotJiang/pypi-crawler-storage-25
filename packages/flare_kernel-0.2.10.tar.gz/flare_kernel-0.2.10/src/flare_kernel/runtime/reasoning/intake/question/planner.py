"""Next-question planning for intake reasoning."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.reasoning.intake.branching.core import (
    find_next_branch_question,
    resolve_effective_branching_policy,
)
from flare_kernel.runtime.reasoning.intake.context import _infer_understood_context
from flare_kernel.runtime.reasoning.intake.gap_detection import (
    _prioritize_specific_candidate_gaps,
    detect_candidate_information_gaps,
)
from flare_kernel.runtime.reasoning.intake.question.builder import (
    _build_contextual_question_text,
    _build_question_text,
    _resolve_question_options_from_definition,
    _resolve_question_options_from_structured,
)
from flare_kernel.runtime.reasoning.intake.question.decision import (
    build_question_decision,
    select_best_question_field,
)
from flare_kernel.runtime.reasoning.intake.shared import (
    coerce_mapping,
    has_value,
    normalize_field_list,
    normalize_text,
)


def plan_next_question_based_on_understanding(
    *,
    session_state: dict[str, Any],
    domain_context: dict[str, Any],
    hypotheses: list[dict[str, Any]],
    candidate_information_gaps: list[dict[str, Any]],
    understood_context: dict[str, Any],
    structured_output: dict[str, Any] | None = None,
) -> dict[str, Any]:
    del hypotheses
    structured = coerce_mapping(structured_output)
    structured_question = coerce_mapping(structured.get("next_question"))
    if structured_question:
        question_key = normalize_text(structured_question.get("question_key") or structured_question.get("field_key"))
        question_text = normalize_text(structured_question.get("question_text"))
        if question_key and question_text:
            return {
                "question_key": question_key,
                "question_text": question_text,
                "why_now": normalize_text(structured_question.get("why_now")) or "structured_model",
                "target_information_gap": normalize_text(structured_question.get("target_information_gap")) or question_key,
                "planning_source": "structured_model",
                "options": _resolve_question_options_from_structured(structured_question),
            }

    confirmed_fields = coerce_mapping(session_state.get("confirmed_fields"))
    required_fields = set(normalize_field_list(domain_context.get("required_fields")))
    field_definitions = {
        normalize_text(item.get("key")): item
        for item in domain_context.get("field_definitions", [])
        if isinstance(item, dict) and normalize_text(item.get("key"))
    }
    field_semantics = coerce_mapping(domain_context.get("field_semantics"))

    prioritized_gaps = _prioritize_specific_candidate_gaps(candidate_information_gaps)
    for gap in prioritized_gaps:
        if not isinstance(gap, dict):
            continue
        question_key = normalize_text(gap.get("key"))
        if not question_key or has_value(confirmed_fields.get(question_key)):
            continue
        definition = coerce_mapping(field_definitions.get(question_key))
        semantics = coerce_mapping(field_semantics.get(question_key))
        default_question = _build_question_text(question_key, definition, semantics)
        question_text = _build_contextual_question_text(
            field_key=question_key,
            default_question=default_question,
            understood_context=understood_context,
        )
        why_now = normalize_text(gap.get("reason")) or "max_information_gain"
        if question_key in required_fields:
            why_now = f"{why_now};required_to_narrow_scope"
        return {
            "question_key": question_key,
            "question_text": question_text,
            "why_now": why_now,
            "target_information_gap": question_key,
            "planning_source": "understanding_layer",
        }

    return {
        "question_key": "",
        "question_text": "",
        "why_now": "no_candidate_gap",
        "target_information_gap": "",
        "planning_source": "none",
    }


def plan_next_question(
    *,
    session_state: dict[str, Any],
    domain_context: dict[str, Any],
    hypotheses: list[dict[str, Any]],
    field_selection: dict[str, Any],
    structured_output: dict[str, Any] | None = None,
) -> dict[str, Any]:
    structured = coerce_mapping(structured_output)
    active_fields = normalize_field_list(field_selection.get("active_fields"))
    field_scores = coerce_mapping(field_selection.get("field_scores"))
    structured_question = coerce_mapping(structured.get("next_question"))
    if structured_question:
        target_field_keys = normalize_field_list(structured_question.get("target_field_keys"))
        question_key = normalize_text(
            structured_question.get("question_key")
            or structured_question.get("field_key")
            or structured_question.get("target_information_gap")
            or (target_field_keys[0] if target_field_keys else "")
        )
        if not target_field_keys and question_key:
            target_field_keys = [question_key]
        valid_target_fields = [field for field in target_field_keys if field in set(active_fields)]
        if valid_target_fields:
            selected_key = valid_target_fields[0]
            selected_question_key = question_key if question_key in set(valid_target_fields) else selected_key
            why_now = normalize_text(structured_question.get("why_now") or structured_question.get("rationale"))
            target_gap = normalize_text(structured_question.get("target_information_gap")) or selected_question_key
            return {
                "question_id": normalize_text(structured_question.get("question_id")) or f"question::{selected_key}",
                "question_key": selected_question_key,
                "question_text": normalize_text(structured_question.get("question_text")),
                "target_field_keys": valid_target_fields,
                "rationale": normalize_text(structured_question.get("rationale")) or "structured_model",
                "expected_answer_type": normalize_text(structured_question.get("expected_answer_type")) or "text",
                "priority": int(structured_question.get("priority") or 1),
                "blocking": bool(structured_question.get("blocking", True)),
                "planning_source": "structured_model",
                "source": "structured_model",
                "why_now": why_now,
                "target_information_gap": target_gap,
                "options": _resolve_question_options_from_structured(structured_question),
                "question_decision": build_question_decision(
                    selected_field_key=selected_key,
                    candidate_information_gaps=[],
                    field_scores=field_scores,
                    planning_source="structured_model",
                    why_now=why_now,
                    target_information_gap=target_gap,
                    session_state=session_state,
                ),
            }

    if not active_fields:
        return {
            "question_id": "",
            "question_text": "",
            "target_field_keys": [],
            "rationale": "no_active_fields",
            "expected_answer_type": "text",
            "priority": 0,
            "blocking": False,
            "planning_source": "none",
        }

    understood_context = _infer_understood_context(
        session_state=session_state,
        latest_input=normalize_text(session_state.get("latest_input")),
    )
    effective_branching_policy = resolve_effective_branching_policy(
        domain_context=domain_context,
        understood_context=understood_context,
    )
    branch_state = coerce_mapping(field_selection.get("branch_state"))
    branch_question = find_next_branch_question(
        policy=effective_branching_policy,
        branch_state=branch_state,
        confirmed_fields=coerce_mapping(session_state.get("confirmed_fields")),
    )
    if isinstance(branch_question, dict):
        expected_answer_type = "enum"
        if any(bool(item.get("requires_custom_input")) for item in branch_question.get("options", [])):
            expected_answer_type = "enum_or_text"
        target_field = normalize_text(branch_question.get("field_key"))
        branch_target_fields = [target_field] if target_field else []
        target_gap = normalize_text(branch_question.get("branch_node_key"))
        return {
            "question_id": f"branch::{normalize_text(branch_question.get('branch_node_key'))}",
            "question_kind": "branch",
            "branch_node_key": normalize_text(branch_question.get("branch_node_key")),
            "question_text": normalize_text(branch_question.get("question_text")),
            "target_field_keys": branch_target_fields,
            "rationale": "branching_chooser_policy",
            "expected_answer_type": expected_answer_type,
            "priority": 1,
            "blocking": True,
            "planning_source": "branching_policy",
            "source": "branching_policy",
            "why_now": "branching_chooser_policy",
            "target_information_gap": target_gap,
            "options": [dict(item) for item in branch_question.get("options", []) if isinstance(item, dict)],
            "active_field_scope": normalize_field_list(branch_question.get("active_field_scope")),
            "suppressed_field_scope": normalize_field_list(branch_question.get("suppressed_field_scope")),
            "question_decision": build_question_decision(
                selected_field_key=target_field,
                candidate_information_gaps=[],
                field_scores=field_scores,
                planning_source="branching_policy",
                why_now="branching_chooser_policy",
                target_information_gap=target_gap,
                session_state=session_state,
            ),
        }
    gap_state = detect_candidate_information_gaps(
        session_state=session_state,
        domain_context=domain_context,
        hypotheses=hypotheses,
        understood_context=understood_context,
        field_selection=field_selection,
    )
    candidate_information_gaps = [
        item
        for item in gap_state.get("candidate_information_gaps", [])
        if isinstance(item, dict) and normalize_text(item.get("key")) in set(active_fields)
    ]
    if not candidate_information_gaps:
        candidate_information_gaps = [
            item
            for item in gap_state.get("candidate_information_gaps", [])
            if isinstance(item, dict)
        ]
    branch_preferred_fields = normalize_field_list(field_selection.get("branch_preferred_fields"))
    confirmed_fields = coerce_mapping(session_state.get("confirmed_fields"))
    field_defs = {
        normalize_text(item.get("key")): item
        for item in domain_context.get("field_definitions", [])
        if isinstance(item, dict) and normalize_text(item.get("key"))
    }
    field_semantics = coerce_mapping(domain_context.get("field_semantics"))
    required_fields = set(normalize_field_list(domain_context.get("required_fields")))
    for preferred_field in branch_preferred_fields:
        if preferred_field not in set(active_fields):
            continue
        if has_value(confirmed_fields.get(preferred_field)):
            continue
        definition = coerce_mapping(field_defs.get(preferred_field))
        semantics = coerce_mapping(field_semantics.get(preferred_field))
        question_text = _build_question_text(preferred_field, definition, semantics)
        why_now = "branch_preferred_followup"
        return {
            "question_id": f"question::{preferred_field}",
            "question_kind": "field",
            "branch_node_key": "",
            "question_text": question_text,
            "target_field_keys": [preferred_field],
            "rationale": why_now,
            "expected_answer_type": normalize_text(
                semantics.get("value_type")
                or ("enum" if isinstance(definition.get("options"), list) and definition.get("options") else "text")
            ),
            "priority": 1,
            "blocking": preferred_field in required_fields,
            "planning_source": "branching_policy",
            "source": "branching_policy",
            "why_now": why_now,
            "target_information_gap": preferred_field,
            "options": _resolve_question_options_from_definition(definition),
            "active_field_scope": normalize_field_list(field_selection.get("branch_active_fields")),
            "suppressed_field_scope": normalize_field_list(field_selection.get("branch_suppressed_fields")),
            "question_decision": build_question_decision(
                selected_field_key=preferred_field,
                candidate_information_gaps=candidate_information_gaps,
                field_scores=field_scores,
                planning_source="branching_policy",
                why_now=why_now,
                target_information_gap=preferred_field,
                session_state=session_state,
            ),
        }
    planned = plan_next_question_based_on_understanding(
        session_state=session_state,
        domain_context=domain_context,
        hypotheses=hypotheses,
        candidate_information_gaps=_prioritize_specific_candidate_gaps(candidate_information_gaps),
        understood_context=understood_context,
    )
    best_field = select_best_question_field(
        planned_key=normalize_text(planned.get("question_key")),
        candidate_information_gaps=candidate_information_gaps,
        active_fields=active_fields,
        field_scores=field_scores,
    )

    definition = coerce_mapping(field_defs.get(best_field))
    semantics = coerce_mapping(field_semantics.get(best_field))
    question_text = normalize_text(planned.get("question_text")) or _build_question_text(best_field, definition, semantics)
    expected_answer_type = normalize_text(
        semantics.get("value_type")
        or ("enum" if isinstance(definition.get("options"), list) and definition.get("options") else "text")
    )
    planning_source = normalize_text(planned.get("planning_source")) or "understanding_layer"
    why_now = normalize_text(planned.get("why_now"))
    target_gap = normalize_text(planned.get("target_information_gap")) or best_field

    return {
        "question_id": f"question::{best_field}",
        "question_kind": "field",
        "branch_node_key": "",
        "question_text": question_text,
        "target_field_keys": [best_field],
        "rationale": normalize_text(planned.get("why_now")) or f"max_information_gain:{best_field}",
        "expected_answer_type": expected_answer_type,
        "priority": 1,
        "blocking": best_field in required_fields,
        "planning_source": planning_source,
        "source": planning_source,
        "why_now": why_now,
        "target_information_gap": target_gap,
        "options": _resolve_question_options_from_definition(definition),
        "active_field_scope": normalize_field_list(field_selection.get("branch_active_fields")),
        "suppressed_field_scope": normalize_field_list(field_selection.get("branch_suppressed_fields")),
        "question_decision": build_question_decision(
            selected_field_key=best_field,
            candidate_information_gaps=candidate_information_gaps,
            field_scores=field_scores,
            planning_source=planning_source,
            why_now=why_now,
            target_information_gap=target_gap,
            session_state=session_state,
        ),
    }


__all__ = ["plan_next_question", "plan_next_question_based_on_understanding"]
