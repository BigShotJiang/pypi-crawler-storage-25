"""Question text and option assembly for intake reasoning."""

from __future__ import annotations

import re
from typing import Any

from flare_kernel.runtime.reasoning.intake.shared import normalize_text


def _build_question_text(field_key: str, definition: dict[str, Any], semantics: dict[str, Any]) -> str:
    explicit = normalize_text(definition.get("question"))
    if explicit:
        return explicit
    label = normalize_text(definition.get("label")) or field_key
    value_type = normalize_text(semantics.get("value_type")).lower()
    if value_type in {"integer", "number"}:
        return f"请补充 {label} 的数量值。"
    if value_type in {"money", "money_range"}:
        return f"请补充 {label} 的预算范围。"
    if value_type == "enum":
        return f"请确认 {label}。"
    if value_type in {"date", "datetime", "time_window"}:
        return f"请补充 {label} 的时间安排。"
    return f"请补充 {label}。"


def _resolve_question_options_from_definition(definition: dict[str, Any]) -> list[dict[str, Any]]:
    options = definition.get("options")
    if not isinstance(options, list):
        return []
    normalized: list[dict[str, Any]] = []
    for item in options:
        if isinstance(item, dict):
            label = normalize_text(item.get("label") or item.get("text") or item.get("value"))
            if not label:
                continue
            normalized.append(
                {
                    "key": normalize_text(item.get("key")) or label,
                    "label": label,
                    "value": normalize_text(item.get("value")) or label,
                    "followup_hint": normalize_text(item.get("followup_hint")),
                    "requires_custom_input": bool(item.get("requires_custom_input")),
                }
            )
            continue
        label = normalize_text(item)
        if not label:
            continue
        normalized.append(
            {
                "key": label,
                "label": label,
                "value": label,
                "followup_hint": "",
                "requires_custom_input": False,
            }
        )
    return normalized


def _resolve_question_options_from_structured(question: dict[str, Any]) -> list[dict[str, Any]]:
    options = question.get("options") if isinstance(question.get("options"), list) else []
    normalized: list[dict[str, Any]] = []
    for index, item in enumerate(options, start=1):
        payload = item if isinstance(item, dict) else {"label": item, "value": item}
        label = normalize_text(payload.get("label") or payload.get("text") or payload.get("value"))
        if not label:
            continue
        normalized.append(
            {
                "key": normalize_text(payload.get("key")) or f"option_{index}",
                "label": label,
                "value": normalize_text(payload.get("value")) or label,
                "followup_hint": normalize_text(payload.get("followup_hint")),
                "requires_custom_input": bool(payload.get("requires_custom_input")),
            }
        )
    return normalized


def _clean_text_option_candidate(value: str) -> str:
    cleaned = normalize_text(value)
    cleaned = re.sub(r"^(例如|比如|如|可选|选项|是否|是用于|用于|还是|或者|或)[:：\s]*", "", cleaned)
    for delimiter in ("：", ":", "，", ","):
        if delimiter in cleaned:
            cleaned = cleaned.rsplit(delimiter, 1)[-1].strip()
    for marker in ("属于", "是", "为"):
        position = cleaned.rfind(marker)
        if position > 0 and len(cleaned[position + len(marker):].strip()) <= 32:
            cleaned = cleaned[position + len(marker):].strip()
    cleaned = re.sub(r"[。？！?!.；;，,、\s]+$", "", cleaned).strip()
    return cleaned


def _is_concrete_text_option(candidate: str) -> bool:
    if not candidate or len(candidate) > 24:
        return False
    if candidate.startswith(("其他", "其它")):
        return False
    if candidate in {"自定义", "补充说明", "自行补充"}:
        return False
    return True


def _split_text_option_candidates(value: str) -> list[str]:
    text = normalize_text(value)
    if not text:
        return []
    chunks = re.split(r"[、,，/；;]|(?:\s+or\s+)|还是|或者|(?:\s*或\s*)|？|\?", text)
    candidates: list[str] = []
    seen: set[str] = set()
    for chunk in chunks:
        candidate = _clean_text_option_candidate(chunk)
        if not _is_concrete_text_option(candidate) or candidate in seen:
            continue
        seen.add(candidate)
        candidates.append(candidate)
    return candidates


def _extract_text_option_regions(text: str) -> list[str]:
    regions = re.findall(r"[（(]([^（）()]{2,160})[）)]", text)
    marker_match = re.split(r"例如[:：]?|比如[:：]?|如[:：]", text, maxsplit=1)
    if not regions and len(marker_match) > 1:
        regions.append(marker_match[1])
    if "还是" in text:
        regions.append(text)
    return regions


def _resolve_question_options_from_text(question_text: str) -> list[dict[str, Any]]:
    """Derive chooser options from explicit examples in a question text.

    This is a generic projection fallback only. It does not infer business
    meaning and only activates when at least two concrete example candidates
    can be extracted from the question wording itself.
    """

    text = normalize_text(question_text)
    if not text:
        return []
    regions = _extract_text_option_regions(text)
    candidates: list[str] = []
    seen: set[str] = set()
    for region in regions:
        for candidate in _split_text_option_candidates(region):
            if candidate in seen:
                continue
            seen.add(candidate)
            candidates.append(candidate)
    if len(candidates) < 2:
        return []
    return [
        {
            "key": f"derived_option_{index}",
            "label": candidate,
            "value": candidate,
            "followup_hint": "",
            "requires_custom_input": False,
        }
        for index, candidate in enumerate(candidates, start=1)
    ]


def _build_contextual_question_text(
    *,
    field_key: str,
    default_question: str,
    understood_context: dict[str, Any],
) -> str:
    del field_key, understood_context
    return default_question


__all__ = []
