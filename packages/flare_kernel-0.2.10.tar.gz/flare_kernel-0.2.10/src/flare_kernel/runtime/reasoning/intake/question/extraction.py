"""Extract next-question plan from user-visible requirement result text."""

from __future__ import annotations

import re
from typing import Any

from flare_kernel.runtime.reasoning.intake.shared import coerce_mapping, normalize_text


def _normalize_gap_key(label: str) -> str:
    normalized = normalize_text(label)
    if not normalized:
        return ""
    return normalized.lower().replace(" ", "_").replace("-", "_")


def _extract_priority_question_line(result_text: str) -> str:
    for raw_line in result_text.splitlines():
        line = normalize_text(raw_line)
        if not line:
            continue
        if line.startswith("请优先补充："):
            return normalize_text(line.replace("请优先补充：", "", 1))
        if line.startswith("下一问："):
            return normalize_text(line.replace("下一问：", "", 1).lstrip("- ").strip())
        numbered_with_question = re.match(r"^\d+[\.、]\s*[^：:]+[：:]\s*(.+)$", line)
        if numbered_with_question:
            candidate = normalize_text(numbered_with_question.group(1))
            if candidate.endswith("？") or candidate.endswith("?"):
                return candidate
        if line.endswith("？") or line.endswith("?"):
            return line
    return ""


def _coerce_single_question(value: str) -> str:
    text = normalize_text(value)
    if not text:
        return ""
    # Keep only the first interrogative sentence to avoid multi-question prompts.
    first_q_index = min(
        [idx for idx in (text.find("？"), text.find("?")) if idx >= 0] or [-1]
    )
    if first_q_index >= 0:
        truncated = normalize_text(text[: first_q_index + 1])
        return truncated
    # Fallback: cut at common conjunctions that often introduce a second ask.
    for delimiter in ("；", ";", "，并", "并且", "以及"):
        position = text.find(delimiter)
        if position > 0:
            return normalize_text(text[:position]) + "？"
    return text


def _normalize_option_text(value: str) -> str:
    return (
        normalize_text(value)
        .replace("（", "(")
        .replace("）", ")")
        .strip("“”\"'`[]【】")
        .strip()
    )


def _dedupe_options(values: list[str]) -> list[dict[str, str]]:
    seen: set[str] = set()
    normalized: list[dict[str, str]] = []
    for raw in values:
        option = _normalize_option_text(raw)
        if not option:
            continue
        key = option.lower()
        if key in seen:
            continue
        seen.add(key)
        normalized.append(
            {
                "key": f"option_{len(normalized) + 1}",
                "label": option,
                "value": option,
            }
        )
    return normalized


def _extract_options_from_question_text(question_text: str) -> list[dict[str, str]]:
    text = normalize_text(question_text)
    if not text:
        return []

    def _extract_left_candidate(value: str) -> str:
        raw = normalize_text(value)
        if not raw:
            return ""
        clauses = re.split(r"[，,。；;：:]", raw)
        candidate = normalize_text(clauses[-1] if clauses else raw)
        with_verb = re.search(r"(?:是|为|属于)\s*(.+)$", candidate)
        return normalize_text(with_verb.group(1) if with_verb else candidate)

    example_match = re.search(r"例如[:：]?\s*(.+?)(?:还是其他|还有其他|或其他|其他\??|其他？|$)", text)
    if example_match and example_match.group(1):
        example_segment = normalize_text(example_match.group(1))
        parts = re.split(r"[、,，;；/]", example_segment)
        return _dedupe_options(parts)
    binary_match = re.search(r"(?:是|为|属于)\s*([^，。；;？?]+?)\s*，?\s*还是\s*([^。；;？?]+?)(?:[。；;？?]|$)", text)
    if binary_match and binary_match.group(1) and binary_match.group(2):
        return _dedupe_options([binary_match.group(1), binary_match.group(2)])
    broad_binary_match = re.search(r"(.+?)\s*，?\s*还是\s*([^。；;？?]+?)(?:[。；;？?]|$)", text)
    if broad_binary_match and broad_binary_match.group(1) and broad_binary_match.group(2):
        return _dedupe_options([_extract_left_candidate(broad_binary_match.group(1)), broad_binary_match.group(2)])
    if "还是" in text:
        cleaned = (
            text.replace("。", "")
            .replace("？", "")
            .replace("?", "")
        )
        parts = [normalize_text(node) for node in cleaned.split("还是")]
        if parts:
            parts[0] = _extract_left_candidate(parts[0])
        return _dedupe_options(parts[-3:])
    return []


def _extract_first_gap_label(result_text: str) -> str:
    for raw_line in result_text.splitlines():
        line = normalize_text(raw_line)
        if not line:
            continue
        normalized = line.lstrip("-* ").strip()
        numbered_match = re.match(r"^\d+[\.、]\s*([^：:]{1,40})[：:]", normalized)
        if numbered_match:
            return normalize_text(numbered_match.group(1))
        emphasized_match = re.match(r"^\*\*([^*：:]{1,40})\*\*[：:]?", normalized)
        if emphasized_match:
            return normalize_text(emphasized_match.group(1))
    return ""


def extract_next_question_plan(
    *,
    result_text: str,
    current_planned_question: dict[str, Any] | None = None,
    candidate_information_gaps: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    text = normalize_text(result_text)
    planned = coerce_mapping(current_planned_question)
    if not text:
        return {}

    priority_question = _coerce_single_question(_extract_priority_question_line(text))
    if priority_question:
        fallback_gap_key = _normalize_gap_key(_extract_first_gap_label(text))
        question_key = normalize_text(
            planned.get("question_key")
            or planned.get("target_information_gap")
            or planned.get("branch_node_key")
            or fallback_gap_key
        )
        planned_options = list(planned.get("options", [])) if isinstance(planned.get("options"), list) else []
        parsed_options = _extract_options_from_question_text(priority_question)
        resolved_options = planned_options if planned_options else parsed_options
        return {
            "question_text": priority_question,
            "question_key": question_key,
            "question_kind": normalize_text(planned.get("question_kind")) or "field",
            "why_now": "result_text_priority_question",
            "options": resolved_options,
            "source": "result_extraction",
            "target_information_gap": normalize_text(planned.get("target_information_gap")) or question_key,
            "branch_node_key": normalize_text(planned.get("branch_node_key")),
        }

    first_gap_label = _extract_first_gap_label(text)
    if not first_gap_label and isinstance(candidate_information_gaps, list) and candidate_information_gaps:
        first_gap_label = normalize_text(coerce_mapping(candidate_information_gaps[0]).get("label") or coerce_mapping(candidate_information_gaps[0]).get("key"))

    gap_key = _normalize_gap_key(first_gap_label)
    if not gap_key:
        return {}
    gap_question = f"请补充：{first_gap_label}"
    return {
        "question_text": gap_question,
        "question_key": gap_key,
        "question_kind": "field",
        "why_now": "result_text_top_gap",
        "options": [],
        "source": "result_extraction",
        "target_information_gap": gap_key,
        "branch_node_key": "",
    }
