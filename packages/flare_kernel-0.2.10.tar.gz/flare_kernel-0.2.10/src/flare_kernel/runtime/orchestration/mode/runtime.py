"""Placeholder mode/context runtime helpers for the kernel."""

from __future__ import annotations

from typing import Any, Callable

from flare_engines import build_memory_recall
from flare_engines.context_runtime import build_context_usage as build_context_usage_from_engine
from flare_engines.context_runtime import get_context_budget_config as get_context_budget_config_from_engine
from flare_engines.decision import apply_domain_pack_payload_defaults as apply_domain_pack_payload_defaults_from_engine
from flare_engines.decision.mode_resolution import ModeRegistry, build_mode_registry_from_workflow
from flare_engines.decision import build_mode_runtime as build_mode_runtime_from_engine
from flare_kernel.runtime.domain.domain_pack_loader import DomainPack, load_domain_pack, resolve_domain_pack_domain
from flare_kernel.runtime.orchestration.module_prompt_registry import build_module_prompt_registry
from flare_kernel.runtime.orchestration.observation import log_kernel_runtime_generated
_FALLBACK_MODE_STATES: dict[str, str] = {
    "default": "idle",
    "requirement_intake": "collecting",
    "analysis_mode": "drafting",
    "intelligent_sourcing": "collecting",
}

_FALLBACK_MODE_ALIASES: dict[str, str] = {
    "requirement_intake": "requirement_intake",
    "analysis_mode": "analysis_mode",
    "requirement_refinement": "requirement_intake",
    "domain_analysis": "analysis_mode",
    "requirement": "requirement_intake",
    "requirements": "requirement_intake",
    "req": "requirement_intake",
    "canvas": "requirement_intake",
    "intelligent_sourcing": "intelligent_sourcing",
    "domain_workflow": "intelligent_sourcing",
    "domain_exploration": "intelligent_sourcing",
    "sourcing": "intelligent_sourcing",
    "source": "intelligent_sourcing",
    "sources": "intelligent_sourcing",
    "supplier": "intelligent_sourcing",
    "supplier_search": "intelligent_sourcing",
    "default": "default",
}


def _normalize_mode_candidate(raw_mode: Any) -> str:
    if not isinstance(raw_mode, str):
        return ""
    return raw_mode.strip().lower().replace("-", "_").replace(" ", "_")


def _build_fallback_mode_runtime(*, intent: str | None, function_type: str | None) -> dict[str, str]:
    candidates = (_normalize_mode_candidate(function_type),)
    for candidate in candidates:
        if not candidate:
            continue
        mode_key = _FALLBACK_MODE_ALIASES.get(candidate, candidate)
        mode_state = _FALLBACK_MODE_STATES.get(mode_key)
        if mode_state:
            return {"mode_key": mode_key, "mode_state": mode_state}
    return {"mode_key": "default", "mode_state": "idle"}


def _normalize_mode_runtime(mode_runtime: dict[str, str]) -> dict[str, str]:
    raw_mode_key = _normalize_mode_candidate(mode_runtime.get("mode_key"))
    mode_key = _FALLBACK_MODE_ALIASES.get(raw_mode_key, raw_mode_key or "unknown")
    mode_state = str(mode_runtime.get("mode_state") or "").strip()
    if not mode_state:
        mode_state = _FALLBACK_MODE_STATES.get(mode_key, "unknown")
    return {"mode_key": mode_key, "mode_state": mode_state}


def _resolve_function_type(req_payload: dict[str, Any]) -> str | None:
    raw_function_type = req_payload.get("function_type")
    if isinstance(raw_function_type, str):
        value = raw_function_type.strip()
        return value or None
    return None


def _apply_domain_pack_payload_defaults(
    *,
    payload: dict[str, Any],
    domain_pack: DomainPack,
    mode_key: str,
) -> dict[str, Any]:
    workflow_raw = domain_pack.workflow.raw if getattr(domain_pack.workflow, "raw", None) is not None else None
    field_policies = [
        {
            "key": policy.key,
            "label": policy.label,
            "priority": policy.priority,
            "blocker": policy.blocker,
        }
        for policy in domain_pack.field_policies()
    ]
    return apply_domain_pack_payload_defaults_from_engine(
        payload=payload,
        mode_key=mode_key,
        pack_workflow=workflow_raw if isinstance(workflow_raw, dict) else None,
        pack_fields=domain_pack.fields if isinstance(domain_pack.fields, dict) else None,
        field_policies=field_policies,
    )


def _apply_memory_recall_payload_defaults(*, payload: dict[str, Any]) -> dict[str, Any]:
    enriched = dict(payload)
    raw_memory_recall = enriched.get("memory_recall")
    if not isinstance(raw_memory_recall, list):
        return enriched
    recall_result = build_memory_recall(
        payload={"memory_recall": raw_memory_recall},
        limit=len(raw_memory_recall),
        min_score=0.0,
    )
    enriched["memory_recall"] = recall_result["items"]
    return enriched


def build_mode_runtime(*, intent: str, function_type: str | None, mode_registry: ModeRegistry | None = None) -> dict[str, str]:
    if mode_registry is None:
        return _build_fallback_mode_runtime(intent=intent, function_type=function_type)
    mode_runtime = build_mode_runtime_from_engine(
        intent=intent,
        function_type=function_type,
        mode_registry=mode_registry,
    )
    if mode_runtime.get("mode_key") == "unknown":
        return _build_fallback_mode_runtime(intent=intent, function_type=function_type)
    return _normalize_mode_runtime(mode_runtime)


def build_context_usage(
    *,
    trace_id: str,
    tenant_id: str,
    instance_id: str,
    domain_pack_version: str,
    session_id: str,
    intent: str,
    function_type: str | None,
    payload: dict[str, Any],
    instance_profile: dict[str, Any] | None,
    mode_runtime: dict[str, str],
) -> dict[str, Any]:
    return build_context_usage_from_engine(
        trace_id=trace_id,
        tenant_id=tenant_id,
        instance_id=instance_id,
        domain_pack_version=domain_pack_version,
        session_id=session_id,
        intent=intent,
        function_type=function_type,
        payload=payload,
        instance_profile=instance_profile,
        mode_runtime=mode_runtime,
    )


def get_context_budget_config() -> dict[str, int]:
    return get_context_budget_config_from_engine()


def build_kernel_runtime(
    *,
    trace_id: str,
    tenant_id: str,
    instance_id: str,
    domain_pack_version: str,
    session_id: str,
    intent: str,
    payload: dict[str, Any],
    instance_profile: dict[str, Any] | None,
    run_sourcing_search_fn: Callable[..., dict[str, Any]] | None = None,
    search_knowledge_records_fn: Callable[..., list[dict[str, Any]]] | None = None,
    search_web_sources_fn: Callable[..., Any] | None = None,
    search_instance_records_fn: Callable[..., Any] | None = None,
    search_mcp_records_fn: Callable[..., Any] | None = None,
    persist_sourcing_run_bundle_fn: Callable[..., dict[str, Any]] | None = None,
) -> dict[str, Any]:
    from flare_kernel.runtime.execution.agent_runtime import build_agent_runtime
    from flare_kernel.runtime.execution.skill_runtime import build_skill_runtime
    from flare_kernel.runtime.orchestration.artifact_template_runtime import build_artifact_template_runtime
    from flare_kernel.runtime.orchestration.mode.orchestration import build_mode_orchestration
    from flare_kernel.runtime.orchestration.mode.reasoning import build_runtime_reasoning
    from flare_kernel.runtime.orchestration.response_strategy_runtime import build_response_strategy_runtime
    from flare_kernel.runtime.orchestration.session_context_runtime import load_session_context_snapshot
    from flare_kernel.runtime.orchestration.sourcing.additive_search import apply_additive_sourcing_search
    from flare_kernel.runtime.orchestration.track_runtime import build_track_runtime

    function_type = _resolve_function_type(payload)
    domain_pack = load_domain_pack(
        instance_id=instance_id,
        domain_pack_version=domain_pack_version,
        domain=resolve_domain_pack_domain(payload=payload, instance_profile=instance_profile),
        payload=payload,
        instance_profile=instance_profile,
        tenant_id=tenant_id,
    )
    workflow_raw = domain_pack.workflow.raw if getattr(domain_pack.workflow, "raw", None) is not None else None
    mode_registry = build_mode_registry_from_workflow(workflow_raw if isinstance(workflow_raw, dict) else None)
    if mode_registry is None:
        payload_workflow = payload.get("workflow") if isinstance(payload.get("workflow"), dict) else None
        mode_registry = build_mode_registry_from_workflow(payload_workflow)
    mode_runtime = build_mode_runtime(intent=intent, function_type=function_type, mode_registry=mode_registry)
    enriched_payload = _apply_domain_pack_payload_defaults(
        payload=payload,
        domain_pack=domain_pack,
        mode_key=mode_runtime["mode_key"],
    )
    enriched_payload = _apply_memory_recall_payload_defaults(payload=enriched_payload)
    module_prompt_registry = build_module_prompt_registry(
        domain_pack=domain_pack.to_dict(),
        instance_profile=instance_profile,
        payload=enriched_payload,
    )
    enriched_payload["module_prompt_registry"] = module_prompt_registry
    context_usage = build_context_usage(
        trace_id=trace_id,
        tenant_id=tenant_id,
        instance_id=instance_id,
        domain_pack_version=domain_pack_version,
        session_id=session_id,
        intent=intent,
        function_type=function_type,
        payload=enriched_payload,
        instance_profile=instance_profile,
        mode_runtime=mode_runtime,
    )
    reasoning_result = build_runtime_reasoning(
        session_id=session_id,
        payload=enriched_payload,
        mode_runtime=mode_runtime,
    )
    session_context = load_session_context_snapshot(session_id)
    enriched_payload["session_context"] = session_context
    track_result = build_track_runtime(
        session_id=session_id,
        payload=enriched_payload,
        session_context=session_context,
        domain_pack=domain_pack.to_dict(),
        mode_runtime=mode_runtime,
    )
    enriched_payload["track_result"] = track_result
    response_strategy_result = build_response_strategy_runtime(
        payload=enriched_payload,
        domain_pack=domain_pack.to_dict(),
        mode_runtime=mode_runtime,
        track_result=track_result,
    )
    enriched_payload["response_strategy_result"] = response_strategy_result
    enriched_payload = apply_additive_sourcing_search(
        trace_id=trace_id,
        session_id=session_id,
        project_id=str(enriched_payload.get("project_id") or ""),
        user_id=str(enriched_payload.get("user_id") or ""),
        payload=enriched_payload,
        mode_runtime=mode_runtime,
        instance_profile=instance_profile,
        run_sourcing_search_fn=run_sourcing_search_fn,
        search_knowledge_records_fn=search_knowledge_records_fn,
        search_web_sources_fn=search_web_sources_fn,
        search_instance_records_fn=search_instance_records_fn,
        search_mcp_records_fn=search_mcp_records_fn,
        persist_sourcing_run_bundle_fn=persist_sourcing_run_bundle_fn,
    )
    artifact_template_result = build_artifact_template_runtime(
        payload=enriched_payload,
        domain_pack=domain_pack.to_dict(),
    )
    enriched_payload["artifact_template_result"] = artifact_template_result
    agent_runtime = build_agent_runtime(
        trace_id=trace_id,
        session_id=session_id,
        intent=intent,
        function_type=function_type,
        mode_runtime=mode_runtime,
    )
    skill_runtime = build_skill_runtime(
        trace_id=trace_id,
        session_id=session_id,
        intent=intent,
        function_type=function_type,
        mode_runtime=mode_runtime,
    )
    mode_orchestration = build_mode_orchestration(
        trace_id=trace_id,
        session_id=session_id,
        payload=enriched_payload,
        mode_runtime=mode_runtime,
        agent_runtime=agent_runtime,
        skill_runtime=skill_runtime,
        domain_pack=domain_pack.to_dict(),
    )
    log_kernel_runtime_generated(
        trace_id=trace_id,
        session_id=session_id,
        function_type=function_type,
        mode_runtime=mode_runtime,
        context_usage=context_usage,
        reasoning_result=reasoning_result,
        track_result=track_result,
        response_strategy_result=response_strategy_result,
        mode_orchestration=mode_orchestration,
    )
    data_ingestion = {
        "trace_id": trace_id,
        "session_id": session_id,
        "project_id": payload.get("project_id"),
        "user_id": payload.get("user_id"),
        "source_count": len(payload.get("knowledge_refs", [])) if isinstance(payload.get("knowledge_refs"), list) else 0,
        "status": "captured",
    }
    memory_runtime = {
        "trace_id": trace_id,
        "session_id": session_id,
        "project_id": payload.get("project_id"),
        "user_id": payload.get("user_id"),
        "status": "pending",
    }
    observation_runtime = {
        "trace_id": trace_id,
        "session_id": session_id,
        "mode_key": mode_runtime["mode_key"],
        "mode_state": mode_runtime["mode_state"],
        "status": "tracked",
        "metrics": {
            "mode_switch_count": int(payload.get("mode_switch_count") or 0),
            "retrieval_hit_count": int(payload.get("retrieval_hit_count") or 0),
            "plan_confirm_count": int(payload.get("plan_confirm_count") or 0),
            "canvas_revision_count": int(payload.get("canvas_revision_count") or 0),
            "llm_success_count": int(payload.get("llm_success_count") or 0),
        },
    }
    return {
        "mode_runtime": mode_runtime,
        "context_usage": context_usage,
        "session_context": session_context,
        "track_result": track_result,
        "response_strategy_result": response_strategy_result,
        "artifact_template_result": artifact_template_result,
        "reasoning_result": reasoning_result,
        "agent_runtime": agent_runtime,
        "skill_runtime": skill_runtime,
        "data_ingestion": data_ingestion,
        "memory_runtime": memory_runtime,
        "observation_runtime": observation_runtime,
        "module_prompt_registry": module_prompt_registry,
        "domain_pack": domain_pack.to_dict(),
        "degrade_reasons": list(domain_pack.degrade_reasons),
        **mode_orchestration,
    }
