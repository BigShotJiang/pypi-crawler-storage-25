"""
DOC HELPER — PLN-02 requirement intake canvas projection boundary.

This module only projects canonical intake state into Canvas display payloads.
It does not decide workflow state, define business fields, or persist answers.
"""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.mode.intake_canvas_content import (
    build_intake_canvas_content,
)
from flare_kernel.runtime.orchestration.canvas.toolbar_actions import (
    build_canvas_toolbar_actions,
    build_canvas_workspace_capabilities,
)


def enrich_intake_canvas_state(
    *,
    canvas_state_payload: dict[str, Any],
    fields: dict[str, Any],
    field_definitions_by_key: dict[str, dict[str, Any]],
    collected: list[str],
    missing: list[str],
    current_question: dict[str, Any] | None,
    question_lifecycle: dict[str, Any] | None = None,
    readiness: dict[str, Any] | None = None,
    next_actions: list[dict[str, Any]] | None = None,
    understanding_summary: str,
    intake_ready: bool,
    intake_completed: bool = False,
) -> dict[str, Any]:
    """Project canonical intake state into the requirement Canvas payload.

    This helper is a projection boundary.  It receives field coverage,
    question state, readiness, and next actions that were already decided by
    orchestration, then shapes them for the Canvas event contract.  It must not
    choose workflow state, infer business fields, or persist answers.

    `intake_completed` is important for the terminal apply / implement path:
    missing rows may still be retained as non-blocking gap metadata, but active
    interaction carriers such as `question_plan` must be cleared so the
    frontend chooser cannot revive a completed intake session from Canvas
    history.
    """

    enriched = dict(canvas_state_payload)
    canvas_state = dict(enriched.get("canvas_state") if isinstance(enriched.get("canvas_state"), dict) else {})
    current_field_key = _current_field_key(current_question)
    collected_rows = _build_field_rows(
        field_keys=collected,
        fields=fields,
        field_definitions_by_key=field_definitions_by_key,
        status="collected",
        current_field_key=current_field_key,
    )
    missing_rows = _build_field_rows(
        field_keys=missing,
        fields=fields,
        field_definitions_by_key=field_definitions_by_key,
        status="missing",
        current_field_key=current_field_key,
    )
    question_plan = [] if intake_completed else _build_question_plan(
        missing=missing,
        current_question=current_question,
        field_definitions_by_key=field_definitions_by_key,
    )
    del understanding_summary
    canvas_content = build_intake_canvas_content(collected_rows=collected_rows)

    versions = _replace_latest_content(canvas_state.get("versions"), canvas_content)
    toolbar_actions = build_canvas_toolbar_actions(
        copy=True,
        edit=True,
        export_markdown=False,
        fullscreen=True,
    )
    canvas_state.update(
        {
            "collected": collected_rows,
            "missing": missing_rows,
            "current_question": current_question or None,
            "question_lifecycle": question_lifecycle if isinstance(question_lifecycle, dict) else {},
            "question_plan": question_plan,
            "readiness": readiness if isinstance(readiness, dict) else {},
            "next_actions": next_actions if isinstance(next_actions, list) else [],
            "toolbar_actions": toolbar_actions,
            "workspace_capabilities": build_canvas_workspace_capabilities(toolbar_actions=toolbar_actions),
            "versions": versions,
        }
    )
    enriched["canvas_state"] = canvas_state
    enriched["canvas_content"] = _latest_version_content(versions) or canvas_content
    enriched["ui_signal"] = {
        "open_canvas_panel": True,
        "active_tab": "requirement",
        "reason": "requirement_intake_ready" if intake_ready else "requirement_intake_collecting",
    }
    return enriched


def _build_field_rows(
    *,
    field_keys: list[str],
    fields: dict[str, Any],
    field_definitions_by_key: dict[str, dict[str, Any]],
    status: str,
    current_field_key: str,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for field_key in field_keys:
        normalized_key = str(field_key or "").strip()
        if not normalized_key:
            continue
        definition = field_definitions_by_key.get(normalized_key, {})
        rows.append(
            {
                "field_key": normalized_key,
                "label": str(definition.get("label") or normalized_key),
                "value": _display_value(fields.get(normalized_key)),
                "priority": str(definition.get("priority") or status),
                "confidence": _display_value(definition.get("confidence")),
                "weight": _display_value(definition.get("weight")),
                "status": status,
                "is_current": normalized_key == current_field_key,
            }
        )
    return rows


def _build_question_plan(
    *,
    missing: list[str],
    current_question: dict[str, Any] | None,
    field_definitions_by_key: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    current_field_key = _current_field_key(current_question)
    plan: list[dict[str, Any]] = []
    for index, field_key in enumerate(missing, start=1):
        normalized_key = str(field_key or "").strip()
        if not normalized_key:
            continue
        definition = field_definitions_by_key.get(normalized_key, {})
        question_text = _question_text_for_plan(
            field_key=normalized_key,
            current_question=current_question,
            definition=definition,
        )
        plan.append(
            {
                "question_id": f"question::{normalized_key}",
                "question_revision": _question_revision_for_plan(
                    field_key=normalized_key,
                    index=index,
                    current_question=current_question,
                ),
                "question_status": _question_status_for_plan(
                    field_key=normalized_key,
                    current_question=current_question,
                ),
                "issued_at": _question_issued_at_for_plan(
                    field_key=normalized_key,
                    current_question=current_question,
                ),
                "field_key": normalized_key,
                "field_label": str(definition.get("label") or normalized_key),
                "question_text": question_text,
                "priority": str(definition.get("priority") or "core"),
                "options": _question_options_for_plan(
                    field_key=normalized_key,
                    current_question=current_question,
                    definition=definition,
                ),
                "is_current": normalized_key == current_field_key or (not current_field_key and index == 1),
            }
        )
    return plan


def _question_revision_for_plan(
    *,
    field_key: str,
    index: int,
    current_question: dict[str, Any] | None,
) -> str:
    """Resolve a stable revision for a Canvas-carried plan question.

    Current revisions come from backend planning; non-current plan rows receive
    deterministic plan revisions so the frontend does not invent them locally.
    """
    if isinstance(current_question, dict) and str(current_question.get("field_key") or "").strip() == field_key:
        revision = str(current_question.get("question_revision") or current_question.get("revision") or "").strip()
        if revision:
            return revision
    return f"plan::{field_key}:{index}"


def _question_status_for_plan(
    *,
    field_key: str,
    current_question: dict[str, Any] | None,
) -> str:
    """Resolve backend-owned status for a Canvas plan question.

    Current rows preserve lifecycle status; other plan rows are explicit active
    planned questions instead of UI-inferred state.
    """
    if isinstance(current_question, dict) and str(current_question.get("field_key") or "").strip() == field_key:
        return str(current_question.get("question_status") or current_question.get("status") or "active").strip()
    return "active"


def _question_issued_at_for_plan(
    *,
    field_key: str,
    current_question: dict[str, Any] | None,
) -> str:
    """Carry issued-at metadata copied from backend for the current plan row.

    This keeps replay deterministic and avoids generated timestamps here.
    """
    if isinstance(current_question, dict) and str(current_question.get("field_key") or "").strip() == field_key:
        return str(current_question.get("issued_at") or "").strip()
    return ""


def _question_text_for_plan(
    *,
    field_key: str,
    current_question: dict[str, Any] | None,
    definition: dict[str, Any],
) -> str:
    if isinstance(current_question, dict) and str(current_question.get("field_key") or "").strip() == field_key:
        question_text = str(current_question.get("question_text") or "").strip()
        if question_text:
            return question_text
    definition_question = str(definition.get("question") or "").strip()
    if definition_question:
        return definition_question
    return f"请确认：{definition.get('label') or field_key}"


def _question_options_for_plan(
    *,
    field_key: str,
    current_question: dict[str, Any] | None,
    definition: dict[str, Any],
) -> list[dict[str, Any]]:
    if isinstance(current_question, dict) and str(current_question.get("field_key") or "").strip() == field_key:
        options = current_question.get("options")
        if isinstance(options, list) and options:
            return [item for item in options if isinstance(item, dict)]
    options = definition.get("options")
    if isinstance(options, list):
        return [item for item in options if isinstance(item, dict)]
    return []


def _replace_latest_content(versions: Any, canvas_content: str) -> list[dict[str, Any]]:
    if not isinstance(versions, list) or not versions:
        return [{"version": 1, "content": canvas_content, "diff": "latest"}]
    normalized = [item for item in versions if isinstance(item, dict)]
    if not normalized:
        return [{"version": 1, "content": canvas_content, "diff": "latest"}]
    latest = normalized[-1]
    current = str(canvas_content or "").strip()
    if current == str(latest.get("content") or "").strip():
        return normalized
    latest_version = _version_number(latest.get("version")) or len(normalized)
    return [
        *normalized,
        {
            "version": latest_version + 1,
            "content": current,
            "diff": "replace",
        },
    ]


def _version_number(value: Any) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return 0
    return max(number, 0)


def _latest_version_content(versions: list[dict[str, Any]]) -> str:
    if not versions:
        return ""
    return str(versions[-1].get("content") or "").strip()


def _display_value(value: Any) -> str:
    if value in (None, "", [], {}):
        return ""
    if isinstance(value, list):
        return "、".join(str(item) for item in value if str(item).strip())
    if isinstance(value, dict):
        return "、".join(f"{key}: {item}" for key, item in value.items() if str(item).strip())
    return str(value)


def _current_field_key(current_question: dict[str, Any] | None) -> str:
    if not isinstance(current_question, dict):
        return ""
    return str(current_question.get("field_key") or "").strip()
