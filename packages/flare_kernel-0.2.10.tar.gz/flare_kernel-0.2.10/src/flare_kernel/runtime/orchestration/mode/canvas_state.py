"""Canvas state payload builders for mode orchestration."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.canvas.toolbar_actions import (
    build_canvas_toolbar_actions,
    build_canvas_workspace_capabilities,
)
from flare_kernel.runtime.orchestration.mode.shared import _coerce_message_excerpt


def _build_canvas_state_payload(
    *,
    mode_key: str,
    session_id: str,
    payload: dict[str, Any],
    progress: float,
    collected: list[str],
    missing: list[str],
) -> dict[str, Any]:
    version = int(payload.get("canvas_version") or 1)
    base_content = payload.get("canvas_content")
    if not isinstance(base_content, str):
        base_content = _coerce_message_excerpt(payload)
    revisions = payload.get("canvas_versions")
    if not isinstance(revisions, list) or not revisions:
        revisions = [
            {"version": 1, "content": base_content, "diff": "initial"},
            {"version": version, "content": base_content, "diff": "latest"},
        ]
    payload_obj = {
        "mode_key": mode_key,
        "session_id": session_id,
        "project_id": payload.get("project_id"),
        "render_hint": "canvas_state",
        "canvas_state": {
            "version": version,
            "confirmed": bool(payload.get("canvas_confirmed", False)),
            "progress": progress,
            "collected": collected,
            "missing": missing,
            "revision_suggestions": payload.get("revision_suggestions", []),
            "versions": revisions,
        },
    }
    if mode_key == "intelligent_sourcing":
        toolbar_actions = build_canvas_toolbar_actions(
            copy=False,
            edit=False,
            export_markdown=True,
            fullscreen=True,
        )
        payload_obj["canvas_state"]["toolbar_actions"] = toolbar_actions
        payload_obj["canvas_state"]["workspace_capabilities"] = build_canvas_workspace_capabilities(
            toolbar_actions=toolbar_actions
        )
        payload_obj["ui_signal"] = {
            "open_canvas_panel": True,
            "active_tab": "sourcing",
            "reason": "sourcing_results_ready" if float(progress) >= 1.0 else "sourcing_collecting",
        }
    return payload_obj


def _build_canvas_revision_payload(
    *,
    mode_key: str,
    session_id: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    revision_diff = payload.get("canvas_revision_diff") or "基于新输入更新关键字段。"
    candidate_content = payload.get("canvas_candidate_content") or _coerce_message_excerpt(payload)
    return {
        "mode_key": mode_key,
        "session_id": session_id,
        "project_id": payload.get("project_id"),
        "render_hint": "canvas_revision",
        "title": "Canvas 修订建议",
        "revision": {
            "candidate_version": int(payload.get("canvas_candidate_version") or 2),
            "diff": revision_diff,
            "content": candidate_content,
        },
        "actions": [
            {
                "type": "confirm_revision",
                "action_key": "accept_canvas_revision",
                "label": "接受修订",
                "target_mode": mode_key,
                "payload": {"target_mode": mode_key, "prefill_prompt": "已接受该修订，继续下一步。"},
            },
            {
                "type": "confirm_revision",
                "action_key": "reject_canvas_revision",
                "label": "暂不接受",
                "target_mode": mode_key,
                "payload": {"target_mode": mode_key, "prefill_prompt": "暂不采用该修订，请给我另一版。"},
            },
        ],
    }


__all__ = ["_build_canvas_revision_payload", "_build_canvas_state_payload"]
