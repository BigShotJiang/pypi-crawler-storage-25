"""Prompt-context content assembly for requirement-intake Canvas.

This module only formats already-projected field rows into Canvas body text.
It does not decide workflow state, ask questions, or emit next actions.
"""

from __future__ import annotations

from typing import Any


def build_intake_canvas_content(*, collected_rows: list[dict[str, Any]]) -> str:
    """Build the durable Canvas body for requirement intake.

    The Canvas body is the part that can be saved, reopened, copied into the
    next prompt, and reused by downstream analysis / sourcing / RFX flows.  For
    that reason this helper only serializes confirmed field values.  It
    intentionally excludes interactive state such as `current_question`,
    `question_plan`, missing-field prompts, readiness hints, and next actions;
    those stay in `canvas_state` where the chooser or workspace projection can
    render them without polluting the reusable prompt context.

    Args:
        collected_rows: Field rows already projected by the orchestration
            layer.  Each row may carry `field_key`, `label`, and `value`.  This
            helper treats rows without a display label or value as incomplete
            and omits them from the persisted body.

    Returns:
        Markdown-like text for the Canvas requirement tab.  If there are no
        confirmed values yet, the result is still a stable placeholder so the
        Canvas can render without inventing UI-local state.
    """

    confirmed_rows = _confirmed_rows(collected_rows)
    if not confirmed_rows:
        return "需求梳理摘要\n当前尚未形成可复用的已确认信息。"
    return _summary_prompt_section(confirmed_rows)


def _confirmed_rows(rows: list[dict[str, Any]]) -> list[tuple[str, str]]:
    """Normalize projected field rows into display-ready label/value pairs.

    The input rows come from the backend projection layer, not directly from
    user input or a provider payload.  This helper still performs defensive
    normalization because Canvas content should never expose malformed dicts,
    empty labels, or empty values.  It does not apply field policy, infer
    missing fields, or decide whether a field is authoritative; those decisions
    must happen before rows reach this formatter.
    """

    confirmed: list[tuple[str, str]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        label = str(row.get("label") or row.get("field_key") or "").strip()
        value = str(row.get("value") or "").strip()
        if label and value:
            confirmed.append((label, value))
    return confirmed


def _summary_prompt_section(rows: list[tuple[str, str]]) -> str:
    """Render confirmed fields as a single reusable prompt-context summary.

    The right-side Canvas already renders field rows separately, so the body
    should not repeat the same facts as both a bullet list and a second summary
    sentence.  This formatter turns accepted values into one concise, reusable
    requirement context paragraph.  It keeps every confirmed label/value pair
    visible for downstream prompts, but does not introduce assumptions, missing
    questions, next actions, or business-specific wording that belongs to a
    domain pack or later workflow step.
    """

    facts = "；".join(f"{label}为“{value}”" for label, value in rows)
    return "\n".join(
        [
            "需求梳理摘要",
            "",
            f"本轮已确认 {len(rows)} 项关键信息：{facts}。",
            "后续分析、供应商筛选或文档生成应以上述信息作为稳定上下文，不再重复追问这些已确认字段。",
        ]
    )


__all__ = ["build_intake_canvas_content"]
