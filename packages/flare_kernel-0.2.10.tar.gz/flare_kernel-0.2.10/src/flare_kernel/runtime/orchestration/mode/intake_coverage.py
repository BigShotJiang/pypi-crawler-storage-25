"""Requirement-intake field coverage calculations."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.mode.shared import _has_value


def build_intake_coverage(
    *,
    payload: dict[str, Any],
    fields: dict[str, Any],
    active_required_fields: list[str],
    recommended_fields: list[str],
    optional_fields: list[str],
    field_definitions: list[dict[str, Any]],
) -> dict[str, Any]:
    collected = [key for key, value in fields.items() if value not in (None, "", [], {})]
    required_collected = [field for field in active_required_fields if fields.get(field) not in (None, "", [], {})]
    recommended_collected = [field for field in recommended_fields if fields.get(field) not in (None, "", [], {})]
    optional_collected = [field for field in optional_fields if fields.get(field) not in (None, "", [], {})]
    payload_required_missing = payload.get("required_missing")
    if isinstance(payload_required_missing, list):
        declared_missing = [
            field
            for field in payload_required_missing
            if isinstance(field, str) and field.strip() and field in active_required_fields
        ]
        declared_missing_set = set(declared_missing)
        collected_set = set(required_collected)
        ordered_missing = [
            field
            for field in active_required_fields
            if field in declared_missing_set and field not in collected_set
        ]
        supplemental_missing = [
            field
            for field in declared_missing
            if field not in active_required_fields and field not in collected_set
        ]
        missing = ordered_missing + supplemental_missing
    else:
        missing = [field for field in active_required_fields if field not in required_collected]
    progress = 0.0
    if active_required_fields:
        progress = len(required_collected) / len(active_required_fields)
    field_definitions_by_key = {
        str(item.get("key")): item
        for item in field_definitions
        if isinstance(item, dict) and isinstance(item.get("key"), str)
    }
    return {
        "collected": collected,
        "field_definitions_by_key": field_definitions_by_key,
        "missing": missing,
        "optional_collected": optional_collected,
        "optional_missing": [field for field in optional_fields if not _has_value(fields.get(field))],
        "progress": progress,
        "recommended_collected": recommended_collected,
        "recommended_missing": [field for field in recommended_fields if not _has_value(fields.get(field))],
        "required_collected": required_collected,
    }


__all__ = ["build_intake_coverage"]
