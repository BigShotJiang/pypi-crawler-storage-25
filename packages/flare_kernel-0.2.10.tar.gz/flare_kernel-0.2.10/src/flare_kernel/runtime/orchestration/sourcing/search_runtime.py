"""Sourcing search orchestration runtime.

DOC HELPER — SRC-01/SRC-03/SRC-06 sourcing runtime boundary.
This module coordinates provider collection, candidate normalization/ranking,
and context patch assembly. Provider implementations stay behind adapters, and
analysis/UI decisions stay outside this runtime.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from inspect import signature
from typing import Any, Callable

from flare_engines import (
    build_default_shortlist,
    build_source_breakdown,
    merge_dedup_rank_candidates,
    normalize_sourcing_candidate,
    resolve_sourcing_task_kind,
    rerank_candidates,
    should_expand_external,
)
from flare_kernel.runtime.orchestration.sourcing.canvas_state import build_sourcing_canvas_state
from flare_kernel.runtime.orchestration.sourcing.candidate_explainability import (
    enrich_sourcing_candidates,
)
from flare_kernel.runtime.orchestration.sourcing.context_round import (
    build_sourcing_context_round,
)
from flare_kernel.runtime.orchestration.sourcing.internal_runtime import collect_internal_sourcing_hits
from flare_kernel.runtime.orchestration.sourcing.observations import (
    build_sourcing_observations,
    resolve_sourcing_final_status,
)
from flare_kernel.runtime.orchestration.sourcing.provider_health import build_provider_health_projection
from flare_kernel.runtime.orchestration.sourcing.result_window import (
    build_locked_rows,
    dedup_base_result_ids,
    resolve_max_top_k,
    resolve_requested_top_k,
)
from flare_kernel.runtime.orchestration.sourcing.source_priority import (
    build_provider_trace_entry,
    build_source_priority_decision,
    is_source_enabled,
    resolve_selected_source,
)
from flare_kernel.runtime.orchestration.sourcing.web_runtime import call_web_search


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _resolve_response_label(sourcing_task_kind: str) -> str:
    task_kind = str(sourcing_task_kind or "").strip().lower()
    if task_kind == "evaluate_rules":
        return "规则参考条目"
    if task_kind == "find_vendor":
        return "候选供应商"
    return "候选条目"


def _with_observations(result: dict[str, Any]) -> dict[str, Any]:
    return {
        **result,
        "final_status": resolve_sourcing_final_status(result),
        "observations": build_sourcing_observations(result),
    }


def _rerank_sourcing_candidates(
    *,
    query: str,
    candidates: list[dict[str, Any]],
    rank_profile: dict[str, Any] | None,
    entities: list[Any] | None,
    sourcing_task_kind: str,
) -> list[dict[str, Any]]:
    params = signature(rerank_candidates).parameters
    extra = {"sourcing_task_kind": sourcing_task_kind} if "sourcing_task_kind" in params else {}
    return rerank_candidates(
        mode="sourcing",
        query=query,
        candidates=candidates,
        rank_profile=rank_profile,
        entities=entities,
        **extra,
    )


def run_sourcing_search(
    *,
    trace_id: str,
    session_id: str,
    project_id: str,
    user_id: str,
    query: str,
    top_k: int,
    append_mode: bool = False,
    lock_existing_order: bool = True,
    base_result_ids: list[str] | None = None,
    sourcing_enabled: bool,
    search_knowledge_records_fn: Callable[..., list[dict[str, Any]]],
    search_web_sources_fn: Callable[..., list[dict[str, Any]]],
    search_instance_records_fn: Callable[..., Any] | None = None,
    search_mcp_records_fn: Callable[..., Any] | None = None,
    persist_sourcing_run_bundle_fn: Callable[..., dict[str, Any]] | None = None,
    source_scope: str = "hybrid",
    internal_threshold: int = 5,
    source_ids: list[str] | None = None,
    entities: list[Any] | None = None,
    rank_profile: dict[str, Any] | None = None,
    provider_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    sourcing_task_kind = resolve_sourcing_task_kind(query)
    response_label = _resolve_response_label(sourcing_task_kind)
    requested_top_k = resolve_requested_top_k(top_k)
    max_top_k = resolve_max_top_k()
    base_ids = dedup_base_result_ids(base_result_ids)
    priority_decision = build_source_priority_decision(
        source_scope=source_scope,
        provider_config=provider_config,
    )
    if not sourcing_enabled:
        provider_health = build_provider_health_projection(
            source_priority=priority_decision.get("source_priority"),
            provider_trace=[],
            provider_health=priority_decision.get("provider_health"),
        )
        return _with_observations({
            "blocked": True,
            "reason": "sourcing_disabled",
            "query": query,
            "source_scope": source_scope,
            "requested_top_k": requested_top_k,
            "returned_count": 0,
            "has_more": False,
            "next_top_k": requested_top_k,
            "new_results": [],
            "all_results": [],
            "source_breakdown": {"local": 0, "mcp": 0, "web": 0},
            **priority_decision,
            "provider_health": provider_health,
            "provider_trace": [],
            "results": [],
            "shortlist": [],
            "retrieval_run_id": "",
        })

    clean_scope = str(source_scope or "hybrid").strip().lower()
    if clean_scope not in {"local", "web", "hybrid"}:
        clean_scope = "hybrid"
    web_enabled = is_source_enabled(priority_decision=priority_decision, source="web")
    internal_response = collect_internal_sourcing_hits(
        clean_scope=clean_scope,
        priority_decision=priority_decision,
        search_knowledge_records_fn=search_knowledge_records_fn,
        search_instance_records_fn=search_instance_records_fn,
        search_mcp_records_fn=search_mcp_records_fn,
        query=query,
        top_k=requested_top_k,
        trace_id=trace_id,
        session_id=session_id,
        project_id=project_id,
        user_id=user_id,
        provider_config=provider_config,
        source_ids=source_ids,
    )
    internal_hits = internal_response["items"]
    provider_trace = internal_response["provider_trace"]
    internal_candidates = [
        normalize_sourcing_candidate(
            item,
            source_type=str(item.get("source_type") or item.get("source") or "local"),
            query=query,
        )
        for item in internal_hits
        if isinstance(item, dict)
    ]
    has_strong_internal_signal = any(
        float(item.get("score") or 0.0) > 0.0
        for item in internal_candidates
        if isinstance(item, dict)
    )

    external_candidates: list[dict[str, Any]] = []
    should_expand = (
        clean_scope in {"web", "hybrid"}
        and web_enabled
        and (
            clean_scope == "web"
            or (not has_strong_internal_signal)
            or should_expand_external(internal_count=len(internal_candidates), threshold=internal_threshold)
        )
    )
    if should_expand:
        web_response = call_web_search(
            search_web_sources_fn=search_web_sources_fn,
            query=query,
            top_k=requested_top_k,
            trace_id=trace_id,
            session_id=session_id,
            project_id=project_id,
            user_id=user_id,
            provider_config=provider_config,
        )
        external_hits = web_response["items"]
        web_provider_trace = web_response["provider_trace"]
        if web_provider_trace:
            provider_trace.extend(item for item in web_provider_trace if isinstance(item, dict))
        else:
            provider_trace.append(
                build_provider_trace_entry(
                    source="web",
                    status="completed",
                    hit_count=len(external_hits),
                    reason="external_expanded",
                )
            )
        external_candidates = [
            normalize_sourcing_candidate(item, source_type="web", query=query)
            for item in external_hits
            if isinstance(item, dict)
        ]
    elif clean_scope in {"web", "hybrid"} and not web_enabled:
        provider_trace.append(
            build_provider_trace_entry(
                source="web",
                status="skipped",
                hit_count=0,
                reason="source_disabled",
            )
        )
    elif clean_scope in {"web", "hybrid"}:
        provider_trace.append(
            build_provider_trace_entry(
                source="web",
                status="skipped",
                hit_count=0,
                reason="internal_signal_sufficient",
            )
        )

    merged_results = merge_dedup_rank_candidates(
        internal_candidates=internal_candidates,
        external_candidates=external_candidates,
        top_k=requested_top_k,
        max_top_k=max_top_k,
    )
    reranked_results = _rerank_sourcing_candidates(
        query=query,
        candidates=merged_results,
        rank_profile=rank_profile,
        entities=entities,
        sourcing_task_kind=sourcing_task_kind,
    )
    full_results = reranked_results[:requested_top_k]
    final_results, new_results = build_locked_rows(
        all_results=full_results,
        base_result_ids=base_ids if append_mode else [],
        lock_existing_order=lock_existing_order,
    )
    final_results = enrich_sourcing_candidates(final_results)
    new_results = enrich_sourcing_candidates(new_results)
    shortlist = build_default_shortlist(final_results)
    new_count = len(new_results) if append_mode else len(final_results)
    returned_count = len(final_results)
    has_more = returned_count < max_top_k and new_count > 0
    next_top_k = min(requested_top_k + 8, max_top_k)
    source_breakdown = build_source_breakdown(final_results)
    source_breakdown["instance_db"] = sum(
        1
        for item in final_results
        if str(item.get("source_type") or item.get("source") or "").strip().lower() == "instance_db"
    )
    selected_source = resolve_selected_source(
        source_breakdown=source_breakdown,
        fallback=str(priority_decision.get("selected_source") or ""),
    )
    provider_health = build_provider_health_projection(
        source_priority=priority_decision.get("source_priority"),
        provider_trace=provider_trace,
        provider_health=priority_decision.get("provider_health"),
    )
    persist_state: dict[str, Any] = {}
    if callable(persist_sourcing_run_bundle_fn):
        try:
            persist_state = persist_sourcing_run_bundle_fn(
                trace_id=trace_id,
                session_id=session_id,
                project_id=project_id,
                user_id=user_id,
                query=query,
                source_scope=clean_scope,
                candidates=final_results,
                shortlist=shortlist,
                append_mode=append_mode,
                requested_top_k=requested_top_k,
                returned_count=returned_count,
                new_count=new_count,
                has_more=has_more,
                next_top_k=next_top_k,
            )
        except Exception:
            persist_state = {}
    retrieval_run_id = str(persist_state.get("retrieval_run_id") or f"sourcing-{uuid.uuid4().hex}")
    context_sourcing_round = build_sourcing_context_round(
        retrieval_run_id=retrieval_run_id,
        round_value=persist_state.get("round"),
        query=query,
        sourcing_task_kind=sourcing_task_kind,
        source_scope=clean_scope,
        requested_top_k=requested_top_k,
        returned_count=returned_count,
        new_count=new_count,
        has_more=has_more,
        next_top_k=next_top_k,
        timestamp=_now_iso(),
        items=final_results,
        shortlist=shortlist,
        source_breakdown=source_breakdown,
        selected_source=selected_source,
        source_priority=priority_decision.get("source_priority"),
        fallbacks=priority_decision.get("fallbacks"),
        provider_health=provider_health,
        provider_trace=provider_trace,
    )
    return _with_observations({
        "blocked": False,
        "reason": "",
        "sourcing_task_kind": sourcing_task_kind,
        "response_label": response_label,
        "query": query,
        "source_scope": clean_scope,
        "requested_top_k": requested_top_k,
        "returned_count": returned_count,
        "has_more": has_more,
        "next_top_k": next_top_k,
        "new_results": new_results,
        "all_results": full_results,
        "source_breakdown": source_breakdown,
        **priority_decision,
        "selected_source": selected_source,
        "provider_health": provider_health,
        "provider_trace": provider_trace,
        "results": final_results,
        "shortlist": shortlist,
        "canvas_state": build_sourcing_canvas_state(
            session_id=session_id,
            project_id=project_id,
            returned_count=returned_count,
        ),
        "retrieval_run_id": retrieval_run_id,
        "persisted": bool(persist_state.get("persisted")),
        "context_patch": {"sourcing_results": [context_sourcing_round]},
        "context_revision_id": f"ctx-{uuid.uuid4().hex}",
    })
