"""Canvas state assembly for sourcing results."""

from __future__ import annotations

from typing import Any

from flare_kernel.runtime.orchestration.canvas.toolbar_actions import (
    build_canvas_toolbar_actions,
    build_canvas_workspace_capabilities,
)


def build_sourcing_canvas_state(*, session_id: str, project_id: str, returned_count: int) -> dict[str, Any]:
    toolbar_actions = build_canvas_toolbar_actions(
        copy=False,
        edit=False,
        export_markdown=True,
        fullscreen=True,
    )
    return {
        "mode_key": "intelligent_sourcing",
        "session_id": session_id,
        "project_id": project_id,
        "render_hint": "canvas_state",
        "canvas_state": {
            "version": 1,
            "confirmed": returned_count > 0,
            "progress": 1.0 if returned_count > 0 else 0.6,
            "collected": [],
            "missing": [],
            "revision_suggestions": [],
            "toolbar_actions": toolbar_actions,
            "workspace_capabilities": build_canvas_workspace_capabilities(toolbar_actions=toolbar_actions),
            "versions": [],
        },
        "ui_signal": {
            "open_canvas_panel": True,
            "active_tab": "sourcing",
            "reason": "sourcing_results_ready" if returned_count > 0 else "sourcing_collecting",
        },
    }


__all__ = ["build_sourcing_canvas_state"]
