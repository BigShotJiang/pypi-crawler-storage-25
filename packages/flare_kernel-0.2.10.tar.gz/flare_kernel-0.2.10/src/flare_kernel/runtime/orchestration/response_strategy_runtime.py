"""Kernel runtime adapter for response strategy normalization."""

from __future__ import annotations

from typing import Any

from flare_engines import run_response_strategy


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _resolve_domain_strategy(domain_pack: dict[str, Any]) -> dict[str, Any]:
    workflow = _coerce_mapping(domain_pack.get("workflow"))
    workflow_strategy = workflow.get("response_strategy")
    if isinstance(workflow_strategy, dict):
        return workflow_strategy
    strategy = domain_pack.get("response_strategy")
    return strategy if isinstance(strategy, dict) else {}


def build_response_strategy_runtime(
    *,
    payload: dict[str, Any],
    domain_pack: dict[str, Any],
    mode_runtime: dict[str, Any],
    track_result: dict[str, Any],
) -> dict[str, Any]:
    payload_strategy = payload.get("response_strategy") if isinstance(payload.get("response_strategy"), dict) else {}
    result = run_response_strategy(
        {
            "payload_strategy": payload_strategy,
            "domain_strategy": _resolve_domain_strategy(domain_pack),
            "track_result": track_result,
            "mode_key": _clean_text(mode_runtime.get("mode_key")),
        }
    )
    return {
        **result,
        "runtime": {
            "mode_key": _clean_text(mode_runtime.get("mode_key")),
            "source": "response_strategy_engine",
        },
    }


__all__ = ["build_response_strategy_runtime"]
