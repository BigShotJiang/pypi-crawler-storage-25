"""Structured reasoning generation for kernel orchestration."""

from __future__ import annotations

import json
import re
from typing import Any, Awaitable, Callable

from flare_kernel.runtime.infrastructure.logging import get_logger

logger = get_logger("flare_kernel.runtime.orchestration.structured_reasoning")


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _coerce_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _coerce_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _extract_json_object(raw_text: str) -> dict[str, Any]:
    text = str(raw_text or "").strip()
    if not text:
        return {}
    try:
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else {}
    except json.JSONDecodeError:
        match = re.search(r"\{[\s\S]*\}", text)
        if not match:
            return {}
        try:
            parsed = json.loads(match.group(0))
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            return {}


def _compact_items(items: list[Any], *, limit: int) -> list[dict[str, str]]:
    compacted: list[dict[str, str]] = []
    for item in items:
        payload = item if isinstance(item, dict) else {"text": item}
        title = _clean_text(payload.get("title") or payload.get("label") or payload.get("id"))
        text = _clean_text(payload.get("snippet") or payload.get("summary") or payload.get("content") or payload.get("text"))
        if not title and not text:
            continue
        compacted.append({"title": title[:120], "text": text[:360]})
        if len(compacted) >= limit:
            break
    return compacted


def _normalize_options(raw_options: Any) -> list[dict[str, Any]]:
    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, item in enumerate(_coerce_list(raw_options), start=1):
        payload = item if isinstance(item, dict) else {"label": item, "value": item}
        label = _clean_text(payload.get("label") or payload.get("text") or payload.get("value"))
        if not label:
            continue
        key = _clean_text(payload.get("key")) or f"option_{index}"
        dedupe_key = label.lower()
        if dedupe_key in seen:
            continue
        seen.add(dedupe_key)
        normalized.append(
            {
                "key": key,
                "label": label,
                "value": _clean_text(payload.get("value")) or label,
                "followup_hint": _clean_text(payload.get("followup_hint")),
                "requires_custom_input": bool(payload.get("requires_custom_input")),
            }
        )
        if len(normalized) >= 8:
            break
    return normalized


def _normalize_structured_output(parsed: dict[str, Any]) -> dict[str, Any]:
    question_planner = _coerce_mapping(parsed.get("question_planner"))
    next_question = _coerce_mapping(question_planner.get("next_question"))
    question_plan = _normalize_question_plan(question_planner)
    question_text = _clean_text(next_question.get("question_text") or next_question.get("text"))
    if not question_text:
        return {
            **parsed,
            "question_planner": {
                **question_planner,
                "question_plan": question_plan,
            },
        }

    target_keys = [
        _clean_text(item)
        for item in _coerce_list(next_question.get("target_field_keys"))
        if _clean_text(item)
    ]
    target_key = _clean_text(
        next_question.get("question_key")
        or next_question.get("field_key")
        or next_question.get("target_key")
        or next_question.get("target")
    )
    if not target_keys and target_key:
        target_keys = [target_key]
    if not target_key and target_keys:
        target_key = target_keys[0]
    if not target_key:
        target_key = "model_question"
        target_keys = [target_key]

    normalized_question = {
        **next_question,
        "question_id": _clean_text(next_question.get("question_id")) or f"question::{target_key}",
        "question_key": target_key,
        "field_key": target_key,
        "target_field_keys": target_keys,
        "target_information_gap": _clean_text(next_question.get("target_information_gap")) or target_key,
        "question_text": question_text,
        "rationale": _clean_text(next_question.get("rationale") or next_question.get("why_now")),
        "why_now": _clean_text(next_question.get("why_now") or next_question.get("rationale")),
        "expected_answer_type": _clean_text(next_question.get("expected_answer_type")) or "enum_or_text",
        "priority": int(next_question.get("priority") or 1),
        "blocking": bool(next_question.get("blocking", True)),
        "options": _normalize_options(next_question.get("options")),
    }
    return {
        **parsed,
        "question_planner": {
            **question_planner,
            "next_question": normalized_question,
            "question_plan": question_plan or [normalized_question],
        },
    }


def _normalize_question_plan(question_planner: dict[str, Any]) -> list[dict[str, Any]]:
    raw_plan = (
        question_planner.get("question_plan")
        or question_planner.get("planned_questions")
        or question_planner.get("questions")
    )
    plan: list[dict[str, Any]] = []
    for index, item in enumerate(_coerce_list(raw_plan), start=1):
        question = item if isinstance(item, dict) else {}
        question_text = _clean_text(question.get("question_text") or question.get("text"))
        target_key = _clean_text(
            question.get("question_key")
            or question.get("field_key")
            or question.get("target_key")
            or question.get("target")
        )
        target_keys = [_clean_text(value) for value in _coerce_list(question.get("target_field_keys")) if _clean_text(value)]
        if not target_keys and target_key:
            target_keys = [target_key]
        if not target_key and target_keys:
            target_key = target_keys[0]
        if not question_text or not target_key:
            continue
        plan.append(
            {
                **question,
                "question_id": _clean_text(question.get("question_id")) or f"question::{target_key}",
                "question_key": target_key,
                "field_key": target_key,
                "target_field_keys": target_keys,
                "target_information_gap": _clean_text(question.get("target_information_gap")) or target_key,
                "question_text": question_text,
                "rationale": _clean_text(question.get("rationale") or question.get("why_now")),
                "why_now": _clean_text(question.get("why_now") or question.get("rationale")),
                "expected_answer_type": _clean_text(question.get("expected_answer_type")) or "enum_or_text",
                "priority": int(question.get("priority") or index),
                "blocking": bool(question.get("blocking", True)),
                "options": _normalize_options(question.get("options")),
            }
        )
    return plan


def build_structured_reasoning_prompt(
    *,
    message: str,
    mode_key: str,
    payload: dict[str, Any],
    retrieved_knowledge: list[dict[str, Any]],
    instance_profile: dict[str, Any] | None,
) -> str:
    fields = _coerce_mapping(payload.get("fields"))
    context = _coerce_mapping(payload.get("context") or payload.get("session_context"))
    compact_payload = {
        "mode_key": mode_key,
        "message": _clean_text(message),
        "known_fields": fields,
        "context_summary": _clean_text(context.get("session_summary") or context.get("summary")),
        "retrieved_knowledge": _compact_items(retrieved_knowledge, limit=4),
        "instance_profile": _coerce_mapping(instance_profile),
    }
    schema = {
        "result_summary": "short summary of what the user wants",
        "hypothesis_inference": {"hypotheses": [{"id": "goal hypothesis", "score": 0.0, "rationale": "why"}]},
        "field_activation": {"active_fields": ["question_target_key"]},
        "gap_detection": {"candidate_information_gaps": [{"key": "question_target_key", "importance": 1.0, "reason": "why missing"}]},
        "question_planner": {
            "question_plan": [
                {
                    "question_key": "stable generic key",
                    "target_field_keys": ["stable generic key"],
                    "question_text": "user-facing follow-up question",
                    "rationale": "why this question belongs in the fixed plan",
                    "expected_answer_type": "enum_or_text",
                    "priority": 1,
                    "blocking": True,
                    "options": [{"key": "option_1", "label": "option label", "value": "option value"}],
                }
            ],
            "next_question": {
                "question_key": "stable generic key",
                "target_field_keys": ["stable generic key"],
                "question_text": "one best user-facing follow-up question",
                "rationale": "why this question is next",
                "expected_answer_type": "enum_or_text",
                "priority": 1,
                "blocking": True,
                "options": [{"key": "option_1", "label": "option label", "value": "option value"}],
            }
        },
    }
    return (
        "你是 FLARE 的结构化 reasoning 层，不是最终回答层。\n"
        "你的任务是先理解用户目标，再产出一个可由系统校验和投影的 JSON 中间结果。\n"
        "不要照抄静态字段选项；只有在确实贴合用户目标时才使用。"
        "如果需要追问，先生成一组固定 question_plan，再把最应该优先确认的一项放入 next_question。"
        "question_plan 要按执行顺序排列，后续系统会按这个计划逐项追问，不能临时随机扩写。"
        "每个问题都要给出贴合当前目标的候选选项。"
        "不要输出 Markdown，不要解释，只输出 JSON。\n"
        f"JSON schema example: {json.dumps(schema, ensure_ascii=False, default=str)}\n"
        f"Input: {json.dumps(compact_payload, ensure_ascii=False, default=str)}"
    )


async def generate_structured_reasoning(
    *,
    trace_id: str,
    session_id: str,
    message: str,
    mode_key: str,
    payload: dict[str, Any],
    retrieved_knowledge: list[dict[str, Any]],
    instance_profile: dict[str, Any] | None,
    generate_llm_completion_fn: Callable[..., Awaitable[Any]] | None,
) -> dict[str, Any]:
    if not callable(generate_llm_completion_fn) or not _clean_text(message):
        return {}
    prompt = build_structured_reasoning_prompt(
        message=message,
        mode_key=mode_key,
        payload=payload,
        retrieved_knowledge=retrieved_knowledge,
        instance_profile=instance_profile,
    )
    completion = await generate_llm_completion_fn(
        prompt,
        trace_id=trace_id,
        session_id=session_id,
        intent="structured_reasoning",
    )
    status = _clean_text(getattr(completion, "status", ""))
    content = _clean_text(getattr(completion, "content", ""))
    parsed = _extract_json_object(content)
    normalized = _normalize_structured_output(parsed)
    logger.info(
        "structured_reasoning.generated trace_id=%s session_id=%s mode=%s status=%s has_question=%s",
        trace_id,
        session_id,
        mode_key,
        status,
        bool(_coerce_mapping(_coerce_mapping(normalized.get("question_planner")).get("next_question")).get("question_text")),
    )
    if not normalized:
        return {}
    return {
        **normalized,
        "metadata": {
            **_coerce_mapping(normalized.get("metadata")),
            "provider_status": status,
            "source": "llm_structured_reasoning",
        },
    }


__all__ = ["build_structured_reasoning_prompt", "generate_structured_reasoning"]
