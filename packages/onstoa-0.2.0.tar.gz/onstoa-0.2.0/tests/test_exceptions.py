"""Tests for Stoa SDK exceptions."""

from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest

# Load exceptions module directly to avoid importing full stoa package
_exceptions_path = Path(__file__).parent.parent / "stoa" / "exceptions.py"
_spec = importlib.util.spec_from_file_location("stoa.exceptions", _exceptions_path)
_exceptions = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_exceptions)

InsufficientBalanceError = _exceptions.InsufficientBalanceError
StoaAPIError = _exceptions.StoaAPIError
StoaAuthenticationError = _exceptions.StoaAuthenticationError
StoaBadRequestError = _exceptions.StoaBadRequestError
StoaConnectionError = _exceptions.StoaConnectionError
StoaError = _exceptions.StoaError
StoaInternalServerError = _exceptions.StoaInternalServerError
StoaNotFoundError = _exceptions.StoaNotFoundError
StoaPermissionDeniedError = _exceptions.StoaPermissionDeniedError
StoaRateLimitError = _exceptions.StoaRateLimitError
StoaTimeoutError = _exceptions.StoaTimeoutError
UserNotFoundError = _exceptions.UserNotFoundError


# --- Inheritance tests ---


def test_stoa_error_is_exception():
    assert issubclass(StoaError, Exception)


def test_stoa_api_error_inherits_from_stoa_error():
    assert issubclass(StoaAPIError, StoaError)


@pytest.mark.parametrize(
    "exception_class",
    [
        StoaBadRequestError,
        StoaAuthenticationError,
        StoaPermissionDeniedError,
        StoaNotFoundError,
        StoaRateLimitError,
        StoaInternalServerError,
    ],
)
def test_http_errors_inherit_from_stoa_api_error(exception_class):
    assert issubclass(exception_class, StoaAPIError)
    assert issubclass(exception_class, StoaError)


@pytest.mark.parametrize(
    "exception_class",
    [
        InsufficientBalanceError,
        UserNotFoundError,
        StoaConnectionError,
        StoaTimeoutError,
    ],
)
def test_domain_errors_inherit_from_stoa_error(exception_class):
    assert issubclass(exception_class, StoaError)
    assert not issubclass(exception_class, StoaAPIError)


# --- Instantiation and attributes tests ---


def test_stoa_error_instantiation_with_message_only():
    err = StoaError("something went wrong")
    assert err.message == "something went wrong"
    assert err.response is None
    assert err.body is None
    assert str(err) == "something went wrong"


def test_stoa_error_instantiation_with_all_attributes():
    response = {"status": 500}
    body = {"error": "internal"}
    err = StoaError("server error", response=response, body=body)
    assert err.message == "server error"
    assert err.response == {"status": 500}
    assert err.body == {"error": "internal"}


def test_stoa_api_error_inherits_attributes():
    response = {"status": 400}
    body = {"detail": "bad request"}
    err = StoaBadRequestError("invalid input", response=response, body=body)
    assert err.message == "invalid input"
    assert err.response == response
    assert err.body == body


def test_insufficient_balance_error_instantiation_minimal():
    err = InsufficientBalanceError("not enough credits")
    assert err.message == "not enough credits"
    assert err.topup_url is None
    assert err.balance is None
    assert err.required is None


def test_insufficient_balance_error_instantiation_full():
    err = InsufficientBalanceError(
        "not enough credits",
        topup_url="https://stoa.dev/topup",
        balance=5.0,
        required=10.0,
    )
    assert err.message == "not enough credits"
    assert err.topup_url == "https://stoa.dev/topup"
    assert err.balance == 5.0
    assert err.required == 10.0


def test_user_not_found_error_instantiation():
    err = UserNotFoundError("user xyz not found")
    assert err.message == "user xyz not found"
    assert str(err) == "user xyz not found"


def test_connection_error_instantiation():
    err = StoaConnectionError("failed to connect", response=None, body=None)
    assert err.message == "failed to connect"


def test_timeout_error_instantiation():
    err = StoaTimeoutError("request timed out after 30s")
    assert err.message == "request timed out after 30s"


# --- Exception raising and catching tests ---


def test_stoa_error_can_be_raised_and_caught():
    with pytest.raises(StoaError) as exc_info:
        raise StoaError("test error")
    assert exc_info.value.message == "test error"


def test_api_error_caught_as_stoa_error():
    with pytest.raises(StoaError):
        raise StoaBadRequestError("bad request")


def test_specific_error_can_be_caught_specifically():
    with pytest.raises(StoaRateLimitError) as exc_info:
        raise StoaRateLimitError("too many requests", response={"retry_after": 60})
    assert exc_info.value.response == {"retry_after": 60}


# --- Serialization for logging tests ---


def test_stoa_error_str_representation():
    err = StoaError("test message")
    assert str(err) == "test message"


def test_stoa_error_repr_contains_class_name():
    err = StoaBadRequestError("invalid input")
    repr_str = repr(err)
    assert "StoaBadRequestError" in repr_str
    assert "invalid input" in repr_str


def test_insufficient_balance_error_attrs_serializable():
    err = InsufficientBalanceError(
        "insufficient funds",
        topup_url="https://stoa.dev/topup",
        balance=1.5,
        required=10.0,
    )
    log_dict = {
        "message": err.message,
        "topup_url": err.topup_url,
        "balance": err.balance,
        "required": err.required,
    }
    assert log_dict == {
        "message": "insufficient funds",
        "topup_url": "https://stoa.dev/topup",
        "balance": 1.5,
        "required": 10.0,
    }


def test_stoa_error_attrs_serializable_with_dict_body():
    body = {"code": "INVALID_TOKEN", "detail": "Token expired"}
    err = StoaAuthenticationError("auth failed", body=body)
    log_dict = {
        "message": err.message,
        "body": err.body,
    }
    assert log_dict["body"]["code"] == "INVALID_TOKEN"


def test_exception_args_tuple():
    err = StoaError("error message")
    assert err.args == ("error message",)


@pytest.mark.parametrize(
    "exception_class,expected_doc",
    [
        (StoaBadRequestError, "HTTP 400 Bad Request - Invalid request parameters."),
        (StoaAuthenticationError, "HTTP 401 Unauthorized - Invalid or missing API key."),
        (StoaPermissionDeniedError, "HTTP 403 Forbidden - API key lacks required permissions."),
        (StoaNotFoundError, "HTTP 404 Not Found - Resource does not exist."),
        (StoaRateLimitError, "HTTP 429 Too Many Requests - Rate limit exceeded. Will auto-retry."),
        (StoaInternalServerError, "HTTP 5xx Server Error - Stoa backend error. Will auto-retry."),
    ],
)
def test_http_error_docstrings(exception_class, expected_doc):
    assert exception_class.__doc__ == expected_doc
