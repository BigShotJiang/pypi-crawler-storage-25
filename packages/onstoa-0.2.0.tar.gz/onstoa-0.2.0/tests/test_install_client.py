from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from stoa import Stoa, StoaError
from stoa.install import InstallExchangeResult


def test_stoa_get_stoa_public_key_delegates(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stoa.get_stoa_public_key delegates to the HTTP client."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")

    with patch("stoa.client.StoaHTTPClient") as mock_http_cls:
        mock_http = MagicMock()
        mock_http.get_stoa_public_key.return_value = {
            "public_key": "PUBLIC KEY",
            "algorithm": "EdDSA",
        }
        mock_http_cls.return_value = mock_http

        client = Stoa()
        result = client.get_stoa_public_key()

        mock_http.get_stoa_public_key.assert_called_once_with(force_refresh=False)
        assert result["public_key"] == "PUBLIC KEY"
        assert result["algorithm"] == "EdDSA"


def test_stoa_verify_install_callback_uses_cached_key(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stoa.verify_install_callback fetches the key then verifies locally."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")

    with (
        patch("stoa.client.StoaHTTPClient") as mock_http_cls,
        patch("stoa.client.verify_install_token") as mock_verify,
    ):
        mock_http = MagicMock()
        mock_http.get_stoa_public_key.return_value = {
            "public_key": "PUBLIC KEY",
            "algorithm": "EdDSA",
        }
        mock_http_cls.return_value = mock_http
        mock_verify.return_value = {
            "membership_id": "mem_123",
            "app_id": "app_123",
            "email": "ada@example.com",
            "name": "Ada",
            "avatar_url": None,
            "user_id": None,
            "jti": "jti_123",
            "issued_at": 1,
            "expires_at": 2,
        }

        client = Stoa(app_id="app_123")
        claims = client.verify_install_callback("bootstrap-token")

        mock_http.get_stoa_public_key.assert_called_once_with(force_refresh=False)
        mock_verify.assert_called_once_with(
            token="bootstrap-token",
            public_key="PUBLIC KEY",
            app_id="app_123",
        )
        assert claims["membership_id"] == "mem_123"


def test_stoa_verify_install_callback_requires_app_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Install callback verification requires an app_id if none is configured."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")
    monkeypatch.delenv("STOA_APP_ID", raising=False)

    with patch("stoa.client.StoaHTTPClient"):
        client = Stoa()

        with pytest.raises(StoaError, match="STOA_APP_ID not set"):
            client.verify_install_callback("bootstrap-token")


def test_stoa_exchange_install_token_delegates(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stoa.exchange_install_token delegates to the HTTP client."""
    monkeypatch.setenv("STOA_API_KEY", "test-key")

    with patch("stoa.client.StoaHTTPClient") as mock_http_cls:
        mock_http = MagicMock()
        mock_http.exchange_install_token.return_value = InstallExchangeResult(
            membership_id="mem_123",
            email="ada@example.com",
            name="Ada",
            avatar_url=None,
            user_id="user_123",
        )
        mock_http_cls.return_value = mock_http

        client = Stoa()
        result = client.exchange_install_token("bootstrap-token", "user_123")

        mock_http.exchange_install_token.assert_called_once_with(
            token="bootstrap-token",
            user_id="user_123",
        )
        assert result.user_id == "user_123"
