"""Shared pytest fixtures for SDK tests."""

import pytest


@pytest.fixture(autouse=True)
def fast_retry_settings(monkeypatch: pytest.MonkeyPatch):
    """Speed up retry-based tests by removing backoff delays."""
    monkeypatch.setenv("STOA_RETRY_WAIT_MULTIPLIER", "0")
    monkeypatch.setenv("STOA_RETRY_WAIT_MAX", "0")
    monkeypatch.setenv("STOA_RETRY_WAIT_MIN", "0")
    yield
