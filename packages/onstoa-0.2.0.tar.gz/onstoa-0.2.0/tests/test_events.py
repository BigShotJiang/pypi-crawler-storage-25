"""Tests for event schema models."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

import orjson
import pytest
from pydantic import ValidationError

from stoa.events import (
    AnthropicMessagesPayload,
    CustomPayload,
    DeepgramTranscriptionPayload,
    DeepgramTTSPayload,
    ElevenLabsSTSPayload,
    ElevenLabsTTSPayload,
    ElevenLabsVoiceClonePayload,
    EventType,
    OpenAIAudioSpeechPayload,
    OpenAIAudioTranscriptionPayload,
    OpenAIChatCompletionPayload,
    OpenAICompletionPayload,
    OpenAIEmbeddingPayload,
    OpenAIImageGenerationPayload,
    OpenRouterChatCompletionPayload,
    UsageEvent,
    UsageEventBatch,
)

# ============================================================================
# EventType Tests
# ============================================================================


def test_event_type_values():
    """EventType enum should have expected values."""
    assert EventType.OPENAI_CHAT_COMPLETION.value == "openai.chat_completion"
    assert EventType.ANTHROPIC_MESSAGES.value == "anthropic.messages"
    assert EventType.ELEVENLABS_TTS.value == "elevenlabs.tts"
    assert EventType.CUSTOM.value == "custom"


def test_event_type_is_string_enum():
    """EventType should be usable as a string."""
    assert str(EventType.OPENAI_CHAT_COMPLETION) == "EventType.OPENAI_CHAT_COMPLETION"
    assert EventType.OPENAI_CHAT_COMPLETION == "openai.chat_completion"


# ============================================================================
# Payload Tests
# ============================================================================


def test_openai_chat_completion_payload():
    """OpenAIChatCompletionPayload should validate correctly."""
    payload = OpenAIChatCompletionPayload(
        model="gpt-4-turbo",
        input_tokens=100,
        output_tokens=50,
        cached_tokens=10,
        reasoning_tokens=5,
        request_id="chatcmpl-abc123",
        streaming=True,
        latency_ms=1500,
    )
    assert payload.model == "gpt-4-turbo"
    assert payload.input_tokens == 100
    assert payload.cached_tokens == 10


def test_openai_chat_completion_payload_defaults():
    """OpenAIChatCompletionPayload should have correct defaults."""
    payload = OpenAIChatCompletionPayload(
        model="gpt-4",
        input_tokens=100,
        output_tokens=50,
    )
    assert payload.cached_tokens == 0
    assert payload.reasoning_tokens == 0
    assert payload.streaming is False
    assert payload.request_id is None


def test_openai_chat_completion_payload_rejects_negative_tokens():
    """OpenAIChatCompletionPayload should reject negative token counts."""
    with pytest.raises(ValidationError):
        OpenAIChatCompletionPayload(
            model="gpt-4",
            input_tokens=-1,
            output_tokens=50,
        )


def test_anthropic_messages_payload():
    """AnthropicMessagesPayload should validate correctly."""
    payload = AnthropicMessagesPayload(
        model="claude-3-5-sonnet-20241022",
        input_tokens=200,
        output_tokens=100,
        cache_creation_input_tokens=50,
        cache_read_input_tokens=25,
    )
    assert payload.model == "claude-3-5-sonnet-20241022"
    assert payload.cache_creation_input_tokens == 50


def test_elevenlabs_tts_payload():
    """ElevenLabsTTSPayload should validate correctly."""
    payload = ElevenLabsTTSPayload(
        voice_id="JBFqnCBsd6RMkjVDRZzb",
        model_id="eleven_multilingual_v2",
        characters=1847,
        audio_duration_ms=12500,
    )
    assert payload.voice_id == "JBFqnCBsd6RMkjVDRZzb"
    assert payload.characters == 1847


def test_custom_payload():
    """CustomPayload should accept arbitrary properties."""
    payload = CustomPayload(
        metric_name="document_pages_processed",
        value=25.0,
        unit="pages",
        properties={"document_type": "pdf", "ocr_enabled": True},
    )
    assert payload.metric_name == "document_pages_processed"
    assert payload.properties["ocr_enabled"] is True


def test_deepgram_transcription_payload():
    """DeepgramTranscriptionPayload should validate correctly."""
    payload = DeepgramTranscriptionPayload(
        model="nova-2",
        tier="nova",
        duration_seconds=120.5,
        features=["diarization", "punctuation"],
    )
    assert payload.features == ["diarization", "punctuation"]


# ============================================================================
# UsageEvent Tests
# ============================================================================


def test_usage_event_creation():
    """UsageEvent should create with valid data."""
    event = UsageEvent(
        user_id="user_abc123",
        event_type=EventType.OPENAI_CHAT_COMPLETION,
        payload=OpenAIChatCompletionPayload(
            model="gpt-4-turbo",
            input_tokens=100,
            output_tokens=50,
        ),
    )
    assert event.user_id == "user_abc123"
    assert event.event_type == EventType.OPENAI_CHAT_COMPLETION
    assert event.schema_version == "1.0"
    assert isinstance(event.event_id, UUID)
    assert isinstance(event.timestamp, datetime)


def test_usage_event_validates_payload_type():
    """UsageEvent should reject mismatched payload types."""
    with pytest.raises(ValidationError) as exc_info:
        UsageEvent(
            user_id="user_abc123",
            event_type=EventType.OPENAI_CHAT_COMPLETION,
            payload=AnthropicMessagesPayload(
                model="claude-3",
                input_tokens=100,
                output_tokens=50,
            ),
        )
    assert "Payload must be OpenAIChatCompletionPayload" in str(exc_info.value)


def test_usage_event_user_id_validation():
    """UsageEvent should reject invalid user_id."""
    # Empty user_id
    with pytest.raises(ValidationError):
        UsageEvent(
            user_id="",
            event_type=EventType.OPENAI_CHAT_COMPLETION,
            payload=OpenAIChatCompletionPayload(
                model="gpt-4",
                input_tokens=100,
                output_tokens=50,
            ),
        )

    # user_id too long
    with pytest.raises(ValidationError):
        UsageEvent(
            user_id="x" * 256,
            event_type=EventType.OPENAI_CHAT_COMPLETION,
            payload=OpenAIChatCompletionPayload(
                model="gpt-4",
                input_tokens=100,
                output_tokens=50,
            ),
        )


def test_usage_event_with_app_metadata():
    """UsageEvent should accept app_metadata."""
    event = UsageEvent(
        user_id="user_abc123",
        event_type=EventType.CUSTOM,
        payload=CustomPayload(
            metric_name="api_calls",
            value=1.0,
        ),
        app_metadata={"batch_id": "batch_001", "priority": 1},
    )
    assert event.app_metadata == {"batch_id": "batch_001", "priority": 1}


# ============================================================================
# Serialization Tests
# ============================================================================


def test_usage_event_to_json():
    """UsageEvent should serialize to JSON string."""
    event = UsageEvent(
        user_id="user_abc123",
        event_type=EventType.OPENAI_CHAT_COMPLETION,
        payload=OpenAIChatCompletionPayload(
            model="gpt-4-turbo",
            input_tokens=100,
            output_tokens=50,
        ),
    )
    json_str = event.to_json()
    assert isinstance(json_str, str)
    assert "user_abc123" in json_str
    assert "gpt-4-turbo" in json_str


def test_usage_event_to_json_bytes():
    """UsageEvent should serialize to JSON bytes using orjson."""
    event = UsageEvent(
        user_id="user_abc123",
        event_type=EventType.OPENAI_CHAT_COMPLETION,
        payload=OpenAIChatCompletionPayload(
            model="gpt-4-turbo",
            input_tokens=100,
            output_tokens=50,
        ),
    )
    json_bytes = event.to_json_bytes()
    assert isinstance(json_bytes, bytes)
    # Verify it's valid JSON
    parsed = orjson.loads(json_bytes)
    assert parsed["user_id"] == "user_abc123"


def test_usage_event_from_json():
    """UsageEvent should deserialize from JSON."""
    json_str = """
    {
        "event_id": "019432a1-7c5b-7000-8000-000000000001",
        "user_id": "user_abc123",
        "event_type": "openai.chat_completion",
        "timestamp": "2025-01-03T14:30:00Z",
        "payload": {
            "model": "gpt-4-turbo",
            "input_tokens": 100,
            "output_tokens": 50
        },
        "schema_version": "1.0"
    }
    """
    event = UsageEvent.from_json(json_str)
    assert event.user_id == "user_abc123"
    assert event.event_type == EventType.OPENAI_CHAT_COMPLETION
    assert event.payload.model == "gpt-4-turbo"  # type: ignore[union-attr]


def test_usage_event_from_json_bytes():
    """UsageEvent should deserialize from JSON bytes."""
    json_bytes = (
        b'{"user_id": "user_xyz", "event_type": "anthropic.messages", '
        b'"payload": {"model": "claude-3", "input_tokens": 50, "output_tokens": 25}, '
        b'"schema_version": "1.0"}'
    )
    event = UsageEvent.from_json(json_bytes)
    assert event.user_id == "user_xyz"
    assert event.event_type == EventType.ANTHROPIC_MESSAGES


def test_usage_event_roundtrip():
    """UsageEvent should survive JSON roundtrip."""
    original = UsageEvent(
        user_id="user_roundtrip",
        event_type=EventType.ELEVENLABS_TTS,
        payload=ElevenLabsTTSPayload(
            voice_id="voice_123",
            characters=500,
        ),
        app_metadata={"session": "abc"},
    )
    json_bytes = original.to_json_bytes()
    restored = UsageEvent.from_json(json_bytes)
    assert restored.user_id == original.user_id
    assert restored.event_type == original.event_type
    assert restored.app_metadata == original.app_metadata


# ============================================================================
# UsageEventBatch Tests
# ============================================================================


def test_usage_event_batch_creation():
    """UsageEventBatch should create with valid events."""
    events = [
        UsageEvent(
            user_id="user_1",
            event_type=EventType.OPENAI_CHAT_COMPLETION,
            payload=OpenAIChatCompletionPayload(
                model="gpt-4",
                input_tokens=100,
                output_tokens=50,
            ),
        ),
        UsageEvent(
            user_id="user_2",
            event_type=EventType.ANTHROPIC_MESSAGES,
            payload=AnthropicMessagesPayload(
                model="claude-3",
                input_tokens=200,
                output_tokens=100,
            ),
        ),
    ]
    batch = UsageEventBatch(events=events)
    assert len(batch.events) == 2


def test_usage_event_batch_rejects_empty():
    """UsageEventBatch should reject empty events list."""
    with pytest.raises(ValidationError):
        UsageEventBatch(events=[])


def test_usage_event_batch_rejects_duplicate_ids():
    """UsageEventBatch should reject duplicate event_ids."""
    from uuid import uuid4

    same_id = uuid4()
    events = [
        UsageEvent(
            event_id=same_id,
            user_id="user_1",
            event_type=EventType.OPENAI_CHAT_COMPLETION,
            payload=OpenAIChatCompletionPayload(
                model="gpt-4",
                input_tokens=100,
                output_tokens=50,
            ),
        ),
        UsageEvent(
            event_id=same_id,
            user_id="user_2",
            event_type=EventType.OPENAI_CHAT_COMPLETION,
            payload=OpenAIChatCompletionPayload(
                model="gpt-4",
                input_tokens=200,
                output_tokens=100,
            ),
        ),
    ]
    with pytest.raises(ValidationError) as exc_info:
        UsageEventBatch(events=events)
    assert "Duplicate event_ids" in str(exc_info.value)


def test_usage_event_batch_serialization():
    """UsageEventBatch should serialize correctly."""
    events = [
        UsageEvent(
            user_id="user_batch",
            event_type=EventType.CUSTOM,
            payload=CustomPayload(metric_name="test", value=1.0),
        )
    ]
    batch = UsageEventBatch(events=events)
    json_bytes = batch.to_json_bytes()
    assert b"user_batch" in json_bytes


def test_usage_event_batch_deserialization():
    """UsageEventBatch should deserialize correctly."""
    json_str = """
    {
        "events": [
            {
                "user_id": "user_batch",
                "event_type": "custom",
                "payload": {"metric_name": "test", "value": 1.0},
                "schema_version": "1.0"
            }
        ]
    }
    """
    batch = UsageEventBatch.from_json(json_str)
    assert len(batch.events) == 1
    assert batch.events[0].user_id == "user_batch"


# ============================================================================
# All Payload Types - Minimal Validation
# ============================================================================


def test_all_payload_types_can_be_created():
    """All payload types should instantiate with required fields."""
    payloads = [
        OpenAIChatCompletionPayload(model="gpt-4", input_tokens=0, output_tokens=0),
        OpenAICompletionPayload(model="davinci", input_tokens=0, output_tokens=0),
        OpenAIEmbeddingPayload(model="text-embedding-3-large", input_tokens=0),
        OpenAIImageGenerationPayload(model="dall-e-3", size="1024x1024"),
        OpenAIAudioTranscriptionPayload(model="whisper-1", duration_seconds=0.0),
        OpenAIAudioSpeechPayload(model="tts-1", voice="alloy", characters=0),
        AnthropicMessagesPayload(model="claude-3", input_tokens=0, output_tokens=0),
        OpenRouterChatCompletionPayload(model="meta/llama", input_tokens=0, output_tokens=0),
        ElevenLabsTTSPayload(voice_id="abc", characters=0),
        ElevenLabsVoiceClonePayload(voice_id="cloned"),
        ElevenLabsSTSPayload(voice_id="xyz", audio_duration_ms=0),
        DeepgramTranscriptionPayload(model="nova-2", duration_seconds=0.0),
        DeepgramTTSPayload(model="aura", characters=0),
        CustomPayload(metric_name="test", value=0.0),
    ]
    assert len(payloads) == 14


def test_all_event_types_with_matching_payloads():
    """Each EventType should work with its matching payload."""
    event_payload_pairs = [
        (
            EventType.OPENAI_CHAT_COMPLETION,
            OpenAIChatCompletionPayload(model="m", input_tokens=0, output_tokens=0),
        ),
        (
            EventType.OPENAI_COMPLETION,
            OpenAICompletionPayload(model="m", input_tokens=0, output_tokens=0),
        ),
        (EventType.OPENAI_EMBEDDING, OpenAIEmbeddingPayload(model="m", input_tokens=0)),
        (
            EventType.OPENAI_IMAGE_GENERATION,
            OpenAIImageGenerationPayload(model="m", size="512x512"),
        ),
        (
            EventType.OPENAI_AUDIO_TRANSCRIPTION,
            OpenAIAudioTranscriptionPayload(model="m", duration_seconds=0.0),
        ),
        (
            EventType.OPENAI_AUDIO_SPEECH,
            OpenAIAudioSpeechPayload(model="m", voice="v", characters=0),
        ),
        (
            EventType.ANTHROPIC_MESSAGES,
            AnthropicMessagesPayload(model="m", input_tokens=0, output_tokens=0),
        ),
        (
            EventType.OPENROUTER_CHAT_COMPLETION,
            OpenRouterChatCompletionPayload(model="m", input_tokens=0, output_tokens=0),
        ),
        (EventType.ELEVENLABS_TTS, ElevenLabsTTSPayload(voice_id="v", characters=0)),
        (EventType.ELEVENLABS_VOICE_CLONE, ElevenLabsVoiceClonePayload(voice_id="v")),
        (EventType.ELEVENLABS_STS, ElevenLabsSTSPayload(voice_id="v", audio_duration_ms=0)),
        (
            EventType.DEEPGRAM_TRANSCRIPTION,
            DeepgramTranscriptionPayload(model="m", duration_seconds=0.0),
        ),
        (EventType.DEEPGRAM_TTS, DeepgramTTSPayload(model="m", characters=0)),
        (EventType.CUSTOM, CustomPayload(metric_name="m", value=0.0)),
    ]

    for event_type, payload in event_payload_pairs:
        event = UsageEvent(
            user_id="test_user",
            event_type=event_type,
            payload=payload,
        )
        assert event.event_type == event_type
