"""Tests for install flow helpers."""

from __future__ import annotations

import time

import jwt
import pytest

from stoa.install import InstallTokenClaims, verify_install_token

# ============================================================================
# Test Fixtures
# ============================================================================


INSTALL_PRIVATE_KEY = """-----BEGIN PRIVATE KEY-----
MC4CAQAwBQYDK2VwBCIEIEaGHzopvo2IvVmOD6OYSlSUH+h7G8t0bPmEfc5yTWWE
-----END PRIVATE KEY-----"""
INSTALL_PUBLIC_KEY = """-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEA/dKYEKNA0D4fQAn9uNr11jlgTAIoeghPm3QT5xtOG2c=
-----END PUBLIC KEY-----"""
APP_ID = "app_abc123"
MEMBERSHIP_ID = "mem_xyz789"


def create_test_token(
    private_key: str = INSTALL_PRIVATE_KEY,
    app_id: str = APP_ID,
    membership_id: str = MEMBERSHIP_ID,
    email: str = "ada@example.com",
    name: str | None = "Ada Lovelace",
    avatar_url: str | None = "https://example.com/avatar.png",
    external_id: str | None = "user_123",
    jti: str = "token_123",
    issuer: str = "stoa",
    expires_in: int = 300,
    issued_at: int | None = None,
) -> str:
    """Create a test JWT token mimicking Stoa's install flow."""
    now = issued_at if issued_at is not None else int(time.time())
    claims: dict = {
        "iss": issuer,
        "aud": app_id,
        "sub": membership_id,
        "email": email,
        "jti": jti,
        "iat": now,
        "exp": now + expires_in,
    }
    if name is not None:
        claims["name"] = name
    if avatar_url is not None:
        claims["avatar_url"] = avatar_url
    if external_id is not None:
        claims["external_id"] = external_id

    return jwt.encode(claims, private_key, algorithm="EdDSA")


# ============================================================================
# Success Cases
# ============================================================================


def test_verify_install_token_success():
    """verify_install_token should decode valid token with all claims."""
    token = create_test_token()

    claims = verify_install_token(token, INSTALL_PUBLIC_KEY, APP_ID)

    assert claims["membership_id"] == MEMBERSHIP_ID
    assert claims["app_id"] == APP_ID
    assert claims["email"] == "ada@example.com"
    assert claims["name"] == "Ada Lovelace"
    assert claims["avatar_url"] == "https://example.com/avatar.png"
    assert claims["user_id"] == "user_123"
    assert claims["jti"] == "token_123"
    assert claims["issued_at"] <= claims["expires_at"]


def test_verify_install_token_requires_app_id():
    """verify_install_token should always return the validated app id."""
    token = create_test_token()

    claims = verify_install_token(token, INSTALL_PUBLIC_KEY, APP_ID)

    assert claims["membership_id"] == MEMBERSHIP_ID
    assert claims["app_id"] == APP_ID
    assert claims["email"] == "ada@example.com"


def test_verify_install_token_optional_claims_none():
    """verify_install_token should handle missing optional claims."""
    token = create_test_token(name=None, avatar_url=None, external_id=None)

    claims = verify_install_token(token, INSTALL_PUBLIC_KEY, APP_ID)

    assert claims["membership_id"] == MEMBERSHIP_ID
    assert claims["app_id"] == APP_ID
    assert claims["email"] == "ada@example.com"
    assert claims["name"] is None
    assert claims["avatar_url"] is None
    assert claims["user_id"] is None


def test_verify_install_token_returns_typed_dict():
    """verify_install_token should return InstallTokenClaims type."""
    token = create_test_token()

    claims = verify_install_token(token, INSTALL_PUBLIC_KEY, APP_ID)

    assert isinstance(claims, dict)
    # Verify it has correct keys
    assert set(claims.keys()) == {
        "membership_id",
        "app_id",
        "email",
        "name",
        "avatar_url",
        "user_id",
        "jti",
        "issued_at",
        "expires_at",
    }


# ============================================================================
# Error Cases
# ============================================================================


def test_verify_install_token_expired():
    """verify_install_token should reject expired tokens."""
    past_time = int(time.time()) - 600  # 10 minutes ago
    token = create_test_token(issued_at=past_time, expires_in=300)  # Expired 5 min ago

    with pytest.raises(ValueError) as exc_info:
        verify_install_token(token, INSTALL_PUBLIC_KEY, APP_ID)

    assert "expired" in str(exc_info.value).lower()


def test_verify_install_token_wrong_secret():
    """verify_install_token should reject tokens signed with wrong secret."""
    other_private_key = """-----BEGIN PRIVATE KEY-----
MC4CAQAwBQYDK2VwBCIEIKJiXWcEV4HyV6zo5/Esz4U4MCpNlU5pqW5+2jvqApdd
-----END PRIVATE KEY-----"""
    token = create_test_token(private_key=other_private_key)

    with pytest.raises(ValueError) as exc_info:
        verify_install_token(token, INSTALL_PUBLIC_KEY, APP_ID)

    assert "invalid" in str(exc_info.value).lower()


def test_verify_install_token_wrong_audience():
    """verify_install_token should reject tokens with wrong audience."""
    token = create_test_token(app_id="different_app")

    with pytest.raises(ValueError) as exc_info:
        verify_install_token(token, INSTALL_PUBLIC_KEY, APP_ID)

    assert "audience" in str(exc_info.value).lower()


def test_verify_install_token_wrong_issuer():
    """verify_install_token should reject tokens with wrong issuer."""
    token = create_test_token(issuer="not-stoa")

    with pytest.raises(ValueError) as exc_info:
        verify_install_token(token, INSTALL_PUBLIC_KEY, APP_ID)

    assert "issuer" in str(exc_info.value).lower()


def test_verify_install_token_malformed():
    """verify_install_token should reject malformed tokens."""
    with pytest.raises(ValueError) as exc_info:
        verify_install_token("not.a.valid.token", INSTALL_PUBLIC_KEY, APP_ID)

    assert "invalid" in str(exc_info.value).lower()


def test_verify_install_token_empty():
    """verify_install_token should reject empty tokens."""
    with pytest.raises(ValueError) as exc_info:
        verify_install_token("", INSTALL_PUBLIC_KEY, APP_ID)

    assert "invalid" in str(exc_info.value).lower()


def test_verify_install_token_wrong_algorithm():
    """verify_install_token should reject tokens with non-EdDSA algorithm."""
    # Create a token with HS384 algorithm
    now = int(time.time())
    claims = {
        "iss": "stoa",
        "aud": APP_ID,
        "sub": MEMBERSHIP_ID,
        "email": "ada@example.com",
        "iat": now,
        "exp": now + 300,
    }
    token = jwt.encode(claims, "legacy-secret", algorithm="HS384")

    with pytest.raises(ValueError) as exc_info:
        verify_install_token(token, INSTALL_PUBLIC_KEY, APP_ID)

    assert "invalid" in str(exc_info.value).lower()


# ============================================================================
# Edge Cases
# ============================================================================


def test_verify_install_token_audience_case_sensitive():
    """verify_install_token should match audience case-sensitively."""
    token = create_test_token(app_id="App_ABC123")  # Different case

    with pytest.raises(ValueError) as exc_info:
        verify_install_token(token, INSTALL_PUBLIC_KEY, "app_abc123")

    assert "audience" in str(exc_info.value).lower()


def test_verify_install_token_just_before_expiry():
    """verify_install_token should accept tokens just before expiry."""
    # Token that expires in 1 second
    token = create_test_token(expires_in=1)

    claims = verify_install_token(token, INSTALL_PUBLIC_KEY, APP_ID)

    assert claims["membership_id"] == MEMBERSHIP_ID


def test_verify_install_token_special_characters_in_claims():
    """verify_install_token should handle special characters in claims."""
    token = create_test_token(
        email="user+test@example.com",
        name="José García",
        external_id="user/123#special",
    )

    claims = verify_install_token(token, INSTALL_PUBLIC_KEY, APP_ID)

    assert claims["email"] == "user+test@example.com"
    assert claims["name"] == "José García"
    assert claims["user_id"] == "user/123#special"


# ============================================================================
# Import Tests
# ============================================================================


def test_verify_install_token_exported_from_stoa():
    """verify_install_token should be importable from stoa package."""
    from stoa import verify_install_token as imported_func

    assert imported_func is verify_install_token


def test_install_token_claims_exported_from_stoa():
    """InstallTokenClaims should be importable from stoa package."""
    from stoa import InstallTokenClaims as ImportedType

    assert ImportedType is InstallTokenClaims
