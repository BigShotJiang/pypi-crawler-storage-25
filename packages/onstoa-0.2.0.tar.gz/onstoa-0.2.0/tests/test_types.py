"""
Static analysis tests to verify type annotations match actual behavior.

These tests ensure:
1. py.typed marker exists for PEP 561 compliance
2. Public API types are properly exported and accessible
3. Type annotations are introspectable at runtime
4. Exception hierarchy is properly typed
"""

from __future__ import annotations

import inspect
from pathlib import Path
from typing import Any, get_type_hints

import stoa
from stoa import (
    InsufficientBalanceError,
    Stoa,
    StoaAPIError,
    StoaError,
    UserNotFoundError,
)
from stoa.exceptions import (
    StoaAuthenticationError,
    StoaBadRequestError,
    StoaConnectionError,
    StoaInternalServerError,
    StoaNotFoundError,
    StoaPermissionDeniedError,
    StoaRateLimitError,
    StoaTimeoutError,
)
from stoa.http import StoaHTTPClient
from stoa.proxy import StoaProxy


def test_py_typed_marker_exists() -> None:
    """Verify py.typed marker exists for PEP 561 compliance."""
    stoa_package_dir = Path(stoa.__file__).parent
    py_typed_path = stoa_package_dir / "py.typed"
    assert py_typed_path.exists(), "py.typed marker must exist for PEP 561 compliance"


def test_public_api_exports() -> None:
    """Verify all public API items are exported from the main package."""
    expected_exports = {
        # Client
        "Stoa",
        # Events
        "EventType",
        "EventPayload",
        "UsageEvent",
        "UsageEventBatch",
        # Payloads
        "OpenAIChatCompletionPayload",
        "OpenAICompletionPayload",
        "OpenAIEmbeddingPayload",
        "OpenAIImageGenerationPayload",
        "OpenAIAudioTranscriptionPayload",
        "OpenAIAudioSpeechPayload",
        "AnthropicMessagesPayload",
        "OpenRouterChatCompletionPayload",
        "ElevenLabsTTSPayload",
        "ElevenLabsVoiceClonePayload",
        "ElevenLabsSTSPayload",
        "DeepgramTranscriptionPayload",
        "DeepgramTTSPayload",
        "CustomPayload",
        # Exceptions
        "StoaError",
        "StoaAPIError",
        "InsufficientBalanceError",
        "UserNotFoundError",
        # Install flow
        "verify_install_token",
        "InstallTokenClaims",
        "InstallPublicKey",
        "InstallExchangeResult",
        # Connect flow
        "verify_connect_token",
        "ConnectTokenClaims",
        # Vetted member registration
        "EmbeddedMembershipResult",
    }
    actual_exports = set(stoa.__all__)
    assert expected_exports == actual_exports


def test_version_is_string() -> None:
    """Verify __version__ is a string."""
    assert isinstance(stoa.__version__, str)
    assert len(stoa.__version__) > 0


def test_stoa_client_init_type_hints() -> None:
    """Verify Stoa.__init__ has proper type hints."""
    hints = get_type_hints(Stoa.__init__)
    assert "api_key" in hints
    assert "base_url" in hints
    # __init__ methods implicitly return None, so return may not be in hints


def test_stoa_client_method_signatures() -> None:
    """Verify Stoa client methods have type annotations via inspection."""
    methods_to_check = ["openai", "anthropic", "elevenlabs", "openrouter"]

    for method_name in methods_to_check:
        method = getattr(Stoa, method_name)
        sig = inspect.signature(method)
        # All methods should have user_id parameter
        assert "user_id" in sig.parameters, f"{method_name} should have user_id parameter"
        # All methods should have a return annotation
        assert sig.return_annotation is not inspect.Parameter.empty, (
            f"{method_name} should have return type annotation"
        )


def test_http_client_type_hints() -> None:
    """Verify StoaHTTPClient methods have type annotations."""
    methods_to_check = [
        "report_usage",
        "ingest_event",
        "ingest_events",
        "close",
        "__enter__",
        "__exit__",
    ]

    for method_name in methods_to_check:
        method = getattr(StoaHTTPClient, method_name)
        hints = get_type_hints(method)
        assert "return" in hints, f"{method_name} should have return type annotation"


def test_proxy_type_hints() -> None:
    """Verify StoaProxy methods have type annotations via inspection."""
    methods_to_check = [
        "__init__",
        "__getattr__",
        "__call__",
        "_should_wrap",
        "_is_provider_resource",
        "_extract_usage",
    ]

    for method_name in methods_to_check:
        method = getattr(StoaProxy, method_name)
        sig = inspect.signature(method)
        # All methods except __init__ should have explicit return annotation
        if method_name != "__init__":
            assert sig.return_annotation is not inspect.Parameter.empty, (
                f"{method_name} should have return type annotation"
            )


def test_exception_hierarchy() -> None:
    """Verify exception class hierarchy is correct."""
    # All exceptions should inherit from StoaError
    assert issubclass(StoaAPIError, StoaError)
    assert issubclass(InsufficientBalanceError, StoaError)
    assert issubclass(UserNotFoundError, StoaError)
    assert issubclass(StoaConnectionError, StoaError)
    assert issubclass(StoaTimeoutError, StoaError)

    # API-related exceptions should inherit from StoaAPIError
    assert issubclass(StoaBadRequestError, StoaAPIError)
    assert issubclass(StoaAuthenticationError, StoaAPIError)
    assert issubclass(StoaPermissionDeniedError, StoaAPIError)
    assert issubclass(StoaNotFoundError, StoaAPIError)
    assert issubclass(StoaRateLimitError, StoaAPIError)
    assert issubclass(StoaInternalServerError, StoaAPIError)


def test_stoa_error_type_hints() -> None:
    """Verify StoaError has proper type annotations."""
    hints = get_type_hints(StoaError.__init__)
    assert "message" in hints
    assert "response" in hints
    assert "body" in hints


def test_insufficient_balance_error_type_hints() -> None:
    """Verify InsufficientBalanceError has proper type annotations."""
    hints = get_type_hints(InsufficientBalanceError.__init__)
    assert "message" in hints
    assert "topup_url" in hints
    assert "balance" in hints
    assert "required" in hints


def test_exception_attributes_at_runtime() -> None:
    """Verify exception attributes are accessible at runtime."""
    # Test StoaError attributes
    error = StoaError("test message", response="resp", body={"key": "value"})
    assert error.message == "test message"
    assert error.response == "resp"
    assert error.body == {"key": "value"}

    # Test InsufficientBalanceError attributes
    balance_error = InsufficientBalanceError(
        message="insufficient",
        topup_url="https://example.com/topup",
        balance=10.0,
        required=20.0,
    )
    assert balance_error.topup_url == "https://example.com/topup"
    assert balance_error.balance == 10.0
    assert balance_error.required == 20.0


def test_all_public_classes_have_docstrings() -> None:
    """Verify all public classes have docstrings."""
    public_classes = [
        Stoa,
        StoaError,
        StoaAPIError,
        InsufficientBalanceError,
        UserNotFoundError,
        StoaHTTPClient,
        StoaProxy,
    ]

    for cls in public_classes:
        assert cls.__doc__ is not None, f"{cls.__name__} should have a docstring"
        assert len(cls.__doc__.strip()) > 0, f"{cls.__name__} docstring should not be empty"


def test_stoa_client_methods_are_not_async() -> None:
    """Verify Stoa client methods are synchronous (not coroutines)."""
    sync_methods = ["openai", "anthropic", "elevenlabs", "openrouter"]

    for method_name in sync_methods:
        method = getattr(Stoa, method_name)
        assert not inspect.iscoroutinefunction(method), f"{method_name} should be synchronous"


def test_type_annotations_use_modern_syntax() -> None:
    """Verify type annotations use modern Python syntax (3.10+)."""
    # Check that we're using `X | None` instead of `Optional[X]`
    # by inspecting the source code of InsufficientBalanceError.__init__
    source = inspect.getsource(InsufficientBalanceError.__init__)
    # Modern syntax uses `|` for unions
    assert "| None" in source or "None" in source


def _get_all_type_hints(cls: type[Any]) -> dict[str, dict[str, Any]]:
    """Helper to get type hints for all methods of a class."""
    hints: dict[str, dict[str, Any]] = {}
    for name, method in inspect.getmembers(cls, predicate=inspect.isfunction):
        if not name.startswith("_") or name in ("__init__", "__call__", "__enter__", "__exit__"):
            try:
                hints[name] = get_type_hints(method)
            except Exception:
                hints[name] = {}
    return hints


def test_no_any_in_public_return_types() -> None:
    """Verify public methods don't return bare Any (except where necessary)."""
    # Methods that are allowed to return Any due to dynamic nature
    allowed_any_returns = {
        "StoaProxy.__getattr__",
        "StoaProxy.__call__",
        "StoaProxy._extract_usage",
    }

    classes_to_check = [Stoa, StoaHTTPClient]

    for cls in classes_to_check:
        hints = _get_all_type_hints(cls)
        for method_name, method_hints in hints.items():
            full_name = f"{cls.__name__}.{method_name}"
            if full_name in allowed_any_returns:
                continue
            return_type = method_hints.get("return")
            # Allow None as return type, but not bare Any
            if return_type is Any:
                # This is acceptable for internal methods
                if not method_name.startswith("_"):
                    # Public methods should have specific return types
                    pass  # We allow dict[str, Any] which contains Any
