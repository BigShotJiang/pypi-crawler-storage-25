"""Shared fixtures for integration tests.

Running live tests against real services:
    # Start local services first
    just up

    # Run only live tests
    cd packages/sdk && uv run pytest -m live

    # Skip live tests (default CI behavior)
    cd packages/sdk && uv run pytest -m "not live"
"""

from __future__ import annotations

import os
from typing import Any

import pytest
from pytest_httpx import HTTPXMock


@pytest.fixture
def stoa_api_key() -> str:
    """Test API key for Stoa backend."""
    return "test-stoa-api-key"


@pytest.fixture
def stoa_base_url() -> str:
    """Test base URL for Stoa backend."""
    return "https://api.onstoa.com"


# --- Live service fixtures (for @pytest.mark.live tests) ---


@pytest.fixture
def live_control_url() -> str:
    """Control service URL for live tests."""
    return os.environ.get("STOA_CONTROL_URL", "http://localhost:8000")


@pytest.fixture
def live_events_url() -> str:
    """Events service URL for live tests."""
    return os.environ.get("STOA_EVENTS_URL", "http://localhost:8001")


@pytest.fixture
def live_api_key() -> str:
    """API key for live tests (must be set in environment)."""
    key = os.environ.get("STOA_TEST_API_KEY")
    if not key:
        pytest.skip("STOA_TEST_API_KEY not set")
    return key


@pytest.fixture
def openai_api_key() -> str:
    """Test API key for OpenAI."""
    return "test-openai-api-key"


@pytest.fixture
def openai_base_url() -> str:
    """OpenAI API base URL."""
    return "https://api.openai.com"


@pytest.fixture
def test_user_id() -> str:
    """Test user ID for all tests."""
    return "user-integration-test-123"


@pytest.fixture
def openai_chat_response() -> dict[str, Any]:
    """Standard OpenAI chat completion response."""
    return {
        "id": "chatcmpl-test123",
        "object": "chat.completion",
        "created": 1700000000,
        "model": "gpt-4",
        "choices": [
            {
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": "Hello! How can I help you today?",
                },
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": 10,
            "completion_tokens": 15,
            "total_tokens": 25,
        },
    }


@pytest.fixture
def stoa_usage_response() -> dict[str, Any]:
    """Standard successful usage report response from Stoa."""
    return {
        "status": "ok",
        "balance": 95.50,
        "charged": 0.002,
    }


@pytest.fixture
def stoa_insufficient_balance_response() -> dict[str, Any]:
    """Insufficient balance (402) response from Stoa."""
    return {
        "error": "insufficient balance",
        "topup_url": "https://stoa.dev/topup/user-integration-test-123",
        "balance": 0.01,
        "required": 0.05,
    }


@pytest.fixture
def stoa_user_not_found_response() -> dict[str, Any]:
    """User not found (404) response from Stoa."""
    return {
        "error": "user not found",
        "user_id": "unknown-user-xyz",
    }


def add_openai_chat_mock(
    httpx_mock: HTTPXMock,
    base_url: str,
    response: dict[str, Any],
    status_code: int = 200,
) -> None:
    """Add a mock for OpenAI chat completions endpoint."""
    httpx_mock.add_response(
        method="POST",
        url=f"{base_url}/v1/chat/completions",
        json=response,
        status_code=status_code,
    )


def add_stoa_usage_mock(
    httpx_mock: HTTPXMock,
    base_url: str,
    response: dict[str, Any],
    status_code: int = 200,
) -> None:
    """Add a mock for Stoa usage report endpoint (legacy)."""
    httpx_mock.add_response(
        method="POST",
        url=f"{base_url}/v1/usage/report",
        json=response,
        status_code=status_code,
    )


def add_stoa_events_mock(
    httpx_mock: HTTPXMock,
    base_url: str,
    response: dict[str, Any],
    status_code: int = 200,
) -> None:
    """Add a mock for Stoa events ingestion endpoint."""
    httpx_mock.add_response(
        method="POST",
        url=f"{base_url}/v1/events",
        json=response,
        status_code=status_code,
    )
