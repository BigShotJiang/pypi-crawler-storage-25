"""Integration tests for complete SDK flows.

Tests the full integration between Stoa client, AI provider proxies,
and the Stoa backend API using real SDKs with mocked HTTP responses.
"""

from __future__ import annotations

from typing import Any

import orjson
import pytest
from pytest_httpx import HTTPXMock

from stoa.client import Stoa
from stoa.exceptions import InsufficientBalanceError, UserNotFoundError
from tests.integration.conftest import (
    add_openai_chat_mock,
    add_stoa_events_mock,
)

# --- Happy Path: Full Flow Tests ---


def test_full_happy_path_openai_call(
    httpx_mock: HTTPXMock,
    monkeypatch: pytest.MonkeyPatch,
    stoa_api_key: str,
    stoa_base_url: str,
    openai_api_key: str,
    openai_base_url: str,
    test_user_id: str,
    openai_chat_response: dict[str, Any],
    stoa_usage_response: dict[str, Any],
) -> None:
    """Test full happy path: make OpenAI call, verify usage reported."""
    # Setup environment
    monkeypatch.setenv("STOA_API_KEY", stoa_api_key)
    monkeypatch.setenv("OPENAI_API_KEY", openai_api_key)

    # Mock Stoa backend response
    add_stoa_events_mock(httpx_mock, stoa_base_url, stoa_usage_response)

    # Mock OpenAI API response
    add_openai_chat_mock(httpx_mock, openai_base_url, openai_chat_response)

    # Create Stoa client
    stoa = Stoa()

    # Get proxied OpenAI client and make call
    openai_client = stoa.openai(test_user_id)
    response = openai_client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello!"}],
    )

    # Verify OpenAI response was returned
    assert response.choices[0].message.content == "Hello! How can I help you today?"

    # Verify Stoa API calls
    requests = httpx_mock.get_requests()
    assert len(requests) == 2  # openai + events

    # Verify events request (last request)
    events_request = requests[1]
    assert events_request.url.path == "/v1/events"
    events_body = orjson.loads(events_request.content)
    assert events_body["user_id"] == test_user_id
    assert events_body["event_type"] == "openai.chat_completion"
    assert events_body["payload"]["input_tokens"] == 10
    assert events_body["payload"]["output_tokens"] == 15


# --- Insufficient Balance Flow Tests ---


def test_insufficient_balance_raises_error(
    httpx_mock: HTTPXMock,
    monkeypatch: pytest.MonkeyPatch,
    stoa_api_key: str,
    stoa_base_url: str,
    openai_api_key: str,
    openai_base_url: str,
    test_user_id: str,
    openai_chat_response: dict[str, Any],
    stoa_insufficient_balance_response: dict[str, Any],
) -> None:
    """Test that InsufficientBalanceError is raised when Stoa returns 402."""
    monkeypatch.setenv("STOA_API_KEY", stoa_api_key)
    monkeypatch.setenv("OPENAI_API_KEY", openai_api_key)

    # Mock OpenAI to succeed
    add_openai_chat_mock(httpx_mock, openai_base_url, openai_chat_response)

    # Mock Stoa to return 402 insufficient balance
    add_stoa_events_mock(
        httpx_mock,
        stoa_base_url,
        stoa_insufficient_balance_response,
        status_code=402,
    )

    stoa = Stoa()
    openai_client = stoa.openai(test_user_id)

    with pytest.raises(InsufficientBalanceError) as exc_info:
        openai_client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello!"}],
        )

    # Verify error details
    exc = exc_info.value
    assert exc.topup_url == "https://stoa.dev/topup/user-integration-test-123"
    assert exc.balance == 0.01
    assert exc.required == 0.05

    # Verify OpenAI call was made (the AI call succeeds, billing fails)
    requests = httpx_mock.get_requests()
    assert any(r.url.path == "/v1/chat/completions" for r in requests)


# --- User Not Found Flow Tests ---


def test_user_not_found_raises_error(
    httpx_mock: HTTPXMock,
    monkeypatch: pytest.MonkeyPatch,
    stoa_api_key: str,
    stoa_base_url: str,
    openai_api_key: str,
    openai_base_url: str,
    openai_chat_response: dict[str, Any],
    stoa_user_not_found_response: dict[str, Any],
) -> None:
    """Test that UserNotFoundError is raised when Stoa returns 404."""
    monkeypatch.setenv("STOA_API_KEY", stoa_api_key)
    monkeypatch.setenv("OPENAI_API_KEY", openai_api_key)

    unknown_user_id = "unknown-user-xyz"

    # Mock OpenAI to succeed
    add_openai_chat_mock(httpx_mock, openai_base_url, openai_chat_response)

    # Mock Stoa to return 404
    add_stoa_events_mock(
        httpx_mock,
        stoa_base_url,
        stoa_user_not_found_response,
        status_code=404,
    )

    stoa = Stoa()
    openai_client = stoa.openai(unknown_user_id)

    with pytest.raises(UserNotFoundError) as exc_info:
        openai_client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello!"}],
        )

    # Verify error contains user ID
    assert unknown_user_id in str(exc_info.value)


# --- Retry Behavior Tests ---


def test_retry_on_500_first_fails_then_succeeds(
    httpx_mock: HTTPXMock,
    monkeypatch: pytest.MonkeyPatch,
    stoa_api_key: str,
    stoa_base_url: str,
    openai_api_key: str,
    openai_base_url: str,
    test_user_id: str,
    openai_chat_response: dict[str, Any],
    stoa_usage_response: dict[str, Any],
) -> None:
    """Test that SDK retries on 5xx errors and succeeds on retry."""
    monkeypatch.setenv("STOA_API_KEY", stoa_api_key)
    monkeypatch.setenv("OPENAI_API_KEY", openai_api_key)

    # Mock OpenAI to succeed
    add_openai_chat_mock(httpx_mock, openai_base_url, openai_chat_response)

    # First Stoa request returns 500, second succeeds
    httpx_mock.add_response(
        method="POST",
        url=f"{stoa_base_url}/v1/events",
        json={"error": "internal server error"},
        status_code=500,
    )
    httpx_mock.add_response(
        method="POST",
        url=f"{stoa_base_url}/v1/events",
        json=stoa_usage_response,
        status_code=200,
    )

    stoa = Stoa()
    openai_client = stoa.openai(test_user_id)
    response = openai_client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello!"}],
    )

    # Should succeed after retry
    assert response.choices[0].message.content == "Hello! How can I help you today?"

    # Verify requests: 1 OpenAI + 2 Stoa events (first failed, second succeeded)
    requests = httpx_mock.get_requests()
    stoa_requests = [r for r in requests if "stoa" in r.url.host]
    assert len(stoa_requests) == 2


def test_retry_exhausted_on_persistent_500(
    httpx_mock: HTTPXMock,
    monkeypatch: pytest.MonkeyPatch,
    stoa_api_key: str,
    stoa_base_url: str,
    openai_api_key: str,
    openai_base_url: str,
    test_user_id: str,
    openai_chat_response: dict[str, Any],
) -> None:
    """Test that SDK raises error after all retries exhausted."""
    from stoa.exceptions import StoaInternalServerError

    monkeypatch.setenv("STOA_API_KEY", stoa_api_key)
    monkeypatch.setenv("OPENAI_API_KEY", openai_api_key)

    # Mock OpenAI to succeed
    add_openai_chat_mock(httpx_mock, openai_base_url, openai_chat_response)

    # All 4 Stoa attempts return 500
    for _ in range(4):
        httpx_mock.add_response(
            method="POST",
            url=f"{stoa_base_url}/v1/events",
            json={"error": "internal server error"},
            status_code=500,
        )

    stoa = Stoa()
    openai_client = stoa.openai(test_user_id)

    with pytest.raises(StoaInternalServerError):
        openai_client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello!"}],
        )

    # Verify all 4 retry attempts were made to Stoa
    requests = httpx_mock.get_requests()
    stoa_requests = [r for r in requests if "stoa" in r.url.host]
    assert len(stoa_requests) == 4


def test_no_retry_on_400_client_error(
    httpx_mock: HTTPXMock,
    monkeypatch: pytest.MonkeyPatch,
    stoa_api_key: str,
    stoa_base_url: str,
    openai_api_key: str,
    openai_base_url: str,
    test_user_id: str,
    openai_chat_response: dict[str, Any],
) -> None:
    """Test that 4xx client errors are not retried."""
    from stoa.exceptions import StoaBadRequestError

    monkeypatch.setenv("STOA_API_KEY", stoa_api_key)
    monkeypatch.setenv("OPENAI_API_KEY", openai_api_key)

    # Mock OpenAI to succeed
    add_openai_chat_mock(httpx_mock, openai_base_url, openai_chat_response)

    # Single 400 response - should not retry
    httpx_mock.add_response(
        method="POST",
        url=f"{stoa_base_url}/v1/events",
        json={"error": "invalid request"},
        status_code=400,
    )

    stoa = Stoa()
    openai_client = stoa.openai(test_user_id)

    with pytest.raises(StoaBadRequestError):
        openai_client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello!"}],
        )

    # Only one Stoa request - no retry on 400
    requests = httpx_mock.get_requests()
    stoa_requests = [r for r in requests if "stoa" in r.url.host]
    assert len(stoa_requests) == 1


def test_retry_on_429_rate_limit(
    httpx_mock: HTTPXMock,
    monkeypatch: pytest.MonkeyPatch,
    stoa_api_key: str,
    stoa_base_url: str,
    openai_api_key: str,
    openai_base_url: str,
    test_user_id: str,
    openai_chat_response: dict[str, Any],
    stoa_usage_response: dict[str, Any],
) -> None:
    """Test retry on 429 Rate Limit error."""
    monkeypatch.setenv("STOA_API_KEY", stoa_api_key)
    monkeypatch.setenv("OPENAI_API_KEY", openai_api_key)

    # Mock OpenAI to succeed
    add_openai_chat_mock(httpx_mock, openai_base_url, openai_chat_response)

    # First two Stoa requests return 429, third succeeds
    httpx_mock.add_response(
        method="POST",
        url=f"{stoa_base_url}/v1/events",
        json={"error": "rate limited"},
        status_code=429,
    )
    httpx_mock.add_response(
        method="POST",
        url=f"{stoa_base_url}/v1/events",
        json={"error": "rate limited"},
        status_code=429,
    )
    httpx_mock.add_response(
        method="POST",
        url=f"{stoa_base_url}/v1/events",
        json=stoa_usage_response,
        status_code=200,
    )

    stoa = Stoa()
    openai_client = stoa.openai(test_user_id)
    response = openai_client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello!"}],
    )

    assert response is not None

    # Verify 3 Stoa requests: 2 rate limited + 1 success
    requests = httpx_mock.get_requests()
    stoa_requests = [r for r in requests if "stoa" in r.url.host]
    assert len(stoa_requests) == 3
