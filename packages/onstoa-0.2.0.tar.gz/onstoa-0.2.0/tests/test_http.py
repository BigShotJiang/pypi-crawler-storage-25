"""Tests for stoa.http module."""

from __future__ import annotations

import httpx
import pytest
from pytest_httpx import HTTPXMock

from stoa.exceptions import (
    InsufficientBalanceError,
    StoaAuthenticationError,
    StoaBadRequestError,
    StoaConnectionError,
    StoaInternalServerError,
    StoaNotFoundError,
    StoaPermissionDeniedError,
    StoaRateLimitError,
    UserNotFoundError,
)
from stoa.http import StoaHTTPClient, is_retryable, raise_for_status

# --- Tests for is_retryable ---


def test_is_retryable_with_internal_server_error():
    exc = StoaInternalServerError("server error")
    assert is_retryable(exc) is True


def test_is_retryable_with_rate_limit_error():
    exc = StoaRateLimitError("rate limited")
    assert is_retryable(exc) is True


def test_is_retryable_with_connection_error():
    exc = StoaConnectionError("connection failed")
    assert is_retryable(exc) is True


def test_is_retryable_with_bad_request_error():
    exc = StoaBadRequestError("bad request")
    assert is_retryable(exc) is False


def test_is_retryable_with_auth_error():
    exc = StoaAuthenticationError("unauthorized")
    assert is_retryable(exc) is False


def test_is_retryable_with_generic_exception():
    exc = ValueError("some error")
    assert is_retryable(exc) is False


# --- Tests for raise_for_status ---


def test_raise_for_status_success():
    response = httpx.Response(200, json={"ok": True})
    raise_for_status(response)  # Should not raise


def test_raise_for_status_400():
    response = httpx.Response(400, json={"error": "bad request"})
    with pytest.raises(StoaBadRequestError) as exc_info:
        raise_for_status(response, "Test context")
    assert "Test context" in str(exc_info.value)
    assert exc_info.value.body == {"error": "bad request"}


def test_raise_for_status_401():
    response = httpx.Response(401, json={"error": "unauthorized"})
    with pytest.raises(StoaAuthenticationError):
        raise_for_status(response)


def test_raise_for_status_403():
    response = httpx.Response(403, json={"error": "forbidden"})
    with pytest.raises(StoaPermissionDeniedError):
        raise_for_status(response)


def test_raise_for_status_404():
    response = httpx.Response(404, json={"error": "not found"})
    with pytest.raises(StoaNotFoundError):
        raise_for_status(response)


def test_raise_for_status_429():
    response = httpx.Response(429, json={"error": "rate limited"})
    with pytest.raises(StoaRateLimitError):
        raise_for_status(response)


def test_raise_for_status_500():
    response = httpx.Response(500, json={"error": "internal error"})
    with pytest.raises(StoaInternalServerError):
        raise_for_status(response)


def test_raise_for_status_502():
    response = httpx.Response(502, json={"error": "bad gateway"})
    with pytest.raises(StoaInternalServerError):
        raise_for_status(response)


def test_raise_for_status_non_json_body():
    response = httpx.Response(400, text="Bad Request")
    with pytest.raises(StoaBadRequestError) as exc_info:
        raise_for_status(response)
    assert exc_info.value.body == "Bad Request"


# --- Tests for StoaHTTPClient ---


def test_client_initialization():
    client = StoaHTTPClient(api_key="test-key", base_url="https://test.api.com")
    assert client.api_key == "test-key"
    assert client.base_url == "https://test.api.com"
    assert client._client.headers["Authorization"] == "Bearer test-key"
    client.close()


def test_client_context_manager_closes_client():
    with StoaHTTPClient(api_key="test-key") as client:
        assert client._client is not None
        internal_client = client._client
    assert internal_client.is_closed


def test_get_stoa_public_key_success(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="GET",
        url="https://api.onstoa.com/v1/install/public-key",
        json={
            "data": {
                "public_key": "PUBLIC KEY",
                "algorithm": "EdDSA",
            }
        },
    )

    with StoaHTTPClient(api_key="test-key") as client:
        result = client.get_stoa_public_key()

    assert result == {"public_key": "PUBLIC KEY", "algorithm": "EdDSA"}


def test_get_stoa_public_key_uses_cache(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="GET",
        url="https://api.onstoa.com/v1/install/public-key",
        json={
            "data": {
                "public_key": "PUBLIC KEY",
                "algorithm": "EdDSA",
            }
        },
    )

    with StoaHTTPClient(api_key="test-key") as client:
        first = client.get_stoa_public_key()
        second = client.get_stoa_public_key()

    assert first == second
    assert len(httpx_mock.get_requests()) == 1


def test_exchange_install_token_success(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/install:exchange",
        json={
            "data": {
                "membership_id": "mem_123",
                "email": "ada@example.com",
                "name": "Ada",
                "avatar_url": None,
                "external_id": "user_123",
            }
        },
    )

    with StoaHTTPClient(api_key="test-key") as client:
        result = client.exchange_install_token("bootstrap-token", "user_123")

    assert result.membership_id == "mem_123"
    assert result.email == "ada@example.com"
    assert result.name == "Ada"
    assert result.avatar_url is None
    assert result.user_id == "user_123"

    request = httpx_mock.get_request()
    assert request is not None
    assert request.url == "https://api.onstoa.com/v1/install:exchange"


def test_register_member_success(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/embedded/memberships:upsert",
        json={
            "data": {
                "membership_id": "mem_123",
                "external_id": "user_123",
            }
        },
    )

    with StoaHTTPClient(api_key="test-key") as client:
        result = client.register_member(
            app_id="app_123",
            user_id="user_123",
            email="ada@example.com",
            name="Ada",
            avatar_url="https://example.com/avatar.png",
            nonce="nonce_1234567890abcd",
            signature="deadbeef" * 8,
            timestamp=1717082400,
        )

    assert result.membership_id == "mem_123"
    assert result.user_id == "user_123"

    request = httpx_mock.get_request()
    assert request is not None
    assert request.url == "https://api.onstoa.com/v1/embedded/memberships:upsert"


# --- Tests for report_usage ---


def test_report_usage_success(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/usage/report",
        json={"status": "ok", "balance": 95.0},
    )

    with StoaHTTPClient(api_key="test-key") as client:
        result = client.report_usage(
            user_id="user123",
            function_name="generate_text",
            usage={"input_tokens": 100, "output_tokens": 50},
            duration=1.5,
        )

    assert result == {"status": "ok", "balance": 95.0}

    request = httpx_mock.get_request()
    import orjson

    body = orjson.loads(request.content)
    assert body == {
        "user_id": "user123",
        "function": "generate_text",
        "usage": {"input_tokens": 100, "output_tokens": 50},
        "duration_ms": 1500,
    }


def test_report_usage_insufficient_balance(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/usage/report",
        status_code=402,
        json={
            "error": "insufficient balance",
            "topup_url": "https://stoa.dev/topup/user123",
            "balance": 0.50,
            "required": 2.00,
        },
    )

    with StoaHTTPClient(api_key="test-key") as client:
        with pytest.raises(InsufficientBalanceError) as exc_info:
            client.report_usage(
                user_id="user123",
                function_name="expensive_op",
                usage={"tokens": 1000},
                duration=1.0,
            )

    exc = exc_info.value
    assert exc.topup_url == "https://stoa.dev/topup/user123"
    assert exc.balance == 0.50
    assert exc.required == 2.00


def test_report_usage_user_not_found(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/usage/report",
        status_code=404,
        json={"error": "user not found"},
    )

    with StoaHTTPClient(api_key="test-key") as client:
        with pytest.raises(UserNotFoundError) as exc_info:
            client.report_usage(
                user_id="unknown_user",
                function_name="some_func",
                usage={},
                duration=0.1,
            )

    assert "unknown_user" in str(exc_info.value)


# --- Tests for error handling ---


def test_authentication_error(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/usage/report",
        status_code=401,
        json={"error": "invalid api key"},
    )

    with StoaHTTPClient(api_key="bad-key") as client:
        with pytest.raises(StoaAuthenticationError):
            client.report_usage(
                user_id="user",
                function_name="func",
                usage={},
                duration=0.1,
            )


def test_permission_denied_error(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/usage/report",
        status_code=403,
        json={"error": "access denied"},
    )

    with StoaHTTPClient(api_key="test-key") as client:
        with pytest.raises(StoaPermissionDeniedError):
            client.report_usage(
                user_id="user",
                function_name="func",
                usage={},
                duration=0.1,
            )


def test_internal_server_error(httpx_mock: HTTPXMock):
    # 500 errors are retryable, so we need to mock all 4 attempts
    for _ in range(4):
        httpx_mock.add_response(
            method="POST",
            url="https://api.onstoa.com/v1/usage/report",
            status_code=500,
            json={"error": "internal server error"},
        )

    with StoaHTTPClient(api_key="test-key") as client:
        with pytest.raises(StoaInternalServerError):
            client.report_usage(
                user_id="user",
                function_name="func",
                usage={},
                duration=0.1,
            )


# --- Tests for retry behavior ---


def test_retry_on_429_rate_limit(httpx_mock: HTTPXMock):
    # First two calls return 429, third succeeds
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/usage/report",
        status_code=429,
        json={"error": "rate limited"},
    )
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/usage/report",
        status_code=429,
        json={"error": "rate limited"},
    )
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/usage/report",
        json={"status": "ok"},
    )

    with StoaHTTPClient(api_key="test-key") as client:
        result = client.report_usage(
            user_id="user123",
            function_name="func",
            usage={},
            duration=0.1,
        )

    assert result == {"status": "ok"}
    assert len(httpx_mock.get_requests()) == 3


def test_retry_exhausted_on_429(httpx_mock: HTTPXMock):
    # All 4 attempts return 429
    for _ in range(4):
        httpx_mock.add_response(
            method="POST",
            url="https://api.onstoa.com/v1/usage/report",
            status_code=429,
            json={"error": "rate limited"},
        )

    with StoaHTTPClient(api_key="test-key") as client:
        with pytest.raises(StoaRateLimitError):
            client.report_usage(
                user_id="user123",
                function_name="func",
                usage={},
                duration=0.1,
            )

    assert len(httpx_mock.get_requests()) == 4


def test_retry_on_500_server_error(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/usage/report",
        status_code=500,
        json={"error": "server error"},
    )
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/usage/report",
        json={"status": "ok"},
    )

    with StoaHTTPClient(api_key="test-key") as client:
        result = client.report_usage(
            user_id="user",
            function_name="func",
            usage={},
            duration=0.1,
        )

    assert result == {"status": "ok"}
    assert len(httpx_mock.get_requests()) == 2


def test_no_retry_on_400_bad_request(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/usage/report",
        status_code=400,
        json={"error": "bad request"},
    )

    with StoaHTTPClient(api_key="test-key") as client:
        with pytest.raises(StoaBadRequestError):
            client.report_usage(
                user_id="user123",
                function_name="func",
                usage={},
                duration=0.1,
            )

    # Should only make 1 request (no retry)
    assert len(httpx_mock.get_requests()) == 1


# --- Tests for connection errors ---


def test_connection_error_wrapped(httpx_mock: HTTPXMock):
    httpx_mock.add_exception(
        httpx.ConnectError("Connection refused"),
        url="https://api.onstoa.com/v1/usage/report",
    )

    with StoaHTTPClient(api_key="test-key") as client:
        with pytest.raises(httpx.ConnectError):
            client.report_usage(
                user_id="user123",
                function_name="func",
                usage={},
                duration=0.1,
            )


# --- Tests for timeout errors ---


def test_timeout_error(httpx_mock: HTTPXMock):
    httpx_mock.add_exception(
        httpx.TimeoutException("Request timed out"),
        url="https://api.onstoa.com/v1/usage/report",
    )

    with StoaHTTPClient(api_key="test-key") as client:
        with pytest.raises(httpx.TimeoutException):
            client.report_usage(
                user_id="user",
                function_name="func",
                usage={},
                duration=0.1,
            )


# --- Tests for ingest_event ---


def test_ingest_event_success(httpx_mock: HTTPXMock):
    from stoa.events import EventType, OpenAIChatCompletionPayload, UsageEvent

    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/events",
        json={"status": "ok", "event_id": "123"},
    )

    event = UsageEvent(
        user_id="user123",
        event_type=EventType.OPENAI_CHAT_COMPLETION,
        payload=OpenAIChatCompletionPayload(
            model="gpt-4",
            input_tokens=100,
            output_tokens=50,
        ),
    )

    with StoaHTTPClient(api_key="test-key") as client:
        result = client.ingest_event(event)

    assert result == {"status": "ok", "event_id": "123"}

    request = httpx_mock.get_request()
    assert request.headers["Content-Type"] == "application/json"
    import orjson

    body = orjson.loads(request.content)
    assert body["user_id"] == "user123"
    assert body["event_type"] == "openai.chat_completion"


def test_ingest_event_insufficient_balance(httpx_mock: HTTPXMock):
    from stoa.events import EventType, OpenAIChatCompletionPayload, UsageEvent

    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/events",
        status_code=402,
        json={
            "error": "insufficient balance",
            "topup_url": "https://stoa.dev/topup/user123",
            "balance": 0.50,
            "required": 2.00,
        },
    )

    event = UsageEvent(
        user_id="user123",
        event_type=EventType.OPENAI_CHAT_COMPLETION,
        payload=OpenAIChatCompletionPayload(
            model="gpt-4",
            input_tokens=100,
            output_tokens=50,
        ),
    )

    with StoaHTTPClient(api_key="test-key") as client:
        with pytest.raises(InsufficientBalanceError) as exc_info:
            client.ingest_event(event)

    exc = exc_info.value
    assert exc.topup_url == "https://stoa.dev/topup/user123"


def test_ingest_event_user_not_found(httpx_mock: HTTPXMock):
    from stoa.events import EventType, OpenAIChatCompletionPayload, UsageEvent

    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/events",
        status_code=404,
        json={"error": "user not found"},
    )

    event = UsageEvent(
        user_id="unknown_user",
        event_type=EventType.OPENAI_CHAT_COMPLETION,
        payload=OpenAIChatCompletionPayload(
            model="gpt-4",
            input_tokens=100,
            output_tokens=50,
        ),
    )

    with StoaHTTPClient(api_key="test-key") as client:
        with pytest.raises(UserNotFoundError) as exc_info:
            client.ingest_event(event)

    assert "unknown_user" in str(exc_info.value)


# --- Tests for ingest_events (batch) ---


def test_ingest_events_batch_success(httpx_mock: HTTPXMock):
    from stoa.events import (
        AnthropicMessagesPayload,
        EventType,
        OpenAIChatCompletionPayload,
        UsageEvent,
    )

    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/events:batchCreate",
        json={"status": "ok", "processed": 2},
    )

    events = [
        UsageEvent(
            user_id="user1",
            event_type=EventType.OPENAI_CHAT_COMPLETION,
            payload=OpenAIChatCompletionPayload(
                model="gpt-4",
                input_tokens=100,
                output_tokens=50,
            ),
        ),
        UsageEvent(
            user_id="user2",
            event_type=EventType.ANTHROPIC_MESSAGES,
            payload=AnthropicMessagesPayload(
                model="claude-3",
                input_tokens=200,
                output_tokens=100,
            ),
        ),
    ]

    with StoaHTTPClient(api_key="test-key") as client:
        result = client.ingest_events(events)

    assert result == {"status": "ok", "processed": 2}

    request = httpx_mock.get_request()
    import orjson

    body = orjson.loads(request.content)
    assert len(body["events"]) == 2


def test_ingest_events_bad_request(httpx_mock: HTTPXMock):
    from stoa.events import EventType, OpenAIChatCompletionPayload, UsageEvent

    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/events:batchCreate",
        status_code=400,
        json={"error": "invalid batch"},
    )

    events = [
        UsageEvent(
            user_id="user1",
            event_type=EventType.OPENAI_CHAT_COMPLETION,
            payload=OpenAIChatCompletionPayload(
                model="gpt-4",
                input_tokens=100,
                output_tokens=50,
            ),
        ),
    ]

    with StoaHTTPClient(api_key="test-key") as client:
        with pytest.raises(StoaBadRequestError):
            client.ingest_events(events)


def test_get_hosted_topup_link_success(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url="https://api.onstoa.com/v1/hosted-topup-link",
        json={
            "data": {
                "membership_id": "mem_123",
                "external_id": "user_123",
                "topup_url": "https://onstoa.com/payments/user_123",
            }
        },
    )

    with StoaHTTPClient(api_key="test-key") as client:
        topup_url = client.get_hosted_topup_link(user_id="user_123")

    assert topup_url == "https://onstoa.com/payments/user_123"
