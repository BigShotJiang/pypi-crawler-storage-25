"""Tests for connect and embedded onboarding helpers."""

from __future__ import annotations

from uuid import uuid4

import pytest

from stoa.connect import create_connect_request, verify_connect_token
from stoa.embedded import create_embedded_membership_request

TEST_PRIVATE_KEY = """-----BEGIN PRIVATE KEY-----
MC4CAQAwBQYDK2VwBCIEIEaGHzopvo2IvVmOD6OYSlSUH+h7G8t0bPmEfc5yTWWE
-----END PRIVATE KEY-----"""
TEST_PUBLIC_KEY = """-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEA/dKYEKNA0D4fQAn9uNr11jlgTAIoeghPm3QT5xtOG2c=
-----END PUBLIC KEY-----"""


def _make_token(app_id: str, membership_id: str, user_id: str, state: str) -> str:
    import jwt

    return jwt.encode(
        {
            "iss": "stoa",
            "aud": app_id,
            "sub": membership_id,
            "external_id": user_id,
            "state": state,
            "kind": "connect_success",
            "jti": "connect-jti-1",
            "iat": 1_717_082_400,
            "exp": 4_102_444_800,
        },
        TEST_PRIVATE_KEY,
        algorithm="EdDSA",
    )


def test_verify_connect_token_success() -> None:
    app_id = str(uuid4())
    membership_id = str(uuid4())
    token = _make_token(app_id, membership_id, "user_123", "state_123")

    claims = verify_connect_token(token, TEST_PUBLIC_KEY, app_id)

    assert claims["membership_id"] == membership_id
    assert claims["app_id"] == app_id
    assert claims["user_id"] == "user_123"
    assert claims["state"] == "state_123"


def test_verify_connect_token_rejects_wrong_audience() -> None:
    app_id = str(uuid4())
    token = _make_token(app_id, str(uuid4()), "user_123", "state_123")

    with pytest.raises(ValueError, match="audience"):
        verify_connect_token(token, TEST_PUBLIC_KEY, str(uuid4()))


def test_create_connect_request_signs_all_fields() -> None:
    params = create_connect_request(
        connect_secret="test-secret",
        app_id="app_123",
        external_user_id="user_123",
        redirect_uri="https://example.com/callback",
        state="state_123",
        nonce="nonce_1234567890abcd",
        timestamp=1_717_082_400,
    )

    assert params["app_id"] == "app_123"
    assert params["external_user_id"] == "user_123"
    assert params["redirect_uri"] == "https://example.com/callback"
    assert params["signature"] == (
        "7d041ab4a4fb864775998e77430b98b572d0bff3e370f81ab5227af69f6ef787"
    )


def test_create_embedded_membership_request_signs_all_fields() -> None:
    params = create_embedded_membership_request(
        connect_secret="test-secret",
        app_id="app_123",
        user_id="user_123",
        email="ada@example.com",
        name="Ada",
        avatar_url="https://example.com/avatar.png",
        nonce="nonce_1234567890abcd",
        timestamp=1_717_082_400,
    )

    assert params["app_id"] == "app_123"
    assert params["external_user_id"] == "user_123"
    assert params["email"] == "ada@example.com"
    assert params["name"] == "Ada"
    assert params["avatar_url"] == "https://example.com/avatar.png"
    assert params["signature"] == (
        "a9872f54437af04b97cc7342b23c2d44ca088380b09ba0ce45c202375a50079c"
    )
