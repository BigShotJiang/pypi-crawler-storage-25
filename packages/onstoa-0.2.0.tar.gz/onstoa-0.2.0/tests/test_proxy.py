from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from stoa.events import (
    AnthropicMessagesPayload,
    ElevenLabsTTSPayload,
    EventType,
    OpenAIChatCompletionPayload,
    UsageEvent,
)
from stoa.proxy import StoaProxy


@pytest.fixture
def mock_stoa_client():
    """Create a mock StoaHTTPClient."""
    client = MagicMock()
    client.ingest_event = MagicMock(return_value={"status": "ok"})
    return client


@pytest.fixture
def proxy(mock_stoa_client):
    """Create a StoaProxy wrapping a mock object."""
    obj = MagicMock()
    return StoaProxy(
        obj=obj,
        function_name="client",
        user_id="user-123",
        stoa_client=mock_stoa_client,
    )


def test_proxy_wraps_methods(mock_stoa_client):
    """Proxy should wrap methods for tracking."""

    class Client:
        def create(self):
            return "response"

    client = Client()
    proxy = StoaProxy(
        obj=client,
        function_name="client",
        user_id="user-123",
        stoa_client=mock_stoa_client,
    )

    # Access method - should be wrapped since it's a method
    create_proxy = proxy.create
    assert isinstance(create_proxy, StoaProxy)


def test_proxy_wraps_functions(mock_stoa_client):
    """Proxy should wrap functions for tracking."""

    def my_func():
        return "result"

    class Container:
        func = my_func

    proxy = StoaProxy(
        obj=Container(),
        function_name="container",
        user_id="user-123",
        stoa_client=mock_stoa_client,
    )

    # Access function - should be wrapped
    func_proxy = proxy.func
    assert isinstance(func_proxy, StoaProxy)


def test_proxy_calls_original_method_and_returns_response(mock_stoa_client):
    """Proxy should call underlying method and return its response."""
    mock_method = MagicMock(return_value="test-response")
    obj = MagicMock()
    obj.some_method = mock_method

    proxy = StoaProxy(
        obj=obj.some_method,
        function_name="client.some_method",
        user_id="user-123",
        stoa_client=mock_stoa_client,
    )

    result = proxy("arg1", kwarg1="value1")

    mock_method.assert_called_once_with("arg1", kwarg1="value1")
    assert result == "test-response"


def test_non_callable_attributes_pass_through(mock_stoa_client):
    """Non-callable, non-resource attributes should pass through unwrapped."""
    obj = MagicMock()
    obj.simple_value = "hello"
    obj.number = 42

    proxy = StoaProxy(
        obj=obj,
        function_name="client",
        user_id="user-123",
        stoa_client=mock_stoa_client,
    )

    assert proxy.simple_value == "hello"
    assert proxy.number == 42


def test_slots_prevents_accidental_assignment(proxy):
    """__slots__ should prevent accidental attribute assignment."""
    with pytest.raises(AttributeError):
        proxy.new_attribute = "should fail"


def test_extract_usage_openai_format(mock_stoa_client):
    """Should extract prompt_tokens/completion_tokens as input/output tokens."""
    response = MagicMock()
    response.model = "gpt-4"
    response.id = "chatcmpl-123"
    response.usage = MagicMock()
    response.usage.prompt_tokens = 100
    response.usage.completion_tokens = 50
    response.usage.prompt_tokens_details = None
    response.usage.completion_tokens_details = None

    mock_method = MagicMock(return_value=response)

    proxy = StoaProxy(
        obj=mock_method,
        function_name="openai.chat.completions.create",
        user_id="user-123",
        stoa_client=mock_stoa_client,
    )

    proxy(model="gpt-4")

    mock_stoa_client.ingest_event.assert_called_once()
    event = mock_stoa_client.ingest_event.call_args[0][0]
    assert isinstance(event, UsageEvent)
    assert event.event_type == EventType.OPENAI_CHAT_COMPLETION
    assert isinstance(event.payload, OpenAIChatCompletionPayload)
    assert event.payload.input_tokens == 100
    assert event.payload.output_tokens == 50


def test_extract_usage_anthropic_format(mock_stoa_client):
    """Should extract input_tokens/output_tokens directly."""
    response = MagicMock()
    response.model = "claude-3-opus"
    response.id = "msg_123"
    response.usage = MagicMock()
    response.usage.input_tokens = 200
    response.usage.output_tokens = 75
    response.usage.cache_creation_input_tokens = None
    response.usage.cache_read_input_tokens = None

    mock_method = MagicMock(return_value=response)

    proxy = StoaProxy(
        obj=mock_method,
        function_name="anthropic.messages.create",
        user_id="user-123",
        stoa_client=mock_stoa_client,
    )

    proxy(model="claude-3-opus")

    mock_stoa_client.ingest_event.assert_called_once()
    event = mock_stoa_client.ingest_event.call_args[0][0]
    assert isinstance(event, UsageEvent)
    assert event.event_type == EventType.ANTHROPIC_MESSAGES
    assert isinstance(event.payload, AnthropicMessagesPayload)
    assert event.payload.input_tokens == 200
    assert event.payload.output_tokens == 75


def test_extract_usage_elevenlabs_characters(mock_stoa_client):
    """Should extract character count from text kwarg for ElevenLabs."""
    response = MagicMock(spec=[])  # No usage attribute

    mock_method = MagicMock(return_value=response)

    proxy = StoaProxy(
        obj=mock_method,
        function_name="elevenlabs.text_to_speech.convert",
        user_id="user-123",
        stoa_client=mock_stoa_client,
    )

    test_text = "Hello, this is a test message!"
    proxy(voice_id="abc", text=test_text)

    mock_stoa_client.ingest_event.assert_called_once()
    event = mock_stoa_client.ingest_event.call_args[0][0]
    assert isinstance(event, UsageEvent)
    assert event.event_type == EventType.ELEVENLABS_TTS
    assert isinstance(event.payload, ElevenLabsTTSPayload)
    assert event.payload.characters == len(test_text)


def test_extract_usage_missing_skips_ingest(mock_stoa_client):
    """Should not call ingest_event when response has no usage info."""
    response = MagicMock(spec=[])  # No usage attribute

    mock_method = MagicMock(return_value=response)

    proxy = StoaProxy(
        obj=mock_method,
        function_name="client.some.method",
        user_id="user-123",
        stoa_client=mock_stoa_client,
    )

    proxy()

    # Should not call ingest_event for unknown event types without usage
    mock_stoa_client.ingest_event.assert_not_called()


def test_proxy_reports_usage_with_correct_metadata(mock_stoa_client):
    """Proxy should report usage with correct user_id."""
    response = MagicMock()
    response.model = "gpt-4"
    response.id = "chatcmpl-456"
    response.usage = MagicMock()
    response.usage.prompt_tokens = 50
    response.usage.completion_tokens = 25
    response.usage.prompt_tokens_details = None
    response.usage.completion_tokens_details = None

    mock_method = MagicMock(return_value=response)

    proxy = StoaProxy(
        obj=mock_method,
        function_name="openai.chat.completions.create",
        user_id="test-user-456",
        stoa_client=mock_stoa_client,
    )

    proxy(model="gpt-4")

    mock_stoa_client.ingest_event.assert_called_once()
    event = mock_stoa_client.ingest_event.call_args[0][0]
    assert event.user_id == "test-user-456"
    assert event.payload.latency_ms is not None


def test_proxy_builds_nested_function_name(mock_stoa_client):
    """Proxy should build dot-separated function names for nested access."""

    class Client:
        def create(self):
            pass

    client = Client()
    proxy = StoaProxy(
        obj=client,
        function_name="client",
        user_id="user-123",
        stoa_client=mock_stoa_client,
    )

    create_proxy = proxy.create
    # Access internal function name via object.__getattribute__
    func_name = object.__getattribute__(create_proxy, "_function_name")
    assert func_name == "client.create"
