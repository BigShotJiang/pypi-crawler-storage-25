"""Tests for provider adapters."""

from __future__ import annotations

from unittest.mock import MagicMock

from stoa.events import (
    AnthropicMessagesPayload,
    DeepgramTranscriptionPayload,
    DeepgramTTSPayload,
    ElevenLabsSTSPayload,
    ElevenLabsTTSPayload,
    ElevenLabsVoiceClonePayload,
    EventType,
    OpenAIAudioSpeechPayload,
    OpenAIAudioTranscriptionPayload,
    OpenAIChatCompletionPayload,
    OpenAICompletionPayload,
    OpenAIEmbeddingPayload,
    OpenAIImageGenerationPayload,
    OpenRouterChatCompletionPayload,
)
from stoa.providers import (
    AnthropicAdapter,
    DeepgramAdapter,
    ElevenLabsAdapter,
    OpenAIAdapter,
    OpenRouterAdapter,
    get_adapter_for_function,
)

# =============================================================================
# OpenAI Adapter Tests
# =============================================================================


def test_openai_adapter_provider_prefix():
    adapter = OpenAIAdapter()
    assert adapter.provider_prefix == "openai"


def test_openai_adapter_handles_function():
    adapter = OpenAIAdapter()
    assert adapter.handles_function("openai.chat.completions.create")
    assert adapter.handles_function("openai.embeddings.create")
    assert not adapter.handles_function("anthropic.messages.create")


def test_openai_adapter_get_event_type():
    adapter = OpenAIAdapter()
    assert (
        adapter.get_event_type("openai.chat.completions.create") == EventType.OPENAI_CHAT_COMPLETION
    )
    assert adapter.get_event_type("openai.completions.create") == EventType.OPENAI_COMPLETION
    assert adapter.get_event_type("openai.embeddings.create") == EventType.OPENAI_EMBEDDING
    assert adapter.get_event_type("openai.images.generate") == EventType.OPENAI_IMAGE_GENERATION
    assert (
        adapter.get_event_type("openai.audio.transcriptions.create")
        == EventType.OPENAI_AUDIO_TRANSCRIPTION
    )
    assert adapter.get_event_type("openai.audio.speech.create") == EventType.OPENAI_AUDIO_SPEECH
    assert adapter.get_event_type("openai.unknown") == EventType.CUSTOM


def test_openai_adapter_extract_chat_completion():
    adapter = OpenAIAdapter()
    response = MagicMock()
    response.model = "gpt-4"
    response.id = "chatcmpl-123"
    response.usage = MagicMock()
    response.usage.prompt_tokens = 100
    response.usage.completion_tokens = 50
    response.usage.prompt_tokens_details = None
    response.usage.completion_tokens_details = None

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={"model": "gpt-4", "stream": False},
        function_name="openai.chat.completions.create",
        latency_ms=150,
    )

    assert isinstance(payload, OpenAIChatCompletionPayload)
    assert payload.model == "gpt-4"
    assert payload.input_tokens == 100
    assert payload.output_tokens == 50
    assert payload.cached_tokens == 0
    assert payload.reasoning_tokens == 0
    assert payload.request_id == "chatcmpl-123"
    assert payload.streaming is False
    assert payload.latency_ms == 150


def test_openai_adapter_extract_chat_completion_with_cached_tokens():
    adapter = OpenAIAdapter()
    response = MagicMock()
    response.model = "gpt-4"
    response.id = "chatcmpl-123"
    response.usage = MagicMock()
    response.usage.prompt_tokens = 100
    response.usage.completion_tokens = 50
    response.usage.prompt_tokens_details = MagicMock()
    response.usage.prompt_tokens_details.cached_tokens = 30
    response.usage.completion_tokens_details = MagicMock()
    response.usage.completion_tokens_details.reasoning_tokens = 10

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={"model": "gpt-4"},
        function_name="openai.chat.completions.create",
        latency_ms=100,
    )

    assert isinstance(payload, OpenAIChatCompletionPayload)
    assert payload.cached_tokens == 30
    assert payload.reasoning_tokens == 10


def test_openai_adapter_extract_chat_completion_no_usage():
    adapter = OpenAIAdapter()
    response = MagicMock(spec=[])  # No usage attribute

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={},
        function_name="openai.chat.completions.create",
        latency_ms=100,
    )

    assert payload is None


def test_openai_adapter_extract_completion():
    adapter = OpenAIAdapter()
    response = MagicMock()
    response.model = "davinci-002"
    response.id = "cmpl-123"
    response.usage = MagicMock()
    response.usage.prompt_tokens = 20
    response.usage.completion_tokens = 30

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={},
        function_name="openai.completions.create",
        latency_ms=100,
    )

    assert isinstance(payload, OpenAICompletionPayload)
    assert payload.model == "davinci-002"
    assert payload.input_tokens == 20
    assert payload.output_tokens == 30


def test_openai_adapter_extract_embedding():
    adapter = OpenAIAdapter()
    response = MagicMock()
    response.model = "text-embedding-3-large"
    response.usage = MagicMock()
    response.usage.total_tokens = 100

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={"dimensions": 256},
        function_name="openai.embeddings.create",
        latency_ms=50,
    )

    assert isinstance(payload, OpenAIEmbeddingPayload)
    assert payload.model == "text-embedding-3-large"
    assert payload.input_tokens == 100
    assert payload.dimensions == 256


def test_openai_adapter_extract_image_generation():
    adapter = OpenAIAdapter()
    response = MagicMock()

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={"model": "dall-e-3", "size": "1024x1792", "quality": "hd", "n": 2},
        function_name="openai.images.generate",
        latency_ms=5000,
    )

    assert isinstance(payload, OpenAIImageGenerationPayload)
    assert payload.model == "dall-e-3"
    assert payload.size == "1024x1792"
    assert payload.quality == "hd"
    assert payload.n == 2


def test_openai_adapter_extract_audio_transcription():
    adapter = OpenAIAdapter()
    response = MagicMock()
    response.duration = 65.5

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={"model": "whisper-1"},
        function_name="openai.audio.transcriptions.create",
        latency_ms=2000,
    )

    assert isinstance(payload, OpenAIAudioTranscriptionPayload)
    assert payload.model == "whisper-1"
    assert payload.duration_seconds == 65.5


def test_openai_adapter_extract_audio_speech():
    adapter = OpenAIAdapter()
    response = MagicMock()

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={"model": "tts-1-hd", "voice": "nova", "input": "Hello world!"},
        function_name="openai.audio.speech.create",
        latency_ms=500,
    )

    assert isinstance(payload, OpenAIAudioSpeechPayload)
    assert payload.model == "tts-1-hd"
    assert payload.voice == "nova"
    assert payload.characters == 12


# =============================================================================
# Anthropic Adapter Tests
# =============================================================================


def test_anthropic_adapter_provider_prefix():
    adapter = AnthropicAdapter()
    assert adapter.provider_prefix == "anthropic"


def test_anthropic_adapter_handles_function():
    adapter = AnthropicAdapter()
    assert adapter.handles_function("anthropic.messages.create")
    assert not adapter.handles_function("openai.chat.completions.create")


def test_anthropic_adapter_get_event_type():
    adapter = AnthropicAdapter()
    assert adapter.get_event_type("anthropic.messages.create") == EventType.ANTHROPIC_MESSAGES
    assert adapter.get_event_type("anthropic.unknown") == EventType.CUSTOM


def test_anthropic_adapter_extract_messages():
    adapter = AnthropicAdapter()
    response = MagicMock()
    response.model = "claude-3-opus"
    response.id = "msg_123"
    response.usage = MagicMock()
    response.usage.input_tokens = 200
    response.usage.output_tokens = 75
    response.usage.cache_creation_input_tokens = 50
    response.usage.cache_read_input_tokens = 100

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={"stream": True},
        function_name="anthropic.messages.create",
        latency_ms=300,
    )

    assert isinstance(payload, AnthropicMessagesPayload)
    assert payload.model == "claude-3-opus"
    assert payload.input_tokens == 200
    assert payload.output_tokens == 75
    assert payload.cache_creation_input_tokens == 50
    assert payload.cache_read_input_tokens == 100
    assert payload.request_id == "msg_123"
    assert payload.streaming is True
    assert payload.latency_ms == 300


def test_anthropic_adapter_extract_messages_no_cache():
    adapter = AnthropicAdapter()
    response = MagicMock()
    response.model = "claude-3-sonnet"
    response.id = "msg_456"
    response.usage = MagicMock()
    response.usage.input_tokens = 100
    response.usage.output_tokens = 50
    response.usage.cache_creation_input_tokens = None
    response.usage.cache_read_input_tokens = None

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={},
        function_name="anthropic.messages.create",
        latency_ms=150,
    )

    assert isinstance(payload, AnthropicMessagesPayload)
    assert payload.cache_creation_input_tokens == 0
    assert payload.cache_read_input_tokens == 0


def test_anthropic_adapter_extract_messages_no_usage():
    adapter = AnthropicAdapter()
    response = MagicMock(spec=[])

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={},
        function_name="anthropic.messages.create",
        latency_ms=100,
    )

    assert payload is None


# =============================================================================
# ElevenLabs Adapter Tests
# =============================================================================


def test_elevenlabs_adapter_provider_prefix():
    adapter = ElevenLabsAdapter()
    assert adapter.provider_prefix == "elevenlabs"


def test_elevenlabs_adapter_handles_function():
    adapter = ElevenLabsAdapter()
    assert adapter.handles_function("elevenlabs.text_to_speech.convert")
    assert adapter.handles_function("elevenlabs.voice_clone.clone")
    assert not adapter.handles_function("openai.chat.completions.create")


def test_elevenlabs_adapter_get_event_type():
    adapter = ElevenLabsAdapter()
    assert adapter.get_event_type("elevenlabs.text_to_speech.convert") == EventType.ELEVENLABS_TTS
    assert (
        adapter.get_event_type("elevenlabs.voice_clone.clone") == EventType.ELEVENLABS_VOICE_CLONE
    )
    assert adapter.get_event_type("elevenlabs.speech_to_speech.convert") == EventType.ELEVENLABS_STS
    assert adapter.get_event_type("elevenlabs.unknown") == EventType.CUSTOM


def test_elevenlabs_adapter_extract_tts():
    adapter = ElevenLabsAdapter()
    response = MagicMock()

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={
            "voice_id": "abc123",
            "text": "Hello world!",
            "model_id": "eleven_multilingual_v2",
        },
        function_name="elevenlabs.text_to_speech.convert",
        latency_ms=200,
    )

    assert isinstance(payload, ElevenLabsTTSPayload)
    assert payload.voice_id == "abc123"
    assert payload.model_id == "eleven_multilingual_v2"
    assert payload.characters == 12


def test_elevenlabs_adapter_extract_voice_clone():
    adapter = ElevenLabsAdapter()
    response = MagicMock()
    response.voice_id = "new_voice_123"

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={},
        function_name="elevenlabs.voice_clone.clone",
        latency_ms=5000,
    )

    assert isinstance(payload, ElevenLabsVoiceClonePayload)
    assert payload.voice_id == "new_voice_123"


def test_elevenlabs_adapter_extract_sts():
    adapter = ElevenLabsAdapter()
    response = MagicMock()

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={
            "voice_id": "target_voice",
            "model_id": "eleven_english_sts_v2",
            "audio_duration_ms": 5000,
        },
        function_name="elevenlabs.speech_to_speech.convert",
        latency_ms=1000,
    )

    assert isinstance(payload, ElevenLabsSTSPayload)
    assert payload.voice_id == "target_voice"
    assert payload.model_id == "eleven_english_sts_v2"
    assert payload.audio_duration_ms == 5000


# =============================================================================
# OpenRouter Adapter Tests
# =============================================================================


def test_openrouter_adapter_provider_prefix():
    adapter = OpenRouterAdapter()
    assert adapter.provider_prefix == "openrouter"


def test_openrouter_adapter_handles_function():
    adapter = OpenRouterAdapter()
    assert adapter.handles_function("openrouter.chat.completions.create")
    assert not adapter.handles_function("openai.chat.completions.create")


def test_openrouter_adapter_get_event_type():
    adapter = OpenRouterAdapter()
    assert (
        adapter.get_event_type("openrouter.chat.completions.create")
        == EventType.OPENROUTER_CHAT_COMPLETION
    )
    assert adapter.get_event_type("openrouter.unknown") == EventType.CUSTOM


def test_openrouter_adapter_extract_chat_completion():
    adapter = OpenRouterAdapter()
    response = MagicMock()
    response.model = "anthropic/claude-3-opus"
    response.id = "gen-123"
    response.usage = MagicMock()
    response.usage.prompt_tokens = 150
    response.usage.completion_tokens = 80

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={"stream": False},
        function_name="openrouter.chat.completions.create",
        latency_ms=400,
    )

    assert isinstance(payload, OpenRouterChatCompletionPayload)
    assert payload.model == "anthropic/claude-3-opus"
    assert payload.input_tokens == 150
    assert payload.output_tokens == 80
    assert payload.request_id == "gen-123"
    assert payload.streaming is False
    assert payload.latency_ms == 400


def test_openrouter_adapter_extract_chat_completion_no_usage():
    adapter = OpenRouterAdapter()
    response = MagicMock(spec=[])

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={},
        function_name="openrouter.chat.completions.create",
        latency_ms=100,
    )

    assert payload is None


# =============================================================================
# Deepgram Adapter Tests
# =============================================================================


def test_deepgram_adapter_provider_prefix():
    adapter = DeepgramAdapter()
    assert adapter.provider_prefix == "deepgram"


def test_deepgram_adapter_handles_function():
    adapter = DeepgramAdapter()
    assert adapter.handles_function("deepgram.transcription.prerecorded")
    assert adapter.handles_function("deepgram.speak.text")
    assert not adapter.handles_function("openai.audio.transcriptions.create")


def test_deepgram_adapter_get_event_type():
    adapter = DeepgramAdapter()
    assert (
        adapter.get_event_type("deepgram.transcription.prerecorded")
        == EventType.DEEPGRAM_TRANSCRIPTION
    )
    assert adapter.get_event_type("deepgram.transcription.live") == EventType.DEEPGRAM_TRANSCRIPTION
    assert adapter.get_event_type("deepgram.speak.text") == EventType.DEEPGRAM_TTS
    assert adapter.get_event_type("deepgram.unknown") == EventType.CUSTOM


def test_deepgram_adapter_extract_transcription():
    adapter = DeepgramAdapter()
    response = MagicMock()
    response.metadata = MagicMock()
    response.metadata.duration = 120.5

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={"model": "nova-2", "tier": "enhanced", "diarize": True, "punctuate": True},
        function_name="deepgram.transcription.prerecorded",
        latency_ms=3000,
    )

    assert isinstance(payload, DeepgramTranscriptionPayload)
    assert payload.model == "nova-2"
    assert payload.tier == "enhanced"
    assert payload.duration_seconds == 120.5
    assert "diarize" in payload.features
    assert "punctuate" in payload.features


def test_deepgram_adapter_extract_transcription_no_metadata():
    adapter = DeepgramAdapter()
    response = MagicMock(spec=[])

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={"model": "nova-2"},
        function_name="deepgram.transcription.prerecorded",
        latency_ms=1000,
    )

    assert isinstance(payload, DeepgramTranscriptionPayload)
    assert payload.duration_seconds == 0.0


def test_deepgram_adapter_extract_tts():
    adapter = DeepgramAdapter()
    response = MagicMock()

    payload = adapter.extract_usage(
        response=response,
        request_kwargs={"model": "aura-asteria-en", "text": "Hello, how are you?"},
        function_name="deepgram.speak.text",
        latency_ms=200,
    )

    assert isinstance(payload, DeepgramTTSPayload)
    assert payload.model == "aura-asteria-en"
    assert payload.characters == 19


# =============================================================================
# Registry Function Tests
# =============================================================================


def test_get_adapter_for_function_openai():
    adapter = get_adapter_for_function("openai.chat.completions.create")
    assert isinstance(adapter, OpenAIAdapter)


def test_get_adapter_for_function_anthropic():
    adapter = get_adapter_for_function("anthropic.messages.create")
    assert isinstance(adapter, AnthropicAdapter)


def test_get_adapter_for_function_elevenlabs():
    adapter = get_adapter_for_function("elevenlabs.text_to_speech.convert")
    assert isinstance(adapter, ElevenLabsAdapter)


def test_get_adapter_for_function_openrouter():
    adapter = get_adapter_for_function("openrouter.chat.completions.create")
    assert isinstance(adapter, OpenRouterAdapter)


def test_get_adapter_for_function_deepgram():
    adapter = get_adapter_for_function("deepgram.transcription.prerecorded")
    assert isinstance(adapter, DeepgramAdapter)


def test_get_adapter_for_function_unknown():
    adapter = get_adapter_for_function("unknown.provider.method")
    assert adapter is None
