"""Helpers for generating and verifying Stoa connect artifacts."""

from __future__ import annotations

import hmac
import time
from typing import TypedDict
from urllib.parse import urlencode

import jwt


class ConnectRequestParams(TypedDict):
    """Canonical query params for initiating the app -> Stoa connect flow."""

    app_id: str
    external_user_id: str
    redirect_uri: str
    state: str
    timestamp: int
    nonce: str
    signature: str


class ConnectTokenClaims(TypedDict):
    """Claims extracted from a verified connect success token."""

    membership_id: str
    app_id: str
    user_id: str
    state: str
    jti: str
    issued_at: int
    expires_at: int


def build_connect_signature_message(
    *,
    app_id: str,
    external_user_id: str,
    redirect_uri: str,
    state: str,
    timestamp: int,
    nonce: str,
) -> str:
    """Build the canonical message signed by the app server for connect."""
    return ":".join(
        [app_id, external_user_id, redirect_uri, state, str(timestamp), nonce]
    )


def create_connect_request(
    *,
    connect_secret: str,
    app_id: str,
    external_user_id: str,
    redirect_uri: str,
    state: str,
    nonce: str,
    timestamp: int | None = None,
) -> ConnectRequestParams:
    """Create signed query params for the Stoa-hosted connect flow."""
    request_timestamp = timestamp or int(time.time())
    message = build_connect_signature_message(
        app_id=app_id,
        external_user_id=external_user_id,
        redirect_uri=redirect_uri,
        state=state,
        timestamp=request_timestamp,
        nonce=nonce,
    )
    signature = hmac.new(
        connect_secret.encode(),
        message.encode(),
        "sha256",
    ).hexdigest()
    return ConnectRequestParams(
        app_id=app_id,
        external_user_id=external_user_id,
        redirect_uri=redirect_uri,
        state=state,
        timestamp=request_timestamp,
        nonce=nonce,
        signature=signature,
    )


def build_connect_url(
    *,
    connect_secret: str,
    app_id: str,
    external_user_id: str,
    redirect_uri: str,
    state: str,
    nonce: str,
    base_url: str = "https://pay.onstoa.com/connect",
    timestamp: int | None = None,
) -> str:
    """Build a fully signed Stoa connect URL for redirecting the browser."""
    params = create_connect_request(
        connect_secret=connect_secret,
        app_id=app_id,
        external_user_id=external_user_id,
        redirect_uri=redirect_uri,
        state=state,
        nonce=nonce,
        timestamp=timestamp,
    )
    return f"{base_url}?{urlencode(params)}"


def verify_connect_token(
    token: str,
    public_key: str,
    app_id: str,
) -> ConnectTokenClaims:
    """Verify and decode a Stoa connect success JWT token."""
    decode_options: dict[str, object] = {
        "require": [
            "iss",
            "aud",
            "sub",
            "external_id",
            "state",
            "kind",
            "jti",
            "iat",
            "exp",
        ],
    }

    try:
        payload = jwt.decode(
            token,
            public_key,
            algorithms=["EdDSA"],
            audience=app_id,
            issuer="stoa",
            options=decode_options,
        )
    except jwt.ExpiredSignatureError:
        raise ValueError("Token has expired")
    except jwt.InvalidAudienceError:
        raise ValueError("Token audience does not match app_id")
    except jwt.InvalidIssuerError:
        raise ValueError("Token issuer is invalid")
    except jwt.InvalidTokenError as e:
        raise ValueError(f"Invalid token: {e}")

    aud = payload["aud"]
    if isinstance(aud, list):
        if len(aud) != 1 or not isinstance(aud[0], str):
            raise ValueError("Token audience is invalid")
        app_token_id = aud[0]
    elif isinstance(aud, str):
        app_token_id = aud
    else:
        raise ValueError("Token audience is invalid")

    if payload["kind"] != "connect_success":
        raise ValueError("Token kind is invalid")

    return ConnectTokenClaims(
        membership_id=payload["sub"],
        app_id=app_token_id,
        user_id=payload["external_id"],
        state=payload["state"],
        jti=payload["jti"],
        issued_at=payload["iat"],
        expires_at=payload["exp"],
    )
