"""Helpers for handling Stoa install flow callbacks."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TypedDict

import jwt


class InstallTokenClaims(TypedDict):
    """Claims extracted from a verified install token."""

    membership_id: str
    app_id: str
    email: str
    name: str | None
    avatar_url: str | None
    user_id: str | None
    jti: str
    issued_at: int
    expires_at: int


class InstallPublicKey(TypedDict):
    """Stoa install verification key metadata."""

    public_key: str
    algorithm: str


@dataclass(frozen=True, slots=True)
class InstallExchangeResult:
    """Result returned after activating an install bootstrap artifact."""

    membership_id: str
    email: str
    name: str | None
    avatar_url: str | None
    user_id: str


def verify_install_token(
    token: str,
    public_key: str,
    app_id: str,
) -> InstallTokenClaims:
    """Verify and decode a Stoa install flow JWT token.

    This function validates JWTs issued by Stoa during the install flow. Apps receive
    this token as a query parameter when users are redirected after installation.

    Args:
        token: The JWT token from the redirect URL query parameter.
        public_key: Stoa's public key (used to verify signature).
        app_id: App ID to verify the token's audience claim matches.

    Returns:
        A dictionary containing the verified claims:
        - membership_id: The Stoa membership ID (from 'sub' claim)
        - app_id: The Stoa app ID (from 'aud' claim)
        - email: User's email address
        - name: User's display name (may be None)
        - avatar_url: URL to user's avatar image (may be None)
        - user_id: Your app's user ID if you stored one (may be None)
        - jti: Unique token ID for one-time-use enforcement
        - issued_at: Token issued-at timestamp
        - expires_at: Token expiry timestamp

    Raises:
        ValueError: If the token is invalid, expired, or audience doesn't match.

    Example:
        >>> from stoa import verify_install_token
        >>>
        >>> @app.get("/stoa/callback")
        ... def stoa_callback(token: str):
        ...     try:
        ...         claims = verify_install_token(
        ...             token=token,
        ...             public_key=STOA_INSTALL_PUBLIC_KEY,
        ...             app_id=APP_ID,
        ...         )
        ...     except ValueError as e:
        ...         return redirect(f"/login?error={e}")
        ...
        ...     user = find_or_create_user(
        ...         email=claims["email"],
        ...         name=claims["name"],
        ...         stoa_membership_id=claims["membership_id"],
        ...     )
        ...     return create_session_and_redirect(user)
    """
    decode_options: dict[str, object] = {
        "require": ["iss", "aud", "sub", "email", "jti", "iat", "exp"],
    }

    try:
        payload = jwt.decode(
            token,
            public_key,
            algorithms=["EdDSA"],
            audience=app_id,
            issuer="stoa",
            options=decode_options,
        )
    except jwt.ExpiredSignatureError:
        raise ValueError("Token has expired")
    except jwt.InvalidAudienceError:
        raise ValueError("Token audience does not match app_id")
    except jwt.InvalidIssuerError:
        raise ValueError("Token issuer is invalid")
    except jwt.InvalidTokenError as e:
        raise ValueError(f"Invalid token: {e}")

    aud = payload["aud"]
    if isinstance(aud, list):
        if len(aud) != 1 or not isinstance(aud[0], str):
            raise ValueError("Token audience is invalid")
        app_token_id = aud[0]
    elif isinstance(aud, str):
        app_token_id = aud
    else:
        raise ValueError("Token audience is invalid")

    return InstallTokenClaims(
        membership_id=payload["sub"],
        app_id=app_token_id,
        email=payload["email"],
        name=payload.get("name"),
        avatar_url=payload.get("avatar_url"),
        user_id=payload.get("external_id"),
        jti=payload["jti"],
        issued_at=payload["iat"],
        expires_at=payload["exp"],
    )
