from __future__ import annotations

import logging
import os
from collections.abc import Callable
from typing import Any, TypeVar

import httpx
from tenacity import (
    RetryCallState,
    before_sleep_log,
    retry,
    retry_if_exception,
    stop_after_attempt,
)

from stoa.embedded import EmbeddedMembershipResult
from stoa.events import UsageEvent, UsageEventBatch
from stoa.exceptions import (
    InsufficientBalanceError,
    StoaAPIError,
    StoaAuthenticationError,
    StoaBadRequestError,
    StoaConnectionError,
    StoaInternalServerError,
    StoaNotFoundError,
    StoaPermissionDeniedError,
    StoaRateLimitError,
    UserNotFoundError,
)
from stoa.install import InstallExchangeResult, InstallPublicKey

logger = logging.getLogger(__name__)


def _get_env_float(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None or value == "":
        return default
    try:
        return float(value)
    except ValueError:
        return default


def _retry_wait_seconds(retry_state: RetryCallState) -> float:
    multiplier: float = _get_env_float("STOA_RETRY_WAIT_MULTIPLIER", 2.0)
    max_wait: float = _get_env_float("STOA_RETRY_WAIT_MAX", 15.0)
    min_wait: float = _get_env_float("STOA_RETRY_WAIT_MIN", 0.0)
    attempt_number = int(retry_state.attempt_number)
    attempt = max(attempt_number, 1)
    wait: float = multiplier * (2 ** (attempt - 1))
    wait = min(wait, max_wait)
    if min_wait:
        wait = max(wait, min_wait)
    return wait


def is_retryable(exception: BaseException) -> bool:
    """Retry on 5xx errors and rate limits."""
    if isinstance(exception, (StoaInternalServerError, StoaRateLimitError)):
        return True
    if isinstance(exception, StoaConnectionError):
        return True
    return False


F = TypeVar("F", bound=Callable[..., Any])


def with_retry(func: F) -> F:
    """Decorator for retryable Stoa API calls."""
    return retry(
        retry=retry_if_exception(is_retryable),
        stop=stop_after_attempt(4),
        wait=_retry_wait_seconds,
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True,
    )(func)


def raise_for_status(response: httpx.Response, context: str = "") -> None:
    """Convert HTTP response to appropriate exception."""
    if response.status_code < 400:
        return

    try:
        body = response.json()
    except Exception:
        body = response.text

    message = f"{context}: {body}" if context else str(body)

    status_map = {
        400: StoaBadRequestError,
        401: StoaAuthenticationError,
        403: StoaPermissionDeniedError,
        404: StoaNotFoundError,
        429: StoaRateLimitError,
    }

    if response.status_code in status_map:
        raise status_map[response.status_code](message, response=response, body=body)
    elif response.status_code >= 500:
        raise StoaInternalServerError(message, response=response, body=body)
    else:
        raise StoaAPIError(message, response=response, body=body)


class StoaHTTPClient:
    """HTTP client for Stoa backend communication."""

    def __init__(self, api_key: str, base_url: str = "https://api.onstoa.com"):
        self.api_key = api_key
        self.base_url = base_url
        self._stoa_public_key: InstallPublicKey | None = None
        self._client = httpx.Client(
            base_url=base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0,
        )

    @with_retry
    def get_stoa_public_key(self, force_refresh: bool = False) -> InstallPublicKey:
        """Fetch and cache Stoa's public verification key."""
        if self._stoa_public_key is not None and not force_refresh:
            return self._stoa_public_key

        response = self._client.get("/v1/install/public-key")
        raise_for_status(response, "Fetching install public key failed")

        payload = response.json()
        data = payload.get("data")
        if not isinstance(data, dict):
            raise StoaAPIError("Fetching install public key failed: invalid response shape")

        public_key = data.get("public_key")
        algorithm = data.get("algorithm")
        if not isinstance(public_key, str) or not isinstance(algorithm, str):
            raise StoaAPIError("Fetching install public key failed: missing public key data")

        result = InstallPublicKey(public_key=public_key, algorithm=algorithm)
        self._stoa_public_key = result
        return result

    @with_retry
    def exchange_install_token(self, token: str, user_id: str) -> InstallExchangeResult:
        """Activate a pending install bootstrap artifact for an app-local user."""
        response = self._client.post(
            "/v1/install:exchange",
            json={"token": token, "external_id": user_id},
        )
        raise_for_status(response, "Install exchange failed")

        payload = response.json()
        data = payload.get("data")
        if not isinstance(data, dict):
            raise StoaAPIError("Install exchange failed: invalid response shape")

        membership_id = data.get("membership_id")
        email = data.get("email")
        external_id_value = data.get("external_id")
        name = data.get("name")
        avatar_url = data.get("avatar_url")

        if not isinstance(membership_id, str) or not isinstance(email, str):
            raise StoaAPIError("Install exchange failed: missing required response fields")
        if not isinstance(external_id_value, str):
            raise StoaAPIError("Install exchange failed: missing external_id")
        if name is not None and not isinstance(name, str):
            raise StoaAPIError("Install exchange failed: invalid name")
        if avatar_url is not None and not isinstance(avatar_url, str):
            raise StoaAPIError("Install exchange failed: invalid avatar_url")

        return InstallExchangeResult(
            membership_id=membership_id,
            email=email,
            name=name,
            avatar_url=avatar_url,
            user_id=external_id_value,
        )

    @with_retry
    def register_member(
        self,
        *,
        app_id: str,
        user_id: str,
        email: str,
        nonce: str,
        signature: str,
        timestamp: int,
        name: str | None = None,
        avatar_url: str | None = None,
    ) -> EmbeddedMembershipResult:
        """Create or reuse a vetted app member."""
        response = self._client.post(
            "/v1/embedded/memberships:upsert",
            json={
                "app_id": app_id,
                "external_user_id": user_id,
                "email": email,
                "name": name,
                "avatar_url": avatar_url,
                "nonce": nonce,
                "signature": signature,
                "timestamp": timestamp,
            },
        )
        raise_for_status(response, "Embedded membership upsert failed")

        payload = response.json()
        data = payload.get("data")
        if not isinstance(data, dict):
            raise StoaAPIError(
                "Embedded membership upsert failed: invalid response shape"
            )

        membership_id = data.get("membership_id")
        external_id_value = data.get("external_id")
        if not isinstance(membership_id, str) or not isinstance(external_id_value, str):
            raise StoaAPIError(
                "Embedded membership upsert failed: missing required response fields"
            )

        return EmbeddedMembershipResult(
            membership_id=membership_id,
            user_id=external_id_value,
        )

    @with_retry
    def get_hosted_topup_link(
        self,
        *,
        user_id: str,
    ) -> str:
        """Return a hosted Stoa top-up URL for an app-linked active membership."""
        response = self._client.post(
            "/v1/hosted-topup-link",
            json={
                "external_id": user_id,
                "membership_id": None,
            },
        )
        raise_for_status(response, "Fetching hosted top-up link failed")

        payload = response.json()
        data = payload.get("data")
        if not isinstance(data, dict):
            raise StoaAPIError(
                "Fetching hosted top-up link failed: invalid response shape"
            )

        topup_url = data.get("topup_url")
        if not isinstance(topup_url, str):
            raise StoaAPIError(
                "Fetching hosted top-up link failed: missing topup_url"
            )

        return topup_url

    @with_retry
    def report_usage(
        self,
        user_id: str,
        function_name: str,
        usage: dict[str, Any],
        duration: float,
    ) -> dict[str, Any]:
        """
        Report usage and deduct from balance.

        Raises InsufficientBalanceError if user doesn't have enough credits.
        """
        response = self._client.post(
            "/v1/usage/report",
            json={
                "user_id": user_id,
                "function": function_name,
                "usage": usage,
                "duration_ms": int(duration * 1000),
            },
        )

        # Check for insufficient balance response
        if response.status_code == 402:
            data = response.json()
            raise InsufficientBalanceError(
                message="Insufficient balance",
                topup_url=data.get("topup_url"),
                balance=data.get("balance"),
                required=data.get("required"),
            )

        # Check for user not found
        if response.status_code == 404:
            raise UserNotFoundError(f"User '{user_id}' not connected")

        raise_for_status(response, "Usage report failed")
        result: dict[str, Any] = response.json()
        return result

    @with_retry
    def ingest_event(self, event: UsageEvent) -> dict[str, Any]:
        """
        Ingest a single usage event.

        Args:
            event: The usage event to ingest.

        Returns:
            Response from the server.

        Raises:
            InsufficientBalanceError: If user doesn't have enough credits.
            UserNotFoundError: If the user is not connected.
            StoaAPIError: For other API errors.
        """
        response = self._client.post(
            "/v1/events",
            content=event.to_json_bytes(),
            headers={"Content-Type": "application/json"},
        )

        if response.status_code == 402:
            data = response.json()
            raise InsufficientBalanceError(
                message="Insufficient balance",
                topup_url=data.get("topup_url"),
                balance=data.get("balance"),
                required=data.get("required"),
            )

        if response.status_code == 404:
            raise UserNotFoundError(f"User '{event.user_id}' not connected")

        raise_for_status(response, "Event ingestion failed")
        result: dict[str, Any] = response.json()
        return result

    @with_retry
    def ingest_events(self, events: list[UsageEvent]) -> dict[str, Any]:
        """
        Ingest multiple usage events in a single batch.

        Args:
            events: List of usage events to ingest (max 500).

        Returns:
            Response from the server with ingestion results.

        Raises:
            StoaBadRequestError: If batch validation fails.
            StoaAPIError: For other API errors.
        """
        batch = UsageEventBatch(events=events)
        response = self._client.post(
            "/v1/events:batchCreate",
            content=batch.to_json_bytes(),
            headers={"Content-Type": "application/json"},
        )

        raise_for_status(response, "Batch event ingestion failed")
        result: dict[str, Any] = response.json()
        return result

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> StoaHTTPClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
