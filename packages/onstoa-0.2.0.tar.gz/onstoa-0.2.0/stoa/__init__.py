from stoa.client import Stoa
from stoa.connect import (
    ConnectTokenClaims,
    verify_connect_token,
)
from stoa.embedded import (
    EmbeddedMembershipResult,
)
from stoa.events import (
    AnthropicMessagesPayload,
    CustomPayload,
    DeepgramTranscriptionPayload,
    DeepgramTTSPayload,
    ElevenLabsSTSPayload,
    ElevenLabsTTSPayload,
    ElevenLabsVoiceClonePayload,
    EventPayload,
    EventType,
    OpenAIAudioSpeechPayload,
    OpenAIAudioTranscriptionPayload,
    OpenAIChatCompletionPayload,
    OpenAICompletionPayload,
    OpenAIEmbeddingPayload,
    OpenAIImageGenerationPayload,
    OpenRouterChatCompletionPayload,
    UsageEvent,
    UsageEventBatch,
)
from stoa.exceptions import (
    InsufficientBalanceError,
    StoaAPIError,
    StoaError,
    UserNotFoundError,
)
from stoa.install import (
    InstallExchangeResult,
    InstallPublicKey,
    InstallTokenClaims,
    verify_install_token,
)

__all__ = [
    # Client
    "Stoa",
    # Events
    "EventType",
    "EventPayload",
    "UsageEvent",
    "UsageEventBatch",
    # Payloads
    "OpenAIChatCompletionPayload",
    "OpenAICompletionPayload",
    "OpenAIEmbeddingPayload",
    "OpenAIImageGenerationPayload",
    "OpenAIAudioTranscriptionPayload",
    "OpenAIAudioSpeechPayload",
    "AnthropicMessagesPayload",
    "OpenRouterChatCompletionPayload",
    "ElevenLabsTTSPayload",
    "ElevenLabsVoiceClonePayload",
    "ElevenLabsSTSPayload",
    "DeepgramTranscriptionPayload",
    "DeepgramTTSPayload",
    "CustomPayload",
    # Exceptions
    "StoaError",
    "StoaAPIError",
    "InsufficientBalanceError",
    "UserNotFoundError",
    # Install flow
    "verify_install_token",
    "InstallTokenClaims",
    "InstallPublicKey",
    "InstallExchangeResult",
    # Connect flow
    "verify_connect_token",
    "ConnectTokenClaims",
    # Vetted member registration
    "EmbeddedMembershipResult",
]

__version__ = "0.2.0"
