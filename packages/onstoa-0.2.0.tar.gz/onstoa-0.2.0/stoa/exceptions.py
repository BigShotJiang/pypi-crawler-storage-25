from __future__ import annotations

from typing import Any


class StoaError(Exception):
    """
    Base exception for all Stoa SDK errors.

    All exceptions raised by the Stoa SDK inherit from this class,
    making it easy to catch all Stoa-related errors.

    Attributes:
        message: Human-readable error description.
        response: The HTTP response object, if available.
        body: The response body, if available.

    Example:
        >>> try:
        ...     client = stoa.openai(user_id="user_123")
        ...     client.chat.completions.create(...)
        ... except StoaError as e:
        ...     print(f"Stoa error: {e.message}")
    """

    def __init__(self, message: str, response: Any = None, body: Any = None):
        super().__init__(message)
        self.message = message
        self.response = response
        self.body = body


class StoaAPIError(StoaError):
    """
    Base exception for API-related errors.

    Raised when the Stoa API returns an error response. Subclasses provide
    more specific error types based on HTTP status codes.

    Example:
        >>> try:
        ...     client.chat.completions.create(...)
        ... except StoaAPIError as e:
        ...     print(f"API error: {e.message}")
        ...     if e.response:
        ...         print(f"Status: {e.response.status_code}")
    """

    pass


# HTTP status code mappings
class StoaBadRequestError(StoaAPIError):
    """HTTP 400 Bad Request - Invalid request parameters."""

    pass


class StoaAuthenticationError(StoaAPIError):
    """HTTP 401 Unauthorized - Invalid or missing API key."""

    pass


class StoaPermissionDeniedError(StoaAPIError):
    """HTTP 403 Forbidden - API key lacks required permissions."""

    pass


class StoaNotFoundError(StoaAPIError):
    """HTTP 404 Not Found - Resource does not exist."""

    pass


class StoaRateLimitError(StoaAPIError):
    """HTTP 429 Too Many Requests - Rate limit exceeded. Will auto-retry."""

    pass


class StoaInternalServerError(StoaAPIError):
    """HTTP 5xx Server Error - Stoa backend error. Will auto-retry."""

    pass


# Stoa-specific exceptions
class InsufficientBalanceError(StoaError):
    """
    User doesn't have enough credits to complete the request.

    Raised after an API call completes but the user's balance is insufficient
    to cover the cost. The response from the provider is still returned, but
    the user should be prompted to add credits.

    Attributes:
        topup_url: URL where the user can add credits to their account.
        balance: The user's current balance.
        required: The amount required for this request.

    Example:
        >>> try:
        ...     response = client.chat.completions.create(...)
        ... except InsufficientBalanceError as e:
        ...     print(f"Balance: ${e.balance:.2f}, Required: ${e.required:.2f}")
        ...     print(f"Top up at: {e.topup_url}")
    """

    def __init__(
        self,
        message: str,
        topup_url: str | None = None,
        balance: float | None = None,
        required: float | None = None,
    ):
        super().__init__(message)
        self.topup_url = topup_url
        self.balance = balance
        self.required = required


class UserNotFoundError(StoaError):
    """
    User ID not connected to your app in Stoa.

    Raised when attempting to use a provider client for a user that hasn't
    completed the Stoa connect flow for your app.

    Example:
        >>> try:
        ...     client = stoa.openai(user_id="unknown_user")
        ...     response = client.chat.completions.create(...)
        ... except UserNotFoundError:
        ...     # Show your "Connect to Stoa" flow to the user.
    """

    pass


# Network errors
class StoaConnectionError(StoaError):
    """
    Failed to connect to Stoa backend.

    Raised when network connectivity issues prevent communication with
    the Stoa API. The SDK will automatically retry with exponential backoff.
    """

    pass


class StoaTimeoutError(StoaError):
    """
    Request to Stoa backend timed out.

    Raised when a request takes longer than the configured timeout (30s default).
    """

    pass
