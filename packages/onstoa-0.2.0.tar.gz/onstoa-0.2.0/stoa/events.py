"""Event schema models for Stoa usage metering."""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Annotated, Any, Literal
from uuid import UUID

import orjson
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from uuid_utils import uuid7 as _uuid7


def _generate_uuid7() -> UUID:
    """Generate a UUIDv7 as a standard library UUID."""
    return UUID(bytes=_uuid7().bytes)


# ============================================================================
# Event Types (Provider + Function specific)
# ============================================================================


class EventType(str, Enum):
    """
    Supported usage event types.

    Each event type maps directly to a pricing table entry.
    Format: provider.function
    """

    # OpenAI
    OPENAI_CHAT_COMPLETION = "openai.chat_completion"
    OPENAI_COMPLETION = "openai.completion"
    OPENAI_EMBEDDING = "openai.embedding"
    OPENAI_IMAGE_GENERATION = "openai.image_generation"
    OPENAI_AUDIO_TRANSCRIPTION = "openai.audio_transcription"
    OPENAI_AUDIO_SPEECH = "openai.audio_speech"

    # Anthropic
    ANTHROPIC_MESSAGES = "anthropic.messages"

    # OpenRouter (uses OpenAI-compatible API but different pricing)
    OPENROUTER_CHAT_COMPLETION = "openrouter.chat_completion"

    # ElevenLabs
    ELEVENLABS_TTS = "elevenlabs.tts"
    ELEVENLABS_VOICE_CLONE = "elevenlabs.voice_clone"
    ELEVENLABS_STS = "elevenlabs.sts"

    # Deepgram
    DEEPGRAM_TRANSCRIPTION = "deepgram.transcription"
    DEEPGRAM_TTS = "deepgram.tts"

    # Custom (for user-defined metrics)
    CUSTOM = "custom"


# ============================================================================
# Base Payload Model with orjson support
# ============================================================================


class PayloadBase(BaseModel):
    """Base class for all payload types with orjson serialization."""

    model_config = ConfigDict(
        populate_by_name=True,
        ser_json_bytes="base64",
    )


# ============================================================================
# Provider + Function Specific Payloads
# ============================================================================

# --- OpenAI Payloads ---


class OpenAIChatCompletionPayload(PayloadBase):
    """Payload for OpenAI chat.completions.create calls."""

    model: str = Field(..., description="Model ID (e.g., 'gpt-4-turbo', 'gpt-4o')")
    input_tokens: int = Field(..., ge=0, description="Prompt tokens")
    output_tokens: int = Field(..., ge=0, description="Completion tokens")

    # OpenAI-specific token breakdowns
    cached_tokens: int = Field(0, ge=0, description="Tokens served from prompt cache")
    reasoning_tokens: int = Field(0, ge=0, description="Reasoning tokens (o1 models)")

    # Metadata
    request_id: str | None = Field(None, description="OpenAI request ID (chatcmpl-xxx)")
    streaming: bool = Field(False)
    latency_ms: int | None = Field(None, ge=0)


class OpenAICompletionPayload(PayloadBase):
    """Payload for legacy OpenAI completions.create calls."""

    model: str = Field(..., description="Model ID")
    input_tokens: int = Field(..., ge=0, description="Prompt tokens")
    output_tokens: int = Field(..., ge=0, description="Completion tokens")
    request_id: str | None = Field(None)


class OpenAIEmbeddingPayload(PayloadBase):
    """Payload for OpenAI embeddings.create calls."""

    model: str = Field(..., description="Embedding model (e.g., 'text-embedding-3-large')")
    input_tokens: int = Field(..., ge=0, description="Tokens embedded")
    dimensions: int | None = Field(None, ge=1, description="Output dimensions (if reduced)")
    request_id: str | None = Field(None)


class OpenAIImageGenerationPayload(PayloadBase):
    """Payload for OpenAI images.generate calls."""

    model: str = Field(..., description="Model (e.g., 'dall-e-3')")
    size: str = Field(..., description="Image size (e.g., '1024x1024', '1792x1024')")
    quality: str = Field("standard", description="'standard' or 'hd'")
    n: int = Field(1, ge=1, description="Number of images generated")
    request_id: str | None = Field(None)


class OpenAIAudioTranscriptionPayload(PayloadBase):
    """Payload for OpenAI audio.transcriptions.create calls."""

    model: str = Field(..., description="Model (e.g., 'whisper-1')")
    duration_seconds: float = Field(..., ge=0, description="Audio duration in seconds")
    request_id: str | None = Field(None)


class OpenAIAudioSpeechPayload(PayloadBase):
    """Payload for OpenAI audio.speech.create calls."""

    model: str = Field(..., description="Model (e.g., 'tts-1', 'tts-1-hd')")
    voice: str = Field(..., description="Voice ID (e.g., 'alloy', 'echo')")
    characters: int = Field(..., ge=0, description="Input character count")
    request_id: str | None = Field(None)


# --- Anthropic Payloads ---


class AnthropicMessagesPayload(PayloadBase):
    """Payload for Anthropic messages.create calls."""

    model: str = Field(..., description="Model ID (e.g., 'claude-3-5-sonnet-20241022')")
    input_tokens: int = Field(..., ge=0, description="Input tokens")
    output_tokens: int = Field(..., ge=0, description="Output tokens")

    # Anthropic-specific: prompt caching
    cache_creation_input_tokens: int = Field(0, ge=0, description="Tokens written to cache")
    cache_read_input_tokens: int = Field(0, ge=0, description="Tokens read from cache")

    # Metadata
    request_id: str | None = Field(None, description="Anthropic request ID (msg_xxx)")
    streaming: bool = Field(False)
    latency_ms: int | None = Field(None, ge=0)


# --- OpenRouter Payloads ---


class OpenRouterChatCompletionPayload(PayloadBase):
    """Payload for OpenRouter chat completions (OpenAI-compatible API)."""

    model: str = Field(..., description="Model path (e.g., 'anthropic/claude-3-opus')")
    input_tokens: int = Field(..., ge=0, description="Prompt tokens")
    output_tokens: int = Field(..., ge=0, description="Completion tokens")

    # OpenRouter reports native tokens for some models
    native_input_tokens: int | None = Field(None, ge=0)
    native_output_tokens: int | None = Field(None, ge=0)

    request_id: str | None = Field(None)
    streaming: bool = Field(False)
    latency_ms: int | None = Field(None, ge=0)


# --- ElevenLabs Payloads ---


class ElevenLabsTTSPayload(PayloadBase):
    """Payload for ElevenLabs text_to_speech.convert calls."""

    voice_id: str = Field(..., description="Voice ID")
    model_id: str | None = Field(None, description="Model (e.g., 'eleven_multilingual_v2')")
    characters: int = Field(..., ge=0, description="Characters synthesized")

    # Metadata
    request_id: str | None = Field(None)
    audio_duration_ms: int | None = Field(None, ge=0, description="Output audio length")


class ElevenLabsVoiceClonePayload(PayloadBase):
    """Payload for ElevenLabs voice cloning."""

    voice_id: str = Field(..., description="Created voice ID")
    request_id: str | None = Field(None)


class ElevenLabsSTSPayload(PayloadBase):
    """Payload for ElevenLabs speech_to_speech.convert calls."""

    voice_id: str = Field(..., description="Target voice ID")
    model_id: str | None = Field(None)
    audio_duration_ms: int = Field(..., ge=0, description="Input audio duration")
    request_id: str | None = Field(None)


# --- Deepgram Payloads ---


class DeepgramTranscriptionPayload(PayloadBase):
    """Payload for Deepgram transcription."""

    model: str = Field(..., description="Model (e.g., 'nova-2')")
    tier: str = Field("nova", description="Pricing tier")
    duration_seconds: float = Field(..., ge=0, description="Audio duration")
    features: list[str] = Field(default_factory=list, description="Enabled features")
    request_id: str | None = Field(None)


class DeepgramTTSPayload(PayloadBase):
    """Payload for Deepgram TTS (Aura)."""

    model: str = Field(..., description="Voice model")
    characters: int = Field(..., ge=0, description="Characters synthesized")
    request_id: str | None = Field(None)


# --- Custom Payload ---


class CustomPayload(PayloadBase):
    """Payload for custom user-defined metrics."""

    metric_name: str = Field(..., description="Custom metric identifier")
    value: float = Field(..., description="Metric value")
    unit: str | None = Field(None, description="Unit of measurement")
    properties: dict[str, str | int | float | bool] = Field(
        default_factory=dict,
        description="Additional properties for billing rules",
    )


# ============================================================================
# Payload Union
# ============================================================================

EventPayload = Annotated[
    OpenAIChatCompletionPayload
    | OpenAICompletionPayload
    | OpenAIEmbeddingPayload
    | OpenAIImageGenerationPayload
    | OpenAIAudioTranscriptionPayload
    | OpenAIAudioSpeechPayload
    | AnthropicMessagesPayload
    | OpenRouterChatCompletionPayload
    | ElevenLabsTTSPayload
    | ElevenLabsVoiceClonePayload
    | ElevenLabsSTSPayload
    | DeepgramTranscriptionPayload
    | DeepgramTTSPayload
    | CustomPayload,
    Field(discriminator=None),
]

# Mapping from EventType to expected Payload type (for validation)
EVENT_TYPE_PAYLOADS: dict[EventType, type[PayloadBase]] = {
    EventType.OPENAI_CHAT_COMPLETION: OpenAIChatCompletionPayload,
    EventType.OPENAI_COMPLETION: OpenAICompletionPayload,
    EventType.OPENAI_EMBEDDING: OpenAIEmbeddingPayload,
    EventType.OPENAI_IMAGE_GENERATION: OpenAIImageGenerationPayload,
    EventType.OPENAI_AUDIO_TRANSCRIPTION: OpenAIAudioTranscriptionPayload,
    EventType.OPENAI_AUDIO_SPEECH: OpenAIAudioSpeechPayload,
    EventType.ANTHROPIC_MESSAGES: AnthropicMessagesPayload,
    EventType.OPENROUTER_CHAT_COMPLETION: OpenRouterChatCompletionPayload,
    EventType.ELEVENLABS_TTS: ElevenLabsTTSPayload,
    EventType.ELEVENLABS_VOICE_CLONE: ElevenLabsVoiceClonePayload,
    EventType.ELEVENLABS_STS: ElevenLabsSTSPayload,
    EventType.DEEPGRAM_TRANSCRIPTION: DeepgramTranscriptionPayload,
    EventType.DEEPGRAM_TTS: DeepgramTTSPayload,
    EventType.CUSTOM: CustomPayload,
}


# ============================================================================
# Core Event Model
# ============================================================================


def _utc_now() -> datetime:
    """Return current UTC time."""
    return datetime.now(timezone.utc)


class UsageEvent(BaseModel):
    """
    Core usage event for metering and billing.

    Each event represents a single billable action. The event_type determines
    which pricing rules apply, and the payload contains the usage details
    needed for cost calculation.
    """

    model_config = ConfigDict(
        populate_by_name=True,
        ser_json_bytes="base64",
    )

    # === Required Fields ===

    event_id: UUID = Field(
        default_factory=_generate_uuid7,
        description="Unique event identifier (UUIDv7 for time-ordering). "
        "Duplicates within 30 days are ignored.",
    )

    user_id: str = Field(
        ...,
        min_length=1,
        max_length=255,
        description="Application's user identifier to bill for this usage",
    )

    event_type: EventType = Field(
        ...,
        description="Provider + function identifier (maps to pricing table)",
    )

    timestamp: datetime = Field(
        default_factory=_utc_now,
        description="When the usage occurred (UTC). Max 1 hour in future.",
    )

    # === Payload (type depends on event_type) ===

    payload: EventPayload = Field(
        ...,
        description="Usage details specific to the event_type",
    )

    # === Optional Metadata ===

    app_metadata: dict[str, str | int | float | bool] | None = Field(
        None,
        description="Application-specific metadata (not used for billing)",
    )

    # === Schema Version ===

    schema_version: Literal["1.0"] = Field(
        "1.0",
        description="Event schema version",
    )

    @model_validator(mode="before")
    @classmethod
    def coerce_payload_type(cls, data: dict[str, Any]) -> dict[str, Any]:
        """Coerce payload to correct type based on event_type."""
        if not isinstance(data, dict):
            return data
        event_type_raw = data.get("event_type")
        payload = data.get("payload")

        if event_type_raw and payload and isinstance(payload, dict):
            # Convert string event_type to EventType enum
            try:
                event_type = EventType(event_type_raw)
            except ValueError:
                return data

            # Get expected payload type and construct it
            if event_type in EVENT_TYPE_PAYLOADS:
                expected_cls = EVENT_TYPE_PAYLOADS[event_type]
                data["payload"] = expected_cls(**payload)

        return data

    @model_validator(mode="after")
    def validate_payload_matches_event_type(self) -> UsageEvent:
        """Ensure payload type matches event_type."""
        if self.event_type in EVENT_TYPE_PAYLOADS:
            expected_type = EVENT_TYPE_PAYLOADS[self.event_type]
            if not isinstance(self.payload, expected_type):
                raise ValueError(
                    f"Payload must be {expected_type.__name__} for event_type {self.event_type}"
                )
        return self

    def to_json_bytes(self) -> bytes:
        """Serialize to JSON bytes using orjson."""
        return orjson.dumps(self.model_dump(mode="json"))

    def to_json(self) -> str:
        """Serialize to JSON string."""
        return self.to_json_bytes().decode("utf-8")

    @classmethod
    def from_json(cls, data: str | bytes) -> UsageEvent:
        """Deserialize from JSON string or bytes."""
        if isinstance(data, str):
            data = data.encode("utf-8")
        return cls.model_validate(orjson.loads(data))


# ============================================================================
# Batch Event Wrapper
# ============================================================================


class UsageEventBatch(BaseModel):
    """Batch of usage events for bulk ingestion."""

    model_config = ConfigDict(
        populate_by_name=True,
        ser_json_bytes="base64",
    )

    events: list[UsageEvent] = Field(
        ...,
        min_length=1,
        max_length=500,
        description="List of events to ingest (max 500 per batch)",
    )

    @field_validator("events")
    @classmethod
    def validate_unique_ids(cls, v: list[UsageEvent]) -> list[UsageEvent]:
        """Ensure no duplicate event_ids in batch."""
        ids = [e.event_id for e in v]
        if len(ids) != len(set(ids)):
            raise ValueError("Duplicate event_ids in batch")
        return v

    def to_json_bytes(self) -> bytes:
        """Serialize to JSON bytes using orjson."""
        return orjson.dumps(self.model_dump(mode="json"))

    def to_json(self) -> str:
        """Serialize to JSON string."""
        return self.to_json_bytes().decode("utf-8")

    @classmethod
    def from_json(cls, data: str | bytes) -> UsageEventBatch:
        """Deserialize from JSON string or bytes."""
        if isinstance(data, str):
            data = data.encode("utf-8")
        return cls.model_validate(orjson.loads(data))
