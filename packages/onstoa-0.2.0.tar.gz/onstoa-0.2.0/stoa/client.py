from __future__ import annotations

import os
from typing import Any

from stoa.connect import (
    ConnectRequestParams,
    ConnectTokenClaims,
    build_connect_url,
    create_connect_request,
    verify_connect_token,
)
from stoa.embedded import (
    EmbeddedMembershipRequest,
    EmbeddedMembershipResult,
    create_embedded_membership_request,
)
from stoa.exceptions import StoaError
from stoa.http import StoaHTTPClient
from stoa.install import (
    InstallExchangeResult,
    InstallPublicKey,
    InstallTokenClaims,
    verify_install_token,
)
from stoa.proxy import StoaProxy


class Stoa:
    """
    Main Stoa client for usage metering and billing.

    The Stoa client wraps AI provider clients (OpenAI, Anthropic, etc.) to
    automatically track usage and bill users based on consumption.

    Args:
        api_key: Your Stoa application API key. If not provided, reads from
            the STOA_API_KEY environment variable.
        base_url: Stoa API base URL. Defaults to https://api.onstoa.com or
            the STOA_BASE_URL environment variable.

    Raises:
        StoaError: If no API key is provided and STOA_API_KEY is not set.

    Example:
        >>> from stoa import Stoa
        >>> stoa = Stoa()  # Uses STOA_API_KEY from environment
        >>> client = stoa.openai(user_id="user_123")
        >>> response = client.chat.completions.create(
        ...     model="gpt-4",
        ...     messages=[{"role": "user", "content": "Hello!"}]
        ... )
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        app_id: str | None = None,
    ):
        self.api_key = api_key or os.environ.get("STOA_API_KEY")
        if not self.api_key:
            raise StoaError("STOA_API_KEY not set")

        self.base_url = base_url or os.environ.get("STOA_BASE_URL", "https://api.onstoa.com")
        self.app_id = app_id or os.environ.get("STOA_APP_ID")
        self._http = StoaHTTPClient(self.api_key, self.base_url)

    def get_stoa_public_key(self, force_refresh: bool = False) -> InstallPublicKey:
        """Fetch Stoa's public verification key for signed bootstrap artifacts.

        The SDK caches the key after the first successful fetch.
        """
        return self._http.get_stoa_public_key(force_refresh=force_refresh)

    def verify_install_callback(
        self,
        token: str,
        app_id: str | None = None,
        *,
        force_refresh_public_key: bool = False,
    ) -> InstallTokenClaims:
        """Verify a Stoa install callback token without manual key management."""
        resolved_app_id = app_id or self.app_id
        if not resolved_app_id:
            raise StoaError("STOA_APP_ID not set")
        public_key = self.get_stoa_public_key(force_refresh=force_refresh_public_key)
        return verify_install_token(
            token=token,
            public_key=public_key["public_key"],
            app_id=resolved_app_id,
        )

    def verify_connect_callback(
        self,
        token: str,
        app_id: str | None = None,
        *,
        force_refresh_public_key: bool = False,
    ) -> ConnectTokenClaims:
        """Verify a Stoa connect completion token without manual key management."""
        resolved_app_id = app_id or self.app_id
        if not resolved_app_id:
            raise StoaError("STOA_APP_ID not set")
        public_key = self.get_stoa_public_key(force_refresh=force_refresh_public_key)
        return verify_connect_token(
            token=token,
            public_key=public_key["public_key"],
            app_id=resolved_app_id,
        )

    def exchange_install_token(self, token: str, user_id: str) -> InstallExchangeResult:
        """Activate a pending Stoa install for the given app-local user ID."""
        return self._http.exchange_install_token(token=token, user_id=user_id)

    def _create_connect_request(
        self,
        *,
        connect_secret: str,
        app_id: str,
        external_user_id: str,
        redirect_uri: str,
        state: str,
        nonce: str,
        timestamp: int | None = None,
    ) -> ConnectRequestParams:
        """Internal helper for constructing hosted connect requests."""
        return create_connect_request(
            connect_secret=connect_secret,
            app_id=app_id,
            external_user_id=external_user_id,
            redirect_uri=redirect_uri,
            state=state,
            nonce=nonce,
            timestamp=timestamp,
        )

    def _build_connect_url(
        self,
        *,
        connect_secret: str,
        app_id: str,
        external_user_id: str,
        redirect_uri: str,
        state: str,
        nonce: str,
        connect_base_url: str | None = None,
        timestamp: int | None = None,
    ) -> str:
        """Internal helper for constructing hosted connect URLs."""
        base_url = connect_base_url or f"{self.base_url.rstrip('/')}/connect"
        return build_connect_url(
            connect_secret=connect_secret,
            app_id=app_id,
            external_user_id=external_user_id,
            redirect_uri=redirect_uri,
            state=state,
            nonce=nonce,
            base_url=base_url,
            timestamp=timestamp,
        )

    def _create_member_registration_request(
        self,
        *,
        connect_secret: str,
        app_id: str | None = None,
        user_id: str,
        email: str,
        nonce: str | None = None,
        name: str | None = None,
        avatar_url: str | None = None,
        timestamp: int | None = None,
    ) -> EmbeddedMembershipRequest:
        """Internal helper for constructing vetted member registration requests."""
        resolved_app_id = app_id or self.app_id
        if not resolved_app_id:
            raise StoaError("STOA_APP_ID not set")
        return create_embedded_membership_request(
            connect_secret=connect_secret,
            app_id=resolved_app_id,
            user_id=user_id,
            email=email,
            nonce=nonce,
            name=name,
            avatar_url=avatar_url,
            timestamp=timestamp,
        )

    def register_member(
        self,
        *,
        connect_secret: str,
        app_id: str | None = None,
        user_id: str,
        email: str,
        nonce: str | None = None,
        name: str | None = None,
        avatar_url: str | None = None,
        timestamp: int | None = None,
    ) -> EmbeddedMembershipResult:
        """Create or reuse a vetted app member with one SDK call."""
        payload = self._create_member_registration_request(
            connect_secret=connect_secret,
            app_id=app_id,
            user_id=user_id,
            email=email,
            nonce=nonce,
            name=name,
            avatar_url=avatar_url,
            timestamp=timestamp,
        )
        return self._http.register_member(
            app_id=payload["app_id"],
            user_id=payload["external_user_id"],
            email=payload["email"],
            nonce=payload["nonce"],
            signature=payload["signature"],
            timestamp=payload["timestamp"],
            name=payload["name"],
            avatar_url=payload["avatar_url"],
        )

    def get_topup_url(
        self,
        *,
        user_id: str,
    ) -> str:
        """Return the hosted Stoa top-up URL for a connected app user."""
        return self._http.get_hosted_topup_link(user_id=user_id)

    def openai(self, user_id: str) -> Any:
        """
        Get a user-scoped OpenAI client with automatic usage tracking.

        Returns a wrapped OpenAI client that automatically reports usage to Stoa
        for billing. Use it exactly like the standard openai.OpenAI client.

        Args:
            user_id: The user to bill for this client's usage.

        Returns:
            A wrapped OpenAI client that tracks usage.

        Raises:
            InsufficientBalanceError: When making API calls if user has no credits.
            UserNotFoundError: When making API calls if user is not connected.

        Example:
            >>> client = stoa.openai(user_id="user_123")
            >>> response = client.chat.completions.create(
            ...     model="gpt-4",
            ...     messages=[{"role": "user", "content": "Hello!"}]
            ... )
        """
        import openai

        client = openai.OpenAI()
        return StoaProxy(
            obj=client,
            function_name="openai",
            user_id=user_id,
            stoa_client=self._http,
        )

    def anthropic(self, user_id: str) -> Any:
        """
        Get a user-scoped Anthropic client with automatic usage tracking.

        Returns a wrapped Anthropic client that automatically reports usage to Stoa
        for billing. Use it exactly like the standard anthropic.Anthropic client.

        Args:
            user_id: The user to bill for this client's usage.

        Returns:
            A wrapped Anthropic client that tracks usage.

        Raises:
            InsufficientBalanceError: When making API calls if user has no credits.
            UserNotFoundError: When making API calls if user is not connected.

        Example:
            >>> client = stoa.anthropic(user_id="user_123")
            >>> response = client.messages.create(
            ...     model="claude-3-5-sonnet-20241022",
            ...     max_tokens=1024,
            ...     messages=[{"role": "user", "content": "Hello!"}]
            ... )
        """
        import anthropic

        client = anthropic.Anthropic()
        return StoaProxy(
            obj=client,
            function_name="anthropic",
            user_id=user_id,
            stoa_client=self._http,
        )

    def openrouter(self, user_id: str) -> Any:
        """
        Get a user-scoped OpenRouter client with automatic usage tracking.

        Returns a wrapped OpenAI-compatible client configured for OpenRouter,
        allowing access to 100+ models through a single API. Requires the
        OPENROUTER_API_KEY environment variable.

        Args:
            user_id: The user to bill for this client's usage.

        Returns:
            A wrapped OpenAI-compatible client for OpenRouter.

        Raises:
            InsufficientBalanceError: When making API calls if user has no credits.
            UserNotFoundError: When making API calls if user is not connected.

        Example:
            >>> client = stoa.openrouter(user_id="user_123")
            >>> response = client.chat.completions.create(
            ...     model="meta-llama/llama-3.1-70b-instruct",
            ...     messages=[{"role": "user", "content": "Hello!"}]
            ... )
        """
        import openai as openai_module

        client = openai_module.OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=os.environ.get("OPENROUTER_API_KEY"),
        )
        return StoaProxy(
            obj=client,
            function_name="openrouter",
            user_id=user_id,
            stoa_client=self._http,
        )

    def elevenlabs(self, user_id: str) -> Any:
        """
        Get a user-scoped ElevenLabs client with automatic usage tracking.

        Returns a wrapped ElevenLabs client that automatically reports usage
        (character count) to Stoa for billing. Use it exactly like the standard
        ElevenLabs client.

        Args:
            user_id: The user to bill for this client's usage.

        Returns:
            A wrapped ElevenLabs client that tracks usage.

        Raises:
            InsufficientBalanceError: When making API calls if user has no credits.
            UserNotFoundError: When making API calls if user is not connected.

        Example:
            >>> client = stoa.elevenlabs(user_id="user_123")
            >>> audio = client.text_to_speech.convert(
            ...     voice_id="JBFqnCBsd6RMkjVDRZzb",
            ...     text="Hello, welcome to our application!"
            ... )
        """
        from elevenlabs.client import ElevenLabs as ElevenLabsClient

        client = ElevenLabsClient()
        return StoaProxy(
            obj=client,
            function_name="elevenlabs",
            user_id=user_id,
            stoa_client=self._http,
        )
