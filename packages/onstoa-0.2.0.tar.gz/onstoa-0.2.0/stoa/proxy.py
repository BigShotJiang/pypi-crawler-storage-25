from __future__ import annotations

import inspect
import time
from typing import Any

from stoa.events import EventType, UsageEvent
from stoa.http import StoaHTTPClient
from stoa.providers import get_adapter_for_function, get_adapter_for_resource


class StoaProxy:
    """
    Transparent proxy that wraps provider clients to meter usage.

    Recursively wraps attribute access to build call chains like
    `client.chat.completions.create()`.
    """

    __slots__ = ["_obj", "_function_name", "_user_id", "_stoa_client"]

    def __init__(
        self,
        obj: Any,
        function_name: str,
        user_id: str,
        stoa_client: StoaHTTPClient,
    ):
        object.__setattr__(self, "_obj", obj)
        object.__setattr__(self, "_function_name", function_name)
        object.__setattr__(self, "_user_id", user_id)
        object.__setattr__(self, "_stoa_client", stoa_client)

    def __getattr__(self, name: str) -> Any:
        attr = getattr(object.__getattribute__(self, "_obj"), name)

        if self._should_wrap(attr):
            return StoaProxy(
                obj=attr,
                function_name=f"{object.__getattribute__(self, '_function_name')}.{name}",
                user_id=object.__getattribute__(self, "_user_id"),
                stoa_client=object.__getattribute__(self, "_stoa_client"),
            )
        return attr

    def _should_wrap(self, attr: Any) -> bool:
        """Determine if attribute should be wrapped for tracking."""
        if inspect.isclass(attr) or inspect.isfunction(attr) or inspect.ismethod(attr):
            return True

        if self._is_provider_resource(attr):
            return True

        return False

    def _is_provider_resource(self, attr: Any) -> bool:
        """Check if attr is a provider SDK resource."""
        return get_adapter_for_resource(attr) is not None

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        stoa_client = object.__getattribute__(self, "_stoa_client")
        user_id = object.__getattribute__(self, "_user_id")
        function_name = object.__getattribute__(self, "_function_name")
        function_object = object.__getattribute__(self, "_obj")

        # Execute the API call
        request_start = time.time()
        response = function_object(*args, **kwargs)
        request_duration = time.time() - request_start
        latency_ms = int(request_duration * 1000)

        # Build event and report usage — may raise InsufficientBalanceError
        event_type, payload = self._extract_usage(response, kwargs, function_name, latency_ms)

        if payload is not None:
            event = UsageEvent(
                user_id=user_id,
                event_type=event_type,
                payload=payload,
            )
            stoa_client.ingest_event(event)

        return response

    def _extract_usage(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
        function_name: str,
        latency_ms: int,
    ) -> tuple[EventType, Any]:
        """Extract usage from provider response using the appropriate adapter."""
        adapter = get_adapter_for_function(function_name)

        if adapter is None:
            return EventType.CUSTOM, None

        event_type = adapter.get_event_type(function_name)
        payload = adapter.extract_usage(response, request_kwargs, function_name, latency_ms)

        return event_type, payload
