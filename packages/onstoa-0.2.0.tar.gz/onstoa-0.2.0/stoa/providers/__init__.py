"""Provider adapters for Stoa usage metering."""

from stoa.providers.anthropic import AnthropicAdapter
from stoa.providers.base import ProviderAdapter
from stoa.providers.deepgram import DeepgramAdapter
from stoa.providers.elevenlabs import ElevenLabsAdapter
from stoa.providers.openai import OpenAIAdapter
from stoa.providers.openrouter import OpenRouterAdapter

__all__ = [
    "ProviderAdapter",
    "AnthropicAdapter",
    "DeepgramAdapter",
    "ElevenLabsAdapter",
    "OpenAIAdapter",
    "OpenRouterAdapter",
]

# Registry of all available adapters
ADAPTERS: list[ProviderAdapter] = [
    OpenAIAdapter(),
    AnthropicAdapter(),
    ElevenLabsAdapter(),
    OpenRouterAdapter(),
    DeepgramAdapter(),
]


def get_adapter_for_function(function_name: str) -> ProviderAdapter | None:
    """Get the appropriate adapter for a function name."""
    for adapter in ADAPTERS:
        if adapter.handles_function(function_name):
            return adapter
    return None


def get_adapter_for_resource(attr: object) -> ProviderAdapter | None:
    """Get the appropriate adapter for a provider resource."""
    for adapter in ADAPTERS:
        if adapter.is_provider_resource(attr):
            return adapter
    return None
