"""Anthropic provider adapter."""

from __future__ import annotations

from typing import Any

from stoa.events import AnthropicMessagesPayload, EventPayload, EventType
from stoa.providers.base import ProviderAdapter


class AnthropicAdapter(ProviderAdapter):
    """Adapter for Anthropic API usage extraction."""

    @property
    def provider_prefix(self) -> str:
        return "anthropic"

    @property
    def resource_module_prefixes(self) -> tuple[str, ...]:
        return ("anthropic.resources",)

    def get_event_type(self, function_name: str) -> EventType:
        mapping: dict[str, EventType] = {
            "anthropic.messages.create": EventType.ANTHROPIC_MESSAGES,
        }
        return mapping.get(function_name, EventType.CUSTOM)

    def extract_usage(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
        function_name: str,
        latency_ms: int,
    ) -> EventPayload | None:
        event_type = self.get_event_type(function_name)

        if event_type == EventType.ANTHROPIC_MESSAGES:
            return self._extract_messages(response, request_kwargs, latency_ms)

        return None

    def _extract_messages(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
        latency_ms: int,
    ) -> AnthropicMessagesPayload | None:
        if not hasattr(response, "usage") or not response.usage:
            return None

        model = getattr(response, "model", request_kwargs.get("model", "unknown"))
        request_id = getattr(response, "id", None)
        cache_creation = getattr(response.usage, "cache_creation_input_tokens", 0) or 0
        cache_read = getattr(response.usage, "cache_read_input_tokens", 0) or 0

        return AnthropicMessagesPayload(
            model=model,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            cache_creation_input_tokens=cache_creation,
            cache_read_input_tokens=cache_read,
            request_id=request_id,
            streaming=request_kwargs.get("stream", False),
            latency_ms=latency_ms,
        )
