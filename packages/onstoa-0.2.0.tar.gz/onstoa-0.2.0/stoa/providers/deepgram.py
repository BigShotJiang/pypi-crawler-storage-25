"""Deepgram provider adapter."""

from __future__ import annotations

from typing import Any

from stoa.events import (
    DeepgramTranscriptionPayload,
    DeepgramTTSPayload,
    EventPayload,
    EventType,
)
from stoa.providers.base import ProviderAdapter


class DeepgramAdapter(ProviderAdapter):
    """Adapter for Deepgram API usage extraction."""

    @property
    def provider_prefix(self) -> str:
        return "deepgram"

    @property
    def resource_module_prefixes(self) -> tuple[str, ...]:
        return ("deepgram.",)

    def get_event_type(self, function_name: str) -> EventType:
        mapping: dict[str, EventType] = {
            "deepgram.transcription.prerecorded": EventType.DEEPGRAM_TRANSCRIPTION,
            "deepgram.transcription.live": EventType.DEEPGRAM_TRANSCRIPTION,
            "deepgram.speak.text": EventType.DEEPGRAM_TTS,
        }
        return mapping.get(function_name, EventType.CUSTOM)

    def extract_usage(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
        function_name: str,
        latency_ms: int,
    ) -> EventPayload | None:
        event_type = self.get_event_type(function_name)

        if event_type == EventType.DEEPGRAM_TRANSCRIPTION:
            return self._extract_transcription(response, request_kwargs)
        if event_type == EventType.DEEPGRAM_TTS:
            return self._extract_tts(response, request_kwargs)

        return None

    def _extract_transcription(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
    ) -> DeepgramTranscriptionPayload | None:
        model = request_kwargs.get("model", "nova-2")
        tier = request_kwargs.get("tier", "nova")

        # Try to extract duration from response metadata
        duration = 0.0
        if hasattr(response, "metadata") and response.metadata:
            duration = getattr(response.metadata, "duration", 0.0) or 0.0

        # Extract features from request
        features: list[str] = []
        feature_keys = ["diarize", "punctuate", "smart_format", "paragraphs", "utterances"]
        for key in feature_keys:
            if request_kwargs.get(key):
                features.append(key)

        return DeepgramTranscriptionPayload(
            model=model,
            tier=tier,
            duration_seconds=duration,
            features=features,
        )

    def _extract_tts(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
    ) -> DeepgramTTSPayload:
        model = request_kwargs.get("model", "aura-asteria-en")
        text = request_kwargs.get("text", "")
        characters = len(text) if isinstance(text, str) else 0

        return DeepgramTTSPayload(
            model=model,
            characters=characters,
        )
