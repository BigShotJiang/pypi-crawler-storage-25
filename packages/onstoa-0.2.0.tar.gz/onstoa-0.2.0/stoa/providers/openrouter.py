"""OpenRouter provider adapter."""

from __future__ import annotations

from typing import Any

from stoa.events import EventPayload, EventType, OpenRouterChatCompletionPayload
from stoa.providers.base import ProviderAdapter


class OpenRouterAdapter(ProviderAdapter):
    """Adapter for OpenRouter API usage extraction.

    OpenRouter uses an OpenAI-compatible API but with different pricing
    and model routing.
    """

    @property
    def provider_prefix(self) -> str:
        return "openrouter"

    @property
    def resource_module_prefixes(self) -> tuple[str, ...]:
        # OpenRouter typically uses the openai SDK with a different base_url,
        # so we can't easily distinguish by module. We rely on function_name.
        return ()

    def get_event_type(self, function_name: str) -> EventType:
        mapping: dict[str, EventType] = {
            "openrouter.chat.completions.create": EventType.OPENROUTER_CHAT_COMPLETION,
        }
        return mapping.get(function_name, EventType.CUSTOM)

    def extract_usage(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
        function_name: str,
        latency_ms: int,
    ) -> EventPayload | None:
        event_type = self.get_event_type(function_name)

        if event_type == EventType.OPENROUTER_CHAT_COMPLETION:
            return self._extract_chat_completion(response, request_kwargs, latency_ms)

        return None

    def _extract_chat_completion(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
        latency_ms: int,
    ) -> OpenRouterChatCompletionPayload | None:
        if not hasattr(response, "usage") or not response.usage:
            return None

        model = getattr(response, "model", request_kwargs.get("model", "unknown"))
        request_id = getattr(response, "id", None)

        return OpenRouterChatCompletionPayload(
            model=model,
            input_tokens=response.usage.prompt_tokens,
            output_tokens=response.usage.completion_tokens,
            request_id=request_id,
            streaming=request_kwargs.get("stream", False),
            latency_ms=latency_ms,
        )
