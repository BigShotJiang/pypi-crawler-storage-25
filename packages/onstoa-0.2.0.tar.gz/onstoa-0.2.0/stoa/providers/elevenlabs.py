"""ElevenLabs provider adapter."""

from __future__ import annotations

from typing import Any

from stoa.events import (
    ElevenLabsSTSPayload,
    ElevenLabsTTSPayload,
    ElevenLabsVoiceClonePayload,
    EventPayload,
    EventType,
)
from stoa.providers.base import ProviderAdapter


class ElevenLabsAdapter(ProviderAdapter):
    """Adapter for ElevenLabs API usage extraction."""

    @property
    def provider_prefix(self) -> str:
        return "elevenlabs"

    @property
    def resource_module_prefixes(self) -> tuple[str, ...]:
        return ("elevenlabs.",)

    def get_event_type(self, function_name: str) -> EventType:
        mapping: dict[str, EventType] = {
            "elevenlabs.text_to_speech.convert": EventType.ELEVENLABS_TTS,
            "elevenlabs.voice_clone.clone": EventType.ELEVENLABS_VOICE_CLONE,
            "elevenlabs.speech_to_speech.convert": EventType.ELEVENLABS_STS,
        }
        return mapping.get(function_name, EventType.CUSTOM)

    def extract_usage(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
        function_name: str,
        latency_ms: int,
    ) -> EventPayload | None:
        event_type = self.get_event_type(function_name)

        if event_type == EventType.ELEVENLABS_TTS:
            return self._extract_tts(response, request_kwargs)
        if event_type == EventType.ELEVENLABS_VOICE_CLONE:
            return self._extract_voice_clone(response, request_kwargs)
        if event_type == EventType.ELEVENLABS_STS:
            return self._extract_sts(response, request_kwargs)

        return None

    def _extract_tts(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
    ) -> ElevenLabsTTSPayload:
        text = request_kwargs.get("text", "")
        voice_id = request_kwargs.get("voice_id", "unknown")
        model_id = request_kwargs.get("model_id")

        return ElevenLabsTTSPayload(
            voice_id=voice_id,
            model_id=model_id,
            characters=len(text) if isinstance(text, str) else 0,
        )

    def _extract_voice_clone(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
    ) -> ElevenLabsVoiceClonePayload:
        voice_id = getattr(response, "voice_id", None) or request_kwargs.get("name", "unknown")

        return ElevenLabsVoiceClonePayload(
            voice_id=voice_id,
        )

    def _extract_sts(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
    ) -> ElevenLabsSTSPayload:
        voice_id = request_kwargs.get("voice_id", "unknown")
        model_id = request_kwargs.get("model_id")
        audio_duration_ms = request_kwargs.get("audio_duration_ms", 0)

        return ElevenLabsSTSPayload(
            voice_id=voice_id,
            model_id=model_id,
            audio_duration_ms=audio_duration_ms,
        )
