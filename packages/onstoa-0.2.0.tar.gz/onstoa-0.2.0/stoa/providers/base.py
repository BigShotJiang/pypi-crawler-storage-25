"""Abstract base class for provider adapters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from stoa.events import EventPayload, EventType


class ProviderAdapter(ABC):
    """
    Abstract base class for provider-specific usage extraction.

    Each provider adapter handles:
    - Mapping function names to EventType
    - Extracting usage from responses
    - Creating appropriate payload objects
    """

    @property
    @abstractmethod
    def provider_prefix(self) -> str:
        """Return the provider prefix for function names (e.g., 'openai', 'anthropic')."""
        ...

    @property
    @abstractmethod
    def resource_module_prefixes(self) -> tuple[str, ...]:
        """Return module prefixes that identify this provider's SDK resources."""
        ...

    @abstractmethod
    def get_event_type(self, function_name: str) -> EventType:
        """
        Map a function name to its corresponding EventType.

        Args:
            function_name: The full function path (e.g., 'openai.chat.completions.create')

        Returns:
            The corresponding EventType, or EventType.CUSTOM if not recognized.
        """
        ...

    @abstractmethod
    def extract_usage(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
        function_name: str,
        latency_ms: int,
    ) -> EventPayload | None:
        """
        Extract usage information from a provider response.

        Args:
            response: The response object from the provider API
            request_kwargs: The keyword arguments passed to the API call
            function_name: The full function path
            latency_ms: The latency of the request in milliseconds

        Returns:
            An EventPayload subclass instance, or None if usage cannot be extracted.
        """
        ...

    def handles_function(self, function_name: str) -> bool:
        """Check if this adapter handles the given function name."""
        return function_name.startswith(f"{self.provider_prefix}.")

    def is_provider_resource(self, attr: Any) -> bool:
        """Check if an attribute is a resource from this provider's SDK."""
        module = getattr(type(attr), "__module__", "")
        return any(module.startswith(prefix) for prefix in self.resource_module_prefixes)
