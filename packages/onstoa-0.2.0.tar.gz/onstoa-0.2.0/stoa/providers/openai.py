"""OpenAI provider adapter."""

from __future__ import annotations

from typing import Any

from stoa.events import (
    EventPayload,
    EventType,
    OpenAIAudioSpeechPayload,
    OpenAIAudioTranscriptionPayload,
    OpenAIChatCompletionPayload,
    OpenAICompletionPayload,
    OpenAIEmbeddingPayload,
    OpenAIImageGenerationPayload,
)
from stoa.providers.base import ProviderAdapter


class OpenAIAdapter(ProviderAdapter):
    """Adapter for OpenAI API usage extraction."""

    @property
    def provider_prefix(self) -> str:
        return "openai"

    @property
    def resource_module_prefixes(self) -> tuple[str, ...]:
        return ("openai.resources",)

    def get_event_type(self, function_name: str) -> EventType:
        mapping: dict[str, EventType] = {
            "openai.chat.completions.create": EventType.OPENAI_CHAT_COMPLETION,
            "openai.completions.create": EventType.OPENAI_COMPLETION,
            "openai.embeddings.create": EventType.OPENAI_EMBEDDING,
            "openai.images.generate": EventType.OPENAI_IMAGE_GENERATION,
            "openai.audio.transcriptions.create": EventType.OPENAI_AUDIO_TRANSCRIPTION,
            "openai.audio.speech.create": EventType.OPENAI_AUDIO_SPEECH,
        }
        return mapping.get(function_name, EventType.CUSTOM)

    def extract_usage(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
        function_name: str,
        latency_ms: int,
    ) -> EventPayload | None:
        event_type = self.get_event_type(function_name)

        if event_type == EventType.OPENAI_CHAT_COMPLETION:
            return self._extract_chat_completion(response, request_kwargs, latency_ms)
        if event_type == EventType.OPENAI_COMPLETION:
            return self._extract_completion(response, request_kwargs)
        if event_type == EventType.OPENAI_EMBEDDING:
            return self._extract_embedding(response, request_kwargs)
        if event_type == EventType.OPENAI_IMAGE_GENERATION:
            return self._extract_image_generation(response, request_kwargs)
        if event_type == EventType.OPENAI_AUDIO_TRANSCRIPTION:
            return self._extract_audio_transcription(response, request_kwargs)
        if event_type == EventType.OPENAI_AUDIO_SPEECH:
            return self._extract_audio_speech(response, request_kwargs)

        return None

    def _extract_chat_completion(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
        latency_ms: int,
    ) -> OpenAIChatCompletionPayload | None:
        if not hasattr(response, "usage") or not response.usage:
            return None

        model = getattr(response, "model", request_kwargs.get("model", "unknown"))
        request_id = getattr(response, "id", None)
        cached_tokens = 0
        reasoning_tokens = 0

        if hasattr(response.usage, "prompt_tokens_details"):
            details = response.usage.prompt_tokens_details
            if details and hasattr(details, "cached_tokens"):
                cached_tokens = details.cached_tokens or 0
        if hasattr(response.usage, "completion_tokens_details"):
            details = response.usage.completion_tokens_details
            if details and hasattr(details, "reasoning_tokens"):
                reasoning_tokens = details.reasoning_tokens or 0

        return OpenAIChatCompletionPayload(
            model=model,
            input_tokens=response.usage.prompt_tokens,
            output_tokens=response.usage.completion_tokens,
            cached_tokens=cached_tokens,
            reasoning_tokens=reasoning_tokens,
            request_id=request_id,
            streaming=request_kwargs.get("stream", False),
            latency_ms=latency_ms,
        )

    def _extract_completion(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
    ) -> OpenAICompletionPayload | None:
        if not hasattr(response, "usage") or not response.usage:
            return None

        model = getattr(response, "model", request_kwargs.get("model", "unknown"))
        request_id = getattr(response, "id", None)

        return OpenAICompletionPayload(
            model=model,
            input_tokens=response.usage.prompt_tokens,
            output_tokens=response.usage.completion_tokens,
            request_id=request_id,
        )

    def _extract_embedding(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
    ) -> OpenAIEmbeddingPayload | None:
        if not hasattr(response, "usage") or not response.usage:
            return None

        model = getattr(response, "model", request_kwargs.get("model", "unknown"))

        return OpenAIEmbeddingPayload(
            model=model,
            input_tokens=response.usage.total_tokens,
            dimensions=request_kwargs.get("dimensions"),
            request_id=None,
        )

    def _extract_image_generation(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
    ) -> OpenAIImageGenerationPayload | None:
        model = request_kwargs.get("model", "dall-e-2")
        size = request_kwargs.get("size", "1024x1024")
        quality = request_kwargs.get("quality", "standard")
        n = request_kwargs.get("n", 1)

        return OpenAIImageGenerationPayload(
            model=model,
            size=size,
            quality=quality,
            n=n,
            request_id=None,
        )

    def _extract_audio_transcription(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
    ) -> OpenAIAudioTranscriptionPayload | None:
        model = request_kwargs.get("model", "whisper-1")
        duration = getattr(response, "duration", 0.0) or 0.0

        return OpenAIAudioTranscriptionPayload(
            model=model,
            duration_seconds=duration,
            request_id=None,
        )

    def _extract_audio_speech(
        self,
        response: Any,
        request_kwargs: dict[str, Any],
    ) -> OpenAIAudioSpeechPayload | None:
        model = request_kwargs.get("model", "tts-1")
        voice = request_kwargs.get("voice", "alloy")
        text = request_kwargs.get("input", "")
        characters = len(text) if isinstance(text, str) else 0

        return OpenAIAudioSpeechPayload(
            model=model,
            voice=voice,
            characters=characters,
            request_id=None,
        )
