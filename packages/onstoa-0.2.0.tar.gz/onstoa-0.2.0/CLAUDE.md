# Stoa SDK

Usage-based billing SDK for AI applications.

## Build System

Use `just` for all build, test, and lint commands. Run `just` to see available recipes.

### Key Recipes

```bash
just lint        # Run all linting (ruff + mypy strict)
just test        # Run tests
just check       # Run all checks (lint + test)
just fmt         # Format code with ruff
just ruff-fix    # Auto-fix ruff issues
```

### Other Recipes

- `just install` - Install all dependencies with uv
- `just mypy` - Run mypy type checker only
- `just ruff` - Run ruff linter only
- `just test-cov` - Run tests with coverage
- `just build` - Build package
- `just clean` - Clean build artifacts

## Conventions

- Python 3.10+ required
- Use `orjson` instead of `json` for serialization
- Use function-based tests (no class-based pytest tests)
- mypy strict mode is enforced
- Line length: 100 characters
- asyncio_mode is auto for pytest-asyncio
