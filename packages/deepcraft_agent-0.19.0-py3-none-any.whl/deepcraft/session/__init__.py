"""Session recording and replay — JSONL-based turn-by-turn capture."""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class TurnRecord:
    """A single turn in a recorded session."""

    def __init__(
        self,
        turn: int,
        user_input: str,
        response: str = "",
        tool_calls: list[dict[str, Any]] | None = None,
        duration_ms: int = 0,
        token_estimate: int = 0,
        compression_count: int = 0,
    ) -> None:
        self.turn = turn
        self.timestamp = datetime.now(timezone.utc).isoformat()
        self.user_input = user_input
        self.response = response
        self.tool_calls = tool_calls or []
        self.duration_ms = duration_ms
        self.token_estimate = token_estimate
        self.compression_count = compression_count

    def to_dict(self) -> dict[str, Any]:
        return {
            "turn": self.turn,
            "timestamp": self.timestamp,
            "user_input": self.user_input,
            "response": self.response,
            "tool_calls": self.tool_calls,
            "duration_ms": self.duration_ms,
            "token_estimate": self.token_estimate,
            "compression_count": self.compression_count,
        }


class SessionRecorder:
    """Records agent conversation turns to a JSONL file.

    Usage:
        recorder = SessionRecorder()
        recorder.start()
        # ... after each turn ...
        recorder.record_turn(1, "hello", "Hi!", tool_calls=[...], duration_ms=1200)
        recorder.stop()
    """

    def __init__(self, path: Path | str | None = None) -> None:
        if path is None:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = Path.cwd() / ".deepcraft" / "sessions" / f"{ts}.jsonl"
        self._path = Path(path)
        self._file = None
        self._start_time: float = 0.0
        self._recording = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> Path:
        """Begin recording. Creates the session file. Returns the path."""
        if self._recording:
            return self._path

        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._file = open(self._path, "w", encoding="utf-8")  # noqa: SIM115
        self._start_time = time.monotonic()
        self._recording = True

        # Write header
        self._file.write(
            json.dumps(
                {
                    "type": "header",
                    "started_at": datetime.now(timezone.utc).isoformat(),
                    "version": "1.0",
                }
            )
            + "\n"
        )
        self._file.flush()
        return self._path

    def record_turn(
        self,
        turn: int,
        user_input: str,
        response: str = "",
        tool_calls: list[dict[str, Any]] | None = None,
        duration_ms: int = 0,
        token_estimate: int = 0,
        compression_count: int = 0,
    ) -> None:
        """Record a single conversation turn."""
        if not self._recording or self._file is None:
            return

        record = TurnRecord(
            turn=turn,
            user_input=user_input,
            response=response,
            tool_calls=tool_calls,
            duration_ms=duration_ms,
            token_estimate=token_estimate,
            compression_count=compression_count,
        )
        self._file.write(json.dumps(record.to_dict(), ensure_ascii=False) + "\n")
        self._file.flush()

    def stop(self) -> Path:
        """Stop recording. Returns the session file path."""
        if not self._recording or self._file is None:
            return self._path

        # Write footer
        elapsed = time.monotonic() - self._start_time
        self._file.write(
            json.dumps(
                {
                    "type": "footer",
                    "ended_at": datetime.now(timezone.utc).isoformat(),
                    "duration_seconds": round(elapsed, 1),
                }
            )
            + "\n"
        )
        self._file.close()
        self._file = None
        self._recording = False
        return self._path

    @property
    def is_recording(self) -> bool:
        return self._recording

    @property
    def path(self) -> Path:
        return self._path

    # ------------------------------------------------------------------
    # Replay (static)
    # ------------------------------------------------------------------

    @staticmethod
    def replay(path: Path | str, console=None) -> str:
        """Replay a recorded session as formatted text.

        Returns a Markdown string suitable for display.
        """
        path = Path(path)
        if not path.exists():
            return f"Session file not found: {path}"

        lines: list[str] = []
        lines.append(f"# Session Replay: {path.name}")
        lines.append("")

        try:
            with open(path, encoding="utf-8") as f:
                for line in f:
                    record = json.loads(line)
                    rtype = record.get("type")

                    if rtype == "header":
                        lines.append(f"Started: {record.get('started_at', '?')}")
                        lines.append("")
                        continue

                    if rtype == "footer":
                        lines.append("---")
                        lines.append(f"Ended: {record.get('ended_at', '?')}")
                        lines.append(f"Duration: {record.get('duration_seconds', '?')}s")
                        continue

                    # Turn record
                    turn = record.get("turn", "?")
                    user_input = record.get("user_input", "")
                    response = record.get("response", "")
                    tool_calls = record.get("tool_calls", [])
                    duration_ms = record.get("duration_ms", 0)
                    token_est = record.get("token_estimate", 0)
                    comp = record.get("compression_count", 0)

                    lines.append(f"## Turn {turn}")
                    lines.append(f"⏱ {duration_ms}ms | 📊 ~{token_est} tokens | 🗜 compression #{comp}")
                    lines.append("")
                    lines.append(f"**User:** {user_input}")
                    lines.append("")
                    if tool_calls:
                        lines.append("**Tools:**")
                        for tc in tool_calls:
                            name = tc.get("name", "?")
                            args = tc.get("arguments", {})
                            args_str = json.dumps(args, ensure_ascii=False)[:200]
                            lines.append(f"  - `{name}({args_str})`")
                        lines.append("")
                    if response:
                        lines.append(f"**DeepCraft:** {response}")
                    lines.append("")
                    lines.append("---")
                    lines.append("")

        except (json.JSONDecodeError, KeyError) as e:
            lines.append(f"⚠️ Error reading session file: {e}")

        result = "\n".join(lines)

        if console:
            from rich.markdown import Markdown

            console.print(Markdown(result))

        return result
