     1|"""DeepCraft — DeepSeek-powered AI coding agent."""
     2|
     3|__version__ = "0.19.0"
     4|