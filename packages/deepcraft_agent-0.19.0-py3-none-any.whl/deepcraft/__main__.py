"""Allow running as: python -m deepcraft"""

from deepcraft.cli import main

if __name__ == "__main__":
    main()
