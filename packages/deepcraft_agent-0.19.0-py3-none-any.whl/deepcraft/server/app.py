"""FastAPI application — SSE streaming + Web UI server."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel

from deepcraft import __version__
from deepcraft.agent.mcp.client import MCPManager
from deepcraft.agent.repl import _connect_mcp_servers, _create_agent
from deepcraft.config import PROVIDER, _get_provider_config
from deepcraft.memory import MemoryStore
from deepcraft.server.runner import SSERunner

STATIC_DIR = Path(__file__).parent.parent / "static"


class ChatRequest(BaseModel):
    prompt: str


def create_app() -> FastAPI:
    """Create the FastAPI application with all routes."""
    app = FastAPI(
        title="DeepCraft API",
        version=__version__,
        description="DeepSeek-powered AI coding agent — Web UI and SSE streaming API",
    )

    # CORS — allow local dev
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/api/status")
    async def status() -> dict[str, Any]:
        return {
            "version": __version__,
            "provider": PROVIDER,
            "model": _get_provider_config(PROVIDER).get("model", "unknown"),
        }

    @app.get("/api/tools")
    async def tools() -> list[dict[str, Any]]:
        agent = _create_agent()
        return agent.tools.list_definitions()

    @app.post("/api/chat")
    async def chat_stream(req: ChatRequest) -> StreamingResponse:
        """SSE streaming chat endpoint."""

        async def event_stream():
            agent = _create_agent()
            mcp_manager = MCPManager(agent.tools)
            memory = MemoryStore(llm=agent.llm)

            try:
                # Connect MCP
                await _connect_mcp_servers(agent, mcp_manager)

                # Load memories
                recent = memory.load_recent(5)
                if recent:
                    agent.ctx.add_message("user", recent)

                # Run agent via SSE runner
                runner = SSERunner(agent)
                async for event in runner.run(req.prompt):
                    yield event.to_sse()

            except Exception as e:
                import json

                yield f"event: error\ndata: {json.dumps({'message': str(e)})}\n\n"
            finally:
                await mcp_manager.close_all()
                await agent.close()

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    @app.post("/api/chat/sync")
    async def chat_sync(req: ChatRequest) -> dict[str, Any]:
        """Non-streaming chat endpoint — returns full response."""
        agent = _create_agent()
        mcp_manager = MCPManager(agent.tools)
        memory = MemoryStore(llm=agent.llm)

        try:
            await _connect_mcp_servers(agent, mcp_manager)

            recent = memory.load_recent(5)
            if recent:
                agent.ctx.add_message("user", recent)

            response = await agent.run(req.prompt)
            return {"response": response}
        finally:
            await mcp_manager.close_all()
            await agent.close()

    # --- Static Web UI ---
    @app.get("/")
    async def index() -> FileResponse:
        return FileResponse(STATIC_DIR / "index.html")

    @app.get("/favicon.ico")
    async def favicon() -> dict[str, Any]:
        return {}  # no favicon, suppress 404 noise

    return app


def run_server(host: str = "127.0.0.1", port: int = 8080) -> None:
    """Run the server via uvicorn."""
    import uvicorn

    uvicorn.run(create_app(), host=host, port=port, log_level="info")
