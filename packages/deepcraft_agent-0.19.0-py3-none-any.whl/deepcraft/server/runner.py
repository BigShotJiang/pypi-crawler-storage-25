"""SSE streaming agent runner — wraps Agent.run() into async event generator.

Events:
  text       — streaming text chunk
  tool_call  — tool invocation started
  tool_result— tool execution result
  done       — final response complete
  error      — error occurred
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

from deepcraft.agent.loop import Agent
from deepcraft.agent.types import ChatMessage, Role
from deepcraft.agent.types import ToolResult as TypedToolResult
from deepcraft.config import MAX_TURNS


@dataclass
class SSEEvent:
    """A single SSE event emitted during agent execution."""

    event: str  # "text" | "tool_call" | "tool_result" | "done" | "error"
    data: dict[str, Any] = field(default_factory=dict)

    def to_sse(self) -> str:
        payload = json.dumps(self.data, ensure_ascii=False)
        return f"event: {self.event}\ndata: {payload}\n\n"


class SSERunner:
    """Wraps an Agent, yielding SSEEvent items as it runs."""

    def __init__(self, agent: Agent) -> None:
        self.agent = agent

    async def run(self, user_input: str) -> AsyncIterator[SSEEvent]:
        """Run the agent loop, yielding SSE events instead of printing.

        Yields:
            SSEEvent — text chunks, tool calls, results, done/error.
        """
        agent = self.agent
        agent._turn_count = 0
        agent._recent_actions = []
        agent.ctx.add_message(Role.USER, user_input)

        while agent._turn_count < MAX_TURNS:
            agent._turn_count += 1

            # --- Get LLM response (streaming → SSE text events) ---
            tool_calls_buffer: dict[int, dict[str, Any]] = {}
            content_parts: list[str] = []

            tool_defs = agent.tools.list_definitions()
            messages = agent.ctx.get_messages()

            try:
                async for chunk in agent.llm.chat(messages, tools=tool_defs or None):
                    if chunk.delta is None:
                        continue

                    # Streaming text
                    if chunk.delta.content:
                        content_parts.append(chunk.delta.content)
                        yield SSEEvent(event="text", data={"content": chunk.delta.content})

                    # Tool calls
                    if chunk.delta.tool_calls:
                        for tc in chunk.delta.tool_calls:
                            tc_index = tc.get("index")
                            if tc_index is None:
                                tc_index = len(tool_calls_buffer)
                            if tc.get("id"):
                                tool_calls_buffer[tc_index] = dict(tc)
                            elif tc_index in tool_calls_buffer:
                                tc_args = tc.get("function", {}).get("arguments", "")
                                tool_calls_buffer[tc_index]["function"]["arguments"] += tc_args

                    if chunk.finish_reason:
                        break
            except Exception as e:
                yield SSEEvent(event="error", data={"message": str(e)})
                return

            # --- No tool calls: done ---
            if not tool_calls_buffer:
                response_text = "".join(content_parts)
                agent.ctx.add_message(Role.ASSISTANT, response_text)
                yield SSEEvent(
                    event="done",
                    data={"response": response_text, "turns": agent._turn_count},
                )
                return

            # --- Execute tool calls ---
            tool_results: list[TypedToolResult] = []

            for tc in tool_calls_buffer.values():
                tool_name = tc["function"]["name"]
                tool_id = tc["id"]

                # Parse arguments
                args_str = tc["function"]["arguments"]
                try:
                    arguments = json.loads(args_str) if args_str else {}
                except json.JSONDecodeError:
                    arguments = {}

                # Loop detection
                action_key = f"{tool_name}:{json.dumps(arguments, sort_keys=True)}"
                agent._recent_actions.append(action_key)
                if agent._recent_actions[-3:].count(action_key) == 3:
                    yield SSEEvent(
                        event="error",
                        data={"message": "Loop detected — 3 identical tool calls."},
                    )
                    return
                agent._recent_actions = agent._recent_actions[-10:]

                yield SSEEvent(
                    event="tool_call",
                    data={"name": tool_name, "arguments": arguments},
                )

                result = await agent.tools.execute(tool_name, arguments)
                tool_results.append(
                    TypedToolResult(
                        tool_call_id=tool_id,
                        content=result.content,
                        is_error=result.is_error,
                    )
                )

                # Truncate long results
                display = result.content[:2000]
                yield SSEEvent(
                    event="tool_result",
                    data={
                        "name": tool_name,
                        "result": display,
                        "is_error": result.is_error,
                        "truncated": len(result.content) > 2000,
                    },
                )

            # --- Add assistant message + tool results to context ---
            assistant_msg = ChatMessage(
                role="assistant",
                content="".join(content_parts) or None,
                tool_calls=[
                    {
                        "id": tc["id"],
                        "type": "function",
                        "function": {
                            "name": tc["function"]["name"],
                            "arguments": tc["function"]["arguments"],
                        },
                    }
                    for tc in tool_calls_buffer.values()
                ],
            )
            agent.ctx._messages.append(assistant_msg)

            for tr in tool_results:
                agent.ctx.add_message(
                    Role.TOOL,
                    tr.content,
                    tool_call_id=tr.tool_call_id,
                )

        # Max turns reached
        yield SSEEvent(
            event="error",
            data={"message": f"Reached max turns ({MAX_TURNS})."},
        )
