"""DeepCraft HTTP server — FastAPI-based Web UI and SSE streaming API."""

from deepcraft.server.app import create_app

__all__ = ["create_app"]
