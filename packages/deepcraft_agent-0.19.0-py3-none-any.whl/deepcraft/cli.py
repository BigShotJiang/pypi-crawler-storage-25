"""CLI entry point for DeepCraft."""

from __future__ import annotations

import sys

import click

from deepcraft import __version__
from deepcraft.config import validate


@click.group(invoke_without_command=True)
@click.version_option(__version__, prog_name="deepcraft")
@click.pass_context
def main(ctx: click.Context) -> None:
    """DeepCraft — DeepSeek-powered AI coding agent."""
    if ctx.invoked_subcommand is None:
        # Default: start REPL
        from deepcraft.agent.repl import run_repl

        validate()
        run_repl()


@main.command()
@click.argument("prompt", nargs=-1)
def run(prompt: tuple[str, ...]) -> None:
    """Run a single prompt and exit."""
    validate()
    text = " ".join(prompt)
    if not text:
        click.echo("Error: provide a prompt or use 'deepcraft' for REPL mode.", err=True)
        sys.exit(1)
    from deepcraft.agent.repl import run_once

    run_once(text)


@main.command()
@click.option("--host", default=None, help="Host to bind (default: 127.0.0.1)")
@click.option("--port", default=None, type=int, help="Port to bind (default: 8080)")
def serve(host: str | None, port: int | None) -> None:
    """Start the Web UI + SSE streaming server."""
    from deepcraft.config import SERVER_HOST, SERVER_PORT

    validate()
    host = host or SERVER_HOST
    port = port or SERVER_PORT

    from deepcraft.server.app import run_server

    click.echo(f"⚡ DeepCraft v{__version__} Web UI → http://{host}:{port}")
    run_server(host=host, port=port)


# Register config subcommand group
from deepcraft.config_cli import config_group  # noqa: E402

main.add_command(config_group)


if __name__ == "__main__":
    main()
