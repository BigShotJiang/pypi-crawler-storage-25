"""Long-term memory — file-backed semantic store with DeepSeek ranking.

Layout: ~/.deepcraft/memory/
  index.json          → [{key, summary, timestamp, tags}, ...]
  {key}.json          → {key, value, summary, timestamp, tags}
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from deepcraft.providers import LLMProvider

MEMORY_DIR = Path.home() / ".deepcraft" / "memory"

SEARCH_PROMPT = """You are a memory ranking system.
Given a user query and a list of memory summaries, rank them by relevance
to the query on a scale of 0-100. Return ONLY a JSON array of scores
in the same order as the memories. Example: [95, 30, 0]

Query: {query}

Memories:
{memories}

Scores (JSON array only):"""

EXTRACT_PROMPT = """Extract key facts from this conversation fragment that are worth remembering long-term.
Focus on: user preferences, project decisions, recurring patterns, fixed bugs, and conventions.
Return as a JSON array of objects with "key" (short slug, lowercase with hyphens)
and "value" (the fact). Max 3 facts. Return ONLY the JSON array.

Example:
[{"key": "prefer-tabs", "value": "User prefers tabs over spaces for indentation"},
 {"key": "db-host", "value": "Production database runs on db-prod.internal:5432"}]

Conversation:
{context}

Facts (JSON array only):"""


class MemoryEntry:
    """A single memory entry."""

    def __init__(
        self,
        key: str,
        value: str,
        summary: str = "",
        tags: list[str] | None = None,
        timestamp: str | None = None,
    ) -> None:
        self.key = key
        self.value = value
        self.summary = summary or value[:200]
        self.tags = tags or []
        self.timestamp = timestamp or datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "value": self.value,
            "summary": self.summary,
            "tags": self.tags,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> MemoryEntry:
        return cls(
            key=d["key"],
            value=d["value"],
            summary=d.get("summary", ""),
            tags=d.get("tags", []),
            timestamp=d.get("timestamp", ""),
        )


class MemoryStore:
    """File-backed long-term memory with DeepSeek semantic search."""

    def __init__(self, llm: LLMProvider | None = None, directory: Path | None = None) -> None:
        self._dir = directory or MEMORY_DIR
        self._dir.mkdir(parents=True, exist_ok=True)
        self._llm = llm
        self._index_path = self._dir / "index.json"

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def save(self, key: str, value: str, tags: list[str] | None = None) -> MemoryEntry:
        """Save a memory entry. Overwrites if key exists."""
        key = self._sanitize_key(key)
        entry = MemoryEntry(
            key=key,
            value=value,
            tags=tags or [],
        )
        self._write_entry(entry)
        self._update_index(entry)
        return entry

    def get(self, key: str) -> MemoryEntry | None:
        """Get a memory entry by key."""
        key = self._sanitize_key(key)
        path = self._dir / f"{key}.json"
        if not path.exists():
            return None
        with open(path, encoding="utf-8") as f:
            return MemoryEntry.from_dict(json.load(f))

    def delete(self, key: str) -> bool:
        """Delete a memory entry. Returns True if found."""
        key = self._sanitize_key(key)
        path = self._dir / f"{key}.json"
        if path.exists():
            path.unlink()
            self._remove_from_index(key)
            return True
        return False

    def list(self) -> list[MemoryEntry]:
        """List all memory entries, newest first."""
        index = self._read_index()
        entries = []
        for item in index:
            entry = self.get(item["key"])
            if entry:
                entries.append(entry)
        return sorted(entries, key=lambda e: e.timestamp, reverse=True)

    def clear(self) -> None:
        """Delete all memories."""
        index = self._read_index()
        for item in index:
            (self._dir / f"{item['key']}.json").unlink(missing_ok=True)
        self._write_index([])

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    async def search(self, query: str, top_k: int = 5) -> list[MemoryEntry]:
        """Semantic search using DeepSeek ranking. Falls back to keyword match."""
        index = self._read_index()
        if not index:
            return []

        # Fast path: keyword filter first
        keywords = self._extract_keywords(query)
        candidates = [item for item in index if self._keyword_match(item, keywords)]

        if not candidates:
            candidates = index  # fall back to all

        if len(candidates) == 1:
            entry = self.get(candidates[0]["key"])
            return [entry] if entry else []

        # LLM ranking
        if self._llm and len(candidates) > 1:
            try:
                ranked = await self._llm_rank(query, candidates)
                entries = []
                for item in ranked[:top_k]:
                    entry = self.get(item["key"])
                    if entry:
                        entries.append(entry)
                return entries
            except Exception:
                pass  # fall through to keyword

        # Keyword fallback: return top_k by keyword score
        scored = [(self._keyword_score(item, keywords), item) for item in candidates]
        scored.sort(key=lambda x: x[0], reverse=True)
        entries = []
        for _, item in scored[:top_k]:
            entry = self.get(item["key"])
            if entry:
                entries.append(entry)
        return entries

    async def _llm_rank(self, query: str, candidates: list[dict]) -> list[dict]:
        """Use DeepSeek to rank memory candidates."""
        assert self._llm is not None

        memory_lines = []
        for i, item in enumerate(candidates):
            memory_lines.append(f"{i}: {item['summary']}")

        prompt = SEARCH_PROMPT.format(
            query=query,
            memories="\n".join(memory_lines),
        )

        result = await self._llm.complete(prompt, max_tokens=200)
        # Parse JSON array from response
        scores = self._parse_json_array(result)
        if not scores or len(scores) != len(candidates):
            return candidates  # fallback: return all

        # Sort by score descending
        ranked = sorted(
            zip(candidates, scores, strict=True),
            key=lambda x: x[1],
            reverse=True,
        )
        return [item for item, _ in ranked if _ > 10]  # filter irrelevant

    # ------------------------------------------------------------------
    # Auto-capture
    # ------------------------------------------------------------------

    async def auto_capture(self, context: str) -> list[MemoryEntry]:
        """Extract key facts from a conversation fragment and save them."""
        if not self._llm:
            return []

        try:
            prompt = EXTRACT_PROMPT.format(context=context[:4000])
            result = await self._llm.complete(prompt, max_tokens=500)
            facts = self._parse_json_array_of_objects(result)
        except Exception:
            return []

        entries = []
        for fact in facts:
            if not isinstance(fact, dict) or "key" not in fact or "value" not in fact:
                continue
            entry = self.save(
                key=fact["key"],
                value=fact["value"],
                tags=["auto"],
            )
            entries.append(entry)

        return entries

    def load_recent(self, n: int = 5) -> str:
        """Load the N most recent memories as context string for a new session."""
        entries = self.list()[:n]
        if not entries:
            return ""

        lines = ["[Long-term memory]"]
        for e in entries:
            lines.append(f"- {e.key}: {e.value}")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _sanitize_key(self, key: str) -> str:
        """Sanitize key to safe filename."""
        return re.sub(r"[^a-z0-9_-]", "-", key.lower())[:64]

    def _write_entry(self, entry: MemoryEntry) -> None:
        path = self._dir / f"{entry.key}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(entry.to_dict(), f, ensure_ascii=False, indent=2)

    def _read_index(self) -> list[dict[str, Any]]:
        if not self._index_path.exists():
            return []
        try:
            with open(self._index_path, encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return []

    def _write_index(self, data: list[dict[str, Any]]) -> None:
        with open(self._index_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _update_index(self, entry: MemoryEntry) -> None:
        index = self._read_index()
        # Remove existing entry with same key
        index = [item for item in index if item["key"] != entry.key]
        index.append(
            {
                "key": entry.key,
                "summary": entry.summary,
                "tags": entry.tags,
                "timestamp": entry.timestamp,
            }
        )
        self._write_index(index)

    def _remove_from_index(self, key: str) -> None:
        index = self._read_index()
        index = [item for item in index if item["key"] != key]
        self._write_index(index)

    @staticmethod
    def _extract_keywords(query: str) -> list[str]:
        """Extract meaningful keywords from query."""
        # Split on non-word chars, filter short words
        words = re.findall(r"\w+", query.lower())
        return [w for w in words if len(w) > 2]

    @staticmethod
    def _keyword_match(item: dict, keywords: list[str]) -> bool:
        """Check if item matches any keyword."""
        text = f"{item.get('key', '')} {item.get('summary', '')} {' '.join(item.get('tags', []))}"
        text_lower = text.lower()
        return any(kw in text_lower for kw in keywords)

    @staticmethod
    def _keyword_score(item: dict, keywords: list[str]) -> int:
        """Score an item by keyword match count."""
        text = f"{item.get('key', '')} {item.get('summary', '')} {' '.join(item.get('tags', []))}"
        text_lower = text.lower()
        return sum(1 for kw in keywords if kw in text_lower)

    @staticmethod
    def _parse_json_array(text: str) -> list[int]:
        """Parse a JSON array of integers from LLM response."""
        # Try to find JSON array in response
        match = re.search(r"\[[\d,\s]+\]", text)
        if not match:
            return []
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            return []

    @staticmethod
    def _parse_json_array_of_objects(text: str) -> list[dict]:
        """Parse a JSON array of objects from LLM response."""
        match = re.search(r"\[.*\]", text, re.DOTALL)
        if not match:
            return []
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            return []
