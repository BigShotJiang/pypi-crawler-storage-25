"""Self-correction — analyze errors and retry with adjusted approach."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from deepcraft.agent.llm import DeepSeekLLM
from deepcraft.agent.types import ChatMessage

CORRECTION_PROMPT = """你是一个调试专家。一个工具执行失败了，请分析错误原因并给出修正后的参数。

原始调用：
  工具: {tool_name}
  参数: {tool_args}
  错误: {error}

请输出 JSON：
```json
{{
  "analysis": "错误原因分析",
  "retry": true或false,
  "corrected_args": {{"参数名": "修正后的值"}} 或 {{}},
  "fix_description": "修正说明"
}}
```
如果错误无法通过修改参数解决（如网络问题、权限问题），retry 设为 false。"""


@dataclass
class CorrectionResult:
    """Result of error analysis and correction."""

    analysis: str
    retry: bool
    corrected_args: dict[str, Any] | None = None
    fix_description: str = ""


class SelfCorrector:
    """Analyze tool failures and suggest corrections."""

    MAX_RETRIES = 2  # Max retries per step

    def __init__(self, llm: DeepSeekLLM | None = None) -> None:
        self.llm = llm or DeepSeekLLM()
        self._retry_counts: dict[str, int] = {}

    async def analyze_error(
        self,
        tool_name: str,
        tool_args: dict[str, Any],
        error: str,
    ) -> CorrectionResult:
        """Analyze a tool failure and suggest a correction.

        Args:
            tool_name: The tool that failed.
            tool_args: The arguments that were used.
            error: The error message.

        Returns:
            CorrectionResult with analysis and optionally corrected args.
        """
        # Check retry limit
        key = f"{tool_name}:{str(sorted(tool_args.items()))}"
        count = self._retry_counts.get(key, 0)
        if count >= self.MAX_RETRIES:
            return CorrectionResult(
                analysis=f"已重试 {count} 次，放弃",
                retry=False,
            )
        self._retry_counts[key] = count + 1

        # Ask LLM to analyze
        prompt = CORRECTION_PROMPT.format(
            tool_name=tool_name,
            tool_args=str(tool_args),
            error=error[:500],
        )

        messages = [
            ChatMessage(role="system", content=prompt),
            ChatMessage(role="user", content="请分析并建议修正"),
        ]

        response = ""
        async for chunk in self.llm.chat(messages):
            if chunk.delta and chunk.delta.content:
                response += chunk.delta.content

        # Parse response
        import json
        import re

        match = re.search(r"```(?:json)?\s*\n(.*?)\n```", response, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(1))
                return CorrectionResult(
                    analysis=data.get("analysis", ""),
                    retry=data.get("retry", False),
                    corrected_args=data.get("corrected_args"),
                    fix_description=data.get("fix_description", ""),
                )
            except json.JSONDecodeError:
                pass

        # Fallback: don't retry
        return CorrectionResult(
            analysis=response[:200] if response else "无法分析错误",
            retry=False,
        )

    def reset_retries(self) -> None:
        """Reset retry counters for a new task."""
        self._retry_counts.clear()

    async def close(self) -> None:
        await self.llm.close()
