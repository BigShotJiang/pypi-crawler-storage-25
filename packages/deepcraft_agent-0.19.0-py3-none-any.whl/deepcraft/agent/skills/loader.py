"""Skills system — domain knowledge encoding with trigger-based activation."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class Skill:
    """A skill encodes domain expertise: identity, workflow, standards.

    Skills are activated by trigger keyword matching and injected into
    the LLM context as specialized guidance.
    """

    name: str
    description: str
    triggers: list[str] = field(default_factory=list)
    content: str = ""  # Markdown body (the actual guidance)
    allowed_tools: list[str] | None = None  # Restrict tool access

    def matches(self, user_input: str) -> bool:
        """Check if this skill's triggers match the user input."""
        if not self.triggers:
            return False
        lower_input = user_input.lower()
        return any(trigger.lower() in lower_input for trigger in self.triggers)


class SkillLoader:
    """Load skills from YAML frontmatter + Markdown files."""

    FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)

    @staticmethod
    def load_from_dir(directory: str | Path) -> list[Skill]:
        """Scan a directory for .md skill files and parse them.

        Args:
            directory: Path to the skills directory.

        Returns:
            List of Skill instances.
        """
        skills: list[Skill] = []
        dir_path = Path(directory)

        if not dir_path.exists():
            return skills

        for md_file in sorted(dir_path.rglob("*.md")):
            try:
                skill = SkillLoader._parse_file(md_file)
                if skill:
                    skills.append(skill)
            except Exception:
                continue

        return skills

    @staticmethod
    def _parse_file(filepath: Path) -> Skill | None:
        """Parse a single skill file with YAML frontmatter."""
        text = filepath.read_text(encoding="utf-8")
        match = SkillLoader.FRONTMATTER_RE.match(text)
        if not match:
            return None

        # Simple YAML parser (avoid external dependency for MVP)
        frontmatter = match.group(1)
        body = text[match.end() :].strip()

        metadata: dict[str, Any] = {}
        for line in frontmatter.split("\n"):
            line = line.strip()
            if ":" not in line:
                continue
            key, _, value = line.partition(":")
            key = key.strip()
            value = value.strip()

            if value.startswith("[") and value.endswith("]"):
                # List value: [a, b, c]
                value = [v.strip().strip("\"'") for v in value[1:-1].split(",") if v.strip()]
            elif value in ("true", "false"):
                value = value == "true"
            else:
                value = value.strip("\"'")

            metadata[key] = value

        if "name" not in metadata:
            return None

        return Skill(
            name=str(metadata.get("name", "")),
            description=str(metadata.get("description", "")),
            triggers=list(metadata.get("triggers", [])),
            content=body,
            allowed_tools=list(metadata.get("allowed-tools", [])) or None,
        )

    @staticmethod
    def match_skills(
        skills: list[Skill],
        user_input: str,
        require_trigger: bool = True,
    ) -> list[Skill]:
        """Find skills whose triggers match the user input.

        Args:
            skills: All available skills.
            user_input: The user's message to match against.
            require_trigger: If True, only match skills with triggers.
                             If False, return all skills (for discovery).

        Returns:
            Matching skills sorted by trigger match quality (longest trigger first).
        """
        if not require_trigger:
            return list(skills)

        matched: list[tuple[int, Skill]] = []
        lower_input = user_input.lower()

        for skill in skills:
            for trigger in skill.triggers:
                if trigger.lower() in lower_input:
                    matched.append((len(trigger), skill))
                    break  # One match is enough, prioritize longest trigger

        # Sort by trigger length descending (more specific match wins)
        matched.sort(key=lambda x: x[0], reverse=True)
        return [skill for _, skill in matched]

    @staticmethod
    def format_skills_context(skills: list[Skill]) -> str:
        """Format matched skills as injectable LLM context.

        Args:
            skills: Skills to format into context.

        Returns:
            Formatted context string for LLM system prompt injection.
        """
        if not skills:
            return ""

        parts: list[str] = ["\n## 已激活的专业技能 (Active Skills)\n"]

        for i, skill in enumerate(skills, 1):
            parts.append(f"### 技能 {i}: {skill.name}")
            if skill.description:
                parts.append(f"**描述**: {skill.description}")
            if skill.allowed_tools:
                parts.append(f"**可用工具**: {', '.join(skill.allowed_tools)}")
            parts.append("")
            parts.append(skill.content)
            parts.append("")

        return "\n".join(parts)
