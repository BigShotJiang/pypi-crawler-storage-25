"""Smart Symbol Navigation — go-to-def, find-refs, rename, hover.

Pure Python AST + codebase index. Zero new dependencies.
Extends v0.10 codebase index with cross-reference tracking.

Architecture:
    SymbolIndex (extends CodebaseIndex)
    ├── parse_all() → symbol_defs + symbol_refs
    ├── go_to_definition(name) → [Location]
    ├── find_references(name) → [Location]
    ├── rename_symbol(old, new) → RefactorPlan
    └── hover(file, line) → docstring + signature
"""

from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class SymbolLocation:
    """A symbol's location in source code."""

    file: str  # Relative path
    line: int
    col: int
    symbol: str  # The symbol name
    kind: str  # "def", "class", "import", "call", "attr", "assign"


@dataclass
class HoverInfo:
    """Information shown on hover over a symbol."""

    symbol: str
    kind: str
    signature: str = ""  # def foo(x: int) -> str
    docstring: str = ""
    file: str = ""
    line: int = 0


@dataclass
class RenamePlan:
    """Plan for renaming a symbol across the codebase."""

    old_name: str
    new_name: str
    definition: SymbolLocation | None  # Where it's defined
    references: list[SymbolLocation]  # All usages
    changes: list[dict[str, Any]]  # Ready for AtomicRefactor

    @property
    def total_locations(self) -> int:
        return (1 if self.definition else 0) + len(self.references)


class SymbolIndex:
    """Codebase-wide symbol index with cross-reference tracking.

    Builds on top of the existing codebase index (v0.10),
    adding per-symbol reference tracking.

    Usage:
        idx = SymbolIndex()
        idx.build(".")  # Index current directory
        locs = idx.go_to_definition("Agent")
        refs = idx.find_references("Agent.run")
        plan = idx.rename("old_func", "new_func")
    """

    def __init__(self) -> None:
        # Symbol → definition location(s)
        self._definitions: dict[str, list[SymbolLocation]] = {}
        # Symbol → all reference locations
        self._references: dict[str, list[SymbolLocation]] = {}
        # File → AST cache
        self._file_cache: dict[str, ast.AST] = {}
        # File → source text cache
        self._source_cache: dict[str, str] = {}
        self._total_files = 0
        self._total_symbols = 0

    # ------------------------------------------------------------------
    # Build
    # ------------------------------------------------------------------

    def build(self, root: str | Path) -> None:
        """Index all Python files under root."""
        root_path = Path(root).resolve()
        py_files = list(root_path.rglob("*.py"))

        # Phase 1: Collect all definitions
        for py_file in py_files:
            rel = str(py_file.relative_to(root_path))
            source = py_file.read_text(encoding="utf-8")
            self._source_cache[rel] = source
            try:
                tree = ast.parse(source, filename=rel)
                self._file_cache[rel] = tree
                self._collect_definitions(tree, rel)
            except SyntaxError:
                continue

        # Phase 2: Collect all references
        for py_file in py_files:
            rel = str(py_file.relative_to(root_path))
            if rel in self._file_cache:
                self._collect_references(self._file_cache[rel], rel)

        self._total_files = len(py_files)
        self._total_symbols = len(self._definitions)

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def go_to_definition(self, symbol: str) -> list[SymbolLocation]:
        """Find where a symbol is defined.

        Args:
            symbol: Symbol name (e.g., "Agent", "loop.run").

        Returns:
            List of definition locations (empty if not found).
        """
        # Try exact match
        if symbol in self._definitions:
            return self._definitions[symbol]

        # Try partial match (e.g., "Agent" matches "deepcraft.agent.loop.Agent")
        results: list[SymbolLocation] = []
        for name, locs in self._definitions.items():
            if name.endswith(f".{symbol}") or name == symbol:
                results.extend(locs)
        return results

    def find_references(self, symbol: str) -> list[SymbolLocation]:
        """Find all references/usages of a symbol.

        Args:
            symbol: Symbol name to search for.

        Returns:
            List of reference locations.
        """
        return self._references.get(symbol, [])

    def hover(self, file: str, line: int, col: int = 0) -> HoverInfo | None:
        """Get hover information for a symbol at a given location.

        Args:
            file: Relative file path.
            line: 1-indexed line number.
            col: 0-indexed column (approximate).

        Returns:
            HoverInfo or None if no symbol found.
        """
        if file not in self._source_cache:
            return None

        source = self._source_cache[file]
        source_lines = source.split("\n")
        if line < 1 or line > len(source_lines):
            return None

        # Find the symbol at or before the given location
        for name, locs in self._definitions.items():
            for loc in locs:
                if loc.file == file and loc.line <= line <= loc.line + 5:
                    return self._build_hover(name, loc)

        return None

    def rename_symbol(self, old_name: str, new_name: str) -> RenamePlan | None:
        """Generate an atomic refactoring plan to rename a symbol.

        Args:
            old_name: Current symbol name.
            new_name: New name for the symbol.

        Returns:
            RenamePlan with all changes, or None if symbol not found.
        """
        definition = None
        if old_name in self._definitions:
            definition = self._definitions[old_name][0]

        references = self._references.get(old_name, [])

        if not definition and not references:
            return None

        changes: list[dict[str, Any]] = []

        # Gather unique files to modify
        files_with_changes: set[str] = set()
        if definition:
            files_with_changes.add(definition.file)
        for ref in references:
            files_with_changes.add(ref.file)

        # Build search-replace for each file
        for file in files_with_changes:
            changes.append(
                {
                    "path": file,
                    "old_string": old_name,
                    "new_string": new_name,
                    "replace_all": True,  # Replace all occurrences in file
                }
            )

        return RenamePlan(
            old_name=old_name,
            new_name=new_name,
            definition=definition,
            references=references,
            changes=changes,
        )

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def list_symbols(self, prefix: str = "") -> list[str]:
        """List all known symbols, optionally filtered by prefix."""
        if prefix:
            return [s for s in self._definitions if s.startswith(prefix)]
        return sorted(self._definitions.keys())

    def stats(self) -> dict[str, int]:
        """Return indexing statistics."""
        return {
            "files": self._total_files,
            "symbols": self._total_symbols,
            "definitions": sum(len(v) for v in self._definitions.values()),
            "references": sum(len(v) for v in self._references.values()),
        }

    # ------------------------------------------------------------------
    # Internal: AST analysis
    # ------------------------------------------------------------------

    def _collect_definitions(self, tree: ast.AST, rel: str) -> None:
        """Collect symbol definitions from an AST."""
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                self._add_def(node.name, node.lineno, node.col_offset, rel, "def")
            elif isinstance(node, ast.AsyncFunctionDef):
                self._add_def(node.name, node.lineno, node.col_offset, rel, "async_def")
            elif isinstance(node, ast.ClassDef):
                self._add_def(node.name, node.lineno, node.col_offset, rel, "class")
                # Methods inside class
                for child in node.body:
                    if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        full = f"{node.name}.{child.name}"
                        self._add_def(full, child.lineno, child.col_offset, rel, "method")

    def _collect_references(self, tree: ast.AST, rel: str) -> None:
        """Collect symbol references from an AST."""
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                self._add_ref(node.id, node.lineno, node.col_offset, rel, "ref")
            elif isinstance(node, ast.Attribute) and isinstance(node.ctx, ast.Load):
                # obj.method call
                if isinstance(node.value, ast.Name):
                    full = f"{node.value.id}.{node.attr}"
                    self._add_ref(full, node.lineno, node.col_offset, rel, "call")
                else:
                    self._add_ref(node.attr, node.lineno, node.col_offset, rel, "attr")
            elif isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name):
                    self._add_ref(node.func.id, node.lineno, node.col_offset, rel, "call")
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    self._add_ref(alias.name, node.lineno, node.col_offset, rel, "import")
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    name = alias.asname or alias.name
                    self._add_ref(name, node.lineno, node.col_offset, rel, "import")

    def _add_def(self, name: str, line: int, col: int, file: str, kind: str) -> None:
        """Record a symbol definition."""
        loc = SymbolLocation(file=file, line=line, col=col, symbol=name, kind=kind)
        if name not in self._definitions:
            self._definitions[name] = []
        self._definitions[name].append(loc)

    def _add_ref(self, name: str, line: int, col: int, file: str, kind: str) -> None:
        """Record a symbol reference."""
        loc = SymbolLocation(file=file, line=line, col=col, symbol=name, kind=kind)
        if name not in self._references:
            self._references[name] = []
        self._references[name].append(loc)

    def _build_hover(self, name: str, loc: SymbolLocation) -> HoverInfo:
        """Build hover information for a symbol."""
        source = self._source_cache.get(loc.file, "")
        if not source:
            return HoverInfo(symbol=name, kind=loc.kind, file=loc.file, line=loc.line)

        # Try to find the function/class definition and its docstring
        try:
            tree = ast.parse(source, filename=loc.file)
            for node in ast.walk(tree):
                if (
                    isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                    and node.name == name
                    and node.lineno == loc.line
                ):
                    docstring = ast.get_docstring(node) or ""
                    sig = self._build_signature(node)
                    return HoverInfo(
                        symbol=name,
                        kind=loc.kind,
                        signature=sig,
                        docstring=docstring,
                        file=loc.file,
                        line=loc.line,
                    )
        except SyntaxError:
            pass

        return HoverInfo(symbol=name, kind=loc.kind, file=loc.file, line=loc.line)

    @staticmethod
    def _build_signature(node: ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef) -> str:
        """Build a human-readable signature from AST node."""
        if isinstance(node, ast.ClassDef):
            return f"class {node.name}"

        prefix = "async " if isinstance(node, ast.AsyncFunctionDef) else ""
        params: list[str] = []
        for arg in node.args.args:
            p = arg.arg
            if arg.annotation:
                p += f": {ast.unparse(arg.annotation)}"
            params.append(p)

        returns = f" -> {ast.unparse(node.returns)}" if node.returns else ""
        return f"{prefix}def {node.name}({', '.join(params)}){returns}"
