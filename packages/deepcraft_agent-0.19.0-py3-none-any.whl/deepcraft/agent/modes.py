"""Agent mode selector — choose the best strategy for each task."""

from __future__ import annotations

from enum import StrEnum


class AgentMode(StrEnum):
    REACT = "react"  # Single turn, think-act-observe
    PLAN_EXECUTE = "plan_execute"  # Plan first, then execute step by step
    SUBAGENT = "subagent"  # Delegate to parallel sub-agents
    AUTO = "auto"  # Let the system decide


# Keywords that suggest complex multi-step tasks
PLAN_KEYWORDS = [
    "审查",
    "分析",
    "重构",
    "生成报告",
    "总结",
    "review",
    "analyze",
    "refactor",
    "audit",
    "检查所有",
    "扫描",
    "评估",
    "对比",
]

# Keywords that suggest parallel subtasks
PARALLEL_KEYWORDS = [
    "同时",
    "分别",
    "并行",
    "一边",
    "各自",
    "parallel",
    "concurrently",
    "both",
]


class ModeSelector:
    """Select the best agent mode based on task characteristics."""

    @staticmethod
    def select(user_input: str, prefer: AgentMode = AgentMode.AUTO) -> AgentMode:
        """Analyze user input and select the optimal agent mode.

        Args:
            user_input: The user's message.
            prefer: Preferred mode override.

        Returns:
            The selected AgentMode.
        """
        if prefer != AgentMode.AUTO:
            return prefer

        text_lower = user_input.lower()

        # Rule 1: Parallel keywords → SubAgent
        if any(kw in text_lower for kw in PARALLEL_KEYWORDS):
            return AgentMode.SUBAGENT

        # Rule 2: Complex task keywords → Plan-Execute
        if any(kw in text_lower for kw in PLAN_KEYWORDS):
            return AgentMode.PLAN_EXECUTE

        # Rule 3: Simple question → ReAct
        # Default: ReAct
        return AgentMode.REACT
