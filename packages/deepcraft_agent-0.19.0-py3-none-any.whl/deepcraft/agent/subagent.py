"""Sub-agent delegation — spawn child agents for parallel subtasks."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

from rich.console import Console

from deepcraft.agent.llm import DeepSeekLLM
from deepcraft.agent.tools.base import ToolRegistry
from deepcraft.agent.types import ChatMessage

console = Console()


@dataclass
class SubTask:
    """A task to be delegated to a sub-agent."""

    description: str
    context: str = ""
    allowed_tools: list[str] | None = None  # None = all tools


@dataclass
class SubResult:
    """Result from a sub-agent."""

    task: str
    output: str
    success: bool


SUBAGENT_PROMPT = """你是一个专门的子代理，负责完成一个具体子任务。

任务：{task}

可用工具：
{tools}

请完成任务并返回结果。直接输出结果，不需要额外对话。"""


class SubAgent:
    """A lightweight agent that executes a single subtask."""

    def __init__(
        self,
        llm: DeepSeekLLM | None = None,
        tools: ToolRegistry | None = None,
    ) -> None:
        self.llm = llm or DeepSeekLLM()
        self.tools = tools or ToolRegistry()

    async def execute(
        self,
        task: str,
        context: str = "",
        max_steps: int = 5,
    ) -> SubResult:
        """Execute a single subtask and return the result.

        Args:
            task: The subtask description.
            context: Additional context for the subtask.
            max_steps: Maximum tool-calling steps.

        Returns:
            SubResult with output and success flag.
        """
        tool_list = "\n".join(f"- {t.name}: {t.description}" for t in self.tools.list_definitions())

        system = SUBAGENT_PROMPT.format(task=task, tools=tool_list)
        messages = [
            ChatMessage(role="system", content=system),
        ]
        if context:
            messages.append(ChatMessage(role="user", content=f"上下文：{context}"))
        messages.append(ChatMessage(role="user", content="请完成此任务。"))

        result_text = ""
        tool_defs = self.tools.list_definitions()

        for _step in range(max_steps):
            tool_calls_buffer: dict[int, dict[str, Any]] = {}
            content_parts: list[str] = []

            async for chunk in self.llm.chat(messages, tools=tool_defs or None):
                if chunk.delta and chunk.delta.content:
                    content_parts.append(chunk.delta.content)
                if chunk.delta and chunk.delta.tool_calls:
                    for tc in chunk.delta.tool_calls:
                        idx = len(tool_calls_buffer)
                        if tc["id"]:
                            tool_calls_buffer[idx] = tc
                        elif idx in tool_calls_buffer:
                            tc_args = tc["function"].get("arguments", "")
                            tool_calls_buffer[idx]["function"]["arguments"] += tc_args

            result_text = "".join(content_parts)

            if not tool_calls_buffer:
                break

            # Execute tools
            for tc in tool_calls_buffer.values():
                import json as _json

                tool_name = tc["function"]["name"]
                tool_id = tc["id"]
                try:
                    raw_args = tc["function"]["arguments"]
                    args = _json.loads(raw_args) if raw_args else {}
                except _json.JSONDecodeError:
                    args = {}

                args_str = _json.dumps(args, ensure_ascii=False)
                console.print(f"    🤖 {tool_name}({args_str})", style="dim")
                tool_result = await self.tools.execute(tool_name, args)

                # Add assistant message with tool call
                messages.append(
                    ChatMessage(
                        role="assistant",
                        content=result_text or None,
                        tool_calls=[
                            {
                                "id": tool_id,
                                "type": "function",
                                "function": {"name": tool_name, "arguments": tc["function"]["arguments"]},
                            }
                        ],
                    )
                )
                # Add tool result
                messages.append(
                    ChatMessage(
                        role="tool",
                        content=tool_result.content,
                        tool_call_id=tool_id,
                    )
                )

        return SubResult(
            task=task,
            output=result_text or "(no output)",
            success=True,
        )

    async def close(self) -> None:
        await self.llm.close()


class Delegator:
    """Manage parallel execution of subtasks via sub-agents."""

    def __init__(
        self,
        llm: DeepSeekLLM | None = None,
        tools: ToolRegistry | None = None,
    ) -> None:
        self.llm = llm or DeepSeekLLM()
        self.tools = tools or ToolRegistry()

    async def delegate(
        self,
        subtasks: list[SubTask],
        max_concurrent: int = 3,
    ) -> list[SubResult]:
        """Execute multiple subtasks in parallel.

        Args:
            subtasks: List of subtasks to delegate.
            max_concurrent: Maximum concurrent sub-agents.

        Returns:
            List of SubResult, one per subtask.
        """
        semaphore = asyncio.Semaphore(max_concurrent)

        async def _run_one(task: SubTask) -> SubResult:
            async with semaphore:
                # Each sub-agent gets its own LLM client and a copy of tools
                sub = SubAgent(
                    llm=DeepSeekLLM(),
                    tools=self.tools,  # Share tool registry (stateless)
                )
                try:
                    console.print(f"  🚀 子代理启动: {task.description[:60]}", style="cyan")
                    result = await sub.execute(
                        task=task.description,
                        context=task.context,
                    )
                    console.print(f"  ✅ 子代理完成: {task.description[:40]}", style="green")
                    return result
                except Exception as e:
                    console.print(f"  ❌ 子代理失败: {e}", style="red")
                    return SubResult(task=task.description, output=str(e), success=False)
                finally:
                    await sub.close()

        results = await asyncio.gather(*[_run_one(t) for t in subtasks])
        return list(results)

    async def close(self) -> None:
        await self.llm.close()
