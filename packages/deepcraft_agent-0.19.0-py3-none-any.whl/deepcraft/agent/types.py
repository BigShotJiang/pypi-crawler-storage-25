"""Shared type definitions for the agent system."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class Role(StrEnum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


@dataclass
class ChatMessage:
    role: str
    content: str | None = None
    tool_calls: list[dict[str, Any]] | None = None
    tool_call_id: str | None = None
    name: str | None = None

    def model_dump(self, exclude_none: bool = False) -> dict[str, Any]:
        d: dict[str, Any] = {"role": self.role}
        if self.content is not None:
            d["content"] = self.content
        if self.tool_calls is not None:
            d["tool_calls"] = self.tool_calls
        if self.tool_call_id is not None:
            d["tool_call_id"] = self.tool_call_id
        if self.name is not None:
            d["name"] = self.name
        return d


@dataclass
class ToolParameter:
    type: str
    description: str
    enum: list[str] | None = None


@dataclass
class ToolDefinition:
    name: str
    description: str
    parameters: dict[str, Any] = field(default_factory=dict)
    required: list[str] | None = None  # None = all params required

    def model_dump(self, exclude_none: bool = False) -> dict[str, Any]:
        req = self.required if self.required is not None else list(self.parameters.keys())
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": self.parameters,
                    "required": req,
                },
            },
        }


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any] = field(default_factory=dict)


@dataclass
class ToolResult:
    tool_call_id: str
    content: str
    is_error: bool = False


@dataclass
class StreamDelta:
    content: str = ""
    tool_calls: list[dict[str, Any]] | None = None


@dataclass
class LLMResponse:
    delta: StreamDelta | None = None
    finish_reason: str | None = None

    @classmethod
    def from_chunk(cls, data: str) -> LLMResponse | None:
        """Parse an SSE chunk into an LLMResponse."""
        import json

        try:
            chunk = json.loads(data)
        except json.JSONDecodeError:
            return None

        choice = chunk.get("choices", [{}])[0]
        finish = choice.get("finish_reason")
        delta_raw = choice.get("delta", {})

        delta = StreamDelta(
            content=delta_raw.get("content", ""),
            tool_calls=[
                {
                    "id": tc.get("id", ""),
                    "type": "function",
                    "index": tc.get("index"),  # Preserve for streaming reassembly
                    "function": {
                        "name": tc.get("function", {}).get("name", ""),
                        "arguments": tc.get("function", {}).get("arguments", ""),
                    },
                }
                for tc in delta_raw.get("tool_calls", [])
            ]
            or None,
        )

        return cls(delta=delta, finish_reason=finish)
