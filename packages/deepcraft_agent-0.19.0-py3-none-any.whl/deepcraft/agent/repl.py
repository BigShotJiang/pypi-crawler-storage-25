"""REPL and single-run entry points for DeepCraft."""

from __future__ import annotations

import asyncio
import os
import shlex
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

from deepcraft import __version__
from deepcraft.agent.autonomous import AutonomousRunner
from deepcraft.agent.code_index import build_index as build_code_index
from deepcraft.agent.context import CompressionStrategy, ContextManager
from deepcraft.agent.diff_view import DiffViewer
from deepcraft.agent.knowledge import KnowledgeBase
from deepcraft.agent.loop import Agent
from deepcraft.agent.mcp.client import MCPManager
from deepcraft.agent.mesh import AgentMesh, AgentRole
from deepcraft.agent.modes import AgentMode
from deepcraft.agent.pr_workflow import PRWorkflow
from deepcraft.agent.refactor import AtomicRefactor, FileChange, RefactorPlan
from deepcraft.agent.sandbox import DockerSandbox, SandboxMode
from deepcraft.agent.symbol_index import SymbolIndex
from deepcraft.agent.test_gen import TestGenerator
from deepcraft.agent.tools.base import ToolRegistry
from deepcraft.agent.tools.checkpoint import CheckpointManager
from deepcraft.agent.tools.diff_view import DiffPreviewTool, DiffTool
from deepcraft.agent.tools.file import ReadFileTool, SearchFilesTool, WriteFileTool
from deepcraft.agent.tools.git_tool import GitTool
from deepcraft.agent.tools.knowledge import KnowledgeAddTool, KnowledgeSearchTool
from deepcraft.agent.tools.pr_tools import (
    CreatePRTool,
    ListPRsTool,
    MergePRTool,
    PRStatusTool,
)
from deepcraft.agent.tools.refactor import RefactorTool
from deepcraft.agent.tools.sandbox import SandboxTool
from deepcraft.agent.tools.search_replace import SearchReplaceTool
from deepcraft.agent.tools.symbol_nav import FindReferencesTool, GotoDefinitionTool, RenameSymbolTool
from deepcraft.agent.tools.terminal import TerminalTool
from deepcraft.agent.tools.test_gen import TestGenTool
from deepcraft.agent.tools.web_search import WebFetchTool, WebSearchTool
from deepcraft.config import COMPRESSION_STRATEGY, PROVIDER, _get_provider_config, parse_mcp_servers
from deepcraft.memory import MemoryStore
from deepcraft.providers import create_provider
from deepcraft.session import SessionRecorder

console = Console()


def _create_agent() -> Agent:
    """Create a fully configured agent with default tools."""
    tools = ToolRegistry()
    checkpoint = CheckpointManager(max_snapshots=30)

    # File tools with checkpoint
    write_tool = WriteFileTool()
    write_tool.checkpoint_manager = checkpoint
    search_replace_tool = SearchReplaceTool()
    search_replace_tool.checkpoint_manager = checkpoint

    tools.register(ReadFileTool())
    tools.register(write_tool)
    tools.register(SearchFilesTool())
    tools.register(TerminalTool())
    tools.register(GitTool())
    tools.register(WebSearchTool())
    tools.register(WebFetchTool())
    tools.register(search_replace_tool)
    tools.register(DiffTool())
    tools.register(DiffPreviewTool())

    provider_config = _get_provider_config(PROVIDER)
    llm = create_provider(PROVIDER, provider_config)
    ctx = ContextManager(
        llm=llm,
        strategy=CompressionStrategy(COMPRESSION_STRATEGY),
    )
    return Agent(
        llm=llm,
        tools=tools,
        context=ctx,
    )


def _create_agent_with_checkpoint() -> tuple[Agent, CheckpointManager]:
    """Create agent + checkpoint manager (exposed for slash commands)."""
    agent = _create_agent()
    # Find the checkpoint manager from one of the file tools
    write_tool = agent.tools.get("write_file")
    if write_tool and hasattr(write_tool, "checkpoint_manager"):
        return agent, write_tool.checkpoint_manager
    return agent, CheckpointManager()


async def _connect_mcp_servers(agent: Agent, mcp_manager: MCPManager) -> None:
    """Connect all configured MCP servers and register their tools."""
    servers = parse_mcp_servers()
    if not servers:
        return

    console.print("\n[dim]Connecting MCP servers...[/]")
    for srv in servers:
        name = srv["name"]
        try:
            if "url" in srv:
                headers = srv.get("headers")
                await mcp_manager.connect_http_server(name, srv["url"], headers=headers)
                console.print(f"  ✅ [green]{name}[/] (HTTP) connected")
            elif "command" in srv:
                argv = shlex.split(srv["command"])
                await mcp_manager.connect_server(name, argv)
                console.print(f"  ✅ [green]{name}[/] (stdio) connected")
            else:
                console.print(f"  ⚠️  [yellow]{name}[/] — missing command or url")
        except Exception as e:
            console.print(f"  ❌ [red]{name}[/] — {e}")


def run_repl() -> None:
    """Start the interactive REPL loop."""
    console.print(
        Panel.fit(
            f"DeepCraft v{__version__} — DeepSeek-powered AI coding agent\nType /help for commands, /quit to exit",
            title="DeepCraft",
            border_style="blue",
        )
    )

    agent = _create_agent()
    mcp_manager = MCPManager(agent.tools)
    current_mode = AgentMode.AUTO
    recorder = SessionRecorder()
    memory = MemoryStore(llm=agent.llm)

    # Checkpoint manager
    write_tool = agent.tools.get("write_file")
    checkpoint_mgr = (
        write_tool.checkpoint_manager
        if write_tool and hasattr(write_tool, "checkpoint_manager")
        else CheckpointManager()
    )

    # Agent Mesh: multi-agent orchestration
    mesh = AgentMesh(provider_factory=lambda: create_provider(PROVIDER, _get_provider_config(PROVIDER)))
    mesh._router_llm = agent.llm  # Use main agent's LLM for routing
    mesh.setup_defaults()

    # Sandbox: Docker container for isolated command execution
    sandbox = DockerSandbox()
    sandbox_tool = SandboxTool(sandbox)
    agent.tools.register(sandbox_tool)

    # Knowledge Base: RAG semantic search
    kb = KnowledgeBase()
    if kb.load():
        kbs = kb.stats()
        ndocs = kbs["documents"]
        nchunks = kbs["chunks"]
        console.print(f"[dim]KB loaded: {ndocs} docs, {nchunks} chunks[/]")
    else:
        console.print("[dim]KB: empty (use /knowledge add <path> to index)[/]")
    agent.tools.register(KnowledgeSearchTool(kb))
    agent.tools.register(KnowledgeAddTool(kb))

    # Test Generator: auto-generate pytest skeletons
    test_gen = TestGenerator()
    agent.tools.register(TestGenTool(test_gen))
    console.print("[dim]Tools: test_gen registered[/]")

    # Atomic Refactor: multi-file changes with rollback
    refactor = AtomicRefactor(checkpoint_mgr)
    agent.tools.register(RefactorTool(refactor))
    console.print("[dim]Tools: refactor registered[/]")

    # Symbol Index: go-to-def, find-refs, rename
    sym_index = SymbolIndex()
    sym_index.build(os.getcwd())
    agent.tools.register(GotoDefinitionTool(sym_index))
    agent.tools.register(FindReferencesTool(sym_index))
    agent.tools.register(RenameSymbolTool(sym_index))
    st = sym_index.stats()
    ns = st["symbols"]
    nr = st["references"]
    console.print(f"[dim]Symbols indexed: {ns} symbols, {nr} refs[/]")

    # Diff Viewer: visual diffs with Rich rendering
    diff_viewer = DiffViewer(context_lines=3, max_width=120)
    # Inject into existing diff tools
    dt = agent.tools.get("diff_view")
    if dt and hasattr(dt, "_viewer"):
        dt._viewer = diff_viewer
    dpt = agent.tools.get("diff_preview")
    if dpt and hasattr(dpt, "_viewer"):
        dpt._viewer = diff_viewer
    console.print("[dim]Tools: diff_view, diff_preview registered[/]")

    # PR Workflow: create/list/status/merge GitHub PRs
    try:
        prwf = PRWorkflow.auto()
        agent.tools.register(CreatePRTool(prwf))
        agent.tools.register(ListPRsTool(prwf))
        agent.tools.register(PRStatusTool(prwf))
        agent.tools.register(MergePRTool(prwf))
        console.print(f"[dim]PR Workflow: {prwf.owner}/{prwf.repo}[/]")
    except Exception as e:
        prwf = None
        console.print(f"[dim]PR Workflow: not available ({e})[/]")

    # Load recent memories into context on startup
    recent = memory.load_recent(5)
    if recent:
        agent.ctx.add_message("user", recent)

    # Build codebase index and inject into fixed context layer
    try:
        code_index = build_code_index(os.getcwd(), cache=True)
        index_ctx = code_index.to_context(max_items=60)
        if len(index_ctx) > 100:
            agent.ctx.set_codebase_index(index_ctx)
            console.print(
                f"[dim]Codebase indexed: {code_index.total_files} files, "
                f"{code_index.total_functions} functions, "
                f"{code_index.total_classes} classes[/]"
            )
    except Exception:
        code_index = None

    async def repl() -> None:
        nonlocal current_mode

        # Connect MCP servers on startup
        await _connect_mcp_servers(agent, mcp_manager)

        try:
            while True:
                try:
                    user_input = Prompt.ask("\n[bold green]▸[/]")
                except (KeyboardInterrupt, EOFError):
                    console.print("\nGoodbye!")
                    break

                if not user_input.strip():
                    continue

                # Commands
                if user_input.startswith("/"):
                    cmd = user_input[1:].strip().lower()
                    if cmd in ("quit", "exit", "q"):
                        console.print("Goodbye!")
                        if sandbox:
                            sandbox.cleanup()
                        kb.save()
                        break
                    elif cmd == "help":
                        console.print(
                            "Commands:\n"
                            "  /quit, /exit, /q — Exit DeepCraft\n"
                            "  /help — Show this help\n"
                            "  /clear — Clear conversation history\n"
                            "  /status — Show token usage and tool count\n"
                            "  /cache — Show prompt cache layers / token budget\n"
                            "  /sandbox run <cmd> — Run command in Docker sandbox\n"
                            "  /sandbox status — Show sandbox status\n"
                            "  /sandbox mode <mode> — Set sandbox mode\n"
                            "  /knowledge — Show knowledge base stats\n"
                            "  /knowledge add <path> — Add doc to knowledge base\n"
                            "  /knowledge search <query> — Search knowledge base\n"
                            "  /knowledge clear — Clear knowledge base\n"
                            "  /test-gen <path> — Auto-generate pytest tests\n"
                            "  /auto <task> — Autonomous plan→execute→report\n"
                            "  /refactor <desc> — Multi-file atomic refactor\n"
                            "  /def <symbol> — Go to symbol definition\n"
                            "  /refs <symbol> — Find all references\n"
                            "  /rename <old> <new> — Rename symbol across codebase\n"
                            "  /hover <file:line> — Show symbol info\n"
                            "  /diff <file> — Visual diff (git) or compare two files\n"
                            "  /diff-side <a> <b> — Side-by-side diff\n"
                            "  /diff-review — Show all uncommitted changes\n"
                            "  /pr create <title> — Create PR from current branch\n"
                            "  /pr list — List open PRs\n"
                            "  /pr status [N] — Check PR CI status\n"
                            "  /pr merge [N] — Merge a PR\n"
                            "  /export md|json [path] — Export conversation\n"
                            "  /record start — Start session recording\n"
                            "  /record stop — Stop session recording\n"
                            "  /record status — Show recording status\n"
                            "  /replay <path> — Replay a recorded session\n"
                            "  /memory save <key> <value> — Save a memory\n"
                            "  /memory search <query> — Search memories\n"
                            "  /memory list — List all memories\n"
                            "  /memory clear — Delete all memories\n"
                            "  /index — Show codebase index\n"
                            "  /agent list — List agent nodes\n"
                            "  /agent create <name> <role> — Create agent node\n"
                            "  /agent run <name> <task> — Run task on a node\n"
                            "  /mesh route <task> — Auto-route to best agent\n"
                            "  /mesh pipeline a,b <task> — Chain agents (a→b)\n"
                            "  /mesh broadcast a,b <task> — Parallel execute\n"
                            "  /mode [react|plan|sub|auto] — Switch agent mode\\n"
                            "  /checkpoint — Manually save file snapshots\\n"
                            "  /rollback [N] — Restore files to snapshot N\\n"
                            "  /checkpoints — List all snapshots\\n"
                            "  /mcp — List connected MCP servers\\n"
                            "  /mcp connect <name> <command|url> — Connect MCP server"
                        )
                    elif cmd == "clear":
                        agent.ctx.reset()
                        console.print("[dim]Conversation cleared.[/]")
                    elif cmd == "sandbox":
                        st = sandbox.status
                        ctn = st["container"]
                        run = st["running"]
                        img = st["image"]
                        mod = st["mode"]
                        cmds = st["commands_run"]
                        ws = st["workspace"]
                        console.print(
                            f"Container: {ctn}\n"
                            f"Running:   {run}\n"
                            f"Image:     {img}\n"
                            f"Mode:      {mod}\n"
                            f"Commands:  {cmds}\n"
                            f"Workspace: {ws}"
                        )
                    elif cmd.startswith("sandbox run "):
                        cmd_to_run = user_input[13:].strip()
                        result = sandbox.run(cmd_to_run)
                        if result.stdout.strip():
                            console.print(result.stdout.strip())
                        if result.stderr.strip():
                            console.print(f"[red]{result.stderr.strip()}[/]")
                        console.print(f"[dim]exit={result.exit_code}  {result.duration_ms}ms[/]")
                    elif cmd.startswith("sandbox mode "):
                        mode_str = cmd[13:].strip().lower()
                        try:
                            sandbox._config.mode = SandboxMode(mode_str)
                            console.print(f"[green]Sandbox mode: {mode_str}[/]")
                            sandbox.cleanup()  # Restart with new mode
                        except ValueError:
                            console.print(f"[red]Invalid mode: {mode_str}. Use: default, restricted, offline[/]")
                    elif cmd == "cache":
                        console.print(agent.ctx.usage_report)
                    elif cmd == "knowledge":
                        st = kb.stats()
                        docs = kb.list_documents()
                        nd = st["documents"]
                        nc = st["chunks"]
                        nv = st["vocabulary_size"]
                        console.print(f"📚 Knowledge Base: {nd} docs, {nc} chunks\nVocabulary: {nv} terms")
                        if docs:
                            for d in docs:
                                console.print(f"  📄 {d}")
                    elif cmd.startswith("knowledge search "):
                        query = user_input[18:].strip()
                        results = kb.search(query, top_k=5)
                        if not results:
                            console.print("[dim]No results.[/]")
                        else:
                            for i, r in enumerate(results, 1):
                                console.print(f"[bold]#{i}[/] [{r.score:.2f}] {r.chunk.source}")
                                console.print(f"   {r.chunk.text[:200]}...")
                                console.print()
                    elif cmd.startswith("knowledge add "):
                        filepath = user_input[15:].strip()
                        try:
                            n = kb.add_file(filepath)
                            console.print(f"[green]+{n} chunks[/] from {filepath}")
                        except FileNotFoundError:
                            console.print(f"[red]File not found: {filepath}[/]")
                        except Exception as e:
                            console.print(f"[red]{e}[/]")
                    elif cmd == "knowledge clear":
                        kb.clear()
                        console.print("[dim]Knowledge base cleared.[/]")
                    elif cmd.startswith("test-gen "):
                        target_path = user_input[9:].strip()
                        try:
                            p = Path(target_path)
                            if p.is_dir():
                                suites = test_gen.generate_directory(target_path)
                                written = []
                                for suite in suites:
                                    wp = test_gen.write_test_file(suite)
                                    written.append(str(wp))
                                console.print(f"[green]+{len(written)} test files[/]")
                                for w in written:
                                    console.print(f"  📄 {w}")
                            else:
                                suite = test_gen.generate(target_path)
                                wp = test_gen.write_test_file(suite)
                                console.print(f"[green]+{suite.target_count} tests[/] → {wp}")
                        except Exception as e:
                            console.print(f"[red]{e}[/]")
                    elif cmd.startswith("auto "):
                        task = user_input[5:].strip()
                        runner = AutonomousRunner(
                            llm=agent.llm,
                            tools=agent.tools,
                        )
                        report = await runner.run(task, console=console)
                        console.print(f"\n[bold]📋 Report: {report.goal}[/]")
                        for d in report.details:
                            console.print(f"  {d}")
                        console.print(
                            f"\n[bold]{report.summary}[/]\n"
                            f"[dim]{report.steps_done}/{report.steps_total} steps, "
                            f"{report.total_duration_ms}ms[/]"
                        )
                    elif cmd.startswith("refactor "):
                        desc = user_input[9:].strip()
                        console.print(f"[bold cyan]🔧 Refactor: {desc}[/]")
                        console.print("[dim]Enter changes (path old→new), empty line to execute:[/]")
                        changes = []
                        while True:
                            line = Prompt.ask("[dim]  change[/]")
                            if not line.strip():
                                break
                            parts = line.split(" → ", 2)
                            if len(parts) < 3:
                                console.print("[red]Format: path :: old :: new[/]")
                                continue
                            changes.append(
                                FileChange(
                                    path=parts[0].strip(),
                                    old_string=parts[1].strip(),
                                    new_string=parts[2].strip(),
                                )
                            )
                        if changes:
                            plan = RefactorPlan(description=desc, changes=changes)
                            # Preview
                            preview = refactor.preview(plan)
                            console.print(f"[dim]{preview[:1000]}[/]")
                            confirm = Prompt.ask("Apply? [y/N]", default="n")
                            if confirm.lower() == "y":
                                result = refactor.apply(plan)
                                if result.success:
                                    console.print(
                                        f"[green]✅ {result.files_modified} files, "
                                        f"+{result.lines_added}/-{result.lines_removed} lines[/]"
                                    )
                                else:
                                    console.print(f"[red]❌ Rolled back: {result.errors}[/]")
                    elif cmd.startswith("def "):
                        symbol = user_input[4:].strip()
                        locs = sym_index.go_to_definition(symbol)
                        if locs:
                            for loc in locs:
                                console.print(f"📄 {loc.file}:{loc.line} [{loc.kind}]")
                        else:
                            console.print(f"[dim]Symbol not found: {symbol}[/]")
                    elif cmd.startswith("refs "):
                        symbol = user_input[5:].strip()
                        refs = sym_index.find_references(symbol)
                        if refs:
                            for r in refs[:30]:
                                console.print(f"📄 {r.file}:{r.line} [{r.kind}]")
                            if len(refs) > 30:
                                console.print(f"[dim]... and {len(refs) - 30} more[/]")
                        else:
                            console.print(f"[dim]No references: {symbol}[/]")
                    elif cmd.startswith("rename "):
                        parts = user_input[7:].strip().split()
                        if len(parts) < 2:
                            console.print("[red]Usage: /rename old_name new_name[/]")
                        else:
                            old, new = parts[0], parts[1]
                            plan = sym_index.rename_symbol(old, new)
                            if plan:
                                console.print(f"[bold]Rename: {old} → {new}[/]")
                                console.print(f"  Def: {plan.definition.file}:{plan.definition.line}")
                                console.print(f"  Refs: {len(plan.references)} ({plan.total_locations} total)")
                                console.print(f"  Files: {len(plan.changes)}")
                                confirm = Prompt.ask("Apply? [y/N]", default="n")
                                if confirm.lower() == "y":
                                    rp = RefactorPlan(
                                        description=f"Rename {old}→{new}",
                                        changes=[FileChange(**c) for c in plan.changes],
                                    )
                                    result = refactor.apply(rp)
                                    if result.success:
                                        console.print(f"[green]✅ Renamed in {result.files_modified} files[/]")
                                    else:
                                        console.print(f"[red]❌ {result.errors}[/]")
                            else:
                                console.print(f"[dim]Symbol not found: {old}[/]")
                    elif cmd.startswith("hover "):
                        loc_str = user_input[6:].strip()
                        # Parse "file:line" or just symbol name
                        if ":" in loc_str:
                            file, line_str = loc_str.rsplit(":", 1)
                            try:
                                line = int(line_str)
                                info = sym_index.hover(file, line)
                                if info:
                                    console.print(f"[bold]{info.symbol}[/] [{info.kind}]")
                                    if info.signature:
                                        console.print(f"  {info.signature}")
                                    if info.docstring:
                                        console.print(f"  [dim]{info.docstring[:200]}[/]")
                                else:
                                    console.print(f"[dim]No symbol at {file}:{line}[/]")
                            except ValueError:
                                console.print("[red]Format: /hover file.py:line[/]")
                    elif cmd == "status":
                        mcp_count = len(mcp_manager.servers)
                        console.print(
                            f"{agent.ctx.usage_report}\n"
                            f"Mode:   {current_mode.value}\n"
                            f"Tokens: ~{agent.ctx.token_count:,}\n"
                            f"Tools:  {len(agent.tools)} registered"
                            + (f" ({mcp_count} MCP servers)\n" if mcp_count else "\n")
                            + f"Turns:  {agent._turn_count}"
                        )
                    elif cmd.startswith("diff "):
                        args = user_input[5:].strip()
                        if not args:
                            console.print("[red]Usage: /diff <file> [vs_file|--staged][/]")
                            console.print("  /diff file.py        — git diff vs HEAD")
                            console.print("  /diff a.py b.py      — compare two files")
                        elif " " in args:
                            # /diff a.py b.py — compare two files
                            parts = args.split(maxsplit=1)
                            file_a, file_b = parts[0], parts[1]
                            result = diff_viewer.file_diff(file_a, file_b)
                            if result.is_binary:
                                console.print("[dim]Binary file — diff not shown.[/]")
                            elif not result.hunks:
                                console.print("[dim]No differences.[/]")
                            else:
                                panel = diff_viewer.unified_diff(result)
                                console.print(panel)
                        else:
                            # /diff file.py — git diff vs HEAD
                            result = diff_viewer.git_diff(args)
                            if result is None:
                                console.print(
                                    "[dim]No git history or file untracked. Use /diff a.py b.py to compare files.[/]"
                                )
                            elif not result.hunks:
                                console.print(f"[dim]No changes in {args} (vs HEAD).[/]")
                            else:
                                panel = diff_viewer.unified_diff(result)
                                console.print(panel)
                    elif cmd == "diff-side":
                        console.print("[red]Usage: /diff-side a.py b.py[/]")
                    elif cmd.startswith("diff-side "):
                        args = user_input[10:].strip()
                        if " " not in args:
                            console.print("[red]Usage: /diff-side a.py b.py[/]")
                        else:
                            parts = args.split(maxsplit=1)
                            result = diff_viewer.file_diff(parts[0], parts[1])
                            if result.is_binary:
                                console.print("[dim]Binary file — diff not shown.[/]")
                            elif not result.hunks:
                                console.print("[dim]No differences.[/]")
                            else:
                                table = diff_viewer.side_by_side(result)
                                console.print(table)
                    elif cmd.startswith("diff-review"):
                        console.print("[dim]Review last refactor changes...[/]")
                        # Show git diff for working tree
                        import subprocess as _sp

                        try:
                            changed = _sp.check_output(
                                ["git", "diff", "--name-only"],
                                text=True,
                                stderr=_sp.DEVNULL,
                            ).strip()
                            if not changed:
                                console.print("[dim]No uncommitted changes.[/]")
                            else:
                                for f in changed.splitlines():
                                    if not f:
                                        continue
                                    r = diff_viewer.git_diff(f)
                                    if r and r.hunks:
                                        console.print(diff_viewer.unified_diff(r))
                        except Exception:
                            console.print("[dim]git unavailable.[/]")
                    elif cmd.startswith("pr "):
                        # /pr create|list|status|merge
                        subcmd = user_input[3:].strip()
                        if not prwf:
                            console.print("[red]PR Workflow not available. Check GitHub token and git remote.[/]")
                        elif subcmd.startswith("create "):
                            title = subcmd[7:].strip()
                            if not title:
                                console.print("[red]Usage: /pr create <title>[/]")
                            else:
                                try:
                                    body = Prompt.ask("Description (markdown, empty to skip)")
                                    pr_info = prwf.create_pr(title=title, body=body or "")
                                    console.print(f"[green]✅ PR created: {pr_info.url}[/]")
                                    console.print(prwf.format_pr(pr_info))
                                except Exception as e:
                                    console.print(f"[red]{e}[/]")
                        elif subcmd == "list" or subcmd.startswith("list "):
                            state = "open"
                            parts = subcmd.split()
                            if len(parts) > 1 and parts[1] in ("open", "closed", "all"):
                                state = parts[1]
                            try:
                                prs = prwf.list_prs(state=state)
                                if not prs:
                                    console.print(f"[dim]No {state} PRs.[/]")
                                else:
                                    console.print(prwf.format_list(prs))
                            except Exception as e:
                                console.print(f"[red]{e}[/]")
                        elif subcmd.startswith("status "):
                            try:
                                n = int(subcmd.split()[1])
                                status = prwf.pr_status(n)
                                console.print(prwf.format_status(status))
                            except (IndexError, ValueError):
                                console.print("[red]Usage: /pr status <number>[/]")
                            except Exception as e:
                                console.print(f"[red]{e}[/]")
                        elif subcmd.startswith("merge "):
                            parts = subcmd.split()
                            if len(parts) < 2:
                                console.print("[red]Usage: /pr merge <number> [squash|merge|rebase][/]")
                            else:
                                try:
                                    n = int(parts[1])
                                    method = parts[2] if len(parts) > 2 else "squash"
                                    result = prwf.merge_pr(n, method)
                                    if result.get("merged"):
                                        console.print(f"[green]✅ Merged PR #{n} ({method})[/]")
                                    else:
                                        console.print(f"[yellow]{result.get('message', 'Unknown')}[/]")
                                except ValueError:
                                    console.print("[red]PR number must be an integer.[/]")
                                except Exception as e:
                                    console.print(f"[red]{e}[/]")
                        else:
                            console.print("Usage: /pr create|list|status|merge")
                    elif cmd == "mode":
                        console.print(f"Current mode: {current_mode.value}")
                    elif cmd == "index":
                        if code_index:
                            console.print(code_index.to_context(max_items=200))
                        else:
                            console.print("[dim]No codebase index available.[/]")
                    elif cmd == "checkpoint":
                        sid = checkpoint_mgr.save_before_write(".")
                        console.print(f"[green]✅ Checkpoint #{sid} saved[/]")
                    elif cmd == "checkpoints":
                        snaps = checkpoint_mgr.list_snapshots()
                        if not snaps:
                            console.print("[dim]No checkpoints yet.[/]")
                        else:
                            for s in snaps:
                                console.print(f"  #{s['id']} {s['filename']} ({s['timestamp'][:19]})")
                    elif cmd.startswith("rollback"):
                        parts = cmd.split()
                        sid = int(parts[1]) if len(parts) > 1 else None
                        result = checkpoint_mgr.rollback(sid)
                        if result:
                            console.print(
                                f"[green]⏪ Rolled back to snapshot{' #' + str(sid) if sid else ''} → {result}[/]"
                            )
                        else:
                            console.print("[dim]No checkpoints to rollback.[/]")
                    elif cmd == "record" or cmd == "record " or cmd.startswith("record "):
                        sub = cmd[7:] if cmd.startswith("record ") else ""
                        if sub == "start":
                            if recorder.is_recording:
                                console.print("[yellow]Already recording.[/]")
                            else:
                                path = recorder.start()
                                console.print(f"[green]🔴 Recording started → {path}[/]")
                        elif sub == "stop":
                            if not recorder.is_recording:
                                console.print("[dim]Not recording.[/]")
                            else:
                                path = recorder.stop()
                                console.print(f"[green]⏹ Recording stopped → {path}[/]")
                        elif sub in ("status", ""):
                            if recorder.is_recording:
                                size = ""
                                if recorder.path.exists():
                                    size = f", {recorder.path.stat().st_size} bytes"
                                console.print(f"[cyan]🔴 Recording → {recorder.path}{size}[/]")
                            else:
                                console.print("[dim]Not recording. Use /record start[/]")
                        else:
                            console.print("Usage: /record start|stop|status")
                    elif cmd.startswith("replay "):
                        replay_path = user_input[8:].strip()
                        SessionRecorder.replay(replay_path, console=console)
                    elif cmd == "memory" or cmd == "memory ":
                        console.print(
                            "Memory commands:\n"
                            "  /memory save <key> <value> — Save a memory\n"
                            "  /memory search <query>  — Search memories\n"
                            "  /memory list           — List all memories\n"
                            "  /memory clear          — Delete all memories"
                            "  /index — Show codebase index\n"
                        )
                    elif cmd.startswith("memory save "):
                        parts = user_input.split(maxsplit=3)
                        if len(parts) < 4:
                            console.print("Usage: /memory save <key> <value>")
                        else:
                            entry = memory.save(parts[2], parts[3])
                            console.print(f"[green]Saved: {entry.key}[/]")
                    elif cmd.startswith("memory search "):
                        query = user_input[15:].strip()
                        if not query:
                            console.print("Usage: /memory search <query>")
                        else:
                            results = await memory.search(query)
                            if not results:
                                console.print("[dim]No matching memories.[/]")
                            else:
                                for m in results:
                                    console.print(f"[cyan]{m.key}[/]: {m.value[:200]}")
                    elif cmd == "memory list":
                        entries = memory.list()
                        if not entries:
                            console.print("[dim]No memories yet.[/]")
                        else:
                            for m in entries:
                                ts = m.timestamp[:10]
                                console.print(f"[cyan]{m.key}[/] [{ts}]: {m.value[:150]}")
                    elif cmd == "memory clear":
                        memory.clear()
                        console.print("[dim]All memories cleared.[/]")
                    elif cmd == "agent list":
                        nodes = mesh.list_nodes()
                        if not nodes:
                            console.print("[dim]No agent nodes.[/]")
                        else:
                            for n in nodes:
                                prompt_preview = n.system_prompt[:60].replace("\n", " ")
                                console.print(f"  [cyan]{n.name}[/] [{n.role.value}] {prompt_preview}...")
                    elif cmd.startswith("agent create "):
                        parts = user_input.split(maxsplit=3)
                        if len(parts) < 3:
                            console.print("Usage: /agent create <name> <role> [coder|reviewer|researcher|planner]")
                        else:
                            name = parts[2]
                            role_str = parts[3] if len(parts) > 3 else "coder"
                            try:
                                role = AgentRole(role_str)
                            except ValueError:
                                console.print(f"Unknown role: {role_str}. Use: coder, reviewer, researcher, planner")
                                continue
                            try:
                                mesh.add_node(name, role)
                                console.print(f"[green]Created agent: {name} ({role})[/]")
                            except ValueError as e:
                                console.print(f"[red]{e}[/]")
                    elif cmd.startswith("agent run "):
                        parts = user_input.split(maxsplit=2)
                        if len(parts) < 3:
                            console.print("Usage: /agent run <name> <task>")
                        else:
                            rest = parts[2].split(maxsplit=1)
                            name = rest[0]
                            task = rest[1] if len(rest) > 1 else ""
                            if not task:
                                console.print("Usage: /agent run <name> <task>")
                            else:
                                result = (
                                    await mesh.route(task)
                                    if name == "auto"
                                    else await mesh._execute_node(mesh.get_node(name), task, label=name)
                                    if mesh.get_node(name)
                                    else None
                                )
                                if result is None:
                                    console.print(f"[red]Node '{name}' not found.[/]")
                                elif result.success:
                                    console.print(
                                        f"\n[bold cyan]{result.node_name}[/] ([{result.role}]):\n{result.output}"
                                    )
                                else:
                                    console.print(f"[red]{result.error}[/]")
                    elif cmd.startswith("mesh route "):
                        task = user_input[12:].strip()
                        if not task:
                            console.print("Usage: /mesh route <task>")
                        else:
                            result = await mesh.route(task)
                            if result.success:
                                console.print(f"\n[bold cyan]{result.node_name}[/] ([{result.role}]):\n{result.output}")
                            else:
                                console.print(f"[red]{result.error}[/]")
                    elif cmd.startswith("mesh pipeline "):
                        rest = user_input[15:].strip()
                        space_idx = rest.find(" ")
                        if space_idx == -1:
                            console.print("Usage: /mesh pipeline n1,n2 <task>")
                        else:
                            nodes_str = rest[:space_idx]
                            task = rest[space_idx + 1 :].strip()
                            node_names = [n.strip() for n in nodes_str.split(",") if n.strip()]
                            if not node_names or not task:
                                console.print("Usage: /mesh pipeline n1,n2 <task>")
                            else:
                                result = await mesh.pipeline(node_names, task)
                                if result.success:
                                    console.print(
                                        f"\n[bold cyan]Pipeline done ({result.duration_ms}ms)[/]:\n{result.output}"
                                    )
                                else:
                                    console.print(f"[red]Pipeline failed at {result.node_name}: {result.error}[/]")
                    elif cmd.startswith("mesh broadcast "):
                        rest = user_input[16:].strip()
                        space_idx = rest.find(" ")
                        if space_idx == -1:
                            console.print("Usage: /mesh broadcast n1,n2 <task>")
                        else:
                            nodes_str = rest[:space_idx]
                            task = rest[space_idx + 1 :].strip()
                            node_names = [n.strip() for n in nodes_str.split(",") if n.strip()]
                            if not node_names or not task:
                                console.print("Usage: /mesh broadcast n1,n2 <task>")
                            else:
                                results = await mesh.broadcast(node_names, task)
                                for r in results:
                                    status = "✅" if r.success else "❌"
                                    msg = (
                                        f"\n{status} [cyan]{r.node_name}[/]"
                                        f" [{r.role}] ({r.duration_ms}ms):\n{r.output[:500]}"
                                    )
                                    console.print(msg)
                                # Synthesize
                                syn = await mesh.synthesize(task, results)
                                console.print(f"\n[bold]🧠 Synthesis:[/]\n{syn}")
                    elif cmd.startswith("mode "):
                        mode_name = cmd[5:].strip()
                        mode_map = {
                            "react": AgentMode.REACT,
                            "plan": AgentMode.PLAN_EXECUTE,
                            "sub": AgentMode.SUBAGENT,
                            "auto": AgentMode.AUTO,
                        }
                        if mode_name in mode_map:
                            current_mode = mode_map[mode_name]
                            console.print(f"[cyan]Mode set to: {current_mode.value}[/]")
                        else:
                            console.print(f"Unknown mode: {mode_name}")
                    elif cmd == "mcp" or cmd == "mcp ":
                        # /mcp — list servers & tools
                        if not mcp_manager.servers:
                            console.print("[dim]No MCP servers connected.[/]")
                            console.print(
                                "Configure via DEEPCRAFT_MCP_SERVERS env var, "
                                "e.g. github:npx -y @modelcontextprotocol/server-github"
                            )
                        else:
                            for srv_name in mcp_manager.servers:
                                table = Table(title=f"MCP: {srv_name}")
                                table.add_column("Tool", style="cyan")
                                table.add_column("Description", style="dim")
                                prefix = f"mcp_{srv_name}_"
                                for t in agent.tools.list_definitions():
                                    if t.name.startswith(prefix):
                                        table.add_row(
                                            t.name,
                                            t.description[:80],
                                        )
                                console.print(table)
                    elif cmd.startswith("mcp connect "):
                        # /mcp connect <name> <command|url>
                        parts = shlex.split(user_input)
                        if len(parts) < 4:
                            console.print(
                                "Usage: /mcp connect <name> <command>     (stdio)\n"
                                "       /mcp connect <name> <url>         (HTTP)"
                            )
                        else:
                            name = parts[2]
                            target = " ".join(parts[3:])
                            try:
                                if target.startswith("http://") or target.startswith("https://"):
                                    await mcp_manager.connect_http_server(name, target)
                                else:
                                    await mcp_manager.connect_server(name, parts[3:])
                                console.print(f"[green]✅ MCP server '{name}' connected![/]")
                            except Exception as e:
                                console.print(f"[red]❌ Failed: {e}[/]")
                    elif cmd.startswith("export "):
                        parts = cmd.split(maxsplit=2)
                        fmt = parts[1] if len(parts) > 1 else "md"
                        path = parts[2] if len(parts) > 2 else ""
                        if fmt not in ("md", "json"):
                            console.print("Usage: /export md|json [path]")
                            continue
                        if not path:
                            ts = __import__("datetime").datetime.now().strftime("%Y%m%d_%H%M%S")
                            path = f"deepcraft_export_{ts}.{fmt}"
                        try:
                            if fmt == "md":
                                content = agent.ctx.export_markdown()
                            else:
                                content = __import__("json").dumps(
                                    agent.ctx.export_json(), ensure_ascii=False, indent=2
                                )
                            with open(path, "w", encoding="utf-8") as f:
                                f.write(content)
                            console.print(f"[green]✅ Exported {len(agent.ctx)} messages → {path}[/]")
                        except Exception as e:
                            console.print(f"[red]❌ Export failed: {e}[/]")
                    else:
                        console.print(f"Unknown command: /{cmd}")
                    continue

                # Normal input → agent loop with mode
                console.print()
                try:
                    import time as _time

                    _start = _time.monotonic()
                    await agent.run_with_mode(user_input, mode=current_mode)
                    _elapsed = int((_time.monotonic() - _start) * 1000)
                    console.print(f"[dim]{agent.ctx.usage_report}[/]")

                    # Auto-record if active
                    if recorder.is_recording:
                        # Collect tool calls from last assistant message
                        tool_calls = []
                        for msg in reversed(agent.ctx._messages):
                            if msg.role == "assistant" and msg.tool_calls:
                                for tc in msg.tool_calls:
                                    tool_calls.append(
                                        {
                                            "name": tc["function"]["name"],
                                            "arguments": tc["function"]["arguments"],
                                        }
                                    )
                                break

                        recorder.record_turn(
                            turn=agent._turn_count,
                            user_input=user_input,
                            tool_calls=tool_calls,
                            duration_ms=_elapsed,
                            token_estimate=agent.ctx.token_count,
                            compression_count=agent.ctx.compression_count,
                        )

                    # Auto-capture memory every 5 turns
                    if agent._turn_count > 0 and agent._turn_count % 5 == 0:
                        try:
                            # Extract last 10 messages as context for memory extraction
                            recent_msgs = agent.ctx._messages[-15:]
                            context = "\n".join(f"[{m.role}] {m.content or ''}" for m in recent_msgs)
                            new_memories = await memory.auto_capture(context[:4000])
                            if new_memories:
                                keys = [m.key for m in new_memories]
                                console.print(f"[dim]🧠 Auto-memorized: {', '.join(keys)}[/]")
                        except Exception:
                            pass  # silent fail for auto-capture
                except Exception as e:
                    console.print(f"\n[red]Error: {e}[/]")

        finally:
            await mcp_manager.close_all()
            await agent.close()

    asyncio.run(repl())


def run_once(prompt: str, mode: AgentMode = AgentMode.AUTO) -> None:
    """Run a single prompt and exit.

    Args:
        prompt: The user's input.
        mode: Agent mode to use (default: auto-detect).
    """

    async def _run() -> None:
        agent = _create_agent()
        mcp_manager = MCPManager(agent.tools)
        try:
            await _connect_mcp_servers(agent, mcp_manager)
            await agent.run_with_mode(prompt, mode=mode)
        finally:
            await mcp_manager.close_all()
            await agent.close()

    asyncio.run(_run())
