"""Search and replace tool — diff-based precise file editing.

Claude Code-style search & replace: find an exact block of text and replace it.
Safer and more precise than rewriting the entire file.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from deepcraft.agent.tools.base import BaseTool, ToolResult

if TYPE_CHECKING:
    from deepcraft.agent.tools.checkpoint import CheckpointManager


@dataclass
class SearchReplaceTool(BaseTool):
    """Precise search-and-replace in files — like Claude Code's edit tool.

    Instead of rewriting an entire file, find a specific block of text
    and replace it. This is safer, preserves surrounding context, and
    reduces token usage.
    """

    name: str = "search_replace"
    description: str = (
        "Perform exact string replacements in an existing file. "
        "Find a specific block of text (old_string) and replace it with new_string. "
        "old_string must match exactly, including whitespace and indentation. "
        "Use this for precise code edits instead of rewriting the entire file. "
        "For best results, include 2-3 lines of surrounding context in old_string "
        "to ensure a unique match."
    )
    parameters: dict = field(
        default_factory=lambda: {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Absolute or relative path to the file to edit",
                },
                "old_string": {
                    "type": "string",
                    "description": (
                        "The exact text to find and replace. Must match exactly, "
                        "including whitespace and indentation. Include enough surrounding "
                        "context (2-3 lines before/after) to ensure a unique match."
                    ),
                },
                "new_string": {
                    "type": "string",
                    "description": "The text to replace it with",
                },
                "replace_all": {
                    "type": "boolean",
                    "description": ("Replace all occurrences instead of requiring a unique match (default: false)"),
                },
            },
            "required": ["path", "old_string", "new_string"],
        }
    )

    checkpoint_manager: CheckpointManager | None = None

    async def execute(
        self,
        path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
        **kwargs: object,
    ) -> ToolResult:
        """Execute search-and-replace in a file."""
        try:
            filepath = Path(path).expanduser().resolve()
            if not filepath.exists():
                return ToolResult(content=f"Error: file not found: {filepath}", is_error=True)
            if not filepath.is_file():
                return ToolResult(content=f"Error: not a file: {filepath}", is_error=True)

            # Save checkpoint before modifying
            if self.checkpoint_manager:
                self.checkpoint_manager.save_before_write(filepath)

            content = filepath.read_text(encoding="utf-8")

            # Count occurrences
            count = content.count(old_string)
            if count == 0:
                return ToolResult(
                    content=(
                        f"Error: old_string not found in {filepath}.\n"
                        f"The string must match exactly, including whitespace and indentation.\n"
                        f"Tip: try reading the file first to get the exact text."
                    ),
                    is_error=True,
                )
            if count > 1 and not replace_all:
                return ToolResult(
                    content=(
                        f"Error: old_string found {count} times in {filepath}.\n"
                        f"Add more surrounding context to make it unique, "
                        f"or set replace_all=true to replace all {count} occurrences."
                    ),
                    is_error=True,
                )

            new_content = content.replace(old_string, new_string)
            filepath.write_text(new_content, encoding="utf-8")

            # Generate a diff-like summary
            old_lines = old_string.strip().split("\n")
            new_lines = new_string.strip().split("\n")
            old_preview = old_lines[0][:80] + ("..." if len(old_lines) > 1 or len(old_lines[0]) > 80 else "")
            new_preview = new_lines[0][:80] + ("..." if len(new_lines) > 1 or len(new_lines[0]) > 80 else "")

            occurrences_str = f" (all {count} occurrences)" if replace_all else ""
            return ToolResult(
                content=(f"✅ Replaced in {filepath}{occurrences_str}:\n  -{old_preview}\n  +{new_preview}")
            )

        except UnicodeDecodeError:
            return ToolResult(
                content=f"Error: {filepath} is a binary file, cannot edit as text.",
                is_error=True,
            )
        except PermissionError:
            return ToolResult(content=f"Error: permission denied: {filepath}", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error editing {filepath}: {e}", is_error=True)
