"""File I/O tools: read, write, search files."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from deepcraft.agent.tools.base import BaseTool, ToolResult
from deepcraft.config import WORKDIR

if TYPE_CHECKING:
    from deepcraft.agent.tools.checkpoint import CheckpointManager


def _resolve_path(filepath: str) -> Path:
    """Resolve path relative to workdir, prevent traversal."""
    p = (WORKDIR / filepath).resolve()
    if not str(p).startswith(str(WORKDIR.resolve())):
        raise ValueError(f"Path traversal denied: {filepath}")
    return p


class ReadFileTool(BaseTool):
    name = "read_file"
    description = "Read contents of a file with line numbers and pagination."
    parameters = {
        "path": {
            "type": "string",
            "description": "Path to the file to read (relative to workdir)",
        },
        "offset": {
            "type": "integer",
            "description": "Line number to start reading from (1-indexed, default: 1)",
        },
        "limit": {
            "type": "integer",
            "description": "Maximum lines to read (default: 500, max: 2000)",
        },
    }

    async def execute(  # type: ignore[override]
        self,
        path: str,
        offset: int = 1,
        limit: int = 500,
    ) -> ToolResult:
        try:
            p = _resolve_path(path)
            if not p.exists():
                return ToolResult(content=f"File not found: {path}", is_error=True)
            if not p.is_file():
                return ToolResult(content=f"Not a file: {path}", is_error=True)

            limit = min(max(limit, 1), 2000)
            offset = max(offset, 1)

            lines = p.read_text(encoding="utf-8").splitlines()
            total = len(lines)

            if offset > total:
                msg = f"Offset {offset} exceeds total lines {total}."
                return ToolResult(content=msg, is_error=True)

            end = min(offset + limit - 1, total)
            result_lines = []
            for i, line in enumerate(lines[offset - 1 : end], start=offset):
                result_lines.append(f"{i:>6}|{line}")

            header = f"[{path}] lines {offset}-{end} of {total}\n"
            return ToolResult(content=header + "\n".join(result_lines))

        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error reading {path}: {e}", is_error=True)


class WriteFileTool(BaseTool):
    name = "write_file"
    description = "Write content to a file, overwriting if it exists."
    parameters = {
        "path": {
            "type": "string",
            "description": "Path to the file to write (relative to workdir)",
        },
        "content": {
            "type": "string",
            "description": "Content to write to the file",
        },
    }

    checkpoint_manager: CheckpointManager | None = None

    async def execute(self, path: str, content: str) -> ToolResult:  # type: ignore[override]
        try:
            p = _resolve_path(path)
            # Save checkpoint before modifying
            if self.checkpoint_manager and p.exists():
                self.checkpoint_manager.save_before_write(p)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")
            size = len(content)
            return ToolResult(content=f"Written {size} bytes to {path}")
        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error writing {path}: {e}", is_error=True)


class SearchFilesTool(BaseTool):
    name = "search_files"
    description = "Search file contents with regex or find files by glob pattern."
    parameters = {
        "pattern": {
            "type": "string",
            "description": "Regex pattern for content search, or glob for file search",
        },
        "target": {
            "type": "string",
            "enum": ["content", "files"],
            "description": "'content' searches inside files, 'files' finds files by name",
        },
        "path": {
            "type": "string",
            "description": "Directory to search in (default: .)",
        },
        "file_glob": {
            "type": "string",
            "description": "Filter files by glob when searching content (e.g., '*.py')",
        },
    }

    async def execute(  # type: ignore[override]
        self,
        pattern: str,
        target: str = "content",
        path: str = ".",
        file_glob: str | None = None,
    ) -> ToolResult:
        try:
            import fnmatch
            import re

            search_dir = _resolve_path(path)
            if not search_dir.exists():
                return ToolResult(content=f"Directory not found: {path}", is_error=True)

            if target == "files":
                matches = []
                for f in search_dir.rglob("*"):
                    if f.is_file() and fnmatch.fnmatch(f.name, pattern):
                        rel = f.relative_to(search_dir)
                        matches.append(str(rel))
                if not matches:
                    return ToolResult(content=f"No files matching '{pattern}'")
                return ToolResult(content="\n".join(sorted(matches)[:50]))

            else:  # content search
                regex = re.compile(pattern)
                matches = []
                glob_pattern = file_glob or "*"

                for f in search_dir.rglob("*"):
                    if not f.is_file():
                        continue
                    rel = f.relative_to(search_dir)
                    if not fnmatch.fnmatch(f.name, glob_pattern):
                        continue
                    # Skip binary and large files
                    if f.suffix in (".pyc", ".so", ".o", ".bin", ".png", ".jpg", ".mp4"):
                        continue
                    if f.stat().st_size > 1_000_000:
                        continue
                    try:
                        for i, line in enumerate(f.read_text(encoding="utf-8").splitlines(), 1):
                            if regex.search(line):
                                matches.append(f"{rel}:{i}: {line.strip()}")
                                if len(matches) >= 50:
                                    break
                    except Exception:
                        continue
                    if len(matches) >= 50:
                        break

                if not matches:
                    return ToolResult(content=f"No matches for '{pattern}'")
                return ToolResult(content="\n".join(matches))

        except ValueError as e:
            return ToolResult(content=str(e), is_error=True)
        except Exception as e:
            return ToolResult(content=f"Error searching: {e}", is_error=True)
