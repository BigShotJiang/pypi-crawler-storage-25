"""Refactoring tools — atomic multi-file changes for the Agent."""

from __future__ import annotations

from typing import Any

from deepcraft.agent.refactor import AtomicRefactor, FileChange, RefactorPlan
from deepcraft.agent.tools.base import Tool, ToolResult

REFACTOR_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "refactor",
        "description": (
            "Apply atomic multi-file changes. All changes succeed or all rollback. "
            "Each change is a search-and-replace in one file. "
            "Use this for cross-cutting refactoring like renaming, "
            "extracting functions, or updating imports across files."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "description": {
                    "type": "string",
                    "description": "Short description of the refactoring goal.",
                },
                "changes": {
                    "type": "array",
                    "description": "List of file changes to apply atomically.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {
                                "type": "string",
                                "description": "File path to modify.",
                            },
                            "old_string": {
                                "type": "string",
                                "description": "Exact text to find and replace.",
                            },
                            "new_string": {
                                "type": "string",
                                "description": "Replacement text.",
                            },
                            "replace_all": {
                                "type": "boolean",
                                "description": "Replace all occurrences (default: false).",
                            },
                        },
                        "required": ["path", "old_string", "new_string"],
                    },
                },
            },
            "required": ["description", "changes"],
        },
    },
}


class RefactorTool(Tool):
    """Atomic multi-file refactoring tool."""

    def __init__(self, refactor: AtomicRefactor) -> None:
        self._refactor = refactor

    @property
    def name(self) -> str:
        return "refactor"

    @property
    def description(self) -> str:
        return "Apply atomic multi-file search-and-replace changes."

    @property
    def definition(self) -> dict[str, Any]:
        return REFACTOR_DEFINITION

    async def execute(self, description: str, changes: list[dict[str, Any]]) -> ToolResult:
        """Execute a multi-file refactoring."""
        try:
            file_changes = [
                FileChange(
                    path=c["path"],
                    old_string=c["old_string"],
                    new_string=c["new_string"],
                    replace_all=c.get("replace_all", False),
                )
                for c in changes
            ]

            plan = RefactorPlan(description=description, changes=file_changes)
            result = self._refactor.apply(plan)

            if result.success:
                return ToolResult(
                    content=(
                        f"✅ Refactored {result.files_modified} file(s): "
                        f"+{result.lines_added}/-{result.lines_removed} lines\n\n"
                        f"{result.diff[:1000]}"
                    ),
                    is_error=False,
                )
            else:
                return ToolResult(
                    content=(
                        f"❌ Refactoring failed. {result.files_modified} applied, "
                        f"{result.files_failed} failed. All changes rolled back.\n" + "\n".join(result.errors)
                    ),
                    is_error=True,
                )
        except Exception as e:
            return ToolResult(content=str(e), is_error=True)
