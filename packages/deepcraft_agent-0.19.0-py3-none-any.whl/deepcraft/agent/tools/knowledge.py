"""Knowledge tools — RAG search and document ingestion for the Agent."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from deepcraft.agent.knowledge import KnowledgeBase
from deepcraft.agent.tools.base import Tool, ToolResult

SEARCH_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "knowledge_search",
        "description": (
            "Search the project knowledge base for relevant documentation. "
            "Use this when you need to understand the project's design, "
            "architecture decisions, or find related documentation."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural language search query.",
                },
                "top_k": {
                    "type": "integer",
                    "description": "Number of results to return (default: 5).",
                },
            },
            "required": ["query"],
        },
    },
}

ADD_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "knowledge_add",
        "description": (
            "Add a document to the knowledge base for future semantic search. Supports .md, .py, .txt, .rst files."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to add.",
                },
            },
            "required": ["path"],
        },
    },
}


class KnowledgeSearchTool(Tool):
    """Search the knowledge base."""

    def __init__(self, kb: KnowledgeBase) -> None:
        self._kb = kb

    @property
    def name(self) -> str:
        return "knowledge_search"

    @property
    def description(self) -> str:
        return "Semantic search across project documentation and code."

    @property
    def definition(self) -> dict[str, Any]:
        return SEARCH_DEFINITION

    async def execute(self, query: str, top_k: int = 5) -> ToolResult:
        try:
            results = self._kb.search(query, top_k=top_k)
            if not results:
                return ToolResult(
                    content="No relevant documents found. Try adding documentation with knowledge_add.",
                    is_error=False,
                )

            lines = [f"Found {len(results)} relevant chunk(s):\n"]
            for i, r in enumerate(results, 1):
                src = Path(r.chunk.source).name
                heading = f" [{r.chunk.heading}]" if r.chunk.heading else ""
                lines.append(f"#{i} [{r.score:.2f}] {src}{heading}\n   {r.chunk.text[:300]}...")
            return ToolResult(content="\n".join(lines), is_error=False)
        except Exception as e:
            return ToolResult(content=str(e), is_error=True)


class KnowledgeAddTool(Tool):
    """Add documents to the knowledge base."""

    def __init__(self, kb: KnowledgeBase) -> None:
        self._kb = kb

    @property
    def name(self) -> str:
        return "knowledge_add"

    @property
    def description(self) -> str:
        return "Add a document to the knowledge base for future search."

    @property
    def definition(self) -> dict[str, Any]:
        return ADD_DEFINITION

    async def execute(self, path: str) -> ToolResult:
        try:
            n = self._kb.add_file(path)
            if n == 0:
                return ToolResult(content="Already indexed.", is_error=False)
            return ToolResult(
                content=f"Added {n} chunk(s) from {Path(path).name} to knowledge base.",
                is_error=False,
            )
        except FileNotFoundError:
            return ToolResult(content=f"File not found: {path}", is_error=True)
        except Exception as e:
            return ToolResult(content=str(e), is_error=True)
