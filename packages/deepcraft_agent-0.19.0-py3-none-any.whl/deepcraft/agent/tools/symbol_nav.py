"""Symbol navigation tools — go-to-def, find-refs, rename, hover."""

from __future__ import annotations

from typing import Any

from deepcraft.agent.symbol_index import SymbolIndex
from deepcraft.agent.tools.base import Tool, ToolResult

GOTO_DEF: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "goto_definition",
        "description": "Find where a symbol (function, class, method) is defined.",
        "parameters": {
            "type": "object",
            "properties": {
                "symbol": {"type": "string", "description": "Symbol name to find."},
            },
            "required": ["symbol"],
        },
    },
}

FIND_REFS: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "find_references",
        "description": "Find all usages of a symbol across the codebase.",
        "parameters": {
            "type": "object",
            "properties": {
                "symbol": {"type": "string", "description": "Symbol name to search."},
            },
            "required": ["symbol"],
        },
    },
}

RENAME_DEF: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "rename_symbol",
        "description": "Rename a symbol across the entire codebase using atomic refactoring.",
        "parameters": {
            "type": "object",
            "properties": {
                "old_name": {"type": "string", "description": "Current symbol name."},
                "new_name": {"type": "string", "description": "New symbol name."},
            },
            "required": ["old_name", "new_name"],
        },
    },
}


class GotoDefinitionTool(Tool):
    def __init__(self, idx: SymbolIndex) -> None:
        self._idx = idx

    @property
    def name(self) -> str:
        return "goto_definition"

    @property
    def description(self) -> str:
        return "Find symbol definition location."

    @property
    def definition(self) -> dict[str, Any]:
        return GOTO_DEF

    async def execute(self, symbol: str) -> ToolResult:
        locs = self._idx.go_to_definition(symbol)
        if not locs:
            return ToolResult(content=f"Symbol '{symbol}' not found.", is_error=False)
        lines = [f"Definition(s) of '{symbol}':"]
        for loc in locs:
            lines.append(f"  📄 {loc.file}:{loc.line} [{loc.kind}]")
        return ToolResult(content="\n".join(lines), is_error=False)


class FindReferencesTool(Tool):
    def __init__(self, idx: SymbolIndex) -> None:
        self._idx = idx

    @property
    def name(self) -> str:
        return "find_references"

    @property
    def description(self) -> str:
        return "Find all references to a symbol."

    @property
    def definition(self) -> dict[str, Any]:
        return FIND_REFS

    async def execute(self, symbol: str) -> ToolResult:
        refs = self._idx.find_references(symbol)
        if not refs:
            return ToolResult(content=f"No references found for '{symbol}'.", is_error=False)
        lines = [f"References to '{symbol}' ({len(refs)}):"]
        for r in refs[:20]:
            lines.append(f"  📄 {r.file}:{r.line} [{r.kind}]")
        if len(refs) > 20:
            lines.append(f"  ... and {len(refs) - 20} more")
        return ToolResult(content="\n".join(lines), is_error=False)


class RenameSymbolTool(Tool):
    def __init__(self, idx: SymbolIndex) -> None:
        self._idx = idx

    @property
    def name(self) -> str:
        return "rename_symbol"

    @property
    def description(self) -> str:
        return "Rename a symbol across the entire codebase."

    @property
    def definition(self) -> dict[str, Any]:
        return RENAME_DEF

    async def execute(self, old_name: str, new_name: str) -> ToolResult:
        plan = self._idx.rename_symbol(old_name, new_name)
        if not plan:
            return ToolResult(content=f"Symbol '{old_name}' not found.", is_error=False)
        return ToolResult(
            content=(
                f"Rename plan: '{old_name}' → '{new_name}'\n"
                f"  Definition: {plan.definition.file}:{plan.definition.line}\n"
                f"  References: {len(plan.references)}\n"
                f"  Total locations: {plan.total_locations}\n\n"
                f"Use the refactor tool to apply these changes:\n"
                f"  changes={plan.changes}"
            ),
            is_error=False,
        )
