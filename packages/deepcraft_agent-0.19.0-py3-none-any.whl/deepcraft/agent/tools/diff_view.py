"""Diff tools — visual diff viewing for the Agent."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from deepcraft.agent.diff_view import DiffViewer
from deepcraft.agent.tools.base import Tool, ToolResult

DIFF_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "diff_view",
        "description": (
            "Show a visual diff between two files, or between a file on disk "
            "and its HEAD version. Use this to see what changed, preview "
            "proposed edits, or compare versions."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path_a": {
                    "type": "string",
                    "description": "First file path (or the only file for git diff).",
                },
                "path_b": {
                    "type": "string",
                    "description": "Second file path. If omitted, shows git diff vs HEAD.",
                },
                "style": {
                    "type": "string",
                    "enum": ["unified", "side_by_side", "summary"],
                    "description": "Diff display style (default: unified).",
                },
            },
            "required": ["path_a"],
        },
    },
}

DIFF_PREVIEW_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "diff_preview",
        "description": (
            "Preview a proposed search-and-replace change in a file. "
            "Shows exactly what lines will be added/removed. "
            "Use BEFORE refactoring to verify correctness."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "File path to preview changes for.",
                },
                "old_string": {
                    "type": "string",
                    "description": "Exact text to find and replace.",
                },
                "new_string": {
                    "type": "string",
                    "description": "Replacement text.",
                },
                "replace_all": {
                    "type": "boolean",
                    "description": "Replace all occurrences (default: false).",
                },
                "context": {
                    "type": "integer",
                    "description": "Lines of context around changes (default: 3).",
                },
            },
            "required": ["path", "old_string", "new_string"],
        },
    },
}


class DiffTool(Tool):
    """Visual diff tool — compare files or see git changes."""

    def __init__(self, viewer: DiffViewer | None = None) -> None:
        self._viewer = viewer or DiffViewer()

    @property
    def name(self) -> str:
        return "diff_view"

    @property
    def description(self) -> str:
        return "Show visual diff between files or vs HEAD."

    @property
    def definition(self) -> dict[str, Any]:
        return DIFF_DEFINITION

    async def execute(
        self,
        path_a: str,
        path_b: str = "",
        style: str = "unified",
    ) -> ToolResult:
        """Execute diff between files or vs git HEAD."""
        try:
            if path_b:
                result = self._viewer.file_diff(path_a, path_b)
            else:
                result = self._viewer.git_diff(path_a)
                if result is None:
                    return ToolResult(
                        content=f"Could not get git diff for {path_a}. File may be untracked or git unavailable.",
                        is_error=True,
                    )

            if result.is_binary:
                return ToolResult(
                    content=f"Binary file — diff not shown: {path_a}",
                    is_error=False,
                )

            if not result.has_changes:
                return ToolResult(
                    content=f"No changes: {result.old_path} vs {result.new_path}",
                    is_error=False,
                )

            if style == "summary":
                return ToolResult(
                    content=(
                        f"Diff: {result.old_path} → {result.new_path}\n"
                        f"+{result.lines_added} / -{result.lines_removed} lines "
                        f"in {result.total_hunks} hunk(s)\n"
                    ),
                    is_error=False,
                )

            # Build text representation of the diff
            lines = [
                f"--- {result.old_path}",
                f"+++ {result.new_path}",
                "",
            ]
            for hunk in result.hunks:
                lines.append(hunk.header)
                for kind, text in hunk.lines:
                    prefix = {"+": "+", "-": "-", " ": " "}.get(kind, kind)
                    lines.append(f"{prefix} {text}")
                lines.append("")

            lines.append(f"+{result.lines_added} / -{result.lines_removed} lines in {result.total_hunks} hunk(s)")
            return ToolResult(content="\n".join(lines), is_error=False)

        except Exception as e:
            return ToolResult(content=f"Diff failed: {e}", is_error=True)


class DiffPreviewTool(Tool):
    """Preview a proposed search-and-replace change before applying it."""

    def __init__(self, viewer: DiffViewer | None = None) -> None:
        self._viewer = viewer or DiffViewer()

    @property
    def name(self) -> str:
        return "diff_preview"

    @property
    def description(self) -> str:
        return "Preview a proposed edit to a file — see what will change."

    @property
    def definition(self) -> dict[str, Any]:
        return DIFF_PREVIEW_DEFINITION

    async def execute(
        self,
        path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
        context: int = 3,
    ) -> ToolResult:
        """Preview a single search-and-replace change."""
        try:
            p = Path(path)
            if not p.exists():
                return ToolResult(content=f"File not found: {path}", is_error=True)

            old_text = p.read_text(encoding="utf-8")

            # Count occurrences
            count = old_text.count(old_string)
            if count == 0:
                return ToolResult(
                    content=f"Pattern not found in {path}. Preview not possible.",
                    is_error=True,
                )

            if not replace_all:
                new_text = old_text.replace(old_string, new_string, 1)
            else:
                new_text = old_text.replace(old_string, new_string)

            result = self._viewer.diff_texts(
                old_text,
                new_text,
                old_label=path,
                new_label=f"{path} (proposed)",
            )

            # Build text diff
            lines = [
                f"Preview: {path}",
                f"  Occurrences: {count} ({'replace all' if replace_all else 'first only'})",
                "",
            ]
            for hunk in result.hunks:
                lines.append(hunk.header)
                for kind, text in hunk.lines:
                    prefix = {"+": "+", "-": "-", " ": " "}.get(kind, kind)
                    lines.append(f"{prefix} {text}")
                lines.append("")

            lines.append(f"+{result.lines_added} / -{result.lines_removed} lines")
            return ToolResult(content="\n".join(lines), is_error=False)

        except UnicodeDecodeError:
            return ToolResult(
                content=f"Binary file — cannot preview diff: {path}",
                is_error=True,
            )
        except Exception as e:
            return ToolResult(content=f"Preview failed: {e}", is_error=True)
