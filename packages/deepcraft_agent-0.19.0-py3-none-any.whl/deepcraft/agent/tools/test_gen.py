"""Test generation tools — auto-generate pytest tests for Python files."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from deepcraft.agent.test_gen import TestGenerator
from deepcraft.agent.tools.base import Tool, ToolResult

GENERATE_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "generate_tests",
        "description": (
            "Generate pytest test skeletons for a Python source file or directory. "
            "Analyzes functions, methods, and classes, then creates sensible test cases "
            "with edge case and error handling coverage. Writes tests to the tests/ directory."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to a .py file or directory to generate tests for.",
                },
                "edge_cases": {
                    "type": "boolean",
                    "description": "Generate edge case tests (default: true).",
                },
                "error_cases": {
                    "type": "boolean",
                    "description": "Generate error/exception tests (default: true).",
                },
            },
            "required": ["path"],
        },
    },
}


class TestGenTool(Tool):
    """Generate tests for Python source files."""

    def __init__(self, generator: TestGenerator) -> None:
        self._gen = generator

    @property
    def name(self) -> str:
        return "generate_tests"

    @property
    def description(self) -> str:
        return "Auto-generate pytest test skeletons for Python source code."

    @property
    def definition(self) -> dict[str, Any]:
        return GENERATE_DEFINITION

    async def execute(
        self,
        path: str,
        edge_cases: bool = True,
        error_cases: bool = True,
    ) -> ToolResult:
        """Generate tests for a file or directory."""
        try:
            self._gen._generate_edge_cases = edge_cases
            self._gen._generate_error_cases = error_cases

            target = Path(path)
            if not target.exists():
                return ToolResult(content=f"Path not found: {path}", is_error=True)

            if target.is_dir():
                suites = self._gen.generate_directory(path)
                written = []
                for suite in suites:
                    p = self._gen.write_test_file(suite)
                    written.append(str(p))
                return ToolResult(
                    content=f"Generated {len(written)} test file(s):\n" + "\n".join(f"  📄 {w}" for w in written),
                    is_error=False,
                )
            else:
                suite = self._gen.generate(path)
                p = self._gen.write_test_file(suite)
                return ToolResult(
                    content=f"Generated {suite.target_count} test(s) for {suite.source_path.name}\n  📄 {p}",
                    is_error=False,
                )
        except Exception as e:
            return ToolResult(content=str(e), is_error=True)
