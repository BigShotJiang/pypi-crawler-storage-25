"""Sandbox tool — Agent-facing wrapper for DockerSandbox."""

from __future__ import annotations

from typing import Any

from deepcraft.agent.sandbox import DockerSandbox
from deepcraft.agent.tools.base import Tool, ToolResult

TOOL_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "sandbox",
        "description": (
            "Execute a command in an isolated Docker sandbox. "
            "Use this instead of terminal when running untrusted code, "
            "installing packages, or testing potentially destructive commands."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "Shell command to execute in the sandbox.",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (default: 30).",
                },
                "workdir": {
                    "type": "string",
                    "description": "Working directory inside container (default: /workspace).",
                },
            },
            "required": ["command"],
        },
    },
}


class SandboxTool(Tool):
    """Agent tool: execute commands in Docker sandbox."""

    def __init__(self, sandbox: DockerSandbox) -> None:
        self._sandbox = sandbox

    @property
    def name(self) -> str:
        return "sandbox"

    @property
    def description(self) -> str:
        return "Execute a command in an isolated Docker sandbox."

    @property
    def definition(self) -> dict[str, Any]:
        return TOOL_DEFINITION

    async def execute(self, command: str, timeout: int = 30, workdir: str = "/workspace") -> ToolResult:
        """Execute a command in the sandbox."""
        try:
            result = self._sandbox.run(
                command=command,
                timeout=timeout,
                workdir=workdir,
            )

            output_parts = []
            if result.stdout.strip():
                output_parts.append(result.stdout.strip())
            if result.stderr.strip():
                output_parts.append(f"[stderr]\n{result.stderr.strip()}")

            output = "\n".join(output_parts) or f"(exit code: {result.exit_code})"

            is_error = result.exit_code != 0 and result.exit_code != 124
            return ToolResult(
                content=output,
                is_error=is_error,
            )
        except RuntimeError as e:
            return ToolResult(content=str(e), is_error=True)
