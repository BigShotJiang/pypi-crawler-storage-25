"""Web search and fetch tool — search the web and extract page content."""

from __future__ import annotations

import re
import subprocess
import urllib.parse
from dataclasses import dataclass, field

from deepcraft.agent.tools.base import BaseTool, ToolResult


@dataclass
class WebSearchTool(BaseTool):
    """Search the web using DuckDuckGo HTML (no API key needed)."""

    name: str = "web_search"
    description: str = (
        "Search the web and return results with titles, URLs, and snippets. "
        "Use for: looking up documentation, finding examples, researching errors, "
        "checking library versions, reading blog posts. "
        "Returns top 5 results by default."
    )
    parameters: dict = field(
        default_factory=lambda: {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query string",
                },
                "num_results": {
                    "type": "integer",
                    "description": "Number of results to return (default: 5, max: 10)",
                },
            },
            "required": ["query"],
        }
    )

    async def execute(self, query: str, num_results: int = 5, **kwargs) -> ToolResult:
        """Execute a web search via DuckDuckGo HTML."""
        num_results = min(num_results, 10)
        try:
            # DuckDuckGo HTML search (no API key needed)
            url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote(query)}"
            result = subprocess.run(
                [
                    "curl",
                    "-s",
                    "--connect-timeout",
                    "10",
                    "--max-time",
                    "15",
                    "-H",
                    "User-Agent: Mozilla/5.0 (compatible; DeepCraft/1.0)",
                    url,
                ],
                capture_output=True,
                text=True,
                timeout=20,
            )
            if result.returncode != 0:
                return ToolResult(content=f"Search failed: {result.stderr}", is_error=True)

            # Extract result snippets from DuckDuckGo HTML
            results = self._parse_ddg_html(result.stdout, num_results)
            if not results:
                return ToolResult(content="No results found.")

            output = "\n\n".join(
                f"{i}. **{r['title']}**\n   URL: {r['url']}\n   {r['snippet']}" for i, r in enumerate(results, 1)
            )
            return ToolResult(content=output)
        except subprocess.TimeoutExpired:
            return ToolResult(content="Search timed out.", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Search error: {e}", is_error=True)

    @staticmethod
    def _parse_ddg_html(html: str, limit: int) -> list[dict]:
        """Parse DuckDuckGo HTML results."""
        results = []
        # Each result is in a div with class "result"
        # Pattern: <a class="result__a" href="URL">Title</a>
        #          <a class="result__snippet">Snippet</a>
        blocks = re.split(r'<div class="[^"]*result[^"]*"', html)[1:]
        for block in blocks[:limit]:
            title_match = re.search(r'class="result__a"[^>]*href="([^"]*)"[^>]*>([^<]*)</a>', block)
            snippet_match = re.search(r'class="result__snippet"[^>]*>(.*?)</a>', block)
            if title_match:
                results.append(
                    {
                        "title": title_match.group(2).strip(),
                        "url": title_match.group(1).strip(),
                        "snippet": (re.sub(r"<[^>]+>", "", snippet_match.group(1).strip()) if snippet_match else ""),
                    }
                )
        return results


@dataclass
class WebFetchTool(BaseTool):
    """Fetch and extract text content from a URL."""

    name: str = "web_fetch"
    description: str = (
        "Fetch a web page and extract its readable text content. "
        "Use after web_search to read full article/documentation content. "
        "Strips HTML, scripts, and styles. Returns plain text."
    )
    parameters: dict = field(
        default_factory=lambda: {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "URL of the page to fetch",
                },
                "max_chars": {
                    "type": "integer",
                    "description": "Maximum characters to return (default: 5000, max: 20000)",
                },
            },
            "required": ["url"],
        }
    )

    async def execute(self, url: str, max_chars: int = 5000, **kwargs) -> ToolResult:
        """Fetch a URL and extract text content."""
        max_chars = min(max_chars, 20000)
        try:
            result = subprocess.run(
                [
                    "curl",
                    "-s",
                    "-L",
                    "--connect-timeout",
                    "10",
                    "--max-time",
                    "20",
                    "-H",
                    "User-Agent: Mozilla/5.0 (compatible; DeepCraft/1.0)",
                    url,
                ],
                capture_output=True,
                text=True,
                timeout=25,
            )
            if result.returncode != 0:
                return ToolResult(content=f"Fetch failed: {result.stderr}", is_error=True)

            # Extract text from HTML
            text = self._html_to_text(result.stdout)
            if len(text) > max_chars:
                text = text[:max_chars] + f"\n\n... (truncated, {len(text)} chars total)"
            return ToolResult(content=text if text.strip() else "(Empty page)")
        except subprocess.TimeoutExpired:
            return ToolResult(content="Fetch timed out.", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Fetch error: {e}", is_error=True)

    @staticmethod
    def _html_to_text(html: str) -> str:
        """Strip HTML tags and extract readable text."""
        # Remove scripts and styles
        html = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL | re.IGNORECASE)
        html = re.sub(r"<style[^>]*>.*?</style>", "", html, flags=re.DOTALL | re.IGNORECASE)
        html = re.sub(r"<nav[^>]*>.*?</nav>", "", html, flags=re.DOTALL | re.IGNORECASE)
        html = re.sub(r"<header[^>]*>.*?</header>", "", html, flags=re.DOTALL | re.IGNORECASE)
        html = re.sub(r"<footer[^>]*>.*?</footer>", "", html, flags=re.DOTALL | re.IGNORECASE)
        # Replace common block elements with newlines
        for tag in ["br", "p", "div", "li", "h1", "h2", "h3", "h4", "h5", "h6", "tr"]:
            html = re.sub(rf"</?{tag}[^>]*>", "\n", html, flags=re.IGNORECASE)
        # Strip remaining tags
        text = re.sub(r"<[^>]+>", "", html)
        # Decode HTML entities
        import html as html_mod

        text = html_mod.unescape(text)
        # Collapse whitespace
        text = re.sub(r"\n\s*\n", "\n\n", text)
        text = re.sub(r"[ \t]+", " ", text)
        return text.strip()
