"""Checkpoint Manager — file snapshot system for rollback.

Before any file-modifying tool writes, it calls checkpoint.save(path).
Snapshots are stored in .deepcraft/checkpoints/ with incrementing IDs.
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


@dataclass
class Snapshot:
    """A single file snapshot."""

    id: int
    path: str
    backup_path: Path
    timestamp: datetime = field(default_factory=datetime.now)


class CheckpointManager:
    """Manages file snapshots for rollback.

    Usage:
        ck = CheckpointManager(max_snapshots=30)
        ck.save_before_write("/path/to/file.py")  # before modifying
        ck.save_before_write("/path/to/file.py")  # another snapshot
        ck.rollback(1)  # restore to snapshot #1

    Snapshots are stored in .deepcraft/checkpoints/ under the project root.
    """

    def __init__(self, project_root: str | Path = ".", max_snapshots: int = 30):
        self.project_root = Path(project_root).resolve()
        self.checkpoint_dir = self.project_root / ".deepcraft" / "checkpoints"
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.max_snapshots = max_snapshots
        self._snapshots: list[Snapshot] = []
        self._next_id = 1
        self._load_existing()

    def _load_existing(self) -> None:
        """Scan existing checkpoints on disk."""
        if not self.checkpoint_dir.exists():
            return
        for entry in sorted(self.checkpoint_dir.iterdir()):
            if entry.is_dir() and entry.name.isdigit():
                sid = int(entry.name)
                meta_file = entry / ".meta"
                if meta_file.exists():
                    original_path = meta_file.read_text().strip()
                    # Find the backed-up file
                    backup = entry / Path(original_path).name
                    if backup.exists():
                        self._snapshots.append(Snapshot(id=sid, path=original_path, backup_path=backup))
                        self._next_id = max(self._next_id, sid + 1)

    def save_before_write(self, filepath: str | Path) -> int:
        """Save a snapshot of the file before it gets modified.

        Returns the snapshot ID.
        """
        src = Path(filepath)
        if not src.exists():
            return 0  # File doesn't exist yet, nothing to snapshot

        sid = self._next_id
        self._next_id += 1

        snap_dir = self.checkpoint_dir / str(sid)
        snap_dir.mkdir(parents=True, exist_ok=True)

        # Copy the file
        dest = snap_dir / src.name
        shutil.copy2(src, dest)

        # Save metadata: original path
        (snap_dir / ".meta").write_text(str(src))

        # Save timestamp
        (snap_dir / ".timestamp").write_text(datetime.now().isoformat())

        snapshot = Snapshot(id=sid, path=str(src), backup_path=dest)
        self._snapshots.append(snapshot)

        # Prune old snapshots
        while len(self._snapshots) > self.max_snapshots:
            oldest = self._snapshots.pop(0)
            shutil.rmtree(self.checkpoint_dir / str(oldest.id), ignore_errors=True)

        return sid

    def rollback(self, snapshot_id: int | None = None) -> str | None:
        """Restore file(s) from a snapshot.

        If snapshot_id is given, rollback to that specific snapshot.
        If None, rollback to the most recent snapshot.
        Returns the restored file path, or None if no snapshots.
        """
        if not self._snapshots:
            return None

        if snapshot_id is not None:
            target = next((s for s in self._snapshots if s.id == snapshot_id), None)
            if target is None:
                return None
        else:
            target = self._snapshots[-1]

        # Restore the file
        original = Path(target.path)
        shutil.copy2(target.backup_path, original)

        # Remove this and all newer snapshots
        idx = self._snapshots.index(target)
        for s in self._snapshots[idx:]:
            shutil.rmtree(self.checkpoint_dir / str(s.id), ignore_errors=True)
        self._snapshots = self._snapshots[:idx]

        return str(original)

    def list_snapshots(self) -> list[dict]:
        """Return list of snapshots for display."""
        return [
            {
                "id": s.id,
                "path": s.path,
                "filename": Path(s.path).name,
                "timestamp": s.timestamp.isoformat() if s.timestamp else "?",
            }
            for s in self._snapshots
        ]

    def clear(self) -> None:
        """Remove all checkpoints."""
        shutil.rmtree(self.checkpoint_dir, ignore_errors=True)
        self._snapshots.clear()
        self._next_id = 1
