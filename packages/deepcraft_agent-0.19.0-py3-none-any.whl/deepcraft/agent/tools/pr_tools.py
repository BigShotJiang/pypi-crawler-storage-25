"""PR tools — GitHub Pull Request operations for the Agent."""

from __future__ import annotations

from typing import Any

from deepcraft.agent.pr_workflow import PRWorkflow
from deepcraft.agent.tools.base import Tool, ToolResult

CREATE_PR_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "create_pr",
        "description": (
            "Create a new GitHub Pull Request from the current branch. "
            "Use this after making code changes to propose merging into main."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "PR title. Use conventional commit format (e.g., 'feat: add...').",
                },
                "body": {
                    "type": "string",
                    "description": "PR description in markdown. Include summary and test plan.",
                },
                "base_branch": {
                    "type": "string",
                    "description": "Target branch (default: main).",
                },
                "draft": {
                    "type": "boolean",
                    "description": "Create as draft PR (default: false).",
                },
            },
            "required": ["title", "body"],
        },
    },
}

LIST_PRS_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "list_prs",
        "description": (
            "List pull requests for the current repository. "
            "Shows open PRs by default."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "state": {
                    "type": "string",
                    "enum": ["open", "closed", "all"],
                    "description": "Filter by state (default: open).",
                },
            },
        },
    },
}

PR_STATUS_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "pr_status",
        "description": (
            "Check CI status for a pull request. "
            "Shows which checks passed, failed, or are pending."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "pr_number": {
                    "type": "integer",
                    "description": "PR number to check.",
                },
            },
            "required": ["pr_number"],
        },
    },
}

MERGE_PR_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "merge_pr",
        "description": (
            "Merge a pull request. Choose squash (one commit), "
            "merge (merge commit), or rebase. "
            "IMPORTANT: Only merge when all CI checks pass."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "pr_number": {
                    "type": "integer",
                    "description": "PR number to merge.",
                },
                "method": {
                    "type": "string",
                    "enum": ["squash", "merge", "rebase"],
                    "description": "Merge method (default: squash).",
                },
            },
            "required": ["pr_number"],
        },
    },
}


class CreatePRTool(Tool):
    """Create a Pull Request on GitHub."""

    def __init__(self, workflow: PRWorkflow | None = None) -> None:
        try:
            self._workflow = workflow or PRWorkflow.auto()
        except Exception:
            self._workflow = None

    @property
    def name(self) -> str:
        return "create_pr"

    @property
    def description(self) -> str:
        return "Create a Pull Request from the current branch."

    @property
    def definition(self) -> dict[str, Any]:
        return CREATE_PR_DEFINITION

    async def execute(
        self,
        title: str,
        body: str,
        base_branch: str = "main",
        draft: bool = False,
    ) -> ToolResult:
        if self._workflow is None:
            return ToolResult(
                content="PR workflow not available. "
                "Check GitHub token and git remote configuration.",
                is_error=True,
            )
        try:
            pr = self._workflow.create_pr(
                title=title,
                body=body,
                base_branch=base_branch,
                draft=draft,
            )
            return ToolResult(
                content=self._workflow.format_pr(pr),
                is_error=False,
            )
        except Exception as e:
            return ToolResult(content=f"Failed to create PR: {e}", is_error=True)


class ListPRsTool(Tool):
    """List pull requests."""

    def __init__(self, workflow: PRWorkflow | None = None) -> None:
        try:
            self._workflow = workflow or PRWorkflow.auto()
        except Exception:
            self._workflow = None

    @property
    def name(self) -> str:
        return "list_prs"

    @property
    def description(self) -> str:
        return "List pull requests for the repository."

    @property
    def definition(self) -> dict[str, Any]:
        return LIST_PRS_DEFINITION

    async def execute(self, state: str = "open") -> ToolResult:
        if self._workflow is None:
            return ToolResult(
                content="PR workflow not available.", is_error=True
            )
        try:
            prs = self._workflow.list_prs(state=state)
            return ToolResult(
                content=self._workflow.format_list(prs),
                is_error=False,
            )
        except Exception as e:
            return ToolResult(content=f"Failed: {e}", is_error=True)


class PRStatusTool(Tool):
    """Check CI status for a PR."""

    def __init__(self, workflow: PRWorkflow | None = None) -> None:
        try:
            self._workflow = workflow or PRWorkflow.auto()
        except Exception:
            self._workflow = None

    @property
    def name(self) -> str:
        return "pr_status"

    @property
    def description(self) -> str:
        return "Check CI status for a pull request."

    @property
    def definition(self) -> dict[str, Any]:
        return PR_STATUS_DEFINITION

    async def execute(self, pr_number: int) -> ToolResult:
        if self._workflow is None:
            return ToolResult(
                content="PR workflow not available.", is_error=True
            )
        try:
            status = self._workflow.pr_status(pr_number)
            return ToolResult(
                content=self._workflow.format_status(status),
                is_error=False,
            )
        except Exception as e:
            return ToolResult(content=f"Failed: {e}", is_error=True)


class MergePRTool(Tool):
    """Merge a pull request."""

    def __init__(self, workflow: PRWorkflow | None = None) -> None:
        try:
            self._workflow = workflow or PRWorkflow.auto()
        except Exception:
            self._workflow = None

    @property
    def name(self) -> str:
        return "merge_pr"

    @property
    def description(self) -> str:
        return "Merge a pull request (use only when CI is green)."

    @property
    def definition(self) -> dict[str, Any]:
        return MERGE_PR_DEFINITION

    async def execute(
        self, pr_number: int, method: str = "squash"
    ) -> ToolResult:
        if self._workflow is None:
            return ToolResult(
                content="PR workflow not available.", is_error=True
            )
        try:
            result = self._workflow.merge_pr(pr_number, method)
            merged = result.get("merged", False)
            msg = result.get("message", "")
            if merged:
                return ToolResult(
                    content=f"✅ Merged PR #{pr_number} ({method}): {msg}",
                    is_error=False,
                )
            else:
                return ToolResult(
                    content=f"⚠️ Merge returned: {msg}", is_error=False
                )
        except Exception as e:
            return ToolResult(content=f"Merge failed: {e}", is_error=True)
