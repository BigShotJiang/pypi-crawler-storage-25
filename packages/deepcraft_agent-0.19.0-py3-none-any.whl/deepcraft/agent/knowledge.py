"""RAG Knowledge Base — semantic document search with zero new dependencies.

Uses TF-IDF + cosine similarity for document retrieval.
Pure Python — no embedding APIs or ML libraries needed.

Architecture:
    KnowledgeBase → chunk documents → TF-IDF index → cosine search
    Backend is pluggable via EmbeddingBackend protocol.
"""

from __future__ import annotations

import json
import math
import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol

# ------------------------------------------------------------------
# Data types
# ------------------------------------------------------------------


@dataclass
class Chunk:
    """A document chunk with content and metadata."""

    text: str
    source: str  # File path
    chunk_index: int
    heading: str = ""  # Nearest heading


@dataclass
class SearchResult:
    """A single search result."""

    chunk: Chunk
    score: float  # Cosine similarity 0-1


# ------------------------------------------------------------------
# Embedding backend protocol
# ------------------------------------------------------------------


class EmbeddingBackend(Protocol):
    """Protocol for pluggable embedding backends."""

    def encode(self, texts: list[str]) -> list[list[float]]: ...

    @property
    def dim(self) -> int: ...


# ------------------------------------------------------------------
# TF-IDF Backend (default, zero-dependency)
# ------------------------------------------------------------------


class TfidfBackend:
    """TF-IDF vectorizer with cosine similarity.

    Pure Python — no dependencies.
    Supports incremental indexing (add documents after initial fit).
    """

    def __init__(self, max_features: int = 5000) -> None:
        self._max_features = max_features
        self._vocabulary: dict[str, int] = {}  # word → index
        self._idf: dict[int, float] = {}  # index → idf value
        self._doc_count = 0
        self._fitted = False

    @property
    def dim(self) -> int:
        return len(self._vocabulary)

    def _tokenize(self, text: str) -> list[str]:
        """Tokenize text into lowercase words (Chinese + English)."""
        # Split on whitespace and punctuation, keep Chinese characters
        tokens: list[str] = []
        # Chinese: extract consecutive CJK characters
        cjk_runs = re.findall(r"[\u4e00-\u9fff\u3400-\u4dbf]+", text)
        for run in cjk_runs:
            # Split CJK into bigrams for better matching
            for i in range(len(run)):
                if i < len(run) - 1:
                    tokens.append(run[i : i + 2])
        # English: extract words
        words = re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*", text.lower())
        tokens.extend(words)
        return tokens

    def fit(self, documents: list[str]) -> None:
        """Build vocabulary and compute IDF from a corpus."""
        # Count document frequency for each term
        df: Counter[str] = Counter()
        for doc in documents:
            terms = set(self._tokenize(doc))
            for term in terms:
                df[term] += 1

        self._doc_count = len(documents)

        # Build vocabulary (top max_features by document frequency)
        top_terms = df.most_common(self._max_features)
        self._vocabulary = {term: idx for idx, (term, _) in enumerate(top_terms)}

        # Compute IDF
        for term, idx in self._vocabulary.items():
            self._idf[idx] = math.log((self._doc_count + 1) / (df[term] + 1)) + 1.0

        self._fitted = True

    def encode(self, texts: list[str]) -> list[list[float]]:
        """Convert texts to TF-IDF vectors."""
        if not self._fitted:
            # Auto-fit on first call
            self.fit(texts)

        vectors: list[list[float]] = []
        for text in texts:
            tokens = self._tokenize(text)
            tf = Counter(tokens)

            # Build sparse then dense vector
            vec = [0.0] * len(self._vocabulary)
            for term, count in tf.items():
                idx = self._vocabulary.get(term)
                if idx is not None and idx in self._idf:
                    vec[idx] = (1 + math.log(count)) * self._idf[idx]

            # L2 normalize
            norm = math.sqrt(sum(v * v for v in vec))
            if norm > 0:
                vec = [v / norm for v in vec]

            vectors.append(vec)

        return vectors

    def add_vocabulary(self, texts: list[str]) -> None:
        """Extend vocabulary with new terms from additional documents.

        Updates IDF values incrementally.
        """
        if not self._fitted:
            self.fit(texts)
            return

        # Count new terms
        df: Counter[str] = Counter()
        for doc in texts:
            terms = set(self._tokenize(doc))
            for term in terms:
                df[term] += 1

        self._doc_count += len(texts)

        # Add new terms to vocabulary
        new_terms = [(t, c) for t, c in df.items() if t not in self._vocabulary]
        new_terms.sort(key=lambda x: -x[1])
        new_terms = new_terms[: self._max_features - len(self._vocabulary)]

        for term, count in new_terms:
            idx = len(self._vocabulary)
            self._vocabulary[term] = idx
            self._idf[idx] = math.log((self._doc_count + 1) / (count + 1)) + 1.0

    def to_dict(self) -> dict[str, Any]:
        """Serialize for persistence."""
        return {
            "vocabulary": self._vocabulary,
            "idf": {str(k): v for k, v in self._idf.items()},
            "doc_count": self._doc_count,
            "max_features": self._max_features,
            "fitted": self._fitted,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TfidfBackend:
        """Restore from serialized state."""
        obj = cls(max_features=data["max_features"])
        obj._vocabulary = data["vocabulary"]
        obj._idf = {int(k): v for k, v in data["idf"].items()}
        obj._doc_count = data["doc_count"]
        obj._fitted = data["fitted"]
        return obj


# ------------------------------------------------------------------
# Knowledge Base
# ------------------------------------------------------------------


@dataclass
class KnowledgeBase:
    """Document knowledge base with semantic search.

    Usage:
        kb = KnowledgeBase(backend=TfidfBackend())
        kb.add_file("docs/architecture.md")
        kb.add_file("README.md")
        results = kb.search("How does the agent loop work?")
        for r in results:
            print(f"{r.score:.2f}: {r.chunk.text[:100]}...")
    """

    backend: EmbeddingBackend = field(default_factory=TfidfBackend)
    _chunks: list[Chunk] = field(default_factory=list)
    _vectors: list[list[float]] = field(default_factory=list)
    _storage_dir: Path = Path.home() / ".deepcraft" / "knowledge"

    # ------------------------------------------------------------------
    # Document ingestion
    # ------------------------------------------------------------------

    def add_file(self, filepath: str | Path, force: bool = False) -> int:
        """Add a file to the knowledge base. Returns number of chunks added.

        Args:
            filepath: Path to a .md, .py, .txt, or .rst file.
            force: Re-index even if already present.

        Returns:
            Number of chunks indexed.
        """
        path = Path(filepath).resolve()
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")

        # Check if already indexed
        if not force and any(c.source == str(path) for c in self._chunks):
            return 0

        # Remove old chunks for this file
        self._chunks = [c for c in self._chunks if c.source != str(path)]

        # Read and chunk
        text = path.read_text(encoding="utf-8", errors="replace")
        chunks = self._chunk_document(text, str(path))

        if not chunks:
            return 0

        # Embed
        chunk_texts = [c.text for c in chunks]
        if isinstance(self.backend, TfidfBackend) and not self.backend._fitted:
            self.backend.fit(chunk_texts)
        else:
            self.backend.add_vocabulary(chunk_texts)

        vectors = self.backend.encode(chunk_texts)

        self._chunks.extend(chunks)
        self._vectors.extend(vectors)

        return len(chunks)

    def add_directory(self, dirpath: str | Path, glob: str = "*.md") -> int:
        """Add all matching files from a directory. Returns total chunks added."""
        path = Path(dirpath)
        total = 0
        for file in sorted(path.rglob(glob)):
            try:
                total += self.add_file(file)
            except Exception:
                continue
        return total

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(self, query: str, top_k: int = 5, min_score: float = 0.05) -> list[SearchResult]:
        """Search the knowledge base for relevant chunks.

        Args:
            query: Natural language query.
            top_k: Maximum number of results.
            min_score: Minimum cosine similarity threshold.

        Returns:
            Ranked list of SearchResult, best first.
        """
        if not self._chunks:
            return []

        # Embed query
        query_vec = self.backend.encode([query])[0]

        # Cosine similarity with all chunks
        results: list[SearchResult] = []
        for i, chunk_vec in enumerate(self._vectors):
            score = self._cosine(query_vec, chunk_vec)
            if score >= min_score:
                results.append(SearchResult(chunk=self._chunks[i], score=score))

        # Sort and trim
        results.sort(key=lambda r: r.score, reverse=True)
        return results[:top_k]

    # ------------------------------------------------------------------
    # Management
    # ------------------------------------------------------------------

    def list_documents(self) -> list[str]:
        """List unique source files in the knowledge base."""
        return sorted({c.source for c in self._chunks})

    def clear(self) -> None:
        """Remove all documents and reset backend."""
        self._chunks = []
        self._vectors = []
        self.backend = TfidfBackend()

    def stats(self) -> dict[str, Any]:
        """Return knowledge base statistics."""
        return {
            "documents": len(self.list_documents()),
            "chunks": len(self._chunks),
            "vocabulary_size": len(self.backend._vocabulary) if hasattr(self.backend, "_vocabulary") else 0,
        }

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: str | None = None) -> None:
        """Save knowledge base to disk."""
        save_path = Path(path) if path else self._storage_dir
        save_path.mkdir(parents=True, exist_ok=True)

        # Save chunks
        chunks_data = [
            {
                "text": c.text,
                "source": c.source,
                "chunk_index": c.chunk_index,
                "heading": c.heading,
            }
            for c in self._chunks
        ]
        (save_path / "chunks.json").write_text(
            json.dumps(chunks_data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        # Save vectors
        (save_path / "vectors.json").write_text(
            json.dumps(self._vectors),
            encoding="utf-8",
        )

        # Save backend state
        if hasattr(self.backend, "to_dict"):
            (save_path / "backend.json").write_text(
                json.dumps(self.backend.to_dict(), ensure_ascii=False),
                encoding="utf-8",
            )

    def load(self, path: str | None = None) -> bool:
        """Load knowledge base from disk. Returns True if successful."""
        load_path = Path(path) if path else self._storage_dir
        if not load_path.exists():
            return False

        try:
            # Load chunks
            chunks_data = json.loads((load_path / "chunks.json").read_text(encoding="utf-8"))
            self._chunks = [
                Chunk(
                    text=d["text"],
                    source=d["source"],
                    chunk_index=d["chunk_index"],
                    heading=d.get("heading", ""),
                )
                for d in chunks_data
            ]

            # Load vectors
            self._vectors = json.loads((load_path / "vectors.json").read_text(encoding="utf-8"))

            # Load backend
            backend_path = load_path / "backend.json"
            if backend_path.exists() and isinstance(self.backend, TfidfBackend):
                backend_data = json.loads(backend_path.read_text(encoding="utf-8"))
                self.backend = TfidfBackend.from_dict(backend_data)

            return True
        except (json.JSONDecodeError, KeyError, FileNotFoundError):
            return False

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _chunk_document(self, text: str, source: str, chunk_size: int = 500) -> list[Chunk]:
        """Split a document into overlapping chunks."""
        chunks: list[Chunk] = []
        lines = text.split("\n")
        current_heading = ""
        current_chunk: list[str] = []
        current_len = 0
        chunk_idx = 0

        for line in lines:
            # Track headings
            if line.startswith("#"):
                heading_match = re.match(r"^#+\s+(.*)", line)
                if heading_match:
                    current_heading = heading_match.group(1)

            current_chunk.append(line)
            current_len += len(line)

            if current_len >= chunk_size and line.strip():
                chunk_text = "\n".join(current_chunk)
                chunks.append(
                    Chunk(
                        text=chunk_text,
                        source=source,
                        chunk_index=chunk_idx,
                        heading=current_heading,
                    )
                )
                chunk_idx += 1
                # Overlap: keep last 2 lines for context
                current_chunk = current_chunk[-2:] if len(current_chunk) > 2 else []
                current_len = sum(len(ln) for ln in current_chunk)

        # Don't miss the last chunk
        if current_chunk:
            chunk_text = "\n".join(current_chunk)
            chunks.append(
                Chunk(
                    text=chunk_text,
                    source=source,
                    chunk_index=chunk_idx,
                    heading=current_heading,
                )
            )

        return chunks

    @staticmethod
    def _cosine(a: list[float], b: list[float]) -> float:
        """Cosine similarity between two vectors."""
        if not a or not b:
            return 0.0
        dot = sum(x * y for x, y in zip(a, b, strict=False))
        return max(0.0, min(1.0, dot))  # Normalize for numerical stability
