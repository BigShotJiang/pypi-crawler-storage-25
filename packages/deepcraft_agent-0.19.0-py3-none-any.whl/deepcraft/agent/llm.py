"""DeepSeek API client with streaming and tool-call support."""

from __future__ import annotations

from collections.abc import AsyncIterator

import httpx

from deepcraft.agent.types import (
    ChatMessage,
    LLMResponse,
    ToolDefinition,
)
from deepcraft.config import (
    DEEPSEEK_API_KEY,
    DEEPSEEK_BASE_URL,
    DEEPSEEK_MAX_TOKENS,
    DEEPSEEK_MODEL,
)


class DeepSeekLLM:
    """Async DeepSeek chat API client."""

    def __init__(self, model: str | None = None) -> None:
        self.model = model or DEEPSEEK_MODEL
        self._client = httpx.AsyncClient(
            base_url=DEEPSEEK_BASE_URL,
            headers={
                "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(120.0),
        )

    async def chat(
        self,
        messages: list[ChatMessage],
        tools: list[ToolDefinition] | None = None,
        stream: bool = True,
    ) -> AsyncIterator[LLMResponse]:
        """Send a chat completion request, yielding responses as they stream."""
        body: dict[str, object] = {
            "model": self.model,
            "messages": [m.model_dump(exclude_none=True) for m in messages],
            "max_tokens": DEEPSEEK_MAX_TOKENS,
            "stream": stream,
        }
        if tools:
            body["tools"] = [t.model_dump(exclude_none=True) for t in tools]

        async with self._client.stream("POST", "/v1/chat/completions", json=body) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data = line[6:].strip()
                if data == "[DONE]":
                    break
                result = LLMResponse.from_chunk(data)
                if result is not None:
                    yield result

    async def complete(self, prompt: str, max_tokens: int = 500) -> str:
        """Non-streaming completion for summaries / compression."""
        body: dict[str, object] = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "stream": False,
        }
        resp = await self._client.post("/v1/chat/completions", json=body)
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"]

    async def close(self) -> None:
        await self._client.aclose()
