"""Test generator — AST-based pytest test skeleton generation.

Analyzes Python source files and generates sensible pytest test functions
with fixtures, mocks, and edge case coverage.

Architecture:
    AST parse → Identify testable units → Generate test skeletons → Write file
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass
from pathlib import Path

# ------------------------------------------------------------------
# Data types
# ------------------------------------------------------------------


@dataclass
class TestTarget:
    """A single testable unit (function, method, or class)."""

    name: str
    kind: str  # "function", "method", "class", "async_function", "async_method"
    line: int
    signature: str  # e.g. "def foo(a: int, b: str = '') -> bool"
    params: list[dict[str, str]]  # [{"name":"a","type":"int","default":""}]
    docstring: str
    raises: list[str]  # Detected exception types
    has_side_effects: bool  # Writes to file/network/DB
    is_async: bool


@dataclass
class TestSuite:
    """Generated test suite for a source file."""

    source_path: Path
    test_path: Path
    imports: list[str]
    fixtures: list[str]
    test_functions: list[str]
    target_count: int


# ------------------------------------------------------------------
# Test Generator
# ------------------------------------------------------------------


class TestGenerator:
    """Generate pytest test skeletons from Python source code.

    Usage:
        gen = TestGenerator()
        suite = gen.generate("deepcraft/agent/loop.py")
        print(suite.test_code)
        gen.write_test_file(suite)  # → tests/test_loop.py
    """

    # Templates for common test patterns
    FUNCTION_TEST = '''def test_{name}():
    """Test {name}. {doc_first_line}"""
    # Arrange
{arrange}
    # Act
    result = {call}

    # Assert
    assert result is not None, "Expected non-None result"
    {extra_asserts}
'''

    ASYNC_TEST = '''@pytest.mark.asyncio
async def test_{name}():
    """Test {name}. {doc_first_line}"""
    # Arrange
{arrange}
    # Act
    result = await {call}

    # Assert
    assert result is not None, "Expected non-None result"
    {extra_asserts}
'''

    CLASS_TEST = '''class Test{ClassName}:
    """Tests for {ClassName}."""

    def test_init(self):
        """Test {ClassName}.__init__."""
{init_body}

    def test_{method_name}(self):
        """Test {ClassName}.{method_name}. {doc_first_line}"""
        # Arrange
{arrange}
        # Act
        result = {instance}.{call}

        # Assert
        {extra_asserts}
'''

    EDGE_CASE_TEST = '''def test_{name}_edge_cases():
    """Test {name} edge cases: empty input, None, boundary values."""
{body}
'''

    ERROR_TEST = '''def test_{name}_raises_{exc}():
    """Test {name} raises {exc} on invalid input."""
    with pytest.raises({exc}):
        {name}({bad_args})
'''

    FIXTURE_TEMPLATE = '''@pytest.fixture
def {name}():
    """Set up {name} for testing."""
    {setup_code}
    yield {yield_val}
'''

    def __init__(
        self,
        test_dir: str = "tests",
        use_mocks: bool = True,
        generate_edge_cases: bool = True,
        generate_error_cases: bool = True,
    ) -> None:
        self._test_dir = test_dir
        self._use_mocks = use_mocks
        self._generate_edge_cases = generate_edge_cases
        self._generate_error_cases = generate_error_cases

    # ------------------------------------------------------------------
    # Main API
    # ------------------------------------------------------------------

    def generate(self, source_path: str | Path) -> TestSuite:
        """Generate test suite for a source file.

        Args:
            source_path: Path to the .py file to generate tests for.

        Returns:
            TestSuite with generated test code.
        """
        spath = Path(source_path).resolve()
        if not spath.exists():
            raise FileNotFoundError(f"Source file not found: {spath}")

        source = spath.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(spath))

        # Analyze
        targets = self._analyze(tree, source, spath)

        # Generate
        imports, fixtures, tests = self._generate_code(targets, spath)

        # Determine test path
        test_path = self._get_test_path(spath)

        return TestSuite(
            source_path=spath,
            test_path=test_path,
            imports=imports,
            fixtures=fixtures,
            test_functions=tests,
            target_count=len(targets),
        )

    def generate_directory(self, dirpath: str | Path, pattern: str = "*.py") -> list[TestSuite]:
        """Generate tests for all matching files in a directory."""
        dp = Path(dirpath)
        suites: list[TestSuite] = []
        for py_file in sorted(dp.rglob(pattern)):
            if "test_" in py_file.name or py_file.name.startswith("_"):
                continue
            try:
                suites.append(self.generate(py_file))
            except (SyntaxError, FileNotFoundError):
                continue
        return suites

    def write_test_file(self, suite: TestSuite) -> Path:
        """Write test code to file. Returns the path."""
        suite.test_path.parent.mkdir(parents=True, exist_ok=True)
        code = self._render_suite(suite)
        suite.test_path.write_text(code, encoding="utf-8")
        return suite.test_path

    # ------------------------------------------------------------------
    # AST Analysis
    # ------------------------------------------------------------------

    def _analyze(self, tree: ast.AST, source: str, path: Path) -> list[TestTarget]:
        """Extract testable targets from AST."""
        targets: list[TestTarget] = []

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                # Skip private and dunder methods
                if node.name.startswith("_") and not node.name.startswith("__init__"):
                    continue
                if node.name.startswith("test_"):
                    continue

                target = self._analyze_function(node, source, in_class=False)
                if target:
                    targets.append(target)

        return targets

    def _analyze_function(self, node: ast.FunctionDef, source: str, in_class: bool = False) -> TestTarget | None:
        """Analyze a single function/method."""
        # Build signature
        deco = "async " if isinstance(node, ast.AsyncFunctionDef) else ""
        params_str = self._format_params(node)
        returns = self._get_return_annotation(node)
        returns_str = f" -> {returns}" if returns else ""
        signature = f"{deco}def {node.name}({params_str}){returns_str}"

        # Params detail
        params = self._get_param_details(node)

        # Docstring
        docstring = ast.get_docstring(node) or ""

        # Detect raises
        raises = self._detect_raises(node, source)

        # Side effects
        has_side = self._detect_side_effects(node)

        # Kind
        if isinstance(node, ast.AsyncFunctionDef):
            kind = "async_method" if in_class else "async_function"
        else:
            kind = "method" if in_class else "function"

        return TestTarget(
            name=node.name,
            kind=kind,
            line=node.lineno,
            signature=signature,
            params=params,
            docstring=docstring,
            raises=raises,
            has_side_effects=has_side,
            is_async=isinstance(node, ast.AsyncFunctionDef),
        )

    # ------------------------------------------------------------------
    # Code Generation
    # ------------------------------------------------------------------

    def _generate_code(self, targets: list[TestTarget], source_path: Path) -> tuple[list[str], list[str], list[str]]:
        """Generate imports, fixtures, and test functions."""
        imports = self._generate_imports(targets, source_path)
        fixtures = self._generate_fixtures(targets)
        tests = self._generate_tests(targets)

        return imports, fixtures, tests

    def _generate_imports(self, targets: list[TestTarget], sp: Path) -> list[str]:
        """Generate necessary imports."""
        imports = ["import pytest"]

        # Import the module under test
        # Convert path to module: deepcraft/agent/loop.py → deepcraft.agent.loop
        # Find the project root (first dir without __init__.py going up)
        module_path = sp
        parts: list[str] = []
        while module_path.suffix == ".py" or module_path.is_dir():
            if module_path.suffix == ".py":
                parts.insert(0, module_path.stem)
                module_path = module_path.parent
            else:
                # Check for __init__.py
                if (module_path / "__init__.py").exists():
                    parts.insert(0, module_path.name)
                else:
                    break
                module_path = module_path.parent

        if parts:
            mod_name = ".".join(parts)
            # Import the specific functions
            names = [t.name for t in targets if t.kind in ("function", "async_function")]
            if names:
                imports.append(f"from {mod_name} import {', '.join(names)}")
            else:
                imports.append(f"import {mod_name}")

        # Mocks
        if self._use_mocks:
            has_side = any(t.has_side_effects for t in targets)
            if has_side:
                imports.append("from unittest.mock import Mock, patch, AsyncMock")

        return imports

    def _generate_fixtures(self, targets: list[TestTarget]) -> list[str]:
        """Generate shared fixtures."""
        fixtures: list[str] = []

        # Check if any target uses common patterns that need fixtures
        has_db = any("db" in t.name.lower() or "database" in t.name.lower() for t in targets)
        has_http = any(
            "http" in t.name.lower() or "fetch" in t.name.lower() or "request" in t.name.lower() for t in targets
        )

        if has_db:
            fixtures.append(
                self.FIXTURE_TEMPLATE.format(
                    name="db_session",
                    setup_code=(
                        "# Use an in-memory SQLite for testing\n"
                        "    from sqlalchemy import create_engine\n"
                        "    engine = create_engine('sqlite:///:memory:')"
                    ),
                    yield_val="engine",
                )
            )

        if has_http and self._use_mocks:
            fixtures.append(
                self.FIXTURE_TEMPLATE.format(
                    name="mock_client",
                    setup_code="from unittest.mock import AsyncMock\n    client = AsyncMock()",
                    yield_val="client",
                )
            )

        return fixtures

    def _generate_tests(self, targets: list[TestTarget]) -> list[str]:
        """Generate test functions for all targets."""
        tests: list[str] = []

        for target in targets:
            if target.kind in ("function", "async_function"):
                tests.append(self._gen_function_test(target))
                if self._generate_edge_cases:
                    tests.append(self._gen_edge_test(target))
                if self._generate_error_cases and target.raises:
                    for exc in target.raises[:2]:  # Max 2 error tests
                        tests.append(self._gen_error_test(target, exc))

        return tests

    def _gen_function_test(self, target: TestTarget) -> str:
        """Generate a basic function test."""
        doc_first = target.docstring.split("\n")[0][:80] if target.docstring else "Basic functionality test."

        # Arrange: build parameter values
        arrange_lines = self._gen_arrange(target)

        # Call: build invocation
        call = self._gen_call(target)

        # Extra asserts based on return type
        extra = self._gen_extra_asserts(target)

        if target.is_async:
            return self.ASYNC_TEST.format(
                name=target.name,
                doc_first_line=doc_first,
                arrange="\n".join(f"    {ln}" for ln in arrange_lines) if arrange_lines else "    pass",
                call=call,
                extra_asserts=extra or "# Add specific assertions",
            )
        else:
            return self.FUNCTION_TEST.format(
                name=target.name,
                doc_first_line=doc_first,
                arrange="\n".join(f"    {ln}" for ln in arrange_lines) if arrange_lines else "    pass",
                call=call,
                extra_asserts=extra or "# Add specific assertions",
            )

    def _gen_edge_test(self, target: TestTarget) -> str:
        """Generate edge case test."""
        body_lines = ["    # Test with minimal valid input"]
        has_params = [p for p in target.params if p.get("default") == ""]

        if not target.params:
            body_lines.append(f"    result = {target.name}()")
            body_lines.append("    assert result is not None")
        elif any(p["type"] in ("str", "") for p in has_params):
            pname = has_params[0]["name"]
            body_lines.append(f'    result = {target.name}({pname}="")')
            body_lines.append("    assert result is not None, f'Empty string should not crash'")

        return self.EDGE_CASE_TEST.format(
            name=target.name,
            body="\n".join(body_lines),
        )

    def _gen_error_test(self, target: TestTarget, exc_name: str) -> str:
        """Generate error case test."""
        # Find a param that could trigger the error
        bad_args = []
        for p in target.params:
            if p["type"] == "int" and "valueerror" in exc_name.lower():
                bad_args.append(f"{p['name']}=-1")
            elif p["type"] == "str":
                bad_args.append(f"{p['name']}=None")
            else:
                bad_args.append(f"{p['name']}=None")

        return self.ERROR_TEST.format(
            name=target.name,
            exc=exc_name,
            bad_args=", ".join(bad_args[:3]) or "...",
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _gen_arrange(self, target: TestTarget) -> list[str]:
        """Generate arrange section lines."""
        lines: list[str] = []
        for p in target.params:
            if p["default"]:
                continue  # Has default, can skip
            ptype = p["type"].lower()
            if ptype in ("int", "float"):
                lines.append(f"{p['name']} = 42")
            elif ptype == "str":
                lines.append(f'{p["name"]} = "test_{p["name"]}"')
            elif ptype == "bool":
                lines.append(f"{p['name']} = True")
            elif ptype in ("list", "list[int]", "list[str]"):
                lines.append(f"{p['name']} = []")
            elif ptype in ("dict", "dict[str,str]"):
                lines.append(f"{p['name']} = {{}}")
            elif ptype == "path" or "path" in ptype:
                lines.append(f'{p["name"]} = Path("test_path")')
            else:
                lines.append(f"{p['name']} = None  # TODO: provide valid input")
        return lines

    def _gen_call(self, target: TestTarget) -> str:
        """Generate the function call expression."""
        args = []
        for p in target.params:
            if p["default"]:
                continue
            args.append(p["name"])
        return f"{target.name}({', '.join(args)})"

    def _gen_extra_asserts(self, target: TestTarget) -> str:
        """Generate extra assertions based on return type."""
        returns = self._get_return_annotation_from_sig(target.signature)
        if not returns:
            return ""
        r = returns.lower()
        if r == "bool":
            return "assert isinstance(result, bool), f'Expected bool, got {type(result)}'"
        elif r in ("int", "float"):
            return "assert isinstance(result, (int, float)), f'Expected number, got {type(result)}'"
        elif r == "str":
            return (
                "assert isinstance(result, str), "
                "f'Expected str, got {type(result)}'\n"
                "    assert len(result) > 0, 'Expected non-empty string'"
            )
        elif r.startswith("list"):
            return "assert isinstance(result, list), f'Expected list, got {type(result)}'"
        elif r == "none":
            return "assert result is None"
        return ""

    def _get_test_path(self, source_path: Path) -> Path:
        """Determine the test file path for a source file."""
        # Convert: deepcraft/agent/loop.py → tests/test_loop.py
        # Or: tests/test_agent_loop.py (keeping directory structure)
        test_name = f"test_{source_path.stem}.py"

        # Try to put in the project's test directory
        project_root = self._find_project_root(source_path)
        test_dir = project_root / self._test_dir
        return test_dir / test_name

    def _get_relative_module_path(self, path: Path) -> str:
        """Get the dotted module path relative to project root."""
        project_root = self._find_project_root(path)
        rel = path.relative_to(project_root)
        parts = list(rel.parts)
        parts[-1] = parts[-1].replace(".py", "")
        return ".".join(parts)

    @staticmethod
    def _find_project_root(path: Path) -> Path:
        """Find the project root directory."""
        current = path if path.is_dir() else path.parent
        while current != current.parent:
            if (current / "pyproject.toml").exists():
                return current
            if (current / "setup.py").exists():
                return current
            if (current / ".git").exists():
                return current
            current = current.parent
        return path.parent if path.is_file() else path

    def _render_suite(self, suite: TestSuite) -> str:
        """Render a test suite to code string."""
        lines: list[str] = [
            f'"""Auto-generated tests for {suite.source_path.name}."""',
            "",
            *suite.imports,
            "",
        ]

        if suite.fixtures:
            lines.append("# Fixtures")
            lines.extend(suite.fixtures)
            lines.append("")

        if suite.test_functions:
            lines.append("# Tests")
            lines.extend(suite.test_functions)
            lines.append("")

        lines.append(f"# Generated {suite.target_count} test(s) for {suite.source_path.name}")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # AST utility methods
    # ------------------------------------------------------------------

    def _format_params(self, node: ast.FunctionDef) -> str:
        """Format function parameters for signature display."""
        parts: list[str] = []
        for arg in node.args.args:
            name = arg.arg
            annotation = ast.unparse(arg.annotation) if arg.annotation else ""
            p = f"{name}: {annotation}" if annotation else name
            parts.append(p)

        # Add defaults
        defaults_offset = len(node.args.args) - len(node.args.defaults)
        for i, default in enumerate(node.args.defaults):
            idx = defaults_offset + i
            if idx < len(parts):
                default_str = ast.unparse(default)
                if parts[idx].endswith(": "):
                    parts[idx] = parts[idx].rstrip(": ") + f" = {default_str}"
                else:
                    parts[idx] += f" = {default_str}"

        return ", ".join(parts)

    def _get_return_annotation(self, node: ast.FunctionDef) -> str:
        """Get the return annotation as string."""
        if node.returns:
            return ast.unparse(node.returns)
        return ""

    def _get_return_annotation_from_sig(self, signature: str) -> str:
        """Extract return type from signature string."""
        m = re.search(r"\)\s*->\s*(\S+)", signature)
        return m.group(1) if m else ""

    def _get_param_details(self, node: ast.FunctionDef) -> list[dict[str, str]]:
        """Get parameter details."""
        params: list[dict[str, str]] = []
        defaults_offset = len(node.args.args) - len(node.args.defaults)
        default_values = [ast.unparse(d) for d in node.args.defaults]

        for i, arg in enumerate(node.args.args):
            ptype = ast.unparse(arg.annotation) if arg.annotation else ""
            default = ""
            if i >= defaults_offset:
                default = default_values[i - defaults_offset] if i - defaults_offset < len(default_values) else ""
            params.append({"name": arg.arg, "type": ptype, "default": default})

        return params

    def _detect_raises(self, node: ast.FunctionDef, source: str) -> list[str]:
        """Detect exception types raised in the function body."""
        raises: set[str] = set()
        for child in ast.walk(node):
            if isinstance(child, ast.Raise):
                # Try to extract exception name
                raise_lines = ast.get_source_segment(source, child)
                if raise_lines:
                    m = re.search(r"raise\s+(\w+)", raise_lines)
                    if m:
                        raises.add(m.group(1))
        return sorted(raises)

    def _detect_side_effects(self, node: ast.FunctionDef) -> bool:
        """Detect if function has side effects (file/network/DB)."""
        side_keywords = {"open(", "write(", "subprocess", "requests", "httpx", "cursor.execute"}
        for child in ast.walk(node):
            if isinstance(child, ast.Call):
                call_str = ast.dump(child)
                for kw in side_keywords:
                    if kw in call_str:
                        return True
        return False
