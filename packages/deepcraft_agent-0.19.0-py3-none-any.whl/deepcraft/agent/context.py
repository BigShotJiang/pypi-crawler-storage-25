"""Context and memory management — conversation history, compression, system prompt.

Uses PromptCache internally for layered context budgeting.
"""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING

from deepcraft.agent.prompt_cache import PromptCache
from deepcraft.agent.types import ChatMessage, Role

if TYPE_CHECKING:
    from deepcraft.providers import LLMProvider

# --- Budget (moved to prompt_cache.py for single source of truth) ---
# Re-export for backward compat
TOKENS_PER_CHAR = 0.4
MAX_CONTEXT_TOKENS = 120_000
COMPRESS_THRESHOLD = 0.75

# How many recent turns to keep verbatim (1 turn = user + assistant + tools)
KEEP_TURNS_VERBATIM = 5

SYSTEM_PROMPT = """You are DeepCraft, an AI coding agent powered by DeepSeek.

Your capabilities:
- Read, write, and search files in the project workspace
- Execute shell commands via terminal
- Manage git repositories
- Analyze code, find bugs, and suggest fixes

Guidelines:
- Be concise and direct. No fluff.
- When you need to see file contents, use read_file.
- When you need to create/modify files, use write_file.
- When you need to run commands, use terminal.
- Think step by step: understand the problem first, then act.
- If a tool fails, analyze the error and try a different approach."""


COMPRESSION_PROMPT = """Summarize the following conversation fragment. Keep it concise.
Preserve: user goals/decisions, key facts discovered, errors encountered and their fixes.
Omit: redundant tool output, repeated attempts, boilerplate.
Respond with the summary only, no preamble."""


class CompressionStrategy(str, Enum):
    """Compression strategy for context management."""

    AUTO = "auto"  # LLM-powered summary when threshold hit (default)
    AGGRESSIVE = "aggressive"  # Truncate aggressively, no LLM call
    OFF = "off"  # Never compress (may hit token limits)


class ContextManager:
    """Manages conversation context: messages, token counting, compression.

    Delegates to PromptCache for layered budgeting.
    """

    def __init__(
        self,
        system_prompt: str | None = None,
        strategy: CompressionStrategy = CompressionStrategy.AUTO,
        llm: LLMProvider | None = None,
    ) -> None:
        self._system_prompt = system_prompt or SYSTEM_PROMPT
        self._strategy = strategy
        self._llm = llm
        self._compression_count = 0
        self._cache = PromptCache(
            llm=llm,
            system_prompt=self._system_prompt,
        )

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def strategy(self) -> CompressionStrategy:
        return self._strategy

    @strategy.setter
    def strategy(self, value: CompressionStrategy) -> None:
        self._strategy = value

    @property
    def token_count(self) -> int:
        """Estimate token count (delegated to PromptCache)."""
        return self._cache.total_tokens

    @property
    def compression_count(self) -> int:
        """Number of compressions performed this session."""
        return self._cache.compression_count

    @property
    def usage_report(self) -> str:
        """Human-readable token budget report."""
        return self._cache.usage_report

    @property
    def _messages(self) -> list[ChatMessage]:
        """Access internal messages (for sub-classes, loop.py)."""
        return self._cache.get_messages()

    # ------------------------------------------------------------------
    # Codebase index
    # ------------------------------------------------------------------

    def set_codebase_index(self, index_text: str) -> None:
        """Set codebase index for fixed context layer."""
        self._cache.set_codebase_index(index_text)

    # ------------------------------------------------------------------
    # Message management
    # ------------------------------------------------------------------

    def add_message(
        self,
        role: Role | str,
        content: str | None = None,
        tool_call_id: str | None = None,
        name: str | None = None,
    ) -> None:
        """Add a message to the conversation. Auto-triggers compression if needed."""
        self._cache.add_message(
            role=role,
            content=content,
            tool_call_id=tool_call_id,
            name=name,
        )

    def get_messages(self) -> list[ChatMessage]:
        """Get all messages for LLM context (uses layered caching internally).

        Returns ChatMessage objects — the provider serializes them.
        """
        return self._cache.build_chat_messages()

    def get_full_messages(self) -> list[ChatMessage]:
        """Get all ChatMessage objects (for export/inspection)."""
        return self._cache.get_messages()

    def reset(self) -> None:
        """Reset conversation, keeping only system prompt."""
        self._cache.reset()

    def __len__(self) -> int:
        return len(self._messages)

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export(self, session_title: str = "DeepCraft Session") -> str:
        """Export conversation as Markdown.

        Returns:
            Markdown string of the full conversation.
        """
        lines = [f"# {session_title}", ""]
        for msg in self._cache.get_messages():
            if msg.role == "system":
                continue
            role_label = msg.role.upper()
            content = msg.content or ""
            if msg.tool_call_id:
                role_label = f"TOOL [{msg.tool_call_id}]"
            lines.append(f"**{role_label}**: {content}")
            lines.append("")
        return "\n".join(lines)

    def export_json(self) -> list[dict[str, object]]:
        """Export conversation as JSON-serializable list.

        Returns:
            List of message dicts with role, content, tool_call_id.
        """
        result: list[dict[str, object]] = []
        for msg in self._cache.get_messages():
            entry: dict[str, object] = {"role": msg.role}
            if msg.content:
                entry["content"] = msg.content
            if msg.tool_call_id:
                entry["tool_call_id"] = msg.tool_call_id
            if msg.tool_calls:
                entry["tool_calls"] = msg.tool_calls
            result.append(entry)
        return result
