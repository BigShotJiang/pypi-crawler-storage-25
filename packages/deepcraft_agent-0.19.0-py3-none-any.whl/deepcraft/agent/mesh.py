"""Agent Mesh — multi-agent orchestration with routing, pipelining, and broadcasting.

Three collaboration strategies:
  route     → LLM decides which agent handles the task
  pipeline  → A's output feeds B's input (e.g., coder → reviewer)
  broadcast → same task sent to all agents, results merged
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum

from rich.console import Console

from deepcraft.providers import LLMProvider

console = Console()

# ------------------------------------------------------------------
# Roles
# ------------------------------------------------------------------


class AgentRole(str, Enum):
    CODER = "coder"
    REVIEWER = "reviewer"
    RESEARCHER = "researcher"
    PLANNER = "planner"
    CUSTOM = "custom"


# Role-specific system prompts
ROLE_PROMPTS: dict[AgentRole, str] = {
    AgentRole.CODER: """You are a senior software engineer. Your task is to write clean, correct, well-documented code.
Guidelines:
- Write idiomatic Python with type hints
- Handle edge cases and errors
- Include brief comments for non-obvious logic
- Return ONLY the code with a short explanation, no preamble""",
    AgentRole.REVIEWER: """You are a principal engineer doing code review.
    Your task is to find bugs, suggest improvements, and ensure code quality.
Guidelines:
- Check for: correctness, security, performance, readability
- Be specific: point to exact lines or patterns
- Categorize issues: 🔴 critical / 🟡 suggestion / 🟢 nit
- Be constructive, not harsh""",
    AgentRole.RESEARCHER: """You are a technical researcher. Your task is to investigate, compare, and report findings.
Guidelines:
- Search for facts, not opinions
- Compare alternatives with pros/cons
- Cite sources when possible
- Structure output with clear sections""",
    AgentRole.PLANNER: """You are a technical architect.
    Your task is to break down complex problems into actionable steps.
Guidelines:
- Output a numbered task list
- Each task should be concrete and actionable
- Estimate complexity: quick / medium / heavy
- Flag dependencies between tasks""",
}

ROUTE_PROMPT = """Given a user task, decide which agent role should handle it. Roles:
- coder: writing or fixing code
- reviewer: reviewing, auditing, checking
- researcher: investigating, comparing, finding information
- planner: breaking down tasks, designing architecture

Task: {task}

Respond with ONLY the role name: coder, reviewer, researcher, or planner."""

SYNTHESIS_PROMPT = """You are a technical lead synthesizing results from multiple agents.
Given the original task and the results from each agent, produce a single coherent response.

Original task: {task}

Agent results:
{results}

Synthesized response:"""


# ------------------------------------------------------------------
# Data types
# ------------------------------------------------------------------


@dataclass
class AgentNode:
    """A single agent with a role, system prompt, and LLM provider."""

    name: str
    role: AgentRole
    system_prompt: str
    provider: LLMProvider


@dataclass
class MeshResult:
    """Result from a single agent execution."""

    node_name: str
    role: AgentRole
    output: str
    success: bool = True
    error: str = ""
    duration_ms: int = 0

    def __str__(self) -> str:
        status = "✅" if self.success else "❌"
        return f"{status} [{self.role}] {self.node_name}: {self.output[:200]}"


# ------------------------------------------------------------------
# Mesh
# ------------------------------------------------------------------


class AgentMesh:
    """Orchestrates multiple AgentNode instances with three strategies.

    Usage:
        mesh = AgentMesh(provider_factory)
        mesh.add_node("coder", AgentRole.CODER)
        mesh.add_node("reviewer", AgentRole.REVIEWER)

        # Route: LLM picks who handles it
        result = await mesh.route("write a fibonacci function")

        # Pipeline: coder writes → reviewer checks
        result = await mesh.pipeline(["coder", "reviewer"], "write a login endpoint")

        # Broadcast: everyone responds, results merged
        results = await mesh.broadcast(["coder", "reviewer", "researcher"], "best ORM?")
    """

    def __init__(self, provider_factory: Callable[..., LLMProvider] | None = None) -> None:
        self._nodes: dict[str, AgentNode] = {}
        self._factory = provider_factory
        self._router_llm: LLMProvider | None = None  # Dedicated LLM for routing decisions

    # ------------------------------------------------------------------
    # Node management
    # ------------------------------------------------------------------

    def add_node(
        self,
        name: str,
        role: AgentRole,
        system_prompt: str | None = None,
        provider: LLMProvider | None = None,
    ) -> AgentNode:
        """Add an agent node to the mesh.

        If provider is None, uses the factory to create one (default deepseek-chat).
        """
        if name in self._nodes:
            raise ValueError(f"Node '{name}' already exists")

        if provider is None and self._factory:
            provider = self._factory()

        if provider is None:
            raise ValueError(f"Node '{name}' needs a provider or a factory")

        prompt = system_prompt or ROLE_PROMPTS.get(role, "")
        node = AgentNode(name=name, role=role, system_prompt=prompt, provider=provider)
        self._nodes[name] = node
        return node

    def remove_node(self, name: str) -> bool:
        """Remove a node. Returns True if found."""
        if name in self._nodes:
            self._nodes.pop(name)
            return True
        return False

    def list_nodes(self) -> list[AgentNode]:
        """List all registered nodes."""
        return list(self._nodes.values())

    def get_node(self, name: str) -> AgentNode | None:
        """Get a node by name."""
        return self._nodes.get(name)

    # ------------------------------------------------------------------
    # Default nodes (built-in)
    # ------------------------------------------------------------------

    def setup_defaults(self) -> None:
        """Create default nodes for all built-in roles."""
        defaults = [
            ("coder", AgentRole.CODER),
            ("reviewer", AgentRole.REVIEWER),
            ("researcher", AgentRole.RESEARCHER),
            ("planner", AgentRole.PLANNER),
        ]
        for name, role in defaults:
            if name not in self._nodes:
                self.add_node(name, role)

    # ------------------------------------------------------------------
    # Execution strategies
    # ------------------------------------------------------------------

    async def route(self, task: str) -> MeshResult:
        """LLM decides which agent should handle the task, then executes it.

        Falls back to 'coder' if routing fails.
        """
        # Step 1: Decide which role
        role_name = "coder"
        if self._router_llm:
            try:
                prompt = ROUTE_PROMPT.format(task=task)
                result = await self._router_llm.complete(prompt, max_tokens=20)
                role_name = result.strip().lower()
            except Exception:
                pass

        # Step 2: Find a matching node
        node = self._nodes.get(role_name)
        if node is None:
            # Find first node with matching role
            for n in self._nodes.values():
                if n.role.value == role_name:
                    node = n
                    break
            # Fallback to first available node
            if node is None and self._nodes:
                node = next(iter(self._nodes.values()))

        if node is None:
            return MeshResult(
                node_name="none",
                role=AgentRole.CUSTOM,
                output="",
                success=False,
                error="No agent nodes registered",
            )

        return await self._execute_node(node, task)

    async def pipeline(self, node_names: list[str], task: str) -> MeshResult:
        """Execute nodes sequentially: each node's output becomes the next node's input.

        Returns the final node's result.
        """
        if not node_names:
            return MeshResult(
                node_name="none",
                role=AgentRole.CUSTOM,
                output="",
                success=False,
                error="No nodes specified",
            )

        current_task = task
        final_result: MeshResult | None = None

        for i, name in enumerate(node_names):
            node = self._nodes.get(name)
            if node is None:
                console.print(f"[yellow]⚠️  Node '{name}' not found, skipping[/]")
                continue

            msg = f"[dim]🔄 Pipeline [{i + 1}/{len(node_names)}]: {name} ({node.role})[/]"
            console.print(msg)

            result = await self._execute_node(node, current_task, label=name)
            if result.success:
                # Use this node's output as input for the next
                current_task = result.output
                final_result = result
            else:
                console.print(f"[red]❌ Pipeline broken at '{name}'[/]")
                return result

        return final_result or MeshResult(
            node_name="none",
            role=AgentRole.CUSTOM,
            output="",
            success=False,
            error="No nodes executed successfully",
        )

    async def broadcast(self, node_names: list[str], task: str) -> list[MeshResult]:
        """Execute the same task on multiple nodes in parallel. Returns all results."""
        if not node_names:
            return []

        nodes = []
        for name in node_names:
            node = self._nodes.get(name)
            if node:
                nodes.append((name, node))
            else:
                console.print(f"[yellow]⚠️  Node '{name}' not found, skipping[/]")

        if not nodes:
            return []

        console.print(f"[dim]📡 Broadcasting to {len(nodes)} agents...[/]")

        # Run in parallel
        tasks = [self._execute_node(node, task, label=name) for name, node in nodes]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Unwrap exceptions
        final: list[MeshResult] = []
        for r in results:
            if isinstance(r, Exception):
                final.append(
                    MeshResult(
                        node_name="error",
                        role=AgentRole.CUSTOM,
                        output="",
                        success=False,
                        error=str(r),
                    )
                )
            else:
                final.append(r)

        return final

    async def synthesize(self, task: str, results: list[MeshResult]) -> str:
        """Merge multiple agent results into a single coherent response using LLM."""
        if not results:
            return "No results to synthesize."

        if len(results) == 1 and results[0].success:
            return results[0].output

        # Build results text
        results_text = ""
        for r in results:
            status = "✅" if r.success else "❌"
            results_text += f"## {status} [{r.role}] {r.node_name}\n{r.output}\n\n"

        # Use first available node's provider for synthesis
        node = next(iter(self._nodes.values()), None)
        if node is None:
            # Simple concatenation fallback
            return "\n\n---\n\n".join(r.output for r in results if r.success)

        try:
            prompt = SYNTHESIS_PROMPT.format(task=task, results=results_text)
            return await node.provider.complete(prompt, max_tokens=2000)
        except Exception:
            return results_text

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _execute_node(self, node: AgentNode, task: str, label: str = "") -> MeshResult:
        """Execute a single node: system prompt + user task → response."""
        start = time.monotonic()

        try:
            # Build messages
            from deepcraft.agent.types import ChatMessage

            messages = [
                ChatMessage(role="system", content=node.system_prompt),
                ChatMessage(role="user", content=task),
            ]

            # Non-streaming execution (simpler for multi-agent)
            response_parts: list[str] = []
            async for chunk in node.provider.chat(messages, stream=True):
                if chunk.delta and chunk.delta.content:
                    response_parts.append(chunk.delta.content)

            output = "".join(response_parts).strip()

            duration = int((time.monotonic() - start) * 1000)

            name = label or node.name
            console.print(f"  [green]✓[/] {name} ({duration}ms)")

            return MeshResult(
                node_name=node.name,
                role=node.role,
                output=output,
                duration_ms=duration,
            )

        except Exception as e:
            duration = int((time.monotonic() - start) * 1000)
            console.print(f"  [red]✗[/] {label or node.name}: {e}")
            return MeshResult(
                node_name=node.name,
                role=node.role,
                output="",
                success=False,
                error=str(e),
                duration_ms=duration,
            )

    async def close(self) -> None:
        """Close all node providers."""
        import contextlib

        for node in self._nodes.values():
            with contextlib.suppress(Exception):
                await node.provider.close()
