"""Atomic multi-file refactoring with automatic rollback.

Architecture:
    AtomicRefactor
    ├── validate() → dry-run all changes
    ├── apply()   → checkpoint → apply all → verify → commit or rollback
    └── preview() → show unified diff for all files
"""

from __future__ import annotations

import difflib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class FileChange:
    """A single search-and-replace change in one file."""

    path: str
    old_string: str
    new_string: str
    replace_all: bool = False

    def validate(self) -> tuple[bool, str]:
        """Check if the change is valid (old_string exists in file)."""
        p = Path(self.path)
        if not p.exists():
            return False, f"File not found: {self.path}"

        content = p.read_text(encoding="utf-8")
        count = content.count(self.old_string)
        if count == 0:
            return False, f"Pattern not found in {self.path}"
        if count > 1 and not self.replace_all:
            return (
                False,
                f"Pattern found {count} times in {self.path}. Use replace_all=True.",
            )
        return True, ""

    def apply(self) -> str:
        """Apply the change and return the new file content."""
        p = Path(self.path)
        content = p.read_text(encoding="utf-8")
        if self.replace_all:
            content = content.replace(self.old_string, self.new_string)
        else:
            content = content.replace(self.old_string, self.new_string, 1)
        p.write_text(content, encoding="utf-8")
        return content

    def diff(self) -> str:
        """Generate unified diff for this change."""
        p = Path(self.path)
        if not p.exists():
            return f"--- {self.path} (new file)\n+++ {self.path}\n+{self.new_string}"

        original = p.read_text(encoding="utf-8")
        if self.replace_all:
            modified = original.replace(self.old_string, self.new_string)
        else:
            modified = original.replace(self.old_string, self.new_string, 1)

        diff_lines = difflib.unified_diff(
            original.splitlines(keepends=True),
            modified.splitlines(keepends=True),
            fromfile=f"a/{self.path}",
            tofile=f"b/{self.path}",
        )
        return "".join(diff_lines)


@dataclass
class RefactorPlan:
    """A complete multi-file refactoring plan."""

    description: str
    changes: list[FileChange]
    checkpoint_id: int | None = None


@dataclass
class RefactorResult:
    """Result of an atomic refactoring operation."""

    success: bool
    files_modified: int
    files_failed: int
    lines_added: int
    lines_removed: int
    diff: str
    errors: list[str] = field(default_factory=list)
    checkpoint_rolled_back: bool = False


class AtomicRefactor:
    """Execute multi-file changes atomically.

    All changes succeed → commit.
    Any change fails → rollback all via checkpoint.

    Usage:
        ref = AtomicRefactor(checkpoint_manager)
        changes = [
            FileChange("a.py", "old_func", "new_func"),
            FileChange("b.py", "import a", "import a_new"),
        ]
        result = ref.apply("Refactor function rename", changes)
        if result.success:
            print(f"Modified {result.files_modified} files")
    """

    def __init__(self, checkpoint_manager: Any = None) -> None:
        """Initialize with optional checkpoint manager.

        Args:
            checkpoint_manager: CheckpointManager instance for rollback.
                If None, rollback is manual (restore from backup files).
        """
        self._checkpoint = checkpoint_manager
        self._backups: dict[str, str] = {}  # path → original content

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def validate(self, plan: RefactorPlan) -> tuple[bool, list[str]]:
        """Validate all changes without applying.

        Returns:
            (is_valid, list_of_errors)
        """
        errors: list[str] = []
        for change in plan.changes:
            ok, err = change.validate()
            if not ok:
                errors.append(f"{change.path}: {err}")
        return len(errors) == 0, errors

    def preview(self, plan: RefactorPlan) -> str:
        """Generate a unified diff preview for all changes.

        Returns:
            Combined diff string.
        """
        parts: list[str] = [f"# Refactor: {plan.description}\n"]
        for change in plan.changes:
            parts.append(f"\n## {change.path}")
            parts.append(change.diff())
        return "\n".join(parts)

    def apply(self, plan: RefactorPlan, dry_run: bool = False) -> RefactorResult:
        """Apply all changes atomically.

        Args:
            plan: The refactoring plan to execute.
            dry_run: If True, only validate and preview, don't apply.

        Returns:
            RefactorResult with success/failure details.
        """
        if dry_run:
            valid, errors = self.validate(plan)
            diff = self.preview(plan)
            return RefactorResult(
                success=valid,
                files_modified=0,
                files_failed=len(errors),
                lines_added=0,
                lines_removed=0,
                diff=diff,
                errors=errors,
            )

        # Save state for rollback
        self._save_backups(plan)
        if self._checkpoint:
            import contextlib

            with contextlib.suppress(Exception):
                plan.checkpoint_id = self._checkpoint.save_before_write(".")

        # Apply all changes
        applied: list[FileChange] = []
        errors: list[str] = []
        added = 0
        removed = 0

        try:
            for change in plan.changes:
                ok, err = change.validate()
                if not ok:
                    errors.append(f"{change.path}: {err}")
                    raise RollbackError(err)

                new_content = change.apply()
                applied.append(change)

                # Count line changes
                old_count = len(self._backups.get(change.path, "").splitlines())
                new_count = len(new_content.splitlines())
                if new_count > old_count:
                    added += new_count - old_count
                elif new_count < old_count:
                    removed += old_count - new_count

        except RollbackError:
            # Rollback all applied changes
            self._rollback(applied, plan)
            return RefactorResult(
                success=False,
                files_modified=len(applied),
                files_failed=len(errors) + (len(plan.changes) - len(applied)),
                lines_added=0,
                lines_removed=0,
                diff="",
                errors=errors,
                checkpoint_rolled_back=True,
            )

        # Success
        diff = self._build_diff(plan)
        return RefactorResult(
            success=True,
            files_modified=len(applied),
            files_failed=0,
            lines_added=added,
            lines_removed=removed,
            diff=diff,
        )

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _save_backups(self, plan: RefactorPlan) -> None:
        """Save original file contents for rollback."""
        for change in plan.changes:
            p = Path(change.path)
            if p.exists() and change.path not in self._backups:
                self._backups[change.path] = p.read_text(encoding="utf-8")

    def _rollback(self, applied: list[FileChange], plan: RefactorPlan) -> None:
        """Restore original content for all applied files."""
        for change in applied:
            if change.path in self._backups:
                Path(change.path).write_text(self._backups[change.path], encoding="utf-8")

        # Also restore via checkpoint if available
        if self._checkpoint and plan.checkpoint_id is not None:
            import contextlib

            with contextlib.suppress(Exception):
                self._checkpoint.rollback(plan.checkpoint_id)

    def _build_diff(self, plan: RefactorPlan) -> str:
        """Build combined diff for all changes."""
        parts: list[str] = []
        for change in plan.changes:
            diff = change.diff()
            if diff.strip():
                parts.append(diff)
        return "\n".join(parts)


class RollbackError(Exception):
    """Internal exception to trigger rollback."""
