"""Codebase Indexer — AST-based project structure analysis.

Scans Python source files with AST, builds a structured index of:
- Classes (methods, bases, docstrings)
- Functions (signatures, docstrings)
- Imports and dependencies
- File summaries

The index is injected into Agent context so it understands the full codebase
without repeated search_files calls. Think Cursor's codebase indexing, but simpler.
"""

from __future__ import annotations

import ast
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class FuncInfo:
    name: str
    file: str
    line: int
    signature: str = ""
    docstring: str = ""
    decorators: list[str] = field(default_factory=list)
    is_async: bool = False


@dataclass
class ClassInfo:
    name: str
    file: str
    line: int
    bases: list[str] = field(default_factory=list)
    docstring: str = ""
    decorators: list[str] = field(default_factory=list)
    methods: list[FuncInfo] = field(default_factory=list)


@dataclass
class FileInfo:
    path: str
    lines: int = 0
    imports: list[str] = field(default_factory=list)
    functions: list[FuncInfo] = field(default_factory=list)
    classes: list[ClassInfo] = field(default_factory=list)
    summary: str = ""


@dataclass
class CodebaseIndex:
    """Complete index of a Python codebase."""

    root: str
    files: list[FileInfo] = field(default_factory=list)
    total_files: int = 0
    total_functions: int = 0
    total_classes: int = 0
    total_lines: int = 0

    def to_context(self, max_items: int = 100) -> str:
        """Convert index to a compact context string for LLM injection."""
        lines = ["# Codebase Index\n"]
        lines.append(f"Root: {self.root}")
        lines.append(f"Files: {self.total_files}, Lines: {self.total_lines}")
        lines.append(f"Functions: {self.total_functions}, Classes: {self.total_classes}")
        lines.append("")

        count = 0
        for f in self.files:
            if count >= max_items:
                lines.append(f"... ({len(self.files) - count} more files)")
                break

            rel = self._relative(f.path)
            lines.append(f"## {rel} ({f.lines} lines)")

            if f.summary:
                lines.append(f"  {f.summary}")

            for cls in f.classes[:10]:
                bases = f"({', '.join(cls.bases)})" if cls.bases else ""
                lines.append(f"  class {cls.name}{bases} (line {cls.line})")
                if cls.docstring:
                    lines.append(f'    "{cls.docstring[:80]}"')
                for m in cls.methods[:5]:
                    prefix = "async " if m.is_async else ""
                    lines.append(f"    {prefix}def {m.name}{m.signature}")
                if len(cls.methods) > 5:
                    lines.append(f"    ... +{len(cls.methods) - 5} more methods")
                count += 1

            for fn in f.functions[:10]:
                prefix = "async " if fn.is_async else ""
                lines.append(f"  {prefix}def {fn.name}{fn.signature} (line {fn.line})")
                if fn.docstring:
                    lines.append(f'    "{fn.docstring[:80]}"')
                count += 1

            lines.append("")
            count += 1

        return "\n".join(lines)

    def _relative(self, path: str) -> str:
        try:
            return os.path.relpath(path, self.root)
        except ValueError:
            return path

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict for JSON caching."""
        return {
            "root": self.root,
            "total_files": self.total_files,
            "total_functions": self.total_functions,
            "total_classes": self.total_classes,
            "total_lines": self.total_lines,
            "files": [
                {
                    "path": f.path,
                    "lines": f.lines,
                    "imports": f.imports,
                    "summary": f.summary,
                    "functions": [
                        {
                            "name": fn.name,
                            "line": fn.line,
                            "signature": fn.signature,
                            "docstring": fn.docstring,
                            "decorators": fn.decorators,
                            "is_async": fn.is_async,
                        }
                        for fn in f.functions
                    ],
                    "classes": [
                        {
                            "name": c.name,
                            "line": c.line,
                            "bases": c.bases,
                            "docstring": c.docstring,
                            "decorators": c.decorators,
                            "methods": [
                                {
                                    "name": m.name,
                                    "line": m.line,
                                    "signature": m.signature,
                                    "docstring": m.docstring,
                                }
                                for m in c.methods
                            ],
                        }
                        for c in f.classes
                    ],
                }
                for f in self.files
            ],
        }


class Indexer:
    """AST-based Python codebase indexer."""

    def __init__(self, root: str | Path, exclude_dirs: list[str] | None = None):
        self.root = Path(root).resolve()
        self.exclude = set(
            exclude_dirs
            or [
                "__pycache__",
                ".git",
                ".venv",
                "venv",
                ".deepcraft",
                "node_modules",
                "dist",
                "build",
                ".mypy_cache",
                ".ruff_cache",
                ".pytest_cache",
                "tests",
                "test",
            ]
        )

    def build(self) -> CodebaseIndex:
        """Scan the codebase and build a complete index."""
        index = CodebaseIndex(root=str(self.root))
        py_files = list(self._walk_python_files())

        for fpath in sorted(py_files):
            try:
                source = fpath.read_text(encoding="utf-8")
                tree = ast.parse(source)
                file_info = self._analyze_file(fpath, tree, source)
                index.files.append(file_info)
                index.total_functions += len(file_info.functions)
                index.total_classes += len(file_info.classes)
                index.total_lines += file_info.lines
            except (SyntaxError, UnicodeDecodeError, Exception):
                continue

        index.total_files = len(index.files)
        return index

    def _walk_python_files(self):
        """Yield .py files, excluding test and hidden dirs."""
        for dirpath, dirnames, filenames in os.walk(self.root):
            dirnames[:] = [d for d in dirnames if d not in self.exclude and not d.startswith(".")]
            for f in filenames:
                if f.endswith(".py") and not f.startswith("."):
                    yield Path(dirpath) / f

    def _analyze_file(self, fpath: Path, tree: ast.Module, source: str) -> FileInfo:
        """Extract all indexable info from one file."""
        rel = str(fpath)
        lines = len(source.splitlines())

        imports = self._extract_imports(tree)
        functions, classes = self._extract_top_level(tree)

        # Generate a short summary
        summary_parts = []
        if classes:
            summary_parts.append(f"{len(classes)} classes")
        if functions:
            summary_parts.append(f"{len(functions)} functions")
        if imports:
            deps = [i for i in imports if not i.startswith(".")]
            if deps:
                top_deps = deps[:3]
                summary_parts.append(f"imports: {', '.join(top_deps)}")

        summary = ", ".join(summary_parts) if summary_parts else "empty module"

        return FileInfo(
            path=rel,
            lines=lines,
            imports=imports,
            functions=functions,
            classes=classes,
            summary=summary,
        )

    def _extract_imports(self, tree: ast.Module) -> list[str]:
        """Extract import statements."""
        imports = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(alias.name)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    if alias.name == "*":
                        imports.append(f"{module}.*")
                    else:
                        imports.append(f"{module}.{alias.name}")
        return sorted(set(imports))

    def _extract_top_level(self, tree: ast.Module) -> tuple[list[FuncInfo], list[ClassInfo]]:
        """Extract top-level functions and classes."""
        functions = []
        classes = []

        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.FunctionDef):
                info = self._func_info(node)
                functions.append(info)
            elif isinstance(node, ast.AsyncFunctionDef):
                info = self._func_info(node, is_async=True)
                functions.append(info)
            elif isinstance(node, ast.ClassDef):
                info = self._class_info(node)
                classes.append(info)

        return functions, classes

    def _func_info(
        self,
        node: ast.FunctionDef | ast.AsyncFunctionDef,
        is_async: bool = False,
    ) -> FuncInfo:
        """Extract info from a function node."""
        args = []
        for arg in node.args.args:
            arg_str = arg.arg
            if arg.annotation:
                arg_str += f": {ast.unparse(arg.annotation)}"
            args.append(arg_str)
        if node.args.vararg:
            args.append(f"*{node.args.vararg.arg}")
        if node.args.kwarg:
            args.append(f"**{node.args.kwarg.arg}")

        returns = ""
        if node.returns:
            returns = f" -> {ast.unparse(node.returns)}"

        signature = f"({', '.join(args)}){returns}"

        docstring = ast.get_docstring(node) or ""
        decorators = [ast.unparse(d) for d in node.decorator_list] if node.decorator_list else []

        return FuncInfo(
            name=node.name,
            file="",
            line=node.lineno,
            signature=signature,
            docstring=docstring.strip(),
            decorators=decorators,
            is_async=is_async,
        )

    def _class_info(self, node: ast.ClassDef) -> ClassInfo:
        """Extract info from a class node."""
        bases = [ast.unparse(b) for b in node.bases] if node.bases else []
        docstring = ast.get_docstring(node) or ""
        decorators = [ast.unparse(d) for d in node.decorator_list] if node.decorator_list else []

        methods = []
        for child in node.body:
            if isinstance(child, ast.FunctionDef):
                methods.append(self._func_info(child))
            elif isinstance(child, ast.AsyncFunctionDef):
                methods.append(self._func_info(child, is_async=True))

        return ClassInfo(
            name=node.name,
            file="",
            line=node.lineno,
            bases=bases,
            docstring=docstring.strip(),
            decorators=decorators,
            methods=methods,
        )


def build_index(root: str | Path, cache: bool = True) -> CodebaseIndex:
    """Build codebase index with optional caching.

    Saves to .deepcraft/index.json for fast reload on subsequent runs.
    """
    root_path = Path(root).resolve()
    cache_path = root_path / ".deepcraft" / "index.json"

    # Try cached version
    if cache and cache_path.exists():
        try:
            data = json.loads(cache_path.read_text())
            if data.get("root") == str(root_path):
                return _from_dict(data)
        except (json.JSONDecodeError, KeyError):
            pass

    # Build fresh
    indexer = Indexer(root_path)
    index = indexer.build()

    # Cache
    if cache:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_path.write_text(json.dumps(index.to_dict(), indent=2, ensure_ascii=False))

    return index


def _from_dict(data: dict[str, Any]) -> CodebaseIndex:
    """Reconstruct CodebaseIndex from dict."""
    files = []
    for fd in data.get("files", []):
        functions = [FuncInfo(**fn) for fn in fd.get("functions", [])]
        classes = []
        for cd in fd.get("classes", []):
            methods = [FuncInfo(**m) for m in cd.pop("methods", [])]
            classes.append(ClassInfo(methods=methods, **cd))
        files.append(
            FileInfo(
                functions=functions,
                classes=classes,
                **{k: v for k, v in fd.items() if k in {"path", "lines", "imports", "summary"}},
            )
        )

    return CodebaseIndex(
        root=data["root"],
        files=files,
        total_files=data.get("total_files", len(files)),
        total_functions=data.get("total_functions", 0),
        total_classes=data.get("total_classes", 0),
        total_lines=data.get("total_lines", 0),
    )
