"""Visual diff engine with Rich rendering and inline annotations.

Architecture:
    DiffViewer
    ├── unified_diff() → colored unified diff (Rich-rendered)
    ├── side_by_side() → side-by-side diff view
    ├── file_diff()   → compare two files on disk
    ├── git_diff()    → working tree vs HEAD
    └── preview_changes() → Rich preview of RefactorPlan changes

Zero external dependencies — uses difflib + Rich (already required).
"""

from __future__ import annotations

import difflib
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

if TYPE_CHECKING:
    from deepcraft.agent.refactor import FileChange


@dataclass
class DiffHunk:
    """A single diff hunk with line-level changes."""

    old_start: int
    old_count: int
    new_start: int
    new_count: int
    header: str = ""
    lines: list[tuple[str, str]] = field(default_factory=list)
    # Each line is (kind, text) where kind is '+', '-', or ' '

    @property
    def added(self) -> int:
        return sum(1 for k, _ in self.lines if k == "+")

    @property
    def removed(self) -> int:
        return sum(1 for k, _ in self.lines if k == "-")


@dataclass
class DiffResult:
    """Complete diff between two files or strings."""

    old_path: str
    new_path: str
    hunks: list[DiffHunk] = field(default_factory=list)
    lines_added: int = 0
    lines_removed: int = 0
    is_binary: bool = False

    @property
    def has_changes(self) -> bool:
        return len(self.hunks) > 0

    @property
    def total_hunks(self) -> int:
        return len(self.hunks)


class DiffViewer:
    """Visual diff engine with Rich-rendered, colorized output.

    Usage:
        viewer = DiffViewer()
        result = viewer.file_diff("old.py", "new.py")
        rich_text = viewer.unified_diff(result, context=3)
        console.print(rich_text)
    """

    def __init__(self, context_lines: int = 3, max_width: int = 120) -> None:
        self.context_lines = context_lines
        self.max_width = max_width

    # ── Core diff engine ───────────────────────────────────────────

    def diff_texts(
        self,
        old_text: str,
        new_text: str,
        old_label: str = "a",
        new_label: str = "b",
    ) -> DiffResult:
        """Compute line-level diff between two text blocks."""
        old_lines = old_text.splitlines(keepends=False)
        new_lines = new_text.splitlines(keepends=False)

        matcher = difflib.SequenceMatcher(None, old_lines, new_lines)
        opcodes = matcher.get_grouped_opcodes(n=self.context_lines)

        result = DiffResult(old_path=old_label, new_path=new_label)
        for group in opcodes:
            hunk = DiffHunk(old_start=0, old_count=0, new_start=0, new_count=0)
            first = True
            for tag, i1, i2, j1, j2 in group:
                if first:
                    hunk.old_start = i1 + 1  # 1-indexed
                    hunk.new_start = j1 + 1
                    hunk.old_count = i2 - i1
                    hunk.new_count = j2 - j1
                    hunk.header = f"@@ -{hunk.old_start},{i2 - i1} +{hunk.new_start},{j2 - j1} @@"
                    first = False
                if tag == "replace":
                    for i in range(i1, i2):
                        hunk.lines.append(("-", old_lines[i]))
                        result.lines_removed += 1
                    for j in range(j1, j2):
                        hunk.lines.append(("+", new_lines[j]))
                        result.lines_added += 1
                elif tag == "delete":
                    for i in range(i1, i2):
                        hunk.lines.append(("-", old_lines[i]))
                        result.lines_removed += 1
                elif tag == "insert":
                    for j in range(j1, j2):
                        hunk.lines.append(("+", new_lines[j]))
                        result.lines_added += 1
                elif tag == "equal":
                    for i in range(i1, i2):
                        hunk.lines.append((" ", old_lines[i]))
            result.hunks.append(hunk)

        return result

    def file_diff(self, path_a: str | Path, path_b: str | Path) -> DiffResult:
        """Compare two files on disk."""
        a, b = Path(path_a), Path(path_b)
        try:
            old_text = a.read_text(encoding="utf-8")
            new_text = b.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return DiffResult(old_path=str(a), new_path=str(b), is_binary=True)
        return self.diff_texts(old_text, new_text, old_label=str(a), new_label=str(b))

    def git_diff(self, path: str | Path, staged: bool = False) -> DiffResult | None:
        """Show changes in working tree vs HEAD for a file.

        Returns None if git is unavailable or file is untracked.
        """
        p = Path(path)
        if not p.exists():
            return None

        try:
            old_text = subprocess.check_output(
                ["git", "show", f"HEAD:{path}"],
                stderr=subprocess.DEVNULL,
                text=True,
            )
        except (subprocess.CalledProcessError, FileNotFoundError):
            return None

        new_text = p.read_text(encoding="utf-8")
        return self.diff_texts(
            old_text,
            new_text,
            old_label=f"HEAD:{path}",
            new_label=str(path),
        )

    def diff_against_string(
        self,
        path: str | Path,
        new_content: str,
    ) -> DiffResult:
        """Show diff between file on disk and a proposed new version."""
        p = Path(path)
        try:
            old_text = p.read_text(encoding="utf-8")
        except (FileNotFoundError, UnicodeDecodeError):
            old_text = ""
        return self.diff_texts(
            old_text,
            new_content,
            old_label=str(p),
            new_label=f"{p} (proposed)",
        )

    # ── Rich rendering ─────────────────────────────────────────────

    def unified_diff(self, result: DiffResult, context: int = 3) -> Panel:
        """Render a colored unified diff as a Rich Panel."""
        if result.is_binary:
            return Panel("[dim]Binary file — diff not shown.[/]", title="Diff")

        if not result.hunks:
            return Panel("[dim]No changes.[/]", title="Diff")

        # File header
        header = Text()
        header.append(f"--- {result.old_path}\n", style="dim red")
        header.append(f"+++ {result.new_path}", style="dim green")

        body = Text()
        body.append(header)
        body.append("\n")

        for hunk in result.hunks:
            body.append(hunk.header, style="bold cyan")
            body.append("\n")

            # Group consecutive removes/inserts for inline annotation
            for kind, line_text in hunk.lines:
                if kind == "-":
                    body.append("- ", style="dim")
                    body.append(line_text, style="red")
                    body.append("\n")
                elif kind == "+":
                    body.append("+ ", style="dim")
                    body.append(line_text, style="green")
                    body.append("\n")
                else:
                    body.append("  ", style="dim")
                    body.append(line_text, style="dim")
                    body.append("\n")

        # Summary footer
        summary = Text()
        if result.lines_added:
            summary.append(f"+{result.lines_added} ", style="green")
        if result.lines_removed:
            summary.append(f"-{result.lines_removed} ", style="red")
        summary.append(
            f"in {result.total_hunks} hunk(s)",
            style="dim",
        )

        return Panel(
            body,
            title=f"[bold]Diff: {result.old_path}[/]",
            subtitle=summary,
            border_style="blue",
            padding=(0, 1),
        )

    def side_by_side(self, result: DiffResult, width: int = 120) -> Table:
        """Render a side-by-side diff using a Rich Table."""
        if result.is_binary:
            t = Table(title="Diff (side-by-side)")
            t.add_column("Binary file — diff not shown.", style="dim")
            return t

        half = max(20, (width - 10) // 2)

        table = Table(
            title=f"[bold]{result.old_path}[/]  ←→  [bold]{result.new_path}[/]",
            show_header=True,
            header_style="bold",
            border_style="blue",
        )
        table.add_column("Old", style="red", max_width=half, no_wrap=True)
        table.add_column("New", style="green", max_width=half, no_wrap=True)

        if not result.hunks:
            table.add_row("[dim](no changes)[/]", "[dim](no changes)[/]")
            return table

        # Flatten hunks into aligned line pairs
        for hunk in result.hunks:
            table.add_row(
                f"[bold cyan]{hunk.header}[/]",
                f"[bold cyan]{hunk.header}[/]",
            )
            old_buf: list[str] = []
            new_buf: list[str] = []

            for kind, text in hunk.lines:
                if kind == "-":
                    old_buf.append(text)
                elif kind == "+":
                    new_buf.append(text)
                elif kind == " ":
                    # Flush buffers
                    while old_buf or new_buf:
                        table.add_row(
                            old_buf.pop(0) if old_buf else "",
                            new_buf.pop(0) if new_buf else "",
                        )
                    table.add_row(f"[dim]{text}[/]", f"[dim]{text}[/]")

            # Flush remaining
            while old_buf or new_buf:
                table.add_row(
                    old_buf.pop(0) if old_buf else "",
                    new_buf.pop(0) if new_buf else "",
                )

        return table

    def preview_changes(self, changes: list[FileChange]) -> list[Panel]:
        """Render a Rich preview for each file in a RefactorPlan.

        Returns a list of Panels, one per changed file.
        """
        panels: list[Panel] = []
        for change in changes:
            try:
                old_text = Path(change.path).read_text(encoding="utf-8")
            except (FileNotFoundError, UnicodeDecodeError):
                old_text = ""

            new_text = old_text
            if change.replace_all:
                new_text = old_text.replace(change.old_string, change.new_string)
            elif change.old_string in old_text:
                new_text = old_text.replace(change.old_string, change.new_string, 1)

            result = self.diff_texts(
                old_text,
                new_text,
                old_label=change.path,
                new_label=f"{change.path} (after)",
            )

            if result.has_changes:
                panels.append(self.unified_diff(result, context=self.context_lines))

        return panels

    def summary(self, changes: list[FileChange]) -> str:
        """Plain-text summary of planned changes (for Agent context)."""
        lines: list[str] = []
        lines.append(f"{len(changes)} file(s) to modify:\n")
        for c in changes:
            old_len = len(c.old_string)
            new_len = len(c.new_string)
            delta = new_len - old_len
            sign = "+" if delta > 0 else ""
            lines.append(f"  {c.path}: {old_len}→{new_len} chars ({sign}{delta})")
        return "\n".join(lines)

    def syntax_highlighted_diff(self, result: DiffResult, language: str = "python") -> Panel:
        """Render diff with syntax highlighting on context lines.

        Uses Rich Syntax for unchanged lines, keeps +/- colored.
        """
        if result.is_binary:
            return Panel("[dim]Binary file[/]")

        if not result.hunks:
            return Panel("[dim]No changes.[/]", title="Diff")

        body = Text()
        body.append(f"--- {result.old_path}\n", style="dim red")
        body.append(f"+++ {result.new_path}\n\n", style="dim green")

        for hunk in result.hunks:
            body.append(hunk.header + "\n", style="bold cyan")

            for kind, text in hunk.lines:
                if kind == "-":
                    body.append(f"- {text}\n", style="bold red")
                elif kind == "+":
                    body.append(f"+ {text}\n", style="bold green")
                else:
                    # Syntax-highlight context lines
                    highlighted = Syntax(
                        text,
                        language,
                        theme="monokai",
                        line_numbers=False,
                    )
                    line = Text("  ")
                    line.append(highlighted)
                    line.append("\n")
                    body.append(line)

        return Panel(body, title="Diff", border_style="blue")
