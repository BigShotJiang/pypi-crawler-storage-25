"""Prompt cache — layered context budgeting and progressive summarization.

DeepSeek doesn't support native prompt caching (like Anthropic's cache_control),
so we simulate it at the application level:

    Layer 1: Fixed prefix (system + index) — never compressed
    Layer 2: Summaries (LLM-compressed old turns) — soft cap
    Layer 3: Recent turns (last N verbatim) — hard cap
    Layer 4: Tool results — truncated

Budget allocation: 128K total → 8K fixed + 20K recent + 5K summaries + 95K working.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from deepcraft.agent.types import ChatMessage, Role

if TYPE_CHECKING:
    from deepcraft.providers import LLMProvider

# --- Budget constants ---
MAX_TOTAL_TOKENS = 120_000  # Leave 8K headroom below DeepSeek 128K
FIXED_PREFIX_BUDGET = 8_000  # System + index + tool defs
RECENT_TURNS_BUDGET = 25_000  # Recent verbatim turns
SUMMARIES_BUDGET = 5_000  # Compressed history
# Remaining ~82K for working context

KEEP_TURNS_VERBATIM = 5  # Number of recent turns to keep full
TOOL_RESULT_MAX_CHARS = 500  # Truncate long tool outputs
COMPRESS_BATCH_CHARS = 3000  # Summarize in batches of ~3K chars

# Compression prompt — more structured than the old one
COMPRESSION_PROMPT = """Summarize this conversation fragment concisely. Preserve:
- User goals, decisions, and explicit preferences
- Key facts discovered (file paths, errors, API responses)
- Fixes applied and their outcomes
- Project conventions established

Omit: redundant tool output, repeated attempts, boilerplate, streaming output.
Respond with the summary only. Keep it under 200 words."""


def estimate_tokens(text: str) -> int:
    """Estimate token count for mixed Chinese/English text.

    Uses a simple heuristic: ~1 token per Chinese character,
    ~0.25 tokens per ASCII character (English words average 4 chars/token).
    """
    if not text:
        return 0
    cjk = sum(1 for c in text if "\u4e00" <= c <= "\u9fff" or "\u3400" <= c <= "\u4dbf")
    ascii_like = len(text) - cjk
    # DeepSeek tokenizer: ~1.2 tokens per CJK char, ~0.3 per ASCII char
    return int(cjk * 1.2 + ascii_like * 0.3)


def estimate_message_tokens(msg: ChatMessage) -> int:
    """Estimate tokens for a single message (content + role overhead)."""
    overhead = 8  # role, formatting
    tokens = overhead
    if msg.content:
        tokens += estimate_tokens(msg.content)
    if msg.tool_calls:
        tokens += estimate_tokens(str(msg.tool_calls))
    return tokens


class PromptCache:
    """Layered context builder with explicit token budgeting.

    Architecture:
        msg[0]       = system prompt (fixed prefix)
        msg[1..S]    = summaries of old turns
        msg[S+1..]   = recent N turns verbatim
    """

    def __init__(
        self,
        llm: LLMProvider | None = None,
        system_prompt: str | None = None,
    ) -> None:
        self._llm = llm
        self._system_prompt = system_prompt or ""
        self._codebase_index: str | None = None
        self._full_messages: list[ChatMessage] = []
        self._summaries: list[str] = []
        self._compression_count = 0

        # Add system message
        if self._system_prompt:
            self._full_messages.append(ChatMessage(role="system", content=self._system_prompt))

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def compression_count(self) -> int:
        return self._compression_count

    @property
    def total_tokens(self) -> int:
        """Estimate total tokens in full message list."""
        return sum(estimate_message_tokens(m) for m in self._full_messages)

    @property
    def fixed_tokens(self) -> int:
        """Tokens in fixed prefix (system + index)."""
        tokens = estimate_message_tokens(self._full_messages[0]) if self._full_messages else 0
        if self._codebase_index:
            # Index is injected as a user message after system
            tokens += estimate_tokens(self._codebase_index) + 8
        return tokens

    @property
    def usage_report(self) -> str:
        """Human-readable token usage report."""
        total = self.total_tokens
        fixed = self.fixed_tokens
        pct = (total / MAX_TOTAL_TOKENS) * 100
        return (
            f"📊 Tokens: {total:,}/{MAX_TOTAL_TOKENS:,} ({pct:.0f}%) "
            f"[fixed: {fixed:,} | compressed: {self._compression_count}]"
        )

    # ------------------------------------------------------------------
    # Index injection
    # ------------------------------------------------------------------

    def set_codebase_index(self, index_text: str) -> None:
        """Set codebase index text for fixed prefix layer."""
        self._codebase_index = index_text

    # ------------------------------------------------------------------
    # Message management
    # ------------------------------------------------------------------

    def add_message(
        self,
        role: Role | str,
        content: str | None = None,
        tool_call_id: str | None = None,
        name: str | None = None,
    ) -> None:
        """Add a message and check budget."""
        msg = ChatMessage(
            role=role.value if isinstance(role, Role) else role,
            content=content,
            tool_call_id=tool_call_id,
            name=name,
        )
        self._full_messages.append(msg)

        # Auto-compress if soft cap exceeded (80% of budget)
        if self.total_tokens > MAX_TOTAL_TOKENS * 0.75:
            self._compress_sync()

    def get_messages(self) -> list[ChatMessage]:
        """Get all messages (for export)."""
        return list(self._full_messages)

    def build_api_messages(self) -> list[dict[str, object]]:
        """Build the message list for the API call.

        Returns the compact representation with:
        - Fixed prefix (system)
        - Codebase index (if set)
        - Summaries
        - Recent turns
        """
        result: list[dict[str, object]] = []

        # Layer 1: Fixed prefix (system message)
        if self._system_prompt:
            result.append({"role": "system", "content": self._system_prompt})

        # Codebase index
        if self._codebase_index:
            result.append({"role": "user", "content": f"# Codebase Context\n{self._codebase_index}"})

        # Layer 2: Summaries
        if self._summaries:
            summary_text = "[Compressed conversation history]\n" + "\n---\n".join(self._summaries)
            result.append({"role": "user", "content": summary_text})

        # Layer 3: Recent turns (skip system + index which are already in layers 1-2)
        recent_from = self._find_keep_index()

        for msg in self._full_messages[recent_from:]:
            msg_dict: dict[str, object] = {"role": msg.role}
            if msg.content:
                msg_dict["content"] = self._truncate_if_tool(msg)
            if msg.tool_calls:
                msg_dict["tool_calls"] = msg.tool_calls
            if msg.tool_call_id:
                msg_dict["tool_call_id"] = msg.tool_call_id
            if msg.name:
                msg_dict["name"] = msg.name
            result.append(msg_dict)

        return result

    def build_chat_messages(self) -> list[ChatMessage]:
        """Build the message list as ChatMessage objects for the provider.

        Same layered structure as build_api_messages() but returns
        ChatMessage objects instead of raw dicts.
        """
        result: list[ChatMessage] = []

        # Layer 1: Fixed prefix (system message)
        if self._system_prompt:
            result.append(ChatMessage(role="system", content=self._system_prompt))

        # Codebase index
        if self._codebase_index:
            result.append(
                ChatMessage(
                    role="user",
                    content=f"# Codebase Context\n{self._codebase_index}",
                )
            )

        # Layer 2: Summaries
        if self._summaries:
            summary_text = "[Compressed conversation history]\n" + "\n---\n".join(self._summaries)
            result.append(ChatMessage(role="user", content=summary_text))

        # Layer 3: Recent turns
        recent_from = self._find_keep_index()
        for msg in self._full_messages[recent_from:]:
            result.append(
                ChatMessage(
                    role=msg.role,
                    content=self._truncate_if_tool(msg),
                    tool_calls=msg.tool_calls,
                    tool_call_id=msg.tool_call_id,
                    name=msg.name,
                )
            )

        return result

    def reset(self) -> None:
        """Reset conversation, keeping only system prompt and index."""
        self._full_messages = []
        self._summaries = []
        self._compression_count = 0
        if self._system_prompt:
            self._full_messages.append(ChatMessage(role="system", content=self._system_prompt))

    # ------------------------------------------------------------------
    # Compression (sync — called inline during add_message)
    # ------------------------------------------------------------------

    def _compress_sync(self) -> None:
        """Synchronous compression: summarize oldest turn into summaries layer."""
        keep_from = self._find_keep_index()
        if keep_from <= 1:
            return  # Nothing to compress

        old_messages = self._full_messages[1:keep_from]
        if len(old_messages) <= 3:
            return

        # Build text for summarization
        text = self._build_compression_text(old_messages)

        # Add to summaries
        self._summaries.append(text)

        # If summaries exceed budget, merge them progressively
        while estimate_tokens("\n".join(self._summaries)) > SUMMARIES_BUDGET:
            if len(self._summaries) <= 1:
                # Truncate the only summary
                self._summaries[0] = self._summaries[0][:1500] + "…"
                break
            # Merge two oldest summaries
            merged = f"Summary of earlier conversation:\n{self._summaries[0]}\n\nThen:\n{self._summaries[1]}"
            self._summaries = [merged] + self._summaries[2:]

        # Remove old messages, keep system + summaries placeholder + recent
        keep_messages = self._full_messages[keep_from:]
        self._full_messages = self._full_messages[:1] + keep_messages
        self._compression_count += 1

    def _find_keep_index(self) -> int:
        """Find the index to keep from (preserving last KEEP_TURNS_VERBATIM user turns)."""
        keep_from = len(self._full_messages)
        turns_found = 0
        for i in range(len(self._full_messages) - 1, 0, -1):
            if self._full_messages[i].role == "user":
                turns_found += 1
            if turns_found >= KEEP_TURNS_VERBATIM:
                keep_from = i
                break
        return keep_from

    def _build_compression_text(self, messages: list[ChatMessage]) -> str:
        """Build a compact text representation of old messages for summarization."""
        parts: list[str] = []
        total_chars = 0
        for msg in messages:
            role = msg.role
            content = msg.content or ""
            if role == "user":
                parts.append(f"User: {content[:300]}")
                total_chars += 300
            elif role == "assistant" and content:
                parts.append(f"Assistant: {content[:200]}")
                total_chars += 200
            elif role == "tool":
                truncated = content[:TOOL_RESULT_MAX_CHARS]
                suffix = "…" if len(content) > TOOL_RESULT_MAX_CHARS else ""
                parts.append(f"Tool: {truncated}{suffix}")
                total_chars += len(truncated)
            if total_chars > COMPRESS_BATCH_CHARS:
                parts.append("… (truncated)")
                break
        return "\n".join(parts)

    @staticmethod
    def _truncate_if_tool(msg: ChatMessage) -> str:
        """Truncate tool result content if too long."""
        content = msg.content or ""
        if msg.role == "tool" and len(content) > TOOL_RESULT_MAX_CHARS:
            return content[:TOOL_RESULT_MAX_CHARS] + "…"
        return content
