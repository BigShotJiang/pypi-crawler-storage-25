"""基于 asyncio 子进程与 JSON-RPC 2.0 的 MCP stdio 客户端。"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from collections.abc import Mapping
from typing import Any

from deepcraft.agent.mcp.http_client import HttpMCPClient  # noqa: E402
from deepcraft.agent.types import ToolDefinition

logger = logging.getLogger(__name__)

# MCP 握手使用的协议版本（与服务端协商一致即可）
DEFAULT_PROTOCOL_VERSION = "2024-11-05"


class MCPProtocolError(Exception):
    """服务端以 JSON-RPC error 返回时的异常。"""

    def __init__(self, error: Mapping[str, Any]) -> None:
        self.code: int = int(error.get("code", -32000))
        self.message: str = str(error.get("message", "Unknown error"))
        self.data: Any = error.get("data")
        super().__init__(f"[{self.code}] {self.message}")


class MCPClient:
    """通过子进程 stdin/stdout 与 MCP 服务端交换 JSON-RPC 消息的轻量客户端。

    每条消息为一行 UTF-8 JSON（newline-delimited JSON-RPC）。
    """

    def __init__(
        self,
        *,
        protocol_version: str = DEFAULT_PROTOCOL_VERSION,
        client_name: str = "deepcraft-mcp-client",
        client_version: str = "0.1.0",
    ) -> None:
        self._protocol_version = protocol_version
        self._client_name = client_name
        self._client_version = client_version

        self._proc: asyncio.subprocess.Process | None = None
        self._reader_task: asyncio.Task[None] | None = None
        self._write_lock = asyncio.Lock()
        self._next_id = 1
        # 尚未完成的请求 id -> Future（由读循环在完成时 set_result / set_exception）
        self._pending: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._pending_guard = asyncio.Lock()

    @property
    def pid(self) -> int | None:
        """子进程 PID；未连接时为 None。"""
        return None if self._proc is None else self._proc.pid

    async def connect(
        self,
        argv: list[str],
        *,
        cwd: str | None = None,
        env: Mapping[str, str] | None = None,
    ) -> None:
        """启动 MCP 服务端子进程并完成 initialize / notifications/initialized 握手。

        argv 为可执行文件及其参数，例如启动本地 MCP 服务器的命令列表。
        """
        if self._proc is not None:
            raise RuntimeError("MCP 客户端已连接，请先调用 close()")

        self._proc = await asyncio.create_subprocess_exec(
            *argv,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
            cwd=cwd,
            env=dict(env) if env is not None else None,
        )

        self._reader_task = asyncio.create_task(self._read_loop(), name="mcp-stdio-read")

        try:
            init_params: dict[str, Any] = {
                "protocolVersion": self._protocol_version,
                "capabilities": {},
                "clientInfo": {"name": self._client_name, "version": self._client_version},
            }
            await self._rpc_request("initialize", init_params)
            await self._rpc_notify("notifications/initialized", {})
        except BaseException:
            await self.close()
            raise

    async def list_tools(self, *, cursor: str | None = None) -> dict[str, Any]:
        """调用 ``tools/list``，返回服务端原始 result 对象（通常含 tools、可选 nextCursor）。"""
        params: dict[str, Any] = {}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._rpc_request("tools/list", params)

    async def call_tool(
        self,
        name: str,
        arguments: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """调用 ``tools/call``，传入工具名与参数（可为空）。"""
        params: dict[str, Any] = {"name": name}
        if arguments:
            params["arguments"] = dict(arguments)
        return await self._rpc_request("tools/call", params)

    async def close(self) -> None:
        """停止读循环并终止子进程。"""
        if self._reader_task is not None:
            self._reader_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._reader_task
            self._reader_task = None

        proc = self._proc
        self._proc = None
        if proc is None:
            await self._fail_all_pending(ConnectionError("MCP 未连接"))
            return

        if proc.stdin is not None:
            proc.stdin.close()
            try:
                await proc.stdin.wait_closed()
            except Exception:
                logger.debug("关闭 MCP stdin 时出现异常", exc_info=True)

        if proc.returncode is None:
            proc.terminate()
            try:
                await asyncio.wait_for(proc.wait(), timeout=5.0)
            except TimeoutError:
                proc.kill()
                await proc.wait()

        await self._fail_all_pending(ConnectionError("MCP 连接已关闭"))

    async def _fail_all_pending(self, exc: BaseException) -> None:
        async with self._pending_guard:
            for fut in self._pending.values():
                if not fut.done():
                    fut.set_exception(exc)
            self._pending.clear()

    async def _read_loop(self) -> None:
        assert self._proc is not None and self._proc.stdout is not None
        stdout = self._proc.stdout
        try:
            while True:
                raw = await stdout.readline()
                if not raw:
                    break
                line = raw.decode("utf-8").strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    logger.warning("忽略无法解析的 MCP 行: %s", line[:200])
                    continue

                if msg.get("jsonrpc") != "2.0":
                    continue

                # 服务端推送的通知（无 id）：此处忽略，可按需扩展为回调
                if "method" in msg and "id" not in msg:
                    logger.debug("收到 MCP 通知: %s", msg.get("method"))
                    continue

                # JSON-RPC 响应：携带 id 与 result 或 error
                if "id" in msg:
                    await self._dispatch_response(msg)
                    continue

                # 服务端发起的请求（带 id）：最小实现不支持，回复 errors 较重，仅记录
                if "method" in msg:
                    logger.warning("收到未处理的 MCP 服务端请求: %s", msg.get("method"))
        finally:
            await self._fail_all_pending(ConnectionError("MCP 读循环结束"))

    async def _dispatch_response(self, msg: dict[str, Any]) -> None:
        req_id = msg.get("id")
        if not isinstance(req_id, int):
            logger.warning("非整数 JSON-RPC id，跳过: %r", req_id)
            return
        async with self._pending_guard:
            fut = self._pending.pop(req_id, None)
        if fut is None or fut.done():
            return
        fut.set_result(msg)

    async def _rpc_request(self, method: str, params: Mapping[str, Any]) -> dict[str, Any]:
        if self._proc is None or self._proc.stdin is None:
            raise RuntimeError("MCP 未连接")

        loop = asyncio.get_running_loop()
        fut: asyncio.Future[dict[str, Any]] = loop.create_future()

        async with self._write_lock:
            req_id = self._next_id
            self._next_id += 1
            async with self._pending_guard:
                self._pending[req_id] = fut

            try:
                envelope: dict[str, Any] = {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "method": method,
                    "params": dict(params),
                }
                line = json.dumps(envelope, ensure_ascii=False) + "\n"
                self._proc.stdin.write(line.encode("utf-8"))
                await self._proc.stdin.drain()
            except BaseException:
                async with self._pending_guard:
                    self._pending.pop(req_id, None)
                if not fut.done():
                    fut.cancel()
                raise

        msg = await fut
        if "error" in msg:
            raise MCPProtocolError(msg["error"])
        result = msg.get("result")
        if isinstance(result, dict):
            return result
        return {}

    async def _rpc_notify(self, method: str, params: Mapping[str, Any]) -> None:
        if self._proc is None or self._proc.stdin is None:
            raise RuntimeError("MCP 未连接")

        async with self._write_lock:
            envelope: dict[str, Any] = {
                "jsonrpc": "2.0",
                "method": method,
                "params": dict(params),
            }
            line = json.dumps(envelope, ensure_ascii=False) + "\n"
            self._proc.stdin.write(line.encode("utf-8"))
            await self._proc.stdin.drain()


# ---------------------------------------------------------------------------
# MCP 工具包装与管理
# ---------------------------------------------------------------------------

from deepcraft.agent.tools.base import BaseTool, ToolRegistry, ToolResult  # noqa: E402


class MCPToolWrapper(BaseTool):
    """将从 MCP Server 发现的远程工具包装为 DeepCraft 本地工具。

    工具名会加上 ``mcp:<server>`` 前缀以避免与本地工具冲突。
    """

    def __init__(self, client: MCPClient, tool_def: dict[str, Any], server_name: str) -> None:
        raw_name: str = tool_def.get("name", "unknown")
        # Use _ instead of : for OpenAI/DeepSeek compatibility
        # (they require ^[a-zA-Z0-9_-]+$ for tool names)
        self.name = f"mcp_{server_name}_{raw_name}"
        self.description = tool_def.get("description", f"MCP 工具：{raw_name}")
        self._client = client
        self._raw_name = raw_name

        # 构建 parameters schema（符合 OpenAI function calling 格式）
        input_schema = tool_def.get("inputSchema", {})
        self.parameters = input_schema.get("properties", {})
        # Only mark truly required params (ignore optional ones)
        self._required_params: list[str] = input_schema.get("required", [])

    def to_definition(self) -> ToolDefinition:
        """Override: only mark truly required params for MCP tools."""
        return ToolDefinition(
            name=self.name,
            description=self.description,
            parameters=self.parameters,
            required=self._required_params,
        )

    async def execute(self, **kwargs: Any) -> ToolResult:
        result = await self._client.call_tool(self._raw_name, arguments=kwargs)
        # MCP 工具返回的 content 可能是 list[dict]
        content = result.get("content", [])
        if isinstance(content, list):
            texts = []
            for item in content:
                if isinstance(item, dict) and item.get("type") == "text":
                    texts.append(item.get("text", ""))
                elif isinstance(item, dict):
                    texts.append(str(item))
                else:
                    texts.append(str(item))
            output = texts[0] if len(texts) == 1 else "\n".join(texts)
            return ToolResult(content=output)
        return ToolResult(content=str(content))


class MCPManager:
    """管理多个 MCP Server 连接，自动发现工具并注册到 ToolRegistry。

    支持 stdio 和 HTTP/SSE 两种传输方式。
    """

    def __init__(self, registry: ToolRegistry) -> None:
        self._registry = registry
        self._clients: dict[str, MCPClient | HttpMCPClient] = {}
        self._tools: dict[str, MCPToolWrapper] = {}

    async def connect_server(
        self,
        name: str,
        argv: list[str],
        *,
        cwd: str | None = None,
        env: Mapping[str, str] | None = None,
    ) -> None:
        """启动一个 stdio MCP Server 并将其工具注册到 ToolRegistry。"""
        if name in self._clients:
            raise ValueError(f"MCP Server '{name}' 已连接")

        client = MCPClient()
        await client.connect(argv, cwd=cwd, env=env)
        await self._register_client(name, client)

    async def connect_http_server(
        self,
        name: str,
        url: str,
        *,
        headers: dict[str, str] | None = None,
    ) -> None:
        """连接一个 HTTP MCP Server 并将其工具注册到 ToolRegistry。"""
        if name in self._clients:
            raise ValueError(f"MCP Server '{name}' 已连接")

        from deepcraft.agent.mcp.http_client import HttpMCPClient

        client = HttpMCPClient(url, headers=headers)
        await client.connect()
        await self._register_client(name, client)

    async def _register_client(self, name: str, client: MCPClient | HttpMCPClient) -> None:
        try:
            tools = await self._discover_and_register(name, client)
            self._clients[name] = client
            logger.info("MCP Server '%s' 已连接，注册 %d 个工具", name, len(tools))
        except BaseException:
            await client.close()
            raise

    async def _discover_and_register(self, name: str, client: MCPClient) -> list[MCPToolWrapper]:
        """调用 tools/list 并将每个工具包装后注册到 ToolRegistry。"""
        result = await client.list_tools()
        tool_list: list[dict[str, Any]] = result.get("tools", [])

        tools: list[MCPToolWrapper] = []
        for tool_def in tool_list:
            wrapper = MCPToolWrapper(client, tool_def, name)
            self._registry.register(wrapper)
            self._tools[wrapper.name] = wrapper
            tools.append(wrapper)

        return tools

    async def close_all(self) -> None:
        """关闭所有 MCP Server 连接并注销工具。"""
        for name in list(self._clients):
            await self.close_server(name)

    async def close_server(self, name: str) -> None:
        """关闭指定 MCP Server。"""
        client = self._clients.pop(name, None)
        if client is None:
            return

        # 注销该 server 的所有工具
        prefix = f"mcp_{name}_"
        for tool_name in list(self._tools):
            if tool_name.startswith(prefix):
                self._registry.unregister(tool_name)
                del self._tools[tool_name]

        await client.close()
        logger.info("MCP Server '%s' 已关闭", name)

    @property
    def servers(self) -> list[str]:
        """当前连接的 Server 名称列表。"""
        return list(self._clients)
