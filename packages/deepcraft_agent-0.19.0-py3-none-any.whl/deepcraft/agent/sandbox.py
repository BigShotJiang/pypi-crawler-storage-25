"""Docker sandbox — isolated command execution for untrusted code.

Architecture:
    DockerSandbox → manages container lifecycle, mounts, security profiles
    SandboxTool   → Agent-facing tool wrapper
"""

from __future__ import annotations

import os
import subprocess
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any


class SandboxMode(str, Enum):
    """Security profile for sandbox execution."""

    DEFAULT = "default"  # Network + write in workspace
    RESTRICTED = "restricted"  # No network, read-only fs
    OFFLINE = "offline"  # No network, write allowed


@dataclass
class SandboxResult:
    """Result of a sandbox command execution."""

    stdout: str
    stderr: str
    exit_code: int
    duration_ms: int
    container_id: str = ""


@dataclass
class SandboxConfig:
    """Configuration for a sandbox session."""

    image: str = "python:3.11-slim"
    mode: SandboxMode = SandboxMode.DEFAULT
    memory_limit: str = "512m"
    cpu_limit: float = 1.0
    default_timeout: int = 30  # seconds
    workspace_mount: str = ""  # Host path to mount (default: cwd)
    reuse_container: bool = True  # Keep container alive between commands
    # Volume mount options
    read_only_workspace: bool = False


class DockerSandbox:
    """Manages a Docker container for isolated command execution.

    Usage:
        sandbox = DockerSandbox(SandboxConfig(workspace_mount="/path/to/project"))
        result = sandbox.run("python -c 'print(1+1)'")
        print(result.stdout)  # "2\\n"
        sandbox.cleanup()
    """

    def __init__(self, config: SandboxConfig | None = None) -> None:
        self._config = config or SandboxConfig()
        self._container_id: str | None = None
        self._container_name = f"deepcraft-sandbox-{uuid.uuid4().hex[:8]}"
        self._command_count = 0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _ensure_container(self) -> str:
        """Ensure a container is running. Returns container_id."""
        if self._container_id and self._config.reuse_container:
            # Check if still running
            code = self._docker(
                ["inspect", "-f", "{{.State.Running}}", self._container_id],
                timeout=5,
            ).exit_code
            if code == 0:
                return self._container_id

        return self._create_container()

    def _create_container(self) -> str:
        """Create and start a new container."""
        # Clean up any existing container with same name
        self._docker(["rm", "-f", self._container_name], timeout=5)

        args = [
            "run",
            "-d",
            "--name",
            self._container_name,
        ]

        # Resource limits
        args += ["--memory", self._config.memory_limit]
        args += ["--cpus", str(self._config.cpu_limit)]

        # Security
        mode = self._config.mode
        if mode == SandboxMode.RESTRICTED:
            args += ["--network", "none"]
            args += ["--read-only"]
            args += ["--tmpfs", "/tmp:exec"]
        elif mode == SandboxMode.OFFLINE:
            args += ["--network", "none"]

        # Mount workspace
        workspace = self._config.workspace_mount or os.getcwd()
        mount_opts = "ro" if self._config.read_only_workspace else "rw"
        args += ["-v", f"{workspace}:/workspace:{mount_opts}"]
        args += ["-w", "/workspace"]

        # Keep alive with sleep
        args += [self._config.image, "sleep", "infinity"]

        result = self._docker(args, timeout=20)
        if result.exit_code != 0:
            raise RuntimeError(f"Failed to create sandbox container: {result.stderr}")

        self._container_id = result.stdout.strip()
        return self._container_id

    def run(
        self,
        command: str,
        timeout: int | None = None,
        workdir: str = "/workspace",
        env: dict[str, str] | None = None,
        stdin: str | None = None,
    ) -> SandboxResult:
        """Execute a command in the sandbox.

        Args:
            command: Shell command to execute.
            timeout: Max seconds (default: SandboxConfig.default_timeout).
            workdir: Working directory inside container.
            env: Environment variables to set.
            stdin: Text to pipe to command's stdin.

        Returns:
            SandboxResult with stdout, stderr, exit_code, duration.
        """
        cid = self._ensure_container()

        timeout_sec = timeout or self._config.default_timeout
        self._command_count += 1

        args = ["exec", "-w", workdir]
        if env:
            for k, v in env.items():
                args += ["-e", f"{k}={v}"]
        args += [cid, "sh", "-c", command]

        start = time.monotonic()
        try:
            result = self._docker(args, timeout=timeout_sec, stdin_str=stdin)
        except subprocess.TimeoutExpired:
            duration = int((time.monotonic() - start) * 1000)
            return SandboxResult(
                stdout="",
                stderr=f"Command timed out after {timeout_sec}s",
                exit_code=124,  # Standard timeout exit code
                duration_ms=duration,
                container_id=cid,
            )

        duration = int((time.monotonic() - start) * 1000)
        return SandboxResult(
            stdout=result.stdout,
            stderr=result.stderr,
            exit_code=result.exit_code,
            duration_ms=duration,
            container_id=cid,
        )

    def cleanup(self) -> None:
        """Remove the sandbox container."""
        if self._container_id:
            self._docker(["rm", "-f", self._container_id], timeout=5)
            self._container_id = None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _docker(
        self,
        args: list[str],
        timeout: int = 30,
        stdin_str: str | None = None,
    ) -> SandboxResult:
        """Run a docker command and return structured result."""
        try:
            proc = subprocess.run(
                ["docker"] + args,
                capture_output=True,
                text=True,
                timeout=timeout,
                input=stdin_str,
            )
            return SandboxResult(
                stdout=proc.stdout,
                stderr=proc.stderr,
                exit_code=proc.returncode,
                duration_ms=0,
            )
        except subprocess.TimeoutExpired:
            return SandboxResult(
                stdout="",
                stderr=f"Docker command timed out ({timeout}s)",
                exit_code=124,
                duration_ms=timeout * 1000,
            )
        except FileNotFoundError:
            return SandboxResult(
                stdout="",
                stderr="Docker is not installed or not in PATH",
                exit_code=127,
                duration_ms=0,
            )

    @property
    def status(self) -> dict[str, Any]:
        """Get sandbox status for REPL display."""
        return {
            "container": self._container_name,
            "running": self._container_id is not None,
            "image": self._config.image,
            "mode": self._config.mode.value,
            "commands_run": self._command_count,
            "workspace": self._config.workspace_mount or os.getcwd(),
        }

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> DockerSandbox:
        self._ensure_container()
        return self

    def __exit__(self, *args: object) -> None:
        self.cleanup()
