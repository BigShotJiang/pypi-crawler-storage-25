"""Ollama provider — local model inference."""

from __future__ import annotations

from collections.abc import AsyncIterator

import httpx

from deepcraft.agent.types import ChatMessage, LLMResponse, ToolDefinition
from deepcraft.providers import LLMProvider


class OllamaProvider(LLMProvider):
    """Ollama local API — OpenAI-compatible /chat/completions endpoint (v0.5+)."""

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: str = "llama3.2",
        max_tokens: int = 4096,
    ) -> None:
        self._model = model
        self._max_tokens = max_tokens
        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            timeout=httpx.Timeout(300.0),  # local models can be slow
        )

    @property
    def model(self) -> str:
        return self._model

    @property
    def provider_name(self) -> str:
        return "ollama"

    async def chat(
        self,
        messages: list[ChatMessage],
        tools: list[ToolDefinition] | None = None,
        stream: bool = True,
    ) -> AsyncIterator[LLMResponse]:
        # Ollama v0.5+ supports OpenAI-compatible /v1/chat/completions
        body: dict[str, object] = {
            "model": self._model,
            "messages": [m.model_dump(exclude_none=True) for m in messages],
            "stream": stream,
        }
        # Ollama doesn't support max_tokens in the same way
        # Use options.num_predict instead
        body["options"] = {"num_predict": self._max_tokens}

        if tools:
            # Simplified tool support for Ollama
            body["tools"] = [t.model_dump(exclude_none=True) for t in tools]

        async with self._client.stream("POST", "/v1/chat/completions", json=body) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data = line[6:].strip()
                if data == "[DONE]":
                    break
                result = LLMResponse.from_chunk(data)
                if result is not None:
                    yield result

    async def complete(self, prompt: str, max_tokens: int = 500) -> str:
        body: dict[str, object] = {
            "model": self._model,
            "messages": [{"role": "user", "content": prompt}],
            "stream": False,
            "options": {"num_predict": max_tokens},
        }
        resp = await self._client.post("/v1/chat/completions", json=body)
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"]

    async def close(self) -> None:
        await self._client.aclose()
