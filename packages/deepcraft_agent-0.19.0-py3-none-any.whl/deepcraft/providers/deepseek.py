"""DeepSeek provider — OpenAI-compatible API."""

from __future__ import annotations

from collections.abc import AsyncIterator

import httpx

from deepcraft.agent.types import ChatMessage, LLMResponse, ToolDefinition
from deepcraft.providers import LLMProvider


class DeepSeekProvider(LLMProvider):
    """DeepSeek chat API — OpenAI-compatible format."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.deepseek.com",
        model: str = "deepseek-chat",
        max_tokens: int = 8192,
    ) -> None:
        self._model = model
        self._max_tokens = max_tokens
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(120.0),
        )

    @property
    def model(self) -> str:
        return self._model

    @property
    def provider_name(self) -> str:
        return "deepseek"

    async def chat(
        self,
        messages: list[ChatMessage],
        tools: list[ToolDefinition] | None = None,
        stream: bool = True,
    ) -> AsyncIterator[LLMResponse]:
        body: dict[str, object] = {
            "model": self._model,
            "messages": [m.model_dump(exclude_none=True) for m in messages],
            "max_tokens": self._max_tokens,
            "stream": stream,
        }
        if tools:
            body["tools"] = [t.model_dump(exclude_none=True) for t in tools]

        async with self._client.stream("POST", "/v1/chat/completions", json=body) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data = line[6:].strip()
                if data == "[DONE]":
                    break
                result = LLMResponse.from_chunk(data)
                if result is not None:
                    yield result

    async def complete(self, prompt: str, max_tokens: int = 500) -> str:
        body: dict[str, object] = {
            "model": self._model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "stream": False,
        }
        resp = await self._client.post("/v1/chat/completions", json=body)
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"]

    async def close(self) -> None:
        await self._client.aclose()
