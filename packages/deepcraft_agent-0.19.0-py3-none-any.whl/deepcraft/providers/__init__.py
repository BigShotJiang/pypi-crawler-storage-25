"""Provider abstraction — pluggable LLM backends."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from typing import Any

from deepcraft.agent.types import ChatMessage, LLMResponse, ToolDefinition


class LLMProvider(ABC):
    """Abstract base for LLM providers (DeepSeek, OpenAI, Anthropic, Ollama)."""

    @property
    @abstractmethod
    def model(self) -> str:
        """Return the model name."""

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Return the provider identifier (e.g. 'deepseek', 'openai')."""

    @abstractmethod
    async def chat(
        self,
        messages: list[ChatMessage],
        tools: list[ToolDefinition] | None = None,
        stream: bool = True,
    ) -> AsyncIterator[LLMResponse]:
        """Send a chat completion request, streaming responses."""

    @abstractmethod
    async def complete(self, prompt: str, max_tokens: int = 500) -> str:
        """Non-streaming completion for summaries / compression / memory."""

    @abstractmethod
    async def close(self) -> None:
        """Close the HTTP client."""


def create_provider(name: str, config: dict[str, Any] | None = None) -> LLMProvider:
    """Factory: create a provider by name.

    Args:
        name: One of 'deepseek', 'openai', 'anthropic', 'ollama'.
        config: Provider-specific config dict (api_key, base_url, model, etc.).

    Returns:
        An LLMProvider instance.

    Raises:
        ValueError: If provider name is unknown.
    """
    cfg = config or {}

    if name == "deepseek":
        from deepcraft.providers.deepseek import DeepSeekProvider

        return DeepSeekProvider(
            api_key=cfg.get("api_key", ""),
            base_url=cfg.get("base_url", "https://api.deepseek.com"),
            model=cfg.get("model", "deepseek-chat"),
            max_tokens=cfg.get("max_tokens", 8192),
        )

    if name == "openai":
        from deepcraft.providers.openai import OpenAIProvider

        return OpenAIProvider(
            api_key=cfg.get("api_key", ""),
            base_url=cfg.get("base_url", "https://api.openai.com/v1"),
            model=cfg.get("model", "gpt-4o"),
            max_tokens=cfg.get("max_tokens", 8192),
        )

    if name == "anthropic":
        from deepcraft.providers.anthropic import AnthropicProvider

        return AnthropicProvider(
            api_key=cfg.get("api_key", ""),
            base_url=cfg.get("base_url", "https://api.anthropic.com"),
            model=cfg.get("model", "claude-sonnet-4-20250514"),
            max_tokens=cfg.get("max_tokens", 8192),
        )

    if name == "ollama":
        from deepcraft.providers.ollama import OllamaProvider

        return OllamaProvider(
            base_url=cfg.get("base_url", "http://localhost:11434"),
            model=cfg.get("model", "llama3.2"),
            max_tokens=cfg.get("max_tokens", 4096),
        )

    raise ValueError(f"Unknown provider: {name}. Supported: deepseek, openai, anthropic, ollama")
