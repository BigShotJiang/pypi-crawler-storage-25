"""Anthropic (Claude) provider."""

from __future__ import annotations

import json
from collections.abc import AsyncIterator

import httpx

from deepcraft.agent.types import ChatMessage, LLMResponse, ToolDefinition
from deepcraft.providers import LLMProvider


class AnthropicProvider(LLMProvider):
    """Anthropic Messages API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.anthropic.com",
        model: str = "claude-sonnet-4-20250514",
        max_tokens: int = 8192,
    ) -> None:
        self._model = model
        self._max_tokens = max_tokens
        self._api_key = api_key
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(120.0),
        )

    @property
    def model(self) -> str:
        return self._model

    @property
    def provider_name(self) -> str:
        return "anthropic"

    async def chat(
        self,
        messages: list[ChatMessage],
        tools: list[ToolDefinition] | None = None,
        stream: bool = True,
    ) -> AsyncIterator[LLMResponse]:
        # Anthropic requires system message separate from messages array
        system = ""
        anthropic_messages: list[dict[str, object]] = []
        for m in messages:
            role = m.role
            if role == "system":
                system = m.content or ""
            elif role in ("user", "assistant"):
                entry: dict[str, object] = {"role": role, "content": m.content or ""}
                anthropic_messages.append(entry)
            elif role == "tool":
                # Anthropic expects tool results in a different format
                # Simplified: append as user message with tool result
                anthropic_messages.append(
                    {
                        "role": "user",
                        "content": f"[Tool result: {m.tool_call_id}] {m.content}",
                    }
                )

        body: dict[str, object] = {
            "model": self._model,
            "max_tokens": self._max_tokens,
            "messages": anthropic_messages,
            "stream": stream,
        }
        if system:
            body["system"] = system

        # Convert our tool definitions to Anthropic format
        if tools:
            anthropic_tools = []
            for t in tools:
                anthropic_tools.append(
                    {
                        "name": t.name,
                        "description": t.description,
                        "input_schema": t.parameters or {"type": "object", "properties": {}},
                    }
                )
            body["tools"] = anthropic_tools

        async with self._client.stream("POST", "/v1/messages", json=body) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_str = line[6:].strip()
                if not data_str:
                    continue

                try:
                    event = json.loads(data_str)
                except json.JSONDecodeError:
                    continue

                if event.get("type") == "content_block_delta":
                    delta = event.get("delta", {})
                    text = delta.get("text", "")
                    if text:
                        yield LLMResponse(content=text, finish_reason=None)
                elif event.get("type") == "message_delta":
                    finish = event.get("delta", {}).get("stop_reason", "end_turn")
                    yield LLMResponse(content="", finish_reason=finish)

    async def complete(self, prompt: str, max_tokens: int = 500) -> str:
        body: dict[str, object] = {
            "model": self._model,
            "max_tokens": max_tokens,
            "messages": [{"role": "user", "content": prompt}],
            "stream": False,
        }
        resp = await self._client.post("/v1/messages", json=body)
        resp.raise_for_status()
        data = resp.json()
        # Anthropic response format: content is an array of blocks
        content_blocks = data.get("content", [])
        text = ""
        for block in content_blocks:
            if block.get("type") == "text":
                text += block.get("text", "")
        return text

    async def close(self) -> None:
        await self._client.aclose()
