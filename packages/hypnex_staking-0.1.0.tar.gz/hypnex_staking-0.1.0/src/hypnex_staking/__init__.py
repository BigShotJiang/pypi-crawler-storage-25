"""hypnex-staking — on-chain helpers for the Morpheus AI capital pool.

Wraps DepositPool.stake() and claimReferrerTier() so a developer can stake
stETH/USDC/USDT/wBTC and capture MRC 73 unlocked-MOR referral rewards.

Quickstart (read-only):

    from hypnex_staking import Staker

    s = Staker()  # defaults to public llamarpc; no key needed for reads
    print(s.get_referrer_tiers("USDC"))

Quickstart (with signer):

    import os
    from hypnex_staking import Staker

    s = Staker(
        rpc_url=os.environ["ETH_RPC_URL"],
        private_key=os.environ["PRIVATE_KEY"],
        default_referrer="0xYourHypnexLabsAddress...",
    )
    tx = s.stake("USDC", amount=1000, claim_lock_end=0)
    print(tx)
"""

from ._constants import (
    BUILDERS_ADDRESSES,
    CHAINLINK_DATA_CONSUMER,
    DECIMALS,
    DEFAULT_BUILDERS_CHAIN,
    DEPOSIT_POOLS,
    DISTRIBUTOR_V2,
    ERC20_ADDRESSES,
    MOR_TOKEN,
    MRC73_TIER_MULTIPLIERS_PCT,
    MRC73_TIER_THRESHOLDS_STETH,
)
from .builders import (
    BuilderPool,
    BuildersClient,
    Subnet,
    SubnetData,
    SubnetMetadata,
    UserPoolData,
    UserSubnetData,
    pool_id_of,
    subnet_id_of,
)
from .staker import Position, ReferrerData, ReferrerTier, Staker

__version__ = "0.1.0"

__all__ = [
    # Capital pool
    "Staker",
    "Position",
    "ReferrerData",
    "ReferrerTier",
    "DEPOSIT_POOLS",
    "ERC20_ADDRESSES",
    "DISTRIBUTOR_V2",
    "CHAINLINK_DATA_CONSUMER",
    "DECIMALS",
    "MRC73_TIER_THRESHOLDS_STETH",
    "MRC73_TIER_MULTIPLIERS_PCT",
    # Builders pool / subnets (V4)
    "BuildersClient",
    "Subnet",
    "SubnetMetadata",
    "SubnetData",
    "UserSubnetData",
    "subnet_id_of",
    "BUILDERS_ADDRESSES",
    "DEFAULT_BUILDERS_CHAIN",
    # Backwards-compat V3 aliases
    "BuilderPool",
    "UserPoolData",
    "pool_id_of",
    # Shared
    "MOR_TOKEN",
    "__version__",
]
