"""Staker — the high-level interface to the Morpheus capital pool.

Provides:
  - read methods (no signer required, hit any RPC)
      * get_pool_address, get_token_address
      * get_position, get_referrer_data
      * get_referrer_tiers, quote_tier
  - write methods (signer required — MOVES REAL FUNDS)
      * approve, stake, claim_referrer_rewards

WARNING ABOUT WRITE METHODS:
    `stake()` and `claim_referrer_rewards()` send transactions that move real
    funds on Ethereum mainnet. Audit the constructed transaction (use the
    `dry_run=True` flag) before broadcasting. The `claim_referrer_rewards()`
    function is `payable` because the on-chain implementation may forward a
    LayerZero messaging fee — you must include `value` (in wei) when calling.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Optional

from eth_account import Account
from eth_account.signers.local import LocalAccount
from web3 import Web3
from web3.contract import Contract

from ._abi import DEPOSIT_POOL_ABI, ERC20_ABI
from ._constants import (
    DECIMALS,
    DEFAULT_REWARD_POOL_INDEX,
    DEPOSIT_POOLS,
    ENV_PRIVATE_KEY,
    ENV_REFERRER,
    ENV_RPC,
    ERC20_ADDRESSES,
    HYPNEX_DEFAULT_REFERRER,
    PUBLIC_ETH_RPC_FALLBACKS,
    ZERO_ADDRESS,
)


# --- domain models -------------------------------------------------------
@dataclass
class Position:
    """Stake position from DepositPool.usersData(address, poolIndex)."""
    last_stake: int
    deposited: int
    rate: int
    virtual_deposited: int
    pending_rewards: int
    claim_lock_start: int
    claim_lock_end: int
    referrer: str

    def deposited_human(self, decimals: int) -> float:
        return self.deposited / (10 ** decimals)


@dataclass
class ReferrerData:
    """Referrer data from DepositPool.referrersData(referrer, poolIndex)."""
    amount_staked: int
    virtual_amount_staked: int
    rate: int
    pending_rewards: int
    last_claim: int


@dataclass
class ReferrerTier:
    """One row of DepositPool.referrerTiers(poolIndex, tierIndex)."""
    amount_threshold: int
    multiplier: int  # PRECISION-scaled (1e25 == 1.0× in Morpheus contracts)


def _normalize_asset(asset: str) -> str:
    a = asset.upper()
    if a not in DEPOSIT_POOLS:
        raise ValueError(
            f"Unknown asset {asset!r}. Supported: {sorted(DEPOSIT_POOLS)}"
        )
    return a


def _checksum(addr: str) -> str:
    return Web3.to_checksum_address(addr)


def _connect_with_fallback(candidates: tuple[str, ...], timeout: int = 20) -> Web3:
    """Try each public RPC URL in order; return the first that supports
    *both* basic connection AND `eth_call` to a known contract.

    Several free public RPCs (notably Cloudflare) accept connections and
    return a chain_id but error on `eth_call` / `eth_getCode`. We probe with
    WETH.balanceOf(0x0) before accepting the RPC.
    """
    from ._constants import PROBE_ADDRESS, PROBE_CALLDATA

    last_err: Optional[Exception] = None
    for url in candidates:
        try:
            w3 = Web3(Web3.HTTPProvider(url, request_kwargs={"timeout": timeout}))
            if not w3.is_connected() or w3.eth.chain_id != 1:
                continue
            # Probe an eth_call to make sure view methods work.
            w3.eth.call({
                "to": Web3.to_checksum_address(PROBE_ADDRESS),
                "data": PROBE_CALLDATA,
            })
            return w3
        except Exception as e:  # noqa: BLE001 - any failure → try next RPC
            last_err = e
            continue
    raise ConnectionError(
        f"None of the public Ethereum RPCs accepted view calls ({len(candidates)} tried). "
        f"Pass rpc_url=... or set {ENV_RPC}. Last error: {last_err!r}"
    )


# --- main class ----------------------------------------------------------
class Staker:
    """High-level Morpheus capital-pool staking client.

    Read methods work with just an RPC. Write methods require an
    `eth_account.LocalAccount` (or a `private_key` string).

    Example:
        from hypnex_staking import Staker
        from web3 import Web3

        w3 = Web3(Web3.HTTPProvider("https://eth.llamarpc.com"))
        s = Staker(w3=w3)

        # Public read — no key needed:
        for asset in ("USDC", "USDT", "WBTC", "WETH"):
            print(asset, s.get_referrer_tiers(asset))

        # Write — requires PRIVATE_KEY env or explicit account:
        # s_signed = Staker(w3=w3, private_key=os.environ["PRIVATE_KEY"])
        # tx = s_signed.stake("USDC", amount=100, claim_lock_end=0)
    """

    def __init__(
        self,
        w3: Optional[Web3] = None,
        rpc_url: Optional[str] = None,
        account: Optional[LocalAccount] = None,
        private_key: Optional[str] = None,
        default_referrer: Optional[str] = None,
        reward_pool_index: int = DEFAULT_REWARD_POOL_INDEX,
    ) -> None:
        if w3 is None:
            url = rpc_url or os.environ.get(ENV_RPC)
            if url:
                w3 = Web3(Web3.HTTPProvider(url, request_kwargs={"timeout": 30}))
                if not w3.is_connected():
                    raise ConnectionError(
                        f"Configured RPC {url} did not respond. "
                        f"Override via {ENV_RPC} or pass rpc_url=..."
                    )
            else:
                w3 = _connect_with_fallback(PUBLIC_ETH_RPC_FALLBACKS)
        elif not w3.is_connected():
            raise ConnectionError("Provided Web3 instance is not connected.")
        self.w3 = w3
        self.reward_pool_index = reward_pool_index

        if account is None and private_key is None:
            private_key = os.environ.get(ENV_PRIVATE_KEY)
        if account is None and private_key:
            account = Account.from_key(private_key)
        self.account: Optional[LocalAccount] = account

        ref = default_referrer or os.environ.get(ENV_REFERRER) or HYPNEX_DEFAULT_REFERRER
        self.default_referrer: str = _checksum(ref) if ref != ZERO_ADDRESS else ZERO_ADDRESS

    # --- contract handles ------------------------------------------------
    def _pool(self, asset: str) -> Contract:
        a = _normalize_asset(asset)
        return self.w3.eth.contract(
            address=_checksum(DEPOSIT_POOLS[a]),
            abi=DEPOSIT_POOL_ABI,
        )

    def _erc20(self, asset: str) -> Contract:
        a = _normalize_asset(asset)
        return self.w3.eth.contract(
            address=_checksum(ERC20_ADDRESSES[a]),
            abi=ERC20_ABI,
        )

    # --- read methods ----------------------------------------------------
    def get_pool_address(self, asset: str) -> str:
        return _checksum(DEPOSIT_POOLS[_normalize_asset(asset)])

    def get_token_address(self, asset: str) -> str:
        return _checksum(ERC20_ADDRESSES[_normalize_asset(asset)])

    def get_decimals(self, asset: str) -> int:
        return DECIMALS[_normalize_asset(asset)]

    def get_position(self, address: str, asset: str) -> Position:
        """Read DepositPool.usersData(address, rewardPoolIndex)."""
        pool = self._pool(asset)
        result = pool.functions.usersData(_checksum(address), self.reward_pool_index).call()
        return Position(
            last_stake=result[0],
            deposited=result[1],
            rate=result[2],
            virtual_deposited=result[3],
            pending_rewards=result[4],
            claim_lock_start=result[5],
            claim_lock_end=result[6],
            referrer=result[7],
        )

    def get_referrer_data(self, referrer: str, asset: str) -> ReferrerData:
        """Read DepositPool.referrersData(referrer, rewardPoolIndex)."""
        pool = self._pool(asset)
        result = pool.functions.referrersData(
            _checksum(referrer), self.reward_pool_index
        ).call()
        return ReferrerData(
            amount_staked=result[0],
            virtual_amount_staked=result[1],
            rate=result[2],
            pending_rewards=result[3],
            last_claim=result[4],
        )

    def get_referrer_tiers(self, asset: str, max_tiers: int = 10) -> list[ReferrerTier]:
        """Read DepositPool.referrerTiers(poolIndex, idx) until it reverts.

        The mapping is `(uint256 => ReferrerTier[])`, so iterate by index until
        an out-of-bounds revert tells us we've consumed the array.
        """
        pool = self._pool(asset)
        tiers: list[ReferrerTier] = []
        for i in range(max_tiers):
            try:
                row = pool.functions.referrerTiers(self.reward_pool_index, i).call()
            except Exception:
                break
            tiers.append(ReferrerTier(amount_threshold=row[0], multiplier=row[1]))
        return tiers

    def quote_tier(
        self,
        asset: str,
        virtual_amount_staked: int,
    ) -> Optional[ReferrerTier]:
        """Given a referrer's virtual_amount_staked, return the tier they fall in.

        Returns None if below the lowest tier threshold.
        """
        tiers = self.get_referrer_tiers(asset)
        # Tiers are stored in ascending order; pick the highest one whose
        # threshold is met.
        match: Optional[ReferrerTier] = None
        for t in tiers:
            if virtual_amount_staked >= t.amount_threshold:
                match = t
            else:
                break
        return match

    # --- write methods (REQUIRE A SIGNER) -------------------------------
    def _require_account(self) -> LocalAccount:
        if self.account is None:
            raise RuntimeError(
                "This call moves real funds. Provide an account: "
                "Staker(account=Account.from_key(...)) or "
                f"set {ENV_PRIVATE_KEY} environment variable."
            )
        return self.account

    def approve(
        self,
        asset: str,
        amount: float,
        *,
        dry_run: bool = False,
    ) -> str:
        """Approve the asset's DepositPool to spend `amount` of the underlying
        ERC20. Required before stake() can succeed.
        """
        account = self._require_account()
        a = _normalize_asset(asset)
        decimals = DECIMALS[a]
        amt_wei = int(amount * (10 ** decimals))
        token = self._erc20(a)
        spender = self.get_pool_address(a)
        fn = token.functions.approve(spender, amt_wei)
        return self._send(fn, account=account, value=0, dry_run=dry_run)

    def stake(
        self,
        asset: str,
        amount: float,
        claim_lock_end: int = 0,
        referrer: Optional[str] = None,
        *,
        auto_approve: bool = True,
        dry_run: bool = False,
    ) -> str:
        """Stake `amount` of `asset` (USDC/USDT/WBTC/WETH) into the Morpheus
        DepositPool.

        Args:
            asset: One of 'USDC', 'USDT', 'WBTC', 'WETH'.
            amount: Human-readable amount (e.g. 100.5 for 100.5 USDC).
            claim_lock_end: Unix timestamp at which the voluntary additional
                claim-lock ends. Use 0 for no additional lock (the protocol's
                90-day default still applies — see MRC 46).
            referrer: Address to credit as referrer. Defaults to the Staker's
                `default_referrer` (which falls back to HYPNEX_REFERRER env or
                the zero address).
            auto_approve: If True, will issue an ERC20 approve() before stake.
            dry_run: If True, returns the encoded calldata without broadcasting.

        Returns:
            Transaction hash (or hex calldata if dry_run=True).
        """
        account = self._require_account()
        a = _normalize_asset(asset)
        decimals = DECIMALS[a]
        amt_wei = int(amount * (10 ** decimals))
        ref = _checksum(referrer) if referrer else self.default_referrer
        if auto_approve and not dry_run:
            allowance = self._erc20(a).functions.allowance(
                account.address, self.get_pool_address(a)
            ).call()
            if allowance < amt_wei:
                self.approve(a, amount)
        pool = self._pool(a)
        fn = pool.functions.stake(
            self.reward_pool_index,
            amt_wei,
            int(claim_lock_end),
            ref,
        )
        return self._send(fn, account=account, value=0, dry_run=dry_run)

    def claim_referrer_rewards(
        self,
        asset: str,
        receiver: Optional[str] = None,
        layerzero_fee_wei: int = 0,
        *,
        dry_run: bool = False,
    ) -> str:
        """Claim accumulated unlocked-MOR referrer rewards (per MRC 73).

        The on-chain function is `payable`; pass `layerzero_fee_wei` if the
        protocol forwards rewards via LayerZero (see MOROFT). For an
        Ethereum-mainnet receiver this is typically 0.
        """
        account = self._require_account()
        recv = _checksum(receiver) if receiver else account.address
        pool = self._pool(asset)
        fn = pool.functions.claimReferrerTier(self.reward_pool_index, recv)
        return self._send(fn, account=account, value=int(layerzero_fee_wei), dry_run=dry_run)

    # --- internal --------------------------------------------------------
    def _send(
        self,
        fn: Any,
        account: LocalAccount,
        value: int = 0,
        dry_run: bool = False,
    ) -> str:
        nonce = self.w3.eth.get_transaction_count(account.address)
        chain_id = self.w3.eth.chain_id
        tx = fn.build_transaction({
            "from": account.address,
            "nonce": nonce,
            "value": value,
            "chainId": chain_id,
        })
        if dry_run:
            return tx["data"]
        signed = account.sign_transaction(tx)
        tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
        return tx_hash.hex()
