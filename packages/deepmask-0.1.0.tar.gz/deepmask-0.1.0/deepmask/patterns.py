import re

PATTERNS = {
    "JWT_TOKEN": r'eyJ[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+\.?[A-Za-z0-9-_.+/=]*',
    "AWS_ACCESS_KEY": r'(?i)\b(A3T[A-Z0-9]|AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}\b',
    "AWS_SECRET_KEY": r'(?i)\b[A-Za-z0-9/+=]{40}\b',
    "PRIVATE_KEY_RSA": r'-----BEGIN RSA PRIVATE KEY-----[\s\S]+?-----END RSA PRIVATE KEY-----',
    "PRIVATE_KEY_GENERIC": r'-----BEGIN PRIVATE KEY-----[\s\S]+?-----END PRIVATE KEY-----',
    "GCP_API_KEY": r'AIza[0-9A-Za-z\\-_]{35}',
    "GITHUB_TOKEN": r'(?i)ghp_[0-9a-zA-Z]{36}|gho_[0-9a-zA-Z]{36}|github_pat_[0-9a-zA-Z_]{82}',
    "STRIPE_KEY": r'(?i)(sk_live|pk_live)_[0-9a-zA-Z]{24}',
    "CREDIT_CARD_GENERIC": r'\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|6(?:011|5[0-9]{2})[0-9]{12}|(?:2131|1800|35\d{3})\d{11})\b',
    "IBAN": r'\b[A-Z]{2}[0-9]{2}(?:[ ]?[0-9]{4}){3,5}[ ]?[0-9]{1,2}\b',
    "BITCOIN_ADDRESS": r'\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b|bc1[ac-hj-np-z02-9]{11,71}\b',
    "ETHEREUM_ADDRESS": r'\b0x[a-fA-F0-9]{40}\b',
    "DNI_NIE_ES": r'\b[XYZxyz]\d{7}[A-Za-z]|\b\d{8}[A-Za-z]\b',
    "EMAIL": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b',
    "PHONE_ES_INTL": r'\b(?:\+34|0034|34)?[\s-]?([6789][0-9]{8})\b',
    "SSN_USA": r'\b\d{3}-\d{2}-\d{4}\b',
    "IPV4": r'\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b',
    "MAC_ADDRESS": r'\b([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})\b'
}
