import argparse
import sys
import time
from pathlib import Path

from rich.console import Console
from rich.progress import track
from rich.panel import Panel

from .masker import DeepMasker
from .policy import PolicyLevel, SecurityAnomalyError
from .file_scanner import FileScanner
from .logger import log_scan_start

console = Console()

def main():
    parser = argparse.ArgumentParser(description="Deepmask")
    parser.add_argument("target", help="Target file or dir")
    parser.add_argument("--policy", choices=["strict", "warn", "silent"], default="strict")
    
    args = parser.parse_args()
    
    console.print(Panel.fit("[bold red]🛡️ DEEPMASK SECURITY ENGINE 🛡️[/bold red]", border_style="red"))
    
    policy_map = {
        "strict": PolicyLevel.STRICT,
        "warn": PolicyLevel.WARN_AND_MASK,
        "silent": PolicyLevel.SILENT_MASK
    }
    
    with console.status(f"[bold green]Loading Engine (Policy: {args.policy.upper()})...", spinner="bouncingBar"):
        masker = DeepMasker(policy=policy_map[args.policy])
        time.sleep(0.4) 
        
    try:
        archivos = FileScanner.get_target_files(args.target)
    except FileNotFoundError as e:
        console.print(f"\n[bold red]Error:[/bold red] {e}")
        sys.exit(1)

    if not archivos:
        sys.exit(0)

    log_scan_start(args.target)

    try:
        for filepath in track(archivos, description="[red]Scanning data..."):
            raw_text = FileScanner.read_file(filepath)
            masker.analyze_and_mask(raw_text)
    except SecurityAnomalyError as e:
        console.print("\n[bold white on red] ¡¡ LETHAL BLOCK TRIGGERED !! [/bold white on red]")
        console.print(f"[white]Reason:[/white] {e}")
        console.print(f"[white]File:[/white] [cyan]{filepath}[/cyan]")
        sys.exit(1)

    console.print("\n[bold green]✅ Clean.[/bold green]")
    sys.exit(0)

if __name__ == "__main__":
    main()
