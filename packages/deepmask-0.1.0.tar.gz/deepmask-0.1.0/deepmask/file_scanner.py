import os
from pathlib import Path
from typing import List

class FileScanner:
    IGNORED_DIRS = {'.git', 'node_modules', '__pycache__', 'venv', 'env', '.env', '.idea', '.vscode', 'dist', 'build'}
    VALID_EXT = {'.txt', '.csv', '.json', '.md', '.log', '.py', '.js', '.ts', '.html', '.css', '.yaml', '.yml', '.xml',
                 '.pdf', '.docx', '.xlsx', '.png', '.jpg', '.jpeg', '.mp3', '.wav', '.m4a'}

    @classmethod
    def get_target_files(cls, target_path: str) -> List[str]:
        path = Path(target_path).resolve()
        
        if not path.exists():
            raise FileNotFoundError(f"Target path not found: {target_path}")
            
        if path.is_file():
            return [str(path)] if not path.suffix or path.suffix.lower() in cls.VALID_EXT else []
            
        found_files = []
        for root, dirs, files in os.walk(path):
            dirs[:] = [d for d in dirs if d not in cls.IGNORED_DIRS and not d.startswith('.')]
            
            for file in files:
                ext = Path(file).suffix.lower()
                if not ext or ext in cls.VALID_EXT:
                    found_files.append(os.path.join(root, file))
                    
        return found_files

    @classmethod
    def read_file(cls, filepath: str) -> str:
        ext = Path(filepath).suffix.lower()
        
        if ext == '.pdf':
            return cls._read_pdf(filepath)
        elif ext == '.docx':
            return cls._read_docx(filepath)
        elif ext == '.xlsx':
            return cls._read_xlsx(filepath)
        elif ext in ('.png', '.jpg', '.jpeg'):
            return cls._read_image(filepath)
        elif ext in ('.mp3', '.wav', '.m4a'):
            return cls._read_audio(filepath)
        else:
            return cls._read_plaintext(filepath)

    @staticmethod
    def _read_pdf(filepath: str) -> str:
        try:
            from pypdf import PdfReader
            reader = PdfReader(filepath)
            text_blocks = []
            for page in reader.pages:
                text = page.extract_text()
                if text:
                    text_blocks.append(text)
            return "\n".join(text_blocks)
        except ImportError:
            raise ImportError(f"Missing pypdf for {filepath}")
        except Exception as e:
            raise Exception(f"Failed parsing PDF {filepath}: {e}")

    @staticmethod
    def _read_docx(filepath: str) -> str:
        try:
            import docx
            doc = docx.Document(filepath)
            text_blocks = [para.text for para in doc.paragraphs if para.text]
            return "\n".join(text_blocks)
        except ImportError:
            raise ImportError(f"Missing python-docx for {filepath}")
        except Exception as e:
            raise Exception(f"Failed parsing DOCX {filepath}: {e}")

    @staticmethod
    def _read_xlsx(filepath: str) -> str:
        try:
            import openpyxl
            wb = openpyxl.load_workbook(filepath, data_only=True)
            text_blocks = []
            for sheet in wb.sheetnames:
                ws = wb[sheet]
                for row in ws.iter_rows(values_only=True):
                    row_text = " ".join([str(cell) for cell in row if cell is not None])
                    if row_text.strip():
                        text_blocks.append(row_text)
            return "\n".join(text_blocks)
        except ImportError:
            raise ImportError(f"Missing openpyxl for {filepath}")
        except Exception as e:
            raise Exception(f"Failed parsing XLSX {filepath}: {e}")

    @staticmethod
    def _read_image(filepath: str) -> str:
        try:
            import easyocr
            reader = easyocr.Reader(['es', 'en'], gpu=False)
            results = reader.readtext(filepath, detail=0)
            return "\n".join(results)
        except ImportError:
            raise ImportError(f"Missing easyocr for {filepath}")
        except Exception as e:
            raise Exception(f"Failed OCR on {filepath}: {e}")

    @staticmethod
    def _read_audio(filepath: str) -> str:
        try:
            import whisper
            model = whisper.load_model("base")
            result = model.transcribe(filepath)
            return result.get("text", "")
        except ImportError:
            raise ImportError(f"Missing openai-whisper for {filepath}")
        except Exception as e:
            raise Exception(f"Failed STT on {filepath}: {e}")

    @staticmethod
    def _read_plaintext(filepath: str) -> str:
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return f.read()
        except UnicodeDecodeError:
            with open(filepath, 'r', encoding='latin-1') as f:
                return f.read()
