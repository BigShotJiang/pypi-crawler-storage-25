import logging
import json
from pathlib import Path

AUDIT_LOG_FILE = Path("deepmask_audit.log")

def _setup_logger():
    logger = logging.getLogger("DeepmaskAudit")
    logger.setLevel(logging.INFO)
    
    if not logger.handlers:
        file_handler = logging.FileHandler(AUDIT_LOG_FILE, encoding='utf-8')
        formatter = logging.Formatter('{"time": "%(asctime)s", "level": "%(levelname)s", "message": %(message)s}')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    return logger

audit_logger = _setup_logger()

def log_anomaly(filepath: str, anomalies: list):
    event = json.dumps({
        "event_type": "DATA_LEAK_PREVENTION",
        "file_compromised": str(filepath),
        "anomalies_detected": anomalies
    })
    audit_logger.critical(event)

def log_scan_start(target: str):
    audit_logger.info(json.dumps({"event_type": "SCAN_START", "target": target}))
