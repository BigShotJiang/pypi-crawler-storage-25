import re
import logging
from typing import Dict, Any, List

from .patterns import PATTERNS
from .policy import PolicyLevel, SecurityAnomalyError
from .file_scanner import FileScanner

try:
    from presidio_analyzer import AnalyzerEngine
    from presidio_anonymizer import AnonymizerEngine
    HAS_PRESIDIO = True
except ImportError:
    HAS_PRESIDIO = False

logging.basicConfig(level=logging.INFO, format='%(levelname)s: DEEPMASK -> %(message)s')

class DeepMasker:
    def __init__(self, replacement: str = "[REDACED]", policy: PolicyLevel = PolicyLevel.WARN_AND_MASK):
        self.replacement = replacement
        self.policy = policy
        self.rules = PATTERNS.copy()
        
        self.analyzer = None
        self.anonymizer = None
        if HAS_PRESIDIO:
            try:
                self.analyzer = AnalyzerEngine()
                self.anonymizer = AnonymizerEngine()
            except Exception as e:
                logging.error(f"Presidio AI model failed to load. Error: {e}")
                
    def analyze_and_mask(self, text: str) -> str:
        masked_text = text
        anomalies_found = []

        for rule_name, pattern in self.rules.items():
            matches = list(re.finditer(pattern, masked_text))
            for match in matches:
                anomalies_found.append(rule_name)
            
            custom_replacement = f"[{rule_name}_CENSURADO]" if self.replacement == "[REDACED]" else self.replacement
            masked_text = re.sub(pattern, custom_replacement, masked_text)

        if self.analyzer and self.anonymizer:
            nlp_results = self.analyzer.analyze(text=masked_text, entities=[], language='en')
            if nlp_results:
                for res in nlp_results:
                    anomalies_found.append(f"NLP_{res.entity_type}")
                
                masked_obj = self.anonymizer.anonymize(text=masked_text, analyzer_results=nlp_results)
                masked_text = masked_obj.text

        if anomalies_found:
            tipos_unicos = list(set(anomalies_found))
            alerta_msg = f"Data Blocked: {', '.join(tipos_unicos)}"
            
            from .logger import log_anomaly
            log_anomaly("In_Memory_Buffer", list(tipos_unicos))
            
            if self.policy == PolicyLevel.STRICT:
                logging.critical("STRICT POLICY TRIGGERED.")
                raise SecurityAnomalyError(f"Locked Actively: {alerta_msg}")
            elif self.policy == PolicyLevel.WARN_AND_MASK:
                logging.warning(alerta_msg)
                
        return masked_text

    def scan_file(self, filepath: str) -> str:
        raw_text = FileScanner.read_file(filepath)
        return self.analyze_and_mask(raw_text)
