from enum import Enum

class PolicyLevel(Enum):
    WARN_AND_MASK = "warn_and_mask"
    STRICT = "strict"
    SILENT_MASK = "silent_mask"

class SecurityAnomalyError(Exception):
    pass
