from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='deepmask',
    version='0.1.0',    
    description='Un paquete que elimina cualquier tipo de dato sensible que le envíes a la IA manteniendo tu privacidad',
    long_description=long_description,
    long_description_content_type="text/markdown",
    url='https://github.com/v019-labs/deepmask',
    author='v019 Labs',
    author_email='v019.exe@gmail.com',
    license='GNU General Public Affero License v3',
    packages=find_packages(),
    install_requires=[
        'presidio-analyzer>=2.2',
        'presidio-anonymizer>=2.2',
        'spacy>=3.7.0',
        'rich>=13.7.0',
        'pypdf>=4.1.0',
        'python-docx>=1.1.0',
        'openpyxl>=3.1.0',
        'easyocr>=1.7.0',
        'openai-whisper>=20231117',
    ],
    entry_points={
        'console_scripts': [
            'deepmask=deepmask.cli:main',
        ],
    },
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: GNU Affero General Public License v3 or later (AGPLv3+)',  
        'Operating System :: OS Independent',        
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
    python_requires='>=3.8',
)
