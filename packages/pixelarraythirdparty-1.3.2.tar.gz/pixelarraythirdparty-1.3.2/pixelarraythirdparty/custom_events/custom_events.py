from pixelarraythirdparty.client import AsyncClient
from typing import Any, Dict, List, Optional, Tuple


class CustomEventsManagerAsync(AsyncClient):
    """自定义事件：新建定义与上报（上报前须存在对应事件定义与字段 schema）。"""

    async def create_custom_event_definition(
        self,
        project_name: str,
        event_key: str,
        display_name: str,
        *,
        description: Optional[str] = None,
        category: str = "custom",
        field_schema: Optional[List[Dict[str, Any]]] = None,
        is_active: bool = True,
    ) -> Tuple[Dict[str, Any], bool]:
        """
        description:
            新建自定义事件定义（需 API Key；与 Portal「新建定义」一致，对应 POST /api/custom-events/definitions/create）
        parameters:
            project_name(str): 项目名称（与 projects.name 一致）
            event_key(str): 事件键（1~64 字符）
            display_name(str): 展示名
            description(str, optional): 说明
            category(str): 分类白名单，默认 custom
            field_schema(list, optional): 字段定义列表，每项含 name、type(string|number|boolean)、required、description
            is_active(bool): 是否启用，默认 True
        return:
            data(dict): 成功时为定义记录；失败时含 message 等
            success(bool): 是否成功
        """
        body: Dict[str, Any] = {
            "project_name": project_name,
            "event_key": event_key,
            "display_name": display_name,
            "category": category,
            "field_schema": field_schema or [],
            "is_active": is_active,
        }
        if description is not None:
            body["description"] = description
        return await self._request(
            "POST", "/api/custom-events/definitions/create", json=body
        )

    async def report_custom_event(
        self,
        project_name: str,
        event_key: str,
        payload: Dict[str, Any],
        client_occurred_at: Optional[str] = None,
    ) -> Tuple[Dict[str, Any], bool]:
        """
        description:
            上报单条自定义事件日志（JSON 载荷须符合 Portal 中配置的 field_schema）
        parameters:
            project_name(str): 项目名称（与 projects.name 一致）
            event_key(str): 事件键
            payload(dict): JSON 对象，键与类型须与定义一致
            client_occurred_at(str, optional): 客户端事件发生时间，ISO8601 字符串
        return:
            data(dict): 成功时为日志记录；失败时含 message 等
            success(bool): 是否成功
        """
        data: Dict[str, Any] = {
            "project_name": project_name,
            "event_key": event_key,
            "payload": payload,
        }
        if client_occurred_at is not None:
            data["client_occurred_at"] = client_occurred_at
        return await self._request("POST", "/api/custom-events/report", json=data)

    async def report_custom_events_batch(
        self,
        project_name: str,
        items: List[Dict[str, Any]],
    ) -> Tuple[Dict[str, Any], bool]:
        """
        description:
            批量上报自定义事件（同一 project_name；任一条校验失败则整批失败）
        parameters:
            project_name(str): 项目名称（与 projects.name 一致）
            items(list): 每项为 dict，须含 event_key、payload；可选 client_occurred_at（字符串）
        return:
            data(dict): 成功时为日志列表；失败时含 message
            success(bool): 是否成功
        """
        body = {"project_name": project_name, "items": items}
        return await self._request("POST", "/api/custom-events/report/batch", json=body)
