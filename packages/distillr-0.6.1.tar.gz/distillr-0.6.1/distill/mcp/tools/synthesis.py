"""MCP tools — synthesis: run or regenerate synthesis for a topic."""

from __future__ import annotations

import json

from mcp.server.fastmcp import Context

from distill.mcp import server as _server
from distill.pipeline.costs import CostTracker, save_run_log

__all__: list[str] = []


@_server.mcp.tool()
async def synthesize(topic: str, force: bool = False, ctx: Context = None) -> str:  # noqa: C901
    """Run or regenerate synthesis for a topic across all sources.

    Args:
        topic: Topic to synthesize
        force: Force regeneration even if fresh
    """
    config = _server._config()
    if not config.xai_api_key:
        return json.dumps({"status": "error", "error": "XAI_API_KEY not configured."})

    from distill.pipeline.synthesis.corpus import synthesize_corpus
    from distill.pipeline.synthesis.topic import synthesize_channel, synthesize_topic

    lib = _server._lib(config)
    tracker = CostTracker()
    channels = lib.get_channels(topic)
    results = []
    total_steps = len(channels) + 2  # channels + topic + corpus

    for i, ch in enumerate(channels):
        if ctx:
            await ctx.report_progress(progress=i, total=total_steps)
        try:
            synthesize_channel(topic, ch.name, config, tracker=tracker)
            results.append({"channel": ch.name, "status": "ok"})
        except Exception as e:
            results.append({"channel": ch.name, "status": "error", "error": str(e)})

    # Topic synthesis
    if ctx:
        await ctx.report_progress(progress=len(channels), total=total_steps)
    try:
        synthesize_topic(topic, config, tracker=tracker)
        results.append({"scope": "topic", "status": "ok"})
    except Exception as e:
        results.append({"scope": "topic", "status": "error", "error": str(e)})

    # Corpus synthesis
    if ctx:
        await ctx.report_progress(progress=len(channels) + 1, total=total_steps)
    try:
        corpus = synthesize_corpus(topic, config, tracker=tracker)
        if corpus:
            results.append({"scope": "corpus", "status": "ok"})
        else:
            results.append({"scope": "corpus", "status": "skipped", "reason": "no mixed sources"})
    except Exception as e:
        results.append({"scope": "corpus", "status": "error", "error": str(e)})

    if ctx:
        await ctx.report_progress(progress=total_steps, total=total_steps)

    save_run_log(config.library_dir, "synthesize", tracker)
    return json.dumps(
        {
            "status": "complete",
            "results": results,
            "cost": _server._cost_summary(tracker),
        },
        indent=2,
    )
