# floxoris

Minimal async Python SDK for the Floxoris AI API gateway.

## Install

```bash
pip install floxoris
```

## Quickstart

```python
import floxoris

floxoris.api_key = "ak-fs-..."

result = await floxoris.moderate("ти дебіл")
print(result.label)        # "toxic"
print(result.toxic_score)  # 0.89
print(result.safe_score)   # 0.10
```

Specify a model explicitly:

```python
import floxoris

floxoris.api_key = "ak-fs-..."

result = await floxoris.moderate(
    "hello world",
    model="floxoris/harmony-v0",
)
```

Use the explicit client when you want to control connection lifecycle:

```python
from floxoris import AsyncClient

async with AsyncClient(api_key="ak-fs-...") as client:
    result = await client.moderate("text here")
```

## Configuration

Module-level configuration:

```python
import floxoris

floxoris.api_key = "ak-fs-..."
floxoris.base_url = "https://floxoris.xyz"
floxoris.default_model = "floxoris/harmony-v0"
```

The SDK:

- sends `Authorization: Bearer <api_key>`
- posts moderation requests to the Floxoris gateway `POST /requests`
- retries once automatically on `5xx`
- raises typed exceptions for auth, rate limit, and API failures

## Response model

```python
from dataclasses import dataclass


@dataclass
class ModerationResult:
    label: str
    class_id: int
    safe_score: float
    toxic_score: float
    latency_ms: float | None
    model: str
```

## Exceptions

```python
from floxoris import APIError, AuthError, FloxorisError, RateLimitError
```
