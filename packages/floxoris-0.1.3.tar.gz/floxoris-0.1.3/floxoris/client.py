from __future__ import annotations

from typing import Any

from ._http import _AsyncHTTPClient
from .exceptions import FloxorisError
from .models import ModerationResult

DEFAULT_MODEL = "floxoris/harmony-v0"
DEFAULT_BASE_URL = "https://floxoris.xyz"
REQUESTS_PATH = "requests"


class AsyncClient:
    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        default_model: str = DEFAULT_MODEL,
        timeout: float = 30.0,
    ) -> None:
        if api_key is None:
            import floxoris as floxoris_module

            api_key = floxoris_module.api_key

        if base_url is None:
            import floxoris as floxoris_module

            base_url = floxoris_module.base_url

        if not api_key:
            raise FloxorisError(
                "API key is required. Set floxoris.api_key or pass api_key explicitly."
            )

        self.api_key = api_key
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.default_model = default_model
        self.timeout = timeout
        self._http = _AsyncHTTPClient(
            api_key=self.api_key,
            base_url=self.base_url,
            timeout=self.timeout,
        )

    async def __aenter__(self) -> "AsyncClient":
        await self._http.__aenter__()
        return self

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
        await self._http.__aexit__(exc_type, exc, tb)

    async def aclose(self) -> None:
        await self._http.aclose()

    async def moderate(
        self, text: str, *, model: str | None = None
    ) -> ModerationResult:
        payload = {
            "text": text,
            "model": model or self.default_model,
        }
        data = await self._http.post_json(REQUESTS_PATH, payload)
        return self._parse_moderation_result(data, requested_model=payload["model"])

    def _parse_moderation_result(
        self,
        payload: dict[str, Any],
        *,
        requested_model: str,
    ) -> ModerationResult:
        # Debugging: Inspect raw response structure as requested
        print(f"DEBUG: Floxoris response: {payload}")

        result_payload = payload.get("result")
        if isinstance(result_payload, dict):
            payload = result_payload

        try:
            latency = payload.get("latency_ms")
            if latency is not None:
                latency = float(latency)

            # Support both Harmony-style (label/score) and Floxoris-style responses
            label = str(payload.get("label", ""))
            flagged = bool(payload.get("flagged", False))

            toxic_score = payload.get("toxic_score")
            safe_score = payload.get("safe_score")
            generic_score = payload.get("score")

            if generic_score is not None:
                generic_score = float(generic_score)
                if label == "toxic" or flagged:
                    toxic_score = (
                        toxic_score if toxic_score is not None else generic_score
                    )
                elif label in ("neutral", "safe"):
                    safe_score = safe_score if safe_score is not None else generic_score
                else:
                    # Default to toxic_score if we can't be sure
                    toxic_score = (
                        toxic_score if toxic_score is not None else generic_score
                    )

            # Normalize scores
            toxic_score = float(toxic_score) if toxic_score is not None else 0.0
            if safe_score is not None:
                safe_score = float(safe_score)
            else:
                safe_score = 1.0 - toxic_score

            # Infer label if missing
            if not label:
                label = "toxic" if (flagged or toxic_score > 0.5) else "neutral"

            if not flagged and toxic_score > 0.5:
                flagged = True

            return ModerationResult(
                label=label,
                class_id=payload.get("class_id"),  # Use .get() to avoid KeyError
                safe_score=safe_score,
                toxic_score=toxic_score,
                latency_ms=latency,
                model=str(payload.get("model", requested_model)),
                flagged=flagged,
                categories=payload.get("categories"),
                category_scores=payload.get("category_scores"),
            )
        except (TypeError, ValueError) as exc:
            # Print payload on error for easier debugging
            print(f"ERROR: Failed to parse payload: {payload}")
            raise FloxorisError("API returned an invalid moderation response.") from exc
