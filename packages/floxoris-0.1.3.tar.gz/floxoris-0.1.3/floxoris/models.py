from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class ModerationResult:
    label: str
    class_id: int | None
    safe_score: float
    toxic_score: float
    latency_ms: float | None
    model: str
    flagged: bool = False
    categories: dict[str, bool] | None = None
    category_scores: dict[str, float] | None = None
