from logging import (
    Logger,
)
from typing import Literal

from fa_purity import (
    Cmd,
    Coproduct,
    FrozenDict,
    FrozenList,
    Maybe,
    Result,
    ResultE,
    cast_exception,
)
from fa_purity.json import (
    JsonObj,
    JsonPrimitive,
    JsonValue,
)
from fluidattacks_etl_utils.date_range import (
    DateRange,
)
from pure_requests.basic import (
    HttpClient,
    HttpClientFactory,
    Params,
)
from pure_requests.response import (
    json_decode,
)
from requests import (
    Response,
)

from fluidattacks_timedoctor_sdk.auth import (
    AuthToken,
)
from fluidattacks_timedoctor_sdk.client._common import (
    DataPage,
    decode_data,
    decode_page,
    with_retry_handler,
)
from fluidattacks_timedoctor_sdk.core import (
    CompanyId,
    ComputerActivity,
    UserId,
    new_json,
    relative_endpoint,
)

from ._decode import (
    decode_activities,
)


def _decode_data(
    data: Coproduct[JsonObj, FrozenList[JsonObj]],
) -> ResultE[DataPage[FrozenList[ComputerActivity]]]:
    return data.map(
        lambda j: decode_page(j, lambda v: decode_data(v, decode_activities)),
        lambda _: Result.failure(ValueError("Expected json but got a list")).alt(
            cast_exception
        ),
    )


def _activity_params(
    activity_type: Literal["video", "screenshot"],
) -> tuple[str, str, str]:
    if activity_type == "video":
        return (
            "api/1.0/files/video",
            "get_activity_video",
            "API: get_activity_video(%s, user=%s, dates=%s, page=%s)",
        )
    return (
        "api/1.0/files/screenshot",
        "get_activity_screenshot",
        "API: get_activity_screenshot(%s, user=%s, dates=%s, page=%s)",
    )


def get_activity_files(
    log: Logger,
    token: AuthToken,
    company: CompanyId,
    user: UserId,
    dates: DateRange,
    activity_type: Literal["video", "screenshot"],
) -> Cmd[ResultE[FrozenList[ComputerActivity]]]:
    return _get_activity_by_type(log, token, company, user, dates, activity_type)


def _decode_response(
    response: Response,
) -> ResultE[DataPage[FrozenList[ComputerActivity]]]:
    return json_decode(response).alt(cast_exception).bind(_decode_data)


def _get_page(
    client: HttpClient,
    company: CompanyId,
    user: UserId,
    dates: DateRange,
    page_id: Maybe[str],
    endpoint: str,
) -> Cmd[ResultE[DataPage[FrozenList[ComputerActivity]]]]:
    get_raw_page = client.get(
        relative_endpoint(endpoint),
        Params(
            FrozenDict(
                {
                    "company": JsonValue.from_primitive(
                        JsonPrimitive.from_str(company.company)
                    ),
                    "user": JsonValue.from_primitive(
                        JsonPrimitive.from_str(user.user_id)
                    ),
                    "from": JsonValue.from_primitive(
                        JsonPrimitive.from_str(dates.from_date.date_time.isoformat()),
                    ),
                    "to": JsonValue.from_primitive(
                        JsonPrimitive.from_str(dates.to_date.date_time.isoformat()),
                    ),
                }
                | page_id.map(
                    lambda p: {
                        "page": JsonValue.from_primitive(JsonPrimitive.from_str(p))
                    },
                ).value_or({}),
            ),
        ),
    )
    return with_retry_handler(get_raw_page, 10).map(lambda r: r.bind(_decode_response))


def _go(
    log: Logger,
    client: HttpClient,
    company: CompanyId,
    user: UserId,
    dates: DateRange,
    endpoint: str,
    log_message: str,
    page: Maybe[str],
    acc: FrozenList[ComputerActivity],
) -> Cmd[ResultE[FrozenList[ComputerActivity]]]:
    def _continue(
        data_page: DataPage[FrozenList[ComputerActivity]],
    ) -> Cmd[ResultE[FrozenList[ComputerActivity]]]:
        new_acc: FrozenList[ComputerActivity] = acc + tuple(
            item for sublist in data_page.items for item in sublist
        )
        return data_page.next_page.map(
            lambda _: _go(
                log,
                client,
                company,
                user,
                dates,
                endpoint,
                log_message,
                data_page.next_page,
                new_acc,
            )
        ).value_or(Cmd.wrap_value(Result.success(new_acc)))

    def _on_failure(err: Exception) -> Cmd[ResultE[FrozenList[ComputerActivity]]]:
        return Cmd.wrap_value(Result.failure(err))

    def _on_result(
        r: ResultE[DataPage[FrozenList[ComputerActivity]]],
    ) -> Cmd[ResultE[FrozenList[ComputerActivity]]]:
        return r.to_coproduct().map(_continue, _on_failure)

    log_cmd: Cmd[None] = Cmd.wrap_impure(
        lambda: log.info(log_message, company, user, dates, page)
    )
    return log_cmd + _get_page(client, company, user, dates, page, endpoint).bind(
        _on_result
    )


def _get_activity_by_type(
    log: Logger,
    token: AuthToken,
    company: CompanyId,
    user: UserId,
    dates: DateRange,
    activity_type: Literal["video", "screenshot"],
) -> Cmd[ResultE[FrozenList[ComputerActivity]]]:
    endpoint, _, log_message = _activity_params(activity_type)
    headers = new_json({"Authorization": " ".join(["JWT", token.token])})
    client = HttpClientFactory.new_client(None, headers, None)
    empty: FrozenList[ComputerActivity] = ()
    return _go(
        log, client, company, user, dates, endpoint, log_message, Maybe.empty(), empty
    )
