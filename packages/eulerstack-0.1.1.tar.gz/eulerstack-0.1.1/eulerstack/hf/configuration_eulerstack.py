from __future__ import annotations

from typing import Any, Dict, Optional

# transformers 버전에 따라 PreTrainedConfig 심볼이 없을 수 있어 호환 import 처리
try:
    from transformers import PreTrainedConfig as HFPreTrainedConfig
except Exception:  # pragma: no cover
    from transformers import PretrainedConfig as HFPreTrainedConfig  # type: ignore


class EulerStackConfig(HFPreTrainedConfig):
    """
    Hugging Face compatible configuration for EulerStack models.

    - Keep it JSON-serializable.
    - Accept **kwargs and forward to HF base config for compatibility.
    - Store assembly decisions (tokenizer/positional/memory/routing/blocks/stack)
      so the model can be reconstructed from config.json alone.
    """

    model_type = "eulerstack"
    keys_to_ignore_at_inference = ["past_key_values"]

    # HF 표준 필드명(hidden_size/num_hidden_layers/...)을 EulerStack 내부 필드명으로 매핑
    # PretrainedConfig.__getattribute__/__setattr__가 이 매핑을 사용합니다. [web:183]
    attribute_map = {
        "hidden_size": "d_model",
        "num_attention_heads": "n_heads",
        "num_hidden_layers": "n_layers",
        "max_position_embeddings": "max_seq_len",
    }

    def __init__(
        self,
        # Core LM
        vocab_size: int = 50257,
        max_seq_len: int = 32768,
        d_model: int = 2048,
        n_layers: int = 32,
        n_heads: int = 16,
        mlp_ratio: int = 4,
        norm: str = "rmsnorm",
        dropout: float = 0.0,
        # Assembly sub-specs (all JSON-serializable dicts)
        tokenizer: Optional[Dict[str, Any]] = None,
        positional: Optional[Dict[str, Any]] = None,
        memory: Optional[Dict[str, Any]] = None,
        routing: Optional[Dict[str, Any]] = None,
        stack: Optional[Dict[str, Any]] = None,
        blocks: Optional[Dict[str, Any]] = None,
        # Phase C (v1): bundle for Phase B extensions that do not map cleanly
        # into the existing sub-sections. Stored verbatim and round-tripped.
        # Keys used by the compiler: `execution_modes`, `transition`,
        # `schedule_kinds`. Other keys are preserved for plugin consumers.
        v1_extensions: Optional[Dict[str, Any]] = None,
        # HF common knobs
        tie_word_embeddings: bool = True,
        torch_dtype: Optional[str] = "bfloat16",
        **kwargs: Any,
    ) -> None:
        self.vocab_size = int(vocab_size)
        self.max_seq_len = int(max_seq_len)

        self.d_model = int(d_model)
        self.n_layers = int(n_layers)
        self.n_heads = int(n_heads)
        self.mlp_ratio = int(mlp_ratio)

        self.norm = str(norm)
        self.dropout = float(dropout)

        self.tokenizer = tokenizer or {}
        self.positional = positional or {}
        self.memory = memory or {}
        self.routing = routing or {}
        self.stack = stack or {}
        self.blocks = blocks or {}
        self.v1_extensions = v1_extensions or {}

        try:
            super().__init__(
                tie_word_embeddings=tie_word_embeddings,
                dtype=torch_dtype,
                **kwargs,
            )
        except TypeError:
            super().__init__(
                tie_word_embeddings=tie_word_embeddings,
                torch_dtype=torch_dtype,
                **kwargs,
            )

    @property
    def num_hidden_layers(self) -> int:
        # generate/DynamicCache 등이 기대하는 표준 속성 제공 (attribute_map으로도 되지만 안전장치) [web:6]
        return int(self.n_layers)

    @property
    def head_dim(self) -> int:
        if self.n_heads <= 0:
            return 0
        return self.d_model // self.n_heads

    def validate(self) -> None:
        if self.vocab_size <= 0:
            raise ValueError("vocab_size must be positive.")
        if self.max_seq_len <= 0:
            raise ValueError("max_seq_len must be positive.")
        if self.d_model <= 0:
            raise ValueError("d_model must be positive.")
        if self.n_layers <= 0:
            raise ValueError("n_layers must be positive.")
        if self.n_heads <= 0:
            raise ValueError("n_heads must be positive.")
        if self.d_model % self.n_heads != 0:
            raise ValueError("d_model must be divisible by n_heads.")
        if self.mlp_ratio <= 0:
            raise ValueError("mlp_ratio must be positive.")

        if self.stack and not isinstance(self.stack, dict):
            raise ValueError("stack must be a dict.")
        if self.blocks and not isinstance(self.blocks, dict):
            raise ValueError("blocks must be a dict.")
