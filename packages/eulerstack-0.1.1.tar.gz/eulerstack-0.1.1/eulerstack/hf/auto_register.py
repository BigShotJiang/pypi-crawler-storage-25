# eulerstack/hf/auto_register.py
from __future__ import annotations

from transformers import AutoConfig, AutoModelForCausalLM

from .configuration_eulerstack import EulerStackConfig
from .modeling_eulerstack import EulerStackForCausalLM


def register_eulerstack_auto_classes(exist_ok: bool = True) -> None:
    """
    Register EulerStack config/model into Hugging Face auto classes (process-local).

    Additionally, register_for_auto_class() is invoked so that save_pretrained() can
    embed auto_map + copy modeling/config python files into the artifact folder,
    enabling Auto* .from_pretrained(..., trust_remote_code=True). [web:702][web:145]
    """
    # ---- enable "trust_remote_code" packaging via auto_map ----
    # These calls configure which Auto classes this config/model correspond to. [web:117]
    try:
        EulerStackConfig.register_for_auto_class()
    except Exception:
        # ok if transformers version doesn't expose it the same way
        pass

    try:
        EulerStackForCausalLM.register_for_auto_class("AutoModelForCausalLM")
    except Exception:
        pass

    # ---- process-local registration (old behavior) ----
    try:
        AutoConfig.register(EulerStackConfig.model_type, EulerStackConfig, exist_ok=exist_ok)
    except TypeError:
        try:
            AutoConfig.register(EulerStackConfig.model_type, EulerStackConfig)
        except ValueError:
            if not exist_ok:
                raise

    try:
        AutoModelForCausalLM.register(EulerStackConfig, EulerStackForCausalLM, exist_ok=exist_ok)
    except TypeError:
        try:
            AutoModelForCausalLM.register(EulerStackConfig, EulerStackForCausalLM)
        except ValueError:
            if not exist_ok:
                raise
