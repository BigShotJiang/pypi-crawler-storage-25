# eulerstack/hf/modeling_eulerstack.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers import PreTrainedModel
from transformers.generation import GenerationMixin
from transformers.modeling_outputs import BaseModelOutputWithPast
from transformers.utils import ModelOutput

from .configuration_eulerstack import EulerStackConfig

# Blocks
from eulerstack.blocks.attention import CausalSelfAttention
from eulerstack.blocks.hyena import HyenaBlock
from eulerstack.blocks.mamba import MambaBlock
from eulerstack.blocks.retnet import RetNetBlock
from eulerstack.blocks.norms import get_norm
from eulerstack.blocks.mlp import build_mlp

# Components
from eulerstack.components.positional import build_rope_cache
from eulerstack.plugins.registry import get_plugin_registry


PastKeyValues = Optional[Tuple[Any, ...]]


@dataclass
class EulerStackCausalLMOutputWithPast(ModelOutput):
    """
    Causal LM output + optional MoE auxiliary diagnostics.

    ModelOutput subclasses are used across Transformers for structured outputs. [web:709][web:708]
    """
    loss: Optional[torch.FloatTensor] = None
    logits: Optional[torch.FloatTensor] = None
    past_key_values: Optional[Tuple[Any, ...]] = None
    hidden_states: Optional[Tuple[torch.FloatTensor, ...]] = None
    attentions: Optional[Tuple[torch.FloatTensor, ...]] = None

    # EulerStack extra payload
    moe_aux: Optional[Dict[str, Any]] = None


def _merge_dicts(*ds: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for d in ds:
        if not d:
            continue
        for k, v in d.items():
            out[k] = v
    return out


def _expand_stack_from_config(config: EulerStackConfig) -> List[Dict[str, Any]]:
    """
    Expand config.stack (dict) into per-layer list of dicts with length == config.n_layers.

    Expected config.stack format (stored in config.json):
      {
        "pattern": [ {"block":"mamba","repeat":3}, {"block":"attn","repeat":1,"attn":{"type":"local","window":2048}}, ... ],
        "repeat": 6,
        "tail": [ {"block":"mamba","repeat":2} ]
      }
    """
    stack = getattr(config, "stack", None) or {}
    if not isinstance(stack, dict):
        raise ValueError("config.stack must be a dict")

    def _expand_items(items: Any) -> List[Dict[str, Any]]:
        if items is None:
            return []
        if not isinstance(items, list):
            raise ValueError("stack.pattern/tail must be lists")
        out: List[Dict[str, Any]] = []
        for it in items:
            if not isinstance(it, dict):
                raise ValueError("each stack item must be a dict")
            rep = int(it.get("repeat", 1))
            if rep <= 0:
                raise ValueError("repeat must be >= 1")
            base = dict(it)
            base.pop("repeat", None)
            out.extend([dict(base) for _ in range(rep)])
        return out

    pattern = _expand_items(stack.get("pattern", []))
    repeat = int(stack.get("repeat", 1))
    if repeat <= 0:
        raise ValueError("stack.repeat must be >= 1")
    tail = _expand_items(stack.get("tail", []))

    layers = (pattern * repeat) + tail
    if len(layers) != int(config.n_layers):
        raise ValueError(f"Expanded stack produced {len(layers)} layers, but config.n_layers={config.n_layers}.")
    return layers


def _infer_past_len(past_key_values: PastKeyValues) -> int:
    """
    Best-effort infer past length from past_key_values.

    Supports:
    - RetNet cache (new): (state_num, state_den, past_len)
      where state_num/state_den are tensors and past_len is int or 0-d tensor.
    - RetNet cache (old): (state, past_len)
    - Attention KV cache: (k, v) with k shape (B, H, S, D). [web:143]
    """
    if past_key_values is None:
        return 0

    for layer_cache in past_key_values:
        if layer_cache is None:
            continue

        if isinstance(layer_cache, (tuple, list)):
            # RetNet (new): (state_num, state_den, past_len)
            if len(layer_cache) == 3:
                state_num, state_den, past_len = layer_cache
                if torch.is_tensor(state_num) and torch.is_tensor(state_den):
                    if isinstance(past_len, int):
                        return int(past_len)
                    if torch.is_tensor(past_len) and past_len.numel() == 1:
                        return int(past_len.item())

            # RetNet (old): (state, past_len)
            if len(layer_cache) == 2:
                state, past_len = layer_cache
                if torch.is_tensor(state):
                    if isinstance(past_len, int):
                        return int(past_len)
                    if torch.is_tensor(past_len) and past_len.numel() == 1:
                        return int(past_len.item())

            # Attention KV: (k, v)
            if len(layer_cache) >= 1 and torch.is_tensor(layer_cache[0]):
                k = layer_cache[0]
                if k.dim() >= 3:
                    return int(k.size(-2))
                return 0

    return 0


def _make_position_ids(
    batch_size: int,
    q_len: int,
    past_len: int,
    device: torch.device,
) -> torch.LongTensor:
    ids = torch.arange(past_len, past_len + q_len, device=device, dtype=torch.long).unsqueeze(0)
    return ids.expand(batch_size, -1)


class _BackboneAdapter(nn.Module):
    """
    Unify calling convention across different block families.

    Supports blocks returning:
      - (out, past)
      - (out, past, aux_dict)
      - out
      - (out, aux_dict)
    """

    def __init__(self, impl: nn.Module, kind: str):
        super().__init__()
        self.impl = impl
        self.kind = kind

    def forward(
        self,
        x: torch.Tensor,
        *,
        attention_mask: Optional[torch.Tensor] = None,
        use_cache: bool = False,
        past_key_values: Optional[Any] = None,
        rope_cos: Optional[torch.Tensor] = None,
        rope_sin: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        output_aux: bool = False,
    ) -> Tuple[torch.Tensor, Optional[Any], Optional[Dict[str, Any]]]:
        if self.kind == "attn":
            y = self.impl(
                x,
                attention_mask=attention_mask,
                use_cache=use_cache,
                past_key_value=past_key_values,
                rope_cos=rope_cos,
                rope_sin=rope_sin,
                position_ids=position_ids,
            )
            if isinstance(y, (tuple, list)) and len(y) == 3:
                out, new_past, aux = y
                return out, new_past, aux if isinstance(aux, dict) else None
            out, new_past = y
            return out, new_past, None

        if self.kind == "retnet":
            y = self.impl(
                x,
                attention_mask=attention_mask,
                use_cache=use_cache,
                past_key_value=past_key_values,
                rope_cos=rope_cos,
                rope_sin=rope_sin,
                position_ids=position_ids,
                output_aux=output_aux,
            )
            if isinstance(y, (tuple, list)) and len(y) == 3:
                out, new_past, aux = y
                return out, new_past, aux if isinstance(aux, dict) else None
            out, new_past = y
            return out, new_past, None
        
        # in _BackboneAdapter.forward()

        if self.kind == "hyena":
            y = self.impl(
                x,
                attention_mask=attention_mask,
                use_cache=use_cache,
                past_key_value=past_key_values,
                rope_cos=rope_cos,
                rope_sin=rope_sin,
                position_ids=position_ids,
                output_aux=output_aux,
            )
            if isinstance(y, (tuple, list)) and len(y) == 3:
                out, new_past, aux = y
                return out, new_past, aux if isinstance(aux, dict) else None
            if isinstance(y, (tuple, list)) and len(y) == 2:
                out, new_past = y
                return out, new_past, None
            return y, None, None


        if self.kind in ("mamba"):
            y = self.impl(x, output_aux=output_aux)
            if isinstance(y, (tuple, list)) and len(y) == 2:
                out, aux = y
                return out, None, aux if isinstance(aux, dict) else None
            return y, None, None

        # Plugin-supplied mixers follow the attention-shaped convention:
        # accept all standard kwargs (attention_mask, use_cache, past,
        # rope_*, position_ids, output_aux) and return (out, past, aux)
        # or (out, past) or out. The common case is (out, None, None).
        y = self.impl(
            x,
            attention_mask=attention_mask,
            use_cache=use_cache,
            past_key_value=past_key_values,
            rope_cos=rope_cos,
            rope_sin=rope_sin,
            position_ids=position_ids,
            output_aux=output_aux,
        )
        if isinstance(y, (tuple, list)) and len(y) == 3:
            out, new_past, aux = y
            return out, new_past, aux if isinstance(aux, dict) else None
        if isinstance(y, (tuple, list)) and len(y) == 2:
            out, new_past = y
            return out, new_past, None
        return y, None, None


class EulerStackLayer(nn.Module):
    """
    Decoder layer:
      x = x + Backbone(Norm(x))
      x = x + MLP(Norm(x))

    Backbone is created directly from EulerStackConfig (no external wiring).
    """

    def __init__(
        self,
        config: EulerStackConfig,
        layer_spec: Dict[str, Any],
        *,
        moe_cfg: Dict[str, Any],
        blocks_defaults: Dict[str, Dict[str, Any]],
        rope_enabled: bool,
    ):
        super().__init__()
        self.config = config
        self.layer_spec = layer_spec

        self.norm1 = get_norm(str(config.norm), int(config.d_model))
        self.norm2 = get_norm(str(config.norm), int(config.d_model))

        block = str(layer_spec.get("block", "attn")).lower()
        extra = layer_spec.get("extra", {})
        extra = extra if isinstance(extra, dict) else {}

        def _pop_keys(d: Dict[str, Any], *keys: str) -> Dict[str, Any]:
            # remove keys that are passed explicitly to constructors to avoid "multiple values" errors
            for k in keys:
                d.pop(k, None)
            return d

        if block == "attn":
            attn_over = layer_spec.get("attn", {})
            attn_over = attn_over if isinstance(attn_over, dict) else {}

            window = attn_over.get("window", None)
            if attn_over.get("type", None) == "local" and window is None:
                window = attn_over.get("local_window", None)

            cfg = _merge_dicts(
                blocks_defaults.get("attn", {}),
                attn_over,
                extra,
            )

            # Phase C Tier-3 runtime: pull MLA latent_dim from _v1_extras if
            # present (compile-time shim preserves the original v1 spec field).
            v1_extras = layer_spec.get("_v1_extras", {}) or {}
            latent_dim = v1_extras.get("attention_latent_dim")

            self.backbone = _BackboneAdapter(
                CausalSelfAttention(
                    d_model=int(config.d_model),
                    n_heads=int(config.n_heads),
                    dropout=float(config.dropout),
                    qkv_bias=bool(cfg.get("qkv_bias", False)),
                    attn_drop=float(cfg.get("attn_drop", 0.0)),
                    window=window if window is not None else cfg.get("window", None),
                    rope=bool(cfg.get("rope", rope_enabled)),
                    latent_dim=int(latent_dim) if latent_dim else None,
                ),
                "attn",
            )

        elif block == "mamba":
            cfg = _merge_dicts(blocks_defaults.get("mamba", {}), extra)

            if bool(cfg.get("use_moe", False)):
                cfg = dict(cfg)
                cfg["moe"] = _merge_dicts(
                    moe_cfg,
                    cfg.get("moe", {}) if isinstance(cfg.get("moe", {}), dict) else {},
                )

            _pop_keys(cfg, "d_model", "norm", "dropout", "mlp_ratio")

            self.backbone = _BackboneAdapter(
                MambaBlock(
                    d_model=int(config.d_model),
                    norm=str(config.norm),
                    dropout=float(config.dropout),
                    mlp_ratio=int(config.mlp_ratio),
                    **cfg,
                ),
                "mamba",
            )

        elif block == "retnet":
            cfg = _merge_dicts(blocks_defaults.get("retnet", {}), extra)
            if bool(cfg.get("use_moe", False)):
                cfg = dict(cfg)
                cfg["moe"] = _merge_dicts(
                    moe_cfg,
                    cfg.get("moe", {}) if isinstance(cfg.get("moe", {}), dict) else {},
                )

            rope_val = bool(cfg.pop("rope", rope_enabled))
            _pop_keys(cfg, "d_model", "n_heads", "norm", "dropout", "mlp_ratio")

            self.backbone = _BackboneAdapter(
                RetNetBlock(
                    d_model=int(config.d_model),
                    n_heads=int(config.n_heads),
                    norm=str(config.norm),
                    dropout=float(config.dropout),
                    mlp_ratio=int(config.mlp_ratio),
                    rope=rope_val,
                    **cfg,
                ),
                "retnet",
            )

        elif block == "hyena":
            cfg = _merge_dicts(blocks_defaults.get("hyena", {}), extra)

            # Propagate global MoE config into use_moe branch, mirroring the
            # mamba and retnet init paths. Without this, a hyena layer with
            # extra.use_moe=True but no embedded `moe` dict would fall back
            # to defaults and ignore e.g. top_k from routing.moe.
            if bool(cfg.get("use_moe", False)):
                cfg = dict(cfg)
                cfg["moe"] = _merge_dicts(
                    moe_cfg,
                    cfg.get("moe", {}) if isinstance(cfg.get("moe", {}), dict) else {},
                )

            _pop_keys(cfg, "d_model", "norm", "dropout", "mlp_ratio")

            self.backbone = _BackboneAdapter(
                HyenaBlock(
                    d_model=int(config.d_model),
                    norm=str(config.norm),
                    dropout=float(config.dropout),
                    mlp_ratio=int(config.mlp_ratio),
                    **cfg,
                ),
                "hyena",
            )

        else:
            raise ValueError(f"Unsupported block type: {block}")

        # Blocks like mamba/retnet/hyena already contain their own norm+MLP.
        # Only attention blocks need a separate MLP from the layer.
        self._has_layer_mlp = (block == "attn")
        self._mlp_returns_aux = False
        if self._has_layer_mlp:
            # Per-layer FFN typing emitted by the compiler (stack.pattern[i].ffn).
            # Legacy compiled models without this key keep the old swiglu default.
            ffn_spec = dict(layer_spec.get("ffn") or {})
            ffn_type_raw = str(ffn_spec.get("type", "swiglu")).lower()
            # YAML uses gated_mlp as the SwiGLU alias.
            if ffn_type_raw in ("gated_mlp",):
                ffn_type_raw = "swiglu"

            mlp_bias = bool(blocks_defaults.get("mlp", {}).get("bias", False))

            if ffn_type_raw == "moe":
                moe_config = dict(ffn_spec.get("moe") or {})
                # Allow the global routing.moe block (if present) to fill in
                # defaults for older configs that didn't emit per-layer moe.
                global_moe = dict(moe_cfg or {})
                for k, v in global_moe.items():
                    moe_config.setdefault(k, v)
                if "experts" not in moe_config or "top_k" not in moe_config:
                    raise ValueError(
                        "MoE FFN requested but per-layer moe config is missing "
                        "experts/top_k — recompile with a current EulerStack."
                    )
                self.mlp = build_mlp(
                    "moe",
                    d_model=int(config.d_model),
                    mlp_ratio=int(config.mlp_ratio),
                    dropout=float(config.dropout),
                    bias=mlp_bias,
                    moe_config=moe_config,
                )
                self._mlp_returns_aux = True
            else:
                self.mlp = build_mlp(
                    ffn_type_raw,
                    d_model=int(config.d_model),
                    mlp_ratio=int(config.mlp_ratio),
                    dropout=float(config.dropout),
                    bias=mlp_bias,
                )
        else:
            self.mlp = None

        self.drop = nn.Dropout(float(config.dropout))

        # Phase B3.3 core: Neural-ODE integration metadata. When present,
        # this layer's residual body is applied K times with numerical
        # integration (ode_euler / ode_rk4) in forward. Shared weights.
        v1_extras = layer_spec.get("_v1_extras", {}) or {}
        ode_spec = v1_extras.get("integrator")
        if ode_spec and str(ode_spec.get("method", "")).startswith("ode_"):
            self._ode_method = str(ode_spec["method"]).removeprefix("ode_")
            self._ode_steps = int(ode_spec["steps"])
        else:
            self._ode_method = None
            self._ode_steps = 0

        # Phase B4.1: Titans-style neural memory (core runtime).
        mem_spec = v1_extras.get("memory")
        if mem_spec and str(mem_spec.get("type", "")) == "neural_memory":
            from eulerstack.components.titans_memory import TitansMemoryModule
            self.titans_memory = TitansMemoryModule(
                d_model=int(config.d_model),
                hidden=int(mem_spec.get("hidden", 2048)),
                inner_lr=float(mem_spec.get("inner_lr", 1e-3)),
                update_at_inference=bool(mem_spec.get("update_at_inference", False)),
                persistence=str(mem_spec.get("persistence", "session")),
            )
        else:
            self.titans_memory = None

        # Plugin-registered mixer override (e.g. TTT from eulerstack-plugins).
        # The modeling layer already built a fallback backbone; if a plugin
        # offers a real implementation for this mixer kind, swap it in.
        plugin_mixer_kind = v1_extras.get("mixer_kind")
        if plugin_mixer_kind:
            reg = get_plugin_registry()
            if reg.has_mixer(plugin_mixer_kind):
                plugin_module = reg.build_mixer(
                    plugin_mixer_kind,
                    d_model=int(config.d_model),
                    n_heads=int(config.n_heads),
                    dropout=float(config.dropout),
                    config=v1_extras.get(plugin_mixer_kind, {}),
                )
                self.backbone = _BackboneAdapter(plugin_module, plugin_mixer_kind)

    def _compute_residual_delta(
        self,
        hidden_states: torch.Tensor,
        *,
        attention_mask: Optional[torch.Tensor],
        use_cache: bool,
        past_key_values: Optional[Any],
        rope_cos: Optional[torch.Tensor],
        rope_sin: Optional[torch.Tensor],
        position_ids: Optional[torch.LongTensor],
        output_aux: bool,
    ) -> Tuple[torch.Tensor, Optional[Any], Dict[str, Any]]:
        """Compute the full residual delta ``block(x)`` without applying ``x +``.

        For Neural-ODE integration (shared weights, K numerical steps), the
        caller composes ``x + dt * delta`` instead of the standard ``x + delta``.
        """
        aux: Dict[str, Any] = {}

        # Backbone contribution
        x_in = self.norm1(hidden_states)
        x_bb, new_past, bb_aux = self.backbone(
            x_in,
            attention_mask=attention_mask,
            use_cache=use_cache,
            past_key_values=past_key_values,
            rope_cos=rope_cos,
            rope_sin=rope_sin,
            position_ids=position_ids,
            output_aux=output_aux,
        )
        x_bb = self.drop(x_bb)
        if output_aux and isinstance(bb_aux, dict):
            aux.update(bb_aux)

        if not self._has_layer_mlp:
            return x_bb, new_past, aux

        # MLP contribution is computed from the post-backbone-residual point
        # (standard sequential layout). Delta returned is the composite
        # (backbone + mlp) — so ``x + delta`` reproduces the standard forward.
        x_after_bb = hidden_states + x_bb
        mlp_in = self.norm2(x_after_bb)
        # MoE layers return (output, aux); dense MLP returns output. We gate
        # the call on the flag set at __init__ time so this works for both.
        if self._mlp_returns_aux:
            mlp_result = self.mlp(mlp_in, output_aux=output_aux)
            if output_aux and isinstance(mlp_result, tuple) and len(mlp_result) == 2:
                x_mlp, mlp_aux = mlp_result
                # Merge MoE aux into the layer-level aux bucket. Preserve any
                # keys the backbone already set (ode/memory/etc.) by not
                # over-writing unless the MoE key is genuinely new.
                if isinstance(mlp_aux, dict):
                    for k, v in mlp_aux.items():
                        aux.setdefault(k, v)
            else:
                # output_aux False (or unexpected shape) — just the tensor
                x_mlp = mlp_result if not isinstance(mlp_result, tuple) else mlp_result[0]
        else:
            x_mlp = self.mlp(mlp_in)
        x_mlp = self.drop(x_mlp)
        delta = x_bb + x_mlp
        return delta, new_past, aux

    def _forward_ode(
        self,
        hidden_states: torch.Tensor,
        *,
        attention_mask: Optional[torch.Tensor],
        use_cache: bool,
        past_key_values: Optional[Any],
        rope_cos: Optional[torch.Tensor],
        rope_sin: Optional[torch.Tensor],
        position_ids: Optional[torch.LongTensor],
        output_aux: bool,
    ) -> Tuple[torch.Tensor, Optional[Any], Dict[str, Any]]:
        """Apply the residual body K times under ode_euler / ode_rk4."""
        dt = 1.0 / float(self._ode_steps)
        aux_final: Dict[str, Any] = {}
        x = hidden_states
        new_past: Optional[Any] = None

        if self._ode_method == "euler":
            for i in range(self._ode_steps):
                delta, new_past, aux = self._compute_residual_delta(
                    x,
                    attention_mask=attention_mask,
                    use_cache=False,
                    past_key_values=None,
                    rope_cos=rope_cos,
                    rope_sin=rope_sin,
                    position_ids=position_ids,
                    output_aux=output_aux and (i == self._ode_steps - 1),
                )
                x = x + dt * delta
                aux_final = aux
            return x, None, aux_final

        # rk4
        for i in range(self._ode_steps):
            k1, _, aux_k = self._compute_residual_delta(
                x, attention_mask=attention_mask, use_cache=False,
                past_key_values=None, rope_cos=rope_cos, rope_sin=rope_sin,
                position_ids=position_ids,
                output_aux=output_aux and (i == self._ode_steps - 1),
            )
            k2, _, _ = self._compute_residual_delta(
                x + 0.5 * dt * k1, attention_mask=attention_mask,
                use_cache=False, past_key_values=None,
                rope_cos=rope_cos, rope_sin=rope_sin,
                position_ids=position_ids, output_aux=False,
            )
            k3, _, _ = self._compute_residual_delta(
                x + 0.5 * dt * k2, attention_mask=attention_mask,
                use_cache=False, past_key_values=None,
                rope_cos=rope_cos, rope_sin=rope_sin,
                position_ids=position_ids, output_aux=False,
            )
            k4, _, _ = self._compute_residual_delta(
                x + dt * k3, attention_mask=attention_mask,
                use_cache=False, past_key_values=None,
                rope_cos=rope_cos, rope_sin=rope_sin,
                position_ids=position_ids, output_aux=False,
            )
            x = x + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
            aux_final = aux_k
        return x, None, aux_final

    def forward(
        self,
        hidden_states: torch.Tensor,
        *,
        attention_mask: Optional[torch.Tensor] = None,
        use_cache: bool = False,
        past_key_values: Optional[Any] = None,
        rope_cos: Optional[torch.Tensor] = None,
        rope_sin: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        output_aux: bool = False,
    ) -> Tuple[torch.Tensor, Optional[Any], Dict[str, Any]]:
        # Phase B3.3 core: Neural-ODE integration path (shared weights, K steps).
        if self._ode_method is not None and self._ode_steps > 0:
            hidden_states, new_past, aux = self._forward_ode(
                hidden_states,
                attention_mask=attention_mask,
                use_cache=use_cache,
                past_key_values=past_key_values,
                rope_cos=rope_cos,
                rope_sin=rope_sin,
                position_ids=position_ids,
                output_aux=output_aux,
            )
        else:
            aux = {}
            # Backbone
            residual = hidden_states
            x = self.norm1(hidden_states)

            x, new_past, bb_aux = self.backbone(
                x,
                attention_mask=attention_mask,
                use_cache=use_cache,
                past_key_values=past_key_values,
                rope_cos=rope_cos,
                rope_sin=rope_sin,
                position_ids=position_ids,
                output_aux=output_aux,
            )
            hidden_states = residual + self.drop(x)

            if output_aux and isinstance(bb_aux, dict):
                aux.update(bb_aux)

            # MLP (only for attention blocks; other blocks handle MLP internally)
            if self._has_layer_mlp:
                residual = hidden_states
                x = self.norm2(hidden_states)
                if self._mlp_returns_aux:
                    mlp_result = self.mlp(x, output_aux=output_aux)
                    if output_aux and isinstance(mlp_result, tuple) and len(mlp_result) == 2:
                        x, mlp_aux = mlp_result
                        if isinstance(mlp_aux, dict):
                            for k, v in mlp_aux.items():
                                aux.setdefault(k, v)
                    else:
                        x = mlp_result if not isinstance(mlp_result, tuple) else mlp_result[0]
                else:
                    x = self.mlp(x)
                hidden_states = residual + self.drop(x)

        # Phase B4.1: Titans memory contribution (additive, residual-form).
        if self.titans_memory is not None:
            hidden_states = self.titans_memory(hidden_states)

        return hidden_states, new_past, aux


class EulerStackModel(PreTrainedModel):
    """
    Base decoder-only model (no LM head), fully constructed from EulerStackConfig.
    """

    config_class = EulerStackConfig
    base_model_prefix = "eulerstack"
    main_input_name = "input_ids"
    supports_gradient_checkpointing = True

    def __init__(self, config: EulerStackConfig):
        super().__init__(config)
        config.validate()

        self.embed_tokens = nn.Embedding(int(config.vocab_size), int(config.d_model))

        positional = getattr(config, "positional", None) or {}
        routing = getattr(config, "routing", None) or {}
        blocks = getattr(config, "blocks", None) or {}
        stack = getattr(config, "stack", None) or {}

        if not isinstance(positional, dict):
            positional = {}
        if not isinstance(routing, dict):
            routing = {}
        if not isinstance(blocks, dict):
            blocks = {}
        if not isinstance(stack, dict):
            stack = {}

        moe_cfg = routing.get("moe", {})
        moe_cfg = moe_cfg if isinstance(moe_cfg, dict) else {}

        blocks_defaults: Dict[str, Dict[str, Any]] = {
            "attn": blocks.get("attn", {}) if isinstance(blocks.get("attn", {}), dict) else {},
            "mamba": blocks.get("mamba", {}) if isinstance(blocks.get("mamba", {}), dict) else {},
            "retnet": blocks.get("retnet", {}) if isinstance(blocks.get("retnet", {}), dict) else {},
            "hyena": blocks.get("hyena", {}) if isinstance(blocks.get("hyena", {}), dict) else {},
            "mlp": blocks.get("mlp", {}) if isinstance(blocks.get("mlp", {}), dict) else {},
        }

        self.rope_enabled = bool(positional.get("type", "none") == "rope")
        self._rope_cos: Optional[torch.Tensor]
        self._rope_sin: Optional[torch.Tensor]
        if self.rope_enabled:
            rope_theta = float(positional.get("rope_theta", 10000.0))
            scaling = positional.get("scaling", None)
            scaling_factor = 1.0
            if isinstance(scaling, dict):
                scaling_factor = float(scaling.get("factor", 1.0))

            cos, sin = build_rope_cache(
                head_dim=int(config.d_model) // int(config.n_heads),
                max_seq_len=int(config.max_seq_len),
                rope_theta=rope_theta,
                scaling_factor=scaling_factor,
                device=torch.device("cpu"),
                dtype=torch.float32,
            )
            self.register_buffer("_rope_cos_buf", cos, persistent=False)
            self.register_buffer("_rope_sin_buf", sin, persistent=False)
            self._rope_cos = self._rope_cos_buf
            self._rope_sin = self._rope_sin_buf
        else:
            self._rope_cos = None
            self._rope_sin = None

        per_layer_specs = _expand_stack_from_config(config)
        self.layers = nn.ModuleList(
            [
                EulerStackLayer(
                    config,
                    per_layer_specs[i],
                    moe_cfg=moe_cfg,
                    blocks_defaults=blocks_defaults,
                    rope_enabled=self.rope_enabled,
                )
                for i in range(int(config.n_layers))
            ]
        )
        self.final_norm = get_norm(str(config.norm), int(config.d_model))

        self.post_init()

    def get_input_embeddings(self) -> nn.Module:
        return self.embed_tokens

    def set_input_embeddings(self, value: nn.Module) -> None:
        self.embed_tokens = value



    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        use_cache: Optional[bool] = None,
        past_key_values: PastKeyValues = None,
        position_ids: Optional[torch.LongTensor] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        **kwargs: Any,
    ) -> Union[BaseModelOutputWithPast, Tuple[torch.Tensor, ...]]:
        use_cache = bool(use_cache) if use_cache is not None else bool(getattr(self.config, "use_cache", False))
        _rd = getattr(self.config, "return_dict", None)
        if _rd is None:
            _rd = getattr(self.config, "use_return_dict", True)
        return_dict = bool(return_dict) if return_dict is not None else bool(_rd)
        output_hidden_states = bool(output_hidden_states) if output_hidden_states is not None else False

        # For MoE aux aggregation:
        moe_aux_out = kwargs.pop("moe_aux_out", None)
        if moe_aux_out is not None and not isinstance(moe_aux_out, dict):
            raise ValueError("moe_aux_out must be a dict if provided")
        output_aux = moe_aux_out is not None

        if inputs_embeds is None:
            if input_ids is None:
                raise ValueError("Either input_ids or inputs_embeds must be provided.")
            hidden_states = self.embed_tokens(input_ids)
        else:
            hidden_states = inputs_embeds

        bsz, q_len, _ = hidden_states.shape

        if position_ids is None and self.rope_enabled:
            past_len = _infer_past_len(past_key_values)
            position_ids = _make_position_ids(bsz, q_len, past_len, hidden_states.device)

        rope_cos = None
        rope_sin = None
        if self.rope_enabled:
            rope_cos = self._rope_cos.to(device=hidden_states.device, dtype=hidden_states.dtype)  # type: ignore[union-attr]
            rope_sin = self._rope_sin.to(device=hidden_states.device, dtype=hidden_states.dtype)  # type: ignore[union-attr]

        all_hidden_states: Optional[Tuple[torch.Tensor, ...]] = () if output_hidden_states else None
        next_past: Optional[List[Any]] = [] if use_cache else None

        if past_key_values is None:
            past_key_values = tuple([None] * len(self.layers))

        # Prepare aux collection structures
        if output_aux:
            moe_aux_out["layers"] = {}
            aux_losses: List[torch.Tensor] = []
            router_z_losses: List[torch.Tensor] = []
            router_loads: List[torch.Tensor] = []

        for i, layer in enumerate(self.layers):
            if output_hidden_states:
                all_hidden_states = all_hidden_states + (hidden_states,)

            layer_past = past_key_values[i] if i < len(past_key_values) else None
            hidden_states, new_past, layer_aux = layer(
                hidden_states,
                attention_mask=attention_mask,
                use_cache=use_cache,
                past_key_values=layer_past,
                rope_cos=rope_cos,
                rope_sin=rope_sin,
                position_ids=position_ids,
                output_aux=output_aux,
            )
            if use_cache:
                next_past.append(new_past)

            if output_aux and isinstance(layer_aux, dict) and layer_aux:
                # Store per-layer aux with namespace
                moe_aux_out["layers"][str(i)] = layer_aux

                # Collect scalars for global aggregation
                if "aux_loss" in layer_aux:
                    aux_losses.append(layer_aux["aux_loss"])
                if "router_z_loss" in layer_aux:
                    router_z_losses.append(layer_aux["router_z_loss"])
                if "router_load" in layer_aux:
                    router_loads.append(layer_aux["router_load"])

        hidden_states = self.final_norm(hidden_states)

        if output_hidden_states:
            all_hidden_states = all_hidden_states + (hidden_states,)

        # Aggregate aux losses
        if output_aux:
            if aux_losses:
                moe_aux_out["aux_loss_total"] = torch.stack(aux_losses).sum()
            if router_z_losses:
                moe_aux_out["router_z_loss_total"] = torch.stack(router_z_losses).sum()
            if router_loads:
                # router_load is (E,) per layer; average across layers
                stacked = torch.stack(router_loads, dim=0)  # (n_layers_with_moe, E)
                moe_aux_out["router_load_mean"] = stacked.mean(dim=0)  # (E,)

        if not return_dict:
            out = (hidden_states,)
            if use_cache:
                out = out + (tuple(next_past),)
            if output_hidden_states:
                out = out + (all_hidden_states,)
            return out

        return BaseModelOutputWithPast(
            last_hidden_state=hidden_states,
            past_key_values=tuple(next_past) if use_cache else None,
            hidden_states=all_hidden_states,
            attentions=None,
        )


class EulerStackForCausalLM(PreTrainedModel, GenerationMixin):
    """
    Causal LM wrapper with tied LM head.
    """

    config_class = EulerStackConfig
    base_model_prefix = "eulerstack"
    main_input_name = "input_ids"

    _tied_weights_keys = {"lm_head.weight": "eulerstack.embed_tokens.weight"}

    def __init__(self, config: EulerStackConfig):
        super().__init__(config)
        config.validate()

        self.eulerstack = EulerStackModel(config)
        self.lm_head = nn.Linear(int(config.d_model), int(config.vocab_size), bias=False)

        if getattr(config, "tie_word_embeddings", True):
            self.tie_weights()

        self.post_init()

    def get_input_embeddings(self) -> nn.Module:
        return self.eulerstack.get_input_embeddings()

    def set_input_embeddings(self, value: nn.Module) -> None:
        self.eulerstack.set_input_embeddings(value)

    def get_output_embeddings(self) -> nn.Module:
        return self.lm_head

    def set_output_embeddings(self, new_embeddings: nn.Module) -> None:
        self.lm_head = new_embeddings  # type: ignore[assignment]

    def step_memory_at_inference(self, hidden_states: torch.Tensor) -> Dict[str, float]:
        """Phase B4.1 standardized hook: advance all Titans memory modules.

        At inference time the caller drives one forward pass, then calls
        this hook with the *last* hidden-state tensor to let every
        :class:`TitansMemoryModule` in the model take one inner SGD step
        minimizing its surprise against the current hidden state. This
        exposes the Titans test-time learning loop on the exported HF
        model without special ``generate()`` surgery — any downstream
        caller (custom ``generate`` loop, agent harness) can invoke it.

        Returns a dict mapping qualified-name → surprise-loss value so
        callers can log or early-stop on it.
        """
        from eulerstack.components.titans_memory import TitansMemoryModule

        losses: Dict[str, float] = {}
        for name, module in self.named_modules():
            if isinstance(module, TitansMemoryModule):
                val = module.update_at_inference_step(hidden_states)
                if val is not None:
                    losses[name] = val
        return losses

    def prepare_inputs_for_generation(
        self,
        input_ids: torch.LongTensor,
        past_key_values: PastKeyValues = None,
        attention_mask: Optional[torch.Tensor] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        use_cache: Optional[bool] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        if past_key_values is not None:
            input_ids = input_ids[:, -1:]

        return {
            "input_ids": input_ids,
            "past_key_values": past_key_values,
            "attention_mask": attention_mask,
            "inputs_embeds": inputs_embeds,
            "use_cache": use_cache,
        }

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.LongTensor] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        use_cache: Optional[bool] = None,
        past_key_values: PastKeyValues = None,
        position_ids: Optional[torch.LongTensor] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        output_aux: Optional[bool] = None,
        **kwargs: Any,
    ) -> Union[EulerStackCausalLMOutputWithPast, Tuple[torch.Tensor, ...]]:
        _rd = getattr(self.config, "return_dict", None)
        if _rd is None:
            _rd = getattr(self.config, "use_return_dict", True)
        return_dict = bool(return_dict) if return_dict is not None else bool(_rd)
        output_aux = bool(output_aux) if output_aux is not None else False

        moe_aux: Optional[Dict[str, Any]] = {} if output_aux else None

        outputs = self.eulerstack(
            input_ids=input_ids,
            attention_mask=attention_mask,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            past_key_values=past_key_values,
            position_ids=position_ids,
            output_hidden_states=output_hidden_states,
            return_dict=True,
            moe_aux_out=moe_aux,
        )

        hidden_states = outputs.last_hidden_state
        logits = self.lm_head(hidden_states)

        loss = None
        if labels is not None:
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()
            loss = F.cross_entropy(
                shift_logits.view(-1, shift_logits.size(-1)),
                shift_labels.view(-1),
                ignore_index=-100,
            )

        if not return_dict:
            out = (logits, outputs.past_key_values, outputs.hidden_states)
            return ((loss,) + out) if loss is not None else out

        return EulerStackCausalLMOutputWithPast(
            loss=loss,
            logits=logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=None,
            moe_aux=moe_aux if output_aux else None,
        )
