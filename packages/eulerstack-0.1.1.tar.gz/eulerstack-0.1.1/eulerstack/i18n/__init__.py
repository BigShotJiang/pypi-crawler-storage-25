# eulerstack/i18n/__init__.py
"""Internationalization (i18n) for EulerStack CLI.

Supported languages: ko (default), en, zh, ja, es.

Usage:
    from eulerstack.i18n import t, set_lang, SUPPORTED_LANGS

    set_lang("en")
    print(t("validate.ok", path="foo.yml"))  # OK: foo.yml is valid.
"""
from __future__ import annotations

from .translate import (
    t,
    set_lang,
    get_lang,
    resolve_lang,
    SUPPORTED_LANGS,
    DEFAULT_LANG,
    MissingTranslationError,
)

__all__ = [
    "t",
    "set_lang",
    "get_lang",
    "resolve_lang",
    "SUPPORTED_LANGS",
    "DEFAULT_LANG",
    "MissingTranslationError",
]
