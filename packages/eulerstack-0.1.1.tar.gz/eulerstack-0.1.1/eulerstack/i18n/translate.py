# eulerstack/i18n/translate.py
"""Translation lookup and language resolution for EulerStack CLI.

Rules (from 공통프롬프트 section 6):
  - Default language: Korean (ko)
  - Supported: ko, en, zh, ja, es
  - CLI interface names (command names, option names, exit codes) MUST NOT change
    across languages. Only human-readable text is translated.
  - Missing translations MUST raise an exception — do not silently fall back to English.
    Tests should catch missing keys immediately.
"""
from __future__ import annotations

import os
from typing import Any, Dict

from .locales import ko, en, zh, ja, es


DEFAULT_LANG = "ko"
SUPPORTED_LANGS = ("ko", "en", "zh", "ja", "es")

_CATALOGS: Dict[str, Dict[str, str]] = {
    "ko": ko.MESSAGES,
    "en": en.MESSAGES,
    "zh": zh.MESSAGES,
    "ja": ja.MESSAGES,
    "es": es.MESSAGES,
}


class MissingTranslationError(KeyError):
    """Raised when a message key is missing from a catalog."""


# ── Process-level current language ──
_current_lang = DEFAULT_LANG


def set_lang(lang: str) -> None:
    """Set the current language for subsequent t() calls."""
    global _current_lang
    _current_lang = resolve_lang(lang)


def get_lang() -> str:
    """Return the currently active language code."""
    return _current_lang


def resolve_lang(lang: str | None) -> str:
    """Resolve a language code. Returns DEFAULT_LANG for None/empty/unknown values.

    Note: unknown values fall back to DEFAULT_LANG silently. CLI `--lang` option
    should validate the user's input against SUPPORTED_LANGS before calling here
    (Click's Choice type handles this).
    """
    if not lang:
        return DEFAULT_LANG
    lang = lang.lower().strip()
    if lang in SUPPORTED_LANGS:
        return lang
    return DEFAULT_LANG


def t(key: str, *, lang: str | None = None, **kwargs: Any) -> str:
    """Translate a message key to the target language.

    Args:
        key: Dotted message key (e.g., "validate.ok").
        lang: Language override. If None, uses the current language set by set_lang().
        **kwargs: Format values substituted into the message template.

    Raises:
        MissingTranslationError: If the key is missing from the target catalog.
    """
    target = resolve_lang(lang) if lang is not None else _current_lang
    catalog = _CATALOGS.get(target, _CATALOGS[DEFAULT_LANG])

    if key not in catalog:
        raise MissingTranslationError(
            f"Missing translation for key '{key}' in language '{target}'. "
            f"Add it to eulerstack/i18n/locales/{target}.py"
        )

    template = catalog[key]
    # Always call .format so missing {placeholders} raise — never silently leak.
    try:
        return template.format(**kwargs)
    except KeyError as e:
        raise MissingTranslationError(
            f"Missing format variable {e} for key '{key}' in language '{target}'"
        )
    except IndexError as e:
        raise MissingTranslationError(
            f"Format error for key '{key}' in language '{target}': {e}"
        )


def resolve_from_env_or_click(click_value: str | None) -> str:
    """Resolve language from click option value or EULERSTACK_LANG env var.

    Precedence: click option > env var > default.
    """
    if click_value:
        return resolve_lang(click_value)
    env = os.environ.get("EULERSTACK_LANG", "")
    return resolve_lang(env)
