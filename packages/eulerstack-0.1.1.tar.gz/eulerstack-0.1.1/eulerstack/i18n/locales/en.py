# eulerstack/i18n/locales/en.py
"""English (en) translations."""
from __future__ import annotations

MESSAGES = {
    "cli.root.help": "EulerStack: YAML-driven modular LLM assembler.",
    "cli.spec.help": "YAML spec operations: validate, explain, compile, schema.",
    "cli.presets.help": "Manage preset model configurations.",
    "cli.option.lang.help": "Output language (ko/en/zh/ja/es). Default: ko.",

    "validate.help": "Validate a YAML spec file against the schema.",
    "validate.opt.preset.help": "YAML spec file path.",
    "validate.opt.report.help": "Show detailed validation report with realism checks.",
    "validate.opt.validate_only.help": "Only validate; do not proceed further. (Same as default, included for eulerwa CLI consistency.)",
    "validate.ok": "OK: {path} is valid.",

    "explain.help": "Show a human-readable summary of a YAML spec.",
    "explain.opt.preset.help": "YAML spec file path.",
    "explain.model": "Model: {name}",
    "explain.family_hint": "Family hint: {hint}",
    "explain.dimensions": "Dimensions: d_model={d_model}, n_heads={n_heads}, n_kv_heads={n_kv_heads}",
    "explain.vocab_seq": "Vocab: {vocab}, Max seq: {max_seq_len}, dtype: {dtype}",
    "explain.positional": "Positional: {positional}",
    "explain.layer_templates": "Layer Templates:",
    # Template body labels — mixer/ffn/norm/residual/moe stay in English
    # across every locale as domain terms; the CLI still routes these
    # through i18n so the output pipeline stays uniform.
    "explain.template.mixer": "    mixer: {type} {config}",
    "explain.template.ffn": "    ffn: {type}{extra}",
    "explain.template.ffn_moe_extra": " (moe: {experts} experts)",
    "explain.template.norm": "    norm: {type}/{position}",
    "explain.template.residual": "    residual: {type}",
    "explain.layer_schedule": "Layer Schedule:",
    "explain.total_layers": "Total layers: {total}",
    "explain.head": "Head: {head_type}, tie_weights={tie}",
    "explain.compile_target": "Compile target: {target}",
    "explain.estimated_params": "Estimated params: {pretty} ({exact:,})",
    "explain.target_params": "Target params: {pretty} (ratio: {ratio:.1%})",

    "compile.help": "Compile YAML spec -> IR -> runtime config (JSON) or HF model directory.",
    "compile.opt.preset.help": "YAML spec file path.",
    "compile.opt.output.help": "Output JSON file path (runtime config).",
    "compile.opt.output_dir.help": "Output directory for HF model (config.json + model.safetensors). "
                                    "Creates a directory loadable by AutoModelForCausalLM.from_pretrained().",
    "compile.opt.validate_only.help": "Only validate; do not compile.",
    "compile.opt.print_config.help": "Print compiled config to stdout.",
    "compile.opt.dry_run.help": "Alias for --print-config.",
    "compile.validate_only_ok": "OK: {path} is valid (validate-only mode).",
    "compile.hf_saved.header": "HF model saved to: {output_dir}",
    "compile.hf_saved.model_type": "  model_type: eulerstack",
    "compile.hf_saved.params": "  params: {pretty} ({exact:,})",
    "compile.hf_saved.layers": "  layers: {n_layers}",
    "compile.hf_saved.load_hint": "  Load with: AutoModelForCausalLM.from_pretrained('{output_dir}', trust_remote_code=True)",
    "compile.hf_saved.tokenizer": "  tokenizer saved: {pretrained} (AutoTokenizer.from_pretrained compatible)",
    "compile.hf_saved.tokenizer_warn": "WARNING: could not save tokenizer — add it manually ({detail})",
    "compile.json_written": "Compiled config written to: {output}",

    "schema.help": "Show YAML schema summary.",
    "schema.header": "EulerStack YAML Schema Summary",
    "schema.top_level": "Top-level keys (all strictly checked):",
    "schema.see_spec": "See: docs/architectures/yaml_v1_spec.md for full specification.",

    "presets.list.help": "List available presets with parameter estimates.",
    "presets.show.help": "Show detailed information about a preset.",
    "presets.list.header.preset": "Preset",
    "presets.list.header.layers": "Layers",
    "presets.list.header.params": "Est. Params",
    "presets.list.header.target": "Target",
    "presets.list.header.ratio": "Ratio",
    "presets.list.empty": "No presets found.",
    "presets.list.no_dir": "No presets directory found.",
    "presets.show.header": "Preset: {name}",
    "presets.list.per_preset_error": "{name:<35s} ERROR: {err}",
    "presets.show.file_label": "File: {path}",

    # ── validation report (generate_report().format_text()) ──
    "report.header": "EulerStack Validation Report",
    "report.schema_ok": "Schema: OK",
    "report.schema_fail": "Schema: FAIL — {error}",
    "report.estimated_params": "Estimated params: {pretty} ({exact:,})",
    "report.total_layers": "Total layers: {total}",
    "report.target_params": "Target params: {pretty}",
    "report.errors_label": "ERRORS ({n}):",
    "report.warnings_label": "WARNINGS ({n}):",
    "report.info_label": "INFO:",
    "report.result_fail": "Result: FAIL ({errors} errors, {warnings} warnings)",
    "report.result_warn": "Result: WARN ({errors} errors, {warnings} warnings)",
    "report.result_ok": "Result: OK ({errors} errors, {warnings} warnings)",

    "error.category.validation": "ValidationError",
    "error.category.compatibility": "CompatibilityError",
    "error.category.normalization": "NormalizationError",
    "error.category.compile": "CompileError",

    "error.file_not_found.msg": "file not found: {path}",
    "error.file_not_found.fix": "Check the file path",
    "error.yaml_parse.msg": "YAML parse error: {detail}",
    "error.yaml_parse.fix": "Fix YAML syntax",
    "error.root_mapping.msg": "root must be a mapping",
    "error.root_mapping.fix": "Ensure YAML root is a dict",
    "error.preset_not_found.msg": "preset not found: {name}",
    "error.preset_not_found.fix": "Use 'eulerstack presets list' to see available presets",
    "error.preset_dir_not_found.msg": "preset directory not found (searched EULERSTACK_PRESETS_DIR, ./configs/presets/, and the package-relative fallback)",
    "error.preset_dir_not_found.fix": "Copy configs/ from the release tarball into the current directory, or set EULERSTACK_PRESETS_DIR to the directory containing your preset YAMLs",
    "error.hf_build_failed.msg": "failed to build HF model: {detail}",
    "error.hf_build_failed.fix": "Check YAML spec and ensure all block types are supported",
    "error.see_spec_doc": "docs/tutorials/en/03_spec_reference.md",
    "error.see_preset_tutorial": "docs/tutorials/en/02_use_presets.md",

    # ── schema helper error messages (spec/schema.py) ──
    "error.schema.expected_mapping.msg": "{path}: expected a mapping, got {type}",
    "error.schema.expected_mapping.fix": "Ensure {path} is a YAML mapping/dict",
    "error.schema.unknown_key.msg": "{path}: unknown key(s): {keys}",
    "error.schema.unknown_key.fix": "Remove or fix: {keys}. Allowed: {allowed}",
    "error.schema.missing_field.msg": "{path}: missing required field '{field}'",
    "error.schema.missing_field.fix": "Add '{field}' to {path}",
    "error.schema.invalid_enum.msg": "{path}: invalid value '{value}'",
    "error.schema.invalid_enum.fix": "Use one of: {allowed}",
    "error.schema.expected_pos_int.msg": "{path}: must be a positive integer, got {value!r}",
    "error.schema.expected_pos_int.fix": "Set {path} to a positive integer",
    "error.schema.must_be_positive.msg": "{path}: must be positive, got {value}",

    # ── report.py — normalization failure / reserved-namespace warnings ──
    "report.normalization_failed": "Normalization failed: {detail}",
    "report.reserved_namespace_warning":
        "{path}.{reserved_key}: reserved-namespace key accepted without a core "
        "implementation — a plugin must register this key to change behaviour",
}
