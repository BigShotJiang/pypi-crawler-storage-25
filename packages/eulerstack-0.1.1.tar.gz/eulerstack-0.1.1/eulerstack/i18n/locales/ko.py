# eulerstack/i18n/locales/ko.py
"""Korean (ko) translations — DEFAULT language."""
from __future__ import annotations

MESSAGES = {
    # ── CLI: group descriptions ──
    "cli.root.help": "EulerStack: YAML 기반 모듈형 LLM 어셈블러.",
    "cli.spec.help": "YAML 스펙 작업: validate, explain, compile, schema.",
    "cli.presets.help": "프리셋 모델 설정 관리.",
    "cli.option.lang.help": "출력 언어 선택 (ko/en/zh/ja/es). 기본값: ko.",

    # ── validate ──
    "validate.help": "YAML 스펙 파일을 스키마 기준으로 검증합니다.",
    "validate.opt.preset.help": "YAML 스펙 파일 경로.",
    "validate.opt.report.help": "실사용성 체크를 포함한 상세 검증 리포트 출력.",
    "validate.opt.validate_only.help": "검증만 수행하고 종료. (eulerwa CLI 공통 플래그와 일관성 유지용)",
    "validate.ok": "OK: {path} 은(는) 유효한 스펙입니다.",

    # ── explain ──
    "explain.help": "YAML 스펙의 정규화된 구조를 사람이 읽기 쉬운 형태로 출력합니다.",
    "explain.opt.preset.help": "YAML 스펙 파일 경로.",
    "explain.model": "모델: {name}",
    "explain.family_hint": "Family 힌트: {hint}",
    "explain.dimensions": "차원: d_model={d_model}, n_heads={n_heads}, n_kv_heads={n_kv_heads}",
    "explain.vocab_seq": "Vocab: {vocab}, 최대 길이: {max_seq_len}, dtype: {dtype}",
    "explain.positional": "위치 인코딩: {positional}",
    "explain.layer_templates": "레이어 템플릿:",
    # Template body labels — mixer/ffn/norm/residual/moe 는 기술 용어로 영문 유지
    # (공통프롬프트 §2 스타일 규칙) 하지만 출력 생성은 i18n 경로로 일원화.
    "explain.template.mixer": "    mixer: {type} {config}",
    "explain.template.ffn": "    ffn: {type}{extra}",
    "explain.template.ffn_moe_extra": " (moe: {experts} experts)",
    "explain.template.norm": "    norm: {type}/{position}",
    "explain.template.residual": "    residual: {type}",
    "explain.layer_schedule": "레이어 스케줄:",
    "explain.total_layers": "총 레이어 수: {total}",
    "explain.head": "Head: {head_type}, tie_weights={tie}",
    "explain.compile_target": "컴파일 타겟: {target}",
    "explain.estimated_params": "추정 파라미터: {pretty} ({exact:,})",
    "explain.target_params": "목표 파라미터: {pretty} (비율: {ratio:.1%})",

    # ── compile ──
    "compile.help": "YAML 스펙 -> IR -> 런타임 config (JSON) 또는 HF 모델 디렉토리로 컴파일합니다.",
    "compile.opt.preset.help": "YAML 스펙 파일 경로.",
    "compile.opt.output.help": "출력 JSON 파일 경로 (런타임 config).",
    "compile.opt.output_dir.help": "HF 모델 디렉토리 출력 경로 (config.json + model.safetensors). "
                                    "AutoModelForCausalLM.from_pretrained() 로 로드 가능한 디렉토리를 생성합니다.",
    "compile.opt.validate_only.help": "검증만 수행하고 컴파일하지 않습니다.",
    "compile.opt.print_config.help": "컴파일된 config 를 stdout 에 출력합니다.",
    "compile.opt.dry_run.help": "--print-config 의 별칭.",
    "compile.validate_only_ok": "OK: {path} 은(는) 유효한 스펙입니다 (validate-only 모드).",
    "compile.hf_saved.header": "HF 모델 저장 완료: {output_dir}",
    "compile.hf_saved.model_type": "  model_type: eulerstack",
    "compile.hf_saved.params": "  파라미터: {pretty} ({exact:,})",
    "compile.hf_saved.layers": "  레이어: {n_layers}",
    "compile.hf_saved.load_hint": "  로드 방법: AutoModelForCausalLM.from_pretrained('{output_dir}', trust_remote_code=True)",
    "compile.hf_saved.tokenizer": "  토크나이저 저장 완료: {pretrained} (AutoTokenizer.from_pretrained 호환)",
    "compile.hf_saved.tokenizer_warn": "경고: 토크나이저 저장 실패 — 수동으로 추가해야 합니다 ({detail})",
    "compile.json_written": "컴파일된 config 저장 완료: {output}",

    # ── schema ──
    "schema.help": "YAML 스키마 요약을 출력합니다.",
    "schema.header": "EulerStack YAML 스키마 요약",
    "schema.top_level": "최상위 키 (모두 엄격 검사):",
    "schema.see_spec": "전체 스펙은 다음을 참조하세요: docs/architectures/yaml_v1_spec.md",

    # ── presets ──
    "presets.list.help": "사용 가능한 프리셋을 파라미터 추정치와 함께 나열합니다.",
    "presets.show.help": "특정 프리셋의 상세 정보를 출력합니다.",
    "presets.list.header.preset": "프리셋",
    "presets.list.header.layers": "레이어",
    "presets.list.header.params": "추정파라미터",
    "presets.list.header.target": "목표",
    "presets.list.header.ratio": "비율",
    "presets.list.empty": "프리셋을 찾을 수 없습니다.",
    "presets.list.no_dir": "presets 디렉토리가 없습니다.",
    "presets.show.header": "프리셋: {name}",
    "presets.list.per_preset_error": "{name:<35s} 오류: {err}",
    "presets.show.file_label": "파일: {path}",

    # ── validation report (generate_report().format_text()) ──
    "report.header": "EulerStack 검증 리포트",
    "report.schema_ok": "Schema: OK",
    "report.schema_fail": "Schema: 실패 — {error}",
    "report.estimated_params": "추정 파라미터: {pretty} ({exact:,})",
    "report.total_layers": "총 레이어 수: {total}",
    "report.target_params": "목표 파라미터: {pretty}",
    "report.errors_label": "오류 ({n}):",
    "report.warnings_label": "경고 ({n}):",
    "report.info_label": "정보:",
    "report.result_fail": "결과: 실패 ({errors} 오류, {warnings} 경고)",
    "report.result_warn": "결과: 경고 ({errors} 오류, {warnings} 경고)",
    "report.result_ok": "결과: 정상 ({errors} 오류, {warnings} 경고)",

    # ── error categories (first line of 3-line format) ──
    "error.category.validation": "ValidationError",
    "error.category.compatibility": "CompatibilityError",
    "error.category.normalization": "NormalizationError",
    "error.category.compile": "CompileError",

    # ── common error templates (3-line format body) ──
    "error.file_not_found.msg": "파일을 찾을 수 없습니다: {path}",
    "error.file_not_found.fix": "파일 경로를 확인하세요",
    "error.yaml_parse.msg": "YAML 파싱 오류: {detail}",
    "error.yaml_parse.fix": "YAML 문법을 수정하세요",
    "error.root_mapping.msg": "루트는 매핑(dict) 이어야 합니다",
    "error.root_mapping.fix": "YAML 루트가 dict 인지 확인하세요",
    "error.preset_not_found.msg": "프리셋을 찾을 수 없습니다: {name}",
    "error.preset_not_found.fix": "사용 가능한 프리셋 목록은 'eulerstack presets list' 로 확인하세요",
    "error.preset_dir_not_found.msg": "프리셋 디렉토리를 찾을 수 없습니다 (EULERSTACK_PRESETS_DIR, ./configs/presets/, 패키지 내부 순으로 탐색)",
    "error.preset_dir_not_found.fix": "릴리즈 tarball 의 configs/ 를 현재 디렉토리로 복사하거나, EULERSTACK_PRESETS_DIR 환경변수를 설정하세요",
    "error.hf_build_failed.msg": "HF 모델 빌드 실패: {detail}",
    "error.hf_build_failed.fix": "YAML 스펙을 확인하고 모든 블록 타입이 지원되는지 점검하세요",
    "error.see_spec_doc": "docs/tutorials/ko/03_spec_reference.md",
    "error.see_preset_tutorial": "docs/tutorials/ko/02_use_presets.md",

    # ── schema helper error messages (spec/schema.py) ──
    "error.schema.expected_mapping.msg": "{path}: 매핑(dict)이 필요하지만 {type} 을(를) 받았습니다",
    "error.schema.expected_mapping.fix": "{path} 이(가) YAML 매핑(dict)인지 확인하세요",
    "error.schema.unknown_key.msg": "{path}: 알 수 없는 키: {keys}",
    "error.schema.unknown_key.fix": "{keys} 을(를) 제거하거나 수정하세요. 허용되는 키: {allowed}",
    "error.schema.missing_field.msg": "{path}: 필수 필드 '{field}' 누락",
    "error.schema.missing_field.fix": "'{field}' 를 {path} 에 추가하세요",
    "error.schema.invalid_enum.msg": "{path}: 허용되지 않는 값 '{value}'",
    "error.schema.invalid_enum.fix": "다음 중 하나를 사용하세요: {allowed}",
    "error.schema.expected_pos_int.msg": "{path}: 양의 정수가 필요하지만 {value!r} 을(를) 받았습니다",
    "error.schema.expected_pos_int.fix": "{path} 에 양의 정수를 지정하세요",
    "error.schema.must_be_positive.msg": "{path}: 양수여야 하지만 {value} 을(를) 받았습니다",

    # ── report.py — 정규화 실패 / reserved-namespace 경고 ──
    "report.normalization_failed": "정규화 실패: {detail}",
    "report.reserved_namespace_warning":
        "{path}.{reserved_key}: reserved 네임스페이스 키가 core 구현 없이 수락됐습니다 — "
        "동작을 바꾸려면 플러그인이 이 키를 등록해야 합니다",
}
