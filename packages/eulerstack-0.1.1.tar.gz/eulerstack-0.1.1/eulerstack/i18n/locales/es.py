# eulerstack/i18n/locales/es.py
"""Spanish (es) translations."""
from __future__ import annotations

MESSAGES = {
    "cli.root.help": "EulerStack: ensamblador modular de LLM basado en YAML.",
    "cli.spec.help": "Operaciones sobre spec YAML: validate, explain, compile, schema.",
    "cli.presets.help": "Gestionar configuraciones de modelos preestablecidas.",
    "cli.option.lang.help": "Idioma de salida (ko/en/zh/ja/es). Predeterminado: ko.",

    "validate.help": "Valida un archivo de spec YAML contra el esquema.",
    "validate.opt.preset.help": "Ruta al archivo de spec YAML.",
    "validate.opt.report.help": "Mostrar un informe detallado con comprobaciones de realismo.",
    "validate.opt.validate_only.help": "Solo validar; no continuar. (Igual que el comportamiento por defecto, incluido por coherencia con la CLI eulerwa.)",
    "validate.ok": "OK: {path} es una spec válida.",

    "explain.help": "Muestra un resumen legible de una spec YAML.",
    "explain.opt.preset.help": "Ruta al archivo de spec YAML.",
    "explain.model": "Modelo: {name}",
    "explain.family_hint": "Pista de familia: {hint}",
    "explain.dimensions": "Dimensiones: d_model={d_model}, n_heads={n_heads}, n_kv_heads={n_kv_heads}",
    "explain.vocab_seq": "Vocab: {vocab}, Máx. secuencia: {max_seq_len}, dtype: {dtype}",
    "explain.positional": "Posicional: {positional}",
    "explain.layer_templates": "Plantillas de capa:",
    # mixer/ffn/norm/residual/moe son términos de dominio y se mantienen en
    # inglés en todos los idiomas; la salida sigue pasando por i18n para
    # unificar el canal.
    "explain.template.mixer": "    mixer: {type} {config}",
    "explain.template.ffn": "    ffn: {type}{extra}",
    "explain.template.ffn_moe_extra": " (moe: {experts} experts)",
    "explain.template.norm": "    norm: {type}/{position}",
    "explain.template.residual": "    residual: {type}",
    "explain.layer_schedule": "Programación de capas:",
    "explain.total_layers": "Total de capas: {total}",
    "explain.head": "Head: {head_type}, tie_weights={tie}",
    "explain.compile_target": "Destino de compilación: {target}",
    "explain.estimated_params": "Parámetros estimados: {pretty} ({exact:,})",
    "explain.target_params": "Parámetros objetivo: {pretty} (ratio: {ratio:.1%})",

    "compile.help": "Compila spec YAML -> IR -> runtime config (JSON) o directorio de modelo HF.",
    "compile.opt.preset.help": "Ruta al archivo de spec YAML.",
    "compile.opt.output.help": "Ruta del archivo JSON de salida (runtime config).",
    "compile.opt.output_dir.help": "Directorio de salida del modelo HF (config.json + model.safetensors). "
                                    "Crea un directorio cargable con AutoModelForCausalLM.from_pretrained().",
    "compile.opt.validate_only.help": "Solo validar; no compilar.",
    "compile.opt.print_config.help": "Imprimir la config compilada en stdout.",
    "compile.opt.dry_run.help": "Alias de --print-config.",
    "compile.validate_only_ok": "OK: {path} es una spec válida (modo validate-only).",
    "compile.hf_saved.header": "Modelo HF guardado en: {output_dir}",
    "compile.hf_saved.model_type": "  model_type: eulerstack",
    "compile.hf_saved.params": "  params: {pretty} ({exact:,})",
    "compile.hf_saved.layers": "  capas: {n_layers}",
    "compile.hf_saved.load_hint": "  Cargar con: AutoModelForCausalLM.from_pretrained('{output_dir}', trust_remote_code=True)",
    "compile.hf_saved.tokenizer": "  tokenizer guardado: {pretrained} (compatible con AutoTokenizer.from_pretrained)",
    "compile.hf_saved.tokenizer_warn": "ADVERTENCIA: no se pudo guardar el tokenizer — añádelo manualmente ({detail})",
    "compile.json_written": "Config compilada escrita en: {output}",

    "schema.help": "Mostrar resumen del esquema YAML.",
    "schema.header": "Resumen del esquema YAML de EulerStack",
    "schema.top_level": "Claves de nivel superior (todas estrictamente comprobadas):",
    "schema.see_spec": "Spec completa: docs/architectures/yaml_v1_spec.md",

    "presets.list.help": "Lista los presets disponibles con estimaciones de parámetros.",
    "presets.show.help": "Mostrar información detallada de un preset.",
    "presets.list.header.preset": "Preset",
    "presets.list.header.layers": "Capas",
    "presets.list.header.params": "Params Est.",
    "presets.list.header.target": "Objetivo",
    "presets.list.header.ratio": "Ratio",
    "presets.list.empty": "No se encontraron presets.",
    "presets.list.no_dir": "No se encontró el directorio de presets.",
    "presets.show.header": "Preset: {name}",
    "presets.list.per_preset_error": "{name:<35s} ERROR: {err}",
    "presets.show.file_label": "Archivo: {path}",

    # ── validation report (generate_report().format_text()) ──
    "report.header": "Informe de validación EulerStack",
    "report.schema_ok": "Schema: OK",
    "report.schema_fail": "Schema: FALLO — {error}",
    "report.estimated_params": "Parámetros estimados: {pretty} ({exact:,})",
    "report.total_layers": "Total de capas: {total}",
    "report.target_params": "Parámetros objetivo: {pretty}",
    "report.errors_label": "ERRORES ({n}):",
    "report.warnings_label": "ADVERTENCIAS ({n}):",
    "report.info_label": "INFO:",
    "report.result_fail": "Resultado: FALLO ({errors} errores, {warnings} advertencias)",
    "report.result_warn": "Resultado: ADVERTENCIA ({errors} errores, {warnings} advertencias)",
    "report.result_ok": "Resultado: OK ({errors} errores, {warnings} advertencias)",

    "error.category.validation": "ValidationError",
    "error.category.compatibility": "CompatibilityError",
    "error.category.normalization": "NormalizationError",
    "error.category.compile": "CompileError",

    "error.file_not_found.msg": "archivo no encontrado: {path}",
    "error.file_not_found.fix": "Verifica la ruta del archivo",
    "error.yaml_parse.msg": "error al parsear YAML: {detail}",
    "error.yaml_parse.fix": "Corrige la sintaxis YAML",
    "error.root_mapping.msg": "la raíz debe ser un mapping",
    "error.root_mapping.fix": "Asegúrate de que la raíz del YAML sea un dict",
    "error.preset_not_found.msg": "preset no encontrado: {name}",
    "error.preset_not_found.fix": "Usa 'eulerstack presets list' para ver los presets disponibles",
    "error.preset_dir_not_found.msg": "directorio de presets no encontrado (se buscó en EULERSTACK_PRESETS_DIR, ./configs/presets/ y la ruta de respaldo del paquete)",
    "error.preset_dir_not_found.fix": "Copia configs/ del tarball de la release al directorio actual, o define EULERSTACK_PRESETS_DIR apuntando al directorio con los YAML de presets",
    "error.hf_build_failed.msg": "falló la construcción del modelo HF: {detail}",
    "error.hf_build_failed.fix": "Revisa la spec YAML y comprueba que todos los tipos de block estén soportados",
    "error.see_spec_doc": "docs/tutorials/en/03_spec_reference.md",
    "error.see_preset_tutorial": "docs/tutorials/en/02_use_presets.md",

    # ── schema helper error messages (spec/schema.py) ──
    "error.schema.expected_mapping.msg": "{path}: se esperaba un mapping, se recibió {type}",
    "error.schema.expected_mapping.fix": "Asegúrate de que {path} sea un mapping/dict YAML",
    "error.schema.unknown_key.msg": "{path}: clave(s) desconocida(s): {keys}",
    "error.schema.unknown_key.fix": "Elimina o corrige: {keys}. Permitidas: {allowed}",
    "error.schema.missing_field.msg": "{path}: falta el campo requerido '{field}'",
    "error.schema.missing_field.fix": "Añade '{field}' a {path}",
    "error.schema.invalid_enum.msg": "{path}: valor inválido '{value}'",
    "error.schema.invalid_enum.fix": "Usa uno de: {allowed}",
    "error.schema.expected_pos_int.msg": "{path}: debe ser un entero positivo, se recibió {value!r}",
    "error.schema.expected_pos_int.fix": "Establece {path} como un entero positivo",
    "error.schema.must_be_positive.msg": "{path}: debe ser positivo, se recibió {value}",

    # ── report.py — fallo de normalización / avisos de reserved-namespace ──
    "report.normalization_failed": "Normalización fallida: {detail}",
    "report.reserved_namespace_warning":
        "{path}.{reserved_key}: clave de espacio reservado aceptada sin implementación "
        "en core — un plugin debe registrar esta clave para cambiar el comportamiento",
}
