# eulerstack/compiler/compile.py
"""IR → runtime config / HF model compiler."""
from __future__ import annotations

from typing import Any, Dict, Optional

import torch

from eulerstack.ir.types import ModelIR
from eulerstack.spec.errors import CompileError
from .targets.huggingface import compile_to_hf


def compile_ir(ir: ModelIR, *, target: str = "huggingface") -> Dict[str, Any]:
    """
    Compile ModelIR to runtime config dict.

    Returns a dict with at least {"config": {...}, "target": str}.
    """
    if target == "huggingface":
        return compile_to_hf(ir)
    else:
        raise CompileError(
            f"Unsupported compile target: '{target}'",
            fix="Use 'huggingface' as compile_target",
        )


def compile_to_hf_config(ir: ModelIR):
    """Compile ModelIR → EulerStackConfig (HF PreTrainedConfig).

    This produces a config object that can be saved via config.save_pretrained()
    and loaded back via AutoConfig.from_pretrained().
    """
    from eulerstack.hf.configuration_eulerstack import EulerStackConfig
    from eulerstack.hf.auto_register import register_eulerstack_auto_classes

    register_eulerstack_auto_classes()

    result = compile_to_hf(ir)
    cfg_dict = result["config"]

    return EulerStackConfig(**cfg_dict)


def compile_to_hf_model(ir: ModelIR, *, seed: int = 42):
    """Compile ModelIR → EulerStackForCausalLM (HF PreTrainedModel).

    The resulting model can be:
      - model.save_pretrained(path)  → creates config.json + model.safetensors
      - AutoModelForCausalLM.from_pretrained(path) → loads it back

    This is the key bridge from YAML spec to a trainable HF model.
    """
    from eulerstack.hf.modeling_eulerstack import EulerStackForCausalLM
    from eulerstack.hf.auto_register import register_eulerstack_auto_classes

    register_eulerstack_auto_classes()

    cfg = compile_to_hf_config(ir)
    torch.manual_seed(seed)
    model = EulerStackForCausalLM(cfg)
    return model
