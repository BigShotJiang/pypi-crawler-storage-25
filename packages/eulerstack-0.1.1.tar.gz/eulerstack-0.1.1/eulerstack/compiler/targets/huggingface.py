# eulerstack/compiler/targets/huggingface.py
"""IR → HuggingFace-compatible runtime config."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from eulerstack.ir.types import ModelIR, LayerTemplateIR, FfnIR, MoeIR


# Core v1 mixer → modeling block name.
# Phase C: new v1 mixer types are mapped to a runtime-compatible fallback so
# save/load works today; the original mixer kind is preserved in
# `_v1_extras.mixer_kind` for the runtime to honour once implemented.
_MIXER_TO_BLOCK = {
    "attention": "attn",
    "mamba": "mamba",
    "retnet": "retnet",
    "hyena": "hyena",
    # ↓ fallback mappings for schema-complete but runtime-pending mixers
    "branched": "attn",       # first-branch fallback decided in _v1_extras
    "ttt_layer": "mamba",     # TTT has persistent state like Mamba
}


def _build_stack_config(ir: ModelIR) -> Dict[str, Any]:
    """Build HF-modeling-compatible stack config from expanded layers.

    Phase C: new v1 mixers (branched, ttt_layer) are mapped to a fallback
    block (`attn` / `mamba` respectively) so save/load works today. The
    original mixer kind and full config are preserved in `_v1_extras` for
    future runtime support.
    """
    pattern: List[Dict[str, Any]] = []

    for layer in ir.expanded_layers:
        mixer_kind = layer.mixer.type
        block_name = _MIXER_TO_BLOCK.get(mixer_kind, mixer_kind)
        entry: Dict[str, Any] = {"block": block_name, "repeat": 1}

        if mixer_kind == "attention":
            attn_cfg = dict(layer.mixer.config)
            if attn_cfg:
                # Strip `latent_dim` from the attn config the base modeling
                # sees (it'd reject the unknown kwarg); preserve it in extras.
                latent_dim = attn_cfg.pop("latent_dim", None)
                entry["attn"] = attn_cfg
                if latent_dim is not None:
                    entry["_v1_extras"] = {"attention_latent_dim": int(latent_dim)}
        elif mixer_kind in ("mamba", "retnet", "hyena"):
            extra = dict(layer.mixer.config)
            # When a non-attention template declares ffn.type=moe, the block's
            # internal MLP slot should swap to a MoE FFN. We translate that to
            # the block's init-time kwargs here (use_moe + moe dict) so
            # MambaBlock / RetNetBlock / HyenaBlock can pick it up in the
            # modeling template. Without this line, ffn.type=moe round-trips
            # into config.json but never reaches the nn.Module tree.
            if layer.ffn.type == "moe" and layer.ffn.moe is not None:
                extra["use_moe"] = True
                extra["moe"] = {
                    "experts": layer.ffn.moe.experts,
                    "top_k": layer.ffn.moe.top_k,
                    "router": layer.ffn.moe.router,
                    "z_loss": layer.ffn.moe.z_loss,
                    "capacity_factor": layer.ffn.moe.capacity_factor,
                }
            entry["extra"] = extra
        elif mixer_kind == "branched":
            # Use first branch's sub-mixer as fallback runtime.
            branches = layer.mixer.config.get("branches") or {}
            extras: Dict[str, Any] = {"mixer_kind": "branched",
                                      "branched": layer.mixer.config}
            if branches:
                first_name = next(iter(branches))
                first = branches[first_name]
                fb_type = first.get("type", "attention")
                fb_block = _MIXER_TO_BLOCK.get(fb_type, "attn")
                entry["block"] = fb_block
                extras["fallback_branch"] = first_name
                extras["fallback_type"] = fb_type
                if fb_type == "attention":
                    entry["attn"] = {k: v for k, v in first.get("config", {}).items()
                                     if k != "latent_dim"}
                else:
                    entry["extra"] = dict(first.get("config", {}))
            entry["_v1_extras"] = extras
        elif mixer_kind == "ttt_layer":
            entry["extra"] = {}          # run as mamba fallback
            entry["_v1_extras"] = {"mixer_kind": "ttt_layer",
                                   "ttt": dict(layer.mixer.config)}

        # Per-layer FFN typing — the runtime wires MoE / SwiGLU / plain MLP
        # from this block. Before this was emitted, `ffn.type: moe` round-
        # tripped only via the global `routing.moe` config and the runtime
        # silently fell back to dense SwiGLU.
        ffn_entry: Dict[str, Any] = {
            "type": layer.ffn.type,
            "activation": layer.ffn.activation,
        }
        if layer.ffn.type == "moe" and layer.ffn.moe is not None:
            ffn_entry["moe"] = {
                "experts": layer.ffn.moe.experts,
                "top_k": layer.ffn.moe.top_k,
                "router": layer.ffn.moe.router,
                "z_loss": layer.ffn.moe.z_loss,
                "capacity_factor": layer.ffn.moe.capacity_factor,
            }
        entry["ffn"] = ffn_entry

        # Phase B4 per-template extras (memory / shape_change): preserve in
        # the layer entry so the model config.json round-trips them.
        extras_bucket = entry.setdefault("_v1_extras", {})
        if layer.memory is not None:
            extras_bucket["memory"] = {
                "type": layer.memory.type,
                "update_at_inference": layer.memory.update_at_inference,
                "hidden": layer.memory.hidden,
                "inner_lr": layer.memory.inner_lr,
                "persistence": layer.memory.persistence,
            }
        if layer.shape_change is not None:
            extras_bucket["shape_change"] = {
                "d_out": layer.shape_change.d_out,
                "projection": layer.shape_change.projection,
            }
        # Phase B3.3 core: ODE integrator metadata for shared-weight
        # numerical integration in forward (ode_euler / ode_rk4).
        if layer.ode_integrator is not None:
            extras_bucket["integrator"] = {
                "method": layer.ode_integrator.integrator_type,
                "steps": layer.ode_integrator.steps,
                "output": layer.ode_integrator.output,
            }
        # Drop the bucket if it ended up empty.
        if not extras_bucket:
            entry.pop("_v1_extras", None)

        pattern.append(entry)

    return {"pattern": pattern, "repeat": 1, "tail": []}


def _build_blocks_defaults(ir: ModelIR) -> Dict[str, Dict[str, Any]]:
    """Extract block-family defaults from first occurrence of each mixer type.

    Phase C: the new v1 mixers (branched, ttt_layer) contribute NO runtime
    defaults — their config is attached per-layer via _v1_extras. We skip
    them here to avoid polluting the `blocks` section with unsupported keys.
    """
    blocks: Dict[str, Dict[str, Any]] = {}
    _runtime_mixers = {"attention", "mamba", "retnet", "hyena"}

    for layer in ir.expanded_layers:
        mt = layer.mixer.type
        if mt not in _runtime_mixers:
            continue
        if mt not in blocks:
            cfg = dict(layer.mixer.config)
            # MLA `latent_dim` isn't a runtime kwarg yet — drop from the shared
            # defaults bucket (it rides in each layer's _v1_extras).
            cfg.pop("latent_dim", None)
            if mt == "attention":
                blocks["attn"] = cfg
            else:
                blocks[mt] = cfg

    return blocks


def _build_routing(ir: ModelIR) -> Dict[str, Any]:
    """Extract MoE routing config if any layer uses MoE FFN."""
    for layer in ir.expanded_layers:
        if layer.ffn.type == "moe" and layer.ffn.moe is not None:
            moe = layer.ffn.moe
            return {
                "moe": {
                    "enabled": True,
                    "experts": moe.experts,
                    "top_k": moe.top_k,
                    "capacity_factor": moe.capacity_factor,
                    "router": {
                        "type": moe.router,
                        "z_loss": moe.z_loss,
                    },
                }
            }
    return {"moe": {"enabled": False}}


def _build_positional(ir: ModelIR) -> Dict[str, Any]:
    emb = ir.embedding
    if emb.positional == "rope":
        result: Dict[str, Any] = {
            "type": "rope",
            "rope_theta": emb.rope_theta or 10000.0,
        }
        if emb.rope_scaling:
            result["scaling"] = emb.rope_scaling
        return result
    return {"type": "none"}


def _build_memory(ir: ModelIR) -> Dict[str, Any]:
    has_kv = any(layer.state.kv_cache for layer in ir.expanded_layers)
    has_ssm = any(layer.state.ssm_state for layer in ir.expanded_layers)
    return {
        "kv_cache": {"enabled": has_kv, "policy": "paged" if has_kv else "none"},
        "ssm_state": {"enabled": has_ssm},
    }


def _build_v1_extensions(ir: ModelIR) -> Dict[str, Any]:
    """Phase C: serialize B5 execution_modes + B3 schedule-kind metadata.

    These are preserved in `config.json` so that `from_pretrained()` can
    reconstruct the full v1 spec metadata even if the runtime doesn't yet
    use the fields.
    """
    out: Dict[str, Any] = {}

    # B5 — execution_modes + transition
    if ir.execution_modes is not None:
        out["execution_modes"] = [
            {
                "name": m.name,
                "max_tokens": m.max_tokens,
                "kv_share": m.kv_share,
                "loss_weight": m.loss_weight,
                "visible_to_user": m.visible_to_user,
                "per_token_rationale": m.per_token_rationale,
            }
            for m in ir.execution_modes
        ]
    if ir.transition is not None:
        out["transition"] = {
            "type": ir.transition.type,
            "token": ir.transition.token,
        }

    # B3 — schedule-entry kinds (parallel / integrator) beyond the flat
    # expansion already captured in stack.pattern.
    schedule_kinds: List[Dict[str, Any]] = []
    for se in ir.layer_schedule:
        if se.kind == "parallel" and se.parallel is not None:
            schedule_kinds.append({
                "kind": "parallel",
                "streams": [
                    {"name": s.name, "body": [list(x) for x in s.body]}
                    for s in se.parallel.streams
                ],
                "merge": {
                    "type": se.parallel.merge_type,
                    "projection": se.parallel.merge_projection,
                    "from": se.parallel.merge_from,
                    "to": se.parallel.merge_to,
                },
            })
        elif se.kind == "integrator" and se.integrator is not None:
            schedule_kinds.append({
                "kind": "integrator",
                "integrator_type": se.integrator.integrator_type,
                "steps": se.integrator.steps,
                "body_template": se.integrator.body_template,
                "output": se.integrator.output,
            })
        elif se.kind == "plain":
            entry: Dict[str, Any] = {"kind": "plain", "template": se.template,
                                      "repeat": se.repeat}
            if se.override is not None:
                entry["override"] = {
                    "residual_scaling": se.override.residual_scaling,
                    "attention_window": se.override.attention_window,
                    "attention_attn_drop": se.override.attention_attn_drop,
                    "norm_type": se.override.norm_type,
                    "norm_position": se.override.norm_position,
                    "ffn_activation": se.override.ffn_activation,
                }
            if se.depth_gating is not None:
                entry["depth_gating"] = {
                    "enabled": se.depth_gating.enabled,
                    "capacity": se.depth_gating.capacity,
                    "router": se.depth_gating.router,
                }
            schedule_kinds.append(entry)
    if schedule_kinds:
        out["schedule_kinds"] = schedule_kinds

    return out


def compile_to_hf(ir: ModelIR) -> Dict[str, Any]:
    """Compile ModelIR to HuggingFace-compatible config dict."""
    n_layers = len(ir.expanded_layers)

    config: Dict[str, Any] = {
        "model_type": "eulerstack",
        "vocab_size": ir.model.vocab_size,
        "max_seq_len": ir.model.max_seq_len,
        "d_model": ir.model.d_model,
        "n_layers": n_layers,
        "n_heads": ir.model.n_heads,
        "mlp_ratio": ir.model.mlp_ratio,
        "norm": ir.expanded_layers[0].norm.type if ir.expanded_layers else "rmsnorm",
        "dropout": ir.training_hints.dropout,
        "use_cache": any(l.state.kv_cache or l.state.ssm_state for l in ir.expanded_layers),
        "tie_word_embeddings": ir.embedding.tie_word_embeddings,
        "torch_dtype": ir.model.dtype,
        "tokenizer": {
            "type": ir.tokenizer_contract.type,
            "pretrained": ir.tokenizer_contract.pretrained,
            "add_bos": ir.tokenizer_contract.add_bos,
            "add_eos": ir.tokenizer_contract.add_eos,
        },
        "positional": _build_positional(ir),
        "memory": _build_memory(ir),
        "routing": _build_routing(ir),
        "stack": _build_stack_config(ir),
        "blocks": _build_blocks_defaults(ir),
    }

    # Phase C: bundle v1 Phase-B extensions (execution_modes, schedule kinds)
    # into a single `v1_extensions` config block — kept separate from existing
    # sections to preserve backward-compatible config layout.
    v1_ext = _build_v1_extensions(ir)
    if v1_ext:
        config["v1_extensions"] = v1_ext

    return {
        "target": "huggingface",
        "config": config,
        "metadata": {
            "source_name": ir.model.name,
            "family_hint": ir.model.family_hint,
            "n_layers": n_layers,
            "compile_target": ir.compatibility.compile_target,
        },
    }
