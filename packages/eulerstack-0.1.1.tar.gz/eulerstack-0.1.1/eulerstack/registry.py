# eulerstack/registry.py
from __future__ import annotations

from dataclasses import dataclass
from importlib import import_module
from typing import Any, Callable, Dict, Optional, TypeVar

T = TypeVar("T")


def import_string(dotted_path: str) -> Any:
    """
    Import a dotted module path and return the attribute/class designated by the last name.
    Example: "eulerstack.blocks.attention:EulerSelfAttention" or "eulerstack.blocks.attention.EulerSelfAttention"
    """
    path = dotted_path.strip()

    if ":" in path:
        module_path, attr = path.split(":", 1)
    else:
        module_path, attr = path.rsplit(".", 1)

    module = import_module(module_path)
    return getattr(module, attr)


@dataclass
class Registry:
    """
    Simple string -> callable/class registry.

    - register(name, obj): register callable/class under name
    - get(name): retrieve registered item
    - resolve(name_or_dotted): if contains '.' or ':' and not registered, import dynamically

    This keeps the assembler flexible:
    - YAML can refer to built-ins: "attn", "mamba", ...
    - Or advanced users can point to dotted paths for custom blocks.
    """

    name: str
    _items: Dict[str, Any]

    def __init__(self, name: str):
        self.name = name
        self._items = {}

    def register(self, key: str, obj: Any, exist_ok: bool = False) -> None:
        k = str(key).strip()
        if not k:
            raise ValueError(f"[{self.name}] key must be non-empty.")
        if (k in self._items) and (not exist_ok):
            raise KeyError(f"[{self.name}] '{k}' already registered.")
        self._items[k] = obj

    def decorator(self, key: str, exist_ok: bool = False) -> Callable[[T], T]:
        def _wrap(obj: T) -> T:
            self.register(key, obj, exist_ok=exist_ok)
            return obj
        return _wrap

    def has(self, key: str) -> bool:
        return str(key).strip() in self._items

    def get(self, key: str) -> Any:
        k = str(key).strip()
        if k not in self._items:
            raise KeyError(f"[{self.name}] '{k}' is not registered.")
        return self._items[k]

    def resolve(self, key_or_dotted: str) -> Any:
        """
        Resolve either:
        - a registered name (e.g., "attn")
        - a dotted path (e.g., "mypkg.blocks.foo:FooBlock")
        """
        k = str(key_or_dotted).strip()
        if not k:
            raise ValueError(f"[{self.name}] key must be non-empty.")

        if k in self._items:
            return self._items[k]

        # Heuristic: treat strings with '.' or ':' as import paths
        if (":" in k) or ("." in k):
            return import_string(k)

        raise KeyError(f"[{self.name}] '{k}' is not registered and is not a dotted import path.")

    def keys(self):
        return sorted(self._items.keys())


# Global registries (assembler will use these)
BLOCKS = Registry("blocks")
COMPONENTS = Registry("components")
TOKENIZERS = Registry("tokenizers")
POSITIONALS = Registry("positionals")
MEMORIES = Registry("memories")
ROUTERS = Registry("routers")
