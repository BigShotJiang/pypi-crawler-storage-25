# eulerstack/training/sanity.py
"""Sanity and e2e training loops for EulerStack models."""
from __future__ import annotations

import gc
import math
from dataclasses import dataclass, field
from typing import List, Optional

import torch
import torch.nn as nn
from torch.utils.data import DataLoader


@dataclass
class SanityTrainResult:
    losses: List[float]
    initial_loss: float
    final_loss: float
    loss_decreased: bool
    steps: int

    def summary(self) -> str:
        status = "PASS" if self.loss_decreased else "FAIL"
        return (
            f"Sanity training: {status}\n"
            f"  Steps: {self.steps}\n"
            f"  Initial loss: {self.initial_loss:.4f}\n"
            f"  Final loss: {self.final_loss:.4f}\n"
            f"  Loss decreased: {self.loss_decreased}"
        )


def build_sanity_model(
    vocab_size: int,
    d_model: int,
    n_heads: int,
    n_layers: int,
    max_seq_len: int,
    dtype: torch.dtype = torch.float32,
) -> nn.Module:
    """Build a minimal transformer model for sanity training.

    Uses PyTorch's native TransformerDecoder to avoid depending on
    the full EulerStack HF model (which requires blocks/components).
    Keeps the same topology concept: embedding → N decoder layers → LM head.
    """
    class SanityLM(nn.Module):
        def __init__(self):
            super().__init__()
            self.embedding = nn.Embedding(vocab_size, d_model)
            decoder_layer = nn.TransformerDecoderLayer(
                d_model=d_model,
                nhead=n_heads,
                dim_feedforward=d_model * 4,
                batch_first=True,
                dtype=dtype,
            )
            self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=n_layers)
            self.lm_head = nn.Linear(d_model, vocab_size, bias=False, dtype=dtype)
            # Tie weights
            self.lm_head.weight = self.embedding.weight

        def forward(self, input_ids):
            x = self.embedding(input_ids)
            # Causal mask
            seq_len = x.size(1)
            causal_mask = nn.Transformer.generate_square_subsequent_mask(seq_len, device=x.device)
            # Use zeros as memory (decoder-only pattern)
            memory = torch.zeros(x.size(0), 1, d_model, device=x.device, dtype=x.dtype)
            x = self.decoder(x, memory, tgt_mask=causal_mask)
            logits = self.lm_head(x)
            return logits

    return SanityLM()


def run_sanity_training(
    model: nn.Module,
    dataset,
    *,
    batch_size: int = 4,
    lr: float = 1e-3,
    max_steps: Optional[int] = None,
    seed: int = 42,
    device: str = "cpu",
) -> SanityTrainResult:
    """Run 1 epoch of sanity training, collecting losses per step."""
    torch.manual_seed(seed)
    model = model.to(device)
    model.train()

    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=True)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()

    losses = []
    steps = 0

    for batch in dataloader:
        input_ids = batch["input_ids"].to(device)
        labels = batch["labels"].to(device)

        logits = model(input_ids)
        # Shift for causal LM: predict next token
        shift_logits = logits[:, :-1, :].contiguous()
        shift_labels = labels[:, 1:].contiguous()

        loss = loss_fn(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        losses.append(loss.item())
        steps += 1

        if max_steps is not None and steps >= max_steps:
            break

    if len(losses) == 0:
        return SanityTrainResult(
            losses=[], initial_loss=float("inf"), final_loss=float("inf"),
            loss_decreased=False, steps=0,
        )

    # Compare first quarter average to last quarter average
    n = len(losses)
    q = max(1, n // 4)
    initial_avg = sum(losses[:q]) / q
    final_avg = sum(losses[-q:]) / q

    return SanityTrainResult(
        losses=losses,
        initial_loss=initial_avg,
        final_loss=final_avg,
        loss_decreased=final_avg < initial_avg,
        steps=steps,
    )


def build_model_from_ir(ir, *, device: str = "cpu", dtype: torch.dtype = torch.float32) -> nn.Module:
    """Build a model from ModelIR on the specified device.

    Uses the IR's model identity (d_model, n_heads, n_layers, vocab_size)
    to construct a native PyTorch transformer. For e2e GPU testing this
    builds at the full IR scale.
    """
    model = build_sanity_model(
        vocab_size=ir.model.vocab_size,
        d_model=ir.model.d_model,
        n_heads=ir.model.n_heads,
        n_layers=len(ir.expanded_layers),
        max_seq_len=ir.model.max_seq_len,
        dtype=dtype,
    )
    model = model.to(device)
    return model


def run_e2e_training(
    model: nn.Module,
    dataset,
    *,
    batch_size: int = 2,
    lr: float = 3e-4,
    max_steps: int = 20,
    seed: int = 42,
    device: str = "cpu",
    use_amp: bool = False,
) -> SanityTrainResult:
    """Run e2e training with optional AMP. GPU-friendly version of run_sanity_training."""
    torch.manual_seed(seed)
    model = model.to(device)
    model.train()

    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    loss_fn = nn.CrossEntropyLoss()

    # bfloat16 doesn't need GradScaler — only use autocast
    amp_enabled = use_amp and device.startswith("cuda")

    losses: List[float] = []
    steps = 0

    for batch in dataloader:
        input_ids = batch["input_ids"].to(device)
        labels = batch["labels"].to(device)

        with torch.amp.autocast("cuda", enabled=amp_enabled, dtype=torch.bfloat16):
            logits = model(input_ids)
            shift_logits = logits[:, :-1, :].contiguous()
            shift_labels = labels[:, 1:].contiguous()
            loss = loss_fn(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        losses.append(loss.item())
        steps += 1

        if steps >= max_steps:
            break

    if not losses:
        return SanityTrainResult(
            losses=[], initial_loss=float("inf"), final_loss=float("inf"),
            loss_decreased=False, steps=0,
        )

    n = len(losses)
    q = max(1, n // 4)
    initial_avg = sum(losses[:q]) / q
    final_avg = sum(losses[-q:]) / q

    return SanityTrainResult(
        losses=losses,
        initial_loss=initial_avg,
        final_loss=final_avg,
        loss_decreased=final_avg < initial_avg,
        steps=steps,
    )


def cleanup_gpu():
    """Free GPU memory — call between tests."""
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    gc.collect()
