# eulerstack/training/arch_e2e.py
"""End-to-end pretrain trainer for arch_ preset integration tests.

This module is **integration-test only** — it is not wired into the CLI and is
not an enterprise pretrain feature. It exists to validate the end-to-end path:

    preset YAML → IR → compile_to_hf_model() → save_pretrained()
    → transformers.AutoModelForCausalLM.from_pretrained(trust_remote_code=True)
    → native transformers forward/backward loop.

If the loss decreases on dolma_10k after N steps and the saved/loaded model
accepts `input_ids=..., labels=...` and returns a `.loss` attribute, the
preset is genuinely usable as a HuggingFace model.
"""
from __future__ import annotations

import csv
import gc
import json
import logging
import os
import time
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

import torch
import yaml


@dataclass
class ArchE2EResult:
    """Summary of an arch_ e2e pretrain run."""
    preset: str
    steps: int
    max_tokens: int
    batch_size: int
    lr: float
    initial_loss: float
    final_loss: float
    min_train_loss: float
    initial_valid_loss: Optional[float]
    final_valid_loss: Optional[float]
    duration_sec: float
    num_train_chunks: int
    num_valid_chunks: int
    loss_decreased: bool = field(init=False)

    def __post_init__(self):
        # Compare first 10% window average to last 10% window average. Robust
        # against single-step noise.
        self.loss_decreased = self.final_loss < self.initial_loss


def _build_hf_model(preset_yaml_path: str, save_dir: str, device: str, dtype: torch.dtype):
    """Full HF roundtrip: compile → save_pretrained → from_pretrained."""
    from eulerstack.ir.normalizer import normalize_to_ir
    from eulerstack.compiler.compile import compile_to_hf_model
    from eulerstack.hf.auto_register import register_eulerstack_auto_classes
    from transformers import AutoModelForCausalLM

    register_eulerstack_auto_classes()

    with open(preset_yaml_path) as f:
        raw = yaml.safe_load(f)
    ir = normalize_to_ir(raw)

    # Compile to HF PreTrainedModel and save.
    torch.manual_seed(42)
    model = compile_to_hf_model(ir)
    os.makedirs(save_dir, exist_ok=True)
    model.save_pretrained(save_dir)

    # Load back via the real HF entry point — validates the roundtrip.
    try:
        loaded = AutoModelForCausalLM.from_pretrained(
            save_dir, trust_remote_code=True, dtype=dtype,
        ).to(device)
    except TypeError:
        loaded = AutoModelForCausalLM.from_pretrained(
            save_dir, trust_remote_code=True, torch_dtype=dtype,
        ).to(device)
    return loaded, ir


def _prepare_dataset(
    *, jsonl_path: str, tokenizer_name: str, max_tokens: int,
    valid_samples: int, vocab_size: int,
):
    """Tokenize dolma_10k and split into train/valid."""
    from eulerstack.data.prepare import tokenize_jsonl, TokenizedDataset

    raw = tokenize_jsonl(
        jsonl_path=jsonl_path,
        tokenizer_name=tokenizer_name,
        max_seq_len=max_tokens,
        num_rows=1000,  # keep tokenization fast; 1k rows ~ thousands of chunks
        cache_dir=os.path.join(os.path.dirname(jsonl_path), ".cache"),
    )
    all_ids = raw.input_ids  # shape (N, max_tokens)
    n = all_ids.size(0)
    valid_samples = min(valid_samples, max(1, n // 10))
    train_ids = all_ids[:-valid_samples]
    valid_ids = all_ids[-valid_samples:]
    train_ds = TokenizedDataset(train_ids, vocab_size=vocab_size)
    valid_ds = TokenizedDataset(valid_ids, vocab_size=vocab_size)
    return train_ds, valid_ds


def _evaluate(model, valid_ds, device: str, batch_size: int) -> float:
    """Mean loss over valid_ds using model's own forward(labels=...) path."""
    from torch.utils.data import DataLoader

    model.eval()
    loader = DataLoader(valid_ds, batch_size=batch_size, shuffle=False, drop_last=False)
    total_loss = 0.0
    total_batches = 0
    with torch.no_grad():
        with torch.amp.autocast("cuda", enabled=device.startswith("cuda"), dtype=torch.bfloat16):
            for batch in loader:
                ids = batch["input_ids"].to(device)
                labels = batch["labels"].to(device)
                out = model(input_ids=ids, labels=labels)
                if out.loss is None:
                    continue
                total_loss += float(out.loss.item())
                total_batches += 1
    model.train()
    if total_batches == 0:
        return float("nan")
    return total_loss / total_batches


def run_arch_pretrain(
    *,
    preset_yaml_path: str,
    preset_name: str,
    log_dir: str,
    device: str,
    steps: int,
    max_tokens: int,
    batch_size: int,
    valid_samples: int,
    log_interval: int,
    valid_interval: int,
    lr: float,
    jsonl_path: str,
    dtype: torch.dtype = torch.bfloat16,
    seed: int = 42,
) -> ArchE2EResult:
    """Run one arch_ preset through HF roundtrip + pretrain loop.

    Writes three files under `{log_dir}/{preset_name}_*`:
      - _steps.csv    : step, train_loss, grad_norm, lr
      - _valid.csv    : step, valid_loss
      - _summary.json : ArchE2EResult fields

    Returns the ArchE2EResult.
    """
    log_dir = os.path.abspath(log_dir)
    os.makedirs(log_dir, exist_ok=True)
    t0 = time.time()

    # ── 1. Build HF model via full save_pretrained / from_pretrained roundtrip ──
    logger.info("[%s] Building HF model from %s ...", preset_name, preset_yaml_path)
    save_dir = os.path.join(log_dir, f"{preset_name}_checkpoint")
    model, ir = _build_hf_model(preset_yaml_path, save_dir, device, dtype)
    n_params = sum(p.numel() for p in model.parameters())
    logger.info(
        "[%s] Model ready | params=%.2fM | d_model=%d | layers=%d | device=%s",
        preset_name, n_params / 1e6, ir.model.d_model, len(ir.expanded_layers), device,
    )

    # ── 2. Tokenize dolma and split ──
    train_ds, valid_ds = _prepare_dataset(
        jsonl_path=jsonl_path,
        tokenizer_name=ir.tokenizer_contract.pretrained,
        max_tokens=max_tokens,
        valid_samples=valid_samples,
        vocab_size=ir.model.vocab_size,
    )
    assert len(train_ds) > 0, f"Train dataset empty for {preset_name}"
    assert len(valid_ds) > 0, f"Valid dataset empty for {preset_name}"

    # ── 3. Optimizer + loop ──
    from torch.utils.data import DataLoader
    torch.manual_seed(seed)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=True)
    amp_on = device.startswith("cuda")

    steps_csv = os.path.join(log_dir, f"{preset_name}_steps.csv")
    valid_csv = os.path.join(log_dir, f"{preset_name}_valid.csv")
    f_steps = open(steps_csv, "w", newline="", encoding="utf-8")
    w_steps = csv.writer(f_steps)
    w_steps.writerow(["step", "train_loss", "grad_norm", "lr"])
    f_valid = open(valid_csv, "w", newline="", encoding="utf-8")
    w_valid = csv.writer(f_valid)
    w_valid.writerow(["step", "valid_loss"])

    model.train()
    train_losses: List[float] = []
    initial_valid_loss: Optional[float] = None
    final_valid_loss: Optional[float] = None
    step = 0
    done = False
    train_iter = iter(train_loader)

    # Baseline valid loss at step 0 (before any training)
    initial_valid_loss = _evaluate(model, valid_ds, device, batch_size)
    w_valid.writerow([0, f"{initial_valid_loss:.6f}"])
    f_valid.flush()
    logger.info(
        "[%s] step 0/%d | valid_loss=%.4f | train=%d chunks, valid=%d chunks",
        preset_name, steps, initial_valid_loss, len(train_ds), len(valid_ds),
    )

    step_t0 = time.time()

    while not done:
        try:
            batch = next(train_iter)
        except StopIteration:
            train_iter = iter(train_loader)
            batch = next(train_iter)

        step += 1
        ids = batch["input_ids"].to(device)
        labels = batch["labels"].to(device)

        with torch.amp.autocast("cuda", enabled=amp_on, dtype=torch.bfloat16):
            out = model(input_ids=ids, labels=labels)
            loss = out.loss

        optimizer.zero_grad()
        loss.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        loss_val = float(loss.item())
        train_losses.append(loss_val)

        if step % log_interval == 0 or step == 1:
            w_steps.writerow([step, f"{loss_val:.6f}", f"{float(grad_norm):.6f}", f"{lr:.6e}"])
            f_steps.flush()
            elapsed = time.time() - step_t0
            steps_per_sec = step / elapsed if elapsed > 0 else 0
            remaining = (steps - step) / steps_per_sec if steps_per_sec > 0 else 0
            logger.info(
                "[%s] step %d/%d | loss=%.4f | grad_norm=%.4f | lr=%.1e "
                "| %.2f step/s | elapsed %.0fs | ETA %.0fs",
                preset_name, step, steps, loss_val, float(grad_norm), lr,
                steps_per_sec, elapsed, remaining,
            )

        if step % valid_interval == 0:
            v = _evaluate(model, valid_ds, device, batch_size)
            w_valid.writerow([step, f"{v:.6f}"])
            f_valid.flush()
            logger.info(
                "[%s] step %d/%d | valid_loss=%.4f",
                preset_name, step, steps, v,
            )

        if step >= steps:
            done = True

    # Final valid loss (regardless of last valid_interval alignment)
    final_valid_loss = _evaluate(model, valid_ds, device, batch_size)
    w_valid.writerow([step, f"{final_valid_loss:.6f}"])
    f_valid.flush()
    f_steps.close()
    f_valid.close()

    total_elapsed = time.time() - t0

    # Robust initial/final via first/last 10% window
    window = max(1, len(train_losses) // 10)
    initial_loss = sum(train_losses[:window]) / window
    final_loss = sum(train_losses[-window:]) / window
    min_train_loss = min(train_losses) if train_losses else float("inf")

    result = ArchE2EResult(
        preset=preset_name,
        steps=step,
        max_tokens=max_tokens,
        batch_size=batch_size,
        lr=lr,
        initial_loss=initial_loss,
        final_loss=final_loss,
        min_train_loss=min_train_loss,
        initial_valid_loss=initial_valid_loss,
        final_valid_loss=final_valid_loss,
        duration_sec=total_elapsed,
        num_train_chunks=len(train_ds),
        num_valid_chunks=len(valid_ds),
    )

    decreased = "YES" if result.loss_decreased else "NO"
    logger.info(
        "[%s] DONE | %d steps in %.1fs (%.2f step/s) "
        "| train %.4f -> %.4f (min %.4f) | valid %.4f -> %.4f | decreased=%s",
        preset_name, step, total_elapsed, step / total_elapsed if total_elapsed > 0 else 0,
        initial_loss, final_loss, min_train_loss,
        initial_valid_loss if initial_valid_loss is not None else float("nan"),
        final_valid_loss if final_valid_loss is not None else float("nan"),
        decreased,
    )

    with open(os.path.join(log_dir, f"{preset_name}_summary.json"), "w", encoding="utf-8") as f:
        json.dump(asdict(result), f, indent=2)

    # Free GPU before next preset.
    del model
    del optimizer
    torch.cuda.empty_cache() if torch.cuda.is_available() else None
    gc.collect()

    return result
