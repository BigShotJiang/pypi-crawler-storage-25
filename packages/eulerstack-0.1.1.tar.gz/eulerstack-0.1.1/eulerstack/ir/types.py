# eulerstack/ir/types.py
"""Canonical IR dataclasses — fully normalized, no optional fields."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass(frozen=True)
class ModelIdentityIR:
    name: str
    family_hint: Optional[str]
    d_model: int
    vocab_size: int
    max_seq_len: int
    n_heads: int
    n_kv_heads: int
    mlp_ratio: int
    dtype: str
    target_params: Optional[int]


@dataclass(frozen=True)
class TokenizerContractIR:
    type: str
    pretrained: str
    add_bos: bool
    add_eos: bool
    pad_token: Optional[str]


@dataclass(frozen=True)
class EmbeddingIR:
    type: str
    positional: str
    rope_theta: Optional[float]
    rope_scaling: Optional[Dict[str, float]]
    tie_word_embeddings: bool


@dataclass(frozen=True)
class MoeIR:
    experts: int
    top_k: int
    router: str
    z_loss: float
    capacity_factor: float


@dataclass(frozen=True)
class MixerIR:
    type: str
    config: Dict  # type-specific config, always fully populated


@dataclass(frozen=True)
class FfnIR:
    type: str
    activation: str
    bias: bool
    moe: Optional[MoeIR]


@dataclass(frozen=True)
class NormIR:
    type: str
    position: str


@dataclass(frozen=True)
class ResidualIR:
    type: str
    scaling: float


@dataclass(frozen=True)
class StateIR:
    kv_cache: bool
    ssm_state: bool


@dataclass(frozen=True)
class MemoryModuleIR:
    """Phase B4.1: Titans-style parametric memory module attached to a template.

    `update_at_inference=True` means the module's parameters receive inner
    gradient steps during generation (test-time update). When the HF custom
    model implements this, it must opt-in to grad at inference for the
    corresponding sub-module only.
    """
    type: str                      # neural_memory | associative | retrieval
    update_at_inference: bool
    hidden: int                    # params.hidden
    inner_lr: float
    persistence: str               # per_query | session | persistent


@dataclass(frozen=True)
class ShapeChangeIR:
    """Phase B4.2: Hourglass-style shape-change layer.

    The compiler reads `d_out` and inserts a projection (linear/conv1d/mlp)
    that remaps hidden_in → hidden_out at the template's residual boundary.
    Param count impact is non-trivial and reflected by the estimator.
    """
    d_out: int
    projection: str                # linear | conv1d | mlp


@dataclass(frozen=True)
class LayerTemplateIR:
    name: str
    mixer: MixerIR
    ffn: FfnIR
    norm: NormIR
    residual: ResidualIR
    state: StateIR
    memory: Optional[MemoryModuleIR] = None        # B4.1
    shape_change: Optional[ShapeChangeIR] = None   # B4.2
    # B3.3 core: Neural-ODE runtime metadata. When present, the expanded
    # layer represents a *single* shared body to be integrated K times at
    # forward with the chosen numerical scheme (ode_euler / ode_rk4).
    # For `discrete` integrators this stays None and the K-copy flattening
    # of `ir.expanded_layers` carries the independent-weights semantics.
    ode_integrator: Optional["IntegratorEntryIR"] = None


@dataclass(frozen=True)
class OverrideIR:
    """Per-layer override applied at schedule materialization.

    All fields are Optional; None means "use template value unchanged". Only
    the whitelisted set of v1 spec §6 is supported here.
    """
    residual_scaling: Optional[float] = None
    attention_window: Optional[int] = None    # int or None (None=unchanged)
    attention_attn_drop: Optional[float] = None
    norm_type: Optional[str] = None
    norm_position: Optional[str] = None
    ffn_activation: Optional[str] = None


@dataclass(frozen=True)
class DepthGatingIR:
    """Mixture-of-Depths routing config attached to a schedule entry."""
    enabled: bool
    capacity: float
    router: str


@dataclass(frozen=True)
class ParallelStreamIR:
    """One stream inside a parallel schedule entry (Phase B3.2)."""
    name: str
    body: tuple                    # tuple of (template_name, repeat) pairs


@dataclass(frozen=True)
class ParallelEntryIR:
    """Phase B3.2: monoidal parallel stream schedule entry.

    Two (or more) streams execute concurrently on the same hidden state and
    are recombined by the merge op. Stream bodies are flat lists of plain
    {template, repeat} entries (no nested parallel/integrator in v1).
    """
    streams: tuple                 # tuple of ParallelStreamIR
    merge_type: str                # concat | add | gated | cross_attn
    merge_projection: bool = True
    merge_from: Optional[str] = None
    merge_to: Optional[str] = None


@dataclass(frozen=True)
class IntegratorEntryIR:
    """Phase B3.3: recursive integrator schedule entry.

    `steps` applications of `body` template with shared params. v1.0 ships
    discrete only; ODE types are reserved.
    """
    integrator_type: str           # discrete (v1.0); ode_* reserved
    steps: int
    body_template: str
    output: str                    # token | hidden


@dataclass(frozen=True)
class ScheduleEntryIR:
    """Tagged-union schedule entry.

    kind="plain"       → template+repeat set, parallel/integrator None
    kind="parallel"    → parallel set, template=None
    kind="integrator"  → integrator set, template=None
    """
    template: Optional[str] = None
    repeat: int = 1
    override: Optional[OverrideIR] = None
    depth_gating: Optional[DepthGatingIR] = None
    parallel: Optional[ParallelEntryIR] = None
    integrator: Optional[IntegratorEntryIR] = None

    @property
    def kind(self) -> str:
        if self.parallel is not None:
            return "parallel"
        if self.integrator is not None:
            return "integrator"
        return "plain"


@dataclass(frozen=True)
class HeadIR:
    type: str
    tie_weights: bool


@dataclass(frozen=True)
class TrainingHintsIR:
    init: str
    dropout: float
    checkpointing: bool
    seed: int


@dataclass(frozen=True)
class CompatibilityIR:
    compile_target: str


@dataclass(frozen=True)
class ExecutionModeIR:
    """Phase B5: one reasoning/answer phase declaration.

    Declarative only — the HF training recipe / custom generate() must read
    these to implement phase-aware loss masking and generation budgets.
    DeepSeek-R1 (2025), OpenAI o1 / o3, Quiet-STaR (NeurIPS 2024).
    """
    name: str
    max_tokens: int
    kv_share: bool
    loss_weight: float
    visible_to_user: bool
    per_token_rationale: bool     # True for Quiet-STaR style


@dataclass(frozen=True)
class TransitionIR:
    """Phase B5: phase transition rule."""
    type: str                     # special_token | budget_exhausted
    token: Optional[str]          # required if type=special_token


@dataclass(frozen=True)
class ModelIR:
    model: ModelIdentityIR
    tokenizer_contract: TokenizerContractIR
    embedding: EmbeddingIR
    layer_templates: Dict[str, LayerTemplateIR]
    layer_schedule: List[ScheduleEntryIR]
    expanded_layers: List[LayerTemplateIR]
    head: HeadIR
    training_hints: TrainingHintsIR
    compatibility: CompatibilityIR
    # Phase B5: reasoning-mode metadata (None when absent; empty tuple for
    # no modes would be meaningless, so we use None to mean "standard model").
    execution_modes: Optional[tuple] = None    # tuple of ExecutionModeIR
    transition: Optional[TransitionIR] = None
