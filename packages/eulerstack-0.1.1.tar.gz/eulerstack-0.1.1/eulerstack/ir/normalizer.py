# eulerstack/ir/normalizer.py
"""YAML v2 dict → canonical ModelIR normalization."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from eulerstack.spec.validate import validate_v2
from eulerstack.spec.errors import NormalizationError
from .types import (
    ModelIR,
    ModelIdentityIR,
    TokenizerContractIR,
    EmbeddingIR,
    MixerIR,
    FfnIR,
    MoeIR,
    NormIR,
    ResidualIR,
    StateIR,
    LayerTemplateIR,
    ScheduleEntryIR,
    OverrideIR,
    DepthGatingIR,
    ParallelStreamIR,
    ParallelEntryIR,
    IntegratorEntryIR,
    MemoryModuleIR,
    ShapeChangeIR,
    ExecutionModeIR,
    TransitionIR,
    HeadIR,
    TrainingHintsIR,
    CompatibilityIR,
)

# ── Mixer defaults ──

_ATTENTION_DEFAULTS = {"qkv_bias": False, "attn_drop": 0.0, "window": None, "latent_dim": None}
_MAMBA_DEFAULTS = {"variant": "mamba2", "d_state": 64, "d_conv": 4, "expand": 2}
_RETNET_DEFAULTS = {"chunkwise": True, "chunk_size": 64, "rope": True}
_HYENA_DEFAULTS = {"depth": 2, "filter_hidden": 64, "filter_decay": 0.0}
# Phase B2.3: TTT layer defaults (Sun et al. 2024).
_TTT_DEFAULTS = {
    "inner_model": {"type": "mlp", "hidden": 256},
    "inner_optimizer": "sgd",
    "inner_lr": 0.01,
    "inner_steps_per_token": 1,
}

_MIXER_DEFAULTS = {
    "attention": _ATTENTION_DEFAULTS,
    "mamba": _MAMBA_DEFAULTS,
    "retnet": _RETNET_DEFAULTS,
    "hyena": _HYENA_DEFAULTS,
    "ttt_layer": _TTT_DEFAULTS,
}

# ── Activation defaults per FFN type ──
_FFN_ACTIVATION_DEFAULTS = {
    "mlp": "gelu",
    "gated_mlp": "swiglu",
    "moe": "gelu",
}


def _merge_defaults(raw: Optional[Dict], defaults: Dict) -> Dict:
    if raw is None:
        raw = {}
    merged = dict(defaults)
    merged.update(raw)
    return merged


def _normalize_mixer(raw: Dict[str, Any]) -> MixerIR:
    mixer_type = raw["type"]
    # Phase B2.2/B2.3: sub-object key differs from type for ttt_layer and branched.
    _TYPE_TO_SUBKEY = {
        "attention": "attention", "mamba": "mamba", "retnet": "retnet",
        "hyena": "hyena", "branched": "branched", "ttt_layer": "ttt",
    }
    sub_key = _TYPE_TO_SUBKEY.get(mixer_type, mixer_type)
    sub_raw = raw.get(sub_key, {})
    if not isinstance(sub_raw, dict):
        sub_raw = {}
    if mixer_type == "branched":
        # Normalize each inner branch recursively.
        branches_raw = sub_raw.get("branches", {})
        branches = {
            name: _normalize_mixer(bdef)
            for name, bdef in branches_raw.items()
        }
        selector_raw = sub_raw.get("selector", {}) or {}
        config = {
            "branches": {
                # Store as dict to keep MixerIR frozen-friendly.
                name: {"type": b.type, "config": dict(b.config)}
                for name, b in branches.items()
            },
            "selector": {
                "type": str(selector_raw.get("type", "learned_gate")),
                "top_k": int(selector_raw.get("top_k", 1)),
                "input": str(selector_raw.get("input", "hidden")),
            },
        }
    else:
        config = _merge_defaults(sub_raw, _MIXER_DEFAULTS.get(mixer_type, {}))
    return MixerIR(type=mixer_type, config=config)


def _normalize_ffn(raw: Dict[str, Any]) -> FfnIR:
    ffn_type = raw["type"]
    activation = raw.get("activation", _FFN_ACTIVATION_DEFAULTS.get(ffn_type, "gelu"))
    bias = bool(raw.get("bias", False))

    moe_ir = None
    if ffn_type == "moe" and "moe" in raw:
        moe_raw = raw["moe"]
        moe_ir = MoeIR(
            experts=int(moe_raw["experts"]),
            top_k=int(moe_raw["top_k"]),
            router=str(moe_raw.get("router", "softmax")),
            z_loss=float(moe_raw.get("z_loss", 0.0)),
            capacity_factor=float(moe_raw.get("capacity_factor", 1.0)),
        )

    return FfnIR(type=ffn_type, activation=activation, bias=bias, moe=moe_ir)


def _normalize_norm(raw: Optional[Dict[str, Any]]) -> NormIR:
    if raw is None:
        raw = {}
    return NormIR(
        type=str(raw.get("type", "rmsnorm")),
        position=str(raw.get("position", "pre")),
    )


def _normalize_residual(raw: Optional[Dict[str, Any]]) -> ResidualIR:
    if raw is None:
        raw = {}
    return ResidualIR(
        type=str(raw.get("type", "sequential")),
        scaling=float(raw.get("scaling", 1.0)),
    )


def _normalize_state(raw: Optional[Dict[str, Any]], mixer_type: str) -> StateIR:
    if raw is None:
        raw = {}
    # Infer defaults from mixer type if not explicitly set
    if "kv_cache" not in raw and "ssm_state" not in raw:
        if mixer_type in ("attention", "retnet"):
            return StateIR(kv_cache=True, ssm_state=False)
        elif mixer_type == "mamba":
            return StateIR(kv_cache=False, ssm_state=True)
        elif mixer_type == "ttt_layer":
            # Phase B2.3: TTT maintains an inner-state that evolves at test time.
            return StateIR(kv_cache=False, ssm_state=True)
        else:
            # branched / unknown: neither default, user must opt in.
            return StateIR(kv_cache=False, ssm_state=False)
    return StateIR(
        kv_cache=bool(raw.get("kv_cache", False)),
        ssm_state=bool(raw.get("ssm_state", False)),
    )


def _normalize_memory(raw: Optional[Dict[str, Any]]) -> Optional[MemoryModuleIR]:
    """Phase B4.1: Titans memory module."""
    if raw is None:
        return None
    params = raw.get("params") or {}
    return MemoryModuleIR(
        type=str(raw["type"]),
        update_at_inference=bool(raw.get("update_at_inference", False)),
        hidden=int(params.get("hidden", 2048)),
        inner_lr=float(raw.get("inner_lr", 1e-3)),
        persistence=str(raw.get("persistence", "session")),
    )


def _normalize_shape_change(raw: Optional[Dict[str, Any]]) -> Optional[ShapeChangeIR]:
    """Phase B4.2: Hourglass-style shape change."""
    if raw is None:
        return None
    return ShapeChangeIR(
        d_out=int(raw["d_out"]),
        projection=str(raw.get("projection", "linear")),
    )


def _normalize_template(name: str, raw: Dict[str, Any]) -> LayerTemplateIR:
    mixer = _normalize_mixer(raw["mixer"])
    ffn = _normalize_ffn(raw["ffn"])
    norm = _normalize_norm(raw.get("norm"))
    residual = _normalize_residual(raw.get("residual"))
    state = _normalize_state(raw.get("state"), mixer.type)
    memory = _normalize_memory(raw.get("memory"))
    shape_change = _normalize_shape_change(raw.get("shape_change"))
    return LayerTemplateIR(
        name=name,
        mixer=mixer,
        ffn=ffn,
        norm=norm,
        residual=residual,
        state=state,
        memory=memory,
        shape_change=shape_change,
    )


def _normalize_plain_entry(entry: Dict[str, Any]) -> ScheduleEntryIR:
    """Build a plain schedule entry IR (template + repeat + optional override/MoD)."""
    override_ir: Optional[OverrideIR] = None
    if entry.get("override"):
        ov = entry["override"]
        attn_ov = ov.get("attention") or {}
        norm_ov = ov.get("norm") or {}
        ffn_ov = ov.get("ffn") or {}
        res_ov = ov.get("residual") or {}
        override_ir = OverrideIR(
            residual_scaling=(float(res_ov["scaling"])
                              if "scaling" in res_ov else None),
            attention_window=(int(attn_ov["window"])
                               if attn_ov.get("window") is not None else None),
            attention_attn_drop=(float(attn_ov["attn_drop"])
                                  if "attn_drop" in attn_ov else None),
            norm_type=norm_ov.get("type"),
            norm_position=norm_ov.get("position"),
            ffn_activation=ffn_ov.get("activation"),
        )
    depth_gating_ir: Optional[DepthGatingIR] = None
    if entry.get("depth_gating"):
        dg = entry["depth_gating"]
        depth_gating_ir = DepthGatingIR(
            enabled=bool(dg.get("enabled", True)),
            capacity=float(dg.get("capacity", 0.5)),
            router=str(dg.get("router", "top_k")),
        )
    return ScheduleEntryIR(
        template=str(entry["template"]),
        repeat=int(entry.get("repeat", 1)),
        override=override_ir,
        depth_gating=depth_gating_ir,
    )


def _normalize_parallel_entry(entry: Dict[str, Any],
                               templates: Dict[str, LayerTemplateIR]) -> ScheduleEntryIR:
    streams_raw = entry["parallel"]
    streams_ir = []
    for s in streams_raw:
        body = tuple((str(b["template"]), int(b.get("repeat", 1))) for b in s["body"])
        streams_ir.append(ParallelStreamIR(name=str(s["stream"]), body=body))
    merge = entry.get("merge") or {"type": "concat"}
    par_ir = ParallelEntryIR(
        streams=tuple(streams_ir),
        merge_type=str(merge.get("type", "concat")),
        merge_projection=bool(merge.get("projection", True)),
        merge_from=merge.get("from"),
        merge_to=merge.get("to"),
    )
    return ScheduleEntryIR(template=None, repeat=1, parallel=par_ir)


def _normalize_integrator_entry(entry: Dict[str, Any]) -> ScheduleEntryIR:
    intg = entry["integrator"]
    int_ir = IntegratorEntryIR(
        integrator_type=str(intg["type"]),
        steps=int(intg["steps"]),
        body_template=str(intg["body"]),
        output=str(intg.get("output", "token")),
    )
    return ScheduleEntryIR(template=None, repeat=1, integrator=int_ir)


def _apply_override(tmpl: LayerTemplateIR, ov: OverrideIR) -> LayerTemplateIR:
    """Return a new LayerTemplateIR with whitelisted fields replaced.

    This is how schedule-level overrides reach the per-layer materialization.
    Param count is preserved (only value-typed fields may change).
    """
    new_residual = tmpl.residual
    if ov.residual_scaling is not None:
        new_residual = ResidualIR(type=tmpl.residual.type, scaling=ov.residual_scaling)

    new_mixer = tmpl.mixer
    if tmpl.mixer.type == "attention" and (
        ov.attention_window is not None or ov.attention_attn_drop is not None
    ):
        cfg = dict(tmpl.mixer.config)
        if ov.attention_window is not None:
            cfg["window"] = ov.attention_window
        if ov.attention_attn_drop is not None:
            cfg["attn_drop"] = ov.attention_attn_drop
        new_mixer = MixerIR(type="attention", config=cfg)

    new_norm = tmpl.norm
    if ov.norm_type is not None or ov.norm_position is not None:
        new_norm = NormIR(
            type=ov.norm_type or tmpl.norm.type,
            position=ov.norm_position or tmpl.norm.position,
        )

    new_ffn = tmpl.ffn
    if ov.ffn_activation is not None:
        new_ffn = FfnIR(
            type=tmpl.ffn.type,
            activation=ov.ffn_activation,
            bias=tmpl.ffn.bias,
            moe=tmpl.ffn.moe,
        )

    return LayerTemplateIR(
        name=tmpl.name,
        mixer=new_mixer,
        ffn=new_ffn,
        norm=new_norm,
        residual=new_residual,
        state=tmpl.state,
        # Preserve template-level primitives not covered by the B1.1
        # override whitelist (Titans memory, Hourglass shape_change, and
        # any attached ode_integrator metadata from B3.3). Dropping these
        # silently would turn override into a stealth param-count changer.
        memory=tmpl.memory,
        shape_change=tmpl.shape_change,
        ode_integrator=tmpl.ode_integrator,
    )


def normalize_to_ir(raw: Dict[str, Any]) -> ModelIR:
    """
    Full pipeline: validate → normalize → produce ModelIR.

    Raises ValidationError/CompatibilityError on invalid input.
    Raises NormalizationError on normalization failures.
    """
    # validate_v2 returns the resolved dict (with let:/${...} substituted).
    # Use it for downstream normalization so ${...} strings never leak in.
    raw = validate_v2(raw)

    # Model identity
    m = raw["model"]
    n_heads = int(m["n_heads"])
    model = ModelIdentityIR(
        name=str(m["name"]),
        family_hint=m.get("family_hint"),
        d_model=int(m["d_model"]),
        vocab_size=int(m["vocab_size"]),
        max_seq_len=int(m["max_seq_len"]),
        n_heads=n_heads,
        n_kv_heads=int(m.get("n_kv_heads", n_heads)),
        mlp_ratio=int(m.get("mlp_ratio", 4)),
        dtype=str(m.get("dtype", "bfloat16")),
        target_params=int(m["target_params"]) if m.get("target_params") is not None else None,
    )

    # Tokenizer
    t = raw["tokenizer_contract"]
    tokenizer = TokenizerContractIR(
        type=str(t["type"]),
        pretrained=str(t["pretrained"]),
        add_bos=bool(t.get("add_bos", True)),
        add_eos=bool(t.get("add_eos", True)),
        pad_token=t.get("pad_token"),
    )

    # Embedding
    e = raw["embedding"]
    rope_scaling = None
    if e.get("rope_scaling") and isinstance(e["rope_scaling"], dict):
        rope_scaling = {
            "type": str(e["rope_scaling"].get("type", "linear")),
            "factor": float(e["rope_scaling"].get("factor", 1.0)),
        }
    embedding = EmbeddingIR(
        type=str(e["type"]),
        positional=str(e["positional"]),
        rope_theta=float(e["rope_theta"]) if "rope_theta" in e and e["rope_theta"] is not None else None,
        rope_scaling=rope_scaling,
        tie_word_embeddings=bool(e.get("tie_word_embeddings", True)),
    )

    # Templates
    templates: Dict[str, LayerTemplateIR] = {}
    for tname, tdef in raw["layer_templates"].items():
        templates[tname] = _normalize_template(tname, tdef)

    # Schedule — dispatch plain / parallel / integrator (Phase B3)
    schedule: list[ScheduleEntryIR] = []
    for entry in raw["layer_schedule"]:
        if "parallel" in entry:
            schedule.append(_normalize_parallel_entry(entry, templates))
        elif "integrator" in entry:
            schedule.append(_normalize_integrator_entry(entry))
        else:
            schedule.append(_normalize_plain_entry(entry))

    # Expand layers. Parallel and integrator are flattened into expanded_layers
    # so existing compiler/param-estimator works:
    #   parallel  → concat of all streams' layers (param sum semantics)
    #   integrator → body template × steps (param sharing handled by compiler)
    expanded: list[LayerTemplateIR] = []
    for se in schedule:
        if se.kind == "plain":
            base_tmpl = templates[se.template]
            tmpl = _apply_override(base_tmpl, se.override) if se.override else base_tmpl
            for _ in range(se.repeat):
                expanded.append(tmpl)
        elif se.kind == "parallel":
            for stream in se.parallel.streams:
                for (tname, rep) in stream.body:
                    tmpl = templates[tname]
                    for _ in range(rep):
                        expanded.append(tmpl)
        elif se.kind == "integrator":
            tmpl = templates[se.integrator.body_template]
            itype = se.integrator.integrator_type
            if itype.startswith("ode_"):
                # Neural-ODE: one shared body integrated K times in forward.
                from dataclasses import replace as _dc_replace
                tagged = _dc_replace(tmpl, ode_integrator=se.integrator)
                expanded.append(tagged)
            else:
                # Discrete (Diffusion-LM-style): K distinct weight copies.
                for _ in range(se.integrator.steps):
                    expanded.append(tmpl)

    if len(expanded) == 0:
        raise NormalizationError("Expanded layers is empty", fix="Add entries to layer_schedule")

    # Head
    h = raw["head"]
    head = HeadIR(
        type=str(h["type"]),
        tie_weights=bool(h.get("tie_weights", True)),
    )

    # Training hints
    th = raw.get("training_hints", {}) or {}
    training_hints = TrainingHintsIR(
        init=str(th.get("init", "normal_0.02")),
        dropout=float(th.get("dropout", 0.0)),
        checkpointing=bool(th.get("checkpointing", False)),
        seed=int(th.get("seed", 1234)),
    )

    # Compatibility
    compat = raw.get("compatibility", {}) or {}
    compatibility = CompatibilityIR(
        compile_target=str(compat.get("compile_target", "huggingface")),
    )

    # Phase B5: execution modes (R1 / Quiet-STaR)
    exec_modes_tuple: Optional[tuple] = None
    if raw.get("execution_modes"):
        modes = []
        for m in raw["execution_modes"]:
            modes.append(ExecutionModeIR(
                name=str(m["name"]),
                max_tokens=int(m["max_tokens"]),
                kv_share=bool(m.get("kv_share", False)),
                loss_weight=float(m.get("loss_weight", 1.0)),
                visible_to_user=bool(m.get("visible_to_user", True)),
                per_token_rationale=bool(m.get("per_token_rationale", False)),
            ))
        exec_modes_tuple = tuple(modes)
    transition_ir: Optional[TransitionIR] = None
    if raw.get("transition"):
        tr = raw["transition"]
        transition_ir = TransitionIR(
            type=str(tr.get("type", "special_token")),
            token=tr.get("token"),
        )

    return ModelIR(
        model=model,
        tokenizer_contract=tokenizer,
        embedding=embedding,
        layer_templates=templates,
        layer_schedule=schedule,
        expanded_layers=expanded,
        head=head,
        training_hints=training_hints,
        compatibility=compatibility,
        execution_modes=exec_modes_tuple,
        transition=transition_ir,
    )
