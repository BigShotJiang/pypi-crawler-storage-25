# eulerstack/cli/spec_cmd.py
"""Top-level CLI commands: validate, explain, compile, schema.

All user-facing strings go through i18n (eulerstack.i18n.t).
Commands are returned by factory functions so Click captures translations
at the current language, not at module import time.
"""
from __future__ import annotations

import json
import sys
from typing import Optional

import click
import yaml

from eulerstack.i18n import t
from eulerstack.spec.errors import EulerStackError
from eulerstack.spec.validate import validate_v2
from eulerstack.ir.normalizer import normalize_to_ir
from eulerstack.compiler.compile import compile_ir


# ── Shared helpers ──


def _emit_3line(category_key: str, msg: str, fix: str, see: str) -> None:
    """Emit a 3-line error to stderr and exit 1."""
    click.echo(f"{t(category_key)}: {msg}\nFix: {fix}\nSee: {see}", err=True)
    sys.exit(1)


def _load_yaml(path: str) -> dict:
    """Load a YAML file. Exits with 3-line error on failure."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except FileNotFoundError:
        _emit_3line(
            "error.category.validation",
            t("error.file_not_found.msg", path=path),
            t("error.file_not_found.fix"),
            t("error.see_spec_doc"),
        )
    except yaml.YAMLError as e:
        _emit_3line(
            "error.category.validation",
            t("error.yaml_parse.msg", detail=str(e)),
            t("error.yaml_parse.fix"),
            t("error.see_spec_doc"),
        )
    if not isinstance(data, dict):
        _emit_3line(
            "error.category.validation",
            t("error.root_mapping.msg"),
            t("error.root_mapping.fix"),
            t("error.see_spec_doc"),
        )
    return data


def _handle_error(e: EulerStackError) -> None:
    """Print existing 3-line error from EulerStackError (already formatted)."""
    click.echo(e.format_3line(), err=True)
    sys.exit(1)


# ── Command factories ──


def make_validate():
    @click.command("validate", help=t("validate.help"))
    @click.option("--preset", required=True, type=click.Path(exists=False),
                  help=t("validate.opt.preset.help"))
    @click.option("--report", is_flag=True, default=False,
                  help=t("validate.opt.report.help"))
    @click.option("--validate-only", is_flag=True, default=False,
                  help=t("validate.opt.validate_only.help"))
    def validate(preset: str, report: bool, validate_only: bool):
        raw = _load_yaml(preset)

        if report:
            from eulerstack.spec.report import generate_report
            rpt = generate_report(raw)
            click.echo(rpt.format_text())
            if rpt.has_errors:
                sys.exit(1)
            return

        try:
            validate_v2(raw)
        except EulerStackError as e:
            _handle_error(e)
        click.echo(t("validate.ok", path=preset))

    return validate


def make_explain():
    @click.command("explain", help=t("explain.help"))
    @click.option("--preset", required=True, type=click.Path(exists=False),
                  help=t("explain.opt.preset.help"))
    def explain(preset: str):
        raw = _load_yaml(preset)
        try:
            ir = normalize_to_ir(raw)
        except EulerStackError as e:
            _handle_error(e)

        click.echo(t("explain.model", name=ir.model.name))
        if ir.model.family_hint:
            click.echo(t("explain.family_hint", hint=ir.model.family_hint))
        click.echo(t("explain.dimensions",
                     d_model=ir.model.d_model, n_heads=ir.model.n_heads,
                     n_kv_heads=ir.model.n_kv_heads))
        click.echo(t("explain.vocab_seq",
                     vocab=ir.model.vocab_size, max_seq_len=ir.model.max_seq_len,
                     dtype=ir.model.dtype))
        click.echo(t("explain.positional", positional=ir.embedding.positional))
        click.echo()

        click.echo(t("explain.layer_templates"))
        for name, tmpl in ir.layer_templates.items():
            click.echo(f"  {name}:")
            click.echo(t("explain.template.mixer",
                         type=tmpl.mixer.type, config=tmpl.mixer.config))
            ffn_extra = (
                t("explain.template.ffn_moe_extra", experts=tmpl.ffn.moe.experts)
                if tmpl.ffn.moe else ""
            )
            click.echo(t("explain.template.ffn",
                         type=tmpl.ffn.type, extra=ffn_extra))
            click.echo(t("explain.template.norm",
                         type=tmpl.norm.type, position=tmpl.norm.position))
            click.echo(t("explain.template.residual", type=tmpl.residual.type))
        click.echo()

        click.echo(t("explain.layer_schedule"))
        total = 0
        for entry in ir.layer_schedule:
            click.echo(f"  {entry.template} x{entry.repeat}")
            total += entry.repeat
        click.echo(t("explain.total_layers", total=total))
        click.echo()

        click.echo(t("explain.head", head_type=ir.head.type, tie=ir.head.tie_weights))
        click.echo(t("explain.compile_target", target=ir.compatibility.compile_target))

        from eulerstack.spec.param_estimator import estimate_params, format_param_count
        est = estimate_params(ir)
        click.echo(t("explain.estimated_params", pretty=format_param_count(est), exact=est))
        if ir.model.target_params:
            ratio = est / ir.model.target_params
            click.echo(t("explain.target_params",
                         pretty=format_param_count(ir.model.target_params), ratio=ratio))

    return explain


def make_compile():
    @click.command("compile", help=t("compile.help"))
    @click.option("--preset", required=True, type=click.Path(exists=False),
                  help=t("compile.opt.preset.help"))
    @click.option("--output", "-o", default=None, type=click.Path(),
                  help=t("compile.opt.output.help"))
    @click.option("--output-dir", default=None, type=click.Path(),
                  help=t("compile.opt.output_dir.help"))
    @click.option("--validate-only", is_flag=True, default=False,
                  help=t("compile.opt.validate_only.help"))
    @click.option("--print-config", is_flag=True, default=False,
                  help=t("compile.opt.print_config.help"))
    @click.option("--dry-run", is_flag=True, default=False,
                  help=t("compile.opt.dry_run.help"))
    def compile_cmd(preset: str, output: Optional[str], output_dir: Optional[str],
                    validate_only: bool, print_config: bool, dry_run: bool):
        raw = _load_yaml(preset)

        try:
            ir = normalize_to_ir(raw)
        except EulerStackError as e:
            _handle_error(e)

        if validate_only:
            click.echo(t("compile.validate_only_ok", path=preset))
            return

        # ── HF model directory output ──
        if output_dir is not None:
            try:
                from eulerstack.compiler.compile import compile_to_hf_model
                from eulerstack.spec.param_estimator import estimate_params, format_param_count
                model = compile_to_hf_model(ir)
                model.save_pretrained(output_dir)

                # Persist the tokenizer referenced by tokenizer_contract so
                # that `AutoTokenizer.from_pretrained(output_dir)` succeeds
                # without network fallback. Non-fatal on failure: the user
                # can always add the tokenizer manually, but the happy path
                # should just work.
                tok_spec = getattr(ir, "tokenizer_contract", None)
                if tok_spec is not None:
                    try:
                        from eulerstack.components.tokenizer_wrap import (
                            load_tokenizer, tokenizer_spec_to_dict,
                        )
                        tok = load_tokenizer(tokenizer_spec_to_dict(tok_spec))
                        tok.save_pretrained(output_dir)
                        click.echo(t("compile.hf_saved.tokenizer",
                                     pretrained=tokenizer_spec_to_dict(tok_spec).get("pretrained", "?")))
                    except Exception as te:  # noqa: BLE001 — non-fatal
                        click.echo(t("compile.hf_saved.tokenizer_warn",
                                     detail=str(te)), err=True)

                est = estimate_params(ir)
                click.echo(t("compile.hf_saved.header", output_dir=output_dir))
                click.echo(t("compile.hf_saved.model_type"))
                click.echo(t("compile.hf_saved.params", pretty=format_param_count(est), exact=est))
                click.echo(t("compile.hf_saved.layers", n_layers=len(ir.expanded_layers)))
                click.echo(t("compile.hf_saved.load_hint", output_dir=output_dir))
            except Exception as e:
                _emit_3line(
                    "error.category.compile",
                    t("error.hf_build_failed.msg", detail=str(e)),
                    t("error.hf_build_failed.fix"),
                    t("error.see_spec_doc"),
                )
            return

        # ── JSON runtime config output ──
        try:
            result = compile_ir(ir)
        except EulerStackError as e:
            _handle_error(e)

        json_str = json.dumps(result, indent=2, ensure_ascii=False)

        if dry_run or print_config:
            click.echo(json_str)
            return

        if output is None:
            click.echo(json_str)
        else:
            with open(output, "w", encoding="utf-8") as f:
                f.write(json_str)
            click.echo(t("compile.json_written", output=output))

    return compile_cmd


def make_schema():
    @click.command("schema", help=t("schema.help"))
    def schema():
        # Structure lines are language-neutral (YAML key names). Only headers/footers
        # are translated. This keeps the output reliable as a spec reference.
        lines = [
            t("schema.header"),
            "==============================",
            "",
            t("schema.top_level"),
            "  schema_version: 1  (REQUIRED)",
            "  model:              (REQUIRED) — name, d_model, vocab_size, max_seq_len, n_heads, ...",
            "  tokenizer_contract: (REQUIRED) — type, pretrained, add_bos, add_eos, pad_token",
            "  embedding:          (REQUIRED) — type, positional, rope_theta, rope_scaling, tie_word_embeddings",
            "  layer_templates:    (REQUIRED) — named templates: mixer, ffn, norm, residual, state",
            "  layer_schedule:     (REQUIRED) — [{template, repeat}, ...]",
            "  head:               (REQUIRED) — type, tie_weights",
            "  training_hints:     (optional) — init, dropout, checkpointing, seed, target_params",
            "  compatibility:      (optional) — compile_target",
            "",
            "mixer.type:     attention | mamba | retnet | hyena",
            "ffn.type:       mlp | gated_mlp | moe",
            "norm.type:      rmsnorm | layernorm",
            "norm.position:  pre | post",
            "residual.type:  sequential | parallel",
            "head.type:      causal_lm",
            "compile_target: huggingface",
            "",
            t("schema.see_spec"),
        ]
        click.echo("\n".join(lines))

    return schema


# ── Back-compat: some callers import the commands directly ──
def _lazy(name):
    factories = {
        "validate": make_validate,
        "explain": make_explain,
        "compile_cmd": make_compile,
        "schema": make_schema,
    }
    return factories[name]()


def __getattr__(attr):
    if attr in ("validate", "explain", "compile_cmd", "schema"):
        return _lazy(attr)
    raise AttributeError(attr)
