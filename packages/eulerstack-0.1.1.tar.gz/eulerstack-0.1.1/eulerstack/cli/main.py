# eulerstack/cli/main.py
"""EulerStack CLI — Click-based entry point.

Command hierarchy (eulerwa product-family style):
  eulerstack [--lang ko|en|zh|ja|es] validate --preset <yaml> [--report] [--validate-only]
  eulerstack [--lang ...]            explain  --preset <yaml>
  eulerstack [--lang ...]            compile  --preset <yaml> [--output <path>] [--output-dir <dir>] [--validate-only] [--print-config]
  eulerstack [--lang ...]            schema
  eulerstack [--lang ...]            presets list
  eulerstack [--lang ...]            presets show <name>

The --lang option translates all help, logs, warnings, errors and completion messages.
CLI command names, option names, and exit codes remain fixed across languages.
"""
from __future__ import annotations

import os
import sys

import click

from eulerstack import __version__ as _pkg_version
from eulerstack.i18n import t, set_lang, SUPPORTED_LANGS, DEFAULT_LANG, resolve_lang


def _peek_lang_from_argv() -> str | None:
    """Peek --lang value from argv before Click parses."""
    argv = sys.argv[1:]
    for i, a in enumerate(argv):
        if a == "--lang" and i + 1 < len(argv):
            return argv[i + 1]
        if a.startswith("--lang="):
            return a.split("=", 1)[1]
    return None


def build_cli():
    """Build the Click CLI tree with translations at current language.

    Must be called AFTER set_lang(). Click captures help= strings at decoration
    time, so we construct the tree lazily so translations are correct.
    """
    from .spec_cmd import make_validate, make_explain, make_compile, make_schema
    from .presets_cmd import make_presets

    @click.group(help=t("cli.root.help"))
    @click.version_option(version=_pkg_version, prog_name="eulerstack")
    @click.option(
        "--lang",
        type=click.Choice(list(SUPPORTED_LANGS), case_sensitive=False),
        default=None,
        help=t("cli.option.lang.help"),
    )
    @click.pass_context
    def cli(ctx, lang):
        """EulerStack root command."""
        resolved = resolve_lang(lang) if lang else get_effective_lang()
        set_lang(resolved)
        ctx.ensure_object(dict)
        ctx.obj["lang"] = resolved

    cli.add_command(make_validate())
    cli.add_command(make_explain())
    cli.add_command(make_compile(), name="compile")
    cli.add_command(make_schema())
    cli.add_command(make_presets())

    return cli


def get_effective_lang() -> str:
    """Resolve effective language from argv or env var."""
    pre = _peek_lang_from_argv()
    if pre:
        return resolve_lang(pre)
    env = os.environ.get("EULERSTACK_LANG", "")
    if env:
        return resolve_lang(env)
    return DEFAULT_LANG


def main():
    # Resolve language BEFORE building CLI so help text is translated.
    set_lang(get_effective_lang())
    cli = build_cli()
    cli()


# Back-compat: some tests do `from eulerstack.cli.main import cli`.
# Provide a lazy attribute that builds on first access with the current lang.
def __getattr__(name):
    if name == "cli":
        set_lang(get_effective_lang())
        return build_cli()
    raise AttributeError(name)


if __name__ == "__main__":
    main()
