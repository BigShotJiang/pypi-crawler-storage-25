# eulerstack/cli/presets_cmd.py
"""CLI `eulerstack presets` subcommands: list, show."""
from __future__ import annotations

import os
import glob
import sys

import click
import yaml

from eulerstack.i18n import t
from eulerstack.spec.errors import EulerStackError
from eulerstack.ir.normalizer import normalize_to_ir
from eulerstack.spec.param_estimator import estimate_params, format_param_count


def _presets_dir() -> str | None:
    """Resolve the preset directory.

    Resolution order (first hit wins):
      1. `EULERSTACK_PRESETS_DIR` env var.
      2. `$cwd/configs/presets` — eulerforge-style workspace pattern; the
         shipped release tarball places `configs/` under the user's cwd.
      3. `{package}/../../configs/presets` — source-tree fallback (editable
         install from a dev checkout).

    Returns None when no candidate exists. Callers must surface a clear
    error; silent fall-through to exit 0 is a packaging bug.
    """
    env = os.environ.get("EULERSTACK_PRESETS_DIR")
    if env and os.path.isdir(env):
        return env

    cwd_candidate = os.path.abspath(os.path.join(os.getcwd(), "configs", "presets"))
    if os.path.isdir(cwd_candidate):
        return cwd_candidate

    pkg_candidate = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..", "..", "configs", "presets")
    )
    if os.path.isdir(pkg_candidate):
        return pkg_candidate

    return None


def _emit_no_dir_error() -> None:
    """3-line error shared by `presets list` and `presets show` when the
    preset directory cannot be found in any of the candidate locations."""
    click.echo(
        f"{t('error.category.validation')}: {t('error.preset_dir_not_found.msg')}\n"
        f"Fix: {t('error.preset_dir_not_found.fix')}\n"
        f"See: {t('error.see_preset_tutorial')}",
        err=True,
    )


def make_presets():
    @click.group("presets", help=t("cli.presets.help"))
    def presets():
        pass

    @presets.command("list", help=t("presets.list.help"))
    def list_presets():
        pdir = _presets_dir()
        if pdir is None:
            _emit_no_dir_error()
            sys.exit(1)

        files = sorted(glob.glob(os.path.join(pdir, "*.yml")))
        if not files:
            click.echo(t("presets.list.empty"))
            return

        header = (
            f"{t('presets.list.header.preset'):<35s} "
            f"{t('presets.list.header.layers'):>6s} "
            f"{t('presets.list.header.params'):>12s} "
            f"{t('presets.list.header.target'):>10s} "
            f"{t('presets.list.header.ratio'):>7s}"
        )
        click.echo(header)
        click.echo("-" * 75)

        for fpath in files:
            name = os.path.splitext(os.path.basename(fpath))[0]
            try:
                with open(fpath) as f:
                    raw = yaml.safe_load(f)
                ir = normalize_to_ir(raw)
                est = estimate_params(ir)
                n_layers = len(ir.expanded_layers)
                target = ir.model.target_params
                target_str = format_param_count(target) if target else "—"
                ratio_str = f"{est / target:.0%}" if target else "—"
                click.echo(f"{name:<35s} {n_layers:>6d} "
                           f"{format_param_count(est):>12s} "
                           f"{target_str:>10s} {ratio_str:>7s}")
            except Exception as e:
                click.echo(t("presets.list.per_preset_error", name=name, err=str(e)))

    @presets.command("show", help=t("presets.show.help"))
    @click.argument("name")
    def show(name: str):
        pdir = _presets_dir()
        if pdir is None:
            _emit_no_dir_error()
            sys.exit(1)
        fpath = os.path.join(pdir, f"{name}.yml")
        if not os.path.exists(fpath):
            click.echo(
                f"{t('error.category.validation')}: {t('error.preset_not_found.msg', name=name)}\n"
                f"Fix: {t('error.preset_not_found.fix')}\n"
                f"See: {t('error.see_preset_tutorial')}",
                err=True,
            )
            sys.exit(1)

        with open(fpath) as f:
            raw = yaml.safe_load(f)

        try:
            ir = normalize_to_ir(raw)
        except EulerStackError as e:
            click.echo(e.format_3line(), err=True)
            sys.exit(1)

        est = estimate_params(ir)
        click.echo(t("presets.show.header", name=name))
        click.echo(t("explain.model", name=ir.model.name))
        if ir.model.family_hint:
            click.echo(t("explain.family_hint", hint=ir.model.family_hint))
        click.echo(t("explain.dimensions",
                     d_model=ir.model.d_model, n_heads=ir.model.n_heads,
                     n_kv_heads=ir.model.n_kv_heads))
        click.echo(t("explain.vocab_seq",
                     vocab=ir.model.vocab_size, max_seq_len=ir.model.max_seq_len,
                     dtype=ir.model.dtype))
        click.echo(t("explain.positional", positional=ir.embedding.positional))
        click.echo(t("explain.estimated_params", pretty=format_param_count(est), exact=est))
        if ir.model.target_params:
            click.echo(t("explain.target_params",
                         pretty=format_param_count(ir.model.target_params),
                         ratio=est / ir.model.target_params))
        click.echo()

        click.echo(t("explain.layer_templates"))
        for tname, tmpl in ir.layer_templates.items():
            click.echo(f"  {tname}:")
            # `presets show` prints a shorter mixer line (no config dump) —
            # pass `config=""` so the template renders the type only.
            click.echo(t("explain.template.mixer",
                         type=tmpl.mixer.type, config=""))
            ffn_extra = (
                t("explain.template.ffn_moe_extra", experts=tmpl.ffn.moe.experts)
                if tmpl.ffn.moe else ""
            )
            click.echo(t("explain.template.ffn",
                         type=tmpl.ffn.type, extra=ffn_extra))
            click.echo(t("explain.template.norm",
                         type=tmpl.norm.type, position=tmpl.norm.position))
        click.echo()

        click.echo(t("explain.layer_schedule"))
        for entry in ir.layer_schedule:
            click.echo(f"  {entry.template} x{entry.repeat}")
        click.echo(t("explain.total_layers", total=len(ir.expanded_layers)))
        click.echo()

        click.echo(t("presets.show.file_label", path=fpath))

    return presets


# Back-compat: some callers do `from eulerstack.cli.presets_cmd import presets`
def __getattr__(name):
    if name == "presets":
        return make_presets()
    raise AttributeError(name)
