"""Plugin registry for enterprise-grade runtime primitives.

The registry decouples core modeling from optional plugin packages.
Each registration maps a **kind string** (e.g. ``"ttt_layer"``,
``"neural_memory"``) to a **builder callable** that returns an
``nn.Module``. The modeling layer checks the registry at construction
time; if the kind is registered, it uses the plugin's module, otherwise
it falls back to the in-core default.

The registry is process-global via :func:`get_plugin_registry`. Plugin
packages register their builders at import time (``plugin_pkg/__init__.py``
should call the registry's ``register_*`` methods).

Why not use :mod:`eulerstack.registry`? That one holds class references
for block discovery. This one holds *builder callables* that accept
runtime kwargs (``d_model``, ``config``/``spec``) and return constructed
modules — the contract needed by ``EulerStackLayer`` during forward-path
assembly.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, Iterable

import torch.nn as nn

MixerBuilder = Callable[..., nn.Module]
MemoryBuilder = Callable[..., nn.Module]


class PluginRegistry:
    """Process-local registry mapping primitive kinds → builder callables."""

    def __init__(self) -> None:
        self._mixers: Dict[str, MixerBuilder] = {}
        self._memories: Dict[str, MemoryBuilder] = {}

    def register_mixer(
        self,
        kind: str,
        builder: MixerBuilder,
        *,
        exist_ok: bool = False,
    ) -> None:
        k = str(kind).strip()
        if not k:
            raise ValueError("mixer kind must be non-empty")
        if k in self._mixers and not exist_ok:
            raise KeyError(f"mixer kind '{k}' already registered")
        self._mixers[k] = builder

    def has_mixer(self, kind: str) -> bool:
        return str(kind).strip() in self._mixers

    def build_mixer(self, kind: str, **kwargs: Any) -> nn.Module:
        k = str(kind).strip()
        if k not in self._mixers:
            raise KeyError(f"mixer kind '{k}' not registered")
        return self._mixers[k](**kwargs)

    def mixer_kinds(self) -> Iterable[str]:
        return sorted(self._mixers.keys())

    def register_memory(
        self,
        kind: str,
        builder: MemoryBuilder,
        *,
        exist_ok: bool = False,
    ) -> None:
        k = str(kind).strip()
        if not k:
            raise ValueError("memory kind must be non-empty")
        if k in self._memories and not exist_ok:
            raise KeyError(f"memory kind '{k}' already registered")
        self._memories[k] = builder

    def has_memory(self, kind: str) -> bool:
        return str(kind).strip() in self._memories

    def build_memory(self, kind: str, **kwargs: Any) -> nn.Module:
        k = str(kind).strip()
        if k not in self._memories:
            raise KeyError(f"memory kind '{k}' not registered")
        return self._memories[k](**kwargs)

    def memory_kinds(self) -> Iterable[str]:
        return sorted(self._memories.keys())

    def clear(self) -> None:
        self._mixers.clear()
        self._memories.clear()


_GLOBAL_REGISTRY: PluginRegistry = PluginRegistry()


def get_plugin_registry() -> PluginRegistry:
    """Return the process-global plugin registry singleton."""
    return _GLOBAL_REGISTRY
