"""TTT (Test-Time Training) reference plugin.

Reference implementation of the real meta-learning loop for
``mixer.type: ttt_layer``. Sun et al. 2024, "Learning to (Learn at
Test Time): RNNs with Expressive Hidden States."

Importing this package registers a builder under ``ttt_layer`` in the
core plugin registry. The core modeling layer then picks up this
builder during construction and replaces the Mamba fallback with the
real TTTBlock.

Common-prompt §7: this plugin is optional. Core-only environments
behave as before (fallback to Mamba). Enterprise / research users who
need real test-time training simply ``import eulerstack.plugins.ttt``.
"""
from __future__ import annotations

from typing import Any, Dict

import torch.nn as nn

from eulerstack.plugins.registry import get_plugin_registry
from .block import TTTBlock


def _build_ttt_block(
    *,
    d_model: int,
    n_heads: int,
    dropout: float,
    config: Dict[str, Any],
) -> nn.Module:
    """Builder callable invoked by the plugin registry.

    The ``config`` payload is ``_v1_extras.ttt`` dict (the round-tripped
    compiler output) or an empty dict if the preset omitted the
    sub-object. See ``eulerstack.compiler.targets.huggingface``.
    """
    ttt_cfg = config.get("ttt", config) if isinstance(config, dict) else {}
    inner_model = ttt_cfg.get("inner_model", {}) or {}
    inner_type = str(inner_model.get("type", "mlp"))
    inner_hidden = int(inner_model.get("hidden", 32))
    inner_optimizer = str(ttt_cfg.get("inner_optimizer", "sgd"))
    inner_lr = float(ttt_cfg.get("inner_lr", 0.01))
    inner_steps = int(ttt_cfg.get("inner_steps_per_token", 1))
    return TTTBlock(
        d_model=d_model,
        n_heads=n_heads,
        inner_hidden=inner_hidden,
        inner_model_type=inner_type,
        inner_optimizer=inner_optimizer,
        inner_lr=inner_lr,
        inner_steps_per_token=inner_steps,
        dropout=dropout,
    )


# Register on import. The ``exist_ok=True`` guard makes repeat imports
# (e.g. pytest collection running the module twice) harmless.
get_plugin_registry().register_mixer(
    "ttt_layer",
    _build_ttt_block,
    exist_ok=True,
)

__all__ = ["TTTBlock"]
