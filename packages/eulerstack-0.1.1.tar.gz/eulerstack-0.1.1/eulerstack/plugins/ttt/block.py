"""Reference TTTBlock: an RNN whose hidden state is a small neural net.

Implements the core meta-learning loop of Sun et al. 2024. At each
token the inner network takes ``inner_steps_per_token`` gradient steps
minimising a self-supervised reconstruction loss (the *surprise*)
against the token's projected view; the inner network's output then
contributes to the block's output as a residual.

Key design choice (*functional fast weights*)
---------------------------------------------
During forward, we never modify the ``nn.Parameter`` of the inner
network in-place. Instead, we build a sequence of fast-weight
*tensors* starting from a detached copy of the persistent parameters,
and update those tensors via ``torch.autograd.grad``. The outer loss
still flows through the final fast-weights via the call
``inner_functional(q_outer, fast_weights)``, so outer backprop does
not trip the "tensor modified in-place between forward and backward"
guard.

At the end of the forward, when ``persist=True`` (the default), we
copy the last fast weights back into the persistent parameters with
``torch.no_grad()`` so the *next* forward starts from the evolved
state. This matches the per-sequence persistence used by the Titans
and TTT papers.
"""
from __future__ import annotations

from typing import Any, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class _InnerMLP(nn.Module):
    """Small MLP that *is* the recurrent state of the TTT layer."""

    def __init__(self, d_in: int, hidden: int, d_out: int) -> None:
        super().__init__()
        self.W1 = nn.Parameter(torch.empty(hidden, d_in))
        self.b1 = nn.Parameter(torch.zeros(hidden))
        self.W2 = nn.Parameter(torch.empty(d_out, hidden))
        self.b2 = nn.Parameter(torch.zeros(d_out))
        nn.init.kaiming_uniform_(self.W1, a=5 ** 0.5)
        nn.init.kaiming_uniform_(self.W2, a=5 ** 0.5)

    def functional_forward(
        self, x: torch.Tensor, weights: Tuple[torch.Tensor, ...]
    ) -> torch.Tensor:
        W1, b1, W2, b2 = weights
        h = F.linear(x, W1, b1)
        h = F.gelu(h)
        return F.linear(h, W2, b2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.functional_forward(x, (self.W1, self.b1, self.W2, self.b2))

    def weight_tuple(self) -> Tuple[torch.Tensor, ...]:
        return (self.W1, self.b1, self.W2, self.b2)


class _InnerLinear(nn.Module):
    """Linear baseline — the 'TTT-Linear' variant of the paper."""

    def __init__(self, d_in: int, d_out: int) -> None:
        super().__init__()
        self.W = nn.Parameter(torch.empty(d_out, d_in))
        self.b = nn.Parameter(torch.zeros(d_out))
        nn.init.kaiming_uniform_(self.W, a=5 ** 0.5)

    def functional_forward(
        self, x: torch.Tensor, weights: Tuple[torch.Tensor, ...]
    ) -> torch.Tensor:
        W, b = weights
        return F.linear(x, W, b)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.functional_forward(x, (self.W, self.b))

    def weight_tuple(self) -> Tuple[torch.Tensor, ...]:
        return (self.W, self.b)


class TTTBlock(nn.Module):
    """Test-Time Training block (plugin reference implementation).

    Forward shape: ``(B, T, D) → (B, T, D)``. Signature is
    attention-shaped to match core's ``_BackboneAdapter``; the extra
    kwargs are accepted but unused.
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        *,
        inner_hidden: int = 32,
        inner_model_type: str = "mlp",
        inner_optimizer: str = "sgd",
        inner_lr: float = 0.01,
        inner_steps_per_token: int = 1,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        if inner_steps_per_token < 0:
            raise ValueError("inner_steps_per_token must be >= 0")
        if inner_model_type not in ("mlp", "linear"):
            raise ValueError(
                f"inner_model_type must be 'mlp' or 'linear'; got {inner_model_type!r}"
            )
        if inner_optimizer not in ("sgd",):
            raise ValueError(
                f"inner_optimizer must be 'sgd' (got {inner_optimizer!r}); "
                f"use a richer plugin for adamw"
            )

        self.d_model = int(d_model)
        self.n_heads = int(n_heads)
        self.inner_hidden = int(inner_hidden)
        self.inner_model_type = inner_model_type
        self.inner_optimizer = inner_optimizer
        self.inner_lr = float(inner_lr)
        self.inner_steps_per_token = int(inner_steps_per_token)

        # Outer projections.
        self.in_proj = nn.Linear(self.d_model, self.d_model, bias=False)
        self.target_proj = nn.Linear(self.d_model, self.d_model, bias=False)
        self.out_proj = nn.Linear(self.d_model, self.d_model, bias=False)
        self.norm = nn.LayerNorm(self.d_model)
        self.drop = nn.Dropout(float(dropout))

        # Inner network — persistent parameters that carry the evolving
        # state across forward calls. During forward, we operate on
        # detached-clone fast weights to avoid autograd version conflicts.
        if inner_model_type == "mlp":
            self.inner_net: nn.Module = _InnerMLP(
                d_in=self.d_model, hidden=self.inner_hidden, d_out=self.d_model
            )
        else:
            self.inner_net = _InnerLinear(d_in=self.d_model, d_out=self.d_model)

        self.last_inner_state_trajectory: Optional[List[torch.Tensor]] = None

    def forward(
        self,
        x: torch.Tensor,
        *,
        attention_mask: Optional[torch.Tensor] = None,
        use_cache: bool = False,
        past_key_value: Optional[Any] = None,
        rope_cos: Optional[torch.Tensor] = None,
        rope_sin: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        output_aux: bool = False,
    ) -> Tuple[torch.Tensor, Optional[Any], Optional[dict]]:
        h = self.norm(x)
        q = self.in_proj(h)                          # outer-graph-connected
        target = self.target_proj(h)                 # outer-graph-connected

        B, T, D = q.shape

        # Fast weights: start from a detached clone of the persistent
        # inner parameters, then evolve per-token.
        persistent = self.inner_net.weight_tuple()
        fast: List[torch.Tensor] = [w.detach().clone() for w in persistent]

        # Trajectory snapshot for tests.
        trajectory: List[torch.Tensor] = [fast[0].detach().flatten()[:8].clone()]
        # Detach the inner-loss inputs — the inner update direction is
        # the only computed signal, not a gradient path back to x.
        q_det = q.detach()
        t_det = target.detach()

        outs: List[torch.Tensor] = []

        for tok in range(T):
            for _ in range(self.inner_steps_per_token):
                fast_rg = [w.detach().requires_grad_(True) for w in fast]
                pred_step = self.inner_net.functional_forward(
                    q_det[:, tok, :], tuple(fast_rg)
                )
                inner_loss = F.mse_loss(pred_step, t_det[:, tok, :])
                grads = torch.autograd.grad(
                    inner_loss, fast_rg, create_graph=False, retain_graph=False,
                )
                fast = [w - self.inner_lr * g for w, g in zip(fast_rg, grads)]
            # Outer forward: use the (just-updated) fast weights; gradient
            # flows to outer projections through q and to the fast-weight
            # tensors themselves (which carry no connection to persistent
            # params — that's handled by the end-of-forward copy_ below).
            out_tok = self.inner_net.functional_forward(
                q[:, tok, :], tuple(fast)
            )
            outs.append(out_tok)
            trajectory.append(fast[0].detach().flatten()[:8].clone())

        y = torch.stack(outs, dim=1)
        y = self.out_proj(y)
        y = self.drop(y)

        # Persist the evolved state back into the persistent parameters
        # so the next forward continues from here. Outer training will
        # re-initialise them from this snapshot, guided by the outer loss
        # via out_proj / in_proj / target_proj / norm / inner_net init.
        with torch.no_grad():
            for p, w in zip(persistent, fast):
                p.copy_(w.detach())

        self.last_inner_state_trajectory = trajectory
        return y, None, None

    def extra_repr(self) -> str:
        return (
            f"d_model={self.d_model}, n_heads={self.n_heads}, "
            f"inner_model={self.inner_model_type!r}, "
            f"inner_hidden={self.inner_hidden}, inner_lr={self.inner_lr}, "
            f"inner_steps_per_token={self.inner_steps_per_token}"
        )
