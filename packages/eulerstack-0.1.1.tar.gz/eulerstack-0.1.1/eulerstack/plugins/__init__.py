"""EulerStack plugin infrastructure.

Plugins extend the core runtime with enterprise-grade primitives (TTT
inner-optim, Titans memory, branched routing, ODE integrators, etc.).
Core ships fallback behavior; plugins upgrade the fallback to the real
implementation.

Common-prompt §7: plugin presence is optional. With plugins **absent**,
every core preset still compiles, trains, saves, and loads via
well-defined fallbacks. With plugins **present**, the registry is
populated and the modeling layer consults it during forward-path
construction.
"""
from .registry import PluginRegistry, get_plugin_registry

__all__ = ["PluginRegistry", "get_plugin_registry"]
