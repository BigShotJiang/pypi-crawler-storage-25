# eulerstack/assembler/export_hf.py
from __future__ import annotations

import json
import os
from dataclasses import asdict, is_dataclass
from typing import Any, Optional

import yaml

from eulerstack.hf.auto_register import register_eulerstack_auto_classes
from eulerstack.hf.configuration_eulerstack import EulerStackConfig
from eulerstack.hf.modeling_eulerstack import EulerStackForCausalLM
from eulerstack.spec.schema import EulerStackSpec


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def export_artifact(
    out_dir: str,
    *,
    spec: EulerStackSpec,
    config: EulerStackConfig,
    model: EulerStackForCausalLM,
    tokenizer: Optional[Any] = None,
    export_hf: bool = True,
    export_spec_yaml: bool = True,
) -> str:
    """
    Export a built model into an artifact directory.

    Writes (depending on flags):
    - HF-compatible: config.json + model weights via save_pretrained() [web:122]
    - model_spec.yaml: the original high-level assembly spec via yaml.safe_dump() [web:153]
    - model_spec.json: optional debug-friendly JSON (always written here)
    - tokenizer files if provided (tokenizer.save_pretrained)

    Additionally:
    - Ensures EulerStack is registered for AutoClasses so that save_pretrained can
      embed auto_map and copy custom code, enabling Auto* .from_pretrained(..., trust_remote_code=True). [web:702][web:145]
    """
    ensure_dir(out_dir)

    # Ensure custom model/config are properly prepared for AutoClasses + trust_remote_code packaging. [web:702]
    register_eulerstack_auto_classes(exist_ok=True)

    # 1) Always save the raw spec as JSON for debugging
    spec_json_path = os.path.join(out_dir, "model_spec.json")
    with open(spec_json_path, "w", encoding="utf-8") as f:
        json.dump(_to_jsonable(spec), f, ensure_ascii=False, indent=2)

    # 2) Optionally save YAML spec
    if export_spec_yaml:
        spec_yaml_path = os.path.join(out_dir, "model_spec.yaml")
        with open(spec_yaml_path, "w", encoding="utf-8") as f:
            yaml.safe_dump(_to_jsonable(spec), f, sort_keys=False, allow_unicode=True)  # [web:153]

    # 3) HF export (config + weights + (optional) tokenizer)
    if export_hf:
        # Prefer model.save_pretrained() to write config + weights consistently. [web:122]
        # Still okay if config.save_pretrained was called earlier; it will be overwritten.
        model.save_pretrained(out_dir)  # [web:122]

        # Some flows still want the config saved explicitly (harmless overwrite).
        # Keeping it for safety if future save_pretrained behavior changes.
        config.save_pretrained(out_dir)

        if tokenizer is not None:
            tokenizer.save_pretrained(out_dir)

    return out_dir


def export_from_yaml_build(
    out_dir: str,
    *,
    yaml_path: str,
    spec: EulerStackSpec,
    config: EulerStackConfig,
    model: EulerStackForCausalLM,
    tokenizer: Optional[Any] = None,
) -> str:
    """
    Convenience wrapper to keep traceability to the source YAML.
    Saves a copy of the input YAML into out_dir for provenance.
    """
    ensure_dir(out_dir)

    # Copy "source config" text for provenance
    if os.path.exists(yaml_path):
        with open(yaml_path, "r", encoding="utf-8") as f:
            src = f.read()
        with open(os.path.join(out_dir, "source_model.yml"), "w", encoding="utf-8") as f:
            f.write(src)

    return export_artifact(
        out_dir,
        spec=spec,
        config=config,
        model=model,
        tokenizer=tokenizer,
        export_hf=bool(getattr(spec.artifact, "export_hf", True)),
        export_spec_yaml=bool(getattr(spec.artifact, "export_spec_yaml", True)),
    )


def _to_jsonable(obj: Any) -> Any:
    """
    Convert dataclasses and nested structures into JSON/YAML-serializable objects.
    """
    if is_dataclass(obj):
        return {k: _to_jsonable(v) for k, v in asdict(obj).items()}
    if isinstance(obj, dict):
        return {str(k): _to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_jsonable(v) for v in obj]
    return obj
