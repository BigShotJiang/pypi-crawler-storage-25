from __future__ import annotations

from dataclasses import fields, is_dataclass
from difflib import get_close_matches
from typing import Any, Dict, List, Optional, Tuple, Type, TypeVar

import torch
import yaml

from eulerstack.hf.configuration_eulerstack import EulerStackConfig
from eulerstack.hf.modeling_eulerstack import EulerStackForCausalLM
from eulerstack.spec.schema import (
    ArtifactSpec,
    BlocksSpec,
    EulerStackSpec,
    HFSpec,
    KVCacheSpec,
    MemorySpec,
    MoESpec,
    PositionalSpec,
    RopeScalingSpec,
    RouterSpec,
    RoutingSpec,
    SSMStateSpec,
    ModelCoreSpec,
    StackItem,
    StackSpec,
    TokenizerSpec,
)
from eulerstack.spec.validate import validate_spec

T = TypeVar("T")


# -------------------------
# YAML -> dict
# -------------------------

def load_yaml(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ValueError("Root YAML must be a mapping/dict.")
    return data


# -------------------------
# Unknown key detection
# -------------------------

def _dc_field_names(dc_type: Type[Any]) -> List[str]:
    return [f.name for f in fields(dc_type)]


def _suggest_key(bad_key: str, allowed: List[str]) -> Optional[str]:
    # Suggest typo fixes using difflib.get_close_matches. [web:651]
    matches = get_close_matches(bad_key, allowed, n=1, cutoff=0.75)
    return matches[0] if matches else None


def _unknown_keys_error(path: str, unknown: List[str], allowed: List[str]) -> ValueError:
    lines = [f"{path}: unknown key(s): {', '.join(map(str, unknown))}"]
    for k in unknown:
        sug = _suggest_key(str(k), allowed)
        if sug:
            lines.append(f"{path}.{k}: did you mean '{sug}'?")
        else:
            preview = ", ".join(allowed[:12]) + ("..." if len(allowed) > 12 else "")
            lines.append(f"{path}.{k}: allowed keys include: {preview}")
    return ValueError("\n".join(lines))


def _validate_unknown_keys_dict(
    raw: Any,
    *,
    dc_type: Type[Any],
    path: str,
) -> None:
    """
    Validate unknown keys for a YAML mapping expected to match dataclass dc_type.
    Recurses into nested dataclasses we explicitly map in spec_from_yaml_dict.
    """
    if raw is None:
        return
    if not isinstance(raw, dict):
        raise ValueError(f"{path}: must be a mapping/dict (got {type(raw).__name__})")

    allowed = _dc_field_names(dc_type)
    allowed_set = set(allowed)

    unknown = [k for k in raw.keys() if k not in allowed_set]
    if unknown:
        raise _unknown_keys_error(path, [str(x) for x in unknown], allowed)

    # Recurse: only where we know the mapping is also a dataclass
    for f in fields(dc_type):
        name = f.name
        if name not in raw:
            continue
        if name == "extra":
            # explicit escape hatch
            continue

        val = raw[name]
        nested_type = f.type if hasattr(f.type, "__dataclass_fields__") else None
        if nested_type and isinstance(val, dict):
            _validate_unknown_keys_dict(val, dc_type=nested_type, path=f"{path}.{name}")

        # StackSpec special casing (pattern/tail list of StackItem)
        if dc_type is StackSpec and name in ("pattern", "tail") and isinstance(val, list):
            for i, it in enumerate(val):
                _validate_unknown_keys_dict(it, dc_type=StackItem, path=f"{path}.{name}[{i}]")


# ---- blocks.* allowlists (NEW) ----
# NOTE: blocks.* 하위는 현재 dataclass로 강제되지 않는 dict 기반이어서,
# 여기서 allowlist로 오타를 잡는다.
_BLOCKS_ALLOWED_KEYS: Dict[str, List[str]] = {
    "attn": [
        "qkv_bias",
        "attn_drop",
        "rope",
        "window",
        "local_window",
        "type",
    ],
    "mamba": [
        "variant",
        "ssm_dim",
        "conv_kernel",
        "d_state",      
        "d_conv",       
        "expand",
        "gating",
        "use_moe",
        "moe",
    ],
    "retnet": [
        "chunkwise",
        "chunk_size",
        "local_window",
        "rope",
        "use_moe",
        "moe",
    ],
    "hyena": [
        "depth",
        "filter_hidden",
        "filter_decay",
    ],
    "mlp": [
        "type",
        "bias",
    ],
}


def _validate_blocks_dict(blocks_raw: Any) -> None:
    if blocks_raw is None:
        return
    if not isinstance(blocks_raw, dict):
        raise ValueError(f"blocks: must be a mapping/dict (got {type(blocks_raw).__name__})")

    # First: blocks top-level keys are already validated against BlocksSpec via dataclass fields.
    # Second: validate known sub-blocks.
    for block_name, allowed_keys in _BLOCKS_ALLOWED_KEYS.items():
        sub = blocks_raw.get(block_name, None)
        if sub is None:
            continue
        if not isinstance(sub, dict):
            raise ValueError(f"blocks.{block_name}: must be a mapping/dict (got {type(sub).__name__})")
        unknown = [k for k in sub.keys() if k not in set(allowed_keys)]
        if unknown:
            raise _unknown_keys_error(f"blocks.{block_name}", [str(x) for x in unknown], allowed_keys)


def validate_yaml_against_schema(raw: Dict[str, Any]) -> None:
    """
    Top-level entry: validate YAML keys against EulerStackSpec schema + nested specs.
    Also validates blocks.* sub-dicts with allowlists.
    """
    _validate_unknown_keys_dict(raw, dc_type=EulerStackSpec, path="root")

    if isinstance(raw.get("artifact"), dict):
        _validate_unknown_keys_dict(raw["artifact"], dc_type=ArtifactSpec, path="artifact")
    if isinstance(raw.get("hf"), dict):
        _validate_unknown_keys_dict(raw["hf"], dc_type=HFSpec, path="hf")
    if isinstance(raw.get("tokenizer"), dict):
        _validate_unknown_keys_dict(raw["tokenizer"], dc_type=TokenizerSpec, path="tokenizer")

    if isinstance(raw.get("positional"), dict):
        _validate_unknown_keys_dict(raw["positional"], dc_type=PositionalSpec, path="positional")
        pos = raw["positional"]
        if isinstance(pos.get("scaling"), dict):
            _validate_unknown_keys_dict(pos["scaling"], dc_type=RopeScalingSpec, path="positional.scaling")

    if isinstance(raw.get("memory"), dict):
        _validate_unknown_keys_dict(raw["memory"], dc_type=MemorySpec, path="memory")
        mem = raw["memory"]
        if isinstance(mem.get("kv_cache"), dict):
            _validate_unknown_keys_dict(mem["kv_cache"], dc_type=KVCacheSpec, path="memory.kv_cache")
        if isinstance(mem.get("ssm_state"), dict):
            _validate_unknown_keys_dict(mem["ssm_state"], dc_type=SSMStateSpec, path="memory.ssm_state")

    if isinstance(raw.get("routing"), dict):
        _validate_unknown_keys_dict(raw["routing"], dc_type=RoutingSpec, path="routing")
        routing = raw["routing"]
        if isinstance(routing.get("moe"), dict):
            _validate_unknown_keys_dict(routing["moe"], dc_type=MoESpec, path="routing.moe")
            moe = routing["moe"]
            if isinstance(moe.get("router"), dict):
                _validate_unknown_keys_dict(moe["router"], dc_type=RouterSpec, path="routing.moe.router")

    if isinstance(raw.get("model"), dict):
        _validate_unknown_keys_dict(raw["model"], dc_type=ModelCoreSpec, path="model")
        model = raw["model"]
        if isinstance(model.get("stack"), dict):
            _validate_unknown_keys_dict(model["stack"], dc_type=StackSpec, path="model.stack")

    if isinstance(raw.get("blocks"), dict):
        _validate_unknown_keys_dict(raw["blocks"], dc_type=BlocksSpec, path="blocks")
        _validate_blocks_dict(raw["blocks"])


# -------------------------
# dict -> dataclass helpers
# -------------------------

def _pick(d: Dict[str, Any], key: str, default: Any) -> Any:
    v = d.get(key, default)
    return default if v is None else v


def _as_dict(x: Any) -> Dict[str, Any]:
    return x if isinstance(x, dict) else {}


def _build_dataclass(dc_type: Type[T], raw: Optional[Dict[str, Any]]) -> T:
    """
    Build a dataclass instance from a dict, recursively creating nested dataclasses when field types match.
    Unknown keys are validated earlier (validate_yaml_against_schema), so here we keep the builder simple.
    """
    if raw is None:
        raw = {}
    if not isinstance(raw, dict):
        raise ValueError(f"Expected dict for {dc_type.__name__}, got {type(raw)}")

    kwargs: Dict[str, Any] = {}
    for f in fields(dc_type):
        name = f.name
        if name not in raw:
            continue
        val = raw[name]

        if isinstance(val, dict) and hasattr(f.type, "__dataclass_fields__"):
            kwargs[name] = _build_dataclass(f.type, val)  # type: ignore[arg-type]
            continue

        if name in ("pattern", "tail") and isinstance(val, list):
            items: List[StackItem] = []
            for it in val:
                if not isinstance(it, dict):
                    raise ValueError(f"{dc_type.__name__}.{name} items must be dicts.")
                items.append(_build_dataclass(StackItem, it))
            kwargs[name] = items
            continue

        kwargs[name] = val

    return dc_type(**kwargs)  # type: ignore[misc]


def spec_from_yaml_dict(raw: Dict[str, Any]) -> EulerStackSpec:
    """
    Convert raw YAML dict into EulerStackSpec with nested dataclasses.
    Also validates unknown keys with typo suggestions (including blocks.* sub-keys).
    """
    validate_yaml_against_schema(raw)

    spec = EulerStackSpec(
        project=_pick(raw, "project", "eulerstack"),
        seed=int(_pick(raw, "seed", 1234)),
        artifact=_build_dataclass(ArtifactSpec, _as_dict(raw.get("artifact"))),
        hf=_build_dataclass(HFSpec, _as_dict(raw.get("hf"))),
        tokenizer=_build_dataclass(TokenizerSpec, _as_dict(raw.get("tokenizer"))),
        positional=_build_dataclass(PositionalSpec, _as_dict(raw.get("positional"))),
        memory=_build_dataclass(MemorySpec, _as_dict(raw.get("memory"))),
        routing=_build_dataclass(RoutingSpec, _as_dict(raw.get("routing"))),
        model=_build_dataclass(ModelCoreSpec, _as_dict(raw.get("model"))),
        blocks=_build_dataclass(BlocksSpec, _as_dict(raw.get("blocks"))),
        extra=_as_dict(raw.get("extra", {})),
    )

    # Nested optional types that need manual re-hydration:
    pos_raw = _as_dict(raw.get("positional"))
    scaling_raw = pos_raw.get("scaling")
    if isinstance(scaling_raw, dict):
        spec.positional.scaling = _build_dataclass(RopeScalingSpec, scaling_raw)

    mem_raw = _as_dict(raw.get("memory"))
    if isinstance(mem_raw.get("kv_cache"), dict):
        spec.memory.kv_cache = _build_dataclass(KVCacheSpec, mem_raw.get("kv_cache"))
    if isinstance(mem_raw.get("ssm_state"), dict):
        spec.memory.ssm_state = _build_dataclass(SSMStateSpec, mem_raw.get("ssm_state"))

    routing_raw = _as_dict(raw.get("routing"))
    if isinstance(routing_raw.get("moe"), dict):
        moe_raw = routing_raw.get("moe")
        spec.routing.moe = _build_dataclass(MoESpec, moe_raw)
        if isinstance(moe_raw.get("router"), dict):
            spec.routing.moe.router = _build_dataclass(RouterSpec, moe_raw.get("router"))

    model_raw = _as_dict(raw.get("model"))
    if isinstance(model_raw.get("stack"), dict):
        stack_raw = model_raw.get("stack")
        spec.model.stack = _build_dataclass(StackSpec, stack_raw)

    return spec


# -------------------------
# Spec -> HF config / model
# -------------------------

def _dataclass_to_dict(obj: Any) -> Dict[str, Any]:
    if obj is None:
        return {}
    if is_dataclass(obj):
        out: Dict[str, Any] = {}
        for f in fields(obj):
            out[f.name] = _dataclass_to_dict(getattr(obj, f.name))
        return out
    if isinstance(obj, dict):
        return {k: _dataclass_to_dict(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_dataclass_to_dict(v) for v in obj]
    return obj

def hf_config_from_spec(spec: EulerStackSpec) -> EulerStackConfig:
    validate_spec(spec)

    cfg = EulerStackConfig(
        vocab_size=spec.model.vocab_size,
        max_seq_len=spec.model.max_seq_len,
        d_model=spec.model.d_model,
        n_layers=spec.model.n_layers,
        n_heads=spec.model.n_heads,
        mlp_ratio=spec.model.mlp_ratio,
        norm=spec.model.norm,
        dropout=spec.model.dropout,
        use_cache=bool(getattr(spec.model, "use_cache", True)),  # <-- 추가

        tokenizer=_dataclass_to_dict(spec.tokenizer),
        positional=_dataclass_to_dict(spec.positional),
        memory=_dataclass_to_dict(spec.memory),
        routing=_dataclass_to_dict(spec.routing),
        stack=_dataclass_to_dict(spec.model.stack),
        blocks=_dataclass_to_dict(spec.blocks),

        tie_word_embeddings=spec.artifact.tie_word_embeddings,
        torch_dtype=spec.hf.torch_dtype,
    )
    return cfg



def build_model_from_spec(spec: EulerStackSpec) -> EulerStackForCausalLM:
    torch.manual_seed(int(spec.seed))
    cfg = hf_config_from_spec(spec)
    return EulerStackForCausalLM(cfg)


def build_from_yaml(yaml_path: str) -> Tuple[EulerStackSpec, EulerStackConfig, EulerStackForCausalLM]:
    raw = load_yaml(yaml_path)
    spec = spec_from_yaml_dict(raw)

    cfg = hf_config_from_spec(spec)
    torch.manual_seed(int(spec.seed))
    model = EulerStackForCausalLM(cfg)
    return spec, cfg, model
