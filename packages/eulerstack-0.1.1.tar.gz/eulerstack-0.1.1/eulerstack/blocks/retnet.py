# eulerstack/blocks/retnet.py
from __future__ import annotations

from typing import Any, Dict, Optional, Tuple, Union

import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from eulerstack.blocks.mlp import build_mlp
from eulerstack.blocks.norms import get_norm
from eulerstack.components.positional import apply_rope


# RetNet cache:
#   past_key_value = (state_num, state_den, past_len)
#     state_num: (B, H, D, D)   accumulates k^T v
#     state_den: (B, H, D)      accumulates k (normalizer term)
#     past_len: int (python int) or 0-dim tensor
RetNetPast = Optional[Tuple[torch.Tensor, torch.Tensor, int]]


def _build_decay_gammas(num_heads: int, *, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
    # head-wise gamma in (0,1)
    idx = torch.linspace(0.0, 1.0, steps=num_heads, device=device, dtype=dtype)
    gammas = 1.0 - 10.0 ** (-2.0 - 3.0 * idx)
    return gammas.clamp(0.0, 1.0)


def _as_int(x: Any) -> int:
    if x is None:
        return 0
    if isinstance(x, int):
        return x
    if torch.is_tensor(x):
        return int(x.item())
    raise TypeError(f"Cannot convert {type(x)} to int")


def _causal_decay_matrix(n: int, gammas: torch.Tensor, *, dtype: torch.dtype, device: torch.device) -> torch.Tensor:
    """
    Returns (1, H, N, N) matrix M where M[..., i, j] = gamma^(i-j) if j<=i else 0.
    """
    qi = torch.arange(n, device=device)
    kj = torch.arange(n, device=device)
    # pow() is computed in float32 to avoid bfloat16 precision loss on decay
    dist = (qi[:, None] - kj[None, :]).clamp_min(0).float()
    allowed = (kj[None, :] <= qi[:, None])
    decay = gammas.float().view(-1, 1, 1).pow(dist.view(1, n, n))
    decay = decay * allowed.view(1, n, n).float()
    return decay.unsqueeze(0).to(dtype=dtype)


def retention_step(
    q_t: torch.Tensor,  # (B,H,D)
    k_t: torch.Tensor,  # (B,H,D)
    v_t: torch.Tensor,  # (B,H,D)
    state_num: Optional[torch.Tensor],  # (B,H,D,D)
    state_den: Optional[torch.Tensor],  # (B,H,D)
    gammas: torch.Tensor,              # (H,)
    eps: float = 1e-6,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    Normalized recurrent retention step.

    num_t = gamma * num_{t-1} + k_t^T v_t
    den_t = gamma * den_{t-1} + k_t
    out_t = (q_t @ num_t) / (q_t @ den_t + eps)

    This design makes parallel/chunkwise/recurrent exactly match (up to fp error). [web:99][web:98]
    """
    b, h, d = q_t.shape

    kv = k_t.unsqueeze(-1) * v_t.unsqueeze(-2)  # (B,H,D,D)

    if state_num is None:
        num = kv
        den = k_t
    else:
        g = gammas.view(1, h, 1, 1)
        num = kv + state_num * g
        den = k_t + state_den * gammas.view(1, h, 1)

    out_num = torch.einsum("bhd,bhde->bhe", q_t, num)  # (B,H,D)
    out_den = torch.einsum("bhd,bhd->bh", q_t, den).unsqueeze(-1)  # (B,H,1)
    out = out_num / out_den.clamp_min(eps)  # (B,H,D) — clamp for backward stability

    return out, num, den


def retention_chunk(
    q: torch.Tensor,  # (B,H,N,D)
    k: torch.Tensor,  # (B,H,N,D)
    v: torch.Tensor,  # (B,H,N,D)
    state_num: Optional[torch.Tensor],  # (B,H,D,D)
    state_den: Optional[torch.Tensor],  # (B,H,D)
    gammas: torch.Tensor,               # (H,)
    eps: float = 1e-6,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    Chunkwise normalized retention that is algebraically consistent with the recurrent step. [web:99][web:98]
    """
    b, h, n, d = q.shape
    device = q.device
    dtype = q.dtype

    # Intra-chunk causal decay matrix
    M = _causal_decay_matrix(n, gammas, dtype=dtype, device=device)  # (1,H,N,N)

    # Intra-chunk numerator: (q @ (M*(k^T v)))  -> compute as:
    # weights_ij = (q_i · k_j) * gamma^(i-j)
    sim = torch.matmul(q, k.transpose(-1, -2)) * M  # (B,H,N,N)
    intra_num = torch.matmul(sim, v)  # (B,H,N,D)

    # Intra-chunk denominator: (q_i · sum_j gamma^(i-j) k_j)
    intra_den_vec = torch.matmul(M, k)  # (B,H,N,D)  (sum_j gamma^(i-j) k_j)
    intra_den = torch.einsum("bhnd,bhnd->bhn", q, intra_den_vec).unsqueeze(-1)  # (B,H,N,1)

    # Cross-chunk contribution from previous states:
    if state_num is not None:
        # each position i sees prev_state decayed by gamma^(i+1)
        pos = torch.arange(1, n + 1, device=device, dtype=dtype)  # (N,)
        gpow = gammas.view(1, h, 1, 1).pow(pos.view(1, 1, n, 1))  # (1,H,N,1)

        cross_num = torch.einsum("bhnd,bhde->bhne", q, state_num) * gpow  # (B,H,N,D)
        cross_den = torch.einsum("bhnd,bhd->bhn", q, state_den) * gpow.squeeze(-1)  # (B,H,N)
        cross_den = cross_den.unsqueeze(-1)  # (B,H,N,1)

        out_num = intra_num + cross_num
        out_den = intra_den + cross_den
    else:
        out_num = intra_num
        out_den = intra_den

    # Defense-in-depth: even with positive-feature-map Q/K, clamp denominator ≥ eps
    # to prevent division-by-zero in edge cases (e.g., all-zero K after masking).
    out = out_num / out_den.clamp_min(eps)  # (B,H,N,D)

    # Update states at end of chunk:
    # num_end = sum_i gamma^(n-1-i) k_i^T v_i + gamma^n * prev_num
    # den_end = sum_i gamma^(n-1-i) k_i     + gamma^n * prev_den
    wpos = torch.arange(n - 1, -1, -1, device=device, dtype=dtype)  # (N,) n-1..0
    g_w = gammas.view(1, h, 1, 1).pow(wpos.view(1, 1, n, 1))  # (1,H,N,1)

    kv = k.unsqueeze(-1) * v.unsqueeze(-2)  # (B,H,N,D,D)
    num_chunk = (kv * g_w.unsqueeze(-2)).sum(dim=2)  # (B,H,D,D)
    den_chunk = (k * g_w).sum(dim=2)  # (B,H,D)

    if state_num is None:
        new_num = num_chunk
        new_den = den_chunk
    else:
        gn = gammas.view(1, h, 1, 1).pow(n)
        new_num = num_chunk + state_num * gn
        new_den = den_chunk + state_den * gammas.view(1, h, 1).pow(n)

    return out, new_num, new_den


class MultiScaleRetention(nn.Module):
    """
    Normalized Retention with consistent parallel/chunkwise/recurrent modes.

    - use_cache=True: recurrent if t==1 else chunkwise (optionally chunk-split)
    - use_cache=False: also uses chunkwise to ensure exact equivalence with cached path
      (you can add an explicit parallel(T^2) fast path later, but it must match this math).
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        *,
        dropout: float = 0.0,
        qkv_bias: bool = False,
        rope: bool = False,
        chunk_size: int = 512,
        chunkwise: bool = True,
        eps: float = 1e-6,
    ):
        super().__init__()
        if d_model % n_heads != 0:
            raise ValueError("d_model must be divisible by n_heads")

        self.d_model = int(d_model)
        self.n_heads = int(n_heads)
        self.head_dim = self.d_model // self.n_heads

        self.qkv = nn.Linear(self.d_model, 3 * self.d_model, bias=bool(qkv_bias))
        self.proj = nn.Linear(self.d_model, self.d_model, bias=True)

        self.dropout = float(dropout)
        self.use_rope = bool(rope)

        self.chunkwise = bool(chunkwise)
        self.chunk_size = int(chunk_size)
        self.eps = max(float(eps), 1e-4)


    def forward(
        self,
        x: torch.Tensor,
        *,
        attention_mask: Optional[torch.Tensor] = None,  # may be (B, S_total) during generate
        use_cache: bool = False,
        past_key_value: RetNetPast = None,
        rope_cos: Optional[torch.Tensor] = None,
        rope_sin: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        **_: Any,
    ) -> Tuple[torch.Tensor, RetNetPast]:
        b, t, _ = x.shape
        qkv = self.qkv(x)
        q, k, v = qkv.chunk(3, dim=-1)

        q = q.view(b, t, self.n_heads, self.head_dim).transpose(1, 2)  # (B,H,T,D)
        k = k.view(b, t, self.n_heads, self.head_dim).transpose(1, 2)
        v = v.view(b, t, self.n_heads, self.head_dim).transpose(1, 2)

        if self.use_rope:
            if rope_cos is None or rope_sin is None:
                raise ValueError("RoPE enabled but rope_cos/rope_sin not provided")
            q = apply_rope(q, rope_cos, rope_sin, position_ids=position_ids)
            k = apply_rope(k, rope_cos, rope_sin, position_ids=position_ids)

        # Positive feature map (Katharopoulos et al. 2020, "Transformers are RNNs"):
        # phi(x) = elu(x) + 1 ensures q, k > 0 so that the retention denominator
        # q · (decayed k) is strictly positive. Without this, signed Q·K can produce
        # denominators near zero, and backward through (num / den) explodes to NaN
        # (especially under bfloat16 AMP, as observed in arch_e2e with 32-layer stacks).
        q = F.elu(q) + 1.0
        k = F.elu(k) + 1.0

        # Scale Q by 1/√head_dim to keep the numerator magnitude well-conditioned.
        scale = self.head_dim ** -0.5
        q = q * scale

        gammas = _build_decay_gammas(self.n_heads, device=x.device, dtype=q.dtype)

        state_num: Optional[torch.Tensor] = None
        state_den: Optional[torch.Tensor] = None
        prev_len: int = 0

        if past_key_value is not None:
            if not isinstance(past_key_value, (tuple, list)):
                raise ValueError(f"Unexpected RetNet past_key_value type: {type(past_key_value)}")

            if len(past_key_value) == 3:
                state_num, state_den, prev_len = past_key_value
                prev_len = _as_int(prev_len)

            elif len(past_key_value) == 2:
                state_num, prev_len = past_key_value  # type: ignore[misc]
                prev_len = _as_int(prev_len)

                if state_num is None:
                    state_num = None
                    state_den = None
                else:
                    if not torch.is_tensor(state_num):
                        raise ValueError("RetNet legacy cache expected tensor state_num or None.")
                    state_den = torch.zeros(
                        (state_num.size(0), state_num.size(1), state_num.size(2)),
                        device=state_num.device,
                        dtype=state_num.dtype,
                    )
            else:
                raise ValueError(f"Unexpected RetNet past_key_value tuple length: {len(past_key_value)}")

        # Fix for generate(): attention_mask is often (B, S_total) while current x is (B, t, C) with t=1. [web:16]
        if attention_mask is not None:
            if attention_mask.dim() != 2:
                raise ValueError("RetNet attention_mask must be (B, S).")
            if attention_mask.size(0) != b:
                raise ValueError("attention_mask batch must match x batch.")
            if attention_mask.size(1) < t:
                raise ValueError("attention_mask length must be >= current sequence length.")

            keep_last = attention_mask[:, -t:].to(dtype=q.dtype)  # (B, t)
            keep_last = keep_last.view(b, 1, t, 1)               # (B,1,t,1)
            k = k * keep_last
            v = v * keep_last

        if use_cache and t == 1:
            y, new_num, new_den = retention_step(
                q[:, :, 0, :],
                k[:, :, 0, :],
                v[:, :, 0, :],
                state_num,
                state_den,
                gammas,
                eps=self.eps,
            )
            y = y.unsqueeze(2)  # (B,H,1,D)
        else:
            if self.chunkwise and self.chunk_size > 0 and t > self.chunk_size:
                outs = []
                num = state_num
                den = state_den
                start = 0
                while start < t:
                    end = min(start + self.chunk_size, t)
                    y_chunk, num, den = retention_chunk(
                        q[:, :, start:end, :],
                        k[:, :, start:end, :],
                        v[:, :, start:end, :],
                        num,
                        den,
                        gammas,
                        eps=self.eps,
                    )
                    outs.append(y_chunk)
                    start = end
                y = torch.cat(outs, dim=2)
                new_num, new_den = num, den
            else:
                y, new_num, new_den = retention_chunk(q, k, v, state_num, state_den, gammas, eps=self.eps)

        new_past: RetNetPast = (new_num, new_den, prev_len + t) if use_cache else None

        out = y.transpose(1, 2).contiguous().view(b, t, self.d_model)
        out = self.proj(out)
        out = F.dropout(out, p=self.dropout, training=self.training)
        return out, new_past


class RetNetBlock(nn.Module):
    """
    RetNet block:
      x = x + Retention(Norm(x))
      x = x + MLP(Norm(x))

    output_aux is accepted for API compatibility (returns empty dict).
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        *,
        norm: str = "rmsnorm",
        dropout: float = 0.0,
        attn_drop: float = 0.0,  # unused (compat)
        qkv_bias: bool = False,
        chunkwise: bool = True,
        chunk_size: int = 512,
        mlp_ratio: int = 4,
        mlp_type: str = "swiglu",
        mlp_bias: bool = False,
        local_window: Optional[int] = None,  # unused (compat)
        rope: bool = False,
        use_moe: bool = False,
        moe: Optional[Dict[str, Any]] = None,
        **_: Any,
    ):
        super().__init__()
        self.d_model = int(d_model)
        self.n_heads = int(n_heads)

        self.norm1 = get_norm(norm, self.d_model)
        self.norm2 = get_norm(norm, self.d_model)

        self.backbone = MultiScaleRetention(
            d_model=self.d_model,
            n_heads=self.n_heads,
            dropout=dropout,
            qkv_bias=qkv_bias,
            rope=rope,
            chunkwise=bool(chunkwise),
            chunk_size=int(chunk_size),
        )

        self.use_moe = bool(use_moe)
        if self.use_moe:
            from eulerstack.blocks.moe import MoEFFN
            moe = moe or {}
            self.moe_ffn = MoEFFN(
                d_model=self.d_model,
                experts=int(moe.get("experts", 8)),
                top_k=int(moe.get("top_k", 2)),
                mlp_ratio=int(moe.get("mlp_ratio", mlp_ratio)),
                router=str(moe.get("router", moe.get("router_type", "softmax"))),
                z_loss=float(moe.get("z_loss", 0.001)),
                load_balance_coef=float(moe.get("load_balance_coef", 0.01)),
                dropout=float(dropout),
                bias=bool(mlp_bias),
                mlp_type=str(moe.get("mlp_type", mlp_type)),
            )
            self.mlp = None
        else:
            self.moe_ffn = None
            self.mlp = build_mlp(
                mlp_type,
                d_model=self.d_model,
                mlp_ratio=int(mlp_ratio),
                dropout=float(dropout),
                bias=bool(mlp_bias),
            )

    def forward(
        self,
        x: torch.Tensor,
        *,
        attention_mask: Optional[torch.Tensor] = None,
        use_cache: bool = False,
        past_key_value: RetNetPast = None,
        rope_cos: Optional[torch.Tensor] = None,
        rope_sin: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        output_aux: bool = False,
        **kwargs: Any,
    ) -> Union[
        Tuple[torch.Tensor, RetNetPast],
        Tuple[torch.Tensor, RetNetPast, Dict[str, torch.Tensor]],
    ]:
        residual = x
        h = self.norm1(x)
        h, new_past = self.backbone(
            h,
            attention_mask=attention_mask,
            use_cache=use_cache,
            past_key_value=past_key_value,
            rope_cos=rope_cos,
            rope_sin=rope_sin,
            position_ids=position_ids,
        )
        x = residual + h

        residual = x
        h = self.norm2(x)
        moe_aux: Dict[str, torch.Tensor] = {}
        if self.use_moe and self.moe_ffn is not None:
            if output_aux:
                h, moe_aux = self.moe_ffn(h, output_aux=True)
            else:
                h = self.moe_ffn(h)
        else:
            assert self.mlp is not None
            h = self.mlp(h)
        x = residual + h

        if output_aux:
            return x, new_past, moe_aux

        return x, new_past
