# eulerstack/blocks/mlp.py
from __future__ import annotations

from typing import Literal, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


MLPType = Literal["mlp", "swiglu"]


class MLP(nn.Module):
    """
    Standard 2-layer FFN: Linear -> SiLU -> Dropout -> Linear.
    """

    def __init__(
        self,
        d_model: int,
        hidden_dim: Optional[int] = None,
        mlp_ratio: int = 4,
        dropout: float = 0.0,
        bias: bool = True,
    ):
        super().__init__()
        hidden = int(hidden_dim) if hidden_dim is not None else int(d_model * mlp_ratio)
        self.fc1 = nn.Linear(d_model, hidden, bias=bias)
        self.act = nn.SiLU()  # [web:344]
        self.drop = nn.Dropout(dropout)
        self.fc2 = nn.Linear(hidden, d_model, bias=bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        return x


class SwiGLU(nn.Module):
    """
    SwiGLU FFN:
      gate = SiLU(Wg x)
      up   = Wu x
      out  = Wo (gate * up)

    This is a commonly used gated FFN variant in modern LMs. [web:344]
    """

    def __init__(
        self,
        d_model: int,
        hidden_dim: Optional[int] = None,
        mlp_ratio: int = 4,
        dropout: float = 0.0,
        bias: bool = False,
    ):
        super().__init__()
        hidden = int(hidden_dim) if hidden_dim is not None else int(d_model * mlp_ratio)

        self.wg = nn.Linear(d_model, hidden, bias=bias)
        self.wu = nn.Linear(d_model, hidden, bias=bias)
        self.wo = nn.Linear(hidden, d_model, bias=bias)
        self.drop = nn.Dropout(dropout)
        self.act = nn.SiLU()  # [web:344]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        gate = self.act(self.wg(x))
        up = self.wu(x)
        x = gate * up
        x = self.drop(x)
        x = self.wo(x)
        return x


def build_mlp(
    mlp_type: MLPType,
    *,
    d_model: int,
    hidden_dim: Optional[int] = None,
    mlp_ratio: int = 4,
    dropout: float = 0.0,
    bias: bool = True,
    moe_config: Optional[dict] = None,
) -> nn.Module:
    """Build the per-layer channel-mixing MLP.

    ``mlp_type`` dispatches to one of:

    * ``"mlp"``       — dense 2-layer MLP (GeLU)
    * ``"swiglu"``    — dense SwiGLU (gate · up → down)
    * ``"gated_mlp"`` — alias for swiglu (preset YAMLs use this spelling)
    * ``"moe"``       — top-k Mixture-of-Experts; requires ``moe_config``
                        with at least ``experts`` and ``top_k``. Optional
                        keys: ``router``, ``z_loss``, ``capacity_factor``,
                        ``load_balance_coef``, ``mlp_type``
                        (base expert type, default swiglu).
    """
    mlp_type = str(mlp_type).lower()
    if mlp_type == "mlp":
        return MLP(d_model, hidden_dim=hidden_dim, mlp_ratio=mlp_ratio,
                   dropout=dropout, bias=bias)
    if mlp_type in ("swiglu", "gated_mlp"):
        return SwiGLU(d_model, hidden_dim=hidden_dim, mlp_ratio=mlp_ratio,
                      dropout=dropout, bias=bias)
    if mlp_type == "moe":
        if not isinstance(moe_config, dict) or \
           "experts" not in moe_config or "top_k" not in moe_config:
            raise ValueError(
                "build_mlp('moe', ...) requires moe_config with at least "
                "'experts' and 'top_k' keys"
            )
        from eulerstack.blocks.moe import MoEFFN
        return MoEFFN(
            d_model=d_model,
            experts=int(moe_config["experts"]),
            top_k=int(moe_config["top_k"]),
            mlp_ratio=int(mlp_ratio),
            router=str(moe_config.get("router", "softmax")),
            z_loss=float(moe_config.get("z_loss", 0.001)),
            load_balance_coef=float(
                moe_config.get("load_balance_coef",
                               # Mixtral-style default; capacity_factor is
                               # not a loss coefficient but surfaces here in
                               # existing config dumps — we ignore it at
                               # this layer and let it drive future dispatch
                               # capacity logic.
                               0.01)
            ),
            dropout=float(dropout),
            bias=bool(bias),
            mlp_type=str(moe_config.get("expert_mlp_type", "swiglu")),
        )
    raise ValueError(f"Unknown mlp_type: {mlp_type}")
