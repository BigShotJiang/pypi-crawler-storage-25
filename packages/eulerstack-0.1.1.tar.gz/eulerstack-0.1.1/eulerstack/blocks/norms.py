# eulerstack/blocks/norms.py
from __future__ import annotations

from typing import Literal

import torch
import torch.nn as nn


NormType = Literal["rmsnorm", "layernorm"]


class RMSNorm(nn.Module):
    """
    Minimal RMSNorm implementation.

    Note:
    - PyTorch provides nn.RMSNorm. This wrapper exists to keep behavior stable across versions
      and to allow custom eps defaults if needed. [web:324]
    """

    def __init__(self, d_model: int, eps: float = 1e-6, elementwise_affine: bool = True):
        super().__init__()
        self.eps = eps
        self.elementwise_affine = elementwise_affine
        if elementwise_affine:
            self.weight = nn.Parameter(torch.ones(d_model))
        else:
            self.register_parameter("weight", None)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (..., d_model)
        var = x.pow(2).mean(dim=-1, keepdim=True)
        x = x * torch.rsqrt(var + self.eps)
        if self.weight is not None:
            x = x * self.weight
        return x


def get_norm(norm: NormType, d_model: int, eps: float = 1e-6) -> nn.Module:
    """
    Factory for normalization layers.
    - rmsnorm: RMS normalization (common in modern decoder LMs) [web:324]
    - layernorm: standard LayerNorm [web:329]
    """
    norm = str(norm).lower()
    if norm == "rmsnorm":
        # If you prefer the built-in, swap to: return nn.RMSNorm(d_model, eps=eps)
        return RMSNorm(d_model, eps=eps)
    if norm == "layernorm":
        return nn.LayerNorm(d_model, eps=eps)  # [web:329]
    raise ValueError(f"Unknown norm type: {norm}")
