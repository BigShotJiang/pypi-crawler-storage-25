from __future__ import annotations

from typing import Any, Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from eulerstack.blocks.mlp import build_mlp
from eulerstack.blocks.norms import get_norm


class HyenaFilter(nn.Module):
    """
    Implicit long convolution filter generator (scaffold).

    Given sequence length T, generate a causal filter h[t] for t=0..T-1.
    This is a lightweight, unoptimized version intended for early plumbing.
    """

    def __init__(
        self,
        channels: int,
        hidden: int = 64,
        *,
        use_sin: bool = True,
        decay: float = 0.0,
    ):
        super().__init__()
        self.channels = int(channels)
        self.use_sin = bool(use_sin)
        self.decay = float(decay)

        self.fc1 = nn.Linear(1, hidden, bias=True)
        self.fc2 = nn.Linear(hidden, channels, bias=False)

    def forward(self, seq_len: int, *, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
        t = torch.linspace(0.0, 1.0, steps=seq_len, device=device, dtype=dtype).unsqueeze(-1)  # (T, 1)
        x = self.fc1(t)
        x = torch.sin(x) if self.use_sin else F.silu(x)
        h = self.fc2(x)  # (T, C)

        if self.decay > 0:
            idx = torch.arange(seq_len, device=device, dtype=dtype)
            w = torch.exp(-self.decay * idx).unsqueeze(-1)  # (T, 1)
            h = h * w

        return h


def fft_causal_conv1d(x: torch.Tensor, h: torch.Tensor) -> torch.Tensor:
    """
    Depthwise causal convolution via FFT (scaffold).

    Args:
      x: (B, T, C)
      h: (T, C) causal filter (t>=0)

    Returns:
      y: (B, T, C)
    """
    b, t, c = x.shape
    if h.shape != (t, c):
        raise ValueError(f"Filter must have shape (T,C)=({t},{c}), got {tuple(h.shape)}")

    n = 2 * t
    # FFT does not support bfloat16 — cast to float32 for the convolution
    orig_dtype = x.dtype
    if orig_dtype == torch.bfloat16 or orig_dtype == torch.float16:
        x = x.float()
        h = h.float()
    x_f = torch.fft.rfft(x, n=n, dim=1)          # (B, F, C)
    h_f = torch.fft.rfft(h, n=n, dim=0)          # (F, C)
    y_f = x_f * h_f.unsqueeze(0)                 # (B, F, C)
    y = torch.fft.irfft(y_f, n=n, dim=1)         # (B, 2T, C)
    y = y[:, :t, :]
    if orig_dtype != y.dtype:
        y = y.to(orig_dtype)
    return y


class HyenaOperator(nn.Module):
    """
    Hyena-like operator (scaffold):
    - Project input into (depth + 1) streams
    - Recurrently apply: v = gate_i * LongConv(v)
    """

    def __init__(
        self,
        d_model: int,
        *,
        depth: int = 2,
        filter_hidden: int = 64,
        filter_decay: float = 0.0,
        dropout: float = 0.0,
    ):
        super().__init__()
        self.d_model = int(d_model)
        self.depth = int(depth)
        if self.depth <= 0:
            raise ValueError("depth must be >= 1")

        self.proj_in = nn.Linear(d_model, (self.depth + 1) * d_model, bias=True)
        self.filter = HyenaFilter(d_model, hidden=filter_hidden, decay=filter_decay)
        self.proj_out = nn.Linear(d_model, d_model, bias=True)
        self.drop = nn.Dropout(float(dropout))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, t, c = x.shape
        z = self.proj_in(x)  # (B, T, (depth+1)C)
        z = z.view(b, t, self.depth + 1, c)

        v = z[:, :, 0, :]  # (B, T, C)
        h = self.filter(t, device=x.device, dtype=x.dtype)  # (T, C)

        for i in range(self.depth):
            gate = z[:, :, i + 1, :]
            v = gate * fft_causal_conv1d(v, h)

        v = self.proj_out(v)
        v = self.drop(v)
        return v


class HyenaBlock(nn.Module):
    """
    Full Hyena block (scaffold):
      x = x + HyenaOperator(Norm(x))
      x = x + MLP(Norm(x))

    output_aux is accepted for API compatibility (ignored). [web:726]
    """

    def __init__(
        self,
        d_model: int,
        *,
        norm: str = "rmsnorm",
        dropout: float = 0.0,
        mlp_ratio: int = 4,
        mlp_type: str = "swiglu",
        depth: int = 2,
        filter_hidden: int = 64,
        filter_decay: float = 0.0,
        use_moe: bool = False,
        moe: Optional[Dict[str, Any]] = None,
        **_: Any,
    ):
        super().__init__()
        self.d_model = int(d_model)
        self.norm1 = get_norm(norm, self.d_model)
        self.norm2 = get_norm(norm, self.d_model)

        self.hyena = HyenaOperator(
            d_model=self.d_model,
            depth=int(depth),
            filter_hidden=int(filter_hidden),
            filter_decay=float(filter_decay),
            dropout=float(dropout),
        )

        self.use_moe = bool(use_moe)
        if self.use_moe:
            from eulerstack.blocks.moe import MoEFFN
            moe = moe or {}
            self.moe_ffn = MoEFFN(
                d_model=self.d_model,
                experts=int(moe.get("experts", 8)),
                top_k=int(moe.get("top_k", 2)),
                mlp_ratio=int(moe.get("mlp_ratio", mlp_ratio)),
                router=str(moe.get("router", moe.get("router_type", "softmax"))),
                z_loss=float(moe.get("z_loss", 0.001)),
                load_balance_coef=float(moe.get("load_balance_coef", 0.01)),
                dropout=float(dropout),
                bias=False,
                mlp_type=str(moe.get("mlp_type", mlp_type)),
            )
            self.mlp = None
        else:
            self.moe_ffn = None
            self.mlp = build_mlp(
                mlp_type,
                d_model=self.d_model,
                mlp_ratio=int(mlp_ratio),
                dropout=float(dropout),
                bias=False,
            )

    def forward(
        self,
        x: torch.Tensor,
        *,
        attention_mask: Optional[torch.Tensor] = None,
        use_cache: bool = False,
        past_key_value: Optional[Any] = None,
        rope_cos: Optional[torch.Tensor] = None,
        rope_sin: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        output_aux: bool = False,
        **kwargs: Any,
    ):
        # 현재 Hyena는 attention_mask/rope/past를 실제 연산에 쓰지 않음(placeholder cache).
        # 단, generate(use_cache=True) 플로우 호환을 위해 past를 그대로 전달/갱신하는 인터페이스를 제공. [web:16]
        y = x + self.hyena(self.norm1(x))
        moe_aux: Dict[str, torch.Tensor] = {}
        if self.use_moe and self.moe_ffn is not None:
            h = self.norm2(y)
            if output_aux:
                delta, moe_aux = self.moe_ffn(h, output_aux=True)
            else:
                delta = self.moe_ffn(h)
            y = y + delta
        else:
            assert self.mlp is not None
            y = y + self.mlp(self.norm2(y))

        new_past = past_key_value
        if use_cache:
            # "past"가 None이면 더미 토큰 카운터라도 넣어두면 추후 실제 cache로 확장하기 쉬움
            # (지금은 EulerStackModel._infer_past_len이 KV/RetNet 위주라 Hyena past_len 추론은 하지 않음)
            if new_past is None:
                new_past = {"past_len": int(x.size(1))}

        if output_aux:
            return y, new_past, moe_aux

        return y, new_past
