"""Mixture-of-Experts FFN — the runtime the v1 preset family declares.

Before this module, ``ffn.type: moe`` declarations round-tripped through
``config.json`` but the runtime silently reverted to dense SwiGLU — the
``build_mlp`` dispatcher only knew ``mlp`` / ``swiglu`` and the layer
forward could not carry the ``(output, aux)`` tuple a MoE head returns.
This module gives the compiled layer a real MoE implementation.

Design — kept intentionally simple and correct:

* **All-experts compute** (``y_all = stack([e(x) for e in experts])``).
  O(E) wasted FLOPs per token, but no sparse-dispatch bookkeeping and no
  capacity drops. Adequate for ``E ≤ 16`` on a single GPU, which matches
  the v1 catalogue.
* **Top-k routing** via the existing ``TopKRouter`` from
  ``eulerstack.components.routing`` (softmax logits → top-k values are
  re-normalised to sum to 1).
* **Load-balance loss** computed here (Switch / Mixtral style):
  ``L_aux = E · <f, P>`` where ``f`` is the dispatch fraction per expert
  (indices, non-diff) and ``P`` is the mean routing probability per
  expert (differentiable through the router).
* **Router z-loss** (if ``z_loss > 0``) flows through the router's own
  accumulator.

Forward contract (different from ``SimpleMoE`` in ``blocks/mamba.py`` —
that one always returns a tuple; here the tuple is opt-in so the call
site does not need to care):

    MoEFFN(x)                       → Tensor (output only)
    MoEFFN(x, output_aux=True)      → (Tensor, dict) with keys
                                      {aux_loss, router_z_loss, router_load}

The outer ``_EulerStackLayer`` checks a flag set at init time and unpacks
accordingly — see ``hf/modeling_eulerstack.py`` for the wiring.
"""
from __future__ import annotations

from typing import Any, Dict, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F

from eulerstack.blocks.mlp import build_mlp
from eulerstack.components.routing import TopKRouter


class MoEFFN(nn.Module):
    def __init__(
        self,
        d_model: int,
        *,
        experts: int,
        top_k: int,
        mlp_ratio: int = 4,
        router: str = "softmax",
        z_loss: float = 0.001,
        load_balance_coef: float = 0.01,
        dropout: float = 0.0,
        bias: bool = False,
        mlp_type: str = "swiglu",
    ):
        super().__init__()
        if experts < 1:
            raise ValueError(f"experts must be ≥ 1, got {experts}")
        if top_k < 1 or top_k > experts:
            raise ValueError(f"top_k must be in [1, experts]; got top_k={top_k}, experts={experts}")

        self.d_model = int(d_model)
        self.num_experts = int(experts)
        self.top_k = int(top_k)
        self.load_balance_coef = float(load_balance_coef)
        self.z_loss_coef = float(z_loss)

        self.router = TopKRouter(
            d_model=self.d_model,
            num_experts=self.num_experts,
            top_k=self.top_k,
            router_type=str(router),
            z_loss_coef=self.z_loss_coef,
        )
        self.experts = nn.ModuleList([
            build_mlp(
                mlp_type,
                d_model=self.d_model,
                mlp_ratio=int(mlp_ratio),
                dropout=float(dropout),
                bias=bias,
            )
            for _ in range(self.num_experts)
        ])

    def forward(
        self,
        x: torch.Tensor,
        *,
        output_aux: bool = False,
    ) -> Union[torch.Tensor, Tuple[torch.Tensor, Dict[str, Any]]]:
        b, t, c = x.shape
        if c != self.d_model:
            raise ValueError(
                f"MoEFFN expected d_model={self.d_model}, got feature dim {c}"
            )

        # Router: returns weights (B,T,K), indices (B,T,K), router_logits (B,T,E),
        # and optionally {z_loss, load}.
        route = self.router(x, compute_losses=self.training or output_aux)
        weights: torch.Tensor = route["weights"]
        indices: torch.Tensor = route["indices"]

        # All-experts compute. Each expert sees every token. The routing
        # gather picks top-k and combines with router weights.
        y_all = torch.stack([expert(x) for expert in self.experts], dim=2)   # (B,T,E,C)
        idx = indices.unsqueeze(-1).expand(b, t, self.top_k, c)              # (B,T,K,C)
        y_topk = torch.gather(y_all, dim=2, index=idx)                       # (B,T,K,C)
        y = (y_topk * weights.unsqueeze(-1)).sum(dim=2)                      # (B,T,C)

        if not output_aux:
            return y

        # ── Aux bundle ────────────────────────────────────────────────────
        aux: Dict[str, Any] = {}

        # 1. Router load-balance loss (Switch / Mixtral style).
        #    f_i = fraction of (token, slot) pairs routed to expert i
        #    P_i = mean(softmax(router_logits))_i over tokens  (differentiable)
        #    L_balance = E * <f, P>
        router_logits = route["router_logits"].float()            # (B, T, E)
        probs = F.softmax(router_logits, dim=-1)                   # (B, T, E)
        p_mean = probs.mean(dim=(0, 1))                            # (E,)

        with torch.no_grad():
            flat_idx = indices.reshape(-1)                         # (B*T*K,)
            total_slots = flat_idx.numel()
            counts = torch.zeros(self.num_experts, dtype=torch.float32, device=x.device)
            counts.index_add_(0, flat_idx, torch.ones_like(flat_idx, dtype=torch.float32))
            dispatch_frac = counts / max(total_slots, 1)           # (E,)

        load_balance = self.num_experts * (dispatch_frac * p_mean).sum()

        # 2. Router z-loss (already scaled by z_loss_coef inside the router).
        z_loss = route.get("z_loss")

        # 3. Diagnostic: mean routing weight per expert (no-grad).
        aux["router_load"] = p_mean.detach()

        # 4. Composite aux_loss that trainers add to the LM loss.
        total_aux = load_balance * self.load_balance_coef
        if z_loss is not None:
            total_aux = total_aux + z_loss
            aux["router_z_loss"] = z_loss.detach()
        aux["aux_loss"] = total_aux

        return y, aux
