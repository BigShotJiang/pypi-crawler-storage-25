from __future__ import annotations

from typing import Any, Dict, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F

from eulerstack.blocks.mlp import build_mlp
from eulerstack.blocks.norms import get_norm
from eulerstack.components.routing import TopKRouter


def _try_import_mamba():
    """
    Optional dependency.
    If installed, prefer the official implementations (Mamba / Mamba2).
    """
    try:
        from mamba_ssm import Mamba, Mamba2  # type: ignore
        return Mamba, Mamba2
    except Exception:
        return None, None


class CausalConvGatedMixer(nn.Module):
    """
    Fallback token-mixing block when mamba-ssm is not installed.

    This is NOT a real selective SSM. It is a shape-preserving mixer that supports:
    - causal depthwise conv (local mixing)
    - SiLU gating
    - configurable expansion
    """

    def __init__(
        self,
        d_model: int,
        *,
        d_conv: int = 4,
        expand: int = 2,
        dropout: float = 0.0,
    ):
        super().__init__()
        self.d_model = int(d_model)
        self.expand = int(expand)
        if self.expand <= 0:
            raise ValueError("expand must be positive")

        inner = self.d_model * self.expand

        self.in_proj = nn.Linear(self.d_model, 2 * inner, bias=False)

        self.d_conv = int(d_conv)
        if self.d_conv <= 0:
            raise ValueError("d_conv must be positive")

        self.conv = nn.Conv1d(
            in_channels=inner,
            out_channels=inner,
            kernel_size=self.d_conv,
            groups=inner,
            bias=True,
        )

        self.out_proj = nn.Linear(inner, self.d_model, bias=False)
        self.drop = nn.Dropout(float(dropout))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, t, c = x.shape
        inner = c * self.expand

        uv = self.in_proj(x)                # (B, T, 2*inner)
        u, v = uv.split(inner, dim=-1)      # each (B, T, inner)

        v_t = v.transpose(1, 2)             # (B, inner, T)
        pad = self.d_conv - 1
        v_t = F.pad(v_t, (pad, 0))
        v_t = self.conv(v_t)                # (B, inner, T)
        v = v_t.transpose(1, 2)             # (B, T, inner)

        y = F.silu(u) * v
        y = self.out_proj(y)
        y = self.drop(y)
        return y


class SimpleMoE(nn.Module):
    """
    Simple MoE FFN (token-wise top-k routing) for early experiments.

    - Computes router weights/indices with TopKRouter
    - Applies all experts and gathers top-k (O(E) compute; okay for small E in prototypes)

    This is deliberately simple; expert parallelism/capacity management comes later.
    """

    def __init__(
        self,
        d_model: int,
        *,
        experts: int = 8,
        top_k: int = 2,
        mlp_ratio: int = 4,
        dropout: float = 0.0,
        router_type: str = "softmax",
        z_loss: float = 0.0,
        mlp_type: str = "swiglu",
    ):
        super().__init__()
        self.d_model = int(d_model)
        self.experts = int(experts)
        self.top_k = int(top_k)

        self.router = TopKRouter(
            d_model=self.d_model,
            num_experts=self.experts,
            top_k=self.top_k,
            router_type=str(router_type),
            z_loss_coef=float(z_loss),
        )

        self.expert_mlps = nn.ModuleList(
            [
                build_mlp(
                    mlp_type,
                    d_model=self.d_model,
                    mlp_ratio=int(mlp_ratio),
                    dropout=float(dropout),
                    bias=False,
                )
                for _ in range(self.experts)
            ]
        )

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        # x: (B, T, C)
        b, t, c = x.shape
        route = self.router(x, compute_losses=self.training)

        weights = route["weights"]          # (B, T, K)
        indices = route["indices"]          # (B, T, K)

        # y_all: (B, T, E, C)
        y_all = torch.stack([mlp(x) for mlp in self.expert_mlps], dim=2)

        # (B, T, K, C)
        idx = indices.unsqueeze(-1).expand(b, t, self.top_k, c)
        y_topk = torch.gather(y_all, dim=2, index=idx)

        # (B, T, C)
        y = (y_topk * weights.unsqueeze(-1)).sum(dim=2)

        aux: Dict[str, torch.Tensor] = {}
        if "z_loss" in route:
            aux["z_loss"] = route["z_loss"]
        if "load" in route:
            aux["load"] = route["load"]
        return y, aux


class MambaBlock(nn.Module):
    """
    EulerStack Mamba block wrapper.

    Behavior:
    - Token-mixing:
        * Prefer mamba_ssm.Mamba or mamba_ssm.Mamba2 if installed.
        * Otherwise fall back to CausalConvGatedMixer.
    - Channel-mixing:
        * Optional MoE FFN (SimpleMoE) if use_moe=True, else standard MLP.

    Aux support (for official forward outputs):
    - If output_aux=True and use_moe=True, returns (x, aux_dict).
    - Otherwise returns x only.
    """

    def __init__(
        self,
        d_model: int,
        *,
        norm: str = "rmsnorm",
        dropout: float = 0.0,
        # Mamba-ish knobs
        variant: str = "mamba2",     # "mamba" | "mamba2"
        d_state: int = 64,
        d_conv: int = 4,
        expand: int = 2,
        # YAML convenience aliases
        conv_kernel: Optional[int] = None,  # alias of d_conv
        ssm_dim: Optional[int] = None,      # alias of d_state
        gating: str = "swiglu",
        # FFN / MoE knobs
        mlp_ratio: int = 4,
        mlp_type: str = "swiglu",
        use_moe: bool = False,
        moe: Optional[Dict[str, Any]] = None,
        **_: Any,
    ):
        super().__init__()
        self.d_model = int(d_model)
        self.norm1 = get_norm(norm, self.d_model)
        self.norm2 = get_norm(norm, self.d_model)

        if conv_kernel is not None:
            d_conv = int(conv_kernel)
        if ssm_dim is not None:
            d_state = int(ssm_dim)

        self.variant = str(variant).lower()
        self.d_state = int(d_state)
        self.d_conv = int(d_conv)
        self.expand = int(expand)
        self.gating = str(gating)

        Mamba, Mamba2 = _try_import_mamba()

        if Mamba is not None and Mamba2 is not None:
            if self.variant == "mamba":
                self.mixer = Mamba(
                    d_model=self.d_model,
                    d_state=self.d_state,
                    d_conv=self.d_conv,
                    expand=self.expand,
                )
            elif self.variant == "mamba2":
                self.mixer = Mamba2(
                    d_model=self.d_model,
                    d_state=self.d_state,
                    d_conv=self.d_conv,
                    expand=self.expand,
                )
            else:
                raise ValueError("variant must be 'mamba' or 'mamba2'")
            self.using_mamba_ssm = True
        else:
            self.mixer = CausalConvGatedMixer(
                d_model=self.d_model,
                d_conv=self.d_conv,
                expand=self.expand,
                dropout=float(dropout),
            )
            self.using_mamba_ssm = False

        self.use_moe = bool(use_moe)
        if self.use_moe:
            # Unified MoE path — same module used by RetNet/Hyena/attention so
            # aux keys ({aux_loss, router_z_loss, router_load}) match across
            # the codebase and the outer forward doesn't need per-block remaps.
            from eulerstack.blocks.moe import MoEFFN
            moe = moe or {}
            self.moe_ffn = MoEFFN(
                d_model=self.d_model,
                experts=int(moe.get("experts", 8)),
                top_k=int(moe.get("top_k", 2)),
                mlp_ratio=int(moe.get("mlp_ratio", mlp_ratio)),
                router=str(moe.get("router_type", moe.get("router", "softmax"))),
                z_loss=float(moe.get("z_loss", 0.001)),
                load_balance_coef=float(moe.get("load_balance_coef", 0.01)),
                dropout=float(moe.get("dropout", dropout)),
                bias=False,
                mlp_type=str(moe.get("mlp_type", mlp_type)),
            )
            self.mlp = None
        else:
            self.mlp = build_mlp(
                mlp_type,
                d_model=self.d_model,
                mlp_ratio=int(mlp_ratio),
                dropout=float(dropout),
                bias=False,
            )
            self.moe_ffn = None

        self.drop = nn.Dropout(float(dropout))

    def forward(
        self,
        x: torch.Tensor,
        *,
        output_aux: bool = False,
        **_: Any,
    ) -> Union[torch.Tensor, Tuple[torch.Tensor, Dict[str, torch.Tensor]]]:
        moe_aux: Dict[str, torch.Tensor] = {}

        # Token mixing
        h = self.norm1(x)
        h = self.mixer(h)
        x = x + self.drop(h)

        # Channel mixing
        h2 = self.norm2(x)
        if self.use_moe and self.moe_ffn is not None:
            if output_aux:
                y, aux = self.moe_ffn(h2, output_aux=True)
                # MoEFFN already emits standardised keys; just forward them.
                for k, v in aux.items():
                    moe_aux[k] = v
            else:
                y = self.moe_ffn(h2)
            x = x + self.drop(y)
        else:
            assert self.mlp is not None
            x = x + self.drop(self.mlp(h2))

        if output_aux and self.use_moe:
            return x, moe_aux
        return x
