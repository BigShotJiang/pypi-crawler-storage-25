# eulerstack/blocks/attention.py
from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from eulerstack.components.positional import apply_rope


PastKV = Optional[Tuple[torch.Tensor, torch.Tensor]]  # (k, v) each (B, H, S, D)


def _make_causal_local_mask(
    q_len: int,
    kv_len: int,
    *,
    window: Optional[int],
    device: torch.device,
) -> torch.Tensor:
    """
    Returns boolean attn_mask of shape (q_len, kv_len) where True means "allowed". [PyTorch SDPA convention]
    Supports rectangular kv_len >= q_len (KV cache) and optional local sliding window.

    For query token i (0..q_len-1), the last key index allowed is past_len + i,
    where past_len = kv_len - q_len.
    """
    past_len = kv_len - q_len
    if past_len < 0:
        raise ValueError("kv_len must be >= q_len for cached decoding mask")

    qi = torch.arange(q_len, device=device)[:, None]            # (q, 1)
    kj = torch.arange(kv_len, device=device)[None, :]           # (1, kv)
    max_k = past_len + qi                                       # (q, 1)
    allowed = kj <= max_k                                       # (q, kv)

    if window is not None:
        if window <= 0:
            raise ValueError("window must be positive")
        min_k = max_k - (window - 1)
        allowed = allowed & (kj >= min_k)

    return allowed


class CausalSelfAttention(nn.Module):
    """
    Minimal causal self-attention with:
    - optional KV cache (past_key_value)
    - optional local attention window
    - optional RoPE cos/sin cache applied to q/k

    Shapes:
      input x: (B, T, C)
      returns:
        out: (B, T, C)
        new_past: (k, v) each (B, H, S_total, D) if use_cache else None
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        dropout: float = 0.0,
        qkv_bias: bool = False,
        attn_drop: float = 0.0,
        window: Optional[int] = None,
        rope: bool = False,
        # Phase B2.1 / Tier-3 runtime: MLA (Multi-head Latent Attention).
        # When set to a positive int < d_model, K and V are produced by first
        # projecting x down to a shared latent of `latent_dim`, then up to
        # full d_model for each of K and V. Q stays a full projection.
        # KV cache memory per token drops from 2*d_model to latent_dim.
        # Reference: DeepSeek-V2/V3 technical reports (2024).
        latent_dim: Optional[int] = None,
    ):
        super().__init__()
        if d_model % n_heads != 0:
            raise ValueError("d_model must be divisible by n_heads")

        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads

        # Validate MLA latent_dim explicitly: only None (disabled) or a
        # positive int strictly less than d_model is permitted. Any other
        # value (including 0) is a user error, not a silent disable.
        if latent_dim is None:
            self.latent_dim = None
        else:
            latent_dim_int = int(latent_dim)
            if latent_dim_int <= 0 or latent_dim_int >= d_model:
                raise ValueError(
                    f"latent_dim must be in (0, d_model); got {latent_dim_int} vs d_model={d_model}"
                )
            self.latent_dim = latent_dim_int

        if self.latent_dim is None:
            # Standard path: fused QKV projection.
            self.qkv = nn.Linear(d_model, 3 * d_model, bias=qkv_bias)
        else:
            # MLA path: separate Q projection + shared KV latent down-proj +
            # per-head K/V up-projections from the latent.
            self.q_proj = nn.Linear(d_model, d_model, bias=qkv_bias)
            self.kv_latent = nn.Linear(d_model, self.latent_dim, bias=qkv_bias)
            self.k_up = nn.Linear(self.latent_dim, d_model, bias=qkv_bias)
            self.v_up = nn.Linear(self.latent_dim, d_model, bias=qkv_bias)

        self.proj = nn.Linear(d_model, d_model, bias=True)

        self.dropout = float(dropout)
        self.attn_drop = float(attn_drop)
        self.window = window
        self.use_rope = bool(rope)

    def forward(
        self,
        x: torch.Tensor,
        *,
        attention_mask: Optional[torch.Tensor] = None,
        use_cache: bool = False,
        past_key_value: PastKV = None,
        rope_cos: Optional[torch.Tensor] = None,
        rope_sin: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
    ) -> Tuple[torch.Tensor, PastKV]:
        b, t, _ = x.shape

        if self.latent_dim is None:
            # Standard fused QKV.
            qkv = self.qkv(x)
            q, k, v = qkv.chunk(3, dim=-1)
        else:
            # MLA: Q full, K and V from shared latent.
            q = self.q_proj(x)
            c_kv = self.kv_latent(x)                # (B, T, latent_dim)
            k = self.k_up(c_kv)
            v = self.v_up(c_kv)

        # (B, H, T, D)
        q = q.view(b, t, self.n_heads, self.head_dim).transpose(1, 2)
        k = k.view(b, t, self.n_heads, self.head_dim).transpose(1, 2)
        v = v.view(b, t, self.n_heads, self.head_dim).transpose(1, 2)

        # RoPE (optional): apply to current q/k only; cached k should already be rotated in a real impl.
        if self.use_rope:
            if rope_cos is None or rope_sin is None:
                raise ValueError("RoPE enabled but rope_cos/rope_sin not provided")
            q = apply_rope(q, rope_cos, rope_sin, position_ids=position_ids)
            k = apply_rope(k, rope_cos, rope_sin, position_ids=position_ids)

        if past_key_value is not None:
            pk, pv = past_key_value
            # concat on sequence axis
            k = torch.cat([pk, k], dim=2)
            v = torch.cat([pv, v], dim=2)

        kv_len = k.size(2)

        # Build SDPA mask rules:
        # - If no extra masking needed, prefer is_causal=True (fast path).
        # - If cached decoding (rectangular) or local window, build boolean mask and set is_causal=False.
        need_rect_or_local = (kv_len != t) or (self.window is not None)

        sdpa_mask = None
        is_causal = False
        if not need_rect_or_local and attention_mask is None:
            is_causal = True
        else:
            # base causal/local for cache + optional window
            sdpa_mask = _make_causal_local_mask(
                q_len=t,
                kv_len=kv_len,
                window=self.window,
                device=x.device,
            )  # (T, S) bool

            # Merge with padding mask if provided
            # If attention_mask is (B, S) with 1 keep / 0 mask
            if attention_mask is not None:
                if attention_mask.dim() == 2:
                    keep = attention_mask.to(dtype=torch.bool)  # (B, S)
                    # broadcast to (B, 1, T, S)
                    sdpa_mask = sdpa_mask.view(1, 1, t, kv_len) & keep.view(b, 1, 1, kv_len)
                elif attention_mask.dim() == 4:
                    # Assume it's already broadcastable additive/bool; keep minimal:
                    # if bool, AND it; if float, pass separately below.
                    if attention_mask.dtype == torch.bool:
                        sdpa_mask = sdpa_mask.view(1, 1, t, kv_len) & attention_mask
                    else:
                        # float mask: SDPA accepts float additive mask too; combine by converting causal bool
                        # to float additive (-inf for masked). Keep it simple:
                        causal_float = torch.where(
                            sdpa_mask,
                            torch.zeros((), device=x.device, dtype=attention_mask.dtype),
                            torch.full((), float("-inf"), device=x.device, dtype=attention_mask.dtype),
                        )
                        sdpa_mask = causal_float + attention_mask
                else:
                    raise ValueError("attention_mask must be (B,S) or (B,1,T,S)")

        # SDPA expects (B, H, T, D)
        out = F.scaled_dot_product_attention(
            q,
            k,
            v,
            attn_mask=sdpa_mask,
            dropout_p=self.attn_drop if self.training else 0.0,
            is_causal=is_causal,
        )

        out = out.transpose(1, 2).contiguous().view(b, t, self.d_model)
        out = self.proj(out)
        out = F.dropout(out, p=self.dropout, training=self.training)

        new_past: PastKV = None
        if use_cache:
            new_past = (k, v)

        return out, new_past
