"""EulerStack — an Architecture Description Language (ADL) for LLMs.

YAML-driven modular LLM assembler with HuggingFace compatibility.
See docs/tutorials/ (ko / en) or https://eulerwa.com/products/eulerstack/
for usage.
"""
from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("eulerstack")
except PackageNotFoundError:  # pragma: no cover — dev checkout without install
    # Fallback for editable-but-uninstalled source trees. The test suite
    # rejects this, but it keeps `import eulerstack` working in CI
    # environments that skip the install step.
    __version__ = "0.0.0+local"

__all__ = ["__version__"]
