# eulerstack/components/parallel_stream.py
"""Phase B3.2 Tier-3 runtime: dual-stream (monoidal) parallel composition.

Semantics
---------
Two (or more) streams receive the same input x, run independently, then the
outputs are combined by a `merge` operator. This is the runtime counterpart
to the v1 schedule entry:

    layer_schedule:
      - parallel:
          - stream: fast
            body: [{template: mamba_block, repeat: 2}]
          - stream: slow
            body: [{template: attn_block, repeat: 2}]
        merge: {type: concat, projection: true}

Supported merge operators (v1.0):
  - "concat"      — concat along last dim, then optional linear projection
                    back to d_model.
  - "add"         — elementwise sum.
  - "gated"       — sigmoid-gated mix: g * A + (1-g) * B with a learned
                    scalar-per-token gate.
  - "cross_attn"  — attention from the `to`-stream query against the
                    `from`-stream KV (single head, simple baseline).

The compiler's default v1 materialization flattens a parallel entry into
all streams' layers concatenated sequentially. This module provides the
*true* parallel runtime for users who want the monoidal semantics.

References
----------
- PaLM (Chowdhery et al., 2023) — within-layer parallel attn/FFN.
- Flamingo (Alayrac et al., NeurIPS 2022) — cross-attention dual tower.
- Jamba (Lieber et al., 2024) — layer-level hybrid; parallel is the
  natural monoidal generalization.
"""
from __future__ import annotations

from typing import Callable, List, Optional, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F


_VALID_MERGES = {"concat", "add", "gated", "cross_attn"}


class ParallelStream(nn.Module):
    """Run N stream-bodies on the same input and merge the outputs.

    Args:
        stream_modules: ordered list of nn.Modules, one per stream. Each
                        must map (B, T, d_model) → (B, T, d_model).
        d_model: hidden dim (used by merge projection/gate).
        merge_type: one of "concat" | "add" | "gated" | "cross_attn".
        merge_projection: for "concat", whether to project N*d_model → d_model.
        from_stream: name of the KV source for "cross_attn".
        to_stream: name of the query source for "cross_attn".
        stream_names: names aligned with stream_modules (required for
                      cross_attn so from/to can be resolved).
    """

    def __init__(
        self,
        stream_modules: Sequence[nn.Module],
        d_model: int,
        *,
        merge_type: str = "concat",
        merge_projection: bool = True,
        from_stream: Optional[str] = None,
        to_stream: Optional[str] = None,
        stream_names: Optional[Sequence[str]] = None,
    ):
        super().__init__()
        if merge_type not in _VALID_MERGES:
            raise ValueError(
                f"merge_type must be one of {sorted(_VALID_MERGES)}; got {merge_type}"
            )
        if len(stream_modules) < 2:
            raise ValueError("ParallelStream requires at least 2 streams")

        self.d_model = int(d_model)
        self.merge_type = merge_type
        self.merge_projection = bool(merge_projection)
        self.streams = nn.ModuleList(stream_modules)
        self.stream_names = list(stream_names) if stream_names is not None else [
            f"stream_{i}" for i in range(len(stream_modules))
        ]
        if len(self.stream_names) != len(self.streams):
            raise ValueError(
                "stream_names must have same length as stream_modules"
            )

        if merge_type == "concat" and self.merge_projection:
            self.merge_proj = nn.Linear(
                len(self.streams) * self.d_model, self.d_model, bias=False
            )
        else:
            self.merge_proj = None

        if merge_type == "gated":
            # one scalar gate per stream, produced from input.
            self.gate = nn.Linear(self.d_model, len(self.streams), bias=False)
        else:
            self.gate = None

        if merge_type == "cross_attn":
            if from_stream is None or to_stream is None:
                raise ValueError(
                    "cross_attn merge requires from_stream and to_stream names"
                )
            if from_stream not in self.stream_names:
                raise ValueError(f"from_stream='{from_stream}' not in {self.stream_names}")
            if to_stream not in self.stream_names:
                raise ValueError(f"to_stream='{to_stream}' not in {self.stream_names}")
            self.from_stream = from_stream
            self.to_stream = to_stream
            self.cross_q = nn.Linear(self.d_model, self.d_model, bias=False)
            self.cross_k = nn.Linear(self.d_model, self.d_model, bias=False)
            self.cross_v = nn.Linear(self.d_model, self.d_model, bias=False)
            self.cross_out = nn.Linear(self.d_model, self.d_model, bias=False)

    def _run_streams(self, x: torch.Tensor) -> List[torch.Tensor]:
        # Each stream sees the same input and produces (B, T, d_model).
        return [stream(x) for stream in self.streams]

    def _merge_concat(self, outs: List[torch.Tensor]) -> torch.Tensor:
        merged = torch.cat(outs, dim=-1)
        if self.merge_proj is not None:
            merged = self.merge_proj(merged)
        return merged

    def _merge_add(self, outs: List[torch.Tensor]) -> torch.Tensor:
        out = outs[0]
        for o in outs[1:]:
            out = out + o
        return out

    def _merge_gated(self, outs: List[torch.Tensor], x: torch.Tensor) -> torch.Tensor:
        # gate shape: (B, T, N); softmax over stream dim.
        logits = self.gate(x)
        weights = F.softmax(logits, dim=-1)           # (B, T, N)
        stacked = torch.stack(outs, dim=-1)           # (B, T, d_model, N)
        return (stacked * weights.unsqueeze(-2)).sum(dim=-1)

    def _merge_cross_attn(self, outs: List[torch.Tensor]) -> torch.Tensor:
        # pick the two named streams.
        idx_from = self.stream_names.index(self.from_stream)
        idx_to = self.stream_names.index(self.to_stream)
        kv = outs[idx_from]
        q_src = outs[idx_to]
        # single-head attention for simplicity.
        q = self.cross_q(q_src)
        k = self.cross_k(kv)
        v = self.cross_v(kv)
        scale = self.d_model ** -0.5
        attn = torch.softmax(q @ k.transpose(-2, -1) * scale, dim=-1)
        out = attn @ v
        return self.cross_out(out)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        outs = self._run_streams(x)
        if self.merge_type == "concat":
            return self._merge_concat(outs)
        if self.merge_type == "add":
            return self._merge_add(outs)
        if self.merge_type == "gated":
            return self._merge_gated(outs, x)
        if self.merge_type == "cross_attn":
            return self._merge_cross_attn(outs)
        # unreachable
        raise RuntimeError(f"unknown merge_type {self.merge_type!r}")

    def extra_repr(self) -> str:
        return f"merge_type={self.merge_type}, streams={self.stream_names}"
