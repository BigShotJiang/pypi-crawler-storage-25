"""Titans-style neural memory module (Phase B4.1 core runtime).

Reference: Behrouz, Zhong, Mirrokni — "Titans: Learning to Memorize at
Test Time" (Google, 2024-2025). The memory is a small parametric
network that persists across turns and can take inner gradient steps
against a **surprise** signal at inference time.

Distinct from:
    - KV cache: non-parametric, sequence-scoped. Titans memory has
      its own parameters independent of sequence length.
    - MoE experts: stateless learners routed per-token. Titans memory
      is a single shared module that evolves over time.

Contract
--------
- Forward: ``(B, T, D) → (B, T, D)``; residual additive contribution.
- Inner optimizer: SGD on the memory's parameters only. Never touches
  the rest of the model.
- The standardized hook ``update_at_inference_step(x)`` takes one
  inner SGD step minimizing a reconstruction (*surprise*) loss against
  incoming hidden states. When ``update_at_inference=False`` the hook
  is a no-op.
- Works after HF ``save_pretrained → from_pretrained``: the memory
  parameters are saved/loaded as standard submodule weights.
"""
from __future__ import annotations

from typing import Any, Optional

import torch
import torch.nn as nn


class TitansMemoryModule(nn.Module):
    """Parametric neural memory with optional inference-time update.

    Architecture: a 2-layer MLP ``D → hidden → D`` plus a learnable
    persistent memory vector ``m`` of size ``hidden``. The forward
    query is:

        q = W_q x
        attn = softmax(q · m^T / sqrt(hidden))    # over sequence dim 0
        v = m (broadcast)
        out = W_o v

    For simplicity and training stability we use a GRU-style gated
    residual: ``y = (1 - g) * x + g * mlp(x)`` with a learned gate.

    The reconstruction loss used for inference-time update is
    ``|| mlp(x) - x ||_2^2`` over the batch — the *surprise*.
    """

    def __init__(
        self,
        d_model: int,
        hidden: int = 2048,
        *,
        inner_lr: float = 1e-3,
        update_at_inference: bool = False,
        persistence: str = "session",
    ) -> None:
        super().__init__()
        self.d_model = int(d_model)
        self.hidden = int(hidden)
        self.inner_lr = float(inner_lr)
        self.update_at_inference = bool(update_at_inference)
        self.persistence = str(persistence)

        self.in_proj = nn.Linear(self.d_model, self.hidden, bias=False)
        self.out_proj = nn.Linear(self.hidden, self.d_model, bias=False)
        self.gate = nn.Linear(self.d_model, self.d_model, bias=True)
        self.norm = nn.LayerNorm(self.d_model)

        # Persistent memory state — a parameter that can receive inner
        # gradient steps at inference time. Initialized small so the
        # module starts close to a gated passthrough.
        self.memory_state = nn.Parameter(torch.zeros(self.hidden))

        # Zero-initialize out_proj so that at init the memory contribution
        # is zero and standard training is unaffected.
        nn.init.zeros_(self.out_proj.weight)

    # ------------------------------------------------------------------
    # Forward (trainable)
    # ------------------------------------------------------------------

    def _mlp(self, x: torch.Tensor) -> torch.Tensor:
        h = self.in_proj(self.norm(x))
        h = torch.nn.functional.gelu(h)
        h = h + self.memory_state  # broadcast add along (B, T)
        return self.out_proj(h)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self._mlp(x)
        g = torch.sigmoid(self.gate(x))
        return x + g * h

    # ------------------------------------------------------------------
    # Inference-time update hook
    # ------------------------------------------------------------------

    @torch.enable_grad()
    def update_at_inference_step(self, x: torch.Tensor) -> Optional[float]:
        """Take one inner SGD step minimizing the *surprise* on ``x``.

        Returns the scalar surprise loss value, or ``None`` when
        ``update_at_inference`` is False.
        """
        if not self.update_at_inference:
            return None

        # Work on a detached copy of input so gradients only flow into
        # the memory's own parameters — never into upstream compute.
        x_det = x.detach()

        params = list(self.parameters())
        # Re-enable grad on params even in eval mode.
        saved_requires_grad = [p.requires_grad for p in params]
        for p in params:
            p.requires_grad_(True)

        try:
            # Clear any stale grad.
            for p in params:
                if p.grad is not None:
                    p.grad = None

            pred = self._mlp(x_det)
            # Surprise: how far the memory's reconstruction is from the
            # incoming hidden state. Lower surprise = better memorization.
            surprise = torch.mean((pred - x_det) ** 2)
            surprise.backward()

            with torch.no_grad():
                for p in params:
                    if p.grad is not None:
                        p.add_(p.grad, alpha=-self.inner_lr)
                        p.grad = None
            return float(surprise.detach().item())
        finally:
            for p, rg in zip(params, saved_requires_grad):
                p.requires_grad_(rg)

    def extra_repr(self) -> str:
        return (
            f"d_model={self.d_model}, hidden={self.hidden}, "
            f"inner_lr={self.inner_lr}, "
            f"update_at_inference={self.update_at_inference}, "
            f"persistence={self.persistence!r}"
        )
