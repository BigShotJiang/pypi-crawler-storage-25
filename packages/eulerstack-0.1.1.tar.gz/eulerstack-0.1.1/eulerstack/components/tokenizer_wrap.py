# eulerstack/components/tokenizer_wrap.py
from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Dict, Optional

from transformers import AutoTokenizer


def load_tokenizer(tokenizer_spec: Dict[str, Any]):
    """
    Load a Hugging Face tokenizer according to tokenizer_spec.

    Expected tokenizer_spec schema (example):
      {
        "type": "hf",
        "pretrained": "gpt2",
        "add_bos": true,
        "add_eos": true,
        "extra": {...}
      }

    Returns:
      transformers.PreTrainedTokenizerBase
    """
    ttype = str(tokenizer_spec.get("type", "hf"))
    if ttype != "hf":
        raise ValueError(f"Unsupported tokenizer.type: {ttype}")

    pretrained = tokenizer_spec.get("pretrained", None)
    if not isinstance(pretrained, str) or not pretrained:
        raise ValueError("tokenizer.pretrained must be a non-empty string for type=hf")

    extra = tokenizer_spec.get("extra", {})
    if extra is None:
        extra = {}
    if not isinstance(extra, dict):
        raise ValueError("tokenizer.extra must be a dict")

    tok = AutoTokenizer.from_pretrained(pretrained, **extra)  # [web:73]

    # Heuristics: ensure pad token exists for batching if user wants it later.
    # Keep this minimal; real policies can live in a separate module.
    if tok.pad_token is None and tok.eos_token is not None:
        tok.pad_token = tok.eos_token

    # Optional BOS/EOS behavior hints (actual insertion is usually done by the data pipeline)
    add_bos = bool(tokenizer_spec.get("add_bos", False))
    add_eos = bool(tokenizer_spec.get("add_eos", False))

    # Store as attributes for downstream datamodule/collator to respect
    tok._eulerstack_add_bos = add_bos  # type: ignore[attr-defined]
    tok._eulerstack_add_eos = add_eos  # type: ignore[attr-defined]

    return tok


def tokenizer_spec_to_dict(spec_obj: Any) -> Dict[str, Any]:
    """
    Accept either dataclass (TokenizerSpec) or dict and normalize to dict.
    """
    if spec_obj is None:
        return {}
    if is_dataclass(spec_obj):
        return asdict(spec_obj)
    if isinstance(spec_obj, dict):
        return dict(spec_obj)
    raise ValueError(f"Unsupported tokenizer spec type: {type(spec_obj)}")
