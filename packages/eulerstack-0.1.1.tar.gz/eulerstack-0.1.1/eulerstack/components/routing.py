# eulerstack/components/routing.py
from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


def routing_spec_to_dict(spec_obj: Any) -> Dict[str, Any]:
    """
    Accept either dataclass (RoutingSpec/MoESpec) or dict and normalize to dict.
    """
    if spec_obj is None:
        return {}
    if is_dataclass(spec_obj):
        return asdict(spec_obj)
    if isinstance(spec_obj, dict):
        return dict(spec_obj)
    raise ValueError(f"Unsupported routing spec type: {type(spec_obj)}")


def router_z_loss(router_logits: torch.Tensor) -> torch.Tensor:
    """
    Router z-loss as used in sparse expert models (penalize large logits for stability). [web:309]

    Args:
      router_logits: (B, T, E) or (N, E)

    Returns:
      scalar tensor
    """
    if router_logits.dim() == 2:
        log_z = torch.logsumexp(router_logits, dim=-1)  # (N,)
        z = log_z**2
        return z.mean()
    if router_logits.dim() == 3:
        b, t, _ = router_logits.shape
        log_z = torch.logsumexp(router_logits, dim=-1)  # (B, T)
        z = log_z**2
        return z.sum() / (b * t)
    raise ValueError("router_logits must be 2D or 3D")


def _topk_routing(
    router_logits_2d: torch.Tensor,
    top_k: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Args:
      router_logits_2d: (N, E)
    Returns:
      weights: (N, K) softmax over top-k logits
      indices: (N, K) expert indices
    """
    top_k_logits, top_k_indices = torch.topk(router_logits_2d, k=top_k, dim=-1)  # [web:316]
    weights = F.softmax(top_k_logits, dim=-1, dtype=torch.float32)
    weights = weights.to(dtype=router_logits_2d.dtype)
    return weights, top_k_indices


class TopKRouter(nn.Module):
    """
    Simple token router for MoE.

    - Projects hidden states -> router logits over experts
    - Selects top-k experts per token
    - Returns (weights, indices, router_logits, aux_losses)

    This is a minimal building block; capacity routing, token dropping,
    and expert-parallel comms are handled later in training/runtime.
    """

    def __init__(
        self,
        d_model: int,
        num_experts: int,
        top_k: int = 2,
        router_type: str = "softmax",
        z_loss_coef: float = 0.0,
    ):
        super().__init__()
        if num_experts <= 0:
            raise ValueError("num_experts must be positive.")
        if top_k <= 0 or top_k > num_experts:
            raise ValueError("top_k must be in [1, num_experts].")

        self.d_model = d_model
        self.num_experts = num_experts
        self.top_k = top_k
        self.router_type = router_type
        self.z_loss_coef = float(z_loss_coef)

        # Commonly a single linear projection is used for routing [web:306]
        self.router = nn.Linear(d_model, num_experts, bias=False)

    def forward(
        self,
        hidden_states: torch.Tensor,
        *,
        compute_losses: bool = True,
    ) -> Dict[str, Any]:
        """
        Args:
          hidden_states: (B, T, D)

        Returns dict:
          - weights: (B, T, K)
          - indices: (B, T, K)
          - router_logits: (B, T, E)
          - z_loss: scalar (optional)
          - load: (E,) fraction of tokens routed to each expert (diagnostic)
        """
        if hidden_states.dim() != 3:
            raise ValueError("hidden_states must be (B, T, D)")

        b, t, d = hidden_states.shape
        if d != self.d_model:
            raise ValueError("hidden_states last dim must match router d_model")

        router_logits = self.router(hidden_states)  # (B, T, E)

        # Flatten tokens
        logits_2d = router_logits.reshape(b * t, self.num_experts)

        # Router type extension point (for now both behave like standard softmax top-k)
        if self.router_type not in ("softmax", "sigmoid"):
            raise ValueError("router_type must be 'softmax' or 'sigmoid'")

        weights_2d, indices_2d = _topk_routing(logits_2d, self.top_k)
        weights = weights_2d.view(b, t, self.top_k)
        indices = indices_2d.view(b, t, self.top_k)

        out: Dict[str, Any] = {
            "weights": weights,
            "indices": indices,
            "router_logits": router_logits,
        }

        if compute_losses and self.z_loss_coef > 0.0:
            z = router_z_loss(router_logits)  # [web:309]
            out["z_loss"] = z * self.z_loss_coef

        # Diagnostic: token load per expert (not a differentiable aux loss)
        # counts how often each expert is selected in top-k across all tokens
        with torch.no_grad():
            load = torch.zeros(self.num_experts, device=hidden_states.device, dtype=torch.float32)
            flat_idx = indices_2d.reshape(-1)  # (N*K,)
            load.scatter_add_(0, flat_idx, torch.ones_like(flat_idx, dtype=torch.float32))
            load = load / float(b * t * self.top_k)
            out["load"] = load

        return out
