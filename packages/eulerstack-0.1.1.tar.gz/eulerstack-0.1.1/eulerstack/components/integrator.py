# eulerstack/components/integrator.py
"""Phase B3.3 Tier-3 runtime: discrete integrator primitive.

Usage
-----
A `DiscreteIntegrator(body, steps)` module applies `body` K times with
**shared weights**, which is the Universal Transformer (Dehghani et al.,
ICLR 2019) / PonderNet (Banino et al., 2021) / Coconut (Hao et al., 2024)
interpretation of the v1 `integrator:` schedule entry.

The default v1 compiler flattens an integrator entry into K independent
copies of the body template (distinct weights per step — Diffusion-LM-style).
This module is provided for users who want the shared-weight
interpretation: they can wire one `DiscreteIntegrator` around a single
compiled body.

Example
-------
>>> body = nn.Linear(32, 32)
>>> integrator = DiscreteIntegrator(body, steps=4)
>>> y = integrator(torch.randn(2, 8, 32))            # y.shape == (2, 8, 32)

Note: the body module's forward must be `(x) -> x` (identity shape).
This matches the Transformer-style residual stack convention.
"""
from __future__ import annotations

from typing import Callable, Optional

import torch
import torch.nn as nn


class DiscreteIntegrator(nn.Module):
    """Apply `body` K times sequentially (shared weights).

    Args:
        body: an nn.Module whose forward preserves the last-dimension shape.
              Signature is either `body(x)` or `body(x, step_index=...)`.
        steps: number of iterations (K). Must be >= 1.
        step_aware: if True, pass the step index as `step_index=i` to the
                    body on each call. If False, just call `body(x)`.
                    Useful for bodies that condition on the iteration
                    number (e.g. diffusion denoising schedules).
    """

    def __init__(
        self,
        body: nn.Module,
        steps: int,
        *,
        step_aware: bool = False,
    ):
        super().__init__()
        if steps < 1:
            raise ValueError(f"DiscreteIntegrator.steps must be >= 1; got {steps}")
        self.body = body
        self.steps = int(steps)
        self.step_aware = bool(step_aware)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for i in range(self.steps):
            if self.step_aware:
                x = self.body(x, step_index=i)
            else:
                x = self.body(x)
        return x

    def extra_repr(self) -> str:
        return f"steps={self.steps}, step_aware={self.step_aware}"


def iterate(body: Callable, x: torch.Tensor, steps: int) -> torch.Tensor:
    """Functional helper: call `body` K times on `x`.

    Equivalent to constructing a `DiscreteIntegrator(body, steps)` and
    invoking it, but without creating a stateful module. Useful inside a
    larger forward where the body is assembled on the fly.
    """
    if steps < 1:
        raise ValueError(f"iterate.steps must be >= 1; got {steps}")
    for _ in range(steps):
        x = body(x)
    return x


# ---------------------------------------------------------------------------
# Phase B3.3 core: Neural-ODE discretizations (ode_euler / ode_rk4)
# ---------------------------------------------------------------------------


class ODEIntegrator(nn.Module):
    """Apply ``body`` as the derivative ``f(x)`` of a Neural ODE.

    Semantics: the body is treated as a single-step derivative; the
    integrator performs K steps of numerical integration with step size
    ``dt = 1 / steps``. Weights are shared across all K steps (this is
    the Chen et al. 2018 Neural-ODE convention).

    Supported methods:
        ``"euler"`` — one body call per step, ``dt * f(x)``.
        ``"rk4"``   — four body calls per step (classic 4th-order RK).

    The body must be shape-preserving: ``body(x).shape == x.shape``.
    """

    _VALID_METHODS = ("euler", "rk4")

    def __init__(
        self,
        body: nn.Module,
        steps: int,
        *,
        method: str = "rk4",
    ):
        super().__init__()
        if steps < 1:
            raise ValueError(f"ODEIntegrator.steps must be >= 1; got {steps}")
        if method not in self._VALID_METHODS:
            raise ValueError(
                f"ODEIntegrator.method must be one of {self._VALID_METHODS}; "
                f"got {method!r}"
            )
        self.body = body
        self.steps = int(steps)
        self.method = method

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        dt = 1.0 / float(self.steps)
        if self.method == "euler":
            for _ in range(self.steps):
                x = x + dt * self.body(x)
            return x
        # rk4
        for _ in range(self.steps):
            k1 = self.body(x)
            k2 = self.body(x + 0.5 * dt * k1)
            k3 = self.body(x + 0.5 * dt * k2)
            k4 = self.body(x + dt * k3)
            x = x + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)
        return x

    def extra_repr(self) -> str:
        return f"steps={self.steps}, method={self.method!r}"
