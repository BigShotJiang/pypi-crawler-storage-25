# eulerstack/components/positional.py
from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Dict, Optional, Tuple

import torch


def positional_spec_to_rope_parameters(positional_spec: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize EulerStack positional spec -> rope_parameters-like dict.

    HF 내부 유틸은 rope_parameters/rope_theta/factor 같은 필드를 사용합니다. [web:270]
    여기서는 EulerStack YAML 구조를 최대한 그대로 유지하면서도,
    어텐션 블록이 쓰기 쉽게 표준화합니다.
    """
    ptype = str(positional_spec.get("type", "none"))
    if ptype == "none":
        return {"type": "none"}

    if ptype != "rope":
        raise ValueError(f"Unsupported positional.type: {ptype}")

    rope_theta = float(positional_spec.get("rope_theta", 10000.0))
    scaling = positional_spec.get("scaling", None)

    out: Dict[str, Any] = {"type": "rope", "rope_theta": rope_theta}

    if isinstance(scaling, dict):
        stype = str(scaling.get("type", "linear"))
        factor = float(scaling.get("factor", 1.0))
        out["scaling"] = {"type": stype, "factor": factor}

    return out


def build_rope_cache(
    *,
    head_dim: int,
    max_seq_len: int,
    rope_theta: float = 10000.0,
    device: Optional[torch.device] = None,
    dtype: Optional[torch.dtype] = None,
    scaling_factor: float = 1.0,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Precompute RoPE cos/sin cache for a given head_dim and max_seq_len.

    Returns:
      cos: (max_seq_len, head_dim)
      sin: (max_seq_len, head_dim)

    Notes:
    - RoPE는 head_dim의 짝(2) 단위로 회전합니다. [web:270]
    - scaling_factor는 context extension을 위해 position index에 선형 스케일을 적용하는 단순 버전입니다. [web:270]
    """
    if head_dim % 2 != 0:
        raise ValueError("RoPE head_dim must be even.")

    device = device or torch.device("cpu")
    dtype = dtype or torch.float32

    # inv_freq shape: (head_dim/2,)
    half = head_dim // 2
    inv_freq = 1.0 / (rope_theta ** (torch.arange(0, half, device=device, dtype=dtype) / half))

    # positions shape: (max_seq_len,)
    positions = torch.arange(max_seq_len, device=device, dtype=dtype) / float(scaling_factor)

    # freqs: (max_seq_len, head_dim/2)
    freqs = torch.einsum("t,f->tf", positions, inv_freq)

    # Expand to full head_dim by duplicating for (cos,sin) pairing
    cos = torch.cat([torch.cos(freqs), torch.cos(freqs)], dim=-1)  # (T, D)
    sin = torch.cat([torch.sin(freqs), torch.sin(freqs)], dim=-1)  # (T, D)
    return cos, sin


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    """
    Helper used in many RoPE implementations:
    split last dim into two halves and rotate. [web:270]
    """
    d = x.size(-1)
    x1 = x[..., : d // 2]
    x2 = x[..., d // 2 :]
    return torch.cat([-x2, x1], dim=-1)


def apply_rope(
    x: torch.Tensor,
    cos: torch.Tensor,
    sin: torch.Tensor,
    position_ids: Optional[torch.LongTensor] = None,
) -> torch.Tensor:
    """
    Apply RoPE to a tensor.

    Args:
      x: (B, H, T, D) or (B, T, H, D)
      cos/sin: (max_seq_len, D)
      position_ids: optional (B, T) positions to pick; otherwise assume [0..T-1]
    """
    if x.dim() != 4:
        raise ValueError("apply_rope expects a 4D tensor.")

    # Normalize shape to (B, H, T, D)
    transposed = False
    if x.shape[1] != 0 and x.shape[-1] != 0:
        # If it's (B, T, H, D), transpose
        if x.size(1) != x.size(2) and x.size(1) == x.size(-2):
            pass  # ambiguous; keep as-is
    if x.size(1) != x.size(2) and x.size(1) == x.size(-2):
        # not reliable; keep minimal
        pass

    # Detect by common convention: (B, T, H, D)
    if x.size(1) == x.size(-2):
        # likely (B, T, H, D)
        x = x.transpose(1, 2)  # (B, H, T, D)
        transposed = True

    b, h, t, d = x.shape
    if cos.size(-1) != d or sin.size(-1) != d:
        raise ValueError("cos/sin last dim must match x head_dim.")

    if position_ids is None:
        cos_t = cos[:t].view(1, 1, t, d)
        sin_t = sin[:t].view(1, 1, t, d)
    else:
        # position_ids: (B, T) — may be an expanded (non-contiguous) view, so
        # use reshape rather than view to avoid stride incompatibility.
        flat_ids = position_ids.reshape(-1)
        cos_t = cos.index_select(0, flat_ids).view(b, 1, t, d)
        sin_t = sin.index_select(0, flat_ids).view(b, 1, t, d)

    out = (x * cos_t) + (rotate_half(x) * sin_t)

    if transposed:
        out = out.transpose(1, 2)  # back to (B, T, H, D)
    return out


def positional_spec_to_dict(spec_obj: Any) -> Dict[str, Any]:
    """
    Accept either dataclass (PositionalSpec) or dict and normalize to dict.
    """
    if spec_obj is None:
        return {}
    if is_dataclass(spec_obj):
        return asdict(spec_obj)
    if isinstance(spec_obj, dict):
        return dict(spec_obj)
    raise ValueError(f"Unsupported positional spec type: {type(spec_obj)}")
