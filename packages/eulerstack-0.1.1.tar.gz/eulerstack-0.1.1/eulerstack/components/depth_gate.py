# eulerstack/components/depth_gate.py
"""Phase B3.1 Tier-3 runtime: Mixture-of-Depths (MoD) router.

Reference
---------
Raposo, Ritter, Richards, Lillicrap, Buchatskaya, Santoro, Barrett.
"Mixture-of-Depths: Dynamically allocating compute in transformer-based
language models." ICML 2024.

Runtime semantics
-----------------
For each layer, a small Linear router assigns a scalar score to each token.
Only the top `capacity` fraction of tokens (per sequence) go through the
wrapped `body` module; the rest bypass via a straight-through residual.

This module wraps an arbitrary body (typically a full `_EulerStackLayer`
sub-component) and returns the same shape as input, honouring the MoD
paper's capacity routing.

Notes on scope
--------------
- Inference: the simplest honest implementation is to always pass through
  (capacity=1.0) when `eval()` — that way decoding cost is predictable.
  During training, the router drops tokens and the gradient flows through
  both paths.
- Straight-through: tokens that bypass are added back with their original
  representation (no mixing with the body output).
"""
from __future__ import annotations

from typing import Callable, Optional

import torch
import torch.nn as nn


class DepthGate(nn.Module):
    """Token-level layer skip (Mixture-of-Depths).

    Args:
        d_model: hidden dimension of the token stream.
        capacity: fraction of tokens per sequence to route through the body.
                  Must be in (0.0, 1.0]. 1.0 = no skipping.
        router: routing strategy — "top_k" (deterministic, per-seq top
                `capacity*T` tokens) or "learned_gate" (soft gate ×
                body-output with a learned linear scorer).

    Usage:
        >>> gate = DepthGate(d_model=128, capacity=0.5)
        >>> y = gate(x, body_fn=layer.forward)       # x: (B, T, C)

    The body_fn must accept (B, T, C) and return (B, T, C).
    """

    def __init__(
        self,
        d_model: int,
        capacity: float = 0.5,
        router: str = "top_k",
    ):
        super().__init__()
        if not (0.0 < capacity <= 1.0):
            raise ValueError(f"capacity must be in (0, 1]; got {capacity}")
        if router not in ("top_k", "learned_gate"):
            raise ValueError(f"router must be 'top_k' or 'learned_gate'; got {router}")
        self.d_model = int(d_model)
        self.capacity = float(capacity)
        self.router = router
        # A tiny linear head that scores each token for routing.
        self.scorer = nn.Linear(self.d_model, 1, bias=False)

    def forward(
        self,
        x: torch.Tensor,
        body_fn: Callable[[torch.Tensor], torch.Tensor],
    ) -> torch.Tensor:
        b, t, c = x.shape

        # Eval-time shortcut: skip routing overhead; behave as a pass-through
        # layer. Prevents surprising decode-time behaviour for users who
        # only train the router briefly.
        if (not self.training) or self.capacity >= 1.0 - 1e-9:
            return body_fn(x)

        scores = self.scorer(x).squeeze(-1)          # (B, T)

        if self.router == "top_k":
            k = max(1, int(round(self.capacity * t)))
            # Per-sequence top-k.
            _, idx = torch.topk(scores, k=k, dim=1)  # (B, k)
            mask = torch.zeros(b, t, dtype=torch.bool, device=x.device)
            mask.scatter_(1, idx, True)
            # Body runs on all positions; mask selects which outputs to keep.
            y = body_fn(x)
            out = torch.where(mask.unsqueeze(-1), y, x)
            return out

        # learned_gate: soft multiplicative gate.
        gate = torch.sigmoid(scores).unsqueeze(-1)   # (B, T, 1)
        y = body_fn(x)
        return gate * y + (1.0 - gate) * x

    def extra_repr(self) -> str:
        return f"capacity={self.capacity}, router={self.router}"
