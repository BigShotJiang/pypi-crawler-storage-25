# eulerstack/components/memory.py
from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Dict, List, Optional, Tuple, Union

import torch

PastKeyValues = Optional[Tuple[Any, ...]]


def memory_spec_to_dict(spec_obj: Any) -> Dict[str, Any]:
    """
    Accept either dataclass (MemorySpec) or dict and normalize to dict.
    """
    if spec_obj is None:
        return {}
    if is_dataclass(spec_obj):
        return asdict(spec_obj)
    if isinstance(spec_obj, dict):
        return dict(spec_obj)
    raise ValueError(f"Unsupported memory spec type: {type(spec_obj)}")


def kv_cache_enabled(memory_spec: Dict[str, Any]) -> bool:
    kv = memory_spec.get("kv_cache", {}) if isinstance(memory_spec.get("kv_cache", {}), dict) else {}
    return bool(kv.get("enabled", True))


def kv_cache_policy(memory_spec: Dict[str, Any]) -> str:
    kv = memory_spec.get("kv_cache", {}) if isinstance(memory_spec.get("kv_cache", {}), dict) else {}
    return str(kv.get("policy", "paged"))


def ssm_state_enabled(memory_spec: Dict[str, Any]) -> bool:
    ssm = memory_spec.get("ssm_state", {}) if isinstance(memory_spec.get("ssm_state", {}), dict) else {}
    return bool(ssm.get("enabled", True))


def ssm_state_precision(memory_spec: Dict[str, Any]) -> str:
    ssm = memory_spec.get("ssm_state", {}) if isinstance(memory_spec.get("ssm_state", {}), dict) else {}
    return str(ssm.get("precision", "fp16"))


def detach_past_key_values(past_key_values: PastKeyValues) -> PastKeyValues:
    """
    Detach tensors inside past_key_values from autograd graph to reduce training-time memory pressure.
    (Detaching removes autograd history; it does not necessarily free reserved CUDA cache.) 
    """
    if past_key_values is None:
        return None

    out: List[Any] = []
    for layer_cache in past_key_values:
        out.append(_detach_any(layer_cache))
    return tuple(out)


def _detach_any(x: Any) -> Any:
    if torch.is_tensor(x):
        return x.detach()
    if isinstance(x, (list, tuple)):
        return type(x)(_detach_any(v) for v in x)
    if isinstance(x, dict):
        return {k: _detach_any(v) for k, v in x.items()}
    return x


def truncate_past_key_values(
    past_key_values: PastKeyValues,
    max_length: int,
    *,
    seq_dim: int = -2,
) -> PastKeyValues:
    """
    Truncate cache along sequence dimension to max_length (best-effort).
    This is a utility for experiments like sliding-window decoding.

    Args:
      seq_dim: common convention for KV shapes is (..., seq_len, head_dim), so seq_dim=-2.
    """
    if past_key_values is None:
        return None

    def _truncate_tensor(t: torch.Tensor) -> torch.Tensor:
        if t.size(seq_dim) <= max_length:
            return t
        # slice last max_length tokens along seq_dim
        slc = [slice(None)] * t.dim()
        slc[seq_dim] = slice(-max_length, None)
        return t[tuple(slc)]

    def _truncate_any(x: Any) -> Any:
        if torch.is_tensor(x):
            return _truncate_tensor(x)
        if isinstance(x, (list, tuple)):
            return type(x)(_truncate_any(v) for v in x)
        if isinstance(x, dict):
            return {k: _truncate_any(v) for k, v in x.items()}
        return x

    return tuple(_truncate_any(layer_cache) for layer_cache in past_key_values)


class EulerMemoryManager:
    """
    A thin policy layer around KV cache and (future) SSM state.

    Purpose:
    - Keep YAML-configured policies in one place.
    - Provide hooks for training vs inference behavior (e.g., detach, truncation, cache on/off).
    - Later: plug in real paged/static cache backends for serving runtimes.

    NOTE: In early stage, HF models can simply pass through `past_key_values`.
    """

    def __init__(self, memory_spec: Dict[str, Any]):
        self.memory_spec = memory_spec_to_dict(memory_spec)
        self.kv_enabled = kv_cache_enabled(self.memory_spec)
        self.kv_policy = kv_cache_policy(self.memory_spec)

        self.ssm_enabled = ssm_state_enabled(self.memory_spec)
        self.ssm_precision = ssm_state_precision(self.memory_spec)

    def preprocess_past_for_forward(
        self,
        past_key_values: PastKeyValues,
        *,
        training: bool,
        detach_in_training: bool = True,
    ) -> PastKeyValues:
        """
        Called before model.forward(...).
        """
        if not self.kv_enabled:
            return None

        if training and detach_in_training:
            return detach_past_key_values(past_key_values)

        return past_key_values

    def postprocess_past_from_forward(
        self,
        past_key_values: PastKeyValues,
        *,
        use_cache: bool,
        max_cache_len: Optional[int] = None,
    ) -> PastKeyValues:
        """
        Called after model.forward(...) returns cache.
        """
        if not use_cache or (not self.kv_enabled):
            return None

        if max_cache_len is not None:
            return truncate_past_key_values(past_key_values, max_cache_len)

        return past_key_values
