# eulerstack/data/prepare.py
"""Dataset download and preparation using HuggingFace datasets."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Optional

import torch
from torch.utils.data import Dataset


def compute_cache_key(
    tokenizer_name: str,
    max_seq_len: int,
    dataset_name: str,
    split: str,
    num_rows: int,
    add_bos: bool = True,
    add_eos: bool = True,
) -> str:
    """Compute a deterministic cache key for tokenized data."""
    key_data = f"{tokenizer_name}|{max_seq_len}|{dataset_name}|{split}|{num_rows}|{add_bos}|{add_eos}"
    return hashlib.sha256(key_data.encode()).hexdigest()[:16]


def get_cache_path(cache_dir: str, cache_key: str) -> Path:
    return Path(cache_dir) / f"tokenized_{cache_key}.pt"


def get_meta_path(cache_dir: str, cache_key: str) -> Path:
    return Path(cache_dir) / f"tokenized_{cache_key}.meta.json"


class TokenizedDataset(Dataset):
    """Simple tokenized text dataset for causal LM training."""

    def __init__(self, input_ids: torch.Tensor, vocab_size: Optional[int] = None):
        """input_ids: shape (num_samples, seq_len).
        vocab_size: if given, clamp all token IDs to [0, vocab_size-1].
        """
        if vocab_size is not None:
            input_ids = input_ids.clamp(max=vocab_size - 1)
        self.input_ids = input_ids

    def __len__(self) -> int:
        return len(self.input_ids)

    def __getitem__(self, idx):
        ids = self.input_ids[idx]
        return {"input_ids": ids, "labels": ids.clone()}


def tokenize_jsonl(
    jsonl_path: str,
    tokenizer_name: str = "gpt2",
    max_seq_len: int = 512,
    num_rows: Optional[int] = None,
    text_field: str = "text",
    cache_dir: str = "data/.cache",
    add_bos: bool = True,
    add_eos: bool = True,
) -> TokenizedDataset:
    """
    Tokenize a local JSONL file (one JSON object per line with a text field).

    Concatenates all text into a single token stream, then chunks into
    fixed-length sequences of max_seq_len. Caches the result.
    """
    import json as _json
    from transformers import AutoTokenizer

    cache_key = compute_cache_key(
        tokenizer_name, max_seq_len, jsonl_path, "local", num_rows or -1, add_bos, add_eos,
    )
    cache_path = get_cache_path(cache_dir, cache_key)
    meta_path = get_meta_path(cache_dir, cache_key)
    os.makedirs(cache_dir, exist_ok=True)

    if cache_path.exists() and meta_path.exists():
        input_ids = torch.load(cache_path, weights_only=True)
        return TokenizedDataset(input_ids)

    tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    all_ids: list[int] = []
    rows_read = 0
    with open(jsonl_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            row = _json.loads(line)
            text = row.get(text_field, "")
            if not text or not text.strip():
                continue
            ids = tokenizer.encode(text, add_special_tokens=False)
            if add_bos and tokenizer.bos_token_id is not None:
                ids = [tokenizer.bos_token_id] + ids
            if add_eos and tokenizer.eos_token_id is not None:
                ids = ids + [tokenizer.eos_token_id]
            all_ids.extend(ids)
            rows_read += 1
            if num_rows is not None and rows_read >= num_rows:
                break

    total = len(all_ids)
    n_chunks = total // max_seq_len
    if n_chunks == 0:
        raise ValueError(f"Not enough tokens ({total}) for even one chunk of {max_seq_len}")

    all_ids = all_ids[:n_chunks * max_seq_len]
    input_ids = torch.tensor(all_ids, dtype=torch.long).view(n_chunks, max_seq_len)

    torch.save(input_ids, cache_path)
    meta = {
        "tokenizer": tokenizer_name,
        "max_seq_len": max_seq_len,
        "source": jsonl_path,
        "num_rows": rows_read,
        "num_chunks": n_chunks,
        "total_tokens": total,
        "add_bos": add_bos,
        "add_eos": add_eos,
        "cache_key": cache_key,
    }
    with open(meta_path, "w") as f:
        _json.dump(meta, f, indent=2)

    return TokenizedDataset(input_ids)


def download_and_tokenize(
    tokenizer_name: str = "gpt2",
    max_seq_len: int = 512,
    dataset_name: str = "wikitext",
    dataset_config: str = "wikitext-2-raw-v1",
    split: str = "train",
    num_rows: int = 10000,
    cache_dir: str = "data/.cache",
    add_bos: bool = True,
    add_eos: bool = True,
) -> TokenizedDataset:
    """
    Download a HF dataset, tokenize, chunk, and cache.

    Returns a TokenizedDataset with shape (num_chunks, max_seq_len).
    Uses cache if available with matching parameters.
    """
    cache_key = compute_cache_key(tokenizer_name, max_seq_len, f"{dataset_name}/{dataset_config}", split, num_rows, add_bos, add_eos)
    cache_path = get_cache_path(cache_dir, cache_key)
    meta_path = get_meta_path(cache_dir, cache_key)

    os.makedirs(cache_dir, exist_ok=True)

    # Check cache
    if cache_path.exists() and meta_path.exists():
        input_ids = torch.load(cache_path, weights_only=True)
        return TokenizedDataset(input_ids)

    # Download
    from datasets import load_dataset
    from transformers import AutoTokenizer

    ds = load_dataset(dataset_name, dataset_config, split=split, trust_remote_code=True)
    if num_rows < len(ds):
        ds = ds.select(range(num_rows))

    tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # Tokenize all text into one long sequence
    text_column = "text" if "text" in ds.column_names else ds.column_names[0]
    all_ids = []
    for row in ds:
        text = row[text_column]
        if not text or not text.strip():
            continue
        ids = tokenizer.encode(text, add_special_tokens=False)
        if add_bos and tokenizer.bos_token_id is not None:
            ids = [tokenizer.bos_token_id] + ids
        if add_eos and tokenizer.eos_token_id is not None:
            ids = ids + [tokenizer.eos_token_id]
        all_ids.extend(ids)

    # Chunk into sequences of max_seq_len
    total = len(all_ids)
    n_chunks = total // max_seq_len
    if n_chunks == 0:
        raise ValueError(f"Not enough tokens ({total}) for even one chunk of {max_seq_len}")

    all_ids = all_ids[:n_chunks * max_seq_len]
    input_ids = torch.tensor(all_ids, dtype=torch.long).view(n_chunks, max_seq_len)

    # Save cache
    torch.save(input_ids, cache_path)
    meta = {
        "tokenizer": tokenizer_name,
        "max_seq_len": max_seq_len,
        "dataset": f"{dataset_name}/{dataset_config}",
        "split": split,
        "num_rows": num_rows,
        "num_chunks": n_chunks,
        "total_tokens": total,
        "add_bos": add_bos,
        "add_eos": add_eos,
        "cache_key": cache_key,
    }
    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)

    return TokenizedDataset(input_ids)
