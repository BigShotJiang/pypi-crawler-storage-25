# eulerstack/spec/report.py
"""Validation report: schema + compatibility + realism checks."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from eulerstack.i18n import t
from eulerstack.spec.errors import EulerStackError
from eulerstack.spec.validate import validate_v2
from eulerstack.ir.normalizer import normalize_to_ir
from eulerstack.ir.types import ModelIR
from eulerstack.spec.param_estimator import estimate_params, format_param_count
from eulerstack.spec.realism import Finding, Severity, run_realism_checks


@dataclass
class ValidationReport:
    """Structured validation report with 3 severity levels."""
    schema_ok: bool = True
    schema_error: Optional[str] = None
    ir: Optional[ModelIR] = None
    estimated_params: Optional[int] = None
    findings: List[Finding] = field(default_factory=list)

    @property
    def errors(self) -> List[Finding]:
        return [f for f in self.findings if f.severity == Severity.ERROR]

    @property
    def warnings(self) -> List[Finding]:
        return [f for f in self.findings if f.severity == Severity.WARNING]

    @property
    def infos(self) -> List[Finding]:
        return [f for f in self.findings if f.severity == Severity.INFO]

    @property
    def has_errors(self) -> bool:
        return not self.schema_ok or len(self.errors) > 0

    def format_text(self) -> str:
        """Format report as human-readable text (fully i18n'd)."""
        lines: List[str] = []
        lines.append("=" * 50)
        lines.append(t("report.header"))
        lines.append("=" * 50)

        # Schema
        if self.schema_ok:
            lines.append(t("report.schema_ok"))
        else:
            lines.append(t("report.schema_fail", error=self.schema_error))

        if not self.schema_ok:
            lines.append("=" * 50)
            return "\n".join(lines)

        # Param estimate
        if self.estimated_params is not None:
            lines.append(t(
                "report.estimated_params",
                pretty=format_param_count(self.estimated_params),
                exact=self.estimated_params,
            ))

        if self.ir:
            lines.append(t("report.total_layers", total=len(self.ir.expanded_layers)))
            if self.ir.model.target_params:
                lines.append(t(
                    "report.target_params",
                    pretty=format_param_count(self.ir.model.target_params),
                ))

        # Errors
        if self.errors:
            lines.append("")
            lines.append(t("report.errors_label", n=len(self.errors)))
            for f in self.errors:
                lines.append(f"  [{f.rule}] {f.message}")

        # Warnings
        if self.warnings:
            lines.append("")
            lines.append(t("report.warnings_label", n=len(self.warnings)))
            for f in self.warnings:
                lines.append(f"  [{f.rule}] {f.message}")

        # Info
        if self.infos:
            lines.append("")
            lines.append(t("report.info_label"))
            for f in self.infos:
                lines.append(f"  [{f.rule}] {f.message}")

        # Summary
        lines.append("")
        if self.has_errors:
            result_key = "report.result_fail"
        elif self.warnings:
            result_key = "report.result_warn"
        else:
            result_key = "report.result_ok"
        lines.append(t(result_key, errors=len(self.errors), warnings=len(self.warnings)))
        lines.append("=" * 50)

        return "\n".join(lines)


def generate_report(raw: Dict[str, Any]) -> ValidationReport:
    """Generate a full validation report for a YAML dict."""
    from eulerstack.spec.schema import get_reserved_warnings
    # Clear any stale reserved warnings from prior parses so the report only
    # reflects the current YAML.
    get_reserved_warnings()

    report = ValidationReport()

    # Step 1: Schema + cross-field validation
    try:
        validate_v2(raw)
    except EulerStackError as e:
        report.schema_ok = False
        report.schema_error = e.message
        return report

    # Collect reserved-namespace warnings emitted during schema parsing
    # (Phase B0/B6). Each is surfaced as a realism-style Finding with
    # severity=WARNING and a dedicated rule tag so downstream tools can
    # group them.
    reserved_warnings = get_reserved_warnings()

    # Step 2: Normalize to IR
    try:
        ir = normalize_to_ir(raw)
        report.ir = ir
    except EulerStackError as e:
        report.schema_ok = False
        report.schema_error = t("report.normalization_failed", detail=e.message)
        return report

    # Step 3: Parameter estimation
    report.estimated_params = estimate_params(ir)

    # Step 4: Realism checks
    report.findings = run_realism_checks(ir)

    # Step 5: append reserved-namespace warnings
    for path, key in reserved_warnings:
        report.findings.append(Finding(
            rule="reserved_namespace",
            severity=Severity.WARNING,
            message=t("report.reserved_namespace_warning",
                      path=path, reserved_key=key),
        ))

    return report
