# eulerstack/spec/expressions.py
"""Phase B1.2 — `let:` + `${...}` reference/arithmetic pre-pass (Level 1).

This pre-pass runs BEFORE structural validation. It walks the raw YAML dict
tree and replaces any string of the form `${expr}` with the evaluated value.
The `let:` top-level block provides the variable scope.

## Allowed inside `${...}`

- Integer / float literals: `42`, `3.14`
- References: `let.<name>` — resolved from the `let:` block
- Binary arithmetic on the above: `+ - * / //`
- Parentheses for grouping

Branches, function calls, attribute access other than `let.*`, and string
operations are rejected. This is Level 1 per the v1 spec; Level 2 (conditionals
and bounded builtins) is reserved for a later minor version.

## Example

```yaml
let:
  n_heads: 16
  d_head: 64
model:
  d_model: ${let.n_heads * let.d_head}   # 1024
```

## Why a separate pre-pass?

Running this before validation keeps the validator untouched — it sees a plain
dict of concrete values. Testing remains independent of schema internals.
"""
from __future__ import annotations

import ast
import operator
from typing import Any, Dict

from .errors import ValidationError


_BIN_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
}
_UNARY_OPS = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}


def _eval_node(node: ast.AST, let_scope: Dict[str, Any], raw_expr: str) -> Any:
    if isinstance(node, ast.Expression):
        return _eval_node(node.body, let_scope, raw_expr)
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)):
            return node.value
        raise ValidationError(
            f"Expression literal must be numeric: {raw_expr!r}",
            fix="Only int/float literals are allowed inside ${...}",
        )
    if isinstance(node, ast.BinOp):
        op_fn = _BIN_OPS.get(type(node.op))
        if op_fn is None:
            raise ValidationError(
                f"Unsupported binary operator in expression: {raw_expr!r}",
                fix="Only + - * / // are allowed in ${...} (v1 Level 1)",
            )
        return op_fn(
            _eval_node(node.left, let_scope, raw_expr),
            _eval_node(node.right, let_scope, raw_expr),
        )
    if isinstance(node, ast.UnaryOp):
        op_fn = _UNARY_OPS.get(type(node.op))
        if op_fn is None:
            raise ValidationError(
                f"Unsupported unary operator in expression: {raw_expr!r}",
                fix="Only + and - unary prefixes are allowed",
            )
        return op_fn(_eval_node(node.operand, let_scope, raw_expr))
    if isinstance(node, ast.Attribute):
        # Only `let.<name>` is allowed.
        if isinstance(node.value, ast.Name) and node.value.id == "let":
            name = node.attr
            if name not in let_scope:
                raise ValidationError(
                    f"Undefined reference 'let.{name}' in expression: {raw_expr!r}",
                    fix=f"Define `{name}` in the top-level `let:` block",
                )
            val = let_scope[name]
            if not isinstance(val, (int, float)):
                raise ValidationError(
                    f"Reference 'let.{name}' is not numeric ({type(val).__name__})",
                    fix="Only numeric let: entries can be referenced in ${...}",
                )
            return val
        raise ValidationError(
            f"Only `let.<name>` references are allowed: {raw_expr!r}",
            fix="Use let.<name>; other attribute access is not permitted",
        )
    raise ValidationError(
        f"Disallowed syntax in expression: {raw_expr!r}",
        fix="Allowed: numeric literals, let.<name>, + - * / //, parentheses",
    )


def _evaluate(expr: str, let_scope: Dict[str, Any]) -> Any:
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as e:
        raise ValidationError(
            f"Invalid expression syntax: {expr!r} ({e.msg})",
            fix="Check that the expression parses; see docs/architectures/yaml_v1_spec.md §B1.2",
        )
    return _eval_node(tree, let_scope, expr)


def _try_resolve_string(s: str, let_scope: Dict[str, Any]) -> Any:
    """If the entire string is a `${...}` expression, replace it. Else return s."""
    s_stripped = s.strip()
    if s_stripped.startswith("${") and s_stripped.endswith("}"):
        inner = s_stripped[2:-1].strip()
        return _evaluate(inner, let_scope)
    # NOTE: partial interpolation ("hello ${x}") is intentionally not supported
    # in Level 1 — only full-string replacement. String concatenation will come
    # in Level 2 if needed.
    return s


def _walk(obj: Any, let_scope: Dict[str, Any]) -> Any:
    if isinstance(obj, dict):
        return {k: _walk(v, let_scope) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_walk(item, let_scope) for item in obj]
    if isinstance(obj, str):
        return _try_resolve_string(obj, let_scope)
    return obj


def resolve_expressions(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Return a new dict with all `${...}` strings replaced by evaluated values.

    The top-level `let:` block (if any) is consumed and removed from the
    returned dict. It is NOT a top-level key of the v1 schema from the
    validator's perspective — it is purely a pre-pass facility.

    If `let:` is absent, the dict is walked looking for `${...}` which will
    then fail with an "Undefined reference" error.
    """
    if not isinstance(raw, dict):
        return raw
    let_scope: Dict[str, Any] = {}
    if "let" in raw:
        let_raw = raw["let"]
        if not isinstance(let_raw, dict):
            raise ValidationError(
                "let: must be a mapping of name → numeric value",
                fix="Example:\n  let:\n    n_heads: 16\n    d_head: 64",
            )
        for k, v in let_raw.items():
            if not isinstance(k, str):
                raise ValidationError(
                    f"let: key must be a string, got {type(k).__name__}",
                    fix="Use identifier-like keys (e.g. n_heads, d_head)",
                )
            if not isinstance(v, (int, float)):
                raise ValidationError(
                    f"let.{k}: must be numeric (int or float), got {type(v).__name__}",
                    fix="Only numeric entries are allowed in let: (Level 1)",
                )
            let_scope[k] = v
    # Walk the rest of the dict with the populated scope.
    out = {k: _walk(v, let_scope) for k, v in raw.items() if k != "let"}
    return out
