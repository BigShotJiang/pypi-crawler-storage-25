# eulerstack/spec/capabilities.py
"""Capability metadata for mixer/ffn/state types."""
from __future__ import annotations

from typing import Dict, Set

MIXER_CAPABILITIES: Dict[str, Dict[str, bool]] = {
    "attention": {
        "supports_kv_cache": True,
        "supports_ssm_state": False,
        "supports_rope": True,
        "supports_chunkwise": False,
    },
    "mamba": {
        "supports_kv_cache": False,
        "supports_ssm_state": True,
        "supports_rope": False,
        "supports_chunkwise": False,
    },
    "retnet": {
        "supports_kv_cache": True,
        "supports_ssm_state": False,
        "supports_rope": True,
        "supports_chunkwise": True,
    },
    "hyena": {
        "supports_kv_cache": False,
        "supports_ssm_state": False,
        "supports_rope": False,
        "supports_chunkwise": False,
    },
}

FFN_CAPABILITIES: Dict[str, Dict[str, bool]] = {
    "mlp": {"supports_moe": False},
    "gated_mlp": {"supports_moe": False},
    "moe": {"supports_moe": True},
}

VALID_MIXER_TYPES: Set[str] = set(MIXER_CAPABILITIES.keys()) | {"branched", "ttt_layer"}
# Phase B2: extend MIXER_CAPABILITIES for the new mixer types.
MIXER_CAPABILITIES["branched"] = {
    "supports_kv_cache": False,     # determined by inner branches
    "supports_ssm_state": False,    # determined by inner branches
    "supports_rope": False,
    "supports_chunkwise": False,
}
MIXER_CAPABILITIES["ttt_layer"] = {
    "supports_kv_cache": False,
    "supports_ssm_state": True,     # inner state is updated at test time
    "supports_rope": False,
    "supports_chunkwise": False,
}
VALID_SELECTOR_TYPES: Set[str] = {"learned_gate", "top_k"}
VALID_TTT_INNER_MODELS: Set[str] = {"mlp", "linear"}
VALID_TTT_OPTIMIZERS: Set[str] = {"sgd", "adamw"}

# Phase B3: schedule extensions
VALID_MERGE_TYPES: Set[str] = {"concat", "add", "gated", "cross_attn"}
# v1.0 core integrators: discrete (distinct-weights flattening) and
# Neural-ODE discretizations `ode_euler` / `ode_rk4` (shared-weights,
# numerical integration in forward). See docs/architectures/rnd/.
VALID_INTEGRATOR_TYPES: Set[str] = {"discrete", "ode_euler", "ode_rk4"}
# `ode_adaptive` requires a dedicated library (e.g. torchdiffeq) with
# adaptive step-size control and is left to a plugin.
RESERVED_INTEGRATOR_TYPES: Set[str] = {"ode_adaptive"}
VALID_INTEGRATOR_OUTPUTS: Set[str] = {"token", "hidden"}

# Phase B4: template extensions
VALID_MEMORY_TYPES: Set[str] = {"neural_memory", "associative", "retrieval"}
VALID_MEMORY_PERSISTENCE: Set[str] = {"per_query", "session", "persistent"}
VALID_SHAPE_CHANGE_PROJECTIONS: Set[str] = {"linear", "conv1d", "mlp"}

# Phase B5: execution modes (R1 / Quiet-STaR metadata)
VALID_EXECUTION_TRANSITIONS: Set[str] = {"special_token", "budget_exhausted"}
VALID_FFN_TYPES: Set[str] = set(FFN_CAPABILITIES.keys())
VALID_NORM_TYPES: Set[str] = {"rmsnorm", "layernorm"}
VALID_NORM_POSITIONS: Set[str] = {"pre", "post"}
VALID_RESIDUAL_TYPES: Set[str] = {"sequential", "parallel"}
VALID_HEAD_TYPES: Set[str] = {"causal_lm"}
VALID_EMBEDDING_TYPES: Set[str] = {"learned"}
VALID_POSITIONAL_TYPES: Set[str] = {"rope", "none", "alibi"}
VALID_DTYPES: Set[str] = {"float32", "float16", "bfloat16"}
VALID_TOKENIZER_TYPES: Set[str] = {"hf"}
VALID_ROUTER_TYPES: Set[str] = {"softmax", "sigmoid"}
VALID_ACTIVATIONS: Set[str] = {"swiglu", "gelu", "relu"}
VALID_COMPILE_TARGETS: Set[str] = {"huggingface"}
VALID_MAMBA_VARIANTS: Set[str] = {"mamba1", "mamba2"}

# ── Reserved namespaces (Phase B0, v1) ─────────────────────────────────────
# Top-level keys or nested keys matching these prefixes bypass strict unknown-key
# rejection and produce a WARNING instead of an error. Intended for:
#   - experimental.*  — in-progress research (e.g. experimental.online_adaptation)
#   - future.*        — reserved for v1.x+ additions (e.g. future.symbolic_interface)
#   - vendor.<name>.* — third-party plugin extensions
# Enum fields (e.g. mixer.type) can also accept values with these prefixes; the
# compiler must fall back to a safe default when no plugin is registered.
RESERVED_KEY_PREFIXES: tuple = ("experimental.", "future.", "vendor.")


def is_reserved_key(key: str) -> bool:
    """True if the key is under a reserved namespace (warning, not error)."""
    return any(key.startswith(p) for p in RESERVED_KEY_PREFIXES)
