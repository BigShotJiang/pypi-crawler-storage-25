# eulerstack/spec/param_estimator.py
"""Parameter count estimator for ModelIR."""
from __future__ import annotations

from eulerstack.ir.types import ModelIR, LayerTemplateIR


def estimate_layer_params(layer: LayerTemplateIR, d_model: int, n_heads: int,
                          n_kv_heads: int, mlp_ratio: int) -> int:
    """Estimate parameter count for a single layer."""
    head_dim = d_model // n_heads
    params = 0

    # ── Mixer params ──
    mixer_type = layer.mixer.type
    if mixer_type == "attention":
        # Q: d_model -> d_model, K/V: d_model -> n_kv_heads * head_dim, O: d_model -> d_model
        q_params = d_model * d_model
        k_params = d_model * (n_kv_heads * head_dim)
        v_params = d_model * (n_kv_heads * head_dim)
        o_params = d_model * d_model
        params += q_params + k_params + v_params + o_params
    elif mixer_type == "mamba":
        expand = layer.mixer.config.get("expand", 2)
        d_inner = d_model * expand
        d_state = layer.mixer.config.get("d_state", 64)
        d_conv = layer.mixer.config.get("d_conv", 4)
        # in_proj + conv1d + x_proj + dt_proj + out_proj (approximate)
        params += d_model * d_inner * 2  # in_proj (2x for gate)
        params += d_inner * d_conv  # conv1d
        params += d_inner * (d_state * 2 + 1)  # x_proj (B, C, dt)
        params += d_inner * d_model  # out_proj
    elif mixer_type == "retnet":
        # Similar to attention with retention (Q, K, V, G, O)
        params += d_model * d_model * 4  # Q, K, V, O
        params += d_model  # gamma/decay
    elif mixer_type == "hyena":
        filter_hidden = layer.mixer.config.get("filter_hidden", 64)
        depth = layer.mixer.config.get("depth", 2)
        # in_proj + filter_gen + out_proj
        params += d_model * d_model * 2  # in/out proj
        params += d_model * filter_hidden * depth  # filter gen

    # ── FFN params ──
    ffn_dim = d_model * mlp_ratio
    if layer.ffn.type == "moe" and layer.ffn.moe is not None:
        n_experts = layer.ffn.moe.experts
        # Each expert: gate_proj + up_proj + down_proj (gated MLP)
        expert_params = d_model * ffn_dim * 3  # gate + up + down
        params += expert_params * n_experts
        # Router
        params += d_model * n_experts
    elif layer.ffn.type == "gated_mlp":
        # gate_proj + up_proj + down_proj
        params += d_model * ffn_dim * 3
    else:  # mlp
        params += d_model * ffn_dim * 2

    # ── Norm params (usually small) ──
    params += d_model * 2  # pre-norm + post-attn norm (or similar)

    return params


def estimate_params(ir: ModelIR) -> int:
    """Estimate total parameter count for a model IR."""
    d_model = ir.model.d_model
    n_heads = ir.model.n_heads
    n_kv_heads = ir.model.n_kv_heads
    mlp_ratio = ir.model.mlp_ratio
    vocab_size = ir.model.vocab_size

    total = 0

    # Embedding
    total += vocab_size * d_model

    # Layers
    for layer in ir.expanded_layers:
        total += estimate_layer_params(layer, d_model, n_heads, n_kv_heads, mlp_ratio)

    # Head
    if not ir.head.tie_weights:
        total += vocab_size * d_model  # separate LM head

    # Final norm
    total += d_model

    return total


def format_param_count(count: int) -> str:
    """Format parameter count as human-readable string (e.g., '0.82B', '2.1B', '125M')."""
    if count >= 1_000_000_000:
        return f"{count / 1_000_000_000:.2f}B"
    elif count >= 1_000_000:
        return f"{count / 1_000_000:.1f}M"
    elif count >= 1_000:
        return f"{count / 1_000:.1f}K"
    return str(count)
