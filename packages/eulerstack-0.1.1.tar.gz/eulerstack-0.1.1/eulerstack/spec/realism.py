# eulerstack/spec/realism.py
"""Heuristic realism rules for model architecture validation.

Each rule is a function that takes a ModelIR and returns a list of
(severity, message) tuples. Rules can be enabled/disabled by name.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Callable, Dict, List, Optional, Tuple

from eulerstack.ir.types import ModelIR
from eulerstack.spec.param_estimator import estimate_params, format_param_count


class Severity(str, Enum):
    ERROR = "ERROR"
    WARNING = "WARNING"
    INFO = "INFO"


@dataclass
class Finding:
    severity: Severity
    rule: str
    message: str


# ── Type alias for rule functions ──
RuleFunc = Callable[[ModelIR], List[Finding]]

# ── Global rule registry ──
_RULES: Dict[str, RuleFunc] = {}


def register_rule(name: str):
    """Decorator to register a realism rule."""
    def decorator(func: RuleFunc) -> RuleFunc:
        _RULES[name] = func
        return func
    return decorator


def run_realism_checks(ir: ModelIR, *, disabled: Optional[set] = None) -> List[Finding]:
    """Run all registered realism rules on a ModelIR."""
    disabled = disabled or set()
    findings: List[Finding] = []
    for name, func in _RULES.items():
        if name not in disabled:
            findings.extend(func(ir))
    return findings


# ══════════════════════════════════════════════════════════════════════
# Rules
# ══════════════════════════════════════════════════════════════════════

@register_rule("head_dim_range")
def check_head_dim_range(ir: ModelIR) -> List[Finding]:
    """Head dimension should be between 32 and 256."""
    head_dim = ir.model.d_model // ir.model.n_heads
    findings = []
    if head_dim < 32:
        findings.append(Finding(
            Severity.WARNING, "head_dim_range",
            f"head_dim={head_dim} is very small (< 32). Most models use 64-128.",
        ))
    if head_dim > 256:
        findings.append(Finding(
            Severity.WARNING, "head_dim_range",
            f"head_dim={head_dim} is very large (> 256). Most models use 64-128.",
        ))
    return findings


@register_rule("param_count_info")
def check_param_count(ir: ModelIR) -> List[Finding]:
    """Report estimated parameter count."""
    est = estimate_params(ir)
    return [Finding(
        Severity.INFO, "param_count_info",
        f"Estimated parameters: {format_param_count(est)} ({est:,})",
    )]


@register_rule("target_params_mismatch")
def check_target_params_mismatch(ir: ModelIR) -> List[Finding]:
    """Warn if estimated params deviate >30% from target_params."""
    if ir.model.target_params is None:
        return []
    est = estimate_params(ir)
    target = ir.model.target_params
    if target <= 0:
        return []
    ratio = est / target
    if ratio < 0.7:
        return [Finding(
            Severity.WARNING, "target_params_mismatch",
            f"Estimated {format_param_count(est)} is {ratio:.0%} of target {format_param_count(target)} (under by >{30}%)",
        )]
    if ratio > 1.3:
        return [Finding(
            Severity.WARNING, "target_params_mismatch",
            f"Estimated {format_param_count(est)} is {ratio:.0%} of target {format_param_count(target)} (over by >{30}%)",
        )]
    return []


@register_rule("moe_expert_ratio")
def check_moe_expert_ratio(ir: ModelIR) -> List[Finding]:
    """Check MoE experts/top_k ratio reasonability."""
    findings = []
    for layer in ir.expanded_layers:
        if layer.ffn.type == "moe" and layer.ffn.moe:
            moe = layer.ffn.moe
            if moe.top_k > moe.experts:
                findings.append(Finding(
                    Severity.ERROR, "moe_expert_ratio",
                    f"Template '{layer.name}': top_k ({moe.top_k}) > experts ({moe.experts})",
                ))
            if moe.experts > 64:
                findings.append(Finding(
                    Severity.WARNING, "moe_expert_ratio",
                    f"Template '{layer.name}': {moe.experts} experts is unusually high",
                ))
            if moe.capacity_factor < 0.5:
                findings.append(Finding(
                    Severity.WARNING, "moe_expert_ratio",
                    f"Template '{layer.name}': capacity_factor={moe.capacity_factor} is very low (< 0.5)",
                ))
    return findings


@register_rule("seq_len_ratio")
def check_seq_len_ratio(ir: ModelIR) -> List[Finding]:
    """max_seq_len >> d_model may be impractical for attention-heavy models."""
    findings = []
    ratio = ir.model.max_seq_len / ir.model.d_model
    has_attention = any(l.mixer.type == "attention" for l in ir.expanded_layers)
    if has_attention and ratio > 64:
        findings.append(Finding(
            Severity.WARNING, "seq_len_ratio",
            f"max_seq_len/d_model ratio is {ratio:.0f}x — attention memory cost may be extreme",
        ))
    return findings


@register_rule("dropout_regularization")
def check_dropout_regularization(ir: ModelIR) -> List[Finding]:
    """Complex models with zero dropout and no checkpointing hint."""
    n_layers = len(ir.expanded_layers)
    if n_layers > 16 and ir.training_hints.dropout == 0.0 and not ir.training_hints.checkpointing:
        has_complex = any(
            l.mixer.type in ("mamba", "hyena") or (l.ffn.type == "moe")
            for l in ir.expanded_layers
        )
        if has_complex:
            return [Finding(
                Severity.WARNING, "dropout_regularization",
                f"Complex {n_layers}-layer model with dropout=0 and no checkpointing hint",
            )]
    return []


@register_rule("family_hint_consistency")
def check_family_hint(ir: ModelIR) -> List[Finding]:
    """Check if family_hint roughly matches actual structure."""
    hint = ir.model.family_hint
    if not hint:
        return []

    findings = []
    mixer_types = {l.mixer.type for l in ir.expanded_layers}
    hint_lower = hint.lower()

    if "llama" in hint_lower and mixer_types != {"attention"}:
        findings.append(Finding(
            Severity.WARNING, "family_hint_consistency",
            f"family_hint='{hint}' but model uses mixer types: {mixer_types}",
        ))
    if "mamba" in hint_lower and "mamba" not in mixer_types:
        findings.append(Finding(
            Severity.WARNING, "family_hint_consistency",
            f"family_hint='{hint}' but no mamba mixer found",
        ))
    return findings


@register_rule("vocab_tokenizer_consistency")
def check_vocab_tokenizer(ir: ModelIR) -> List[Finding]:
    """Common tokenizer/vocab_size mismatches."""
    findings = []
    pretrained = ir.tokenizer_contract.pretrained.lower()
    vs = ir.model.vocab_size

    # GPT2 tokenizer has 50257 tokens
    if "gpt2" in pretrained and vs < 50257:
        findings.append(Finding(
            Severity.WARNING, "vocab_tokenizer_consistency",
            f"Tokenizer '{ir.tokenizer_contract.pretrained}' has 50257 tokens but vocab_size={vs}",
        ))
    return findings


@register_rule("tie_weight_consistency")
def check_tie_weights(ir: ModelIR) -> List[Finding]:
    """Embedding tie and head tie should be consistent."""
    findings = []
    emb_tie = ir.embedding.tie_word_embeddings
    head_tie = ir.head.tie_weights
    if emb_tie != head_tie:
        findings.append(Finding(
            Severity.WARNING, "tie_weight_consistency",
            f"embedding.tie_word_embeddings={emb_tie} but head.tie_weights={head_tie} — usually these match",
        ))
    return findings


@register_rule("rope_scaling_factor")
def check_rope_scaling(ir: ModelIR) -> List[Finding]:
    """RoPE scaling factor sanity."""
    findings = []
    if ir.embedding.rope_scaling:
        factor = ir.embedding.rope_scaling.get("factor", 1.0)
        if factor <= 0:
            findings.append(Finding(
                Severity.ERROR, "rope_scaling_factor",
                f"rope_scaling.factor={factor} must be positive",
            ))
        elif factor > 32:
            findings.append(Finding(
                Severity.WARNING, "rope_scaling_factor",
                f"rope_scaling.factor={factor} is unusually high (> 32)",
            ))
    return findings


@register_rule("negative_dropout")
def check_negative_dropout(ir: ModelIR) -> List[Finding]:
    """Dropout must not be negative."""
    findings = []
    if ir.training_hints.dropout < 0:
        findings.append(Finding(
            Severity.ERROR, "negative_dropout",
            f"training_hints.dropout={ir.training_hints.dropout} is negative",
        ))
    # Check per-template attention dropout
    for layer in ir.expanded_layers:
        if layer.mixer.type == "attention":
            attn_drop = layer.mixer.config.get("attn_drop", 0.0)
            if isinstance(attn_drop, (int, float)) and attn_drop < 0:
                findings.append(Finding(
                    Severity.ERROR, "negative_dropout",
                    f"Template '{layer.name}': attn_drop={attn_drop} is negative",
                ))
    return findings


# ── Phase B realism checks (v1 new primitives) ───────────────────────────

@register_rule("mla_latent_dim_range")
def check_mla_latent_dim(ir: ModelIR) -> List[Finding]:
    """Warn on MLA `latent_dim` values that are structurally odd.

    - latent_dim < d_model / 16   → too aggressive; quality likely suffers
    - latent_dim > d_model × 3/4  → compression savings minimal, barely worth it
    Typical healthy range is d_model/8 ≤ latent_dim ≤ d_model/2.
    """
    findings = []
    d_model = ir.model.d_model
    if d_model <= 0:
        return findings
    seen = set()  # avoid duplicate findings for repeated layers
    for layer in ir.expanded_layers:
        if layer.mixer.type != "attention":
            continue
        latent_dim = layer.mixer.config.get("latent_dim")
        if latent_dim is None:
            continue
        key = (layer.name, latent_dim)
        if key in seen:
            continue
        seen.add(key)
        if latent_dim < d_model // 16:
            findings.append(Finding(
                Severity.WARNING, "mla_latent_dim_range",
                f"Template '{layer.name}': latent_dim={latent_dim} < d_model/16"
                f" ({d_model // 16}). Very aggressive compression; quality likely"
                f" degrades. Recommended: d_model/8–d_model/2.",
            ))
        elif latent_dim > d_model * 3 // 4:
            findings.append(Finding(
                Severity.WARNING, "mla_latent_dim_range",
                f"Template '{layer.name}': latent_dim={latent_dim} > 3·d_model/4"
                f" ({d_model * 3 // 4}). KV savings are marginal; consider"
                f" removing MLA to simplify.",
            ))
    return findings


@register_rule("execution_modes_budget")
def check_execution_modes_budget(ir: ModelIR) -> List[Finding]:
    """Sum of execution_modes[*].max_tokens should fit inside max_seq_len.

    In R1-style 2-phase generation both phases share the same KV cache.
    If think.max_tokens + answer.max_tokens exceeds max_seq_len, decoding
    will hit the context limit mid-answer.
    """
    if ir.execution_modes is None:
        return []
    total = sum(m.max_tokens for m in ir.execution_modes)
    if total > ir.model.max_seq_len:
        return [Finding(
            Severity.WARNING, "execution_modes_budget",
            f"execution_modes total max_tokens ({total}) exceeds"
            f" model.max_seq_len ({ir.model.max_seq_len}). Decoding will"
            f" truncate the answer phase. Lower a phase budget or raise"
            f" max_seq_len.",
        )]
    return []


@register_rule("depth_gating_capacity_extreme")
def check_depth_gating_capacity(ir: ModelIR) -> List[Finding]:
    """Warn on depth_gating capacity close to 0 or 1.

    Schema only rejects capacity outside (0, 1]. Values <0.1 rarely train
    stably; capacity=1.0 is a no-op and usually a mistake.
    """
    findings = []
    for i, se in enumerate(ir.layer_schedule):
        if se.depth_gating is None:
            continue
        cap = se.depth_gating.capacity
        if cap < 0.1:
            findings.append(Finding(
                Severity.WARNING, "depth_gating_capacity_extreme",
                f"layer_schedule[{i}].depth_gating.capacity={cap:.3f} is very"
                f" low (<0.1). Most tokens bypass the layer; training may"
                f" under-utilise the model.",
            ))
        elif cap >= 0.99:
            findings.append(Finding(
                Severity.WARNING, "depth_gating_capacity_extreme",
                f"layer_schedule[{i}].depth_gating.capacity={cap:.3f} ≈ 1.0 is"
                f" effectively a no-op. Remove depth_gating instead.",
            ))
    return findings


@register_rule("integrator_steps_range")
def check_integrator_steps(ir: ModelIR) -> List[Finding]:
    """Warn when integrator.steps is above the typical window.

    discrete integrators above K=32 multiply compute substantially and are
    rarely used in published work. Treat as a smell.
    """
    findings = []
    for i, se in enumerate(ir.layer_schedule):
        if se.integrator is None:
            continue
        steps = se.integrator.steps
        if steps > 32:
            findings.append(Finding(
                Severity.WARNING, "integrator_steps_range",
                f"layer_schedule[{i}].integrator.steps={steps} is unusually"
                f" large. Each step runs the body template once; total FLOPs"
                f" scale linearly. Published Universal Transformer / PonderNet"
                f" / Diffusion-LM typically use K ≤ 16.",
            ))
    return findings


@register_rule("memory_hidden_range")
def check_memory_hidden(ir: ModelIR) -> List[Finding]:
    """Warn on Titans memory with hidden size that dwarfs d_model.

    memory.params.hidden much larger than 4·d_model inflates parameter
    count heavily with marginal returns in published Titans results.
    """
    findings = []
    d_model = ir.model.d_model
    seen = set()
    for layer in ir.expanded_layers:
        if layer.memory is None:
            continue
        key = (layer.name, layer.memory.hidden)
        if key in seen:
            continue
        seen.add(key)
        if layer.memory.hidden > 8 * d_model:
            findings.append(Finding(
                Severity.WARNING, "memory_hidden_range",
                f"Template '{layer.name}': memory.hidden={layer.memory.hidden}"
                f" > 8·d_model ({8 * d_model}). Very large memory module;"
                f" consider ≤ 4·d_model first.",
            ))
    return findings


@register_rule("shape_change_direction")
def check_shape_change(ir: ModelIR) -> List[Finding]:
    """Shape-change layers are Hourglass-style narrowing. Warn on widening."""
    findings = []
    d_model = ir.model.d_model
    for name, tmpl in ir.layer_templates.items():
        if tmpl.shape_change is None:
            continue
        d_out = tmpl.shape_change.d_out
        if d_out > d_model:
            findings.append(Finding(
                Severity.WARNING, "shape_change_direction",
                f"Template '{name}': shape_change.d_out={d_out} >"
                f" model.d_model ({d_model}). Hourglass convention is to"
                f" narrow (d_out < d_model). Widening is untested.",
            ))
    return findings


# Note: branched.selector.top_k > branch count is now a schema-level
# validation (raised in _validate_branched). No realism rule needed.


@register_rule("ttt_inner_lr_range")
def check_ttt_inner_lr(ir: ModelIR) -> List[Finding]:
    """TTT inner_lr outside [1e-6, 1.0] is almost always a mistake."""
    findings = []
    for name, tmpl in ir.layer_templates.items():
        if tmpl.mixer.type != "ttt_layer":
            continue
        lr = tmpl.mixer.config.get("inner_lr", 0.01)
        if not (1e-6 <= lr <= 1.0):
            findings.append(Finding(
                Severity.WARNING, "ttt_inner_lr_range",
                f"Template '{name}': ttt.inner_lr={lr} is outside the"
                f" typical range [1e-6, 1.0]. Sun et al. 2024 uses 1e-3 to 1e-2.",
            ))
    return findings


@register_rule("layer_count_info")
def check_layer_count(ir: ModelIR) -> List[Finding]:
    """Report layer composition."""
    from collections import Counter
    mixer_counts = Counter(l.mixer.type for l in ir.expanded_layers)
    parts = [f"{t}:{c}" for t, c in sorted(mixer_counts.items())]
    return [Finding(
        Severity.INFO, "layer_count_info",
        f"Total layers: {len(ir.expanded_layers)} ({', '.join(parts)})",
    )]
