# eulerstack/spec/errors.py
"""Error taxonomy for EulerStack v1 pipeline."""
from __future__ import annotations


class EulerStackError(Exception):
    """Base class for all EulerStack errors."""

    category: str = "Error"

    def __init__(self, message: str, *, fix: str = "", see: str = "docs/architectures/yaml_v1_spec.md"):
        self.message = message
        self.fix = fix
        self.see = see
        super().__init__(message)

    def format_3line(self) -> str:
        return (
            f"{self.category}: {self.message}\n"
            f"Fix: {self.fix}\n"
            f"See: {self.see}"
        )


class ValidationError(EulerStackError):
    """Schema validation failure (unknown keys, missing fields, type/enum errors)."""
    category = "ValidationError"


class NormalizationError(EulerStackError):
    """IR normalization failure."""
    category = "NormalizationError"


class CompatibilityError(EulerStackError):
    """Cross-field compatibility violation (mixer/state, ffn/moe, etc)."""
    category = "CompatibilityError"


class CompileError(EulerStackError):
    """Compilation failure (IR → runtime config)."""
    category = "CompileError"
