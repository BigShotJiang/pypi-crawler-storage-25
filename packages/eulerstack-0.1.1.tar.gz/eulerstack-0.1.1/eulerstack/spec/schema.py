# eulerstack/spec/schema.py
"""YAML v1 schema parser — parses and structurally validates raw YAML dicts.

Version history: this schema was internally developed as v2 during pre-release
and then unified as v1 for the first public release (no prior public v1 exists).
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Set

from .errors import ValidationError
from .capabilities import (
    VALID_MIXER_TYPES,
    VALID_FFN_TYPES,
    VALID_NORM_TYPES,
    VALID_NORM_POSITIONS,
    VALID_RESIDUAL_TYPES,
    VALID_HEAD_TYPES,
    VALID_EMBEDDING_TYPES,
    VALID_POSITIONAL_TYPES,
    VALID_DTYPES,
    VALID_TOKENIZER_TYPES,
    VALID_ROUTER_TYPES,
    VALID_ACTIVATIONS,
    VALID_COMPILE_TARGETS,
    VALID_MAMBA_VARIANTS,
    is_reserved_key,
)


# ── Reserved-namespace warning collector (Phase B0) ───────────────────────
# parse_v2_yaml appends (path, key) tuples here for reserved-prefix keys it
# encountered. Callers (report/CLI) can inspect this after a parse.
_RESERVED_WARNINGS: list = []


def get_reserved_warnings() -> list:
    """Return and clear the list of (path, key) reserved-namespace warnings."""
    global _RESERVED_WARNINGS
    out = list(_RESERVED_WARNINGS)
    _RESERVED_WARNINGS = []
    return out


def _emit_reserved_warning(path: str, key: str) -> None:
    _RESERVED_WARNINGS.append((path, key))


VALID_TOP_LEVEL_KEYS: Set[str] = {
    "schema_version",
    "model",
    "tokenizer_contract",
    "embedding",
    "layer_templates",
    "layer_schedule",
    "head",
    "training_hints",
    "compatibility",
    # Phase B1.2 pre-pass block (stripped before structural validation,
    # but listed here so that the strict unknown-key check does not fire
    # in the rare case the pre-pass is bypassed).
    "let",
    # Phase B5: reasoning-mode metadata (R1 / Quiet-STaR). Declarative
    # only — architecture is unchanged; the training loop / generate()
    # honours the phase split.
    "execution_modes",
    "transition",
}

_MODEL_KEYS: Set[str] = {
    "name", "family_hint", "d_model", "vocab_size", "max_seq_len",
    "n_heads", "n_kv_heads", "mlp_ratio", "dtype", "target_params",
}

_TOKENIZER_KEYS: Set[str] = {"type", "pretrained", "add_bos", "add_eos", "pad_token"}
_EMBEDDING_KEYS: Set[str] = {"type", "positional", "rope_theta", "rope_scaling", "tie_word_embeddings"}
_ROPE_SCALING_KEYS: Set[str] = {"type", "factor"}
_HEAD_KEYS: Set[str] = {"type", "tie_weights"}
_TRAINING_HINTS_KEYS: Set[str] = {"init", "dropout", "checkpointing", "seed"}
_COMPATIBILITY_KEYS: Set[str] = {"compile_target"}

_MIXER_KEYS: Set[str] = {"type", "attention", "mamba", "retnet", "hyena", "branched", "ttt"}
# Phase B2.1: attention gains `latent_dim` (DeepSeek-V3 MLA style).
# Phase B2.2: `branched` is a new mixer type with branches/selector sub-objects.
# Phase B2.3: `ttt` sub-object on ttt_layer mixer type.
_ATTENTION_KEYS: Set[str] = {"qkv_bias", "attn_drop", "window", "latent_dim"}
_MAMBA_KEYS: Set[str] = {"variant", "d_state", "d_conv", "expand"}
_RETNET_KEYS: Set[str] = {"chunkwise", "chunk_size", "rope"}
_HYENA_KEYS: Set[str] = {"depth", "filter_hidden", "filter_decay"}
_BRANCHED_KEYS: Set[str] = {"branches", "selector"}
_SELECTOR_KEYS: Set[str] = {"type", "top_k", "input"}
_TTT_KEYS: Set[str] = {"inner_model", "inner_optimizer", "inner_lr", "inner_steps_per_token"}
_TTT_INNER_MODEL_KEYS: Set[str] = {"type", "hidden"}

_FFN_KEYS: Set[str] = {"type", "activation", "bias", "moe"}
_MOE_KEYS: Set[str] = {"experts", "top_k", "router", "z_loss", "capacity_factor"}
_NORM_KEYS: Set[str] = {"type", "position"}
_RESIDUAL_KEYS: Set[str] = {"type", "scaling"}
_STATE_KEYS: Set[str] = {"kv_cache", "ssm_state"}

_TEMPLATE_KEYS: Set[str] = {"mixer", "ffn", "norm", "residual", "state", "memory", "shape_change"}
# Phase B4.1: template.memory (Titans-style parametric memory that may update at test time).
_MEMORY_KEYS: Set[str] = {"type", "update_at_inference", "params", "inner_lr", "persistence"}
_MEMORY_PARAMS_KEYS: Set[str] = {"hidden"}
# Phase B4.2: template.shape_change (Hourglass-style shape-changing layer).
_SHAPE_CHANGE_KEYS: Set[str] = {"d_out", "projection"}
# Phase B5: execution_modes (reasoning phase declaration)
_EXEC_MODE_KEYS: Set[str] = {
    "name", "max_tokens", "kv_share", "loss_weight",
    "visible_to_user", "per_token_rationale",
}
_TRANSITION_KEYS: Set[str] = {"type", "token"}
# Phase B3: schedule entry is a tagged union. A plain entry has `template`;
# a parallel entry has `parallel`+`merge`; an integrator entry has `integrator`.
_SCHEDULE_ENTRY_KEYS: Set[str] = {
    "template", "repeat", "override", "depth_gating",   # plain
    "parallel", "merge",                                  # monoidal branch
    "integrator",                                         # recursive/iter branch
}
_PARALLEL_STREAM_KEYS: Set[str] = {"stream", "body"}
_MERGE_KEYS: Set[str] = {"type", "projection", "from", "to"}
_INTEGRATOR_KEYS: Set[str] = {"type", "steps", "body", "output"}

# ── Per-layer override (Phase B1.1) ───────────────────────────────────────
# Whitelist: which sub-paths inside a layer may be overridden at schedule time.
# Changing `mixer.type` is intentionally NOT allowed — that requires a new
# template. Param-count-affecting fields are excluded.
_OVERRIDE_TOP_KEYS: Set[str] = {"residual", "attention", "norm", "ffn"}
_OVERRIDE_RESIDUAL_KEYS: Set[str] = {"scaling"}
_OVERRIDE_ATTENTION_KEYS: Set[str] = {"window", "attn_drop"}
_OVERRIDE_NORM_KEYS: Set[str] = {"type", "position"}
_OVERRIDE_FFN_KEYS: Set[str] = {"activation"}

# ── Depth gating (Phase B3.1) ─────────────────────────────────────────────
_DEPTH_GATING_KEYS: Set[str] = {"enabled", "capacity", "router"}


def _check_unknown(raw: Dict[str, Any], allowed: Set[str], path: str) -> None:
    from eulerstack.i18n import t  # local import to avoid circular at module load
    if not isinstance(raw, dict):
        raise ValidationError(
            t("error.schema.expected_mapping.msg", path=path, type=type(raw).__name__),
            fix=t("error.schema.expected_mapping.fix", path=path),
        )
    unknown = set(raw.keys()) - allowed
    if unknown:
        # Separate reserved-namespace keys (warning) from truly unknown keys (error).
        reserved = {k for k in unknown if is_reserved_key(k)}
        real_unknown = unknown - reserved
        for k in reserved:
            _emit_reserved_warning(path, k)
        if real_unknown:
            keys = ", ".join(sorted(real_unknown))
            allowed_str = ", ".join(sorted(allowed))
            raise ValidationError(
                t("error.schema.unknown_key.msg", path=path, keys=keys),
                fix=t("error.schema.unknown_key.fix", keys=keys, allowed=allowed_str),
            )


def _require_field(raw: Dict[str, Any], field: str, path: str) -> Any:
    from eulerstack.i18n import t
    if field not in raw:
        raise ValidationError(
            t("error.schema.missing_field.msg", path=path, field=field),
            fix=t("error.schema.missing_field.fix", path=path, field=field),
        )
    return raw[field]


def _check_enum(value: Any, allowed: Set[str], path: str) -> None:
    from eulerstack.i18n import t
    if value not in allowed:
        raise ValidationError(
            t("error.schema.invalid_enum.msg", path=path, value=value),
            fix=t("error.schema.invalid_enum.fix", allowed=", ".join(sorted(allowed))),
        )


def _check_positive_int(value: Any, path: str) -> int:
    from eulerstack.i18n import t
    try:
        v = int(value)
    except (TypeError, ValueError):
        raise ValidationError(
            t("error.schema.expected_pos_int.msg", path=path, value=value),
            fix=t("error.schema.expected_pos_int.fix", path=path),
        )
    if v <= 0:
        raise ValidationError(
            t("error.schema.must_be_positive.msg", path=path, value=v),
            fix=t("error.schema.expected_pos_int.fix", path=path),
        )
    return v


def _validate_model(raw: Dict[str, Any]) -> None:
    _check_unknown(raw, _MODEL_KEYS, "model")
    _require_field(raw, "name", "model")
    _require_field(raw, "d_model", "model")
    _require_field(raw, "vocab_size", "model")
    _require_field(raw, "max_seq_len", "model")
    _require_field(raw, "n_heads", "model")

    _check_positive_int(raw["d_model"], "model.d_model")
    _check_positive_int(raw["vocab_size"], "model.vocab_size")
    _check_positive_int(raw["max_seq_len"], "model.max_seq_len")
    _check_positive_int(raw["n_heads"], "model.n_heads")

    if "mlp_ratio" in raw:
        _check_positive_int(raw["mlp_ratio"], "model.mlp_ratio")
    if "dtype" in raw:
        _check_enum(raw["dtype"], VALID_DTYPES, "model.dtype")
    if "n_kv_heads" in raw:
        _check_positive_int(raw["n_kv_heads"], "model.n_kv_heads")


def _validate_tokenizer(raw: Dict[str, Any]) -> None:
    _check_unknown(raw, _TOKENIZER_KEYS, "tokenizer_contract")
    _require_field(raw, "type", "tokenizer_contract")
    _check_enum(raw["type"], VALID_TOKENIZER_TYPES, "tokenizer_contract.type")
    _require_field(raw, "pretrained", "tokenizer_contract")


def _validate_embedding(raw: Dict[str, Any]) -> None:
    _check_unknown(raw, _EMBEDDING_KEYS, "embedding")
    _require_field(raw, "type", "embedding")
    _check_enum(raw["type"], VALID_EMBEDDING_TYPES, "embedding.type")
    _require_field(raw, "positional", "embedding")
    _check_enum(raw["positional"], VALID_POSITIONAL_TYPES, "embedding.positional")

    if "rope_scaling" in raw and raw["rope_scaling"] is not None:
        scaling = raw["rope_scaling"]
        if isinstance(scaling, dict):
            _check_unknown(scaling, _ROPE_SCALING_KEYS, "embedding.rope_scaling")


def _validate_mixer(raw: Dict[str, Any], path: str) -> None:
    _check_unknown(raw, _MIXER_KEYS, path)
    mixer_type = _require_field(raw, "type", path)
    _check_enum(mixer_type, VALID_MIXER_TYPES, f"{path}.type")

    # Sub-object exclusivity: only the sub-object matching type= may be present.
    sub_keys = {"attention", "mamba", "retnet", "hyena", "branched", "ttt"}
    # Phase B2.3: `ttt` is the sub-object for mixer.type == "ttt_layer".
    type_to_subkey = {
        "attention": "attention", "mamba": "mamba", "retnet": "retnet",
        "hyena": "hyena", "branched": "branched", "ttt_layer": "ttt",
    }
    expected_sub = type_to_subkey.get(mixer_type)
    for sk in sub_keys:
        if sk in raw and sk != expected_sub:
            raise ValidationError(
                f"{path}: sub-object '{sk}' not allowed when type='{mixer_type}'",
                fix=f"Remove '{sk}' from {path} or change type accordingly",
            )

    # Validate sub-object contents
    if "attention" in raw and isinstance(raw["attention"], dict):
        _check_unknown(raw["attention"], _ATTENTION_KEYS, f"{path}.attention")
        # Phase B2.1: latent_dim (MLA) must be a positive int if set.
        if raw["attention"].get("latent_dim") is not None:
            _check_positive_int(raw["attention"]["latent_dim"],
                                f"{path}.attention.latent_dim")
    if "mamba" in raw and isinstance(raw["mamba"], dict):
        _check_unknown(raw["mamba"], _MAMBA_KEYS, f"{path}.mamba")
        if "variant" in raw["mamba"]:
            _check_enum(raw["mamba"]["variant"], VALID_MAMBA_VARIANTS, f"{path}.mamba.variant")
    if "retnet" in raw and isinstance(raw["retnet"], dict):
        _check_unknown(raw["retnet"], _RETNET_KEYS, f"{path}.retnet")
    if "hyena" in raw and isinstance(raw["hyena"], dict):
        _check_unknown(raw["hyena"], _HYENA_KEYS, f"{path}.hyena")
    if "branched" in raw and isinstance(raw["branched"], dict):
        _validate_branched(raw["branched"], f"{path}.branched")
    if "ttt" in raw and isinstance(raw["ttt"], dict):
        _validate_ttt(raw["ttt"], f"{path}.ttt")


def _validate_branched(raw: Dict[str, Any], path: str) -> None:
    """Phase B2.2: branched mixer — routes tokens across inner mixers."""
    from .capabilities import VALID_SELECTOR_TYPES
    _check_unknown(raw, _BRANCHED_KEYS, path)
    branches = _require_field(raw, "branches", path)
    if not isinstance(branches, dict) or len(branches) < 2:
        raise ValidationError(
            f"{path}.branches: must be a mapping of at least 2 named mixers",
            fix="Define at least two branches, e.g. {ssm: {...}, attn: {...}}",
        )
    for bname, bdef in branches.items():
        if not isinstance(bdef, dict):
            raise ValidationError(
                f"{path}.branches.{bname}: must be a mapping",
                fix="Each branch is a mixer spec (type + sub-object)",
            )
        # Each branch is itself a mixer — recurse. Forbid nested branched to
        # keep semantics simple (no branched-of-branched in v1).
        if bdef.get("type") == "branched":
            raise ValidationError(
                f"{path}.branches.{bname}: nested branched mixers are not allowed in v1",
                fix="Flatten the branches into this level",
            )
        _validate_mixer(bdef, f"{path}.branches.{bname}")
    selector = raw.get("selector") or {}
    if not isinstance(selector, dict):
        raise ValidationError(
            f"{path}.selector: must be a mapping",
            fix="Provide selector: {type: learned_gate, top_k: 1}",
        )
    _check_unknown(selector, _SELECTOR_KEYS, f"{path}.selector")
    if "type" in selector:
        _check_enum(selector["type"], VALID_SELECTOR_TYPES, f"{path}.selector.type")
    if "top_k" in selector:
        top_k = _check_positive_int(selector["top_k"], f"{path}.selector.top_k")
        if top_k > len(branches):
            raise ValidationError(
                f"{path}.selector.top_k={top_k} exceeds branch count ({len(branches)})",
                fix=(
                    f"top_k must be ≤ number of branches. Either lower top_k or"
                    f" add more branches to {path}.branches."
                ),
            )


def _validate_ttt(raw: Dict[str, Any], path: str) -> None:
    """Phase B2.3: TTT layer config (Sun et al. 2024)."""
    from .capabilities import VALID_TTT_INNER_MODELS, VALID_TTT_OPTIMIZERS
    _check_unknown(raw, _TTT_KEYS, path)
    inner = raw.get("inner_model") or {}
    if inner:
        if not isinstance(inner, dict):
            raise ValidationError(
                f"{path}.inner_model: must be a mapping",
                fix="inner_model: {type: mlp, hidden: 256}",
            )
        _check_unknown(inner, _TTT_INNER_MODEL_KEYS, f"{path}.inner_model")
        if "type" in inner:
            _check_enum(inner["type"], VALID_TTT_INNER_MODELS,
                        f"{path}.inner_model.type")
        if "hidden" in inner:
            _check_positive_int(inner["hidden"], f"{path}.inner_model.hidden")
    if "inner_optimizer" in raw:
        _check_enum(raw["inner_optimizer"], VALID_TTT_OPTIMIZERS,
                    f"{path}.inner_optimizer")
    if "inner_lr" in raw:
        lr = raw["inner_lr"]
        if not isinstance(lr, (int, float)) or float(lr) <= 0:
            raise ValidationError(
                f"{path}.inner_lr: must be a positive float",
                fix="Use a value like 0.01 (1e-2)",
            )
    if "inner_steps_per_token" in raw:
        _check_positive_int(raw["inner_steps_per_token"],
                            f"{path}.inner_steps_per_token")


def _validate_ffn(raw: Dict[str, Any], path: str) -> None:
    _check_unknown(raw, _FFN_KEYS, path)
    ffn_type = _require_field(raw, "type", path)
    _check_enum(ffn_type, VALID_FFN_TYPES, f"{path}.type")

    if "activation" in raw:
        _check_enum(raw["activation"], VALID_ACTIVATIONS, f"{path}.activation")

    if ffn_type == "moe":
        moe = _require_field(raw, "moe", path)
        if isinstance(moe, dict):
            _check_unknown(moe, _MOE_KEYS, f"{path}.moe")
            _require_field(moe, "experts", f"{path}.moe")
            _require_field(moe, "top_k", f"{path}.moe")
            _check_positive_int(moe["experts"], f"{path}.moe.experts")
            _check_positive_int(moe["top_k"], f"{path}.moe.top_k")
            if "router" in moe:
                _check_enum(moe["router"], VALID_ROUTER_TYPES, f"{path}.moe.router")
    else:
        if "moe" in raw and raw["moe"] is not None:
            raise ValidationError(
                f"{path}: 'moe' section not allowed when type='{ffn_type}'",
                fix=f"Remove 'moe' from {path} or change type to 'moe'",
            )


def _validate_template(raw: Dict[str, Any], name: str) -> None:
    path = f"layer_templates.{name}"
    _check_unknown(raw, _TEMPLATE_KEYS, path)
    _require_field(raw, "mixer", path)
    _require_field(raw, "ffn", path)

    _validate_mixer(raw["mixer"], f"{path}.mixer")
    _validate_ffn(raw["ffn"], f"{path}.ffn")

    if "norm" in raw and isinstance(raw["norm"], dict):
        _check_unknown(raw["norm"], _NORM_KEYS, f"{path}.norm")
        if "type" in raw["norm"]:
            _check_enum(raw["norm"]["type"], VALID_NORM_TYPES, f"{path}.norm.type")
        if "position" in raw["norm"]:
            _check_enum(raw["norm"]["position"], VALID_NORM_POSITIONS, f"{path}.norm.position")

    if "residual" in raw and isinstance(raw["residual"], dict):
        _check_unknown(raw["residual"], _RESIDUAL_KEYS, f"{path}.residual")
        if "type" in raw["residual"]:
            _check_enum(raw["residual"]["type"], VALID_RESIDUAL_TYPES, f"{path}.residual.type")

    if "state" in raw and isinstance(raw["state"], dict):
        _check_unknown(raw["state"], _STATE_KEYS, f"{path}.state")

    # Phase B4.1: template.memory (Titans parametric memory module)
    if "memory" in raw and raw["memory"] is not None:
        _validate_memory(raw["memory"], f"{path}.memory")

    # Phase B4.2: template.shape_change (Hourglass-style shape change)
    if "shape_change" in raw and raw["shape_change"] is not None:
        _validate_shape_change(raw["shape_change"], f"{path}.shape_change")


def _validate_memory(raw: Dict[str, Any], path: str) -> None:
    """Phase B4.1: Titans-style parametric memory attached to a template."""
    from .capabilities import VALID_MEMORY_TYPES, VALID_MEMORY_PERSISTENCE
    if not isinstance(raw, dict):
        raise ValidationError(
            f"{path}: must be a mapping",
            fix="memory: {type: neural_memory, update_at_inference: true, ...}",
        )
    _check_unknown(raw, _MEMORY_KEYS, path)
    mtype = _require_field(raw, "type", path)
    _check_enum(mtype, VALID_MEMORY_TYPES, f"{path}.type")
    if "update_at_inference" in raw and not isinstance(raw["update_at_inference"], bool):
        raise ValidationError(
            f"{path}.update_at_inference: must be bool",
            fix="Set to true (Titans test-time update) or false (static)",
        )
    if "params" in raw and raw["params"] is not None:
        params = raw["params"]
        if not isinstance(params, dict):
            raise ValidationError(
                f"{path}.params: must be a mapping",
                fix="params: {hidden: 2048}",
            )
        _check_unknown(params, _MEMORY_PARAMS_KEYS, f"{path}.params")
        if "hidden" in params:
            _check_positive_int(params["hidden"], f"{path}.params.hidden")
    if "inner_lr" in raw:
        lr = raw["inner_lr"]
        if not isinstance(lr, (int, float)) or float(lr) <= 0:
            raise ValidationError(
                f"{path}.inner_lr: must be a positive float",
                fix="Use a small positive value like 1e-3",
            )
    if "persistence" in raw:
        _check_enum(raw["persistence"], VALID_MEMORY_PERSISTENCE,
                    f"{path}.persistence")


def _validate_shape_change(raw: Dict[str, Any], path: str) -> None:
    """Phase B4.2: Hourglass-style shape change on a template."""
    from .capabilities import VALID_SHAPE_CHANGE_PROJECTIONS
    if not isinstance(raw, dict):
        raise ValidationError(
            f"{path}: must be a mapping",
            fix="shape_change: {d_out: 512, projection: linear}",
        )
    _check_unknown(raw, _SHAPE_CHANGE_KEYS, path)
    d_out = _require_field(raw, "d_out", path)
    _check_positive_int(d_out, f"{path}.d_out")
    if "projection" in raw:
        _check_enum(raw["projection"], VALID_SHAPE_CHANGE_PROJECTIONS,
                    f"{path}.projection")


def _validate_head(raw: Dict[str, Any]) -> None:
    _check_unknown(raw, _HEAD_KEYS, "head")
    _require_field(raw, "type", "head")
    _check_enum(raw["type"], VALID_HEAD_TYPES, "head.type")


# ── Per-layer override validation (Phase B1.1) ────────────────────────────

def _validate_override(raw: Dict[str, Any], path: str,
                        template_raw: Dict[str, Any]) -> None:
    """Validate a schedule-entry `override:` block against the whitelist.

    Rule: only a bounded whitelist of sub-paths may be overridden at schedule
    time. Mixer type changes require a new template (not an override). This
    keeps param counts stable across overrides.
    """
    if not isinstance(raw, dict):
        raise ValidationError(
            f"{path}: must be a mapping",
            fix=f"Ensure {path} is a dict; see docs/architectures/yaml_v1_spec.md §6",
        )
    _check_unknown(raw, _OVERRIDE_TOP_KEYS, path)

    if "residual" in raw and isinstance(raw["residual"], dict):
        _check_unknown(raw["residual"], _OVERRIDE_RESIDUAL_KEYS, f"{path}.residual")
    if "attention" in raw and isinstance(raw["attention"], dict):
        # attention override only valid if the template uses attention mixer
        mixer_type = template_raw.get("mixer", {}).get("type")
        if mixer_type != "attention":
            raise ValidationError(
                f"{path}.attention: override target not compatible (template mixer.type={mixer_type})",
                fix="Only templates with mixer.type=attention accept an attention override",
            )
        _check_unknown(raw["attention"], _OVERRIDE_ATTENTION_KEYS, f"{path}.attention")
    if "norm" in raw and isinstance(raw["norm"], dict):
        _check_unknown(raw["norm"], _OVERRIDE_NORM_KEYS, f"{path}.norm")
        if "type" in raw["norm"]:
            _check_enum(raw["norm"]["type"], VALID_NORM_TYPES, f"{path}.norm.type")
        if "position" in raw["norm"]:
            _check_enum(raw["norm"]["position"], VALID_NORM_POSITIONS, f"{path}.norm.position")
    if "ffn" in raw and isinstance(raw["ffn"], dict):
        _check_unknown(raw["ffn"], _OVERRIDE_FFN_KEYS, f"{path}.ffn")
        if "activation" in raw["ffn"]:
            _check_enum(raw["ffn"]["activation"], VALID_ACTIVATIONS, f"{path}.ffn.activation")


# ── Schedule entry kind dispatch (Phase B3) ───────────────────────────────

def _dispatch_schedule_entry_kind(entry: Dict[str, Any], path: str) -> str:
    """Decide whether entry is plain / parallel / integrator.

    A plain entry MUST have `template`. A parallel entry MUST have `parallel`
    and MUST NOT have `template`. An integrator entry MUST have `integrator`
    and MUST NOT have `template`. Mixing is rejected.
    """
    has_template = "template" in entry
    has_parallel = "parallel" in entry
    has_integrator = "integrator" in entry

    n_kinds = sum(1 for x in (has_template, has_parallel, has_integrator) if x)
    if n_kinds == 0:
        raise ValidationError(
            f"{path}: must contain one of 'template', 'parallel', or 'integrator'",
            fix="Add a `template: <name>` (plain) or `parallel:`/`integrator:` (B3)",
        )
    if n_kinds > 1:
        raise ValidationError(
            f"{path}: mixing 'template'/'parallel'/'integrator' in one entry is not allowed",
            fix="Split into separate schedule entries",
        )
    if has_parallel:
        return "parallel"
    if has_integrator:
        return "integrator"
    return "plain"


def _validate_parallel_entry(entry: Dict[str, Any], path: str,
                              templates_raw: Dict[str, Any]) -> None:
    """Phase B3.2: parallel (monoidal) schedule entry."""
    from .capabilities import VALID_MERGE_TYPES
    streams = entry["parallel"]
    if not isinstance(streams, list) or len(streams) < 2:
        raise ValidationError(
            f"{path}.parallel: must be a list of at least 2 streams",
            fix="Provide two streams, e.g. [{stream: a, body: [...]}, {stream: b, body: [...]}]",
        )
    seen_names = set()
    for j, s in enumerate(streams):
        sp = f"{path}.parallel[{j}]"
        if not isinstance(s, dict):
            raise ValidationError(f"{sp}: must be a mapping", fix="See parallel schema")
        _check_unknown(s, _PARALLEL_STREAM_KEYS, sp)
        name = _require_field(s, "stream", sp)
        if name in seen_names:
            raise ValidationError(
                f"{sp}.stream='{name}': duplicate stream name",
                fix="Stream names must be unique within a parallel entry",
            )
        seen_names.add(name)
        body = _require_field(s, "body", sp)
        if not isinstance(body, list) or len(body) == 0:
            raise ValidationError(
                f"{sp}.body: must be a non-empty list of plain schedule entries",
                fix="Provide at least one {template, repeat} entry",
            )
        # Each body entry must be plain (no nesting of parallel/integrator in v1).
        for k, bent in enumerate(body):
            bpath = f"{sp}.body[{k}]"
            if not isinstance(bent, dict):
                raise ValidationError(f"{bpath}: must be a mapping", fix="See body schema")
            if "parallel" in bent or "integrator" in bent:
                raise ValidationError(
                    f"{bpath}: nesting parallel/integrator inside a parallel stream is not allowed in v1",
                    fix="Flatten the stream body to plain {template, repeat} entries",
                )
            tref = _require_field(bent, "template", bpath)
            if tref not in templates_raw:
                raise ValidationError(
                    f"{bpath}: template '{tref}' not found in layer_templates",
                    fix=f"Add '{tref}' to layer_templates",
                )
            if "repeat" in bent:
                _check_positive_int(bent["repeat"], f"{bpath}.repeat")

    merge = entry.get("merge") or {"type": "concat"}
    if not isinstance(merge, dict):
        raise ValidationError(f"{path}.merge: must be a mapping", fix="See merge schema")
    _check_unknown(merge, _MERGE_KEYS, f"{path}.merge")
    if "type" in merge:
        _check_enum(merge["type"], VALID_MERGE_TYPES, f"{path}.merge.type")


def _validate_integrator_entry(entry: Dict[str, Any], path: str,
                                templates_raw: Dict[str, Any]) -> None:
    """Phase B3.3: integrator (recursive) schedule entry.

    v1.0 ships with `type: discrete` only (Universal Transformer / PonderNet /
    Diffusion-LM / Coconut share this). Continuous ODE solvers are reserved
    for v1.x+ via RESERVED_INTEGRATOR_TYPES.
    """
    from .capabilities import (
        VALID_INTEGRATOR_TYPES,
        VALID_INTEGRATOR_OUTPUTS,
        RESERVED_INTEGRATOR_TYPES,
    )
    intg = entry["integrator"]
    if not isinstance(intg, dict):
        raise ValidationError(
            f"{path}.integrator: must be a mapping",
            fix="integrator: {type: discrete, steps: 4, body: <template>, output: token}",
        )
    _check_unknown(intg, _INTEGRATOR_KEYS, f"{path}.integrator")
    itype = _require_field(intg, "type", f"{path}.integrator")
    if itype in RESERVED_INTEGRATOR_TYPES:
        # Accepted as reservation but not implemented in v1.0 core.
        raise ValidationError(
            f"{path}.integrator.type='{itype}' is reserved for v1.x+; v1.0 supports only 'discrete'",
            fix="Use type: discrete, or register a plugin that implements the continuous integrator",
        )
    _check_enum(itype, VALID_INTEGRATOR_TYPES, f"{path}.integrator.type")

    steps = _require_field(intg, "steps", f"{path}.integrator")
    _check_positive_int(steps, f"{path}.integrator.steps")

    body = _require_field(intg, "body", f"{path}.integrator")
    if not isinstance(body, str):
        raise ValidationError(
            f"{path}.integrator.body: must be a template name (string) in v1",
            fix="Reference a single template name by string",
        )
    if body not in templates_raw:
        raise ValidationError(
            f"{path}.integrator.body: template '{body}' not found in layer_templates",
            fix=f"Add '{body}' to layer_templates",
        )

    if "output" in intg:
        _check_enum(intg["output"], VALID_INTEGRATOR_OUTPUTS, f"{path}.integrator.output")


# ── Depth gating validation (Phase B3.1, MoD) ─────────────────────────────

def _validate_depth_gating(raw: Dict[str, Any], path: str) -> None:
    if not isinstance(raw, dict):
        raise ValidationError(
            f"{path}: must be a mapping",
            fix=f"Ensure {path} is a dict",
        )
    _check_unknown(raw, _DEPTH_GATING_KEYS, path)
    if "enabled" in raw and not isinstance(raw["enabled"], bool):
        raise ValidationError(
            f"{path}.enabled: must be bool",
            fix=f"Set {path}.enabled to true or false",
        )
    if "capacity" in raw:
        cap = raw["capacity"]
        if not isinstance(cap, (int, float)) or not (0.0 < float(cap) <= 1.0):
            raise ValidationError(
                f"{path}.capacity: must be a float in (0, 1]",
                fix="Set capacity in (0, 1]; e.g. 0.5 keeps half the tokens",
            )
    if "router" in raw:
        _check_enum(raw["router"], {"top_k", "learned_gate"}, f"{path}.router")


def parse_v2_yaml(raw: Dict[str, Any]) -> Dict[str, Any]:
    """
    Parse and structurally validate a YAML v1 dict.

    Returns the (possibly resolved) validated dict on success. If the input
    contains a top-level `let:` block or any `${...}` expression strings,
    they are resolved before structural validation (Phase B1.2).

    Raises ValidationError on any structural violation or expression error.
    """
    if not isinstance(raw, dict):
        raise ValidationError("Root YAML must be a mapping", fix="Ensure YAML is a dict/mapping")

    # Pre-pass: resolve let: / ${...} expressions (Phase B1.2).
    # The returned dict has let: stripped and all ${...} replaced by concrete
    # numeric values, so the rest of validation operates on plain data.
    from .expressions import resolve_expressions
    raw = resolve_expressions(raw)

    # schema_version check
    sv = raw.get("schema_version")
    if sv is None:
        raise ValidationError(
            "Missing 'schema_version'",
            fix="Add 'schema_version: 1' at the top of your YAML",
        )
    if sv != 1:
        raise ValidationError(
            f"Unsupported schema_version: {sv}",
            fix="Set 'schema_version: 1'",
        )

    # Unknown top-level keys
    _check_unknown(raw, VALID_TOP_LEVEL_KEYS, "root")

    # Required sections
    model_raw = _require_field(raw, "model", "root")
    _validate_model(model_raw)

    tok_raw = _require_field(raw, "tokenizer_contract", "root")
    _validate_tokenizer(tok_raw)

    emb_raw = _require_field(raw, "embedding", "root")
    _validate_embedding(emb_raw)

    templates_raw = _require_field(raw, "layer_templates", "root")
    if not isinstance(templates_raw, dict) or len(templates_raw) == 0:
        raise ValidationError(
            "layer_templates: must be a non-empty mapping",
            fix="Add at least one layer template",
        )
    for tname, tdef in templates_raw.items():
        if not isinstance(tdef, dict):
            raise ValidationError(
                f"layer_templates.{tname}: must be a mapping",
                fix=f"Ensure layer_templates.{tname} is a dict",
            )
        _validate_template(tdef, tname)

    schedule_raw = _require_field(raw, "layer_schedule", "root")
    if not isinstance(schedule_raw, list) or len(schedule_raw) == 0:
        raise ValidationError(
            "layer_schedule: must be a non-empty list",
            fix="Add at least one schedule entry",
        )
    for i, entry in enumerate(schedule_raw):
        path = f"layer_schedule[{i}]"
        if not isinstance(entry, dict):
            raise ValidationError(f"{path}: must be a mapping", fix=f"Ensure {path} is a dict")
        _check_unknown(entry, _SCHEDULE_ENTRY_KEYS, path)

        # Phase B3: dispatch schedule entry kind.
        kind = _dispatch_schedule_entry_kind(entry, path)
        if kind == "plain":
            tref = _require_field(entry, "template", path)
            if tref not in templates_raw:
                raise ValidationError(
                    f"{path}: template '{tref}' not found in layer_templates",
                    fix=f"Add '{tref}' to layer_templates or fix the reference",
                )
            if "repeat" in entry:
                _check_positive_int(entry["repeat"], f"{path}.repeat")
            if "override" in entry and entry["override"] is not None:
                _validate_override(entry["override"], f"{path}.override",
                                   templates_raw[tref])
            if "depth_gating" in entry and entry["depth_gating"] is not None:
                _validate_depth_gating(entry["depth_gating"], f"{path}.depth_gating")
        elif kind == "parallel":
            _validate_parallel_entry(entry, path, templates_raw)
        elif kind == "integrator":
            _validate_integrator_entry(entry, path, templates_raw)

    head_raw = _require_field(raw, "head", "root")
    _validate_head(head_raw)

    # Optional sections
    if "training_hints" in raw and raw["training_hints"] is not None:
        _check_unknown(raw["training_hints"], _TRAINING_HINTS_KEYS, "training_hints")

    if "compatibility" in raw and raw["compatibility"] is not None:
        _check_unknown(raw["compatibility"], _COMPATIBILITY_KEYS, "compatibility")
        if "compile_target" in raw["compatibility"]:
            _check_enum(
                raw["compatibility"]["compile_target"],
                VALID_COMPILE_TARGETS,
                "compatibility.compile_target",
            )

    # Phase B5: reasoning mode declaration (R1 / Quiet-STaR). Declarative
    # only — no architecture change. The training recipe / generate() must
    # honour the phase split.
    if "execution_modes" in raw and raw["execution_modes"] is not None:
        _validate_execution_modes(raw["execution_modes"], raw.get("transition"))

    return raw


def _validate_execution_modes(modes: Any, transition_raw: Any) -> None:
    """Phase B5: top-level `execution_modes` + optional `transition:` block."""
    from .capabilities import VALID_EXECUTION_TRANSITIONS
    if not isinstance(modes, list) or len(modes) == 0:
        raise ValidationError(
            "execution_modes: must be a non-empty list",
            fix="Provide at least one {name, max_tokens, ...} entry",
        )
    seen_names = set()
    for i, m in enumerate(modes):
        mp = f"execution_modes[{i}]"
        if not isinstance(m, dict):
            raise ValidationError(
                f"{mp}: must be a mapping",
                fix="Each execution mode is a {name, max_tokens, ...} dict",
            )
        _check_unknown(m, _EXEC_MODE_KEYS, mp)
        name = _require_field(m, "name", mp)
        if name in seen_names:
            raise ValidationError(
                f"{mp}.name='{name}': duplicate execution mode name",
                fix="Mode names must be unique (e.g. think, answer)",
            )
        seen_names.add(name)
        _check_positive_int(_require_field(m, "max_tokens", mp),
                            f"{mp}.max_tokens")
        if "loss_weight" in m:
            lw = m["loss_weight"]
            if not isinstance(lw, (int, float)) or float(lw) < 0:
                raise ValidationError(
                    f"{mp}.loss_weight: must be a non-negative float",
                    fix="Use 0.0 for phases excluded from loss; 1.0 otherwise",
                )
        for bool_field in ("kv_share", "visible_to_user", "per_token_rationale"):
            if bool_field in m and not isinstance(m[bool_field], bool):
                raise ValidationError(
                    f"{mp}.{bool_field}: must be bool",
                    fix=f"Set {bool_field} to true or false",
                )
    # transition: is optional but if present must be valid.
    if transition_raw is not None:
        if not isinstance(transition_raw, dict):
            raise ValidationError(
                "transition: must be a mapping",
                fix="transition: {type: special_token, token: '<think_end>'}",
            )
        _check_unknown(transition_raw, _TRANSITION_KEYS, "transition")
        if "type" in transition_raw:
            _check_enum(transition_raw["type"], VALID_EXECUTION_TRANSITIONS,
                        "transition.type")
        if transition_raw.get("type") == "special_token":
            if not transition_raw.get("token"):
                raise ValidationError(
                    "transition.token: required when transition.type=special_token",
                    fix="Provide a token string, e.g. '<think_end>'",
                )
