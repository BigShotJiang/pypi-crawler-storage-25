# eulerstack/spec/validate_v2.py
"""Full v2 validation: structural + cross-field + compatibility checks."""
from __future__ import annotations

from typing import Any, Dict

from .errors import ValidationError, CompatibilityError
from .schema import parse_v2_yaml
from .capabilities import MIXER_CAPABILITIES


def _check_model_constraints(model: Dict[str, Any]) -> None:
    """R11, R12: GQA head divisibility and d_model/n_heads divisibility."""
    d_model = int(model["d_model"])
    n_heads = int(model["n_heads"])

    if d_model % n_heads != 0:
        raise ValidationError(
            f"model.d_model ({d_model}) must be divisible by model.n_heads ({n_heads})",
            fix=f"Adjust d_model or n_heads so d_model % n_heads == 0",
        )

    n_kv_heads = int(model.get("n_kv_heads", n_heads))
    if n_heads % n_kv_heads != 0:
        raise ValidationError(
            f"model.n_heads ({n_heads}) must be divisible by model.n_kv_heads ({n_kv_heads})",
            fix=f"Adjust n_kv_heads so n_heads % n_kv_heads == 0",
        )


def _check_embedding_rope(embedding: Dict[str, Any]) -> None:
    """R7: If positional != rope, rope_theta/rope_scaling must not be set."""
    positional = embedding.get("positional", "none")
    if positional != "rope":
        if "rope_theta" in embedding and embedding["rope_theta"] is not None:
            raise ValidationError(
                f"embedding.rope_theta set but positional='{positional}' (not rope)",
                fix="Remove rope_theta or set positional to 'rope'",
            )
        if "rope_scaling" in embedding and embedding["rope_scaling"] is not None:
            raise ValidationError(
                f"embedding.rope_scaling set but positional='{positional}' (not rope)",
                fix="Remove rope_scaling or set positional to 'rope'",
            )


def _check_mla_latent_dim(template: Dict[str, Any], tname: str, d_model: int) -> None:
    """Phase B2.1 cross-field: attention.latent_dim must be < d_model.

    Structural validation already rejects latent_dim ≤ 0, but the upper bound
    depends on model.d_model and so must live at cross-field level.
    """
    mixer = template.get("mixer") or {}
    if mixer.get("type") != "attention":
        return
    attn = mixer.get("attention") or {}
    latent_dim = attn.get("latent_dim")
    if latent_dim is None:
        return
    if int(latent_dim) >= d_model:
        raise ValidationError(
            f"layer_templates.{tname}.mixer.attention.latent_dim="
            f"{latent_dim} must be strictly less than model.d_model ({d_model}).",
            fix=(
                "MLA compresses KV through a latent; latent_dim ≥ d_model is"
                " either a no-op or an up-projection (nonsensical). Use"
                " latent_dim ≈ d_model / 2 as a starting point."
            ),
        )


def _check_mixer_state_compat(template: Dict[str, Any], tname: str) -> None:
    """R5: mixer/state compatibility."""
    mixer_type = template["mixer"]["type"]
    state = template.get("state", {})
    if not isinstance(state, dict):
        state = {}

    caps = MIXER_CAPABILITIES.get(mixer_type, {})

    if state.get("kv_cache", False) and not caps.get("supports_kv_cache", False):
        raise CompatibilityError(
            f"layer_templates.{tname}: kv_cache=true incompatible with mixer.type='{mixer_type}'",
            fix=f"Set state.kv_cache to false or change mixer.type",
        )
    if state.get("ssm_state", False) and not caps.get("supports_ssm_state", False):
        raise CompatibilityError(
            f"layer_templates.{tname}: ssm_state=true incompatible with mixer.type='{mixer_type}'",
            fix=f"Set state.ssm_state to false or change mixer.type",
        )


def _check_training_hints(hints: Dict[str, Any]) -> None:
    """R13: training_hints constraints."""
    dropout = hints.get("dropout", 0.0)
    if isinstance(dropout, (int, float)) and dropout < 0:
        raise ValidationError(
            f"training_hints.dropout ({dropout}) must not be negative",
            fix="Set training_hints.dropout to 0 or a positive value",
        )


def _check_moe_constraints(template: Dict[str, Any], tname: str) -> None:
    """R14: MoE top_k <= experts."""
    ffn = template.get("ffn", {})
    if not isinstance(ffn, dict):
        return
    if ffn.get("type") == "moe" and "moe" in ffn:
        moe = ffn["moe"]
        if isinstance(moe, dict):
            experts = moe.get("experts", 1)
            top_k = moe.get("top_k", 1)
            if isinstance(experts, int) and isinstance(top_k, int) and top_k > experts:
                raise ValidationError(
                    f"layer_templates.{tname}: moe.top_k ({top_k}) exceeds moe.experts ({experts})",
                    fix=f"Set top_k <= experts",
                )


def validate_v2(raw: Dict[str, Any]) -> Dict[str, Any]:
    """
    Full YAML validation.

    1. Structural validation (parse_v2_yaml) — runs the B1.2 let:/${...}
       pre-pass and returns the resolved dict
    2. Model constraints (R11, R12)
    3. Embedding/rope compatibility (R7)
    4. Mixer/state compatibility per template (R5)
    5. Training hints constraints (R13)
    6. MoE constraints per template (R14)

    Returns the resolved/validated dict (with `let:` stripped and `${...}`
    substituted). Raises ValidationError or CompatibilityError on failure.
    """
    # Step 1: structural (includes expression pre-pass). Use the returned
    # dict — the input `raw` may still contain unresolved `${...}` strings.
    resolved = parse_v2_yaml(raw)

    # Step 2: model constraints
    _check_model_constraints(resolved["model"])

    # Step 3: embedding/rope
    _check_embedding_rope(resolved["embedding"])

    # Step 4: per-template compatibility
    for tname, tdef in resolved["layer_templates"].items():
        _check_mixer_state_compat(tdef, tname)
        _check_moe_constraints(tdef, tname)
        _check_mla_latent_dim(tdef, tname, int(resolved["model"]["d_model"]))

    # Step 5: training hints
    hints = resolved.get("training_hints")
    if hints and isinstance(hints, dict):
        _check_training_hints(hints)

    return resolved
