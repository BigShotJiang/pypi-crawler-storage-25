"""MoE runtime contract tests.

Before this work, EulerStack's `ffn.type: moe` was silently down-graded to
a dense SwiGLU at compile time: the `build_mlp` dispatcher only knew
`mlp` / `swiglu`, the compile target never emitted per-layer FFN info,
and the layer forward threw away any `(output, aux)` tuple a MoE module
might have returned. The project catalogued this as "🟡 MoE = Fallback"
in docs/architectures/runtime_primitive_status.md.

These tests guard the lift to **"✅ Core"**: the full
`YAML → IR → compile → save_pretrained → AutoModel load → forward → aux`
chain must produce a real MoE-wired model whose attention-block FFN is a
`MoEFFN` instance, whose forward returns differentiable aux losses when
asked, and whose compiled config.json carries per-layer FFN typing so
the runtime can make that decision.

We exercise two regimes the project actually uses:

* **configs/presets/arch_expert_deepseek_moe_mini.yml** — canonical
  fine-grained recipe with 16 experts × top-2. Compile must succeed and
  produce 16-way routing; we do not train here (VRAM).
* **projects/moe_pretrain_study/configs/deepseek.yml** — research-project
  variant where the user reduced experts to 8 to fit RTX 5090 training
  budgets. Compile + 1-step forward must succeed with aux populated.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent
VALID_YAMLS = REPO_ROOT / "docs" / "fixtures" / "valid_yamls"
PRESETS = REPO_ROOT / "configs" / "presets"
PROJECT_CFG = REPO_ROOT / "projects" / "moe_pretrain_study" / "configs"


# ─────────────────────────────────────────────────────────────────────────────
# MoEFFN module — the new standalone class
# ─────────────────────────────────────────────────────────────────────────────

class TestMoEFFNStandalone:
    """The MoE module works as a plain nn.Module, before any compile wiring."""

    def test_forward_default_returns_tensor(self):
        torch = pytest.importorskip("torch")
        from eulerstack.blocks.moe import MoEFFN
        m = MoEFFN(d_model=64, experts=4, top_k=2, mlp_ratio=4)
        x = torch.randn(2, 8, 64)
        y = m(x)
        assert torch.is_tensor(y)
        assert y.shape == (2, 8, 64)

    def test_forward_output_aux_returns_tuple(self):
        torch = pytest.importorskip("torch")
        from eulerstack.blocks.moe import MoEFFN
        m = MoEFFN(d_model=64, experts=4, top_k=2, mlp_ratio=4,
                   z_loss=0.001)
        x = torch.randn(2, 8, 64)
        y, aux = m(x, output_aux=True)
        assert y.shape == (2, 8, 64)
        assert isinstance(aux, dict)
        assert "aux_loss" in aux, f"aux keys: {list(aux)}"
        assert "router_load" in aux
        assert aux["router_load"].shape == (4,)
        # aux_loss must be a scalar tensor (addable to LM loss)
        assert torch.is_tensor(aux["aux_loss"])
        assert aux["aux_loss"].dim() == 0

    @pytest.mark.parametrize("experts", [4, 8, 16])
    def test_expert_counts(self, experts):
        """Both 8-expert (projects) and 16-expert (preset canonical) wire up."""
        torch = pytest.importorskip("torch")
        from eulerstack.blocks.moe import MoEFFN
        m = MoEFFN(d_model=32, experts=experts, top_k=2, mlp_ratio=4)
        x = torch.randn(1, 8, 32)
        y, aux = m(x, output_aux=True)
        assert y.shape == (1, 8, 32)
        assert aux["router_load"].shape == (experts,)

    def test_backward_gate_gets_gradient(self):
        """Router gate must receive gradient — else nothing learns."""
        torch = pytest.importorskip("torch")
        from eulerstack.blocks.moe import MoEFFN
        m = MoEFFN(d_model=32, experts=4, top_k=2, z_loss=0.001)
        x = torch.randn(4, 16, 32)
        y, aux = m(x, output_aux=True)
        loss = y.sum() + aux["aux_loss"]
        loss.backward()
        # The router is a Linear layer; its weight must get grad.
        router_params = [p for p in m.router.parameters() if p.requires_grad]
        assert len(router_params) > 0
        assert any(p.grad is not None and p.grad.abs().sum() > 0
                   for p in router_params)


# ─────────────────────────────────────────────────────────────────────────────
# build_mlp dispatcher — contract extension
# ─────────────────────────────────────────────────────────────────────────────

class TestBuildMLPSupportsMoE:
    def test_build_mlp_moe_returns_moeffn(self):
        pytest.importorskip("torch")
        from eulerstack.blocks.mlp import build_mlp
        from eulerstack.blocks.moe import MoEFFN
        m = build_mlp(
            "moe", d_model=64, mlp_ratio=4, dropout=0.0, bias=False,
            moe_config={"experts": 4, "top_k": 2},
        )
        assert isinstance(m, MoEFFN)

    def test_build_mlp_swiglu_still_works(self):
        pytest.importorskip("torch")
        from eulerstack.blocks.mlp import build_mlp, SwiGLU
        m = build_mlp("swiglu", d_model=64, mlp_ratio=4,
                      dropout=0.0, bias=False)
        assert isinstance(m, SwiGLU)

    def test_build_mlp_moe_missing_config_raises(self):
        """moe without moe_config is a programmer error."""
        pytest.importorskip("torch")
        from eulerstack.blocks.mlp import build_mlp
        with pytest.raises((ValueError, TypeError, KeyError)):
            build_mlp("moe", d_model=64, mlp_ratio=4,
                      dropout=0.0, bias=False)


# ─────────────────────────────────────────────────────────────────────────────
# compile emits per-layer FFN typing in stack.pattern
# ─────────────────────────────────────────────────────────────────────────────

class TestCompileEmitsPerLayerFFN:

    @pytest.fixture
    def runner(self):
        from click.testing import CliRunner
        return CliRunner()

    def test_swiglu_layer_marked_in_pattern(self, runner, tmp_path):
        from eulerstack.cli.main import cli
        out = tmp_path / "llama"
        r = runner.invoke(cli, [
            "compile",
            "--preset", str(VALID_YAMLS / "llama_like.yml"),
            "--output-dir", str(out),
        ])
        assert r.exit_code == 0, r.output
        cfg = json.loads((out / "config.json").read_text())
        pattern = cfg["stack"]["pattern"]
        assert len(pattern) > 0
        # Every entry must declare its ffn
        assert all("ffn" in e for e in pattern), \
            f"stack.pattern missing ffn on some layers: {pattern}"
        # Llama fixture uses gated_mlp → swiglu
        ffn_types = {e["ffn"]["type"] for e in pattern}
        assert ffn_types & {"swiglu", "gated_mlp", "mlp"}, \
            f"unexpected ffn types: {ffn_types}"

    def test_moe_layer_marked_in_pattern(self, runner, tmp_path):
        from eulerstack.cli.main import cli
        out = tmp_path / "moe"
        r = runner.invoke(cli, [
            "compile",
            "--preset", str(VALID_YAMLS / "moe_model.yml"),
            "--output-dir", str(out),
        ])
        assert r.exit_code == 0, r.output
        cfg = json.loads((out / "config.json").read_text())
        pattern = cfg["stack"]["pattern"]
        moe_entries = [e for e in pattern if e.get("ffn", {}).get("type") == "moe"]
        assert len(moe_entries) >= 1, \
            f"no moe entries in pattern; got types " \
            f"{[e.get('ffn', {}).get('type') for e in pattern]}"
        first = moe_entries[0]
        moe_cfg = first["ffn"]["moe"]
        assert moe_cfg["experts"] >= 1
        assert moe_cfg["top_k"] >= 1


# ─────────────────────────────────────────────────────────────────────────────
# End-to-end: compiled model ACTUALLY uses MoEFFN at runtime
# ─────────────────────────────────────────────────────────────────────────────

class TestCompiledMoERuntime:
    """The decisive guard. After compile, a loaded model's attention layers
    must hold a MoEFFN (not SwiGLU) and forward must produce populated aux.
    """

    @pytest.fixture
    def runner(self):
        from click.testing import CliRunner
        return CliRunner()

    def _compile_and_load(self, runner, preset_path: Path, out: Path):
        from eulerstack.cli.main import cli
        r = runner.invoke(cli, [
            "compile", "--preset", str(preset_path),
            "--output-dir", str(out),
        ])
        assert r.exit_code == 0, r.output
        from transformers import AutoModelForCausalLM
        return AutoModelForCausalLM.from_pretrained(str(out), trust_remote_code=True)

    def _moe_layer_count(self, model) -> int:
        from eulerstack.blocks.moe import MoEFFN
        return sum(
            1 for layer in model.eulerstack.layers
            if isinstance(getattr(layer, "mlp", None), MoEFFN)
        )

    def test_fixture_moe_model_uses_moeffn(self, runner, tmp_path):
        pytest.importorskip("transformers")
        out = tmp_path / "fixture_moe"
        model = self._compile_and_load(runner, VALID_YAMLS / "moe_model.yml", out)
        assert self._moe_layer_count(model) >= 1, \
            "moe_model fixture compiled without any MoEFFN — dense fallback bug"

    def test_presets_deepseek_canonical_16_experts(self, runner, tmp_path):
        """The untouched catalogue preset must keep 16-way fine-grained MoE."""
        pytest.importorskip("transformers")
        preset = PRESETS / "arch_expert_deepseek_moe_mini.yml"
        if not preset.is_file():
            pytest.skip(f"catalogue preset missing: {preset}")
        out = tmp_path / "deepseek16"
        model = self._compile_and_load(runner, preset, out)
        from eulerstack.blocks.moe import MoEFFN
        moe_layers = [
            layer.mlp for layer in model.eulerstack.layers
            if isinstance(getattr(layer, "mlp", None), MoEFFN)
        ]
        assert moe_layers, "catalogue deepseek preset must instantiate MoEFFN"
        assert moe_layers[0].num_experts == 16, \
            f"expected 16 experts in catalogue preset, got {moe_layers[0].num_experts}"

    def test_projects_deepseek_reduced_8_experts(self, runner, tmp_path):
        """Project variant at 8 experts — VRAM-realistic on RTX 5090."""
        pytest.importorskip("transformers")
        preset = PROJECT_CFG / "deepseek.yml"
        if not preset.is_file():
            pytest.skip(f"project config missing: {preset}")
        out = tmp_path / "deepseek8"
        model = self._compile_and_load(runner, preset, out)
        from eulerstack.blocks.moe import MoEFFN
        moe_layers = [
            layer.mlp for layer in model.eulerstack.layers
            if isinstance(getattr(layer, "mlp", None), MoEFFN)
        ]
        assert moe_layers, "project deepseek preset must instantiate MoEFFN"
        assert moe_layers[0].num_experts == 8, \
            f"project config should use 8 experts; got {moe_layers[0].num_experts}"

    def test_forward_populates_moe_aux_dict(self, runner, tmp_path):
        """`output_aux=True` → outputs.moe_aux has aux_loss_total / router_load_mean
        as actual tensors (no empty dicts, no missing keys)."""
        pytest.importorskip("transformers")
        torch = pytest.importorskip("torch")
        out = tmp_path / "fixture_moe_forward"
        model = self._compile_and_load(runner, VALID_YAMLS / "moe_model.yml", out)
        model.eval()
        x = torch.randint(0, min(model.config.vocab_size, 50000), (1, 8))
        with torch.no_grad():
            result = model(x, output_aux=True)
        aux = getattr(result, "moe_aux", None)
        assert isinstance(aux, dict) and aux
        assert "aux_loss_total" in aux, f"keys: {list(aux)}"
        tot = aux["aux_loss_total"]
        assert torch.is_tensor(tot) and tot.dim() == 0
        assert "router_load_mean" in aux
        load = aux["router_load_mean"]
        assert torch.is_tensor(load) and load.dim() == 1

    def test_forward_without_output_aux_returns_none_moe_aux(self, runner, tmp_path):
        pytest.importorskip("transformers")
        torch = pytest.importorskip("torch")
        out = tmp_path / "fixture_moe_noaux"
        model = self._compile_and_load(runner, VALID_YAMLS / "moe_model.yml", out)
        model.eval()
        x = torch.randint(0, min(model.config.vocab_size, 50000), (1, 8))
        with torch.no_grad():
            result = model(x)
        # Default forward (no output_aux): moe_aux should be None
        assert getattr(result, "moe_aux", None) is None


# ─────────────────────────────────────────────────────────────────────────────
# Phase A — Block-level MoE for the three non-attention mixer families.
#
# Before this work only attention layers routed to MoEFFN; mamba layers could
# run MoE only by means of an older `SimpleMoE` inside the block that used a
# different aux-key convention; retnet and hyena blocks ignored ffn.type=moe
# entirely. Now all three support use_moe + moe kwargs uniformly and emit the
# standardised aux dict {aux_loss, router_z_loss, router_load}.
# ─────────────────────────────────────────────────────────────────────────────

class TestMambaBlockMoE:
    def test_mamba_block_with_use_moe_instantiates_moeffn(self):
        torch = pytest.importorskip("torch")
        from eulerstack.blocks.mamba import MambaBlock
        from eulerstack.blocks.moe import MoEFFN
        blk = MambaBlock(
            d_model=32, norm="rmsnorm", dropout=0.0, mlp_ratio=4,
            use_moe=True, moe={"experts": 4, "top_k": 2},
        )
        assert isinstance(getattr(blk, "moe_ffn", None), MoEFFN), \
            f"MambaBlock.use_moe should build a MoEFFN, got {type(getattr(blk, 'moe_ffn', None))}"
        # Forward emits aux with the standardised keys
        x = torch.randn(1, 8, 32)
        y, aux = blk(x, output_aux=True)
        assert y.shape == (1, 8, 32)
        assert isinstance(aux, dict)
        assert "aux_loss" in aux
        assert "router_load" in aux

    def test_mamba_block_without_use_moe_unchanged(self):
        torch = pytest.importorskip("torch")
        from eulerstack.blocks.mamba import MambaBlock
        blk = MambaBlock(d_model=32, norm="rmsnorm", dropout=0.0, mlp_ratio=4)
        x = torch.randn(1, 8, 32)
        y = blk(x)
        assert y.shape == (1, 8, 32)


class TestRetNetBlockMoE:
    def test_retnet_block_accepts_use_moe(self):
        torch = pytest.importorskip("torch")
        from eulerstack.blocks.retnet import RetNetBlock
        from eulerstack.blocks.moe import MoEFFN
        blk = RetNetBlock(
            d_model=32, n_heads=4, norm="rmsnorm", dropout=0.0, mlp_ratio=4,
            use_moe=True, moe={"experts": 4, "top_k": 2},
        )
        assert isinstance(getattr(blk, "moe_ffn", None), MoEFFN), \
            "RetNetBlock.use_moe should build a MoEFFN"

    def test_retnet_block_forward_returns_aux(self):
        torch = pytest.importorskip("torch")
        from eulerstack.blocks.retnet import RetNetBlock
        blk = RetNetBlock(
            d_model=32, n_heads=4, norm="rmsnorm", dropout=0.0, mlp_ratio=4,
            use_moe=True, moe={"experts": 4, "top_k": 2},
        )
        x = torch.randn(1, 8, 32)
        result = blk(x, output_aux=True)
        assert isinstance(result, tuple) and len(result) == 3, \
            f"RetNetBlock(output_aux=True) must return (out, past, aux); got tuple of size {len(result)}"
        y, past, aux = result
        assert y.shape == (1, 8, 32)
        assert isinstance(aux, dict)
        assert "aux_loss" in aux
        assert "router_load" in aux

    def test_retnet_block_dense_unchanged(self):
        torch = pytest.importorskip("torch")
        from eulerstack.blocks.retnet import RetNetBlock
        blk = RetNetBlock(d_model=32, n_heads=4, norm="rmsnorm",
                          dropout=0.0, mlp_ratio=4)
        x = torch.randn(1, 8, 32)
        y, past = blk(x)
        assert y.shape == (1, 8, 32)


class TestHyenaBlockMoE:
    def test_hyena_block_accepts_use_moe(self):
        torch = pytest.importorskip("torch")
        from eulerstack.blocks.hyena import HyenaBlock
        from eulerstack.blocks.moe import MoEFFN
        blk = HyenaBlock(
            d_model=32, norm="rmsnorm", dropout=0.0, mlp_ratio=4,
            use_moe=True, moe={"experts": 4, "top_k": 2},
        )
        assert isinstance(getattr(blk, "moe_ffn", None), MoEFFN), \
            "HyenaBlock.use_moe should build a MoEFFN"

    def test_hyena_block_forward_returns_aux(self):
        torch = pytest.importorskip("torch")
        from eulerstack.blocks.hyena import HyenaBlock
        blk = HyenaBlock(
            d_model=32, norm="rmsnorm", dropout=0.0, mlp_ratio=4,
            use_moe=True, moe={"experts": 4, "top_k": 2},
        )
        x = torch.randn(1, 8, 32)
        result = blk(x, output_aux=True)
        assert isinstance(result, tuple) and len(result) == 3
        y, past, aux = result
        assert y.shape == (1, 8, 32)
        assert isinstance(aux, dict)
        assert "aux_loss" in aux
        assert "router_load" in aux

    def test_hyena_block_dense_unchanged(self):
        torch = pytest.importorskip("torch")
        from eulerstack.blocks.hyena import HyenaBlock
        blk = HyenaBlock(d_model=32, norm="rmsnorm", dropout=0.0, mlp_ratio=4)
        x = torch.randn(1, 8, 32)
        y, past = blk(x)
        assert y.shape == (1, 8, 32)


# ─────────────────────────────────────────────────────────────────────────────
# Phase B — Compile emits per-layer use_moe/moe for non-attention mixers.
# ─────────────────────────────────────────────────────────────────────────────

class TestCompileEmitsUseMoEForNonAttention:
    """For non-attention mixers with ffn.type=moe, compile must populate
    stack.pattern[i].extra.use_moe=True + extra.moe={...}, otherwise the
    block's internal MoE path never fires."""

    @pytest.fixture
    def runner(self):
        from click.testing import CliRunner
        return CliRunner()

    @pytest.mark.parametrize("preset_name", [
        "arch_expert_blackmamba_moe_mini",
        "arch_expert_retnet_moe",
        "arch_expert_frontier_full_moe_mini",
    ])
    def test_non_attention_moe_template_compile_extras(
        self, runner, tmp_path, preset_name
    ):
        preset = PRESETS / f"{preset_name}.yml"
        if not preset.is_file():
            pytest.skip(f"missing preset: {preset}")
        from eulerstack.cli.main import cli
        out = tmp_path / preset_name
        r = runner.invoke(cli, ["compile", "--preset", str(preset),
                                  "--output-dir", str(out)])
        assert r.exit_code == 0, r.output
        cfg = json.loads((out / "config.json").read_text())
        pattern = cfg["stack"]["pattern"]

        # At least one non-attention layer must carry use_moe=True +
        # extra.moe.experts>=1 — this is the missing signal.
        non_attn_moe_entries = [
            e for e in pattern
            if e.get("block") in ("mamba", "retnet", "hyena")
            and (e.get("extra") or {}).get("use_moe") is True
        ]
        assert non_attn_moe_entries, (
            f"No non-attention layer in {preset_name} has extra.use_moe=True. "
            f"Sample entries: {pattern[:3]}"
        )
        # Each such entry's extra.moe must carry experts + top_k
        for entry in non_attn_moe_entries:
            extra = entry["extra"]
            assert isinstance(extra.get("moe"), dict)
            assert extra["moe"].get("experts", 0) >= 1
            assert extra["moe"].get("top_k", 0) >= 1


# ─────────────────────────────────────────────────────────────────────────────
# Phase C — End-to-end: compiled model actually runs MoE in all three block
#           families. Layer introspection + forward aux population.
# ─────────────────────────────────────────────────────────────────────────────

class TestEndToEndMoEAcrossMixerFamilies:

    @pytest.fixture
    def runner(self):
        from click.testing import CliRunner
        return CliRunner()

    def _compile_and_load(self, runner, preset_path, out):
        from eulerstack.cli.main import cli
        r = runner.invoke(cli, ["compile", "--preset", str(preset_path),
                                  "--output-dir", str(out)])
        assert r.exit_code == 0, r.output
        from transformers import AutoModelForCausalLM
        return AutoModelForCausalLM.from_pretrained(str(out), trust_remote_code=True)

    def test_blackmamba_mamba_layers_all_use_moe(self, runner, tmp_path):
        pytest.importorskip("transformers")
        preset = PRESETS / "arch_expert_blackmamba_moe_mini.yml"
        if not preset.is_file():
            pytest.skip("preset missing")
        out = tmp_path / "blackmamba"
        model = self._compile_and_load(runner, preset, out)
        from eulerstack.blocks.mamba import MambaBlock
        mamba_layers = [
            L for L in model.eulerstack.layers
            if isinstance(getattr(L.backbone, "impl", None), MambaBlock)
        ]
        assert mamba_layers, "blackmamba has no mamba layers"
        # In blackmamba preset, EVERY mamba template declares ffn.type=moe.
        assert all(getattr(L.backbone.impl, "use_moe", False) for L in mamba_layers), \
            f"Some mamba layers still have use_moe=False (of {len(mamba_layers)} mamba layers)"

    def test_retnet_moe_preset_layers_actually_use_moe(self, runner, tmp_path):
        pytest.importorskip("transformers")
        preset = PRESETS / "arch_expert_retnet_moe.yml"
        if not preset.is_file():
            pytest.skip("preset missing")
        out = tmp_path / "retnet_moe"
        model = self._compile_and_load(runner, preset, out)
        from eulerstack.blocks.retnet import RetNetBlock
        retnet_layers = [
            L for L in model.eulerstack.layers
            if isinstance(getattr(L.backbone, "impl", None), RetNetBlock)
        ]
        assert retnet_layers, "retnet_moe has no retnet layers"
        moe_retnet = [L for L in retnet_layers
                      if getattr(L.backbone.impl, "use_moe", False)]
        # The preset declares two templates: retnet_dense + retnet_moe; at
        # least the retnet_moe template layers should flip use_moe on.
        assert moe_retnet, "No retnet layer has use_moe=True"

    def test_frontier_full_moe_mixer_types_all_get_moe(self, runner, tmp_path):
        pytest.importorskip("transformers")
        preset = PRESETS / "arch_expert_frontier_full_moe_mini.yml"
        if not preset.is_file():
            pytest.skip("preset missing")
        out = tmp_path / "frontier"
        model = self._compile_and_load(runner, preset, out)
        from eulerstack.blocks.mamba import MambaBlock
        from eulerstack.blocks.retnet import RetNetBlock
        from eulerstack.blocks.hyena import HyenaBlock

        # Every layer must have use_moe=True; each block type must appear.
        kinds_seen = set()
        for L in model.eulerstack.layers:
            impl = getattr(L.backbone, "impl", None)
            if isinstance(impl, MambaBlock):
                kinds_seen.add("mamba")
            elif isinstance(impl, RetNetBlock):
                kinds_seen.add("retnet")
            elif isinstance(impl, HyenaBlock):
                kinds_seen.add("hyena")
            assert getattr(impl, "use_moe", False), \
                f"Layer with {type(impl).__name__} has use_moe=False"
        assert kinds_seen == {"mamba", "retnet", "hyena"}, \
            f"Expected all 3 mixer kinds, got {kinds_seen}"

    def test_forward_with_output_aux_populates_moe_aux_from_non_attention(
        self, runner, tmp_path
    ):
        """Run forward on blackmamba_mini and verify moe_aux gets populated
        by the mamba layers' internal MoE path."""
        pytest.importorskip("transformers")
        torch = pytest.importorskip("torch")
        preset = PRESETS / "arch_expert_blackmamba_moe_mini.yml"
        if not preset.is_file():
            pytest.skip("preset missing")
        out = tmp_path / "blackmamba_forward"
        model = self._compile_and_load(runner, preset, out)
        model.eval()
        x = torch.randint(0, min(model.config.vocab_size, 32000), (1, 8))
        with torch.no_grad():
            result = model(x, output_aux=True)
        aux = getattr(result, "moe_aux", None)
        assert isinstance(aux, dict) and aux, \
            f"blackmamba output_aux=True must fill moe_aux; got {aux}"
        assert "aux_loss_total" in aux, \
            f"mamba MoE aux not aggregated. keys: {list(aux)}"
