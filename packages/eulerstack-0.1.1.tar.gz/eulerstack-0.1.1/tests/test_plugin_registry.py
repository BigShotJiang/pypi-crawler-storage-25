# tests/test_plugin_registry.py
"""Plugin registry contract tests (RED).

The plugin registry lets enterprise-grade primitives (TTT, Titans,
branched routing) install their runtime into core's modeling layer without
core depending on them. Core provides the fallback; plugins upgrade.

Common-prompt §7: plugin presence must not change core behavior.
"""
from __future__ import annotations

from typing import Any, Dict

import pytest
import torch
import torch.nn as nn


class TestPluginRegistryContract:
    """Core-level contract: the registry lifecycle and isolation."""

    def test_registry_module_imports(self):
        from eulerstack.plugins import registry  # noqa: F401

    def test_default_registry_is_empty(self):
        from eulerstack.plugins.registry import PluginRegistry

        reg = PluginRegistry()
        assert list(reg.mixer_kinds()) == []
        assert not reg.has_mixer("ttt_layer")
        assert not reg.has_memory("neural_memory")

    def test_register_and_retrieve_mixer(self):
        from eulerstack.plugins.registry import PluginRegistry

        reg = PluginRegistry()

        def build(d_model: int, config: Dict[str, Any]) -> nn.Module:
            return nn.Linear(d_model, d_model)

        reg.register_mixer("ttt_layer", build)
        assert reg.has_mixer("ttt_layer")
        assert "ttt_layer" in list(reg.mixer_kinds())
        out = reg.build_mixer("ttt_layer", d_model=16, config={})
        assert isinstance(out, nn.Linear)
        assert out.in_features == 16

    def test_register_memory_handler(self):
        from eulerstack.plugins.registry import PluginRegistry

        reg = PluginRegistry()

        def build(d_model: int, spec: Dict[str, Any]) -> nn.Module:
            return nn.Linear(d_model, d_model)

        reg.register_memory("neural_memory", build)
        assert reg.has_memory("neural_memory")

    def test_duplicate_mixer_raises(self):
        from eulerstack.plugins.registry import PluginRegistry

        reg = PluginRegistry()
        reg.register_mixer("ttt_layer", lambda d_model, config: nn.Identity())
        with pytest.raises(KeyError):
            reg.register_mixer("ttt_layer", lambda d_model, config: nn.Identity())

    def test_duplicate_mixer_with_exist_ok(self):
        from eulerstack.plugins.registry import PluginRegistry

        reg = PluginRegistry()
        reg.register_mixer("ttt_layer", lambda d_model, config: nn.Identity())
        # exist_ok overwrites silently
        reg.register_mixer("ttt_layer", lambda d_model, config: nn.Linear(8, 8), exist_ok=True)
        out = reg.build_mixer("ttt_layer", d_model=8, config={})
        assert isinstance(out, nn.Linear)

    def test_unknown_mixer_raises(self):
        from eulerstack.plugins.registry import PluginRegistry

        reg = PluginRegistry()
        with pytest.raises(KeyError):
            reg.build_mixer("unknown_kind", d_model=16, config={})

    def test_get_registry_is_singleton(self):
        from eulerstack.plugins.registry import get_plugin_registry

        r1 = get_plugin_registry()
        r2 = get_plugin_registry()
        assert r1 is r2

    def test_clear_registry(self):
        from eulerstack.plugins.registry import PluginRegistry

        reg = PluginRegistry()
        reg.register_mixer("ttt_layer", lambda d_model, config: nn.Identity())
        reg.register_memory("neural_memory", lambda d_model, spec: nn.Identity())
        reg.clear()
        assert not reg.has_mixer("ttt_layer")
        assert not reg.has_memory("neural_memory")


class TestCoreBehaviorWithoutPlugins:
    """Core-only users must not see any change from plugin infra."""

    def test_core_import_does_not_require_plugins(self):
        """Importing core must not crash on a registry-less environment.

        We snapshot + clear the registry, import core, and assert the core
        module imports cleanly even when no plugins are present. (Some
        earlier test in the session may have imported `eulerstack.plugins.ttt`
        — Python's import cache keeps that module loaded process-wide, so
        we can't meaningfully assert "ttt_layer not registered" globally.
        What we can assert is that *with a cleared registry* core still
        works.)
        """
        from eulerstack.plugins.registry import get_plugin_registry

        reg = get_plugin_registry()
        saved_mixers = dict(reg._mixers)
        saved_mems = dict(reg._memories)
        reg._mixers.clear()
        reg._memories.clear()
        try:
            from eulerstack.hf.modeling_eulerstack import EulerStackForCausalLM  # noqa: F401

            # With registry empty, ttt_layer must indeed not be present.
            assert "ttt_layer" not in list(reg.mixer_kinds())
        finally:
            reg._mixers = saved_mixers
            reg._memories = saved_mems
