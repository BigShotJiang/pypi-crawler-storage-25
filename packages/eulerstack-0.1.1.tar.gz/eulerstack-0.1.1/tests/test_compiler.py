# tests/test_compiler.py
"""Compiler tests: IR → runtime config."""
from __future__ import annotations

import os
import pytest
import yaml

from eulerstack.ir.normalizer import normalize_to_ir
from eulerstack.compiler.compile import compile_ir
from eulerstack.spec.errors import CompileError


FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "docs", "fixtures")
VALID_DIR = os.path.join(FIXTURES_DIR, "valid_yamls")


def _load(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


class TestCompiler:
    def test_llama_like_compiles(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        result = compile_ir(ir)
        assert result is not None
        assert "config" in result
        assert result["config"]["n_layers"] == 4

    def test_hybrid_compiles(self):
        raw = _load(os.path.join(VALID_DIR, "hybrid_mixed.yml"))
        ir = normalize_to_ir(raw)
        result = compile_ir(ir)
        assert result["config"]["n_layers"] == 4
        assert len(result["config"]["stack"]["pattern"]) > 0

    def test_moe_compiles(self):
        raw = _load(os.path.join(VALID_DIR, "moe_model.yml"))
        ir = normalize_to_ir(raw)
        result = compile_ir(ir)
        routing = result["config"].get("routing", {})
        moe = routing.get("moe", {})
        assert moe.get("experts") == 4

    def test_compile_output_has_required_keys(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        result = compile_ir(ir)
        cfg = result["config"]
        for key in ["vocab_size", "d_model", "n_layers", "n_heads", "max_seq_len", "stack", "blocks"]:
            assert key in cfg, f"Missing key: {key}"
