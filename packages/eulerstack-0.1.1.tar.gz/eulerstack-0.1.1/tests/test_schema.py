# tests/test_schema_v2.py
"""YAML v2 schema parsing and dataclass construction tests."""
from __future__ import annotations

import os
import pytest
import yaml

from eulerstack.spec.errors import ValidationError
from eulerstack.spec.schema import parse_v2_yaml, VALID_TOP_LEVEL_KEYS


FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "docs", "fixtures")
VALID_DIR = os.path.join(FIXTURES_DIR, "valid_yamls")
INVALID_DIR = os.path.join(FIXTURES_DIR, "invalid_yamls")


def _load(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


# ── Valid fixtures must parse without error ──


class TestValidFixturesParse:
    def test_llama_like(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        result = parse_v2_yaml(raw)
        assert result["schema_version"] == 1
        assert result["model"]["name"] == "tiny-llama"

    def test_hybrid_mixed(self):
        raw = _load(os.path.join(VALID_DIR, "hybrid_mixed.yml"))
        result = parse_v2_yaml(raw)
        assert "mamba_layer" in result["layer_templates"]
        assert "attn_layer" in result["layer_templates"]
        assert "retnet_layer" in result["layer_templates"]

    def test_moe_model(self):
        raw = _load(os.path.join(VALID_DIR, "moe_model.yml"))
        result = parse_v2_yaml(raw)
        tmpl = result["layer_templates"]["moe_decoder"]
        assert tmpl["ffn"]["type"] == "moe"
        assert tmpl["ffn"]["moe"]["experts"] == 4


# ── Schema version check ──


class TestSchemaVersionCheck:
    def test_missing_schema_version_raises(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        del raw["schema_version"]
        with pytest.raises(ValidationError, match="schema_version"):
            parse_v2_yaml(raw)

    def test_wrong_schema_version_raises(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        raw["schema_version"] = 2
        with pytest.raises(ValidationError, match="schema_version"):
            parse_v2_yaml(raw)


# ── Unknown key detection ──


class TestUnknownKeyDetection:
    def test_unknown_top_level_key(self):
        raw = _load(os.path.join(INVALID_DIR, "unknown_key.yml"))
        with pytest.raises(ValidationError, match="foobar"):
            parse_v2_yaml(raw)

    def test_valid_top_level_keys_accepted(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        # Should not raise
        parse_v2_yaml(raw)


# ── Reserved namespace (Phase B0) ──


class TestReservedNamespace:
    """Keys under experimental.* / future.* / vendor.* are WARNING, not ERROR."""

    def _add_key_and_parse(self, extra_key: str, value):
        from eulerstack.spec.schema import get_reserved_warnings
        get_reserved_warnings()  # clear any prior warnings
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        raw[extra_key] = value
        # Should NOT raise
        parse_v2_yaml(raw)
        warns = get_reserved_warnings()
        assert any(k == extra_key for _, k in warns), (
            f"Expected reserved warning for {extra_key}; got {warns}"
        )

    def test_experimental_prefix_accepted_with_warning(self):
        self._add_key_and_parse("experimental.online_adaptation", {"enabled": True})

    def test_future_prefix_accepted_with_warning(self):
        self._add_key_and_parse("future.symbolic_interface", {"mode": "sidecar"})

    def test_vendor_prefix_accepted_with_warning(self):
        self._add_key_and_parse("vendor.acme.custom", {"foo": "bar"})

    def test_plain_unknown_key_still_errors(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        raw["foobar"] = {"x": 1}
        with pytest.raises(ValidationError, match="foobar"):
            parse_v2_yaml(raw)


# ── Per-layer override (Phase B1.1) ──


class TestPerLayerOverride:
    """Schedule-entry override validation & IR materialization."""

    def test_valid_override_fixture_parses(self):
        raw = _load(os.path.join(VALID_DIR, "per_layer_override.yml"))
        parse_v2_yaml(raw)  # should not raise

    def test_invalid_override_fixture_raises(self):
        raw = _load(os.path.join(INVALID_DIR, "override_unknown_path.yml"))
        with pytest.raises(ValidationError, match="override"):
            parse_v2_yaml(raw)

    def test_override_ir_applied_to_first_group(self):
        from eulerstack.ir.normalizer import normalize_to_ir
        raw = _load(os.path.join(VALID_DIR, "per_layer_override.yml"))
        ir = normalize_to_ir(raw)
        # First 2 layers (override group) must have scaling=0.5, window=128.
        # Remaining 4 layers keep template defaults (scaling=1.0, window=None).
        assert ir.expanded_layers[0].residual.scaling == 0.5
        assert ir.expanded_layers[0].mixer.config["window"] == 128
        assert ir.expanded_layers[1].residual.scaling == 0.5
        assert ir.expanded_layers[2].residual.scaling == 1.0
        assert ir.expanded_layers[2].mixer.config.get("window") is None
        assert len(ir.expanded_layers) == 6

    def test_override_param_count_preserved(self):
        """Override must not change parameter count."""
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.spec.param_estimator import estimate_params
        raw = _load(os.path.join(VALID_DIR, "per_layer_override.yml"))
        ir_with_ov = normalize_to_ir(raw)
        # Remove the override and re-estimate
        raw2 = dict(raw)
        raw2["layer_schedule"] = [
            {"template": "attn_dense", "repeat": 6},
        ]
        ir_without_ov = normalize_to_ir(raw2)
        assert estimate_params(ir_with_ov) == estimate_params(ir_without_ov)


# ── let: + ${...} expressions (Phase B1.2) ──


class TestLetExpressions:
    """Pre-pass resolves numeric references and Level-1 arithmetic."""

    def test_valid_let_fixture_parses_and_resolves(self):
        raw = _load(os.path.join(VALID_DIR, "let_expressions.yml"))
        result = parse_v2_yaml(raw)
        # let: must be stripped from the output (pre-pass only)
        assert "let" not in result
        # Arithmetic must be evaluated
        assert result["model"]["d_model"] == 256       # 8 * 32
        assert result["model"]["max_seq_len"] == 2048  # 512 * 4
        assert result["model"]["n_heads"] == 8
        assert result["model"]["n_kv_heads"] == 4      # 8 // 2
        assert result["layer_schedule"][0]["repeat"] == 3

    def test_let_disallowed_syntax_raises(self):
        raw = _load(os.path.join(INVALID_DIR, "let_disallowed_syntax.yml"))
        with pytest.raises(ValidationError):
            parse_v2_yaml(raw)

    def test_undefined_reference_raises(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        raw["model"]["d_model"] = "${let.undefined_var * 2}"
        with pytest.raises(ValidationError, match="undefined_var"):
            parse_v2_yaml(raw)

    def test_function_call_rejected(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        raw["let"] = {"x": 16}
        raw["model"]["d_model"] = "${min(let.x, 32)}"
        with pytest.raises(ValidationError):
            parse_v2_yaml(raw)

    def test_attribute_outside_let_rejected(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        raw["let"] = {"x": 16}
        raw["model"]["d_model"] = "${model.n_heads * 2}"
        with pytest.raises(ValidationError):
            parse_v2_yaml(raw)


# ── Phase B2: new mixer types (MLA / branched / TTT) ──


class TestNewMixerTypes:
    def test_mla_latent_dim_parses(self):
        from eulerstack.ir.normalizer import normalize_to_ir
        raw = _load(os.path.join(VALID_DIR, "mla_attention.yml"))
        ir = normalize_to_ir(raw)
        assert ir.expanded_layers[0].mixer.type == "attention"
        assert ir.expanded_layers[0].mixer.config["latent_dim"] == 128

    def test_mla_latent_dim_must_be_positive(self):
        raw = _load(os.path.join(VALID_DIR, "mla_attention.yml"))
        raw["layer_templates"]["mla"]["mixer"]["attention"]["latent_dim"] = 0
        with pytest.raises(ValidationError, match="latent_dim"):
            parse_v2_yaml(raw)

    def test_mla_latent_dim_equal_to_d_model_rejected(self):
        """Cross-field: latent_dim >= d_model is caught by validate_v2()."""
        from eulerstack.spec.validate import validate_v2
        raw = _load(os.path.join(INVALID_DIR, "mla_latent_equals_d_model.yml"))
        with pytest.raises(ValidationError, match="strictly less than"):
            validate_v2(raw)

    def test_mla_latent_dim_greater_than_d_model_rejected(self):
        from eulerstack.spec.validate import validate_v2
        raw = _load(os.path.join(VALID_DIR, "mla_attention.yml"))
        d = raw["model"]["d_model"]
        raw["layer_templates"]["mla"]["mixer"]["attention"]["latent_dim"] = d + 16
        with pytest.raises(ValidationError, match="strictly less than"):
            validate_v2(raw)

    def test_branched_mixer_parses(self):
        from eulerstack.ir.normalizer import normalize_to_ir
        raw = _load(os.path.join(VALID_DIR, "branched_mixer.yml"))
        ir = normalize_to_ir(raw)
        layer = ir.expanded_layers[0]
        assert layer.mixer.type == "branched"
        assert set(layer.mixer.config["branches"].keys()) == {"ssm", "attn"}
        assert layer.mixer.config["selector"]["type"] == "learned_gate"

    def test_branched_requires_at_least_two_branches(self):
        raw = _load(os.path.join(VALID_DIR, "branched_mixer.yml"))
        # Keep only one branch → error
        raw["layer_templates"]["branched_layer"]["mixer"]["branched"]["branches"] = {
            "only_one": {"type": "attention", "attention": {}}
        }
        with pytest.raises(ValidationError, match="branches"):
            parse_v2_yaml(raw)

    def test_branched_nested_rejected(self):
        raw = _load(os.path.join(INVALID_DIR, "branched_nested_not_allowed.yml"))
        with pytest.raises(ValidationError, match="nested"):
            parse_v2_yaml(raw)

    def test_ttt_layer_parses(self):
        from eulerstack.ir.normalizer import normalize_to_ir
        raw = _load(os.path.join(VALID_DIR, "ttt_layer.yml"))
        ir = normalize_to_ir(raw)
        assert ir.expanded_layers[0].mixer.type == "ttt_layer"
        cfg = ir.expanded_layers[0].mixer.config
        assert cfg["inner_optimizer"] == "sgd"
        assert cfg["inner_lr"] == 0.01
        assert cfg["inner_model"]["hidden"] == 128
        # TTT layers default to ssm_state=True (persistent inner weights)
        assert ir.expanded_layers[0].state.ssm_state is True

    def test_ttt_layer_rejects_negative_lr(self):
        raw = _load(os.path.join(VALID_DIR, "ttt_layer.yml"))
        raw["layer_templates"]["ttt_block"]["mixer"]["ttt"]["inner_lr"] = -0.01
        with pytest.raises(ValidationError, match="inner_lr"):
            parse_v2_yaml(raw)


# ── Phase B3: schedule extensions (MoD / parallel / integrator) ──


class TestScheduleExtensions:
    def test_depth_gating_parses_and_captured_in_ir(self):
        from eulerstack.ir.normalizer import normalize_to_ir
        raw = _load(os.path.join(VALID_DIR, "depth_gating_mod.yml"))
        ir = normalize_to_ir(raw)
        se = ir.layer_schedule[0]
        assert se.depth_gating is not None
        assert se.depth_gating.capacity == 0.5
        assert se.depth_gating.router == "top_k"
        # 4 layers expanded
        assert len(ir.expanded_layers) == 4

    def test_depth_gating_capacity_out_of_range_rejected(self):
        raw = _load(os.path.join(INVALID_DIR, "depth_gating_bad_capacity.yml"))
        with pytest.raises(ValidationError, match="capacity"):
            parse_v2_yaml(raw)

    def test_parallel_entry_parses(self):
        from eulerstack.ir.normalizer import normalize_to_ir
        raw = _load(os.path.join(VALID_DIR, "parallel_dual_stream.yml"))
        ir = normalize_to_ir(raw)
        se = ir.layer_schedule[0]
        assert se.kind == "parallel"
        assert len(se.parallel.streams) == 2
        names = {s.name for s in se.parallel.streams}
        assert names == {"fast", "slow"}
        assert se.parallel.merge_type == "concat"
        # expanded = 2 (mamba) + 2 (attn) = 4 layers total after flattening
        assert len(ir.expanded_layers) == 4

    def test_parallel_requires_min_two_streams(self):
        raw = _load(os.path.join(VALID_DIR, "parallel_dual_stream.yml"))
        raw["layer_schedule"][0]["parallel"] = [
            {"stream": "solo", "body": [{"template": "attn_block", "repeat": 1}]}
        ]
        with pytest.raises(ValidationError, match="at least 2 streams"):
            parse_v2_yaml(raw)

    def test_schedule_mixed_kinds_rejected(self):
        raw = _load(os.path.join(INVALID_DIR, "schedule_entry_mixed_kinds.yml"))
        with pytest.raises(ValidationError, match="mixing"):
            parse_v2_yaml(raw)

    def test_integrator_discrete_parses(self):
        from eulerstack.ir.normalizer import normalize_to_ir
        raw = _load(os.path.join(VALID_DIR, "integrator_discrete.yml"))
        ir = normalize_to_ir(raw)
        se = ir.layer_schedule[0]
        assert se.kind == "integrator"
        assert se.integrator.integrator_type == "discrete"
        assert se.integrator.steps == 4
        assert se.integrator.output == "token"
        # expanded = body × steps = 4
        assert len(ir.expanded_layers) == 4

    def test_integrator_continuous_reserved_rejected(self):
        raw = _load(os.path.join(INVALID_DIR, "integrator_continuous_reserved.yml"))
        with pytest.raises(ValidationError, match="reserved"):
            parse_v2_yaml(raw)

    def test_integrator_output_enum_enforced(self):
        raw = _load(os.path.join(VALID_DIR, "integrator_discrete.yml"))
        raw["layer_schedule"][0]["integrator"]["output"] = "garbage"
        with pytest.raises(ValidationError):
            parse_v2_yaml(raw)


# ── Phase B4: template extensions (memory / shape_change) ──


class TestTemplateExtensions:
    def test_memory_module_parses(self):
        from eulerstack.ir.normalizer import normalize_to_ir
        raw = _load(os.path.join(VALID_DIR, "memory_module_titans.yml"))
        ir = normalize_to_ir(raw)
        tmpl = ir.layer_templates["attn_with_mem"]
        assert tmpl.memory is not None
        assert tmpl.memory.type == "neural_memory"
        assert tmpl.memory.update_at_inference is True
        assert tmpl.memory.hidden == 1024
        assert tmpl.memory.persistence == "session"

    def test_memory_bad_type_rejected(self):
        raw = _load(os.path.join(INVALID_DIR, "memory_bad_type.yml"))
        with pytest.raises(ValidationError, match="quantum_ram"):
            parse_v2_yaml(raw)

    def test_memory_negative_lr_rejected(self):
        raw = _load(os.path.join(VALID_DIR, "memory_module_titans.yml"))
        raw["layer_templates"]["attn_with_mem"]["memory"]["inner_lr"] = -1e-3
        with pytest.raises(ValidationError, match="inner_lr"):
            parse_v2_yaml(raw)

    def test_shape_change_parses(self):
        from eulerstack.ir.normalizer import normalize_to_ir
        raw = _load(os.path.join(VALID_DIR, "shape_change_hourglass.yml"))
        ir = normalize_to_ir(raw)
        bn = ir.layer_templates["bottleneck_block"]
        assert bn.shape_change is not None
        assert bn.shape_change.d_out == 128
        assert bn.shape_change.projection == "linear"
        wide = ir.layer_templates["wide_block"]
        assert wide.shape_change is None

    def test_shape_change_missing_d_out(self):
        raw = _load(os.path.join(INVALID_DIR, "shape_change_missing_d_out.yml"))
        with pytest.raises(ValidationError, match="d_out"):
            parse_v2_yaml(raw)

    def test_shape_change_projection_enum(self):
        raw = _load(os.path.join(VALID_DIR, "shape_change_hourglass.yml"))
        raw["layer_templates"]["bottleneck_block"]["shape_change"]["projection"] = "bogus"
        with pytest.raises(ValidationError):
            parse_v2_yaml(raw)


# ── Phase B5: execution_modes (R1 / Quiet-STaR) ──


class TestExecutionModes:
    def test_r1_two_phase_parses(self):
        from eulerstack.ir.normalizer import normalize_to_ir
        raw = _load(os.path.join(VALID_DIR, "reasoning_mode_r1.yml"))
        ir = normalize_to_ir(raw)
        assert ir.execution_modes is not None
        assert len(ir.execution_modes) == 2
        think, answer = ir.execution_modes
        assert think.name == "think"
        assert think.loss_weight == 0.0
        assert think.visible_to_user is False
        assert answer.name == "answer"
        assert answer.loss_weight == 1.0
        assert ir.transition is not None
        assert ir.transition.type == "special_token"
        assert ir.transition.token == "<think_end>"

    def test_duplicate_mode_names_rejected(self):
        raw = _load(os.path.join(INVALID_DIR, "exec_modes_duplicate_name.yml"))
        with pytest.raises(ValidationError, match="duplicate"):
            parse_v2_yaml(raw)

    def test_transition_special_token_requires_token(self):
        raw = _load(os.path.join(INVALID_DIR, "transition_missing_token.yml"))
        with pytest.raises(ValidationError, match="token"):
            parse_v2_yaml(raw)

    def test_loss_weight_negative_rejected(self):
        raw = _load(os.path.join(VALID_DIR, "reasoning_mode_r1.yml"))
        raw["execution_modes"][0]["loss_weight"] = -0.5
        with pytest.raises(ValidationError, match="loss_weight"):
            parse_v2_yaml(raw)

    def test_max_tokens_positive_enforced(self):
        raw = _load(os.path.join(VALID_DIR, "reasoning_mode_r1.yml"))
        raw["execution_modes"][0]["max_tokens"] = 0
        with pytest.raises(ValidationError):
            parse_v2_yaml(raw)

    def test_standard_model_has_no_execution_modes(self):
        """A normal model without execution_modes must still work."""
        from eulerstack.ir.normalizer import normalize_to_ir
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        assert ir.execution_modes is None
        assert ir.transition is None


# ── Phase B6: reserved namespace surface via report ──


WARNING_DIR = os.path.join(FIXTURES_DIR, "warning_yamls")


class TestReservedNamespaceReporting:
    """The report must surface reserved-namespace keys as WARNING findings."""

    def test_experimental_warning_in_report(self):
        from eulerstack.spec.report import generate_report
        raw = _load(os.path.join(WARNING_DIR, "reserved_experimental_namespace.yml"))
        rpt = generate_report(raw)
        assert rpt.schema_ok
        assert not rpt.has_errors
        reserved = [f for f in rpt.warnings if f.rule == "reserved_namespace"]
        assert len(reserved) >= 1
        assert any("experimental" in f.message for f in reserved)

    def test_vendor_warning_in_report(self):
        from eulerstack.spec.report import generate_report
        raw = _load(os.path.join(WARNING_DIR, "reserved_vendor_namespace.yml"))
        rpt = generate_report(raw)
        assert rpt.schema_ok
        reserved = [f for f in rpt.warnings if f.rule == "reserved_namespace"]
        assert any("vendor" in f.message for f in reserved)

    def test_future_warning_in_report(self):
        from eulerstack.spec.report import generate_report
        raw = _load(os.path.join(WARNING_DIR, "reserved_future_namespace.yml"))
        rpt = generate_report(raw)
        assert rpt.schema_ok
        reserved = [f for f in rpt.warnings if f.rule == "reserved_namespace"]
        assert any("future" in f.message for f in reserved)

    def test_clean_model_has_no_reserved_warning(self):
        from eulerstack.spec.report import generate_report
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        rpt = generate_report(raw)
        reserved = [f for f in rpt.warnings if f.rule == "reserved_namespace"]
        assert len(reserved) == 0

    def test_reserved_warnings_cleared_between_parses(self):
        """Successive generate_report calls must not accumulate warnings."""
        from eulerstack.spec.report import generate_report
        raw1 = _load(os.path.join(WARNING_DIR, "reserved_experimental_namespace.yml"))
        raw2 = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        rpt1 = generate_report(raw1)
        rpt2 = generate_report(raw2)
        r1 = [f for f in rpt1.warnings if f.rule == "reserved_namespace"]
        r2 = [f for f in rpt2.warnings if f.rule == "reserved_namespace"]
        assert len(r1) >= 1
        assert len(r2) == 0


# ── Required field checks ──


class TestRequiredFields:
    def test_missing_model_d_model(self):
        raw = _load(os.path.join(INVALID_DIR, "missing_required.yml"))
        with pytest.raises(ValidationError, match="d_model"):
            parse_v2_yaml(raw)

    def test_missing_tokenizer_pretrained(self):
        raw = _load(os.path.join(INVALID_DIR, "bad_tokenizer_contract.yml"))
        with pytest.raises(ValidationError, match="pretrained"):
            parse_v2_yaml(raw)


# ── Enum validation ──


class TestEnumValidation:
    def test_invalid_mixer_type(self):
        raw = _load(os.path.join(INVALID_DIR, "invalid_enum.yml"))
        with pytest.raises(ValidationError, match="transformer"):
            parse_v2_yaml(raw)

    def test_invalid_compile_target(self):
        raw = _load(os.path.join(INVALID_DIR, "unsupported_compile_target.yml"))
        with pytest.raises(ValidationError, match="tensorrt"):
            parse_v2_yaml(raw)
