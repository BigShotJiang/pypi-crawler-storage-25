# tests/test_retnet_stability.py
"""Numerical stability tests for RetNet block.

Regression: the normalized retention formulation `out = num / (den + eps)`
produced NaN gradients whenever `den` was near zero (since Q·K can be
signed, and eps could not rescue `den ≈ -eps`). This test ensures
forward + backward produce finite values for signed random inputs and
for bfloat16 autocast.
"""
from __future__ import annotations

import pytest
import torch

from eulerstack.blocks.retnet import (
    MultiScaleRetention,
    RetNetBlock,
    retention_chunk,
)


@pytest.fixture(scope="module", autouse=True)
def _cublaslt_workaround():
    """RTX 5090 (Blackwell) needs cublaslt preference for bf16 gemm."""
    if torch.cuda.is_available():
        try:
            torch.backends.cuda.preferred_blas_library("cublaslt")
        except Exception:
            pass
    yield


@pytest.fixture(scope="module")
def seed():
    torch.manual_seed(0)


def _make_signed_qkv(b=2, h=4, n=16, d=8):
    """Signed random Q/K/V with values spanning [-2, 2] (will hit Q·K negative region)."""
    q = torch.randn(b, h, n, d) * 2.0
    k = torch.randn(b, h, n, d) * 2.0
    v = torch.randn(b, h, n, d) * 0.5
    return q, k, v


def _make_gammas(h=4):
    idx = torch.linspace(0.0, 1.0, steps=h)
    return 1.0 - 10.0 ** (-2.0 - 3.0 * idx)


def test_retention_chunk_forward_is_finite(seed):
    """Forward pass with signed Q/K must not produce NaN/Inf."""
    q, k, v = _make_signed_qkv()
    gammas = _make_gammas(h=q.size(1))
    out, new_num, new_den = retention_chunk(q, k, v, None, None, gammas)
    assert torch.isfinite(out).all(), "retention_chunk forward produced non-finite values"


def test_retention_chunk_backward_is_finite(seed):
    """Backward through retention_chunk must produce finite gradients.

    This is the regression case: Q·K can be negative → den can be near zero →
    gradient w.r.t. den is -num/(den+eps)^2 which explodes. The fix must
    keep the denominator bounded away from zero.
    """
    q, k, v = _make_signed_qkv()
    q.requires_grad_(True)
    k.requires_grad_(True)
    v.requires_grad_(True)
    gammas = _make_gammas(h=q.size(1))
    out, _, _ = retention_chunk(q, k, v, None, None, gammas)
    loss = out.pow(2).mean()
    loss.backward()
    assert torch.isfinite(q.grad).all(), "NaN in ∂loss/∂q"
    assert torch.isfinite(k.grad).all(), "NaN in ∂loss/∂k"
    assert torch.isfinite(v.grad).all(), "NaN in ∂loss/∂v"


def test_retnet_block_forward_backward_no_nan(seed):
    """End-to-end RetNetBlock fwd/bwd with signed random input — no NaN."""
    block = RetNetBlock(d_model=64, n_heads=4, mlp_ratio=4, chunkwise=True, chunk_size=128)
    x = (torch.randn(2, 32, 64) * 2.0).requires_grad_(True)
    y, _ = block(x)
    loss = y.pow(2).mean()
    loss.backward()
    assert torch.isfinite(y).all(), "RetNetBlock forward produced NaN/Inf"
    assert torch.isfinite(x.grad).all(), "RetNetBlock backward produced NaN/Inf"
    # Also check model weight gradients:
    for name, p in block.named_parameters():
        if p.grad is not None:
            assert torch.isfinite(p.grad).all(), f"NaN in grad of {name}"


def test_retnet_block_bfloat16_no_nan(seed):
    """bfloat16 autocast path must not produce NaN (the arch_e2e failure mode)."""
    if not torch.cuda.is_available():
        pytest.skip("bfloat16 autocast requires CUDA")
    device = "cuda"
    block = RetNetBlock(d_model=64, n_heads=4, mlp_ratio=4).to(device)
    x = (torch.randn(2, 32, 64, device=device) * 2.0).requires_grad_(True)
    with torch.amp.autocast("cuda", dtype=torch.bfloat16):
        y, _ = block(x)
        loss = y.pow(2).mean()
    loss.backward()
    assert torch.isfinite(y).all()
    assert torch.isfinite(x.grad).all()
    for name, p in block.named_parameters():
        if p.grad is not None:
            assert torch.isfinite(p.grad).all(), f"NaN in grad of {name}"


def test_multi_scale_retention_with_rope(seed):
    """MultiScaleRetention with RoPE enabled — regression for the arch_ preset path."""
    from eulerstack.components.positional import build_rope_cache

    d_model = 64
    n_heads = 4
    max_seq_len = 32
    head_dim = d_model // n_heads
    msr = MultiScaleRetention(
        d_model=d_model, n_heads=n_heads, rope=True, chunkwise=True, chunk_size=64,
    )
    cos, sin = build_rope_cache(head_dim=head_dim, max_seq_len=max_seq_len, rope_theta=10000.0)
    x = (torch.randn(2, max_seq_len, d_model) * 1.5).requires_grad_(True)
    out, _ = msr(x, rope_cos=cos, rope_sin=sin)
    loss = out.pow(2).mean()
    loss.backward()
    assert torch.isfinite(out).all()
    assert torch.isfinite(x.grad).all()
    for name, p in msr.named_parameters():
        if p.grad is not None:
            assert torch.isfinite(p.grad).all(), f"NaN in grad of {name}"


def test_retention_denominator_always_positive(seed):
    """Invariant — after the fix the effective denominator in retention must be ≥ 0.

    This is what prevents the division explosion. We check by running many
    random signed inputs and asserting the model doesn't produce NaN.
    """
    block = RetNetBlock(d_model=32, n_heads=4)
    for trial in range(5):
        torch.manual_seed(trial)
        x = torch.randn(1, 16, 32) * 3.0  # Large magnitude stresses the divisor
        y, _ = block(x)
        assert torch.isfinite(y).all(), f"Trial {trial}: non-finite output"


def test_retnet_preset_scale_bfloat16_cuda():
    """Production-scale reproduction: d_model=1024, head_dim=64, seq_len=512, bf16.

    This mirrors the arch_expert_retnet_moe config that fails in arch_e2e with
    grad_norm=nan at step 1.
    """
    if not torch.cuda.is_available():
        pytest.skip("bfloat16 retnet stability requires CUDA")

    torch.manual_seed(0)
    device = "cuda"
    d_model, n_heads, seq_len = 1024, 16, 512
    block = RetNetBlock(
        d_model=d_model, n_heads=n_heads, mlp_ratio=4, chunkwise=True, chunk_size=128,
    ).to(device)

    # Simulate a realistic embedding output with std≈1 (like normal_0.02 init of embedding
    # followed by activations at step 1)
    x = (torch.randn(1, seq_len, d_model, device=device)).requires_grad_(True)

    with torch.amp.autocast("cuda", dtype=torch.bfloat16):
        y, _ = block(x)
        loss = y.pow(2).mean()
    loss.backward()

    assert torch.isfinite(y).all(), "bf16 prod-scale: forward produced NaN"
    assert torch.isfinite(x.grad).all(), "bf16 prod-scale: input grad is NaN"
    for name, p in block.named_parameters():
        if p.grad is not None:
            assert torch.isfinite(p.grad).all(), f"bf16 prod-scale: NaN in grad of {name}"


def test_retnet_preset_scale_with_rope_bfloat16():
    """Same as above but with RoPE enabled, matching arch_advanced_retnet config."""
    if not torch.cuda.is_available():
        pytest.skip("requires CUDA")
    from eulerstack.components.positional import build_rope_cache

    torch.manual_seed(0)
    device = "cuda"
    d_model, n_heads, seq_len = 1536, 16, 512
    head_dim = d_model // n_heads

    msr = MultiScaleRetention(
        d_model=d_model, n_heads=n_heads, rope=True, chunkwise=True, chunk_size=128,
    ).to(device)

    cos, sin = build_rope_cache(head_dim=head_dim, max_seq_len=seq_len, rope_theta=10000.0)
    cos, sin = cos.to(device), sin.to(device)

    x = (torch.randn(1, seq_len, d_model, device=device)).requires_grad_(True)

    with torch.amp.autocast("cuda", dtype=torch.bfloat16):
        out, _ = msr(x, rope_cos=cos, rope_sin=sin)
        loss = out.pow(2).mean()
    loss.backward()

    assert torch.isfinite(out).all()
    assert torch.isfinite(x.grad).all()
    for name, p in msr.named_parameters():
        if p.grad is not None:
            assert torch.isfinite(p.grad).all(), f"NaN in grad of {name}"


def test_retnet_full_hf_stack_bfloat16_step():
    """Full reproduction: HF EulerStackForCausalLM built from arch_advanced_retnet preset,
    one forward/backward step with token IDs and CE loss. Mirrors the arch_e2e path.
    """
    if not torch.cuda.is_available():
        pytest.skip("requires CUDA")
    import os
    import yaml
    from eulerstack.ir.normalizer import normalize_to_ir
    from eulerstack.compiler.compile import compile_to_hf_model

    presets_dir = os.path.join(
        os.path.dirname(__file__), "..", "configs", "presets",
    )
    preset_path = os.path.join(presets_dir, "arch_advanced_retnet.yml")
    if not os.path.exists(preset_path):
        pytest.skip(f"Preset missing: {preset_path}")

    with open(preset_path) as f:
        raw = yaml.safe_load(f)

    # Full production scale — do NOT shrink; this is the arch_e2e failure config.
    raw["model"]["max_seq_len"] = 512

    ir = normalize_to_ir(raw)
    torch.manual_seed(42)
    model = compile_to_hf_model(ir).to("cuda", dtype=torch.bfloat16)
    model.train()

    # Fake a batch: token IDs within vocab. Match production seq_len=512.
    input_ids = torch.randint(0, ir.model.vocab_size, (1, 512), device="cuda")
    labels = input_ids.clone()

    with torch.amp.autocast("cuda", dtype=torch.bfloat16):
        out = model(input_ids=input_ids, labels=labels)
        loss = out.loss

    assert torch.isfinite(loss), f"Forward loss not finite: {loss}"

    loss.backward()

    # Check every parameter gradient is finite (the NaN we're chasing).
    bad = [n for n, p in model.named_parameters() if p.grad is not None and not torch.isfinite(p.grad).all()]
    assert not bad, f"NaN gradients found in: {bad[:5]}... (total {len(bad)})"
