"""Regression: every examples/*.py must have at least one tutorial reference
in both docs/tutorials/ko/ and docs/tutorials/en/.

Why this test exists — past incidents: 04_pretrain_tokenize.py and
05_pretrain_train.py were both added to examples/ but the root README's
Examples section listed only 01-03, so new users never discovered them.
This test makes that kind of drift surface at CI time.

Contract:
- An example is "referenced" if its filename appears in at least one .md
  under the tutorial root. The form can be `examples/04_pretrain_tokenize.py`
  inside a prose link OR a fenced code block — we grep the filename.
- Both language trees (ko, en) are checked because common-prompt §6 requires
  i18n symmetry across CLI+doc surfaces.
"""
from __future__ import annotations

import pathlib

import pytest


_REPO = pathlib.Path(__file__).resolve().parent.parent
_EXAMPLES_DIR = _REPO / "examples"
_KO_TUTORIALS = _REPO / "docs" / "tutorials" / "ko"
_EN_TUTORIALS = _REPO / "docs" / "tutorials" / "en"


def _example_scripts() -> list[str]:
    """Return basenames of every runnable example under examples/."""
    return sorted(p.name for p in _EXAMPLES_DIR.glob("*.py")
                  if not p.name.startswith("_"))


def _references_in(tree: pathlib.Path, script_name: str) -> list[pathlib.Path]:
    """Return tutorial .md files that mention the example script."""
    hits: list[pathlib.Path] = []
    for md in tree.rglob("*.md"):
        if script_name in md.read_text():
            hits.append(md)
    return hits


@pytest.mark.parametrize("script", _example_scripts())
class TestExampleIsReferenced:
    """Each examples/*.py must be mentioned in at least one tutorial per lang."""

    def test_ko_tutorial_mentions_it(self, script: str):
        refs = _references_in(_KO_TUTORIALS, script)
        assert refs, (
            f"examples/{script} is never referenced in docs/tutorials/ko/. "
            f"Add it to the tutorial that walks its flow (see sibling ko/12_"
            f"pretrain_your_preset.md for the pattern) or, if it is an "
            f"internal helper, rename it with an underscore prefix."
        )

    def test_en_tutorial_mentions_it(self, script: str):
        refs = _references_in(_EN_TUTORIALS, script)
        assert refs, (
            f"examples/{script} is never referenced in docs/tutorials/en/. "
            f"Add the English mirror of the ko entry — common-prompt §6 "
            f"requires ko/en symmetry."
        )


class TestRootReadmeListsEveryExample:
    """Both root READMEs (en + ko) must list every examples/*.py in the
    top-level Examples section. This was the exact regression that motivated
    this test file: 04 and 05 were silently missing from the root READMEs
    even though tutorial 12 covered them end-to-end."""

    @pytest.mark.parametrize("readme", [
        "README.md",
        "README.ko.md",
    ])
    def test_every_script_appears(self, readme: str):
        body = (_REPO / readme).read_text()
        missing = [s for s in _example_scripts() if s not in body]
        assert not missing, (
            f"{readme} does not mention these example scripts in its body: "
            f"{missing}. Add them to the ## Examples section."
        )
