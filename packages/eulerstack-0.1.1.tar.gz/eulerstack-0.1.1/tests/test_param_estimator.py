# tests/test_param_estimator.py
"""Parameter estimator unit tests."""
from __future__ import annotations

import os
import pytest
import yaml

from eulerstack.ir.normalizer import normalize_to_ir
from eulerstack.spec.param_estimator import estimate_params, format_param_count


FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "docs", "fixtures")
VALID_DIR = os.path.join(FIXTURES_DIR, "valid_yamls")


def _load(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


class TestEstimateParams:
    def test_returns_positive_int(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        est = estimate_params(ir)
        assert isinstance(est, int)
        assert est > 0

    def test_larger_model_has_more_params(self):
        """A model with more layers / larger d_model should have more params."""
        raw1 = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir1 = normalize_to_ir(raw1)
        est1 = estimate_params(ir1)

        raw2 = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        raw2["model"]["d_model"] = 512
        raw2["model"]["n_heads"] = 8
        raw2["model"]["n_kv_heads"] = 4
        ir2 = normalize_to_ir(raw2)
        est2 = estimate_params(ir2)
        assert est2 > est1

    def test_moe_has_more_params_than_dense(self):
        """MoE model should have more params than equivalent dense."""
        llama = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        moe = _load(os.path.join(VALID_DIR, "moe_model.yml"))
        # Make comparable: same d_model
        moe["model"]["d_model"] = llama["model"]["d_model"]
        moe["model"]["n_heads"] = llama["model"]["n_heads"]
        moe["model"]["vocab_size"] = llama["model"]["vocab_size"]

        ir_llama = normalize_to_ir(llama)
        ir_moe = normalize_to_ir(moe)
        assert estimate_params(ir_moe) > estimate_params(ir_llama)

    def test_tied_weights_reduces_params(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        raw["head"]["tie_weights"] = True
        ir_tied = normalize_to_ir(raw)
        est_tied = estimate_params(ir_tied)

        raw2 = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        raw2["head"]["tie_weights"] = False
        ir_untied = normalize_to_ir(raw2)
        est_untied = estimate_params(ir_untied)

        assert est_untied > est_tied


class TestFormatParamCount:
    def test_billions(self):
        assert "B" in format_param_count(2_000_000_000)

    def test_millions(self):
        assert "M" in format_param_count(800_000_000)

    def test_thousands(self):
        assert "K" in format_param_count(1500)

    def test_small(self):
        assert format_param_count(42) == "42"
