"""Environment / dependency-pin guards.

These tests protect against regressions that live outside source code —
e.g. a known-broken upstream release that we must not let users install.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest


_PROJECT_ROOT = Path(__file__).resolve().parent.parent
_PYPROJECT = _PROJECT_ROOT / "pyproject.toml"


def _read_pyproject_deps() -> list[str]:
    text = _PYPROJECT.read_text()
    m = re.search(r"dependencies\s*=\s*\[(.*?)\]", text, re.DOTALL)
    assert m, f"could not locate dependencies block in {_PYPROJECT}"
    raw = m.group(1)
    deps = [d.strip().strip(",").strip('"').strip("'")
            for d in raw.splitlines() if d.strip() and not d.strip().startswith("#")]
    # Strip trailing commas and quotes that survive splitlines trimming.
    return [d.strip().strip(",").strip('"').strip("'") for d in deps if d]


class TestTorchVersionPin:
    """Guard: PyTorch 2.10.x must be excluded.

    Root cause: PyTorch 2.10.0+cu128 ships a CUBLAS regression for bf16/fp16
    GEMM on Blackwell (RTX 5090, sm_120). Forward on any bf16/fp16 attention
    Linear dies with ``CUBLAS_STATUS_INVALID_VALUE``. 2.8.x is known-good;
    2.9.x was never released broadly. We keep the ceiling at ``<2.10`` until
    an upstream fix lands.

    See: https://qiita.com/… (referenced in the v1 release notes).
    """

    def test_pyproject_pins_torch_below_2_10(self):
        deps = _read_pyproject_deps()
        torch_specs = [d for d in deps if d.lower().startswith("torch")
                       and not d.lower().startswith("torchvision")
                       and not d.lower().startswith("torchaudio")]
        assert torch_specs, f"no torch spec found in dependencies: {deps}"
        spec = torch_specs[0]
        assert "<2.10" in spec.replace(" ", ""), (
            f"pyproject.toml torch spec '{spec}' must exclude 2.10+; "
            f"bf16 GEMM regressions on Blackwell / sm_120."
        )

    # (runtime torch version check is intentionally not enforced at test
    # time — `test_bf16_linear_gemm` below is the real runtime guard: it
    # exercises the exact failure mode rather than relying on version
    # string heuristics, and it skips cleanly on CPU-only hosts.)


@pytest.mark.skipif(
    not __import__("importlib").util.find_spec("torch"),
    reason="torch not installed",
)
class TestCudaBf16Sanity:
    """Fast runtime probe: if CUDA is available, a bf16 matmul at attention
    QKV scale must succeed. Catches the exact failure mode users hit on
    Blackwell + bad torch.

    Skips silently on CPU-only environments.
    """

    def test_bf16_linear_gemm(self):
        torch = __import__("torch")
        if not torch.cuda.is_available():
            pytest.skip("no cuda device")
        # Shape matches the failing attention.qkv(x) in the smoke reports:
        #   x: (B*T, d_model) = (32*512, 512),  W: (3*d_model, d_model)
        x = torch.randn(16384, 512, device="cuda", dtype=torch.bfloat16)
        w = torch.randn(1536, 512, device="cuda", dtype=torch.bfloat16)
        try:
            y = torch.nn.functional.linear(x, w)
            torch.cuda.synchronize()
        except RuntimeError as e:
            pytest.fail(
                f"bf16 GEMM failed on {torch.cuda.get_device_name(0)} "
                f"with torch {torch.__version__} / CUDA {torch.version.cuda}. "
                f"This is the known Blackwell + torch 2.10 cuBLAS regression. "
                f"Underlying error: {e}"
            )
        assert y.shape == (16384, 1536)
        assert y.dtype == torch.bfloat16
