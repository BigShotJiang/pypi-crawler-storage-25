"""Tests for the public pretraining examples (examples/04, 05).

Three layers:
    - Static: scripts exist, `--help` succeeds, no import errors.
    - Functional: tokenize an 8-row fixture corpus → validate the binary
      cache schema (tokens.bin + meta.json) matches the training loader.
    - Smoke (optional, gated by RUN_EXAMPLE_SMOKE=1): compile a tiny
      preset, tokenize the fixture, train 2 steps, assert loss finite.

The smoke test is gated because it requires transformers + weight
allocation; CI runs the static and functional tests by default.
"""
from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent
EXAMPLES = REPO_ROOT / "examples"
FIXTURE_DIR = REPO_ROOT / "docs" / "fixtures"
TINY_CORPUS = FIXTURE_DIR / "tiny_corpus_sample.jsonl"
LLAMA_LIKE = FIXTURE_DIR / "valid_yamls" / "llama_like.yml"

TOKENIZE_SCRIPT = EXAMPLES / "04_pretrain_tokenize.py"
TRAIN_SCRIPT = EXAMPLES / "05_pretrain_train.py"


# ─────────────────────────────────────────────────────────────────────────────
# Static layer
# ─────────────────────────────────────────────────────────────────────────────

class TestScriptsExist:
    def test_tokenize_script_exists(self):
        assert TOKENIZE_SCRIPT.is_file(), f"missing: {TOKENIZE_SCRIPT}"

    def test_train_script_exists(self):
        assert TRAIN_SCRIPT.is_file(), f"missing: {TRAIN_SCRIPT}"

    def test_tokenize_help(self):
        r = subprocess.run(
            [sys.executable, str(TOKENIZE_SCRIPT), "--help"],
            capture_output=True, text=True, timeout=30,
        )
        assert r.returncode == 0, r.stderr
        assert "--input" in r.stdout
        assert "--tokenizer" in r.stdout
        assert "--output" in r.stdout
        assert "--seq-len" in r.stdout

    def test_train_help(self):
        r = subprocess.run(
            [sys.executable, str(TRAIN_SCRIPT), "--help"],
            capture_output=True, text=True, timeout=30,
        )
        assert r.returncode == 0, r.stderr
        assert "--model-path" in r.stdout
        # Either --data or --tokenized-dir must be discoverable.
        assert "--data" in r.stdout or "--tokenized-dir" in r.stdout
        # Benchmark flags absorbed from projects/moe_pretrain_study.
        assert "--hellaswag-n" in r.stdout
        assert "--arc-n" in r.stdout
        # Cache-dir for HF datasets benchmark downloads.
        assert "--cache-dir" in r.stdout


class TestTrainerConfigBanner:
    """The trainer's startup banner must announce every category of knob
    (Shapes / Schedule / Optimizer / Logging / Benchmark). Keeping this in
    a dedicated test prevents regressions where somebody trims the banner
    to keep logs 'short' and users lose critical context.
    """

    @pytest.fixture
    def tiny_run(self, tmp_path):
        """Spin up a 0-step dummy run to capture stdout without training."""
        pytest.importorskip("torch")
        pytest.importorskip("transformers")
        from click.testing import CliRunner
        from eulerstack.cli.main import cli

        # Compile a tiny fixture
        model_dir = tmp_path / "model"
        runner = CliRunner()
        r = runner.invoke(cli, ["compile", "--preset", str(LLAMA_LIKE),
                                  "--output-dir", str(model_dir)])
        assert r.exit_code == 0, r.output

        # Override vocab to match gpt2
        # llama_like fixture ships with vocab_size=32000 + gpt2 tokenizer
        # which mismatch; we need the aligned variant for the script to start.
        import yaml
        override = tmp_path / "override.yml"
        spec = yaml.safe_load(LLAMA_LIKE.read_text())
        spec["model"]["vocab_size"] = 50304
        override.write_text(yaml.safe_dump(spec, sort_keys=False))
        shutil.rmtree(model_dir)
        r = runner.invoke(cli, ["compile", "--preset", str(override),
                                  "--output-dir", str(model_dir)])
        assert r.exit_code == 0, r.output

        # Tokenize tiny corpus
        cache = tmp_path / "tok"
        subprocess.run(
            [sys.executable, str(TOKENIZE_SCRIPT),
             "--input", str(TINY_CORPUS),
             "--tokenizer", str(model_dir),
             "--output", str(cache),
             "--seq-len", "64",
             "--num-workers", "2"],
            check=True, capture_output=True, timeout=180,
        )
        return model_dir, cache

    def test_startup_banner_has_all_categories(self, tiny_run, tmp_path):
        model_dir, cache = tiny_run
        out = tmp_path / "run"
        r = subprocess.run(
            [sys.executable, str(TRAIN_SCRIPT),
             "--model-path", str(model_dir),
             "--tokenized-dir", str(cache),
             "--output-dir", str(out),
             "--max-steps", "1",
             "--batch-size", "1",
             "--grad-accum", "1",
             "--dtype", "fp32",
             "--device", "cpu",
             "--hellaswag-n", "0",
             "--arc-n", "0",
             "--log-every", "1",
             "--val-every", "99",
             "--save-every", "99",
             "--benchmark-every", "99",
             "--dataloader-workers", "0"],
            capture_output=True, text=True, timeout=300,
        )
        assert r.returncode == 0, f"{r.stdout}\n{r.stderr}"
        combined = r.stdout + r.stderr
        # Each category the user needs to reason about must appear once.
        for header in ("Shapes", "Schedule", "Optimizer",
                       "Logging / checkpoints", "Benchmark subsets"):
            assert header in combined, (
                f"startup banner missing '{header}' section. Full output:\n"
                f"{combined}"
            )
        # Critical knob values must be echoed
        for value in ("batch_size", "grad_accum", "seq_len",
                      "tokens/step", "target_tokens", "max_steps",
                      "warmup_steps", "lr", "weight_decay",
                      "log_every", "val_every", "save_every",
                      "hellaswag_n", "arc_n"):
            assert value in combined, f"banner missing knob '{value}'"

    def test_hellaswag_arc_zero_skips_download(self, tiny_run, tmp_path):
        """Passing --hellaswag-n 0 --arc-n 0 must NOT attempt to download
        benchmark data. This lets CI / offline runs avoid HF hub hits."""
        model_dir, cache = tiny_run
        out = tmp_path / "run2"
        # Redirect HF cache to a temp dir we control; if any download
        # happens, it would leave traces here.
        hf_cache = tmp_path / "hf_cache"
        env = os.environ.copy()
        env["HF_HUB_OFFLINE"] = "1"  # belt + braces
        env["TRANSFORMERS_OFFLINE"] = "1"
        env["HF_DATASETS_OFFLINE"] = "1"
        r = subprocess.run(
            [sys.executable, str(TRAIN_SCRIPT),
             "--model-path", str(model_dir),
             "--tokenized-dir", str(cache),
             "--output-dir", str(out),
             "--max-steps", "1",
             "--batch-size", "1",
             "--grad-accum", "1",
             "--dtype", "fp32",
             "--device", "cpu",
             "--hellaswag-n", "0",
             "--arc-n", "0",
             "--cache-dir", str(hf_cache),
             "--dataloader-workers", "0"],
            capture_output=True, text=True, timeout=300, env=env,
        )
        assert r.returncode == 0, (
            f"training with benchmarks disabled failed under offline mode:\n"
            f"stdout:\n{r.stdout}\nstderr:\n{r.stderr}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Functional: tokenize produces a valid binary cache
# ─────────────────────────────────────────────────────────────────────────────

class TestTokenizeFixture:
    @pytest.fixture
    def tiny_corpus(self):
        assert TINY_CORPUS.is_file(), (
            f"fixture missing: {TINY_CORPUS}. "
            "Add docs/fixtures/tiny_corpus_sample.jsonl (≥5 rows)."
        )
        return TINY_CORPUS

    def test_tokenize_emits_cache(self, tiny_corpus, tmp_path):
        pytest.importorskip("transformers")
        out = tmp_path / "tok_cache"
        r = subprocess.run(
            [sys.executable, str(TOKENIZE_SCRIPT),
             "--input", str(tiny_corpus),
             "--tokenizer", "gpt2",
             "--output", str(out),
             "--seq-len", "64",
             "--num-workers", "2"],
            capture_output=True, text=True, timeout=180,
        )
        assert r.returncode == 0, f"stdout:\n{r.stdout}\nstderr:\n{r.stderr}"

        tokens_bin = out / "tokens.bin"
        meta_json = out / "meta.json"
        assert tokens_bin.is_file(), f"missing {tokens_bin}"
        assert meta_json.is_file(), f"missing {meta_json}"

        with open(meta_json) as f:
            meta = json.load(f)
        assert meta["seq_len"] == 64
        assert meta["n_sequences"] >= 1
        # tokens.bin size = n_sequences × seq_len × 4 bytes (int32)
        expected_bytes = meta["n_sequences"] * meta["seq_len"] * 4
        assert tokens_bin.stat().st_size == expected_bytes
        # Meta must name the tokenizer so downstream code can verify
        assert "tokenizer_name" in meta
        assert "tokenizer_vocab_size" in meta


# ─────────────────────────────────────────────────────────────────────────────
# Smoke: full pipeline — compile → tokenize → train 2 steps (GPU or CPU)
# ─────────────────────────────────────────────────────────────────────────────

# (Previously `TestEndToEndSmoke` ran a single compile+train smoke on
# llama_like.yml. That coverage is now subsumed by `TestTrainerAcrossPresets
# [dense-attention]` below, which runs the same flow + 3 more architecture
# axes, all with the vocab-alignment override that real users must apply.)


# ─────────────────────────────────────────────────────────────────────────────
# Cross-architecture validation — the universal-trainer promise.
#
# The value proposition of examples/05_pretrain_train.py is that ONE command
# line trains ANY compiled EulerStack preset. Below we prove it by running
# compile → tokenize → 2-step train against four fixtures, each minimal but
# representative of a distinct architecture axis:
#
#     - dense attention      (llama_like.yml)       ← baseline
#     - MLA attention        (mla_attention.yml)    ← latent_dim compression
#     - Mamba + Attention    (hybrid_mixed.yml)     ← different mixer, mixed stack
#     - MoE FFN              (moe_model.yml)        ← sparse experts
#
# Using the fixture YAMLs (d_model 64-256) keeps the test CPU-fast and
# deterministic without depending on a free GPU. It also means the real
# configs/presets/ sizing choices don't gate this sanity check.
#
# Each case asserts: exit 0, final checkpoint exists, metrics.jsonl holds at
# least one TRAIN event. Gated on RUN_EXAMPLE_SMOKE=1 because it still takes
# ~1-2 s per case (compile + tokenize + 2 train steps on CPU).
# ─────────────────────────────────────────────────────────────────────────────

_CROSS_ARCH_FIXTURES = [
    ("dense-attention", "llama_like.yml"),
    ("mla-attention",   "mla_attention.yml"),
    ("hybrid-mixer",    "hybrid_mixed.yml"),
    ("moe-ffn",         "moe_model.yml"),
]


def _override_vocab(src: Path, dst: Path,
                    vocab_size: int = 50304,
                    tokenizer: str = "gpt2") -> None:
    """Copy a preset with `model.vocab_size` + `tokenizer_contract.pretrained`
    aligned.

    The shipped presets declare `vocab_size: 32000` (Llama-1/2 SentencePiece
    tradition) but `tokenizer_contract.pretrained: gpt2` (50257 vocab)
    for HF-out-of-the-box convenience. In real use these two are expected
    to be overridden together (see projects/moe_pretrain_study/README §2.1).
    For the test we lift the model vocab to 50304 (64-aligned, covers gpt2's
    50257) so compile + load + train can run end-to-end.
    """
    import yaml
    spec = yaml.safe_load(src.read_text())
    spec.setdefault("model", {})["vocab_size"] = int(vocab_size)
    spec.setdefault("tokenizer_contract", {})["pretrained"] = tokenizer
    dst.write_text(yaml.safe_dump(spec, sort_keys=False, allow_unicode=True))


@pytest.mark.skipif(
    os.environ.get("RUN_EXAMPLE_SMOKE") != "1",
    reason="set RUN_EXAMPLE_SMOKE=1 to run cross-architecture trainer smoke",
)
class TestTrainerAcrossPresets:
    """One trainer, many architectures — verified for real, not just on paper."""

    @pytest.mark.parametrize("tag,fixture_name", _CROSS_ARCH_FIXTURES,
                             ids=[t[0] for t in _CROSS_ARCH_FIXTURES])
    def test_compile_tokenize_train_2_steps(self, tag, fixture_name, tmp_path):
        pytest.importorskip("torch")
        pytest.importorskip("transformers")

        fixture_path = FIXTURE_DIR / "valid_yamls" / fixture_name
        assert fixture_path.is_file(), f"fixture missing: {fixture_path}"

        # 0. Align model vocab_size with the gpt2 tokenizer (50257).
        #    All fixtures ship with vocab_size=32000 or 128 paired with
        #    tokenizer_contract.pretrained=gpt2 — users are expected to
        #    reconcile at compile time. Test uses 50304 (64-aligned).
        overridden = tmp_path / f"override_{fixture_name}"
        _override_vocab(fixture_path, overridden, vocab_size=50304,
                        tokenizer="gpt2")

        # 1. Compile the overridden fixture into a fresh HF model directory.
        from click.testing import CliRunner
        from eulerstack.cli.main import cli

        model_dir = tmp_path / f"{tag}_model"
        runner = CliRunner()
        result = runner.invoke(cli, [
            "compile", "--preset", str(overridden),
            "--output-dir", str(model_dir),
        ])
        assert result.exit_code == 0, f"compile[{tag}] failed:\n{result.output}"
        assert (model_dir / "config.json").is_file()
        assert (model_dir / "tokenizer_config.json").is_file(), \
            "tokenizer must be saved at compile time (regression guard)"

        # 2. Tokenize the tiny corpus with the model's own tokenizer.
        cache_dir = tmp_path / "tok_cache"
        r = subprocess.run(
            [sys.executable, str(TOKENIZE_SCRIPT),
             "--input", str(TINY_CORPUS),
             "--tokenizer", str(model_dir),
             "--output", str(cache_dir),
             "--seq-len", "64",
             "--num-workers", "2"],
            capture_output=True, text=True, timeout=300,
        )
        assert r.returncode == 0, \
            f"tokenize[{tag}] failed:\nstdout:\n{r.stdout}\nstderr:\n{r.stderr}"

        # 3. Run 2 training steps. We force CPU so the test does not fight
        #    for VRAM with other GPU workloads and so bf16 (guarded by
        #    tests/test_environment.py against torch 2.10 + Blackwell) does
        #    not matter here. fp32 to match.
        run_dir = tmp_path / "run"
        r = subprocess.run(
            [sys.executable, str(TRAIN_SCRIPT),
             "--model-path", str(model_dir),
             "--tokenized-dir", str(cache_dir),
             "--output-dir", str(run_dir),
             "--max-steps", "2",
             "--batch-size", "1",
             "--grad-accum", "1",
             "--dtype", "fp32",
             "--device", "cpu",
             "--log-every", "1",
             "--val-every", "99",
             "--save-every", "99",
             "--benchmark-every", "99",
             "--dataloader-workers", "0"],
            capture_output=True, text=True, timeout=600,
        )
        assert r.returncode == 0, (
            f"train[{tag}] failed (exit {r.returncode}):\n"
            f"stdout:\n{r.stdout}\nstderr:\n{r.stderr}"
        )

        # 4. Artefacts landed and at least one TRAIN event was written.
        assert (run_dir / "final").is_dir(), \
            f"final checkpoint not created for {tag}"
        metrics_file = run_dir / "metrics.jsonl"
        assert metrics_file.is_file(), \
            f"metrics.jsonl missing for {tag}"
        events = [json.loads(line) for line in metrics_file.read_text().splitlines()
                  if line.strip()]
        train_events = [e for e in events if e.get("event") == "train"]
        assert len(train_events) >= 1, (
            f"no TRAIN events recorded for {tag}. All events: {events}"
        )
        # Loss must be finite (catches silent NaN / Inf in forward).
        first_loss = train_events[0].get("loss")
        assert first_loss is not None and math.isfinite(first_loss), (
            f"non-finite loss at first step for {tag}: {first_loss}"
        )


