# tests/test_ode_integrator_runtime.py
"""ODE integrator runtime (Phase B3.3, promoted from reserved → core).

Decision: `ode_euler` and `ode_rk4` are hand-rollable without external
dependencies (torchdiffeq etc.), and their semantics are well-defined.
They are promoted to v1 core. `ode_adaptive` stays reserved because
adaptive step-size control needs a dedicated library.

Core semantics:
- body: a Module whose forward(x) returns dx/dt (same shape as x).
- The integrator applies K Euler/RK4 steps with step size ``dt = 1 / K``.
- Shared weights across steps.
"""
from __future__ import annotations

import pytest
import torch
import torch.nn as nn


class TestODEIntegratorModule:
    """Unit tests on the stand-alone component."""

    def test_module_imports(self):
        from eulerstack.components.integrator import ODEIntegrator  # noqa: F401

    def test_euler_forward_shape(self):
        from eulerstack.components.integrator import ODEIntegrator

        body = nn.Linear(16, 16)
        odeint = ODEIntegrator(body, steps=4, method="euler")
        x = torch.randn(2, 8, 16)
        y = odeint(x)
        assert y.shape == x.shape

    def test_rk4_forward_shape(self):
        from eulerstack.components.integrator import ODEIntegrator

        body = nn.Linear(16, 16)
        odeint = ODEIntegrator(body, steps=4, method="rk4")
        x = torch.randn(2, 8, 16)
        y = odeint(x)
        assert y.shape == x.shape

    def test_backward_runs(self):
        from eulerstack.components.integrator import ODEIntegrator

        body = nn.Linear(16, 16)
        odeint = ODEIntegrator(body, steps=2, method="rk4")
        x = torch.randn(2, 8, 16, requires_grad=True)
        y = odeint(x)
        y.sum().backward()
        assert body.weight.grad is not None
        assert body.weight.grad.abs().sum() > 0

    def test_euler_matches_hand_computation(self):
        """Euler step: y = x + dt * body(x). Verify at K=1."""
        from eulerstack.components.integrator import ODEIntegrator

        torch.manual_seed(0)
        body = nn.Linear(8, 8, bias=False)
        odeint = ODEIntegrator(body, steps=1, method="euler")
        x = torch.randn(1, 4, 8)
        y = odeint(x)
        # One Euler step with dt=1/1=1: y = x + body(x)
        expected = x + body(x)
        assert torch.allclose(y, expected, atol=1e-5)

    def test_rk4_zero_body_is_identity(self):
        """If body outputs 0, RK4 reduces to identity."""
        from eulerstack.components.integrator import ODEIntegrator

        class Zero(nn.Module):
            def forward(self, x):
                return torch.zeros_like(x)

        odeint = ODEIntegrator(Zero(), steps=4, method="rk4")
        x = torch.randn(1, 4, 8)
        y = odeint(x)
        assert torch.allclose(y, x)

    def test_rejects_bad_method(self):
        from eulerstack.components.integrator import ODEIntegrator

        with pytest.raises(ValueError, match="method"):
            ODEIntegrator(nn.Linear(8, 8), steps=2, method="unknown")

    def test_rejects_zero_steps(self):
        from eulerstack.components.integrator import ODEIntegrator

        with pytest.raises(ValueError, match="steps"):
            ODEIntegrator(nn.Linear(8, 8), steps=0, method="rk4")


class TestSchemaAcceptsODEVariants:
    """Schema: ode_rk4 / ode_euler must now be accepted (promoted from reserved)."""

    def _make_spec(self, integrator_type: str):
        return {
            "schema_version": 1,
            "model": {
                "name": "ode-demo",
                "d_model": 64,
                "vocab_size": 256,
                "max_seq_len": 128,
                "n_heads": 4,
            },
            "tokenizer_contract": {"type": "hf", "pretrained": "gpt2"},
            "embedding": {"type": "learned", "positional": "rope",
                          "rope_theta": 10000.0},
            "layer_templates": {
                "refine": {
                    "mixer": {"type": "attention", "attention": {}},
                    "ffn": {"type": "gated_mlp"},
                }
            },
            "layer_schedule": [
                {"integrator": {"type": integrator_type, "steps": 2,
                                 "body": "refine", "output": "token"}}
            ],
            "head": {"type": "causal_lm"},
        }

    def test_ode_rk4_accepted(self):
        from eulerstack.spec.schema import parse_v2_yaml

        spec = self._make_spec("ode_rk4")
        result = parse_v2_yaml(spec)  # should not raise
        assert result is not None

    def test_ode_euler_accepted(self):
        from eulerstack.spec.schema import parse_v2_yaml

        spec = self._make_spec("ode_euler")
        result = parse_v2_yaml(spec)
        assert result is not None

    def test_ode_adaptive_still_reserved(self):
        """ode_adaptive still requires a plugin — must still be rejected by v1 core."""
        from eulerstack.spec.schema import parse_v2_yaml
        from eulerstack.spec.errors import ValidationError

        spec = self._make_spec("ode_adaptive")
        with pytest.raises(ValidationError, match="reserved"):
            parse_v2_yaml(spec)


class TestODEIntegratorEndToEnd:
    """IR → HF model → forward: ODE integrator flattens into K layers and runs."""

    def _build_model(self, integrator_type: str):
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model

        raw = {
            "schema_version": 1,
            "model": {
                "name": f"ode-{integrator_type}",
                "d_model": 64,
                "vocab_size": 256,
                "max_seq_len": 64,
                "n_heads": 4,
            },
            "tokenizer_contract": {"type": "hf", "pretrained": "gpt2"},
            "embedding": {"type": "learned", "positional": "rope",
                          "rope_theta": 10000.0},
            "layer_templates": {
                "refine": {
                    "mixer": {"type": "attention", "attention": {}},
                    "ffn": {"type": "gated_mlp"},
                }
            },
            "layer_schedule": [
                {"integrator": {"type": integrator_type, "steps": 2,
                                 "body": "refine", "output": "token"}}
            ],
            "head": {"type": "causal_lm"},
        }
        ir = normalize_to_ir(raw)
        return compile_to_hf_model(ir, seed=0)

    def test_ode_rk4_model_forward(self):
        model = self._build_model("ode_rk4")
        ids = torch.randint(0, 256, (1, 8))
        out = model(ids)
        assert out.logits.shape == (1, 8, 256)

    def test_ode_euler_model_forward(self):
        model = self._build_model("ode_euler")
        ids = torch.randint(0, 256, (1, 8))
        out = model(ids)
        assert out.logits.shape == (1, 8, 256)

    def test_ode_rk4_training_decreases_loss(self):
        """A single overfitting batch must see loss go down."""
        model = self._build_model("ode_rk4")
        opt = torch.optim.AdamW(model.parameters(), lr=3e-3)
        torch.manual_seed(0)
        ids = torch.randint(0, 256, (2, 16))
        labels = ids.clone()
        initial = None
        final = None
        model.train()
        for step in range(30):
            out = model(input_ids=ids, labels=labels)
            loss = out.loss
            if step == 0:
                initial = float(loss.item())
            opt.zero_grad()
            loss.backward()
            opt.step()
            final = float(loss.item())
        assert final is not None and initial is not None
        assert final < initial, f"loss did not decrease: {initial} -> {final}"


class TestODEIntegratorSharedWeights:
    """Neural-ODE semantics: one body module applied K numerical steps.

    Contrast with `discrete` integrator which flattens into K distinct
    layer copies (Diffusion-LM-style, independent weights).
    """

    def _build(self, integrator_type: str, steps: int):
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model

        raw = {
            "schema_version": 1,
            "model": {
                "name": "ode-shared",
                "d_model": 32,
                "vocab_size": 128,
                "max_seq_len": 32,
                "n_heads": 4,
            },
            "tokenizer_contract": {"type": "hf", "pretrained": "gpt2"},
            "embedding": {"type": "learned", "positional": "rope",
                          "rope_theta": 10000.0},
            "layer_templates": {
                "refine": {
                    "mixer": {"type": "attention", "attention": {}},
                    "ffn": {"type": "gated_mlp"},
                }
            },
            "layer_schedule": [
                {"integrator": {"type": integrator_type, "steps": steps,
                                 "body": "refine", "output": "token"}}
            ],
            "head": {"type": "causal_lm"},
        }
        ir = normalize_to_ir(raw)
        return ir, compile_to_hf_model(ir, seed=0)

    def test_ode_expands_to_one_layer_in_ir(self):
        """ODE expansion → 1 shared layer (not K copies)."""
        ir, _ = self._build("ode_rk4", steps=4)
        assert len(ir.expanded_layers) == 1

    def test_discrete_still_expands_to_k_layers(self):
        """Regression guard: discrete must keep K-copy semantics."""
        ir, _ = self._build("discrete", steps=4)
        assert len(ir.expanded_layers) == 4

    def test_model_layer_declares_ode_integrator(self):
        """Layers must carry ODE metadata so _forward_ode fires at runtime.

        Rather than require an ODEIntegrator Module instance (which would
        create a circular submodule reference since the "body" is the layer
        itself), core records the method/steps on the layer and routes
        forward() through _forward_ode. This test locks that contract.
        """
        _, model = self._build("ode_rk4", steps=4)
        found = False
        for m in model.modules():
            if hasattr(m, "_ode_method") and m._ode_method == "rk4" \
                    and hasattr(m, "_ode_steps") and m._ode_steps == 4:
                found = True
                break
        assert found, "No layer declared ODE rk4 metadata"

    def test_ode_param_count_is_one_bodys_worth(self):
        """Shared weights: K=4 ODE has same params as K=1 (up to overhead)."""
        _, model_k4 = self._build("ode_rk4", steps=4)
        _, model_k1 = self._build("ode_rk4", steps=1)
        p4 = sum(p.numel() for p in model_k4.parameters())
        p1 = sum(p.numel() for p in model_k1.parameters())
        # Shared across K → params don't scale with K.
        assert p4 == p1, (
            f"Shared-weight ODE: K=4 and K=1 must have identical params "
            f"(got {p4} vs {p1})"
        )
    """save_pretrained → from_pretrained must preserve ODE integrator metadata."""

    def test_save_load_preserves_integrator_type(self, tmp_path):
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model
        from eulerstack.hf.auto_register import register_eulerstack_auto_classes
        from transformers import AutoModelForCausalLM

        register_eulerstack_auto_classes()
        raw = {
            "schema_version": 1,
            "model": {
                "name": "ode-rt",
                "d_model": 32,
                "vocab_size": 256,
                "max_seq_len": 64,
                "n_heads": 4,
            },
            "tokenizer_contract": {"type": "hf", "pretrained": "gpt2"},
            "embedding": {"type": "learned", "positional": "rope",
                          "rope_theta": 10000.0},
            "layer_templates": {
                "refine": {
                    "mixer": {"type": "attention", "attention": {}},
                    "ffn": {"type": "gated_mlp"},
                }
            },
            "layer_schedule": [
                {"integrator": {"type": "ode_rk4", "steps": 2,
                                 "body": "refine", "output": "token"}}
            ],
            "head": {"type": "causal_lm"},
        }
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=0)
        out = str(tmp_path / "ode_model")
        model.save_pretrained(out)
        loaded = AutoModelForCausalLM.from_pretrained(out, trust_remote_code=True)

        # round-tripped config should reflect `ode_rk4` in v1_extensions
        ext = getattr(loaded.config, "v1_extensions", {}) or {}
        kinds = ext.get("schedule_kinds") or []
        found = any(k.get("integrator_type") == "ode_rk4" for k in kinds)
        assert found, f"ode_rk4 not preserved in v1_extensions: {kinds}"

        # forward still runs
        ids = torch.randint(0, 256, (1, 8))
        loaded.eval()
        with torch.no_grad():
            out_logits = loaded(ids).logits
        assert out_logits.shape == (1, 8, 256)
