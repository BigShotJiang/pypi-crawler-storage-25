# tests/test_mla_runtime.py
"""Tier-3 runtime tests for MLA latent attention (Phase B2.1).

Verifies that `CausalSelfAttention(latent_dim=...)` produces a working,
backward-pass-compatible compressed-KV attention as documented in
DeepSeek-V2/V3 and the v1 spec §12.3.
"""
from __future__ import annotations

import pytest
import torch

from eulerstack.blocks.attention import CausalSelfAttention


class TestMLAAttention:
    """MLA (latent_dim) must forward cleanly and have the expected param count."""

    def test_mla_forward_shape(self):
        attn = CausalSelfAttention(d_model=64, n_heads=4, latent_dim=32, rope=False)
        x = torch.randn(2, 8, 64)
        out, past = attn(x)
        assert out.shape == (2, 8, 64)
        assert past is None  # use_cache default False

    def test_mla_vs_standard_param_reduction(self):
        """MLA with latent_dim < d_model reduces attention param count."""
        std = CausalSelfAttention(d_model=128, n_heads=8, rope=False)
        mla = CausalSelfAttention(d_model=128, n_heads=8, latent_dim=32, rope=False)
        std_params = sum(p.numel() for p in std.parameters())
        mla_params = sum(p.numel() for p in mla.parameters())
        # Standard = 3*d^2 (QKV) + d^2 (out proj) + biases ≈ 4 d^2
        # MLA = d^2 (Q) + d*l (latent down) + 2*l*d (up K+V) + d^2 (out) ≈ 2 d^2 + 3 d l
        # For d=128, l=32: std ≈ 4*16384 = 65536; mla ≈ 2*16384 + 3*128*32 = 32768 + 12288 = 45056
        assert mla_params < std_params

    def test_mla_backward_pass_runs(self):
        attn = CausalSelfAttention(d_model=64, n_heads=4, latent_dim=16, rope=False)
        x = torch.randn(2, 4, 64, requires_grad=True)
        out, _ = attn(x)
        loss = out.sum()
        loss.backward()
        # All MLA sub-projections must receive a gradient.
        assert attn.q_proj.weight.grad is not None
        assert attn.kv_latent.weight.grad is not None
        assert attn.k_up.weight.grad is not None
        assert attn.v_up.weight.grad is not None
        assert attn.proj.weight.grad is not None

    def test_mla_rejects_bad_latent_dim(self):
        with pytest.raises(ValueError, match="latent_dim"):
            CausalSelfAttention(d_model=64, n_heads=4, latent_dim=0)
        with pytest.raises(ValueError, match="latent_dim"):
            CausalSelfAttention(d_model=64, n_heads=4, latent_dim=64)   # == d_model
        with pytest.raises(ValueError, match="latent_dim"):
            CausalSelfAttention(d_model=64, n_heads=4, latent_dim=200)  # > d_model

    def test_standard_path_unaffected(self):
        """latent_dim=None must keep the exact pre-existing fused-QKV path."""
        attn = CausalSelfAttention(d_model=64, n_heads=4, latent_dim=None)
        # The standard module path registers `qkv`, not the MLA projections.
        assert hasattr(attn, "qkv")
        assert not hasattr(attn, "q_proj")

    def test_mla_kv_cache_round_trip(self):
        """KV cache must still work when MLA is active."""
        attn = CausalSelfAttention(d_model=64, n_heads=4, latent_dim=16, rope=False)
        attn.eval()
        x = torch.randn(1, 4, 64)
        out, past = attn(x, use_cache=True)
        assert past is not None
        pk, pv = past
        # Cached K/V still have head_dim structure (MLA up-projects before cache).
        assert pk.shape == (1, 4, 4, 16)  # (B, H, S, head_dim)
        assert pv.shape == (1, 4, 4, 16)


class TestMLAFromPresetRoundtrip:
    """End-to-end: arch_advanced_mla preset must produce a functional MLA model."""

    def test_mla_preset_forward_consistent(self, tmp_path):
        """Tiny-size MLA preset: save → load → deterministic forward."""
        import os
        import yaml
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model
        from eulerstack.hf.auto_register import register_eulerstack_auto_classes
        from transformers import AutoModelForCausalLM

        register_eulerstack_auto_classes()
        preset_path = os.path.join(
            os.path.dirname(__file__), "..", "configs", "presets", "arch_advanced_mla.yml"
        )
        with open(preset_path) as f:
            raw = yaml.safe_load(f)
        # Shrink for unit-test scale.
        raw["model"]["d_model"] = 64
        raw["model"]["n_heads"] = 4
        raw["model"]["n_kv_heads"] = 2
        raw["model"]["vocab_size"] = 512
        raw["model"]["max_seq_len"] = 128
        raw["layer_templates"]["mla_decoder"]["mixer"]["attention"]["latent_dim"] = 32
        raw["layer_schedule"][0]["repeat"] = 2

        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=42)

        out_dir = str(tmp_path / "mla_runtime")
        model.save_pretrained(out_dir)

        loaded = AutoModelForCausalLM.from_pretrained(out_dir, trust_remote_code=True)

        # Both models share the seed → forward outputs should be identical.
        ids = torch.randint(0, raw["model"]["vocab_size"], (1, 8))
        model.eval()
        loaded.eval()
        with torch.no_grad():
            out1 = model(ids).logits
            out2 = loaded(ids).logits
        assert torch.allclose(out1, out2, atol=1e-6)

    def test_mla_layers_have_latent_projections(self):
        """The compiled model must instantiate MLA (latent-dim) attention layers."""
        import os
        import yaml
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model

        preset_path = os.path.join(
            os.path.dirname(__file__), "..", "configs", "presets", "arch_advanced_mla.yml"
        )
        with open(preset_path) as f:
            raw = yaml.safe_load(f)
        raw["model"]["d_model"] = 64
        raw["model"]["n_heads"] = 4
        raw["model"]["n_kv_heads"] = 2
        raw["model"]["vocab_size"] = 256
        raw["model"]["max_seq_len"] = 128
        raw["layer_templates"]["mla_decoder"]["mixer"]["attention"]["latent_dim"] = 16
        raw["layer_schedule"][0]["repeat"] = 2

        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=42)

        # Walk model and confirm at least one attention block has the MLA
        # kv_latent projection rather than the fused qkv.
        found_mla = False
        for m in model.modules():
            if isinstance(m, CausalSelfAttention) and m.latent_dim is not None:
                found_mla = True
                assert hasattr(m, "kv_latent")
                assert m.kv_latent.out_features == m.latent_dim
        assert found_mla, "No MLA attention layer instantiated from arch_advanced_mla preset"
