# tests/test_presets.py
"""Preset validation, compile, and CLI tests."""
from __future__ import annotations

import os
import glob
import pytest
import yaml
from click.testing import CliRunner

from eulerstack.spec.validate import validate_v2
from eulerstack.ir.normalizer import normalize_to_ir
from eulerstack.compiler.compile import compile_ir
from eulerstack.spec.param_estimator import estimate_params
from eulerstack.spec.report import generate_report
from eulerstack.cli.main import cli


PRESETS_DIR = os.path.join(os.path.dirname(__file__), "..", "configs", "presets")
PRESET_FILES = sorted(glob.glob(os.path.join(PRESETS_DIR, "*.yml")))
PRESET_NAMES = [os.path.splitext(os.path.basename(f))[0] for f in PRESET_FILES]


def _load(path: str) -> dict:
    """Load a preset YAML and apply the B1.2 `let:` / `${…}` pre-pass so
    downstream numeric checks see resolved integers rather than string
    templates.
    """
    from eulerstack.spec.expressions import resolve_expressions
    with open(path, "r") as f:
        raw = yaml.safe_load(f)
    return resolve_expressions(raw)


# ── All presets must exist ──

class TestPresetsExist:
    def test_all_presets_exist(self):
        # v1 preset catalogue:
        # 20 arch_* (beginner×2, intermediate×3, advanced×5, expert×10) [was 17]
        #    advanced gained mla + mod (Phase B primitives at arch-scale).
        #    expert gained reasoning_r1 + titans_memory + dual_stream.
        # + 6 arch_expert_*_mini (small-scale speculative-expert variants)
        # + 24 llm_ (0.1B×4 stage-1/CPT, 0.8B/2B/4B/16B × 5 variants)
        # = 50 presets minimum
        assert len(PRESET_FILES) >= 50

    @pytest.mark.parametrize("name", [
        # ── llm_ 0.1B (Stage-1 / CPT warm-up) — 4 variants, MoE skipped ──
        "llm_0p1b_simple", "llm_0p1b_mistral", "llm_0p1b_jamba", "llm_0p1b_mla",
        # ── llm_ : 4 production sizes × 5 architectural variants ──
        "llm_0p8b_simple", "llm_0p8b_mistral", "llm_0p8b_jamba", "llm_0p8b_moe", "llm_0p8b_mla",
        "llm_2b_simple",   "llm_2b_mistral",   "llm_2b_jamba",   "llm_2b_moe",   "llm_2b_mla",
        "llm_4b_simple",   "llm_4b_mistral",   "llm_4b_jamba",   "llm_4b_moe",   "llm_4b_mla",
        "llm_16b_simple",  "llm_16b_mistral",  "llm_16b_jamba",  "llm_16b_moe",  "llm_16b_mla",
        # ── arch_ : skill-level walkthrough, multiple variants per level ──
        # beginner (2)
        "arch_beginner_gpt2",
        "arch_beginner_llama",
        # intermediate (3)
        "arch_intermediate_mistral",
        "arch_intermediate_gemma2",
        "arch_intermediate_qwen_longctx",
        # advanced (5) — was 3; Phase B added mla + mod at arch-scale
        "arch_advanced_jamba",
        "arch_advanced_samba",
        "arch_advanced_retnet",
        "arch_advanced_mla",
        "arch_advanced_mod",
        # expert (12) — was 9; Phase B added reasoning_r1 + titans_memory + dual_stream
        "arch_expert_research",
        "arch_expert_mixtral_moe",
        "arch_expert_striped_hyena",
        "arch_expert_blackmamba_moe",
        "arch_expert_deepseek_moe",
        "arch_expert_retnet_moe",
        "arch_expert_frontier_full_moe",
        "arch_expert_progressive_stack",
        "arch_expert_dilated_longnet",
        "arch_expert_reasoning_r1",
        "arch_expert_titans_memory",
        "arch_expert_dual_stream",
        # expert mini (6) — small-scale (~120M–160M) variants of the six speculative experts
        # for cheap experimentation on expert-level architectural ideas.
        "arch_expert_progressive_stack_mini",
        "arch_expert_blackmamba_moe_mini",
        "arch_expert_mixtral_moe_mini",
        "arch_expert_dilated_longnet_mini",
        "arch_expert_deepseek_moe_mini",
        "arch_expert_frontier_full_moe_mini",
    ])
    def test_expected_preset_exists(self, name):
        path = os.path.join(PRESETS_DIR, f"{name}.yml")
        assert os.path.exists(path), f"Missing preset: {name}"

    def test_no_v1_prefix_presets(self):
        """Phase-B primitive demos were renamed to arch_advanced_/arch_expert_.
        The temporary `v1_*` prefix must be gone.
        """
        leftover = [p for p in PRESET_FILES if os.path.basename(p).startswith("v1_")]
        assert not leftover, f"Legacy v1_* presets still present: {leftover}"

    def test_no_legacy_configs_model_dir(self):
        """configs/model (v1 legacy) must be fully removed."""
        legacy = os.path.join(PRESETS_DIR, "..", "model")
        assert not os.path.isdir(legacy), "configs/model still exists — remove v1 legacy configs"

    def test_no_legacy_preset_names(self):
        """Old preset names (arch_stage*, llm_Xb_hybrid/complex, 8B/32B) must be gone."""
        legacy_prefixes = ("arch_stage", "llm_8b_", "llm_32b_")
        legacy_suffixes = ("_hybrid.yml", "_complex.yml")
        for f in PRESET_FILES:
            name = os.path.basename(f)
            for pref in legacy_prefixes:
                assert not name.startswith(pref), f"Legacy preset still present: {name}"
            for suf in legacy_suffixes:
                assert not name.endswith(suf), f"Legacy preset still present: {name}"


# ── All presets validate ──

class TestPresetsValidate:
    @pytest.mark.parametrize("path", PRESET_FILES, ids=PRESET_NAMES)
    def test_preset_validates(self, path):
        raw = _load(path)
        validate_v2(raw)  # should not raise


# ── All presets compile ──

class TestPresetsCompile:
    @pytest.mark.parametrize("path", PRESET_FILES, ids=PRESET_NAMES)
    def test_preset_compiles(self, path):
        raw = _load(path)
        ir = normalize_to_ir(raw)
        result = compile_ir(ir)
        assert "config" in result
        assert result["config"]["n_layers"] > 0


# ── RoPE compatibility: head_dim must be even ──

class TestPresetsRopeHeadDim:
    """Regression guard for RoPE compatibility.

    The MoE presets were shipped with d_model / n_heads = 83 (odd) because
    d_model was chosen to hit target_params without checking RoPE's even-
    head_dim requirement. At runtime this triggers
    `ValueError: RoPE head_dim must be even.` inside components/positional.py.

    Any preset that uses `positional: rope` (default for all llm_ / arch_
    presets) must have an even head_dim.
    """
    @pytest.mark.parametrize("path", PRESET_FILES, ids=PRESET_NAMES)
    def test_head_dim_even_when_rope_used(self, path):
        raw = _load(path)
        pos_type = (raw.get("embedding") or {}).get("positional", "rope")
        if pos_type != "rope":
            return  # not using RoPE; no constraint
        d_model = raw["model"]["d_model"]
        n_heads = raw["model"]["n_heads"]
        assert d_model % n_heads == 0, \
            f"{path}: d_model ({d_model}) not divisible by n_heads ({n_heads})"
        head_dim = d_model // n_heads
        assert head_dim % 2 == 0, (
            f"{path}: head_dim={head_dim} is odd; RoPE requires even. "
            f"Adjust d_model or n_heads so (d_model / n_heads) is even."
        )


# ── Param estimation within 30% of target ──

class TestPresetsParamEstimate:
    @pytest.mark.parametrize("path", PRESET_FILES, ids=PRESET_NAMES)
    def test_param_estimate_within_range(self, path):
        raw = _load(path)
        ir = normalize_to_ir(raw)
        est = estimate_params(ir)
        target = ir.model.target_params
        if target is not None and target > 0:
            ratio = est / target
            assert 0.5 < ratio < 1.5, f"Param estimate {est} is {ratio:.1%} of target {target}"


# ── Report generation for presets ──

class TestPresetsReport:
    @pytest.mark.parametrize("path", PRESET_FILES, ids=PRESET_NAMES)
    def test_preset_report_no_errors(self, path):
        raw = _load(path)
        report = generate_report(raw)
        assert report.schema_ok
        assert not report.has_errors, f"Report errors: {[e.message for e in report.errors]}"


# ── CLI tests ──

class TestPresetsCLI:
    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_presets_list(self, runner):
        result = runner.invoke(cli, ["presets", "list"])
        assert result.exit_code == 0
        assert "llm_0p8b_simple" in result.output

    def test_presets_show(self, runner):
        result = runner.invoke(cli, ["--lang", "en", "presets", "show", "llm_0p8b_simple"])
        assert result.exit_code == 0
        assert "eulerstack-0.8b-simple" in result.output
        assert "Estimated params" in result.output

    def test_presets_show_missing(self, runner):
        result = runner.invoke(cli, ["presets", "show", "nonexistent"])
        assert result.exit_code != 0

    def test_validate_report_flag(self, runner):
        path = os.path.join(PRESETS_DIR, "llm_0p8b_simple.yml")
        result = runner.invoke(cli, ["--lang", "en", "validate", "--preset", path, "--report"])
        assert result.exit_code == 0
        # Report body is now fully i18n'd — pin language to en for stability.
        assert "EulerStack Validation Report" in result.output

    def test_explain_shows_params(self, runner):
        path = os.path.join(PRESETS_DIR, "llm_2b_simple.yml")
        result = runner.invoke(cli, ["--lang", "en", "explain", "--preset", path])
        assert result.exit_code == 0
        assert "Estimated params" in result.output


# ── Preset directory resolution (wheel-install & workspace scenarios) ──

class TestPresetDirResolution:
    """`_presets_dir()` must find presets in wheel-install / workspace setups,
    not just when running from the source checkout.

    Resolution order:
      1. `EULERSTACK_PRESETS_DIR` environment variable
      2. `$cwd/configs/presets`
      3. package-relative `{package}/../../configs/presets` (dev fallback)
    """

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @pytest.fixture
    def fake_presets(self, tmp_path):
        """Create a workspace-style `configs/presets/` with a UNIQUELY NAMED
        preset so we can prove the lookup used our fake dir (not the dev-tree
        fallback, which also has `arch_beginner_llama.yml`)."""
        src = os.path.join(PRESETS_DIR, "arch_beginner_llama.yml")
        dst_dir = tmp_path / "configs" / "presets"
        dst_dir.mkdir(parents=True)
        import shutil
        # Unique name that does NOT exist in dev-tree — forces the resolver
        # to prove it opened the file from our fake dir.
        shutil.copy2(src, dst_dir / "zz_smoke_unique_preset.yml")
        return tmp_path

    def test_env_var_takes_priority(self, runner, fake_presets, monkeypatch):
        presets_dir = str(fake_presets / "configs" / "presets")
        monkeypatch.setenv("EULERSTACK_PRESETS_DIR", presets_dir)
        monkeypatch.chdir("/tmp")  # not where configs/presets is
        result = runner.invoke(cli, ["--lang", "en", "presets", "show",
                                     "zz_smoke_unique_preset"])
        assert result.exit_code == 0, result.output
        assert "zz_smoke_unique_preset" in result.output

    def test_cwd_configs_presets_discovered(self, runner, fake_presets,
                                             monkeypatch):
        monkeypatch.delenv("EULERSTACK_PRESETS_DIR", raising=False)
        monkeypatch.chdir(fake_presets)
        result = runner.invoke(cli, ["--lang", "en", "presets", "show",
                                     "zz_smoke_unique_preset"])
        assert result.exit_code == 0, result.output
        assert "zz_smoke_unique_preset" in result.output

    def test_presets_list_finds_cwd_configs(self, runner, fake_presets,
                                             monkeypatch):
        monkeypatch.delenv("EULERSTACK_PRESETS_DIR", raising=False)
        monkeypatch.chdir(fake_presets)
        result = runner.invoke(cli, ["--lang", "en", "presets", "list"])
        assert result.exit_code == 0, result.output
        assert "zz_smoke_unique_preset" in result.output

    def test_missing_preset_dir_exits_nonzero(self, runner, tmp_path,
                                               monkeypatch):
        """When NO preset directory can be found anywhere, the CLI must fail
        loudly with a 3-line error — not silently exit 0."""
        monkeypatch.delenv("EULERSTACK_PRESETS_DIR", raising=False)
        monkeypatch.chdir(tmp_path)  # empty workspace
        # Also make the package-relative fallback miss by pointing env var to
        # a nonexistent directory — that path is still tried first, but when
        # it doesn't exist we fall through to package-relative. To isolate,
        # we assert the list command no longer silently returns exit 0 in
        # the "nothing found anywhere" branch. We test this by mocking
        # _presets_dir to return None.
        from eulerstack.cli import presets_cmd
        monkeypatch.setattr(presets_cmd, "_presets_dir", lambda: None)
        result = runner.invoke(cli, ["--lang", "en", "presets", "list"])
        assert result.exit_code != 0, \
            f"expected loud failure, got exit 0 with output: {result.output}"
        assert "Fix:" in result.output
        assert "See:" in result.output

    def test_show_missing_dir_error_is_specific(self, runner, monkeypatch):
        """When the preset dir is missing, `presets show` must report the
        directory problem, not a misleading 'preset not found'."""
        from eulerstack.cli import presets_cmd
        monkeypatch.setattr(presets_cmd, "_presets_dir", lambda: None)
        result = runner.invoke(cli, ["--lang", "en", "presets", "show", "foo"])
        assert result.exit_code != 0
        # Must mention directory, not just "preset not found"
        assert "director" in result.output.lower() \
            or "EULERSTACK_PRESETS_DIR" in result.output
