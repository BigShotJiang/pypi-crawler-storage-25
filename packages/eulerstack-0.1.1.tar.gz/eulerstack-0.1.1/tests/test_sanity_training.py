# tests/test_sanity_training.py
"""Sanity training unit and integration tests."""
from __future__ import annotations

import pytest
import torch

from eulerstack.data.prepare import TokenizedDataset
from eulerstack.training.sanity import build_sanity_model, run_sanity_training, SanityTrainResult


class TestBuildSanityModel:
    def test_model_builds(self):
        model = build_sanity_model(
            vocab_size=256, d_model=64, n_heads=4, n_layers=2, max_seq_len=128,
        )
        assert model is not None

    def test_model_forward(self):
        model = build_sanity_model(
            vocab_size=256, d_model=64, n_heads=4, n_layers=2, max_seq_len=128,
        )
        ids = torch.randint(0, 256, (2, 32))
        logits = model(ids)
        assert logits.shape == (2, 32, 256)


class TestSanityTraining:
    def _make_dataset(self, num_samples=64, seq_len=32, vocab_size=256):
        ids = torch.randint(0, vocab_size, (num_samples, seq_len))
        return TokenizedDataset(ids)

    def test_loss_decreases_on_repeated_data(self):
        """Key test: training on repeated data should decrease loss."""
        vocab_size = 256
        model = build_sanity_model(
            vocab_size=vocab_size, d_model=64, n_heads=4, n_layers=2, max_seq_len=64,
        )
        # Create small dataset with some pattern (repeated data)
        pattern = torch.arange(0, 32).unsqueeze(0).repeat(128, 1)
        ds = TokenizedDataset(pattern)

        result = run_sanity_training(
            model, ds, batch_size=16, lr=1e-3, max_steps=50, seed=42,
        )
        assert result.steps > 0
        assert result.loss_decreased, f"Loss did not decrease: {result.initial_loss:.4f} → {result.final_loss:.4f}"

    def test_returns_sanity_result(self):
        model = build_sanity_model(
            vocab_size=256, d_model=64, n_heads=4, n_layers=2, max_seq_len=64,
        )
        ds = self._make_dataset(num_samples=64, seq_len=32)
        result = run_sanity_training(model, ds, batch_size=8, max_steps=5, seed=42)
        assert isinstance(result, SanityTrainResult)
        assert result.steps == 5
        assert len(result.losses) == 5

    def test_summary_output(self):
        model = build_sanity_model(
            vocab_size=256, d_model=64, n_heads=4, n_layers=2, max_seq_len=64,
        )
        ds = self._make_dataset()
        result = run_sanity_training(model, ds, batch_size=8, max_steps=5, seed=42)
        summary = result.summary()
        assert "Sanity training" in summary
        assert "Steps" in summary


class TestSanityTrainingIntegration:
    """Integration test: build from IR → train → loss decreases."""

    def test_ir_to_sanity_train(self):
        """Use an IR-like config to build a sanity model and verify training works."""
        import yaml, os
        from eulerstack.ir.normalizer import normalize_to_ir

        # Use llama_like fixture as basis
        fixture_path = os.path.join(os.path.dirname(__file__), "..", "docs", "fixtures", "valid_yamls", "llama_like.yml")
        with open(fixture_path) as f:
            raw = yaml.safe_load(f)

        ir = normalize_to_ir(raw)

        # Build sanity model using IR params (but much smaller for speed)
        # This is the "sanity variant" pattern: same topology, tiny scale
        model = build_sanity_model(
            vocab_size=256,  # tiny vocab for speed
            d_model=64,      # tiny d_model
            n_heads=4,
            n_layers=len(ir.expanded_layers),
            max_seq_len=64,
        )

        # Train on pattern data
        pattern = torch.arange(0, 32).unsqueeze(0).repeat(128, 1)
        ds = TokenizedDataset(pattern)
        result = run_sanity_training(model, ds, batch_size=16, lr=1e-3, max_steps=50, seed=42)

        assert result.loss_decreased, f"Loss did not decrease: {result.summary()}"
