# tests/test_smoke_blocks.py
import torch

from eulerstack.hf.configuration_eulerstack import EulerStackConfig
from eulerstack.hf.modeling_eulerstack import EulerStackForCausalLM


# -------------------------
# Config builders
# -------------------------
def build_tiny_moe_mamba_config() -> EulerStackConfig:
    cfg = EulerStackConfig(
        vocab_size=100,
        d_model=32,
        n_heads=4,
        n_layers=2,
        max_seq_len=64,
        dropout=0.0,
        mlp_ratio=4,
        use_cache=False,
        norm="rmsnorm",
    )

    cfg.routing = {
        "moe": {
            "experts": 4,
            "top_k": 2,
            "router_type": "softmax",
            "z_loss": 1.0,
        }
    }

    cfg.blocks = {
        "mamba": {
            "variant": "mamba2",
            "d_state": 16,
            "d_conv": 4,
            "expand": 2,
            "use_moe": True,
        }
    }

    cfg.stack = {
        "pattern": [{"block": "mamba", "repeat": 2}],
        "repeat": 1,
        "tail": [],
    }
    return cfg


def build_tiny_retnet_config() -> EulerStackConfig:
    cfg = EulerStackConfig(
        vocab_size=100,
        d_model=32,
        n_heads=4,
        n_layers=2,
        max_seq_len=64,
        dropout=0.0,
        mlp_ratio=4,
        use_cache=False,
        norm="rmsnorm",
    )

    cfg.routing = {}
    cfg.blocks = {
        "retnet": {
            "chunkwise": True,
            "chunk_size": 8,
            "rope": False,
        }
    }

    cfg.stack = {
        "pattern": [{"block": "retnet", "repeat": 2}],
        "repeat": 1,
        "tail": [],
    }
    return cfg


def build_tiny_hyena_config() -> EulerStackConfig:
    cfg = EulerStackConfig(
        vocab_size=100,
        d_model=32,
        n_heads=4,
        n_layers=2,
        max_seq_len=64,
        dropout=0.0,
        mlp_ratio=4,
        use_cache=False,
        norm="rmsnorm",
    )

    cfg.routing = {}
    cfg.blocks = {
        "hyena": {
            "depth": 2,
            "filter_hidden": 64,
            "filter_decay": 0.0,
        }
    }

    cfg.stack = {
        "pattern": [{"block": "hyena", "repeat": 2}],
        "repeat": 1,
        "tail": [],
    }
    return cfg


# -------------------------
# Smoke tests
# -------------------------
@torch.no_grad()
def smoke_mamba_moe_aux(device: str = "cpu") -> None:
    cfg = build_tiny_moe_mamba_config()
    model = EulerStackForCausalLM(cfg).to(device)
    model.train()

    b, t = 2, 8
    input_ids = torch.randint(0, cfg.vocab_size, (b, t), device=device)
    labels = torch.randint(0, cfg.vocab_size, (b, t), device=device)

    outputs = model(input_ids=input_ids, labels=labels, output_aux=True, return_dict=True)

    print("\n=== Mamba+MoE forward OK ===")
    print("loss:", outputs.loss.item())

    moe_aux = outputs.moe_aux
    assert moe_aux is not None, "moe_aux is None (output_aux 전달/집계 실패)"

    print("moe_aux keys:", list(moe_aux.keys()))
    assert "layers" in moe_aux, "moe_aux['layers'] missing"
    assert len(moe_aux["layers"]) > 0, "moe_aux['layers'] empty"

    assert "aux_loss_total" in moe_aux, "aux_loss_total missing"
    print("aux_loss_total:", float(moe_aux["aux_loss_total"]))


@torch.no_grad()
def smoke_retnet_cache_and_generate(device: str = "cpu") -> None:
    # 네가 '완전히 잘 도는' test_aux_retnet.py 로직을 그대로 사용
    cfg = build_tiny_retnet_config()
    model = EulerStackForCausalLM(cfg).to(device)
    model.eval()

    b, t = 2, 8
    input_ids = torch.randint(0, cfg.vocab_size, (b, t), device=device)
    labels = torch.randint(0, cfg.vocab_size, (b, t), device=device)

    out_full = model(
        input_ids=input_ids,
        labels=labels,
        use_cache=False,
        output_aux=True,
        return_dict=True,
    )
    print("\n=== RetNet forward OK (no cache) ===")
    print("loss:", out_full.loss.item())
    print("logits shape:", tuple(out_full.logits.shape))

    # cache consistency
    prefix_len = 5
    prefix = input_ids[:, :prefix_len]
    suffix = input_ids[:, prefix_len:]

    out_prefix = model(input_ids=prefix, use_cache=True, return_dict=True)
    pkv = out_prefix.past_key_values
    assert pkv is not None, "use_cache=True인데 past_key_values가 None입니다."

    out_suffix = model(input_ids=suffix, past_key_values=pkv, use_cache=True, return_dict=True)

    logits_full_suffix = out_full.logits[:, prefix_len:, :]
    logits_cached_suffix = out_suffix.logits
    max_diff = (logits_full_suffix - logits_cached_suffix).abs().max().item()

    print("=== RetNet cache consistency ===")
    print("max diff:", max_diff)
    assert max_diff < 1e-4, f"RetNet cache/no-cache mismatch too large: {max_diff}"

    gen = model.generate(
        input_ids=prefix,
        max_new_tokens=2,
        do_sample=False,
        use_cache=True,
    )
    print("=== RetNet generate OK ===")
    print("generated shape:", tuple(gen.shape))


@torch.no_grad()
def smoke_hyena_forward_and_generate(device: str = "cpu") -> None:
    cfg = build_tiny_hyena_config()
    model = EulerStackForCausalLM(cfg).to(device)
    model.eval()

    b, t = 2, 8
    input_ids = torch.randint(0, cfg.vocab_size, (b, t), device=device)
    labels = torch.randint(0, cfg.vocab_size, (b, t), device=device)

    out = model(input_ids=input_ids, labels=labels, output_aux=True, return_dict=True)
    print("\n=== Hyena forward OK ===")
    print("loss:", out.loss.item())
    print("logits shape:", tuple(out.logits.shape))

    # Hyena는 MoE aux 없음: 비어있거나 layers만 있는 게 정상
    if out.moe_aux is not None:
        print("moe_aux keys:", list(out.moe_aux.keys()))
        layers = out.moe_aux.get("layers", {})
        assert len(layers) == 0, "Hyena인데 moe_aux layers가 비어있지 않음(의도한 경우 아니면 확인 필요)"

    # generate는 Hyena가 use_cache를 구현하지 않아도 동작하게 use_cache=False로만 확인
    gen = model.generate(
        input_ids=input_ids[:, :5],
        max_new_tokens=2,
        do_sample=False,
        use_cache=True,
    )
    print("=== Hyena generate OK (use cache) ===")
    print("generated shape:", tuple(gen.shape))


def _run_all_for_device(device: str) -> None:
    print(f"\n\n######## device={device} ########")
    smoke_mamba_moe_aux(device=device)
    smoke_retnet_cache_and_generate(device=device)
    smoke_hyena_forward_and_generate(device=device)


if __name__ == "__main__":
    _run_all_for_device("cpu")
    if torch.cuda.is_available():
        _run_all_for_device("cuda")
    else:
        print("\nCUDA not available; skipped GPU run.")
