# tests/test_cli_spec.py
"""CLI command tests (eulerwa-style flat commands)."""
from __future__ import annotations

import os
import pytest
from click.testing import CliRunner

from eulerstack.cli.main import cli


FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "docs", "fixtures")
VALID_DIR = os.path.join(FIXTURES_DIR, "valid_yamls")
INVALID_DIR = os.path.join(FIXTURES_DIR, "invalid_yamls")


@pytest.fixture
def runner():
    return CliRunner()


# ── validate ──


class TestValidate:
    def test_valid_file_exits_zero(self, runner):
        result = runner.invoke(cli, ["validate", "--preset", os.path.join(VALID_DIR, "llama_like.yml")])
        assert result.exit_code == 0
        assert "OK" in result.output

    def test_invalid_file_exits_nonzero(self, runner):
        result = runner.invoke(cli, ["validate", "--preset", os.path.join(INVALID_DIR, "unknown_key.yml")])
        assert result.exit_code != 0

    def test_error_output_has_3line_format(self, runner):
        result = runner.invoke(cli, ["validate", "--preset", os.path.join(INVALID_DIR, "unknown_key.yml")])
        output = result.output
        assert "Fix:" in output
        assert "See:" in output

    def test_missing_file_exits_nonzero(self, runner):
        result = runner.invoke(cli, ["validate", "--preset", "/nonexistent/path.yml"])
        assert result.exit_code != 0

    def test_report_flag(self, runner):
        # --lang en so the test is language-pinned and does not depend on default.
        result = runner.invoke(cli, ["--lang", "en", "validate",
                                      "--preset", os.path.join(VALID_DIR, "llama_like.yml"),
                                      "--report"])
        assert result.exit_code == 0
        assert "EulerStack Validation Report" in result.output
        # Schema + Result lines must also be translated.
        assert "Schema: OK" in result.output
        assert "Result:" in result.output

    def test_report_flag_korean(self, runner):
        """--lang ko must translate the full report body, not leave English headers."""
        result = runner.invoke(cli, ["--lang", "ko", "validate",
                                      "--preset", os.path.join(VALID_DIR, "llama_like.yml"),
                                      "--report"])
        assert result.exit_code == 0
        assert "검증 리포트" in result.output
        assert "결과:" in result.output

    def test_validate_only_flag(self, runner):
        result = runner.invoke(cli, ["validate", "--preset", os.path.join(VALID_DIR, "llama_like.yml"), "--validate-only"])
        assert result.exit_code == 0
        assert "OK" in result.output


# ── explain ──


class TestExplain:
    def test_explain_valid_file(self, runner):
        result = runner.invoke(cli, ["explain", "--preset", os.path.join(VALID_DIR, "llama_like.yml")])
        assert result.exit_code == 0
        assert "tiny-llama" in result.output

    def test_explain_shows_schedule(self, runner):
        result = runner.invoke(cli, ["explain", "--preset", os.path.join(VALID_DIR, "hybrid_mixed.yml")])
        assert result.exit_code == 0
        assert "mamba" in result.output.lower()
        assert "attention" in result.output.lower()

    def test_explain_shows_params(self, runner):
        # Use --lang en so the English "Estimated params" string is in output.
        result = runner.invoke(cli, ["--lang", "en", "explain",
                                     "--preset", os.path.join(VALID_DIR, "llama_like.yml")])
        assert result.exit_code == 0
        assert "Estimated params" in result.output

    def test_explain_ko_default(self, runner):
        # Default language is Korean; Korean label must appear.
        result = runner.invoke(cli, ["explain", "--preset", os.path.join(VALID_DIR, "llama_like.yml")])
        assert result.exit_code == 0
        assert "추정 파라미터" in result.output


# ── compile ──


class TestCompile:
    def test_compile_valid_file(self, runner, tmp_path):
        result = runner.invoke(cli, [
            "compile", "--preset", os.path.join(VALID_DIR, "llama_like.yml"),
            "--output", str(tmp_path / "compiled.json"),
        ])
        assert result.exit_code == 0
        assert (tmp_path / "compiled.json").exists()

    def test_compile_dry_run(self, runner):
        result = runner.invoke(cli, [
            "compile", "--preset", os.path.join(VALID_DIR, "llama_like.yml"),
            "--dry-run",
        ])
        assert result.exit_code == 0
        assert '"config"' in result.output

    def test_compile_print_config(self, runner):
        result = runner.invoke(cli, [
            "compile", "--preset", os.path.join(VALID_DIR, "llama_like.yml"),
            "--print-config",
        ])
        assert result.exit_code == 0
        assert '"config"' in result.output

    def test_compile_output_dir_creates_hf_model(self, runner, tmp_path):
        out_dir = str(tmp_path / "hf_model")
        result = runner.invoke(cli, [
            "--lang", "en", "compile",
            "--preset", os.path.join(VALID_DIR, "llama_like.yml"),
            "--output-dir", out_dir,
        ])
        assert result.exit_code == 0
        assert "HF model saved to" in result.output
        assert "from_pretrained" in result.output
        assert (tmp_path / "hf_model" / "config.json").exists()

    def test_compile_output_dir_saves_tokenizer(self, runner, tmp_path):
        """compile --output-dir must also save the tokenizer.

        Downstream code (HF Trainer, our projects/ training scripts) calls
        `AutoTokenizer.from_pretrained(output_dir)`. That only works if the
        compile step persists the tokenizer referenced by the YAML spec's
        `tokenizer_contract.pretrained`.
        """
        out_dir = tmp_path / "hf_model"
        result = runner.invoke(cli, [
            "--lang", "en", "compile",
            "--preset", os.path.join(VALID_DIR, "llama_like.yml"),
            "--output-dir", str(out_dir),
        ])
        assert result.exit_code == 0, result.output
        # tokenizer_config.json is present on every HF tokenizer save.
        assert (out_dir / "tokenizer_config.json").exists(), \
            f"tokenizer_config.json missing from {out_dir}; contents: " \
            f"{[p.name for p in out_dir.iterdir()]}"

    def test_compile_output_dir_tokenizer_loadable(self, runner, tmp_path):
        """AutoTokenizer.from_pretrained must succeed on the compiled dir."""
        pytest.importorskip("transformers")
        from transformers import AutoTokenizer
        out_dir = tmp_path / "hf_model"
        result = runner.invoke(cli, [
            "compile",
            "--preset", os.path.join(VALID_DIR, "llama_like.yml"),
            "--output-dir", str(out_dir),
        ])
        assert result.exit_code == 0, result.output
        tok = AutoTokenizer.from_pretrained(str(out_dir), trust_remote_code=True)
        # gpt2 vocab size is 50257; accept any sane range.
        assert tok.vocab_size > 1000
        # Smoke: tokenizer actually encodes.
        ids = tok("hello world", return_tensors=None)["input_ids"]
        assert len(ids) > 0

    def test_compile_validate_only(self, runner):
        result = runner.invoke(cli, [
            "compile", "--preset", os.path.join(VALID_DIR, "llama_like.yml"),
            "--validate-only",
        ])
        assert result.exit_code == 0
        assert "validate-only" in result.output.lower()
        assert '"config"' not in result.output


# ── schema ──


class TestSchema:
    def test_schema_output(self, runner):
        result = runner.invoke(cli, ["schema"])
        assert result.exit_code == 0
        assert "schema_version" in result.output
        assert "model" in result.output
        assert "layer_templates" in result.output


# ── 3-line error format enforcement ──


class TestErrorFormat:
    @pytest.mark.parametrize("fixture", [
        "unknown_key.yml",
        "invalid_enum.yml",
        "missing_required.yml",
    ])
    def test_all_errors_have_3line_format(self, runner, fixture):
        result = runner.invoke(cli, ["validate", "--preset", os.path.join(INVALID_DIR, fixture)])
        assert result.exit_code != 0
        output = result.output
        assert "Fix:" in output
        assert "See:" in output
