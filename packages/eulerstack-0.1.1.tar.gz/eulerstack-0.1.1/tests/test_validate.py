# tests/test_validate_v2.py
"""Strict v2 validation tests — cross-field constraints and compatibility checks."""
from __future__ import annotations

import os
import pytest
import yaml

from eulerstack.spec.errors import ValidationError, CompatibilityError
from eulerstack.spec.validate import validate_v2


FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "docs", "fixtures")
VALID_DIR = os.path.join(FIXTURES_DIR, "valid_yamls")
INVALID_DIR = os.path.join(FIXTURES_DIR, "invalid_yamls")


def _load(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


# ── Valid fixtures pass validation ──


class TestValidFixturesPassValidation:
    @pytest.mark.parametrize("name", ["llama_like.yml", "hybrid_mixed.yml", "moe_model.yml"])
    def test_valid_fixture(self, name: str):
        raw = _load(os.path.join(VALID_DIR, name))
        # Should not raise
        validate_v2(raw)


# ── Cross-field: mixer/state compatibility (R5) ──


class TestMixerStateCompatibility:
    def test_mamba_with_kv_cache_raises(self):
        raw = _load(os.path.join(INVALID_DIR, "incompatible_mixer_state.yml"))
        with pytest.raises(CompatibilityError, match="kv_cache"):
            validate_v2(raw)

    def test_attention_with_kv_cache_ok(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        validate_v2(raw)  # should not raise


# ── Cross-field: ffn/moe compatibility (R6) ──


class TestFfnMoeCompatibility:
    def test_gated_mlp_with_moe_section_raises(self):
        raw = _load(os.path.join(INVALID_DIR, "incompatible_moe_routing.yml"))
        with pytest.raises(ValidationError, match="moe"):
            validate_v2(raw)


# ── Schedule template references (R8) ──


class TestScheduleValidation:
    def test_nonexistent_template_raises(self):
        raw = _load(os.path.join(INVALID_DIR, "invalid_schedule.yml"))
        with pytest.raises(ValidationError, match="nonexistent"):
            validate_v2(raw)

    def test_valid_schedule(self):
        raw = _load(os.path.join(VALID_DIR, "hybrid_mixed.yml"))
        validate_v2(raw)  # should not raise


# ── d_model/n_heads divisibility (R12) ──


class TestModelConstraints:
    def test_d_model_not_divisible_by_n_heads(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        raw["model"]["d_model"] = 65  # not divisible by 8
        with pytest.raises(ValidationError, match="divisible"):
            validate_v2(raw)

    def test_n_kv_heads_not_dividing_n_heads(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        raw["model"]["n_kv_heads"] = 3  # 8 % 3 != 0
        with pytest.raises(ValidationError, match="n_kv_heads"):
            validate_v2(raw)


# ── Embedding/rope compatibility (R7) ──


class TestEmbeddingRopeCompatibility:
    def test_non_rope_with_rope_theta_raises(self):
        raw = _load(os.path.join(VALID_DIR, "moe_model.yml"))
        # moe_model uses positional=none
        raw["embedding"]["rope_theta"] = 10000.0
        with pytest.raises(ValidationError, match="rope"):
            validate_v2(raw)
