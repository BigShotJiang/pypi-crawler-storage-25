# tests/test_integration.py
"""End-to-end integration tests: YAML v2 → validate → IR → compile pipeline."""
from __future__ import annotations

import os
import json
import pytest
import yaml

from eulerstack.spec.validate import validate_v2
from eulerstack.ir.normalizer import normalize_to_ir
from eulerstack.compiler.compile import compile_ir


FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "docs", "fixtures")
VALID_DIR = os.path.join(FIXTURES_DIR, "valid_yamls")


def _load(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


class TestFullPipeline:
    @pytest.mark.parametrize("name", ["llama_like.yml", "hybrid_mixed.yml", "moe_model.yml"])
    def test_validate_normalize_compile(self, name: str):
        raw = _load(os.path.join(VALID_DIR, name))

        # Step 1: validate
        validate_v2(raw)

        # Step 2: normalize to IR
        ir = normalize_to_ir(raw)
        assert len(ir.expanded_layers) > 0

        # Step 3: compile
        result = compile_ir(ir)
        assert "config" in result

        # Step 4: result should be JSON-serializable
        json_str = json.dumps(result, indent=2)
        assert len(json_str) > 0

    def test_llama_like_roundtrip_shapes(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        validate_v2(raw)
        ir = normalize_to_ir(raw)
        result = compile_ir(ir)

        cfg = result["config"]
        assert cfg["d_model"] == 256
        assert cfg["vocab_size"] == 32000
        assert cfg["n_heads"] == 8
        assert cfg["n_layers"] == 4
        assert cfg["max_seq_len"] == 2048
