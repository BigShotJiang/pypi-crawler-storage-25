# tests/test_realism.py
"""Realism rules unit tests."""
from __future__ import annotations

import os
import copy
import pytest
import yaml

from eulerstack.ir.normalizer import normalize_to_ir
from eulerstack.spec.realism import Severity, run_realism_checks, Finding


FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "docs", "fixtures")
VALID_DIR = os.path.join(FIXTURES_DIR, "valid_yamls")


def _load(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


def _findings_by_rule(findings: list, rule: str) -> list:
    return [f for f in findings if f.rule == rule]


class TestHeadDimRange:
    def test_tiny_head_dim_warns(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        raw["model"]["d_model"] = 64
        raw["model"]["n_heads"] = 8  # head_dim = 8
        raw["model"]["n_kv_heads"] = 4
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        hd = _findings_by_rule(findings, "head_dim_range")
        assert any(f.severity == Severity.WARNING for f in hd)

    def test_normal_head_dim_no_warning(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        # d_model=256, n_heads=8 → head_dim=32 (boundary)
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        hd = _findings_by_rule(findings, "head_dim_range")
        assert not any(f.severity == Severity.WARNING for f in hd)


class TestTargetParamsMismatch:
    def test_no_target_no_warning(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        assert not _findings_by_rule(findings, "target_params_mismatch")

    def test_matching_target_no_warning(self):
        from eulerstack.spec.param_estimator import estimate_params
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        est = estimate_params(ir)
        # Set target close to actual
        raw["model"]["target_params"] = est
        ir2 = normalize_to_ir(raw)
        findings = run_realism_checks(ir2)
        assert not _findings_by_rule(findings, "target_params_mismatch")

    def test_wildly_off_target_warns(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        # Tiny model claiming to be 2B
        raw["model"]["target_params"] = 2_000_000_000
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        tm = _findings_by_rule(findings, "target_params_mismatch")
        assert any(f.severity == Severity.WARNING for f in tm)


class TestMoeExpertRatio:
    def test_valid_moe_no_error(self):
        raw = _load(os.path.join(VALID_DIR, "moe_model.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        errs = [f for f in _findings_by_rule(findings, "moe_expert_ratio") if f.severity == Severity.ERROR]
        assert len(errs) == 0


class TestFamilyHintConsistency:
    def test_llama_hint_with_mamba_warns(self):
        raw = _load(os.path.join(VALID_DIR, "hybrid_mixed.yml"))
        raw["model"]["family_hint"] = "llama-like"
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        fh = _findings_by_rule(findings, "family_hint_consistency")
        assert any(f.severity == Severity.WARNING for f in fh)

    def test_correct_hint_no_warning(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        fh = _findings_by_rule(findings, "family_hint_consistency")
        assert not any(f.severity == Severity.WARNING for f in fh)


class TestParamCountInfo:
    def test_always_has_info(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        pc = _findings_by_rule(findings, "param_count_info")
        assert len(pc) == 1
        assert pc[0].severity == Severity.INFO


class TestDisableRules:
    def test_disabled_rule_skipped(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir, disabled={"param_count_info"})
        assert not _findings_by_rule(findings, "param_count_info")


# ── Phase B realism rules (v1 new primitives) ─────────────────────────────


WARNING_DIR = os.path.join(FIXTURES_DIR, "warning_yamls")


class TestMlaLatentDimRange:
    """Rule: mla_latent_dim_range."""

    def test_healthy_mla_no_warning(self):
        raw = _load(os.path.join(VALID_DIR, "mla_attention.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        assert not _findings_by_rule(findings, "mla_latent_dim_range")

    def test_tiny_latent_warns(self):
        raw = _load(os.path.join(WARNING_DIR, "mla_latent_too_small.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        w = _findings_by_rule(findings, "mla_latent_dim_range")
        assert len(w) >= 1
        assert w[0].severity == Severity.WARNING

    def test_excessive_latent_warns(self):
        """latent_dim > d_model·3/4 is a valid-but-pointless configuration."""
        raw = _load(os.path.join(VALID_DIR, "mla_attention.yml"))
        # d_model=256 → upper threshold = 192. Use 220 to trigger warn.
        raw["layer_templates"]["mla"]["mixer"]["attention"]["latent_dim"] = 220
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        assert _findings_by_rule(findings, "mla_latent_dim_range")


class TestExecutionModesBudget:
    """Rule: execution_modes_budget."""

    def test_healthy_budget_no_warning(self):
        raw = _load(os.path.join(VALID_DIR, "reasoning_mode_r1.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        assert not _findings_by_rule(findings, "execution_modes_budget")

    def test_over_budget_warns(self):
        raw = _load(os.path.join(WARNING_DIR, "execution_modes_budget_exceeds.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        w = _findings_by_rule(findings, "execution_modes_budget")
        assert len(w) == 1
        assert "1200" in w[0].message


class TestDepthGatingCapacityExtreme:
    """Rule: depth_gating_capacity_extreme."""

    def test_normal_capacity_no_warning(self):
        raw = _load(os.path.join(VALID_DIR, "depth_gating_mod.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        assert not _findings_by_rule(findings, "depth_gating_capacity_extreme")

    def test_tiny_capacity_warns(self):
        raw = _load(os.path.join(VALID_DIR, "depth_gating_mod.yml"))
        raw["layer_schedule"][0]["depth_gating"]["capacity"] = 0.05
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        w = _findings_by_rule(findings, "depth_gating_capacity_extreme")
        assert len(w) == 1
        assert "0.050" in w[0].message or "very" in w[0].message.lower()

    def test_capacity_one_warns_as_noop(self):
        raw = _load(os.path.join(VALID_DIR, "depth_gating_mod.yml"))
        raw["layer_schedule"][0]["depth_gating"]["capacity"] = 1.0
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        w = _findings_by_rule(findings, "depth_gating_capacity_extreme")
        assert len(w) == 1
        assert "no-op" in w[0].message


class TestIntegratorStepsRange:
    """Rule: integrator_steps_range."""

    def test_normal_steps_no_warning(self):
        raw = _load(os.path.join(VALID_DIR, "integrator_discrete.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        assert not _findings_by_rule(findings, "integrator_steps_range")

    def test_huge_steps_warn(self):
        raw = _load(os.path.join(WARNING_DIR, "integrator_steps_huge.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        w = _findings_by_rule(findings, "integrator_steps_range")
        assert len(w) == 1
        assert "128" in w[0].message


class TestMemoryHiddenRange:
    """Rule: memory_hidden_range."""

    def test_reasonable_memory_no_warning(self):
        raw = _load(os.path.join(VALID_DIR, "memory_module_titans.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        assert not _findings_by_rule(findings, "memory_hidden_range")

    def test_oversized_memory_warns(self):
        raw = _load(os.path.join(VALID_DIR, "memory_module_titans.yml"))
        # d_model=256 → threshold 2048; 16384 = 64·d_model clearly over
        raw["layer_templates"]["attn_with_mem"]["memory"]["params"]["hidden"] = 16384
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        assert _findings_by_rule(findings, "memory_hidden_range")


class TestShapeChangeDirection:
    """Rule: shape_change_direction — Hourglass convention is narrowing."""

    def test_narrowing_no_warning(self):
        raw = _load(os.path.join(VALID_DIR, "shape_change_hourglass.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        assert not _findings_by_rule(findings, "shape_change_direction")

    def test_widening_warns(self):
        raw = _load(os.path.join(VALID_DIR, "shape_change_hourglass.yml"))
        raw["layer_templates"]["bottleneck_block"]["shape_change"]["d_out"] = 1024  # > 256
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        assert _findings_by_rule(findings, "shape_change_direction")


class TestBranchedSelectorTopK:
    """branched.selector.top_k > branch count — now enforced at schema level."""

    def test_healthy_top_k_parses(self):
        raw = _load(os.path.join(VALID_DIR, "branched_mixer.yml"))
        ir = normalize_to_ir(raw)
        assert ir.layer_templates["branched_layer"].mixer.type == "branched"

    def test_top_k_exceeds_branches_rejected_by_validator(self):
        from eulerstack.spec.validate import validate_v2
        from eulerstack.spec.errors import ValidationError
        raw = _load(os.path.join(
            FIXTURES_DIR, "invalid_yamls", "branched_top_k_exceeds_branches.yml"))
        with pytest.raises(ValidationError, match="branch count"):
            validate_v2(raw)


class TestTtTInnerLrRange:
    """Rule: ttt_inner_lr_range."""

    def test_normal_lr_no_warning(self):
        raw = _load(os.path.join(VALID_DIR, "ttt_layer.yml"))
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        assert not _findings_by_rule(findings, "ttt_inner_lr_range")

    def test_absurd_lr_warns(self):
        raw = _load(os.path.join(VALID_DIR, "ttt_layer.yml"))
        raw["layer_templates"]["ttt_block"]["mixer"]["ttt"]["inner_lr"] = 10.0
        ir = normalize_to_ir(raw)
        findings = run_realism_checks(ir)
        assert _findings_by_rule(findings, "ttt_inner_lr_range")


class TestReportGeneration:
    def test_valid_yaml_produces_report(self):
        from eulerstack.spec.report import generate_report
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        report = generate_report(raw)
        assert report.schema_ok
        assert report.estimated_params is not None
        assert report.estimated_params > 0

    def test_invalid_yaml_schema_fail(self):
        from eulerstack.spec.report import generate_report
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        raw["foobar"] = 123
        report = generate_report(raw)
        assert not report.schema_ok

    def test_report_format_text(self):
        """Report text contains header + OK marker. Pin language so the test
        is order-independent (other suites may leave the global lang set to
        something else)."""
        from eulerstack.spec.report import generate_report
        from eulerstack.i18n import set_lang
        set_lang("en")
        try:
            raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
            report = generate_report(raw)
            text = report.format_text()
            assert "Validation Report" in text
            assert "OK" in text
        finally:
            set_lang("ko")            # restore default for downstream tests
