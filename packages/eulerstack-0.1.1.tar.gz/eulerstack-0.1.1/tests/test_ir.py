# tests/test_ir.py
"""IR normalization and invariant tests."""
from __future__ import annotations

import os
import pytest
import yaml

from eulerstack.ir.types import ModelIR, LayerTemplateIR
from eulerstack.ir.normalizer import normalize_to_ir


FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "docs", "fixtures")
VALID_DIR = os.path.join(FIXTURES_DIR, "valid_yamls")


def _load(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


class TestIRNormalization:
    def test_llama_like_produces_model_ir(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        assert isinstance(ir, ModelIR)

    def test_expanded_layers_count(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        assert len(ir.expanded_layers) == 4  # decoder repeat=4

    def test_hybrid_mixed_expanded_layers(self):
        raw = _load(os.path.join(VALID_DIR, "hybrid_mixed.yml"))
        ir = normalize_to_ir(raw)
        # mamba*2 + attn*1 + retnet*1 = 4
        assert len(ir.expanded_layers) == 4
        assert ir.expanded_layers[0].mixer.type == "mamba"
        assert ir.expanded_layers[1].mixer.type == "mamba"
        assert ir.expanded_layers[2].mixer.type == "attention"
        assert ir.expanded_layers[3].mixer.type == "retnet"

    def test_moe_model_ffn_type(self):
        raw = _load(os.path.join(VALID_DIR, "moe_model.yml"))
        ir = normalize_to_ir(raw)
        for layer in ir.expanded_layers:
            assert layer.ffn.type == "moe"
            assert layer.ffn.moe is not None
            assert layer.ffn.moe.experts == 4

    def test_defaults_filled(self):
        """Optional fields should be filled with defaults after normalization."""
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        layer = ir.expanded_layers[0]
        assert layer.norm.type == "rmsnorm"
        assert layer.norm.position == "pre"
        assert layer.residual.type == "sequential"
        assert layer.residual.scaling == 1.0

    def test_n_kv_heads_resolved(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        assert ir.model.n_kv_heads == 4  # explicitly set in fixture

    def test_n_kv_heads_defaults_to_n_heads(self):
        raw = _load(os.path.join(VALID_DIR, "hybrid_mixed.yml"))
        ir = normalize_to_ir(raw)
        assert ir.model.n_kv_heads == ir.model.n_heads  # not explicitly set

    def test_all_layers_are_layer_template_ir(self):
        raw = _load(os.path.join(VALID_DIR, "hybrid_mixed.yml"))
        ir = normalize_to_ir(raw)
        for layer in ir.expanded_layers:
            assert isinstance(layer, LayerTemplateIR)

    def test_model_identity_fields(self):
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        assert ir.model.name == "tiny-llama"
        assert ir.model.d_model == 256
        assert ir.model.vocab_size == 32000
        assert ir.model.max_seq_len == 2048
