# tests/test_integrator_runtime.py
"""Tier-3 runtime tests for the discrete integrator primitive (Phase B3.3)."""
from __future__ import annotations

import pytest
import torch
import torch.nn as nn

from eulerstack.components.integrator import DiscreteIntegrator, iterate


class _AddOne(nn.Module):
    """Toy body: adds a learned bias (scalar) every step."""
    def __init__(self):
        super().__init__()
        self.bias = nn.Parameter(torch.tensor(1.0))

    def forward(self, x):
        return x + self.bias


class TestDiscreteIntegrator:
    def test_single_step(self):
        body = _AddOne()
        intg = DiscreteIntegrator(body, steps=1)
        x = torch.zeros(4)
        assert torch.allclose(intg(x), torch.ones(4))

    def test_k_step_accumulates(self):
        """K steps with shared weights = K applications of same body."""
        body = _AddOne()
        intg = DiscreteIntegrator(body, steps=5)
        x = torch.zeros(3)
        # AddOne adds bias=1 each step; K=5 → all ones × 5
        assert torch.allclose(intg(x), torch.full((3,), 5.0))

    def test_shared_weights_single_parameter(self):
        """Param count must match the body — not K × body."""
        body = _AddOne()                          # 1 param
        intg = DiscreteIntegrator(body, steps=7)  # still 1 param
        assert sum(p.numel() for p in intg.parameters()) == 1

    def test_backward_through_all_steps(self):
        body = _AddOne()
        intg = DiscreteIntegrator(body, steps=3)
        x = torch.zeros(1, requires_grad=True)
        y = intg(x)
        y.sum().backward()
        # d(y)/d(bias) should be 3 (3 additions of the same bias)
        assert body.bias.grad is not None
        assert body.bias.grad.item() == pytest.approx(3.0)

    def test_rejects_zero_or_negative_steps(self):
        body = _AddOne()
        with pytest.raises(ValueError):
            DiscreteIntegrator(body, steps=0)
        with pytest.raises(ValueError):
            DiscreteIntegrator(body, steps=-1)

    def test_step_aware_receives_index(self):
        """`step_aware=True` threads the step index into the body call."""
        calls = []

        class _Logger(nn.Module):
            def forward(self, x, step_index=None):
                calls.append(step_index)
                return x

        intg = DiscreteIntegrator(_Logger(), steps=4, step_aware=True)
        _ = intg(torch.zeros(2))
        assert calls == [0, 1, 2, 3]

    def test_extra_repr(self):
        intg = DiscreteIntegrator(_AddOne(), steps=3)
        r = repr(intg)
        assert "steps=3" in r


class TestIterateFunctional:
    def test_iterate_k_times(self):
        def f(x):
            return x + 1
        y = iterate(f, torch.zeros(2), steps=3)
        assert torch.allclose(y, torch.full((2,), 3.0))

    def test_iterate_rejects_zero(self):
        with pytest.raises(ValueError):
            iterate(lambda x: x, torch.zeros(1), steps=0)
