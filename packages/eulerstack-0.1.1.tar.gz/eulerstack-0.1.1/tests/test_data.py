# tests/test_data.py
"""Data pipeline unit tests (cache key, dataset creation)."""
from __future__ import annotations

import pytest
from eulerstack.data.prepare import compute_cache_key, TokenizedDataset
import torch


class TestCacheKey:
    def test_deterministic(self):
        k1 = compute_cache_key("gpt2", 512, "wiki", "train", 1000)
        k2 = compute_cache_key("gpt2", 512, "wiki", "train", 1000)
        assert k1 == k2

    def test_different_params_different_key(self):
        k1 = compute_cache_key("gpt2", 512, "wiki", "train", 1000)
        k2 = compute_cache_key("gpt2", 1024, "wiki", "train", 1000)
        assert k1 != k2

    def test_key_is_string(self):
        k = compute_cache_key("gpt2", 512, "wiki", "train", 1000)
        assert isinstance(k, str)
        assert len(k) == 16


class TestTokenizedDataset:
    def test_len(self):
        ids = torch.randint(0, 100, (10, 64))
        ds = TokenizedDataset(ids)
        assert len(ds) == 10

    def test_getitem(self):
        ids = torch.randint(0, 100, (5, 32))
        ds = TokenizedDataset(ids)
        item = ds[0]
        assert "input_ids" in item
        assert "labels" in item
        assert item["input_ids"].shape == (32,)
