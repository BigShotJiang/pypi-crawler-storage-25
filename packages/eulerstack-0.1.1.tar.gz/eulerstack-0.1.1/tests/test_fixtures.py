# tests/test_fixtures.py
"""Comprehensive fixture-based tests: invalid fixtures → errors, warning fixtures → warnings."""
from __future__ import annotations

import os
import glob
import pytest
import yaml

from eulerstack.i18n import set_lang
from eulerstack.spec.errors import ValidationError, CompatibilityError, EulerStackError
from eulerstack.spec.schema import parse_v2_yaml
from eulerstack.spec.validate import validate_v2
from eulerstack.ir.normalizer import normalize_to_ir
from eulerstack.spec.report import generate_report
from eulerstack.spec.realism import Severity


@pytest.fixture(autouse=True)
def _pin_lang_en():
    """Pin language to English for these tests so regex assertions on error
    message body match the canonical English form. (Validation errors are now
    i18n'd — default language ko would otherwise break `match=` patterns.)
    """
    set_lang("en")
    yield
    set_lang("ko")


FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "docs", "fixtures")
VALID_DIR = os.path.join(FIXTURES_DIR, "valid_yamls")
INVALID_DIR = os.path.join(FIXTURES_DIR, "invalid_yamls")
WARNING_DIR = os.path.join(FIXTURES_DIR, "warning_yamls")


def _load(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


# ══════════════════════════════════════════
# Invalid fixtures — ALL must raise errors
# ══════════════════════════════════════════

INVALID_FILES = sorted(glob.glob(os.path.join(INVALID_DIR, "*.yml")))
INVALID_NAMES = [os.path.splitext(os.path.basename(f))[0] for f in INVALID_FILES]


class TestAllInvalidFixturesRaise:
    """Every file in invalid_yamls/ must cause a validation error."""

    @pytest.mark.parametrize("path", INVALID_FILES, ids=INVALID_NAMES)
    def test_invalid_fixture_raises(self, path):
        raw = _load(path)
        with pytest.raises(EulerStackError):
            validate_v2(raw)

    def test_at_least_20_invalid_fixtures(self):
        assert len(INVALID_FILES) >= 20, f"Only {len(INVALID_FILES)} invalid fixtures (need ≥20)"


class TestSpecificInvalidErrors:
    def test_unknown_key(self):
        raw = _load(os.path.join(INVALID_DIR, "unknown_key.yml"))
        with pytest.raises(ValidationError, match="unknown"):
            parse_v2_yaml(raw)

    def test_invalid_enum(self):
        raw = _load(os.path.join(INVALID_DIR, "invalid_enum.yml"))
        with pytest.raises(ValidationError):
            parse_v2_yaml(raw)

    def test_missing_required(self):
        raw = _load(os.path.join(INVALID_DIR, "missing_required.yml"))
        with pytest.raises(ValidationError, match="d_model"):
            parse_v2_yaml(raw)

    def test_incompatible_mixer_state(self):
        raw = _load(os.path.join(INVALID_DIR, "incompatible_mixer_state.yml"))
        with pytest.raises(CompatibilityError, match="kv_cache"):
            validate_v2(raw)

    def test_repeat_zero(self):
        raw = _load(os.path.join(INVALID_DIR, "repeat_zero.yml"))
        with pytest.raises(ValidationError, match="positive"):
            parse_v2_yaml(raw)

    def test_d_model_not_divisible(self):
        raw = _load(os.path.join(INVALID_DIR, "d_model_not_divisible.yml"))
        with pytest.raises(ValidationError, match="divisible"):
            validate_v2(raw)

    def test_n_kv_heads_not_dividing(self):
        raw = _load(os.path.join(INVALID_DIR, "n_kv_heads_not_dividing.yml"))
        with pytest.raises(ValidationError, match="n_kv_heads"):
            validate_v2(raw)

    def test_rope_with_non_rope_positional(self):
        raw = _load(os.path.join(INVALID_DIR, "rope_with_non_rope_positional.yml"))
        with pytest.raises(ValidationError, match="rope"):
            validate_v2(raw)

    def test_mixer_wrong_subobject(self):
        raw = _load(os.path.join(INVALID_DIR, "mixer_wrong_subobject.yml"))
        with pytest.raises(ValidationError, match="mamba"):
            parse_v2_yaml(raw)

    def test_moe_missing_experts(self):
        raw = _load(os.path.join(INVALID_DIR, "moe_missing_experts.yml"))
        with pytest.raises(ValidationError, match="experts"):
            parse_v2_yaml(raw)

    def test_empty_layer_templates(self):
        raw = _load(os.path.join(INVALID_DIR, "empty_layer_templates.yml"))
        with pytest.raises(ValidationError, match="non-empty"):
            parse_v2_yaml(raw)

    def test_empty_layer_schedule(self):
        raw = _load(os.path.join(INVALID_DIR, "empty_layer_schedule.yml"))
        with pytest.raises(ValidationError, match="non-empty"):
            parse_v2_yaml(raw)

    def test_missing_schema_version(self):
        raw = _load(os.path.join(INVALID_DIR, "missing_schema_version.yml"))
        with pytest.raises(ValidationError, match="schema_version"):
            parse_v2_yaml(raw)

    def test_wrong_schema_version(self):
        raw = _load(os.path.join(INVALID_DIR, "wrong_schema_version.yml"))
        with pytest.raises(ValidationError, match="schema_version"):
            parse_v2_yaml(raw)

    def test_missing_head(self):
        raw = _load(os.path.join(INVALID_DIR, "missing_head.yml"))
        with pytest.raises(ValidationError, match="head"):
            parse_v2_yaml(raw)

    def test_invalid_norm_type(self):
        raw = _load(os.path.join(INVALID_DIR, "invalid_norm_type.yml"))
        with pytest.raises(ValidationError, match="batchnorm"):
            parse_v2_yaml(raw)

    def test_invalid_dtype(self):
        raw = _load(os.path.join(INVALID_DIR, "invalid_dtype.yml"))
        with pytest.raises(ValidationError, match="int8"):
            parse_v2_yaml(raw)


# ══════════════════════════════════════════
# Warning fixtures — must pass validation but have warnings
# ══════════════════════════════════════════

WARNING_FILES = sorted(glob.glob(os.path.join(WARNING_DIR, "*.yml"))) if os.path.isdir(WARNING_DIR) else []
WARNING_NAMES = [os.path.splitext(os.path.basename(f))[0] for f in WARNING_FILES]


class TestAllWarningFixturesPassSchema:
    """Every warning fixture must be structurally valid (no schema errors)."""

    @pytest.mark.parametrize("path", WARNING_FILES, ids=WARNING_NAMES)
    def test_warning_fixture_is_valid(self, path):
        raw = _load(path)
        validate_v2(raw)  # must not raise

    def test_at_least_10_warning_fixtures(self):
        assert len(WARNING_FILES) >= 10, f"Only {len(WARNING_FILES)} warning fixtures (need ≥10)"


class TestWarningFixturesHaveWarnings:
    """Each warning fixture should produce at least one realism WARNING."""

    @pytest.mark.parametrize("path", WARNING_FILES, ids=WARNING_NAMES)
    def test_warning_fixture_produces_warnings(self, path):
        raw = _load(path)
        report = generate_report(raw)
        assert report.schema_ok, f"Schema failed: {report.schema_error}"
        warnings = [f for f in report.findings if f.severity == Severity.WARNING]
        assert len(warnings) > 0, f"No warnings for {os.path.basename(path)}"


class TestSpecificWarnings:
    def test_tiny_head_dim_warns(self):
        raw = _load(os.path.join(WARNING_DIR, "tiny_head_dim.yml"))
        report = generate_report(raw)
        assert any("head_dim" in f.rule for f in report.warnings)

    def test_huge_head_dim_warns(self):
        raw = _load(os.path.join(WARNING_DIR, "huge_head_dim.yml"))
        report = generate_report(raw)
        assert any("head_dim" in f.rule for f in report.warnings)

    def test_target_mismatch_warns(self):
        raw = _load(os.path.join(WARNING_DIR, "target_params_mismatch.yml"))
        report = generate_report(raw)
        assert any("target_params" in f.rule for f in report.warnings)

    def test_family_hint_mismatch_warns(self):
        raw = _load(os.path.join(WARNING_DIR, "family_hint_mismatch.yml"))
        report = generate_report(raw)
        assert any("family_hint" in f.rule for f in report.warnings)

    def test_vocab_mismatch_warns(self):
        raw = _load(os.path.join(WARNING_DIR, "vocab_tokenizer_mismatch.yml"))
        report = generate_report(raw)
        assert any("vocab" in f.rule for f in report.warnings)

    def test_tie_weight_inconsistency_warns(self):
        raw = _load(os.path.join(WARNING_DIR, "tie_weight_inconsistency.yml"))
        report = generate_report(raw)
        assert any("tie_weight" in f.rule for f in report.warnings)

    def test_extreme_seq_len_warns(self):
        raw = _load(os.path.join(WARNING_DIR, "extreme_seq_len.yml"))
        report = generate_report(raw)
        assert any("seq_len" in f.rule for f in report.warnings)

    def test_high_rope_scaling_warns(self):
        raw = _load(os.path.join(WARNING_DIR, "high_rope_scaling.yml"))
        report = generate_report(raw)
        assert any("rope_scaling" in f.rule for f in report.warnings)

    def test_many_experts_warns(self):
        raw = _load(os.path.join(WARNING_DIR, "many_experts.yml"))
        report = generate_report(raw)
        assert any("moe" in f.rule for f in report.warnings)


# ══════════════════════════════════════════
# Valid fixtures — must pass everything
# ══════════════════════════════════════════

VALID_FILES = sorted(glob.glob(os.path.join(VALID_DIR, "*.yml")))
VALID_NAMES = [os.path.splitext(os.path.basename(f))[0] for f in VALID_FILES]


class TestAllValidFixturesPass:
    @pytest.mark.parametrize("path", VALID_FILES, ids=VALID_NAMES)
    def test_valid_fixture_validates(self, path):
        raw = _load(path)
        validate_v2(raw)

    @pytest.mark.parametrize("path", VALID_FILES, ids=VALID_NAMES)
    def test_valid_fixture_normalizes(self, path):
        raw = _load(path)
        ir = normalize_to_ir(raw)
        assert len(ir.expanded_layers) > 0
