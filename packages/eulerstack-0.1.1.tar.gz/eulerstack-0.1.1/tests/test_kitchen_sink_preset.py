# tests/test_kitchen_sink_preset.py
"""Capstone TDD: the "kitchen sink" preset combines every v1 primitive.

`configs/presets/arch_expert_kitchen_sink.yml` deliberately uses, in a
single spec:

    Schema primitives ─────────────────────────────────────────────────
    - let: + ${...} expressions (B1.2)
    - reserved namespaces (experimental.* / vendor.*.* / future.*, B0/B6)
    - per-layer override on plain entries (B1.1)
    - depth_gating (MoD, B3.1)
    - parallel schedule (monoidal, B3.2)
    - integrator discrete (B3.3)
    - integrator ode_rk4 (B3.3 core, v1.1)
    - execution_modes + transition (R1, B5)

    Mixer families ────────────────────────────────────────────────────
    - attention w/ MLA latent_dim (B2.1)
    - mamba (B2 baseline)
    - retnet (B2 baseline)
    - hyena (B2 baseline)
    - branched mixer (B2.2, fallback to first branch)
    - ttt_layer (B2.3, plugin reference or Mamba fallback)

    FFN / per-layer ──────────────────────────────────────────────────
    - gated_mlp (SwiGLU)
    - MoE (B2)
    - Titans neural memory (B4.1, core v1.1)

This test is the capstone that:
    1. validates the preset
    2. compiles to a real HF model
    3. save_pretrained → AutoModelForCausalLM.from_pretrained round-trip
    4. trains on toy data and asserts the loss descends

Without the TTT plugin installed the runtime uses the Mamba fallback
for `ttt_layer` (common-prompt §7). With the plugin imported the real
`TTTBlock` takes over. Both modes are exercised here.
"""
from __future__ import annotations

import os

import pytest
import torch
import yaml
from torch.utils.data import DataLoader, Dataset


PRESET_PATH = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        "..",
        "configs",
        "presets",
        "arch_expert_kitchen_sink.yml",
    )
)


def _load_raw():
    with open(PRESET_PATH) as f:
        return yaml.safe_load(f)


class TestKitchenSinkValidate:
    """RED 1: preset must validate + pass realism."""

    def test_file_exists(self):
        assert os.path.exists(PRESET_PATH), f"preset missing: {PRESET_PATH}"

    def test_schema_passes(self):
        from eulerstack.spec.schema import parse_v2_yaml

        raw = _load_raw()
        parse_v2_yaml(raw)  # no exception

    def test_validate_v2_passes(self):
        from eulerstack.spec.validate import validate_v2

        raw = _load_raw()
        validate_v2(raw)

    def test_normalizes_to_ir(self):
        from eulerstack.ir.normalizer import normalize_to_ir

        raw = _load_raw()
        ir = normalize_to_ir(raw)
        # Must have non-trivial expanded layer list.
        assert len(ir.expanded_layers) >= 12, \
            f"Expected substantial depth; got {len(ir.expanded_layers)} layers"
        # Must carry R1 execution_modes.
        assert ir.execution_modes is not None
        # Reserved namespaces must have warned (collected after parse).
        from eulerstack.spec.schema import get_reserved_warnings
        # Run a fresh parse so the collector actually records.
        from eulerstack.spec.schema import parse_v2_yaml
        parse_v2_yaml(raw)
        warnings = get_reserved_warnings()
        assert len(warnings) >= 2, (
            f"Expected ≥2 reserved-namespace warnings (experimental / vendor / future), "
            f"got {warnings}"
        )

    def test_override_preserves_memory_and_ode(self):
        """Per-layer override must not silently drop template.memory / ode_integrator.

        Before fix, `_apply_override` re-built LayerTemplateIR without the
        B4.1/B3.3 fields, so the two `mla_with_memory` layers that carry an
        override also lost their Titans memory → no TitansMemoryModule in
        the compiled model.
        """
        from eulerstack.ir.normalizer import normalize_to_ir

        ir = normalize_to_ir(_load_raw())
        layers_with_memory = [
            l for l in ir.expanded_layers if l.memory is not None
        ]
        # The preset puts 2 copies of mla_with_memory under an override;
        # both must still carry the memory spec.
        assert len(layers_with_memory) == 2, \
            f"Expected 2 Titans-memory layers, got {len(layers_with_memory)}"
        # ODE body must keep its integrator tag (sanity).
        layers_with_ode = [
            l for l in ir.expanded_layers if l.ode_integrator is not None
        ]
        assert len(layers_with_ode) == 1


class TestKitchenSinkCompile:
    """RED 2: compile to HF model and run one forward pass."""

    def test_compile_to_hf_model(self):
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model

        ir = normalize_to_ir(_load_raw())
        model = compile_to_hf_model(ir, seed=0)
        assert model is not None
        param_count = sum(p.numel() for p in model.parameters())
        assert param_count > 10_000, \
            f"Suspiciously small param count: {param_count}"

    def test_single_forward_runs(self):
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model

        ir = normalize_to_ir(_load_raw())
        model = compile_to_hf_model(ir, seed=0)
        vocab = int(model.config.vocab_size)
        ids = torch.randint(0, vocab, (1, 12))
        out = model(ids)
        assert out.logits.shape == (1, 12, vocab)


class TestKitchenSinkHFRoundTrip:
    """RED 3: save_pretrained → from_pretrained yields a usable model."""

    def test_save_and_reload(self, tmp_path):
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model
        from eulerstack.hf.auto_register import register_eulerstack_auto_classes
        from transformers import AutoModelForCausalLM

        register_eulerstack_auto_classes()
        ir = normalize_to_ir(_load_raw())
        model = compile_to_hf_model(ir, seed=0)
        out_dir = str(tmp_path / "kitchen_sink_model")
        model.save_pretrained(out_dir)
        loaded = AutoModelForCausalLM.from_pretrained(out_dir, trust_remote_code=True)

        # Deterministic forward must match.
        vocab = int(model.config.vocab_size)
        ids = torch.randint(0, vocab, (1, 10))
        model.eval()
        loaded.eval()
        with torch.no_grad():
            o1 = model(ids).logits
            o2 = loaded(ids).logits
        assert torch.allclose(o1, o2, atol=1e-5), \
            "reload forward diverges from original"

        # v1_extensions metadata must round-trip.
        ext = getattr(loaded.config, "v1_extensions", {}) or {}
        assert "execution_modes" in ext, "execution_modes lost on reload"
        assert any(
            k.get("kind") == "integrator" and k.get("integrator_type") == "ode_rk4"
            for k in ext.get("schedule_kinds", [])
        ), "ode_rk4 not round-tripped"


class _ToyLM(Dataset):
    def __init__(self, vocab_size: int, seq_len: int, n_samples: int, seed: int = 0):
        g = torch.Generator().manual_seed(seed)
        self.ids = torch.randint(0, vocab_size, (n_samples, seq_len), generator=g)

    def __len__(self):
        return self.ids.size(0)

    def __getitem__(self, i):
        x = self.ids[i]
        return {"input_ids": x, "labels": x.clone()}


class TestKitchenSinkHFTraining:
    """RED 4: real HF training loop on the exported model must descend loss.

    This is the capstone: YAML-spec → HF model → train → loss goes down.
    If this test passes with every v1 primitive combined in one spec,
    the runtime maturity claim is real.
    """

    @pytest.mark.parametrize("with_ttt_plugin", [False, True])
    def test_loss_descends_after_reload(self, tmp_path, with_ttt_plugin):
        if with_ttt_plugin:
            import eulerstack.plugins.ttt  # noqa: F401 — register TTT runtime

        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model
        from eulerstack.hf.auto_register import register_eulerstack_auto_classes
        from transformers import AutoModelForCausalLM

        register_eulerstack_auto_classes()
        ir = normalize_to_ir(_load_raw())
        model = compile_to_hf_model(ir, seed=0)
        out_dir = str(tmp_path / ("ks_plugin" if with_ttt_plugin else "ks_core"))
        model.save_pretrained(out_dir)
        reloaded = AutoModelForCausalLM.from_pretrained(out_dir, trust_remote_code=True)

        vocab = int(reloaded.config.vocab_size)
        ds = _ToyLM(vocab_size=vocab, seq_len=16, n_samples=4, seed=0)
        dl = DataLoader(ds, batch_size=2, shuffle=True, drop_last=True)
        opt = torch.optim.AdamW(reloaded.parameters(), lr=3e-3)

        torch.manual_seed(0)
        reloaded.train()
        first = None
        last = None
        steps = 0
        max_steps = 25
        while steps < max_steps:
            for batch in dl:
                if steps >= max_steps:
                    break
                out = reloaded(
                    input_ids=batch["input_ids"], labels=batch["labels"]
                )
                loss = out.loss
                if steps == 0:
                    first = float(loss.item())
                opt.zero_grad()
                loss.backward()
                opt.step()
                last = float(loss.item())
                steps += 1

        assert first is not None and last is not None
        # Loose tolerance — this is a kitchen-sink model with many new
        # primitives interacting; we only require monotone descent in the
        # coarse sense.
        assert last < first, (
            f"kitchen-sink loss failed to descend "
            f"(plugin={with_ttt_plugin}): {first:.3f} -> {last:.3f}"
        )
