# tests/test_version.py
"""Package-version contract tests.

The installed package must expose ``eulerstack.__version__`` and the
``eulerstack --version`` CLI must agree with it. Both read from the
package metadata (pyproject.toml), so there is only one source of truth.
"""
from __future__ import annotations

import pathlib
import re
import tomllib

import pytest
from click.testing import CliRunner


# ── pyproject metadata is the single source of truth ────────────────

_ROOT = pathlib.Path(__file__).resolve().parent.parent
_PYPROJECT = _ROOT / "pyproject.toml"


def _pyproject_version() -> str:
    data = tomllib.loads(_PYPROJECT.read_text())
    return str(data["project"]["version"])


# ── Package-level contract ──────────────────────────────────────────


class TestPackageVersion:
    def test_dunder_version_exists(self):
        import eulerstack

        assert hasattr(eulerstack, "__version__"), (
            "eulerstack.__version__ missing — users expect "
            "`import eulerstack; eulerstack.__version__` to work"
        )

    def test_dunder_version_is_non_empty_string(self):
        from eulerstack import __version__

        assert isinstance(__version__, str)
        assert __version__.strip() != ""

    def test_dunder_version_matches_pyproject(self):
        """pyproject.toml must be the single source of truth."""
        from eulerstack import __version__

        # In an editable install, importlib.metadata reads .dist-info
        # generated from pyproject.toml. If the two disagree, the
        # install is stale (need to re-run `pip install -e .`).
        assert __version__ == _pyproject_version(), (
            f"eulerstack.__version__={__version__!r} but "
            f"pyproject.toml version={_pyproject_version()!r}. "
            f"Re-run `pip install -e .` to re-generate .dist-info."
        )

    def test_version_looks_like_semver(self):
        """Basic semver shape: MAJOR.MINOR.PATCH with optional suffix."""
        from eulerstack import __version__

        # Accept `0.3.0`, `0.3.0a1`, `0.3.0.post1`, `0.3.0+dev` etc.
        assert re.match(r"^\d+\.\d+(\.\d+)?([-.+a-zA-Z0-9]*)$", __version__), (
            f"Version {__version__!r} does not look like a semver string"
        )


# ── CLI --version contract ──────────────────────────────────────────


class TestCLIVersion:
    def test_cli_version_flag_exits_zero(self):
        from eulerstack.cli.main import build_cli
        runner = CliRunner()
        result = runner.invoke(build_cli(), ["--version"])
        assert result.exit_code == 0

    def test_cli_version_matches_package_version(self):
        """`eulerstack --version` must print the same version as
        `eulerstack.__version__`. No drift between CLI-hardcoded and
        package-metadata versions.
        """
        from eulerstack import __version__
        from eulerstack.cli.main import build_cli

        runner = CliRunner()
        result = runner.invoke(build_cli(), ["--version"])
        assert __version__ in result.output, (
            f"`eulerstack --version` output ({result.output!r}) does not "
            f"contain eulerstack.__version__={__version__!r}"
        )
