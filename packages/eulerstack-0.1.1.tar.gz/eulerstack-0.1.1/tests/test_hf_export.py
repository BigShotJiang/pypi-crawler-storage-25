# tests/test_hf_export.py
"""Tests for YAML -> IR -> HF model export -> from_pretrained roundtrip.

This is the critical path: eulerstack compile must produce a directory that
transformers.AutoModelForCausalLM.from_pretrained() can load.
"""
from __future__ import annotations

import json
import os
import pytest
import yaml

from eulerstack.ir.normalizer import normalize_to_ir


FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "docs", "fixtures")
VALID_DIR = os.path.join(FIXTURES_DIR, "valid_yamls")


def _load(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


class TestCompileToHFConfig:
    """compile_to_hf_config() must produce an EulerStackConfig from IR."""

    def test_llama_like_produces_config(self):
        from eulerstack.compiler.compile import compile_to_hf_config
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        cfg = compile_to_hf_config(ir)
        assert cfg.model_type == "eulerstack"
        assert cfg.d_model == 256
        assert cfg.n_layers == 4
        assert cfg.vocab_size == 32000

    def test_hybrid_produces_config(self):
        from eulerstack.compiler.compile import compile_to_hf_config
        raw = _load(os.path.join(VALID_DIR, "hybrid_mixed.yml"))
        ir = normalize_to_ir(raw)
        cfg = compile_to_hf_config(ir)
        assert cfg.n_layers == 4

    def test_moe_produces_config(self):
        from eulerstack.compiler.compile import compile_to_hf_config
        raw = _load(os.path.join(VALID_DIR, "moe_model.yml"))
        ir = normalize_to_ir(raw)
        cfg = compile_to_hf_config(ir)
        assert cfg.routing["moe"]["enabled"] is True


class TestCompileToHFModel:
    """compile_to_hf_model() must produce an EulerStackForCausalLM."""

    def test_llama_like_builds_model(self):
        from eulerstack.compiler.compile import compile_to_hf_model
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir)
        assert hasattr(model, "lm_head")
        assert hasattr(model, "eulerstack")
        total = sum(p.numel() for p in model.parameters())
        assert total > 0

    def test_model_forward_pass(self):
        import torch
        from eulerstack.compiler.compile import compile_to_hf_model
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir)
        model.eval()
        ids = torch.randint(0, ir.model.vocab_size, (1, 16))
        with torch.no_grad():
            out = model(ids)
        assert out.logits.shape == (1, 16, ir.model.vocab_size)


class TestSavePretrained:
    """save_pretrained must create a valid HF model directory."""

    def test_save_creates_config_json(self, tmp_path):
        from eulerstack.compiler.compile import compile_to_hf_model
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir)

        out_dir = str(tmp_path / "my_model")
        model.save_pretrained(out_dir)

        assert os.path.exists(os.path.join(out_dir, "config.json"))
        with open(os.path.join(out_dir, "config.json")) as f:
            cfg_data = json.load(f)
        assert cfg_data["model_type"] == "eulerstack"

    def test_save_creates_model_weights(self, tmp_path):
        from eulerstack.compiler.compile import compile_to_hf_model
        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir)

        out_dir = str(tmp_path / "my_model")
        model.save_pretrained(out_dir)

        # Either safetensors or pytorch_model.bin
        has_weights = (
            os.path.exists(os.path.join(out_dir, "model.safetensors"))
            or os.path.exists(os.path.join(out_dir, "pytorch_model.bin"))
        )
        assert has_weights, f"No weight file in {os.listdir(out_dir)}"


class TestFromPretrainedRoundtrip:
    """The critical roundtrip: save -> load -> forward must work."""

    def test_roundtrip_load(self, tmp_path):
        import torch
        from eulerstack.compiler.compile import compile_to_hf_model
        from eulerstack.hf.auto_register import register_eulerstack_auto_classes
        from transformers import AutoModelForCausalLM

        register_eulerstack_auto_classes()

        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir)

        out_dir = str(tmp_path / "my_model")
        model.save_pretrained(out_dir)

        # Load back
        loaded = AutoModelForCausalLM.from_pretrained(out_dir, trust_remote_code=True)
        assert loaded.config.model_type == "eulerstack"
        assert loaded.config.d_model == ir.model.d_model

        # Forward pass
        ids = torch.randint(0, ir.model.vocab_size, (1, 8))
        with torch.no_grad():
            out = loaded(ids)
        assert out.logits.shape == (1, 8, ir.model.vocab_size)

    def test_roundtrip_weights_match(self, tmp_path):
        import torch
        from eulerstack.compiler.compile import compile_to_hf_model
        from eulerstack.hf.auto_register import register_eulerstack_auto_classes
        from transformers import AutoModelForCausalLM

        register_eulerstack_auto_classes()

        raw = _load(os.path.join(VALID_DIR, "llama_like.yml"))
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=42)

        out_dir = str(tmp_path / "my_model")
        model.save_pretrained(out_dir)

        loaded = AutoModelForCausalLM.from_pretrained(out_dir, trust_remote_code=True)

        # Weights should be identical
        for (n1, p1), (n2, p2) in zip(
            sorted(model.named_parameters()), sorted(loaded.named_parameters())
        ):
            assert n1 == n2, f"Param name mismatch: {n1} vs {n2}"
            assert torch.equal(p1, p2), f"Weights differ for {n1}"


# ── Phase C: Tier-3 presets save/load/forward round-trip ──────────────────


_PRESETS_DIR = os.path.join(os.path.dirname(__file__), "..", "configs", "presets")


def _tiny_override_for_forward(raw: dict) -> dict:
    """Shrink a 200M preset to forward-testable size while preserving the
    primitive under test. Keeps mixer layout / new fields untouched.
    """
    raw = dict(raw)
    raw["model"] = dict(raw["model"])
    raw["model"]["d_model"] = 64
    raw["model"]["n_heads"] = 4
    raw["model"]["n_kv_heads"] = 2
    raw["model"]["vocab_size"] = 512
    raw["model"]["max_seq_len"] = 128
    raw["model"].pop("target_params", None)
    # Shrink any attention.latent_dim proportionally.
    for t in raw.get("layer_templates", {}).values():
        mixer = (t or {}).get("mixer", {})
        attn = mixer.get("attention") or {}
        if "latent_dim" in attn and attn["latent_dim"]:
            attn["latent_dim"] = 32
    # Shrink memory.params.hidden if present.
    for t in raw.get("layer_templates", {}).values():
        mem = (t or {}).get("memory")
        if mem and "params" in mem and mem["params"]:
            mem["params"]["hidden"] = 64
    # Shrink schedule to 2 layers total per entry.
    shrunk_schedule = []
    for se in raw["layer_schedule"]:
        if "parallel" in se:
            shrunk = {"parallel": [], "merge": se.get("merge", {"type": "concat"})}
            for s in se["parallel"]:
                body = [{"template": b["template"], "repeat": 1} for b in s["body"]]
                shrunk["parallel"].append({"stream": s["stream"], "body": body})
            shrunk_schedule.append(shrunk)
        elif "integrator" in se:
            shrunk_schedule.append(se)  # integrator keeps its shape
        else:
            shrunk_schedule.append({**se, "repeat": 2})
    raw["layer_schedule"] = shrunk_schedule
    return raw


class TestV1Tier3PresetsRoundtrip:
    """Each Phase B primitive-demoing arch_* preset must (a) compile, (b) save,
    (c) load via AutoModelForCausalLM, and (d) run one forward pass.

    For primitives whose runtime is not yet implemented, the compiler falls
    back to an equivalent standard block (documented in compile_to_hf); the
    original spec metadata is preserved in config.v1_extensions.

    These presets were previously named `v1_*_200m`; they have been
    reclassified into the arch_advanced_* / arch_expert_* educational
    tiers at ~1.2–1.5B scale to match their peers.
    """

    TIER3_PRESETS = [
        "arch_advanced_mla.yml",
        "arch_advanced_mod.yml",
        "arch_expert_reasoning_r1.yml",
        "arch_expert_titans_memory.yml",
        "arch_expert_dual_stream.yml",
    ]

    @pytest.mark.parametrize("name", TIER3_PRESETS)
    def test_compile_to_hf_config(self, name):
        from eulerstack.compiler.compile import compile_to_hf_config
        raw = _load(os.path.join(_PRESETS_DIR, name))
        ir = normalize_to_ir(raw)
        cfg = compile_to_hf_config(ir)
        assert cfg.model_type == "eulerstack"
        # v1_extensions should exist when the preset uses a B-phase primitive
        # beyond the base attention stack (all 5 of these do in some form).
        assert isinstance(cfg.v1_extensions, dict)

    @pytest.mark.parametrize("name", TIER3_PRESETS)
    def test_compile_save_load_forward(self, name, tmp_path):
        import torch
        from eulerstack.compiler.compile import compile_to_hf_model
        from eulerstack.hf.auto_register import register_eulerstack_auto_classes
        from transformers import AutoModelForCausalLM

        register_eulerstack_auto_classes()

        raw = _tiny_override_for_forward(_load(os.path.join(_PRESETS_DIR, name)))
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=42)

        out_dir = str(tmp_path / "tier3_model")
        model.save_pretrained(out_dir)

        loaded = AutoModelForCausalLM.from_pretrained(out_dir, trust_remote_code=True)
        assert loaded.config.model_type == "eulerstack"

        ids = torch.randint(0, ir.model.vocab_size, (1, 8))
        with torch.no_grad():
            out = loaded(ids)
        assert out.logits.shape == (1, 8, ir.model.vocab_size)
        # Sanity: no NaN in logits
        assert not torch.isnan(out.logits).any()

    def test_r1_execution_modes_preserved(self, tmp_path):
        """Phase B5: execution_modes + transition must round-trip via config."""
        import json
        from eulerstack.compiler.compile import compile_to_hf_model

        raw = _tiny_override_for_forward(_load(os.path.join(_PRESETS_DIR,
                                                             "arch_expert_reasoning_r1.yml")))
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=42)
        out_dir = str(tmp_path / "r1_roundtrip")
        model.save_pretrained(out_dir)

        with open(os.path.join(out_dir, "config.json")) as f:
            cfg_data = json.load(f)
        ext = cfg_data.get("v1_extensions", {})
        assert "execution_modes" in ext
        names = [m["name"] for m in ext["execution_modes"]]
        assert names == ["think", "answer"]
        assert ext["transition"]["type"] == "special_token"
        assert ext["transition"]["token"] == "<think_end>"

    def test_dual_stream_schedule_kinds_preserved(self, tmp_path):
        """Phase B3.2: parallel schedule kind must be in v1_extensions."""
        import json
        from eulerstack.compiler.compile import compile_to_hf_model

        raw = _tiny_override_for_forward(_load(os.path.join(_PRESETS_DIR,
                                                             "arch_expert_dual_stream.yml")))
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=42)
        out_dir = str(tmp_path / "dual_roundtrip")
        model.save_pretrained(out_dir)

        with open(os.path.join(out_dir, "config.json")) as f:
            cfg_data = json.load(f)
        kinds = cfg_data["v1_extensions"].get("schedule_kinds", [])
        assert any(k["kind"] == "parallel" for k in kinds)

    def test_mod_depth_gating_preserved(self, tmp_path):
        """Phase B3.1: depth_gating must be in v1_extensions.schedule_kinds."""
        import json
        from eulerstack.compiler.compile import compile_to_hf_model

        raw = _tiny_override_for_forward(_load(os.path.join(_PRESETS_DIR,
                                                             "arch_advanced_mod.yml")))
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=42)
        out_dir = str(tmp_path / "mod_roundtrip")
        model.save_pretrained(out_dir)

        with open(os.path.join(out_dir, "config.json")) as f:
            cfg_data = json.load(f)
        kinds = cfg_data["v1_extensions"].get("schedule_kinds", [])
        assert any("depth_gating" in k for k in kinds
                    if k.get("kind") == "plain")

    def test_titans_memory_in_stack(self, tmp_path):
        """Phase B4.1: memory module must be preserved in stack pattern."""
        import json
        from eulerstack.compiler.compile import compile_to_hf_model

        raw = _tiny_override_for_forward(_load(os.path.join(_PRESETS_DIR,
                                                             "arch_expert_titans_memory.yml")))
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=42)
        out_dir = str(tmp_path / "titans_roundtrip")
        model.save_pretrained(out_dir)

        with open(os.path.join(out_dir, "config.json")) as f:
            cfg_data = json.load(f)
        pattern = cfg_data["stack"]["pattern"]
        assert any("memory" in e.get("_v1_extras", {}) for e in pattern), (
            "memory module metadata missing from stack pattern"
        )

    def test_mla_latent_dim_preserved(self, tmp_path):
        """Phase B2.1: MLA latent_dim must round-trip via _v1_extras."""
        import json
        from eulerstack.compiler.compile import compile_to_hf_model

        raw = _tiny_override_for_forward(_load(os.path.join(_PRESETS_DIR,
                                                             "arch_advanced_mla.yml")))
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=42)
        out_dir = str(tmp_path / "mla_roundtrip")
        model.save_pretrained(out_dir)

        with open(os.path.join(out_dir, "config.json")) as f:
            cfg_data = json.load(f)
        pattern = cfg_data["stack"]["pattern"]
        assert any(
            "attention_latent_dim" in e.get("_v1_extras", {})
            for e in pattern
        ), "attention_latent_dim missing from stack pattern"
