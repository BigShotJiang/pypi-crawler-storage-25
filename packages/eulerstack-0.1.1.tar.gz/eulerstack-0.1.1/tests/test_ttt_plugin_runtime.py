# tests/test_ttt_plugin_runtime.py
"""TTT plugin runtime (Phase B2.3, plugin reference implementation).

Reference: Sun et al. 2024, "Learning to (Learn at Test Time): RNNs
with Expressive Hidden States". The TTT layer maintains a small inner
network (MLP or linear) whose parameters evolve per-token via inner
gradient steps — i.e. a learned RNN whose hidden state is itself a
neural network.

Common-prompt §7: TTT is a plugin-grade primitive (non-trivial PyTorch
surgery: inner-optim, explicit grad during forward). Core ships a
fallback that treats the layer as Mamba. The plugin upgrades the
fallback to the real TTT via the plugin registry.

Plugin package layout (reference):
    eulerstack/plugins/ttt/
        __init__.py    # registers itself on import
        block.py       # TTTBlock nn.Module

Contract:
    - The plugin registers a builder under ``mixer_kind="ttt_layer"``.
    - Importing ``eulerstack.plugins.ttt`` populates the registry.
    - Core modeling picks up the plugin when the registry has the kind.
    - Without plugin import, the fallback remains active.
"""
from __future__ import annotations

import pytest
import torch
import torch.nn as nn


@pytest.fixture
def empty_registry():
    """Context manager providing a temporarily empty plugin registry.

    Python's import cache prevents plugin ``__init__`` from re-running,
    so we save/restore the registry contents rather than re-import the
    plugin module.
    """
    from eulerstack.plugins.registry import get_plugin_registry
    reg = get_plugin_registry()
    saved_mixers = dict(reg._mixers)
    saved_mems = dict(reg._memories)
    reg._mixers.clear()
    reg._memories.clear()
    yield reg
    reg._mixers = saved_mixers
    reg._memories = saved_mems


class TestTTTBlockUnit:
    """Unit tests on the stand-alone TTTBlock."""

    def test_ttt_block_imports(self):
        from eulerstack.plugins.ttt.block import TTTBlock  # noqa: F401

    def test_forward_shape(self):
        from eulerstack.plugins.ttt.block import TTTBlock

        blk = TTTBlock(d_model=32, n_heads=4, inner_hidden=32,
                       inner_steps_per_token=1, inner_lr=0.01)
        x = torch.randn(1, 8, 32)
        # Backbone convention: returns (out, past, aux)
        out, past, aux = blk(x)
        assert out.shape == x.shape
        assert past is None

    def test_inner_state_evolves_across_tokens(self):
        """The defining property of TTT: inner state is updated per-token."""
        from eulerstack.plugins.ttt.block import TTTBlock

        blk = TTTBlock(d_model=16, n_heads=2, inner_hidden=16,
                       inner_steps_per_token=1, inner_lr=0.1)
        blk.eval()
        x = torch.randn(1, 6, 16)
        blk(x)
        trajectory = blk.last_inner_state_trajectory
        assert trajectory is not None
        # Inner state at step 0 vs step T-1 must differ (it learned).
        diff = (trajectory[0] - trajectory[-1]).abs().max()
        assert diff.item() > 1e-8, \
            f"TTT inner state did not evolve across tokens (max-diff {diff.item()})"

    def test_backward_through_outer_parameters_works(self):
        """Outer (non-inner) params receive grads from standard training."""
        from eulerstack.plugins.ttt.block import TTTBlock

        blk = TTTBlock(d_model=16, n_heads=2, inner_hidden=16,
                       inner_steps_per_token=1, inner_lr=0.01)
        x = torch.randn(1, 4, 16, requires_grad=True)
        out, _, _ = blk(x)
        out.sum().backward()
        outer = [p for n, p in blk.named_parameters() if "inner_net" not in n]
        assert any(p.grad is not None and p.grad.abs().sum() > 0 for p in outer)


class TestPluginRegistration:
    """Importing the plugin must populate the registry."""

    def test_plugin_import_registers_ttt_layer(self):
        """After importing the plugin, ttt_layer is available in the registry."""
        import eulerstack.plugins.ttt  # noqa: F401  (registration on import)
        from eulerstack.plugins.registry import get_plugin_registry

        reg = get_plugin_registry()
        assert reg.has_mixer("ttt_layer")

    def test_registered_builder_constructs_ttt_block(self):
        import eulerstack.plugins.ttt  # noqa: F401
        from eulerstack.plugins.registry import get_plugin_registry
        from eulerstack.plugins.ttt.block import TTTBlock

        reg = get_plugin_registry()
        module = reg.build_mixer(
            "ttt_layer",
            d_model=16, n_heads=2, dropout=0.0,
            config={"ttt": {"inner_model": {"type": "mlp", "hidden": 16},
                             "inner_optimizer": "sgd",
                             "inner_lr": 0.01,
                             "inner_steps_per_token": 1}},
        )
        assert isinstance(module, TTTBlock)


class TestCoreFallbackWithoutPlugin:
    """Without plugin import, core falls back to mamba as before."""

    def test_ttt_spec_compiles_without_plugin(self, empty_registry):
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model

        raw = {
            "schema_version": 1,
            "model": {"name": "ttt-fb", "d_model": 32, "vocab_size": 128,
                      "max_seq_len": 64, "n_heads": 4},
            "tokenizer_contract": {"type": "hf", "pretrained": "gpt2"},
            "embedding": {"type": "learned", "positional": "none"},
            "layer_templates": {
                "ttt_block": {
                    "mixer": {
                        "type": "ttt_layer",
                        "ttt": {
                            "inner_model": {"type": "mlp", "hidden": 32},
                            "inner_optimizer": "sgd",
                            "inner_lr": 0.01,
                            "inner_steps_per_token": 1,
                        },
                    },
                    "ffn": {"type": "gated_mlp"},
                }
            },
            "layer_schedule": [{"template": "ttt_block", "repeat": 2}],
            "head": {"type": "causal_lm"},
        }
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=0)
        # Without plugin import, the mixer must be the Mamba fallback.
        from eulerstack.blocks.mamba import MambaBlock
        found_mamba = any(isinstance(m, MambaBlock) for m in model.modules())
        assert found_mamba


class TestPluginUpgradesRuntime:
    """With plugin import, core instantiates the real TTT block."""

    def test_ttt_model_uses_plugin_block(self):
        import eulerstack.plugins.ttt  # noqa: F401  (register)
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model
        from eulerstack.plugins.ttt.block import TTTBlock

        raw = {
            "schema_version": 1,
            "model": {"name": "ttt-real", "d_model": 32, "vocab_size": 128,
                      "max_seq_len": 64, "n_heads": 4},
            "tokenizer_contract": {"type": "hf", "pretrained": "gpt2"},
            "embedding": {"type": "learned", "positional": "none"},
            "layer_templates": {
                "ttt_block": {
                    "mixer": {
                        "type": "ttt_layer",
                        "ttt": {
                            "inner_model": {"type": "mlp", "hidden": 32},
                            "inner_optimizer": "sgd",
                            "inner_lr": 0.01,
                            "inner_steps_per_token": 1,
                        },
                    },
                    "ffn": {"type": "gated_mlp"},
                }
            },
            "layer_schedule": [{"template": "ttt_block", "repeat": 1}],
            "head": {"type": "causal_lm"},
        }
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=0)
        found_ttt = any(isinstance(m, TTTBlock) for m in model.modules())
        assert found_ttt, "Plugin-registered TTTBlock not found in model"

    def test_ttt_model_forward_runs(self):
        import eulerstack.plugins.ttt  # noqa: F401
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model

        raw = {
            "schema_version": 1,
            "model": {"name": "ttt-fwd", "d_model": 32, "vocab_size": 128,
                      "max_seq_len": 64, "n_heads": 4},
            "tokenizer_contract": {"type": "hf", "pretrained": "gpt2"},
            "embedding": {"type": "learned", "positional": "none"},
            "layer_templates": {
                "ttt_block": {
                    "mixer": {
                        "type": "ttt_layer",
                        "ttt": {
                            "inner_model": {"type": "mlp", "hidden": 32},
                            "inner_optimizer": "sgd",
                            "inner_lr": 0.01,
                            "inner_steps_per_token": 1,
                        },
                    },
                    "ffn": {"type": "gated_mlp"},
                }
            },
            "layer_schedule": [{"template": "ttt_block", "repeat": 1}],
            "head": {"type": "causal_lm"},
        }
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=0)
        ids = torch.randint(0, 128, (1, 8))
        out = model(ids)
        assert out.logits.shape == (1, 8, 128)

    def test_ttt_model_training_decreases_loss(self):
        import eulerstack.plugins.ttt  # noqa: F401
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model

        raw = {
            "schema_version": 1,
            "model": {"name": "ttt-train", "d_model": 32, "vocab_size": 128,
                      "max_seq_len": 64, "n_heads": 4},
            "tokenizer_contract": {"type": "hf", "pretrained": "gpt2"},
            "embedding": {"type": "learned", "positional": "none"},
            "layer_templates": {
                "ttt_block": {
                    "mixer": {
                        "type": "ttt_layer",
                        "ttt": {
                            "inner_model": {"type": "mlp", "hidden": 32},
                            "inner_optimizer": "sgd",
                            "inner_lr": 0.01,
                            "inner_steps_per_token": 1,
                        },
                    },
                    "ffn": {"type": "gated_mlp"},
                }
            },
            "layer_schedule": [{"template": "ttt_block", "repeat": 1}],
            "head": {"type": "causal_lm"},
        }
        ir = normalize_to_ir(raw)
        model = compile_to_hf_model(ir, seed=0)
        opt = torch.optim.AdamW(model.parameters(), lr=3e-3)
        torch.manual_seed(0)
        ids = torch.randint(0, 128, (2, 12))
        labels = ids.clone()
        first = None
        last = None
        for step in range(30):
            out = model(input_ids=ids, labels=labels)
            loss = out.loss
            if step == 0:
                first = float(loss.item())
            opt.zero_grad()
            loss.backward()
            opt.step()
            last = float(loss.item())
        assert last < first, f"loss did not decrease: {first} -> {last}"
