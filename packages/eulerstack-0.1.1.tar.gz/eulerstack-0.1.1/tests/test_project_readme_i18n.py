"""Regression: every projects/<name>/ directory must ship README.md (English
default) AND README.ko.md (Korean mirror), both cross-linking to each other
via a "Language:" banner near the top.

Why this test exists: the project READMEs started Korean-only, then were
flipped so English is the default and Korean lives in README.ko.md. Without
a check, a new project could ship without the Korean mirror (breaking
common-prompt §6 i18n symmetry) or without the language-selector banner
(making the mirror undiscoverable).

Scope: every immediate child of projects/ that contains at least one .yml
under a configs/ subdirectory is treated as an active project.
"""
from __future__ import annotations

import pathlib

import pytest


_REPO = pathlib.Path(__file__).resolve().parent.parent
_PROJECTS = _REPO / "projects"


def _active_projects() -> list[str]:
    """Return names of directories under projects/ that look like real
    projects (contain a configs/*.yml at least). Skips __pycache__, hidden
    dirs, and empty scaffolds."""
    if not _PROJECTS.is_dir():
        return []
    out = []
    for child in sorted(_PROJECTS.iterdir()):
        if not child.is_dir() or child.name.startswith((".", "_")):
            continue
        if list((child / "configs").glob("*.yml")) or list(
            (child / "configs").rglob("*.yml")
        ):
            out.append(child.name)
    return out


@pytest.mark.parametrize("project", _active_projects())
class TestProjectHasBothLanguages:
    """Every active project ships a parallel README.md / README.ko.md pair."""

    def test_english_readme_exists(self, project: str):
        p = _PROJECTS / project / "README.md"
        assert p.is_file(), (
            f"projects/{project}/README.md missing. English is the default "
            f"README language — see projects/arch_complex_rtx3090/ for the "
            f"template."
        )

    def test_korean_readme_exists(self, project: str):
        p = _PROJECTS / project / "README.ko.md"
        assert p.is_file(), (
            f"projects/{project}/README.ko.md missing. Korean mirror is "
            f"required per common-prompt §6 i18n symmetry."
        )

    def test_english_readme_links_to_korean(self, project: str):
        body = (_PROJECTS / project / "README.md").read_text()
        # Accept any banner that names both languages and contains the
        # relative link — we don't over-constrain formatting.
        assert "README.ko.md" in body, (
            f"projects/{project}/README.md must link to README.ko.md "
            f"(language selector at the top). Example:\n"
            f"  🌐 **Language:** English · [한국어](README.ko.md)"
        )
        assert "한국어" in body or "Korean" in body, (
            f"projects/{project}/README.md language banner should name "
            f"the Korean version so readers can discover it."
        )

    def test_korean_readme_links_to_english(self, project: str):
        body = (_PROJECTS / project / "README.ko.md").read_text()
        # Allow either an explicit README.md link or the bare `[English]`
        # wrapper — the latter is the convention used in the current files.
        assert "README.md" in body or "[English]" in body, (
            f"projects/{project}/README.ko.md must link back to README.md. "
            f"Example:\n"
            f"  🌐 **Language:** [English](README.md) · 한국어"
        )
        assert "English" in body or "English" in body, (
            f"projects/{project}/README.ko.md language banner should name "
            f"the English version so readers can discover it."
        )
