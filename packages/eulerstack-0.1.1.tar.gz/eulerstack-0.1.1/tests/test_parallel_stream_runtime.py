# tests/test_parallel_stream_runtime.py
"""Tier-3 runtime tests for dual-stream parallel composition (Phase B3.2)."""
from __future__ import annotations

import pytest
import torch
import torch.nn as nn

from eulerstack.components.parallel_stream import ParallelStream


class _Linear(nn.Module):
    def __init__(self, d_model, scale=1.0):
        super().__init__()
        self.proj = nn.Linear(d_model, d_model, bias=False)
        nn.init.constant_(self.proj.weight, scale / d_model)

    def forward(self, x):
        return self.proj(x)


class TestParallelStreamMerges:
    @pytest.fixture
    def streams(self):
        return [_Linear(16, scale=1.0), _Linear(16, scale=2.0)]

    def test_add_merge_shape(self, streams):
        p = ParallelStream(streams, d_model=16, merge_type="add")
        x = torch.randn(2, 5, 16)
        y = p(x)
        assert y.shape == x.shape

    def test_add_merge_equals_sum(self, streams):
        """add: merged output must equal sum of stream outputs."""
        p = ParallelStream(streams, d_model=16, merge_type="add")
        x = torch.randn(1, 3, 16)
        y = p(x)
        expected = streams[0](x) + streams[1](x)
        assert torch.allclose(y, expected, atol=1e-6)

    def test_concat_merge_shape(self, streams):
        p = ParallelStream(streams, d_model=16, merge_type="concat")
        x = torch.randn(2, 5, 16)
        y = p(x)
        assert y.shape == x.shape   # projection back to d_model

    def test_concat_without_projection(self, streams):
        """projection=False → output dim stays at N * d_model."""
        p = ParallelStream(
            streams, d_model=16, merge_type="concat", merge_projection=False
        )
        x = torch.randn(1, 3, 16)
        y = p(x)
        assert y.shape == (1, 3, 32)

    def test_gated_merge_shape(self, streams):
        p = ParallelStream(streams, d_model=16, merge_type="gated")
        x = torch.randn(2, 5, 16)
        y = p(x)
        assert y.shape == x.shape

    def test_gated_weights_sum_to_one(self):
        """Internal gate weights must be a softmax distribution per token."""
        streams = [nn.Identity(), nn.Identity()]
        p = ParallelStream(streams, d_model=8, merge_type="gated")
        x = torch.randn(1, 4, 8)
        w = torch.softmax(p.gate(x), dim=-1)
        assert torch.allclose(w.sum(dim=-1), torch.ones(1, 4), atol=1e-5)

    def test_cross_attn_shape(self, streams):
        p = ParallelStream(
            streams, d_model=16, merge_type="cross_attn",
            from_stream="stream_0", to_stream="stream_1",
            stream_names=["stream_0", "stream_1"],
        )
        x = torch.randn(2, 5, 16)
        y = p(x)
        assert y.shape == x.shape

    def test_cross_attn_requires_from_to(self, streams):
        with pytest.raises(ValueError, match="from_stream"):
            ParallelStream(streams, d_model=16, merge_type="cross_attn")


class TestParallelStreamValidation:
    def test_rejects_invalid_merge(self):
        with pytest.raises(ValueError, match="merge_type"):
            ParallelStream(
                [nn.Identity(), nn.Identity()], d_model=8, merge_type="telepathy"
            )

    def test_requires_min_two_streams(self):
        with pytest.raises(ValueError, match="at least 2"):
            ParallelStream([nn.Identity()], d_model=8, merge_type="add")

    def test_stream_name_count_must_match(self):
        with pytest.raises(ValueError, match="stream_names"):
            ParallelStream(
                [nn.Identity(), nn.Identity()],
                d_model=8, merge_type="add",
                stream_names=["only_one"],
            )


class TestParallelBackward:
    def test_all_streams_receive_gradient(self):
        s1 = _Linear(8, scale=1.0)
        s2 = _Linear(8, scale=1.5)
        p = ParallelStream([s1, s2], d_model=8, merge_type="concat")
        x = torch.randn(1, 3, 8, requires_grad=True)
        y = p(x).sum()
        y.backward()
        assert s1.proj.weight.grad is not None
        assert s2.proj.weight.grad is not None
        assert p.merge_proj.weight.grad is not None
