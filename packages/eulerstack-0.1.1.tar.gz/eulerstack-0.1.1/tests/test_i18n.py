# tests/test_i18n.py
"""i18n unit tests — catalog coverage, language resolution, translation correctness."""
from __future__ import annotations

import pytest
from click.testing import CliRunner

from eulerstack.i18n import t, set_lang, resolve_lang, SUPPORTED_LANGS, DEFAULT_LANG
from eulerstack.i18n.translate import MissingTranslationError
from eulerstack.i18n.locales import ko, en, zh, ja, es


class TestCatalogCoverage:
    """Every language catalog must have the same keys as ko (default)."""

    def test_all_5_languages_supported(self):
        assert set(SUPPORTED_LANGS) == {"ko", "en", "zh", "ja", "es"}

    def test_default_is_ko(self):
        assert DEFAULT_LANG == "ko"

    @pytest.mark.parametrize("lang_name,mod", [
        ("en", en), ("zh", zh), ("ja", ja), ("es", es),
    ])
    def test_catalog_matches_ko(self, lang_name, mod):
        ko_keys = set(ko.MESSAGES.keys())
        mod_keys = set(mod.MESSAGES.keys())
        missing = ko_keys - mod_keys
        extra = mod_keys - ko_keys
        assert not missing, f"{lang_name} is missing keys: {missing}"
        assert not extra, f"{lang_name} has extra keys not in ko: {extra}"

    @pytest.mark.parametrize("mod", [ko, en, zh, ja, es])
    def test_no_empty_values(self, mod):
        empties = [k for k, v in mod.MESSAGES.items() if not v.strip()]
        assert not empties, f"Empty translations: {empties}"


class TestLanguageResolution:
    def test_empty_returns_default(self):
        assert resolve_lang("") == DEFAULT_LANG
        assert resolve_lang(None) == DEFAULT_LANG

    def test_unknown_returns_default(self):
        assert resolve_lang("xx") == DEFAULT_LANG

    def test_uppercase_normalized(self):
        assert resolve_lang("EN") == "en"

    def test_all_supported_resolve(self):
        for lang in SUPPORTED_LANGS:
            assert resolve_lang(lang) == lang


class TestTranslate:
    def test_format_substitution(self):
        assert t("validate.ok", lang="en", path="foo.yml") == "OK: foo.yml is valid."

    def test_korean_default(self):
        set_lang("ko")
        result = t("validate.ok", path="foo.yml")
        assert "유효한" in result

    def test_missing_key_raises(self):
        with pytest.raises(MissingTranslationError):
            t("definitely.does.not.exist", lang="en")

    def test_missing_format_var_raises(self):
        # validate.ok requires {path}; omit it.
        with pytest.raises(MissingTranslationError):
            t("validate.ok", lang="en")

    @pytest.mark.parametrize("lang", list(SUPPORTED_LANGS))
    def test_every_language_resolves_same_key(self, lang):
        # validate.ok must exist in every language and produce non-empty output
        out = t("validate.ok", lang=lang, path="x.yml")
        assert out
        assert "x.yml" in out


# ── CLI integration ──


@pytest.fixture
def runner():
    return CliRunner()


def _invoke(runner, *args):
    """Invoke CLI with a fresh build (to pick up current language)."""
    from eulerstack.cli.main import build_cli
    return runner.invoke(build_cli(), list(args))


class TestCLILang:
    def test_help_ko_default(self, runner):
        from eulerstack.cli.main import build_cli
        set_lang("ko")
        result = runner.invoke(build_cli(), ["--help"])
        assert result.exit_code == 0
        assert "모듈형 LLM 어셈블러" in result.output

    def test_help_en(self, runner):
        from eulerstack.cli.main import build_cli
        set_lang("en")
        result = runner.invoke(build_cli(), ["--help"])
        assert result.exit_code == 0
        assert "modular LLM assembler" in result.output

    def test_help_zh(self, runner):
        from eulerstack.cli.main import build_cli
        set_lang("zh")
        result = runner.invoke(build_cli(), ["--help"])
        assert result.exit_code == 0
        assert "组装器" in result.output

    def test_help_ja(self, runner):
        from eulerstack.cli.main import build_cli
        set_lang("ja")
        result = runner.invoke(build_cli(), ["--help"])
        assert result.exit_code == 0
        assert "アセンブラ" in result.output

    def test_help_es(self, runner):
        from eulerstack.cli.main import build_cli
        set_lang("es")
        result = runner.invoke(build_cli(), ["--help"])
        assert result.exit_code == 0
        assert "ensamblador modular" in result.output

    def test_lang_option_overrides(self, runner):
        """--lang en must force English output even if default is ko."""
        from eulerstack.cli.main import build_cli
        set_lang("ko")
        import os
        valid = os.path.join(os.path.dirname(__file__), "..",
                             "docs", "fixtures", "valid_yamls", "llama_like.yml")
        result = runner.invoke(build_cli(), ["--lang", "en", "validate", "--preset", valid])
        assert result.exit_code == 0
        assert "is valid" in result.output

    def test_lang_ko_default(self, runner):
        from eulerstack.cli.main import build_cli
        set_lang("ko")
        import os
        valid = os.path.join(os.path.dirname(__file__), "..",
                             "docs", "fixtures", "valid_yamls", "llama_like.yml")
        result = runner.invoke(build_cli(), ["validate", "--preset", valid])
        assert result.exit_code == 0
        assert "유효한" in result.output


class TestCLIErrorFormatPerLang:
    """Error output 3-line format must hold in every language."""

    def test_ko_error_3line(self, runner):
        from eulerstack.cli.main import build_cli
        set_lang("ko")
        result = runner.invoke(build_cli(), ["validate", "--preset", "/no/such/file.yml"])
        assert result.exit_code != 0
        assert "Fix:" in result.output
        assert "See:" in result.output
        # Korean message content
        assert "파일" in result.output or "경로" in result.output

    def test_en_error_3line(self, runner):
        from eulerstack.cli.main import build_cli
        set_lang("en")
        result = runner.invoke(build_cli(), ["--lang", "en", "validate",
                                             "--preset", "/no/such/file.yml"])
        assert result.exit_code != 0
        assert "Fix:" in result.output
        assert "See:" in result.output
        assert "file not found" in result.output


class TestCLIInterfaceIsFixed:
    """Command names and option names MUST NOT change across languages."""

    @pytest.mark.parametrize("lang", list(SUPPORTED_LANGS))
    def test_command_names_fixed(self, runner, lang):
        from eulerstack.cli.main import build_cli
        set_lang(lang)
        result = runner.invoke(build_cli(), ["--help"])
        # Core command names must appear literally (no translation of command names)
        for cmd in ("validate", "explain", "compile", "schema", "presets"):
            assert cmd in result.output, f"Command '{cmd}' missing in {lang} help"

    @pytest.mark.parametrize("lang", list(SUPPORTED_LANGS))
    def test_option_names_fixed(self, runner, lang):
        from eulerstack.cli.main import build_cli
        set_lang(lang)
        result = runner.invoke(build_cli(), ["validate", "--help"])
        # Option flag names must appear literally
        assert "--preset" in result.output
        assert "--report" in result.output
        assert "--validate-only" in result.output


class TestReportFullyTranslated:
    """Regression guard: validation report body must fully translate.

    Before this was added, `spec/report.py::format_text()` hardcoded English
    labels like 'EulerStack Validation Report', 'Schema: OK', 'Result: ...'
    so `validate --report --lang ko` leaked English into otherwise Korean output.
    """

    def _report_for(self, runner, lang, preset_name):
        import os
        from eulerstack.cli.main import build_cli
        set_lang(lang)
        preset = os.path.join(os.path.dirname(__file__), "..",
                              "docs", "fixtures", "valid_yamls", preset_name)
        return runner.invoke(build_cli(), ["--lang", lang, "validate",
                                            "--preset", preset, "--report"])

    def test_report_header_ko(self, runner):
        r = self._report_for(runner, "ko", "llama_like.yml")
        assert r.exit_code == 0
        assert "검증 리포트" in r.output, "Report header not translated in ko"
        # Must NOT leak the English header.
        assert "EulerStack Validation Report" not in r.output

    def test_report_schema_line_ko(self, runner):
        r = self._report_for(runner, "ko", "llama_like.yml")
        assert r.exit_code == 0
        # Body labels are translated. "Schema:" is part of "Schema: OK" (English)
        # for en but "Schema: OK" is kept literally because it contains a YAML-like token.
        # We just require SOME translated marker appears.
        assert "결과:" in r.output, "Result label not translated in ko"

    def test_report_header_en(self, runner):
        r = self._report_for(runner, "en", "llama_like.yml")
        assert r.exit_code == 0
        assert "EulerStack Validation Report" in r.output
        assert "Result:" in r.output

    def test_report_header_zh(self, runner):
        r = self._report_for(runner, "zh", "llama_like.yml")
        assert r.exit_code == 0
        assert "校验报告" in r.output
        assert "结果:" in r.output

    def test_report_header_ja(self, runner):
        r = self._report_for(runner, "ja", "llama_like.yml")
        assert r.exit_code == 0
        assert "検証レポート" in r.output
        assert "結果:" in r.output

    def test_report_header_es(self, runner):
        r = self._report_for(runner, "es", "llama_like.yml")
        assert r.exit_code == 0
        assert "Informe de validación" in r.output
        assert "Resultado:" in r.output


class TestPresetsListTranslated:
    """Regression guard: per-preset inline error label must translate."""

    def test_presets_show_file_label_en(self, runner):
        from eulerstack.cli.main import build_cli
        set_lang("en")
        result = runner.invoke(build_cli(),
            ["--lang", "en", "presets", "show", "llm_0p8b_simple"])
        assert result.exit_code == 0
        assert "File:" in result.output

    def test_presets_show_file_label_ko(self, runner):
        from eulerstack.cli.main import build_cli
        set_lang("ko")
        result = runner.invoke(build_cli(),
            ["--lang", "ko", "presets", "show", "llm_0p8b_simple"])
        assert result.exit_code == 0
        assert "파일:" in result.output
        # Must NOT leak the English label.
        assert "\nFile:" not in result.output


class TestValidationErrorsTranslated:
    """Regression guard: schema-helper error messages must translate.

    Covers `_check_unknown`, `_require_field`, `_check_enum`, `_check_positive_int`
    — the four helpers in spec/schema.py that produce ~70% of all validation
    errors. Before this fix, their message/fix strings were hardcoded English
    and leaked into Korean CLI output.
    """

    def test_unknown_key_error_en(self, runner):
        import os
        from eulerstack.cli.main import build_cli
        set_lang("en")
        fixture = os.path.join(os.path.dirname(__file__), "..",
                               "docs", "fixtures", "invalid_yamls", "unknown_key.yml")
        result = runner.invoke(build_cli(),
            ["--lang", "en", "validate", "--preset", fixture])
        assert result.exit_code != 0
        assert "unknown key" in result.output.lower()

    def test_unknown_key_error_ko(self, runner):
        import os
        from eulerstack.cli.main import build_cli
        set_lang("ko")
        fixture = os.path.join(os.path.dirname(__file__), "..",
                               "docs", "fixtures", "invalid_yamls", "unknown_key.yml")
        result = runner.invoke(build_cli(),
            ["--lang", "ko", "validate", "--preset", fixture])
        assert result.exit_code != 0
        assert "알 수 없는 키" in result.output, \
            f"Korean error text missing, got: {result.output!r}"

    def test_missing_field_error_ko(self, runner):
        import os
        from eulerstack.cli.main import build_cli
        set_lang("ko")
        fixture = os.path.join(os.path.dirname(__file__), "..",
                               "docs", "fixtures", "invalid_yamls", "missing_required.yml")
        result = runner.invoke(build_cli(),
            ["--lang", "ko", "validate", "--preset", fixture])
        assert result.exit_code != 0
        assert "필수 필드" in result.output

    def test_missing_field_error_ja(self, runner):
        import os
        from eulerstack.cli.main import build_cli
        set_lang("ja")
        fixture = os.path.join(os.path.dirname(__file__), "..",
                               "docs", "fixtures", "invalid_yamls", "missing_required.yml")
        result = runner.invoke(build_cli(),
            ["--lang", "ja", "validate", "--preset", fixture])
        assert result.exit_code != 0
        assert "必須フィールド" in result.output


class TestExplainOutputGoesThroughI18n:
    """Regression guard: `explain` output must not contain stray English labels.

    Before this set of keys was added, the CLI emitted `mixer:`, `ffn:`,
    `norm:`, `residual:` literally from `click.echo(f"...")`. Now those
    labels flow through `explain.template.*` i18n keys. The test pins the
    behaviour so a future accidental hardcode is caught in all 5 locales.
    """

    @pytest.mark.parametrize("lang", list(SUPPORTED_LANGS))
    def test_explain_template_labels_come_from_catalog(self, runner, lang):
        """The `explain` output must include the mixer/ffn/norm/residual
        prefixes that the i18n template defines. If somebody replaces the
        t() call with a raw f-string this test still passes — so we also
        assert the exact strings the catalog declares.
        """
        import os
        from eulerstack.cli.main import build_cli
        set_lang(lang)
        fixture = os.path.join(
            os.path.dirname(__file__), "..",
            "configs", "presets", "arch_beginner_llama.yml",
        )
        result = runner.invoke(build_cli(),
            ["--lang", lang, "explain", "--preset", fixture])
        assert result.exit_code == 0, result.output

        # All 5 locales use English domain terms for the template body —
        # exact prefixes defined in the catalog must appear verbatim.
        out = result.output
        assert "    mixer: " in out, f"{lang}: missing `    mixer: ` prefix"
        assert "    ffn: " in out, f"{lang}: missing `    ffn: ` prefix"
        assert "    norm: " in out, f"{lang}: missing `    norm: ` prefix"
        assert "    residual: " in out, f"{lang}: missing `    residual: ` prefix"

    @pytest.mark.parametrize("lang", list(SUPPORTED_LANGS))
    def test_explain_routes_through_t_not_fstring(self, lang):
        """Unit-level guard: verify the template keys exist and format
        correctly in every locale. If somebody deletes a key, every
        locale's test fails — making the regression source obvious.
        """
        rendered_mixer = t(
            "explain.template.mixer", lang=lang,
            type="attention", config="{}",
        )
        assert rendered_mixer == "    mixer: attention {}"

        rendered_ffn = t(
            "explain.template.ffn", lang=lang, type="moe",
            extra=t("explain.template.ffn_moe_extra", lang=lang, experts=8),
        )
        assert rendered_ffn == "    ffn: moe (moe: 8 experts)"

        rendered_norm = t(
            "explain.template.norm", lang=lang, type="rmsnorm", position="pre",
        )
        assert rendered_norm == "    norm: rmsnorm/pre"

        rendered_residual = t(
            "explain.template.residual", lang=lang, type="sequential",
        )
        assert rendered_residual == "    residual: sequential"


class TestReportMessagesGoThroughI18n:
    """The validation report's `Normalization failed` message and the
    reserved-namespace warning now flow through i18n. Regression-guard both.
    """

    @pytest.mark.parametrize("lang", list(SUPPORTED_LANGS))
    def test_normalization_failed_key_exists(self, lang):
        out = t("report.normalization_failed", lang=lang, detail="demo")
        assert "demo" in out
        assert out.strip()  # non-empty

    @pytest.mark.parametrize("lang", list(SUPPORTED_LANGS))
    def test_reserved_namespace_warning_key_exists(self, lang):
        # The placeholder is `reserved_key` (not `key`) so it doesn't clash
        # with t()'s own `key` positional argument.
        out = t("report.reserved_namespace_warning", lang=lang,
                path="root", reserved_key="experimental.foo")
        assert "root" in out and "experimental.foo" in out
        assert out.strip()

    def test_reserved_namespace_finding_uses_i18n(self):
        """End-to-end: the Finding.message produced by generate_report()
        must match what t() returns in the active language.
        """
        from eulerstack.spec.report import generate_report
        set_lang("ko")
        raw = {
            "schema_version": 1,
            "experimental.kitchen_sink": True,  # triggers reserved-warning
            "model": {
                "name": "demo", "d_model": 64, "vocab_size": 256,
                "max_seq_len": 128, "n_heads": 4,
            },
            "tokenizer_contract": {"type": "hf", "pretrained": "gpt2"},
            "embedding": {"type": "learned", "positional": "rope",
                          "rope_theta": 10000.0},
            "layer_templates": {
                "d": {
                    "mixer": {"type": "attention", "attention": {}},
                    "ffn": {"type": "gated_mlp"},
                },
            },
            "layer_schedule": [{"template": "d", "repeat": 2}],
            "head": {"type": "causal_lm"},
        }
        report = generate_report(raw)
        reserved = [f for f in report.findings if f.rule == "reserved_namespace"]
        assert reserved, "expected a reserved-namespace Finding"
        # The Korean catalog says '예약 네임스페이스' (never appears in English).
        assert "예약" in reserved[0].message or "reserved" in reserved[0].message.lower()
