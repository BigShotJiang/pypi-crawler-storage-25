# tests/test_depth_gate_runtime.py
"""Tier-3 runtime tests for Mixture-of-Depths depth_gate (Phase B3.1)."""
from __future__ import annotations

import pytest
import torch
import torch.nn as nn

from eulerstack.components.depth_gate import DepthGate


class _DoubleBody(nn.Module):
    """Toy body: multiply by 2 (makes routing effects visible)."""
    def forward(self, x):
        return x * 2


class TestDepthGate:
    def test_capacity_one_is_pass_through(self):
        gate = DepthGate(d_model=16, capacity=1.0)
        body = _DoubleBody()
        gate.train()
        x = torch.randn(2, 8, 16)
        y = gate(x, body)
        assert torch.allclose(y, body(x))

    def test_eval_mode_is_pass_through_through_body(self):
        """In eval mode the router is bypassed — body runs on all tokens."""
        gate = DepthGate(d_model=16, capacity=0.5)
        body = _DoubleBody()
        gate.eval()
        x = torch.randn(2, 4, 16)
        y = gate(x, body)
        assert torch.allclose(y, body(x))

    def test_training_top_k_routes_capacity_fraction(self):
        """During training with capacity<1, only capacity*T tokens receive body output."""
        torch.manual_seed(0)
        gate = DepthGate(d_model=16, capacity=0.5, router="top_k")
        body = _DoubleBody()
        gate.train()
        x = torch.randn(1, 8, 16)
        y = gate(x, body)
        # Tokens that were routed got doubled (= 2x input); others stayed at input.
        # So each token is either y==x or y==2x.
        eq_x = torch.isclose(y, x, atol=1e-6).all(dim=-1)
        eq_2x = torch.isclose(y, x * 2, atol=1e-6).all(dim=-1)
        # Each token matches exactly one of the two.
        assert (eq_x ^ eq_2x).all()
        n_routed = int(eq_2x.sum().item())
        assert n_routed == 4   # 50% of 8

    def test_rejects_bad_capacity(self):
        with pytest.raises(ValueError):
            DepthGate(d_model=16, capacity=0.0)
        with pytest.raises(ValueError):
            DepthGate(d_model=16, capacity=-0.1)
        with pytest.raises(ValueError):
            DepthGate(d_model=16, capacity=1.5)

    def test_rejects_unknown_router(self):
        with pytest.raises(ValueError, match="router"):
            DepthGate(d_model=16, router="quantum_routing")

    def test_learned_gate_shape(self):
        gate = DepthGate(d_model=16, capacity=0.5, router="learned_gate")
        body = _DoubleBody()
        gate.train()
        x = torch.randn(2, 8, 16)
        y = gate(x, body)
        assert y.shape == x.shape

    def test_learned_gate_backward(self):
        gate = DepthGate(d_model=16, capacity=0.5, router="learned_gate")
        body = nn.Linear(16, 16)
        gate.train()
        x = torch.randn(1, 4, 16, requires_grad=True)
        y = gate(x, body)
        y.sum().backward()
        assert gate.scorer.weight.grad is not None
        assert body.weight.grad is not None
