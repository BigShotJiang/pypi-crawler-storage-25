# tests/test_runtime_hf_training_e2e.py
"""End-to-end HF export + training TDD for the new runtime primitives.

This test suite is the capstone for runtime maturity:

    1. Build a model spec that exercises each primitive.
    2. ``compile_to_hf_model(ir)`` → ``EulerStackForCausalLM``.
    3. ``save_pretrained`` → ``AutoModelForCausalLM.from_pretrained``.
    4. Run short training on the **re-loaded** model.
    5. Assert loss descends.

This is the "Transformers로 export한 후에 실제 훈련이 짤게 되는지" check.
"""
from __future__ import annotations

import pytest
import torch
from torch.utils.data import Dataset, DataLoader


class _ToyLM(Dataset):
    """Tiny synthetic LM dataset — memorise a small vocabulary of patterns."""

    def __init__(self, vocab_size: int, seq_len: int, n_samples: int, seed: int = 0):
        g = torch.Generator().manual_seed(seed)
        self.ids = torch.randint(0, vocab_size, (n_samples, seq_len), generator=g)

    def __len__(self):
        return self.ids.size(0)

    def __getitem__(self, idx):
        x = self.ids[idx]
        return {"input_ids": x, "labels": x.clone()}


def _save_and_reload(model, tmp_path):
    """Save the model and reload via AutoModelForCausalLM."""
    from eulerstack.hf.auto_register import register_eulerstack_auto_classes
    from transformers import AutoModelForCausalLM

    register_eulerstack_auto_classes()
    out = str(tmp_path / "rt_model")
    model.save_pretrained(out)
    return AutoModelForCausalLM.from_pretrained(out, trust_remote_code=True)


def _train_and_measure(model, *, vocab_size: int, seq_len: int, steps: int = 25,
                        batch_size: int = 2, lr: float = 3e-3, seed: int = 0):
    """Run a short overfitting loop and return (first_loss, last_loss)."""
    torch.manual_seed(seed)
    ds = _ToyLM(vocab_size=vocab_size, seq_len=seq_len, n_samples=batch_size * 2, seed=seed)
    dl = DataLoader(ds, batch_size=batch_size, shuffle=True, drop_last=True)
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    model.train()
    first = None
    last = None
    step = 0
    while step < steps:
        for batch in dl:
            if step >= steps:
                break
            out = model(input_ids=batch["input_ids"], labels=batch["labels"])
            loss = out.loss
            if step == 0:
                first = float(loss.item())
            opt.zero_grad()
            loss.backward()
            opt.step()
            last = float(loss.item())
            step += 1
    return first, last


# ---------------------------------------------------------------------------
# ODE (core)
# ---------------------------------------------------------------------------


class TestHFExportOdeTraining:
    def _spec(self, method: str, steps: int):
        return {
            "schema_version": 1,
            "model": {
                "name": f"ode-e2e-{method}",
                "d_model": 32,
                "vocab_size": 96,
                "max_seq_len": 32,
                "n_heads": 4,
            },
            "tokenizer_contract": {"type": "hf", "pretrained": "gpt2"},
            "embedding": {"type": "learned", "positional": "rope",
                          "rope_theta": 10000.0},
            "layer_templates": {
                "refine": {
                    "mixer": {"type": "attention", "attention": {}},
                    "ffn": {"type": "gated_mlp"},
                }
            },
            "layer_schedule": [
                {"integrator": {"type": method, "steps": steps,
                                 "body": "refine", "output": "token"}}
            ],
            "head": {"type": "causal_lm"},
        }

    def _build(self, method, steps):
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model

        ir = normalize_to_ir(self._spec(method, steps))
        return compile_to_hf_model(ir, seed=0)

    def test_ode_rk4_save_load_train(self, tmp_path):
        model = self._build("ode_rk4", steps=3)
        reloaded = _save_and_reload(model, tmp_path)
        first, last = _train_and_measure(
            reloaded, vocab_size=96, seq_len=16, steps=25,
        )
        assert last is not None and first is not None
        assert last < first, f"ode_rk4 loss did not descend after reload: {first} -> {last}"

    def test_ode_euler_save_load_train(self, tmp_path):
        model = self._build("ode_euler", steps=3)
        reloaded = _save_and_reload(model, tmp_path)
        first, last = _train_and_measure(
            reloaded, vocab_size=96, seq_len=16, steps=25,
        )
        assert last < first, f"ode_euler loss did not descend after reload: {first} -> {last}"


# ---------------------------------------------------------------------------
# Titans memory (core)
# ---------------------------------------------------------------------------


class TestHFExportTitansTraining:
    def _build(self, update_at_inference: bool):
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model

        raw = {
            "schema_version": 1,
            "model": {
                "name": "titans-e2e",
                "d_model": 32,
                "vocab_size": 96,
                "max_seq_len": 32,
                "n_heads": 4,
                "n_kv_heads": 4,
            },
            "tokenizer_contract": {"type": "hf", "pretrained": "gpt2"},
            "embedding": {"type": "learned", "positional": "rope",
                          "rope_theta": 10000.0},
            "layer_templates": {
                "m": {
                    "mixer": {"type": "attention", "attention": {}},
                    "ffn": {"type": "gated_mlp"},
                    "memory": {
                        "type": "neural_memory",
                        "update_at_inference": update_at_inference,
                        "params": {"hidden": 64},
                        "inner_lr": 0.01,
                        "persistence": "session",
                    },
                }
            },
            "layer_schedule": [{"template": "m", "repeat": 2}],
            "head": {"type": "causal_lm"},
        }
        ir = normalize_to_ir(raw)
        return compile_to_hf_model(ir, seed=0)

    def test_titans_save_load_train(self, tmp_path):
        model = self._build(update_at_inference=False)
        reloaded = _save_and_reload(model, tmp_path)
        first, last = _train_and_measure(
            reloaded, vocab_size=96, seq_len=16, steps=30,
        )
        assert last < first, f"titans loss did not descend after reload: {first} -> {last}"

    def test_titans_inference_hook_works_after_reload(self, tmp_path):
        from eulerstack.components.titans_memory import TitansMemoryModule

        model = self._build(update_at_inference=True)
        reloaded = _save_and_reload(model, tmp_path)
        reloaded.eval()

        # Snapshot memory params of reloaded model.
        mems = [m for m in reloaded.modules() if isinstance(m, TitansMemoryModule)]
        assert mems, "No TitansMemoryModule after reload"
        before = {id(m): {n: p.detach().clone() for n, p in m.named_parameters()}
                  for m in mems}

        ids = torch.randint(0, 96, (1, 12))
        with torch.no_grad():
            out = reloaded(ids, output_hidden_states=True)
        losses = reloaded.step_memory_at_inference(out.hidden_states[-1])
        assert losses, "step_memory_at_inference returned empty dict"

        changed = False
        for m in mems:
            b = before[id(m)]
            a = {n: p.detach() for n, p in m.named_parameters()}
            if any(not torch.allclose(b[k], a[k]) for k in b):
                changed = True
                break
        assert changed, "inference-time update did not move memory params"


# ---------------------------------------------------------------------------
# TTT (plugin — upgraded runtime)
# ---------------------------------------------------------------------------


class TestHFExportTTTTraining:
    """TTT runtime must survive save/load when the plugin is available."""

    def _build(self):
        import eulerstack.plugins.ttt  # noqa: F401  (register)
        from eulerstack.ir.normalizer import normalize_to_ir
        from eulerstack.compiler.compile import compile_to_hf_model

        raw = {
            "schema_version": 1,
            "model": {
                "name": "ttt-e2e",
                "d_model": 32,
                "vocab_size": 96,
                "max_seq_len": 32,
                "n_heads": 4,
            },
            "tokenizer_contract": {"type": "hf", "pretrained": "gpt2"},
            "embedding": {"type": "learned", "positional": "none"},
            "layer_templates": {
                "ttt_block": {
                    "mixer": {
                        "type": "ttt_layer",
                        "ttt": {
                            "inner_model": {"type": "mlp", "hidden": 32},
                            "inner_optimizer": "sgd",
                            "inner_lr": 0.01,
                            "inner_steps_per_token": 1,
                        },
                    },
                    "ffn": {"type": "gated_mlp"},
                }
            },
            "layer_schedule": [{"template": "ttt_block", "repeat": 1}],
            "head": {"type": "causal_lm"},
        }
        ir = normalize_to_ir(raw)
        return compile_to_hf_model(ir, seed=0)

    def test_ttt_save_load_train(self, tmp_path):
        import eulerstack.plugins.ttt  # noqa: F401  (ensure registered before reload)
        from eulerstack.plugins.ttt.block import TTTBlock

        model = self._build()
        reloaded = _save_and_reload(model, tmp_path)

        # The reloaded model must retain the plugin-provided TTTBlock (the
        # plugin is still imported in this process).
        found = any(isinstance(m, TTTBlock) for m in reloaded.modules())
        assert found, "TTTBlock missing after reload — plugin wiring broke"

        first, last = _train_and_measure(
            reloaded, vocab_size=96, seq_len=12, steps=20,
        )
        assert last < first, f"ttt loss did not descend after reload: {first} -> {last}"
