# tests/test_roundtrip_spec.py
from __future__ import annotations

import os
import tempfile

from transformers import AutoConfig, AutoModelForCausalLM

from eulerstack.assembler.build import build_from_yaml
from eulerstack.assembler.export_hf import export_from_yaml_build
from eulerstack.hf.auto_register import register_eulerstack_auto_classes


def test_roundtrip_yaml_to_hf_and_back():
    # Ensure Auto classes are registered in this test process
    register_eulerstack_auto_classes(exist_ok=True)

    yaml_path = os.path.join("configs", "model", "eulerstack_32k_hybrid.yml")
    assert os.path.exists(yaml_path), f"Missing YAML: {yaml_path}"

    spec, cfg, model = build_from_yaml(yaml_path)

    with tempfile.TemporaryDirectory() as tmp:
        out_dir = os.path.join(tmp, "artifact")
        export_from_yaml_build(
            out_dir,
            yaml_path=yaml_path,
            spec=spec,
            config=cfg,
            model=model,
            tokenizer=None,
        )

        # Check exported files
        assert os.path.exists(os.path.join(out_dir, "config.json"))
        assert os.path.exists(os.path.join(out_dir, "model_spec.json"))

        # Roundtrip load via AutoConfig/AutoModel
        cfg2 = AutoConfig.from_pretrained(out_dir)
        assert getattr(cfg2, "model_type", None) == "eulerstack"

        model2 = AutoModelForCausalLM.from_pretrained(out_dir)
        assert model2.config.vocab_size == cfg.vocab_size
        assert model2.config.d_model == cfg.d_model
        assert model2.config.n_layers == cfg.n_layers
