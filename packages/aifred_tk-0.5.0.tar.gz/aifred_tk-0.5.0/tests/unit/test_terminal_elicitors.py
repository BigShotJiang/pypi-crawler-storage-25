"""Unit tests for terminal-based elicitors."""

import pytest

from aifred_tk.elicitation._models import Choice, ElicitationResult
from aifred_tk.elicitation._terminal import NumberedElicitor, _format_choice_label


class TestFormatChoiceLabel:
    @pytest.mark.parametrize(
        ("choice", "expected"),
        [
            (Choice("Alpha"), "Alpha"),
            (Choice("Alpha", description="The first"), "Alpha — The first"),
            (Choice("Alpha", example="foo"), "Alpha (e.g. foo)"),
            (Choice("Alpha", description="First", example="foo"), "Alpha — First (e.g. foo)"),
        ],
    )
    def test_formats_label(self, choice: Choice, expected: str) -> None:
        """_format_choice_label must produce the expected display string."""
        assert _format_choice_label(choice) == expected


class TestNumberedElicitor:
    def _elicit(
        self,
        monkeypatch: pytest.MonkeyPatch,
        choices: list[Choice],
        *,
        answers: list[str],
        allow_free_input: bool = False,
        context: str | None = None,
    ) -> ElicitationResult:
        answer_iter = iter(answers)
        monkeypatch.setattr("builtins.input", lambda _prompt="": next(answer_iter))
        return NumberedElicitor().elicit("Question?", choices, context, allow_free_input)

    def test_selects_first_option(self, monkeypatch: pytest.MonkeyPatch) -> None:
        result = self._elicit(
            monkeypatch,
            [Choice("Alpha"), Choice("Beta")],
            answers=["1"],
        )
        assert result.selected_index == 0
        assert result.selected_label == "Alpha"
        assert result.free_text is None
        assert not result.is_free_input

    def test_selects_second_option(self, monkeypatch: pytest.MonkeyPatch) -> None:
        result = self._elicit(
            monkeypatch,
            [Choice("Alpha"), Choice("Beta"), Choice("Gamma")],
            answers=["2"],
        )
        assert result.selected_index == 1
        assert result.selected_label == "Beta"

    def test_free_input_with_allow_free_input(self, monkeypatch: pytest.MonkeyPatch) -> None:
        result = self._elicit(
            monkeypatch,
            [Choice("Alpha"), Choice("Beta")],
            answers=["0", "my custom text"],
            allow_free_input=True,
        )
        assert result.is_free_input
        assert result.selected_index == -1
        assert result.selected_label is None
        assert result.free_text == "my custom text"

    def test_reprompts_on_invalid_then_accepts(self, monkeypatch: pytest.MonkeyPatch) -> None:
        result = self._elicit(
            monkeypatch,
            [Choice("Alpha")],
            answers=["99", "not-a-number", "1"],
        )
        assert result.selected_index == 0

    def test_free_input_not_available_unless_enabled(self, monkeypatch: pytest.MonkeyPatch) -> None:
        # "0" is invalid when allow_free_input is False → re-prompt then "1"
        result = self._elicit(
            monkeypatch,
            [Choice("Alpha")],
            answers=["0", "1"],
            allow_free_input=False,
        )
        assert result.selected_index == 0


class TestInteractiveElicitor:
    """Smoke tests for InteractiveElicitor using mocked questionary."""

    def test_returns_selected_choice(self, monkeypatch: pytest.MonkeyPatch) -> None:
        import questionary

        monkeypatch.setattr(
            questionary,
            "select",
            lambda _msg, choices: type("Q", (), {"ask": lambda self: 1})(),
        )

        from aifred_tk.elicitation._terminal import InteractiveElicitor

        result = InteractiveElicitor().elicit(
            "Pick?",
            [Choice("Alpha"), Choice("Beta"), Choice("Gamma")],
            context=None,
            allow_free_input=False,
        )
        assert result.selected_index == 1
        assert result.selected_label == "Beta"

    def test_free_input_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        import questionary

        from aifred_tk.elicitation._terminal import _FREE_SENTINEL

        monkeypatch.setattr(
            questionary,
            "select",
            lambda _msg, choices: type("Q", (), {"ask": lambda self: _FREE_SENTINEL})(),
        )
        monkeypatch.setattr(
            questionary,
            "text",
            lambda _msg: type("Q", (), {"ask": lambda self: "custom answer"})(),
        )

        from aifred_tk.elicitation._terminal import InteractiveElicitor

        result = InteractiveElicitor().elicit(
            "Pick?", [Choice("Alpha")], context=None, allow_free_input=True
        )
        assert result.is_free_input
        assert result.free_text == "custom answer"
