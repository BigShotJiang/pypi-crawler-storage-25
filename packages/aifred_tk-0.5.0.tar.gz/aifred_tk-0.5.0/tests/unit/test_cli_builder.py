"""Unit tests for the CLI command builder."""

from typing import Any

import click
import pytest
import typer
import typer.main
from pydantic import Field

from aifred_tk.cli.app import app, build_command_for_tool
from aifred_tk.core.interfaces import Tool, ToolArgs
from aifred_tk.plugins.demo.plugin import DemoEchoTool


class _StrOptArgs(ToolArgs):
    name: str = Field(..., description="A required string")
    tag: str = Field("default", description="An optional string")


class _TypedArgs(ToolArgs):
    count: int = Field(1, description="An integer")
    ratio: float = Field(0.5, description="A float")
    flag: bool = Field(False, description="A boolean flag")


class _StrOptTool(Tool):
    @property
    def tool_id(self) -> str:
        return "str_opt_tool"

    @property
    def name(self) -> str:
        return "Str Opt Tool"

    @property
    def description(self) -> str:
        return "Tool with string options."

    @property
    def args_schema(self) -> type[_StrOptArgs]:
        return _StrOptArgs

    def execute(self, args: ToolArgs) -> dict[str, Any]:
        return {}


class _TypedTool(Tool):
    @property
    def tool_id(self) -> str:
        return "typed_tool"

    @property
    def name(self) -> str:
        return "Typed Tool"

    @property
    def description(self) -> str:
        return "Tool with typed options."

    @property
    def args_schema(self) -> type[_TypedArgs]:
        return _TypedArgs

    def execute(self, args: ToolArgs) -> dict[str, Any]:
        return {}


class TestBuildCommandForTool:
    """Click command construction from Pydantic model fields."""

    def test_command_name_matches_tool_id(self) -> None:
        """The generated command name must equal the tool's tool_id."""
        cmd = build_command_for_tool(DemoEchoTool())
        assert cmd.name == "demo_echo"

    def test_required_field_creates_required_option(self) -> None:
        """A field with no default must map to a required Click option."""
        cmd = build_command_for_tool(_StrOptTool())
        name_param = next(p for p in cmd.params if p.name == "name")
        assert name_param.required

    def test_optional_field_creates_optional_option(self) -> None:
        """A field with a default must map to an optional Click option."""
        cmd = build_command_for_tool(_StrOptTool())
        tag_param = next(p for p in cmd.params if p.name == "tag")
        assert not tag_param.required

    @pytest.mark.parametrize(
        ("field_name", "expected_click_type", "expect_is_flag"),
        [
            ("count", click.INT, False),
            ("ratio", click.FLOAT, False),
            ("flag", None, True),
        ],
    )
    def test_typed_field_maps_to_click_type(
        self,
        field_name: str,
        expected_click_type: click.ParamType | None,
        expect_is_flag: bool,
    ) -> None:
        """Typed fields must map to the correct Click type or is_flag."""
        cmd = build_command_for_tool(_TypedTool())
        param = next(p for p in cmd.params if p.name == field_name)
        assert isinstance(param, click.Option)
        if expect_is_flag:
            assert param.is_flag
        else:
            assert param.type == expected_click_type

    def test_command_help_text_matches_tool_description(self) -> None:
        """The command help text must equal the tool description."""
        tool = DemoEchoTool()
        cmd = build_command_for_tool(tool)
        assert cmd.help == tool.description


class TestCliGroup:
    """Top-level CLI app behaviour."""

    def test_cli_is_typer_app(self) -> None:
        """The ``app`` object must be a Typer app."""
        assert isinstance(app, typer.Typer)

    def test_cli_has_config_option(self) -> None:
        """The CLI must expose a --config option."""
        cmd = typer.main.get_command(app)
        param_names = [p.name for p in cmd.params]
        assert "config" in param_names
