"""Unit tests for core LLM configuration models, resolver, and factory."""

from unittest.mock import patch

import pytest
from pydantic import ValidationError
from pydantic_ai.models import Model

from aifred_tk.core.llm import (
    AnthropicLlmConfig,
    LlmInlineSetting,
    LlmRefSetting,
    OllamaLlmConfig,
    OpenAICompatLlmConfig,
    OpenAILlmConfig,
    PluginLlmSetting,
    build_pydantic_ai_model,
    resolve_llm,
)
from aifred_tk.core.llm._config import LlmConfig
from aifred_tk.core.models import ConfigurationError


class TestOllamaLlmConfig:
    def test_defaults(self) -> None:
        cfg = OllamaLlmConfig(model="gemma4:e4b")
        assert cfg.provider == "ollama"
        assert cfg.host == "127.0.0.1"
        assert cfg.port == 11434
        assert cfg.context_size is None
        assert cfg.response_size is None

    def test_all_fields(self) -> None:
        cfg = OllamaLlmConfig(
            model="llama3.2", host="10.0.0.1", port=9999, context_size=8192, response_size=4096
        )
        assert cfg.host == "10.0.0.1"
        assert cfg.port == 9999
        assert cfg.context_size == 8192
        assert cfg.response_size == 4096

    def test_requires_model(self) -> None:
        with pytest.raises(ValidationError):
            OllamaLlmConfig()  # type: ignore[call-arg]


class TestOpenAILlmConfig:
    def test_defaults(self) -> None:
        cfg = OpenAILlmConfig(model="gpt-4o-mini")
        assert cfg.provider == "openai"
        assert cfg.api_key is None
        assert cfg.base_url is None

    def test_with_api_key(self) -> None:
        cfg = OpenAILlmConfig(model="gpt-4o", api_key="sk-test")
        assert cfg.api_key == "sk-test"

    def test_requires_model(self) -> None:
        with pytest.raises(ValidationError):
            OpenAILlmConfig()  # type: ignore[call-arg]


class TestAnthropicLlmConfig:
    def test_defaults(self) -> None:
        cfg = AnthropicLlmConfig(model="claude-sonnet-4-6")
        assert cfg.provider == "anthropic"
        assert cfg.api_key is None

    def test_requires_model(self) -> None:
        with pytest.raises(ValidationError):
            AnthropicLlmConfig()  # type: ignore[call-arg]


class TestOpenAICompatLlmConfig:
    def test_requires_base_url(self) -> None:
        with pytest.raises(ValidationError):
            OpenAICompatLlmConfig(model="phi-3")  # type: ignore[call-arg]

    def test_valid(self) -> None:
        cfg = OpenAICompatLlmConfig(model="phi-3", base_url="http://localhost:8080/v1")
        assert cfg.provider == "openai-compatible"
        assert cfg.base_url == "http://localhost:8080/v1"


class TestPluginLlmSettingParsing:
    def test_ref_setting(self) -> None:
        data = {"type": "ref", "ref": "my-model"}
        setting = _parse_plugin_setting(data)
        assert isinstance(setting, LlmRefSetting)
        assert setting.ref == "my-model"

    def test_inline_ollama_setting(self) -> None:
        data = {"type": "custom", "provider": "ollama", "model": "gemma4:e4b", "port": 11434}
        setting = _parse_plugin_setting(data)
        assert isinstance(setting, LlmInlineSetting)
        assert setting.provider == "ollama"
        assert setting.model == "gemma4:e4b"

    def test_inline_openai_setting(self) -> None:
        data = {"type": "custom", "provider": "openai", "model": "gpt-4o"}
        setting = _parse_plugin_setting(data)
        assert isinstance(setting, LlmInlineSetting)
        assert setting.provider == "openai"

    def test_invalid_type_raises(self) -> None:
        from pydantic import TypeAdapter, ValidationError

        with pytest.raises(ValidationError):
            TypeAdapter(PluginLlmSetting).validate_python({"type": "unknown"})


class TestResolveLlm:
    def _make_registry(self) -> dict[str, LlmConfig]:
        return {"my-model": OpenAILlmConfig(model="gpt-4o-mini")}

    def test_resolves_ref(self) -> None:
        setting = LlmRefSetting(ref="my-model")
        resolved = resolve_llm(setting, self._make_registry())
        assert isinstance(resolved, OpenAILlmConfig)
        assert resolved.model == "gpt-4o-mini"

    def test_raises_on_missing_ref(self) -> None:
        setting = LlmRefSetting(ref="does-not-exist")
        with pytest.raises(ConfigurationError, match="does-not-exist"):
            resolve_llm(setting, self._make_registry())

    def test_resolves_inline_ollama(self) -> None:
        setting = LlmInlineSetting(type="custom", provider="ollama", model="llama3.2")
        resolved = resolve_llm(setting, {})
        assert isinstance(resolved, OllamaLlmConfig)
        assert resolved.model == "llama3.2"

    def test_resolves_inline_openai(self) -> None:
        setting = LlmInlineSetting(type="custom", provider="openai", model="gpt-4o")
        resolved = resolve_llm(setting, {})
        assert isinstance(resolved, OpenAILlmConfig)

    def test_resolves_inline_anthropic(self) -> None:
        setting = LlmInlineSetting(
            type="custom", provider="anthropic", model="claude-haiku-4-5-20251001"
        )
        resolved = resolve_llm(setting, {})
        assert isinstance(resolved, AnthropicLlmConfig)

    def test_resolves_inline_openai_compat(self) -> None:
        setting = LlmInlineSetting(
            type="custom", provider="openai-compatible", model="phi-3", base_url="http://host/v1"
        )
        resolved = resolve_llm(setting, {})
        assert isinstance(resolved, OpenAICompatLlmConfig)
        assert resolved.base_url == "http://host/v1"

    def test_empty_registry_ref_raises(self) -> None:
        setting = LlmRefSetting(ref="any")
        with pytest.raises(ConfigurationError):
            resolve_llm(setting, {})


class TestBuildPydanticAiModel:
    def test_ollama_returns_model(self) -> None:
        config = OllamaLlmConfig(model="gemma4:e4b", host="127.0.0.1", port=11434)
        model = build_pydantic_ai_model(config)
        assert isinstance(model, Model)

    def test_openai_returns_model(self) -> None:
        import os

        config = OpenAILlmConfig(model="gpt-4o-mini")
        with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test"}):
            model = build_pydantic_ai_model(config)
        assert isinstance(model, Model)

    def test_anthropic_returns_model(self) -> None:
        import os

        config = AnthropicLlmConfig(model="claude-haiku-4-5-20251001")
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk-test"}):
            model = build_pydantic_ai_model(config)
        assert isinstance(model, Model)

    def test_openai_compat_returns_model(self) -> None:
        config = OpenAICompatLlmConfig(model="phi-3", base_url="http://localhost:8080/v1")
        model = build_pydantic_ai_model(config)
        assert isinstance(model, Model)

    def test_ollama_uses_correct_base_url(self) -> None:
        from pydantic_ai.models.openai import OpenAIModel

        config = OllamaLlmConfig(model="gemma4:e4b", host="10.0.0.5", port=9999)
        model = build_pydantic_ai_model(config)
        assert isinstance(model, OpenAIModel)


def _parse_plugin_setting(data: dict) -> PluginLlmSetting:
    from pydantic import TypeAdapter

    return TypeAdapter(PluginLlmSetting).validate_python(data)
