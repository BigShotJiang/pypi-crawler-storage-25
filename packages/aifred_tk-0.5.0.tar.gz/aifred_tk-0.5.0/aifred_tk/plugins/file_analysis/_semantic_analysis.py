"""Semantic code analysis tool using LSP symbol extraction and bottom-up LLM analysis."""

from __future__ import annotations

import ast
import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal, cast

from loguru import logger
from multilspy.multilspy_types import UnifiedSymbolInformation
from pydantic import BaseModel, Field
from pydantic_ai import Agent

from aifred_tk.core.ignore import AiIgnoreChecker
from aifred_tk.core.interfaces import Tool, ToolArgs
from aifred_tk.core.llm import LlmConfig, build_pydantic_ai_model

from ._lsp import (
    build_fqn,
    extract_source_lines,
    extract_symbols,
    resolve_workspace,
    sort_bottom_up,
    symbol_kind_name,
)
from ._symbol_agent import SymbolAnalysisResult, create_symbol_analysis_agent

_TOOL_ID = "semantic_code_analysis"


class SemanticCodeAnalysisArgs(ToolArgs):
    """Arguments accepted by :class:`SemanticCodeAnalysisTool`.

    :param file_path: Absolute or relative path to the source file to analyse.
    :param language: Programming language identifier used to select the LSP server.
    :param prompt: Analysis request applied to every symbol (max 500 characters).
    :param output_file: Optional path to write the analysis report.
    :param output_format: ``"json"`` (default) returns or writes the full structured report;
        ``"markdown"`` returns or writes a human-readable summary.
    """

    file_path: str = Field(description="Path to the source file to analyse.")
    language: str = Field(
        description=(
            "Programming language of the file. Supported values: "
            "'python', 'typescript', 'javascript', 'java', 'rust', 'go', "
            "'kotlin', 'csharp', 'ruby', 'dart'."
        )
    )
    prompt: str = Field(
        max_length=500,
        description=(
            "Analysis request applied to every symbol "
            "(e.g. 'describe what this symbol does', 'find security issues'). "
            "Maximum 500 characters."
        ),
    )
    output_file: str | None = Field(
        None,
        description="Optional path to write the analysis report. Defaults to returning inline.",
    )
    output_format: Literal["json", "markdown"] = Field(
        "json",
        description=(
            "Output format. "
            "'json' (default) returns/writes the full structured report; "
            "'markdown' returns/writes a human-readable summary."
        ),
    )
    max_retries: int = Field(
        3,
        ge=1,
        le=10,
        description="Maximum LLM call attempts per symbol before skipping it. Default 3.",
    )
    local_symbols_only: bool = Field(
        True,
        description=(
            "When True (default), only symbols whose definition resides in the analysed file "
            "are included. Set to False to include all symbols returned by the language server."
        ),
    )


class SymbolRecord(BaseModel):
    """Analysis result for a single code symbol.

    :param fqn: Fully-qualified name (container.name, or name for top-level symbols).
    :param kind: Symbol kind name (e.g. ``"Function"``, ``"Class"``).
    :param start_line: First line of the symbol (1-based).
    :param end_line: Last line of the symbol (1-based).
    :param start_col: Start column (0-based).
    :param end_col: End column (0-based).
    :param analysis: Semantic description of the symbol's behaviour.
    :param issues: Issues identified within this symbol.
    :param error: Error message when the LLM analysis failed for this symbol; ``None`` on success.
    :param children: Nested child symbols (e.g. methods inside a class), sorted by start line.
    """

    fqn: str
    kind: str
    start_line: int
    end_line: int
    start_col: int
    end_col: int
    analysis: str
    issues: list[str]
    error: str | None = Field(
        None, description="Error message when analysis failed for this symbol."
    )
    children: list[SymbolRecord] = Field(default_factory=list)


SymbolRecord.model_rebuild()


class SemanticAnalysisReport(BaseModel):
    """Full semantic analysis report for a source file.

    :param file_path: Workspace-relative path to the analysed file.
    :param language: Language identifier used for LSP.
    :param analyzed_at: UTC timestamp in ISO 8601 format.
    :param symbols: Top-level symbol records with children nested inside them, sorted by start line.
    :param issues: Deduplicated flat list of all issues found across symbols.
    :param errors: Error messages for symbols whose LLM analysis failed after all retries.
    """

    file_path: str
    language: str
    analyzed_at: str
    symbols: list[SymbolRecord]
    issues: list[str]
    errors: list[str] = Field(default_factory=list)


_BLOCK_COMMENT_RE = re.compile(r"/\*\*[\s\S]*?\*/|/\*[\s\S]*?\*/")
_LINE_DOC_RE = re.compile(r"(?:///[^\n]*\n?|//![^\n]*\n?)+")


def _is_local_symbol(sym: UnifiedSymbolInformation, file_path: Path) -> bool:
    """Return True when *sym* is defined in *file_path* (or has no location info).

    :param sym: LSP symbol to check.
    :type sym: UnifiedSymbolInformation
    :param file_path: Resolved absolute path of the file being analysed.
    :type file_path: Path
    :return: True if the symbol is local to *file_path*.
    :rtype: bool
    """
    location = sym.get("location")
    if location is None:
        return True
    abs_path = location.get("absolutePath")
    if abs_path:
        return Path(abs_path) == file_path
    uri: str = location.get("uri", "")
    if uri.startswith("file://"):
        return Path(uri[7:]) == file_path
    return True


def _extract_doc(source: str, language: str) -> str | None:
    """Return only the documentation portion of a container symbol's source.

    For Python, uses :func:`ast.get_docstring` on the first parsed node.
    For other languages, extracts leading block doc comments (``/** */``, ``/* */``)
    or line doc comments (``///``, ``//!``).  Returns ``None`` when no
    documentation is found.

    :param source: Raw source text for the symbol.
    :type source: str
    :param language: Language identifier (e.g. ``"python"``).
    :type language: str
    :return: Documentation string, or ``None``.
    :rtype: str | None
    """
    if language == "python":
        try:
            tree = ast.parse(source)
            if tree.body:
                node = tree.body[0]
                if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef, ast.ClassDef)):
                    return ast.get_docstring(node)
        except SyntaxError:
            pass
        return None
    stripped = source.lstrip()
    m = _BLOCK_COMMENT_RE.match(stripped)
    if m:
        return m.group(0)
    m = _LINE_DOC_RE.match(stripped)
    if m:
        return m.group(0).rstrip()
    return None


def _build_previously_analyzed_md(records: list[SymbolRecord]) -> str:
    if not records:
        return ""
    parts: list[str] = []
    for rec in records:
        if rec.error is None:
            parts.append(f"## `{rec.fqn}` ({rec.kind})\n{rec.analysis}")
    return "\n\n".join(parts)


def _nest_records(records: list[SymbolRecord]) -> list[SymbolRecord]:
    """Arrange a flat list of records into a tree using FQN hierarchy.

    A record whose FQN contains a dot is treated as a child of the record whose
    FQN equals the prefix before the last dot.  Records with no matching parent
    (or no dot in their FQN) become top-level entries.  Both the top-level list
    and each record's ``children`` list are sorted by ``start_line``.

    :param records: Flat list of analysed symbol records (order does not matter).
    :type records: list[SymbolRecord]
    :return: Top-level records with children populated.
    :rtype: list[SymbolRecord]
    """
    fqn_to_record = {rec.fqn: rec for rec in records}
    top_level: list[SymbolRecord] = []
    for rec in records:
        if "." in rec.fqn:
            parent_fqn = rec.fqn.rsplit(".", 1)[0]
            parent = fqn_to_record.get(parent_fqn)
            if parent is not None:
                parent.children.append(rec)
                continue
        top_level.append(rec)
    top_level.sort(key=lambda r: r.start_line)
    for rec in fqn_to_record.values():
        rec.children.sort(key=lambda r: r.start_line)
    return top_level


def _render_symbol_md(sym: SymbolRecord, depth: int) -> list[str]:
    heading = "#" * depth
    lines: list[str] = [
        f"{heading} `{sym.fqn}` ({sym.kind})",
        f"Lines {sym.start_line}–{sym.end_line}",
        "",
    ]
    if sym.error is not None:
        lines += [f"**Analysis failed:** {sym.error}", ""]
    else:
        lines += [sym.analysis, ""]
        if sym.issues:
            lines += ["**Issues:**", ""]
            for issue in sym.issues:
                lines.append(f"- {issue}")
            lines.append("")
    for child in sym.children:
        lines += _render_symbol_md(child, depth + 1)
    return lines


def _render_markdown(report: SemanticAnalysisReport) -> str:
    lines: list[str] = [
        f"# Semantic Analysis: `{report.file_path}`",
        f"Language: {report.language}  |  Analyzed at: {report.analyzed_at}",
        "",
    ]
    if report.issues:
        lines += ["## Issues", ""]
        for issue in report.issues:
            lines.append(f"- {issue}")
        lines.append("")
    if report.errors:
        lines += ["## Analysis Errors", ""]
        for err in report.errors:
            lines.append(f"- {err}")
        lines.append("")
    lines += ["## Symbols", ""]
    for sym in report.symbols:
        lines += _render_symbol_md(sym, depth=3)
    return "\n".join(lines)


class SemanticCodeAnalysisTool(Tool):
    """Analyses a source file symbol-by-symbol using LSP + LLM in bottom-up order.

    The tool queries a language server for the file's symbol list, sorts symbols
    bottom-up (leaves first), then calls an LLM agent on each symbol, accumulating
    prior analyses as markdown context. The final report contains per-symbol
    analyses, a deduplicated issue list, and a UTC timestamp.
    """

    def __init__(self, llm_config: LlmConfig) -> None:
        """Initialise with a resolved LLM configuration.

        The pydantic-ai agent is built lazily on first :meth:`execute` call.

        :param llm_config: Resolved LLM configuration for the agent.
        :type llm_config: LlmConfig
        """
        self._llm_config = llm_config
        self._agent: Agent[None, SymbolAnalysisResult] | None = None

    def _get_agent(self) -> Agent[None, SymbolAnalysisResult]:
        """Return the pydantic-ai agent, building it on first call.

        :return: Configured symbol analysis agent.
        :rtype: Agent[None, SymbolAnalysisResult]
        """
        if self._agent is None:
            self._agent = create_symbol_analysis_agent(build_pydantic_ai_model(self._llm_config))
        return self._agent

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"semantic_code_analysis"``
        :rtype: str
        """
        return _TOOL_ID

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "Semantic Code Analysis"

    @property
    def description(self) -> str:
        """Return the tool description shown in CLI help and MCP metadata.

        :return: Description string.
        :rtype: str
        """
        return (
            "Performs a bottom-up semantic analysis of a source file. "
            "Queries a language server for the file's symbol tree, then analyses each symbol "
            "with an LLM from leaves (functions, methods) to roots (classes, modules), "
            "passing prior analyses as context. Returns a structured report with per-symbol "
            "analyses, a deduplicated issue list, and a UTC timestamp."
        )

    @property
    def args_schema(self) -> type[SemanticCodeAnalysisArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`SemanticCodeAnalysisArgs` class.
        :rtype: type[SemanticCodeAnalysisArgs]
        """
        return SemanticCodeAnalysisArgs

    def execute(self, args: ToolArgs) -> dict[str, Any] | str:
        """Run bottom-up semantic analysis on a source file.

        Validates the file, resolves the LSP workspace, extracts symbols, then
        iterates bottom-up calling the LLM agent on each symbol with accumulated
        context. Returns or writes the :class:`SemanticAnalysisReport`.

        :param args: Validated :class:`SemanticCodeAnalysisArgs` instance.
        :type args: ToolArgs
        :return: Result dict with ``status`` key (``"ok"``, ``"written"``, or ``"error"``),
            or a raw markdown string when ``output_format="markdown"`` and no ``output_file``.
        :rtype: dict[str, Any] | str
        """
        analysis_args = cast(SemanticCodeAnalysisArgs, args)
        file_path = Path(analysis_args.file_path).resolve()

        if not file_path.exists():
            logger.error("File not found: {}", file_path)
            return {"status": "error", "message": f"File not found: {file_path}"}
        if not file_path.is_file():
            logger.error("Path is not a regular file: {}", file_path)
            return {"status": "error", "message": f"Path is not a regular file: {file_path}"}
        if AiIgnoreChecker.for_path(file_path).is_ignored(file_path):
            logger.warning("File is ignored by .aiignore: {}", file_path)
            return {"status": "error", "message": f"File is ignored by .aiignore: {file_path}"}

        workspace = resolve_workspace(file_path)
        logger.debug("LSP workspace resolved to: {}", workspace)
        try:
            report_path = str(file_path.relative_to(workspace))
        except ValueError:
            report_path = str(file_path)

        try:
            raw_symbols = extract_symbols(analysis_args.language, workspace, file_path)
        except Exception as exc:
            logger.error("LSP symbol extraction failed for {}: {}", file_path, exc)
            return {"status": "error", "message": f"LSP error: {exc}"}

        if analysis_args.local_symbols_only:
            raw_symbols = [s for s in raw_symbols if _is_local_symbol(s, file_path)]

        if not raw_symbols:
            return {
                "status": "error",
                "message": "No symbols found (language server returned an empty result).",
            }

        try:
            file_lines = file_path.read_text(encoding="utf-8", errors="replace").splitlines(
                keepends=True
            )
        except OSError as exc:
            logger.error("Failed to read file {}: {}", file_path, exc)
            return {"status": "error", "message": f"Failed to read file: {exc}"}

        ordered = sort_bottom_up(raw_symbols)
        container_fqns: set[str] = set()
        for sym in ordered:
            if sym.get("containerName"):
                child_fqn = build_fqn(sym["name"], sym["containerName"])
                container_fqns.add(child_fqn.rsplit(".", 1)[0])

        agent = self._get_agent()
        records: list[SymbolRecord] = []

        for sym in ordered:
            fqn = build_fqn(sym["name"], sym.get("containerName", ""))
            kind = symbol_kind_name(sym)
            sym_range = sym.get("range")

            if sym_range is not None:
                start_line = sym_range["start"]["line"] + 1
                end_line = sym_range["end"]["line"] + 1
                start_col = sym_range["start"]["character"]
                end_col = sym_range["end"]["character"]
                source = extract_source_lines(file_lines, sym_range)
            else:
                start_line = end_line = start_col = end_col = 0
                source = ""

            if fqn in container_fqns:
                display_source: str | None = _extract_doc(source, analysis_args.language)
            else:
                display_source = source

            prev_md = _build_previously_analyzed_md(records)
            user_message = (
                f"<analysis_request>\n{analysis_args.prompt}\n</analysis_request>\n\n"
                f"<symbol_to_analyze>\n"
                f"Name: {fqn}  Kind: {kind}  Lines: {start_line}-{end_line}"
                f"  Cols: {start_col}-{end_col}\n"
            )
            if display_source:
                user_message += f"<symbol_source>\n{display_source}\n</symbol_source>\n"
            user_message += "</symbol_to_analyze>"
            if prev_md:
                user_message += f"\n\n<previously_analyzed>\n{prev_md}\n</previously_analyzed>"

            logger.debug("Analysing symbol: {} ({})", fqn, kind)
            sym_result: SymbolAnalysisResult | None = None
            last_exc: Exception | None = None
            for attempt in range(analysis_args.max_retries):
                try:
                    sym_result = agent.run_sync(user_message).output
                    break
                except Exception as exc:
                    last_exc = exc
                    logger.warning(
                        "Symbol '{}' attempt {}/{} failed: {}",
                        fqn,
                        attempt + 1,
                        analysis_args.max_retries,
                        exc,
                    )

            if sym_result is None:
                error_msg = f"Symbol '{fqn}': {last_exc}"
                logger.error("All retries exhausted for symbol '{}': {}", fqn, last_exc)
                records.append(
                    SymbolRecord(
                        fqn=fqn,
                        kind=kind,
                        start_line=start_line,
                        end_line=end_line,
                        start_col=start_col,
                        end_col=end_col,
                        analysis="",
                        issues=[],
                        error=error_msg,
                    )
                )
                continue

            records.append(
                SymbolRecord(
                    fqn=fqn,
                    kind=kind,
                    start_line=start_line,
                    end_line=end_line,
                    start_col=start_col,
                    end_col=end_col,
                    analysis=sym_result.analysis,
                    issues=sym_result.issues,
                    error=None,
                )
            )

        seen: set[str] = set()
        all_issues: list[str] = []
        for rec in records:
            for issue in rec.issues:
                if issue not in seen:
                    seen.add(issue)
                    all_issues.append(issue)
        all_errors = [rec.error for rec in records if rec.error is not None]

        report = SemanticAnalysisReport(
            file_path=report_path,
            language=analysis_args.language,
            analyzed_at=datetime.now(tz=UTC).isoformat(),
            symbols=_nest_records(records),
            issues=all_issues,
            errors=all_errors,
        )
        logger.info(
            "Semantic analysis complete: {} symbol(s) analysed in {}", len(records), file_path
        )

        if analysis_args.output_file is not None:
            output_path = Path(analysis_args.output_file)
            report_dict = report.model_dump()
            written_result: dict[str, Any] = {
                "status": "written",
                "output_file": str(output_path),
                "report": report_dict,
            }
            content = (
                json.dumps(written_result, indent=2)
                if analysis_args.output_format == "json"
                else _render_markdown(report)
            )
            try:
                output_path.write_text(content, encoding="utf-8")
            except OSError as exc:
                logger.error("Failed to write output file {}: {}", output_path, exc)
                return {"status": "error", "message": f"Failed to write output file: {exc}"}
            return written_result

        if analysis_args.output_format == "markdown":
            return _render_markdown(report)
        return {"status": "ok", "report": report.model_dump()}
