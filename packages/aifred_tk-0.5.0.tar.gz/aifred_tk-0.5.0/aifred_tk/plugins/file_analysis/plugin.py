"""File analysis plugin providing the ``analyze_file`` tool.

The tool reads a file from disk, submits its contents together with a user-supplied
analysis prompt to an LLM agent, and returns the analysis result. Both the analysis
prompt and the file contents are structurally isolated from the agent's instruction
layer to mitigate prompt injection attacks.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Literal, cast

from dynaconf import Dynaconf
from loguru import logger
from pydantic import Field, TypeAdapter
from pydantic_ai import Agent

from aifred_tk.core.ignore import AiIgnoreChecker
from aifred_tk.core.interfaces import Plugin, Tool, ToolArgs
from aifred_tk.core.llm import LlmConfig, PluginLlmSetting, build_pydantic_ai_model, resolve_llm
from aifred_tk.core.models import ConfigurationError

from ._agent import create_file_analysis_agent
from ._semantic_analysis import SemanticCodeAnalysisTool

_TOOL_ID = "analyze_file"
_SEMANTIC_TOOL_ID = "semantic_code_analysis"
_MAX_FILE_BYTES = 1_048_576


class FileAnalysisArgs(ToolArgs):
    """Arguments accepted by :class:`FileAnalysisTool`.

    :param file_path: Absolute or relative path to the file to analyse.
    :param prompt: Short natural-language description of the desired analysis (max 500 chars).
    :param output_file: Optional path to write the analysis result. When ``None`` the result
        is returned directly to the caller.
    :param output_format: Format used when *output_file* is set. ``"markdown"`` (default)
        writes only the analysis text; ``"json"`` writes the full result dict as indented JSON.
    """

    file_path: str = Field(description="Path to the file to analyse.")
    prompt: str = Field(
        max_length=500,
        description=(
            "Short description of the desired analysis "
            "(e.g., 'briefly describe the functions', 'list all organisation names'). "
            "Maximum 10000 characters."
        ),
    )
    output_file: str | None = Field(
        None,
        description="Optional path to write the analysis result. Defaults to returning inline.",
    )
    output_format: Literal["markdown", "json"] = Field(
        "markdown",
        description=(
            "Format used when writing to output_file. "
            "'markdown' (default) writes only the analysis text; "
            "'json' writes the full result as indented JSON."
        ),
    )


class FileAnalysisTool(Tool):
    """Reads a file and uses an LLM agent to produce an analysis based on a user prompt.

    Both the analysis prompt and the file contents are wrapped in XML-style isolation
    markers before being forwarded to the agent, preventing the file contents from
    acting as instructions (prompt injection).
    """

    def __init__(self, llm_config: LlmConfig) -> None:
        """Initialise with a resolved LLM config.

        The pydantic-ai agent is built lazily on first :meth:`execute` call so that
        plugin registration succeeds even when no API key is present in the environment.

        :param llm_config: Resolved LLM configuration for the agent.
        :type llm_config: LlmConfig
        """
        self._llm_config = llm_config
        self._agent: Agent[None, str] | None = None

    def _get_agent(self) -> Agent[None, str]:
        """Return the pydantic-ai agent, building it on first call.

        :return: Configured file analysis agent.
        :rtype: Agent[None, str]
        """
        if self._agent is None:
            self._agent = create_file_analysis_agent(build_pydantic_ai_model(self._llm_config))
        return self._agent

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"analyze_file"``
        :rtype: str
        """
        return _TOOL_ID

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "File Analysis"

    @property
    def description(self) -> str:
        """Return the tool description shown in CLI help and MCP metadata.

        :return: Description string.
        :rtype: str
        """
        return (
            "Reads a file and uses an AI agent to analyse its contents based on a short prompt. "
            "Examples: 'briefly describe the code functions', 'list all organisation names'. "
            "The analysis result is returned to the caller or written to an optional output file."
        )

    @property
    def args_schema(self) -> type[FileAnalysisArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`FileAnalysisArgs` class.
        :rtype: type[FileAnalysisArgs]
        """
        return FileAnalysisArgs

    def execute(self, args: ToolArgs) -> dict[str, Any]:
        """Read the target file and return an LLM-generated analysis.

        Validates the file path and size, reads the contents, then submits both the
        analysis prompt and the file contents to the agent using XML isolation markers
        to prevent prompt injection. If *output_file* is set the result is persisted
        to disk; otherwise it is returned inline.

        :param args: Validated :class:`FileAnalysisArgs` instance.
        :type args: ToolArgs
        :return: Result dict with a ``status`` key: ``"ok"``, ``"written"``, or ``"error"``.
        :rtype: dict[str, Any]
        """
        analysis_args = cast(FileAnalysisArgs, args)
        file_path = Path(analysis_args.file_path)

        if not file_path.exists():
            logger.error("File not found: {}", file_path)
            return {"status": "error", "message": f"File not found: {file_path}"}

        if not file_path.is_file():
            logger.error("Path is not a regular file: {}", file_path)
            return {"status": "error", "message": f"Path is not a regular file: {file_path}"}

        if AiIgnoreChecker.for_path(file_path).is_ignored(file_path):
            logger.warning("File is ignored by .aiignore: {}", file_path)
            return {"status": "error", "message": f"File is ignored by .aiignore: {file_path}"}

        file_size = file_path.stat().st_size
        if file_size > _MAX_FILE_BYTES:
            logger.error("File exceeds size limit ({} bytes): {}", _MAX_FILE_BYTES, file_path)
            return {
                "status": "error",
                "message": (
                    f"File exceeds the {_MAX_FILE_BYTES // 1_048_576} MB size limit "
                    f"({file_size} bytes)."
                ),
            }

        try:
            file_content = file_path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.error("Failed to read file {}: {}", file_path, exc)
            return {"status": "error", "message": f"Failed to read file: {exc}"}

        user_message = (
            f"<analysis_request>\n{analysis_args.prompt}\n</analysis_request>\n\n"
            f"<file_content>\n{file_content}\n</file_content>"
        )

        logger.debug("Invoking file analysis agent for: {}", file_path)
        try:
            run_result = self._get_agent().run_sync(user_message)
        except Exception as exc:
            logger.error("Agent error while analysing {}: {}", file_path, exc)
            return {"status": "error", "message": f"Agent error: {exc}"}

        analysis: str = run_result.output.strip()
        logger.info("File analysis complete for: {}", file_path)

        if analysis_args.output_file is not None:
            output_path = Path(analysis_args.output_file)
            result: dict[str, Any] = {
                "status": "written",
                "output_file": str(output_path),
                "analysis": analysis,
            }
            content = (
                json.dumps(result, indent=2) if analysis_args.output_format == "json" else analysis
            )
            try:
                output_path.write_text(content, encoding="utf-8")
            except OSError as exc:
                logger.error("Failed to write output file {}: {}", output_path, exc)
                return {"status": "error", "message": f"Failed to write output file: {exc}"}
            return result

        return {"status": "ok", "analysis": analysis}


class FileAnalysisPlugin(Plugin):
    """Plugin that provides :class:`FileAnalysisTool` and :class:`SemanticCodeAnalysisTool`."""

    def __init__(self, analyze_file_llm: LlmConfig, semantic_analysis_llm: LlmConfig) -> None:
        """Initialise with resolved LLM configs for each tool.

        :param analyze_file_llm: LLM config for the :class:`FileAnalysisTool`.
        :type analyze_file_llm: LlmConfig
        :param semantic_analysis_llm: LLM config for the :class:`SemanticCodeAnalysisTool`.
        :type semantic_analysis_llm: LlmConfig
        """
        self._analyze_file_llm = analyze_file_llm
        self._semantic_analysis_llm = semantic_analysis_llm

    @property
    def plugin_id(self) -> str:
        """Return the unique plugin identifier.

        :return: ``"file_analysis"``
        :rtype: str
        """
        return "file_analysis"

    @property
    def name(self) -> str:
        """Return the human-readable plugin name.

        :return: Display name string.
        :rtype: str
        """
        return "File Analysis"

    def get_tools(self) -> list[Tool]:
        """Return all tools provided by this plugin.

        :return: List containing :class:`FileAnalysisTool` and :class:`SemanticCodeAnalysisTool`.
        :rtype: list[Tool]
        """
        return [
            FileAnalysisTool(self._analyze_file_llm),
            SemanticCodeAnalysisTool(self._semantic_analysis_llm),
        ]


def _resolve_tool_llm(
    tool_id: str, settings: Dynaconf, llms_registry: dict[str, LlmConfig]
) -> LlmConfig:
    """Resolve the LLM config for a single tool from settings.

    :param tool_id: Snake-case tool identifier (e.g. ``"analyze_file"``).
    :type tool_id: str
    :param settings: Active Dynaconf settings instance.
    :type settings: Dynaconf
    :param llms_registry: Pre-built registry of named LLM configs.
    :type llms_registry: dict[str, LlmConfig]
    :return: Resolved :class:`LlmConfig`.
    :rtype: LlmConfig
    :raises ConfigurationError: When the setting is missing or references an unknown name.
    """
    llm_raw = settings.get(f"TOOLS__{tool_id.upper()}__LLM")
    if not llm_raw:
        raise ConfigurationError(
            f"Missing tools.{tool_id}.llm configuration; "
            "define an LLM reference or inline definition."
        )
    llm_setting: PluginLlmSetting = TypeAdapter(PluginLlmSetting).validate_python(dict(llm_raw))
    return resolve_llm(llm_setting, llms_registry)


def create_plugin(settings: Dynaconf) -> FileAnalysisPlugin:
    """Entry point factory for the file_analysis plugin.

    Reads the ``llms`` registry and per-tool LLM settings from *settings*, resolves
    the LLM configurations, and constructs the plugin with both tools.

    :param settings: Active Dynaconf settings instance.
    :type settings: Dynaconf
    :return: Initialised :class:`FileAnalysisPlugin` instance.
    :rtype: FileAnalysisPlugin
    :raises ConfigurationError: When an LLM setting is missing or references an unknown name.
    """
    llms_data: dict[str, Any] = dict(settings.get("LLMS", {}) or {})
    llms_registry: dict[str, LlmConfig] = (
        TypeAdapter(dict[str, LlmConfig]).validate_python(llms_data) if llms_data else {}
    )

    analyze_file_llm = _resolve_tool_llm(_TOOL_ID, settings, llms_registry)
    semantic_analysis_llm = _resolve_tool_llm(_SEMANTIC_TOOL_ID, settings, llms_registry)

    logger.debug(
        "file_analysis plugin: analyze_file using {} {!r}, semantic_code_analysis using {} {!r}",
        analyze_file_llm.provider,
        analyze_file_llm.model,
        semantic_analysis_llm.provider,
        semantic_analysis_llm.model,
    )
    return FileAnalysisPlugin(analyze_file_llm, semantic_analysis_llm)
