"""LSP symbol extraction utilities using multilspy."""

from __future__ import annotations

from pathlib import Path
from typing import cast

from multilspy import SyncLanguageServer
from multilspy.multilspy_config import MultilspyConfig
from multilspy.multilspy_logger import MultilspyLogger
from multilspy.multilspy_types import Range, SymbolKind, UnifiedSymbolInformation


def resolve_workspace(file_path: Path) -> Path:
    """Walk up from *file_path* looking for a ``.git`` directory.

    :param file_path: Source file whose workspace root should be found.
    :type file_path: Path
    :return: Nearest ancestor containing ``.git``, or :func:`Path.cwd` as fallback.
    :rtype: Path
    """
    for candidate in [file_path.parent, *file_path.parent.parents]:
        if (candidate / ".git").exists():
            return candidate
    return Path.cwd()


def extract_symbols(
    language: str, workspace: Path, file_path: Path
) -> list[UnifiedSymbolInformation]:
    """Start an LSP server for *language* and return document symbols for *file_path*.

    :param language: Language identifier accepted by multilspy (e.g. ``"python"``).
    :type language: str
    :param workspace: Project root passed to the LSP server.
    :type workspace: Path
    :param file_path: Absolute path to the file to analyse.
    :type file_path: Path
    :return: Flat list of document symbols returned by the language server.
    :rtype: list[UnifiedSymbolInformation]
    :raises Exception: Re-raises any multilspy or LSP server error.
    """
    config = MultilspyConfig.from_dict({"code_language": language})
    slsp = SyncLanguageServer.create(config, MultilspyLogger(), str(workspace))
    relative_path = str(file_path.relative_to(workspace))
    with slsp.start_server():
        symbols, _ = slsp.request_document_symbols(relative_path)
    result = cast(list[UnifiedSymbolInformation], symbols)
    _infer_container_names(result)
    return result


def build_fqn(name: str, container_name: str) -> str:
    """Build a display-oriented fully-qualified name.

    :param name: Symbol's own name.
    :type name: str
    :param container_name: Immediate parent symbol name, or empty string for top-level.
    :type container_name: str
    :return: ``"container.name"`` or ``"name"`` when there is no container.
    :rtype: str
    """
    return f"{container_name}.{name}" if container_name else name


def symbol_kind_name(symbol: UnifiedSymbolInformation) -> str:
    """Return the human-readable name for a symbol's kind.

    :param symbol: Symbol whose kind should be resolved.
    :type symbol: UnifiedSymbolInformation
    :return: Kind name string (e.g. ``"Function"``).
    :rtype: str
    """
    try:
        return str(SymbolKind(symbol["kind"]).name)
    except (ValueError, KeyError):
        return str(symbol.get("kind", "Unknown"))


def extract_source_lines(file_lines: list[str], symbol_range: Range) -> str:
    """Slice source lines for a symbol's range.

    LSP ranges use 0-based line indices. The returned text includes both boundary
    lines and preserves original line endings.

    :param file_lines: File content split into lines (with line endings).
    :type file_lines: list[str]
    :param symbol_range: LSP Range with ``start`` and ``end`` positions.
    :type symbol_range: Range
    :return: Source text for the symbol.
    :rtype: str
    """
    start = symbol_range["start"]["line"]
    end = symbol_range["end"]["line"]
    return "".join(file_lines[start : end + 1])


def _symbol_span(symbol: UnifiedSymbolInformation) -> int:
    sym_range = symbol.get("range")
    if sym_range is None:
        return 0
    return int(sym_range["end"]["line"]) - int(sym_range["start"]["line"])


def _range_contains(outer: Range, inner: Range) -> bool:
    """Return True when *outer* strictly contains *inner* (inner is nested inside outer).

    :param outer: Candidate parent range.
    :type outer: Range
    :param inner: Candidate child range.
    :type inner: Range
    :return: True when outer starts at or before inner and ends at or after inner,
        but they are not identical.
    :rtype: bool
    """
    o_s = (outer["start"]["line"], outer["start"]["character"])
    o_e = (outer["end"]["line"], outer["end"]["character"])
    i_s = (inner["start"]["line"], inner["start"]["character"])
    i_e = (inner["end"]["line"], inner["end"]["character"])
    return o_s <= i_s and i_e <= o_e and (o_s, o_e) != (i_s, i_e)


def _infer_container_names(symbols: list[UnifiedSymbolInformation]) -> None:
    """Populate missing ``containerName`` fields by inferring parent from range containment.

    multilspy flattens hierarchical ``DocumentSymbol`` responses without setting
    ``containerName`` on child symbols.  This function restores parent-child
    relationships using range containment and assigns each symbol's
    ``containerName`` as its parent's full FQN, supporting arbitrary nesting depth.

    Symbols that already have a non-empty ``containerName`` are left unchanged.

    :param symbols: Flat symbol list from the LSP server (modified in-place).
    :type symbols: list[UnifiedSymbolInformation]
    """
    if not symbols or all(sym.get("containerName") for sym in symbols):
        return

    parent_of: dict[int, int] = {}
    for i, sym in enumerate(symbols):
        sym_range = sym.get("range")
        if sym_range is None:
            continue
        best: int | None = None
        best_span: float = float("inf")
        for j, candidate in enumerate(symbols):
            if i == j:
                continue
            cand_range = candidate.get("range")
            if cand_range is None:
                continue
            if _range_contains(cand_range, sym_range):
                span = float(_symbol_span(candidate))
                if span < best_span:
                    best_span = span
                    best = j
        if best is not None:
            parent_of[i] = best

    fqns: dict[int, str] = {}

    def _fqn(idx: int) -> str:
        if idx in fqns:
            return fqns[idx]
        p = parent_of.get(idx)
        name: str = symbols[idx]["name"]
        result = f"{_fqn(p)}.{name}" if p is not None else name
        fqns[idx] = result
        return result

    for i in range(len(symbols)):
        _fqn(i)

    for i, sym in enumerate(symbols):
        if not sym.get("containerName") and i in parent_of:
            sym["containerName"] = fqns[parent_of[i]]


def sort_bottom_up(symbols: list[UnifiedSymbolInformation]) -> list[UnifiedSymbolInformation]:
    """Sort symbols bottom-up: smallest line span (leaf) first, largest (parent) last.

    :param symbols: Flat list of symbols from the LSP server.
    :type symbols: list[UnifiedSymbolInformation]
    :return: Sorted copy with leaves first.
    :rtype: list[UnifiedSymbolInformation]
    """

    def _start_line(s: UnifiedSymbolInformation) -> int:
        r = s.get("range")
        return int(r["start"]["line"]) if r is not None else 0

    return sorted(symbols, key=lambda s: (_symbol_span(s), _start_line(s)))
