# Pydifact - a python edifact library
#
# Copyright (c) 2017-2024 Christian González
#
# Permission is hereby granted, free of charge, to any person obtaining a copy of
# this software and associated documentation files (the "Software"), to deal in
# the Software without restriction, including without limitation the rights to
# use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
from collections.abc import Iterator

from pydifact.exceptions import EDISyntaxError
from pydifact.token import Token
from pydifact.control.characters import Characters


class Tokenizer:
    """Convert EDI messages into tokens for parsing."""

    def __init__(self) -> None:
        super().__init__()

        # The message that we are tokenizing.
        self._message: Iterator[str] = iter("")

        self._current_chars: list[str] = []

        # The current character from the message we are dealing with.
        self._char: str | None = ""

        # bool isEscaped If the current character has been escaped.
        self.isEscaped = False

        # The control characters for the message
        self.characters: Characters | None = None

        self.token_selector: dict[str, Token.Type] = {}

        # The line number and column within the message
        # beware of the UNA header before!
        self._message_index: int = 0
        self._lineno = 0
        self._column = 0

    def get_tokens(
        self, message: str, characters: Characters | None = None
    ) -> Iterator[Token]:
        """Convert the passed message into tokens.

        Parameters:
            characters: the Control Characters to use for tokenizing.
                If omitted, use a default set.
            message: The EDI message, without the UNA header
        Returns:
            Iterator[Token]
        """

        self.characters = characters or Characters()
        self._char = None
        self._message = iter(message)
        self.read_next_char()

        self.token_selector = {
            self.characters.component_separator: Token.Type.COMPONENT_SEPARATOR,
            self.characters.data_separator: Token.Type.DATA_SEPARATOR,
            self.characters.segment_terminator: Token.Type.TERMINATOR,
        }

        while not self.end_of_message():
            yield self.get_next_token()

    def read_next_char(self) -> None:
        """Read the next character from the message.

        If the character is an escape character, set the isEscaped flag to
        True, get the one after it and store that character in the internal storage."""

        # first, get the next char.
        self._char = self.get_next_char()

        # If the last character was escaped, this one can't possibly be an escaped one.
        if self.isEscaped:
            self.isEscaped = False

        # If this is the escape character, then read the next one, store it and
        # flag it as escaped
        if self.characters and self._char == self.characters.escape_character:
            self.isEscaped = True
            self._char = self.get_next_char()

            # next char after an escape char may not be a newline
            if self._char == "\n":
                raise EDISyntaxError(
                    "Newlines after escape characters are not allowed.",
                    self._lineno,
                    self._column - 1,
                )

    def get_next_char(self) -> str | None:
        """Get the next character from the message."""
        try:
            char = next(self._message)
            self._message_index += 1
            self._column += 1
            if self._char == "\n":
                self._lineno += 1
                self._column = 0
            return char
        except StopIteration:
            return None

    def get_next_token(self) -> Token:
        """Get the next token from the message.

        Raises:
            RuntimeError: If the message ends, and the last token is not a control
                          character
        """
        # If we're not escaping this character then see if it's
        # a control character
        assert self.characters is not None

        if not self.isEscaped and self._char in self.token_selector:
            token_type = self.token_selector[self._char]
            self.store_current_char_and_read_next()
            token = Token(token_type, self.extract_stored_chars())
            if token_type == Token.Type.TERMINATOR:
                while self._char in self.characters.line_terminators:
                    self.read_next_char()
            return token

        # When message ends without a control character, raise an error
        # except for a newline.
        while not self.is_control_character():
            if self.end_of_message():
                raise EDISyntaxError("Unexpected end of EDI messages.")
            self.store_current_char_and_read_next()

        return Token(Token.Type.CONTENT, self.extract_stored_chars())

    def is_control_character(self) -> bool:
        """Check if the current character is a control character."""

        if self.isEscaped:
            return False

        return self._char in self.token_selector

    def store_current_char_and_read_next(self) -> None:
        """Store the current character and read the
        next one from the message."""

        assert self._char is not None
        self._current_chars.append(self._char)
        self.read_next_char()

    def extract_stored_chars(self) -> str:
        """Return the previously stored characters and empty the store."""

        chars = self._current_chars
        self._current_chars = []
        return "".join(chars)

    def end_of_message(self) -> bool:
        """Check if we've reached the end of the message"""
        return self._char is None

    def __str__(self) -> str:
        return "".join(self._current_chars)
