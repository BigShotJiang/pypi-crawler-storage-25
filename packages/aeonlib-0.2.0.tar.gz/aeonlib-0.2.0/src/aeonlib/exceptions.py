class ServiceNetworkError(Exception):
    pass
