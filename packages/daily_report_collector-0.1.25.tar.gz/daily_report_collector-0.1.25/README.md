# daily-report-collector

Cross-platform agent that automatically collects AI coding tool memory files and syncs them to a central [AI Daily Report](https://github.com/ddong8/daily_report) server.

## Supported AI Tools

| Tool | Data Collected |
|------|---------------|
| **Claude Code** | Conversations, memory, plans, history |
| **OpenClaw** | Sessions, identity, memory, learnings, skills |
| **Codex** | Sessions (active + archived), history, skills |
| **Antigravity** | Full conversations (via aghistory), brain plans, code snapshots |
| **Obsidian** | All markdown notes in your vault |
| **Cursor** | Agent transcripts, skills, MCP config |

## Install

```bash
pip install daily-report-collector
```

For Antigravity full conversation export:
```bash
pip install daily-report-collector[antigravity]
```

## Quick Start

```bash
# Interactive setup (first time)
daily-report-collector setup

# Or run directly
daily-report-collector run
```

The setup wizard will:
1. Detect your platform (macOS / Linux / Windows)
2. Auto-discover installed AI tools and Obsidian vaults
3. Configure the server URL and auth token
4. Optionally install as a system service (auto-start on boot)

## Commands

```bash
daily-report-collector setup      # Interactive setup wizard
daily-report-collector run        # Run in foreground
daily-report-collector install    # Install as system service
daily-report-collector start      # Start the service
daily-report-collector stop       # Stop the service
daily-report-collector status     # Show collector status
daily-report-collector uninstall  # Remove system service
```

## How It Works

1. **File Watching** — Uses `watchdog` (FSEvents on macOS, inotify on Linux, ReadDirectoryChanges on Windows) to detect file changes in real-time
2. **Parsing** — Supports Markdown, JSONL, JSON, TOML, SQLite formats
3. **Sanitization** — Automatically redacts API keys, tokens, passwords, private keys before upload
4. **Queuing** — Local SQLite queue for offline resilience (syncs when server is reachable)
5. **Syncing** — HTTP upload to server, with chunked upload for files > 2MB (tested with 37MB files)
6. **Device Identity** — Each device gets a persistent unique ID, all data tagged with device info

## Configuration

Environment variables (or set via `daily-report-collector setup`):

| Variable | Default | Description |
|----------|---------|-------------|
| `DR_SERVER_URL` | `http://localhost:8001` | Server API URL |
| `DR_SERVER_TOKEN` | | Collector auth token |
| `DR_OBSIDIAN_VAULT_PATH` | Auto-detected | Obsidian vault path |

Config file: `~/.daily-report/config.json`

## System Service

| Platform | Service Type | Config Location |
|----------|-------------|-----------------|
| macOS | LaunchAgent | `~/Library/LaunchAgents/com.dailyreport.collector.plist` |
| Linux | systemd user | `~/.config/systemd/user/daily-report-collector.service` |
| Windows | Task Scheduler | `DailyReportCollector` scheduled task |

## License

MIT
