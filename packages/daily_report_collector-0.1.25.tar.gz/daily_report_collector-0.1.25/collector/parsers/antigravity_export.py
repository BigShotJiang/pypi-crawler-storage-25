"""Antigravity conversation exporter — uses aghistory to export full conversations."""

from __future__ import annotations

import logging
import subprocess
import tempfile
from pathlib import Path

logger = logging.getLogger("collector.antigravity_export")


def export_conversations(output_dir: Path | None = None) -> list[dict]:
    """Export all Antigravity conversations using aghistory CLI.

    Requires: pip install antigravity-history
    Requires: Antigravity IDE to be running (for language server connection)

    Returns list of dicts: {path, title, size, content}
    """
    if output_dir is None:
        output_dir = Path(tempfile.mkdtemp(prefix="ag_export_"))

    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        result = subprocess.run(
            ["aghistory", "export", "--full", "-f", "md", "-o", str(output_dir)],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode != 0:
            logger.warning("aghistory export failed: %s", result.stderr[:200])
            return []
    except FileNotFoundError:
        logger.debug("aghistory not installed, skipping Antigravity conversation export")
        return []
    except subprocess.TimeoutExpired:
        logger.warning("aghistory export timed out")
        return []

    # Collect exported files
    conversations = []
    for md_file in output_dir.glob("*.md"):
        content = md_file.read_text(encoding="utf-8", errors="replace")
        conversations.append({
            "path": str(md_file),
            "title": md_file.stem,
            "size": len(content),
            "content": content,
        })

    logger.info("Exported %d Antigravity conversations via aghistory", len(conversations))
    return conversations
