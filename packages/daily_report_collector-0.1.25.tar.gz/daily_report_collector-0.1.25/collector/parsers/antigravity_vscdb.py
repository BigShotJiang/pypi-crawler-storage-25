"""Antigravity vscdb parser — extracts conversation fragments and session→workspace mapping.

Protobuf parsing based on antigravity-trajectory-extractor (MIT):
https://github.com/jijiamoer/antigravity-trajectory-extractor
"""

from __future__ import annotations

import base64
import json
import platform
import re
import sqlite3
import struct
import subprocess
from pathlib import Path
from urllib.parse import unquote


# ---------------------------------------------------------------------------
# Protobuf wire format parser (pure Python, zero deps)
# ---------------------------------------------------------------------------

def _decode_varint(data: bytes, pos: int) -> tuple[int, int]:
    result = 0
    shift = 0
    while pos < len(data):
        value = data[pos]
        result |= (value & 0x7F) << shift
        pos += 1
        if not (value & 0x80):
            return result, pos
        shift += 7
    return result, pos


def _parse_fields(data: bytes, start: int, end: int) -> list[dict]:
    fields: list[dict] = []
    cursor = start
    while cursor < end:
        try:
            tag, next_pos = _decode_varint(data, cursor)
            if tag == 0:
                cursor = next_pos
                continue
            field_number, wire_type = tag >> 3, tag & 7
            if wire_type == 0:  # varint
                value, cursor = _decode_varint(data, next_pos)
                fields.append({"fn": field_number, "type": "varint", "value": value})
            elif wire_type == 2:  # length-delimited
                size, start_pos = _decode_varint(data, next_pos)
                if size < 0 or size > end - start_pos:
                    break
                cursor = start_pos + size
                fields.append({"fn": field_number, "type": "bytes", "start": start_pos, "end": cursor})
            elif wire_type == 1:  # fixed64
                fields.append({"fn": field_number, "type": "fixed64",
                               "value": struct.unpack_from("<Q", data, next_pos)[0]})
                cursor = next_pos + 8
            elif wire_type == 5:  # fixed32
                fields.append({"fn": field_number, "type": "fixed32",
                               "value": struct.unpack_from("<I", data, next_pos)[0]})
                cursor = next_pos + 4
            else:
                break
        except Exception:
            break
    return fields


_BASE64_RE = re.compile(r"^[A-Za-z0-9+/=_-]+$")
_UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)


def _try_decode_str(data: bytes, start: int, end: int) -> str | None:
    try:
        return data[start:end].decode("utf-8")
    except Exception:
        return None


def _maybe_decode_base64(data: bytes) -> bytes | None:
    try:
        text = data.decode("ascii").strip()
    except UnicodeDecodeError:
        return None
    if len(text) < 16 or len(text) % 4 != 0 or not _BASE64_RE.fullmatch(text):
        return None
    try:
        return base64.b64decode(text, validate=True)
    except Exception:
        return None


def _walk_strings(data: bytes, max_depth: int = 5, _depth: int = 0) -> list[str]:
    """Recursively extract all UTF-8 strings from protobuf binary."""
    if _depth > max_depth:
        return []
    fields = _parse_fields(data, 0, len(data))
    strings: list[str] = []
    seen: set[str] = set()

    for field in fields:
        if field["type"] != "bytes":
            continue
        start, end = field["start"], field["end"]
        raw = data[start:end]

        text = _try_decode_str(data, start, end)
        if text is not None:
            cleaned = text.strip()
            if cleaned and cleaned not in seen:
                strings.append(cleaned)
                seen.add(cleaned)

        nested = _maybe_decode_base64(raw)
        sub = _walk_strings(nested if nested is not None else raw,
                            max_depth=max_depth, _depth=_depth + 1)
        for s in sub:
            if s not in seen:
                strings.append(s)
                seen.add(s)

    return strings


def _file_uri_to_path(uri: str) -> str:
    decoded = unquote(uri)
    if decoded.startswith("file:///"):
        path_part = decoded[8:]
        if len(path_part) > 1 and path_part[1] == ":":
            return path_part  # Windows: C:/Users/...
        return "/" + path_part  # Unix: /Users/...
    return decoded


# ---------------------------------------------------------------------------
# Session → Workspace mapping
# ---------------------------------------------------------------------------

def _get_vscdb_path() -> Path | None:
    home = Path.home()
    system = platform.system()
    if system == "Darwin":
        p = home / "Library" / "Application Support" / "Antigravity" / "User" / "globalStorage" / "state.vscdb"
    elif system == "Windows":
        import os
        appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
        p = appdata / "Antigravity" / "User" / "globalStorage" / "state.vscdb"
    else:
        p = home / ".config" / "Antigravity" / "User" / "globalStorage" / "state.vscdb"
    return p if p.exists() else None


def extract_session_workspace_map(vscdb_path: Path | None = None) -> dict[str, str]:
    """Extract session cascade_id → workspace project name mapping from vscdb.

    Parses the antigravityUnifiedStateSync.trajectorySummaries protobuf:
    - Outer: repeated { field1=cascade_id(string), field2=summary_blob(bytes) }
    - summary_blob: base64 → inner protobuf containing file:// workspace URIs

    Returns: {"cascade_id": "project_name", ...}
    """
    if vscdb_path is None:
        vscdb_path = _get_vscdb_path()
    if vscdb_path is None:
        return {}

    skip_dirs = {"users", "user", "home", "desktop", "dev", "documents",
                 "python", "projects", "src", "code", "admin", "appdata",
                 "roaming", "local"}

    session_map: dict[str, str] = {}

    try:
        conn = sqlite3.connect(f"file:{vscdb_path}?mode=ro", uri=True, timeout=5)
        for key in [
            "antigravityUnifiedStateSync.trajectorySummaries",
            "unifiedStateSync.trajectorySummaries",
        ]:
            row = conn.execute("SELECT value FROM ItemTable WHERE key = ?", (key,)).fetchone()
            if not row:
                continue

            blob = base64.b64decode(row[0])

            # Parse outer protobuf: each field 1 = one trajectory entry
            for field in _parse_fields(blob, 0, len(blob)):
                if field["fn"] != 1 or field["type"] != "bytes":
                    continue

                entry_data = blob[field["start"]:field["end"]]
                entry_fields = _parse_fields(entry_data, 0, len(entry_data))

                cascade_id = ""
                summary_blob = b""

                for ef in entry_fields:
                    if ef["fn"] == 1 and ef["type"] == "bytes" and not cascade_id:
                        cascade_id = (_try_decode_str(entry_data, ef["start"], ef["end"]) or "").strip()
                    elif ef["fn"] == 2 and ef["type"] == "bytes" and not summary_blob:
                        summary_blob = entry_data[ef["start"]:ef["end"]]

                if not cascade_id or not _UUID_RE.match(cascade_id):
                    continue

                # Decode inner blob (may be base64-wrapped)
                decoded = _maybe_decode_base64(summary_blob) or summary_blob
                strings = _walk_strings(decoded)

                # Find first workspace file:// URI
                for s in strings:
                    if not s.startswith("file://"):
                        continue
                    # Truncate at first control character (protobuf field boundaries)
                    clean = re.split(r"[\x00-\x1f]", s)[0]
                    if not clean.startswith("file://"):
                        continue
                    path = _file_uri_to_path(clean)
                    # Skip Antigravity internal paths
                    if "/antigravity/" in path or "/.gemini/" in path:
                        continue
                    parts = path.replace("\\", "/").rstrip("/").split("/")
                    meaningful = [p for p in parts if p.lower() not in skip_dirs and len(p) > 1]
                    if meaningful and cascade_id not in session_map:
                        session_map[cascade_id] = meaningful[-1]
                    break

        conn.close()
    except Exception:
        pass

    return session_map


# ---------------------------------------------------------------------------
# Conversation extraction (from state.vscdb protobuf)
# ---------------------------------------------------------------------------

def extract_antigravity_conversations(vscdb_path: Path | None = None) -> list[dict]:
    """Extract conversation fragments from Antigravity's globalStorage/state.vscdb.

    Returns a list of dicts with keys: session_id, title, content, source_key.
    """
    if vscdb_path is None:
        vscdb_path = _get_vscdb_path()
    if vscdb_path is None:
        return []

    conversations: list[dict] = []

    try:
        db = sqlite3.connect(f"file:{vscdb_path}?mode=ro", uri=True)

        for key in [
            "jetskiStateSync.agentManagerInitState",
            "unifiedStateSync.trajectorySummaries",
            "antigravityUnifiedStateSync.trajectorySummaries",
        ]:
            val = db.execute("SELECT value FROM ItemTable WHERE key = ?", (key,)).fetchone()
            if not val:
                continue

            raw = val[0]
            try:
                decoded = base64.b64decode(raw)
            except Exception:
                decoded = raw.encode("utf-8") if isinstance(raw, str) else raw

            # Try protoc decode
            try:
                result = subprocess.run(
                    ["protoc", "--decode_raw"],
                    input=decoded,
                    capture_output=True,
                    timeout=10,
                )
                if result.returncode != 0:
                    continue
                output = result.stdout.decode("utf-8", errors="replace")
            except (subprocess.TimeoutExpired, FileNotFoundError):
                continue

            # Extract session IDs
            session_ids = re.findall(
                r'1: "([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"',
                output,
            )

            # Extract all meaningful string fields
            all_strings = re.findall(r'\d+: "(.+?)"', output)
            fragments = []
            for s in all_strings:
                if len(s) < 30:
                    continue
                if s.startswith("file://") or s.startswith("http"):
                    continue
                if re.match(r'^[A-Za-z0-9+/=]{60,}$', s):
                    continue
                try:
                    decoded_s = s.encode().decode("unicode_escape").encode("latin1").decode("utf-8")
                except Exception:
                    decoded_s = s
                if len(decoded_s) > 30:
                    fragments.append(decoded_s)

            if fragments:
                conversations.append({
                    "source_key": key,
                    "session_ids": session_ids,
                    "fragments": fragments,
                    "fragment_count": len(fragments),
                })

        db.close()
    except Exception:
        pass

    return conversations


def format_as_markdown(conversations: list[dict]) -> str:
    """Format extracted conversations as a readable markdown document."""
    lines = ["# Antigravity Conversation Extracts\n"]

    for conv in conversations:
        lines.append(f"## Source: {conv['source_key']}")
        if conv["session_ids"]:
            lines.append(f"Sessions: {', '.join(conv['session_ids'][:5])}")
        lines.append(f"Fragments: {conv['fragment_count']}\n")

        for i, frag in enumerate(conv["fragments"]):
            lines.append(f"### Fragment {i + 1}")
            lines.append(frag)
            lines.append("")

    return "\n".join(lines)
