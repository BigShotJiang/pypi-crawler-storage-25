"""Cursor tool definition — watches ~/.cursor/ for conversations, skills, config."""

from __future__ import annotations

from pathlib import Path

from ..config import TOOL_PATHS, HOME
from .claude_code import _extract_cwd_from_jsonl


def _resolve_hash_to_path(project_hash: str) -> str | None:
    """Try to find the real filesystem path for a Cursor/Claude Code project hash.

    Hash format: 'Users-haixingdong-Desktop-dev-ft-userdata'
    Real path:   '/Users/haixingdong/Desktop/dev/ft_userdata' (could be _ or -)
    """
    raw = project_hash.strip("-")
    # Reconstruct candidate path: replace - with /
    candidate = "/" + raw.replace("-", "/")
    from pathlib import Path
    if Path(candidate).exists():
        return candidate
    # Try replacing last segment's / back to - and _
    parts = candidate.rsplit("/", 1)
    if len(parts) == 2:
        parent, name = parts
        # Try underscore variant
        for sep in ("_", "-"):
            # Scan parent directory for a matching name
            parent_path = Path(parent)
            if parent_path.is_dir():
                for entry in parent_path.iterdir():
                    if entry.is_dir() and entry.name.replace(sep, "-") == name.replace(sep, "-"):
                        return str(entry)
    return None
from .base import (
    BaseTool, Category, ContentType, FileClassification, SyncStrategy, WatchPath,
)


class CursorTool(BaseTool):

    _project_path_cache: dict[str, str | None] = {}

    def _resolve_project_path(self, project_hash: str) -> str | None:
        """Resolve hash to real path. Try cwd from JSONL, then filesystem match."""
        if project_hash not in self._project_path_cache:
            project_dir = self.root_path / "projects" / project_hash
            # Try extracting cwd from agent-transcripts JSONL
            result = None
            for sub in (project_dir / "agent-transcripts").glob("*/*.jsonl") if (project_dir / "agent-transcripts").exists() else []:
                result = _extract_cwd_from_jsonl(sub.parent)
                if result:
                    break
            if not result:
                result = _extract_cwd_from_jsonl(project_dir)
            if not result:
                # Fallback: try to match hash to a real directory on disk
                result = _resolve_hash_to_path(project_hash)
            self._project_path_cache[project_hash] = result
        return self._project_path_cache[project_hash]

    @property
    def name(self) -> str:
        return "cursor"

    @property
    def display_name(self) -> str:
        return "Cursor"

    @property
    def root_path(self) -> Path:
        return TOOL_PATHS["cursor"]

    def get_watch_paths(self) -> list[WatchPath]:
        if not self.is_available():
            return []
        root = self.root_path
        return [
            # Config
            WatchPath(
                path=root,
                pattern="argv.json",
                category=Category.CONFIG,
                content_type=ContentType.JSON,
                description="Cursor argv configuration",
            ),
            # Extensions
            WatchPath(
                path=root / "extensions",
                pattern="extensions.json",
                category=Category.EXTENSION,
                content_type=ContentType.JSON,
                description="Installed extensions",
            ),
            # Agent transcripts (conversations) — same format as Claude Code
            WatchPath(
                path=root / "projects",
                pattern="**/*.jsonl",
                category=Category.CONVERSATION,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                recursive=True,
                description="Agent conversation transcripts",
            ),
            # Project MCP instructions
            WatchPath(
                path=root / "projects",
                pattern="**/*.md",
                category=Category.MEMORY,
                content_type=ContentType.MARKDOWN,
                recursive=True,
                description="MCP instructions and project rules",
            ),
            # Project metadata
            WatchPath(
                path=root / "projects",
                pattern="**/*.json",
                category=Category.CONFIG,
                content_type=ContentType.JSON,
                recursive=True,
                description="Project and MCP metadata",
            ),
            # Skills
            WatchPath(
                path=root / "skills-cursor",
                pattern="**/*.md",
                category=Category.SKILL,
                content_type=ContentType.MARKDOWN,
                recursive=True,
                description="Cursor built-in skills",
            ),
            # AI tracking database
            WatchPath(
                path=root / "ai-tracking",
                pattern="*.db",
                category=Category.STATE,
                content_type=ContentType.SQLITE,
                sync_strategy=SyncStrategy.POLL,
                description="AI code tracking database",
            ),
        ]

    def classify_file(self, abs_path: Path) -> FileClassification | None:
        if not self.is_available():
            return None
        try:
            rel = abs_path.relative_to(self.root_path)
        except ValueError:
            return None

        rel_str = str(rel).replace("\\", "/")
        parts = rel.parts

        # Skip cache, crashpad, etc.
        skip = {".gitignore"}
        if abs_path.name in skip:
            return None

        # argv.json
        if rel_str == "argv.json":
            return FileClassification(
                tool_name=self.name, category=Category.CONFIG,
                content_type=ContentType.JSON, sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # extensions
        if rel_str == "extensions/extensions.json":
            return FileClassification(
                tool_name=self.name, category=Category.EXTENSION,
                content_type=ContentType.JSON, sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # projects/ — agent transcripts
        if parts and parts[0] == "projects":
            if abs_path.suffix == ".jsonl":
                dir_hash = parts[1] if len(parts) >= 2 else ""
                real_path = self._resolve_project_path(dir_hash) if dir_hash else None
                project_name = real_path.replace("\\", "/").rstrip("/").split("/")[-1] if real_path else dir_hash
                is_subagent = "subagents" in parts
                meta: dict = {
                    "project_hash": project_name,
                    "session_id": abs_path.stem,
                    "is_subagent": is_subagent,
                }
                if real_path:
                    meta["project_path"] = real_path
                return FileClassification(
                    tool_name=self.name, category=Category.CONVERSATION,
                    content_type=ContentType.JSONL, sync_strategy=SyncStrategy.DELTA,
                    relative_path=rel_str,
                    metadata=meta,
                )
            if abs_path.suffix == ".md":
                return FileClassification(
                    tool_name=self.name, category=Category.MEMORY,
                    content_type=ContentType.MARKDOWN, sync_strategy=SyncStrategy.FULL,
                    relative_path=rel_str,
                )
            if abs_path.suffix == ".json":
                return FileClassification(
                    tool_name=self.name, category=Category.CONFIG,
                    content_type=ContentType.JSON, sync_strategy=SyncStrategy.FULL,
                    relative_path=rel_str,
                )

        # skills-cursor/
        if parts and parts[0] == "skills-cursor" and abs_path.suffix == ".md":
            return FileClassification(
                tool_name=self.name, category=Category.SKILL,
                content_type=ContentType.MARKDOWN, sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # ai-tracking
        if parts and parts[0] == "ai-tracking" and abs_path.suffix == ".db":
            return FileClassification(
                tool_name=self.name, category=Category.STATE,
                content_type=ContentType.SQLITE, sync_strategy=SyncStrategy.POLL,
                relative_path=rel_str,
            )

        return None
