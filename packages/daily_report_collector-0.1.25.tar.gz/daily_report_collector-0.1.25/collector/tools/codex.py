"""Codex tool definition — watches ~/.codex/ for sessions, history, config."""

from __future__ import annotations

import json
import re
from pathlib import Path

from ..config import TOOL_PATHS
from .base import (
    BaseTool, Category, ContentType, FileClassification, SyncStrategy, WatchPath,
)

_SKIP_DIRS = {"users", "user", "home", "desktop", "dev", "documents",
              "python", "projects", "src", "code"}


class CodexTool(BaseTool):

    @property
    def name(self) -> str:
        return "codex"

    @property
    def display_name(self) -> str:
        return "Codex"

    @property
    def root_path(self) -> Path:
        return TOOL_PATHS["codex"]

    def get_watch_paths(self) -> list[WatchPath]:
        root = self.root_path
        return [
            # Config
            WatchPath(
                path=root,
                pattern="config.toml",
                category=Category.CONFIG,
                content_type=ContentType.TOML,
                description="Main config: model, reasoning level, personality",
            ),
            # AGENTS.md
            WatchPath(
                path=root,
                pattern="AGENTS.md",
                category=Category.IDENTITY,
                content_type=ContentType.MARKDOWN,
                description="Agent instructions",
            ),
            # History
            WatchPath(
                path=root,
                pattern="history.jsonl",
                category=Category.HISTORY,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                description="Session command history",
            ),
            # Active sessions
            WatchPath(
                path=root / "sessions",
                pattern="**/*.jsonl",
                category=Category.CONVERSATION,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                recursive=True,
                description="Conversation session transcripts",
            ),
            # Archived sessions
            WatchPath(
                path=root / "archived_sessions",
                pattern="*.jsonl",
                category=Category.CONVERSATION,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                description="Archived conversation sessions",
            ),
            # SQLite logs (polled)
            WatchPath(
                path=root,
                pattern="logs_1.sqlite",
                category=Category.STATE,
                content_type=ContentType.SQLITE,
                sync_strategy=SyncStrategy.POLL,
                description="Structured log database",
            ),
            # SQLite state (polled)
            WatchPath(
                path=root,
                pattern="state_5.sqlite",
                category=Category.STATE,
                content_type=ContentType.SQLITE,
                sync_strategy=SyncStrategy.POLL,
                description="Threads and jobs state database",
            ),
            # Skills
            WatchPath(
                path=root / "vendor_imports",
                pattern="**/*.md",
                category=Category.SKILL,
                content_type=ContentType.MARKDOWN,
                recursive=True,
                description="Curated vendor skills (44+)",
            ),
        ]

    def classify_file(self, abs_path: Path) -> FileClassification | None:
        try:
            rel = abs_path.relative_to(self.root_path)
        except ValueError:
            return None

        rel_str = str(rel).replace("\\", "/")
        parts = rel.parts

        # Exclude auth, cache, tmp, log, shell snapshots
        skip_dirs = {"cache", "tmp", ".tmp", "log", "shell_snapshots"}
        if parts and parts[0] in skip_dirs:
            return None

        # Exclude auth.json entirely
        if rel_str == "auth.json":
            return None

        # config.toml
        if rel_str == "config.toml":
            return FileClassification(
                tool_name=self.name,
                category=Category.CONFIG,
                content_type=ContentType.TOML,
                sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # AGENTS.md
        if rel_str == "AGENTS.md":
            return FileClassification(
                tool_name=self.name,
                category=Category.IDENTITY,
                content_type=ContentType.MARKDOWN,
                sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # history.jsonl
        if rel_str == "history.jsonl":
            return FileClassification(
                tool_name=self.name,
                category=Category.HISTORY,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                relative_path=rel_str,
            )

        # Active sessions
        if parts[0] == "sessions" and abs_path.suffix == ".jsonl":
            project_name, project_path = self._extract_cwd_from_session(abs_path)
            meta: dict = {"session_name": abs_path.stem}
            if project_name:
                meta["project_hash"] = project_name
            if project_path:
                meta["project_path"] = project_path
            return FileClassification(
                tool_name=self.name,
                category=Category.CONVERSATION,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                relative_path=rel_str,
                metadata=meta,
            )

        # Archived sessions
        if parts[0] == "archived_sessions" and abs_path.suffix == ".jsonl":
            project_name, project_path = self._extract_cwd_from_session(abs_path)
            meta = {"session_name": abs_path.stem, "archived": True}
            if project_name:
                meta["project_hash"] = project_name
            if project_path:
                meta["project_path"] = project_path
            return FileClassification(
                tool_name=self.name,
                category=Category.CONVERSATION,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                relative_path=rel_str,
                metadata=meta,
            )

        # version.json
        if rel_str == "version.json":
            return FileClassification(
                tool_name=self.name,
                category=Category.CONFIG,
                content_type=ContentType.JSON,
                sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # SQLite databases
        if abs_path.name in ("logs_1.sqlite", "state_5.sqlite"):
            return FileClassification(
                tool_name=self.name,
                category=Category.STATE,
                content_type=ContentType.SQLITE,
                sync_strategy=SyncStrategy.POLL,
                relative_path=rel_str,
            )

        # Skills / vendor imports
        if parts[0] == "vendor_imports" and abs_path.suffix == ".md":
            return FileClassification(
                tool_name=self.name,
                category=Category.SKILL,
                content_type=ContentType.MARKDOWN,
                sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # models_cache.json — useful for tracking model availability
        if rel_str == "models_cache.json":
            return FileClassification(
                tool_name=self.name,
                category=Category.CONFIG,
                content_type=ContentType.JSON,
                sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        return None

    @staticmethod
    def _extract_cwd_from_session(abs_path: Path) -> tuple[str | None, str | None]:
        """Extract (project_name, full_cwd) from session_meta cwd field."""
        try:
            with open(abs_path, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    obj = json.loads(line)
                    if obj.get("type") == "session_meta":
                        cwd = obj.get("payload", {}).get("cwd", "")
                        if cwd:
                            parts = cwd.replace("\\", "/").rstrip("/").split("/")
                            meaningful = [p for p in parts
                                          if p.lower() not in _SKIP_DIRS and len(p) > 1]
                            name = meaningful[-1] if meaningful else None
                            return name, cwd
                    break
        except Exception:
            pass
        return None, None

    @property
    def excluded_paths(self) -> list[str]:
        root = str(self.root_path)
        return [
            f"{root}/auth.json",
            f"{root}/cache/**",
            f"{root}/tmp/**",
            f"{root}/.tmp/**",
            f"{root}/log/**",
            f"{root}/shell_snapshots/**",
        ]
