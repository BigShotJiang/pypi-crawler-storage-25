"""Differentiable Cornell box — GPU path tracing + interior/edge AD."""

import argparse, time
from pathlib import Path
import drjit as dr
import matplotlib.pyplot as plt, numpy as np
import rayd as rd

PI = 3.14159265358979323846
LIGHT_P0, LIGHT_U, LIGHT_V = np.float32([-0.25, 0.99, 2.65]), np.float32([0.50, 0, 0]), np.float32([0, 0, 0.60])
LIGHT_N, LIGHT_AREA, LIGHT_E = np.float32([0, -1, 0]), 0.30, np.float32([18, 16, 14])

def arr3(v):
    v = np.asarray(v, dtype=np.float32)
    return dr.cuda.Array3f(v[:, 0].tolist(), v[:, 1].tolist(), v[:, 2].tolist())

def quad(a, b, c, d):
    return rd.Mesh(arr3([a, b, c, d]), dr.cuda.Array3i([0, 0], [1, 2], [2, 3]))

def box(lo, hi):
    x0, y0, z0 = lo; x1, y1, z1 = hi
    v = arr3([[x0,y0,z0],[x1,y0,z0],[x1,y1,z0],[x0,y1,z0],[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]])
    f = dr.cuda.Array3i([0,0,4,4,0,0,1,1,0,0,3,3],[2,3,5,6,7,4,2,6,1,5,7,6],[1,2,6,7,3,7,6,5,5,4,6,2])
    m = rd.Mesh(v, f); m.use_face_normals = True; return m

def build_scene(tx):
    scene, albedos, emissions = rd.Scene(), [], []
    def add(mesh, albedo, emission=(0,0,0)):
        scene.add_mesh(mesh); albedos.append(albedo); emissions.append(emission)
    add(quad([-1,-1,1],[-1,-1,5],[1,-1,5],[1,-1,1]), [.78,.78,.78])          # floor
    add(quad([-1,1,1],[1,1,1],[1,1,5],[-1,1,5]),     [.78,.78,.78])          # ceiling
    add(quad([-1,-1,5],[-1,1,5],[1,1,5],[1,-1,5]),    [.75,.75,.75])          # back
    add(quad([-1,-1,1],[-1,1,1],[-1,1,5],[-1,-1,5]), [.74,.14,.12])          # left (red)
    add(quad([1,-1,1],[1,-1,5],[1,1,5],[1,1,1]),      [.12,.55,.16])          # right (green)
    lq = np.float32([[-0.25,0.99,2.65],[0.25,0.99,2.65],[-0.25,0.99,3.25],[0.25,0.99,3.25]])[[0,1,3,2]]
    light_id = len(albedos)
    add(quad(*lq), [1,1,1], LIGHT_E)                                          # light
    add(box([-0.72,-1.0,2.70],[-0.18,0.25,3.62]), [.82,.82,.82])             # tall block
    moving = box([-0.25,-1.0,-0.33],[0.25,-0.34,0.33])                        # short block
    c, s = float(np.cos(np.radians(20))), float(np.sin(np.radians(20)))
    moving.to_world_left = dr.cuda.ad.Matrix4f([[c,0,s,0.35+tx],[0,1,0,0],[-s,0,c,2.6],[0,0,0,1]])
    add(moving, [.86,.84,.80])
    scene.build()
    return scene, arr3(np.array(albedos, np.float32)), arr3(np.array(emissions, np.float32)), light_id

# --- path tracer with NEE ---

def ortho_frame(n):
    sign = dr.select(n[2] >= 0, 1.0, -1.0); a = -dr.rcp(sign + n[2]); b = n[0]*n[1]*a; V3 = type(n)
    return V3(1+sign*n[0]*n[0]*a, sign*b, -sign*n[0]), V3(b, sign+n[1]*n[1]*a, -n[1])

def cosine_hemisphere(n, rng):
    u1, u2 = rng.next_float32(), rng.next_float32(); r = dr.sqrt(u1); phi = 2*PI*u2
    t, s = ortho_frame(n)
    return dr.normalize(t*(r*dr.cos(phi)) + s*(r*dr.sin(phi)) + n*dr.sqrt(dr.maximum(0, 1-u1)))

def trace(scene, alb, emi, light_id, primary_ray, rng, max_depth=4, diff=False):
    n = dr.width(primary_ray.o[0])
    if diff:
        F3, B, MkR = dr.cuda.ad.Array3f, dr.cuda.ad.Bool, rd.Ray
        ray = rd.Ray(dr.cuda.ad.Array3f(primary_ray.o), dr.cuda.ad.Array3f(primary_ray.d))
    else:
        F3, B, MkR = dr.cuda.Array3f, dr.cuda.Bool, rd.RayDetached; ray = primary_ray
    beta, L, active = dr.full(F3, 1, n), dr.zeros(F3, n), dr.full(B, True, n)

    for depth in range(max_depth):
        its = scene.intersect(ray, active); hit = active & its.is_valid()
        sn = dr.select(dr.dot(its.n, ray.d) > 0, -its.n, its.n)
        gn = dr.select(dr.dot(its.geo_n, ray.d) > 0, -its.geo_n, its.geo_n)
        sid, hit_d = dr.detach(dr.select(hit, its.shape_id, 0)), dr.detach(hit)
        kd = F3(dr.gather(dr.cuda.Array3f, alb, sid, hit_d))
        Le = F3(dr.gather(dr.cuda.Array3f, emi, sid, hit_d))
        if depth == 0:
            L = dr.select(hit & (sid == light_id), L + beta * Le, L)
        surf = hit & ~(sid == light_id)
        # NEE
        lp = F3(*(LIGHT_P0[i]+rng.next_float32()*LIGHT_U[i]+rng.next_float32()*LIGHT_V[i] for i in range(3)))
        to_l = lp - its.p; d2 = dr.maximum(dr.squared_norm(to_l), 1e-8); wi = to_l * dr.rsqrt(d2)
        cos_s = dr.maximum(dr.dot(sn, wi), 0.0)
        cos_l = dr.maximum(dr.dot(F3(*(-LIGHT_N).tolist()), wi), 0.0)
        can_shade = surf & (cos_s > 0) & (cos_l > 0)
        sh = rd.RayDetached(dr.detach(its.p)+dr.detach(gn)*1e-3, dr.detach(wi))
        sh.tmax = dr.maximum(dr.sqrt(dr.detach(d2))-2e-3, 1e-3)
        vis = dr.select(~scene.intersect(sh, dr.detach(can_shade)).is_valid(), 1.0, 0.0)
        L = dr.select(surf, L + beta*kd*(F3(*LIGHT_E.tolist())*(LIGHT_AREA*cos_s*cos_l*dr.rcp(PI*dr.maximum(d2,1e-5))*vis)), L)
        # bounce
        ray = MkR(dr.select(surf, its.p+gn*1e-3, ray.o), dr.select(surf, cosine_hemisphere(sn, rng), ray.d))
        beta = dr.select(surf, beta*kd, beta); active = surf
        if depth >= 2:
            q = dr.clip(dr.maximum(beta[0], dr.maximum(beta[1], beta[2])), 0.05, 0.95)
            survive = rng.next_float32() < q
            beta = dr.select(active & survive, beta*dr.rcp(q), beta); active &= survive
    return L

# --- gradient passes ---

def _make_rng(count, seed, seq=1):
    rng = dr.cuda.PCG32(size=count)
    rng.seed(initstate=dr.arange(dr.cuda.UInt64, count)+seed, initseq=dr.full(dr.cuda.UInt64, seq, count))
    return rng

def _pixel_uv(w, h, spp, rng):
    n = w * h
    px = dr.repeat(dr.cuda.Float(dr.arange(dr.cuda.UInt, n) % w), spp)
    py = dr.repeat(dr.cuda.Float(dr.arange(dr.cuda.UInt, n) // w), spp)
    return dr.cuda.Array2f((px+rng.next_float32())/w, (py+rng.next_float32())/h)

def _forward_grad(tx, image):
    dr.set_grad(tx, 0.0); dr.set_grad(tx, 1.0)
    dr.forward_to(image); g = dr.grad(image); dr.eval(g); return g

def render_interior_ad(scene, camera, alb, emi, lid, tx, seed=7, spp=64, md=3):
    w, h, sc = camera.width, camera.height, camera.width*camera.height*spp
    rng = _make_rng(sc, seed+0x10000, 2)
    primary = camera.sample_ray(_pixel_uv(w, h, spp, rng))
    rgb = trace(scene, alb, emi, lid, primary, rng, md, diff=True)
    return _forward_grad(tx, dr.block_sum(0.2126*rgb[0]+0.7152*rgb[1]+0.0722*rgb[2], spp)/float(spp))

def render_edge_ad(scene, camera, alb, emi, lid, tx, seed=7, spp=16, md=4):
    n, sc = camera.width*camera.height, camera.width*camera.height*spp
    edge = camera.sample_edge((dr.arange(dr.cuda.Float, sc)+0.5)/float(sc))
    valid, safe_pdf = dr.cuda.ad.Bool(edge.idx >= 0), dr.maximum(edge.pdf, 1e-8)
    def lum(ray):
        rng = _make_rng(sc, seed, seed+1)
        rgb = trace(scene, alb, emi, lid, ray, rng, md)
        return 0.2126*rgb[0]+0.7152*rgb[1]+0.0722*rgb[2]
    c = edge.x_dot_n * dr.cuda.ad.Float((lum(edge.ray_n)-lum(edge.ray_p))/safe_pdf)
    c = dr.select(valid, c/float(spp), 0.0); c -= dr.cuda.ad.Float(dr.detach(c))
    image = dr.zeros(dr.cuda.ad.Float, n)
    dr.scatter_reduce(dr.ReduceOp.Add, image, c, dr.cuda.ad.UInt(edge.idx), valid)
    return _forward_grad(tx, image)

# --- main ---

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--width", type=int, default=512);  ap.add_argument("--height", type=int, default=512)
    ap.add_argument("--spp", type=int, default=256);     ap.add_argument("--interior-spp", type=int, default=64)
    ap.add_argument("--edge-spp", type=int, default=16); ap.add_argument("--max-depth", type=int, default=3)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args(); w, h, n = args.width, args.height, args.width*args.height

    t0 = time.perf_counter()
    tx = dr.cuda.ad.Float([0.0]); dr.enable_grad(tx)
    scene, alb, emi, lid = build_scene(tx)
    camera = rd.Camera(55.0, 1e-4, 1e4); camera.width, camera.height = w, h
    camera.build(); camera.prepare_edges(scene); dr.sync_thread()
    t1 = time.perf_counter()

    # render (detached, display only)
    rng = _make_rng(n*args.spp, args.seed)
    primary = camera.sample_ray(_pixel_uv(w, h, args.spp, rng))
    rgb = trace(scene, alb, emi, lid, primary, rng, args.max_depth)
    rgb = dr.block_sum(rgb, args.spp) / float(args.spp)
    rgb = dr.power(dr.minimum(rgb * dr.rcp(1 + rgb), 1), 1 / 2.2)
    dr.eval(rgb); dr.sync_thread(); t2 = time.perf_counter()

    # gradients
    ig = render_interior_ad(scene, camera, alb, emi, lid, tx, args.seed, args.interior_spp, args.max_depth)
    dr.sync_thread(); t3 = time.perf_counter()
    eg = render_edge_ad(scene, camera, alb, emi, lid, tx, args.seed, args.edge_spp, args.max_depth)
    dr.sync_thread(); t4 = time.perf_counter()
    grad = ig + eg

    # plot
    rgb_np = np.stack([np.asarray(dr.detach(rgb[i])) for i in range(3)], 1).reshape(h, w, 3)
    grad_np = np.asarray(dr.detach(grad)).reshape(h, w)
    print(f"res={w}x{h} spp={args.spp} int_spp={args.interior_spp} edge_spp={args.edge_spp} depth={args.max_depth}")
    print(f"setup {(t1-t0)*1e3:.0f}ms  render {(t2-t1)*1e3:.0f}ms  interior {(t3-t2)*1e3:.0f}ms  edge {(t4-t3)*1e3:.0f}ms")
    out = Path(__file__).resolve().parent / "cornell_box.png"
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 5))
    a1.imshow(np.clip(rgb_np, 0, 1)); a1.set_title("render"); a1.axis("off")
    lim = max(float(np.percentile(np.abs(grad_np), 99.5)), 1e-6)
    a2.imshow(grad_np, cmap="coolwarm", vmin=-lim, vmax=lim)
    a2.set_title("d(luminance)/d(tx)  (interior + edge)"); a2.axis("off")
    plt.tight_layout(); plt.savefig(out, dpi=150); print(f"saved = {out}")

if __name__ == "__main__":
    main()
