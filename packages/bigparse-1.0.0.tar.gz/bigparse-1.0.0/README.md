# BigParse Python SDK

[![PyPI version](https://badge.fury.io/py/bigparse.svg)](https://pypi.org/project/bigparse/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

**BigParse**, Turkiye'nin bagimsiz arama motoru API'si icin resmi Python istemcisidir. 11.000+ Turk haber kaynagini gercek zamanli indeksler, saniyeler icinde JSON formatinda arama sonuclari dondurur.

Sifir bagimlilk. Sadece Python standart kutuphanesi. 3 satirda entegre edin.

> **Kapsam Notu:** BigParse su anda **Turkiye kaynakli guncel haber ve icerik** uzerine odaklanmaktadir. Indeksimiz 11.000+ Turk haber sitesi, yerel gazeteler, bolgesel medya kuruluslari ve Turkce icerik ureten platformlari kapsar. Genel amacli bir web arama motoru degildir — uluslararasi kaynaklar, Ingilizce icerikler veya haber disi web sayfalari (e-ticaret, forum, wiki vb.) henuz indekste yer almamaktadir. En iyi sonuclari **Turkiye gundemi, yerel haberler, bolgesel icerikler ve Turkce haber aramalari** icin alirsiniz. Kapsam surekli genislemektedir.

## Kurulum

```bash
pip install bigparse
```

## Hizli Baslangic

```python
from bigparse import BigParse

bp = BigParse("YOUR_API_KEY")

results = bp.search("yapay zeka")
print(f"{results.total} sonuc, {results.duration_ms}ms")

for r in results:
    print(f"{r.title} — {r.domain}")
```

---

## API Key Almak

BigParse API'yi kullanmak icin bir API anahtarina ihtiyaciniz var. Ucretsiz plan ile hemen baslayabilirsiniz.

### 1. Hesap Olusturun
[bigparse.com/kayit](https://bigparse.com/kayit) adresinden ucretsiz hesabinizi olusturun. E-posta ve sifreniz yeterli.

### 2. API Key Talep Edin
[bigparse.com/hesap](https://bigparse.com/hesap) panelinden **"Yeni API Key Talep Et"** butonuna tiklayarak key talebinizi olusturun. Projenizin adini ve kullanim amacinizi belirtin.

### 3. Onay Sonrasi Kullanima Baslayin
Talebiniz ekibimiz tarafindan incelenir ve onaylanir. Onay sonrasi API keyiniz aninda aktif olur ve hesap panelinizden kopyalayabilirsiniz.

### Planlar

| Plan | Gunluk Sorgu | Rate Limit | API Key | Aylik Ucret |
|------|-------------|------------|---------|-------------|
| **Ucretsiz** | 100 | 10/dk | 1 | Ucretsiz |
| **Baslangic** | 1.000 | 30/dk | 3 | 149 TL |
| **Profesyonel** | 10.000 | 60/dk | 10 | 499 TL |
| **Kurumsal** | 100.000 | 120/dk | 50 | 1.999 TL |

Kurumsal planlarda ozel limitler ve oncelikli destek icin [info@rturk.com.tr](mailto:info@rturk.com.tr) adresinden bize ulasin.

---

## Arama

```python
# Temel arama
results = bp.search("deprem")

# Zaman filtresi: son 24 saatin haberleri
results = bp.search("son dakika", tbs="24h")  # 1h, 24h, 7d, 30d, 1y

# Bolge filtresi: sadece Istanbul kaynaklari
results = bp.search("trafik", region="istanbul")

# Kategori filtresi
results = bp.search("faiz", category="ekonomi")

# Sayfalama
results = bp.search("teknoloji", limit=20, page=2)

# Hepsini birden
results = bp.search("secim", tbs="7d", region="ankara", limit=50)
```

## Tum Sayfalari Dolasma

```python
# Otomatik sayfalama — tum sonuclari tek dongude alin
for r in bp.search_all("yapay zeka", max_pages=5):
    print(r.title, r.url)
```

## Otomatik Tamamlama

```python
suggestions = bp.suggest("anka")
for s in suggestions.suggestions:
    print(s)  # ankara, ankaragucu, ankarada bugun...
```

## Hata Yonetimi

```python
from bigparse import BigParse, AuthError, RateLimitError, BigParseError

bp = BigParse("YOUR_API_KEY")

try:
    results = bp.search("test")
except AuthError:
    print("API key gecersiz veya aktif degil.")
except RateLimitError as e:
    print(f"Cok fazla istek. {e.retry_after} saniye sonra tekrar deneyin.")
except BigParseError as e:
    print(f"API hatasi [{e.status_code}]: {e}")
```

## Yanit Modeli

```python
results = bp.search("istanbul haber")

# SearchResponse
results.total           # Toplam sonuc sayisi
results.duration_ms     # Sorgu suresi (milisaniye)
results.detected_city   # Otomatik tespit edilen sehir
results.detected_region # Tespit edilen bolge
results.query_type      # Sorgu tipi (general, news, local)
len(results)            # Bu sayfadaki sonuc sayisi

# SearchResult
r = results[0]
r.title          # Baslik
r.url            # Kaynak URL
r.domain         # Domain adi
r.snippet        # Icerik ozeti
r.image          # Gorsel URL (varsa)
r.author         # Yazar (varsa)
r.published_at   # Yayin tarihi (ISO 8601)
r.quality_score  # Kalite puani (0-1)
r.quality_tier   # Kalite seviyesi (A/B/C/D)
r.keywords       # Anahtar kelimeler
```

## Kullanim Senaryolari

**Haber Uygulamasi** — Turkiye genelindeki haber kaynaklarini tek API ile arayin, zaman ve bolge filtresiyle daraltarak son dakika iceriklerini sunun.

**Icerik Analizi** — 11.000+ kaynaktan veri cekin. Belirli konulardaki haber yogunlugunu, kaynak cesitliligini ve trend degisimlerini analiz edin.

**Medya Izleme** — Marka, kisi veya konu bazli arama yaparak Turk medyasindaki gorunurlugu takip edin. Otomatik sayfalama ile tum sonuclari toplayin.

**Chatbot Entegrasyonu** — Yapay zeka asistanlariniza gercek zamanli Turkiye gundemini kazandirin. Kullanici sorularina BigParse verileriyle desteklenmis yanitlar verin.

**Akademik Arastirma** — Turk medyasindaki belirli konularin zaman icindeki yansimalarini arastirin. Tarih filtresi ve bolge filtresiyle kapsamli veri toplayin.

---

## Teknik Detaylar

- **Sifir bagimlilk**: Sadece Python standart kutuphanesi (`urllib`). Ek paket gerektirmez.
- **Python 3.8+** uyumlu
- **Thread-safe**: Her BigParse instance'i bagimsiz calismaktadir.
- **Timeout**: Varsayilan 30 saniye, ozellestirebilirsiniz: `BigParse("key", timeout=10)`
- **Base URL**: Ozel ortamlar icin degistirilebilir: `BigParse("key", base_url="https://...")`

## Destek ve Iletisim

- Dokumantasyon: [bigparse.com/hesap](https://bigparse.com/hesap)
- E-posta: [info@rturk.com.tr](mailto:info@rturk.com.tr)
- Web: [bigparse.com](https://bigparse.com)

---

**BigParse** — Turkiye'nin bagimsiz arama motoru. [RTURK Teknoloji](https://rturk.com.tr) tarafindan gelistirilmektedir.

MIT License
