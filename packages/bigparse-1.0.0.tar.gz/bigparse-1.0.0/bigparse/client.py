"""BigParse API istemcisi."""

import urllib.request
import urllib.parse
import urllib.error
import json
from typing import Optional, Dict, Any

from .models import SearchResponse, SuggestResponse


class BigParseError(Exception):
    """BigParse API hatasi."""
    def __init__(self, message: str, status_code: int = 0, response: Optional[dict] = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class AuthError(BigParseError):
    """Gecersiz API key veya yetkisiz erisim."""
    pass


class RateLimitError(BigParseError):
    """Rate limit asildi."""
    def __init__(self, message: str = "Rate limit asildi", retry_after: Optional[int] = None, **kwargs):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class BigParse:
    """
    BigParse API istemcisi.

    Kullanim:
        bp = BigParse("YOUR_API_KEY")
        results = bp.search("yapay zeka")
        for r in results:
            print(r.title, r.url)

    Args:
        api_key: BigParse API anahtari.
        base_url: API base URL (varsayilan: https://bigparse.com).
        timeout: Istek timeout suresi saniye (varsayilan: 30).
    """

    DEFAULT_BASE_URL = "https://bigparse.com"

    def __init__(self, api_key: str, base_url: Optional[str] = None, timeout: int = 30):
        if not api_key:
            raise AuthError("API key zorunlu")
        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout

    def _request(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> dict:
        """API istegi gonder."""
        url = f"{self.base_url}{endpoint}"
        if params:
            filtered = {k: v for k, v in params.items() if v is not None}
            if filtered:
                url += "?" + urllib.parse.urlencode(filtered)

        req = urllib.request.Request(url, headers={
            "X-API-Key": self.api_key,
            "Accept": "application/json",
            "User-Agent": f"bigparse-python/1.0.0",
        })

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return data
        except urllib.error.HTTPError as e:
            body = {}
            try:
                body = json.loads(e.read().decode("utf-8"))
            except Exception:
                pass
            msg = body.get("error", str(e))

            if e.code == 401:
                raise AuthError(msg, status_code=401, response=body)
            elif e.code == 429:
                retry = e.headers.get("Retry-After")
                raise RateLimitError(msg, status_code=429, response=body, retry_after=int(retry) if retry else None)
            else:
                raise BigParseError(msg, status_code=e.code, response=body)
        except urllib.error.URLError as e:
            raise BigParseError(f"Baglanti hatasi: {e.reason}")

    def search(
        self,
        query: str,
        limit: int = 10,
        page: int = 1,
        tbs: Optional[str] = None,
        category: Optional[str] = None,
        region: Optional[str] = None,
        language: Optional[str] = None,
    ) -> SearchResponse:
        """
        Arama yap.

        Args:
            query: Arama sorgusu.
            limit: Sonuc sayisi (1-50, varsayilan: 10).
            page: Sayfa numarasi (varsayilan: 1).
            tbs: Zaman filtresi (1h, 24h, 7d, 30d, 1y).
            category: Kategori filtresi.
            region: Bolge filtresi (ornek: istanbul, ankara).
            language: Dil filtresi (ornek: tr).

        Returns:
            SearchResponse: Arama sonuclari. Iterable — dogrudan for dongusu ile kullanilabilir.

        Raises:
            AuthError: Gecersiz API key.
            RateLimitError: Rate limit asildi.
            BigParseError: Diger API hatalari.

        Ornek:
            >>> results = bp.search("deprem", tbs="24h", limit=5)
            >>> print(f"Toplam: {results.total}")
            >>> for r in results:
            ...     print(r.title)
        """
        data = self._request("/api/v1/search", {
            "q": query,
            "limit": limit,
            "page": page,
            "tbs": tbs,
            "category": category,
            "region": region,
            "language": language,
        })
        return SearchResponse.from_dict(data)

    def suggest(self, query: str) -> SuggestResponse:
        """
        Otomatik tamamlama onerileri al.

        Args:
            query: Arama metni (min 2 karakter).

        Returns:
            SuggestResponse: Oneri listesi.

        Ornek:
            >>> suggestions = bp.suggest("anka")
            >>> for s in suggestions.suggestions:
            ...     print(s)
        """
        data = self._request("/api/v1/suggest", {"q": query})
        return SuggestResponse.from_dict(data)

    def search_all(
        self,
        query: str,
        max_pages: int = 10,
        limit: int = 10,
        **kwargs,
    ):
        """
        Tum sayfalari otomatik dolasarak sonuclari topla.

        Args:
            query: Arama sorgusu.
            max_pages: Maksimum sayfa sayisi (varsayilan: 10).
            limit: Sayfa basina sonuc (varsayilan: 10).
            **kwargs: search() icin ek parametreler.

        Yields:
            SearchResult: Her bir arama sonucu.

        Ornek:
            >>> for r in bp.search_all("yapay zeka", max_pages=3):
            ...     print(r.title, r.url)
        """
        for page_num in range(1, max_pages + 1):
            resp = self.search(query, limit=limit, page=page_num, **kwargs)
            if not resp.results:
                break
            for r in resp.results:
                yield r
            if page_num * limit >= resp.total:
                break

    def __repr__(self):
        masked = self.api_key[:8] + "..." if len(self.api_key) > 8 else "***"
        return f"BigParse(api_key='{masked}', base_url='{self.base_url}')"
