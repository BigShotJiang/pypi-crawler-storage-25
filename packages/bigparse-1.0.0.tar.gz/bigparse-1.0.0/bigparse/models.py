"""BigParse veri modelleri."""

from dataclasses import dataclass, field
from typing import Optional, List


@dataclass
class SearchResult:
    """Tek bir arama sonucu."""
    id: int = 0
    title: str = ""
    url: str = ""
    domain: str = ""
    snippet: str = ""
    image: Optional[str] = None
    author: Optional[str] = None
    published_at: Optional[str] = None
    language: Optional[str] = None
    content_type: Optional[str] = None
    quality_score: Optional[float] = None
    quality_tier: Optional[str] = None
    keywords: Optional[List[str]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "SearchResult":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class SearchResponse:
    """Arama yaniti."""
    results: List[SearchResult] = field(default_factory=list)
    total: int = 0
    page: int = 1
    limit: int = 10
    query: str = ""
    query_type: Optional[str] = None
    corrected_query: Optional[str] = None
    detected_city: Optional[str] = None
    detected_region: Optional[str] = None
    detected_date: Optional[str] = None
    duration_ms: int = 0
    cached: bool = False

    @classmethod
    def from_dict(cls, data: dict) -> "SearchResponse":
        results = [SearchResult.from_dict(r) for r in data.get("results", [])]
        return cls(
            results=results,
            total=data.get("total", 0),
            page=data.get("page", 1),
            limit=data.get("limit", 10),
            query=data.get("query", ""),
            query_type=data.get("queryType"),
            corrected_query=data.get("correctedQuery"),
            detected_city=data.get("detectedCity"),
            detected_region=data.get("detectedRegion"),
            detected_date=data.get("detectedDate"),
            duration_ms=data.get("duration_ms", 0),
            cached=data.get("cached", False),
        )

    def __iter__(self):
        return iter(self.results)

    def __len__(self):
        return len(self.results)

    def __getitem__(self, index):
        return self.results[index]


@dataclass
class SuggestResponse:
    """Otomatik tamamlama yaniti."""
    suggestions: List[str] = field(default_factory=list)
    query: str = ""

    @classmethod
    def from_dict(cls, data: dict) -> "SuggestResponse":
        return cls(
            suggestions=data.get("suggestions", []),
            query=data.get("query", ""),
        )
