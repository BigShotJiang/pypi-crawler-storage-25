"""
BigParse Python SDK
Turkiye'nin bagimsiz arama motoru API'si icin resmi Python istemcisi.

Kullanim:
    from bigparse import BigParse

    bp = BigParse("YOUR_API_KEY")
    results = bp.search("yapay zeka")
    for r in results:
        print(r.title, r.url)
"""

from .client import BigParse, BigParseError, RateLimitError, AuthError
from .models import SearchResult, SearchResponse, SuggestResponse

__version__ = "1.0.0"
__author__ = "RTURK Teknoloji"
__all__ = ["BigParse", "BigParseError", "RateLimitError", "AuthError", "SearchResult", "SearchResponse", "SuggestResponse"]
