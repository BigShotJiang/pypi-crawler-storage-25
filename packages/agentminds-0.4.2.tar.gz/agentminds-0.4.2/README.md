# agentminds — Python SDK

Auto-capture errors, failed requests, and logs from your Python web app.
Sentry-style API, Sentry-style ergonomics — one `init()` call and the SDK
hooks `sys.excepthook`, your web framework's error pipeline, and the
logging module. Connect once and your site joins the AgentMinds
intelligence pool — patterns the network has already learned for your
stack come back as recommendations.

## Install — one command

```bash
pip install agentminds && python -m agentminds connect
```

`python -m agentminds connect` is the recommended onboarding. It prompts
for your site URL + email, registers your site with the API, gets your
DSN, and auto-edits your FastAPI/Flask entry file in place (a
`.agentminds.bak` backup is written first). After that, set the printed
`AGENTMINDS_DSN` env var in your runtime and deploy.

```bash
# non-interactive — pass everything as flags
python -m agentminds connect --url=https://yourapp.com --email=you@example.com
```

> **Why `python -m agentminds` and not bare `agentminds`?** Pip
> installs the binary in `<python>/Scripts/` (Windows) or `<python>/bin/`
> (macOS/Linux). On Windows `--user` installs that directory isn't on
> PATH by default, so a stranger running `pip install agentminds` then
> `agentminds connect` gets `command not found` even though the install
> succeeded. `python -m agentminds` always works because the Python
> you just used to run `pip` is already on your PATH. Both forms are
> functionally identical.

## Quickstart (manual, if you already have a DSN)

```python
import agentminds

agentminds.init(
    dsn="https://pk_yoursite_xxx@api.agentminds.dev/yoursite",
    release="v1.2.3",        # optional — auto-detected from git
    environment="production",
)
```

That's it. From this point:

- Every uncaught exception (main thread + worker threads) is captured.
- Every `logging.error(...)` call ships as an event.
- Every `logging.info/warning(...)` becomes a breadcrumb on the next event.

The SDK is a no-op if no DSN is set — safe to leave `init()` in dev.

## FastAPI

```python
from fastapi import FastAPI
import agentminds
from agentminds.integrations.fastapi_app import AgentMindsMiddleware

agentminds.init(dsn="...")
app = FastAPI()
app.add_middleware(AgentMindsMiddleware)
```

Captures uncaught handler exceptions plus any 5xx response. Adds
`http.method` / `http.route` tags and a request breadcrumb.

## Flask

```python
from flask import Flask
import agentminds
from agentminds.integrations.flask_app import init_app

agentminds.init(dsn="...")
app = Flask(__name__)
init_app(app)
```

## Manual capture

```python
try:
    risky_thing()
except Exception as e:
    agentminds.capture_exception(e)

agentminds.capture_message("payment retry exceeded", level="warning")
agentminds.set_user({"id": user.id, "email": user.email})
agentminds.set_tag("plan", user.plan)
agentminds.add_breadcrumb(category="db", message="SELECT users WHERE...")
```

## Configuration

| Argument | Env var | Default | Notes |
|---|---|---|---|
| `dsn` | `AGENTMINDS_DSN` | — | Required. SDK no-op if absent. |
| `release` | `AGENTMINDS_RELEASE` | `git rev-parse --short HEAD` | Tag events with build. |
| `environment` | `AGENTMINDS_ENV` | `"production"` | Filter on the dashboard. |
| `sample_rate` | — | `1.0` | `0.1` = drop 90% of events. |
| `debug` | `AGENTMINDS_DEBUG=1` | `False` | Logs SDK internals to `agentminds` logger. |
| `attach_logging` | — | `True` | Auto-attach logging handler. |
| `install_excepthook` | — | `True` | Auto-hook `sys.excepthook`. |

## Wire format

The SDK posts batched events to:

```
POST {api_base}/api/v1/sync/ingest/{site_id}/events?key={public_key}
Content-Type: application/json
{ "events": [ { type, fingerprint, payload, page_url? }, ... ] }
```

Same envelope as the browser collector (`agent.js`) — server-side and
browser events land in the same `runtime_events` table.

## Privacy

- No request bodies sent unless you opt in (`send_default_pii=True`).
- No DB query parameters captured.
- User PII (email, IP) only sent if you set it via `set_user(...)`.
- Stack traces are truncated to 8 KB; messages to 500 chars.

## License

MIT
