"""Memory and persistence layer for conversations and state.

This module provides interfaces for persisting conversation history, managing checkpoints,
and implementing memory strategies for long-running workflows.

Examples:
    Use conversation memory:

        from flowgentra_ai.memory import ConversationMemory

        memory = ConversationMemory()

    Async in-memory checkpointer (full history):

        from flowgentra_ai.memory import AsyncMemoryCheckpointer

        cp = AsyncMemoryCheckpointer()
        await cp.save("thread-1", state, meta)
        history = await cp.list_history("thread-1")

    Namespaced checkpointer:

        from flowgentra_ai.memory import AsyncMemoryCheckpointer, NamespacedCheckpointer

        inner = AsyncMemoryCheckpointer()
        cp = NamespacedCheckpointer(inner, "my_agent")

    SQLite async checkpointer:

        from flowgentra_ai.memory import AsyncSqliteCheckpointer

        cp = await AsyncSqliteCheckpointer.new("sqlite:///checkpoints.db")

    PostgreSQL async checkpointer:

        from flowgentra_ai.memory import AsyncPostgresCheckpointer

        cp = await AsyncPostgresCheckpointer.new("postgresql://user:pass@localhost/db")

    Redis async checkpointer:

        from flowgentra_ai.memory import AsyncRedisCheckpointer

        cp = await AsyncRedisCheckpointer.new("redis://localhost/", ttl_seconds=86400)

    MongoDB async checkpointer:

        from flowgentra_ai.memory import AsyncMongoCheckpointer

        cp = await AsyncMongoCheckpointer.new("mongodb://localhost:27017", "mydb", "checkpoints")

    MySQL async checkpointer:

        from flowgentra_ai.memory import AsyncMysqlCheckpointer

        cp = await AsyncMysqlCheckpointer.new("mysql://user:pass@localhost/db")
"""

from flowgentra_ai._native import memory as _m, state as _s

# ── Core types ────────────────────────────────────────────────────────────────
Checkpoint = _m.Checkpoint
CheckpointMetadata = _m.CheckpointMetadata
ConversationMemory = _m.ConversationMemory
TokenBufferMemory = _m.TokenBufferMemory
SummaryConfig = _m.SummaryConfig
SummaryMemory = _m.SummaryMemory

# ── File-based (always available) ────────────────────────────────────────────
FileCheckpointer = _s.FileCheckpointer

# ── Database-backed checkpointers ────────────────────────────────────────────
# Conditionally available based on Cargo feature flags.
# If the native extension was built without the relevant feature, returns None.

def _try_import(module, attr):
    try:
        return getattr(module, attr)
    except AttributeError:
        return None

# Sync (original) checkpointers
SqliteCheckpointer = _try_import(_s, "SqliteCheckpointer")
PostgresCheckpointer = _try_import(_s, "PostgresCheckpointer")
RedisCheckpointer = _try_import(_s, "RedisCheckpointer")

# Async checkpointers (always available)
AsyncMemoryCheckpointer = _try_import(_s, "AsyncMemoryCheckpointer")
NamespacedCheckpointer = _try_import(_s, "NamespacedCheckpointer")
CheckpointHistoryEntry = _try_import(_s, "CheckpointHistoryEntry")

# Async DB checkpointers (feature-gated)
AsyncSqliteCheckpointer = _try_import(_s, "AsyncSqliteCheckpointer")
AsyncPostgresCheckpointer = _try_import(_s, "AsyncPostgresCheckpointer")
AsyncRedisCheckpointer = _try_import(_s, "AsyncRedisCheckpointer")
AsyncMongoCheckpointer = _try_import(_s, "AsyncMongoCheckpointer")
AsyncMysqlCheckpointer = _try_import(_s, "AsyncMysqlCheckpointer")

__all__ = [
    "Checkpoint",
    "CheckpointMetadata",
    "ConversationMemory",
    "TokenBufferMemory",
    "SummaryConfig",
    "SummaryMemory",
    # Sync checkpointers
    "FileCheckpointer",
    "SqliteCheckpointer",
    "PostgresCheckpointer",
    "RedisCheckpointer",
    # Async checkpointers
    "AsyncMemoryCheckpointer",
    "NamespacedCheckpointer",
    "CheckpointHistoryEntry",
    "AsyncSqliteCheckpointer",
    "AsyncPostgresCheckpointer",
    "AsyncRedisCheckpointer",
    "AsyncMongoCheckpointer",
    "AsyncMysqlCheckpointer",
]
