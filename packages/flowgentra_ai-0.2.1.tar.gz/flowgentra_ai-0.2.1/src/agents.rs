//! Python bindings for prebuilt agents (AgentType, GraphBasedAgent,
//! and typed constructors ZeroShotReAct / FewShotReAct / Conversational / …)

use pyo3::prelude::*;

use flowgentra_ai::core::agents::{
    AgentConfig, AgentType, Conversational as RsConversational, FewShotReAct as RsFewShotReAct,
    GraphBasedAgent, ReactDocstore as RsReactDocstore, SelfAskWithSearch as RsSelfAskWithSearch,
    StructuredChat as RsStructuredChat, ToolCalling as RsToolCalling, ToolSpec,
    ZeroShotReAct as RsZeroShotReAct,
};

use crate::error::to_py_err;
use crate::llm::PyLLM;

// ─── PyAgentType ────────────────────────────────────────────────────────────

/// Agent type: "zero_shot_react", "few_shot_react", or "conversational".
#[pyclass(name = "AgentType")]
#[derive(Clone)]
pub struct PyAgentType {
    pub(crate) inner: AgentType,
}

#[pymethods]
impl PyAgentType {
    /// Zero-shot ReAct agent (reasoning + action without examples).
    #[staticmethod]
    fn zero_shot_react() -> Self {
        PyAgentType { inner: AgentType::ZeroShotReAct }
    }

    /// Few-shot ReAct agent (with example demonstrations).
    #[staticmethod]
    fn few_shot_react() -> Self {
        PyAgentType { inner: AgentType::FewShotReAct }
    }

    /// Conversational agent (multi-turn dialogue with memory).
    #[staticmethod]
    fn conversational() -> Self {
        PyAgentType { inner: AgentType::Conversational }
    }

    /// Tool Calling agent — uses the provider's native function/tool-calling API.
    #[staticmethod]
    fn tool_calling() -> Self {
        PyAgentType { inner: AgentType::ToolCalling }
    }

    /// Structured Chat Zero-Shot ReAct agent — ReAct with JSON-blob actions.
    #[staticmethod]
    fn structured_chat_zero_shot_react() -> Self {
        PyAgentType {
            inner: AgentType::StructuredChatZeroShotReAct,
        }
    }

    /// Self Ask With Search agent — decomposes questions into sub-questions.
    #[staticmethod]
    fn self_ask_with_search() -> Self {
        PyAgentType { inner: AgentType::SelfAskWithSearch }
    }

    /// ReAct Docstore agent — Search + Lookup loop over a document store.
    #[staticmethod]
    fn react_docstore() -> Self {
        PyAgentType { inner: AgentType::ReactDocstore }
    }

    fn __repr__(&self) -> String {
        format!("AgentType({})", self.inner)
    }

    fn __str__(&self) -> String {
        self.inner.to_string()
    }
}

// ─── PyToolSpec ─────────────────────────────────────────────────────────────

/// Tool specification for prebuilt agents.
///
/// Example:
///     tool = ToolSpec("search", "Search the web")
///     tool.add_parameter("query", "string")
///     tool.set_required("query")
#[pyclass(name = "ToolSpec")]
#[derive(Clone)]
pub struct PyToolSpec {
    pub(crate) inner: ToolSpec,
}

#[pymethods]
impl PyToolSpec {
    #[new]
    fn new(name: &str, description: &str) -> Self {
        PyToolSpec {
            inner: ToolSpec::new(name, description),
        }
    }

    /// Add a parameter with its type.
    fn add_parameter(&mut self, name: &str, param_type: &str) {
        self.inner.parameters.insert(name.to_string(), param_type.to_string());
    }

    /// Mark a parameter as required.
    fn set_required(&mut self, param: &str) {
        self.inner.required.push(param.to_string());
    }

    #[getter]
    fn name(&self) -> String {
        self.inner.name.clone()
    }

    #[getter]
    fn description(&self) -> String {
        self.inner.description.clone()
    }

    fn __repr__(&self) -> String {
        format!("ToolSpec(name='{}', desc='{}')", self.inner.name, self.inner.description)
    }
}

// ─── PyGraphBasedAgent ──────────────────────────────────────────────────────

/// A graph-based prebuilt agent (ReAct, Conversational, etc.).
///
/// Execute with `execute_input()` for simple string in/out.
#[pyclass(name = "GraphBasedAgent")]
pub struct PyGraphBasedAgent {
    inner: GraphBasedAgent,
}

#[pymethods]
impl PyGraphBasedAgent {
    /// Execute the agent with a text input and get a text response.
    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    /// Get the agent name.
    #[getter]
    fn name(&self) -> String {
        self.inner.config().name.clone()
    }

    /// Get node names of the underlying graph.
    fn node_names(&self) -> Vec<String> {
        self.inner.graph().node_names()
    }

    fn __repr__(&self) -> String {
        format!("GraphBasedAgent(name='{}')", self.inner.config().name)
    }
}

// ── Typed agent constructors ──────────────────────────────────────────────────
//
// Each class accepts keyword arguments and wraps the corresponding Rust typed agent.
//
//   agent = ZeroShotReAct(name="my-agent", llm=llm, retries=2, tools=[search])
//   result = agent.execute_input("What is 2+2?")

/// Helper: build an AgentConfig from Python keyword arguments.
macro_rules! apply_common_args {
    ($rs_type:ident, $name:expr, $llm:expr, $system_prompt:expr,
     $tools:expr, $retries:expr, $memory_steps:expr) => {{
        let mut config = AgentConfig {
            name: $name.to_string(),
            llm: $llm.inner.clone(),
            retries: $retries,
            ..Default::default()
        };
        if let Some(prompt) = $system_prompt {
            config.system_prompt = Some(prompt.to_string());
        }
        if let Some(ts) = $tools {
            config.tools = ts.iter().map(|t: &PyRef<PyToolSpec>| t.inner.clone()).collect();
        }
        if let Some(steps) = $memory_steps {
            config.memory_steps = Some(steps);
        }
        $rs_type::new(config)
    }};
}

// ─── ZeroShotReAct ──────────────────────────────────────────────────────────

/// Zero-shot ReAct agent — general-purpose reasoning + action without examples.
///
/// Example::
///
///     from flowgentra_ai.agent import ZeroShotReAct
///     from flowgentra_ai.llm import LLM
///
///     llm = LLM(provider="openai", model="gpt-4")
///     agent = ZeroShotReAct(name="assistant", llm=llm, retries=2, tools=[search])
///     result = agent.execute_input("What is the capital of France?")
#[pyclass(name = "ZeroShotReAct")]
pub struct PyZeroShotReAct {
    inner: RsZeroShotReAct,
}

#[pymethods]
impl PyZeroShotReAct {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &PyLLM,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let agent = apply_common_args!(
            RsZeroShotReAct, name, llm, system_prompt, tools, retries, memory_steps
        ).map_err(to_py_err)?;
        Ok(Self { inner: agent })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.name().to_string() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("ZeroShotReAct(name='{}')", self.inner.name())
    }
}

// ─── FewShotReAct ───────────────────────────────────────────────────────────

/// Few-shot ReAct agent — same as ZeroShotReAct with example demonstrations.
#[pyclass(name = "FewShotReAct")]
pub struct PyFewShotReAct {
    inner: RsFewShotReAct,
}

#[pymethods]
impl PyFewShotReAct {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &PyLLM,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let agent = apply_common_args!(
            RsFewShotReAct, name, llm, system_prompt, tools, retries, memory_steps
        ).map_err(to_py_err)?;
        Ok(Self { inner: agent })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.name().to_string() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("FewShotReAct(name='{}')", self.inner.name())
    }
}

// ─── Conversational ─────────────────────────────────────────────────────────

/// Conversational agent — multi-turn dialogue with persistent conversation history.
#[pyclass(name = "Conversational")]
pub struct PyConversational {
    inner: RsConversational,
}

#[pymethods]
impl PyConversational {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &PyLLM,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let agent = apply_common_args!(
            RsConversational, name, llm, system_prompt, tools, retries, memory_steps
        ).map_err(to_py_err)?;
        Ok(Self { inner: agent })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.name().to_string() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("Conversational(name='{}')", self.inner.name())
    }
}

// ─── ToolCalling ────────────────────────────────────────────────────────────

/// Tool-calling agent — uses the provider's native function-calling API.
#[pyclass(name = "ToolCalling")]
pub struct PyToolCalling {
    inner: RsToolCalling,
}

#[pymethods]
impl PyToolCalling {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &PyLLM,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let agent = apply_common_args!(
            RsToolCalling, name, llm, system_prompt, tools, retries, memory_steps
        ).map_err(to_py_err)?;
        Ok(Self { inner: agent })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.name().to_string() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("ToolCalling(name='{}')", self.inner.name())
    }
}

// ─── StructuredChat ─────────────────────────────────────────────────────────

/// Structured-chat agent — ReAct with JSON-blob tool actions and a JSON final answer.
#[pyclass(name = "StructuredChat")]
pub struct PyStructuredChat {
    inner: RsStructuredChat,
}

#[pymethods]
impl PyStructuredChat {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &PyLLM,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let agent = apply_common_args!(
            RsStructuredChat, name, llm, system_prompt, tools, retries, memory_steps
        ).map_err(to_py_err)?;
        Ok(Self { inner: agent })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.name().to_string() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("StructuredChat(name='{}')", self.inner.name())
    }
}

// ─── SelfAskWithSearch ──────────────────────────────────────────────────────

/// Self-ask-with-search agent — decomposes questions via a `search` tool.
#[pyclass(name = "SelfAskWithSearch")]
pub struct PySelfAskWithSearch {
    inner: RsSelfAskWithSearch,
}

#[pymethods]
impl PySelfAskWithSearch {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &PyLLM,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let agent = apply_common_args!(
            RsSelfAskWithSearch, name, llm, system_prompt, tools, retries, memory_steps
        ).map_err(to_py_err)?;
        Ok(Self { inner: agent })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.name().to_string() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("SelfAskWithSearch(name='{}')", self.inner.name())
    }
}

// ─── ReactDocstore ──────────────────────────────────────────────────────────

/// ReAct docstore agent — Search + Lookup loop over a document store.
#[pyclass(name = "ReactDocstore")]
pub struct PyReactDocstore {
    inner: RsReactDocstore,
}

#[pymethods]
impl PyReactDocstore {
    #[new]
    #[pyo3(signature = (name, llm, system_prompt=None, tools=None, retries=3, memory_steps=None))]
    fn new(
        name: &str,
        llm: &PyLLM,
        system_prompt: Option<&str>,
        tools: Option<Vec<PyRef<PyToolSpec>>>,
        retries: usize,
        memory_steps: Option<usize>,
    ) -> PyResult<Self> {
        let agent = apply_common_args!(
            RsReactDocstore, name, llm, system_prompt, tools, retries, memory_steps
        ).map_err(to_py_err)?;
        Ok(Self { inner: agent })
    }

    fn execute_input(&self, input: &str) -> PyResult<String> {
        crate::run_async(self.inner.execute_input(input)).map_err(to_py_err)
    }

    #[getter]
    fn name(&self) -> String { self.inner.name().to_string() }

    fn node_names(&self) -> Vec<String> { self.inner.graph().node_names() }

    fn __repr__(&self) -> String {
        format!("ReactDocstore(name='{}')", self.inner.name())
    }
}
