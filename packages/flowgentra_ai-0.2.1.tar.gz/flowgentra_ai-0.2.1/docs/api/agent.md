# Agent API Reference

## Agent

Config-driven agent. Loads its graph structure from a YAML file and auto-discovers handler functions by name.

```python
from flowgentra_ai.agent import Agent
```

### Class Methods

#### `Agent.from_config_path(path)` → `Agent`

Load an agent from a YAML configuration file.

| Parameter | Type | Description |
|-----------|------|-------------|
| `path` | `str` | Path to the YAML config file |

```python
agent = Agent.from_config_path("agent.yaml")
```

#### `Agent.from_config(config)` → `Agent`

Load from an already-constructed `AgentConfig` object.

| Parameter | Type | Description |
|-----------|------|-------------|
| `config` | `AgentConfig` | Pre-loaded config |

---

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `name` | `str` | Agent name from config |
| `config` | `AgentConfig` | The full configuration |
| `state` | `State` | Current state (after `run()`) |

---

### Methods

#### `run()` → `State`

Execute the agent from the start. Returns the final state.

```python
agent.set_state("query", "What is Rust?")
result = agent.run()
print(result["response"])
```

#### `run_with_thread(thread_id)` → `State`

Execute with checkpointing. State is persisted to disk — calling this again with the same `thread_id` resumes from where it left off.

| Parameter | Type | Description |
|-----------|------|-------------|
| `thread_id` | `str` | Unique ID for this session |

```python
result = agent.run_with_thread("session-abc")
```

#### `set_state(key, value)` → `None`

Set an initial state value before running.

| Parameter | Type | Description |
|-----------|------|-------------|
| `key` | `str` | State key |
| `value` | `Any` | Value (must be JSON-serializable) |

---

## AgentConfig

Configuration loaded from a YAML file.

```python
from flowgentra_ai.agent import AgentConfig
```

### Class Methods

#### `AgentConfig.from_file(path)` → `AgentConfig`

| Parameter | Type | Description |
|-----------|------|-------------|
| `path` | `str` | Path to YAML file |

#### `AgentConfig.from_yaml(yaml_str)` → `AgentConfig`

| Parameter | Type | Description |
|-----------|------|-------------|
| `yaml_str` | `str` | YAML content as a string |

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `name` | `str` | Agent name |
| `description` | `str \| None` | Optional description |

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `validate()` | `None` | Validate the config; raises on error |
| `to_json()` | `str` | Serialize to JSON |

---

## AgentBuilder

Builds a prebuilt agent (ZeroShotReAct, FewShotReAct, Conversational) without writing YAML.

```python
from flowgentra_ai.agent import AgentBuilder, AgentType
```

### Constructor

```python
AgentBuilder(agent_type: AgentType)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `agent_type` | `AgentType` | Which prebuilt pattern to use |

### Methods

All builder methods return `self` so you can chain them.

| Method | Parameter | Description |
|--------|-----------|-------------|
| `with_name(name)` | `str` | Human-readable name for the agent |
| `with_llm_config(model)` | `str` | Model string (e.g., `"gpt-4"`) |
| `with_temperature(temp)` | `float` | Response randomness, 0.0–2.0 |
| `with_max_tokens(tokens)` | `int` | Max tokens in each LLM response |
| `with_tool(tool_spec)` | `ToolSpec` | Add a tool the agent can call |
| `with_system_prompt(prompt)` | `str` | System prompt injected into every request |
| `with_memory_steps(steps)` | `int` | Number of past turns to keep in context |
| `with_evaluation()` | — | Enable automatic output evaluation |
| `with_retries(max_retries)` | `int` | Retry count for failed LLM calls |
| `with_param(key, value)` | `str, Any` | Set a custom parameter |
| `build_graph()` | → `GraphBasedAgent` | Finalize and return the agent |

```python
agent = (
    AgentBuilder(AgentType.zero_shot_react())
    .with_name("assistant")
    .with_llm_config("gpt-4")
    .with_temperature(0.2)
    .with_tool(my_tool)
    .with_system_prompt("You are a helpful assistant.")
    .with_retries(3)
    .build_graph()
)
```

---

## AgentType

Selects which prebuilt reasoning pattern to use.

```python
from flowgentra_ai.agent import AgentType
```

| Factory Method | Description |
|----------------|-------------|
| `AgentType.zero_shot_react()` | Reason + Act loop without example demonstrations. Best general-purpose choice. |
| `AgentType.few_shot_react()` | Same loop but includes worked examples in the prompt. Better for specialized domains. |
| `AgentType.conversational()` | Multi-turn dialogue with history. Use for chatbots. |

### ZeroShotReAct example

```python
agent = (
    AgentBuilder(AgentType.zero_shot_react())
    .with_llm_config("gpt-4")
    .with_tool(search_tool)
    .build_graph()
)
answer = agent.execute_input("What is the population of Japan?")
```

### FewShotReAct example

```python
agent = (
    AgentBuilder(AgentType.few_shot_react())
    .with_llm_config("gpt-4")
    .with_tool(data_tool)
    .with_memory_steps(5)
    .build_graph()
)
```

### Conversational example

```python
agent = (
    AgentBuilder(AgentType.conversational())
    .with_llm_config("gpt-4")
    .with_memory_steps(20)
    .build_graph()
)
r1 = agent.execute_input("My name is Alice.")
r2 = agent.execute_input("What's my name?")  # "Alice"
```

---

## GraphBasedAgent

A compiled prebuilt agent. Created by `AgentBuilder.build_graph()`.

### Methods

#### `execute_input(input)` → `str`

Run the agent with a text input. Returns the final text response.

| Parameter | Type | Description |
|-----------|------|-------------|
| `input` | `str` | The user's input text |

```python
answer = agent.execute_input("What is 17 * 8?")
print(answer)  # "136"
```

#### `node_names()` → `list[str]`

Returns the names of all nodes in the underlying graph. Useful for debugging.

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `name` | `str` | Agent name |

---

## ToolSpec

Describes a tool that a prebuilt agent can call. You define the name, description, and parameter schema — Flowgentra passes this to the LLM so it knows when and how to call the tool.

```python
from flowgentra_ai.agent import ToolSpec
```

### Constructor

```python
ToolSpec(name: str, description: str)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | `str` | Tool name (used by LLM to call it) |
| `description` | `str` | Plain-English description of what the tool does |

### Methods

#### `add_parameter(name, param_type)` → `None`

Add a parameter to the tool's input schema.

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | `str` | Parameter name |
| `param_type` | `str` | JSON type: `"string"`, `"number"`, `"integer"`, `"boolean"`, `"array"`, `"object"` |

#### `set_required(param_name)` → `None`

Mark a parameter as required. The LLM will always include it.

| Parameter | Type | Description |
|-----------|------|-------------|
| `param_name` | `str` | Parameter name to mark required |

```python
tool = ToolSpec("calculator", "Perform arithmetic calculations")
tool.add_parameter("operation", "string")   # "add", "subtract", etc.
tool.add_parameter("a", "number")
tool.add_parameter("b", "number")
tool.set_required("operation")
tool.set_required("a")
tool.set_required("b")
```

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `name` | `str` | Tool name |
| `description` | `str` | Tool description |

---

## MemoryAwareAgent

High-level agent wrapper with automatic per-user memory management. Each thread ID gets its own isolated conversation history.

```python
from flowgentra_ai.agent import MemoryAwareAgent
```

### Class Methods

#### `MemoryAwareAgent.from_config(path)` → `MemoryAwareAgent`

| Parameter | Type | Description |
|-----------|------|-------------|
| `path` | `str` | Path to YAML config file |

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `set_thread_id(thread_id)` | `None` | Switch to this user's conversation thread |
| `thread_id()` | `str` | Get the currently active thread ID |
| `run_turn(input)` | `str` | Run one conversation turn, returns agent response |
| `clear_memory()` | `None` | Clear conversation history for the current thread |
| `memory_stats()` | `MemoryStats` | Get memory usage stats for the current thread |

```python
agent = MemoryAwareAgent.from_config("agent.yaml")
agent.set_thread_id("user_alice")
r1 = agent.run_turn("Hello, I'm Alice.")
r2 = agent.run_turn("What's my name?")   # "Alice"
stats = agent.memory_stats()
```

---

## MemoryStats

Memory usage statistics for a thread.

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `message_count` | `int` | Total messages stored |
| `user_messages` | `int` | Number of user messages |
| `assistant_messages` | `int` | Number of assistant messages |
| `approximate_tokens` | `int` | Approximate token count across all messages |

---

## StateField

Defines a field in the state schema for config-driven agents.

```python
from flowgentra_ai.agent import StateField
```

### Constructor

```python
StateField(field_type: str, description: str)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `field_type` | `str` | Type of the field (`"string"`, `"number"`, etc.) |
| `description` | `str` | Human-readable description |

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `field_type` | `str` | Field type |
| `description` | `str` | Field description |
