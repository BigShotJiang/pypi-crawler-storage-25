"""Integration tests against live api.opedd.com.

Gated behind ``pytest --integration`` flag. Per founder M6 ratification 6:
"CI runs unit tests with mocked HTTP. Integration suite documented in README as
'run locally with your JWT before SDK release.'"

Requires env vars:
- ``OPEDD_BUYER_JWT`` — buyer-side Supabase session JWT
- ``OPEDD_BUYER_TOKEN`` — buyer-side ``opedd_buyer_live_*`` or ``opedd_buyer_test_*``
- ``OPEDD_ACCESS_KEY`` (optional) — for ``/enterprise-license`` GET feed tests

Skipped if env vars not set.

Discipline: keep this suite SMALL and READ-ONLY. The unit suite covers correctness.
This suite is a smoke test against real backend wire shape to catch backend-drift
issues before release. Do NOT add destructive operations or anything that writes
to production state (no license purchases, no content uploads).
"""

from __future__ import annotations

import os

import pytest

from opedd import Opedd

pytestmark = pytest.mark.integration


def _has_env(*names: str) -> bool:
    return all(os.environ.get(n) for n in names)


@pytest.mark.skipif(not _has_env("OPEDD_BUYER_JWT"), reason="OPEDD_BUYER_JWT not set")
def test_audit_events_returns_shape() -> None:
    """JWT auth path: /buyer-audit returns a shape we can iterate."""
    with Opedd() as client:
        result = client.audit.events(limit=5)
    assert result.get("success") is True
    assert "events" in result or "data" in result


@pytest.mark.skipif(not _has_env("OPEDD_BUYER_JWT"), reason="OPEDD_BUYER_JWT not set")
def test_compliance_report_smoke() -> None:
    """JWT auth path: /buyer-compliance-report returns dossier shape.

    Read-only; window is intentionally narrow (1 day) to minimize footprint.
    """
    with Opedd() as client:
        result = client.compliance.report(from_="2026-05-14", to="2026-05-15")
    assert "dossier_metadata" in result or "data" in result
    if "dossier_metadata" in result:
        assert "compliance_framework_anchors" in result["dossier_metadata"]


@pytest.mark.skipif(not _has_env("OPEDD_BUYER_TOKEN"), reason="OPEDD_BUYER_TOKEN not set")
def test_content_get_known_canonical_uuid() -> None:
    """Bearer-token auth path: /content-delivery returns flat content shape.

    Uses the canonical test publisher's known article UUID from the live-db seed
    (see opedd-backend reference_backend_test_seed memory). Read-only.

    NOTE: This test depends on the live-db seed being intact. If the seed is
    pruned or migrated, this test surfaces the seed-drift issue.
    """
    # Use a stable sandbox-accessible article from the canonical test publisher
    # publisher 8268c353-ffa3-4db3-bbb2-90ddbbb43e41 (test@example.com)
    # First article from /publisher-directory sampling is the simplest probe.
    # For deterministic test, fetch directory first.
    import httpx

    directory = httpx.get(
        "https://api.opedd.com/publisher-directory",
        params={"min_articles": 1, "limit": 5},
        timeout=30.0,
    ).json()
    publishers = directory.get("data", {}).get("publishers", [])
    pytest.skip_if_no_sample = lambda: pytest.skip("no sample article available")
    if not publishers or not publishers[0].get("sample_articles"):
        pytest.skip("no sample article available in directory")
    sample_id = publishers[0]["sample_articles"][0]["id"]

    with Opedd() as client:
        article = client.content.get(sample_id)
    assert "id" in article or "title" in article


@pytest.mark.skipif(not _has_env("OPEDD_ACCESS_KEY"), reason="OPEDD_ACCESS_KEY not set")
def test_feed_list_with_access_key() -> None:
    """access_key query-param path: /enterprise-license JSON returns articles[]."""
    with Opedd() as client:
        result = client.feed.list(limit=2)
    assert result.get("success") is True
    assert "data" in result
