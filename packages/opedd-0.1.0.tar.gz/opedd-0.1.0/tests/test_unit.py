"""Unit tests with mocked HTTPX. Run in CI; no live API calls.

Coverage targets:
- Client construction and credential precedence (constructor args > env vars)
- Auth header construction per credential type
- Response unwrapping for endpoints that return both flat + envelope shapes
- Exception mapping per HTTP status class
- NDJSON streaming generator: per-line yield + cursor pagination
- Each namespace produces a request hitting the expected path
"""

from __future__ import annotations

import json
from typing import Any

import pytest
from pytest_httpx import HTTPXMock

from opedd import (
    Opedd,
    OpeddAuthError,
    OpeddError,
    OpeddNotFoundError,
    OpeddRateLimitError,
    OpeddServerError,
    OpeddValidationError,
    __schema_version__,
    __version__,
)

BASE = "https://api.opedd.com"


def make_client(**overrides: Any) -> Opedd:
    """Helper: construct a client with sane defaults for testing."""
    kwargs: dict[str, Any] = {
        "buyer_token": "opedd_buyer_test_abc",
        "buyer_jwt": "test-jwt",
        "access_key": "eak_test",
    }
    kwargs.update(overrides)
    return Opedd(**kwargs)


# ───────────────────────────── construction ─────────────────────────────


def test_version_and_schema_pin() -> None:
    assert __version__ == "0.1.0"
    assert __schema_version__ == "phase-11-m4"


def test_construction_requires_at_least_one_credential() -> None:
    with pytest.raises(OpeddError, match="at least one of"):
        Opedd()


def test_base_url_normalization() -> None:
    client = make_client(base_url="https://staging.opedd.com/")
    assert client.base_url == "https://staging.opedd.com"


def test_env_vars_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPEDD_BUYER_TOKEN", "env-token")
    monkeypatch.setenv("OPEDD_BUYER_JWT", "env-jwt")
    monkeypatch.setenv("OPEDD_ACCESS_KEY", "env-key")
    monkeypatch.setenv("OPEDD_BASE_URL", "https://env.opedd.com")
    client = Opedd()
    assert client.buyer_token == "env-token"
    assert client.buyer_jwt == "env-jwt"
    assert client.access_key == "env-key"
    assert client.base_url == "https://env.opedd.com"


def test_constructor_args_override_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPEDD_BUYER_TOKEN", "env-token")
    client = make_client(buyer_token="explicit-token")
    assert client.buyer_token == "explicit-token"


# ───────────────────────────── auth headers ─────────────────────────────


def test_bearer_headers_require_buyer_token() -> None:
    client = Opedd(buyer_jwt="jwt-only")
    with pytest.raises(OpeddAuthError, match="buyer_token"):
        client._bearer_headers()


def test_jwt_headers_require_buyer_jwt() -> None:
    client = Opedd(buyer_token="token-only")
    with pytest.raises(OpeddAuthError, match="buyer_jwt"):
        client._jwt_headers()


def test_access_key_params_require_access_key() -> None:
    client = Opedd(buyer_token="token-only")
    with pytest.raises(OpeddAuthError, match="access_key"):
        client._access_key_params()


# ───────────────────────────── error mapping ─────────────────────────────


@pytest.mark.parametrize(
    "status_code,error_body,expected_exc",
    [
        (401, {"error": "Invalid bearer token"}, OpeddAuthError),
        (403, {"error": "Forbidden"}, OpeddAuthError),
        (404, {"error": "Article not found"}, OpeddNotFoundError),
        (400, {"error": "Bad request"}, OpeddValidationError),
        (422, {"error": "Validation failed"}, OpeddValidationError),
        (429, {"error": "rate_limit_exceeded", "retry_after_seconds": 60}, OpeddRateLimitError),
        (500, {"error": "Internal error"}, OpeddServerError),
        (502, {"error": "Bad gateway"}, OpeddServerError),
    ],
)
def test_error_status_mapping(
    httpx_mock: HTTPXMock,
    status_code: int,
    error_body: dict[str, Any],
    expected_exc: type[OpeddError],
) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/content-delivery?article_id=test",
        status_code=status_code,
        json=error_body,
    )
    client = make_client()
    with pytest.raises(expected_exc):
        client.content.get("test")


def test_429_carries_retry_after_seconds(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/content-delivery?article_id=test",
        status_code=429,
        json={"error": "rate_limit_exceeded", "retry_after_seconds": 42},
    )
    client = make_client()
    with pytest.raises(OpeddRateLimitError) as exc_info:
        client.content.get("test")
    assert exc_info.value.retry_after_seconds == 42


def test_request_id_propagated_on_error(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/content-delivery?article_id=test",
        status_code=404,
        json={"error": "not found"},
        headers={"X-Opedd-Request-Id": "req_abc123"},
    )
    client = make_client()
    with pytest.raises(OpeddNotFoundError) as exc_info:
        client.content.get("test")
    assert exc_info.value.request_id == "req_abc123"


def test_phase_8_nested_error_envelope(httpx_mock: HTTPXMock) -> None:
    """Phase 8 endpoints use {error: {code, message, details}} envelope."""
    httpx_mock.add_response(
        url=f"{BASE}/content-delivery?article_id=test",
        status_code=422,
        json={
            "success": False,
            "error": {"code": "VALIDATION_FAILED", "message": "Invalid input", "details": {"zod": "..."}},
        },
    )
    client = make_client()
    with pytest.raises(OpeddValidationError, match="Invalid input"):
        client.content.get("test")


# ───────────────────────────── content namespace ─────────────────────────────


def test_content_get_returns_data_field_when_envelope_present(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/content-delivery?article_id=art-123",
        json={
            "success": True,
            "data": {"id": "art-123", "title": "Hello", "content": "Body", "word_count": 100},
        },
    )
    client = make_client()
    article = client.content.get("art-123")
    assert article["title"] == "Hello"
    assert article["word_count"] == 100


def test_content_get_returns_flat_shape_when_no_envelope(httpx_mock: HTTPXMock) -> None:
    """Some endpoints return flat shape directly."""
    httpx_mock.add_response(
        url=f"{BASE}/content-delivery?article_id=art-123",
        json={"id": "art-123", "title": "Hello", "content": "Body", "word_count": 100},
    )
    client = make_client()
    article = client.content.get("art-123")
    assert article["title"] == "Hello"


def test_content_get_sends_bearer_header(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/content-delivery?article_id=x",
        json={"data": {"id": "x"}},
    )
    client = make_client()
    client.content.get("x")
    request = httpx_mock.get_request()
    assert request.headers["Authorization"] == "Bearer opedd_buyer_test_abc"


# ───────────────────────────── feed namespace ─────────────────────────────


def test_feed_list_includes_access_key_in_params(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/enterprise-license?access_key=eak_test&format=json&limit=200",
        json={"success": True, "data": {"articles": [], "next_cursor": None}},
    )
    client = make_client()
    result = client.feed.list()
    assert result["success"] is True


def test_feed_list_passes_since_filter(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/enterprise-license?access_key=eak_test&format=json&limit=200&since=2026-05-01",
        json={"success": True, "data": {"articles": []}},
    )
    client = make_client()
    client.feed.list(since="2026-05-01")


def test_feed_stream_ndjson_yields_per_article_and_consumes_meta(httpx_mock: HTTPXMock) -> None:
    ndjson_body = (
        b'{"id":"art-1","title":"A","content":"x"}\n'
        b'{"id":"art-2","title":"B","content":"y"}\n'
        b'{"_meta":{"count":2,"truncated":false,"audit_event_id":"audit-1","request_id":"req_1"}}\n'
    )
    httpx_mock.add_response(
        url=f"{BASE}/enterprise-license?access_key=eak_test&format=ndjson&limit=5000",
        content=ndjson_body,
    )
    client = make_client()
    articles = list(client.feed.stream_ndjson())
    assert len(articles) == 2
    assert articles[0]["id"] == "art-1"
    assert articles[1]["id"] == "art-2"


def test_feed_stream_ndjson_auto_paginates_on_truncated(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/enterprise-license?access_key=eak_test&format=ndjson&limit=5000",
        content=(
            b'{"id":"art-1"}\n'
            b'{"_meta":{"count":1,"truncated":true,"next_cursor":"cur_page2"}}\n'
        ),
    )
    httpx_mock.add_response(
        url=f"{BASE}/enterprise-license?access_key=eak_test&format=ndjson&limit=5000&cursor=cur_page2",
        content=(
            b'{"id":"art-2"}\n'
            b'{"_meta":{"count":1,"truncated":false}}\n'
        ),
    )
    client = make_client()
    articles = list(client.feed.stream_ndjson())
    assert [a["id"] for a in articles] == ["art-1", "art-2"]


# ───────────────────────────── audit namespace ─────────────────────────────


def test_audit_events_uses_jwt(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/buyer-audit?limit=100",
        json={"success": True, "events": []},
    )
    client = make_client()
    client.audit.events()
    request = httpx_mock.get_request()
    assert request.headers["Authorization"] == "Bearer test-jwt"


def test_audit_events_passes_window_and_filter(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/buyer-audit?limit=50&from=2026-05-01&to=2026-05-15&event_type=content_access",
        json={"success": True, "events": []},
    )
    client = make_client()
    client.audit.events(from_="2026-05-01", to="2026-05-15", event_type="content_access", limit=50)


# ───────────────────────────── compliance namespace ─────────────────────────────


def test_compliance_report_required_window(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/buyer-compliance-report?from=2026-04-01&to=2026-04-30&format=json",
        json={
            "success": True,
            "dossier_metadata": {
                "summary": {"total_retrievals": 14523},
                "compliance_framework_anchors": {
                    "eu_ai_act_article_53_evidenced": True,
                    "cdsm_article_4_optout_honored": True,
                },
            },
            "retrievals": [],
            "_meta": {"audit_event_id": "self-audit-1", "schema_version": "phase-11-m4"},
        },
    )
    client = make_client()
    dossier = client.compliance.report(from_="2026-04-01", to="2026-04-30")
    assert dossier["dossier_metadata"]["summary"]["total_retrievals"] == 14523
    assert dossier["_meta"]["audit_event_id"] == "self-audit-1"


# ───────────────────────────── licenses namespace ─────────────────────────────


def test_licenses_purchase_posts_expected_body(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/enterprise-license",
        method="POST",
        json={
            "success": True,
            "data": {
                "enterprise_license_id": "lic-1",
                "stripe_client_secret": "cs_test_xyz",
                "checkout_url": "https://checkout.stripe.com/c/pay/cs_test_xyz",
            },
        },
    )
    client = make_client()
    resp = client.licenses.purchase(
        publisher_ids=["pub-1", "pub-2"],
        buyer_email="eng@example.com",
        buyer_org="Test Lab",
        billing_type="annual",
        license_tier="training",
    )
    assert resp["data"]["enterprise_license_id"] == "lic-1"
    request = httpx_mock.get_request()
    assert request.method == "POST"
    body = json.loads(request.content)
    assert body["publisher_ids"] == ["pub-1", "pub-2"]
    assert body["license_tier"] == "training"


# ───────────────────────────── context manager ─────────────────────────────


def test_client_context_manager_closes_http_pool() -> None:
    with make_client() as client:
        assert client._http is not None
    # Post-exit: client._http._client is closed; subsequent operations would fail


# ───────────────────────────── from_access_key ─────────────────────────────


def test_from_access_key_exchanges_for_bearer_token(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/enterprise-auth",
        method="POST",
        json={"success": True, "data": {"bearer_token": "opedd_buyer_live_xxx"}},
    )
    client = Opedd.from_access_key(access_key="eak_xyz", buyer_email="e@example.com")
    assert client.buyer_token == "opedd_buyer_live_xxx"
    assert client.access_key == "eak_xyz"


def test_from_access_key_raises_on_exchange_failure(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/enterprise-auth",
        method="POST",
        status_code=401,
        json={"error": "invalid access key"},
    )
    with pytest.raises(OpeddAuthError, match="access_key exchange failed"):
        Opedd.from_access_key(access_key="eak_bad", buyer_email="e@example.com")
