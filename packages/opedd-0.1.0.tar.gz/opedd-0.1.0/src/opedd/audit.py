"""client.audit — per-event audit browse with on-chain inclusion proofs.

Endpoint: ``GET /buyer-audit``

Auth: Supabase JWT (buyer_jwt).

For procurement-defense-grade dossiers, use ``client.compliance.report()`` —
``/buyer-audit`` is the lighter-weight per-event browse endpoint.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from . import Opedd


class AuditNamespace:
    """Per-event audit access for licensed buyers."""

    def __init__(self, client: Opedd) -> None:
        self._client = client

    def events(
        self,
        *,
        from_: str | None = None,
        to: str | None = None,
        event_type: str | None = None,
        cursor: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        """Browse per-event audit rows.

        Args:
            from_: ISO-8601 timestamp lower bound (inclusive).
            to: ISO-8601 timestamp upper bound (inclusive).
            event_type: Filter to a specific event class
                (e.g., ``"content_access"``, ``"bulk_content_access"``,
                ``"compliance_report_generated"``).
            cursor: Opaque cursor for pagination.
            limit: Max rows per response. Default 100, max bounded by backend.

        Returns:
            Dict containing ``events[]`` array, each row with ``event_id``,
            ``event_type``, ``retrieved_at``, ``article`` (when applicable),
            ``license_terms``, and ``attestation`` block (with ``inclusion_proof``
            when ``blockchain_status='confirmed'``).

        Window cap: 30 days (vs 90-day cap on ``client.compliance.report()``).
        Rate limit: 100/min per buyer.
        """
        params: dict[str, Any] = {"limit": limit}
        if from_:
            params["from"] = from_
        if to:
            params["to"] = to
        if event_type:
            params["event_type"] = event_type
        if cursor:
            params["cursor"] = cursor

        return self._client._http.get(
            "/buyer-audit",
            params=params,
            headers=self._client._jwt_headers(),
        )
