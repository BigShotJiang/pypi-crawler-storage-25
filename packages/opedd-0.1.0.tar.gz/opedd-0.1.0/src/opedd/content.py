"""client.content — fetch licensed article content.

Endpoint: ``GET /content-delivery``

Auth: buyer_token (sandbox returns truncated content; live returns full).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from . import Opedd


class ContentNamespace:
    """Article retrieval for licensed buyers."""

    def __init__(self, client: Opedd) -> None:
        self._client = client

    def get(self, article_id: str) -> dict[str, Any]:
        """Fetch a single article by UUID.

        Args:
            article_id: Article UUID (from publisher-directory or feed listings).

        Returns:
            Dict with at least these keys (Phase 11 M2 RAG-extended shape):
            ``id``, ``title``, ``content``, ``url``, ``published_at``, ``author``,
            ``language``, ``word_count``, ``content_hash``, ``image_urls``,
            ``canonical_url``, ``tags``, ``publisher``, ``sandbox`` (bool).

        Note:
            ``content`` is truncated to 500 chars when ``sandbox=True``.
            For full content, use a live ``opedd_buyer_live_*`` token.

            NULL on optional fields (author / language / image_urls / canonical_url /
            tags) means "data unavailable for this article," NOT "explicitly empty."
            Treat as data-missing; do not interpret as anti-match.
        """
        body = self._client._http.get(
            "/content-delivery",
            params={"article_id": article_id},
            headers=self._client._bearer_headers(),
        )
        # /content-delivery returns flat shape (no nested data envelope on success)
        if "data" in body and isinstance(body["data"], dict):
            return body["data"]
        return body
