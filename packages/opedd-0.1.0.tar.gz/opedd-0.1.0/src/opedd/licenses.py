"""client.licenses — purchase + list enterprise licenses.

Endpoint: ``POST /enterprise-license`` (purchase), ``GET /buyer-account`` (list).

Auth: ``POST`` is unauthenticated (returns a Stripe ``client_secret`` for payment
completion); ``GET`` requires Supabase JWT.

For the full purchase flow (sandbox → catalog → license → access key →
bearer token), see https://docs.opedd.com/cookbook-rag-bulk-export.md.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from . import Opedd


class LicensesNamespace:
    """Enterprise license purchase + listing."""

    def __init__(self, client: Opedd) -> None:
        self._client = client

    def purchase(
        self,
        *,
        publisher_ids: list[str],
        buyer_email: str,
        buyer_org: str,
        billing_type: str = "annual",
        license_tier: str = "rag",
        duration_months: int = 12,
        scope: str = "custom",
        filter_rules: dict[str, Any] | None = None,
        buyer_webhook_url: str | None = None,
    ) -> dict[str, Any]:
        """Create an enterprise license and return Stripe payment intent.

        Args:
            publisher_ids: Array of publisher UUIDs. Required for ``scope='custom'``.
                Ignored for ``scope='platform_wide'`` or ``scope='filtered'``
                (resolved server-side from ``filter_rules`` / opted-in publishers).
            buyer_email: Email to deliver the access key (eak_*) after payment.
            buyer_org: Buyer organization name for billing + audit ledger.
            billing_type: ``"annual"``, ``"monthly"``, or ``"annual_plus_monthly"``.
            license_tier: ``"rag"`` (= ``ai_retrieval``), ``"training"``
                (= ``ai_training``), ``"inference"`` (= ``ai_retrieval``),
                ``"full_ai"`` (= ``ai_retrieval`` + ``ai_training``).
            duration_months: Length of license. Default 12.
            scope: ``"custom"``, ``"platform_wide"``, or ``"filtered"`` (Phase 10).
            filter_rules: Required when ``scope='filtered'``. See Phase 10 docs
                for ``excluded_publisher_ids`` / ``direct_license_carveouts`` /
                ``categories`` / ``max_price_per_event`` schema.
            buyer_webhook_url: Optional. HMAC-SHA256 signed webhook for
                ``content.published`` events on covered publishers.

        Returns:
            Dict with ``enterprise_license_id``, ``stripe_client_secret``,
            ``checkout_url``.

        After payment completion, the buyer receives an ``eak_*`` access key
        via email; use ``Opedd.from_access_key()`` to authenticate.
        """
        body: dict[str, Any] = {
            "publisher_ids": publisher_ids,
            "buyer_email": buyer_email,
            "buyer_org": buyer_org,
            "billing_type": billing_type,
            "license_tier": license_tier,
            "duration_months": duration_months,
            "scope": scope,
        }
        if filter_rules:
            body["filter_rules"] = filter_rules
        if buyer_webhook_url:
            body["buyer_webhook_url"] = buyer_webhook_url

        return self._client._http.post("/enterprise-license", json_body=body)

    def list(self) -> dict[str, Any]:
        """List licenses owned by the authenticated buyer (Supabase JWT auth).

        Returns the ``enterprise_buyers`` row + masked API key list. Plaintext
        access keys are NEVER returned post-issuance; only ``key_prefix`` (12 chars).

        For full mid-lifecycle license details (filter_rules, billing, payouts),
        consult the buyer portal at opedd.com/buyer.
        """
        return self._client._http.get(
            "/buyer-account",
            headers=self._client._jwt_headers(),
        )
