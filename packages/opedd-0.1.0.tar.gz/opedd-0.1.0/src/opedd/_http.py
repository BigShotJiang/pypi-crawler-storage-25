"""HTTP client wrapper that handles auth, response unwrapping, and error mapping.

Wire-format contract (mirrors backend convention):
- Successful response body is flat (no nested ``data.data`` envelope on most endpoints).
- Error response: ``{"success": false, "error": "..."}`` or ``{"success": false, "error": {"code": "...", "message": "...", "details": {...}}}``.
- ``X-Opedd-Request-Id`` header carried back for forensic correlation.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from typing import Any

import httpx

from ._exceptions import (
    OpeddAuthError,
    OpeddError,
    OpeddNotFoundError,
    OpeddRateLimitError,
    OpeddServerError,
    OpeddValidationError,
)


class HttpClient:
    """Thin wrapper around httpx.Client that normalizes auth + errors."""

    def __init__(self, base_url: str, timeout: float = 300.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client = httpx.Client(timeout=timeout)

    def get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """GET ``base_url + path``, return parsed JSON body. Raises on non-2xx."""
        resp = self._client.get(
            f"{self.base_url}{path}",
            params=params,
            headers=headers,
        )
        return self._parse(resp)

    def post(
        self,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """POST ``base_url + path``, return parsed JSON body. Raises on non-2xx."""
        resp = self._client.post(
            f"{self.base_url}{path}",
            json=json_body,
            params=params,
            headers=headers,
        )
        return self._parse(resp)

    def stream_ndjson(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Iterator[dict[str, Any]]:
        """GET ``base_url + path`` and yield each NDJSON line as a parsed dict.

        Yields per-article rows AND the trailing ``_meta`` row (the caller is
        expected to recognize ``"_meta" in row`` and act accordingly).
        """
        with self._client.stream(
            "GET",
            f"{self.base_url}{path}",
            params=params,
            headers=headers,
        ) as resp:
            if resp.status_code != 200:
                resp.read()
                self._raise_for_status(resp)
            for line in resp.iter_lines():
                if not line:
                    continue
                yield json.loads(line)

    def close(self) -> None:
        self._client.close()

    def _parse(self, resp: httpx.Response) -> dict[str, Any]:
        if resp.status_code >= 400:
            self._raise_for_status(resp)
        try:
            return resp.json()
        except json.JSONDecodeError as e:
            raise OpeddError(
                f"Non-JSON response: {resp.text[:500]}",
                status_code=resp.status_code,
            ) from e

    def _raise_for_status(self, resp: httpx.Response) -> None:
        """Map backend error response to typed exception."""
        request_id = resp.headers.get("X-Opedd-Request-Id")

        try:
            body: dict[str, Any] = resp.json()
        except (json.JSONDecodeError, ValueError):
            body = {"error": resp.text[:500] or f"HTTP {resp.status_code}"}

        error_field = body.get("error")
        if isinstance(error_field, dict):
            message = error_field.get("message") or error_field.get("code") or f"HTTP {resp.status_code}"
        elif isinstance(error_field, str):
            message = error_field
        else:
            message = body.get("message") or f"HTTP {resp.status_code}"

        kwargs = {
            "status_code": resp.status_code,
            "request_id": request_id,
            "body": body,
        }

        if resp.status_code in (401, 403):
            raise OpeddAuthError(message, **kwargs)
        if resp.status_code == 404:
            raise OpeddNotFoundError(message, **kwargs)
        if resp.status_code in (400, 422):
            raise OpeddValidationError(message, **kwargs)
        if resp.status_code == 429:
            retry_after: int | None = None
            if isinstance(body.get("retry_after_seconds"), int):
                retry_after = body["retry_after_seconds"]
            raise OpeddRateLimitError(message, retry_after_seconds=retry_after, **kwargs)
        if resp.status_code >= 500:
            raise OpeddServerError(message, **kwargs)
        raise OpeddError(message, **kwargs)
