"""Exception types raised by the Opedd SDK.

All Opedd-specific errors inherit from ``OpeddError``. Each subclass corresponds
to a backend HTTP status class so callers can catch precisely:

    try:
        client.content.get(uuid)
    except OpeddRateLimitError as e:
        time.sleep(e.retry_after_seconds)
        retry()
    except OpeddNotFoundError:
        log.warning("article gone; skipping")
    except OpeddError as e:
        # Catch-all for anything else
        log.error(e)
"""

from __future__ import annotations

from typing import Any


class OpeddError(Exception):
    """Base class for all Opedd SDK errors."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        request_id: str | None = None,
        body: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.request_id = request_id
        self.body = body

    def __str__(self) -> str:
        parts = [self.message]
        if self.status_code:
            parts.append(f"(HTTP {self.status_code})")
        if self.request_id:
            parts.append(f"[request_id={self.request_id}]")
        return " ".join(parts)


class OpeddAuthError(OpeddError):
    """401/403 — authentication or authorization failure."""


class OpeddNotFoundError(OpeddError):
    """404 — resource not found."""


class OpeddValidationError(OpeddError):
    """400/422 — request body or params malformed."""


class OpeddRateLimitError(OpeddError):
    """429 — rate limit exceeded.

    Attributes:
        retry_after_seconds: Backend-provided retry hint (None if not surfaced).
    """

    def __init__(
        self,
        message: str,
        *,
        retry_after_seconds: int | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(message, **kwargs)
        self.retry_after_seconds = retry_after_seconds


class OpeddServerError(OpeddError):
    """5xx — server error. Usually safe to retry."""
