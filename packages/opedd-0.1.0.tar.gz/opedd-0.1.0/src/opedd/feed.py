"""client.feed — paginated + streaming access to licensed catalogs.

Endpoint: ``GET /enterprise-license``

Auth: ``?access_key=eak_*`` query param (no token exchange required).

Two methods:
- ``list(...)`` — returns a single dict response (up to ``limit`` articles).
- ``stream_ndjson(...)`` — generator yielding articles one at a time, suitable
  for streaming bulk-ingest pipelines without holding the full corpus in memory.

The ``?since=`` parameter filters to articles with ``published_at > since`` —
the buyer-side delta-feed pattern. See
https://docs.opedd.com/cookbook-delta-feed-polling.md for the polling cookbook.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from . import Opedd


class FeedNamespace:
    """Catalog feeds for licensed buyers."""

    def __init__(self, client: Opedd) -> None:
        self._client = client

    def list(
        self,
        *,
        since: str | None = None,
        cursor: str | None = None,
        limit: int = 200,
    ) -> dict[str, Any]:
        """Fetch one page of licensed articles in JSON format.

        Args:
            since: ISO-8601 timestamp. Returns articles with ``published_at > since``.
                Optional; omit to get the full licensed catalog.
            cursor: Opaque cursor from the previous response's ``next_cursor``.
            limit: Max articles per response. Default 200, max 200 in JSON mode.

        Returns:
            Dict shape:
                {
                    "success": True,
                    "data": {
                        "articles": [{...}, ...],
                        "next_cursor": "opaque-string" | None,
                        "count": int,
                        "truncated": bool,
                    },
                    "_meta": {"schema_version": "...", "request_id": "..."},
                }

        Use ``stream_ndjson`` for >200-article bulk ingest.
        """
        params: dict[str, Any] = {
            **self._client._access_key_params(),
            "format": "json",
            "limit": limit,
        }
        if since:
            params["since"] = since
        if cursor:
            params["cursor"] = cursor

        return self._client._http.get("/enterprise-license", params=params)

    def stream_ndjson(
        self,
        *,
        since: str | None = None,
        cursor: str | None = None,
        limit: int = 5000,
    ) -> Iterator[dict[str, Any]]:
        """Stream licensed articles as NDJSON, one dict per article.

        Auto-paginates across multiple HTTP requests until ``_meta.truncated == false``.
        Yields per-article dicts only; the ``_meta`` trailing row is consumed internally.

        Args:
            since: ISO-8601 timestamp. Returns articles with ``published_at > since``.
            cursor: Opaque cursor from a previous response's ``next_cursor``. Usually
                omitted on first call; the generator handles cursor propagation.
            limit: Max articles per HTTP request. Default 5000 (NDJSON cap).
                Total returned is unbounded across pagination.

        Yields:
            One article dict per yield, matching the
            ``GET /enterprise-license?format=ndjson`` per-line shape.

        Example:

            for article in client.feed.stream_ndjson(since="2026-05-01", limit=5000):
                train_model.ingest(article["content"], metadata=article)

        Audit trail: every streamed article emits one ``usage_records`` row
        (sentinel ``stripe_usage_record_id = 'bulk-export:<request_id>:<article_id>'``;
        analytics-only, not metered-billable). One ``license_events`` envelope row
        per HTTP call; the trailing ``_meta.audit_event_id`` is logged for forensic
        correlation but not yielded.
        """
        current_cursor = cursor

        while True:
            params: dict[str, Any] = {
                **self._client._access_key_params(),
                "format": "ndjson",
                "limit": limit,
            }
            if since:
                params["since"] = since
            if current_cursor:
                params["cursor"] = current_cursor

            meta: dict[str, Any] | None = None
            for row in self._client._http.stream_ndjson("/enterprise-license", params=params):
                if "_meta" in row:
                    meta = row["_meta"]
                    continue
                yield row

            if not meta or not meta.get("truncated"):
                return
            next_cursor = meta.get("next_cursor")
            if not next_cursor:
                return
            current_cursor = next_cursor
