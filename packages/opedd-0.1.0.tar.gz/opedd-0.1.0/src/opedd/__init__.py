"""Official Python SDK for the Opedd content licensing API (buyer-side).

Quick start:

    from opedd import Opedd

    client = Opedd(buyer_token="opedd_buyer_live_...")

    article = client.content.get("article-uuid")
    print(article["title"], article["author"], article["word_count"])

See https://docs.opedd.com/cookbook.md for end-to-end walkthroughs.
"""

from __future__ import annotations

import os
from typing import Any

from ._exceptions import (
    OpeddAuthError,
    OpeddError,
    OpeddNotFoundError,
    OpeddRateLimitError,
    OpeddServerError,
    OpeddValidationError,
)
from ._http import HttpClient
from .audit import AuditNamespace
from .compliance import ComplianceNamespace
from .content import ContentNamespace
from .feed import FeedNamespace
from .licenses import LicensesNamespace

__version__ = "0.1.0"
__schema_version__ = "phase-11-m4"

__all__ = [
    "Opedd",
    "OpeddAuthError",
    "OpeddError",
    "OpeddNotFoundError",
    "OpeddRateLimitError",
    "OpeddServerError",
    "OpeddValidationError",
    "__schema_version__",
    "__version__",
]


class Opedd:
    """Opedd buyer-side API client.

    Args:
        buyer_token: An ``opedd_buyer_live_<32-hex>`` or ``opedd_buyer_test_<32-hex>``
            token issued by ``POST /enterprise-auth``. Used for ``/content-delivery``
            and ``/enterprise-license`` calls.
        buyer_jwt: A Supabase session JWT for the buyer portal. Used for
            ``/buyer-audit`` and ``/buyer-compliance-report`` calls.
        access_key: An ``eak_*`` enterprise access key. Some endpoints
            (``/enterprise-license`` GET) accept this directly via ``?access_key=``
            query param, no token exchange required.
        base_url: Override the API base URL (default ``https://api.opedd.com``).
            Useful for local testing or staging environments.
        timeout: HTTP timeout in seconds. Default 300 (long enough for NDJSON streaming).

    Notes:
        At least one of ``buyer_token``, ``buyer_jwt``, or ``access_key`` must be
        provided. Different endpoints accept different credentials — see method
        docstrings for which credential each method requires.

        Env-var fallbacks: ``OPEDD_BUYER_TOKEN``, ``OPEDD_BUYER_JWT``,
        ``OPEDD_ACCESS_KEY``, ``OPEDD_BASE_URL``.

    Example:

        client = Opedd(buyer_token="opedd_buyer_live_...")
        article = client.content.get("uuid")

        for row in client.feed.stream_ndjson(limit=5000):
            train_model.ingest(row)

        dossier = client.compliance.report(from_="2026-04-01", to="2026-04-30")
    """

    def __init__(
        self,
        buyer_token: str | None = None,
        buyer_jwt: str | None = None,
        access_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 300.0,
    ) -> None:
        self.buyer_token = buyer_token or os.environ.get("OPEDD_BUYER_TOKEN")
        self.buyer_jwt = buyer_jwt or os.environ.get("OPEDD_BUYER_JWT")
        self.access_key = access_key or os.environ.get("OPEDD_ACCESS_KEY")
        self.base_url = (base_url or os.environ.get("OPEDD_BASE_URL") or "https://api.opedd.com").rstrip("/")
        self.timeout = timeout

        if not any([self.buyer_token, self.buyer_jwt, self.access_key]):
            raise OpeddError(
                "Opedd client requires at least one of: buyer_token, buyer_jwt, access_key. "
                "See https://docs.opedd.com/python-sdk.md for the credential matrix."
            )

        self._http = HttpClient(self.base_url, timeout=timeout)

        self.content = ContentNamespace(self)
        self.feed = FeedNamespace(self)
        self.audit = AuditNamespace(self)
        self.compliance = ComplianceNamespace(self)
        self.licenses = LicensesNamespace(self)

    @classmethod
    def from_access_key(
        cls,
        access_key: str,
        buyer_email: str,
        base_url: str | None = None,
    ) -> Opedd:
        """Exchange an eak_* access key for a bearer token, return an authenticated client.

        Calls ``POST /enterprise-auth`` under the hood. Useful when you only
        have the access key emailed to you after license purchase.
        """
        import httpx

        base = (base_url or os.environ.get("OPEDD_BASE_URL") or "https://api.opedd.com").rstrip("/")
        resp = httpx.post(
            f"{base}/enterprise-auth",
            json={"access_key": access_key, "buyer_email": buyer_email},
            timeout=30.0,
        )
        if resp.status_code != 200:
            raise OpeddAuthError(
                f"access_key exchange failed: {resp.status_code} {resp.text}",
                status_code=resp.status_code,
            )
        body = resp.json()
        bearer_token = body.get("data", {}).get("bearer_token") or body.get("bearer_token")
        if not bearer_token:
            raise OpeddAuthError(
                f"access_key exchange returned no bearer_token: {body}",
            )
        return cls(buyer_token=bearer_token, access_key=access_key, base_url=base_url)

    def _bearer_headers(self) -> dict[str, str]:
        """Build Authorization headers for endpoints that accept buyer_token."""
        if not self.buyer_token:
            raise OpeddAuthError("This method requires buyer_token. Pass it at construction or set OPEDD_BUYER_TOKEN.")
        return {"Authorization": f"Bearer {self.buyer_token}"}

    def _jwt_headers(self) -> dict[str, str]:
        """Build Authorization headers for endpoints that accept Supabase JWT."""
        if not self.buyer_jwt:
            raise OpeddAuthError("This method requires buyer_jwt. Pass it at construction or set OPEDD_BUYER_JWT.")
        return {"Authorization": f"Bearer {self.buyer_jwt}"}

    def _access_key_params(self) -> dict[str, str]:
        """Build query params for endpoints that accept ?access_key=."""
        if not self.access_key:
            raise OpeddAuthError("This method requires access_key. Pass it at construction or set OPEDD_ACCESS_KEY.")
        return {"access_key": self.access_key}

    def close(self) -> None:
        """Close the underlying HTTP client connection pool."""
        self._http.close()

    def __enter__(self) -> Opedd:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
