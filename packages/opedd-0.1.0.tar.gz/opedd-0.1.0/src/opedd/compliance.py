"""client.compliance — procurement-defense compliance dossiers.

Endpoint: ``GET /buyer-compliance-report``

Auth: Supabase JWT (buyer_jwt).

The dossier is the buyer-side procurement-defense artifact. Every retrieval
within the date range, mapped to license terms, with Tempo Merkle attestation
hashes inline + on-chain verification URLs. Audit-defensibility under
EU AI Act Article 53 + CDSM Article 4 + post-Anthropic-settlement scrutiny.

See https://docs.opedd.com/cookbook-compliance-dossier.md for end-to-end usage.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from . import Opedd


class ComplianceNamespace:
    """Procurement-defense compliance dossier access."""

    def __init__(self, client: Opedd) -> None:
        self._client = client

    def report(
        self,
        *,
        from_: str,
        to: str,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """Generate a compliance dossier covering [from_, to].

        Args:
            from_: ISO-8601 timestamp lower bound (inclusive).
            to: ISO-8601 timestamp upper bound (inclusive).
            cursor: Opaque cursor for pagination across windows > the natural
                response size.

        Returns:
            Dict with these top-level keys:

            - ``dossier_metadata.buyer`` — buyer identity
            - ``dossier_metadata.window`` — confirmed window (echo of from/to)
            - ``dossier_metadata.summary`` — total_retrievals, unique_articles,
              unique_publishers, event_class_breakdown
            - ``dossier_metadata.platform`` — schema_version, contract_version
            - ``dossier_metadata.compliance_framework_anchors`` — boolean flags
              for EU AI Act Article 53, CDSM Article 4(3), on-chain attestation,
              TDM reservation; plus ``framework_documentation_url``
            - ``retrievals[]`` — array of per-row dossier entries (25+ fields each)
            - ``_meta.audit_event_id`` — references the self-audit row written
              before the dossier was returned (chain-of-custody)
            - ``_meta.next_cursor`` — pagination cursor or None
            - ``_meta.schema_version`` — pinned to ``phase-11-m4``
            - ``_meta.request_id``

        Window cap: 90 days per request. For annual audits, paginate across 4
        quarterly windows.

        Rate limit: 30/min per buyer.

        Self-audit invariant: every successful call writes one ``license_events``
        row with ``event_type='compliance_report_generated'`` BEFORE returning
        the dossier. The trailing ``_meta.audit_event_id`` references this row.

        Bulk fan-out: ``bulk_content_access`` envelopes expand into N retrieval
        rows by iterating the envelope's ``metadata.article_ids[]``. All N rows
        share the same ``on_chain_attestation.merkle_root``
        (``attestation_granularity: "envelope"``).
        """
        params: dict[str, Any] = {
            "from": from_,
            "to": to,
            "format": "json",
        }
        if cursor:
            params["cursor"] = cursor

        return self._client._http.get(
            "/buyer-compliance-report",
            params=params,
            headers=self._client._jwt_headers(),
        )
