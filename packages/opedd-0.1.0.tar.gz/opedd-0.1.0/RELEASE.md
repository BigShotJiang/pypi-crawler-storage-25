# Release process for opedd-python

This document codifies the SDK release discipline established in Phase 11 M6.

## Trigger

A release ships when:

1. The backend bumps `X-Opedd-Schema-Version` on any buyer-facing endpoint, AND the bump requires a wrapper change (additive bumps are absorbed transparently; subtractive/rename bumps require code).
2. A new buyer-side endpoint ships in the backend (e.g., Phase 12 onwards).
3. A bug is fixed in the SDK itself.
4. A new minor feature lands in the SDK (e.g., new error type, retry helper).

Per the [schema-pin invariant](https://github.com/Opedd/opedd-backend/blob/main/INVARIANTS.md#python-sdk--mcp-server-pin-to-backend-x-opedd-schema-version-phase-11-m6), backend schema bumps trigger a follow-up SDK release within 1 sprint.

## Version-bump rules

- **MAJOR** (1.0.0 → 2.0.0): breaking SDK API change — method removed/renamed, parameter signature change.
- **MINOR** (0.1.0 → 0.2.0): new endpoint surface, new namespace, new optional parameter, backend schema-pin bump.
- **PATCH** (0.1.0 → 0.1.1): bug fix, doc update, dependency-version bump that doesn't change behavior.

While the SDK is pre-1.0, MINOR bumps are also acceptable for behavior-breaking changes; the README + CHANGELOG must call them out explicitly.

## Pre-release checklist

1. **Update `__version__`** in `src/opedd/__init__.py` AND `version` in `pyproject.toml`.
2. **Update `__schema_version__`** if the backend bumped any buyer-facing endpoint schema version.
3. **Update `CHANGELOG.md`** with a new section dated today's UTC date.
4. **Run unit tests**: `pytest tests/test_unit.py` — must be all-green.
5. **Run integration tests locally** with founder credentials:
   ```bash
   export OPEDD_BUYER_JWT="..."
   export OPEDD_BUYER_TOKEN="..."
   export OPEDD_ACCESS_KEY="..."
   pytest --integration
   ```
   Per founder M6 ratification 6, integration tests do NOT run in CI — they run locally before each release. Verify all-green.
6. **Lint + type-check**: `ruff check src/ tests/` AND `mypy src/`. Must be clean.
7. **Build the package**: `pip install --upgrade build && python -m build`. Confirm `dist/opedd-<version>-py3-none-any.whl` and `dist/opedd-<version>.tar.gz` produced.
8. **Verify install from local wheel**: `pip install --force-reinstall dist/opedd-<version>-py3-none-any.whl && python -c "import opedd; print(opedd.__version__)"`.

## PyPI publish

```bash
pip install --upgrade twine
twine check dist/*
twine upload dist/*
```

You'll need a PyPI API token (`pypi-AgEIcHlw...`) stored either in `~/.pypirc`:

```ini
[pypi]
username = __token__
password = pypi-AgEIcHlw...
```

Or passed via `TWINE_USERNAME=__token__ TWINE_PASSWORD=pypi-...`.

Verify install from PyPI after upload (give the CDN ~30s to propagate):

```bash
pip install --upgrade opedd
python -c "import opedd; print(opedd.__version__, opedd.__schema_version__)"
```

## Git tag + GitHub release

```bash
git tag -a v0.1.0 -m "v0.1.0 — initial buyer-side SDK"
git push origin v0.1.0
gh release create v0.1.0 \
  --title "v0.1.0 — initial buyer-side SDK" \
  --notes-file CHANGELOG.md
```

## Post-release

- Cross-link from opedd-docs `python-sdk.md` if the README example block changed.
- If schema pin changed: update `opedd-backend/INVARIANTS.md` "Python SDK + MCP server pin to backend X-Opedd-Schema-Version" section with the new version.
- Email `support@opedd.com` (or whatever the buyer-facing channel is) if the bump is breaking.

## Yank / unpublish

If a release ships with a critical bug:

```bash
# Yank (preferred — removes from default index but keeps for pinned installs)
twine upload --skip-existing dist/opedd-<patched-version>-*  # ship the patch first
pip install --upgrade twine
# Then yank the broken version via PyPI web UI: https://pypi.org/manage/project/opedd/release/<version>/
```

NEVER fully delete a PyPI release; PyPI does not allow re-publishing the same version number, so deletion creates a permanent gap. Yank-then-patch is the canonical recovery path.

## CI

CI runs unit tests on every push (see `.github/workflows/ci.yml`). Integration tests run locally only (per Phase 11 M6 ratification 6: "SDK live tests running autonomously in CI could pollute usage_records, distort metered-publisher-payouts aggregation, fire production API calls with founder identity at scale").

## Maintenance schedule

- **Backend X-Opedd-Schema-Version bump**: ship follow-up SDK within 1 sprint per the schema-pin invariant.
- **Dependency security advisory (httpx, pytest)**: ship patch release within 1 week.
- **Python EOL versions (3.10 EOL October 2026)**: drop EOL'd versions in a MINOR bump, document in CHANGELOG.

See [opedd-backend/docs/cleanup/active-deferrals.md](https://github.com/Opedd/opedd-backend/blob/main/docs/cleanup/active-deferrals.md) for the institutional schema-pin maintenance discipline entry.
