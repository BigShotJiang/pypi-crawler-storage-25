# Changelog

All notable changes to opedd-python are documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/). This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] — 2026-05-15

Initial public release. Phase 11 M6 ship.

### Added

- `Opedd` client class with 5 namespaces:
  - `client.content.get(article_id)` — fetch licensed article (`GET /content-delivery`)
  - `client.feed.list(since, cursor, limit)` — paginated JSON catalog (`GET /enterprise-license?format=json`)
  - `client.feed.stream_ndjson(since, cursor, limit)` — NDJSON streaming generator (`GET /enterprise-license?format=ndjson`)
  - `client.audit.events(from_, to, event_type, cursor, limit)` — per-event audit browse (`GET /buyer-audit`)
  - `client.compliance.report(from_, to, cursor)` — procurement-defense dossier (`GET /buyer-compliance-report`)
  - `client.licenses.purchase(...)` — enterprise license purchase (`POST /enterprise-license`)
  - `client.licenses.list()` — buyer profile + masked key list (`GET /buyer-account`)
- Three credential modes:
  - `buyer_token` (bearer) for `/content-delivery`
  - `access_key` (query param) for `/enterprise-license` GET feed
  - `buyer_jwt` (Supabase session) for `/buyer-audit` + `/buyer-compliance-report` + `/buyer-account`
- Env-var fallbacks: `OPEDD_BUYER_TOKEN`, `OPEDD_BUYER_JWT`, `OPEDD_ACCESS_KEY`, `OPEDD_BASE_URL`
- `Opedd.from_access_key(access_key, buyer_email)` constructor that exchanges `eak_*` for a bearer token via `POST /enterprise-auth`
- Context manager support (`with Opedd(...) as client:` closes the underlying HTTP pool)
- Typed exception hierarchy: `OpeddError`, `OpeddAuthError`, `OpeddNotFoundError`, `OpeddValidationError`, `OpeddRateLimitError`, `OpeddServerError`. Each carries `status_code`, `request_id`, `body`. `OpeddRateLimitError` additionally carries `retry_after_seconds`.
- NDJSON streaming with auto-pagination across `_meta.next_cursor` until `_meta.truncated == false`.
- 29 unit tests with mocked HTTPX (`pytest tests/test_unit.py`).
- Integration test suite gated on `pytest --integration` flag (manual local execution before release; not run in CI per institutional risk discipline).
- Schema version pin: `phase-11-m4`. Surfaced as `opedd.__schema_version__`.

### Wire-format contract

- Successful response body is flat (no nested `data.data` envelope on most endpoints).
- Error response: `{"success": false, "error": "..."}` or `{"success": false, "error": {"code": "...", "message": "...", "details": {...}}}` (Phase 8 nested envelope).
- `X-Opedd-Request-Id` propagated to all SDK exception `request_id` fields.

[0.1.0]: https://github.com/Opedd/opedd-python/releases/tag/v0.1.0
