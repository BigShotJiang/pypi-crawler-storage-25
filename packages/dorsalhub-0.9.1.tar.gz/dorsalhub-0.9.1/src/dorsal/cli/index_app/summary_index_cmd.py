# Copyright 2025-2026 Dorsal Hub LTD
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import logging
import typer
from typing import Annotated

from rich.console import Group
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from dorsal.cli.themes import UIContext
from dorsal.cli.themes.borders import get_borders

logger = logging.getLogger(__name__)


def show_index_summary(
    ctx: typer.Context,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output the summary as a raw JSON object."),
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Show extended metrics and distributions."),
    ] = False,
    limit: Annotated[int, typer.Option("--limit", "-l", help="Length limit for the tables in verbose view.")] = 10,
):
    """
    Displays statistics and health metrics about the local file search index.
    """
    from datetime import datetime
    from rich.columns import Columns
    from dorsal.api.index import summary as get_index_summary
    from dorsal.common.cli import get_rich_console, exit_cli, EXIT_CODE_ERROR
    from dorsal.file.utils.size import human_filesize

    console = get_rich_console()
    ui_context: UIContext = ctx.obj
    palette = ui_context["palette"]
    icons = ui_context["icons"]
    borders = ui_context["borders"]

    try:
        summary = get_index_summary(verbose=verbose, limit=limit)

        if json_output:
            console.print(json.dumps(summary, indent=2))
            exit_cli()

        created_dt = (
            datetime.fromtimestamp(summary.get("created_time", 0)).strftime("%Y-%m-%d %H:%M")
            if summary.get("created_time")
            else "N/A"
        )
        modified_dt = (
            datetime.fromtimestamp(summary.get("modified_time", 0)).strftime("%Y-%m-%d %H:%M")
            if summary.get("modified_time")
            else "N/A"
        )

        summary_table = Table.grid(expand=False, padding=(0, 1))
        summary_table.add_column(justify="right", style=palette.get("key", "dim"), width=24)
        summary_table.add_column(justify="left", style=palette.get("primary_value", "default"))

        summary_table.add_row("Index Path:", str(summary.get("database_path", "N/A")))
        summary_table.add_row("Index Size:", f"{summary.get('total_records', 0):,} Records")
        summary_table.add_row("Record Cache Size:", human_filesize(summary.get("record_cache_size_bytes", 0)))
        summary_table.add_row("Search Index Size:", human_filesize(summary.get("search_index_size_bytes", 0)))

        if verbose:
            summary_table.add_row("Total DB Size:", human_filesize(summary.get("database_size_bytes", 0)))
            summary_table.add_row("Full-Text Index:", f"{summary.get('fts_indexed_records', 0):,} Records")
            summary_table.add_row("Index Created:", created_dt)
            summary_table.add_row("Last Modified:", modified_dt)
            summary_table.add_row("Tracked File Data:", human_filesize(summary.get("total_tracked_file_bytes", 0)))

            # --- Storage Metrics ---
            summary_table.add_row("Avg Index Record Size:", human_filesize(summary.get("avg_record_size_bytes", 0)))
            summary_table.add_row("Max Index Record Size:", human_filesize(summary.get("max_record_size_bytes", 0)))

            # --- Deduplication Metrics ---
            summary_table.add_row("Unique Files (Hash):", f"{summary.get('unique_files_by_hash', 0):,}")
            summary_table.add_row("Duplicate Files:", f"{summary.get('duplicate_files_detected', 0):,}")

            # --- Data Freshness Metrics ---
            oldest_ts = summary.get("oldest_record_timestamp")
            if oldest_ts:
                summary_table.add_row("Oldest Tracked File:", datetime.fromtimestamp(oldest_ts).strftime("%Y-%m-%d"))
            newest_ts = summary.get("newest_record_timestamp")
            if newest_ts:
                summary_table.add_row("Newest Tracked File:", datetime.fromtimestamp(newest_ts).strftime("%Y-%m-%d"))

            # --- Compression Info ---
            comp_mode = summary.get("compression_mode", "None")
            comp_level = summary.get("compression_level")
            comp_str = f"{comp_mode} (Level {comp_level})" if comp_level else comp_mode
            summary_table.add_row("Compression Config:", comp_str)

            comp_ratio = summary.get("compression_ratio_sample")
            if comp_ratio:
                summary_table.add_row("Compression Ratio:", f"{comp_ratio:.2f}x")
            else:
                summary_table.add_row("Compressed Records:", f"{summary.get('compressed_records', 0):,}")

            summary_table.add_row("Hash Only Records:", f"{summary.get('hash_only_records', 0):,}")
            summary_table.add_row("Indexed Attributes:", f"{summary.get('indexed_attributes', 0):,}")

        is_none_style = borders == get_borders("none")
        title_text = f"[{palette.get('panel_title', 'bold white')}]{icons.get('search', '')}Index Summary[/]"

        if is_none_style:
            console.print(Group(Text.from_markup(f"{title_text}\n"), summary_table))
        else:
            console.print(
                Panel(
                    summary_table,
                    title=title_text,
                    border_style=palette.get("panel_border", "default"),
                    box=borders,
                    expand=False,
                )
            )

        if verbose:

            def build_dist_table(title: str, data: dict, limit: int | None = None):
                t = Table(
                    title=f"[{palette.get('panel_title', 'bold white')}]{title}[/]",
                    show_header=False,
                    box=borders,
                    expand=False,
                )
                t.add_column("Type", style=palette.get("key", "dim"))
                t.add_column("Count", justify="right", style=palette.get("primary_value", "default"))
                for k, v in list(data.items())[:limit]:
                    t.add_row(str(k), f"{v:,}")
                return t

            dist_tables = []

            top_exts = summary.get("top_extensions", {})
            if top_exts:
                dist_tables.append(build_dist_table("Top Extensions", top_exts, limit=limit))

            top_media = summary.get("top_media_types", {})
            if top_media:
                dist_tables.append(build_dist_table("Top Media Types", top_media, limit=limit))

            top_schemas = summary.get("top_schemas", {})
            if top_schemas:
                dist_tables.append(build_dist_table("Top Schemas", top_schemas, limit=limit))

            top_attrs = summary.get("top_attribute_keys", {})
            if top_attrs:
                dist_tables.append(build_dist_table("Top Attributes", top_attrs, limit=limit))

            if dist_tables:
                console.print()
                console.print(Columns(dist_tables, padding=(0, 2)))

    except typer.Exit:
        raise
    except Exception as err:
        logger.exception("Failed to retrieve search index summary.")
        exit_cli(
            code=EXIT_CODE_ERROR,
            message=f"An error occurred while getting search index info: {err}",
        )
