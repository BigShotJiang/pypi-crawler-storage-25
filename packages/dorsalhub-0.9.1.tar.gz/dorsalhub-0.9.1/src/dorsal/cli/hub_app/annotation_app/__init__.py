# Copyright 2025-2026 Dorsal Hub LTD
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import typer

from dorsal.cli.hub_app.annotation_app.get_annotation_cmd import get_annotation
from dorsal.cli.hub_app.annotation_app.list_annotations_cmd import list_annotations


app = typer.Typer(
    name="annotation", help="... [bold]get[/bold] and [bold]list[/bold] annotations.", no_args_is_help=True
)

app.command(name="get")(get_annotation)
app.command(name="list")(list_annotations)
