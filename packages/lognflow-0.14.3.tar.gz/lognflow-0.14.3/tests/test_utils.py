#!/usr/bin/env python

"""Tests for `lognflow` package."""
import pytest
from pathlib import Path
import matplotlib.pyplot as plt
import lognflow
from lognflow.utils import printv, is_builtin_collection, print_table
import numpy as np

def test_is_builtin_collection():

    # Test the function with various types
    test_list   = [1, 2, 3]
    test_string = "hello"
    test_dict   = {'a': 1, 'b': 2}
    test_set    = {1, 2, 3}
    test_tuple  = (1, 2, 3)
    test_array  = np.array([1, 2, 3])
    
    assert     is_builtin_collection(test_list  ) 
    assert not is_builtin_collection(test_string)
    assert     is_builtin_collection(test_dict  ) 
    assert     is_builtin_collection(test_set   )  
    assert     is_builtin_collection(test_tuple )
    assert not is_builtin_collection(test_array )

def test_ssh_system():
    try:
        ssh = ssh_system(
            hostname = 'hostname', 
            username = 'username', 
            password = 'password')
        remote_dir = Path('/remote/folder/path')
        local_dir = Path('/local/folder/path')
        target_fname = 'intresting_file.log'
        ssh.monitor_and_move(remote_dir, local_dir, target_fname)
        ssh.close_connection()
    except:
        print('SSH test not passed maybe because '
              'you did not set the SSH credentials.')

def test_ssh_upload_download():
    try:        
        from pathlib import Path
        from lognflow.utils import SSHSystem
        
        ssh = SSHSystem(
            hostname="hostname",
            username="username",
            password="password"
        )
        
        ssh.upload(
            local_root=Path(r"local_root"),
            remote_root=Path(r"remote_root")
        )
        
        ssh.download(
            local_root=Path(r"local_root"),
            remote_root=Path(r"remote_root")
        )
        
        ssh.close_connection()
    except:
        print('SSH test not passed maybe because '
              'you did not set the SSH credentials.')
    
def test_printv():
    
    test_True1 = True
    test_True2 = True
    
    printv(test_True2)

    test0 = np.random.rand(10).max()
    printv(test0)
    test1 = 123
    printv(test1)
    test2 = 123.2
    printv(test2)
    test3 = np.random.rand(10000)
    printv(test3)
    test4 = [test3, 'asdf', 21]
    printv(test4)
    test5 = {'A':test3, 'B': test4}
    printv(test5)
    test55 = {'A':test5, 'C': test4}
    printv(test55)
    test6 = [test3, 'asdf', 21]*200
    printv(test6)
    test7 = 'asdf'*200000
    printv(test7)
    test8 = ['34', '123']
    printv(test8)
    test9 = np.random.rand(3, 3)
    printv(test9)

def test_print_table():
    print("\n=== basic table ===")
    print_table(
        header=["A", "B"],
        rows=[
            [1, 2],
            [3, 4],
        ],
        title="No row labels",
    )

    print("\n=== table with row labels ===")
    print_table(
        header=["A", "B"],
        rows=[
            [1, 2],
            [3, 4],
        ],
        row_labels=["r1", "r2"],
        title="With row labels",
    )

    print("\n=== numeric row labels ===")
    print_table(
        header=["X", "Y"],
        rows=[
            [10, 20],
            [30, 40],
            [50, 60],
        ],
        row_labels=[0, 1, 2],
        title="Numeric row labels",
    )

    print("\n=== auto-generated row labels ===")
    print_table(
        header=["foo", "bar"],
        rows=[
            ["a", "b"],
            ["c", "d"],
        ],
        row_labels="auto",
        title="Auto index",
    )


def test_save_or_load_kernel_state():
    vec = np.random.rand(100)
    vec_orig = vec.copy()
    another_variable = "Hello"
    
    current_kernel_state = lognflow.utils.save_or_load_kernel_state()
    
    vec = vec ** 2
    another_variable = "Goodbye"
    
    lognflow.utils.save_or_load_kernel_state(current_kernel_state)
    
    assert (vec == vec_orig).all()
    assert another_variable == "Hello"
    
    print("State restored successfully!")

def test_block_runner():
    from lognflow.utils import block_runner
    block_runner(Path('./test_block_runner_code.py'))

def test_richprint():
    
    from lognflow.utils import richprint
    # Examples
    # --------
    # a line
    richprint(line = True)
    
    # Like normal print
    richprint("A", "B", 123, style = 'red')
    
    # Line
    richprint("Section Start", line=True, style="bold yellow")
    
    # Box
    richprint("Hello world!", box=True, style="green", title="Greeting")
    
    # Table
    richprint(table={'header': ['a', 'b'], 'rows': [[1, 2], [3, 4]]})
    
    # Mixed styles
    richprint("Warning!", style="bold red on yellow")
    richprint("Italic text inside", box=True, style="italic blue")
    
    # More examples
    # -------------
    richprint("Hello", "world", 123, style="bold green")
    richprint("Header", line=True, style="yellow")
    richprint("Message inside a box", box=True, style="bold cyan")
    richprint(table=dict(header=["a", "b"], rows=np.random.rand(10, 2)))

def test_print_table_simple():
    print_table(np.arange(0, 10), 
                (100 * np.random.rand(11, 10)).astype('int'))

    print_table(header = np.arange(0, 10), 
                rows = (100 * np.random.rand(11, 10)).astype('int'), 
                row_labels = 'auto')

if __name__ == '__main__':
    test_print_table_simple(); exit()
    test_print_table()
    test_printv()
    test_richprint()
    test_is_builtin_collection()
    test_block_runner()
    test_ssh_system()
    test_ssh_upload_download()
    
    
    