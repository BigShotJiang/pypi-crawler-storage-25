"""
FastAPI routes for user management.

These endpoints provide CRUD operations for users and role assignments.
All endpoints require authentication and appropriate permissions.
"""

import hashlib
import logging
import secrets
import uuid
from datetime import UTC, datetime, timedelta
from typing import Any

import bcrypt
from fastapi import APIRouter, Depends, HTTPException, status

from ezrules.backend.api_v2.auth.dependencies import (
    get_current_active_user,
    get_current_org_id,
    get_db,
    require_permission,
)
from ezrules.backend.api_v2.schemas.users import (
    AssignRoleRequest,
    RoleAssignmentResponse,
    RoleResponse,
    UserCreate,
    UserInvite,
    UserInviteResponse,
    UserListItem,
    UserMutationResponse,
    UserResponse,
    UsersListResponse,
    UserUpdate,
)
from ezrules.backend.email_service import send_invitation_email
from ezrules.core.audit_helpers import save_user_account_history
from ezrules.core.permissions_constants import PermissionAction
from ezrules.models.backend_core import Invitation, PasswordResetToken, Role, User, UserSession
from ezrules.settings import app_settings

router = APIRouter(prefix="/api/v2/users", tags=["Users"])
logger = logging.getLogger(__name__)


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================


def user_to_response(user: User) -> UserResponse:
    """Convert a database user model to API response."""
    roles = [
        RoleResponse(
            id=int(role.id),
            name=str(role.name),
            description=role.description,
        )
        for role in user.roles
    ]

    # Cast datetime fields - they're either datetime or None
    last_login = user.last_login_at if user.last_login_at is not None else None
    current_login = user.current_login_at if user.current_login_at is not None else None

    return UserResponse(
        id=int(user.id),
        email=str(user.email),
        active=bool(user.active),
        roles=roles,
        last_login_at=last_login,  # type: ignore[arg-type]
        current_login_at=current_login,  # type: ignore[arg-type]
    )


def user_to_list_item(user: User) -> UserListItem:
    """Convert a database user model to list item response."""
    roles = [
        RoleResponse(
            id=int(role.id),
            name=str(role.name),
            description=role.description,
        )
        for role in user.roles
    ]

    return UserListItem(
        id=int(user.id),
        email=str(user.email),
        active=bool(user.active),
        roles=roles,
    )


def hash_password(password: str) -> str:
    """Hash a password using bcrypt."""
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def hash_token(token: str) -> str:
    """Hash a one-time token for database storage."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def now_utc_naive() -> datetime:
    """Get current UTC timestamp without tzinfo for DB compatibility."""
    return datetime.now(UTC).replace(tzinfo=None)


# =============================================================================
# LIST USERS
# =============================================================================


@router.get("", response_model=UsersListResponse)
def list_users(
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.VIEW_USERS)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
) -> UsersListResponse:
    """
    Get all users.

    Returns a list of all users with their roles.
    Requires VIEW_USERS permission.
    """
    users = db.query(User).filter(User.o_id == current_org_id).all()
    users_data = [user_to_list_item(u) for u in users]
    return UsersListResponse(users=users_data)


# =============================================================================
# GET SINGLE USER
# =============================================================================


@router.get("/{user_id}", response_model=UserResponse)
def get_user(
    user_id: int,
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.VIEW_USERS)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
) -> UserResponse:
    """
    Get a single user by ID.

    Returns full user details including roles.
    Requires VIEW_USERS permission.
    """
    target_user = db.query(User).filter(User.id == user_id, User.o_id == current_org_id).first()

    if not target_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User with id {user_id} not found",
        )

    return user_to_response(target_user)


# =============================================================================
# CREATE USER
# =============================================================================


@router.post("", response_model=UserMutationResponse, status_code=status.HTTP_201_CREATED)
def create_user(
    user_data: UserCreate,
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.CREATE_USER)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
) -> UserMutationResponse:
    """
    Create a new user.

    Requires CREATE_USER permission.
    Email must be unique.
    """
    # Check if email already exists
    existing_user = db.query(User).filter(User.email == user_data.email).first()
    if existing_user:
        return UserMutationResponse(
            success=False,
            message="Email already exists",
            error=f"A user with email '{user_data.email}' already exists",
        )

    # Create the new user
    new_user = User(
        email=user_data.email,
        password=hash_password(user_data.password),
        active=True,
        fs_uniquifier=str(uuid.uuid4()),
        o_id=current_org_id,
    )

    # Assign roles if provided
    if user_data.role_ids:
        roles = db.query(Role).filter(Role.o_id == current_org_id, Role.id.in_(user_data.role_ids)).all()
        if len(roles) != len(user_data.role_ids):
            found_ids = {r.id for r in roles}
            missing_ids = [rid for rid in user_data.role_ids if rid not in found_ids]
            return UserMutationResponse(
                success=False,
                message="Some roles not found",
                error=f"Role IDs not found: {missing_ids}",
            )
        new_user.roles = roles

    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    save_user_account_history(
        db,
        user_id=int(new_user.id),
        user_email=str(new_user.email),
        action="created",
        o_id=current_org_id,
        changed_by=str(user.email),
    )
    db.commit()

    return UserMutationResponse(
        success=True,
        message="User created successfully",
        user=user_to_response(new_user),
    )


# =============================================================================
# INVITE USER
# =============================================================================


@router.post("/invite", response_model=UserInviteResponse)
def invite_user(
    invite_data: UserInvite,
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.CREATE_USER)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
) -> UserInviteResponse:
    """
    Invite a user by email.

    Requires CREATE_USER permission.
    Creates an inactive user when needed and sends a one-time invite email.
    """
    email = str(invite_data.email).strip().lower()
    existing_user = db.query(User).filter(User.email == email).first()

    if existing_user and int(existing_user.o_id) != current_org_id:
        return UserInviteResponse(
            success=False,
            message="Email already exists",
            error=f"A user with email '{email}' already exists",
        )

    if existing_user and existing_user.active:
        return UserInviteResponse(
            success=False,
            message="Email already exists",
            error=f"A user with email '{email}' already exists and is active",
        )

    target_user = existing_user
    if target_user is None:
        target_user = User(
            email=email,
            password=hash_password(secrets.token_urlsafe(32)),
            active=False,
            fs_uniquifier=str(uuid.uuid4()),
            o_id=current_org_id,
        )
        db.add(target_user)
        db.flush()
    else:
        target_user.active = False

    if invite_data.role_ids:
        roles = db.query(Role).filter(Role.o_id == current_org_id, Role.id.in_(invite_data.role_ids)).all()
        if len(roles) != len(invite_data.role_ids):
            found_ids = {int(r.id) for r in roles}
            missing_ids = [rid for rid in invite_data.role_ids if rid not in found_ids]
            return UserInviteResponse(
                success=False,
                message="Some roles not found",
                error=f"Role IDs not found: {missing_ids}",
            )
        for role in roles:
            if role not in target_user.roles:
                target_user.roles.append(role)

    now = now_utc_naive()
    db.query(Invitation).filter(
        Invitation.user_id == int(target_user.id),
        Invitation.accepted_at.is_(None),
    ).delete(synchronize_session=False)

    invite_token = secrets.token_urlsafe(48)
    invitation = Invitation(
        gid=str(uuid.uuid4()),
        email=email,
        o_id=current_org_id,
        user_id=int(target_user.id),
        token_hash=hash_token(invite_token),
        invited_by=str(user.email),
        created_at=now,
        expires_at=now + timedelta(hours=app_settings.INVITE_TOKEN_EXPIRY_HOURS),
    )
    db.add(invitation)

    try:
        db.flush()
        send_invitation_email(email, invite_token)
    except Exception as exc:
        db.rollback()
        logger.exception("Failed to send invite email for %s", email)
        return UserInviteResponse(
            success=False,
            message="Failed to send invitation",
            error=str(exc),
        )

    save_user_account_history(
        db,
        user_id=int(target_user.id),
        user_email=str(target_user.email),
        action="invited",
        o_id=current_org_id,
        changed_by=str(user.email),
        details=f"invited_by={user.email}",
    )
    db.commit()

    return UserInviteResponse(
        success=True,
        message=f"Invitation sent to {email}",
    )


# =============================================================================
# UPDATE USER
# =============================================================================


@router.put("/{user_id}", response_model=UserMutationResponse)
def update_user(
    user_id: int,
    user_data: UserUpdate,
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.MODIFY_USER)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
) -> UserMutationResponse:
    """
    Update an existing user.

    Requires MODIFY_USER permission.
    Cannot deactivate yourself.
    """
    target_user = db.query(User).filter(User.id == user_id, User.o_id == current_org_id).first()

    if not target_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User with id {user_id} not found",
        )

    # Prevent self-deactivation
    if user_data.active is False and user.id == user_id:
        return UserMutationResponse(
            success=False,
            message="Cannot deactivate yourself",
            error="You cannot deactivate your own account",
        )

    # Track changes for audit
    changes: list[str] = []

    # Update email if provided
    if user_data.email is not None:
        # Check if email already exists for another user
        existing = db.query(User).filter(User.email == user_data.email, User.id != user_id).first()
        if existing:
            return UserMutationResponse(
                success=False,
                message="Email already exists",
                error=f"A user with email '{user_data.email}' already exists",
            )
        changes.append(f"email changed to {user_data.email}")
        target_user.email = user_data.email

    # Update password if provided
    if user_data.password is not None:
        target_user.password = hash_password(user_data.password)
        changes.append("password changed")

    # Update active status if provided
    if user_data.active is not None:
        target_user.active = user_data.active
        changes.append(f"active set to {user_data.active}")

    db.commit()
    db.refresh(target_user)

    if changes:
        save_user_account_history(
            db,
            user_id=int(target_user.id),
            user_email=str(target_user.email),
            action="updated",
            o_id=int(target_user.o_id),
            changed_by=str(user.email),
            details="; ".join(changes),
        )
        db.commit()

    return UserMutationResponse(
        success=True,
        message="User updated successfully",
        user=user_to_response(target_user),
    )


# =============================================================================
# DELETE USER
# =============================================================================


@router.delete("/{user_id}", response_model=UserMutationResponse)
def delete_user(
    user_id: int,
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.DELETE_USER)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
) -> UserMutationResponse:
    """
    Delete a user.

    Requires DELETE_USER permission.
    Cannot delete yourself.
    """
    # Prevent self-deletion
    if user.id == user_id:
        return UserMutationResponse(
            success=False,
            message="Cannot delete yourself",
            error="You cannot delete your own account",
        )

    target_user = db.query(User).filter(User.id == user_id, User.o_id == current_org_id).first()

    if not target_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User with id {user_id} not found",
        )

    target_email = str(target_user.email)
    target_id = int(target_user.id)

    save_user_account_history(
        db,
        user_id=target_id,
        user_email=target_email,
        action="deleted",
        o_id=int(target_user.o_id),
        changed_by=str(user.email),
    )

    # Clean up dependent rows explicitly to avoid FK violations.
    db.query(Invitation).filter(Invitation.user_id == target_id).delete(synchronize_session=False)
    db.query(PasswordResetToken).filter(PasswordResetToken.user_id == target_id).delete(synchronize_session=False)
    db.query(UserSession).filter(UserSession.user_id == target_id).delete(synchronize_session=False)

    db.delete(target_user)
    db.commit()

    return UserMutationResponse(
        success=True,
        message="User deleted successfully",
    )


# =============================================================================
# ASSIGN ROLE TO USER
# =============================================================================


@router.post("/{user_id}/roles", response_model=RoleAssignmentResponse)
def assign_role(
    user_id: int,
    role_data: AssignRoleRequest,
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.MANAGE_USER_ROLES)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
) -> RoleAssignmentResponse:
    """
    Assign a role to a user.

    Requires MANAGE_USER_ROLES permission.
    """
    target_user = db.query(User).filter(User.id == user_id, User.o_id == current_org_id).first()

    if not target_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User with id {user_id} not found",
        )

    role = db.query(Role).filter(Role.id == role_data.role_id, Role.o_id == current_org_id).first()

    if not role:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Role with id {role_data.role_id} not found",
        )

    # Check if user already has this role
    if role in target_user.roles:
        return RoleAssignmentResponse(
            success=False,
            message="Role already assigned",
            error=f"User already has role '{role.name}'",
            user=user_to_response(target_user),
        )

    target_user.roles.append(role)
    db.commit()
    db.refresh(target_user)

    save_user_account_history(
        db,
        user_id=int(target_user.id),
        user_email=str(target_user.email),
        action="role_assigned",
        o_id=int(target_user.o_id),
        changed_by=str(user.email),
        details=f"role: {role.name}",
    )
    db.commit()

    return RoleAssignmentResponse(
        success=True,
        message=f"Role '{role.name}' assigned successfully",
        user=user_to_response(target_user),
    )


# =============================================================================
# REMOVE ROLE FROM USER
# =============================================================================


@router.delete("/{user_id}/roles/{role_id}", response_model=RoleAssignmentResponse)
def remove_role(
    user_id: int,
    role_id: int,
    user: User = Depends(get_current_active_user),
    _: None = Depends(require_permission(PermissionAction.MANAGE_USER_ROLES)),
    current_org_id: int = Depends(get_current_org_id),
    db: Any = Depends(get_db),
) -> RoleAssignmentResponse:
    """
    Remove a role from a user.

    Requires MANAGE_USER_ROLES permission.
    """
    target_user = db.query(User).filter(User.id == user_id, User.o_id == current_org_id).first()

    if not target_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User with id {user_id} not found",
        )

    role = db.query(Role).filter(Role.id == role_id, Role.o_id == current_org_id).first()

    if not role:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Role with id {role_id} not found",
        )

    # Check if user has this role
    if role not in target_user.roles:
        return RoleAssignmentResponse(
            success=False,
            message="Role not assigned",
            error=f"User does not have role '{role.name}'",
            user=user_to_response(target_user),
        )

    target_user.roles.remove(role)
    db.commit()
    db.refresh(target_user)

    save_user_account_history(
        db,
        user_id=int(target_user.id),
        user_email=str(target_user.email),
        action="role_removed",
        o_id=int(target_user.o_id),
        changed_by=str(user.email),
        details=f"role: {role.name}",
    )
    db.commit()

    return RoleAssignmentResponse(
        success=True,
        message=f"Role '{role.name}' removed successfully",
        user=user_to_response(target_user),
    )
