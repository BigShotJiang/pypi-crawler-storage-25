from datetime import datetime

from pydantic import BaseModel, field_validator

from ezrules.core.outcomes import DatabaseOutcome
from ezrules.models.backend_core import TestingRecordLog, TestingResultsLog


class Event(BaseModel):
    event_id: str
    event_timestamp: int  # Assuming Unix timestamp as input
    event_data: dict

    @field_validator("event_timestamp", mode="before")
    def validate_unix_timestamp(cls, value):
        # Ensure the timestamp is an integer
        if not isinstance(value, int):
            raise ValueError("Timestamp must be an integer")

        # Ensure the timestamp is in a reasonable range (e.g., 1970-01-01 to 3000-01-01)
        min_timestamp = 0  # Unix timestamp for 1970-01-01T00:00:00Z
        max_timestamp = 32503680000  # Approximate Unix timestamp for 3000-01-01T00:00:00Z
        if not (min_timestamp <= value <= max_timestamp):
            raise ValueError("Timestamp out of range")

        return value


def eval_and_store(lre, event: Event, response: dict | None = None, commit: bool = True):
    if response is None:
        response = lre.evaluate_rules(event.event_data)
    response, tl_id = store_eval_result(
        db_session=lre.db,
        o_id=lre.o_id,
        event=event,
        response=response,
        commit=commit,
    )
    return response, tl_id


def store_eval_result(db_session, o_id: int, event: Event, response: dict, commit: bool = True):
    outcome_manager = DatabaseOutcome(db_session=db_session, o_id=o_id)
    created_at_datetime = datetime.fromtimestamp(event.event_timestamp)
    tl = TestingRecordLog(
        o_id=o_id,
        event=event.event_data,
        event_timestamp=event.event_timestamp,
        event_id=event.event_id,
        created_at=created_at_datetime,
    )
    db_session.add(tl)
    if commit:
        db_session.commit()
    else:
        db_session.flush()

    resolved_outcome = outcome_manager.resolve_outcome(response["outcome_counters"])
    tl.outcome_counters = response["outcome_counters"]
    tl.resolved_outcome = resolved_outcome
    for r_id, result in response["rule_results"].items():
        trl = TestingResultsLog(tl_id=tl.tl_id, r_id=r_id, rule_result=result)
        db_session.add(trl)
    response["resolved_outcome"] = resolved_outcome
    if commit:
        db_session.commit()
    return response, tl.tl_id
