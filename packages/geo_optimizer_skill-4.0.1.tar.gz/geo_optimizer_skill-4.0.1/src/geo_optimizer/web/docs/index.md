# GEO Optimizer — Documentation

Optimize any website to be cited by ChatGPT, Perplexity, Claude, and Gemini.
This documentation covers every tool and concept in the toolkit. → [README](../README.md)

---

## Navigation

| Page | Description |
|------|-------------|
| [Getting Started](getting-started.md) | Install the toolkit and run your first audit in 5 minutes |
| [GEO Audit Script](geo-audit.md) | Full reference for `geo audit` — flags, output, scoring |
| [Generating llms.txt](llms-txt.md) | Auto-generate `/llms.txt` from your sitemap for AI crawlers |
| [Schema Injector](schema-injector.md) | Generate and inject JSON-LD structured data into your pages |
| [Using SKILL.md as AI Context](ai-context.md) | Use the toolkit with Claude, ChatGPT, Gemini, Cursor, Windsurf |
| [42 GEO Methods](geo-methods.md) | Research-backed content optimization methods (KDD 2024 + ICLR 2026) |
| [AI Bots Reference](ai-bots-reference.md) | Complete list of 27 AI crawlers and `robots.txt` configuration |
| [Scoring Rubric](scoring-rubric.md) | How the GEO Score (0–100) is computed across 8 categories |
| [geo fix Command](geo-fix.md) | Automatic fix generation — robots.txt, llms.txt, schema, meta |
| [MCP Server](mcp-server.md) | Use GEO Optimizer as an MCP server in Claude Code, Cursor, etc. |
| [CI/CD Integration](ci-cd.md) | Run GEO audits in GitHub Actions, GitLab CI, and other pipelines |
| [Troubleshooting](troubleshooting.md) | Solutions to 10 common installation and runtime problems |

---

## Quick Navigation

**Start here if you're new →** [Getting Started](getting-started.md)

**Already installed? Run your first audit →** [GEO Audit Script](geo-audit.md)
