from __future__ import annotations

import re
from typing import ClassVar

from .base import Summarizer
from ..models import MessageEvent, SummaryResult
from ..text_transform import sanitize_text_for_tts


class RuleBasedSummarizer(Summarizer):
    """Rule-based summarizer using text patterns and heuristics."""

    name: ClassVar[str] = "rule_based"

    def summarize(self, message: str, event: MessageEvent, max_chars: int) -> SummaryResult:
        cleaned = _clean(message)
        short = _truncate(cleaned, max_chars)

        if event == MessageEvent.NEEDS_INPUT:
            prompt = _extract_question(cleaned)
            text = prompt or short
            return SummaryResult(
                summary=_truncate(text, max_chars),
                state=event,
                user_action_required=True,
                action_prompt=prompt,
            )

        if event in (MessageEvent.ERROR, MessageEvent.PROGRESS, MessageEvent.FINAL):
            return SummaryResult(
                summary=short,
                state=event,
            )

        return SummaryResult(summary=short, state=event)


def _clean(message: str) -> str:
    text = re.sub(r"```.*?```", "", message, flags=re.DOTALL)
    text = re.sub(r"\[(.*?)\]\(.*?\)", r"\1", text)
    return sanitize_text_for_tts(text)


def _truncate(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 1].rstrip() + "…"


def _extract_question(text: str) -> str | None:
    for sentence in re.split(r"(?<=[.?!])\s+", text):
        if "?" in sentence:
            return sentence.strip()
    return None
