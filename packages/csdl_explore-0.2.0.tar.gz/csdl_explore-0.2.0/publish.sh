#!/usr/bin/env bash
set -euo pipefail

# Publish csdl-explore to PyPI
# Requires: PYPI_TOKEN environment variable (API token from pypi.org)

if [ -z "${PYPI_TOKEN:-}" ]; then
    echo "Error: PYPI_TOKEN environment variable is not set."
    echo "Get one at https://pypi.org/manage/account/token/"
    exit 1
fi

echo "==> Cleaning old builds..."
rm -rf dist/ build/ src/*.egg-info

echo "==> Building package..."
python -m build

echo "==> Uploading to PyPI..."
twine upload dist/* \
    --username __token__ \
    --password "$PYPI_TOKEN" \
    --non-interactive

echo "==> Published! Install with: pip install csdl-explore"
