"""CLI exit code constants."""

OK = 0
ERROR = 1
INVALID_INPUT = 2
NETWORK_ERROR = 3
NOT_FOUND = 4
