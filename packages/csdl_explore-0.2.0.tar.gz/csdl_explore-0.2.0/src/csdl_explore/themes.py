"""
Theme definitions for CSDL Explorer.

Provides Textual themes for the TUI and a color palette dict for the Rich REPL
so both interfaces stay visually consistent.
"""

from textual.theme import Theme

# ── Textual themes ─────────────────────────────────────────────────────

TERMINAL_THEME = Theme(
    name="terminal-green",
    primary="#00FF41",
    secondary="#222222",
    accent="#FFB800",
    foreground="#cccccc",
    background="#000000",
    surface="#0a0a0a",
    panel="#111111",
    warning="#FFB800",
    error="#ff3333",
    success="#00FF41",
    dark=True,
)

CLASSIC_THEME = Theme(
    name="classic",
    primary="#00bfff",
    secondary="#9370db",
    accent="#ffd700",
    foreground="#e1e1e1",
    background="#1e1e1e",
    surface="#2d2d2d",
    panel="#333333",
    warning="#ffa500",
    error="#ff4444",
    success="#44ff44",
    dark=True,
)

ALL_THEMES = [TERMINAL_THEME, CLASSIC_THEME]
THEME_NAMES = [t.name for t in ALL_THEMES]

# ── Rich REPL palettes ────────────────────────────────────────────────
# Simple role→Rich-markup-color mappings used by repl.py.

PALETTES: dict[str, dict[str, str]] = {
    "terminal-green": {
        "primary": "#00FF41",
        "secondary": "#888888",
        "accent": "#FFB800",
        "entity": "#00FF41",
        "property": "#cccccc",
        "key": "#FFB800",
        "required": "#ff3333",
        "crud": "#00FF41",
        "hidden": "dim",
        "no_filter": "#ff3333",
        "nav": "#00FF41",
        "picklist": "#FFB800",
        "dim": "dim",
        "label": "dim",
    },
    "classic": {
        "primary": "cyan",
        "secondary": "magenta",
        "accent": "yellow",
        "entity": "cyan",
        "property": "cyan",
        "key": "yellow",
        "required": "red",
        "crud": "green",
        "hidden": "dim",
        "no_filter": "red",
        "nav": "blue",
        "picklist": "magenta",
        "dim": "dim",
        "label": "dim",
    },
}

DEFAULT_PALETTE = "terminal-green"
