"""
CLI entry point for CSDL Explorer.
"""

import argparse
import asyncio
import json
import sys
from dataclasses import dataclass
from pathlib import Path

from rich.console import Console

from . import repl
from .exit_codes import ERROR, INVALID_INPUT, NETWORK_ERROR, NOT_FOUND, OK
from .explorer import CSDLExplorer

console = Console()


@dataclass
class OutputConfig:
    """Output preferences parsed from CLI flags."""

    format: str = "table"
    wide: bool = False
    filter_pattern: str = ""
    json_only: bool = False


# ── Argument Parser ──────────────────────────────────────────────


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser."""
    # Shared output flags — inherited by every subcommand so flags work
    # both before and after the command name. Uses SUPPRESS to avoid
    # subcommand defaults overwriting top-level values.
    output_parent = argparse.ArgumentParser(add_help=False)
    output_parent.add_argument("--format", choices=["table", "json", "json-compact", "csv"], default=argparse.SUPPRESS)
    output_parent.add_argument("--wide", action="store_true", default=argparse.SUPPRESS, help="Full column widths")
    output_parent.add_argument("--filter", dest="filter_pattern", default=argparse.SUPPRESS, help="Filter properties by glob pattern")
    output_parent.add_argument("--json-only", action="store_true", default=argparse.SUPPRESS, help="JSON output, no banner (for scripts)")

    parser = argparse.ArgumentParser(
        prog="csdl-explore",
        parents=[output_parent],
        description="OData CSDL Metadata Explorer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""examples:
  csdl-explore metadata.xml                    # Interactive REPL
  csdl-explore metadata.xml --tui              # Full Textual TUI
  csdl-explore metadata.xml search contract    # Search fields
  csdl-explore metadata.xml entity EmpJob      # Entity details
  csdl-explore metadata.xml tree EmpJob        # Visual tree
  csdl-explore metadata.xml query EmpJob --select "userId,company" --top 5
""",
    )

    # Positional: metadata file
    parser.add_argument(
        "metadata_file", metavar="metadata.xml",
        help="Path to OData $metadata XML file",
    )

    # Global options
    parser.add_argument("--tui", action="store_true", help="Launch full Textual TUI")

    # Connection options
    conn = parser.add_argument_group("connection")
    conn.add_argument("--base-url", help="OData service base URL")
    conn.add_argument("--auth-type", choices=["none", "bearer", "basic", "oauth2"])
    conn.add_argument("--bearer-token", help="Bearer token")
    conn.add_argument("--username", help="Basic auth username")
    conn.add_argument("--password", help="Basic auth password")

    # Subcommands — each inherits output_parent so --format etc. work after command
    subs = parser.add_subparsers(dest="command")

    # Commands with no extra args
    for name, help_text in [
        ("interactive", "Start interactive REPL (default)"),
        ("tui", "Start Textual TUI"),
        ("entities", "List all entity types"),
        ("emp", "List Emp* entities"),
        ("per", "List Per* entities"),
        ("picklists", "List all picklists (JSON)"),
    ]:
        subs.add_parser(name, parents=[output_parent], help=help_text)

    # Commands with a name argument
    for name, aliases, help_text in [
        ("entity", ["e"], "Show entity properties"),
        ("tree", ["t"], "Show entity as visual tree"),
        ("search", ["s"], "Search entities and properties"),
        ("custom", ["c"], "Show custom fields"),
        ("nav", [], "Show navigation properties"),
        ("path", ["paths"], "Suggest JSON paths"),
        ("picklist", ["pk"], "Fetch picklist values (JSON)"),
        ("batch-picklists", [], "Fetch all picklist values for an entity"),
        ("model", [], "Show data model overview"),
    ]:
        sub = subs.add_parser(name, aliases=aliases, parents=[output_parent], help=help_text)
        sub.add_argument("name", nargs="+" if name in ("search", "model") else 1, help="Entity or search term")

    # Diff takes two entity names
    diff_sub = subs.add_parser("diff", parents=[output_parent], help="Compare two entities")
    diff_sub.add_argument("entity1", help="First entity")
    diff_sub.add_argument("entity2", help="Second entity")

    # Query has its own flags — no output_parent (--filter means $filter here, not property glob)
    query_sub = subs.add_parser("query", help="Execute OData query")
    query_sub.add_argument("name", help="Entity name")
    query_sub.add_argument("--select", default="", help="Comma-separated properties")
    query_sub.add_argument("--filter", dest="query_filter", default="", help="OData $filter expression")
    query_sub.add_argument("--orderby", default="", help="Property to sort by")
    query_sub.add_argument("--orderby-dir", default="asc", choices=["asc", "desc"])
    query_sub.add_argument("--top", default="20", help="Result limit")
    query_sub.add_argument("--expand", default="", help="Navigation properties to expand")
    query_sub.add_argument("--asof-date", default="", help="Point-in-time query date")
    query_sub.add_argument("--from-date", default="", help="Date range start")
    query_sub.add_argument("--to-date", default="", help="Date range end")

    return parser


# ── Helpers ──────────────────────────────────────────────────────


def _build_output_config(args: argparse.Namespace) -> OutputConfig:
    """Extract OutputConfig from parsed args."""
    config = OutputConfig(
        format=getattr(args, "format", "table"),
        wide=getattr(args, "wide", False),
        filter_pattern=getattr(args, "filter_pattern", ""),
        json_only=getattr(args, "json_only", False),
    )
    if config.json_only:
        config.format = "json"
    return config


def _build_cli_env(args: argparse.Namespace) -> dict[str, str]:
    """Extract connection env overrides from parsed args."""
    mapping = {
        "base_url": "SAP_BASE_URL",
        "auth_type": "SAP_AUTH_TYPE",
        "bearer_token": "SAP_BEARER_TOKEN",
        "username": "SAP_USERNAME",
        "password": "SAP_PASSWORD",
    }
    return {
        env_key: getattr(args, attr)
        for attr, env_key in mapping.items()
        if getattr(args, attr, None)
    }


def _build_connection(metadata_file: Path, cli_env: dict[str, str]):
    """Build SAPConnection from .env file + CLI overrides."""
    from .sap_client import SAPConnection, load_env_file

    env = {}
    env_path = metadata_file.with_suffix(".env")
    if env_path.exists():
        env = load_env_file(env_path)
    env.update(cli_env)

    connection = SAPConnection.from_env_dict(env)
    if not connection.base_url:
        console.print(
            "[red]Error: No base URL configured.[/]\n"
            "[dim]Provide --base-url or set SAP_BASE_URL in a .env file alongside your metadata XML[/]"
        )
        sys.exit(INVALID_INPUT)
    return connection


def _json_indent(output_config: OutputConfig) -> int | None:
    """Return JSON indent based on format."""
    return None if output_config.format == "json-compact" else 2


def _get_name(args: argparse.Namespace) -> str:
    """Get the name argument (handles list or string)."""
    name = args.name
    return name[0] if isinstance(name, list) else name


# ── Command Dispatch ─────────────────────────────────────────────

# Maps command names to handler functions.
# Each handler takes (explorer, args, metadata_file, cli_env, output_config).

def _cmd_entities(explorer, args, metadata_file, cli_env, out):
    entities_list = explorer.list_entities()
    if out.format == "table":
        repl.print_entities(entities_list)
    else:
        print(json.dumps(entities_list, indent=_json_indent(out), ensure_ascii=False))


def _cmd_emp(explorer, args, metadata_file, cli_env, out):
    entities_list = explorer.get_emp_entities()
    if out.format == "table":
        repl.print_entities(entities_list)
    else:
        print(json.dumps(entities_list, indent=_json_indent(out), ensure_ascii=False))


def _cmd_per(explorer, args, metadata_file, cli_env, out):
    entities_list = explorer.get_per_entities()
    if out.format == "table":
        repl.print_entities(entities_list)
    else:
        print(json.dumps(entities_list, indent=_json_indent(out), ensure_ascii=False))


def _cmd_entity(explorer, args, metadata_file, cli_env, out):
    name = _get_name(args)
    entity = explorer.get_entity(name)
    if not entity:
        suggestions = [r.entity for r in explorer.search(name) if r.type == "entity"][:5]
        repl.print_not_found(name, suggestions)
        sys.exit(NOT_FOUND)

    if out.format == "table":
        repl.print_entity_details(entity, wide=out.wide, filter_pattern=out.filter_pattern)
    elif out.format in ("json", "json-compact"):
        from .formatters import entity_to_dict
        data = entity_to_dict(entity, filter_pattern=out.filter_pattern)
        print(json.dumps(data, indent=_json_indent(out), ensure_ascii=False))
    elif out.format == "csv":
        from .formatters import properties_to_csv
        print(properties_to_csv(entity, filter_pattern=out.filter_pattern), end="")


def _cmd_search(explorer, args, metadata_file, cli_env, out):
    term = " ".join(args.name)
    results = explorer.search(term)
    if out.format == "table":
        repl.print_search_results(results)
    else:
        from .formatters import search_results_to_dicts
        data = search_results_to_dicts(results)
        print(json.dumps(data, indent=_json_indent(out), ensure_ascii=False))


def _cmd_custom(explorer, args, metadata_file, cli_env, out):
    name = _get_name(args)
    fields = explorer.get_custom_fields(name)
    if out.format == "table":
        repl.print_custom_fields(fields, name)
    else:
        data = [
            {"name": p.name, "type": p.type, "label": p.label,
             "picklist": p.picklist, "max_length": p.max_length,
             "creatable": p.creatable, "updatable": p.updatable}
            for p in fields
        ]
        print(json.dumps(data, indent=_json_indent(out), ensure_ascii=False))


def _cmd_nav(explorer, args, metadata_file, cli_env, out):
    name = _get_name(args)
    nav_props = explorer.get_navigation_properties(name)
    if out.format == "table":
        repl.print_navigation(nav_props, name)
    else:
        print(json.dumps(nav_props, indent=_json_indent(out), ensure_ascii=False))


def _cmd_diff(explorer, args, metadata_file, cli_env, out):
    comp = explorer.compare_entities(args.entity1, args.entity2)
    if out.format == "table":
        repl.print_comparison(comp)
    else:
        data = {
            "entity1": comp.entity1, "entity2": comp.entity2,
            "only_in_entity1": comp.only_in_entity1,
            "only_in_entity2": comp.only_in_entity2,
            "common": comp.common, "nav1": comp.nav1, "nav2": comp.nav2,
        }
        print(json.dumps(data, indent=_json_indent(out), ensure_ascii=False))


def _cmd_path(explorer, args, metadata_file, cli_env, out):
    name = _get_name(args)
    paths = explorer.suggest_json_paths(name)
    if out.format == "table":
        repl.print_json_paths(paths, name)
    else:
        print(json.dumps(paths, indent=_json_indent(out), ensure_ascii=False))


def _cmd_tree(explorer, args, metadata_file, cli_env, out):
    name = _get_name(args)
    entity = explorer.get_entity(name)
    if entity:
        repl.print_entity_tree(entity, explorer)
    else:
        suggestions = [r.entity for r in explorer.search(name) if r.type == "entity"][:5]
        repl.print_not_found(name, suggestions)
        sys.exit(NOT_FOUND)


def _cmd_model(explorer, args, metadata_file, cli_env, out):
    names = args.name if args.name else None
    if names:
        repl.print_data_model(explorer, names)
    else:
        repl.print_data_model(explorer)


def _cmd_picklists(explorer, args, metadata_file, cli_env, out):
    usage = explorer.get_picklist_usage()
    print(json.dumps(usage, indent=_json_indent(out), ensure_ascii=False))


def _cmd_picklist(explorer, args, metadata_file, cli_env, out):
    from .sap_client import SAPClient, SAPError

    name = _get_name(args)
    connection = _build_connection(metadata_file, cli_env)

    async def _fetch():
        client = SAPClient(connection)
        try:
            await client.authenticate()
            return await client.get_picklist_values(name)
        finally:
            await client.close()

    try:
        results = asyncio.run(_fetch())
    except SAPError as e:
        console.print(f"[red]{e}[/]", highlight=False)
        sys.exit(NETWORK_ERROR)

    print(json.dumps(results, indent=2, ensure_ascii=False))


def _cmd_batch_picklists(explorer, args, metadata_file, cli_env, out):
    from .sap_client import SAPClient, SAPError

    name = _get_name(args)
    entity = explorer.get_entity(name)
    if not entity:
        console.print(f"[red]Entity '{name}' not found[/]")
        sys.exit(NOT_FOUND)

    picklist_props = {
        p.name: {"picklist_id": p.picklist, "label": p.label or ""}
        for p in entity.properties.values()
        if p.picklist
    }

    if not picklist_props:
        print(json.dumps({"entity": name, "picklists": {}}, indent=_json_indent(out), ensure_ascii=False))
        return

    connection = _build_connection(metadata_file, cli_env)
    unique_picklists = {info["picklist_id"] for info in picklist_props.values()}

    async def _fetch_all():
        client = SAPClient(connection)
        try:
            await client.authenticate()
            fetched = {}
            for pl_id in sorted(unique_picklists):
                try:
                    values = await client.get_picklist_values(pl_id)
                    fetched[pl_id] = values
                except Exception as e:
                    fetched[pl_id] = {"error": str(e)}
            return fetched
        finally:
            await client.close()

    if not out.json_only:
        console.print(f"[dim]Fetching {len(unique_picklists)} picklists for {name}...[/]")

    try:
        fetched = asyncio.run(_fetch_all())
    except SAPError as e:
        console.print(f"[red]{e}[/]", highlight=False)
        sys.exit(NETWORK_ERROR)

    result = {"entity": name, "picklists": {}}
    for prop_name, info in sorted(picklist_props.items()):
        pl_id = info["picklist_id"]
        result["picklists"][prop_name] = {
            "picklist_id": pl_id, "label": info["label"],
            "values": fetched.get(pl_id, []),
        }
    print(json.dumps(result, indent=_json_indent(out), ensure_ascii=False))


def _cmd_query(explorer, args, metadata_file, cli_env, out):
    from .formatters import build_odata_query_params
    from .sap_client import SAPClient, SAPError

    # Validate date flags
    if args.asof_date and (args.from_date or args.to_date):
        console.print("[red]Error: --asof-date is mutually exclusive with --from-date/--to-date[/]")
        sys.exit(INVALID_INPUT)

    if args.top:
        try:
            if int(args.top) <= 0:
                raise ValueError
        except (ValueError, TypeError):
            console.print(f"[red]Error: --top must be a positive integer, got '{args.top}'[/]")
            sys.exit(INVALID_INPUT)

    name = _get_name(args) if isinstance(args.name, list) else args.name
    connection = _build_connection(metadata_file, cli_env)

    params = build_odata_query_params(
        selected=[s.strip() for s in args.select.split(",") if s.strip()],
        filter_expr=args.query_filter,
        orderby_prop=args.orderby,
        orderby_dir=args.orderby_dir,
        expanded=[e.strip() for e in args.expand.split(",") if e.strip()],
        top=args.top,
        asof_date=args.asof_date,
        from_date=args.from_date,
        to_date=args.to_date,
    )

    async def _fetch():
        client = SAPClient(connection)
        try:
            await client.authenticate()
            return await client.query_entity(name, params)
        finally:
            await client.close()

    try:
        results, full_url, raw_text, content_type = asyncio.run(_fetch())
    except SAPError as e:
        console.print(f"[red]{e}[/]", highlight=False)
        sys.exit(NETWORK_ERROR)

    print(json.dumps(results, indent=2, ensure_ascii=False))


# Command dispatch table — maps command name to handler function
COMMANDS = {
    "entities": _cmd_entities,
    "emp": _cmd_emp,
    "per": _cmd_per,
    "entity": _cmd_entity,
    "e": _cmd_entity,
    "tree": _cmd_tree,
    "t": _cmd_tree,
    "search": _cmd_search,
    "s": _cmd_search,
    "custom": _cmd_custom,
    "c": _cmd_custom,
    "nav": _cmd_nav,
    "diff": _cmd_diff,
    "path": _cmd_path,
    "paths": _cmd_path,
    "model": _cmd_model,
    "picklists": _cmd_picklists,
    "picklist": _cmd_picklist,
    "pk": _cmd_picklist,
    "batch-picklists": _cmd_batch_picklists,
    "query": _cmd_query,
}


# ── Main ─────────────────────────────────────────────────────────


def main():
    """Main CLI entry point."""
    parser = build_parser()
    args = parser.parse_args()

    metadata_file = Path(args.metadata_file).resolve()
    if not metadata_file.exists():
        console.print(f"[red]Error: File not found: {metadata_file}[/]")
        sys.exit(INVALID_INPUT)

    output_config = _build_output_config(args)
    cli_env = _build_cli_env(args)

    # Load metadata
    explorer = CSDLExplorer.from_file(metadata_file)
    if not output_config.json_only:
        console.print(f"[dim]Loaded {explorer.entity_count} entities from {metadata_file.name}[/]")

    # Determine command
    command = args.command
    use_tui = args.tui or command == "tui"

    if not command or command == "interactive" or use_tui:
        if use_tui:
            _run_textual_app(explorer)
        else:
            repl.run_interactive(explorer)
        return

    # Dispatch
    handler = COMMANDS.get(command)
    if not handler:
        console.print(f"[red]Unknown command: {command}[/]")
        console.print("[dim]Run with --help for usage[/]")
        sys.exit(INVALID_INPUT)

    err_console = Console(stderr=True) if output_config.json_only else console
    try:
        handler(explorer, args, metadata_file, cli_env, output_config)
    except Exception as e:
        err_console.print(f"[red]Error: {e}[/]")
        sys.exit(ERROR)


def _run_textual_app(explorer: CSDLExplorer):
    """Launch the Textual TUI application."""
    try:
        from .app import run_app
        run_app(explorer)
    except ImportError:
        console.print("[red]Error: Textual not installed.[/]")
        console.print("\n[dim]Install the TUI extra:[/]")
        console.print("  pip install csdl-explore\\[tui]")
        sys.exit(ERROR)


if __name__ == "__main__":
    main()
