"""Graph tab pane with navigation relationship visualization."""

from textual.widgets import TabPane, Input, Static
from textual.containers import Horizontal
from textual import on

from ..explorer import CSDLExplorer
from .nav_graph import NavigationGraph


class GraphTabPane(TabPane):
    """Graph tab showing entity navigation relationships as a force-directed graph.

    Args:
        explorer: The CSDL explorer instance.
    """

    DEFAULT_CSS = """
    GraphTabPane #graph-toolbar {
        dock: top;
        height: 3;
        padding: 0 1;
        background: $surface;
    }

    GraphTabPane #graph-focus-input {
        width: 40;
        margin: 0 1;
    }

    GraphTabPane #graph-focus-label {
        width: auto;
        padding: 1 0;
        color: $text-muted;
    }

    GraphTabPane NavigationGraph {
        height: 1fr;
        width: 1fr;
    }
    """

    def __init__(self, explorer: CSDLExplorer):
        super().__init__("Graph", id="graph-tab")
        self.explorer = explorer

    def compose(self):
        with Horizontal(id="graph-toolbar"):
            yield Static("[dim]Focus entity:[/]", id="graph-focus-label")
            yield Input(
                placeholder="Type entity name and press Enter (empty = hub)",
                id="graph-focus-input",
            )
        yield NavigationGraph(self.explorer, id="nav-graph")

    @on(Input.Submitted, "#graph-focus-input")
    def on_focus_submitted(self, event: Input.Submitted) -> None:
        """Rebuild graph centred on the entered entity."""
        entity_name = event.value.strip()
        graph = self.query_one("#nav-graph", NavigationGraph)

        if entity_name:
            # Validate entity exists
            entity = self.explorer.get_entity(entity_name)
            if not entity:
                self.app.notify(f"Entity '{entity_name}' not found", severity="warning")
                return
            graph.rebuild(focus_entity=entity_name)
        else:
            graph.rebuild(focus_entity=None)
