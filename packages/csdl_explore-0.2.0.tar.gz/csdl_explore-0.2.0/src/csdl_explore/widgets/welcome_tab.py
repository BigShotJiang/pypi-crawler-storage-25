"""Welcome tab pane with stats and global search."""

import os
from pathlib import Path
from typing import Optional

from textual.widgets import TabPane, Static, TabbedContent

from ..explorer import CSDLExplorer
from ..themes import TERMINAL_THEME
from .global_search import GlobalSearch


class WelcomeTabPane(TabPane):
    """Welcome screen tab showing metadata stats and global search.

    Args:
        explorer: The CSDL explorer instance.
        metadata_path: Optional path to the loaded metadata file.
    """

    DEFAULT_CSS = """
    WelcomeTabPane #welcome-subtabs > Tabs {
        display: none;
    }

    WelcomeTabPane #welcome-file-info {
        dock: top;
        height: auto;
        padding: 1 2;
        border-bottom: solid $secondary;
    }

    WelcomeTabPane #welcome-stats {
        height: auto;
        padding: 1 2;
        background: $surface;
    }

    WelcomeTabPane #global-search {
        height: 1fr;
    }
    """

    def __init__(self, explorer: CSDLExplorer, metadata_path: Optional[Path] = None):
        super().__init__("Welcome", id="welcome-tab")
        self.explorer = explorer
        self._metadata_path = metadata_path

    def on_mount(self) -> None:
        """Set focus to the global search when tab is mounted."""
        search = self.query_one("#global-search", GlobalSearch)
        search.focus()

    def compose(self):
        pc = TERMINAL_THEME.primary
        ac = TERMINAL_THEME.accent

        # File info
        if self._metadata_path and self._metadata_path.exists():
            size_bytes = os.path.getsize(self._metadata_path)
            if size_bytes >= 1_048_576:
                size_str = f"{size_bytes / 1_048_576:.1f} MB"
            elif size_bytes >= 1024:
                size_str = f"{size_bytes / 1024:.1f} KB"
            else:
                size_str = f"{size_bytes} B"
            file_info = f"[dim]Exploring[/] [{pc}]{self._metadata_path.name}[/] [dim]·[/] [dim]{size_str}[/]"
        else:
            file_info = f"[dim]Exploring[/] [{pc}]metadata[/]"

        # Stats
        total_props = sum(len(e.properties) for e in self.explorer.entities.values())
        total_custom = sum(
            len([p for p in e.properties.values() if p.name.startswith("custom")])
            for e in self.explorer.entities.values()
        )
        all_picklists = set()
        for entity in self.explorer.entities.values():
            for prop in entity.properties.values():
                if prop.picklist:
                    all_picklists.add(prop.picklist)

        stats_text = (
            f"[bold]Metadata Overview[/]\n\n"
            f"[{pc}]Entities:[/] {self.explorer.entity_count}\n"
            f"[{pc}]Properties:[/] {total_props:,}\n"
            f"[{ac}]Picklists:[/] {len(all_picklists)}\n"
            f"[{pc}]Custom Fields:[/] {total_custom:,}\n"
        )

        with TabbedContent(id="welcome-subtabs"):
            with TabPane("Overview", id="welcome-overview"):
                yield Static(file_info, id="welcome-file-info")
                yield Static(stats_text, id="welcome-stats")
                yield GlobalSearch(self.explorer, id="global-search")
