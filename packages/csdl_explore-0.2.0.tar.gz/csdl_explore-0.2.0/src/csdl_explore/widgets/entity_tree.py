"""Entity tree widget for navigating CSDL entities."""

from textual.widgets import Tree

from ..explorer import CSDLExplorer
from ..themes import TERMINAL_THEME


class EntityTree(Tree):
    """Tree widget for navigating entities.

    Builds a categorised tree from the explorer's entity list, grouping
    entities into Emp*, Per*, and alphabetical buckets.
    """

    def __init__(self, explorer: CSDLExplorer, **kwargs):
        """Initialise the entity tree.

        Args:
            explorer: The CSDL explorer instance providing entity data.
            **kwargs: Extra keyword arguments forwarded to ``Tree``.
        """
        super().__init__("CSDL Metadata", **kwargs)
        self.explorer = explorer
        self._filter_term = ""
        self._build_tree()

    def _build_tree(self):
        """Build the tree with Entities and Picklists as top-level branches."""
        root = self.root
        root.expand()

        # Use default theme colors for Rich markup (Tree labels go through
        # Rich's Text.from_markup, so Textual $-tokens don't work here).
        pc = TERMINAL_THEME.primary
        ac = TERMINAL_THEME.accent
        sc = TERMINAL_THEME.success
        wc = TERMINAL_THEME.warning

        # ── Entities branch ──────────────────────────────────────
        all_entity_names = self.explorer.list_entities()

        # Apply filter if set
        if self._filter_term:
            filter_lower = self._filter_term.lower()
            all_entity_names = [
                name for name in all_entity_names
                if filter_lower in name.lower()
            ]

        entities_node = root.add(
            f"[{pc}]Entities[/] ({len(all_entity_names)})", expand=True
        )

        emp_entities = [e for e in self.explorer.get_emp_entities() if e in all_entity_names]
        per_entities = [e for e in self.explorer.get_per_entities() if e in all_entity_names]
        other_entities = sorted(
            set(all_entity_names) - set(emp_entities) - set(per_entities)
        )

        if emp_entities:
            emp_node = entities_node.add(f"[{pc}]Emp*[/] ({len(emp_entities)})", expand=False)
            for entity in emp_entities:
                emp_node.add_leaf(entity, data={"type": "entity", "name": entity})

        if per_entities:
            per_node = entities_node.add(f"[{sc}]Per*[/] ({len(per_entities)})", expand=False)
            for entity in per_entities:
                per_node.add_leaf(entity, data={"type": "entity", "name": entity})

        if len(other_entities) > 50:
            current_letter = None
            current_node = None
            letter_count = {}
            for entity in other_entities:
                letter = entity[0].upper()
                letter_count[letter] = letter_count.get(letter, 0) + 1
            for entity in other_entities:
                letter = entity[0].upper()
                if letter != current_letter:
                    current_letter = letter
                    current_node = entities_node.add(
                        f"[{ac}]{letter}[/] ({letter_count[letter]})",
                        expand=False,
                    )
                current_node.add_leaf(entity, data={"type": "entity", "name": entity})
        else:
            other_node = entities_node.add(f"[{ac}]Other[/] ({len(other_entities)})", expand=False)
            for entity in other_entities:
                other_node.add_leaf(entity, data={"type": "entity", "name": entity})

        # ── Picklists branch ─────────────────────────────────────
        picklists = self.explorer.get_picklist_usage()

        # Apply filter if set
        if self._filter_term:
            filter_lower = self._filter_term.lower()
            picklists = {
                name: entities
                for name, entities in picklists.items()
                if filter_lower in name.lower()
            }

        if picklists:
            pick_node = root.add(
                f"[{wc}]Picklists[/] ({len(picklists)})", expand=False
            )
            for name in sorted(picklists):
                count = len(picklists[name])
                pick_node.add_leaf(
                    f"{name} [dim]({count} entities)[/]",
                    data={"type": "picklist", "name": name, "entities": picklists[name]},
                )

    def filter_tree(self, term: str) -> int:
        """Filter the tree to show only matching entities and picklists.

        Args:
            term: Search term to filter by (case-insensitive).

        Returns:
            Number of matching items (entities + picklists).
        """
        self._filter_term = term
        self.clear()
        self._build_tree()

        # Count leaf nodes (entities and picklists)
        count = 0
        for node in self.root.children:
            count += self._count_leaves(node)
        return count

    def _count_leaves(self, node) -> int:
        """Recursively count leaf nodes."""
        if not node.children:
            return 1 if node.data else 0
        return sum(self._count_leaves(child) for child in node.children)
