"""Interactive navigation graph widget - force-directed entity relationship visualization."""

from textual.widget import Widget
from textual.reactive import reactive
from textual.message import Message
from textual import events, work
from textual.widgets import Static

from rich.text import Text

from ..explorer import CSDLExplorer
from ..formatters import build_navigation_graph
from ..themes import TERMINAL_THEME


class NavigationGraph(Widget):
    """Interactive graph visualization of entity navigation relationships.

    Shows entities as labeled boxes connected by edges. Uses force-directed
    layout from NetworkX. Supports pan, zoom, Tab navigation, and Enter to open.

    Args:
        explorer: The CSDL explorer instance.
        focus_entity: Optional entity name to centre the graph on.
    """

    can_focus = True

    DEFAULT_CSS = """
    NavigationGraph {
        height: 1fr;
        width: 1fr;
    }

    NavigationGraph #graph-status {
        width: 100%;
        height: 100%;
        content-align: center middle;
    }

    NavigationGraph #graph-canvas {
        width: 100%;
        height: 1fr;
    }
    """

    BINDINGS = [
        ("up", "pan('up')", "Pan Up"),
        ("down", "pan('down')", "Pan Down"),
        ("left", "pan('left')", "Pan Left"),
        ("right", "pan('right')", "Pan Right"),
        ("plus", "zoom('in')", "Zoom In"),
        ("minus", "zoom('out')", "Zoom Out"),
        ("tab", "navigate('next')", "Next Node"),
        ("shift+tab", "navigate('prev')", "Prev Node"),
        ("enter", "select", "Open"),
        ("home", "reset", "Reset"),
    ]

    zoom_level = reactive(1.0)

    class EntitySelected(Message):
        """Posted when a node is selected for opening."""

        def __init__(self, entity_name: str) -> None:
            super().__init__()
            self.entity_name = entity_name

    def __init__(self, explorer: CSDLExplorer, focus_entity: str | None = None, **kwargs) -> None:
        super().__init__(**kwargs)
        self._explorer = explorer
        self._focus_entity = focus_entity
        self._graph_data: dict | None = None
        self._pan_x = 0.0
        self._pan_y = 0.0
        self._zoom = 1.0
        self._selected_node: str | None = None
        self._node_list: list[str] = []
        self._zoom_levels = [0.2, 0.3, 0.5, 0.7, 1.0, 1.3, 1.6, 2.0, 2.5, 3.0, 4.0]
        self._zoom_index = 4  # Start at 1.0

    def compose(self):
        yield Static("Building graph...", id="graph-status")
        yield Static(id="graph-canvas")

    def on_mount(self) -> None:
        """Compute graph on mount in background thread."""
        canvas = self.query_one("#graph-canvas", Static)
        canvas.display = False
        self._build_graph_async()

    def on_resize(self) -> None:
        """Re-render on resize."""
        if self._graph_data:
            self._render_graph()

    def rebuild(self, focus_entity: str | None = None) -> None:
        """Rebuild the graph with a new focus entity.

        Args:
            focus_entity: Entity name to centre on, or None for hub.
        """
        self._focus_entity = focus_entity
        status = self.query_one("#graph-status", Static)
        status.update(f"Building graph for {focus_entity or 'hub'}...")
        status.display = True
        self.query_one("#graph-canvas", Static).display = False
        self._build_graph_async()

    @work(thread=True)
    def _build_graph_async(self) -> None:
        """Build graph in worker thread."""
        try:
            graph_data = build_navigation_graph(
                self._explorer,
                focus_entity=self._focus_entity,
                max_hops=2,
            )
            self.app.call_from_thread(self._on_graph_ready, graph_data)
        except Exception as e:
            self.app.call_from_thread(self._on_graph_error, str(e))

    def _on_graph_ready(self, graph_data: dict) -> None:
        """Handle graph computation completion."""
        self._graph_data = graph_data

        # Build sorted node list for Tab navigation
        self._node_list = sorted(n["id"] for n in graph_data["nodes"])

        # Select focus node by default
        focus = graph_data.get("focus")
        if focus and focus in self._node_list:
            self._selected_node = focus
        elif self._node_list:
            self._selected_node = self._node_list[0]

        # Centre viewport on focus entity
        positions = graph_data["positions"]
        if focus and focus in positions:
            self._pan_x, self._pan_y = positions[focus]
        elif positions:
            xs = [p[0] for p in positions.values()]
            ys = [p[1] for p in positions.values()]
            self._pan_x = sum(xs) / len(xs)
            self._pan_y = sum(ys) / len(ys)

        self._zoom_index = 4
        self._zoom = 1.0

        # Show canvas
        self.query_one("#graph-status", Static).display = False
        canvas = self.query_one("#graph-canvas", Static)
        canvas.display = True
        self._render_graph()

    def _on_graph_error(self, error: str) -> None:
        """Handle graph computation error."""
        status = self.query_one("#graph-status", Static)
        status.update(f"[red]Error building graph:[/] {error}")

    def _render_graph(self) -> None:
        """Render the graph to a character grid and update the canvas."""
        if not self._graph_data or not self._graph_data["nodes"]:
            self.query_one("#graph-canvas", Static).update(
                "[dim]No navigation relationships found[/]"
            )
            return

        canvas = self.query_one("#graph-canvas", Static)
        w = max(self.size.width - 2, 60)
        h = max(self.size.height - 4, 15)  # Reserve 2 rows for status

        positions = self._graph_data["positions"]

        # Viewport in world coordinates — aspect-ratio corrected
        # Terminal chars are ~2x taller than wide, so stretch x
        aspect = (w / h) * 0.5  # Approximate terminal char aspect
        view_h = 10.0 / self._zoom
        view_w = view_h * aspect
        vx1 = self._pan_x - view_w / 2
        vy1 = self._pan_y - view_h / 2
        vx2 = self._pan_x + view_w / 2
        vy2 = self._pan_y + view_h / 2

        # Map world -> screen, clamped to canvas
        def to_screen(wx: float, wy: float) -> tuple[int, int]:
            sx = int((wx - vx1) / (vx2 - vx1) * w)
            sy = int((wy - vy1) / (vy2 - vy1) * h)
            return sx, sy

        # Collect visible nodes with screen positions
        visible = []
        for node in self._graph_data["nodes"]:
            nid = node["id"]
            if nid not in positions:
                continue
            wx, wy = positions[nid]
            if vx1 <= wx <= vx2 and vy1 <= wy <= vy2:
                sx, sy = to_screen(wx, wy)
                visible.append((node, sx, sy))

        # Build character grid
        grid: dict[tuple[int, int], str] = {}
        occupied_rects: list[tuple[int, int, int, int]] = []  # (x1, y1, x2, y2)

        def rect_collides(x1: int, y1: int, x2: int, y2: int) -> bool:
            for ox1, oy1, ox2, oy2 in occupied_rects:
                if x1 <= ox2 + 1 and x2 >= ox1 - 1 and y1 <= oy2 + 1 and y2 >= oy1 - 1:
                    return True
            return False

        # Render edges first (so boxes draw on top)
        if self._zoom >= 0.7:
            for edge in self._graph_data["edges"]:
                src, tgt = edge["source"], edge["target"]
                if src not in positions or tgt not in positions:
                    continue
                swx, swy = positions[src]
                twx, twy = positions[tgt]
                if not (vx1 <= swx <= vx2 and vy1 <= swy <= vy2):
                    continue
                if not (vx1 <= twx <= vx2 and vy1 <= twy <= vy2):
                    continue
                sx1, sy1 = to_screen(swx, swy)
                sx2, sy2 = to_screen(twx, twy)
                self._draw_edge(grid, sx1, sy1, sx2, sy2)

        # Sort: focus first, then by degree so important nodes get placed first
        visible.sort(
            key=lambda v: (
                not v[0].get("is_focus", False),
                -(v[0]["incoming_count"] + v[0]["outgoing_count"]),
            )
        )

        # Render nodes — try full box first, fall back to abbreviated label
        for node, sx, sy in visible:
            nid = node["id"]
            is_selected = nid == self._selected_node
            is_focus = node.get("is_focus", False)

            if self._zoom >= 0.5:
                label = nid
                box_w = len(label) + 4
                box_h = 3
                bx1 = sx - box_w // 2
                by1 = sy - 1
                bx2 = bx1 + box_w - 1
                by2 = by1 + box_h - 1

                # Try full box if it fits on screen and doesn't collide
                if (bx1 >= 0 and by1 >= 0 and bx2 < w and by2 < h
                        and not rect_collides(bx1, by1, bx2, by2)):
                    self._draw_box(grid, bx1, by1, label, is_selected, is_focus)
                    occupied_rects.append((bx1, by1, bx2, by2))
                    continue

                # Fall back to abbreviated label (first 3 chars + ellipsis or full if short)
                abbr = nid[:4] if len(nid) > 4 else nid
                abbr_w = len(abbr)
                ax1 = sx - abbr_w // 2
                ay = sy
                if (0 <= ay < h and 0 <= ax1 and ax1 + abbr_w < w
                        and not rect_collides(ax1, ay, ax1 + abbr_w - 1, ay)):
                    color = TERMINAL_THEME.primary if (is_selected or is_focus) else "#888888"
                    for i, ch in enumerate(abbr):
                        grid[(ay, ax1 + i)] = f"[{color}]{ch}[/]"
                    occupied_rects.append((ax1, ay, ax1 + abbr_w - 1, ay))
            else:
                # Dot mode at low zoom
                if 0 <= sx < w and 0 <= sy < h:
                    color = TERMINAL_THEME.primary if (is_selected or is_focus) else "#555555"
                    grid[(sy, sx)] = f"[{color}]●[/]"

        # Build full-height output so status bar stays pinned at bottom
        lines = []
        for row in range(h):
            parts = []
            for col in range(w):
                parts.append(grid.get((row, col), " "))
            lines.append("".join(parts))

        # Status line — always at the bottom
        node_count = len(self._graph_data["nodes"])
        total = self._graph_data.get("total_entities", 0)
        focus = self._graph_data.get("focus", "")
        sel = self._selected_node or ""
        status = (
            f"[dim]Nodes: {node_count}/{total} | "
            f"Focus: {focus} | Selected: [bold]{sel}[/bold] | "
            f"Zoom: {self._zoom:.1f}x | "
            f"↑↓←→ Pan  +/- Zoom  Tab Nav  Enter Open  Home Reset[/]"
        )
        lines.append(status)

        canvas.update("\n".join(lines))

    def _draw_box(
        self,
        grid: dict,
        x: int,
        y: int,
        label: str,
        is_selected: bool,
        is_focus: bool,
    ) -> None:
        """Draw a labeled box at (x, y)."""
        width = len(label) + 4

        if is_focus:
            border_color = TERMINAL_THEME.primary
            text_color = TERMINAL_THEME.primary
            tl, tr, bl, br, h_char, v_char = "╔", "╗", "╚", "╝", "═", "║"
        elif is_selected:
            border_color = TERMINAL_THEME.primary
            text_color = "white"
            tl, tr, bl, br, h_char, v_char = "┌", "┐", "└", "┘", "─", "│"
        else:
            border_color = "#666666"
            text_color = "#aaaaaa"
            tl, tr, bl, br, h_char, v_char = "┌", "┐", "└", "┘", "─", "│"

        bc = border_color

        # Top border
        grid[(y, x)] = f"[{bc}]{tl}[/]"
        for i in range(1, width - 1):
            grid[(y, x + i)] = f"[{bc}]{h_char}[/]"
        grid[(y, x + width - 1)] = f"[{bc}]{tr}[/]"

        # Middle row
        grid[(y + 1, x)] = f"[{bc}]{v_char}[/]"
        padded = f" {label} "
        for i, ch in enumerate(padded):
            grid[(y + 1, x + 1 + i)] = f"[{text_color}]{ch}[/]"
        grid[(y + 1, x + width - 1)] = f"[{bc}]{v_char}[/]"

        # Bottom border
        grid[(y + 2, x)] = f"[{bc}]{bl}[/]"
        for i in range(1, width - 1):
            grid[(y + 2, x + i)] = f"[{bc}]{h_char}[/]"
        grid[(y + 2, x + width - 1)] = f"[{bc}]{br}[/]"

    def _draw_edge(
        self,
        grid: dict,
        x1: int,
        y1: int,
        x2: int,
        y2: int,
    ) -> None:
        """Draw a simple L-shaped edge between two points."""
        color = "#333333"
        mid_x = x2  # Go horizontal first, then vertical

        # Horizontal segment
        start_x, end_x = min(x1, mid_x), max(x1, mid_x)
        for col in range(start_x, end_x + 1):
            key = (y1, col)
            if key not in grid:
                grid[key] = f"[{color}]─[/]"

        # Vertical segment
        start_y, end_y = min(y1, y2), max(y1, y2)
        for row in range(start_y, end_y + 1):
            key = (row, mid_x)
            if key not in grid:
                grid[key] = f"[{color}]│[/]"

        # Corner
        key = (y1, mid_x)
        if key not in grid:
            if y2 > y1:
                grid[key] = f"[{color}]┐[/]" if mid_x < x1 else f"[{color}]┌[/]"
            else:
                grid[key] = f"[{color}]┘[/]" if mid_x < x1 else f"[{color}]└[/]"

    # ── Actions ──────────────────────────────────────────────────

    def action_pan(self, direction: str = "up") -> None:
        """Pan the viewport."""
        step = 0.5 / self._zoom
        if direction == "up":
            self._pan_y -= step
        elif direction == "down":
            self._pan_y += step
        elif direction == "left":
            self._pan_x -= step
        elif direction == "right":
            self._pan_x += step
        self._render_graph()

    def action_zoom(self, direction: str = "in") -> None:
        """Zoom in or out."""
        if direction == "in":
            self._zoom_index = min(self._zoom_index + 1, len(self._zoom_levels) - 1)
        else:
            self._zoom_index = max(self._zoom_index - 1, 0)
        self._zoom = self._zoom_levels[self._zoom_index]
        self.zoom_level = self._zoom
        self._render_graph()

    def action_navigate(self, direction: str = "next") -> None:
        """Navigate between nodes."""
        if not self._node_list or not self._selected_node:
            return
        try:
            idx = self._node_list.index(self._selected_node)
        except ValueError:
            idx = 0

        if direction == "next":
            idx = (idx + 1) % len(self._node_list)
        else:
            idx = (idx - 1) % len(self._node_list)

        self._selected_node = self._node_list[idx]

        # Pan to selected node
        positions = self._graph_data["positions"] if self._graph_data else {}
        if self._selected_node in positions:
            self._pan_x, self._pan_y = positions[self._selected_node]

        self._render_graph()

    def action_select(self) -> None:
        """Open the selected node's entity."""
        if self._selected_node:
            self.post_message(self.EntitySelected(self._selected_node))

    def action_reset(self) -> None:
        """Reset viewport to focus entity."""
        if not self._graph_data or not self._graph_data["positions"]:
            return
        focus = self._graph_data.get("focus")
        positions = self._graph_data["positions"]
        if focus and focus in positions:
            self._pan_x, self._pan_y = positions[focus]
        self._zoom_index = 4
        self._zoom = 1.0
        self.zoom_level = 1.0
        self._selected_node = focus
        self._render_graph()
