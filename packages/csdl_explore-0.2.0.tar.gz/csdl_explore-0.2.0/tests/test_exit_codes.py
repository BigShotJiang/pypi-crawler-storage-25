from csdl_explore.exit_codes import OK, ERROR, INVALID_INPUT, NETWORK_ERROR, NOT_FOUND

def test_exit_codes_are_distinct():
    codes = [OK, ERROR, INVALID_INPUT, NETWORK_ERROR, NOT_FOUND]
    assert len(set(codes)) == 5

def test_exit_codes_values():
    assert OK == 0
    assert ERROR == 1
    assert INVALID_INPUT == 2
    assert NETWORK_ERROR == 3
    assert NOT_FOUND == 4
