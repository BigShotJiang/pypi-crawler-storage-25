from csdl_explore.sap_client import SAPError, parse_sap_error

def test_parse_sap_error_property_not_found():
    body = '{"error":{"code":"COE_PROPERTY_NOT_FOUND","message":{"value":"[COE0021]Invalid property names: PicklistOption/value"}}}'
    err = parse_sap_error(400, "https://example.com/odata/v2/EmpJob", body)
    assert isinstance(err, SAPError)
    assert err.code == "COE_PROPERTY_NOT_FOUND"
    assert "Invalid property" in err.message
    assert len(err.suggestions) > 0

def test_parse_sap_error_unknown_code():
    body = '{"error":{"code":"UNKNOWN_CODE","message":{"value":"Something broke"}}}'
    err = parse_sap_error(500, "https://example.com/odata/v2/EmpJob", body)
    assert err.code == "UNKNOWN_CODE"
    assert "Something broke" in err.message

def test_parse_sap_error_invalid_json():
    err = parse_sap_error(500, "https://example.com", "not json at all")
    assert err.code == "HTTP_500"
    assert "not json at all" in err.message

def test_sap_error_str():
    err = SAPError(
        status=400, code="COE_PROPERTY_NOT_FOUND", message="Invalid property",
        url="https://example.com", suggestions=["Check spelling"],
    )
    text = str(err)
    assert "400" in text
    assert "Invalid property" in text
    assert "Check spelling" in text
