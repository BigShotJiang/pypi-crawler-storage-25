# Visual Refresh Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Update the color palette to terminal green + amber accent on true black, and rework the Welcome tab to be a persistent home base showing the loaded file, with the Graph as an on-demand feature.

**Architecture:** Pure visual/behavioral changes across themes.py, app.py, welcome_tab.py, and several widgets that hardcode hex colors. No new modules, no new dependencies, no architectural changes.

**Tech Stack:** Python, Textual, Rich

**Spec:** `docs/superpowers/specs/2026-03-31-visual-refresh-design.md`

---

### Task 1: Update Color Palette in themes.py

**Files:**
- Modify: `src/csdl_explore/themes.py`

- [ ] **Step 1: Rename VERCEL_THEME to TERMINAL_THEME and update colors**

Replace the entire `VERCEL_THEME` definition and its palette entry:

```python
TERMINAL_THEME = Theme(
    name="terminal-green",
    primary="#00FF41",
    secondary="#222222",
    accent="#FFB800",
    foreground="#cccccc",
    background="#000000",
    surface="#0a0a0a",
    panel="#111111",
    warning="#FFB800",
    error="#ff3333",
    success="#00FF41",
    dark=True,
)
```

- [ ] **Step 2: Update ALL_THEMES to use TERMINAL_THEME**

```python
ALL_THEMES = [TERMINAL_THEME, CLASSIC_THEME]
```

- [ ] **Step 3: Update the Rich REPL palette**

Replace the `"terminal-vercel-green"` key with `"terminal-green"`:

```python
PALETTES: dict[str, dict[str, str]] = {
    "terminal-green": {
        "primary": "#00FF41",
        "secondary": "#888888",
        "accent": "#FFB800",
        "entity": "#00FF41",
        "property": "#cccccc",
        "key": "#FFB800",
        "required": "#ff3333",
        "crud": "#00FF41",
        "hidden": "dim",
        "no_filter": "#ff3333",
        "nav": "#00FF41",
        "picklist": "#FFB800",
        "dim": "dim",
        "label": "dim",
    },
    "classic": {
        # ... unchanged ...
    },
}

DEFAULT_PALETTE = "terminal-green"
```

- [ ] **Step 4: Run app to verify theme loads**

```bash
cd D:/Developer/py-csdl-explorer && python -c "from csdl_explore.themes import TERMINAL_THEME, ALL_THEMES, PALETTES, DEFAULT_PALETTE; print('Theme:', TERMINAL_THEME.name); print('Themes:', [t.name for t in ALL_THEMES]); print('Palette keys:', list(PALETTES.keys())); print('Default:', DEFAULT_PALETTE)"
```

Expected: Theme: terminal-green, Themes: ['terminal-green', 'classic'], Palette keys: ['terminal-green', 'classic'], Default: terminal-green

- [ ] **Step 5: Commit**

```bash
git add src/csdl_explore/themes.py
git commit -m "feat: replace vercel theme with terminal green + amber accent palette"
```

---

### Task 2: Update app.py — Theme Reference and Default Theme

**Files:**
- Modify: `src/csdl_explore/app.py`

- [ ] **Step 1: Update the default theme name in __init__**

In `CSDLExplorerApp.__init__`, change:

```python
# Old
self.theme = "terminal-vercel-green"
# New
self.theme = "terminal-green"
```

- [ ] **Step 2: Update the VERCEL_THEME import to TERMINAL_THEME**

In the imports at top of `app.py`, the file imports `ALL_THEMES` and `THEME_NAMES` — no direct `VERCEL_THEME` import, so no import change needed. Just the theme string in step 1.

- [ ] **Step 3: Run import check**

```bash
cd D:/Developer/py-csdl-explorer && python -c "from csdl_explore.app import CSDLExplorerApp; print('OK')"
```

Expected: OK

- [ ] **Step 4: Commit**

```bash
git add src/csdl_explore/app.py
git commit -m "feat: use terminal-green as default theme"
```

---

### Task 3: Update Hardcoded Colors in entity_tree.py

**Files:**
- Modify: `src/csdl_explore/widgets/entity_tree.py`

- [ ] **Step 1: Change VERCEL_THEME import to TERMINAL_THEME**

```python
# Old
from ..themes import VERCEL_THEME
# New
from ..themes import TERMINAL_THEME
```

- [ ] **Step 2: Update all VERCEL_THEME references in _build_tree**

```python
# Old
pc = VERCEL_THEME.primary
ac = VERCEL_THEME.accent
sc = VERCEL_THEME.success
wc = VERCEL_THEME.warning
# New
pc = TERMINAL_THEME.primary
ac = TERMINAL_THEME.accent
sc = TERMINAL_THEME.success
wc = TERMINAL_THEME.warning
```

These variables are used in Rich markup throughout the method — no further changes needed since the colors now flow from the theme object.

- [ ] **Step 3: Run import check**

```bash
cd D:/Developer/py-csdl-explorer && python -c "from csdl_explore.widgets.entity_tree import EntityTree; print('OK')"
```

Expected: OK

- [ ] **Step 4: Commit**

```bash
git add src/csdl_explore/widgets/entity_tree.py
git commit -m "refactor: use TERMINAL_THEME in entity tree"
```

---

### Task 4: Update Hardcoded Colors in details_tab.py

**Files:**
- Modify: `src/csdl_explore/widgets/details_tab.py`

- [ ] **Step 1: Change VERCEL_THEME import to TERMINAL_THEME**

```python
# Old
from ..themes import VERCEL_THEME
# New
from ..themes import TERMINAL_THEME
```

- [ ] **Step 2: Update all VERCEL_THEME references in _populate**

```python
# Old
pc = VERCEL_THEME.primary
ac = VERCEL_THEME.accent
sc = VERCEL_THEME.success
# New
pc = TERMINAL_THEME.primary
ac = TERMINAL_THEME.accent
sc = TERMINAL_THEME.success
```

- [ ] **Step 3: Run import check**

```bash
cd D:/Developer/py-csdl-explorer && python -c "from csdl_explore.widgets.details_tab import DetailsTab; print('OK')"
```

Expected: OK

- [ ] **Step 4: Commit**

```bash
git add src/csdl_explore/widgets/details_tab.py
git commit -m "refactor: use TERMINAL_THEME in details tab"
```

---

### Task 5: Update Hardcoded Colors in picklist_overview_tab.py

**Files:**
- Modify: `src/csdl_explore/widgets/picklist_overview_tab.py`

- [ ] **Step 1: Change VERCEL_THEME import to TERMINAL_THEME**

```python
# Old
from ..themes import VERCEL_THEME
# New
from ..themes import TERMINAL_THEME
```

- [ ] **Step 2: Update all VERCEL_THEME references in _populate**

```python
# Old
wc = VERCEL_THEME.warning
pc = VERCEL_THEME.primary
# New
wc = TERMINAL_THEME.warning
pc = TERMINAL_THEME.primary
```

- [ ] **Step 3: Commit**

```bash
git add src/csdl_explore/widgets/picklist_overview_tab.py
git commit -m "refactor: use TERMINAL_THEME in picklist overview tab"
```

---

### Task 6: Update Hardcoded Colors in picklist_impact_tab.py

**Files:**
- Modify: `src/csdl_explore/widgets/picklist_impact_tab.py`

- [ ] **Step 1: Change VERCEL_THEME import to TERMINAL_THEME**

```python
# Old
from ..themes import VERCEL_THEME
# New
from ..themes import TERMINAL_THEME
```

- [ ] **Step 2: Update all VERCEL_THEME references in _setup**

```python
# Old
wc = VERCEL_THEME.warning
# New
wc = TERMINAL_THEME.warning
```

- [ ] **Step 3: Commit**

```bash
git add src/csdl_explore/widgets/picklist_impact_tab.py
git commit -m "refactor: use TERMINAL_THEME in picklist impact tab"
```

---

### Task 7: Update Hardcoded Colors in properties_tab.py

**Files:**
- Modify: `src/csdl_explore/widgets/properties_tab.py`

- [ ] **Step 1: Change VERCEL_THEME import to TERMINAL_THEME**

```python
# Old
from ..themes import VERCEL_THEME
# New
from ..themes import TERMINAL_THEME
```

- [ ] **Step 2: Update VERCEL_THEME reference in _setup_table**

```python
# Old
ac = VERCEL_THEME.accent
# New
ac = TERMINAL_THEME.accent
```

- [ ] **Step 3: Commit**

```bash
git add src/csdl_explore/widgets/properties_tab.py
git commit -m "refactor: use TERMINAL_THEME in properties tab"
```

---

### Task 8: Update Hardcoded Colors in nav_graph.py

**Files:**
- Modify: `src/csdl_explore/widgets/nav_graph.py`

- [ ] **Step 1: Add TERMINAL_THEME import**

At the top of the file, add:

```python
from ..themes import TERMINAL_THEME
```

- [ ] **Step 2: Replace hardcoded #00dc82 with theme references**

In the `_render_graph` method (around line 264-271), replace hardcoded colors:

```python
# Old (line ~264)
color = "#00dc82" if (is_selected or is_focus) else "#888888"
# New
color = TERMINAL_THEME.primary if (is_selected or is_focus) else "#888888"

# Old (line ~271)
color = "#00dc82" if (is_selected or is_focus) else "#555555"
# New
color = TERMINAL_THEME.primary if (is_selected or is_focus) else "#555555"
```

In the `_draw_box` method (around line 310-314), replace hardcoded colors:

```python
# Old
border_color = "#00dc82"
text_color = "#00dc82"
# New (for is_focus block, ~line 310-311)
border_color = TERMINAL_THEME.primary
text_color = TERMINAL_THEME.primary

# Old (for is_selected block, ~line 314)
border_color = "#00dc82"
# New
border_color = TERMINAL_THEME.primary
```

- [ ] **Step 3: Commit**

```bash
git add src/csdl_explore/widgets/nav_graph.py
git commit -m "refactor: use TERMINAL_THEME in navigation graph"
```

---

### Task 9: Update Hardcoded Colors in results_viewer.py

**Files:**
- Modify: `src/csdl_explore/widgets/results_viewer.py`

- [ ] **Step 1: Add TERMINAL_THEME import**

At the top of the file, add:

```python
from ..themes import TERMINAL_THEME
```

- [ ] **Step 2: Replace hardcoded #00dc82 in tree rendering**

Around line 207:

```python
# Old
rich_tree = RichTree(f"[bold #00dc82]{entity_name}[/] [dim]({len(results)} results)[/]")
# New
rich_tree = RichTree(f"[bold {TERMINAL_THEME.primary}]{entity_name}[/] [dim]({len(results)} results)[/]")
```

Around line 231:

```python
# Old
branch = parent.add(f"[#00dc82]{label}[/]{hint}")
# New
branch = parent.add(f"[{TERMINAL_THEME.primary}]{label}[/]{hint}")
```

Around line 235:

```python
# Old
parent.add(f"[#00dc82]{label}[/]{hint}")
# New
parent.add(f"[{TERMINAL_THEME.primary}]{label}[/]{hint}")
```

- [ ] **Step 3: Commit**

```bash
git add src/csdl_explore/widgets/results_viewer.py
git commit -m "refactor: use TERMINAL_THEME in results viewer"
```

---

### Task 10: Update welcome_tab.py — File Info, Amber Picklists, Graph Button

**Files:**
- Modify: `src/csdl_explore/widgets/welcome_tab.py`

- [ ] **Step 1: Update imports and constructor to accept metadata_path**

```python
"""Welcome tab pane with stats and global search."""

import os
from pathlib import Path
from typing import Optional

from textual.widgets import TabPane, Static, TabbedContent, Button
from textual.containers import Vertical
from textual import on

from ..explorer import CSDLExplorer
from ..themes import TERMINAL_THEME
from .global_search import GlobalSearch
```

- [ ] **Step 2: Update WelcomeTabPane constructor**

```python
class WelcomeTabPane(TabPane):
    """Welcome screen tab showing metadata stats and global search.

    Args:
        explorer: The CSDL explorer instance.
        metadata_path: Optional path to the loaded metadata file.
    """

    DEFAULT_CSS = """
    WelcomeTabPane #welcome-subtabs > Tabs {
        display: none;
    }

    WelcomeTabPane #welcome-file-info {
        dock: top;
        height: auto;
        padding: 1 2;
        border-bottom: solid $secondary;
    }

    WelcomeTabPane #welcome-stats {
        height: auto;
        padding: 1 2;
        background: $surface;
    }

    WelcomeTabPane #welcome-actions {
        height: auto;
        padding: 0 2;
    }

    WelcomeTabPane #open-graph-btn {
        margin: 1 0;
    }

    WelcomeTabPane #global-search {
        height: 1fr;
    }
    """

    def __init__(self, explorer: CSDLExplorer, metadata_path: Optional[Path] = None):
        super().__init__("Welcome", id="welcome-tab")
        self.explorer = explorer
        self._metadata_path = metadata_path
```

- [ ] **Step 3: Update compose() with file info, amber picklists, and graph button**

```python
    def compose(self):
        pc = TERMINAL_THEME.primary
        ac = TERMINAL_THEME.accent

        # File info
        if self._metadata_path and self._metadata_path.exists():
            size_bytes = os.path.getsize(self._metadata_path)
            if size_bytes >= 1_048_576:
                size_str = f"{size_bytes / 1_048_576:.1f} MB"
            elif size_bytes >= 1024:
                size_str = f"{size_bytes / 1024:.1f} KB"
            else:
                size_str = f"{size_bytes} B"
            file_info = f"[dim]Exploring[/] [{pc}]{self._metadata_path.name}[/] [dim]·[/] [dim]{size_str}[/]"
        else:
            file_info = f"[dim]Exploring[/] [{pc}]metadata[/]"

        # Stats
        total_props = sum(len(e.properties) for e in self.explorer.entities.values())
        total_custom = sum(
            len([p for p in e.properties.values() if p.name.startswith("custom")])
            for e in self.explorer.entities.values()
        )
        all_picklists = set()
        for entity in self.explorer.entities.values():
            for prop in entity.properties.values():
                if prop.picklist:
                    all_picklists.add(prop.picklist)

        stats_text = (
            f"[bold]Metadata Overview[/]\n\n"
            f"[{pc}]Entities:[/] {self.explorer.entity_count}\n"
            f"[{pc}]Properties:[/] {total_props:,}\n"
            f"[{ac}]Picklists:[/] {len(all_picklists)}\n"
            f"[{pc}]Custom Fields:[/] {total_custom:,}\n"
        )

        with TabbedContent(id="welcome-subtabs"):
            with TabPane("Overview", id="welcome-overview"):
                yield Static(file_info, id="welcome-file-info")
                yield Static(stats_text, id="welcome-stats")
                yield Button("Open Graph View", id="open-graph-btn", variant="default")
                yield GlobalSearch(self.explorer, id="global-search")
```

- [ ] **Step 4: Add graph button handler via Textual message**

Add a message class and button handler:

```python
    class OpenGraphRequested(Message):
        """Posted when user clicks 'Open Graph View'."""
        pass

    @on(Button.Pressed, "#open-graph-btn")
    def on_open_graph(self, event: Button.Pressed) -> None:
        """Handle graph button press."""
        self.post_message(self.OpenGraphRequested())
```

Also add the Message import at the top:

```python
from textual.message import Message
```

- [ ] **Step 5: Run import check**

```bash
cd D:/Developer/py-csdl-explorer && python -c "from csdl_explore.widgets.welcome_tab import WelcomeTabPane; print('OK')"
```

Expected: OK

- [ ] **Step 6: Commit**

```bash
git add src/csdl_explore/widgets/welcome_tab.py
git commit -m "feat: welcome tab with file info, amber picklists, graph button"
```

---

### Task 11: Update app.py — Graph on Demand, Welcome Auto-Reopen

**Files:**
- Modify: `src/csdl_explore/app.py`

- [ ] **Step 1: Update on_mount to only add Welcome tab (no Graph)**

```python
    def on_mount(self) -> None:
        """Add welcome tab after mount."""
        tabs = self.query_one("#tabs", TabbedContent)
        tabs.add_pane(WelcomeTabPane(self.explorer, metadata_path=self.metadata_path))
```

- [ ] **Step 2: Add handler for OpenGraphRequested message**

Add this method to `CSDLExplorerApp`:

```python
    @on(WelcomeTabPane.OpenGraphRequested)
    def on_open_graph_requested(self, event: WelcomeTabPane.OpenGraphRequested) -> None:
        """Open the graph tab when requested from welcome screen."""
        tabs = self.query_one("#tabs", TabbedContent)

        # If graph tab already exists, focus it
        try:
            tabs.query_one("#graph-tab", TabPane)
            tabs.active = "graph-tab"
            return
        except Exception:
            pass

        tabs.add_pane(GraphTabPane(self.explorer))
        tabs.active = "graph-tab"
        self.sub_title = "Navigation Graph"
```

- [ ] **Step 3: Update _open_entity_tab — stop removing welcome/graph unconditionally**

Replace the "Remove welcome/graph tabs if present" block in `_open_entity_tab`:

```python
        # Remove welcome tab if present (graph stays if user opened it)
        try:
            tabs.query_one("#welcome-tab", TabPane)
            tabs.remove_pane("welcome-tab")
        except Exception:
            pass
```

- [ ] **Step 4: Update _open_picklist_tab — same change**

Replace the "Remove welcome/graph tabs if present" block in `_open_picklist_tab`:

```python
        # Remove welcome tab if present (graph stays if user opened it)
        try:
            tabs.query_one("#welcome-tab", TabPane)
            tabs.remove_pane("welcome-tab")
        except Exception:
            pass
```

- [ ] **Step 5: Update action_close_tab — welcome-only auto-reopen (no graph)**

Replace the "If no tabs left" block in `action_close_tab`:

```python
        # If no tabs left, show welcome
        remaining = tabs.query(TabPane)
        if not remaining:
            tabs.add_pane(WelcomeTabPane(self.explorer, metadata_path=self.metadata_path))
            tabs.active = "welcome-tab"
            self.sub_title = f"{self.explorer.entity_count} entities"
```

- [ ] **Step 6: Run import check**

```bash
cd D:/Developer/py-csdl-explorer && python -c "from csdl_explore.app import CSDLExplorerApp; print('OK')"
```

Expected: OK

- [ ] **Step 7: Commit**

```bash
git add src/csdl_explore/app.py
git commit -m "feat: graph tab on demand, welcome tab auto-reopens when all tabs closed"
```

---

### Task 12: Update REPL palette reference

**Files:**
- Modify: `src/csdl_explore/repl.py`

- [ ] **Step 1: Check if repl.py references the old palette name**

Search for `"terminal-vercel-green"` in repl.py. If found, replace with `"terminal-green"`. Also check for `DEFAULT_PALETTE` usage — if it uses `DEFAULT_PALETTE` from themes.py, no change needed.

```bash
cd D:/Developer/py-csdl-explorer && grep -n "terminal-vercel-green\|DEFAULT_PALETTE\|PALETTES" src/csdl_explore/repl.py
```

Update any hardcoded `"terminal-vercel-green"` strings to `"terminal-green"`.

- [ ] **Step 2: Commit if changes were needed**

```bash
git add src/csdl_explore/repl.py
git commit -m "refactor: use terminal-green palette name in REPL"
```

---

### Task 13: Run Existing Tests

**Files:** None (validation only)

- [ ] **Step 1: Run full test suite**

```bash
cd D:/Developer/py-csdl-explorer && python -m pytest tests/ -v
```

Expected: All existing tests pass. The theme rename should not break tests unless they reference theme names directly.

- [ ] **Step 2: Fix any test failures**

If any test references `"terminal-vercel-green"` or `VERCEL_THEME`, update to `"terminal-green"` / `TERMINAL_THEME`.

- [ ] **Step 3: Commit fixes if needed**

```bash
git add tests/
git commit -m "test: update theme references for terminal-green rename"
```

---

### Task 14: Manual Smoke Test

**Files:** None (validation only)

- [ ] **Step 1: Launch the TUI and verify**

```bash
cd D:/Developer/py-csdl-explorer && csdl-explore metadata.xml --tui
```

Check:
1. Colors are matrix green (#00FF41) on true black — no washed-out grays
2. Welcome tab shows filename and file size at top
3. Picklist count is amber colored
4. "Open Graph View" button is present and works
5. Closing all tabs reopens Welcome tab
6. Graph tab opens from the button, not on startup
7. Ctrl+T cycles themes (terminal-green → classic → terminal-green)
8. Entity tree uses new green/amber colors
9. Details tab panels use new colors
10. Picklist tabs use amber accent

- [ ] **Step 2: Launch REPL and verify colors**

```bash
cd D:/Developer/py-csdl-explorer && csdl-explore metadata.xml
```

Check that REPL colors match the new palette (green entities, amber keys/picklists).
