# Visual Refresh: Terminal Color Palette + Welcome Tab Rework

**Date:** 2026-03-31
**Scope:** Color palette overhaul, Welcome tab improvements, theme alignment

## Problem

The app's visual design is serviceable but forgettable. The green-on-gray Vercel theme lacks personality, the accent color doesn't pull its weight, and the Welcome tab doesn't orient the user — it shows stats but not what file you're exploring, and once dismissed it's gone forever. The Graph tab sits as a default tab that users may close without understanding.

## Changes

### 1. Color Palette: Terminal Green + Amber Accent

Replace the Vercel-inspired palette with a pure terminal aesthetic.

| Role | Old | New | Notes |
|------|-----|-----|-------|
| Primary | `#00dc82` | `#00FF41` | Matrix green |
| Accent | `#00dc82` | `#FFB800` | Amber — used for picklists, warnings |
| Background | `#0a0a0a` | `#000000` | True black |
| Surface | `#171717` | `#0a0a0a` | Near-black |
| Panel | `#1a1a1a` | `#111111` | Slightly lighter |
| Foreground | `#e1e1e1` | `#cccccc` | Softer white |
| Secondary | `#333333` | `#222222` | Darker gray |
| Warning | `#f5a623` | `#FFB800` | Matches accent |
| Error | `#ee0000` | `#ff3333` | Slightly brighter red |
| Success | `#00dc82` | `#00FF41` | Matches primary |

**Semantic color mapping:**
- Green (`#00FF41`): Entities, properties, keys, navigation — the "data" color
- Amber (`#FFB800`): Picklists, warnings, counts, accents — the "metadata" color

### 2. Welcome Tab Rework

#### 2a. File Info Header

Display the loaded metadata filename and file size at the top of the Welcome tab.

- Format: `Exploring metadata_sf.xml · 2.3 MB`
- The metadata file path is already available in `CSDLExplorerApp` from CLI args
- Pass the path through to `WelcomeTabPane` as a constructor parameter
- Use `os.path.getsize()` for the file size, format human-readable (KB/MB)

#### 2b. Picklist Stats in Amber

The existing stats display (entities, properties, picklists, custom fields) stays, but the picklist count uses the amber accent color instead of green. This reinforces the two-tone semantic mapping.

#### 2c. "Open Graph View" Button

Add a clickable button below the stats row that opens the Graph tab on demand.

- Button text: "Open Graph View"
- On click: post a message that the app handles to add the Graph tab (same logic that currently runs in `compose()`)
- Style: bordered button in primary green

#### 2d. Remove Graph as Default Tab

Currently `app.py` `compose()` adds both Welcome and Graph tabs on startup. Remove the Graph tab from the default set — it only opens via the Welcome tab button.

#### 2e. Welcome Tab Auto-Reopen

When the last non-Welcome tab is closed, automatically re-add the Welcome tab.

- Hook into the tab removal handler in `app.py`
- After removing a tab, check if `TabbedContent` has zero remaining tabs
- If empty, re-add `WelcomeTabPane` with the current metadata path

### 3. Theme File Alignment

#### 3a. Update `themes.py`

- Rename `VERCEL_THEME` to `TERMINAL_THEME` (update `theme_name` in the Theme object, the `ALL_THEMES` list, and the default theme reference in `app.py`)
- Apply new color values from section 1
- Update the corresponding Rich palette dict with matching colors
- Keep the Classic theme unchanged

#### 3b. Update Hardcoded Markup Colors

Several widgets hardcode hex colors from the old palette in Rich markup strings (e.g., entity tree labels using `#00dc82`). Update these to the new values:

- `entity_tree.py`: Entity branch labels → `#00FF41`, picklist labels → `#FFB800`
- `welcome_tab.py`: Stats markup colors
- `details_tab.py`: Panel/tree colors if hardcoded
- `picklist_overview_tab.py`: Picklist panel colors → `#FFB800`
- Any other widget using old hex colors in Rich markup

## Files Modified

- `src/csdl_explore/themes.py` — new palette values, rename theme
- `src/csdl_explore/app.py` — remove default Graph tab, pass metadata path to Welcome, auto-reopen Welcome
- `src/csdl_explore/widgets/welcome_tab.py` — file info header, graph button, amber picklist stat
- `src/csdl_explore/widgets/entity_tree.py` — update hardcoded markup colors
- `src/csdl_explore/widgets/details_tab.py` — update hardcoded markup colors
- `src/csdl_explore/widgets/picklist_overview_tab.py` — update hardcoded markup colors
- Any other widget files with hardcoded old hex values

## Out of Scope

- Sidebar layout changes
- Entity/Properties/Query tab redesign
- New widgets or screens
- Auth modal changes
- REPL layout changes (only palette dict update)
