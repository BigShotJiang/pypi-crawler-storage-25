# CLI Improvements for Agent/Programmatic Use — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add 7 CLI features (`--format`, `--filter`, `--wide`, SAP error translation, `batch-picklists`, `--json-only`, exit codes) to make csdl-explore agent-friendly and more usable for scripting.

**Architecture:** Introduce an `OutputConfig` dataclass that captures output preferences (format, wide, filter_pattern, json_only). Parse new global flags in `main()`, thread `OutputConfig` to `run_command`. Add serialization functions to `formatters.py` for JSON/CSV output. Add `SAPError` with error code translation to `sap_client.py`. New `batch-picklists` command reuses existing picklist infrastructure.

**Tech Stack:** Python 3.10+, `rich`, `httpx`, `fnmatch` (stdlib), `csv` (stdlib), `io` (stdlib)

---

## Task 1: Exit Code Constants

**Files:**
- Create: `src/csdl_explore/exit_codes.py`
- Test: `tests/test_exit_codes.py`

**Step 1: Create exit_codes module**

```python
# src/csdl_explore/exit_codes.py
"""CLI exit code constants."""

OK = 0
ERROR = 1
INVALID_INPUT = 2
NETWORK_ERROR = 3
NOT_FOUND = 4
```

**Step 2: Write test**

```python
# tests/test_exit_codes.py
from csdl_explore.exit_codes import OK, ERROR, INVALID_INPUT, NETWORK_ERROR, NOT_FOUND

def test_exit_codes_are_distinct():
    codes = [OK, ERROR, INVALID_INPUT, NETWORK_ERROR, NOT_FOUND]
    assert len(set(codes)) == 5

def test_exit_codes_values():
    assert OK == 0
    assert ERROR == 1
    assert INVALID_INPUT == 2
    assert NETWORK_ERROR == 3
    assert NOT_FOUND == 4
```

**Step 3: Run test**

Run: `pytest tests/test_exit_codes.py -v`
Expected: PASS

**Step 4: Commit**

```bash
git add src/csdl_explore/exit_codes.py tests/test_exit_codes.py
git commit -m "feat: add exit code constants module"
```

---

## Task 2: OutputConfig Dataclass

**Files:**
- Modify: `src/csdl_explore/cli.py` (add dataclass, parse new flags)

**Step 1: Add OutputConfig and parse new global flags**

Add at the top of `cli.py`, after imports:

```python
from dataclasses import dataclass

@dataclass
class OutputConfig:
    """Output preferences parsed from CLI flags."""
    format: str = "table"          # table, json, json-compact, csv
    wide: bool = False             # --wide: no column truncation
    filter_pattern: str = ""       # --filter: fnmatch pattern for property names
    json_only: bool = False        # --json-only: suppress banner, force json format
```

In `main()`, add flag parsing for `--format`, `--wide`, `--filter`, `--json-only` in the `while i < len(args)` loop. Add these cases before the `elif arg.startswith('--'):` catch-all:

```python
elif arg == '--format':
    if i + 1 >= len(args):
        console.print("[red]Error: --format requires a value (table, json, json-compact, csv)[/]")
        sys.exit(2)
    output_config.format = args[i + 1]
    i += 2

elif arg == '--wide':
    output_config.wide = True
    i += 1

elif arg == '--filter':
    if i + 1 >= len(args):
        console.print("[red]Error: --filter requires a glob pattern[/]")
        sys.exit(2)
    output_config.filter_pattern = args[i + 1]
    i += 2

elif arg == '--json-only':
    output_config.json_only = True
    output_config.format = "json"
    i += 1
```

Initialize `output_config = OutputConfig()` at the top of `main()` alongside the other variables.

Validate `output_config.format` after parsing:

```python
if output_config.format not in ("table", "json", "json-compact", "csv"):
    console.print(f"[red]Error: Invalid format '{output_config.format}'. Use: table, json, json-compact, csv[/]")
    sys.exit(2)
```

**Step 2: Thread OutputConfig through call chain**

Pass `output_config` to `run_file_mode()`:
- Add `output_config: OutputConfig` parameter to `run_file_mode()` signature
- When `json_only` is True, suppress the "Loaded N entities" banner
- Pass `output_config` to `run_command()` and `run_query_command()`

Add `output_config: OutputConfig` parameter to `run_command()` and `run_query_command()` signatures. Don't use them yet — just thread them through.

**Step 3: Update all sys.exit() calls to use exit code constants**

Import `from .exit_codes import OK, ERROR, INVALID_INPUT, NETWORK_ERROR, NOT_FOUND`

Replace throughout `cli.py`:
- `sys.exit(0)` → `sys.exit(OK)`
- `sys.exit(1)` for input errors (missing args, invalid format) → `sys.exit(INVALID_INPUT)`
- `sys.exit(1)` for not found (entity not found) → `sys.exit(NOT_FOUND)`
- `sys.exit(1)` for general errors → `sys.exit(ERROR)`
- `sys.exit(1)` for network errors (query/picklist fetch failures) → `sys.exit(NETWORK_ERROR)`

**Step 4: Update HELP_TEXT**

Add the new options to the `HELP_TEXT` string under the `[bold]Options:[/]` section:

```
    --format <fmt>     Output format: table (default), json, json-compact, csv
    --wide             Show full column widths (no truncation)
    --filter <pattern> Filter properties by name pattern (e.g. "custom*")
    --json-only        JSON output only (no banner, for agents/scripts)
```

**Step 5: Run existing tests to verify nothing breaks**

Run: `pytest -v`
Expected: All existing tests PASS

**Step 6: Commit**

```bash
git add src/csdl_explore/cli.py
git commit -m "feat: add OutputConfig, new CLI flags, and exit codes"
```

---

## Task 3: Serialization Functions in formatters.py

**Files:**
- Modify: `src/csdl_explore/formatters.py`
- Modify: `tests/test_formatters.py`

**Step 1: Write tests for serialization functions**

Add to `tests/test_formatters.py`:

```python
from csdl_explore.formatters import entity_to_dict, search_results_to_dicts, properties_to_csv
from csdl_explore.parser import Property, EntityType

def _make_entity():
    """Create a test entity."""
    props = {
        "userId": Property(name="userId", type="Edm.String", label="User ID"),
        "customString1": Property(
            name="customString1", type="Edm.String", label="Custom 1",
            picklist="ecJobCode", creatable=True, updatable=True, max_length="256",
        ),
    }
    return EntityType(name="EmpJob", keys=["userId"], properties=props, navigation={})

def test_entity_to_dict():
    entity = _make_entity()
    result = entity_to_dict(entity)
    assert result["entity"] == "EmpJob"
    assert result["keys"] == ["userId"]
    assert len(result["properties"]) == 2
    prop = next(p for p in result["properties"] if p["name"] == "customString1")
    assert prop["type"] == "Edm.String"
    assert prop["label"] == "Custom 1"
    assert prop["picklist"] == "ecJobCode"
    assert prop["creatable"] is True

def test_entity_to_dict_with_filter():
    entity = _make_entity()
    result = entity_to_dict(entity, filter_pattern="custom*")
    assert len(result["properties"]) == 1
    assert result["properties"][0]["name"] == "customString1"

def test_search_results_to_dicts():
    from csdl_explore.explorer import SearchResult
    results = [
        SearchResult(type="property", entity="EmpJob", match="userId", prop_type="Edm.String"),
    ]
    dicts = search_results_to_dicts(results)
    assert len(dicts) == 1
    assert dicts[0]["type"] == "property"
    assert dicts[0]["entity"] == "EmpJob"

def test_properties_to_csv():
    entity = _make_entity()
    csv_str = properties_to_csv(entity)
    assert "userId" in csv_str
    assert "customString1" in csv_str
    # Should have header row
    lines = csv_str.strip().split("\n")
    assert lines[0].startswith("name,")
    assert len(lines) == 3  # header + 2 properties

def test_properties_to_csv_with_filter():
    entity = _make_entity()
    csv_str = properties_to_csv(entity, filter_pattern="user*")
    lines = csv_str.strip().split("\n")
    assert len(lines) == 2  # header + 1 property
```

**Step 2: Run tests to verify they fail**

Run: `pytest tests/test_formatters.py -v -k "entity_to_dict or search_results or properties_to_csv"`
Expected: FAIL (functions don't exist yet)

**Step 3: Implement serialization functions**

Add to `src/csdl_explore/formatters.py`:

```python
import csv
import io
from fnmatch import fnmatch

def entity_to_dict(
    entity: EntityType,
    filter_pattern: str = "",
) -> dict:
    """Convert entity to a plain dict for JSON serialization.

    Args:
        entity: The entity to convert.
        filter_pattern: Optional fnmatch glob to filter property names.

    Returns:
        Dict with keys: entity, keys, properties (list of property dicts),
        navigation (list of nav dicts).
    """
    props = sorted(entity.properties.values(), key=lambda p: p.name)
    if filter_pattern:
        props = [p for p in props if fnmatch(p.name.lower(), filter_pattern.lower())]

    return {
        "entity": entity.name,
        "keys": entity.keys,
        "base_type": entity.base_type or None,
        "properties": [
            {
                "name": p.name,
                "type": p.type,
                "max_length": p.max_length or None,
                "label": p.label or None,
                "picklist": p.picklist or None,
                "nullable": p.nullable,
                "required": p.required,
                "creatable": p.creatable,
                "updatable": p.updatable,
                "upsertable": p.upsertable,
                "visible": p.visible,
                "filterable": p.filterable,
                "sortable": p.sortable,
            }
            for p in props
        ],
        "navigation": [
            {"name": n.name, "target_entity": n.target_entity}
            for n in sorted(entity.navigation.values(), key=lambda n: n.name)
        ],
    }


def search_results_to_dicts(results: list) -> list[dict]:
    """Convert SearchResult list to plain dicts for JSON serialization.

    Args:
        results: List of SearchResult dataclass instances.

    Returns:
        List of dicts with keys: type, entity, match, property, prop_type, label,
        navigation, picklist.
    """
    return [
        {
            "type": r.type,
            "entity": r.entity,
            "match": r.match,
            "property": r.property,
            "prop_type": r.prop_type,
            "label": r.label,
            "navigation": r.navigation,
            "picklist": r.picklist,
        }
        for r in results
    ]


def properties_to_csv(
    entity: EntityType,
    filter_pattern: str = "",
) -> str:
    """Convert entity properties to CSV string.

    Args:
        entity: The entity whose properties to export.
        filter_pattern: Optional fnmatch glob to filter property names.

    Returns:
        CSV string with header row and one row per property.
    """
    props = sorted(entity.properties.values(), key=lambda p: p.name)
    if filter_pattern:
        props = [p for p in props if fnmatch(p.name.lower(), filter_pattern.lower())]

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "name", "type", "max_length", "label", "picklist",
        "required", "creatable", "updatable", "upsertable",
        "visible", "filterable", "sortable",
    ])
    for p in props:
        writer.writerow([
            p.name, p.type, p.max_length, p.label, p.picklist,
            p.required, p.creatable, p.updatable, p.upsertable,
            p.visible, p.filterable, p.sortable,
        ])
    return output.getvalue()
```

**Step 4: Run tests**

Run: `pytest tests/test_formatters.py -v -k "entity_to_dict or search_results or properties_to_csv"`
Expected: PASS

**Step 5: Commit**

```bash
git add src/csdl_explore/formatters.py tests/test_formatters.py
git commit -m "feat: add entity_to_dict, search_results_to_dicts, properties_to_csv serializers"
```

---

## Task 4: SAP Error Translation

**Files:**
- Modify: `src/csdl_explore/sap_client.py`
- Test: `tests/test_sap_errors.py`

**Step 1: Write test**

```python
# tests/test_sap_errors.py
from csdl_explore.sap_client import SAPError, parse_sap_error

def test_parse_sap_error_property_not_found():
    body = '{"error":{"code":"COE_PROPERTY_NOT_FOUND","message":{"value":"[COE0021]Invalid property names: PicklistOption/value"}}}'
    err = parse_sap_error(400, "https://example.com/odata/v2/EmpJob", body)
    assert isinstance(err, SAPError)
    assert err.code == "COE_PROPERTY_NOT_FOUND"
    assert "Invalid property" in err.message
    assert len(err.suggestions) > 0
    assert any("property name" in s.lower() or "spelling" in s.lower() for s in err.suggestions)

def test_parse_sap_error_unknown_code():
    body = '{"error":{"code":"UNKNOWN_CODE","message":{"value":"Something broke"}}}'
    err = parse_sap_error(500, "https://example.com/odata/v2/EmpJob", body)
    assert err.code == "UNKNOWN_CODE"
    assert "Something broke" in err.message

def test_parse_sap_error_invalid_json():
    err = parse_sap_error(500, "https://example.com", "not json at all")
    assert err.code == "HTTP_500"
    assert "not json at all" in err.message

def test_sap_error_str():
    err = SAPError(
        status=400,
        code="COE_PROPERTY_NOT_FOUND",
        message="Invalid property",
        url="https://example.com",
        suggestions=["Check spelling"],
    )
    text = str(err)
    assert "400" in text
    assert "Invalid property" in text
    assert "Check spelling" in text
```

**Step 2: Run test to verify failure**

Run: `pytest tests/test_sap_errors.py -v`
Expected: FAIL (SAPError and parse_sap_error don't exist)

**Step 3: Implement SAPError and parse_sap_error**

Add to `src/csdl_explore/sap_client.py` after the imports:

```python
import json as _json

@dataclass
class SAPError(Exception):
    """Structured SAP OData API error with actionable suggestions.

    Args:
        status: HTTP status code.
        code: SAP error code (e.g. ``"COE_PROPERTY_NOT_FOUND"``).
        message: Error message from SAP.
        url: The request URL.
        suggestions: Actionable hints for the user.
    """
    status: int
    code: str
    message: str
    url: str = ""
    suggestions: list[str] = field(default_factory=list)

    def __str__(self) -> str:
        parts = [f"HTTP {self.status}: {self.message}"]
        if self.code:
            parts[0] = f"HTTP {self.status} [{self.code}]: {self.message}"
        if self.suggestions:
            parts.append("\nSuggestions:")
            for s in self.suggestions:
                parts.append(f"  - {s}")
        return "\n".join(parts)


# Known SAP error codes → suggestion templates
_SAP_ERROR_HINTS: dict[str, list[str]] = {
    "COE_PROPERTY_NOT_FOUND": [
        "Check the property name spelling",
        "Run 'entity <name>' to see available properties",
        "Run --refresh to reload metadata if the schema changed",
    ],
    "COE0021": [
        "Check the property name spelling",
        "The property may not exist on this entity",
    ],
    "INVALID_ENTITY_SET": [
        "Check the entity name spelling",
        "Run 'entities' to list all available entity types",
    ],
}


def parse_sap_error(status: int, url: str, body: str) -> SAPError:
    """Parse a SAP OData error response into a structured SAPError.

    Args:
        status: HTTP status code.
        url: The request URL.
        body: Raw response body text.

    Returns:
        SAPError with parsed code, message, and suggestions.
    """
    try:
        data = _json.loads(body)
        error = data.get("error", {})
        code = error.get("code", f"HTTP_{status}")
        message = error.get("message", {}).get("value", body[:200])
    except (_json.JSONDecodeError, AttributeError):
        return SAPError(
            status=status,
            code=f"HTTP_{status}",
            message=body[:200] if body else f"HTTP {status} error",
            url=url,
            suggestions=["Check the URL and authentication settings"],
        )

    suggestions = []
    # Match against known codes (check both full code and embedded codes like COE0021)
    for known_code, hints in _SAP_ERROR_HINTS.items():
        if known_code in code or known_code in message:
            suggestions.extend(hints)
            break

    if not suggestions:
        suggestions = ["Check the URL and query parameters", "Verify authentication is configured"]

    return SAPError(
        status=status, code=code, message=message, url=url, suggestions=suggestions,
    )
```

**Step 4: Update query_entity and get_picklist_values to raise SAPError instead of RuntimeError**

In `query_entity()` (line ~259-266), replace:
```python
if resp.status_code >= 400:
    try:
        body = raw_text[:500]
    except Exception:
        body = ""
    raise RuntimeError(
        f"HTTP {resp.status_code} from {full_url}\n{body}"
    )
```

With:
```python
if resp.status_code >= 400:
    raise parse_sap_error(resp.status_code, full_url, raw_text[:1000])
```

Same change in `get_picklist_values()` (line ~299-306):
```python
if resp.status_code >= 400:
    raise parse_sap_error(resp.status_code, str(resp.url), resp.text[:1000])
```

**Step 5: Update cli.py error handling for SAPError**

In `run_query_command()` and `run_picklist_command()`, catch `SAPError` separately:

```python
from .sap_client import SAPConnection, SAPClient, SAPError, load_env_file

# In the try/except block:
except SAPError as e:
    console.print(f"[red]{e}[/]", highlight=False)
    sys.exit(NETWORK_ERROR)
except Exception as e:
    console.print(f"[red]Error: {e}[/]")
    sys.exit(NETWORK_ERROR)
```

**Step 6: Run tests**

Run: `pytest tests/test_sap_errors.py -v`
Expected: PASS

**Step 7: Commit**

```bash
git add src/csdl_explore/sap_client.py tests/test_sap_errors.py src/csdl_explore/cli.py
git commit -m "feat: add SAPError with error code translation and suggestions"
```

---

## Task 5: Wire Output Formats Into run_command

**Files:**
- Modify: `src/csdl_explore/cli.py`
- Modify: `src/csdl_explore/repl.py`

**Step 1: Add --wide and --filter support to repl.print_entity_details**

In `src/csdl_explore/repl.py`, modify `print_entity_details` signature and body:

```python
def print_entity_details(entity: EntityType, *, wide: bool = False, filter_pattern: str = ""):
    """Print detailed entity information.

    Args:
        entity: The entity to display.
        wide: If True, disable column truncation.
        filter_pattern: fnmatch glob to filter properties by name.
    """
```

Add filtering logic after `for prop in sort_properties(...)`:
```python
from fnmatch import fnmatch

sorted_props = sort_properties(entity.properties, entity.keys)
if filter_pattern:
    sorted_props = [p for p in sorted_props if fnmatch(p.name.lower(), filter_pattern.lower())]
```

For `wide` mode, add `no_wrap=True` and `max_width=None` to table columns:
```python
if wide:
    table.add_column("Name", style=_c("property"), no_wrap=True)
    table.add_column("Type", no_wrap=True)
    table.add_column("Len", style="dim", justify="right")
    table.add_column("Flags", style="dim", no_wrap=True)
    table.add_column("Picklist", style=_c("picklist"), no_wrap=True)
    table.add_column("Info", style="dim", no_wrap=True)
else:
    # existing column definitions
```

**Step 2: Wire format routing in run_command**

In `cli.py` `run_command()`, add format-aware output for the `entity` command. Before the existing `repl.print_entity_details(entity)` call:

```python
elif command in ('entity', 'e'):
    if not args:
        console.print("[yellow]Usage: entity <name>[/]")
        sys.exit(INVALID_INPUT)
    entity = explorer.get_entity(args[0])
    if not entity:
        suggestions = [r.entity for r in explorer.search(args[0]) if r.type == 'entity'][:5]
        repl.print_not_found(args[0], suggestions)
        sys.exit(NOT_FOUND)

    if output_config.format == "table":
        repl.print_entity_details(
            entity, wide=output_config.wide, filter_pattern=output_config.filter_pattern,
        )
    elif output_config.format in ("json", "json-compact"):
        from .formatters import entity_to_dict
        data = entity_to_dict(entity, filter_pattern=output_config.filter_pattern)
        indent = 2 if output_config.format == "json" else None
        print(json.dumps(data, indent=indent, ensure_ascii=False))
    elif output_config.format == "csv":
        from .formatters import properties_to_csv
        print(properties_to_csv(entity, filter_pattern=output_config.filter_pattern), end="")
```

Apply similar format routing for `search` command:

```python
elif command in ('search', 's'):
    if not args:
        console.print("[yellow]Usage: search <term>[/]")
        sys.exit(INVALID_INPUT)
    results = explorer.search(' '.join(args))
    if output_config.format == "table":
        repl.print_search_results(results)
    else:
        from .formatters import search_results_to_dicts
        data = search_results_to_dicts(results)
        indent = 2 if output_config.format != "json-compact" else None
        print(json.dumps(data, indent=indent, ensure_ascii=False))
```

For `entities` command:
```python
if command == 'entities':
    entities_list = explorer.list_entities()
    if output_config.format == "table":
        repl.print_entities(entities_list)
    else:
        indent = 2 if output_config.format != "json-compact" else None
        print(json.dumps(entities_list, indent=indent, ensure_ascii=False))
```

For `custom` command:
```python
elif command in ('custom', 'c'):
    if not args:
        console.print("[yellow]Usage: custom <entity>[/]")
        sys.exit(INVALID_INPUT)
    fields = explorer.get_custom_fields(args[0])
    if output_config.format == "table":
        repl.print_custom_fields(fields, args[0])
    else:
        data = [
            {"name": p.name, "type": p.type, "label": p.label, "picklist": p.picklist,
             "max_length": p.max_length, "creatable": p.creatable, "updatable": p.updatable}
            for p in fields
        ]
        indent = 2 if output_config.format != "json-compact" else None
        print(json.dumps(data, indent=indent, ensure_ascii=False))
```

For `picklists` command (already outputs JSON, just respect format flag):
```python
elif command == 'picklists':
    usage = explorer.get_picklist_usage()
    indent = 2 if output_config.format != "json-compact" else None
    print(json.dumps(usage, indent=indent, ensure_ascii=False))
```

For remaining commands (`nav`, `diff`, `path`, `tree`, `model`, `emp`, `per`), keep table output as default and just output JSON when format is json:
- `nav`: serialize as list of `{"name", "target_entity"}` dicts
- `diff`: serialize EntityComparison fields
- `path`: serialize list of path dicts
- `emp`/`per`: same as `entities`
- `tree`/`model`: table-only (Rich Tree doesn't serialize to JSON meaningfully — skip JSON for these)

**Step 3: Run all tests**

Run: `pytest -v`
Expected: PASS

**Step 4: Commit**

```bash
git add src/csdl_explore/cli.py src/csdl_explore/repl.py
git commit -m "feat: wire --format, --wide, --filter into entity/search/custom commands"
```

---

## Task 6: batch-picklists Command

**Files:**
- Modify: `src/csdl_explore/cli.py`

**Step 1: Add batch-picklists to HELP_TEXT**

Add under Commands:
```
    batch-picklists <entity>  Fetch all picklist values for an entity's fields
```

**Step 2: Implement run_batch_picklists_command**

```python
def run_batch_picklists_command(
    entity_name: str,
    explorer: CSDLExplorer,
    metadata_file: Path | None,
    cli_env: dict[str, str],
    output_config: OutputConfig,
) -> None:
    """Fetch all picklist values referenced by an entity's properties.

    Args:
        entity_name: The entity to scan for picklist references.
        explorer: Initialised CSDL explorer instance.
        metadata_file: Resolved path to the metadata XML file.
        cli_env: Connection overrides from CLI flags.
        output_config: Output configuration.
    """
    from .sap_client import SAPConnection, SAPClient, SAPError, load_env_file

    entity = explorer.get_entity(entity_name)
    if not entity:
        console.print(f"[red]Entity '{entity_name}' not found[/]")
        sys.exit(NOT_FOUND)

    # Collect all picklist references
    picklist_props = {
        p.name: {"picklist_id": p.picklist, "label": p.label or ""}
        for p in entity.properties.values()
        if p.picklist
    }

    if not picklist_props:
        console.print(f"[yellow]No picklist references found in {entity_name}[/]")
        result = {"entity": entity_name, "picklists": {}}
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return

    # Build connection
    env = {}
    if metadata_file:
        env_path = metadata_file.with_suffix('.env')
        if env_path.exists():
            env = load_env_file(env_path)
    env.update(cli_env)

    connection = SAPConnection.from_env_dict(env)
    if not connection.base_url:
        console.print(
            "[red]Error: No base URL configured.[/]\n"
            "[dim]Provide --base-url or create a .env file alongside metadata XML[/]"
        )
        sys.exit(INVALID_INPUT)

    # Fetch each unique picklist
    unique_picklists = {info["picklist_id"] for info in picklist_props.values()}

    async def _fetch_all():
        client = SAPClient(connection)
        try:
            await client.authenticate()
            fetched = {}
            for pl_id in sorted(unique_picklists):
                try:
                    values = await client.get_picklist_values(pl_id)
                    fetched[pl_id] = values
                except Exception as e:
                    fetched[pl_id] = {"error": str(e)}
            return fetched
        finally:
            await client.close()

    if not output_config.json_only:
        console.print(f"[dim]Fetching {len(unique_picklists)} picklists for {entity_name}...[/]",
                      file=sys.stderr)

    try:
        fetched = asyncio.run(_fetch_all())
    except SAPError as e:
        console.print(f"[red]{e}[/]", highlight=False)
        sys.exit(NETWORK_ERROR)
    except Exception as e:
        console.print(f"[red]Error: {e}[/]")
        sys.exit(NETWORK_ERROR)

    # Build result
    result = {"entity": entity_name, "picklists": {}}
    for prop_name, info in picklist_props.items():
        pl_id = info["picklist_id"]
        result["picklists"][prop_name] = {
            "picklist_id": pl_id,
            "label": info["label"],
            "values": fetched.get(pl_id, []),
        }

    indent = 2 if output_config.format != "json-compact" else None
    print(json.dumps(result, indent=indent, ensure_ascii=False))
```

**Step 3: Wire into run_command dispatch**

In `run_command()`, add before the `else` catch-all:

```python
elif command == 'batch-picklists':
    if not args:
        console.print("[yellow]Usage: batch-picklists <entity>[/]")
        sys.exit(INVALID_INPUT)
    run_batch_picklists_command(args[0], explorer, metadata_file, cli_env or {}, output_config)
```

**Step 4: Run tests**

Run: `pytest -v`
Expected: PASS

**Step 5: Commit**

```bash
git add src/csdl_explore/cli.py
git commit -m "feat: add batch-picklists command to fetch all picklist values for an entity"
```

---

## Task 7: Final Integration & Cleanup

**Files:**
- Modify: `src/csdl_explore/cli.py`
- Modify: `README.md`

**Step 1: Ensure --json-only suppresses all non-JSON output**

In `run_file_mode()`, wrap the banner print:

```python
if not output_config.json_only:
    console.print(f"[dim]Loaded {explorer.entity_count} entities from {metadata_file.name}[/]")
```

Also route console error messages to stderr when json_only is set. Add at the top of `run_command`:
```python
if output_config.json_only:
    console = Console(stderr=True)
```

**Step 2: Update README.md with new options and commands**

Add the new options to the Options table and the new `batch-picklists` command to the Commands table. Add examples for `--format`, `--filter`, `--wide`, `--json-only`.

**Step 3: Run full test suite**

Run: `pytest -v`
Expected: All PASS

**Step 4: Commit**

```bash
git add src/csdl_explore/cli.py README.md
git commit -m "feat: finalize CLI improvements — json-only mode, README updates"
```

---

## Summary of Changes

| File | Changes |
|------|---------|
| `src/csdl_explore/exit_codes.py` | New: exit code constants |
| `src/csdl_explore/cli.py` | OutputConfig, new flags parsing, format routing, batch-picklists, exit codes |
| `src/csdl_explore/formatters.py` | New: entity_to_dict, search_results_to_dicts, properties_to_csv |
| `src/csdl_explore/sap_client.py` | New: SAPError, parse_sap_error; updated error handling |
| `src/csdl_explore/repl.py` | print_entity_details gains wide + filter_pattern params |
| `README.md` | Document new CLI options and commands |
| `tests/test_exit_codes.py` | New: exit code tests |
| `tests/test_formatters.py` | New: serialization function tests |
| `tests/test_sap_errors.py` | New: SAP error parsing tests |
