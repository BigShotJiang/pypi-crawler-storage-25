"""Utility classes and functions for momapy.

This module provides general-purpose utilities including bidirectional mappings,
pretty printing for dataclasses, and collection manipulation helpers.
"""

import collections.abc
import dataclasses
import os
import uuid
import types

import colorama
import frozendict

import momapy


class SurjectionDict(dict):
    """A dictionary that maintains an inverse mapping from values to keys.

    A surjection (onto mapping) where each value maps back to one or more keys.
    The inverse is automatically maintained as the dict is modified.

    Note:
        Code adapted from https://stackoverflow.com/a/21894086 by Basj.

    Examples:
        ```python
        d = SurjectionDict({'a': 1, 'b': 1, 'c': 2})
        d.inverse
        d['d'] = 1
        d.inverse
        ```
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._inverse = {}
        for key, value in self.items():
            self._inverse.setdefault(value, []).append(key)

    def __setitem__(self, key, value):
        if key in self:
            self._inverse[self[key]].remove(key)
        super(SurjectionDict, self).__setitem__(key, value)
        self._inverse.setdefault(value, []).append(key)

    def __delitem__(self, key):
        value = self[key]  # throws expected KeyError if key not in self
        super().__delitem__(key)
        # we know key was in self, hence value is expected to be in self.inverse
        self._inverse[value].remove(key)
        if not self._inverse[value]:
            del self._inverse[value]

    @property
    def inverse(self) -> frozendict.frozendict:
        """Get the inverse mapping from values to keys.

        Returns:
            A frozendict mapping each value to a list of keys that map to it.
        """
        return frozendict.frozendict(self._inverse)


class IdentitySurjectionDict(dict):
    """A dictionary with an identity-based inverse mapping.

    Like SurjectionDict, but the inverse uses object identity (id())
    instead of equality.  This allows O(1) lookup of all keys whose
    value is a specific object, even when multiple distinct objects
    compare equal.

    The forward dict uses normal equality for key lookup.  The inverse
    is safe from id() address reuse because the forward dict holds a
    reference to each value, keeping it alive.

    Examples:
        ```python
        d = IdentitySurjectionDict()
        a, b = object(), object()
        d['x'] = a
        d['y'] = a
        d['z'] = b
        d.inverse[id(a)]  # {'x', 'y'}
        d.inverse[id(b)]  # {'z'}
        ```
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._identity_inverse: dict[int, set] = {}
        for key, value in self.items():
            self._identity_inverse.setdefault(id(value), set()).add(key)

    def __setitem__(self, key, value):
        if key in self:
            old_value = self[key]
            old_identity = id(old_value)
            if old_identity in self._identity_inverse:
                self._identity_inverse[old_identity].discard(key)
                if not self._identity_inverse[old_identity]:
                    del self._identity_inverse[old_identity]
        super().__setitem__(key, value)
        self._identity_inverse.setdefault(id(value), set()).add(key)

    def __delitem__(self, key):
        value = self[key]
        value_identity = id(value)
        super().__delitem__(key)
        if value_identity in self._identity_inverse:
            self._identity_inverse[value_identity].discard(key)
            if not self._identity_inverse[value_identity]:
                del self._identity_inverse[value_identity]

    @property
    def inverse(self) -> dict[int, set]:
        """Get the identity-based inverse mapping.

        Returns:
            A dict mapping id(value) to the set of keys that point
            to that value by identity.
        """
        return self._identity_inverse


class IdentityMultiDict:
    """An identity-keyed multidict for n-to-m string -> object mappings.

    Forward: ``dict[str, set[object]]`` — a key may name several values.
    Inverse: ``dict[int, set[str]]`` keyed by ``id(value)``.

    The forward dict holds references to every value, so the
    identity-keyed inverse is safe from ``id()`` address reuse for the
    lifetime of the multidict.

    The class deliberately does **not** subclass ``dict`` so that
    accidental ``d[key] = value`` writes (which would replace the whole
    set with a single object) raise instead of silently corrupting
    state.  Use ``add`` / ``remove`` / ``replace_value`` to mutate.

    Examples:
        ```python
        d = IdentityMultiDict()
        a, b = object(), object()
        d.add('x', a)
        d.add('x', b)
        d.get_all('x')      # frozenset({a, b})
        d.inverse[id(a)]    # frozenset({'x'})
        ```
    """

    def __init__(self):
        self._forward: dict[str, set] = {}
        self._inverse: dict[int, set[str]] = {}

    def add(self, key: str, value: object) -> None:
        """Register ``value`` under ``key``.  Idempotent on identity."""
        bucket = self._forward.setdefault(key, set())
        for existing in bucket:
            if existing is value:
                return
        bucket.add(value)
        self._inverse.setdefault(id(value), set()).add(key)

    def remove(self, key: str, value: object) -> None:
        """Drop ``value`` from ``key``.  Raises ``KeyError`` if absent."""
        bucket = self._forward.get(key)
        if bucket is None:
            raise KeyError(key)
        target = None
        for existing in bucket:
            if existing is value:
                target = existing
                break
        if target is None:
            raise KeyError(key)
        bucket.discard(target)
        if not bucket:
            del self._forward[key]
        keys_for_value = self._inverse.get(id(value))
        if keys_for_value is not None:
            keys_for_value.discard(key)
            if not keys_for_value:
                del self._inverse[id(value)]

    def replace_value(self, old: object, new: object) -> None:
        """Replace ``old`` with ``new`` everywhere it appears (by identity).

        Drives the dedup remap path: every key whose set contains
        ``old`` (compared by identity) drops ``old`` and adds ``new``.
        """
        keys = self._inverse.pop(id(old), None)
        if not keys:
            return
        for key in keys:
            bucket = self._forward.get(key)
            if bucket is None:
                continue
            target = None
            for existing in bucket:
                if existing is old:
                    target = existing
                    break
            if target is not None:
                bucket.discard(target)
            already_present = False
            for existing in bucket:
                if existing is new:
                    already_present = True
                    break
            if not already_present:
                bucket.add(new)
            self._inverse.setdefault(id(new), set()).add(key)

    def get_one(self, key: str, default=None):
        """Return the single value for ``key`` or ``default``.

        Raises:
            ValueError: If ``key`` is registered with more than one value.
        """
        bucket = self._forward.get(key)
        if bucket is None:
            return default
        if len(bucket) != 1:
            raise ValueError(f"key {key!r} has {len(bucket)} values; use get_all")
        return next(iter(bucket))

    def get_all(self, key: str) -> frozenset:
        """Return the frozenset of values registered under ``key``."""
        bucket = self._forward.get(key)
        if bucket is None:
            return frozenset()
        return frozenset(bucket)

    def __contains__(self, key: str) -> bool:
        return key in self._forward

    def __iter__(self):
        return iter(self._forward)

    def __len__(self) -> int:
        return len(self._forward)

    def keys(self):
        return self._forward.keys()

    def items(self):
        """Iterate ``(key, frozenset_of_values)`` pairs."""
        for key, bucket in self._forward.items():
            yield key, frozenset(bucket)

    def items_flat(self):
        """Iterate one ``(key, value)`` pair per value member of each key."""
        for key, bucket in self._forward.items():
            for value in bucket:
                yield key, value

    @property
    def inverse(self) -> dict[int, frozenset[str]]:
        """Identity-keyed inverse: ``id(value) -> frozenset[str]``."""
        return {value_id: frozenset(keys) for value_id, keys in self._inverse.items()}


class FrozenIdentityMultiDict(frozendict.frozendict):
    """An immutable identity-keyed multidict.

    Forward: ``frozendict[str, frozenset[object]]``.  Inverse:
    ``dict[int, frozenset[str]]`` keyed by ``id(value)``.

    Constructed from any mapping ``str -> Iterable[object]``.

    Examples:
        ```python
        a, b = object(), object()
        d = FrozenIdentityMultiDict({'x': [a, b], 'y': [a]})
        d.get_all('x')      # frozenset({a, b})
        d.inverse[id(a)]    # frozenset({'x', 'y'})
        ```
    """

    def __new__(cls, mapping=None):
        frozen_forward: dict[str, frozenset] = {}
        if mapping is not None:
            for key, values in mapping.items():
                frozen_forward[key] = frozenset(values)
        return super().__new__(cls, frozen_forward)

    def __init__(self, mapping=None):
        inverse: dict[int, set[str]] = {}
        for key, bucket in self.items():
            for value in bucket:
                inverse.setdefault(id(value), set()).add(key)
        object.__setattr__(
            self,
            "_identity_inverse",
            {value_id: frozenset(keys) for value_id, keys in inverse.items()},
        )

    def get_one(self, key: str, default=None):
        """Return the single value for ``key`` or ``default``.

        Raises:
            ValueError: If ``key`` has more than one value.
        """
        bucket = self.get(key)
        if bucket is None:
            return default
        if len(bucket) != 1:
            raise ValueError(f"key {key!r} has {len(bucket)} values; use get_all")
        return next(iter(bucket))

    def get_all(self, key: str) -> frozenset:
        """Return the frozenset of values registered under ``key``."""
        bucket = self.get(key)
        if bucket is None:
            return frozenset()
        return bucket

    def items_flat(self):
        """Iterate one ``(key, value)`` pair per value member of each key."""
        for key, bucket in self.items():
            for value in bucket:
                yield key, value

    @property
    def inverse(self) -> dict[int, frozenset[str]]:
        """Identity-keyed inverse: ``id(value) -> frozenset[str]``."""
        return self._identity_inverse


class FrozenSurjectionDict(frozendict.frozendict):
    """An immutable version of SurjectionDict.

    A frozen dictionary that maintains an inverse mapping from values to keys.
    The inverse is computed once at initialization and cannot be modified.

    Examples:
        ```python
        d = FrozenSurjectionDict({'a': 1, 'b': 1, 'c': 2})
        d.inverse
        ```
    """

    def __init__(self, *args, **kwargs):
        inverse = {}
        for key, value in self.items():
            inverse.setdefault(value, []).append(key)
        object.__setattr__(self, "_inverse", frozendict.frozendict(inverse))

    @property
    def inverse(self) -> frozendict.frozendict:
        """Get the inverse mapping from values to keys.

        Returns:
            A frozendict mapping each value to a list of keys that map to it.
        """
        return self._inverse


class FrozenIdentitySurjectionDict(frozendict.frozendict):
    """An immutable version of IdentitySurjectionDict.

    A frozen dictionary whose inverse is keyed by ``id(value)``, not by
    value equality.  The forward dict still uses normal ``frozendict``
    semantics (``==`` on keys); only the value-side index is
    identity-keyed.

    The inverse is safe from ``id()`` address reuse because the forward
    dict holds a reference to each value, keeping it alive for the
    lifetime of the dict.

    Examples:
        ```python
        a, b = object(), object()
        d = FrozenIdentitySurjectionDict({'x': a, 'y': a, 'z': b})
        d.inverse[id(a)]  # {'x', 'y'}
        d.inverse[id(b)]  # {'z'}
        ```
    """

    def __init__(self, *args, **kwargs):
        inverse: dict[int, set] = {}
        for key, value in self.items():
            inverse.setdefault(id(value), set()).add(key)
        object.__setattr__(self, "_identity_inverse", inverse)

    @property
    def inverse(self) -> dict[int, set]:
        """Get the identity-based inverse mapping.

        Returns:
            A dict mapping ``id(value)`` to the set of keys that point
            to that value by identity.
        """
        return self._identity_inverse


def pretty_print(obj, max_depth=0, exclude_cls=None, _depth=0, _indent=0):
    """Pretty print a dataclass or iterable object with colors.

    Recursively prints the structure of dataclasses and iterables with
    type information and color coding for better readability.

    Args:
        obj: The object to print (dataclass, iterable, or other).
        max_depth: Maximum recursion depth. 0 means unlimited. Defaults to 0.
        exclude_cls: List of classes to exclude from recursive printing.
        _depth: Internal parameter for tracking current depth.
        _indent: Internal parameter for tracking current indentation.

    Examples:
        ```python
        from dataclasses import dataclass
        @dataclass
        class Point:
            x: float
            y: float

        p = Point(x=1.0, y=2.0)
        pretty_print(p)
        ```
    """

    def _print_with_indent(s, indent):
        dark = f"{colorama.Style.DIM}│{colorama.Style.RESET_ALL} "
        light = f"{colorama.Fore.WHITE}│{colorama.Style.RESET_ALL} "
        guides = "".join(dark if i % 2 == 0 else light for i in range(indent))
        print(f"{guides}{s}")

    def _get_value_string(attr_value, max_len=30):
        s = str(attr_value)
        if len(s) > max_len:
            s = f"{s[:max_len]}..."
        return s

    if _depth > max_depth:
        return
    if exclude_cls is None:
        exclude_cls = []
    obj_typing = type(obj)
    if issubclass(obj_typing, tuple(exclude_cls)):
        return
    obj_value_string = _get_value_string(obj)
    obj_string = f"{colorama.Fore.GREEN}{obj_typing}{colorama.Fore.RED}: {obj_value_string}{colorama.Style.RESET_ALL}"
    _print_with_indent(obj_string, _indent)
    if dataclasses.is_dataclass(type(obj)):
        for field in dataclasses.fields(obj):
            attr_name = field.name
            if not attr_name.startswith("_"):
                attr_value = getattr(obj, attr_name)
                attr_typing = field.type
                attr_value_string = _get_value_string(attr_value)
                attr_string = f"{colorama.Fore.BLUE}* {attr_name}{colorama.Fore.MAGENTA}: {attr_typing} = {colorama.Fore.RED}{attr_value_string}{colorama.Style.RESET_ALL}"
                _print_with_indent(attr_string, _indent + 1)
                if (
                    not isinstance(attr_value, (str, float, int, bool, types.NoneType))
                    and attr_value
                ):
                    pretty_print(
                        attr_value,
                        max_depth=max_depth,
                        exclude_cls=exclude_cls,
                        _depth=_depth + 1,
                        _indent=_indent + 2,
                    )
    if isinstance(obj, collections.abc.Iterable) and not isinstance(
        obj, (str, bytes, bytearray, momapy.geometry.Point)
    ):
        for i, elem_value in enumerate(obj):
            elem_typing = type(elem_value)
            elem_value_string = _get_value_string(elem_value)
            elem_string = f"{colorama.Fore.BLUE}- {i}{colorama.Fore.MAGENTA}: {elem_typing} = {colorama.Fore.RED}{elem_value_string}{colorama.Style.RESET_ALL}"
            _print_with_indent(elem_string, _indent + 1)
            pretty_print(
                elem_value,
                max_depth=max_depth,
                exclude_cls=exclude_cls,
                _depth=_depth + 1,
                _indent=_indent + 2,
            )


def get_element_from_collection(element, collection):
    """Find and return an element from a collection using equality.

    Args:
        element: The element to search for.
        collection: An iterable collection to search in.

    Returns:
        The existing element from the collection if found, None otherwise.

    Examples:
        ```python
        items = [1, 2, 3]
        get_element_from_collection(2, items)
        get_element_from_collection(4, items) is None
        ```
    """
    for e in collection:
        if e == element:
            return e
    return None


def get_or_return_element_from_collection(element, collection):
    """Get existing element from collection or return the input element.

    Args:
        element: The element to search for.
        collection: An iterable collection to search in.

    Returns:
        The existing element from the collection if found, otherwise
        the input element.

    Examples:
        ```python
        items = [1, 2, 3]
        get_or_return_element_from_collection(2, items)
        get_or_return_element_from_collection(4, items)
        ```
    """
    existing_element = get_element_from_collection(element, collection)
    if existing_element is not None:
        return existing_element
    return element


def add_or_replace_element_in_set(element, set_, func=None, cache=None):
    """Add element to set or replace existing element based on condition.

    If the element doesn't exist in the set, it is added. If it exists
    and a comparison function is provided, the existing element may be
    replaced if the function returns True.

    Args:
        element: The element to add or replace with.
        set_: The set to modify.
        func: Optional comparison function func(new, existing) that returns
            True if the new element should replace the existing one.
        cache: Optional dict mapping elements to themselves. When provided,
            uses O(1) dict lookup instead of O(n) linear scan. The cache
            is kept in sync with the set on add/replace.

    Returns:
        The element that is now in the set (either the existing or new one).

    Examples:
        ```python
        s = {1, 2, 3}
        add_or_replace_element_in_set(4, s)
        4 in s

        # Replace only if new value is greater
        add_or_replace_element_in_set(2, s, lambda new, old: new > old)
        ```
    """
    if cache is not None:
        existing_element = cache.get(element)
    else:
        existing_element = get_element_from_collection(element, set_)
    if existing_element is None:
        set_.add(element)
        if cache is not None:
            cache[element] = element
        return element
    # Replaces existing element by input element if func(element, existing_element) is True
    elif func is not None and func(element, existing_element):
        set_.remove(existing_element)
        set_.add(element)
        if cache is not None:
            del cache[existing_element]
            cache[element] = element
        return element
    return existing_element


def make_uuid4_as_str():
    """Generate a UUID4 as a string.

    Returns:
        A string representation of a random UUID (version 4).

    Examples:
        ```python
        uuid_str = make_uuid4_as_str()
        isinstance(uuid_str, str)
        len(uuid_str)  # Standard UUID string length
        ```
    """
    return str(uuid.uuid4())


def check_parent_dir_exists(file_path: str | os.PathLike) -> None:
    """Raise `FileNotFoundError` if the parent directory of `file_path` is missing.

    Guards against C-backed writers (notably skia's `FILEWStream`) that
    segfault when handed a path whose parent directory does not exist.

    Args:
        file_path: Output file path. The file itself does not need to exist.

    Raises:
        FileNotFoundError: If the parent directory does not exist.
    """
    parent_dir = os.path.dirname(os.path.abspath(os.fspath(file_path)))
    if not os.path.isdir(parent_dir):
        raise FileNotFoundError(f"parent directory does not exist: {parent_dir}")
