"""
glain - Namespace claimed via ShieldFace

This package namespace has been claimed to prevent typosquatting.
Namespace claim for glain
"""
__version__ = "0.0.0"
__author__ = "Solutions Brewer"