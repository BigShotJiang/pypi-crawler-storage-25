from __future__ import annotations

import numpy as np

from rasptorch import vulkan_backend as vk
from rasptorch.checkpoint import load_checkpoint
from rasptorch.gpu_training import GpuMLP


def test_gpu_training_model_save_payload(tmp_path) -> None:
    """Covers the README-documented save format.

    The file should be loadable without requiring torch.
    """

    path = tmp_path / "model.pth"

    m = GpuMLP(in_features=2, hidden=4, out_features=3, seed=0)
    try:
        m.save(str(path))
    finally:
        m.close()

    assert path.exists()
    payload = load_checkpoint(str(path))

    assert isinstance(payload, dict)
    assert "arch" in payload
    assert "state_dict" in payload


def test_torch_bridge_linear_readme_option() -> None:
    """README option: torch_bridge.

    This test is designed to be non-skipping:
    - If torch is installed, it validates correctness via the CPU/fallback bridge path.
    - If torch is not installed, it asserts we raise a clear error message.
    - If Vulkan is unavailable, the bridge still works in fallback mode, but strict `device='gpu'`
      conversion should raise.
    """

    try:
        import torch  # type: ignore
    except ModuleNotFoundError:
        # Importing is fine; using it should fail with a clear message.
        from rasptorch import torch_bridge

        try:
            torch_bridge.convert_torch_model(object(), device="gpu")
        except RuntimeError as e:
            msg = str(e).lower()
            assert "pytorch" in msg or "torch" in msg
        else:
            raise AssertionError("expected RuntimeError when torch is not installed")
        return

    from rasptorch.torch_bridge import convert_torch_model

    torch.manual_seed(0)

    mod = torch.nn.Linear(6, 4, bias=True)
    x = torch.randn(3, 6, dtype=torch.float32)

    ref = mod(x)

    # Use device='cpu' to avoid requiring strict Vulkan init on machines without Vulkan.
    bridged = convert_torch_model(mod, device="cpu")
    out = bridged(x)
    np.testing.assert_allclose(out.detach().cpu().numpy(), ref.detach().cpu().numpy(), rtol=2e-2, atol=2e-2)

    # README also mentions a strict Vulkan-backed path; assert it either works or fails clearly.
    try:
        bridged_gpu = convert_torch_model(mod, device="gpu")
        out2 = bridged_gpu(x)
        np.testing.assert_allclose(out2.detach().cpu().numpy(), ref.detach().cpu().numpy(), rtol=2e-2, atol=2e-2)
    except Exception as e:
        # On non-Vulkan systems, strict init can fail; ensure it's an informative error.
        msg = (str(e) or "").lower()
        reason = (vk.disabled_reason() or "").lower()
        assert ("vulkan" in msg) or ("glslc" in msg) or (reason and reason in msg)


def test_torch_bridge_extended_modules() -> None:
    try:
        import torch  # type: ignore
    except ModuleNotFoundError:
        from rasptorch import torch_bridge

        try:
            torch_bridge.convert_torch_model(object(), device="cpu")
        except RuntimeError as e:
            msg = str(e).lower()
            assert "pytorch" in msg or "torch" in msg
        else:
            raise AssertionError("expected RuntimeError when torch is not installed")
        return

    from rasptorch.torch_bridge import convert_torch_model

    torch.manual_seed(0)
    model = torch.nn.Sequential(
        torch.nn.BatchNorm2d(2),
        torch.nn.MaxPool2d(2),
        torch.nn.AvgPool2d(2),
        torch.nn.Sigmoid(),
        torch.nn.Tanh(),
        torch.nn.GELU(),
        torch.nn.Dropout(p=0.25),
    )
    model.eval()

    x = torch.randn(2, 2, 4, 4, dtype=torch.float32)
    ref = model(x)
    bridged = convert_torch_model(model, device="cpu")
    bridged.eval()
    out = bridged(x)

    np.testing.assert_allclose(out.detach().cpu().numpy(), ref.detach().cpu().numpy(), rtol=3e-2, atol=3e-2)


def test_torch_bridge_layernorm_and_avgpool() -> None:
    try:
        import torch  # type: ignore
    except ModuleNotFoundError:
        from rasptorch import torch_bridge

        try:
            torch_bridge.convert_torch_model(object(), device="cpu")
        except RuntimeError as e:
            msg = str(e).lower()
            assert "pytorch" in msg or "torch" in msg
        else:
            raise AssertionError("expected RuntimeError when torch is not installed")
        return

    from rasptorch.torch_bridge import convert_torch_model

    torch.manual_seed(1)

    ln = torch.nn.LayerNorm(6)
    pool = torch.nn.AvgPool2d(kernel_size=2, stride=2)
    model = torch.nn.Sequential(ln, pool)
    model.eval()

    x = torch.randn(2, 1, 6, 6, dtype=torch.float32)
    ref = model(x)
    bridged = convert_torch_model(model, device="cpu")
    bridged.eval()
    out = bridged(x)

    np.testing.assert_allclose(out.detach().cpu().numpy(), ref.detach().cpu().numpy(), rtol=3e-2, atol=3e-2)
