"""Processing pipeline orchestration for site-level workflows."""

from __future__ import annotations

import contextlib
import os
import time as _time
from collections import defaultdict
from collections.abc import Generator
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

import pint
import xarray as xr
from rich.progress import TaskID

from canvod.readers import MatchedDirs, PairDataDirMatcher
from canvod.readers.gnss_specs.constants import UREG
from canvod.store import GnssResearchSite
from canvod.utils.tools import YYYYDOY
from canvod.virtualiconvname.patterns import BUILTIN_PATTERNS, auto_match_order

try:
    from dask.distributed import as_completed as dask_as_completed

    _HAS_DISTRIBUTED = True
except ImportError:
    _HAS_DISTRIBUTED = False
    dask_as_completed = None  # ty: ignore[invalid-assignment]

from canvodpy.logging import get_logger
from canvodpy.orchestrator.processor import (
    RinexDataProcessor,
    _processing_progress,
    preprocess_with_hermite_aux,
)
from canvodpy.orchestrator.resources import DaskClusterManager, MemoryMonitor


class PipelineOrchestrator:
    """Orchestrate RINEX processing pipeline for all receiver pairs at a site.

    Processes each unique receiver once per day, regardless of how many
    pairs it's involved in.

    Parameters
    ----------
    site : GnssResearchSite
        Research site configuration
    n_max_workers : int | None
        Maximum parallel workers per day. ``None`` means auto-detect
        (Dask/OS picks based on ``os.cpu_count()``).
    dry_run : bool
        If True, only simulate processing without executing
    batch_hours : float
        Hours of data per processing batch (default: 24.0)
    max_memory_gb : float | None
        Soft RAM limit in GB (None = no limit)
    cpu_affinity : list[int] | None
        Pin workers to specific CPU core IDs (None = no restriction)
    nice_priority : int
        Process nice value (0=normal, 19=lowest)
    threads_per_worker : int | None
        Threads per Dask worker process. None defaults to 1.
    scheduler_address : str | None
        Address of an existing Dask scheduler (e.g. ``'tcp://host:8786'``).
        When set a LocalCluster is NOT created — the client connects to the
        remote scheduler instead.  Ignored when parallelization_strategy is
        ``'processpool'``.

    """

    def __init__(
        self,
        site: GnssResearchSite,
        n_max_workers: int | None = None,
        dry_run: bool = False,
        batch_hours: float = 24.0,
        max_memory_gb: float | None = None,
        cpu_affinity: list[int] | None = None,
        nice_priority: int = 0,
        threads_per_worker: int | None = None,
        parallelization_strategy: str = "dask",
        scheduler_address: str | None = None,
    ) -> None:
        self.site = site
        self.n_max_workers = n_max_workers
        self.dry_run = dry_run
        self.batch_hours = batch_hours
        self._batch_duration: pint.Quantity = batch_hours * UREG.hour
        self._max_memory_gb = max_memory_gb
        self._cpu_affinity = cpu_affinity
        self._nice_priority = nice_priority
        self._threads_per_worker = threads_per_worker
        self._memory_monitor = MemoryMonitor(max_memory_gb=max_memory_gb)
        self._logger = get_logger(__name__).bind(site=site.site_name)

        # Store cluster config for lazy creation (avoid startup cost for
        # preview_processing_plan() and dry_run=True).
        if n_max_workers is not None:
            dask_workers: int | None = min(
                n_max_workers, os.cpu_count() or n_max_workers
            )
            memory_limit: str | float = "auto"
            if max_memory_gb is not None and dask_workers > 0:
                memory_limit = max_memory_gb / dask_workers * (1024**3)

            self._logger.info(
                "resource_mode_manual",
                n_workers=dask_workers,
                max_memory_gb=max_memory_gb,
                cpu_affinity=cpu_affinity,
                nice_priority=nice_priority,
                threads_per_worker=threads_per_worker,
            )
        else:
            dask_workers = None
            memory_limit = "auto"

            self._logger.info(
                "resource_mode_auto",
                detected_cores=os.cpu_count(),
                threads_per_worker=threads_per_worker,
            )

        self._cluster_config = {
            "n_workers": dask_workers,
            "memory_limit_per_worker": memory_limit,
            "cpu_affinity": cpu_affinity,
            "nice_priority": nice_priority,
            "threads_per_worker": threads_per_worker,
            "scheduler_address": scheduler_address,
        }
        self._use_processpool = parallelization_strategy == "processpool"
        self._cluster_manager: DaskClusterManager | None = None
        self._cluster_creation_attempted = False

        self.pair_matcher = PairDataDirMatcher(
            base_dir=site.site_config["gnss_site_data_root"],
            receivers=site.receivers,
            analysis_pairs={
                name: cfg.model_dump() if hasattr(cfg, "model_dump") else cfg
                for name, cfg in site.vod_analyses.items()
            },
        )

        self._logger.info(
            "pipeline_initialized",
            site=site.site_name,
            analysis_pairs=len(site.active_vod_analyses),
            n_max_workers=n_max_workers,
            dry_run=dry_run,
            batch_hours=batch_hours,
        )

    @property
    def cluster_manager(self) -> DaskClusterManager | None:
        """Lazily create the Dask cluster on first access."""
        if self._use_processpool:
            return None
        if not self._cluster_creation_attempted:
            self._cluster_creation_attempted = True
            try:
                self._cluster_manager = DaskClusterManager(**self._cluster_config)  # ty: ignore[invalid-argument-type]
            except ImportError:
                self._logger.warning(
                    "dask_distributed_unavailable",
                    message="Falling back to ProcessPoolExecutor",
                )
                self._cluster_manager = None
        return self._cluster_manager

    def close(self) -> None:
        """Shut down the Dask cluster if it was created."""
        if self._cluster_manager is not None:
            self._logger.info("pipeline_orchestrator_closing")
            self._cluster_manager.close()
            self._cluster_manager = None
            self._logger.info("pipeline_orchestrator_closed")

    def __enter__(self) -> PipelineOrchestrator:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    @staticmethod
    def _detect_reader_format(data_dir: Path) -> str:
        """Detect reader format from files in a directory.

        Parameters
        ----------
        data_dir : Path
            Directory containing GNSS data files.

        Returns
        -------
        str
            Detected format name (e.g. ``"rinex3"``, ``"sbf"``).
            Falls back to ``"rinex3"`` if nothing matches.

        """
        # Map source pattern names to reader format names
        _PATTERN_TO_READER = {
            "septentrio_sbf": "sbf",
            "rinex_v2_short": "rinex3",
            "rinex_v3_long": "rinex3",
            "canvod": "rinex3",
        }
        for name in auto_match_order():
            pat = BUILTIN_PATTERNS[name]
            if any(
                f for glob in pat.file_globs for f in data_dir.glob(glob) if f.is_file()
            ):
                return _PATTERN_TO_READER.get(name, "rinex3")
        return "rinex3"

    def _group_by_date_and_receiver(
        self,
    ) -> dict[str, dict[str, tuple[Path, str, Path | None, str]]]:
        """Group receivers by date, expanding references per canopy via scs_from.

        Canopy receivers are deduplicated (processed once with own position).
        Reference receivers are expanded: one entry per canopy in scs_from,
        stored as ``{ref_name}_{canopy_name}`` with position_data_dir pointing
        to the canopy's RINEX directory.

        Returns
        -------
        dict[str, dict[str, tuple[Path, str, Path | None, str]]]
            {date: {store_group_name: (data_dir, receiver_type, position_data_dir, reader_format)}}

        """
        grouped: dict[str, dict[str, tuple[Path, str, Path | None, str]]] = defaultdict(
            dict
        )
        site_config = self.site._site_config

        for pair_dirs in self.pair_matcher:
            date_key = pair_dirs.yyyydoy.to_str()

            # Add canopy receiver if not already present (uses own position)
            if pair_dirs.canopy_receiver not in grouped[date_key]:
                canopy_cfg = site_config.receivers.get(pair_dirs.canopy_receiver)
                canopy_fmt = canopy_cfg.reader_format if canopy_cfg else "auto"
                if canopy_fmt == "auto":
                    canopy_fmt = self._detect_reader_format(pair_dirs.canopy_data_dir)
                grouped[date_key][pair_dirs.canopy_receiver] = (
                    pair_dirs.canopy_data_dir,
                    "canopy",
                    None,
                    canopy_fmt,
                )

            # Expand reference receiver per canopy in scs_from
            ref_name = pair_dirs.reference_receiver
            ref_cfg = site_config.receivers.get(ref_name)
            if ref_cfg and ref_cfg.type == "reference":
                ref_fmt = ref_cfg.reader_format
                if ref_fmt == "auto":
                    ref_fmt = self._detect_reader_format(pair_dirs.reference_data_dir)
                canopy_names = site_config.resolve_scs_from(ref_name)
                for canopy_name in canopy_names:
                    store_group = f"{ref_name}_{canopy_name}"
                    if store_group not in grouped[date_key]:
                        # Get canopy data dir for position computation
                        canopy_cfg = site_config.receivers.get(canopy_name)
                        if canopy_cfg:
                            _yydoy = pair_dirs.yyyydoy.yydoy
                            canopy_position_dir = (
                                (
                                    site_config.get_base_path()
                                    / canopy_cfg.directory
                                    / _yydoy
                                )
                                if _yydoy is not None
                                else None
                            )
                        else:
                            canopy_position_dir = None
                        grouped[date_key][store_group] = (
                            pair_dirs.reference_data_dir,
                            "reference",
                            canopy_position_dir,
                            ref_fmt,
                        )

        return grouped

    def preview_processing_plan(self) -> dict:
        """Preview what would be processed without executing.

        Returns
        -------
        dict
            Summary of dates, receivers, and files to process

        """
        grouped = self._group_by_date_and_receiver()

        plan = {
            "site": self.site.site_name,
            "dates": [],
            "total_receivers": 0,
            "total_files": 0,
        }

        for date_key, receivers in sorted(grouped.items()):
            date_info = {"date": date_key, "receivers": []}

            for receiver_name, (data_dir, receiver_type, _pos_dir, _fmt) in sorted(
                receivers.items()
            ):
                files = list(data_dir.glob("*.2*o"))

                receiver_info = {
                    "name": receiver_name,
                    "type": receiver_type,
                    "files": len(files),
                    "dir": str(data_dir),
                }

                date_info["receivers"].append(receiver_info)
                plan["total_files"] += len(files)

            plan["dates"].append(date_info)
            plan["total_receivers"] += len(receivers)

        return plan

    def print_preview(self) -> None:
        """Print a formatted preview of the processing plan."""
        plan = self.preview_processing_plan()

        print(f"\n{'=' * 70}")
        print(f"PROCESSING PLAN FOR SITE: {plan['site']}")
        print(f"{'=' * 70}")
        print(f"Total unique receivers to process: {plan['total_receivers']}")
        print(f"Total RINEX files: {plan['total_files']}")
        print(f"{'=' * 70}\n")

        for date_info in plan["dates"]:
            print(f"Date: {date_info['date']}")
            for receiver_info in date_info["receivers"]:
                print(
                    f"  {receiver_info['name']} ({receiver_info['type']}): "
                    f"{receiver_info['files']} files"
                )
                print(f"    {receiver_info['dir']}")
            print()

    def _filter_dates(
        self,
        grouped: dict[str, dict[str, tuple[Path, str, Path | None, str]]],
        start_from: str | None,
        end_at: str | None,
    ) -> list[tuple[str, dict[str, tuple[Path, str, Path | None, str]]]]:
        """Filter and sort dates within the requested range.

        Parameters
        ----------
        grouped : dict
            Date-grouped receiver configs from ``_group_by_date_and_receiver()``.
        start_from : str | None
            YYYYDOY string to start from (inclusive).
        end_at : str | None
            YYYYDOY string to end at (inclusive).

        Returns
        -------
        list[tuple[str, dict]]
            Filtered and sorted ``(date_key, receivers)`` pairs.

        """
        filtered = []
        for date_key, receivers in sorted(grouped.items()):
            if start_from and date_key < start_from:
                self._logger.info(
                    "date_skipped_before_range",
                    date=date_key,
                    start_from=start_from,
                )
                continue
            if end_at and date_key > end_at:
                self._logger.info(
                    "date_range_complete",
                    date=date_key,
                    end_at=end_at,
                )
                break
            filtered.append((date_key, receivers))
        return filtered

    def _validate_batch_floor(
        self,
        n_files: int,
    ) -> pint.Quantity:
        """Validate batch_hours is at least the duration of one file.

        If the configured batch duration is smaller than one file's duration,
        clamp up to the file duration with a warning.

        Parameters
        ----------
        n_files : int
            Number of RINEX files per day for a receiver.

        Returns
        -------
        pint.Quantity
            Effective batch duration (in hours), clamped if necessary.

        """
        file_duration: pint.Quantity = (24 * UREG.hour) / n_files
        batch_duration = self._batch_duration

        if batch_duration < file_duration:
            self._logger.warning(
                "batch_duration_clamped",
                requested=str(batch_duration),
                min_file_duration=str(file_duration),
                n_files=n_files,
            )
            batch_duration = file_duration
        else:
            self._logger.info(
                "batch_duration_validated",
                batch_duration=str(batch_duration),
                file_duration=str(file_duration),
                n_files=n_files,
            )

        return batch_duration

    def _process_single_date(
        self,
        date_key: str,
        receivers: dict[str, tuple[Path, str, Path | None, str]],
        keep_vars: list[str] | None,
    ) -> tuple[str, dict[str, xr.Dataset], dict[str, float]] | None:
        """Process all receivers for a single date (one DOY).

        Parameters
        ----------
        date_key : str
            YYYYDOY string.
        receivers : dict
            ``{store_group: (data_dir, receiver_type, position_data_dir, reader_format)}``.
        keep_vars : list[str] | None
            Variables to keep in datasets.

        Returns
        -------
        tuple or None
            ``(date_key, datasets, timings)`` or None if processing failed.

        """
        date_start = _time.monotonic()

        self._logger.info(
            "date_processing_started",
            date=date_key,
            receivers=len(receivers),
            receiver_names=sorted(receivers.keys()),
        )

        receiver_configs = [
            (receiver_name, receiver_type, data_dir, position_data_dir, reader_format)
            for receiver_name, (
                data_dir,
                receiver_type,
                position_data_dir,
                reader_format,
            ) in sorted(receivers.items())
        ]

        first_data_dir = receiver_configs[0][2]
        matched_dirs = MatchedDirs(
            canopy_data_dir=first_data_dir,
            reference_data_dir=first_data_dir,
            yyyydoy=YYYYDOY.from_str(date_key),
        )

        # Use Dask cluster if available; otherwise falls back to PPE inside
        # RinexDataProcessor.
        dask_client = (
            self.cluster_manager.client if self.cluster_manager is not None else None
        )
        t_init_start = _time.perf_counter()
        try:
            processor = RinexDataProcessor(
                matched_data_dirs=matched_dirs,
                site=self.site,
                n_max_workers=self.n_max_workers,
                dask_client=dask_client,
            )
        except RuntimeError as e:
            if "Failed to download" in str(e):
                self._logger.warning(
                    "auxiliary_download_failed",
                    date=date_key,
                    error=str(e),
                    exception=type(e).__name__,
                    elapsed_seconds=round(_time.monotonic() - date_start, 2),
                )
                return None
            raise
        t_init_end = _time.perf_counter()
        self._logger.info(
            "processor_init_complete",
            date=date_key,
            init_seconds=round(t_init_end - t_init_start, 2),
        )

        datasets: dict[str, xr.Dataset] = {}
        timings: dict[str, float] = {}
        t_gen_start = _time.perf_counter()
        try:
            for receiver_name, ds, proc_time in processor.parsed_rinex_data_gen(
                keep_vars=keep_vars, receiver_configs=receiver_configs
            ):
                datasets[receiver_name] = ds
                timings[receiver_name] = proc_time
                self._logger.debug(
                    "receiver_result_collected",
                    date=date_key,
                    receiver=receiver_name,
                    dataset_dims=dict(ds.sizes) if hasattr(ds, "sizes") else {},
                    proc_time_seconds=round(proc_time, 2),
                )
        except (OSError, RuntimeError, ValueError) as e:
            self._logger.error(
                "rinex_processing_failed",
                date=date_key,
                error=str(e),
                exception=type(e).__name__,
                elapsed_seconds=round(_time.monotonic() - date_start, 2),
            )
            return None

        t_gen_end = _time.perf_counter()
        date_elapsed = _time.monotonic() - date_start
        self._logger.info(
            "date_processing_complete",
            date=date_key,
            receivers_processed=len(datasets),
            receiver_names=sorted(datasets.keys()),
            total_seconds=round(date_elapsed, 2),
            init_seconds=round(t_init_end - t_init_start, 2),
            gen_seconds=round(t_gen_end - t_gen_start, 2),
            per_receiver_seconds={k: round(v, 2) for k, v in timings.items()},
        )

        return date_key, datasets, timings

    @staticmethod
    def _build_receiver_configs(
        receivers: dict[str, tuple[Path, str, Path | None, str]],
    ) -> list[tuple[str, str, Path, Path | None, str]]:
        """Build sorted receiver config tuples from the receivers dict.

        Parameters
        ----------
        receivers : dict
            ``{store_group: (data_dir, receiver_type, position_data_dir, reader_format)}``.

        Returns
        -------
        list[tuple[str, str, Path, Path | None, str]]
            ``(receiver_name, receiver_type, data_dir, position_data_dir, reader_format)`` tuples.

        """
        return [
            (name, rtype, ddir, pdir, fmt)
            for name, (ddir, rtype, pdir, fmt) in sorted(receivers.items())
        ]

    def _create_processor_for_date(
        self,
        date_key: str,
        receivers: dict[str, tuple[Path, str, Path | None, str]],
    ) -> RinexDataProcessor:
        """Create a RinexDataProcessor for a single DOY.

        Parameters
        ----------
        date_key : str
            YYYYDOY string.
        receivers : dict
            ``{store_group: (data_dir, receiver_type, position_data_dir, reader_format)}``.

        Returns
        -------
        RinexDataProcessor

        """
        receiver_configs = self._build_receiver_configs(receivers)
        first_data_dir = receiver_configs[0][2]
        matched_dirs = MatchedDirs(
            canopy_data_dir=first_data_dir,
            reference_data_dir=first_data_dir,
            yyyydoy=YYYYDOY.from_str(date_key),
        )
        dask_client = (
            self.cluster_manager.client if self.cluster_manager is not None else None
        )
        return RinexDataProcessor(
            matched_data_dirs=matched_dirs,
            site=self.site,
            n_max_workers=self.n_max_workers,
            dask_client=dask_client,
        )

    def _prepare_single_date(
        self,
        date_key: str,
        receivers: dict[str, tuple[Path, str, Path | None, str]],
        keep_vars: list[str] | None,
    ) -> tuple[RinexDataProcessor, list[tuple], list[tuple[str, list[Path]]]] | None:
        """Prepare one DOY for flat Dask submission (Phase 1 helper).

        Thread-safe: each date downloads different SP3/CLK files,
        aux Zarr paths are date-specific, and position computation reads
        independent RINEX headers.

        Returns
        -------
        tuple or None
            ``(processor, task_descriptors, receiver_file_map)`` or None
            if no RINEX files found.

        Raises
        ------
        RuntimeError
            If auxiliary data download fails.

        """
        processor = self._create_processor_for_date(date_key, receivers)
        receiver_configs = self._build_receiver_configs(receivers)
        task_descriptors, receiver_file_map = processor.prepare_batch_tasks(
            keep_vars, receiver_configs
        )
        if not task_descriptors:
            return None
        return processor, task_descriptors, receiver_file_map

    def _process_multi_day_batches(
        self,
        filtered_dates: list[tuple[str, dict[str, tuple[Path, str, Path | None, str]]]],
        keep_vars: list[str] | None,
    ) -> Generator[tuple[str, dict[str, xr.Dataset], dict[str, float]]]:
        """Process dates in multi-day batches (batch_hours >= 24).

        When ``days_per_batch > 1`` and a Dask cluster is available, RINEX
        files from ALL DOYs in a batch are submitted to Dask as one flat
        pool (Phase 2). Auxiliary data and receiver positions are prepared
        sequentially per DOY first (Phase 1), and Icechunk writes happen
        sequentially afterwards (Phase 3).

        When ``days_per_batch == 1`` or no Dask cluster is available, falls
        back to sequential ``_process_single_date()`` calls.

        Parameters
        ----------
        filtered_dates : list
            Filtered ``(date_key, receivers)`` pairs.
        keep_vars : list[str] | None
            Variables to keep in datasets.

        Yields
        ------
        tuple[str, dict[str, xr.Dataset], dict[str, float]]
            ``(date_key, datasets, timings)`` per DOY.

        """
        days_per_batch = max(1, round(self.batch_hours / 24))
        total_batches = (len(filtered_dates) + days_per_batch - 1) // days_per_batch
        dask_client = (
            self.cluster_manager.client if self.cluster_manager is not None else None
        )
        use_flat_dask = dask_client is not None and _HAS_DISTRIBUTED

        self._logger.info(
            "multi_day_batch_strategy",
            batch_hours=self.batch_hours,
            days_per_batch=days_per_batch,
            total_dates=len(filtered_dates),
            total_batches=total_batches,
            flat_dask=use_flat_dask,
        )

        # Partition dates into batches
        for batch_idx, batch_start in enumerate(
            range(0, len(filtered_dates), days_per_batch)
        ):
            batch = filtered_dates[batch_start : batch_start + days_per_batch]
            batch_date_keys = [dk for dk, _ in batch]
            batch_start_time = _time.monotonic()

            self._logger.info(
                "batch_started",
                batch_index=batch_idx + 1,
                total_batches=total_batches,
                batch_dates=batch_date_keys,
                batch_size=len(batch),
            )

            self._memory_monitor.log_memory_stats(
                context=f"before_batch_{batch_idx + 1}"
            )

            if not use_flat_dask:
                # Fallback: sequential _process_single_date (batch_hours=24
                # or no Dask cluster)
                doys_succeeded = 0
                doys_failed = 0
                for date_key, receivers in batch:
                    result = self._process_single_date(date_key, receivers, keep_vars)
                    if result is not None:
                        doys_succeeded += 1
                        yield result
                    else:
                        doys_failed += 1

                batch_elapsed = _time.monotonic() - batch_start_time
                self._logger.info(
                    "batch_complete",
                    batch_index=batch_idx + 1,
                    total_batches=total_batches,
                    batch_dates=batch_date_keys,
                    doys_succeeded=doys_succeeded,
                    doys_failed=doys_failed,
                    batch_seconds=round(batch_elapsed, 2),
                )
                continue

            # ── Phase 1: Prepare (concurrent across dates) ────────────
            t_phase1_start = _time.monotonic()
            doy_contexts: dict[
                str,
                tuple[RinexDataProcessor, list[tuple[str, list[Path]]]],
            ] = {}
            all_tasks: list[tuple[str, tuple]] = []

            phase1_workers = min(len(batch), 4)
            with ThreadPoolExecutor(max_workers=phase1_workers) as tp:
                futures = {
                    tp.submit(
                        self._prepare_single_date, date_key, receivers, keep_vars
                    ): date_key
                    for date_key, receivers in batch
                }
                for fut in as_completed(futures):
                    date_key = futures[fut]
                    try:
                        result = fut.result()
                    except RuntimeError as e:
                        if "Failed to download" in str(e):
                            self._logger.warning(
                                "auxiliary_download_failed",
                                date=date_key,
                                error=str(e),
                            )
                            continue
                        raise
                    except (OSError, ValueError) as e:
                        self._logger.error(
                            "prepare_batch_failed",
                            date=date_key,
                            error=str(e),
                        )
                        continue

                    if result is None:
                        continue

                    processor, task_descriptors, receiver_file_map = result
                    doy_contexts[date_key] = (processor, receiver_file_map)
                    for task_args in task_descriptors:
                        all_tasks.append((date_key, task_args))

            t_phase1_end = _time.monotonic()
            self._logger.info(
                "phase1_prepare_complete",
                batch_index=batch_idx + 1,
                phase1_seconds=round(t_phase1_end - t_phase1_start, 2),
                doys_prepared=len(doy_contexts),
                total_tasks=len(all_tasks),
            )

            if not all_tasks:
                self._logger.warning(
                    "batch_no_tasks",
                    batch_index=batch_idx + 1,
                    batch_dates=batch_date_keys,
                )
                continue

            # ── Phase 2+3: Pipelined Dask processing + streaming writes ─
            #
            # Submit all tasks to Dask, then write to Icechunk as soon as
            # all tasks for a (date, receiver) group complete. This frees
            # raw results immediately instead of buffering everything.

            # Build expected counts and receiver→files lookup
            expected_counts: dict[tuple[str, str], int] = {}
            receiver_files_lookup: dict[tuple[str, str], list[Path]] = {}
            reader_format_lookup: dict[tuple[str, str], str | None] = {}
            for date_key in doy_contexts:
                _processor, receiver_file_map = doy_contexts[date_key]
                for receiver_name, rinex_files in receiver_file_map:
                    key = (date_key, receiver_name)
                    expected_counts[key] = len(rinex_files)
                    receiver_files_lookup[key] = rinex_files
            # Build reader_format lookup from the original receivers dict
            for date_key, receivers in batch:
                for store_group, (_, _, _, fmt) in receivers.items():
                    reader_format_lookup[(date_key, store_group)] = fmt

            # Submit all tasks
            assert dask_client is not None, "dask_client must be set in Dask path"
            t_submit_start = _time.monotonic()
            future_to_meta: dict = {}
            for date_key, task_args in all_tasks:
                fut = dask_client.submit(
                    preprocess_with_hermite_aux, *task_args, pure=False
                )
                receiver_name = task_args[4]  # 5th element
                future_to_meta[fut] = (date_key, receiver_name)
            t_submit_end = _time.monotonic()
            self._logger.info(
                "phase2_dask_submitted",
                batch_index=batch_idx + 1,
                tasks_submitted=len(future_to_meta),
                submit_seconds=round(t_submit_end - t_submit_start, 4),
            )

            # Streaming collection: write as groups complete
            pending_results: dict[tuple[str, str], list[tuple[Path, xr.Dataset]]] = (
                defaultdict(list)
            )
            pending_aux: dict[tuple[str, str], dict[Path, dict[str, xr.Dataset]]] = (
                defaultdict(dict)
            )
            completed_counts: dict[tuple[str, str], int] = defaultdict(int)
            tasks_succeeded = 0
            tasks_failed = 0

            # Per-date accumulators for final yield
            date_datasets: dict[str, dict[str, xr.Dataset]] = defaultdict(dict)
            date_timings: dict[str, dict[str, float]] = defaultdict(dict)
            groups_written: set[tuple[str, str]] = set()

            # Build file-size lookup for throughput display
            file_sizes_mb: dict[tuple[str, str], float] = {}
            for (dk, rn), files in receiver_files_lookup.items():
                file_sizes_mb[(dk, rn)] = sum(
                    f.stat().st_size / 1_048_576 for f in files if f.exists()
                )

            with _processing_progress() as progress:
                # Overall batch bar
                batch_task = progress.add_task(
                    f"[bold]batch {batch_idx + 1}",
                    total=len(future_to_meta),
                )
                # Per-group sub-bars
                group_tasks: dict[tuple[str, str], TaskID] = {}
                for gk, exp in sorted(expected_counts.items()):
                    dk, rn = gk
                    mb = file_sizes_mb.get(gk, 0)
                    label = f"  {dk} {rn} ({mb:.0f} MB)"
                    group_tasks[gk] = progress.add_task(label, total=exp)

                batch_t0 = _time.monotonic()
                for fut in dask_as_completed(future_to_meta):
                    date_key, receiver_name = future_to_meta[fut]
                    group_key = (date_key, receiver_name)

                    try:
                        fname, ds, aux, _sids = fut.result()
                        pending_results[group_key].append((fname, ds))
                        if aux:
                            pending_aux[group_key][fname] = aux
                        tasks_succeeded += 1
                    except Exception:
                        tasks_failed += 1
                        self._logger.exception(
                            "dask_task_failed",
                            date=date_key,
                            receiver=receiver_name,
                            batch_index=batch_idx + 1,
                        )

                    # Count both successes and failures toward completion
                    completed_counts[group_key] += 1
                    progress.advance(batch_task)
                    progress.advance(group_tasks[group_key])

                    # Update batch description with worker activity
                    done = tasks_succeeded + tasks_failed
                    total_tasks = len(future_to_meta)
                    elapsed = _time.monotonic() - batch_t0
                    rate = done / elapsed if elapsed > 0 else 0
                    active = 0
                    if dask_client is not None:
                        with contextlib.suppress(Exception):
                            active = sum(
                                len(v) for v in dask_client.processing().values()
                            )
                    progress.update(
                        batch_task,
                        description=(
                            f"[bold]batch {batch_idx + 1}  "
                            f"{done}/{total_tasks} files  "
                            f"{rate:.1f}/min  "
                            f"{active} workers"
                        ),
                    )

                    # Mark completed groups
                    if completed_counts[group_key] >= expected_counts.get(group_key, 0):
                        dk, rn = group_key
                        mb = file_sizes_mb.get(group_key, 0)
                        progress.update(
                            group_tasks[group_key],
                            description=(f"  {dk} {rn} ({mb:.0f} MB) [green]done"),
                        )

                    # Check if this group is fully complete
                    if completed_counts[group_key] < expected_counts.get(group_key, 0):
                        continue

                    # ── Group complete: write to Icechunk immediately ──
                    group_results = pending_results.pop(group_key, [])
                    if not group_results:
                        self._logger.warning(
                            "receiver_all_tasks_failed",
                            date=date_key,
                            receiver=receiver_name,
                            batch_index=batch_idx + 1,
                        )
                        continue

                    augmented = sorted(group_results, key=lambda x: x[0].name)
                    processor = doy_contexts[date_key][0]
                    rinex_files = receiver_files_lookup[group_key]
                    group_aux = pending_aux.pop(group_key, None)
                    group_fmt = reader_format_lookup.get(group_key)

                    t_write_start = _time.monotonic()
                    try:
                        processor._append_to_icechunk(
                            augmented,
                            receiver_name,
                            rinex_files,
                            aux_datasets=group_aux or None,
                            reader_format=group_fmt,
                        )
                    except OSError, RuntimeError, ValueError:
                        self._logger.exception(
                            "icechunk_write_failed",
                            date=date_key,
                            receiver=receiver_name,
                        )
                        continue
                    t_write_end = _time.monotonic()

                    # Read back daily dataset
                    date_obj = processor.matched_data_dirs.yyyydoy.date
                    assert date_obj is not None, "yyyydoy.date must not be None"
                    time_range = (
                        datetime.combine(date_obj, datetime.min.time()),
                        datetime.combine(date_obj, datetime.max.time()),
                    )
                    try:
                        daily_ds = self.site.read_receiver_data(
                            receiver_name=receiver_name,
                            time_range=time_range,
                        )
                    except ValueError, OSError, RuntimeError:
                        self._logger.exception(
                            "read_back_failed",
                            date=date_key,
                            receiver=receiver_name,
                        )
                        continue
                    t_read_end = _time.monotonic()

                    self._logger.info(
                        "group_write_complete",
                        date=date_key,
                        receiver=receiver_name,
                        write_seconds=round(t_write_end - t_write_start, 2),
                        read_back_seconds=round(t_read_end - t_write_end, 2),
                        total_seconds=round(t_read_end - t_write_start, 2),
                    )

                    date_datasets[date_key][receiver_name] = daily_ds
                    date_timings[date_key][receiver_name] = t_read_end - t_write_start
                    groups_written.add(group_key)

            self._logger.info(
                "flat_dask_complete",
                batch_index=batch_idx + 1,
                tasks_succeeded=tasks_succeeded,
                tasks_failed=tasks_failed,
                groups_written=len(groups_written),
            )

            # Guard: skip yield if all tasks failed
            if tasks_succeeded == 0:
                self._logger.error(
                    "batch_all_tasks_failed",
                    batch_index=batch_idx + 1,
                    total_tasks=len(all_tasks),
                    batch_dates=batch_date_keys,
                )
                batch_elapsed = _time.monotonic() - batch_start_time
                self._logger.info(
                    "batch_complete",
                    batch_index=batch_idx + 1,
                    total_batches=total_batches,
                    batch_dates=batch_date_keys,
                    doys_succeeded=0,
                    doys_failed=len(batch),
                    batch_seconds=round(batch_elapsed, 2),
                )
                continue

            # Yield per date in batch order (deterministic output)
            doys_succeeded = 0
            doys_failed = 0
            for date_key, _receivers in batch:
                if date_datasets.get(date_key):
                    doys_succeeded += 1
                    yield (
                        date_key,
                        date_datasets[date_key],
                        date_timings[date_key],
                    )
                else:
                    doys_failed += 1

            batch_elapsed = _time.monotonic() - batch_start_time
            self._logger.info(
                "batch_complete",
                batch_index=batch_idx + 1,
                total_batches=total_batches,
                batch_dates=batch_date_keys,
                doys_succeeded=doys_succeeded,
                doys_failed=doys_failed,
                batch_seconds=round(batch_elapsed, 2),
            )

    def _process_sub_day_batches(
        self,
        filtered_dates: list[tuple[str, dict[str, tuple[Path, str, Path | None, str]]]],
        keep_vars: list[str] | None,
    ) -> Generator[tuple[str, dict[str, xr.Dataset], dict[str, float]]]:
        """Process dates with sub-day file batching (batch_hours < 24).

        Splits RINEX files within each day into smaller chunks based on
        ``batch_hours``, processing each chunk separately. Still yields
        per-DOY and commits to Icechunk per-DOY.

        Parameters
        ----------
        filtered_dates : list
            Filtered ``(date_key, receivers)`` pairs.
        keep_vars : list[str] | None
            Variables to keep in datasets.

        Yields
        ------
        tuple[str, dict[str, xr.Dataset], dict[str, float]]
            ``(date_key, datasets, timings)`` per DOY.

        """
        self._logger.info(
            "sub_day_batch_strategy",
            batch_hours=self.batch_hours,
            total_dates=len(filtered_dates),
        )

        # For sub-day batches, we still process per-date but the processor
        # handles smaller file chunks. The current processor already processes
        # all files for a date, so we delegate to the single-date processor
        # which internally uses ProcessPoolExecutor for parallelism.
        # The sub-day batch_hours primarily controls how many files are
        # submitted to the pool at once.
        dates_succeeded = 0
        dates_failed = 0
        for date_idx, (date_key, receivers) in enumerate(filtered_dates):
            self._memory_monitor.log_memory_stats(context=f"before_sub_day_{date_key}")
            self._logger.info(
                "sub_day_date_started",
                date=date_key,
                date_index=date_idx + 1,
                total_dates=len(filtered_dates),
            )

            result = self._process_single_date(date_key, receivers, keep_vars)
            if result is not None:
                dates_succeeded += 1
                yield result
            else:
                dates_failed += 1
                self._logger.warning(
                    "sub_day_date_failed",
                    date=date_key,
                    date_index=date_idx + 1,
                )

        self._logger.info(
            "sub_day_strategy_complete",
            dates_succeeded=dates_succeeded,
            dates_failed=dates_failed,
            total_dates=len(filtered_dates),
        )

    def process_by_date(
        self,
        keep_vars: list[str] | None = None,
        start_from: str | None = None,
        end_at: str | None = None,
    ) -> Generator[tuple[str, dict[str, xr.Dataset], dict[str, float]]]:
        """Process all receivers grouped by date.

        Each unique receiver is processed once per day with its actual name
        as the Icechunk group name. Dispatches to multi-day or sub-day batch
        strategies based on ``batch_hours``.

        Parameters
        ----------
        keep_vars : list[str], optional
            Variables to keep in datasets
        start_from : str, optional
            YYYYDOY string to start from
        end_at : str, optional
            YYYYDOY string to end at

        Yields
        ------
        tuple[str, dict[str, xr.Dataset], dict[str, float]]
            Date string, dict of {receiver_name: dataset}, and timings

        """
        if self.dry_run:
            self._logger.info(
                "dry_run_mode", message="Simulating processing without execution"
            )
            self.print_preview()
            return

        grouped = self._group_by_date_and_receiver()
        filtered_dates = self._filter_dates(grouped, start_from, end_at)

        if not filtered_dates:
            self._logger.warning(
                "no_dates_in_range", start_from=start_from, end_at=end_at
            )
            return

        self._logger.info(
            "process_by_date_started",
            total_dates=len(filtered_dates),
            date_range_start=filtered_dates[0][0],
            date_range_end=filtered_dates[-1][0],
            batch_hours=self.batch_hours,
            n_max_workers=self.n_max_workers,
        )

        overall_start = _time.monotonic()

        # Validate batch floor against first receiver's file count
        _first_date_key, first_receivers = filtered_dates[0]
        first_receiver_info = next(iter(first_receivers.values()))
        first_data_dir = first_receiver_info[0]
        n_files = len(
            list(first_data_dir.glob("*.2*o")) or list(first_data_dir.glob("*.??o"))
        )
        if n_files > 0:
            self._validate_batch_floor(n_files)

        strategy = "multi_day" if self.batch_hours >= 24 else "sub_day"
        self._logger.info(
            "batch_strategy_selected",
            strategy=strategy,
            batch_hours=self.batch_hours,
        )

        if self.batch_hours >= 24:
            yield from self._process_multi_day_batches(filtered_dates, keep_vars)
        else:
            yield from self._process_sub_day_batches(filtered_dates, keep_vars)

        overall_elapsed = _time.monotonic() - overall_start
        self._logger.info(
            "process_by_date_complete",
            total_dates=len(filtered_dates),
            strategy=strategy,
            total_seconds=round(overall_elapsed, 2),
        )


class SingleReceiverProcessor:
    """Process a single receiver for one day.

    Parameters
    ----------
    receiver_name : str
        Actual receiver name (e.g., 'canopy_01', 'reference_01')
    receiver_type : str
        Receiver type ('canopy' or 'reference')
    data_dir : Path
        Directory containing RINEX files
    yyyydoy : YYYYDOY
        Date to process
    site : GnssResearchSite
        Research site
    n_max_workers : int
        Maximum parallel workers

    """

    def __init__(
        self,
        receiver_name: str,
        receiver_type: str,
        data_dir: Path,
        yyyydoy: YYYYDOY,
        site: GnssResearchSite,
        n_max_workers: int = 12,
        reader_name: str = "rinex3",
    ) -> None:
        self.receiver_name = receiver_name
        self.receiver_type = receiver_type
        self.data_dir = data_dir
        self.yyyydoy = yyyydoy
        self.site = site
        self.n_max_workers = n_max_workers
        self.reader_name = reader_name
        self._logger = get_logger(__name__).bind(
            receiver=receiver_name,
            date=yyyydoy.to_str(),
        )

    def _get_rinex_files(self) -> list[Path]:
        """Get sorted list of GNSS data files using BUILTIN_PATTERNS globs."""
        globs: set[str] = set()
        for name in auto_match_order():
            globs.update(BUILTIN_PATTERNS[name].file_globs)

        files: list[Path] = []
        seen: set[Path] = set()
        for g in sorted(globs):
            for path in self.data_dir.glob(g):
                if path.is_file() and path not in seen:
                    seen.add(path)
                    files.append(path)
        return sorted(files)

    def process(self, keep_vars: list[str] | None = None) -> xr.Dataset:
        """Process all RINEX files for this receiver and write to Icechunk.

        Parameters
        ----------
        keep_vars : list[str], optional
            Variables to keep in datasets

        Returns
        -------
        xr.Dataset
            Final daily dataset for this receiver

        """
        rinex_files = self._get_rinex_files()

        if not rinex_files:
            self._logger.error(
                "no_rinex_files_found",
                data_dir=str(self.data_dir),
            )
            msg = f"No RINEX files found in {self.data_dir}"
            raise ValueError(msg)

        self._logger.info(
            "receiver_processing_started",
            rinex_files=len(rinex_files),
        )

        # Create matched dirs for aux data (using first available dir as dummy)
        matched_dirs = MatchedDirs(
            canopy_data_dir=self.data_dir,
            reference_data_dir=self.data_dir,  # Dummy, aux data is date-based
            yyyydoy=self.yyyydoy,
        )

        # Initialize processor with receiver name override
        processor = RinexDataProcessor(
            matched_data_dirs=matched_dirs,
            site=self.site,
            n_max_workers=self.n_max_workers,
            reader_name=self.reader_name,
        )

        # Process with actual receiver name (NOT type)
        # This requires modifying RinexDataProcessor to accept receiver_name parameter
        return processor._process_receiver(  # ty: ignore[unresolved-attribute]
            rinex_files=rinex_files,
            receiver_name=self.receiver_name,  # Use actual name as group
            receiver_type=self.receiver_type,
            keep_vars=keep_vars,
        )


if __name__ == "__main__":
    from canvod.store import GnssResearchSite
    from canvod.utils.config import load_config

    cfg = load_config()
    proc = cfg.processing.processing
    site = GnssResearchSite(site_name="Rosalia")

    # All params from config — no hardcoded defaults
    keep_vars = proc.keep_rnx_vars
    resources = proc.resolve_resources()
    with PipelineOrchestrator(
        site=site,
        dry_run=False,
        n_max_workers=resources["n_workers"],
        batch_hours=proc.batch_hours,
        max_memory_gb=resources["max_memory_gb"],
        cpu_affinity=resources["cpu_affinity"],
        nice_priority=resources["nice_priority"],
    ) as orchestrator:
        for date_key, datasets, _timings in orchestrator.process_by_date(
            keep_vars=keep_vars
        ):
            print(f"\nProcessed date: {date_key}")
            for receiver_name, ds in datasets.items():
                print(f"  {receiver_name}: {dict(ds.sizes)}")
