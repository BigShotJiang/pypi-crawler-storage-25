<!-- rye:signed:2026-03-30T06:50:00Z:d7b89f77a67173ccd883d83aac5c8cefa2a288393038e4f8008261c3af61e798:vSx3wN6qPT03vP3efa_ScfR6zApYR7l6m4mp6IhkFgCHO1UavgOFCZBEyi-0UZ2Jqu03AvjWX2Cg0wKmcl-BAA:6ea18199041a1ea8 -->
# Registry Logout

Clear the local authentication session.

```xml
<directive name="logout" version="1.0.0">
  <metadata>
    <description>Wraps the registry tool action=logout to clear the local auth session.</description>
    <category>rye/core/registry</category>
    <author>rye-os</author>
    <model tier="fast" />
    <limits turns="3" tokens="2048" />
    <permissions>
      <execute>
        <tool>rye.core.registry.*</tool>
      </execute>
    </permissions>
  </metadata>

  <inputs />

  <outputs>
    <output name="status">Logout confirmation</output>
  </outputs>
</directive>
```

<process>
  <step name="call_registry_logout">
    Call the registry tool with action=logout.
    `rye_execute(item_type="tool", item_id="rye/core/registry/registry", parameters={"action": "logout"})`
  </step>

  <step name="return_result">
    Return the logout confirmation to the user.
  </step>
</process>
