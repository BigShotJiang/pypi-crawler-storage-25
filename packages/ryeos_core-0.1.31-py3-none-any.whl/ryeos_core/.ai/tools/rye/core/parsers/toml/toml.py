# rye:signed:2026-03-30T06:50:01Z:8febd1a77e329a7ea74a168404f10b5ad6cf99f21f9b5fae752747af6091fc75:U0_-AaBi4J5gmfXgNP8C9vv17PRBKiKdA3le9HdmT3K-YhlFX-d2ITizYwNe9FLkbHYSjqUqlEkxlGsjLSLVCA:6ea18199041a1ea8
"""TOML parser for RYE."""

__version__ = "1.0.0"
__tool_type__ = "parser"
__category__ = "rye/core/parsers/toml"
__tool_description__ = "TOML parser - parse TOML content into Python dictionaries"

import sys

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomli as tomllib
    except ImportError:
        tomllib = None


def parse(content):
    """Parse TOML content."""
    if tomllib is None:
        return {"error": "No TOML parser available. Install tomli for Python < 3.11."}
    try:
        return {"data": tomllib.loads(content) or {}, "content": content}
    except Exception as e:
        return {"error": f"TOML parse error: {e}", "content": content}
