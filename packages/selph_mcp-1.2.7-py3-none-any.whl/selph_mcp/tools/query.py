"""
MCP ``query`` tool — structured evidence retrieval over the persona graph.

Hard boundary: this tool MUST NOT synthesize natural-language answers.
The kernel returns structured evidence bundles (records). Synthesis is
an App concern and lives in ``selph_apps.answering`` — NEVER imported
here (the ``.importlinter`` contract enforces this).

Delegates to the deployed engine via ``GET /apps/answer/kg/answer``
(HTTP). No direct imports of ``selph_core``, ``selph_graph``, or
``selph_db``.
"""
from __future__ import annotations

import logging
import time as _time
from typing import Optional

from mcp.server.fastmcp import Context, FastMCP

from selph_mcp._client import EngineUpstreamError, get_client
from selph_mcp.config import SelphContext, stamp_mcp_trace_id
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.tools.query")


def _resolve_user_id(arg: Optional[str], ctx_obj: SelphContext) -> str:
    uid = (arg or "").strip() or (ctx_obj.default_user_id or "")
    if not uid:
        raise ValueError(
            "user_id is required — supply it as a tool argument or set "
            "SELPH_USER_ID in the server environment."
        )
    return uid


def register(server: FastMCP) -> None:
    @server.tool(
        name="query",
        description=(
            "Query the persona kernel across L1/L2/L3/L4. Returns structured "
            "evidence bundles — NEVER a synthesized natural-language answer. "
            "Synthesis is an App concern; Consumers that want NL output "
            "should call an App tool or synthesize themselves."
        ),
    )
    async def query(
        question: str,
        user_id: Optional[str] = None,
        include_evidence: bool = False,
        max_results: int = 10,
        tz: str = "America/Chicago",
        ctx: Optional[Context] = None,
    ) -> dict:
        """
        Run the kernel-side query pipeline and return structured records.

        Parameters mirror the design brief:
            - ``question``        : natural language question (required).
            - ``user_id``         : per-call override for the scoped user
                                    (falls back to ``SELPH_USER_ID``).
            - ``include_evidence``: include raw anchor content / scores
                                    in each record. When False the result
                                    list is trimmed to the most compact
                                    surface.
            - ``max_results``     : cap on records returned to the
                                    Consumer.
        """
        assert ctx is not None, "MCP runtime always supplies ctx"
        stamp_mcp_trace_id()
        lifespan_ctx: SelphContext = ctx.request_context.lifespan_context
        t0 = _time.perf_counter()

        try:
            resolved_user_id = _resolve_user_id(user_id, lifespan_ctx)
        except ValueError as exc:
            log_event(
                _log, logging.WARNING, "mcp.query.bad_request",
                user_id=user_id,
                consumer_id=lifespan_ctx.default_consumer_id,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise

        question_trimmed = (question or "").strip()
        if not question_trimmed:
            log_event(
                _log, logging.WARNING, "mcp.query.bad_request",
                user_id=resolved_user_id,
                consumer_id=lifespan_ctx.default_consumer_id,
                error_type="ValueError",
                error="question is required",
            )
            raise ValueError("question must be a non-empty string")

        if max_results <= 0:
            max_results = 10

        log_event(
            _log, logging.INFO, "mcp.query.entry",
            user_id=resolved_user_id,
            consumer_id=lifespan_ctx.default_consumer_id,
            question_len=len(question_trimmed),
            max_results=max_results,
            include_evidence=include_evidence,
            tz=tz,
        )

        try:
            data = await get_client().post(
                "/apps/answer/kg/answer",
                json={
                    "query": question_trimmed,
                    "user_id": resolved_user_id,
                    "tz": tz,
                },
            )
        except EngineUpstreamError as exc:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.query.error",
                user_id=resolved_user_id,
                consumer_id=lifespan_ctx.default_consumer_id,
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise RuntimeError(f"Query engine returned an error: {exc}") from exc
        except Exception as exc:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.query.error",
                user_id=resolved_user_id,
                consumer_id=lifespan_ctx.default_consumer_id,
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise

        # The engine's KGAnswerResponse has `evidence` (list of records) and
        # `answer` (synthesized text). The MCP query tool returns only the
        # structured evidence bundles — never the synthesized answer.
        records = list(data.get("evidence") or [])
        truncated = False
        if len(records) > max_results:
            records = records[:max_results]
            truncated = True

        # Compact surface when the Consumer asked to skip evidence payloads.
        # We pass through the full records otherwise — synthesis / formatting
        # is NOT the kernel's job.
        if not include_evidence:
            records = [_compact_record(r) for r in records]

        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.INFO, "mcp.query.complete",
            user_id=resolved_user_id,
            consumer_id=lifespan_ctx.default_consumer_id,
            result_count=len(records),
            truncated=truncated,
            duration_ms=duration_ms,
        )

        return {
            "status": "ok",
            "user_id": resolved_user_id,
            "result_count": len(records),
            "truncated": truncated,
            "results": records,
        }


def _compact_record(record: object) -> object:
    """Trim verbose evidence payloads when include_evidence=False.

    The kernel's query pipeline returns dict-like records. We keep id /
    type / score fields and drop the long content blobs that only matter
    when the Consumer asked for full evidence. Non-dict records pass
    through unchanged.
    """
    if not isinstance(record, dict):
        return record

    keep_keys = {
        "memory_id",
        "entity_id",
        "hub_id",
        "id",
        "type",
        "memory_type",
        "entity_type",
        "hub_type",
        "score",
        "confidence",
        "layer",
        "staleness_status",
        "generated_at",
    }
    compact = {k: v for k, v in record.items() if k in keep_keys}
    # Keep a short preview when available so the Consumer still gets a
    # hint at what the record is about without paying for the full blob.
    content = record.get("content") or record.get("text") or record.get("summary")
    if isinstance(content, str) and content:
        compact["content_preview"] = content[:200]
    return compact


__all__ = ["register"]
