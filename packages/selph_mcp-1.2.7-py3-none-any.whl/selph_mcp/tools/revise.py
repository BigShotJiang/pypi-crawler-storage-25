"""
MCP ``revise`` tool — unified revision surface (Gap 5 syscall).

Thin adapter over the engine's ``POST /core/revise/`` endpoint. All
parameters map 1:1 to the engine's ``RevisionRequest``. The
``initiated_by`` field is stamped as ``consumer:<consumer_id>`` so the
audit trail records which Consumer requested the mutation.

No direct imports of ``selph_core``, ``selph_db``, or ``selph_graph``.
Delegates via HTTP to the deployed engine.
"""
from __future__ import annotations

import logging
import os
import time as _time
from typing import Any, Optional

from mcp.server.fastmcp import Context, FastMCP

from selph_mcp._client import EngineUpstreamError, RevisionTargetNotFoundError, get_client
from selph_mcp.config import SelphContext, stamp_mcp_trace_id
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.tools.revise")

# Valid target types — kept as a local set so we can validate before the
# HTTP call and return a clean 400 with a user-readable message rather
# than propagating the engine's 422.
_VALID_TARGET_TYPES = frozenset({
    "entity_field",
    "memory",
    "review_item",
    "identity_claim",
})

# Valid actions.
_VALID_ACTIONS = frozenset({
    "correct",
    "retract",
    "accept",
    "reject",
    "supersede",
    "defer",
})


def _resolve_user_id(arg: Optional[str], ctx_obj: SelphContext) -> str:
    uid = (arg or "").strip() or (ctx_obj.default_user_id or "")
    if not uid:
        raise ValueError(
            "user_id is required — supply it as a tool argument or set "
            "SELPH_USER_ID in the server environment."
        )
    return uid


def _resolve_consumer_id(
    consumer_id_arg: Optional[str],
    ctx_obj: SelphContext,
) -> str:
    """Resolve the Consumer identity for audit attribution.

    Precedence (per the Gap 6 brief):
        1. Tool-call ``consumer_id`` argument
        2. ``SELPH_CONSUMER_ID`` environment variable
        3. ``SelphContext.default_consumer_id`` (populated from env at lifespan)
        4. ``"mcp_client"`` literal fallback
    """
    candidate = (consumer_id_arg or "").strip()
    if not candidate:
        env_val = os.getenv("SELPH_CONSUMER_ID")
        candidate = env_val.strip() if env_val and env_val.strip() else ""
    if not candidate:
        candidate = ctx_obj.default_consumer_id or "mcp_client"
    return candidate


def register(server: FastMCP) -> None:
    @server.tool(
        name="revise",
        description=(
            "Correct, retract, or supersede persona data. Every call writes "
            "one revision_events audit row. Target types: entity_field | "
            "memory | review_item | identity_claim. Actions: correct | "
            "retract | accept | reject | supersede | defer."
        ),
    )
    async def revise(
        target_type: str,
        target_id: str,
        action: str,
        reason: str,
        user_id: Optional[str] = None,
        consumer_id: Optional[str] = None,
        new_value: Optional[dict] = None,
        evidence_ids: Optional[list] = None,
        ctx: Optional[Context] = None,
    ) -> dict:
        """Dispatch a revision through the engine's ``POST /core/revise/``."""
        assert ctx is not None, "MCP runtime always supplies ctx"
        stamp_mcp_trace_id()
        lifespan_ctx: SelphContext = ctx.request_context.lifespan_context
        t0 = _time.perf_counter()

        # Resolve Consumer identity up-front so every subsequent audit log
        # records the resolved value rather than whatever the caller sent
        # (or didn't send). Cannot raise.
        resolved_consumer = _resolve_consumer_id(consumer_id, lifespan_ctx)
        initiated_by = f"consumer:{resolved_consumer}"

        # Local enum validation — mirrors what the engine would reject with
        # a 422, but surfaces a clean ValueError with a user-readable message.
        try:
            resolved_user_id = _resolve_user_id(user_id, lifespan_ctx)
            if target_type not in _VALID_TARGET_TYPES:
                raise ValueError(
                    f"Invalid target_type {target_type!r}. "
                    f"Must be one of: {sorted(_VALID_TARGET_TYPES)}"
                )
            if action not in _VALID_ACTIONS:
                raise ValueError(
                    f"Invalid action {action!r}. "
                    f"Must be one of: {sorted(_VALID_ACTIONS)}"
                )
        except ValueError as exc:
            log_event(
                _log, logging.WARNING, "mcp.revise.bad_request",
                user_id=user_id,
                consumer_id=resolved_consumer,
                target_type=target_type,
                action=action,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise

        if not (reason or "").strip():
            log_event(
                _log, logging.WARNING, "mcp.revise.bad_request",
                user_id=resolved_user_id,
                consumer_id=resolved_consumer,
                target_type=target_type,
                action=action,
                error_type="ValueError",
                error="reason must be a non-empty string",
            )
            raise ValueError("reason must be a non-empty string")

        log_event(
            _log, logging.INFO, "mcp.revise.entry",
            user_id=resolved_user_id,
            consumer_id=resolved_consumer,
            initiated_by=initiated_by,
            target_type=target_type,
            target_id=target_id,
            action=action,
            has_new_value=new_value is not None,
            evidence_count=len(evidence_ids or []),
        )

        body: dict[str, Any] = {
            "user_id": resolved_user_id,
            "target_type": target_type,
            "target_id": target_id,
            "action": action,
            "reason": reason,
            "initiated_by": initiated_by,
            "evidence_ids": list(evidence_ids or []),
        }
        if new_value is not None:
            body["new_value"] = new_value

        try:
            result = await get_client().post("/core/revise/", json=body)
        except RevisionTargetNotFoundError as exc:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.WARNING, "mcp.revise.not_found",
                user_id=resolved_user_id,
                consumer_id=resolved_consumer,
                target_type=target_type,
                target_id=target_id,
                action=action,
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise ValueError(f"Revision target not found: {target_id!r}") from exc
        except EngineUpstreamError as exc:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.revise.error",
                user_id=resolved_user_id,
                consumer_id=resolved_consumer,
                target_type=target_type,
                target_id=target_id,
                action=action,
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise
        except Exception as exc:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.revise.error",
                user_id=resolved_user_id,
                consumer_id=resolved_consumer,
                target_type=target_type,
                target_id=target_id,
                action=action,
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise

        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.INFO, "mcp.revise.complete",
            user_id=resolved_user_id,
            consumer_id=resolved_consumer,
            revision_id=result.get("revision_id"),
            target_type=result.get("target_type"),
            action=result.get("action"),
            status=result.get("status"),
            duration_ms=duration_ms,
        )
        return result


__all__ = ["register"]
