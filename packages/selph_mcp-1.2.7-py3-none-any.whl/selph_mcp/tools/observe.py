"""
MCP ``observe`` tool — wraps ``raw_evidence_manager.insert_raw_evidence_detailed``.

Semantics:
    - Writes one row to the L1 ``raw_evidence`` ledger and returns its UUID.
    - If the (user, source_type, content) tuple already exists the existing
      row is returned and ``status`` is ``"deduplicated"``.
    - When ``trigger_extraction=True`` (default) the handler also schedules
      ``run_extraction_pipeline`` as a fire-and-forget background task and
      reports ``extraction_scheduled=True`` to the Consumer.
"""
from __future__ import annotations

import asyncio
import gc
import logging
import os
import time as _time
from datetime import datetime
from typing import Any, Optional

from mcp.server.fastmcp import Context, FastMCP

from selph_mcp.config import SelphContext, stamp_mcp_trace_id
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.tools.observe")

# Bound concurrent fire-and-forget extractions so a burst of ``observe``
# calls cannot pile up Phase 0-5 coroutines (each ~49 MB working set) on
# the MCP event loop. The existing `_phase7_sem` only gates Phases 6-7;
# Phases 0-5 are LLM-heavy and not globally bounded elsewhere. Overridable
# via env for operators running SSE at higher concurrency.
_MCP_EXTRACTION_CONCURRENCY = int(os.getenv("SELPH_MCP_EXTRACTION_CONCURRENCY", "4"))
_extraction_sem = asyncio.Semaphore(_MCP_EXTRACTION_CONCURRENCY)


def _resolve_user_id(arg: Optional[str], ctx_obj: SelphContext) -> str:
    uid = (arg or "").strip() or (ctx_obj.default_user_id or "")
    if not uid:
        raise ValueError(
            "user_id is required — supply it as a tool argument or set "
            "SELPH_USER_ID in the server environment."
        )
    return uid


def _parse_original_timestamp(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(
            f"original_timestamp must be ISO-8601 (e.g. 2026-04-17T12:00:00Z) — "
            f"got {value!r}: {exc}"
        ) from exc


def register(server: FastMCP) -> None:
    @server.tool(
        name="observe",
        description=(
            "Ingest raw evidence into the persona kernel (L1 write). "
            "Provide either content_text or content_json, not both. "
            "By default the tool also triggers asynchronous extraction "
            "(Phases 0-7) so L2/L3 promotion happens without a second call. "
            "Returns {raw_evidence_id, status, extraction_scheduled}."
        ),
    )
    async def observe(
        user_id: Optional[str] = None,
        content_text: Optional[str] = None,
        content_json: Optional[dict] = None,
        source_type: str = "generic_message",
        source_channel: str = "mcp",
        external_source_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
        original_timestamp: Optional[str] = None,
        metadata: Optional[dict] = None,
        trigger_extraction: bool = True,
        ctx: Optional[Context] = None,
    ) -> dict:
        """Write L1 evidence and optionally schedule extraction."""
        assert ctx is not None, "MCP runtime always supplies ctx"
        stamp_mcp_trace_id()
        lifespan_ctx: SelphContext = ctx.request_context.lifespan_context
        t0 = _time.perf_counter()

        try:
            resolved_user_id = _resolve_user_id(user_id, lifespan_ctx)
            parsed_ts = _parse_original_timestamp(original_timestamp)
        except ValueError as exc:
            log_event(
                _log, logging.WARNING, "mcp.observe.bad_request",
                user_id=user_id,
                consumer_id=lifespan_ctx.default_consumer_id,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise

        log_event(
            _log, logging.INFO, "mcp.observe.entry",
            user_id=resolved_user_id,
            consumer_id=lifespan_ctx.default_consumer_id,
            source_type=source_type,
            source_channel=source_channel,
            external_source_id=external_source_id,
            trigger_extraction=trigger_extraction,
            has_content_text=content_text is not None,
            has_content_json=content_json is not None,
        )

        # ── L1 write ────────────────────────────────────────────────────
        try:
            from selph_db.raw_evidence_manager import insert_raw_evidence_detailed

            loop = asyncio.get_running_loop()
            insert_result = await loop.run_in_executor(
                None,
                lambda: insert_raw_evidence_detailed(
                    user_id=resolved_user_id,
                    source_type=source_type,
                    content_text=content_text,
                    content_json=content_json,
                    source_channel=source_channel,
                    external_source_id=external_source_id,
                    conversation_id=conversation_id,
                    original_timestamp=parsed_ts,
                    metadata=metadata,
                ),
            )
        except Exception as exc:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.observe.error",
                user_id=resolved_user_id,
                consumer_id=lifespan_ctx.default_consumer_id,
                source_type=source_type,
                error_type=type(exc).__name__,
                error=str(exc),
                duration_ms=duration_ms,
            )
            raise

        raw_evidence_id = insert_result.raw_evidence_id
        l1_status = insert_result.status  # "created" | "deduplicated"

        # ── Optional background extraction ──────────────────────────────
        extraction_scheduled = False
        if trigger_extraction:
            try:
                task = asyncio.create_task(
                    _run_extraction_background(
                        raw_evidence_id=raw_evidence_id,
                        user_id=resolved_user_id,
                        consumer_id=lifespan_ctx.default_consumer_id,
                        content_text=content_text,
                        content_json=content_json,
                        source_type=source_type,
                        source_channel=source_channel,
                        external_source_id=external_source_id,
                        metadata=metadata,
                        graph=lifespan_ctx.neo4j,
                    ),
                    name=f"selph_mcp.observe.extract:{raw_evidence_id}",
                )
                lifespan_ctx.background_tasks.add(task)
                # discard (not remove) so double-gc can't KeyError us.
                task.add_done_callback(
                    lambda t: _finalize_task(t, lifespan_ctx, raw_evidence_id)
                )
                extraction_scheduled = True
            except Exception as exc:  # noqa: BLE001
                log_event(
                    _log, logging.ERROR, "mcp.observe.extraction_schedule_failed",
                    user_id=resolved_user_id,
                    consumer_id=lifespan_ctx.default_consumer_id,
                    raw_evidence_id=raw_evidence_id,
                    error_type=type(exc).__name__,
                    error=str(exc),
                )

        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.INFO, "mcp.observe.complete",
            user_id=resolved_user_id,
            consumer_id=lifespan_ctx.default_consumer_id,
            raw_evidence_id=raw_evidence_id,
            status=l1_status,
            extraction_scheduled=extraction_scheduled,
            duration_ms=duration_ms,
        )

        return {
            "raw_evidence_id": raw_evidence_id,
            "status": l1_status,
            "extraction_scheduled": extraction_scheduled,
        }


def _finalize_task(
    task: asyncio.Task[Any],
    lifespan_ctx: SelphContext,
    raw_evidence_id: str,
) -> None:
    """Done-callback: log exceptions and discard from the registry."""
    lifespan_ctx.background_tasks.discard(task)
    if task.cancelled():
        log_event(
            _log, logging.WARNING, "mcp.observe.extraction_cancelled",
            raw_evidence_id=raw_evidence_id,
        )
        return
    exc = task.exception()
    if exc is not None:
        log_event(
            _log, logging.ERROR, "mcp.observe.extraction_task_error",
            raw_evidence_id=raw_evidence_id,
            error_type=type(exc).__name__,
            error=str(exc),
        )


async def _run_extraction_background(
    *,
    raw_evidence_id: str,
    user_id: str,
    consumer_id: str,
    content_text: Optional[str],
    content_json: Optional[dict],
    source_type: str,
    source_channel: str,
    external_source_id: Optional[str],
    metadata: Optional[dict],
    graph: Any,
) -> None:
    """Build an IngestRequest from the raw evidence and run Phases 0-7.

    Gated by ``_extraction_sem`` so concurrent ``observe`` calls cannot
    saturate the MCP event loop with Phase 0-5 coroutine frames. Runs
    ``gc.collect()`` after completion to release httpx response buffers /
    PydanticAI agent state held across awaits (matches the GC hygiene
    pattern used by the FastAPI ingestion routes).
    """
    from selph_core.observe.pipeline import run_extraction_pipeline
    from selph_core.observe.request import IngestRequest

    async with _extraction_sem:
        t0 = _time.perf_counter()
        log_event(
            _log, logging.INFO, "mcp.observe.extraction.start",
            user_id=user_id,
            consumer_id=consumer_id,
            raw_evidence_id=raw_evidence_id,
            source_type=source_type,
        )

        # Build a minimal IngestRequest. `message` is required by the schema,
        # so when the caller provided structured JSON we fall back to a
        # deterministic JSON dump — Phase 0-3 prompts can still reason over it.
        if content_text is not None:
            message_text = content_text
        else:
            import json as _json
            message_text = _json.dumps(content_json or {}, sort_keys=True)

        try:
            payload = IngestRequest(
                user_id=user_id,
                message=message_text,
                source="api",
                client_msg_id=None,
                raw_evidence_id=raw_evidence_id,
            )
        except Exception as exc:  # noqa: BLE001
            log_event(
                _log, logging.ERROR, "mcp.observe.extraction.request_build_failed",
                user_id=user_id,
                consumer_id=consumer_id,
                raw_evidence_id=raw_evidence_id,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            return

        try:
            result = await run_extraction_pipeline(payload, graph=graph)
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.observe.extraction.complete",
                user_id=user_id,
                consumer_id=consumer_id,
                raw_evidence_id=raw_evidence_id,
                status=result.get("status"),
                duration_ms=duration_ms,
                entities_successful=result.get("entity_results", {}).get("successful"),
                memories_successful=result.get("memory_results", {}).get("successful"),
            )
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.observe.extraction.error",
                user_id=user_id,
                consumer_id=consumer_id,
                raw_evidence_id=raw_evidence_id,
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc),
            )
        finally:
            # Release httpx response buffers / PydanticAI agent frames held
            # across awaits — cheap insurance against RSS creep under burst
            # `observe` traffic. Incident 1 lesson: async LLM pipelines without
            # explicit gc hints accumulate response buffers linearly with call
            # rate.
            gc.collect()


__all__ = ["register"]
