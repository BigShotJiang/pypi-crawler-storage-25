"""
Tool registrar for the Selph MCP Surface.

Each tool module exposes a ``register(server)`` function. ``register_all``
calls every one of them so ``selph_mcp.server`` only has to import this
package and get all four syscalls wired in one go.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover — typing only
    from mcp.server.fastmcp import FastMCP


def register_all(server: "FastMCP") -> None:
    """Register observe, query, project, revise, and compile_skill on the given server."""
    from selph_mcp.tools import compile_skill as compile_skill_tool
    from selph_mcp.tools import observe as observe_tool
    from selph_mcp.tools import project as project_tool
    from selph_mcp.tools import query as query_tool
    from selph_mcp.tools import revise as revise_tool

    observe_tool.register(server)
    query_tool.register(server)
    project_tool.register(server)
    revise_tool.register(server)
    compile_skill_tool.register(server)


__all__ = ["register_all"]
