"""
MCP ``project`` tool — scoped persona projection.

Thin adapter over the engine's ``POST /core/project/`` endpoint. Every call
writes one ``projection_events`` row (audit trail) via the engine. No direct
imports of ``selph_core``, ``selph_db``, or ``selph_graph``.

Valid scope values: full_persona | communication | professional | personal |
behavioral | domain.

Valid freshness values: latest | cached | max_age.
"""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Optional

from mcp.server.fastmcp import Context, FastMCP

from selph_mcp._client import EngineUpstreamError, get_client
from selph_mcp.config import SelphContext, stamp_mcp_trace_id
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.tools.project")

_VALID_SCOPES = frozenset({
    "full_persona", "communication", "professional",
    "personal", "behavioral", "domain",
})
_VALID_FRESHNESS = frozenset({"latest", "cached", "max_age"})


def _resolve_user_id(arg: Optional[str], ctx_obj: SelphContext) -> str:
    uid = (arg or "").strip() or (ctx_obj.default_user_id or "")
    if not uid:
        raise ValueError(
            "user_id is required — supply it as a tool argument or set "
            "SELPH_USER_ID in the server environment."
        )
    return uid


def _resolve_consumer_id(arg: Optional[str], ctx_obj: SelphContext) -> str:
    value = (arg or "").strip() or ctx_obj.default_consumer_id
    return value or "mcp_client"


def register(server: FastMCP) -> None:
    @server.tool(
        name="project",
        description=(
            "Emit a scoped persona projection (structured JSON, SKILL.md "
            "text, or prose narrative). Every call is audit-logged against "
            "the supplied consumer_id / consumer_purpose. Scopes: "
            "full_persona | communication | professional | personal | "
            "behavioral | domain."
        ),
    )
    async def project(
        consumer_purpose: str,
        user_id: Optional[str] = None,
        consumer_id: Optional[str] = None,
        scope: str = "full_persona",
        domain_filter: Optional[str] = None,
        output_format: str = "structured",
        include_evidence: bool = False,
        include_confidence: bool = False,
        freshness: str = "cached",
        max_age_hours: Optional[int] = None,
        ctx: Optional[Context] = None,
    ) -> dict:
        """Dispatch a ``ProjectionRequest`` through the engine's project endpoint."""
        assert ctx is not None, "MCP runtime always supplies ctx"
        stamp_mcp_trace_id()
        lifespan_ctx: SelphContext = ctx.request_context.lifespan_context
        t0 = _time.perf_counter()

        try:
            resolved_user_id = _resolve_user_id(user_id, lifespan_ctx)
            resolved_consumer_id = _resolve_consumer_id(consumer_id, lifespan_ctx)
            if scope not in _VALID_SCOPES:
                raise ValueError(
                    f"Invalid scope {scope!r}. Must be one of: {sorted(_VALID_SCOPES)}"
                )
            if freshness not in _VALID_FRESHNESS:
                raise ValueError(
                    f"Invalid freshness {freshness!r}. Must be one of: {sorted(_VALID_FRESHNESS)}"
                )
        except ValueError as exc:
            log_event(
                _log, logging.WARNING, "mcp.project.bad_request",
                user_id=user_id,
                consumer_id=consumer_id,
                scope=scope,
                freshness=freshness,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise

        log_event(
            _log, logging.INFO, "mcp.project.entry",
            user_id=resolved_user_id,
            consumer_id=resolved_consumer_id,
            scope=scope,
            domain_filter=domain_filter,
            output_format=output_format,
            freshness=freshness,
            include_evidence=include_evidence,
            include_confidence=include_confidence,
            max_age_hours=max_age_hours,
        )

        body: dict[str, Any] = {
            "user_id": resolved_user_id,
            "consumer_id": resolved_consumer_id,
            "consumer_purpose": consumer_purpose,
            "scope": scope,
            "output_format": output_format,
            "include_evidence": include_evidence,
            "include_confidence": include_confidence,
            "freshness": freshness,
        }
        if domain_filter is not None:
            body["domain_filter"] = domain_filter
        if max_age_hours is not None:
            body["max_age_hours"] = max_age_hours

        try:
            result = await get_client().post("/core/project/", json=body)
        except EngineUpstreamError as exc:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.project.error",
                user_id=resolved_user_id,
                consumer_id=resolved_consumer_id,
                scope=scope,
                output_format=output_format,
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise
        except Exception as exc:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.project.error",
                user_id=resolved_user_id,
                consumer_id=resolved_consumer_id,
                scope=scope,
                output_format=output_format,
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise

        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.INFO, "mcp.project.complete",
            user_id=resolved_user_id,
            consumer_id=resolved_consumer_id,
            projection_id=result.get("projection_id"),
            scope=result.get("scope"),
            output_format=result.get("output_format"),
            freshness_status=result.get("freshness_status"),
            hub_count=len(result.get("source_hubs") or []),
            duration_ms=duration_ms,
            status="ok",
        )
        return result


__all__ = ["register"]
