"""
MCP ``compile_skill`` tool — compile a portable persona SKILL.md.

Thin adapter over the engine's ``POST /core/compile/`` endpoint. Imports
go through the engine HTTP client — no direct imports of
``selph_core.compiler`` or ``selph_db``.

Filesystem writes are NOT performed here — when the Consumer wants the
compiled SKILL.md on disk they consume the returned ``skill_text`` and
write it themselves (or use the ``scripts/compile_skill.py`` CLI).
``include_manifest=True`` returns the citation manifest inline in the
response dict so the Consumer can persist it with matching semantics.

The ``min_confidence`` default is fetched lazily from the engine's
``GET /core/compile/thresholds`` on first use and cached process-wide so
we don't incur an extra round-trip on every call.
"""
from __future__ import annotations

import logging
import time as _time
from typing import Literal, Optional

from mcp.server.fastmcp import Context, FastMCP

from selph_mcp._client import EngineUpstreamError, get_client
from selph_mcp.config import SelphContext, stamp_mcp_trace_id
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.tools.compile_skill")

# Process-wide cache for the claim-inclusion threshold defaults fetched
# from the engine.  Populated lazily on the first compile call.
_cached_thresholds: Optional[dict] = None

# Fallback in case the engine is unreachable when we fetch thresholds.
_DEFAULT_MIN_CONFIDENCE = 0.6


async def _get_min_confidence_default() -> float:
    """Return ``CLAIM_INCLUSION['min_confidence']`` from the engine.

    Cached after the first successful fetch so subsequent calls are free.
    Falls back to :data:`_DEFAULT_MIN_CONFIDENCE` if the engine is not
    reachable.
    """
    global _cached_thresholds  # noqa: PLW0603 — intentional process-wide cache
    if _cached_thresholds is not None:
        return float(_cached_thresholds.get("min_confidence", _DEFAULT_MIN_CONFIDENCE))
    try:
        data = await get_client().get("/core/compile/thresholds")
        _cached_thresholds = data
        return float(data.get("min_confidence", _DEFAULT_MIN_CONFIDENCE))
    except Exception:  # noqa: BLE001 — non-fatal; use fallback
        return _DEFAULT_MIN_CONFIDENCE


def _resolve_user_id(arg: Optional[str], ctx_obj: SelphContext) -> str:
    uid = (arg or "").strip() or (ctx_obj.default_user_id or "")
    if not uid:
        raise ValueError(
            "user_id is required — supply it as a tool argument or set "
            "SELPH_USER_ID in the server environment."
        )
    return uid


def register(server: FastMCP) -> None:
    @server.tool(
        name="compile_skill",
        description=(
            "Compile a portable persona skill (SKILL.md) from the kernel. "
            "Every claim is evidence-backed and confidence-scored; returns "
            "status='insufficient_data' when the persona graph is too thin "
            "to compile a trustworthy skill (anti-Barnum protection). "
            "Set include_manifest=True to receive the citation manifest "
            "inline — no files are written by this tool. The `scope` "
            "argument is reserved for future use; for Gap 7 only "
            "'full_persona' is accepted and any other value is rejected."
        ),
    )
    async def compile_skill(
        user_id: Optional[str] = None,
        scope: Literal["full_persona"] = "full_persona",
        min_confidence: Optional[float] = None,
        include_manifest: bool = False,
        ctx: Optional[Context] = None,
    ) -> dict:
        """Dispatch a compile request through the engine's ``POST /core/compile/``."""
        assert ctx is not None, "MCP runtime always supplies ctx"
        stamp_mcp_trace_id()
        lifespan_ctx: SelphContext = ctx.request_context.lifespan_context
        t0 = _time.perf_counter()

        try:
            resolved_user_id = _resolve_user_id(user_id, lifespan_ctx)
        except ValueError as exc:
            log_event(
                _log, logging.WARNING, "mcp.compile_skill.bad_request",
                user_id=user_id,
                scope=scope,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise

        # Fall back to the configured floor if the caller omitted it —
        # fetched from the engine so MCP and Core stay in sync.
        resolved_min_confidence = (
            float(min_confidence)
            if min_confidence is not None
            else await _get_min_confidence_default()
        )

        log_event(
            _log, logging.INFO, "mcp.compile_skill.entry",
            user_id=resolved_user_id,
            scope=scope,
            min_confidence=resolved_min_confidence,
            include_manifest=include_manifest,
        )

        body = {
            "user_id": resolved_user_id,
            "scope": scope,
            "min_confidence": resolved_min_confidence,
            "include_manifest": include_manifest,
            # Filesystem writes are not a MCP-tool responsibility.
            "output_path": None,
            "dry_run": False,
        }

        try:
            result = await get_client().post("/core/compile/", json=body)
        except EngineUpstreamError as exc:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.compile_skill.error",
                user_id=resolved_user_id,
                scope=scope,
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise
        except Exception as exc:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.compile_skill.error",
                user_id=resolved_user_id,
                scope=scope,
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise

        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        status = result.get("status")

        if status == "insufficient_data":
            density = result.get("density_check") or {}
            log_event(
                _log, logging.WARNING, "mcp.compile_skill.insufficient_data",
                user_id=resolved_user_id,
                scope=scope,
                failures=density.get("failures", []),
                duration_ms=duration_ms,
                status="insufficient_data",
            )
        else:
            skill_text = result.get("skill_text") or ""
            log_event(
                _log, logging.INFO, "mcp.compile_skill.complete",
                user_id=resolved_user_id,
                scope=scope,
                projection_id=result.get("projection_id"),
                skill_chars=len(skill_text),
                duration_ms=duration_ms,
                status="ok",
            )

        return result


__all__ = ["register"]
