"""Session spool — harness-side local SQLite log + trigger/retry logic.

Implements §2 (trigger logic), §3 (local log schema), and the 409 trim+retry
handshake for the harness-driven session ingest route (Phase D).

Design constraints (per brief §3):
- SQLite (not JSON) because delete-on-ack must be atomic across crash boundaries.
- Debounce/backoff state lives in the spool metadata table so it survives
  Claude Code restarts.
- This module MUST NOT import selph_core, selph_db, selph_graph, ingestion_api,
  or selph_apps — only selph_mcp.contracts, selph_mcp.adapters.binding,
  selph_utils, stdlib, and this package (per runtime __init__.py import contract).

Clock-skew handling: negative deltas from last_successful_flush_at are clamped
to zero — no time has passed, do not fire prematurely, but do not debounce
either.

Trigger rules (any one fires unless debounce blocks):
  1. 20 USER messages accumulated since last successful flush
  2. Session start with any unsent rows in the local log
  3. 4-hour idle cron since last successful flush and log is non-empty

Debounce: skip trigger if last_successful_flush_at is within 10 minutes AND
fewer than 5 user messages have accumulated since that flush.

Failure backoff: 30s, 2m, 10m, then idle until next natural trigger.
"""

from __future__ import annotations

import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional, Tuple

from ._shared import _log

# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────

_USER_MSG_THRESHOLD = 20        # §2: flush after 20 user messages
_DEBOUNCE_MINUTES = 10          # §2: debounce window
_DEBOUNCE_MIN_MSGS = 5          # §2: min user msgs within debounce window to override
_IDLE_CRON_HOURS = 4            # §2: idle cron flush interval
_BACKOFF_SEQUENCE = (30, 120, 600)  # §2: exponential backoff seconds

_SPOOL_DB_FILENAME = "session_spool.db"


# ─────────────────────────────────────────────────────────────────────────────
# Path
# ─────────────────────────────────────────────────────────────────────────────

def _spool_db_path(workspace: Path) -> Path:
    """Return path to the session spool SQLite file."""
    return workspace / ".selph" / "state" / _SPOOL_DB_FILENAME


# ─────────────────────────────────────────────────────────────────────────────
# Schema initialisation
# ─────────────────────────────────────────────────────────────────────────────

_INIT_SQL = """
CREATE TABLE IF NOT EXISTS turns (
    session_id        TEXT    NOT NULL,
    turn_idx          INTEGER NOT NULL,
    role              TEXT    NOT NULL CHECK(role IN ('user', 'assistant')),
    content           TEXT    NOT NULL,
    ts                TEXT    NOT NULL,
    last_attempt_at   TEXT,
    last_attempt_id   TEXT,
    acked_at          TEXT,
    PRIMARY KEY (session_id, turn_idx)
);

CREATE TABLE IF NOT EXISTS spool_meta (
    id                        INTEGER PRIMARY KEY CHECK(id = 1),
    last_successful_flush_at  TEXT,
    next_retry_after          TEXT,
    last_attempt_error        TEXT,
    last_attempt_id           TEXT
);

INSERT OR IGNORE INTO spool_meta (id) VALUES (1);
"""


def _ensure_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(_INIT_SQL)
    conn.commit()


# ─────────────────────────────────────────────────────────────────────────────
# Connection helper
# ─────────────────────────────────────────────────────────────────────────────

@contextmanager
def _open_db(db_path: Path) -> Generator[sqlite3.Connection, None, None]:
    """Open the spool database, ensure schema, yield the connection."""
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path), isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    try:
        _ensure_schema(conn)
        yield conn
    finally:
        conn.close()


# ─────────────────────────────────────────────────────────────────────────────
# Turn write helpers
# ─────────────────────────────────────────────────────────────────────────────

def append_turn(
    db_path: Path,
    session_id: str,
    turn_idx: int,
    role: str,
    content: str,
    ts: str,
) -> None:
    """Append a single turn to the local log.

    Idempotent on (session_id, turn_idx) — INSERT OR IGNORE so a duplicate
    append from a re-delivered event does not overwrite acked state.
    """
    with _open_db(db_path) as conn:
        conn.execute(
            """
            INSERT OR IGNORE INTO turns
                   (session_id, turn_idx, role, content, ts)
            VALUES (?, ?, ?, ?, ?)
            """,
            (session_id, turn_idx, role, content, ts),
        )
    _log.debug(
        "session_spool.turn_appended",
        extra={
            "event": "session_spool.turn_appended",
            "session_id": session_id,
            "turn_idx": turn_idx,
            "role": role,
        },
    )


def get_pending_turns(
    db_path: Path,
    session_id: str,
    after_turn_idx: int = -1,
) -> List[Dict[str, Any]]:
    """Return all unacked turns for session_id with turn_idx > after_turn_idx, ordered."""
    with _open_db(db_path) as conn:
        cur = conn.execute(
            """
            SELECT session_id, turn_idx, role, content, ts,
                   last_attempt_at, last_attempt_id, acked_at
              FROM turns
             WHERE session_id = ?
               AND turn_idx > ?
               AND acked_at IS NULL
             ORDER BY turn_idx ASC
            """,
            (session_id, after_turn_idx),
        )
        return [dict(row) for row in cur.fetchall()]


def count_user_turns_since_flush(db_path: Path, session_id: str, since_turn_idx: int) -> int:
    """Count unacked USER turns with turn_idx > since_turn_idx."""
    with _open_db(db_path) as conn:
        cur = conn.execute(
            """
            SELECT COUNT(*) AS n
              FROM turns
             WHERE session_id = ?
               AND role = 'user'
               AND turn_idx > ?
               AND acked_at IS NULL
            """,
            (session_id, since_turn_idx),
        )
        row = cur.fetchone()
        return int(row["n"]) if row else 0


def stamp_attempt(
    db_path: Path,
    session_id: str,
    attempt_id: str,
    turn_idxs: List[int],
) -> None:
    """Stamp last_attempt_at and last_attempt_id on the given turns."""
    now_iso = _now_iso()
    with _open_db(db_path) as conn:
        conn.executemany(
            """
            UPDATE turns
               SET last_attempt_at = ?,
                   last_attempt_id = ?
             WHERE session_id = ?
               AND turn_idx = ?
            """,
            [(now_iso, attempt_id, session_id, idx) for idx in turn_idxs],
        )
    _log.debug(
        "session_spool.attempt_stamped",
        extra={
            "event": "session_spool.attempt_stamped",
            "session_id": session_id,
            "attempt_id": attempt_id,
            "turn_count": len(turn_idxs),
        },
    )


def delete_acked_turns(
    db_path: Path,
    session_id: str,
    up_to_turn_idx: int,
) -> int:
    """Atomically delete all turns with turn_idx <= up_to_turn_idx for session_id.

    Returns the count of deleted rows. This is the ack handshake — called
    after the server confirms acked_through_turn_idx = N.
    """
    with _open_db(db_path) as conn:
        cur = conn.execute(
            """
            DELETE FROM turns
             WHERE session_id = ?
               AND turn_idx <= ?
            """,
            (session_id, up_to_turn_idx),
        )
        deleted = cur.rowcount
    _log.info(
        "session_spool.turns_acked",
        extra={
            "event": "session_spool.turns_acked",
            "session_id": session_id,
            "up_to_turn_idx": up_to_turn_idx,
            "deleted_count": deleted,
        },
    )
    return deleted


# ─────────────────────────────────────────────────────────────────────────────
# Spool metadata
# ─────────────────────────────────────────────────────────────────────────────

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def get_spool_meta(db_path: Path) -> Dict[str, Any]:
    """Return the single spool_meta row as a dict."""
    with _open_db(db_path) as conn:
        cur = conn.execute("SELECT * FROM spool_meta WHERE id = 1")
        row = cur.fetchone()
        if row is None:
            return {
                "last_successful_flush_at": None,
                "next_retry_after": None,
                "last_attempt_error": None,
                "last_attempt_id": None,
            }
        return dict(row)


def set_flush_success(db_path: Path, attempt_id: str) -> None:
    """Record a successful flush — clears backoff state."""
    now_iso = _now_iso()
    with _open_db(db_path) as conn:
        conn.execute(
            """
            UPDATE spool_meta
               SET last_successful_flush_at = ?,
                   next_retry_after          = NULL,
                   last_attempt_error        = NULL,
                   last_attempt_id           = ?
             WHERE id = 1
            """,
            (now_iso, attempt_id),
        )
    _log.info(
        "session_spool.flush_success",
        extra={
            "event": "session_spool.flush_success",
            "attempt_id": attempt_id,
            "ts": now_iso,
        },
    )


def set_flush_failure(
    db_path: Path,
    attempt_id: str,
    error: str,
    backoff_attempt: int,
) -> None:
    """Record a failed flush — set backoff state.

    backoff_attempt is 0-indexed: 0→30s, 1→2m, 2→10m, 3+→no scheduled retry.
    """
    if backoff_attempt < len(_BACKOFF_SEQUENCE):
        delay = _BACKOFF_SEQUENCE[backoff_attempt]
    else:
        delay = None

    now_dt = datetime.now(timezone.utc)
    if delay is not None:
        next_retry = (now_dt + timedelta(seconds=delay)).isoformat()
    else:
        next_retry = None

    with _open_db(db_path) as conn:
        conn.execute(
            """
            UPDATE spool_meta
               SET next_retry_after  = ?,
                   last_attempt_error = ?,
                   last_attempt_id    = ?
             WHERE id = 1
            """,
            (next_retry, error[:500], attempt_id),
        )
    _log.warning(
        "session_spool.flush_failure",
        extra={
            "event": "session_spool.flush_failure",
            "attempt_id": attempt_id,
            "backoff_attempt": backoff_attempt,
            "next_retry_after": next_retry,
            "error": error[:200],
        },
    )


# ─────────────────────────────────────────────────────────────────────────────
# Trigger evaluation
# ─────────────────────────────────────────────────────────────────────────────

def should_flush(
    db_path: Path,
    session_id: str,
    is_session_start: bool = False,
    last_flushed_turn_idx: int = -1,
) -> Tuple[bool, str]:
    """Evaluate whether a flush should fire now.

    Returns (True, reason) if flush should proceed, (False, reason) otherwise.
    """
    now_dt = datetime.now(timezone.utc)
    meta = get_spool_meta(db_path)

    # ── Backoff gate — respect next_retry_after ───────────────────────────────
    next_retry_str = meta.get("next_retry_after")
    if next_retry_str:
        try:
            next_retry = datetime.fromisoformat(next_retry_str)
            if now_dt < next_retry:
                return False, f"backoff_wait_until={next_retry_str}"
        except ValueError:
            pass  # malformed timestamp — ignore backoff

    # ── Compute elapsed since last flush (clamp negative to 0) ───────────────
    last_flush_str = meta.get("last_successful_flush_at")
    elapsed_seconds: float = 0.0
    if last_flush_str:
        try:
            last_flush = datetime.fromisoformat(last_flush_str)
            delta = (now_dt - last_flush).total_seconds()
            elapsed_seconds = max(0.0, delta)  # clamp negative (clock skew)
        except ValueError:
            elapsed_seconds = float("inf")
    else:
        elapsed_seconds = float("inf")

    # ── Pending USER message count ────────────────────────────────────────────
    user_count = count_user_turns_since_flush(db_path, session_id, last_flushed_turn_idx)

    if user_count == 0 and not is_session_start:
        return False, "no_pending_user_turns"

    # ── Debounce: within 10 min AND fewer than 5 new user msgs → skip ────────
    within_debounce = elapsed_seconds < (_DEBOUNCE_MINUTES * 60)
    if within_debounce and user_count < _DEBOUNCE_MIN_MSGS:
        return False, f"debounce_active elapsed={elapsed_seconds:.0f}s user_msgs={user_count}"

    # ── Trigger 1: 20+ user messages ─────────────────────────────────────────
    if user_count >= _USER_MSG_THRESHOLD:
        return True, f"user_msg_threshold user_msgs={user_count}"

    # ── Trigger 2: session start with pending turns ───────────────────────────
    if is_session_start and user_count > 0:
        return True, f"session_start pending_user_msgs={user_count}"

    # ── Trigger 3: 4-hour idle cron ───────────────────────────────────────────
    if elapsed_seconds >= (_IDLE_CRON_HOURS * 3600) and user_count > 0:
        return True, f"idle_cron elapsed={elapsed_seconds:.0f}s user_msgs={user_count}"

    return False, f"no_trigger user_msgs={user_count} elapsed={elapsed_seconds:.0f}s"


# ─────────────────────────────────────────────────────────────────────────────
# 409 trim-and-retry helper
# ─────────────────────────────────────────────────────────────────────────────

def trim_to_suffix(
    db_path: Path,
    session_id: str,
    server_acked_through: int,
) -> int:
    """Handle a 409 response: delete rows already acked on server, return new count.

    Per §2 last paragraph: the server returned acked_through_turn_idx=N, meaning
    it already has all turns <= N. Delete those local rows (they are duplicates
    of what the server holds) so the next attempt starts at N+1.

    Returns the count of remaining pending turns after trim.
    """
    deleted = delete_acked_turns(db_path, session_id, server_acked_through)
    remaining = get_pending_turns(db_path, session_id, after_turn_idx=server_acked_through)
    _log.info(
        "session_spool.trim_on_409",
        extra={
            "event": "session_spool.trim_on_409",
            "session_id": session_id,
            "server_acked_through": server_acked_through,
            "deleted_count": deleted,
            "remaining_count": len(remaining),
        },
    )
    return len(remaining)


# ─────────────────────────────────────────────────────────────────────────────
# High-level flush helper
# ─────────────────────────────────────────────────────────────────────────────

def build_flush_payload(
    db_path: Path,
    session_id: str,
    user_id: str,
    after_turn_idx: int = -1,
) -> Optional[Dict[str, Any]]:
    """Build the POST payload for /ingest/selph/session.

    Returns None if there are no pending turns to flush.
    Stamps all included turns with last_attempt_at and a fresh attempt_id.
    """
    turns = get_pending_turns(db_path, session_id, after_turn_idx=after_turn_idx)
    if not turns:
        return None

    attempt_id = str(uuid.uuid4())
    turn_idxs = [t["turn_idx"] for t in turns]
    stamp_attempt(db_path, session_id, attempt_id, turn_idxs)

    payload = {
        "user_id": user_id,
        "session_id": session_id,
        "attempt_id": attempt_id,
        "turns": [
            {
                "turn_idx": t["turn_idx"],
                "role": t["role"],
                "content": t["content"],
                "ts": t["ts"],
            }
            for t in turns
        ],
    }
    _log.info(
        "session_spool.payload_built",
        extra={
            "event": "session_spool.payload_built",
            "session_id": session_id,
            "attempt_id": attempt_id,
            "turn_count": len(turns),
            "first_turn_idx": turns[0]["turn_idx"],
            "last_turn_idx": turns[-1]["turn_idx"],
        },
    )
    return payload


def on_flush_success(
    db_path: Path,
    session_id: str,
    attempt_id: str,
    server_acked_through: int,
) -> None:
    """Process a successful flush response from the server.

    Atomically deletes the acked turns and records the success timestamp.
    """
    delete_acked_turns(db_path, session_id, up_to_turn_idx=server_acked_through)
    set_flush_success(db_path, attempt_id)


def on_flush_failure(
    db_path: Path,
    attempt_id: str,
    error: str,
    backoff_attempt: int,
) -> None:
    """Process a flush failure — persists backoff state."""
    set_flush_failure(db_path, attempt_id, error, backoff_attempt)


def on_flush_409(
    db_path: Path,
    session_id: str,
    server_acked_through: int,
) -> int:
    """Handle a 409 conflict — trim already-acked turns and return remaining count."""
    return trim_to_suffix(db_path, session_id, server_acked_through)


# ─────────────────────────────────────────────────────────────────────────────
# Force-flush (session_close immediate-flush — §12.3 / §13a item #7)
# ─────────────────────────────────────────────────────────────────────────────


def force_flush_payload(
    workspace: Path,
    session_id: str,
    user_id: str,
    after_turn_idx: int = -1,
) -> Optional[Dict[str, Any]]:
    """Build a flush payload bypassing should_flush/debounce/threshold checks.

    Intended for session_close events where the harness wants an immediate
    flush regardless of message count or debounce state.

    Reuses build_flush_payload internally — stamps attempt_id and
    last_attempt_at on included turns.

    Returns:
        The POST payload dict (same shape as build_flush_payload), or None
        when there are no pending turns to flush.
    """
    db_path = _spool_db_path(workspace)
    payload = build_flush_payload(
        db_path,
        session_id=session_id,
        user_id=user_id,
        after_turn_idx=after_turn_idx,
    )
    if payload is None:
        _log.info(
            "session_spool.force_flush_noop",
            extra={
                "event": "session_spool.force_flush_noop",
                "session_id": session_id,
                "reason": "no_pending_turns",
            },
        )
        return None

    _log.info(
        "session_spool.force_flush_payload_built",
        extra={
            "event": "session_spool.force_flush_payload_built",
            "session_id": session_id,
            "turn_count": len(payload.get("turns", [])),
        },
    )
    return payload


# ─────────────────────────────────────────────────────────────────────────────
# Runtime hook wiring (called from external hook points; does not alter
# _runtime.py's core state machine)
# ─────────────────────────────────────────────────────────────────────────────

def on_session_turn(
    workspace: Path,
    session_id: str,
    turn_idx: int,
    role: str,
    content: str,
    ts: Optional[str] = None,
) -> None:
    """Hook: called whenever a conversation turn is observed.

    Appends the turn to the local spool. Callers should then call
    evaluate_trigger() to decide whether to flush.
    """
    db_path = _spool_db_path(workspace)
    ts_str = ts or _now_iso()
    try:
        append_turn(
            db_path,
            session_id=session_id,
            turn_idx=turn_idx,
            role=role,
            content=content,
            ts=ts_str,
        )
    except Exception as exc:
        _log.warning(
            "session_spool.append_failed",
            extra={
                "event": "session_spool.append_failed",
                "session_id": session_id,
                "turn_idx": turn_idx,
                "error": str(exc)[:200],
            },
        )


def evaluate_trigger(
    workspace: Path,
    session_id: str,
    is_session_start: bool = False,
    last_flushed_turn_idx: int = -1,
) -> Tuple[bool, str]:
    """Hook: evaluate whether a flush should fire now.

    Returns (should_flush, reason_str). Callers use this to decide whether
    to call the actual HTTP flush. Does not perform the flush itself.
    """
    db_path = _spool_db_path(workspace)
    try:
        return should_flush(
            db_path,
            session_id=session_id,
            is_session_start=is_session_start,
            last_flushed_turn_idx=last_flushed_turn_idx,
        )
    except Exception as exc:
        _log.warning(
            "session_spool.trigger_eval_failed",
            extra={
                "event": "session_spool.trigger_eval_failed",
                "session_id": session_id,
                "error": str(exc)[:200],
            },
        )
        return False, f"trigger_eval_error: {exc}"
