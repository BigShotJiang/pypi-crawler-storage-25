"""The Runtime class — async binding watcher + persona-call dispatcher.

Held intentionally as one file despite exceeding the 400/600 adapter
size targets in `.claude/rules/code-structure.md`. The Runtime is one
external system (the late-bound binding watcher); per the per-role
table's `selph_shared/llm/client.py` precedent, cohesion outweighs
line count when a class is one indivisible concern.

Module-level helpers (cache-index I/O, telemetry rotation, fingerprint
validation, path resolution, protocol typing) live in sibling
`_*.py` modules; this file is class-only.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path
from typing import Any, Callable, Optional, Union

from selph_mcp.adapters.binding import (
    BoundParams,
    LateBoundSlot,
    LifecycleManager,
    MemoMap,
    SessionMemo,
    UnboundResult,
    UnboundState,
    parse_predicate,
    resolve,
)

from ._cache_index import (
    _load_cache_index,
    _save_cache_index,
    enforce_cache_limits,
    purge_stale_cache,
)
from ._paths import _cache_dir
from ._protocol import PersonaCallProtocol
from ._shared import _ADAPTER_CONTRACT_VERSION, _PURGE_INTERVAL_SECONDS, _log
from ._telemetry import _append_telemetry
from ._fingerprint import _safe_cache_file


class Runtime:
    """Async watcher + binding wiring for one workflow run.

    §3.3.a–§3.3.c of the implementation plan.

    Usage::

        rt = Runtime(
            workspace=Path("/my/project"),
            workflow_id="my_workflow",
            skill_version="1.0.0",
            persona_call=my_transport_callable,
        )
        await rt.start(workflow_spec, initial_state)
        # On each state mutation:
        rt.workflow_state_changed("workflow.state.topic", "python")
        # Workflow-callable primitives:
        rt.freeze("my_alias")
        rt.session_boundary()
        # Persona call with full lookup protocol:
        result = await rt.call_persona_tool("get_context", params, consumer)

    Transport agnosticism
    ---------------------
    ``persona_call`` is a ``Callable[[tool, params], dict]`` injected at
    init time.  ``runtime.py`` never imports an HTTP client — the caller
    decides how to reach the Selph MCP server.
    """

    def __init__(
        self,
        *,
        workspace: Path,
        workflow_id: str,
        skill_version: str,
        persona_call: Union[PersonaCallProtocol, Callable[[str, dict[str, Any]], dict[str, Any]]],
    ) -> None:
        # Path-traversal defense: validate workflow_id BEFORE any filesystem
        # use. Mirrors the check in ``bootstrap.install_workflow``; keeps
        # runtime.py and bootstrap.py aligned on a single allow-list regex.
        from ..state_schema import validate_workflow_id
        validate_workflow_id(workflow_id)

        self._workspace = workspace
        self._workflow_id = workflow_id
        self._skill_version = skill_version
        self._persona_call = persona_call

        self._lifecycle = LifecycleManager()
        self._memo = MemoMap()
        self._session_memo = SessionMemo()

        # Parsed workflow spec — set in start()
        self._workflow_spec: Any = None
        self._workflow_state: dict[str, Any] = {}

        # Server contract versions learned from handshake (§3.6)
        self._server_versions: dict[str, Any] = {}

        # Resolved context by alias — populated by start() and state callbacks
        self._resolved_context: dict[str, Any] = {}

        # Stale-cache purge throttle state (High 1 fix — §3.2)
        self._last_purge_ts: float = 0.0

        _log.info(
            "runtime created",
            extra={
                "event": "adapter.runtime.created",
                "workflow_id": workflow_id,
                "skill_version": skill_version,
            },
        )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _invoke_persona_call(
        self,
        tool: str,
        params: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, str]]:
        """Invoke the underlying ``persona_call`` in a protocol-agnostic way.

        Accepts both the new ``PersonaCallProtocol`` returning ``(body, headers)``
        and the legacy ``Callable[[str, dict], dict]`` returning a plain dict.

        Also sends ``X-Selph-Adapter-Contract-Version`` when the protocol
        supports the ``adapter_version`` keyword (§3.6 adapter-side rule 1).

        Extracts and caches ``X-Selph-Server-Contract-Versions`` from the
        returned headers on every call (§3.6 adapter-side rule 2).
        """
        try:
            # Attempt new-protocol call with adapter_version kwarg.
            raw = self._persona_call(
                tool,
                params,
                adapter_version=_ADAPTER_CONTRACT_VERSION,  # type: ignore[call-arg]
            )
        except TypeError:
            # Legacy callable — does not accept keyword args.
            raw = self._persona_call(tool, params)  # type: ignore[call-arg]

        if isinstance(raw, tuple):
            body, headers = raw
        else:
            body, headers = raw, {}

        # Parse and cache server versions if present.
        versions_hdr = headers.get("X-Selph-Server-Contract-Versions")
        if versions_hdr and not self._server_versions:
            try:
                self._server_versions = json.loads(versions_hdr)
            except Exception as exc:
                _log.warning(
                    "failed to parse X-Selph-Server-Contract-Versions header",
                    extra={
                        "event": "adapter.contract.version_parse_failed",
                        "error_type": type(exc).__name__,
                        "error": str(exc)[:200],
                    },
                )

        return body, headers

    def _check_server_version(self) -> None:
        """Raise RuntimeError if server adapter version is older than ours (§3.6).

        Only raises when we have concrete evidence (non-empty ``_server_versions``
        with a ``harness_adapter_version`` key) that the server is older.  If
        the header was absent, we log a WARNING but do not crash.
        """
        if not self._server_versions:
            _log.warning(
                "server contract versions unknown; proceeding without version check",
                extra={"event": "adapter.contract.unknown_server_version"},
            )
            return

        server_adapter_v = self._server_versions.get("harness_adapter_version")
        if server_adapter_v is None:
            _log.warning(
                "server contract versions header missing harness_adapter_version",
                extra={"event": "adapter.contract.unknown_server_version"},
            )
            return

        if int(server_adapter_v) < _ADAPTER_CONTRACT_VERSION:
            raise RuntimeError(
                f"Server harness_adapter_version={server_adapter_v} is older than "
                f"this adapter's compiled-in version={_ADAPTER_CONTRACT_VERSION}. "
                "Upgrade the Selph server before using this adapter version."
            )

    async def start(
        self,
        workflow_spec: Any,
        workflow_state: dict[str, Any],
    ) -> None:
        """Initialize the runtime for a workflow run.

        - Resolves ``context.declared`` blocks eagerly via real Selph calls.
        - Processes each ``context.late_bound`` block per ``bind_on`` policy.
          ``bind_on="run_start"`` → resolve + call Selph immediately; raises
          ``RuntimeError`` if any placeholder is unresolved.
          ``bind_on="on_available"`` → registers a resolver; binds on the
          first ``workflow_state_changed`` where all placeholders have values.
        - Validates server contract version via version negotiation (§3.6).

        Args:
            workflow_spec: A parsed ``WorkflowSpec`` instance.
            workflow_state: Initial harness workflow state dict.
        """
        self._workflow_spec = workflow_spec
        self._workflow_state = dict(workflow_state)

        _log.info(
            "runtime start",
            extra={
                "event": "adapter.runtime.start",
                "workflow_id": self._workflow_id,
            },
        )

        # ------------------------------------------------------------------ #
        # Server version preflight (§3.6) — must run BEFORE any other call   #
        # so the adapter can fail fast if the server is older, even when     #
        # the workflow has no declared context and no run_start late-bound   #
        # entries. Use ``what_changed`` as the cheapest handshake — it is    #
        # budget-free and returns the contract-version header.               #
        # ------------------------------------------------------------------ #
        try:
            self._invoke_persona_call("what_changed", {})
        except Exception as exc:
            _log.warning(
                "server version preflight call failed; will retry from declared context",
                extra={
                    "event": "adapter.runtime.version_preflight_failed",
                    "workflow_id": self._workflow_id,
                    "error_type": type(exc).__name__,
                    "error": str(exc)[:200],
                },
            )
        # Fail-fast version check — runs even when the rest of start() has
        # nothing to do. If the server is older than the adapter's compiled
        # contract version, we raise RuntimeError per §3.6.
        if self._server_versions:
            self._check_server_version()

        # ------------------------------------------------------------------ #
        # Declared context — eager Selph calls (§3.3 "same semantics as      #
        # today's bootstrap")                                                  #
        # ------------------------------------------------------------------ #
        declared_ctx = getattr(getattr(workflow_spec, "context", None), "declared", None) or []
        for decl in declared_ctx:
            alias = getattr(decl, "alias", None) or str(id(decl))
            tool = getattr(decl, "tool", None)
            params = dict(getattr(decl, "params", None) or {})
            depth = getattr(decl, "depth", None)

            _log.info(
                "resolving declared context entry",
                extra={
                    "event": "adapter.binding.declared",
                    "workflow_id": self._workflow_id,
                    "alias": alias,
                    "tool": tool,
                },
            )

            if tool:
                try:
                    payload = await self.call_persona_tool(
                        tool,
                        params,
                        consumer=None,
                        depth=depth,
                        alias=alias,
                        call_site="declared_context",
                    )
                    self._resolved_context[alias] = payload
                    fp = (payload.get("meta") or {}).get("query_fingerprint")
                    if fp:
                        self._lifecycle.record_fingerprint(alias, fp)
                    _log.info(
                        "declared context entry resolved",
                        extra={
                            "event": "adapter.binding.declared.resolved",
                            "workflow_id": self._workflow_id,
                            "alias": alias,
                            "fingerprint": fp,
                        },
                    )
                except Exception as exc:
                    _log.warning(
                        "declared context entry failed; continuing",
                        extra={
                            "event": "adapter.binding.declared.failed",
                            "workflow_id": self._workflow_id,
                            "alias": alias,
                            "error_type": type(exc).__name__,
                            "error": str(exc)[:200],
                        },
                    )

        # ------------------------------------------------------------------ #
        # Version check (§3.6) — second pass in case the preflight failed    #
        # but a declared-context call later populated ``_server_versions``.  #
        # ------------------------------------------------------------------ #
        self._check_server_version()

        # ------------------------------------------------------------------ #
        # Late-bound context                                                   #
        # ------------------------------------------------------------------ #
        late_bound = getattr(getattr(workflow_spec, "context", None), "late_bound", None) or []
        run_start_unresolved: list[str] = []

        for entry in late_bound:
            alias = entry.alias
            # Pre-parse the rebind_trigger expression if present.
            trigger_expr = None
            if entry.rebind_trigger is not None:
                try:
                    trigger_expr = parse_predicate(entry.rebind_trigger)
                except Exception as exc:
                    _log.warning(
                        "rebind_trigger parse failed at start; slot will stay unbound",
                        extra={
                            "event": "adapter.binding.trigger_parse_failed",
                            "workflow_id": self._workflow_id,
                            "alias": alias,
                            "error": str(exc)[:200],
                        },
                    )

            slot = LateBoundSlot(
                alias=alias,
                template=entry,
                rebind_trigger_expr=trigger_expr,
            )
            self._lifecycle.register(slot)

            if entry.bind_on == "run_start":
                result = resolve(entry, self._workflow_state)
                if isinstance(result, BoundParams):
                    # Actually call Selph with the resolved params (§3.3).
                    try:
                        payload = await self.call_persona_tool(
                            entry.tool,
                            result.params,
                            consumer=None,
                            alias=alias,
                            call_site="late_bound_run_start",
                        )
                        self._resolved_context[alias] = payload
                        fp = (payload.get("meta") or {}).get("query_fingerprint")
                        # Advance lifecycle state via on_state_change FIRST so
                        # the slot transitions Unbound → Bound, then stamp the
                        # server-returned fingerprint onto the Bound state.
                        # (Calling record_fingerprint on an Unbound slot is a
                        # no-op — order matters for freeze/rebind semantics.)
                        self._lifecycle.on_state_change("__init__", None, self._workflow_state)
                        if fp:
                            self._lifecycle.record_fingerprint(alias, fp)
                        _log.info(
                            "late-bound slot resolved at run_start",
                            extra={
                                "event": "adapter.binding.bound",
                                "workflow_id": self._workflow_id,
                                "alias": alias,
                                "fingerprint": fp,
                            },
                        )
                    except Exception as exc:
                        _log.warning(
                            "late-bound run_start Selph call failed",
                            extra={
                                "event": "adapter.binding.bound.call_failed",
                                "workflow_id": self._workflow_id,
                                "alias": alias,
                                "error_type": type(exc).__name__,
                                "error": str(exc)[:200],
                            },
                        )
                        run_start_unresolved.append(alias)
                else:
                    run_start_unresolved.append(alias)

            # bind_on="on_available" → already registered; will resolve on
            # first workflow_state_changed where all placeholders have values.

        if run_start_unresolved:
            raise RuntimeError(
                f"Late-bound slots with bind_on='run_start' could not resolve at "
                f"workflow init: {run_start_unresolved}. Every placeholder must have "
                "a non-null, non-empty value at workflow start."
            )

        _log.info(
            "runtime start complete",
            extra={
                "event": "adapter.runtime.start_complete",
                "workflow_id": self._workflow_id,
                "late_bound_count": len(late_bound),
                "declared_count": len(declared_ctx),
            },
        )

    # ------------------------------------------------------------------
    # State change callback
    # ------------------------------------------------------------------

    def workflow_state_changed(self, path: str, value: Any) -> None:
        """Re-evaluate registered late-bound slots against the updated state.

        Single-threaded per run (§2.1 semantics). Called by SKILL.md and
        the workflow loader on every harness state mutation.

        For every slot that newly binds (``on_available``) or rebinds
        (``rebind_on_change``), this method schedules a Selph persona call
        using ``asyncio.create_task`` so the async call does not block the
        synchronous state-change callback. The caller must be in a running
        event loop for the tasks to execute.

        Args:
            path: Dot-separated workflow-state path that changed.
            value: New value at ``path``.
        """
        # Update local state snapshot.
        parts = path.split(".")
        node = self._workflow_state
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        node[parts[-1]] = value

        transitioned = self._lifecycle.on_state_change(path, value, self._workflow_state)

        for slot in transitioned:
            if isinstance(slot.state, type(None)):
                continue
            from selph_mcp.adapters.binding.lifecycle import Bound, Frozen  # noqa: PLC0415
            if isinstance(slot.state, Bound):
                _log.info(
                    "late-bound slot bound",
                    extra={
                        "event": "adapter.binding.bound",
                        "workflow_id": self._workflow_id,
                        "alias": slot.alias,
                        "fingerprint": slot.state.fingerprint,
                    },
                )
                # Resolve and call Selph for the newly-bound slot (§3.3).
                result = resolve(slot.template, self._workflow_state)
                if isinstance(result, BoundParams):
                    alias = slot.alias
                    resolved_params = result.params

                    async def _call_and_store(
                        _alias: str = alias,
                        _tool: str = slot.template.tool,
                        _params: dict[str, Any] = resolved_params,
                    ) -> None:
                        try:
                            payload = await self.call_persona_tool(
                                _tool,
                                _params,
                                consumer=None,
                                alias=_alias,
                                call_site="late_bound_on_available",
                            )
                            self._resolved_context[_alias] = payload
                            fp = (payload.get("meta") or {}).get("query_fingerprint")
                            if fp:
                                self._lifecycle.record_fingerprint(_alias, fp)
                            _log.info(
                                "late-bound on_available resolved",
                                extra={
                                    "event": "adapter.binding.bound.resolved",
                                    "workflow_id": self._workflow_id,
                                    "alias": _alias,
                                    "fingerprint": fp,
                                },
                            )
                        except Exception as exc:
                            _log.warning(
                                "late-bound on_available Selph call failed",
                                extra={
                                    "event": "adapter.binding.bound.call_failed",
                                    "workflow_id": self._workflow_id,
                                    "alias": _alias,
                                    "error_type": type(exc).__name__,
                                    "error": str(exc)[:200],
                                },
                            )

                    try:
                        asyncio.get_event_loop().create_task(_call_and_store())
                    except RuntimeError:
                        # No running loop — caller is sync; log and skip.
                        _log.warning(
                            "no event loop; skipping async Selph call for on_available binding",
                            extra={
                                "event": "adapter.binding.no_event_loop",
                                "alias": slot.alias,
                            },
                        )

            elif isinstance(slot.state, Frozen):
                _log.info(
                    "late-bound slot frozen",
                    extra={
                        "event": "adapter.binding.frozen",
                        "workflow_id": self._workflow_id,
                        "alias": slot.alias,
                        "fingerprint": slot.state.fingerprint,
                    },
                )

    # ------------------------------------------------------------------
    # Workflow-callable primitives (§2.5.1)
    # ------------------------------------------------------------------

    def freeze(self, alias: str) -> None:
        """Schedule a freeze for the named slot. Takes effect at the next evaluation boundary.

        §2.5.1 — delegates to ``LifecycleManager.freeze(alias)``.
        """
        self._lifecycle.freeze(alias)
        _log.info(
            "freeze scheduled",
            extra={
                "event": "adapter.binding.frozen",
                "workflow_id": self._workflow_id,
                "alias": alias,
            },
        )

    def session_boundary(self) -> None:
        """Flush session memoization independently of writeback.

        §2.5.1 — delegates to ``SessionMemo.session_boundary()``.
        """
        self._session_memo.session_boundary()
        _log.info(
            "session boundary",
            extra={
                "event": "adapter.session.boundary",
                "workflow_id": self._workflow_id,
            },
        )

    # ------------------------------------------------------------------
    # Lookup protocol (§3.1)
    # ------------------------------------------------------------------

    async def call_persona_tool(
        self,
        tool: str,
        params: dict[str, Any],
        consumer: Any,
        *,
        depth: Optional[str] = None,
        alias: Optional[str] = None,
        call_site: str = "unknown",
    ) -> dict[str, Any]:
        """Call a persona tool following the §3.1 lookup protocol.

        Steps:
        1. Check session memoization (ephemeral, depth-ceilinged).
        2. Check call-site MemoMap for a known fingerprint.
        3. If ``SELPH_GET_FINGERPRINT_AVAILABLE=1``, preflight via
           ``get_fingerprint``, check ``.selph/cache/<fp>.json``.
        4. On miss: call the full persona tool, persist cache entry,
           update index, record in MemoMap.

        Args:
            tool: Persona MCP tool name.
            params: Tool parameters (fully resolved — no placeholders).
            consumer: Authenticated consumer (passed to ``persona_call``
                injected callable if it needs it; not used directly here).
            depth: Request depth string (optional). Used for session-memo
                depth-ceiling enforcement.
            alias: Template alias for MemoMap keying. Defaults to ``tool``.
            call_site: Human-readable label for telemetry.

        Returns:
            The full persona tool response dict.
        """
        effective_alias = alias or tool
        effective_depth = depth or "brief"

        _log.info(
            "persona tool call entry",
            extra={
                "event": "adapter.runtime.persona_call.entry",
                "workflow_id": self._workflow_id,
                "tool": tool,
                "alias": effective_alias,
                "depth": effective_depth,
                "call_site": call_site,
            },
        )

        # §3.2 contract: purge stale cache before ANY cache read.
        # Throttled to at most once per _PURGE_INTERVAL_SECONDS per Runtime
        # instance so we don't call what_changed on every call in a fast loop.
        now = time.monotonic()
        if (now - self._last_purge_ts) >= _PURGE_INTERVAL_SECONDS:
            try:
                purge_stale_cache(self._workspace, self._persona_call)
            except Exception as exc:
                _log.warning(
                    "purge_stale_cache raised unexpectedly; continuing",
                    extra={
                        "event": "adapter.cache.coherence_check.error",
                        "error_type": type(exc).__name__,
                        "error": str(exc)[:200],
                    },
                )
            self._last_purge_ts = now

        # Step 1: session memoization check
        session_hit = self._session_memo.get(tool, params, effective_depth)
        if session_hit is not None:
            _log.info(
                "persona tool call resolved from session memo",
                extra={
                    "event": "adapter.runtime.persona_call.session_hit",
                    "workflow_id": self._workflow_id,
                    "tool": tool,
                    "alias": effective_alias,
                },
            )
            _append_telemetry(
                self._workspace,
                self._workflow_id,
                tool,
                params,
                "session_memo",
                None,
                call_site,
            )
            return session_hit

        # Step 2: MemoMap check (known fingerprint for this call-site key)
        known_fp = self._memo.get(
            self._workflow_id,
            self._skill_version,
            effective_alias,
            params,
        )
        cache_dir = _cache_dir(self._workspace)

        if known_fp:
            cache_file = _safe_cache_file(self._workspace, known_fp)
            if cache_file is not None and cache_file.exists():
                try:
                    payload = json.loads(cache_file.read_text(encoding="utf-8"))
                    _log.info(
                        "persona tool call resolved from disk cache (memo hit)",
                        extra={
                            "event": "adapter.runtime.persona_call.memo_hit",
                            "workflow_id": self._workflow_id,
                            "tool": tool,
                            "fingerprint": known_fp,
                        },
                    )
                    _append_telemetry(
                        self._workspace,
                        self._workflow_id,
                        tool,
                        params,
                        "memo_cache",
                        known_fp,
                        call_site,
                    )
                    return payload
                except Exception as exc:
                    _log.warning(
                        "disk cache read failed; falling through to live call",
                        extra={
                            "event": "adapter.runtime.persona_call.cache_read_failed",
                            "fingerprint": known_fp,
                            "error_type": type(exc).__name__,
                        },
                    )

        # Step 3: optional get_fingerprint preflight
        fingerprint: Optional[str] = None
        if os.getenv("SELPH_GET_FINGERPRINT_AVAILABLE") == "1":
            try:
                fp_body, _fp_headers = self._invoke_persona_call(
                    "get_fingerprint", {"tool": tool, "params": params}
                )
                fp_result = fp_body
                fingerprint = (fp_result.get("data") or {}).get("query_fingerprint")
                if fingerprint:
                    cache_file = _safe_cache_file(self._workspace, fingerprint)
                    if cache_file is not None and cache_file.exists():
                        try:
                            payload = json.loads(cache_file.read_text(encoding="utf-8"))
                            _log.info(
                                "persona tool call resolved from disk cache (fingerprint preflight)",
                                extra={
                                    "event": "adapter.runtime.persona_call.fp_cache_hit",
                                    "workflow_id": self._workflow_id,
                                    "tool": tool,
                                    "fingerprint": fingerprint,
                                },
                            )
                            self._memo.put(
                                self._workflow_id,
                                self._skill_version,
                                effective_alias,
                                params,
                                fingerprint,
                            )
                            _append_telemetry(
                                self._workspace,
                                self._workflow_id,
                                tool,
                                params,
                                "fp_cache",
                                fingerprint,
                                call_site,
                            )
                            return payload
                        except Exception:
                            pass  # fall through to live call
            except Exception as exc:
                _log.warning(
                    "get_fingerprint preflight failed; falling through to live call",
                    extra={
                        "event": "adapter.runtime.persona_call.fp_preflight_failed",
                        "tool": tool,
                        "error_type": type(exc).__name__,
                    },
                )

        # Step 4: live Selph call
        response, _live_headers = self._invoke_persona_call(tool, params)

        # Extract fingerprint and dep keys from response meta
        meta = response.get("meta") or {}
        returned_fp: Optional[str] = meta.get("query_fingerprint")
        dep_keys: list[str] = meta.get("dependency_keys") or []

        # Persist to disk cache — only if fingerprint passes the strict
        # shape check (path-traversal defense: server-returned strings never
        # touch the filesystem unvalidated).
        if returned_fp:
            cache_file = _safe_cache_file(self._workspace, returned_fp)
            if cache_file is None:
                _log.warning(
                    "server-returned fingerprint failed safety check; cache skipped",
                    extra={
                        "event": "adapter.runtime.persona_call.unsafe_fingerprint",
                        "fingerprint": returned_fp[:80],
                        "tool": tool,
                    },
                )
            else:
                cache_dir.mkdir(parents=True, exist_ok=True)
                try:
                    cache_file.write_text(
                        json.dumps(response, ensure_ascii=False, indent=2),
                        encoding="utf-8",
                    )
                except OSError as exc:
                    _log.warning(
                        "cache write failed",
                        extra={
                            "event": "adapter.runtime.persona_call.cache_write_failed",
                            "fingerprint": returned_fp,
                            "error_type": type(exc).__name__,
                        },
                    )

                # Update _index.json
                if dep_keys:
                    index = _load_cache_index(self._workspace)
                    index[returned_fp] = dep_keys
                    _save_cache_index(self._workspace, index)

            # Record in MemoMap
            self._memo.put(
                self._workflow_id,
                self._skill_version,
                effective_alias,
                params,
                returned_fp,
            )

        # Session memo (depth-ceilinged — brief/targeted only)
        if effective_depth in ("brief", "targeted"):
            try:
                self._session_memo.put(tool, params, effective_depth, response)
            except ValueError:
                pass  # Non-cacheable depth — should not occur given the guard above

        _append_telemetry(
            self._workspace,
            self._workflow_id,
            tool,
            params,
            "live",
            returned_fp,
            call_site,
        )

        _log.info(
            "persona tool call complete",
            extra={
                "event": "adapter.runtime.persona_call.complete",
                "workflow_id": self._workflow_id,
                "tool": tool,
                "alias": effective_alias,
                "fingerprint": returned_fp,
            },
        )
        return response

    # ------------------------------------------------------------------
    # Writeback flush hooks
    # ------------------------------------------------------------------

    def on_writeback(self) -> None:
        """Flush memo maps after ``observe_session`` or ``correct``.

        Must be called after any writeback completes per §2.5
        (session memoization flush on writeback).
        """
        self._memo.flush()
        self._session_memo.flush()
        _log.info(
            "writeback flush complete",
            extra={
                "event": "adapter.runtime.writeback_flush",
                "workflow_id": self._workflow_id,
            },
        )

    def purge_stale_cache_now(self) -> int:
        """Force an immediate stale-cache purge, bypassing the TTL throttle.

        Delegates to the module-level ``purge_stale_cache`` function and
        resets the per-instance throttle timestamp so the next scheduled
        call will also run after a full interval.

        Returns:
            Number of cache entries purged.
        """
        count = purge_stale_cache(self._workspace, self._persona_call)
        self._last_purge_ts = time.monotonic()
        _log.info(
            "forced cache purge complete",
            extra={
                "event": "adapter.cache.forced_purge",
                "workflow_id": self._workflow_id,
                "count": count,
            },
        )
        return count

    def get_resolved_context(self, alias: str) -> Optional[dict[str, Any]]:
        """Return the resolved persona response for a context alias, or None.

        Args:
            alias: The declared or late-bound alias name.

        Returns:
            The full PersonaResponse dict, or ``None`` if not yet resolved.
        """
        return self._resolved_context.get(alias)
