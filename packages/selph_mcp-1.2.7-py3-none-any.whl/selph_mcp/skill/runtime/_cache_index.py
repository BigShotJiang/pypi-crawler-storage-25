"""Cache-index I/O and eviction logic (§3.1, §3.2).

Exports:
  _load_cache_index   — read _index.json, returns {} on miss/error
  _save_cache_index   — write _index.json (creates parents as needed)
  enforce_cache_limits — TTL + LRU eviction pass
  purge_stale_cache   — coherence purge driven by what_changed dep keys
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Callable, Union

from ._fingerprint import _is_safe_fingerprint, _safe_cache_file
from ._paths import _cache_dir, _cache_index_path
from ._shared import (
    _CACHE_MAX_ENTRIES_DEFAULT,
    _CACHE_TTL_DAYS_DEFAULT,
    _int_env,
    _log,
)
from ._protocol import PersonaCallProtocol


def _load_cache_index(workspace: Path) -> dict[str, list[str]]:
    """Load ``_index.json`` → {fingerprint: [dep_keys]}. Returns {} on miss/error."""
    path = _cache_index_path(workspace)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        _log.warning(
            "cache index load failed; treating as empty",
            extra={
                "event": "adapter.cache.index_load_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return {}


def _save_cache_index(workspace: Path, index: dict[str, list[str]]) -> None:
    path = _cache_index_path(workspace)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(index, indent=2, sort_keys=True), encoding="utf-8")


def enforce_cache_limits(workspace: Path) -> int:
    """Evict cache entries exceeding TTL or LRU caps.

    Runs after ``purge_stale_cache`` during every coherence cycle. Evicts:
      1. Entries whose file ``mtime`` is older than
         ``SELPH_CACHE_TTL_DAYS`` (default 7 days).
      2. Any remaining surplus over ``SELPH_CACHE_MAX_ENTRIES``
         (default 500), oldest-by-mtime first.

    The ``_index.json`` is updated in lockstep so purged fingerprints
    do not linger in the index.

    Returns:
        Number of cache entries evicted.
    """
    cache_dir = _cache_dir(workspace)
    if not cache_dir.exists():
        return 0

    max_entries = _int_env("SELPH_CACHE_MAX_ENTRIES", _CACHE_MAX_ENTRIES_DEFAULT)
    ttl_days = _int_env("SELPH_CACHE_TTL_DAYS", _CACHE_TTL_DAYS_DEFAULT)
    ttl_seconds = ttl_days * 86400
    now = time.time()

    # Build (fingerprint, path, mtime) list of valid cache files.
    entries: list[tuple[str, Path, float]] = []
    try:
        iterator = list(cache_dir.iterdir())
    except OSError:
        return 0

    unsafe_stems: list[str] = []
    for child in iterator:
        if child.name == "_index.json" or not child.is_file() or child.suffix != ".json":
            continue
        fingerprint = child.stem
        if not _is_safe_fingerprint(fingerprint):
            # Unsafe names should never be on disk, but if one slipped in
            # evict it outright and track it so _index.json can be
            # reconciled in the same cycle.
            try:
                child.unlink()
                unsafe_stems.append(fingerprint)
            except OSError as exc:
                _log.warning(
                    "cache unsafe-name unlink failed",
                    extra={
                        "event": "adapter.cache.unsafe_unlink_failed",
                        "fingerprint": fingerprint[:80],
                        "error_type": type(exc).__name__,
                    },
                )
            continue
        try:
            mtime = child.stat().st_mtime
        except OSError:
            continue
        entries.append((fingerprint, child, mtime))

    evicted: list[str] = []

    if not entries:
        # No safe entries to scan, but unsafe files may still have been
        # unlinked above — reconcile _index.json before returning.
        if unsafe_stems:
            index = _load_cache_index(workspace)
            for fingerprint in unsafe_stems:
                index.pop(fingerprint, None)
            _save_cache_index(workspace, index)
        return len(unsafe_stems)

    # TTL pass — evict stale entries regardless of count.
    fresh: list[tuple[str, Path, float]] = []
    for fingerprint, path, mtime in entries:
        if now - mtime > ttl_seconds:
            try:
                path.unlink()
                evicted.append(fingerprint)
            except OSError as exc:
                _log.warning(
                    "cache TTL unlink failed",
                    extra={
                        "event": "adapter.cache.ttl_unlink_failed",
                        "fingerprint": fingerprint,
                        "error_type": type(exc).__name__,
                    },
                )
        else:
            fresh.append((fingerprint, path, mtime))

    # LRU pass — evict oldest-first until we fit under max_entries.
    if len(fresh) > max_entries:
        fresh.sort(key=lambda row: row[2])  # oldest mtime first
        surplus = len(fresh) - max_entries
        for fingerprint, path, _mtime in fresh[:surplus]:
            try:
                path.unlink()
                evicted.append(fingerprint)
            except OSError as exc:
                _log.warning(
                    "cache LRU unlink failed",
                    extra={
                        "event": "adapter.cache.lru_unlink_failed",
                        "fingerprint": fingerprint,
                        "error_type": type(exc).__name__,
                    },
                )

    # Reconcile _index.json against both legitimate evictions AND any
    # unsafe-named files that we unlinked earlier.
    index_stale_keys = evicted + unsafe_stems
    if index_stale_keys:
        index = _load_cache_index(workspace)
        for fingerprint in index_stale_keys:
            index.pop(fingerprint, None)
        _save_cache_index(workspace, index)
        _log.info(
            "adapter cache limits enforced",
            extra={
                "event": "adapter.cache.limits_enforced",
                "evicted_count": len(evicted),
                "unsafe_evicted_count": len(unsafe_stems),
                "max_entries": max_entries,
                "ttl_days": ttl_days,
            },
        )

    return len(evicted) + len(unsafe_stems)


def purge_stale_cache(
    workspace: Path,
    persona_call: Union[PersonaCallProtocol, Callable[[str, dict[str, Any]], dict[str, Any]]],
) -> int:
    """Purge stale ``.selph/cache/`` entries based on ``what_changed`` dep keys.

    §3.2 implementation. Uses ``OnboardingState.etag_cursor`` (single cursor
    authority — no second cursor file per the plan).

    Args:
        workspace: Workspace root.
        persona_call: Injected callable. Accepts both the legacy
            ``(tool, params) -> dict`` shape and the new
            ``PersonaCallProtocol`` that returns ``(body, headers)``.

    Returns:
        Number of cache entries purged.
    """
    from selph_mcp.skill.bootstrap import detect_state, update_etag_cursor

    state_result = detect_state(workspace)
    if state_result.kind != "returning":
        # Cold start — nothing to purge.
        return 0

    since_cursor: int = state_result.state.etag_cursor

    _log.info(
        "cache coherence check starting",
        extra={
            "event": "adapter.cache.coherence_check.entry",
            "since_cursor": since_cursor,
        },
    )

    # Call what_changed — unwrap body from (body, headers) if new protocol.
    try:
        raw = persona_call("what_changed", {"since_cursor": since_cursor})
        result = raw[0] if isinstance(raw, tuple) else raw
    except Exception as exc:
        _log.warning(
            "what_changed call failed during cache coherence; skipping purge",
            extra={
                "event": "adapter.cache.coherence_check.what_changed_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return 0

    # Extract invalidated_keys and new cursor
    data = result.get("data") or {}
    invalidated_keys: set[str] = set(data.get("invalidated_keys") or [])
    new_cursor: int = int(data.get("cursor") or since_cursor)

    if not invalidated_keys:
        # Advance cursor even if nothing invalidated.
        if new_cursor > since_cursor:
            update_etag_cursor(workspace, new_cursor)
        # Still run TTL+LRU enforcement — upstream may never emit a
        # matching invalidation for a given entry, so the caps must
        # apply every coherence cycle, not only on invalidation events.
        enforce_cache_limits(workspace)
        return 0

    # Load index and purge intersecting entries
    index = _load_cache_index(workspace)
    purged_fps: list[str] = []

    for fingerprint, dep_keys in list(index.items()):
        if invalidated_keys.intersection(dep_keys):
            cache_file = _safe_cache_file(workspace, fingerprint)
            if cache_file is None:
                # Malformed fingerprint in the index — skip unlink, drop the
                # entry so a future write can re-cache under a valid key.
                _log.warning(
                    "skipping unsafe fingerprint in cache index",
                    extra={
                        "event": "adapter.cache.unsafe_fingerprint",
                        "fingerprint": fingerprint[:80],
                    },
                )
                purged_fps.append(fingerprint)
                del index[fingerprint]
                continue
            try:
                if cache_file.exists():
                    cache_file.unlink()
            except OSError as exc:
                _log.warning(
                    "failed to delete stale cache entry",
                    extra={
                        "event": "adapter.cache.entry_delete_failed",
                        "fingerprint": fingerprint,
                        "error_type": type(exc).__name__,
                    },
                )
            purged_fps.append(fingerprint)
            del index[fingerprint]

    if purged_fps:
        _save_cache_index(workspace, index)

    # Advance cursor
    if new_cursor > since_cursor:
        update_etag_cursor(workspace, new_cursor)

    _log.info(
        "cache coherence purge complete",
        extra={
            "event": "adapter.cache.purged",
            "count": len(purged_fps),
            "invalidated_keys_sample": sorted(invalidated_keys)[:5],
            "new_cursor": new_cursor,
        },
    )

    # Follow-up: enforce TTL + LRU caps on whatever remains, so the cache
    # cannot grow without bound even if the server never emits matching
    # invalidation keys for a given entry.
    enforce_cache_limits(workspace)

    return len(purged_fps)
