"""Fingerprint validator — path-traversal defense for server-returned strings.

``query_fingerprint`` flows from the server into a filesystem path segment
(``.selph/cache/<fp>.json``). The server emits
``{tool}:{subject_hint}:{hash12}`` where ``subject_hint`` is derived from
caller-supplied params. To prevent path traversal (e.g. a malicious caller
producing ``entity_id="../../evil"``), we enforce a strict shape BEFORE using
the fingerprint as a filename. Format:

  - ``tool``         : ^[a-z][a-z0-9_]{0,63}$
  - ``subject_hint`` : ^[A-Za-z0-9_.\\-]{0,80}$   (NO '/' or '..')
  - ``hash12``       : ^[0-9a-f]{12}$

Any fingerprint that does not match is ignored for cache-file operations.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Optional

from ._paths import _cache_dir
from ._shared import _log

_FINGERPRINT_RE = re.compile(
    r"^[a-z][a-z0-9_]{0,63}:[A-Za-z0-9_.\-]{0,80}:[0-9a-f]{12}$"
)


def _is_safe_fingerprint(fp: Optional[str]) -> bool:
    """Return True if *fp* matches the strict fingerprint shape.

    Rejects fingerprints containing ``/``, ``\\``, or ``..`` even if the
    regex would incidentally accept them — defense-in-depth.
    """
    if not fp or not isinstance(fp, str):
        return False
    if ".." in fp or "/" in fp or "\\" in fp:
        return False
    return bool(_FINGERPRINT_RE.match(fp))


def _safe_cache_file(workspace: Path, fingerprint: str) -> Optional[Path]:
    """Resolve a cache file path iff the fingerprint is safe AND the
    resolved path stays within ``<workspace>/.selph/cache``.

    Returns None if either check fails.
    """
    if not _is_safe_fingerprint(fingerprint):
        return None
    cache_dir = _cache_dir(workspace)
    candidate = cache_dir / f"{fingerprint}.json"
    try:
        resolved = candidate.resolve()
        cache_root = cache_dir.resolve()
        if not str(resolved).startswith(str(cache_root) + os.sep) and resolved != cache_root:
            return None
    except OSError:
        return None
    return candidate
