"""Path helpers for the runtime sub-package.

Note: there is an analogous ``_cache_dir`` in the ``bootstrap/_paths.py``
sub-module. They are intentionally separate; the runtime version may
differ from the bootstrap version. Do NOT consolidate.
"""

from __future__ import annotations

from pathlib import Path


def _cache_dir(workspace: Path) -> Path:
    return workspace / ".selph" / "cache"


def _cache_index_path(workspace: Path) -> Path:
    return _cache_dir(workspace) / "_index.json"


def _telemetry_dir(workspace: Path) -> Path:
    return workspace / ".selph" / "telemetry"


def _memo_dir(workspace: Path) -> Path:
    return workspace / ".selph" / "state" / "memo"
