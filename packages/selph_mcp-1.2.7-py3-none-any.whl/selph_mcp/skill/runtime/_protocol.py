"""PersonaCallProtocol and its lazy WorkflowSpec type-import helper."""

from __future__ import annotations

from typing import Any, Optional, Protocol


class PersonaCallProtocol(Protocol):
    """Protocol for the injected transport callable.

    Returns ``(response_body, response_headers)`` so the runtime can extract
    ``X-Selph-Server-Contract-Versions`` for version negotiation (§3.6).
    """

    def __call__(
        self,
        tool: str,
        params: dict[str, Any],
        *,
        adapter_version: Optional[int] = None,
    ) -> "tuple[dict[str, Any], dict[str, str]]":
        """Call a Selph persona tool.

        Args:
            tool: MCP tool name.
            params: Tool parameters.
            adapter_version: Adapter contract version to pass as
                ``X-Selph-Adapter-Contract-Version`` header. ``None`` means
                the transport omits the header.

        Returns:
            ``(response_body, response_headers)`` — both are plain dicts.
        """
        ...


# ---------------------------------------------------------------------------
# WorkflowSpec import (type-only, deferred to avoid module-level dep issues)
# ---------------------------------------------------------------------------

def _get_workflow_spec_type() -> Any:
    try:
        from selph_mcp.contracts.workflow_spec import WorkflowSpec  # type: ignore[import]
        return WorkflowSpec
    except Exception:
        return None
