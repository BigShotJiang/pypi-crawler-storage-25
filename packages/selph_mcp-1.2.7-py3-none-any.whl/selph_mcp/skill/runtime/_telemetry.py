"""Telemetry rotation and append helpers (§3.5).

Local-only; telemetry records are never shipped to the server. All
operations are best-effort — failures are WARNING-logged and swallowed
so telemetry can never break a persona call.
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Optional

from ._paths import _telemetry_dir
from ._shared import (
    _TELEMETRY_BACKUP_COUNT_DEFAULT,
    _TELEMETRY_MAX_BYTES_DEFAULT,
    _int_env,
    _log,
)


def _rotate_telemetry_if_needed(tel_path: Path) -> None:
    """Rotate ``<workflow_id>.jsonl`` when it exceeds the byte threshold.

    Rename scheme: ``f.jsonl`` → ``f.jsonl.1`` → ``f.jsonl.2`` → ...
    Files past ``SELPH_TELEMETRY_BACKUP_COUNT`` are deleted.

    Best-effort — any OSError is logged and swallowed. Callers proceed
    with the append regardless (a too-large file is still appendable).
    """
    max_bytes = _int_env("SELPH_TELEMETRY_MAX_BYTES", _TELEMETRY_MAX_BYTES_DEFAULT)
    backup_count = _int_env("SELPH_TELEMETRY_BACKUP_COUNT", _TELEMETRY_BACKUP_COUNT_DEFAULT)

    try:
        if not tel_path.exists():
            return
        size = tel_path.stat().st_size
    except OSError as exc:
        _log.warning(
            "telemetry preflight stat failed; skipping rotation",
            extra={
                "event": "adapter.telemetry.preflight_failed",
                "path": str(tel_path),
                "error_type": type(exc).__name__,
            },
        )
        return

    if size < max_bytes:
        return

    try:
        # Drop the oldest backup if it exceeds the allowed count.
        oldest = tel_path.with_suffix(tel_path.suffix + f".{backup_count}")
        if oldest.exists():
            try:
                oldest.unlink()
            except OSError as exc:
                _log.warning(
                    "telemetry oldest-backup unlink failed",
                    extra={
                        "event": "adapter.telemetry.oldest_unlink_failed",
                        "path": str(oldest),
                        "error_type": type(exc).__name__,
                    },
                )
        # Shift each backup down by one (.N-1 → .N, ..., .1 → .2).
        for idx in range(backup_count - 1, 0, -1):
            src = tel_path.with_suffix(tel_path.suffix + f".{idx}")
            dst = tel_path.with_suffix(tel_path.suffix + f".{idx + 1}")
            if src.exists():
                try:
                    src.replace(dst)
                except OSError as exc:
                    _log.warning(
                        "telemetry backup shift failed; aborting rotation cycle",
                        extra={
                            "event": "adapter.telemetry.backup_shift_failed",
                            "src": str(src),
                            "dst": str(dst),
                            "error_type": type(exc).__name__,
                        },
                    )
                    # Abort this rotation cycle — continuing would risk
                    # a mismatched backup generation (later shifts
                    # succeed while earlier ones failed). The append
                    # still proceeds on the current file.
                    return
        # Current → .1
        rotated = tel_path.with_suffix(tel_path.suffix + ".1")
        tel_path.replace(rotated)
        _log.info(
            "telemetry rotated",
            extra={
                "event": "adapter.telemetry.rotated",
                "path": str(tel_path),
                "size_bytes": size,
                "max_bytes": max_bytes,
                "backup_count": backup_count,
            },
        )
    except OSError as exc:
        _log.warning(
            "telemetry rotation failed; continuing to append",
            extra={
                "event": "adapter.telemetry.rotation_failed",
                "path": str(tel_path),
                "error_type": type(exc).__name__,
            },
        )


def _append_telemetry(
    workspace: Path,
    workflow_id: str,
    tool: str,
    params: dict[str, Any],
    mode_used: str,
    fingerprint: Optional[str],
    call_site: str,
) -> None:
    """Append one telemetry line to ``.selph/telemetry/<workflow_id>.jsonl``.

    Local-only; never shipped to the server. Best-effort — failures are
    WARNING-logged and swallowed.
    """
    tel_dir = _telemetry_dir(workspace)
    tel_dir.mkdir(parents=True, exist_ok=True)
    tel_path = tel_dir / f"{workflow_id}.jsonl"

    # Size-based rotation before the append so the file never grows past
    # max_bytes + one record.
    _rotate_telemetry_if_needed(tel_path)

    params_hash = hashlib.sha256(
        json.dumps(params, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).hexdigest()[:16]

    record = {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "tool": tool,
        "params_hash": params_hash,
        "mode_used": mode_used,
        "fingerprint": fingerprint,
        "call_site": call_site,
    }
    try:
        with tel_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError as exc:
        _log.warning(
            "telemetry append failed",
            extra={
                "event": "adapter.telemetry.append_failed",
                "workflow_id": workflow_id,
                "error_type": type(exc).__name__,
            },
        )
