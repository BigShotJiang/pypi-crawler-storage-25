"""Shared constants, logger, and env-var helpers for the runtime sub-package.

Logger name is pinned to ``adapters.claude_code.using_selph.runtime`` verbatim
so operator dashboards and log-query filters continue to work unchanged after
the monolith-to-sub-package refactor. Every other runtime sub-module must
import ``_log`` from here rather than constructing a logger via ``__name__``.
"""

from __future__ import annotations

import os

from selph_mcp.contracts.versions import (
    HARNESS_ADAPTER_VERSION,
    load_contract_versions,
)
from selph_mcp._log import get_logger

# Pinned logger name — MUST NOT be changed; operator dashboards filter on it.
_log = get_logger("selph_mcp.skill.runtime")

# Adapter-side contract version sent as X-Selph-Adapter-Contract-Version.
_ADAPTER_CONTRACT_VERSION: int = HARNESS_ADAPTER_VERSION

# How often to run the stale-cache purge per Runtime instance (seconds).
_PURGE_INTERVAL_SECONDS: int = 30

# Adapter-side cache limits (follow-up to resource-pressure audit).
# Env-var overrides let operators tune without a code change.
#
# Cache eviction policy: (1) TTL by mtime — entries older than
# ``SELPH_CACHE_TTL_DAYS`` are always evicted; (2) LRU — when the cache
# holds more than ``SELPH_CACHE_MAX_ENTRIES`` entries, evict the oldest
# by mtime until the count fits. Both layers run together each cycle.
_CACHE_MAX_ENTRIES_DEFAULT: int = 500
_CACHE_TTL_DAYS_DEFAULT: int = 7

# Telemetry rotation (follow-up to resource-pressure audit).
# Size-based rotation: when ``<workflow_id>.jsonl`` exceeds the byte
# threshold, rename to ``<workflow_id>.jsonl.1`` (shifting older backups
# out to ``.2``, ``.3``, …) and truncate. ``SELPH_TELEMETRY_BACKUP_COUNT``
# caps total backups; files beyond that are deleted.
_TELEMETRY_MAX_BYTES_DEFAULT: int = 10 * 1024 * 1024  # 10 MiB
_TELEMETRY_BACKUP_COUNT_DEFAULT: int = 3


def _int_env(name: str, default: int) -> int:
    """Read a positive-integer env var with a fallback."""
    raw = os.getenv(name)
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        return default
    return value if value > 0 else default
