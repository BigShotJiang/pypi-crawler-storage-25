# Package marker — required for importlib.resources and pyproject.toml
# package-data key "selph_mcp.skill.templates" to resolve correctly.
