# Retrieval policy (§5.7 of the MCP distribution plan)

This document is the canonical retrieval policy referenced by the
`using-selph` CLAUDE.md block. It governs how Claude Code interacts with
the Selph persona MCP during normal (non-onboarding) work.

## When to call Selph

Call the persona MCP whenever you need persona context that is not already
in the current Claude Code session transcript:

- About the user themselves (preferences, history, voice, current
  pursuits).
- About a person they know (a relationship, a colleague, a contact).
- About a project, pursuit, or decision they are working on.
- About a recent change in their world (yesterday's events, this week's
  pattern).

Do **not** call Selph for general world knowledge, code in the current
repo, or anything you can resolve from the active session.

## Tool selection

| You need… | Call |
|---|---|
| A short briefing or reply draft | `get_context(intent="briefing" or "reply_draft", depth="auto")` |
| A specific question answered | `ask_selph(question=…)` |
| A recent-changes drift list | `what_changed(since_cursor=…)` |
| A specific evidence record / citation | `find_evidence(ref_id=…)` |
| A summary card for one entity | `get_entity_card(entity_id=…)` |
| To install a role-bound bootstrap | `hire_for_role(role=…, purpose=…)` |
| To write back a session observation | `observe_session(text=…, mode="store_raw_only")` |
| To correct a memory or observation | `correct(payload=…)` |

`depth="auto"` is the default. Override only when you specifically need
`brief`, `targeted`, `insight`, or `evidence`.

## Reading the response envelope

Every read returns a `PersonaResponse` envelope. Always inspect:

- `meta.confidence` — float in [0, 1]. Below 0.3 ⇒ sparse-graph posture.
- `meta.evidence_count` — integer. 0 ⇒ sparse-graph posture.
- `meta.staleness_status` — `fresh`, `stale`, or `unknown`. Stale ⇒ flag
  it to the user; do not silently serve.
- `meta.degraded_from` — present when the depth router downgraded due to
  budget pressure. Mention it inline.
- `citations[]` — typed Citation objects. Source for every chip.
- `suggested_next_actions[]` — surface as proposal-first menu items
  whenever they would help the user.

## Sparse-graph posture

Trigger when `meta.confidence < 0.3` OR `meta.evidence_count == 0`.

The literal opening line is:

> "I don't know you well enough yet."

Never substitute a softer phrase. Then, in plain language, explain what
Selph has on this subject (count, freshness) and what would help (an
import, a recent conversation, a correction). Do not fabricate to fill
the gap.

## Caching

`.selph/cache/` is a local optimization, not source of truth. Rules:

- Cache reads keyed by the etag from `meta.etag`.
- On every session start, run `what_changed(since_cursor=…)` and purge
  any cache entries whose key matches an invalidation prefix.
- Never serve a cached read whose etag falls before an invalidation.
- A cache miss is fine — refetching is cheap.

## Revocation

A 401 from any persona call means the consumer was revoked. Stop calling.
Tell the user the harness was revoked and what to do (re-run
`/using-selph` to register a new consumer or wait for the operator).

## Writeback

The retrieval policy and writeback policy share one rule: **never alter the
graph in a way the user did not authorize**. Specifically:

- `observe_session` default mode is `store_raw_only`. The full ingest
  pipeline (`deep_ingest`) is opt-in, per workflow.
- `correct` requires explicit user confirmation per call (not blanket
  pre-authorization).
- `recommendation_feedback` is fire-and-forget — but always send it when
  the user accepts/skips/modifies/defers a recommendation, so the heuristic
  ranker can learn.
