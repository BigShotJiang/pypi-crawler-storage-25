## Evidence chip contract (§5.10)

Every interpretive statement this workflow echoes back to the user MUST
carry at least one citation chip pulled from `response.citations[]`.

Inline format:

> Your last project review with Sam was tense
> `[MEM-U001-00042 · L2 · 2026-04-18T14:22:00Z]`.

Block format (multiple chips, e.g. for an `insight` mode answer):

> Sources:
> - `[MEM-U001-00042 · L2 · 2026-04-18]` — `relationship_state_snapshot`
>   confidence 0.81
> - `[HUB-AB12CD34 · L4 · 2026-04-19]` — `relationship_priority_hub`
> - `[OBS-…uuid… · L1 · 2026-04-17]` — raw utterance

Pull `ref_id`, `layer`, and `captured_at` from the typed `Citation` objects
on the response. If a statement has no backing citation, drop the
statement — do not soften, do not paraphrase, do not invent.

If `meta.confidence < 0.3` OR `meta.evidence_count == 0`, do not emit any
interpretive statement at all. Apply the sparse-graph posture instead:
say "I don't know you well enough yet" and explain what would help.
