# selph_mcp.skill — wheel-packaged bootstrap helpers and runtime for
# the using-selph Claude Code skill.
#
# Sub-packages:
#   bootstrap/   — filesystem glue helpers (credentials, MCP config, onboarding)
#   runtime/     — async runtime + cache layer
#   templates/   — CLAUDE.md / gitignore / policy block templates
#   install/     — bundled SKILL.md and install assets
#
# Public surface: import from selph_mcp.skill.bootstrap or
# selph_mcp.skill.runtime directly.
