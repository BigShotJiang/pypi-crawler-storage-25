"""On-disk state schemas for the ``using-selph`` Claude Code adapter.

All models use ``extra="forbid"`` per Phase 1a contract conventions —
unknown fields are a hard error so corrupted state surfaces immediately
instead of being silently dropped.

State files live under ``<workspace>/.selph/state/``:

- ``onboarding.json`` — ``OnboardingState``
- ``credentials.json`` — credentials (separate; chmod 0600; never logged)

Workflow manifests are not persisted to JSON — they are rendered into
``.claude/skills/<workflow_id>/SKILL.md`` at install time. The ``installed``
list on ``OnboardingState`` is the durable record of what was installed.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import StrEnum
from typing import Annotated, List, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

# ``WorkflowManifest`` and ``PLACEHOLDER_WORKFLOW`` now live in
# ``selph_mcp.contracts.workflow_manifest`` so that
# ``selph_mcp.persona.workflows`` can import them without creating a
# ``selph_mcp -> adapters`` import edge. The import is permitted here
# because the ``.importlinter`` ``adapters-surface-only`` contract
# explicitly allows ``adapters.** -> selph_mcp.contracts.**``.
from selph_mcp.contracts.workflow_manifest import (  # noqa: F401 — re-exported
    PLACEHOLDER_WORKFLOW,
    WorkflowManifest,
    _validate_workflow_id_str as _contracts_validate_workflow_id,
)
from selph_mcp.contracts.versions import (
    HARNESS_ADAPTER_VERSION,
    MEMORY_BOUNDARY_POLICY_VERSION,
)

# -----------------------------------------------------------------------------
# Workflow ID validator (HIGH 1 — path-traversal defense)
# -----------------------------------------------------------------------------
#
# ``workflow_id`` flows from MCP responses (user-controllable upstream) into a
# filesystem path segment (``.claude/skills/<workflow_id>/SKILL.md``). To
# prevent directory traversal, symlink tricks, or hidden-dotfile placement, we
# constrain it to a strict, conservative shape:
#
#   - Lowercase alphanumeric + underscore + hyphen.
#   - Must start with an alphanumeric character (no leading ``.`` or ``-``
#     or ``_``).
#   - Length 1..63 (POSIX NAME_MAX-friendly, leaves room for parent dirs).
#
# ``..``, ``/``, ``\\`` and any absolute path are rejected as a side effect of
# the character class. The validator is exposed as a public function so
# ``bootstrap.install_workflow`` can re-run it as defense-in-depth even if the
# manifest came from a legacy / unvalidated source.
#
# NOTE: the canonical regex and logic now live in
# ``selph_mcp.contracts.workflow_manifest._validate_workflow_id_str``.
# This wrapper delegates to that implementation to guarantee both sites
# stay in sync without duplicating the regex.


def validate_workflow_id(value: str) -> str:
    """Return ``value`` if it is a safe ``workflow_id``; raise ``ValueError``.

    Delegates to ``selph_mcp.contracts.workflow_manifest._validate_workflow_id_str``
    so both validation sites stay in sync.

    Rejects: ``..``, ``/``, ``\\``, leading dots, leading hyphens or
    underscores, uppercase letters, any character outside ``[a-z0-9_-]``,
    empty strings, and strings longer than 63 chars.
    """
    return _contracts_validate_workflow_id(value)

# -----------------------------------------------------------------------------
# Onboarding state (single tenant, per-workspace)
# -----------------------------------------------------------------------------


class OnboardingState(BaseModel):
    """Durable state stored at ``<workspace>/.selph/state/onboarding.json``.

    Written by ``bootstrap.record_onboarding_complete`` after the first-run
    flow finishes. Read by ``bootstrap.detect_state`` on every subsequent
    invocation of ``/using-selph`` to decide between cold-start vs returning
    flows (per §5.3 of the implementation plan).

    Schema v2 adds ``harness_adapter_version`` and
    ``memory_boundary_policy_version``. Both fields are required when
    ``schema_version == 2``; they are optional for transitional v1 input
    (the v1→v2 migration helper stamps them before validation in practice).
    """

    model_config = ConfigDict(extra="forbid")

    schema_version: int = Field(
        default=2, ge=1, description="Bumped when this on-disk schema changes."
    )
    consumer_id: str = Field(
        ...,
        min_length=1,
        description="MCP consumer_id issued by the kernel admin route.",
    )
    user_id: str = Field(
        ...,
        min_length=1,
        description="Selph user_id bound to the consumer (e.g. U001).",
    )
    persona_contract_version: str = Field(
        ...,
        min_length=1,
        description=(
            "Pinned persona contract version at the time onboarding "
            "completed. Mismatch on reload triggers a re-onboarding hint."
        ),
    )
    etag_cursor: int = Field(
        default=0,
        ge=0,
        description=(
            "Last-seen ``mcp_etag_invalidations`` cursor. Sent on the "
            "returning-user handshake so the server can return the "
            "purge set since this point."
        ),
    )
    installed_workflows: List[str] = Field(
        default_factory=list,
        description="Workflow IDs currently installed under .claude/skills/.",
    )
    completed_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="UTC timestamp when onboarding finished.",
    )
    harness_adapter_version: Optional[int] = Field(
        default=None,
        ge=1,
        description=(
            "Harness adapter version at the time onboarding completed. "
            "Required when schema_version == 2."
        ),
    )
    memory_boundary_policy_version: Optional[int] = Field(
        default=None,
        ge=1,
        description=(
            "Memory-boundary policy version at the time onboarding completed. "
            "Required when schema_version == 2."
        ),
    )

    @field_validator("installed_workflows")
    @classmethod
    def _validate_installed_workflow_ids(cls, value: List[str]) -> List[str]:
        """Run the workflow-id allowlist over every entry on load and write.

        Belt-and-braces: even if a malformed id slipped past the install path,
        it cannot survive a round-trip through ``OnboardingState`` and become
        a directory name in a later run.
        """
        for item in value:
            validate_workflow_id(item)
        return value

    @model_validator(mode="after")
    def _require_version_fields_on_v2(self) -> "OnboardingState":
        """Require harness_adapter_version and memory_boundary_policy_version
        to be non-None when schema_version == 2.

        schema_version == 1 input is treated as transitional — the v1→v2
        migration helper stamps both fields before validation in practice, but
        we allow them absent here to permit raw v1 dicts to pass through
        ``migrate_onboarding_raw`` without a double-validate error.
        """
        if self.schema_version == 2:
            if self.harness_adapter_version is None:
                raise ValueError(
                    "harness_adapter_version is required when schema_version == 2"
                )
            if self.memory_boundary_policy_version is None:
                raise ValueError(
                    "memory_boundary_policy_version is required when schema_version == 2"
                )
        return self


# -----------------------------------------------------------------------------
# v1 → v2 migration helper (pure — no I/O, no bootstrap imports)
# -----------------------------------------------------------------------------


def migrate_onboarding_raw(raw: dict) -> dict:
    """Pure v1->v2 dict transform. Stamps schema_version=2, fills new version
    fields from current adapter constants. Idempotent — returns raw unchanged
    when raw.get('schema_version') == 2.

    Sources for version constants:
      - ``HARNESS_ADAPTER_VERSION`` from ``selph_mcp.contracts.versions``
      - ``MEMORY_BOUNDARY_POLICY_VERSION`` from ``selph_mcp.contracts.versions``

    Preserves all existing fields (consumer_id, user_id, etag_cursor,
    installed_workflows, completed_at, persona_contract_version) verbatim.
    """
    if raw.get("schema_version") == 2:
        return raw
    migrated = dict(raw)
    migrated["schema_version"] = 2
    migrated["harness_adapter_version"] = HARNESS_ADAPTER_VERSION
    migrated["memory_boundary_policy_version"] = MEMORY_BOUNDARY_POLICY_VERSION
    return migrated


# -----------------------------------------------------------------------------
# Workflow manifest (transient — used at install time)
# -----------------------------------------------------------------------------
# WorkflowManifest and PLACEHOLDER_WORKFLOW are now imported from
# ``selph_mcp.contracts.workflow_manifest`` (see import block above).
# They are re-exported here so existing call sites in bootstrap.py and
# SKILL.md-driven code remain unchanged.

# -----------------------------------------------------------------------------
# Discriminated state result returned by ``bootstrap.detect_state``
# -----------------------------------------------------------------------------


class ColdStart(BaseModel):
    """Returned when no ``onboarding.json`` exists at the workspace.

    The bootstrap caller (Claude Code, via SKILL.md) must run the first-run
    flow per §5.3: hire_for_role → what_changed → get_context(operating_manual)
    → get_context(workflow_recommendation).
    """

    model_config = ConfigDict(extra="forbid")

    kind: Literal["cold_start"] = "cold_start"
    workspace_root: str
    state_dir: str
    reason: Literal["no_state_file", "state_file_unreadable"] = "no_state_file"


# -----------------------------------------------------------------------------
# Returning sub-state
# -----------------------------------------------------------------------------


class ReturningSubState(StrEnum):
    CLEAN = "clean"
    UPGRADE_IN_PLACE = "upgrade_in_place"
    REPAIR = "repair"


class Returning(BaseModel):
    """Returned when valid ``onboarding.json`` is present.

    ``contract_drift`` flags persona_contract_version mismatch — the caller
    must re-run the first-run flow per the brief, even though state exists.

    ``sub_state`` refines the returning classification:
      - ``clean``: no drift detected, no action required.
      - ``upgrade_in_place``: version drift detected; artifacts can be updated
        without destructive reset.
      - ``repair``: structural or unrecoverable drift; targeted repair needed.

    ``drift_reasons`` is a list of declarative tags identifying what drifted
    (e.g. ``"persona_contract_version"``, ``"harness_adapter_version"``,
    ``"memory_boundary_policy_version"``, ``"retrieval_policy_block_missing"``,
    ``"workflow_template_stale"``).
    """

    model_config = ConfigDict(extra="forbid")

    kind: Literal["returning"] = "returning"
    workspace_root: str
    state_dir: str
    state: OnboardingState
    contract_drift: bool = Field(
        default=False,
        description=(
            "True when stored persona_contract_version does not match the "
            "currently-imported one. Triggers a SKILL.md warning + "
            "first-run re-execution."
        ),
    )
    sub_state: ReturningSubState = Field(
        default=ReturningSubState.CLEAN,
        description=(
            "Refined returning classification: clean | upgrade_in_place | repair."
        ),
    )
    drift_reasons: list[str] = Field(
        default_factory=list,
        description=(
            "Declarative tags identifying what drifted. Examples: "
            "\"persona_contract_version\", \"harness_adapter_version\", "
            "\"memory_boundary_policy_version\", "
            "\"retrieval_policy_block_missing\", \"workflow_template_stale\"."
        ),
    )


# Discriminated union — consumers of ``detect_state`` should pattern-match
# on ``.kind``.
State = Annotated[Union[ColdStart, Returning], Field(discriminator="kind")]


# -----------------------------------------------------------------------------
# Workflow scan models (§4.7 — Phase C workflow scan + proposals)
# -----------------------------------------------------------------------------


class PersonalizationMode(StrEnum):
    UNKNOWN = "unknown"
    ELIGIBLE = "eligible"
    NOT_APPLICABLE = "not_applicable"


class WorkflowScanCandidate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    workflow_id: str
    skill_md_path: str
    classification: Literal["selph_managed", "unmanaged_preexisting"]
    personalization_mode: PersonalizationMode
    last_policy_version_applied: Optional[int] = None


class WorkflowProposal(BaseModel):
    model_config = ConfigDict(extra="forbid")

    workflow_id: str
    proposal_kind: Literal["upgrade_in_place", "advisory_only", "noop"]
    drift_reasons: list[str]
    suggested_action: str  # human-readable


class WorkflowScanReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    candidates: list[WorkflowScanCandidate]
    proposals: list[WorkflowProposal]


# -----------------------------------------------------------------------------
# Typed exceptions (raised by bootstrap.py; defined here for shared import)
# -----------------------------------------------------------------------------


class OnboardingStateError(Exception):
    """Base for onboarding-state IO errors."""


class OnboardingStateCorrupt(OnboardingStateError):
    """JSON parse failure or unrecoverable structural damage."""


class OnboardingMigrationFailed(OnboardingStateError):
    """v1->v2 migration produced a dict that fails v2 validation."""

    def __init__(self, original_raw: bytes, cause: Exception) -> None:
        self.original_raw = original_raw
        self.cause = cause
        super().__init__(
            f"OnboardingState v1→v2 migration failed: {cause!r}"
        )


__all__ = [
    "OnboardingState",
    "migrate_onboarding_raw",
    "WorkflowManifest",
    "PLACEHOLDER_WORKFLOW",
    "ColdStart",
    "Returning",
    "ReturningSubState",
    "State",
    "validate_workflow_id",
    "PersonalizationMode",
    "WorkflowScanCandidate",
    "WorkflowProposal",
    "WorkflowScanReport",
    "OnboardingStateError",
    "OnboardingStateCorrupt",
    "OnboardingMigrationFailed",
]
