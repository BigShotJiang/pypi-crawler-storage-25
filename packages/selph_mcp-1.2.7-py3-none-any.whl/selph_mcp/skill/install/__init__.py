# Package marker — required for importlib.resources and pyproject.toml
# package-data key "selph_mcp.skill.install" to resolve correctly.
