# Returning-user flow

Read this file when the slim controller routes you here (state.kind ==
"returning"). The common steps run in ALL returning sub-states. Then branch
on `state.sub_state` for the drift-specific menus.

---

## Common steps (always run)

### 0. Drift check first

Run the wheel-version drift check (see slim controller §"Wheel-version
drift check"). If the wheel is below `recommended_wheel_version`, stop here
— the user must upgrade before any sync can proceed.

### 1. Self-update the slash command

```bash
selph-mcp-bootstrap refresh-slash-command --api-url "<api_url>"
```

Best-effort — if it exits non-zero (network failure), log and continue
with the cached local copy. The next invocation picks up the refreshed spec.

### 2. Ensure CLAUDE.md policy block is current

```bash
selph-mcp-bootstrap install-policy-block --workspace "<cwd>"
```

### 3. Write/refresh the remote MCP entry (idempotent — only writes if stale)

```bash
selph-mcp-bootstrap write-mcp-entry --remote-url "<api_url>"
```

This also migrates any legacy `type: "stdio"` `selph` entry on first contact.

### 4. Reconcile onboarding state against the server

If `global_hydrated` is non-null, fetch the server's authoritative view:

```bash
selph-mcp-bootstrap whoami-remote \
    --api-url "<api_url>"
# bearer_token and consumer_id are read automatically from the credentials file
```

On success, write the response JSON to a temp file and reconcile:

```bash
selph-mcp-bootstrap reconcile-onboarding \
    --workspace "<cwd>" \
    --whoami @<whoami_temp>.json
```

If `whoami-remote` returns `ok: false` with an auth error (HTTP 401/403),
surface the failure:

> Selph could not verify your consumer identity (auth failed on `/whoami`).
> Run `selph-mcp-bootstrap doctor` to diagnose. Continuing with cached state.

Do NOT silently skip — the user must know their credentials may need renewal.

If the failure is a network/5xx error, log and continue with cached state.

### 5. Drain invalidations

Call the Remote MCP tool `what_changed(since_cursor=<state.etag_cursor>)`.
The response returns `data.invalidated_keys`. Intersect with
`<workspace>/.selph/cache/_index.json` and purge stale cache entries.

### 6. Update the etag cursor

```bash
selph-mcp-bootstrap update-etag --workspace "<cwd>" --cursor <new_cursor>
```

### 7. Read the user's voice signal (Layer 2 personalization)

Call the Remote MCP tool `get_context` once with
`domain_hint="voice_and_creative_context"` and a short, broad question
like "How does this person prefer to be talked to — tone, length, level
of formality, things to avoid?" Hold the response in working memory for
the rest of the session.

Apply the response to *texture only* — the static rules in the slim
controller's "Voice & manner" section always remain in force. Use the
signal to bend defaults: if it indicates "prefers short", trim adjectives;
if "dry humor", let phrasing be drier; if "direct", drop softeners. If the
signal is absent or sparse (`meta.confidence < 0.3` OR
`meta.evidence_count == 0`), continue with the static defaults — do
NOT prompt the user for voice preferences. The signal accumulates over
time as the graph fills; cold sessions just feel like a polite,
plain-spoken assistant.

Soft-fail on any error: log internally and continue. A missing voice
signal must never block the rest of the session.

### 8. MANDATORY — run the workflow scan now, before branching

```bash
selph-mcp-bootstrap scan-workflows --workspace "<cwd>"
```

Parse `data` as the `WorkflowScanReport`. Hold it in scope. **Each
sub-state branch is required to render proposals from `data.proposals`
(per `flows/workflow-audit.md`) before producing its status summary.**
If `data.proposals` is empty, render nothing for proposals; do not
silently drop a non-empty list.

---

## Branch on `state.sub_state`

### `sub_state == "clean"` (no drift)

**Required ordering: render workflow proposals → then status line.**

1. Render proposals from the scan report per `flows/workflow-audit.md`. If
   empty, skip and continue.
2. Short status line: workspace name, installed workflow count, last sync
   timestamp, and proposal counts (N applied, M skipped/deferred).
3. No deep retrieval unless the user asks.

### `sub_state == "upgrade_in_place"` (version drift; no structural damage)

`upgrade_in_place` is triggered by one or more of:
`persona_contract_version`, `harness_adapter_version`,
`memory_boundary_policy_version`, or `contract_drift=True`.

If `contract_drift` is True (persona contract bumped), run:
`pipx upgrade selph-mcp`. Reuse the existing `consumer_id`; do not register
again.

Present the following numbered proposal menu (render actual drift_reasons):

```
Selph found N updates available:
- <drift_reason 1>
- <drift_reason 2>
How would you like to proceed?
  [1] Apply all updates
  [2] Review each
  [3] Skip this run
  [4] Defer until later
```

On `[1]` accept-all, apply the matching surgical primitives:

- `"retrieval_policy_block_missing"` →
  `selph-mcp-bootstrap install-policy-block --workspace "<cwd>"`
- `"workflow_template_stale"` → for each installed workflow:
  `selph-mcp-bootstrap migrate-workflow --workspace "<cwd>" --workflow-id <id> --current-template-version 1`
- Version drift tags → re-run `selph-mcp-bootstrap record-onboarding`
  with current constants to stamp the new versions.

On `[2]` review-each, show one accept/skip prompt per drift item.

On `[3]`/`[4]`, emit an observation via `observe_session` noting the deferred
upgrade (best-effort; do not block if the MCP call fails) and continue.

After the drift menu resolves, render proposals from the scan report per
`flows/workflow-audit.md`, then produce the final status summary.

### `sub_state == "repair"` (structural drift)

`repair` means at least one structural artifact is broken.

Present a narrower "Repair required" menu:

```
Selph detected broken artifacts that need repair:
- <drift_reason 1>
- <drift_reason 2>
These issues can be fixed without resetting your workspace.
  [1] Repair all broken artifacts now
  [2] Review each artifact
  [3] Skip repair this run
  [4] Defer repair until later
```

On `[1]` repair-all, apply the same surgical primitives as `upgrade_in_place`.
On `[2]`, show one per-artifact accept/skip prompt.
On `[3]`/`[4]`, log the deferral and continue.

After the repair menu resolves, render proposals from the scan report, then
produce the final status summary.
