# Troubleshooting + first-install (out-of-band)

Read this file when something fails in either flow, or when a user has
the wheel but no slash command yet.

---

## Doctor — `selph-mcp-bootstrap doctor`

If anything in either flow fails (auth 401, contract version mismatch,
engine unreachable), shell out to:

```bash
selph-mcp-bootstrap doctor
```

The output is a checklist of `OK` / `FAIL` lines covering:

- credentials file exists at `~/.config/selph-mcp/credentials.json`
- engine reachable at the configured `api_url`
- persona contract version matches the installed wheel
- bearer token authenticates against `GET /apps/mcp/whoami`

Surface the doctor output verbatim.

---

## First-install (out-of-band)

Users who only have `pipx install selph-mcp` (no repo clone) install the
slash command via:

```bash
selph-mcp-bootstrap install-slash-command --api-url "<api_url>"
selph-mcp-bootstrap install-skill-tree --api-url "<api_url>"
```

`install-slash-command` fetches `<api_url>/apps/install/using-selph` and
writes the slim controller to `~/.claude/commands/using-selph.md`.

`install-skill-tree` populates the modular sub-files at
`~/.claude/commands/using-selph/{flows,reference}/*.md`. It always
writes from the wheel-bundled fallback first, then optionally refreshes
from the server when `--api-url` is provided. Subsequent
`/using-selph` invocations call this command in Step 0 to keep the tree
intact even if the user has deleted or modified files.
