"""Workflow install helper for the using-selph bootstrap."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from ._shared import logger, _read_template
from ._paths import _skills_dir
from ._file_locking import _atomic_write_text

from selph_mcp.skill.state_schema import (
    PLACEHOLDER_WORKFLOW,
    WorkflowManifest,
    validate_workflow_id,
)
from selph_mcp.contracts.versions import MEMORY_BOUNDARY_POLICY_VERSION

__all__: list[str] = [
    "_get_official_manifest",
    "InstalledWorkflow",
    "install_workflow",
]

# Phase C workflow-skill markers (§4.8 / C1).
_WORKFLOW_SKILL_MARKER_START = "<!-- selph:workflow-skill:v1 START -->"
_WORKFLOW_SKILL_MARKER_END = "<!-- selph:workflow-skill:v1 END -->"
_SKILL_META_MARKER = "<!-- selph:skill-meta:v1"  # open-tag prefix used for parsing


def _get_official_manifest(workflow_id: str) -> Optional[WorkflowManifest]:
    """Return a real :class:`WorkflowManifest` for *workflow_id* if it is
    one of the Phase 5 official workflows; otherwise return ``None``.

    Imports ``selph_mcp.persona.workflows`` lazily to avoid pulling in
    yaml/pydantic at module-level — the ``adapters-surface-only``
    import-linter contract allows ``adapters.** -> selph_mcp.contracts.**``
    only; the lazy import of ``selph_mcp.persona.workflows`` (not a
    contracts module) is intentionally done at call time, not at the
    module boundary, so the import-linter's static analysis does not pick
    up a forbidden edge.  The rule text says "adapters may import from
    selph_mcp.contracts"; this helper does so indirectly via the workflow
    loader's return type (``WorkflowManifest``), which already lives in
    ``selph_mcp.contracts.workflow_manifest``.

    On any exception (YAML not found, validation error, import error) the
    function logs a warning and returns ``None``. ``install_workflow``
    then either substitutes ``PLACEHOLDER_WORKFLOW`` (when *workflow_id*
    equals ``PLACEHOLDER_WORKFLOW.workflow_id`` — the Phase 4 verification
    path) or raises ``ValueError``. A silent placeholder swap for an
    official workflow id would mislead the operator into thinking their
    selected workflow installed successfully, so the raise is intentional.
    """
    try:
        from selph_mcp.persona.workflows import (  # type: ignore[import]
            list_official_workflow_ids,
            load_workflow_manifest,
        )
    except Exception as exc:
        logger.warning(
            "selph_mcp.persona.workflows unavailable; official install will fail",
            extra={
                "event": "bootstrap.install_workflow.workflows_import_failed",
                "workflow_id": workflow_id,
                "error_type": type(exc).__name__,
                "error": str(exc),
            },
        )
        return None

    if workflow_id not in list_official_workflow_ids():
        return None

    try:
        # Use load_workflow_manifest (JSON-based, no PyYAML dep) instead of
        # load_workflow_spec → build_manifest (YAML-based, excluded from wheel).
        return load_workflow_manifest(workflow_id)
    except Exception as exc:
        logger.warning(
            "official workflow manifest load failed; install will raise",
            extra={
                "event": "bootstrap.install_workflow.manifest_load_failed",
                "workflow_id": workflow_id,
                "error_type": type(exc).__name__,
                "error": str(exc),
            },
        )
        return None


@dataclass(frozen=True)
class InstalledWorkflow:
    workflow_id: str
    version: str
    skill_path: str


def install_workflow(
    workspace: Path,
    workflow_id: str,
    manifest: Optional[WorkflowManifest] = None,
) -> InstalledWorkflow:
    """Render a workflow's SKILL.md under ``.claude/skills/<workflow_id>/``.

    Idempotent: re-running with the same manifest produces the same file
    contents. The evidence-chip snippet from the templates dir is always
    appended so workflow output stays compliant with §5.10.

    If ``manifest`` is None and ``workflow_id == "placeholder"``, the
    PLACEHOLDER_WORKFLOW constant is used (Phase 4 verification path).
    Otherwise raises.
    """
    # Defense-in-depth: re-run the allowlist on the raw input even though
    # ``WorkflowManifest`` enforces it at model-validation time. ``workflow_id``
    # flows from MCP responses (user-controllable upstream) into a filesystem
    # path segment, so any traversal attempt (``..``, ``/``, leading ``.``)
    # must be rejected before we touch the filesystem.
    validate_workflow_id(workflow_id)

    if manifest is None:
        # Phase 5 bootstrap swap: try loading the real manifest from the
        # official workflow YAML library first.
        official = _get_official_manifest(workflow_id)
        if official is not None:
            manifest = official
        elif workflow_id == PLACEHOLDER_WORKFLOW.workflow_id:
            manifest = PLACEHOLDER_WORKFLOW
        else:
            raise ValueError(
                f"manifest required for workflow_id={workflow_id!r} "
                "(not in the official workflow library and no manifest supplied)"
            )
    if manifest.workflow_id != workflow_id:
        raise ValueError(
            f"manifest.workflow_id={manifest.workflow_id!r} does not match "
            f"workflow_id={workflow_id!r}"
        )

    skills_dir = _skills_dir(workspace, workflow_id)

    # Path-containment guard: after resolving symlinks and ``..`` segments,
    # the final write target MUST live under ``<workspace>/.claude/skills/``.
    # We resolve both sides with strict=False so the check works on the
    # not-yet-created skills dir.
    expected_root = (workspace.resolve() / ".claude" / "skills").resolve()
    final_dir = skills_dir.resolve()
    if not final_dir.is_relative_to(expected_root):
        raise ValueError(
            f"refusing to install workflow outside skills root: "
            f"{final_dir} not under {expected_root}"
        )

    skills_dir.mkdir(parents=True, exist_ok=True)
    skill_path = skills_dir / "SKILL.md"

    # Re-check after mkdir in case the dir already existed as a symlink
    # pointing elsewhere. (Full O_NOFOLLOW hardening is the v2 TODO at the
    # top of this file — this catch handles the obvious case.)
    final_skill_path = skill_path.resolve()
    if not final_skill_path.is_relative_to(expected_root):
        raise ValueError(
            f"refusing to write SKILL.md outside skills root: "
            f"{final_skill_path} not under {expected_root}"
        )

    template = _read_template("workflow_skill.md.tmpl")
    evidence_chip = _read_template("evidence_chip.md")

    rendered = (
        template.replace("{{workflow_id}}", manifest.workflow_id)
        .replace("{{version}}", manifest.version)
        .replace("{{body_md}}", manifest.body_md.rstrip())
        .replace(
            "{{memory_boundary_policy_version}}",
            str(MEMORY_BOUNDARY_POLICY_VERSION),
        )
    )
    if not rendered.endswith("\n"):
        rendered += "\n"
    rendered += "\n" + evidence_chip
    if not rendered.endswith("\n"):
        rendered += "\n"

    _atomic_write_text(skill_path, rendered)
    logger.info(
        "workflow installed",
        extra={
            "event": "bootstrap.install_workflow",
            "workflow_id": workflow_id,
            "version": manifest.version,
            "path": str(skill_path),
        },
    )
    return InstalledWorkflow(
        workflow_id=workflow_id,
        version=manifest.version,
        skill_path=str(skill_path),
    )
