"""Onboarding state read/write helpers for the using-selph bootstrap."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from ._shared import logger
from ._paths import _state_dir, _onboarding_path
from ._file_locking import _atomic_write_text, _locked_write
from ._cache import ensure_cache_dir

from selph_mcp.skill.state_schema import (
    OnboardingMigrationFailed,
    OnboardingState,
    OnboardingStateCorrupt,
    migrate_onboarding_raw,
    validate_workflow_id,
)
from selph_mcp.contracts.versions import (
    HARNESS_ADAPTER_VERSION,
    MEMORY_BOUNDARY_POLICY_VERSION,
    PERSONA_CONTRACT_VERSION,
)
from selph_mcp.contracts.whoami import Whoami

__all__: list[str] = [
    "reconcile_onboarding",
    "_load_onboarding_state",
    "record_onboarding_complete",
    "update_etag_cursor",
]


def _load_onboarding_state(
    path: Path,
    *,
    allow_migration: bool,
) -> Optional[OnboardingState]:
    """Read, optionally migrate (v1→v2), validate, and return ``OnboardingState``.

    Args:
        path: Absolute path to ``onboarding.json``.
        allow_migration: When True the function will perform v1→v2 migration
            automatically. When False a v1 file raises
            ``OnboardingMigrationFailed`` (safety-net for callers that have
            already ensured migration was done).

    Returns:
        Validated ``OnboardingState``, or ``None`` when the file does not exist.

    Raises:
        OnboardingStateCorrupt: JSON parse failure.
        OnboardingMigrationFailed: v1 detected but ``allow_migration=False``,
            or migration produced a dict that fails v2 validation.
    """
    # Step 1 — read raw bytes.
    if not path.exists():
        return None
    try:
        raw_bytes = path.read_bytes()
    except OSError as exc:
        raise OnboardingStateCorrupt(
            f"could not read onboarding state at {path}: {exc}"
        ) from exc

    # Step 2 — JSON parse.
    try:
        raw_parsed = json.loads(raw_bytes.decode("utf-8", errors="replace"))
    except json.JSONDecodeError as exc:
        raise OnboardingStateCorrupt(
            f"onboarding.json is not valid JSON at {path}: {exc}"
        ) from exc
    if not isinstance(raw_parsed, dict):
        raise OnboardingStateCorrupt(
            f"onboarding.json is not a JSON object at {path}: "
            f"got {type(raw_parsed).__name__}"
        )
    raw: dict = raw_parsed

    migrated = raw
    migration_occurred = False

    # Step 3 — v1→v2 migration if needed.
    if raw.get("schema_version", 1) < 2:
        if not allow_migration:
            raise OnboardingMigrationFailed(
                original_raw=raw_bytes,
                cause=ValueError(
                    "v1 onboarding state detected but migration not allowed "
                    f"at {path}"
                ),
            )
        migrated = migrate_onboarding_raw(raw)
        migration_occurred = True

    # Step 3b — pre-filter malformed workflow IDs (allow_migration path only).
    # If a stale regex-violating ID slipped into installed_workflows we drop it
    # with a warning rather than letting ValidationError cascade to ColdStart,
    # which would lose consumer_id / user_id / etag_cursor for returning users.
    # With allow_migration=False the validator inside OnboardingState still
    # raises, preserving the safety-net path.
    if allow_migration:
        raw_workflows = migrated.get("installed_workflows")
        if raw_workflows is not None and not isinstance(raw_workflows, list):
            logger.warning(
                "dropping non-list installed_workflows from onboarding state",
                extra={
                    "event": "bootstrap.load_onboarding_state.dropped_invalid_installed_workflows_type",
                    "type": repr(type(raw_workflows)),
                    "path": str(path),
                },
            )
            migrated["installed_workflows"] = []
            raw_workflows = []
            migration_occurred = True
        cleaned_workflows: list = []
        for _wf_id in (raw_workflows or []):
            try:
                validate_workflow_id(_wf_id)
                cleaned_workflows.append(_wf_id)
            except ValueError:
                logger.warning(
                    "dropping malformed workflow id from onboarding state",
                    extra={
                        "event": "bootstrap.load_onboarding_state.dropped_invalid_workflow_id",
                        "workflow_id": repr(_wf_id),
                        "path": str(path),
                    },
                )
                migration_occurred = True  # trigger Step 5 writeback
        migrated["installed_workflows"] = cleaned_workflows

    # Step 4 — validate.
    from pydantic import ValidationError
    try:
        state = OnboardingState.model_validate(migrated)
    except ValidationError as exc:
        raise OnboardingMigrationFailed(
            original_raw=raw_bytes,
            cause=exc,
        ) from exc

    # Step 5 — persist migrated result atomically (only when migration ran).
    if migration_occurred:
        try:
            _atomic_write_text(
                path,
                state.model_dump_json(indent=2),
                prefix=".onboarding.",
                suffix=".tmp",
            )
            logger.info(
                "onboarding state migrated v1→v2 and persisted",
                extra={
                    "event": "bootstrap.load_onboarding_state.migrated",
                    "path": str(path),
                },
            )
        except Exception as exc:  # noqa: BLE001
            # Non-fatal: we have the valid in-memory state; disk write failed.
            logger.warning(
                "onboarding state migration could not be persisted to disk",
                extra={
                    "event": "bootstrap.load_onboarding_state.migrate_persist_failed",
                    "path": str(path),
                    "error_type": type(exc).__name__,
                    "error": str(exc)[:300],
                },
            )

    return state


def reconcile_onboarding(workspace: Path, whoami: Whoami) -> OnboardingState:
    """Overwrite ``onboarding.json`` if ``consumer_id`` or ``user_id`` drifted.

    Algorithm (executed under ``_locked_write`` on the onboarding path):

    1. Re-read the existing ``OnboardingState`` inside the lock so concurrent
       callers converge to the same final state.
    2. If ``state.consumer_id == whoami.consumer_id AND state.user_id ==
       whoami.user_id``, return the state without writing (noop path;
       logs ``bootstrap.reconcile_onboarding.noop``).
    3. Otherwise build a new ``OnboardingState`` preserving ALL non-binding
       fields verbatim (``schema_version``, ``persona_contract_version``,
       ``etag_cursor``, ``installed_workflows``, ``completed_at``).
       Only ``consumer_id`` and ``user_id`` are overwritten.
       Writes atomically via ``_atomic_write_text``.
       Logs ``bootstrap.reconcile_onboarding.updated`` with before/after
       ``consumer_id``.

    ``persona_contract_version`` is intentionally NOT touched here — that
    field is ``detect_state``'s responsibility.

    Returns the (possibly updated) :class:`OnboardingState`.

    Raises:
        FileNotFoundError: if no ``onboarding.json`` exists yet (should not
            happen in the returning-user flow — callers must check
            ``detect_state`` first).
    """
    path = _onboarding_path(workspace)
    result: Dict[str, Any] = {}

    def _do_reconcile() -> None:
        # Re-read inside the lock to handle concurrent callers.
        # Use _load_onboarding_state with allow_migration=True to handle the
        # cross-process race where another process wrote a v1 file between
        # detect and reconcile.
        try:
            state = _load_onboarding_state(path, allow_migration=True)
        except Exception as exc:
            logger.warning(
                "reconcile_onboarding: onboarding.json unreadable; skipping reconcile",
                extra={
                    "event": "bootstrap.reconcile_onboarding.read_failed",
                    "error_type": type(exc).__name__,
                    "error": str(exc)[:300],
                },
            )
            raise
        if state is None:
            raise FileNotFoundError(
                f"reconcile_onboarding: onboarding.json disappeared at {path}"
            )

        if (
            state.consumer_id == whoami.consumer_id
            and state.user_id == whoami.user_id
        ):
            logger.info(
                "reconcile_onboarding: no drift; skipping write",
                extra={
                    "event": "bootstrap.reconcile_onboarding.noop",
                    "consumer_id": state.consumer_id,
                    "user_id": state.user_id,
                },
            )
            result["state"] = state
            return

        # Preserve all non-binding fields verbatim (B4 preserve-list).
        prev_consumer_id = state.consumer_id
        new_state = OnboardingState(
            schema_version=state.schema_version,
            consumer_id=whoami.consumer_id,
            user_id=whoami.user_id,
            persona_contract_version=state.persona_contract_version,
            etag_cursor=state.etag_cursor,
            installed_workflows=list(state.installed_workflows),
            completed_at=state.completed_at,
            harness_adapter_version=state.harness_adapter_version,
            memory_boundary_policy_version=state.memory_boundary_policy_version,
        )
        _atomic_write_text(
            path,
            new_state.model_dump_json(indent=2),
            prefix=".onboarding.",
            suffix=".tmp",
        )
        logger.info(
            "reconcile_onboarding: consumer binding updated",
            extra={
                "event": "bootstrap.reconcile_onboarding.updated",
                "prev_consumer_id": prev_consumer_id,
                "new_consumer_id": whoami.consumer_id,
                "user_id": whoami.user_id,
            },
        )
        result["state"] = new_state

    _locked_write(path, _do_reconcile)
    return result["state"]


def record_onboarding_complete(
    workspace: Path,
    *,
    consumer_id: str,
    user_id: str,
    installed_workflows: Optional[List[str]] = None,
    etag_cursor: int = 0,
) -> OnboardingState:
    """Persist ``OnboardingState`` to ``.selph/state/onboarding.json``.

    Idempotent: re-running overwrites in place. Pins the currently-imported
    persona contract version so future ``detect_state`` calls can flag drift.

    Callers should gate this behind :func:`assert_retrieval_ok` in the
    cold-start path — stamping completion on an empty first run traps
    the user in the minimal *returning* flow with no obvious way to
    recover.
    """
    state_dir = _state_dir(workspace)
    state_dir.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(state_dir, 0o700)
    except OSError as exc:
        logger.warning(
            "failed to chmod state dir during onboarding completion",
            extra={
                "event": "bootstrap.record_onboarding.chmod_failed",
                "path": str(state_dir),
                "error_type": type(exc).__name__,
            },
        )

    # ``OnboardingState`` re-validates installed_workflows internally; this
    # construction will raise ValueError if any id violates the allowlist.
    # B3: stamp schema_version=2, harness_adapter_version, and
    # memory_boundary_policy_version on fresh install completion.
    state = OnboardingState(
        schema_version=2,
        consumer_id=consumer_id,
        user_id=user_id,
        persona_contract_version=str(PERSONA_CONTRACT_VERSION),
        etag_cursor=etag_cursor,
        installed_workflows=installed_workflows or [],
        harness_adapter_version=HARNESS_ADAPTER_VERSION,
        memory_boundary_policy_version=MEMORY_BOUNDARY_POLICY_VERSION,
    )
    path = _onboarding_path(workspace)
    serialized = state.model_dump_json(indent=2)

    def _do_write() -> None:
        _atomic_write_text(
            path,
            serialized,
            prefix=".onboarding.",
            suffix=".tmp",
        )

    _locked_write(path, _do_write)

    # Pre-create the cache dir so returning-user reads don't have to handle
    # a missing dir. Mode 0700 to match the state dir.
    ensure_cache_dir(workspace)

    logger.info(
        "onboarding state recorded",
        extra={
            "event": "bootstrap.record_onboarding",
            "path": str(path),
            "consumer_id": consumer_id,
            "user_id": user_id,
            "installed_workflows": installed_workflows or [],
            "etag_cursor": etag_cursor,
        },
    )
    return state


def update_etag_cursor(workspace: Path, cursor: int) -> OnboardingState:
    """Bump the stored ``etag_cursor`` to ``cursor`` (monotonic).

    Refuses to move backwards — silently keeps the higher value. Logs both
    the old and new cursor so the handshake replay path is auditable.

    Read/check/write happens entirely inside ``_file_lock`` so two concurrent
    advances from different sessions can't both observe the smaller stored
    value and overwrite each other. Final on-disk value will equal
    ``max(all_requested_cursors, stored_cursor)``.
    """
    if cursor < 0:
        raise ValueError("etag cursor must be non-negative")

    path = _onboarding_path(workspace)
    if not path.exists():
        raise FileNotFoundError(
            f"cannot update etag cursor; no onboarding state at {path}"
        )

    result: Dict[str, OnboardingState] = {}

    def _do_write() -> None:
        # Re-read inside the lock so the monotonicity check is against the
        # most-recent stored value, not a stale snapshot from before
        # contention. Use _load_onboarding_state with allow_migration=True to
        # handle cross-process race where another process wrote a v1 file.
        loaded = _load_onboarding_state(path, allow_migration=True)
        if loaded is None:
            raise FileNotFoundError(
                f"update_etag_cursor: onboarding.json disappeared at {path}"
            )
        state = loaded
        if cursor < state.etag_cursor:
            logger.warning(
                "refusing to move etag cursor backwards",
                extra={
                    "event": "bootstrap.update_etag_cursor.regression",
                    "stored": state.etag_cursor,
                    "requested": cursor,
                },
            )
            result["state"] = state
            return
        new_state = state.model_copy(update={"etag_cursor": cursor})
        _atomic_write_text(
            path,
            new_state.model_dump_json(indent=2),
            prefix=".onboarding.",
            suffix=".tmp",
        )
        logger.info(
            "etag cursor advanced",
            extra={
                "event": "bootstrap.update_etag_cursor",
                "previous": state.etag_cursor,
                "current": cursor,
            },
        )
        result["state"] = new_state

    _locked_write(path, _do_write)
    return result["state"]
