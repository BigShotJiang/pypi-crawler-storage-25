"""Remote MCP entry writer for the using-selph bootstrap (Phase D).

Writes a ``type: "http"`` entry pointing at ``<api_url>/mcp`` with both
``Authorization: Bearer ...`` and ``X-Consumer-Id: ...`` headers.

This is the Phase D replacement for ``write_mcp_entry_pipx()`` which wrote
a ``type: "stdio"`` entry for the shelved local wheel transport.  The two
functions coexist as siblings so the legacy stdio writer remains cleanly
removable (Phase A cleanup) without touching this file.

Migration semantics
-------------------
When ``write_mcp_entry_remote()`` detects an existing ``selph`` (stdio)
entry in ``~/.claude.json``, it removes that key silently, writes one log
line, and appends a ``{from, to, at}`` entry to
``<state_dir>/state.json``'s ``migrations`` list.  This handles the
migration for users currently on the stdio wheel and satisfies the §5 Q5
brief decision ("silent + log line + audit entry").
"""

from __future__ import annotations

import json
import os
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Union

from ._shared import logger, _now_iso
from ._file_locking import _atomic_write_text, _locked_write
from ._credentials import hydrate_from_global_credentials, _global_credentials_path_for_log
from ._paths import _state_dir

__all__: list[str] = ["write_mcp_entry_remote"]

# Server-key names
_LEGACY_STDIO_KEY = "selph"   # the old stdio entry key
_REMOTE_KEY = "selph-remote"  # the new HTTP entry key


def _append_migration_audit(
    workspace: Optional[Union[str, Path]],
    from_key: str,
    to_key: str,
) -> None:
    """Append a migration record to ``.selph/state.json`` migrations list.

    Best-effort: if the state file cannot be read or written, we log and
    continue rather than aborting the migration.

    Args:
        workspace: Workspace root or None (falls back to cwd-relative
            ``.selph/`` if no workspace is provided; migration audit is
            best-effort so None is acceptable).
        from_key: The server key that was removed (e.g. ``"selph"``).
        to_key: The server key that was written (e.g. ``"selph-remote"``).
    """
    if workspace is None:
        return

    state_file = _state_dir(Path(workspace)) / "state.json"
    try:
        state_file.parent.mkdir(parents=True, exist_ok=True)
        if state_file.exists():
            raw = state_file.read_text(encoding="utf-8")
            data: Dict[str, Any] = json.loads(raw)
        else:
            data = {}

        migrations = data.get("migrations")
        if not isinstance(migrations, list):
            migrations = []
        migrations.append({
            "from": from_key,
            "to": to_key,
            "at": _now_iso(),
        })
        data["migrations"] = migrations
        _atomic_write_text(state_file, json.dumps(data, indent=2, sort_keys=True) + "\n")
    except Exception as exc:  # noqa: BLE001 — best-effort
        logger.warning(
            "migration audit write failed",
            extra={
                "event": "bootstrap.write_mcp_entry_remote.audit_failed",
                "state_file": str(state_file),
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )


def write_mcp_entry_remote(
    *,
    api_url: str,
    bearer_token: str,
    consumer_id: str,
    server_name: str = _REMOTE_KEY,
    claude_config: Union[str, Path, None] = None,
    workspace: Union[str, Path, None] = None,
    require_global_credentials: bool = False,
) -> bool:
    """Write/refresh the user's ``~/.claude.json`` MCP entry for the remote HTTP MCP.

    Writes a ``type: "http"`` entry pointing at ``<api_url>/mcp`` with both
    ``Authorization: Bearer <token>`` and ``X-Consumer-Id: <consumer_id>``
    headers — the two headers required by ``ingestion_api/mcp_mount_auth.py``.

    Migration: if a legacy ``selph`` (stdio) entry exists, it is removed.
    One log line is emitted and an audit record is appended to
    ``.selph/state.json``.

    Idempotent: if the entry already matches the target shape, no write is
    performed and returns ``False``.

    Read/modify/write is protected by ``_file_lock`` so concurrent
    ``/using-selph`` runs cannot clobber other ``mcpServers`` entries via a
    last-writer-wins race.

    Args:
        api_url: Base URL of the Selph API (e.g.
            ``"https://selph-api.example.com"``).  The MCP transport path
            ``/mcp`` is appended automatically.
        bearer_token: Bearer token issued by ``selph-mcp-bootstrap register``.
        consumer_id: Consumer identifier (e.g. ``"cns-ab12cd34"``).
        server_name: MCP server key under ``mcpServers``
            (default ``"selph-remote"``).
        claude_config: Override the path to ``~/.claude.json`` for tests.
        workspace: Workspace root for the migration audit state file.
            If ``None``, the audit is skipped (best-effort).
        require_global_credentials: When True, verify that the global
            credentials file exists before writing.  Default is False because
            the caller (SKILL.md / CLI) supplies the credentials explicitly.

    Returns:
        ``True`` if the file was written or modified; ``False`` if the
        existing entry already matched (idempotent noop).

    Raises:
        RuntimeError: when ``require_global_credentials`` is True and no
            global credentials file is present.
    """
    logger.info(
        "write_mcp_entry_remote entry",
        extra={
            "event": "bootstrap.write_mcp_entry_remote.entry",
            "api_url": api_url,
            "consumer_id": consumer_id,
            "server_name": server_name,
        },
    )

    if require_global_credentials and hydrate_from_global_credentials() is None:
        raise RuntimeError(
            "refusing to write ~/.claude.json: no global selph-mcp "
            "credentials file found at "
            f"{_global_credentials_path_for_log()}. Run "
            "`selph-mcp-bootstrap register --user-id <id> --api-key <key>` first."
        )

    mcp_url = api_url.rstrip("/") + "/mcp"
    path = Path(claude_config) if claude_config else Path.home() / ".claude.json"

    target: Dict[str, Any] = {
        "type": "http",
        "url": mcp_url,
        "headers": {
            "Authorization": f"Bearer {bearer_token}",
            "X-Consumer-Id": consumer_id,
        },
    }

    changed = {"value": False}
    migrated_from_stdio = {"value": False}

    def _do_write() -> None:
        cfg: Dict[str, Any]
        if path.exists():
            try:
                cfg = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                bak_path = path.with_suffix(
                    f".json.selph-bak.{int(time.time())}"
                )
                try:
                    shutil.copy2(path, bak_path)
                    try:
                        os.chmod(bak_path, 0o600)
                    except OSError as chmod_exc:
                        logger.warning(
                            "failed to chmod backup file",
                            extra={
                                "event": "bootstrap.write_mcp_entry_remote.backup_chmod_failed",
                                "path": str(bak_path),
                                "error_type": type(chmod_exc).__name__,
                                "error": str(chmod_exc)[:200],
                            },
                        )
                    backup_note = str(bak_path)
                except Exception as bak_exc:  # noqa: BLE001
                    backup_note = f"<backup failed: {bak_exc}>"
                logger.warning(
                    "claude config unreadable; backed up and will overwrite",
                    extra={
                        "event": "bootstrap.write_mcp_entry_remote.unreadable",
                        "path": str(path),
                        "backup_path": backup_note,
                        "error_type": type(exc).__name__,
                        "error": str(exc)[:200],
                    },
                )
                cfg = {}
        else:
            cfg = {}

        if not isinstance(cfg.get("mcpServers"), dict):
            cfg["mcpServers"] = {}

        # Detect and silently remove any legacy stdio entry under key "selph".
        if _LEGACY_STDIO_KEY in cfg["mcpServers"]:
            old_entry = cfg["mcpServers"].pop(_LEGACY_STDIO_KEY)
            migrated_from_stdio["value"] = True
            logger.info(
                "removed legacy stdio selph entry from ~/.claude.json",
                extra={
                    "event": "bootstrap.write_mcp_entry_remote.legacy_removed",
                    "removed_key": _LEGACY_STDIO_KEY,
                    "old_type": old_entry.get("type", "unknown"),
                    "path": str(path),
                },
            )

        existing = cfg["mcpServers"].get(server_name)
        if isinstance(existing, dict) and not migrated_from_stdio["value"]:
            # Check if the entry already matches target exactly.
            existing_headers = existing.get("headers", {})
            target_headers = target["headers"]
            if (
                existing.get("type") == target["type"]
                and existing.get("url") == target["url"]
                and existing_headers.get("Authorization") == target_headers["Authorization"]
                and existing_headers.get("X-Consumer-Id") == target_headers["X-Consumer-Id"]
            ):
                logger.debug(
                    "remote mcp entry already matches target",
                    extra={
                        "event": "bootstrap.write_mcp_entry_remote.noop",
                        "server_name": server_name,
                    },
                )
                return

        cfg["mcpServers"][server_name] = target
        serialized = json.dumps(cfg, indent=2, sort_keys=True)
        _atomic_write_text(path, serialized + "\n", mode=0o600)
        changed["value"] = True
        logger.info(
            "remote mcp entry written",
            extra={
                "event": "bootstrap.write_mcp_entry_remote.written",
                "path": str(path),
                "server_name": server_name,
                "mcp_url": mcp_url,
                "migrated_from_stdio": migrated_from_stdio["value"],
            },
        )

    _locked_write(path, _do_write)

    if migrated_from_stdio["value"] and workspace is not None:
        _append_migration_audit(workspace, _LEGACY_STDIO_KEY, server_name)

    if changed["value"]:
        logger.info(
            "write_mcp_entry_remote complete",
            extra={
                "event": "bootstrap.write_mcp_entry_remote.complete",
                "changed": True,
                "migrated_from_stdio": migrated_from_stdio["value"],
            },
        )
    return changed["value"]
