"""Credential read/write helpers for the using-selph bootstrap."""

from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Union

from ._shared import logger, _now_iso
from ._paths import _state_dir, _credentials_path
from ._file_locking import _atomic_write_text, _locked_write
from ._gitignore import ensure_gitignore

__all__: list[str] = [
    "CredentialsRecord",
    "hydrate_from_claude_code_config",
    "hydrate_from_global_credentials",
    "_global_credentials_path_for_log",
    "write_credentials",
]


def hydrate_from_claude_code_config(
    claude_config: Union[str, Path, None] = None,
    server_name: str = "selph",
) -> Optional[Dict[str, str]]:
    """Read credentials out of a user-scope Claude Code MCP registration.

    When ``scripts/install_mcp.py`` has already wired the MCP into
    ``~/.claude.json``, the first-run flow in SKILL.md should NOT prompt
    for endpoint/API key/user_id again, and should NOT mint a new
    ``mcp_consumers`` row — the installer did both. This helper lets the
    skill short-circuit the credential-minting half of the first-run flow
    by reading what the installer wrote.

    Returns a dict with ``consumer_id``, ``user_id``, ``api_key``, and
    optionally ``mcp_endpoint`` when present — or ``None`` if no Claude
    Code config exists, the target server is not registered, or the env
    block is missing the required fields.

    Pure; never writes; never raises. Missing config files or malformed
    JSON produce a debug log and a ``None`` return so the caller can fall
    through to the interactive prompt path.
    """
    path = Path(claude_config) if claude_config else Path.home() / ".claude.json"
    if not path.exists():
        logger.debug(
            "no Claude Code config found",
            extra={
                "event": "bootstrap.hydrate_from_claude_code_config.missing",
                "path": str(path),
            },
        )
        return None
    try:
        cfg = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        logger.debug(
            "Claude Code config unreadable",
            extra={
                "event": "bootstrap.hydrate_from_claude_code_config.unreadable",
                "path": str(path),
                "error_type": type(exc).__name__,
            },
        )
        return None
    servers = cfg.get("mcpServers") or {}
    server = servers.get(server_name)
    if not server:
        return None
    env = server.get("env") or {}
    consumer_id = env.get("SELPH_CONSUMER_ID")
    user_id = env.get("SELPH_USER_ID")
    api_key = env.get("SELPH_API_KEY")
    if not (consumer_id and user_id and api_key):
        logger.debug(
            "Claude Code selph entry missing required env fields",
            extra={
                "event": "bootstrap.hydrate_from_claude_code_config.incomplete",
                "has_consumer_id": bool(consumer_id),
                "has_user_id": bool(user_id),
                "has_api_key": bool(api_key),
            },
        )
        return None
    result: Dict[str, str] = {
        "consumer_id": consumer_id,
        "user_id": user_id,
        "api_key": api_key,
    }
    # ``type: stdio`` entries don't carry a URL; streamable-http / SSE
    # entries do. Both are valid — only the HTTP case needs the endpoint.
    url = server.get("url") or env.get("SELPH_DEPLOYED_URL")
    if url:
        result["mcp_endpoint"] = url
    return result


def hydrate_from_global_credentials() -> Optional[Dict[str, str]]:
    """Read identity from ``$XDG_CONFIG_HOME/selph-mcp/credentials.json``.

    This is the pipx-era replacement for ``hydrate_from_claude_code_config``.
    Once the user has run ``selph-mcp-bootstrap register`` (the wheel's
    console script — see :mod:`selph_mcp.bootstrap.cli`), the identity
    needed by the 4-step MCP chain (consumer_id / user_id / api_url /
    bearer_token) lives in a chmod-0600 JSON file at a stable path,
    independent of ``~/.claude.json`` and independent of any workspace.

    Returns:
        Dict with ``consumer_id``, ``user_id``, ``api_url``, ``bearer_token``,
        and (when present) ``self_entity_id`` / ``api_key`` /
        ``mcp_endpoint``. Returns ``None`` if the file is absent or
        unreadable — callers fall back to interactive prompts.

    Pure: never writes; never raises.
    """
    # Lazy import — keep adapters surface stdlib-only at module load. The
    # wheel's bootstrap.credentials module is itself stdlib-only at runtime.
    try:
        from selph_mcp.bootstrap.credentials import load_credentials
    except Exception as exc:  # noqa: BLE001
        logger.debug(
            "selph_mcp.bootstrap.credentials unavailable",
            extra={
                "event": "bootstrap.hydrate_from_global_credentials.import_failed",
                "error_type": type(exc).__name__,
            },
        )
        return None

    try:
        creds = load_credentials()
    except Exception as exc:  # noqa: BLE001
        logger.debug(
            "global credentials unreadable",
            extra={
                "event": "bootstrap.hydrate_from_global_credentials.load_failed",
                "error_type": type(exc).__name__,
            },
        )
        return None

    if not creds:
        return None
    consumer_id = creds.get("consumer_id")
    user_id = creds.get("user_id")
    api_url = creds.get("api_url")
    bearer_token = creds.get("bearer_token")
    if not (consumer_id and user_id and api_url and bearer_token):
        logger.debug(
            "global credentials missing required fields",
            extra={
                "event": "bootstrap.hydrate_from_global_credentials.incomplete",
                "has_consumer_id": bool(consumer_id),
                "has_user_id": bool(user_id),
                "has_api_url": bool(api_url),
                "has_bearer_token": bool(bearer_token),
            },
        )
        return None

    out: Dict[str, str] = {
        "consumer_id": consumer_id,
        "user_id": user_id,
        "api_url": api_url,
        "bearer_token": bearer_token,
        # Mirror under the legacy mcp_endpoint name so callers that already
        # expect that key (hydrate_from_claude_code_config style) keep working.
        "mcp_endpoint": api_url,
    }
    for optional_key in ("self_entity_id", "api_key", "harness_id", "display_name"):
        v = creds.get(optional_key)
        if v:
            out[optional_key] = v
    return out


def _global_credentials_path_for_log() -> str:
    """Best-effort path string for error messages — returns '<unknown>' on import failure."""
    try:
        from selph_mcp.bootstrap.credentials import credentials_path
        return str(credentials_path())
    except Exception:  # noqa: BLE001
        return "<unknown — selph_mcp.bootstrap.credentials unavailable>"


@dataclass(frozen=True)
class CredentialsRecord:
    """Returned by ``write_credentials`` for SKILL.md to confirm placement.

    ``api_key`` is intentionally omitted — never returned, never logged.
    """

    path: str
    consumer_id: str
    user_id: str
    mcp_endpoint: str
    mode: int


def write_credentials(
    workspace: Path,
    *,
    consumer_id: str,
    user_id: str,
    mcp_endpoint: str,
    api_key: Optional[str] = None,
) -> CredentialsRecord:
    """Write ``.selph/state/credentials.json`` with mode 0600.

    Always runs ``ensure_gitignore`` first per the brief. Idempotent —
    re-running with the same args overwrites in place and re-applies 0600
    perms. ``api_key`` is optional (bearer-auth flows do not carry one) and
    is omitted from the written payload when empty. ``api_key`` value is
    never written to logs.
    """
    if not consumer_id or not user_id or not mcp_endpoint:
        raise ValueError(
            "consumer_id, user_id, and mcp_endpoint are all required"
        )

    # Order matters: gitignore BEFORE write so credentials never land in a
    # commit even if Claude Code is interrupted between calls.
    ensure_gitignore(workspace)

    state_dir = _state_dir(workspace)
    state_dir.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(state_dir, 0o700)
    except OSError as exc:
        logger.warning(
            "failed to chmod state dir to 0700",
            extra={
                "event": "bootstrap.write_credentials.chmod_dir_failed",
                "path": str(state_dir),
                "error_type": type(exc).__name__,
            },
        )

    path = _credentials_path(workspace)
    payload: dict = {
        "consumer_id": consumer_id,
        "user_id": user_id,
        "mcp_endpoint": mcp_endpoint,
        "credential_version": 1,
        "created_at": _now_iso(),
    }
    if api_key:
        payload["api_key"] = api_key

    # Atomic write under a file lock. Tmp filename is unique per call
    # (``tempfile.mkstemp``) so concurrent writers don't collide on a fixed
    # ``credentials.json.tmp`` path. chmod 0600 is applied to the tmp file
    # BEFORE the rename so the credentials file is never on-disk with looser
    # perms than 0600, even momentarily.
    serialized = json.dumps(payload, indent=2, sort_keys=True)

    def _do_write() -> None:
        _atomic_write_text(
            path,
            serialized,
            mode=0o600,
            prefix=".credentials.",
            suffix=".tmp",
        )
        # Re-chmod after rename as belt-and-braces in case ``os.replace``
        # inherited target perms on some platforms.
        try:
            os.chmod(path, 0o600)
        except OSError as exc:
            logger.warning(
                "failed to chmod credentials to 0600",
                extra={
                    "event": "bootstrap.write_credentials.chmod_failed",
                    "path": str(path),
                    "error_type": type(exc).__name__,
                },
            )

    _locked_write(path, _do_write)
    mode = stat.S_IMODE(path.stat().st_mode)
    logger.info(
        "credentials written",
        extra={
            "event": "bootstrap.write_credentials",
            "path": str(path),
            "consumer_id": consumer_id,
            "user_id": user_id,
            "mode": oct(mode),
        },
    )
    return CredentialsRecord(
        path=str(path),
        consumer_id=consumer_id,
        user_id=user_id,
        mcp_endpoint=mcp_endpoint,
        mode=mode,
    )
