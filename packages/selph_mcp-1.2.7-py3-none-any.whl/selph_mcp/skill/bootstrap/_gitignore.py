"""Gitignore helper for the using-selph bootstrap."""

from __future__ import annotations

from pathlib import Path

from ._shared import logger, _read_template
from ._paths import _gitignore_path
from ._file_locking import _atomic_write_text, _locked_write

__all__: list[str] = ["ensure_gitignore"]

_GITIGNORE_MARKER = "# selph:using-selph"


def ensure_gitignore(workspace: Path) -> bool:
    """Ensure ``.selph/`` is ignored by git. Idempotent.

    Returns True if the file was modified (or created), False if no change.
    Always called BEFORE ``write_credentials`` so the credentials file is
    never staged into a commit even momentarily.

    Read/modify/write is protected by ``_file_lock`` so two concurrent
    bootstrap runs can't both append the same block.
    """
    path = _gitignore_path(workspace)
    changed = {"value": False}

    def _do_write() -> None:
        existing = path.read_text(encoding="utf-8") if path.exists() else ""
        if _GITIGNORE_MARKER in existing or "\n.selph/\n" in f"\n{existing}\n":
            logger.debug(
                ".gitignore already excludes .selph/",
                extra={"event": "bootstrap.ensure_gitignore", "changed": False},
            )
            return
        block = _read_template("gitignore.block")
        sep = "" if existing.endswith("\n") or existing == "" else "\n"
        _atomic_write_text(path, existing + sep + block)
        changed["value"] = True
        logger.info(
            ".gitignore updated to exclude .selph/",
            extra={
                "event": "bootstrap.ensure_gitignore",
                "changed": True,
                "path": str(path),
            },
        )

    _locked_write(path, _do_write)
    return changed["value"]
