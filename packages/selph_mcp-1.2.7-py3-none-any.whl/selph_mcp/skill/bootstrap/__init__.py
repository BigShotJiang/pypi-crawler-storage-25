"""Deterministic filesystem helpers for the ``using-selph`` Claude Code skill.

This sub-package is the thin Python adapter behind ``SKILL.md``. It
deliberately holds **no interactive prompt loop and no async I/O** —
Claude Code drives the proposal-first menu (§5.8) and all user dialogue
from inside SKILL.md by reading MCP tool responses and rendering numbered
choices in chat.

Every filesystem write here is idempotent. Re-running ``/using-selph``
after a partial failure must converge to the same final state without
ever overwriting user content (CLAUDE.md is append-only behind a marker
comment; the ``.gitignore`` rule is added once; credentials.json gets
re-chmodded).

Layer/import constraints (per ``.importlinter`` rule
``adapters-surface-only``):

- ALLOWED: ``selph_mcp.contracts``, ``selph_utils``, stdlib, this package.
- FORBIDDEN: ``selph_core``, ``selph_db``, ``selph_graph``, ``ingestion_api``,
  ``selph_apps``. Adapters never reach into Core or other Surfaces.

Sub-module layout
-----------------
- ``_shared``        — logger (pinned name), _now_iso, _read_template, fcntl block
- ``_paths``         — resolve_workspace_root, _state_dir, _credentials_path, etc.
- ``_file_locking``  — _file_lock, _atomic_write_text, _locked_write
- ``_credentials``   — CredentialsRecord, hydrate_from_*, write_credentials
- ``_mcp_config``         — write_mcp_entry_pipx
- ``_mcp_config_remote``  — write_mcp_entry_remote (Phase D)
- ``_cache``         — ensure_cache_dir, purge_cache, handshake_and_purge_if_revoked,
                       fetch_whoami
- ``_onboarding``    — reconcile_onboarding, _load_onboarding_state,
                       record_onboarding_complete, update_etag_cursor
- ``_claude_md``     — rewrite_generated_block, append_claude_md_block,
                       install_retrieval_policy_block
- ``_slash_command`` — _slash_command_path, refresh_slash_command
- ``_state_detect``  — detect_state
- ``_gitignore``     — ensure_gitignore
- ``_workflow_install`` — _get_official_manifest, InstalledWorkflow, install_workflow
- ``_health``        — RetrievalHealthError, assert_retrieval_ok
- ``_migration``     — MigrationOutcome, migrate_workflow_skill
"""

from __future__ import annotations

# ── shared infrastructure ─────────────────────────────────────────────────────
from ._shared import (
    _now_iso,
    _read_template,
    fcntl,
    logger,
)

# ── path helpers ──────────────────────────────────────────────────────────────
from ._paths import (
    _cache_dir,
    _claude_md_path,
    _credentials_path,
    _gitignore_path,
    _onboarding_path,
    _skills_dir,
    _skills_root,
    _state_dir,
    resolve_workspace_root,
)

# ── file-locking / atomic write ───────────────────────────────────────────────
from ._file_locking import (
    _WINDOWS_LOCK_NOTICE_EMITTED,
    _atomic_write_text,
    _file_lock,
    _locked_write,
)

# ── gitignore (imported before _credentials to break the _credentials → _gitignore dep) ──
from ._gitignore import ensure_gitignore

# ── credentials ───────────────────────────────────────────────────────────────
from ._credentials import (
    CredentialsRecord,
    _global_credentials_path_for_log,
    hydrate_from_claude_code_config,
    hydrate_from_global_credentials,
    write_credentials,
)

# ── MCP config ────────────────────────────────────────────────────────────────
from ._mcp_config import write_mcp_entry_pipx
from ._mcp_config_remote import write_mcp_entry_remote

# ── cache + whoami ────────────────────────────────────────────────────────────
from ._cache import (
    ensure_cache_dir,
    fetch_whoami,
    handshake_and_purge_if_revoked,
    purge_cache,
)

# ── onboarding state ──────────────────────────────────────────────────────────
from ._onboarding import (
    _load_onboarding_state,
    record_onboarding_complete,
    reconcile_onboarding,
    update_etag_cursor,
)

# ── CLAUDE.md helpers ─────────────────────────────────────────────────────────
from ._claude_md import (
    append_claude_md_block,
    install_retrieval_policy_block,
    rewrite_generated_block,
)

# ── slash-command self-update ─────────────────────────────────────────────────
from ._slash_command import (
    _slash_command_path,
    refresh_slash_command,
)

# ── modular skill-tree install/repair ─────────────────────────────────────────
from ._skill_tree import (
    SKILL_TREE_MANIFEST,
    install_skill_tree,
    skill_tree_root,
)

# ── state detection ───────────────────────────────────────────────────────────
from ._state_detect import detect_state

# ── workflow install ──────────────────────────────────────────────────────────
from ._workflow_install import (
    InstalledWorkflow,
    _get_official_manifest,
    install_workflow,
)

# ── retrieval health guard ────────────────────────────────────────────────────
from ._health import RetrievalHealthError, assert_retrieval_ok

# ── workflow skill migration ──────────────────────────────────────────────────
from ._migration import MigrationOutcome, migrate_workflow_skill

# ── version constants (re-exported for bootstrap.<name> attribute access) ─────
from selph_mcp.contracts.versions import (
    HARNESS_ADAPTER_VERSION,
    MEMORY_BOUNDARY_POLICY_VERSION,
    PERSONA_CONTRACT_VERSION,
)

# ── Whoami re-export (used by callers via bootstrap.Whoami) ───────────────────
from selph_mcp.contracts.whoami import Whoami

# ── public surface ────────────────────────────────────────────────────────────
__all__ = [
    # Dataclasses / exceptions
    "CredentialsRecord",
    "InstalledWorkflow",
    "MigrationOutcome",
    "RetrievalHealthError",
    "Whoami",
    # Public functions
    "append_claude_md_block",
    "assert_retrieval_ok",
    "detect_state",
    "ensure_cache_dir",
    "ensure_gitignore",
    "fetch_whoami",
    "handshake_and_purge_if_revoked",
    "hydrate_from_claude_code_config",
    "hydrate_from_global_credentials",
    "install_retrieval_policy_block",
    "install_skill_tree",
    "install_workflow",
    "migrate_workflow_skill",
    "purge_cache",
    "reconcile_onboarding",
    "record_onboarding_complete",
    "refresh_slash_command",
    "resolve_workspace_root",
    "rewrite_generated_block",
    "skill_tree_root",
    "update_etag_cursor",
    "write_credentials",
    "write_mcp_entry_pipx",
    "write_mcp_entry_remote",
    # Constants
    "SKILL_TREE_MANIFEST",
    # Version constants
    "HARNESS_ADAPTER_VERSION",
    "MEMORY_BOUNDARY_POLICY_VERSION",
    "PERSONA_CONTRACT_VERSION",
]
