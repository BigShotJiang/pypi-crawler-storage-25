"""Path resolution helpers for the using-selph bootstrap."""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Union

from ._shared import logger

from selph_mcp.skill.state_schema import validate_workflow_id

__all__: list[str] = [
    "resolve_workspace_root",
    "_state_dir",
    "_credentials_path",
    "_onboarding_path",
    "_claude_md_path",
    "_skills_root",
    "_skills_dir",
    "_cache_dir",
    "_gitignore_path",
]


def resolve_workspace_root(start: Union[str, Path, None] = None) -> Path:
    """Resolve the workspace root.

    Strategy: prefer the git top-level if ``start`` (or cwd) lives inside a
    git repo; otherwise fall back to the directory itself. Matches the
    decision recorded in the Phase 4 brief.

    Accepts ``str`` or ``Path`` for ``start`` because slash-command prompts
    pass workspace paths as plain strings — rejecting those here produced a
    cryptic ``AttributeError: 'str' object has no attribute 'resolve'`` at
    the very first line of ``/using-selph``.

    Pure: never writes; never errors. If ``git`` is unavailable (or the
    invocation fails for any reason) we silently fall back to ``start``.
    """
    if start is None:
        base = Path.cwd().resolve()
    else:
        base = Path(start).resolve()
    try:
        proc = subprocess.run(
            ["git", "-C", str(base), "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
    except (FileNotFoundError, subprocess.SubprocessError) as exc:
        logger.debug(
            "git lookup failed during workspace resolution",
            extra={"event": "workspace.git_unavailable", "error": str(exc)},
        )
        return base

    if proc.returncode == 0:
        top = proc.stdout.strip()
        if top:
            return Path(top).resolve()
    return base


def _state_dir(workspace: Path) -> Path:
    return workspace / ".selph" / "state"


def _credentials_path(workspace: Path) -> Path:
    return _state_dir(workspace) / "credentials.json"


def _onboarding_path(workspace: Path) -> Path:
    return _state_dir(workspace) / "onboarding.json"


def _claude_md_path(workspace: Path) -> Path:
    return workspace / "CLAUDE.md"


def _skills_root(workspace: Path) -> Path:
    return workspace / ".claude" / "skills"


def _skills_dir(workspace: Path, workflow_id: str) -> Path:
    """Build the per-workflow skills directory path.

    ``workflow_id`` is re-validated here as defense-in-depth — even though
    ``WorkflowManifest`` enforces the same allowlist via Pydantic, callers may
    pass a raw string from an untrusted source.
    """
    validate_workflow_id(workflow_id)
    return _skills_root(workspace) / workflow_id


def _cache_dir(workspace: Path) -> Path:
    return workspace / ".selph" / "cache"


def _gitignore_path(workspace: Path) -> Path:
    return workspace / ".gitignore"
