"""Workflow skill migration helper for the using-selph bootstrap (Phase C2)."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from ._shared import logger, _read_template
from ._paths import _skills_dir
from ._file_locking import _atomic_write_text
from ._claude_md import rewrite_generated_block
from ._workflow_install import _get_official_manifest, install_workflow

from selph_mcp.contracts.versions import MEMORY_BOUNDARY_POLICY_VERSION

__all__: list[str] = ["MigrationOutcome", "migrate_workflow_skill"]

# Workflow-skill markers — mirrored from _workflow_install so _migration is
# self-contained without a cross-import that would be circular via __init__.
_WORKFLOW_SKILL_MARKER_START = "<!-- selph:workflow-skill:v1 START -->"
_WORKFLOW_SKILL_MARKER_END = "<!-- selph:workflow-skill:v1 END -->"


@dataclass(frozen=True)
class MigrationOutcome:
    """Result of :func:`migrate_workflow_skill`.

    ``kind`` values:
    - ``"noop"`` — markers present and content already matches current render.
    - ``"marker_replaced"`` — markers present; content updated in place.
    - ``"legacy_rewrite"`` — no markers; full-file rewrite from current manifest.
    - ``"reinstalled"`` — SKILL.md was absent; full reinstall via ``install_workflow``.
    - ``"unmanaged_skipped"`` — workflow_id not in official list; no mutation.
    """

    kind: str  # Literal above for docs; str avoids a Literal import here
    drift_reason: Optional[str] = None


def migrate_workflow_skill(
    workspace: Path,
    workflow_id: str,
    *,
    current_template_version: int,
) -> MigrationOutcome:
    """Upgrade a Selph-managed workflow SKILL.md to the current template version.

    Behavior:
    - ``workflow_id`` not in ``list_official_workflow_ids()`` → ``unmanaged_skipped``
      (no file mutation).
    - SKILL.md absent → full reinstall via ``install_workflow`` → ``reinstalled``.
    - SKILL.md present + ``_WORKFLOW_SKILL_MARKER_START`` markers present and
      content already matches current render → ``noop``.
    - SKILL.md present + markers present but content differs → replace content
      between markers via ``rewrite_generated_block`` → ``marker_replaced``.
    - SKILL.md present but no markers (legacy markerless install) → full-file
      rewrite from current manifest → ``legacy_rewrite``.
    """
    logger.info(
        "migrate_workflow_skill: starting",
        extra={
            "event": "bootstrap.migrate_workflow_skill.entry",
            "workflow_id": workflow_id,
            "current_template_version": current_template_version,
        },
    )

    # Rule 5 inventory: re-verify workflow_id is official via runtime call.
    manifest = _get_official_manifest(workflow_id)
    if manifest is None:
        logger.info(
            "migrate_workflow_skill: workflow not official; skipping",
            extra={
                "event": "bootstrap.migrate_workflow_skill.unmanaged_skipped",
                "workflow_id": workflow_id,
            },
        )
        return MigrationOutcome(kind="unmanaged_skipped")

    skill_path = _skills_dir(workspace, workflow_id) / "SKILL.md"

    if not skill_path.exists():
        # Full reinstall.
        install_workflow(workspace, workflow_id, manifest=manifest)
        logger.info(
            "migrate_workflow_skill: SKILL.md absent; reinstalled",
            extra={
                "event": "bootstrap.migrate_workflow_skill.reinstalled",
                "workflow_id": workflow_id,
                "path": str(skill_path),
            },
        )
        return MigrationOutcome(kind="reinstalled", drift_reason="skill_md_missing")

    try:
        existing_text = skill_path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.warning(
            "migrate_workflow_skill: cannot read SKILL.md; skipping",
            extra={
                "event": "bootstrap.migrate_workflow_skill.read_failed",
                "workflow_id": workflow_id,
                "error_type": type(exc).__name__,
                "error": str(exc)[:300],
            },
        )
        return MigrationOutcome(kind="unmanaged_skipped", drift_reason="read_error")

    # Build the rendered inner content (body only — markers wrap it).
    template = _read_template("workflow_skill.md.tmpl")
    evidence_chip = _read_template("evidence_chip.md")
    rendered_inner = (
        template.replace("{{workflow_id}}", manifest.workflow_id)
        .replace("{{version}}", manifest.version)
        .replace("{{body_md}}", manifest.body_md.rstrip())
        .replace(
            "{{memory_boundary_policy_version}}",
            str(MEMORY_BOUNDARY_POLICY_VERSION),
        )
    )
    if not rendered_inner.endswith("\n"):
        rendered_inner += "\n"
    rendered_inner += "\n" + evidence_chip
    if not rendered_inner.endswith("\n"):
        rendered_inner += "\n"

    _has_start = _WORKFLOW_SKILL_MARKER_START in existing_text
    _has_end = _WORKFLOW_SKILL_MARKER_END in existing_text
    if _has_start and _has_end:
        # Both markers present — update block in-place.
        modified = rewrite_generated_block(
            skill_path,
            _WORKFLOW_SKILL_MARKER_START,
            _WORKFLOW_SKILL_MARKER_END,
            rendered_inner,
        )
        if not modified:
            logger.info(
                "migrate_workflow_skill: content already current; noop",
                extra={
                    "event": "bootstrap.migrate_workflow_skill.noop",
                    "workflow_id": workflow_id,
                },
            )
            return MigrationOutcome(kind="noop")
        logger.info(
            "migrate_workflow_skill: marker block updated",
            extra={
                "event": "bootstrap.migrate_workflow_skill.marker_replaced",
                "workflow_id": workflow_id,
                "path": str(skill_path),
            },
        )
        return MigrationOutcome(kind="marker_replaced", drift_reason="workflow_template_stale")
    elif _has_start or _has_end:
        # Partial markers (malformed / truncated file) — fall through to
        # full-file legacy_rewrite. Do NOT call rewrite_generated_block here;
        # it would append a second block when END is missing, duplicating content.
        logger.warning(
            "migrate_workflow_skill: partial markers detected; treating as legacy",
            extra={
                "event": "bootstrap.migrate_workflow_skill.partial_markers",
                "workflow_id": workflow_id,
                "has_start": _has_start,
                "has_end": _has_end,
                "path": str(skill_path),
            },
        )

    # Legacy markerless install — full-file rewrite.
    full_content = (
        f"{_WORKFLOW_SKILL_MARKER_START}\n{rendered_inner}\n{_WORKFLOW_SKILL_MARKER_END}\n"
    )
    _atomic_write_text(skill_path, full_content)
    logger.info(
        "migrate_workflow_skill: legacy install rewritten with markers",
        extra={
            "event": "bootstrap.migrate_workflow_skill.legacy_rewrite",
            "workflow_id": workflow_id,
            "path": str(skill_path),
        },
    )
    return MigrationOutcome(kind="legacy_rewrite", drift_reason="workflow_template_stale")
