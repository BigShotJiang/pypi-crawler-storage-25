"""File-locking and atomic-write helpers for the using-selph bootstrap."""

from __future__ import annotations

import contextlib
import os
import sys
import tempfile
from pathlib import Path
from typing import Callable, Iterator, Optional

from ._shared import fcntl, logger

__all__: list[str] = [
    "_file_lock",
    "_atomic_write_text",
    "_locked_write",
    "_WINDOWS_LOCK_NOTICE_EMITTED",
]

_WINDOWS_LOCK_NOTICE_EMITTED = False


@contextlib.contextmanager
def _file_lock(path: Path) -> Iterator[None]:
    """Acquire an exclusive advisory lock on ``<path>.lock`` for the block.

    The lock file is created if missing with mode 0600. On non-POSIX hosts
    the lock is silently skipped and a one-shot debug log is emitted (we do
    not want to spam every call).
    """
    global _WINDOWS_LOCK_NOTICE_EMITTED
    if fcntl is None:
        if not _WINDOWS_LOCK_NOTICE_EMITTED:
            logger.debug(
                "fcntl unavailable; file locks disabled on this platform",
                extra={
                    "event": "bootstrap.file_lock.unavailable",
                    "platform": sys.platform,
                },
            )
            _WINDOWS_LOCK_NOTICE_EMITTED = True
        yield
        return

    lock_path = path.with_name(path.name + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    # Open with O_CREAT and chmod the lock so concurrent processes can each
    # acquire/release without leaving world-readable cruft behind.
    fd = os.open(str(lock_path), os.O_CREAT | os.O_RDWR, 0o600)
    try:
        try:
            os.fchmod(fd, 0o600)
        except OSError:
            pass
        fcntl.flock(fd, fcntl.LOCK_EX)
        try:
            yield
        finally:
            try:
                fcntl.flock(fd, fcntl.LOCK_UN)
            except OSError as exc:  # pragma: no cover - defensive
                logger.warning(
                    "failed to release file lock",
                    extra={
                        "event": "bootstrap.file_lock.release_failed",
                        "path": str(lock_path),
                        "error_type": type(exc).__name__,
                    },
                )
    finally:
        try:
            os.close(fd)
        except OSError:
            pass


def _atomic_write_text(
    path: Path,
    content: str,
    *,
    mode: Optional[int] = None,
    prefix: str = ".",
    suffix: str = ".tmp",
) -> None:
    """Write ``content`` to ``path`` atomically via a unique tempfile.

    Uses ``tempfile.NamedTemporaryFile(delete=False, dir=parent, prefix, suffix)``
    so concurrent writers get unique tmp names (no fixed ``.tmp`` collisions).
    If ``mode`` is given, ``chmod`` is applied to the tmp BEFORE the rename so
    the file is never on-disk with looser perms than intended (matters for
    credentials.json, mode 0600).
    """
    parent = path.parent
    parent.mkdir(parents=True, exist_ok=True)
    tmp_fd, tmp_name = tempfile.mkstemp(prefix=prefix, suffix=suffix, dir=str(parent))
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as fh:
            fh.write(content)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass
        if mode is not None:
            try:
                os.chmod(tmp_path, mode)
            except OSError as exc:
                logger.warning(
                    "failed to chmod tmp before rename",
                    extra={
                        "event": "bootstrap.atomic_write.chmod_tmp_failed",
                        "path": str(tmp_path),
                        "mode": oct(mode),
                        "error_type": type(exc).__name__,
                    },
                )
        os.replace(tmp_path, path)
    except Exception:
        with contextlib.suppress(OSError):
            tmp_path.unlink()
        raise


def _locked_write(path: Path, write_fn: Callable[[], None]) -> None:
    """Run ``write_fn`` while holding ``_file_lock(path)``.

    Helper for read/modify/write sequences against a single state file. The
    callable is responsible for re-reading inside the lock (so monotonicity
    or other invariants hold under contention).
    """
    with _file_lock(path):
        write_fn()
