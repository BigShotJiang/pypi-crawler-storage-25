"""Slash-command self-update helpers for the using-selph bootstrap."""

from __future__ import annotations

import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from ._shared import logger
from ._file_locking import _atomic_write_text


def _require_https_url(api_url: str) -> tuple[bool, str]:
    """Return (True, "") if api_url is safe; (False, reason) otherwise.

    Mirrors the helper in selph_mcp.bootstrap.cli._install_subcommands so
    direct callers of refresh_slash_command() also get the scheme check.
    Allows https:// everywhere and http:// on loopback only (dev convenience).
    """
    parsed = urlparse(api_url)
    if parsed.scheme == "https":
        if not parsed.netloc:
            return False, "api_url must include a host"
        return True, ""
    if parsed.scheme == "http":
        if parsed.hostname in {"localhost", "127.0.0.1", "0.0.0.0"}:
            return True, ""
        return False, (
            f"api_url must use https:// scheme for non-loopback hosts; got {parsed.scheme!r}"
        )
    return False, f"api_url must use https:// scheme; got {parsed.scheme!r}"

__all__: list[str] = ["_slash_command_path", "refresh_slash_command"]


def _slash_command_path() -> Path:
    """Resolve the user's installed `/using-selph` slash-command file.

    The slash-command file lives in the user's Claude Code config directory
    at ``~/.claude/commands/using-selph.md``. This is the file Claude Code
    actually reads when the user types ``/using-selph`` — distinct from the
    SKILL.md spec in the repo (which is the source of truth shipped by the
    server).
    """
    return Path.home() / ".claude" / "commands" / "using-selph.md"


def refresh_slash_command(api_url: str, *, timeout: float = 10.0) -> Optional[bool]:
    """Fetch the latest using-selph slash-command spec from the server and
    write it to ``~/.claude/commands/using-selph.md``.

    Uses ``urllib.request`` only — keeps the bootstrap dependency-free so
    it can run in any Python environment (no httpx / requests).

    Returns:
        - ``True`` if the file was created or updated
        - ``False`` if the on-disk content already matched (no write)
        - ``None`` if the fetch failed (network, 5xx) — best-effort, never
          raises so it can run as a side effect in noncritical paths

    The endpoint is unauthenticated by design — the slash-command spec
    carries no secrets and must be fetchable before any auth handshake.
    Network failures and 4xx/5xx responses are logged and swallowed; a
    user with no network connectivity still gets the cached local copy.
    """
    ok, reason = _require_https_url(api_url)
    if not ok:
        logger.warning(
            "refresh_slash_command: insecure URL rejected",
            extra={
                "event": "bootstrap.refresh_slash_command.insecure_url",
                "api_url": api_url,
                "reason": reason,
            },
        )
        return None

    base = api_url.rstrip("/")
    url = f"{base}/apps/install/using-selph"

    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = resp.status
            raw = resp.read()
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        logger.info(
            "refresh_slash_command: fetch failed",
            extra={
                "event": "bootstrap.refresh_slash_command.fetch_failed",
                "api_url": api_url,
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return None

    if status != 200:
        logger.warning(
            "refresh_slash_command: bad status",
            extra={
                "event": "bootstrap.refresh_slash_command.bad_status",
                "api_url": api_url,
                "status": status,
            },
        )
        return None

    try:
        new_content = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        logger.warning(
            "refresh_slash_command: decode failed",
            extra={
                "event": "bootstrap.refresh_slash_command.decode_failed",
                "api_url": api_url,
                "error": str(exc)[:200],
            },
        )
        return None

    if not new_content.strip():
        logger.warning(
            "refresh_slash_command: empty body",
            extra={
                "event": "bootstrap.refresh_slash_command.empty_body",
                "api_url": api_url,
            },
        )
        return None

    target = _slash_command_path()
    try:
        existing = target.read_text(encoding="utf-8") if target.is_file() else None
    except OSError as exc:
        logger.warning(
            "refresh_slash_command: read existing failed",
            extra={
                "event": "bootstrap.refresh_slash_command.read_existing_failed",
                "path": str(target),
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        existing = None

    if existing == new_content:
        logger.debug(
            "refresh_slash_command: unchanged",
            extra={
                "event": "bootstrap.refresh_slash_command.unchanged",
                "path": str(target),
                "bytes": len(new_content),
            },
        )
        return False

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_text(target, new_content)
    except OSError as exc:
        logger.error(
            "refresh_slash_command: write failed",
            extra={
                "event": "bootstrap.refresh_slash_command.write_failed",
                "path": str(target),
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return None

    logger.info(
        "refresh_slash_command: updated",
        extra={
            "event": "bootstrap.refresh_slash_command.updated",
            "path": str(target),
            "bytes": len(new_content),
            "was_present": existing is not None,
        },
    )
    return True
