"""Shared infrastructure for the bootstrap sub-package.

Logger is defined here with a pinned literal name so log queries
remain stable across the refactor.  Every other sub-module does
``from ._shared import logger`` instead of defining its own.

Also holds: _now_iso, _read_template, and the fcntl POSIX-detection
block that every file-locking helper needs.
"""

from __future__ import annotations

import sys
from datetime import datetime, timezone
from pathlib import Path

try:  # POSIX file locking. Skip silently on Windows (logged once at use).
    import fcntl  # type: ignore[import]
except ImportError:  # pragma: no cover - non-POSIX platforms
    fcntl = None  # type: ignore[assignment]

from selph_mcp._log import get_logger

# Pinned literal name — do NOT use __name__ here; that yields
# ``adapters.claude_code.using_selph.bootstrap._shared`` and splits log queries.
logger = get_logger("selph_mcp.skill.bootstrap")

__all__: list[str] = ["logger", "fcntl", "_now_iso", "_read_template"]


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _read_template(name: str) -> str:
    """Read a sibling template by relative name."""
    # Resolve relative to the *package directory* (bootstrap/), then go up one
    # level to the using_selph dir that owns templates/.
    template_path = Path(__file__).parent.parent / "templates" / name
    return template_path.read_text(encoding="utf-8")
