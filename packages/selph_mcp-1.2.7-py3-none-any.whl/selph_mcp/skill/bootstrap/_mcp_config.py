"""MCP config entry writer for the using-selph bootstrap (pipx-era)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional, Union

from ._shared import logger
from ._file_locking import _atomic_write_text, _locked_write
from ._credentials import hydrate_from_global_credentials, _global_credentials_path_for_log

__all__: list[str] = ["write_mcp_entry_pipx"]


def write_mcp_entry_pipx(
    *,
    server_name: str = "selph",
    selph_mcp_command: Optional[str] = None,
    claude_config: Union[str, Path, None] = None,
    require_global_credentials: bool = True,
) -> bool:
    """Write/refresh the user's ``~/.claude.json`` MCP entry to call ``selph-mcp``.

    The pipx-era wiring is a single ``stdio`` entry with no PYTHONPATH /
    cwd / .venv-bin reference — the wheel's ``selph-mcp`` console script
    is on PATH and reads its credentials from the global file written by
    ``selph-mcp-bootstrap register``. Idempotent: if the entry already
    matches the target shape, no write is performed.

    Anti-foot-gun: when ``require_global_credentials`` is True (the
    default), this helper REFUSES to write when no global credentials
    file exists. Writing the new entry without a bearer token would
    overwrite a working legacy entry (with ``SELPH_API_KEY`` in env)
    and replace it with an entry whose ``env: {}`` block produces a
    silently-broken wheel. Set False only for tests / lifecycle paths
    that have already verified a credentials file exists.

    Read/modify/write is protected by ``_file_lock`` so a concurrent
    ``/using-selph`` run (or a sibling tool that mutates the same
    config) cannot clobber other ``mcpServers`` entries via a
    last-writer-wins race.

    Args:
        server_name: MCP server key under ``mcpServers`` (default
            ``"selph"``).
        selph_mcp_command: Path to the ``selph-mcp`` executable. When
            ``None``, defaults to the bare ``"selph-mcp"`` (PATH lookup).
        claude_config: Override the path to ``~/.claude.json`` for tests.
        require_global_credentials: When True, raise ``RuntimeError`` if
            ``hydrate_from_global_credentials()`` returns None.

    Returns:
        ``True`` if the file was written or modified; ``False`` if the
        existing entry already matched.

    Raises:
        RuntimeError: when ``require_global_credentials`` is True and no
            global credentials file is present.
    """
    if require_global_credentials and hydrate_from_global_credentials() is None:
        raise RuntimeError(
            "refusing to write ~/.claude.json: no global selph-mcp "
            "credentials file found at "
            f"{_global_credentials_path_for_log()}. Run "
            "`selph-mcp-bootstrap register --user-id <id> --api-key <key>` "
            "first; the resulting bearer token is what makes the new MCP "
            "entry actually usable."
        )

    path = Path(claude_config) if claude_config else Path.home() / ".claude.json"

    target: Dict[str, Any] = {
        "type": "stdio",
        "command": selph_mcp_command or "selph-mcp",
        "args": [],
        # No env block — selph_mcp._client falls back to the chmod-0600
        # global credentials file written by ``selph-mcp-bootstrap``.
        "env": {},
    }

    changed = {"value": False}

    def _do_write() -> None:
        cfg: Dict[str, Any]
        if path.exists():
            try:
                cfg = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                logger.warning(
                    "claude config unreadable; will overwrite on next save",
                    extra={
                        "event": "bootstrap.write_mcp_entry_pipx.unreadable",
                        "path": str(path),
                        "error_type": type(exc).__name__,
                    },
                )
                cfg = {}
        else:
            cfg = {}

        if not isinstance(cfg.get("mcpServers"), dict):
            cfg["mcpServers"] = {}
        existing = cfg["mcpServers"].get(server_name)
        if isinstance(existing, dict) and all(
            existing.get(k) == v for k, v in target.items()
        ):
            logger.debug(
                "mcp entry already matches target",
                extra={
                    "event": "bootstrap.write_mcp_entry_pipx.noop",
                    "server_name": server_name,
                },
            )
            return

        cfg["mcpServers"][server_name] = target
        serialized = json.dumps(cfg, indent=2, sort_keys=True)
        _atomic_write_text(path, serialized + "\n")
        changed["value"] = True
        logger.info(
            "mcp entry written",
            extra={
                "event": "bootstrap.write_mcp_entry_pipx",
                "path": str(path),
                "server_name": server_name,
                "command": target["command"],
            },
        )

    _locked_write(path, _do_write)
    return changed["value"]
