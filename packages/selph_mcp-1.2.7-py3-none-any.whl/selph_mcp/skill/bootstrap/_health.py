"""Retrieval health guard for the using-selph bootstrap."""

from __future__ import annotations

from typing import List, Optional

__all__: list[str] = ["RetrievalHealthError", "assert_retrieval_ok"]


class RetrievalHealthError(RuntimeError):
    """Raised when the 4-step MCP chain finished with zero retrieval output.

    Cold-start onboarding sets an "I'm done" marker in
    ``.selph/state/onboarding.json``; re-running ``/using-selph`` after
    that marker exists runs the minimal *returning* flow (policy refresh
    only — no hub re-reads). That is intentional for healthy returning
    users, but disastrous when the first run silently failed because the
    graph was unreachable (e.g. Aura paused, DNS NXDOMAIN, routing bug).
    The user ends up permanently "onboarded" to an empty experience with
    no obvious way to retry short of deleting state by hand.

    This error is raised by :func:`assert_retrieval_ok` when the
    aggregate citations + evidence across the 4-step chain is zero, so
    the skill can refuse to stamp completion and surface the cause.
    """


def assert_retrieval_ok(
    *,
    citation_totals: List[int],
    evidence_totals: Optional[List[int]] = None,
) -> None:
    """Guard: ``/using-selph`` must not record onboarding complete on an
    empty first run.

    Args:
        citation_totals: One integer per MCP tool call in the cold-start
            4-step chain (typically: hire_for_role, what_changed,
            get_context(operating_manual), get_context(workflow_recommendation)).
            Values come from the length of each response's
            ``citations`` array.
        evidence_totals: Parallel list of each response's
            ``meta.evidence_count``. Optional — some endpoints return
            citations but omit ``evidence_count``.

    Raises:
        RetrievalHealthError: if every entry in both lists is zero (or
            the only non-zero values are in ``what_changed`` — which
            legitimately returns 0 on a fresh consumer and is therefore
            ignored for this check when passed as element index 1).

    Pure; never writes.
    """
    if not citation_totals:
        raise RetrievalHealthError(
            "no retrieval attempts recorded — refusing to mark onboarding "
            "complete without proof of a working retrieval path."
        )
    ev = evidence_totals or [0] * len(citation_totals)
    # Ignore what_changed (index 1) in the aggregate: a fresh consumer
    # legitimately has 0 invalidations, and hire_for_role (index 0) is a
    # lightweight handshake that often returns 0 citations too.
    # Treat get_context calls (indices 2 and 3) as the load-bearing signal.
    load_bearing_cits = sum(citation_totals[2:])
    load_bearing_ev = sum(ev[2:])
    if load_bearing_cits == 0 and load_bearing_ev == 0:
        raise RetrievalHealthError(
            "cold-start retrieval returned 0 citations and 0 evidence "
            "across every get_context call — refusing to mark onboarding "
            "complete. Likely causes: (a) the Neo4j graph instance is "
            "paused/unreachable (check DNS + console); (b) the consumer "
            "is bound to a user_id with no hub payloads yet; "
            "(c) a router regression. Investigate before re-running."
        )
