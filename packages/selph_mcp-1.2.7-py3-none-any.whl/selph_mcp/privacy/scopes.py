"""Sensitivity derivation at read time (Phase 2 task 5).

Evidence payloads do not carry a sensitivity column today (a real column
is a future migration; see §Phase 2 task 5 of the implementation plan).
Until then the persona layer derives sensitivity at the moment it
assembles citations from four signals:

    Signal                                    Sensitivity
    --------------------------------------------------------------
    Layer 1 utterances matching PII patterns  sensitive
    memory_type in SENSITIVE_MEMORY_TYPES     sensitive
    hub_type in SENSITIVE_HUB_TYPES           sensitive
    Explicit ``restricted`` tag (future)       restricted
    everything else                            normal

The persona router enforces the consumer's ``sensitivity_ceiling`` by
either rejecting the read outright or redacting per-citation content via
:mod:`selph_mcp.privacy.redaction`.

This module is a pure classifier — it imports only from
:mod:`selph_mcp.contracts.envelope` and standard library. No Postgres,
no Neo4j, no LLMs.

Observation PII wire-up (Phase 2):
    :mod:`selph_mcp.persona.tools.find_evidence` populates ``content_map``
    for Layer 1 observation citations via
    :func:`selph_db.raw_evidence_manager.get_raw_evidence_by_id`, so the PII
    row of the §Phase 2 task 5 mapping fires when raw observation text
    matches the email/phone/address regex set. Other callers that do not
    hydrate observation text (e.g. :mod:`selph_mcp.persona.tools.get_context`)
    pass an empty ``content_map`` and the PII branch no-ops — which is
    expected since those paths never return raw Layer 1 content.
"""
from __future__ import annotations

import re
from typing import Iterable, Literal, Optional, Set

from selph_mcp.contracts.envelope import Citation, SensitivityClass

# ---------------------------------------------------------------------------
# Sensitivity mapping (§Phase 2 task 5)
# ---------------------------------------------------------------------------

#: Memory types that always carry ``sensitive`` sensitivity regardless of
#: content. Keyed by ``BaseMemorySchemaV2.memory_type`` — matches the
#: names declared in ``rules/data-models.md``.
SENSITIVE_MEMORY_TYPES: Set[str] = {
    "belief_memory",
    "self_narrative_fragment",
    "identity_claim_memory",
    "conflict_event",
    "emotion_memory",
    "relationship_state_snapshot",
    "financial_memory",
}

#: Hub types that always carry ``sensitive`` sensitivity. Keyed by
#: ``BaseHub.hub_type`` — matches ``rules/hubs.md``.
SENSITIVE_HUB_TYPES: Set[str] = {
    "spiritual",
    "tension",
    "emotional",
    "narrative_identity",
}


# ---------------------------------------------------------------------------
# Conservative PII patterns for Layer 1 utterance content
# ---------------------------------------------------------------------------
#
# These are intentionally conservative — we over-flag rather than
# under-flag. A real PII scanner lives in a future migration; today's
# goal is to avoid shipping utterances containing an email / phone /
# address to a ``normal``-ceiling consumer.
#
# - Email: standard RFC-lite local@domain.tld (case insensitive).
# - Phone: 7–15 digits optionally separated by spaces/dashes/dots/parens,
#   with optional leading + for international.
# - Address: street-number + one-to-four words + common street suffix
#   (street|st|avenue|ave|road|rd|blvd|lane|ln|drive|dr|way|court|ct).
# The patterns are deliberately shallow — the goal is a coarse "looks
# like PII" signal, not comprehensive extraction.

_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_PHONE_RE = re.compile(
    r"(?:\+?\d{1,3}[\s.-]?)?(?:\(?\d{2,4}\)?[\s.-]?)?\d{3,4}[\s.-]?\d{3,4}"
)
_ADDRESS_RE = re.compile(
    r"\b\d{1,6}\s+(?:\w+\s+){0,4}"
    r"(?:street|st|avenue|ave|road|rd|blvd|boulevard|lane|ln|drive|dr|way|court|ct)"
    r"\b",
    re.IGNORECASE,
)

_PII_PATTERNS = (_EMAIL_RE, _PHONE_RE, _ADDRESS_RE)


def pii_patterns_match(text: Optional[str]) -> bool:
    """Return True when ``text`` contains any of the conservative PII patterns.

    Used by :func:`derive_sensitivity` for Layer-1 observation citations.
    ``None`` / empty → ``False``. The patterns are deliberately coarse
    (email-ish, phone-ish, address-ish) to keep the false-negative rate
    low at the cost of occasional false positives — the intent is to keep
    raw utterance text with PII from going to a ``normal``-ceiling
    consumer, not to perform clean extraction.
    """
    if not text:
        return False
    for rx in _PII_PATTERNS:
        if rx.search(text):
            return True
    return False


# ---------------------------------------------------------------------------
# Public classifiers
# ---------------------------------------------------------------------------

SensitivityLabel = Literal["normal", "sensitive", "restricted"]

_ORDER = {"normal": 0, "sensitive": 1, "restricted": 2}


def derive_sensitivity(
    citation: Citation,
    *,
    content_text: Optional[str] = None,
    restricted_flag: bool = False,
) -> SensitivityLabel:
    """Classify one citation per the §Phase 2 task 5 mapping.

    Rules applied in order:

    1. ``restricted_flag`` (reserved for a future ``restricted`` column on
       memories or hubs) → ``restricted``.
    2. ``ref_type == memory`` and ``memory_type`` in
       :data:`SENSITIVE_MEMORY_TYPES` → ``sensitive``.
    3. ``ref_type == hub`` and ``hub_type`` in :data:`SENSITIVE_HUB_TYPES`
       → ``sensitive``.
    4. ``ref_type == observation`` and layer == 1 with PII-shaped content
       → ``sensitive``. Content is checked only when supplied by the
       caller (``content_text``) — the Citation itself does not carry
       raw text.
    5. Otherwise → ``normal``.
    """
    if restricted_flag:
        return "restricted"

    ref_type = citation.ref_type.value

    if ref_type == "memory" and citation.memory_type in SENSITIVE_MEMORY_TYPES:
        return "sensitive"

    if ref_type == "hub" and citation.hub_type in SENSITIVE_HUB_TYPES:
        return "sensitive"

    if ref_type == "observation" and citation.layer == 1:
        if pii_patterns_match(content_text):
            return "sensitive"

    return "normal"


def derive_sensitivity_batch(
    citations: Iterable[Citation],
    *,
    content_map: Optional[dict] = None,
    restricted_ids: Optional[Set[str]] = None,
) -> SensitivityLabel:
    """Return the MAX sensitivity across ``citations``.

    The batch-level sensitivity drives ``meta.sensitivity_class`` on the
    response envelope — a response is only ``normal`` when every
    contributing citation is ``normal``.

    Args:
        citations: Iterable of :class:`Citation` objects to classify.
        content_map: Optional mapping of ``ref_id`` → raw text for
            Layer-1 observation citations. Only used when the caller has
            already read the observation row and can supply the string.
        restricted_ids: Optional set of ``ref_id`` values the caller has
            already determined to be ``restricted`` (future flag field).

    Returns:
        ``"normal" | "sensitive" | "restricted"`` — the max per
        :data:`_ORDER`.
    """
    cmap = content_map or {}
    rset = restricted_ids or set()
    max_label: SensitivityLabel = "normal"
    for c in citations:
        label = derive_sensitivity(
            c,
            content_text=cmap.get(c.ref_id),
            restricted_flag=(c.ref_id in rset),
        )
        if _ORDER[label] > _ORDER[max_label]:
            max_label = label
        if max_label == "restricted":
            break  # can't get higher
    return max_label


def enforce_ceiling(
    ceiling: SensitivityLabel | SensitivityClass | str,
    actual: SensitivityLabel | SensitivityClass | str,
) -> bool:
    """Return ``True`` when ``actual`` is allowed under ``ceiling``.

    Ordering: ``normal < sensitive < restricted``. A consumer with a
    ``normal`` ceiling may receive ``normal`` content but not
    ``sensitive`` or ``restricted``.

    Accepts bare strings, :class:`SensitivityClass`, or
    :class:`SensitivityLabel` literals so callers do not have to
    manually unwrap enums.
    """
    ceiling_v = (
        ceiling.value if isinstance(ceiling, SensitivityClass) else str(ceiling)
    )
    actual_v = (
        actual.value if isinstance(actual, SensitivityClass) else str(actual)
    )
    if ceiling_v not in _ORDER or actual_v not in _ORDER:
        # Unknown label — refuse by default rather than silently allow.
        return False
    return _ORDER[actual_v] <= _ORDER[ceiling_v]


__all__ = [
    "SENSITIVE_HUB_TYPES",
    "SENSITIVE_MEMORY_TYPES",
    "SensitivityLabel",
    "derive_sensitivity",
    "derive_sensitivity_batch",
    "enforce_ceiling",
    "pii_patterns_match",
]
