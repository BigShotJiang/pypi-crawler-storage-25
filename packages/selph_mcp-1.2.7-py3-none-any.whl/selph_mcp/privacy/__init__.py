"""Persona-layer privacy primitives (Phase 2).

Read-time sensitivity derivation + citation redaction per §Phase 2 task 5
of ``docs/selph_mcp_distribution_implementation_plan.md``. Evidence does
NOT carry a sensitivity column today, so sensitivity is derived from
(memory_type, hub_type, layer, PII patterns in utterance content) at the
moment a citation is assembled.

Public surface:

- :func:`selph_mcp.privacy.scopes.derive_sensitivity` — classify one
  citation.
- :func:`selph_mcp.privacy.scopes.derive_sensitivity_batch` — max across
  a list.
- :func:`selph_mcp.privacy.scopes.enforce_ceiling` — boolean gate against
  the consumer's ``sensitivity_ceiling``.
- :func:`selph_mcp.privacy.redaction.redact_citation` — strip content
  payload when the citation exceeds the ceiling.
"""

from selph_mcp.privacy.redaction import (
    RedactedCitation,
    redact_citation,
    redact_citations,
)
from selph_mcp.privacy.scopes import (
    SENSITIVE_HUB_TYPES,
    SENSITIVE_MEMORY_TYPES,
    derive_sensitivity,
    derive_sensitivity_batch,
    enforce_ceiling,
    pii_patterns_match,
)

__all__ = [
    "SENSITIVE_HUB_TYPES",
    "SENSITIVE_MEMORY_TYPES",
    "derive_sensitivity",
    "derive_sensitivity_batch",
    "enforce_ceiling",
    "pii_patterns_match",
    "RedactedCitation",
    "redact_citation",
    "redact_citations",
]
