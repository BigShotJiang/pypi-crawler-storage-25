"""Citation redaction (Phase 2 task 6).

When a citation's derived sensitivity exceeds the consumer's
``sensitivity_ceiling``, the persona layer can either:

  (a) reject the entire read (caller choice — see
      ``persona/tools/get_context.py``), or
  (b) keep the citation ID + layer + memory_type/hub_type but strip the
      content payload via :func:`redact_citation`.

This module implements (b). A sibling :class:`RedactedCitation` model is
used instead of mutating the Phase 1a :class:`Citation` contract — the
Phase 1a ``Citation`` model uses ``extra="forbid"`` and we do not change
the Phase 1a shape in Phase 2. Redacted citations carry the same
identifier set plus a ``redacted=True`` marker and a ``redaction_reason``
so harnesses can render an evidence chip that says "redacted by scope"
rather than silently dropping the citation.
"""
from __future__ import annotations

from datetime import datetime
from typing import Iterable, List, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field

from selph_mcp.contracts.envelope import Citation, RefType, SensitivityClass
from selph_mcp.privacy.scopes import (
    SensitivityLabel,
    derive_sensitivity,
    enforce_ceiling,
)


# ---------------------------------------------------------------------------
# RedactedCitation — sibling model, leaves Phase 1a Citation untouched
# ---------------------------------------------------------------------------


class RedactedCitation(BaseModel):
    """A citation whose payload was stripped for consumer ceiling reasons.

    Mirrors the :class:`Citation` identifier fields 1:1 (``ref_type``,
    ``ref_id``, ``layer``, ``memory_type``, ``hub_type``) so the harness
    can still render an evidence chip. The ``confidence`` and
    ``captured_at`` fields are intentionally omitted — they are
    interpretive signals that would leak some shape of the underlying
    content even after the payload is stripped.

    ``redacted=True`` is fixed so downstream code can branch on it
    without re-deriving sensitivity.
    """

    model_config = ConfigDict(extra="forbid")

    ref_type: RefType
    ref_id: str
    layer: Literal[1, 2, 3, 4]
    memory_type: Optional[str] = None
    hub_type: Optional[str] = None
    redacted: Literal[True] = True
    redaction_reason: str = Field(
        default="sensitivity_ceiling_exceeded",
        description=(
            "Why the payload was stripped — fixed default covers the "
            "ceiling-exceeded path; future extensions may surface "
            "per-field justifications."
        ),
    )


CitationOrRedacted = Union[Citation, RedactedCitation]


# ---------------------------------------------------------------------------
# Redaction helpers
# ---------------------------------------------------------------------------


def _ceiling_label(
    ceiling: SensitivityLabel | SensitivityClass | str,
) -> str:
    return ceiling.value if isinstance(ceiling, SensitivityClass) else str(ceiling)


def redact_citation(
    citation: Citation,
    consumer_ceiling: SensitivityLabel | SensitivityClass | str,
    *,
    content_text: Optional[str] = None,
    restricted_flag: bool = False,
) -> CitationOrRedacted:
    """Return ``citation`` unchanged when the ceiling permits, else a
    :class:`RedactedCitation` with ID/layer/type preserved but payload
    stripped.

    The Phase 1a :class:`Citation` model is NOT mutated — if ``actual``
    exceeds the ceiling we return a sibling :class:`RedactedCitation`.
    This keeps the Phase 1a contract frozen while still surfacing the
    redaction to downstream harnesses via a ``redacted=True`` flag.

    Args:
        citation: The input citation to evaluate.
        consumer_ceiling: The authenticated consumer's
            ``sensitivity_ceiling``.
        content_text: Optional Layer-1 observation text the caller has
            already pulled — used for PII detection on observation
            citations. Leave ``None`` for non-observation or when the
            caller has no raw text handy.
        restricted_flag: When the caller has resolved an explicit
            ``restricted`` marker (future column) out of band.

    Returns:
        The original :class:`Citation` when allowed, else a
        :class:`RedactedCitation`.
    """
    actual = derive_sensitivity(
        citation,
        content_text=content_text,
        restricted_flag=restricted_flag,
    )
    if enforce_ceiling(consumer_ceiling, actual):
        return citation

    return RedactedCitation(
        ref_type=citation.ref_type,
        ref_id=citation.ref_id,
        layer=citation.layer,
        memory_type=citation.memory_type,
        hub_type=citation.hub_type,
        redaction_reason=(
            f"sensitivity_ceiling_exceeded:{actual}>{_ceiling_label(consumer_ceiling)}"
        ),
    )


def redact_citations(
    citations: Iterable[Citation],
    consumer_ceiling: SensitivityLabel | SensitivityClass | str,
    *,
    content_map: Optional[dict] = None,
    restricted_ids: Optional[set] = None,
) -> List[CitationOrRedacted]:
    """Batch-apply :func:`redact_citation` across a citation list."""
    cmap = content_map or {}
    rset = restricted_ids or set()
    out: List[CitationOrRedacted] = []
    for c in citations:
        out.append(
            redact_citation(
                c,
                consumer_ceiling,
                content_text=cmap.get(c.ref_id),
                restricted_flag=(c.ref_id in rset),
            )
        )
    return out


__all__ = [
    "RedactedCitation",
    "CitationOrRedacted",
    "redact_citation",
    "redact_citations",
]
