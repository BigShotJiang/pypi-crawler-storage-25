selph-mcp
=========

> **Status: shelved (2026-04-24).** The remote MCP surface mounted on `ingestion_api`
> is the supported way to reach Selph. This stdio wheel is not actively maintained:
> `HttpEngineAdapter` still works against the cloud, but `InProcessEngineAdapter`
> remains a stub, so installing the wheel buys clients nothing they can't get from
> remote MCP. Code stays in tree as optionality. Revisit if (a) a client requires
> stdio specifically, or (b) Selph commits to a self-hosted product where
> `InProcessEngineAdapter` runs the kernel locally against a client-owned Neo4j +
> Postgres + Azure OpenAI.

Selph MCP stdio transport. Install with pipx:

    pipx install selph-mcp

Then register with your Selph engine:

    selph-mcp-bootstrap register \
        --engine-url https://<your-engine>.azurecontainerapps.io \
        --admin-key <SELPH_API_KEY> \
        --user-id U001 \
        --display-name "MyClaudeCode"

Paste the printed JSON snippet into ~/.claude.json and reload Claude Code.

Diagnostics:
    selph-mcp-bootstrap doctor    # check contract-version compatibility
    selph-mcp-bootstrap whoami    # print consumer info
