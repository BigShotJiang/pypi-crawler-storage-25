"""GET /apps/mcp/server/versions — contract-version metadata endpoint.

Phase 3 §3.6 of `docs/selph_harness_context_implementation_plan.md`.

Returns the ``ContractVersions`` block so conforming adapters can learn the
server's current versions without parsing a persona tool response.

Auth: PUBLIC (no auth). Slice 3 chicken-and-egg: the wheel's
``EngineClient.startup()`` calls this route to verify contract compatibility
BEFORE it has resolved any per-request auth. The default Slice 3 install
path persists only the per-consumer Bearer token (no shared API key) in
``~/.config/selph-mcp/credentials.json`` — so an X-API-Key gate here would
fail every wheel boot. The payload contains only public version integers
(``persona_contract_version``, ``harness_adapter_version``,
``response_envelope_version``) which carry zero PII and are intentionally
discoverable so clients can detect drift before establishing auth.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter

from selph_mcp.contracts.versions import ContractVersions, load_contract_versions
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.server.versions_route")

router = APIRouter()


@router.get(
    "/apps/mcp/server/versions",
    response_model=ContractVersions,
    summary="Contract version metadata",
    description=(
        "Returns the server's current contract versions as a JSON object. "
        "Auth: PUBLIC. Adapters call this on startup to verify "
        "compatibility before any per-request auth is established."
    ),
    tags=["meta"],
)
async def get_server_versions() -> ContractVersions:
    """Return the server's ``ContractVersions`` block.

    Logs entry and completion per mandatory logging coverage
    (``rules/naming-and-constraints.md``).
    """
    log_event(
        _log,
        logging.INFO,
        "mcp.server.versions.entry",
    )
    versions = load_contract_versions()
    log_event(
        _log,
        logging.INFO,
        "mcp.server.versions.complete",
        harness_adapter_version=versions.harness_adapter_version,
        response_envelope_version=versions.response_envelope_version,
    )
    return versions


__all__ = ["router"]
