"""MCP transport servers (Phase 1b §3) + back-compat shim for the legacy
``selph_mcp/server.py`` module that this package now shadows. The shim
loads ``selph_mcp/server.py`` by absolute path via ``importlib`` and
re-exports its ``server`` FastMCP instance so existing callers
(``selph_mcp/run_stdio.py``, ``selph_mcp/run_sse.py``) keep working until
the dedicated cleanup pass removes the old file.

`mcp_app.py` exposes a factory that returns a configured FastMCP
instance with the four kernel tools (``observe``, ``query``,
``project``, ``revise``) registered. Two transport runners are
exported:

    from selph_mcp.server.mcp_app import create_mcp_app, run_stdio, run_http

Per ``CLAUDE.md`` the runners are NEVER invoked locally — they live
here so the operator can wire ``python -m selph_mcp.server.mcp_app``
into Claude Code's ``.mcp.json`` (stdio) or run the HTTP transport
inside the deployed container.
"""

from __future__ import annotations

import importlib.util as _importlib_util
import os as _os

from selph_mcp.server.mcp_app import create_mcp_app, run_http, run_stdio

__all__: list[str] = ["create_mcp_app", "run_http", "run_stdio"]

# ─── Back-compat shim ─────────────────────────────────────────────────────
# The legacy module ``selph_mcp/server.py`` is unreachable through normal
# imports now that this package shadows it. Load it by absolute path and
# re-export ``server`` so ``from selph_mcp.server import server`` still
# resolves for ``run_stdio.py`` / ``run_sse.py``. Wrapped in try/except so
# the eventual deletion of ``server.py`` does not crash package imports.
try:
    _OLD_SERVER_PATH = _os.path.join(
        _os.path.dirname(_os.path.dirname(__file__)), "server.py"
    )
    if _os.path.isfile(_OLD_SERVER_PATH):
        _spec = _importlib_util.spec_from_file_location(
            "_selph_mcp_old_server", _OLD_SERVER_PATH
        )
        if _spec is not None and _spec.loader is not None:
            _old_server_module = _importlib_util.module_from_spec(_spec)
            _spec.loader.exec_module(_old_server_module)
            server = _old_server_module.server  # legacy FastMCP instance
            __all__.append("server")
except Exception:  # noqa: BLE001 — best-effort shim, never block package import
    pass
