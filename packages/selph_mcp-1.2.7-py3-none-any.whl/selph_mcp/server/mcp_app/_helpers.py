"""Shared helpers: logger, header extraction, consumer auth, credential forwarding, lifespan attr."""
from __future__ import annotations

import asyncio
import logging
import os
from contextlib import asynccontextmanager
from typing import Any, AsyncGenerator, Dict, Optional

from fastapi import HTTPException, status
from mcp.server.fastmcp import Context

from selph_mcp.auth import require_consumer
from selph_mcp.contracts.consumer import Consumer
from selph_mcp._log import get_logger, log_event

# NOTE: configure_logging() is intentionally NOT called here at module-import
# time.  Calling it here caused a §5.6 regression: when ingestion_api.main
# imports this module, configure_logging() would clear selph_utils.log's
# stdout handler and reroute all API logs to stderr.  configure_logging() is
# now idempotent (host-aware), but the call is still moved into the
# run_stdio() / run_http() entry points so it only fires in standalone mode.
_log = get_logger("selph_mcp.server.mcp_app")


# ─────────────────────────────────────────────────────────────────────────────
# Header / auth bridging
# ─────────────────────────────────────────────────────────────────────────────

def _extract_headers(ctx: Optional[Context]) -> Dict[str, str]:
    """Pull the ``X-API-Key`` / ``X-Selph-Consumer`` headers from the
    MCP request context, regardless of transport.

    The MCP SDK stores per-request metadata under
    ``ctx.request_context.request.meta`` (stdio) or on the underlying
    HTTP request (streamable-http). FastMCP normalizes both into the
    same ``request_context`` shape, so we look in a fixed set of
    locations and return whatever we find.

    Returns a header dict with lowercase-canonical keys for the two
    headers we care about. Missing values become empty strings so the
    downstream FastAPI dependency can raise its own 4xx with a stable
    message.
    """
    out = {"x-api-key": "", "x-selph-consumer": ""}
    if ctx is None:
        return out

    rc = getattr(ctx, "request_context", None)
    if rc is None:
        return out

    # 1) Direct request.headers (HTTP transport)
    request = getattr(rc, "request", None)
    headers = getattr(request, "headers", None) if request is not None else None
    if headers is not None:
        try:
            for key in out:
                value = headers.get(key) or headers.get(key.upper()) or ""
                out[key] = value
        except Exception:  # noqa: BLE001 — fall through to meta path
            pass

    # 2) Request meta dict (stdio transport — MCP clients push headers
    # under request.meta when launching the subprocess)
    meta = getattr(request, "meta", None) if request is not None else None
    if meta:
        try:
            for key in out:
                if not out[key]:
                    out[key] = (
                        meta.get(key)
                        or meta.get(key.upper())
                        or meta.get(key.replace("-", "_"))
                        or ""
                    )
        except Exception:  # noqa: BLE001
            pass

    return out


async def _consumer_from_ctx(ctx: Optional[Context]) -> Consumer:
    """Resolve the authenticated :class:`Consumer` for this tool call.

    §5.2 amendment — prefer a pre-resolved ``Consumer`` injected into the
    ASGI scope by ``ingestion_api.mcp_mount_auth.bearer_auth_asgi`` when
    the MCP app runs mounted.  The bearer_auth_asgi wrapper authenticates
    the ``Authorization: Bearer`` token once per HTTP request and stores
    the result under ``scope["state"]["selph_consumer"]`` so individual
    tool calls do not incur a redundant Postgres lookup.

    When ``scope["state"]["selph_consumer"]`` is absent (stdio transport,
    standalone streamable-HTTP, or any path that did not go through the
    ASGI wrapper), falls back to the original header-extraction path.
    Stdio behaviour is byte-identical.

    ``require_consumer`` performs sync Postgres I/O (``get_consumer``)
    so we offload it to the default executor — every MCP tool handler
    is async and a blocking call here would freeze the event loop for
    the duration of the row lookup.
    """
    # §5.2: check scope["state"]["selph_consumer"] first (mounted-HTTP path)
    if ctx is not None:
        rc = getattr(ctx, "request_context", None)
        if rc is not None:
            req = getattr(rc, "request", None)
            if req is not None:
                scope = getattr(req, "scope", None)
                if scope is not None:
                    state = scope.get("state", {}) or {}
                    pre_resolved = state.get("selph_consumer")
                    if pre_resolved is not None:
                        return pre_resolved  # type: ignore[return-value]

    headers = _extract_headers(ctx)
    consumer_id = headers["x-selph-consumer"]
    api_key = headers["x-api-key"]

    # Stdio fallback: Claude Code (and the reference Python MCP client)
    # don't forward X-API-Key / X-Selph-Consumer into per-call request.meta
    # for stdio transports — the auth boundary is the subprocess spawn
    # (parent had to set the env vars to launch us). When we detect stdio
    # AND the headers are empty, hydrate them from the child env so the
    # downstream compare in ``require_api_key`` still runs, but against
    # matching values. The streamable-http path is untouched.
    if os.getenv("SELPH_MCP_TRANSPORT", "").lower() == "stdio":
        if not api_key:
            api_key = os.getenv("SELPH_API_KEY", "")
        if not consumer_id:
            consumer_id = os.getenv("SELPH_CONSUMER_ID", "")

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        None,
        lambda: require_consumer(consumer_id=consumer_id, _api_key=api_key),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Per-request credential forwarding (Bug 3 fix — mounted auth bypass)
# ─────────────────────────────────────────────────────────────────────────────


@asynccontextmanager
async def _mounted_request_credentials(
    ctx: Optional[Context],
) -> AsyncGenerator[None, None]:
    """Propagate the caller's Bearer + consumer_id into the selph_mcp._client
    contextvars so loopback HTTP calls carry the correct per-caller identity.

    In mounted mode, ``bearer_auth_asgi`` validates the incoming Bearer token
    and stores both the raw token and the consumer_id under
    ``scope["state"]["selph_bearer_token"]`` / ``scope["state"]["selph_consumer_id"]``.
    This helper extracts those values and pushes them into the per-request
    contextvars before any tool dispatch, then resets them on exit.

    For stdio transport (or any path where the ASGI scope is absent), the
    state keys are missing → both values are ``None`` → the contextvars stay
    at their default ``None`` → ``get_client()`` returns the env singleton.
    Stdio behaviour is byte-identical.

    On exit, any per-request ``EngineClient`` cached in ``_request_client_ctx``
    is closed via ``aclose()`` so its httpx.AsyncClient and associated sockets
    are released immediately. Under stdio (bearer/consumer_id both None) the
    cache stays ``None`` and no close is attempted.

    Usage inside a tool wrapper::

        async with _mounted_request_credentials(ctx):
            result = await some_kernel_function(...)
    """
    from selph_mcp._client import (
        _request_bearer_ctx,
        _request_consumer_id_ctx,
        _request_client_ctx,
        set_request_credentials,
    )

    bearer: Optional[str] = None
    consumer_id: Optional[str] = None
    if ctx is not None:
        rc = getattr(ctx, "request_context", None)
        if rc is not None:
            req = getattr(rc, "request", None)
            if req is not None:
                scope = getattr(req, "scope", None)
                if scope is not None:
                    state = scope.get("state") or {}
                    bearer = state.get("selph_bearer_token") or None
                    consumer_id = state.get("selph_consumer_id") or None

    tok_b, tok_c = set_request_credentials(bearer, consumer_id)
    # Open a fresh cache slot for this request scope. Setting to None here
    # ensures that a stale cached client from a previous request (same
    # coroutine context) is not accidentally reused.
    tok_client = _request_client_ctx.set(None)
    try:
        yield
    finally:
        # Close the per-request EngineClient if it was lazily instantiated
        # during the tool call. This releases the httpx.AsyncClient + its
        # connection pool and prevents FD leaks under mounted load.
        #
        # Use a nested try/finally so contextvar resets ALWAYS run, even if
        # aclose() raises (including asyncio.CancelledError on task abort).
        # Skipping the resets would leak stale request credentials into the
        # next coroutine that reuses this contextvar scope.
        try:
            cached = _request_client_ctx.get()
            if cached is not None:
                try:
                    await cached.aclose()
                except Exception as exc:  # noqa: BLE001
                    log_event(
                        _log, logging.WARNING, "mcp.mounted_client.close_failed",
                        error_type=type(exc).__name__,
                        error=str(exc)[:300],
                    )
        finally:
            _request_client_ctx.reset(tok_client)
            _request_bearer_ctx.reset(tok_b)
            _request_consumer_id_ctx.reset(tok_c)


# ─────────────────────────────────────────────────────────────────────────────
# Lifespan context
# ─────────────────────────────────────────────────────────────────────────────


def _lifespan_attr(ctx: Optional[Context], name: str) -> Any:
    """Return ``ctx.request_context.lifespan_context.<name>`` or ``None``.

    The lifespan context shape is owned by the host that invokes
    ``create_mcp_app`` — typically the FastAPI lifespan in
    ``ingestion_api/main.py`` (which already owns ``app.state.neo4j``
    and ``app.state.chroma``). When the MCP server runs out-of-process
    it bootstraps its own lifespan; either way the kernel tools
    expect ``.neo4j`` and ``.chroma`` attributes.
    """
    if ctx is None:
        return None
    rc = getattr(ctx, "request_context", None)
    if rc is None:
        return None
    lc = getattr(rc, "lifespan_context", None)
    if lc is None:
        return None
    return getattr(lc, name, None)


def _safe_envelope_dump(envelope: Any) -> Dict[str, Any]:
    """Serialize a :class:`PersonaResponse` envelope to a plain dict.

    Uses ``mode="json"`` so nested datetimes/enums round-trip cleanly
    for the MCP transport. Falls back to ``dict(envelope)`` when the
    passed object is already a plain dict (defensive — some handlers
    may return a raw dict on an early-exit path).
    """
    if hasattr(envelope, "model_dump"):
        try:
            return envelope.model_dump(mode="json")
        except Exception:  # noqa: BLE001
            pass
    if isinstance(envelope, dict):
        return envelope
    return {"envelope": str(envelope)}
