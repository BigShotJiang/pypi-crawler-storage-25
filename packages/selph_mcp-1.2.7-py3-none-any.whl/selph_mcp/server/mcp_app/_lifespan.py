"""MCPLifespanContext dataclass and lifespan implementations (default + host-provided)."""
from __future__ import annotations

import asyncio
import logging
import os
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from pathlib import Path as _Path
from typing import Any, AsyncIterator, Dict, Optional, Set

from mcp.server.fastmcp import FastMCP

from ._helpers import _log, log_event

# ─────────────────────────────────────────────────────────────────────────────
# Lifespan context dataclass
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class MCPLifespanContext:
    """Context handed to every tool call via
    ``ctx.request_context.lifespan_context``.

    The kernel adapters look up ``.neo4j`` and ``.chroma`` here through
    :func:`_lifespan_attr` — without these the ``query`` and
    ``observe(deep_ingest=true)`` tools hard-fail.

    Phase 2 additions
    -----------------
    ``insight_synthesizer`` is optional and only consulted when the
    persona surface requests ``mode="insight"``. The default lifespan
    does NOT import or populate it — the Phase 2 boundary constraint is
    that ``selph_mcp`` cannot reach into ``selph_apps`` (the
    ``mcp-surface-boundary`` import-linter contract). A host that
    wishes to enable insight synthesis is responsible for:

      1. Constructing its own lifespan that calls this dataclass with
         an ``insight_synthesizer`` callable (typically a thin
         adapter around ``selph_apps.answering.synthesize_evidence``),
      2. Passing that lifespan into :func:`create_mcp_app` via the
         ``lifespan=`` kwarg.

    When ``insight_synthesizer`` is ``None`` the persona layer
    silently degrades ``insight`` requests to ``targeted`` + a
    warning marker in the response. This keeps the kernel/persona
    code import-clean.
    """

    neo4j: Any = None
    chroma: Any = None
    insight_synthesizer: Optional[Any] = None
    self_entity_id: Optional[str] = None
    background_tasks: Set[asyncio.Task[Any]] = field(default_factory=set)
    # Pass B — engine adapter and transport label.
    # ``engine`` is the EngineAdapter instance used by kernel tools.
    # ``transport`` is stamped on every tool log as ``mcp_transport``.
    # Default "stdio" keeps the _default_lifespan path byte-identical.
    engine: Optional[Any] = None  # EngineAdapter
    transport: str = "stdio"


# ─────────────────────────────────────────────────────────────────────────────
# Default lifespan (Neo4j + Chroma init/teardown)
# ─────────────────────────────────────────────────────────────────────────────


@asynccontextmanager
async def _default_lifespan(server: "FastMCP") -> AsyncIterator[MCPLifespanContext]:
    """Boot the shared Neo4j + Chroma clients the kernel tools need.

    Mirrors the legacy ``selph_mcp/server.py`` lifespan but stays inside
    the Surface-layer import boundary (selph_db / selph_graph /
    selph_shared only — no ``ingestion_api`` imports). On shutdown the
    Neo4j driver and the entity Postgres pool are closed cleanly so a
    subprocess reload does not leak connections back to Azure.
    """
    log_event(
        _log, logging.INFO, "mcp.server.lifespan.start",
        pool_max=os.getenv("SELPH_KG_DB_POOL_MAX"),
        checkpoint_pool_max=os.getenv("CHECKPOINT_POOL_MAX"),
    )

    # Engine contract-version handshake — runs FIRST, before any other
    # resource is constructed, so a stale-wheel-vs-new-engine mismatch
    # fails fast without leaking Neo4j / Chroma / Postgres pool. The
    # handshake itself only allocates the (cheap) httpx singleton.
    from selph_mcp._client import get_client
    engine_client = get_client()
    await engine_client.startup()

    # Neo4j ------------------------------------------------------------
    from selph_graph.graph_upserter import Neo4jConnection
    neo4j_conn: Any = None
    try:
        neo4j_conn = Neo4jConnection()
        log_event(_log, logging.INFO, "mcp.server.lifespan.neo4j_ready")
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "mcp.server.lifespan.neo4j_failed",
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )

    # Chroma + predicates collection seed -----------------------------
    from selph_db.chroma_predicate import (
        init_chroma_client,
        seed_predicates_collection,
    )
    chroma_client: Any = None
    # BaseException (not Exception) because chromadb's Rust bindings raise
    # ``pyo3_runtime.PanicException`` which inherits from BaseException in
    # the pinned pyo3 version. A panic pointed at a corrupt/incompatible
    # local ChromaDB directory would otherwise kill the MCP process before
    # any tool could serve. Chroma is optional at startup — tools that
    # need it (predicate similarity) will log their own miss.
    # Resolve the predicates JSON relative to the package so lifespan
    # startup survives when the MCP subprocess is launched from any
    # cwd (e.g. Claude Code stdio launches don't honor the ``cwd``
    # field in ~/.claude.json on every platform — see PYTHONPATH
    # fallback in the installer). Walking up from
    # ``selph_mcp/server/mcp_app/`` lands at the repo root, then
    # joins the documented static asset path.
    _repo_root = _Path(__file__).resolve().parent.parent.parent.parent
    _preds_json_path = _repo_root / "Selph" / "Predicates" / \
        "relationships_predicates.json"
    try:
        chroma_client = init_chroma_client(
            chroma_path=os.getenv("CHROMA_PATH", "./ChromaDB"),
            chroma_host=os.getenv("CHROMA_HOST"),
            chroma_port=int(os.getenv("CHROMA_PORT", "8000")),
        )
        seed_predicates_collection(
            client=chroma_client,
            json_path=str(_preds_json_path),
            collection_name="Predicates",
            clear=os.getenv("CHROMA_CLEAR_AT_BOOT", "false").lower() == "true",
            batch_size=64,
        )
        log_event(_log, logging.INFO, "mcp.server.lifespan.chroma_ready")
    except BaseException as exc:  # noqa: BLE001
        chroma_client = None
        log_event(
            _log, logging.ERROR, "mcp.server.lifespan.chroma_failed",
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )

    # Fix C3: wire a real synthesizer callable onto the default lifespan.
    # Without this the shipped ``run_stdio`` / ``run_sse`` entrypoints
    # silently degrade every ``depth=insight`` read to ``targeted`` and
    # report ``mode_used=insight`` — lying to the client. The
    # ``.importlinter`` carve-out permits mcp_app.py (the composition
    # root) to reach into ``selph_apps.answering`` for the synthesis
    # agent; the kernel + persona tool modules remain import-clean.
    insight_synthesizer: Optional[Any] = None
    try:
        from selph_apps.answering.synthesis import (
            EvidenceBundle,
            synthesize_evidence,
        )

        async def _default_insight_synthesizer(
            *,
            question: str,
            bundles: Any,
            user_id: Optional[str] = None,
            self_entity_id: Optional[str] = None,
        ) -> Dict[str, Any]:
            """Adapter wrapping ``synthesize_evidence`` for the MCP kernel.

            The kernel calls the synthesizer with ``bundles`` as a list
            of dicts (the raw anchor records from ``query_to_answer_v2``).
            ``synthesize_evidence`` expects
            :class:`selph_apps.answering.synthesis.EvidenceBundle`
            objects — we adapt at the boundary so the kernel stays
            import-clean.
            """
            # Pack all records into a single bundle — phase 2 does not
            # yet sub-decompose the query into multiple bundles here.
            # Future work: teach the kernel to pass pre-bucketed
            # bundles through when the query decomposer lands.
            record_list = list(bundles or [])
            ev_bundle = EvidenceBundle(
                sub_question=question,
                traversal_focus="mcp_persona_insight",
                records=record_list,
            )
            result = await synthesize_evidence(
                question=question,
                bundles=[ev_bundle],
                user_id=user_id,
                self_entity_id=self_entity_id,
            )
            return {
                "status": "ok",
                "thinking": result.thinking,
                "answer": result.answer,
                "evidence_used": list(result.evidence_used or []),
                "confidence": result.confidence,
            }

        insight_synthesizer = _default_insight_synthesizer
        log_event(
            _log, logging.INFO, "mcp.server.lifespan.insight_synthesizer_ready",
        )
    except Exception as exc:  # noqa: BLE001
        # Fail soft: the kernel degrades insight → targeted with an
        # ``insight_disabled`` marker when the synthesizer is None, so
        # the MCP surface still functions if the app-layer import breaks
        # (e.g. a missing transitive dep in a slim deployment image).
        log_event(
            _log, logging.WARNING,
            "mcp.server.lifespan.insight_synthesizer_unavailable",
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        insight_synthesizer = None

    # Pass B: wire HttpEngineAdapter for stdio (uses get_client() over HTTP).
    from selph_mcp.adapters.engine import HttpEngineAdapter as _HttpEngineAdapter
    _http_engine = _HttpEngineAdapter(engine_client)

    context = MCPLifespanContext(
        neo4j=neo4j_conn,
        chroma=chroma_client,
        insight_synthesizer=insight_synthesizer,
        self_entity_id=None,
        background_tasks=set(),
        engine=_http_engine,
        transport="stdio",
    )

    try:
        yield context
    finally:
        # Drain fire-and-forget background tasks (none today, but the
        # set lives on the context so future ``observe`` deep-ingest
        # work can register here without rewiring the lifespan).
        if context.background_tasks:
            pending = [t for t in context.background_tasks if not t.done()]
            if pending:
                log_event(
                    _log, logging.INFO, "mcp.server.lifespan.drain_bg_tasks",
                    outstanding=len(pending),
                )
                try:
                    await asyncio.wait_for(
                        asyncio.gather(*pending, return_exceptions=True),
                        timeout=30.0,
                    )
                except asyncio.TimeoutError:
                    still_pending = [t for t in pending if not t.done()]
                    for task in still_pending:
                        task.cancel()
                    log_event(
                        _log, logging.WARNING,
                        "mcp.server.lifespan.bg_tasks_cancelled",
                        cancelled=len(still_pending),
                    )

        # Close shared clients ---------------------------------------
        if neo4j_conn is not None:
            try:
                neo4j_conn.close()
            except Exception as exc:  # noqa: BLE001
                log_event(
                    _log, logging.WARNING,
                    "mcp.server.lifespan.neo4j_close_failed",
                    error_type=type(exc).__name__,
                    error=str(exc)[:300],
                )

        try:
            from selph_db.postgres_connection import close_pool
            close_pool()
        except Exception as exc:  # noqa: BLE001
            log_event(
                _log, logging.WARNING,
                "mcp.server.lifespan.entity_pool_close_failed",
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )

        # Drain the EngineClient httpx pool — keepalive sockets, HTTP/2
        # state, and any in-flight response buffers belong to the wheel,
        # not the GC.
        try:
            await engine_client.aclose()
        except Exception as exc:  # noqa: BLE001
            log_event(
                _log, logging.WARNING,
                "mcp.server.lifespan.engine_client_close_failed",
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )

        log_event(_log, logging.INFO, "mcp.server.lifespan.end")


# ─────────────────────────────────────────────────────────────────────────────
# Mounted-MCP concurrency cap (§5.8)
# ─────────────────────────────────────────────────────────────────────────────

_SELPH_MCP_MOUNT_CONCURRENCY: int = int(
    os.environ.get("SELPH_MCP_MOUNT_CONCURRENCY", "8")
)
"""Concurrency cap for mounted MCP tool dispatch (§5.8).

Default 8 (corrected from brief's 15 per Codex plan review).  Raise to 15
once ``pool.wait_ms`` data at real ingest + MCP load confirms headroom.
Persona-loopback audit (Pass A):
- 4 tools call get_client() directly (loopback HTTP):
    find_evidence, get_entity_card, drift_signal, recommendation_feedback
- 4 tools delegate to kernel (collapse to InProcessEngineAdapter in Pass B):
    ask_selph, get_context, observe_session, correct
- 4 tools already local/non-loopback:
    what_changed, hire_for_role, recommend_workflows, get_fingerprint

At default SELPH_MCP_MOUNT_CONCURRENCY=8 and worst-case 3 loopback pool
slots per call (MCP inbound + loopback outbound + engine route pool
acquisition), the cap consumes up to ~24 logical entity-pool slots against
the 80-conn budget.  Comfortable headroom vs concurrent ingest (CC=40 →
~47 conns) even when coincident.  Raising to 15 would consume ~45 slots
and becomes the trigger to raise SELPH_KG_DB_POOL_MAX in lockstep per
``rules/concurrency.md``.  Promote 8→15 if p95 pool.wait_ms stays < 50 ms
over a 24-hour window at real load.
"""

_mount_semaphore: Optional[asyncio.Semaphore] = None


def _get_mount_semaphore() -> asyncio.Semaphore:
    """Lazy singleton semaphore for mounted-MCP concurrency cap."""
    global _mount_semaphore  # noqa: PLW0603
    if _mount_semaphore is None:
        _mount_semaphore = asyncio.Semaphore(_SELPH_MCP_MOUNT_CONCURRENCY)
    return _mount_semaphore


@asynccontextmanager
async def _host_provided_lifespan(
    server: "FastMCP",
    *,
    host_app: Any,
) -> AsyncIterator[MCPLifespanContext]:
    """Lifespan for the mounted FastMCP instance (Pass A §6).

    Pulls ``neo4j`` / ``chroma`` from ``host_app.state`` — does NOT open
    its own Neo4j driver, Chroma client, or Postgres pool (non-negotiable §4.2).
    Does NOT call ``engine_client.startup()`` — the mounted binary is
    self-talking (loopback) so the contract-version handshake is irrelevant.
    Does NOT call ``_mount_versions_route`` — the host already serves
    ``/apps/mcp/server/versions`` (§5.5).

    ``insight_synthesizer`` is constructed inline using the same carve-out as
    ``_default_lifespan`` (``selph_mcp.server.mcp_app → selph_apps.answering.synthesis``
    is permitted by the ``mcp-surface-boundary`` importlinter contract).
    """
    log_event(
        _log, logging.INFO, "mcp.server.mounted_lifespan.start",
        concurrency_cap=_SELPH_MCP_MOUNT_CONCURRENCY,
    )

    neo4j_conn: Any = getattr(getattr(host_app, "state", None), "neo4j", None)
    chroma_client: Any = getattr(getattr(host_app, "state", None), "chroma", None)

    if neo4j_conn is None:
        log_event(
            _log, logging.WARNING, "mcp.server.mounted_lifespan.neo4j_missing",
            msg="host_app.state.neo4j is None — query/observe tools will hard-fail",
        )
    else:
        log_event(_log, logging.INFO, "mcp.server.mounted_lifespan.neo4j_bound")

    if chroma_client is None:
        log_event(
            _log, logging.WARNING, "mcp.server.mounted_lifespan.chroma_missing",
            msg="host_app.state.chroma is None — predicate similarity will degrade",
        )
    else:
        log_event(_log, logging.INFO, "mcp.server.mounted_lifespan.chroma_bound")

    # Construct the insight synthesizer inline — same pattern as _default_lifespan.
    insight_synthesizer: Optional[Any] = None
    try:
        from selph_apps.answering.synthesis import (
            EvidenceBundle,
            synthesize_evidence,
        )

        async def _mounted_insight_synthesizer(
            *,
            question: str,
            bundles: Any,
            user_id: Optional[str] = None,
            self_entity_id: Optional[str] = None,
        ) -> Dict[str, Any]:
            record_list = list(bundles or [])
            ev_bundle = EvidenceBundle(
                sub_question=question,
                traversal_focus="mcp_persona_insight_mounted",
                records=record_list,
            )
            result = await synthesize_evidence(
                question=question,
                bundles=[ev_bundle],
                user_id=user_id,
                self_entity_id=self_entity_id,
            )
            return {
                "status": "ok",
                "thinking": result.thinking,
                "answer": result.answer,
                "evidence_used": list(result.evidence_used or []),
                "confidence": result.confidence,
            }

        insight_synthesizer = _mounted_insight_synthesizer
        log_event(_log, logging.INFO, "mcp.server.mounted_lifespan.insight_synthesizer_ready")
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.WARNING,
            "mcp.server.mounted_lifespan.insight_synthesizer_unavailable",
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )

    # Pass B: wire the composite engine adapter.
    # InProcessEngineAdapter routes /core/* calls in-process.
    # HttpEngineAdapter handles /apps/correction/* (MUST stay HTTP — preserves
    # the ENABLE_CORRECTION_LAYER dark-launch gate at ingestion_api/main.py:58).
    from selph_mcp._client import get_client as _get_client
    from selph_mcp.adapters.engine import (
        CompositeEngineAdapter as _CompositeEngineAdapter,
        HttpEngineAdapter as _HttpEngineAdapter,
        InProcessEngineAdapter as _InProcessEngineAdapter,
    )
    _inprocess_engine = _InProcessEngineAdapter(host_app)
    # Pass the factory (not a pre-built client) so every loopback call
    # consults the contextvar-aware `get_client()` and picks up the
    # incoming caller's Bearer + X-Consumer-Id instead of the
    # env-bound singleton.
    _http_engine = _HttpEngineAdapter(client_factory=_get_client)
    _composite_engine = _CompositeEngineAdapter(_inprocess_engine, _http_engine)

    context = MCPLifespanContext(
        neo4j=neo4j_conn,
        chroma=chroma_client,
        insight_synthesizer=insight_synthesizer,
        self_entity_id=None,
        background_tasks=set(),
        engine=_composite_engine,
        transport="mounted",
    )

    try:
        yield context
    finally:
        # Drain fire-and-forget background tasks.
        if context.background_tasks:
            pending = [t for t in context.background_tasks if not t.done()]
            if pending:
                log_event(
                    _log, logging.INFO, "mcp.server.mounted_lifespan.drain_bg_tasks",
                    outstanding=len(pending),
                )
                try:
                    await asyncio.wait_for(
                        asyncio.gather(*pending, return_exceptions=True),
                        timeout=30.0,
                    )
                except asyncio.TimeoutError:
                    still_pending = [t for t in pending if not t.done()]
                    for task in still_pending:
                        task.cancel()
                    log_event(
                        _log, logging.WARNING,
                        "mcp.server.mounted_lifespan.bg_tasks_cancelled",
                        cancelled=len(still_pending),
                    )

        # NOTE: do NOT close neo4j_conn or chroma_client — they are owned
        # by the host FastAPI lifespan (ingestion_api/main.py) and will be
        # closed by the host on its own teardown path.
        log_event(_log, logging.INFO, "mcp.server.mounted_lifespan.end")
