"""Register persona read tools and hire_for_role (lines 736-1157 of original mcp_app.py)."""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Dict, Optional

from mcp.server.fastmcp import Context, FastMCP

from selph_mcp.contracts.read import (
    Constraints,
    Depth,
    GetContextRequest,
    Intent,
    Subject,
    TimeWindow,
)
from selph_mcp.persona.tools.ask_selph import ask_selph as persona_ask_selph
from selph_mcp.persona.tools.find_evidence import (
    find_evidence as persona_find_evidence,
)
from selph_mcp.persona.tools.get_context import get_context as persona_get_context
from selph_mcp.persona.tools.get_entity_card import (
    get_entity_card as persona_get_entity_card,
)
from selph_mcp.persona.tools.hire_for_role import (
    hire_for_role as persona_hire_for_role,
)
from selph_mcp.persona.tools.what_changed import (
    what_changed as persona_what_changed,
)

from ._helpers import (
    _consumer_from_ctx,
    _lifespan_attr,
    _log,
    _mounted_request_credentials,
    _safe_envelope_dump,
    log_event,
)


def _register_persona_read_tools(server: FastMCP) -> None:
    """Register get_context, ask_selph, what_changed, find_evidence, get_entity_card, hire_for_role."""

    @server.tool(
        name="get_context",
        description=(
            "Depth-aware persona read. Applies the deterministic depth "
            "router (brief/targeted/insight/evidence) with budget "
            "degradation and returns a PersonaResponse envelope with "
            "typed citations + etag + meta."
        ),
    )
    async def get_context_tool(
        subject: str,
        intent: str,
        depth: str = "auto",
        entity_id: Optional[str] = None,
        time_window_start: Optional[str] = None,
        time_window_end: Optional[str] = None,
        memory_types: Optional[list] = None,
        max_age_days: Optional[int] = None,
        sensitivity: str = "normal",
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.get_context.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="get_context",
            subject=subject,
            intent=intent,
            depth=depth,
            mcp_transport=_mcp_transport,
        )
        try:
            tw = None
            if time_window_start or time_window_end:
                tw = TimeWindow(start=time_window_start, end=time_window_end)
            # Fix E: thread the ``sensitivity`` MCP tool arg into
            # ``Constraints(...)``. Previously the arg was accepted by
            # the tool signature but dropped on the floor — invalid
            # values were silently ignored and valid values did not
            # alter the request hash or filter the response. Pass the
            # bare string through; Pydantic's strict Sensitivity enum
            # on Constraints raises ValidationError for unknown values
            # which we surface as a 400-equivalent envelope below.
            constraint_kwargs: Dict[str, Any] = {
                "entity_id": entity_id,
                "time_window": tw,
                "memory_types": list(memory_types or []),
                "max_age_days": max_age_days,
            }
            if sensitivity is not None:
                constraint_kwargs["sensitivity"] = sensitivity
            try:
                constraints = Constraints(**constraint_kwargs)
            except Exception as exc:  # noqa: BLE001 — pydantic ValidationError
                # Surface unknown ``sensitivity`` values (or any other
                # Constraints-level validation error) as a terse
                # ok=False envelope rather than raising through to the
                # MCP runtime. Keeps the tool contract symmetric with
                # other envelope-returning tools.
                from selph_mcp.contracts.envelope import (
                    BudgetTier as _BT,
                    ConsumerScope as _CS,
                    ModeUsed as _MU,
                )
                from selph_mcp.persona.envelope_builder import (
                    build_envelope as _build_envelope,
                )
                log_event(
                    _log, logging.WARNING, "mcp.tool.get_context.bad_constraints",
                    consumer_id=consumer.consumer_id,
                    user_id=consumer.user_id,
                    tool_name="get_context",
                    error_type=type(exc).__name__,
                    error=str(exc)[:300],
                    mcp_transport=_mcp_transport,
                )
                fallback = _build_envelope(
                    mode_used=_MU.none,
                    ok=False,
                    data={
                        "error": "invalid_sensitivity",
                        "allowed": ["normal", "cautious", "strict"],
                        "received": sensitivity,
                    },
                    citations=[],
                    meta_inputs={
                        "source_cutoff_at": "1970-01-01T00:00:00Z",
                        "staleness_status": "fresh",
                        "confidence": 0.0,
                        "etag": "invalid:constraints:validation:error",
                        "budget_tier": _BT.exhausted.value,
                        "consumer_scope": _CS.personal,
                        "sensitivity_class": consumer.sensitivity_ceiling.value,
                    },
                )
                return _safe_envelope_dump(fallback)
            request = GetContextRequest(
                subject=Subject(subject),
                intent=Intent(intent),
                depth=Depth(depth),
                constraints=constraints,
            )
            async with _mounted_request_credentials(ctx):
                envelope = await persona_get_context(
                    request=request,
                    consumer=consumer,
                    graph=_lifespan_attr(ctx, "neo4j"),
                    chroma=_lifespan_attr(ctx, "chroma"),
                    synthesizer=_lifespan_attr(ctx, "insight_synthesizer"),
                    self_entity_id=_lifespan_attr(ctx, "self_entity_id"),
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.get_context.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="get_context",
                mode_used=envelope.mode_used.value,
                duration_ms=duration_ms,
                mcp_transport=_mcp_transport,
            )
            return _safe_envelope_dump(envelope)
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.get_context.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="get_context",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="ask_selph",
        description=(
            "Ask Selph a question. Defaults intent=strategy and forces "
            "depth=insight unless explicitly overridden — routes through "
            "the persona insight synthesis path. Optional free-text "
            "domain_hint scopes retrieval (e.g. professional_context, "
            "social_context, daily_routines); unknown hints fall through "
            "to no scoping."
        ),
    )
    async def ask_selph_tool(
        question: str,
        subject: str = "self",
        intent: str = "strategy",
        depth: str = "insight",
        entity_id: Optional[str] = None,
        domain_hint: Optional[str] = None,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.ask_selph.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="ask_selph",
            subject=subject,
            intent=intent,
            depth=depth,
            domain_hint=domain_hint,
            question_len=len(question or ""),
            mcp_transport=_mcp_transport,
        )
        try:
            async with _mounted_request_credentials(ctx):
                envelope = await persona_ask_selph(
                    consumer=consumer,
                    question=question,
                    subject=subject,
                    intent=intent,
                    depth=depth,
                    entity_id=entity_id,
                    domain_hint=domain_hint,
                    graph=_lifespan_attr(ctx, "neo4j"),
                    chroma=_lifespan_attr(ctx, "chroma"),
                    synthesizer=_lifespan_attr(ctx, "insight_synthesizer"),
                    self_entity_id=_lifespan_attr(ctx, "self_entity_id"),
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.ask_selph.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="ask_selph",
                mode_used=envelope.mode_used.value,
                duration_ms=duration_ms,
                mcp_transport=_mcp_transport,
            )
            return _safe_envelope_dump(envelope)
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.ask_selph.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="ask_selph",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="what_changed",
        description=(
            "Return invalidation rows newer than since_cursor (or the "
            "consumer's etag_cursor when omitted). Cache-coherence "
            "read — zero budget cost."
        ),
    )
    async def what_changed_tool(
        since_cursor: Optional[int] = None,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.what_changed.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="what_changed",
            since_cursor=since_cursor,
            mcp_transport=_mcp_transport,
        )
        try:
            async with _mounted_request_credentials(ctx):
                envelope = await persona_what_changed(
                    consumer=consumer, since_cursor=since_cursor
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.what_changed.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="what_changed",
                duration_ms=duration_ms,
                mcp_transport=_mcp_transport,
            )
            return _safe_envelope_dump(envelope)
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.what_changed.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="what_changed",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="find_evidence",
        description=(
            "Return evidence payloads for citation_ids (MEM-/ENT-/HUB-). "
            "Filters through privacy scopes + redaction. Evidence mode."
        ),
    )
    async def find_evidence_tool(
        citation_ids: Optional[list] = None,
        subject: Optional[str] = None,
        intent: Optional[str] = None,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.find_evidence.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="find_evidence",
            id_count=len(citation_ids or []),
            subject=subject,
            intent=intent,
            mcp_transport=_mcp_transport,
        )
        try:
            async with _mounted_request_credentials(ctx):
                envelope = await persona_find_evidence(
                    consumer=consumer,
                    citation_ids=citation_ids,
                    subject=subject,
                    intent=intent,
                    graph=_lifespan_attr(ctx, "neo4j"),
                    chroma=_lifespan_attr(ctx, "chroma"),
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.find_evidence.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="find_evidence",
                duration_ms=duration_ms,
                mcp_transport=_mcp_transport,
            )
            return _safe_envelope_dump(envelope)
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.find_evidence.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="find_evidence",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="get_entity_card",
        description=(
            "Compact entity card — canonical_id, alias set, kind_hint, "
            "and recent memory count. Targeted mode."
        ),
    )
    async def get_entity_card_tool(
        ref_id: str,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.get_entity_card.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="get_entity_card",
            ref_id=ref_id,
            mcp_transport=_mcp_transport,
        )
        try:
            async with _mounted_request_credentials(ctx):
                envelope = await persona_get_entity_card(
                    consumer=consumer, ref_id=ref_id
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.get_entity_card.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="get_entity_card",
                ref_id=ref_id,
                duration_ms=duration_ms,
                mcp_transport=_mcp_transport,
            )
            return _safe_envelope_dump(envelope)
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.get_entity_card.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="get_entity_card",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="hire_for_role",
        description=(
            "Minimal role→workflow_id map. Unknown role → "
            "{status: unknown_role}. Phase 5 replaces this with an "
            "LLM-driven recommender."
        ),
    )
    async def hire_for_role_tool(
        role: str,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.hire_for_role.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="hire_for_role",
            role=role,
            mcp_transport=_mcp_transport,
        )
        try:
            async with _mounted_request_credentials(ctx):
                envelope = await persona_hire_for_role(consumer=consumer, role=role)
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.hire_for_role.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="hire_for_role",
                role=role,
                duration_ms=duration_ms,
                mcp_transport=_mcp_transport,
            )
            return _safe_envelope_dump(envelope)
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.hire_for_role.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="hire_for_role",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise
