"""Register the four kernel tools (observe, query, project, revise) onto a FastMCP server."""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Dict, Optional

from fastapi import HTTPException, status
from mcp.server.fastmcp import Context, FastMCP

from selph_mcp.contracts.correction import CorrectionPayload
from selph_mcp.contracts.writeback import IngestMode, SessionObservation
from selph_mcp.kernel import observe as kernel_observe
from selph_mcp.kernel import project as kernel_project
from selph_mcp.kernel import query as kernel_query
from selph_mcp.kernel import revise as kernel_revise

from ._helpers import (
    _consumer_from_ctx,
    _lifespan_attr,
    _log,
    _mounted_request_credentials,
    log_event,
)


# ─────────────────────────────────────────────────────────────────────────────
# Tool registration
# ─────────────────────────────────────────────────────────────────────────────

def _register_tools(server: FastMCP) -> None:
    """Wire the four kernel tools onto ``server``.

    Each tool:
      1. Calls :func:`_consumer_from_ctx` for auth (raises on failure).
      2. Adapts the tool params into the kernel adapter signature.
      3. Logs entry / complete / error per the mandatory coverage rule.
    """

    @server.tool(
        name="observe",
        description=(
            "Persist a harness session observation. Defaults to "
            "store_raw_only (Layer 1 only); set deep_ingest=true to run "
            "the full extraction pipeline. Returns "
            "{status, raw_evidence_id, mode, extraction, duration_ms}."
        ),
    )
    async def observe_tool(  # noqa: D401 — MCP tool docstring is the description
        consumer_id: str,
        harness_id: str,
        session_id: str,
        captured_at: str,
        speaker: str,
        text: str,
        deep_ingest: bool = False,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.observe.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="observe",
            session_id=session_id,
            deep_ingest=deep_ingest,
            text_len=len(text or ""),
            mcp_transport=_mcp_transport,
        )
        try:
            # ── Anti-bypass binding (§3.5.1) ────────────────────────────
            # Reject caller-supplied consumer_id / harness_id when they
            # disagree with the authenticated consumer row. A consumer
            # authenticated as ``cns-A`` must not be able to write
            # provenance metadata claiming ``cns-B`` (or some other
            # harness they don't own). Empty-string args are treated as
            # "not supplied" and silently filled from the consumer row.
            bound_consumer_id = consumer.consumer_id
            bound_harness_id = consumer.harness_id
            supplied_consumer = (consumer_id or "").strip()
            supplied_harness = (harness_id or "").strip()
            if supplied_consumer and supplied_consumer != bound_consumer_id:
                log_event(
                    _log, logging.WARNING,
                    "mcp.tool.observe.consumer_binding_violation",
                    consumer_id=bound_consumer_id,
                    user_id=consumer.user_id,
                    payload_consumer_id=supplied_consumer,
                )
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=(
                        "Payload consumer_id does not match the authenticated consumer."
                    ),
                )
            if supplied_harness and supplied_harness != bound_harness_id:
                log_event(
                    _log, logging.WARNING,
                    "mcp.tool.observe.harness_binding_violation",
                    consumer_id=bound_consumer_id,
                    user_id=consumer.user_id,
                    bound_harness_id=bound_harness_id,
                    payload_harness_id=supplied_harness,
                )
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=(
                        "Payload harness_id does not match the authenticated consumer."
                    ),
                )

            observation = SessionObservation(
                consumer_id=bound_consumer_id,
                harness_id=bound_harness_id,
                session_id=session_id,
                captured_at=captured_at,  # pydantic parses ISO-8601
                speaker=speaker,
                text=text,
                mode=IngestMode.deep_ingest if deep_ingest else IngestMode.store_raw_only,
            )
            async with _mounted_request_credentials(ctx):
                result = await kernel_observe.observe_session(
                    consumer=consumer,
                    observation=observation,
                    graph=_lifespan_attr(ctx, "neo4j"),
                    engine=_lifespan_attr(ctx, "engine"),
                    mcp_transport=_mcp_transport,
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.observe.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="observe",
                duration_ms=duration_ms,
                raw_evidence_id=result.get("raw_evidence_id"),
                mode=result.get("mode"),
                mcp_transport=_mcp_transport,
            )
            return result
        except HTTPException:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.WARNING, "mcp.tool.observe.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="observe",
                duration_ms=duration_ms,
                error_type="HTTPException",
                mcp_transport=_mcp_transport,
            )
            raise
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.observe.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="observe",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="query",
        description=(
            "Run a natural-language query against the persona KG. "
            "Returns {status, data, timing_ms, duration_ms}."
        ),
    )
    async def query_tool(
        query_text: str,
        tz: str = "America/Chicago",
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.query.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="query",
            query_len=len(query_text or ""),
            tz=tz,
            mcp_transport=_mcp_transport,
        )
        try:
            async with _mounted_request_credentials(ctx):
                result = await kernel_query.query(
                    consumer=consumer,
                    query_text=query_text,
                    graph=_lifespan_attr(ctx, "neo4j"),
                    chroma=_lifespan_attr(ctx, "chroma"),
                    tz=tz,
                    engine=_lifespan_attr(ctx, "engine"),
                    mcp_transport=_mcp_transport,
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.query.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="query",
                duration_ms=duration_ms,
                status=result.get("status"),
                mcp_transport=_mcp_transport,
            )
            return result
        except HTTPException:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.WARNING, "mcp.tool.query.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="query",
                duration_ms=duration_ms,
                error_type="HTTPException",
                mcp_transport=_mcp_transport,
            )
            raise
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.query.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="query",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="project",
        description=(
            "Read the latest hub payload for (user_id, hub_type). "
            "Sync read — never triggers a rebuild. Returns "
            "{status, user_id, hub_type, payload, duration_ms}."
        ),
    )
    async def project_tool(
        hub_type: str,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.project.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="project",
            hub_type=hub_type,
            mcp_transport=_mcp_transport,
        )
        try:
            async with _mounted_request_credentials(ctx):
                result = await kernel_project.project(
                    consumer=consumer,
                    hub_type=hub_type,
                    engine=_lifespan_attr(ctx, "engine"),
                    mcp_transport=_mcp_transport,
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.project.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="project",
                hub_type=hub_type,
                duration_ms=duration_ms,
                status=result.get("status"),
                mcp_transport=_mcp_transport,
            )
            return result
        except HTTPException:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.WARNING, "mcp.tool.project.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="project",
                duration_ms=duration_ms,
                error_type="HTTPException",
                mcp_transport=_mcp_transport,
            )
            raise
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.project.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="project",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="revise",
        description=(
            "Apply a structured persona correction. Dispatches per the "
            "§3.4 compile table — all 12 cells are live ops (Phase 3 "
            "wired supersede for memory/identity_claim + "
            "reject_recommendation). Returns the underlying "
            "manager_result; unmapped (action, target_type) pairs return "
            "HTTP 400."
        ),
    )
    async def revise_tool(
        payload: Dict[str, Any],
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.revise.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="revise",
            action=(payload or {}).get("action"),
            target_type=(payload or {}).get("target_type"),
            mcp_transport=_mcp_transport,
        )
        try:
            structured = CorrectionPayload(**payload)
            async with _mounted_request_credentials(ctx):
                result = await kernel_revise.revise(
                    consumer=consumer,
                    payload=structured,
                    engine=_lifespan_attr(ctx, "engine"),
                    mcp_transport=_mcp_transport,
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.revise.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="revise",
                action=structured.action.value,
                target_type=structured.target_type.value,
                duration_ms=duration_ms,
                status=(result or {}).get("status"),
                mcp_transport=_mcp_transport,
            )
            return result
        except HTTPException:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.WARNING, "mcp.tool.revise.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="revise",
                duration_ms=duration_ms,
                error_type="HTTPException",
                mcp_transport=_mcp_transport,
            )
            raise
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.revise.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="revise",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise
