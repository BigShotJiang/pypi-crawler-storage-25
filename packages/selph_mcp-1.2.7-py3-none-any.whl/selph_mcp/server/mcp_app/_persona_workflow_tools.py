"""Register persona workflow tools: recommendation_feedback, recommend_workflows, get_fingerprint, drift_signal (lines 1286-1575)."""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Dict, Optional

from fastapi import HTTPException
from mcp.server.fastmcp import Context, FastMCP

from selph_mcp.contracts.writeback import FeedbackOutcome
from selph_mcp.persona.tools.drift_signal import (
    drift_signal as persona_drift_signal,
)
from selph_mcp.persona.tools.get_fingerprint import (
    get_fingerprint as persona_get_fingerprint,
)
from selph_mcp.persona.tools.recommendation_feedback import (
    recommendation_feedback as persona_recommendation_feedback,
)
from selph_mcp.persona.tools.recommend_workflows import (
    recommend_workflows as persona_recommend_workflows,
)

from ._helpers import (
    _consumer_from_ctx,
    _lifespan_attr,
    _log,
    _mounted_request_credentials,
    _safe_envelope_dump,
    log_event,
)


def _register_persona_workflow_tools(server: FastMCP) -> None:
    """Register recommendation_feedback, recommend_workflows, get_fingerprint, drift_signal."""

    @server.tool(
        name="recommendation_feedback",
        description=(
            "Record an outcome for a previously surfaced workflow "
            "recommendation (accepted/skipped/modified/deferred/rejected). "
            "Writes to selph_recommendation_feedback. Idempotent on "
            "feedback_event_key. Zero budget cost."
        ),
    )
    async def recommendation_feedback_tool(
        feedback_event_key: str,
        outcome: str,
        notes: Optional[str] = None,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.recommendation_feedback.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="recommendation_feedback",
            feedback_event_key=feedback_event_key,
            outcome=outcome,
            has_notes=notes is not None,
            mcp_transport=_mcp_transport,
        )
        try:
            # Coerce the bare string to the strict Phase 1a enum. Unknown
            # values surface as a ValueError → HTTPException(400) below.
            try:
                outcome_enum = FeedbackOutcome(outcome)
            except ValueError as exc:
                log_event(
                    _log, logging.WARNING,
                    "mcp.tool.recommendation_feedback.bad_outcome",
                    consumer_id=consumer.consumer_id,
                    user_id=consumer.user_id,
                    tool_name="recommendation_feedback",
                    received_outcome=outcome,
                    error=str(exc),
                    mcp_transport=_mcp_transport,
                )
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"outcome must be one of "
                        f"{[o.value for o in FeedbackOutcome]}; got {outcome!r}"
                    ),
                ) from exc

            async with _mounted_request_credentials(ctx):
                envelope = await persona_recommendation_feedback(
                    consumer=consumer,
                    feedback_event_key=feedback_event_key,
                    outcome=outcome_enum,
                    notes=notes,
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO,
                "mcp.tool.recommendation_feedback.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="recommendation_feedback",
                feedback_event_key=feedback_event_key,
                outcome=outcome_enum.value,
                duration_ms=duration_ms,
                mcp_transport=_mcp_transport,
            )
            return _safe_envelope_dump(envelope)
        except HTTPException:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.WARNING,
                "mcp.tool.recommendation_feedback.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="recommendation_feedback",
                duration_ms=duration_ms,
                error_type="HTTPException",
                mcp_transport=_mcp_transport,
            )
            raise
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR,
                "mcp.tool.recommendation_feedback.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="recommendation_feedback",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="recommend_workflows",
        description=(
            "Return ranked workflow recommendations for this consumer "
            "using the heuristic ranker (Phase 5 §6.2). Reads 5 hub "
            "payloads and 4 memory counts; no LLM. Returns "
            "{recommendations: [...]} sorted by score desc, each with "
            "workflow_id, score, confidence, top_reasons, "
            "supporting_signals, missing_information, "
            "feedback_event_key. Brief budget cost (0.2 credits)."
        ),
    )
    async def recommend_workflows_tool(
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.recommend_workflows.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="recommend_workflows",
            subject="self",
            intent="workflow_recommendation",
            mcp_transport=_mcp_transport,
        )
        try:
            async with _mounted_request_credentials(ctx):
                envelope = await persona_recommend_workflows(consumer=consumer)
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.recommend_workflows.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="recommend_workflows",
                mode_used=envelope.mode_used.value,
                etag=getattr(getattr(envelope, "meta", None), "etag", None),
                budget_tier=(
                    getattr(getattr(envelope, "meta", None), "budget_tier",
                            consumer.budget_tier).value
                    if hasattr(
                        getattr(getattr(envelope, "meta", None), "budget_tier",
                                None), "value"
                    ) else consumer.budget_tier.value
                ),
                duration_ms=duration_ms,
                mcp_transport=_mcp_transport,
            )
            return _safe_envelope_dump(envelope)
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.recommend_workflows.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="recommend_workflows",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="get_fingerprint",
        description=(
            "Preflight endpoint: compute the Selph query fingerprint for a "
            "(tool, params) pair without performing any graph read, LLM call, "
            "or DB write. Rate-limited at the brief budget cost per call. "
            "Returns {query_fingerprint, canonicalization_version, "
            "dependency_vocabulary_version}."
        ),
    )
    async def get_fingerprint_tool(
        tool: str,
        params: Optional[Dict[str, Any]] = None,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.get_fingerprint.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="get_fingerprint",
            target_tool=tool,
            mcp_transport=_mcp_transport,
        )
        try:
            async with _mounted_request_credentials(ctx):
                envelope = await persona_get_fingerprint(
                    consumer=consumer,
                    tool=tool,
                    params=params or {},
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.get_fingerprint.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="get_fingerprint",
                target_tool=tool,
                duration_ms=duration_ms,
                mcp_transport=_mcp_transport,
            )
            return _safe_envelope_dump(envelope)
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.get_fingerprint.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="get_fingerprint",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="drift_signal",
        description=(
            "Flag that the harness's local cache disagrees with Selph "
            "(etag no longer produces the same logical result). Writes "
            "to mcp_drift_signals for offline investigation — no live "
            "mutation and no cache invalidation. Zero budget cost."
        ),
    )
    async def drift_signal_tool(
        etag: str,
        observed_local_state: Dict[str, Any],
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.drift_signal.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="drift_signal",
            etag=etag,
            mcp_transport=_mcp_transport,
        )
        try:
            async with _mounted_request_credentials(ctx):
                envelope = await persona_drift_signal(
                    consumer=consumer,
                    etag=etag,
                    observed_local_state=observed_local_state,
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.drift_signal.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="drift_signal",
                duration_ms=duration_ms,
                mcp_transport=_mcp_transport,
            )
            return _safe_envelope_dump(envelope)
        except HTTPException:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.WARNING, "mcp.tool.drift_signal.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="drift_signal",
                duration_ms=duration_ms,
                error_type="HTTPException",
                mcp_transport=_mcp_transport,
            )
            raise
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.drift_signal.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="drift_signal",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise
