"""Entry point guard for ``python -m selph_mcp.server.mcp_app``."""
raise SystemExit(
    "Direct invocation of selph_mcp.server.mcp_app is unsupported because "
    "auth/kernel modules import-time-init the Postgres pool before "
    "transport defaults can be applied. Use 'python -m selph_mcp.run_stdio' "
    "or 'python -m selph_mcp.run_sse' instead — those wrappers call "
    "apply_transport_defaults() before any pool initialization."
)
