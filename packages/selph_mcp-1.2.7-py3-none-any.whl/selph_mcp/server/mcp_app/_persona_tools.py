"""Wire the 11 persona tools onto a FastMCP server (Phase 5)."""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from ._persona_read_tools import _register_persona_read_tools
from ._persona_writeback_tools import _register_persona_writeback_tools
from ._persona_workflow_tools import _register_persona_workflow_tools


def _register_persona_tools(server: FastMCP) -> None:
    """Wire the 11 persona tools onto ``server`` (Phase 5).

    Phase 2 delivered 8 tools; Phase 3 adds ``recommendation_feedback``
    and ``drift_signal``; Phase 5 adds ``recommend_workflows``.

    Each tool:
      1. Calls :func:`_consumer_from_ctx` for auth (raises on failure).
      2. Adapts the tool params into the persona handler signature.
      3. Derives ``user_id`` from the authenticated consumer row —
         NEVER from tool args (§3.5.1 anti-bypass).
      4. Pulls Neo4j / Chroma / synthesizer from lifespan context.
      5. Logs entry / complete / error per the mandatory coverage rule.

    Registration order matches the original mcp_app.py:
      get_context, ask_selph, what_changed, find_evidence,
      get_entity_card, hire_for_role  (read group)
      observe_session, correct         (writeback group)
      recommendation_feedback, recommend_workflows,
      get_fingerprint, drift_signal    (workflow group)
    """
    _register_persona_read_tools(server)
    _register_persona_writeback_tools(server)
    _register_persona_workflow_tools(server)
