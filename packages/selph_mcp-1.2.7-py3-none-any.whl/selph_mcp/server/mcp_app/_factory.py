"""Public factory + runners: create_mcp_app, run_stdio, run_http."""
from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import FastMCP

from selph_mcp._log import configure_logging

from ._helpers import _log, log_event
from ._kernel_tools import _register_tools
from ._lifespan import _default_lifespan
from ._persona_tools import _register_persona_tools
from ._versions_route import _mount_versions_route


# ─────────────────────────────────────────────────────────────────────────────
# Public factory + runners
# ─────────────────────────────────────────────────────────────────────────────

def create_mcp_app(
    name: str = "selph",
    *,
    lifespan: Any = None,
    host: str = "127.0.0.1",
    port: int = 8765,
) -> FastMCP:
    """Build the MCP app with all 15 tools registered.

    Tool count: 4 kernel (observe, query, project, revise) + 11 persona
    (Phase 2 set plus Phase 3 ``recommendation_feedback`` +
    ``drift_signal`` plus Phase 5 ``recommend_workflows``).

    Installs :func:`_default_lifespan` unless the caller supplies its
    own — the kernel tools require ``.neo4j`` / ``.chroma`` on the
    lifespan context, so a missing lifespan would hard-fail
    ``query`` and ``observe(deep_ingest=true)`` at runtime.

    The ``port`` argument flows through to the FastMCP constructor —
    ``FastMCP.run("streamable-http")`` does NOT accept a ``port=``
    kwarg, so the value must be set at construction time.

    Does NOT bind the server. The caller picks the transport via
    :func:`run_stdio` or :func:`run_http`.
    """
    chosen_lifespan = lifespan if lifespan is not None else _default_lifespan
    server = FastMCP(
        name=name,
        instructions=(
            "Selph MCP surface (Phase 1b kernel + Phase 2 persona + "
            "Phase 3 writeback/correction + Phase 5 workflow library + "
            "Phase 1 harness context). "
            "Kernel tools: observe, query, project, revise. "
            "Persona tools: get_context, ask_selph, what_changed, "
            "find_evidence, get_entity_card, hire_for_role, "
            "observe_session, correct, recommendation_feedback, "
            "drift_signal, recommend_workflows, get_fingerprint."
        ),
        lifespan=chosen_lifespan,
        host=host,
        port=port,
    )
    _register_tools(server)
    _register_persona_tools(server)

    # §3.6 — register the /apps/mcp/server/versions route and attach
    # contract-version header middleware to the FastMCP app.
    _mount_versions_route(server)

    log_event(
        _log, logging.INFO, "mcp.server.created",
        server_name=name,
        tool_count=16,  # 4 kernel + 12 persona (Phase 2: 8, Phase 3: +2, Phase 5: +1, Phase 1 harness: +1)
        lifespan="default" if lifespan is None else "custom",
    )
    return server


def run_stdio() -> None:
    """Run the kernel MCP over the stdio transport.

    Per ``CLAUDE.md`` this is NEVER invoked locally — wire it into
    Claude Code via ``.mcp.json`` (``command: python``,
    ``args: ["-m", "selph_mcp.server.mcp_app", "stdio"]``).
    """
    # §5.6: configure_logging() is called here (entry-point scope) rather than
    # at module-import time so it only fires in standalone mode — not when
    # ingestion_api.main imports this module for the mounted-MCP path.
    configure_logging()
    create_mcp_app().run("stdio")


def run_http(port: int = 8765, host: str = "127.0.0.1") -> None:
    """Run the kernel MCP over the streamable-HTTP transport.

    Defaults to port 8765 — operators override via the deployment
    config. NEVER invoked locally. The port is passed through the
    FastMCP constructor (``FastMCP.run("streamable-http")`` itself
    does not accept ``port=``).
    """
    # §5.6: same guard as run_stdio() — call configure_logging() at the entry
    # point, not at module-import time, to avoid the host-logger regression.
    configure_logging()
    create_mcp_app(port=port, host=host).run("streamable-http")


__all__ = ["create_mcp_app", "run_stdio", "run_http"]


if __name__ == "__main__":  # pragma: no cover — operator entry point
    raise SystemExit(
        "Direct invocation of selph_mcp.server.mcp_app is unsupported because "
        "auth/kernel modules import-time-init the Postgres pool before "
        "transport defaults can be applied. Use 'python -m selph_mcp.run_stdio' "
        "or 'python -m selph_mcp.run_sse' instead — those wrappers call "
        "apply_transport_defaults() before any pool initialization."
    )
