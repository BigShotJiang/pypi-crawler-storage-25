"""Register persona writeback tools: observe_session, correct (lines 1159-1284 of original)."""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Dict, Optional

from mcp.server.fastmcp import Context, FastMCP

from selph_mcp.contracts.correction import CorrectionPayload
from selph_mcp.contracts.writeback import IngestMode, SessionObservation
from selph_mcp.persona.tools.correct import correct as persona_correct
from selph_mcp.persona.tools.observe_session import (
    observe_session as persona_observe_session,
)

from ._helpers import (
    _consumer_from_ctx,
    _lifespan_attr,
    _log,
    _mounted_request_credentials,
    _safe_envelope_dump,
    log_event,
)


def _register_persona_writeback_tools(server: FastMCP) -> None:
    """Register observe_session and correct tools."""

    @server.tool(
        name="observe_session",
        description=(
            "Persist a harness session observation as Layer 1 raw "
            "evidence (source=harness_session). Default store_raw_only; "
            "opt-in deep_ingest runs the full extraction pipeline."
        ),
    )
    async def observe_session_tool(
        session_id: str,
        captured_at: str,
        speaker: str,
        text: str,
        deep_ingest: bool = False,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.observe_session.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="observe_session",
            session_id=session_id,
            deep_ingest=deep_ingest,
            text_len=len(text or ""),
            mcp_transport=_mcp_transport,
        )
        try:
            observation = SessionObservation(
                consumer_id=consumer.consumer_id,
                harness_id=consumer.harness_id,
                session_id=session_id,
                captured_at=captured_at,
                speaker=speaker,
                text=text,
                mode=(
                    IngestMode.deep_ingest if deep_ingest else IngestMode.store_raw_only
                ),
            )
            async with _mounted_request_credentials(ctx):
                envelope = await persona_observe_session(
                    consumer=consumer,
                    observation=observation,
                    graph=_lifespan_attr(ctx, "neo4j"),
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.observe_session.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="observe_session",
                session_id=session_id,
                duration_ms=duration_ms,
                mcp_transport=_mcp_transport,
            )
            return _safe_envelope_dump(envelope)
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.observe_session.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="observe_session",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="correct",
        description=(
            "Apply a structured correction. Verbs:\n\n"
            "  replace      — overwrite the value with a corrected one\n"
            "  retract      — withdraw: \"this should never have been recorded\"\n"
            "  expire       — mark as no longer current: \"was true at the time, no longer is\"\n"
            "  reinstate    — un-retract a previously retracted memory\n"
            "  reattribute  — point the record at a different entity\n"
            "  supersede    — replace with a newer version (preserves the old)\n"
            "  reject_recommendation — reject a recommendation served to the user\n\n"
            "Zero budget cost."
        ),
    )
    async def correct_tool(
        payload: Dict[str, Any],
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.correct.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="correct",
            action=(payload or {}).get("action"),
            target_type=(payload or {}).get("target_type"),
            mcp_transport=_mcp_transport,
        )
        try:
            structured = CorrectionPayload(**payload)
            async with _mounted_request_credentials(ctx):
                envelope = await persona_correct(
                    consumer=consumer, payload=structured
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.correct.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="correct",
                action=structured.action.value,
                target_type=structured.target_type.value,
                duration_ms=duration_ms,
                mcp_transport=_mcp_transport,
            )
            return _safe_envelope_dump(envelope)
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.correct.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="correct",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise
