"""Build the MCP ASGI sub-app for mounting on the host FastAPI process."""
from __future__ import annotations

import functools as _functools
import logging
import os
from typing import Any

from mcp.server.fastmcp import FastMCP

from ._helpers import _log, log_event
from ._kernel_tools import _register_tools
from ._lifespan import (
    _SELPH_MCP_MOUNT_CONCURRENCY,
    _get_mount_semaphore,
    _host_provided_lifespan,
)
from ._persona_tools import _register_persona_tools


def build_mounted_mcp(host_app: Any) -> "Starlette":  # type: ignore[name-defined]
    """Build the MCP ASGI sub-app for mounting on the host FastAPI process.

    Pass A §6 — this function is **dormant** in Pass A.  ``ingestion_api/main.py``
    does NOT import or call it yet; that wiring happens in Pass B.

    Returns a ``starlette.applications.Starlette`` (the ASGI sub-app produced by
    ``FastMCP.streamable_http_app()``) with:
    - All 16 tools registered (4 kernel + 12 persona) — identical to
      ``create_mcp_app()``.
    - ``streamable_http_path="/"`` so the JSON-RPC endpoint is served at the
      sub-app root (§5.4).  ``app.mount("/mcp", ...)`` then exposes it at
      ``POST /mcp`` without a double-prefix (``/mcp/mcp`` regression avoided).
    - A host-provided lifespan that pulls ``neo4j`` / ``chroma`` from
      ``host_app.state`` — no resource duplication (§4.2).
    - Does NOT call ``_mount_versions_route`` — the host already serves
      ``/apps/mcp/server/versions`` (§5.5).
    - Tool dispatch wrapped in ``asyncio.Semaphore(SELPH_MCP_MOUNT_CONCURRENCY)``
      (§5.8) — ``ToolError`` with a ``Retry later`` message on overflow rather than
      an unbounded queue. FastMCP surfaces ``ToolError`` as
      ``CallToolResult(isError=True)`` carrying the retry hint in the message text;
      HTTP 503+Retry-After is not emitted because FastMCP does not propagate
      ``HTTPException`` cleanly through the streamable-HTTP transport.

    The caller (Pass B ``ingestion_api/main.py``) must:
    1. Call this function **once** at import time to get a single ``mcp_asgi``
       instance.
    2. Enter ``mcp_asgi.router.lifespan_context(mcp_asgi)`` inside the host
       lifespan (§5.3 session-manager nesting).  ``mcp_asgi.router`` is the
       Starlette router; ``.lifespan_context`` is available because
       ``streamable_http_app()`` returns a ``Starlette`` instance.
    3. Call ``app.mount("/mcp", bearer_auth_asgi_wrap(mcp_asgi))`` with the
       **same** instance (§5.3 — mounting a different instance leaves the
       session manager uninitialized).
    """
    from starlette.applications import Starlette as _Starlette
    from mcp.server.transport_security import TransportSecuritySettings as _TSS

    lifespan = _functools.partial(_host_provided_lifespan, host_app=host_app)

    # MCP SDK's FastMCP.Settings is a pydantic-settings BaseSettings with
    # nested_model_default_partial_update=True, so passing transport_security=None
    # does NOT leave it None — it auto-instantiates TransportSecuritySettings()
    # whose own default is enable_dns_rebinding_protection=True with an empty
    # allowed_hosts=[]. That rejects every Host header with 421 "Invalid Host header".
    # Pass explicit settings so the field is non-default and predictable.
    #
    # Default: protection OFF. The bearer_auth_asgi wrapper one layer above
    # already gates every request and DNS rebinding requires a browser-side
    # attacker; API consumers calling /mcp directly are not in that threat model.
    # If the operator wants to lock the Host allowlist (e.g. for a public-facing
    # browser-bound deployment), set SELPH_MCP_ALLOWED_HOSTS to a comma-separated
    # list of FQDNs and rebinding protection turns on automatically.
    _allowed_hosts_env = os.environ.get("SELPH_MCP_ALLOWED_HOSTS", "").strip()
    if _allowed_hosts_env:
        _allowed = [h.strip() for h in _allowed_hosts_env.split(",") if h.strip()]
        _security = _TSS(enable_dns_rebinding_protection=True, allowed_hosts=_allowed)
    else:
        _security = _TSS(enable_dns_rebinding_protection=False)

    server = FastMCP(
        "selph-mounted",
        instructions=(
            "Selph MCP surface — mounted on selph-api. "
            "Kernel tools: observe, query, project, revise. "
            "Persona tools: get_context, ask_selph, what_changed, "
            "find_evidence, get_entity_card, hire_for_role, "
            "observe_session, correct, recommendation_feedback, "
            "drift_signal, recommend_workflows, get_fingerprint."
        ),
        lifespan=lifespan,
        streamable_http_path="/",
        transport_security=_security,
    )
    _register_tools(server)
    _register_persona_tools(server)
    # §5.5: do NOT call _mount_versions_route — host owns the versions endpoint.

    # §5.8 — wrap every registered tool's dispatch function in the mount
    # semaphore so concurrent mounted-MCP calls are bounded at
    # SELPH_MCP_MOUNT_CONCURRENCY.  Overflow raises ``ToolError`` which
    # FastMCP surfaces as ``CallToolResult(isError=True)`` carrying the
    # ``retry_after=5`` / ``concurrency_cap`` hint in the message text.
    #
    # Admission control uses a ``Semaphore.locked()`` pre-check before
    # ``acquire()``.  In single-threaded asyncio this is atomic: when
    # ``not locked()`` the synchronous fast path of ``Semaphore.acquire()``
    # decrements ``_value`` with no suspension point, so no other
    # coroutine can slip in between the check and the acquire.
    # (``asyncio.wait_for(..., timeout=0)`` does NOT work here — it
    # always raises ``TimeoutError`` because ``ensure_future`` only
    # schedules the acquire task and ``fut.done()`` is therefore False
    # on the immediate timeout branch — see CPython asyncio/tasks.py.)
    #
    # We mutate Tool.fn in-place rather than re-registering closures so
    # that tool names, descriptions, and parameter schemas produced by
    # _register_tools / _register_persona_tools remain unchanged.
    # The stdio path (create_mcp_app → _register_tools / _register_persona_tools)
    # is NOT touched; only this mounted server's tool objects are mutated.
    _sem = _get_mount_semaphore()
    for _tool in server._tool_manager.list_tools():
        _original_fn = _tool.fn

        async def _semaphore_wrapped(*_args: Any, _fn: Any = _original_fn, **_kwargs: Any) -> Any:
            from mcp.server.fastmcp.exceptions import ToolError as _ToolError
            if _sem.locked():
                log_event(
                    _log, logging.WARNING, "mcp.tool.mount_semaphore.overflow",
                    concurrency_cap=_SELPH_MCP_MOUNT_CONCURRENCY,
                )
                raise _ToolError(
                    f"MCP server overloaded — retry after 5 seconds "
                    f"(concurrency_cap={_SELPH_MCP_MOUNT_CONCURRENCY}, retry_after=5)"
                )
            await _sem.acquire()
            try:
                return await _fn(*_args, **_kwargs)
            finally:
                _sem.release()

        _tool.fn = _semaphore_wrapped

    log_event(
        _log, logging.INFO, "mcp.server.mounted.created",
        server_name="selph-mounted",
        tool_count=16,
        concurrency_cap=_SELPH_MCP_MOUNT_CONCURRENCY,
    )

    # Finding 3 fix: return the Starlette ASGI sub-app, not the FastMCP object.
    # Pass B's mount and lifespan_context calls both require the same Starlette
    # instance — returning ``server`` (a FastMCP object) would leave
    # ``.router`` and ``.router.lifespan_context`` undefined.
    mcp_asgi: _Starlette = server.streamable_http_app()
    return mcp_asgi
