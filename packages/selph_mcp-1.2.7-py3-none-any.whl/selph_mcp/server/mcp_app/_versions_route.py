"""Mount the contract-version route and middleware onto the FastMCP app."""
from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import FastMCP

from ._helpers import _log, log_event


# ─────────────────────────────────────────────────────────────────────────────
# Contract-version route + middleware (§3.6)
# ─────────────────────────────────────────────────────────────────────────────


def _mount_versions_route(server: "FastMCP") -> None:
    """Mount GET /apps/mcp/server/versions and add contract-version middleware.

    FastMCP exposes the underlying Starlette/FastAPI app via
    ``server.router`` (a ``fastapi.APIRouter``). We include the versions
    router and install a lightweight middleware that stamps
    ``X-Selph-Server-Contract-Versions`` on every response.

    If ``server`` does not expose a wrappable router (e.g. an older SDK
    version), the mount is skipped with a WARNING rather than crashing.
    """
    from selph_mcp.server.versions_route import router as _versions_router
    from selph_mcp.auth.consumer_handshake import add_contract_versions_header

    # Include the versions router on the FastMCP instance's underlying
    # FastAPI / Starlette application object.  FastMCP stores this as
    # ``server._app`` (FastAPI instance) in the MCP Python SDK 1.x series.
    app = getattr(server, "_app", None)
    if app is None:
        log_event(
            _log, logging.WARNING, "mcp.server.versions_route.mount_skipped",
            reason="no_app_attribute",
        )
        return

    try:
        app.include_router(_versions_router)
    except Exception as exc:
        log_event(
            _log, logging.WARNING, "mcp.server.versions_route.include_failed",
            error_type=type(exc).__name__,
            error=str(exc)[:200],
        )
        return

    # Add a middleware that stamps X-Selph-Server-Contract-Versions on
    # every response.  Uses Starlette's BaseHTTPMiddleware pattern.
    try:
        from starlette.middleware.base import BaseHTTPMiddleware
        from starlette.requests import Request as StarletteRequest
        from starlette.responses import Response as StarletteResponse

        class _ContractVersionsMiddleware(BaseHTTPMiddleware):
            async def dispatch(
                self,
                request: StarletteRequest,
                call_next: Any,
            ) -> StarletteResponse:
                response = await call_next(request)
                add_contract_versions_header(response)
                return response

        app.add_middleware(_ContractVersionsMiddleware)
        log_event(_log, logging.INFO, "mcp.server.versions_route.mounted")
    except Exception as exc:
        log_event(
            _log, logging.WARNING, "mcp.server.versions_route.middleware_failed",
            error_type=type(exc).__name__,
            error=str(exc)[:200],
        )
