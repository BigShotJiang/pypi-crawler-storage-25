"""MCP transport entrypoints (Phase 1b §3, Q1: stdio AND HTTP).

Exports:

    create_mcp_app() -> FastMCP
        Build a FastMCP server, register all 15 tools (4 kernel +
        11 persona — Phase 2 set plus Phase 3
        ``recommendation_feedback`` / ``drift_signal`` plus Phase 5
        ``recommend_workflows``), and return it.
        Does NOT bind the server — the caller picks the transport.

    run_stdio() -> None
        Convenience runner: ``create_mcp_app().run("stdio")``. Used by
        Claude Code via ``python -m selph_mcp.server.mcp_app stdio``.

    run_http(port: int) -> None
        Convenience runner: ``create_mcp_app().run("streamable-http",
        port=port)``. Used for remote harnesses.

Per ``CLAUDE.md`` neither runner is invoked locally — they ship for
deployment wiring. Static checks (import smoke + ``py_compile``) only.

Auth handshake
--------------
Every tool call validates ``X-API-Key`` and ``X-Selph-Consumer`` via
:func:`selph_mcp.auth.require_consumer`. For stdio the headers come
from the MCP request metadata field (forwarded by the MCP client into
``ctx.request_context.request.meta`` per the SDK convention); for HTTP
they arrive on the underlying HTTP request and are bridged through the
same metadata accessor by the FastMCP runtime. The kernel tool calls
``_consumer_from_ctx`` to pull and validate them on every invocation.

Logging
-------
Each tool emits ``mcp.tool.<name>.entry`` and either
``mcp.tool.<name>.complete`` (with ``duration_ms``) or
``mcp.tool.<name>.error`` (with ``error_type``). ``consumer_id`` and
``user_id`` propagate to every log line per the mandatory logging
coverage in ``rules/naming-and-constraints.md``.

Sub-package structure
---------------------
Implementation lives in sibling modules:
  _helpers              — logger, header extraction, consumer auth,
                          credential forwarding, lifespan attr,
                          safe_envelope_dump
  _lifespan             — MCPLifespanContext, _default_lifespan,
                          _host_provided_lifespan, semaphore helpers
  _versions_route       — _mount_versions_route
  _kernel_tools         — _register_tools (4 kernel tools)
  _persona_read_tools   — get_context, ask_selph, what_changed,
                          find_evidence, get_entity_card, hire_for_role
  _persona_writeback_tools — observe_session, correct
  _persona_workflow_tools  — recommendation_feedback,
                             recommend_workflows, get_fingerprint,
                             drift_signal
  _persona_tools        — _register_persona_tools (orchestrates above)
  _factory              — create_mcp_app, run_stdio, run_http
  _mounted              — build_mounted_mcp
"""
from __future__ import annotations

from ._factory import create_mcp_app, run_http, run_stdio
from ._lifespan import MCPLifespanContext
from ._mounted import build_mounted_mcp

__all__ = ["create_mcp_app", "run_stdio", "run_http", "build_mounted_mcp"]
