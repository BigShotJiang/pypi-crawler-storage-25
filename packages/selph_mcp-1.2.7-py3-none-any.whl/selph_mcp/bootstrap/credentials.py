"""Credentials file persistence for the selph-mcp wheel (Slice 3C).

Stores the per-consumer Bearer token + identity returned by
``POST /apps/mcp/consumers`` so the wheel can boot without the user
pasting the token into ``~/.claude.json`` env blocks.

Path resolution
---------------
Writes to ``${XDG_CONFIG_HOME:-$HOME/.config}/selph-mcp/credentials.json``.
Macs and Linux honour XDG_CONFIG_HOME when set; otherwise both fall back
to ``~/.config/selph-mcp/credentials.json``. On Windows, ``$HOME`` is
the user profile and the file lands at
``%USERPROFILE%\\.config\\selph-mcp\\credentials.json`` — chmod has no
effect on Windows but is harmless.

File mode
---------
The file is created with mode ``0o600`` (owner read/write only). On
Linux/macOS this prevents other local users from reading the bearer
token. On Windows the chmod is a no-op (NTFS ACLs apply instead) — that
is documented but not separately hardened in this module.

Schema
------
The JSON file is a single object with these keys::

    {
        "version":       1,                   // bump on schema change
        "api_url":       "https://...",       // engine base URL
        "consumer_id":   "cns-1a2b3c4d",      // matches mcp_consumers row
        "user_id":       "U001",              // bound user_id
        "bearer_token":  "<plaintext>",       // 32-byte url-safe (43 char)
        "harness_id":    "claude-code",
        "issued_at":     "2026-04-23T18:23:00+00:00",
        "api_key":       "...",               // optional, kept iff supplied
        "self_entity_id":"ENT-U001-PER-00001" // cached from /apps/users/{id}
    }

Public API
----------
:func:`credentials_path`          — resolve the file path (no I/O).
:func:`load_credentials`          — read+parse, return dict or None.
:func:`save_credentials`          — write+chmod 0o600, atomic.
:func:`apply_to_environment`      — populate SELPH_* env vars iff missing.

Read by both the bootstrap CLI and ``selph_mcp._client`` (env-var
fallback path) — keep this module dependency-light (stdlib only) so it
loads even when the wheel runs in a minimal pipx venv.
"""
from __future__ import annotations

import json
import logging
import os
import stat
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional

from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.bootstrap.credentials")

CREDENTIALS_SCHEMA_VERSION = 1
_FILENAME = "credentials.json"
_DIRNAME = "selph-mcp"


def credentials_path() -> Path:
    """Return the absolute path to the credentials file (no I/O).

    Honours ``XDG_CONFIG_HOME``; falls back to ``$HOME/.config``.
    Does NOT create parent directories — :func:`save_credentials`
    handles that.
    """
    xdg = os.environ.get("XDG_CONFIG_HOME", "").strip()
    if xdg:
        base = Path(xdg)
    else:
        base = Path(os.path.expanduser("~")) / ".config"
    return base / _DIRNAME / _FILENAME


def load_credentials() -> Optional[Dict[str, Any]]:
    """Read and JSON-parse the credentials file.

    Returns:
        Parsed dict on success, ``None`` if the file is missing.

    Raises:
        json.JSONDecodeError: when the file exists but is not valid JSON.
        OSError: on read errors other than ENOENT.
    """
    path = credentials_path()
    if not path.exists():
        log_event(
            _log, logging.DEBUG, "selph_mcp.creds.miss",
            path=str(path),
        )
        return None
    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        log_event(
            _log, logging.ERROR, "selph_mcp.creds.load_failed",
            path=str(path),
            error_type=type(exc).__name__,
            error=str(exc)[:200],
        )
        raise

    if not isinstance(data, dict):
        log_event(
            _log, logging.ERROR, "selph_mcp.creds.malformed",
            path=str(path),
            payload_type=type(data).__name__,
        )
        raise ValueError(
            f"credentials file at {path} is not a JSON object"
        )

    log_event(
        _log, logging.DEBUG, "selph_mcp.creds.loaded",
        path=str(path),
        consumer_id=data.get("consumer_id"),
        user_id=data.get("user_id"),
        version=data.get("version"),
    )
    return data


def _refuse_symlinks_under(path: Path) -> None:
    """Raise PermissionError if any segment between ``$HOME`` (or XDG root)
    and ``path`` (exclusive) is a symbolic link.

    Confused-deputy guard — without this, a hostile process can
    pre-create ``~/.config/selph-mcp`` as a symlink to attacker-writable
    storage and capture the bearer token on save. ``Path.mkdir(parents=
    True)`` and ``os.chmod`` both follow symlinks, so without an explicit
    refusal the chmod 0o700 / 0o600 protections do not apply to the
    symlink target.

    On non-POSIX filesystems where ``Path.lstat`` raises, we silently
    fall through (the protection is best-effort).
    """
    try:
        target_root = Path(os.environ.get("XDG_CONFIG_HOME") or
                           Path(os.path.expanduser("~")) / ".config").resolve()
    except OSError:
        target_root = Path(os.path.expanduser("~")).resolve()

    probe = path
    while True:
        try:
            lst = probe.lstat()
        except FileNotFoundError:
            # Doesn't exist yet — safe; it will be created with our mode.
            pass
        except OSError:
            # Filesystem doesn't support lstat (rare); skip the check.
            return
        else:
            import stat as _stat
            if _stat.S_ISLNK(lst.st_mode):
                raise PermissionError(
                    f"refusing to save credentials under a symlink at {probe}; "
                    "remove the symlink and re-run."
                )
        if probe == target_root or probe.parent == probe:
            return
        probe = probe.parent


def save_credentials(payload: Dict[str, Any]) -> Path:
    """Atomically write ``payload`` as JSON, chmod 0o600.

    Writes to a sibling tempfile then ``os.replace``s into place so a
    crash mid-write cannot leave a half-written file. Sets the
    schema version automatically; never logs the bearer_token field.

    Refuses to write through any symlink between ``$HOME``/``$XDG_CONFIG_HOME``
    and the credentials file (see :func:`_refuse_symlinks_under`).

    Output is COMPACT (no indentation) so the bearer_token is not on a
    line by itself — reduces accidental screen-share / paste exposure.

    Args:
        payload: Must include ``consumer_id``, ``user_id``,
            ``bearer_token``, ``api_url``. Extra keys are preserved.

    Returns:
        The path the file was written to.
    """
    required = {"consumer_id", "user_id", "bearer_token", "api_url"}
    missing = required - set(payload.keys())
    if missing:
        raise ValueError(
            f"save_credentials: missing required keys {sorted(missing)}"
        )

    body = dict(payload)
    body.setdefault("version", CREDENTIALS_SCHEMA_VERSION)

    path = credentials_path()

    # Refuse symlinked ancestor segments BEFORE mkdir — mkdir would
    # silently follow them. Only checks segments that already exist.
    _refuse_symlinks_under(path)

    path.parent.mkdir(parents=True, exist_ok=True)
    # Tighten parent dir to 0o700 — same owner-only constraint as the file.
    try:
        os.chmod(path.parent, stat.S_IRWXU)
    except OSError:
        # Windows / unsupported filesystem — the file chmod below still applies.
        pass

    fd, tmp_path = tempfile.mkstemp(
        prefix=".credentials-",
        suffix=".tmp",
        dir=str(path.parent),
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            # Compact serialisation (no indent, no spaces). Single-line
            # output means the bearer_token never sits on its own line —
            # smaller screen-share / paste-by-accident exposure surface.
            json.dump(body, f, sort_keys=True, separators=(",", ":"))
            f.write("\n")
        # chmod BEFORE replace so the public path never exists with looser
        # mode. (mkstemp creates 0o600 on POSIX already; explicit for clarity.)
        try:
            os.chmod(tmp_path, stat.S_IRUSR | stat.S_IWUSR)
        except OSError:
            pass
        os.replace(tmp_path, path)
    except Exception:
        # Best-effort cleanup of the tempfile if anything went wrong.
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise

    log_event(
        _log, logging.INFO, "selph_mcp.creds.saved",
        path=str(path),
        consumer_id=body.get("consumer_id"),
        user_id=body.get("user_id"),
        api_url=body.get("api_url"),
    )
    return path


def apply_to_environment(payload: Optional[Dict[str, Any]] = None) -> None:
    """Populate ``SELPH_*`` env vars from credentials, only when unset.

    Used by :mod:`selph_mcp._client` so the wheel boots even when the
    MCP server entry in ``~/.claude.json`` does not pass an ``env``
    block. Never overwrites an existing env var (env wins so operators
    can override credentials at process launch).

    Args:
        payload: Pre-loaded credentials dict; loads from disk when
            ``None``. Silently no-ops if no credentials exist.
    """
    if payload is None:
        try:
            payload = load_credentials()
        except Exception:  # noqa: BLE001 — log+swallow; env may be sufficient
            log_event(
                _log, logging.WARNING, "selph_mcp.creds.apply.load_failed",
            )
            return
    if not payload:
        return

    mapping = {
        "SELPH_API_URL": payload.get("api_url"),
        "SELPH_CONSUMER_ID": payload.get("consumer_id"),
        "SELPH_BEARER_TOKEN": payload.get("bearer_token"),
        "SELPH_USER_ID": payload.get("user_id"),
        "SELPH_API_KEY": payload.get("api_key"),
    }
    for env_name, value in mapping.items():
        if value and not os.environ.get(env_name):
            os.environ[env_name] = str(value)


__all__ = [
    "CREDENTIALS_SCHEMA_VERSION",
    "credentials_path",
    "load_credentials",
    "save_credentials",
    "apply_to_environment",
]
