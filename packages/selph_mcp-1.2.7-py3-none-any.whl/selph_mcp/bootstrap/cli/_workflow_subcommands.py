"""Workflow subcommand handlers for selph-mcp-bootstrap (Phase C).

Subcommands:
- install-workflow
- migrate-workflow
- scan-workflows
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any

from selph_mcp._log import get_logger, log_event
from ._envelope import err_envelope, ok_envelope

_log = get_logger("selph_mcp.bootstrap.cli")


def _load_manifest_arg(raw: str) -> Any:
    """Load JSON from ``@path.json``, ``-`` (stdin), or inline JSON string."""
    if raw.startswith("@"):
        return json.loads(Path(raw[1:]).read_text(encoding="utf-8"))
    if raw == "-":
        return json.loads(sys.stdin.read())
    return json.loads(raw)


# ---------------------------------------------------------------------------
# install-workflow
# ---------------------------------------------------------------------------

def _cmd_install_workflow(args: argparse.Namespace) -> int:
    """install-workflow --workspace PATH --workflow-id ID [--manifest @file.json]"""
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    workflow_id = args.workflow_id
    manifest_raw = getattr(args, "manifest", None)
    log_event(_log, logging.INFO, "cli.install_workflow.entry",
              workspace=str(workspace), workflow_id=workflow_id)
    try:
        from selph_mcp.skill.bootstrap import install_workflow, resolve_workspace_root
        from selph_mcp.contracts.workflow_manifest import WorkflowManifest
        ws = resolve_workspace_root(str(workspace))
        manifest = None
        if manifest_raw:
            manifest_data = _load_manifest_arg(manifest_raw)
            manifest = WorkflowManifest.model_validate(manifest_data)
        installed = install_workflow(ws, workflow_id, manifest=manifest)
        ok_envelope({
            "workflow_id": installed.workflow_id,
            "version": installed.version,
            "skill_path": installed.skill_path,
        })
        log_event(_log, logging.INFO, "cli.install_workflow.complete",
                  workflow_id=workflow_id)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.install_workflow.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# migrate-workflow
# ---------------------------------------------------------------------------

def _cmd_migrate_workflow(args: argparse.Namespace) -> int:
    """migrate-workflow --workspace PATH --workflow-id ID --current-template-version N"""
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    workflow_id = args.workflow_id
    current_version = int(args.current_template_version)
    log_event(_log, logging.INFO, "cli.migrate_workflow.entry",
              workspace=str(workspace), workflow_id=workflow_id,
              current_template_version=current_version)
    try:
        from selph_mcp.skill.bootstrap import migrate_workflow_skill, resolve_workspace_root
        ws = resolve_workspace_root(str(workspace))
        outcome = migrate_workflow_skill(
            ws, workflow_id, current_template_version=current_version
        )
        ok_envelope({"outcome": outcome.value if hasattr(outcome, "value") else str(outcome)})
        log_event(_log, logging.INFO, "cli.migrate_workflow.complete",
                  workflow_id=workflow_id, outcome=str(outcome))
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.migrate_workflow.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# scan-workflows
# ---------------------------------------------------------------------------

def _cmd_scan_workflows(args: argparse.Namespace) -> int:
    """scan-workflows --workspace PATH"""
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    log_event(_log, logging.INFO, "cli.scan_workflows.entry",
              workspace=str(workspace))
    try:
        from selph_mcp.skill.bootstrap import detect_state, resolve_workspace_root
        from selph_mcp.skill.workflow_scan import scan_workspace_workflows
        ws = resolve_workspace_root(str(workspace))
        state = detect_state(ws)
        # scan_workspace_workflows expects OnboardingState (from Returning path)
        onboarding_state = getattr(state, "state", None)
        if onboarding_state is None:
            ok_envelope({"proposals": [], "candidates": [], "note": "cold_start"})
            return 0
        report = scan_workspace_workflows(ws, onboarding_state)
        ok_envelope(json.loads(report.model_dump_json()))
        log_event(_log, logging.INFO, "cli.scan_workflows.complete",
                  proposal_count=len(report.proposals))
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.scan_workflows.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)
