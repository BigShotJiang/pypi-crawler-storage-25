"""Install/MCP-config subcommand handlers for selph-mcp-bootstrap (Phase C/D/E).

Subcommands:
- write-mcp-entry   (Phase D — writes selph-remote HTTP entry)
- install-slash-command  (Phase E option 1)
- refresh-slash-command
- whoami-remote
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path
from urllib.parse import urlparse

from selph_mcp._log import get_logger, log_event
from ._defaults import resolve_api_url
from ._envelope import err_envelope, ok_envelope

_log = get_logger("selph_mcp.bootstrap.cli")


# ---------------------------------------------------------------------------
# URL validation helper
# ---------------------------------------------------------------------------

def _require_https_url(api_url: str) -> tuple[bool, str]:
    """Return (True, "") if api_url is safe to fetch; (False, reason) otherwise.

    Allows https:// everywhere and http:// on loopback only (dev convenience).
    """
    parsed = urlparse(api_url)
    if parsed.scheme == "https":
        if not parsed.netloc:
            return False, "api_url must include a host"
        return True, ""
    if parsed.scheme == "http":
        if parsed.hostname in {"localhost", "127.0.0.1", "0.0.0.0"}:
            return True, ""
        return False, (
            f"api_url must use https:// scheme for non-loopback hosts; got {parsed.scheme!r}"
        )
    return False, f"api_url must use https:// scheme; got {parsed.scheme!r}"


# ---------------------------------------------------------------------------
# write-mcp-entry (Phase D)
# ---------------------------------------------------------------------------

def _cmd_write_mcp_entry(args: argparse.Namespace) -> int:
    """write-mcp-entry --remote-url URL

    Reads bearer_token and consumer_id from the global credentials file
    (written by ``selph-mcp-bootstrap register``) and writes a
    ``type: "http"`` ``selph-remote`` entry into ``~/.claude.json``.

    If a legacy ``type: "stdio"`` ``selph`` entry exists, it is silently
    removed and a migration audit record is written.
    """
    # When --remote-url is omitted, fall back to the credentials file's
    # api_url (set during register), then to the hardcoded default.
    remote_url = (getattr(args, "remote_url", None) or "").rstrip("/")
    if not remote_url:
        try:
            from selph_mcp.skill.bootstrap import hydrate_from_global_credentials
            cached = hydrate_from_global_credentials()
            if cached and cached.get("api_url"):
                remote_url = cached["api_url"].rstrip("/")
        except Exception:  # noqa: BLE001 — fall through to hardcoded default
            pass
    if not remote_url:
        remote_url = resolve_api_url(None)
    workspace = getattr(args, "workspace", None)
    log_event(_log, logging.INFO, "cli.write_mcp_entry.entry", remote_url=remote_url)
    try:
        from selph_mcp.skill.bootstrap import (
            hydrate_from_global_credentials,
            write_mcp_entry_remote,
        )
        creds = hydrate_from_global_credentials()
        if creds is None:
            return err_envelope(
                error_type="CredentialsNotFound",
                message=(
                    "No global credentials file found. "
                    "Run `selph-mcp-bootstrap register --user-id <id> --api-key <key>` first."
                ),
            )
        changed = write_mcp_entry_remote(
            api_url=remote_url,
            bearer_token=creds["bearer_token"],
            consumer_id=creds["consumer_id"],
            workspace=Path(workspace) if workspace else None,
        )
        ok_envelope({"changed": changed, "server_name": "selph-remote", "url": remote_url + "/mcp"})
        log_event(_log, logging.INFO, "cli.write_mcp_entry.complete", changed=changed)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.write_mcp_entry.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# install-slash-command (Phase E option 1)
# ---------------------------------------------------------------------------

def _cmd_install_slash_command(args: argparse.Namespace) -> int:
    """install-slash-command --api-url URL

    Fetches the latest SKILL.md controller from
    ``<api_url>/apps/install/using-selph`` and writes it to
    ``~/.claude/commands/using-selph.md``.  This is the out-of-band
    first-install path for users who only have the wheel (no repo clone).
    """
    import httpx

    api_url = resolve_api_url(getattr(args, "api_url", None))
    log_event(_log, logging.INFO, "cli.install_slash_command.entry", api_url=api_url)
    ok, reason = _require_https_url(api_url)
    if not ok:
        return err_envelope(error_type="InsecureURL", message=reason)
    try:
        dest = Path.home() / ".claude" / "commands" / "using-selph.md"
        dest.parent.mkdir(parents=True, exist_ok=True)
        with httpx.Client(timeout=30.0) as client:
            resp = client.get(f"{api_url}/apps/install/using-selph")
        if resp.status_code != 200:
            return err_envelope(
                error_type="HTTPError",
                message=f"GET /apps/install/using-selph returned {resp.status_code}: {resp.text[:200]}",
            )
        if not resp.text.strip():
            return err_envelope(
                error_type="EmptyResponse",
                message="GET /apps/install/using-selph returned an empty body",
            )
        dest.write_text(resp.text, encoding="utf-8")
        ok_envelope({"path": str(dest), "api_url": api_url, "bytes": len(resp.text)})
        log_event(_log, logging.INFO, "cli.install_slash_command.complete",
                  path=str(dest), bytes=len(resp.text))
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.install_slash_command.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# install-skill-tree
# ---------------------------------------------------------------------------


def _cmd_install_skill_tree(args: argparse.Namespace) -> int:
    """install-skill-tree [--api-url URL] [--force]

    Idempotently restores the modular sub-tree under
    ``~/.claude/commands/using-selph/{flows,reference}/``. Missing files are
    written from the wheel-bundled fallback (or from the server when
    ``--api-url`` is provided). Existing files are preserved unless
    ``--force`` is passed.
    """
    api_url_arg = getattr(args, "api_url", None)
    force = bool(getattr(args, "force", False))
    api_url: str | None = None
    if api_url_arg:
        api_url = resolve_api_url(api_url_arg)
        ok, reason = _require_https_url(api_url)
        if not ok:
            return err_envelope(error_type="InsecureURL", message=reason)
    log_event(
        _log,
        logging.INFO,
        "cli.install_skill_tree.entry",
        api_url=api_url or "",
        force=force,
    )
    try:
        from selph_mcp.skill.bootstrap import install_skill_tree
        summary = install_skill_tree(api_url=api_url, force=force)
        ok_envelope(summary)
        log_event(
            _log,
            logging.INFO,
            "cli.install_skill_tree.complete",
            repaired_count=len(summary.get("repaired", [])),
            refreshed_count=len(summary.get("refreshed", [])),
            preserved_count=len(summary.get("preserved", [])),
            failed_count=len(summary.get("failed", [])),
        )
        return 0
    except ValueError as exc:
        return err_envelope(error_type="InsecureURL", message=str(exc))
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log,
            logging.ERROR,
            "cli.install_skill_tree.error",
            error_type=type(exc).__name__,
            error=str(exc)[:200],
        )
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# refresh-slash-command
# ---------------------------------------------------------------------------

def _cmd_refresh_slash_command(args: argparse.Namespace) -> int:
    """refresh-slash-command [--api-url URL]"""
    api_url = resolve_api_url(getattr(args, "api_url", None))
    log_event(_log, logging.INFO, "cli.refresh_slash_command.entry", api_url=api_url)
    ok, reason = _require_https_url(api_url)
    if not ok:
        return err_envelope(error_type="InsecureURL", message=reason)
    try:
        from selph_mcp.skill.bootstrap import refresh_slash_command
        result = refresh_slash_command(api_url)
        ok_envelope({"refreshed": result is not None, "path": str(result) if result else None})
        log_event(_log, logging.INFO, "cli.refresh_slash_command.complete",
                  refreshed=result is not None)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.refresh_slash_command.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# whoami-remote
# ---------------------------------------------------------------------------

def _cmd_whoami_remote(args: argparse.Namespace) -> int:
    """whoami-remote --api-url URL [--bearer-token TOKEN] [--consumer-id ID]

    Reads bearer_token and consumer_id from the global credentials file by
    default (same as write-mcp-entry).  --bearer-token and --consumer-id are
    optional overrides; if provided on the command line they take precedence.
    """
    api_url = resolve_api_url(getattr(args, "api_url", None))
    ok, msg = _require_https_url(api_url)
    if not ok:
        return err_envelope(error_type="InvalidApiUrl", message=msg)
    bearer_token: str | None = getattr(args, "bearer_token", None)
    consumer_id: str | None = getattr(args, "consumer_id", None)

    # Hydrate from file when argv did not supply the creds.
    if bearer_token is None or consumer_id is None:
        try:
            from selph_mcp.skill.bootstrap import hydrate_from_global_credentials
            creds = hydrate_from_global_credentials()
        except Exception as exc:  # noqa: BLE001
            creds = None
            log_event(_log, logging.WARNING, "cli.whoami_remote.creds_load_failed",
                      error_type=type(exc).__name__, error=str(exc)[:200])
        if creds is None:
            return err_envelope(
                error_type="CredentialsNotFound",
                message=(
                    "No credentials provided and no global credentials file found. "
                    "Run `selph-mcp-bootstrap register` first, or pass "
                    "--bearer-token and --consumer-id explicitly."
                ),
            )
        if bearer_token is None:
            bearer_token = creds["bearer_token"]
        if consumer_id is None:
            consumer_id = creds["consumer_id"]

    log_event(_log, logging.INFO, "cli.whoami_remote.entry",
              api_url=api_url, consumer_id=consumer_id)
    try:
        from selph_mcp.skill.bootstrap import fetch_whoami
        import json
        whoami = fetch_whoami(api_url, bearer_token, consumer_id)
        if whoami is None:
            return err_envelope(
                error_type="AuthError",
                message="fetch_whoami returned None — auth failed or network error.",
            )
        ok_envelope(json.loads(whoami.model_dump_json()))
        log_event(_log, logging.INFO, "cli.whoami_remote.complete",
                  consumer_id=whoami.consumer_id)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.whoami_remote.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)
