"""``selph-mcp-bootstrap`` console script (Slice 3C).

Subcommands
-----------
- ``register`` — POST /apps/mcp/consumers, save the returned bearer_token
  to ``${XDG_CONFIG_HOME:-$HOME/.config}/selph-mcp/credentials.json``.
- ``whoami``   — print the locally-stored consumer identity (no network).
- ``doctor``   — verify the credentials file parses, the engine is
  reachable, and the persona contract version matches.

The plaintext bearer token is shown to the user **once** at registration
time and immediately written to the chmod-0600 credentials file. The
token is never echoed again by ``whoami`` (only its presence is
reported). It is never logged.

Exit codes
----------
- 0 — success
- 1 — operational error (network, file I/O, contract mismatch)
- 2 — user error (missing args, invalid input)
"""
from __future__ import annotations

import argparse
import getpass
import json
import logging
import os
import sys
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

# Stdlib + httpx only — keep the bootstrap CLI dep-light. We do NOT
# import the EngineClient here because EngineClient is async and
# pre-creates an httpx.AsyncClient with HTTP/2; we want a simple sync
# httpx call so the CLI runs without an event loop.
import httpx

from selph_mcp._log import configure_logging, get_logger, log_event
from selph_mcp.bootstrap import credentials as _creds

_log = get_logger("selph_mcp.bootstrap.cli")

from ._defaults import DEFAULT_API_URL as _DEFAULT_API_URL  # backwards-compat re-export
_DEFAULT_HARNESS_ID = "claude-code"
_DEFAULT_DISPLAY_NAME = "Claude Code (selph-mcp wheel)"
_DEFAULT_SCOPES = ["communication", "professional", "personal", "behavioral", "domain"]
_DEFAULT_SENSITIVITY_CEILING = "normal"
_DEFAULT_BUDGET_TIER = "standard"


def _resolve_api_url(arg_url: Optional[str]) -> str:
    """Argument > env > default."""
    return (
        arg_url
        or os.environ.get("SELPH_API_URL", "").strip()
        or _DEFAULT_API_URL
    ).rstrip("/")


def _resolve_api_key(arg_key: Optional[str]) -> Optional[str]:
    """Argument > env. Returns None if neither set; the caller decides
    whether to error out (register requires it; doctor does not)."""
    if arg_key:
        return arg_key
    env_key = os.environ.get("SELPH_API_KEY", "").strip()
    return env_key or None


# ────────────────────────────────────────────────────────────────────────────
# register
# ────────────────────────────────────────────────────────────────────────────


def _cmd_register(args: argparse.Namespace) -> int:
    """``selph-mcp-bootstrap register --user-id U001 [...]``.

    POSTs ``/apps/mcp/consumers`` with the supplied identity, captures
    the one-time ``bearer_token`` from the response, fetches the
    user's ``self_entity_id`` (best-effort), and writes everything to
    the credentials file with mode 0o600.
    """
    api_url = _resolve_api_url(args.api_url)
    api_key = _resolve_api_key(args.api_key)

    user_id = (args.user_id or os.environ.get("SELPH_USER_ID", "")).strip()

    # Interactive Q&A path: if user_id or api_key wasn't supplied, ask.
    # Only prompts when stdin is a TTY so non-interactive callers
    # (SKILL.md, CI scripts) still fail fast on missing required values.
    if (not user_id or not api_key) and sys.stdin.isatty():
        if not user_id:
            print("Selph user ID (e.g. U001):", end=" ", flush=True)
            user_id = sys.stdin.readline().strip()
        if not api_key:
            api_key = getpass.getpass("Selph API key (won't be displayed): ").strip()

    if not api_key:
        print(
            "ERROR: api key not provided. Pass --api-key, set SELPH_API_KEY, "
            "or run interactively.",
            file=sys.stderr,
        )
        return 2
    if not user_id:
        print(
            "ERROR: user_id not provided. Pass --user-id, set SELPH_USER_ID, "
            "or run interactively.",
            file=sys.stderr,
        )
        return 2

    args.user_id = user_id  # downstream code reads from args

    scopes = (
        [s.strip() for s in args.scopes.split(",") if s.strip()]
        if args.scopes
        else list(_DEFAULT_SCOPES)
    )

    body: Dict[str, Any] = {
        "user_id": args.user_id,
        "harness_id": args.harness_id or _DEFAULT_HARNESS_ID,
        "display_name": args.display_name or _DEFAULT_DISPLAY_NAME,
        "allowed_scopes": scopes,
        "sensitivity_ceiling": args.sensitivity_ceiling or _DEFAULT_SENSITIVITY_CEILING,
        "budget_tier": args.budget_tier or _DEFAULT_BUDGET_TIER,
        "issue_bearer_token": True,
    }

    log_event(
        _log, logging.INFO, "selph_mcp.bootstrap.register.start",
        api_url=api_url,
        user_id=args.user_id,
        harness_id=body["harness_id"],
        display_name=body["display_name"],
        scope_count=len(scopes),
    )

    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(
                f"{api_url}/apps/mcp/consumers",
                json=body,
                headers={
                    "X-API-Key": api_key,
                    "Content-Type": "application/json",
                },
            )
    except httpx.RequestError as exc:
        log_event(
            _log, logging.ERROR, "selph_mcp.bootstrap.register.unreachable",
            api_url=api_url,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        print(f"ERROR: engine unreachable at {api_url}: {exc}", file=sys.stderr)
        return 1

    if resp.status_code != 200:
        log_event(
            _log, logging.ERROR, "selph_mcp.bootstrap.register.bad_status",
            api_url=api_url,
            status_code=resp.status_code,
            body_preview=resp.text[:300],
        )
        print(
            f"ERROR: POST /apps/mcp/consumers returned {resp.status_code}: "
            f"{resp.text[:300]}",
            file=sys.stderr,
        )
        return 1

    try:
        data = resp.json()
    except json.JSONDecodeError as exc:
        log_event(
            _log, logging.ERROR, "selph_mcp.bootstrap.register.malformed_response",
            error=str(exc)[:200],
        )
        print(f"ERROR: response was not valid JSON: {exc}", file=sys.stderr)
        return 1

    consumer_id = data.get("consumer_id")
    user_id = data.get("user_id")
    bearer_token = data.get("bearer_token")
    harness_id = data.get("harness_id") or body["harness_id"]
    if not (consumer_id and user_id and bearer_token):
        log_event(
            _log, logging.ERROR, "selph_mcp.bootstrap.register.incomplete_response",
            consumer_id=consumer_id,
            has_user_id=bool(user_id),
            has_bearer_token=bool(bearer_token),
        )
        print(
            "ERROR: response missing required fields "
            "(consumer_id / user_id / bearer_token).",
            file=sys.stderr,
        )
        return 1

    # Best-effort: cache self_entity_id so persona tools can resolve
    # the SELF without an extra round-trip on first call. Failure here
    # is non-fatal — the file gets written either way.
    self_entity_id: Optional[str] = None
    try:
        with httpx.Client(timeout=15.0) as client:
            ue_resp = client.get(
                f"{api_url}/apps/users/{user_id}",
                headers={
                    "Authorization": f"Bearer {bearer_token}",
                    "X-Consumer-Id": consumer_id,
                },
            )
        if ue_resp.status_code == 200:
            ue_data = ue_resp.json()
            self_entity_id = ue_data.get("self_entity_id")
    except (httpx.RequestError, json.JSONDecodeError) as exc:
        log_event(
            _log, logging.WARNING, "selph_mcp.bootstrap.register.user_lookup_failed",
            error_type=type(exc).__name__,
            error=str(exc)[:200],
        )

    payload = {
        "version": _creds.CREDENTIALS_SCHEMA_VERSION,
        "api_url": api_url,
        "consumer_id": consumer_id,
        "user_id": user_id,
        "harness_id": harness_id,
        "bearer_token": bearer_token,
        "issued_at": datetime.now(timezone.utc).isoformat(),
        "self_entity_id": self_entity_id,
        "display_name": data.get("display_name"),
        "allowed_scopes": data.get("allowed_scopes", scopes),
        "sensitivity_ceiling": data.get("sensitivity_ceiling"),
        "budget_tier": data.get("budget_tier"),
    }
    if api_key and args.persist_api_key:
        payload["api_key"] = api_key

    try:
        path = _creds.save_credentials(payload)
    except Exception as exc:  # noqa: BLE001 — surface as 1
        log_event(
            _log, logging.ERROR, "selph_mcp.bootstrap.register.save_failed",
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        print(f"ERROR: failed to write credentials file: {exc}", file=sys.stderr)
        return 1

    log_event(
        _log, logging.INFO, "selph_mcp.bootstrap.register.complete",
        consumer_id=consumer_id,
        user_id=user_id,
        api_url=api_url,
        path=str(path),
        self_entity_id=self_entity_id,
    )
    print(f"Registered consumer_id={consumer_id} user_id={user_id}")
    print(f"Credentials saved to {path}")
    print("The bearer_token has been written to that file (chmod 0600).")
    print(
        "If you need to inject it into a shell, the only canonical "
        "place it now lives is that file."
    )

    # Pass B: when --transport http was requested, point users at write-mcp-entry
    # instead of echoing the bearer token in a copy-pasteable shell snippet.
    transport = getattr(args, "transport", "stdio")
    if transport == "http":
        print()
        print(
            "Server credentials saved. To wire up Claude Code's remote MCP entry, run:\n"
            "  selph-mcp-bootstrap write-mcp-entry --remote-url <api_url>\n"
            "(reads the token from the chmod-0600 credentials file; never echoes it)"
        )

    return 0


# ────────────────────────────────────────────────────────────────────────────
# whoami
# ────────────────────────────────────────────────────────────────────────────


def _cmd_whoami(_args: argparse.Namespace) -> int:
    """Print the locally-stored consumer identity. Never echoes the token."""
    try:
        creds = _creds.load_credentials()
    except Exception as exc:  # noqa: BLE001
        print(f"ERROR: failed to read credentials: {exc}", file=sys.stderr)
        return 1
    if creds is None:
        print(
            "No credentials found at "
            f"{_creds.credentials_path()}. Run "
            "`selph-mcp-bootstrap register` to create them.",
            file=sys.stderr,
        )
        return 1

    print(f"path:           {_creds.credentials_path()}")
    print(f"api_url:        {creds.get('api_url')}")
    print(f"consumer_id:    {creds.get('consumer_id')}")
    print(f"user_id:        {creds.get('user_id')}")
    print(f"harness_id:     {creds.get('harness_id')}")
    print(f"display_name:   {creds.get('display_name')}")
    print(f"self_entity_id: {creds.get('self_entity_id')}")
    print(f"issued_at:      {creds.get('issued_at')}")
    has_token = bool(creds.get("bearer_token"))
    print(f"bearer_token:   {'<present>' if has_token else '<missing>'}")
    return 0


# ────────────────────────────────────────────────────────────────────────────
# doctor
# ────────────────────────────────────────────────────────────────────────────


def _cmd_doctor(args: argparse.Namespace) -> int:
    """Verify creds parse + engine reachable + contract version matches."""
    failures: List[str] = []

    try:
        creds = _creds.load_credentials()
    except Exception as exc:  # noqa: BLE001
        print(f"FAIL credentials file read failed: {exc}", file=sys.stderr)
        return 1
    if creds is None:
        print(
            f"FAIL no credentials file at {_creds.credentials_path()}. "
            "Run `selph-mcp-bootstrap register` first.",
            file=sys.stderr,
        )
        return 1
    print(f"OK   credentials file found at {_creds.credentials_path()}")

    api_url = _resolve_api_url(args.api_url) or creds.get("api_url") or ""
    consumer_id = creds.get("consumer_id")
    bearer_token = creds.get("bearer_token")
    if not (api_url and consumer_id and bearer_token):
        msg = (
            "credentials are missing one of: api_url / consumer_id / bearer_token"
        )
        failures.append(msg)
        print(f"FAIL {msg}")

    # Lazy import of the local PERSONA_CONTRACT_VERSION constant so we
    # don't pull in pydantic etc. unnecessarily on the happy path.
    try:
        from selph_mcp.contracts.versions import PERSONA_CONTRACT_VERSION
    except Exception as exc:  # noqa: BLE001
        msg = f"could not import PERSONA_CONTRACT_VERSION: {exc}"
        failures.append(msg)
        print(f"FAIL {msg}")
        return 1

    try:
        with httpx.Client(timeout=15.0) as client:
            resp = client.get(f"{api_url}/apps/mcp/server/versions")
    except httpx.RequestError as exc:
        msg = f"engine unreachable at {api_url}: {exc}"
        failures.append(msg)
        print(f"FAIL {msg}")
        return 1
    if resp.status_code != 200:
        msg = (
            f"GET /apps/mcp/server/versions returned {resp.status_code}: "
            f"{resp.text[:200]}"
        )
        failures.append(msg)
        print(f"FAIL {msg}")
        return 1
    try:
        ver_data = resp.json()
    except json.JSONDecodeError as exc:
        msg = f"versions response was not valid JSON: {exc}"
        failures.append(msg)
        print(f"FAIL {msg}")
        return 1
    remote = ver_data.get("persona_contract_version")
    if remote is None:
        msg = "engine response missing persona_contract_version field"
        failures.append(msg)
        print(f"FAIL {msg}")
        return 1
    if int(remote) != int(PERSONA_CONTRACT_VERSION):
        msg = (
            f"contract version mismatch — local={PERSONA_CONTRACT_VERSION} "
            f"remote={remote}. Upgrade the wheel or the engine."
        )
        failures.append(msg)
        print(f"FAIL {msg}")
        return 1
    print(
        f"OK   engine reachable, contract version match "
        f"(persona_contract_version={remote})"
    )

    # Auth probe: GET /apps/users/{user_id} with the stored bearer.
    user_id = creds.get("user_id")
    try:
        with httpx.Client(timeout=15.0) as client:
            ue_resp = client.get(
                f"{api_url}/apps/users/{user_id}",
                headers={
                    "Authorization": f"Bearer {bearer_token}",
                    "X-Consumer-Id": consumer_id,
                },
            )
    except httpx.RequestError as exc:
        msg = f"auth probe unreachable: {exc}"
        failures.append(msg)
        print(f"FAIL {msg}")
        return 1
    if ue_resp.status_code != 200:
        msg = (
            f"auth probe (GET /apps/users/{user_id}) returned "
            f"{ue_resp.status_code}: {ue_resp.text[:200]}"
        )
        failures.append(msg)
        print(f"FAIL {msg}")
        return 1
    print("OK   bearer token authenticates against /apps/users/{user_id}")

    if failures:
        print(f"\n{len(failures)} check(s) failed.", file=sys.stderr)
        return 1
    print("\nAll checks passed.")
    return 0

