"""Wheel-side default endpoint for the Selph remote MCP.

Hardcoded so the CLI feels like a normal consumer tool (no URL to type
on every command). Override hierarchy:

    explicit --api-url / --remote-url  >  SELPH_API_URL env var  >  DEFAULT_API_URL

If the production endpoint moves, bump the wheel version and republish;
older wheels keep working as long as the old URL still resolves.
"""

from __future__ import annotations

import os

DEFAULT_API_URL = (
    "https://selph-api.kindisland-e536c4ff.eastus2.azurecontainerapps.io"
)


def resolve_api_url(arg_url: str | None = None) -> str:
    """Argument > env > hardcoded default. Trailing slash stripped."""
    return (
        arg_url
        or os.environ.get("SELPH_API_URL", "").strip()
        or DEFAULT_API_URL
    ).rstrip("/")
