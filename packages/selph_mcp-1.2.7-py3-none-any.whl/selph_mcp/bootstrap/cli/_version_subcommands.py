"""Version/self-check subcommand handlers for selph-mcp-bootstrap (Phase C/F).

Subcommands:
- version
- _self-check
"""

from __future__ import annotations

import argparse
import json
import logging

from selph_mcp._log import get_logger, log_event
from ._envelope import err_envelope, ok_envelope

_log = get_logger("selph_mcp.bootstrap.cli")

# ---------------------------------------------------------------------------
# version (Phase C + F)
# ---------------------------------------------------------------------------

def _cmd_version(_args: argparse.Namespace) -> int:
    """version — emit installed wheel version + persona_contract_version."""
    log_event(_log, logging.INFO, "cli.version.entry")
    try:
        from selph_mcp.contracts.versions import PERSONA_CONTRACT_VERSION
        try:
            import importlib.metadata as _meta
            installed = _meta.version("selph-mcp")
        except Exception:  # noqa: BLE001
            installed = "unknown"
        ok_envelope({
            "installed": installed,
            "persona_contract_version": PERSONA_CONTRACT_VERSION,
        })
        log_event(_log, logging.INFO, "cli.version.complete",
                  installed=installed, persona_contract_version=PERSONA_CONTRACT_VERSION)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.version.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# _self-check (Phase C discriminated-union round-trip)
# ---------------------------------------------------------------------------

def _cmd_self_check(_args: argparse.Namespace) -> int:
    """_self-check — round-trip known-good fixtures for State, OnboardingState,
    ScanReport discriminated unions to verify CLI↔Python boundary fidelity."""
    log_event(_log, logging.INFO, "cli._self_check.entry")
    failures: list[str] = []

    # ── State fixture ─────────────────────────────────────────────────────────
    try:
        from selph_mcp.skill.state_schema import ColdStart, State
        from datetime import datetime, timezone
        cold = ColdStart(kind="cold_start")
        rt = State.model_validate({"kind": "cold_start"})
        assert rt.kind == "cold_start", f"State kind mismatch: {rt.kind}"
        # Re-parse from JSON
        State.model_validate(json.loads(cold.model_dump_json()))
    except Exception as exc:  # noqa: BLE001
        failures.append(f"State fixture failed: {exc}")

    # ── OnboardingState fixture ────────────────────────────────────────────────
    try:
        from selph_mcp.skill.state_schema import OnboardingState
        raw = {
            "schema_version": 1,
            "consumer_id": "cns-test01",
            "user_id": "U001",
            "completed_at": "2026-04-25T00:00:00+00:00",
            "persona_contract_version": 1,
            "harness_adapter_version": 1,
            "memory_boundary_policy_version": 1,
            "etag_cursor": 0,
            "installed_workflows": [],
        }
        state = OnboardingState.model_validate(raw)
        OnboardingState.model_validate(json.loads(state.model_dump_json()))
    except Exception as exc:  # noqa: BLE001
        failures.append(f"OnboardingState fixture failed: {exc}")

    # ── WorkflowScanReport fixture ─────────────────────────────────────────────
    try:
        from selph_mcp.skill.state_schema import WorkflowScanReport
        report = WorkflowScanReport(proposals=[], candidates=[])
        WorkflowScanReport.model_validate(json.loads(report.model_dump_json()))
    except Exception as exc:  # noqa: BLE001
        failures.append(f"WorkflowScanReport fixture failed: {exc}")

    if failures:
        log_event(_log, logging.ERROR, "cli._self_check.failed",
                  failure_count=len(failures))
        return err_envelope(
            error_type="SelfCheckFailed",
            message=f"{len(failures)} fixture(s) failed",
            details={"failures": failures},
        )

    ok_envelope({"checks_passed": 3, "checks": ["State", "OnboardingState", "WorkflowScanReport"]})
    log_event(_log, logging.INFO, "cli._self_check.complete", checks_passed=3)
    return 0
