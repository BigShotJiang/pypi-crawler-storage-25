"""``selph-mcp-bootstrap setup`` — one-shot interactive onboarding.

Wraps ``register`` + ``install-slash-command`` + ``write-mcp-entry`` so
a fresh user only has to answer two questions (user_id, api_key) and
ends up fully wired:

- ``~/.config/selph-mcp/credentials.json`` (chmod 0600) with bearer token
- ``~/.claude/commands/using-selph.md`` with the latest SKILL.md
- ``~/.claude.json`` with a ``selph-remote`` HTTP MCP entry

Designed to be the *only* CLI command a tester ever has to type.
"""

from __future__ import annotations

import argparse
import getpass
import logging
import os
import sys
from types import SimpleNamespace

from selph_mcp._log import get_logger, log_event

from ._defaults import resolve_api_url
from ._install_subcommands import _cmd_install_slash_command, _cmd_write_mcp_entry
from ._legacy import _cmd_register

_log = get_logger("selph_mcp.bootstrap.cli")


def _cmd_setup(args: argparse.Namespace) -> int:
    """Walk the user through the full first-time onboarding."""
    api_url = resolve_api_url(getattr(args, "api_url", None))

    print()
    print("Selph setup — two questions and we're done.")
    print(f"  Endpoint: {api_url}")
    print(f"  (override with --api-url or SELPH_API_URL)")
    print()

    user_id = (getattr(args, "user_id", None) or os.environ.get("SELPH_USER_ID", "")).strip()
    api_key = (getattr(args, "api_key", None) or os.environ.get("SELPH_API_KEY", "")).strip()

    if not sys.stdin.isatty() and (not user_id or not api_key):
        print(
            "ERROR: stdin is not a TTY but --user-id / --api-key were not supplied. "
            "Pass them as flags or set SELPH_USER_ID / SELPH_API_KEY.",
            file=sys.stderr,
        )
        return 2

    if not user_id:
        print("Your Selph user ID (e.g. U001):", end=" ", flush=True)
        user_id = sys.stdin.readline().strip()
    if not user_id:
        print("ERROR: user_id is required.", file=sys.stderr)
        return 2

    if not api_key:
        api_key = getpass.getpass("Your Selph API key (won't be displayed): ").strip()
    if not api_key:
        print("ERROR: api_key is required.", file=sys.stderr)
        return 2

    log_event(_log, logging.INFO, "cli.setup.entry", api_url=api_url, user_id=user_id)

    # ── Step 1/3 ── register
    print()
    print("[1/3] Registering with the Selph engine…")
    register_args = SimpleNamespace(
        user_id=user_id,
        api_url=api_url,
        api_key=api_key,
        harness_id=None,
        display_name=None,
        scopes=None,
        sensitivity_ceiling=None,
        budget_tier=None,
        persist_api_key=False,
        transport="http",
    )
    rc = _cmd_register(register_args)
    if rc != 0:
        print(
            "\nSetup aborted at register step. Fix the error above and re-run "
            "`selph-mcp-bootstrap setup`.",
            file=sys.stderr,
        )
        return rc

    # ── Step 2/3 ── install-slash-command
    print()
    print("[2/3] Installing the /using-selph slash command…")
    isc_args = SimpleNamespace(api_url=api_url)
    rc = _cmd_install_slash_command(isc_args)
    if rc != 0:
        print(
            "\nSlash-command install failed. The credentials file is saved, "
            "so you can re-run `selph-mcp-bootstrap install-slash-command` "
            "directly to retry just this step.",
            file=sys.stderr,
        )
        return rc

    # ── Step 3/3 ── write-mcp-entry
    print()
    print("[3/3] Wiring the remote MCP entry into ~/.claude.json…")
    wme_args = SimpleNamespace(remote_url=api_url, workspace=None)
    rc = _cmd_write_mcp_entry(wme_args)
    if rc != 0:
        print(
            "\nMCP-entry write failed. Re-run "
            "`selph-mcp-bootstrap write-mcp-entry` directly to retry.",
            file=sys.stderr,
        )
        return rc

    print()
    print("Done. Open Claude Code and type /using-selph to onboard a workspace.")
    log_event(_log, logging.INFO, "cli.setup.complete", api_url=api_url, user_id=user_id)
    return 0
