"""``selph-mcp-bootstrap`` console-script entry point (Phase C sub-package).

The CLI was split from a single ``cli.py`` (525 lines) into this sub-package
to stay within the surface-route 600-line hard cap after adding 16+ Phase C
subcommands.

Entry point for pyproject.toml stays at ``selph_mcp.bootstrap.cli:main``.
"""

from ._dispatch import main

__all__ = ["main"]
