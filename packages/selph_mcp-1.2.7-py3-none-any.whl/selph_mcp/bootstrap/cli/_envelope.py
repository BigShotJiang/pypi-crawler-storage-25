"""Uniform JSON envelope helper for selph-mcp-bootstrap subcommands.

Every subcommand prints exactly one JSON object to stdout:

    {"ok": true,  "data": <subcommand-specific>, "error": null}
    {"ok": false, "data": null, "error": {"type": "...", "message": "...", "details": {}}}

Exit code is 0 on ``ok: true``, non-zero on ``ok: false``.

This contract lets SKILL.md parse responses without inspecting stderr and
lets the user run any subcommand themselves to reproduce / debug.
"""

from __future__ import annotations

import json
import sys
import traceback
from typing import Any, Dict, Optional


def ok_envelope(data: Any) -> None:
    """Print a success envelope to stdout and return (do not exit)."""
    print(json.dumps({"ok": True, "data": data, "error": None}, indent=2, default=str))


def err_envelope(
    exc: Optional[Exception] = None,
    *,
    error_type: str = "RuntimeError",
    message: str = "",
    details: Optional[Dict[str, Any]] = None,
    exit_code: int = 1,
) -> int:
    """Print a failure envelope to stdout and return the exit code.

    Does NOT call sys.exit — callers use the return value with sys.exit.

    Args:
        exc: Exception to extract type/message from. If provided, overrides
            *error_type* and *message* unless those are explicitly set.
        error_type: Override error type string.
        message: Override error message.
        details: Optional extra context dict.
        exit_code: Exit code to return (default 1).

    Returns:
        The supplied *exit_code*.
    """
    if exc is not None:
        if not error_type or error_type == "RuntimeError":
            error_type = type(exc).__name__
        if not message:
            message = str(exc)[:500]
        if details is None:
            tb = traceback.format_exc()
            details = {"traceback": tb[:800]} if tb and tb != "NoneType: None\n" else {}

    print(
        json.dumps(
            {
                "ok": False,
                "data": None,
                "error": {
                    "type": error_type,
                    "message": message,
                    "details": details or {},
                },
            },
            indent=2,
            default=str,
        )
    )
    return exit_code
