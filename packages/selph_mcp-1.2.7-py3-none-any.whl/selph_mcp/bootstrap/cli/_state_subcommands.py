"""State/credentials subcommand handlers for selph-mcp-bootstrap (Phase C/D).

Subcommands:
- detect-state
- hydrate-global
- hydrate-legacy
- write-credentials
- record-onboarding
- update-etag
- reconcile-onboarding
- install-policy-block
- append-claude-md
- session-flush  (Phase D §13a item #7)
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any

from selph_mcp._log import get_logger, log_event
from ._envelope import err_envelope, ok_envelope

_log = get_logger("selph_mcp.bootstrap.cli")


# ---------------------------------------------------------------------------
# detect-state
# ---------------------------------------------------------------------------

def _cmd_detect_state(args: argparse.Namespace) -> int:
    """detect-state --workspace PATH"""
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    log_event(_log, logging.INFO, "cli.detect_state.entry", workspace=str(workspace))
    try:
        from selph_mcp.skill.bootstrap import detect_state, resolve_workspace_root
        ws = resolve_workspace_root(str(workspace))
        state = detect_state(ws)
        ok_envelope(json.loads(state.model_dump_json()))
        log_event(_log, logging.INFO, "cli.detect_state.complete", kind=state.kind)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.detect_state.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# hydrate-global
# ---------------------------------------------------------------------------

def _cmd_hydrate_global(_args: argparse.Namespace) -> int:
    """hydrate-global"""
    log_event(_log, logging.INFO, "cli.hydrate_global.entry")
    try:
        from selph_mcp.skill.bootstrap import hydrate_from_global_credentials
        result = hydrate_from_global_credentials()
        ok_envelope(result)
        log_event(_log, logging.INFO, "cli.hydrate_global.complete", found=result is not None)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.hydrate_global.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# hydrate-legacy
# ---------------------------------------------------------------------------

def _cmd_hydrate_legacy(_args: argparse.Namespace) -> int:
    """hydrate-legacy"""
    log_event(_log, logging.INFO, "cli.hydrate_legacy.entry")
    try:
        from selph_mcp.skill.bootstrap import hydrate_from_claude_code_config
        result = hydrate_from_claude_code_config()
        ok_envelope(result)
        log_event(_log, logging.INFO, "cli.hydrate_legacy.complete", found=result is not None)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.hydrate_legacy.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# write-credentials
# ---------------------------------------------------------------------------

def _cmd_write_credentials(args: argparse.Namespace) -> int:
    """write-credentials --workspace PATH --consumer-id ID --user-id UID --api-url URL"""
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    consumer_id = args.consumer_id
    user_id = args.user_id
    api_url = args.api_url
    log_event(_log, logging.INFO, "cli.write_credentials.entry",
              workspace=str(workspace), consumer_id=consumer_id, user_id=user_id)
    try:
        from selph_mcp.skill.bootstrap import write_credentials, resolve_workspace_root
        ws = resolve_workspace_root(str(workspace))
        write_credentials(
            ws,
            consumer_id=consumer_id,
            api_key=getattr(args, "api_key", "") or "",
            user_id=user_id,
            mcp_endpoint=api_url,
        )
        ok_envelope({"workspace": str(ws), "consumer_id": consumer_id})
        log_event(_log, logging.INFO, "cli.write_credentials.complete")
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.write_credentials.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# record-onboarding
# ---------------------------------------------------------------------------

def _cmd_record_onboarding(args: argparse.Namespace) -> int:
    """record-onboarding --workspace PATH --consumer-id ID --user-id UID
                         --etag-cursor N [--installed-workflows '[...]']"""
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    consumer_id = args.consumer_id
    user_id = args.user_id
    etag_cursor = int(args.etag_cursor)
    raw_workflows = getattr(args, "installed_workflows", None) or "[]"
    log_event(_log, logging.INFO, "cli.record_onboarding.entry",
              workspace=str(workspace), consumer_id=consumer_id)
    try:
        installed_workflows = json.loads(raw_workflows)
        from selph_mcp.skill.bootstrap import record_onboarding_complete, resolve_workspace_root
        ws = resolve_workspace_root(str(workspace))
        record_onboarding_complete(
            ws,
            consumer_id=consumer_id,
            user_id=user_id,
            installed_workflows=installed_workflows,
            etag_cursor=etag_cursor,
        )
        ok_envelope({"workspace": str(ws), "etag_cursor": etag_cursor})
        log_event(_log, logging.INFO, "cli.record_onboarding.complete")
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.record_onboarding.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# update-etag
# ---------------------------------------------------------------------------

def _cmd_update_etag(args: argparse.Namespace) -> int:
    """update-etag --workspace PATH --cursor N"""
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    cursor = int(args.cursor)
    log_event(_log, logging.INFO, "cli.update_etag.entry",
              workspace=str(workspace), cursor=cursor)
    try:
        from selph_mcp.skill.bootstrap import update_etag_cursor, resolve_workspace_root
        ws = resolve_workspace_root(str(workspace))
        update_etag_cursor(ws, cursor)
        ok_envelope({"cursor": cursor})
        log_event(_log, logging.INFO, "cli.update_etag.complete", cursor=cursor)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.update_etag.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# reconcile-onboarding
# ---------------------------------------------------------------------------

def _load_manifest_arg(raw: str) -> Any:
    """Load JSON from ``@path.json``, ``-`` (stdin), or inline JSON string."""
    if raw.startswith("@"):
        return json.loads(Path(raw[1:]).read_text(encoding="utf-8"))
    if raw == "-":
        return json.loads(sys.stdin.read())
    return json.loads(raw)


def _cmd_reconcile_onboarding(args: argparse.Namespace) -> int:
    """reconcile-onboarding --workspace PATH --whoami @file.json"""
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    log_event(_log, logging.INFO, "cli.reconcile_onboarding.entry",
              workspace=str(workspace))
    try:
        whoami_data = _load_manifest_arg(args.whoami)
        # Auto-unwrap the standard CLI envelope `{"ok": bool, "data": {...},
        # "error": ...}` so the SKILL.md flow ("dump whoami-remote output to a
        # temp file, pass via @file") works without an external `jq`-style
        # extraction step. Surface envelope-level failures explicitly.
        if (
            isinstance(whoami_data, dict)
            and "ok" in whoami_data
            and "data" in whoami_data
        ):
            if not whoami_data.get("ok"):
                return err_envelope(
                    error_type="WhoamiEnvelopeError",
                    message=(
                        "whoami envelope has ok=false; cannot reconcile. "
                        f"error={whoami_data.get('error')!r}"
                    ),
                )
            whoami_data = whoami_data["data"]
        from selph_mcp.skill.bootstrap import reconcile_onboarding, resolve_workspace_root
        from selph_mcp.contracts.whoami import Whoami
        whoami = Whoami.model_validate(whoami_data)
        ws = resolve_workspace_root(str(workspace))
        reconcile_onboarding(ws, whoami)
        ok_envelope({"consumer_id": whoami.consumer_id, "user_id": whoami.user_id})
        log_event(_log, logging.INFO, "cli.reconcile_onboarding.complete",
                  consumer_id=whoami.consumer_id)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.reconcile_onboarding.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# install-policy-block
# ---------------------------------------------------------------------------

def _cmd_install_policy_block(args: argparse.Namespace) -> int:
    """install-policy-block --workspace PATH"""
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    log_event(_log, logging.INFO, "cli.install_policy_block.entry",
              workspace=str(workspace))
    try:
        from selph_mcp.skill.bootstrap import install_retrieval_policy_block, resolve_workspace_root
        ws = resolve_workspace_root(str(workspace))
        install_retrieval_policy_block(ws)
        ok_envelope({"workspace": str(ws)})
        log_event(_log, logging.INFO, "cli.install_policy_block.complete")
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.install_policy_block.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# append-claude-md
# ---------------------------------------------------------------------------

def _cmd_append_claude_md(args: argparse.Namespace) -> int:
    """append-claude-md --workspace PATH"""
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    log_event(_log, logging.INFO, "cli.append_claude_md.entry",
              workspace=str(workspace))
    try:
        from selph_mcp.skill.bootstrap import append_claude_md_block, resolve_workspace_root
        ws = resolve_workspace_root(str(workspace))
        append_claude_md_block(ws)
        ok_envelope({"workspace": str(ws)})
        log_event(_log, logging.INFO, "cli.append_claude_md.complete")
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.append_claude_md.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# session-flush  (Phase D §13a item #7)
# ---------------------------------------------------------------------------

def _cmd_session_flush(args: argparse.Namespace) -> int:
    """session-flush --workspace PATH --session-id UUID --user-id UID

    Build and print the immediate-flush payload for a session, bypassing
    debounce/threshold checks (for session_close events).

    Prints the flush envelope JSON to stdout, or {"ok": true, "data": null}
    with a message if there are no pending turns.  Exit 0 in both cases.
    """
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    session_id: str = args.session_id
    user_id: str = args.user_id

    log_event(_log, logging.INFO, "cli.session_flush.entry",
              workspace=str(workspace), session_id=session_id, user_id=user_id)
    try:
        from selph_mcp.skill.runtime import force_flush_payload
        payload = force_flush_payload(
            workspace=workspace,
            session_id=session_id,
            user_id=user_id,
        )
        if payload is None:
            ok_envelope({"message": "no pending turns", "session_id": session_id})
            log_event(_log, logging.INFO, "cli.session_flush.no_pending_turns",
                      session_id=session_id)
        else:
            ok_envelope(payload)
            log_event(_log, logging.INFO, "cli.session_flush.complete",
                      session_id=session_id,
                      turn_count=len(payload.get("turns", [])))
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.session_flush.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)
