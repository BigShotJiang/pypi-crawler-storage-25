"""Bootstrap package for the selph-mcp wheel (Slice 3C).

Provides the ``selph-mcp-bootstrap`` console script entry point used by
the ``using-selph`` skill to register a new MCP consumer with a deployed
Selph engine and persist the resulting credentials at
``$XDG_CONFIG_HOME/selph-mcp/credentials.json``.

Subcommands
-----------
- ``register``   — POST /apps/mcp/consumers, capture bearer_token, write creds.
- ``whoami``     — print the locally-stored consumer_id / user_id / api_url.
- ``doctor``     — verify creds parse, engine reachable, contract version OK.

Public surface
--------------
:func:`selph_mcp.bootstrap.cli.main` — argparse entry point wired into
``[project.scripts]`` as ``selph-mcp-bootstrap``.

:mod:`selph_mcp.bootstrap.credentials` — XDG-compliant credentials
file loader / saver. Read by the same wheel's ``_client.py`` as a
fallback when ``SELPH_BEARER_TOKEN`` / ``SELPH_CONSUMER_ID`` env vars
are absent.
"""
