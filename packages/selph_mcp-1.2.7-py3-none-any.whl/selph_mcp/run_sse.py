"""
Entry point — run the Selph MCP server over the streamable-HTTP transport.

Pass B deployment note
----------------------
**Production** uses the mounted ``/mcp`` endpoint on ``selph-api`` (see
``ingestion_api/main.py::build_mounted_mcp`` and the ``app.mount("/mcp", ...)``
call).  This standalone runner is kept for two use cases:

1. **Local development** — launch a standalone streamable-HTTP MCP server
   without starting the full FastAPI stack.
2. **Backup second-Container-App path** — if the mounted ``/mcp`` approach is
   ever rolled back, this runner can be deployed on a separate Container App
   running ``selph_mcp.run_sse:main`` with its own Neo4j / Chroma / Postgres
   pool.

For the unified remote MCP hosting story see
``docs/selph_remote_mcp_hosting_strategy.md``.

Phase 1b §3.5.1 rewire
-----------------------
This runner historically started the legacy unauthenticated SSE FastMCP
server. It now boots the AUTHENTICATED ``selph_mcp.server.mcp_app``
streamable-HTTP transport — every tool call goes through
``require_consumer`` (X-API-Key + X-Selph-Consumer handshake) and the
consumer-to-user binding before any kernel work runs.

The new MCP SDK ships ``streamable-http`` instead of the legacy SSE
transport. Operators that previously hit the SSE endpoint should switch
to the streamable-HTTP path — same JSON-RPC envelope, just a different
transport name in the SDK.

The legacy ``selph_mcp/server.py`` FastMCP instance and the
unauthenticated ``selph_mcp/tools/*`` handlers stay on disk for the
future cleanup pass but are unreachable through this entry point.

Transport-aware pool sizing picks the larger HTTP defaults
(20-connection entity pool, matching the long-lived FastAPI process)
because the HTTP transport runs as a single shared process — unlike
stdio, each remote client does NOT spawn its own subprocess.
"""
from __future__ import annotations

import logging
import os


def main() -> None:
    # Keep the env-var name as ``sse`` so the existing pool-sizing
    # branch in selph_mcp.config.apply_transport_defaults still picks
    # the larger long-lived-process defaults.
    os.environ.setdefault("SELPH_MCP_TRANSPORT", "sse")

    from selph_mcp.config import apply_transport_defaults
    apply_transport_defaults()

    from selph_mcp.server.mcp_app import run_http
    from selph_mcp._log import configure_logging, get_logger, log_event

    configure_logging()
    _log = get_logger("selph_mcp.run_sse")

    # Honor both the legacy SELPH_MCP_SSE_* env vars (for back-compat
    # with existing deployment configs) and the new MCP_PORT/MCP_HOST
    # names called out in the brief.
    host = os.getenv("MCP_HOST") or os.getenv("SELPH_MCP_SSE_HOST", "127.0.0.1")
    port = int(os.getenv("MCP_PORT") or os.getenv("SELPH_MCP_SSE_PORT", "8765"))

    log_event(
        _log, logging.WARNING, "selph_mcp.run_sse.rewired",
        msg=(
            "selph_mcp run_stdio rewired to authenticated transport — "
            "old tools/* entrypoints retired"
        ),
    )
    log_event(
        _log, logging.INFO, "selph_mcp.run_sse.boot",
        host=host, port=port,
    )

    if host not in ("127.0.0.1", "localhost", "::1"):
        # Surface a LOUD warning in the log timeline so an accidental
        # 0.0.0.0 bind can't slip past unnoticed. Auth IS now enforced
        # (X-API-Key + X-Selph-Consumer) so a non-localhost bind is no
        # longer an open door, but it still widens the attack surface
        # to anyone who can reach the host.
        log_event(
            _log, logging.WARNING, "selph_mcp.run_sse.nonlocal_bind",
            host=host,
            warning=(
                "streamable-http MCP transport bound to a non-localhost host. "
                "Auth handshake (X-API-Key + X-Selph-Consumer) is required, "
                "but a stolen or shared API key now reaches more callers. "
                "Gate behind a VPN / reverse proxy when possible."
            ),
        )

    try:
        run_http(port=port, host=host)
    except KeyboardInterrupt:
        log_event(_log, logging.INFO, "selph_mcp.run_sse.keyboard_interrupt")
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "selph_mcp.run_sse.error",
            error_type=type(exc).__name__, error=str(exc),
        )
        raise
    finally:
        log_event(_log, logging.INFO, "selph_mcp.run_sse.shutdown")


if __name__ == "__main__":
    main()
