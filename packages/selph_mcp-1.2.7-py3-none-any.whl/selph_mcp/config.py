"""
Configuration for the Selph MCP Surface.

Owns:
    - Environment-variable readers for MCP-specific knobs
    - Transport-aware default pool sizing (stdio vs SSE)
    - `SelphContext` dataclass — the lifespan context handed to tool
      handlers by FastMCP

Transport-aware pool sizing
---------------------------
The MCP server shares the same Postgres pools (`SELPH_KG_DB_POOL_MAX`,
`CHECKPOINT_POOL_MAX`) as the FastAPI surface because the underlying
`selph_db.postgres_connection` pool is a module-level singleton. However,
when running in **stdio mode** every Claude Code session spawns its own
MCP subprocess, so each subprocess is a new Python process with a new
pool. Multiplying the FastAPI defaults (80 / 20) across many concurrent
Claude Code sessions would blow through Azure Postgres `max_connections`
quickly — so stdio defaults are sized down aggressively.

SSE mode runs a single shared process (like the FastAPI app) so the
defaults match the FastAPI budget.

Operator overrides always win: if the operator has already set
`SELPH_KG_DB_POOL_MAX` or `CHECKPOINT_POOL_MAX` in the environment before
the process starts, this module leaves them alone.
"""
from __future__ import annotations

import asyncio
import os
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional, Set

from selph_mcp._log import trace_id_ctx


SELPH_MCP_TRANSPORT_ENV = "SELPH_MCP_TRANSPORT"


def apply_transport_defaults() -> str:
    """
    Apply transport-appropriate Postgres pool defaults before the pool
    singleton is touched for the first time.

    Must be called during process startup BEFORE any code imports
    `selph_db.postgres_connection` — once the pool is built, env-var
    changes are ignored.

    Returns the resolved transport string ("stdio" or "sse" — defaults to
    "stdio" when unset).

    Rationale for the stdio ceiling: one MCP process per Claude Code
    session. At e.g. 10 concurrent sessions the aggregate load on Azure
    Postgres would be 10 × pool_max. A 5-connection stdio pool keeps the
    worst case bounded.
    """
    transport = (os.getenv(SELPH_MCP_TRANSPORT_ENV) or "stdio").strip().lower()

    if transport == "sse":
        # SSE runs as a single long-lived process — mirror the FastAPI
        # defaults (80 entity pool, 20 checkpoint pool).
        entity_default = "20"
        checkpoint_default = "10"
    else:
        # stdio — one process per Claude Code session. Pool is tight
        # (3 entity + 2 checkpoint = 5 conns/session) so Azure Postgres
        # max_connections=150 stays under the ceiling even with FastAPI
        # (100 conns at full load) + several concurrent stdio sessions.
        # Budget: 150 - 100 FastAPI - ~20 server reserve = 30 for stdio,
        # 30 / 5 = 6 safe concurrent sessions. Raise both Azure
        # max_connections AND these defaults together if more headroom
        # is needed. Operator overrides via env win.
        entity_default = "3"
        checkpoint_default = "2"

    # Only apply if the operator has NOT already pinned the value. This
    # means the operator can override (up or down) from the cloud env or
    # the .mcp.json `env` block.
    os.environ.setdefault("SELPH_KG_DB_POOL_MAX", entity_default)
    os.environ.setdefault("CHECKPOINT_POOL_MAX", checkpoint_default)

    return transport


def resolve_default_user_id() -> Optional[str]:
    """
    Return the fallback user_id applied when an MCP tool call omits it.

    For stdio / single-user setups operators can pin `SELPH_USER_ID` so
    Claude Code calls do not have to repeat the value on every tool call.
    For SSE / multi-user setups leave it unset and require the tool call
    to supply user_id.
    """
    value = os.getenv("SELPH_USER_ID")
    return value.strip() if value and value.strip() else None


def resolve_default_consumer_id() -> str:
    """
    Return the Consumer identifier used when the tool call omits one.

    `SELPH_CONSUMER_ID` lets the operator pre-declare the Consumer
    attached to this MCP process (e.g. "claude_code", "openclaw_delegate").
    Defaults to the generic `"mcp_client"` so audit rows always have a
    non-empty initiator — auth arrives later.
    """
    value = os.getenv("SELPH_CONSUMER_ID")
    if value and value.strip():
        return value.strip()
    return "mcp_client"


@dataclass
class SelphContext:
    """Context object passed to every tool handler by the FastMCP lifespan.

    Tool handlers access it through ``ctx.request_context.lifespan_context``.
    All fields are populated during ``selph_lifespan`` in
    ``selph_mcp.server``.
    """

    # Shared clients — lifecycle owned by selph_lifespan
    neo4j: Any = None
    """``selph_graph.graph_upserter.Neo4jConnection`` singleton."""

    chroma: Any = None
    """Chroma vector DB client, or ``None`` if init failed."""

    pg_pool_handle: Any = None
    """Checkpoint Postgres pool (``psycopg2.pool.ThreadedConnectionPool``)."""

    # Default identity — can be overridden per tool call
    default_user_id: Optional[str] = None
    default_consumer_id: str = "mcp_client"

    # Transport flavor — for logging / diagnostics
    transport: str = "stdio"

    # Background extraction task registry
    background_tasks: Set[asyncio.Task[Any]] = field(default_factory=set)
    """
    Outstanding fire-and-forget tasks spawned by the ``observe`` tool when
    ``trigger_extraction=True``. The lifespan drains these on shutdown —
    NEVER add tasks here without wiring a ``discard`` done-callback.
    """


def stamp_mcp_trace_id() -> str:
    """Stamp a fresh 16-char trace_id on the current async context.

    Called at the top of every MCP tool handler so the shared
    ``selph_utils.log.ContextFilter`` picks it up on every ``log_event``
    emission instead of falling back to the default ``"-"``. No reset is
    needed: FastMCP dispatches each tool invocation to its own coroutine,
    and each new call overwrites the previous trace_id at entry.

    Kept as a plain function (not a decorator) so FastMCP's tool-signature
    introspection sees the original handler — ``functools.wraps``'d
    wrappers break ``ForwardRef`` resolution for ``Optional[Context]``
    annotations under ``from __future__ import annotations``.
    """
    trace_id = uuid.uuid4().hex[:16]
    trace_id_ctx.set(trace_id)
    return trace_id


__all__ = [
    "SELPH_MCP_TRANSPORT_ENV",
    "SelphContext",
    "apply_transport_defaults",
    "resolve_default_consumer_id",
    "resolve_default_user_id",
    "stamp_mcp_trace_id",
]
