"""Vendored logger for the selph_mcp wheel (Slice 2).

Provides the minimal subset of ``selph_utils.log`` that the MCP package
needs — ``get_logger``, ``log_event``, plus the supporting context vars
and formatter — without importing ``selph_utils`` itself.

Goal: after Slice 2 ``selph_mcp/`` imports nothing from ``selph_utils``.
The output format (JSON, same fixed field names) is kept byte-for-byte
compatible so logfire / Azure Log Analytics KQL queries continue to work
unchanged against both the engine and the wheel.

Stdout-poisoning guard
----------------------
This module is imported early in both the stdio and SSE transports.
At import time we set the ``httpx``, ``httpcore``, and ``urllib3``
loggers to ``WARNING`` and force a ``StreamHandler(sys.stderr)`` so any
retry / timeout / connection chatter from the HTTP engine client never
lands on stdout (which is the JSON-RPC channel for stdio transports).
"""

from __future__ import annotations

import json
import logging
import os
import sys
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Any, Generator, Optional

# ─────────────────────────────────────────────────────────────────────────────
# Stdout-poisoning guard — applied once at module import.
# httpx / httpcore / urllib3 must never write to stdout because the stdio
# transport uses stdout as the exclusive JSON-RPC channel. Force every
# HTTP-library logger to stderr before any client is created.
# ─────────────────────────────────────────────────────────────────────────────

def _redirect_http_loggers_to_stderr() -> None:
    """Force httpx/httpcore/urllib3 logs to stderr at WARNING level."""
    _REDIRECT_NAMES = ("httpx", "httpcore", "urllib3")
    _stderr_handler = logging.StreamHandler(sys.stderr)
    _stderr_handler.setLevel(logging.WARNING)
    for name in _REDIRECT_NAMES:
        lib_logger = logging.getLogger(name)
        lib_logger.setLevel(logging.WARNING)
        # Only add if no stderr handler already present (idempotent).
        if not any(
            isinstance(h, logging.StreamHandler) and h.stream is sys.stderr
            for h in lib_logger.handlers
        ):
            lib_logger.addHandler(_stderr_handler)
        lib_logger.propagate = False  # prevent bubbling to root (which may stdout)


_redirect_http_loggers_to_stderr()

# ─────────────────────────────────────────────────────────────────────────────
# Context variables (matches selph_utils.log)
# ─────────────────────────────────────────────────────────────────────────────

trace_id_ctx: ContextVar[str] = ContextVar("trace_id", default="-")
run_id_ctx: ContextVar[str] = ContextVar("run_id", default="-")


def get_trace_id() -> str:
    """Return the current trace ID.

    §5.7 bridge: when ``selph_utils.log`` is present in the same process
    (mounted MCP case), prefer its ``trace_id_ctx`` over our own so that
    both the API and the MCP code emit the same trace ID on every log line.
    Falls back to our own contextvar for standalone stdio / SSE operation.
    """
    try:
        import selph_utils.log as _sul
        host_trace = _sul.trace_id_ctx.get()
        if host_trace and host_trace != "-":
            return host_trace
    except Exception:  # noqa: BLE001 — selph_utils not present in wheel env
        pass
    return trace_id_ctx.get()


def get_run_id() -> str:
    return run_id_ctx.get()


def new_run_id() -> str:
    """Generate a short 12-char hex run ID."""
    return uuid.uuid4().hex[:12]


def set_run_id(run_id: str):
    """Set run_id in the current async context; returns a reset token."""
    return run_id_ctx.set(run_id)


# ─────────────────────────────────────────────────────────────────────────────
# LogRecord attribute names — excluded from the "extra" JSON payload
# ─────────────────────────────────────────────────────────────────────────────

_RECORD_ATTRS = frozenset({
    "name", "msg", "args", "levelname", "levelno", "pathname",
    "filename", "module", "exc_info", "exc_text", "stack_info",
    "lineno", "funcName", "created", "msecs", "relativeCreated",
    "thread", "threadName", "processName", "process", "message",
    "taskName", "trace_id", "run_id",
})

_RESERVED_LOGRECORD_ATTRS = frozenset({
    "name", "msg", "args", "levelname", "levelno", "pathname", "filename",
    "module", "exc_info", "exc_text", "stack_info", "lineno", "funcName",
    "created", "msecs", "relativeCreated", "thread", "threadName",
    "processName", "process", "message", "asctime",
})


# ─────────────────────────────────────────────────────────────────────────────
# JSON Formatter (identical output to selph_utils.log.SelphJSONFormatter)
# ─────────────────────────────────────────────────────────────────────────────

class _SelphJSONFormatter(logging.Formatter):
    """Renders each LogRecord as a single UTF-8 JSON line to stderr."""

    def format(self, record: logging.LogRecord) -> str:
        record.message = record.getMessage()
        if record.exc_info and not record.exc_text:
            record.exc_text = self.formatException(record.exc_info)

        doc: dict[str, Any] = {
            "ts": (
                datetime.fromtimestamp(record.created, tz=timezone.utc)
                .strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
            ),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.message,
            "trace_id": getattr(record, "trace_id", "-"),
            "run_id": getattr(record, "run_id", "-"),
        }

        for key, val in record.__dict__.items():
            if key not in _RECORD_ATTRS and not key.startswith("_"):
                doc[key] = val

        if record.exc_text:
            doc["exc"] = record.exc_text.strip()

        return json.dumps(doc, default=str, ensure_ascii=False)


class _ContextFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.trace_id = get_trace_id()
        record.run_id = get_run_id()
        return True


# ─────────────────────────────────────────────────────────────────────────────
# Application-level setup
# ─────────────────────────────────────────────────────────────────────────────

def _is_host_logging_configured() -> bool:
    """Return True when ``selph_utils.log`` has already configured the root logger.

    Detection strategy: look for a handler whose formatter is an instance of
    ``selph_utils.log.SelphJSONFormatter`` (the class that
    ``selph_utils.log.configure_logging`` installs).  That class is distinct
    from this module's ``_SelphJSONFormatter``, so the check is unambiguous.

    If ``selph_utils`` is not importable (standalone wheel environment), the
    import guard catches the ``ImportError`` / ``ModuleNotFoundError`` and we
    fall back to a sentinel-attribute check: ``selph_utils.log.configure_logging``
    stamps ``_selph_utils_log = True`` on its handler so the sentinel is stable
    even if the formatter name ever changes.

    Both approaches may be True simultaneously; either is sufficient.

    Note: ``selph_utils.log.configure_logging`` uses ``StreamHandler()`` with
    *no* argument, which defaults to ``sys.stderr`` (not ``sys.stdout``).
    A stream-identity check would therefore always return False — do NOT use it.
    """
    root = logging.getLogger()
    for h in root.handlers:
        # Primary: formatter-class check.
        fmt = getattr(h, "formatter", None)
        if fmt is not None:
            try:
                from selph_utils.log import SelphJSONFormatter as _HostFmt
                if isinstance(fmt, _HostFmt):
                    return True
            except Exception:  # noqa: BLE001 — selph_utils absent in wheel env
                pass
        # Fallback: sentinel attribute set by selph_utils.log.configure_logging.
        if getattr(h, "_selph_utils_log", False):
            return True
    return False


def configure_logging(level: int = logging.INFO) -> None:
    """Configure the root logger to emit JSON to **stderr**.

    The stdio transport owns stdout; all logging MUST go to stderr.
    This is the wheel-specific departure from the engine's
    ``selph_utils.log.configure_logging`` which writes to stdout.

    Call once at process startup (``run_stdio.py``, ``run_sse.py``).

    **Idempotence / host-aware guard** — when ``selph_utils.log`` has already
    configured the root logger (detected by a ``StreamHandler(sys.stdout)``),
    this function is a no-op.  That prevents the MCP package from silently
    replacing the API's JSON-on-stdout handler with its own JSON-on-stderr
    handler when ``ingestion_api.main`` imports ``selph_mcp.server.mcp_app``
    (the §5.6 double-call regression).
    """
    if _is_host_logging_configured():
        # Host (selph_utils.log) already owns the root logger — do not
        # disturb its handlers.  Any subsequent log_event() calls in MCP
        # code will propagate through the host's handler, which is correct
        # behaviour for the mounted (in-process) case.
        return

    env_level_str = os.environ.get("LOG_LEVEL", "").upper()
    env_level = getattr(logging, env_level_str, None)
    resolved_level = env_level if env_level is not None else level

    root = logging.getLogger()
    root.handlers.clear()

    # stderr — never stdout
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(_SelphJSONFormatter())
    handler.addFilter(_ContextFilter())

    root.addHandler(handler)
    root.setLevel(resolved_level)


# ─────────────────────────────────────────────────────────────────────────────
# Public logger factory
# ─────────────────────────────────────────────────────────────────────────────

def get_logger(name: str) -> logging.Logger:
    """Return a standard Python logger by name."""
    return logging.getLogger(name)


# ─────────────────────────────────────────────────────────────────────────────
# Structured event helper (identical signature to selph_utils.log.log_event)
# ─────────────────────────────────────────────────────────────────────────────

def log_event(
    logger: logging.Logger,
    level: int,
    event: str,
    msg: Optional[str] = None,
    **kwargs: Any,
) -> None:
    """Emit a structured log event.

    Signature is identical to :func:`selph_utils.log.log_event` so call
    sites are mechanically substitutable (just change the import).

    Tokens and secrets MUST NEVER be passed as kwargs — callers are
    responsible for redacting sensitive values before this call.
    """
    if not logger.isEnabledFor(level):
        return
    reserved = _RESERVED_LOGRECORD_ATTRS
    safe: dict[str, Any] = {}
    collisions: list[str] = []
    for k, v in kwargs.items():
        if k in reserved:
            safe[f"field_{k}"] = v
            collisions.append(k)
        else:
            safe[k] = v
    extra = {"event": event, **safe}
    if collisions:
        extra["_log_field_collisions"] = ",".join(collisions)
    logger.log(level, msg if msg is not None else event, extra=extra)


def format_log_message(*parts: Any, sep: str = " ", end: str = "\n") -> str:
    """Build a print-style message string for structured logging."""
    msg = sep.join(str(p) for p in parts)
    if end and end != "\n":
        msg = f"{msg}{end}"
    return msg


# ─────────────────────────────────────────────────────────────────────────────
# Phase timing context manager (subset used by some MCP modules)
# ─────────────────────────────────────────────────────────────────────────────

@contextmanager
def log_phase(
    logger: logging.Logger,
    phase: str,
    *,
    user_id: Optional[str] = None,
) -> Generator[None, None, None]:
    """Context manager that logs phase start and end with duration."""
    import time as _time
    start = _time.perf_counter()
    log_event(logger, logging.INFO, f"{phase}.start", phase=phase, user_id=user_id)
    try:
        yield
    finally:
        duration_ms = round((_time.perf_counter() - start) * 1000, 2)
        log_event(
            logger, logging.INFO, f"{phase}.end",
            phase=phase,
            duration_ms=duration_ms,
            user_id=user_id,
        )


__all__ = [
    "get_logger",
    "log_event",
    "format_log_message",
    "log_phase",
    "configure_logging",
    "trace_id_ctx",
    "run_id_ctx",
    "get_trace_id",
    "get_run_id",
    "new_run_id",
    "set_run_id",
]
