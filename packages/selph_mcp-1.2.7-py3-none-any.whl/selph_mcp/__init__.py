"""
Selph MCP Surface — persona kernel over the Model Context Protocol (Gap 6).

This package is a **Surface layer** — a transport adapter that exposes the
four kernel syscalls (`observe`, `query`, `project`, `revise`) to any
MCP-compatible Consumer (Claude Code, OpenClaw, Claude Agent SDK, future
third-party apps).

Import discipline
-----------------
`selph_mcp` imports ONLY from:
    - selph_core
    - selph_db
    - selph_graph
    - selph_shared
    - selph_schema

`selph_mcp` MUST NOT import:
    - ingestion_api (FastAPI Surface — peer, not dependency)
    - selph_apps    (App layer — peer, not dependency)

The `.importlinter` contract in the repo root enforces this boundary.

Two entry points
----------------
    python -m selph_mcp.run_stdio   — stdio transport (Claude Code local)
    python -m selph_mcp.run_sse     — SSE transport (remote Consumers)

See `docs/selph-gap6-design-brief.md` for the full design.
"""

__all__: list[str] = []
