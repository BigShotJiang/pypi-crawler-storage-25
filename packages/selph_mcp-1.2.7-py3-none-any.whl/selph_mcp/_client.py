"""Thin httpx-based HTTP client for the Selph MCP wheel (Slice 2).

The EngineClient is the ONLY mechanism by which ``selph_mcp`` talks to
Postgres, Neo4j, Chroma, or any other backend store. All direct
``selph_db`` / ``selph_core`` / ``selph_graph`` imports have been
removed from ``selph_mcp`` — every I/O request now flows through this
client to the deployed FastAPI engine.

Public surface
--------------
``EngineClient`` — async HTTP/2 client with typed exceptions, per-call
auth-header injection, and startup contract-version assertion.

Environment variables (read at construction time)
-------------------------------------------------
``SELPH_API_URL``        — base URL of the deployed engine
                           (default: https://selph-api.kindisland-e536c4ff.eastus2.azurecontainerapps.io)
``SELPH_CONSUMER_ID``    — ``X-Consumer-Id`` header value
``SELPH_BEARER_TOKEN``   — ``Authorization: Bearer <token>`` value
``SELPH_API_KEY``        — ``X-API-Key`` shared secret (engine routes
                           that still use the API-key transport path)
``SELPH_CLIENT_TIMEOUT`` — per-request timeout in seconds (default 60)

Exception classes
-----------------
``EngineUpstreamError``          — non-2xx response from engine
``EngineUnreachableError``       — network-level failure (no response)
``EngineRevokedError``           — 401 received (consumer revoked)
``EngineUnknownConsumerError``   — 400/403 for unknown consumer
``RevisionTargetNotFoundError``  — 404 from a revision route
``EngineContractVersionMismatch``— server version != local constant

Stdout-poisoning guard
----------------------
This module, like ``_log.py``, is imported early. The guard is already
applied by ``_log.py`` at module import time; we do NOT re-apply it
here to avoid double-adding the stderr handler.
"""
from __future__ import annotations

import logging
import os
from contextvars import ContextVar, Token
from typing import Any, Dict, Optional, Tuple

import httpx

from selph_mcp._log import get_logger, log_event
from selph_mcp.contracts.versions import PERSONA_CONTRACT_VERSION

_log = get_logger("selph_mcp._client")

# ─────────────────────────────────────────────────────────────────────────────
# Engine base URL default (matches cloud.sh deploy target)
# ─────────────────────────────────────────────────────────────────────────────

_DEFAULT_ENGINE_URL = (
    "https://selph-api.kindisland-e536c4ff.eastus2.azurecontainerapps.io"
)

# ─────────────────────────────────────────────────────────────────────────────
# Per-request credential contextvars (Bug 3 fix — mounted auth forwarding)
# ─────────────────────────────────────────────────────────────────────────────
# In mounted mode, each incoming /mcp request is authenticated by
# bearer_auth_asgi and the caller's raw Bearer token + consumer_id are stored
# in scope["state"].  The tool wrappers in mcp_app.py call
# set_request_credentials() so that loopback HTTP calls made via get_client()
# carry the *caller's* credentials rather than the env-singleton credentials.
#
# For stdio transport: bearer_auth_asgi never runs, contextvars remain at
# their default (None), and get_client() returns the env-based singleton —
# byte-identical to the pre-Bug-3-fix behaviour.
_request_bearer_ctx: ContextVar[Optional[str]] = ContextVar(
    "_request_bearer_ctx", default=None
)
_request_consumer_id_ctx: ContextVar[Optional[str]] = ContextVar(
    "_request_consumer_id_ctx", default=None
)
# Per-request EngineClient cache (Bug 4 fix — socket leak).
# get_client() stores the freshly-constructed per-request client here so
# that multiple get_client() calls within the same request reuse a SINGLE
# httpx.AsyncClient (no repeated socket allocation).  On scope exit,
# _mounted_request_credentials resets this var and calls aclose() on the
# cached client — preventing the FD leak that Codex cycle-3 introduced.
# For stdio transport the var stays None and no aclose() is attempted.
_request_client_ctx: ContextVar[Optional["EngineClient"]] = ContextVar(
    "_request_client_ctx", default=None
)


# ─────────────────────────────────────────────────────────────────────────────
# Typed exceptions
# ─────────────────────────────────────────────────────────────────────────────

class EngineUpstreamError(Exception):
    """Non-2xx HTTP response from the engine."""

    def __init__(self, status_code: int, body: str) -> None:
        self.status_code = status_code
        self.body = body
        super().__init__(f"Engine returned HTTP {status_code}: {body[:300]}")


class EngineUnreachableError(Exception):
    """Network-level failure — no HTTP response received."""


def _format_unreachable(verb: str, path: str, exc: Exception) -> str:
    """Build an EngineUnreachableError message that survives empty exc strs.

    httpx timeout exceptions (ConnectTimeout, ReadTimeout, PoolTimeout)
    have empty ``args`` so ``str(exc)`` is "" — without the class name
    the wrapped error renders as bare ``engine unreachable:`` and is
    undebuggable downstream.
    """
    detail = str(exc) or repr(exc)
    return (
        f"{verb} {path} failed — engine unreachable: "
        f"{type(exc).__name__}: {detail}"
    )


class EngineRevokedError(EngineUpstreamError):
    """HTTP 401 — consumer token revoked or API key invalid."""


class EngineUnknownConsumerError(EngineUpstreamError):
    """HTTP 400 or 403 — consumer_id not found or cross-user mismatch."""


class RevisionTargetNotFoundError(EngineUpstreamError):
    """HTTP 404 from a revision/correction endpoint."""


class EngineContractVersionMismatch(Exception):
    """Server ``persona_contract_version`` does not match the local constant."""

    def __init__(self, local: int, remote: int) -> None:
        self.local = local
        self.remote = remote
        super().__init__(
            f"Contract version mismatch: local={local}, remote={remote}. "
            "Upgrade the selph_mcp wheel or the engine."
        )


# ─────────────────────────────────────────────────────────────────────────────
# EngineClient
# ─────────────────────────────────────────────────────────────────────────────

class EngineClient:
    """Async HTTP/2 client targeting the Selph FastAPI engine.

    Lifecycle
    ---------
    Call ``await client.startup()`` once after construction to assert
    contract-version compatibility. Call ``await client.aclose()`` on
    shutdown to drain the underlying connection pool.

    Headers injected on every request
    ----------------------------------
    ``Authorization: Bearer <bearer_token>``
    ``X-Consumer-Id: <consumer_id>``
    ``X-API-Key: <api_key>``        (for routes that use key-auth)
    ``Content-Type: application/json``
    """

    def __init__(
        self,
        *,
        api_url: Optional[str] = None,
        consumer_id: Optional[str] = None,
        bearer_token: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: float = 60.0,
    ) -> None:
        # Slice 3C: fall back to the chmod-0600 credentials file when
        # the SELPH_* env vars are unset. Lets the wheel boot from
        # ``selph-mcp`` (a console script) without the user pasting
        # creds into ~/.claude.json — bootstrap CLI wrote them.
        try:
            from selph_mcp.bootstrap.credentials import apply_to_environment
            apply_to_environment()
        except Exception:  # noqa: BLE001 — env-only path must keep working
            pass

        self._api_url = (
            api_url
            or os.environ.get("SELPH_API_URL", _DEFAULT_ENGINE_URL)
        ).rstrip("/")
        self._consumer_id = (
            consumer_id
            or os.environ.get("SELPH_CONSUMER_ID", "")
        )
        self._bearer_token = (
            bearer_token
            or os.environ.get("SELPH_BEARER_TOKEN", "")
        )
        self._api_key = (
            api_key
            or os.environ.get("SELPH_API_KEY", "")
        )

        try:
            timeout_env = float(os.environ.get("SELPH_CLIENT_TIMEOUT", timeout))
        except (ValueError, TypeError):
            timeout_env = float(timeout)
        self._timeout = timeout_env

        # Lazy-init: created on first use (or explicitly via startup()).
        self._http: Optional[httpx.AsyncClient] = None

    # ── Internal helpers ───────────────────────────────────────────────

    def _get_http(self) -> httpx.AsyncClient:
        """Return the shared async HTTP client, creating it on first call."""
        if self._http is None:
            limits = httpx.Limits(
                max_connections=10,
                max_keepalive_connections=5,
            )
            self._http = httpx.AsyncClient(
                base_url=self._api_url,
                http2=True,
                limits=limits,
                timeout=self._timeout,
            )
        return self._http

    def _headers(self) -> Dict[str, str]:
        """Build the per-request header dict."""
        h: Dict[str, str] = {"Content-Type": "application/json"}
        if self._bearer_token:
            h["Authorization"] = f"Bearer {self._bearer_token}"
        if self._consumer_id:
            h["X-Consumer-Id"] = self._consumer_id
        if self._api_key:
            h["X-API-Key"] = self._api_key
        return h

    def _raise_for_status(self, resp: httpx.Response) -> None:
        """Translate non-2xx responses into typed exceptions."""
        if resp.is_success:
            return
        body = resp.text or ""
        status = resp.status_code
        if status == 401:
            raise EngineRevokedError(status, body)
        if status in (400, 403):
            raise EngineUnknownConsumerError(status, body)
        if status == 404:
            # Callers that handle 404 specially (e.g. revise) catch
            # RevisionTargetNotFoundError; others catch EngineUpstreamError.
            raise RevisionTargetNotFoundError(status, body)
        raise EngineUpstreamError(status, body)

    # ── Startup / shutdown ─────────────────────────────────────────────

    async def startup(self) -> None:
        """Assert contract-version compatibility with the engine.

        Fetches ``GET /apps/mcp/server/versions`` and compares
        ``persona_contract_version`` against the local
        :data:`selph_mcp.contracts.versions.PERSONA_CONTRACT_VERSION`.
        Raises :class:`EngineContractVersionMismatch` when they differ.

        Called once at MCP process startup (e.g. ``run_stdio.py``
        lifespan). Safe to call multiple times — idempotent.
        """
        log_event(
            _log, logging.INFO, "mcp.client.startup.entry",
            api_url=self._api_url,
            local_contract_version=PERSONA_CONTRACT_VERSION,
        )
        try:
            data = await self.get("/apps/mcp/server/versions")
        except (EngineUnreachableError, EngineUpstreamError) as exc:
            log_event(
                _log, logging.ERROR, "mcp.client.startup.version_check_failed",
                api_url=self._api_url,
                error=str(exc)[:300],
            )
            # Fail-closed: a wheel that can't verify contract compatibility
            # must NOT serve tool calls. Silent fail-open here would let a
            # vN wheel talk to a vN+1 engine and silently misinterpret any
            # response shape that changed (sensitivity_ceiling fields, hub
            # payload schema, etc). The only way to recover is to make the
            # versions endpoint reachable.
            raise EngineContractVersionMismatch(
                PERSONA_CONTRACT_VERSION, -1
            ) from exc
        remote_version = data.get("persona_contract_version")
        if remote_version is None:
            log_event(
                _log, logging.ERROR, "mcp.client.startup.version_field_missing",
                api_url=self._api_url,
                response_keys=list(data.keys()),
            )
            raise EngineContractVersionMismatch(
                PERSONA_CONTRACT_VERSION, -1
            )
        if int(remote_version) != PERSONA_CONTRACT_VERSION:
            log_event(
                _log, logging.ERROR, "mcp.client.startup.version_mismatch",
                local=PERSONA_CONTRACT_VERSION,
                remote=remote_version,
            )
            raise EngineContractVersionMismatch(
                PERSONA_CONTRACT_VERSION, int(remote_version)
            )
        log_event(
            _log, logging.INFO, "mcp.client.startup.complete",
            api_url=self._api_url,
            persona_contract_version=PERSONA_CONTRACT_VERSION,
        )

    async def aclose(self) -> None:
        """Drain the connection pool and release resources."""
        if self._http is not None:
            await self._http.aclose()
            self._http = None
            log_event(_log, logging.INFO, "mcp.client.closed")

    # ── HTTP verb wrappers ─────────────────────────────────────────────

    async def get(
        self,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """HTTP GET, returns parsed JSON dict.

        Args:
            path: Path relative to ``api_url`` (must start with ``/``).
            params: Optional query-string parameters.

        Returns:
            Parsed JSON response body as a dict.

        Raises:
            EngineUnreachableError: network failure.
            EngineUpstreamError / subclasses: non-2xx response.
        """
        http = self._get_http()
        log_event(
            _log, logging.DEBUG, "mcp.client.get",
            path=path,
            params=params,
        )
        try:
            resp = await http.get(path, params=params, headers=self._headers())
        except httpx.RequestError as exc:
            log_event(
                _log, logging.ERROR, "mcp.client.get.unreachable",
                path=path,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )
            raise EngineUnreachableError(
                _format_unreachable("GET", path, exc)
            ) from exc
        self._raise_for_status(resp)
        return resp.json()

    async def post(
        self,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """HTTP POST with JSON body, returns parsed JSON dict.

        Args:
            path: Path relative to ``api_url`` (must start with ``/``).
            json: Request body (serialized as JSON).
            params: Optional query-string parameters.

        Returns:
            Parsed JSON response body as a dict.

        Raises:
            EngineUnreachableError: network failure.
            EngineUpstreamError / subclasses: non-2xx response.
        """
        http = self._get_http()
        log_event(
            _log, logging.DEBUG, "mcp.client.post",
            path=path,
            body_keys=list((json or {}).keys()),
        )
        try:
            resp = await http.post(
                path,
                json=json or {},
                params=params,
                headers=self._headers(),
            )
        except httpx.RequestError as exc:
            log_event(
                _log, logging.ERROR, "mcp.client.post.unreachable",
                path=path,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )
            raise EngineUnreachableError(
                _format_unreachable("POST", path, exc)
            ) from exc
        self._raise_for_status(resp)
        return resp.json()

    async def delete(
        self,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """HTTP DELETE, returns parsed JSON dict.

        Args:
            path: Path relative to ``api_url`` (must start with ``/``).
            params: Optional query-string parameters.

        Returns:
            Parsed JSON response body as a dict.

        Raises:
            EngineUnreachableError: network failure.
            EngineUpstreamError / subclasses: non-2xx response.
        """
        http = self._get_http()
        log_event(
            _log, logging.DEBUG, "mcp.client.delete",
            path=path,
        )
        try:
            resp = await http.delete(path, params=params, headers=self._headers())
        except httpx.RequestError as exc:
            log_event(
                _log, logging.ERROR, "mcp.client.delete.unreachable",
                path=path,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )
            raise EngineUnreachableError(
                _format_unreachable("DELETE", path, exc)
            ) from exc
        self._raise_for_status(resp)
        return resp.json()


# ─────────────────────────────────────────────────────────────────────────────
# Process-scoped singleton
# ─────────────────────────────────────────────────────────────────────────────

# A single default client instance.  Callers that need a custom URL /
# credentials construct their own; most callers import and use this one.
# It is intentionally NOT initialized at module import time to allow
# env vars to be set after the module loads (e.g. in test fixtures).
_default_client: Optional[EngineClient] = None

# Module-level base URL constant exposed so per-request clients constructed
# inside get_client() use the same URL as the env singleton.
_MODULE_CLIENT_BASE_URL: str = os.environ.get("SELPH_API_URL", _DEFAULT_ENGINE_URL)


def get_client() -> EngineClient:
    """Return (or lazily create) the appropriate EngineClient for this call.

    In mounted mode, ``set_request_credentials`` sets the per-request
    contextvars before the tool handler body executes. When those vars are
    non-None this function constructs a **fresh** ``EngineClient`` bound to
    the caller's Bearer token + consumer_id so loopback HTTP calls carry the
    correct per-caller identity instead of the env-singleton identity.

    For stdio transport (and any path where ``set_request_credentials`` was
    not called), the contextvars remain at their default ``None`` value and
    this function returns the env-based singleton — byte-identical to the
    previous behaviour.

    Thread-safe for reads; singleton construction races are harmless (both
    threads read the same env vars and produce equivalent clients).
    """
    global _default_client  # noqa: PLW0603
    bearer_override = _request_bearer_ctx.get()
    consumer_override = _request_consumer_id_ctx.get()
    if bearer_override is not None or consumer_override is not None:
        # Per-request client: check the request-scoped cache first so that
        # multiple get_client() calls within the same request share a single
        # httpx.AsyncClient (avoids repeated socket allocation).
        cached = _request_client_ctx.get()
        if cached is not None:
            return cached
        # No cached client yet — construct one, store it, and return it.
        # api_key stays env-based — the admin X-API-Key is not per-caller.
        client = EngineClient(
            api_url=_MODULE_CLIENT_BASE_URL,
            bearer_token=bearer_override or "",
            consumer_id=consumer_override or "",
            api_key=os.environ.get("SELPH_API_KEY", ""),
        )
        _request_client_ctx.set(client)
        return client
    # Fallback: env-based singleton (stdio path and any non-mounted caller).
    if _default_client is None:
        _default_client = EngineClient()
    return _default_client


def set_request_credentials(
    bearer: Optional[str],
    consumer_id: Optional[str],
) -> Tuple[Token[Optional[str]], Token[Optional[str]]]:
    """Set per-request Bearer token and consumer_id in contextvars.

    Must be called inside a ``try/finally`` block; the returned tokens must
    be passed to :meth:`contextvars.Token.reset` in the ``finally`` clause
    to restore the previous state::

        tok_b, tok_c = set_request_credentials(bearer, consumer_id)
        try:
            ...
        finally:
            _request_bearer_ctx.reset(tok_b)
            _request_consumer_id_ctx.reset(tok_c)

    When ``bearer`` and ``consumer_id`` are both ``None`` (stdio path), the
    contextvars stay at their default ``None`` value and ``get_client()``
    continues to return the env singleton — no behaviour change.
    """
    tok_b = _request_bearer_ctx.set(bearer)
    tok_c = _request_consumer_id_ctx.set(consumer_id)
    return tok_b, tok_c


__all__ = [
    "EngineClient",
    "EngineUpstreamError",
    "EngineUnreachableError",
    "EngineRevokedError",
    "EngineUnknownConsumerError",
    "RevisionTargetNotFoundError",
    "EngineContractVersionMismatch",
    "get_client",
    "set_request_credentials",
    "_request_bearer_ctx",
    "_request_consumer_id_ctx",
    "_request_client_ctx",
]
