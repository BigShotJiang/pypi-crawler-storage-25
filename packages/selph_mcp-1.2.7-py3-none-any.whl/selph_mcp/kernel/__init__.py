"""Kernel MCP surface — thin typed adapters over the Core syscalls.

Phase 1b §1 of the implementation plan. Each module exposes a single
async entry point that wraps a Core syscall (or, for compile-table
entries that do not yet have a single Core syscall, the underlying
DB manager) under the consumer-handshake auth model.

Public surface:

    from selph_mcp.kernel import observe, query, project, revise

Each module enforces the §3.5.1 consumer-to-user binding (anti-bypass)
before touching any DB. None of these modules import from
``ingestion_api`` or ``selph_apps`` (enforced by the
``mcp-surface-boundary`` import-linter contract).
"""

from selph_mcp.kernel import observe, project, query, revise

__all__ = ["observe", "project", "query", "revise"]
