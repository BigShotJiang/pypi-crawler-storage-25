"""Kernel ``observe`` adapter (Phase 1b §1).

Typed in-process adapter over the existing message-ingest path. Backs
the MCP ``observe`` tool exposed by ``selph_mcp.server.mcp_app``.

Behavior parity with ``POST /core/observe/ingest/selph/message`` (the
FastAPI route):

  1. Validate the consumer-to-user binding (anti-bypass per §3.5.1).
  2. Persist the universal Layer 1 row via
     :func:`selph_db.raw_evidence_manager.insert_raw_evidence` (sync —
     offloaded to an executor so the event loop stays free).
  3. Build an :class:`IngestRequest` with ``source = "harness_session"``
     and the freshly minted ``raw_evidence_id`` attached.
  4. Run :func:`selph_core.observe.pipeline.run_extraction_pipeline`
     ONLY when the caller opts into ``IngestMode.deep_ingest``;
     ``store_raw_only`` (default) returns after the L1 write so Phases
     0–7 stay opt-in per §3.3.1 of the implementation plan.

This module imports only from ``selph_core`` / ``selph_db`` /
``selph_graph`` — no ``ingestion_api`` reach-through (enforced by the
``mcp-surface-boundary`` import-linter contract).

See:
  - docs/selph_mcp_distribution_implementation_plan.md  (§1, §3.3.1)
  - selph_core/observe/pipeline.py
  - selph_db/raw_evidence_manager.py
  - .claude/rules/naming-and-constraints.md  (mandatory logging coverage)
"""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Dict, Optional

from fastapi import HTTPException, status

from selph_mcp._client import EngineUpstreamError, get_client
from selph_mcp.adapters.engine import EngineAdapter, HttpEngineAdapter
from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.writeback import IngestMode, SessionObservation
from selph_mcp.persona.etag import emit_invalidations
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.kernel.observe")


def _resolve_user_id(
    *,
    consumer: Consumer,
    payload_user_id: Optional[str],
) -> str:
    """Apply the §3.5.1 consumer-to-user binding.

    - When the payload omits ``user_id``: derive from
      ``consumer.user_id``.
    - When the payload includes ``user_id``: it MUST equal
      ``consumer.user_id``; mismatch → ``HTTPException(401)``.

    This closes the shared-API-key bypass: a caller holding the shared
    key cannot present a foreign ``user_id`` alongside a valid
    ``consumer_id`` and read another user's graph once multi-user lands.
    """
    if not payload_user_id:
        return consumer.user_id
    if payload_user_id != consumer.user_id:
        log_event(
            _log, logging.WARNING, "mcp.kernel.observe.user_binding_violation",
            consumer_id=consumer.consumer_id,
            consumer_user_id=consumer.user_id,
            payload_user_id=payload_user_id,
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=(
                "Payload user_id does not match the consumer-bound user_id."
            ),
        )
    return payload_user_id


async def observe_session(
    *,
    consumer: Consumer,
    observation: SessionObservation,
    graph: Any,
    engine: Optional[EngineAdapter] = None,
    mcp_transport: str = "stdio",
) -> Dict[str, Any]:
    """Adapter for harness session writeback (§3.3.1).

    Persists the raw text as a Layer 1 ``raw_evidence`` row tagged
    ``source = "harness_session"``. When ``observation.mode ==
    IngestMode.deep_ingest`` the full extraction pipeline runs against
    the freshly written L1 row; otherwise the call returns immediately
    after the L1 write (default ``store_raw_only`` posture).

    Args:
        consumer: The authenticated consumer (from
            :func:`selph_mcp.auth.require_consumer`). Supplies the bound
            ``user_id``.
        observation: The session observation contract instance.
        graph: ``selph_graph.graph_upserter.Neo4jConnection`` handle —
            required only when ``deep_ingest`` is selected; the
            ``store_raw_only`` path skips Neo4j entirely.
        engine: Optional :class:`selph_mcp.adapters.engine.EngineAdapter`
            instance. When supplied, used instead of constructing a fresh
            ``HttpEngineAdapter`` around ``get_client()`` — allows the
            mounted-MCP path to inject a ``CompositeEngineAdapter`` that
            routes ``/core/observe`` over loopback HTTP (Bug 1 fix).
        mcp_transport: Transport label forwarded to the inner
            :func:`observe` call for structured log fields.

    Returns:
        ``{"status": "ok" | "error", "raw_evidence_id": str|None,
           "mode": str, "extraction": dict|None, "duration_ms": float}``

    Raises:
        HTTPException(401): consumer/user binding violation, or
            payload-supplied ``consumer_id`` / ``harness_id`` that
            disagrees with the authenticated consumer (anti-bypass).
        HTTPException(404): unknown user_id.
    """
    # ── Anti-bypass binding (§3.5.1, defense-in-depth) ────────────────
    # The MCP tool handler in ``selph_mcp.server.mcp_app`` already
    # overwrites ``observation.consumer_id`` / ``observation.harness_id``
    # with the authenticated values, but ``observe_session`` is also
    # callable directly from any in-process operator script. Re-validate
    # here so a forgotten overwrite cannot persist a forged
    # provenance row claiming a consumer / harness the caller does not
    # own.
    if observation.consumer_id and observation.consumer_id != consumer.consumer_id:
        log_event(
            _log, logging.WARNING, "mcp.kernel.observe.consumer_binding_violation",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            payload_consumer_id=observation.consumer_id,
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=(
                "SessionObservation.consumer_id does not match the authenticated consumer."
            ),
        )
    if observation.harness_id and observation.harness_id != consumer.harness_id:
        log_event(
            _log, logging.WARNING, "mcp.kernel.observe.harness_binding_violation",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            bound_harness_id=consumer.harness_id,
            payload_harness_id=observation.harness_id,
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=(
                "SessionObservation.harness_id does not match the authenticated consumer."
            ),
        )

    return await observe(
        consumer=consumer,
        text=observation.text,
        source="harness_session",
        mode=observation.mode,
        external_source_id=observation.session_id,
        engine=engine,
        mcp_transport=mcp_transport,
        metadata={
            # Always persist the AUTHENTICATED ids — never the
            # caller-supplied values — so audit metadata cannot be
            # forged even when the in-process caller passes a
            # mismatching ``SessionObservation``.
            "consumer_id": consumer.consumer_id,
            "harness_id": consumer.harness_id,
            "session_id": observation.session_id,
            "speaker": observation.speaker.value,
            "captured_at": observation.captured_at.isoformat(),
            "structured_signals": [
                s.model_dump(mode="json") for s in observation.structured_signals
            ] if observation.structured_signals else [],
            "link_context": (
                observation.link_context.model_dump(mode="json")
                if observation.link_context else None
            ),
            # v2 memory-boundary metadata (§4.2, Phase A).
            # All four fields are optional on SessionObservation; omit
            # keys entirely when None to keep the JSONB payload clean.
            **({
                "provenance_role": observation.provenance_role,
            } if observation.provenance_role is not None else {}),
            **({
                "memory_boundary_class": observation.memory_boundary_class,
            } if observation.memory_boundary_class is not None else {}),
            **({
                "stability_hint": observation.stability_hint,
            } if observation.stability_hint is not None else {}),
            **({
                "write_intent": observation.write_intent,
            } if observation.write_intent is not None else {}),
        },
        user_id=None,  # binding derives from consumer.user_id
        graph=graph,
    )


async def observe(
    *,
    consumer: Consumer,
    text: str,
    user_id: Optional[str] = None,
    source: str = "harness_session",
    mode: IngestMode = IngestMode.store_raw_only,
    source_type: str = "generic_message",
    external_source_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    graph: Any = None,
    engine: Optional[EngineAdapter] = None,
    mcp_transport: str = "stdio",
) -> Dict[str, Any]:
    """General-purpose ``observe`` adapter for the MCP kernel surface.

    The session-observation entry point (:func:`observe_session`)
    delegates here. Direct callers can use this for non-session
    writebacks (e.g. operator scripts pushing raw evidence in batch)
    while keeping the same auth / binding semantics.
    """
    t0 = _time.perf_counter()
    resolved_user_id = _resolve_user_id(consumer=consumer, payload_user_id=user_id)

    log_event(
        _log, logging.INFO, "mcp.kernel.observe.entry",
        consumer_id=consumer.consumer_id,
        user_id=resolved_user_id,
        source=source,
        mode=mode.value,
        source_type=source_type,
        text_len=len(text or ""),
        deep_ingest=(mode is IngestMode.deep_ingest),
        mcp_transport=mcp_transport,
    )

    if mode is IngestMode.deep_ingest and not (text and text.strip()):
        log_event(
            _log, logging.WARNING, "mcp.kernel.observe.blank_text_deep_ingest",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            source=source,
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "deep_ingest requires non-empty text — Layer 1 anchor must "
                "exist before any Layer 2 derivative is produced (§3.3.1)."
            ),
        )

    # Delegate to the engine ingest route — it handles L1 write + optional
    # extraction pipeline and returns the same response shape this kernel
    # used to produce directly.
    payload: Dict[str, Any] = {
        "user_id": resolved_user_id,
        "message": text or "",
        "source": source,
        "source_type": source_type,
        "mode": mode.value,
        "consumer_id": consumer.consumer_id,
        "harness_id": consumer.harness_id,
    }
    if external_source_id is not None:
        payload["external_source_id"] = external_source_id
    if metadata is not None:
        payload["metadata"] = metadata

    # Use the injected engine adapter when present; fall back to HttpEngineAdapter
    # wrapping get_client() so persona tools that don't pass engine= keep working.
    _engine: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())

    try:
        result = await _engine.post(
            "/core/observe/ingest/selph/message",
            json=payload,
        )
    except EngineUpstreamError as exc:
        if exc.status_code == 404:
            log_event(
                _log, logging.WARNING, "mcp.kernel.observe.unknown_user",
                consumer_id=consumer.consumer_id,
                user_id=resolved_user_id,
                error=str(exc)[:300],
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=(
                    f"Unknown user_id: {resolved_user_id!r}. "
                    "Create the user first via POST /apps/users/ensure."
                ),
            ) from exc
        if exc.status_code in (400, 422):
            raise HTTPException(
                status_code=exc.status_code,
                detail=exc.body[:500],
            ) from exc
        log_event(
            _log, logging.ERROR, "mcp.kernel.observe.l1_write_failed",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            source_type=source_type,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Layer 1 raw_evidence write failed; aborting observation "
                "to preserve four-layer provenance (§3.3.1)."
            ),
        ) from exc
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "mcp.kernel.observe.l1_write_failed",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            source_type=source_type,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"observe failed: {exc}",
        ) from exc

    # Emit etag invalidation after successful ingest (non-fatal).
    try:
        await emit_invalidations(consumer, "l1_utterance_write", target_id=None)
    except Exception as inv_exc:  # noqa: BLE001
        log_event(
            _log, logging.WARNING, "mcp.kernel.observe.invalidation_failed",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            event_kind="l1_utterance_write",
            error_type=type(inv_exc).__name__,
            error=str(inv_exc)[:300],
        )

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    # NOTE: the HTTP IngestResponse (ingestion_api/clientSchema/responseSchema.py)
    # does NOT expose raw_evidence_id or extraction — those fields are internal to
    # the pipeline. Both are Optional here; callers must not depend on them being
    # populated via the HTTP path (they will be None). In-process paths that bypass
    # HTTP may populate them in future but do not yet.
    raw_evidence_id: Optional[str] = result.get("raw_evidence_id")  # type: ignore[assignment]
    extraction_result: Optional[Dict[str, Any]] = result.get("extraction")  # type: ignore[assignment]
    log_event(
        _log, logging.INFO, "mcp.kernel.observe.complete",
        consumer_id=consumer.consumer_id,
        user_id=resolved_user_id,
        raw_evidence_id=raw_evidence_id,
        mode=mode.value,
        deep_ingest_status=(extraction_result or {}).get("status") if isinstance(extraction_result, dict) else None,
        duration_ms=duration_ms,
        mcp_transport=mcp_transport,
    )

    return {
        "status": "ok",
        "raw_evidence_id": raw_evidence_id,
        "mode": mode.value,
        "extraction": extraction_result,
        "duration_ms": duration_ms,
    }


__all__ = ["observe", "observe_session"]
