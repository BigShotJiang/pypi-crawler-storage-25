"""Persona MCP surface (Phase 2).

Harness-facing tools, depth router, budget gate, etag lookup, envelope
builder. Implements §Phase 2 of
``docs/selph_mcp_distribution_implementation_plan.md``.

Public re-exports for the server tool registrar
(:mod:`selph_mcp.server.mcp_app`) and for in-process callers that
compose persona tools directly (e.g. the FastAPI side-car mount).
"""

from selph_mcp.persona.budget import (
    MODE_COSTS,
    check_and_decrement,
    ensure_and_decrement,
    ensure_today_row,
    peek_remaining,
)
from selph_mcp.persona.envelope_builder import build_envelope
from selph_mcp.persona.etag import (
    emit_invalidations,
    generate_etag,
    get_staleness_status,
    list_invalidations_since,
)
from selph_mcp.persona.router import (
    RouterMode,
    degrade_if_budget_insufficient,
    route_depth,
)
from selph_mcp.persona.tools.ask_selph import ask_selph
from selph_mcp.persona.tools.correct import correct
from selph_mcp.persona.tools.drift_signal import drift_signal
from selph_mcp.persona.tools.find_evidence import find_evidence
from selph_mcp.persona.tools.get_context import get_context
from selph_mcp.persona.tools.get_entity_card import get_entity_card
from selph_mcp.persona.tools.hire_for_role import hire_for_role
from selph_mcp.persona.tools.observe_session import observe_session
from selph_mcp.persona.tools.recommendation_feedback import recommendation_feedback
from selph_mcp.persona.tools.what_changed import what_changed

__all__ = [
    # tools (Phase 2 + Phase 3)
    "ask_selph",
    "correct",
    "drift_signal",
    "find_evidence",
    "get_context",
    "get_entity_card",
    "hire_for_role",
    "observe_session",
    "recommendation_feedback",
    "what_changed",
    # router
    "RouterMode",
    "route_depth",
    "degrade_if_budget_insufficient",
    # budget
    "MODE_COSTS",
    "ensure_today_row",
    "check_and_decrement",
    "ensure_and_decrement",
    "peek_remaining",
    # etag
    "emit_invalidations",
    "generate_etag",
    "get_staleness_status",
    "list_invalidations_since",
    # envelope
    "build_envelope",
]
