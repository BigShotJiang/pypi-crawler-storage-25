# Package marker — required for importlib.resources to resolve this directory
# as a package and for pyproject.toml package-data keys to take effect.
