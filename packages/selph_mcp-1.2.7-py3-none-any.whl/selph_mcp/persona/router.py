"""Depth router (Phase 2 task 2).

Deterministic 6-row decision table in front of the retrieval lanes.
Input: ``(GetContextRequest, Consumer)`` → chosen mode.

No natural-language phrase matching — unknown intents fall through to
the row-6 fallback (``"targeted"``). First matching row wins; ties
broken by first row.

    | Row | Condition                                                                                  | Chosen mode |
    |-----|--------------------------------------------------------------------------------------------|-------------|
    | 1   | request.depth != "auto"                                                                    | request.depth |
    | 2   | request.intent == "evidence_lookup" OR caller is find_evidence                              | evidence    |
    | 3   | request.intent in {strategy, decision_support, learning, planning} AND budget_tier != "cheap" | insight     |
    | 4   | request.constraints.entity_id set OR time_window set OR memory_types non-empty              | targeted    |
    | 5   | request.intent in {briefing, reply_draft, outreach}                                         | brief       |
    | 6   | (fallback)                                                                                 | targeted    |

Post-route degradation is the second half (§Phase 2 task 4): when
remaining budget is insufficient the chosen mode is stepped down one
level (``insight → targeted → brief``) and ``meta.degraded_from``
records the original mode.
"""
from __future__ import annotations

import logging
from decimal import Decimal
from typing import Literal, Optional, Tuple

from selph_mcp.persona.budget import MODE_COSTS
from selph_mcp.contracts.consumer import BudgetTier as ConsumerBudgetTier, Consumer
from selph_mcp.contracts.read import Depth, GetContextRequest, Intent
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.router")

# Modes the router returns. A superset of :class:`ModeUsed` minus
# "none" — the exhausted case is signaled by the budget gate, not the
# router itself.
RouterMode = Literal["brief", "targeted", "insight", "evidence"]

# Intents that upgrade the chosen mode to "insight" when budget permits.
_INSIGHT_INTENTS = frozenset({
    Intent.strategy,
    Intent.decision_support,
    Intent.learning,
    Intent.planning,
})

# Intents that map to a "brief" read when nothing more specific fires.
# ``operating_manual`` and ``workflow_recommendation`` are the bootstrapper
# intents used by the ``using-selph`` onboarding skill; both are summary
# reads over precomputed hub payloads (Postgres) — routing them to
# ``targeted`` (which does live KNN + Cypher on Neo4j) is a 20× cost
# increase for zero user benefit, and produces raw records with no
# citations instead of the structured hub envelope the skill expects.
_BRIEF_INTENTS = frozenset({
    Intent.briefing,
    Intent.reply_draft,
    Intent.outreach,
    Intent.operating_manual,
    Intent.workflow_recommendation,
})


def route_depth(
    request: GetContextRequest,
    consumer: Consumer,
    *,
    caller: Optional[str] = None,
) -> RouterMode:
    """Apply the deterministic depth decision table.

    Args:
        request: Validated depth-aware read request.
        consumer: Authenticated consumer (supplies ``budget_tier``).
        caller: Optional caller tag — ``"find_evidence"`` forces the
            evidence lane per row 2 regardless of intent.

    Returns:
        One of ``"brief" | "targeted" | "insight" | "evidence"``.
    """
    # Row 1: explicit override always wins.
    if request.depth != Depth.auto:
        chosen = request.depth.value
        log_event(
            _log, logging.INFO, "mcp.persona.router.row1_explicit",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            subject=request.subject.value,
            intent=request.intent.value,
            chosen=chosen,
        )
        return chosen  # type: ignore[return-value]

    # Row 2: evidence lookup.
    if request.intent == Intent.evidence_lookup or caller == "find_evidence":
        log_event(
            _log, logging.INFO, "mcp.persona.router.row2_evidence",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            subject=request.subject.value,
            intent=request.intent.value,
            caller=caller,
        )
        return "evidence"

    # Row 3: insight intents, only when budget tier permits.
    if (
        request.intent in _INSIGHT_INTENTS
        and consumer.budget_tier != ConsumerBudgetTier.cheap
    ):
        log_event(
            _log, logging.INFO, "mcp.persona.router.row3_insight",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            subject=request.subject.value,
            intent=request.intent.value,
            budget_tier=consumer.budget_tier.value,
        )
        return "insight"

    # Row 4: constraint-driven targeted retrieval.
    c = request.constraints
    if (
        c.entity_id is not None
        or c.time_window is not None
        or (c.memory_types and len(c.memory_types) > 0)
    ):
        log_event(
            _log, logging.INFO, "mcp.persona.router.row4_targeted",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            subject=request.subject.value,
            intent=request.intent.value,
            has_entity=c.entity_id is not None,
            has_time_window=c.time_window is not None,
            memory_type_count=len(c.memory_types or []),
        )
        return "targeted"

    # Row 5: brief-intent bucket.
    if request.intent in _BRIEF_INTENTS:
        log_event(
            _log, logging.INFO, "mcp.persona.router.row5_brief",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            subject=request.subject.value,
            intent=request.intent.value,
        )
        return "brief"

    # Row 6: fallback.
    log_event(
        _log, logging.INFO, "mcp.persona.router.row6_fallback",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        subject=request.subject.value,
        intent=request.intent.value,
    )
    return "targeted"


# ---------------------------------------------------------------------------
# Post-route degradation (§Phase 2 task 4)
# ---------------------------------------------------------------------------

# Order used for one-step degradation.
_STEP_DOWN: dict = {
    "insight": "targeted",
    "targeted": "brief",
    "brief": None,       # cannot step below brief — signals exhausted
    "evidence": None,    # evidence mode is non-LLM; we do not degrade it
}


def degrade_if_budget_insufficient(
    mode: RouterMode,
    remaining_credits: Decimal,
) -> Tuple[Optional[RouterMode], Optional[RouterMode]]:
    """Apply the §Phase 2 task 4 budget degradation rules.

    Rule:
      - If ``remaining_credits < 2 × cost_of_chosen_mode``: step down one
        level (``insight → targeted → brief``). ``meta.degraded_from``
        records the pre-degradation mode.
      - If ``remaining_credits < cost_of_brief``: the consumer is
        effectively exhausted — caller should return
        ``ok=False, mode_used="none", budget_tier="exhausted"``.

    ``evidence`` mode is not stepped down — its cost (0.5) is already
    the second cheapest after brief, and the caller is asking for raw
    evidence; degrading to a targeted summary would change the semantic
    of the read.

    Args:
        mode: The router-chosen mode.
        remaining_credits: The consumer's current remaining credits.
            Typically the ``peek_remaining`` value from
            :mod:`selph_mcp.persona.budget`.

    Returns:
        ``(final_mode, degraded_from)``:
          * ``final_mode``: the mode the caller should actually run, OR
            ``None`` to signal exhaustion (caller must short-circuit with
            ``ok=False, mode_used="none"``).
          * ``degraded_from``: the pre-degradation mode, OR ``None`` when
            no degradation occurred. Always ``None`` when ``final_mode``
            is ``None`` — the exhausted case does not produce an envelope
            with a mode_used at all.
    """
    if remaining_credits is None:
        # No row primed yet — treat as exhausted so caller primes a row
        # (via ensure_today_row) or returns exhausted envelope.
        return mode, None

    cost = MODE_COSTS.get(mode)
    if cost is None:
        # Unknown mode — surface as an invariant error rather than silently
        # degrade.
        raise ValueError(
            f"degrade_if_budget_insufficient called with unknown mode: {mode!r}"
        )

    brief_cost = MODE_COSTS["brief"]

    # Exhausted check: cannot afford even the cheapest mode.
    if remaining_credits < brief_cost:
        log_event(
            _log, logging.INFO, "mcp.persona.router.degrade_exhausted",
            remaining=str(remaining_credits),
            brief_cost=str(brief_cost),
            chosen_mode=mode,
        )
        return None, None

    # Full-cost + headroom check: degrade when remaining < 2 * cost.
    threshold = Decimal(2) * cost
    if remaining_credits >= threshold:
        return mode, None

    stepped = _STEP_DOWN.get(mode)
    if stepped is None:
        # ``brief`` + below-threshold: not truly exhausted (we already
        # passed the brief_cost gate above) but there is no mode cheaper
        # to degrade to. Run brief anyway — the single call will succeed
        # and the budget gate may refuse the NEXT call.
        return mode, None

    # Cascade: if the stepped mode is STILL below 2x its own cost,
    # degrade again. Prevents a caller on 0.3 credits from getting
    # "insight -> targeted" when they can't afford targeted either.
    final: RouterMode = stepped
    degraded_from: RouterMode = mode
    while True:
        step_cost = MODE_COSTS.get(final)
        if step_cost is None:
            break
        step_threshold = Decimal(2) * step_cost
        if remaining_credits >= step_threshold:
            break
        next_step = _STEP_DOWN.get(final)
        if next_step is None:
            break
        final = next_step  # type: ignore[assignment]

    log_event(
        _log, logging.INFO, "mcp.persona.router.degraded",
        remaining=str(remaining_credits),
        chosen_mode=degraded_from,
        final_mode=final,
        degraded_from=degraded_from,
    )
    return final, degraded_from


__all__ = [
    "RouterMode",
    "route_depth",
    "degrade_if_budget_insufficient",
]
