"""Dependency-key emitters for persona reads (Phase 1 §1.4).

Implements the two-tier dependency vocabulary per
``docs/dependency_vocabulary_v1.md``.

Tier 1 (object-level): ``entity:<entity_id>``, ``memory:<memory_id>``,
    ``hub:<hub_type>``
Tier 2 (coarse fallback): ``scope:self``, ``scope:person:<entity_id>``,
    ``scope:domain:<domain>``, ``memory_type:<type>``,
    ``consumer:<consumer_id>:recommendations``

Emission policy (per §1.2 of the implementation plan):
- Direct graph read  → Tier 1 only.
- Synthesized response → Tier 1 for every cited source + Tier 2 for every
  domain/scope/namespace integrated.
- Hub read (brief mode) → Tier 1 ``hub:<type>`` + Tier 2
  ``scope:domain:<domain>`` per domain. Per-entity Tier 1 keys NOT emitted
  from hub reads (spec §1.2: picked up at re-synthesis time).
- Evidence read → Tier 1 only.
- Writeback ack (observe_session, correct, recommendation_feedback,
  drift_signal) → empty list (these are writes, not reads).
- ``what_changed`` → empty list (it IS the invalidation feed).

All emitters deduplicate and preserve order (first-seen wins for dedup).
"""
from __future__ import annotations

from typing import List


def _dedup(keys: List[str]) -> List[str]:
    """Deduplicate while preserving first-seen order."""
    seen: set = set()
    out: List[str] = []
    for k in keys:
        if k not in seen:
            seen.add(k)
            out.append(k)
    return out


def emit_for_hub_read(hub_type: str, domains: List[str]) -> List[str]:
    """Emit dependency keys for a hub/brief-mode read.

    Tier 1: ``hub:<hub_type>``
    Tier 2: ``scope:domain:<d>`` for each known domain, or ``scope:self``
        when no domain information is available in the hub payload.

    The ``scope:domain:self`` key is NOT valid v1 vocabulary — ``"self"``
    is not a domain string.  When domains is empty (hub payload does not
    expose domain metadata), we fall back to the coarse Tier 2 key
    ``scope:self`` instead.  This avoids emitting an invalid key while
    still capturing the broad "self-scoped hub" invalidation surface.

    Per-entity Tier 1 keys are NOT emitted from hub reads — they are
    picked up when the hub is re-synthesized (spec §1.2).

    Args:
        hub_type: Hub type string (e.g. ``"current_identity"``).
        domains: List of domain strings the hub integrates.  Empty list
            triggers the ``scope:self`` fallback.

    Returns:
        Deduplicated list of dependency key strings.
    """
    keys: List[str] = []
    if hub_type:
        keys.append(f"hub:{hub_type}")
    populated_domains = [d for d in (domains or []) if d]
    if populated_domains:
        for d in populated_domains:
            keys.append(f"scope:domain:{d}")
    else:
        # No domain information — fall back to coarse self-scope key
        # (valid Tier 2 vocabulary) rather than the invalid scope:domain:self.
        keys.append("scope:self")
    return _dedup(keys)


def emit_for_graph_query(
    entity_ids: List[str],
    memory_ids: List[str],
) -> List[str]:
    """Emit dependency keys for a targeted/direct graph query.

    Tier 1 only: ``entity:<id>`` and ``memory:<id>`` for every cited
    source. No Tier 2 — direct reads are anchored to specific objects.

    Args:
        entity_ids: Entity IDs referenced by the response.
        memory_ids: Memory IDs referenced by the response.

    Returns:
        Deduplicated list of Tier 1 dependency key strings.
    """
    keys: List[str] = []
    for eid in entity_ids or []:
        if eid:
            keys.append(f"entity:{eid}")
    for mid in memory_ids or []:
        if mid:
            keys.append(f"memory:{mid}")
    return _dedup(keys)


def emit_for_synthesis(
    cited_entity_ids: List[str],
    cited_memory_ids: List[str],
    cited_hub_types: List[str],
    integrated_scopes: List[str],
    integrated_domains: List[str],
) -> List[str]:
    """Emit dependency keys for a synthesized (insight-mode) response.

    Tier 1 for every cited source + Tier 2 for every domain/scope/namespace
    integrated. Tier 2 is explicitly plural (spec §1.2: "Tier 2 explicitly
    plural" for synthesis).

    Args:
        cited_entity_ids: Entity IDs cited in the synthesis.
        cited_memory_ids: Memory IDs cited in the synthesis.
        cited_hub_types: Hub TYPES (not hub IDs) cited in the synthesis.
            The vocabulary key is ``hub:<hub_type>`` — passing bare
            ``HUB-XXXX`` IDs here is incorrect and would produce
            non-canonical keys that invalidation writers never emit.
            Callers must resolve hub citations to their ``hub_type``
            field before passing them here.
        integrated_scopes: Scopes integrated (e.g. ``["self"]``,
            ``["person:ENT-U001-PER-00042"]``). Emits
            ``scope:<value>`` Tier 2 keys.
        integrated_domains: Domain strings integrated (e.g.
            ``["professional", "learning"]``). Emits
            ``scope:domain:<d>`` Tier 2 keys.

    Returns:
        Deduplicated list of dependency key strings (Tier 1 + Tier 2).
    """
    keys: List[str] = []
    # Tier 1 — every cited object.
    for eid in cited_entity_ids or []:
        if eid:
            keys.append(f"entity:{eid}")
    for mid in cited_memory_ids or []:
        if mid:
            keys.append(f"memory:{mid}")
    for hub_type in cited_hub_types or []:
        if hub_type:
            keys.append(f"hub:{hub_type}")
    # Tier 2 — every integrated scope/domain namespace.
    for s in integrated_scopes or []:
        if s:
            # Scope values may already be prefixed (e.g. "person:ENT-…") or
            # bare ("self"). Normalize to "scope:<value>".
            if not s.startswith("scope:"):
                keys.append(f"scope:{s}")
            else:
                keys.append(s)
    for d in integrated_domains or []:
        if d:
            keys.append(f"scope:domain:{d}")
    return _dedup(keys)


def emit_for_evidence(
    cited_entity_ids: List[str],
    cited_memory_ids: List[str],
) -> List[str]:
    """Emit dependency keys for an evidence-mode read.

    Tier 1 only: ``entity:<id>`` and ``memory:<id>`` for every cited
    source.  Mirrors ``emit_for_graph_query`` — same policy for evidence
    reads.

    Args:
        cited_entity_ids: Entity IDs returned as evidence items.
        cited_memory_ids: Memory IDs returned as evidence items.

    Returns:
        Deduplicated list of Tier 1 dependency key strings.
    """
    return emit_for_graph_query(cited_entity_ids, cited_memory_ids)


__all__ = [
    "emit_for_hub_read",
    "emit_for_graph_query",
    "emit_for_synthesis",
    "emit_for_evidence",
]
