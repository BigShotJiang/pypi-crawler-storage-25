"""Etag generation + staleness lookup (Phase 2 task 4).

- :func:`generate_etag` wraps :func:`selph_mcp.contracts.envelope.etag_for`
  so tool modules don't have to re-import the recipe.
- :func:`get_staleness_status` looks at ``mcp_etag_invalidations`` for
  rows newer than the consumer's ``etag_cursor`` and reports whether
  the read is ``fresh`` or ``stale``.

All sync Postgres I/O is offloaded via executor so the MCP event loop
stays free (matches the Phase 1b kernel pattern).

Cursor-bump policy
------------------
Reads do NOT bump ``mcp_consumers.etag_cursor`` in Phase 2 — that's a
Phase 3 revocation-handshake concern per the brief. :func:`get_staleness_status`
returns the latest ``seq`` it observed so upstream code (or a future
handshake endpoint) can choose when to persist the advance; this module
never writes to the consumer row itself.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Iterable, List, Literal, Mapping, Optional, Tuple

from selph_mcp._client import get_client
from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import (
    ConsumerScope,
    SensitivityClass,
    etag_for,
)
from selph_mcp.contracts.versions import (
    PERSONA_CONTRACT_VERSION,
    RESPONSE_ENVELOPE_VERSION,
)
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.etag")


# Deterministic fallback used when no source-derived timestamp is
# available. The etag must be deterministic for the same logical request
# regardless of when it runs — wall-clock ``datetime.now()`` is
# explicitly NOT used here (see Fix D).
_EPOCH_FALLBACK: str = "1970-01-01T00:00:00Z"

#: Field names checked by :func:`_derive_content_cutoff` in order of
#: preference. The first non-null value wins for a given record.
_CUTOFF_FIELDS: Tuple[str, ...] = (
    "source_cutoff_at",
    "generated_at",
    "captured_at",
    "last_mentioned_at",
    "invalidated_at",
    "updated_at",
    "created_at",
)


def _coerce_iso(value: Any) -> Optional[str]:
    """Normalize a value to a comparable ISO-8601 string.

    Accepts a :class:`datetime`, date-like string, or ``None``. Returns
    ``None`` when the input cannot be interpreted as a timestamp — the
    caller is expected to skip ``None`` entries when computing ``max``.
    """
    if value is None:
        return None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.isoformat()
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return None
        # Best-effort parse: if it's ISO-8601-ish, round-trip so the
        # fallback comparator behaves. Otherwise return as-is.
        try:
            parsed = datetime.fromisoformat(s.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            return parsed.isoformat()
        except ValueError:
            return s
    return None


def derive_content_cutoff(
    records: Optional[Iterable[Mapping[str, Any]]],
    *,
    fields: Optional[Tuple[str, ...]] = None,
    fallback: str = _EPOCH_FALLBACK,
) -> str:
    """Compute a deterministic content cutoff from a list of records.

    Fix D: etags must be deterministic for the same logical request.
    Previously tool modules were feeding ``datetime.now()`` into
    :func:`generate_etag`, producing a fresh etag on every call and
    breaking the cache-invalidation contract. This helper returns the
    MAX of any timestamp-ish field (``captured_at`` /
    ``last_mentioned_at`` / ``generated_at`` / ``source_cutoff_at`` /
    ``invalidated_at`` / ``updated_at`` / ``created_at``) across the
    supplied records, falling back to ``"1970-01-01T00:00:00Z"`` when no
    records are present so an empty result still has a stable etag.

    Args:
        records: An iterable of dict-like rows. ``None`` or empty →
            ``fallback``.
        fields: Override the default list of timestamp field names.
        fallback: Stable string returned when no timestamps are found.
            Defaults to the Unix epoch.

    Returns:
        An ISO-8601 string or ``fallback``. The return value is safe to
        pass to :func:`generate_etag` as ``content_cutoff_at``.
    """
    lookup = fields or _CUTOFF_FIELDS
    best: Optional[str] = None
    if records is None:
        return fallback

    for rec in records:
        if rec is None:
            continue
        if hasattr(rec, "model_dump"):
            try:
                rec = rec.model_dump()  # type: ignore[assignment]
            except Exception:  # noqa: BLE001
                pass
        if not isinstance(rec, Mapping):
            continue
        for key in lookup:
            value = rec.get(key)
            iso = _coerce_iso(value)
            if iso is None:
                continue
            if best is None or iso > best:
                best = iso
            # keep walking — a record may carry multiple timestamp
            # columns and we want the max across all of them.
    if best is None:
        return fallback
    return best


# Back-compat alias for code that imports the private-style helper.
_derive_content_cutoff = derive_content_cutoff


def generate_etag(
    *,
    kind: str,
    subject: str,
    intent: str,
    user_id: str,
    consumer_scope: ConsumerScope | str,
    sensitivity_class: SensitivityClass | str,
    constraints: Any,
    content_cutoff_at: datetime | str,
    response_envelope_version: int = RESPONSE_ENVELOPE_VERSION,
    persona_contract_version: int = PERSONA_CONTRACT_VERSION,
) -> str:
    """Generate the deterministic etag string for a persona read.

    Thin wrapper around :func:`selph_mcp.contracts.envelope.etag_for` so
    tool modules have one import surface for etag concerns.

    Args:
        kind: Etag kind prefix (e.g. ``"ctx"``, ``"brief"``,
            ``"evidence"``).
        subject: Subject label from :class:`GetContextRequest.subject`.
        intent: Intent label from :class:`GetContextRequest.intent`.
        user_id: The consumer-bound user_id (never the caller-supplied
            user_id — anti-bypass enforcement lives in the kernel).
        consumer_scope: Consumer's scope label; appears in the hash so
            cross-scope cached etags cannot collide.
        sensitivity_class: Effective sensitivity of the returned
            payload.
        constraints: Normalized constraints dict / list / primitive.
            MUST be JSON-safe — bare ``datetime``/``set``/``Enum`` will
            raise ``TypeError`` from the underlying ``json.dumps`` per
            the Phase 1a contract.
        content_cutoff_at: Latest source timestamp included. Accepts a
            datetime or ISO-8601 string.
        response_envelope_version / persona_contract_version: Defaults
            pulled from ``contract_versions.json``.

    Returns:
        ``"{kind}:{subject}:{intent}:{hash12}"``.
    """
    return etag_for(
        kind=kind,
        subject=subject,
        intent=intent,
        user_id=user_id,
        consumer_scope=consumer_scope,
        sensitivity_class=sensitivity_class,
        constraints_normalized=constraints,
        content_cutoff_at=content_cutoff_at,
        response_envelope_version=response_envelope_version,
        persona_contract_version=persona_contract_version,
    )


async def get_staleness_status(
    consumer_id: str,
    user_id: str,
    consumer_cursor: int,
) -> Tuple[Literal["fresh", "stale"], int]:
    """Check the invalidation log for rows newer than ``consumer_cursor``.

    Returns:
        ``("stale", latest_seq)`` when any invalidation row for
        ``user_id`` has ``seq > consumer_cursor``; otherwise
        ``("fresh", current_seq)`` where ``current_seq`` is the latest
        known ``seq`` in the log (``0`` when the table is empty).

    Callers MUST use the returned ``seq`` for the next cursor checkpoint
    rather than re-reading the table — this avoids a race where a new
    row is inserted between the stale check and a subsequent bump.

    This call does NOT write to ``mcp_consumers.etag_cursor``. Phase 2
    reads are side-effect-free on consumer state (cursor bumps happen
    via the Phase 3 handshake endpoint).
    """
    # Validate inputs cheaply so the executor doesn't do it for us.
    if not user_id:
        log_event(
            _log, logging.WARNING, "mcp.persona.etag.staleness.bad_request",
            reason="empty_user_id",
        )
        return "fresh", 0
    if not isinstance(consumer_cursor, int) or consumer_cursor < 0:
        log_event(
            _log, logging.WARNING, "mcp.persona.etag.staleness.bad_cursor",
            user_id=user_id,
            consumer_cursor=consumer_cursor,
        )
        consumer_cursor = 0

    try:
        _raw = await get_client().get(
            "/apps/mcp/invalidations",
            params={"since_cursor": consumer_cursor},
        )
        from selph_mcp.contracts.invalidations import ListInvalidationsResponse as _LIR
        _resp = _LIR.model_validate(_raw)
        rows = _resp.invalidations
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "mcp.persona.etag.staleness.list_since_failed",
            user_id=user_id,
            consumer_cursor=consumer_cursor,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise

    if rows:
        latest_seq = int(max(row.seq for row in rows))
        log_event(
            _log, logging.INFO, "mcp.persona.etag.staleness.stale",
            user_id=user_id,
            consumer_cursor=consumer_cursor,
            latest_seq=latest_seq,
            row_count=len(rows),
        )
        return "stale", latest_seq

    latest = int(_resp.latest_seq)
    log_event(
        _log, logging.DEBUG, "mcp.persona.etag.staleness.fresh",
        user_id=user_id,
        consumer_cursor=consumer_cursor,
        current_seq=latest,
    )
    return "fresh", latest


async def list_invalidations_since(
    consumer_id: str,
    user_id: str,
    since_cursor: int,
) -> list:
    """Return every invalidation row for ``user_id`` newer than
    ``since_cursor``.

    Thin async wrapper around
    :func:`selph_db.mcp_etag_invalidation_log.list_since`. Used by
    ``what_changed`` + the future revocation handshake.
    """
    if not user_id:
        return []
    if not isinstance(since_cursor, int) or since_cursor < 0:
        since_cursor = 0
    try:
        _raw = await get_client().get(
            "/apps/mcp/invalidations",
            params={"since_cursor": since_cursor},
        )
        from selph_mcp.contracts.invalidations import ListInvalidationsResponse as _LIR
        _resp = _LIR.model_validate(_raw)
        return list(_resp.invalidations)
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "mcp.persona.etag.list_invalidations.failed",
            user_id=user_id,
            since_cursor=since_cursor,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise


# ─────────────────────────────────────────────────────────────────────────────
# Etag invalidation emission (Phase 3)
# ─────────────────────────────────────────────────────────────────────────────

# Event kinds recognised by :func:`emit_invalidations`. Each maps to a
# ``(scope_prefix, kind_prefix)`` pair per §Phase 2 task 3 of the
# implementation plan (extended in Phase 3 to cover recommendation
# rejections + drift signals).
#
# * ``l1_utterance_write`` — Layer 1 raw_evidence / utterance INSERT. Bust
#   every self-scoped context etag because new evidence may shift every
#   downstream brief / targeted read for this user.
# * ``memory_correction`` — a correction targeting a memory row. Scope to
#   the affected entity when ``target_id`` is supplied so only per-entity
#   context etags invalidate.
# * ``entity_field_correction`` — same shape as ``memory_correction``;
#   kept as a distinct key for operator readability.
# * ``identity_claim_correction`` — layer-3 claim revisions bust every
#   self-scoped identity etag.
# * ``recommendation_rejection`` — rejection of a workflow recommendation.
#   Scoped per-consumer because recommendations are consumer-local.
# * ``drift_signal`` — informational only. NO invalidation emitted.
EmitEventKind = Literal[
    "l1_utterance_write",
    "memory_correction",
    "entity_field_correction",
    "identity_claim_correction",
    "recommendation_rejection",
    "drift_signal",
]

_VALID_EMIT_KINDS: Tuple[str, ...] = (
    "l1_utterance_write",
    "memory_correction",
    "entity_field_correction",
    "identity_claim_correction",
    "recommendation_rejection",
    "drift_signal",
)


def _invalidation_keys(
    *,
    event_kind: str,
    target_id: Optional[str],
    consumer_id: Optional[str] = None,
) -> List[str]:
    """Compute the Tier 1/Tier 2 dependency vocabulary keys for an event.

    Per §1.4 event → dependency-key mapping table:

    | Event kind                | Keys emitted                                 |
    |---------------------------|----------------------------------------------|
    | l1_utterance_write        | ["scope:self"]                               |
    | memory_correction (id)    | ["memory:<MEM-id>", "scope:self"]            |
    | memory_correction (None)  | ["scope:self"]                               |
    | entity_field_correction   | ["scope:self"]  (observation IDs anchor to   |
    |                           |  user; Tier 1 deferred — see plan §1.4)      |
    | identity_claim_correction | ["scope:self"]                               |
    | recommendation_rejection  | ["consumer:<id>:recommendations"]            |
    | drift_signal              | []  (informational only)                     |
    | unknown                   | []  + WARNING                                |

    No legacy event silently drops to an empty set (spec invariant).
    """
    if event_kind == "l1_utterance_write":
        return ["scope:self"]
    if event_kind == "memory_correction":
        if target_id:
            return [f"memory:{target_id}", "scope:self"]
        return ["scope:self"]
    if event_kind == "entity_field_correction":
        # Observation IDs do not anchor to a single entity in v1 vocabulary.
        # Widened to coarse scope:self per §1.4 rationale (deferred to future
        # entity-fan-out hook on L2 supporting-memory index).
        return ["scope:self"]
    if event_kind == "identity_claim_correction":
        return ["scope:self"]
    if event_kind == "recommendation_rejection":
        cid = consumer_id or ""
        # When consumer_id is empty (e.g. unauthenticated writeback path),
        # fall back to ["scope:self"] — a coarse-but-safe invalidation that
        # will not match any recommendation-specific cache entries but avoids
        # emitting a malformed "consumer::recommendations" key.
        return [f"consumer:{cid}:recommendations"] if cid else ["scope:self"]
    if event_kind == "drift_signal":
        return []
    # Unknown kind — no keys.
    return []


def _invalidation_prefixes(
    *,
    consumer: Consumer,
    event_kind: str,
    target_id: Optional[str],
) -> List[Tuple[str, str]]:
    """Compute the list of ``(scope_prefix, kind_prefix)`` pairs to emit.

    Returns an empty list for ``drift_signal`` (informational only) and
    for unknown event kinds — the caller logs a WARNING in the latter
    case. Using a list (not a single pair) leaves the door open for
    fan-out invalidations in a single call.
    """
    if event_kind == "l1_utterance_write":
        # Per §Phase 2 task 3: also any entity-scoped prefixes inferred
        # from tagged entities. The current observe path does not extract
        # entity tags pre-pipeline, so v1 emits the user-wide pair only;
        # entity-scoped fan-out is deferred to a future hook on the L2
        # extraction completion event (Phases 0–7 callback).
        return [("ctx:self:*", "what_changed:*")]
    if event_kind == "memory_correction":
        # ``target_id`` is a ``MEM-...`` id (per §3.4 row "memory" target).
        # Use kind ``memory:{MEM-id}:*`` so adapters can purge per-memory
        # caches; entity-scoped fan-out (the brief's "all hub prefixes
        # that list that memory as supporting") is deferred to a future
        # hook that walks the supporting-memory index.
        if target_id:
            return [("ctx:person:*", f"memory:{target_id}:*")]
        return [("ctx:person:*", "memory:*")]
    if event_kind == "entity_field_correction":
        # ``target_id`` for entity-field corrections is an
        # ``entity_field_observation`` id (per §3.4 row), not an entity
        # id. Use kind ``observation:{obs-id}:*``.
        if target_id:
            return [("ctx:person:*", f"observation:{target_id}:*")]
        return [("ctx:person:*", "observation:*")]
    if event_kind == "identity_claim_correction":
        return [("ctx:self:*", "identity:*")]
    if event_kind == "recommendation_rejection":
        return [
            (
                f"consumer:{consumer.consumer_id}:recommendations:*",
                "recommendations:*",
            )
        ]
    if event_kind == "drift_signal":
        # Informational only — no invalidation row.
        return []
    # Unknown event kind — caller logs a WARNING, returns empty list.
    return []


async def emit_invalidations(
    consumer: Consumer,
    event_kind: str,
    *,
    target_id: Optional[str] = None,
) -> List[int]:
    """Emit ``mcp_etag_invalidations`` rows for a writeback event (Phase 3).

    Centralises the §Phase 2 task 3 mapping so every writer (kernel
    revise, kernel observe, persona recommendation_feedback) funnels
    through a single code path. Anti-bypass: ``user_id`` is ALWAYS taken
    from ``consumer.user_id`` — never from a caller-supplied value —
    matching the §3.5.1 consumer-to-user binding enforced elsewhere.

    Args:
        consumer: Authenticated consumer (binding source). Both
            ``consumer.user_id`` and ``consumer.consumer_id`` are used
            to scope the emitted prefixes.
        event_kind: One of :data:`_VALID_EMIT_KINDS`. Unknown values log
            a WARNING and return ``[]``.
        target_id: Optional ID that narrows the ``kind_prefix`` for
            entity-scoped events. Ignored by other event kinds.

    Returns:
        A list of newly assigned ``seq`` values (one per emitted row).
        Empty list when the event kind maps to zero prefixes (e.g.
        ``drift_signal``), when the event kind is unknown, or when every
        underlying INSERT failed.

    Non-fatal semantics:
        Invalidation writes are strictly non-blocking for the primary
        writeback. On exception we log a WARNING and return ``[]`` —
        callers MUST NOT roll back their primary write on our failure.
        This keeps Gap 2 raw_evidence writes durable even if the
        invalidation log is temporarily unreachable.
    """
    if event_kind not in _VALID_EMIT_KINDS:
        log_event(
            _log, logging.WARNING, "mcp.persona.etag.emit.unknown_event_kind",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            event_kind=event_kind,
        )
        return []

    prefixes = _invalidation_prefixes(
        consumer=consumer,
        event_kind=event_kind,
        target_id=target_id,
    )

    # Compute the new-style dependency_keys alongside legacy prefixes.
    dep_keys = _invalidation_keys(
        event_kind=event_kind,
        target_id=target_id,
        consumer_id=consumer.consumer_id,
    )

    if not prefixes:
        # ``drift_signal`` lands here on purpose — nothing to emit but
        # we log a DEBUG line so the call is still visible in the
        # trace.
        log_event(
            _log, logging.DEBUG, "mcp.persona.etag.emit.no_prefixes",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            event_kind=event_kind,
            target_id=target_id,
        )
        return []

    # Anti-bypass: ``user_id`` ALWAYS comes from the authenticated
    # consumer row. Never accept a caller-supplied user_id here.
    user_id = consumer.user_id

    emitted: List[int] = []
    for scope_prefix, kind_prefix in prefixes:
        try:
            _raw = await get_client().post(
                "/apps/mcp/invalidations",
                json={
                    "kind": kind_prefix,
                    "scope_prefix": scope_prefix,
                    "reason": f"emit_invalidations:{event_kind}",
                    "dependency_keys": dep_keys if dep_keys else None,
                },
            )
            from selph_mcp.contracts.invalidations import EmitInvalidationResponse as _EIR
            _emit_resp = _EIR.model_validate(_raw)
            seq = _emit_resp.cursor
            emitted.append(seq)
            log_event(
                _log, logging.INFO, "mcp.persona.etag.emit.success",
                consumer_id=consumer.consumer_id,
                user_id=user_id,
                event_kind=event_kind,
                scope_prefix=scope_prefix,
                kind_prefix=kind_prefix,
                seq=seq,
            )
        except Exception as exc:  # noqa: BLE001 — non-fatal by contract
            log_event(
                _log, logging.WARNING, "mcp.persona.etag.emit.failed",
                consumer_id=consumer.consumer_id,
                user_id=user_id,
                event_kind=event_kind,
                scope_prefix=scope_prefix,
                kind_prefix=kind_prefix,
                target_id=target_id,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )
            # Keep going — a single prefix failure should not block the
            # other prefixes in a fan-out mapping.
            continue
    return emitted


__all__ = [
    "derive_content_cutoff",
    "emit_invalidations",
    "generate_etag",
    "get_staleness_status",
    "list_invalidations_since",
    "_invalidation_keys",
]
