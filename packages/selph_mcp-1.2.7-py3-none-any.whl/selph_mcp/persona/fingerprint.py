"""Query fingerprint computation for persona reads (Phase 1 §1.3).

Implements server-side, Selph-computed cache identity for every persona
read tool per ``docs/canonicalization_spec_v1.md``.

Public API
----------
- :func:`canonicalize_params` — shared canonicalization helper.
  Imported by both this module and ``get_fingerprint`` so there is a
  single code path with no "computed two ways" risk.
- :func:`compute_fingerprint` — hashes the canonical (tool, params,
  consumer-scope, user_id, sensitivity_ceiling, envelope_version,
  vocab_version) tuple and returns ``"{tool}:{subject_hint}:{hash12}"``.

Canonicalization rules (per spec v1)
-------------------------------------
1. Parameter keys sorted at every object nesting level.
2. Enum values represented as ``.value`` (not ``.name``).
3. Scope normalized: lowercase, singular (``"communications"`` →
   ``"communication"``).
4. Defaults fold — absent key and key-with-default-value produce the
   same hash.  Callers that wish to fold a default should simply omit
   the key; this function folds ``None`` values and empty strings for
   ``entity_id`` / ``subject`` / ``intent`` per the spec.
5. Pure ``hashlib.sha256`` over UTF-8 canonical JSON (sorted keys,
   no whitespace).

Hash inputs (per §1.3)
-----------------------
``(tool, canonicalized_params, consumer.scope, consumer.user_id,
consumer.sensitivity_ceiling.value, envelope_version, vocab_version)``

**Why sensitivity_ceiling, not post-read effective_sensitivity:**
The fingerprint must be computable BEFORE retrieval so ``get_fingerprint``
can run as a no-DB-read preflight. The post-redaction
``effective_sensitivity`` is not known until after retrieval + redaction.
The ceiling is stable and known at request entry. See §1.3 rationale in
the implementation plan.
"""
from __future__ import annotations

import hashlib
import json
import logging
from typing import Any, Dict

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.versions import (
    DEPENDENCY_VOCABULARY_VERSION,
    RESPONSE_ENVELOPE_VERSION,
)
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.fingerprint")

# Singular form map for scope normalization (§1.3 "lowercase, singular").
_SCOPE_SINGULAR: Dict[str, str] = {
    "communications": "communication",
    "professionals":  "professional",
    "personals":      "personal",
    "behaviorals":    "behavioral",
    "domains":        "domain",
}


def _normalize_scope(scope: str) -> str:
    """Lowercase + singular-normalize a scope string."""
    s = (scope or "").lower().strip()
    return _SCOPE_SINGULAR.get(s, s)


def _sort_recursive(obj: Any) -> Any:
    """Recursively sort all dict keys (spec §1.1 — sorted keys at every level).

    Enums / non-JSON primitives must be resolved by the caller before
    calling this helper. Only ``dict``, ``list``, and leaf primitives
    (``str``, ``int``, ``float``, ``bool``, ``None``) are processed.
    """
    if isinstance(obj, dict):
        return {k: _sort_recursive(v) for k in sorted(obj.keys()) for v in [obj[k]]}
    if isinstance(obj, list):
        return [_sort_recursive(v) for v in obj]
    return obj


def _canonical_json(payload: Any) -> str:
    """Deterministic JSON serialization (sorted keys, no whitespace)."""
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def canonicalize_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """Canonicalize a params dict per canonicalization_spec_v1.

    Rules applied:
    - Enum values: resolved to ``.value`` if they have one.
    - ``None`` and empty-string values for known default-foldable keys
      (``entity_id``) are removed (defaults fold).
    - All dict keys sorted recursively.

    Args:
        params: Raw params dict from the tool call.  May contain Enum
            members; they are coerced to their ``.value`` string.

    Returns:
        A new dict with all keys sorted, enums resolved to values, and
        default-folded keys removed.  Suitable as input to
        ``json.dumps(sort_keys=True)`` for hashing.
    """
    _FOLD_DEFAULTS: Dict[str, Any] = {
        # Keys whose absence and None value are identical for fingerprint
        # purposes (spec §1.1 "defaults fold").
        "entity_id": None,
        "max_age_days": None,
        "time_window": None,
        "memory_types": [],
        "sensitivity": "normal",
    }

    def _coerce(v: Any) -> Any:
        """Recursively coerce enums to .value and normalize containers."""
        if hasattr(v, "value"):
            return v.value
        if isinstance(v, dict):
            return {k: _coerce(val) for k, val in v.items()}
        if isinstance(v, list):
            return [_coerce(i) for i in v]
        return v

    coerced: Dict[str, Any] = {k: _coerce(v) for k, v in params.items()}

    # Fold default values — spec §1.1.
    folded: Dict[str, Any] = {}
    for k, v in coerced.items():
        default = _FOLD_DEFAULTS.get(k, ...)
        if default is ...:
            # Not a foldable key — always include.
            folded[k] = v
        else:
            if v != default:
                folded[k] = v
            # else: absent == default == omit from fingerprint input

    return _sort_recursive(folded)  # type: ignore[return-value]


def compute_fingerprint(
    tool: str,
    params: Dict[str, Any],
    consumer: Consumer,
    *,
    envelope_version: int = RESPONSE_ENVELOPE_VERSION,
    vocab_version: str = str(DEPENDENCY_VOCABULARY_VERSION),
) -> str:
    """Compute the deterministic Selph query fingerprint.

    Hash inputs (§1.3):
        ``(tool, canonicalized_params, consumer.scope, consumer.user_id,
        consumer.sensitivity_ceiling.value, envelope_version,
        vocab_version)``

    Format: ``"{tool}:{subject_hint}:{hash12}"``
    where ``subject_hint`` is the first ``entity_id`` found in ``params``
    (if present) otherwise ``consumer.user_id``.

    Args:
        tool: Persona tool name (e.g. ``"get_context"``).
        params: Raw tool params dict — canonicalization is applied here.
        consumer: Authenticated consumer row (supplies scope, user_id,
            sensitivity_ceiling).
        envelope_version: Active ``response_envelope_version``.  Defaults
            to the current constant so callers don't need to pass it.
        vocab_version: Active ``dependency_vocabulary_version`` string.
            Defaults to the current constant.

    Returns:
        ``"{tool}:{subject_hint}:{hash12}"`` — 12 lowercase hex chars.
    """
    canonical_params = canonicalize_params(params)

    # Primary scope: first allowed scope or "personal" fallback.
    scope_raw = (
        consumer.allowed_scopes[0].value
        if consumer.allowed_scopes
        else "personal"
    )
    scope = _normalize_scope(scope_raw)

    # Sensitivity ceiling: use the consumer's declared ceiling, NOT the
    # post-read effective_sensitivity.  See module docstring §1.3 rationale.
    ceiling = consumer.sensitivity_ceiling.value

    # Subject hint: first entity_id in params if present, else user_id.
    subject_hint: str = params.get("entity_id") or params.get("ref_id") or consumer.user_id

    hash_input = {
        "tool":                            tool,
        "params":                          canonical_params,
        "consumer_scope":                  scope,
        "user_id":                         consumer.user_id,
        "consumer_sensitivity_ceiling":    ceiling,
        "response_envelope_version":       envelope_version,
        "dependency_vocabulary_version":   vocab_version,
    }
    canonical = _canonical_json(hash_input)
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    hash12 = digest[:12]

    fp = f"{tool}:{subject_hint}:{hash12}"

    log_event(
        _log, logging.DEBUG, "persona.fingerprint.computed",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        tool=tool,
        query_fingerprint=fp,
        dependency_vocabulary_version=vocab_version,
    )

    return fp


def normalize_params_for_tool(tool: str, raw_params: dict) -> dict:
    """Per-tool public-arg → fingerprint-input shape.

    Single source of truth for both ``get_fingerprint`` preflight and
    full-call fingerprint computation. Each branch mirrors EXACTLY the
    ``_fp_params`` construction in the corresponding tool body so that
    ``compute_fingerprint(tool, normalize_params_for_tool(tool, wire_args),
    consumer)`` in ``get_fingerprint`` produces the IDENTICAL string the
    full tool stamps in ``meta.query_fingerprint`` for the same wire args.

    Unknown tools fall back to ``dict(raw_params)`` — callers that want
    strict enforcement should check the returned dict independently.

    Args:
        tool: Persona tool name (e.g. ``"get_context"``).
        raw_params: Wire-level args dict as the adapter would send them.

    Returns:
        Normalized params dict suitable as the ``params`` argument to
        :func:`compute_fingerprint`.
    """
    if tool == "get_context":
        # Mirror the _fp_params construction in get_context.py ~line 431.
        # subject/intent are required wire args — no default applied here.
        # depth default = "auto" (Depth.auto.value); sensitivity default = "normal"
        # (Sensitivity.normal.value).  Absent wire args must fold to the same
        # value the full tool resolves, so preflight and full-call hashes match.
        return {
            "subject": raw_params.get("subject"),
            "intent": raw_params.get("intent"),
            "depth": raw_params.get("depth") or "auto",
            "entity_id": raw_params.get("entity_id"),
            "memory_types": sorted(raw_params.get("memory_types") or []),
            "max_age_days": raw_params.get("max_age_days"),
            "sensitivity": raw_params.get("sensitivity") or "normal",
        }
    if tool == "ask_selph":
        return {
            "subject": raw_params.get("subject", "self"),
            "intent": raw_params.get("intent", "strategy"),
            "depth": raw_params.get("depth", "insight"),
            "entity_id": raw_params.get("entity_id"),
            "question": (raw_params.get("question") or "").strip(),
        }
    if tool == "what_changed":
        return {
            "since_cursor": raw_params.get("since_cursor"),
        }
    if tool == "find_evidence":
        ids = raw_params.get("citation_ids") or []
        return {
            "citation_ids": sorted(ids) if ids else [],
            "subject": raw_params.get("subject"),
            "intent": raw_params.get("intent"),
        }
    if tool == "get_entity_card":
        return {"ref_id": raw_params.get("ref_id")}
    if tool == "hire_for_role":
        return {"role": (raw_params.get("role") or "").strip().lower()}
    if tool == "recommend_workflows":
        return {"subject": "self", "intent": "workflow_recommendation"}
    if tool == "observe_session":
        # Wire arg is deep_ingest: bool; tool derives mode via
        # IngestMode.deep_ingest if deep_ingest else IngestMode.store_raw_only.
        # Mirror that derivation so the normalizer and the full call agree.
        deep_ingest = raw_params.get("deep_ingest", False)
        mode = "deep_ingest" if deep_ingest else "store_raw_only"
        return {
            "session_id": raw_params.get("session_id"),
            "mode": mode,
        }
    if tool == "correct":
        # Wire arg is payload: dict (nested); tool extracts action/target_type/
        # target_id via CorrectionPayload(**payload) then stamps .value strings.
        # Mirror that extraction so preflight and full-call hashes match.
        payload = raw_params.get("payload") or {}
        return {
            "action": payload.get("action"),
            "target_type": payload.get("target_type"),
            "target_id": payload.get("target_id"),
        }
    if tool == "recommendation_feedback":
        return {
            "feedback_event_key": (raw_params.get("feedback_event_key") or "").strip(),
            "outcome": raw_params.get("outcome"),
        }
    if tool == "drift_signal":
        return {"etag": (raw_params.get("etag") or "").strip()}
    # Unknown tool — pass through verbatim.
    return dict(raw_params)


__all__ = ["canonicalize_params", "compute_fingerprint", "normalize_params_for_tool"]
