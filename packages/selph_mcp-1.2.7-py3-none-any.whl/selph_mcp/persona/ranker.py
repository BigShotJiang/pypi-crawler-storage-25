"""Deterministic heuristic workflow ranker (Phase 5 §6.2).

Reads 5 hub payloads and 4 memory counts for a consumer, then scores the
three v1 official workflows using per-workflow weighted formulas. No LLM.
No HTTP — every I/O call is synchronous Postgres; the public ``score_workflows``
entry point is async and offloads all sync I/O via executor.

Fail-soft contract
------------------
- Every individual hub read or memory count returns 0 on any exception.
- ``score_workflows`` NEVER raises. A fresh user with zero hubs gets three
  recommendations with low confidence (≥0.3 from the base offset).
- Missing rows → signal value 0.0 → workflow score driven by formula
  intercepts only.

Signal names and saturation formulas
-------------------------------------
Hub confidence comes from the ``selph_hubs.confidence_score`` column
(BaseHub contract — `rules/hubs.md`), NOT from the JSONB payload.
Hub-specific list signals fall back across known payload keys because
each hub type emits its own schema (``recent_change.signals``,
``assistance.common_task_types``, etc.).

``recent_change_strength``    min(len(payload.signals|changes|items|emerging_topics) / 5, 1.0)
``assistance_confidence``     row.confidence_score
``assistance_delegation_cnt`` min(len(payload.common_task_types|items|assistance_preferences) / 10, 1.0)
``learning_confidence``       row.confidence_score
``pursuit_confidence``        row.confidence_score
``project_confidence``        row.confidence_score
``project_memory_cnt``        min(project_memory_count / 5, 1.0)
``task_request_cnt``          min(task_request_memory_count / 10, 1.0)
``goal_memory_cnt``           min(goal_memory_count / 5, 1.0)
``friction_memory_cnt``       min(friction_memory_count / 5, 1.0)

Per-workflow scoring formulas (authoritative v1 weights — see plan
§Phase 5 task 4; mirrored in ``_WORKFLOW_WEIGHTS`` below)
-------------------------------------------------------------------------
morning-operator-brief:
    0.35 * recent_change_strength
  + 0.25 * project_memory_cnt
  + 0.20 * task_request_cnt
  + 0.10 * friction_memory_cnt
  + 0.10 * project_confidence

vip-reply-drafting:
    0.30 * recent_change_strength
  + 0.25 * task_request_cnt
  + 0.20 * assistance_confidence
  + 0.15 * project_memory_cnt
  + 0.10 * pursuit_confidence

weekly-strategy-memo:
    0.30 * pursuit_confidence
  + 0.25 * goal_memory_cnt
  + 0.20 * project_memory_cnt
  + 0.15 * friction_memory_cnt
  + 0.10 * recent_change_strength
"""
from __future__ import annotations

import hashlib
import json
import logging
from typing import Any, Dict, List, Optional

from selph_mcp.contracts.consumer import Consumer
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.ranker")

# ---------------------------------------------------------------------------
# Signal table
# ---------------------------------------------------------------------------

_SIGNAL_NAMES: tuple[str, ...] = (
    "recent_change_strength",
    "assistance_confidence",
    "assistance_delegation_cnt",
    "learning_confidence",
    "pursuit_confidence",
    "project_confidence",
    "project_memory_cnt",
    "task_request_cnt",
    "goal_memory_cnt",
    "friction_memory_cnt",
)

# Human-readable phrase for each signal (for top_reasons)
_SIGNAL_PHRASES: Dict[str, str] = {
    "recent_change_strength": "recent changes detected in your persona graph",
    "assistance_confidence": "strong AI-delegation pattern identified",
    "assistance_delegation_cnt": "multiple AI-delegated tasks recorded",
    "learning_confidence": "active learning patterns on file",
    "pursuit_confidence": "open-ended pursuits defined",
    "project_confidence": "active project portfolio identified",
    "project_memory_cnt": "project memories present",
    "task_request_cnt": "task-request memories present",
    "goal_memory_cnt": "goal memories present",
    "friction_memory_cnt": "friction patterns recorded",
}

# Hub types → missing message. "no signal" covers two cases:
#  (a) the hub row doesn't exist yet, or
#  (b) the hub exists but its signal value is 0 (zero confidence, or
#      the hub-specific list-bearing payload field is empty).
_HUB_MISSING_MESSAGES: Dict[str, str] = {
    "recent_change": "no recent_change signal yet",
    "assistance": "no assistance signal yet",
    "learning_dynamics": "no learning_dynamics signal yet",
    "pursuit": "no pursuit signal yet",
    "project": "no project signal yet",
}

# Memory type → missing message
_MEMORY_MISSING_MESSAGES: Dict[str, str] = {
    "project_memory": "no project_memory records yet",
    "task_request_memory": "no task_request_memory records yet",
    "friction_memory": "no friction_memory records yet",
    "goal_memory": "no goal_memory records yet",
}


# ---------------------------------------------------------------------------
# Per-workflow scoring formulas
# ---------------------------------------------------------------------------

# Each entry: (workflow_id, weights_dict)
# Weights are non-negative floats. Only signals in the dict contribute.
# Authoritative v1 weight table — pinned in Phase 5 of
# `docs/selph_mcp_distribution_implementation_plan.md`. Any change must bump
# the `feedback_event_key` version (`rec:{workflow_id}:v1` → `v2`).
_WORKFLOW_WEIGHTS: List[tuple[str, Dict[str, float]]] = [
    (
        "morning-operator-brief",
        {
            "recent_change_strength": 0.35,
            "project_memory_cnt": 0.25,
            "task_request_cnt": 0.20,
            "friction_memory_cnt": 0.10,
            "project_confidence": 0.10,
        },
    ),
    (
        "vip-reply-drafting",
        {
            "recent_change_strength": 0.30,
            "task_request_cnt": 0.25,
            "assistance_confidence": 0.20,
            "project_memory_cnt": 0.15,
            "pursuit_confidence": 0.10,
        },
    ),
    (
        "weekly-strategy-memo",
        {
            "pursuit_confidence": 0.30,
            "goal_memory_cnt": 0.25,
            "project_memory_cnt": 0.20,
            "friction_memory_cnt": 0.15,
            "recent_change_strength": 0.10,
        },
    ),
]


# ---------------------------------------------------------------------------
# Sync I/O helpers (called via executor from async entry points)
# ---------------------------------------------------------------------------

def _safe_get_hub_row(user_id: str, hub_type: str) -> Optional[Dict[str, Any]]:
    """Stub — hub reads are now batched via the ranker-signals endpoint.

    This function is kept so ``_gather_signals_sync`` still compiles; in
    Slice 2 ``gather_signals`` calls the HTTP endpoint directly and never
    invokes ``_gather_signals_sync``. Returns ``None`` always.
    """
    return None


def _first_list_len(payload: Dict[str, Any], keys: List[str]) -> int:
    """Return the length of the first list-bearing key in ``payload``.

    Hub payloads vary by hub type — ``recent_change`` exposes ``signals``
    while ``assistance`` exposes ``common_task_types``. The ranker probes
    several known keys and uses the first that resolves to a list.
    """
    for key in keys:
        value = payload.get(key)
        if isinstance(value, list):
            return len(value)
    return 0


def _safe_count_memories(user_id: str, memory_types: List[str]) -> Dict[str, int]:
    """Stub — memory counts are now batched via the ranker-signals endpoint.

    This function is kept so ``_gather_signals_sync`` still compiles; in
    Slice 2 ``gather_signals`` calls the HTTP endpoint directly. Returns
    all-zeros always.
    """
    return {mt: 0 for mt in memory_types}


def _compute_signals_from_batch(
    hubs: Dict[str, Any],
    memory_counts: Dict[str, Any],
) -> Dict[str, float]:
    """Reduce a batched ``{hubs, memory_counts}`` response from
    ``GET /apps/mcp/persona/ranker-signals`` into the 10 normalised
    workflow-ranker signal values.

    Pure function — no I/O, no exceptions for missing keys; absent
    fields collapse to 0.0 so callers stay fail-soft.

    Hub confidence reads ``selph_hubs.confidence_score`` (BaseHub
    contract column). Hub list signals fall back across alternate
    payload keys because each hub type emits its own schema.
    """
    def _conf(hub: Any) -> float:
        if not isinstance(hub, dict):
            return 0.0
        raw = hub.get("confidence_score")
        try:
            v = float(raw or 0.0)
        except (TypeError, ValueError):
            v = 0.0
        return max(0.0, min(1.0, v))

    def _payload(hub: Any) -> Dict[str, Any]:
        if not isinstance(hub, dict):
            return {}
        p = hub.get("payload")
        return p if isinstance(p, dict) else {}

    def _count(name: str) -> int:
        try:
            return int(memory_counts.get(name, 0) or 0)
        except (TypeError, ValueError):
            return 0

    recent_count = _first_list_len(
        _payload(hubs.get("recent_change")),
        ["signals", "changes", "items", "emerging_topics"],
    )
    assistance_count = _first_list_len(
        _payload(hubs.get("assistance")),
        ["common_task_types", "items", "assistance_preferences"],
    )

    return {
        "recent_change_strength": min(recent_count / 5, 1.0),
        "assistance_confidence": _conf(hubs.get("assistance")),
        "assistance_delegation_cnt": min(assistance_count / 10, 1.0),
        "learning_confidence": _conf(hubs.get("learning_dynamics")),
        "pursuit_confidence": _conf(hubs.get("pursuit")),
        "project_confidence": _conf(hubs.get("project")),
        "project_memory_cnt": min(_count("project_memory") / 5, 1.0),
        "task_request_cnt": min(_count("task_request_memory") / 10, 1.0),
        "goal_memory_cnt": min(_count("goal_memory") / 5, 1.0),
        "friction_memory_cnt": min(_count("friction_memory") / 5, 1.0),
    }


def _gather_signals_sync(user_id: str) -> Dict[str, float]:
    """Synchronous signal collection — call from executor only.

    Reads 5 hub rows and 4 memory counts and computes the 10
    normalised signal values.  Every read is individually fail-soft;
    missing data → 0.0.

    Hub confidence comes from ``selph_hubs.confidence_score`` (BaseHub
    contract column), not the payload JSONB. Hub-specific list-bearing
    payload fields are probed across known keys because each hub type
    uses its own payload schema.
    """
    # Hub row reads (column-based confidence + payload)
    recent_row = _safe_get_hub_row(user_id, "recent_change") or {}
    assistance_row = _safe_get_hub_row(user_id, "assistance") or {}
    learning_row = _safe_get_hub_row(user_id, "learning_dynamics") or {}
    pursuit_row = _safe_get_hub_row(user_id, "pursuit") or {}
    project_row = _safe_get_hub_row(user_id, "project") or {}

    # Memory counts
    mem_counts = _safe_count_memories(
        user_id,
        ["project_memory", "task_request_memory", "friction_memory", "goal_memory"],
    )

    def _conf(row: Dict[str, Any]) -> float:
        raw = row.get("confidence_score")
        try:
            v = float(raw or 0.0)
        except (TypeError, ValueError):
            v = 0.0
        return max(0.0, min(1.0, v))

    # recent_change_strength: count of change-bearing items in payload.
    # The recent_change hub uses ``signals``; older or alternate builders
    # may use ``changes``, ``items``, or ``emerging_topics``.
    recent_payload = recent_row.get("payload") or {}
    recent_count = _first_list_len(
        recent_payload, ["signals", "changes", "items", "emerging_topics"]
    )
    recent_change_strength = min(recent_count / 5, 1.0)

    assistance_confidence = _conf(assistance_row)
    learning_confidence = _conf(learning_row)
    pursuit_confidence = _conf(pursuit_row)
    project_confidence = _conf(project_row)

    # Delegation count: assistance hub exposes ``common_task_types``;
    # legacy/alternate keys ``items`` and ``assistance_preferences`` are
    # probed as fallbacks.
    assistance_payload = assistance_row.get("payload") or {}
    assistance_count = _first_list_len(
        assistance_payload, ["common_task_types", "items", "assistance_preferences"]
    )
    assistance_delegation_cnt = min(assistance_count / 10, 1.0)

    # Memory count signals (saturate at given denominators)
    project_memory_cnt = min(mem_counts.get("project_memory", 0) / 5, 1.0)
    task_request_cnt = min(mem_counts.get("task_request_memory", 0) / 10, 1.0)
    goal_memory_cnt = min(mem_counts.get("goal_memory", 0) / 5, 1.0)
    friction_memory_cnt = min(mem_counts.get("friction_memory", 0) / 5, 1.0)

    return {
        "recent_change_strength": recent_change_strength,
        "assistance_confidence": assistance_confidence,
        "assistance_delegation_cnt": assistance_delegation_cnt,
        "learning_confidence": learning_confidence,
        "pursuit_confidence": pursuit_confidence,
        "project_confidence": project_confidence,
        "project_memory_cnt": project_memory_cnt,
        "task_request_cnt": task_request_cnt,
        "goal_memory_cnt": goal_memory_cnt,
        "friction_memory_cnt": friction_memory_cnt,
    }


# ---------------------------------------------------------------------------
# Public async entry points
# ---------------------------------------------------------------------------

async def gather_signals(consumer: Consumer) -> Dict[str, float]:
    """Collect the 10 heuristic signals for *consumer* via HTTP.

    Calls ``GET /apps/mcp/persona/ranker-signals?user_id=<user_id>`` on
    the engine, which batches the 5 hub reads and 4 memory counts into a
    single response. Never raises — returns all-zero dict on any
    unhandled exception (fail-soft contract).

    Args:
        consumer: Authenticated consumer (supplies ``user_id`` via binding).

    Returns:
        Dict of signal_name → float ∈ [0, 1].
    """
    from selph_mcp._client import get_client

    user_id = consumer.user_id
    log_event(
        _log, logging.INFO, "mcp.persona.ranker.gather_signals.entry",
        consumer_id=consumer.consumer_id,
        user_id=user_id,
    )
    try:
        data = await get_client().get(
            "/apps/mcp/persona/ranker-signals",
            params={"user_id": user_id},
        )
        # The endpoint returns ``{hubs: {...}, memory_counts: {...}}``;
        # compute the 10 normalised signals from that batch ourselves.
        # (Earlier code assumed a pre-computed ``signals`` field that the
        #  endpoint never emitted — every signal silently coerced to 0.0,
        #  yielding "0 supporting signals" no matter how much data the
        #  user actually had ingested.)
        signals = _compute_signals_from_batch(
            hubs=data.get("hubs") or {},
            memory_counts=data.get("memory_counts") or {},
        )
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "mcp.persona.ranker.gather_signals.failed",
            consumer_id=consumer.consumer_id,
            user_id=user_id,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        # Full fail-soft: return zeroed signals so score_workflows can still
        # return low-confidence recommendations.
        signals = {name: 0.0 for name in _SIGNAL_NAMES}

    log_event(
        _log, logging.INFO, "mcp.persona.ranker.gather_signals.complete",
        consumer_id=consumer.consumer_id,
        user_id=user_id,
        nonzero_signals=sum(1 for v in signals.values() if v > 0),
    )
    return signals


def _score_one(
    workflow_id: str,
    weights: Dict[str, float],
    signals: Dict[str, float],
) -> Dict[str, Any]:
    """Compute a single workflow recommendation entry.

    Returns a dict with:
        workflow_id, score, confidence, top_reasons (<=3),
        supporting_signals, missing_information, feedback_event_key
    """
    # Weighted score
    score = 0.0
    nonzero_weighted_count = 0
    contributions: Dict[str, float] = {}  # signal_name → weighted contribution
    for signal_name, weight in weights.items():
        value = signals.get(signal_name, 0.0)
        contrib = weight * value
        contributions[signal_name] = contrib
        score += contrib
        if value > 0:
            nonzero_weighted_count += 1

    # Confidence: 0.3 base + 0.15 per nonzero weighted signal, capped at 1.0
    confidence = min(1.0, 0.3 + 0.15 * nonzero_weighted_count)

    # top_reasons: signals whose weighted contribution ≥ 10% of total score,
    # sorted by contribution desc, capped at 3.
    top_reasons: List[str] = []
    if score > 0:
        threshold = 0.10 * score
        ranked = sorted(
            [(sn, c) for sn, c in contributions.items() if c >= threshold],
            key=lambda x: x[1],
            reverse=True,
        )
        top_reasons = [
            _SIGNAL_PHRASES.get(sn, sn)
            for sn, _ in ranked[:3]
        ]
    # Fallback: when score is zero, no reasons
    if not top_reasons:
        top_reasons = []

    # supporting_signals: all signals that contributed > 0
    supporting_signals = {
        sn: round(signals.get(sn, 0.0), 4)
        for sn in weights
        if signals.get(sn, 0.0) > 0
    }

    # missing_information: hubs/memory-types that returned 0 for this workflow
    missing_information: List[str] = []
    # Map signal names back to their source
    _signal_to_source: Dict[str, str] = {
        "recent_change_strength": "recent_change",
        "assistance_confidence": "assistance",
        "assistance_delegation_cnt": "assistance",
        "learning_confidence": "learning_dynamics",
        "pursuit_confidence": "pursuit",
        "project_confidence": "project",
        "project_memory_cnt": "project_memory",
        "task_request_cnt": "task_request_memory",
        "goal_memory_cnt": "goal_memory",
        "friction_memory_cnt": "friction_memory",
    }
    seen_missing: set[str] = set()
    for sn in weights:
        if signals.get(sn, 0.0) == 0:
            source = _signal_to_source.get(sn, sn)
            if source not in seen_missing:
                seen_missing.add(source)
                msg = (
                    _HUB_MISSING_MESSAGES.get(source)
                    or _MEMORY_MISSING_MESSAGES.get(source)
                    or f"{source} data not yet available"
                )
                missing_information.append(msg)

    feedback_event_key = f"rec:{workflow_id}:v1"

    return {
        "workflow_id": workflow_id,
        "score": round(score, 4),
        "confidence": round(confidence, 4),
        "top_reasons": top_reasons,
        "supporting_signals": supporting_signals,
        "missing_information": missing_information,
        "feedback_event_key": feedback_event_key,
    }


async def score_workflows(consumer: Consumer) -> List[Dict[str, Any]]:
    """Rank the three official workflows for *consumer*.

    Calls :func:`gather_signals` once, then applies each workflow's weighted
    formula. Returns results sorted by score descending. Never raises — a
    fresh consumer with zero data gets three low-confidence entries.

    Args:
        consumer: Authenticated consumer.

    Returns:
        List of recommendation dicts sorted by ``score`` desc.  Each entry
        has: ``workflow_id``, ``score``, ``confidence``, ``top_reasons``,
        ``supporting_signals``, ``missing_information``,
        ``feedback_event_key``.
    """
    log_event(
        _log, logging.INFO, "mcp.persona.ranker.score_workflows.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
    )
    try:
        signals = await gather_signals(consumer)
        results = [
            _score_one(workflow_id, weights, signals)
            for workflow_id, weights in _WORKFLOW_WEIGHTS
        ]
        results.sort(key=lambda x: x["score"], reverse=True)
    except Exception as exc:  # noqa: BLE001
        # Absolute fail-soft: return minimal zero-scored entries so the MCP
        # tool can always return something to the harness.
        log_event(
            _log, logging.ERROR, "mcp.persona.ranker.score_workflows.failed",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        results = [
            {
                "workflow_id": wid,
                "score": 0.0,
                "confidence": 0.3,
                "top_reasons": [],
                "supporting_signals": {},
                "missing_information": [
                    _HUB_MISSING_MESSAGES.get(h, f"{h} not yet built")
                    for h in ["recent_change", "assistance", "learning_dynamics",
                              "pursuit", "project"]
                ],
                "feedback_event_key": f"rec:{wid}:v1",
            }
            for wid, _ in _WORKFLOW_WEIGHTS
        ]

    log_event(
        _log, logging.INFO, "mcp.persona.ranker.score_workflows.complete",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        top_workflow=(results[0]["workflow_id"] if results else None),
        top_score=(results[0]["score"] if results else 0.0),
    )
    return results


def signals_hash(signals: Dict[str, float]) -> str:
    """Stable 12-hex hash of a signals dict (for etag content_cutoff_at).

    Deterministic: same dict in same order always produces the same hash.
    Returns the epoch fallback string when all signals are zero (or dict empty).
    """
    if not signals or all(v == 0.0 for v in signals.values()):
        return "1970-01-01T00:00:00Z"
    canonical = json.dumps(signals, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode()).hexdigest()[:12]


__all__ = [
    "gather_signals",
    "score_workflows",
    "signals_hash",
]
