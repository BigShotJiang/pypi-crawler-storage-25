"""Response envelope assembly (Phase 2 task 1 / §3.1).

Every persona read tool funnels its final output through
:func:`build_envelope`, which:

  1. Fills the :class:`MetaBlock` from (source_cutoff_at, staleness_status,
     confidence, etag, budget_tier, degraded_from, consumer_scope,
     sensitivity_class) plus the active ``response_envelope_version``
     pulled from ``selph_mcp.contracts.versions``.
  2. Wraps the tool-specific payload in :class:`PersonaResponse[T]`
     alongside typed citations + suggested_next_actions.

The ``consumer`` and ``observed_seq`` kwargs were removed in Phase 6
revision (Codex review finding High 2).  Bumping the etag cursor from
inside ``build_envelope`` was incorrect: ``get_staleness_status`` marks
stale on ANY newer row for the user without prefix-matching against the
request etag, so advancing the cursor from ``build_envelope`` could cause
the adapter to silently miss a future invalidation for a different key.

The cursor advance now lives exclusively in ``what_changed`` — the only
tool that actually delivers the full invalidation set to the adapter.
``what_changed`` bumps the cursor directly via
:func:`selph_db.mcp_consumer_manager.bump_etag_cursor` after confirming
which rows were returned, so the cursor advance is scoped to an
authoritative delivery event.

If you see old call sites still passing ``consumer=`` or
``observed_seq=`` they are silently accepted (kwargs absorbed by
``**_ignored``) and have NO effect — remove them when convenient.

No business logic — the builder does not synthesize, re-rank, or
re-interpret anything. Upstream tool modules are responsible for
producing ``data`` and ``citations``; this builder just stamps meta
and packages the envelope.

Contract deviation — citations list type:
    The Phase 1a ``PersonaResponse.citations`` field is typed
    ``List[Citation]`` with ``extra="forbid"``, but the persona layer
    may emit :class:`RedactedCitation` siblings (distinct pydantic
    model, not a ``Citation`` subclass) for items that exceeded the
    consumer's sensitivity ceiling. Rather than bypass ALL validation
    with ``PersonaResponse.model_construct(...)``, we validate the
    envelope normally via ``PersonaResponse.model_validate(...)``
    WITHOUT the citations field — so ``extra="forbid"`` and every
    other field's type check still fires — and then attach the mixed
    ``List[Union[Citation, RedactedCitation]]`` after the fact via
    ``object.__setattr__``. This is the narrowest possible deviation:
    only the citations list tolerates the sibling type; every other
    field (ok, mode_used, data, meta, suggested_next_actions) stays
    fully validated.
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence, Union

from selph_mcp.contracts.envelope import (
    BudgetTier,
    Citation,
    ConsumerScope,
    MetaBlock,
    ModeUsed,
    PersonaResponse,
    SensitivityClass,
    StalenessStatus,
)
from selph_mcp.contracts.versions import RESPONSE_ENVELOPE_VERSION
from selph_mcp.privacy.redaction import RedactedCitation
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.envelope_builder")

CitationOrRedacted = Union[Citation, RedactedCitation]


def _coerce_enum(value: Any, enum_cls: type) -> Any:
    """Coerce a string / enum value to ``enum_cls`` if necessary.

    Accepts a bare string for ergonomic call sites (e.g. passing
    ``"fresh"`` instead of ``StalenessStatus.fresh``) while still
    returning a strictly-typed enum instance.
    """
    if isinstance(value, enum_cls):
        return value
    return enum_cls(value)


def build_envelope(
    *,
    mode_used: Union[ModeUsed, str],
    data: Any,
    citations: Optional[Sequence[CitationOrRedacted]] = None,
    meta_inputs: Dict[str, Any],
    ok: bool = True,
    suggested_next_actions: Optional[List[str]] = None,
    query_fingerprint: str = "",
    dependency_keys: Optional[List[str]] = None,
) -> PersonaResponse:
    """Assemble a :class:`PersonaResponse` envelope.

    Args:
        mode_used: The retrieval lane that produced ``data``. Accepts a
            :class:`ModeUsed` or bare string (``"brief"``, ``"targeted"``,
            ``"insight"``, ``"evidence"``, or ``"none"`` when budget is
            exhausted). Surface tools that don't fit the Phase 1a enum
            (``"what_changed"``, ``"writeback"``, ``"correction"``) pass
            their value in as a string — the :class:`ModeUsed` enum is
            strict, so callers that need those extended values set
            ``mode_used`` directly on the returned envelope in
            ``suggested_next_actions`` style flows or pass the literal.
        data: Tool-specific payload (dict, list, pydantic model, or
            None when ``ok=False`` — e.g. budget exhausted).
        citations: List of :class:`Citation` or :class:`RedactedCitation`
            produced by the tool. ``None`` → empty list (allowed for
            tools like ``hire_for_role`` that have no underlying evidence
            to cite).
        meta_inputs: Dict of meta fields supplied by the caller. Required
            keys:
              ``source_cutoff_at`` (datetime),
              ``staleness_status`` (``"fresh"|"aging"|"stale"`` or enum),
              ``confidence`` (float 0–1),
              ``etag`` (str),
              ``budget_tier`` (``"cheap"|"standard"|"expensive"|"exhausted"``
              or enum),
              ``consumer_scope`` (``"communication"|...`` or enum),
              ``sensitivity_class`` (``"normal"|"sensitive"|"restricted"``
              or enum).
            Optional keys: ``degraded_from`` (ModeUsed or bare string),
              ``response_envelope_version`` (int, default from
              contract_versions.json).
        ok: Whether the read succeeded. ``False`` signals exhausted
            budget or similar soft failures — ``data`` is typically
            ``None`` in that case.
        suggested_next_actions: Optional hints for the harness.
        **_ignored: Silently absorbs legacy ``consumer=`` and
            ``observed_seq=`` kwargs from call sites that have not yet
            been cleaned up.  These have NO effect — cursor bumping is
            handled exclusively by ``what_changed`` (see module
            docstring).

    Returns:
        A :class:`PersonaResponse` with validated meta.

    Raises:
        pydantic.ValidationError: when ``meta_inputs`` is missing a
            required key or supplies an invalid enum value.
        KeyError: when a required meta key is not supplied.
    """
    # Required meta fields — fail loudly if a tool forgets one rather
    # than silently defaulting.
    required = (
        "source_cutoff_at",
        "staleness_status",
        "confidence",
        "etag",
        "budget_tier",
        "consumer_scope",
        "sensitivity_class",
    )
    missing = [k for k in required if k not in meta_inputs]
    if missing:
        raise KeyError(
            f"build_envelope(meta_inputs=...) missing required keys: {missing}"
        )

    # Phase 1 harness context: fingerprint + dependency_keys.
    # Callers may pass these via meta_inputs (legacy style) or via the
    # dedicated keyword args.  Dedicated kwargs take precedence so the
    # call sites can pass either without breaking existing callers that
    # only supply meta_inputs.
    _fp: str = query_fingerprint or str(meta_inputs.get("query_fingerprint") or "")
    _dep_keys: List[str] = (
        dependency_keys
        if dependency_keys is not None
        else list(meta_inputs.get("dependency_keys") or [])
    )

    _env_version = int(
        meta_inputs.get("response_envelope_version", RESPONSE_ENVELOPE_VERSION)
    )
    # For response_envelope_version >= 2, etag is aliased to
    # query_fingerprint (§1.3 back-compat) when a fingerprint is present.
    _raw_etag = str(meta_inputs["etag"])
    _final_etag = _fp if (_fp and _env_version >= 2) else _raw_etag

    meta = MetaBlock(
        source_cutoff_at=_coerce_dt(meta_inputs["source_cutoff_at"]),
        staleness_status=_coerce_enum(
            meta_inputs["staleness_status"], StalenessStatus
        ),
        confidence=float(meta_inputs["confidence"]),
        etag=_final_etag,
        budget_tier=_coerce_enum(meta_inputs["budget_tier"], BudgetTier),
        degraded_from=(
            _coerce_enum(meta_inputs["degraded_from"], ModeUsed)
            if meta_inputs.get("degraded_from") is not None
            else None
        ),
        consumer_scope=_coerce_enum(meta_inputs["consumer_scope"], ConsumerScope),
        sensitivity_class=_coerce_enum(
            meta_inputs["sensitivity_class"], SensitivityClass
        ),
        response_envelope_version=_env_version,
        query_fingerprint=_fp,
        dependency_keys=_dep_keys,
    )

    mu = _coerce_enum(mode_used, ModeUsed)

    # Build the citations list up-front — mixed ``Citation`` /
    # ``RedactedCitation`` entries are permitted per the module
    # docstring "Contract deviation" note.
    citations_list: List[CitationOrRedacted] = list(citations or [])

    # Validate the envelope WITHOUT citations so every other field
    # still enforces ``extra="forbid"`` + type checks. We pass model
    # instances directly (``meta``, ``mu``) rather than dumping to
    # dicts so their own validation carries through.
    response = PersonaResponse.model_validate(
        {
            "ok": bool(ok),
            "mode_used": mu,
            "data": data,
            "citations": [],
            "suggested_next_actions": list(suggested_next_actions or []),
            "meta": meta,
        }
    )

    # Attach the real (possibly mixed-type) citations list after the
    # fact. ``object.__setattr__`` is needed because pydantic v2
    # BaseModel intercepts regular attribute writes and would re-run
    # validation, which would reject any ``RedactedCitation`` siblings.
    # See the module-level "Contract deviation" docstring for the full
    # rationale.
    object.__setattr__(response, "citations", citations_list)
    return response


def _coerce_dt(value: Any) -> datetime:
    """Accept a :class:`datetime` or ISO-8601 string and return a datetime."""
    if isinstance(value, datetime):
        return value
    return datetime.fromisoformat(str(value))


__all__ = ["build_envelope"]
