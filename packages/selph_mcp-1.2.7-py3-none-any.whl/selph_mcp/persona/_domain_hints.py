"""Server-side mapping from caller-facing free-text ``domain_hint`` to
internal retrieval-scoping signals. Schema-hiding rule (rules/api-surface.md):
the public ``domain_hint`` parameter is free text — this module owns the
one-place mapping to internal taxonomy so no hub_type / memory_type names
ever leak into a caller-facing surface.
"""
from __future__ import annotations
from typing import Dict, Optional

# Maps a hint string to a keyword-rich query-text prefix that fires
# selph_core.query.service._DOMAIN_KEYWORDS. The prefix is concatenated
# in front of the user's question before the kernel sees it, so the
# narrow keyword classifier returns a non-empty domain list and the
# answer pipeline gets a hub anchor instead of falling into the broad
# DEEP-embedding path that surfaces unrelated memories.
#
# Keep prefixes short and packed with classifier-matching keywords.
# Six product-vocabulary buckets per design §4 Phase A vocabulary table.
_DOMAIN_HINT_TO_QUERY_PREFIX: Dict[str, str] = {
    "professional_context": (
        "Focus on identity, goals, priorities, projects, and what kind "
        "of person the user is professionally — values, traits, and "
        "what they care about in their work."
    ),
    "learning_and_active_interests": (
        "Focus on identity, values, what the user cares about, recurring "
        "patterns, and the topics they are actively pursuing or learning."
    ),
    "social_context": (
        "Focus on the user's closest relationships — friends, family, "
        "partner, social circle, and the people who matter most."
    ),
    "daily_routines": (
        "Focus on patterns, recurring tendencies, the user's recent "
        "timeline, and how their behavior has changed over time."
    ),
    "voice_and_creative_context": (
        "Focus on the user's voice — how they talk, write, phrase "
        "messages, the words and tone and style they use."
    ),
    "tools_and_workflow_context": (
        "Focus on identity, goals, priorities, and how the user "
        "approaches their work and the tools they rely on."
    ),
}


def resolve_domain_hint_prefix(hint: Optional[str]) -> Optional[str]:
    """Return the query-text prefix for a hint, or None for unknown/empty.

    Forgiving by design (per ``rules/api-surface.md``): unknown hints
    return ``None`` so the caller falls through to current behavior
    (no scoping). Never raise on unknown values.
    """
    if not hint:
        return None
    return _DOMAIN_HINT_TO_QUERY_PREFIX.get(hint.strip().lower())


__all__ = ["resolve_domain_hint_prefix"]
