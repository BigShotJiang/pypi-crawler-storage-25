"""Budget gate (Phase 2 task 3).

Thin async wrapper over :mod:`selph_db.mcp_consumer_budget_manager`. The
persona layer:

  1. Primes today's budget row via :func:`ensure_today_row` before the
     first decrement of a UTC day.
  2. Calls :func:`check_and_decrement` immediately before dispatching a
     read to the kernel.

All sync Postgres I/O is offloaded via
``asyncio.get_event_loop().run_in_executor(None, ...)`` so the MCP
event loop stays free — matches the Phase 1b kernel pattern.

Re-exports :data:`MODE_COSTS` from the DB module so persona call sites
do not duplicate the figures.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from decimal import Decimal
from typing import Optional, Tuple

from selph_mcp._client import get_client
from selph_mcp._log import get_logger, log_event
from selph_mcp.contracts.budget import BudgetChargeResponse
from selph_mcp.contracts.consumer import BudgetTier as ConsumerBudgetTier, Consumer

# Hardcoded MODE_COSTS so selph_mcp does not import selph_db at all.
# These values mirror selph_db.mcp_consumer_budget_manager.MODE_COSTS.
# Update in lockstep when the DB source changes.
MODE_COSTS: dict = {
    "brief": Decimal("0.2"),
    "targeted": Decimal("1"),
    "insight": Decimal("6"),
    "evidence": Decimal("0.5"),
    "get_fingerprint": Decimal("0.02"),
}


@dataclass
class BudgetRow:
    """Minimal budget row mirroring selph_db.mcp_consumer_budget_manager.BudgetRow."""
    consumer_id: str
    budget_date: str
    budget_tier: str
    credits_allocated: Decimal
    credits_remaining: Decimal

_log = get_logger("selph_mcp.persona.budget")


async def ensure_today_row(
    consumer_id: str,
    user_id: str,
    budget_tier: ConsumerBudgetTier | str,
) -> BudgetRow:
    """Prime today's budget row for ``consumer_id`` (UTC day boundary).

    Calls ``POST /apps/mcp/consumers/{consumer_id}/budget/charge`` with
    ``mode="ensure"`` to UPSERT and return the budget row for today.
    The engine's budget manager handles the UPSERT / fetch-on-conflict.

    Args:
        consumer_id: FK to ``mcp_consumers.consumer_id``.
        user_id: Consumer-bound user_id (anti-bypass enforced upstream).
        budget_tier: Daily tier; accepts a bare string or
            :class:`ConsumerBudgetTier`.

    Returns:
        The primed :class:`BudgetRow`.
    """
    tier_value = (
        budget_tier.value
        if isinstance(budget_tier, ConsumerBudgetTier)
        else str(budget_tier)
    )

    log_event(
        _log, logging.INFO, "mcp.persona.budget.ensure_today.entry",
        consumer_id=consumer_id,
        user_id=user_id,
        budget_tier=tier_value,
    )
    try:
        # The engine ignores caller-supplied user_id / budget_tier and
        # reads both from the authenticated Consumer (anti-bypass). We
        # only send `mode="ensure"`.
        _raw = await get_client().post(
            "/apps/mcp/budget/charge",
            json={"mode": "ensure"},
        )
        _resp = BudgetChargeResponse.model_validate(_raw)
        row = BudgetRow(
            consumer_id=consumer_id,
            budget_date=_resp.budget_date,
            budget_tier=_resp.budget_tier,
            credits_allocated=Decimal(_resp.credits_allocated),
            credits_remaining=Decimal(_resp.credits_remaining),
        )
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "mcp.persona.budget.ensure_today.failed",
            consumer_id=consumer_id,
            user_id=user_id,
            budget_tier=tier_value,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise

    log_event(
        _log, logging.INFO, "mcp.persona.budget.ensure_today.complete",
        consumer_id=consumer_id,
        user_id=user_id,
        budget_tier=tier_value,
        credits_allocated=str(row.credits_allocated),
        credits_remaining=str(row.credits_remaining),
    )
    return row


async def peek_remaining(consumer_id: str) -> Optional[Decimal]:
    """Best-effort snapshot of today's remaining credits.

    Calls ``POST /apps/mcp/consumers/{consumer_id}/budget/charge`` with
    ``mode="ensure"`` — the engine treats this as prime-only (no
    decrement) and returns the row's ``credits_remaining``. Returns
    ``None`` when no value can be parsed from the response.
    """
    try:
        _raw = await get_client().post(
            "/apps/mcp/budget/charge",
            json={"mode": "ensure"},
        )
        _resp = BudgetChargeResponse.model_validate(_raw)
        return Decimal(_resp.credits_remaining)
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "mcp.persona.budget.peek.failed",
            consumer_id=consumer_id,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise


async def check_and_decrement(
    consumer_id: str,
    mode: str,
) -> Tuple[Decimal, bool]:
    """Atomically deduct ``MODE_COSTS[mode]`` from today's budget.

    Calls ``POST /apps/mcp/consumers/{consumer_id}/budget/charge``
    with the ``mode`` so the engine performs the atomic decrement.
    Returns ``(remaining, ok)`` where ``ok=False`` means the deduction
    was refused (cost > remaining OR no row primed).

    Args:
        consumer_id: FK to ``mcp_consumers.consumer_id``.
        mode: ``"brief" | "targeted" | "insight" | "evidence"``. Must be
            a key in :data:`MODE_COSTS` or the call raises
            :class:`ValueError`.

    Returns:
        ``(remaining, ok)`` mirroring the underlying DB contract.

    Raises:
        ValueError: when ``mode`` is not in :data:`MODE_COSTS`.
    """
    cost = MODE_COSTS.get(mode)
    if cost is None:
        log_event(
            _log, logging.WARNING, "mcp.persona.budget.unknown_mode",
            consumer_id=consumer_id,
            mode=mode,
        )
        raise ValueError(f"check_and_decrement: unknown mode {mode!r}")

    log_event(
        _log, logging.INFO, "mcp.persona.budget.decrement.entry",
        consumer_id=consumer_id,
        mode=mode,
        cost=str(cost),
    )
    try:
        _raw = await get_client().post(
            "/apps/mcp/budget/charge",
            json={"mode": mode},
        )
        _resp = BudgetChargeResponse.model_validate(_raw)
        remaining = Decimal(_resp.credits_remaining)
        # ``accepted`` is the canonical field; ``ok`` is its alias — both
        # are always present in BudgetChargeResponse. Prefer ``accepted``
        # per the wheel contract (BudgetChargeResponse docstring).
        ok = _resp.accepted
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "mcp.persona.budget.decrement.failed",
            consumer_id=consumer_id,
            mode=mode,
            cost=str(cost),
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise

    log_event(
        _log, logging.INFO, "mcp.persona.budget.decrement.complete",
        consumer_id=consumer_id,
        mode=mode,
        cost=str(cost),
        remaining=str(remaining),
        accepted=ok,
    )
    return remaining, ok


async def ensure_and_decrement(
    consumer: Consumer,
    mode: str,
) -> Tuple[Decimal, bool]:
    """Convenience: prime today's row (if missing) then attempt a decrement.

    Primes the row on the first call of a UTC day so the subsequent
    :func:`check_and_decrement` finds one to lock. Returns the
    ``(remaining, ok)`` tuple from the underlying decrement.
    """
    await ensure_today_row(
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        budget_tier=consumer.budget_tier,
    )
    return await check_and_decrement(consumer.consumer_id, mode)


__all__ = [
    "MODE_COSTS",
    "BudgetRow",
    "ensure_today_row",
    "check_and_decrement",
    "ensure_and_decrement",
    "peek_remaining",
]
