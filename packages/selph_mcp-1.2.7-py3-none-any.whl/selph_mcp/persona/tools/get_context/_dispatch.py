"""Per-mode kernel dispatch helpers.

Each dispatcher produces a uniform result dict::

    {
        "data":             <mode-specific payload>,
        "citations":        list[Citation],
        "source_cutoff_at": str,             # derived from record timestamps
        "confidence":       float,
        "mode_executed":    Optional[str],   # only on query-backed modes
        "mode_requested":   Optional[str],
        "insight_degraded_reason": Optional[str],
    }

The orchestrator in :mod:`_entry` does not care which kernel adapter
produced the result — only the surface shape above is contract.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.read import GetContextRequest
from selph_mcp.kernel import project as kernel_project
from selph_mcp.kernel import query as kernel_query
from selph_mcp.persona import etag as _etag

from selph_mcp.persona.tools.get_context._citations import (
    _citations_from_hub_payload,
    _citations_from_kernel_records,
)
from selph_mcp.persona.tools.get_context._helpers import (
    _SUBJECT_TO_HUB_MAP,
    _compose_query_text,
    _safe_float,
)


async def _dispatch_brief(
    request: GetContextRequest,
    consumer: Consumer,
    graph: Any,
) -> Dict[str, Any]:
    """Brief mode: single hub payload read keyed on subject.

    We map ``Subject`` → hub_type via :data:`_SUBJECT_TO_HUB_MAP`.
    Subjects that have no direct hub (e.g. ``topic``) fall back to
    ``current_identity`` so the caller still gets a response envelope
    rather than a 400. The mapping is intentionally not a 1:1 contract
    — it's a brief-mode heuristic documented in-line.
    """
    hub_type = _SUBJECT_TO_HUB_MAP.get(request.subject.value, "current_identity")
    result = await kernel_project.project(
        consumer=consumer,
        hub_type=hub_type,
        user_id=consumer.user_id,
    )
    payload = result.get("payload")
    citations = _citations_from_hub_payload(hub_type, payload)
    return {
        "data": payload or {},
        "citations": citations,
        "hub_type": hub_type,
        # Fix D: source_cutoff_at is derived from the hub payload's own
        # timestamps (source_cutoff_at / generated_at) rather than
        # wall-clock ``now()``. Empty payload falls back to the Unix
        # epoch via :func:`_etag.derive_content_cutoff` so an empty
        # result still has a deterministic etag.
        "source_cutoff_at": _etag.derive_content_cutoff(
            [payload] if payload else None
        ),
        "confidence": _safe_float(
            (payload or {}).get("confidence_score")
        ) or 0.7,
    }


async def _dispatch_targeted(
    request: GetContextRequest,
    consumer: Consumer,
    graph: Any,
    chroma: Any,
    question_override: Optional[str] = None,
    domain_hint_prefix: Optional[str] = None,
) -> Dict[str, Any]:
    query_text = _compose_query_text(request, question_override, domain_hint_prefix=domain_hint_prefix)
    result = await kernel_query.query(
        consumer=consumer,
        query_text=query_text,
        graph=graph,
        chroma=chroma,
        user_id=consumer.user_id,
        mode="targeted",
    )
    records = result.get("data") or []
    citations = _citations_from_kernel_records(records)
    return {
        "data": {"records": records, "timing_ms": result.get("timing_ms")},
        "citations": citations,
        # Fix D: cutoff derived from the records' own timestamps, not
        # wall clock. Empty result → epoch fallback (deterministic).
        "source_cutoff_at": _etag.derive_content_cutoff(records),
        "confidence": 0.6,
        # Fix C2: surface the kernel's actually-executed mode so the
        # caller can detect insight → targeted silent degrades. The
        # kernel returns ``mode_executed`` as a stable alias of ``mode``.
        "mode_executed": result.get("mode_executed") or result.get("mode"),
        "mode_requested": result.get("mode_requested"),
        "insight_degraded_reason": result.get("insight_degraded_reason"),
        # Propagate kernel-level failure so the entry orchestrator can
        # surface ok=False instead of an empty success envelope.
        "kernel_status": result.get("status"),
        "kernel_error_message": result.get("error_message"),
    }


async def _dispatch_insight(
    request: GetContextRequest,
    consumer: Consumer,
    graph: Any,
    chroma: Any,
    synthesizer: Any,
    self_entity_id: Optional[str],
    question_override: Optional[str] = None,
    domain_hint_prefix: Optional[str] = None,
) -> Dict[str, Any]:
    query_text = _compose_query_text(request, question_override, domain_hint_prefix=domain_hint_prefix)
    result = await kernel_query.query(
        consumer=consumer,
        query_text=query_text,
        graph=graph,
        chroma=chroma,
        user_id=consumer.user_id,
        mode="insight",
        synthesizer=synthesizer,
        self_entity_id=self_entity_id,
    )
    records = result.get("data") or []
    citations = _citations_from_kernel_records(records)
    insight = result.get("insight") or {}
    return {
        "data": {
            "records": records,
            "insight": insight,
            "executed_mode": result.get("mode"),
            "timing_ms": result.get("timing_ms"),
        },
        "citations": citations,
        # Fix D: cutoff from records (insight is synthesized from the
        # same evidence bundles). Empty → epoch fallback.
        "source_cutoff_at": _etag.derive_content_cutoff(records),
        "confidence": 0.7,
        "mode_executed": result.get("mode_executed") or result.get("mode"),
        "mode_requested": result.get("mode_requested"),
        "insight_degraded_reason": result.get("insight_degraded_reason"),
        # Propagate kernel-level failure so the entry orchestrator can
        # surface ok=False instead of an empty success envelope.
        "kernel_status": result.get("status"),
        "kernel_error_message": result.get("error_message"),
    }
