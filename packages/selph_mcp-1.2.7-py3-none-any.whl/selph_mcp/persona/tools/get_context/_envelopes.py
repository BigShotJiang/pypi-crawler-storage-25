"""Short-circuit envelope builders.

Used when the orchestrator must return early without dispatching to a
kernel adapter:

  - :func:`_exhausted_envelope`  — daily budget exhausted (no decrement)
  - :func:`_rejected_envelope`   — sensitivity ceiling exceeded with
                                    ``reject_on_ceiling=True``
  - :func:`_error_envelope`      — kernel adapter raised; surface as
                                    ``ok=False`` with redacted message
"""

from __future__ import annotations

from typing import Any

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import (
    BudgetTier,
    ConsumerScope,
    ModeUsed,
    PersonaResponse,
)
from selph_mcp.contracts.read import GetContextRequest
from selph_mcp.persona import etag as _etag
from selph_mcp.persona.envelope_builder import build_envelope

from selph_mcp.persona.tools.get_context._helpers import _normalize_constraints


def _exhausted_envelope(
    *,
    request: GetContextRequest,
    consumer: Consumer,
    chosen_mode: str,
    scope: ConsumerScope,
    query_fingerprint: str = "",
) -> PersonaResponse:
    # Fix D: deterministic cutoff for the exhausted short-circuit — no
    # records were returned, so use the epoch fallback so repeated
    # exhausted calls hash to the same etag.
    source_cutoff_at = "1970-01-01T00:00:00Z"
    constraints_norm = _normalize_constraints(request)
    etag = _etag.generate_etag(
        kind="exhausted",
        subject=request.subject.value,
        intent=request.intent.value,
        user_id=consumer.user_id,
        consumer_scope=scope,
        sensitivity_class=consumer.sensitivity_ceiling.value,
        constraints=constraints_norm,
        content_cutoff_at=source_cutoff_at,
    )
    return build_envelope(
        mode_used=ModeUsed.none,
        ok=False,
        data=None,
        citations=[],
        meta_inputs={
            "source_cutoff_at": source_cutoff_at,
            "staleness_status": "fresh",
            "confidence": 0.0,
            "etag": etag,
            "budget_tier": BudgetTier.exhausted.value,
            "degraded_from": chosen_mode,
            "consumer_scope": scope,
            "sensitivity_class": consumer.sensitivity_ceiling.value,
        },
        suggested_next_actions=[
            "Wait for daily UTC rollover or request a higher budget_tier."
        ],
        query_fingerprint=query_fingerprint,
        dependency_keys=[],
    )


def _rejected_envelope(
    *,
    request: GetContextRequest,
    consumer: Consumer,
    final_mode: str,
    chosen_mode: str,
    scope: ConsumerScope,
    decr_remaining: Any,
    ceiling: str,
    actual: str,
    query_fingerprint: str = "",
) -> PersonaResponse:
    # Fix D: deterministic — the reject path does not include record
    # timestamps in its output, so seed from the epoch fallback.
    source_cutoff_at = "1970-01-01T00:00:00Z"
    constraints_norm = _normalize_constraints(request)
    etag = _etag.generate_etag(
        kind="rejected",
        subject=request.subject.value,
        intent=request.intent.value,
        user_id=consumer.user_id,
        consumer_scope=scope,
        sensitivity_class=ceiling,
        constraints=constraints_norm,
        content_cutoff_at=source_cutoff_at,
    )
    return build_envelope(
        mode_used=final_mode,
        ok=False,
        data={"error": "sensitivity_ceiling_exceeded", "actual": actual},
        citations=[],
        meta_inputs={
            "source_cutoff_at": source_cutoff_at,
            "staleness_status": "fresh",
            "confidence": 0.0,
            "etag": etag,
            "budget_tier": consumer.budget_tier.value,
            "degraded_from": chosen_mode if chosen_mode != final_mode else None,
            "consumer_scope": scope,
            "sensitivity_class": ceiling,
        },
        query_fingerprint=query_fingerprint,
        dependency_keys=[],
    )


def _error_envelope(
    *,
    request: GetContextRequest,
    consumer: Consumer,
    chosen_mode: str,
    final_mode: str,
    scope: ConsumerScope,
    decr_remaining: Any,
    error: str,
    query_fingerprint: str = "",
) -> PersonaResponse:
    # Fix D: deterministic — error path has no content, epoch fallback.
    source_cutoff_at = "1970-01-01T00:00:00Z"
    constraints_norm = _normalize_constraints(request)
    etag = _etag.generate_etag(
        kind="error",
        subject=request.subject.value,
        intent=request.intent.value,
        user_id=consumer.user_id,
        consumer_scope=scope,
        sensitivity_class=consumer.sensitivity_ceiling.value,
        constraints=constraints_norm,
        content_cutoff_at=source_cutoff_at,
    )
    return build_envelope(
        mode_used=final_mode,
        ok=False,
        data={"error": error},
        citations=[],
        meta_inputs={
            "source_cutoff_at": source_cutoff_at,
            "staleness_status": "fresh",
            "confidence": 0.0,
            "etag": etag,
            "budget_tier": consumer.budget_tier.value,
            "degraded_from": chosen_mode if chosen_mode != final_mode else None,
            "consumer_scope": scope,
            "sensitivity_class": consumer.sensitivity_ceiling.value,
        },
        query_fingerprint=query_fingerprint,
        dependency_keys=[],
    )
