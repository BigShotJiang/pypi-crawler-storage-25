"""Persona ``get_context`` tool — depth-aware read entry point.

Flow per §Phase 2 task 7 of
``docs/selph_mcp_distribution_implementation_plan.md``:

  1. Validate request.
  2. Run the deterministic depth router.
  3. Prime today's budget row and attempt a decrement (post-route
     degradation may step the chosen mode down).
  4. Dispatch to the appropriate kernel adapter:
       - ``brief``    → :func:`selph_mcp.kernel.project.project`
       - ``targeted`` → :func:`selph_mcp.kernel.query.query`
       - ``insight``  → :func:`selph_mcp.kernel.query.query(mode="insight")`
       - ``evidence`` → hand off to :mod:`find_evidence` (forced mode)
  5. Derive sensitivity across citations, enforce the consumer's
     ceiling (reject OR redact per caller policy — default redact).
  6. Generate the etag + check staleness.
  7. Package via :func:`selph_mcp.persona.envelope_builder.build_envelope`.

Every entry / exit / exception logs ``trace_id``, ``user_id``,
``consumer_id``, and the chosen mode per the mandatory logging coverage
rule in ``rules/naming-and-constraints.md``.

This module was split out of a single 913-line ``get_context.py`` per the
code-structure rule (surface routes <=400 soft / 600 hard).  The public
API is preserved verbatim; sub-modules carry the implementation.
"""

from __future__ import annotations

from selph_mcp.persona.tools.get_context._entry import get_context


__all__ = ["get_context"]
