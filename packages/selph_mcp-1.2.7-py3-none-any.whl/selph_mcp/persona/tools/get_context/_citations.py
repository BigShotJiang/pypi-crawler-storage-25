"""Best-effort citation extraction from kernel-side payloads.

The ``query_to_answer_v2`` path returns raw Neo4j anchor records
(mixed ``anchor_type=memory|entity`` rows). Hub reads return a payload
dict with a ``hub_id`` and ``supporting_memory_ids``. We translate both
shapes into the typed :class:`Citation` model used by the persona
envelope. Rows we cannot classify are silently skipped — citations are
best-effort evidence chips, not a full provenance ledger.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from selph_mcp.contracts.envelope import Citation, RefType

from selph_mcp.persona.tools.get_context._helpers import _safe_float


def _citations_from_kernel_records(records: List[Dict[str, Any]]) -> List[Citation]:
    """Best-effort typed citation extraction from targeted-query records."""
    out: List[Citation] = []
    for rec in records or []:
        atype = (rec.get("anchor_type") or "").lower()
        if atype == "memory":
            ref_id = rec.get("memory_id") or rec.get("anchor_id")
            mtype = rec.get("memory_type")
            if ref_id and mtype:
                try:
                    out.append(
                        Citation(
                            ref_type=RefType.memory,
                            ref_id=str(ref_id),
                            layer=2,
                            memory_type=str(mtype),
                        )
                    )
                except Exception:  # noqa: BLE001 — skip malformed rows
                    continue
        elif atype == "entity":
            ref_id = rec.get("entity_id") or rec.get("anchor_id")
            if ref_id:
                try:
                    out.append(
                        Citation(
                            ref_type=RefType.entity,
                            ref_id=str(ref_id),
                            layer=2,
                        )
                    )
                except Exception:  # noqa: BLE001
                    continue
    return out


def _citations_from_hub_payload(
    hub_type: str, payload: Optional[Dict[str, Any]]
) -> List[Citation]:
    """Emit one hub citation + any supporting_memory_ids citations."""
    out: List[Citation] = []
    if payload is None:
        return out
    hub_id = payload.get("hub_id") or f"HUB-{(hub_type or 'unknown').upper()[:8]}"
    try:
        out.append(
            Citation(
                ref_type=RefType.hub,
                ref_id=str(hub_id),
                layer=4,
                hub_type=str(hub_type),
                confidence=_safe_float(payload.get("confidence_score")),
            )
        )
    except Exception:  # noqa: BLE001
        pass
    for mid in (payload.get("supporting_memory_ids") or [])[:25]:
        try:
            out.append(
                Citation(
                    ref_type=RefType.memory,
                    ref_id=str(mid),
                    layer=2,
                    memory_type=str(payload.get("memory_type_hint") or "unknown"),
                )
            )
        except Exception:  # noqa: BLE001
            continue
    return out
