"""Public entry point: ``get_context``.

Sequences the depth router → budget gate → kernel dispatch → sensitivity
filter → etag/dep-keys → envelope build. All branch-specific work
(citation extraction, per-mode dispatch, short-circuit envelopes) is
delegated to sibling modules so this file stays a control-flow file.
"""

from __future__ import annotations

import logging
import time as _time
from typing import Any, Dict, List, Optional

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import Citation, PersonaResponse
from selph_mcp.contracts.read import GetContextRequest
from selph_mcp.persona import budget as _budget
from selph_mcp.persona import etag as _etag
from selph_mcp.persona.dependency_keys import (
    emit_for_graph_query,
    emit_for_hub_read,
    emit_for_synthesis,
)
from selph_mcp.persona.envelope_builder import build_envelope
from selph_mcp.persona.fingerprint import compute_fingerprint
from selph_mcp.persona.router import (
    degrade_if_budget_insufficient,
    route_depth,
)
from selph_mcp.privacy.redaction import redact_citations
from selph_mcp.privacy.scopes import derive_sensitivity_batch, enforce_ceiling
from selph_mcp._log import get_logger, log_event

from selph_mcp.persona.tools.get_context._dispatch import (
    _dispatch_brief,
    _dispatch_insight,
    _dispatch_targeted,
)
from selph_mcp.persona.tools.get_context._envelopes import (
    _error_envelope,
    _exhausted_envelope,
    _rejected_envelope,
)
from selph_mcp.persona.tools.get_context._helpers import (
    _SUBJECT_TO_HUB_MAP,
    _normalize_constraints,
    _primary_scope,
)


_log = get_logger("selph_mcp.persona.tools.get_context")


async def get_context(
    request: GetContextRequest,
    consumer: Consumer,
    *,
    graph: Any = None,
    chroma: Any = None,
    synthesizer: Any = None,
    self_entity_id: Optional[str] = None,
    reject_on_ceiling: bool = False,
    _question_override: Optional[str] = None,
    _domain_hint_prefix_override: Optional[str] = None,
) -> PersonaResponse:
    """Handle a persona ``get_context`` call.

    Args:
        request: Validated :class:`GetContextRequest`.
        consumer: The authenticated consumer (supplies ``user_id`` via
            the Phase 1b anti-bypass binding).
        graph: Neo4j handle from the MCP lifespan.
        chroma: Chroma handle from the MCP lifespan.
        synthesizer: Optional async callable injected by the host
            lifespan for insight-mode synthesis. ``None`` → insight
            mode degrades to targeted with an ``insight_disabled``
            marker (see ``selph_mcp.kernel.query``).
        self_entity_id: Optional self-entity id passed through to the
            synthesizer when ``mode == "insight"``.
        reject_on_ceiling: When ``True`` the call returns
            ``ok=False, data=None`` if any citation exceeds the
            consumer's sensitivity_ceiling. Default ``False`` =
            redact per-citation via :func:`redact_citations` and still
            return a usable envelope.
        _question_override: Private keyword used by :func:`ask_selph`
            to pass the raw NL question through to the kernel query
            text composer without abusing ``Constraints.memory_types``.
            When set, :func:`_compose_query_text` uses this string
            verbatim instead of synthesizing one from constraints.
        _domain_hint_prefix_override: Private keyword used by
            :func:`ask_selph` to pass the resolved domain-hint prefix
            (from :func:`selph_mcp.persona._domain_hints.resolve_domain_hint_prefix`)
            to the query text composer. Prepended before the question
            (or the synthesized fallback) so the kernel classifier gets
            classifier-matching keywords. ``None`` → no scoping change.

    Returns:
        A :class:`PersonaResponse` envelope.
    """
    t0 = _time.perf_counter()
    log_event(
        _log, logging.INFO, "mcp.persona.get_context.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        subject=request.subject.value,
        intent=request.intent.value,
        depth=request.depth.value,
    )

    # ── Depth router ─────────────────────────────────────────────────
    chosen_mode = route_depth(request, consumer)

    # ── Phase 1 §1.3: compute fingerprint BEFORE retrieval ───────────
    _fp_params: Dict[str, Any] = {
        "subject": request.subject.value,
        "intent": request.intent.value,
        "depth": request.depth.value,
        "entity_id": request.constraints.entity_id,
        "memory_types": sorted(request.constraints.memory_types or []),
        "max_age_days": request.constraints.max_age_days,
        "sensitivity": request.constraints.sensitivity.value,
    }
    _fp = compute_fingerprint(
        tool="get_context",
        params=_fp_params,
        consumer=consumer,
    )

    # ── Budget gate ──────────────────────────────────────────────────
    # Fix: ``ensure_today_row`` already returns a fully populated
    # :class:`BudgetRow` (``credits_allocated`` + ``credits_remaining``).
    # We use that directly instead of a follow-up ``peek_remaining`` call
    # and we no longer reach into the private ``_DAILY_ALLOCATIONS``
    # mapping — the row is the single source of truth.
    row = await _budget.ensure_today_row(
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        budget_tier=consumer.budget_tier,
    )
    remaining = row.credits_remaining

    final_mode, degraded_from = degrade_if_budget_insufficient(
        chosen_mode, remaining
    )

    scope = _primary_scope(consumer)
    ceiling = consumer.sensitivity_ceiling.value  # str

    if final_mode is None:
        # Exhausted — return envelope with ok=False, no decrement.
        exhausted = _exhausted_envelope(
            request=request,
            consumer=consumer,
            chosen_mode=chosen_mode,
            scope=scope,
            query_fingerprint=_fp,
        )
        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.WARNING, "mcp.persona.get_context.exhausted",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            chosen_mode=chosen_mode,
            remaining=str(remaining),
            duration_ms=duration_ms,
        )
        return exhausted

    # ── Evidence-lane handoff (pre-decrement) ─────────────────────────
    # Fix 1: when the router resolves to ``evidence`` mode, delegate to
    # :func:`find_evidence` BEFORE charging the budget here.
    # ``find_evidence`` owns the single ``ensure_today_row +
    # check_and_decrement`` call for the evidence cost — charging again
    # in ``get_context`` would double-bill the consumer.
    if final_mode == "evidence":
        from selph_mcp.persona.tools import find_evidence as _fe_mod

        fe_envelope = await _fe_mod.find_evidence(
            consumer=consumer,
            citation_ids=None,
            subject=request.subject.value,
            intent=request.intent.value,
            graph=graph,
            chroma=chroma,
        )
        # Overwrite the inner find_evidence fingerprint + etag with the
        # get_context-shape fingerprint so get_fingerprint(tool="get_context")
        # matches this envelope (Finding 2a).  _fp was computed pre-retrieval
        # from the get_context wire args above.
        fe_envelope.meta.query_fingerprint = _fp
        fe_envelope.meta.etag = _fp
        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.INFO, "mcp.persona.get_context.evidence_delegated",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            chosen_mode=chosen_mode,
            final_mode=final_mode,
            query_fingerprint=_fp,
            duration_ms=duration_ms,
        )
        return fe_envelope

    decr_remaining, decr_ok = await _budget.check_and_decrement(
        consumer.consumer_id, final_mode
    )
    if not decr_ok:
        # Race: peek saw enough credits but try_decrement lost them.
        exhausted = _exhausted_envelope(
            request=request,
            consumer=consumer,
            chosen_mode=chosen_mode,
            scope=scope,
            query_fingerprint=_fp,
        )
        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.WARNING, "mcp.persona.get_context.decrement_refused",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            chosen_mode=chosen_mode,
            final_mode=final_mode,
            duration_ms=duration_ms,
        )
        return exhausted

    # ── Dispatch to the appropriate kernel adapter ────────────────────
    # Note: ``final_mode == "evidence"`` is handled earlier (pre-decrement
    # delegation to :func:`find_evidence`) and never reaches this block.
    try:
        if final_mode == "brief":
            result = await _dispatch_brief(request, consumer, graph)
        elif final_mode == "targeted":
            result = await _dispatch_targeted(
                request, consumer, graph, chroma,
                question_override=_question_override,
                domain_hint_prefix=_domain_hint_prefix_override,
            )
        elif final_mode == "insight":
            result = await _dispatch_insight(
                request, consumer, graph, chroma, synthesizer, self_entity_id,
                question_override=_question_override,
                domain_hint_prefix=_domain_hint_prefix_override,
            )
        else:
            raise ValueError(f"Unknown final_mode: {final_mode!r}")
    except Exception as exc:  # noqa: BLE001 — surface as ok=False envelope
        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.ERROR, "mcp.persona.get_context.kernel_error",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            chosen_mode=chosen_mode,
            final_mode=final_mode,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
            duration_ms=duration_ms,
        )
        return _error_envelope(
            request=request,
            consumer=consumer,
            chosen_mode=chosen_mode,
            final_mode=final_mode,
            scope=scope,
            decr_remaining=decr_remaining,
            error=str(exc)[:200],
            query_fingerprint=_fp,
        )

    # ── Kernel-level failure short-circuit ────────────────────────────
    # ``kernel_query.query`` swallows transport / engine errors and
    # returns ``status="error"`` with empty data instead of raising.
    # Without this check the dispatcher result falls through to envelope
    # assembly and ships ``ok=True`` with zero records — misleading the
    # caller into thinking the read succeeded. Surface as ``ok=False``
    # via the same error envelope used for the exception path above.
    if result.get("kernel_status") == "error":
        kernel_err = result.get("kernel_error_message") or "kernel returned status=error"
        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.ERROR, "mcp.persona.get_context.kernel_status_error",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            chosen_mode=chosen_mode,
            final_mode=final_mode,
            kernel_executed=result.get("mode_executed"),
            insight_degraded_reason=result.get("insight_degraded_reason"),
            error=str(kernel_err)[:300],
            duration_ms=duration_ms,
        )
        return _error_envelope(
            request=request,
            consumer=consumer,
            chosen_mode=chosen_mode,
            final_mode=final_mode,
            scope=scope,
            decr_remaining=decr_remaining,
            error=str(kernel_err)[:200],
            query_fingerprint=_fp,
        )

    # ── Sensitivity + redaction ───────────────────────────────────────
    citations: List[Citation] = list(result.get("citations") or [])
    batch_sensitivity = derive_sensitivity_batch(citations)
    ceiling_ok = enforce_ceiling(ceiling, batch_sensitivity)

    if reject_on_ceiling and not ceiling_ok:
        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.WARNING, "mcp.persona.get_context.ceiling_rejected",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            ceiling=ceiling,
            actual=batch_sensitivity,
            duration_ms=duration_ms,
        )
        return _rejected_envelope(
            request=request,
            consumer=consumer,
            final_mode=final_mode,
            chosen_mode=chosen_mode,
            scope=scope,
            decr_remaining=decr_remaining,
            ceiling=ceiling,
            actual=batch_sensitivity,
            query_fingerprint=_fp,
        )

    # Redaction path: keep citation IDs but strip payloads beyond the
    # ceiling. The reported ``sensitivity_class`` is the MAX of what
    # survived the redaction — after redaction the caller effectively
    # sees only citation IDs for the sensitive rows, so we clamp to
    # the consumer's ceiling.
    final_citations = redact_citations(citations, ceiling)
    effective_sensitivity = (
        batch_sensitivity if ceiling_ok else ceiling
    )

    # Fix A (CRITICAL): when ``reject_on_ceiling=False`` (the default)
    # the pre-fix code only redacted CITATIONS while still returning the
    # full ``data`` payload (hub payload content, query records, insight
    # output). §Phase 2 task 5 requires reads that return citations to
    # also filter *payloads* against the ceiling. Replace ``data`` with
    # a status marker while keeping citations redacted (ID + layer +
    # type only). ``ok=True`` stays — the request was valid, the
    # content was scoped out.
    final_data: Any = result.get("data")
    if not ceiling_ok:
        final_data = {
            "status": "redacted_by_sensitivity_ceiling",
            "ceiling": ceiling,
            "actual": batch_sensitivity,
            "citation_count": len(final_citations),
        }
        log_event(
            _log, logging.WARNING, "mcp.persona.sensitivity_redacted",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            chosen_mode=chosen_mode,
            final_mode=final_mode,
            ceiling=ceiling,
            actual=batch_sensitivity,
            citation_count=len(final_citations),
        )

    # ── Fix C2: reconcile kernel's executed mode with router mode ─────
    # The kernel query path may silently degrade insight → targeted
    # when no synthesizer is wired. Use the kernel's ``mode_executed``
    # as the envelope's ``mode_used`` so the client sees the TRUE path.
    kernel_executed = result.get("mode_executed")
    envelope_mode: str = final_mode
    if kernel_executed and kernel_executed != final_mode:
        envelope_mode = kernel_executed
        if final_mode == "insight" and kernel_executed == "targeted":
            reason = result.get("insight_degraded_reason") or "synthesizer_not_wired"
            log_event(
                _log, logging.WARNING, "mcp.persona.insight_degraded",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                chosen_mode=chosen_mode,
                final_mode=final_mode,
                kernel_executed=kernel_executed,
                reason=reason,
            )
            # Overlay degraded_from so the envelope records "insight
            # was asked for" even when router degradation did not fire.
            degraded_from = degraded_from or "insight"

    # ── Etag + staleness ──────────────────────────────────────────────
    constraints_norm = _normalize_constraints(request)
    # Fix D: source_cutoff_at is now derived by each dispatcher from
    # actual record timestamps. Use it verbatim — no wall-clock fallback.
    source_cutoff_at = result.get("source_cutoff_at") or "1970-01-01T00:00:00Z"
    etag = _etag.generate_etag(
        kind=envelope_mode,
        subject=request.subject.value,
        intent=request.intent.value,
        user_id=consumer.user_id,
        consumer_scope=scope,
        sensitivity_class=effective_sensitivity,
        constraints=constraints_norm,
        content_cutoff_at=source_cutoff_at,
    )
    staleness, _observed_seq = await _etag.get_staleness_status(
        consumer.consumer_id, consumer.user_id, consumer.etag_cursor
    )

    # ── Phase 1 §1.4: compute dependency keys after payload is assembled ─
    _entity_ids = [c.ref_id for c in final_citations if c.ref_type.value == "entity"]
    _memory_ids = [c.ref_id for c in final_citations if c.ref_type.value == "memory"]
    _hub_ids = [c.ref_id for c in final_citations if c.ref_type.value == "hub"]
    if envelope_mode in ("brief",):
        # Brief = hub read.  Hub type comes from _SUBJECT_TO_HUB_MAP.
        _hub_type = _SUBJECT_TO_HUB_MAP.get(request.subject.value, "current_identity")
        # §1.4: emit hub:<type> + scope:domain:<d> per domain the hub
        # integrates.  Extract from the hub payload if present; pass an
        # empty list when no domain info is available — emit_for_hub_read
        # handles the empty case by falling back to scope:self (the valid
        # Tier-2 coarse-scope key).  Do NOT pass ["self"] — scope:domain:self
        # is not a valid v1 vocabulary key.
        _hub_payload = (result.get("data") or {}) if isinstance(result.get("data"), dict) else {}
        _hub_domains: List[str] = (
            list(_hub_payload.get("domains") or _hub_payload.get("focus_domains") or [])
        )
        _dep_keys = emit_for_hub_read(_hub_type, _hub_domains)
    elif envelope_mode in ("insight",):
        # §1.4: cited_hub_types must be hub TYPE strings, not hub IDs.
        # Extract the hub_type field from hub citations; fall back to
        # stripping the HUB- prefix as a best-effort if hub_type is absent.
        _hub_types: List[str] = []
        for c in final_citations:
            if c.ref_type.value == "hub":
                hub_t = getattr(c, "hub_type", None) or ""
                if hub_t:
                    _hub_types.append(hub_t)
        _dep_keys = emit_for_synthesis(
            cited_entity_ids=_entity_ids,
            cited_memory_ids=_memory_ids,
            cited_hub_types=_hub_types,
            integrated_scopes=["self"],
            integrated_domains=[],
        )
    else:
        # targeted / evidence / unknown — direct graph query keys.
        _dep_keys = emit_for_graph_query(
            entity_ids=_entity_ids,
            memory_ids=_memory_ids,
        )

    # ── Envelope assembly ─────────────────────────────────────────────
    envelope = build_envelope(
        mode_used=envelope_mode,
        data=final_data,
        citations=final_citations,
        meta_inputs={
            "source_cutoff_at": source_cutoff_at,
            "staleness_status": staleness,
            "confidence": float(result.get("confidence") or 0.5),
            "etag": etag,
            "budget_tier": consumer.budget_tier.value,
            "degraded_from": degraded_from,
            "consumer_scope": scope,
            "sensitivity_class": effective_sensitivity,
        },
        query_fingerprint=_fp,
        dependency_keys=_dep_keys,
    )

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    log_event(
        _log, logging.INFO, "mcp.persona.get_context.complete",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        chosen_mode=chosen_mode,
        final_mode=final_mode,
        envelope_mode=envelope_mode,
        degraded_from=degraded_from,
        citation_count=len(final_citations),
        sensitivity=str(effective_sensitivity),
        staleness=staleness,
        etag=etag,
        remaining=str(decr_remaining),
        ceiling_redacted=(not ceiling_ok),
        duration_ms=duration_ms,
    )
    return envelope
