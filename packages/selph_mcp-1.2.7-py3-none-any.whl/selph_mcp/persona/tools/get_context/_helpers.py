"""Small format / normalize helpers and the brief-mode subject map.

Kept small and side-effect free so they can be reused by the dispatch
layer, the entry-point orchestrator, and the short-circuit envelope
builders without circular imports.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import ConsumerScope
from selph_mcp.contracts.read import GetContextRequest
from selph_mcp.persona import etag as _etag


# Phase-2 conservative ``Subject`` → hub_type mapping. Reused by brief-mode
# dispatch and by :mod:`find_evidence` for the ``(subject, intent)``
# fallback. Keep in one place so future additions don't drift between
# call sites.
_SUBJECT_TO_HUB_MAP: Dict[str, str] = {
    "self": "current_identity",
    "person": "relationship",
    "project": "project",
    "pursuit": "pursuit",
    "relationship": "relationship",
    "relationships": "relationship",
    "topic": "current_identity",
    "decision": "current_identity",
}


def _primary_scope(consumer: Consumer) -> ConsumerScope:
    """Pick the first allowed_scope or fall back to ``personal``.

    The MCP contract requires ``meta.consumer_scope`` on every envelope;
    consumers with multiple scopes are represented in the envelope by
    their primary (= first-declared) scope. Future per-request scope
    selection is deferred to a later phase.
    """
    if consumer.allowed_scopes:
        value = consumer.allowed_scopes[0].value
        try:
            return ConsumerScope(value)
        except ValueError:
            pass
    return ConsumerScope.personal


def _normalize_constraints(req: GetContextRequest) -> Dict[str, Any]:
    """Build a JSON-safe constraints dict for etag hashing."""
    c = req.constraints
    tw = c.time_window
    return {
        "entity_id": c.entity_id,
        "time_window": (
            {
                "start": tw.start.isoformat() if tw and tw.start else None,
                "end": tw.end.isoformat() if tw and tw.end else None,
            }
            if tw is not None
            else None
        ),
        "memory_types": sorted(c.memory_types or []),
        "max_age_days": c.max_age_days,
        "sensitivity": c.sensitivity.value,
    }


def _safe_float(value: Any) -> Optional[float]:
    try:
        if value is None:
            return None
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return None


def _compose_query_text(
    request: GetContextRequest,
    question_override: Optional[str] = None,
    domain_hint_prefix: Optional[str] = None,
) -> str:
    """Compose a synthetic NL query text from (subject, intent, constraints).

    When ``question_override`` is supplied (e.g. by :func:`ask_selph`),
    it is used verbatim as the NL query text instead of the synthesized
    one. This keeps ``Constraints.memory_types`` strictly reserved for
    real memory-type registry names and avoids a row-4 router false
    positive when the caller is on ``depth="auto"``.

    When ``domain_hint_prefix`` is supplied (resolved server-side from
    the caller's free-text ``domain_hint`` by
    :func:`selph_mcp.persona._domain_hints.resolve_domain_hint_prefix`),
    it is prepended to the resolved query text with a single space
    separator. Order: prefix first, then the question (or the synthesized
    fallback). Both override paths compose correctly together.
    """
    if question_override and question_override.strip():
        base = question_override.strip()
    else:
        parts = [f"Intent: {request.intent.value}", f"Subject: {request.subject.value}"]
        c = request.constraints
        if c.entity_id:
            parts.append(f"entity={c.entity_id}")
        if c.time_window is not None:
            parts.append(
                f"time_window=({c.time_window.start}..{c.time_window.end})"
            )
        if c.memory_types:
            parts.append(f"memory_types=[{','.join(sorted(c.memory_types))}]")
        base = " | ".join(parts)

    if domain_hint_prefix and domain_hint_prefix.strip():
        return f"{domain_hint_prefix.strip()} {base}"
    return base


def _cutoff_from_payload(payload: Optional[Dict[str, Any]]) -> str:
    """Extract a source cutoff from a hub payload.

    Deprecated wrapper — new call sites use
    :func:`_etag.derive_content_cutoff` directly. Kept for any
    transitive importers; delegates to the shared helper with the
    single-payload list to preserve prior semantics.
    """
    return _etag.derive_content_cutoff(
        [payload] if payload else None
    )
