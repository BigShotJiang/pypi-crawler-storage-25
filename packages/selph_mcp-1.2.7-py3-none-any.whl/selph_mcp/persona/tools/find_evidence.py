"""Persona ``find_evidence`` tool (Phase 2 task 10).

Given a list of citation IDs (or a ``(subject, intent)`` pair) this
tool returns the underlying evidence payloads. Every payload is run
through the privacy scopes filter + redaction before return.

Cost is :data:`MODE_COSTS["evidence"]` (0.5 credits) — retrieval-heavy
but non-LLM in v1.
"""
from __future__ import annotations

import asyncio
import logging
import re
import time as _time
from typing import Any, Dict, Iterable, List, Optional, Tuple

from selph_mcp._client import get_client
from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import (
    Citation,
    ConsumerScope,
    ModeUsed,
    PersonaResponse,
    RefType,
)
from selph_mcp.kernel import project as kernel_project
from selph_mcp.persona import budget as _budget
from selph_mcp.persona import etag as _etag
from selph_mcp.persona.dependency_keys import emit_for_evidence
from selph_mcp.persona.envelope_builder import build_envelope
from selph_mcp.persona.fingerprint import compute_fingerprint
from selph_mcp.privacy.redaction import redact_citations
from selph_mcp.privacy.scopes import derive_sensitivity_batch, enforce_ceiling
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.tools.find_evidence")

# Per-process semaphore capping concurrent ``find_evidence`` invocations.
# Each call hydrates K citations sequentially (one HTTP GET per ref_id);
# at K=50 a single call can occupy one engine entity-pool connection for
# its full duration. Capping concurrent invocations at 5 bounds the
# wheel's draw on the engine entity pool to ~5 in-flight conns from this
# tool, leaving headroom for ingest baseline (47/80) and other tools.
# Followup: replace with a batched ``POST /apps/search/{kind}/batch``
# engine route so a single call doesn't need K round-trips at all.
_FIND_EVIDENCE_CONCURRENCY = asyncio.Semaphore(5)

# Fix B (part 2): recognise 36-char UUIDs (raw_evidence_id) as
# Layer-1 observation citations. ``observe_session`` returns bare
# UUIDs — the old classifier only matched MEM-/ENT-/HUB- prefixes
# and dropped every observation citation silently.
_UUID_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)

# Fix B (part 4): (subject, intent) fallback hub-type mapping. Mirrors
# :data:`selph_mcp.persona.tools.get_context._SUBJECT_TO_HUB_MAP`;
# kept local so find_evidence has no reverse dep on get_context.
_SUBJECT_TO_HUB_MAP: Dict[str, str] = {
    "self": "current_identity",
    "person": "relationship",
    "project": "project",
    "pursuit": "pursuit",
    "relationship": "relationship",
    "relationships": "relationship",
    "topic": "current_identity",
    "decision": "current_identity",
}


def _primary_scope(consumer: Consumer) -> ConsumerScope:
    if consumer.allowed_scopes:
        try:
            return ConsumerScope(consumer.allowed_scopes[0].value)
        except ValueError:
            pass
    return ConsumerScope.personal


# ---------------------------------------------------------------------------
# Citation classification
# ---------------------------------------------------------------------------


def _classify_ref_id(ref_id: str) -> str:
    """Best-effort classification of a bare ``ref_id`` string.

    Returns one of ``"memory" | "entity" | "hub" | "observation" |
    "unknown"`` based on the canonical-ID prefix scheme from
    ``rules/data-models.md`` plus the Gap-2 raw_evidence UUID format
    (36-char canonical UUID, no prefix).

    Fix B (part 2): extended to recognize bare UUIDs as Layer-1
    observation citations. Without this, every citation emitted by
    ``observe_session`` was silently dropped by the ``unknown`` branch.
    """
    if not ref_id:
        return "unknown"
    r = ref_id.strip()
    if r.startswith("MEM-"):
        return "memory"
    if r.startswith("ENT-"):
        return "entity"
    if r.startswith("HUB-"):
        return "hub"
    if _UUID_RE.match(r):
        return "observation"
    return "unknown"


async def _read_memory_payload(
    memory_id: str, user_id: str
) -> Optional[Dict[str, Any]]:
    """Fetch a memory row via the engine HTTP API."""
    try:
        return await get_client().get(f"/apps/search/memories/{memory_id}")
    except Exception:  # noqa: BLE001
        return None


async def _read_entity_payload(
    entity_id: str, user_id: str
) -> Optional[Dict[str, Any]]:
    """Fetch an entity row via the engine HTTP API."""
    try:
        data = await get_client().get(f"/apps/search/entities/{entity_id}")
        return {
            "canonical_id": data.get("canonical_id", entity_id),
            "entity_type": data.get("entity_type", ""),
            "aliases": list(data.get("aliases") or []),
            "entity_data": dict(data.get("entity_data") or {}),
            "resolution_status": data.get("resolution_status"),
            "mention_count": data.get("mention_count"),
        }
    except Exception:  # noqa: BLE001
        return None


async def _read_hub_payload(
    consumer: Consumer,
    hub_ref_id: str,
    *,
    hub_type_hint: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Read a hub payload via the kernel project adapter.

    ``find_evidence`` takes a ``ref_id`` but
    :func:`selph_mcp.kernel.project.project` reads by ``hub_type``.
    When the caller supplies a ``hub_type_hint`` we use it; otherwise
    we return ``None`` (hub lookup by bare ``HUB-XXXX`` id is a future
    capability that would need a new DB helper).

    The real authenticated ``consumer`` is threaded through — no
    fabricated/dummy Consumer. The §3.5.1 anti-bypass binding relies
    on the consumer row being authentic, so we must never synthesize
    one here.
    """
    if not hub_type_hint:
        # Bare HUB- id lookup not yet supported via HTTP without hub_type.
        log_event(
            _log, logging.INFO, "mcp.persona.find_evidence.hub_by_id_miss",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            ref_id=hub_ref_id,
        )
        return None
    try:
        result = await kernel_project.project(
            consumer=consumer,
            hub_type=hub_type_hint,
            user_id=consumer.user_id,
        )
        return result.get("payload")
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.WARNING, "mcp.persona.find_evidence.hub_read_failed",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            ref_id=hub_ref_id,
            hub_type=hub_type_hint,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        return None


async def _read_observation_payload(
    raw_evidence_id: str, user_id: str
) -> Optional[Dict[str, Any]]:
    """Hydrate a Layer-1 ``raw_evidence`` row via the engine HTTP API."""
    try:
        return await get_client().get(
            f"/core/observe/raw-evidence/{raw_evidence_id}",
        )
    except Exception:  # noqa: BLE001
        return None


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


async def _resolve_subject_intent_fallback(
    *,
    consumer: Consumer,
    subject: Optional[str],
    intent: Optional[str],
) -> Tuple[List[str], Optional[Dict[str, Any]], Optional[str]]:
    """Fallback: resolve (subject, intent) to a list of citation ids.

    Fix B (part 4): when the caller omits ``citation_ids`` but supplies
    ``(subject, intent)``, look up the subject's hub payload and return
    its ``supporting_memory_ids`` as the hydration list. Keeps v1
    simple — fancy search lives in Phase 5.

    Returns:
        Tuple ``(ids_to_hydrate, hub_payload, hub_type_used)``. The hub
        payload is returned so the caller can log + also hydrate the
        hub itself as an evidence item. When no mapping is found all
        three are empty/None and the caller should skip-charge.
    """
    if not subject:
        return [], None, None
    hub_type = _SUBJECT_TO_HUB_MAP.get(subject.strip())
    if hub_type is None:
        log_event(
            _log, logging.INFO, "mcp.persona.find_evidence.subject_unmapped",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            subject=subject,
            intent=intent,
        )
        return [], None, None
    payload = await _read_hub_payload(
        consumer=consumer,
        hub_ref_id=f"HUB-{hub_type.upper()[:8]}",
        hub_type_hint=hub_type,
    )
    if not payload:
        return [], None, hub_type
    ids = [str(m) for m in (payload.get("supporting_memory_ids") or [])]
    return ids, payload, hub_type


async def find_evidence(
    *,
    consumer: Consumer,
    citation_ids: Optional[Iterable[str]] = None,
    subject: Optional[str] = None,
    intent: Optional[str] = None,
    graph: Any = None,
    chroma: Any = None,
) -> PersonaResponse:
    """Return evidence payloads for the supplied citation IDs.

    Fix B reshaping:
      1. Classify + resolve citations FIRST. Determine whether any real
         hydration work is queued.
      2. Only ``ensure_today_row + check_and_decrement`` when there's
         actual work to charge for. Empty input now returns a no-op
         envelope WITHOUT charging the evidence credit.
      3. Hub-prefix ids hydrate via :func:`_read_hub_payload` through
         the (subject, intent) fallback table.
      4. 36-char UUIDs hydrate via
         :func:`selph_db.raw_evidence_manager.get_raw_evidence_by_id`.
      5. When ``citation_ids`` is empty but ``(subject, intent)`` is
         supplied, fall back to the subject's hub payload and hydrate
         its ``supporting_memory_ids``.

    Args:
        consumer: The authenticated consumer (supplies ``user_id``).
        citation_ids: Optional iterable of canonical IDs
            (``MEM-…``, ``ENT-…``, ``HUB-…``, or a raw_evidence UUID).
            When supplied these take precedence over the
            ``(subject, intent)`` fallback.
        subject: Optional :class:`Subject` label — drives the
            hub-backed fallback when ``citation_ids`` is empty.
        intent: Optional :class:`Intent` label — pairs with subject.
        graph, chroma: Lifespan handles (reserved for future rich
            provenance reads).

    Returns:
        Envelope with ``data = {"items": [{ref_id, payload, ...}, ...]}``
        on the happy path, or a status marker when no hydration work was
        possible (in which case no budget is charged).
    """
    async with _FIND_EVIDENCE_CONCURRENCY:
        return await _find_evidence_impl(
            consumer=consumer,
            citation_ids=citation_ids,
            subject=subject,
            intent=intent,
            graph=graph,
            chroma=chroma,
        )


async def _find_evidence_impl(
    *,
    consumer: Consumer,
    citation_ids: Optional[Iterable[str]] = None,
    subject: Optional[str] = None,
    intent: Optional[str] = None,
    graph: Any = None,
    chroma: Any = None,
) -> PersonaResponse:
    t0 = _time.perf_counter()
    ids = [s for s in (citation_ids or []) if s]
    log_event(
        _log, logging.INFO, "mcp.persona.find_evidence.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        id_count=len(ids),
        subject=subject,
        intent=intent,
    )

    scope = _primary_scope(consumer)
    ceiling = consumer.sensitivity_ceiling.value

    # Phase 1 §1.3: compute fingerprint BEFORE any retrieval.
    _fp = compute_fingerprint(
        tool="find_evidence",
        params={
            "citation_ids": sorted(ids) if ids else [],
            "subject": subject,
            "intent": intent,
        },
        consumer=consumer,
    )

    # ── Fix B: classify up front so we can skip-charge when empty ────
    fallback_hub_payload: Optional[Dict[str, Any]] = None
    fallback_hub_type: Optional[str] = None
    used_fallback = False

    if not ids:
        # No explicit ids → try (subject, intent) fallback.
        fb_ids, fallback_hub_payload, fallback_hub_type = (
            await _resolve_subject_intent_fallback(
                consumer=consumer,
                subject=subject,
                intent=intent,
            )
        )
        if fb_ids:
            ids = fb_ids
            used_fallback = True
        elif subject and fallback_hub_type and fallback_hub_payload is None:
            # Subject mapped to a hub but no hub exists for this user.
            # Skip-charge and surface a helpful status — do NOT
            # decrement the budget (Fix B part 3).
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.persona.find_evidence.no_hub_for_subject",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                subject=subject,
                intent=intent,
                hub_type=fallback_hub_type,
                duration_ms=duration_ms,
            )
            return _no_work_envelope(
                consumer=consumer,
                subject=subject,
                intent=intent,
                scope=scope,
                ceiling=ceiling,
                status="no_hub_for_subject",
                hint=(
                    f"No {fallback_hub_type!s} hub is built for this "
                    "user yet — rebuild the hub or supply explicit "
                    "citation_ids."
                ),
                query_fingerprint=_fp,
            )

    if not ids:
        # No explicit ids AND no fallback hit → skip-charge and return
        # a helpful status. This is the main Fix B (part 3) correction
        # — prior behavior decremented 0.5 credits for an empty call.
        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.INFO, "mcp.persona.find_evidence.no_citations",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            subject=subject,
            intent=intent,
            duration_ms=duration_ms,
        )
        return _no_work_envelope(
            consumer=consumer,
            subject=subject,
            intent=intent,
            scope=scope,
            ceiling=ceiling,
            status="no_citations_provided",
            hint=(
                "supply citation_ids (MEM-/ENT-/HUB-/UUID) or call "
                "get_context which auto-delegates to find_evidence "
                "when evidence is the resolved mode."
            ),
            query_fingerprint=_fp,
        )

    # ── Budget gate — evidence mode. Fires only now that there's work. ─
    await _budget.ensure_today_row(
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        budget_tier=consumer.budget_tier,
    )
    decr_remaining, decr_ok = await _budget.check_and_decrement(
        consumer.consumer_id, "evidence"
    )
    if not decr_ok:
        # Fix D: deterministic cutoff — exhausted path has no content.
        source_cutoff_at = "1970-01-01T00:00:00Z"
        etag = _etag.generate_etag(
            kind="evidence",
            subject=subject or "self",
            intent=intent or "evidence_lookup",
            user_id=consumer.user_id,
            consumer_scope=scope,
            sensitivity_class=ceiling,
            constraints={"citation_ids": sorted(ids) or None},
            content_cutoff_at=source_cutoff_at,
        )
        log_event(
            _log, logging.WARNING, "mcp.persona.find_evidence.exhausted",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            remaining=str(decr_remaining),
        )
        return build_envelope(
            mode_used=ModeUsed.none,
            ok=False,
            data=None,
            citations=[],
            meta_inputs={
                "source_cutoff_at": source_cutoff_at,
                "staleness_status": "fresh",
                "confidence": 0.0,
                "etag": etag,
                "budget_tier": "exhausted",
                "consumer_scope": scope,
                "sensitivity_class": ceiling,
            },
            suggested_next_actions=[
                "Wait for daily UTC rollover or request a higher budget_tier.",
            ],
            query_fingerprint=_fp,
            dependency_keys=[],
        )

    # ── Hydrate each citation ─────────────────────────────────────────
    items: List[Dict[str, Any]] = []
    citations: List[Citation] = []
    content_map: Dict[str, str] = {}

    # If the fallback resolved a hub payload, surface it as an
    # evidence item too — the hub itself is the headline evidence.
    if used_fallback and fallback_hub_payload is not None:
        hub_id = str(
            fallback_hub_payload.get("hub_id")
            or f"HUB-{(fallback_hub_type or 'unknown').upper()[:8]}"
        )
        try:
            citations.append(
                Citation(
                    ref_type=RefType.hub,
                    ref_id=hub_id,
                    layer=4,
                    hub_type=str(fallback_hub_type or "unknown"),
                )
            )
        except Exception:  # noqa: BLE001
            pass
        items.append(
            {
                "ref_id": hub_id,
                "kind": "hub",
                "payload": fallback_hub_payload,
                "via": "subject_intent_fallback",
                "hub_type": fallback_hub_type,
            }
        )

    for ref_id in ids:
        kind = _classify_ref_id(ref_id)
        payload: Optional[Dict[str, Any]] = None
        try:
            if kind == "memory":
                payload = await _read_memory_payload(ref_id, consumer.user_id)
                if payload:
                    mtype = str(payload.get("memory_type") or "unknown")
                    try:
                        citations.append(
                            Citation(
                                ref_type=RefType.memory,
                                ref_id=ref_id,
                                layer=2,
                                memory_type=mtype,
                            )
                        )
                    except Exception:  # noqa: BLE001
                        pass
                    items.append(
                        {"ref_id": ref_id, "kind": "memory", "payload": payload}
                    )
            elif kind == "entity":
                payload = await _read_entity_payload(ref_id, consumer.user_id)
                if payload:
                    citations.append(
                        Citation(
                            ref_type=RefType.entity,
                            ref_id=ref_id,
                            layer=2,
                        )
                    )
                    items.append(
                        {"ref_id": ref_id, "kind": "entity", "payload": payload}
                    )
            elif kind == "hub":
                # Fix B (part 1): wire _read_hub_payload into the main
                # hydration loop. Without hub_type_hint we cannot yet
                # resolve a bare HUB-XXXX id — surface the skip explicitly
                # so callers know to follow up.
                payload = await _read_hub_payload(
                    consumer=consumer,
                    hub_ref_id=ref_id,
                    hub_type_hint=None,
                )
                if payload is not None:
                    try:
                        citations.append(
                            Citation(
                                ref_type=RefType.hub,
                                ref_id=ref_id,
                                layer=4,
                                hub_type=str(payload.get("hub_type") or "unknown"),
                            )
                        )
                    except Exception:  # noqa: BLE001
                        pass
                    items.append(
                        {"ref_id": ref_id, "kind": "hub", "payload": payload}
                    )
                else:
                    items.append(
                        {
                            "ref_id": ref_id,
                            "kind": "hub",
                            "payload": None,
                            "note": (
                                "hub lookup by bare HUB- id not yet supported; "
                                "pass subject+intent so the fallback resolves "
                                "the hub_type."
                            ),
                        }
                    )
            elif kind == "observation":
                # Fix B (part 2): hydrate raw_evidence UUIDs via the
                # public helper. The text is carried into ``content_map``
                # so the sensitivity classifier can run its PII scan
                # (per ``selph_mcp.privacy.scopes`` row 4).
                payload = await _read_observation_payload(ref_id, consumer.user_id)
                if payload:
                    try:
                        citations.append(
                            Citation(
                                ref_type=RefType.observation,
                                ref_id=ref_id,
                                layer=1,
                            )
                        )
                    except Exception:  # noqa: BLE001
                        pass
                    text_for_pii = payload.get("content_text") or ""
                    if text_for_pii:
                        content_map[ref_id] = str(text_for_pii)
                    items.append(
                        {
                            "ref_id": ref_id,
                            "kind": "observation",
                            "payload": payload,
                        }
                    )
                else:
                    items.append(
                        {
                            "ref_id": ref_id,
                            "kind": "observation",
                            "payload": None,
                            "note": "raw_evidence row not found for this user",
                        }
                    )
            else:
                items.append(
                    {
                        "ref_id": ref_id,
                        "kind": "unknown",
                        "payload": None,
                        "note": f"unrecognized ref_id prefix: {ref_id!r}",
                    }
                )
        except Exception as exc:  # noqa: BLE001
            log_event(
                _log, logging.WARNING, "mcp.persona.find_evidence.read_failed",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                ref_id=ref_id,
                kind=kind,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )
            items.append(
                {
                    "ref_id": ref_id,
                    "kind": kind,
                    "payload": None,
                    "error": str(exc)[:200],
                }
            )

    # Sensitivity + per-item redaction.
    batch_sensitivity = derive_sensitivity_batch(
        citations, content_map=content_map
    )
    ceiling_ok = enforce_ceiling(ceiling, batch_sensitivity)

    redacted_data: Optional[Dict[str, Any]] = None
    if not ceiling_ok:
        redacted_data = {
            "status": "redacted_by_sensitivity_ceiling",
            "ceiling": ceiling,
            "actual": batch_sensitivity,
            "citation_count": len(citations),
        }
        log_event(
            _log, logging.WARNING, "mcp.persona.sensitivity_redacted",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            mode="evidence",
            ceiling=ceiling,
            actual=batch_sensitivity,
            citation_count=len(citations),
        )

    effective_sensitivity = (
        batch_sensitivity if ceiling_ok else ceiling
    )
    final_citations = redact_citations(citations, ceiling, content_map=content_map)

    # Fix D: deterministic cutoff derived from the hydrated records
    # rather than wall-clock time. ``captured_at`` / ``last_mentioned_at``
    # / ``generated_at`` all qualify via :data:`_etag._CUTOFF_FIELDS`.
    cutoff_records: List[Dict[str, Any]] = []
    for item in items:
        payload = item.get("payload")
        if isinstance(payload, dict):
            cutoff_records.append(payload)
    source_cutoff_at = _etag.derive_content_cutoff(cutoff_records)

    etag = _etag.generate_etag(
        kind="evidence",
        subject=subject or "self",
        intent=intent or "evidence_lookup",
        user_id=consumer.user_id,
        consumer_scope=scope,
        sensitivity_class=effective_sensitivity,
        constraints={"citation_ids": sorted(ids)},
        content_cutoff_at=source_cutoff_at,
    )
    staleness, _observed_seq = await _etag.get_staleness_status(
        consumer.consumer_id, consumer.user_id, consumer.etag_cursor
    )

    # Phase 1 §1.4: dependency keys for evidence mode — Tier 1 only.
    _ev_entity_ids = [c.ref_id for c in final_citations if c.ref_type.value == "entity"]
    _ev_memory_ids = [c.ref_id for c in final_citations if c.ref_type.value == "memory"]
    _dep_keys = emit_for_evidence(
        cited_entity_ids=_ev_entity_ids,
        cited_memory_ids=_ev_memory_ids,
    )

    envelope_data: Any = redacted_data if redacted_data is not None else {
        "items": items,
        "requested": {
            "citation_ids": ids,
            "subject": subject,
            "intent": intent,
            "used_subject_intent_fallback": used_fallback,
            "fallback_hub_type": fallback_hub_type,
        },
    }
    envelope = build_envelope(
        mode_used=ModeUsed.evidence,
        data=envelope_data,
        citations=final_citations,
        meta_inputs={
            "source_cutoff_at": source_cutoff_at,
            "staleness_status": staleness,
            "confidence": 0.8,
            "etag": etag,
            "budget_tier": consumer.budget_tier.value,
            "consumer_scope": scope,
            "sensitivity_class": effective_sensitivity,
        },
        query_fingerprint=_fp,
        dependency_keys=_dep_keys,
    )

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    log_event(
        _log, logging.INFO, "mcp.persona.find_evidence.complete",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        id_count=len(ids),
        returned=len(items),
        citations=len(final_citations),
        sensitivity=str(effective_sensitivity),
        remaining=str(decr_remaining),
        used_fallback=used_fallback,
        ceiling_redacted=(not ceiling_ok),
        duration_ms=duration_ms,
    )
    return envelope


def _no_work_envelope(
    *,
    consumer: Consumer,
    subject: Optional[str],
    intent: Optional[str],
    scope: ConsumerScope,
    ceiling: str,
    status: str,
    hint: str,
    query_fingerprint: str = "",
) -> PersonaResponse:
    """Return an ``ok=True, mode_used=evidence`` envelope with no charge.

    Used by the skip-charge short-circuits added in Fix B (part 3) —
    when there is no citation to hydrate and no ``(subject, intent)``
    fallback resolves a hub payload, the budget MUST NOT be decremented.
    The envelope still carries a deterministic etag so consumers can
    cache the "no-op" response.
    """
    # Fix D: deterministic — no records → epoch fallback.
    source_cutoff_at = "1970-01-01T00:00:00Z"
    etag = _etag.generate_etag(
        kind="evidence",
        subject=subject or "self",
        intent=intent or "evidence_lookup",
        user_id=consumer.user_id,
        consumer_scope=scope,
        sensitivity_class=ceiling,
        constraints={
            "citation_ids": None,
            "subject": subject,
            "intent": intent,
            "status": status,
        },
        content_cutoff_at=source_cutoff_at,
    )
    return build_envelope(
        mode_used=ModeUsed.evidence,
        ok=True,
        data={
            "status": status,
            "hint": hint,
            "items": [],
        },
        citations=[],
        meta_inputs={
            "source_cutoff_at": source_cutoff_at,
            "staleness_status": "fresh",
            "confidence": 0.0,
            "etag": etag,
            "budget_tier": consumer.budget_tier.value,
            "consumer_scope": scope,
            "sensitivity_class": ceiling,
        },
        query_fingerprint=query_fingerprint,
        dependency_keys=[],
    )


__all__ = ["find_evidence"]
