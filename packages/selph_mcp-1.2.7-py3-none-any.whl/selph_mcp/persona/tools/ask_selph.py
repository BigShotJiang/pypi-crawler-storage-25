"""Persona ``ask_selph`` tool (Phase 2 task 8).

Convenience wrapper over :func:`selph_mcp.persona.tools.get_context.get_context`
that defaults ``intent="strategy"`` and forces ``depth="insight"`` unless
the caller explicitly overrides either.

This is the primary harness entry point for "ask Selph a question" —
the depth router still runs (so budget degradation can step the read
down to targeted), but the intent/depth defaults make a direct LLM
synthesis the likely path.
"""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Optional

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import PersonaResponse
from selph_mcp.contracts.read import (
    Constraints,
    Depth,
    GetContextRequest,
    Intent,
    Subject,
)
from selph_mcp.persona._domain_hints import resolve_domain_hint_prefix
from selph_mcp.persona.fingerprint import compute_fingerprint
from selph_mcp.persona.tools.get_context import get_context
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.tools.ask_selph")


async def ask_selph(
    *,
    consumer: Consumer,
    question: str,
    subject: str = "self",
    intent: str = "strategy",
    depth: str = "insight",
    domain_hint: Optional[str] = None,
    entity_id: Optional[str] = None,
    graph: Any = None,
    chroma: Any = None,
    synthesizer: Any = None,
    self_entity_id: Optional[str] = None,
) -> PersonaResponse:
    """Route ``question`` through the persona insight path.

    Args:
        consumer: The authenticated consumer.
        question: Natural-language question string — passed through to
            the downstream kernel query via the private
            ``_question_override`` keyword on :func:`get_context` so
            the synthesizer receives it verbatim. The question is NOT
            stashed in ``Constraints.memory_types``; that field is
            reserved for real memory-type registry names and would
            otherwise trip the depth router's row-4 (targeted) rule.
        subject / intent / depth: Defaults per the brief — override
            only when the caller needs a non-insight read. The strict
            enum on ``GetContextRequest`` rejects unknown values.
        domain_hint: Optional free-text retrieval scope hint. Accepted
            values (unknown hints fall through to no scoping —
            schema-hiding rule, per ``rules/api-surface.md``):

            - ``"professional_context"`` — identity, goals, priorities,
              active projects, working style.
            - ``"learning_and_active_interests"`` — values, recurring
              patterns, topics actively being pursued or learned.
            - ``"social_context"`` — closest relationships, friends,
              family, partner, social circle.
            - ``"daily_routines"`` — patterns, recurring tendencies,
              timeline, behavioral changes over time.
            - ``"voice_and_creative_context"`` — how the user writes,
              talks, the tone and style they use.
            - ``"tools_and_workflow_context"`` — how the user approaches
              work and the tools they rely on.

            Never a hub_type, memory_type, layer number, or other
            internal taxonomy element — Selph maps free text to
            internals server-side.
        entity_id: Optional entity filter.
        graph, chroma, synthesizer, self_entity_id: Passed through to
            :func:`get_context`. ``synthesizer`` is required for
            genuine insight synthesis — absent → degrades to targeted.

    Returns:
        The :class:`PersonaResponse` from the downstream read.
    """
    t0 = _time.perf_counter()
    _domain_hint_prefix = resolve_domain_hint_prefix(domain_hint)
    log_event(
        _log, logging.INFO, "mcp.persona.ask_selph.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        subject=subject,
        intent=intent,
        depth=depth,
        question_len=len(question or ""),
        domain_hint=domain_hint,
    )

    try:
        request = GetContextRequest(
            subject=Subject(subject),
            intent=Intent(intent),
            depth=Depth(depth),
            constraints=Constraints(
                entity_id=entity_id,
                # Note: ``memory_types`` is NOT the transport for the
                # user's question. The question is threaded to
                # :func:`get_context` via its private
                # ``_question_override`` kwarg below — keeping this
                # constraint field strictly for registry memory-type
                # names so the depth router does not misfire row 4.
                memory_types=[],
            ),
        )
    except Exception as exc:  # noqa: BLE001 — pydantic validation error
        log_event(
            _log, logging.WARNING, "mcp.persona.ask_selph.bad_request",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise

    envelope = await get_context(
        request=request,
        consumer=consumer,
        graph=graph,
        chroma=chroma,
        synthesizer=synthesizer,
        self_entity_id=self_entity_id,
        _question_override=(question.strip() if question else None),
        _domain_hint_prefix_override=_domain_hint_prefix,
    )

    # Critical fix: stamp ask_selph's own fingerprint so
    # get_fingerprint(tool="ask_selph", ...) matches this envelope.
    # The inner get_context call stamps "get_context:…" — overwrite with
    # the ask_selph-shape fingerprint before returning.
    _ask_fp_params = {
        "subject": subject,
        "intent": intent,
        "depth": depth,
        "entity_id": entity_id,
        "question": (question.strip() if question else ""),
        "domain_hint": domain_hint or "",
    }
    _ask_fp = compute_fingerprint(
        tool="ask_selph",
        params=_ask_fp_params,
        consumer=consumer,
    )
    # Overwrite the inner fingerprint + etag (§1.3 v2: etag aliases
    # fingerprint) — the inner get_context call stamps "get_context:…"
    # on both fields; overwrite both so get_fingerprint(tool="ask_selph")
    # matches this envelope exactly.  dependency_keys remain as-is from
    # the inner call (same underlying evidence).
    envelope.meta.query_fingerprint = _ask_fp
    envelope.meta.etag = _ask_fp

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    log_event(
        _log, logging.INFO, "mcp.persona.ask_selph.complete",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        mode_used=envelope.mode_used.value,
        domain_hint=domain_hint,
        duration_ms=duration_ms,
    )
    return envelope


__all__ = ["ask_selph"]
