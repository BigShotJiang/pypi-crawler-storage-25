"""Persona ``get_entity_card`` tool (Phase 2 task 11).

Thin read-only lookup against ``entity_registry``. Returns a compact
card containing the canonical_id, entity_type, alias set, and recent
memory counts. Useful for harnesses that want to render an entity
chip without the full graph traversal.

Cost: :data:`MODE_COSTS["targeted"]` (1 credit).
"""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Dict, List, Optional

from selph_mcp._client import get_client
from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import (
    Citation,
    ConsumerScope,
    ModeUsed,
    PersonaResponse,
    RefType,
)
from selph_mcp.persona import budget as _budget
from selph_mcp.persona import etag as _etag
from selph_mcp.persona.dependency_keys import emit_for_graph_query
from selph_mcp.persona.envelope_builder import build_envelope
from selph_mcp.persona.fingerprint import compute_fingerprint
from selph_mcp.privacy.redaction import redact_citations
from selph_mcp.privacy.scopes import derive_sensitivity_batch, enforce_ceiling
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.tools.get_entity_card")


def _primary_scope(consumer: Consumer) -> ConsumerScope:
    if consumer.allowed_scopes:
        try:
            return ConsumerScope(consumer.allowed_scopes[0].value)
        except ValueError:
            pass
    return ConsumerScope.personal


async def _read_entity(entity_id: str, user_id: str) -> Optional[Dict[str, Any]]:
    """Fetch an entity row via the engine HTTP API.

    Calls ``GET /apps/search/entities/{entity_id}`` (bearer-auth,
    user-scoped on the engine side).
    """
    try:
        data = await get_client().get(f"/apps/search/entities/{entity_id}")
        return {
            "canonical_id": data.get("canonical_id", entity_id),
            "entity_type": data.get("entity_type", ""),
            "aliases": list(data.get("aliases") or []),
            "entity_data": dict(data.get("entity_data") or {}),
            "last_mentioned_at": data.get("last_mentioned_at"),
            "updated_at": data.get("updated_at"),
            "created_at": data.get("created_at"),
        }
    except Exception:  # noqa: BLE001 — 404 or network error → None
        return None


async def _recent_memory_count(entity_id: str, user_id: str) -> int:
    """Return number of memories that mention ``entity_id`` via the engine."""
    try:
        data = await get_client().get(
            f"/apps/search/entities/{entity_id}",
            params={"include_mention_count": "true"},
        )
        return int(data.get("mention_count") or 0)
    except Exception:  # noqa: BLE001
        return 0


async def get_entity_card(
    *,
    consumer: Consumer,
    ref_id: str,
) -> PersonaResponse:
    """Return a compact entity card for ``ref_id``."""
    t0 = _time.perf_counter()
    log_event(
        _log, logging.INFO, "mcp.persona.get_entity_card.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        ref_id=ref_id,
    )

    scope = _primary_scope(consumer)
    ceiling = consumer.sensitivity_ceiling.value

    # Phase 1 §1.3: compute fingerprint BEFORE retrieval.
    _fp = compute_fingerprint(
        tool="get_entity_card",
        params={"ref_id": ref_id},
        consumer=consumer,
    )

    # Budget: charged as targeted.
    await _budget.ensure_today_row(
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        budget_tier=consumer.budget_tier,
    )
    decr_remaining, decr_ok = await _budget.check_and_decrement(
        consumer.consumer_id, "targeted"
    )
    if not decr_ok:
        # Fix D: deterministic — exhausted short-circuit has no content.
        source_cutoff_at = "1970-01-01T00:00:00Z"
        etag = _etag.generate_etag(
            kind="entity_card",
            subject="person",
            intent="briefing",
            user_id=consumer.user_id,
            consumer_scope=scope,
            sensitivity_class=ceiling,
            constraints={"ref_id": ref_id},
            content_cutoff_at=source_cutoff_at,
        )
        return build_envelope(
            mode_used=ModeUsed.none,
            ok=False,
            data=None,
            citations=[],
            meta_inputs={
                "source_cutoff_at": source_cutoff_at,
                "staleness_status": "fresh",
                "confidence": 0.0,
                "etag": etag,
                "budget_tier": "exhausted",
                "consumer_scope": scope,
                "sensitivity_class": ceiling,
            },
            query_fingerprint=_fp,
            dependency_keys=[],
        )

    payload = await _read_entity(ref_id, consumer.user_id)
    if payload is None:
        # Fix D: miss path has no entity row → epoch fallback keeps the
        # etag stable across identical misses.
        source_cutoff_at = "1970-01-01T00:00:00Z"
        etag = _etag.generate_etag(
            kind="entity_card",
            subject="person",
            intent="briefing",
            user_id=consumer.user_id,
            consumer_scope=scope,
            sensitivity_class=ceiling,
            constraints={"ref_id": ref_id},
            content_cutoff_at=source_cutoff_at,
        )
        log_event(
            _log, logging.INFO, "mcp.persona.get_entity_card.miss",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            ref_id=ref_id,
        )
        return build_envelope(
            mode_used=ModeUsed.targeted,
            ok=False,
            data={"error": "unknown_entity", "ref_id": ref_id},
            citations=[],
            meta_inputs={
                "source_cutoff_at": source_cutoff_at,
                "staleness_status": "fresh",
                "confidence": 0.0,
                "etag": etag,
                "budget_tier": consumer.budget_tier.value,
                "consumer_scope": scope,
                "sensitivity_class": ceiling,
            },
            query_fingerprint=_fp,
            dependency_keys=[],
        )

    mem_count = await _recent_memory_count(ref_id, consumer.user_id)

    citations: List[Citation] = [
        Citation(
            ref_type=RefType.entity,
            ref_id=payload["canonical_id"],
            layer=2,
        )
    ]
    batch_sensitivity = derive_sensitivity_batch(citations)
    final_citations = redact_citations(citations, ceiling)
    effective_sensitivity = (
        batch_sensitivity
        if enforce_ceiling(ceiling, batch_sensitivity)
        else ceiling
    )

    # Compose the card.
    entity_data = payload.get("entity_data") or {}
    card = {
        "canonical_id": payload["canonical_id"],
        "entity_type": payload["entity_type"],
        "alias_set": list(payload.get("aliases") or []),
        "kind_hint": entity_data.get("kind_hint"),
        "primary_name": entity_data.get("primary_name")
        or entity_data.get("full_name")
        or (list(payload.get("aliases") or []) or [None])[0],
        "recent_memories_count": mem_count,
    }

    # Fix D: derive the cutoff from the entity row's own timestamps
    # (``last_mentioned_at`` → ``updated_at`` → ``created_at``) so the
    # etag is deterministic for the same entity state.
    source_cutoff_at = _etag.derive_content_cutoff([payload])
    etag = _etag.generate_etag(
        kind="entity_card",
        subject="person",
        intent="briefing",
        user_id=consumer.user_id,
        consumer_scope=scope,
        sensitivity_class=effective_sensitivity,
        constraints={"ref_id": ref_id},
        content_cutoff_at=source_cutoff_at,
    )
    staleness, _observed_seq = await _etag.get_staleness_status(
        consumer.consumer_id, consumer.user_id, consumer.etag_cursor
    )

    _dep_keys = emit_for_graph_query(entity_ids=[ref_id], memory_ids=[])

    envelope = build_envelope(
        mode_used=ModeUsed.targeted,
        data=card,
        citations=final_citations,
        meta_inputs={
            "source_cutoff_at": source_cutoff_at,
            "staleness_status": staleness,
            "confidence": 0.9,
            "etag": etag,
            "budget_tier": consumer.budget_tier.value,
            "consumer_scope": scope,
            "sensitivity_class": effective_sensitivity,
        },
        query_fingerprint=_fp,
        dependency_keys=_dep_keys,
    )

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    log_event(
        _log, logging.INFO, "mcp.persona.get_entity_card.complete",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        ref_id=ref_id,
        entity_type=card["entity_type"],
        aliases_count=len(card["alias_set"]),
        recent_memories=mem_count,
        remaining=str(decr_remaining),
        duration_ms=duration_ms,
    )
    return envelope


__all__ = ["get_entity_card"]
