"""Persona ``recommendation_feedback`` tool (Phase 3, §3.3).

Writes an outcome for a previously surfaced recommendation into
``selph_recommendation_feedback`` via the engine's bridge route
``POST /apps/mcp/consumers/{consumer_id}/recommendation-feedback``.
Used by the heuristic ranker (Phase 5) plus the Phase 5
``recommend_workflows`` tool when harnesses report
accept / skip / modify / defer / reject outcomes.

Symmetric with ``correct(action=reject_recommendation, target_type=recommendation)``
— both paths hit the same manager and share the same idempotent
``ON CONFLICT DO NOTHING`` insert. Keeping both live is a deliberate
compile-table symmetry decision (§3.4).

Zero budget cost — feedback writes are free.

Channel vs ``mode_used`` (deferred contract note):
    :class:`ModeUsed` is a Phase 1a-frozen read-side enum — there is
    no ``"feedback"`` value. To stay contract-clean we report
    ``mode_used=ModeUsed.brief`` (the smallest read-shape) and surface
    the real channel via ``data["channel"] = "feedback"``. Harnesses
    that need to distinguish feedback from a read must branch on
    ``data["channel"]``. Adding a first-class feedback ``mode_used``
    value is a future contract bump — deferred beyond Phase 3.

Invalidation semantics:
    Only ``rejected`` emits an etag invalidation (scope
    ``consumer:{consumer_id}:recommendations:*``) so the harness'
    recommendation cache busts on next handshake. The other four
    outcomes are signals for the ranker and do NOT invalidate any
    downstream read.

No direct imports of ``selph_db``. Delegates via HTTP to the engine.
"""
from __future__ import annotations

import logging
import time as _time
from typing import Optional

from fastapi import HTTPException

from selph_mcp._client import EngineUpstreamError, get_client
from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import (
    ConsumerScope,
    ModeUsed,
    PersonaResponse,
)
from selph_mcp.contracts.writeback import FeedbackOutcome
from selph_mcp.persona import etag as _etag
from selph_mcp.persona.envelope_builder import build_envelope
from selph_mcp.persona.fingerprint import compute_fingerprint
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.tools.recommendation_feedback")

# Deterministic fallback used for the envelope's ``source_cutoff_at``
# when the feedback event has no caller-supplied timestamp. Matches the
# pattern in the other writeback tools (observe_session, correct).
_EPOCH_FALLBACK: str = "1970-01-01T00:00:00Z"


def _primary_scope(consumer: Consumer) -> ConsumerScope:
    """Pick the consumer's primary scope for etag hashing.

    Falls back to :attr:`ConsumerScope.personal` when the consumer row
    has no allowed_scopes or the value doesn't round-trip through the
    envelope enum (which can happen if scopes are added on the consumer
    contract before the envelope contract catches up).
    """
    if consumer.allowed_scopes:
        try:
            return ConsumerScope(consumer.allowed_scopes[0].value)
        except ValueError:
            pass
    return ConsumerScope.personal


async def recommendation_feedback(
    *,
    consumer: Consumer,
    feedback_event_key: str,
    outcome: FeedbackOutcome,
    notes: Optional[str] = None,
) -> PersonaResponse:
    """Persist a recommendation-feedback row.

    Args:
        consumer: Authenticated consumer (binding source — supplies
            ``consumer_id`` + ``user_id`` for the DB row).
        feedback_event_key: Stable key from the recommendation envelope
            (§6.4 of the strategy doc). Idempotent: re-delivery with the
            same key is a no-op thanks to ``ON CONFLICT DO NOTHING`` in
            the manager.
        outcome: Which outcome was observed by the harness.
        notes: Optional free-form notes from the harness.

    Returns:
        A :class:`PersonaResponse` envelope with
        ``data = {"channel": "feedback", "feedback_event_key": ...,
        "outcome": ...}``.

    Raises:
        HTTPException(400): when ``feedback_event_key`` is empty. The
            manager's own validation is also surfaced here so the
            persona surface returns a clean 400 rather than a bare
            ``ValueError`` bubbling up through the MCP runtime.
    """
    t0 = _time.perf_counter()
    log_event(
        _log, logging.INFO, "mcp.persona.recommendation_feedback.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        feedback_event_key=feedback_event_key,
        outcome=outcome.value,
        has_notes=notes is not None,
    )

    # ── Surface-layer validation (pre-emptive) ────────────────────────
    key = (feedback_event_key or "").strip()
    if not key:
        log_event(
            _log, logging.WARNING,
            "mcp.persona.recommendation_feedback.empty_key",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
        )
        raise HTTPException(
            status_code=400,
            detail="recommendation_feedback requires a non-empty feedback_event_key.",
        )

    scope = _primary_scope(consumer)
    ceiling = consumer.sensitivity_ceiling.value

    # Phase 1 §1.3: fingerprint BEFORE any mutation.  Writeback ack →
    # empty dependency_keys.
    _fp = compute_fingerprint(
        tool="recommendation_feedback",
        params={
            "feedback_event_key": key,
            "outcome": outcome.value,
        },
        consumer=consumer,
    )

    # ── Engine write (HTTP) ────────────────────────────────────────────
    try:
        await get_client().post(
            "/apps/mcp/recommendation-feedback",
            json={
                "feedback_event_key": key,
                "outcome": outcome.value,
                "notes": notes,
            },
        )
    except EngineUpstreamError as exc:
        if exc.status_code == 400:
            log_event(
                _log, logging.WARNING,
                "mcp.persona.recommendation_feedback.validation_failed",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                feedback_event_key=key,
                outcome=outcome.value,
                error=str(exc),
            )
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        log_event(
            _log, logging.ERROR,
            "mcp.persona.recommendation_feedback.engine_error",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            feedback_event_key=key,
            outcome=outcome.value,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise HTTPException(
            status_code=502,
            detail=f"Engine returned an error persisting feedback: {exc}",
        ) from exc

    # ── Emit invalidation for ``rejected`` only ───────────────────────
    if outcome is FeedbackOutcome.rejected:
        try:
            await _etag.emit_invalidations(
                consumer,
                "recommendation_rejection",
                target_id=key,
            )
        except Exception as exc:  # noqa: BLE001 — already non-fatal
            log_event(
                _log, logging.WARNING,
                "mcp.persona.recommendation_feedback.invalidation_failed",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                feedback_event_key=key,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )

    # ── Envelope assembly ────────────────────────────────────────────
    etag = _etag.generate_etag(
        kind="feedback",
        subject="self",
        intent="feedback",
        user_id=consumer.user_id,
        consumer_scope=scope,
        sensitivity_class=ceiling,
        constraints={
            "feedback_event_key": key,
            "outcome": outcome.value,
        },
        content_cutoff_at=_EPOCH_FALLBACK,
    )

    envelope = build_envelope(
        mode_used=ModeUsed.brief,
        ok=True,
        data={
            "channel": "feedback",
            "feedback_event_key": key,
            "outcome": outcome.value,
        },
        citations=[],
        meta_inputs={
            "source_cutoff_at": _EPOCH_FALLBACK,
            "staleness_status": "fresh",
            "confidence": 1.0,
            "etag": etag,
            "budget_tier": consumer.budget_tier.value,
            "consumer_scope": scope,
            "sensitivity_class": ceiling,
        },
        query_fingerprint=_fp,
        dependency_keys=[],
    )

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    log_event(
        _log, logging.INFO, "mcp.persona.recommendation_feedback.complete",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        feedback_event_key=key,
        outcome=outcome.value,
        duration_ms=duration_ms,
    )
    return envelope


__all__ = ["recommendation_feedback"]
