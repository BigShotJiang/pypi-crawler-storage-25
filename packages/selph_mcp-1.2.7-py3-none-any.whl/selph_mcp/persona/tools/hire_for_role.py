"""Persona ``hire_for_role`` tool (Phase 2 task 12).

Minimal role → workflow_id map. Full LLM dispatch is deferred to
Phase 5; in Phase 2 this tool is intentionally a static lookup so
harnesses have a stable contract to build against. Unrecognized roles
return ``ok=False, data={"status": "unknown_role"}``.

Zero budget cost — registry lookup, no evidence retrieval.
"""
from __future__ import annotations

import logging
import time as _time
from datetime import datetime, timezone
from typing import Dict

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import (
    ConsumerScope,
    ModeUsed,
    PersonaResponse,
)
from selph_mcp.persona import etag as _etag
from selph_mcp.persona.envelope_builder import build_envelope
from selph_mcp.persona.fingerprint import compute_fingerprint
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.tools.hire_for_role")


# Phase-2 static map. Phase 5's `recommend_workflows` replaces this with
# an LLM-driven dispatch that consults the workflow library.
_ROLE_MAP: Dict[str, str] = {
    "bootstrapper": "using-selph",
    "operator": "morning-operator-brief",
    "drafter": "vip-reply-drafting",
    "strategist": "weekly-strategy-memo",
}


def _primary_scope(consumer: Consumer) -> ConsumerScope:
    if consumer.allowed_scopes:
        try:
            return ConsumerScope(consumer.allowed_scopes[0].value)
        except ValueError:
            pass
    return ConsumerScope.personal


async def hire_for_role(
    *,
    consumer: Consumer,
    role: str,
) -> PersonaResponse:
    """Return the workflow_id bound to ``role`` in the Phase 2 static map."""
    t0 = _time.perf_counter()
    log_event(
        _log, logging.INFO, "mcp.persona.hire_for_role.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        role=role,
    )

    scope = _primary_scope(consumer)
    ceiling = consumer.sensitivity_ceiling.value
    normalized_role = (role or "").strip().lower()
    source_cutoff_at = "1970-01-01T00:00:00Z"

    # Phase 1 §1.3: compute fingerprint BEFORE any retrieval.
    _fp = compute_fingerprint(
        tool="hire_for_role",
        params={"role": normalized_role},
        consumer=consumer,
    )
    # hire_for_role is a static role→workflow map lookup (§1.4 aggregate/
    # static lookup, Tier 2 only) — not a synthesis. No hub or memory IDs
    # are cited; the lookup aggregates across the static _ROLE_MAP only.
    _dep_keys = ["scope:self"]

    etag = _etag.generate_etag(
        kind="hire_for_role",
        subject="self",
        intent="operating_manual",
        user_id=consumer.user_id,
        consumer_scope=scope,
        sensitivity_class=ceiling,
        constraints={"role": normalized_role},
        content_cutoff_at=source_cutoff_at,
    )

    workflow_id = _ROLE_MAP.get(normalized_role)
    if workflow_id is None:
        log_event(
            _log, logging.INFO, "mcp.persona.hire_for_role.unknown_role",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            role=role,
            known=list(_ROLE_MAP.keys()),
        )
        return build_envelope(
            mode_used=ModeUsed.none,
            ok=False,
            data={
                "status": "unknown_role",
                "role": role,
                "known_roles": sorted(_ROLE_MAP.keys()),
            },
            citations=[],
            meta_inputs={
                "source_cutoff_at": source_cutoff_at,
                "staleness_status": "fresh",
                "confidence": 1.0,
                "etag": etag,
                "budget_tier": consumer.budget_tier.value,
                "consumer_scope": scope,
                "sensitivity_class": ceiling,
            },
            query_fingerprint=_fp,
            dependency_keys=[],
        )

    envelope = build_envelope(
        mode_used=ModeUsed.brief,
        data={
            "status": "ok",
            "role": normalized_role,
            "workflow_id": workflow_id,
        },
        citations=[],
        meta_inputs={
            "source_cutoff_at": source_cutoff_at,
            "staleness_status": "fresh",
            "confidence": 1.0,
            "etag": etag,
            "budget_tier": consumer.budget_tier.value,
            "consumer_scope": scope,
            "sensitivity_class": ceiling,
        },
        suggested_next_actions=[
            f"Install the '{workflow_id}' workflow via the harness adapter.",
        ],
        query_fingerprint=_fp,
        dependency_keys=_dep_keys,
    )
    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    log_event(
        _log, logging.INFO, "mcp.persona.hire_for_role.complete",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        role=normalized_role,
        workflow_id=workflow_id,
        duration_ms=duration_ms,
    )
    return envelope


__all__ = ["hire_for_role"]
