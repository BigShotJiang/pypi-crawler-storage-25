"""Persona ``recommend_workflows`` tool (Phase 5).

Returns three ranked workflow recommendations with heuristic scores,
top_reasons, supporting_signals, missing_information, and feedback_event_key.

Budget: brief (0.2 credits). Citations: empty (ranker aggregates across hubs
and memory counts — no individual memory IDs to cite).

Etag is derived deterministically from the signals dict hash, not from wall
clock — identical signal values for the same consumer produce the same etag.

Logging: entry with consumer_id / user_id; exit with mode_used, duration_ms,
etag, budget_tier (per naming-and-constraints.md mandatory coverage).
"""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Dict, List

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import (
    ConsumerScope,
    ModeUsed,
    PersonaResponse,
)
from selph_mcp.persona import budget as _budget
from selph_mcp.persona import etag as _etag
from selph_mcp.persona.envelope_builder import build_envelope
from selph_mcp.persona.fingerprint import compute_fingerprint
from selph_mcp.persona.ranker import gather_signals, score_workflows, signals_hash
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.tools.recommend_workflows")

_MODE = "brief"
_EPOCH_FALLBACK = "1970-01-01T00:00:00Z"


def _primary_scope(consumer: Consumer) -> ConsumerScope:
    if consumer.allowed_scopes:
        try:
            return ConsumerScope(consumer.allowed_scopes[0].value)
        except ValueError:
            pass
    return ConsumerScope.personal


async def recommend_workflows(
    *,
    consumer: Consumer,
) -> PersonaResponse:
    """Return ranked workflow recommendations for *consumer*.

    Args:
        consumer: Authenticated consumer (``user_id`` sourced from binding).

    Returns:
        Envelope with:
          ``mode_used = "brief"``
          ``data = {"recommendations": [...]}``
          ``citations = []``

    Never raises — fail-soft at every layer (ranker, budget, envelope
    assembly). A fresh user with zero graph data gets three low-confidence
    entries with ``missing_information`` populated.
    """
    t0 = _time.perf_counter()
    scope = _primary_scope(consumer)

    log_event(
        _log, logging.INFO, "mcp.persona.recommend_workflows.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        subject="self",
        intent="workflow_recommendation",
    )

    # Phase 1 §1.3: compute fingerprint BEFORE any retrieval.
    _fp = compute_fingerprint(
        tool="recommend_workflows",
        params={"subject": "self", "intent": "workflow_recommendation"},
        consumer=consumer,
    )
    # recommend_workflows is an aggregate/statistical response (§1.4
    # emission policy) — Tier 2 only. No individual entity or memory IDs
    # are cited; the result aggregates across hubs and memory counts.
    _dep_keys = ["scope:self"]

    # ── Budget gate (brief = 0.2 credits) ──────────────────────────────────
    # Fail-soft: budget exceptions are logged but do not abort the read —
    # the ranker result is returned even if the budget ledger is unreachable.
    budget_ok = True
    remaining_str = "unknown"
    try:
        await _budget.ensure_today_row(
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            budget_tier=consumer.budget_tier,
        )
        remaining, budget_ok = await _budget.check_and_decrement(
            consumer.consumer_id, _MODE
        )
        remaining_str = str(remaining)
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.WARNING,
            "mcp.persona.recommend_workflows.budget_failed",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            error_type=type(exc).__name__,
            error=str(exc)[:200],
        )
        budget_ok = True  # fail-open on budget errors per Phase 2 contract

    if not budget_ok:
        # Budget exhausted — return a terse ok=False envelope.
        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.WARNING,
            "mcp.persona.recommend_workflows.budget_exhausted",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            duration_ms=duration_ms,
        )
        from selph_mcp.contracts.envelope import BudgetTier as _BT
        exhausted_etag = _etag.generate_etag(
            kind="recommend_workflows",
            subject="self",
            intent="workflow_recommendation",
            user_id=consumer.user_id,
            consumer_scope=scope,
            sensitivity_class=consumer.sensitivity_ceiling.value,
            constraints={"budget": "exhausted"},
            content_cutoff_at=_EPOCH_FALLBACK,
        )
        return build_envelope(
            mode_used=ModeUsed.none,
            ok=False,
            data=None,
            citations=[],
            meta_inputs={
                "source_cutoff_at": _EPOCH_FALLBACK,
                "staleness_status": "fresh",
                "confidence": 0.0,
                "etag": exhausted_etag,
                "budget_tier": _BT.exhausted.value,
                "consumer_scope": scope,
                "sensitivity_class": consumer.sensitivity_ceiling.value,
            },
            query_fingerprint=_fp,
            dependency_keys=[],
        )

    # ── Score workflows ─────────────────────────────────────────────────────
    recommendations: List[Dict[str, Any]] = await score_workflows(consumer)

    # ── Etag: deterministic from signals hash ───────────────────────────────
    # We call gather_signals a second time here only when needed for the etag
    # hash. To avoid double I/O on the hot path, we derive the hash from the
    # scores dict instead (same determinism property).
    # Build a stable proxy from the supporting_signals across all recs.
    all_signals_proxy: Dict[str, float] = {}
    for rec in recommendations:
        for sn, sv in rec.get("supporting_signals", {}).items():
            if sn not in all_signals_proxy or sv > all_signals_proxy[sn]:
                all_signals_proxy[sn] = sv
    content_cutoff = signals_hash(all_signals_proxy) if all_signals_proxy else _EPOCH_FALLBACK
    # signals_hash returns a 12-hex digest string or epoch fallback — both are
    # valid content_cutoff_at values for etag_for (accepts str)
    # We need a proper timestamp-like string for the etag. Use epoch when
    # signals are zero; otherwise embed the hash as part of the constraint.
    etag = _etag.generate_etag(
        kind="recommend_workflows",
        subject="self",
        intent="workflow_recommendation",
        user_id=consumer.user_id,
        consumer_scope=scope,
        sensitivity_class=consumer.sensitivity_ceiling.value,
        constraints={"signals_hash": content_cutoff},
        content_cutoff_at=_EPOCH_FALLBACK,
    )

    # ── Build envelope ──────────────────────────────────────────────────────
    confidence = (
        max((rec["confidence"] for rec in recommendations), default=0.3)
        if recommendations else 0.3
    )
    staleness_label = "fresh"

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    log_event(
        _log, logging.INFO, "mcp.persona.recommend_workflows.complete",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        mode_used=_MODE,
        etag=etag,
        budget_tier=consumer.budget_tier.value,
        rec_count=len(recommendations),
        duration_ms=duration_ms,
    )

    return build_envelope(
        mode_used=ModeUsed.brief,
        data={"recommendations": recommendations},
        citations=[],
        meta_inputs={
            "source_cutoff_at": _EPOCH_FALLBACK,
            "staleness_status": staleness_label,
            "confidence": confidence,
            "etag": etag,
            "budget_tier": consumer.budget_tier.value,
            "consumer_scope": scope,
            "sensitivity_class": consumer.sensitivity_ceiling.value,
        },
        query_fingerprint=_fp,
        dependency_keys=_dep_keys,
    )


__all__ = ["recommend_workflows"]
