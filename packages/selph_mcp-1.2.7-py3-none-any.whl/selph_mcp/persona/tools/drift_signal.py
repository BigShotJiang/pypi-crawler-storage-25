"""Persona ``drift_signal`` tool (Phase 3, §3.3).

Harness flags that its local cache disagrees with Selph (the etag it is
holding no longer matches what the server would produce for the same
logical request). Logged to ``mcp_drift_signals`` via the engine bridge
route ``POST /apps/mcp/consumers/{consumer_id}/drift-signals`` for
offline investigation; no live mutation + no etag invalidation.

Drift signals surface staleness bugs that the etag invalidation
pipeline missed. Operators join drift rows back to the underlying
``mcp_etag_invalidations`` log to diagnose flaky adapters.

Zero budget cost — diagnostic writes are free.

Channel vs ``mode_used`` (deferred contract note):
    :class:`ModeUsed` is a Phase 1a-frozen read-side enum — there is
    no ``"drift_signal"`` value. To stay contract-clean we report
    ``mode_used=ModeUsed.brief`` (the smallest read-shape) and surface
    the real channel via ``data["channel"] = "drift_signal"``.

Anti-bypass:
    ``user_id`` + ``consumer_id`` on the ``mcp_drift_signals`` row are
    ALWAYS taken from the authenticated :class:`Consumer`. The caller
    cannot forge those values via tool args — the MCP handler doesn't
    accept them and the persona tool doesn't look at them.

No direct imports of ``selph_db``. Delegates via HTTP to the engine.
"""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Dict

from fastapi import HTTPException

from selph_mcp._client import EngineUpstreamError, get_client
from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import (
    ConsumerScope,
    ModeUsed,
    PersonaResponse,
)
from selph_mcp.persona import etag as _etag
from selph_mcp.persona.envelope_builder import build_envelope
from selph_mcp.persona.fingerprint import compute_fingerprint
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.tools.drift_signal")

_EPOCH_FALLBACK: str = "1970-01-01T00:00:00Z"


def _primary_scope(consumer: Consumer) -> ConsumerScope:
    """Pick the consumer's primary scope for etag hashing.

    Same fallback shape as the other writeback tools (observe_session,
    correct, recommendation_feedback) — defaults to
    :attr:`ConsumerScope.personal` if the consumer row is missing
    allowed_scopes or the value doesn't round-trip through the envelope
    enum.
    """
    if consumer.allowed_scopes:
        try:
            return ConsumerScope(consumer.allowed_scopes[0].value)
        except ValueError:
            pass
    return ConsumerScope.personal


async def drift_signal(
    *,
    consumer: Consumer,
    etag: str,
    observed_local_state: Dict[str, Any],
) -> PersonaResponse:
    """Log a harness-reported drift signal.

    Args:
        consumer: Authenticated consumer (supplies ``consumer_id`` +
            ``user_id`` for the DB row — never accepts caller-supplied
            overrides).
        etag: The etag the harness was operating on when it detected
            drift. Persisted to ``mcp_drift_signals.etag`` verbatim.
        observed_local_state: Dict describing what the harness saw
            locally. Persisted to ``mcp_drift_signals.observed_local_state``
            (JSONB) for offline analysis.

    Returns:
        A :class:`PersonaResponse` envelope with
        ``data = {"channel": "drift_signal", "signal_id": <bigserial>}``.

    Raises:
        HTTPException(400): when ``etag`` is empty or
            ``observed_local_state`` is not a dict.

    Note:
        Does NOT emit etag invalidations — drift is informational
        only. The manager writes to ``mcp_drift_signals``, not to
        ``mcp_etag_invalidations``.
    """
    t0 = _time.perf_counter()
    log_event(
        _log, logging.INFO, "mcp.persona.drift_signal.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        etag=etag,
    )

    # ── Surface-layer validation (pre-emptive) ────────────────────────
    cleaned_etag = (etag or "").strip()
    if not cleaned_etag:
        log_event(
            _log, logging.WARNING, "mcp.persona.drift_signal.empty_etag",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
        )
        raise HTTPException(
            status_code=400,
            detail="drift_signal requires a non-empty etag.",
        )
    if not isinstance(observed_local_state, dict):
        log_event(
            _log, logging.WARNING,
            "mcp.persona.drift_signal.bad_observed_local_state",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            observed_type=type(observed_local_state).__name__,
        )
        raise HTTPException(
            status_code=400,
            detail="drift_signal requires observed_local_state to be a dict.",
        )

    scope = _primary_scope(consumer)
    ceiling = consumer.sensitivity_ceiling.value

    # Phase 1 §1.3: fingerprint BEFORE any write.  Drift ack →
    # empty dependency_keys.
    _fp = compute_fingerprint(
        tool="drift_signal",
        params={"etag": cleaned_etag},
        consumer=consumer,
    )

    # ── Engine write (HTTP) ────────────────────────────────────────────
    try:
        resp = await get_client().post(
            "/apps/mcp/drift-signals",
            json={
                "etag": cleaned_etag,
                "observed_local_state": observed_local_state,
            },
        )
        signal_id = int(resp["signal_id"])
    except EngineUpstreamError as exc:
        if exc.status_code == 400:
            log_event(
                _log, logging.WARNING,
                "mcp.persona.drift_signal.validation_failed",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                etag=cleaned_etag,
                error=str(exc),
            )
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        log_event(
            _log, logging.ERROR,
            "mcp.persona.drift_signal.engine_error",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            etag=cleaned_etag,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise HTTPException(
            status_code=502,
            detail=f"Engine returned an error persisting drift signal: {exc}",
        ) from exc

    # ── Envelope assembly ────────────────────────────────────────────
    response_etag = _etag.generate_etag(
        kind="drift_signal",
        subject="self",
        intent="briefing",
        user_id=consumer.user_id,
        consumer_scope=scope,
        sensitivity_class=ceiling,
        constraints={
            "signal_id": signal_id,
        },
        content_cutoff_at=_EPOCH_FALLBACK,
    )

    envelope = build_envelope(
        mode_used=ModeUsed.brief,
        ok=True,
        data={
            "channel": "drift_signal",
            "signal_id": signal_id,
        },
        citations=[],
        meta_inputs={
            "source_cutoff_at": _EPOCH_FALLBACK,
            "staleness_status": "fresh",
            "confidence": 1.0,
            "etag": response_etag,
            "budget_tier": consumer.budget_tier.value,
            "consumer_scope": scope,
            "sensitivity_class": ceiling,
        },
        query_fingerprint=_fp,
        dependency_keys=[],
    )

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    log_event(
        _log, logging.INFO, "mcp.persona.drift_signal.complete",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        signal_id=signal_id,
        duration_ms=duration_ms,
    )
    return envelope


__all__ = ["drift_signal"]
