"""Persona ``get_fingerprint`` tool (Phase 1 §1.7).

Preflight-only endpoint: computes + returns the query fingerprint without
performing any graph read, LLM call, or DB write.  Adapters use this to
check whether a locally cached response is still valid before committing
a full persona read.

Semantics
---------
- No graph read. No LLM. No budget debit beyond the rate-limit charge.
- Rate-limited per consumer at 10× the ``"brief"`` budget cost (0.2
  credits × 10 = 2.0 credits), so a burst of preflight calls is cheap
  but not free.  Discourages scanning.
- Returns ``PersonaResponse`` with:
    ``data = {"query_fingerprint": str,
              "canonicalization_version": str,
              "dependency_vocabulary_version": str}``
- ``meta.query_fingerprint`` is set to the SAME value as
  ``data.query_fingerprint`` — the envelope stamp IS the echo.
- ``meta.dependency_keys`` is empty (this read has no evidence, so
  there are no dependency keys to cover it).

Logging (per rules/naming-and-constraints.md mandatory coverage)
----------------------------------------------------------------
- Entry: ``event="persona.get_fingerprint.entry"`` with
  ``consumer_id``, ``user_id``, ``tool_name``.
- Completion: ``event="persona.get_fingerprint.served"`` with
  ``consumer_id``, ``tool``, ``query_fingerprint``, ``duration_ms``.
- Exception: ``event="persona.get_fingerprint.error"`` with
  ``error_type``, ``error``.
"""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Dict

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import (
    BudgetTier,
    ConsumerScope,
    ModeUsed,
    PersonaResponse,
)
from selph_mcp.contracts.versions import (
    CANONICALIZATION_VERSION,
    DEPENDENCY_VOCABULARY_VERSION,
    RESPONSE_ENVELOPE_VERSION,
)
from selph_mcp.persona import budget as _budget
from selph_mcp.persona.envelope_builder import build_envelope
from selph_mcp.persona.fingerprint import (
    canonicalize_params,
    compute_fingerprint,
    normalize_params_for_tool,
)
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.tools.get_fingerprint")

# Rate limit: 10× cheaper than brief (brief=0.2, get_fingerprint=0.02 credits).
# Uses the dedicated "get_fingerprint" entry in MODE_COSTS — no DB read or LLM
# call is made, so charging the full brief cost (0.2) would be wrong per §1.7.
_GET_FINGERPRINT_COST_STR = "get_fingerprint"

_EPOCH_FALLBACK: str = "1970-01-01T00:00:00Z"


def _primary_scope(consumer: Consumer) -> ConsumerScope:
    if consumer.allowed_scopes:
        try:
            return ConsumerScope(consumer.allowed_scopes[0].value)
        except ValueError:
            pass
    return ConsumerScope.personal


async def get_fingerprint(
    *,
    consumer: Consumer,
    tool: str,
    params: Dict[str, Any],
) -> PersonaResponse:
    """Compute and return the query fingerprint for ``(tool, params, consumer)``.

    Args:
        consumer: The authenticated consumer.
        tool: Persona tool name whose fingerprint is being requested.
        params: Tool parameters dict — same shape the caller would pass to
            the actual tool.

    Returns:
        A :class:`PersonaResponse` envelope with:
          ``data = {"query_fingerprint": str,
                    "canonicalization_version": str,
                    "dependency_vocabulary_version": str}``
        ``meta.query_fingerprint`` is set to the same fingerprint so the
        echo is self-consistent.
    """
    t0 = _time.perf_counter()
    log_event(
        _log, logging.INFO, "persona.get_fingerprint.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        tool_name="get_fingerprint",
        target_tool=tool,
    )

    scope = _primary_scope(consumer)
    ceiling = consumer.sensitivity_ceiling.value

    # Rate-limit gate: charge at the get_fingerprint rate (0.02 credits,
    # = brief / 10, per §1.7 spec).  Discourages scanning without
    # penalising routine preflight checks.  Exhausted → ok=False.
    await _budget.ensure_today_row(
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        budget_tier=consumer.budget_tier,
    )
    decr_remaining, decr_ok = await _budget.check_and_decrement(
        consumer.consumer_id, _GET_FINGERPRINT_COST_STR
    )
    if not decr_ok:
        log_event(
            _log, logging.WARNING, "persona.get_fingerprint.exhausted",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
        )
        return build_envelope(
            mode_used=ModeUsed.none,
            ok=False,
            data=None,
            citations=[],
            meta_inputs={
                "source_cutoff_at": _EPOCH_FALLBACK,
                "staleness_status": "fresh",
                "confidence": 0.0,
                "etag": "get_fingerprint:exhausted:000000000000",
                "budget_tier": BudgetTier.exhausted.value,
                "consumer_scope": scope,
                "sensitivity_class": ceiling,
                "query_fingerprint": "",
                "dependency_keys": [],
            },
        )

    # Canonicalize + fingerprint — pure computation, no I/O.
    # Normalize wire-level params to the same shape the full tool hashes,
    # so preflight fingerprint == full-call fingerprint for the same args.
    vocab_version = str(DEPENDENCY_VOCABULARY_VERSION)
    normalized_params = normalize_params_for_tool(tool, params)
    fp = compute_fingerprint(
        tool=tool,
        params=normalized_params,
        consumer=consumer,
        envelope_version=RESPONSE_ENVELOPE_VERSION,
        vocab_version=vocab_version,
    )

    data = {
        "query_fingerprint": fp,
        "canonicalization_version": str(CANONICALIZATION_VERSION),
        "dependency_vocabulary_version": vocab_version,
    }

    # Etag for this response is just the fingerprint itself — the response
    # IS the fingerprint computation.
    etag = fp

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    log_event(
        _log, logging.INFO, "persona.get_fingerprint.served",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        tool=tool,
        query_fingerprint=fp,
        duration_ms=duration_ms,
    )

    return build_envelope(
        mode_used=ModeUsed.brief,
        ok=True,
        data=data,
        citations=[],
        meta_inputs={
            "source_cutoff_at": _EPOCH_FALLBACK,
            "staleness_status": "fresh",
            "confidence": 1.0,
            "etag": etag,
            "budget_tier": consumer.budget_tier.value,
            "consumer_scope": scope,
            "sensitivity_class": ceiling,
            "query_fingerprint": fp,
            "dependency_keys": [],
        },
    )


__all__ = ["get_fingerprint"]
