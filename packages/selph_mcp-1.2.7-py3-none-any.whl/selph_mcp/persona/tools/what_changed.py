"""Persona ``what_changed`` tool (Phase 2 task 9).

Reports invalidation rows from ``mcp_etag_invalidations`` since a
caller-provided cursor (or the consumer's stored ``etag_cursor`` when
the caller omits it). Zero budget cost — cache-coherence reads are
free.

Channel vs ``mode_used`` (deferred contract note):
    ``mode_used`` on the returned envelope is a :class:`ModeUsed`
    enum value frozen by the Phase 1a contract — ``"what_changed"``
    is NOT one of them. To stay contract-clean in Phase 2 we return
    ``mode_used=ModeUsed.targeted`` (the route the read took) and
    surface the real channel via ``data["channel"] = "what_changed"``.
    Harnesses that need to distinguish the call type must read
    ``data["channel"]``, not ``mode_used``. Promoting ``what_changed``
    into :class:`ModeUsed` would require a contract bump and is
    deferred beyond Phase 2.
"""
from __future__ import annotations

import asyncio
import logging
import time as _time
from typing import List, Optional

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.invalidations import InvalidationRow
from selph_mcp.contracts.envelope import (
    ConsumerScope,
    ModeUsed,
    PersonaResponse,
)
from selph_mcp.persona import etag as _etag
from selph_mcp.persona.envelope_builder import build_envelope
from selph_mcp.persona.fingerprint import compute_fingerprint, normalize_params_for_tool
from selph_mcp.contracts.versions import (
    DEPENDENCY_VOCABULARY_VERSION,
    RESPONSE_ENVELOPE_VERSION,
)
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.tools.what_changed")


def _primary_scope(consumer: Consumer) -> ConsumerScope:
    if consumer.allowed_scopes:
        try:
            return ConsumerScope(consumer.allowed_scopes[0].value)
        except ValueError:
            pass
    return ConsumerScope.personal


async def what_changed(
    *,
    consumer: Consumer,
    since_cursor: Optional[int] = None,
) -> PersonaResponse:
    """Return invalidation rows newer than ``since_cursor``.

    Args:
        consumer: The authenticated consumer (supplies ``user_id`` via
            binding).
        since_cursor: The consumer's last-seen invalidation ``seq``.
            Defaults to ``consumer.etag_cursor`` when omitted so the
            first call after a reconnect gets the full backlog.

    Returns:
        Envelope with ``data = {"channel": "what_changed",
                               "invalidations": [...], "latest_seq": int}``.
    """
    t0 = _time.perf_counter()
    effective_cursor = (
        since_cursor if since_cursor is not None else int(consumer.etag_cursor or 0)
    )
    log_event(
        _log, logging.INFO, "mcp.persona.what_changed.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        since_cursor=effective_cursor,
    )

    rows: List[InvalidationRow] = await _etag.list_invalidations_since(
        consumer.consumer_id, consumer.user_id, effective_cursor
    )
    # invalidated_at is already an ISO-8601 string per InvalidationRow schema.

    latest_seq = (
        int(max(row.seq for row in rows)) if rows else effective_cursor
    )

    # Phase 1 §1.6: dependency_keys is not a field on InvalidationRow —
    # the server does not return it.  Invalidated_keys remains empty;
    # the what_changed feed IS the invalidation surface (spec §1.4).
    invalidated_keys: List[str] = []

    scope = _primary_scope(consumer)

    # Phase 1 §1.3: compute fingerprint BEFORE any retrieval.  Dependency keys
    # remain [] — what_changed IS the invalidation feed (spec §1.4).
    # Fingerprint is keyed by the CALLER-SUPPLIED since_cursor (None when not
    # sent), NOT the server-resolved effective_cursor.  This ensures that the
    # preflight get_fingerprint call (which also passes the raw wire arg) and
    # this full-call path produce identical hashes for the same request.
    # See canonicalization_spec §1.1 defaults-fold note for what_changed.
    _fp = compute_fingerprint(
        tool="what_changed",
        params=normalize_params_for_tool(
            "what_changed", {"since_cursor": since_cursor}
        ),
        consumer=consumer,
        envelope_version=RESPONSE_ENVELOPE_VERSION,
        vocab_version=str(DEPENDENCY_VOCABULARY_VERSION),
    )

    # Fix D: derive cutoff from the invalidation rows' ``invalidated_at``
    # field (already normalized to ISO strings above). Empty rows →
    # deterministic epoch fallback. Wall-clock ``now()`` is explicitly
    # NOT used — same (since_cursor, current latest_seq) must hash to
    # the same etag across repeated calls.
    source_cutoff_at = _etag.derive_content_cutoff(rows)
    etag = _etag.generate_etag(
        kind="what_changed",
        subject="self",
        intent="briefing",
        user_id=consumer.user_id,
        consumer_scope=scope,
        sensitivity_class=consumer.sensitivity_ceiling.value,
        constraints={"since_cursor": effective_cursor},
        content_cutoff_at=source_cutoff_at,
    )

    staleness_label = "stale" if rows else "fresh"
    envelope = build_envelope(
        mode_used=ModeUsed.targeted,
        data={
            "channel": "what_changed",
            # Phase 1 §1.6: new canonical fields.
            "cursor": latest_seq,
            "invalidated_keys": invalidated_keys,
            # Legacy fields retained for back-compat during transition.
            "since_cursor": effective_cursor,
            "latest_seq": latest_seq,
            "invalidations": [r.model_dump(mode="json") for r in rows],
            "count": len(rows),
        },
        citations=[],
        meta_inputs={
            "source_cutoff_at": source_cutoff_at,
            "staleness_status": staleness_label,
            "confidence": 1.0,
            "etag": etag,
            "budget_tier": consumer.budget_tier.value,
            "consumer_scope": scope,
            "sensitivity_class": consumer.sensitivity_ceiling.value,
        },
        # what_changed has no dependency_keys — it IS the invalidation feed.
        query_fingerprint=_fp,
        dependency_keys=[],
    )

    # Phase 6 cursor bump — what_changed is the ONLY tool that delivers the
    # full invalidation set to the adapter and therefore the ONLY place the
    # cursor should advance.  We bump directly here (not via build_envelope)
    # so the advance is scoped to a confirmed delivery event and cannot
    # silently skip a future invalidation for a different key.
    if rows and latest_seq > effective_cursor:
        from selph_db import mcp_consumer_manager as _cm  # local import — DB layer

        def _do_bump() -> None:
            try:
                _cm.bump_etag_cursor(consumer.consumer_id, latest_seq)
            except Exception as exc:  # noqa: BLE001
                log_event(
                    _log, logging.WARNING,
                    "mcp.persona.what_changed.cursor_bump_failed",
                    consumer_id=consumer.consumer_id,
                    latest_seq=latest_seq,
                    error_type=type(exc).__name__,
                    error=str(exc)[:300],
                )

        try:
            loop = asyncio.get_running_loop()
            task = loop.run_in_executor(None, _do_bump)

            def _on_done(t: "asyncio.Future[Any]") -> None:
                if not t.cancelled() and t.exception() is not None:
                    log_event(
                        _log, logging.WARNING,
                        "mcp.persona.what_changed.cursor_bump_executor_error",
                        consumer_id=consumer.consumer_id,
                        latest_seq=latest_seq,
                        error_type=type(t.exception()).__name__,
                        error=str(t.exception())[:300],
                    )

            task.add_done_callback(_on_done)
        except RuntimeError:
            # No running event loop (e.g. unit-test context) — skip silently.
            pass
        except Exception as exc:  # noqa: BLE001 — event-loop-shutdown safety
            log_event(
                _log, logging.WARNING,
                "mcp.persona.what_changed.cursor_bump_schedule_failed",
                consumer_id=consumer.consumer_id,
                latest_seq=latest_seq,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    log_event(
        _log, logging.INFO, "mcp.persona.what_changed.complete",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        since_cursor=effective_cursor,
        latest_seq=latest_seq,
        row_count=len(rows),
        duration_ms=duration_ms,
    )
    return envelope


__all__ = ["what_changed"]
