"""Persona MCP tool handlers (Phase 2).

Each module under :mod:`selph_mcp.persona.tools` exposes one async
entry point that the FastMCP server registers as a tool. Handlers are
deliberately thin — they adapt tool parameters to the kernel contract,
run the depth router / budget / etag pipeline, and package the result
via :func:`selph_mcp.persona.envelope_builder.build_envelope`.
"""

__all__: list[str] = []
