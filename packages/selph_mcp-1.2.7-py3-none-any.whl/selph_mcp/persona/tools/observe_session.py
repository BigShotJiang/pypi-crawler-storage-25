"""Persona ``observe_session`` tool (Phase 2 task 13).

Thin wrapper around :func:`selph_mcp.kernel.observe.observe_session`.
Default mode is ``store_raw_only`` per §3.3.1. Returns an envelope
with a citation pointing at the newly minted ``raw_evidence_id``.

Zero budget cost — writes are free.

Channel vs ``mode_used`` (deferred contract note):
    :class:`ModeUsed` is a Phase 1a-frozen read-side enum (``brief``,
    ``targeted``, ``insight``, ``evidence``, ``none``) — there is no
    ``"writeback"`` value. To stay contract-clean we report
    ``mode_used=ModeUsed.brief`` (the smallest read-shape) and surface
    the real channel via ``data["channel"] = "writeback"``. Harnesses
    that need to distinguish writeback from a read must branch on
    ``data["channel"]``, not ``mode_used``. Adding a first-class
    writeback ``mode_used`` value is a future contract bump — deferred
    beyond Phase 2.
"""
from __future__ import annotations

import logging
import time as _time
from datetime import datetime, timezone
from typing import Any, Optional

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import (
    Citation,
    ConsumerScope,
    ModeUsed,
    PersonaResponse,
    RefType,
)
from selph_mcp.contracts.writeback import IngestMode, SessionObservation
from selph_mcp.kernel import observe as kernel_observe
from selph_mcp.persona import etag as _etag
from selph_mcp.persona.envelope_builder import build_envelope
from selph_mcp.persona.fingerprint import compute_fingerprint
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.tools.observe_session")


def _primary_scope(consumer: Consumer) -> ConsumerScope:
    if consumer.allowed_scopes:
        try:
            return ConsumerScope(consumer.allowed_scopes[0].value)
        except ValueError:
            pass
    return ConsumerScope.personal


async def observe_session(
    *,
    consumer: Consumer,
    observation: SessionObservation,
    graph: Any = None,
) -> PersonaResponse:
    """Persist a session observation as Layer 1 raw_evidence.

    The kernel adapter handles the consumer/user binding anti-bypass,
    L1 write, and (optional) deep_ingest pipeline. This wrapper just
    shapes the response envelope.
    """
    t0 = _time.perf_counter()
    log_event(
        _log, logging.INFO, "mcp.persona.observe_session.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        session_id=observation.session_id,
        mode=observation.mode.value,
        text_len=len(observation.text or ""),
    )

    scope = _primary_scope(consumer)
    ceiling = consumer.sensitivity_ceiling.value

    # Phase 1 §1.3: fingerprint BEFORE retrieval.  Writeback ack →
    # empty dependency_keys (spec: writebacks do not carry dep keys).
    _fp = compute_fingerprint(
        tool="observe_session",
        params={
            "session_id": observation.session_id,
            "mode": observation.mode.value,
        },
        consumer=consumer,
    )

    result = await kernel_observe.observe_session(
        consumer=consumer,
        observation=observation,
        graph=graph,
    )

    raw_evidence_id = result.get("raw_evidence_id")
    citations = []
    if raw_evidence_id:
        try:
            citations.append(
                Citation(
                    ref_type=RefType.observation,
                    ref_id=str(raw_evidence_id),
                    layer=1,
                    captured_at=observation.captured_at,
                )
            )
        except Exception:  # noqa: BLE001
            pass

    captured = observation.captured_at
    source_cutoff_at = (
        captured.isoformat() if hasattr(captured, "isoformat") else str(captured)
    )
    etag = _etag.generate_etag(
        kind="writeback",
        subject="self",
        intent="briefing",
        user_id=consumer.user_id,
        consumer_scope=scope,
        sensitivity_class=ceiling,
        constraints={
            "session_id": observation.session_id,
            "mode": observation.mode.value,
        },
        content_cutoff_at=source_cutoff_at,
    )

    # ``mode_used`` must be a :class:`ModeUsed` value — there is no
    # "writeback" enum in Phase 1a (ModeUsed is read-side). We report
    # ``brief`` (smallest footprint) and surface the real channel in
    # ``data.channel`` so harnesses can differentiate. This keeps the
    # Phase 1a envelope contract frozen.
    envelope = build_envelope(
        mode_used=ModeUsed.brief,
        ok=bool(result.get("status") == "ok"),
        data={
            "channel": "writeback",
            "raw_evidence_id": raw_evidence_id,
            "mode": result.get("mode"),
            "extraction": result.get("extraction"),
        },
        citations=citations,
        meta_inputs={
            "source_cutoff_at": source_cutoff_at,
            "staleness_status": "fresh",
            "confidence": 1.0,
            "etag": etag,
            "budget_tier": consumer.budget_tier.value,
            "consumer_scope": scope,
            "sensitivity_class": ceiling,
        },
        query_fingerprint=_fp,
        dependency_keys=[],
    )

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    log_event(
        _log, logging.INFO, "mcp.persona.observe_session.complete",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        session_id=observation.session_id,
        raw_evidence_id=raw_evidence_id,
        mode=result.get("mode"),
        duration_ms=duration_ms,
    )
    return envelope


__all__ = ["observe_session"]
