"""Correction payload (``correction_payload_v1``).

Implements §3.4 of the implementation plan. ``persona.correct(...)`` MUST
compile 1:1 to a concrete kernel HTTP call via the table embedded in
:class:`CorrectionAction`'s docstring.  Every cell in that table maps to
a real mounted route; see ``selph_mcp/kernel/revise.py`` for the full
routing logic.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict, Field


class CorrectionTargetType(str, Enum):
    """What is being corrected."""

    entity_field_observation = "entity_field_observation"
    memory = "memory"
    identity_claim = "identity_claim"
    recommendation = "recommendation"


class CorrectionAction(str, Enum):
    """Persona-layer correction verb.

    Persona → kernel compile table (§3.4 — all 12 cells live):

    | Persona action        | Persona target_type           | HTTP route (mounted path)                                      |
    |-----------------------|-------------------------------|----------------------------------------------------------------|
    | replace               | entity_field_observation      | POST /core/revise/  action=correct                             |
    | retract               | entity_field_observation      | POST /core/revise/  action=retract                             |
    | expire                | entity_field_observation      | POST /apps/correction/corrections/entity-field?user_id=…       |
    |                       |                               |   body: {operation:"expire", target_observation_id:int, …}    |
    | reattribute           | entity_field_observation      | POST /apps/correction/corrections/entity-field?user_id=…       |
    |                       |                               |   body: {operation:"reattribute", target_observation_id:int, …}|
    | replace               | memory                        | POST /core/revise/  action=correct                             |
    | retract               | memory                        | POST /core/revise/  action=retract                             |
    | expire                | memory                        | POST /core/revise/  action=reject                              |
    | reinstate             | memory                        | POST /core/revise/  action=accept                              |
    | reattribute           | memory                        | POST /apps/correction/corrections/memory?user_id=…             |
    |                       |                               |   body: {operation:"reattribute_entity", memory_id, …}        |
    | supersede             | memory                        | POST /core/revise/  action=supersede                           |
    | supersede             | identity_claim                | POST /core/revise/  action=supersede                           |
    | reject_recommendation | recommendation                | POST /apps/mcp/recommendation-feedback                         |
    |                       |                               |   body: {feedback_event_key, outcome:"rejected", notes}        |

    The ``/core/revise/`` arms build a typed ``RevisionRequest`` and post
    ``.model_dump(mode="json")`` — the ``RevisionAction`` values are
    lowercase (``correct``, ``retract``, etc.) per the Core enum.
    The ``/apps/correction/`` arms pass ``?user_id=`` as a query param.
    The ``/apps/mcp/recommendation-feedback`` arm sends no ``user_id``
    in the body — the server reads identity from the Bearer token.
    """

    replace = "replace"
    retract = "retract"
    expire = "expire"
    reattribute = "reattribute"
    reinstate = "reinstate"
    supersede = "supersede"
    reject_recommendation = "reject_recommendation"


class ObservedIn(BaseModel):
    """Where the correction originated — consumer/harness/session triple."""

    model_config = ConfigDict(extra="forbid")

    consumer_id: str
    harness_id: str
    session_id: str


class CorrectionPayload(BaseModel):
    """Structured revision request from a persona consumer."""

    model_config = ConfigDict(extra="forbid")

    target_type: CorrectionTargetType
    target_id: str = Field(
        ...,
        description=(
            "What is being corrected: an `observation_id`, a `MEM-…` id, an "
            "`entity_id+field` composite, or a `feedback_event_key` for "
            "recommendation rejections."
        ),
    )
    action: CorrectionAction
    reason: str = Field(..., description="Human-readable rationale required for audit.")
    new_state: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Replacement payload — required for `replace`/`supersede`, optional otherwise.",
    )
    effective_at: Optional[datetime] = Field(
        default=None,
        description="ISO-8601 timestamp at which the correction takes effect.",
    )
    confidence_override: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Optional override for the post-correction confidence score.",
    )
    observed_in: ObservedIn


__all__ = [
    "CorrectionTargetType",
    "CorrectionAction",
    "ObservedIn",
    "CorrectionPayload",
]
