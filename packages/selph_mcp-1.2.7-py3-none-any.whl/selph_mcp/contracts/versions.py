"""Contract version constants for the Selph MCP persona/kernel surfaces.

Versioning follows §3.6 of the implementation plan
(`docs/selph_mcp_distribution_implementation_plan.md`) and §1.8 of the
Harness Context Strategy implementation plan
(`docs/selph_harness_context_implementation_plan.md`) — ten distinct axes,
loaded from the sibling `contract_versions.json` file so every model can stamp
the active version into responses without scattering literal numbers across
the codebase.

Bumping any version requires updating `contract_versions.json` AND any
downstream tag/migration steps documented in the plan.

`MEMORY_BOUNDARY_POLICY_VERSION` is a standalone constant (not in
`contract_versions.json`) that tracks the in-effect memory-boundary policy
as defined in `docs/selph_conversational_memory_boundary_strategy.md`.
It is surfaced via `GET /apps/mcp/whoami` so harness bootstrap can detect
policy drift and trigger upgrade proposals (§4.6 / §4.7 of the brief).
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Final

from pydantic import BaseModel, ConfigDict, Field

_VERSIONS_PATH: Final[Path] = Path(__file__).with_name("contract_versions.json")


class ContractVersions(BaseModel):
    """Strict, validated view of `contract_versions.json`."""

    model_config = ConfigDict(extra="forbid")

    persona_contract_version: int = Field(..., ge=1)
    workflow_spec_version: int = Field(..., ge=1)
    harness_adapter_version: int = Field(..., ge=1)
    connector_requirements_version: int = Field(..., ge=1)
    response_envelope_version: int = Field(..., ge=1)
    writeback_event_version: int = Field(..., ge=1)
    correction_payload_version: int = Field(..., ge=1)
    # Phase 1 harness context axes (§1.8 of harness context implementation plan)
    canonicalization_version: int = Field(..., ge=1)
    dependency_vocabulary_version: int = Field(..., ge=1)
    get_fingerprint_endpoint_version: int = Field(..., ge=1)


@lru_cache(maxsize=1)
def load_contract_versions() -> ContractVersions:
    """Load and cache the canonical contract versions from JSON."""
    with _VERSIONS_PATH.open("r", encoding="utf-8") as fh:
        raw = json.load(fh)
    return ContractVersions.model_validate(raw)


_versions = load_contract_versions()

# Module-level constants — preferred call site for any model that needs to
# stamp the active version into a payload.
PERSONA_CONTRACT_VERSION: Final[int] = _versions.persona_contract_version
WORKFLOW_SPEC_VERSION: Final[int] = _versions.workflow_spec_version
HARNESS_ADAPTER_VERSION: Final[int] = _versions.harness_adapter_version
CONNECTOR_REQUIREMENTS_VERSION: Final[int] = _versions.connector_requirements_version
RESPONSE_ENVELOPE_VERSION: Final[int] = _versions.response_envelope_version
WRITEBACK_EVENT_VERSION: Final[int] = _versions.writeback_event_version
CORRECTION_PAYLOAD_VERSION: Final[int] = _versions.correction_payload_version
# Phase 1 harness context constants
CANONICALIZATION_VERSION: Final[int] = _versions.canonicalization_version
DEPENDENCY_VOCABULARY_VERSION: Final[int] = _versions.dependency_vocabulary_version
GET_FINGERPRINT_ENDPOINT_VERSION: Final[int] = _versions.get_fingerprint_endpoint_version

# Memory-boundary policy version (Phase A, §4.2 / §4.6 of the conversational
# memory-boundary strategy). Standalone constant — not in contract_versions.json
# because it is a policy axis, not a wire-contract axis. Surfaced via whoami so
# harness bootstrap can detect policy drift and fire upgrade proposals.
MEMORY_BOUNDARY_POLICY_VERSION: Final[int] = 1


__all__ = [
    "ContractVersions",
    "load_contract_versions",
    "PERSONA_CONTRACT_VERSION",
    "WORKFLOW_SPEC_VERSION",
    "HARNESS_ADAPTER_VERSION",
    "CONNECTOR_REQUIREMENTS_VERSION",
    "RESPONSE_ENVELOPE_VERSION",
    "WRITEBACK_EVENT_VERSION",
    "CORRECTION_PAYLOAD_VERSION",
    "CANONICALIZATION_VERSION",
    "DEPENDENCY_VOCABULARY_VERSION",
    "GET_FINGERPRINT_ENDPOINT_VERSION",
    "MEMORY_BOUNDARY_POLICY_VERSION",
]
