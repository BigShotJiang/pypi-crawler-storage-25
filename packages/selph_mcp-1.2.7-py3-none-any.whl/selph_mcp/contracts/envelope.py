"""Common response envelope for every Selph persona MCP read tool.

Implements §3.1 of `docs/selph_mcp_distribution_implementation_plan.md`:

- `PersonaResponse[T]`: generic envelope returned by every persona read.
- `MetaBlock`: nested freshness / scope / etag metadata.
- `Citation` + `RefType`: typed citation contract referencing canonical IDs
  defined in `rules/data-models.md` (memory `MEM-…`, entity `ENT-…`,
  hub `HUB-…`, observation IDs).
- `etag_for(...)`: deterministic etag generator. The etag is bound to
  `(user_id, consumer_scope, sensitivity_class)` so two consumers at
  different scopes get different etags for the same logical request.

The etag uses sha256 of a canonical JSON serialization (sorted keys,
no whitespace) of the hash_input shape from §3.1, then takes the first
12 hex characters. Including contract versions in the hash forces natural
invalidation on schema bumps.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime
from enum import Enum
from typing import Any, Generic, List, Literal, Optional, TypeVar

from pydantic import BaseModel, ConfigDict, Field, model_validator

from selph_mcp.contracts.versions import (
    DEPENDENCY_VOCABULARY_VERSION,
    PERSONA_CONTRACT_VERSION,
    RESPONSE_ENVELOPE_VERSION,
)

T = TypeVar("T")


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class RefType(str, Enum):
    """Kind of resource a Citation points at."""

    memory = "memory"
    entity = "entity"
    hub = "hub"
    observation = "observation"


class ModeUsed(str, Enum):
    """Internal retrieval lane that produced the response payload."""

    brief = "brief"
    targeted = "targeted"
    insight = "insight"
    evidence = "evidence"
    # Returned when budget is exhausted and even the cheapest mode is unavailable.
    none = "none"


class StalenessStatus(str, Enum):
    fresh = "fresh"
    aging = "aging"
    stale = "stale"


class BudgetTier(str, Enum):
    cheap = "cheap"
    standard = "standard"
    expensive = "expensive"
    # Surfaced when the consumer has fully consumed their daily budget.
    exhausted = "exhausted"


class ConsumerScope(str, Enum):
    """Allowed projection scope for the consumer that issued the request."""

    communication = "communication"
    professional = "professional"
    personal = "personal"
    behavioral = "behavioral"
    domain = "domain"


class SensitivityClass(str, Enum):
    """Effective sensitivity class of the returned payload."""

    normal = "normal"
    sensitive = "sensitive"
    restricted = "restricted"


# ---------------------------------------------------------------------------
# Citation
# ---------------------------------------------------------------------------


class Citation(BaseModel):
    """Typed citation pointing at a canonical Selph resource.

    Required on every read that returns interpretive content. Harnesses
    render evidence chips from these. Field shape per §3.1.
    """

    model_config = ConfigDict(extra="forbid")

    ref_type: RefType = Field(..., description="Kind of resource being cited.")
    ref_id: str = Field(
        ...,
        description=(
            "Canonical Selph ID — `MEM-{user}-#####`, `ENT-{user}-{TYPE}-#####`, "
            "`HUB-{8 alphanumeric}`, or an observation_id for entity-field observations."
        ),
    )
    layer: Literal[1, 2, 3, 4] = Field(
        ...,
        description="Which KG layer the cited resource belongs to (per `rules/four-layer-architecture.md`).",
    )
    memory_type: Optional[str] = Field(
        default=None,
        description="Present when `ref_type == memory`. Matches the registry in `rules/data-models.md`.",
    )
    hub_type: Optional[str] = Field(
        default=None,
        description="Present when `ref_type == hub`. One of the hub types in `rules/hubs.md`.",
    )
    confidence: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    captured_at: Optional[datetime] = Field(
        default=None,
        description="ISO-8601 timestamp at which the underlying evidence was captured.",
    )

    @model_validator(mode="after")
    def _enforce_ref_type_discriminator(self) -> "Citation":
        """Enforce the §3.1 discriminator contract on `ref_type`.

        - `ref_type == memory`: `memory_type` MUST be set, `hub_type` MUST be None.
        - `ref_type == hub`: `hub_type` MUST be set, `memory_type` MUST be None.
        - `ref_type in (entity, observation)`: both `memory_type` and `hub_type`
          MUST be None.
        """
        if self.ref_type == RefType.memory:
            if self.memory_type is None:
                raise ValueError(
                    "Citation with ref_type='memory' requires `memory_type` to be set."
                )
            if self.hub_type is not None:
                raise ValueError(
                    "Citation with ref_type='memory' must not set `hub_type`."
                )
        elif self.ref_type == RefType.hub:
            if self.hub_type is None:
                raise ValueError(
                    "Citation with ref_type='hub' requires `hub_type` to be set."
                )
            if self.memory_type is not None:
                raise ValueError(
                    "Citation with ref_type='hub' must not set `memory_type`."
                )
        else:  # entity, observation
            if self.memory_type is not None or self.hub_type is not None:
                raise ValueError(
                    f"Citation with ref_type='{self.ref_type.value}' must not set "
                    "`memory_type` or `hub_type`."
                )
        return self


# ---------------------------------------------------------------------------
# Meta block
# ---------------------------------------------------------------------------


class MetaBlock(BaseModel):
    """Nested response metadata — freshness, etag, scope, sensitivity."""

    model_config = ConfigDict(extra="forbid")

    source_cutoff_at: datetime = Field(
        ...,
        description="Latest evidence timestamp included in the response payload.",
    )
    staleness_status: StalenessStatus
    confidence: float = Field(..., ge=0.0, le=1.0)
    etag: str = Field(
        ...,
        description=(
            "`{kind}:{subject}:{intent}:{hash12}` — deterministic per §3.1. "
            "For response_envelope_version >= 2, set equal to `query_fingerprint` "
            "so existing adapters keep working during the deprecation window."
        ),
    )
    budget_tier: BudgetTier
    degraded_from: Optional[ModeUsed] = Field(
        default=None,
        description="Original mode requested before budget-driven degradation. None if no degradation occurred.",
    )
    consumer_scope: ConsumerScope
    sensitivity_class: SensitivityClass
    response_envelope_version: int = Field(
        default=RESPONSE_ENVELOPE_VERSION,
        description="Active response_envelope_version from `contract_versions.json`.",
    )
    # Phase 1 harness context fields (§1.5 of harness context implementation plan)
    query_fingerprint: str = Field(
        default="",
        description=(
            "Selph-computed cache identity for this request. "
            "Format: `{tool}:{subject_hint}:{hash12}`. "
            "Computed from (tool, canonicalized_params, consumer_scope, user_id, "
            "consumer_sensitivity_ceiling, response_envelope_version, dependency_vocabulary_version) "
            "per `docs/canonicalization_spec_v1.md`. "
            "Populated on every persona read; empty string on ok=false error responses."
        ),
    )
    dependency_keys: List[str] = Field(
        default_factory=list,
        description=(
            "Tier 1/Tier 2 dependency vocabulary keys covering this response. "
            "Adapters use these to intersect against `what_changed.invalidated_keys` "
            "for cache coherence. May be empty for ok=false responses. "
            "Vocabulary defined in `docs/dependency_vocabulary_v1.md`."
        ),
    )
    dependency_vocabulary_version: str = Field(
        default=str(DEPENDENCY_VOCABULARY_VERSION),
        description=(
            "Version of the dependency vocabulary spec used when emitting `dependency_keys`. "
            "Matches `contract_versions.json` → `dependency_vocabulary_version`."
        ),
    )


# ---------------------------------------------------------------------------
# PersonaResponse[T]
# ---------------------------------------------------------------------------


class PersonaResponse(BaseModel, Generic[T]):
    """Generic envelope returned by every persona read tool."""

    model_config = ConfigDict(extra="forbid")

    ok: bool
    mode_used: ModeUsed
    data: Optional[T] = Field(
        default=None,
        description="Tool-specific payload. None when ok=false (e.g. budget exhausted).",
    )
    citations: List[Citation] = Field(default_factory=list)
    suggested_next_actions: List[str] = Field(default_factory=list)
    meta: MetaBlock


# ---------------------------------------------------------------------------
# etag generation
# ---------------------------------------------------------------------------


def _canonical_json(payload: Any) -> str:
    """Deterministic JSON serialization (sorted keys, no whitespace).

    Callers MUST pre-normalize all values to JSON-safe primitives
    (`str`, `int`, `float`, `bool`, `None`, `list`, `dict`). No
    `default=` fallback is provided: passing non-JSON values such as
    `datetime`, `set`, `Enum`, or arbitrary objects will raise
    `TypeError` from `json.dumps`. This is intentional — silent
    coercion via `str(...)` would make the resulting hash dependent
    on each object's `__str__` implementation and break the etag
    determinism guarantees in §3.1.
    """
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def etag_for(
    *,
    kind: str,
    subject: str,
    intent: str,
    user_id: str,
    consumer_scope: ConsumerScope | str,
    sensitivity_class: SensitivityClass | str,
    constraints_normalized: Any,
    content_cutoff_at: datetime | str,
    response_envelope_version: int = RESPONSE_ENVELOPE_VERSION,
    persona_contract_version: int = PERSONA_CONTRACT_VERSION,
) -> str:
    """Generate the deterministic etag string per §3.1.

    Format: ``{kind}:{subject}:{intent}:{hash12}`` where ``hash12`` is the
    first 12 hex chars of the sha256 of a canonical-JSON encoding of:

        {
            "user_id", "consumer_scope", "sensitivity_class",
            "subject", "intent", "constraints_normalized",
            "response_envelope_version", "persona_contract_version",
            "content_cutoff_at"
        }

    Including ``user_id``, ``consumer_scope``, and ``sensitivity_class``
    in the hash prevents cross-user and cross-scope cache collisions.
    Including the contract versions forces natural invalidation on
    schema bumps.

    Callers MUST pass ``constraints_normalized`` as JSON-safe primitives
    only (``str``, ``int``, ``float``, ``bool``, ``None``, ``list``,
    ``dict``). Passing ``datetime``, ``set``, ``Enum``, or other
    custom objects will raise ``TypeError`` from ``json.dumps``;
    no silent ``str(...)`` coercion is performed because that would
    make the etag depend on each object's ``__str__`` implementation
    and break determinism.
    """
    scope_value = (
        consumer_scope.value if isinstance(consumer_scope, ConsumerScope) else consumer_scope
    )
    sensitivity_value = (
        sensitivity_class.value
        if isinstance(sensitivity_class, SensitivityClass)
        else sensitivity_class
    )
    cutoff_value = (
        content_cutoff_at.isoformat()
        if isinstance(content_cutoff_at, datetime)
        else content_cutoff_at
    )

    hash_input = {
        "user_id": user_id,
        "consumer_scope": scope_value,
        "sensitivity_class": sensitivity_value,
        "subject": subject,
        "intent": intent,
        "constraints_normalized": constraints_normalized,
        "response_envelope_version": response_envelope_version,
        "persona_contract_version": persona_contract_version,
        "content_cutoff_at": cutoff_value,
    }
    canonical = _canonical_json(hash_input)
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    hash12 = digest[:12]
    return f"{kind}:{subject}:{intent}:{hash12}"


__all__ = [
    "RefType",
    "ModeUsed",
    "StalenessStatus",
    "BudgetTier",
    "ConsumerScope",
    "SensitivityClass",
    "Citation",
    "MetaBlock",
    "PersonaResponse",
    "etag_for",
]
