"""Portable workflow spec.

Implements §7.2 of `docs/selph_mcp_distribution_bootstrapping_strategy.md`.
Each workflow is authored as a portable spec first and then compiled to
harness-specific bundles (Phase 5 of the implementation plan).

Field list per §7.2:
    - workflow ID
    - purpose
    - required connectors
    - allowed harnesses
    - approval model
    - expected outputs
    - Selph retrieval policy
    - minimum graph requirements
    - cache policy
    - write permissions
"""

from __future__ import annotations

from enum import Enum
from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from selph_mcp.contracts.correction import CorrectionTargetType
from selph_mcp.contracts.late_bound import LateBoundQuery
from selph_mcp.contracts.read import Depth, Intent, Subject


class DeclaredQuery(BaseModel):
    """A single declared (eager, non-late-bound) context query.

    Declared queries resolve at workflow startup before any late-bound
    queries are evaluated.  Modeled explicitly here for the first time
    as part of the §2.2 WorkflowContext extension.
    """

    model_config = ConfigDict(extra="forbid")

    tool: str = Field(..., description="Persona MCP tool name.")
    params: dict = Field(default_factory=dict, description="Tool call parameters.")
    alias: str = Field(..., description="Stable reference alias for this query's result.")


class ParamSpec(BaseModel):
    """Type declaration for a single workflow input parameter.

    Used in `WorkflowParametersSchema.fields` and referenced by `validate_late_bound`
    to verify `run_start` binding source paths.
    """

    model_config = ConfigDict(extra="forbid")

    type: Literal["str", "int", "float", "bool", "object", "array"] = Field(
        ...,
        description="JSON-compatible type of the parameter.",
    )
    required: bool = Field(
        default=True,
        description="Whether the workflow requires this parameter to be provided at run start.",
    )
    description: Optional[str] = Field(
        default=None,
        description="Human-readable description for skill authors and documentation.",
    )


class WorkflowParametersSchema(BaseModel):
    """Typed declaration of every parameter the workflow accepts at run start.

    Referenced by `validate_late_bound` to validate `run_start` binding source paths.
    Empty dict means the workflow accepts no parameters.
    """

    model_config = ConfigDict(extra="forbid")

    fields: dict[str, ParamSpec] = Field(
        default_factory=dict,
        description="Map of parameter name → type declaration.",
    )


class WorkflowContext(BaseModel):
    """The context block for a workflow spec.

    Contains both eagerly-resolved declared queries and late-bound durable
    queries.  Added in workflow_spec_version=2 (§2.2).
    """

    model_config = ConfigDict(extra="forbid")

    declared: List[DeclaredQuery] = Field(
        default_factory=list,
        description="Eagerly resolved queries fired at workflow startup.",
    )
    late_bound: List[LateBoundQuery] = Field(
        default_factory=list,
        description="Late-bound durable queries resolved according to `bind_on` policy.",
    )


class ApprovalMode(str, Enum):
    """How aggressively the workflow may act without explicit user approval."""

    # Only produce reads/insights — never drafts, never side-effects.
    insight_only = "insight_only"
    # Produce drafts but never send them; user reviews before any write.
    draft_first = "draft_first"
    # Digest of proposed actions — user approves the bundle before execution.
    digest_first = "digest_first"
    # Auto-execute approved patterns; high-risk steps still need user approval.
    action_first = "action_first"


class TrustTier(str, Enum):
    """Governance tier for the workflow (§7.4 of the strategy doc)."""

    official = "official"
    partner = "partner"
    community = "community"


class CacheTTL(str, Enum):
    """Coarse cache lifetime hint for the role pack."""

    none = "none"
    short = "short"
    medium = "medium"
    long = "long"


class WriteScope(str, Enum):
    """What writeback this workflow is permitted to perform."""

    # No writebacks at all — pure read workflow.
    none = "none"
    # Session observations only (Layer 1 raw, default mode).
    observation_only = "observation_only"
    # Session observations + recommendation feedback events.
    feedback = "feedback"
    # Full writeback surface, including correction payloads.
    correction = "correction"


class RetrievalPolicy(BaseModel):
    """How the workflow should pull context from Selph."""

    model_config = ConfigDict(extra="forbid")

    default_depth: Depth = Field(
        default=Depth.auto,
        description="Default `depth` to pass into `get_context`/`ask_selph` calls.",
    )
    preferred_subjects: List[Subject] = Field(
        default_factory=list,
        description="`Subject` enum values the workflow tends to read against.",
    )
    preferred_intents: List[Intent] = Field(
        default_factory=list,
        description="`Intent` enum values the workflow tends to issue.",
    )
    use_evidence_mode: bool = Field(
        default=False,
        description="Whether the workflow surfaces evidence chips by default.",
    )
    notes: Optional[str] = Field(
        default=None,
        description="Free-form policy guidance for harness compilers.",
    )


class GraphRequirement(BaseModel):
    """Single minimum-graph predicate the workflow needs to satisfy."""

    model_config = ConfigDict(extra="forbid")

    signal: str = Field(
        ...,
        description="Signal name — e.g. `recent_change_hub`, `task_request_memory`, `project_memory`.",
    )
    minimum_count: int = Field(
        default=1,
        ge=0,
        description="Minimum count of the signal required for the workflow to be useful.",
    )
    description: Optional[str] = Field(
        default=None,
        description="Why this signal matters for the workflow.",
    )


class CachePolicy(BaseModel):
    """Local-cache rules for harness adapters."""

    model_config = ConfigDict(extra="forbid")

    ttl: CacheTTL = Field(default=CacheTTL.short)
    revalidate_on_etag_change: bool = Field(default=True)
    purge_on_revocation: bool = Field(
        default=True,
        description="Compliant adapters MUST purge on revocation handshake (§4.7).",
    )
    notes: Optional[str] = None


class WritePermissions(BaseModel):
    """What writeback the workflow is allowed to perform."""

    model_config = ConfigDict(extra="forbid")

    scope: WriteScope = Field(default=WriteScope.observation_only)
    deep_ingest_allowed: bool = Field(
        default=False,
        description="Whether the workflow may opt session observations into `deep_ingest` mode.",
    )
    correction_targets: List[CorrectionTargetType] = Field(
        default_factory=list,
        description=(
            "If `scope == correction`, the `CorrectionTargetType` values "
            "the workflow may submit. Empty list means no targets allowed."
        ),
    )


class ExpectedOutput(BaseModel):
    """One expected output artifact this workflow produces."""

    model_config = ConfigDict(extra="forbid")

    name: str
    description: str
    sample_path: Optional[str] = Field(
        default=None,
        description="Repo-relative path to a sample output rendered for docs/onboarding.",
    )


class WorkflowSpec(BaseModel):
    """Portable workflow definition — authored once, compiled per harness.

    Stored as YAML in `adapters/workflows/<workflow-id>/workflow.yaml`
    (Phase 5 of the implementation plan).
    """

    model_config = ConfigDict(extra="forbid")

    workflow_id: str = Field(
        ...,
        description="Stable kebab-case identifier — e.g. `morning-operator-brief`.",
    )
    purpose: str = Field(
        ...,
        description="One-sentence statement of what the workflow does for the user.",
    )
    required_connectors: List[str] = Field(
        default_factory=list,
        description="External systems required — e.g. `email`, `calendar`. Empty means Selph-only.",
    )
    allowed_harnesses: List[str] = Field(
        default_factory=list,
        description="Harness IDs this workflow may run on — e.g. `claude-code`, `claude-desktop`.",
    )
    approval_model: ApprovalMode
    expected_outputs: List[ExpectedOutput] = Field(default_factory=list)
    selph_retrieval_policy: RetrievalPolicy = Field(default_factory=RetrievalPolicy)
    minimum_graph_requirements: List[GraphRequirement] = Field(default_factory=list)
    cache_policy: CachePolicy = Field(default_factory=CachePolicy)
    write_permissions: WritePermissions = Field(default_factory=WritePermissions)
    trust_tier: TrustTier = Field(
        default=TrustTier.official,
        description="Governance tier — `official` (Selph-maintained), `partner`, or `community`.",
    )
    description: Optional[str] = Field(
        default=None,
        description="Long-form description rendered in onboarding cards.",
    )
    # --- Phase 2 (workflow_spec_version=2) additions ---
    # Defaults are empty so existing v1 specs continue to validate without
    # modification.  A v1 spec cannot declare late-bound queries until the
    # author adds the new sections — injecting empty defaults here is the
    # loader-side upgrade described in §2.2.
    context: WorkflowContext = Field(
        default_factory=lambda: WorkflowContext(declared=[], late_bound=[]),
        description=(
            "Declared and late-bound context queries for this workflow. "
            "Declared queries resolve at startup; late-bound queries resolve "
            "per their `bind_on` policy."
        ),
    )
    parameters: WorkflowParametersSchema = Field(
        default_factory=lambda: WorkflowParametersSchema(fields={}),
        description=(
            "Typed declaration of every parameter the workflow accepts at run start. "
            "Used by the skill loader to validate `run_start` binding source paths."
        ),
    )
    permitted_write_paths: List[str] = Field(
        default_factory=list,
        description=(
            "Glob-style paths over workflow-state that `on_available` binding sources "
            "may reference (e.g. `workflow.state.topics.*`). "
            "Empty list means no `on_available` sources are allowed."
        ),
    )


__all__ = [
    "ApprovalMode",
    "TrustTier",
    "CacheTTL",
    "WriteScope",
    "RetrievalPolicy",
    "GraphRequirement",
    "CachePolicy",
    "WritePermissions",
    "ExpectedOutput",
    "DeclaredQuery",
    "ParamSpec",
    "WorkflowParametersSchema",
    "WorkflowContext",
    "WorkflowSpec",
]
