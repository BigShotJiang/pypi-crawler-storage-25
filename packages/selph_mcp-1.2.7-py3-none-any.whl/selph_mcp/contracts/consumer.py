"""Consumer registration (`consumer_v1`).

Implements §3.5 of the implementation plan. Per-harness record stored in
the `mcp_consumers` Postgres table (Phase 1b migration). The model here
is the in-memory Pydantic shape — the SQL migration lives in
`sql/migrations/20260421_mcp_consumers.sql` (Phase 1b).
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field


class Scope(str, Enum):
    """Allowed projection scopes for a consumer."""

    communication = "communication"
    professional = "professional"
    personal = "personal"
    behavioral = "behavioral"
    domain = "domain"


class SensitivityCeiling(str, Enum):
    """Maximum sensitivity tier the consumer may receive."""

    normal = "normal"
    sensitive = "sensitive"
    restricted = "restricted"


class BudgetTier(str, Enum):
    """Daily persona-credit budget tier (per §Phase 2 task 4)."""

    cheap = "cheap"
    standard = "standard"
    expensive = "expensive"


class Consumer(BaseModel):
    """In-memory shape of an `mcp_consumers` row."""

    model_config = ConfigDict(extra="forbid")

    consumer_id: str = Field(
        ...,
        description="Stable identifier (e.g. `cns-<8hex>`). Sent as `X-Selph-Consumer` header.",
    )
    user_id: str = Field(
        ...,
        description=(
            "User the consumer is bound to. MCP routes derive `user_id` from "
            "this column rather than trusting any caller-supplied user_id "
            "(see §3.5.1 consumer-to-user binding)."
        ),
    )
    harness_id: str
    display_name: str
    allowed_scopes: List[Scope] = Field(
        default_factory=list,
        description="Projection scopes the consumer is permitted to request.",
    )
    sensitivity_ceiling: SensitivityCeiling = Field(default=SensitivityCeiling.normal)
    budget_tier: BudgetTier = Field(default=BudgetTier.standard)
    secret_hash: Optional[str] = Field(
        default=None,
        description=(
            "Reserved for per-consumer token auth — null in v1 since the "
            "shared `SELPH_API_KEY` carries transport auth (see §3.5.1)."
        ),
    )
    revoked_at: Optional[datetime] = None
    etag_cursor: int = Field(
        default=0,
        ge=0,
        description=(
            "Monotonic cursor advancing with the `mcp_etag_invalidations` "
            "log seq. Bumped on every invalidation that affects this consumer."
        ),
    )


__all__ = [
    "Scope",
    "SensitivityCeiling",
    "BudgetTier",
    "Consumer",
]
