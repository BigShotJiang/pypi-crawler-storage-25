"""Budget contract models — single-source response shape for POST /apps/mcp/budget/charge.

Both sides of the HTTP boundary import ``BudgetChargeResponse`` from here:
the server route (`ingestion_api.mcp_admin_routes`) sets it as the
``response_model``, and the MCP wheel's ``persona.budget`` client calls
``BudgetChargeResponse.model_validate(...)`` on the response body — satisfying
async-safety rule 6 (typed HTTP-boundary consumers) without violating the
``mcp-surface-boundary`` import-linter contract (``selph_mcp`` must not import
``ingestion_api``).
"""
from __future__ import annotations

from pydantic import BaseModel, Field


class BudgetChargeResponse(BaseModel):
    """Response for ``POST /apps/mcp/budget/charge``.

    Carries both naming conventions so this single model can serve the
    prime call (``ensure_today_row``, reads ``credits_*`` / ``budget_date``)
    and the decrement call (``check_and_decrement``, reads ``accepted`` /
    ``credits_remaining``). The legacy ``remaining`` / ``ok`` fields remain
    for any direct HTTP caller.
    """

    remaining: float = Field(
        ...,
        description=(
            "Credits remaining after the attempt — same value as "
            "``credits_remaining`` but as a float for legacy HTTP callers."
        ),
    )
    ok: bool = Field(
        ...,
        description=(
            'For billed modes: ``True`` when the budget was decremented, '
            '``False`` when out of budget. For ``mode="ensure"``: always '
            "``True`` (priming succeeds whenever the row materializes)."
        ),
    )
    accepted: bool = Field(
        ...,
        description="Alias of ``ok`` — what the wheel client reads.",
    )
    mode: str = Field(
        ...,
        description="Echoes the request mode so callers can correlate.",
    )
    budget_date: str = Field(
        ...,
        description="ISO date (UTC) the budget row is keyed on.",
    )
    credits_remaining: str = Field(
        ...,
        description="Credits remaining after the attempt, as a Decimal string.",
    )
    credits_allocated: str = Field(
        ...,
        description="Today's tier allocation, as a Decimal string.",
    )
    budget_tier: str = Field(
        ...,
        description="Tier the row was sized at — read from the authenticated consumer.",
    )


__all__ = ["BudgetChargeResponse"]
