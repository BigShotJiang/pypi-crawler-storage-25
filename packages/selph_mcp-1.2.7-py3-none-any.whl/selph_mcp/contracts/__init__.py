"""Selph MCP Phase 1a contracts (`persona_contract_v1`).

Public re-exports for §3 of `docs/selph_mcp_distribution_implementation_plan.md`:
response envelope, depth-aware read request, writeback events, correction
payload, consumer registration, workflow spec, and version constants.

Contracts land BEFORE any tool code. Bumping any version requires updating
`contract_versions.json` and tagging a new `persona_contract_v{N}` git tag.
"""

from selph_mcp.contracts.consumer import (
    BudgetTier as ConsumerBudgetTier,
    Consumer,
    Scope,
    SensitivityCeiling,
)
from selph_mcp.contracts.correction import (
    CorrectionAction,
    CorrectionPayload,
    CorrectionTargetType,
    ObservedIn,
)
from selph_mcp.contracts.envelope import (
    BudgetTier,
    Citation,
    ConsumerScope,
    MetaBlock,
    ModeUsed,
    PersonaResponse,
    RefType,
    SensitivityClass,
    StalenessStatus,
    etag_for,
)
from selph_mcp.contracts.read import (
    Constraints,
    Depth,
    GetContextRequest,
    Intent,
    Sensitivity,
    Subject,
    TimeWindow,
)
from selph_mcp.contracts.versions import (
    CONNECTOR_REQUIREMENTS_VERSION,
    CORRECTION_PAYLOAD_VERSION,
    HARNESS_ADAPTER_VERSION,
    PERSONA_CONTRACT_VERSION,
    RESPONSE_ENVELOPE_VERSION,
    WORKFLOW_SPEC_VERSION,
    WRITEBACK_EVENT_VERSION,
    ContractVersions,
    load_contract_versions,
)
from selph_mcp.contracts.workflow_spec import (
    ApprovalMode,
    CachePolicy,
    CacheTTL,
    ExpectedOutput,
    GraphRequirement,
    RetrievalPolicy,
    TrustTier,
    WorkflowSpec,
    WritePermissions,
    WriteScope,
)
from selph_mcp.contracts.budget import BudgetChargeResponse
from selph_mcp.contracts.invalidations import (
    EmitInvalidationRequest,
    EmitInvalidationResponse,
    InvalidationRow,
    ListInvalidationsResponse,
)
from selph_mcp.contracts.whoami import Whoami
from selph_mcp.contracts.writeback import (
    DriftSignal,
    FeedbackOutcome,
    IngestMode,
    LinkContext,
    RecommendationFeedback,
    SessionObservation,
    SignalKind,
    SpanRef,
    Speaker,
    StructuredSignal,
)

__all__ = [
    # envelope
    "PersonaResponse",
    "MetaBlock",
    "Citation",
    "RefType",
    "ModeUsed",
    "StalenessStatus",
    "BudgetTier",
    "ConsumerScope",
    "SensitivityClass",
    "etag_for",
    # read
    "GetContextRequest",
    "Subject",
    "Intent",
    "Depth",
    "Sensitivity",
    "TimeWindow",
    "Constraints",
    # writeback
    "SessionObservation",
    "Speaker",
    "StructuredSignal",
    "SignalKind",
    "SpanRef",
    "LinkContext",
    "IngestMode",
    "RecommendationFeedback",
    "FeedbackOutcome",
    "DriftSignal",
    # correction
    "CorrectionPayload",
    "CorrectionAction",
    "CorrectionTargetType",
    "ObservedIn",
    # consumer
    "Consumer",
    "Scope",
    "SensitivityCeiling",
    "ConsumerBudgetTier",
    # whoami
    "Whoami",
    # budget
    "BudgetChargeResponse",
    # invalidations
    "InvalidationRow",
    "ListInvalidationsResponse",
    "EmitInvalidationRequest",
    "EmitInvalidationResponse",
    # workflow spec
    "WorkflowSpec",
    "ApprovalMode",
    "TrustTier",
    "CacheTTL",
    "WriteScope",
    "RetrievalPolicy",
    "GraphRequirement",
    "CachePolicy",
    "WritePermissions",
    "ExpectedOutput",
    # versions
    "ContractVersions",
    "load_contract_versions",
    "PERSONA_CONTRACT_VERSION",
    "WORKFLOW_SPEC_VERSION",
    "HARNESS_ADAPTER_VERSION",
    "CONNECTOR_REQUIREMENTS_VERSION",
    "RESPONSE_ENVELOPE_VERSION",
    "WRITEBACK_EVENT_VERSION",
    "CORRECTION_PAYLOAD_VERSION",
]
