"""Whoami contract — secret-free consumer identity returned by GET /whoami.

This model mirrors :class:`~selph_mcp.contracts.consumer.Consumer` but:
- omits ``secret_hash`` (never returned over the wire);
- uses ``extra="forbid"`` so downstream validators fail loudly on schema drift.

Adapters import this from ``selph_mcp.contracts.whoami`` (allowed by the
``adapters-surface-only`` import-linter contract:
``adapters.** -> selph_mcp.contracts.**``).

v2 addition (Phase A): ``memory_boundary_policy_version`` is part of the
``writeback_event_version`` 1→2 contract bump. ``Optional[int]`` lets a
**newer** client validate an older server's response (where the field is
absent). It does NOT protect older clients that pin a pre-v2 ``Whoami``
model with ``extra="forbid"`` — those will hard-fail validation when the
new server returns this field. This is the accepted breaking-change
boundary documented in §4.2 of the memory-boundary brief; the gate is
``selph-mcp`` wheel re-release before Phase C ships. Harness bootstrap
uses this value to detect policy drift and fire upgrade proposals (§4.6).

v3 addition (Phase F — remote decoupling strategy): ``recommended_wheel_version``
and ``min_supported_wheel_version`` enable server-driven wheel drift detection.
SKILL.md's returning flow runs ``selph-mcp-bootstrap version --json``, compares
against these fields, and offers a numbered upgrade menu when the installed wheel
falls behind. Both are ``Optional[str]`` so a v3 client can talk to a pre-v3
server without validation failure (``None`` from old server = no drift check).
Source on the server side: env vars ``SELPH_RECOMMENDED_WHEEL_VERSION`` and
``SELPH_MIN_SUPPORTED_WHEEL_VERSION`` (set via ``cloud.sh sync env``).
"""

from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field

from selph_mcp.contracts.consumer import BudgetTier, Scope, SensitivityCeiling


class Whoami(BaseModel):
    """Secret-free consumer identity payload for ``GET /apps/mcp/whoami``.

    The server builds this from the authenticated :class:`~selph_mcp.contracts.consumer.Consumer`
    object resolved by ``verify_consumer_bearer`` — no second DB round-trip.

    Adapters use :meth:`Whoami.model_validate` to parse the response body so
    any contract drift surfaces as a ``ValidationError`` rather than a silent
    ``KeyError``-on-missing-field fallback (async-safety rule 6).
    """

    model_config = ConfigDict(extra="forbid")

    consumer_id: str = Field(
        ...,
        description="Stable consumer identifier (e.g. ``cns-<8hex>``).",
    )
    user_id: str = Field(
        ...,
        description="Selph user_id bound to this consumer (e.g. ``U001``).",
    )
    harness_id: str = Field(
        ...,
        description="Harness identifier (e.g. ``claude-code``).",
    )
    display_name: str = Field(
        ...,
        description="Human-readable label for this consumer.",
    )
    allowed_scopes: List[Scope] = Field(
        default_factory=list,
        description="Projection scopes this consumer may request.",
    )
    sensitivity_ceiling: SensitivityCeiling = Field(
        default=SensitivityCeiling.normal,
        description="Maximum sensitivity tier this consumer may receive.",
    )
    budget_tier: BudgetTier = Field(
        default=BudgetTier.standard,
        description="Daily persona-credit budget tier.",
    )
    revoked_at: Optional[datetime] = Field(
        default=None,
        description="Non-null when the consumer has been revoked.",
    )
    etag_cursor: int = Field(
        default=0,
        ge=0,
        description=(
            "Monotonic invalidation log cursor. Sent by adapters on the "
            "returning-user handshake so the server can return the purge "
            "set since this point."
        ),
    )
    memory_boundary_policy_version: Optional[int] = Field(
        default=None,
        ge=1,
        description=(
            "Active memory-boundary policy version on the server "
            "(``MEMORY_BOUNDARY_POLICY_VERSION`` from "
            "``selph_mcp.contracts.versions``). ``None`` from a newer client "
            "talking to a pre-v2 server. Harness bootstrap compares this "
            "against its locally-installed policy version to detect drift "
            "and fire upgrade proposals per §4.6 of the memory-boundary "
            "strategy."
        ),
    )

    # v3 fields — Phase F (remote decoupling strategy)
    recommended_wheel_version: Optional[str] = Field(
        default=None,
        description=(
            "Server-recommended wheel version string (e.g. ``'1.2.0'``). "
            "``None`` from a pre-v3 server. When set, SKILL.md compares "
            "against the locally installed wheel version and offers a numbered "
            "upgrade menu when the installed version lags behind."
        ),
    )
    min_supported_wheel_version: Optional[str] = Field(
        default=None,
        description=(
            "Minimum wheel version the server will support (e.g. ``'1.1.0'``). "
            "``None`` from a pre-v3 server. When the installed wheel is older "
            "than this version, SKILL.md must refuse to continue and print the "
            "upgrade command before proceeding."
        ),
    )


__all__ = ["Whoami"]
