"""Late-bound durable query schema and skill-loader strictness policy.

Implements §2.2 and §2.3 of `docs/selph_harness_context_implementation_plan.md`.

`LateBoundQuery` is the Pydantic model for a single late-bound entry inside
`WorkflowContext.late_bound`.  `validate_late_bound` is the skill-loader
validator — it raises `ValueError` on any malformed late-bound spec before the
workflow starts.

The `rebind_trigger` expression parser is deferred to §2.4
(`selph_mcp.adapters.binding.predicate.parse_predicate`).  The module is
imported here at load time; if the binding package has not yet been installed,
the import error surfaces before any workflow tries to validate.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel, ConfigDict, Field

if TYPE_CHECKING:
    from selph_mcp.contracts.workflow_spec import WorkflowSpec

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Cross-skill alias collision registry (§2.3)
# ---------------------------------------------------------------------------
# Maps alias → {workflow_id: fingerprint}.  Populated by validate_late_bound.
_ALIAS_REGISTRY: dict[str, dict[str, str]] = {}


def clear_alias_registry() -> None:
    """Clear the module-level alias registry.  Intended for tests."""
    _ALIAS_REGISTRY.clear()

_PLACEHOLDER_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


def _entry_fingerprint(entry: "LateBoundQuery") -> str:
    """Compute a stable fingerprint for an alias based on (tool, params, binding_sources).

    Used by the cross-skill alias collision check in validate_late_bound.
    """
    payload = json.dumps(
        {
            "tool": entry.tool,
            "params": entry.params,
            "binding_sources": entry.binding_sources,
        },
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def _extract_placeholders(value: Any) -> set[str]:
    """Recursively scan a params value tree for all ${NAME} tokens."""
    found: set[str] = set()
    if isinstance(value, str):
        found.update(_PLACEHOLDER_RE.findall(value))
    elif isinstance(value, dict):
        for v in value.values():
            found.update(_extract_placeholders(v))
    elif isinstance(value, list):
        for item in value:
            found.update(_extract_placeholders(item))
    return found


def _glob_matches(path: str, patterns: list[str]) -> bool:
    """Return True if `path` matches any glob in `patterns` (simple * wildcard)."""
    import fnmatch

    return any(fnmatch.fnmatch(path, p) for p in patterns)


class LateBoundQuery(BaseModel):
    """A single late-bound durable context entry in a workflow's context block.

    See §2.2 of `docs/selph_harness_context_implementation_plan.md` for the
    full field contract.
    """

    model_config = ConfigDict(extra="forbid")

    tool: str = Field(
        ...,
        description="Persona MCP tool name (e.g. `get_context`, `ask_selph`).",
    )
    params: dict[str, Any] = Field(
        ...,
        description="Tool parameters. String values may contain ${PLACEHOLDER} tokens.",
    )
    bind_on: Literal["run_start", "on_available"] = Field(
        ...,
        description=(
            "`run_start` — resolve at workflow init; fail fast if unresolved. "
            "`on_available` — register a watcher; bind at the first evaluation "
            "where every placeholder has a non-null, non-empty value."
        ),
    )
    rebinding: Literal["bind_once", "rebind_on_change"] = Field(
        default="bind_once",
        description=(
            "`bind_once` — binding is permanent for the run after first resolution. "
            "`rebind_on_change` — re-evaluate `rebind_trigger` on every "
            "workflow-state change; rebind when the trigger fires."
        ),
    )
    rebind_trigger: str | None = Field(
        default=None,
        description=(
            "Predicate expression (§2.4 grammar) evaluated on workflow state. "
            "Required iff `rebinding == rebind_on_change`. "
            "Must be absent (null) when `rebinding == bind_once`."
        ),
    )
    binding_sources: dict[str, list[str]] = Field(
        ...,
        description=(
            "Map of placeholder name → ordered list of workflow-state paths. "
            "Walked per-placeholder in declared precedence order. "
            "Must have exactly one entry per ${PLACEHOLDER} token in `params`."
        ),
    )
    alias: str = Field(
        ...,
        description=(
            "Stable identifier for this late-bound slot within the workflow. "
            "Must be unique within the skill. Used by `freeze(alias)` and "
            "as the memoization map key segment."
        ),
    )


def validate_late_bound(
    spec: "WorkflowSpec",
    *,
    strict_mode: bool = False,
) -> None:
    """Validate all late-bound entries in `spec.context.late_bound`.

    Raises `ValueError` on hard errors.  Emits `UserWarning` for cross-skill
    alias collisions on different fingerprints unless `strict_mode=True`, in
    which case those also raise.

    Caller MUST invoke this after constructing `WorkflowSpec` and before
    allowing the workflow to start.

    Args:
        spec: The parsed `WorkflowSpec` to validate.
        strict_mode: If True, cross-skill alias collisions on different
            fingerprints are promoted from warnings to errors.
    """
    late_bound = spec.context.late_bound
    if not late_bound:
        return

    # Collect aliases within this skill to detect intra-skill collisions.
    seen_aliases: dict[str, int] = {}  # alias → first index

    for idx, entry in enumerate(late_bound):
        alias = entry.alias

        # --- Alias uniqueness within skill ---
        if alias in seen_aliases:
            raise ValueError(
                f"LateBoundQuery alias collision within skill: alias '{alias}' "
                f"appears at index {seen_aliases[alias]} and index {idx}. "
                "Aliases must be unique within a workflow spec."
            )
        seen_aliases[alias] = idx

        # --- Placeholder extraction ---
        placeholders_in_params = _extract_placeholders(entry.params)

        # --- Placeholder ↔ binding_sources symmetry ---
        sources_keys = set(entry.binding_sources.keys())

        missing_sources = placeholders_in_params - sources_keys
        if missing_sources:
            raise ValueError(
                f"LateBoundQuery alias='{alias}': placeholder(s) {sorted(missing_sources)} "
                "appear in `params` but have no entry in `binding_sources`."
            )

        extra_sources = sources_keys - placeholders_in_params
        if extra_sources:
            raise ValueError(
                f"LateBoundQuery alias='{alias}': `binding_sources` has entry/entries "
                f"{sorted(extra_sources)} not referenced by any ${{PLACEHOLDER}} in `params`."
            )

        # --- rebinding / rebind_trigger consistency ---
        if entry.rebinding == "bind_once" and entry.rebind_trigger is not None:
            raise ValueError(
                f"LateBoundQuery alias='{alias}': `rebind_trigger` must be absent "
                "(null) when `rebinding == 'bind_once'`."
            )
        if entry.rebinding == "rebind_on_change" and entry.rebind_trigger is None:
            raise ValueError(
                f"LateBoundQuery alias='{alias}': `rebind_trigger` is required "
                "when `rebinding == 'rebind_on_change'`."
            )

        # --- rebind_trigger expression grammar (§2.4) ---
        if entry.rebind_trigger is not None:
            # Lazy import to avoid the circular-import cycle:
            #   late_bound → binding.__init__ → resolver → late_bound
            from selph_mcp.adapters.binding.predicate import parse_predicate  # noqa: PLC0415

            try:
                parse_predicate(entry.rebind_trigger)
            except Exception as exc:
                raise ValueError(
                    f"LateBoundQuery alias='{alias}': `rebind_trigger` expression "
                    f"'{entry.rebind_trigger}' does not parse under the §2.4 predicate "
                    f"grammar: {exc}"
                ) from exc

        # --- run_start binding source path validation ---
        if entry.bind_on == "run_start":
            param_fields = set(spec.parameters.fields.keys())
            if not param_fields and entry.binding_sources:
                # §2.3: run_start binding requires parameters to be declared.
                raise ValueError(
                    f"LateBoundQuery alias='{alias}': `run_start` binding requires "
                    "workflow parameters to be declared in `spec.parameters.fields`, "
                    "but the field map is empty. Declare the parameter schema or "
                    "change `bind_on` to `on_available`."
                )
            for placeholder, source_paths in entry.binding_sources.items():
                for path in source_paths:
                    # A run_start path references a workflow parameter.
                    # The path must resolve against spec.parameters.fields.
                    segments = path.split(".")
                    root = segments[0]
                    if root not in param_fields:
                        raise ValueError(
                            f"LateBoundQuery alias='{alias}', placeholder='{placeholder}': "
                            f"`run_start` binding source path '{path}' does not resolve "
                            f"against spec.parameters.fields. Declared fields: "
                            f"{sorted(param_fields)}."
                        )
                    # If the root field is a scalar (str/int/float/bool), further
                    # segments cannot resolve — reject.  `object`/`array` fields
                    # may have arbitrary trailing segments (v1 semantics).
                    if len(segments) > 1:
                        root_spec = spec.parameters.fields[root]
                        if root_spec.type in {"str", "int", "float", "bool"}:
                            raise ValueError(
                                f"LateBoundQuery alias='{alias}', placeholder='{placeholder}': "
                                f"`run_start` binding source path '{path}' has trailing "
                                f"segments but the root parameter '{root}' is a scalar "
                                f"({root_spec.type}). Scalars cannot be traversed."
                            )

        # --- on_available binding source path validation ---
        if entry.bind_on == "on_available":
            permitted = spec.permitted_write_paths
            for placeholder, source_paths in entry.binding_sources.items():
                for path in source_paths:
                    if not _glob_matches(path, permitted):
                        raise ValueError(
                            f"LateBoundQuery alias='{alias}', placeholder='{placeholder}': "
                            f"`on_available` binding source path '{path}' does not match "
                            f"any glob in `permitted_write_paths`. "
                            f"Permitted patterns: {permitted}."
                        )

    # --- Cross-skill alias collision check (§2.3) ---
    # Register each alias in the module-level registry keyed by
    # (alias → {workflow_id: fingerprint}).  Same fingerprint on a different
    # skill → DEBUG (silent).  Different fingerprint → WARNING (or error under
    # strict_mode).
    skill_id = spec.workflow_id
    for entry in late_bound:
        alias = entry.alias
        fingerprint = _entry_fingerprint(entry)
        if alias not in _ALIAS_REGISTRY:
            _ALIAS_REGISTRY[alias] = {}
        existing = _ALIAS_REGISTRY[alias]
        # Check all previously registered skills for this alias.
        for other_skill_id, other_fingerprint in list(existing.items()):
            if other_skill_id == skill_id:
                continue  # Same skill — intra-skill already caught above.
            if other_fingerprint == fingerprint:
                logger.debug(
                    "Cross-skill alias '%s' collision on same fingerprint "
                    "(skill '%s' vs '%s') — silent per §2.3.",
                    alias,
                    skill_id,
                    other_skill_id,
                )
            else:
                msg = (
                    f"Cross-skill alias collision: alias '{alias}' is registered "
                    f"by skill '{other_skill_id}' with a different fingerprint "
                    f"('{other_fingerprint[:8]}…') than skill '{skill_id}' "
                    f"('{fingerprint[:8]}…'). "
                    "Alias names should be globally unique or intentionally shared "
                    "with an identical binding spec."
                )
                if strict_mode:
                    raise ValueError(msg)
                logger.warning(msg)
        # Register this skill's fingerprint for this alias.
        existing[skill_id] = fingerprint


__all__ = [
    "LateBoundQuery",
    "validate_late_bound",
    "clear_alias_registry",
]
