"""Invalidation contract models — shared between the server route and MCP client.

Models moved here from ``ingestion_api/mcp_admin_routes.py`` so both sides of
the HTTP boundary can import from the same source of truth, satisfying
async-safety rule 6 (HTTP-boundary consumers validate response shape via the
route's Pydantic model).

Mirrors the ``whoami.py`` pattern in this package.
"""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class InvalidationRow(BaseModel):
    """One row from the ``mcp_etag_invalidations`` table."""

    seq: int
    scope_prefix: str
    kind_prefix: str
    invalidated_at: str = Field(
        ...,
        description="ISO-8601 UTC string.",
    )


class ListInvalidationsResponse(BaseModel):
    """Response body for ``GET /apps/mcp/invalidations`` (Bearer-auth) and
    the admin ``GET /apps/mcp/consumers/{consumer_id}/invalidations`` path
    (X-API-Key).

    Field names are the canonical names — adapters must reference them
    exactly (``invalidations``, ``latest_seq``) rather than using fallback
    ``.get()`` chains.
    """

    consumer_id: str
    since_cursor: int
    latest_seq: int
    revoked: bool
    invalidations: List[InvalidationRow]


class EmitInvalidationRequest(BaseModel):
    """Body for ``POST /apps/mcp/invalidations`` (Bearer-auth).

    ``scope_prefix`` is the raw string written directly to the
    ``mcp_etag_invalidations.scope_prefix`` column (e.g. ``ctx:self:*``).
    The old ``scope: dict`` field has been removed — callers must now pass
    the resolved string, not a dict that the server would JSON-encode and
    store verbatim (which broke prefix-filter queries).
    """

    kind: str = Field(
        ...,
        description=(
            "``kind_prefix`` value for the invalidation row "
            "(e.g. ``hub:current_identity:*``)."
        ),
    )
    scope_prefix: str = Field(
        ...,
        description=(
            "Raw scope prefix string landed directly in "
            "``mcp_etag_invalidations.scope_prefix`` "
            "(e.g. ``ctx:self:*``, ``entity:ENT-U001-PER-00042:*``)."
        ),
    )
    reason: str = Field(
        ...,
        description="Human-readable reason for the invalidation.",
    )
    dependency_keys: Optional[List[str]] = Field(
        default=None,
        description=(
            "Tier 1/Tier 2 dependency vocabulary keys for selective purge "
            "(per ``docs/dependency_vocabulary_v1.md``). "
            "When None, ``insert_invalidation`` falls back to ``['scope:self']``."
        ),
    )


class EmitInvalidationResponse(BaseModel):
    """Response for ``POST /apps/mcp/invalidations`` (flat) and legacy path.

    ``cursor`` is the ``seq`` of the newly emitted row.
    """

    cursor: int = Field(
        ...,
        description="The ``seq`` of the newly emitted invalidation row.",
    )


__all__ = [
    "EmitInvalidationRequest",
    "EmitInvalidationResponse",
    "InvalidationRow",
    "ListInvalidationsResponse",
]
