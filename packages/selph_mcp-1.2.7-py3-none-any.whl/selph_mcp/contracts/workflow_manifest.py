"""Renderable workflow manifest shape shared between the contracts layer and
the bootstrap adapter.

``WorkflowManifest`` is the *installed* representation of a workflow — a small,
harness-renderable bundle written to ``.claude/skills/<workflow_id>/SKILL.md``
at install time.  It is NOT the same as :class:`~selph_mcp.contracts.workflow_spec.WorkflowSpec`,
which is the portable authoring format.

Placing this here (under ``selph_mcp.contracts``) rather than in
``adapters.claude_code.using_selph.state_schema`` allows both:

1. ``selph_mcp.persona.workflows.build_manifest`` to import it without
   creating a ``selph_mcp -> adapters`` edge.
2. ``adapters.claude_code.using_selph.state_schema`` to import it under
   the permitted ``adapters.** -> selph_mcp.contracts.**`` import-linter
   allow-list (see ``.importlinter``).

``state_schema`` re-exports this class and its ``PLACEHOLDER_WORKFLOW``
constant so existing call sites in the bootstrap skill remain unchanged.
"""

from __future__ import annotations

import re

from pydantic import BaseModel, ConfigDict, Field, field_validator

# ---------------------------------------------------------------------------
# Workflow ID validator (mirrors the one in state_schema — kept in sync)
# ---------------------------------------------------------------------------

_WORKFLOW_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,62}$")


def _validate_workflow_id_str(value: str) -> str:
    """Validate a workflow_id against the path-safe regex.

    Accepts: lowercase alphanumeric, hyphens, underscores; starts with
    alphanumeric; 1–63 characters.

    Raises:
        ValueError: if *value* does not match or is not a string.
    """
    if not isinstance(value, str):
        raise ValueError(
            f"workflow_id must be a string, got {type(value).__name__}"
        )
    if not value:
        raise ValueError("workflow_id must not be empty")
    if not _WORKFLOW_ID_RE.fullmatch(value):
        raise ValueError(
            "workflow_id must match ^[a-z0-9][a-z0-9_-]{0,62}$ "
            "(lowercase alphanumeric, underscore, or hyphen; must start "
            "with alphanumeric; max 63 chars). "
            f"Got: {value!r}"
        )
    return value


class WorkflowManifest(BaseModel):
    """A renderable workflow definition delivered by the persona MCP.

    Phase 4 uses the ``PLACEHOLDER_WORKFLOW`` constant below so the install
    path can be exercised end-to-end before Phase 5 ships the three real
    workflows. Phase 5 returns real manifests via ``recommend_workflows`` /
    ``hire_for_role`` MCP responses and ``build_manifest`` in
    ``selph_mcp.persona.workflows``.

    Fields:
        workflow_id: Path-safe workflow identifier. Validated against the
            same ``^[a-z0-9][a-z0-9_-]{0,62}$`` regex used by the
            bootstrap install path to prevent directory traversal.
        version: Semantic version string (e.g. ``"1.0.0"``).
        body_md: Markdown content written to
            ``.claude/skills/<workflow_id>/SKILL.md`` at install time.
    """

    model_config = ConfigDict(extra="forbid")

    workflow_id: str = Field(..., min_length=1)
    version: str = Field(..., min_length=1)
    body_md: str = Field(..., min_length=1)

    @field_validator("workflow_id")
    @classmethod
    def _validate_workflow_id(cls, value: str) -> str:
        """Reject path-traversal / unsafe shapes."""
        return _validate_workflow_id_str(value)


# Phase 4 verification stub. Phase 5 replaces with three real manifests
# returned over the wire from the persona MCP recommend_workflows tool.
PLACEHOLDER_WORKFLOW: WorkflowManifest = WorkflowManifest(
    workflow_id="placeholder",
    version="0.1.0",
    body_md=(
        "# placeholder workflow\n\n"
        "No-op workflow used to verify the using-selph install path.\n"
        "Phase 5 of the MCP distribution plan replaces this with three "
        "real workflows: morning-operator-brief, vip-reply-drafting, "
        "and weekly-strategy-memo.\n"
    ),
)


__all__ = [
    "WorkflowManifest",
    "PLACEHOLDER_WORKFLOW",
    "_validate_workflow_id_str",
]
