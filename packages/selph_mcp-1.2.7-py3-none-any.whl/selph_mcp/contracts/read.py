"""Depth-aware read request shape for the persona MCP.

Implements §3.2 / §4.1 of the implementation plan. Strict pydantic enums
on `subject`, `intent`, `depth`, and `sensitivity` — unknown values are
rejected (no silent passthrough).

The depth router (Phase 2 task 2) consumes a validated `GetContextRequest`
and decides which retrieval lane runs.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field


class Subject(str, Enum):
    """What the harness is asking about."""

    self_ = "self"
    person = "person"
    project = "project"
    pursuit = "pursuit"
    relationship = "relationship"
    topic = "topic"
    decision = "decision"


class Intent(str, Enum):
    """Why the harness is asking — drives the depth router decision table."""

    briefing = "briefing"
    reply_draft = "reply_draft"
    outreach = "outreach"
    strategy = "strategy"
    decision_support = "decision_support"
    learning = "learning"
    planning = "planning"
    # Explicit intent for evidence-mode lookups.
    evidence_lookup = "evidence_lookup"
    # Used by the bootstrapper to fetch operating-manual / workflow recs.
    operating_manual = "operating_manual"
    workflow_recommendation = "workflow_recommendation"


class Depth(str, Enum):
    """Requested retrieval depth. `auto` lets Selph route internally."""

    auto = "auto"
    brief = "brief"
    targeted = "targeted"
    insight = "insight"
    evidence = "evidence"


class Sensitivity(str, Enum):
    """Caller-declared sensitivity ceiling for this request."""

    normal = "normal"
    cautious = "cautious"
    strict = "strict"


class TimeWindow(BaseModel):
    """Half-open time window for time-bounded retrieval."""

    model_config = ConfigDict(extra="forbid")

    start: Optional[datetime] = None
    end: Optional[datetime] = None


class Constraints(BaseModel):
    """Optional constraints narrowing the retrieval scope."""

    model_config = ConfigDict(extra="forbid")

    entity_id: Optional[str] = Field(
        default=None,
        description="Canonical entity ID (`ENT-{user}-{TYPE}-#####`) or stub ID.",
    )
    time_window: Optional[TimeWindow] = None
    memory_types: List[str] = Field(
        default_factory=list,
        description="Optional restriction to specific memory types from the registry.",
    )
    max_age_days: Optional[int] = Field(
        default=None,
        ge=0,
        description="Hard cap on evidence age in days.",
    )
    sensitivity: Sensitivity = Field(
        default=Sensitivity.normal,
        description="Caller-declared sensitivity ceiling for the response.",
    )


class GetContextRequest(BaseModel):
    """Depth-aware read request — body of `persona.get_context`."""

    model_config = ConfigDict(extra="forbid")

    subject: Subject
    intent: Intent
    depth: Depth = Field(default=Depth.auto)
    constraints: Constraints = Field(default_factory=Constraints)


__all__ = [
    "Subject",
    "Intent",
    "Depth",
    "Sensitivity",
    "TimeWindow",
    "Constraints",
    "GetContextRequest",
]
