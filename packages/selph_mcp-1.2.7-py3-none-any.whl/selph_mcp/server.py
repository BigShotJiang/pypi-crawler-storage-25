"""
FastMCP server for the Selph persona kernel.

Exposes the four kernel syscalls (`observe`, `query`, `project`, `revise`)
as MCP tools over stdio or SSE. The ``selph_lifespan`` context manager
mirrors ``ingestion_api/main.py``'s DB boot/teardown — but imports ONLY
from ``selph_core`` / ``selph_db`` / ``selph_graph`` / ``selph_shared``
(no Surface-layer imports allowed; see ``.importlinter``).

Lifespan ownership:
    - Neo4j driver (``Neo4jConnection``)
    - Chroma client + predicates collection seeding
    - Checkpoint Postgres pool
    - Background extraction task registry (drained with 30s timeout)

The ``SelphContext`` dataclass is handed to every tool call via
``ctx.request_context.lifespan_context`` (FastMCP convention).
"""
from __future__ import annotations

import asyncio
import logging
import os
from contextlib import asynccontextmanager
from typing import AsyncIterator

from mcp.server.fastmcp import FastMCP

from selph_mcp.config import (
    SelphContext,
    apply_transport_defaults,
    resolve_default_consumer_id,
    resolve_default_user_id,
)

# Apply transport-aware Postgres pool defaults BEFORE any code can import
# selph_db.postgres_connection (which builds the module-level pool on
# first use). We do this at module-import time rather than inside
# lifespan so the defaults lock in before the tool modules resolve their
# own selph_db imports.
_RESOLVED_TRANSPORT = apply_transport_defaults()

from selph_mcp.tools import register_all  # noqa: E402  (must follow pool setup)
from selph_mcp._log import (  # noqa: E402
    configure_logging,
    get_logger,
    log_event,
)

# §5.6 fix: configure_logging() is NOT called here at module-import time.
# The back-compat shim in selph_mcp/server/__init__.py loads this file via
# importlib at package import time, which is too early — before we know
# whether a host logger (selph_utils.log) has already been installed.
# configure_logging() is now idempotent, but the call is still moved out of
# module scope to avoid any import-order surprises. It is called inside the
# FastMCP lifespan (selph_lifespan) or by the entry-point runners instead.
_log = get_logger("selph_mcp.server")


# ─── Lifespan ─────────────────────────────────────────────────────────────


@asynccontextmanager
async def selph_lifespan(server: "FastMCP") -> AsyncIterator[SelphContext]:
    """
    Boot the shared clients the MCP tools need and tear them down on exit.

    Mirrors the startup order of ``ingestion_api/main.py`` but skips
    everything that only matters for the HTTP surface (blob client,
    vector-index creation on boot, vitals emitter, hub rebuild daemon).
    """
    log_event(
        _log, logging.INFO, "selph_mcp.lifespan.start",
        transport=_RESOLVED_TRANSPORT,
        pool_max=os.getenv("SELPH_KG_DB_POOL_MAX"),
        checkpoint_pool_max=os.getenv("CHECKPOINT_POOL_MAX"),
    )

    # 1) Neo4j connection — shared across all tool calls
    from selph_graph.graph_upserter import Neo4jConnection
    neo4j_conn = Neo4jConnection()
    log_event(_log, logging.INFO, "selph_mcp.neo4j_ready")

    # 2) Postgres handle — the entity pool is a module-level singleton
    #    inside selph_db.postgres_connection; the MCP surface does NOT
    #    own a separate checkpoint pool (the chunked ingest paths in
    #    ingestion_api.checkpoint are Surface-layer concerns). Tools that
    #    need a pool handle go through selph_db.PostgresConnection().
    from selph_db.postgres_connection import PostgresConnection
    pg_pool_handle = PostgresConnection()
    log_event(_log, logging.INFO, "selph_mcp.pg_handle_ready")

    # 3) Chroma + predicates seeding
    from selph_db.chroma_predicate import init_chroma_client, seed_predicates_collection
    chroma_host = os.getenv("CHROMA_HOST")
    chroma_port = int(os.getenv("CHROMA_PORT", "8000"))
    chroma_path = os.getenv("CHROMA_PATH", "./ChromaDB")
    from schema_registry.relationship_loader import get_predicates_path
    preds_json = str(get_predicates_path())
    clear_at_boot = os.getenv("CHROMA_CLEAR_AT_BOOT", "false").lower() == "true"

    chroma_client = None
    try:
        chroma_client = init_chroma_client(
            chroma_path=chroma_path,
            chroma_host=chroma_host,
            chroma_port=chroma_port,
        )
        seed_predicates_collection(
            client=chroma_client,
            json_path=preds_json,
            collection_name="Predicates",
            clear=clear_at_boot,
            batch_size=64,
        )
        log_event(_log, logging.INFO, "selph_mcp.chroma_ready")
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "selph_mcp.chroma_failed",
            error_type=type(exc).__name__,
            error=str(exc),
        )

    # 4) Build the context + yield
    context = SelphContext(
        neo4j=neo4j_conn,
        chroma=chroma_client,
        pg_pool_handle=pg_pool_handle,
        default_user_id=resolve_default_user_id(),
        default_consumer_id=resolve_default_consumer_id(),
        transport=_RESOLVED_TRANSPORT,
        background_tasks=set(),
    )

    try:
        yield context
    finally:
        # ── Drain background extraction tasks (observe fire-and-forget) ──
        if context.background_tasks:
            pending = [t for t in context.background_tasks if not t.done()]
            log_event(
                _log, logging.INFO, "selph_mcp.lifespan.drain_bg_tasks",
                outstanding=len(pending),
            )
            if pending:
                try:
                    await asyncio.wait_for(
                        asyncio.gather(*pending, return_exceptions=True),
                        timeout=30.0,
                    )
                    log_event(_log, logging.INFO, "selph_mcp.lifespan.bg_tasks_drained")
                except asyncio.TimeoutError:
                    still_pending = [t for t in pending if not t.done()]
                    log_event(
                        _log, logging.WARNING, "selph_mcp.lifespan.bg_tasks_timeout",
                        still_pending=len(still_pending),
                    )
                    for task in still_pending:
                        task.cancel()
                    # Give cancellations a brief moment to propagate so the
                    # error_type we log below reflects CancelledError rather
                    # than the original exception being swallowed.
                    try:
                        await asyncio.wait_for(
                            asyncio.gather(*still_pending, return_exceptions=True),
                            timeout=5.0,
                        )
                    except asyncio.TimeoutError:
                        pass
                    log_event(
                        _log, logging.WARNING, "selph_mcp.lifespan.bg_tasks_cancelled",
                        cancelled=len(still_pending),
                    )

        # ── Clean up shared clients ──
        try:
            neo4j_conn.close()
        except Exception as exc:  # noqa: BLE001
            log_event(
                _log, logging.WARNING, "selph_mcp.neo4j_close_failed",
                error_type=type(exc).__name__, error=str(exc),
            )

        try:
            from selph_db.postgres_connection import close_pool as close_entity_pool
            close_entity_pool()
        except Exception as exc:  # noqa: BLE001
            log_event(
                _log, logging.WARNING, "selph_mcp.entity_pool_close_failed",
                error_type=type(exc).__name__, error=str(exc),
            )

        try:
            from selph_shared.llm.client import close_llm_client
            close_llm_client()
        except Exception as exc:  # noqa: BLE001
            log_event(
                _log, logging.WARNING, "selph_mcp.llm_client_close_failed",
                error_type=type(exc).__name__, error=str(exc),
            )

        log_event(_log, logging.INFO, "selph_mcp.lifespan.end")


# ─── FastMCP server instance ──────────────────────────────────────────────

server: "FastMCP" = FastMCP(
    "selph-persona-kernel",
    instructions=(
        "Selph persona kernel — four syscalls: observe (ingest L1 evidence), "
        "query (structured evidence retrieval, no synthesis), "
        "project (scoped persona projection), "
        "revise (unified corrections/retractions). "
        "See docs/selph-gap6-design-brief.md for the full contract."
    ),
    lifespan=selph_lifespan,
)

# Register every @tool-decorated handler in selph_mcp.tools
register_all(server)


__all__ = ["server", "selph_lifespan"]
