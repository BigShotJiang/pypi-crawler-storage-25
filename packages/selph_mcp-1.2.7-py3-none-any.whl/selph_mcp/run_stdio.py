"""
Entry point — run the Selph MCP server over the stdio transport.

This is the path Claude Code (and any other local MCP client that
launches subprocesses) uses. The operator wires the command into
``.mcp.json``:

    {
      "mcpServers": {
        "selph": {
          "command": "python",
          "args": ["-m", "selph_mcp.run_stdio"],
          "cwd": "/path/to/SelphSchemaBuilder.ai",
          "env": {
            "SELPH_API_KEY": "...",
            "SELPH_USER_ID": "U001",
            "SELPH_CONSUMER_ID": "claude_code",
            "NEO4J_URI": "bolt://...",
            "SELPH_KG_DB_HOST": "...",
            "SELPH_KG_DB_PASSWORD": "..."
          }
        }
      }
    }

Phase 1b §3.5.1 rewire
----------------------
This runner now boots the AUTHENTICATED ``selph_mcp.server.mcp_app``
transport — every tool call goes through ``require_consumer`` and the
consumer-to-user binding check before any kernel work runs. The legacy
``selph_mcp/server.py`` FastMCP instance and the unauthenticated
``selph_mcp/tools/*`` handlers stay on disk for the future cleanup pass
but are unreachable through this entry point.

We force ``SELPH_MCP_TRANSPORT=stdio`` before importing the server so the
transport-aware pool sizing in ``selph_mcp.config.apply_transport_defaults``
picks the right defaults (5-connection stdio entity pool, not the
80-connection FastAPI pool).
"""
from __future__ import annotations

import logging
import os
import sys


def _guard_stdout_during_imports():
    """Redirect stdout to stderr for the duration of a ``with`` block.

    Stdio MCP reserves stdout for JSON-RPC frames — any stray print at
    import time corrupts the protocol. Several third-party deps import
    clean **except** for logfire, which unconditionally writes either
    "Logfire project URL: …" (when credentials are found) or
    "No Logfire project credentials found." (when they aren't) to
    stdout during ``logfire.configure()``. Both messages make Claude
    Code's MCP client parse the first line as JSON, fail, and flag
    the server as "Failed to connect" — with zero useful diagnostic.

    This guard replaces ``sys.stdout`` with ``sys.stderr`` just long
    enough to cover the imports that trigger ``logfire.configure()``
    (transitively via ``selph_shared.llm.client``), then restores the
    real stdout so FastMCP's stdio transport writes to the correct
    channel. The downside — we lose any *legitimate* early stdout
    output — is acceptable: nothing in this module intentionally
    writes to stdout before the transport handshake.
    """
    class _GuardedStdout:
        def __enter__(self):
            self._real = sys.stdout
            sys.stdout = sys.stderr
            return self
        def __exit__(self, *exc):
            sys.stdout = self._real
            return False
    return _GuardedStdout()


def main() -> None:
    os.environ["SELPH_MCP_TRANSPORT"] = "stdio"

    # Apply stdio pool defaults BEFORE selph_db.postgres_connection is
    # imported anywhere downstream — once the pool singleton is built,
    # env-var changes are ignored.
    from selph_mcp.config import apply_transport_defaults
    apply_transport_defaults()

    # Import after the env var so transport-aware defaults are in place.
    # Wrapped in the stdout guard so logfire's credential-lookup output
    # (see docstring above) can't poison the JSON-RPC channel — this
    # is what caused "Failed to connect" from any cwd that didn't
    # already have cached logfire credentials on 2026-04-22.
    with _guard_stdout_during_imports():
        from selph_mcp.server.mcp_app import run_stdio
        from selph_mcp._log import configure_logging, get_logger, log_event

    configure_logging()
    _log = get_logger("selph_mcp.run_stdio")
    log_event(
        _log, logging.WARNING, "selph_mcp.run_stdio.rewired",
        msg=(
            "selph_mcp run_stdio rewired to authenticated transport — "
            "old tools/* entrypoints retired"
        ),
    )
    log_event(_log, logging.INFO, "selph_mcp.run_stdio.boot")

    try:
        run_stdio()
    except KeyboardInterrupt:
        log_event(_log, logging.INFO, "selph_mcp.run_stdio.keyboard_interrupt")
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "selph_mcp.run_stdio.error",
            error_type=type(exc).__name__, error=str(exc),
        )
        raise
    finally:
        log_event(_log, logging.INFO, "selph_mcp.run_stdio.shutdown")


if __name__ == "__main__":
    main()
