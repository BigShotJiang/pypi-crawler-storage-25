"""Per-harness adapter packages.

Phase 4 ships the Claude Code reference adapter and the `using-selph`
bootstrap skill under this tree. Phase 1a leaves this package empty as
a scaffold.
"""

__all__: list[str] = []
