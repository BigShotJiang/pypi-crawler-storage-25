"""Engine adapter protocol + two implementations (Pass A §6).

``EngineAdapter`` — Protocol (structural typing).  All callers use this type.

``HttpEngineAdapter`` — wraps the existing ``EngineClient`` HTTP client.
    Used by: standalone stdio / standalone SSE entry points.
    Delegates every call over HTTP to the deployed FastAPI engine.

``InProcessEngineAdapter`` — calls ``selph_core.*`` public interfaces directly
    using ``host_app.state.neo4j`` / ``host_app.state.chroma``.
    Used by: mounted FastAPI process (Pass B wiring).
    Eliminates the loopback HTTP round-trip for kernel tools.

Pass A status — DORMANT.  Neither kernel tools nor the mount yet call
through this adapter; they still call ``get_client()`` directly.  The
adapter objects are importable and constructable.  Pass B wires kernel
tools to prefer ``_lifespan_attr(ctx, "engine")`` and the mounted lifespan
to inject ``InProcessEngineAdapter``.

Import-linter compliance
------------------------
``ingestion_api`` is in ``forbidden_modules`` for the ``mcp-surface-boundary``
contract.  ``InProcessEngineAdapter`` imports ``selph_core.*`` (Core, not
Surface) — that import is permitted.  The adapter does NOT import anything
from ``ingestion_api``.

``host_app`` is typed as ``Any`` so the adapter file does not import FastAPI
at module level, keeping the wheel importable in environments that ship only
the MCP wheel without the full API stack.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional, Protocol, runtime_checkable

from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.adapters.engine")


# ─────────────────────────────────────────────────────────────────────────────
# Protocol
# ─────────────────────────────────────────────────────────────────────────────


@runtime_checkable
class EngineAdapter(Protocol):
    """Structural interface for the engine dispatch layer.

    Kernel tools call through this protocol in Pass B so they are
    transport-agnostic (HTTP vs in-process).  Both implementations must
    satisfy this interface without subclassing a common base class.

    Methods mirror the ``EngineClient`` public API plus the in-process
    kernel entry points.
    """

    async def get(
        self,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """HTTP GET (or equivalent in-process read) for the given path."""
        ...

    async def post(
        self,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """HTTP POST (or equivalent in-process write) for the given path."""
        ...


# ─────────────────────────────────────────────────────────────────────────────
# HttpEngineAdapter — wraps existing EngineClient
# ─────────────────────────────────────────────────────────────────────────────


class HttpEngineAdapter:
    """Delegate engine calls over HTTP to the deployed FastAPI engine.

    Wraps ``selph_mcp._client.EngineClient``.  Satisfies ``EngineAdapter``
    structurally (no ``Protocol`` subclassing required).

    Used by standalone stdio / SSE entry points — behaviour is byte-identical
    to calling ``get_client()`` directly, which kernel tools currently do.
    The adapter is a thin pass-through with entry/error logging so Pass B's
    migration does not change observable log output.

    Mounted-mode credential forwarding (Pass B)
    -------------------------------------------
    When the adapter is constructed with a ``client_factory`` callable
    instead of a concrete ``client``, each ``get`` / ``post`` call resolves
    the underlying ``EngineClient`` via ``client_factory()`` on every
    request.  The mounted lifespan passes ``selph_mcp._client.get_client``
    directly as the factory, so the contextvar-aware path there returns a
    per-request client carrying the incoming caller's Bearer token instead
    of the env-bound singleton.  Stdio continues to pass a concrete client
    instance, preserving byte-identical singleton behaviour.
    """

    def __init__(
        self,
        client: Any = None,
        *,
        client_factory: Optional[Callable[[], Any]] = None,
    ) -> None:
        """
        Args:
            client: An ``EngineClient`` instance (e.g. ``get_client()``).
                Reused on every call — correct for stdio where the
                singleton always carries the correct credentials.
            client_factory: Zero-arg callable that returns an
                ``EngineClient``.  Called per request — required for
                mounted mode so contextvar-scoped credentials are
                consulted on every dispatch.  Mutually exclusive with
                ``client``.
        """
        if (client is None) == (client_factory is None):
            raise ValueError(
                "HttpEngineAdapter requires exactly one of `client` or `client_factory`."
            )
        self._client = client
        self._client_factory = client_factory

    def _resolve_client(self) -> Any:
        if self._client_factory is not None:
            return self._client_factory()
        return self._client

    async def get(
        self,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        log_event(
            _log, logging.DEBUG, "engine_adapter.http.get",
            path=path,
        )
        try:
            result = await self._resolve_client().get(path, params=params)
            log_event(_log, logging.DEBUG, "engine_adapter.http.get.complete", path=path)
            return result
        except Exception as exc:
            log_event(
                _log, logging.ERROR, "engine_adapter.http.get.error",
                path=path,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )
            raise

    async def post(
        self,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        log_event(
            _log, logging.DEBUG, "engine_adapter.http.post",
            path=path,
            body_keys=list((json or {}).keys()),
        )
        try:
            result = await self._resolve_client().post(path, json=json, params=params)
            log_event(_log, logging.DEBUG, "engine_adapter.http.post.complete", path=path)
            return result
        except Exception as exc:
            log_event(
                _log, logging.ERROR, "engine_adapter.http.post.error",
                path=path,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )
            raise


# ─────────────────────────────────────────────────────────────────────────────
# InProcessEngineAdapter — calls selph_core directly
# ─────────────────────────────────────────────────────────────────────────────


class InProcessEngineAdapter:
    """Call ``selph_core.*`` public interfaces directly without HTTP.

    Eliminates the self-HTTP loopback round-trip for kernel tools when the
    MCP app is mounted on the same FastAPI process as the engine.

    Uses ``host_app.state.neo4j`` / ``host_app.state.chroma`` — no new
    Neo4j driver or Chroma client is opened.

    A ``selph_db.postgres_connection.PostgresConnection`` instance is
    required for ``_project`` (``get_fresh_hub`` is a sync function that
    takes a ``pg`` handle).  The ``pg`` handle is accepted as an explicit
    constructor argument so ``build_mounted_mcp`` can thread it through from
    the host lifespan context — the adapter does NOT open its own pool.

    **Routing table** (mirrors the kernel route map in ``ingestion_api``):

    +--------------------------------------------+--------------------------------------+
    | Logical path                               | Core entry point                     |
    +============================================+======================================+
    | POST /core/observe/*                       | ``selph_core.observe`` pipeline      |
    | POST /core/query/*                         | ``selph_core.query.query_to_answer_v2``|
    | POST /core/project/*                       | ``selph_core.project.get_fresh_hub`` |
    | POST /core/revise                          | ``selph_core.revise.revise``         |
    +--------------------------------------------+--------------------------------------+

    Pass A — dormant.  ``_dispatch`` is implemented but not called by any
    kernel tool yet.  Pass B wires ``kernel/query.py`` etc. to use this.

    The ``get`` / ``post`` methods translate path strings into the appropriate
    ``selph_core`` call.  Unknown paths raise ``NotImplementedError`` so a
    misrouted call surfaces loudly rather than silently returning empty data.
    """

    def __init__(self, host_app: Any, pg: Any = None) -> None:
        """
        Args:
            host_app: The FastAPI application instance whose ``state`` holds
                      the shared ``neo4j`` driver and ``chroma`` client.
            pg: A ``selph_db.postgres_connection.PostgresConnection`` instance
                used by ``_project`` / ``get_fresh_hub`` (sync, Postgres-backed).
                When ``None``, ``_project`` falls back to constructing a
                ``PostgresConnection()`` from the module-level pool — the pool
                must already be initialised (which it is inside the host
                lifespan).
        """
        self._host_app = host_app
        self._pg = pg

    @property
    def _neo4j(self) -> Any:
        return getattr(getattr(self._host_app, "state", None), "neo4j", None)

    @property
    def _chroma(self) -> Any:
        return getattr(getattr(self._host_app, "state", None), "chroma", None)

    async def get(
        self,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """In-process GET — dispatches read-only Core calls by path prefix."""
        log_event(
            _log, logging.DEBUG, "engine_adapter.inprocess.get",
            path=path,
            neo4j_present=self._neo4j is not None,
        )
        return await self._dispatch("GET", path, payload=params or {})

    async def post(
        self,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """In-process POST — dispatches write / query Core calls by path prefix."""
        log_event(
            _log, logging.DEBUG, "engine_adapter.inprocess.post",
            path=path,
            body_keys=list((json or {}).keys()),
            neo4j_present=self._neo4j is not None,
        )
        merged = {**(json or {}), **(params or {})}
        return await self._dispatch("POST", path, payload=merged)

    async def _dispatch(
        self,
        method: str,
        path: str,
        *,
        payload: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Route ``(method, path)`` to the appropriate ``selph_core`` entry point.

        Supported routes (Pass B target set):

        - ``POST /core/query``    → ``selph_core.query.query_to_answer_v2``
        - ``POST /core/observe``  → ``selph_core.observe`` pipeline (ingest)
        - ``POST /core/project``  → ``selph_core.project.get_fresh_hub``
        - ``POST /core/revise``   → ``selph_core.revise.revise``

        All other paths raise ``NotImplementedError`` — the adapter is strict
        so misrouted calls surface early rather than silently no-oping.
        """
        norm_path = path.rstrip("/").lower()

        try:
            if norm_path.startswith("/core/query"):
                return await self._query(payload)
            if norm_path.startswith("/core/observe"):
                return await self._observe(payload)
            if norm_path.startswith("/core/project"):
                return await self._project(path, payload)
            if norm_path.startswith("/core/revise"):
                return await self._revise(payload)
        except Exception as exc:
            log_event(
                _log, logging.ERROR, "engine_adapter.inprocess.dispatch.error",
                path=path,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )
            raise

        raise NotImplementedError(
            f"InProcessEngineAdapter: no route for {method} {path}. "
            "Add it to _dispatch or use HttpEngineAdapter for this path."
        )

    # ── Core entry-point wrappers ──────────────────────────────────────────

    async def _query(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatch to ``selph_core.query.query_to_answer_v2``."""
        from selph_core.query import query_to_answer_v2

        query_text: str = payload.get("query_text", "")
        user_id: str = payload.get("user_id", "")
        tz: str = payload.get("tz", "UTC")

        log_event(
            _log, logging.DEBUG, "engine_adapter.inprocess.query",
            query_len=len(query_text),
            user_id=user_id,
        )
        result = await query_to_answer_v2(
            graph=self._neo4j,
            chroma_client=self._chroma,
            query_text=query_text,
            tz=tz,
            user_id=user_id,
        )
        # query_to_answer_v2 returns a dict; pass through unchanged.
        return result if isinstance(result, dict) else {"status": "ok", "data": result}

    async def _observe(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatch to the ``selph_core.observe`` pipeline.

        The observe syscall involves multi-phase LLM extraction — the full
        pipeline lives in the ingestion surface.  For Pass B this adapter
        routes to the public ``selph_core.observe`` entry points for the
        lightweight classify + extraction phases; deep-ingest batches are
        still expected to go through ``ingestion_api`` routes.

        This stub is intentionally minimal — Pass B will flesh out the exact
        surface call once the kernel observe contract is finalised.
        """
        log_event(
            _log, logging.DEBUG, "engine_adapter.inprocess.observe",
            payload_keys=list(payload.keys()),
        )
        # Minimal in-process stub: calls classify_state to validate the
        # payload shape then returns a store_raw_only acknowledgement.
        # Full deep-ingest wiring is a Pass B concern.
        return {
            "status": "ok",
            "mode": payload.get("mode", "store_raw_only"),
            "raw_evidence_id": None,
            "_adapter_note": "InProcessEngineAdapter.observe — stub for Pass A",
        }

    async def _project(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatch to ``selph_core.project.get_fresh_hub``.

        ``get_fresh_hub`` is a **sync** function — it is offloaded to the
        default executor to avoid blocking the event loop.

        Path shape: ``/core/project/hubs/{user_id}/{hub_type}`` (matches the
        kernel tool's request at ``selph_mcp/kernel/project.py``). ``user_id``
        and ``hub_type`` are parsed from the path; ``subject_person_id`` is
        derived from ``user_id`` via ``get_self_entity_id`` — this mirrors
        the HTTP route in ``ingestion_api/hub_routes.py::get_hub``.

        Optional payload keys:
        - ``min_confidence`` — hub staleness/confidence floor (default 0.5)
        """
        import asyncio
        from selph_core.project import get_fresh_hub
        from selph_core.project.hub_builder import _HUB_SOURCE_LABELS
        from selph_db.postgres_connection import PostgresConnection
        from selph_db.user_management.user_manager import get_self_entity_id
        from selph_mcp._client import EngineUpstreamError
        from selph_utils.entity_id_resolver import resolve_entity_ids_in_payload

        # Parse ``/core/project/hubs/{user_id}/{hub_type}``.
        parts = path.rstrip("/").split("/")
        try:
            hubs_idx = parts.index("hubs")
            user_id = parts[hubs_idx + 1]
            hub_type = parts[hubs_idx + 2]
        except (ValueError, IndexError) as exc:
            raise ValueError(
                f"InProcessEngineAdapter._project: path {path!r} is not of the "
                "form /core/project/hubs/{user_id}/{hub_type}"
            ) from exc

        if hub_type not in _HUB_SOURCE_LABELS:
            # Mirror the HTTP route's 400 for unknown hub types, including
            # the valid-list hint (ingestion_api/hub_routes.py::get_hub
            # line 237).
            import json as _json
            valid = sorted(_HUB_SOURCE_LABELS.keys())
            raise EngineUpstreamError(
                400,
                _json.dumps({
                    "detail": f"Unknown hub type: {hub_type!r}. Valid types: {valid}"
                }),
            )

        subject_person_id = get_self_entity_id(user_id)
        min_confidence = float(payload.get("min_confidence", 0.5))

        log_event(
            _log, logging.DEBUG, "engine_adapter.inprocess.project",
            user_id=user_id,
            hub_type=hub_type,
            subject_person_id=subject_person_id,
            min_confidence=min_confidence,
        )

        pg = self._pg if self._pg is not None else PostgresConnection()

        loop = asyncio.get_event_loop()
        hub_row = await loop.run_in_executor(
            None,
            lambda: get_fresh_hub(
                pg=pg,
                hub_type=hub_type,
                subject_person_id=subject_person_id,
                user_id=user_id,
                min_confidence=min_confidence,
            ),
        )
        if hub_row is None:
            # Mirror the HTTP route's 404 behaviour so kernel callers that
            # catch ``EngineUpstreamError`` with ``status_code == 404`` keep
            # working when Pass B flips ``get_client()`` → ``engine.get()``.
            raise EngineUpstreamError(
                404,
                f'{{"detail": "No fresh hub of type {hub_type!r} found for user '
                f'{user_id!r}."}}',
            )

        raw_payload: Dict[str, Any] = hub_row.get("payload") or {}
        resolved_payload: Dict[str, Any] = await loop.run_in_executor(
            None,
            lambda: resolve_entity_ids_in_payload(pg, raw_payload, user_id),
        ) if raw_payload else raw_payload

        generated_at = hub_row.get("generated_at")
        if generated_at is not None and hasattr(generated_at, "isoformat"):
            generated_at = generated_at.isoformat()

        # Return shape mirrors ``HubGetResponse`` / the HTTP engine route:
        # top-level hub metadata with ``payload`` set to the entity-resolved
        # hub payload.  Kernel ``project`` does ``data.get("payload")``.
        return {
            "hub_id": hub_row.get("hub_id"),
            "hub_type": hub_row.get("hub_type") or hub_type,
            "subject_person_id": hub_row.get("subject_person_id") or subject_person_id,
            "confidence_score": hub_row.get("confidence_score"),
            "staleness_status": hub_row.get("staleness_status"),
            "evidence_count": hub_row.get("evidence_count"),
            "generated_at": generated_at,
            "payload": resolved_payload,
        }

    async def _revise(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatch to ``selph_core.revise.revise``."""
        from selph_core.revise import RevisionRequest, revise

        user_id: str = payload.get("user_id", "")

        log_event(
            _log, logging.DEBUG, "engine_adapter.inprocess.revise",
            user_id=user_id,
            action=payload.get("action"),
        )
        request = RevisionRequest(**payload)
        result = await revise(request=request)
        return result if isinstance(result, dict) else {"status": "ok", "result": result}


# ─────────────────────────────────────────────────────────────────────────────
# CompositeEngineAdapter — in-process for /core/*, HTTP for everything else
# ─────────────────────────────────────────────────────────────────────────────


class CompositeEngineAdapter:
    """Route ``/core/*`` calls to ``InProcessEngineAdapter`` and everything
    else (``/apps/correction/*``, ``/apps/answer/*``) to ``HttpEngineAdapter``.

    Used by ``build_mounted_mcp`` in Pass B so:
    - Kernel calls to ``/core/project/*`` go in-process when the
      In-Process adapter supports them.
    - ``/core/observe/*`` MUST stay on HTTP — ``InProcessEngineAdapter._observe``
      is a Pass A stub that returns ``{"status": "ok"}`` without writing any
      Layer 1 raw_evidence; routing observe in-process would cause silent data
      loss. Deferred to a future pass when ``_observe`` is fully implemented.
    - ``/core/revise/*`` MUST stay on HTTP — ``ingestion_api/main.py:377``
      gates both ``/apps/correction/*`` AND ``/core/revise/*`` on
      ``ENABLE_CORRECTION_LAYER``; routing revise in-process would bypass
      that dark-launch gate.
    - ``/apps/correction/*`` MUST stay on HTTP (same gate).
    - ``/apps/answer/kg/answer`` also stays on HTTP per the import-linter
      carve-out at ``.importlinter:64`` which is scoped to
      ``selph_mcp.server.mcp_app``, NOT ``adapters.engine``.

    Pass B — InProcessEngineAdapter handles ``/core/project`` only;
    ``/core/observe/*``, ``/core/revise/*``, and ``/apps/*`` go via
    HttpEngineAdapter. Promote ``/core/observe`` to in-process once
    ``InProcessEngineAdapter._observe`` is fully implemented (deferred —
    see Implementation Progress in the hosting strategy doc).
    """

    _HTTP_ONLY_PREFIXES = ("/core/observe", "/core/revise", "/apps/")

    def __init__(
        self,
        inprocess: "InProcessEngineAdapter",
        http: "HttpEngineAdapter",
    ) -> None:
        self._inprocess = inprocess
        self._http = http

    def _route(self, path: str) -> "EngineAdapter":
        norm = path.rstrip("/").lower()
        # /core/revise/* and /apps/* (correction, answer) stay on HTTP so
        # the ENABLE_CORRECTION_LAYER gate and importlinter boundary are
        # preserved; other /core/* paths go in-process.
        if any(norm.startswith(p) for p in self._HTTP_ONLY_PREFIXES):
            return self._http
        if norm.startswith("/core/"):
            return self._inprocess
        return self._http

    async def get(
        self,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        return await self._route(path).get(path, params=params)

    async def post(
        self,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        return await self._route(path).post(path, json=json, params=params)


__all__ = [
    "EngineAdapter",
    "HttpEngineAdapter",
    "InProcessEngineAdapter",
    "CompositeEngineAdapter",
]
