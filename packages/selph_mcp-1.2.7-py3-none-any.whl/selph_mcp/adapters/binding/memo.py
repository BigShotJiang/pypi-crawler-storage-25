"""Call-site memoization map for late-bound workflow queries.

Implements §2.5 of `docs/selph_harness_context_implementation_plan.md`.

Memoization key format (per §2.1 adapter contract spec)
--------------------------------------------------------
``(workflow_id, skill_version, template_alias, canonical_bound_params_json)``

where ``canonical_bound_params_json`` is UTF-8 JSON with:
- Keys sorted at every object level.
- ``null`` values explicit (not omitted).
- Numbers in canonical JSON form (no trailing zeros, no extra precision).
- Strings unescaped (no surrogate escape sequences beyond standard JSON).

Serialization delegates to ``selph_mcp.persona.fingerprint.canonicalize_params``
for the dict-normalization step and then ``json.dumps(sort_keys=True)`` for
the final string.

Lifecycle
---------
- ``put()`` is write-once per (workflow_id, alias, params) tuple for a given
  run — a second ``put()`` with the same key is silently ignored to prevent
  mid-run fingerprint drift.
- ``flush()`` clears all entries — called on ``observe_session`` or ``correct``
  completion (strategy §Ephemeral Pulls and Session Memoization).
- ``invalidate(alias)`` removes all entries for a specific template alias —
  called when a rebind fires so the old fingerprint is no longer the live
  cache identity.
"""
from __future__ import annotations

import json
from enum import Enum
from typing import Any, Optional

__all__ = [
    "MemoKey",
    "MemoMap",
]

# ``(workflow_id, skill_version, template_alias, canonical_bound_params_json)``
MemoKey = tuple[str, str, str, str]


def _canonicalize_for_memo(params: Any) -> Any:
    """Recursively normalize ``params`` for §2.1 memoization-key serialization.

    Rules (per §2.1 key format spec):
    - Does NOT fold defaults — null stays null, empty string stays empty string.
    - Recursively sorts dict keys.
    - Enum values serialized via ``.value``.
    - Integer-valued floats (1.0) coerced to int so ``1`` and ``1.0`` hash
      identically.
    - Strings pass through unescaped (``ensure_ascii=False`` at dumps level).
    """
    if isinstance(params, dict):
        return {k: _canonicalize_for_memo(v) for k, v in sorted(params.items())}
    if isinstance(params, list):
        return [_canonicalize_for_memo(item) for item in params]
    if isinstance(params, Enum):
        return params.value
    if isinstance(params, float) and params.is_integer():
        return int(params)
    return params


def _canonical_params_json(bound_params: dict[str, Any]) -> str:
    """Serialize ``bound_params`` to a deterministic JSON string per §2.1.

    Steps:
    1. ``_canonicalize_for_memo`` — sort keys, coerce enums, normalize floats.
       Does NOT fold defaults (null/empty stay as-is).
    2. ``json.dumps`` with ``sort_keys=True``, ``separators=(",", ":")``,
       ``ensure_ascii=False``, explicit ``null`` for None.
    """
    normalized = _canonicalize_for_memo(bound_params)
    return json.dumps(
        normalized,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


class MemoMap:
    """Per-workflow-run memoization map from call-site key to fingerprint.

    The fingerprint stored here is the Selph-returned ``meta.query_fingerprint``
    and is the sole durable cache identity — the memoization key is a lookup
    hint only (per §2.1 Lookup Protocol).

    Thread safety: not thread-safe.  Each workflow run should own its own
    ``MemoMap`` instance and access it from a single thread.
    """

    def __init__(self) -> None:
        self._store: dict[MemoKey, str] = {}

    def _make_key(
        self,
        workflow_id: str,
        skill_version: str,
        template_alias: str,
        bound_params: dict[str, Any],
    ) -> MemoKey:
        canonical_json = _canonical_params_json(bound_params)
        return (workflow_id, skill_version, template_alias, canonical_json)

    def get(
        self,
        workflow_id: str,
        skill_version: str,
        template_alias: str,
        bound_params: dict[str, Any],
    ) -> Optional[str]:
        """Look up the fingerprint for the given call-site coordinates.

        Args:
            workflow_id: Stable workflow identifier.
            skill_version: Version string of the skill file.
            template_alias: ``LateBoundQuery.alias``.
            bound_params: The fully-resolved (post-substitution) params dict.

        Returns:
            The stored fingerprint string, or ``None`` on a cache miss.
        """
        key = self._make_key(workflow_id, skill_version, template_alias, bound_params)
        return self._store.get(key)

    def put(
        self,
        workflow_id: str,
        skill_version: str,
        template_alias: str,
        bound_params: dict[str, Any],
        fingerprint: str,
    ) -> None:
        """Store a fingerprint for the given call-site coordinates.

        Write-once per run — a second ``put()`` with the same key is silently
        ignored to prevent mid-run fingerprint drift.

        Args:
            workflow_id: Stable workflow identifier.
            skill_version: Version string of the skill file.
            template_alias: ``LateBoundQuery.alias``.
            bound_params: The fully-resolved (post-substitution) params dict.
            fingerprint: The ``meta.query_fingerprint`` returned by Selph.
        """
        key = self._make_key(workflow_id, skill_version, template_alias, bound_params)
        if key not in self._store:
            self._store[key] = fingerprint

    def flush(self) -> None:
        """Clear all entries.

        Called on ``observe_session`` or ``correct`` completion per
        §2.5 strategy §Ephemeral Pulls and Session Memoization.
        """
        self._store.clear()

    def invalidate(self, alias: str) -> None:
        """Remove all entries whose ``template_alias`` matches ``alias``.

        Called on the rebind path so the old fingerprint is no longer the
        live cache identity for the current binding slot.

        Args:
            alias: The ``LateBoundQuery.alias`` whose entries should be removed.
        """
        keys_to_remove = [k for k in self._store if k[2] == alias]
        for k in keys_to_remove:
            del self._store[k]

    def __len__(self) -> int:
        return len(self._store)
