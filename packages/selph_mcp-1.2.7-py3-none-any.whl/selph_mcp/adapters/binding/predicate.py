"""Restricted predicate grammar parser for `rebind_trigger` expressions.

Implements §2.4 of `docs/selph_harness_context_implementation_plan.md`.

Grammar (recursive-descent, no external lexer dependencies):

    expr   := term ((AND | OR) term)*
    term   := '(' expr ')' | path cmp_op value | path
    cmp_op := == | != | >= | <= | > | <
    value  := string_literal | number_literal | null | true | false | path
    path   := IDENT ('.' IDENT)+

Constraints:
    - No function calls.
    - No arithmetic operators.
    - No side effects.

The evaluator (`evaluate_predicate`) takes a workflow-state dict and returns
bool.  It raises `PredicateError` on an undefined path reference or a type
mismatch that prevents comparison.

`parse_predicate` is the primary entry-point used by `validate_late_bound`.
It raises `PredicateParseError` if the expression does not conform to the
grammar.  On success it returns an `Expr` AST node (opaque to callers).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Union

__all__ = [
    "PredicateError",
    "PredicateParseError",
    "parse_predicate",
    "evaluate_predicate",
]

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class PredicateError(Exception):
    """Raised at evaluation time when a path is undefined or a type mismatch occurs."""


class PredicateParseError(PredicateError):
    """Raised at parse time when the expression does not conform to the grammar."""


# ---------------------------------------------------------------------------
# AST node types (opaque to external callers; exported for testing only)
# ---------------------------------------------------------------------------


@dataclass
class PathNode:
    parts: list[str]


@dataclass
class LiteralNode:
    value: Any  # str | int | float | bool | None


@dataclass
class CmpNode:
    left: Union[PathNode, LiteralNode]
    op: str
    right: Union[PathNode, LiteralNode]


@dataclass
class BoolNode:
    op: str  # "AND" | "OR"
    operands: list[Any] = field(default_factory=list)


Expr = Union[PathNode, LiteralNode, CmpNode, BoolNode]

# ---------------------------------------------------------------------------
# Tokenizer
# ---------------------------------------------------------------------------

_TOKEN_RE = re.compile(
    r"""
    \s*
    (?:
        (==|!=|>=|<=|>|<)       # comparison operators  [group 1]
        | (AND\b|OR\b)          # boolean operators — §2.4: AND|OR only [group 2]
        | (\()                  # open paren            [group 3]
        | (\))                  # close paren           [group 4]
        | (true|false|null)     # keywords              [group 5]
        | (-?\d+(?:\.\d+)?)     # number literal        [group 6]
        | ("(?:[^"\\]|\\.)*")  # double-quoted string  [group 7]
        | ('(?:[^'\\]|\\.)*')  # single-quoted string  [group 8]
        | ([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+)  # path — §2.4: IDENT ('.' IDENT)+ (at least 2 segments) [group 9]
    )
    """,
    re.VERBOSE,
)


def _tokenize(expr: str) -> list[tuple[str, str]]:
    """Return list of (kind, value) tokens.  Raises on unrecognised characters."""
    tokens: list[tuple[str, str]] = []
    pos = 0
    while pos < len(expr):
        m = _TOKEN_RE.match(expr, pos)
        if not m:
            # Skip pure whitespace
            if expr[pos].isspace():
                pos += 1
                continue
            raise PredicateParseError(
                f"Unrecognised character '{expr[pos]}' at position {pos} in: {expr!r}"
            )
        tok_val = m.group(0).strip()
        if not tok_val:
            pos = m.end()
            continue
        if m.group(1):
            tokens.append(("CMP", tok_val))
        elif m.group(2):
            tokens.append(("BOOL", "AND" if tok_val in ("&&", "AND") else "OR"))
        elif m.group(3):
            tokens.append(("LPAREN", "("))
        elif m.group(4):
            tokens.append(("RPAREN", ")"))
        elif m.group(5):
            tokens.append(("KEYWORD", tok_val))
        elif m.group(6):
            tokens.append(("NUMBER", tok_val))
        elif m.group(7) or m.group(8):
            tokens.append(("STRING", tok_val[1:-1]))
        elif m.group(9):
            tokens.append(("PATH", tok_val))
        pos = m.end()
    return tokens


# ---------------------------------------------------------------------------
# Recursive-descent parser
# ---------------------------------------------------------------------------


class _Parser:
    def __init__(self, tokens: list[tuple[str, str]]) -> None:
        self._tokens = tokens
        self._pos = 0

    def _peek(self) -> tuple[str, str] | None:
        if self._pos < len(self._tokens):
            return self._tokens[self._pos]
        return None

    def _consume(self) -> tuple[str, str]:
        tok = self._tokens[self._pos]
        self._pos += 1
        return tok

    def parse(self) -> Expr:
        node = self._parse_expr()
        if self._peek() is not None:
            raise PredicateParseError(
                f"Unexpected token '{self._peek()}' after complete expression."
            )
        return node

    def _parse_expr(self) -> Expr:
        left = self._parse_term()
        while self._peek() and self._peek()[0] == "BOOL":
            op = self._consume()[1]
            right = self._parse_term()
            if isinstance(left, BoolNode) and left.op == op:
                left.operands.append(right)
            else:
                left = BoolNode(op=op, operands=[left, right])
        return left

    def _parse_term(self) -> Expr:
        tok = self._peek()
        if tok is None:
            raise PredicateParseError("Unexpected end of expression.")

        if tok[0] == "LPAREN":
            self._consume()
            inner = self._parse_expr()
            if self._peek() is None or self._peek()[0] != "RPAREN":
                raise PredicateParseError("Expected closing ')'.")
            self._consume()
            return inner

        # Grammar: term := path cmp_op value | path
        # The LHS of a term MUST be a path.  Bare literals (numbers, strings,
        # keywords) are NOT valid as stand-alone terms or as the left-hand side
        # of a comparison — only paths may appear there.  This rejects
        # expressions like `1 == 1`, `true`, or `"x"` as invalid terms.
        tok = self._peek()
        if tok is not None and tok[0] in ("NUMBER", "STRING", "KEYWORD"):
            raise PredicateParseError(
                f"Expected a path (e.g. `workflow.state.flag`) as the term "
                f"left-hand side, but got literal token ({tok[0]}, {tok[1]!r}). "
                "Bare literals are not valid terms per §2.4 grammar."
            )
        lhs = self._parse_value()  # must return PathNode given the guard above

        if self._peek() and self._peek()[0] == "CMP":
            op = self._consume()[1]
            rhs = self._parse_value()
            return CmpNode(left=lhs, op=op, right=rhs)

        # Bare path — valid boolean-ish workflow_state flag.
        return lhs

    def _parse_value(self) -> Union[PathNode, LiteralNode]:
        tok = self._peek()
        if tok is None:
            raise PredicateParseError("Expected a value or path, got end of input.")

        kind, val = tok
        if kind == "KEYWORD":
            self._consume()
            if val == "true":
                return LiteralNode(value=True)
            if val == "false":
                return LiteralNode(value=False)
            return LiteralNode(value=None)  # null

        if kind == "NUMBER":
            self._consume()
            return LiteralNode(value=float(val) if "." in val else int(val))

        if kind == "STRING":
            self._consume()
            return LiteralNode(value=val)

        if kind == "PATH":
            self._consume()
            return PathNode(parts=val.split("."))

        raise PredicateParseError(
            f"Expected value or path, got token ({kind}, {val!r})."
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def parse_predicate(expr: str) -> Expr:
    """Parse a `rebind_trigger` expression string.

    Returns an AST root node on success.
    Raises `PredicateParseError` if the expression does not conform to the §2.4 grammar.
    """
    if not expr or not expr.strip():
        raise PredicateParseError("Predicate expression must not be empty.")
    tokens = _tokenize(expr.strip())
    if not tokens:
        raise PredicateParseError("Predicate expression produced no tokens.")
    return _Parser(tokens).parse()


def _resolve_path(state: dict[str, Any], parts: list[str]) -> Any:
    """Walk `state` along `parts`, raising `PredicateError` on missing keys."""
    current: Any = state
    for part in parts:
        if not isinstance(current, dict) or part not in current:
            raise PredicateError(
                f"Undefined path '{'.'.join(parts)}' in workflow state."
            )
        current = current[part]
    return current


def evaluate_predicate(expr: Expr, state: dict[str, Any]) -> bool:
    """Evaluate a parsed predicate AST against a workflow-state dict.

    Returns bool.  Raises `PredicateError` on undefined path or type mismatch.
    """
    if isinstance(expr, LiteralNode):
        return bool(expr.value)

    if isinstance(expr, PathNode):
        return bool(_resolve_path(state, expr.parts))

    if isinstance(expr, CmpNode):
        lv = (
            _resolve_path(state, expr.left.parts)
            if isinstance(expr.left, PathNode)
            else expr.left.value
        )
        rv = (
            _resolve_path(state, expr.right.parts)
            if isinstance(expr.right, PathNode)
            else expr.right.value
        )
        op = expr.op
        try:
            if op == "==":
                return lv == rv
            if op == "!=":
                return lv != rv
            if op == ">":
                return lv > rv  # type: ignore[operator]
            if op == ">=":
                return lv >= rv  # type: ignore[operator]
            if op == "<":
                return lv < rv  # type: ignore[operator]
            if op == "<=":
                return lv <= rv  # type: ignore[operator]
        except TypeError as exc:
            raise PredicateError(
                f"Type mismatch evaluating '{op}' between {lv!r} and {rv!r}."
            ) from exc
        raise PredicateError(f"Unknown operator '{op}'.")

    if isinstance(expr, BoolNode):
        if expr.op == "AND":
            return all(evaluate_predicate(operand, state) for operand in expr.operands)
        if expr.op == "OR":
            return any(evaluate_predicate(operand, state) for operand in expr.operands)
        raise PredicateError(f"Unknown boolean operator '{expr.op}'.")

    raise PredicateError(f"Unknown AST node type: {type(expr)}")
