"""Slot state machine for late-bound query aliases.

Implements §2.5 and §2.5.1 of
`docs/selph_harness_context_implementation_plan.md`.

State machine
-------------
Each late-bound alias progresses through:

    Unbound  ──resolve()──►  Bound(params, fingerprint)
                                    │
                    rebind_on_change + trigger fires
                                    │
                             Bound'(params', fingerprint')
                                    │
                         freeze(alias) or LifecycleManager.freeze()
                                    │
                             Frozen(params, fingerprint)  ← terminal for the run
                                    │
                      fingerprint invalidated by what_changed
                                    │
                       reset_frozen_fingerprint() — params stay frozen,
                       fingerprint set to None so caller re-queries Selph.

In-flight-during-rebind rule
----------------------------
If a rebind fires while a Selph call for the old binding is in-flight,
the in-flight response lands under the old fingerprint but is **not** used
by the current workflow; the new binding re-queries.  This module does not
manage async I/O — this invariant is enforced by the caller (see §2.5
docstring in the implementation plan).

Single-threaded evaluation contract
------------------------------------
``LifecycleManager.on_state_change`` is not re-entrant.  All lifecycle
evaluations for a given run are single-threaded.  A ``threading.Lock`` is
held for the duration of ``on_state_change`` to guard against accidental
concurrent calls; intentional single-threaded callers incur no contention.
"""
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any, Optional

from selph_mcp.adapters.binding.predicate import Expr, evaluate_predicate
from selph_mcp.adapters.binding.resolver import BoundParams, resolve
from selph_mcp.contracts.late_bound import LateBoundQuery

__all__ = [
    "Unbound",
    "Bound",
    "Frozen",
    "SlotState",
    "LateBoundSlot",
    "LifecycleManager",
]


# ---------------------------------------------------------------------------
# Discriminated state types
# ---------------------------------------------------------------------------


@dataclass
class Unbound:
    """Slot has not yet successfully resolved its placeholders."""


@dataclass
class Bound:
    """Slot has resolved params and a Selph-returned fingerprint."""

    params: dict[str, Any]
    fingerprint: str


@dataclass
class Frozen:
    """Slot has been frozen — no further rebinds allowed for this run.

    ``fingerprint`` may be set to ``None`` by ``reset_frozen_fingerprint()``
    when ``what_changed`` reports the stored fingerprint has been invalidated.
    In that state the **params remain frozen** (the binding_sources values do
    not change) but the caller must re-query Selph to obtain a fresh payload.
    """

    params: dict[str, Any]
    fingerprint: Optional[str]


SlotState = Unbound | Bound | Frozen


# ---------------------------------------------------------------------------
# LateBoundSlot
# ---------------------------------------------------------------------------


@dataclass
class LateBoundSlot:
    """A single late-bound slot tracked by the ``LifecycleManager``.

    Args:
        alias: Stable alias matching ``LateBoundQuery.alias``.
        template: The ``LateBoundQuery`` defining the tool, params template,
            and ``rebinding`` policy for this slot.
        rebind_trigger_expr: Pre-parsed ``Expr`` from
            ``predicate.parse_predicate(template.rebind_trigger)`` — or
            ``None`` when ``template.rebinding == "bind_once"``.
    """

    alias: str
    template: LateBoundQuery
    rebind_trigger_expr: Optional[Expr] = None
    state: SlotState = field(default_factory=Unbound)

    def reset_frozen_fingerprint(self) -> None:
        """Clear the fingerprint on a Frozen slot so the caller re-queries.

        The binding params remain frozen — only the fingerprint is cleared to
        signal that the cached payload is stale and must be re-fetched.
        Calling this on a non-Frozen slot is a no-op.
        """
        if isinstance(self.state, Frozen):
            self.state = Frozen(params=self.state.params, fingerprint=None)


# ---------------------------------------------------------------------------
# LifecycleManager
# ---------------------------------------------------------------------------


class LifecycleManager:
    """Manages the full set of ``LateBoundSlot`` instances for one workflow run.

    Thread safety
    -------------
    ``on_state_change`` and ``freeze`` acquire ``_lock`` before mutating
    state.  The lock is non-re-entrant; do not call either method from
    inside a callback triggered by the same ``LifecycleManager``.

    In-flight-during-rebind rule (advisory, not enforced here)
    -----------------------------------------------------------
    If a Selph call for the old binding is in flight when ``rebind`` fires,
    the in-flight response lands under the old fingerprint but is not used by
    the current workflow; the new binding re-queries.  The caller is
    responsible for tracking in-flight calls — this module emits no async I/O.
    """

    def __init__(self) -> None:
        self._slots: dict[str, LateBoundSlot] = {}
        self._pending_freeze: set[str] = set()
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, slot: LateBoundSlot) -> None:
        """Register a ``LateBoundSlot`` with this manager.

        Must be called before ``on_state_change``.  Registering the same
        alias twice replaces the previous slot — callers should avoid this.

        Args:
            slot: The slot to register.
        """
        with self._lock:
            self._slots[slot.alias] = slot

    # ------------------------------------------------------------------
    # State-change evaluation
    # ------------------------------------------------------------------

    def on_state_change(
        self,
        path: str,  # noqa: ARG002  (unused but part of the declared surface)
        value: Any,  # noqa: ARG002
        workflow_state: dict[str, Any],
    ) -> list[LateBoundSlot]:
        """Re-evaluate all registered slots against the updated workflow state.

        Steps for each slot:
        1. If ``Frozen`` — no transition (terminal state, except fingerprint
           invalidation which is handled via ``reset_frozen_fingerprint``).
        2. If ``Unbound`` — attempt ``resolve()``; on success transition to
           ``Bound``.
        3. If ``Bound`` with ``rebinding == "rebind_on_change"`` — evaluate
           the ``rebind_trigger_expr``; on True, re-resolve and if successful
           transition to a new ``Bound`` state.

        Pending freezes (from ``freeze(alias)`` calls) are applied at the
        start of this evaluation boundary, before any transitions.

        Args:
            path: The workflow-state path that changed.  Stored for logging
                by the caller; this method does not filter slots by path.
            value: The new value at ``path``.
            workflow_state: The full, current workflow state dict.

        Returns:
            List of ``LateBoundSlot`` instances that transitioned during
            this call (in registration order).
        """
        transitioned: list[LateBoundSlot] = []

        with self._lock:
            # Apply pending freezes first — freeze() takes effect at the
            # next evaluation boundary, not mid-evaluation (§2.5.1).
            for alias in list(self._pending_freeze):
                slot = self._slots.get(alias)
                if slot and isinstance(slot.state, Bound):
                    slot.state = Frozen(
                        params=slot.state.params,
                        fingerprint=slot.state.fingerprint,
                    )
                    transitioned.append(slot)
            self._pending_freeze.clear()

            for slot in self._slots.values():
                if isinstance(slot.state, Frozen):
                    # Terminal — no lifecycle transition.
                    continue

                if isinstance(slot.state, Unbound):
                    result = resolve(slot.template, workflow_state)
                    if isinstance(result, BoundParams):
                        slot.state = Bound(
                            params=result.params,
                            fingerprint=result.fingerprint or "",
                        )
                        transitioned.append(slot)
                    continue

                # Bound — check rebind trigger.
                if (
                    isinstance(slot.state, Bound)
                    and slot.template.rebinding == "rebind_on_change"
                    and slot.rebind_trigger_expr is not None
                ):
                    try:
                        trigger_fired = evaluate_predicate(
                            slot.rebind_trigger_expr, workflow_state
                        )
                    except Exception:
                        # Undefined path or type mismatch — treat as not fired.
                        trigger_fired = False

                    if trigger_fired:
                        result = resolve(slot.template, workflow_state)
                        if isinstance(result, BoundParams):
                            slot.state = Bound(
                                params=result.params,
                                fingerprint=result.fingerprint or "",
                            )
                            transitioned.append(slot)

        return transitioned

    # ------------------------------------------------------------------
    # Freeze
    # ------------------------------------------------------------------

    def freeze(self, alias: str) -> None:
        """Schedule a freeze for the slot identified by ``alias``.

        The freeze takes effect at the **next** ``on_state_change`` evaluation
        boundary, not immediately (§2.5.1 — "freeze takes effect at the next
        evaluation boundary, not mid-evaluation").

        If the alias is unknown, this is a no-op.

        Args:
            alias: The ``LateBoundQuery.alias`` of the slot to freeze.
        """
        with self._lock:
            if alias in self._slots:
                self._pending_freeze.add(alias)

    # ------------------------------------------------------------------
    # Fingerprint update
    # ------------------------------------------------------------------

    def record_fingerprint(self, alias: str, fingerprint: str) -> None:
        """Update the stored fingerprint on a ``Bound`` or ``Frozen`` slot.

        Called by the caller after a successful Selph round-trip to stamp
        the server-returned ``meta.query_fingerprint`` onto the slot.

        Args:
            alias: The slot alias.
            fingerprint: The ``meta.query_fingerprint`` returned by Selph.
        """
        with self._lock:
            slot = self._slots.get(alias)
            if slot is None:
                return
            if isinstance(slot.state, Bound):
                slot.state = Bound(params=slot.state.params, fingerprint=fingerprint)
            elif isinstance(slot.state, Frozen):
                slot.state = Frozen(params=slot.state.params, fingerprint=fingerprint)

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def get_slot(self, alias: str) -> Optional[LateBoundSlot]:
        """Return the slot for ``alias``, or ``None`` if not registered."""
        return self._slots.get(alias)

    def all_slots(self) -> list[LateBoundSlot]:
        """Return all registered slots in registration order."""
        return list(self._slots.values())
