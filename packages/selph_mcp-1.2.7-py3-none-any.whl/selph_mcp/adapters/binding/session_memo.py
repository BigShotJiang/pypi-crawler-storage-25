"""Ephemeral session cache for persona tool calls.

Implements §2.5 of `docs/selph_harness_context_implementation_plan.md`.

This cache is:
- Process-local (never persisted, never shipped to the server).
- Scoped to one workflow run or conversation thread.
- Keyed by raw call signature — NOT the canonical fingerprint key (ephemeral
  queries do not participate in durable cache identity).
- Depth-ceiling enforced: ``insight`` payloads are **not** cached here.
  Only ``brief`` and ``targeted`` depth responses may be stored.

Flush
-----
``flush()`` must be called whenever a writeback occurs (``observe_session``
or ``correct`` completes) — a stale ephemeral read must not outlive a
correction.  ``session_boundary()`` is exposed as an explicit session-reset
primitive for workflows that want to clear the cache without a writeback
(§2.5.1 resolves open question 5 with this workflow-callable primitive).
"""
from __future__ import annotations

import json
from typing import Any, Optional

__all__ = [
    "SessionMemo",
]

# §2.5: only brief and targeted are cached at the session layer.
# All other depths (including insight, and any unknown future depths) are
# rejected on put() and return None on get().
_CACHEABLE_DEPTHS = frozenset({"brief", "targeted"})


def _raw_call_key(tool: str, params: dict[str, Any]) -> str:
    """Produce a raw (non-canonicalized) string key from tool + params.

    §2.5 specifies "raw call signature — ephemeral queries do not participate
    in durable identity."  We use ``json.dumps(sort_keys=True)`` for
    determinism within a process run without applying the §2.1 canonical
    normalization (no default-folding, no enum coercion, no float→int).
    """
    params_json = json.dumps(params, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return f"{tool}:{params_json}"


class SessionMemo:
    """Ephemeral per-run session cache for brief/targeted persona calls.

    Depth-ceiling enforcement (§2.5)
    ---------------------------------
    Only ``"brief"`` and ``"targeted"`` depths are cacheable.  ``put()``
    raises ``ValueError`` for any other depth string (including ``"insight"``
    and any unknown future depths).  ``get()`` returns ``None`` for any
    non-cacheable depth without raising — the caller falls through to a live
    Selph call.

    Thread safety: not thread-safe.  Same single-run ownership model as
    ``MemoMap``.
    """

    def __init__(self) -> None:
        self._store: dict[str, Any] = {}

    def get(
        self,
        tool: str,
        params: dict[str, Any],
        depth: str,
    ) -> Optional[Any]:
        """Return the cached payload, or ``None`` on miss / non-cacheable depth.

        Args:
            tool: Persona tool name.
            params: Tool call parameters (raw — no canonicalization applied).
            depth: Request depth string.  Only ``"brief"`` and ``"targeted"``
                are cacheable; any other value returns ``None``.

        Returns:
            The cached payload, or ``None`` on miss or non-cacheable depth.
        """
        if depth not in _CACHEABLE_DEPTHS:
            return None
        key = _raw_call_key(tool, params)
        return self._store.get(key)

    def put(
        self,
        tool: str,
        params: dict[str, Any],
        depth: str,
        payload: Any,
    ) -> None:
        """Store a payload for the given tool/params/depth combination.

        Args:
            tool: Persona tool name.
            params: Tool call parameters.
            depth: Response depth.  Must be ``"brief"`` or ``"targeted"``.
            payload: The response payload to cache (any Python value).

        Raises:
            ValueError: If ``depth`` is not in ``{"brief", "targeted"}``.
                Insight-depth and all other responses must not be cached at
                this layer (§2.5 depth ceiling).
        """
        if depth not in _CACHEABLE_DEPTHS:
            raise ValueError(
                f"SessionMemo: depth='{depth}' is not cacheable at the ephemeral "
                "session layer. Only 'brief' and 'targeted' depths may be stored "
                "here. Insight-depth responses must flow through the late-bound "
                "durable binding path (§2.5)."
            )
        key = _raw_call_key(tool, params)
        self._store[key] = payload

    def flush(self) -> None:
        """Clear all cached entries.

        Must be called on any writeback (``observe_session`` or ``correct``
        completion) to prevent stale reads surviving a correction.
        """
        self._store.clear()

    def session_boundary(self) -> None:
        """Explicit session-scope reset independent of writeback.

        Workflow-callable primitive (§2.5.1).  Clears the cache so that
        subsequent ephemeral calls re-query Selph even if no writeback
        occurred.
        """
        self._store.clear()

    def __len__(self) -> int:
        return len(self._store)
