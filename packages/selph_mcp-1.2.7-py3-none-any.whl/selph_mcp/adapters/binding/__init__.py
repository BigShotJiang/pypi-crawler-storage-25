"""Client-side binding library for conforming harness adapters.

Phase 2 of `docs/selph_harness_context_implementation_plan.md` (§2.4–§2.5).

Modules:
    predicate    — Restricted predicate grammar parser for `rebind_trigger` (§2.4).
    resolver     — Per-template binding resolver (§2.5).
    lifecycle    — Slot state machine per late-bound alias (§2.5).
    memo         — Call-site memoization map (§2.5).
    session_memo — Ephemeral session cache (§2.5).
"""

# §2.4 — predicate grammar
from selph_mcp.adapters.binding.predicate import (
    Expr,
    PredicateError,
    PredicateParseError,
    evaluate_predicate,
    parse_predicate,
)

# §2.5 — resolver
from selph_mcp.adapters.binding.resolver import (
    BoundParams,
    ResolveResult,
    Unbound as UnboundResult,
    resolve,
)

# §2.5 — lifecycle state machine
from selph_mcp.adapters.binding.lifecycle import (
    Bound,
    Frozen,
    LateBoundSlot,
    LifecycleManager,
    SlotState,
    Unbound as UnboundState,
)

# §2.5 — call-site memoization map
from selph_mcp.adapters.binding.memo import (
    MemoKey,
    MemoMap,
)

# §2.5 — ephemeral session cache
from selph_mcp.adapters.binding.session_memo import (
    SessionMemo,
)

__all__ = [
    # predicate
    "Expr",
    "PredicateError",
    "PredicateParseError",
    "parse_predicate",
    "evaluate_predicate",
    # resolver
    "BoundParams",
    "UnboundResult",
    "ResolveResult",
    "resolve",
    # lifecycle
    "UnboundState",
    "Bound",
    "Frozen",
    "SlotState",
    "LateBoundSlot",
    "LifecycleManager",
    # memo
    "MemoKey",
    "MemoMap",
    # session_memo
    "SessionMemo",
]
