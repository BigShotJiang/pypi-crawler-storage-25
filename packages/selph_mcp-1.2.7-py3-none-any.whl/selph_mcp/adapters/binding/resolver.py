"""Per-template binding resolver for late-bound workflow queries.

Implements §2.5 of `docs/selph_harness_context_implementation_plan.md`.

Public API
----------
- :func:`resolve` — resolve a ``LateBoundQuery`` template against a
  workflow-state dict, returning ``BoundParams`` (all placeholders
  resolved) or ``Unbound`` (one or more missing).
- ``ResolveResult`` — ``BoundParams | Unbound`` union alias.

Resolution semantics (per §2.1 adapter contract spec)
------------------------------------------------------
1. For each placeholder in ``template.binding_sources``, walk the source
   paths in declared precedence order.
2. A source "has a value" iff the workflow-state path resolves to a value
   that is **not** ``None``, not an empty string, and not an empty list.
3. All placeholders must resolve simultaneously — partial resolution
   returns ``Unbound(missing=[...])``.  There is no partial-bind state.
4. Resolved values are substituted into ``template.params`` — every
   ``${NAME}`` token in any string value is replaced with the resolved
   value.
5. ``fingerprint`` on ``BoundParams`` is ``None``; the caller stamps it
   after a successful Selph call returns ``meta.query_fingerprint``.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Union

from selph_mcp.contracts.late_bound import LateBoundQuery

__all__ = [
    "BoundParams",
    "Unbound",
    "ResolveResult",
    "resolve",
]

_PLACEHOLDER_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass
class BoundParams:
    """All placeholders resolved — ready to call the persona tool.

    ``params`` has all ``${NAME}`` tokens replaced with their resolved values.
    ``fingerprint`` starts as ``None``; the caller sets it once Selph returns
    ``meta.query_fingerprint``.
    """

    params: dict[str, Any]
    fingerprint: str | None = None


@dataclass
class Unbound:
    """One or more placeholders could not be resolved.

    ``missing`` lists the placeholder names (not paths) that had no
    non-empty value across all their declared sources.
    """

    missing: list[str] = field(default_factory=list)


ResolveResult = Union[BoundParams, Unbound]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resolve_path(state: dict[str, Any], path: str) -> Any:
    """Walk a dot-separated path through ``state``.

    Returns the value if found.  Returns ``_MISSING`` sentinel on any
    missing key, type mismatch (non-dict traversal), or index error.
    """
    parts = path.split(".")
    current: Any = state
    for part in parts:
        if isinstance(current, dict):
            if part not in current:
                return _MISSING
            current = current[part]
        elif isinstance(current, list):
            try:
                current = current[int(part)]
            except (ValueError, IndexError):
                return _MISSING
        else:
            return _MISSING
    return current


_MISSING = object()  # sentinel distinguishing "key absent" from value=None


def _has_value(v: Any) -> bool:
    """Return True iff ``v`` is considered a non-empty binding value.

    Explicit falsy empties that do **not** count as a value:
    - ``None``
    - Empty string ``""``
    - Empty list ``[]``
    """
    if v is _MISSING or v is None:
        return False
    if isinstance(v, str) and v == "":
        return False
    if isinstance(v, list) and len(v) == 0:
        return False
    return True


def _substitute(value: Any, resolved: dict[str, Any]) -> Any:
    """Recursively replace ``${NAME}`` tokens with resolved values.

    Non-string leaves pass through unchanged.  Dict keys are not
    substituted (placeholder tokens are only valid in values).
    """
    if isinstance(value, str):
        # If the entire string is a single token, substitute directly
        # (preserves non-string types like int/bool).
        m = _PLACEHOLDER_RE.fullmatch(value)
        if m:
            name = m.group(1)
            return resolved.get(name, value)
        # Partial substitution — inline into string.
        def _replacer(match: re.Match) -> str:  # type: ignore[type-arg]
            name = match.group(1)
            replacement = resolved.get(name)
            return str(replacement) if replacement is not None else match.group(0)

        return _PLACEHOLDER_RE.sub(_replacer, value)

    if isinstance(value, dict):
        return {k: _substitute(v, resolved) for k, v in value.items()}
    if isinstance(value, list):
        return [_substitute(item, resolved) for item in value]
    return value


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def resolve(template: LateBoundQuery, workflow_state: dict[str, Any]) -> ResolveResult:
    """Resolve a ``LateBoundQuery`` template against current workflow state.

    For each placeholder in ``template.binding_sources``, walks the source
    paths in declared order, taking the first path that resolves to a
    non-null, non-empty value.  If every placeholder finds a value, returns
    ``BoundParams`` with the substituted params dict.  Otherwise returns
    ``Unbound(missing=[...])`` naming every unresolved placeholder.

    Args:
        template: The ``LateBoundQuery`` whose ``binding_sources`` and
            ``params`` define the placeholders and substitution targets.
        workflow_state: Current harness workflow state dict (may be nested).

    Returns:
        ``BoundParams`` — all placeholders resolved, params substituted.
        ``Unbound`` — one or more placeholders had no non-empty value.
    """
    resolved: dict[str, Any] = {}
    missing: list[str] = []

    for placeholder, source_paths in template.binding_sources.items():
        value = _MISSING
        for path in source_paths:
            candidate = _resolve_path(workflow_state, path)
            if _has_value(candidate):
                value = candidate
                break

        if not _has_value(value):
            missing.append(placeholder)
        else:
            resolved[placeholder] = value

    if missing:
        return Unbound(missing=sorted(missing))

    # Substitute resolved values into template params.
    substituted_params: dict[str, Any] = {
        k: _substitute(v, resolved) for k, v in template.params.items()
    }
    return BoundParams(params=substituted_params)
