"""MCP consumer-handshake dependency (Phase 1b §3.5.1).

`require_consumer` is the FastAPI dependency every MCP transport
endpoint hangs off. It runs the auth chain documented in §3.5.1 of
``docs/selph_mcp_distribution_implementation_plan.md``:

    1. ``X-API-Key`` validated against the shared ``SELPH_API_KEY`` env
       (same transport secret as every other FastAPI route today —
       implementation mirrored locally to keep ``selph_mcp`` from
       importing ``ingestion_api`` per the import-linter
       ``mcp-surface-boundary`` contract).
    2. ``X-Selph-Consumer`` resolved against the ``mcp_consumers``
       table via ``mcp_consumer_manager.get_consumer``.
    3. Unknown ``consumer_id``  → ``HTTPException(400)``.
    4. ``revoked_at IS NOT NULL`` → ``HTTPException(401)`` regardless
       of API-key match.

Returns the in-memory :class:`Consumer` row to downstream handlers.

Anti-bypass binding
-------------------
The consumer-to-user binding (rejecting payload-supplied ``user_id``
values that disagree with ``consumer.user_id``) is enforced inside
each kernel tool that accepts ``user_id`` in its payload — this
dependency only validates the consumer's identity. See
``selph_mcp.kernel.observe`` / ``query`` / ``project`` / ``revise``
for the per-tool binding checks.

Stdio transport
---------------
For stdio transports the headers come from the MCP request metadata
(populated by the transport layer in
``selph_mcp.server.mcp_app``); for HTTP transports they arrive on the
HTTP request itself. Either way the dependency only sees the
strings — the surface that wraps it is responsible for adapting
metadata into headers.

See:
  - ingestion_api/auth.py  (parallel ``require_api_key`` — kept in sync)
  - selph_db/mcp_consumer_manager.py  (consumer row lookup)
  - .claude/rules/naming-and-constraints.md  (mandatory logging)
"""
from __future__ import annotations

import json
import logging
import os
from typing import Optional

from fastapi import Depends, Header, HTTPException, Response, Security, status
from fastapi.security import APIKeyHeader

from selph_mcp._client import EngineUpstreamError, get_client
from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.versions import HARNESS_ADAPTER_VERSION, load_contract_versions
from selph_mcp.contracts.whoami import Whoami
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.auth.consumer_handshake")

# Header names for contract-version negotiation (§3.6).
_SERVER_VERSIONS_HEADER = "X-Selph-Server-Contract-Versions"
_ADAPTER_VERSION_HEADER = "X-Selph-Adapter-Contract-Version"


def add_contract_versions_header(response: Response) -> None:
    """Stamp ``X-Selph-Server-Contract-Versions`` onto ``response``.

    The header value is the JSON-serialized ``ContractVersions`` block.
    Called from middleware or per-route response injection (§3.6).
    """
    try:
        versions = load_contract_versions()
        header_value = json.dumps(versions.model_dump(), sort_keys=True, separators=(",", ":"))
        response.headers[_SERVER_VERSIONS_HEADER] = header_value
    except Exception as exc:
        _log.warning(
            "failed to stamp contract versions header",
            extra={
                "event": "mcp.auth.contract_versions_header.failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )


def check_adapter_version_header(adapter_version_str: Optional[str]) -> None:
    """Emit a WARNING when the incoming adapter version is older than server's.

    §3.6: graceful degradation — do NOT reject; only warn. Called from
    ``require_consumer`` on each request.

    Args:
        adapter_version_str: Value of ``X-Selph-Adapter-Contract-Version``
            header, or ``None`` / empty if absent.
    """
    if not adapter_version_str:
        return  # Header absent — no version negotiation, silent pass.
    try:
        adapter_version = int(adapter_version_str.strip())
    except (ValueError, AttributeError):
        _log.debug(
            "unparseable X-Selph-Adapter-Contract-Version header; ignoring",
            extra={
                "event": "mcp.auth.adapter_version.unparseable",
                "received": str(adapter_version_str)[:50],
            },
        )
        return

    if adapter_version < HARNESS_ADAPTER_VERSION:
        log_event(
            _log,
            logging.WARNING,
            "mcp.auth.adapter_version.stale",
            adapter_version=adapter_version,
            server_harness_adapter_version=HARNESS_ADAPTER_VERSION,
        )


# Shared-secret transport check. Identical semantics to
# ``ingestion_api.auth.require_api_key`` but redeclared here so
# ``selph_mcp`` does not violate the
# ``mcp-surface-boundary`` import-linter contract (no ``ingestion_api``
# imports). Both definitions read the same ``SELPH_API_KEY`` env var so
# rotating the key still propagates everywhere with a single env update.
_API_KEY_HEADER = APIKeyHeader(name="X-API-Key", auto_error=False)


def require_api_key(api_key: str = Security(_API_KEY_HEADER)) -> str:
    """FastAPI dependency that validates the ``X-API-Key`` header.

    Mirrors :func:`ingestion_api.auth.require_api_key`. The two live
    side by side because the import-linter forbids ``selph_mcp`` from
    pulling in ``ingestion_api``; both read ``SELPH_API_KEY`` so a
    single env change rotates both surfaces together.
    """
    server_key = os.getenv("SELPH_API_KEY", "")
    if not server_key:
        log_event(
            _log, logging.ERROR, "mcp.auth.api_key.unconfigured",
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="SELPH_API_KEY is not configured on this server.",
        )
    if api_key != server_key:
        log_event(
            _log, logging.WARNING, "mcp.auth.api_key.mismatch",
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key.",
            headers={"WWW-Authenticate": "ApiKey"},
        )
    return api_key


async def require_consumer(
    consumer_id: str = Header(
        ...,
        alias="X-Selph-Consumer",
        description=(
            "Stable consumer identifier (e.g. ``cns-<8hex>``) registered "
            "via ``POST /apps/mcp/consumers``. Identifies the harness/scope "
            "the request is attributed to — not a credential."
        ),
    ),
    _api_key: str = Depends(require_api_key),
    adapter_version: Optional[str] = Header(
        default=None,
        alias="X-Selph-Adapter-Contract-Version",
        description=(
            "Optional: harness adapter contract version (integer string). "
            "Used for version negotiation — server warns but does NOT "
            "reject when adapter is older than the server's harness_adapter_version."
        ),
        include_in_schema=False,
    ),
) -> Consumer:
    """Resolve ``X-Selph-Consumer`` to a :class:`Consumer` row.

    Order of operations matches §3.5.1:
      1. ``require_api_key`` runs first via ``Depends`` chain.
      2. Header is required (FastAPI raises 422 if missing).
      3. Row lookup — ``None`` → ``HTTPException(400)``.
      4. Revoked rows → ``HTTPException(401)`` even though the API key
         matched. Revoking a consumer immediately closes its window
         regardless of which transport secret it presents.

    Returns:
        The fully-hydrated :class:`Consumer`.

    Raises:
        HTTPException: 400 (unknown consumer), 401 (revoked or API key
            invalid via the upstream dependency), 422 (header missing).

    Notes:
        ``Depends(require_api_key)`` only fires through FastAPI's
        dependency-injection machinery — it does **not** run when this
        function is invoked as a plain Python callable from the stdio /
        streamable-http MCP transport bridge in
        ``selph_mcp.server.mcp_app._consumer_from_ctx``. To guarantee
        the API-key check on every code path, we explicitly invoke
        :func:`require_api_key` as the first statement of the body.
        The ``Depends(...)`` annotation is kept so FastAPI DI still
        pre-validates (defence in depth — the inner call is a string
        compare, no extra cost).
    """
    # Explicit call so the API-key check runs even when this function is
    # invoked directly (stdio / streamable-http bridge), not only via
    # FastAPI's dependency injection. See docstring above.
    require_api_key(api_key=_api_key)

    # §3.6 — warn on stale adapter version (graceful, never reject).
    check_adapter_version_header(adapter_version)

    cid = (consumer_id or "").strip()
    if not cid:
        # Defensive — ``Header(...)`` already enforces presence so this
        # branch only fires when the caller sent an empty string.
        log_event(
            _log, logging.WARNING, "mcp.auth.consumer_handshake.bad_request",
            reason="empty_consumer_id",
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="X-Selph-Consumer header is required and must be non-empty.",
        )

    log_event(
        _log, logging.INFO, "mcp.auth.consumer_handshake.entry",
        consumer_id=cid,
    )

    try:
        data = await get_client().get("/apps/mcp/whoami")
    except EngineUpstreamError as exc:
        # /whoami only returns 401 (revoked / invalid key) or 5xx.
        # 400/403/404 are not part of its contract — map everything non-401
        # to 500 so a contract change on the server side is immediately
        # visible rather than silently becoming a 400 to the caller.
        if exc.status_code == 401:
            log_event(
                _log, logging.WARNING, "mcp.auth.consumer_handshake.revoked",
                consumer_id=cid,
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Consumer {cid!r} is revoked or key is invalid.",
                headers={"WWW-Authenticate": "ApiKey"},
            ) from exc
        log_event(
            _log, logging.ERROR, "mcp.auth.consumer_handshake.lookup_failed",
            consumer_id=cid,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Consumer lookup failed.",
        ) from exc
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "mcp.auth.consumer_handshake.lookup_failed",
            consumer_id=cid,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Consumer lookup failed.",
        ) from exc

    try:
        whoami = Whoami.model_validate(data)
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "mcp.auth.consumer_handshake.parse_failed",
            consumer_id=cid,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Consumer parse failed.",
        ) from exc

    # Whoami.model_validate above validates the response contract (rule 6).
    # On the mounted-MCP path, auth.py uses X-Consumer-Id as the DB lookup
    # key, so whoami.consumer_id ≡ cid by construction.  However on the
    # stdio / non-mounted HTTP path, _client.py._headers() injects
    # X-Consumer-Id from self._consumer_id (env-bound at construction),
    # while cid is read from the outer X-Selph-Consumer header supplied by
    # the caller.  If these diverge the request would authenticate as the
    # wrong identity — detect and reject explicitly rather than silently
    # proceeding as the wrong consumer.
    whoami_validated = whoami  # already model_validate'd above
    if whoami_validated.consumer_id != cid:
        log_event(
            _log, logging.ERROR, "mcp.auth.consumer_handshake.identity_mismatch",
            consumer_id=cid,
            whoami_consumer_id=whoami_validated.consumer_id,
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="X-Consumer-Id header does not match authenticated bearer identity.",
        )
    consumer = Consumer.model_validate(whoami_validated.model_dump())

    if consumer.revoked_at is not None:
        log_event(
            _log, logging.WARNING, "mcp.auth.consumer_handshake.revoked",
            consumer_id=cid,
            user_id=consumer.user_id,
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Consumer {cid!r} is revoked.",
            headers={"WWW-Authenticate": "ApiKey"},
        )

    log_event(
        _log, logging.INFO, "mcp.auth.consumer_handshake.complete",
        consumer_id=cid,
        user_id=consumer.user_id,
        harness_id=consumer.harness_id,
    )
    return consumer


__all__ = [
    "require_consumer",
    "require_api_key",
    "add_contract_versions_header",
    "check_adapter_version_header",
]
