"""MCP transport-handshake auth (Phase 1b §3.5.1).

Public surface — re-exports the FastAPI-style consumer dependency used by
both transport entry points (HTTP and stdio):

    from selph_mcp.auth import require_consumer

The kernel tool modules under :mod:`selph_mcp.kernel` consume the
resolved :class:`~selph_mcp.contracts.consumer.Consumer` to enforce the
consumer-to-user binding (anti-bypass) per §3.5.1 of the implementation
plan.
"""

from selph_mcp.auth.consumer_handshake import require_consumer

__all__ = ["require_consumer"]
