#!/usr/bin/env python3
"""Run MERaLiON inference on Apple Silicon via MLX.

Usage:
    # Transcribe audio (ASR)
    mlx-meralion --model MERaLiON/MERaLiON-2-10B-MLX --audio test.wav --task asr

    # Translate to Chinese
    mlx-meralion --model MERaLiON/MERaLiON-2-10B-MLX --audio test.wav --task translate_zh

    # Spoken question answering
    mlx-meralion --model MERaLiON/MERaLiON-2-10B-MLX --audio test.wav --task sqa --question "What is the speaker talking about?"

    # Custom instruction
    mlx-meralion --model MERaLiON/MERaLiON-2-10B-MLX --audio test.wav --instruction "Summarize this in one sentence."
"""

import argparse
import json
import shutil
import sys
import time
from collections import namedtuple
from pathlib import Path

import mlx.core as mx
import mlx.nn as nn
import numpy as np

from .processor import MERaLiONProcessor, get_task_prompt, load_audio, SAMPLE_RATE
from .whisper_encoder import WhisperEncoder, WhisperEncoderConfig
from .adaptor import create_adapter

# ---------------------------------------------------------------------------
# N-gram blocking sampler
# ---------------------------------------------------------------------------

NO_REPEAT_NGRAM_SIZE = 6


def make_no_repeat_ngram_sampler(ngram_size: int = NO_REPEAT_NGRAM_SIZE):
    """Create a greedy sampler that blocks repeated n-grams.

    Tracks generated n-grams and falls back to the next-best token when
    the greedy choice would create a repeated n-gram. This matches the
    behavior of HuggingFace's no_repeat_ngram_size in generation_config.json.

    Note: calls int() per token which forces synchronous evaluation.
    This is acceptable because mlx-lm's generate_step already calls
    y.item() before yield, so the token is already materialized.
    Requires sufficient GPU memory to avoid thrashing.

    Returns a sampler compatible with mlx-lm's generate_step(sampler=...).
    """
    prefix_to_next: dict[tuple[int, ...], set[int]] = {}
    id_list: list[int] = []

    def _register(token: int):
        id_list.append(token)
        if len(id_list) >= ngram_size:
            prefix = tuple(id_list[-ngram_size:-1])
            if prefix not in prefix_to_next:
                prefix_to_next[prefix] = set()
            prefix_to_next[prefix].add(id_list[-1])

    def sampler(logits: mx.array) -> mx.array:
        flat = logits.reshape(-1) if logits.ndim == 2 else logits
        token = mx.argmax(flat)
        tid = int(token)

        if len(id_list) >= ngram_size - 1:
            ctx = tuple(id_list[-(ngram_size - 1) :])
            banned = prefix_to_next.get(ctx)
            if banned and tid in banned:
                sorted_ids = mx.argsort(flat)[::-1]
                for candidate in sorted_ids:
                    cid = int(candidate)
                    if cid not in banned:
                        tid = cid
                        token = candidate
                        break

        _register(tid)
        return token.reshape(logits.shape[:-1]) if logits.ndim == 2 else token

    return sampler


def _wrap_sampler_with_ngram_blocking(base_sampler, ngram_size: int = NO_REPEAT_NGRAM_SIZE):
    """Wrap any sampler (including temperature>0) with n-gram blocking.

    Runs the base sampler first, then checks if the chosen token would
    create a repeated n-gram. If so, falls back to the next-best token
    by logit ranking (ignoring the base sampler's stochastic choice).

    For temperature=0 (base_sampler is None), uses the greedy n-gram sampler.
    """
    if base_sampler is None:
        return make_no_repeat_ngram_sampler(ngram_size)

    prefix_to_next: dict[tuple[int, ...], set[int]] = {}
    id_list: list[int] = []

    def _register(token: int):
        id_list.append(token)
        if len(id_list) >= ngram_size:
            prefix = tuple(id_list[-ngram_size:-1])
            if prefix not in prefix_to_next:
                prefix_to_next[prefix] = set()
            prefix_to_next[prefix].add(id_list[-1])

    def wrapped_sampler(logits: mx.array) -> mx.array:
        token = base_sampler(logits)
        tid = int(token.reshape(-1)[0]) if token.ndim > 0 else int(token)

        if len(id_list) >= ngram_size - 1:
            ctx = tuple(id_list[-(ngram_size - 1) :])
            banned = prefix_to_next.get(ctx)
            if banned and tid in banned:
                flat = logits.reshape(-1) if logits.ndim == 2 else logits
                sorted_ids = mx.argsort(flat)[::-1]
                for candidate in sorted_ids:
                    cid = int(candidate)
                    if cid not in banned:
                        tid = cid
                        token = candidate.reshape(token.shape)
                        break

        _register(tid)
        return token

    return wrapped_sampler


# ---------------------------------------------------------------------------
# Model directory detection and auto-conversion
# ---------------------------------------------------------------------------


def is_converted_dir(model_dir: Path) -> bool:
    """Check if model_dir contains converted MLX weights."""
    return (model_dir / "encoder_config.json").exists()


def is_raw_hf_dir(model_dir: Path) -> bool:
    """Check if model_dir contains raw HuggingFace model files."""
    return (model_dir / "config.json").exists() and any(model_dir.glob("model-*.safetensors"))


def auto_convert(model_dir: Path, verbose: bool = True) -> Path:
    """Auto-convert raw HF model to MLX format if needed.

    Returns the path to the converted model directory.
    """
    if is_converted_dir(model_dir):
        return model_dir

    if not is_raw_hf_dir(model_dir):
        raise FileNotFoundError(
            f"{model_dir} is neither a converted MLX dir nor a raw HF dir. "
            "Expected either encoder_config.json (converted) or model-*.safetensors (raw)."
        )

    converted_dir = model_dir.parent / f"{model_dir.name}-mlx"
    if is_converted_dir(converted_dir):
        if verbose:
            print(f"Using existing converted model: {converted_dir}")
        return converted_dir

    if verbose:
        print(f"Raw HF model detected. Auto-converting to {converted_dir}...")

    from .model import (
        load_config,
        load_weights,
        partition_weights,
        remap_whisper_keys,
        remap_adaptor_keys,
        save_component_weights,
    )

    converted_dir.mkdir(parents=True, exist_ok=True)
    config = load_config(model_dir)

    with open(converted_dir / "config.json", "w") as f:
        json.dump(config, f, indent=2)

    weights = load_weights(model_dir)
    encoder_w, ln_w, adaptor_w, decoder_w = partition_weights(weights)

    # Save encoder
    encoder_config = config.get("speech_config", {})
    with open(converted_dir / "encoder_config.json", "w") as f:
        json.dump(encoder_config, f, indent=2)
    remapped_enc = remap_whisper_keys(encoder_w)
    save_component_weights(remapped_enc, converted_dir / "encoder.safetensors")

    # Save adaptor (+ ln_speech)
    adaptor_config = {
        "speech_hidden_size": encoder_config.get("d_model", 1280),
        "text_hidden_size": config.get("text_config", {}).get("hidden_size", 3584),
        "scale_factor": config.get("speech_mlp_scale_factor", 15),
    }
    with open(converted_dir / "adaptor_config.json", "w") as f:
        json.dump(adaptor_config, f, indent=2)
    remapped_adp = remap_adaptor_keys(adaptor_w)
    ln_prefixed = {f"ln_speech.{k}": v for k, v in ln_w.items()}
    remapped_adp.update(ln_prefixed)
    save_component_weights(remapped_adp, converted_dir / "adaptor.safetensors")

    # Save decoder
    text_config = config.get("text_config", {})
    with open(converted_dir / "decoder_config.json", "w") as f:
        json.dump(text_config, f, indent=2)

    # Shard decoder weights if > 4GB
    total_bytes = sum(v.nbytes for v in decoder_w.values())
    max_shard_bytes = 4 * 1024**3
    if total_bytes <= max_shard_bytes:
        save_component_weights(decoder_w, converted_dir / "decoder.safetensors")
    else:
        shard_idx = 0
        current_shard = {}
        current_bytes = 0
        index_map = {}
        for key in sorted(decoder_w.keys()):
            val = decoder_w[key]
            if current_bytes + val.nbytes > max_shard_bytes and current_shard:
                fname = f"decoder-{shard_idx:05d}.safetensors"
                save_component_weights(current_shard, converted_dir / fname)
                shard_idx += 1
                current_shard = {}
                current_bytes = 0
            current_shard[key] = val
            current_bytes += val.nbytes
            fname = f"decoder-{shard_idx:05d}.safetensors"
            index_map[key] = fname
        if current_shard:
            fname = f"decoder-{shard_idx:05d}.safetensors"
            save_component_weights(current_shard, converted_dir / fname)
        with open(converted_dir / "decoder.safetensors.index.json", "w") as f:
            json.dump({"weight_map": index_map}, f, indent=2)

    # Copy tokenizer files
    for pattern in ("tokenizer*", "special_tokens*"):
        for src in model_dir.glob(pattern):
            dst = converted_dir / src.name
            if not dst.exists():
                shutil.copy2(src, dst)

    if verbose:
        print(f"Auto-conversion complete: {converted_dir}\n")

    return converted_dir


def resolve_model_dir(model: str, verbose: bool = True) -> Path:
    """Resolve a model string to a local directory path.

    Accepts:
        - Local path to a converted MLX directory
        - Local path to a raw HF directory (auto-converts)
        - HuggingFace repo ID like "MERaLiON/MERaLiON-2-10B-MLX" (auto-downloads)

    Returns:
        Path to the converted MLX model directory.
    """
    model_path = Path(model)

    # Local directory
    if model_path.exists():
        return auto_convert(model_path, verbose=verbose)

    # HuggingFace repo ID — download via huggingface_hub
    if "/" in model and not model_path.exists():
        if verbose:
            print(f"Downloading model from HuggingFace: {model}")
        from huggingface_hub import snapshot_download

        local_dir = snapshot_download(model)
        return auto_convert(Path(local_dir), verbose=verbose)

    raise FileNotFoundError(
        f"Model not found: {model}. "
        "Provide a local path or HuggingFace repo ID (e.g. MERaLiON/MERaLiON-2-10B-MLX)."
    )


# ---------------------------------------------------------------------------
# Component loading
# ---------------------------------------------------------------------------


def load_encoder(model_dir: Path) -> WhisperEncoder:
    """Load converted Whisper encoder."""
    config_path = model_dir / "encoder_config.json"
    weights_path = model_dir / "encoder.safetensors"

    with open(config_path) as f:
        config_dict = json.load(f)

    config = WhisperEncoderConfig.from_dict(config_dict)
    encoder = WhisperEncoder(config)

    weights = mx.load(str(weights_path))
    encoder.load_weights(list(weights.items()))
    mx.eval(encoder.parameters())

    return encoder


def detect_adaptor_variant(adaptor_weights: dict) -> str:
    """Detect whether weights are v1 (simple) or v2 (gated) adaptor."""
    keys = set(adaptor_weights.keys())
    if any("gate_proj" in k for k in keys):
        return "v2"
    return "v1"


def load_adaptor(model_dir: Path) -> tuple:
    """Load converted MLP adaptor and LayerNorm.

    Auto-detects v1 vs v2 adaptor architecture from weight keys.
    """
    config_path = model_dir / "adaptor_config.json"
    weights_path = model_dir / "adaptor.safetensors"

    with open(config_path) as f:
        config = json.load(f)

    all_weights = mx.load(str(weights_path))

    adaptor_weights = {}
    ln_weights = {}
    for key, value in all_weights.items():
        if key.startswith("ln_speech."):
            ln_weights[key[len("ln_speech.") :]] = value
        else:
            adaptor_weights[key] = value

    variant = detect_adaptor_variant(adaptor_weights)
    adaptor = create_adapter(
        variant=variant,
        speech_hidden_size=config["speech_hidden_size"],
        text_hidden_size=config["text_hidden_size"],
        scale_factor=config["scale_factor"],
    )

    ln_speech = nn.LayerNorm(config["speech_hidden_size"])

    adaptor.load_weights(list(adaptor_weights.items()))
    ln_speech.load_weights(list(ln_weights.items()))
    mx.eval(adaptor.parameters())
    mx.eval(ln_speech.parameters())

    return adaptor, ln_speech


def load_decoder(model_dir: Path):
    """Load text decoder using mlx-lm.

    Returns:
        (model, tokenizer) from mlx-lm
    """
    try:
        from mlx_lm import load as mlx_lm_load

        decoder_config_path = model_dir / "decoder_config.json"
        if not decoder_config_path.exists():
            raise FileNotFoundError(
                f"decoder_config.json not found in {model_dir}. Run convert.py first."
            )

        decoder_dir = model_dir / "decoder"
        decoder_dir.mkdir(exist_ok=True)

        shutil.copy2(decoder_config_path, decoder_dir / "config.json")

        for f in model_dir.glob("decoder*.safetensors"):
            target = decoder_dir / f.name.replace("decoder-", "model-")
            if not target.exists():
                target.symlink_to(f.resolve())

        for f in model_dir.glob("tokenizer*"):
            target = decoder_dir / f.name
            if not target.exists():
                shutil.copy2(f, target)

        for f in model_dir.glob("special_tokens*"):
            target = decoder_dir / f.name
            if not target.exists():
                shutil.copy2(f, target)

        model, tokenizer = mlx_lm_load(str(decoder_dir))
        return model, tokenizer

    except ImportError:
        print("Error: mlx-lm is required for decoder loading.")
        print("Install with: pip install mlx-lm")
        sys.exit(1)


def patch_decoder_for_embeddings(decoder_model):
    """Patch mlx-lm Gemma2 model to accept input_embeddings parameter.

    This enables use with mlx_lm.generate.generate_step(), which passes
    input_embeddings as a keyword argument. The patch adds a code path
    that uses provided embeddings instead of calling embed_tokens, while
    preserving ALL model internals: sqrt scaling, mask creation, attention
    softcapping, layer iteration, final logit softcapping.
    """
    from mlx_lm.models.base import create_attention_mask

    inner = decoder_model.model

    def patched_inner_call(self, inputs, cache=None, input_embeddings=None):
        if input_embeddings is not None:
            h = input_embeddings
        else:
            h = self.embed_tokens(inputs)
        h = h * (self.args.hidden_size**0.5)

        if cache is None:
            cache = [None] * len(self.layers)

        mask = create_attention_mask(h, cache[0], return_array=True)

        # Gemma2 GQA reshapes scores to 5D (B, n_kv, repeats, L, S).
        # The mask from BatchKVCache is 4D (B, 1, L, S) which doesn't
        # broadcast correctly when B>1. Add an extra dim so it becomes
        # (B, 1, 1, L, S) which broadcasts with any 5D score shape.
        if (
            mask is not None
            and mask.ndim == 4
            and hasattr(self.args, "num_key_value_heads")
            and self.args.num_key_value_heads != self.args.num_attention_heads
        ):
            mask = mask[:, :, None, :, :]

        for layer, c in zip(self.layers, cache):
            h = layer(h, mask, c)

        return self.norm(h)

    def patched_outer_call(self, inputs, cache=None, input_embeddings=None):
        out = self.model(inputs, cache, input_embeddings=input_embeddings)
        out = self.model.embed_tokens.as_linear(out)
        out = mx.tanh(out / self.final_logit_softcapping)
        out = out * self.final_logit_softcapping
        return out

    type(inner).__call__ = patched_inner_call
    type(decoder_model).__call__ = patched_outer_call


def build_merged_embeddings(
    decoder_model,
    input_ids: mx.array,
    speech_embeds: mx.array,
    speech_token_index: int,
) -> mx.array:
    """Build merged text+speech embeddings (UNscaled).

    Returns UNscaled embeddings because the model's __call__ applies
    sqrt(hidden_size) scaling internally after embed_tokens.

    Uses vectorized operations instead of Python loops for efficiency.
    """
    embed_fn = decoder_model.model.embed_tokens
    text_embeds = embed_fn(input_ids)

    # Boolean mask: True where speech tokens should be inserted
    speech_mask = input_ids == speech_token_index  # (B, S)

    B, S, H = text_embeds.shape
    N_speech = speech_embeds.shape[1]  # number of speech tokens per batch

    # For each batch element, the speech_mask positions (in order) map 1:1
    # to speech_embeds positions. We build a flat index to scatter speech
    # embeddings into the correct positions.
    for b in range(B):
        # Find positions where speech tokens appear using mx.where
        mask_b = speech_mask[b]  # (S,)
        indices = mx.arange(S)
        # Select indices where mask is True, fill rest with S (out of bounds sentinel)
        speech_positions = mx.where(mask_b, indices, mx.full(indices.shape, S))
        speech_positions = mx.sort(speech_positions)
        # Count actual speech positions (those < S)
        n_actual = int(mx.sum(mask_b))
        n_pos = min(n_actual, N_speech)
        # Replace text embeddings at speech positions with speech embeddings
        for i in range(n_pos):
            pos = int(speech_positions[i])
            text_embeds = text_embeds.at[b, pos].add(speech_embeds[b, i] - text_embeds[b, pos])

    return text_embeds


def build_merged_embeddings_single(
    decoder_model,
    input_ids: mx.array,
    speech_embeds: mx.array,
    speech_token_index: int,
) -> mx.array:
    """Build merged embeddings for a single (unbatched) sequence.

    Optimized path for single-sequence inference: avoids batch-dim loops,
    uses mx.argwhere + scatter for O(1) Python overhead regardless of
    sequence length.

    Args:
        decoder_model: Gemma2 decoder with embed_tokens
        input_ids: (1, S) or (S,) token IDs
        speech_embeds: (1, N, H) speech embeddings from adaptor
        speech_token_index: token ID for <SpeechHere> (e.g. 255999)

    Returns:
        (1, S, H) merged embeddings (unscaled)
    """
    if input_ids.ndim == 1:
        input_ids = input_ids[None, :]
    if speech_embeds.ndim == 2:
        speech_embeds = speech_embeds[None, :, :]

    embed_fn = decoder_model.model.embed_tokens
    text_embeds = embed_fn(input_ids)  # (1, S, H)

    mask = input_ids[0] == speech_token_index
    S = input_ids.shape[1]
    indices = mx.arange(S)
    speech_positions = mx.where(mask, indices, mx.full(indices.shape, S))
    speech_positions = mx.sort(speech_positions)
    n_actual = int(mx.sum(mask))
    n_pos = min(n_actual, speech_embeds.shape[1])

    for i in range(n_pos):
        pos = int(speech_positions[i])
        text_embeds = text_embeds.at[0, pos].add(speech_embeds[0, i] - text_embeds[0, pos])

    return text_embeds


# ---------------------------------------------------------------------------
# Model loading and segment-level inference
# ---------------------------------------------------------------------------

LoadedModel = namedtuple(
    "LoadedModel",
    [
        "encoder",
        "adaptor",
        "ln_speech",
        "decoder",
        "processor",
    ],
)


def load_model(model: str | Path, verbose: bool = True) -> LoadedModel:
    """Load all model components.

    Args:
        model: Local path to MLX model directory, or HuggingFace repo ID
               (e.g. "MERaLiON/MERaLiON-2-10B-MLX"). HF repos are
               automatically downloaded and cached.
        verbose: Print loading progress

    Returns:
        LoadedModel namedtuple that can be reused across segments.
    """
    model_dir = resolve_model_dir(str(model), verbose=verbose)

    if verbose:
        print("Loading model components...")

    t0 = time.time()
    encoder = load_encoder(model_dir)
    if verbose:
        print(f"  Encoder loaded in {time.time() - t0:.1f}s")

    t0 = time.time()
    adaptor, ln_speech = load_adaptor(model_dir)
    if verbose:
        print(f"  Adaptor loaded in {time.time() - t0:.1f}s")

    t0 = time.time()
    decoder, _ = load_decoder(model_dir)
    if verbose:
        print(f"  Decoder loaded in {time.time() - t0:.1f}s")

    patch_decoder_for_embeddings(decoder)
    processor = MERaLiONProcessor(model_dir)

    return LoadedModel(encoder, adaptor, ln_speech, decoder, processor)


def _infer_segment(
    model: LoadedModel,
    audio_array: np.ndarray,
    instruction: str,
    max_new_tokens: int = 256,
    temperature: float = 0.0,
    verbose: bool = True,
) -> str:
    """Run inference on a single audio segment.

    N-gram blocking (size=6) is always enabled to match HuggingFace
    generation_config.json and prevent repetitive output.
    """
    from mlx_lm.generate import generate_step

    # Prepare audio (chunked into 30s pieces internally)
    mel_features, num_chunks = model.processor.prepare_audio(
        audio_array=audio_array,
        max_duration=None,
    )
    mel_mx = mx.array(mel_features)
    if verbose:
        print(f"  Mel: {mel_features.shape} ({num_chunks} chunk{'s' if num_chunks > 1 else ''})")

    # Prepare text (expands <SpeechHere> to 100 * num_chunks positions)
    text_inputs = model.processor.prepare_text(instruction, num_chunks=num_chunks)
    input_ids = mx.array(text_inputs["input_ids"])

    # Encode speech — batch all chunks in one forward pass
    t0 = time.time()
    enc_out = model.encoder(mel_mx)  # (num_chunks, 1500, 1280)
    enc_out = model.ln_speech(enc_out)  # (num_chunks, 1500, 1280)
    speech_embeds = model.adaptor(enc_out)  # (num_chunks, 100, H)
    speech_embeds = speech_embeds.reshape(1, -1, speech_embeds.shape[-1])
    mx.eval(speech_embeds)
    if verbose:
        print(f"  Encoded {num_chunks} chunk(s) in {time.time() - t0:.2f}s")

    # Build merged embeddings
    t0 = time.time()
    merged_embeds = build_merged_embeddings(
        model.decoder,
        input_ids,
        speech_embeds,
        model.processor.speech_token_index,
    )
    mx.eval(merged_embeds)

    # Generate with n-gram blocking always enabled (greedy and sampling)
    from mlx_lm.sample_utils import make_sampler

    prompt_tokens = input_ids[0]
    embeddings_2d = merged_embeds[0]

    base_sampler = make_sampler(temp=temperature) if temperature > 0 else None
    sampler = _wrap_sampler_with_ngram_blocking(base_sampler, NO_REPEAT_NGRAM_SIZE)

    eos_tokens = {1, 107}
    if (
        hasattr(model.processor.tokenizer, "eos_token_id")
        and model.processor.tokenizer.eos_token_id is not None
    ):
        eos_tokens.add(model.processor.tokenizer.eos_token_id)

    generated_tokens = []
    for token, logprobs in generate_step(
        prompt=prompt_tokens,
        model=model.decoder,
        max_tokens=max_new_tokens,
        sampler=sampler,
        input_embeddings=embeddings_2d,
    ):
        token_id = token.item() if hasattr(token, "item") else int(token)
        if token_id in eos_tokens:
            break
        generated_tokens.append(token_id)

    gen_time = time.time() - t0
    response = model.processor.decode(generated_tokens)

    if verbose:
        n_tokens = len(generated_tokens)
        tps = n_tokens / gen_time if gen_time > 0 else 0
        print(f"  Generated {n_tokens} tokens in {gen_time:.2f}s ({tps:.1f} tok/s)")

    return response


# ---------------------------------------------------------------------------
# High-level API
# ---------------------------------------------------------------------------

_CHUNK_SAMPLES = 30 * 16000  # 480000 samples = 30s at 16kHz
_MIN_LAST_CHUNK = 10 * 16000  # 160000 samples = 10s


def transcribe(
    model: LoadedModel,
    audio: str | np.ndarray,
    task: str = "asr",
    max_new_tokens: int = 512,
    temperature: float = 0.0,
    verbose: bool = False,
    **task_kwargs,
) -> str:
    """Transcribe or process audio using a loaded MERaLiON model.

    Smart chunking: splits long audio at 30s boundaries, merges short
    (<10s) tail segments with the previous chunk to prevent hallucination.
    N-gram blocking is always enabled.

    Args:
        model: LoadedModel from load_model()
        audio: Path to audio file, or pre-loaded 16kHz float32 numpy array
        task: Task key (asr, translate_zh, translate_id, translate_ms,
              translate_ta, sqa, summarize, paralinguistics)
        max_new_tokens: Maximum tokens to generate per chunk
        temperature: Sampling temperature (0 = greedy)
        verbose: Print progress info
        **task_kwargs: Extra args for task prompt (e.g. question="..." for sqa)

    Returns:
        Generated text string
    """
    instruction = get_task_prompt(task, **task_kwargs)

    # Load audio if path given
    if isinstance(audio, (str, Path)):
        audio_array = load_audio(str(audio))
    else:
        audio_array = audio

    # Short audio: single inference call
    if len(audio_array) <= _CHUNK_SAMPLES:
        return _infer_segment(
            model,
            audio_array,
            instruction,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            verbose=verbose,
        )

    # Long audio: smart chunking
    segments = [
        audio_array[start : start + _CHUNK_SAMPLES]
        for start in range(0, len(audio_array), _CHUNK_SAMPLES)
    ]

    # Merge short last segment into the previous one
    if len(segments) > 1 and len(segments[-1]) < _MIN_LAST_CHUNK:
        segments = segments[:-2] + [np.concatenate([segments[-2], segments[-1]])]

    parts = []
    for i, seg in enumerate(segments):
        if verbose:
            print(f"[Chunk {i + 1}/{len(segments)}]")
        text = _infer_segment(
            model,
            seg,
            instruction,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            verbose=verbose,
        )
        parts.append(text.strip())

    return " ".join(p for p in parts if p)


# ---------------------------------------------------------------------------
# Batch inference
# ---------------------------------------------------------------------------


def _encode_audio(model: LoadedModel, audio_array: np.ndarray, verbose: bool = False):
    """Encode a single audio array through encoder + adaptor.

    All chunks are batched through encoder/ln_speech/adaptor in one forward
    pass (they share the same mel dimensions since audio is padded to 30s).

    Returns speech embeddings ready for merging into text sequence.
    """
    mel_features, num_chunks = model.processor.prepare_audio(
        audio_array=audio_array,
        max_duration=None,
    )
    mel_mx = mx.array(mel_features)  # (num_chunks, num_mel_bins, time)

    # Batch all chunks through encoder + adaptor in one pass
    enc_out = model.encoder(mel_mx)  # (num_chunks, 1500, 1280)
    enc_out = model.ln_speech(enc_out)  # (num_chunks, 1500, 1280)
    speech_embeds = model.adaptor(enc_out)  # (num_chunks, 100, H)

    # Merge chunks into single sequence: (1, num_chunks*100, H)
    speech_embeds = speech_embeds.reshape(1, -1, speech_embeds.shape[-1])
    mx.eval(speech_embeds)
    return speech_embeds, num_chunks


def _prepare_embeddings(
    model: LoadedModel,
    audio_array: np.ndarray,
    instruction: str,
) -> tuple[mx.array, mx.array]:
    """Prepare merged embeddings and input_ids for one audio sample.

    Returns:
        (merged_embeds_2d, input_ids_1d) — both without batch dimension
    """
    speech_embeds, num_chunks = _encode_audio(model, audio_array)
    text_inputs = model.processor.prepare_text(instruction, num_chunks=num_chunks)
    input_ids = mx.array(text_inputs["input_ids"])

    merged_embeds = build_merged_embeddings_single(
        model.decoder,
        input_ids,
        speech_embeds,
        model.processor.speech_token_index,
    )
    return merged_embeds[0], input_ids[0]


def _left_pad_embeddings(embeds_list: list[mx.array]) -> tuple[mx.array, list[int]]:
    """Left-pad a list of 2D embedding tensors to the same length.

    Args:
        embeds_list: List of (seq_len_i, H) tensors

    Returns:
        (B, max_seq_len, H) padded tensor and list of left-padding amounts
    """
    lengths = [e.shape[0] for e in embeds_list]
    max_len = max(lengths)
    H = embeds_list[0].shape[-1]
    padding = [max_len - seq_len for seq_len in lengths]

    padded = []
    for embed, pad in zip(embeds_list, padding):
        if pad > 0:
            pad_tensor = mx.zeros((pad, H))
            padded.append(mx.concatenate([pad_tensor, embed], axis=0))
        else:
            padded.append(embed)
    return mx.stack(padded), padding


def _left_pad_ids(ids_list: list[mx.array]) -> mx.array:
    """Left-pad a list of 1D token ID tensors to the same length."""
    lengths = [len(ids) for ids in ids_list]
    max_len = max(lengths)
    return mx.array([[0] * (max_len - len(ids)) + ids.tolist() for ids in ids_list])


def batch_transcribe(
    model: LoadedModel,
    audios: list[str | np.ndarray],
    task: str = "asr",
    max_new_tokens: int = 512,
    temperature: float = 0.0,
    verbose: bool = False,
    **task_kwargs,
) -> list[str]:
    """Transcribe multiple audio files in a true GPU-batched decode.

    Uses the mlx-vlm BatchGenerator pattern: pre-compute merged embeddings
    for all audio, left-pad to uniform length, batch prefill with embeddings,
    then batch decode with token IDs only (embeddings baked into KV cache).

    Args:
        model: LoadedModel from load_model()
        audios: List of audio file paths or pre-loaded 16kHz float32 arrays
        task: Task key (asr, translate_zh, etc.)
        max_new_tokens: Maximum tokens to generate per audio
        temperature: Sampling temperature (0 = greedy)
        verbose: Print progress info
        **task_kwargs: Extra args for task prompt

    Returns:
        List of generated text strings, one per audio
    """
    from mlx_lm.models.cache import BatchKVCache

    instruction = get_task_prompt(task, **task_kwargs)
    B = len(audios)

    if verbose:
        print(f"Batch transcribe: {B} audio(s), task={task}")

    # Phase 1: Load audio
    audio_arrays = []
    for audio in audios:
        if isinstance(audio, (str, Path)):
            audio_arrays.append(load_audio(str(audio)))
        else:
            audio_arrays.append(audio)

    # Phase 2: Batch-encode all audio chunks through encoder+adaptor, then merge
    t0 = time.time()

    # 2a: Prepare mel features and text inputs for each audio
    all_mel_chunks = []  # list of (num_chunks_i, mel_bins, time) arrays
    all_num_chunks = []
    all_text_inputs = []
    for audio_array in audio_arrays:
        mel_features, num_chunks = model.processor.prepare_audio(
            audio_array=audio_array,
            max_duration=None,
        )
        all_mel_chunks.append(mx.array(mel_features))
        all_num_chunks.append(num_chunks)
        text_inputs = model.processor.prepare_text(instruction, num_chunks=num_chunks)
        all_text_inputs.append(mx.array(text_inputs["input_ids"]))

    # 2b: Stack ALL chunks across all audios into one big batch for encoder
    all_chunks_flat = mx.concatenate(all_mel_chunks, axis=0)  # (total_chunks, mel, time)
    enc_out = model.encoder(all_chunks_flat)
    enc_out = model.ln_speech(enc_out)
    all_speech_flat = model.adaptor(enc_out)  # (total_chunks, 100, H)
    mx.eval(all_speech_flat)

    # 2c: Split back per-audio and merge with text embeddings
    all_embeds = []  # list of (seq_len_i, H) — no batch dim
    all_input_ids = []  # list of (seq_len_i,) — no batch dim
    chunk_offset = 0
    for i in range(B):
        nc = all_num_chunks[i]
        speech_embeds = all_speech_flat[chunk_offset : chunk_offset + nc]
        speech_embeds = speech_embeds.reshape(1, -1, speech_embeds.shape[-1])
        chunk_offset += nc

        input_ids = all_text_inputs[i]
        merged = build_merged_embeddings_single(
            model.decoder,
            input_ids,
            speech_embeds,
            model.processor.speech_token_index,
        )
        all_embeds.append(merged[0])  # (seq_len, H)
        all_input_ids.append(input_ids[0])  # (seq_len,)

    if verbose:
        lens = [e.shape[0] for e in all_embeds]
        print(f"  Encoded {B} audio(s) in {time.time() - t0:.2f}s, seq_lens={lens}")

    # Phase 3: Left-pad to uniform length for batching
    batched_embeds, padding = _left_pad_embeddings(all_embeds)  # (B, S, H)
    batched_ids = _left_pad_ids(all_input_ids)  # (B, S)
    mx.eval(batched_embeds, batched_ids)

    # Phase 4: Create batch-aware KV cache (handles left-padding offsets)
    batch_cache = [BatchKVCache(padding) for _ in model.decoder.model.layers]

    # Phase 5: Prefill with embeddings — bakes audio info into KV cache
    t0 = time.time()
    prefill_step_size = 2048
    embeds_remaining = batched_embeds
    ids_remaining = batched_ids

    while embeds_remaining.shape[1] > 1:
        n = min(prefill_step_size, embeds_remaining.shape[1] - 1)
        model.decoder(
            ids_remaining[:, :n],
            cache=batch_cache,
            input_embeddings=embeds_remaining[:, :n],
        )
        mx.eval([c.state for c in batch_cache])
        embeds_remaining = embeds_remaining[:, n:]
        ids_remaining = ids_remaining[:, n:]
        mx.clear_cache()

    # Process last token to get first generated token
    logits = model.decoder(
        ids_remaining,
        cache=batch_cache,
        input_embeddings=embeds_remaining,
    )
    logits = logits[:, -1, :]  # (B, vocab)

    if verbose:
        print(f"  Prefill done in {time.time() - t0:.2f}s")

    # Phase 6: Batched autoregressive decode — token IDs only
    #
    # Key optimization: minimize GPU→CPU syncs. Instead of mx.eval every step,
    # we keep tokens on GPU and only sync every `check_interval` steps to see
    # if all sequences hit EOS. After generation, we sync once to read all tokens.
    t0 = time.time()

    eos_tokens = {1, 107}
    if (
        hasattr(model.processor.tokenizer, "eos_token_id")
        and model.processor.tokenizer.eos_token_id is not None
    ):
        eos_tokens.add(model.processor.tokenizer.eos_token_id)

    # Build EOS token array for GPU-side checking
    eos_arr = mx.array(sorted(eos_tokens))  # (E,)

    tokens_buf = []  # list of mx.array (B,) — all generated tokens
    done = mx.zeros((B,), dtype=mx.bool_)  # GPU-side per-sequence done flag
    check_interval = 8  # sync every N steps

    for step in range(max_new_tokens):
        y = mx.argmax(logits, axis=-1)  # (B,) — greedy, no logprobs needed
        tokens_buf.append(y)

        # GPU-side EOS check: is y[i] in eos_tokens?
        is_eos = mx.any(y[:, None] == eos_arr[None, :], axis=-1)  # (B,)
        done = done | is_eos

        # Only sync periodically to check if ALL sequences are done
        if (step + 1) % check_interval == 0:
            mx.eval(done)
            if bool(mx.all(done)):
                break

        # Forward pass with token IDs (KV cache has context)
        logits = model.decoder(y[:, None], cache=batch_cache)
        logits = logits[:, -1, :]

    # Sync all tokens at once
    if tokens_buf:
        mx.eval(*tokens_buf)

    # Reconstruct per-sequence token lists, truncating at first EOS
    generated = [[] for _ in range(B)]
    stopped = [False] * B
    for y_arr in tokens_buf:
        y_list = y_arr.tolist()
        for i in range(B):
            if stopped[i]:
                continue
            tid = y_list[i]
            if tid in eos_tokens:
                stopped[i] = True
            else:
                generated[i].append(tid)

    gen_time = time.time() - t0
    results = [model.processor.decode(g) for g in generated]

    if verbose:
        total_tokens = sum(len(g) for g in generated)
        tps = total_tokens / gen_time if gen_time > 0 else 0
        print(f"  Generated {total_tokens} tokens in {gen_time:.2f}s ({tps:.1f} tok/s)")

    return results


def _format_time(seconds: float) -> str:
    """Format seconds as M:SS or H:MM:SS."""
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


def run_inference(
    model_dir: Path,
    audio_path: str,
    instruction: str,
    max_new_tokens: int = 256,
    temperature: float = 0.0,
    max_audio_duration: float | None = None,
    segment_length: float = 300.0,
    show_segments: bool = True,
    show_full: bool = True,
    verbose: bool = True,
) -> str:
    """Run full MERaLiON inference pipeline with automatic segmentation.

    For audio longer than segment_length, the audio is split into
    independent segments. Each segment is processed through the full
    encode-merge-generate pipeline.

    Returns:
        Tuple of (generated_text, num_segments)
    """
    t_start = time.time()

    model = load_model(model_dir, verbose=verbose)

    if verbose:
        print(f"\nProcessing audio: {audio_path}")
    audio = load_audio(audio_path)
    total_duration = len(audio) / SAMPLE_RATE

    if max_audio_duration is not None:
        max_samples = int(max_audio_duration * SAMPLE_RATE)
        audio = audio[:max_samples]
        total_duration = len(audio) / SAMPLE_RATE

    if verbose:
        print(f"  Duration: {_format_time(total_duration)} ({total_duration:.1f}s)")

    segment_samples = int(segment_length * SAMPLE_RATE)
    num_segments = max(1, -(-len(audio) // segment_samples))

    if num_segments == 1:
        response = _infer_segment(
            model,
            audio,
            instruction,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            verbose=verbose,
        )
        if verbose:
            print(f"  Total pipeline: {time.time() - t_start:.2f}s")
        return response, 1

    if verbose:
        print(
            f"  Splitting into {num_segments} segments (up to {_format_time(segment_length)} each)"
        )

    results = []
    for seg_idx in range(num_segments):
        seg_start = seg_idx * segment_samples
        seg_end = min(seg_start + segment_samples, len(audio))
        seg_audio = audio[seg_start:seg_end]

        start_time = seg_start / SAMPLE_RATE
        end_time = seg_end / SAMPLE_RATE
        header = (
            f"[Segment {seg_idx + 1}/{num_segments}"
            f" | {_format_time(start_time)}\u2013{_format_time(end_time)}]"
        )

        if verbose or show_segments:
            print(f"\n{header}")

        text = _infer_segment(
            model,
            seg_audio,
            instruction,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            verbose=verbose,
        )
        results.append(text)

        if show_segments:
            print(text)

    combined = " ".join(results)

    if verbose:
        print(f"\n  Total pipeline: {time.time() - t_start:.2f}s ({num_segments} segments)")

    if show_full:
        print(f"\n{'=' * 60}")
        print(f"Full transcript:\n{combined}")
        print(f"{'=' * 60}")

    return combined, num_segments


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main():
    parser = argparse.ArgumentParser(description="MERaLiON inference on Apple Silicon via MLX")
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Path to MLX model directory or HuggingFace repo ID "
        "(e.g. MERaLiON/MERaLiON-2-10B-MLX)",
    )
    parser.add_argument(
        "--audio",
        type=str,
        required=True,
        help="Path to input audio file (WAV, MP3, FLAC, etc.)",
    )
    parser.add_argument(
        "--task",
        type=str,
        default=None,
        help="Predefined task: asr, translate_zh, translate_id, sqa, summarize, "
        "instruction, paralinguistics",
    )
    parser.add_argument(
        "--instruction",
        type=str,
        default=None,
        help="Custom text instruction (overrides --task)",
    )
    parser.add_argument(
        "--question",
        type=str,
        default=None,
        help="Question for SQA task",
    )
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=256,
        help="Maximum tokens to generate per segment (default: 256)",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.0,
        help="Sampling temperature (0 = greedy, default: 0.0)",
    )
    parser.add_argument(
        "--max-audio-duration",
        type=float,
        default=None,
        help="Truncate audio to this many seconds (default: no limit)",
    )
    parser.add_argument(
        "--segment-length",
        type=float,
        default=300.0,
        help="Maximum seconds per inference segment (default: 300).",
    )
    parser.add_argument(
        "--show-segments",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Print each segment's text as it completes (default: on)",
    )
    parser.add_argument(
        "--show-full",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Print combined full text after all segments (default: on)",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress verbose output",
    )

    args = parser.parse_args()

    if args.segment_length <= 0:
        print("Error: --segment-length must be > 0")
        sys.exit(1)

    if args.instruction:
        instruction = args.instruction
    elif args.task:
        kwargs = {}
        if args.task == "sqa":
            if not args.question:
                print("Error: --question is required for SQA task")
                sys.exit(1)
            kwargs["question"] = args.question
        instruction = get_task_prompt(args.task, **kwargs)
    else:
        instruction = get_task_prompt("asr")

    if not args.quiet:
        print(f"Task instruction: {instruction}")

    response, num_segments = run_inference(
        model_dir=args.model,
        audio_path=args.audio,
        instruction=instruction,
        max_new_tokens=args.max_tokens,
        temperature=args.temperature,
        max_audio_duration=args.max_audio_duration,
        segment_length=args.segment_length,
        show_segments=args.show_segments,
        show_full=args.show_full,
        verbose=not args.quiet,
    )

    if num_segments == 1:
        print(f"\n{'=' * 60}")
        print(f"Response:\n{response}")
        print(f"{'=' * 60}")


if __name__ == "__main__":
    main()
