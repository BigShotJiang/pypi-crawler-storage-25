lattics.core package
====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   lattics.core.spaces
   lattics.core.substrates

Module contents
---------------

.. automodule:: lattics.core
   :members:
   :show-inheritance:
   :undoc-members:
