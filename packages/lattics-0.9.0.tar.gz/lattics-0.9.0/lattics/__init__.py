# from ._version import get_versions

from lattics.utils.create import *

# __version__ = get_versions()["version"]
# del get_versions

__version__ = "0.9.0"
