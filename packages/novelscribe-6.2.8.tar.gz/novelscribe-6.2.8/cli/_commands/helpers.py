"""Shared helpers for CLI commands."""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

from services.global_settings import _PROVIDER_DEFAULTS as PROVIDER_DEFAULT_MODELS

ENV_PROVIDER_KEYS: list[tuple[str, str]] = [
    ("openai", "OPENAI_API_KEY"),
    ("anthropic", "ANTHROPIC_API_KEY"),
    ("google", "GOOGLE_API_KEY"),
    ("minimax", "MINIMAX_API_KEY"),
    ("zhipuai", "ZHIPUAI_API_KEY"),
    ("moonshot", "MOONSHOT_API_KEY"),
    ("ollama", "OLLAMA_BASE_URL"),
    ("lm_studio", "LM_STUDIO_BASE_URL"),
]


def configure_logging(verbose: int = 0, debug: bool = False) -> None:
    """Configure logging based on verbosity level."""
    from core.logging.structured import configure_structured_logging

    configure_structured_logging(
        level=logging.DEBUG if debug else logging.INFO,
        json_output=os.environ.get("SCRIBE_JSON_LOGS", "").lower() in ("1", "true"),
        verbose=verbose,
        debug=debug,
    )


def _canonicalize_provider(provider: str) -> str:
    """Normalize provider aliases to canonical IDs."""
    normalized = (provider or "").strip().lower()
    if normalized in {"lm-studio", "lmstudio"}:
        return "lm_studio"
    return normalized


def _detect_provider_from_setup() -> str:
    """Detect provider from configured environment variables."""
    for provider, env_key in ENV_PROVIDER_KEYS:
        if os.getenv(env_key):
            return _canonicalize_provider(provider)
    return ""


def _default_model_for_provider(provider: str) -> str:
    """Return default model for known provider."""
    return PROVIDER_DEFAULT_MODELS.get(_canonicalize_provider(provider), "gpt-5.1")


def _resolve_new_project_llm(provider: str, model: str) -> tuple[str, str]:
    """Resolve provider/model for `new` with setup inheritance.

    Resolution order:
    1. Explicit --provider/--model flags (highest priority)
    2. Global settings from ~/.scribe/settings.json
    3. Environment variable fallback
    4. Provider default (openai/gpt-5.1)
    """
    from services.global_settings import GlobalSettings

    explicit_provider = _canonicalize_provider(provider)
    explicit_model = (model or "").strip()

    gs = GlobalSettings.load()
    global_provider = gs.default_provider
    global_model = gs.default_model

    resolved_provider = (
        explicit_provider or global_provider or _detect_provider_from_setup() or "openai"
    )

    if explicit_model:
        resolved_model = explicit_model
    elif explicit_provider and explicit_provider == global_provider and global_model:
        resolved_model = global_model
    elif global_provider and global_provider == resolved_provider and global_model:
        resolved_model = global_model
    else:
        resolved_model = _default_model_for_provider(resolved_provider)

    return resolved_provider, resolved_model


def get_base_url_for_provider(provider: str) -> str | None:
    """Get configured base URL for a provider.

    Checks global settings first, then falls back to environment variables.
    """
    from services.global_settings import GlobalSettings

    gs = GlobalSettings.load()
    provider_settings = gs.get_provider_settings(provider)
    if provider_settings.base_url:
        return provider_settings.base_url

    env_key_map = {
        "openai": "OPENAI_API_BASE",
        "anthropic": None,
        "google": None,
        "minimax": "MINIMAX_BASE_URL",
        "zhipu": "ZHIPUAI_BASE_URL",
        "zhipuai": "ZHIPUAI_BASE_URL",
        "moonshot": "MOONSHOT_BASE_URL",
        "ollama": "OLLAMA_BASE_URL",
        "lm_studio": "LM_STUDIO_BASE_URL",
        "lmstudio": "LM_STUDIO_BASE_URL",
    }
    env_key = env_key_map.get(provider.lower())
    if env_key:
        return os.getenv(env_key)
    return None
