"""Command-line interface for novel writing harness."""

import logging
import sys
from difflib import get_close_matches
from pathlib import Path

import click
from dotenv import load_dotenv

from cli._commands._benchmark import benchmark
from cli._commands._creative_init import new, outline  # noqa: F401
from cli._commands._dashboard import dashboard
from cli._commands.agents import agents
from cli._commands.autonomous import autonomous
from cli._commands.character import character
from cli._commands.checkpoint import checkpoint
from cli._commands.config import config
from cli._commands.drafts import drafts
from cli._commands.export import export
from cli._commands.guardrails import guardrails
from cli._commands.helpers import (
    configure_logging,
)
from cli._commands.list import templates
from cli._commands.logs import logs
from cli._commands.memory import memory
from cli._commands.model import model
from cli._commands.pagination import cache, paginate
from cli._commands.parallel import parallel_cli
from cli._commands.performance import performance_cli
from cli._commands.plugins import plugins
from cli._commands.proactive import app as proactive
from cli._commands.project import project
from cli._commands.qa import qa
from cli._commands.review import review
from cli._commands.run import run
from cli._commands.setup import setup
from cli._commands.summary import summary
from cli._commands.tui import tui
from cli._commands.verify import verify
from cli._commands.version import version as version_cmd
from cli._commands.workflows import workflows
from cli._helpers.error_handling import handle_cli_exception
from cli._templates.create import template_create
from core._version import get_version
from core.git import create_git_manager
from core.llm.client import LLMConfig
from core.orchestration.pipeline import (
    create_orchestrator,  # noqa: F401 — kept for test patch targets
)
from services.project_service import ProjectService
from services.workflow_service import WorkflowService

load_dotenv()


_WORKFLOW_COMMANDS = [
    "setup",
    "new",
    "outline",
    "character",
    "write",
    "status",
    "export",
]


class ScribeCLI(click.Group):
    """Custom Click group with better error handling and grouped help."""

    def format_commands(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        commands = []
        for subcommand in self.list_commands(ctx):
            cmd = self.get_command(ctx, subcommand)
            if cmd is None or cmd.hidden:
                continue
            commands.append((subcommand, cmd))

        if not commands:
            return

        limit = formatter.width - 6 - max(len(cmd[0]) for cmd in commands)

        def _rows(names: list[str]) -> list[tuple[str, str]]:
            return [
                (name, self.get_command(ctx, name).get_short_help_str(limit))
                for name in names
                if self.get_command(ctx, name) and not self.get_command(ctx, name).hidden
            ]

        workflow_rows = _rows(_WORKFLOW_COMMANDS)
        auxiliary_names = sorted(name for name, _ in commands if name not in _WORKFLOW_COMMANDS)
        auxiliary_rows = _rows(auxiliary_names)

        if workflow_rows:
            with formatter.section("Workflow"):
                formatter.write_dl(workflow_rows)

        if auxiliary_rows:
            with formatter.section("Utilities"):
                formatter.write_dl(auxiliary_rows)

    def get_command(self, ctx: click.Context, cmd_name: str):
        """Get command by name, with suggestions for typos."""
        cmd = super().get_command(ctx, cmd_name)
        if cmd is not None:
            return cmd

        available_commands = list(self.commands.keys())
        suggestions = get_close_matches(cmd_name, available_commands, n=3, cutoff=0.4)

        if suggestions:
            suggestion_text = "\nDid you mean one of these?\n"
            for suggestion in suggestions:
                suggestion_text += f"  • {suggestion}\n"
            ctx.fail(f"No such command '{cmd_name}'.{suggestion_text}")
        else:
            ctx.fail(f"No such command '{cmd_name}'. Use 'scribe help' to see available commands.")


HELP_SHORT = {"help_option_names": ["-h", "--help"]}


@click.group(cls=ScribeCLI, context_settings=HELP_SHORT)
@click.option("-v", "--verbose", count=True, help="Increase verbosity (can be used multiple times)")
@click.option("-d", "--debug", is_flag=True, help="Enable debug mode")
@click.option(
    "--lang",
    type=click.Choice(["en", "zh-CN", "zh-TW"], case_sensitive=False),
    default=None,
    help="Language (en, zh-CN, zh-TW). Overrides project META.yaml.",
)
@click.version_option(version=get_version(), prog_name="scribe")
@click.option("--no-update-check", is_flag=True, help="Skip update check on startup")
@click.pass_context
def cli(
    ctx: click.Context, verbose: int, debug: bool, lang: str | None, no_update_check: bool
) -> None:
    """NovelScribe - AI-powered autonomous novel generation system."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["debug"] = debug
    ctx.obj["lang"] = lang

    configure_logging(verbose, debug)

    logger = logging.getLogger("scribe")
    logger.debug(f"Scribe CLI started (verbose={verbose}, debug={debug}, lang={lang})")

    if not no_update_check and not debug:
        try:
            from core.version import notify_if_update_available

            notify_if_update_available()
        except Exception:
            pass


@cli.command()
@click.argument("project_name")
@click.option("--chapter", "-c", required=True, type=int, help="Chapter number to write")
@click.option("--provider", default="openai", help="LLM provider to use")
@click.pass_context
def write(ctx: click.Context, project_name: str, chapter: int, provider: str) -> None:
    """Write a specific chapter."""
    debug = ctx.obj.get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        logger.info(f"Writing chapter {chapter} for: {project_name}")

        svc = ProjectService()
        project_path = svc.get_project_path(project_name)

        llm_config = LLMConfig(provider=provider)
        wf_svc = WorkflowService()
        result = wf_svc.execute_workflow_sync(
            project_name=project_name,
            workflow_path=str(Path(__file__).parent / "workflows" / "writing_phase.yaml"),
            variables={"chapter": chapter},
            llm_config=llm_config,
        )

        git_manager = create_git_manager(project_path, auto_commit=True)
        git_manager.auto_commit_step(
            agent="writer_agent",
            description=f"Write chapter {chapter}",
        )

        logger.info(f"✅ Chapter {chapter} written successfully for '{project_name}'")
        logger.info(f"   Executed {result.get('steps_executed', 0)} steps")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to write chapter: {e}", e, debug=debug)


@cli.command()
@click.argument("project_name")
@click.pass_context
def status(ctx: click.Context, project_name: str) -> None:
    """Show project status."""
    logger = logging.getLogger("scribe")

    try:
        svc = ProjectService()
        project_path = svc.get_project_path(project_name)

        git_manager = create_git_manager(project_path, auto_commit=False)
        repo_status = git_manager.status()

        logger.info(f"Project: {project_name}")
        logger.info(f"Location: {project_path}")
        logger.info(f"Git Repository: {'Yes' if repo_status['is_repository'] else 'No'}")

        if repo_status["is_repository"]:
            logger.info(f"Current Branch: {repo_status['current_branch']}")
            logger.info(f"Current Commit: {repo_status['current_commit']}")

            if repo_status["has_changes"]:
                logger.info(f"Uncommitted Changes: {len(repo_status['changed_files'])} files")
            else:
                logger.info("Uncommitted Changes: None")

            tags = git_manager.get_tags()
            if tags:
                logger.info(f"Milestones: {', '.join(tag['name'] for tag in tags)}")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to get status: {e}", e, debug=False)


@cli.command()
@click.argument("args", nargs=-1)
@click.option("--provider", default="", help="LLM provider to use (auto-detected if omitted)")
@click.option("--model", default="", help="LLM model to use (provider default if omitted)")
@click.pass_context
def help(ctx: click.Context, args: tuple[str, ...], provider: str, model: str) -> None:
    """Ask questions, get help, or start an interactive chat with AI.

    \b
    Interactive chat (no args):
      scribe help

    \b
    Subcommand help (first arg is a known subcommand):
      scribe help agents

    \b
    One-shot answer (first arg is NOT a known subcommand):
      scribe help how to create a new character?
      scribe help --provider anthropic what agents are available?
    """
    from cli._commands.chat import SETUP_HELP
    from core.chat import ChatEngine

    if args and args[0] in ctx.parent.command.commands:
        sub_cmd = ctx.parent.command.commands[args[0]]
        if sub_cmd:
            click.echo(sub_cmd.get_help(ctx))
            return

    lang = ctx.obj.get("lang") or ""
    engine = ChatEngine(provider=provider, model=model, lang=lang or None, project_dir=".")

    if not engine.is_configured():
        click.echo(SETUP_HELP)
        return

    question_text = " ".join(args).strip()
    if question_text:
        try:
            answer = engine.ask(question_text)
            click.echo(f"\n🤖 {answer}\n")
        except Exception as e:
            logger = logging.getLogger("scribe")
            logger.error(f"Chat failed: {e}")
            click.echo(f"\n❌ Error: {e}")
            click.echo("💡 Check your API key with: scribe setup verify\n")
    else:
        try:
            engine.run_interactive()
        except KeyboardInterrupt:
            click.echo("\n👋 Bye!")


cli.add_command(agents)
cli.add_command(character)
cli.add_command(workflows)
cli.add_command(run)
cli.add_command(autonomous)
cli.add_command(verify)
cli.add_command(drafts)
cli.add_command(paginate)
cli.add_command(cache)
cli.add_command(summary)
cli.add_command(memory)
cli.add_command(tui)
cli.add_command(model)
cli.add_command(performance_cli)
cli.add_command(version_cmd)
cli.add_command(config)
cli.add_command(setup)
cli.add_command(logs)
cli.add_command(new)
cli.add_command(outline)
cli.add_command(templates)
cli.add_command(template_create)
cli.add_command(proactive)
cli.add_command(checkpoint)
cli.add_command(export)
cli.add_command(review)
cli.add_command(qa)
cli.add_command(parallel_cli)
cli.add_command(project)
cli.add_command(guardrails)
cli.add_command(plugins)
cli.add_command(benchmark)
cli.add_command(dashboard)


def main() -> int:
    """Main entry point for CLI with improved error handling."""
    try:
        cli(obj={}, standalone_mode=False)
        return 0
    except click.exceptions.UsageError as e:
        msg = e.format_message() if hasattr(e, "format_message") else str(e)
        click.echo(f"❌ Usage Error: {msg}", err=True)
        click.echo("\n💡 Run 'scribe help' to see available commands.", err=True)
        return 1
    except click.exceptions.ClickException as e:
        # Handle other Click exceptions
        e.show()
        return 1
    except KeyboardInterrupt:
        # Handle Ctrl+C gracefully
        click.echo("\n⚠️  Operation cancelled by user.", err=True)
        return 130
    except Exception as e:
        # Handle unexpected errors with a clean message
        click.echo(f"❌ Unexpected error: {str(e)}", err=True)

        import logging

        logger = logging.getLogger("scribe")
        logger.debug("Full traceback:", exc_info=True)

        click.echo("\n💡 Run with -v or -vv for more verbose output.", err=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
