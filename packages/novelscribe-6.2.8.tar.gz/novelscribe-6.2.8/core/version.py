"""Version management and update checking for NovelScribe."""

import json
import logging
import shlex
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import requests
import toml

from core._version import get_version as get_imported_version

logger = logging.getLogger("scribe")

CACHE_DIR = Path.home() / ".scribe"
CACHE_FILE = CACHE_DIR / "update_cache.json"
CACHE_TTL_HOURS = 24


class VersionManager:
    """Manage version information and check for updates."""

    def __init__(self):
        self.current_version = self._get_current_version()
        self.package_name = "novelscribe"
        self.pypi_url = f"https://pypi.org/pypi/{self.package_name}/json"

    def _get_current_version(self) -> str:
        """Get the current version from _version.py (primary) or pyproject.toml (fallback)."""
        try:
            return get_imported_version()
        except Exception:
            logger.debug("Failed to get imported version")

        try:
            pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
            if pyproject_path.exists():
                pyproject_data = toml.load(pyproject_path)
                return pyproject_data.get("project", {}).get("version", "0.0.0")
        except Exception:
            logger.debug("Failed to read version from pyproject.toml")
        return "0.0.0"

    def get_version_info(self) -> dict[str, str]:
        """Get version information dictionary."""
        return {
            "current": self.current_version,
            "package": self.package_name,
        }

    def _read_cache(self) -> Optional[dict]:
        """Read cached update check result."""
        try:
            if not CACHE_FILE.exists():
                return None
            data = json.loads(CACHE_FILE.read_text())
            cached_at = datetime.fromisoformat(data.get("cached_at", ""))
            if datetime.now() - cached_at < timedelta(hours=CACHE_TTL_HOURS):
                data["cached"] = True
                return data
        except Exception:
            pass
        return None

    def _write_cache(self, data: dict) -> None:
        """Write update check result to cache."""
        try:
            CACHE_DIR.mkdir(parents=True, exist_ok=True)
            data["cached_at"] = datetime.now().isoformat()
            CACHE_FILE.write_text(json.dumps(data, indent=2))
        except Exception:
            logger.debug("Failed to write update cache")

    def check_for_updates(self, verbose: bool = False, force: bool = False) -> Optional[dict]:
        """
        Check if there's a newer version available on PyPI.

        Uses a 24h cache to avoid hitting PyPI on every command.

        Args:
            verbose: Print status messages.
            force: Skip cache and always check PyPI.

        Returns:
            dict with update info if available, None on error.
        """
        if not force:
            cached = self._read_cache()
            if cached is not None:
                return cached

        try:
            response = requests.get(self.pypi_url, timeout=10)
            if response.status_code == 200:
                pypi_data = response.json()
                latest_version = pypi_data.get("info", {}).get("version", "")

                if self._is_newer_version(latest_version):
                    release_date = (
                        pypi_data.get("releases", {})
                        .get(latest_version, [{}])[0]
                        .get("upload_time", "")
                    )
                    release_notes = self._get_release_notes(pypi_data, latest_version)

                    result = {
                        "current": self.current_version,
                        "latest": latest_version,
                        "update_available": True,
                        "release_date": release_date,
                        "release_notes": release_notes,
                        "upgrade_command": self._get_upgrade_command(),
                    }
                    self._write_cache(result)
                    return result
                else:
                    result = {
                        "current": self.current_version,
                        "latest": latest_version,
                        "update_available": False,
                    }
                    self._write_cache(result)
                    if verbose:
                        print(f"✓ You're running the latest version: {self.current_version}")
                    return result
        except requests.RequestException as e:
            if verbose:
                print(f"⚠ Could not check for updates: {e}")
        except Exception as e:
            if verbose:
                print(f"⚠ Error checking for updates: {e}")

        return None

    def _is_newer_version(self, latest: str) -> bool:
        """Compare versions to determine if latest is newer."""
        try:
            from packaging import version

            return version.parse(latest) > version.parse(self.current_version)
        except Exception:
            return False

    def _get_release_notes(self, pypi_data: dict, ver: str) -> str:
        """Extract release notes or summary from PyPI data."""
        try:
            info = pypi_data.get("info", {})
            summary = info.get("summary", "")
            description = info.get("description", "")[:500]
            return summary or description or "Visit PyPI for details"
        except Exception:
            return "Visit PyPI for details"

    def _get_upgrade_command(self) -> str:
        """Get the appropriate upgrade command based on installation method."""
        if self._installed_with_pipx():
            if self._pipx_installed_from_local():
                return "pipx install --force novelscribe"
            return "pipx upgrade novelscribe"
        elif self._installed_with_uv():
            return "uv pip install --upgrade novelscribe"
        else:
            return "pip install --upgrade novelscribe"

    def _installed_with_pipx(self) -> bool:
        """Check if installed with pipx."""
        try:
            result = subprocess.run(
                ["pipx", "list"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            return "novelscribe" in result.stdout
        except Exception:
            return False

    def _pipx_installed_from_local(self) -> bool:
        """Check if pipx installed from a local path (not PyPI)."""
        try:
            result = subprocess.run(
                ["pipx", "list", "--json"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                import json as _json

                data = _json.loads(result.stdout)
                for venv_info in data.get("venvs", {}).values():
                    main = venv_info.get("metadata", {}).get("main_package", {})
                    if main.get("package") == self.package_name:
                        source = main.get("package_or_url", "")
                        return bool(source) and not source.startswith(("http", self.package_name))
        except Exception:
            pass
        return False

    def _installed_with_pip(self) -> bool:
        """Check if installed with pip."""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", "novelscribe"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            return result.returncode == 0
        except Exception:
            return False

    def _installed_with_uv(self) -> bool:
        """Check if installed with uv."""
        try:
            result = subprocess.run(
                ["uv", "pip", "show", "novelscribe"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            return result.returncode == 0
        except Exception:
            return False

    def perform_self_update(self) -> bool:
        """
        Perform a self-update by running the appropriate upgrade command.

        Returns:
            True if update succeeded, False otherwise.
        """
        update_info = self.check_for_updates(force=True)
        if not update_info:
            logger.error("Could not check for updates.")
            return False

        if not update_info.get("update_available"):
            logger.info(f"Already on latest version: {self.current_version}")
            return True

        latest = update_info["latest"]
        upgrade_cmd = self._get_upgrade_command()
        logger.info(f"Updating novelscribe {self.current_version} → {latest}...")

        try:
            result = subprocess.run(
                shlex.split(upgrade_cmd),
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode != 0:
                stderr = result.stderr.strip()
                logger.error(f"Update failed: {stderr}")
                logger.info(f"Try manually: {upgrade_cmd}")
                return False

            post_version = self._verify_post_update_version(upgrade_cmd)
            if post_version and post_version != self.current_version:
                logger.info(f"Successfully updated to v{post_version}!")
                logger.info("Run 'scribe version info' to confirm.")
                return True

            if "pipx upgrade" in upgrade_cmd:
                logger.info(
                    "pipx upgrade did not change version — retrying with pipx install --force..."
                )
                fallback = "pipx install --force novelscribe"
                fb_result = subprocess.run(
                    shlex.split(fallback),
                    capture_output=True,
                    text=True,
                    timeout=120,
                )
                if fb_result.returncode == 0:
                    post_version = self._verify_via_pipx()
                    if post_version and post_version != self.current_version:
                        logger.info(f"Successfully updated to v{post_version}!")
                        logger.info("Run 'scribe version info' to confirm.")
                        return True

            still = post_version or self.current_version
            logger.error(f"Update verification failed: version is still v{still}.")
            logger.info("The upgrade command may have targeted the wrong environment.")
            logger.info(f"Try manually: {upgrade_cmd}")
            return False
        except subprocess.TimeoutExpired:
            logger.error("Update timed out after 120 seconds.")
            return False
        except Exception as e:
            logger.error(f"Update failed: {e}")
            return False

    def _verify_post_update_version(self, upgrade_cmd: str = "") -> Optional[str]:
        """Check version after update using the same installer that performed the upgrade."""
        if "pipx" in upgrade_cmd:
            return self._verify_via_pipx()
        if upgrade_cmd.startswith("uv "):
            return self._verify_via_uv()
        return self._verify_via_pip()

    def _verify_via_pipx(self) -> Optional[str]:
        """Check version via pipx list output."""
        try:
            result = subprocess.run(
                ["pipx", "list"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    if "novelscribe" in line:
                        for part in line.split():
                            if part.startswith(("novelscribe", "package")):
                                continue
                            for segment in part.split(","):
                                s = segment.strip()
                                if s and s[0].isdigit():
                                    return s
        except Exception:
            pass
        return None

    def _verify_via_uv(self) -> Optional[str]:
        """Check version via uv pip show."""
        try:
            result = subprocess.run(
                ["uv", "pip", "show", "novelscribe"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    if line.startswith("Version:"):
                        return line.split(":", 1)[1].strip()
        except Exception:
            pass
        return None

    def _verify_via_pip(self) -> Optional[str]:
        """Check version via pip show."""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", "novelscribe"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    if line.startswith("Version:"):
                        return line.split(":", 1)[1].strip()
        except Exception:
            pass
        return None

    def display_update_notification(self) -> None:
        """Display a brief update notification if available (for CLI startup)."""
        update_info = self.check_for_updates(verbose=False)
        if update_info and update_info.get("update_available"):
            print(
                f"\n  🔔 novelscribe {update_info['current']} → {update_info['latest']} available. "
                f"Run: {update_info['upgrade_command']}\n"
            )


def get_version() -> str:
    """Get the current version string."""
    manager = VersionManager()
    return manager.current_version


def check_updates() -> Optional[dict]:
    """Check for updates and return update info."""
    manager = VersionManager()
    return manager.check_for_updates()


def notify_if_update_available() -> None:
    """Notify user if an update is available (for CLI startup)."""
    manager = VersionManager()
    manager.display_update_notification()
