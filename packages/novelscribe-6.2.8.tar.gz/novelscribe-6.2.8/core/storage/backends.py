"""Storage backend implementations."""

from __future__ import annotations

import logging
import os
import shutil
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel

from .errors import FileNotFoundError, FileParseError, FileWriteError, StorageError

logger = logging.getLogger(__name__)


class StorageConfig(BaseModel):
    """Configuration for storage backend."""

    backend: str = "file"
    base_path: str = ".novels"
    cache_enabled: bool = True


class AgentDefinition(BaseModel):
    """Parsed agent definition from Markdown file."""

    name: str
    description: str
    model: str = "gpt-5.1"
    temperature: float = 0.7
    max_tokens: int = 4096
    system_prompt: str
    metadata: dict[str, Any] = {}


class WorkflowDefinition(BaseModel):
    """Parsed workflow definition from YAML file."""

    name: str
    description: str
    steps: list[dict[str, Any]]
    metadata: dict[str, Any] = {}


class StorageBackend(ABC):
    """Abstract base class for storage backends."""

    @abstractmethod
    def read_markdown(self, path: str) -> str:
        """Read markdown file content."""

    @abstractmethod
    def write_markdown(self, path: str, content: str) -> None:
        """Write markdown file content."""

    @abstractmethod
    def read_yaml(self, path: str) -> dict[str, Any]:
        """Read YAML file content."""

    @abstractmethod
    def write_yaml(self, path: str, data: dict[str, Any]) -> None:
        """Write YAML file content."""

    @abstractmethod
    def read_agent(self, path: str) -> AgentDefinition:
        """Read and parse agent definition from Markdown."""

    @abstractmethod
    def read_workflow(self, path: str) -> WorkflowDefinition:
        """Read and parse workflow definition from YAML."""

    @abstractmethod
    def exists(self, path: str) -> bool:
        """Check if file exists."""

    @abstractmethod
    def delete(self, path: str) -> None:
        """Delete file."""

    @abstractmethod
    def list_files(self, directory: str, pattern: str = "*") -> list[str]:
        """List files in directory matching pattern."""


class FileStorage(StorageBackend):
    """File-based storage implementation."""

    def __init__(self, config: StorageConfig):
        self.config = config
        self.base_path = Path(config.base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)

    def _resolve_path(self, path: str) -> Path:
        """Resolve path relative to base path."""
        if os.path.isabs(path):
            return Path(path)
        return self.base_path / path

    def read_markdown(self, path: str) -> str:
        """Read markdown file content."""
        file_path = self._resolve_path(path)
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                return f.read()
        except OSError as e:
            raise FileNotFoundError(f"Failed to read markdown file {path}: {e}") from e

    def write_markdown(self, path: str, content: str) -> None:
        """Write markdown file content atomically."""
        file_path = self._resolve_path(path)
        file_path.parent.mkdir(parents=True, exist_ok=True)

        temp_path = file_path.with_suffix(f"{file_path.suffix}.tmp")

        try:
            with open(temp_path, "w", encoding="utf-8") as f:
                f.write(content)

            shutil.move(temp_path, file_path)
        except OSError as e:
            raise FileWriteError(f"Failed to write markdown file {path}: {e}") from e

    def read_yaml(self, path: str) -> dict[str, Any]:
        """Read YAML file content."""
        file_path = self._resolve_path(path)
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            raise FileParseError(f"Failed to parse YAML file {path}: {e}") from e
        except OSError as e:
            raise FileNotFoundError(f"Failed to read YAML file {path}: {e}") from e

    def write_yaml(self, path: str, data: dict[str, Any]) -> None:
        """Write YAML file content atomically."""
        file_path = self._resolve_path(path)
        file_path.parent.mkdir(parents=True, exist_ok=True)

        temp_path = file_path.with_suffix(f"{file_path.suffix}.tmp")

        try:
            with open(temp_path, "w", encoding="utf-8") as f:
                yaml.safe_dump(data, f, default_flow_style=False, sort_keys=False)

            shutil.move(temp_path, file_path)
        except (OSError, yaml.YAMLError) as e:
            raise FileWriteError(f"Failed to write YAML file {path}: {e}") from e

    def read_agent(self, path: str) -> AgentDefinition:
        """Read and parse agent definition from Markdown with YAML frontmatter."""
        content = self.read_markdown(path)

        if not content.startswith("---"):
            raise FileParseError(f"Agent file {path} must start with YAML frontmatter")

        try:
            parts = content.split("---", 2)
            if len(parts) < 3:
                raise FileParseError(f"Invalid frontmatter format in {path}")

            frontmatter_yaml = parts[1]
            system_prompt = parts[2].strip()

            frontmatter = yaml.safe_load(frontmatter_yaml)

            required_fields = ["name", "description"]
            for field in required_fields:
                if field not in frontmatter:
                    raise FileParseError(f"Missing required field '{field}' in {path}")

            return AgentDefinition(
                name=frontmatter["name"],
                description=frontmatter["description"],
                model=frontmatter.get("model", "gpt-5.1"),
                temperature=frontmatter.get("temperature", 0.7),
                max_tokens=frontmatter.get("max_tokens", 4096),
                system_prompt=system_prompt,
                metadata={
                    k: v
                    for k, v in frontmatter.items()
                    if k not in required_fields + ["model", "temperature", "max_tokens"]
                },
            )
        except (yaml.YAMLError, ValueError) as e:
            raise FileParseError(f"Failed to parse agent definition from {path}: {e}") from e

    def read_workflow(self, path: str) -> WorkflowDefinition:
        """Read and parse workflow definition from YAML."""
        data = self.read_yaml(path)

        required_fields = ["name", "description", "steps"]
        for field in required_fields:
            if field not in data:
                raise FileParseError(f"Missing required field '{field}' in {path}")

        if not isinstance(data["steps"], list):
            raise FileParseError(f"'steps' must be a list in {path}")

        return WorkflowDefinition(
            name=data["name"],
            description=data["description"],
            steps=data["steps"],
            metadata={k: v for k, v in data.items() if k not in required_fields},
        )

    def exists(self, path: str) -> bool:
        """Check if file exists."""
        file_path = self._resolve_path(path)
        return file_path.exists()

    def delete(self, path: str) -> None:
        """Delete file."""
        file_path = self._resolve_path(path)
        try:
            if file_path.is_file():
                file_path.unlink()
            elif file_path.is_dir():
                shutil.rmtree(file_path)
        except OSError as e:
            raise StorageError(f"Failed to delete {path}: {e}") from e

    def list_files(self, directory: str, pattern: str = "*") -> list[str]:
        """List files in directory matching pattern."""
        dir_path = self._resolve_path(directory)
        if not dir_path.exists():
            return []

        try:
            return [
                str(f.relative_to(self.base_path)) for f in dir_path.glob(pattern) if f.is_file()
            ]
        except OSError as e:
            raise StorageError(f"Failed to list files in {directory}: {e}") from e
