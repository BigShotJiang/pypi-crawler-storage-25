"""Shared logic for OpenAI-compatible provider clients."""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator

from core.llm.client import LLMClient, LLMError, LLMResponse


class OpenAICompatibleClient(LLMClient):
    """Base client for providers using OpenAI-compatible chat APIs."""

    api_error_label: str = "Provider"
    config_error_message: str = "API key not configured"
    use_response_model_name: bool = True

    def _ensure_clients(self) -> None:
        return

    def _ensure_config(self) -> None:
        if not self.validate_config():
            raise LLMError(self.config_error_message)

    def _response_model_name(self, response: object) -> str:
        if self.use_response_model_name:
            model = getattr(response, "model", None)
            if isinstance(model, str) and model:
                return model
        return self.config.model

    def _to_response(self, response: object) -> LLMResponse:
        usage = getattr(response, "usage", None)
        choices = getattr(response, "choices", None) or []
        choice0 = choices[0]
        return LLMResponse(
            content=choice0.message.content,
            model=self._response_model_name(response),
            provider=self.provider_name,
            tokens_used=usage.total_tokens if usage else None,
            finish_reason=choice0.finish_reason,
        )

    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        self._ensure_config()
        self._ensure_clients()
        messages = self._format_messages(system_prompt, user_prompt)
        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )
            return self._to_response(response)
        except Exception as e:
            raise LLMError(f"{self.api_error_label} API error: {e}") from e

    async def generate_async(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        self._ensure_config()
        self._ensure_clients()
        messages = self._format_messages(system_prompt, user_prompt)
        try:
            response = await self.async_client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )
            return self._to_response(response)
        except Exception as e:
            raise LLMError(f"{self.api_error_label} API error: {e}") from e

    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        self._ensure_config()
        self._ensure_clients()
        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )
            return self._to_response(response)
        except Exception as e:
            raise LLMError(f"{self.api_error_label} API error: {e}") from e

    async def generate_with_history_async(self, messages: list[dict[str, str]]) -> LLMResponse:
        self._ensure_config()
        self._ensure_clients()
        try:
            response = await self.async_client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )
            return self._to_response(response)
        except Exception as e:
            raise LLMError(f"{self.api_error_label} API error: {e}") from e

    def generate_stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        self._ensure_config()
        self._ensure_clients()
        messages = self._format_messages(system_prompt, user_prompt)
        try:
            stream = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
                stream=True,
            )
            for chunk in stream:
                delta = chunk.choices[0].delta.content if chunk.choices else None
                if delta:
                    yield delta
        except Exception as e:
            raise LLMError(f"{self.api_error_label} streaming error: {e}") from e

    async def generate_stream_async(
        self, system_prompt: str, user_prompt: str
    ) -> AsyncIterator[str]:
        self._ensure_config()
        self._ensure_clients()
        messages = self._format_messages(system_prompt, user_prompt)
        try:
            stream = await self.async_client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
                stream=True,
            )
            async for chunk in stream:
                delta = chunk.choices[0].delta.content if chunk.choices else None
                if delta:
                    yield delta
        except Exception as e:
            raise LLMError(f"{self.api_error_label} streaming error: {e}") from e
