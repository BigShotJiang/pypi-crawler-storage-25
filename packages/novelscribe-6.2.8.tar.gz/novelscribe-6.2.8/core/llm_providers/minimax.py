"""MiniMax provider client (OpenAI-compatible).

MiniMax API is fully OpenAI-compatible, so this client reuses the openai SDK
with a custom base_url pointing to MiniMax's endpoint.

API docs: https://platform.minimaxi.com/
"""

from __future__ import annotations

import os

from core.llm.client import LLMConfig, LLMError
from core.llm_providers.openai_compatible import OpenAICompatibleClient


class MiniMaxClient(OpenAICompatibleClient):
    """MiniMax provider client (OpenAI-compatible)."""

    api_error_label = "MiniMax"
    config_error_message = "MiniMax API key not configured"

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            import openai

            self.openai = openai
            self.base_url = config.base_url or os.getenv(
                "MINIMAX_BASE_URL", "https://api.minimax.chat/v1"
            )
            api_key = config.api_key or os.getenv("MINIMAX_API_KEY", "")
            self.client = openai.OpenAI(
                base_url=self.base_url, api_key=api_key, timeout=config.timeout
            )
            self.async_client = openai.AsyncOpenAI(
                base_url=self.base_url, api_key=api_key, timeout=config.timeout
            )
        except ImportError:
            raise LLMError("OpenAI package not installed. Install with: pip install openai")

    def validate_config(self) -> bool:
        """Validate MiniMax configuration."""
        return bool(
            self.config.api_key
            or os.getenv("MINIMAX_API_KEY")
            or os.getenv("MINIMAX_BASE_URL", "").startswith("http://localhost")
        )
