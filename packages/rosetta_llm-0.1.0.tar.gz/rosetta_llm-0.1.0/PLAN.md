# Rosetta: Multi-Format Bidirectional Translation Service

## Context

A proxy that translates between OpenAI Chat Completions, OpenAI Responses, and Anthropic Messages. We want a clean, generic Python/FastAPI implementation that:

1. Exposes all three endpoint families (`/v1/chat/completions`, `/v1/responses`, `/v1/messages` + count_tokens + models) **with full streaming support on each**.
2. Routes requests to arbitrary providers via a `<provider>/<model>` prefix scheme (`abc/kimi-k2.5`).
3. Translates losslessly across formats — including thinking blocks, signed reasoning, encrypted reasoning carriers, and tool-call round-trips.
4. Is driven entirely by a single `config.json` (JSON; companion `config.example.jsonc` documents fields).
5. Ships as a Dockerfile.
6. Has minimal per-request overhead (passthrough when inbound format == provider native format; canonical IR only when translation is needed).

The end goal is a drop-in proxy that lets any client SDK (OpenAI, Anthropic, Codex, Claude Code, opencode, Cline, etc.) talk to any provider regardless of which native API the provider speaks.

---

References:
https://www.openresponses.org/reference
https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create
https://platform.claude.com/docs/en/api/messages/create

## Architecture

### Translation strategy: hybrid passthrough + canonical IR

- **Passthrough fast path**: when `inbound_format == provider.format`, serialize once, forward, stream back. Touch only the `model` field (strip prefix / apply `upstream_name`) and headers (auth swap). No IR allocation. ~zero overhead vs. plain reverse-proxy.
- **Translation slow path**: when formats differ, run inbound bytes → canonical IR → provider format. Reverse on response. Streaming uses per-format state machines that emit IR events; outbound state machine consumes IR events and emits target SSE.
- The canonical IR keeps a `_raw` sidecar dict on every block so format-specific fields (Anthropic `signature`, Responses `encrypted_content`, Chat `reasoning_content`, etc.) survive lossy rendering and can be reconstructed when round-tripping.

### Encrypted-reasoning carrier (lossless thinking round-trip)

Mirror source repo: when rendering Responses reasoning into Anthropic, encode `encrypted_content + "@" + id` into Anthropic's `signature`. When parsing Anthropic, split on the **last** `@` to extract id + encrypted_content. For compaction items, prefix with `cm1#`. Without this, multi-turn agentic workloads (Claude Code, Codex CLI) lose prompt-cache hits and reasoning continuity.

### Provider routing

Model id format: `<provider_key>/<model_name>`. Split on first `/`. `provider_key` looks up provider config; remainder is the user-facing model name. Per-model `upstream_name` (optional) overrides what we forward.

### Stack

- Python 3.13, FastAPI, uvicorn (uvloop + httptools), httpx (async), Pydantic v2, orjson, tiktoken, structlog.
- `uv` for deps. `python:3.13-slim` multi-stage Docker.
- No pydantic-ai dependency — its agent abstraction would obscure the wire-level fidelity we need.

---

## Project layout

```
/Users/lokesh/me/api/
├── pyproject.toml
├── uv.lock
├── README.md
├── Dockerfile
├── .dockerignore
├── config.example.jsonc          # documented sample
├── src/
│   └── rosetta/
│       ├── __init__.py
│       ├── __main__.py           # `python -m rosetta`
│       ├── app.py                # FastAPI app factory
│       ├── config.py             # Pydantic-validated config loader
│       ├── auth.py               # bearer-token middleware
│       ├── errors.py             # endpoint-format-aware error envelopes
│       ├── upstream.py           # httpx.AsyncClient pool per provider
│       ├── tokens.py             # tiktoken-based count_tokens
│       ├── observability.py      # structlog JSON setup, request_id ctxvar
│       ├── ir/
│       │   ├── __init__.py
│       │   ├── request.py        # CanonicalRequest, Message, ContentPart, Tool
│       │   ├── response.py       # CanonicalResponse, Usage, StopInfo
│       │   └── events.py         # CanonicalStreamEvent
│       ├── codecs/               # non-streaming parse/render per format
│       │   ├── anthropic.py
│       │   ├── openai_chat.py
│       │   └── openai_responses.py
│       ├── stream_codecs/        # streaming parse/render per format
│       │   ├── anthropic.py
│       │   ├── openai_chat.py
│       │   └── openai_responses.py
│       ├── pipeline.py           # passthrough vs translate dispatch
│       └── routes/
│           ├── messages.py       # POST /v1/messages, /v1/messages/count_tokens
│           ├── chat_completions.py # POST /v1/chat/completions
│           ├── responses.py      # POST /v1/responses
│           ├── models.py         # GET /v1/models
│           └── health.py         # GET /health, GET /providers
└── tests/
    ├── conftest.py
    ├── fixtures/                 # golden JSON captured from real providers
    │   ├── anthropic/
    │   ├── openai_chat/
    │   └── openai_responses/
    ├── codecs/
    │   ├── test_anthropic.py
    │   ├── test_openai_chat.py
    │   └── test_openai_responses.py
    ├── stream_codecs/
    │   ├── test_anthropic_stream.py
    │   ├── test_openai_chat_stream.py
    │   └── test_openai_responses_stream.py
    ├── test_round_trip.py        # IR round-trip identity checks
    ├── test_config.py
    └── test_tokens.py
```

---

## Decisions (captured from interview)

| Decision | Choice |
|---|---|
| Translator shape | Canonical IR with raw sidecars + passthrough fast path |
| pydantic-ai | Not used — pure httpx async |
| Format routing | Auto-translate transparently; provider's native format declared in config |
| Unknown params | Pass through unrecognized fields verbatim when not converting |
| Reasoning fidelity | Lossless round-trip via `<encrypted>@<id>` signature encoding |
| Effort/budget | Request-level (NOT model-level); flow with each turn |
| Tool-result ordering | Always validate + auto-repair |
| count_tokens | Local-only via tiktoken |
| Models list | If config has `*`, fetch upstream + TTL cache; else fixed list |
| Proxy auth | Optional bearer via `proxy.api_keys` in config |
| Config reload | Restart required (no hot reload) |
| Error format | Match inbound endpoint format |
| Config file | Strict `config.json` runtime + `config.example.jsonc` reference |
| Model name remap | Optional `upstream_name` per model |
| Stream pings | Synthesize every 15s during silence on Anthropic outbound |
| Embeddings | Out of scope for v1 |
| Multimodal | Best-effort + degrade to text placeholder |
| Capability declaration | Optional config; permissive default |
| Logging | Structured JSON, configurable level |
| Container | python:3.13-slim + uv multi-stage |
| Cancellation | Propagate immediately on client disconnect |
| Rate limiting | None |
| Tests | Unit tests on translation only, golden fixtures |
| Health | GET /health + GET /providers |
| Streaming | Required on all 3 endpoints |

---

## Config schema (`config.example.jsonc`)

```jsonc
{
  // Optional: bind address. Defaults to 0.0.0.0:7860
  "host": "0.0.0.0",
  "port": 7860,

  // Optional: bearer-token auth on the proxy itself.
  // If omitted or empty array, all incoming requests are accepted.
  "proxy": {
    "api_keys": ["sk-proxy-XXXX"]
  },

  // Logging: "debug" | "info" | "warning" | "error"
  "log_level": "info",

  // Provider definitions. Keys are the prefix used in model ids.
  "providers": {
    "abc": {
      // The native API format this provider speaks. One of:
      //   "openai_chat" | "openai_responses" | "anthropic"
      "format": "openai_chat",

      // Upstream base URL. The proxy appends the format's standard path.
      // For openai_chat: <base_url>/chat/completions
      // For openai_responses: <base_url>/responses
      // For anthropic: <base_url>/messages
      "base_url": "https://api.abc.com/v1",

      // API key. Choose ONE:
      "api_key": "sk-...",          // direct
      // "api_key_env": "ABC_API_KEY", // read from environment

      // Optional headers merged into every upstream request
      "extra_headers": {
        "X-Custom": "value"
      },

      // Connection timeouts (seconds). Defaults to 30 connect / 600 read.
      "timeout": { "connect": 30, "read": 600 },

      // Models. Either an explicit list OR ["*"] to auto-discover via upstream /v1/models.
      // Auto-discover caches results for `models_ttl_seconds` (default 300).
      "models": [
        {
          "id": "kimi-k2.5",                          // user-facing (called as "abc/kimi-k2.5")
          "upstream_name": "moonshotai/kimi-k2.5",    // optional remap; default = id
          // Optional capabilities. Permissive default if omitted.
          "supports": {
            "tools": true,
            "vision": false,
            "thinking": true,
            "structured_output": true
          },
          // Optional default reasoning when target uses budget instead of effort
          "thinking_budget_default": 12288
        }
      ],
      "models_ttl_seconds": 300
    },

    "anthropic": {
      "format": "anthropic",
      "base_url": "https://api.anthropic.com/v1",
      "api_key_env": "ANTHROPIC_API_KEY",
      "extra_headers": {
        "anthropic-version": "2023-06-01"
      },
      "models": ["*"]
    },

    "openai": {
      "format": "openai_responses",
      "base_url": "https://api.openai.com/v1",
      "api_key_env": "OPENAI_API_KEY",
      "models": [
        { "id": "gpt-5.4" },
        { "id": "gpt-5.5" }
      ]
    }
  }
}
```

Strict-JSON `config.json` is the same shape with `//` comments stripped.

---

## Translation matrix

| Inbound endpoint | Provider format | Path |
|---|---|---|
| `/v1/messages` | anthropic | passthrough |
| `/v1/messages` | openai_chat | translate via IR |
| `/v1/messages` | openai_responses | translate via IR |
| `/v1/chat/completions` | openai_chat | passthrough |
| `/v1/chat/completions` | anthropic | translate via IR |
| `/v1/chat/completions` | openai_responses | translate via IR |
| `/v1/responses` | openai_responses | passthrough |
| `/v1/responses` | anthropic | translate via IR |
| `/v1/responses` | openai_chat | translate via IR |

Each row supports both streaming and non-streaming. Streaming uses per-format state machines (parse upstream events → IR events → render outbound events).

### Critical translation rules

- **System prompt**: Anthropic top-level `system` (string or `[{type:'text',...}]`) ↔ OpenAI `system` role / Responses `instructions`. Concatenate multiple system blocks with `\n\n`.
- **Tool result ordering** (Anthropic): within a user message, all `tool_result` blocks must precede any `text` block. When translating Chat→Anthropic, group consecutive `role:tool` messages and merge with the next user message; ensure tool_results come first.
- **Tool definitions**: Anthropic `input_schema` ↔ OpenAI `parameters`. Inject `properties: {}` into empty `type: object` schemas (OpenAI rejects without).
- **Tool choice**: `auto` ↔ `auto`, `any` ↔ `required`, `tool{name}` ↔ `function{name}`, `none` ↔ `none`.
- **Stop reasons**: `end_turn`↔`stop`, `max_tokens`↔`length`, `tool_use`↔`tool_calls`, `stop_sequence`↔`stop`+`stop_sequence` field, `refusal`/`pause_turn`/`model_context_window_exceeded` preserved in raw sidecar.
- **Reasoning effort** (request-level, not model-level): IR carries `reasoning.effort` (string enum) and `reasoning.budget_tokens` (int). Render to whichever the target supports. Anthropic now accepts `output_config.effort` AND `thinking.budget_tokens`. When converting effort→budget without explicit value, use per-model `thinking_budget_default` from config or a sensible default per effort tier.
- **Reasoning content**: encode Responses `(encrypted_content, id)` as `f"{encrypted_content}@{id}"` in Anthropic `signature`. Decode by splitting on **last** `@`. Compaction items use `cm1#<encrypted>@<id>` prefix.
- **Multimodal degradation**: PDF→non-Anthropic targets becomes a text part `"[PDF document attached but not supported by target]"`. Image→target lacking vision becomes `"[Image attached but not supported by target]"`. Both controlled by capabilities declared (or assumed) on the model.
- **`max_tokens` synthesis**: when forwarding to Anthropic without `max_tokens`, synthesize from `max_output_tokens` (Responses) or model-default fallback (4096).
- **Streaming tool args**: buffer `input_json_delta` / `function_call_arguments.delta` per call_id. Don't parse to object until valid JSON. Detect runaway whitespace (>20 consecutive newlines/tabs) → abort with synthesized error event (mirrors source repo's Copilot bug workaround).

---

## Streaming details

- **Per-format event taxonomy** (parsed into IR events):
  - Anthropic: `message_start`, `content_block_start`, `content_block_delta` ({text|input_json|thinking|signature}_delta), `content_block_stop`, `message_delta`, `message_stop`, `ping`, `error`.
  - OpenAI Chat: chunk-with-`delta` envelope. Final chunk has `finish_reason` + `usage`. Optional `delta.reasoning_content` (DeepSeek/Groq variants).
  - OpenAI Responses: `response.created`, `response.output_item.added`, `response.output_text.delta`/`.done`, `response.reasoning_summary_text.delta`/`.done`, `response.function_call_arguments.delta`/`.done`, `response.output_item.done`, `response.completed`/`.incomplete`, `response.failed`, `error`.

- **Synthetic ping injector**: when outbound is Anthropic, an `asyncio.Task` checks the time-since-last-byte; if >15s, emit a `ping` event. Cancelled when stream closes.

- **Cancellation**: each request creates an `asyncio.CancelScope` (via `anyio`). FastAPI's `request.is_disconnected()` is polled; on disconnect, scope is cancelled, which closes the upstream `httpx.AsyncClient.stream` context, sending TCP FIN to the provider.

- **Backpressure**: streaming responses use `Starlette.StreamingResponse` with an async generator. Upstream is consumed via `async for chunk in response.aiter_raw()` and pushed downstream as fast as the client reads.

---

## Endpoints

| Method | Path | Purpose |
|---|---|---|
| POST | `/v1/messages` | Anthropic Messages |
| POST | `/v1/messages/count_tokens` | Local tiktoken approximation |
| POST | `/v1/chat/completions` | OpenAI Chat |
| POST | `/v1/responses` | OpenAI Responses |
| GET | `/v1/models` | Merged model list (with TTL cache for `*`) |
| GET | `/health` | Liveness 200 |
| GET | `/providers` | Configured providers + last-seen status |

The `/v1/models` response uses OpenAI shape: `{"object": "list", "data": [{"id": "abc/kimi-k2.5", "object": "model", "owned_by": "abc"}, ...]}`. For Anthropic-style clients, the same shape is acceptable (Claude Code reads `data[].id`).

---

## Implementation tasks (Linear-style)

Tasks are grouped into phases. Each phase depends on the previous. Within a phase, tasks can be done in any order unless noted.

### Phase 0 — Project foundation

**T0.1 — Scaffold project layout and dependencies**
- Initialize `pyproject.toml` with: fastapi, uvicorn[standard], httpx, pydantic, pydantic-settings, structlog, orjson, tiktoken, python-json-logger.
- Dev: pytest, pytest-asyncio, respx, ruff, mypy.
- Create the `src/rosetta/` package skeleton (empty modules with docstrings), `tests/` skeleton, `.dockerignore`.
- Run `uv sync`.
- **Acceptance**: `python -c "import rosetta"` succeeds; `uv run pytest` passes (zero tests).

**T0.2 — Config loader and validation**
- File: `src/rosetta/config.py`.
- Pydantic v2 models: `ProxyConfig`, `ProviderConfig` (with `format: Literal["openai_chat","openai_responses","anthropic"]`), `ModelConfig` (id, upstream_name?, supports?, thinking_budget_default?), `TimeoutConfig`, `Capabilities`.
- Resolve `api_key_env` → `os.environ[...]` at load time; error if missing.
- Validate model id format; build a route table `{"<provider_key>/<model_id>": (ProviderConfig, ModelConfig)}`.
- Auto-detect mode: if `models == ["*"]`, mark provider for lazy upstream discovery.
- **Acceptance**: load test fixtures `tests/fixtures/configs/*.json` and assert validation errors / route table contents.

**T0.3 — Structured logging + request context**
- File: `src/rosetta/observability.py`.
- structlog configured for JSON output; level from config.
- `request_id` and `provider_key` ContextVars; included in every log record.
- FastAPI middleware that generates `request_id` (UUID4) per request and stamps it onto a response header `X-Request-Id`.
- **Acceptance**: emitting a log inside a route handler produces a JSON line with `request_id`, `provider_key`, `model`, `path`.

**T0.4 — Upstream HTTP client pool**
- File: `src/rosetta/upstream.py`.
- `UpstreamClient` holds one `httpx.AsyncClient` per provider, with that provider's `base_url`, timeout, and headers (auth + extra). Created at app startup via `lifespan`. Closed on shutdown.
- Helper `request_json(provider, path, body)` and `stream(provider, path, body)` (yields raw bytes).
- Sets `Authorization: Bearer <key>` for OpenAI-style; `x-api-key` + `anthropic-version` for Anthropic.
- **Acceptance**: respx test simulates upstream 200/4xx/5xx and validates header injection + body forwarding.

### Phase 1 — Canonical IR

**T1.1 — Define IR models**
- Files: `src/rosetta/ir/{request,response,events}.py`.
- `CanonicalRequest`: model, messages, system, tools, tool_choice, max_output_tokens, sampling (temperature/top_p/top_k/seed), stop_sequences, reasoning ({effort, budget_tokens, summary, include_encrypted, redacted_visible}), stream, metadata, raw_extras (dict for unknown fields when same-format pass-through).
- `Message`: role, parts (list of `ContentPart` discriminated by `type`).
- `ContentPart` types: text, image (data uri or url), document (pdf), tool_call (call_id, name, arguments_json_text), tool_result (call_id, content_parts, is_error), reasoning (visibility, text, signature, encrypted_content, summary), refusal (text). Each has `_raw` sidecar for unrendered provider extras.
- `Tool`: name, description, input_schema, kind (function/hosted), strict, _raw.
- `CanonicalResponse`: id, model, output_messages, stop ({normalized, provider_raw, stop_sequence}), usage (input/output/cache_read/cache_creation/reasoning), _raw.
- `CanonicalStreamEvent` (discriminated union): message_start, part_start, part_delta (text/json/reasoning/signature), part_stop, message_delta (usage/stop), message_stop, ping, error.
- **Acceptance**: import + instantiate all models; `model_dump_json()` round-trips.

### Phase 2 — Non-streaming codecs

**T2.1 — Anthropic codec (parse + render)**
- File: `src/rosetta/codecs/anthropic.py`.
- `parse_request(payload: dict) -> CanonicalRequest` and `render_request(ir) -> dict`.
- `parse_response(payload) -> CanonicalResponse` and `render_response(ir) -> dict`.
- Implements: system block flattening, multi-block content arrays, tool_result-before-text validation/auto-repair on render, thinking signature decode (split last `@`), effort/budget round-trip, max_tokens synthesis on render.
- **Acceptance**: golden-fixture tests for 8 scenarios — text, multi-turn, tool_use loop, multi-image, thinking, redacted_thinking, refusal, max_tokens cutoff.

**T2.2 — OpenAI Chat codec**
- File: `src/rosetta/codecs/openai_chat.py`.
- Same parse/render contract.
- Implements: system role extraction, multimodal `image_url` parts, tool_calls↔IR.tool_call, role=tool messages↔IR.tool_result, `reasoning_content` (DeepSeek/Groq variant) → IR.reasoning, `stop` ↔ IR.stop_sequences, `frequency_penalty`/`presence_penalty` preserved in `_raw`.
- **Acceptance**: golden fixtures for 6 scenarios; cross-codec round-trip test (Anthropic→IR→Chat→IR→Anthropic) preserves tool_call ids.

**T2.3 — OpenAI Responses codec**
- File: `src/rosetta/codecs/openai_responses.py`.
- Most complex codec.
- Implements: typed `output[]` items (message, reasoning, function_call, function_call_output, compaction), `input` array of typed items, `instructions`, content-part discrimination (input_text/output_text/input_image/input_file/refusal), reasoning encrypted_content + summary + id, compaction items via `cm1#` carrier, `phase` markers (commentary/final_answer) — preserved in `_raw` and only emitted if config opts in.
- Implements `<encrypted>@<id>` round-trip with Anthropic.
- **Acceptance**: golden fixtures for 8 scenarios including reasoning round-trip, compaction round-trip, function_call sequencing.

**T2.4 — Cross-format round-trip suite**
- File: `tests/test_round_trip.py`.
- Property-style test: Anthropic→IR→Chat→IR→Anthropic must preserve {tool_use ids, system, tools, max_tokens, stop_sequences}.
- Tool result ordering invariant: any IR with tool_results renders to Anthropic with tool_results before text.
- Reasoning round-trip: Responses → IR → Anthropic → IR → Responses preserves encrypted_content + id exactly.
- **Acceptance**: 15+ round-trip cases pass.

### Phase 3 — Streaming codecs

**T3.1 — Anthropic stream codec**
- File: `src/rosetta/stream_codecs/anthropic.py`.
- `parse(byte_chunks) -> AsyncIterator[CanonicalStreamEvent]`: SSE parser → typed Anthropic events → IR events.
- `render(events) -> AsyncIterator[bytes]`: IR events → Anthropic SSE (proper `event:` + `data:` lines, double-newline separators).
- Maintains state: contentBlockIndex counter, blockHasDelta tracking, thinkingBlockOpen flag.
- Emits `message_start` once, opens/closes content blocks correctly, emits `message_delta` with stop_reason + usage before `message_stop`.
- **Acceptance**: replay captured Anthropic SSE → IR events → render → byte-equal up to whitespace.

**T3.2 — OpenAI Chat stream codec**
- File: `src/rosetta/stream_codecs/openai_chat.py`.
- Parse SSE chunks (`data: {...}\n\n`, terminator `data: [DONE]`) into IR events.
- Render IR events as chunks: first chunk has `delta.role`, subsequent chunks have `delta.content` or `delta.tool_calls[].function.arguments` (JSON fragments), terminal chunk has `finish_reason` + `usage`.
- Handle `delta.reasoning_content` for DeepSeek-style.
- **Acceptance**: replay captured Chat SSE; render IR events; byte-similar (modulo `id`/timestamps).

**T3.3 — OpenAI Responses stream codec**
- File: `src/rosetta/stream_codecs/openai_responses.py`.
- Parse semantic events (`response.created`, `.output_item.added`, `.output_text.delta`/`.done`, `.reasoning_summary_text.delta`/`.done`, `.function_call_arguments.delta`/`.done`, `.output_item.done`, `.completed`/`.incomplete`/`.failed`, `error`) into IR.
- Render IR events as the inverse.
- Implements per-output-index function-call buffer, whitespace runaway guard (abort if >20 consecutive newlines/tabs in tool args).
- **Acceptance**: replay captured Responses SSE; round-trip identity.

**T3.4 — Synthetic ping injector**
- File: `src/rosetta/stream_codecs/anthropic.py` (helper).
- `wrap_with_ping(events: AsyncIterator) -> AsyncIterator`: yields a `ping` IR event if 15s pass without an upstream event. Uses `asyncio.wait` with timeout.
- Only used when outbound format == anthropic.
- **Acceptance**: feed a slow generator; assert pings emitted at 15s intervals; assert no pings emitted when generator is fast.

**T3.5 — Cancellation propagation**
- File: `src/rosetta/pipeline.py`.
- `asyncio.shield`-free design: client disconnect cancels the task running the upstream `httpx.stream` context, which closes the connection.
- Use `request.is_disconnected()` polled in the streaming loop; on disconnect, raise `asyncio.CancelledError`.
- **Acceptance**: integration test with respx + a slow stream; client disconnects after 1s; assert upstream stream is closed.

### Phase 4 — Pipeline + endpoints

**T4.1 — Pipeline dispatcher**
- File: `src/rosetta/pipeline.py`.
- `async def handle(inbound_format, payload, request) -> Response | StreamingResponse`:
  1. Parse model id → resolve `(ProviderConfig, ModelConfig)`.
  2. Apply `upstream_name` remap.
  3. If `inbound_format == provider.format`: passthrough — forward payload (with model rewritten + auth swapped + extra_headers merged); stream upstream bytes downstream verbatim.
  4. Else: `parse_request` (inbound codec) → `render_request` (provider codec) → upstream call → `parse_response` (provider codec) → `render_response` (inbound codec) → return.
  5. For streams: same but using stream codecs with backpressure.
- Wraps every upstream call in a try/except that emits inbound-format error envelopes via `errors.py`.
- **Acceptance**: unit-tested with respx mocking each path.

**T4.2 — POST /v1/messages**
- File: `src/rosetta/routes/messages.py`.
- Parse JSON body (orjson). Detect `stream: bool`. Call `pipeline.handle("anthropic", body, request)`.
- **Acceptance**: respx test for both stream and non-stream; check `Content-Type` (`application/json` vs `text/event-stream`).

**T4.3 — POST /v1/chat/completions**
- File: `src/rosetta/routes/chat_completions.py`.
- Same shape. Inbound format `"openai_chat"`.
- **Acceptance**: same.

**T4.4 — POST /v1/responses**
- File: `src/rosetta/routes/responses.py`.
- Same shape. Inbound format `"openai_responses"`.
- **Acceptance**: same.

**T4.5 — POST /v1/messages/count_tokens**
- File: `src/rosetta/routes/messages.py` + `src/rosetta/tokens.py`.
- Use tiktoken `o200k_base` encoding. Walk the request: count system + each message + tool definitions. Approximation only.
- Returns `{"input_tokens": <int>}`.
- **Acceptance**: known-fixture inputs produce expected counts (within ±5% tolerance documented).

**T4.6 — GET /v1/models**
- File: `src/rosetta/routes/models.py`.
- For each provider:
  - Static models from config: emit immediately.
  - `["*"]`: query upstream (`/v1/models` for OpenAI-format; `/v1/models` for Anthropic) on first call; cache for `models_ttl_seconds`. On failure, emit nothing for that provider but don't fail the response.
- Output shape: OpenAI-compatible `{object: "list", data: [{id: "<provider>/<model>", object: "model", owned_by: "<provider>"}]}`.
- **Acceptance**: respx tests for static, `*`-with-success, `*`-with-failure cases.

**T4.7 — Bearer-token auth middleware**
- File: `src/rosetta/auth.py`.
- If `proxy.api_keys` present and non-empty, require `Authorization: Bearer <key>` matching one of them. Otherwise no-op.
- Compatible with `x-api-key` header (Anthropic clients send this) — accept either.
- **Acceptance**: 401 when no header; 200 when matching; bypass when not configured.

**T4.8 — Error envelope adapter**
- File: `src/rosetta/errors.py`.
- `format_error(inbound_format, status_code, type_, message)` returns dict in matching shape.
  - anthropic: `{"type": "error", "error": {"type": "<type>", "message": "<msg>"}}`.
  - openai_chat / openai_responses: `{"error": {"message": "<msg>", "type": "<type>", "code": null, "param": null}}`.
- For streams, errors after stream start emit a final inline error event (Anthropic `event: error`, OpenAI `data: {error: ...}`) then close.
- **Acceptance**: unit tests for each format and code path.

**T4.9 — GET /health, GET /providers**
- File: `src/rosetta/routes/health.py`.
- `/health`: returns 200 `{"status": "ok"}`.
- `/providers`: `{"providers": [{"key": "abc", "format": "openai_chat", "last_status": "ok"|"error"|"unknown", "last_check_ts": ...}]}`. Status updated per upstream call (passive — no active healthchecks).
- **Acceptance**: 200 from cold start; status reflects last call.

### Phase 5 — App wiring

**T5.1 — App factory + lifespan**
- File: `src/rosetta/app.py`.
- `create_app(config_path)` returns FastAPI app with all routes mounted, auth middleware, lifespan that initializes/closes the `UpstreamClient` pool.
- **Acceptance**: `TestClient(create_app("tests/fixtures/configs/min.json"))` boots and serves /health.

**T5.2 — Entrypoint**
- File: `src/rosetta/__main__.py`.
- Reads `ROSETTA_CONFIG` env var (default `./config.json`).
- Runs uvicorn with config-derived host/port.
- **Acceptance**: `python -m rosetta` boots with a sample config.

### Phase 6 — Docker

**T6.1 — Dockerfile (multi-stage)**
- Stage 1 (`python:3.13-slim` + uv): copy `pyproject.toml` + `uv.lock`, run `uv sync --frozen --no-dev`.
- Stage 2 (`python:3.13-slim`): copy `.venv` + `src/`. `EXPOSE 7860`. `CMD ["python", "-m", "rosetta"]`.
- Healthcheck: `HEALTHCHECK CMD curl -f http://localhost:7860/health || exit 1`.
- `.dockerignore` excludes tests, .venv, __pycache__, .git.
- **Acceptance**: `docker build .` produces image <100MB; `docker run -v ./config.json:/app/config.json image` boots and answers /health.

### Phase 7 — Docs and sample config

**T7.1 — README.md**
- Install (uv), config, run locally, run in Docker, supported endpoints, model id format, environment variables, troubleshooting (common 4xx from upstream).
- Examples: curl Anthropic + curl OpenAI hitting same model via different prefixes.

**T7.2 — config.example.jsonc**
- Heavily commented sample (matches schema in this plan). Include 3 example providers: an OpenAI-format provider, an Anthropic provider, an OpenAI Responses provider.

---

## Verification

End-to-end smoke test before declaring done:

1. **Build + boot**:
   ```
   uv sync
   cp config.example.jsonc config.json    # then strip comments
   python -m rosetta &
   curl localhost:7860/health   # expect {"status":"ok"}
   ```

2. **Same-format passthrough** (lowest-overhead path):
   ```
   curl localhost:7860/v1/messages \
     -H "Authorization: Bearer $PROXY_KEY" \
     -d '{"model":"anthropic/claude-opus-4-7","max_tokens":256,"messages":[{"role":"user","content":"hi"}]}'
   ```

3. **Cross-format translation**:
   ```
   # OpenAI client hitting Anthropic-backed model
   curl localhost:7860/v1/chat/completions \
     -d '{"model":"anthropic/claude-opus-4-7","messages":[{"role":"user","content":"hi"}],"stream":true}'
   ```
   Verify Chat-format SSE is emitted even though provider streamed Anthropic SSE.

4. **Reasoning round-trip**:
   - Send a Responses-format request with `reasoning.effort:"high"` to an Anthropic-backed model. Check response includes a thinking block with non-empty signature.
   - Send a follow-up Anthropic request including the prior assistant message (with thinking block). Confirm 200 (signature decoded correctly) and prompt-cache hit (`cache_read_input_tokens > 0`).

5. **Tool round-trip**:
   - Anthropic-format request with `tools` to an OpenAI Chat-backed model. Confirm `tool_use` blocks emitted with stable ids; submit `tool_result` follow-up; confirm successful continuation.

6. **Streaming cancellation**:
   - Start a long stream; kill curl mid-stream; confirm `httpx` upstream connection closed (visible in upstream provider logs or via mitmproxy locally).

7. **Tests**:
   ```
   uv run pytest -q
   uv run mypy src/
   uv run ruff check src/ tests/ --fix
   uv run ruff check src/ tests/ --select I --fix
   uv run ruff format src/ tests/
   ```
   All green.

8. **Docker**:
   ```
   docker build -t rosetta .
   docker run -p 7860:7860 -v $PWD/config.json:/app/config.json -e ANTHROPIC_API_KEY=... rosetta
   ```
   Repeat smoke tests against the container.
