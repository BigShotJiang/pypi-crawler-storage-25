from argparse import ArgumentParser, REMAINDER


def launch_command_parser():
    parser = ArgumentParser(
        usage="so-record <script.py> [<args>]",
        description="Launch a Python script with Sovara instrumentation.",
        allow_abbrev=False,
    )

    parser.add_argument(
        "--run-name",
        default=None,
        help="Name that will be used in the run list. If not set, Run X where X is the index of the current run will be used.",
    )

    parser.add_argument(
        "-m",
        "--module",
        action="store_true",
        help="Change each process to interpret the launch script as a Python module, executing with the same behavior as 'python -m'.",
    )

    parser.add_argument(
        "-u",
        "--unbuffered",
        action="store_true",
        help="Run with unbuffered stdout/stderr, like 'python -u'.",
    )

    parser.add_argument("--user-name", help="Override or create the local Sovara user full name.")
    parser.add_argument("--user-email", help="Override or create the local Sovara user email.")
    parser.add_argument(
        "--project-root",
        help="Project root to resolve or create for this run. Defaults to the script directory.",
    )
    parser.add_argument("--project-name", help="Override or create the Sovara project name.")
    parser.add_argument(
        "--project-description",
        help="Override or create the Sovara project description.",
    )

    parser.add_argument(
        "script_path",
        type=str,
        help="The full path to the script to be executed, followed by all the remaining arguments.",
    )

    parser.add_argument(
        "script_args", nargs=REMAINDER, help="Arguments of the script to be executed."
    )
    return parser


def launch_command(args):
    from sovara.runner.agent_runner import AgentRunner

    agent_runner = AgentRunner(
        script_path=args.script_path,
        script_args=args.script_args,
        is_module_execution=args.module,
        unbuffered=args.unbuffered,
        run_name=args.run_name,
        user_name=getattr(args, "user_name", None),
        user_email=getattr(args, "user_email", None),
        project_root=getattr(args, "project_root", None),
        project_name=getattr(args, "project_name", None),
        project_description=getattr(args, "project_description", None),
    )
    agent_runner.run()


def main():
    parser = launch_command_parser()
    args = parser.parse_args()
    launch_command(args)


if __name__ == "__main__":
    main()
