import atexit
import os
import sys
import json
import re
import shlex
import shutil
import uuid
import time
import tempfile
import subprocess
from argparse import ArgumentParser, REMAINDER
from pathlib import Path
from typing import Any
from sovara.common.constants import HOST, PORT, PRIORS_SERVER_URL, PRIORS_SERVER_TIMEOUT

RUN_WAIT_TIMEOUT = 30  # Max seconds to wait for run_id from agent_runner
SOVARA_SERVER_URL = f"http://{HOST}:{PORT}"
_INHERITED_RUN_ENV_KEYS = (
    "SOVARA_ACTIVE_RUN",
    "SOVARA_RUN_ID",
    "SOVARA_REUSE_RUN_ID",
)


def output_json(data: Any) -> None:
    """Print JSON to stdout and exit with appropriate code."""
    print(json.dumps(data, indent=2))
    if isinstance(data, dict) and data.get("status") == "error":
        sys.exit(1)
    sys.exit(0)


def format_timestamp(ts) -> str | None:
    """Format a timestamp to ISO 8601 without microseconds."""
    if ts is None:
        return None
    from datetime import datetime

    if isinstance(ts, str):
        try:
            ts = datetime.fromisoformat(ts)
        except ValueError:
            return ts
    return ts.strftime("%Y-%m-%d %H:%M:%S")


# ===========================================================
# Shared helpers for reusable logic
# ===========================================================


def _resolve_value(value: str) -> str:
    """Resolve a value argument: if it's a path to an existing file, read the file contents."""
    if os.path.isfile(value):
        with open(value, "r") as f:
            return f.read()
    return value


def _load_json_file(path: str) -> Any:
    """Load a JSON file from disk."""
    with open(path, "r") as f:
        return json.load(f)


def _build_restructure_execute_body(args) -> dict:
    """Build the execute request body from CLI arguments."""
    body = {}

    if args.proposal_file:
        proposal = _load_json_file(args.proposal_file)
        if not isinstance(proposal, dict):
            raise ValueError("--proposal-file must contain a JSON object")
        for key in ("task_id", "moves", "new_folders", "base_path", "snapshot"):
            if key in proposal:
                body[key] = proposal[key]

    if args.task_id:
        body["task_id"] = args.task_id

    if args.moves_file:
        moves = _load_json_file(args.moves_file)
        if not isinstance(moves, list):
            raise ValueError("--moves-file must contain a JSON array")
        body["moves"] = moves

    if args.base_path is not None:
        body["base_path"] = args.base_path

    if args.snapshot is not None:
        body["snapshot"] = args.snapshot

    if args.new_folder:
        body["new_folders"] = args.new_folder

    if not body:
        raise ValueError("Provide --task-id, --proposal-file, or a standalone execute body")

    return body


def _ensure_server_running() -> None:
    """Start the local FastAPI server on demand for CLI reads/writes."""
    from sovara.cli.so_server import _is_server_running, launch_daemon_server

    if _is_server_running():
        return

    launch_daemon_server()
    deadline = time.time() + 10.0
    while time.time() < deadline:
        if _is_server_running():
            return
        time.sleep(0.1)

    output_json(
        {
            "status": "error",
            "error": "Sovara server did not become ready. Run `so-server start` and retry.",
        }
    )


def _extract_http_error(resp) -> str:
    try:
        data = resp.json()
    except ValueError:
        text = resp.text.strip()
        return text or "Server error"

    if isinstance(data, dict):
        detail = data.get("detail")
        if isinstance(detail, str) and detail.strip():
            return detail
        error = data.get("error")
        if isinstance(error, str) and error.strip():
            return error

    return "Server error"


def _server_request(
    method: str,
    path: str,
    *,
    params: dict | None = None,
    data: dict | None = None,
    timeout: float = 30.0,
) -> dict:
    """Make a JSON request to the local Sovara server."""
    import httpx

    _ensure_server_running()

    try:
        with httpx.Client(timeout=timeout) as client:
            response = client.request(
                method,
                f"{SOVARA_SERVER_URL}{path}",
                params=params,
                json=data,
            )
    except httpx.RequestError as exc:
        return {"status": "error", "error": f"Connection failed: {exc}"}

    if not response.is_success:
        return {
            "status": "error",
            "error": _extract_http_error(response),
            "code": response.status_code,
        }

    try:
        return response.json()
    except ValueError as exc:
        return {"status": "error", "error": f"Invalid JSON response: {exc}"}


def _resolve_project_id_prefix(project_id_or_prefix: str) -> tuple[str | None, dict[str, Any] | None]:
    """Resolve an unambiguous project-id prefix to a full project ID."""
    from sovara.common.user import read_user_id
    from sovara.server.database import DB

    prefix = str(project_id_or_prefix or "").strip()
    if not prefix:
        return None, {"status": "error", "error": "Project ID is required."}

    user_id = read_user_id()
    if not user_id:
        return None, {
            "status": "error",
            "error": (
                "No local Sovara user configured. "
                "Run `uv run so-cli init --user-name <full-name> --user-email <email>` first."
            ),
        }

    projects = DB.get_all_projects()
    exact = [project for project in projects if str(project.get("project_id") or "") == prefix]
    if exact:
        return str(exact[0]["project_id"]), None

    prefix_lower = prefix.lower()
    matches = [
        project
        for project in projects
        if str(project.get("project_id") or "").lower().startswith(prefix_lower)
    ]
    if len(matches) == 1:
        return str(matches[0]["project_id"]), None
    if not matches:
        return None, {
            "status": "error",
            "error": f"No project found for project-id prefix '{prefix}'.",
            "hint": "Run `uv run so-cli projects` to list available project IDs.",
        }

    preview = [
        {
            "project_id": str(project.get("project_id") or ""),
            "name": str(project.get("name") or ""),
        }
        for project in matches[:10]
    ]
    return None, {
        "status": "error",
        "error": f"Project-id prefix '{prefix}' is ambiguous.",
        "matches": preview,
        "hint": "Use a longer prefix or the full project ID.",
    }


def _resolve_local_priors_scope_headers(
    project_id: str | None = None,
    user_id: str | None = None,
) -> tuple[dict[str, str], dict[str, Any] | None]:
    """Resolve the local user/project scope for priors CLI commands.

    Priors commands should bind to the caller's workspace, not the long-lived
    server process's cwd. Return either scope headers or an error payload that
    the caller can surface directly.
    """
    from sovara.common.project import find_project_root, read_project_id, suggest_project_name_for_root
    from sovara.common.user import read_user_id
    from sovara.server.database import DB

    workspace_root = os.path.abspath(
        os.environ.get("SOVARA_WORKSPACE_ROOT") or os.environ.get("SOVARA_PROJECT_ROOT") or os.getcwd()
    )
    explicit_user_id = str(user_id or "").strip() or None
    if explicit_user_id is not None:
        resolved_project_id = str(project_id or "").strip()
        if not resolved_project_id:
            return {}, {
                "status": "error",
                "error": "Explicit priors scope requires both --user-id and --project-id.",
            }
        return {
            "x-sovara-user-id": explicit_user_id,
            "x-sovara-project-id": resolved_project_id,
        }, None

    user_id = read_user_id()
    if not user_id:
        return {}, {
            "status": "error",
            "error": (
                "No local Sovara user configured for priors commands. "
                "Run `uv run so-cli init --user-name <full-name> --user-email <email>`."
            ),
        }

    if project_id is not None:
        resolved_project_id, project_error = _resolve_project_id_prefix(project_id)
        if project_error is not None:
            return {}, project_error
        return {
            "x-sovara-user-id": user_id,
            "x-sovara-project-id": str(resolved_project_id),
        }, None

    project_root = find_project_root(workspace_root)
    if project_root:
        resolved_project_id = read_project_id(project_root)
        return {
            "x-sovara-user-id": user_id,
            "x-sovara-project-id": resolved_project_id,
        }, None

    result = DB.find_project_for_location(user_id, workspace_root)
    if result is not None:
        resolved_project_id, _project_location = result
        return {
            "x-sovara-user-id": user_id,
            "x-sovara-project-id": resolved_project_id,
        }, None

    suggested_root = workspace_root if os.path.isdir(workspace_root) else os.path.dirname(workspace_root)
    suggested_name = suggest_project_name_for_root(suggested_root)
    return {}, {
        "status": "error",
        "error": (
            f"No local Sovara project configured for priors commands at '{workspace_root}'. "
            "Priors CLI commands resolve scope from the current workspace, not the server process."
        ),
        "next_command": _format_init_command(
            project_root=suggested_root,
            project_name=suggested_name,
        ),
    }


def _fetch_all_runs(project_id: str | None = None) -> list[dict]:
    """Fetch the full run list via paginated UI endpoints."""
    if project_id is not None:
        limit = 100
        first_page = _server_request(
            "GET",
            f"/ui/projects/{project_id}/runs",
            params={"limit": limit, "offset": 0},
        )
        if first_page.get("status") == "error":
            output_json(first_page)

        running = list(first_page.get("running", []))
        finished = list(first_page.get("finished", []))
        total_finished = int(first_page.get("finished_total", len(finished)) or 0)
        offset = len(finished)

        while offset < total_finished:
            page = _server_request(
                "GET",
                f"/ui/projects/{project_id}/runs",
                params={"limit": limit, "offset": offset},
            )
            if page.get("status") == "error":
                output_json(page)
            next_finished = list(page.get("finished", []))
            if not next_finished:
                break
            finished.extend(next_finished)
            offset += len(next_finished)

        return running + finished

    first_page = _server_request("GET", "/ui/runs")
    if first_page.get("status") == "error":
        output_json(first_page)

    runs = list(first_page.get("runs", []))
    finished_offset = sum(1 for run in runs if run.get("status") != "running")
    has_more = first_page.get("has_more", False)

    while has_more:
        page = _server_request("GET", "/ui/runs/more", params={"offset": finished_offset})
        if page.get("status") == "error":
            output_json(page)
        next_runs = page.get("runs", [])
        runs.extend(next_runs)
        finished_offset += len(next_runs)
        has_more = page.get("has_more", False)

    return runs


def _can_prompt() -> bool:
    stdin_isatty = getattr(sys.stdin, "isatty", None)
    stdout_isatty = getattr(sys.stdout, "isatty", None)
    return bool(
        callable(stdin_isatty) and stdin_isatty() and callable(stdout_isatty) and stdout_isatty()
    )


def _record_process_stdin():
    return None if _can_prompt() else subprocess.DEVNULL


def _clear_inherited_run_markers(env: dict[str, str]) -> dict[str, str]:
    for key in _INHERITED_RUN_ENV_KEYS:
        env.pop(key, None)
    return env


def _format_init_command(
    *,
    user_name: str | None = None,
    user_email: str | None = None,
    project_root: str | None = None,
    project_name: str | None = None,
    project_description: str | None = None,
) -> str:
    parts = ["so-cli", "init"]

    def _append(flag: str, value: str | None) -> None:
        if value is None:
            return
        parts.extend([flag, value])

    _append("--user-name", user_name)
    _append("--user-email", user_email)
    _append("--project-root", project_root)
    _append("--project-name", project_name)
    _append("--project-description", project_description)
    return " ".join(shlex.quote(part) for part in parts)


def _status_target_path(path: str | None) -> str:
    return os.path.abspath(path or os.getcwd())


def _inspect_local_status(path: str | None) -> dict[str, Any]:
    from sovara.common.project import (
        find_project_root,
        read_project_id,
        suggest_project_name_for_root,
    )
    from sovara.common.user import read_user_id
    from sovara.server.database import DB

    target_path = _status_target_path(path)
    location = target_path if os.path.isdir(target_path) else os.path.dirname(target_path)

    user_id = read_user_id()
    user_row = DB.get_user(user_id) if user_id else None
    if user_row:
        user_status = {
            "status": "configured",
            "user_id": user_row["user_id"],
            "full_name": user_row["full_name"],
            "email": user_row["email"],
        }
    else:
        user_status = {"status": "missing"}

    project_status: dict[str, Any] = {
        "status": "missing",
        "checked_path": location,
    }

    if os.path.isdir(location):
        project_root = find_project_root(location)
        if project_root:
            project_id = read_project_id(project_root)
            project_row = DB.get_project(project_id)
            project_status = {
                "status": "existing",
                "checked_path": location,
                "project_root": project_root,
                "project_id": project_id,
                "name": (
                    project_row["name"]
                    if project_row
                    else suggest_project_name_for_root(project_root, exclude_project_id=project_id)
                ),
                "description": project_row["description"] if project_row else "",
                "db_record_present": bool(project_row),
            }
        elif user_row:
            restored = DB.find_project_for_location(user_row["user_id"], location)
            if restored:
                project_id, project_root = restored
                project_row = DB.get_project(project_id)
                project_status = {
                    "status": "restorable",
                    "checked_path": location,
                    "project_root": project_root,
                    "project_id": project_id,
                    "name": (
                        project_row["name"]
                        if project_row
                        else suggest_project_name_for_root(
                            project_root, exclude_project_id=project_id
                        )
                    ),
                    "description": project_row["description"] if project_row else "",
                }
            else:
                project_status["suggested_name"] = suggest_project_name_for_root(location)
        else:
            project_status["suggested_name"] = suggest_project_name_for_root(location)

    user_ready = user_status["status"] == "configured"
    project_ready = project_status["status"] in {"existing", "restorable"}

    return {
        "status": "ok",
        "path": target_path,
        "user": user_status,
        "project": project_status,
        "ready": {
            "user": user_ready,
            "project": project_ready,
            "record": user_ready and project_ready,
        },
    }


def format_log_output(
    log_text: str,
    *,
    tail: int | None = None,
    grep: str | None = None,
    context: int = 0,
    line_numbers: bool = False,
) -> str:
    """Render persisted run logs with optional filtering and line-number formatting."""
    if tail is not None and tail < 0:
        raise ValueError("--tail must be greater than or equal to 0")
    if context < 0:
        raise ValueError("--context must be greater than or equal to 0")

    if grep is None and tail is None and context == 0 and not line_numbers:
        return log_text

    lines = log_text.splitlines()
    entries: list[tuple[int, str] | None]

    if grep:
        try:
            pattern = re.compile(grep)
        except re.error as exc:
            raise ValueError(f"Invalid regex: {exc}") from exc

        ranges: list[tuple[int, int]] = []
        for index, line in enumerate(lines):
            if not pattern.search(line):
                continue

            start = max(0, index - context)
            end = min(len(lines) - 1, index + context)
            if ranges and start <= ranges[-1][1] + 1:
                ranges[-1] = (ranges[-1][0], max(ranges[-1][1], end))
            else:
                ranges.append((start, end))

        entries = []
        for range_index, (start, end) in enumerate(ranges):
            if range_index > 0:
                entries.append(None)
            for line_index in range(start, end + 1):
                entries.append((line_index + 1, lines[line_index]))
    else:
        entries = [(index + 1, line) for index, line in enumerate(lines)]

    if tail is not None:
        entries = entries[-tail:] if tail > 0 else []

    if not entries:
        return ""

    numbered_lines = [entry for entry in entries if entry is not None]
    number_width = len(str(max((line_number for line_number, _line in numbered_lines), default=1)))

    rendered_lines: list[str] = []
    for entry in entries:
        if entry is None:
            rendered_lines.append("--")
            continue

        line_number, line = entry
        if line_numbers:
            rendered_lines.append(f"{line_number:>{number_width}}: {line}")
        else:
            rendered_lines.append(line)

    return "\n".join(rendered_lines) + "\n"


def _spawn_rerun(prepared: dict, timeout: float | None = None) -> dict:
    """
    Spawn a rerun process for a run and block until completion.

    Consistent with record_command: stdout/stderr pass through to terminal.
    Returns result dict with status, run_id, exit_code, etc.
    """
    run_id = prepared["run_id"]
    cwd = prepared["cwd"]
    command = prepared["command"]
    environment = prepared["environment"]

    if not command:
        return {"status": "error", "error": f"Run not found or no command stored: {run_id}"}

    # Create temp file for run_id IPC
    run_file = os.path.join(tempfile.gettempdir(), f"sovara-run-{run_id}.json")

    def cleanup_run_file():
        try:
            if os.path.exists(run_file):
                os.unlink(run_file)
        except OSError:
            pass

    atexit.register(cleanup_run_file)

    # Set up environment: restore original env + set rerun run ID
    env = os.environ.copy()
    env.update(environment)
    _clear_inherited_run_markers(env)
    env["SOVARA_RUN_ID"] = run_id  # Tell agent_runner to reuse this run
    env["SOVARA_REUSE_RUN_ID"] = "1"
    env["SOVARA_RUN_FILE"] = run_file

    # Parse and execute the original command
    cmd_parts = shlex.split(command)

    process = subprocess.Popen(
        cmd_parts,
        cwd=cwd,
        env=env,
        stdin=subprocess.DEVNULL,
    )

    # Wait for run_id from agent_runner (confirms handshake)
    run_data = wait_for_run_file(run_file, RUN_WAIT_TIMEOUT, process=process)

    # Clean up temp file
    cleanup_run_file()
    atexit.unregister(cleanup_run_file)

    if not run_data:
        return {
            "status": "error",
            "error": "Timeout waiting for run handshake",
            "pid": process.pid,
        }
    if run_data["run_id"] != run_id:
        return {
            "status": "error",
            "error": f"Run handshake mismatch: expected {run_id}, got {run_data['run_id']}",
            "pid": process.pid,
        }

    # Block until completion
    start_time = time.time()
    try:
        exit_code = process.wait(timeout=timeout)
        duration = time.time() - start_time
        return {
            "status": "completed" if exit_code == 0 else "failed",
            "run_id": run_id,
            "exit_code": exit_code,
            "duration_seconds": round(duration, 2),
        }
    except subprocess.TimeoutExpired:
        process.terminate()
        return {
            "status": "timeout",
            "run_id": run_id,
            "pid": process.pid,
        }


def wait_for_run_file(
    run_file: str,
    timeout: float | None,
    process: subprocess.Popen | None = None,
) -> dict | None:
    """Poll for the run file written by agent_runner.

    Returns the parsed JSON data if successful, None on timeout.
    """
    start = time.time()
    while timeout is None or time.time() - start < timeout:
        if os.path.exists(run_file):
            try:
                with open(run_file, "r") as f:
                    data = json.load(f)
                    if "run_id" in data:
                        return data
            except (json.JSONDecodeError, IOError):
                pass  # File not fully written yet
        if process is not None and process.poll() is not None:
            return None
        time.sleep(0.1)
    return None


def record_command(args) -> None:
    """Run so-record and block until completion, return result via JSON."""

    if not args.module and not os.path.isfile(args.script_path):
        output_json({"status": "error", "error": f"Script not found: {args.script_path}"})

    run_id = str(uuid.uuid4())[:8]
    run_file = os.path.join(tempfile.gettempdir(), f"sovara-run-{run_id}.json")

    def cleanup_run_file():
        try:
            if os.path.exists(run_file):
                os.unlink(run_file)
        except OSError:
            pass

    atexit.register(cleanup_run_file)

    cmd = [sys.executable]
    if args.unbuffered:
        cmd.append("-u")
    cmd.extend(["-m", "sovara.cli.so_record"])
    if args.run_name:
        cmd.extend(["--run-name", args.run_name])
    if getattr(args, "user_name", None):
        cmd.extend(["--user-name", args.user_name])
    if getattr(args, "user_email", None):
        cmd.extend(["--user-email", args.user_email])
    if getattr(args, "project_root", None):
        cmd.extend(["--project-root", args.project_root])
    if getattr(args, "project_name", None):
        cmd.extend(["--project-name", args.project_name])
    if getattr(args, "project_description", None):
        cmd.extend(["--project-description", args.project_description])
    if args.module:
        cmd.append("-m")
    if args.unbuffered:
        cmd.append("-u")
    cmd.append(args.script_path)
    cmd.extend(args.script_args)

    env = _clear_inherited_run_markers(os.environ.copy())
    env["SOVARA_RUN_FILE"] = run_file

    process = subprocess.Popen(
        cmd,
        env=env,
        stdin=_record_process_stdin(),
    )

    run_data = wait_for_run_file(
        run_file,
        None if _can_prompt() else RUN_WAIT_TIMEOUT,
        process=process,
    )

    # Clean up temp file now that we've read it
    cleanup_run_file()
    atexit.unregister(cleanup_run_file)

    if not run_data:
        output_json(
            {
                "status": "error",
                "error": "Timeout waiting for run_id from agent runner",
                "pid": process.pid,
            }
        )

    run_id = run_data["run_id"]

    start_time = time.time()
    try:
        exit_code = process.wait(timeout=args.timeout)
        duration = time.time() - start_time
        output_json(
            {
                "status": "completed" if exit_code == 0 else "failed",
                "run_id": run_id,
                "exit_code": exit_code,
                "duration_seconds": round(duration, 2),
            }
        )
    except subprocess.TimeoutExpired:
        process.terminate()
        output_json(
            {
                "status": "timeout",
                "run_id": run_id,
                "pid": process.pid,
            }
        )


def status_command(args) -> None:
    """Inspect local Sovara setup state for the current path or an explicit target."""
    output_json(_inspect_local_status(args.path))


def init_command(args) -> None:
    """Create or update the local Sovara user and optionally a project."""
    from sovara.common.config import _ask_field
    from sovara.common.project import normalize_project_name, suggest_project_name_for_root

    can_prompt = _can_prompt()
    result: dict[str, Any] = {"status": "ok"}

    user_response = _server_request("GET", "/ui/user")
    if user_response.get("status") == "error":
        output_json(user_response)
    existing_user = user_response.get("user")

    full_name = (
        args.user_name
        if args.user_name is not None
        else (existing_user["full_name"] if existing_user else None)
    )
    email = (
        args.user_email
        if args.user_email is not None
        else (existing_user["email"] if existing_user else None)
    )

    if full_name is None and can_prompt:
        full_name = _ask_field("Full name\n> ", str)
    if email is None and can_prompt:
        email = _ask_field("Email\n> ", str)

    if full_name is None or email is None:
        missing_parts = []
        if full_name is None:
            missing_parts.append("--user-name")
        if email is None:
            missing_parts.append("--user-email")
        output_json(
            {
                "status": "error",
                "error": f"Missing required user fields: {', '.join(missing_parts)}",
                "next_command": _format_init_command(
                    user_name=args.user_name or "<full-name>",
                    user_email=args.user_email or "<email>",
                    project_root=args.project_root,
                    project_name=args.project_name,
                    project_description=args.project_description,
                ),
            }
        )

    if existing_user is None or args.user_name is not None or args.user_email is not None:
        user_create_response = _server_request(
            "POST",
            "/ui/setup-user",
            data={"full_name": full_name, "email": email},
        )
        if user_create_response.get("status") == "error":
            output_json(user_create_response)
        user_status = "created" if existing_user is None else "updated"
        user_payload = user_create_response["user"]
    else:
        user_status = "existing"
        user_payload = existing_user

    result["user"] = {"status": user_status, **user_payload}

    if not args.project_root and (
        args.project_name is not None or args.project_description is not None
    ):
        output_json(
            {
                "status": "error",
                "error": "--project-root is required when setting project metadata.",
                "next_command": _format_init_command(
                    user_name=full_name,
                    user_email=email,
                    project_root=os.getcwd(),
                    project_name=args.project_name or "<project-name>",
                    project_description=args.project_description,
                ),
            }
        )

    if not args.project_root:
        result["project"] = {"status": "skipped"}
        output_json(result)

    project_root = os.path.abspath(args.project_root)
    resolve_response = _server_request(
        "POST",
        "/ui/projects/resolve-location",
        data={"location": project_root},
    )
    if resolve_response.get("status") == "error":
        output_json(resolve_response)

    if resolve_response.get("status") != "missing":
        existing_project = resolve_response["project"]
        if args.project_name is not None or args.project_description is not None:
            updated_name = (
                normalize_project_name(args.project_name)
                if args.project_name is not None
                else existing_project["name"]
            )
            updated_description = (
                args.project_description.strip()
                if args.project_description is not None
                else existing_project.get("description", "")
            )
            update_response = _server_request(
                "POST",
                "/ui/update-project",
                data={
                    "project_id": existing_project["project_id"],
                    "name": updated_name,
                    "description": updated_description,
                },
            )
            if update_response.get("status") == "error":
                output_json(update_response)
            result["project"] = {
                "status": "updated",
                "project_root": resolve_response["project_root"],
                **update_response["project"],
            }
        else:
            result["project"] = {
                "status": "existing",
                "project_root": resolve_response["project_root"],
                **existing_project,
            }
        output_json(result)

    suggested_name = resolve_response.get("suggested_name") or suggest_project_name_for_root(
        project_root
    )
    if args.project_name is not None:
        project_name = normalize_project_name(args.project_name)
    elif can_prompt:
        print(f"Project name (default: {suggested_name})")
        project_name = _ask_field(
            "> ",
            normalize_project_name,
            default=suggested_name,
            error_message="Project name is required.",
        )
    else:
        output_json(
            {
                "status": "error",
                "error": "Missing required project field: --project-name",
                "next_command": _format_init_command(
                    project_root=project_root,
                    project_name=suggested_name,
                    project_description=args.project_description,
                ),
            }
        )

    project_description = (args.project_description or "").strip()
    create_response = _server_request(
        "POST",
        "/ui/create-project",
        data={
            "location": project_root,
            "name": project_name,
            "description": project_description,
        },
    )
    if create_response.get("status") == "error":
        output_json(create_response)

    result["project"] = {
        "status": "created",
        "project_root": project_root,
        "project_id": create_response["project_id"],
        "name": create_response["name"],
        "description": project_description,
    }
    output_json(result)


def probe_command(args) -> None:
    """Query the state of a run via the REST API."""
    params = {}
    if args.node:
        params["node"] = args.node
    if args.nodes:
        params["nodes"] = args.nodes
    if args.preview:
        params["preview"] = True
    if args.show_input:
        params["input"] = True
    if args.show_output:
        params["output"] = True
    if args.key_regex:
        params["key_regex"] = args.key_regex

    result = _server_request("GET", f"/ui/run/{args.run_id}/probe", params=params)
    output_json(result)


def logs_command(args) -> None:
    """Show the persisted log for a run."""
    result = _server_request("GET", f"/ui/run/{args.run_id}/log")
    if result.get("status") == "error":
        output_json(result)

    try:
        rendered = format_log_output(
            result.get("log", ""),
            tail=args.tail,
            grep=args.grep,
            context=args.context,
            line_numbers=args.line_numbers,
        )
    except ValueError as exc:
        output_json({"status": "error", "error": str(exc)})

    sys.stdout.write(rendered)
    sys.stdout.flush()


def runs_command(args) -> None:
    """List runs via the REST API."""
    import re

    resolved_project_id = None
    if getattr(args, "project_id", None):
        resolved_project_id, project_error = _resolve_project_id_prefix(args.project_id)
        if project_error is not None:
            output_json(project_error)

    # Parse range (format: "start:end", ":end", "start:", or "start")
    range_str = args.range or ":50"

    if ":" in range_str:
        parts = range_str.split(":", 1)
        start = int(parts[0]) if parts[0] else 0
        end = int(parts[1]) if parts[1] else None
    else:
        start = int(range_str)
        end = start + 1  # Single item

    all_runs = _fetch_all_runs(project_id=resolved_project_id)
    total_count = len(all_runs)

    if args.status != "all":
        all_runs = [run for run in all_runs if run.get("status") == args.status]

    # Apply range first
    if end is not None:
        runs = all_runs[start:end]
    else:
        runs = all_runs[start:]

    # Apply regex filter on top of the range
    if args.regex:
        try:
            pattern = re.compile(args.regex)
        except re.error as e:
            output_json({"status": "error", "error": f"Invalid regex: {e}"})
        runs = [exp for exp in runs if pattern.search(exp["name"] or "")]

    # Format output
    result = []
    for exp in runs:
        result.append(
            {
                "run_id": exp["run_id"],
                "name": exp["name"],
                "status": exp.get("status"),
                "timestamp": format_timestamp(exp.get("timestamp")),
                "custom_metrics": exp.get("custom_metrics", {}),
                "thumb_label": exp.get("thumb_label"),
                "version_date": exp["version_date"],
            }
        )

    output_json({"runs": result, "total": total_count, "range": f"{start}:{end if end else ''}"})


def edit_and_rerun_command(args) -> None:
    """Edit a single key in a node's input or output and immediately rerun."""
    # Determine field, key, and value from mutually exclusive args
    if args.input:
        field = "input"
        key, value = args.input
    else:
        field = "output"
        key, value = args.output

    prepared = _server_request(
        "POST",
        f"/ui/run/{args.run_id}/prepare-edit-rerun",
        data={
            "node_uuid": args.node_uuid,
            "field": field,
            "key": key,
            "value": _resolve_value(value),
            "run_name": args.run_name,
        },
    )
    if prepared.get("status") == "error":
        output_json(prepared)

    result = _spawn_rerun(prepared, timeout=args.timeout)
    result["node_uuid"] = prepared.get("node_uuid", args.node_uuid)
    result["edited_field"] = field
    result["edited_key"] = key
    output_json(result)


def install_skill_command(args) -> None:
    """Install the shared sovara skill for Codex, Claude Code, or both."""
    from sovara.common.config import _ask_field, _convert_to_valid_path

    install_targets = _expand_skill_install_targets(args.target)
    try:
        target_root = _resolve_skill_install_root(
            args.level,
            args.project_dir,
            _ask_field,
            _convert_to_valid_path,
        )
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    install_roots = _resolve_skill_install_roots(target_root, install_targets, args.level)
    installed_files = _install_skill_files(install_roots, install_targets)

    for target_name, target_file in installed_files:
        print(f"\033[32mInstalled {target_name} skill to {target_file}\033[0m")

    location_label = "globally" if args.level == "global" else "in the selected project"

    if "codex" in install_targets and "claude" in install_targets:
        print(
            f"\nInstalled {location_label}. "
            "Re-open Claude Code, and restart Codex if the skill does not appear."
        )
    elif "codex" in install_targets:
        print(f"\nInstalled {location_label} for Codex. Restart Codex if needed.")
    else:
        print(f"\nInstalled {location_label} for Claude Code. Re-open Claude Code if needed.")


def _resolve_skill_install_root(
    install_level: str,
    project_dir: str | None,
    ask_field,
    convert_to_valid_path,
) -> Path:
    """Resolve the base directory for skill installation."""
    if install_level == "global":
        if project_dir is not None:
            raise ValueError("--project-dir can only be used with --level project")
        return Path(_home_dir())

    if install_level != "project":
        raise ValueError(f"Unsupported install level: {install_level}")

    if project_dir is None:
        default_path = os.getcwd()
        project_dir = ask_field(
            f"Target project directory [{default_path}]\n> ",
            convert_to_valid_path,
            default=default_path,
            error_message="Please enter a valid directory path.",
            path_completion=True,
        )
    else:
        project_dir = convert_to_valid_path(project_dir)

    target_root = Path(project_dir).expanduser().resolve()
    if not target_root.is_dir():
        raise ValueError(f"Target project directory does not exist: {target_root}")
    return target_root


def _expand_skill_install_targets(target: str) -> list[str]:
    """Expand a target selector into concrete install destinations."""
    if target == "both":
        return ["codex", "claude"]
    return [target]


def _skill_install_dir(target_root: Path, target: str) -> Path:
    """Return the install directory for a supported skill target."""
    if target == "codex":
        return target_root / ".agents" / "skills" / "sovara"
    if target == "claude":
        return target_root / ".claude" / "skills" / "sovara"
    raise ValueError(f"Unsupported skill install target: {target}")


def _skill_target_display_name(target: str) -> str:
    """Return the display name for a supported skill target."""
    if target == "codex":
        return "Codex"
    if target == "claude":
        return "Claude Code"
    raise ValueError(f"Unsupported skill install target: {target}")


def _home_dir() -> str:
    """Return the resolved current user's home directory."""
    return os.path.realpath(os.path.expanduser("~"))


def _has_existing_skill_install(root: Path, install_targets: list[str]) -> bool:
    """Return True when at least one requested target is already installed under root."""
    for install_target in install_targets:
        target_file = os.path.join(_skill_install_dir(root, install_target), "SKILL.md")
        if os.path.isfile(target_file):
            return True
    return False


def _find_current_project_skill_root(install_targets: list[str]) -> Path | None:
    """Return the nearest cwd ancestor with an existing skill install, excluding the home root."""
    cwd_root = os.path.realpath(os.getcwd())
    home_root = _home_dir()

    try:
        if os.path.commonpath([cwd_root, home_root]) != home_root:
            return None
    except ValueError:
        return None

    current = cwd_root
    while current != home_root:
        candidate_root = Path(current)
        if _has_existing_skill_install(candidate_root, install_targets):
            return candidate_root
        parent = os.path.dirname(current)
        if parent == current:
            break
        current = parent

    return None


def _resolve_skill_install_roots(
    target_root: Path, install_targets: list[str], install_level: str
) -> list[Path]:
    """Install to the requested root and refresh matching existing installs in common locations."""
    install_roots: list[Path] = []
    seen: set[Path] = set()

    def _add(root: Path | None) -> None:
        if root is None:
            return
        resolved = root.expanduser().resolve()
        if resolved in seen:
            return
        seen.add(resolved)
        install_roots.append(resolved)

    home_root = Path(_home_dir())
    _add(target_root)

    if home_root != target_root and _has_existing_skill_install(home_root, install_targets):
        _add(home_root)

    if install_level == "global":
        _add(_find_current_project_skill_root(install_targets))

    return install_roots


def _install_skill_files(
    target_roots: list[Path], install_targets: list[str]
) -> list[tuple[str, Path]]:
    """Copy the bundled SKILL.md into each requested target location."""
    # Find the source SKILL.md bundled inside the sovara package
    import sovara.assets

    skill_source = Path(sovara.assets.__file__).parent / "SKILL.md"

    if not skill_source.exists():
        print(f"Error: SKILL.md not found at {skill_source}", file=sys.stderr)
        sys.exit(1)

    installed_files = []
    written_files: set[Path] = set()
    for target_root in target_roots:
        for install_target in install_targets:
            target_dir = _skill_install_dir(target_root, install_target)
            target_file = target_dir / "SKILL.md"
            if target_file in written_files:
                continue
            os.makedirs(target_dir, exist_ok=True)
            shutil.copy2(skill_source, target_file)
            written_files.add(target_file)
            installed_files.append((_skill_target_display_name(install_target), target_file))

    return installed_files


# ===========================================================
# Priors commands
# ===========================================================


def _is_priors_server_running() -> bool:
    """Check if the main server's priors API is already running."""
    import urllib.request
    import urllib.error

    try:
        req = urllib.request.Request(f"{PRIORS_SERVER_URL}/health", method="GET")
        with urllib.request.urlopen(req, timeout=2) as response:
            return response.status == 200
    except (urllib.error.URLError, TimeoutError, OSError):
        return False


def priors_start_server_command(args) -> None:
    """Start the main Sovara server that hosts the priors API."""
    # Check if already running
    if _is_priors_server_running():
        output_json(
            {
                "status": "success",
                "message": "Sovara priors API is already running",
                "url": PRIORS_SERVER_URL,
            }
        )

    cmd = ["uv", "run", "so-server", "start"]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=PRIORS_SERVER_TIMEOUT)
        if result.returncode == 0:
            output_json(
                {
                    "status": "success",
                    "message": "Sovara server started successfully",
                    "url": PRIORS_SERVER_URL,
                }
            )
        else:
            error_output = result.stderr or result.stdout or "Unknown error starting server"
            output_json(
                {
                    "status": "error",
                    "error": error_output,
                    "hint": "Try starting the main server directly with `uv run so-server start`.",
                }
            )
    except FileNotFoundError:
        output_json(
            {
                "status": "error",
                "error": "uv command not found. Please install uv or ensure it's in PATH.",
            }
        )
    except subprocess.TimeoutExpired:
        output_json(
            {
                "status": "error",
                "error": f"Server start command timed out after {PRIORS_SERVER_TIMEOUT}s",
            }
        )
    except Exception as e:
        output_json(
            {
                "status": "error",
                "error": f"Failed to start Sovara server: {e}",
            }
        )


def _priors_request(
    method: str,
    path: str,
    data: dict | None = None,
    *,
    project_id: str | None = None,
    user_id: str | None = None,
) -> dict:
    """Make an HTTP request to the priors server.

    Returns the parsed JSON response, or an error dict.
    """
    import urllib.request
    import urllib.error

    url = f"{PRIORS_SERVER_URL}{path}"

    if data is not None:
        body = json.dumps(data).encode("utf-8")
    else:
        body = None

    if user_id is None:
        headers, scope_error = _resolve_local_priors_scope_headers(project_id=project_id)
    else:
        headers, scope_error = _resolve_local_priors_scope_headers(project_id=project_id, user_id=user_id)
    if scope_error is not None:
        return scope_error
    if body:
        headers["Content-Type"] = "application/json"

    req = urllib.request.Request(
        url,
        data=body,
        headers=headers,
        method=method,
    )

    try:
        with urllib.request.urlopen(req, timeout=120) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8") if e.fp else str(e)
        try:
            server_error = json.loads(error_body)
            if "detail" in server_error:
                return {"status": "error", "error": server_error["detail"]}
            if "error" in server_error:
                return {"status": "error", "error": server_error["error"]}
        except json.JSONDecodeError:
            pass
        return {"status": "error", "error": error_body}
    except urllib.error.URLError as e:
        return {"status": "error", "error": f"Connection failed: {e.reason}"}
    except json.JSONDecodeError as e:
        return {"status": "error", "error": f"Invalid JSON response: {e}"}


def _parse_sse_stream(response) -> dict:
    """Read an SSE stream from *response* and return the result/error data.

    Handles ``waiting``, ``result``, and ``error`` events.  On ``waiting``,
    prints a message to stderr so the CLI user sees feedback.
    """
    current_event = None
    for raw_line in response:
        line = raw_line.decode("utf-8", errors="replace").rstrip("\n").rstrip("\r")

        if line.startswith("event: "):
            current_event = line[7:]
        elif line.startswith("data: "):
            data_str = line[6:]
            try:
                data = json.loads(data_str)
            except json.JSONDecodeError:
                data = {"raw": data_str}

            if current_event == "waiting":
                msg = data.get("message", "Waiting for lock...")
                print(f"[priors] {msg}", file=sys.stderr)
            elif current_event == "acquired":
                msg = data.get("message", "Acquired lock")
                print(f"[priors] {msg}", file=sys.stderr)
            elif current_event == "result":
                return data
            elif current_event == "error":
                code = data.get("code", 500)
                error_msg = data.get("error", "Unknown error")
                return {"status": "error", "error": error_msg, "code": code}

            current_event = None

    # Stream ended without result/error
    return {"status": "error", "error": "SSE stream ended unexpectedly"}


def _priors_request_sse(
    method: str,
    path: str,
    data: dict | None = None,
    *,
    project_id: str | None = None,
    user_id: str | None = None,
) -> dict:
    """Make an HTTP request to the priors server expecting an SSE stream.

    Returns the parsed result/error data dict.
    """
    import urllib.request
    import urllib.error

    url = f"{PRIORS_SERVER_URL}{path}"

    if data is not None:
        body = json.dumps(data).encode("utf-8")
    else:
        body = None

    if user_id is None:
        scope_headers, scope_error = _resolve_local_priors_scope_headers(project_id=project_id)
    else:
        scope_headers, scope_error = _resolve_local_priors_scope_headers(project_id=project_id, user_id=user_id)
    if scope_error is not None:
        return scope_error

    headers = {"Accept": "text/event-stream", **scope_headers}
    if body:
        headers["Content-Type"] = "application/json"

    req = urllib.request.Request(
        url,
        data=body,
        headers=headers,
        method=method,
    )

    try:
        with urllib.request.urlopen(req, timeout=120) as response:
            content_type = response.headers.get("Content-Type", "")
            if "text/event-stream" in content_type:
                return _parse_sse_stream(response)
            # Fallback: plain JSON response
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8") if e.fp else str(e)
        try:
            server_error = json.loads(error_body)
            if "detail" in server_error:
                return {"status": "error", "error": server_error["detail"]}
            if "error" in server_error:
                return {"status": "error", "error": server_error["error"]}
        except json.JSONDecodeError:
            pass
        return {"status": "error", "error": error_body}
    except urllib.error.URLError as e:
        return {"status": "error", "error": f"Connection failed: {e.reason}"}
    except json.JSONDecodeError as e:
        return {"status": "error", "error": f"Invalid JSON response: {e}"}


def projects_command(args) -> None:
    """List projects or fetch a single project by ID/prefix."""
    if getattr(args, "project_id", None):
        project_id, project_error = _resolve_project_id_prefix(args.project_id)
        if project_error is not None:
            output_json(project_error)
        output_json(_server_request("GET", f"/ui/projects/{project_id}"))
        return

    output_json(_server_request("GET", "/ui/projects"))


def priors_list_command(args) -> None:
    """List priors, optionally filtered by folder path."""
    endpoint = "/api/v1/priors"
    if args.path:
        from urllib.parse import urlencode

        endpoint += "?" + urlencode({"path": args.path})
    output_json(_priors_request("GET", endpoint, project_id=args.project_id))


def priors_get_command(args) -> None:
    """Get a specific prior by ID."""
    output_json(_priors_request("GET", f"/api/v1/priors/{args.prior_id}", project_id=args.project_id))


def priors_create_command(args) -> None:
    """Create a new prior. Server performs LLM validation unless force=true."""
    data = {
        "title": args.title,
        "content": args.content,
    }
    if args.summary:
        data["summary"] = args.summary
    if args.path:
        data["path"] = args.path
    if args.run_id:
        data["run_id"] = args.run_id
    if args.when_to_use:
        data["when_to_use"] = args.when_to_use
    if args.consequence_if_not_followed:
        data["consequence_if_not_followed"] = args.consequence_if_not_followed
    if args.non_adherence_severity is not None:
        data["non_adherence_severity"] = args.non_adherence_severity
    if args.aliases:
        data["aliases"] = args.aliases
    if args.keywords:
        data["keywords"] = args.keywords
    if args.related_priors:
        data["related_priors"] = args.related_priors

    endpoint = "/api/v1/priors"
    if args.force:
        endpoint += "?force=true"

    output_json(_priors_request_sse("POST", endpoint, data, project_id=args.project_id))


def priors_update_command(args) -> None:
    """Update an existing prior. Server performs LLM validation unless force=true."""
    data = {}
    if args.title:
        data["title"] = args.title
    if args.content:
        data["content"] = args.content
    if args.path:
        data["path"] = args.path
    if args.run_id:
        data["run_id"] = args.run_id
    if args.when_to_use is not None:
        data["when_to_use"] = args.when_to_use
    if args.consequence_if_not_followed is not None:
        data["consequence_if_not_followed"] = args.consequence_if_not_followed
    if args.non_adherence_severity is not None:
        data["non_adherence_severity"] = args.non_adherence_severity
    if args.aliases is not None:
        data["aliases"] = args.aliases
    if args.keywords is not None:
        data["keywords"] = args.keywords
    if args.related_priors is not None:
        data["related_priors"] = args.related_priors

    if not data:
        output_json({"status": "error", "error": "At least one field must be provided"})

    endpoint = f"/api/v1/priors/{args.prior_id}"
    if args.force:
        endpoint += "?force=true"

    output_json(_priors_request_sse("PUT", endpoint, data, project_id=args.project_id))


def priors_delete_command(args) -> None:
    """Delete a prior."""
    output_json(_priors_request_sse("DELETE", f"/api/v1/priors/{args.prior_id}", project_id=args.project_id))


def priors_query_command(args) -> None:
    """Query all priors in a folder and return an injected context block."""
    data = {}
    if args.path:
        data["path"] = args.path
    output_json(_priors_request("POST", "/api/v1/query/priors", data, project_id=args.project_id))


def priors_retrieve_command(args) -> None:
    """Retrieve relevant priors with the LLM-backed retriever."""
    data = {"context": args.context}
    if args.path:
        data["base_path"] = args.path
    output_json(_priors_request("POST", "/api/v1/priors/retrieve", data, project_id=args.project_id))


def _normalize_folder_path(path: str) -> str:
    """Normalize a folder path: append '/' if non-empty and missing trailing slash.

    Validates path safety: rejects '..', leading '/', double '//', and '.folder' segments.
    """
    if not path:
        return path
    # Reject unsafe patterns
    if ".." in path:
        output_json({"status": "error", "error": "Path must not contain '..'"})
    if path.startswith("/"):
        output_json({"status": "error", "error": "Path must not start with '/'"})
    if "//" in path:
        output_json({"status": "error", "error": "Path must not contain '//'"})
    # Reject segments ending with '.' (e.g. '.hidden/' or 'some.folder/')
    for segment in path.rstrip("/").split("/"):
        if segment.startswith("."):
            output_json(
                {"status": "error", "error": f"Path segment '{segment}' must not start with '.'"}
            )
    if not path.endswith("/"):
        return path + "/"
    return path


def priors_migrate_command(args) -> None:
    """Migrate root-level priors into the default retrieval folder."""
    output_json(_priors_request("POST", "/api/v1/priors/migrate", {}, project_id=args.project_id))


def priors_rebalance_command(args) -> None:
    """Queue background folder rebalancing for oversized folders under a path."""
    path = _normalize_folder_path(args.path or "")
    output_json(
        _priors_request(
            "POST",
            "/api/v1/priors/folders/rebalance",
            {"path": path},
            project_id=args.project_id,
            user_id=args.user_id,
        )
    )


def priors_restructure_propose_command(args) -> None:
    """Propose a prior folder restructure."""
    data = {"base_path": args.path or ""}
    if args.comments:
        data["comments"] = args.comments
    output_json(_priors_request("POST", "/api/v1/priors/restructure/propose", data, project_id=args.project_id))


def priors_restructure_execute_command(args) -> None:
    """Execute a proposed or client-specified prior restructure."""
    try:
        data = _build_restructure_execute_body(args)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        output_json({"status": "error", "error": str(exc)})
    output_json(_priors_request("POST", "/api/v1/priors/restructure/execute", data, project_id=args.project_id))


def priors_restructure_abort_command(args) -> None:
    """Abort a pending prior restructure proposal."""
    output_json(
        _priors_request(
            "POST",
            "/api/v1/priors/restructure/abort",
            {"task_id": args.task_id},
            project_id=args.project_id,
        )
    )


def priors_ls_command(args) -> None:
    """List folder contents at a path."""
    path = _normalize_folder_path(args.path or "")
    output_json(_priors_request("POST", "/api/v1/priors/folders/ls", {"path": path}, project_id=args.project_id))


def priors_mkdir_command(args) -> None:
    """Create an empty folder."""
    path = _normalize_folder_path(args.path)
    output_json(_priors_request("POST", "/api/v1/priors/folders/mkdir", {"path": path}, project_id=args.project_id))


def priors_mv_command(args) -> None:
    """Move/rename a folder, or move priors by ID."""
    if args.ids:
        # Prior mode: -i id1,id2 DST
        prior_ids = [i.strip() for i in args.ids.split(",")]
        if not args.paths:
            output_json({"status": "error", "error": "DST path is required when using -i"})
            return
        dst = _normalize_folder_path(args.paths[0])
        result = _priors_request(
            "POST",
            "/api/v1/priors/items/move",
            {
                "items": [{"kind": "prior", "id": prior_id} for prior_id in prior_ids if prior_id],
                "destination_path": dst,
            },
            project_id=args.project_id,
        )
    else:
        # Folder mode: SRC DST
        if not args.paths or len(args.paths) != 2:
            output_json(
                {
                    "status": "error",
                    "error": "mv requires SRC and DST arguments (or use -i for prior IDs)",
                }
            )
            return
        src = _normalize_folder_path(args.paths[0])
        dst = _normalize_folder_path(args.paths[1])
        result = _priors_request(
            "PUT",
            "/api/v1/priors/folders",
            {
                "path": src,
                "new_path": dst,
            },
            project_id=args.project_id,
        )
    output_json(result)


def priors_cp_command(args) -> None:
    """Copy a folder to a new destination."""
    src = _normalize_folder_path(args.src)
    dst = _normalize_folder_path(args.dst)
    result = _priors_request(
        "POST",
        "/api/v1/priors/folders/cp",
        {
            "src": src,
            "dst": dst,
        },
        project_id=args.project_id,
    )
    output_json(result)


def priors_rm_command(args) -> None:
    """Delete a prior by ID, or recursively delete a folder."""
    if args.recursive:
        # Folder mode: rm -r PATH
        path = _normalize_folder_path(args.target)
        result = _priors_request("POST", "/api/v1/priors/folders/rm", {"path": path}, project_id=args.project_id)
    else:
        # Single prior delete by ID
        result = _priors_request_sse("DELETE", f"/api/v1/priors/{args.target}", project_id=args.project_id)
    output_json(result)


def _add_project_id_argument(parser, *, help_text: str | None = None) -> None:
    parser.add_argument(
        "--project-id",
        "--proj-id",
        dest="project_id",
        default=None,
        help=help_text or "Project ID or unambiguous prefix.",
    )


def _add_user_id_argument(parser, *, help_text: str | None = None) -> None:
    parser.add_argument(
        "--user-id",
        dest="user_id",
        default=None,
        help=help_text or "Explicit user ID. Requires --project-id.",
    )


def create_parser() -> ArgumentParser:
    """Create the argument parser with subcommands."""
    parser = ArgumentParser(
        prog="so-cli",
        description="CLI for programmatic interaction with Sovara dataflow system. Most commands output JSON; `logs` outputs plain text.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    status = subparsers.add_parser(
        "status",
        help="Inspect local Sovara setup state",
        description="Report whether the local Sovara user and project are configured for a path.",
    )
    status.add_argument(
        "--path",
        help="Path to inspect. Defaults to the current working directory.",
    )

    init = subparsers.add_parser(
        "init",
        help="Create or update local Sovara setup",
        description="Create or update the local Sovara user profile and optionally initialize a project.",
    )
    init.add_argument("--user-name", help="Create or update the local Sovara user full name.")
    init.add_argument("--user-email", help="Create or update the local Sovara user email.")
    init.add_argument("--project-root", help="Project root to initialize or update.")
    init.add_argument("--project-name", help="Create or update the Sovara project name.")
    init.add_argument(
        "--project-description", help="Create or update the Sovara project description."
    )

    projects = subparsers.add_parser(
        "projects",
        help="List projects or fetch a single project",
        description="List all visible projects with their project IDs, or fetch one project by ID/prefix.",
    )
    projects.add_argument(
        "project_id",
        nargs="?",
        default=None,
        help="Optional project ID or unambiguous prefix to fetch a single project.",
    )

    # record subcommand
    record = subparsers.add_parser(
        "record",
        help="Start recording a script execution",
        description="Spawn so-record as a background process and return run_id.",
    )
    record.add_argument(
        "-m",
        "--module",
        action="store_true",
        help="Run script_path as a Python module (like python -m)",
    )
    record.add_argument(
        "-u",
        "--unbuffered",
        action="store_true",
        help="Run with unbuffered stdout/stderr, like python -u",
    )
    record.add_argument("--run-name", help="Human-readable name for this run")
    record.add_argument("--user-name", help="Override or create the local Sovara user full name.")
    record.add_argument("--user-email", help="Override or create the local Sovara user email.")
    record.add_argument(
        "--project-root",
        help="Project root to resolve or create for this run. Defaults to the script directory.",
    )
    record.add_argument("--project-name", help="Override or create the Sovara project name.")
    record.add_argument(
        "--project-description", help="Override or create the Sovara project description."
    )
    record.add_argument(
        "--timeout",
        type=float,
        default=None,
        help="Timeout in seconds (terminates script if exceeded)",
    )
    # Positional args must come after options to avoid REMAINDER capturing them
    record.add_argument("script_path", help="Script to execute (or module name with -m)")
    record.add_argument("script_args", nargs=REMAINDER, help="Arguments to pass to the script")

    # probe subcommand
    probe = subparsers.add_parser(
        "probe",
        help="Query run state",
        description="Query metadata or specific nodes of a run.",
    )
    probe.add_argument("run_id", help="Run UUID or unambiguous prefix to probe")
    probe.add_argument(
        "--node",
        help="Return detailed info for a single node UUID or unambiguous prefix",
    )
    probe.add_argument(
        "--nodes",
        help="Return detailed info for multiple node UUIDs or prefixes (comma-separated)",
    )
    probe.add_argument(
        "--preview",
        action="store_true",
        help="Truncate string values to 20 characters for a compact overview",
    )
    probe.add_argument(
        "--input",
        dest="show_input",
        action="store_true",
        help="Only show input content (omit output)",
    )
    probe.add_argument(
        "--output",
        dest="show_output",
        action="store_true",
        help="Only show output content (omit input)",
    )
    probe.add_argument(
        "--key-regex",
        help="Filter keys using regex pattern on flattened keys (e.g., 'messages.*content'). Lists use index notation: content.0.hello",
    )

    logs = subparsers.add_parser(
        "logs",
        help="Show a run's persisted logs",
        description="Show the persisted log transcript for a run with optional filtering.",
    )
    logs.add_argument("run_id", help="Run UUID or unambiguous prefix to fetch logs for")
    logs.add_argument(
        "--tail",
        type=int,
        help="Show only the last N displayed lines",
    )
    logs.add_argument(
        "--grep",
        help="Filter displayed lines using a regex pattern",
    )
    logs.add_argument(
        "--context",
        type=int,
        default=0,
        help="Show N lines of context around each grep match",
    )
    logs.add_argument(
        "--line-numbers",
        action="store_true",
        help="Prefix displayed lines with original line numbers",
    )

    # runs subcommand
    runs = subparsers.add_parser(
        "runs",
        help="List runs from server",
        description="List runs with optional range. Range format: ':50' (first 50), '50:100' (50-99), '10:' (from 10 onwards).",
    )
    runs.add_argument(
        "--range",
        default=":50",
        help="Range of runs to return (default: ':50'). Format: 'start:end', ':end', 'start:'",
    )
    runs.add_argument(
        "--regex",
        help="Filter runs by name using regex pattern",
    )
    runs.add_argument(
        "--status",
        choices=["all", "running", "finished"],
        default="all",
        help="Filter runs by runtime status",
    )
    _add_project_id_argument(
        runs,
        help_text="Filter runs to a project ID or unambiguous prefix.",
    )

    # edit-and-rerun subcommand
    edit_and_rerun = subparsers.add_parser(
        "edit-and-rerun",
        help="Edit a node and immediately rerun",
        description="Copy a run, edit a single key in a node's input or output, and rerun. "
        "Keys use flattened dot-notation from probe output (e.g., messages.0.content). "
        "Value can be a literal or a path to a file.",
    )
    edit_and_rerun.add_argument("run_id", help="Run UUID or unambiguous prefix containing the node")
    edit_and_rerun.add_argument("node_uuid", help="Node UUID or unambiguous prefix to edit")
    edit_and_rerun_group = edit_and_rerun.add_mutually_exclusive_group(required=True)
    edit_and_rerun_group.add_argument(
        "--input",
        nargs=2,
        metavar=("KEY", "VALUE"),
        help="Edit an input key: --input <flat_key> <value_or_file_path>",
    )
    edit_and_rerun_group.add_argument(
        "--output",
        nargs=2,
        metavar=("KEY", "VALUE"),
        help="Edit an output key: --output <flat_key> <value_or_file_path>",
    )
    edit_and_rerun.add_argument(
        "--timeout",
        type=float,
        default=None,
        help="Timeout in seconds (terminates script if exceeded)",
    )
    edit_and_rerun.add_argument(
        "--run-name",
        help="Name for the new run. Defaults to 'Edit of <original name>'",
    )

    # install-skill subcommand
    install_skill = subparsers.add_parser(
        "install-skill",
        help="Install the sovara skill globally or into a project",
        description=(
            "Install the shared sovara skill for Codex, Claude Code, or both. "
            "Defaults to both targets at the global user level."
        ),
    )
    install_skill.add_argument(
        "--level",
        choices=("global", "project"),
        default="global",
        help="Install to user-level skill directories (default) or into a specific project.",
    )
    install_skill.add_argument(
        "--project-dir",
        help="Project root to install into when --level project is used. Defaults to an interactive prompt.",
    )
    install_skill.add_argument(
        "--target",
        choices=("codex", "claude", "both"),
        default="both",
        help="Install for Codex, Claude Code, or both (default: both).",
    )

    # priors subcommand with nested subcommands
    priors = subparsers.add_parser(
        "priors",
        help="Design priors commands",
        description="Manage priors for agent development.",
    )
    priors_subparsers = priors.add_subparsers(dest="priors_command", required=True)

    # priors start-server
    priors_subparsers.add_parser(
        "start-server",
        help="Start the priors server",
        description="Start the SovaraDB daemon.",
    )

    priors_list = priors_subparsers.add_parser(
        "list",
        help="List priors",
        description="List priors with their IDs, titles, and summaries.",
    )
    priors_list.add_argument("--path", "-p", default=None, help="Folder path to filter by")
    _add_project_id_argument(priors_list)

    priors_get = priors_subparsers.add_parser(
        "get",
        help="Get a prior",
        description="Get full details of a prior by its ID.",
    )
    priors_get.add_argument("prior_id", help="The prior ID to retrieve")
    _add_project_id_argument(priors_get)

    priors_create = priors_subparsers.add_parser(
        "create",
        help="Create a prior",
        description="Create a new prior with a title and markdown content.",
    )
    priors_create.add_argument(
        "--title",
        "-n",
        required=True,
        help="Prior title (max 200 chars)",
    )
    priors_create.add_argument(
        "--content",
        "-c",
        required=True,
        help="Full prior content in markdown",
    )
    priors_create.add_argument(
        "--summary",
        default=None,
        help="Optional summary override. When omitted, the server generates one.",
    )
    priors_create.add_argument(
        "--path",
        "-p",
        default=None,
        help="Folder path (e.g. 'beaver/retriever/')",
    )
    priors_create.add_argument(
        "--run-id",
        default=None,
        help="Optional run ID the prior was extracted from",
    )
    priors_create.add_argument(
        "--when-to-use",
        default=None,
        help="Optional retrieval-oriented usage hint. Normally generated by the cheap model.",
    )
    priors_create.add_argument(
        "--consequence-if-not-followed",
        default=None,
        help="Expected failure mode when this prior is relevant but violated.",
    )
    priors_create.add_argument(
        "--non-adherence-severity",
        type=int,
        default=None,
        help="Prior-authored violation severity from 1 to 10.",
    )
    priors_create.add_argument(
        "--alias",
        dest="aliases",
        action="append",
        default=[],
        help="Add an alias for BM25/keyword search. Repeat to provide multiple aliases.",
    )
    priors_create.add_argument(
        "--keyword",
        dest="keywords",
        action="append",
        default=[],
        help="Add a search keyword. Repeat to provide multiple keywords.",
    )
    priors_create.add_argument(
        "--related-prior",
        dest="related_priors",
        action="append",
        default=[],
        help="Add a related prior ID. Repeat to provide multiple links.",
    )
    priors_create.add_argument(
        "--force",
        "-f",
        action="store_true",
        help="Skip LLM validation and create the prior directly",
    )
    _add_project_id_argument(priors_create)

    priors_update = priors_subparsers.add_parser(
        "update",
        help="Update a prior",
        description="Update an existing prior's title, content, path, or source run ID.",
    )
    priors_update.add_argument("prior_id", help="The prior ID to update")
    priors_update.add_argument("--title", "-n", help="New prior title")
    priors_update.add_argument("--content", "-c", help="New content")
    priors_update.add_argument("--path", "-p", help="New folder path")
    priors_update.add_argument("--run-id", help="New source run ID")
    priors_update.add_argument(
        "--when-to-use",
        help="Override the retrieval-oriented usage hint.",
    )
    priors_update.add_argument(
        "--consequence-if-not-followed",
        help="Set the expected failure mode when this prior is relevant but violated.",
    )
    priors_update.add_argument(
        "--non-adherence-severity",
        type=int,
        help="Set the prior-authored violation severity from 1 to 10.",
    )
    priors_update.add_argument(
        "--alias",
        dest="aliases",
        action="append",
        default=None,
        help="Set aliases for BM25/keyword search. Repeat to provide multiple aliases.",
    )
    priors_update.add_argument(
        "--keyword",
        dest="keywords",
        action="append",
        default=None,
        help="Set search keywords. Repeat to provide multiple keywords.",
    )
    priors_update.add_argument(
        "--related-prior",
        dest="related_priors",
        action="append",
        default=None,
        help="Set related prior IDs. Repeat to provide multiple links.",
    )
    priors_update.add_argument(
        "--force",
        "-f",
        action="store_true",
        help="Skip LLM validation and update the prior directly",
    )
    _add_project_id_argument(priors_update)

    priors_delete = priors_subparsers.add_parser(
        "delete",
        help="Delete a prior",
        description="Delete a prior by its ID.",
    )
    priors_delete.add_argument("prior_id", help="The prior ID to delete")
    _add_project_id_argument(priors_delete)

    priors_query = priors_subparsers.add_parser(
        "query",
        help="Query priors by folder path",
        description="Get priors from a folder and return them as injected context.",
    )
    priors_query.add_argument(
        "--path",
        "-p",
        default=None,
        help="Folder path to retrieve priors from (omit for all priors)",
    )
    _add_project_id_argument(priors_query)

    priors_retrieve = priors_subparsers.add_parser(
        "retrieve",
        help="Retrieve relevant priors",
        description="Use the LLM-backed retriever to select relevant priors.",
    )
    priors_retrieve.add_argument("context", help="Context string used for retrieval")
    priors_retrieve.add_argument(
        "--path",
        "-p",
        default=None,
        help="Root folder path to search from",
    )
    _add_project_id_argument(priors_retrieve)

    priors_migrate = priors_subparsers.add_parser(
        "migrate",
        help="Migrate root priors",
        description="Move root-level priors into the default retrieval folder.",
    )
    _add_project_id_argument(priors_migrate)

    priors_rebalance = priors_subparsers.add_parser(
        "rebalance",
        help="Queue folder rebalancing",
        description="Queue the background folder rebalancer for oversized folders under a path.",
    )
    priors_rebalance.add_argument(
        "--path",
        "-p",
        default="",
        help="Root folder path to scan (default: root)",
    )
    _add_project_id_argument(
        priors_rebalance,
        help_text="Project ID or unambiguous prefix. Required with --user-id; use the full project ID in that case.",
    )
    _add_user_id_argument(priors_rebalance)

    priors_restructure = priors_subparsers.add_parser(
        "restructure",
        help="Propose/execute/abort taxonomy changes",
        description="Manage prior taxonomy restructure proposals.",
    )
    restructure_subparsers = priors_restructure.add_subparsers(
        dest="restructure_command", required=True
    )

    restructure_propose = restructure_subparsers.add_parser(
        "propose",
        help="Propose a restructure",
        description="Analyze priors and propose a better folder taxonomy.",
    )
    restructure_propose.add_argument(
        "--path",
        "-p",
        default="",
        help="Root folder path to analyze (default: root)",
    )
    restructure_propose.add_argument(
        "--comments",
        "-c",
        default=None,
        help="Optional guidance for the restructurer",
    )
    _add_project_id_argument(restructure_propose)

    restructure_execute = restructure_subparsers.add_parser(
        "execute",
        help="Execute a restructure",
        description="Execute a proposal by task ID, from a proposal file, or from a standalone execute body.",
    )
    restructure_execute.add_argument(
        "--task-id",
        default=None,
        help="Task ID from a prior propose step",
    )
    restructure_execute.add_argument(
        "--proposal-file",
        default=None,
        help="JSON file containing a propose response or execute request body",
    )
    restructure_execute.add_argument(
        "--moves-file",
        default=None,
        help="JSON file containing a moves array for an edited execute request",
    )
    restructure_execute.add_argument(
        "--base-path",
        default=None,
        help="Root folder path for standalone execution",
    )
    restructure_execute.add_argument(
        "--snapshot",
        default=None,
        help="State hash for standalone execution",
    )
    restructure_execute.add_argument(
        "--new-folder",
        action="append",
        default=None,
        help="New folder to create during execution; repeat as needed",
    )
    _add_project_id_argument(restructure_execute)

    restructure_abort = restructure_subparsers.add_parser(
        "abort",
        help="Abort a restructure",
        description="Abort a pending restructure proposal and release its lock.",
    )
    restructure_abort.add_argument("task_id", help="Task ID from the propose step")
    _add_project_id_argument(restructure_abort)

    priors_ls = priors_subparsers.add_parser(
        "ls",
        help="List folder contents",
        description="List immediate child folders and priors at a path.",
    )
    priors_ls.add_argument(
        "path", nargs="?", default="", help="Folder path to list (default: root)"
    )
    _add_project_id_argument(priors_ls)

    priors_mkdir = priors_subparsers.add_parser(
        "mkdir",
        help="Create an empty folder",
        description="Create an empty folder at the given path.",
    )
    priors_mkdir.add_argument("path", help="Folder path to create (e.g. 'beaver/new-folder/')")
    _add_project_id_argument(priors_mkdir)

    priors_mv = priors_subparsers.add_parser(
        "mv",
        help="Move/rename a folder or move priors by ID",
        description="Move a folder (mv SRC DST) or move priors by ID (mv -i id1,id2 DST).",
    )
    priors_mv.add_argument(
        "-i",
        "--ids",
        default=None,
        help="Comma-separated prior IDs to move (prior mode)",
    )
    priors_mv.add_argument("paths", nargs="*", help="SRC DST (folder mode) or DST (with -i)")
    _add_project_id_argument(priors_mv)

    priors_cp = priors_subparsers.add_parser(
        "cp",
        help="Copy a folder",
        description="Copy all priors under a folder to a new destination.",
    )
    priors_cp.add_argument("src", help="Source folder path")
    priors_cp.add_argument("dst", help="Destination folder path")
    _add_project_id_argument(priors_cp)

    priors_rm = priors_subparsers.add_parser(
        "rm",
        help="Delete a prior or folder",
        description="Delete a single prior by ID (rm TARGET) or a folder recursively (rm -r PATH).",
    )
    priors_rm.add_argument(
        "-r",
        "--recursive",
        action="store_true",
        help="Delete folder recursively",
    )
    priors_rm.add_argument("target", help="Prior ID or folder path (with -r)")
    _add_project_id_argument(priors_rm)

    return parser


def main():
    parser = create_parser()
    args = parser.parse_args()

    if args.command == "status":
        status_command(args)
    elif args.command == "init":
        init_command(args)
    elif args.command == "projects":
        projects_command(args)
    elif args.command == "record":
        record_command(args)
    elif args.command == "probe":
        probe_command(args)
    elif args.command == "logs":
        logs_command(args)
    elif args.command == "runs":
        runs_command(args)
    elif args.command == "edit-and-rerun":
        edit_and_rerun_command(args)
    elif args.command == "install-skill":
        install_skill_command(args)
    elif args.command == "priors":
        if args.priors_command == "start-server":
            priors_start_server_command(args)
        elif args.priors_command == "list":
            priors_list_command(args)
        elif args.priors_command == "get":
            priors_get_command(args)
        elif args.priors_command == "create":
            priors_create_command(args)
        elif args.priors_command == "update":
            priors_update_command(args)
        elif args.priors_command == "delete":
            priors_delete_command(args)
        elif args.priors_command == "query":
            priors_query_command(args)
        elif args.priors_command == "retrieve":
            priors_retrieve_command(args)
        elif args.priors_command == "migrate":
            priors_migrate_command(args)
        elif args.priors_command == "rebalance":
            priors_rebalance_command(args)
        elif args.priors_command == "restructure":
            if args.restructure_command == "propose":
                priors_restructure_propose_command(args)
            elif args.restructure_command == "execute":
                priors_restructure_execute_command(args)
            elif args.restructure_command == "abort":
                priors_restructure_abort_command(args)
        elif args.priors_command == "ls":
            priors_ls_command(args)
        elif args.priors_command == "mkdir":
            priors_mkdir_command(args)
        elif args.priors_command == "mv":
            priors_mv_command(args)
        elif args.priors_command == "cp":
            priors_cp_command(args)
        elif args.priors_command == "rm":
            priors_rm_command(args)


if __name__ == "__main__":
    main()
