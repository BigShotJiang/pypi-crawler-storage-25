#!/usr/bin/env python3

import sys
import os
import json
import shlex
import random
import threading
import traceback
import time
import psutil
import signal
import runpy

from typing import Optional, List

from sovara.common.logger import logger
from sovara.common.constants import (
    HOST,
    PORT,
    WELCOME_ART,
    SERVER_START_TIMEOUT,
    MESSAGE_POLL_INTERVAL,
)
from sovara.common.config import _ask_field
from sovara.common.project import normalize_project_name, suggest_project_name_for_root
from sovara.runner.context_manager import (
    clear_run_timer,
    reset_current_run_timer,
    set_parent_run_id,
)
from sovara.common.utils import set_server_url, http_post
from sovara.runner.monkey_patching.apply_monkey_patches import apply_all_monkey_patches
from sovara.runner.run_log_capture import RunLogCapture
from sovara.runner.runtime_client import runtime_client

_REUSE_RUN_ID_ENV = "SOVARA_REUSE_RUN_ID"


class SetupRequiredError(RuntimeError):
    """Raised when Sovara setup is missing and prompting is not available."""


def _log_error(context: str, exception: Exception) -> None:
    """Centralized error logging utility."""
    logger.error(f"[AgentRunner] {context}: {exception}")
    logger.debug(f"[AgentRunner] Traceback: {traceback.format_exc()}")


def _format_init_command(
    *,
    user_name: str | None = None,
    user_email: str | None = None,
    project_root: str | None = None,
    project_name: str | None = None,
    project_description: str | None = None,
) -> str:
    parts = ["so-cli", "init"]

    def _append(flag: str, value: str | None) -> None:
        if value is None:
            return
        parts.extend([flag, value])

    _append("--user-name", user_name)
    _append("--user-email", user_email)
    _append("--project-root", project_root)
    _append("--project-name", project_name)
    _append("--project-description", project_description)
    return " ".join(shlex.quote(part) for part in parts)


def _normalize_traceback_path(path: str | None) -> str | None:
    """Return a normalized absolute path, or None for synthetic traceback entries."""
    if not path or path.startswith("<") and path.endswith(">"):
        return None
    return os.path.normcase(os.path.realpath(os.path.abspath(path)))


def _build_traceback_layout() -> dict[str, str] | None:
    """Infer the repo layout from this file when running from a source checkout."""
    agent_runner_path = _normalize_traceback_path(__file__)
    if not agent_runner_path:
        return None

    runner_root = os.path.dirname(agent_runner_path)
    package_root = os.path.dirname(runner_root)
    src_root = os.path.dirname(package_root)
    repo_root = os.path.dirname(src_root)

    if os.path.basename(runner_root) != "runner":
        return None
    if os.path.basename(package_root) != "sovara":
        return None
    if os.path.basename(src_root) != "src":
        return None

    return {
        "repo_root": repo_root,
        "package_root": package_root,
        "tests_root": os.path.join(repo_root, "tests"),
        "example_workflows_root": os.path.join(repo_root, "example_workflows"),
    }


TRACEBACK_LAYOUT = _build_traceback_layout()


def _is_traceback_path_under(path: str | None, root: str | None) -> bool:
    if not path or not root:
        return False

    normalized_path = _normalize_traceback_path(path)
    normalized_root = _normalize_traceback_path(root)
    if not normalized_path or not normalized_root:
        return False

    try:
        return os.path.commonpath([normalized_path, normalized_root]) == normalized_root
    except ValueError:
        return False


def _iter_traceback_chain(tb_exc):
    """Yield traceback exception segments in the order Python formats them."""
    seen = set()
    current = tb_exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        yield current
        if current.__cause__ is not None:
            current = current.__cause__
        elif current.__context__ is not None and not current.__suppress_context__:
            current = current.__context__
        else:
            current = None


def _traceback_has_repo_dev_frames(tb_exc, layout: dict[str, str]) -> bool:
    for current in _iter_traceback_chain(tb_exc):
        for frame in current.stack:
            if _is_traceback_path_under(frame.filename, layout["tests_root"]):
                return True
            if _is_traceback_path_under(frame.filename, layout["example_workflows_root"]):
                return True
    return False


def _deepest_traceback_originates_in_sovara(tb_exc, layout: dict[str, str]) -> bool:
    deepest = None
    for current in _iter_traceback_chain(tb_exc):
        deepest = current

    if deepest is None:
        return False

    for frame in reversed(deepest.stack):
        if _is_traceback_path_under(frame.filename, layout["package_root"]):
            return True

        normalized = _normalize_traceback_path(frame.filename)
        if normalized:
            return False

    return False


def _should_filter_sovara_traceback(tb_exc, layout: dict[str, str] | None = None) -> bool:
    """Hide Sovara frames only for external-user exceptions."""
    active_layout = layout or TRACEBACK_LAYOUT
    if active_layout is None:
        return False

    if _traceback_has_repo_dev_frames(tb_exc, active_layout):
        return False

    if _deepest_traceback_originates_in_sovara(tb_exc, active_layout):
        return False

    return True


def _filter_sovara_traceback_frames(tb_exc, layout: dict[str, str]) -> None:
    for current in _iter_traceback_chain(tb_exc):
        filtered_frames = [
            frame
            for frame in current.stack
            if not _is_traceback_path_under(frame.filename, layout["package_root"])
        ]
        current.stack = traceback.StackSummary.from_list(filtered_frames)


def _format_exception_for_user(
    exception: BaseException, layout: dict[str, str] | None = None
) -> str:
    """Format exceptions, filtering Sovara frames for external-user failures."""
    tb_exc = traceback.TracebackException.from_exception(exception, capture_locals=False)
    active_layout = layout or TRACEBACK_LAYOUT

    if _should_filter_sovara_traceback(tb_exc, active_layout):
        _filter_sovara_traceback_frames(tb_exc, active_layout)

    return "".join(tb_exc.format(chain=True))


def _find_process_on_port(port: int) -> Optional[int]:
    """Find PID of process listening on the given port using lsof."""
    import subprocess

    try:
        result = subprocess.run(
            ["lsof", "-ti", f":{port}"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0 and result.stdout.strip():
            pid_str = result.stdout.strip().split("\n")[0]
            return int(pid_str)
    except Exception as e:
        logger.debug(f"Could not check port {port} with lsof: {e}")
    return None


def _kill_zombie_server(pid: int) -> bool:
    """Kill a zombie server process gracefully."""
    try:
        os.kill(pid, signal.SIGTERM)
        logger.info(f"Sent SIGTERM to zombie server process {pid}")
        for _ in range(6):
            time.sleep(0.5)
            try:
                os.kill(pid, 0)
            except OSError:
                return True
        logger.warning(f"Process {pid} didn't respond to SIGTERM, sending SIGKILL")
        os.kill(pid, signal.SIGKILL)
        time.sleep(0.5)
        return True
    except OSError as e:
        if e.errno == 3:
            return True
        logger.warning(f"Could not kill process {pid}: {e}")
        return False


def _check_server_health() -> bool:
    """Check if the server is healthy via HTTP."""
    import httpx

    expected_python = os.path.realpath(sys.executable)
    try:
        resp = httpx.get(f"http://{HOST}:{PORT}/health", timeout=SERVER_START_TIMEOUT)
        if resp.status_code != 200:
            return False
        payload = resp.json()
        if not (
            isinstance(payload, dict)
            and payload.get("status") == "ok"
            and payload.get("service") == "sovara"
        ):
            return False
        server_python = payload.get("python_executable")
        if not server_python:
            logger.warning("Sovara server health response is missing python_executable.")
            return False
        if os.path.realpath(str(server_python)) != expected_python:
            logger.warning(
                "Sovara server is running under a different Python executable "
                f"({server_python}); expected {sys.executable}."
            )
            return False
        return True
    except Exception:
        return False


def ensure_server_running() -> None:
    """Ensure the server is running, start it if necessary."""
    if _check_server_health():
        logger.debug(f"Server already running on {HOST}:{PORT}")
        return

    # Check for an unresponsive or incompatible server process.
    existing_pid = _find_process_on_port(PORT)
    if existing_pid:
        logger.warning(
            f"Found unresponsive or incompatible server process {existing_pid}, killing it..."
        )
        if _kill_zombie_server(existing_pid):
            time.sleep(1)

    # Launch new daemon
    from sovara.cli.so_server import launch_daemon_server

    launch_daemon_server()
    logger.debug("Daemon launched, waiting for startup...")

    # Poll for server availability
    max_wait = 15
    poll_interval = 0.5
    elapsed = 0
    while elapsed < max_wait:
        time.sleep(poll_interval)
        elapsed += poll_interval
        if _check_server_health():
            logger.info(f"Server started successfully after {elapsed:.1f}s")
            return

    # Final attempt
    if not _check_server_health():
        raise RuntimeError(f"Server not ready after {max_wait}s")
    logger.info("Server started successfully (final attempt)")


class AgentRunner:
    """Unified agent runner that combines orchestration and execution."""

    def __init__(
        self,
        script_path: str,
        script_args: List[str],
        is_module_execution: bool,
        unbuffered: bool = False,
        sample_id: Optional[str] = None,
        run_name: Optional[str] = None,
        user_name: Optional[str] = None,
        user_email: Optional[str] = None,
        project_root: Optional[str] = None,
        project_name: Optional[str] = None,
        project_description: Optional[str] = None,
    ):
        self.script_path = script_path
        self.script_args = script_args
        self.is_module_execution = is_module_execution
        self.unbuffered = unbuffered
        self.sample_id = sample_id
        self.run_name = run_name
        self.user_name = user_name
        self.user_email = user_email
        self.project_root_override = project_root
        self.project_name_override = project_name
        self.project_description_override = project_description

        # State management
        self.shutdown_flag = False
        self.restart_event = threading.Event()
        self.process_id = os.getpid()
        self._signal_count = 0
        self._deregister_sent = False

        # Run
        self.run_id: Optional[str] = None
        self.server_url: Optional[str] = None

        # SSE listener thread
        self.listener_thread: Optional[threading.Thread] = None

        # Register signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        # Start computing restart command in background (it's slow due to psutil)
        from concurrent.futures import ThreadPoolExecutor

        self._executor = ThreadPoolExecutor(max_workers=1)
        self._restart_command_future = self._executor.submit(self._generate_restart_command)

    def _can_prompt(self) -> bool:
        stdin_isatty = getattr(sys.stdin, "isatty", None)
        stdout_isatty = getattr(sys.stdout, "isatty", None)
        return bool(
            callable(stdin_isatty)
            and stdin_isatty()
            and callable(stdout_isatty)
            and stdout_isatty()
        )

    def _get_script_dir(self) -> str:
        if self.is_module_execution:
            return os.getcwd()
        return os.path.dirname(os.path.abspath(self.script_path))

    def _default_project_root(self) -> str:
        if self.project_root_override:
            return os.path.abspath(self.project_root_override)
        return self._get_script_dir()

    def _build_init_command(
        self,
        *,
        include_user: bool,
        include_project: bool,
        suggested_project_name: str | None = None,
    ) -> str:
        project_root = self._default_project_root() if include_project else None
        project_name = None
        if include_project:
            project_name = (
                self.project_name_override
                or suggested_project_name
                or suggest_project_name_for_root(project_root or os.getcwd())
            )

        return _format_init_command(
            user_name=(self.user_name or "<full-name>") if include_user else None,
            user_email=(self.user_email or "<email>") if include_user else None,
            project_root=project_root,
            project_name=project_name,
            project_description=self.project_description_override if include_project else None,
        )

    def _require_setup(
        self,
        message: str,
        *,
        include_user: bool,
        include_project: bool,
        suggested_project_name: str | None = None,
    ) -> None:
        command = self._build_init_command(
            include_user=include_user,
            include_project=include_project,
            suggested_project_name=suggested_project_name,
        )
        raise SetupRequiredError(f"{message}\nRun `{command}` and retry.")

    def _validate_project_root_override(self, script_dir: str) -> None:
        if not self.project_root_override:
            return

        project_root = os.path.abspath(self.project_root_override)
        try:
            contains_script = os.path.commonpath([project_root, script_dir]) == project_root
        except ValueError:
            contains_script = False

        if not contains_script:
            raise SetupRequiredError(
                f"--project-root must contain the script or module working directory.\n"
                f"Project root: {project_root}\n"
                f"Script directory: {script_dir}"
            )

    def _signal_handler(self, signum, frame) -> None:
        """Handle termination signals gracefully."""
        self._signal_count += 1
        if self._signal_count > 1:
            os._exit(130)
        logger.info(f"Received signal {signum}, shutting down...")
        self.shutdown_flag = True
        self._send_deregister(timeout=0.5)
        clear_run_timer(self.run_id)
        raise SystemExit(130)

    def _send_deregister(self, timeout: float | None = None) -> None:
        """Send deregistration message to the server."""
        if self.run_id and not self._deregister_sent:
            try:
                http_post("/runner/deregister", {"run_id": self.run_id}, timeout=timeout)
                self._deregister_sent = True
            except Exception as e:
                _log_error("Failed to send deregister", e)

    def _listen_for_server_events(self) -> None:
        """Background thread: listen for SSE events from the server."""
        import httpx

        url = f"{self.server_url}/runner/events/{self.run_id}"
        try:
            with httpx.stream("GET", url, timeout=None) as resp:
                for line in resp.iter_lines():
                    if self.shutdown_flag:
                        break
                    if not line or line.startswith(":"):
                        continue  # keepalive or comment
                    if line.startswith("data: "):
                        try:
                            event = json.loads(line[6:])
                            self._handle_server_event(event)
                        except json.JSONDecodeError:
                            continue
        except Exception as e:
            if not self.shutdown_flag:
                _log_error("SSE connection lost", e)

    def _handle_server_event(self, event: dict) -> None:
        """Handle incoming server events."""
        event_type = event.get("type")
        if event_type == "restart":
            logger.info("[AgentRunner] Received restart event")
            self.restart_event.set()
        elif event_type == "shutdown":
            logger.info("[AgentRunner] Received shutdown event")
            self.shutdown_flag = True

    def _is_debugpy_session(self) -> bool:
        """Detect if we're running under debugpy (VSCode debugging)."""
        if os.environ.get("SOVARA_NO_DEBUG_MODE", False):
            return False
        if "debugpy" not in sys.modules:
            return False
        try:
            import debugpy

            return debugpy.is_client_connected() or hasattr(debugpy, "_client")
        except (ImportError, AttributeError):
            return True

    def _get_parent_cmdline(self) -> List[str]:
        """Get the command line of the parent process."""
        try:
            current_process = psutil.Process()
            parent = current_process.parent()
            return parent.cmdline() if parent else []
        except Exception as e:
            _log_error("Failed to get parent cmdline", e)
            return []

    def _generate_restart_command(self) -> str:
        """Generate the appropriate command for restarting the script."""
        original_command = " ".join(shlex.quote(arg) for arg in sys.argv)
        python_executable = sys.executable
        interpreter_flags = "-u " if self.unbuffered else ""

        if not self._is_debugpy_session():
            return f"{python_executable} {original_command}"
        parent_cmdline = self._get_parent_cmdline()

        if not parent_cmdline:
            return f"/usr/bin/env {python_executable} {original_command}"

        cmdline_str = " ".join(shlex.quote(arg) for arg in parent_cmdline)

        if "launcher" in cmdline_str and "--" in parent_cmdline:
            dash_index = parent_cmdline.index("--")
            original_args = " ".join(shlex.quote(arg) for arg in parent_cmdline[dash_index + 1 :])
            return f"/usr/bin/env {python_executable} {interpreter_flags}{original_args}".strip()

        if "-m" in parent_cmdline and "debugpy" in parent_cmdline:
            if self.is_module_execution:
                target_args = f"-m {self.script_path} {' '.join(shlex.quote(arg) for arg in self.script_args)}"
            else:
                target_args = f"{shlex.quote(self.script_path)} {' '.join(shlex.quote(arg) for arg in self.script_args)}"
            return f"{python_executable} {interpreter_flags}{target_args}".strip()

        if self.is_module_execution:
            target_args = (
                f"-m {self.script_path} {' '.join(shlex.quote(arg) for arg in self.script_args)}"
            )
        else:
            target_args = f"{shlex.quote(self.script_path)} {' '.join(shlex.quote(arg) for arg in self.script_args)}"
        return f"{python_executable} {interpreter_flags}{target_args}".strip()

    def _apply_python_runtime_flags(self) -> None:
        """Apply interpreter-like runtime flags that matter for in-process execution."""
        if not self.unbuffered:
            return

        os.environ["PYTHONUNBUFFERED"] = "1"
        for stream_name in ("stdout", "stderr"):
            stream = getattr(sys, stream_name, None)
            reconfigure = getattr(stream, "reconfigure", None)
            if not callable(reconfigure):
                continue
            try:
                reconfigure(line_buffering=True, write_through=True)
            except ValueError:
                logger.debug(f"Could not reconfigure sys.{stream_name} for unbuffered mode")

    def _register_with_server(self) -> None:
        """Register with the server via HTTP POST."""
        logger.info(f"[AgentRunner] Registering with server at {self.server_url}...")
        prev_run_id = os.getenv("SOVARA_RUN_ID") if os.getenv(_REUSE_RUN_ID_ENV) == "1" else None

        response = http_post(
            "/runner/register",
            {
                "name": self.run_name,
                "cwd": os.getcwd(),
                "environment": dict(os.environ),
                "prev_run_id": prev_run_id,
                "project_id": self.project_id,
                "project_name": self.project_name,
                "project_description": self.project_description,
                "project_root": self.project_root,
                "user_id": self.user_id,
                "user_full_name": self.user_full_name,
                "user_email": self.user_email,
            },
        )

        self.run_id = response.get("run_id")
        if not self.run_id:
            raise RuntimeError(f"Registration failed: {response}")
        logger.info(f"Registered with run_id: {self.run_id}")

        # Write run info to file for so-cli IPC
        run_file = os.environ.get("SOVARA_RUN_FILE")
        if run_file:
            try:
                with open(run_file, "w") as f:
                    json.dump({"run_id": self.run_id, "pid": self.process_id}, f)
            except Exception as e:
                logger.warning(f"Failed to write run file: {e}")

    def _setup_environment(self) -> None:
        """Set up the execution environment for the agent runner."""
        if os.environ.get("_SOVARA_TESTING"):
            from sovara.common.constants import TEST_USER_ID, TEST_PROJECT_ID

            self.user_id = TEST_USER_ID
            self.user_full_name = "Test User"
            self.user_email = "test@test.com"
            self.project_id = TEST_PROJECT_ID
            self.project_name = "sovara-test"
            self.project_description = ""
            self.project_root = os.getcwd()
        else:
            user_config = self._resolve_user_config()
            self.user_id = user_config["user_id"]
            self.user_full_name = user_config["full_name"]
            self.user_email = user_config["email"]

            project_config = self._resolve_project_config()
            self.project_id = project_config["project"]["project_id"]
            self.project_name = project_config["project"]["name"]
            self.project_description = project_config["project"].get("description", "")
            self.project_root = project_config["project_root"]

        # Set random seed for reproducibility
        if not os.environ.get("SOVARA_SEED"):
            os.environ["SOVARA_SEED"] = str(random.randint(0, 2**31 - 1))

    def _resolve_user_config(self) -> dict:
        user_config = runtime_client.get_active_user()
        full_name = (
            self.user_name
            if self.user_name is not None
            else (user_config["full_name"] if user_config is not None else None)
        )
        email = (
            self.user_email
            if self.user_email is not None
            else (user_config["email"] if user_config is not None else None)
        )

        if user_config is not None and self.user_name is None and self.user_email is None:
            return user_config

        if full_name and email:
            return runtime_client.setup_user(full_name, email)

        if self._can_prompt():
            if user_config is None:
                print(WELCOME_ART)
                print("Welcome to Sovara! Let's set up your identity.\n")
            if not full_name:
                full_name = _ask_field("Full name\n> ", str)
            if not email:
                email = _ask_field("Email\n> ", str)
            return runtime_client.setup_user(full_name, email)

        self._require_setup(
            "Sovara user setup is missing and this session cannot prompt for it.",
            include_user=True,
            include_project=False,
        )

    def _resolve_project_config(self) -> dict:
        script_dir = self._get_script_dir()
        self._validate_project_root_override(script_dir)

        project_target = self._default_project_root()
        project_config = runtime_client.resolve_project_location(project_target)
        if project_config.get("status") != "missing":
            if self.project_name_override is None and self.project_description_override is None:
                return project_config

            existing_project = project_config["project"]
            updated_name = (
                normalize_project_name(self.project_name_override)
                if self.project_name_override is not None
                else existing_project["name"]
            )
            updated_description = (
                self.project_description_override.strip()
                if self.project_description_override is not None
                else existing_project.get("description", "")
            )
            updated_project = runtime_client.update_project(
                existing_project["project_id"],
                updated_name,
                updated_description,
            )
            return {
                "project": updated_project,
                "project_root": project_config["project_root"],
            }

        default_name = str(
            self.project_name_override
            or project_config.get("suggested_name")
            or suggest_project_name_for_root(project_target)
        )
        if self.project_name_override is not None:
            project_name = normalize_project_name(self.project_name_override)
        elif self._can_prompt():
            print(f"Project name (default: {default_name})")
            project_name = _ask_field(
                "> ",
                normalize_project_name,
                default=default_name,
                error_message="Project name is required.",
            )
        else:
            self._require_setup(
                "Sovara project setup is missing and this session cannot prompt for it.",
                include_user=False,
                include_project=True,
                suggested_project_name=default_name,
            )

        project_description = (self.project_description_override or "").strip()
        created = runtime_client.create_project(
            location=project_config["location"],
            name=project_name,
            description=project_description,
        )
        return {
            "project": {
                "project_id": created["project_id"],
                "name": created["name"],
                "description": project_description,
            },
            "project_root": project_config["location"],
        }

    def _apply_runtime_setup(self) -> None:
        """Apply runtime setup for execution environment."""
        set_parent_run_id(self.run_id)
        apply_all_monkey_patches()

    def _convert_file_to_module_name(self, script_path: str) -> str:
        abs_path = os.path.abspath(script_path)
        return os.path.splitext(os.path.basename(abs_path))[0]

    def _execute_user_code(self) -> int:
        """Execute the user's code directly in this process."""
        try:
            script_dir = self._get_script_dir()
            if script_dir not in sys.path:
                sys.path.insert(0, script_dir)

            if self.is_module_execution:
                sys.argv = [self.script_path] + self.script_args
                runpy.run_module(self.script_path, run_name="__main__")
            else:
                module_name = self._convert_file_to_module_name(self.script_path)
                sys.argv = [self.script_path] + self.script_args
                runpy.run_module(module_name, run_name="__main__")
            return 0
        except SystemExit as e:
            return e.code if e.code is not None else 0
        except Exception as exc:
            sys.stderr.write(_format_exception_for_user(exc))
            return 1

    def _append_run_log(self, log_chunk: str) -> None:
        if not self.run_id or not log_chunk:
            return
        http_post(
            "/runner/update-log",
            {
                "run_id": self.run_id,
                "log_text": log_chunk,
                "replace": False,
            },
            timeout=2.0,
        )

    def _run_user_code_with_output_capture(self) -> int:
        if not self.run_id:
            return self._execute_user_code()
        with RunLogCapture(
            append_callback=self._append_run_log,
        ):
            return self._execute_user_code()

    def _run_debug_mode(self) -> int:
        """Run in debug mode with persistent restart loop."""
        logger.info("[AgentRunner] Debug mode detected. Running with restart capability.")
        exit_code = 0
        first_run = True

        while not self.shutdown_flag:
            if first_run:
                self._apply_runtime_setup()
                first_run = False

            exit_code = self._run_user_code_with_output_capture()
            logger.info(f"[AgentRunner] Script completed with exit code {exit_code}. Waiting...")

            while not self.shutdown_flag and not self.restart_event.is_set():
                time.sleep(MESSAGE_POLL_INTERVAL)

            if self.shutdown_flag:
                break
            if self.restart_event.is_set():
                logger.info("[AgentRunner] Restart requested, rerunning script...")
                self.restart_event.clear()
                reset_current_run_timer()

        return exit_code

    def _run_normal_mode(self) -> int:
        """Run in normal mode (single execution)."""
        self._apply_runtime_setup()
        return self._run_user_code_with_output_capture()

    def run(self) -> None:
        """Main entry point."""
        exit_code = 1
        try:
            self._apply_python_runtime_flags()
            ensure_server_running()

            # Set server URL for HTTP communication
            self.server_url = f"http://{HOST}:{PORT}"
            set_server_url(self.server_url)

            self._setup_environment()

            self._register_with_server()

            # Start SSE listener for server events (restart, shutdown)
            self.listener_thread = threading.Thread(
                target=self._listen_for_server_events, daemon=True
            )
            self.listener_thread.start()

            # Send restart command asynchronously
            def send_restart_command():
                try:
                    cmd = self._restart_command_future.result()
                    http_post(
                        "/runner/update-command",
                        {
                            "run_id": self.run_id,
                            "command": cmd,
                        },
                    )
                except Exception as e:
                    _log_error("Failed to send restart command", e)

            threading.Thread(target=send_restart_command, daemon=True).start()

            if self._is_debugpy_session():
                exit_code = self._run_debug_mode()
            else:
                exit_code = self._run_normal_mode()

        except SetupRequiredError as exc:
            sys.stderr.write(f"{exc}\n")
            sys.stderr.flush()
        except Exception as exc:
            sys.stderr.write(_format_exception_for_user(exc))
            sys.stderr.flush()

        finally:
            self._send_deregister(timeout=0.5 if self.shutdown_flag else None)
            clear_run_timer(self.run_id)
            self.shutdown_flag = True
            if self.listener_thread:
                self.listener_thread.join(timeout=2)

        sys.exit(exit_code)
