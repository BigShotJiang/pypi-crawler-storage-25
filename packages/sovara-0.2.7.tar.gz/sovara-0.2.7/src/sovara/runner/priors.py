"""Runtime priors helpers and the legacy manual priors injection API."""

from contextlib import contextmanager
from dataclasses import dataclass, field
import io
import json
import time
import urllib.error
import urllib.request
from typing import Any, Callable, Iterator, List, Optional

from sovara.common.priors_block import render_priors_block
from sovara.common.constants import (
    INTERNAL_PRIORS_TIMEOUT_MS as SHARED_INTERNAL_PRIORS_TIMEOUT_MS,
    PRIORS_SERVER_URL,
)
from sovara.common.logger import logger
from sovara.common.utils import http_post
from sovara.runner.context_manager import get_run_id, warn_if_inactive_run
from sovara.runner.monkey_patching.api_parser import (
    flatten_complete_to_show,
    func_kwargs_to_json_str,
    json_str_to_original_inp_dict,
    replace_to_show_in_input_dict,
    restore_complete_to_show_from_flattened,
)
from sovara.runner.priors_pipeline import (
    detect_manual_priors_reason,
    extract_content_bearing_pairs,
    extract_prompt_bearing_pairs,
    inject_priors_block,
    replay_injected_prefix,
    render_retrieval_context,
    strip_priors_from_flattened,
)
from sovara.runner.runtime_client import runtime_client

_INTERNAL_PRIORS_TIMEOUT_MS = SHARED_INTERNAL_PRIORS_TIMEOUT_MS
_INTERNAL_PRIORS_HTTP_TIMEOUT_S = (_INTERNAL_PRIORS_TIMEOUT_MS / 1000.0) + 5.0
_INTERNAL_PREFIX_CACHE_TIMEOUT_MS = 10000
_INTERNAL_PREFIX_CACHE_HTTP_TIMEOUT_S = (_INTERNAL_PREFIX_CACHE_TIMEOUT_MS / 1000.0) + 5.0


@dataclass(slots=True)
class PriorRuntimeMetadata:
    """Priors-sidecar metadata for one prepared LLM call.

    `status` is a coarse runtime/debug label for the preparation outcome.
    `injection_anchor` is the prompt-bearing key where newly retrieved priors
    would be injected for this node's suffix, if any.
    `warning_message` captures non-fatal cleanup/strip warnings.
    `raw_context` is the rendered prefix/suffix context sent to the retriever.
    `processed_context` is the retrieval-focused context after server preprocessing.
    `inherited_prior_ids` are priors recovered from stripped manual blocks or
    prefix-cache replay.
    `retrieved_priors` are only the priors freshly retrieved for this node.
    `applied_priors` are the full effective prior set for this node after
    inheritance and retrieval.
    `rendered_priors_block` is the exact block injected for the fresh priors.
    `model` is the retriever model actually used.
    `latency_tier` is the project-configured priors retrieval tier.
    `timeout_ms` is the fixed internal priors-route timeout.
    `retrieval_latency_ms` is populated only when a retrieval request is made.
    `error_message` captures fatal retrieval/preparation failures.
    """

    status: str
    injection_anchor: dict[str, Any] | None
    warning_message: str | None
    retrieval_id: str | None = None
    raw_context: str = ""
    processed_context: str = ""
    inherited_prior_ids: list[str] = field(default_factory=list)
    retrieved_priors: list[dict[str, Any]] = field(default_factory=list)
    applied_priors: list[dict[str, Any]] = field(default_factory=list)
    rendered_priors_block: str = ""
    model: str | None = None
    latency_tier: str | None = None
    timeout_ms: int = field(default=_INTERNAL_PRIORS_TIMEOUT_MS, init=False)
    retrieval_latency_ms: int | None = None
    prior_coverage: int | None = None
    retrieval_status: str = "pending"
    coverage_status: str = "not_requested"
    error_message: str | None = None


@dataclass(slots=True)
class PriorPreparationResult:
    """Prepared priors artifacts returned to a transport patch.

    `executed_input_dict` is the final outbound payload that should be sent to
    the provider after stripping, replaying, and injecting priors.
    `prompt_suffix_json` is the JSON-serialized unmatched prompt-bearing suffix
    for this node, which is stored for observability on the captured LLM call.
    `metadata` is the priors retrieval/replay sidecar persisted separately.
    `restore_original_input` reverts any in-place transport mutations after the
    patch has finished sending/caching/recording the call.
    """

    executed_input_dict: dict[str, Any]
    prompt_suffix_json: str
    metadata: PriorRuntimeMetadata
    restore_original_input: Callable[[], None] | None = None


def build_prior_metadata_persistence_payload(metadata: PriorRuntimeMetadata) -> dict[str, Any]:
    return {
        "retrieval_id": metadata.retrieval_id,
        "raw_context": str(metadata.raw_context or ""),
        "processed_context": str(metadata.processed_context or ""),
        "inherited_prior_ids": list(metadata.inherited_prior_ids),
        "retrieved_priors": list(metadata.retrieved_priors),
        "applied_priors": list(metadata.applied_priors),
        "rendered_priors_block": str(metadata.rendered_priors_block or ""),
        "injection_anchor": metadata.injection_anchor,
        "model": metadata.model,
        "latency_tier": metadata.latency_tier,
        "timeout_ms": metadata.timeout_ms,
        "retrieval_latency_ms": metadata.retrieval_latency_ms,
        "prior_coverage": metadata.prior_coverage,
        "retrieval_status": metadata.retrieval_status,
        "coverage_status": metadata.coverage_status,
        "warning_message": metadata.warning_message,
        "error_message": metadata.error_message,
    }


def _log_priors(source: str, level: str, message: str, **details: Any) -> None:
    log_method = getattr(logger, level)
    log_method(
        "%s | %s",
        message,
        json.dumps({"source": source, **details}, sort_keys=True, ensure_ascii=False),
    )


def _httpx_response_detail(exc: Any) -> str | None:
    response = getattr(exc, "response", None)
    if response is None:
        return None
    try:
        payload = response.json()
    except Exception:
        text = getattr(response, "text", None)
        if isinstance(text, str) and text.strip():
            return text.strip()
        return None
    if isinstance(payload, dict):
        detail = payload.get("detail")
        if detail is not None:
            try:
                return json.dumps(detail, sort_keys=True, ensure_ascii=False)
            except Exception:
                return str(detail)
    try:
        return json.dumps(payload, sort_keys=True, ensure_ascii=False)
    except Exception:
        return str(payload)


def _unique_prior_ids(prior_ids: list[str]) -> list[str]:
    # Preserve first-seen order so replayed/inherited priors stay stable.
    ordered_unique: list[str] = []
    for prior_id in prior_ids:
        if prior_id and prior_id not in ordered_unique:
            ordered_unique.append(prior_id)
    return ordered_unique


def _lookup_longest_prefix_cache_hit(
    run_id: str,
    clean_pairs: list[dict[str, str]],
) -> tuple[dict[str, Any] | None, int]:
    if not run_id or not clean_pairs:
        return None, 0
    try:
        response = http_post(
            "/internal/priors/prefix-cache/lookup",
            {
                "run_id": run_id,
                "clean_pairs": clean_pairs,
            },
            timeout=_INTERNAL_PREFIX_CACHE_HTTP_TIMEOUT_S,
        )
    except Exception as exc:
        _log_priors("automatic", "warning", "[PRIORS RUNTIME] prefix lookup failed", error=str(exc))
        return None, 0

    if not response.get("found"):
        return None, 0
    matched_pair_count = int(response.get("matched_pair_count") or 0)
    if matched_pair_count <= 0:
        return None, 0
    return response, matched_pair_count


def _store_prefix_cache_entry(
    run_id: str | None,
    clean_pairs: list[dict[str, str]],
    injected_pairs: list[dict[str, str]],
    prior_ids: list[str],
) -> None:
    if not run_id or not clean_pairs:
        return
    try:
        http_post(
            "/internal/priors/prefix-cache/store",
            {
                "run_id": run_id,
                "clean_pairs": clean_pairs,
                "injected_pairs": injected_pairs,
                "prior_ids": prior_ids,
            },
            timeout=_INTERNAL_PREFIX_CACHE_HTTP_TIMEOUT_S,
        )
    except Exception as exc:
        _log_priors("automatic", "warning", "[PRIORS RUNTIME] prefix store failed", error=str(exc))


def _append_message(existing: str | None, new_message: str | None) -> str | None:
    if not new_message:
        return existing
    if not existing:
        return new_message
    return f"{existing}\n{new_message}"


@contextmanager
def restore_input_after_call(prior_result: PriorPreparationResult | None) -> Iterator[None]:
    """Restore the original transport input after a patched provider call finishes."""
    try:
        yield
    finally:
        restore = getattr(prior_result, "restore_original_input", None)
        if restore is not None:
            try:
                restore()
            except Exception:
                logger.exception("Failed to restore original input after patched call")


def prepare_llm_call_for_priors(
    input_dict: dict[str, Any],
    api_type: str,
    *,
    lookup_prefix_cache_func: (
        Callable[[str, list[dict[str, str]]], tuple[dict[str, Any] | None, int]] | None
    ) = None,
    store_prefix_cache_func: (
        Callable[[str | None, list[dict[str, str]], list[dict[str, str]], list[str]], None] | None
    ) = None,
    retrieve_priors_func: Callable[[str, str, list[str]], dict[str, Any]] | None = None,
) -> PriorPreparationResult:
    run_id = get_run_id()
    complete_json_str = func_kwargs_to_json_str(input_dict, api_type)
    complete_input = json.loads(complete_json_str)
    flattened_to_show = flatten_complete_to_show(complete_input.get("to_show"))

    def _restore_original_input() -> None:
        json_str_to_original_inp_dict(complete_json_str, input_dict, api_type)

    def _materialize_input(final_flattened_to_show: dict[str, Any]) -> dict[str, Any]:
        return replace_to_show_in_input_dict(
            input_dict,
            api_type,
            restore_complete_to_show_from_flattened(final_flattened_to_show),
        )

    manual_priors_reason = detect_manual_priors_reason(flattened_to_show)
    if manual_priors_reason is not None:
        metadata = PriorRuntimeMetadata(
            status="manual",
            raw_context="",
            inherited_prior_ids=[],
            injection_anchor=None,
            warning_message=manual_priors_reason,
        )
        return PriorPreparationResult(
            executed_input_dict=input_dict,
            prompt_suffix_json="[]",
            metadata=metadata,
            restore_original_input=_restore_original_input,
        )

    cleaned_flattened, inherited_prior_ids, warnings = strip_priors_from_flattened(
        flattened_to_show
    )
    clean_content_pairs = extract_content_bearing_pairs(cleaned_flattened, api_type)
    clean_prompt_pairs = extract_prompt_bearing_pairs(cleaned_flattened, api_type)

    prefix_entry = None
    matched_prefix_len = 0
    working_flattened = dict(cleaned_flattened)
    if run_id and clean_content_pairs:
        if lookup_prefix_cache_func is not None:
            try:
                prefix_entry, matched_prefix_len = lookup_prefix_cache_func(
                    run_id, clean_content_pairs
                )
            except Exception as exc:
                _log_priors(
                    "automatic",
                    "warning",
                    "[PRIORS RUNTIME] prefix lookup failed",
                    error=str(exc),
                )
                prefix_entry, matched_prefix_len = None, 0
        else:
            prefix_entry, matched_prefix_len = _lookup_longest_prefix_cache_hit(
                run_id, clean_content_pairs
            )
        if prefix_entry is not None:
            working_flattened = replay_injected_prefix(
                cleaned_flattened,
                list(prefix_entry.get("injected_pairs") or []),
            )
            inherited_prior_ids = _unique_prior_ids(
                inherited_prior_ids + list(prefix_entry.get("prior_ids") or [])
            )

    prefix_pairs = clean_content_pairs[:matched_prefix_len]
    suffix_pairs = clean_content_pairs[matched_prefix_len:]
    prefix_keys = [pair["key"] for pair in prefix_pairs]
    suffix_keys = [pair["key"] for pair in suffix_pairs]
    suffix_key_set = set(suffix_keys)
    prompt_suffix_pairs = [pair for pair in clean_prompt_pairs if pair["key"] in suffix_key_set]
    prompt_suffix_json = json.dumps(prompt_suffix_pairs, sort_keys=True)
    raw_context = render_retrieval_context(cleaned_flattened, prefix_keys, suffix_keys)
    injection_anchor_key = next((pair["key"] for pair in prompt_suffix_pairs), None)
    if injection_anchor_key is None and clean_prompt_pairs:
        injection_anchor_key = clean_prompt_pairs[0]["key"]

    metadata = PriorRuntimeMetadata(
        status="pending",
        raw_context=raw_context,
        inherited_prior_ids=inherited_prior_ids,
        applied_priors=[{"id": prior_id} for prior_id in inherited_prior_ids],
        injection_anchor={"key": injection_anchor_key} if injection_anchor_key else None,
        warning_message="\n".join(warnings) if warnings else None,
    )

    def _build_result(final_flattened: dict[str, Any]) -> PriorPreparationResult:
        return PriorPreparationResult(
            executed_input_dict=_materialize_input(final_flattened),
            prompt_suffix_json=prompt_suffix_json,
            metadata=metadata,
            restore_original_input=_restore_original_input,
        )

    if not clean_prompt_pairs:
        metadata.status = "uninjectable"
        metadata.warning_message = _append_message(
            metadata.warning_message,
            "No prompt-bearing fields found for priors injection.",
        )
        return _build_result(working_flattened)

    executed_flattened = dict(working_flattened)

    if not suffix_pairs:
        metadata.status = "none"
        metadata.retrieval_status = "complete"
        # A full prefix-cache hit skips retrieval, but groundedness still needs
        # the current LLM step input. Treat the full clean input as latest
        # context instead of persisting an empty suffix.
        metadata.raw_context = render_retrieval_context(
            cleaned_flattened,
            [],
            [pair["key"] for pair in clean_content_pairs],
        )
        return _build_result(executed_flattened)

    if not raw_context.strip():
        metadata.status = "empty_context"
        return _build_result(executed_flattened)

    if not run_id:
        metadata.status = "unavailable"
        metadata.error_message = "No active run id available for priors retrieval."
        _log_priors(
            "automatic",
            "warning",
            "[PRIORS RUNTIME] retrieval unavailable",
            error=metadata.error_message,
        )
        return _build_result(executed_flattened)

    import httpx

    def _mark_retrieval_failure(
        status: str,
        exc: Exception,
        *,
        level: str,
        message: str,
        **details: Any,
    ) -> None:
        metadata.status = status
        metadata.retrieval_status = "failed"
        metadata.coverage_status = "failed"
        metadata.error_message = str(exc)
        _log_priors("automatic", level, message, error=metadata.error_message, **details)

    try:
        started_at = time.perf_counter()
        _log_priors(
            "automatic",
            "info",
            "[PRIORS RUNTIME] retrieving via internal route",
            run_id=run_id,
            ignore_ids=inherited_prior_ids,
        )
        response = (
            http_post(
                "/internal/priors/retrieve",
                {
                    "run_id": run_id,
                    "raw_context": raw_context,
                    "ignore_prior_ids": inherited_prior_ids,
                },
                timeout=_INTERNAL_PRIORS_HTTP_TIMEOUT_S,
            )
            if retrieve_priors_func is None
            else retrieve_priors_func(
                run_id,
                raw_context,
                inherited_prior_ids,
            )
        )
        metadata.retrieval_latency_ms = int((time.perf_counter() - started_at) * 1000)
        metadata.retrieval_id = response.get("retrieval_id")
        metadata.processed_context = str(response.get("processed_context") or "")
        metadata.retrieved_priors = list(response.get("priors") or [])
        metadata.applied_priors = list(response.get("applied_priors") or [])
        metadata.rendered_priors_block = str(response.get("rendered_priors_block") or "")
        metadata.model = response.get("model_used")
        metadata.latency_tier = response.get("latency_tier")
        metadata.prior_coverage = response.get("prior_coverage")
        metadata.retrieval_status = str(response.get("retrieval_status") or "complete")
        metadata.coverage_status = str(response.get("coverage_status") or "not_requested")
        metadata.status = "applied" if metadata.retrieved_priors else "none"
        _log_priors(
            "automatic",
            "info",
            "[PRIORS RUNTIME] retrieval complete",
            status=metadata.status,
            latency_ms=metadata.retrieval_latency_ms,
            applied_ids=[prior.get("id") for prior in metadata.retrieved_priors],
            model=metadata.model,
        )
        if metadata.rendered_priors_block:
            executed_flattened = inject_priors_block(
                executed_flattened,
                metadata.rendered_priors_block,
                metadata.injection_anchor or {"key": clean_prompt_pairs[0]["key"]},
            )
        effective_prior_ids = _unique_prior_ids(
            [
                str(prior.get("id"))
                for prior in metadata.applied_priors
                if isinstance(prior.get("id"), str) and prior.get("id")
            ]
        )
        injected_pairs = extract_content_bearing_pairs(executed_flattened, api_type)
        if store_prefix_cache_func is not None:
            try:
                store_prefix_cache_func(
                    run_id,
                    clean_content_pairs,
                    injected_pairs,
                    effective_prior_ids,
                )
            except Exception as exc:
                _log_priors(
                    "automatic",
                    "warning",
                    "[PRIORS RUNTIME] prefix store failed",
                    error=str(exc),
                )
        else:
            _store_prefix_cache_entry(
                run_id,
                clean_content_pairs,
                injected_pairs,
                effective_prior_ids,
            )
        return _build_result(executed_flattened)
    except httpx.TimeoutException as exc:
        _mark_retrieval_failure(
            "timeout",
            exc,
            level="warning",
            message="[PRIORS RUNTIME] retrieval timeout",
        )
    except httpx.RequestError as exc:
        _mark_retrieval_failure(
            "unavailable",
            exc,
            level="warning",
            message="[PRIORS RUNTIME] retrieval unavailable",
        )
    except httpx.HTTPStatusError as exc:
        status_code = exc.response.status_code if exc.response is not None else None
        response_detail = _httpx_response_detail(exc)
        _mark_retrieval_failure(
            "unavailable" if status_code in {502, 503, 504} else "error",
            exc,
            level="warning",
            message="[PRIORS RUNTIME] retrieval http error",
            status_code=status_code,
            detail=response_detail,
        )
    except Exception as exc:
        _mark_retrieval_failure(
            "error",
            exc,
            level="error",
            message="[PRIORS RUNTIME] retrieval failed unexpectedly",
        )

    return _build_result(executed_flattened)


def persist_prior_metadata(run_id: str, node_uuid: str, metadata: PriorRuntimeMetadata) -> None:
    payload = build_prior_metadata_persistence_payload(metadata)
    runtime_client.upsert_prior_retrieval(
        run_id,
        node_uuid,
        retrieval_id=payload["retrieval_id"],
        raw_context=payload["raw_context"],
        processed_context=payload["processed_context"],
        inherited_prior_ids=payload["inherited_prior_ids"],
        retrieved_priors=payload["retrieved_priors"],
        applied_priors=payload["applied_priors"],
        rendered_priors_block=payload["rendered_priors_block"],
        injection_anchor=payload["injection_anchor"],
        model=payload["model"],
        latency_tier=payload["latency_tier"] or "MEDIUM",
        timeout_ms=payload["timeout_ms"],
        retrieval_latency_ms=payload["retrieval_latency_ms"],
        prior_coverage=payload["prior_coverage"],
        retrieval_status=payload["retrieval_status"],
        coverage_status=payload["coverage_status"],
        warning_message=payload["warning_message"],
        error_message=payload["error_message"],
    )
    for prior in payload["applied_priors"]:
        prior_id = prior.get("id")
        if isinstance(prior_id, str) and prior_id:
            runtime_client.add_prior_applied(prior_id, run_id, node_uuid)


def schedule_prior_coverage(
    run_id: str, node_uuid: str, metadata: PriorRuntimeMetadata | None = None
) -> None:
    if not run_id or not node_uuid:
        return
    if metadata is not None:
        if getattr(metadata, "retrieval_status", None) == "failed":
            return
        if getattr(metadata, "error_message", None):
            return
        if not str(getattr(metadata, "raw_context", "") or "").strip():
            return
        has_retrieval = bool(getattr(metadata, "retrieval_id", None))
        has_applied_priors = bool(getattr(metadata, "applied_priors", None)) or bool(
            getattr(metadata, "inherited_prior_ids", None)
        )
        if not has_retrieval and not has_applied_priors:
            return
    try:
        runtime_client.schedule_prior_coverage(run_id, node_uuid)
    except Exception as exc:
        _log_priors(
            "automatic",
            "warning",
            "[PRIORS RUNTIME] coverage scheduling failed",
            run_id=run_id,
            node_uuid=node_uuid,
            error=str(exc),
        )


def _call_priors_route(
    *,
    internal_endpoint: str,
    internal_payload: dict[str, Any],
    public_endpoint: str,
    public_payload: dict[str, Any],
) -> dict[str, Any]:
    run_id = get_run_id()
    if run_id:
        return http_post(
            internal_endpoint,
            {"run_id": run_id, **internal_payload},
            timeout=_INTERNAL_PRIORS_HTTP_TIMEOUT_S,
        )
    return _priors_request(public_endpoint, public_payload)


def _priors_request(endpoint: str, payload: dict) -> dict:
    """POST to the priors server and return parsed JSON response."""
    url = f"{PRIORS_SERVER_URL}/api/v1{endpoint}"
    data = json.dumps(payload).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    run_id = get_run_id()
    if run_id:
        run = runtime_client.get_run_scope(run_id)
        if run is not None:
            user_id = run.get("user_id")
            project_id = run.get("project_id")
            if user_id:
                headers["x-sovara-user-id"] = str(user_id)
            if project_id:
                headers["x-sovara-project-id"] = str(project_id)

    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=300) as response:
        return json.loads(response.read().decode("utf-8"))


def _query_priors(path: Optional[str] = None) -> tuple[List[dict], str]:
    """Fetch all priors from a path and return both rows and injected context."""
    result = _call_priors_route(
        internal_endpoint="/internal/priors/query",
        internal_payload={"path": path},
        public_endpoint="/query/priors",
        public_payload={} if path is None else {"path": path},
    )
    return result.get("priors", []), result.get("injected_context", "")


def _retrieve_priors(path: Optional[str], context: str) -> List[dict]:
    """Retrieve relevant priors via the LLM-backed retriever."""
    result = _call_priors_route(
        internal_endpoint="/internal/priors/retrieve",
        internal_payload={
            "context": context,
            "base_path": path,
            "ignore_prior_ids": [],
        },
        public_endpoint="/priors/retrieve",
        public_payload={"context": context, **({"base_path": path} if path is not None else {})},
    )
    return result.get("priors", [])


def _stringify_context(context: Any) -> str:
    if isinstance(context, str):
        return context
    try:
        return json.dumps(context, indent=2, ensure_ascii=False)
    except TypeError:
        return str(context)


def _track_priors(prior_ids: List[str]) -> None:
    """Track which priors were applied to the current run."""
    run_id = get_run_id()
    if not run_id:
        return
    try:
        for prior_id in prior_ids:
            runtime_client.add_prior_applied(prior_id, run_id)
        logger.debug("Tracked %d priors applied to run %s", len(prior_ids), run_id[:8])
    except Exception as exc:
        logger.debug("Could not track prior application: %s", exc)


def _http_error_detail(exc: urllib.error.HTTPError) -> str | None:
    if exc.fp is None:
        return None
    raw: bytes | None = None
    try:
        raw = exc.fp.read()
    except Exception:
        return None
    finally:
        try:
            exc.fp = io.BytesIO(raw if isinstance(raw, bytes) else b"")
        except Exception:
            pass

    if not isinstance(raw, bytes) or not raw:
        return None
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        text = raw.decode("utf-8", errors="ignore").strip()
        return text or None

    if isinstance(payload, dict):
        detail = payload.get("detail") or payload.get("error")
        if isinstance(detail, str) and detail.strip():
            return detail.strip()
    return None


def inject_priors(
    path: Optional[str] = None,
    context: Any = None,
    method: str = "retrieve",
) -> str:
    """
    Retrieve priors from the priors server and return them as injected context.

    Args:
        path: Folder path to retrieve priors from (e.g. 'beaver/retriever/').
        context: Retrieval context. Supports str, dict, list, or other JSON-serializable
            values, which are stringified before retrieval.
        method: "retrieve" (LLM-filtered), "all" (all priors in path), or "none".
    Returns:
        Formatted priors string, or empty string if the priors server is unavailable.

    Raises:
        ValueError: When the requested priors folder path is invalid for the current scope.
        RuntimeError: When the priors request fails with a non-recoverable HTTP error.
    """
    if warn_if_inactive_run("inject_priors()") is None:
        return ""
    path_label = path or "<root>"
    if method == "none":
        return ""

    context_text: str | None = None
    if method == "retrieve":
        if context is None:
            raise ValueError("context is required when method='retrieve'")
        context_text = _stringify_context(context)
    _log_priors(
        "manual",
        "info",
        "[PRIORS MANUAL] fetching",
        path=path_label,
        method=method,
        context_chars=len(context_text) if context_text is not None else 0,
    )

    try:
        if method == "retrieve":
            priors = _retrieve_priors(path, context_text or "")
            injected_context = render_priors_block(priors, manual=True)
        elif method == "all":
            priors, _unused_injected_context = _query_priors(path)
            injected_context = render_priors_block(priors, manual=True)
        else:
            raise ValueError(f"Unknown method: {method}")
    except urllib.error.HTTPError as e:
        detail = _http_error_detail(e) or e.reason
        _log_priors(
            "manual",
            "warning",
            "[PRIORS MANUAL] fetch http error",
            path=path_label,
            method=method,
            status_code=e.code,
            detail=detail,
        )
        if e.code == 404 and path:
            raise ValueError(
                f"inject_priors(path={path!r}, method={method!r}) failed because the prior folder "
                f"{path!r} does not exist in the current SovaraDB project scope. "
                f"Fix the path or create that folder in SovaraDB and retry. "
                f"Backend detail: {detail}"
            ) from e
        raise RuntimeError(
            f"inject_priors(path={path!r}, method={method!r}) failed with HTTP {e.code}: {detail}"
        ) from e
    except (urllib.error.URLError, ConnectionError) as e:
        _log_priors(
            "manual",
            "warning",
            "[PRIORS MANUAL] fetch unavailable",
            path=path_label,
            method=method,
            error=str(e),
        )
        return ""
    except ValueError:
        raise
    except Exception as e:
        _log_priors(
            "manual",
            "warning",
            "[PRIORS MANUAL] fetch failed",
            path=path_label,
            method=method,
            error=str(e),
        )
        return ""

    prior_ids = [prior.get("id") for prior in priors if prior.get("id")]
    if prior_ids:
        _track_priors(prior_ids)
    _log_priors(
        "manual",
        "info",
        "[PRIORS MANUAL] fetch complete",
        path=path_label,
        method=method,
        status="applied" if prior_ids else "none",
        applied_ids=prior_ids,
    )

    return injected_context
