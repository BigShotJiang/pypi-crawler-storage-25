from __future__ import annotations

import io
import logging
import sys
import threading
import time
from contextlib import contextmanager
from typing import Callable, TextIO


AppendLogCallback = Callable[[str], None]


class _ThreadLocalLogFilter(logging.Filter):
    def __init__(self, is_suppressed: Callable[[], bool]) -> None:
        super().__init__()
        self._is_suppressed = is_suppressed

    def filter(self, record: logging.LogRecord) -> bool:
        return not self._is_suppressed()


class _BinaryStreamTee:
    def __init__(
        self,
        original_buffer,
        *,
        capture: "RunLogCapture",
    ) -> None:
        self._original_buffer = original_buffer
        self._capture = capture

    def write(self, data: bytes) -> int:
        written = self._original_buffer.write(data)
        self._capture.record_bytes(data)
        return written

    def flush(self) -> None:
        self._original_buffer.flush()

    def __getattr__(self, name: str):
        return getattr(self._original_buffer, name)


class _TextStreamTee(io.TextIOBase):
    def __init__(
        self,
        original_stream: TextIO,
        *,
        capture: "RunLogCapture",
    ) -> None:
        self._original_stream = original_stream
        self._capture = capture
        original_buffer = getattr(original_stream, "buffer", None)
        self.buffer = (
            _BinaryStreamTee(original_buffer, capture=capture)
            if original_buffer is not None
            else None
        )

    @property
    def encoding(self) -> str:
        return getattr(self._original_stream, "encoding", "utf-8") or "utf-8"

    @property
    def errors(self) -> str | None:
        return getattr(self._original_stream, "errors", None)

    def fileno(self) -> int:
        return self._original_stream.fileno()

    def flush(self) -> None:
        self._original_stream.flush()
        self._capture.flush()

    def isatty(self) -> bool:
        return self._original_stream.isatty()

    def reconfigure(self, *args, **kwargs) -> None:
        reconfigure = getattr(self._original_stream, "reconfigure", None)
        if callable(reconfigure):
            reconfigure(*args, **kwargs)

    def writable(self) -> bool:
        return True

    def write(self, text: str) -> int:
        written = self._original_stream.write(text)
        self._capture.record_text(text)
        return written

    def __getattr__(self, name: str):
        return getattr(self._original_stream, name)


class RunLogCapture:
    def __init__(
        self,
        *,
        append_callback: AppendLogCallback | None = None,
        flush_interval_seconds: float = 0.25,
        stdout_stream: TextIO | None = None,
        stderr_stream: TextIO | None = None,
    ) -> None:
        self.append_callback = append_callback
        self.flush_interval_seconds = max(0.0, flush_interval_seconds)
        self.stdout_stream = stdout_stream
        self.stderr_stream = stderr_stream

        self._pending_lock = threading.Lock()
        self._pending_chunks: list[str] = []
        self._last_flush_at = time.monotonic()
        self._saved_stdout = None
        self._saved_stderr = None
        self._callback_suppression = threading.local()

    def __enter__(self) -> "RunLogCapture":
        self._last_flush_at = time.monotonic()

        self._saved_stdout = sys.stdout
        self._saved_stderr = sys.stderr
        stdout_target = self.stdout_stream or self._saved_stdout
        stderr_target = self.stderr_stream or self._saved_stderr
        sys.stdout = _TextStreamTee(stdout_target, capture=self)
        sys.stderr = _TextStreamTee(stderr_target, capture=self)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        try:
            sys.stdout.flush()
            sys.stderr.flush()
        finally:
            if self._saved_stdout is not None:
                sys.stdout = self._saved_stdout
            if self._saved_stderr is not None:
                sys.stderr = self._saved_stderr
            self.flush(force=True)

    def record_bytes(self, data: bytes) -> None:
        if self._is_callback_suppressed():
            return
        self._queue_text(data.decode("utf-8", errors="replace"))

    def record_text(self, text: str) -> None:
        if not text:
            return
        if self._is_callback_suppressed():
            return
        self._queue_text(text)

    def flush(self, force: bool = False) -> None:
        self._flush_pending(force=force)

    def _queue_text(self, text: str) -> None:
        if not text:
            return
        with self._pending_lock:
            self._pending_chunks.append(text)
        self._flush_pending(force=False)

    def _flush_pending(self, *, force: bool) -> None:
        if self.append_callback is None:
            with self._pending_lock:
                self._pending_chunks.clear()
                self._last_flush_at = time.monotonic()
            return

        with self._pending_lock:
            if not self._pending_chunks:
                return
            now = time.monotonic()
            if not force and (now - self._last_flush_at) < self.flush_interval_seconds:
                return
            chunk = "".join(self._pending_chunks)
            self._pending_chunks.clear()
            self._last_flush_at = now

        try:
            with self._suppress_internal_callback_output():
                self.append_callback(chunk)
        except Exception:
            with self._pending_lock:
                self._pending_chunks.insert(0, chunk)

    def _is_callback_suppressed(self) -> bool:
        return bool(getattr(self._callback_suppression, "active", False))

    @contextmanager
    def _suppress_internal_callback_output(self):
        previous_active = self._is_callback_suppressed()
        self._callback_suppression.active = True

        scoped_filters = [
            (logging.getLogger("httpx"), _ThreadLocalLogFilter(self._is_callback_suppressed)),
            (logging.getLogger("httpcore"), _ThreadLocalLogFilter(self._is_callback_suppressed)),
        ]
        for logger, scoped_filter in scoped_filters:
            logger.addFilter(scoped_filter)
        try:
            yield
        finally:
            for logger, scoped_filter in scoped_filters:
                logger.removeFilter(scoped_filter)
            self._callback_suppression.active = previous_active
