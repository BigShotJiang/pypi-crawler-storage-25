"""Helpers for strip/retrieve/inject over fully flattened ``to_show`` payloads."""

from __future__ import annotations

import json
import re
from typing import Any

_PRIORS_BLOCK_RE = re.compile(r"<sovara-priors\b[^>]*>.*?</sovara-priors>", re.DOTALL | re.IGNORECASE)
_MANIFEST_RE = re.compile(r"<!--\s*(\{.*?\})\s*-->", re.DOTALL)

_PROMPT_BEARING_PATTERNS = [
    re.compile(r"^(?:body\.)?system$"),
    re.compile(r"^(?:body\.)?system\.\d+\.text$"),
    re.compile(r"^(?:body\.)?instructions$"),
    re.compile(r"^(?:body\.)?input$"),
    re.compile(r"^(?:body\.)?input\.\d+\.content$"),
    re.compile(r"^(?:body\.)?messages\.\d+\.content$"),
    re.compile(r"^(?:body\.)?(?:input|messages)\.\d+\.content\.\d+\.text$"),
    re.compile(r"^(?:body\.)?system_instruction\.parts\.\d+\.text$"),
    re.compile(r"^(?:body\.)?systemInstruction\.parts\.\d+\.text$"),
    re.compile(r"^(?:body\.)?contents\.\d+\.parts\.\d+\.text$"),
]
_CONTENT_BEARING_PATTERNS = [
    *_PROMPT_BEARING_PATTERNS,
    re.compile(r"^(?:body\.)?(?:input|messages)\.\d+\.content\.\d+\.image_url\.(?:url|detail)$"),
]
_SYSTEM_PROMPT_BEARING_PATTERNS = [
    pattern for pattern in _PROMPT_BEARING_PATTERNS if "system" in pattern.pattern
]


def get_prompt_bearing_patterns() -> list[str]:
    """Return the canonical prompt-bearing regex strings for UI/runtime consumers."""
    return [pattern.pattern for pattern in _PROMPT_BEARING_PATTERNS]


def get_system_prompt_bearing_patterns() -> list[str]:
    """Return the canonical explicit system-style regex strings for pretty-view ordering."""
    return [pattern.pattern for pattern in _SYSTEM_PROMPT_BEARING_PATTERNS]


def get_content_bearing_patterns() -> list[str]:
    """Return the canonical content-bearing regex strings for runtime matching."""
    return [pattern.pattern for pattern in _CONTENT_BEARING_PATTERNS]


def parse_inherited_prior_ids(value: str) -> tuple[list[str], list[str]]:
    """Extract inherited prior ids from a rendered priors block."""
    inherited_prior_ids: list[str] = []
    warnings: list[str] = []

    for block in _leading_priors_blocks(value):
        manifest_match = _MANIFEST_RE.search(block)
        if not manifest_match:
            warnings.append("Stripped a manual <sovara-priors> block without a manifest.")
            continue

        try:
            manifest = json.loads(manifest_match.group(1))
        except json.JSONDecodeError:
            warnings.append("Stripped a <sovara-priors> block with an invalid manifest.")
            continue

        priors = manifest.get("priors")
        if not isinstance(priors, list):
            warnings.append("Stripped a <sovara-priors> block with a malformed manifest payload.")
            continue

        for prior in priors:
            if not isinstance(prior, dict):
                continue
            prior_id = prior.get("id")
            if isinstance(prior_id, str) and prior_id and prior_id not in inherited_prior_ids:
                inherited_prior_ids.append(prior_id)

    return inherited_prior_ids, warnings


def _leading_priors_blocks(value: str) -> list[str]:
    blocks: list[str] = []
    index = len(value) - len(value.lstrip())
    while index < len(value):
        match = _PRIORS_BLOCK_RE.match(value, index)
        if match is None:
            break
        blocks.append(match.group(0))
        index = match.end()
        if value.startswith("\n\n", index):
            index += 2
        while index < len(value) and value[index].isspace():
            next_match = _PRIORS_BLOCK_RE.match(value, index)
            if next_match is not None:
                break
            if value.startswith("\n\n", index):
                break
            if value[index] in "\r\n\t ":
                index += 1
                continue
            return blocks
    return blocks


def _strip_leading_priors_prefix(value: str) -> str:
    index = len(value) - len(value.lstrip())
    found_block = False
    while index < len(value):
        match = _PRIORS_BLOCK_RE.match(value, index)
        if match is None:
            break
        found_block = True
        index = match.end()
        if value.startswith("\n\n", index):
            index += 2
    return value[index:] if found_block else value


def detect_manual_priors_reason(flattened_to_show: dict[str, Any]) -> str | None:
    """Return a reason when the payload contains user-managed priors blocks."""
    for value in flattened_to_show.values():
        if not isinstance(value, str):
            continue
        if "<sovara-priors>" not in value:
            continue

        for block in _leading_priors_blocks(value):
            manifest_match = _MANIFEST_RE.search(block)
            if not manifest_match:
                return "Detected a manual <sovara-priors> block without a manifest; skipped automated priors retrieval."
            try:
                manifest = json.loads(manifest_match.group(1))
            except json.JSONDecodeError:
                return "Detected a manual <sovara-priors> block with an invalid manifest; skipped automated priors retrieval."
            if manifest.get("manual") is True:
                return "Detected a manual <sovara-priors> block; skipped automated priors retrieval."
            if not isinstance(manifest.get("priors"), list):
                return "Detected a manual <sovara-priors> block with a malformed manifest payload; skipped automated priors retrieval."

    return None


def strip_priors_from_flattened(flattened_to_show: dict[str, Any]) -> tuple[dict[str, Any], list[str], list[str]]:
    """Strip priors blocks from every string value in a flattened mapping."""
    cleaned = dict(flattened_to_show)
    inherited_prior_ids: list[str] = []
    warnings: list[str] = []

    for key, value in flattened_to_show.items():
        if not isinstance(value, str) or "<sovara-priors>" not in value:
            continue

        blocks = _leading_priors_blocks(value)
        if not blocks:
            continue

        ids, parse_warnings = parse_inherited_prior_ids(value)
        for prior_id in ids:
            if prior_id not in inherited_prior_ids:
                inherited_prior_ids.append(prior_id)
        warnings.extend(parse_warnings)

        cleaned[key] = strip_priors_blocks_exact(value)

    return cleaned, inherited_prior_ids, warnings


def strip_priors_blocks_exact(value: str) -> str:
    """Remove managed priors blocks without altering unrelated prompt whitespace."""
    return _strip_leading_priors_prefix(value)


def _flattened_key_sort_key(key: str) -> tuple[Any, ...]:
    parts: list[Any] = []
    for segment in key.split("."):
        if segment.isdigit():
            parts.append(int(segment))
        else:
            parts.append(segment)
    return tuple(parts)


def _extract_matching_string_keys(
    flattened_to_show: dict[str, Any],
    patterns: list[re.Pattern[str]],
) -> list[str]:
    string_keys = sorted(
        (
            key
            for key, value in flattened_to_show.items()
            if isinstance(value, str)
        ),
        key=_flattened_key_sort_key,
    )

    ordered_keys: list[str] = []
    seen: set[str] = set()
    for pattern in patterns:
        for key in string_keys:
            if key not in seen and pattern.match(key):
                ordered_keys.append(key)
                seen.add(key)
    return ordered_keys


def extract_prompt_bearing_keys(flattened_to_show: dict[str, Any], api_type: str) -> list[str]:
    """Return the ordered prompt-bearing keys for a flattened ``to_show`` payload."""
    del api_type  # keyed off normalized ``to_show`` keys in v1.
    return _extract_matching_string_keys(flattened_to_show, _PROMPT_BEARING_PATTERNS)


def extract_prompt_bearing_pairs(flattened_to_show: dict[str, Any], api_type: str) -> list[dict[str, str]]:
    """Return ordered prompt-bearing ``(key, value)`` pairs for matching and replay."""
    return [
        {"key": key, "value": flattened_to_show[key]}
        for key in extract_prompt_bearing_keys(flattened_to_show, api_type)
    ]


def extract_content_bearing_keys(flattened_to_show: dict[str, Any], api_type: str) -> list[str]:
    """Return ordered content-bearing keys for prefix caching and retrieval suffixing."""
    del api_type  # keyed off normalized ``to_show`` keys in v1.
    return _extract_matching_string_keys(flattened_to_show, _CONTENT_BEARING_PATTERNS)


def extract_content_bearing_pairs(flattened_to_show: dict[str, Any], api_type: str) -> list[dict[str, str]]:
    """Return ordered content-bearing ``(key, value)`` pairs for prefix caching and replay."""
    return [
        {"key": key, "value": flattened_to_show[key]}
        for key in extract_content_bearing_keys(flattened_to_show, api_type)
    ]


def render_retrieval_context(
    cleaned_flattened: dict[str, Any],
    prefix_keys: list[str],
    suffix_keys: list[str],
) -> str:
    """Serialize retrieval context as semantic prefix/suffix entries."""
    prefix_entries = [
        {"key": key, "text": value}
        for key in prefix_keys
        if isinstance((value := cleaned_flattened.get(key)), str)
    ]
    suffix_entries = [
        {"key": key, "text": value}
        for key in suffix_keys
        if isinstance((value := cleaned_flattened.get(key)), str)
    ]
    return json.dumps(
        {
            "prefix": prefix_entries,
            "suffix": suffix_entries,
        },
        ensure_ascii=False,
        separators=(",", ":"),
    )


def replay_injected_prefix(
    flattened_to_show: dict[str, Any],
    injected_prefix_pairs: list[dict[str, str]],
) -> dict[str, Any]:
    """Replay a cached injected prompt prefix onto a clean flattened mapping."""
    updated = dict(flattened_to_show)
    for pair in injected_prefix_pairs:
        key = pair.get("key")
        value = pair.get("value")
        if isinstance(key, str) and isinstance(value, str):
            updated[key] = value
    return updated


def inject_priors_block(
    flattened_to_show: dict[str, Any],
    rendered_priors_block: str,
    injection_anchor: dict[str, Any],
) -> dict[str, Any]:
    """Inject priors into the approved anchor field of a flattened mapping."""
    key = injection_anchor.get("key")
    if not isinstance(key, str):
        raise ValueError("Injection anchor must contain a string 'key'.")
    if key not in flattened_to_show or not isinstance(flattened_to_show[key], str):
        raise ValueError(f"Injection anchor '{key}' does not point to a string field.")

    updated = dict(flattened_to_show)
    original = updated[key]
    updated[key] = f"{rendered_priors_block}\n\n{original}" if original else rendered_priors_block
    return updated
