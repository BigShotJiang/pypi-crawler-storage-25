"""API parser helpers for ``claude_code.messages`` proxy calls."""

from __future__ import annotations

import json
from typing import Any

def build_to_show_claude_code_messages_input(raw_input: dict[str, Any]) -> dict[str, Any]:
    body = raw_input.get("body")
    if body is None:
        return {}
    return {"body": body}


def build_to_show_claude_code_messages_output(raw_output: dict[str, Any]) -> dict[str, Any]:
    visible_output = {
        key: value
        for key, value in raw_output.items()
        if not str(key).startswith("_")
    }
    from sovara.runner.monkey_patching.api_parser import filter_dict

    return filter_dict(visible_output)


def func_kwargs_to_json_str_claude_code_messages(input_dict: dict[str, Any]) -> str:
    return json.dumps({
        "url": input_dict.get("url", ""),
        "body": input_dict.get("body"),
    })


def api_obj_to_json_str_claude_code_messages(obj: Any) -> str:
    if not isinstance(obj, dict):
        obj = {"value": obj}
    return json.dumps(obj)


def json_str_to_api_obj_claude_code_messages(json_str: str) -> Any:
    return json.loads(json_str)


def json_str_to_original_inp_dict_claude_code_messages(json_str: str, input_dict: dict) -> dict:
    payload = json.loads(json_str)
    input_dict["url"] = payload.get("url", input_dict.get("url", ""))
    input_dict["body"] = payload.get("body")
    return input_dict
