import json
from typing import Any


def strip_optional_sse_space(payload: str) -> str:
    """SSE allows exactly one optional space after the field separator."""
    return payload[1:] if payload.startswith(" ") else payload


def parse_sse_data_value(payload: str) -> Any:
    try:
        return json.loads(payload)
    except json.JSONDecodeError:
        return payload


def parse_sse_events(decoded_content: str) -> list[dict[str, Any]] | None:
    """Parse a standards-based SSE body into event dictionaries."""
    if not decoded_content.strip():
        return None

    events: list[dict[str, Any]] = []
    data_lines: list[str] = []
    current_event: dict[str, Any] = {}
    saw_sse_line = False

    def flush_event() -> None:
        nonlocal data_lines, current_event
        if data_lines:
            current_event["data"] = parse_sse_data_value("\n".join(data_lines))
            data_lines = []
        if not current_event:
            return
        events.append(current_event)
        current_event = {}

    for line in decoded_content.splitlines():
        if not line:
            flush_event()
            continue

        if line.startswith(":"):
            saw_sse_line = True
            continue

        saw_sse_line = True
        if ":" in line:
            field, raw_value = line.split(":", 1)
            value = strip_optional_sse_space(raw_value)
        else:
            field, value = line, ""

        if field == "data":
            data_lines.append(value)
        elif field in {"event", "id", "retry"}:
            current_event[field] = int(value) if field == "retry" and value.isdigit() else value
        else:
            return None

    flush_event()
    return events if saw_sse_line and events else None


def serialize_sse_data_lines(data: Any) -> list[str]:
    if isinstance(data, str):
        return data.split("\n")
    return [json.dumps(data, separators=(",", ":"))]


def serialize_sse_events(events: list[dict[str, Any]]) -> bytes:
    """Serialize stored SSE events back into an event stream body."""
    chunks = []
    for event in events:
        if "event" in event:
            chunks.append(f"event: {event['event']}\r\n")
        if "id" in event:
            chunks.append(f"id: {event['id']}\r\n")
        if "retry" in event:
            chunks.append(f"retry: {event['retry']}\r\n")
        if "data" in event:
            for payload_line in serialize_sse_data_lines(event["data"]):
                chunks.append(f"data: {payload_line}\r\n")
        chunks.append("\r\n")
    return "".join(chunks).encode("utf-8")


def extract_sse_display_content(events: list[dict[str, Any]]) -> Any:
    data_events = [event["data"] for event in events if "data" in event]
    if not data_events:
        return ""
    return data_events[0] if len(data_events) == 1 else data_events


def merge_sse_events_with_content(events: list[dict[str, Any]], content: Any) -> list[dict[str, Any]]:
    data_event_count = sum(1 for event in events if "data" in event)
    if data_event_count == 0:
        return events

    if data_event_count == 1:
        merged = []
        for event in events:
            updated = dict(event)
            if "data" in updated:
                updated["data"] = content
            merged.append(updated)
        return merged

    content_items = content if isinstance(content, list) else [content]
    content_iter = iter(content_items)
    merged = []
    for event in events:
        updated = dict(event)
        if "data" in updated:
            try:
                updated["data"] = next(content_iter)
            except StopIteration:
                pass
        merged.append(updated)
    return merged
