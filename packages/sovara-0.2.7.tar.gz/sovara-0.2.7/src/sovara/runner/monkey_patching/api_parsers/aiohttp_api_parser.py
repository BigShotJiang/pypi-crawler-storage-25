import asyncio
import base64
import json
from typing import Any, Dict
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from sovara.runner.monkey_patching.api_parsers.sse_utils import (
    extract_sse_display_content,
    merge_sse_events_with_content,
    parse_sse_events,
    serialize_sse_events,
)
from sovara.runner.monkey_patching.async_streaming import ReplayAsyncByteStream

try:
    from aiohttp import ClientConnectionError, ClientResponse, ContentTypeError, hdrs
    from aiohttp.client_reqrep import RequestInfo
    from multidict import CIMultiDict, CIMultiDictProxy
    from yarl import URL

    HAS_AIOHTTP = True
except ImportError:  # pragma: no cover - exercised indirectly by import safety
    ClientConnectionError = RuntimeError
    ContentTypeError = ValueError
    ClientResponse = object
    RequestInfo = None
    CIMultiDict = dict
    CIMultiDictProxy = dict
    hdrs = type("_Headers", (), {"CONTENT_TYPE": "content-type"})()
    URL = None
    HAS_AIOHTTP = False


def _build_url(str_or_url: Any, params: Any = None) -> str:
    parsed = urlparse(str(str_or_url))
    query_items = parse_qsl(parsed.query, keep_blank_values=True)
    if params:
        if isinstance(params, dict):
            query_items.extend(params.items())
        else:
            query_items.extend(params)
    return urlunparse(parsed._replace(query=urlencode(query_items, doseq=True)))


def _serialize_body_value(input_dict: Dict[str, Any]) -> tuple[Any, str, bool, bool, bool]:
    if input_dict.get("json") is not None:
        return input_dict["json"], "json", False, False, False

    data = input_dict.get("data")
    if data in (None, "", b""):
        return "", "none", False, False, False

    if isinstance(data, bytes):
        try:
            decoded = data.decode("utf-8")
        except UnicodeDecodeError:
            return base64.b64encode(data).decode("ascii"), "data", True, True, False
        try:
            return json.loads(decoded), "data", True, False, True
        except json.JSONDecodeError:
            return decoded, "data", True, False, False

    if isinstance(data, str):
        try:
            return json.loads(data), "data", False, False, True
        except json.JSONDecodeError:
            return data, "data", False, False, False

    if isinstance(data, (dict, list)):
        return data, "data", False, False, True

    return str(data), "data", False, False, False


def _restore_data_value(
    body: Any,
    *,
    encoded: bool,
    body_base64: bool,
    body_is_json: bool,
) -> Any:
    if body == "":
        return None

    if body_base64:
        return base64.b64decode(body.encode("ascii"))

    restored = json.dumps(body) if body_is_json else body
    if encoded and isinstance(restored, str):
        return restored.encode("utf-8")
    return restored


def json_str_to_original_inp_dict_aiohttp(json_str: str, input_dict: dict) -> dict:
    parsed = json.loads(json_str)
    input_dict["method"] = parsed["method"]
    input_dict["str_or_url"] = parsed["url"]
    input_dict["params"] = None

    body_source = parsed.get("_body_source", "none")
    if body_source == "json":
        input_dict["json"] = parsed["body"]
        input_dict["data"] = None
    elif body_source == "data":
        input_dict["json"] = None
        input_dict["data"] = _restore_data_value(
            parsed["body"],
            encoded=parsed.get("_body_encoded", False),
            body_base64=parsed.get("_body_base64", False),
            body_is_json=parsed.get("_body_is_json", False),
        )
    else:
        input_dict["json"] = None
        input_dict["data"] = None

    return input_dict


def func_kwargs_to_json_str_aiohttp(input_dict: Dict[str, Any]):
    body, body_source, body_encoded, body_base64, body_is_json = _serialize_body_value(input_dict)
    json_str = json.dumps(
        {
            "method": input_dict["method"],
            "url": _build_url(input_dict["str_or_url"], input_dict.get("params")),
            "body": body,
            "_body_source": body_source,
            "_body_encoded": body_encoded,
            "_body_base64": body_base64,
            "_body_is_json": body_is_json,
        },
    )
    return json_str


class ReplayAiohttpResponse(ClientResponse):
    """Replayable aiohttp-compatible response backed by in-memory bytes."""

    def __init__(
        self,
        *,
        status: int,
        reason: str | None,
        headers: dict[str, str],
        request_url: str,
        body_bytes: bytes,
        method: str = "GET",
        encoding: str = "utf-8",
        error: dict[str, str] | None = None,
        incomplete_details: dict[str, str] | None = None,
    ):
        if not HAS_AIOHTTP:
            raise ImportError("aiohttp is required to reconstruct aiohttp responses")
        self.method = method
        self.status = status
        self.reason = reason
        self._url = URL(request_url)
        self._real_url = self._url
        self._headers = CIMultiDictProxy(CIMultiDict(headers))
        self._raw_headers = tuple(
            (str(key).encode("utf-8"), str(value).encode("utf-8"))
            for key, value in headers.items()
        )
        self._request_info = RequestInfo(self._url, method, self._headers, self._real_url)
        self._history = ()
        self._cache = {}
        self._in_context = False
        self._released = False
        self._closed = False
        self._connection = None
        try:
            self._loop = asyncio.get_running_loop()
        except RuntimeError:
            self._loop = None
        self._traces = []
        self._body = None
        self._resolve_charset = lambda _response, _body: encoding
        self.replay_body_bytes = body_bytes
        self.replay_error = error
        self.replay_incomplete_details = incomplete_details
        self.replay_encoding = encoding
        self.content = ReplayAsyncByteStream(body_bytes, error=error)

    async def read(self) -> bytes:
        if self._body is None:
            self._body = await self.content.read()
        elif self._released:
            raise ClientConnectionError("Connection closed")
        return self._body

    async def text(self, encoding: str | None = None, errors: str = "strict") -> str:
        body = await self.read()
        if encoding is None:
            encoding = self.get_encoding()
        return body.decode(encoding, errors=errors)

    async def json(
        self,
        *,
        encoding: str | None = None,
        loads=json.loads,
        content_type: str | None = "application/json",
    ) -> Any:
        body = await self.read()
        if content_type:
            ctype = self.headers.get(hdrs.CONTENT_TYPE, "").lower()
            if content_type not in ctype and not (
                content_type == "application/json" and ctype.endswith("+json")
            ):
                raise ContentTypeError(
                    self.request_info,
                    self.history,
                    status=self.status,
                    message=f"Attempt to decode JSON with unexpected mimetype: {ctype}",
                    headers=self.headers,
                )

        stripped = body.strip()
        if not stripped:
            return None

        if encoding is None:
            encoding = self.get_encoding()
        return loads(stripped.decode(encoding))

    def release(self) -> None:
        self._released = True
        self._closed = True

    def close(self) -> None:
        self.release()

    async def wait_for_close(self) -> None:
        self.release()


def build_replay_aiohttp_response(
    *,
    status: int,
    reason: str | None,
    headers: dict[str, str],
    request_url: str,
    body_bytes: bytes,
    method: str = "GET",
    encoding: str = "utf-8",
    error: dict[str, str] | None = None,
    incomplete_details: dict[str, str] | None = None,
) -> ReplayAiohttpResponse:
    return ReplayAiohttpResponse(
        status=status,
        reason=reason,
        headers=headers,
        request_url=request_url,
        body_bytes=body_bytes,
        method=method,
        encoding=encoding,
        error=error,
        incomplete_details=incomplete_details,
    )


def api_obj_to_json_str_aiohttp(obj: Any) -> str:
    body_bytes = getattr(obj, "replay_body_bytes", b"")
    encoding = getattr(obj, "replay_encoding", None) or "utf-8"
    decoded_content = body_bytes.decode(encoding, errors="replace")

    out_dict = {
        "_encoding": encoding,
        "method": getattr(obj, "method", "GET"),
        "request_url": str(getattr(obj, "url", "")),
        "status": getattr(obj, "status", 0),
        "reason": getattr(obj, "reason", None),
        "headers": dict(getattr(obj, "headers", {}).items()),
    }

    sse_events = parse_sse_events(decoded_content)
    if sse_events is not None:
        out_dict["_response_format"] = "sse"
        out_dict["content"] = extract_sse_display_content(sse_events)
        out_dict["sse"] = {"events": sse_events}
    else:
        try:
            out_dict["content"] = json.loads(decoded_content) if decoded_content else ""
        except json.JSONDecodeError:
            out_dict["content"] = decoded_content

    error = getattr(obj, "replay_error", None)
    if error is not None:
        out_dict["error"] = error

    incomplete_details = getattr(obj, "replay_incomplete_details", None)
    if incomplete_details is not None:
        out_dict["incomplete_details"] = incomplete_details

    return json.dumps(out_dict)


def json_str_to_api_obj_aiohttp(new_output_text: str) -> ReplayAiohttpResponse:
    out_dict = json.loads(new_output_text)
    encoding = out_dict.get("_encoding", "utf-8")

    if out_dict.get("_response_format") == "sse":
        events = out_dict.get("sse", {}).get("events", [])
        body_bytes = serialize_sse_events(merge_sse_events_with_content(events, out_dict["content"]))
    elif isinstance(out_dict["content"], str):
        body_bytes = out_dict["content"].encode(encoding)
    elif isinstance(out_dict["content"], (dict, list)):
        body_bytes = json.dumps(out_dict["content"], separators=(",", ":")).encode(encoding)
    else:
        raise Exception("out_dict['content'] is not dict, list, or str after json.loads")

    return build_replay_aiohttp_response(
        status=out_dict.get("status", 0),
        reason=out_dict.get("reason"),
        headers=dict(out_dict.get("headers", {})),
        request_url=out_dict.get("request_url", ""),
        body_bytes=body_bytes,
        method=out_dict.get("method", "GET"),
        encoding=encoding,
        error=out_dict.get("error"),
        incomplete_details=out_dict.get("incomplete_details"),
    )
