from __future__ import annotations

from collections.abc import Callable
import json
from dataclasses import dataclass
from typing import Any

from sovara.runner.context_manager import get_run_id
from sovara.runner.node_execution import (
    publish_prepared_call_output,
    record_prepared_call_exception,
)
from sovara.runner.runtime_client import runtime_client
from sovara.runner.string_matching import find_source_nodes


@dataclass
class PreparedToolTrace:
    prepared_call: Any
    source_node_ids: list[str]


SourceFinder = Callable[[str, dict[str, Any], str], list[str]]


def normalize_jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): normalize_jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [normalize_jsonable(item) for item in value]
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        try:
            return normalize_jsonable(model_dump(by_alias=True, mode="json", exclude_none=True))
        except TypeError:
            return normalize_jsonable(model_dump())
    dict_method = getattr(value, "dict", None)
    if callable(dict_method):
        return normalize_jsonable(dict_method())
    return str(value)


def build_tool_input_dict(
    *,
    tool_name: str,
    tool_input: Any,
    tool_call_id: str,
    meta: dict[str, Any] | None = None,
) -> dict[str, Any]:
    normalized_input = normalize_jsonable(tool_input)
    payload = {
        "tool_name": tool_name,
        "tool_call_id": tool_call_id,
        "tool_input": normalized_input,
    }
    normalized_meta = normalize_jsonable(meta or {})
    if normalized_meta:
        payload["_meta"] = normalized_meta
    if isinstance(normalized_input, (dict, list)):
        payload["tool_input_json"] = json.dumps(normalized_input, sort_keys=True)
    return payload


def build_tool_success_output(
    *,
    tool_name: str,
    tool_call_id: str,
    result: Any,
    meta: dict[str, Any] | None = None,
) -> dict[str, Any]:
    normalized_meta = normalize_jsonable(meta or {})
    normalized_meta.setdefault("output_type", result.__class__.__name__)
    return {
        "tool_name": tool_name,
        "tool_call_id": tool_call_id,
        "status": "success",
        "tool_output": normalize_jsonable(result),
        "_meta": normalized_meta,
    }


def build_tool_error_output(
    *,
    tool_name: str,
    tool_call_id: str,
    exc: Exception,
) -> dict[str, Any]:
    return {
        "tool_name": tool_name,
        "tool_call_id": tool_call_id,
        "status": "error",
        "error_type": exc.__class__.__name__,
        "error_message": str(exc) or exc.__class__.__name__,
    }


def build_prepared_tool_trace(
    prepared_call: Any,
    api_type: str,
    *,
    source_finder: SourceFinder = find_source_nodes,
) -> PreparedToolTrace:
    return PreparedToolTrace(
        prepared_call=prepared_call,
        source_node_ids=source_finder(
            prepared_call.run_id,
            prepared_call.input_dict,
            api_type,
        ),
    )


def should_trace_tool(tool_call_id: str | None) -> bool:
    return bool(tool_call_id and get_run_id())


def prepare_tool_trace(
    *,
    tool_name: str,
    tool_input: Any,
    tool_call_id: str,
    api_type: str,
    meta: dict[str, Any] | None = None,
) -> PreparedToolTrace:
    prepared_call = runtime_client.prepare_call(
        build_tool_input_dict(
            tool_name=tool_name,
            tool_input=tool_input,
            tool_call_id=tool_call_id,
            meta=meta,
        ),
        api_type,
    )
    return build_prepared_tool_trace(
        prepared_call,
        api_type,
    )


def publish_prepared_tool_output(trace: PreparedToolTrace, api_type: str) -> None:
    publish_prepared_call_output(
        prepared_call=trace.prepared_call,
        api_type=api_type,
        source_node_ids=trace.source_node_ids,
    )


def record_prepared_tool_output(
    trace: PreparedToolTrace,
    output_obj: Any,
    api_type: str,
) -> None:
    runtime_client.record_output(trace.prepared_call, output_obj, api_type)
    publish_prepared_tool_output(trace, api_type)


def record_prepared_tool_exception(
    trace: PreparedToolTrace,
    exc: Exception,
    api_type: str,
) -> None:
    def build_exception_output_func(exc: Exception, api_type: str, input_dict: dict[str, Any]) -> Any:
        del api_type
        return build_tool_error_output(
            tool_name=str(input_dict.get("tool_name") or "Tool"),
            tool_call_id=str(input_dict.get("tool_call_id") or ""),
            exc=exc,
        )

    record_prepared_call_exception(
        prepared_call=trace.prepared_call,
        exc=exc,
        api_type=api_type,
        source_node_ids=trace.source_node_ids,
        build_exception_output_func=build_exception_output_func,
    )
