from __future__ import annotations

from functools import wraps
from typing import Any

from sovara.common.logger import logger
from sovara.runner.monkey_patching.patching_utils import send_graph_node_and_edges
from sovara.runner.monkey_patching.tool_trace_utils import (
    build_tool_error_output,
    build_tool_input_dict,
    normalize_jsonable,
    should_trace_tool,
)
from sovara.runner.string_matching import find_source_nodes, store_output_strings
from sovara.server.database import DB


API_TYPE = "langchain_core.tools.BaseTool.run"


def _normalize_result(tool, tool_call_id: str, result: Any) -> dict[str, Any]:
    tool_message = getattr(result, "tool_call_id", None) is not None and hasattr(result, "content")
    if tool_message:
        artifact = getattr(result, "artifact", None)
        output = {
            "tool_name": tool.name,
            "tool_call_id": getattr(result, "tool_call_id", None) or tool_call_id,
            "status": getattr(result, "status", "success") or "success",
            "tool_output": normalize_jsonable(result.content),
            "_meta": {
                "message_name": getattr(result, "name", None),
                "output_type": result.__class__.__name__,
            },
        }
        if artifact is not None:
            output["_meta"]["artifact"] = normalize_jsonable(artifact)
        return output

    return {
        "tool_name": tool.name,
        "tool_call_id": tool_call_id,
        "status": "success",
        "tool_output": normalize_jsonable(result),
        "_meta": {
            "output_type": result.__class__.__name__,
        },
    }


def langchain_patch():
    try:
        from langchain_core.tools.base import BaseTool
    except ImportError:
        logger.info("langchain_core not installed, skipping LangChain tool patches")
        return

    if getattr(BaseTool.run, "__sovara_langchain_patched__", False):
        return

    original_run = BaseTool.run
    original_arun = BaseTool.arun

    @wraps(original_run)
    def patched_run(
        self,
        tool_input,
        verbose=None,
        start_color="green",
        color="green",
        callbacks=None,
        *,
        tags=None,
        metadata=None,
        run_name=None,
        run_id=None,
        config=None,
        tool_call_id=None,
        **kwargs,
    ):
        if not should_trace_tool(tool_call_id):
            return original_run(
                self,
                tool_input,
                verbose=verbose,
                start_color=start_color,
                color=color,
                callbacks=callbacks,
                tags=tags,
                metadata=metadata,
                run_name=run_name,
                run_id=run_id,
                config=config,
                tool_call_id=tool_call_id,
                **kwargs,
            )

        input_dict = build_tool_input_dict(
            tool_name=self.name,
            tool_input=tool_input,
            tool_call_id=tool_call_id,
            meta={
                "tool_class": self.__class__.__name__,
                "response_format": getattr(self, "response_format", None),
            },
        )
        cache_output = DB.get_in_out(input_dict, API_TYPE)
        source_node_ids = find_source_nodes(cache_output.run_id, cache_output.input_dict, API_TYPE)
        executed_input = cache_output.input_dict["tool_input"]

        try:
            result = original_run(
                self,
                executed_input,
                verbose=verbose,
                start_color=start_color,
                color=color,
                callbacks=callbacks,
                tags=tags,
                metadata=metadata,
                run_name=run_name,
                run_id=run_id,
                config=config,
                tool_call_id=cache_output.input_dict["tool_call_id"],
                **kwargs,
            )
        except Exception as exc:
            output_obj = build_tool_error_output(
                tool_name=self.name,
                tool_call_id=cache_output.input_dict["tool_call_id"],
                exc=exc,
            )
            DB.cache_output(cache_result=cache_output, output_obj=output_obj, api_type=API_TYPE)
            store_output_strings(cache_output.run_id, cache_output.node_uuid, output_obj, API_TYPE)
            send_graph_node_and_edges(
                node_id=cache_output.node_uuid,
                input_dict=cache_output.input_dict,
                output_obj=output_obj,
                source_node_ids=source_node_ids,
                api_type=API_TYPE,
                stack_trace=cache_output.stack_trace,
                latency_seconds=cache_output.latency_seconds,
            )
            raise

        output_obj = _normalize_result(self, cache_output.input_dict["tool_call_id"], result)
        DB.cache_output(cache_result=cache_output, output_obj=output_obj, api_type=API_TYPE)
        store_output_strings(cache_output.run_id, cache_output.node_uuid, output_obj, API_TYPE)
        send_graph_node_and_edges(
            node_id=cache_output.node_uuid,
            input_dict=cache_output.input_dict,
            output_obj=output_obj,
            source_node_ids=source_node_ids,
            api_type=API_TYPE,
            stack_trace=cache_output.stack_trace,
            latency_seconds=cache_output.latency_seconds,
        )
        return result

    @wraps(original_arun)
    async def patched_arun(
        self,
        tool_input,
        verbose=None,
        start_color="green",
        color="green",
        callbacks=None,
        *,
        tags=None,
        metadata=None,
        run_name=None,
        run_id=None,
        config=None,
        tool_call_id=None,
        **kwargs,
    ):
        if not should_trace_tool(tool_call_id):
            return await original_arun(
                self,
                tool_input,
                verbose=verbose,
                start_color=start_color,
                color=color,
                callbacks=callbacks,
                tags=tags,
                metadata=metadata,
                run_name=run_name,
                run_id=run_id,
                config=config,
                tool_call_id=tool_call_id,
                **kwargs,
            )

        input_dict = build_tool_input_dict(
            tool_name=self.name,
            tool_input=tool_input,
            tool_call_id=tool_call_id,
            meta={
                "tool_class": self.__class__.__name__,
                "response_format": getattr(self, "response_format", None),
            },
        )
        cache_output = DB.get_in_out(input_dict, API_TYPE)
        source_node_ids = find_source_nodes(cache_output.run_id, cache_output.input_dict, API_TYPE)
        executed_input = cache_output.input_dict["tool_input"]

        try:
            result = await original_arun(
                self,
                executed_input,
                verbose=verbose,
                start_color=start_color,
                color=color,
                callbacks=callbacks,
                tags=tags,
                metadata=metadata,
                run_name=run_name,
                run_id=run_id,
                config=config,
                tool_call_id=cache_output.input_dict["tool_call_id"],
                **kwargs,
            )
        except Exception as exc:
            output_obj = build_tool_error_output(
                tool_name=self.name,
                tool_call_id=cache_output.input_dict["tool_call_id"],
                exc=exc,
            )
            DB.cache_output(cache_result=cache_output, output_obj=output_obj, api_type=API_TYPE)
            store_output_strings(cache_output.run_id, cache_output.node_uuid, output_obj, API_TYPE)
            send_graph_node_and_edges(
                node_id=cache_output.node_uuid,
                input_dict=cache_output.input_dict,
                output_obj=output_obj,
                source_node_ids=source_node_ids,
                api_type=API_TYPE,
                stack_trace=cache_output.stack_trace,
                latency_seconds=cache_output.latency_seconds,
            )
            raise

        output_obj = _normalize_result(self, cache_output.input_dict["tool_call_id"], result)
        DB.cache_output(cache_result=cache_output, output_obj=output_obj, api_type=API_TYPE)
        store_output_strings(cache_output.run_id, cache_output.node_uuid, output_obj, API_TYPE)
        send_graph_node_and_edges(
            node_id=cache_output.node_uuid,
            input_dict=cache_output.input_dict,
            output_obj=output_obj,
            source_node_ids=source_node_ids,
            api_type=API_TYPE,
            stack_trace=cache_output.stack_trace,
            latency_seconds=cache_output.latency_seconds,
        )
        return result

    patched_run.__sovara_langchain_patched__ = True
    patched_arun.__sovara_langchain_patched__ = True
    BaseTool.run = patched_run
    BaseTool.arun = patched_arun
    logger.info("langchain_core tool patch applied")
