"""Patch Claude Agent SDK to route model traffic through the Sovara proxy."""

from __future__ import annotations

from dataclasses import replace
from functools import wraps
import os
import uuid
from typing import Any

from sovara.common.constants import SOVARA_SERVER_URL
from sovara.common.logger import logger
from sovara.runner.context_manager import get_run_id
from sovara.runner.monkey_patching.patching_utils import capture_stack_trace
from sovara.runner.runtime_client import runtime_client

_DEFAULT_ANTHROPIC_BASE_URL = "https://api.anthropic.com"
_UNSUPPORTED_CUSTOM_TRANSPORT_MESSAGE = (
    "Custom Claude Agent SDK transports are not supported yet under so-record. "
    "Please reach out to support@sovara-labs.com."
)
_PROXY_LOOP_MESSAGE = (
    "Claude Agent SDK ANTHROPIC_BASE_URL points at the Sovara Claude proxy itself. "
    "Nested Claude proxy configuration is not supported under so-record."
)


def _replace_options_env(options: Any, env: dict[str, str]):
    try:
        return replace(options, env=env)
    except Exception:
        options.env = env
        return options


def _merged_transport_env(options_env: dict[str, str] | None) -> dict[str, str]:
    inherited_env = {key: value for key, value in os.environ.items() if key != "CLAUDECODE"}
    return {
        **inherited_env,
        "CLAUDE_CODE_ENTRYPOINT": "sdk-py",
        **(options_env or {}),
    }


def _proxy_base_url(run_id: str, client_id: str) -> str:
    return f"{SOVARA_SERVER_URL}/claude-proxy/runs/{run_id}/clients/{client_id}"


def _is_sovara_proxy_base_url(base_url: str) -> bool:
    return base_url.rstrip("/").startswith(f"{SOVARA_SERVER_URL.rstrip('/')}/claude-proxy/")


def _ensure_supported_transport(transport: Any) -> None:
    if transport is not None and get_run_id():
        raise RuntimeError(_UNSUPPORTED_CUSTOM_TRANSPORT_MESSAGE)


def _normalize_tool_result_content(content: Any) -> Any:
    if content is None:
        return ""
    return content


def claude_sdk_patch():
    """Apply Claude Agent SDK patches when running under ``so-record``."""
    try:
        from claude_agent_sdk._internal import client as internal_client
        from claude_agent_sdk._internal import message_parser
        from claude_agent_sdk._internal.transport.subprocess_cli import SubprocessCLITransport
        from claude_agent_sdk import client as sdk_client
        from claude_agent_sdk.client import ClaudeSDKClient
    except ImportError:
        logger.info("claude_agent_sdk not installed, skipping SDK patches")
        return

    try:
        from claude_agent_sdk.types import AssistantMessage, ToolResultBlock, ToolUseBlock, UserMessage
    except ImportError:
        logger.info("claude_agent_sdk types unavailable, skipping SDK patches")
        return

    original_parse = message_parser.parse_message
    original_process_query = internal_client.InternalClient.process_query
    original_client_connect = ClaudeSDKClient.connect
    original_transport_connect = SubprocessCLITransport.connect

    @wraps(original_parse)
    def patched_parse_message(data: dict) -> Any:
        message = original_parse(data)
        run_id = get_run_id()
        if not run_id:
            return message

        stack_trace = capture_stack_trace()
        try:
            if isinstance(message, AssistantMessage):
                for block in getattr(message, "content", []) or []:
                    if isinstance(block, ToolUseBlock):
                        runtime_client.register_claude_sdk_tool_use(
                            run_id,
                            block.id,
                            block.name,
                            getattr(block, "input", None),
                            stack_trace=stack_trace,
                        )
            elif isinstance(message, UserMessage):
                content = getattr(message, "content", None)
                if isinstance(content, list):
                    for block in content:
                        if isinstance(block, ToolResultBlock):
                            runtime_client.finalize_claude_sdk_tool_result(
                                run_id,
                                block.tool_use_id,
                                _normalize_tool_result_content(getattr(block, "content", None)),
                                is_error=bool(getattr(block, "is_error", False)),
                            )
        except Exception as exc:
            logger.error("Error in claude_sdk_patch parse hook: %s", exc)
        return message

    @wraps(original_process_query)
    async def patched_process_query(self, prompt, options, transport=None):
        _ensure_supported_transport(transport)
        async for message in original_process_query(self, prompt, options, transport=transport):
            yield message

    @wraps(original_client_connect)
    async def patched_client_connect(self, prompt=None):
        _ensure_supported_transport(getattr(self, "_custom_transport", None))
        return await original_client_connect(self, prompt)

    @wraps(original_transport_connect)
    async def patched_transport_connect(self):
        run_id = get_run_id()
        if not run_id:
            return await original_transport_connect(self)

        original_env = dict(getattr(self._options, "env", {}) or {})
        merged_env = _merged_transport_env(original_env)
        if merged_env.get("SOVARA_CLAUDE_PROXY_ACTIVE") == "1":
            return await original_transport_connect(self)

        upstream_base_url = merged_env.get("ANTHROPIC_BASE_URL") or _DEFAULT_ANTHROPIC_BASE_URL
        if _is_sovara_proxy_base_url(upstream_base_url):
            raise RuntimeError(_PROXY_LOOP_MESSAGE)
        client_id = getattr(self, "_sovara_claude_proxy_client_id", None)
        if not client_id:
            client_id = uuid.uuid4().hex
            self._sovara_claude_proxy_client_id = client_id

        runtime_client.register_claude_proxy_client(
            run_id,
            client_id,
            upstream_base_url,
            stack_trace=capture_stack_trace(),
        )

        proxy_env = {
            **merged_env,
            "ANTHROPIC_BASE_URL": _proxy_base_url(run_id, client_id),
            "SOVARA_CLAUDE_PROXY_ACTIVE": "1",
        }
        self._options = _replace_options_env(self._options, proxy_env)
        try:
            return await original_transport_connect(self)
        finally:
            self._options = _replace_options_env(self._options, original_env)

    message_parser.parse_message = patched_parse_message
    internal_client.parse_message = patched_parse_message
    sdk_client.parse_message = patched_parse_message
    internal_client.InternalClient.process_query = patched_process_query
    ClaudeSDKClient.connect = patched_client_connect
    SubprocessCLITransport.connect = patched_transport_connect

    logger.info("claude_agent_sdk patch applied")


def clear_sdk_run_data(run_id: str):
    """Retained for compatibility with older cleanup paths."""
    del run_id
