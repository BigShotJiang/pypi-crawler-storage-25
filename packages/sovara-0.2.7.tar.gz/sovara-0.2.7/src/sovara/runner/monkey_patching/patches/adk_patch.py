from __future__ import annotations

from functools import wraps
from typing import Any

from sovara.common.logger import logger
from sovara.runner.context_manager import get_run_id
from sovara.runner.monkey_patching.tool_trace_utils import (
    PreparedToolTrace,
    build_tool_success_output,
    prepare_tool_trace,
    publish_prepared_tool_output,
    record_prepared_tool_exception,
    record_prepared_tool_output,
    should_trace_tool,
)


API_TYPE = "google.adk.tools.BaseTool.run"
SOVARA_ADK_PLUGIN_NAME = "sovara_adk_tool_tracer"


def _tool_name(tool: Any) -> str:
    return str(getattr(tool, "name", None) or tool.__class__.__name__)


def _tool_meta(tool: Any, tool_context: Any) -> dict[str, Any]:
    meta = {
        "tool_class": tool.__class__.__name__,
    }
    invocation_context = getattr(tool_context, "_invocation_context", None)
    agent = getattr(invocation_context, "agent", None)
    agent_name = getattr(agent, "name", None)
    if agent_name:
        meta["agent_name"] = agent_name
    return meta


def _replace_tool_args(tool_args: dict[str, Any], prepared_input: dict[str, Any]) -> None:
    tool_args.clear()
    tool_args.update(prepared_input)


def adk_patch():
    try:
        from google.adk.plugins.base_plugin import BasePlugin
        from google.adk.plugins.plugin_manager import PluginManager
    except ImportError:
        logger.info("google.adk not installed, skipping ADK patches")
        return

    if getattr(PluginManager.__init__, "__sovara_adk_patched__", False):
        return

    class SovaraADKPlugin(BasePlugin):
        name = SOVARA_ADK_PLUGIN_NAME

        def __init__(self):
            self._pending: dict[str, PreparedToolTrace] = {}

        async def before_tool_callback(
            self,
            *,
            tool,
            tool_args: dict[str, Any],
            tool_context,
        ) -> dict[str, Any] | None:
            tool_call_id = getattr(tool_context, "function_call_id", None)
            if not should_trace_tool(tool_call_id):
                return None

            trace = prepare_tool_trace(
                tool_name=_tool_name(tool),
                tool_input=tool_args,
                tool_call_id=tool_call_id,
                api_type=API_TYPE,
                meta=_tool_meta(tool, tool_context),
            )
            self._pending[tool_call_id] = trace

            prepared_input = trace.prepared_call.input_dict.get("tool_input")
            if isinstance(prepared_input, dict):
                _replace_tool_args(tool_args, prepared_input)

            if trace.prepared_call.output is not None:
                publish_prepared_tool_output(trace, API_TYPE)
                self._pending.pop(tool_call_id, None)
                return trace.prepared_call.output

            return None

        async def after_tool_callback(
            self,
            *,
            tool,
            tool_args: dict[str, Any],
            tool_context,
            result: dict[str, Any],
        ) -> dict[str, Any] | None:
            del tool_args
            tool_call_id = getattr(tool_context, "function_call_id", None)
            trace = self._pending.pop(tool_call_id, None)
            if trace is None:
                return None

            record_prepared_tool_output(
                trace,
                build_tool_success_output(
                    tool_name=_tool_name(tool),
                    tool_call_id=trace.prepared_call.input_dict.get("tool_call_id", tool_call_id),
                    result=result,
                    meta=_tool_meta(tool, tool_context),
                ),
                API_TYPE,
            )
            return None

        async def on_tool_error_callback(
            self,
            *,
            tool,
            tool_args: dict[str, Any],
            tool_context,
            error: Exception,
        ) -> dict[str, Any] | None:
            del tool
            del tool_args
            tool_call_id = getattr(tool_context, "function_call_id", None)
            trace = self._pending.pop(tool_call_id, None)
            if trace is None:
                return None

            record_prepared_tool_exception(trace, error, API_TYPE)
            return None

        async def close(self) -> None:
            self._pending.clear()

    original_init = PluginManager.__init__

    @wraps(original_init)
    def patched_init(self, *args, **kwargs):
        original_init(self, *args, **kwargs)

        if not get_run_id():
            return

        if self.get_plugin(SOVARA_ADK_PLUGIN_NAME) is None:
            self.register_plugin(SovaraADKPlugin())

    patched_init.__sovara_adk_patched__ = True
    PluginManager.__init__ = patched_init
    logger.info("google.adk patch applied")
