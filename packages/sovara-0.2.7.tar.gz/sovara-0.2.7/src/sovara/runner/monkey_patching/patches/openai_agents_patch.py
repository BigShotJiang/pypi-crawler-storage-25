from __future__ import annotations

import asyncio
import json
from functools import wraps
from typing import Any

from sovara.common.logger import logger
from sovara.runner.context_manager import get_run_id
from sovara.runner.monkey_patching.tool_trace_utils import (
    PreparedToolTrace,
    build_prepared_tool_trace,
    build_tool_error_output,
    build_tool_success_output,
    normalize_jsonable,
)
from sovara.runner.node_execution import publish_prepared_call_output
from sovara.runner.string_matching import find_source_nodes
from sovara.server.database import DB

API_TYPE = "openai_agents.FunctionTool.run"
_TRACE_STATE_ATTR = "_sovara_openai_agents_trace_state"


def _tool_namespace(tool_call: Any, func_tool: Any) -> str | None:
    namespace = getattr(tool_call, "namespace", None) or getattr(func_tool, "_tool_namespace", None)
    return namespace if isinstance(namespace, str) and namespace else None


def _qualified_tool_name(tool_name: str, namespace: str | None) -> str:
    return f"{namespace}.{tool_name}" if namespace else tool_name


def _parse_tool_arguments(arguments: str) -> tuple[dict[str, Any] | None, str | None]:
    if not arguments:
        return {}, None

    try:
        parsed = json.loads(arguments)
    except Exception as exc:
        return None, f"Invalid JSON arguments: {exc}"

    if not isinstance(parsed, dict):
        return None, "Tool arguments must decode to a JSON object."

    return parsed, None


def _build_input_dict(func_tool: Any, tool_call: Any) -> dict[str, Any]:
    tool_name = str(func_tool.name)
    namespace = _tool_namespace(tool_call, func_tool)
    arguments = str(getattr(tool_call, "arguments", "") or "")
    parsed_input, parse_error = _parse_tool_arguments(arguments)

    payload = {
        "tool_name": tool_name,
        "tool_call_id": str(getattr(tool_call, "call_id", "") or ""),
        "_meta": {
            "tool_class": func_tool.__class__.__name__,
            "strict_json_schema": bool(getattr(func_tool, "strict_json_schema", False)),
            "is_agent_tool": bool(getattr(func_tool, "_is_agent_tool", False)),
            "defer_loading": bool(getattr(func_tool, "defer_loading", False)),
        },
    }

    if namespace:
        payload["tool_namespace"] = namespace
    payload["qualified_tool_name"] = _qualified_tool_name(tool_name, namespace)

    if parse_error is None:
        normalized_input = normalize_jsonable(parsed_input)
        payload["tool_input"] = normalized_input
        payload["tool_input_json"] = json.dumps(normalized_input, sort_keys=True)
    else:
        payload["tool_arguments_raw"] = arguments
        payload["_meta"]["arguments_error"] = parse_error

    return payload


def _normalize_result(func_tool: Any, tool_call: Any, result: Any) -> dict[str, Any]:
    return build_tool_success_output(
        tool_name=str(func_tool.name),
        tool_call_id=str(getattr(tool_call, "call_id", "") or ""),
        result=result,
    )


def _normalize_error(func_tool: Any, tool_call: Any, exc: Exception) -> dict[str, Any]:
    return build_tool_error_output(
        tool_name=str(func_tool.name),
        tool_call_id=str(getattr(tool_call, "call_id", "") or ""),
        exc=exc,
    )


def _sdk_result_from_cached_output(output_obj: Any) -> Any:
    if not isinstance(output_obj, dict):
        return output_obj
    if output_obj.get("status") == "error":
        return output_obj.get("error_message") or output_obj.get("tool_output") or output_obj
    if "tool_output" in output_obj:
        return output_obj["tool_output"]
    return output_obj


def _exception_from_cached_output(output_obj: Any) -> Exception | None:
    if not isinstance(output_obj, dict) or output_obj.get("status") != "error":
        return None

    from agents.exceptions import UserError

    message = output_obj.get("error_message") or output_obj.get("tool_output") or "Tool failed."
    tool_name = output_obj.get("tool_name") or "tool"
    return UserError(f"Error running tool {tool_name}: {message}")


def _apply_input_dict_to_tool_call(
    tool_call: Any, tool_context: Any, input_dict: dict[str, Any]
) -> None:
    if "tool_input" in input_dict:
        arguments = json.dumps(input_dict["tool_input"])
        tool_input = input_dict["tool_input"]
    elif "tool_arguments_raw" in input_dict:
        arguments = str(input_dict["tool_arguments_raw"])
        tool_input = None
    else:
        arguments = "{}"
        tool_input = {}

    tool_call.arguments = arguments
    tool_context.tool_arguments = arguments
    tool_context.tool_call = tool_call
    tool_context.tool_input = tool_input


def _set_trace_state(task_state: Any, trace: PreparedToolTrace) -> None:
    setattr(task_state, _TRACE_STATE_ATTR, trace)


def _get_trace_state(task_state: Any) -> PreparedToolTrace | None:
    trace_state = getattr(task_state, _TRACE_STATE_ATTR, None)
    if trace_state is None:
        return None
    if isinstance(trace_state, PreparedToolTrace):
        return trace_state
    prepared_call, source_node_ids = trace_state
    return PreparedToolTrace(prepared_call=prepared_call, source_node_ids=list(source_node_ids))


def _publish_tool_result(trace: PreparedToolTrace, output_obj: dict[str, Any]) -> None:
    prepared_call = trace.prepared_call
    current_output = prepared_call.output
    if current_output != output_obj:
        DB.cache_output(prepared_call, output_obj, API_TYPE)
    else:
        prepared_call.output = output_obj

    publish_prepared_call_output(
        prepared_call=prepared_call,
        api_type=API_TYPE,
        source_node_ids=trace.source_node_ids,
    )


def openai_agents_patch() -> None:
    try:
        from agents.run_internal import tool_execution
        from agents.util import _coro
    except ImportError:
        logger.info("openai-agents not installed, skipping openai-agents patches")
        return

    batch_executor_cls = tool_execution._FunctionToolBatchExecutor
    if getattr(batch_executor_cls, "__sovara_openai_agents_patched__", False):
        return

    original_execute_single_tool_body = batch_executor_cls._execute_single_tool_body
    original_invoke_tool_and_run_post_invoke = batch_executor_cls._invoke_tool_and_run_post_invoke

    @wraps(original_execute_single_tool_body)
    async def patched_execute_single_tool_body(
        self,
        *,
        outer_task,
        task_state,
        func_tool,
        tool_call,
        tool_context,
        agent_hooks,
    ):
        if not get_run_id():
            return await original_execute_single_tool_body(
                self,
                outer_task=outer_task,
                task_state=task_state,
                func_tool=func_tool,
                tool_call=tool_call,
                tool_context=tool_context,
                agent_hooks=agent_hooks,
            )

        input_dict = _build_input_dict(func_tool, tool_call)
        trace = build_prepared_tool_trace(
            DB.get_in_out(input_dict, API_TYPE),
            API_TYPE,
            source_finder=find_source_nodes,
        )
        _set_trace_state(task_state, trace)
        _apply_input_dict_to_tool_call(tool_call, tool_context, trace.prepared_call.input_dict)

        return await original_execute_single_tool_body(
            self,
            outer_task=outer_task,
            task_state=task_state,
            func_tool=func_tool,
            tool_call=tool_call,
            tool_context=tool_context,
            agent_hooks=agent_hooks,
        )

    @wraps(original_invoke_tool_and_run_post_invoke)
    async def patched_invoke_tool_and_run_post_invoke(
        self,
        *,
        outer_task,
        task_state,
        func_tool,
        tool_call,
        tool_context,
        agent_hooks,
    ):
        trace_state = _get_trace_state(task_state)
        if not get_run_id() or trace_state is None:
            return await original_invoke_tool_and_run_post_invoke(
                self,
                outer_task=outer_task,
                task_state=task_state,
                func_tool=func_tool,
                tool_call=tool_call,
                tool_context=tool_context,
                agent_hooks=agent_hooks,
            )

        prepared_call = trace_state.prepared_call
        replay_exception = _exception_from_cached_output(prepared_call.output)
        if replay_exception is not None:
            _publish_tool_result(trace_state, prepared_call.output)
            raise replay_exception

        try:
            if prepared_call.output is None:
                final_result = await original_invoke_tool_and_run_post_invoke(
                    self,
                    outer_task=outer_task,
                    task_state=task_state,
                    func_tool=func_tool,
                    tool_call=tool_call,
                    tool_context=tool_context,
                    agent_hooks=agent_hooks,
                )
            else:
                real_result = _sdk_result_from_cached_output(prepared_call.output)
                task_state.in_post_invoke_phase = True
                final_result = await tool_execution._execute_tool_output_guardrails(
                    func_tool=func_tool,
                    tool_context=tool_context,
                    agent=self.agent,
                    real_result=real_result,
                    tool_output_guardrail_results=self.tool_output_guardrail_results,
                )
                await asyncio.gather(
                    self.hooks.on_tool_end(tool_context, self.agent, func_tool, final_result),
                    (
                        agent_hooks.on_tool_end(tool_context, self.agent, func_tool, final_result)
                        if agent_hooks
                        else _coro.noop_coroutine()
                    ),
                )

            output_obj = _normalize_result(func_tool, tool_call, final_result)
            _publish_tool_result(trace_state, output_obj)
            return final_result
        except Exception as exc:
            output_obj = _normalize_error(func_tool, tool_call, exc)
            _publish_tool_result(trace_state, output_obj)
            raise

    batch_executor_cls._execute_single_tool_body = patched_execute_single_tool_body
    batch_executor_cls._invoke_tool_and_run_post_invoke = patched_invoke_tool_and_run_post_invoke
    batch_executor_cls.__sovara_openai_agents_patched__ = True
    logger.info("openai-agents FunctionTool patch applied")
