from functools import wraps

from sovara.runner.context_manager import get_run_id
from sovara.runner.monkey_patching.api_parsers.aiohttp_api_parser import (
    build_replay_aiohttp_response,
)
from sovara.runner.monkey_patching.async_streaming import CapturingAsyncByteStream
from sovara.runner.monkey_patching.patching_utils import (
    get_input_dict,
    is_whitelisted_endpoint,
    send_graph_node_and_edges,
)
from sovara.runner.priors import persist_prior_metadata
from sovara.runner.string_matching import find_source_nodes, store_output_strings
from sovara.runner.runtime_client import runtime_client
from sovara.runner.node_execution import (
    build_exception_output,
    publish_prepared_call_output,
    record_prepared_call_exception,
)
from sovara.common.logger import logger

API_TYPE = "aiohttp.ClientSession._request"


def _get_response_encoding(response) -> str:
    try:
        return response.get_encoding()
    except Exception:
        return "utf-8"


def _finalize_capture(captured_call, response, source_node_ids, *, error=None, incomplete_details=None):
    replay_response = build_replay_aiohttp_response(
        status=response.status,
        reason=response.reason,
        headers=dict(response.headers.items()),
        request_url=str(response.url),
        body_bytes=captured_call["body_bytes"],
        method=getattr(response, "method", captured_call["method"]),
        encoding=_get_response_encoding(response),
        error=error,
        incomplete_details=incomplete_details,
    )

    runtime_client.record_output(
        prepared_call=captured_call["prepared_call"],
        output_obj=replay_response,
        api_type=API_TYPE,
    )
    publish_prepared_call_output(
        prepared_call=captured_call["prepared_call"],
        api_type=API_TYPE,
        source_node_ids=source_node_ids,
        prior_result=captured_call["prior_result"],
        persist_prior_metadata_func=persist_prior_metadata,
        store_output_strings_func=store_output_strings,
        send_graph_node_and_edges_func=send_graph_node_and_edges,
    )


def _attach_capture(response, prepared_call, source_node_ids, prior_result):
    state = {
        "prepared_call": prepared_call,
        "prior_result": prior_result,
        "body_bytes": b"",
        "finalized": False,
        "method": prepared_call.input_dict.get("method", "GET"),
    }

    def finalize(body_bytes, *, error=None, incomplete_details=None):
        if state["finalized"]:
            return
        state["finalized"] = True
        state["body_bytes"] = body_bytes
        _finalize_capture(
            state,
            response,
            source_node_ids,
            error=error,
            incomplete_details=incomplete_details,
        )

    content_proxy = CapturingAsyncByteStream(response.content, finalize)
    response.content = content_proxy

    original_release = response.release
    original_close = response.close

    @wraps(original_release)
    def patched_release(*args, **kwargs):
        content_proxy.finalize_incomplete(
            "stream_abandoned",
            "Stream closed before EOF.",
        )
        return original_release(*args, **kwargs)

    @wraps(original_close)
    def patched_close(*args, **kwargs):
        content_proxy.finalize_incomplete(
            "stream_abandoned",
            "Stream closed before EOF.",
        )
        return original_close(*args, **kwargs)

    response.release = patched_release
    response.close = patched_close
    return response


def aiohttp_patch():
    try:
        from aiohttp import ClientSession
    except ImportError:
        logger.info("aiohttp not installed, skipping aiohttp patches")
        return

    def create_patched_init(original_init):

        @wraps(original_init)
        def patched_init(self, *args, **kwargs):
            original_init(self, *args, **kwargs)
            patch_aiohttp_request(self, type(self))

        return patched_init

    ClientSession.__init__ = create_patched_init(ClientSession.__init__)


def patch_aiohttp_request(bound_obj, bound_cls):
    if getattr(bound_obj, "_sovara_aiohttp_request_patched", False):
        return

    original_function = bound_obj._request

    @wraps(original_function)
    async def patched_function(self, *args, **kwargs):
        input_dict = get_input_dict(original_function, *args, **kwargs)

        url = str(input_dict.get("str_or_url", ""))
        params = input_dict.get("params")
        if params:
            from yarl import URL

            url = str(URL(url).update_query(params))
        path = url
        try:
            from yarl import URL

            path = URL(url).path
        except Exception:
            pass

        if not is_whitelisted_endpoint(url, path):
            return await original_function(*args, **kwargs)

        source_node_ids = find_source_nodes(get_run_id(), input_dict, API_TYPE)
        prepared_call = runtime_client.prepare_call(input_dict, API_TYPE, prepare_runtime_priors=True)
        prior_result = prepared_call.prior_result

        if prepared_call.output is not None:
            publish_prepared_call_output(
                prepared_call=prepared_call,
                api_type=API_TYPE,
                source_node_ids=source_node_ids,
                prior_result=prior_result,
                persist_prior_metadata_func=persist_prior_metadata,
                store_output_strings_func=store_output_strings,
                send_graph_node_and_edges_func=send_graph_node_and_edges,
            )
            return prepared_call.output

        try:
            response = await original_function(**prepared_call.input_dict)
        except Exception as exc:
            record_prepared_call_exception(
                prepared_call=prepared_call,
                exc=exc,
                api_type=API_TYPE,
                source_node_ids=source_node_ids,
                record_exception_func=runtime_client.record_exception,
                send_graph_node_and_edges_func=send_graph_node_and_edges,
                build_exception_output_func=build_exception_output,
            )
            raise
        return _attach_capture(response, prepared_call, source_node_ids, prior_result)

    bound_obj._request = patched_function.__get__(bound_obj, bound_cls)
    bound_obj._sovara_aiohttp_request_patched = True
