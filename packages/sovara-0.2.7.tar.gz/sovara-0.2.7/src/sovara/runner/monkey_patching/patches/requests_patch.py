from functools import wraps
from sovara.runner.monkey_patching.patching_utils import (
    get_input_dict,
    send_graph_node_and_edges,
)
from sovara.runner.string_matching import find_source_nodes, store_output_strings
from sovara.runner.context_manager import get_run_id
from sovara.runner.priors import persist_prior_metadata, restore_input_after_call
from sovara.runner.runtime_client import runtime_client
from sovara.runner.node_execution import (
    build_exception_output,
    publish_prepared_call_output,
    record_prepared_call_exception,
)
from sovara.common.logger import logger
from sovara.runner.monkey_patching.patching_utils import is_whitelisted_endpoint


def requests_patch():
    try:
        from requests import Session
    except ImportError:
        logger.info("requests not installed, skipping requests patches")
        return

    def create_patched_init(original_init):

        @wraps(original_init)
        def patched_init(self, *args, **kwargs):
            original_init(self, *args, **kwargs)
            patch_requests_send(self, type(self))

        return patched_init

    Session.__init__ = create_patched_init(Session.__init__)


def patch_requests_send(bound_obj, bound_cls):
    original_function = bound_obj.send

    @wraps(original_function)
    def patched_function(self, *args, **kwargs):

        api_type = "requests.Session.send"

        input_dict = get_input_dict(original_function, *args, **kwargs)

        request = input_dict["request"]
        url = str(request.url)
        path = request.path_url
        if not is_whitelisted_endpoint(url, path):
            return original_function(*args, **kwargs)

        source_node_ids = find_source_nodes(get_run_id(), input_dict, api_type)

        # Get result from cache or call LLM
        prepared_call = runtime_client.prepare_call(input_dict, api_type, prepare_runtime_priors=True)
        prior_result = prepared_call.prior_result
        with restore_input_after_call(prior_result):
            if prepared_call.output is None:
                try:
                    result = original_function(**prepared_call.input_dict)  # Call LLM
                except Exception as exc:
                    record_prepared_call_exception(
                        prepared_call=prepared_call,
                        exc=exc,
                        api_type=api_type,
                        source_node_ids=source_node_ids,
                        record_exception_func=runtime_client.record_exception,
                        send_graph_node_and_edges_func=send_graph_node_and_edges,
                        build_exception_output_func=build_exception_output,
                    )
                    raise
                runtime_client.record_output(
                    prepared_call=prepared_call,
                    output_obj=result,
                    api_type=api_type,
                )
            publish_prepared_call_output(
                prepared_call=prepared_call,
                api_type=api_type,
                source_node_ids=source_node_ids,
                prior_result=prior_result,
                persist_prior_metadata_func=persist_prior_metadata,
                store_output_strings_func=store_output_strings,
                send_graph_node_and_edges_func=send_graph_node_and_edges,
            )

            return prepared_call.output

    bound_obj.send = patched_function.__get__(bound_obj, bound_cls)
