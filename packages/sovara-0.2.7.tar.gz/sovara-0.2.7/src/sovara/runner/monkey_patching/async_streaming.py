import asyncio
from typing import Any, Callable

try:
    from aiohttp.streams import AsyncStreamIterator, ChunkTupleAsyncStreamIterator
except ImportError:  # pragma: no cover - exercised indirectly by import safety
    class AsyncStreamIterator:
        def __init__(self, read_func):
            self._read_func = read_func

        def __aiter__(self):
            return self

        async def __anext__(self):
            item = await self._read_func()
            if item == b"" or item == (b"", False):
                raise StopAsyncIteration
            return item

    class ChunkTupleAsyncStreamIterator:
        def __init__(self, stream):
            self._stream = stream

        def __aiter__(self):
            return self

        async def __anext__(self):
            item = await self._stream.readchunk()
            if item == (b"", False):
                raise StopAsyncIteration
            return item


def exception_to_error_dict(exc: BaseException) -> dict[str, str]:
    message = str(exc) or exc.__class__.__name__
    return {
        "type": exc.__class__.__name__,
        "message": message,
    }


class ReplayAsyncStreamError(RuntimeError):
    """Raised by replayed async streams when the original stream ended in error."""

    def __init__(self, message: str, *, error_type: str | None = None):
        super().__init__(message)
        self.error_type = error_type


class ReplayAsyncByteStream:
    """In-memory async byte stream with optional terminal error replay."""

    def __init__(self, body: bytes, *, error: dict[str, str] | None = None):
        self._body = body
        self._cursor = 0
        self._exception: BaseException | None = None
        self._error = error
        self._error_raised = False
        self._eof_callbacks: list[Callable[[], None]] = []

    def _remaining(self) -> bytes:
        return self._body[self._cursor :]

    def _emit_eof_callbacks(self) -> None:
        callbacks = list(self._eof_callbacks)
        self._eof_callbacks.clear()
        for callback in callbacks:
            callback()

    def _advance(self, chunk: bytes) -> bytes:
        self._cursor += len(chunk)
        if self._cursor >= len(self._body):
            self._emit_eof_callbacks()
        return chunk

    def _raise_terminal_error(self) -> None:
        if self._error is None or self._error_raised:
            return
        self._error_raised = True
        error_type = self._error.get("type")
        message = self._error.get("message") or "Captured stream ended with an error."
        if error_type:
            raise ReplayAsyncStreamError(f"{error_type}: {message}", error_type=error_type)
        raise ReplayAsyncStreamError(message)

    def exception(self) -> BaseException | None:
        return self._exception

    def set_exception(self, exc: BaseException, exc_cause: BaseException | object = object()) -> None:
        del exc_cause
        self._exception = exc

    def at_eof(self) -> bool:
        return self._cursor >= len(self._body)

    def on_eof(self, callback: Callable[[], None]) -> None:
        if self.at_eof():
            callback()
        else:
            self._eof_callbacks.append(callback)

    async def readline(self) -> bytes:
        if self._cursor >= len(self._body):
            self._raise_terminal_error()
            return b""

        newline_idx = self._body.find(b"\n", self._cursor)
        if newline_idx == -1:
            chunk = self._body[self._cursor :]
        else:
            chunk = self._body[self._cursor : newline_idx + 1]
        return self._advance(chunk)

    async def read(self, n: int = -1) -> bytes:
        if self._cursor >= len(self._body):
            self._raise_terminal_error()
            return b""

        if n is None or n < 0:
            chunk = self._body[self._cursor :]
            self._advance(chunk)
            self._raise_terminal_error()
            return chunk

        chunk = self._body[self._cursor : self._cursor + n]
        return self._advance(chunk)

    async def readany(self) -> bytes:
        if self._cursor >= len(self._body):
            self._raise_terminal_error()
            return b""

        chunk = self._body[self._cursor :]
        return self._advance(chunk)

    async def readexactly(self, n: int) -> bytes:
        remaining = self._remaining()
        if len(remaining) < n:
            if self._error is not None:
                self._cursor = len(self._body)
                self._emit_eof_callbacks()
                self._raise_terminal_error()
            partial = self._advance(remaining)
            raise asyncio.IncompleteReadError(partial=partial, expected=n)

        chunk = remaining[:n]
        return self._advance(chunk)

    async def readchunk(self) -> tuple[bytes, bool]:
        if self._cursor >= len(self._body):
            self._raise_terminal_error()
            return b"", False

        chunk = self._body[self._cursor :]
        self._advance(chunk)
        return chunk, True

    def __aiter__(self) -> AsyncStreamIterator[bytes]:
        return AsyncStreamIterator(self.readline)

    def iter_any(self) -> AsyncStreamIterator[bytes]:
        return AsyncStreamIterator(self.readany)

    def iter_chunked(self, n: int) -> AsyncStreamIterator[bytes]:
        return AsyncStreamIterator(lambda: self.read(n))

    def iter_chunks(self) -> ChunkTupleAsyncStreamIterator:
        return ChunkTupleAsyncStreamIterator(self)


class CapturingAsyncByteStream:
    """Proxy an async byte stream while capturing the bytes the user consumes."""

    def __init__(
        self,
        stream: Any,
        finalize: Callable[..., Any],
    ):
        self._stream = stream
        self._finalize = finalize
        self._buffer = bytearray()
        self._exception: BaseException | None = None
        self._eof_callbacks: list[Callable[[], None]] = []
        self._finalized = False

    def _append(self, chunk: bytes) -> None:
        if chunk:
            self._buffer.extend(chunk)

    def _emit_eof_callbacks(self) -> None:
        callbacks = list(self._eof_callbacks)
        self._eof_callbacks.clear()
        for callback in callbacks:
            callback()

    def _finalize_once(
        self,
        *,
        error: dict[str, str] | None = None,
        incomplete_details: dict[str, str] | None = None,
    ) -> None:
        if self._finalized:
            return
        self._finalized = True
        self._emit_eof_callbacks()
        self._finalize(
            bytes(self._buffer),
            error=error,
            incomplete_details=incomplete_details,
        )

    def finalize_incomplete(self, reason: str, message: str) -> None:
        if self.at_eof():
            self._finalize_once()
            return
        self._finalize_once(
            incomplete_details={
                "reason": reason,
                "message": message,
            }
        )

    def exception(self) -> BaseException | None:
        return self._exception or self._stream.exception()

    def set_exception(self, exc: BaseException, exc_cause: BaseException | object = object()) -> None:
        self._exception = exc
        if hasattr(self._stream, "set_exception"):
            self._stream.set_exception(exc, exc_cause)

    def at_eof(self) -> bool:
        return self._stream.at_eof()

    def on_eof(self, callback: Callable[[], None]) -> None:
        if self.at_eof():
            callback()
        else:
            self._eof_callbacks.append(callback)

    def _maybe_finalize_complete(self) -> None:
        if self._stream.at_eof():
            self._finalize_once()

    def _finalize_error(self, exc: BaseException) -> None:
        self._exception = exc
        self._finalize_once(
            error=exception_to_error_dict(exc),
            incomplete_details={
                "reason": "stream_error",
                "message": "Stream read failed before EOF.",
            },
        )

    async def readline(self) -> bytes:
        try:
            chunk = await self._stream.readline()
        except Exception as exc:
            self._finalize_error(exc)
            raise
        self._append(chunk)
        self._maybe_finalize_complete()
        return chunk

    async def read(self, n: int = -1) -> bytes:
        try:
            chunk = await self._stream.read(n)
        except asyncio.IncompleteReadError as exc:
            self._append(exc.partial)
            self._finalize_error(exc)
            raise
        except Exception as exc:
            self._finalize_error(exc)
            raise
        self._append(chunk)
        self._maybe_finalize_complete()
        return chunk

    async def readany(self) -> bytes:
        try:
            chunk = await self._stream.readany()
        except Exception as exc:
            self._finalize_error(exc)
            raise
        self._append(chunk)
        self._maybe_finalize_complete()
        return chunk

    async def readexactly(self, n: int) -> bytes:
        try:
            chunk = await self._stream.readexactly(n)
        except asyncio.IncompleteReadError as exc:
            self._append(exc.partial)
            self._finalize_error(exc)
            raise
        except Exception as exc:
            self._finalize_error(exc)
            raise
        self._append(chunk)
        self._maybe_finalize_complete()
        return chunk

    async def readchunk(self) -> tuple[bytes, bool]:
        try:
            chunk, end_of_http_chunk = await self._stream.readchunk()
        except Exception as exc:
            self._finalize_error(exc)
            raise
        self._append(chunk)
        self._maybe_finalize_complete()
        return chunk, end_of_http_chunk

    def __aiter__(self) -> AsyncStreamIterator[bytes]:
        return AsyncStreamIterator(self.readline)

    def iter_any(self) -> AsyncStreamIterator[bytes]:
        return AsyncStreamIterator(self.readany)

    def iter_chunked(self, n: int) -> AsyncStreamIterator[bytes]:
        return AsyncStreamIterator(lambda: self.read(n))

    def iter_chunks(self) -> ChunkTupleAsyncStreamIterator:
        return ChunkTupleAsyncStreamIterator(self)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)
