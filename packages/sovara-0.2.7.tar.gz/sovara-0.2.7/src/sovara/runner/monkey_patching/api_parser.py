import json
import re
from typing import Any, Dict
from flatten_json import flatten
from flatten_dict import unflatten, flatten as flatten_keep_list
from sovara.runner.monkey_patching.api_parsers.mcp_api_parser import (
    func_kwargs_to_json_str_mcp,
    api_obj_to_json_str_mcp,
    json_str_to_api_obj_mcp,
    json_str_to_original_inp_dict_mcp,
)
from sovara.runner.monkey_patching.api_parsers.httpx_api_parser import (
    func_kwargs_to_json_str_httpx,
    api_obj_to_json_str_httpx,
    json_str_to_api_obj_httpx,
    json_str_to_original_inp_dict_httpx,
)
from sovara.runner.monkey_patching.api_parsers.aiohttp_api_parser import (
    func_kwargs_to_json_str_aiohttp,
    api_obj_to_json_str_aiohttp,
    json_str_to_api_obj_aiohttp,
    json_str_to_original_inp_dict_aiohttp,
)
from sovara.runner.monkey_patching.api_parsers.requests_api_parser import (
    func_kwargs_to_json_str_requests,
    api_obj_to_json_str_requests,
    json_str_to_api_obj_requests,
    json_str_to_original_inp_dict_requests,
)
from sovara.runner.monkey_patching.api_parsers.claude_code_messages_api_parser import (
    build_to_show_claude_code_messages_output,
    func_kwargs_to_json_str_claude_code_messages,
    api_obj_to_json_str_claude_code_messages,
    json_str_to_api_obj_claude_code_messages,
    json_str_to_original_inp_dict_claude_code_messages,
)
from sovara.runner.monkey_patching.api_parsers.urllib3_api_parser import (
    func_kwargs_to_json_str_urllib3,
    api_obj_to_json_str_urllib3,
    json_str_to_api_obj_urllib3,
    json_str_to_original_inp_dict_urllib3,
)
from sovara.runner.monkey_patching.edit_io_filters import COMPILED_EDIT_IO_EXCLUDE_PATTERNS


def flatten_to_show(inp):
    """
    Does this transformation:
    {"a": [{"b": {"c": 1}}], "d": 2} -> {"a": ["b.c": 1], "a.d": 2}
    This is nice to visualize since lists can be expanded (default)/collapsed
    but inside the lists, dicts are still flattened.
    """
    if isinstance(inp, dict):
        flattened = flatten_keep_list(inp, reducer="dot")
        flattened_lists = {}
        for key, value in flattened.items():
            if isinstance(value, list):
                flattened_lists[key] = [flatten_to_show(el) for el in value]
        for key, value in flattened_lists.items():
            flattened[key] = value
    else:
        flattened = inp
    return flattened


def unflatten_to_show(inp):
    """
    Reverts flatten_to_show.
    """
    if isinstance(inp, dict):
        unflattened_dict = unflatten(inp, splitter="dot")
        unflattened_lists = {}
        for key, value in unflattened_dict.items():
            if isinstance(value, list):
                unflattened_lists[key] = [unflatten_to_show(el) for el in value]

        for key, value in unflattened_lists.items():
            unflattened_dict[key] = value
    else:
        unflattened_dict = inp
    return unflattened_dict


def _convert_dense_numeric_dicts_to_lists(value: Any) -> Any:
    """Convert nested ``{"0": ..., "1": ...}`` mappings into ordered lists."""
    if isinstance(value, dict):
        converted = {
            key: _convert_dense_numeric_dicts_to_lists(child) for key, child in value.items()
        }
        if not converted:
            return converted

        numeric_key_map: dict[int, str] = {}
        for key in converted:
            if not isinstance(key, str) or not key.isdigit():
                return converted
            index = int(key)
            if index in numeric_key_map:
                return converted
            numeric_key_map[index] = key

        if sorted(numeric_key_map.keys()) != list(range(len(converted))):
            return converted

        return [converted[numeric_key_map[index]] for index in range(len(converted))]

    if isinstance(value, list):
        return [_convert_dense_numeric_dicts_to_lists(item) for item in value]

    return value


def ordered_unflatten_list(flat_dict: dict[str, Any], separator: str = ".") -> Any:
    """Unflatten a mapping without reordering sibling keys while still restoring lists."""
    if not flat_dict:
        return {}

    splitter: str | Any
    if separator == ".":
        splitter = "dot"
    else:
        splitter = lambda key: tuple(key.split(separator))

    nested = unflatten(flat_dict, splitter=splitter)
    return _convert_dense_numeric_dicts_to_lists(nested)


def flatten_complete_to_show(to_show: dict[str, Any] | list[Any] | str | None) -> dict[str, Any]:
    """Fully flatten a stored ``to_show`` payload, including list indices."""
    if to_show is None:
        return {}
    if isinstance(to_show, dict):
        nested = unflatten_to_show(to_show)
        return flatten(nested, ".")
    if isinstance(to_show, list):
        return flatten(to_show, ".")
    return {"value": to_show}


def restore_complete_to_show_from_flattened(
    flattened_to_show: dict[str, Any],
) -> dict[str, Any] | list[Any] | str | None:
    """Rebuild a stored ``to_show`` payload from a fully flattened mapping."""
    if not flattened_to_show:
        return {}
    if set(flattened_to_show.keys()) == {"value"}:
        return flattened_to_show["value"]
    nested = ordered_unflatten_list(flattened_to_show, ".")
    return flatten_to_show(nested)


def should_exclude_key(key: str) -> bool:
    """Check if a flattened key should be excluded based on regex patterns."""
    for pattern in COMPILED_EDIT_IO_EXCLUDE_PATTERNS:
        if pattern.match(key):
            return True
    return False


def filter_dict(input_dict: dict) -> dict:
    """Filter a dictionary by excluding keys matching exclude patterns."""
    flattened = flatten(input_dict, ".")
    filtered = {
        k: v for k, v in flattened.items() if not should_exclude_key(k) and not (v == [] or v == {})
    }
    unflattened = ordered_unflatten_list(filtered, ".")
    flattened_list_preserved = flatten_to_show(unflattened)
    return flattened_list_preserved


def merge_filtered_into_raw(raw_dict: dict, to_show_dict: dict) -> dict:
    """
    Merge values from to_show back into raw_dict.
    This updates the values in raw that exist in to_show while preserving structure and types.

    Important: Preserves numeric types (float vs int) from raw_dict to avoid API validation errors.
    For example, if raw has temperature: 0.0, we keep it as float even if JSON parsing made it 0.
    """
    # flatten the raw dict. the to-show is already flattened
    flattened_raw = flatten(raw_dict, ".")
    flattened_to_show = flatten_complete_to_show(to_show_dict)

    # Update raw values with to_show values, preserving types from raw
    for key, value in flattened_to_show.items():
        if key in flattened_raw:
            flattened_raw[key] = value

    return ordered_unflatten_list(flattened_raw, ".")


def func_kwargs_to_json_str(input_dict: Dict[str, Any], api_type: str) -> str:
    """
    Convert function kwargs to JSON string with filtered display version.

    Args:
        input_dict: Input dictionary containing function arguments
        api_type: The API type identifier

    Returns:
        JSON string with raw and to_show
    """
    # Get the complete JSON string from the appropriate parser
    if api_type == "requests.Session.send":
        complete_json_str = func_kwargs_to_json_str_requests(input_dict)
    elif api_type in ["httpx.Client.send", "httpx.AsyncClient.send"]:
        complete_json_str = func_kwargs_to_json_str_httpx(input_dict)
    elif api_type == "aiohttp.ClientSession._request":
        complete_json_str = func_kwargs_to_json_str_aiohttp(input_dict)
    elif api_type == "MCP.ClientSession.send_request":
        complete_json_str = func_kwargs_to_json_str_mcp(input_dict)
    elif api_type == "claude_agent_sdk.parse_message":
        complete_json_str = json.dumps(input_dict)
    elif api_type == "claude_code.messages":
        complete_json_str = func_kwargs_to_json_str_claude_code_messages(input_dict)
    elif api_type in {"langchain_core.tools.BaseTool.run", "openai_agents.FunctionTool.run"}:
        complete_json_str = json.dumps(input_dict)
    elif api_type == "google.adk.tools.BaseTool.run":
        complete_json_str = json.dumps(input_dict)
    elif api_type == "urllib3.HTTPConnectionPool.urlopen":
        complete_json_str = func_kwargs_to_json_str_urllib3(input_dict)
    else:
        raise ValueError(f"Unknown API type {api_type}")

    # Parse the JSON string to get the raw dict
    raw_dict = json.loads(complete_json_str)

    # Filter the dict to create the display version
    to_show_dict = filter_dict(raw_dict)

    # Construct the wrapped format
    complete_dict = {"raw": raw_dict, "to_show": to_show_dict}

    # Return the wrapped JSON string
    return json.dumps(complete_dict)


def json_str_to_original_inp_dict(json_str: str, input_dict: dict, api_type: str) -> dict:
    """
    Unpack the wrapped format and merge filtered values back into raw.

    Args:
        json_str: JSON string in format {"raw": {...}, "to_show": {...}}
        input_dict: Original input dictionary
        api_type: The API type identifier

    Returns:
        Updated input_dict with merged values
    """
    # Parse the wrapped format
    complete_dict = json.loads(json_str)

    # Extract raw and to_show
    raw_dict = complete_dict["raw"]
    to_show_dict = complete_dict["to_show"]

    # Merge to_show values back into raw
    merged_dict = merge_filtered_into_raw(raw_dict, to_show_dict)

    # Convert back to JSON string
    merged_json_str = json.dumps(merged_dict)

    # Feed to the appropriate parser
    if api_type == "requests.Session.send":
        return json_str_to_original_inp_dict_requests(merged_json_str, input_dict)
    elif api_type in ["httpx.Client.send", "httpx.AsyncClient.send"]:
        return json_str_to_original_inp_dict_httpx(merged_json_str, input_dict)
    elif api_type == "aiohttp.ClientSession._request":
        return json_str_to_original_inp_dict_aiohttp(merged_json_str, input_dict)
    elif api_type == "MCP.ClientSession.send_request":
        return json_str_to_original_inp_dict_mcp(merged_json_str, input_dict)
    elif api_type == "claude_agent_sdk.parse_message":
        return json.loads(merged_json_str)
    elif api_type == "claude_code.messages":
        return json_str_to_original_inp_dict_claude_code_messages(merged_json_str, input_dict)
    elif api_type in {"langchain_core.tools.BaseTool.run", "openai_agents.FunctionTool.run"}:
        return json.loads(merged_json_str)
    elif api_type == "google.adk.tools.BaseTool.run":
        return json.loads(merged_json_str)
    elif api_type == "urllib3.HTTPConnectionPool.urlopen":
        return json_str_to_original_inp_dict_urllib3(merged_json_str, input_dict)
    else:
        return merged_dict


def replace_to_show_in_input_dict(
    input_dict: dict,
    api_type: str,
    to_show: dict[str, Any] | list[Any] | str | None,
) -> dict:
    """
    Rebuild the transport payload from ``to_show`` and apply it to ``input_dict`` in place.

    The current policy is to override the original request object rather than clone it.
    Callers should treat ``input_dict`` as the mutable executed request state.
    """
    complete_json_str = func_kwargs_to_json_str(input_dict, api_type)
    complete_input = json.loads(complete_json_str)
    merged_raw = merge_filtered_into_raw(complete_input["raw"], to_show)
    wrapped = json.dumps({"raw": merged_raw, "to_show": to_show})
    return json_str_to_original_inp_dict(wrapped, input_dict, api_type)


def api_obj_to_json_str(response_obj: Any, api_type: str) -> str:
    """
    Convert API response object to JSON string with filtered display version.

    Args:
        response_obj: The response object from the API call
        api_type: The API type identifier

    Returns:
        JSON string in format {"content": {...}, "to_show": {...}, others}
    """
    # Get the complete JSON string from the appropriate parser
    if api_type == "requests.Session.send":
        complete_json_str = api_obj_to_json_str_requests(response_obj)
    elif api_type in ["httpx.Client.send", "httpx.AsyncClient.send"]:
        complete_json_str = api_obj_to_json_str_httpx(response_obj)
    elif api_type == "aiohttp.ClientSession._request":
        complete_json_str = api_obj_to_json_str_aiohttp(response_obj)
    elif api_type == "MCP.ClientSession.send_request":
        complete_json_str = api_obj_to_json_str_mcp(response_obj)
    elif api_type == "claude_agent_sdk.parse_message":
        complete_json_str = json.dumps(response_obj)
    elif api_type == "claude_code.messages":
        complete_json_str = api_obj_to_json_str_claude_code_messages(response_obj)
    elif api_type in {"langchain_core.tools.BaseTool.run", "openai_agents.FunctionTool.run"}:
        complete_json_str = json.dumps(response_obj)
    elif api_type == "google.adk.tools.BaseTool.run":
        complete_json_str = json.dumps(response_obj)
    elif api_type == "urllib3.HTTPConnectionPool.urlopen":
        complete_json_str = api_obj_to_json_str_urllib3(response_obj)
    else:
        raise ValueError(f"Unknown API type {api_type}")

    # Parse the JSON string to get the raw dict
    raw_dict = json.loads(complete_json_str)
    # Filter the content dict
    if api_type == "claude_code.messages":
        to_show_dict = build_to_show_claude_code_messages_output(raw_dict)
    else:
        to_show_dict = filter_dict(raw_dict)
    # Create to_show with filtered content
    final_dict = {"raw": raw_dict, "to_show": to_show_dict}
    # Return the wrapped JSON string

    # json_str_to_api_obj(json.dumps(final_dict), api_type)

    return json.dumps(final_dict)


def json_str_to_api_obj(new_output_text: str, api_type: str) -> Any:
    """
    Convert JSON string back to API object, merging filtered values.

    Args:
        new_output_text: JSON string in format {"content": {...}, "to_show": {...}, others}
        api_type: The API type identifier

    Returns:
        Reconstructed API response object
    """
    # Parse the wrapped format
    complete_dict = json.loads(new_output_text)
    raw_dict = complete_dict["raw"]
    to_show_dict = complete_dict["to_show"]
    merged_dict = merge_filtered_into_raw(raw_dict, to_show_dict)
    merged_json_str = json.dumps(merged_dict)

    # Feed to the appropriate parser
    if api_type == "requests.Session.send":
        return json_str_to_api_obj_requests(merged_json_str)
    elif api_type in ["httpx.Client.send", "httpx.AsyncClient.send"]:
        return json_str_to_api_obj_httpx(merged_json_str)
    elif api_type == "aiohttp.ClientSession._request":
        return json_str_to_api_obj_aiohttp(merged_json_str)
    elif api_type == "MCP.ClientSession.send_request":
        return json_str_to_api_obj_mcp(merged_json_str)
    elif api_type == "claude_agent_sdk.parse_message":
        return json.loads(merged_json_str)
    elif api_type == "claude_code.messages":
        return json_str_to_api_obj_claude_code_messages(merged_json_str)
    elif api_type in {"langchain_core.tools.BaseTool.run", "openai_agents.FunctionTool.run"}:
        return json.loads(merged_json_str)
    elif api_type == "google.adk.tools.BaseTool.run":
        return json.loads(merged_json_str)
    elif api_type == "urllib3.HTTPConnectionPool.urlopen":
        return json_str_to_api_obj_urllib3(merged_json_str)
    else:
        raise ValueError(f"Unknown API type {api_type}")


def api_obj_to_response_ok(response_obj: Any, api_type: str) -> bool:
    if api_type == "requests.Session.send":
        return response_obj.ok
    elif api_type in ["httpx.Client.send", "httpx.AsyncClient.send"]:
        return response_obj.is_success
    elif api_type == "aiohttp.ClientSession._request":
        return getattr(response_obj, "ok", False)
    elif api_type == "MCP.ClientSession.send_request":
        # MCP tool responses should always be cached for replay, even if isError=True.
        # Unlike HTTP errors (which may be transient), MCP tool errors are deterministic
        # responses that should be replayed consistently.
        return True
    elif api_type == "urllib3.HTTPConnectionPool.urlopen":
        return True
    else:
        return True
