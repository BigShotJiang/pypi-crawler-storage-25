import re
from typing import Callable
from urllib.parse import urlparse

from sovara.common.constants import NO_LABEL


URL_PATTERN_TO_NODE_NAME = [
    (r"google\.serper\.dev", "Serper Search"),
    (r"scrape\.serper\.dev", "Serper Scrape"),
    (r"api\.search\.brave\.com/res/v1/web/search", "Brave Search"),
    (r"r\.jina\.ai/", "Jina Scrape"),
    (r"api\.brightdata\.com/request", "BrightData"),
    (r"api\.patronus\.ai/v1/evaluate", "Patronus Eval"),
    (r"api\.contextual\.ai/v1/parse", "Contextual Parse"),
    (r"api\.contextual\.ai/v1/rerank", "Contextual Rerank"),
    (r"api\.parallel\.ai/v1beta/search", "Parallel Search"),
]
COMPILED_URL_PATTERN_TO_NODE_NAME = [
    (re.compile(pattern), name) for pattern, name in URL_PATTERN_TO_NODE_NAME
]

MODEL_TOKEN_OVERRIDES = {
    "airx": "AirX",
    "aya": "Aya",
    "awq": "AWQ",
    "bf16": "BF16",
    "chatglm": "ChatGLM",
    "claude": "Claude",
    "codestral": "Codestral",
    "deepseek": "DeepSeek",
    "devstral": "Devstral",
    "exp": "Experimental",
    "flashx": "FlashX",
    "fp8": "FP8",
    "gemini": "Gemini",
    "gemma": "Gemma",
    "gguf": "GGUF",
    "glm": "GLM",
    "gpt": "GPT",
    "grok": "Grok",
    "it": "IT",
    "kimi": "Kimi",
    "llama": "Llama",
    "magistral": "Magistral",
    "medgemma": "MedGemma",
    "minimax": "MiniMax",
    "mistral": "Mistral",
    "mixtral": "Mixtral",
    "ministral": "Ministral",
    "moonlight": "Moonlight",
    "ocr": "OCR",
    "omni": "Omni",
    "onnx": "ONNX",
    "open": "Open",
    "opus": "Opus",
    "oss": "OSS",
    "phi": "Phi",
    "pixtral": "Pixtral",
    "pt": "PT",
    "qwen": "Qwen",
    "qwq": "QwQ",
    "sonnet": "Sonnet",
    "tars": "TARS",
    "tts": "TTS",
    "ui": "UI",
    "vl": "VL",
    "vlm": "VLM",
    "voxtral": "Voxtral",
}

INVALID_LABEL_CHARS = set("{[<>%$#@")


def _format_model_token(token: str) -> str:
    if not token:
        return token

    lower = token.lower()
    if lower in MODEL_TOKEN_OVERRIDES:
        return MODEL_TOKEN_OVERRIDES[lower]

    if re.fullmatch(r"\d+(?:\.\d+)?[a-z]+", lower):
        return token.upper()
    if re.fullmatch(r"[a-z]\d+(?:\.\d+)?[a-z]*", lower):
        return token.upper()
    if re.fullmatch(r"\d+x\d+[a-z]+", lower):
        return token.upper()
    if re.fullmatch(r"q\d+_[a-z0-9]+", lower):
        return token.upper()
    if token.isupper():
        return token

    return token[0].upper() + token[1:]


def _format_joined_tokens(*tokens: str) -> str:
    return " ".join(_format_model_token(token) for token in tokens if token)


def _format_optional_variant(variant: str | None) -> str:
    return f" {_format_model_token(variant)}" if variant else ""


def _format_optional_minor(major: str, minor: str | None) -> str:
    return f"{major}.{minor}" if minor else major


def _format_tail(tail: str | None, *, strip_gemini_preview_date: bool = False) -> str:
    if not tail:
        return ""

    cleaned_tail = tail
    if strip_gemini_preview_date:
        cleaned_tail = re.sub(r"-(preview|exp)-\d{2}-\d{2,4}$", r"-\1", cleaned_tail)

    return f" {_format_joined_tokens(*[token for token in re.split(r'[-:]', cleaned_tail) if token])}"


def _format_openai_gpt(match: re.Match[str]) -> str:
    version, tail = match.groups()
    return f"GPT-{version}{_format_tail(tail)}"


def _format_openai_gpt_oss(match: re.Match[str]) -> str:
    (size,) = match.groups()
    return f"GPT-OSS {size.upper()}"


def _format_openai_gpt_4o(match: re.Match[str]) -> str:
    mini, tail = match.groups()
    mini_suffix = " Mini" if mini else ""
    return f"GPT-4o{mini_suffix}{_format_tail(tail)}"


def _format_openai_o_series(match: re.Match[str]) -> str:
    major, variant = match.groups()
    return f"o{major}{_format_optional_variant(variant)}"


def _format_claude_modern(match: re.Match[str]) -> str:
    family, major, minor = match.groups()
    version = _format_optional_minor(major, minor)
    return f"Claude {_format_model_token(family)} {version}"


def _format_claude_legacy(match: re.Match[str]) -> str:
    major, minor, family = match.groups()
    version = _format_optional_minor(major, minor)
    return f"Claude {version} {_format_model_token(family)}"


def _format_gemini(match: re.Match[str]) -> str:
    version, tail = match.groups()
    return f"Gemini {version}{_format_tail(tail, strip_gemini_preview_date=True)}"


def _format_amazon_nova(match: re.Match[str]) -> str:
    (family,) = match.groups()
    return f"Amazon Nova {_format_model_token(family)}"


def _format_prefixed_family(match: re.Match[str], display_family: str) -> str:
    tail = match.group(1)
    return f"{display_family}{_format_tail(tail)}"


def _format_captured_family(match: re.Match[str]) -> str:
    prefix, tail = match.groups()
    return f"{_format_model_token(prefix)}{_format_tail(tail)}"


def _format_compact_versioned_family(match: re.Match[str]) -> str:
    family, version, tail = match.groups()
    return f"{_format_model_token(family)} {_format_model_token(version)}{_format_tail(tail)}"


def _format_slug_family(match: re.Match[str]) -> str:
    prefix, tail = match.groups()
    family = _format_joined_tokens(*prefix.split("-"))
    return f"{family}{_format_tail(tail)}"


MODEL_NAME_PATTERNS: list[tuple[str, str]] = [
    (r"^mistral-small-2603$", "Mistral Small 4"),
    (r"^mistral-moderation-2603$", "Mistral Moderation 2"),
    (r"^mistral-small-2506$", "Mistral Small 3.2"),
    (r"^voxtral-mini-tts-2603$", "Voxtral Mini TTS"),
    (r"^voxtral-tts-2603$", "Voxtral TTS"),
    (r"^voxtral-small-2507$", "Voxtral Small"),
    (r"^voxtral-mini-2507$", "Voxtral Mini"),
    (r"^voxtral-mini-2602$", "Voxtral Mini Transcribe 2"),
    (r"^voxtral-mini-transcribe-realtime-2602$", "Voxtral Mini Transcribe Realtime"),
    (r"^labs-leanstral-2603$", "Leanstral"),
    (r"^mistral-large-2512$", "Mistral Large 3"),
    (r"^ministral-14b-2512$", "Ministral 3 14B"),
    (r"^ministral-8b-2512$", "Ministral 3 8B"),
    (r"^ministral-3b-2512$", "Ministral 3 3B"),
    (r"^devstral-2512$", "Devstral 2"),
    (r"^labs-devstral-small-2512$", "Devstral Small 2"),
    (r"^devstral-medium-2507$", "Devstral Medium 1.0"),
    (r"^devstral-small-2507$", "Devstral Small 1.1"),
    (r"^devstral-small-2505$", "Devstral Small 1.0"),
    (r"^magistral-medium-2509$", "Magistral Medium 1.2"),
    (r"^magistral-small-2509$", "Magistral Small 1.2"),
    (r"^magistral-medium-2506$", "Magistral Medium 1.0"),
    (r"^magistral-small-2506$", "Magistral Small 1.0"),
    (r"^mistral-medium-2508$", "Mistral Medium 3.1"),
    (r"^magistral-medium-2507$", "Magistral Medium 1.1"),
    (r"^magistral-small-2507$", "Magistral Small 1.1"),
    (r"^codestral-2508$", "Codestral"),
    (r"^mistral-ocr-2512$", "OCR 3"),
    (r"^mistral-ocr-2505$", "OCR 2"),
    (r"^(?:openai/)?gpt-5\.2-chat-latest$", "GPT-5.2 Chat"),
    (r"^grok-4\.20-multi-agent-beta-\d{4}$", "Grok 4.20 Multi-Agent Beta"),
    (r"^grok-4\.20(?:-beta(?:-latest(?:-non-reasoning)?)?)?$", "Grok 4.20 Beta"),
    (r"^grok-4-fast-(?:reasoning|non-reasoning)$", "Grok 4 Fast"),
    (r"^grok-4(?:-latest|-0709)?$", "Grok 4"),
    (r"^command-a-03-2025$", "Command A"),
    (r"^command-a-vision-07-2025$", "Command A Vision"),
    (r"^command-a-reasoning-08-2025$", "Command A Reasoning"),
    (r"^command-a-translate-08-2025$", "Command A Translate"),
    (r"^(?:[a-z]+\.)?amazon\.nova-premier-v1(?::0)?$", "Amazon Nova Premier"),
    (r"^(?:[a-z]+\.)?amazon\.nova-pro-v1(?::0)?$", "Amazon Nova Pro"),
    (r"^(?:[a-z]+\.)?amazon\.nova-lite-v1(?::0)?$", "Amazon Nova Lite"),
    (r"^(?:[a-z]+\.)?amazon\.nova-micro-v1(?::0)?$", "Amazon Nova Micro"),
    (r"^(?:[a-z]+\.)?amazon\.nova-2-lite-v1(?::0)?$", "Amazon Nova 2 Lite"),
    (r"^(?:[a-z]+\.)?amazon\.nova-2-sonic-v1(?::0)?$", "Amazon Nova 2 Sonic"),
    (
        r"^(?:[a-z]+\.)?amazon\.nova-2-multimodal-embeddings-v1(?::0)?$",
        "Amazon Nova 2 Multimodal Embeddings",
    ),
    (r"^(?:[a-z]+\.)?amazon\.nova-sonic-v1(?::0)?$", "Amazon Nova Sonic"),
]
COMPILED_MODEL_NAME_PATTERNS = [
    (re.compile(pattern), name) for pattern, name in MODEL_NAME_PATTERNS
]

ModelNameFormatter = Callable[[re.Match[str]], str]

MODEL_NAME_FORMATTERS: list[tuple[str, ModelNameFormatter]] = [
    (r"^(?:chatgpt-)?gpt-4o(?:-(mini))?(?:-([a-z0-9]+(?:-[a-z0-9]+)*))?$", _format_openai_gpt_4o),
    (r"^(?:openai/)?gpt-(\d+(?:\.\d+)?)(?:-([a-z0-9]+(?:-[a-z0-9]+)*))?$", _format_openai_gpt),
    (r"^(?:openai/)?gpt-oss-(\d+[a-z])$", _format_openai_gpt_oss),
    (r"^(?:openai/)?o(\d+)(?:-(mini|pro|preview))?$", _format_openai_o_series),
    (
        r"^claude-(opus|sonnet|haiku)-(\d+)(?:-(\d{1,2}))?(?:-(?:\d{8}|latest))?$",
        _format_claude_modern,
    ),
    (
        r"^claude-(\d+)(?:-(\d{1,2}))?-(opus|sonnet|haiku)(?:-(?:\d{8}|latest|v\d))?$",
        _format_claude_legacy,
    ),
    (r"^gemini-(\d+(?:\.\d+)?)(?:-([a-z0-9]+(?:-[a-z0-9]+)*))?$", _format_gemini),
    (r"^(?:[a-z]+\.)?amazon\.nova-(micro|lite|pro|premier|sonic|canvas|reel)-v\d+:\d+$", _format_amazon_nova),
    (r"^grok(?:-(.+))?$", lambda m: _format_prefixed_family(m, "Grok")),
    (r"^doubao(?:-(.+))?$", lambda m: _format_prefixed_family(m, "Doubao")),
    (r"^harrier(?:-(.+))?$", lambda m: _format_prefixed_family(m, "Harrier")),
    (r"^(minimax)(?:-(.+))?$", _format_captured_family),
    (r"^(qwen[\w.]*|qwq)(?:-(.+))?$", _format_captured_family),
    (r"^llama(?:-(.+))?$", lambda m: _format_prefixed_family(m, "Llama")),
    (r"^(glm[\w.]*|chatglm[\w.]*)(?:-(.+))?$", _format_captured_family),
    (r"^(kimi[\w.]*|moonlight[\w.]*)(?:-(.+))?$", _format_captured_family),
    (r"^deepseek(?:-(.+))?$", lambda m: _format_prefixed_family(m, "DeepSeek")),
    (r"^(gemma|medgemma|t5gemma)(\d[\w.]*)(?:[:\-](.+))?$", _format_compact_versioned_family),
    (r"^(gemma[\w.]*|medgemma[\w.]*|t5gemma[\w.]*)(?:-(.+))?$", _format_captured_family),
    (r"^phi(?:-(.+))?$", lambda m: _format_prefixed_family(m, "Phi")),
    (r"^(command|aya|tiny-aya)(?:-(.+))?$", _format_slug_family),
    (r"^granite(?:-(.+))?$", lambda m: _format_prefixed_family(m, "Granite")),
    (
        r"^(?:labs-)?(open-mistral|open-mixtral|mistral|mixtral|ministral|magistral|devstral|codestral|pixtral|voxtral|leanstral)(?:-(.+))?$",
        _format_slug_family,
    ),
]
COMPILED_MODEL_NAME_FORMATTERS = [
    (re.compile(pattern, re.IGNORECASE), formatter)
    for pattern, formatter in MODEL_NAME_FORMATTERS
]


def get_tool_name_for_url(url: str) -> str | None:
    for pattern, name in COMPILED_URL_PATTERN_TO_NODE_NAME:
        if pattern.search(url):
            return name
    return None


def clean_model_name(name: str) -> str:
    if not name:
        return name

    if "/" in name:
        name = name.rsplit("/", 1)[-1]

    return name


def sanitize_node_name_for_display(name: str) -> str:
    if not name:
        return NO_LABEL

    for pattern, clean_name in COMPILED_MODEL_NAME_PATTERNS:
        if pattern.match(name):
            return clean_name

    for pattern, formatter in COMPILED_MODEL_NAME_FORMATTERS:
        match = pattern.match(name)
        if match:
            return formatter(match)

    parsed_url = urlparse(name)
    if parsed_url.scheme and parsed_url.netloc:
        name = parsed_url.hostname + parsed_url.path
    else:
        name = re.sub(r"(\d)-(?=\d)", r"\1.", name)
        name = name.replace("_", " ").replace("-", " ").title()

    if any(c in INVALID_LABEL_CHARS for c in name):
        return NO_LABEL

    return name
