import inspect
import json
import os
import re
import threading
import traceback
from collections import defaultdict
from typing import Optional, Dict, Any
from urllib.parse import unquote, urlencode, urlparse, parse_qsl, urlunparse

from sovara.runner.context_manager import get_run_id
from sovara.common.constants import (
    NO_LABEL,
)
from sovara.common.utils import http_post
from sovara.common.logger import logger
from sovara.runner.monkey_patching.endpoint_whitelist import COMPILED_ENDPOINT_PATTERNS
from sovara.runner.monkey_patching.node_naming import (
    clean_model_name,
    get_tool_name_for_url as _get_tool_name_for_url,
    sanitize_node_name_for_display,
)


# ===========================================================
# Model and tool name extraction
# ===========================================================


def _extract_model_from_body(input_dict: Dict[str, Any], api_type: str) -> Optional[str]:
    """
    Extract model name from request body/params (API-specific).
    Returns None if extraction fails.
    """
    try:
        if api_type == "requests.Session.send":
            body = input_dict["request"].body
            if isinstance(body, bytes):
                body = body.decode("utf-8")
            return json.loads(body)["model"]

        elif api_type in ["httpx.Client.send", "httpx.AsyncClient.send"]:
            content = input_dict["request"].content.decode("utf-8")
            return json.loads(content)["model"]

        elif api_type == "aiohttp.ClientSession._request":
            body = input_dict.get("json")
            if body is None:
                body = input_dict.get("data")
                if isinstance(body, bytes):
                    body = body.decode("utf-8")
                if isinstance(body, str):
                    body = json.loads(body)
            if isinstance(body, dict) and "model" in body:
                return body["model"]
            return None

        elif api_type == "MCP.ClientSession.send_request":
            return input_dict["request"].root.params.name

        elif api_type == "claude_agent_sdk.parse_message":
            # For SDK messages: redacted LLM nodes, tool calls, or text responses
            if input_dict.get("type") == "redacted_llm":
                return "Redacted Reasoning"
            return input_dict.get("tool_name") or input_dict.get("model")

        elif api_type == "claude_code.messages":
            body = input_dict.get("body")
            if isinstance(body, dict):
                return body.get("model")
            return None

        elif api_type == "langchain_core.tools.BaseTool.run":
            return input_dict.get("tool_name")

        elif api_type == "openai_agents.FunctionTool.run":
            return input_dict.get("qualified_tool_name") or input_dict.get("tool_name")
        elif api_type == "google.adk.tools.BaseTool.run":
            return input_dict.get("tool_name")

    except (KeyError, json.JSONDecodeError, UnicodeDecodeError, AttributeError, TypeError):
        pass

    return None


def _extract_name_from_url(input_dict: Dict[str, Any], api_type: str) -> Optional[str]:
    """
    Extract model name from URL path or known URL patterns.
    Returns None if extraction fails.
    """
    try:
        url, path = _extract_request_url_and_path(input_dict, api_type)
        if not url:
            return None

        # Try regex pattern for /models/xxx:<path> or models/xxx:<path>
        match = re.search(r"/?models/([^/:]+)", path or "")
        if match:
            return unquote(match.group(1))

        match = re.search(
            r"/model/([^/]+)/(?:converse|converse-stream|invoke|invoke-with-response-stream)", path
        )
        if match:
            return unquote(match.group(1))

        tool_name = get_tool_name_for_url(url)
        if tool_name:
            return tool_name

        # Last resort: return the path itself
        if url:
            return url

    except (AttributeError, KeyError, TypeError):
        pass

    return None


def _clean_model_name(name: str) -> str:
    """
    Clean raw model name by applying extraction patterns.
    E.g., "meta-llama/Llama-3-8B" -> "Llama-3-8B"
    """
    return clean_model_name(name)


def _sanitize_for_display(name: str) -> str:
    """
    Sanitize model name for display as node label.
    Truncation is handled in the VSCode extension (CustomNode.tsx).
    """
    return sanitize_node_name_for_display(name)


def get_node_name(input_dict: Dict[str, Any], api_type: str) -> str:
    """
    Extract raw node name from request (for caching).

    Tries body/params first, then URL fallback.
    Returns NO_LABEL if extraction fails.
    """
    raw_name = _extract_model_from_body(input_dict, api_type)
    if not raw_name:
        raw_name = _extract_name_from_url(input_dict, api_type)
    return raw_name or NO_LABEL


def get_node_label(input_dict: Dict[str, Any], api_type: str) -> str:
    """
    Extract and sanitize node name for display as node label.

    1. Extract from body/params
    2. Clean HuggingFace-style names (org/model -> model)
    3. Fall back to URL extraction if body fails
    4. Sanitize for display
    """
    raw_name = _extract_model_from_body(input_dict, api_type)
    if raw_name:
        raw_name = _clean_model_name(raw_name)
    else:
        raw_name = _extract_name_from_url(input_dict, api_type)

    return _sanitize_for_display(raw_name) if raw_name else NO_LABEL


def is_whitelisted_endpoint(url: str, path: str) -> bool:
    """Check if a URL and path match any of the whitelist (url_regex, path_regex) tuples."""
    for url_pattern, path_pattern in COMPILED_ENDPOINT_PATTERNS:
        if url_pattern.search(url) and path_pattern.search(path):
            return True
    return False


def get_tool_name_for_url(url: str) -> Optional[str]:
    """Return the display name for a known tool URL if it matches any pattern, else None."""
    return _get_tool_name_for_url(url)


def _extract_request_url_and_path(
    input_dict: Dict[str, Any], api_type: str
) -> tuple[str | None, str | None]:
    """Extract request URL/path for API types that expose transport-level metadata."""
    try:
        if api_type == "requests.Session.send":
            request = input_dict["request"]
            return str(request.url), request.path_url
        if api_type in ["httpx.Client.send", "httpx.AsyncClient.send"]:
            request = input_dict["request"]
            return str(request.url), request.url.path
        if api_type == "aiohttp.ClientSession._request":
            parsed = urlparse(str(input_dict["str_or_url"]))
            query_items = parse_qsl(parsed.query, keep_blank_values=True)
            params = input_dict.get("params")
            if params:
                if isinstance(params, dict):
                    query_items.extend(params.items())
                else:
                    query_items.extend(params)
            url = urlunparse(parsed._replace(query=urlencode(query_items, doseq=True)))
            return url, parsed.path
        if api_type == "urllib3.HTTPConnectionPool.urlopen":
            return input_dict.get("full_url"), input_dict.get("url")
        if api_type == "claude_code.messages":
            url = str(input_dict.get("url") or "")
            parsed = urlparse(url)
            return url, parsed.path
    except (AttributeError, KeyError, TypeError):
        return None, None

    return None, None


def _is_embedding_path(path: str | None) -> bool:
    """Embeddings are tracked as tool nodes because priors should never target them."""
    if not path:
        return False
    return "/embed" in path or "/embeddings" in path


def get_node_kind(input_dict: Dict[str, Any], api_type: str) -> str:
    """Classify a captured node as llm, mcp, or tool."""
    if api_type == "MCP.ClientSession.send_request":
        return "mcp"

    if api_type == "claude_agent_sdk.parse_message":
        return "tool" if input_dict.get("tool_name") else "llm"

    if api_type == "claude_code.messages":
        return "llm"

    if api_type == "langchain_core.tools.BaseTool.run":
        return "tool"

    if api_type in {"openai_agents.FunctionTool.run", "google.adk.tools.BaseTool.run"}:
        return "tool"

    url, path = _extract_request_url_and_path(input_dict, api_type)
    if _is_embedding_path(path):
        return "tool"

    if url and get_tool_name_for_url(url):
        return "tool"

    return "llm"


# ===========================================================
# Generic wrappers for caching and server notification
# ===========================================================

# str -> {str -> set(str)}
# if we add a -> b, we go through every element. If a is in the set, we add b to the
_graph_reachable_set = defaultdict(lambda: defaultdict(set))
_graph_lock = threading.Lock()


def capture_stack_trace() -> str:
    """Capture the current stack trace, showing only user code.

    Removes sovara infrastructure frames:
    - Beginning: everything up to and including sovara/runner/agent_runner.py
    - End: everything from and including sovara/server/database/
    - Middle: any frames inside sovara/ (unless cwd is sovara itself)
    """
    stack_lines = traceback.format_stack()

    # Find the start index: skip frames up to and including agent_runner.py
    start_idx = 0
    for i, line in enumerate(stack_lines):
        if "sovara/runner/agent_runner.py" in line or "sovara\\runner\\agent_runner.py" in line:
            start_idx = i + 1  # Start after this frame

    # Find the end index: stop before the database package
    end_idx = len(stack_lines)
    for i, line in enumerate(stack_lines):
        if "sovara/server/database/" in line or "sovara\\server\\database\\" in line:
            end_idx = i
            break

    # Extract only user code frames
    user_frames = stack_lines[start_idx:end_idx]

    # Filter out sovara frames unless we're developing sovara itself
    # Split cwd on path separators and check if "sovara" is an exact directory name
    cwd = os.getcwd()
    cwd_parts = re.split(r"[/\\]", cwd)
    developing_ao = "sovara" in cwd_parts

    if not developing_ao:
        # Filter out any frames from sovara directory
        # Match /sovara/ or \sovara\ as exact directory name
        filtered_frames = []
        for frame in user_frames:
            if "/sovara/" not in frame and "\\sovara\\" not in frame:
                filtered_frames.append(frame)
        user_frames = filtered_frames

    return "".join(user_frames).rstrip()


def get_input_dict(func, *args, **kwargs):
    # Arguments are normalized to the function's parameter order.
    # func(a=5, b=2) and func(b=2, a=5) will result in same dict.

    # Try to get signature, handling "invalid method signature" error
    sig = None
    try:
        sig = inspect.signature(func)
    except ValueError as e:
        if "invalid method signature" in str(e):
            # This can happen with monkey-patched bound methods
            # Try to get the signature from the unbound method instead
            if hasattr(func, "__self__") and hasattr(func, "__func__"):
                try:
                    # Get the unbound function from the class
                    cls = func.__self__.__class__
                    func_name = func.__name__
                    unbound_func = getattr(cls, func_name)
                    sig = inspect.signature(unbound_func)

                    # For unbound methods, we need to include 'self' in the arguments
                    # when binding, so prepend the bound object as the first argument
                    args = (func.__self__,) + args
                except (AttributeError, TypeError):
                    # If we can't get the unbound signature, re-raise the original error
                    raise e
        else:
            # Re-raise other ValueError exceptions
            raise e

    if sig is None:
        raise ValueError("Could not obtain function signature")

    try:
        bound = sig.bind(*args, **kwargs)
    except TypeError:
        # Many APIs only accept kwargs
        bound = sig.bind(**kwargs)
    bound.apply_defaults()

    input_dict = {}
    for name, value in bound.arguments.items():
        if name == "self":
            continue
        param = sig.parameters[name]
        if param.kind == inspect.Parameter.VAR_KEYWORD:
            input_dict.update(value)  # Flatten the captured extras
        else:
            input_dict[name] = value

    return input_dict


def send_graph_node_and_edges(
    node_id,
    input_dict,
    output_obj,
    source_node_ids,
    api_type,
    stack_trace,
    latency_seconds=None,
    node_title: str | None = None,
):
    """Send graph node and edge updates to the server."""
    run_id = get_run_id()
    node_msg = build_add_node_message(
        run_id=run_id,
        node_id=node_id,
        input_dict=input_dict,
        output_obj=output_obj,
        source_node_ids=source_node_ids,
        api_type=api_type,
        stack_trace=stack_trace,
        latency_seconds=latency_seconds,
        node_title=node_title,
    )

    try:
        http_post("/runner/add-node", node_msg)
    except Exception as e:
        logger.error(f"Failed to send add_node: {e}")


def build_add_node_message(
    *,
    run_id,
    node_id,
    input_dict,
    output_obj,
    source_node_ids,
    api_type,
    stack_trace,
    latency_seconds=None,
    node_title: str | None = None,
):
    """Build the canonical add-node payload for graph updates."""
    # Import here to avoid circular import
    from sovara.runner.monkey_patching.api_parser import (
        func_kwargs_to_json_str,
        api_obj_to_json_str,
    )
    from sovara.runner.node_execution import extract_node_error

    # Build display strings: only send to_show portion to the UI (not raw)
    input_full_str = func_kwargs_to_json_str(input_dict, api_type)
    output_full_str = api_obj_to_json_str(output_obj, api_type)
    input_string = json.dumps(json.loads(input_full_str)["to_show"])
    output_string = json.dumps(json.loads(output_full_str)["to_show"])
    raw_node_name = get_node_name(input_dict, api_type)
    label = node_title if node_title is not None else get_node_label(input_dict, api_type)
    node_kind = get_node_kind(input_dict, api_type)
    error_payload = extract_node_error(output_obj, api_type)
    node_status = "error" if error_payload else "success"
    error_message = error_payload.get("message") if isinstance(error_payload, dict) else None

    # Store input for this node (needed for containment checks)
    from sovara.runner.string_matching import store_input_strings, output_contained_in_input

    store_input_strings(run_id, node_id, input_dict, api_type)

    # Update reachability and filter redundant edges under lock
    with _graph_lock:
        for source_node_id in source_node_ids:
            _graph_reachable_set[run_id][source_node_id].add(node_id)

        for reachable_by_a in _graph_reachable_set[run_id].values():
            if any(source_node_id in reachable_by_a for source_node_id in source_node_ids):
                reachable_by_a.add(node_id)

        # Filter redundant source nodes: if node_b is reachable from node_a and node_a's output
        # is contained in node_b's input, remove node_a (its content already flows through node_b)
        nodes_to_remove = set()
        for node_a in source_node_ids:
            for node_b in source_node_ids:
                if node_a != node_b and node_b in _graph_reachable_set[run_id][node_a]:
                    if output_contained_in_input(run_id, node_a, node_b):
                        nodes_to_remove.add(node_a)
        filtered_source_node_ids = [n for n in source_node_ids if n not in nodes_to_remove]

    return {
        "type": "add_node",
        "run_id": run_id,
        "node": {
            "uuid": node_id,
            "input": input_string,
            "output": output_string,
            "label": label,
            "latency_seconds": latency_seconds,
            "status": node_status,
            "error_message": error_message,
            "stack_trace": stack_trace,
            "node_kind": node_kind,
            "raw_node_name": raw_node_name,
        },
        "incoming_edges": filtered_source_node_ids,
    }
