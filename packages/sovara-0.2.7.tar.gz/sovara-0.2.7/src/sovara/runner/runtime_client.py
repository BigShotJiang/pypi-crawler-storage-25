"""Runner-side HTTP client for server-owned Sovara state."""

from __future__ import annotations

import json
import random
import time
import uuid
from dataclasses import dataclass
from typing import Any

from sovara.common.logger import logger
from sovara.common.utils import hash_input, http_get, http_post, set_seed
from sovara.runner.context_manager import get_run_id
from sovara.runner.monkey_patching.api_parser import (
    api_obj_to_json_str,
    func_kwargs_to_json_str,
    json_str_to_api_obj,
    json_str_to_original_inp_dict,
)
from sovara.runner.monkey_patching.patching_utils import capture_stack_trace, get_node_kind


@dataclass
class PreparedCall:
    input_dict: dict
    output: Any | None
    node_uuid: str | None
    input_pickle: str
    input_hash: str
    run_id: str
    stack_trace: str | None = None
    node_kind: str | None = None
    prompt_suffix_json: str = "[]"
    prior_result: Any = None
    consumed_edit_field: str | None = None
    started_at: float | None = None
    latency_seconds: float | None = None


class RuntimeClient:
    def get_active_user(self) -> dict[str, Any] | None:
        return http_get("/ui/user").get("user")

    def setup_user(self, full_name: str, email: str) -> dict[str, Any]:
        return http_post("/ui/setup-user", {"full_name": full_name, "email": email})["user"]

    def resolve_project_location(self, location: str) -> dict[str, Any]:
        return http_post("/ui/projects/resolve-location", {"location": location})

    def create_project(self, location: str, name: str, description: str = "") -> dict[str, Any]:
        return http_post(
            "/ui/create-project",
            {"location": location, "name": name, "description": description},
        )

    def update_project(self, project_id: str, name: str, description: str = "") -> dict[str, Any]:
        return http_post(
            "/ui/update-project",
            {"project_id": project_id, "name": name, "description": description},
        )["project"]

    def get_run_scope(self, run_id: str) -> dict[str, Any] | None:
        return http_post("/internal/runner/run-scope", {"run_id": run_id}).get("run")

    def register_claude_proxy_client(
        self,
        run_id: str,
        client_id: str,
        upstream_base_url: str,
        stack_trace: str | None = None,
    ) -> None:
        http_post(
            "/internal/runner/claude-proxy/register-client",
            {
                "run_id": run_id,
                "client_id": client_id,
                "upstream_base_url": upstream_base_url,
                "stack_trace": stack_trace,
            },
        )

    def add_prior_applied(self, prior_id: str, run_id: str, node_uuid: str | None = None) -> None:
        http_post(
            "/internal/runner/priors/track-applied",
            {"prior_id": prior_id, "run_id": run_id, "node_uuid": node_uuid},
        )

    def schedule_prior_coverage(self, run_id: str, node_uuid: str) -> None:
        http_post(
            "/internal/runner/priors/schedule-coverage",
            {"run_id": run_id, "node_uuid": node_uuid},
        )

    def register_claude_sdk_tool_use(
        self,
        run_id: str,
        tool_use_id: str,
        tool_name: str,
        tool_input: Any,
        *,
        stack_trace: str | None = None,
    ) -> None:
        http_post(
            "/internal/runner/claude-sdk/tool-use",
            {
                "run_id": run_id,
                "tool_use_id": tool_use_id,
                "tool_name": tool_name,
                "tool_input": tool_input,
                "stack_trace": stack_trace,
            },
        )

    def finalize_claude_sdk_tool_result(
        self,
        run_id: str,
        tool_use_id: str,
        tool_result: Any,
        *,
        is_error: bool = False,
    ) -> None:
        http_post(
            "/internal/runner/claude-sdk/tool-result",
            {
                "run_id": run_id,
                "tool_use_id": tool_use_id,
                "tool_result": tool_result,
                "is_error": is_error,
            },
        )

    def upsert_prior_retrieval(
        self,
        run_id: str,
        node_uuid: str,
        *,
        retrieval_id: str | None,
        raw_context: str,
        processed_context: str,
        inherited_prior_ids: list[str],
        retrieved_priors: list[dict[str, Any]],
        applied_priors: list[dict[str, Any]],
        rendered_priors_block: str,
        injection_anchor: dict[str, Any] | None,
        model: str | None,
        latency_tier: str,
        timeout_ms: int,
        retrieval_latency_ms: int | None,
        prior_coverage: int | None,
        retrieval_status: str,
        coverage_status: str,
        warning_message: str | None,
        error_message: str | None,
    ) -> None:
        http_post(
            "/internal/runner/priors/persist-metadata",
            {
                "run_id": run_id,
                "node_uuid": node_uuid,
                "retrieval_id": retrieval_id,
                "raw_context": raw_context,
                "processed_context": processed_context,
                "inherited_prior_ids": inherited_prior_ids,
                "retrieved_priors": retrieved_priors,
                "applied_priors": applied_priors,
                "rendered_priors_block": rendered_priors_block,
                "injection_anchor": injection_anchor,
                "model": model,
                "latency_tier": latency_tier,
                "timeout_ms": timeout_ms,
                "retrieval_latency_ms": retrieval_latency_ms,
                "prior_coverage": prior_coverage,
                "retrieval_status": retrieval_status,
                "coverage_status": coverage_status,
                "warning_message": warning_message,
                "error_message": error_message,
            },
        )

    def prepare_call(
        self,
        input_dict: dict,
        api_type: str,
        *,
        prepare_runtime_priors: bool = False,
    ) -> PreparedCall:
        from sovara.runner.priors import prepare_llm_call_for_priors

        stack_trace = capture_stack_trace()
        run_id = get_run_id()
        node_kind = get_node_kind(input_dict, api_type)
        prior_result = None
        original_transport_json = func_kwargs_to_json_str(input_dict, api_type)
        should_prepare_runtime_priors = (
            prepare_runtime_priors
            and node_kind == "llm"
            and api_type
            in {
                "httpx.Client.send",
                "httpx.AsyncClient.send",
                "aiohttp.ClientSession._request",
                "requests.Session.send",
                "urllib3.HTTPConnectionPool.urlopen",
                "claude_code.messages",
            }
        )

        def restore_original_transport_input() -> dict:
            return json_str_to_original_inp_dict(original_transport_json, input_dict, api_type)

        working_input_dict = input_dict
        if should_prepare_runtime_priors:
            prior_result = prepare_llm_call_for_priors(input_dict, api_type)
            working_input_dict = prior_result.executed_input_dict

        input_pickle = func_kwargs_to_json_str(working_input_dict, api_type)
        input_hash = hash_input(input_pickle)

        row = http_post(
            "/internal/runner/llm/lookup",
            {
                "run_id": run_id,
                "input_hash": input_hash,
                "input_pickle": input_pickle,
                "api_type": api_type,
                "stack_trace": stack_trace,
                "node_kind": node_kind,
                "prompt_suffix_json": (
                    prior_result.prompt_suffix_json if prior_result is not None else "[]"
                ),
            },
        ).get("row")

        if row is None:
            raise RuntimeError(f"LLM lookup failed to prepare a row for run_id={run_id}")

        node_uuid = row["node_uuid"]
        output = None
        consumed_edit_field = None

        if row.get("input_overwrite") is not None:
            logger.debug(
                f"Cache hit (input overwritten): run_id {str(run_id)[:4]}, "
                f"input_hash {str(input_hash)[:4]}"
            )
            restore_original_transport_input()
            working_input_dict = json_str_to_original_inp_dict(
                row["input_overwrite"],
                input_dict,
                api_type,
            )
            if should_prepare_runtime_priors:
                prior_result = prepare_llm_call_for_priors(working_input_dict, api_type)
                prior_result.restore_original_input = restore_original_transport_input
                working_input_dict = prior_result.executed_input_dict
            input_pickle = func_kwargs_to_json_str(working_input_dict, api_type)
            input_hash = hash_input(input_pickle)
            consumed_edit_field = "input"

        elif row.get("output_overwrite") is not None:
            output = json_str_to_api_obj(row["output_overwrite"], api_type)
            from sovara.runner.node_execution import extract_node_error

            error_payload = extract_node_error(output, api_type)
            http_post(
                "/internal/runner/llm/finalize",
                {
                    "run_id": run_id,
                    "node_uuid": node_uuid,
                    "status": "error" if error_payload else "success",
                    "output_json": row["output_overwrite"],
                    "error_json": (
                        None if error_payload is None else json.dumps(error_payload, sort_keys=True)
                    ),
                    "consume_edit_field": "output",
                },
            )
            logger.debug(
                f"Cache hit (output overwritten): run_id {str(run_id)[:4]}, "
                f"input_hash {str(input_hash)[:4]}"
            )
        elif row.get("output") is not None:
            output = json_str_to_api_obj(row["output"], api_type)
            logger.debug(
                f"Cache hit (output set): run_id {str(run_id)[:4]}, input_hash {str(input_hash)[:4]}"
            )

        set_seed(node_uuid)
        return PreparedCall(
            input_dict=working_input_dict,
            output=output,
            node_uuid=node_uuid,
            input_pickle=input_pickle,
            input_hash=input_hash,
            run_id=run_id,
            stack_trace=stack_trace,
            node_kind=node_kind,
            prompt_suffix_json=(
                prior_result.prompt_suffix_json if prior_result is not None else "[]"
            ),
            prior_result=prior_result,
            consumed_edit_field=consumed_edit_field,
            started_at=None if output is not None else time.perf_counter(),
            latency_seconds=row.get("latency_seconds"),
        )

    def record_output(
        self,
        prepared_call: PreparedCall,
        output_obj: Any,
        api_type: str,
        cache: bool = True,
    ) -> None:
        random.seed()
        node_uuid = prepared_call.node_uuid or str(uuid.uuid4())
        del cache
        from sovara.runner.node_execution import extract_node_error

        error_payload = extract_node_error(output_obj, api_type)
        latency_seconds = None
        if prepared_call.started_at is not None:
            latency_seconds = max(0.0, time.perf_counter() - prepared_call.started_at)
        http_post(
            "/internal/runner/llm/finalize",
            {
                "run_id": prepared_call.run_id,
                "node_uuid": node_uuid,
                "status": "error" if error_payload else "success",
                "input_pickle": prepared_call.input_pickle,
                "input_hash": prepared_call.input_hash,
                "output_json": api_obj_to_json_str(output_obj, api_type),
                "error_json": (
                    None if error_payload is None else json.dumps(error_payload, sort_keys=True)
                ),
                "latency_seconds": latency_seconds,
                "stack_trace": prepared_call.stack_trace,
                "node_kind": prepared_call.node_kind,
                "prompt_suffix_json": prepared_call.prompt_suffix_json,
                "consume_edit_field": prepared_call.consumed_edit_field,
            },
        )

        prepared_call.node_uuid = node_uuid
        prepared_call.output = output_obj
        prepared_call.latency_seconds = latency_seconds
        set_seed(node_uuid)

    def record_exception(
        self,
        prepared_call: PreparedCall,
        exc: Exception,
        api_type: str,
    ) -> None:
        from sovara.runner.node_execution import exception_to_node_error

        node_uuid = prepared_call.node_uuid or str(uuid.uuid4())
        latency_seconds = None
        if prepared_call.started_at is not None:
            latency_seconds = max(0.0, time.perf_counter() - prepared_call.started_at)
        http_post(
            "/internal/runner/llm/finalize",
            {
                "run_id": prepared_call.run_id,
                "node_uuid": node_uuid,
                "status": "error",
                "input_pickle": prepared_call.input_pickle,
                "input_hash": prepared_call.input_hash,
                "error_json": json.dumps(exception_to_node_error(exc, api_type), sort_keys=True),
                "latency_seconds": latency_seconds,
                "stack_trace": prepared_call.stack_trace,
                "node_kind": prepared_call.node_kind,
                "prompt_suffix_json": prepared_call.prompt_suffix_json,
                "consume_edit_field": prepared_call.consumed_edit_field,
                "clear_output": True,
            },
        )
        prepared_call.node_uuid = node_uuid
        prepared_call.latency_seconds = latency_seconds


runtime_client = RuntimeClient()
