from __future__ import annotations

from typing import Any


def publish_prepared_call_output(
    *,
    prepared_call,
    api_type: str,
    source_node_ids: list[str],
    prior_result: Any = None,
    persist_prior_metadata_func=None,
    schedule_prior_coverage_func=None,
    store_output_strings_func=None,
    send_graph_node_and_edges_func=None,
) -> None:
    if prior_result is not None:
        if persist_prior_metadata_func is None:
            from sovara.runner.priors import persist_prior_metadata as persist_prior_metadata_func

        persist_prior_metadata_func(
            prepared_call.run_id,
            prepared_call.node_uuid,
            prior_result.metadata,
        )
        if schedule_prior_coverage_func is None:
            from sovara.runner.priors import schedule_prior_coverage as schedule_prior_coverage_func

        schedule_prior_coverage_func(
            prepared_call.run_id,
            prepared_call.node_uuid,
            prior_result.metadata,
        )

    if send_graph_node_and_edges_func is None:
        from sovara.runner.monkey_patching.patching_utils import (
            send_graph_node_and_edges as send_graph_node_and_edges_func,
        )
    if store_output_strings_func is None:
        from sovara.runner.string_matching import store_output_strings as store_output_strings_func

    store_output_strings_func(
        prepared_call.run_id,
        prepared_call.node_uuid,
        prepared_call.output,
        api_type,
    )
    send_graph_node_and_edges_func(
        node_id=prepared_call.node_uuid,
        input_dict=prepared_call.input_dict,
        output_obj=prepared_call.output,
        source_node_ids=source_node_ids,
        api_type=api_type,
        stack_trace=prepared_call.stack_trace,
        latency_seconds=prepared_call.latency_seconds,
    )


def record_prepared_call_exception(
    *,
    prepared_call,
    exc: Exception,
    api_type: str,
    source_node_ids: list[str],
    record_exception_func=None,
    send_graph_node_and_edges_func=None,
    build_exception_output_func=None,
) -> None:
    if record_exception_func is None:
        from sovara.runner.runtime_client import runtime_client

        record_exception_func = runtime_client.record_exception
    if send_graph_node_and_edges_func is None:
        from sovara.runner.monkey_patching.patching_utils import (
            send_graph_node_and_edges as send_graph_node_and_edges_func,
        )
    if build_exception_output_func is None:
        build_exception_output_func = build_exception_output

    # Support recorders that use either ``prepared_call`` or ``cache_result``
    # for the first argument name.
    record_exception_func(prepared_call, exc, api_type)
    prepared_call.output = build_exception_output_func(exc, api_type, prepared_call.input_dict)
    send_graph_node_and_edges_func(
        node_id=prepared_call.node_uuid,
        input_dict=prepared_call.input_dict,
        output_obj=prepared_call.output,
        source_node_ids=source_node_ids,
        api_type=api_type,
        stack_trace=prepared_call.stack_trace,
        latency_seconds=prepared_call.latency_seconds,
    )


def _jsonable_payload(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _jsonable_payload(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable_payload(item) for item in value]
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        try:
            return _jsonable_payload(model_dump(by_alias=True, mode="json", exclude_none=True))
        except TypeError:
            return _jsonable_payload(model_dump())
    dict_method = getattr(value, "dict", None)
    if callable(dict_method):
        return _jsonable_payload(dict_method())
    return str(value)


def _http_error_payload(
    *, api_type: str, status: int | None, reason: str | None, details: Any = None
) -> dict[str, Any]:
    message = f"HTTP {status}" if status is not None else "HTTP error"
    if reason:
        message = f"{message}: {reason}"
    return {
        "kind": "http_error",
        "source": api_type,
        "message": message,
        "type": str(status) if status is not None else None,
        "details": {"body": _jsonable_payload(details)} if details is not None else {},
    }


def _structured_error_payload(
    *,
    api_type: str,
    kind: str,
    message: str | None,
    error_type: str | None = None,
    details: Any = None,
) -> dict[str, Any]:
    return {
        "kind": kind,
        "source": api_type,
        "message": message or error_type or "Execution error",
        "type": error_type,
        "details": _jsonable_payload(details) if details is not None else {},
    }


def extract_node_error(output_obj: Any, api_type: str) -> dict[str, Any] | None:
    if api_type in {"requests.Session.send", "httpx.Client.send", "httpx.AsyncClient.send"}:
        status = getattr(output_obj, "status_code", None)
        if status is not None and status >= 400:
            details = None
            try:
                details = output_obj.json()
            except Exception:
                try:
                    details = output_obj.text
                except Exception:
                    details = None
            return _http_error_payload(
                api_type=api_type,
                status=status,
                reason=getattr(output_obj, "reason_phrase", None),
                details=details,
            )
        return None

    if api_type == "aiohttp.ClientSession._request":
        replay_error = getattr(output_obj, "replay_error", None)
        if replay_error:
            return _structured_error_payload(
                api_type=api_type,
                kind="stream_error",
                message=replay_error.get("message"),
                error_type=replay_error.get("type"),
                details=replay_error,
            )
        incomplete_details = getattr(output_obj, "replay_incomplete_details", None)
        if incomplete_details:
            return _structured_error_payload(
                api_type=api_type,
                kind="stream_error",
                message=incomplete_details.get("message"),
                error_type=incomplete_details.get("reason"),
                details=incomplete_details,
            )
        status = getattr(output_obj, "status", None)
        if status is not None and status >= 400:
            return _http_error_payload(
                api_type=api_type,
                status=status,
                reason=getattr(output_obj, "reason", None),
            )
        return None

    if api_type == "urllib3.HTTPConnectionPool.urlopen":
        status = getattr(output_obj, "status", None)
        if status is not None and status >= 400:
            return _http_error_payload(
                api_type=api_type,
                status=status,
                reason=getattr(output_obj, "reason", None),
            )
        return None

    payload = _jsonable_payload(output_obj)

    if api_type == "claude_code.messages":
        if isinstance(payload, dict):
            status = payload.get("_status_code")
            if isinstance(status, int) and status >= 400:
                details = {
                    key: value for key, value in payload.items() if not str(key).startswith("_")
                }
                return _http_error_payload(
                    api_type=api_type,
                    status=status,
                    reason=None,
                    details=details,
                )
        return None

    if api_type == "MCP.ClientSession.send_request":
        if isinstance(payload, dict) and (
            payload.get("isError") is True or payload.get("is_error") is True
        ):
            return _structured_error_payload(
                api_type=api_type,
                kind="returned_error",
                message=payload.get("message") or payload.get("error"),
                error_type=payload.get("code"),
                details=payload,
            )
        return None

    if api_type in {
        "langchain_core.tools.BaseTool.run",
        "openai_agents.FunctionTool.run",
        "google.adk.tools.BaseTool.run",
        "claude_agent_sdk.parse_message",
    }:
        if isinstance(payload, dict) and payload.get("status") == "error":
            return _structured_error_payload(
                api_type=api_type,
                kind="returned_error",
                message=payload.get("error_message") or payload.get("message"),
                error_type=payload.get("error_type"),
                details=payload,
            )
        return None

    return None


def exception_to_node_error(exc: Exception, api_type: str) -> dict[str, Any]:
    return {
        "kind": "exception",
        "source": api_type,
        "message": str(exc) or exc.__class__.__name__,
        "type": exc.__class__.__name__,
        "details": {},
    }


def build_exception_output(exc: Exception, api_type: str, input_dict: dict[str, Any]) -> Any:
    error_payload = {
        "error": {
            "type": exc.__class__.__name__,
            "message": str(exc) or exc.__class__.__name__,
        }
    }

    if api_type in {"httpx.Client.send", "httpx.AsyncClient.send"}:
        import httpx

        return httpx.Response(
            599,
            request=input_dict.get("request"),
            json=error_payload,
        )

    if api_type == "requests.Session.send":
        import json
        from requests import Response

        response = Response()
        response.status_code = 599
        response.reason = "Exception"
        response.request = input_dict.get("request")
        response._content = json.dumps(error_payload).encode("utf-8")
        response.encoding = "utf-8"
        return response

    if api_type == "aiohttp.ClientSession._request":
        from sovara.runner.monkey_patching.api_parsers.aiohttp_api_parser import (
            build_replay_aiohttp_response,
        )
        import json

        return build_replay_aiohttp_response(
            status=599,
            reason="Exception",
            headers={"content-type": "application/json"},
            request_url=str(input_dict.get("str_or_url", "")),
            body_bytes=json.dumps(error_payload).encode("utf-8"),
            method=input_dict.get("method", "GET"),
            error={"type": exc.__class__.__name__, "message": str(exc) or exc.__class__.__name__},
        )

    if api_type == "urllib3.HTTPConnectionPool.urlopen":
        from urllib3.response import HTTPResponse
        import io
        import json

        body_bytes = json.dumps(error_payload).encode("utf-8")
        return HTTPResponse(
            body=io.BytesIO(body_bytes),
            headers={"content-type": "application/json", "content-length": str(len(body_bytes))},
            status=599,
            reason="Exception",
            preload_content=False,
            decode_content=False,
            request_url=input_dict.get("full_url"),
        )

    if api_type == "claude_code.messages":
        return {
            **error_payload,
            "_stream": bool(input_dict.get("body", {}).get("stream")),
            "_status_code": 599,
            "_headers": {"content-type": "application/json"},
        }

    return error_payload
