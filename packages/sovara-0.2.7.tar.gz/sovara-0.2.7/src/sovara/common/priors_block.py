"""Shared rendering for managed <sovara-priors> blocks."""

from __future__ import annotations

import json
from typing import Any

_PRIORS_BLOCK_GUIDANCE = (
    "These priors are retrieved project-specific guidance from past successful work that may apply "
    "to the current task. Follow them closely when they are relevant, because they encode preferred "
    "patterns, constraints, and lessons that help avoid repeated mistakes."
)


def render_priors_block(priors: list[dict[str, Any]], *, manual: bool = False) -> str:
    """Render priors as a managed injection block with a manifest and guidance text."""
    if not priors:
        return ""

    manifest: dict[str, Any] = {
        "priors": [
            {"id": prior["id"]}
            for prior in priors
            if prior.get("id")
        ]
    }
    if manual:
        manifest["manual"] = True

    blocks = [
        (
            f"## {prior.get('title') or prior.get('name') or prior.get('id', 'Untitled')}\n"
            f"{prior.get('content', '')}"
        )
        for prior in priors
    ]
    return (
        "<sovara-priors>\n"
        f"<!-- {json.dumps(manifest, separators=(',', ':'))} -->\n"
        f"{_PRIORS_BLOCK_GUIDANCE}\n\n"
        + "\n\n".join(blocks)
        + "\n</sovara-priors>"
    )
