"""Structured stdio lifecycle events for parent/child process supervision."""

from __future__ import annotations

import json
import os
import sys
import threading
from typing import Any

LIFECYCLE_STDIO_ENV = "SOVARA_LIFECYCLE_STDIO"
LIFECYCLE_STDIO_PREFIX = "SOVARA_EVENT "

_emit_lock = threading.Lock()


def lifecycle_stdio_enabled() -> bool:
    return os.environ.get(LIFECYCLE_STDIO_ENV) == "1"


def emit_lifecycle_event(component: str, state: str, **payload: Any) -> None:
    """Emit a structured lifecycle event on stdout when enabled."""
    if not lifecycle_stdio_enabled():
        return

    event = {
        "type": "lifecycle",
        "component": component,
        "state": state,
    }
    for key, value in payload.items():
        if value is not None:
            event[key] = value

    line = f"{LIFECYCLE_STDIO_PREFIX}{json.dumps(event, separators=(',', ':'))}"
    with _emit_lock:
        print(line, file=sys.stdout, flush=True)


def parse_lifecycle_line(line: str) -> dict[str, Any] | None:
    """Parse a structured lifecycle event from a single stdout line."""
    if not line.startswith(LIFECYCLE_STDIO_PREFIX):
        return None

    try:
        payload = json.loads(line[len(LIFECYCLE_STDIO_PREFIX):])
    except json.JSONDecodeError:
        return None

    if not isinstance(payload, dict):
        return None
    if payload.get("type") != "lifecycle":
        return None
    if not isinstance(payload.get("component"), str):
        return None
    if not isinstance(payload.get("state"), str):
        return None
    return payload
