import re
from typing import Any, Sequence

REDACTED_SECRET = "****************"
OPENAI_STYLE_SECRET_PATTERN = re.compile(r"\bsk-[A-Za-z0-9_-]+\b")
AWS_ACCESS_KEY_ID_PATTERN = re.compile(r"\b(?:AKIA|ASIA|AIDA|AROA)[A-Z0-9]{16}\b")
SECRET_LABEL_PATTERN = r"api(?:_| |-)?key|access(?:_| |-)?key(?:_| |-)?id|access(?:_| |-)?token|secret(?:_| |-)?access(?:_| |-)?key|token|secret|authorization|vertex(?:_| |-)?credentials"
CONTEXTUAL_SECRET_PATTERN = re.compile(
    rf"(?i)\b(?P<label>{SECRET_LABEL_PATTERN})\b"
    r"(?P<separator>(?:\s+(?:provided|is|was)\s*:\s*|\s*[:=]\s*|\s+))"
    r"(?P<secret>(?!provided\b|is\b|was\b)[A-Za-z0-9._/+=-]{8,})"
)
SENSITIVE_LOG_FIELD_NAMES = frozenset({"api_key", "aws_access_key_id", "aws_secret_access_key", "vertex_credentials"})


def redact_secret_like_text(text: str, supplied_secrets: Sequence[str | None] = ()) -> str:
    redacted = OPENAI_STYLE_SECRET_PATTERN.sub(REDACTED_SECRET, text)
    redacted = AWS_ACCESS_KEY_ID_PATTERN.sub(REDACTED_SECRET, redacted)
    redacted = CONTEXTUAL_SECRET_PATTERN.sub(lambda match: f"{match.group('label')}{match.group('separator')}{REDACTED_SECRET}", redacted)
    for secret in supplied_secrets:
        trimmed = secret.strip() if isinstance(secret, str) else None
        if trimmed:
            redacted = redacted.replace(trimmed, REDACTED_SECRET)
    return redacted


def sanitize_for_log(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            key: REDACTED_SECRET if isinstance(key, str) and key in SENSITIVE_LOG_FIELD_NAMES and item is not None else sanitize_for_log(item)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [sanitize_for_log(item) for item in value]
    if isinstance(value, tuple):
        return tuple(sanitize_for_log(item) for item in value)
    return redact_secret_like_text(value) if isinstance(value, str) else value
