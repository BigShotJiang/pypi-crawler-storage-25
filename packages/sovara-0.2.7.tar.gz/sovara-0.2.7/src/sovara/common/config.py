from dataclasses import dataclass
from enum import Enum
import logging
import os
from typing import Any, Callable
import yaml

from sovara.common.logger import logger

try:
    import readline
except ImportError:
    try:
        import pyreadline3 as readline
    except ImportError:
        readline = None


def green(text: str) -> str:
    """Wrap text in ANSI green. Works on light and dark terminals."""
    return f"\033[32m{text}\033[0m"


@dataclass
class Config:
    python_executable: str = None  # Auto-populated when so-server runs

    # Database backend selection (overrides SOVARA_DB_BACKEND env var when set)
    db_backend: str | None = None
    mongodb_uri: str | None = None
    mongodb_db: str | None = None
    pg_dsn: str | None = None

    @classmethod
    def from_yaml_file(cls, yaml_file: str) -> "Config":
        with open(yaml_file, encoding="utf-8") as f:
            config_dict = yaml.safe_load(f)
        if config_dict is None:
            config_dict = {}
        if not isinstance(config_dict, dict):
            raise ValueError("Config file must contain a YAML mapping.")
        known_keys = set(cls.__dataclass_fields__.keys())
        filtered = {k: v for k, v in config_dict.items() if k in known_keys}
        return cls(**filtered)

    def to_yaml_file(self, yaml_file: str, *, log: logging.Logger | None = None) -> None:
        # Create parent directories if they don't exist
        os.makedirs(os.path.dirname(yaml_file), exist_ok=True)
        with open(yaml_file, "w", encoding="utf-8") as f:
            yaml.safe_dump(self.to_dict(), f)
        (log or logger).info(f"Saved config at {yaml_file}")

    def to_dict(self) -> dict:
        result = self.__dict__
        # For serialization, it's best to convert Enums to strings (or their underlying value type).

        def _convert_enums(value):
            if isinstance(value, Enum):
                return value.value
            if isinstance(value, dict):
                if not bool(value):
                    return None
                for key1, value1 in value.items():
                    value[key1] = _convert_enums(value1)
            return value

        for key, value in result.items():
            result[key] = _convert_enums(value)
        result = {k: v for k, v in result.items() if v is not None}
        return result


def complete_path(text, state):
    """Readline completer for filesystem paths."""
    try:
        expanded = os.path.expanduser(text)
        if os.path.isdir(expanded):
            parent = expanded
            prefix = expanded.rstrip(os.sep) + os.sep
        else:
            parent = os.path.dirname(expanded) or "."
            prefix = expanded

        completions = []
        if os.path.isdir(parent):
            for entry in os.listdir(parent):
                candidate = os.path.join(parent, entry)
                if candidate.startswith(prefix) or not text:
                    if text.startswith("~"):
                        home = os.path.expanduser("~")
                        candidate = "~" + candidate[len(home):]
                    if os.path.isdir(candidate):
                        candidate += "/"
                    completions.append(candidate)

        completions.sort()
        if state < len(completions):
            return completions[state]
        return None
    except Exception:
        return None


def _ask_field(
    input_text: str,
    convert_value: Callable[[Any], Any] | None = None,
    default: Any | None = None,
    error_message: str | None = None,
    path_completion: bool = False,
):
    if path_completion and readline is not None:
        readline.set_completer_delims(" \t\n;")
        # libedit (macOS) uses different syntax than GNU readline
        if "libedit" in (readline.__doc__ or ""):
            readline.parse_and_bind("bind ^I rl_complete")
        else:
            readline.parse_and_bind("tab: complete")
        readline.set_completer(complete_path)
    elif readline is not None:
        readline.set_completer(None)
    ask_again = True
    while ask_again:
        result = input(input_text)
        try:
            if default is not None and len(result) == 0:
                return default
            return convert_value(result) if convert_value is not None else result
        except Exception:
            if error_message is not None:
                print(error_message)


def _convert_yes_no_to_bool(value: str) -> bool:
    return {"yes": True, "no": False}[value.lower()]


def _convert_to_valid_path(value: str) -> str:
    value = os.path.abspath(value)
    if os.path.isdir(value):
        return value
    raise ValueError("Invalid path.")


# ── DB config helpers ─────────────────────────────────────────────────────────

def load_config() -> "Config":
    """Load config from ~/.sovara/config.yaml, returning defaults if absent."""
    from sovara.common.constants import SOVARA_CONFIG
    if os.path.exists(SOVARA_CONFIG):
        return Config.from_yaml_file(SOVARA_CONFIG)
    return Config()


def get_db_config() -> dict:
    """Return the effective DB configuration.

    Priority per field: config.yaml value > env var > built-in default.

    Returns a dict with keys:
      backend, mongodb_uri, mongodb_db, pg_dsn, source
    where ``source`` is ``"config_file"`` if any value came from config.yaml,
    ``"env_var"`` if it came from env, or ``"default"`` otherwise.
    """
    import os as _os
    from sovara.common.constants import (
        SOVARA_CONFIG,
        SOVARA_DB_BACKEND as _ENV_BACKEND,
        SOVARA_MONGODB_URI as _ENV_MONGO_URI,
        SOVARA_MONGODB_DB as _ENV_MONGO_DB,
        SOVARA_PG_DSN as _ENV_PG_DSN,
    )

    cfg = load_config()
    from_file = False

    def _resolve(file_val, env_val, default_val):
        nonlocal from_file
        if file_val is not None:
            from_file = True
            return file_val
        return env_val if env_val is not None else default_val

    backend = _resolve(cfg.db_backend, _ENV_BACKEND, "sqlite")
    mongodb_uri = _resolve(cfg.mongodb_uri, _ENV_MONGO_URI, "mongodb://localhost:27017")
    mongodb_db = _resolve(cfg.mongodb_db, _ENV_MONGO_DB, "sovara")
    pg_dsn = _resolve(cfg.pg_dsn, _ENV_PG_DSN, "postgresql://localhost:5432/sovara")

    # Determine source label (best-effort: does config.yaml exist with DB keys?)
    source = "default"
    if os.path.exists(SOVARA_CONFIG):
        if from_file:
            source = "config_file"
        else:
            source = "env_var"
    elif _os.environ.get("SOVARA_DB_BACKEND"):
        source = "env_var"

    return {
        "backend": backend,
        "mongodb_uri": mongodb_uri,
        "mongodb_db": mongodb_db,
        "pg_dsn": pg_dsn,
        "source": source,
    }


def save_db_config(
    backend: str,
    mongodb_uri: str | None = None,
    mongodb_db: str | None = None,
    pg_dsn: str | None = None,
) -> None:
    """Persist DB settings to ~/.sovara/config.yaml, merging with existing config."""
    from sovara.common.constants import SOVARA_CONFIG
    cfg = load_config()
    cfg.db_backend = backend
    if mongodb_uri is not None:
        cfg.mongodb_uri = mongodb_uri
    if mongodb_db is not None:
        cfg.mongodb_db = mongodb_db
    if pg_dsn is not None:
        cfg.pg_dsn = pg_dsn
    cfg.to_yaml_file(SOVARA_CONFIG)
