"""Helpers for launching Sovara subprocesses across source and frozen builds."""

from __future__ import annotations

import sys


def is_frozen_runtime() -> bool:
    return bool(getattr(sys, "frozen", False))


def build_so_server_command(*args: str) -> list[str]:
    if is_frozen_runtime():
        return [sys.executable, *args]
    return [sys.executable, "-m", "sovara.cli.so_server", *args]
