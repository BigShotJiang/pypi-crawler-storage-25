import re
import os


# default home directory for configs and temporary/cached files
default_home: str = os.path.join(os.path.expanduser("~"), ".sovara")
SOVARA_HOME: str = default_home

# User identity file
USER_ID_PATH = os.path.join(SOVARA_HOME, ".user_id")

# Project config directory and file
PROJECT_CONFIG_DIR = ".sovara"
PROJECT_ID_FILE = ".project_id"

# Path to config.yaml.
default_config_path = os.path.join(SOVARA_HOME, "config.yaml")
SOVARA_CONFIG = default_config_path

# server-related constants
HOST = os.environ.get("HOST", "127.0.0.1")
PORT = int(os.environ.get("PYTHON_PORT", 5959))
SOVARA_SERVER_URL = f"http://{HOST}:{PORT}"
SERVER_START_TIMEOUT = 2
PROCESS_TERMINATE_TIMEOUT = 5
MESSAGE_POLL_INTERVAL = 0.1
SERVER_INACTIVITY_TIMEOUT = 1200  # Shutdown server after 20 min of inactivity
RUN_ORPHAN_TIMEOUT = 5  # Seconds before a run without SSE is considered dead
SHUTDOWN_WAIT = 2

# Trace chat
SCATTER_BUDGET = 20.0
SCATTER_SUMMARY_BUDGET = 3 * SCATTER_BUDGET
# seconds

# Run meta data.
DEFAULT_NOTE = "Take notes."
DEFAULT_LOG = "No entries"
DEFAULT_SUCCESS = ""
SUCCESS_STRING = {True: "Satisfactory", False: "Failed", None: ""}


# Node label constants
NO_LABEL = "No Label"

CERTAINTY_UNKNOWN = "#000000"
CERTAINTY_GREEN = "#7fc17b"  # Matches restart/rerun button
CERTAINTY_YELLOW = "#d4a825"  # Matches tag icon; currently unused
CERTAINTY_RED = "#e05252"  # Matches erase button
SUCCESS_COLORS = {
    "Satisfactory": CERTAINTY_GREEN,
    "": CERTAINTY_UNKNOWN,
    "Failed": CERTAINTY_RED,
}

# Git repository for code versioning (separate from user's git)
default_git_path = os.path.join(SOVARA_HOME, "git")
SOVARA_GIT_DIR = default_git_path
# Note: Don't create the directory here - let GitVersioner handle initialization


# the path to the folder where the runs database is stored
default_db_cache_path = os.path.join(SOVARA_HOME, "db")
SOVARA_DB_PATH = default_db_cache_path

# ── Database backend selection ────────────────────────────────────────────────
# Set SOVARA_DB_BACKEND=mongodb (or postgresql) to switch engines.
# Defaults to "sqlite" which preserves existing behaviour.
SOVARA_DB_BACKEND: str = os.environ.get("SOVARA_DB_BACKEND", "sqlite")

# MongoDB connection URI (used when SOVARA_DB_BACKEND=mongodb).
SOVARA_MONGODB_URI: str = os.environ.get(
    "SOVARA_MONGODB_URI", "mongodb://localhost:27017"
)
# MongoDB database name.
SOVARA_MONGODB_DB: str = os.environ.get("SOVARA_MONGODB_DB", "sovara")

# PostgreSQL DSN (used when SOVARA_DB_BACKEND=postgresql).
# Example: postgresql://user:password@localhost:5432/sovara
SOVARA_PG_DSN: str = os.environ.get(
    "SOVARA_PG_DSN", "postgresql://localhost:5432/sovara"
)

# Blob storage: large string values (images, PDFs, etc.) are externalized here
# instead of being stored inline in the database.
SOVARA_BLOB_DIR = os.path.join(SOVARA_HOME, "blobs")

# String values in LLM call payloads larger than this (in characters) are
# written to SOVARA_BLOB_DIR and replaced with a {"__sovara_ref__": "<sha256>"} marker.
BLOB_EXTERNALIZATION_THRESHOLD = 1_000_000  # ~1 MB

# the path to the folder where the logs are stored
default_log_path = os.path.join(SOVARA_HOME, "logs")
SOVARA_LOG_DIR = default_log_path
MAIN_SERVER_LOG = os.path.join(SOVARA_LOG_DIR, "main_server.log")
PRIORS_SERVER_LOG = os.path.join(SOVARA_LOG_DIR, "priors_server.log")
INFERENCE_SERVER_LOG = os.path.join(SOVARA_LOG_DIR, "inference_server.log")
MAIN_SERVER_STARTUP_LOCK = os.path.join(SOVARA_HOME, "server.starting.lock")
INFERENCE_SERVER_PID = os.path.join(SOVARA_HOME, "inference_server.pid")

# Inference sub-server port (5959=main, 5961=inference)
INFERENCE_PORT = PORT + 2

# Path to the sovara package directory
# Computed from this file's location: sovara/common/constants.py -> sovara/
# Works for both editable installs (src/sovara/) and pip installs (site-packages/sovara/)
SOVARA_INSTALL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

STRING_MATCH_EXCLUDE_PATTERNS = [
    # Identifiers & timestamps
    r".*id$",
    r".*object$",
    r".*created_at$",
    r".*completed_at$",
    r".*responseId$",
    r".*previous_response_id$",
    r".*prompt_cache_key$",
    r".*safety_identifier$",
    r".*signature$",
    # Model & config
    r".*model$",
    r".*modelVersion$",
    r".*role$",
    r".*type$",
    r".*status$",
    r".*background$",
    r".*temperature$",
    r".*top_p$",
    r".*top_k$",
    r".*top_logprobs$",
    r".*frequency_penalty$",
    r".*presence_penalty$",
    r".*max_output_tokens$",
    r".*max_tokens$",
    r".*max_tool_calls$",
    r".*service_tier$",
    r".*store$",
    r".*truncation$",
    # Tool-related
    r".*tool_choice$",
    r".*tools$",
    r".*parallel_tool_calls$",
    # Stop conditions
    r".*stop_reason$",
    r".*stop_sequence$",
    r".*stop$",
    r".*finish_reason$",
    r".*finishReason$",
    # Usage/billing (entire subtrees)
    r".*usage$",
    r".*usageMetadata$",
    r".*billing$",
    # Other metadata
    r".*error$",
    r".*incomplete_details$",
    # r".*instructions$",  # May contain legitimate content
    # r".*reasoning$",  # May contain chain-of-thought content
    r".*metadata$",
    r".*user$",
    r".*index$",
    r".*logprobs$",
    r".*annotations$",
    r".*payer$",
    r".*verbosity$",
    r".*format$",
    r".*effort$",
    # r".*summary$",  # May contain legitimate summary content
    # Cache-related
    r".*prompt_cache_retention$",
    r".*cache_creation$",
    r".*cache_creation_input_tokens$",
    r".*cache_read_input_tokens$",
    # Additional patterns
    r".*reasoning_effort$",
    r".*native_finish_reason$",
    r".*provider$",
]
COMPILED_STRING_MATCH_EXCLUDE_PATTERNS = [re.compile(p) for p in STRING_MATCH_EXCLUDE_PATTERNS]

STRING_MATCH_INCLUDE_PATTERNS = [
    r".*tool_call_id$",
    r".*tool_calls\.\d+\.id$",
]
COMPILED_STRING_MATCH_INCLUDE_PATTERNS = [re.compile(p) for p in STRING_MATCH_INCLUDE_PATTERNS]

# Priors server constants
DEFAULT_PRIORS_SERVER_URL = SOVARA_SERVER_URL
PRIORS_SERVER_URL = os.environ.get("PRIORS_SERVER_URL", DEFAULT_PRIORS_SERVER_URL).rstrip("/")

PRIORS_SERVER_TIMEOUT = 30  # Seconds to wait for server startup
INTERNAL_PRIORS_TIMEOUT_MS = 240000

# Testing constants
TEST_USER_ID = "test-user"
TEST_PROJECT_ID = "test-project"

# Welcome banner
WELCOME_ART = """\033[32m
  ____
 / ___|  _____   ____ _ _ __ __ _
 \\___ \\ / _ \\ \\ / / _` | '__/ _` |
  ___) | (_) \\ V / (_| | | | (_| |
 |____/ \\___/ \\_/ \\__,_|_|  \\__,_|
\033[0m"""
