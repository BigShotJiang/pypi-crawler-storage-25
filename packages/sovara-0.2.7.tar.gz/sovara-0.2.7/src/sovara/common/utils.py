import hashlib
import json
import random
import os
import sys
import threading
import importlib
from sovara.common.logger import logger


def hash_input(input_bytes):
    """Hash input for deduplication"""
    if isinstance(input_bytes, bytes):
        return hashlib.sha256(input_bytes).hexdigest()
    else:
        return hashlib.sha256(input_bytes.encode("utf-8")).hexdigest()


def set_seed(node_id: str) -> None:
    """Set the seed based on the node_id."""
    seed = int(hashlib.sha256(node_id.encode()).hexdigest(), 16) % (2**32)
    random.seed(seed)


def is_valid_mod(mod_name: str):
    """Checks if one could import this module."""
    try:
        return importlib.util.find_spec(mod_name) is not None
    except:
        return False


def get_module_file_path(module_name: str) -> str | None:
    """Get the file path for an installed module without importing it."""
    parts = module_name.split(".")
    for base_path in sys.path:
        if not base_path or not os.path.isdir(base_path):
            continue
        current_path = base_path
        for part in parts:
            current_path = os.path.join(current_path, part)
        init_path = os.path.join(current_path, "__init__.py")
        if os.path.exists(init_path):
            return os.path.abspath(init_path)
        module_path = current_path + ".py"
        if os.path.exists(module_path):
            return os.path.abspath(module_path)
    return None


# ==============================================================================
# Communication with server via HTTP.
# ==============================================================================

_server_base_url = None
_local = threading.local()


def set_server_url(url: str) -> None:
    """Set the server base URL for HTTP communication."""
    global _server_base_url
    _server_base_url = url


def _get_http_client():
    """Return a per-thread httpx client (httpx.Client is not thread-safe)."""
    if not hasattr(_local, "client"):
        import httpx
        _local.client = httpx.Client(timeout=30.0)
    return _local.client


def _http_response_detail(response) -> str | None:
    def _stringify_detail(value) -> str | None:
        if value is None:
            return None
        if isinstance(value, str):
            return value.strip() or None
        try:
            return json.dumps(value, sort_keys=True, ensure_ascii=False)
        except Exception:
            text = str(value).strip()
            return text or None

    try:
        payload = response.json()
    except Exception:
        text = getattr(response, "text", None)
        if isinstance(text, str) and text.strip():
            return text.strip()
        return None

    if isinstance(payload, dict):
        detail = payload.get("detail")
        detail_text = _stringify_detail(detail)
        if detail_text:
            return detail_text

        error = payload.get("error")
        error_text = _stringify_detail(error)
        if error_text:
            return error_text

    return _stringify_detail(payload)


def _raise_for_status_with_detail(resp) -> None:
    import httpx

    try:
        resp.raise_for_status()
    except httpx.HTTPStatusError as exc:
        response = exc.response
        request = exc.request
        status_code = response.status_code
        reason = response.reason_phrase or ""
        status_text = f"{status_code} {reason}".strip()
        error_kind = (
            "Client error"
            if 400 <= status_code < 500
            else "Server error" if 500 <= status_code < 600 else "HTTP error"
        )
        base_message = f"{error_kind} '{status_text}' for url '{request.url}'"
        detail = _http_response_detail(exc.response)
        if detail:
            raise httpx.HTTPStatusError(
                f"{base_message} | detail={detail}",
                request=exc.request,
                response=exc.response,
            ) from exc
        raise httpx.HTTPStatusError(
            base_message,
            request=exc.request,
            response=exc.response,
        ) from exc


def http_post(endpoint: str, data: dict, timeout: float | None = None) -> dict:
    """POST JSON to the server and return the response dict.

    Raises on failure -- callers that are best-effort should catch exceptions.
    """
    if not _server_base_url:
        raise RuntimeError("Server URL not set. Did you forget to use so-record?")
    client = _get_http_client()
    resp = client.post(f"{_server_base_url}{endpoint}", json=data, timeout=timeout)
    _raise_for_status_with_detail(resp)
    return resp.json()


def http_get(endpoint: str, timeout: float | None = None) -> dict:
    """GET JSON from the server and return the response dict."""
    if not _server_base_url:
        raise RuntimeError("Server URL not set. Did you forget to use so-record?")
    client = _get_http_client()
    resp = client.get(f"{_server_base_url}{endpoint}", timeout=timeout)
    _raise_for_status_with_detail(resp)
    return resp.json()
