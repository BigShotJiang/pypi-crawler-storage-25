---
name: sovara
description: sovara helps you develop and maintain adaptable agentic systems. It adds context-optimized observability, accelerated A/B testing, and dynamic runtime prior injection. Use when actively developing or improving agentic systems.
---

# sovara

## Overview

- **Integrated Observability** – Record agent traces as dataflow graphs with zero code changes
- **Accelerated A/B Testing** – Edit node inputs/outputs and rerun to see how changes propagate
- **Priors** – Inject learned priors into agent context dynamically at runtime

---

## Setup

1. **Check for caching conflicts**: Scan the user-code for caching mechanisms (such as ad-hoc implementation of LLM-input caching or benchmark caching) that can interfere with the re-run capability. If you encounter such caching, flag this to the user and propose to change it by, for example, being able to disable caching with a `--no-cache` flag. **NOTE:** Caching that happens at the API provider level, for example using `cache_control` in the Anthropic API is OK!
2. **Check setup state before the first run**: Start with `uv run so-cli status --path <script-or-project-dir>`. This reports whether the local Sovara user is configured and whether the target directory already belongs to a Sovara project.
3. **Initialize explicitly when setup is missing**: If the user or project is missing, run `uv run so-cli init --user-name "<full name>" --user-email "<email>" [--project-root <dir> --project-name "<name>"]`. Do not reason about `~/.sovara/.user_id` or `.sovara/.project_id` directly if the CLI can tell you the setup state.
4. **For non-interactive runs, pass setup through the CLI**: When running through Codex or another non-interactive shell, do not rely on prompts. Use `so-cli init` first or pass `--user-name`, `--user-email`, `--project-root`, `--project-name`, and `--project-description` directly to `so-cli record`.
5. **Use explicit project selection when needed**: Run `uv run so-cli projects` to list visible projects and their `project_id`s. Project-scoped CLI commands such as `so-cli runs ...` and `so-cli priors ...` accept `--project-id` / `--proj-id`, and these flags accept any unambiguous project-id prefix. If you do not pass a project ID, priors commands resolve scope from the client workspace. Do not assume the server process's cwd will select the right project.

## Integrated Observability

Record agent execution as a graph where nodes are LLM/tool calls and edges are data dependencies.

### Record a script
Run any agent and record the dataflow graph, as well as input/output to each node.

The tool is generally structured like this.

```
usage: so-cli record [-h] [-m] [-u] [--run-name RUN_NAME] [--user-name USER_NAME]
                     [--user-email USER_EMAIL] [--project-root PROJECT_ROOT]
                     [--project-name PROJECT_NAME]
                     [--project-description PROJECT_DESCRIPTION]
                     [--timeout TIMEOUT] script_path ...

positional arguments:
  script_path          Script to execute (or module name with -m)
  script_args          Arguments to pass to the script

options:
  -h, --help           show this help message and exit
  -m, --module         Run script_path as a Python module (like python -m)
  -u, --unbuffered     Run with unbuffered stdout/stderr, like python -u
  --run-name RUN_NAME  Human-readable name for this run
  --user-name USER_NAME
                       Override or create the local Sovara user full name
  --user-email USER_EMAIL
                       Override or create the local Sovara user email
  --project-root PROJECT_ROOT
                       Project root to resolve or create for this run
  --project-name PROJECT_NAME
                       Override or create the Sovara project name
  --project-description PROJECT_DESCRIPTION
                       Override or create the Sovara project description
  --timeout TIMEOUT    Timeout in seconds (terminates script if exceeded)
```

Example:

```bash
uv run so-cli record --run-name "OAI-debate-run-1" --timeout 60 example_workflows/debug_examples/openai/debate.py
```

First-run example with explicit setup:

```bash
uv run so-cli init \
  --user-name "Jane Doe" \
  --user-email "jane@example.com" \
  --project-root example_workflows/debug_examples/openai \
  --project-name openai-debug
```

This will return
```json
{
  "status": "completed",
  "run_id": "77772451-2bea-4401-89aa-1b32cb34f688",
  "exit_code": 0,
  "duration_seconds": 16.9
}
```

### Inspect a run
After you ran a script/module you can investigate the input/output of each node (LLM call, tool call) using the `probe` command.

The tool is generally structured like this.

```
usage: so-cli probe [-h] [--node NODE] [--nodes NODES] [--preview] [--input] [--output] [--key-regex KEY_REGEX] run_id

positional arguments:
  run_id            Run ID to probe

options:
  -h, --help            show this help message and exit
  --node NODE           Return detailed info for a single node
  --nodes NODES         Return detailed info for multiple nodes (comma-separated IDs)
  --preview             Truncate string values to 20 characters for a compact overview
  --input               Only show input content (omit output)
  --output              Only show output content (omit input)
  --key-regex KEY_REGEX
                        Filter keys using regex pattern on flattened keys (e.g., 'messages.*content'). Lists use index notation: content.0.hello
```

`run_id`, `--node`, and `--nodes` accept full UUIDs or any unambiguous prefix. Start with the first 8 hex characters; if that is ambiguous, use a longer prefix.

Examples:
To return the metadata, the nodes in the graph, and the graph topology, run
```bash
uv run so-cli probe b6aaf796-8e25-4e9a-aae6-a47f261ced54
```

This will return a structured JSON with the run metadata and the graph information:
```json
{
  "run_id": "b6aaf796-8e25-4e9a-aae6-a47f261ced54",
  "name": "bench-train-9",
  "status": "finished",
  "timestamp": "2026-01-25 17:55:42.100729",
  "result": "Satisfactory",
  "version_date": null,
  "node_count": 3,
  "nodes": [
    {
      "node_id": "229386ef-fa49-4505-a28a-0049c2a5eb3e",
      "label": "Claude Sonnet 4.5",
      "parent_ids": [],
      "child_ids": []
    },
    <other two nodes omitted>
  ],
  "edges": [
    {
      "source": "00b0e4b8-db1d-4f44-bd5e-23c049c7b8c0",
      "target": "264d1f3e-8799-4752-b707-a4202af21340"
    }
  ]
}
```

Then, after having found the graph topology and the node IDs, you can investigate a node in more detail, but make sure to use preview to not spam your context with unnecessary tokens.

Important: use `--preview` together with `--node` or `--nodes`. Running `probe <run_id> --preview` only shows run topology; it does not show the flattened input/output keys inside a node.

```bash
uv run so-cli probe b6aaf796-8e25-4e9a-aae6-a47f261ced54 --node 00b0e4b8-db1d-4f44-bd5e-23c049c7b8c0 --preview
```

This will produce a preview with flattened keys:
```json
{
  "node_id": "00b0e4b8-db1d-4f44-bd5e-23c049c7b8c0",
  "run_id": "b6aaf796-8e25-4e9a-aae6-a47f261ced54",
  "api_type": "httpx.Client.send",
  "label": null,
  "timestamp": "2026-01-25 16:56:25",
  "parent_ids": [],
  "child_ids": [
    "264d1f3e-8799-4752-b707-a4202af21340"
  ],
  "has_input_overwrite": false,
  "stack_trace": [
    "File \"/Users/jub/sovara-beaver/benchmark_runner.py\", line 104, in <module>",
    "evaluate_sample(args.sample_id, max_turns=args.max_turns)",
    "File \"/Users/jub/sovara-beaver/benchmark_runner.py\", line 32, in evaluate_sample",
    "result = run_sql_agent(question, max_turns=max_turns)",
    "File \"/Users/jub/sovara-beaver/src/ao_beaver/sql_agent.py\", line 89, in run_sql_agent",
    "response = client.beta.messages.parse(",
    "File \"/Users/jub/sovara-beaver/.venv/lib/python3.13/site-packages/anthropic/resources/beta/messages/messages.py\", line 1141, in parse",
    "return self._post(",
    "File \"/Users/jub/sovara-beaver/.venv/lib/python3.13/site-packages/anthropic/_base_client.py\", line 1361, in post",
    "return cast(ResponseT, self.request(cast_to, opts, stream=stream, stream_cls=stream_cls))",
    "File \"/Users/jub/sovara-beaver/.venv/lib/python3.13/site-packages/anthropic/_base_client.py\", line 1069, in request",
    "response = self._client.send("
  ],
  "input": {
    "body.max_tokens": 8000,
    "body.messages.0.content": "<sovara-priors>\n## Student...",
    "body.thinking.budget_tokens": 4000,
    "body.thinking.type": "enabled",
    "url": "https://api.anthropi..."
  },
  "output": {
    "content.content.0.thinking": "The user is asking f...",
    "content.content.1.text": "{\"sql_query\": \"SELEC...",
    "content.role": "assistant",
    "content.stop_reason": "end_turn"
  }
}
```

If you then want to investigate a specific key of the input or output (or both) you can do so by passing a `--key-regex` like so

```bash
uv run so-cli probe b6aaf796-8e25-4e9a-aae6-a47f261ced54 --node 00b0e4b8-db1d-4f44-bd5e-23c049c7b8c0 --input --key-regex "body.max_tokens$"
```

This will produce the full result (no preview) of the specific keys that match the regex:
```json
{
  "node_id": "00b0e4b8-db1d-4f44-bd5e-23c049c7b8c0",
  "run_id": "b6aaf796-8e25-4e9a-aae6-a47f261ced54",
  "api_type": "httpx.Client.send",
  "label": null,
  "timestamp": "2026-01-25 16:56:25",
  "parent_ids": [],
  "child_ids": [
    "264d1f3e-8799-4752-b707-a4202af21340"
  ],
  "has_input_overwrite": false,
  "stack_trace": [
    "File \"<frozen runpy>\", line 198, in _run_module_as_main",
    "File \"<frozen runpy>\", line 88, in _run_code",
    "File \"<frozen runpy>\", line 229, in run_module",
    "File \"<frozen runpy>\", line 88, in _run_code",
    "File \"/Users/jub/sovara-beaver/benchmark_runner.py\", line 104, in <module>",
    "evaluate_sample(args.sample_id, max_turns=args.max_turns)",
    "File \"/Users/jub/sovara-beaver/benchmark_runner.py\", line 32, in evaluate_sample",
    "result = run_sql_agent(question, max_turns=max_turns)",
    "File \"/Users/jub/sovara-beaver/src/ao_beaver/sql_agent.py\", line 89, in run_sql_agent",
    "response = client.beta.messages.parse(",
    "File \"/Users/jub/sovara-beaver/.venv/lib/python3.13/site-packages/anthropic/resources/beta/messages/messages.py\", line 1141, in parse",
    "return self._post(",
    "File \"/Users/jub/sovara-beaver/.venv/lib/python3.13/site-packages/anthropic/_base_client.py\", line 1361, in post",
    "return cast(ResponseT, self.request(cast_to, opts, stream=stream, stream_cls=stream_cls))",
    "File \"/Users/jub/sovara-beaver/.venv/lib/python3.13/site-packages/anthropic/_base_client.py\", line 1069, in request",
    "response = self._client.send("
  ],
  "input": {
    "body.max_tokens": 8000
  }
}
```

### Inspect persisted logs
If you want to inspect the captured stdout/stderr transcript for a run, use the `logs` command. Unlike `probe` and `runs`, this command prints plain text rather than JSON.

The tool is generally structured like this.

```
usage: so-cli logs [-h] [--tail TAIL] [--grep GREP] [--context CONTEXT] [--line-numbers] run_id

positional arguments:
  run_id                Run ID to fetch logs for

options:
  -h, --help            show this help message and exit
  --tail TAIL           Show only the last N displayed lines
  --grep GREP           Filter displayed lines using a regex pattern
  --context CONTEXT     Show N lines of context around each grep match
  --line-numbers        Prefix displayed lines with original line numbers
```

`run_id` accepts a full UUID or any unambiguous prefix, just like `probe`.

Examples:
To inspect the last 40 lines of a run, run

```bash
uv run so-cli logs b6aaf796 --tail 40
```

To search a large log for cache misses with nearby context and original line numbers, run

```bash
uv run so-cli logs b6aaf796 --grep "Cache miss" --context 2 --line-numbers
```

### List and manage runs
You can manage past runs that you did with the `runs` command, which is structured in the following way

```
usage: so-cli runs [-h] [--range RANGE] [--regex REGEX] [--status {all,running,finished}]

List runs with optional range. Range format: ':50' (first 50), '50:100' (50-99), '10:' (from 10 onwards).

options:
  -h, --help                              show this help message and exit
  --range RANGE                           Range of runs to return (default: ':50'). Format: 'start:end', ':end', 'start:'
  --regex REGEX                           Filter runs by name using regex pattern
  --status {all,running,finished}         Filter runs by runtime status
```

Example:
To list the most recent 2 runs that match a certain regex, I can do

```bash
uv run so-cli runs --range :2 --regex "Run \d+$"
```

which produces

```json
{
  "runs": [
    {
      "run_id": "77772451-2bea-4401-89aa-1b32cb34f688",
      "name": "Run 1023",
      "timestamp": "2026-01-26 09:04:26",
      "result": "",
      "version_date": null
    },
    {
      "run_id": "b5288aae-02ca-4696-89ee-5f4074f4064e",
      "name": "Run 1022",
      "timestamp": "2026-01-26 08:39:28",
      "result": "",
      "version_date": null
    }
  ],
  "total": 1023,
  "range": "0:2"
}
```

### Parallel execution
If you want to execute muliple runs in parallel, invoke `so-cli record` separately multiple times. Example:

```bash
for i in 0 1 2 3 4 5 6 7 8 9; do
  uv run so-cli record -m --run-name "sql-agent-sample-$i" module.some_module -- --sample-id $i 2>&1 &
done
wait
```

---

## Accelerated A/B Testing

Copy a run, edit a single key in a node's input or output, and rerun to see how changes propagate through the graph. The original run is always preserved. The command blocks until completion and passes stdout/stderr through to the terminal.

```
usage: so-cli edit-and-rerun [-h] (--input KEY VALUE | --output KEY VALUE) [--timeout TIMEOUT] [--run-name RUN_NAME] run_id node_id

positional arguments:
  run_id            Run ID containing the node
  node_id               Node ID to edit

options:
  --input KEY VALUE     Edit an input key: --input <flat_key> <value_or_file_path>
  --output KEY VALUE    Edit an output key: --output <flat_key> <value_or_file_path>
  --timeout TIMEOUT     Timeout in seconds (terminates script if exceeded)
  --run-name RUN_NAME   Name for the new run (defaults to 'Edit of <original name>')
```

Keys use flattened dot-notation matching the keys from `probe --preview` output (e.g., `body.messages.0.content`, `body.temperature`). The value can be a literal string or a path to an existing file whose contents will be used.

`run_id` and `node_uuid` accept full UUIDs or any unambiguous prefix. Start with the first 8 hex characters; if that is ambiguous, use a longer prefix.

### Workflow

The typical workflow is: **probe** a node to see its flattened keys → **edit-and-rerun** a specific key → **probe** the downstream nodes to verify the effect.

**Step 1:** Probe a node with `--preview` to see available keys:
```bash
uv run so-cli probe 77772451-2bea-4401-89aa-1b32cb34f688 --node ee5643e0 --preview --input
```
```json
{
  "node_id": "ee5643e0-04e0-474b-bbc5-2d303d02e273",
  "input": {
    "body.input": "Come up with a simpl...",
    "body.model": "gpt-4o-mini",
    "body.temperature": 0,
    "url": "https://api.openai.c..."
  }
}
```

**Step 2:** Edit a key and rerun. This creates a new run, applies the edit, and reruns the script — downstream nodes recompute while unchanged nodes return cached results:
```bash
uv run so-cli edit-and-rerun 77772451-2bea-4401-89aa-1b32cb34f688 ee5643e0-04e0-474b-bbc5-2d303d02e273 \
  --input body.input "What is the best programming language?" \
  --run-name "test-new-question"
```
```json
{
  "status": "completed",
  "run_id": "b7df883a-d5f9-4e5a-8743-48dc3536b57c",
  "exit_code": 0,
  "duration_seconds": 18.73,
  "node_id": "ee5643e0-04e0-474b-bbc5-2d303d02e273",
  "edited_field": "input",
  "edited_key": "body.input"
}
```

**Step 3:** Probe downstream nodes in the new run to verify the effect of the change.

If `--key-regex` returns an empty `input` or `output` object, do not guess the field names. Re-run `probe` with `--preview` on that node first and inspect the flattened keys that actually exist for that API call.

### Using file contents as value
For longer edits (e.g., replacing a system prompt), write the new value to a file and pass the path:
```bash
uv run so-cli edit-and-rerun <run_id> <node_id> \
  --input body.messages.0.content /path/to/new_system_prompt.txt
```

### Parallel A/B testing
To test multiple variations of the same input in parallel, launch several `edit-and-rerun` commands concurrently. Each creates its own run copy, so they don't interfere:
```bash
SESSION=77772451-2bea-4401-89aa-1b32cb34f688
NODE=ee5643e0-04e0-474b-bbc5-2d303d02e273

uv run so-cli edit-and-rerun $SESSION $NODE --input body.temperature 0 --run-name "temp-0" &
uv run so-cli edit-and-rerun $SESSION $NODE --input body.temperature 0.5 --run-name "temp-0.5" &
uv run so-cli edit-and-rerun $SESSION $NODE --input body.temperature 1.0 --run-name "temp-1.0" &
wait
```
Then compare results across the three runs using `so-cli probe` and `so-cli runs --regex "temp-"`.

---

## Priors

Priors are small snippets that augment a context at runtime to inform the agent of specifics like company policies, specific domain knowledge, or conventions. Priors are organized in folders (e.g. `path/to/subfolder/`) so different parts of an agent system can have their own priors. `so-cli` provides capability to create and manage priors.

**Default retrieval scope:** Automatic runtime prior injection is the default and is project-wide. It retrieves from root scope (`""`), so it can consider priors anywhere in the project, including subfolders. Use folders for organization, or to narrow scope explicitly with `inject_priors(path="path/to/subfolder/", ...)`. If you manually call `inject_priors(...)`, that inserts a managed `<sovara-priors>` block and automatic retrieval for that same call is skipped.

### When to use
If injecting additional information that resolves ambiguity, introduces domain knowledge, or specifies company policy, can resolve the issue – construct a prior.
The ideal prior has three properties:

  1. It fixes the problem at hand
  2. generalizes well to other scenarios where the same problem could occur in a slightly different way
  3. and it does not conflict with other existing priors.

Once you have constructed a prior, check if the problem is solved by doing A/B testing. You should inject the prior at any point you see fit, and use the `edit-and-rerun` functionality. If you want to try different versions of the prior, run `edit-and-rerun` in parallel.
Once you verified that the prior addresses the problem, retrieve the available priors, and check if you introduced a conflict with another prior. If so, resolve the conflict by iteratively tuning and running the agent with the adapted priors, until you are satisfied.
If the prior came from debugging or improving a specific Sovara run, attach that provenance when you save it: pass `--run-id <full_run_uuid>` to `so-cli priors create` or `so-cli priors update`. Use the full UUID from `so-cli record` or `so-cli runs`; unlike `probe` and `logs`, this field should not use a short prefix.
When you learned the prior from a concrete run and omit `--run-id`, treat that as a mistake and fix it before you move on. The only normal case for a missing `run_id` is when the prior came from broad repository inspection or synthesis across multiple runs rather than one specific trace.

When a prior constrains correctness, also attach prior-adherence metadata:

- `--consequence-if-not-followed`: the concrete failure mode expected when the prior is relevant but the model violates it.
- `--non-adherence-severity`: an integer from 1 to 10 used as the fixed penalty when the adherence judge finds the prior relevant and not followed.

Use this severity scale:

- `1-2`: cosmetic or negligible; unlikely to affect outcome
- `3-4`: minor quality, consistency, or preference issue
- `5-6`: material correctness or interpretation risk
- `7-8`: serious issue likely to cause wrong output, wrong action, output-contract violation, or major degradation
- `9-10`: direct correctness break, safety-critical violation, hard contract violation, or likely primary reason the step failed

The adherence judge decides whether the prior was relevant and followed, but it does not reinterpret the severity. If the prior is violated, the stored `non_adherence_severity` is used as-is.

### How to use

First, inject priors into the context by modifying the user code.

```python
from sovara.runner.priors import inject_priors

# Inject all priors from a specific folder into a <sovara-priors> block
priors_context = inject_priors(path="path/to/subfolder/")

# Prepend to your prompt
prompt = f"{priors_context}\n\n{user_query}" if priors_context else user_query

response = client.messages.create(
    model="claude-sonnet-4-20250514",
    messages=[{"role": "user", "content": prompt}],
)
```

If you want LLM-filtered retrieval instead of loading all priors in a path:

```python
priors_context = inject_priors(
    path="path/to/subfolder/",
    context=user_query,
    method="retrieve",
)
```

**Note:** Ignore the warning that `inject_priors` is not available.

### CLI

`so-cli priors` mirrors the public priors API exposed by the main `so-server`.

```
usage: so-cli priors [-h] {start-server,list,get,create,update,delete,query,retrieve,migrate,restructure,ls,mkdir,mv,cp,rm} ...
```

When you need to target a project explicitly, list projects first:

```bash
uv run so-cli projects
```

Then pass `--project-id` or `--proj-id` with a full project ID or any unambiguous prefix:

```bash
uv run so-cli runs --project-id a6cbns64
uv run so-cli priors ls --proj-id a6cbns64
uv run so-cli priors ls path/to/subfolder/ --proj-id a6cbns64
uv run so-cli priors create --title "<title>" --content "<content>" --summary "<summary>" --path "path/to/subfolder/" --consequence-if-not-followed "<failure mode>" --non-adherence-severity <severity_1_to_10> --project-id a6cbns64
```

For root scope, omit the path entirely. Examples: `uv run so-cli priors ls --project-id a6cbns64`, `uv run so-cli priors list --project-id a6cbns64`, or `uv run so-cli priors retrieve "<context>" --project-id a6cbns64`.

The main commands are:

- `list`: list priors, optionally filtered by `--path`
- `get <prior_id>`: fetch one prior
- `create`: create a prior with `--title`, `--content`, and optional `--summary`, `--path`, `--run-id`, `--when-to-use`, `--consequence-if-not-followed`, `--non-adherence-severity`, `--alias`, `--keyword`, and `--related-prior`. If you omit `--summary`, the server generates one with a cheap model and a fallback. Pass `--run-id <full_run_uuid>` whenever the prior came from a specific run; if you just verified a fix with `so-cli record`, this should usually be present.
- `update <prior_id>`: update `--title`, `--content`, `--path`, `--run-id`, `--when-to-use`, `--consequence-if-not-followed`, `--non-adherence-severity`, `--alias`, `--keyword`, and/or `--related-prior`. Preserve or add `--run-id <full_run_uuid>` when the prior is tied to a run; do not drop provenance during follow-up edits.
- `delete <prior_id>`: delete one prior
- `query`: return all priors in a path plus an injected `<sovara-priors>` block
- `retrieve "<context>"`: use the LLM retriever to select relevant priors
- `migrate`: move root-level priors into the default retrieval folder
- `restructure {propose,execute,abort}`: manage taxonomy restructure proposals
- `ls`, `mkdir`, `mv`, `cp`, `rm`: folder and bulk-prior operations

Examples:

```bash
so-cli priors list --path "path/to/subfolder/"
so-cli priors get <prior_id>
so-cli priors create --title "<title>" --content "<content>" --summary "<summary>" --path "path/to/subfolder/" --run-id "<full_run_uuid>" --consequence-if-not-followed "<failure mode>" --non-adherence-severity <severity_1_to_10> --alias "<alias>" --keyword "<keyword>" --related-prior "<prior_id>"
so-cli priors update <prior_id> --content "<new_content>" --path "path/to/another-subfolder/" --consequence-if-not-followed "<failure mode>" --non-adherence-severity <severity_1_to_10> --alias "<alias>" --keyword "<keyword>"
so-cli priors delete <prior_id>
so-cli priors query --path "path/to/subfolder/"
so-cli priors retrieve "Find validation guidance"
so-cli priors migrate
so-cli priors restructure propose --path "path/to/root/" --comments "Group priors by subsystem" > proposal.json
so-cli priors restructure execute --proposal-file proposal.json
so-cli priors restructure abort <task_id>
so-cli priors ls
so-cli priors mv -i abc123,def456 path/to/destination/
so-cli priors cp path/to/subfolder/ path/to/subfolder-backup/
so-cli priors rm -r path/to/old-folder/
```

Restructure workflow:

1. Run `so-cli priors restructure propose` to get a proposal with `task_id`, `moves`, `new_folders`, and `snapshot`.
2. Optionally inspect or edit the JSON proposal file.
3. Run `so-cli priors restructure execute --proposal-file proposal.json` to execute it.
4. If you do not want to apply it, run `so-cli priors restructure abort <task_id>` to release the lock.

Representative outputs:

`so-cli priors list` returns a JSON object:

```json
{
  "priors": [
    {
      "id": "24d90294",
      "title": "Rate Limiting Best Practices",
      "summary": "Use exponential backoff with jitter when upstream APIs rate-limit requests.",
      "content": "When dealing with rate limits, implement exponential backoff...",
      "path": "path/to/subfolder/",
      "prior_status": "active",
      "run_id": "<run_uuid_or_null>",
      "consequence_if_not_followed": "Violating this prior can cause retries to duplicate side-effecting calls.",
      "non_adherence_severity": "<integer_1_to_10>",
      "aliases": ["rate limit retries", "429 retry policy"],
      "keywords": ["rate-limit", "backoff", "jitter", "429"],
      "related_priors": []
    }
  ]
}
```

Active priors now store:

- `title`: mandatory, separate from the markdown body
- `summary`: mandatory persisted summary; generated by the cheap model with a fallback unless you pass `--summary` on create
- `content`: mandatory raw markdown without a title heading
- `status`: active or draft
- `run_id`: optional source trace/run UUID; pass it whenever the prior was derived from a specific run
- `consequence_if_not_followed`: optional expected failure mode when a relevant prior is violated
- `non_adherence_severity`: optional integer `1-10` fixed severity penalty for a violated relevant prior
- `aliases`, `keywords`, `related_priors`: optional string lists
- `created_at`, `updated_at`: UTC timestamps
- `validation_metadata`: latest validation payload

`so-cli priors create` returns the server's creation response:

```json
{
  "status": "created",
  "id": "<prior_id>",
  "title": "<title>",
  "summary": "<manual_or_generated_summary>",
  "content": "<content>",
  "path": "path/to/subfolder/",
  "run_id": "<run_uuid_or_null>",
  "consequence_if_not_followed": "<failure_mode_or_empty_string>",
  "non_adherence_severity": "<integer_1_to_10>",
  "aliases": ["<manual_or_generated_alias>"],
  "keywords": ["<manual_or_generated_keyword>"],
  "related_priors": ["<prior_id>"]
}
```

`so-cli priors query` returns all priors in a path plus the injected context:

```json
{
  "path": "path/to/subfolder/",
  "priors": [
    {
      "id": "<prior_id>",
      "name": "<name>",
      "summary": "<summary>",
      "content": "<content>",
      "path": "path/to/subfolder/"
    }
  ],
  "injected_context": "<sovara-priors>\n<!-- {\"priors\":[{\"id\":\"<prior_id>\"}]} -->\n## <name>\n<content>\n</sovara-priors>"
}
```

`so-cli priors retrieve` returns the retriever result:

```json
{
  "context": "Find SQL validation guidance",
  "base_path": "path/to/root/",
  "priors": [
    {
      "id": "<prior_id>",
      "name": "<name>",
      "summary": "<summary>",
      "content": "<content>",
      "path": "path/to/another-subfolder/"
    }
  ],
  "prior_count": 1
}
```

`so-cli priors restructure propose` returns a proposal you can review or edit:

```json
{
  "task_id": "<task_id>",
  "summary": "<summary>",
  "new_folders": ["path/to/another-subfolder/"],
  "removed_folders": [],
  "moves": [
    {
      "prior_id": "<prior_id>",
      "current_path": "path/to/root/",
      "new_path": "path/to/another-subfolder/",
      "reason": "<reason>"
    }
  ],
  "redundant_prior_ids": [],
  "total_priors": 4,
  "snapshot": "<snapshot>"
}
```

`so-cli priors ls` returns folder metadata plus child priors:

```json
{
  "path": "path/to/root/",
  "folders": [
    {
      "path": "path/to/subfolder/",
      "prior_count": 3
    }
  ],
  "priors": [
    {
      "id": "abc123",
      "name": "Some Prior",
      "summary": "...",
      "content": "...",
      "path": "path/to/root/"
    }
  ],
  "prior_count": 4
}
```

`mkdir`, `mv`, `cp`, `rm`, `delete`, and `migrate` return status objects shaped like the SovaraDB API, for example:

```json
{
  "status": "moved",
  "dst": "path/to/destination/",
  "moved_count": 2
}
```

---

## Troubleshooting

### Sandboxed / restricted filesystem

**Problem:** You are running inside a sandboxed environment and Sovara commands fail because they try to write under `~/.sovara`, `~/.cache`, or Python cache locations.

**Solution:** Redirect writable cache and Python temp state into `/tmp` before invoking the CLI:

```bash
export SOVARA_CACHE=/tmp/sovara-cache
export UV_CACHE_DIR=/tmp/uv-cache
export PYTHONPYCACHEPREFIX=/tmp/pycache
```

Sovara still keeps durable state under `~/.sovara`, so cache-only redirection only helps with non-persistent writes.

**Important limitation:** this only fixes cache/temp writes. If `so-cli record` needs to start the local Sovara server, that startup still writes durable state under `~/.sovara` (logs, config, DB, lock files). In Codex or another sandboxed agent, the smooth workflow is to start the server outside the sandbox first:

```bash
so-server start
```

Then run `so-cli record`, `so-cli runs`, `so-cli probe`, `so-cli logs`, and `so-cli edit-and-rerun` from inside Codex against the already-running server.

If the sandbox also forbids binding a localhost port, server-backed commands may still fail until Sovara supports a no-daemon / in-process CLI transport.

### Priors server not reachable

**Problem:** `so-cli priors ...` fails because the main Sovara server cannot be reached.

**Check:** Confirm the main Sovara server is running and that `PRIORS_SERVER_URL` points at the correct host. If you set `PRIORS_SERVER_URL` in your shell config, remember that non-interactive shells may not load files like `~/.zshrc`.

**Solution:** Put your `PRIORS_SERVER_URL` export in a file that is sourced for all shell invocations:

| OS | Recommended location |
|-----|----------------------|
| macOS (zsh) | `~/.zshenv` |
| Linux (zsh) | `~/.zshenv` |
| Linux (bash) | `~/.bashrc` or `~/.profile` |
| Windows | System Environment Variables (GUI or `[System.Environment]::SetEnvironmentVariable("PRIORS_SERVER_URL", "http://your-host:5959", "User")` in PowerShell) |

After making this change, restart your agent shell/session for the new environment to take effect.

### Missing user or project setup

**Problem:** `so-cli record` reports that Sovara user or project setup is missing and the session cannot prompt.

**Solution:** Run `so-cli status --path <target>` to inspect the missing pieces, then initialize them explicitly:

```bash
uv run so-cli init \
  --user-name "<full name>" \
  --user-email "<email>" \
  --project-root <target-dir> \
  --project-name "<project name>"
```

---

- You executed a code using  `uv run so-cli --help`
but you get: `error: Failed to spawn: so-cli` &rarr; You need to add sovara to your `uv` dependencies.

- You executed `so-cli record some_script.py` and a module is not found &rarr; You need to add the module to your virtual environment.

---

## Feedback

When you are using this tool and you encounter an issue (a command that should work didn't), propose opening an issue at [github.com/SovaraLabs/sovara](https://github.com/SovaraLabs/sovara) or emailing `support@sovara-labs.com`. Propose the exact, nicely formatted text the user should use.
