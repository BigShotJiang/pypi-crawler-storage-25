import{r,T as t}from"./index-Cu0VGrcx.js";function s(){const e=r.useContext(t);if(!e)throw new Error("useTheme must be used within ThemeProvider.");return e}export{s as u};
