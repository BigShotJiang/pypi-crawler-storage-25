"""Claude Code proxy routes that reuse the normal llm_calls lifecycle."""

from __future__ import annotations

import asyncio
import copy
import json
import time
from typing import Any, AsyncIterator

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from starlette.responses import StreamingResponse

from sovara.common.constants import MAIN_SERVER_LOG
from sovara.common.logger import create_file_logger
from sovara.runner.context_manager import bind_run_id
from sovara.runner.monkey_patching.api_parsers.sse_utils import parse_sse_events
from sovara.runner.monkey_patching.patching_utils import (
    build_add_node_message,
)
from sovara.runner.priors import build_prior_metadata_persistence_payload
from sovara.runner.node_execution import (
    build_exception_output,
    publish_prepared_call_output,
    record_prepared_call_exception,
)
from sovara.runner.string_matching import (
    find_source_nodes,
    store_output_strings,
)
from sovara.server.app import get_state
from sovara.server.claude_proxy_utils import (
    assemble_anthropic_message_from_sse_events,
    build_nonstream_output_payload,
    build_stream_output_payload,
    extract_public_response,
    extract_stream_replay_bytes,
    filter_forward_request_headers,
    filter_proxy_response_headers,
)
from sovara.server.database import DB
from sovara.server.handlers.runner_handlers import handle_add_node
from sovara.server.state import ServerState

router = APIRouter()
logger = create_file_logger(MAIN_SERVER_LOG, logger_name="sovara.server.routes.claude_proxy")

API_TYPE = "claude_code.messages"
CLAUDE_SDK_API_TYPE = "claude_agent_sdk.parse_message"
MESSAGES_PATH = "/v1/messages"
COUNT_TOKENS_PATH = "/v1/messages/count_tokens"


class ClaudeSdkToolUseRequest(BaseModel):
    run_id: str
    tool_use_id: str
    tool_name: str
    tool_input: Any = None
    stack_trace: str | None = None


class ClaudeSdkToolResultRequest(BaseModel):
    run_id: str
    tool_use_id: str
    tool_result: Any = None
    is_error: bool = False


def _resolve_proxy_client(state: ServerState, run_id: str, client_id: str) -> dict[str, str]:
    client = state.get_claude_proxy_client(run_id, client_id)
    if client is None:
        raise HTTPException(
            status_code=404,
            detail=f"Unknown Claude proxy client for run_id={run_id}, client_id={client_id}.",
        )
    return client


def _build_input_dict(*, upstream_url: str, request_body: dict[str, Any]) -> dict[str, Any]:
    return {
        "url": upstream_url,
        "body": copy.deepcopy(request_body),
    }


def _build_server_side_prior_preparer(run_id: str):
    run_scope = DB.get_run_scope(run_id)
    if run_scope is None:
        raise HTTPException(status_code=404, detail=f"Run not found: {run_id}")
    run_scope = dict(run_scope)
    user_id = run_scope.get("user_id")
    project_id = run_scope.get("project_id")
    if not user_id or not project_id:
        raise HTTPException(status_code=400, detail="Run is missing user/project scope.")

    from sovara.runner.priors import prepare_llm_call_for_priors
    from sovara.server.priors_backend.routes import (
        lookup_prefix_cache_for_scope,
        retrieve_priors_for_scope,
        store_prefix_cache_for_scope,
    )

    def _lookup_prefix_cache(
        _run_id: str,
        clean_pairs: list[dict[str, str]],
    ) -> tuple[dict[str, Any] | None, int]:
        match = lookup_prefix_cache_for_scope(
            user_id=str(user_id),
            project_id=str(project_id),
            clean_pairs=clean_pairs,
        )
        if not match.get("found"):
            return None, 0
        return match, int(match.get("matched_pair_count") or 0)

    def _store_prefix_cache(
        _run_id: str | None,
        clean_pairs: list[dict[str, str]],
        injected_pairs: list[dict[str, str]],
        prior_ids: list[str],
    ) -> None:
        store_prefix_cache_for_scope(
            user_id=str(user_id),
            project_id=str(project_id),
            clean_pairs=clean_pairs,
            injected_pairs=injected_pairs,
            prior_ids=prior_ids,
        )

    def _retrieve_priors(
        _run_id: str,
        raw_context: str,
        ignore_prior_ids: list[str],
    ) -> dict[str, Any]:
        return asyncio.run(
            retrieve_priors_for_scope(
                user_id=str(user_id),
                project_id=str(project_id),
                run_id=_run_id,
                raw_context=raw_context,
                ignore_prior_ids=ignore_prior_ids,
            )
        )

    def _prepare(input_dict: dict, api_type: str):
        return prepare_llm_call_for_priors(
            input_dict,
            api_type,
            lookup_prefix_cache_func=_lookup_prefix_cache,
            store_prefix_cache_func=_store_prefix_cache,
            retrieve_priors_func=_retrieve_priors,
        )

    return _prepare


def _persist_prior_metadata_direct(run_id: str, node_uuid: str, metadata) -> None:
    payload = build_prior_metadata_persistence_payload(metadata)
    DB.upsert_prior_retrieval(
        run_id,
        node_uuid,
        retrieval_id=payload["retrieval_id"],
        raw_context=payload["raw_context"],
        processed_context=payload["processed_context"],
        inherited_prior_ids=payload["inherited_prior_ids"],
        retrieved_priors=payload["retrieved_priors"],
        applied_priors=payload["applied_priors"],
        rendered_priors_block=payload["rendered_priors_block"],
        injection_anchor=payload["injection_anchor"],
        model=payload["model"],
        latency_tier=payload["latency_tier"] or "MEDIUM",
        timeout_ms=payload["timeout_ms"],
        retrieval_latency_ms=payload["retrieval_latency_ms"],
        prior_coverage=payload["prior_coverage"],
        retrieval_status=payload["retrieval_status"],
        coverage_status=payload["coverage_status"],
        warning_message=payload["warning_message"],
        error_message=payload["error_message"],
    )
    for prior in payload["applied_priors"]:
        prior_id = prior.get("id")
        if isinstance(prior_id, str) and prior_id:
            DB.add_prior_applied(prior_id, run_id, node_uuid=node_uuid)


def _schedule_prior_coverage_direct(run_id: str, node_uuid: str, metadata=None) -> None:
    if not run_id or not node_uuid:
        return
    if metadata is not None:
        if getattr(metadata, "retrieval_status", None) == "failed":
            return
        if getattr(metadata, "error_message", None):
            return
        if not str(getattr(metadata, "raw_context", "") or "").strip():
            return
        has_retrieval = bool(getattr(metadata, "retrieval_id", None))
        has_applied_priors = bool(getattr(metadata, "applied_priors", None)) or bool(
            getattr(metadata, "inherited_prior_ids", None)
        )
        if not has_retrieval and not has_applied_priors:
            return

    retrieval = DB.get_prior_retrieval(run_id, node_uuid)
    if retrieval is None or retrieval.get("retrieval_status") == "failed":
        return

    llm_call = DB.get_llm_call_full(run_id, node_uuid)
    if llm_call is None or not llm_call["output"]:
        return

    run = DB.get_run_scope(run_id)
    project_id = run["project_id"] if run else None
    project = DB.get_project(project_id) if project_id else None
    track_groundedness = bool(project and project.get("priors_track_groundedness"))
    track_adherence = bool(project and project.get("priors_track_adherence"))
    if not track_groundedness and not track_adherence:
        return

    from sovara.server.priors_backend.llm.lesson_retriever import (
        apply_cached_prior_adherence,
        apply_cached_prior_coverage,
        ensure_prior_coverage_worker_started,
    )

    coverage_complete = not track_groundedness or (
        retrieval.get("coverage_status") == "complete"
        and retrieval.get("prior_coverage") is not None
    )
    adherence_complete = not track_adherence or (
        retrieval.get("adherence_status") == "complete"
        and retrieval.get("prior_adherence") is not None
        and retrieval.get("severity_weighted_prior_adherence") is not None
    )
    if coverage_complete and adherence_complete:
        return

    coverage_cache_hit = coverage_complete or (
        track_groundedness and apply_cached_prior_coverage(retrieval)
    )
    adherence_cache_hit = adherence_complete or (
        track_adherence and apply_cached_prior_adherence(retrieval)
    )
    if coverage_cache_hit and adherence_cache_hit:
        return

    if track_groundedness and not coverage_cache_hit:
        DB.update_prior_coverage(
            retrieval["retrieval_id"],
            prior_coverage=None,
            coverage_status="pending",
        )
    if track_adherence and not adherence_cache_hit:
        DB.update_prior_adherence(
            retrieval["retrieval_id"],
            adherence_status="pending",
        )
    ensure_prior_coverage_worker_started()


def _publish_graph_node_local(
    state: ServerState,
    run_id: str,
    *,
    node_id: str,
    input_dict: dict[str, Any],
    output_obj: Any,
    source_node_ids: list[str],
    api_type: str,
    stack_trace: str | None,
    latency_seconds: float | None,
) -> None:
    handle_add_node(
        state,
        build_add_node_message(
            run_id=run_id,
            node_id=node_id,
            input_dict=input_dict,
            output_obj=output_obj,
            source_node_ids=source_node_ids,
            api_type=api_type,
            stack_trace=stack_trace,
            latency_seconds=latency_seconds,
        ),
    )
    state.schedule_graph_update(run_id)


def _replay_cached_output(output_obj: dict[str, Any]) -> Response:
    status_code = int(output_obj.get("_status_code") or 200)
    headers = filter_proxy_response_headers(output_obj.get("_headers") or {})
    if output_obj.get("_stream"):
        stream_bytes = extract_stream_replay_bytes(output_obj)

        async def _iterate_bytes() -> AsyncIterator[bytes]:
            yield stream_bytes

        media_type = headers.get("content-type", "text/event-stream")
        return StreamingResponse(
            _iterate_bytes(), status_code=status_code, headers=headers, media_type=media_type
        )

    return JSONResponse(
        content=extract_public_response(output_obj),
        status_code=status_code,
        headers=headers,
    )


@router.post("/internal/runner/claude-sdk/tool-use")
def register_claude_sdk_tool_use(
    req: ClaudeSdkToolUseRequest,
    state: ServerState = Depends(get_state),
):
    state.register_claude_sdk_pending_tool_use(
        req.run_id,
        req.tool_use_id,
        {
            "tool_name": req.tool_name,
            "tool_input": copy.deepcopy(req.tool_input),
            "stack_trace": req.stack_trace or "",
        },
    )
    return {"ok": True}


@router.post("/internal/runner/claude-sdk/tool-result")
def finalize_claude_sdk_tool_result(
    req: ClaudeSdkToolResultRequest,
    state: ServerState = Depends(get_state),
):
    pending = state.pop_claude_sdk_pending_tool_use(req.run_id, req.tool_use_id)
    if pending is None:
        raise HTTPException(
            status_code=404,
            detail=f"No pending Claude SDK tool use found for run_id={req.run_id}, tool_use_id={req.tool_use_id}.",
        )

    input_dict = {
        "tool_name": pending.get("tool_name"),
        "tool_input": copy.deepcopy(pending.get("tool_input")),
        "tool_use_id": req.tool_use_id,
    }
    output_obj = {
        "tool_name": str(pending.get("tool_name") or ""),
        "tool_input": pending.get("tool_input"),
        "tool_result": req.tool_result,
    }
    if req.is_error:
        output_obj["status"] = "error"
        if isinstance(req.tool_result, str) and req.tool_result.strip():
            output_obj["error_message"] = req.tool_result.strip()
        else:
            output_obj["error_message"] = "Claude tool returned an error."

    with bind_run_id(req.run_id):
        source_node_ids = find_source_nodes(req.run_id, input_dict, CLAUDE_SDK_API_TYPE)
        cache_result = DB.get_in_out(input_dict, CLAUDE_SDK_API_TYPE)

    stack_trace = str(pending.get("stack_trace") or "")
    if stack_trace:
        cache_result.stack_trace = stack_trace

    def _send_graph_node_and_edges(**kwargs) -> None:
        _publish_graph_node_local(state, req.run_id, **kwargs)

    if cache_result.output is None:
        DB.cache_output(
            cache_result=cache_result, output_obj=output_obj, api_type=CLAUDE_SDK_API_TYPE
        )

    publish_prepared_call_output(
        prepared_call=cache_result,
        api_type=CLAUDE_SDK_API_TYPE,
        source_node_ids=source_node_ids,
        store_output_strings_func=store_output_strings,
        send_graph_node_and_edges_func=_send_graph_node_and_edges,
    )
    return {"ok": True}


@router.post("/claude-proxy/runs/{run_id}/clients/{client_id}/v1/messages/count_tokens")
async def claude_proxy_count_tokens(
    run_id: str,
    client_id: str,
    request: Request,
    state: ServerState = Depends(get_state),
):
    client = _resolve_proxy_client(state, run_id, client_id)
    query = request.url.query
    upstream_url = f"{client['upstream_base_url'].rstrip('/')}{COUNT_TOKENS_PATH}"
    if query:
        upstream_url = f"{upstream_url}?{query}"
    body = await request.body()
    forward_headers = filter_forward_request_headers(request.headers)

    async with httpx.AsyncClient(timeout=None) as client_session:
        upstream_response = await client_session.post(
            upstream_url,
            headers=forward_headers,
            content=body,
        )

    response_headers = filter_proxy_response_headers(upstream_response.headers)
    return Response(
        content=upstream_response.content,
        status_code=upstream_response.status_code,
        headers=response_headers,
        media_type=response_headers.get("content-type"),
    )


@router.post("/claude-proxy/runs/{run_id}/clients/{client_id}/v1/messages")
async def claude_proxy_messages(
    run_id: str,
    client_id: str,
    request: Request,
    state: ServerState = Depends(get_state),
):
    client = _resolve_proxy_client(state, run_id, client_id)
    try:
        request_body = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid JSON request body: {exc}") from exc
    upstream_url = f"{client['upstream_base_url'].rstrip('/')}{MESSAGES_PATH}"
    client_stack_trace = client.get("stack_trace") or None
    input_dict = _build_input_dict(upstream_url=upstream_url, request_body=request_body)
    forward_headers = filter_forward_request_headers(request.headers)

    def _prepare_cache_lookup():
        started_at = time.perf_counter()
        with bind_run_id(run_id):
            prior_preparer = _build_server_side_prior_preparer(run_id)
            source_node_ids = find_source_nodes(run_id, input_dict, API_TYPE)
            cache_result = DB.get_in_out(
                input_dict,
                API_TYPE,
                prepare_runtime_priors=True,
                prior_preparer=prior_preparer,
            )
        logger.debug(
            "Claude proxy cache lookup prepared run_id=%s client_id=%s elapsed_ms=%d",
            run_id,
            client_id,
            int((time.perf_counter() - started_at) * 1000),
        )
        return source_node_ids, cache_result

    source_node_ids, cache_result = await asyncio.to_thread(_prepare_cache_lookup)
    if client_stack_trace:
        cache_result.stack_trace = client_stack_trace

    def _send_graph_node_and_edges(**kwargs) -> None:
        _publish_graph_node_local(state, run_id, **kwargs)

    if cache_result.output is not None:
        publish_prepared_call_output(
            prepared_call=cache_result,
            api_type=API_TYPE,
            source_node_ids=source_node_ids,
            prior_result=cache_result.prior_result,
            persist_prior_metadata_func=_persist_prior_metadata_direct,
            schedule_prior_coverage_func=_schedule_prior_coverage_direct,
            store_output_strings_func=store_output_strings,
            send_graph_node_and_edges_func=_send_graph_node_and_edges,
        )
        return _replay_cached_output(cache_result.output)

    is_stream = bool(cache_result.input_dict.get("body", {}).get("stream"))

    if not is_stream:
        async with httpx.AsyncClient(timeout=None) as client_session:
            try:
                upstream_response = await client_session.post(
                    upstream_url,
                    headers=forward_headers,
                    json=cache_result.input_dict.get("body"),
                )
            except Exception as exc:
                with bind_run_id(run_id):
                    record_prepared_call_exception(
                        prepared_call=cache_result,
                        exc=exc,
                        api_type=API_TYPE,
                        source_node_ids=source_node_ids,
                        record_exception_func=DB.cache_exception,
                        send_graph_node_and_edges_func=_send_graph_node_and_edges,
                        build_exception_output_func=build_exception_output,
                    )
                raise

        response_headers = filter_proxy_response_headers(upstream_response.headers)
        try:
            response_payload = upstream_response.json()
        except Exception:
            response_payload = upstream_response.text

        output_obj = build_nonstream_output_payload(
            response_payload,
            status_code=upstream_response.status_code,
            headers=response_headers,
            fallback_key="error" if upstream_response.status_code >= 400 else "content",
        )

        with bind_run_id(run_id):
            DB.cache_output(cache_result=cache_result, output_obj=output_obj, api_type=API_TYPE)
            publish_prepared_call_output(
                prepared_call=cache_result,
                api_type=API_TYPE,
                source_node_ids=source_node_ids,
                prior_result=cache_result.prior_result,
                persist_prior_metadata_func=_persist_prior_metadata_direct,
                schedule_prior_coverage_func=_schedule_prior_coverage_direct,
                store_output_strings_func=store_output_strings,
                send_graph_node_and_edges_func=_send_graph_node_and_edges,
            )

        return JSONResponse(
            content=extract_public_response(output_obj),
            status_code=upstream_response.status_code,
            headers=response_headers,
        )

    def _fetch_stream_response() -> tuple[int, dict[str, str], str, bytes]:
        started_at = time.perf_counter()
        with httpx.Client(timeout=None) as client_session:
            with client_session.stream(
                "POST",
                upstream_url,
                headers=forward_headers,
                json=cache_result.input_dict.get("body"),
            ) as upstream_response:
                body_bytes = upstream_response.read()
                logger.debug(
                    "Claude proxy upstream stream fetched run_id=%s client_id=%s status=%s bytes=%d elapsed_ms=%d",
                    run_id,
                    client_id,
                    upstream_response.status_code,
                    len(body_bytes),
                    int((time.perf_counter() - started_at) * 1000),
                )
                return (
                    upstream_response.status_code,
                    filter_proxy_response_headers(upstream_response.headers),
                    upstream_response.headers.get("content-type", ""),
                    body_bytes,
                )

    try:
        status_code, response_headers, content_type, body_bytes = await asyncio.to_thread(
            _fetch_stream_response
        )
    except Exception as exc:
        with bind_run_id(run_id):
            record_prepared_call_exception(
                prepared_call=cache_result,
                exc=exc,
                api_type=API_TYPE,
                source_node_ids=source_node_ids,
                record_exception_func=DB.cache_exception,
                send_graph_node_and_edges_func=_send_graph_node_and_edges,
                build_exception_output_func=build_exception_output,
            )
        raise

    if status_code >= 400 or "text/event-stream" not in content_type.lower():
        try:
            response_payload = json.loads(body_bytes.decode("utf-8"))
        except Exception:
            response_payload = body_bytes.decode("utf-8", errors="replace")
        output_obj = build_nonstream_output_payload(
            response_payload,
            status_code=status_code,
            headers=response_headers,
            fallback_key="error",
        )
        with bind_run_id(run_id):
            DB.cache_output(cache_result=cache_result, output_obj=output_obj, api_type=API_TYPE)
            publish_prepared_call_output(
                prepared_call=cache_result,
                api_type=API_TYPE,
                source_node_ids=source_node_ids,
                prior_result=cache_result.prior_result,
                persist_prior_metadata_func=_persist_prior_metadata_direct,
                schedule_prior_coverage_func=_schedule_prior_coverage_direct,
                store_output_strings_func=store_output_strings,
                send_graph_node_and_edges_func=_send_graph_node_and_edges,
            )
        return JSONResponse(
            content=extract_public_response(output_obj),
            status_code=status_code,
            headers=response_headers,
        )

    try:
        raw_stream = body_bytes.decode("utf-8", errors="replace")
        sse_events = parse_sse_events(raw_stream)
        if not sse_events:
            raise RuntimeError("Claude proxy received an invalid SSE stream from upstream.")
        response_payload = assemble_anthropic_message_from_sse_events(sse_events)
        output_obj = build_stream_output_payload(
            response_payload,
            status_code=status_code,
            headers=response_headers,
            sse_events=sse_events,
        )
        with bind_run_id(run_id):
            DB.cache_output(cache_result=cache_result, output_obj=output_obj, api_type=API_TYPE)
            publish_prepared_call_output(
                prepared_call=cache_result,
                api_type=API_TYPE,
                source_node_ids=source_node_ids,
                prior_result=cache_result.prior_result,
                persist_prior_metadata_func=_persist_prior_metadata_direct,
                schedule_prior_coverage_func=_schedule_prior_coverage_direct,
                store_output_strings_func=store_output_strings,
                send_graph_node_and_edges_func=_send_graph_node_and_edges,
            )
    except Exception as exc:
        with bind_run_id(run_id):
            record_prepared_call_exception(
                prepared_call=cache_result,
                exc=exc,
                api_type=API_TYPE,
                source_node_ids=source_node_ids,
                record_exception_func=DB.cache_exception,
                send_graph_node_and_edges_func=_send_graph_node_and_edges,
                build_exception_output_func=build_exception_output,
            )
        raise

    async def _stream_and_capture() -> AsyncIterator[bytes]:
        yield body_bytes

    return StreamingResponse(
        _stream_and_capture(),
        status_code=status_code,
        headers=response_headers,
        media_type=response_headers.get("content-type", "text/event-stream"),
    )
