"""UI REST endpoints -- called by VS Code extension and web app."""

import os
import uuid
from copy import deepcopy
from typing import Literal

from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from sovara.common.constants import PRIORS_SERVER_URL
from sovara.common.project import delete_project_configs
from sovara.common.user import invalidate_user_id_cache, read_user_id, write_user_id
from sovara.runner.priors_pipeline import get_prompt_bearing_patterns, get_system_prompt_bearing_patterns
from sovara.server.app import get_state
from sovara.server.database import DB, BadRequestError
from sovara.server.llm_backend import invalidate_request_config_cache
from sovara.server.llm_provider_catalog import (
    DEFAULT_LOCAL_MODEL_PROVIDER,
    LocalModelProvider,
    discover_local_model_names,
    normalize_local_base_url,
    serialize_local_model_provider_specs,
    supports_local_model_discovery,
)
from sovara.server.package_version import get_package_version_status
from sovara.server.llm_settings import (
    TierName,
    USER_LLM_TIERS,
    normalize_user_llm_settings_row,
    serialize_user_llm_settings_for_client,
    strip_local_model_prefix,
)
from sovara.server.llm_settings_verification import verify_updated_llm_settings
from sovara.server.state import ServerState
from sovara.server.third_party_model_catalog import (
    canonicalize_vendor_model_name,
    derive_third_party_vendor,
    get_third_party_model_catalog,
    get_third_party_vendor_auth_type,
    requires_third_party_base_url,
)

from . import ui_projects as _ui_projects
from . import ui_runs as _ui_runs
from . import ui_trace_chat as _ui_trace_chat

router = APIRouter(prefix="/ui")


def _notify_user_state_changed(state: ServerState) -> None:
    """Broadcast all UI invalidations caused by a local-user identity change."""
    state.notify_user_changed()
    state.notify_project_list_changed()
    state.notify_run_list_changed()


def _serialize_user(row) -> dict:
    return {
        "user_id": row["user_id"],
        "full_name": row["full_name"],
        "email": row["email"],
        "llm_settings": serialize_user_llm_settings_for_client(normalize_user_llm_settings_row(row)),
    }


class SetupUserRequest(BaseModel):
    full_name: str
    email: str


class UpdateUserRequest(BaseModel):
    full_name: str
    email: str


class UpdateUserLlmTierSettingsRequest(BaseModel):
    connection_type: Literal["third_party_api", "locally_hosted"]
    local_provider: LocalModelProvider = DEFAULT_LOCAL_MODEL_PROVIDER
    third_party_vendor: str | None = None
    model_name: str
    api_key: str | None = None
    aws_region: str | None = None
    aws_access_key_id: str | None = None
    aws_secret_access_key: str | None = None
    vertex_project: str | None = None
    vertex_location: str | None = None
    vertex_credentials: str | None = None
    base_url: str | None = None
    clear_api_key: bool = False
    clear_aws_access_key_id: bool = False
    clear_aws_secret_access_key: bool = False


class UpdateUserLlmSettingsRequest(BaseModel):
    primary: UpdateUserLlmTierSettingsRequest | None = None
    helper: UpdateUserLlmTierSettingsRequest | None = None
    ultra_helper: UpdateUserLlmTierSettingsRequest | None = None
    embedding: UpdateUserLlmTierSettingsRequest | None = None
    reranker: UpdateUserLlmTierSettingsRequest | None = None


class DeleteUserLlmTierCredentialsRequest(BaseModel):
    tier: TierName


class DeleteUserRequest(BaseModel):
    confirmation_name: str


OPTIONAL_TIER_CREDENTIAL_FIELDS = ("api_key", "aws_region", "aws_access_key_id", "aws_secret_access_key", "vertex_project", "vertex_location", "vertex_credentials")


def _trim_optional_text(value: str | None) -> str | None:
    return value.strip() or None if isinstance(value, str) else None


def _merge_secret_value(provided: str | None, clear: bool, current_value: str | None) -> str | None:
    return provided or (None if clear else current_value)


def _normalize_third_party_tier_settings_request(
    tier: TierName,
    current_tier: dict,
    tier_req: UpdateUserLlmTierSettingsRequest,
    model_name: str,
    base_url: str | None,
) -> dict:
    credential_requirements = {
        "api_key": [("api_key", "API key")],
        "aws_credentials": [("aws_region", "AWS region"), ("aws_access_key_id", "AWS access key ID"), ("aws_secret_access_key", "AWS secret access key")],
        "vertex_credentials": [("vertex_project", "Vertex project"), ("vertex_location", "Vertex location")],
    }
    third_party_vendor = _trim_optional_text(tier_req.third_party_vendor) or derive_third_party_vendor(model_name)
    if not third_party_vendor:
        raise BadRequestError(f"{tier.title()} vendor is required for Third-party API.")
    if not model_name:
        raise BadRequestError(f"{tier.title()} model is required for Third-party API.")

    auth_type = get_third_party_vendor_auth_type(third_party_vendor)
    requires_base_url = requires_third_party_base_url(third_party_vendor)
    canonical_model_name = canonicalize_vendor_model_name(third_party_vendor, model_name) or model_name
    api_key = _merge_secret_value(
        _trim_optional_text(tier_req.api_key),
        tier_req.clear_api_key,
        current_tier.get("api_key"),
    )
    aws_region = _trim_optional_text(tier_req.aws_region) or current_tier.get("aws_region")
    aws_access_key_id = _merge_secret_value(
        _trim_optional_text(tier_req.aws_access_key_id),
        tier_req.clear_aws_access_key_id,
        current_tier.get("aws_access_key_id"),
    )
    aws_secret_access_key = _merge_secret_value(
        _trim_optional_text(tier_req.aws_secret_access_key),
        tier_req.clear_aws_secret_access_key,
        current_tier.get("aws_secret_access_key"),
    )
    vertex_project = _trim_optional_text(tier_req.vertex_project) or current_tier.get("vertex_project")
    vertex_location = _trim_optional_text(tier_req.vertex_location) or current_tier.get("vertex_location")
    vertex_credentials = _trim_optional_text(tier_req.vertex_credentials) or current_tier.get("vertex_credentials")
    credential_values = {
        "api_key": api_key,
        "aws_region": aws_region,
        "aws_access_key_id": aws_access_key_id,
        "aws_secret_access_key": aws_secret_access_key,
        "vertex_project": vertex_project,
        "vertex_location": vertex_location,
        "vertex_credentials": vertex_credentials,
    }

    enabled_fields = {field_name for field_name, _ in credential_requirements[auth_type]}

    if requires_base_url and not base_url:
        raise BadRequestError(f"{tier.title()} Endpoint is required for Third-party API.")
    for field_name, label in credential_requirements[auth_type]:
        if not credential_values[field_name]:
            raise BadRequestError(f"{tier.title()} {label} is required for Third-party API.")

    return {
        "connection_type": tier_req.connection_type,
        "local_provider": tier_req.local_provider,
        "third_party_vendor": third_party_vendor,
        "model_name": canonical_model_name,
        **{
            field_name: value if field_name in enabled_fields else None
            for field_name, value in credential_values.items()
        },
        "base_url": base_url if requires_base_url else None,
    }


def _normalize_local_tier_settings_request(
    tier: TierName,
    tier_req: UpdateUserLlmTierSettingsRequest,
    model_name: str,
    base_url: str | None,
) -> dict:
    if not base_url:
        raise BadRequestError(f"{tier.title()} Endpoint is required for Locally hosted.")
    if not model_name:
        raise BadRequestError(f"{tier.title()} model name is required.")

    return {
        "connection_type": tier_req.connection_type,
        "local_provider": tier_req.local_provider,
        "third_party_vendor": None,
        "model_name": strip_local_model_prefix(model_name) or model_name,
        **{field_name: None for field_name in OPTIONAL_TIER_CREDENTIAL_FIELDS},
        "base_url": base_url,
    }


def _normalize_user_llm_tier_settings_request(
    tier: TierName,
    current_tier: dict,
    tier_req: UpdateUserLlmTierSettingsRequest,
) -> dict:
    model_name = tier_req.model_name.strip()
    base_url = _trim_optional_text(tier_req.base_url)
    if tier_req.connection_type == "third_party_api":
        return _normalize_third_party_tier_settings_request(
            tier,
            current_tier,
            tier_req,
            model_name,
            base_url,
        )
    return _normalize_local_tier_settings_request(tier, tier_req, model_name, base_url)


def _merge_user_llm_settings_request(req: UpdateUserLlmSettingsRequest, current_settings: dict) -> tuple[dict, list[str]]:
    merged = deepcopy(current_settings)
    updated_tiers: list[str] = []
    for tier in USER_LLM_TIERS:
        tier_req = getattr(req, tier)
        if tier_req is None:
            continue
        merged[tier] = _normalize_user_llm_tier_settings_request(tier, merged[tier], tier_req)
        updated_tiers.append(tier)

    if not updated_tiers:
        raise BadRequestError("At least one model settings tier is required.")

    return merged, updated_tiers


def _delete_user_llm_tier_credentials(
    tier: TierName,
    current_settings: dict,
) -> tuple[dict, Literal["api_key", "aws_credentials", "vertex_credentials"]]:
    updated_settings = deepcopy(current_settings)
    current_tier = deepcopy(updated_settings[tier])
    if current_tier.get("connection_type") != "third_party_api":
        raise BadRequestError(f"{tier.title()} credentials can only be deleted for Third-party API.")

    vendor = derive_third_party_vendor(current_tier.get("model_name"))
    auth_type = get_third_party_vendor_auth_type(vendor)
    if auth_type == "aws_credentials":
        current_tier["aws_access_key_id"] = None
        current_tier["aws_secret_access_key"] = None
    elif auth_type == "vertex_credentials":
        current_tier["vertex_credentials"] = None
    else:
        current_tier["api_key"] = None

    updated_settings[tier] = current_tier
    return updated_settings, auth_type


@router.get("/config")
def get_ui_config():
    """Return static UI bootstrap configuration."""
    third_party_catalog = get_third_party_model_catalog("chat")
    embedding_catalog = get_third_party_model_catalog("embedding")
    rerank_catalog = get_third_party_model_catalog("rerank")
    return {
        "package": get_package_version_status(),
        "priors_url": PRIORS_SERVER_URL,
        "prompt_bearing_patterns": get_prompt_bearing_patterns(),
        "system_prompt_bearing_patterns": get_system_prompt_bearing_patterns(),
        "llm": {
            "default_local_provider": DEFAULT_LOCAL_MODEL_PROVIDER,
            "local_model_providers": serialize_local_model_provider_specs(),
            "third_party_vendors": third_party_catalog["third_party_vendors"],
            "third_party_models_by_vendor": third_party_catalog["third_party_models_by_vendor"],
            "third_party_catalogs": {
                "chat": third_party_catalog,
                "embedding": embedding_catalog,
                "rerank": rerank_catalog,
            },
        },
    }


@router.get("/user")
def get_user():
    """Get the local user's info."""
    user_id = read_user_id()
    if not user_id:
        return {"user": None}
    row = DB.get_user(user_id)
    if not row:
        return {"user": None}
    return {"user": _serialize_user(row)}


@router.get("/local-models")
def get_local_models(
    provider: LocalModelProvider = Query(...),
    base_url: str | None = Query(default=None),
):
    """List models exposed by a supported locally-hosted provider."""
    normalized_base_url = normalize_local_base_url(provider, base_url)
    if not supports_local_model_discovery(provider):
        return JSONResponse(
            status_code=400,
            content={"error": "Model discovery is not supported for this local server."},
        )

    try:
        resolved_base_url, model_names = discover_local_model_names(provider, base_url)
    except ValueError as exc:
        return JSONResponse(status_code=400, content={"error": str(exc)})
    except Exception:
        return JSONResponse(status_code=400, content={"error": "Could not load models from the local server."})

    return {
        "provider": provider,
        "base_url": resolved_base_url or normalized_base_url,
        "models": [{"label": model_name, "value": model_name} for model_name in model_names],
    }


@router.post("/setup-user")
def setup_user(req: SetupUserRequest, state: ServerState = Depends(get_state)):
    """Create or update the local user profile."""
    if not req.full_name.strip():
        return JSONResponse(status_code=400, content={"error": "Full name is required."})
    if not req.email.strip():
        return JSONResponse(status_code=400, content={"error": "Email is required."})

    user_id = read_user_id()
    if not user_id:
        user_id = str(uuid.uuid4())
        write_user_id(user_id)

    DB.upsert_user(user_id, req.full_name.strip(), req.email.strip())
    row = DB.get_user(user_id)
    _notify_user_state_changed(state)
    return {"user": _serialize_user(row)}


@router.post("/update-user")
def update_user(req: UpdateUserRequest, state: ServerState = Depends(get_state)):
    """Update the local user's profile."""
    user_id = read_user_id()
    if not user_id:
        return JSONResponse(status_code=404, content={"error": "No user configured."})
    if not req.full_name.strip():
        return JSONResponse(status_code=400, content={"error": "Full name is required."})
    if not req.email.strip():
        return JSONResponse(status_code=400, content={"error": "Email is required."})
    DB.upsert_user(user_id, req.full_name.strip(), req.email.strip())
    row = DB.get_user(user_id)
    _notify_user_state_changed(state)
    return {"user": _serialize_user(row)}


@router.post("/update-user-llm-settings")
def update_user_llm_settings(req: UpdateUserLlmSettingsRequest, state: ServerState = Depends(get_state)):
    """Update the local user's persisted trace-chat model settings."""
    user_id = read_user_id()
    if not user_id:
        return JSONResponse(status_code=404, content={"error": "No user configured."})
    row = DB.get_user(user_id)
    if not row:
        return JSONResponse(status_code=404, content={"error": "User not found."})

    current_settings = normalize_user_llm_settings_row(row)

    try:
        normalized, updated_tiers = _merge_user_llm_settings_request(req, current_settings)
        verify_updated_llm_settings(updated_tiers, normalized, current_settings)
    except BadRequestError as exc:
        return JSONResponse(status_code=400, content={"error": str(exc)})

    DB.update_user_llm_settings(user_id, normalized)
    invalidate_request_config_cache(user_id)
    updated_row = DB.get_user(user_id)
    _notify_user_state_changed(state)
    return {"user": _serialize_user(updated_row)}


@router.post("/delete-user-llm-tier-credentials")
def delete_user_llm_tier_credentials(
    req: DeleteUserLlmTierCredentialsRequest,
    state: ServerState = Depends(get_state),
):
    """Delete persisted third-party credentials for a single LLM settings tier."""
    user_id = read_user_id()
    if not user_id:
        return JSONResponse(status_code=404, content={"error": "No user configured."})
    row = DB.get_user(user_id)
    if not row:
        return JSONResponse(status_code=404, content={"error": "User not found."})

    current_settings = normalize_user_llm_settings_row(row)

    try:
        normalized, auth_type = _delete_user_llm_tier_credentials(req.tier, current_settings)
    except BadRequestError as exc:
        return JSONResponse(status_code=400, content={"error": str(exc)})

    DB.update_user_llm_settings(user_id, normalized)
    invalidate_request_config_cache(user_id)
    updated_row = DB.get_user(user_id)
    _notify_user_state_changed(state)
    return {
        "auth_type": auth_type,
        "tier": req.tier,
        "user": _serialize_user(updated_row),
    }


@router.post("/delete-user")
def delete_user(req: DeleteUserRequest, state: ServerState = Depends(get_state)):
    """Delete the local user and all associated data."""
    user_id = read_user_id()
    if not user_id:
        return JSONResponse(status_code=404, content={"error": "No user configured."})
    row = DB.get_user(user_id)
    if not row:
        return JSONResponse(status_code=404, content={"error": "User not found."})
    if req.confirmation_name != row["full_name"]:
        return JSONResponse(status_code=400, content={"error": "Name does not match."})
    delete_project_configs(DB.get_user_project_locations(user_id))
    DB.delete_user(user_id)

    from sovara.common.constants import USER_ID_PATH

    if os.path.isfile(USER_ID_PATH):
        os.remove(USER_ID_PATH)
    invalidate_user_id_cache()
    _notify_user_state_changed(state)
    return {"ok": True}


@router.post("/refresh-user")
def refresh_user(state: ServerState = Depends(get_state)):
    """Broadcast that the local user identity changed outside the server process."""
    invalidate_user_id_cache()
    _notify_user_state_changed(state)
    return {"ok": True}


# ── DB Settings ───────────────────────────────────────────────────────────────

_VALID_BACKENDS = frozenset({"sqlite", "mongodb", "postgresql"})


class UpdateDbSettingsRequest(BaseModel):
    backend: str
    mongodb_uri: str | None = None
    mongodb_db: str | None = None
    pg_dsn: str | None = None


class TestDbConnectionRequest(BaseModel):
    backend: str
    mongodb_uri: str | None = None
    mongodb_db: str | None = None
    pg_dsn: str | None = None


def _probe_backend(backend: str, mongodb_uri: str | None, mongodb_db: str | None, pg_dsn: str | None) -> str | None:
    """Try a lightweight operation against the proposed backend config.

    Returns ``None`` on success or an error message string on failure.
    """
    try:
        if backend == "sqlite":
            from sovara.server.database.sqlite.connection import get_conn
            conn = get_conn()
            conn.execute("SELECT 1")
            conn.close()

        elif backend == "mongodb":
            try:
                import pymongo
            except ImportError:
                return "pymongo is not installed. Run: pip install pymongo"
            uri = mongodb_uri or "mongodb://localhost:27017"
            db_name = mongodb_db or "sovara"
            client = pymongo.MongoClient(uri, serverSelectionTimeoutMS=3_000, connectTimeoutMS=3_000)
            client[db_name].list_collection_names()
            client.close()

        elif backend == "postgresql":
            try:
                import psycopg2
                import psycopg2.extras
            except ImportError:
                return "psycopg2 is not installed. Run: pip install psycopg2-binary"
            dsn = pg_dsn or "postgresql://localhost:5432/sovara"
            conn = psycopg2.connect(dsn, connect_timeout=3)
            conn.cursor().execute("SELECT 1")
            conn.close()

        else:
            return f"Unknown backend {backend!r}."

    except Exception as exc:
        return str(exc)

    return None


@router.get("/db-settings")
def get_db_settings():
    """Return the effective DB configuration (config.yaml > env var > default)."""
    from sovara.common.config import get_db_config
    return get_db_config()


@router.post("/update-db-settings")
def update_db_settings(req: UpdateDbSettingsRequest, state: ServerState = Depends(get_state)):
    """Persist new DB settings to config.yaml and hot-swap the backend."""
    backend = req.backend.strip().lower()
    if backend not in _VALID_BACKENDS:
        return JSONResponse(status_code=400, content={"error": f"Invalid backend {backend!r}. Choose: sqlite, mongodb, postgresql."})

    # Validate connection before committing
    error = _probe_backend(backend, req.mongodb_uri, req.mongodb_db, req.pg_dsn)
    if error:
        return JSONResponse(status_code=400, content={"error": f"Connection test failed: {error}"})

    from sovara.common.config import save_db_config
    save_db_config(backend=backend, mongodb_uri=req.mongodb_uri, mongodb_db=req.mongodb_db, pg_dsn=req.pg_dsn)
    DB.reset_backend()
    state.notify_db_settings_changed()

    from sovara.common.config import get_db_config
    return get_db_config()


@router.post("/test-db-connection")
def test_db_connection(req: TestDbConnectionRequest):
    """Test a DB connection without persisting anything."""
    backend = req.backend.strip().lower()
    if backend not in _VALID_BACKENDS:
        return JSONResponse(status_code=400, content={"error": f"Invalid backend {backend!r}."})

    error = _probe_backend(backend, req.mongodb_uri, req.mongodb_db, req.pg_dsn)
    if error:
        return {"ok": False, "error": error}
    return {"ok": True}


router.include_router(_ui_projects.router)
router.include_router(_ui_runs.router)
router.include_router(_ui_trace_chat.router)

CreateProjectRequest = _ui_projects.CreateProjectRequest
UpdateProjectLocationRequest = _ui_projects.UpdateProjectLocationRequest
DeleteProjectLocationRequest = _ui_projects.DeleteProjectLocationRequest
DeleteProjectLocationsRequest = _ui_projects.DeleteProjectLocationsRequest
UpdateProjectRequest = _ui_projects.UpdateProjectRequest
DeleteProjectRequest = _ui_projects.DeleteProjectRequest
CreateProjectTagRequest = _ui_projects.CreateProjectTagRequest
DeleteProjectTagRequest = _ui_projects.DeleteProjectTagRequest
pick_directory = _ui_projects.pick_directory
create_project = _ui_projects.create_project
update_project_location = _ui_projects.update_project_location
update_project = _ui_projects.update_project
delete_project_location = _ui_projects.delete_project_location
delete_project_locations = _ui_projects.delete_project_locations
delete_project = _ui_projects.delete_project
get_projects = _ui_projects.get_projects
get_project = _ui_projects.get_project
get_project_tags = _ui_projects.get_project_tags
create_project_tag = _ui_projects.create_project_tag
delete_project_tag = _ui_projects.delete_project_tag

EditInputRequest = _ui_runs.EditInputRequest
EditOutputRequest = _ui_runs.EditOutputRequest
UpdateNodeRequest = _ui_runs.UpdateNodeRequest
UpdateRunNameRequest = _ui_runs.UpdateRunNameRequest
UpdateThumbLabelRequest = _ui_runs.UpdateThumbLabelRequest
UpdateNotesRequest = _ui_runs.UpdateNotesRequest
RestartRequest = _ui_runs.RestartRequest
EraseRequest = _ui_runs.EraseRequest
DeleteRunsRequest = _ui_runs.DeleteRunsRequest
UpdateRunTagsRequest = _ui_runs.UpdateRunTagsRequest
PrepareEditRerunRequest = _ui_runs.PrepareEditRerunRequest
delete_runs = _ui_runs.delete_runs
get_project_runs = _ui_runs.get_project_runs
get_graph = _ui_runs.get_graph
probe_run = _ui_runs.probe_run
get_run_log = _ui_runs.get_run_log
get_runs = _ui_runs.get_runs
get_more_runs = _ui_runs.get_more_runs
get_run_detail = _ui_runs.get_run_detail
get_node_prior_retrieval = _ui_runs.get_node_prior_retrieval
get_run_prior_retrievals = _ui_runs.get_run_prior_retrievals
get_priors_applied = _ui_runs.get_priors_applied
get_runs_for_prior = _ui_runs.get_runs_for_prior
edit_input = _ui_runs.edit_input
edit_output = _ui_runs.edit_output
update_node = _ui_runs.update_node
update_run_name = _ui_runs.update_run_name
update_thumb_label = _ui_runs.update_thumb_label
update_run_tags = _ui_runs.update_run_tags
update_notes = _ui_runs.update_notes
restart = _ui_runs.restart
prepare_run_edit_rerun = _ui_runs.prepare_run_edit_rerun
erase = _ui_runs.erase
shutdown = _ui_runs.shutdown
clear = _ui_runs.clear

PersistedTraceChatMessage = _ui_trace_chat.PersistedTraceChatMessage
ChatMessageRequest = _ui_trace_chat.ChatMessageRequest
PersistedTraceChatHistoryRequest = _ui_trace_chat.PersistedTraceChatHistoryRequest
get_trace_chat_history = _ui_trace_chat.get_trace_chat_history
update_trace_chat_history = _ui_trace_chat.update_trace_chat_history
clear_trace_chat_history = _ui_trace_chat.clear_trace_chat_history
prefetch_trace = _ui_trace_chat.prefetch_trace
chat = _ui_trace_chat.chat
abort_trace_chat = _ui_trace_chat.abort_trace_chat
