"""Project-related UI routes."""

import os
import uuid

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from sovara.common.project import (
    delete_project_configs,
    find_project_root,
    is_project_name_available,
    normalize_project_name,
    read_project_id,
    suggest_available_project_name,
    suggest_project_name_for_root,
    write_project_id,
)
from sovara.common.user import read_user_id
from sovara.server.app import get_state
from sovara.server.database import DB
from sovara.server.priors_backend.constants import (
    DEFAULT_PRIORS_LATENCY_TIER,
    LATENCY_TIERS,
)
from sovara.server.state import ServerState

router = APIRouter()

TAG_COLORS = {
    "#0969da",
    "#1a7f37",
    "#cf222e",
    "#bf8700",
    "#8250df",
    "#e85aad",
    "#0598d5",
    "#d1570a",
    "#5e60ce",
    "#1b8a72",
}


class CreateProjectRequest(BaseModel):
    name: str
    description: str = ""
    location: str


class ResolveProjectLocationRequest(BaseModel):
    location: str


class UpdateProjectLocationRequest(BaseModel):
    project_id: str
    old_location: str
    new_location: str


class DeleteProjectLocationRequest(BaseModel):
    project_id: str
    location: str


class DeleteProjectLocationsRequest(BaseModel):
    project_id: str
    locations: list[str]


class UpdateProjectRequest(BaseModel):
    project_id: str
    name: str
    description: str = ""
    priors_latency_tier: str = DEFAULT_PRIORS_LATENCY_TIER
    priors_track_groundedness: bool = False
    priors_track_adherence: bool = False


class DeleteProjectRequest(BaseModel):
    project_id: str
    confirmation_name: str


class CreateProjectTagRequest(BaseModel):
    name: str
    color: str


class DeleteProjectTagRequest(BaseModel):
    tag_id: str


def _project_name_conflict_response(name: str, *, exclude_project_id: str | None = None) -> JSONResponse:
    normalized_name = normalize_project_name(name)
    return JSONResponse(
        status_code=409,
        content={
            "error": f"A project named '{normalized_name}' already exists.",
            "suggested_name": suggest_available_project_name(
                normalized_name,
                exclude_project_id=exclude_project_id,
            ),
        },
    )


def _project_payload(project: dict, **extra) -> dict:
    payload = {
        "project_id": project["project_id"],
        "name": project["name"],
        "description": project["description"] or "",
        "priors_latency_tier": project["priors_latency_tier"],
        "priors_track_groundedness": bool(project.get("priors_track_groundedness")),
        "priors_track_adherence": bool(project.get("priors_track_adherence")),
    }
    payload.update(extra)
    return payload


def _existing_project_location_response(project: dict, project_root: str) -> dict:
    return {
        "status": "existing",
        "project": _project_payload(project),
        "project_root": project_root,
    }


@router.post("/pick-directory")
def pick_directory():
    """Open native OS folder picker and return the selected path."""
    import subprocess
    import sys

    path = None
    try:
        if sys.platform == "darwin":
            result = subprocess.run(
                ["osascript", "-e", 'POSIX path of (choose folder with prompt "Select Project Location")'],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode == 0:
                path = result.stdout.strip().rstrip("/")
        elif sys.platform == "win32":
            ps_script = (
                "Add-Type -AssemblyName System.Windows.Forms; "
                "$d = New-Object System.Windows.Forms.FolderBrowserDialog; "
                "if ($d.ShowDialog() -eq 'OK') { $d.SelectedPath }"
            )
            result = subprocess.run(
                ["powershell", "-Command", ps_script],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode == 0 and result.stdout.strip():
                path = result.stdout.strip()
        else:
            for cmd in [
                ["zenity", "--file-selection", "--directory", "--title=Select Project Location"],
                ["kdialog", "--getexistingdirectory", "."],
            ]:
                try:
                    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
                    if result.returncode == 0 and result.stdout.strip():
                        path = result.stdout.strip()
                        break
                except FileNotFoundError:
                    continue
    except subprocess.TimeoutExpired:
        pass

    return {"path": path}


@router.post("/projects/resolve-location")
def resolve_project_location(req: ResolveProjectLocationRequest, state: ServerState = Depends(get_state)):
    user_id = read_user_id()
    if not user_id:
        return JSONResponse(status_code=403, content={
            "error": "No user configured. Run so-record once to set up your user profile."
        })

    location = os.path.abspath(req.location)
    if not os.path.isdir(location):
        return JSONResponse(status_code=400, content={"error": f"Directory does not exist: {location}"})

    project_root = find_project_root(location)
    if project_root:
        project_id = read_project_id(project_root)
        project = DB.get_project(project_id)
        if not project:
            DB.upsert_project(
                project_id,
                suggest_project_name_for_root(project_root, exclude_project_id=project_id),
                "",
                DEFAULT_PRIORS_LATENCY_TIER,
            )
            state.notify_project_list_changed()
            project = DB.get_project(project_id)
        DB.upsert_project_location(user_id, project_id, project_root)
        return _existing_project_location_response(project, project_root)

    result = DB.find_project_for_location(user_id, location)
    if result:
        project_id, project_root = result
        project = DB.get_project(project_id)
        if project:
            return _existing_project_location_response(project, project_root)

    return {
        "status": "missing",
        "location": location,
        "suggested_name": suggest_project_name_for_root(location),
    }


@router.post("/create-project")
def create_project(req: CreateProjectRequest, state: ServerState = Depends(get_state)):
    """Create a new project with validation."""
    user_id = read_user_id()
    if not user_id:
        return JSONResponse(status_code=403, content={
            "error": "No user configured. Run so-record once to set up your user profile."
        })

    try:
        normalized_name = normalize_project_name(req.name)
    except ValueError as exc:
        return JSONResponse(status_code=400, content={"error": str(exc)})
    normalized_description = req.description.strip()
    location = os.path.abspath(req.location)

    if not os.path.isdir(location):
        return JSONResponse(status_code=400, content={"error": f"Directory does not exist: {location}"})

    project_root = find_project_root(location)
    if project_root:
        project_id = read_project_id(project_root)
        existing = DB.get_project(project_id)
        if existing:
            return JSONResponse(status_code=409, content={
                "error": f"This directory is already part of project '{existing['name']}' (root: {project_root})."
            })
        location = project_root
    else:
        project_id = str(uuid.uuid4())

    if not is_project_name_available(normalized_name):
        return _project_name_conflict_response(normalized_name)

    if project_root is None:
        write_project_id(location, project_id)

    DB.upsert_project(project_id, normalized_name, normalized_description, DEFAULT_PRIORS_LATENCY_TIER)
    DB.upsert_project_location(user_id, project_id, location)
    state.notify_project_list_changed()

    return {"project_id": project_id, "name": normalized_name}


@router.post("/update-project-location")
def update_project_location(req: UpdateProjectLocationRequest):
    """Update a project location (e.g. after moving the project folder)."""
    user_id = read_user_id()
    if not user_id:
        return JSONResponse(status_code=403, content={"error": "No user configured."})

    new_location = os.path.abspath(req.new_location)
    if not os.path.isdir(new_location):
        return JSONResponse(status_code=400, content={"error": f"Directory does not exist: {new_location}"})

    write_project_id(new_location, req.project_id)
    DB.delete_project_location(user_id, req.project_id, req.old_location)
    DB.upsert_project_location(user_id, req.project_id, new_location)

    return {"ok": True}


@router.post("/update-project")
def update_project(req: UpdateProjectRequest, state: ServerState = Depends(get_state)):
    """Update project name and description."""
    project = DB.get_project(req.project_id)
    if not project:
        return JSONResponse(status_code=404, content={"error": "Project not found."})
    try:
        normalized_name = normalize_project_name(req.name)
    except ValueError as exc:
        return JSONResponse(status_code=400, content={"error": str(exc)})
    normalized_description = req.description.strip()
    normalized_tier = str(req.priors_latency_tier or DEFAULT_PRIORS_LATENCY_TIER).upper()
    if normalized_tier not in LATENCY_TIERS:
        return JSONResponse(status_code=400, content={"error": "Invalid priors latency tier."})
    if not is_project_name_available(normalized_name, exclude_project_id=req.project_id):
        return _project_name_conflict_response(normalized_name, exclude_project_id=req.project_id)
    DB.upsert_project(
        req.project_id,
        normalized_name,
        normalized_description,
        normalized_tier,
        req.priors_track_groundedness,
        req.priors_track_adherence,
    )
    state.notify_project_list_changed()
    return {"project": _project_payload(DB.get_project(req.project_id))}


@router.post("/delete-project-location")
def delete_project_location(req: DeleteProjectLocationRequest):
    """Remove a single project location."""
    user_id = read_user_id()
    if not user_id:
        return JSONResponse(status_code=403, content={"error": "No user configured."})
    DB.delete_project_location(user_id, req.project_id, req.location)
    delete_project_configs([req.location])
    return {"ok": True}


@router.post("/delete-project-locations")
def delete_project_locations(req: DeleteProjectLocationsRequest, state: ServerState = Depends(get_state)):
    """Remove multiple project locations at once."""
    user_id = read_user_id()
    if not user_id:
        return JSONResponse(status_code=403, content={"error": "No user configured."})

    project = DB.get_project(req.project_id)
    if not project:
        return JSONResponse(status_code=404, content={"error": "Project not found."})

    unique_locations = list(dict.fromkeys(req.locations))
    if not unique_locations:
        return {"ok": True, "deleted_count": 0}

    existing_locations = [row["project_location"] for row in DB.get_all_project_locations(req.project_id)]
    remaining_locations = [
        location
        for location in existing_locations
        if location not in set(unique_locations)
    ]
    if not remaining_locations:
        return JSONResponse(
            status_code=400,
            content={"error": "Cannot remove all locations from a project. Delete the project instead."},
        )

    for location in unique_locations:
        DB.delete_project_location(user_id, req.project_id, location)

    delete_project_configs(unique_locations)
    state.notify_project_list_changed()
    return {"ok": True, "deleted_count": len(unique_locations)}


@router.post("/delete-project")
def delete_project(req: DeleteProjectRequest, state: ServerState = Depends(get_state)):
    """Delete an entire project and all associated data."""
    project = DB.get_project(req.project_id)
    if not project:
        return JSONResponse(status_code=404, content={"error": "Project not found."})
    if req.confirmation_name != project["name"]:
        return JSONResponse(status_code=400, content={"error": "Name does not match."})
    locations = DB.get_all_project_locations(req.project_id)
    delete_project_configs([row["project_location"] for row in locations])
    DB.delete_project(req.project_id)
    state.notify_run_list_changed()
    state.notify_project_list_changed()
    return {"ok": True}


def _validate_location(path: str, expected_project_id: str) -> bool:
    """Check if a location is valid: directory exists and .sovara/.project_id matches."""
    if not os.path.isdir(path):
        return False
    project_root = find_project_root(path)
    if not project_root:
        return False
    try:
        return read_project_id(project_root) == expected_project_id
    except Exception:
        return False


@router.get("/projects")
def get_projects():
    """List all projects with run counts and location sync status."""
    projects = DB.get_all_projects()
    result = []
    for project in projects:
        project_id = project["project_id"]
        run_count = DB.get_run_count(project_id=project_id)
        location_rows = DB.get_all_project_locations(project_id)
        locations = []
        location_warning = False
        for row in location_rows:
            path = row["project_location"]
            valid = _validate_location(path, project_id)
            locations.append({"path": path, "valid": valid})
            if not valid:
                location_warning = True
        result.append(
            _project_payload(
                project,
                created_at=project["created_at"],
                last_run_at=project["last_run_at"],
                num_runs=run_count,
                num_users=DB.get_project_user_count(project_id),
                locations=locations,
                location_warning=location_warning,
            )
        )
    return {"projects": result}


@router.get("/projects/{project_id}")
def get_project(project_id: str):
    """Get a single project by ID."""
    project = DB.get_project(project_id)
    if not project:
        return JSONResponse(status_code=404, content={"error": "Project not found."})
    return _project_payload(project)


@router.get("/projects/{project_id}/tags")
def get_project_tags(project_id: str):
    project = DB.get_project(project_id)
    if not project:
        return JSONResponse(status_code=404, content={"error": "Project not found."})
    return {"tags": DB.get_project_tags(project_id)}


@router.post("/projects/{project_id}/tags")
def create_project_tag(project_id: str, req: CreateProjectTagRequest, state: ServerState = Depends(get_state)):
    if req.color not in TAG_COLORS:
        return JSONResponse(status_code=400, content={"error": "Invalid tag color."})
    try:
        tag = DB.create_project_tag(project_id, req.name.strip(), req.color)
    except ValueError as exc:
        message = str(exc)
        if "already exists" in message:
            status_code = 409
        elif "Project not found" in message:
            status_code = 404
        else:
            status_code = 400
        return JSONResponse(status_code=status_code, content={"error": message})
    state.notify_run_list_changed()
    return {"tag": tag}


@router.post("/projects/{project_id}/tags/delete")
def delete_project_tag(project_id: str, req: DeleteProjectTagRequest, state: ServerState = Depends(get_state)):
    try:
        DB.delete_project_tag(project_id, req.tag_id)
    except ValueError as exc:
        message = str(exc)
        status_code = 404 if "not found" in message.lower() else 400
        return JSONResponse(status_code=status_code, content={"error": message})
    state.notify_run_list_changed()
    return {"ok": True}
