"""Internal server-only REST endpoints."""

import asyncio
import uuid
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field

from sovara.common.constants import MAIN_SERVER_LOG
from sovara.common.logger import create_file_logger
from sovara.server.app import get_state
from sovara.server.database import DB
from sovara.server.handlers.ui_handlers import handle_update_llm_verdicts
from sovara.server import llm_backend
from sovara.server.llm_backend import StructuredInferenceError
from sovara.server.priors_backend.routes import (
    lookup_prefix_cache_for_scope,
    query_priors_for_scope,
    retrieve_priors_for_scope,
    store_prefix_cache_for_scope,
)
from sovara.server.priors_backend.llm.lesson_retriever import (
    apply_cached_prior_adherence,
    apply_cached_prior_coverage,
    ensure_prior_coverage_worker_started,
)
from sovara.server.priors_backend.tools.preprocess_context import normalize_raw_context
from sovara.server.state import ServerState

router = APIRouter(prefix="/internal")
main_server_logger = create_file_logger(MAIN_SERVER_LOG)


def _preview_exception_raw_text(raw_text: str, max_len: int = 2000) -> str:
    text = (raw_text or "").strip()
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."


class InternalPriorsRetrieveRequest(BaseModel):
    run_id: str
    raw_context: str | None = None
    context: str | None = None
    base_path: str | None = None
    ignore_prior_ids: list[str] = Field(default_factory=list)


class InternalPriorsQueryRequest(BaseModel):
    run_id: str
    path: str | None = None


class InternalPrefixCacheLookupRequest(BaseModel):
    run_id: str
    clean_pairs: list[dict[str, str]] = Field(default_factory=list)


class InternalPrefixCacheStoreRequest(BaseModel):
    run_id: str
    clean_pairs: list[dict[str, str]] = Field(default_factory=list)
    injected_pairs: list[dict[str, str]] = Field(default_factory=list)
    prior_ids: list[str] = Field(default_factory=list)


class InternalRunnerRunScopeRequest(BaseModel):
    run_id: str


class InternalRunnerLlmLookupRequest(BaseModel):
    run_id: str
    input_hash: str
    input_pickle: str | None = None
    api_type: str | None = None
    stack_trace: str | None = None
    node_kind: str | None = None
    prompt_suffix_json: str = "[]"


class InternalRunnerFinalizeLlmCallRequest(BaseModel):
    run_id: str
    node_uuid: str
    status: str
    input_pickle: str | None = None
    input_hash: str | None = None
    output_json: str | None = None
    error_json: str | None = None
    latency_seconds: float | None = None
    stack_trace: str | None = None
    node_kind: str | None = None
    prompt_suffix_json: str | None = None
    consume_edit_field: str | None = None
    clear_output: bool = False


class InternalRunnerPersistPriorMetadataRequest(BaseModel):
    run_id: str
    node_uuid: str
    retrieval_id: str | None = None
    raw_context: str = ""
    processed_context: str = ""
    inherited_prior_ids: list[str] = Field(default_factory=list)
    retrieved_priors: list[dict] = Field(default_factory=list)
    applied_priors: list[dict] = Field(default_factory=list)
    rendered_priors_block: str = ""
    injection_anchor: dict | None = None
    model: str | None = None
    latency_tier: str = "MEDIUM"
    timeout_ms: int
    retrieval_latency_ms: int | None = None
    prior_coverage: int | None = None
    retrieval_status: str = "pending"
    coverage_status: str = "not_requested"
    warning_message: str | None = None
    error_message: str | None = None


class InternalRunnerRegisterClaudeProxyClientRequest(BaseModel):
    run_id: str
    client_id: str
    upstream_base_url: str
    stack_trace: str | None = None


class InternalRunnerTrackPriorAppliedRequest(BaseModel):
    prior_id: str
    run_id: str
    node_uuid: str | None = None


class InternalRunnerSchedulePriorCoverageRequest(BaseModel):
    run_id: str
    node_uuid: str


class InternalRunnerVerdictUpdate(BaseModel):
    node_uuid: str
    llm_verdict: Literal["correct", "incorrect", "uncertain"]


class InternalRunnerPersistLlmVerdictsRequest(BaseModel):
    run_id: str
    verdicts: list[InternalRunnerVerdictUpdate] = Field(default_factory=list)


class InternalLlmEmbedRequest(BaseModel):
    input: str | list[str]
    model: str | None = None
    input_type: str | None = None
    dimensions: int | None = None
    encoding_format: str | None = None


class InternalLlmRerankRequest(BaseModel):
    query: str
    documents: list[str | dict[str, Any]] = Field(default_factory=list)
    model: str | None = None
    top_n: int | None = None
    rank_fields: list[str] | None = None
    return_documents: bool = True
    max_chunks_per_doc: int | None = None
    max_tokens_per_doc: int | None = None


async def _get_run_scope_or_raise(run_id: str) -> tuple[str, str]:
    run = await asyncio.to_thread(
        DB.get_run_scope,
        run_id,
    )
    if run is None:
        raise HTTPException(status_code=404, detail=f"Run not found: {run_id}")
    if not run["user_id"] or not run["project_id"]:
        raise HTTPException(
            status_code=400, detail="Run is missing user/project scope for priors access"
        )
    return str(run["user_id"]), str(run["project_id"])


@router.post("/priors/retrieve")
async def internal_priors_retrieve(request: Request, req: InternalPriorsRetrieveRequest):
    base_path_label = req.base_path if req.base_path is not None else "<root>"
    user_id, project_id = await _get_run_scope_or_raise(req.run_id)
    raw_context = normalize_raw_context(
        req.raw_context if req.raw_context is not None else (req.context or "")
    )

    try:
        call_kwargs: dict[str, Any] = {
            "user_id": user_id,
            "project_id": project_id,
            "run_id": req.run_id,
            "raw_context": raw_context,
            "base_path": req.base_path or "",
            "ignore_prior_ids": req.ignore_prior_ids,
            "disconnect_checker": request.is_disconnected,
        }
        while True:
            try:
                response = await retrieve_priors_for_scope(**call_kwargs)
                break
            except TypeError as exc:
                message = str(exc)
                stripped = False
                for optional_key in ("run_id", "disconnect_checker"):
                    if optional_key in call_kwargs and optional_key in message:
                        call_kwargs.pop(optional_key, None)
                        stripped = True
                if not stripped:
                    raise
        return response
    except asyncio.CancelledError:
        main_server_logger.warning(
            "[INTERNAL PRIORS] retrieve cancelled after client disconnect run_id=%s base_path=%s",
            req.run_id,
            base_path_label,
        )
        raise
    except HTTPException as exc:
        main_server_logger.warning(
            "[INTERNAL PRIORS] retrieve failed run_id=%s base_path=%s status_code=%s detail=%s",
            req.run_id,
            base_path_label,
            exc.status_code,
            exc.detail,
        )
        raise
    except StructuredInferenceError as exc:
        main_server_logger.exception(
            "[INTERNAL PRIORS] retrieve structured-inference crashed run_id=%s base_path=%s "
            "structured_mode=%s raw_text_chars=%s raw_text_preview=%s",
            req.run_id,
            base_path_label,
            exc.structured_mode,
            len(exc.raw_text or ""),
            _preview_exception_raw_text(exc.raw_text),
        )
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:
        main_server_logger.exception(
            "[INTERNAL PRIORS] retrieve crashed run_id=%s base_path=%s",
            req.run_id,
            base_path_label,
        )
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/priors/query")
def internal_priors_query(req: InternalPriorsQueryRequest):
    run = DB.get_run_scope(req.run_id)
    if run is None:
        raise HTTPException(status_code=404, detail=f"Run not found: {req.run_id}")
    if not run["user_id"] or not run["project_id"]:
        raise HTTPException(
            status_code=400, detail="Run is missing user/project scope for priors query"
        )

    return query_priors_for_scope(
        user_id=run["user_id"],
        project_id=run["project_id"],
        path=req.path,
    )


@router.post("/priors/prefix-cache/lookup")
async def internal_priors_prefix_cache_lookup(req: InternalPrefixCacheLookupRequest):
    user_id, project_id = await _get_run_scope_or_raise(req.run_id)
    return await asyncio.to_thread(
        lookup_prefix_cache_for_scope,
        user_id=user_id,
        project_id=project_id,
        clean_pairs=req.clean_pairs,
    )


@router.post("/priors/prefix-cache/store")
async def internal_priors_prefix_cache_store(req: InternalPrefixCacheStoreRequest):
    user_id, project_id = await _get_run_scope_or_raise(req.run_id)
    return await asyncio.to_thread(
        store_prefix_cache_for_scope,
        user_id=user_id,
        project_id=project_id,
        clean_pairs=req.clean_pairs,
        injected_pairs=req.injected_pairs,
        prior_ids=req.prior_ids,
    )


@router.post("/llm/embed")
async def internal_llm_embed(req: InternalLlmEmbedRequest):
    response = await asyncio.to_thread(
        llm_backend.embed,
        input=req.input,
        model=req.model,
        input_type=req.input_type,
        dimensions=req.dimensions,
        encoding_format=req.encoding_format,
    )
    return jsonable_encoder(response)


@router.post("/llm/rerank")
async def internal_llm_rerank(req: InternalLlmRerankRequest):
    response = await asyncio.to_thread(
        llm_backend.rerank,
        query=req.query,
        documents=req.documents,
        model=req.model,
        top_n=req.top_n,
        rank_fields=req.rank_fields,
        return_documents=req.return_documents,
        max_chunks_per_doc=req.max_chunks_per_doc,
        max_tokens_per_doc=req.max_tokens_per_doc,
    )
    return jsonable_encoder(response)


@router.post("/runner/run-scope")
def internal_runner_run_scope(req: InternalRunnerRunScopeRequest):
    run = DB.get_run_scope(req.run_id)
    return {"run": dict(run) if run is not None else None}


@router.post("/runner/claude-proxy/register-client")
def internal_runner_register_claude_proxy_client(
    req: InternalRunnerRegisterClaudeProxyClientRequest,
    state: ServerState = Depends(get_state),
):
    state.register_claude_proxy_client(
        req.run_id,
        req.client_id,
        req.upstream_base_url,
        stack_trace=req.stack_trace,
    )
    return {"ok": True}


@router.post("/runner/llm/lookup")
def internal_runner_llm_lookup(req: InternalRunnerLlmLookupRequest):
    occurrence = DB.next_cache_occurrence(req.run_id, req.input_hash)
    row = DB.backend.get_llm_call_by_run_and_hash_query(
        req.run_id, req.input_hash, offset=occurrence
    )
    if row is None and req.input_pickle is not None and req.api_type is not None:
        node_uuid = str(uuid.uuid4())
        DB.begin_llm_call(
            req.run_id,
            req.input_pickle,
            req.input_hash,
            node_uuid,
            req.api_type,
            req.stack_trace,
            req.node_kind,
            req.prompt_suffix_json,
        )
        row = DB.get_llm_call_full(req.run_id, node_uuid)
    elif row is not None:
        if row["input_overwrite"] is not None or row["output"] is None:
            DB.backend.mark_llm_call_in_flight_query(req.run_id, row["node_uuid"])
            row = DB.get_llm_call_full(req.run_id, row["node_uuid"])
    return {"row": dict(row) if row is not None else None}


@router.post("/runner/llm/finalize")
def internal_runner_finalize_llm_call(req: InternalRunnerFinalizeLlmCallRequest):
    DB.finalize_llm_call(
        req.run_id,
        req.node_uuid,
        status=req.status,
        input_pickle=req.input_pickle,
        input_hash=req.input_hash,
        output_json=req.output_json,
        latency_seconds=req.latency_seconds,
        error_json=req.error_json,
        stack_trace=req.stack_trace,
        node_kind=req.node_kind,
        prompt_suffix_json=req.prompt_suffix_json,
        consume_edit_field=req.consume_edit_field,
        clear_output=req.clear_output,
    )
    return {"ok": True}


@router.post("/runner/llm/persist-output")
def internal_runner_persist_output(req: InternalRunnerFinalizeLlmCallRequest):
    if req.output_json is None or req.input_pickle is None or req.input_hash is None:
        raise HTTPException(status_code=400, detail="persist-output requires input/output payloads")
    DB.finalize_llm_call(
        req.run_id,
        req.node_uuid,
        status=req.status,
        input_pickle=req.input_pickle,
        input_hash=req.input_hash,
        output_json=req.output_json,
        latency_seconds=req.latency_seconds,
        error_json=req.error_json,
        stack_trace=req.stack_trace,
        node_kind=req.node_kind,
        prompt_suffix_json=req.prompt_suffix_json,
        consume_edit_field=req.consume_edit_field,
        clear_output=req.clear_output,
    )
    return {"ok": True}


@router.post("/runner/priors/persist-metadata")
def internal_runner_persist_prior_metadata(req: InternalRunnerPersistPriorMetadataRequest):
    raw_context = normalize_raw_context(req.raw_context)
    DB.upsert_prior_retrieval(
        req.run_id,
        req.node_uuid,
        retrieval_id=req.retrieval_id,
        raw_context=raw_context,
        processed_context=req.processed_context,
        inherited_prior_ids=req.inherited_prior_ids,
        retrieved_priors=req.retrieved_priors,
        applied_priors=req.applied_priors,
        rendered_priors_block=req.rendered_priors_block,
        injection_anchor=req.injection_anchor,
        model=req.model,
        latency_tier=req.latency_tier,
        timeout_ms=req.timeout_ms,
        retrieval_latency_ms=req.retrieval_latency_ms,
        prior_coverage=req.prior_coverage,
        retrieval_status=req.retrieval_status,
        coverage_status=req.coverage_status,
        warning_message=req.warning_message,
        error_message=req.error_message,
    )
    for prior in req.applied_priors:
        prior_id = prior.get("id")
        if isinstance(prior_id, str) and prior_id:
            DB.add_prior_applied(prior_id, req.run_id, req.node_uuid)
    return {"ok": True}


@router.post("/runner/priors/track-applied")
def internal_runner_track_prior_applied(req: InternalRunnerTrackPriorAppliedRequest):
    DB.add_prior_applied(req.prior_id, req.run_id, req.node_uuid)
    return {"ok": True}


@router.post("/runner/priors/schedule-coverage")
def internal_runner_schedule_prior_coverage(req: InternalRunnerSchedulePriorCoverageRequest):
    retrieval = DB.get_prior_retrieval(req.run_id, req.node_uuid)
    if retrieval is None:
        return {"scheduled": False, "reason": "no_prior_retrieval"}
    if retrieval.get("retrieval_status") == "failed":
        return {
            "scheduled": False,
            "reason": "retrieval_failed",
            "retrieval_id": retrieval["retrieval_id"],
        }

    llm_call = DB.get_llm_call_full(req.run_id, req.node_uuid)
    if llm_call is None:
        return {
            "scheduled": False,
            "reason": "no_llm_call",
            "retrieval_id": retrieval["retrieval_id"],
        }
    if not llm_call["output"]:
        return {
            "scheduled": False,
            "reason": "output_unavailable",
            "retrieval_id": retrieval["retrieval_id"],
        }
    run = DB.get_run_scope(req.run_id)
    project_id = run["project_id"] if run else None
    project = DB.get_project(project_id) if project_id else None
    track_groundedness = bool(project and project.get("priors_track_groundedness"))
    track_adherence = bool(project and project.get("priors_track_adherence"))
    if not track_groundedness and not track_adherence:
        return {
            "scheduled": False,
            "reason": "tracking_disabled",
            "retrieval_id": retrieval["retrieval_id"],
        }
    coverage_complete = (
        not track_groundedness
        or (
            retrieval.get("coverage_status") == "complete"
            and retrieval.get("prior_coverage") is not None
        )
    )
    adherence_complete = (
        not track_adherence
        or (
            retrieval.get("adherence_status") == "complete"
            and retrieval.get("prior_adherence") is not None
            and retrieval.get("severity_weighted_prior_adherence") is not None
        )
    )
    if coverage_complete and adherence_complete:
        return {
            "scheduled": False,
            "reason": "already_complete",
            "retrieval_id": retrieval["retrieval_id"],
        }
    coverage_cache_hit = (
        coverage_complete
        or (track_groundedness and apply_cached_prior_coverage(retrieval))
    )
    adherence_cache_hit = (
        adherence_complete
        or (track_adherence and apply_cached_prior_adherence(retrieval))
    )
    if coverage_cache_hit and adherence_cache_hit:
        return {
            "scheduled": False,
            "reason": "metrics_cache_hit",
            "retrieval_id": retrieval["retrieval_id"],
        }

    if track_groundedness and not coverage_cache_hit:
        DB.update_prior_coverage(
            retrieval["retrieval_id"],
            prior_coverage=None,
            coverage_status="pending",
        )
    if track_adherence and not adherence_cache_hit:
        DB.update_prior_adherence(
            retrieval["retrieval_id"],
            adherence_status="pending",
        )
    ensure_prior_coverage_worker_started()
    return {"scheduled": True, "retrieval_id": retrieval["retrieval_id"]}


@router.post("/runner/llm/verdicts")
def internal_runner_persist_llm_verdicts(
    req: InternalRunnerPersistLlmVerdictsRequest,
    state: ServerState = Depends(get_state),
):
    updated = handle_update_llm_verdicts(
        state,
        req.run_id,
        [item.model_dump() for item in req.verdicts],
    )
    if updated:
        state.schedule_graph_update(req.run_id)
    return {"ok": True, "updated": updated}
