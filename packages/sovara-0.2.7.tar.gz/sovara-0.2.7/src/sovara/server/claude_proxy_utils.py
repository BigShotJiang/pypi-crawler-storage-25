"""Helpers for Claude Code proxy request forwarding and stream replay."""

from __future__ import annotations

import copy
import json
from typing import Any, Mapping

from sovara.runner.monkey_patching.api_parsers.sse_utils import serialize_sse_events

_HOP_BY_HOP_HEADERS = {
    "connection",
    "content-length",
    "host",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade",
}

# The proxy reads response bodies through httpx's decoded interfaces
# (e.g. ``json()``, ``text``, ``content``, ``aiter_bytes()``), so the payload
# forwarded to Claude clients is already decompressed. Preserve content type,
# but drop upstream content-encoding metadata to avoid downstream zlib errors.
_DECODED_BODY_HEADERS = {
    "content-encoding",
}


def filter_forward_request_headers(headers: Mapping[str, str]) -> dict[str, str]:
    return {
        key: value
        for key, value in headers.items()
        if key.lower() not in _HOP_BY_HOP_HEADERS
    }


def filter_proxy_response_headers(headers: Mapping[str, str]) -> dict[str, str]:
    return {
        key: value
        for key, value in headers.items()
        if key.lower() not in _HOP_BY_HOP_HEADERS
        and key.lower() not in _DECODED_BODY_HEADERS
    }


def extract_public_response(payload: Mapping[str, Any]) -> dict[str, Any]:
    return {
        key: value
        for key, value in payload.items()
        if not str(key).startswith("_")
    }


def build_stream_output_payload(
    response_payload: Mapping[str, Any],
    *,
    status_code: int,
    headers: Mapping[str, str],
    sse_events: list[dict[str, Any]],
) -> dict[str, Any]:
    public_payload = copy.deepcopy(dict(response_payload))
    return {
        **public_payload,
        "_stream": True,
        "_status_code": status_code,
        "_headers": dict(headers),
        "_sse_events": copy.deepcopy(sse_events),
        "_original_response": copy.deepcopy(public_payload),
    }


def build_nonstream_output_payload(
    response_payload: Any,
    *,
    status_code: int,
    headers: Mapping[str, str],
    fallback_key: str,
) -> dict[str, Any]:
    if isinstance(response_payload, dict):
        public_payload = copy.deepcopy(response_payload)
    else:
        public_payload = {fallback_key: response_payload}
    return {
        **public_payload,
        "_stream": False,
        "_status_code": status_code,
        "_headers": dict(headers),
    }


def extract_stream_replay_bytes(payload: Mapping[str, Any]) -> bytes:
    original_response = payload.get("_original_response")
    current_response = extract_public_response(payload)
    if current_response == original_response:
        return serialize_sse_events(list(payload.get("_sse_events") or []))
    synthesized = synthesize_anthropic_sse_events(current_response)
    return serialize_sse_events(synthesized)


def assemble_anthropic_message_from_sse_events(events: list[dict[str, Any]]) -> dict[str, Any]:
    message: dict[str, Any] = {}
    content_blocks: list[dict[str, Any] | None] = []

    def ensure_block(index: int) -> dict[str, Any]:
        while len(content_blocks) <= index:
            content_blocks.append(None)
        block = content_blocks[index]
        if block is None:
            block = {}
            content_blocks[index] = block
        return block

    for event in events:
        data = event.get("data")
        if not isinstance(data, dict):
            continue
        event_type = data.get("type")

        if event_type == "message_start":
            message = copy.deepcopy(data.get("message") or {})
            existing_content = list(message.get("content") or [])
            content_blocks = [copy.deepcopy(block) for block in existing_content]
            continue

        if event_type == "content_block_start":
            index = int(data.get("index", 0))
            block = ensure_block(index)
            block.clear()
            block.update(copy.deepcopy(data.get("content_block") or {}))
            continue

        if event_type == "content_block_delta":
            index = int(data.get("index", 0))
            block = ensure_block(index)
            delta = data.get("delta") or {}
            delta_type = delta.get("type")
            if delta_type == "text_delta":
                block["text"] = f"{block.get('text', '')}{delta.get('text', '')}"
            elif delta_type == "thinking_delta":
                block["thinking"] = f"{block.get('thinking', '')}{delta.get('thinking', '')}"
            elif delta_type == "input_json_delta":
                partial_json = delta.get("partial_json", "")
                block["_input_json_buffer"] = f"{block.get('_input_json_buffer', '')}{partial_json}"
            elif delta_type == "signature_delta":
                block["signature"] = delta.get("signature")
            else:
                for key, value in delta.items():
                    if key != "type":
                        block[key] = copy.deepcopy(value)
            continue

        if event_type == "content_block_stop":
            index = int(data.get("index", 0))
            block = ensure_block(index)
            if "_input_json_buffer" in block:
                buffer = str(block.pop("_input_json_buffer") or "")
                if buffer:
                    try:
                        block["input"] = json.loads(buffer)
                    except json.JSONDecodeError:
                        block["input"] = buffer
            continue

        if event_type == "message_delta":
            message.update(copy.deepcopy(data.get("delta") or {}))
            usage = data.get("usage")
            if usage is not None:
                message["usage"] = copy.deepcopy(usage)
            continue

        if event_type == "message_stop":
            break

    if content_blocks:
        message["content"] = [block or {} for block in content_blocks]
    return message


def synthesize_anthropic_sse_events(response_payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    public_payload = copy.deepcopy(dict(response_payload))
    content = list(public_payload.get("content") or [])
    base_message = copy.deepcopy(public_payload)
    base_message["content"] = []

    events: list[dict[str, Any]] = [{
        "event": "message_start",
        "data": {
            "type": "message_start",
            "message": base_message,
        },
    }]

    for index, block in enumerate(content):
        block_dict = copy.deepcopy(block if isinstance(block, dict) else {"text": str(block)})
        start_block = copy.deepcopy(block_dict)
        if block_dict.get("type") == "text":
            start_block["text"] = ""
        elif block_dict.get("type") == "thinking":
            start_block["thinking"] = ""
        elif block_dict.get("type") == "tool_use" and "input" in start_block:
            start_block.pop("input", None)
        events.append({
            "event": "content_block_start",
            "data": {
                "type": "content_block_start",
                "index": index,
                "content_block": start_block,
            },
        })
        block_type = block_dict.get("type")
        if block_type == "text" and block_dict.get("text"):
            events.append({
                "event": "content_block_delta",
                "data": {
                    "type": "content_block_delta",
                    "index": index,
                    "delta": {
                        "type": "text_delta",
                        "text": block_dict.get("text", ""),
                    },
                },
            })
        elif block_type == "thinking" and block_dict.get("thinking"):
            events.append({
                "event": "content_block_delta",
                "data": {
                    "type": "content_block_delta",
                    "index": index,
                    "delta": {
                        "type": "thinking_delta",
                        "thinking": block_dict.get("thinking", ""),
                    },
                },
            })
        elif block_type == "tool_use" and "input" in block_dict:
            events.append({
                "event": "content_block_delta",
                "data": {
                    "type": "content_block_delta",
                    "index": index,
                    "delta": {
                        "type": "input_json_delta",
                        "partial_json": json.dumps(block_dict.get("input")),
                    },
                },
            })
        events.append({
            "event": "content_block_stop",
            "data": {
                "type": "content_block_stop",
                "index": index,
            },
        })

    delta_payload = {
        key: public_payload.get(key)
        for key in ("stop_reason", "stop_sequence")
        if key in public_payload
    }
    usage_payload = public_payload.get("usage")
    events.append({
        "event": "message_delta",
        "data": {
            "type": "message_delta",
            "delta": delta_payload,
            "usage": usage_payload,
        },
    })
    events.append({
        "event": "message_stop",
        "data": {"type": "message_stop"},
    })
    return events
