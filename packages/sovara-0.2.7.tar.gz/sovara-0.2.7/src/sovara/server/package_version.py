from __future__ import annotations

import re
import threading
import time
from importlib.metadata import PackageNotFoundError, version as installed_version

import httpx


PYPI_PROJECT_JSON_URL = "https://pypi.org/pypi/sovara/json"
PYPI_VERSION_TTL_SECONDS = 60 * 60 * 6
PYPI_VERSION_FAILURE_TTL_SECONDS = 60 * 5


def _read_installed_sovara_version() -> str | None:
    try:
        return installed_version("sovara")
    except PackageNotFoundError:
        return None


def _version_key(raw_version: str) -> tuple[int, ...] | None:
    parts = tuple(int(part) for part in re.findall(r"\d+", raw_version))
    return parts or None


def _is_update_available(current_version: str | None, latest_version: str | None) -> bool:
    if not current_version or not latest_version:
        return False

    current_key = _version_key(current_version)
    latest_key = _version_key(latest_version)
    if current_key is None or latest_key is None:
        return current_version != latest_version

    return current_key < latest_key


class PackageVersionCache:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._next_refresh_at = 0.0
        self._latest_pypi_version: str | None = None

    def _refresh_locked(self) -> None:
        response = httpx.get(PYPI_PROJECT_JSON_URL, timeout=2.0, follow_redirects=True)
        response.raise_for_status()
        payload = response.json()

        latest_version = payload.get("info", {}).get("version")
        if isinstance(latest_version, str) and latest_version.strip():
            self._latest_pypi_version = latest_version.strip()
        self._last_checked_at = time.time()

    def get_status(self) -> dict[str, str | bool | None]:
        current_version = _read_installed_sovara_version()

        with self._lock:
            now = time.time()
            if now >= self._next_refresh_at:
                try:
                    self._refresh_locked()
                    self._next_refresh_at = time.time() + PYPI_VERSION_TTL_SECONDS
                except Exception:
                    self._next_refresh_at = time.time() + PYPI_VERSION_FAILURE_TTL_SECONDS

            latest_pypi_version = self._latest_pypi_version

        return {
            "current_version": current_version,
            "latest_pypi_version": latest_pypi_version,
            "update_available": _is_update_available(current_version, latest_pypi_version),
        }


PACKAGE_VERSION_CACHE = PackageVersionCache()


def get_package_version_status() -> dict[str, str | bool | None]:
    return PACKAGE_VERSION_CACHE.get_status()
