from __future__ import annotations

import time
from typing import Any, Literal, Mapping, Sequence

import litellm

from sovara.common.constants import MAIN_SERVER_LOG
from sovara.common.logger import create_file_logger
from sovara.common.log_redaction import redact_secret_like_text
from sovara.server.database import BadRequestError
from sovara.server.llm_settings import TierName, build_litellm_request_config, flatten_user_llm_settings
from sovara.server.third_party_model_catalog import (
    ThirdPartyModelKind,
    canonicalize_vendor_model_name,
    derive_third_party_vendor,
    get_third_party_model_catalog,
    get_third_party_vendor_auth_type,
    requires_third_party_base_url,
    uses_manual_third_party_model_entry,
)


logger = create_file_logger(MAIN_SERVER_LOG, logger_name="sovara.llm_settings_verification")
VerificationProbeKind = Literal["chat", "embedding", "rerank"]
SETTINGS_TIER_TO_REQUEST_TIER: dict[TierName, str] = {
    "primary": "expensive",
    "helper": "cheap",
    "ultra_helper": "ultra-cheap",
    "embedding": "embedding",
    "reranker": "reranker",
}
SETTINGS_TIER_TO_MODEL_KIND: dict[TierName, ThirdPartyModelKind] = {
    "primary": "chat",
    "helper": "chat",
    "ultra_helper": "chat",
    "embedding": "embedding",
    "reranker": "rerank",
}

LIVE_MODEL_CHECK_PROVIDERS = frozenset(
    {
        "anthropic",
        "fireworks_ai",
        "gemini",
        "litellm_proxy",
        "openai",
        "xai",
    }
)
VERIFICATION_TIMEOUT_SECONDS = 8.0
LOCAL_VERIFICATION_RETRY_TIMEOUT_SECONDS = 30.0
SLOW_LOCAL_VERIFICATION_PROVIDERS = frozenset({"localai"})
VERIFICATION_PROMPT = "This is a test. Are you working? Reply with 'Yes'."
# Keep verification cheap, but not so tight that reasoning-capable models fail
# the probe solely because the output budget is too small.
VERIFICATION_MAX_TOKENS = 16
VERIFICATION_RESPONSE_PREVIEW_CHARS = 80


def _trim_text(value: Any) -> str | None:
    return value.strip() or None if isinstance(value, str) else None


def _coerce_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _summarize_third_party_verification_error(exc: Exception) -> str:
    message = redact_secret_like_text(str(exc))
    lower = message.lower()

    if "no module named 'boto3'" in lower or 'no module named "boto3"' in lower:
        return "Bedrock support requires boto3."
    if (
        "google cloud sdk not found" in lower
        or "no module named 'google'" in lower
        or 'no module named "google"' in lower
        or "google-auth" in lower
        or "google-cloud-aiplatform" in lower
    ):
        return "Vertex AI support requires google-cloud-aiplatform."
    if "aws region is required" in lower:
        return "Missing AWS region."
    if "aws access key id is required" in lower:
        return "Missing AWS access key ID."
    if "aws secret access key is required" in lower:
        return "Missing AWS secret access key."
    if "vertex project is required" in lower:
        return "Missing Vertex project."
    if "vertex location is required" in lower:
        return "Missing Vertex location."
    if "could not resolve credentials" in lower or "application default credentials" in lower:
        return "Missing Vertex credentials or ADC."
    if "failed to load vertex credentials" in lower or "invalid_grant" in lower:
        return "Invalid Vertex credentials."
    if (
        "inference profile" in lower
        or "on-demand throughput isn’t supported" in lower
        or "on-demand throughput isn't supported" in lower
    ):
        return "Bedrock model requires an inference profile."
    if (
        "security token included in the request is invalid" in lower
        or "unrecognizedclientexception" in lower
        or "invalidsignatureexception" in lower
        or "signaturedoesnotmatch" in lower
        or ("access key id" in lower and "does not exist" in lower)
    ):
        return "Invalid AWS credentials."
    if "incorrect api key" in lower or "invalid api key" in lower or "authenticationerror" in lower:
        return "Invalid API key."
    if (
        "could not access model" in lower
        or "model not accessible" in lower
        or "accessdeniedexception" in lower
        or "not authorized to invoke" in lower
        or "not authorized to perform" in lower
        or "don't have access to the model" in lower
    ):
        return "Model not accessible."
    if "resource not found" in lower:
        return "Invalid endpoint or deployment."
    if "selected model does not belong to vendor" in lower:
        return "Invalid model."
    if "vendor" in lower and "not available" in lower:
        return "Vendor unavailable."
    if "timed out" in lower or "connecterror" in lower or "connection error" in lower or "apiconnectionerror" in lower:
        return "Provider not reachable."
    return "Could not verify model."


def _summarize_local_verification_error(exc: Exception) -> str:
    message = redact_secret_like_text(str(exc))
    lower = message.lower()

    if "base url is required" in lower or "endpoint is required" in lower:
        return "Missing endpoint."
    if "model name is required" in lower or "model is required" in lower:
        return "Missing model."
    if "server is required" in lower:
        return "Missing server."
    if (
        "timed out" in lower
        or "connecterror" in lower
        or "connection error" in lower
        or "apiconnectionerror" in lower
        or "connection refused" in lower
    ):
        return "Server not reachable."
    if (
        ("model" in lower and "not found" in lower)
        or ("model" in lower and "does not exist" in lower)
        or ("model" in lower and "missing" in lower)
    ):
        return "Model not accessible."
    return "Could not verify model."


def _is_timeout_error(exc: Exception) -> bool:
    lower = str(exc).lower()
    return (
        "timed out" in lower
        or "connecterror" in lower
        or "connection error" in lower
        or "apiconnectionerror" in lower
        or "connection refused" in lower
    )


def _initial_local_verification_timeout_seconds(local_provider: str) -> float:
    if local_provider in SLOW_LOCAL_VERIFICATION_PROVIDERS:
        return LOCAL_VERIFICATION_RETRY_TIMEOUT_SECONDS
    return VERIFICATION_TIMEOUT_SECONDS


def _get_field(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _content_item_to_text(item: Any) -> str:
    if isinstance(item, str):
        return item
    if isinstance(item, dict):
        for key in ("text", "content", "value"):
            value = item.get(key)
            if isinstance(value, str):
                return value
        return ""
    for attr in ("text", "content", "value"):
        value = getattr(item, attr, None)
        if isinstance(value, str):
            return value
    return ""


def _extract_message_text(message: Any) -> str:
    content = _get_field(message, "content") if message is not None else None

    if isinstance(content, str):
        text = content
    elif isinstance(content, list):
        text = "".join(_content_item_to_text(item) for item in content)
    else:
        text = _content_item_to_text(content)

    normalized = " ".join(text.split()).strip()
    if normalized:
        return normalized

    for key in ("reasoning_content", "reasoning"):
        value = _get_field(message, key) if message is not None else None
        trimmed = _trim_text(value)
        if trimmed:
            return f"[reasoning] {' '.join(trimmed.split()).strip()}"

    provider_specific_fields = _get_field(message, "provider_specific_fields") if message is not None else None
    if isinstance(provider_specific_fields, dict):
        for key in ("reasoning_content", "reasoning"):
            trimmed = _trim_text(provider_specific_fields.get(key))
            if trimmed:
                return f"[reasoning] {' '.join(trimmed.split()).strip()}"

    return ""


def _extract_response_preview(response: Any) -> str:
    try:
        choices = _get_field(response, "choices") or []
        choice = choices[0] if choices else None
        message = _get_field(choice, "message") if choice is not None else None
        text = _extract_message_text(message)
    except Exception:
        return "<unavailable>"

    normalized = " ".join(text.split()).strip()
    if not normalized:
        return "<empty>"

    redacted = redact_secret_like_text(normalized)
    if len(redacted) <= VERIFICATION_RESPONSE_PREVIEW_CHARS:
        return redacted
    return f"{redacted[: VERIFICATION_RESPONSE_PREVIEW_CHARS - 3]}..."


def verify_updated_llm_settings(
    updated_tiers: Sequence[str],
    next_settings: Mapping[str, Mapping[str, Any]],
    current_settings: Mapping[str, Mapping[str, Any]],
) -> None:
    flattened_next_settings = flatten_user_llm_settings(next_settings)
    for tier in updated_tiers:
        tier_settings = dict(next_settings[tier])
        current_tier = dict(current_settings[tier])
        model_kind = SETTINGS_TIER_TO_MODEL_KIND.get(tier, "chat")
        request_config = build_litellm_request_config(
            flattened_next_settings,
            tier=SETTINGS_TIER_TO_REQUEST_TIER.get(tier, "expensive"),
        )
        if tier_settings.get("connection_type") == "third_party_api":
            _verify_third_party_tier(
                tier,
                tier_settings,
                current_tier,
                request_config=request_config,
                model_kind=model_kind,
            )
        else:
            _verify_local_tier(
                tier,
                tier_settings,
                request_config=request_config,
                probe_kind=model_kind,
            )


def _verify_third_party_tier(
    tier: str,
    tier_settings: Mapping[str, Any],
    current_tier: Mapping[str, Any],
    *,
    request_config: Mapping[str, Any],
    model_kind: ThirdPartyModelKind,
) -> None:
    started_at = time.perf_counter()
    vendor = _trim_text(tier_settings.get("third_party_vendor")) or derive_third_party_vendor(tier_settings.get("model_name"))
    model_name = _trim_text(tier_settings.get("model_name"))
    api_key = _trim_text(tier_settings.get("api_key"))
    aws_region = _trim_text(tier_settings.get("aws_region"))
    aws_access_key_id = _trim_text(tier_settings.get("aws_access_key_id"))
    aws_secret_access_key = _trim_text(tier_settings.get("aws_secret_access_key"))
    vertex_project = _trim_text(tier_settings.get("vertex_project"))
    vertex_location = _trim_text(tier_settings.get("vertex_location"))
    vertex_credentials = _trim_text(tier_settings.get("vertex_credentials"))
    base_url = _trim_text(tier_settings.get("base_url"))
    auth_type = get_third_party_vendor_auth_type(vendor)

    if vendor is None:
        raise BadRequestError(f"{tier.title()} vendor is required for Third-party API.")
    if model_name is None:
        raise BadRequestError(f"{tier.title()} model is required for Third-party API.")
    if requires_third_party_base_url(vendor) and base_url is None:
        raise BadRequestError(f"{tier.title()} Endpoint is required for Third-party API.")
    if auth_type == "aws_credentials" and aws_region is None:
        raise BadRequestError(f"{tier.title()} AWS region is required for Third-party API.")
    if auth_type == "aws_credentials" and aws_access_key_id is None:
        raise BadRequestError(f"{tier.title()} AWS access key ID is required for Third-party API.")
    if auth_type == "aws_credentials" and aws_secret_access_key is None:
        raise BadRequestError(f"{tier.title()} AWS secret access key is required for Third-party API.")
    if auth_type == "vertex_credentials" and vertex_project is None:
        raise BadRequestError(f"{tier.title()} Vertex project is required for Third-party API.")
    if auth_type == "vertex_credentials" and vertex_location is None:
        raise BadRequestError(f"{tier.title()} Vertex location is required for Third-party API.")
    if auth_type == "api_key" and api_key is None:
        raise BadRequestError(f"{tier.title()} API key is required for Third-party API.")

    canonical_model = canonicalize_vendor_model_name(vendor, model_name)
    if canonical_model is None:
        raise BadRequestError(f"{tier.title()} model is required for Third-party API.")

    catalog = get_third_party_model_catalog(model_kind)
    catalog_models = {
        option["value"]
        for option in catalog["third_party_models_by_vendor"].get(vendor, [])
    }
    is_current_third_party_model = (
        current_tier.get("connection_type") == "third_party_api"
        and canonicalize_vendor_model_name(
            vendor,
            _trim_text(current_tier.get("model_name")),
        ) == canonical_model
    )

    if not uses_manual_third_party_model_entry(vendor) and not catalog_models and not is_current_third_party_model:
        raise BadRequestError(f"Vendor {vendor} is not available in this Sovara installation.")
    if (
        not uses_manual_third_party_model_entry(vendor)
        and catalog_models
        and canonical_model not in catalog_models
        and not is_current_third_party_model
    ):
        raise BadRequestError(f"Selected model does not belong to vendor {vendor}.")

    try:
        if auth_type == "api_key" and vendor in LIVE_MODEL_CHECK_PROVIDERS and model_kind == "chat":
            live_models = litellm.get_valid_models(
                custom_llm_provider=vendor,
                check_provider_endpoint=True,
                api_key=api_key,
            )
            canonical_live_models = {
                canonicalize_vendor_model_name(vendor, model)
                for model in live_models
                if canonicalize_vendor_model_name(vendor, model) is not None
            }
            if canonical_live_models:
                display_model_name = canonical_model[len(f"{vendor}/") :] if canonical_model.startswith(f"{vendor}/") else canonical_model
                if (
                    canonical_model not in canonical_live_models
                    and not any(
                        live_model == canonical_model
                        or live_model.endswith(f"/{display_model_name}")
                        or live_model.startswith(f"{vendor}/{display_model_name}-")
                        for live_model in canonical_live_models
                    )
                ):
                    raise BadRequestError(f"{tier.title()} API key could not access model {canonical_model}.")
        response_preview = _probe_model(request_config, probe_kind=model_kind)
    except BadRequestError as exc:
        elapsed_ms = int((time.perf_counter() - started_at) * 1000)
        detail = redact_secret_like_text(
            str(exc),
            [api_key, aws_access_key_id, aws_secret_access_key, vertex_credentials],
        )
        logger.warning(
            "llm settings verification failed tier=%s connection_type=third_party_api vendor=%s auth_type=%s model=%s elapsed_ms=%d detail=%s",
            tier,
            vendor,
            auth_type,
            canonical_model,
            elapsed_ms,
            detail,
        )
        raise
    except Exception as exc:
        elapsed_ms = int((time.perf_counter() - started_at) * 1000)
        detail = redact_secret_like_text(
            str(exc),
            [api_key, aws_access_key_id, aws_secret_access_key, vertex_credentials],
        )
        logger.warning(
            "llm settings verification failed tier=%s connection_type=third_party_api vendor=%s auth_type=%s model=%s elapsed_ms=%d detail=%s",
            tier,
            vendor,
            auth_type,
            canonical_model,
            elapsed_ms,
            detail,
        )
        raise BadRequestError(_summarize_third_party_verification_error(exc)) from exc

    elapsed_ms = int((time.perf_counter() - started_at) * 1000)
    logger.info(
        "llm settings verification passed tier=%s connection_type=third_party_api model_kind=%s vendor=%s auth_type=%s model=%s elapsed_ms=%d response_preview=%s",
        tier,
        model_kind,
        vendor,
        auth_type,
        canonical_model,
        elapsed_ms,
        response_preview,
    )


def _request_provider_name(request_config: Mapping[str, Any]) -> str | None:
    custom_provider = _trim_text(request_config.get("custom_llm_provider"))
    if custom_provider:
        return custom_provider
    model_name = _trim_text(request_config.get("model"))
    return derive_third_party_vendor(model_name)


def _probe_model_completion(
    request_config: Mapping[str, Any],
    *,
    timeout_seconds: float = VERIFICATION_TIMEOUT_SECONDS,
    local_provider: str | None = None,
) -> str:
    completion_kwargs = {
        "messages": [{"role": "user", "content": VERIFICATION_PROMPT}],
        "max_tokens": VERIFICATION_MAX_TOKENS,
        "max_retries": 0,
        "temperature": 0,
        "timeout": timeout_seconds,
        **dict(request_config),
    }
    # Disable Ollama thinking during verification so we get an actual content answer
    # within a tiny token budget instead of reasoning-only output.
    if local_provider == "ollama":
        completion_kwargs["think"] = False

    response = litellm.completion(
        **completion_kwargs,
    )
    return _extract_response_preview(response)


def _probe_model_embedding(
    request_config: Mapping[str, Any],
    *,
    timeout_seconds: float = VERIFICATION_TIMEOUT_SECONDS,
) -> str:
    embedding_kwargs: dict[str, Any] = {
        "input": ["Sovara verification document"],
        "max_retries": 0,
        "timeout": timeout_seconds,
        **dict(request_config),
    }
    if _request_provider_name(request_config) == "cohere":
        embedding_kwargs["input_type"] = "search_document"

    response = litellm.embedding(**embedding_kwargs)
    data = _get_field(response, "data") or []
    first_item = data[0] if data else None
    vector = _get_field(first_item, "embedding") or []
    if not isinstance(vector, list) or not vector:
        return "<empty>"
    return f"{len(vector)} dimensions"


def _probe_model_rerank(
    request_config: Mapping[str, Any],
    *,
    timeout_seconds: float = VERIFICATION_TIMEOUT_SECONDS,
) -> str:
    response = litellm.rerank(
        query="Which document is about verification?",
        documents=[
            "This document is about verification and health checks.",
            "This document is about something unrelated.",
        ],
        top_n=1,
        return_documents=False,
        max_retries=0,
        timeout=timeout_seconds,
        **dict(request_config),
    )
    results = _get_field(response, "results") or []
    first_result = results[0] if results else None
    result_index = _coerce_int(_get_field(first_result, "index"))
    relevance_score = _get_field(first_result, "relevance_score")
    if result_index is None:
        return "<empty>"
    if isinstance(relevance_score, (int, float)):
        return f"top_index={result_index} score={relevance_score:.3f}"
    return f"top_index={result_index}"


def _probe_model(
    request_config: Mapping[str, Any],
    *,
    probe_kind: VerificationProbeKind,
    timeout_seconds: float = VERIFICATION_TIMEOUT_SECONDS,
    local_provider: str | None = None,
) -> str:
    if probe_kind == "embedding":
        return _probe_model_embedding(request_config, timeout_seconds=timeout_seconds)
    if probe_kind == "rerank":
        return _probe_model_rerank(request_config, timeout_seconds=timeout_seconds)
    return _probe_model_completion(
        request_config,
        timeout_seconds=timeout_seconds,
        local_provider=local_provider,
    )


def _verify_local_tier(
    tier: str,
    tier_settings: Mapping[str, Any],
    *,
    request_config: Mapping[str, Any],
    probe_kind: VerificationProbeKind,
) -> None:
    started_at = time.perf_counter()
    local_provider = tier_settings.get("local_provider")
    base_url = _trim_text(tier_settings.get("base_url"))
    model_name = _trim_text(tier_settings.get("model_name"))

    if not isinstance(local_provider, str):
        raise BadRequestError(f"{tier.title()} server is required for Locally hosted.")
    if base_url is None:
        raise BadRequestError(f"{tier.title()} Endpoint is required for Locally hosted.")
    if model_name is None:
        raise BadRequestError(f"{tier.title()} model name is required.")

    try:
        initial_timeout_seconds = _initial_local_verification_timeout_seconds(local_provider)
        try:
            response_preview = _probe_model(
                request_config,
                probe_kind=probe_kind,
                timeout_seconds=initial_timeout_seconds,
                local_provider=local_provider,
            )
        except Exception as exc:
            if not _is_timeout_error(exc) or initial_timeout_seconds >= LOCAL_VERIFICATION_RETRY_TIMEOUT_SECONDS:
                raise
            logger.info(
                "llm settings verification retrying tier=%s connection_type=locally_hosted local_provider=%s model=%s base_url=%s initial_timeout_s=%.1f retry_timeout_s=%.1f",
                tier,
                local_provider,
                model_name,
                base_url,
                initial_timeout_seconds,
                LOCAL_VERIFICATION_RETRY_TIMEOUT_SECONDS,
            )
            response_preview = _probe_model(
                request_config,
                probe_kind=probe_kind,
                timeout_seconds=LOCAL_VERIFICATION_RETRY_TIMEOUT_SECONDS,
                local_provider=local_provider,
            )
    except BadRequestError as exc:
        elapsed_ms = int((time.perf_counter() - started_at) * 1000)
        detail = redact_secret_like_text(str(exc))
        logger.warning(
            "llm settings verification failed tier=%s connection_type=locally_hosted local_provider=%s model=%s base_url=%s elapsed_ms=%d detail=%s",
            tier,
            local_provider,
            model_name,
            base_url,
            elapsed_ms,
            detail,
        )
        raise
    except Exception as exc:
        elapsed_ms = int((time.perf_counter() - started_at) * 1000)
        detail = redact_secret_like_text(str(exc))
        logger.warning(
            "llm settings verification failed tier=%s connection_type=locally_hosted local_provider=%s model=%s base_url=%s elapsed_ms=%d detail=%s",
            tier,
            local_provider,
            model_name,
            base_url,
            elapsed_ms,
            detail,
        )
        raise BadRequestError(_summarize_local_verification_error(exc)) from exc

    elapsed_ms = int((time.perf_counter() - started_at) * 1000)
    logger.info(
        "llm settings verification passed tier=%s connection_type=locally_hosted probe_kind=%s local_provider=%s model=%s base_url=%s elapsed_ms=%d response_preview=%s",
        tier,
        probe_kind,
        local_provider,
        model_name,
        base_url,
        elapsed_ms,
        response_preview,
    )
