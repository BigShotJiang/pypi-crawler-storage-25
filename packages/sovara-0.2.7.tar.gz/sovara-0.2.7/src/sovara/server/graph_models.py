"""Typed graph models for persisted and UI-facing execution graphs."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class IncomingNode:
    """Validated node payload received from the runner before graph insertion."""

    uuid: str
    input: str
    output: str
    label: str
    latency_seconds: float | None = None
    status: str | None = None
    error_message: str | None = None
    llm_verdict: str | None = None
    stack_trace: str | None = None
    node_kind: str | None = None
    raw_node_name: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "IncomingNode":
        return cls(
            uuid=str(data["uuid"]),
            input=str(data["input"]),
            output=str(data["output"]),
            label=str(data["label"]),
            latency_seconds=(
                None if data.get("latency_seconds") is None else float(data["latency_seconds"])
            ),
            status=None if data.get("status") is None else str(data["status"]),
            error_message=None if data.get("error_message") is None else str(data["error_message"]),
            llm_verdict=None if data.get("llm_verdict") is None else str(data["llm_verdict"]),
            stack_trace=None if data.get("stack_trace") is None else str(data["stack_trace"]),
            node_kind=None if data.get("node_kind") is None else str(data["node_kind"]),
            raw_node_name=None if data.get("raw_node_name") is None else str(data["raw_node_name"]),
        )


@dataclass(slots=True)
class GraphNode:
    """Canonical graph node stored in memory and in graph_topology."""

    uuid: str
    step_id: int
    input: str
    output: str
    label: str
    latency_seconds: float | None = None
    status: str | None = None
    error_message: str | None = None
    llm_verdict: str | None = None
    stack_trace: str | None = None
    node_kind: str | None = None
    raw_node_name: str | None = None

    @classmethod
    def from_incoming(cls, node: IncomingNode, step_id: int) -> "GraphNode":
        return cls(
            uuid=node.uuid,
            step_id=step_id,
            input=node.input,
            output=node.output,
            label=node.label,
            latency_seconds=node.latency_seconds,
            status=node.status,
            error_message=node.error_message,
            llm_verdict=node.llm_verdict,
            stack_trace=node.stack_trace,
            node_kind=node.node_kind,
            raw_node_name=node.raw_node_name,
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GraphNode":
        return cls(
            uuid=str(data["uuid"]),
            step_id=int(data["step_id"]),
            input=str(data["input"]),
            output=str(data["output"]),
            label=str(data["label"]),
            latency_seconds=(
                None if data.get("latency_seconds") is None else float(data["latency_seconds"])
            ),
            status=None if data.get("status") is None else str(data["status"]),
            error_message=None if data.get("error_message") is None else str(data["error_message"]),
            llm_verdict=None if data.get("llm_verdict") is None else str(data["llm_verdict"]),
            stack_trace=None if data.get("stack_trace") is None else str(data["stack_trace"]),
            node_kind=None if data.get("node_kind") is None else str(data["node_kind"]),
            raw_node_name=None if data.get("raw_node_name") is None else str(data["raw_node_name"]),
        )

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "uuid": self.uuid,
            "step_id": self.step_id,
            "input": self.input,
            "output": self.output,
            "label": self.label,
            "stack_trace": self.stack_trace,
            "node_kind": self.node_kind,
            "raw_node_name": self.raw_node_name,
        }
        if self.latency_seconds is not None:
            payload["latency_seconds"] = self.latency_seconds
        if self.status is not None:
            payload["status"] = self.status
        if self.error_message is not None:
            payload["error_message"] = self.error_message
        if self.llm_verdict is not None:
            payload["llm_verdict"] = self.llm_verdict
        return payload

    def to_metadata_dict(self) -> dict[str, Any]:
        payload = {
            "uuid": self.uuid,
            "step_id": self.step_id,
            "label": self.label,
            "node_kind": self.node_kind,
            "raw_node_name": self.raw_node_name,
            "has_input": bool(self.input),
            "has_output": bool(self.output),
            "input_size": len(self.input or ""),
            "output_size": len(self.output or ""),
        }
        if self.latency_seconds is not None:
            payload["latency_seconds"] = self.latency_seconds
        if self.status is not None:
            payload["status"] = self.status
        if self.error_message is not None:
            payload["error_message"] = self.error_message
        if self.llm_verdict is not None:
            payload["llm_verdict"] = self.llm_verdict
        return payload


@dataclass(slots=True)
class GraphEdge:
    """Directed dataflow edge between two graph nodes."""

    id: str
    source_uuid: str
    target_uuid: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GraphEdge":
        return cls(
            id=str(data["id"]),
            source_uuid=str(data["source_uuid"]),
            target_uuid=str(data["target_uuid"]),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "source_uuid": self.source_uuid,
            "target_uuid": self.target_uuid,
        }


@dataclass(slots=True)
class RunGraph:
    """Typed run graph persisted to graph_topology and served to UIs."""

    nodes: list[GraphNode] = field(default_factory=list)
    edges: list[GraphEdge] = field(default_factory=list)

    @classmethod
    def empty(cls) -> "RunGraph":
        return cls(nodes=[], edges=[])

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "RunGraph":
        if not data:
            return cls.empty()
        return cls(
            nodes=[GraphNode.from_dict(node) for node in data.get("nodes", [])],
            edges=[GraphEdge.from_dict(edge) for edge in data.get("edges", [])],
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "nodes": [node.to_dict() for node in self.nodes],
            "edges": [edge.to_dict() for edge in self.edges],
        }

    def to_metadata_dict(self) -> dict[str, Any]:
        return {
            "nodes": [node.to_metadata_dict() for node in self.nodes],
            "edges": [edge.to_dict() for edge in self.edges],
        }

    @classmethod
    def from_json_string(cls, data: str | None) -> "RunGraph":
        if not data:
            return cls.empty()
        from sovara.server.database.blob_storage import restore  # lazy to avoid circular import

        return cls.from_dict(json.loads(restore(data)))

    def to_json_string(self) -> str:
        return json.dumps(self.to_dict())

    def get_node_by_uuid(self, node_uuid: str) -> GraphNode | None:
        for node in self.nodes:
            if node.uuid == node_uuid:
                return node
        return None

    def add_node(self, incoming: IncomingNode, incoming_source_uuids: list[str]) -> GraphNode:
        existing = self.get_node_by_uuid(incoming.uuid)
        if existing is None:
            existing = GraphNode.from_incoming(incoming, step_id=len(self.nodes) + 1)
            self.nodes.append(existing)

        existing_edge_ids = {edge.id for edge in self.edges}
        existing_node_uuids = {node.uuid for node in self.nodes}
        for source_uuid in incoming_source_uuids:
            if source_uuid not in existing_node_uuids:
                continue
            edge_id = f"e{source_uuid}-{existing.uuid}"
            if edge_id in existing_edge_ids:
                continue
            self.edges.append(
                GraphEdge(id=edge_id, source_uuid=source_uuid, target_uuid=existing.uuid)
            )
            existing_edge_ids.add(edge_id)

        return existing

    def assert_valid_step_ids(self) -> None:
        expected = list(range(1, len(self.nodes) + 1))
        actual = [node.step_id for node in self.nodes]
        if actual != expected:
            raise ValueError(f"Invalid step ids: expected {expected}, got {actual}")
