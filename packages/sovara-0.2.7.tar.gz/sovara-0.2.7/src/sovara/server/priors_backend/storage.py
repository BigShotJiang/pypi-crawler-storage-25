"""Scoped file-backed storage for priors."""

from __future__ import annotations

from collections import defaultdict
from contextlib import contextmanager
import hashlib
import json
import os
import shutil
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

import bm25s
import numpy as np
import psutil

from sovara.server import llm_backend
from sovara.server.priors_backend.constants import PRIORS_BACKEND_HOME, SCOPE_METADATA_FILENAME
from sovara.server.database import DB
from sovara.server.priors_backend.path_utils import normalize_path as _normalize_path
from sovara.server.priors_backend.constants import (
    DEFAULT_PRIORS_CACHE_MAX_BYTES_ENV,
    PRIORS_BACKEND_INDEX_HOME,
)

_UNSET = object()
_EMBED_BATCH_SIZE = 96
_SNAPSHOT_GENERATION_FILENAME = ".snapshot_generation"
_RESTRUCTURE_TASKS_FILENAME = ".restructure_tasks.json"


def _default_cache_max_bytes() -> int:
    configured = os.environ.get(DEFAULT_PRIORS_CACHE_MAX_BYTES_ENV)
    if configured:
        try:
            parsed = int(configured)
        except ValueError:
            parsed = 0
        if parsed > 0:
            return parsed

    available = int(getattr(psutil.virtual_memory(), "available", 0) or 0)
    if available <= 0:
        return 16 * 1024 * 1024 * 1024
    return min(16 * 1024 * 1024 * 1024, available // 4)

def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class PriorStoreWriteLockedError(FileExistsError):
    """Raised when a pending restructure task owns a tree for writes."""

    def __init__(self, *, base_path: str, task_id: str):
        label = base_path or "(root)"
        super().__init__(f"Tree '{label}' is locked by pending restructure task '{task_id}'")
        self.base_path = base_path
        self.task_id = task_id


def _tokenize(text: str, *, drop_stopwords: bool = False) -> list[str]:
    tokenized = bm25s.tokenize(
        text or "",
        stopwords="english" if drop_stopwords else [],
        return_ids=False,
        show_progress=False,
    )
    if not tokenized:
        return []
    return [str(token) for token in tokenized[0]]


def _unique_tokens(text: str, *, drop_stopwords: bool = False) -> tuple[str, ...]:
    ordered: list[str] = []
    seen: set[str] = set()
    for token in _tokenize(text, drop_stopwords=drop_stopwords):
        if token in seen:
            continue
        seen.add(token)
        ordered.append(token)
    return tuple(ordered)


def _taxonomy_path(path: str) -> list[str]:
    return [segment for segment in str(path or "").strip("/").split("/") if segment]


def _build_retrieval_text(row: dict) -> str:
    aliases = ", ".join(row.get("aliases") or [])
    keywords = ", ".join(row.get("keywords") or [])
    taxonomy = " > ".join(_taxonomy_path(str(row.get("path") or "")))
    fields = [
        str(row.get("title") or ""),
        str(row.get("summary") or ""),
        str(row.get("when_to_use") or ""),
        aliases,
        keywords,
        taxonomy,
        str(row.get("content") or ""),
    ]
    return "\n".join(value for value in fields if value.strip())


def _normalize_rows(matrix: np.ndarray) -> np.ndarray:
    if matrix.size == 0:
        return matrix
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms = np.where(norms <= 1e-12, 1.0, norms)
    return matrix / norms


def _batched(items: list[str], batch_size: int) -> list[list[str]]:
    return [items[index : index + batch_size] for index in range(0, len(items), batch_size)]


def _embedding_vectors(response: object) -> np.ndarray:
    data = getattr(response, "data", None)
    if data is None and isinstance(response, dict):
        data = response.get("data")
    if isinstance(data, list):
        vectors: list[list[float]] = []
        for item in data:
            if isinstance(item, dict):
                vector = item.get("embedding")
            else:
                vector = getattr(item, "embedding", None)
            if isinstance(vector, list):
                vectors.append(vector)
        if vectors:
            return np.asarray(vectors, dtype=np.float32)

    embeddings = getattr(response, "embeddings", None)
    if embeddings is None and isinstance(response, dict):
        embeddings = response.get("embeddings")
    vectors = None
    if isinstance(embeddings, dict):
        vectors = embeddings.get("float")
    elif embeddings is not None:
        vectors = getattr(embeddings, "float_", None)
        if vectors is None:
            vectors = getattr(embeddings, "float", None)
    if isinstance(vectors, list):
        return np.asarray(vectors, dtype=np.float32)
    raise ValueError("embedding response did not contain usable vectors")


def _embed_texts(texts: list[str], *, input_type: str) -> np.ndarray:
    if not texts:
        return np.empty((0, 0), dtype=np.float32)

    batches: list[np.ndarray] = []
    for batch in _batched(texts, _EMBED_BATCH_SIZE):
        response = llm_backend.embed(
            input=batch,
            tier="embedding",
            input_type=input_type,
            encoding_format="float",
        )
        batches.append(_embedding_vectors(response))
    return _normalize_rows(np.vstack(batches))


@dataclass(slots=True, frozen=True)
class KeywordSearchDocument:
    prior_id: str
    title: str
    path: str
    title_tokens: tuple[str, ...]
    keyword_tokens: tuple[str, ...]
    alias_tokens: tuple[str, ...]
    taxonomy_tokens: tuple[str, ...]
    when_to_use_tokens: tuple[str, ...]


@dataclass(slots=True, frozen=True)
class PriorLightRow:
    id: str
    title: str
    summary: str
    path: str
    when_to_use: str
    consequence_if_not_followed: str
    non_adherence_severity: int | None
    aliases: tuple[str, ...]
    keywords: tuple[str, ...]
    related_priors: tuple[str, ...]
    prior_status: str
    updated_at: str | None
    filepath: str

    @property
    def prior_id(self) -> str:
        return self.id

    @property
    def taxonomy_path(self) -> tuple[str, ...]:
        return tuple(_taxonomy_path(self.path))

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "summary": self.summary,
            "path": self.path,
            "when_to_use": self.when_to_use,
            "consequence_if_not_followed": self.consequence_if_not_followed,
            "non_adherence_severity": self.non_adherence_severity,
            "aliases": list(self.aliases),
            "keywords": list(self.keywords),
            "related_priors": list(self.related_priors),
            "prior_status": self.prior_status,
            "updated_at": self.updated_at,
        }


@dataclass(slots=True)
class PriorSnapshot:
    user_id: str
    project_id: str
    base_path: str
    generation: str
    scope_hash: str
    prior_rows: list[PriorLightRow]
    prior_by_id: dict[str, PriorLightRow]
    folder_priors: dict[str, list[PriorLightRow]]
    filepath_by_id: dict[str, str]
    approx_bytes: int
    access_count: int = 0
    last_accessed_at: float = 0.0

    def mark_accessed(self) -> None:
        self.access_count += 1
        self.last_accessed_at = time.monotonic()


@dataclass(slots=True)
class PriorCorpus:
    user_id: str
    project_id: str
    base_path: str
    scope_hash: str
    prior_rows: list[dict]
    prior_by_id: dict[str, dict]
    retrieval_texts: dict[str, str]
    keyword_docs: list[KeywordSearchDocument]
    bm25_retriever: object | None
    bm25_prior_ids: list[str]
    dense_prior_ids: list[str]
    dense_matrix: np.ndarray
    approx_bytes: int
    access_count: int = 0
    last_accessed_at: float = 0.0

    def mark_accessed(self) -> None:
        self.access_count += 1
        self.last_accessed_at = time.monotonic()


@dataclass(slots=True)
class SnapshotGenerationState:
    token: str
    signature: tuple[int, int, int] | None


class PriorStore:
    """Filesystem-backed priors store scoped by user and project."""
    _cache_lock = threading.RLock()
    _scope_locks: dict[tuple[str, str], threading.RLock] = {}
    _tree_lock_conditions: dict[tuple[str, str], threading.Condition] = {}
    _active_tree_locks: dict[tuple[str, str], dict[str, tuple[int, int]]] = {}
    _restructure_task_context = threading.local()
    _snapshot_cache: dict[tuple[str, str, str], PriorSnapshot] = {}
    _corpus_cache: dict[tuple[str, str, str], PriorCorpus] = {}
    _snapshot_generation_states: dict[tuple[str, str], SnapshotGenerationState] = {}
    _snapshot_cache_total_bytes = 0
    _corpus_cache_total_bytes = 0
    _cache_max_bytes = _default_cache_max_bytes()

    def __init__(self, user_id: str, project_id: str):
        if not user_id:
            raise ValueError("user_id is required")
        if not project_id:
            raise ValueError("project_id is required")

        self.user_id = user_id
        self.project_id = project_id
        self.base = os.path.join(PRIORS_BACKEND_HOME, user_id, project_id)
        os.makedirs(self.base, exist_ok=True)
        os.makedirs(self.artifact_root, exist_ok=True)
        self._ensure_scope_metadata()

    @property
    def _scope_key(self) -> tuple[str, str]:
        return self.user_id, self.project_id

    @property
    def artifact_root(self) -> str:
        return os.path.join(PRIORS_BACKEND_INDEX_HOME, self.user_id, self.project_id)

    @property
    def _lock(self) -> threading.RLock:
        with self._cache_lock:
            lock = self._scope_locks.get(self._scope_key)
            if lock is None:
                lock = threading.RLock()
                self._scope_locks[self._scope_key] = lock
            return lock

    @contextmanager
    def locked_scope(self):
        """Hold the shared scope lock across a multi-step commit."""
        with self._lock:
            yield

    def _corpus_key(self, base_path: str) -> tuple[str, str, str]:
        return self.user_id, self.project_id, _normalize_path(base_path)

    @staticmethod
    def _tree_paths_overlap(left: str, right: str) -> bool:
        normalized_left = _normalize_path(left)
        normalized_right = _normalize_path(right)
        if not normalized_left or not normalized_right:
            return True
        return normalized_left.startswith(normalized_right) or normalized_right.startswith(normalized_left)

    @property
    def _tree_lock_condition(self) -> threading.Condition:
        with self._cache_lock:
            condition = self._tree_lock_conditions.get(self._scope_key)
            if condition is None:
                condition = threading.Condition(threading.RLock())
                self._tree_lock_conditions[self._scope_key] = condition
            return condition

    def _tree_lock_conflicts(self, paths: list[str], *, owner_thread_id: int) -> bool:
        active = type(self)._active_tree_locks.get(self._scope_key, {})
        for active_path, (active_owner_thread_id, _count) in active.items():
            if active_owner_thread_id == owner_thread_id:
                continue
            if any(self._tree_paths_overlap(path, active_path) for path in paths):
                return True
        return False

    @staticmethod
    def _task_matches_paths(task: dict[str, Any], paths: list[str]) -> bool:
        task_path = _normalize_path(str(task.get("base_path") or ""))
        return any(PriorStore._tree_paths_overlap(path, task_path) for path in paths)

    def _current_restructure_task_id(self) -> str | None:
        return getattr(type(self)._restructure_task_context, "task_id", None)

    @property
    def _restructure_tasks_path(self) -> str:
        return os.path.join(self.base, _RESTRUCTURE_TASKS_FILENAME)

    def _read_restructure_tasks(self) -> dict[str, dict[str, Any]]:
        try:
            with open(self._restructure_tasks_path, encoding="utf-8") as handle:
                data = json.load(handle)
        except FileNotFoundError:
            return {}
        except Exception:
            return {}
        if not isinstance(data, dict):
            return {}
        return {str(task_id): task for task_id, task in data.items() if isinstance(task, dict)}

    def _write_restructure_tasks(self, tasks: dict[str, dict[str, Any]]) -> None:
        fd, tmp = tempfile.mkstemp(dir=self.base, prefix=f"{_RESTRUCTURE_TASKS_FILENAME}.", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(tasks, handle, ensure_ascii=False, indent=2, sort_keys=True)
            os.replace(tmp, self._restructure_tasks_path)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    def _pending_restructure_conflict(
        self,
        paths: list[str],
        *,
        task_id: str | None = None,
    ) -> dict[str, Any] | None:
        current_task_id = task_id if task_id is not None else self._current_restructure_task_id()
        for candidate_task_id, task in self._read_restructure_tasks().items():
            if str(task.get("status") or "") != "pending":
                continue
            if current_task_id and candidate_task_id == current_task_id:
                continue
            if self._task_matches_paths(task, paths):
                return {"task_id": candidate_task_id, **task}
        return None

    def _raise_if_pending_restructure_conflict(
        self,
        *paths: str,
        task_id: str | None = None,
    ) -> None:
        normalized_paths = [_normalize_path(path) for path in paths]
        if not normalized_paths:
            return
        conflict = self._pending_restructure_conflict(normalized_paths, task_id=task_id)
        if conflict is None:
            return
        raise PriorStoreWriteLockedError(
            base_path=_normalize_path(str(conflict.get("base_path") or "")),
            task_id=str(conflict.get("task_id") or ""),
        )

    @contextmanager
    def _locked_tree_mutation(self, *paths: str):
        self._wait_for_tree_lock(*paths)
        with self._lock:
            self._raise_if_pending_restructure_conflict(*paths)
            yield

    def _wait_for_tree_lock(self, *paths: str) -> None:
        normalized_paths = [_normalize_path(path) for path in paths]
        if not normalized_paths:
            return
        owner_thread_id = threading.get_ident()
        condition = self._tree_lock_condition
        with condition:
            self._raise_if_pending_restructure_conflict(*normalized_paths)
            while self._tree_lock_conflicts(normalized_paths, owner_thread_id=owner_thread_id):
                condition.wait()

    @contextmanager
    def locked_tree(self, path: str = "", *, restructure_task_id: str | None = None):
        normalized_path = _normalize_path(path)
        owner_thread_id = threading.get_ident()
        condition = self._tree_lock_condition
        previous_task_id = self._current_restructure_task_id()
        try:
            if restructure_task_id is not None:
                type(self)._restructure_task_context.task_id = restructure_task_id
            with condition:
                self._raise_if_pending_restructure_conflict(normalized_path, task_id=restructure_task_id)
                while self._tree_lock_conflicts([normalized_path], owner_thread_id=owner_thread_id):
                    condition.wait()
                active = type(self)._active_tree_locks.setdefault(self._scope_key, {})
                current_owner_thread_id, current_count = active.get(normalized_path, (owner_thread_id, 0))
                if current_count and current_owner_thread_id != owner_thread_id:
                    raise RuntimeError("locked_tree owner tracking became inconsistent")
                active[normalized_path] = (owner_thread_id, current_count + 1)
            yield
        finally:
            with condition:
                active = type(self)._active_tree_locks.get(self._scope_key, {})
                current_owner_thread_id, current_count = active.get(normalized_path, (owner_thread_id, 0))
                if current_count <= 1:
                    active.pop(normalized_path, None)
                else:
                    active[normalized_path] = (current_owner_thread_id, current_count - 1)
                if not active:
                    type(self)._active_tree_locks.pop(self._scope_key, None)
                condition.notify_all()
            if previous_task_id is None:
                try:
                    delattr(type(self)._restructure_task_context, "task_id")
                except AttributeError:
                    pass
            else:
                type(self)._restructure_task_context.task_id = previous_task_id

    def create_restructure_task(
        self,
        *,
        task_id: str,
        base_path: str = "",
        comments: str | None = None,
    ) -> dict[str, Any]:
        normalized_base_path = _normalize_path(base_path)
        with self._lock:
            self._raise_if_pending_restructure_conflict(normalized_base_path, task_id=task_id)
            tasks = self._read_restructure_tasks()
            if task_id in tasks:
                raise FileExistsError(f"Restructure task '{task_id}' already exists")
            now = _utc_now_iso()
            entry = {
                "task_id": task_id,
                "base_path": normalized_base_path,
                "comments": str(comments or ""),
                "status": "pending",
                "created_at": now,
                "updated_at": now,
                "snapshot": "",
                "proposal": None,
                "total_priors": 0,
            }
            tasks[task_id] = entry
            self._write_restructure_tasks(tasks)
            return dict(entry)

    def get_restructure_task(self, task_id: str) -> dict[str, Any] | None:
        with self._lock:
            task = self._read_restructure_tasks().get(task_id)
            return dict(task) if task is not None else None

    def update_restructure_task(self, task_id: str, **updates: Any) -> dict[str, Any]:
        with self._lock:
            tasks = self._read_restructure_tasks()
            task = tasks.get(task_id)
            if task is None:
                raise KeyError(task_id)
            task = dict(task)
            task.update(updates)
            task["task_id"] = task_id
            task["base_path"] = _normalize_path(str(task.get("base_path") or ""))
            task["updated_at"] = _utc_now_iso()
            tasks[task_id] = task
            self._write_restructure_tasks(tasks)
            return dict(task)

    def delete_restructure_task(self, task_id: str) -> dict[str, Any] | None:
        with self._lock:
            tasks = self._read_restructure_tasks()
            task = tasks.pop(task_id, None)
            if task is None:
                return None
            self._write_restructure_tasks(tasks)
        condition = self._tree_lock_condition
        with condition:
            condition.notify_all()
        return dict(task)

    @property
    def _snapshot_generation_path(self) -> str:
        return os.path.join(self.base, _SNAPSHOT_GENERATION_FILENAME)

    def _snapshot_generation_signature(self) -> tuple[int, int, int] | None:
        try:
            stat = os.stat(self._snapshot_generation_path)
        except FileNotFoundError:
            return None
        return (
            int(getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1_000_000_000))),
            int(stat.st_size),
            int(getattr(stat, "st_ino", 0)),
        )

    def _read_snapshot_generation(self) -> str:
        cached_state: SnapshotGenerationState | None = None
        signature = self._snapshot_generation_signature()
        with self._cache_lock:
            cached_state = type(self)._snapshot_generation_states.get(self._scope_key)
            if cached_state is not None and cached_state.signature == signature:
                return cached_state.token

        for _attempt in range(3):
            signature = self._snapshot_generation_signature()
            if signature is None:
                token = ""
            else:
                with open(self._snapshot_generation_path, encoding="utf-8") as handle:
                    token = handle.read().strip()
            current_signature = self._snapshot_generation_signature()
            if current_signature == signature:
                with self._cache_lock:
                    type(self)._snapshot_generation_states[self._scope_key] = SnapshotGenerationState(
                        token=token,
                        signature=current_signature,
                    )
                return token

        token = ""
        if signature is not None:
            with open(self._snapshot_generation_path, encoding="utf-8") as handle:
                token = handle.read().strip()
        final_signature = self._snapshot_generation_signature()
        with self._cache_lock:
            type(self)._snapshot_generation_states[self._scope_key] = SnapshotGenerationState(
                token=token,
                signature=final_signature,
            )
        return token

    def _bump_snapshot_generation(self) -> str:
        token = f"{time.time_ns()}-{uuid.uuid4().hex}"
        fd, tmp = tempfile.mkstemp(dir=self.base, prefix=f"{_SNAPSHOT_GENERATION_FILENAME}.", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(token)
            os.replace(tmp, self._snapshot_generation_path)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
        with self._cache_lock:
            type(self)._snapshot_generation_states[self._scope_key] = SnapshotGenerationState(
                token=token,
                signature=self._snapshot_generation_signature(),
            )
        return token

    def _invalidate_retrieval_state(self) -> None:
        self._bump_snapshot_generation()
        cls = type(self)
        with self._cache_lock:
            doomed = [
                key
                for key in cls._snapshot_cache
                if key[0] == self.user_id and key[1] == self.project_id
            ]
            for key in doomed:
                cls._snapshot_cache_total_bytes -= cls._snapshot_cache[key].approx_bytes
                cls._snapshot_cache.pop(key, None)
            doomed = [
                key
                for key in cls._corpus_cache
                if key[0] == self.user_id and key[1] == self.project_id
            ]
            for key in doomed:
                cls._corpus_cache_total_bytes -= cls._corpus_cache[key].approx_bytes
                cls._corpus_cache.pop(key, None)
        shutil.rmtree(self.artifact_root, ignore_errors=True)
        os.makedirs(self.artifact_root, exist_ok=True)

    @classmethod
    def _total_cache_bytes(cls) -> int:
        return cls._snapshot_cache_total_bytes + cls._corpus_cache_total_bytes

    @classmethod
    def _evict_if_needed(cls) -> None:
        if cls._total_cache_bytes() <= cls._cache_max_bytes:
            return
        ranked = sorted(
            [("snapshot", key, snapshot) for key, snapshot in cls._snapshot_cache.items()]
            + [("corpus", key, corpus) for key, corpus in cls._corpus_cache.items()],
            key=lambda item: (item[2].access_count, item[2].last_accessed_at, item[0], item[1]),
        )
        for cache_kind, key, entry in ranked:
            if cls._total_cache_bytes() <= cls._cache_max_bytes:
                break
            if cache_kind == "snapshot":
                removed = cls._snapshot_cache.pop(key, None)
                if removed is not None:
                    cls._snapshot_cache_total_bytes -= removed.approx_bytes
                continue
            removed = cls._corpus_cache.pop(key, None)
            if removed is not None:
                cls._corpus_cache_total_bytes -= removed.approx_bytes

    def _artifact_dir(self, base_path: str, scope_hash: str) -> str:
        base_key = hashlib.sha256((_normalize_path(base_path) or "/").encode("utf-8")).hexdigest()[:16]
        return os.path.join(self.artifact_root, base_key, scope_hash)

    def _dense_artifact_paths(self, base_path: str, scope_hash: str) -> tuple[str, str]:
        artifact_dir = self._artifact_dir(base_path, scope_hash)
        return os.path.join(artifact_dir, "metadata.json"), os.path.join(artifact_dir, "matrix.npy")

    def _scope_hash(self, prior_rows: list[dict]) -> str:
        normalized = [
            {
                "id": row.get("id"),
                "title": row.get("title"),
                "summary": row.get("summary"),
                "content": row.get("content"),
                "path": row.get("path"),
                "when_to_use": row.get("when_to_use"),
                "consequence_if_not_followed": row.get("consequence_if_not_followed"),
                "non_adherence_severity": row.get("non_adherence_severity"),
                "aliases": row.get("aliases") or [],
                "keywords": row.get("keywords") or [],
                "related_priors": row.get("related_priors") or [],
                "prior_status": row.get("prior_status", "active"),
                "updated_at": row.get("updated_at"),
            }
            for row in sorted(prior_rows, key=lambda item: (str(item.get("path") or ""), str(item.get("id") or "")))
        ]
        payload = json.dumps(normalized, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    @staticmethod
    def _prior_sort_key(prior: PriorLightRow) -> tuple[str, str, str]:
        return prior.path, prior.title, prior.id

    def _iter_prior_filepaths(self, search_dir: str) -> list[str]:
        filepaths: list[str] = []
        for dirpath, dirnames, filenames in os.walk(search_dir):
            dirnames[:] = sorted(name for name in dirnames if not name.startswith("."))
            for filename in sorted(filenames):
                if not self._is_prior_file(filename):
                    continue
                filepath = os.path.join(dirpath, filename)
                if os.path.basename(filepath) == SCOPE_METADATA_FILENAME:
                    continue
                filepaths.append(filepath)
        return filepaths

    def _snapshot_approx_bytes(self, prior_rows: list[PriorLightRow]) -> int:
        return sum(
            len(
                json.dumps(
                    {
                        **row.to_dict(),
                        "filepath": row.filepath,
                    },
                    ensure_ascii=False,
                    sort_keys=True,
                ).encode("utf-8")
            )
            for row in prior_rows
        )

    def _build_snapshot_once(self, normalized_base_path: str, generation: str) -> PriorSnapshot:
        search_dir = self.base if not normalized_base_path else os.path.join(self.base, normalized_base_path)
        if not os.path.isdir(search_dir):
            snapshot = PriorSnapshot(
                user_id=self.user_id,
                project_id=self.project_id,
                base_path=normalized_base_path,
                generation=generation,
                scope_hash=self._scope_hash([]),
                prior_rows=[],
                prior_by_id={},
                folder_priors={},
                filepath_by_id={},
                approx_bytes=0,
            )
            snapshot.mark_accessed()
            return snapshot

        prior_rows: list[PriorLightRow] = []
        prior_by_id: dict[str, PriorLightRow] = {}
        folder_priors: dict[str, list[PriorLightRow]] = defaultdict(list)
        filepath_by_id: dict[str, str] = {}
        scope_hash_rows: list[dict[str, Any]] = []

        for filepath in self._iter_prior_filepaths(search_dir):
            row = self._normalized_prior_record(
                self._read_prior_file(filepath),
                filepath,
                include_content=True,
            )
            if not row["id"] or row["prior_status"] != "active":
                continue
            light_row = PriorLightRow(
                id=row["id"],
                title=row["title"],
                summary=row["summary"],
                path=row["path"],
                when_to_use=row["when_to_use"],
                consequence_if_not_followed=row["consequence_if_not_followed"],
                non_adherence_severity=row["non_adherence_severity"],
                aliases=tuple(row["aliases"]),
                keywords=tuple(row["keywords"]),
                related_priors=tuple(row["related_priors"]),
                prior_status=row["prior_status"],
                updated_at=row["updated_at"],
                filepath=filepath,
            )
            prior_rows.append(light_row)
            prior_by_id[light_row.id] = light_row
            folder_priors[light_row.path].append(light_row)
            filepath_by_id[light_row.id] = filepath
            scope_hash_rows.append(
                {
                    key: row[key]
                    for key in (
                        "id",
                        "title",
                        "summary",
                        "content",
                        "path",
                        "when_to_use",
                        "consequence_if_not_followed",
                        "non_adherence_severity",
                        "aliases",
                        "keywords",
                        "related_priors",
                        "prior_status",
                        "updated_at",
                    )
                }
            )

        prior_rows.sort(key=self._prior_sort_key)
        for path, rows in folder_priors.items():
            folder_priors[path] = sorted(rows, key=self._prior_sort_key)

        snapshot = PriorSnapshot(
            user_id=self.user_id,
            project_id=self.project_id,
            base_path=normalized_base_path,
            generation=generation,
            scope_hash=self._scope_hash(scope_hash_rows),
            prior_rows=prior_rows,
            prior_by_id=prior_by_id,
            folder_priors=dict(folder_priors),
            filepath_by_id=filepath_by_id,
            approx_bytes=self._snapshot_approx_bytes(prior_rows),
        )
        snapshot.mark_accessed()
        return snapshot

    def _build_snapshot(self, base_path: str = "") -> PriorSnapshot:
        normalized_base_path = _normalize_path(base_path)
        generation = self._read_snapshot_generation()
        for _attempt in range(3):
            snapshot = self._build_snapshot_once(normalized_base_path, generation)
            current_generation = self._read_snapshot_generation()
            if current_generation == generation:
                return snapshot
            generation = current_generation
        return self._build_snapshot_once(normalized_base_path, generation)

    def get_snapshot(self, base_path: str = "") -> PriorSnapshot:
        normalized_base_path = _normalize_path(base_path)
        cache_key = self._corpus_key(normalized_base_path)

        with self._lock:
            current_generation = self._read_snapshot_generation()
            with self._cache_lock:
                cached = type(self)._snapshot_cache.get(cache_key)
                if cached is not None and cached.generation == current_generation:
                    cached.mark_accessed()
                    return cached

            snapshot = self._build_snapshot(normalized_base_path)

            with self._cache_lock:
                cls = type(self)
                previous = cls._snapshot_cache.get(cache_key)
                if previous is not None:
                    cls._snapshot_cache_total_bytes -= previous.approx_bytes
                cls._snapshot_cache[cache_key] = snapshot
                cls._snapshot_cache_total_bytes += snapshot.approx_bytes
                cls._evict_if_needed()
            return snapshot

    def _load_dense_matrix(self, *, base_path: str, scope_hash: str, prior_ids: list[str]) -> np.ndarray | None:
        metadata_path, matrix_path = self._dense_artifact_paths(base_path, scope_hash)
        if not os.path.exists(metadata_path) or not os.path.exists(matrix_path):
            return None
        try:
            with open(metadata_path, encoding="utf-8") as handle:
                metadata = json.load(handle)
            if metadata.get("scope_hash") != scope_hash:
                return None
            if list(metadata.get("prior_ids") or []) != list(prior_ids):
                return None
            matrix = np.load(matrix_path)
            if matrix.ndim != 2 or matrix.shape[0] != len(prior_ids):
                return None
            return matrix.astype(np.float32, copy=False)
        except Exception:
            return None

    def _store_dense_matrix(
        self,
        *,
        base_path: str,
        scope_hash: str,
        prior_ids: list[str],
        matrix: np.ndarray,
    ) -> None:
        metadata_path, matrix_path = self._dense_artifact_paths(base_path, scope_hash)
        artifact_dir = os.path.dirname(metadata_path)
        os.makedirs(artifact_dir, exist_ok=True)
        with open(metadata_path, "w", encoding="utf-8") as handle:
            json.dump(
                {
                    "scope_hash": scope_hash,
                    "base_path": _normalize_path(base_path),
                    "prior_ids": prior_ids,
                },
                handle,
                ensure_ascii=False,
                indent=2,
            )
        np.save(matrix_path, matrix)

    def _build_bm25_index(self, prior_ids: list[str], retrieval_texts: list[str]) -> tuple[object | None, list[str]]:
        if not prior_ids:
            return None, []
        corpus_tokens = bm25s.tokenize(
            retrieval_texts,
            stopwords="english",
            show_progress=False,
        )
        retriever = bm25s.BM25(method="lucene")
        retriever.index(corpus_tokens, show_progress=False)
        return retriever, list(prior_ids)

    def _load_prior_from_filepath(self, filepath: str, *, include_content: bool = True) -> dict[str, Any]:
        return self._build_prior_dict(self._read_prior_file(filepath), filepath, include_content=include_content)

    def get_many(
        self,
        prior_ids: list[str],
        *,
        snapshot: PriorSnapshot | None = None,
    ) -> list[dict[str, Any]]:
        if not prior_ids:
            return []

        rows: list[dict[str, Any]] = []
        seen: set[str] = set()
        with self._lock:
            resolved_snapshot = snapshot or self.get_snapshot()
            for prior_id in prior_ids:
                normalized_prior_id = str(prior_id or "").strip()
                if not normalized_prior_id or normalized_prior_id in seen:
                    continue
                seen.add(normalized_prior_id)
                filepath = resolved_snapshot.filepath_by_id.get(normalized_prior_id)
                if filepath is not None:
                    rows.append(self._load_prior_from_filepath(filepath, include_content=True))
                    continue
                filepath = self._find_prior_file(normalized_prior_id)
                if filepath is not None:
                    rows.append(self._load_prior_from_filepath(filepath, include_content=True))
        return rows

    def get_corpus(self, base_path: str = "") -> PriorCorpus:
        normalized_base_path = _normalize_path(base_path)
        cache_key = self._corpus_key(normalized_base_path)

        with self._lock:
            snapshot = self.get_snapshot(normalized_base_path)
            with self._cache_lock:
                cached = type(self)._corpus_cache.get(cache_key)
                if cached is not None and cached.scope_hash == snapshot.scope_hash:
                    cached.mark_accessed()
                    return cached

            prior_rows = self.get_many([row.id for row in snapshot.prior_rows], snapshot=snapshot)
            retrieval_text_by_id: dict[str, str] = {}
            keyword_docs: list[KeywordSearchDocument] = []
            prior_by_id: dict[str, dict] = {}
            prior_ids: list[str] = []
            retrieval_texts: list[str] = []

            for row in prior_rows:
                prior_id = str(row.get("id") or "")
                if not prior_id:
                    continue
                prior_by_id[prior_id] = row
                retrieval_text = _build_retrieval_text(row)
                retrieval_text_by_id[prior_id] = retrieval_text
                prior_ids.append(prior_id)
                retrieval_texts.append(retrieval_text)
                keyword_docs.append(
                    KeywordSearchDocument(
                        prior_id=prior_id,
                        title=str(row.get("title") or ""),
                        path=str(row.get("path") or ""),
                        title_tokens=_unique_tokens(str(row.get("title") or ""), drop_stopwords=True),
                        keyword_tokens=_unique_tokens(" ".join(row.get("keywords") or []), drop_stopwords=True),
                        alias_tokens=_unique_tokens(" ".join(row.get("aliases") or []), drop_stopwords=True),
                        taxonomy_tokens=_unique_tokens(" ".join(_taxonomy_path(str(row.get("path") or ""))), drop_stopwords=True),
                        when_to_use_tokens=_unique_tokens(str(row.get("when_to_use") or ""), drop_stopwords=True),
                    )
                )

            bm25_retriever, bm25_prior_ids = self._build_bm25_index(prior_ids, retrieval_texts)
            dense_matrix = self._load_dense_matrix(
                base_path=normalized_base_path,
                scope_hash=snapshot.scope_hash,
                prior_ids=prior_ids,
            )
            if dense_matrix is None:
                dense_matrix = _embed_texts(retrieval_texts, input_type="search_document")
                self._store_dense_matrix(
                    base_path=normalized_base_path,
                    scope_hash=snapshot.scope_hash,
                    prior_ids=prior_ids,
                    matrix=dense_matrix,
                )

            approx_bytes = int(dense_matrix.nbytes)
            approx_bytes += sum(len(text.encode("utf-8")) for text in retrieval_texts)
            approx_bytes += sum(len(json.dumps(row, ensure_ascii=False)) for row in prior_rows)

            corpus = PriorCorpus(
                user_id=self.user_id,
                project_id=self.project_id,
                base_path=normalized_base_path,
                scope_hash=snapshot.scope_hash,
                prior_rows=prior_rows,
                prior_by_id=prior_by_id,
                retrieval_texts=retrieval_text_by_id,
                keyword_docs=keyword_docs,
                bm25_retriever=bm25_retriever,
                bm25_prior_ids=bm25_prior_ids,
                dense_prior_ids=prior_ids,
                dense_matrix=dense_matrix,
                approx_bytes=approx_bytes,
            )
            corpus.mark_accessed()

            with self._cache_lock:
                cls = type(self)
                previous = cls._corpus_cache.get(cache_key)
                if previous is not None:
                    cls._corpus_cache_total_bytes -= previous.approx_bytes
                cls._corpus_cache[cache_key] = corpus
                cls._corpus_cache_total_bytes += corpus.approx_bytes
                cls._evict_if_needed()
            return corpus

    @property
    def scope_metadata_path(self) -> str:
        return os.path.join(self.base, SCOPE_METADATA_FILENAME)

    def _read_legacy_scope_metadata(self) -> dict | None:
        if not os.path.exists(self.scope_metadata_path):
            return None
        with open(self.scope_metadata_path, encoding="utf-8") as handle:
            return json.load(handle)

    def _ensure_scope_metadata(self) -> dict:
        scope = DB.get_priors_scope(user_id=self.user_id, project_id=self.project_id)
        if scope is not None:
            return scope

        legacy = self._read_legacy_scope_metadata()
        return DB.ensure_priors_scope(
            user_id=self.user_id,
            project_id=self.project_id,
            revision=int((legacy or {}).get("revision", 1) or 1),
            updated_at=str((legacy or {}).get("updated_at") or _utc_now_iso()),
        )

    def read_scope_metadata(self) -> dict:
        return self._ensure_scope_metadata()

    def bump_scope_revision(self) -> dict:
        return DB.bump_priors_scope_revision(
            user_id=self.user_id,
            project_id=self.project_id,
            updated_at=_utc_now_iso(),
        )

    def _prior_path(self, path: str, prior_id: str) -> str:
        return os.path.join(self.base, _normalize_path(path), f"{prior_id}.json")

    def _folder_path(self, path: str) -> str:
        return os.path.join(self.base, _normalize_path(path))

    def folder_exists(self, path: str) -> bool:
        normalized = _normalize_path(path)
        if not normalized:
            return True
        with self._lock:
            return os.path.isdir(self._folder_path(normalized))

    def _join_folder_path(self, parent_path: str, name: str) -> str:
        parent = _normalize_path(parent_path)
        segment = name.strip("/").strip()
        return _normalize_path(f"{parent}{segment}" if parent else segment)

    def _folder_name(self, path: str) -> str:
        normalized = _normalize_path(path)
        return normalized.rstrip("/").split("/")[-1] if normalized else ""

    @staticmethod
    def _normalize_string_list(values: object) -> list[str]:
        if not isinstance(values, list):
            return []

        normalized: list[str] = []
        seen: set[str] = set()
        for value in values:
            if not isinstance(value, str):
                continue
            item = value.strip()
            key = item.casefold()
            if not item or key in seen:
                continue
            seen.add(key)
            normalized.append(item)
        return normalized

    @staticmethod
    def _normalize_non_adherence_severity(value: object) -> int | None:
        if value in (None, ""):
            return None
        try:
            severity = int(value)
        except (TypeError, ValueError):
            return None
        return max(1, min(10, severity))

    def _normalized_prior_record(
        self,
        data: dict[str, Any],
        filepath: str,
        *,
        include_content: bool,
    ) -> dict[str, Any]:
        record = {
            "id": str(data.get("prior_id") or "").strip(),
            "title": str(data.get("title") or data.get("name", "")),
            "summary": str(data.get("summary", "")),
            "path": self._relative_path_from_file(filepath),
            "prior_status": str(data.get("status", "active") or "active"),
            "when_to_use": str(data.get("when_to_use") or ""),
            "run_id": data.get("run_id") or data.get("creation_trace_id"),
            "consequence_if_not_followed": str(data.get("consequence_if_not_followed") or ""),
            "non_adherence_severity": self._normalize_non_adherence_severity(
                data.get("non_adherence_severity")
            ),
            "aliases": self._normalize_string_list(data.get("aliases")),
            "keywords": self._normalize_string_list(data.get("keywords")),
            "related_priors": self._normalize_string_list(data.get("related_priors")),
            "created_at": data.get("created_at"),
            "updated_at": str(data.get("updated_at")) if data.get("updated_at") is not None else None,
            "validation_metadata": data.get("validation_metadata"),
        }
        if include_content:
            record["content"] = str(data.get("content", ""))
        return record

    def _normalized_write_extra(
        self,
        *,
        status: str,
        run_id: object,
        validation_metadata: object,
        when_to_use: object,
        consequence_if_not_followed: object,
        non_adherence_severity: object,
        aliases: object,
        keywords: object,
        related_priors: object,
        created_at: object,
        updated_at: object,
    ) -> dict[str, Any]:
        return {
            "status": status,
            "run_id": run_id,
            "when_to_use": str(when_to_use or ""),
            "consequence_if_not_followed": str(consequence_if_not_followed or ""),
            "non_adherence_severity": self._normalize_non_adherence_severity(
                non_adherence_severity
            ),
            "aliases": self._normalize_string_list(aliases),
            "keywords": self._normalize_string_list(keywords),
            "related_priors": self._normalize_string_list(related_priors),
            "created_at": created_at,
            "updated_at": updated_at,
            "validation_metadata": validation_metadata,
        }

    @staticmethod
    def _written_prior_response(
        prior_id: str, title: str, summary: str, content: str, path: str, extra: dict[str, Any]
    ) -> dict[str, Any]:
        return {
            "id": prior_id,
            "title": title,
            "summary": summary,
            "content": content,
            "path": path,
            "prior_status": extra["status"],
            **{key: value for key, value in extra.items() if key != "status"},
        }

    def _copy_create_kwargs(self, data: dict[str, Any], *, as_draft: bool) -> dict[str, Any]:
        return {
            "status": "draft" if as_draft else str(data.get("status", "active")),
            "run_id": data.get("run_id") or data.get("creation_trace_id"),
            "validation_metadata": None if as_draft else data.get("validation_metadata"),
            "when_to_use": str(data.get("when_to_use") or ""),
            "consequence_if_not_followed": str(data.get("consequence_if_not_followed") or ""),
            "non_adherence_severity": self._normalize_non_adherence_severity(
                data.get("non_adherence_severity")
            ),
            "aliases": self._normalize_string_list(data.get("aliases")),
            "keywords": self._normalize_string_list(data.get("keywords")),
            "related_priors": self._normalize_string_list(data.get("related_priors")),
        }

    def _read_prior_file(self, filepath: str) -> dict:
        with open(filepath, encoding="utf-8") as handle:
            return json.load(handle)

    def _write_prior_file(
        self,
        filepath: str,
        prior_id: str,
        title: str,
        summary: str,
        content: str,
        **extra,
    ) -> None:
        dirpath = os.path.dirname(filepath)
        os.makedirs(dirpath, exist_ok=True)
        data = {
            "prior_id": prior_id,
            "title": title,
            "summary": summary,
            "content": content,
        }
        data.update(extra)
        fd, tmp = tempfile.mkstemp(dir=dirpath, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(data, handle, ensure_ascii=False, indent=2)
            os.replace(tmp, filepath)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    def _find_prior_file(self, prior_id: str) -> Optional[str]:
        target = f"{prior_id}.json"
        for dirpath, dirnames, filenames in os.walk(self.base):
            dirnames[:] = sorted(name for name in dirnames if not name.startswith("."))
            if target in filenames:
                return os.path.join(dirpath, target)
        return None

    def _relative_path_from_file(self, filepath: str) -> str:
        rel = os.path.relpath(os.path.dirname(filepath), self.base)
        if rel == ".":
            return ""
        return rel.replace(os.sep, "/") + "/"

    def _is_prior_file(self, filename: str) -> bool:
        return filename.endswith(".json") and not filename.startswith(".")

    def _existing_prior_names(self, path: str, exclude_prior_id: Optional[str] = None) -> set[str]:
        target_dir = self._folder_path(path)
        if not os.path.isdir(target_dir):
            return set()
        names: set[str] = set()
        for entry in os.listdir(target_dir):
            full = os.path.join(target_dir, entry)
            if not os.path.isfile(full) or not self._is_prior_file(entry):
                continue
            data = self._read_prior_file(full)
            if exclude_prior_id and data.get("prior_id") == exclude_prior_id:
                continue
            names.add(str(data.get("title") or data.get("name", "")))
        return names

    def _unique_prior_name(self, path: str, desired_name: str, exclude_prior_id: Optional[str] = None) -> str:
        existing = self._existing_prior_names(path, exclude_prior_id=exclude_prior_id)
        if desired_name not in existing:
            return desired_name
        base = desired_name
        suffix = " copy"
        candidate = f"{base}{suffix}"
        counter = 2
        while candidate in existing:
            candidate = f"{base}{suffix} {counter}"
            counter += 1
        return candidate

    def _unique_folder_path(self, parent_path: str, desired_name: str) -> str:
        candidate_name = desired_name
        candidate_path = self._join_folder_path(parent_path, candidate_name)
        if not os.path.exists(self._folder_path(candidate_path)):
            return candidate_path
        suffix = " copy"
        candidate_name = f"{desired_name}{suffix}"
        counter = 2
        candidate_path = self._join_folder_path(parent_path, candidate_name)
        while os.path.exists(self._folder_path(candidate_path)):
            candidate_name = f"{desired_name}{suffix} {counter}"
            candidate_path = self._join_folder_path(parent_path, candidate_name)
            counter += 1
        return candidate_path

    def _build_prior_dict(self, data: dict, filepath: str, include_content: bool = True) -> dict:
        return self._normalized_prior_record(data, filepath, include_content=include_content)

    def create(
        self,
        prior_id: str,
        title: str,
        summary: str,
        content: str,
        path: str = "",
        status: str = "active",
        run_id: Optional[str] = None,
        validation_metadata: Optional[dict] = None,
        when_to_use: str = "",
        consequence_if_not_followed: str = "",
        non_adherence_severity: int | None = None,
        aliases: Optional[list[str]] = None,
        keywords: Optional[list[str]] = None,
        related_priors: Optional[list[str]] = None,
    ) -> dict:
        with self._locked_tree_mutation(path):
            now = _utc_now_iso()
            filepath = self._prior_path(path, prior_id)
            extra = self._normalized_write_extra(
                status=status,
                run_id=run_id,
                validation_metadata=validation_metadata,
                when_to_use=when_to_use,
                consequence_if_not_followed=consequence_if_not_followed,
                non_adherence_severity=non_adherence_severity,
                aliases=aliases,
                keywords=keywords,
                related_priors=related_priors,
                created_at=now,
                updated_at=now,
            )
            self._write_prior_file(filepath, prior_id, title, summary, content, **extra)
            self._invalidate_retrieval_state()
            return self._written_prior_response(
                prior_id, title, summary, content, _normalize_path(path), extra
            )

    def import_prior(
        self,
        *,
        prior_id: str,
        title: str,
        summary: str,
        content: str,
        path: str = "",
        status: str = "active",
        run_id: Optional[str] = None,
        validation_metadata: Optional[dict] = None,
        when_to_use: str = "",
        consequence_if_not_followed: str = "",
        non_adherence_severity: int | None = None,
        aliases: Optional[list[str]] = None,
        keywords: Optional[list[str]] = None,
        related_priors: Optional[list[str]] = None,
        created_at: Optional[str] = None,
        updated_at: Optional[str] = None,
    ) -> dict:
        target_path = _normalize_path(path)
        old_filepath = self._find_prior_file(prior_id)
        old_path = self._relative_path_from_file(old_filepath) if old_filepath else ""
        with self._locked_tree_mutation(old_path, target_path):
            now = _utc_now_iso()
            filepath = self._prior_path(target_path, prior_id)
            extra = self._normalized_write_extra(
                status=status,
                run_id=run_id,
                validation_metadata=validation_metadata,
                when_to_use=when_to_use,
                consequence_if_not_followed=consequence_if_not_followed,
                non_adherence_severity=non_adherence_severity,
                aliases=aliases,
                keywords=keywords,
                related_priors=related_priors,
                created_at=created_at or now,
                updated_at=updated_at or created_at or now,
            )
            self._write_prior_file(filepath, prior_id, title, summary, content, **extra)
            if old_filepath and os.path.normpath(old_filepath) != os.path.normpath(filepath):
                os.remove(old_filepath)
            self._invalidate_retrieval_state()
            return self._written_prior_response(prior_id, title, summary, content, target_path, extra)

    def get(self, prior_id: str) -> Optional[dict]:
        with self._lock:
            filepath = self._find_prior_file(prior_id)
            if filepath is None:
                return None
            return self._load_prior_from_filepath(filepath, include_content=True)

    def list_all(self, path: Optional[str] = None, include_content: bool = False) -> list[dict]:
        with self._lock:
            search_dir = self.base if path is None else os.path.join(self.base, _normalize_path(path))
            if not os.path.isdir(search_dir):
                return []

            results = [
                self._load_prior_from_filepath(filepath, include_content=include_content)
                for filepath in self._iter_prior_filepaths(search_dir)
            ]
            results.sort(key=lambda item: (str(item.get("path") or ""), str(item.get("title") or ""), str(item.get("id") or "")))
            return results

    def list_folders(self, path: str = "", include_content: bool = False) -> dict:
        with self._lock:
            path = _normalize_path(path)
            target_dir = os.path.join(self.base, path) if path else self.base
            folders = []
            priors = []

            if not os.path.isdir(target_dir):
                return {"folders": [], "priors": [], "prior_count": 0}

            for entry in sorted(os.listdir(target_dir)):
                if entry == SCOPE_METADATA_FILENAME:
                    continue
                full = os.path.join(target_dir, entry)
                if os.path.isdir(full):
                    folders.append(
                        {
                            "path": path + entry + "/",
                            "prior_count": self._count_priors_recursive(full),
                        }
                    )
                elif self._is_prior_file(entry):
                    priors.append(self._load_prior_from_filepath(full, include_content=include_content))

            return {"folders": folders, "priors": priors, "prior_count": len(priors)}

    def _count_priors_recursive(self, directory: str) -> int:
        return len(self._iter_prior_filepaths(directory))

    def create_folder(self, path: str) -> dict:
        with self._locked_tree_mutation(path):
            folder_dir = self._folder_path(path)
            if os.path.exists(folder_dir):
                raise FileExistsError(f"Folder '{_normalize_path(path)}' already exists")
            os.makedirs(folder_dir, exist_ok=True)
            self._invalidate_retrieval_state()
            return {"path": _normalize_path(path)}

    def move_folder(self, path: str, new_path: str) -> Optional[dict]:
        with self._locked_tree_mutation(path, new_path):
            source_path = _normalize_path(path)
            target_path = _normalize_path(new_path)
            if not source_path or not target_path:
                return None

            source_dir = os.path.normpath(self._folder_path(source_path))
            target_dir = os.path.normpath(self._folder_path(target_path))
            base = os.path.normpath(self.base)

            if not os.path.isdir(source_dir):
                return None
            if source_dir == target_dir:
                return {"path": target_path}
            if os.path.exists(target_dir):
                raise FileExistsError(f"Folder '{target_path}' already exists")
            if os.path.commonpath([source_dir, target_dir]) == source_dir:
                raise ValueError("Cannot move a folder into one of its descendants")
            if os.path.commonpath([base, target_dir]) != base:
                raise ValueError("Target path escapes priors root")

            os.makedirs(os.path.dirname(target_dir), exist_ok=True)
            shutil.move(source_dir, target_dir)
            self._invalidate_retrieval_state()
            return {"path": target_path}

    def move_folder_to(self, path: str, destination_parent: str) -> Optional[dict]:
        source_path = _normalize_path(path)
        destination_parent = _normalize_path(destination_parent)
        folder_name = self._folder_name(source_path)
        if not folder_name:
            return None
        target_path = self._join_folder_path(destination_parent, folder_name)
        return self.move_folder(source_path, target_path)

    def delete_folder(self, path: str) -> bool:
        with self._locked_tree_mutation(path):
            target_path = _normalize_path(path)
            if not target_path:
                return False
            folder_dir = os.path.normpath(self._folder_path(target_path))
            if not os.path.isdir(folder_dir):
                return False
            shutil.rmtree(folder_dir)
            self._invalidate_retrieval_state()
            return True

    def update(
        self,
        prior_id: str,
        title: str,
        summary: str,
        content: str,
        path: Optional[str] = None,
        status: Optional[str] = None,
        run_id: Optional[str] | object = _UNSET,
        validation_metadata: Optional[dict] | object = _UNSET,
        when_to_use: str | object = _UNSET,
        consequence_if_not_followed: str | object = _UNSET,
        non_adherence_severity: int | None | object = _UNSET,
        aliases: list[str] | object = _UNSET,
        keywords: list[str] | object = _UNSET,
        related_priors: list[str] | object = _UNSET,
    ) -> Optional[dict]:
        old_filepath = self._find_prior_file(prior_id)
        current_path = self._relative_path_from_file(old_filepath) if old_filepath else ""
        target_path = _normalize_path(path) if path is not None else current_path
        with self._locked_tree_mutation(current_path, target_path):
            old_filepath = self._find_prior_file(prior_id)
            if old_filepath is None:
                return None

            old_data = self._read_prior_file(old_filepath)
            current_path = self._relative_path_from_file(old_filepath)
            target_path = _normalize_path(path) if path is not None else current_path

            extra = self._normalized_write_extra(
                status=status if status is not None else str(old_data.get("status", "active")),
                run_id=old_data.get("run_id") if run_id is _UNSET else run_id,
                validation_metadata=(
                    old_data.get("validation_metadata")
                    if validation_metadata is _UNSET
                    else validation_metadata
                ),
                when_to_use=(
                    old_data.get("when_to_use") if when_to_use is _UNSET else when_to_use
                ),
                consequence_if_not_followed=(
                    old_data.get("consequence_if_not_followed")
                    if consequence_if_not_followed is _UNSET
                    else consequence_if_not_followed
                ),
                non_adherence_severity=(
                    old_data.get("non_adherence_severity")
                    if non_adherence_severity is _UNSET
                    else non_adherence_severity
                ),
                aliases=old_data.get("aliases") if aliases is _UNSET else aliases,
                keywords=old_data.get("keywords") if keywords is _UNSET else keywords,
                related_priors=(
                    old_data.get("related_priors")
                    if related_priors is _UNSET
                    else related_priors
                ),
                created_at=old_data.get("created_at"),
                updated_at=_utc_now_iso(),
            )
            if extra["run_id"] is None:
                extra["run_id"] = old_data.get("creation_trace_id")

            new_filepath = self._prior_path(target_path, prior_id)
            self._write_prior_file(new_filepath, prior_id, title, summary, content, **extra)
            if os.path.normpath(old_filepath) != os.path.normpath(new_filepath):
                os.remove(old_filepath)
            self._invalidate_retrieval_state()

            return self._written_prior_response(prior_id, title, summary, content, target_path, extra)

    def delete(self, prior_id: str) -> bool:
        filepath = self._find_prior_file(prior_id)
        with self._locked_tree_mutation(self._relative_path_from_file(filepath) if filepath else ""):
            filepath = self._find_prior_file(prior_id)
            if filepath is None:
                return False
            os.remove(filepath)
            self._invalidate_retrieval_state()
            return True

    def move_lessons(self, prior_ids: list[str], dst: str) -> dict:
        paths = [_normalize_path(dst)]
        for prior_id in prior_ids:
            filepath = self._find_prior_file(prior_id)
            if filepath is not None:
                paths.append(self._relative_path_from_file(filepath))
        with self._locked_tree_mutation(*paths):
            dst = _normalize_path(dst)
            moved = 0
            for prior_id in prior_ids:
                filepath = self._find_prior_file(prior_id)
                if filepath is None:
                    continue
                new_filepath = self._prior_path(dst, prior_id)
                if os.path.normpath(filepath) == os.path.normpath(new_filepath):
                    continue
                os.makedirs(os.path.dirname(new_filepath), exist_ok=True)
                shutil.move(filepath, new_filepath)
                moved += 1
            if moved:
                self._invalidate_retrieval_state()
            return {"moved_count": moved}

    def copy_prior(self, prior_id: str, dst: str, *, as_draft: bool = False) -> Optional[dict]:
        filepath = self._find_prior_file(prior_id)
        with self._locked_tree_mutation(self._relative_path_from_file(filepath) if filepath else "", dst):
            filepath = self._find_prior_file(prior_id)
            if filepath is None:
                return None
            data = self._read_prior_file(filepath)
            new_id = str(uuid.uuid4())[:8]
            unique_name = self._unique_prior_name(dst, str(data.get("title") or data.get("name", "")))
            return self.create(
                new_id,
                unique_name,
                str(data.get("summary", "")),
                str(data.get("content", "")),
                dst,
                **self._copy_create_kwargs(data, as_draft=as_draft),
            )

    def copy_folder(self, path: str, destination_parent: str, *, as_draft: bool = False) -> Optional[dict]:
        with self._locked_tree_mutation(path, destination_parent):
            source_path = _normalize_path(path)
            destination_parent = _normalize_path(destination_parent)
            source_dir = os.path.normpath(self._folder_path(source_path))
            if not os.path.isdir(source_dir):
                return None

            folder_name = self._folder_name(source_path)
            if not folder_name:
                return None

            target_root_path = self._unique_folder_path(destination_parent, folder_name)
            target_root_dir = self._folder_path(target_root_path)
            os.makedirs(target_root_dir, exist_ok=True)

            for dirpath, _, filenames in os.walk(source_dir):
                rel_dir = os.path.relpath(dirpath, source_dir)
                relative_folder = "" if rel_dir == "." else rel_dir.replace(os.sep, "/") + "/"
                target_folder_path = self._join_folder_path(target_root_path, relative_folder.rstrip("/")) if relative_folder else target_root_path
                for filename in filenames:
                    if filename == SCOPE_METADATA_FILENAME or not self._is_prior_file(filename):
                        continue
                    filepath = os.path.join(dirpath, filename)
                    data = self._read_prior_file(filepath)
                    self.create(
                        str(uuid.uuid4())[:8],
                        str(data.get("title") or data.get("name", "")),
                        str(data.get("summary", "")),
                        str(data.get("content", "")),
                        target_folder_path,
                        **self._copy_create_kwargs(data, as_draft=as_draft),
                    )

            self._invalidate_retrieval_state()
            return {"path": target_root_path}
