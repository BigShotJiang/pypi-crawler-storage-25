"""Prior retrieval pipelines and background coverage worker."""

from __future__ import annotations

import asyncio
import json
import queue
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

from sovara.server.database import DB
from sovara.server.llm_backend import resolve_model
from sovara.server.priors_backend.constants import (
    DEFAULT_PRIORS_LATENCY_TIER,
    DEFAULT_PRIORS_PARALLEL_SEARCH_MAX_PARALLELISM,
    LOOSE_TOPK,
    PARALLEL_SEARCH_DIRECT_PRIOR_THRESHOLD,
    TOPK,
)
from sovara.server.priors_backend.logger import logger
from sovara.server.priors_backend.storage import PriorStore
from sovara.server.priors_backend.tools.bm25_search import bm25_search
from sovara.server.priors_backend.tools.dense_search import dense_search
from sovara.server.priors_backend.tools.keyword_search import keyword_search
from sovara.server.priors_backend.tools.parallel_search import parallel_search
from sovara.server.priors_backend.tools.preprocess_context import (
    materialize_raw_context,
    normalize_raw_context,
    preprocess_context,
)
from sovara.server.priors_backend.tools.prior_adherence import (
    calculate_prior_adherence,
    prior_adherence_judge_cache_config,
)
from sovara.server.priors_backend.tools.prior_coverage import (
    calculate_groundedness,
    groundedness_judge_cache_config,
)
from sovara.server.priors_backend.tools.rerank import RerankCandidate, rerank

_PRIOR_COVERAGE_POLL_SECONDS = 1.0
_PRIOR_COVERAGE_WORKER_POOL_SIZE = 32
_PRIOR_COVERAGE_QUEUE_MAXSIZE = _PRIOR_COVERAGE_WORKER_POOL_SIZE * 4
_PRIOR_COVERAGE_FETCH_LIMIT = _PRIOR_COVERAGE_QUEUE_MAXSIZE
_PRIOR_METRIC_GROUNDEDNESS = "groundedness"
_PRIOR_METRIC_ADHERENCE = "adherence"
_PRIOR_METRICS = (_PRIOR_METRIC_GROUNDEDNESS, _PRIOR_METRIC_ADHERENCE)
_worker_lock = threading.Lock()
_worker_stop = threading.Event()
_worker_coordinator_thread: threading.Thread | None = None
_worker_threads: list[threading.Thread] = []
_worker_queue: queue.Queue[dict[str, Any]] | None = None
_worker_state_lock = threading.Lock()
_queued_or_running_retrieval_ids: set[str] = set()


@dataclass(slots=True)
class PriorRetrieval:
    raw_context: str
    processed_context: str
    latency_tier: str
    model_used: str | None
    retrieved_priors: list[dict[str, Any]] = field(default_factory=list)
    applied_priors: list[dict[str, Any]] = field(default_factory=list)
    prior_coverage: int | None = None
    retrieval_status: str = "complete"
    coverage_status: str = "not_requested"


def ensure_prior_coverage_worker_started() -> None:
    global _worker_coordinator_thread, _worker_queue, _worker_threads
    with _worker_lock:
        if (
            _worker_coordinator_thread is not None
            and _worker_coordinator_thread.is_alive()
            and any(thread.is_alive() for thread in _worker_threads)
        ):
            return
        _worker_stop.clear()
        with _worker_state_lock:
            _queued_or_running_retrieval_ids.clear()
        _worker_queue = queue.Queue(maxsize=_PRIOR_COVERAGE_QUEUE_MAXSIZE)
        _worker_threads = [
            threading.Thread(
                target=_prior_coverage_worker,
                args=(worker_index, _worker_queue),
                name=f"sovara-prior-coverage-{worker_index + 1}",
                daemon=True,
            )
            for worker_index in range(_PRIOR_COVERAGE_WORKER_POOL_SIZE)
        ]
        for thread in _worker_threads:
            thread.start()
        _worker_coordinator_thread = threading.Thread(
            target=_prior_coverage_coordinator,
            args=(_worker_queue,),
            name="sovara-prior-coverage-coordinator",
            daemon=True,
        )
        _worker_coordinator_thread.start()
        logger.info(
            "[PRIORS GROUNDEDNESS] worker pool started size=%s queue_maxsize=%s",
            _PRIOR_COVERAGE_WORKER_POOL_SIZE,
            _PRIOR_COVERAGE_QUEUE_MAXSIZE,
        )


def shutdown_retrieval_process_pool() -> None:
    _worker_stop.set()
    coordinator_thread = _worker_coordinator_thread
    if coordinator_thread is not None and coordinator_thread.is_alive():
        coordinator_thread.join(timeout=2.0)
    for thread in list(_worker_threads):
        if thread.is_alive():
            thread.join(timeout=0.1)
    from sovara.server.priors_backend.llm.folder_rebalancer import (
        shutdown_folder_rebalance_worker,
    )

    shutdown_folder_rebalance_worker()


def _stringify_coverage_value(value: Any) -> str:
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)
    except TypeError:
        return str(value)


def _load_llm_output_for_coverage(run_id: str, node_uuid: str | None) -> str | None:
    if not run_id or not node_uuid:
        return None
    row = DB.get_llm_call_full(run_id, node_uuid)
    if row is None or not row["output"]:
        return None
    raw_output = str(row["output"])
    try:
        payload = json.loads(raw_output)
    except (TypeError, json.JSONDecodeError):
        output_text = raw_output
    else:
        if isinstance(payload, dict) and "to_show" in payload:
            output_text = _stringify_coverage_value(payload["to_show"])
        else:
            output_text = _stringify_coverage_value(payload)
    return output_text


def _prior_coverage_inputs(
    job: dict[str, Any],
) -> tuple[str, str | None, list[dict[str, Any]]] | None:
    run = DB.get_run_scope(job["run_id"])
    if run is None:
        return None
    run_scope = dict(run)
    if not run_scope.get("user_id") or not run_scope.get("project_id"):
        return None
    store = PriorStore(str(run_scope["user_id"]), str(run_scope["project_id"]))
    applied_priors = _resolve_applied_prior_rows(store, job.get("applied_priors") or [])
    normalized_raw_context = normalize_raw_context(str(job.get("raw_context") or ""))
    processed_context = str(job.get("processed_context") or "").strip() or materialize_raw_context(
        normalized_raw_context
    )
    llm_output = _load_llm_output_for_coverage(job["run_id"], job.get("node_uuid"))
    return processed_context, llm_output, applied_priors


def _prior_metric_context(job: dict[str, Any]) -> tuple[str, str, str]:
    return (
        str(job.get("retrieval_id") or ""),
        str(job.get("run_id") or ""),
        str(job.get("node_uuid") or ""),
    )


def _prior_metric_cache_config(metric: str) -> dict[str, Any]:
    if metric == _PRIOR_METRIC_GROUNDEDNESS:
        return groundedness_judge_cache_config()
    if metric == _PRIOR_METRIC_ADHERENCE:
        return prior_adherence_judge_cache_config()
    raise ValueError(f"unknown prior metric: {metric}")


def _prior_metric_cache_kwargs(
    metric: str,
    *,
    processed_context: str,
    llm_output: str | None,
    applied_priors: list[dict[str, Any]],
) -> dict[str, Any]:
    cache_config = _prior_metric_cache_config(metric)
    return {
        "processed_context": processed_context,
        "llm_output": llm_output,
        "priors": applied_priors,
        "judge_model": cache_config["model"],
        "judge_tier": cache_config["tier"],
        "reasoning_effort": cache_config["reasoning_effort"],
        "prompt_version": cache_config["prompt_version"],
    }


def _get_cached_prior_metric(
    metric: str,
    *,
    processed_context: str,
    llm_output: str | None,
    applied_priors: list[dict[str, Any]],
) -> dict[str, Any] | None:
    cache_kwargs = _prior_metric_cache_kwargs(
        metric,
        processed_context=processed_context,
        llm_output=llm_output,
        applied_priors=applied_priors,
    )
    if metric == _PRIOR_METRIC_GROUNDEDNESS:
        return DB.get_cached_prior_coverage(**cache_kwargs)
    return DB.get_cached_prior_adherence(**cache_kwargs)


def _store_cached_prior_metric(
    metric: str,
    *,
    processed_context: str,
    llm_output: str | None,
    applied_priors: list[dict[str, Any]],
    result: dict[str, Any],
) -> None:
    cache_kwargs = _prior_metric_cache_kwargs(
        metric,
        processed_context=processed_context,
        llm_output=llm_output,
        applied_priors=applied_priors,
    )
    if metric == _PRIOR_METRIC_GROUNDEDNESS:
        DB.store_cached_prior_coverage(
            **cache_kwargs,
            prior_coverage=int(result["groundedness"]),
            groundedness_details=result,
        )
        return
    DB.store_cached_prior_adherence(**cache_kwargs, adherence_details=result)


def _prior_metric_result_from_cached(metric: str, cached: dict[str, Any]) -> dict[str, Any]:
    if metric == _PRIOR_METRIC_GROUNDEDNESS:
        return cached.get("groundedness_details") or {
            "groundedness": int(cached["prior_coverage"]),
        }
    return cached.get("adherence_details") or {}


def _mark_cached_prior_metric_complete(
    retrieval_id: str,
    metric: str,
    cached: dict[str, Any],
) -> None:
    if metric == _PRIOR_METRIC_GROUNDEDNESS:
        DB.update_prior_coverage(
            retrieval_id,
            prior_coverage=int(cached["prior_coverage"]),
            coverage_status="complete",
            groundedness_details=cached.get("groundedness_details"),
        )
        return
    DB.update_prior_adherence(
        retrieval_id,
        adherence_status="complete",
        adherence_details=cached.get("adherence_details"),
    )


def _mark_prior_metric_complete(retrieval_id: str, metric: str, result: dict[str, Any]) -> None:
    if metric == _PRIOR_METRIC_GROUNDEDNESS:
        DB.update_prior_coverage(
            retrieval_id,
            prior_coverage=int(result["groundedness"]),
            coverage_status="complete",
            groundedness_details=result,
        )
        return
    DB.update_prior_adherence(
        retrieval_id,
        adherence_status="complete",
        adherence_details=result,
    )


def _calculate_prior_metric(
    metric: str,
    *,
    processed_context: str,
    llm_output: str | None,
    applied_priors: list[dict[str, Any]],
) -> dict[str, Any]:
    if metric == _PRIOR_METRIC_GROUNDEDNESS:
        return calculate_groundedness(
            processed_context=processed_context,
            llm_output=llm_output,
            priors=applied_priors,
        )
    return calculate_prior_adherence(
        processed_context=processed_context,
        llm_output=llm_output,
        priors=applied_priors,
    )


def _log_prior_metric_result(
    metric: str,
    *,
    retrieval_id: str,
    run_id: str,
    node_uuid: str,
    result: dict[str, Any],
    source: str,
) -> None:
    if metric == _PRIOR_METRIC_GROUNDEDNESS:
        logger.info(
            "[PRIORS GROUNDEDNESS] retrieval_id=%s run_id=%s node_uuid=%s "
            "source=%s groundedness=%s grounded_importance=%s total_importance=%s "
            "guidance_points=%s",
            retrieval_id,
            run_id,
            node_uuid,
            source,
            result.get("groundedness"),
            result.get("grounded_importance"),
            result.get("total_importance"),
            json.dumps(result.get("guidance_points") or [], ensure_ascii=False, sort_keys=True),
        )
        return
    logger.info(
        "[PRIORS ADHERENCE] retrieval_id=%s run_id=%s node_uuid=%s "
        "source=%s prior_adherence=%s severity_weighted_prior_adherence=%s "
        "relevant=%s followed=%s violated=%s total_severity=%s max_severity=%s items=%s",
        retrieval_id,
        run_id,
        node_uuid,
        source,
        result.get("prior_adherence"),
        result.get("severity_weighted_prior_adherence"),
        result.get("relevant_prior_count"),
        result.get("followed_relevant_prior_count"),
        result.get("violated_relevant_prior_count"),
        result.get("total_non_adherence_severity"),
        result.get("max_non_adherence_severity"),
        json.dumps(result.get("prior_adherence_items") or [], ensure_ascii=False, sort_keys=True),
    )


def _apply_cached_prior_metric(
    job: dict[str, Any],
    metric: str,
    inputs: tuple[str, str | None, list[dict[str, Any]]] | None = None,
) -> bool:
    retrieval_id, run_id, node_uuid = _prior_metric_context(job)
    if not retrieval_id:
        return False
    inputs = inputs or _prior_coverage_inputs(job)
    if inputs is None:
        return False
    processed_context, llm_output, applied_priors = inputs
    cached = _get_cached_prior_metric(
        metric,
        processed_context=processed_context,
        llm_output=llm_output,
        applied_priors=applied_priors,
    )
    if cached is None:
        return False
    _mark_cached_prior_metric_complete(retrieval_id, metric, cached)
    _log_prior_metric_result(
        metric,
        retrieval_id=retrieval_id,
        run_id=run_id,
        node_uuid=node_uuid,
        result=_prior_metric_result_from_cached(metric, cached),
        source="cache",
    )
    return True


def apply_cached_prior_coverage(job: dict[str, Any]) -> bool:
    return _apply_cached_prior_metric(job, _PRIOR_METRIC_GROUNDEDNESS)


def apply_cached_prior_adherence(job: dict[str, Any]) -> bool:
    return _apply_cached_prior_metric(job, _PRIOR_METRIC_ADHERENCE)


def _needs_groundedness(job: dict[str, Any]) -> bool:
    return job.get("coverage_status") != "complete" or job.get("prior_coverage") is None


def _needs_prior_adherence(job: dict[str, Any]) -> bool:
    return (
        job.get("adherence_status") != "complete"
        or job.get("prior_adherence") is None
        or job.get("severity_weighted_prior_adherence") is None
    )


def _prior_metric_job_key(metric: str, retrieval_id: str) -> str:
    return f"{metric}:{retrieval_id}"


def _prior_metric_from_job(job: dict[str, Any]) -> str | None:
    metric = str(job.get("_prior_metric") or "")
    return metric if metric in _PRIOR_METRICS else None


def _needs_prior_metric(job: dict[str, Any], metric: str) -> bool:
    if metric == _PRIOR_METRIC_GROUNDEDNESS:
        return _needs_groundedness(job)
    if metric == _PRIOR_METRIC_ADHERENCE:
        return _needs_prior_adherence(job)
    return False


def _prior_metric_status(job: dict[str, Any], metric: str) -> str | None:
    if metric == _PRIOR_METRIC_GROUNDEDNESS:
        return str(job.get("coverage_status") or "")
    if metric == _PRIOR_METRIC_ADHERENCE:
        return str(job.get("adherence_status") or "")
    return None


def _prior_metric_is_pending(job: dict[str, Any], metric: str) -> bool:
    return _prior_metric_status(job, metric) == "pending" and _needs_prior_metric(job, metric)


def _mark_prior_metric_failed(retrieval_id: str, metric: str) -> None:
    if metric == _PRIOR_METRIC_GROUNDEDNESS:
        DB.update_prior_coverage(retrieval_id, prior_coverage=None, coverage_status="failed")
    elif metric == _PRIOR_METRIC_ADHERENCE:
        DB.update_prior_adherence(retrieval_id, adherence_status="failed")


def _process_prior_metric_job(job: dict[str, Any], metric: str) -> None:
    retrieval_id, run_id, node_uuid = _prior_metric_context(job)
    if not retrieval_id or metric not in _PRIOR_METRICS:
        return
    if not _prior_metric_is_pending(job, metric):
        return
    try:
        inputs = _prior_coverage_inputs(job)
        if inputs is None:
            logger.warning(
                "[PRIORS %s] missing inputs retrieval_id=%s run_id=%s node_uuid=%s",
                metric.upper(),
                retrieval_id,
                run_id,
                node_uuid,
            )
            _mark_prior_metric_failed(retrieval_id, metric)
            return
        processed_context, llm_output, applied_priors = inputs
        if _apply_cached_prior_metric(job, metric, inputs):
            return
        result = _calculate_prior_metric(
            metric,
            processed_context=processed_context,
            llm_output=llm_output,
            applied_priors=applied_priors,
        )
        _store_cached_prior_metric(
            metric,
            processed_context=processed_context,
            llm_output=llm_output,
            applied_priors=applied_priors,
            result=result,
        )
        _mark_prior_metric_complete(retrieval_id, metric, result)
        _log_prior_metric_result(
            metric,
            retrieval_id=retrieval_id,
            run_id=run_id,
            node_uuid=node_uuid,
            result=result,
            source="judge",
        )
    except Exception:
        logger.exception(
            "[PRIORS %s] failed retrieval_id=%s run_id=%s node_uuid=%s",
            metric.upper(),
            retrieval_id,
            run_id,
            node_uuid,
        )
        fresh = DB.get_prior_retrieval_by_id(retrieval_id)
        if fresh is None or _prior_metric_is_pending(fresh, metric):
            _mark_prior_metric_failed(retrieval_id, metric)


def _process_prior_coverage_job(job: dict[str, Any]) -> None:
    for metric in _PRIOR_METRICS:
        if _prior_metric_is_pending(job, metric):
            _process_prior_metric_job(job, metric)
            job = DB.get_prior_retrieval_by_id(str(job.get("retrieval_id") or "")) or job


def _prior_coverage_coordinator(job_queue: queue.Queue[dict[str, Any]]) -> None:
    while not _worker_stop.is_set():
        enqueued_count = _enqueue_pending_prior_coverage_jobs(job_queue)
        if enqueued_count == 0:
            _worker_stop.wait(_PRIOR_COVERAGE_POLL_SECONDS)
            continue
        _worker_stop.wait(0.05)


def _enqueue_pending_prior_coverage_jobs(job_queue: queue.Queue[dict[str, Any]]) -> int:
    available_slots = job_queue.maxsize - job_queue.qsize()
    if available_slots <= 0:
        return 0

    jobs = DB.get_pending_prior_coverage_jobs(
        limit=min(_PRIOR_COVERAGE_FETCH_LIMIT, available_slots)
    )
    enqueued_count = 0
    for job in jobs:
        if enqueued_count >= available_slots:
            break
        retrieval_id = str(job.get("retrieval_id") or "")
        if not retrieval_id:
            continue
        for metric in _PRIOR_METRICS:
            if enqueued_count >= available_slots:
                break
            if not _prior_metric_is_pending(job, metric):
                continue
            queue_key = _prior_metric_job_key(metric, retrieval_id)
            with _worker_state_lock:
                if queue_key in _queued_or_running_retrieval_ids:
                    continue
                _queued_or_running_retrieval_ids.add(queue_key)
            metric_job = dict(job)
            metric_job["_prior_metric"] = metric
            try:
                job_queue.put_nowait(metric_job)
            except queue.Full:
                with _worker_state_lock:
                    _queued_or_running_retrieval_ids.discard(queue_key)
                return enqueued_count
            enqueued_count += 1
    return enqueued_count


def _prior_coverage_worker(
    worker_index: int,
    job_queue: queue.Queue[dict[str, Any]],
) -> None:
    while not _worker_stop.is_set():
        try:
            queued_job = job_queue.get(timeout=_PRIOR_COVERAGE_POLL_SECONDS)
        except queue.Empty:
            continue

        retrieval_id = str(queued_job.get("retrieval_id") or "")
        metric = _prior_metric_from_job(queued_job)
        queue_key = _prior_metric_job_key(metric, retrieval_id) if metric and retrieval_id else ""
        try:
            job = _refresh_pending_prior_coverage_job(queued_job)
            if job is not None:
                logger.debug(
                    "[PRIORS %s] worker=%s processing retrieval_id=%s",
                    str(metric).upper(),
                    worker_index + 1,
                    retrieval_id,
                )
                _process_prior_metric_job(job, str(metric))
        finally:
            if queue_key:
                with _worker_state_lock:
                    _queued_or_running_retrieval_ids.discard(queue_key)
            job_queue.task_done()


def _refresh_pending_prior_coverage_job(job: dict[str, Any]) -> dict[str, Any] | None:
    retrieval_id = str(job.get("retrieval_id") or "")
    metric = _prior_metric_from_job(job)
    if not retrieval_id or metric is None:
        return None
    fresh = DB.get_prior_retrieval_by_id(retrieval_id)
    if fresh is None:
        return None
    if not _prior_metric_is_pending(fresh, metric):
        return None
    fresh = dict(fresh)
    fresh["_prior_metric"] = metric
    return fresh


def _resolve_applied_prior_rows(
    store: PriorStore, applied_priors: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    snapshots: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for prior in applied_priors:
        if not isinstance(prior, dict):
            continue
        prior_id = str(prior.get("id") or "").strip()
        if not prior_id or prior_id in seen_ids:
            continue
        seen_ids.add(prior_id)
        snapshot = dict(prior)
        snapshot["id"] = prior_id
        snapshots.append(snapshot)

    if not snapshots:
        return []

    loaded_rows = store.get_many([str(prior["id"]) for prior in snapshots])
    loaded_by_id = {str(row.get("id") or ""): row for row in loaded_rows}
    resolved: list[dict[str, Any]] = []
    for prior in snapshots:
        loaded = loaded_by_id.get(str(prior["id"]))
        if _has_complete_prior_snapshot(prior) or loaded is None:
            resolved.append(prior)
            continue
        resolved.extend(_merge_prior_rows([prior], [loaded]))
    return resolved


def _has_complete_prior_snapshot(prior: dict[str, Any]) -> bool:
    return all(
        key in prior
        for key in (
            "title",
            "summary",
            "content",
            "path",
            "consequence_if_not_followed",
            "non_adherence_severity",
        )
    )


def _load_prior_rows(store: PriorStore, prior_ids: list[str]) -> list[dict[str, Any]]:
    seen_ids: list[str] = []
    seen: set[str] = set()
    for prior_id in prior_ids:
        normalized_prior_id = str(prior_id or "").strip()
        if not normalized_prior_id or normalized_prior_id in seen:
            continue
        seen.add(normalized_prior_id)
        seen_ids.append(normalized_prior_id)

    loaded_rows = store.get_many(seen_ids)
    loaded_by_id = {str(row.get("id") or ""): row for row in loaded_rows}
    return [loaded_by_id.get(prior_id, {"id": prior_id}) for prior_id in seen_ids]


def _merge_prior_rows(*groups: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged: list[dict[str, Any]] = []
    by_id: dict[str, dict[str, Any]] = {}
    for group in groups:
        for prior in group:
            prior_id = str(prior.get("id") or "")
            if not prior_id:
                continue
            existing = by_id.get(prior_id)
            if existing is None:
                existing = {"id": prior_id}
                by_id[prior_id] = existing
                merged.append(existing)
            for key, value in prior.items():
                if value not in (None, "") and existing.get(key) in (None, ""):
                    existing[key] = value
    return merged


def _rrf_rankings(*rankings: dict[str, float], top_k: int) -> list[str]:
    scores: dict[str, float] = defaultdict(float)
    for ranking in rankings:
        ordered = sorted(ranking.items(), key=lambda item: item[1], reverse=True)
        for index, (prior_id, _score) in enumerate(ordered, start=1):
            scores[prior_id] += 1.0 / (60.0 + index)
    return [
        prior_id
        for prior_id, _score in sorted(scores.items(), key=lambda item: item[1], reverse=True)[
            :top_k
        ]
    ]


def _candidate_rows_from_ids(corpus, candidate_ids: list[str]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for prior_id in candidate_ids:
        row = corpus.prior_by_id.get(prior_id)
        if row is not None:
            rows.append(row)
    return rows


def _rerank_candidates(corpus, processed_context: str, candidate_ids: list[str]) -> list[str]:
    candidates = [
        RerankCandidate(
            prior_id=prior_id,
            retrieval_text=corpus.retrieval_texts[prior_id],
            title=str(corpus.prior_by_id[prior_id].get("title") or ""),
            path=str(corpus.prior_by_id[prior_id].get("path") or ""),
        )
        for prior_id in candidate_ids
        if prior_id in corpus.prior_by_id and prior_id in corpus.retrieval_texts
    ]
    if not candidates:
        return []
    ranked = rerank(retrieval_context=processed_context, candidates=candidates, top_k=None)
    return [str(item["prior_id"]) for item in ranked]


def _hybrid_candidate_ids(corpus, processed_context: str) -> list[str]:
    keyword_scores = keyword_search(
        docs=corpus.keyword_docs,
        retrieval_context=processed_context,
        top_k=LOOSE_TOPK,
    )
    bm25_scores = bm25_search(
        bm25_retriever=corpus.bm25_retriever,
        corpus_ids=corpus.bm25_prior_ids,
        retrieval_context=processed_context,
        top_k=LOOSE_TOPK,
    )
    dense_scores = dense_search(
        dense_prior_ids=corpus.dense_prior_ids,
        dense_matrix=corpus.dense_matrix,
        retrieval_context=processed_context,
        top_k=LOOSE_TOPK,
    )
    return _rrf_rankings(keyword_scores, bm25_scores, dense_scores, top_k=LOOSE_TOPK)


def _selection_infer_tier(latency_tier: str) -> str:
    return "expensive" if latency_tier == "HIGH" else "ultra-cheap"


def _selection_reasoning_effort(latency_tier: str) -> str:
    if latency_tier == "HIGH":
        return "low"
    return "none"


def _use_summary_only_selection(latency_tier: str) -> bool:
    return latency_tier in {"MEDIUM", "HIGH"}


def _log_retrieval_timings(total_started_at: float, **payload: Any) -> None:
    logger.info(
        "Prior retrieval timings | %s",
        json.dumps(
            {
                **payload,
                "total_ms": int((time.perf_counter() - total_started_at) * 1000),
            },
            ensure_ascii=False,
            sort_keys=True,
        ),
    )


def _complete_prior_retrieval(
    *,
    raw_context: str,
    processed_context: str,
    latency_tier: str,
    model_used: str,
    retrieved_priors: list[dict[str, Any]],
    applied_priors: list[dict[str, Any]],
) -> PriorRetrieval:
    return PriorRetrieval(
        raw_context=raw_context,
        processed_context=processed_context,
        latency_tier=latency_tier,
        model_used=model_used,
        retrieved_priors=retrieved_priors,
        applied_priors=applied_priors,
        prior_coverage=None,
        retrieval_status="complete",
        coverage_status="not_requested",
    )


def _filter_candidate_ids(candidate_ids: list[str], ignored_prior_ids: set[str]) -> list[str]:
    return [prior_id for prior_id in candidate_ids if prior_id not in ignored_prior_ids]


def _effective_parallel_search_max_parallelism(
    *,
    folder_count: int,
) -> int:
    return max(1, min(DEFAULT_PRIORS_PARALLEL_SEARCH_MAX_PARALLELISM, folder_count or 1))


def _parallel_search_kwargs(
    *,
    store: PriorStore,
    processed_context: str,
    base_path: str,
    ignore_prior_ids: list[str],
    latency_tier: str,
    max_parallelism: int,
    snapshot,
) -> dict[str, Any]:
    return {
        "store": store,
        "processed_context": processed_context,
        "root_path": base_path,
        "ignore_prior_ids": ignore_prior_ids,
        "summary_only": _use_summary_only_selection(latency_tier),
        "max_parallelism": max_parallelism,
        "tier": _selection_infer_tier(latency_tier),
        "reasoning_effort": _selection_reasoning_effort(latency_tier),
        "snapshot": snapshot,
    }


async def async_retrieve_relevant_priors_for_scope(
    *,
    store: PriorStore,
    raw_context: str,
    base_path: str = "",
    ignore_prior_ids: list[str] | None = None,
    latency_tier: str = DEFAULT_PRIORS_LATENCY_TIER,
) -> PriorRetrieval:
    total_started_at = time.perf_counter()
    raw_context = normalize_raw_context(raw_context)
    ignore_ids = [prior_id for prior_id in (ignore_prior_ids or []) if prior_id]
    ignore_id_set = set(ignore_ids)
    inherited_prior_rows = await asyncio.to_thread(_load_prior_rows, store, ignore_ids)
    snapshot = await asyncio.to_thread(store.get_snapshot, base_path)
    folder_priors = snapshot.folder_priors
    prior_count = len(snapshot.prior_rows)
    available_prior_count = (
        prior_count
        if not ignore_id_set
        else sum(
            1
            for priors in folder_priors.values()
            for prior in priors
            if str(prior.id or "") not in ignore_id_set
        )
    )

    if available_prior_count == 0:
        applied_rows = list(inherited_prior_rows)
        _log_retrieval_timings(
            total_started_at,
            pipeline="skipped_no_candidate_priors",
            latency_tier=latency_tier,
            raw_context_chars=len(raw_context or ""),
            processed_context_chars=1,
            preprocess_ms=0,
            prior_count=prior_count,
            available_prior_count=available_prior_count,
            direct_parallel_used=False,
            parallel_search_ms=0,
            effective_parallelism=0,
            hybrid_ms=0,
            candidate_count=0,
            rerank_ms=0,
            reranked_count=0,
            filtered_count=0,
            selection_ms=0,
            selection_candidate_count=0,
            selected_count=0,
            retrieved_count=0,
            applied_count=len(applied_rows),
        )
        return _complete_prior_retrieval(
            raw_context=raw_context,
            processed_context="-",
            latency_tier=latency_tier,
            model_used="",
            retrieved_priors=[],
            applied_priors=applied_rows,
        )

    preprocess_started_at = time.perf_counter()
    processed_context = await asyncio.to_thread(
        preprocess_context,
        raw_context=raw_context,
        latency_tier=latency_tier,
    )
    preprocess_ms = int((time.perf_counter() - preprocess_started_at) * 1000)
    model_used = ""

    retrieved_rows: list[dict[str, Any]]
    retrieval_pipeline = "low_hybrid"
    hybrid_ms = 0
    rerank_ms = 0
    selection_ms = 0
    selection_candidate_count = 0
    filtered_count = 0
    candidate_ids: list[str] = []
    reranked_ids: list[str] = []
    parallel_search_ms = 0
    direct_parallel_used = False
    effective_parallelism = 0

    if latency_tier == "LOW":
        model_used = resolve_model(None, "reranker")
        corpus = await asyncio.to_thread(store.get_corpus, base_path)
        prior_count = len(corpus.prior_rows)
        hybrid_started_at = time.perf_counter()
        candidate_ids = await asyncio.to_thread(_hybrid_candidate_ids, corpus, processed_context)
        hybrid_ms = int((time.perf_counter() - hybrid_started_at) * 1000)
        rerank_started_at = time.perf_counter()
        reranked_ids = await asyncio.to_thread(
            _rerank_candidates, corpus, processed_context, candidate_ids
        )
        rerank_ms = int((time.perf_counter() - rerank_started_at) * 1000)
        filtered_ids = _filter_candidate_ids(reranked_ids, ignore_id_set)
        filtered_count = len(filtered_ids)
        retrieved_rows = _candidate_rows_from_ids(corpus, filtered_ids[:TOPK])
    else:
        direct_parallel_used = prior_count < PARALLEL_SEARCH_DIRECT_PRIOR_THRESHOLD
        model_used = resolve_model(None, _selection_infer_tier(latency_tier))
        effective_parallelism = _effective_parallel_search_max_parallelism(
            folder_count=len(folder_priors),
        )
        parallel_kwargs = _parallel_search_kwargs(
            store=store,
            processed_context=processed_context,
            base_path=base_path,
            ignore_prior_ids=ignore_ids,
            latency_tier=latency_tier,
            max_parallelism=effective_parallelism,
            snapshot=snapshot,
        )
        if direct_parallel_used:
            retrieval_pipeline = "parallel_search"
            parallel_search_started_at = time.perf_counter()
            parallel_result = await parallel_search(
                candidate_prior_ids=None,
                **parallel_kwargs,
            )
            parallel_search_ms = int((time.perf_counter() - parallel_search_started_at) * 1000)
            selection_candidate_count = prior_count
            retrieved_rows = list(parallel_result.selected_priors)
        else:
            retrieval_pipeline = "hybrid_rerank_parallel_search"
            corpus = await asyncio.to_thread(store.get_corpus, base_path)
            hybrid_started_at = time.perf_counter()
            candidate_ids = await asyncio.to_thread(
                _hybrid_candidate_ids, corpus, processed_context
            )
            hybrid_ms = int((time.perf_counter() - hybrid_started_at) * 1000)
            rerank_started_at = time.perf_counter()
            reranked_ids = await asyncio.to_thread(
                _rerank_candidates, corpus, processed_context, candidate_ids
            )
            rerank_ms = int((time.perf_counter() - rerank_started_at) * 1000)
            filtered_ids = _filter_candidate_ids(reranked_ids, ignore_id_set)
            filtered_count = len(filtered_ids)
            selection_candidate_ids = filtered_ids[:LOOSE_TOPK]
            selection_candidate_count = len(selection_candidate_ids)
            parallel_search_started_at = time.perf_counter()
            parallel_result = await parallel_search(
                candidate_prior_ids=selection_candidate_ids,
                **parallel_kwargs,
            )
            parallel_search_ms = int((time.perf_counter() - parallel_search_started_at) * 1000)
            selection_ms = parallel_search_ms
            retrieved_rows = list(parallel_result.selected_priors)

    applied_rows = _merge_prior_rows(inherited_prior_rows, retrieved_rows)
    _log_retrieval_timings(
        total_started_at,
        pipeline=retrieval_pipeline,
        latency_tier=latency_tier,
        raw_context_chars=len(raw_context or ""),
        processed_context_chars=len(processed_context or ""),
        preprocess_ms=preprocess_ms,
        prior_count=prior_count,
        direct_parallel_used=direct_parallel_used,
        parallel_search_ms=parallel_search_ms,
        effective_parallelism=effective_parallelism,
        hybrid_ms=hybrid_ms,
        candidate_count=len(candidate_ids),
        rerank_ms=rerank_ms,
        reranked_count=len(reranked_ids),
        filtered_count=filtered_count,
        selection_ms=selection_ms,
        selection_candidate_count=selection_candidate_count,
        selected_count=len(retrieved_rows),
        retrieved_count=len(retrieved_rows),
        applied_count=len(applied_rows),
    )
    return _complete_prior_retrieval(
        raw_context=raw_context,
        processed_context=processed_context,
        latency_tier=latency_tier,
        model_used=model_used,
        retrieved_priors=retrieved_rows,
        applied_priors=applied_rows,
    )


def retrieve_relevant_priors_for_scope(
    *,
    store: PriorStore,
    raw_context: str,
    base_path: str = "",
    ignore_prior_ids: list[str] | None = None,
    latency_tier: str = DEFAULT_PRIORS_LATENCY_TIER,
) -> PriorRetrieval:
    """Synchronous compatibility wrapper for direct callers/tests.

    The production server path should await `async_retrieve_relevant_priors_for_scope`
    directly to avoid creating a fresh event loop per retrieval.
    """
    return asyncio.run(
        async_retrieve_relevant_priors_for_scope(
            store=store,
            raw_context=raw_context,
            base_path=base_path,
            ignore_prior_ids=ignore_prior_ids,
            latency_tier=latency_tier,
        )
    )
