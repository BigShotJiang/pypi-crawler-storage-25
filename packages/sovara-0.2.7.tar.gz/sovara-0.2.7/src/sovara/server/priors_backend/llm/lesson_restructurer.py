"""LLM-based prior restructuring using the internal structured LLM bridge."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Optional

from sovara.server.priors_backend.tools.folder_groups import build_folder_tree_summary, collect_folder_priors
from sovara.server.priors_backend.llm_client import infer_structured_json
from sovara.server.priors_backend.logger import logger
from sovara.server.priors_backend.path_utils import join_path as _join_path
from sovara.server.priors_backend.path_utils import normalize_path as _normalize_path

_RESTRUCTURE_RESPONSE_SCHEMA = {
    "type": "json_schema",
    "json_schema": {
        "name": "prior_restructure",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "summary": {"type": "string"},
                "new_folders": {"type": "array", "items": {"type": "string"}},
                "removed_folders": {"type": "array", "items": {"type": "string"}},
                "moves": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "prior_id": {"type": "string"},
                            "current_path": {"type": "string"},
                            "new_path": {"type": "string"},
                        },
                        "required": ["prior_id", "current_path", "new_path"],
                        "additionalProperties": False,
                    },
                },
                "redundant_prior_ids": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["summary", "new_folders", "removed_folders", "moves", "redundant_prior_ids"],
            "additionalProperties": False,
        },
    },
}


@dataclass
class PriorMove:
    prior_id: str
    current_path: str
    new_path: str


@dataclass
class RestructureProposal:
    summary: str
    new_folders: list[str]
    removed_folders: list[str]
    moves: list[PriorMove]
    redundant_prior_ids: list[str]

def _normalize_target_path(base_path: str, proposed_path: str) -> str:
    return _join_path(base_path, proposed_path)


def _compute_snapshot(all_priors: dict[str, dict]) -> str:
    items = sorted(all_priors.items())
    parts = []
    for prior_id, prior in items:
        parts.append(f"{prior_id}:{prior.get('path', '')}:{prior.get('title') or prior.get('name', '')}")
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:16]


def normalize_restructure_proposal(
    proposal: RestructureProposal,
    *,
    all_priors: dict[str, dict],
    base_path: str = "",
) -> RestructureProposal:
    current_paths = {prior_id: str(prior.get("path") or "") for prior_id, prior in all_priors.items()}
    normalized_base_path = _normalize_path(base_path)

    new_folders = sorted(
        {
            normalized_folder
            for folder in proposal.new_folders
            for normalized_folder in [_normalize_target_path(normalized_base_path, folder)]
            if normalized_folder and normalized_folder != normalized_base_path
        }
    )
    removed_folders = sorted(
        {
            normalized_folder
            for folder in proposal.removed_folders
            for normalized_folder in [_normalize_target_path(normalized_base_path, folder)]
            if normalized_folder and normalized_folder != normalized_base_path
        }
    )

    normalized_moves: list[PriorMove] = []
    seen_moves: set[tuple[str, str]] = set()
    for move in proposal.moves:
        if move.prior_id not in all_priors:
            continue
        current_path = current_paths.get(move.prior_id, "")
        normalized_new_path = _normalize_target_path(normalized_base_path, move.new_path)
        if normalized_new_path == current_path:
            continue
        move_key = (move.prior_id, normalized_new_path)
        if move_key in seen_moves:
            continue
        seen_moves.add(move_key)
        normalized_moves.append(
            PriorMove(
                prior_id=move.prior_id,
                current_path=current_path,
                new_path=normalized_new_path,
            )
        )

    redundant_prior_ids = [prior_id for prior_id in proposal.redundant_prior_ids if prior_id in all_priors]

    return RestructureProposal(
        summary=proposal.summary,
        new_folders=new_folders,
        removed_folders=removed_folders,
        moves=normalized_moves,
        redundant_prior_ids=redundant_prior_ids,
    )


async def propose_restructure(
    store,
    base_path: str = "",
    comments: Optional[str] = None,
) -> tuple[RestructureProposal, str, dict[str, dict]]:
    folder_priors, all_priors = collect_folder_priors(store, base_path)
    if not all_priors:
        return (
            RestructureProposal(
                summary="No priors found to restructure.",
                new_folders=[],
                removed_folders=[],
                moves=[],
                redundant_prior_ids=[],
            ),
            _compute_snapshot(all_priors),
            all_priors,
        )

    folder_tree = build_folder_tree_summary(store, base_path)
    snapshot = _compute_snapshot(all_priors)

    prior_lines = []
    for prior_id, prior in sorted(all_priors.items()):
        aliases = ", ".join(str(alias) for alias in (prior.get("aliases") or []))
        keywords = ", ".join(str(keyword) for keyword in (prior.get("keywords") or []))
        prior_lines.append(
            f"- ID: {prior_id} | Path: {prior.get('path', '(root)')} | "
            f"Title: {prior.get('title') or prior.get('name', '')} | Summary: {prior.get('summary', '')} | "
            f"When to use: {prior.get('when_to_use', '')} | Aliases: {aliases} | Keywords: {keywords}"
        )

    prompt = (
        "Analyze the following prior collection and propose a better folder structure.\n\n"
        f"BASE PATH TO REBALANCE:\n{base_path or '(root)'}\n\n"
        f"CURRENT FOLDER TREE:\n{folder_tree}\n\n"
        f"PRIORS:\n{chr(10).join(prior_lines)}\n\n"
        "Propose a restructured folder organization. For each prior that should move, specify the move.\n"
        "Keep all proposed folders and moves inside the provided base path.\n"
        "Prefer a shallow natural taxonomy based on titles, summaries, when-to-use guidance, aliases, and keywords.\n"
        "Mark redundant priors that could potentially be deleted after human review."
    )
    if comments:
        prompt += f"\n\nUSER GUIDANCE:\n{comments}"

    result = await infer_structured_json(
        tier="expensive",
        response_format=_RESTRUCTURE_RESPONSE_SCHEMA,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a prior taxonomy expert. Group priors semantically, minimize churn, "
                    "and prefer a shallow but meaningful folder hierarchy."
                ),
            },
            {"role": "user", "content": prompt},
        ],
        reasoning_effort="low",
        timeout_ms=30000,
        repair_attempts=2,
    )
    parsed = result["parsed"]
    proposal = RestructureProposal(
        summary=parsed["summary"],
        new_folders=list(parsed["new_folders"]),
        removed_folders=list(parsed["removed_folders"]),
        moves=[PriorMove(**move) for move in parsed["moves"]],
        redundant_prior_ids=list(parsed["redundant_prior_ids"]),
    )
    logger.info(
        "Restructure proposal for '%s': %s moves, %s new folders, %s redundant",
        base_path or "(root)",
        len(proposal.moves),
        len(proposal.new_folders),
        len(proposal.redundant_prior_ids),
    )
    return proposal, snapshot, all_priors


async def execute_restructure(store, proposal: RestructureProposal, expected_snapshot: str, base_path: str = "") -> dict:
    with store.locked_scope():
        _, all_priors = collect_folder_priors(store, base_path)
        current_snapshot = _compute_snapshot(all_priors)
        if current_snapshot != expected_snapshot:
            raise ValueError(
                f"Priors have changed since the proposal was generated. Expected snapshot {expected_snapshot}, got {current_snapshot}."
            )

        created_folders: set[str] = set()
        moved_count = 0
        move_log: list[dict] = []

        for folder in proposal.new_folders:
            try:
                store.create_folder(folder)
            except FileExistsError:
                pass
            created_folders.add(folder)

        for move in proposal.moves:
            if move.new_path and move.new_path not in created_folders:
                try:
                    store.create_folder(move.new_path)
                except FileExistsError:
                    pass
                created_folders.add(move.new_path)
            result = store.move_lessons([move.prior_id], move.new_path)
            if result.get("moved_count", 0) > 0:
                moved_count += 1
                move_log.append(
                    {
                        "prior_id": move.prior_id,
                        "from": move.current_path,
                        "to": move.new_path,
                    }
                )

    return {
        "status": "completed",
        "moved_count": moved_count,
        "created_folders": sorted(created_folders),
        "move_log": move_log,
    }
