"""LLM-backed priors operations."""
