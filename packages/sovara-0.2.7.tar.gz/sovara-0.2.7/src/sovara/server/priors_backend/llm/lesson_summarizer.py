"""LLM-based prior metadata generation with a safe local fallback."""

from __future__ import annotations

import re
from dataclasses import dataclass

from sovara.server.priors_backend.llm_client import infer_structured_json
from sovara.server.priors_backend.logger import logger


@dataclass(frozen=True)
class PriorGeneratedMetadata:
    summary: str
    when_to_use: str
    aliases: list[str]
    keywords: list[str]


_SUMMARY_RESPONSE_SCHEMA = {
    "type": "json_schema",
    "json_schema": {
        "name": "prior_summary",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "summary": {"type": "string"},
            },
            "required": ["summary"],
            "additionalProperties": False,
        },
    },
}

_METADATA_RESPONSE_SCHEMA = {
    "type": "json_schema",
    "json_schema": {
        "name": "prior_metadata",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "summary": {"type": "string"},
                "when_to_use": {"type": "string"},
                "aliases": {
                    "type": "array",
                    "items": {"type": "string"},
                },
                "keywords": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
            "required": ["summary", "when_to_use", "aliases", "keywords"],
            "additionalProperties": False,
        },
    },
}


def _strip_markdown(text: str) -> str:
    text = re.sub(r"```.*?```", " ", text, flags=re.DOTALL)
    text = re.sub(r"`([^`]*)`", r"\1", text)
    text = re.sub(r"^#{1,6}\s*", "", text, flags=re.MULTILINE)
    text = re.sub(r"[*_>#-]+", " ", text)
    text = re.sub(r"\[[^\]]+\]\([^)]+\)", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _normalize_string_list(values: object) -> list[str]:
    if not isinstance(values, list):
        return []

    normalized: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not isinstance(value, str):
            continue
        item = value.strip()
        key = item.casefold()
        if not item or key in seen:
            continue
        seen.add(key)
        normalized.append(item)
    return normalized


def fallback_prior_summary(*, title: str | None = None, name: str | None = None, content: str) -> str:
    resolved_title = (title or name or "").strip() or "this prior"
    cleaned = _strip_markdown(content)
    if not cleaned:
        return f"Prior for {resolved_title}."
    sentence = re.split(r"(?<=[.!?])\s+", cleaned, maxsplit=1)[0].strip()
    candidate = sentence or cleaned
    if len(candidate) <= 180:
        return candidate
    return candidate[:177].rstrip() + "..."


def fallback_prior_when_to_use(*, title: str | None = None, name: str | None = None, content: str) -> str:
    resolved_title = (title or name or "").strip() or "this prior"
    cleaned = _strip_markdown(content)
    if cleaned:
        sentence = re.split(r"(?<=[.!?])\s+", cleaned, maxsplit=1)[0].strip()
        if sentence.lower().startswith("when "):
            candidate = sentence
            return candidate if len(candidate) <= 220 else candidate[:217].rstrip() + "..."
    return f"When the task or query is about {resolved_title}."


def fallback_prior_metadata(*, title: str, content: str) -> PriorGeneratedMetadata:
    return PriorGeneratedMetadata(
        summary=fallback_prior_summary(title=title, content=content),
        when_to_use=fallback_prior_when_to_use(title=title, content=content),
        aliases=[],
        keywords=[],
    )


async def generate_prior_metadata(
    *,
    title: str,
    content: str,
    path: str,
) -> PriorGeneratedMetadata:
    system_prompt = """You write compact metadata for priors.

Return:
- summary: one short sentence capturing the main guidance in the prior
- when_to_use: a short retrieval-oriented description of the situations, task intents, or query patterns where this prior should be applied
- aliases: alternate phrasings, abbreviations, and synonymous query forms
- keywords: high-signal lexical terms for BM25 and keyword search

Requirements:
- Keep everything concise, concrete, and faithful to the prior
- Make when_to_use useful for retrieval; describe the kinds of queries or tasks that should trigger this prior
- Good patterns for when_to_use include phrasing like "When the query asks about ...", "When the task is to ...", or "When working with ..."
- Prefer terms a user would literally type into search
- Include domain terminology, error names, APIs, protocols, tools, and abbreviations when relevant
- Do not stuff the lists with weak variants
- Use empty arrays only when there truly are no useful aliases or keywords
- Do not mention formatting, markdown, or file names"""

    user_prompt = f"""Generate metadata for this prior.

Title: {title}
Path: {path or "(root)"}
Content:
{content}
"""

    try:
        result = await infer_structured_json(
            tier="cheap",
            response_format=_METADATA_RESPONSE_SCHEMA,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            timeout_ms=15000,
            repair_attempts=2,
        )
        parsed = result["parsed"]
        summary = str(parsed["summary"]).strip()
        when_to_use = str(parsed["when_to_use"]).strip()
        metadata = PriorGeneratedMetadata(
            summary=summary or fallback_prior_summary(title=title, content=content),
            when_to_use=when_to_use or fallback_prior_when_to_use(title=title, content=content),
            aliases=_normalize_string_list(parsed.get("aliases")),
            keywords=_normalize_string_list(parsed.get("keywords")),
        )
        return metadata
    except Exception as exc:
        logger.warning("Prior metadata generation failed: %s", exc)
        return fallback_prior_metadata(title=title, content=content)


async def generate_prior_summary(
    *,
    name: str,
    content: str,
    path: str,
) -> str:
    metadata = await generate_prior_metadata(title=name, content=content, path=path)
    return metadata.summary
