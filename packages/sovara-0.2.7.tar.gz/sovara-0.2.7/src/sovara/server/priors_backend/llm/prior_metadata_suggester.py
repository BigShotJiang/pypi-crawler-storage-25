"""LLM-powered suggestions for editable prior metadata fields."""

from __future__ import annotations

from typing import Any, Literal

from sovara.server.priors_backend.llm.lesson_summarizer import fallback_prior_when_to_use
from sovara.server.priors_backend.llm_client import infer_structured_json
from sovara.server.priors_backend.logger import logger

PriorSuggestionField = Literal[
    "when_to_use",
    "consequence_if_not_followed",
    "non_adherence_severity",
]


def _normalize_optional_text(value: Any) -> str | None:
    text = str(value or "").strip()
    return text or None


def _coerce_suggested_severity(value: Any, *, default: int = 5) -> int:
    try:
        severity = int(value)
    except (TypeError, ValueError):
        severity = default
    return max(1, min(10, severity))


def _fallback_consequence_if_not_followed(*, title: str) -> str:
    resolved_title = title.strip() or "this prior"
    return f"Violating {resolved_title} can lead to an incorrect or lower-quality final answer."


def _field_response_format(field: PriorSuggestionField) -> dict[str, Any]:
    value_schema = {"type": "integer"} if field == "non_adherence_severity" else {"type": "string"}
    return {
        "type": "json_schema",
        "json_schema": {
            "name": f"prior_{field}_suggestion",
            "strict": True,
            "schema": {
                "type": "object",
                "properties": {
                    field: value_schema,
                },
                "required": [field],
                "additionalProperties": False,
            },
        },
    }


def _system_prompt(field: PriorSuggestionField) -> str:
    if field == "when_to_use":
        return """You improve the retrieval applicability field for a prior.

Return a single concise string for when_to_use.

Requirements:
- Describe the kinds of tasks, intents, or queries that should trigger this prior
- Prefer phrasing like "When the task is to ...", "When the query asks about ...", or "When working with ..."
- Optimize for retrieval usefulness, not prose style
- If a draft value is provided, improve it when useful, but ignore it if it is weak, vague, or wrong
- Keep it concrete and faithful to the prior"""
    if field == "consequence_if_not_followed":
        return """You improve the failure-mode field for a prior.

Return a single concise string for consequence_if_not_followed.

Requirements:
- Describe the concrete failure mode if the prior is relevant but violated
- Focus on what can go wrong in the final output or behavior
- Keep it specific and practical
- If a draft value is provided, improve it when useful, but ignore it if it is weak, vague, or wrong"""
    return """You score the non-adherence severity for a prior.

Return a single integer from 1 to 10 for non_adherence_severity.

Requirements:
- Score how bad it is if the prior is relevant and violated
- 1 means minor quality loss
- 10 means severe correctness or behavior failure
- Be conservative but meaningful
- If a draft value is provided, improve it when useful, but ignore it if it is weak, vague, or wrong"""


def _draft_context(*, saved_value: Any, draft_value: Any) -> str:
    saved_text = _normalize_optional_text(saved_value)
    draft_text = _normalize_optional_text(draft_value)
    if draft_text and draft_text != saved_text:
        return (
            f"Saved value: {saved_text or '(empty)'}\n"
            f"Current draft value: {draft_text}\n"
            "Treat the current draft value as a possible rough draft to improve if it is useful."
        )
    return f"Current saved value: {saved_text or '(empty)'}"


async def suggest_prior_field(
    *,
    field: PriorSuggestionField,
    title: str,
    content: str,
    path: str,
    saved_value: Any = None,
    draft_value: Any = None,
) -> str | int:
    user_prompt = f"""Suggest a value for {field} for this prior.

Title: {title}
Path: {path or "(root)"}
Content:
{content}

Current field context:
{_draft_context(saved_value=saved_value, draft_value=draft_value)}
"""
    try:
        result = await infer_structured_json(
            tier="expensive",
            reasoning_effort="low",
            response_format=_field_response_format(field),
            messages=[
                {"role": "system", "content": _system_prompt(field)},
                {"role": "user", "content": user_prompt},
            ],
            timeout_ms=20000,
            repair_attempts=2,
        )
        value = result["parsed"][field]
        if field == "non_adherence_severity":
            return _coerce_suggested_severity(value)
        text = str(value).strip()
        if text:
            return text
    except Exception as exc:
        logger.warning("Prior field suggestion failed field=%s: %s", field, exc)

    if field == "when_to_use":
        return fallback_prior_when_to_use(title=title, content=content)
    if field == "consequence_if_not_followed":
        return _fallback_consequence_if_not_followed(title=title)
    return 5
