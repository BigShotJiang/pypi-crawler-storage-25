"""Background folder rebalancer for oversized prior folders."""

from __future__ import annotations

import asyncio
import json
import os
import tempfile
import threading
from collections import deque
from datetime import datetime, timezone
from typing import Any

from sovara.server.database import DB
from sovara.server.priors_backend.constants import DEFAULT_PRIORS_REBALANCE_FOLDER_THRESHOLD
from sovara.server.priors_backend.events import publish
from sovara.server.priors_backend.llm.lesson_restructurer import (
    execute_restructure,
    normalize_restructure_proposal,
    propose_restructure,
)
from sovara.server.priors_backend.logger import logger
from sovara.server.priors_backend.path_utils import normalize_path as _normalize_path
from sovara.server.priors_backend.path_utils import path_depth as _path_depth
from sovara.server.priors_backend.path_utils import path_within_root as _path_within_root
from sovara.server.priors_backend.storage import PriorSnapshot, PriorStore

_REBALANCE_STATE_FILENAME = ".rebalance_state.json"
_REBALANCE_POLL_SECONDS = 1.0
_worker_lock = threading.Lock()
_worker_stop = threading.Event()
_worker_thread: threading.Thread | None = None
_queue_condition = threading.Condition(threading.RLock())
_queued_jobs: deque[tuple[str, str, str]] = deque()
_queued_job_keys: set[tuple[str, str, str]] = set()
_active_job_keys: set[tuple[str, str, str]] = set()


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _rebalance_state_path(store: PriorStore) -> str:
    return os.path.join(store.base, _REBALANCE_STATE_FILENAME)


def _read_rebalance_state(store: PriorStore) -> dict[str, Any]:
    path = _rebalance_state_path(store)
    try:
        with open(path, encoding="utf-8") as handle:
            data = json.load(handle)
    except FileNotFoundError:
        return {}
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _write_rebalance_state(store: PriorStore, state: dict[str, Any]) -> None:
    path = _rebalance_state_path(store)
    fd, tmp = tempfile.mkstemp(dir=store.base, prefix=f"{_REBALANCE_STATE_FILENAME}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(state, handle, ensure_ascii=False, indent=2, sort_keys=True)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _record_rebalance_snapshot(
    store: PriorStore,
    *,
    base_path: str,
    snapshot_hash: str,
    status: str,
    moved_count: int = 0,
) -> None:
    state = _read_rebalance_state(store)
    state[_normalize_path(base_path)] = {
        "snapshot_hash": snapshot_hash,
        "status": status,
        "moved_count": moved_count,
        "updated_at": _utc_now_iso(),
    }
    _write_rebalance_state(store, state)


def _snapshot_already_processed(store: PriorStore, *, base_path: str, snapshot_hash: str) -> bool:
    entry = _read_rebalance_state(store).get(_normalize_path(base_path))
    return isinstance(entry, dict) and str(entry.get("snapshot_hash") or "") == snapshot_hash


def _oversized_folder_paths(
    snapshot: PriorSnapshot,
    *,
    root_paths: list[str],
    threshold: int = DEFAULT_PRIORS_REBALANCE_FOLDER_THRESHOLD,
) -> list[str]:
    normalized_roots = sorted(
        {_normalize_path(path) for path in root_paths},
        key=lambda value: (_path_depth(value), value),
    )
    return sorted(
        [
            folder_path
            for folder_path, priors in snapshot.folder_priors.items()
            if len(priors) > threshold and any(_path_within_root(folder_path, root_path) for root_path in normalized_roots)
        ],
        key=lambda path: (_path_depth(path), path),
    )


def ensure_folder_rebalance_worker_started() -> None:
    global _worker_thread
    with _worker_lock:
        if _worker_thread is not None and _worker_thread.is_alive():
            return
        _worker_stop.clear()
        _worker_thread = threading.Thread(
            target=_folder_rebalance_worker,
            name="sovara-folder-rebalance",
            daemon=True,
        )
        _worker_thread.start()


def shutdown_folder_rebalance_worker() -> None:
    _worker_stop.set()
    with _queue_condition:
        _queue_condition.notify_all()
    thread = _worker_thread
    if thread is not None and thread.is_alive():
        thread.join(timeout=2.0)


def request_folder_rebalance(user_id: str, project_id: str, base_path: str = "") -> bool:
    job_key = (user_id, project_id, _normalize_path(base_path))
    with _queue_condition:
        if job_key in _queued_job_keys or job_key in _active_job_keys:
            return False
        _queued_jobs.append(job_key)
        _queued_job_keys.add(job_key)
        _queue_condition.notify()
    return True


def enqueue_folder_rebalances_if_needed(
    store: PriorStore,
    root_paths: list[str],
    *,
    threshold: int = DEFAULT_PRIORS_REBALANCE_FOLDER_THRESHOLD,
) -> list[str]:
    snapshot = store.get_snapshot()
    oversized = _oversized_folder_paths(snapshot, root_paths=root_paths, threshold=threshold)
    if not oversized:
        return []
    ensure_folder_rebalance_worker_started()
    scheduled = [
        path
        for path in oversized
        if request_folder_rebalance(store.user_id, store.project_id, path)
    ]
    if scheduled:
        logger.info(
            "Queued folder rebalance | %s",
            json.dumps(
                {
                    "user_id": store.user_id,
                    "project_id": store.project_id,
                    "paths": scheduled,
                    "threshold": threshold,
                },
                ensure_ascii=False,
                sort_keys=True,
            ),
        )
    return scheduled


def _process_folder_rebalance_job(job: tuple[str, str, str]) -> dict[str, Any]:
    user_id, project_id, root_path = job
    store = PriorStore(user_id, project_id)
    with store.locked_tree(root_path):
        snapshot = store.get_snapshot()
        oversized_paths = _oversized_folder_paths(snapshot, root_paths=[root_path])
        if not oversized_paths:
            return {"status": "skipped", "reason": "no_oversized_folders", "root_path": root_path}

        target_path = oversized_paths[0]
        proposal, expected_snapshot, all_priors = asyncio.run(
            propose_restructure(
                store,
                base_path=target_path,
                comments=(
                    "Rebalance this folder into a natural, shallow taxonomy. "
                    "Only reorganize priors inside the provided base path. "
                    "Interpret any new folder names as children of that base path. "
                    "Prefer moving only the priors directly in this area; minimize churn."
                ),
            )
        )
        if len(all_priors) <= DEFAULT_PRIORS_REBALANCE_FOLDER_THRESHOLD:
            return {"status": "skipped", "reason": "below_threshold", "root_path": root_path, "target_path": target_path}
        if _snapshot_already_processed(store, base_path=target_path, snapshot_hash=expected_snapshot):
            return {"status": "skipped", "reason": "snapshot_already_processed", "root_path": root_path, "target_path": target_path}

        proposal = normalize_restructure_proposal(proposal, all_priors=all_priors, base_path=target_path)

        if not proposal.moves:
            _record_rebalance_snapshot(
                store,
                base_path=target_path,
                snapshot_hash=expected_snapshot,
                status="no_moves",
                moved_count=0,
            )
            logger.info(
                "Folder rebalance skipped with no valid moves | %s",
                json.dumps(
                    {
                        "user_id": user_id,
                        "project_id": project_id,
                        "root_path": root_path,
                        "target_path": target_path,
                    },
                    ensure_ascii=False,
                    sort_keys=True,
                ),
            )
            return {"status": "skipped", "reason": "no_valid_moves", "root_path": root_path, "target_path": target_path}

        result = asyncio.run(execute_restructure(store, proposal, expected_snapshot, base_path=target_path))
        moved_count = int(result.get("moved_count") or 0)
        _record_rebalance_snapshot(
            store,
            base_path=target_path,
            snapshot_hash=expected_snapshot,
            status="complete" if moved_count else "no_moves",
            moved_count=moved_count,
        )
        if moved_count <= 0:
            return {"status": "skipped", "reason": "no_moves_applied", "root_path": root_path, "target_path": target_path}

        DB.clear_scope_prefix_cache(user_id=user_id, project_id=project_id)
        scope = store.bump_scope_revision()
        publish(
            "folder_rebalanced",
            {
                "path": target_path,
                "moved_count": moved_count,
                "revision": scope["revision"],
            },
        )
        logger.info(
            "Folder rebalance complete | %s",
            json.dumps(
                {
                    "user_id": user_id,
                    "project_id": project_id,
                    "root_path": root_path,
                    "target_path": target_path,
                    "moved_count": moved_count,
                    "revision": scope["revision"],
                },
                ensure_ascii=False,
                sort_keys=True,
            ),
        )
        return {
            "status": "complete",
            "root_path": root_path,
            "target_path": target_path,
            "moved_count": moved_count,
            "reschedule_paths": _oversized_folder_paths(store.get_snapshot(), root_paths=[root_path]),
        }


def _folder_rebalance_worker() -> None:
    while not _worker_stop.is_set():
        with _queue_condition:
            while not _queued_jobs and not _worker_stop.is_set():
                _queue_condition.wait(timeout=_REBALANCE_POLL_SECONDS)
            if _worker_stop.is_set():
                return
            job = _queued_jobs.popleft()
            _queued_job_keys.discard(job)
            _active_job_keys.add(job)
        try:
            result = _process_folder_rebalance_job(job)
        except Exception:
            logger.exception("Folder rebalance worker failed for %s", job)
            result = {}
        finally:
            with _queue_condition:
                _active_job_keys.discard(job)
                _queue_condition.notify_all()
        reschedule_paths = result.get("reschedule_paths") if isinstance(result, dict) else None
        if isinstance(reschedule_paths, list):
            user_id, project_id, _root_path = job
            for path in reschedule_paths:
                request_folder_rebalance(user_id, project_id, str(path or ""))
