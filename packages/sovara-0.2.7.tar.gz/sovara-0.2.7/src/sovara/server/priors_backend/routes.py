"""Public priors API and shared priors service helpers."""

from __future__ import annotations

import asyncio
import json
import uuid
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any, List, Literal, Optional
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel, Field

from sovara.common.priors_block import render_priors_block
from sovara.server.priors_backend.events import publish, subscribe
from sovara.server.priors_backend.storage import PriorStore
from sovara.server.llm_backend import resolve_model
from sovara.server.priors_scope import resolve_priors_scope_from_request
from sovara.server.priors_backend.constants import (
    DEFAULT_PRIORS_REBALANCE_FOLDER_THRESHOLD,
)
from sovara.server.priors_backend.llm.lesson_restructurer import (
    PriorMove,
    RestructureProposal,
    execute_restructure,
    normalize_restructure_proposal,
    propose_restructure,
)
from sovara.server.priors_backend.llm.lesson_retriever import (
    async_retrieve_relevant_priors_for_scope as retrieve_relevant_priors_for_scope,
)
from sovara.server.priors_backend.llm.lesson_summarizer import (
    fallback_prior_summary,
    generate_prior_metadata,
)
from sovara.server.priors_backend.llm.prior_metadata_suggester import (
    suggest_prior_field,
)
from sovara.server.priors_backend.llm.folder_rebalancer import enqueue_folder_rebalances_if_needed
from sovara.server.priors_backend.llm.lesson_validator import validate_prior
from sovara.server.priors_backend.logger import logger
from sovara.server.priors_backend.path_utils import (
    InvalidPathError,
    normalize_suggested_path as _normalize_suggested_path,
    validate_relative_path,
)
from sovara.server.priors_backend import retrieval_service
from sovara.server.priors_backend.retrieval_service import PriorRetrieveResponse
from sovara.server.priors_backend.tools.folder_groups import (
    build_folder_tree_summary,
    collect_folder_priors,
)
from sovara.server.database import DB

router = APIRouter(prefix="/api/v1")
_RETRIEVAL_DEMO_USER_ID = "e17941ff-83e7-4d9b-bc2d-683b0ad8a9f4"
_RETRIEVAL_DEMO_PROJECT_ID = "a64584f1-90de-41b6-8c73-9ce5529eee82"
_RETRIEVAL_DEMO_BASE_PATH = ""
_RETRIEVAL_DEMO_IGNORE_PRIOR_IDS = ["06c6a2df", "0a30220f", "11f3b73d"]
_RETRIEVAL_DEMO_CONTEXT_PATH = (
    Path(__file__).resolve().parents[4] / "tests" / "data" / "retrieval_demo_context2.json"
)
_IN_FLIGHT_RETRIEVALS_LOCK = retrieval_service._IN_FLIGHT_RETRIEVALS_LOCK
_IN_FLIGHT_RETRIEVALS = retrieval_service._IN_FLIGHT_RETRIEVALS


def _normalize_path(path: str) -> str:
    try:
        return validate_relative_path(path)
    except InvalidPathError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


def _validation_to_feedback(validation) -> dict:
    path_assessment = None
    if validation.path_assessment:
        path_assessment = {
            "path_is_correct": validation.path_assessment.path_is_correct,
            "suggested_path": _normalize_suggested_path(validation.path_assessment.suggested_path),
        }
    conflict_details = [
        {
            "prior_id": detail.prior_id,
            "conflict_type": detail.conflict_type,
            "run_id": detail.run_id,
        }
        for detail in validation.conflict_details
    ]
    return {
        "feedback": validation.feedback,
        "severity": validation.severity,
        "conflicting_prior_ids": validation.conflicting_prior_ids,
        "path_assessment": path_assessment,
        "conflict_details": conflict_details,
    }


def _suggested_path_for_root_creation(validation, requested_path: str) -> str:
    if requested_path:
        return ""
    path_assessment = getattr(validation, "path_assessment", None)
    if path_assessment is None or path_assessment.path_is_correct:
        return ""
    return _normalize_suggested_path(path_assessment.suggested_path)


def _root_creation_rejection(reason_path: str) -> tuple[str, str]:
    return (
        f"Creating this prior at '(root)' is not allowed because validation suggested the more specific folder '{reason_path}'.",
        f"Retry with path '{reason_path}' or use force=true query parameter to keep it at root.",
    )


def _validate_required_prior_fields(
    *,
    when_to_use: str,
    consequence_if_not_followed: str,
    non_adherence_severity: int | None,
) -> None:
    missing: list[str] = []
    if not when_to_use.strip():
        missing.append("when_to_use")
    if not consequence_if_not_followed.strip():
        missing.append("consequence_if_not_followed")
    if non_adherence_severity is None:
        missing.append("non_adherence_severity")
    if missing:
        raise HTTPException(
            status_code=400,
            detail=f"Missing required prior fields: {', '.join(missing)}",
        )


def _normalize_string_list(values: object) -> list[str]:
    if not isinstance(values, list):
        return []

    normalized: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not isinstance(value, str):
            continue
        item = value.strip()
        key = item.casefold()
        if not item or key in seen:
            continue
        seen.add(key)
        normalized.append(item)
    return normalized


def _merge_string_lists(*groups: object) -> list[str]:
    merged: list[str] = []
    seen: set[str] = set()
    for group in groups:
        for item in _normalize_string_list(group):
            key = item.casefold()
            if key in seen:
                continue
            seen.add(key)
            merged.append(item)
    return merged


def _serialize_restructure_proposal(proposal: RestructureProposal) -> dict[str, Any]:
    return {
        "summary": proposal.summary,
        "new_folders": list(proposal.new_folders),
        "removed_folders": list(proposal.removed_folders),
        "moves": [
            {
                "prior_id": move.prior_id,
                "current_path": move.current_path,
                "new_path": move.new_path,
            }
            for move in proposal.moves
        ],
        "redundant_prior_ids": list(proposal.redundant_prior_ids),
    }


def _deserialize_restructure_proposal(payload: object) -> RestructureProposal:
    if not isinstance(payload, dict):
        raise HTTPException(
            status_code=400, detail="Restructure proposal payload is missing or invalid"
        )
    moves_payload = payload.get("moves") or []
    if not isinstance(moves_payload, list):
        raise HTTPException(status_code=400, detail="Restructure proposal moves are invalid")
    return RestructureProposal(
        summary=str(payload.get("summary") or ""),
        new_folders=[
            str(path) for path in (payload.get("new_folders") or []) if str(path or "").strip()
        ],
        removed_folders=[
            str(path) for path in (payload.get("removed_folders") or []) if str(path or "").strip()
        ],
        moves=[
            PriorMove(
                prior_id=str(move.get("prior_id") or ""),
                current_path=str(move.get("current_path") or ""),
                new_path=str(move.get("new_path") or ""),
            )
            for move in moves_payload
            if isinstance(move, dict) and str(move.get("prior_id") or "").strip()
        ],
        redundant_prior_ids=[
            str(prior_id)
            for prior_id in (payload.get("redundant_prior_ids") or [])
            if str(prior_id or "").strip()
        ],
    )


def _proposal_response_payload(
    *,
    task_id: str,
    base_path: str,
    snapshot: str,
    total_priors: int,
    proposal: RestructureProposal,
) -> dict[str, Any]:
    return {
        "status": "proposed",
        "task_id": task_id,
        "base_path": base_path,
        "snapshot": snapshot,
        "total_priors": total_priors,
        **_serialize_restructure_proposal(proposal),
    }


class PriorCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    content: str = Field(..., min_length=1)
    summary: Optional[str] = Field(None, min_length=1)
    path: str = ""
    run_id: UUID | None = None
    when_to_use: Optional[str] = None
    consequence_if_not_followed: Optional[str] = None
    non_adherence_severity: Optional[int] = Field(None, ge=1, le=10)
    aliases: list[str] = Field(default_factory=list)
    keywords: list[str] = Field(default_factory=list)
    related_priors: list[str] = Field(default_factory=list)


class PriorUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    content: Optional[str] = Field(None, min_length=1)
    path: Optional[str] = None
    run_id: UUID | None = None
    when_to_use: Optional[str] = None
    consequence_if_not_followed: Optional[str] = None
    non_adherence_severity: Optional[int] = Field(None, ge=1, le=10)
    aliases: list[str] | None = None
    keywords: list[str] | None = None
    related_priors: list[str] | None = None


class PriorDraftCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    content: str = Field(..., min_length=1)
    path: str = ""
    run_id: UUID | None = None
    when_to_use: Optional[str] = None
    consequence_if_not_followed: Optional[str] = None
    non_adherence_severity: Optional[int] = Field(None, ge=1, le=10)
    aliases: list[str] = Field(default_factory=list)
    keywords: list[str] = Field(default_factory=list)
    related_priors: list[str] = Field(default_factory=list)


class PriorSubmitRequest(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    content: Optional[str] = Field(None, min_length=1)
    path: Optional[str] = None
    run_id: UUID | None = None
    when_to_use: Optional[str] = None
    consequence_if_not_followed: Optional[str] = None
    non_adherence_severity: Optional[int] = Field(None, ge=1, le=10)
    aliases: list[str] | None = None
    keywords: list[str] | None = None
    related_priors: list[str] | None = None


class PriorSuggestFieldRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    content: str = Field(..., min_length=1)
    path: str = ""
    field: Literal["when_to_use", "consequence_if_not_followed", "non_adherence_severity"]
    saved_value: str | int | None = None
    draft_value: str | int | None = None


class PriorQueryRequest(BaseModel):
    path: Optional[str] = None


class PriorRebalanceRequest(BaseModel):
    path: str = ""


class PriorRestructureProposeRequest(BaseModel):
    base_path: str = ""
    comments: str | None = None


class PriorRestructureMove(BaseModel):
    prior_id: str
    current_path: str = ""
    new_path: str = ""


class PriorRestructureProposalResponse(BaseModel):
    status: Literal["proposed"]
    task_id: str
    base_path: str
    snapshot: str
    total_priors: int
    summary: str
    new_folders: list[str] = Field(default_factory=list)
    removed_folders: list[str] = Field(default_factory=list)
    moves: list[PriorRestructureMove] = Field(default_factory=list)
    redundant_prior_ids: list[str] = Field(default_factory=list)


class PriorRestructureExecuteRequest(BaseModel):
    task_id: str | None = None
    base_path: str | None = None
    snapshot: str | None = None
    new_folders: list[str] = Field(default_factory=list)
    moves: list[PriorRestructureMove] = Field(default_factory=list)


class PriorRestructureExecuteResponse(BaseModel):
    status: str
    task_id: str | None = None
    base_path: str
    snapshot: str
    moved_count: int = 0
    created_folders: list[str] = Field(default_factory=list)
    move_log: list[dict[str, str]] = Field(default_factory=list)
    revision: int | None = None


class PriorRestructureAbortRequest(BaseModel):
    task_id: str


class PriorRestructureAbortResponse(BaseModel):
    status: Literal["aborted"]
    task_id: str
    base_path: str


class FolderLsRequest(BaseModel):
    path: str = ""


class FolderCreateRequest(BaseModel):
    path: str


class FolderMoveRequest(BaseModel):
    path: str
    new_path: str


class FolderDeleteRequest(BaseModel):
    path: str


class PriorItemRef(BaseModel):
    kind: Literal["prior", "folder"]
    id: Optional[str] = None
    path: Optional[str] = None


class PriorItemsCopyRequest(BaseModel):
    items: list[PriorItemRef] = Field(default_factory=list)
    destination_path: str = ""
    as_draft: bool = False


class PriorItemsMoveRequest(BaseModel):
    items: list[PriorItemRef] = Field(default_factory=list)
    destination_path: str = ""


class PriorItemsDeleteRequest(BaseModel):
    items: list[PriorItemRef] = Field(default_factory=list)


class PriorRetrieveRequest(BaseModel):
    raw_context: str | None = Field(default=None, min_length=1)
    context: str | None = Field(default=None, min_length=1)
    base_path: str = ""
    ignore_prior_ids: list[str] = Field(default_factory=list)


class PrefixCacheLookupRequest(BaseModel):
    base_path: str = ""
    clean_pairs: list[dict[str, str]] = Field(default_factory=list)


class PrefixCacheStoreRequest(BaseModel):
    base_path: str = ""
    clean_pairs: list[dict[str, str]] = Field(default_factory=list)
    injected_pairs: list[dict[str, str]] = Field(default_factory=list)
    prior_ids: list[str] = Field(default_factory=list)


class PriorRebalanceResponse(BaseModel):
    status: Literal["queued", "skipped"]
    path: str
    queued_paths: list[str] = Field(default_factory=list)
    threshold: int = DEFAULT_PRIORS_REBALANCE_FOLDER_THRESHOLD
    reason: str | None = None


def _normalize_item_refs(items: list[PriorItemRef]) -> list[PriorItemRef]:
    normalized: list[PriorItemRef] = []
    seen: set[tuple[str, str]] = set()

    folder_paths = {
        _normalize_path(item.path or "") for item in items if item.kind == "folder" and item.path
    }

    for item in items:
        if item.kind == "prior":
            if not item.id:
                raise HTTPException(status_code=400, detail="Prior item is missing id")
            key = ("prior", item.id)
            if key in seen:
                continue
            seen.add(key)
            normalized.append(PriorItemRef(kind="prior", id=item.id))
            continue

        path = _normalize_path(item.path or "")
        if not path:
            raise HTTPException(status_code=400, detail="Folder item is missing path")
        if any(path != parent and path.startswith(parent) for parent in folder_paths):
            continue
        key = ("folder", path)
        if key in seen:
            continue
        seen.add(key)
        normalized.append(PriorItemRef(kind="folder", path=path))

    normalized.sort(key=lambda item: (item.kind != "folder", len((item.path or "").split("/"))))
    return normalized


def _copied_item_payload(item: dict, kind: Literal["prior", "folder"]) -> dict:
    if kind == "folder":
        path = item["path"]
        return {
            "kind": "folder",
            "path": path,
            "name": path.rstrip("/").split("/")[-1] if path else "",
        }
    return {
        "kind": "prior",
        "id": item["id"],
        "path": item["path"],
        "title": item["title"],
    }


def _active_only(priors: list[dict]) -> list[dict]:
    return [prior for prior in priors if prior.get("prior_status", "active") == "active"]


def _folder_contains_active_priors(store, path: str) -> bool:
    return any(
        prior.get("prior_status", "active") == "active"
        for prior in store.list_all(path=path, include_content=False)
    )


def _items_affect_active_world(store, items: list[PriorItemRef]) -> bool:
    for item in items:
        if item.kind == "prior":
            prior = store.get(item.id or "")
            if prior and prior.get("prior_status", "active") == "active":
                return True
            continue
        path = _normalize_path(item.path or "")
        if path and _folder_contains_active_priors(store, path):
            return True
    return False


def _get_prior_store_for_scope(user_id: str, project_id: str) -> PriorStore:
    return PriorStore(user_id, project_id)


def _resolve_store(
    request: Request,
    *,
    project_id: str | None = None,
) -> tuple[str, str, PriorStore]:
    user_id, resolved_project_id = resolve_priors_scope_from_request(request, project_id=project_id)
    return user_id, resolved_project_id, _get_prior_store_for_scope(user_id, resolved_project_id)


def _clear_scope_prefix_cache(user_id: str, project_id: str) -> None:
    DB.clear_scope_prefix_cache(user_id=user_id, project_id=project_id)


def _schedule_ui_priors_refresh(request: Request) -> None:
    state = getattr(request.app.state, "server_state", None)
    if state is not None:
        state.schedule_broadcast({"type": "priors_refresh"})


def _queue_folder_rebalances(store: PriorStore, *paths: str) -> None:
    normalized_paths = [
        path for path in (_normalize_path(path) for path in paths) if path or path == ""
    ]
    if not normalized_paths:
        return
    try:
        enqueue_folder_rebalances_if_needed(store, normalized_paths)
    except Exception:
        logger.exception("Failed to queue folder rebalance for paths=%s", normalized_paths)


def get_scope_metadata_for_scope(user_id: str, project_id: str) -> dict:
    store = _get_prior_store_for_scope(user_id, project_id)
    return store.read_scope_metadata()


def lookup_prefix_cache_for_scope(
    *,
    user_id: str,
    project_id: str,
    base_path: str = "",
    clean_pairs: list[dict[str, str]] | None = None,
) -> dict:
    normalized_base_path = _normalize_path(base_path)
    model_used = resolve_model(None, "cheap")
    match = DB.lookup_prefix_cache(
        user_id=user_id,
        project_id=project_id,
        base_path=normalized_base_path,
        model=model_used,
        clean_pairs=clean_pairs or [],
    )
    if match is None:
        return {"found": False}
    return {"found": True, **match}


def store_prefix_cache_for_scope(
    *,
    user_id: str,
    project_id: str,
    base_path: str = "",
    clean_pairs: list[dict[str, str]] | None = None,
    injected_pairs: list[dict[str, str]] | None = None,
    prior_ids: list[str] | None = None,
) -> dict:
    normalized_base_path = _normalize_path(base_path)
    model_used = resolve_model(None, "cheap")
    DB.store_prefix_cache(
        user_id=user_id,
        project_id=project_id,
        base_path=normalized_base_path,
        model=model_used,
        clean_pairs=clean_pairs or [],
        injected_pairs=injected_pairs or [],
        prior_ids=prior_ids or [],
    )
    return {"stored": True}


def query_priors_for_scope(
    *,
    user_id: str,
    project_id: str,
    path: str | None = None,
) -> dict:
    store = _get_prior_store_for_scope(user_id, project_id)
    normalized_path = _normalize_path(path) if path else ""
    if path is not None and not store.folder_exists(normalized_path):
        raise HTTPException(status_code=404, detail="Folder not found")
    priors = _active_only(
        store.list_all(path=normalized_path if path is not None else None, include_content=True)
    )
    return {
        "path": normalized_path,
        "priors": priors,
        "injected_context": render_priors_block(priors),
    }


async def retrieve_priors_for_scope(
    *,
    user_id: str,
    project_id: str,
    raw_context: str,
    base_path: str = "",
    run_id: str | None = None,
    ignore_prior_ids: list[str] | None = None,
    disconnect_checker: Callable[[], Awaitable[bool]] | None = None,
) -> dict:
    return await retrieval_service.retrieve_priors_for_scope(
        user_id=user_id,
        project_id=project_id,
        raw_context=raw_context,
        base_path=base_path,
        run_id=run_id,
        ignore_prior_ids=ignore_prior_ids,
        disconnect_checker=disconnect_checker,
        retriever=retrieve_relevant_priors_for_scope,
    )


@router.get("/priors/scope")
def get_scope(request: Request, project_id: str | None = Query(default=None)):
    user_id, resolved_project_id = resolve_priors_scope_from_request(request, project_id=project_id)
    return get_scope_metadata_for_scope(user_id, resolved_project_id)


@router.get("/info")
def info():
    return {
        "status": "bootstrapped",
        "service": "priors",
        "message": "Priors API is served directly by the main Sovara server.",
    }


@router.get("/events")
async def events():
    return await subscribe()


@router.post("/priors/prefix-cache/lookup")
def lookup_prefix_cache_endpoint(
    request: Request,
    body: PrefixCacheLookupRequest,
    project_id: str | None = Query(default=None),
):
    user_id, resolved_project_id = resolve_priors_scope_from_request(request, project_id=project_id)
    return lookup_prefix_cache_for_scope(
        user_id=user_id,
        project_id=resolved_project_id,
        base_path=body.base_path,
        clean_pairs=body.clean_pairs,
    )


@router.post("/priors/prefix-cache/store")
def store_prefix_cache_endpoint(
    request: Request,
    body: PrefixCacheStoreRequest,
    project_id: str | None = Query(default=None),
):
    user_id, resolved_project_id = resolve_priors_scope_from_request(request, project_id=project_id)
    return store_prefix_cache_for_scope(
        user_id=user_id,
        project_id=resolved_project_id,
        base_path=body.base_path,
        clean_pairs=body.clean_pairs,
        injected_pairs=body.injected_pairs,
        prior_ids=body.prior_ids,
    )


@router.get("/priors")
def list_priors(
    request: Request,
    path: Optional[str] = Query(default=None),
    project_id: str | None = Query(default=None),
):
    _user_id, _project_id, store = _resolve_store(request, project_id=project_id)
    priors = store.list_all(path=_normalize_path(path) if path else None, include_content=True)
    return {"priors": priors}


@router.get("/priors/{prior_id}")
def get_prior(request: Request, prior_id: str, project_id: str | None = Query(default=None)):
    _user_id, _project_id, store = _resolve_store(request, project_id=project_id)
    prior = store.get(prior_id)
    if prior is None:
        raise HTTPException(status_code=404, detail="Prior not found")
    return prior


@router.post("/query/priors")
def query_priors(
    request: Request, body: PriorQueryRequest, project_id: str | None = Query(default=None)
):
    user_id, resolved_project_id = resolve_priors_scope_from_request(request, project_id=project_id)
    return query_priors_for_scope(user_id=user_id, project_id=resolved_project_id, path=body.path)


@router.post("/priors/folders/rebalance", response_model=PriorRebalanceResponse)
def rebalance_priors_endpoint(
    request: Request,
    body: PriorRebalanceRequest,
    project_id: str | None = Query(default=None),
):
    _user_id, _project_id, store = _resolve_store(request, project_id=project_id)
    path = _normalize_path(body.path)
    if path and not store.folder_exists(path):
        raise HTTPException(status_code=404, detail="Folder not found")

    queued_paths = enqueue_folder_rebalances_if_needed(store, [path])
    response = {
        "status": "queued" if queued_paths else "skipped",
        "path": path,
        "queued_paths": queued_paths,
        "threshold": DEFAULT_PRIORS_REBALANCE_FOLDER_THRESHOLD,
        "reason": None if queued_paths else "no_oversized_folders",
    }
    logger.info(
        "Manual prior rebalance request | %s",
        json.dumps(
            {
                "user_id": store.user_id,
                "project_id": store.project_id,
                "path": path,
                "queued_paths": queued_paths,
            },
            ensure_ascii=False,
            sort_keys=True,
        ),
    )
    return response


@router.post("/priors/restructure/propose", response_model=PriorRestructureProposalResponse)
async def propose_priors_restructure_endpoint(
    request: Request,
    body: PriorRestructureProposeRequest,
    project_id: str | None = Query(default=None),
):
    _user_id, _project_id, store = _resolve_store(request, project_id=project_id)
    base_path = _normalize_path(body.base_path)
    task_id = uuid.uuid4().hex[:12]
    task_created = False

    try:
        with store.locked_tree(base_path, restructure_task_id=task_id):
            if base_path and not store.folder_exists(base_path):
                raise HTTPException(status_code=404, detail="Folder not found")
            store.create_restructure_task(
                task_id=task_id, base_path=base_path, comments=body.comments
            )
            task_created = True
            proposal, snapshot, all_priors = await propose_restructure(
                store,
                base_path=base_path,
                comments=body.comments,
            )
            proposal = normalize_restructure_proposal(
                proposal, all_priors=all_priors, base_path=base_path
            )
            store.update_restructure_task(
                task_id,
                snapshot=snapshot,
                proposal=_serialize_restructure_proposal(proposal),
                total_priors=len(all_priors),
            )
    except Exception:
        if task_created:
            store.delete_restructure_task(task_id)
        raise

    logger.info(
        "Proposed prior restructure | %s",
        json.dumps(
            {
                "user_id": store.user_id,
                "project_id": store.project_id,
                "task_id": task_id,
                "base_path": base_path,
                "move_count": len(proposal.moves),
                "new_folder_count": len(proposal.new_folders),
            },
            ensure_ascii=False,
            sort_keys=True,
        ),
    )
    return _proposal_response_payload(
        task_id=task_id,
        base_path=base_path,
        snapshot=snapshot,
        total_priors=len(all_priors),
        proposal=proposal,
    )


@router.post("/priors/restructure/execute", response_model=PriorRestructureExecuteResponse)
async def execute_priors_restructure_endpoint(
    request: Request,
    body: PriorRestructureExecuteRequest,
    project_id: str | None = Query(default=None),
):
    user_id, resolved_project_id, store = _resolve_store(request, project_id=project_id)
    stored_task = store.get_restructure_task(body.task_id) if body.task_id else None
    if body.task_id and stored_task is None:
        raise HTTPException(status_code=404, detail="Restructure task not found")

    base_path = (
        _normalize_path(body.base_path)
        if body.base_path is not None
        else _normalize_path(str((stored_task or {}).get("base_path") or ""))
    )
    if base_path and not store.folder_exists(base_path):
        raise HTTPException(status_code=404, detail="Folder not found")

    snapshot = str(body.snapshot or (stored_task or {}).get("snapshot") or "")
    if not snapshot:
        raise HTTPException(status_code=400, detail="snapshot is required")

    proposal_payload = (stored_task or {}).get("proposal")
    proposal = (
        _deserialize_restructure_proposal(proposal_payload)
        if proposal_payload is not None
        else RestructureProposal(
            summary="Manual prior restructure execution.",
            new_folders=[],
            removed_folders=[],
            moves=[],
            redundant_prior_ids=[],
        )
    )
    if body.new_folders:
        proposal.new_folders = [folder for folder in body.new_folders if str(folder or "").strip()]
    if body.moves:
        proposal.moves = [
            PriorMove(
                prior_id=move.prior_id,
                current_path=move.current_path,
                new_path=move.new_path,
            )
            for move in body.moves
        ]

    with store.locked_tree(base_path, restructure_task_id=body.task_id):
        _, all_priors = collect_folder_priors(store, base_path)
        proposal = normalize_restructure_proposal(
            proposal, all_priors=all_priors, base_path=base_path
        )
        result = await execute_restructure(store, proposal, snapshot, base_path=base_path)
        if body.task_id:
            store.delete_restructure_task(body.task_id)

    moved_count = int(result.get("moved_count") or 0)
    created_folders = list(result.get("created_folders") or [])
    revision = None
    if moved_count or created_folders:
        _clear_scope_prefix_cache(user_id, resolved_project_id)
        scope = store.bump_scope_revision()
        revision = int(scope["revision"])
        publish(
            "priors_restructured",
            {
                "task_id": body.task_id,
                "path": base_path,
                "moved_count": moved_count,
                "revision": revision,
            },
        )
        _schedule_ui_priors_refresh(request)

    logger.info(
        "Executed prior restructure | %s",
        json.dumps(
            {
                "user_id": store.user_id,
                "project_id": store.project_id,
                "task_id": body.task_id,
                "base_path": base_path,
                "moved_count": moved_count,
                "created_folder_count": len(created_folders),
                "revision": revision,
            },
            ensure_ascii=False,
            sort_keys=True,
        ),
    )
    return {
        **result,
        "task_id": body.task_id,
        "base_path": base_path,
        "snapshot": snapshot,
        "revision": revision,
    }


@router.post("/priors/restructure/abort", response_model=PriorRestructureAbortResponse)
def abort_priors_restructure_endpoint(
    request: Request,
    body: PriorRestructureAbortRequest,
    project_id: str | None = Query(default=None),
):
    _user_id, _project_id, store = _resolve_store(request, project_id=project_id)
    task = store.delete_restructure_task(body.task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Restructure task not found")
    base_path = _normalize_path(str(task.get("base_path") or ""))
    logger.info(
        "Aborted prior restructure | %s",
        json.dumps(
            {
                "user_id": store.user_id,
                "project_id": store.project_id,
                "task_id": body.task_id,
                "base_path": base_path,
            },
            ensure_ascii=False,
            sort_keys=True,
        ),
    )
    return {
        "status": "aborted",
        "task_id": body.task_id,
        "base_path": base_path,
    }


@router.post("/priors/folders/ls")
def folder_ls(
    request: Request, body: FolderLsRequest, project_id: str | None = Query(default=None)
):
    _user_id, _project_id, store = _resolve_store(request, project_id=project_id)
    path = _normalize_path(body.path)
    result = store.list_folders(path, include_content=False)
    return {
        "path": path,
        "folders": result["folders"],
        "priors": result["priors"],
        "prior_count": result["prior_count"],
    }


@router.post("/priors/folders")
def create_folder(
    request: Request, body: FolderCreateRequest, project_id: str | None = Query(default=None)
):
    user_id, resolved_project_id, store = _resolve_store(request, project_id=project_id)
    path = _normalize_path(body.path)
    if not path:
        raise HTTPException(status_code=400, detail="Folder path is required")
    try:
        result = store.create_folder(path)
    except FileExistsError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    publish("folder_created", {"path": path, "revision": None})
    _schedule_ui_priors_refresh(request)
    logger.info("Created prior folder '%s'", path)
    return {"status": "created", **result}


@router.put("/priors/folders")
def move_folder(
    request: Request, body: FolderMoveRequest, project_id: str | None = Query(default=None)
):
    user_id, resolved_project_id, store = _resolve_store(request, project_id=project_id)
    path = _normalize_path(body.path)
    new_path = _normalize_path(body.new_path)
    if not path or not new_path:
        raise HTTPException(status_code=400, detail="Both path and new_path are required")
    active_affected = _folder_contains_active_priors(store, path)

    try:
        result = store.move_folder(path, new_path)
    except FileExistsError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    if result is None:
        raise HTTPException(status_code=404, detail="Folder not found")

    revision = None
    if active_affected:
        _clear_scope_prefix_cache(user_id, resolved_project_id)
        scope = store.bump_scope_revision()
        revision = scope["revision"]
    publish("folder_moved", {"path": path, "new_path": new_path, "revision": revision})
    _schedule_ui_priors_refresh(request)
    if active_affected:
        _queue_folder_rebalances(store, new_path)
    logger.info("Moved prior folder '%s' -> '%s'", path, new_path)
    return {"status": "updated", "path": path, "new_path": new_path}


@router.post("/priors/folders/delete")
def delete_folder(
    request: Request, body: FolderDeleteRequest, project_id: str | None = Query(default=None)
):
    user_id, resolved_project_id, store = _resolve_store(request, project_id=project_id)
    path = _normalize_path(body.path)
    if not path:
        raise HTTPException(status_code=400, detail="Folder path is required")
    active_affected = _folder_contains_active_priors(store, path)
    if not store.delete_folder(path):
        raise HTTPException(status_code=404, detail="Folder not found")
    revision = None
    if active_affected:
        _clear_scope_prefix_cache(user_id, resolved_project_id)
        scope = store.bump_scope_revision()
        revision = scope["revision"]
    publish("folder_deleted", {"path": path, "revision": revision})
    _schedule_ui_priors_refresh(request)
    logger.info("Deleted prior folder '%s'", path)
    return {"status": "deleted", "path": path}


@router.post("/priors/items/copy")
def copy_items(
    request: Request, body: PriorItemsCopyRequest, project_id: str | None = Query(default=None)
):
    user_id, resolved_project_id, store = _resolve_store(request, project_id=project_id)
    destination_path = _normalize_path(body.destination_path)
    items = _normalize_item_refs(body.items)
    if not items:
        raise HTTPException(status_code=400, detail="At least one item is required")
    active_affected = (not body.as_draft) and _items_affect_active_world(store, items)

    copied_items: list[dict] = []
    for item in items:
        if item.kind == "prior":
            copied = store.copy_prior(item.id or "", destination_path, as_draft=body.as_draft)
            if copied is None:
                raise HTTPException(status_code=404, detail=f"Prior '{item.id}' not found")
            copied_items.append(_copied_item_payload(copied, "prior"))
            continue
        copied = store.copy_folder(item.path or "", destination_path, as_draft=body.as_draft)
        if copied is None:
            raise HTTPException(status_code=404, detail=f"Folder '{item.path}' not found")
        copied_items.append(_copied_item_payload(copied, "folder"))

    revision = None
    if active_affected:
        _clear_scope_prefix_cache(user_id, resolved_project_id)
        scope = store.bump_scope_revision()
        revision = scope["revision"]
    publish("items_copied", {"count": len(copied_items), "revision": revision})
    _schedule_ui_priors_refresh(request)
    if active_affected:
        _queue_folder_rebalances(store, *[str(item.get("path") or "") for item in copied_items])
    logger.info(
        "Copied %s prior items into '%s'%s",
        len(copied_items),
        destination_path,
        " as drafts" if body.as_draft else "",
    )
    return {"status": "copied", "items": copied_items, "count": len(copied_items)}


@router.post("/priors/drafts")
def create_prior_draft(
    request: Request, prior: PriorDraftCreate, project_id: str | None = Query(default=None)
):
    _user_id, _project_id, store = _resolve_store(request, project_id=project_id)
    path = _normalize_path(prior.path)
    prior_id = str(uuid.uuid4())[:8]
    result = store.create(
        prior_id,
        prior.title,
        "",
        prior.content,
        path,
        status="draft",
        run_id=str(prior.run_id) if prior.run_id else None,
        validation_metadata=None,
        when_to_use=(prior.when_to_use or "").strip(),
        consequence_if_not_followed=(prior.consequence_if_not_followed or "").strip(),
        non_adherence_severity=prior.non_adherence_severity,
        aliases=_normalize_string_list(prior.aliases),
        keywords=_normalize_string_list(prior.keywords),
        related_priors=_normalize_string_list(prior.related_priors),
    )
    publish("prior_created", {"id": prior_id, "path": path, "status": "draft"})
    _schedule_ui_priors_refresh(request)
    logger.info("Created draft prior %s at '%s'", prior_id, path)
    return {"status": "created", **result}


@router.post("/priors/suggest-field")
async def suggest_prior_metadata_field(
    request: Request,
    body: PriorSuggestFieldRequest,
    project_id: str | None = Query(default=None),
):
    _user_id, _project_id, _store = _resolve_store(request, project_id=project_id)
    suggestion = await suggest_prior_field(
        field=body.field,
        title=body.title,
        content=body.content,
        path=_normalize_path(body.path),
        saved_value=body.saved_value,
        draft_value=body.draft_value,
    )
    return {"field": body.field, "suggestion": suggestion}


@router.post("/priors/items/move")
def move_items(
    request: Request, body: PriorItemsMoveRequest, project_id: str | None = Query(default=None)
):
    user_id, resolved_project_id, store = _resolve_store(request, project_id=project_id)
    destination_path = _normalize_path(body.destination_path)
    items = _normalize_item_refs(body.items)
    if not items:
        raise HTTPException(status_code=400, detail="At least one item is required")
    active_affected = _items_affect_active_world(store, items)

    moved_items: list[dict] = []
    try:
        for item in items:
            if item.kind == "prior":
                result = store.move_lessons([item.id or ""], destination_path)
                if result["moved_count"] == 0:
                    raise HTTPException(status_code=404, detail=f"Prior '{item.id}' not found")
                moved = store.get(item.id or "")
                if moved:
                    moved_items.append(_copied_item_payload(moved, "prior"))
                continue

            moved = store.move_folder_to(item.path or "", destination_path)
            if moved is None:
                raise HTTPException(status_code=404, detail=f"Folder '{item.path}' not found")
            moved_items.append(_copied_item_payload(moved, "folder"))
    except FileExistsError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    revision = None
    if active_affected:
        _clear_scope_prefix_cache(user_id, resolved_project_id)
        scope = store.bump_scope_revision()
        revision = scope["revision"]
    publish("items_moved", {"count": len(moved_items), "revision": revision})
    _schedule_ui_priors_refresh(request)
    if active_affected:
        _queue_folder_rebalances(store, *[str(item.get("path") or "") for item in moved_items])
    logger.info("Moved %s prior items into '%s'", len(moved_items), destination_path)
    return {"status": "moved", "items": moved_items, "count": len(moved_items)}


@router.post("/priors/items/delete")
def delete_items(
    request: Request, body: PriorItemsDeleteRequest, project_id: str | None = Query(default=None)
):
    user_id, resolved_project_id, store = _resolve_store(request, project_id=project_id)
    items = _normalize_item_refs(body.items)
    if not items:
        raise HTTPException(status_code=400, detail="At least one item is required")
    active_affected = _items_affect_active_world(store, items)

    deleted_priors = 0
    deleted_folders = 0
    folder_items = sorted(
        [item for item in items if item.kind == "folder"],
        key=lambda item: len((_normalize_path(item.path or "")).split("/")),
        reverse=True,
    )
    prior_items = [item for item in items if item.kind == "prior"]

    for item in prior_items:
        deleted_priors += int(store.delete(item.id or ""))
    for item in folder_items:
        deleted_folders += int(store.delete_folder(item.path or ""))

    deleted = deleted_priors + deleted_folders

    if deleted == 0:
        raise HTTPException(status_code=404, detail="No matching priors or folders found")

    revision = None
    if active_affected:
        _clear_scope_prefix_cache(user_id, resolved_project_id)
        scope = store.bump_scope_revision()
        revision = scope["revision"]
    publish(
        "items_deleted",
        {
            "count": deleted,
            "prior_count": deleted_priors,
            "folder_count": deleted_folders,
            "revision": revision,
        },
    )
    logger.info(
        "Deleted %s prior items (%s priors, %s folders)",
        deleted,
        deleted_priors,
        deleted_folders,
    )
    _schedule_ui_priors_refresh(request)
    return {"status": "deleted", "count": deleted}


@router.post("/priors")
async def create_prior(
    request: Request,
    prior: PriorCreate,
    force: bool = Query(default=False),
    project_id: str | None = Query(default=None),
):
    user_id, resolved_project_id, store = _resolve_store(request, project_id=project_id)
    prior.path = _normalize_path(prior.path)
    requested_summary = (prior.summary or "").strip()
    requested_when_to_use = (prior.when_to_use or "").strip()
    requested_consequence = (prior.consequence_if_not_followed or "").strip()
    requested_aliases = _normalize_string_list(prior.aliases)
    requested_keywords = _normalize_string_list(prior.keywords)
    related_priors = _normalize_string_list(prior.related_priors)
    _validate_required_prior_fields(
        when_to_use=requested_when_to_use,
        consequence_if_not_followed=requested_consequence,
        non_adherence_severity=prior.non_adherence_severity,
    )
    summary_for_validation = requested_summary or fallback_prior_summary(
        title=prior.title, content=prior.content
    )

    existing_priors = _active_only(store.list_all(path=prior.path, include_content=not force))
    duplicates = [existing for existing in existing_priors if existing.get("title") == prior.title]
    if duplicates:
        duplicate_ids = [existing["id"] for existing in duplicates]
        return {
            "status": "rejected",
            "reason": (
                f"A prior titled '{prior.title}' already exists at path '{prior.path}' "
                f"(id: {', '.join(duplicate_ids)}). Update the existing prior instead."
            ),
            "conflicting_prior_ids": duplicate_ids,
            "hint": f"Use PUT /priors/{duplicate_ids[0]} to update the existing prior, or choose a different title.",
        }

    validation_feedback = None
    validation_metadata = None
    if not force:
        folder_tree = build_folder_tree_summary(store)
        validation = await validate_prior(
            title=prior.title,
            summary=summary_for_validation,
            content=prior.content,
            path=prior.path,
            existing_priors=existing_priors,
            folder_tree_summary=folder_tree,
        )
        validation_feedback = _validation_to_feedback(validation)
        validation_metadata = validation_feedback
        suggested_path = _suggested_path_for_root_creation(validation, prior.path)
        if suggested_path:
            reason, hint = _root_creation_rejection(suggested_path)
            return {
                "status": "rejected",
                "reason": reason,
                "validation": validation_feedback,
                "conflicting_prior_ids": validation.conflicting_prior_ids,
                "hint": hint,
            }
        if not validation.approved:
            return {
                "status": "rejected",
                "reason": validation.feedback,
                "validation": validation_feedback,
                "conflicting_prior_ids": validation.conflicting_prior_ids,
                "hint": "Use force=true query parameter to skip validation",
            }

    generated_metadata = await generate_prior_metadata(
        title=prior.title,
        content=prior.content,
        path=prior.path,
    )

    prior_id = str(uuid.uuid4())[:8]
    result = store.create(
        prior_id,
        prior.title,
        requested_summary or generated_metadata.summary,
        prior.content,
        prior.path,
        status="active",
        run_id=str(prior.run_id) if prior.run_id else None,
        validation_metadata=validation_metadata,
        when_to_use=requested_when_to_use,
        consequence_if_not_followed=requested_consequence,
        non_adherence_severity=prior.non_adherence_severity,
        aliases=_merge_string_lists(requested_aliases, generated_metadata.aliases),
        keywords=_merge_string_lists(requested_keywords, generated_metadata.keywords),
        related_priors=related_priors,
    )
    _clear_scope_prefix_cache(user_id, resolved_project_id)
    scope = store.bump_scope_revision()
    publish("prior_created", {"id": prior_id, "path": prior.path, "revision": scope["revision"]})
    _schedule_ui_priors_refresh(request)
    _queue_folder_rebalances(store, prior.path)
    logger.info("Created prior %s at '%s'", prior_id, prior.path)
    return {
        "status": "created",
        **result,
        "validation": validation_feedback,
    }


@router.post("/priors/{prior_id}/submit")
async def submit_prior(
    request: Request,
    prior_id: str,
    submission: PriorSubmitRequest,
    force: bool = Query(default=False),
    project_id: str | None = Query(default=None),
):
    user_id, resolved_project_id, store = _resolve_store(request, project_id=project_id)
    existing = store.get(prior_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="Prior not found")
    if existing.get("prior_status", "active") != "draft":
        raise HTTPException(status_code=400, detail="Only draft priors can be submitted")

    title = submission.title if submission.title is not None else existing["title"]
    content = submission.content if submission.content is not None else existing["content"]
    result_path = (
        _normalize_path(submission.path) if submission.path is not None else existing["path"]
    )
    run_id = str(submission.run_id) if submission.run_id is not None else existing.get("run_id")
    when_to_use = (
        submission.when_to_use.strip()
        if submission.when_to_use is not None
        else str(existing.get("when_to_use") or "")
    )
    consequence_if_not_followed = (
        submission.consequence_if_not_followed.strip()
        if submission.consequence_if_not_followed is not None
        else str(existing.get("consequence_if_not_followed") or "")
    )
    non_adherence_severity = (
        submission.non_adherence_severity
        if submission.non_adherence_severity is not None
        else existing.get("non_adherence_severity")
    )
    aliases = (
        _normalize_string_list(submission.aliases)
        if submission.aliases is not None
        else _normalize_string_list(existing.get("aliases"))
    )
    keywords = (
        _normalize_string_list(submission.keywords)
        if submission.keywords is not None
        else _normalize_string_list(existing.get("keywords"))
    )
    related_priors = (
        _normalize_string_list(submission.related_priors)
        if submission.related_priors is not None
        else _normalize_string_list(existing.get("related_priors"))
    )
    _validate_required_prior_fields(
        when_to_use=when_to_use,
        consequence_if_not_followed=consequence_if_not_followed,
        non_adherence_severity=non_adherence_severity,
    )

    active_priors = _active_only(store.list_all(path=result_path, include_content=not force))
    duplicates = [
        prior
        for prior in active_priors
        if prior.get("title") == title and prior.get("id") != prior_id
    ]
    if duplicates:
        duplicate_ids = [prior["id"] for prior in duplicates]
        rejection_feedback = {
            "feedback": (
                f"A prior titled '{title}' already exists at path '{result_path}' "
                f"(id: {', '.join(duplicate_ids)}). Choose a different title or update the existing active prior."
            ),
            "severity": "error",
            "conflicting_prior_ids": duplicate_ids,
        }
        result = store.update(
            prior_id,
            title,
            existing.get("summary", ""),
            content,
            path=result_path,
            run_id=run_id,
            status="draft",
            validation_metadata=rejection_feedback,
            when_to_use=when_to_use,
            consequence_if_not_followed=consequence_if_not_followed,
            non_adherence_severity=non_adherence_severity,
            aliases=aliases,
            keywords=keywords,
            related_priors=related_priors,
        )
        return {
            "status": "rejected",
            **(result or {}),
            "reason": rejection_feedback["feedback"],
            "validation": rejection_feedback,
            "conflicting_prior_ids": duplicate_ids,
            "hint": "Choose a different title or update the existing active prior instead.",
        }

    validation_feedback = None
    validation_metadata = None
    if not force:
        folder_tree = build_folder_tree_summary(store)
        validation = await validate_prior(
            title=title,
            summary=fallback_prior_summary(title=title, content=content),
            content=content,
            path=result_path,
            existing_priors=active_priors,
            existing_prior_id=prior_id,
            folder_tree_summary=folder_tree,
        )
        validation_feedback = _validation_to_feedback(validation)
        validation_metadata = validation_feedback
        suggested_path = _suggested_path_for_root_creation(validation, result_path)
        if suggested_path:
            reason, hint = _root_creation_rejection(suggested_path)
            result = store.update(
                prior_id,
                title,
                existing.get("summary", ""),
                content,
                path=result_path,
                run_id=run_id,
                status="draft",
                validation_metadata=validation_feedback,
                when_to_use=when_to_use,
                consequence_if_not_followed=consequence_if_not_followed,
                non_adherence_severity=non_adherence_severity,
                aliases=aliases,
                keywords=keywords,
                related_priors=related_priors,
            )
            return {
                "status": "rejected",
                **(result or {}),
                "reason": reason,
                "validation": validation_feedback,
                "conflicting_prior_ids": validation.conflicting_prior_ids,
                "hint": hint,
            }
        if not validation.approved:
            result = store.update(
                prior_id,
                title,
                existing.get("summary", ""),
                content,
                path=result_path,
                run_id=run_id,
                status="draft",
                validation_metadata=validation_feedback,
                when_to_use=when_to_use,
                consequence_if_not_followed=consequence_if_not_followed,
                non_adherence_severity=non_adherence_severity,
                aliases=aliases,
                keywords=keywords,
                related_priors=related_priors,
            )
            return {
                "status": "rejected",
                **(result or {}),
                "reason": validation.feedback,
                "validation": validation_feedback,
                "conflicting_prior_ids": validation.conflicting_prior_ids,
                "hint": "Address the validation feedback and submit again.",
            }

    generated_metadata = await generate_prior_metadata(
        title=title,
        content=content,
        path=result_path,
    )
    result = store.update(
        prior_id,
        title,
        generated_metadata.summary,
        content,
        path=result_path,
        run_id=run_id,
        status="active",
        validation_metadata=validation_metadata,
        when_to_use=when_to_use,
        consequence_if_not_followed=consequence_if_not_followed,
        non_adherence_severity=non_adherence_severity,
        aliases=_merge_string_lists(aliases, generated_metadata.aliases),
        keywords=_merge_string_lists(keywords, generated_metadata.keywords),
        related_priors=related_priors,
    )
    _clear_scope_prefix_cache(user_id, resolved_project_id)
    scope = store.bump_scope_revision()
    publish("prior_updated", {"id": prior_id, "path": result_path, "revision": scope["revision"]})
    _schedule_ui_priors_refresh(request)
    _queue_folder_rebalances(store, result_path)
    logger.info("Submitted draft prior %s", prior_id)
    return {
        "status": "submitted",
        **(result or {}),
        "validation": validation_feedback,
    }


@router.put("/priors/{prior_id}")
async def update_prior(
    request: Request,
    prior_id: str,
    update: PriorUpdate,
    force: bool = Query(default=False),
    project_id: str | None = Query(default=None),
):
    user_id, resolved_project_id, store = _resolve_store(request, project_id=project_id)
    existing = store.get(prior_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="Prior not found")

    existing_status = existing.get("prior_status", "active")
    title = update.title if update.title is not None else existing["title"]
    content = update.content if update.content is not None else existing["content"]
    result_path = _normalize_path(update.path) if update.path is not None else existing["path"]
    run_id = str(update.run_id) if update.run_id is not None else existing.get("run_id")
    when_to_use = (
        update.when_to_use.strip()
        if update.when_to_use is not None
        else str(existing.get("when_to_use") or "")
    )
    consequence_if_not_followed = (
        update.consequence_if_not_followed.strip()
        if update.consequence_if_not_followed is not None
        else str(existing.get("consequence_if_not_followed") or "")
    )
    non_adherence_severity = (
        update.non_adherence_severity
        if update.non_adherence_severity is not None
        else existing.get("non_adherence_severity")
    )
    aliases = (
        _normalize_string_list(update.aliases)
        if update.aliases is not None
        else _normalize_string_list(existing.get("aliases"))
    )
    keywords = (
        _normalize_string_list(update.keywords)
        if update.keywords is not None
        else _normalize_string_list(existing.get("keywords"))
    )
    related_priors = (
        _normalize_string_list(update.related_priors)
        if update.related_priors is not None
        else _normalize_string_list(existing.get("related_priors"))
    )
    if existing_status == "active":
        _validate_required_prior_fields(
            when_to_use=when_to_use,
            consequence_if_not_followed=consequence_if_not_followed,
            non_adherence_severity=non_adherence_severity,
        )
    title_changed = update.title is not None and update.title != existing["title"]
    content_changed = update.content is not None and update.content != existing["content"]
    summary_for_validation = existing["summary"] or fallback_prior_summary(
        title=title, content=content
    )

    validation_feedback = None
    validation_metadata = (
        None
        if force and content_changed and existing_status == "active"
        else existing.get("validation_metadata")
    )
    if content_changed and existing_status == "active" and not force:
        existing_with_content = _active_only(store.list_all(path=result_path, include_content=True))
        folder_tree = build_folder_tree_summary(store)
        validation = await validate_prior(
            title=title,
            summary=summary_for_validation,
            content=content,
            path=result_path,
            existing_priors=existing_with_content,
            existing_prior_id=prior_id,
            folder_tree_summary=folder_tree,
        )
        validation_feedback = _validation_to_feedback(validation)
        validation_metadata = validation_feedback
        if not validation.approved:
            return {
                "status": "rejected",
                "reason": validation.feedback,
                "validation": validation_feedback,
                "conflicting_prior_ids": validation.conflicting_prior_ids,
                "hint": "Use force=true query parameter to skip validation",
            }

    generated_metadata = None
    if existing_status == "active" and (content_changed or title_changed):
        generated_metadata = await generate_prior_metadata(
            title=title,
            content=content,
            path=result_path,
        )

    persisted_summary = (
        generated_metadata.summary
        if generated_metadata and content_changed
        else existing["summary"]
    )
    if generated_metadata:
        aliases = _merge_string_lists(aliases, generated_metadata.aliases)
        keywords = _merge_string_lists(keywords, generated_metadata.keywords)

    result = store.update(
        prior_id,
        title,
        persisted_summary,
        content,
        path=result_path if update.path is not None else None,
        run_id=run_id,
        status=existing_status,
        validation_metadata=validation_metadata,
        when_to_use=when_to_use,
        consequence_if_not_followed=consequence_if_not_followed,
        non_adherence_severity=non_adherence_severity,
        aliases=aliases,
        keywords=keywords,
        related_priors=related_priors,
    )
    revision = None
    if existing_status == "active":
        _clear_scope_prefix_cache(user_id, resolved_project_id)
        scope = store.bump_scope_revision()
        revision = scope["revision"]
    publish("prior_updated", {"id": prior_id, "path": result_path, "revision": revision})
    _schedule_ui_priors_refresh(request)
    if existing_status == "active" and result_path != existing["path"]:
        _queue_folder_rebalances(store, result_path)
    logger.info("Updated prior %s", prior_id)
    return {
        "status": "updated",
        **(result or {}),
        "validation": validation_feedback,
    }


@router.delete("/priors/{prior_id}")
def delete_prior(request: Request, prior_id: str, project_id: str | None = Query(default=None)):
    user_id, resolved_project_id, store = _resolve_store(request, project_id=project_id)
    existing = store.get(prior_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="Prior not found")
    if not store.delete(prior_id):
        raise HTTPException(status_code=404, detail="Prior not found")
    revision = None
    if existing.get("prior_status", "active") == "active":
        _clear_scope_prefix_cache(user_id, resolved_project_id)
        scope = store.bump_scope_revision()
        revision = scope["revision"]
    publish("prior_deleted", {"id": prior_id, "revision": revision})
    _schedule_ui_priors_refresh(request)
    logger.info("Deleted prior %s", prior_id)
    return {"status": "deleted", "id": prior_id}


@router.post("/priors/retrieve", response_model=PriorRetrieveResponse)
async def retrieve_priors_endpoint(
    request: Request,
    body: PriorRetrieveRequest,
    project_id: str | None = Query(default=None),
):
    user_id, resolved_project_id = resolve_priors_scope_from_request(request, project_id=project_id)
    response = await retrieve_priors_for_scope(
        user_id=user_id,
        project_id=resolved_project_id,
        raw_context=body.raw_context if body.raw_context is not None else (body.context or ""),
        base_path=body.base_path,
        ignore_prior_ids=body.ignore_prior_ids,
        disconnect_checker=request.is_disconnected,
    )
    return PriorRetrieveResponse(**response)


async def _run_retrieval_demo() -> int:
    if not _RETRIEVAL_DEMO_CONTEXT_PATH.is_file():
        raise FileNotFoundError(f"Context file not found: {_RETRIEVAL_DEMO_CONTEXT_PATH}")

    raw_context = _RETRIEVAL_DEMO_CONTEXT_PATH.read_text(encoding="utf-8")
    response = await retrieve_priors_for_scope(
        user_id=_RETRIEVAL_DEMO_USER_ID,
        project_id=_RETRIEVAL_DEMO_PROJECT_ID,
        raw_context=raw_context,
        base_path=_RETRIEVAL_DEMO_BASE_PATH,
        ignore_prior_ids=_RETRIEVAL_DEMO_IGNORE_PRIOR_IDS,
    )

    payload = {
        "context_path": str(_RETRIEVAL_DEMO_CONTEXT_PATH),
        "user_id": _RETRIEVAL_DEMO_USER_ID,
        "project_id": _RETRIEVAL_DEMO_PROJECT_ID,
        "base_path": _RETRIEVAL_DEMO_BASE_PATH,
        "ignore_prior_ids": _RETRIEVAL_DEMO_IGNORE_PRIOR_IDS,
        "latency_tier": response["latency_tier"],
        "retrieval_status": response["retrieval_status"],
        "coverage_status": response["coverage_status"],
        "prior_coverage": response.get("prior_coverage"),
        "prior_ids": [prior["id"] for prior in response.get("priors", [])],
        "applied_prior_ids": [prior["id"] for prior in response.get("applied_priors", [])],
        "model_used": response["model_used"],
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(_run_retrieval_demo()))
