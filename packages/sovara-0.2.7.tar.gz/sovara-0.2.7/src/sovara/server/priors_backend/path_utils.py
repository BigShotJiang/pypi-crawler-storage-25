"""Shared path helpers for the priors backend."""

from __future__ import annotations


class InvalidPathError(ValueError):
    """Raised when a client-provided priors path is invalid."""


def normalize_path(path: str) -> str:
    cleaned = (path or "").strip("/")
    return f"{cleaned}/" if cleaned else ""


def validate_relative_path(path: str) -> str:
    if not path:
        return ""
    if ".." in path:
        raise InvalidPathError("Path must not contain '..'")
    if path.startswith("/"):
        raise InvalidPathError("Path must not start with '/'")
    if "//" in path:
        raise InvalidPathError("Path must not contain '//'")
    for segment in path.rstrip("/").split("/"):
        if segment.startswith("."):
            raise InvalidPathError(f"Path segment '{segment}' must not start with '.'")
    return normalize_path(path)


def normalize_suggested_path(path: str | None) -> str:
    text = str(path or "").strip()
    if not text or text == "(root)":
        return ""
    if text.startswith("(root)/"):
        text = text[len("(root)/") :]
    try:
        return validate_relative_path(text)
    except InvalidPathError:
        return ""


def join_path(base_path: str, proposed_path: str) -> str:
    normalized_base_path = normalize_path(base_path)
    normalized_proposed_path = normalize_path(proposed_path)
    if not normalized_base_path:
        return normalized_proposed_path
    if not normalized_proposed_path:
        return normalized_base_path
    if normalized_proposed_path.startswith(normalized_base_path):
        return normalized_proposed_path
    return normalize_path(f"{normalized_base_path}{normalized_proposed_path.strip('/')}")


def path_depth(path: str) -> int:
    return len([segment for segment in normalize_path(path).strip("/").split("/") if segment])


def path_within_root(path: str, root_path: str) -> bool:
    normalized_path = normalize_path(path)
    normalized_root = normalize_path(root_path)
    return not normalized_root or normalized_path.startswith(normalized_root)
