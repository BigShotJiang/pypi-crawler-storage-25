"""Shared constants for the priors backend."""

from __future__ import annotations

import os
from typing import Literal

from sovara.common.constants import SOVARA_HOME

PRIORS_BACKEND_HOME = os.path.join(SOVARA_HOME, "priors")
PRIORS_BACKEND_INDEX_HOME = os.path.join(SOVARA_HOME, "priors_index")
SCOPE_METADATA_FILENAME = ".scope_metadata.json"

LatencyTier = Literal["LOW", "MEDIUM", "HIGH"]
LATENCY_TIERS: tuple[LatencyTier, ...] = ("LOW", "MEDIUM", "HIGH")
DEFAULT_PRIORS_LATENCY_TIER: LatencyTier = "MEDIUM"
DEFAULT_PRIORS_TRACK_GROUNDEDNESS = False
DEFAULT_PRIORS_TRACK_ADHERENCE = False

TOPK = 25
LOOSE_TOPK = 50
PRIORS_RETRIEVAL_MAX_TURNS = 5
PARALLEL_SEARCH_DIRECT_PRIOR_THRESHOLD = 300
DEFAULT_PRIORS_PARALLEL_SEARCH_ENABLED = True
DEFAULT_PRIORS_PARALLEL_SEARCH_MAX_PARALLELISM = 16
MAX_PRIORS_PARALLEL_SEARCH_MAX_PARALLELISM = 16
DEFAULT_PRIORS_REBALANCE_FOLDER_THRESHOLD = 20

PRIOR_COVERAGE_STATUSES: tuple[str, ...] = ("not_requested", "pending", "complete", "failed")
PRIOR_RETRIEVAL_STATUSES: tuple[str, ...] = ("pending", "complete", "failed")

DEFAULT_PRIORS_CACHE_MAX_BYTES_ENV = "SOVARA_PRIORS_CACHE_MAX_BYTES"
