"""Shared priors retrieval service logic."""

from __future__ import annotations

import asyncio
import inspect
import threading
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from fastapi import HTTPException
from pydantic import BaseModel, Field

from sovara.common.constants import INTERNAL_PRIORS_TIMEOUT_MS
from sovara.common.priors_block import render_priors_block
from sovara.common.utils import hash_input
from sovara.server.database import DB
from sovara.server.priors_backend.constants import (
    LOOSE_TOPK,
    PARALLEL_SEARCH_DIRECT_PRIOR_THRESHOLD,
    TOPK,
)
from sovara.server.priors_backend.llm.lesson_retriever import (
    async_retrieve_relevant_priors_for_scope,
)
from sovara.server.priors_backend.logger import logger
from sovara.server.priors_backend.path_utils import InvalidPathError, validate_relative_path
from sovara.server.priors_backend.storage import PriorStore
from sovara.server.priors_backend.tools.preprocess_context import normalize_raw_context

class RetrievedPrior(BaseModel):
    id: str
    title: str
    summary: str
    when_to_use: str = ""
    consequence_if_not_followed: str = ""
    non_adherence_severity: int | None = None
    content: str
    path: str


class PriorRetrieveResponse(BaseModel):
    raw_context: str
    processed_context: str
    base_path: str
    priors: list[RetrievedPrior]
    applied_priors: list[RetrievedPrior] = Field(default_factory=list)
    prior_count: int
    priors_revision: int
    rendered_priors_block: str
    model_used: str = ""
    latency_tier: str
    retrieval_id: str | None = None
    prior_coverage: int | None = None
    retrieval_status: str = "complete"
    coverage_status: str = "not_requested"


@dataclass(frozen=True, slots=True)
class _RetrievalSingleflightKey:
    user_id: str
    project_id: str
    priors_revision: int
    base_path: str
    model: str
    context_hash: str
    ignore_prior_ids: tuple[str, ...]


_IN_FLIGHT_RETRIEVALS_LOCK = threading.Lock()
_IN_FLIGHT_RETRIEVALS: dict[tuple[int, _RetrievalSingleflightKey], asyncio.Task[dict[str, Any]]] = {}


def _preview_log_context(value: str, limit: int = 4000) -> str:
    text = value or ""
    return text or "(empty)" if len(text) <= limit else f"{text[:limit]}... ({len(text) - limit} chars truncated)"


def _retrieved_prior_payload(prior: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": str(prior.get("id") or ""),
        "title": str(prior.get("title") or ""),
        "summary": str(prior.get("summary") or ""),
        "when_to_use": str(prior.get("when_to_use") or ""),
        "consequence_if_not_followed": str(prior.get("consequence_if_not_followed") or ""),
        "non_adherence_severity": prior.get("non_adherence_severity"),
        "content": str(prior.get("content") or ""),
        "path": str(prior.get("path") or ""),
    }


async def _invoke_retriever(fn, **kwargs):
    result = fn(**kwargs)
    return await result if inspect.isawaitable(result) else result


def _decode_cached_retrieval_response(cached: dict | None) -> dict[str, Any] | None:
    try:
        return None if cached is None else PriorRetrieveResponse.model_validate(cached).model_dump()
    except Exception:
        return None


def _ignored_applied_priors(ignore_prior_ids: list[str]) -> list[dict[str, str]]:
    return [{"id": prior_id} for prior_id in ignore_prior_ids]


def _finalize_retrieval_response(
    response: dict[str, Any],
    *,
    retrieval_id: str | None,
) -> dict[str, Any]:
    return {**response, "retrieval_id": retrieval_id, "coverage_status": "not_requested", "prior_coverage": None}


def _retrieval_cache_model_key(latency_tier: str) -> str:
    return (
        f"priors:v3:{latency_tier}:topk={TOPK}:loose={LOOSE_TOPK}:"
        f"threshold={PARALLEL_SEARCH_DIRECT_PRIOR_THRESHOLD}"
    )


def _make_retrieval_singleflight_key(
    *,
    user_id: str,
    project_id: str,
    priors_revision: int,
    base_path: str,
    model: str,
    raw_context: str,
    ignore_prior_ids: list[str] | None,
) -> _RetrievalSingleflightKey:
    return _RetrievalSingleflightKey(
        user_id=user_id,
        project_id=project_id,
        priors_revision=priors_revision,
        base_path=base_path,
        model=model,
        context_hash=hash_input(raw_context or ""),
        ignore_prior_ids=tuple(sorted({prior_id for prior_id in (ignore_prior_ids or []) if prior_id})),
    )


async def _persist_run_prior_retrieval(
    *,
    run_id: str | None,
    retrieval_id: str | None,
    raw_context: str,
    ignore_prior_ids: list[str],
    latency_tier: str,
    response: dict[str, Any] | None = None,
    retrieval_latency_ms: int | None = None,
    retrieval_status: str = "pending",
    error_message: str | None = None,
) -> str | None:
    if not run_id:
        return None

    payload = response or {}
    return await asyncio.to_thread(
        DB.upsert_prior_retrieval,
        run_id,
        None,
        retrieval_id=retrieval_id,
        raw_context=str(payload.get("raw_context") or raw_context),
        processed_context=str(payload.get("processed_context") or ""),
        inherited_prior_ids=ignore_prior_ids,
        retrieved_priors=payload.get("priors") or [],
        applied_priors=payload.get("applied_priors") or _ignored_applied_priors(ignore_prior_ids),
        rendered_priors_block=str(payload.get("rendered_priors_block") or ""),
        model=payload.get("model_used"),
        latency_tier=str(payload.get("latency_tier") or latency_tier),
        timeout_ms=INTERNAL_PRIORS_TIMEOUT_MS,
        retrieval_latency_ms=retrieval_latency_ms,
        prior_coverage=None,
        retrieval_status=str(payload.get("retrieval_status") or retrieval_status),
        coverage_status=str(
            payload.get("coverage_status")
            or ("failed" if retrieval_status == "failed" else "not_requested")
        ),
        error_message=error_message,
    )


async def _compute_cached_retrieval_response(
    *,
    store: PriorStore,
    retriever,
    raw_context: str,
    normalized_base_path: str,
    ignore_prior_ids: list[str],
    latency_tier: str,
    priors_revision: int,
    user_id: str,
    project_id: str,
    cache_model_key: str,
) -> dict[str, Any]:
    retrieval = await _invoke_retriever(
        retriever,
        store=store,
        raw_context=raw_context,
        base_path=normalized_base_path,
        ignore_prior_ids=ignore_prior_ids,
        latency_tier=latency_tier,
    )
    payload = PriorRetrieveResponse(
        raw_context=raw_context,
        processed_context=retrieval.processed_context,
        base_path=normalized_base_path,
        priors=[_retrieved_prior_payload(prior) for prior in retrieval.retrieved_priors],
        applied_priors=[
            _retrieved_prior_payload(prior)
            for prior in retrieval.applied_priors
            if all(key in prior for key in ("id", "title", "summary", "content", "path"))
        ],
        prior_count=len(retrieval.retrieved_priors),
        priors_revision=priors_revision,
        rendered_priors_block=render_priors_block(retrieval.retrieved_priors),
        model_used=retrieval.model_used or "",
        latency_tier=latency_tier,
        retrieval_id=None,
        prior_coverage=None,
        retrieval_status=retrieval.retrieval_status,
        coverage_status="not_requested",
    ).model_dump()
    logger.info(
        "[PRIORS ROUTE] retrieve complete prior_count=%s ids=%s rendered_block_chars=%d",
        payload["prior_count"],
        [prior["id"] for prior in payload["priors"]],
        len(payload["rendered_priors_block"]),
    )
    await asyncio.to_thread(
        DB.store_cached_retrieval,
        user_id=user_id,
        project_id=project_id,
        priors_revision=priors_revision,
        base_path=normalized_base_path,
        model=cache_model_key,
        context=raw_context,
        ignore_prior_ids=ignore_prior_ids,
        response=payload,
    )
    return payload


async def _await_shared_retrieval_response(
    *,
    store: PriorStore,
    retriever,
    raw_context: str,
    normalized_base_path: str,
    ignore_prior_ids: list[str],
    latency_tier: str,
    priors_revision: int,
    user_id: str,
    project_id: str,
    cache_model_key: str,
) -> dict[str, Any]:
    key = _make_retrieval_singleflight_key(
        user_id=user_id,
        project_id=project_id,
        priors_revision=priors_revision,
        base_path=normalized_base_path,
        model=cache_model_key,
        raw_context=raw_context,
        ignore_prior_ids=ignore_prior_ids,
    )
    loop = asyncio.get_running_loop()
    task_key = (id(loop), key)

    with _IN_FLIGHT_RETRIEVALS_LOCK:
        task = _IN_FLIGHT_RETRIEVALS.get(task_key)
    if task is not None:
        logger.info(
            "[PRIORS ROUTE] singleflight follower revision=%s base_path=%s tier=%s",
            priors_revision,
            normalized_base_path or "(root)",
            latency_tier,
        )
        return await asyncio.shield(task)

    cached = await asyncio.to_thread(
        DB.get_cached_retrieval,
        user_id=user_id,
        project_id=project_id,
        priors_revision=priors_revision,
        base_path=normalized_base_path,
        model=cache_model_key,
        context=raw_context,
        ignore_prior_ids=ignore_prior_ids,
    )
    cached_response = _decode_cached_retrieval_response(cached)
    if cached_response is not None:
        logger.info(
            "[PRIORS ROUTE] cache filled during singleflight wait revision=%s base_path=%s tier=%s",
            priors_revision,
            normalized_base_path or "(root)",
            latency_tier,
        )
        return cached_response

    with _IN_FLIGHT_RETRIEVALS_LOCK:
        task = _IN_FLIGHT_RETRIEVALS.get(task_key)
        if task is None:
            logger.info(
                "[PRIORS ROUTE] singleflight leader revision=%s base_path=%s tier=%s",
                priors_revision,
                normalized_base_path or "(root)",
                latency_tier,
            )
            task = loop.create_task(
                _compute_cached_retrieval_response(
                    store=store,
                    retriever=retriever,
                    raw_context=raw_context,
                    normalized_base_path=normalized_base_path,
                    ignore_prior_ids=ignore_prior_ids,
                    latency_tier=latency_tier,
                    priors_revision=priors_revision,
                    user_id=user_id,
                    project_id=project_id,
                    cache_model_key=cache_model_key,
                )
            )
            _IN_FLIGHT_RETRIEVALS[task_key] = task

            def _cleanup(done_task: asyncio.Task[dict[str, Any]]) -> None:
                with _IN_FLIGHT_RETRIEVALS_LOCK:
                    if _IN_FLIGHT_RETRIEVALS.get(task_key) is done_task:
                        _IN_FLIGHT_RETRIEVALS.pop(task_key, None)

            task.add_done_callback(_cleanup)
    return await asyncio.shield(task)


async def retrieve_priors_for_scope(
    *,
    user_id: str,
    project_id: str,
    raw_context: str,
    base_path: str = "",
    run_id: str | None = None,
    ignore_prior_ids: list[str] | None = None,
    disconnect_checker: Callable[[], Awaitable[bool]] | None = None,
    retriever=async_retrieve_relevant_priors_for_scope,
) -> dict[str, Any]:
    raw_context = normalize_raw_context(raw_context)
    store = PriorStore(user_id, project_id)
    try:
        normalized_base_path = validate_relative_path(base_path)
    except InvalidPathError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if base_path and not await asyncio.to_thread(store.folder_exists, normalized_base_path):
        raise HTTPException(status_code=404, detail="Folder not found")

    scope = await asyncio.to_thread(store.read_scope_metadata)
    priors_revision = int(scope["revision"])
    latency_tier = await asyncio.to_thread(DB.get_project_priors_latency_tier, project_id)
    cache_model_key = _retrieval_cache_model_key(latency_tier)
    ignore_ids = sorted({prior_id for prior_id in (ignore_prior_ids or []) if prior_id})
    retrieval_id: str | None = None

    logger.info(
        "[PRIORS ROUTE] retrieve start user=%s project=%s revision=%s base_path=%s tier=%s ignore_ids=%s\n"
        "[PRIORS ROUTE] context (%d chars):\n%s",
        scope["user_id"],
        scope["project_id"],
        priors_revision,
        normalized_base_path or "(root)",
        latency_tier,
        ignore_ids,
        len(raw_context or ""),
        _preview_log_context(raw_context or ""),
    )

    if run_id:
        retrieval_id = await _persist_run_prior_retrieval(
            run_id=run_id,
            retrieval_id=None,
            raw_context=raw_context,
            ignore_prior_ids=ignore_ids,
            latency_tier=latency_tier,
        )

    cached = await asyncio.to_thread(
        DB.get_cached_retrieval,
        user_id=str(scope["user_id"]),
        project_id=str(scope["project_id"]),
        priors_revision=priors_revision,
        base_path=normalized_base_path,
        model=cache_model_key,
        context=raw_context,
        ignore_prior_ids=ignore_prior_ids or [],
    )
    cached_response = _decode_cached_retrieval_response(cached)
    if cached_response is not None:
        response = _finalize_retrieval_response(cached_response, retrieval_id=retrieval_id)
        await _persist_run_prior_retrieval(
            run_id=run_id,
            retrieval_id=retrieval_id,
            raw_context=raw_context,
            ignore_prior_ids=ignore_ids,
            latency_tier=latency_tier,
            response=response,
            retrieval_latency_ms=0,
        )
        logger.info(
            "[PRIORS ROUTE] cache hit revision=%s base_path=%s tier=%s prior_count=%s ids=%s",
            priors_revision,
            normalized_base_path or "(root)",
            latency_tier,
            response.get("prior_count"),
            [prior.get("id") for prior in response.get("priors", [])],
        )
        return response

    logger.info(
        "[PRIORS ROUTE] cache miss revision=%s base_path=%s tier=%s",
        priors_revision,
        normalized_base_path or "(root)",
        latency_tier,
    )

    started_at = time.perf_counter()
    retrieve_task = asyncio.create_task(
        _await_shared_retrieval_response(
            store=store,
            retriever=retriever,
            raw_context=raw_context,
            normalized_base_path=normalized_base_path,
            ignore_prior_ids=ignore_prior_ids or [],
            latency_tier=latency_tier,
            priors_revision=priors_revision,
            user_id=str(scope["user_id"]),
            project_id=str(scope["project_id"]),
            cache_model_key=cache_model_key,
        )
    )

    wait_tasks = [retrieve_task]
    disconnect_task: asyncio.Task | None = None
    if disconnect_checker is not None:

        async def _wait_disconnect():
            while not await disconnect_checker():
                await asyncio.sleep(1)

        disconnect_task = asyncio.create_task(_wait_disconnect())
        wait_tasks.append(disconnect_task)

    done, pending = await asyncio.wait(wait_tasks, return_when=asyncio.FIRST_COMPLETED)
    for task in pending:
        task.cancel()

    if disconnect_task is not None and disconnect_task in done:
        elapsed_ms = int((time.perf_counter() - started_at) * 1000)
        await _persist_run_prior_retrieval(
            run_id=run_id,
            retrieval_id=retrieval_id,
            raw_context=raw_context,
            ignore_prior_ids=ignore_ids,
            latency_tier=latency_tier,
            retrieval_status="failed",
            error_message="Client disconnected during priors retrieval.",
        )
        logger.warning(
            "[PRIORS ROUTE] client disconnected during priors retrieval run_id=%s base_path=%s tier=%s elapsed_ms=%d",
            run_id or "-",
            normalized_base_path or "(root)",
            latency_tier,
            elapsed_ms,
        )
        raise asyncio.CancelledError()

    try:
        response = dict(retrieve_task.result())
    except Exception as exc:
        await _persist_run_prior_retrieval(
            run_id=run_id,
            retrieval_id=retrieval_id,
            raw_context=raw_context,
            ignore_prior_ids=ignore_ids,
            latency_tier=latency_tier,
            retrieval_status="failed",
            error_message=str(exc),
        )
        raise

    response = _finalize_retrieval_response(
        response,
        retrieval_id=retrieval_id,
    )
    await _persist_run_prior_retrieval(
        run_id=run_id,
        retrieval_id=retrieval_id,
        raw_context=raw_context,
        ignore_prior_ids=ignore_ids,
        latency_tier=latency_tier,
        response=response,
        retrieval_latency_ms=int((time.perf_counter() - started_at) * 1000),
    )
    return response
