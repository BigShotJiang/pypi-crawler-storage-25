"""Shared LLM bridge helpers used by priors retrieval and validation."""

from __future__ import annotations

import asyncio
import os
import threading
from collections import deque
from typing import Any, Optional

_async_global_prior_llm_semaphore: Optional["_AsyncGlobalSemaphore"] = None
_async_global_prior_llm_semaphore_limit: int | None = None
_async_global_prior_llm_semaphore_lock = threading.Lock()


class _AsyncGlobalSemaphore:
    """Async process-wide semaphore that can be awaited from multiple event loops."""

    def __init__(self, value: int) -> None:
        self._max_value = max(1, value)
        self._value = self._max_value
        self._waiters: deque[tuple[asyncio.AbstractEventLoop, asyncio.Future[None]]] = deque()
        self._lock = threading.Lock()

    async def __aenter__(self) -> "_AsyncGlobalSemaphore":
        await self.acquire()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        del exc_type, exc, tb
        self.release()

    async def acquire(self) -> None:
        loop = asyncio.get_running_loop()
        future: asyncio.Future[None] | None = None
        with self._lock:
            self._discard_done_waiters_locked()
            if self._value > 0:
                self._value -= 1
                return
            future = loop.create_future()
            self._waiters.append((loop, future))

        try:
            await future
        except BaseException:
            release_acquired_slot = False
            with self._lock:
                removed = self._remove_waiter_locked(future)
                if not removed and future.done() and not future.cancelled():
                    release_acquired_slot = True
            if release_acquired_slot:
                self.release()
            raise

    def release(self) -> None:
        with self._lock:
            self._discard_done_waiters_locked()
            while self._waiters:
                loop, future = self._waiters.popleft()
                if future.done() or future.cancelled():
                    continue
                try:
                    loop.call_soon_threadsafe(self._wake_waiter, future)
                except RuntimeError:
                    continue
                return
            if self._value >= self._max_value:
                raise ValueError("AsyncGlobalSemaphore released too many times")
            self._value += 1

    def _wake_waiter(self, future: asyncio.Future[None]) -> None:
        if future.done() or future.cancelled():
            self.release()
            return
        future.set_result(None)

    def _discard_done_waiters_locked(self) -> None:
        self._waiters = deque(
            (loop, future)
            for loop, future in self._waiters
            if not future.done() and not future.cancelled()
        )

    def _remove_waiter_locked(self, target: asyncio.Future[None]) -> bool:
        removed = False
        remaining: deque[tuple[asyncio.AbstractEventLoop, asyncio.Future[None]]] = deque()
        while self._waiters:
            loop, future = self._waiters.popleft()
            if future is target and not removed:
                removed = True
                continue
            remaining.append((loop, future))
        self._waiters = remaining
        return removed


def _get_max_concurrent() -> int:
    try:
        return max(1, int(os.environ.get("SOVARA_PRIORS_LLM_MAX_CONCURRENT", "20")))
    except ValueError:
        return 20


def _get_async_global_prior_llm_semaphore() -> _AsyncGlobalSemaphore:
    global _async_global_prior_llm_semaphore
    global _async_global_prior_llm_semaphore_limit
    max_concurrent = _get_max_concurrent()
    with _async_global_prior_llm_semaphore_lock:
        if (
            _async_global_prior_llm_semaphore is None
            or _async_global_prior_llm_semaphore_limit != max_concurrent
        ):
            _async_global_prior_llm_semaphore = _AsyncGlobalSemaphore(max_concurrent)
            _async_global_prior_llm_semaphore_limit = max_concurrent
        return _async_global_prior_llm_semaphore


def _run_infer_structured_json_without_threading_semaphore(
    messages: list[dict[str, Any]],
    tier: str,
    response_format: dict[str, Any],
    timeout_ms: int,
    repair_attempts: int,
    extra: dict[str, Any],
) -> dict[str, Any]:
    from sovara.server.llm_backend import infer_structured_json as _infer_structured_json

    return _infer_structured_json(
        messages,
        None,
        tier=tier,
        response_format=response_format,
        repair_attempts=repair_attempts,
        timeout=max(timeout_ms / 1000.0, 0.001),
        **extra,
    )


async def infer_structured_json(
    *,
    messages: list[dict[str, Any]],
    tier: str,
    response_format: dict[str, Any],
    timeout_ms: int = 30000,
    repair_attempts: int = 1,
    **extra: Any,
) -> dict[str, Any]:
    async with _get_async_global_prior_llm_semaphore():
        return await asyncio.to_thread(
            _run_infer_structured_json_without_threading_semaphore,
            messages,
            tier,
            response_format,
            timeout_ms,
            repair_attempts,
            dict(extra),
        )
