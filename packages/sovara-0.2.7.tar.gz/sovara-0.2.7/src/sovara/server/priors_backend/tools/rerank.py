"""Reranker tool for prior search."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Sequence

from sovara.server.llm_backend import rerank as llm_rerank

TOOL_DEFINITION = {
    "type": "function",
    "function": {
        "name": "rerank",
        "description": "Rerank a candidate set of priors against the retrieval context.",
        "parameters": {
            "type": "object",
            "properties": {
                "candidate_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                },
                "top_k": {"type": "integer"},
            },
            "required": ["candidate_ids"],
            "additionalProperties": False,
        },
    },
}


@dataclass(frozen=True)
class RerankCandidate:
    prior_id: str
    retrieval_text: str
    title: str = ""
    path: str = ""


def _result_items(response: object) -> list[Any]:
    items = getattr(response, "results", None)
    if items is None and isinstance(response, dict):
        items = response.get("results")
    return list(items or [])


def rerank(
    *,
    retrieval_context: str,
    candidates: Sequence[Any],
    top_k: int | None = None,
) -> list[dict[str, Any]]:
    candidate_list = list(candidates)
    if not candidate_list or not (retrieval_context or "").strip():
        return []

    response = llm_rerank(
        query=retrieval_context,
        documents=[candidate.retrieval_text for candidate in candidate_list],
        tier="reranker",
        top_n=top_k,
        return_documents=False,
    )
    ranked: list[dict[str, Any]] = []
    for item in _result_items(response):
        if isinstance(item, dict):
            index = int(item.get("index"))
            score = float(item.get("relevance_score") or item.get("score") or 0.0)
        else:
            index = int(getattr(item, "index"))
            score = float(getattr(item, "relevance_score", getattr(item, "score", 0.0)))
        if index < 0 or index >= len(candidate_list):
            continue
        candidate = candidate_list[index]
        ranked.append({"index": index, "prior_id": candidate.prior_id, "score": score})
    return ranked

