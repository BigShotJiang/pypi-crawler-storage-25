"""Dense retrieval tool for prior search."""

from __future__ import annotations

from typing import Any, Sequence

import numpy as np

from sovara.server.llm_backend import embed

TOOL_DEFINITION = {
    "type": "function",
    "function": {
        "name": "dense_search",
        "description": "Run dense vector retrieval over the prior corpus.",
        "parameters": {
            "type": "object",
            "properties": {
                "top_k": {"type": "integer"},
            },
            "additionalProperties": False,
        },
    },
}


def _embedding_vectors(response: object) -> np.ndarray:
    data = getattr(response, "data", None)
    if data is None and isinstance(response, dict):
        data = response.get("data")
    if isinstance(data, list):
        vectors: list[list[float]] = []
        for item in data:
            if isinstance(item, dict):
                vector = item.get("embedding")
            else:
                vector = getattr(item, "embedding", None)
            if isinstance(vector, list):
                vectors.append(vector)
        if vectors:
            return np.asarray(vectors, dtype=np.float32)

    embeddings = getattr(response, "embeddings", None)
    if embeddings is None and isinstance(response, dict):
        embeddings = response.get("embeddings")
    vectors = None
    if isinstance(embeddings, dict):
        vectors = embeddings.get("float")
    elif embeddings is not None:
        vectors = getattr(embeddings, "float_", None)
        if vectors is None:
            vectors = getattr(embeddings, "float", None)
    if isinstance(vectors, list):
        return np.asarray(vectors, dtype=np.float32)
    raise ValueError("embedding response did not contain usable vectors")


def _normalize_rows(matrix: np.ndarray) -> np.ndarray:
    if matrix.size == 0:
        return matrix
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms = np.where(norms <= 1e-12, 1.0, norms)
    return matrix / norms


def dense_search(
    *,
    dense_prior_ids: Sequence[str],
    dense_matrix: np.ndarray,
    retrieval_context: str,
    top_k: int,
) -> dict[str, float]:
    available = len(dense_prior_ids)
    effective_top_k = min(int(top_k), available) if top_k > 0 else 0
    if effective_top_k <= 0 or not dense_prior_ids or dense_matrix.size == 0 or not (retrieval_context or "").strip():
        return {}

    response = embed(
        input=[retrieval_context],
        tier="embedding",
        input_type="search_query",
        encoding_format="float",
    )
    query_vectors = _normalize_rows(_embedding_vectors(response))
    if query_vectors.size == 0:
        return {}

    scores = dense_matrix @ query_vectors[0]
    positive_indices = np.flatnonzero(scores > 0)
    if positive_indices.size == 0:
        return {}
    ranked_indices = positive_indices[np.argsort(scores[positive_indices])[::-1][:effective_top_k]]
    return {
        str(dense_prior_ids[int(index)]): float(scores[int(index)])
        for index in ranked_indices
    }
