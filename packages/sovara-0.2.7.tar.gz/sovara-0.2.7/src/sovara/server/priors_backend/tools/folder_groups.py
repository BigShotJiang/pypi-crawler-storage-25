"""Helpers for grouping active priors by the folders that directly contain them."""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from sovara.server.priors_backend.storage import PriorStore


def collect_folder_priors(
    store: PriorStore,
    base_path: str = "",
    *,
    include_content: bool = False,
) -> tuple[dict[str, list[dict[str, Any]]], dict[str, dict[str, Any]]]:
    snapshot = store.get_snapshot(base_path)
    folder_priors: dict[str, list[dict[str, Any]]] = defaultdict(list)
    all_priors: dict[str, dict[str, Any]] = {}
    all_prior_ids = [prior.id for prior in snapshot.prior_rows]
    hydrated_by_id = (
        {
            str(prior.get("id") or ""): prior
            for prior in store.get_many(all_prior_ids, snapshot=snapshot)
        }
        if include_content
        else {}
    )
    for prior in snapshot.prior_rows:
        prior_dict = hydrated_by_id.get(prior.id) or prior.to_dict()
        path = str(prior.path or "")
        folder_priors[path].append(prior_dict)
        prior_id = str(prior.id or "")
        if prior_id:
            all_priors[prior_id] = prior_dict
    for path in folder_priors:
        folder_priors[path].sort(key=lambda prior: (str(prior.get("title") or ""), str(prior.get("id") or "")))
    return dict(folder_priors), all_priors


def build_folder_tree_summary(store: PriorStore, base_path: str = "") -> str:
    folder_priors, _all_priors = collect_folder_priors(store, base_path)
    paths = sorted(folder_priors)
    if not paths:
        return "(empty)"

    lines: list[str] = []
    for path in paths:
        depth = len([segment for segment in path.strip("/").split("/") if segment])
        folder_name = path.rstrip("/") or "(root)"
        indent = "  " * depth
        priors = folder_priors[path]
        lines.append(f"{indent}- {folder_name}/ ({len(priors)} priors)")
        for prior in priors:
            title = str(prior.get("title") or prior.get("name") or prior.get("id") or "")
            lines.append(f"{indent}  - {title}")
    return "\n".join(lines)
