"""Batch-parallel prior selection over a rooted subtree."""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass
from typing import Any

from sovara.server.priors_backend.constants import MAX_PRIORS_PARALLEL_SEARCH_MAX_PARALLELISM
from sovara.server.priors_backend.logger import logger
from sovara.server.priors_backend.storage import PriorSnapshot, PriorStore
from sovara.server.priors_backend.tools.adjudication import async_select_priors


@dataclass(slots=True)
class ParallelSearchResult:
    selected_ids: list[str]
    selected_priors: list[dict[str, Any]]
    folder_count: int
    selected_folder_count: int


def _dedupe_preserving_order(ids: list[str]) -> list[str]:
    seen: set[str] = set()
    deduped: list[str] = []
    for prior_id in ids:
        if not prior_id or prior_id in seen:
            continue
        seen.add(prior_id)
        deduped.append(prior_id)
    return deduped


def _split_evenly(items: list[Any], batch_count: int) -> list[list[Any]]:
    if not items or batch_count <= 0:
        return []
    batch_count = min(batch_count, len(items))
    base_size, remainder = divmod(len(items), batch_count)
    batches: list[list[Any]] = []
    start = 0
    for index in range(batch_count):
        size = base_size + (1 if index < remainder else 0)
        end = start + size
        batches.append(items[start:end])
        start = end
    return batches


async def parallel_search(
    *,
    store: PriorStore,
    processed_context: str,
    root_path: str = "",
    ignore_prior_ids: list[str] | None = None,
    candidate_prior_ids: list[str] | None = None,
    summary_only: bool,
    max_parallelism: int,
    tier: str,
    reasoning_effort: str = "medium",
    snapshot: PriorSnapshot | None = None,
) -> ParallelSearchResult:
    resolved_snapshot = snapshot or store.get_snapshot(root_path)
    ignore_ids = {prior_id for prior_id in (ignore_prior_ids or []) if prior_id}
    if candidate_prior_ids:
        ordered_prior_ids = _dedupe_preserving_order([prior_id for prior_id in candidate_prior_ids if prior_id])
    else:
        ordered_prior_ids = [prior.id for prior in resolved_snapshot.prior_rows]
    ordered_prior_ids = [
        prior_id
        for prior_id in ordered_prior_ids
        if prior_id not in ignore_ids and prior_id in resolved_snapshot.prior_by_id
    ]
    if not ordered_prior_ids:
        return ParallelSearchResult(
            selected_ids=[],
            selected_priors=[],
            folder_count=0,
            selected_folder_count=0,
        )

    effective_parallelism = max(
        1,
        min(max_parallelism, len(ordered_prior_ids), MAX_PRIORS_PARALLEL_SEARCH_MAX_PARALLELISM),
    )
    prior_id_batches = _split_evenly(ordered_prior_ids, effective_parallelism)
    semaphore = asyncio.Semaphore(effective_parallelism)
    started_at = time.perf_counter()

    async def _select_batch(batch_index: int, prior_ids: list[str]) -> tuple[int, list[str]]:
        if not prior_ids:
            return batch_index, []
        async with semaphore:
            candidates = (
                [resolved_snapshot.prior_by_id[prior_id] for prior_id in prior_ids]
                if summary_only
                else store.get_many(prior_ids, snapshot=resolved_snapshot)
            )
            return batch_index, await async_select_priors(
                processed_context=processed_context,
                candidates=candidates,
                tier=tier,
                summary_only=summary_only,
                reasoning_effort=reasoning_effort,
            )

    batch_results = await asyncio.gather(
        *[_select_batch(batch_index, prior_ids) for batch_index, prior_ids in enumerate(prior_id_batches)]
    )

    selected_ids: list[str] = []
    selected_batch_count = 0
    seen: set[str] = set()
    for _batch_index, batch_ids in batch_results:
        if batch_ids:
            selected_batch_count += 1
        for prior_id in batch_ids:
            if prior_id in ignore_ids or prior_id in seen:
                continue
            if prior_id not in resolved_snapshot.filepath_by_id:
                continue
            seen.add(prior_id)
            selected_ids.append(prior_id)

    selected_priors = store.get_many(selected_ids, snapshot=resolved_snapshot)
    logger.info(
        "Parallel prior search | %s",
        json.dumps(
            {
                "root_path": root_path or "(root)",
                "batch_count": len(prior_id_batches),
                "candidate_count": len(ordered_prior_ids),
                "selected_batch_count": selected_batch_count,
                "selected_count": len(selected_ids),
                "summary_only": summary_only,
                "max_parallelism": max_parallelism,
                "effective_parallelism": effective_parallelism,
                "total_ms": int((time.perf_counter() - started_at) * 1000),
            },
            ensure_ascii=False,
            sort_keys=True,
        ),
    )
    return ParallelSearchResult(
        selected_ids=selected_ids,
        selected_priors=selected_priors,
        folder_count=len(prior_id_batches),
        selected_folder_count=selected_batch_count,
    )
