"""Preprocess raw retrieval context before prior search."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from typing import Any

_PREPROCESS_PREFIX_TOKEN_BUDGET = 500
_PREPROCESS_SUFFIX_TOKEN_BUDGET = 1000
_MIDDLE_TRIM_MARKER = "\n...\n"
_MANUAL_CONTEXT_SUFFIX_KEY = "manual.context"


@dataclass(frozen=True, slots=True)
class RetrievalContextEntry:
    key: str
    text: str


@dataclass(frozen=True, slots=True)
class StructuredRetrievalContext:
    prefix: list[RetrievalContextEntry]
    suffix: list[RetrievalContextEntry]


def _approx_tokens(text: str) -> int:
    stripped = (text or "").strip()
    if not stripped:
        return 0
    return max(1, math.ceil(len(stripped) / 4))


def _parse_entry_list(value: Any) -> list[RetrievalContextEntry] | None:
    if not isinstance(value, list):
        return None

    entries: list[RetrievalContextEntry] = []
    for item in value:
        if not isinstance(item, dict):
            return None
        key = item.get("key")
        text = item.get("text")
        if not isinstance(key, str) or not isinstance(text, str):
            return None
        entries.append(RetrievalContextEntry(key=key, text=text))
    return entries


def _parse_structured_retrieval_context(raw_context: str) -> StructuredRetrievalContext | None:
    try:
        parsed = json.loads(raw_context)
    except json.JSONDecodeError:
        return None

    if not isinstance(parsed, dict):
        return None

    prefix = _parse_entry_list(parsed.get("prefix"))
    suffix = _parse_entry_list(parsed.get("suffix"))
    if prefix is None or suffix is None:
        return None
    return StructuredRetrievalContext(prefix=prefix, suffix=suffix)


def _entry_payload(entry: RetrievalContextEntry | dict[str, str]) -> dict[str, str]:
    if isinstance(entry, RetrievalContextEntry):
        return {"key": entry.key, "text": entry.text}
    return {
        "key": str(entry.get("key") or ""),
        "text": str(entry.get("text") or ""),
    }


def render_structured_raw_context(
    *,
    prefix: list[RetrievalContextEntry | dict[str, str]],
    suffix: list[RetrievalContextEntry | dict[str, str]],
) -> str:
    return json.dumps(
        {
            "prefix": [_entry_payload(entry) for entry in prefix],
            "suffix": [_entry_payload(entry) for entry in suffix],
        },
        ensure_ascii=False,
        separators=(",", ":"),
    )


def render_suffix_only_raw_context(context: str, *, key: str = _MANUAL_CONTEXT_SUFFIX_KEY) -> str:
    return render_structured_raw_context(
        prefix=[],
        suffix=[{"key": key, "text": context}],
    )


def normalize_raw_context(raw_context: str) -> str:
    raw_context = (raw_context or "").strip()
    if not raw_context:
        return ""
    if _parse_structured_retrieval_context(raw_context) is not None:
        return raw_context
    return render_suffix_only_raw_context(raw_context)


def _require_structured_retrieval_context(raw_context: str) -> StructuredRetrievalContext:
    structured_context = _parse_structured_retrieval_context(raw_context)
    if structured_context is None:
        raise ValueError("raw_context must use the canonical structured retrieval context shape")
    return structured_context


def _join_entry_texts(entries: list[RetrievalContextEntry]) -> str:
    return "\n\n".join(entry.text for entry in entries)


def _trim_middle_text_to_token_target(text: str, target_tokens: int) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    if target_tokens <= 0:
        return _MIDDLE_TRIM_MARKER.strip()

    current_tokens = _approx_tokens(text)
    if current_tokens <= target_tokens:
        return text

    marker = _MIDDLE_TRIM_MARKER
    target_chars = max(8, (target_tokens * 4) - len(marker))
    if target_chars >= len(text):
        return text

    keep_head = max(1, target_chars // 2)
    keep_tail = max(1, target_chars - keep_head)
    if keep_head + keep_tail >= len(text):
        return text
    return f"{text[:keep_head].rstrip()}{marker}{text[-keep_tail:].lstrip()}"


def _middle_truncate_section_text(text: str, *, target_tokens: int) -> str:
    return _trim_middle_text_to_token_target(text, target_tokens)


def _render_processed_context(*, suffix_text: str, prefix_text: str) -> str:
    blocks: list[str] = []

    suffix_text = (suffix_text or "").strip()
    if suffix_text:
        blocks.append(f"LATEST CONTEXT\n{suffix_text}")

    prefix_text = (prefix_text or "").strip()
    if prefix_text:
        blocks.append(f"RELEVANT EARLIER CONTEXT\n{prefix_text}")

    return "\n\n".join(blocks) or "-"


def _deterministic_middle_truncate_preprocess(structured: StructuredRetrievalContext) -> str:
    return _render_processed_context(
        suffix_text=_middle_truncate_section_text(
            _join_entry_texts(structured.suffix),
            target_tokens=_PREPROCESS_SUFFIX_TOKEN_BUDGET,
        ),
        prefix_text=_middle_truncate_section_text(
            _join_entry_texts(structured.prefix),
            target_tokens=_PREPROCESS_PREFIX_TOKEN_BUDGET,
        ),
    )


def materialize_raw_context(raw_context: str) -> str:
    raw_context = (raw_context or "").strip()
    if not raw_context:
        return "-"

    structured_context = _require_structured_retrieval_context(raw_context)
    return _render_processed_context(
        suffix_text=_join_entry_texts(structured_context.suffix),
        prefix_text=_join_entry_texts(structured_context.prefix),
    )


def preprocess_context(
    *,
    raw_context: str,
    latency_tier: str,
) -> str:
    raw_context = (raw_context or "").strip()
    if not raw_context:
        return "-"

    structured = _require_structured_retrieval_context(raw_context)
    del latency_tier
    return _deterministic_middle_truncate_preprocess(structured)
