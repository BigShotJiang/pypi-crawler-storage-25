"""Shared helpers for retrieval tools."""

from __future__ import annotations

from typing import Any

import bm25s

DEFAULT_USER_ID = "e17941ff-83e7-4d9b-bc2d-683b0ad8a9f4"
DEFAULT_PROJECT_ID = "a64584f1-90de-41b6-8c73-9ce5529eee82"


def tokenize(text: str, *, drop_stopwords: bool = False) -> list[str]:
    tokenized = bm25s.tokenize(
        text or "",
        stopwords="english" if drop_stopwords else [],
        return_ids=False,
        show_progress=False,
    )
    if not tokenized:
        return []
    return [str(token) for token in tokenized[0]]


def unique_ordered_tokens(text: str, *, drop_stopwords: bool = False) -> tuple[str, ...]:
    ordered: list[str] = []
    seen: set[str] = set()
    for token in tokenize(text, drop_stopwords=drop_stopwords):
        if token in seen:
            continue
        seen.add(token)
        ordered.append(token)
    return tuple(ordered)


def normalize_phrase(text: str) -> str:
    return " ".join(tokenize(text, drop_stopwords=False))


def taxonomy_path_from_row(row: dict[str, Any]) -> list[str]:
    return [segment for segment in str(row.get("path") or "").strip("/").split("/") if segment]


def build_retrieval_text(row: dict[str, Any], taxonomy_path: list[str] | None = None) -> str:
    current_taxonomy_path = taxonomy_path if taxonomy_path is not None else taxonomy_path_from_row(row)
    aliases = ", ".join(row.get("aliases") or [])
    keywords = ", ".join(row.get("keywords") or [])
    taxonomy = " > ".join(current_taxonomy_path)
    fields = [
        str(row.get("title") or ""),
        str(row.get("summary") or ""),
        str(row.get("when_to_use") or ""),
        aliases,
        keywords,
        taxonomy,
        str(row.get("content") or ""),
    ]
    return "\n".join(value for value in fields if value.strip())


def load_active_prior_rows(user_id: str, project_id: str) -> list[dict[str, Any]]:
    from sovara.server.priors_backend.storage import PriorStore

    rows = PriorStore(user_id, project_id).list_all(include_content=True)
    return [row for row in rows if row.get("prior_status", "active") == "active"]


def load_active_prior_row_by_id(user_id: str, project_id: str, prior_id: str) -> dict[str, Any] | None:
    for row in load_active_prior_rows(user_id, project_id):
        if str(row.get("id")) == prior_id:
            return row
    return None


def format_prior_text(
    prior: Any,
    *,
    summary_only: bool = False,
    applicability_label: str = "When to use",
) -> str:
    if isinstance(prior, dict):
        path = str(prior.get("path") or "")
        taxonomy_path = taxonomy_path_from_row(prior)
        title = str(prior.get("title") or "")
        when_to_use = str(prior.get("when_to_use") or "")
        consequence_if_not_followed = str(prior.get("consequence_if_not_followed") or "")
        non_adherence_severity = prior.get("non_adherence_severity")
        aliases = list(prior.get("aliases") or [])
        keywords = list(prior.get("keywords") or [])
        summary = str(prior.get("summary") or "")
        content = str(prior.get("content") or "")
        prior_id = str(prior.get("id") or "")
    else:
        path = str(getattr(prior, "path", "") or "")
        taxonomy_path = list(getattr(prior, "taxonomy_path", []) or [])
        title = str(getattr(prior, "title", "") or "")
        when_to_use = str(getattr(prior, "when_to_use", "") or "")
        consequence_if_not_followed = str(
            getattr(prior, "consequence_if_not_followed", "") or ""
        )
        non_adherence_severity = getattr(prior, "non_adherence_severity", None)
        aliases = list(getattr(prior, "aliases", []) or [])
        keywords = list(getattr(prior, "keywords", []) or [])
        summary = str(getattr(prior, "summary", "") or "")
        content = str(getattr(prior, "content", "") or "")
        prior_id = str(getattr(prior, "prior_id", "") or "")

    if summary_only:
        severity_text = (
            str(non_adherence_severity) if non_adherence_severity is not None else ""
        )
        return (
            f"ID: {prior_id}\n"
            f"Title: {title}\n"
            f"Path: {path}\n"
            f"Taxonomy: {' > '.join(taxonomy_path)}\n"
            f"{applicability_label}: {when_to_use}\n"
            f"Consequence if not followed: {consequence_if_not_followed}\n"
            f"Non-adherence severity: {severity_text}\n"
            f"Aliases: {', '.join(aliases)}\n"
            f"Keywords: {', '.join(keywords)}\n"
            f"Summary: {summary}\n"
        )

    severity_text = str(non_adherence_severity) if non_adherence_severity is not None else ""
    return (
        f"ID: {prior_id}\n"
        f"Title: {title}\n"
        f"Path: {path}\n"
        f"Taxonomy: {' > '.join(taxonomy_path)}\n"
        f"{applicability_label}: {when_to_use}\n"
        f"Consequence if not followed: {consequence_if_not_followed}\n"
        f"Non-adherence severity: {severity_text}\n"
        f"Aliases: {', '.join(aliases)}\n"
        f"Keywords: {', '.join(keywords)}\n"
        f"Summary: {summary}\n"
        f"Content:\n{content}\n"
    )
