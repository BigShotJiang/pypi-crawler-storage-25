"""Metadata-focused keyword retrieval."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Sequence

from sovara.server.priors_backend.tools.utils import tokenize, unique_ordered_tokens

TOOL_DEFINITION = {
    "type": "function",
    "function": {
        "name": "keyword_search",
        "description": "Run metadata-focused keyword search over titles, aliases, keywords, taxonomy, and when-to-use text.",
        "parameters": {
            "type": "object",
            "properties": {"top_k": {"type": "integer"}},
            "additionalProperties": False,
        },
    },
}


@dataclass(frozen=True)
class KeywordSearchDocument:
    prior_id: str
    title: str
    path: str
    title_tokens: tuple[str, ...]
    keyword_tokens: tuple[str, ...]
    alias_tokens: tuple[str, ...]
    taxonomy_tokens: tuple[str, ...]
    when_to_use_tokens: tuple[str, ...]


def keyword_search(
    *,
    docs: Sequence[Any],
    retrieval_context: str,
    top_k: int,
) -> dict[str, float]:
    query_terms = set(tokenize(retrieval_context, drop_stopwords=True))
    if not query_terms:
        return {}

    scores: dict[str, float] = {}
    for doc in docs:
        score = (
            2.0 * len(query_terms & set(doc.title_tokens))
            + 4.0 * len(query_terms & set(doc.keyword_tokens))
            + 3.0 * len(query_terms & set(doc.alias_tokens))
            + 1.0 * len(query_terms & set(doc.taxonomy_tokens))
            + 2.0 * len(query_terms & set(doc.when_to_use_tokens))
        )
        if score > 0:
            scores[str(doc.prior_id)] = score
    return dict(sorted(scores.items(), key=lambda item: item[1], reverse=True)[:top_k])


def build_keyword_document(row: dict[str, Any]) -> KeywordSearchDocument:
    taxonomy_segments = [segment for segment in str(row.get("path") or "").strip("/").split("/") if segment]
    return KeywordSearchDocument(
        prior_id=str(row.get("id") or ""),
        title=str(row.get("title") or ""),
        path=str(row.get("path") or ""),
        title_tokens=unique_ordered_tokens(str(row.get("title") or ""), drop_stopwords=True),
        keyword_tokens=unique_ordered_tokens(" ".join(row.get("keywords") or []), drop_stopwords=True),
        alias_tokens=unique_ordered_tokens(" ".join(row.get("aliases") or []), drop_stopwords=True),
        taxonomy_tokens=unique_ordered_tokens(" ".join(taxonomy_segments), drop_stopwords=True),
        when_to_use_tokens=unique_ordered_tokens(str(row.get("when_to_use") or ""), drop_stopwords=True),
    )

