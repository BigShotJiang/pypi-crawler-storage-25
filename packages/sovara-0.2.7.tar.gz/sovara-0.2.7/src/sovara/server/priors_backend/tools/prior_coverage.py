"""Estimate groundedness for an already selected prior set."""

from __future__ import annotations

import json
from typing import Any, Sequence

from sovara.server.llm_backend import infer_structured_json, resolve_model
from sovara.server.priors_backend.tools.utils import format_prior_text

GROUNDEDNESS_PROMPT_VERSION = "groundedness_guidance_points_v4"
GROUNDEDNESS_JUDGE_TIER = "expensive"
GROUNDEDNESS_JUDGE_REASONING_EFFORT = "medium"

SYSTEM_PROMPT = """You are scoring groundedness for an LLM step in a trace.

In this system, a "prior" means a reusable guidance snippet learned from past successful work.
It is not the generic machine-learning term "prior".

You are given:
- the input context for an LLM step
- the generated output for that step
- the full applied prior set for that step

Your job is to measure how well the applied priors ground the materially important guidance needs of that step.

Definition of groundedness:
Groundedness is the extent to which the applied priors already ground the important unresolved choices, ambiguities, and failure modes in the latest context. In other words, a step has high groundedness when the remaining unguided decision space is small.

This score must be computed through guidance points.

Definition of a guidance point:
A guidance point is a distinct, materially important, prior-addressable decision point, ambiguity, constraint, failure mode, exception, or domain-specific interpretation in LATEST CONTEXT.

A guidance point should be counted only if:
- it is relevant to the next-step task implied by LATEST CONTEXT
- it involves meaningful room for error, ambiguity, or interpretation
- a prior could realistically constrain or guide it
- it is materially distinct from other counted guidance points

Do not count:
- trivial details
- generic competence or obvious execution steps that do not require prior guidance
- duplicate or near-duplicate restatements of the same underlying guidance point
- points that are already fully specified in LATEST CONTEXT itself and therefore do not need prior grounding

Operational method:
1. Identify the distinct guidance points in LATEST CONTEXT.
2. Use RELEVANT EARLIER CONTEXT only to interpret LATEST CONTEXT.
3. Use LLM output as supporting evidence for which decisions, interpretations, or constraints were active in the step.
4. For each guidance point, assign an importance from 1 to 10 based on how much getting that point wrong would affect the step outcome.
5. For each guidance point, determine whether at least one applied prior grounds it.
6. Let:
   - total_importance = sum of importance for all guidance points
   - grounded_importance = sum of importance for guidance points grounded by at least one applied prior
7. Compute:
   groundedness = round(100 * grounded_importance / total_importance)
8. If total_importance = 0, return groundedness = 0.

Important:
- The provided prior set is the final applied set, not just newly retrieved priors.
- It may include both inherited priors and newly retrieved priors.
- Score the set as a whole, not each prior independently.
- A score of 100 should be rare. It means the applied priors leave essentially no materially important unguided decision space for the next step.

The LLM step is provided in this serialized form:

Processed retrieval context:
LATEST CONTEXT:
<text>

RELEVANT EARLIER CONTEXT:
<text>

LLM output:
<text or structured text>

Applied priors:
<one or more formatted priors>

Interpret these sections carefully:
- LATEST CONTEXT is the primary part of the step input to score against.
- RELEVANT EARLIER CONTEXT is supporting background only.
- LLM output is evidence about which decisions were actually made or surfaced in the step.
- The main question is: how many materially important prior-addressable guidance points are present in LATEST CONTEXT, and how many of them are grounded by the applied priors?

How to use LLM output:
- Use LLM output to detect which guidance points were active in the step.
- Use it to reveal which choices, interpretations, and constraints the model actually had to resolve.
- Use it as supporting evidence, not as the definition of what matters.
- Do not ignore an important guidance point just because it is absent from the output.
- Do not count something as a guidance point only because it appears in the output if it was not materially important to the task.

How to evaluate whether a prior grounds a guidance point:
Use the prior fields in this order of importance:
1. Select for this situation -> strongest signal for applicability
2. Content -> strongest signal for substantive grounding
3. Summary -> concise confirmation
4. Aliases / Keywords -> supporting lexical and entity cues
5. Title -> lightweight hint
6. Path / Taxonomy -> weak organizational hints only

Grounding rule for a single guidance point:
A guidance point counts as grounded only if at least one prior:
- applies to that situation, and
- contains substantive guidance that constrains that guidance point

This means:
- "Select for this situation" determines applicability
- "Content" determines substantive grounding
- topical overlap alone is not enough
- keyword overlap alone is not enough
- a prior that is relevant to the broad topic but does not constrain the actual guidance point does not count as grounding

Importance rule:
Importance measures how much getting this guidance point wrong would affect the step outcome.
Assign importance before evaluating grounding.
Do not assign higher importance because a point is grounded or because a prior discusses it.
Use this 1-10 integer scale:
- 1-2: minor detail; unlikely to materially change the outcome
- 3-4: useful constraint; mistake causes limited degradation
- 5-6: important; mistake can produce a materially worse answer or require revision
- 7-8: critical; mistake likely causes a wrong, unsafe, broken, or unusable result
- 9-10: decisive; this point alone can determine success or failure

Typical high-importance points include:
- choosing the correct operational workflow, source of truth, field meaning, counting unit, API/tool contract, or join/path equivalent
- resolving a central ambiguity where plausible alternatives lead to different outcomes
- preserving an explicit user constraint, safety boundary, irreversible-action rule, or public contract
- avoiding a failure mode that would invalidate the result even if other details are correct

Typical low-importance points include:
- formatting, ordering, tone, or presentation details that do not change the substantive outcome
- extra low-confidence alternatives or optional checks whose absence would not invalidate the step
- minor efficiency or style choices

How to identify guidance points:
Look for distinct materially important needs such as:
- the main rule or decision logic
- required constraints or exclusions
- the critical disambiguation needed to act correctly
- the relevant schema interpretation, field meaning, aggregation rule, or API/tool-use rule
- important exceptions, carve-outs, overrides, or failure modes
- important output requirements or evaluation criteria
- materially important safety or boundary conditions
- behavior that must be preserved while making the requested change

Granularity rule:
A guidance point should correspond to one distinct materially important thing that could be grounded or missed independently.
If two items could reasonably be grounded by different priors or one could be grounded while the other is not, count them separately.
If two phrasings refer to the same underlying guidance need, count them once.

Specificity rule:
Guidance points must be concrete enough that a reviewer can tell what would satisfy or violate them.
Do not write vague guidance points such as:
- use the correct semantics
- handle the situation carefully
- avoid common pitfalls
- choose the right workflow
- account for edge cases

Instead, name the actual decision axis, contrast, scope, unit, exception, or failure mode.
If a materially important point depends on choosing between two plausible interpretations, state that contrast explicitly.

Match by meaning, not surface form:
- Do not require exact wording overlap between context, output, and priors.
- Paraphrases, aliases, abbreviations, reformulations, and implicit references count.
- Use RELEVANT EARLIER CONTEXT only to resolve what LATEST CONTEXT is referring to.
- However, do not over-credit weak thematic overlap. Grounding must be about the same underlying guidance point.

Contrastive grounding rule:
If a guidance point involves choosing between plausible alternatives, a prior grounds it only if it rules out the wrong alternatives or selects the right one.
A prior that merely says to be careful, avoid mistakes, handle edge cases, or use the correct interpretation does not ground the point.
A broad prior can ground a point only when its content substantively constrains the same decision axis at the needed specificity.

What does NOT count as grounding:
- generic advice that only vaguely overlaps
- priors that match the broad topic but miss the critical rule, constraint, edge case, or failure mode
- priors that mention related entities or keywords without supplying the needed guidance
- multiple priors that repeat the same point
- priors that would have helped some earlier part of the conversation but do not help the next step implied by LATEST CONTEXT

Redundancy and conflicts:
- Repeated priors do not increase grounded_importance by themselves.
- Each guidance point can be counted at most once as grounded.
- Multiple priors may support the same guidance point, but this still counts as one grounded guidance point.
- If priors conflict, are misleading, or point in different directions for the current situation, do not count a guidance point as grounded unless the applied set still provides clear correct guidance for that point.

Calibration examples:

Example 1: document processing / information extraction
LATEST CONTEXT:
Extract the invoice total from this vendor PDF and return it as a number.

LLM output:
Returned the amount from the "Amount Due" field as a numeric value.

Applied priors:
- Prior A
  Select for this situation: When extracting totals from invoices issued by Acme Telecom.
  Content: In Acme Telecom invoices, Amount Due is the payable total. Do not use Subtotal, Tax Total, or Previous Balance. If both Amount Due and AutoPay Amount appear, prefer Amount Due.
- Prior B
  Select for this situation: When extracting monetary fields from invoices.
  Content: Normalize currency symbols and thousands separators, and return only the numeric amount.

Reasoning:
Distinct guidance points include:
1. which field is the true payable total
2. how to handle multiple candidate total-like fields
3. how to normalize the returned numeric amount

These are all grounded by the applied priors.
Expected result:
- total_importance: around 20
- grounded_importance: around 20
- groundedness: 100

Example 2: customer support agent
LATEST CONTEXT:
Customer message:
Hi, I'm confused. I clicked pause deliveries for May 3-17 because I'll be traveling, but now my dashboard says my subscription is canceled. I don't want a new plan or to lose my current discount. Can you fix this before my next box ships?

Task:
Draft the support reply and choose the next internal action.

RELEVANT EARLIER CONTEXT:
The support agent can send either pause, reactivate, cancel, refund, or escalation actions.

LLM output:
Hi Jordan,

I'm sorry for the confusion. I can help you get set up again before your next box ships. I'll start a new subscription using your current delivery preferences and make sure May 3-17 is skipped while you're away. You'll receive a confirmation once the new plan is active.

Applied priors:
- Prior A
  Select for this situation: When responding to customers with account problems.
  Content: Be empathetic, acknowledge the issue, explain next steps clearly, and avoid making irreversible account changes without confirmation.

Reasoning:
Distinct guidance points include:
1. distinguish pausing deliveries from canceling the subscription
2. determine whether the correct internal action is restoration, reactivation, or escalation rather than creating a new subscription
3. preserve the customer's current discount and plan state
4. avoid taking or recommending irreversible account actions before confirming intent
5. address the timing constraint before the next box ships

Prior A grounds tone and caution around irreversible actions, but it does not resolve the operational distinction between pause, cancellation, reactivation, escalation, and new subscription creation. It also does not ground preserving the discount or choosing the correct internal workflow.
Expected result:
- total_importance: around 35-45
- grounded_importance: around 8-12
- groundedness: around 20-30

Example 3: software engineering / code change agent
LATEST CONTEXT:
Add retry logic around the PartnerX charge creation call. Keep public API behavior unchanged.

RELEVANT EARLIER CONTEXT:
The PartnerX integration already has a request wrapper. We previously agreed retries must be safe for side-effecting calls.

LLM output:
Implemented PartnerX charge creation retries using bounded exponential backoff with jitter. The retry loop only retries transient 429/5xx responses, reuses the existing idempotency key on every attempt, and skips permanent validation errors so public API behavior remains unchanged.

Applied priors:
- Prior A
  Select for this situation: When adding or changing retries for PartnerX write operations.
  Content: For PartnerX create or update calls, retry only transient statuses such as 429, 500, 502, 503, and 504. Reuse the same idempotency key across attempts. Do not retry validation, authorization, or malformed-request errors.
- Prior B
  Select for this situation: When implementing retry behavior for third-party APIs.
  Content: Use exponential backoff with jitter, cap attempts, and keep retry behavior inside the integration boundary unless the caller contract explicitly includes retry state.

Reasoning:
Distinct guidance points include:
1. classify which PartnerX responses are retryable
2. preserve idempotency safety for a write operation
3. use bounded exponential backoff with jitter
4. keep public API behavior unchanged by containing retry behavior within the integration boundary

These guidance points are grounded by the applied priors.
Expected result:
- total_importance: around 30-40
- grounded_importance: around 30-40
- groundedness: 100

Before returning groundedness = 100:
Ask whether a competent model could still follow the applied priors and make a materially different wrong choice for this step.
If yes, at least one guidance point remains ungrounded and the score must be below 100.
A score of 100 requires that the applied prior set resolves all materially important prior-addressable choices at the specificity required by the latest context.

Output requirements:
Return only structured JSON with exactly these fields:
{
  "guidance_points": [
    {
      "guidance_point": <string>,
      "grounded": <boolean>,
      "importance": <integer 1-10>,
      "importance_reason": <string>
    }
  ],
  "total_importance": <integer>,
  "grounded_importance": <integer>,
  "groundedness": <integer>
}

Rules:
- guidance_points must contain every distinct guidance point you identified
- every guidance point must include importance and importance_reason
- importance must be an integer from 1 to 10
- total_importance must equal the sum of importance over guidance_points
- grounded_importance must equal the sum of importance where grounded is true
- grounded_importance must be less than or equal to total_importance
- groundedness must equal round(100 * grounded_importance / total_importance) when total_importance > 0
- if total_importance = 0, return groundedness = 0
- return integers only for importance and score fields
- return no extra text"""

RESPONSE_FORMAT = {
    "type": "json_schema",
    "json_schema": {
        "name": "groundedness",
        "schema": {
            "type": "object",
            "properties": {
                "guidance_points": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "guidance_point": {"type": "string"},
                            "grounded": {"type": "boolean"},
                            "importance": {"type": "integer", "minimum": 1, "maximum": 10},
                            "importance_reason": {"type": "string"},
                        },
                        "required": [
                            "guidance_point",
                            "grounded",
                            "importance",
                            "importance_reason",
                        ],
                        "additionalProperties": False,
                    },
                },
                "total_importance": {"type": "integer"},
                "grounded_importance": {"type": "integer"},
                "groundedness": {"type": "integer"},
            },
            "required": [
                "guidance_points",
                "total_importance",
                "grounded_importance",
                "groundedness",
            ],
            "additionalProperties": False,
        },
    },
}


def groundedness_judge_cache_config() -> dict[str, str]:
    return {
        "prompt_version": GROUNDEDNESS_PROMPT_VERSION,
        "tier": GROUNDEDNESS_JUDGE_TIER,
        "reasoning_effort": GROUNDEDNESS_JUDGE_REASONING_EFFORT,
        "model": resolve_model(None, GROUNDEDNESS_JUDGE_TIER),
    }


def coverage_judge_cache_config() -> dict[str, str]:
    return groundedness_judge_cache_config()


def _format_llm_output(llm_output: Any) -> str:
    if llm_output is None:
        return "(not provided)"
    if isinstance(llm_output, str):
        return llm_output
    try:
        return json.dumps(llm_output, ensure_ascii=False, indent=2, sort_keys=True)
    except TypeError:
        return str(llm_output)


def _normalize_guidance_points(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    guidance_points: list[dict[str, Any]] = []
    for item in value:
        if isinstance(item, str):
            text = item.strip()
            if text:
                guidance_points.append(
                    {
                        "guidance_point": text,
                        "grounded": False,
                        "importance": 1,
                        "importance_reason": "",
                    }
                )
            continue
        if not isinstance(item, dict):
            continue
        text = str(item.get("guidance_point") or "").strip()
        if not text:
            continue
        importance = _coerce_importance(item.get("importance"))
        importance_reason = str(item.get("importance_reason") or "").strip()
        guidance_points.append(
            {
                "guidance_point": text,
                "grounded": bool(item.get("grounded")),
                "importance": importance,
                "importance_reason": importance_reason,
            }
        )
    return guidance_points


def _coerce_importance(value: Any) -> int:
    try:
        importance = int(value)
    except (TypeError, ValueError):
        importance = 1
    return max(1, min(10, importance))


def _groundedness_score(total_importance: int, grounded_importance: int) -> int:
    if total_importance <= 0:
        return 0
    return int(round(100 * grounded_importance / total_importance))


def _normalize_groundedness_result(parsed: dict[str, Any]) -> dict[str, Any]:
    guidance_points = _normalize_guidance_points(parsed.get("guidance_points"))
    if guidance_points:
        total_importance = sum(item["importance"] for item in guidance_points)
        grounded_importance = sum(
            item["importance"] for item in guidance_points if item["grounded"]
        )
    else:
        total_importance = max(0, int(parsed.get("total_importance") or 0))
        grounded_importance = max(0, int(parsed.get("grounded_importance") or 0))
        grounded_importance = min(grounded_importance, total_importance)
    groundedness = _groundedness_score(total_importance, grounded_importance)
    return {
        "guidance_points": guidance_points,
        "total_importance": total_importance,
        "grounded_importance": grounded_importance,
        "groundedness": max(0, min(100, groundedness)),
    }


def calculate_groundedness(
    *,
    processed_context: str,
    llm_output: Any = None,
    priors: Sequence[Any],
) -> dict[str, Any]:
    prior_list = list(priors)
    formatted_priors = "\n---\n\n".join(
        format_prior_text(
            prior,
            applicability_label="Select for this situation",
        )
        for prior in prior_list
    )
    if not formatted_priors:
        formatted_priors = "(none)"

    messages = [
        {
            "role": "system",
            "content": SYSTEM_PROMPT,
        },
        {
            "role": "user",
            "content": (
                f"Processed retrieval context:\n{processed_context}\n\n"
                f"LLM output:\n{_format_llm_output(llm_output)}\n\n"
                "Applied priors:\n\n" + formatted_priors
            ),
        },
    ]
    parsed = infer_structured_json(
        messages=messages,
        tier=GROUNDEDNESS_JUDGE_TIER,
        model=None,
        response_format=RESPONSE_FORMAT,
        repair_attempts=1,
        reasoning_effort=GROUNDEDNESS_JUDGE_REASONING_EFFORT,
    )["parsed"]
    return _normalize_groundedness_result(parsed)


def calculate_prior_coverage(
    *,
    processed_context: str,
    llm_output: Any = None,
    priors: Sequence[Any],
) -> int:
    return int(
        calculate_groundedness(
            processed_context=processed_context,
            llm_output=llm_output,
            priors=priors,
        )["groundedness"]
    )
