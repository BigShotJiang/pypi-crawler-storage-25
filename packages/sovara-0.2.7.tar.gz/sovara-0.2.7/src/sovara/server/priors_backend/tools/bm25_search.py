"""BM25 retrieval tool for prior search."""

from __future__ import annotations

from typing import Any, Sequence

import bm25s

TOOL_DEFINITION = {
    "type": "function",
    "function": {
        "name": "bm25_search",
        "description": "Run BM25 search over the prior corpus against the current retrieval context.",
        "parameters": {
            "type": "object",
            "properties": {"top_k": {"type": "integer"}},
            "additionalProperties": False,
        },
    },
}


def bm25_search(
    *,
    bm25_retriever: Any,
    corpus_ids: Sequence[str],
    retrieval_context: str,
    top_k: int,
) -> dict[str, float]:
    available = len(corpus_ids)
    effective_top_k = min(int(top_k), available) if top_k > 0 else 0
    if bm25_retriever is None or effective_top_k <= 0 or not (retrieval_context or "").strip():
        return {}

    query_tokens = bm25s.tokenize(retrieval_context, stopwords="english", show_progress=False)
    results, scores = bm25_retriever.retrieve(
        query_tokens,
        corpus=list(corpus_ids),
        k=effective_top_k,
        show_progress=False,
    )
    if getattr(results, "size", 0) == 0:
        return {}

    ranked: dict[str, float] = {}
    for prior_id, score in zip(results[0], scores[0]):
        normalized_id = str(prior_id)
        numeric_score = float(score)
        if normalized_id and numeric_score > 0:
            ranked[normalized_id] = numeric_score
    return ranked
