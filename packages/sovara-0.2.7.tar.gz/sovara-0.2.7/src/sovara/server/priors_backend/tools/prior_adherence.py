"""Audit whether relevant applied priors were followed by an LLM output."""

from __future__ import annotations

import json
from typing import Any, Sequence

from sovara.server.llm_backend import infer_structured_json, resolve_model
from sovara.server.priors_backend.tools.prior_coverage import _format_llm_output
from sovara.server.priors_backend.tools.utils import format_prior_text

PRIOR_ADHERENCE_PROMPT_VERSION = "prior_adherence_v2"
PRIOR_ADHERENCE_JUDGE_TIER = "expensive"
PRIOR_ADHERENCE_JUDGE_REASONING_EFFORT = "medium"

SYSTEM_PROMPT = """You are auditing prior adherence for an LLM step in a trace.

In this system, a "prior" means a reusable guidance snippet learned from past successful work.
It is not the generic machine-learning term "prior".

You are given:
- the input context for an LLM step
- the generated output for that step
- the full applied prior set for that step

Your job is to audit the applied priors directly.
For each applied prior, determine:
1. whether it was relevant to this node, and
2. if relevant, whether the generated output materially followed it.

Definition of the node obligation:
The output obligation for this LLM step may come from more than the latest user request.
When deciding relevance and adherence, consider the full node contract, including:
- LATEST CONTEXT
- RELEVANT EARLIER CONTEXT
- system, developer, prefix, or persistent instructions included in the provided context
- output schema, tool contract, or response format requirements
- the generated output itself as evidence of which decisions were actually made in the step

Definition of a relevant prior:
A prior is relevant if its instruction would have constrained, guided, or evaluated what counts as an acceptable output for this node.

Operationally:
A prior is relevant if following it would have changed the set of acceptable outputs for this step.

A prior can be relevant even if:
- the exact issue is not explicitly stated in LATEST CONTEXT
- the obligation comes from system, developer, prefix, or schema requirements
- the generated output reveals that the model made a decision governed by the prior
- the prior constrains what must not be added, omitted, changed, or violated

A prior is not relevant if:
- it only overlaps topically but does not constrain this specific output
- it applies to a different table, API, tool, domain, schema, workflow, or task than the one actually at issue
- it would only have helped an earlier or different step
- it is too generic to evaluate against this specific node output

Definition of followed:
For each relevant prior, determine whether the generated output materially followed the prior.

followed = true when:
- the output complies with the prior's substantive instruction
- the output satisfies the required behavior the prior imposes for this situation
- minor wording, formatting, or stylistic differences do not change substantive compliance

followed = false when:
- the output contradicts the prior
- the output omits a required behavior from the prior
- the output uses an approach the prior explicitly warns against
- the output adds something the prior says not to add
- the output violates an output-shape, schema, safety, tool-use, domain, or correctness constraint imposed by the prior

For non-relevant priors:
- relevant must be false
- followed must be null
- non_adherence_severity must be 0

Definition of non-adherence consequence and severity:
Each prior may include:
- Consequence if not followed: the expected failure mode when this prior is relevant but violated
- Non-adherence severity: a prior-authored integer from 1 to 10

Do not reinterpret or rescale the prior-authored severity.
If a prior is relevant and not followed, non_adherence_severity must be the prior's Non-adherence severity exactly.
If a violated relevant prior has no Non-adherence severity, use 5.

Severity scale:
1-2 = Cosmetic or negligible; unlikely to affect outcome.
3-4 = Minor quality, consistency, or preference issue.
5-6 = Material issue that can cause wrong behavior, wrong interpretation, or degraded quality.
7-8 = Serious issue likely to cause wrong output, wrong action, output-contract violation, or major degradation.
9-10 = Direct correctness break, safety-critical violation, hard contract violation, or likely primary reason the step failed.

How to use consequence and severity:
- Use Consequence if not followed as context for the reason field.
- Use Non-adherence severity only as the fixed numeric penalty for a violated relevant prior.
- If multiple priors repeat the same violated instruction, mark each relevant repeated prior as not followed and use each prior's own authored severity.

Important examples:
- If a prior says "only include requested output columns" and the generated SQL adds an unrequested ROOM column, that prior is relevant and followed=false.
- If a prior says "do not use table X for this domain" and the generated output uses table X for that domain, that prior is relevant and followed=false.
- If a prior says "deduplicate table Y before aggregation" and the generated query aggregates after joining raw duplicate rows, that prior is relevant and followed=false.
- If a prior describes a table family, API, or workflow unrelated to the generated output and this node did not need it, that prior is not relevant.

How to use the prior fields:
Use the prior fields in this order of importance:
1. Select for this situation -> strongest signal for when the prior applies
2. Content -> strongest signal for what must be followed
3. Summary -> concise confirmation
4. Aliases / Keywords -> supporting cues
5. Title -> lightweight hint
6. Path / Taxonomy -> weak organizational hint only

Field usage rule:
- "Select for this situation" is the strongest signal for relevance.
- "Content" is the strongest signal for what the output must or must not do.
- topical overlap alone is not enough for relevance
- keyword overlap alone is not enough for relevance
- a prior can be relevant even if the exact wording does not appear in the context, as long as it constrains acceptable output for this node

Match by meaning, not surface form:
- Do not require exact wording overlap between the context, output, and prior.
- Paraphrases, aliases, abbreviations, reformulations, and implicit references count.
- Use the generated output as evidence of what choices the model actually made.
- However, do not infer relevance from topic similarity alone. The prior must constrain this node's acceptable output.

The LLM step is provided in this serialized form:

Processed retrieval context:
LATEST CONTEXT:
<text>

RELEVANT EARLIER CONTEXT:
<text>

LLM output:
<text or structured output>

Applied priors:
<one or more formatted priors>

Interpret these sections carefully:
- LATEST CONTEXT is the primary part of the step input.
- RELEVANT EARLIER CONTEXT is supporting background only.
- The generated output is the object being audited for compliance.
- The main question is not "would this prior have been nice to have?"
- The main question is "was this prior relevant to what this node needed to produce, and if so, did the output follow it?"

Output requirements:
Return only structured JSON with exactly these fields:

{
  "prior_adherence_items": [
    {
      "prior_id": "<string>",
      "prior_title": "<string>",
      "relevant": <boolean>,
      "followed": <boolean or null>,
      "non_adherence_severity": <integer>,
      "consequence_if_not_followed": "<string>",
      "reason": "<short string>"
    }
  ],
  "relevant_prior_count": <integer>,
  "followed_relevant_prior_count": <integer>,
  "violated_relevant_prior_count": <integer>,
  "total_non_adherence_severity": <integer>,
  "max_non_adherence_severity": <integer>,
  "prior_adherence": <integer>,
  "severity_weighted_prior_adherence": <integer>
}

Rules:
- Include exactly one prior_adherence_items entry for every applied prior.
- If relevant=false, followed must be null and non_adherence_severity must be 0.
- If relevant=true and followed=true, non_adherence_severity must be 0.
- If relevant=true and followed=false, non_adherence_severity must equal the prior's Non-adherence severity, or 5 if absent.
- consequence_if_not_followed must copy the prior's Consequence if not followed, or "" if absent.
- The reason must be short, concrete, and evidence-based.
- relevant_prior_count = number of items with relevant=true.
- followed_relevant_prior_count = number of items with relevant=true and followed=true.
- violated_relevant_prior_count = number of items with relevant=true and followed=false.
- total_non_adherence_severity = sum of non_adherence_severity across all items.
- max_non_adherence_severity = maximum non_adherence_severity across all items, or 0 if none.
- prior_adherence = round(100 * followed_relevant_prior_count / relevant_prior_count), or 0 if relevant_prior_count = 0.
- severity_weighted_prior_adherence = round(100 * (1 - total_non_adherence_severity / (10 * relevant_prior_count))), or 0 if relevant_prior_count = 0.
- Clamp severity_weighted_prior_adherence to the range 0 to 100.
- Return integers only for all aggregate numeric fields.
- Return no extra text."""

RESPONSE_FORMAT = {
    "type": "json_schema",
    "json_schema": {
        "name": "prior_adherence",
        "schema": {
            "type": "object",
            "properties": {
                "prior_adherence_items": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "prior_id": {"type": "string"},
                            "prior_title": {"type": "string"},
                            "relevant": {"type": "boolean"},
                            "followed": {
                                "anyOf": [
                                    {"type": "boolean"},
                                    {"type": "null"},
                                ]
                            },
                            "non_adherence_severity": {
                                "type": "integer",
                                "minimum": 0,
                                "maximum": 10,
                            },
                            "consequence_if_not_followed": {"type": "string"},
                            "reason": {"type": "string"},
                        },
                        "required": [
                            "prior_id",
                            "prior_title",
                            "relevant",
                            "followed",
                            "non_adherence_severity",
                            "consequence_if_not_followed",
                            "reason",
                        ],
                        "additionalProperties": False,
                    },
                },
                "relevant_prior_count": {"type": "integer"},
                "followed_relevant_prior_count": {"type": "integer"},
                "violated_relevant_prior_count": {"type": "integer"},
                "total_non_adherence_severity": {"type": "integer"},
                "max_non_adherence_severity": {"type": "integer"},
                "prior_adherence": {"type": "integer"},
                "severity_weighted_prior_adherence": {"type": "integer"},
            },
            "required": [
                "prior_adherence_items",
                "relevant_prior_count",
                "followed_relevant_prior_count",
                "violated_relevant_prior_count",
                "total_non_adherence_severity",
                "max_non_adherence_severity",
                "prior_adherence",
                "severity_weighted_prior_adherence",
            ],
            "additionalProperties": False,
        },
    },
}


def prior_adherence_judge_cache_config() -> dict[str, str]:
    return {
        "prompt_version": PRIOR_ADHERENCE_PROMPT_VERSION,
        "tier": PRIOR_ADHERENCE_JUDGE_TIER,
        "reasoning_effort": PRIOR_ADHERENCE_JUDGE_REASONING_EFFORT,
        "model": resolve_model(None, PRIOR_ADHERENCE_JUDGE_TIER),
    }


def _prior_id(prior: Any) -> str:
    if isinstance(prior, dict):
        return str(prior.get("id") or prior.get("prior_id") or "").strip()
    return ""


def _prior_title(prior: Any) -> str:
    if isinstance(prior, dict):
        return str(prior.get("title") or prior.get("name") or "").strip()
    return ""


def _prior_consequence_if_not_followed(prior: Any) -> str:
    if isinstance(prior, dict):
        return str(prior.get("consequence_if_not_followed") or "").strip()
    return str(getattr(prior, "consequence_if_not_followed", "") or "").strip()


def _coerce_severity(value: Any, *, default: int = 0) -> int:
    try:
        severity = int(value)
    except (TypeError, ValueError):
        severity = default
    return max(0, min(10, severity))


def _prior_non_adherence_severity(prior: Any, *, default: int = 5) -> int:
    if isinstance(prior, dict):
        value = prior.get("non_adherence_severity")
    else:
        value = getattr(prior, "non_adherence_severity", None)
    return max(1, _coerce_severity(value, default=default))


def _score_percentage(numerator: int, denominator: int) -> int:
    if denominator <= 0:
        return 0
    return max(0, min(100, int(round(100 * numerator / denominator))))


def _severity_weighted_adherence(
    relevant_prior_count: int, total_non_adherence_severity: int
) -> int:
    if relevant_prior_count <= 0:
        return 0
    denominator = 10 * relevant_prior_count
    score = 100 * (1 - total_non_adherence_severity / denominator)
    return max(0, min(100, int(round(score))))


def _normalize_prior_adherence_result(
    parsed: dict[str, Any],
    priors: Sequence[Any],
) -> dict[str, Any]:
    parsed_items = parsed.get("prior_adherence_items")
    parsed_items_by_id: dict[str, dict[str, Any]] = {}
    if isinstance(parsed_items, list):
        for item in parsed_items:
            if not isinstance(item, dict):
                continue
            prior_id = str(item.get("prior_id") or "").strip()
            if prior_id and prior_id not in parsed_items_by_id:
                parsed_items_by_id[prior_id] = item

    normalized_items: list[dict[str, Any]] = []
    for index, prior in enumerate(priors):
        prior_id = _prior_id(prior) or f"prior_{index + 1}"
        prior_title = _prior_title(prior)
        consequence_if_not_followed = _prior_consequence_if_not_followed(prior)
        item = parsed_items_by_id.get(prior_id, {})
        relevant = bool(item.get("relevant"))
        followed_raw = item.get("followed")
        followed = bool(followed_raw) if relevant else None
        if relevant and followed is False:
            severity = _prior_non_adherence_severity(prior)
        else:
            severity = 0
        normalized_items.append(
            {
                "prior_id": prior_id,
                "prior_title": str(item.get("prior_title") or prior_title),
                "relevant": relevant,
                "followed": followed,
                "non_adherence_severity": severity,
                "consequence_if_not_followed": consequence_if_not_followed,
                "reason": str(item.get("reason") or "").strip(),
            }
        )

    relevant_prior_count = sum(1 for item in normalized_items if item["relevant"])
    followed_relevant_prior_count = sum(
        1 for item in normalized_items if item["relevant"] and item["followed"] is True
    )
    violated_relevant_prior_count = sum(
        1 for item in normalized_items if item["relevant"] and item["followed"] is False
    )
    total_non_adherence_severity = sum(
        int(item["non_adherence_severity"]) for item in normalized_items
    )
    max_non_adherence_severity = max(
        (int(item["non_adherence_severity"]) for item in normalized_items),
        default=0,
    )
    return {
        "prior_adherence_items": normalized_items,
        "relevant_prior_count": relevant_prior_count,
        "followed_relevant_prior_count": followed_relevant_prior_count,
        "violated_relevant_prior_count": violated_relevant_prior_count,
        "total_non_adherence_severity": total_non_adherence_severity,
        "max_non_adherence_severity": max_non_adherence_severity,
        "prior_adherence": _score_percentage(followed_relevant_prior_count, relevant_prior_count),
        "severity_weighted_prior_adherence": _severity_weighted_adherence(
            relevant_prior_count, total_non_adherence_severity
        ),
    }


def calculate_prior_adherence(
    *,
    processed_context: str,
    llm_output: Any = None,
    priors: Sequence[Any],
) -> dict[str, Any]:
    prior_list = list(priors)
    formatted_priors = "\n---\n\n".join(
        format_prior_text(
            prior,
            applicability_label="Select for this situation",
        )
        for prior in prior_list
    )
    if not formatted_priors:
        formatted_priors = "(none)"

    messages = [
        {
            "role": "system",
            "content": SYSTEM_PROMPT,
        },
        {
            "role": "user",
            "content": (
                f"Processed retrieval context:\n{processed_context}\n\n"
                f"LLM output:\n{_format_llm_output(llm_output)}\n\n"
                "Applied priors:\n\n" + formatted_priors
            ),
        },
    ]
    parsed = infer_structured_json(
        messages=messages,
        tier=PRIOR_ADHERENCE_JUDGE_TIER,
        model=None,
        response_format=RESPONSE_FORMAT,
        repair_attempts=1,
        reasoning_effort=PRIOR_ADHERENCE_JUDGE_REASONING_EFFORT,
    )["parsed"]
    return _normalize_prior_adherence_result(parsed, prior_list)
