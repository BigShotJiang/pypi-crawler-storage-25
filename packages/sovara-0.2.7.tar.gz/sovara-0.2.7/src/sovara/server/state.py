"""
Server state management.

Holds all in-memory state, broadcasting logic, git versioning, and process spawning.
"""

import asyncio
import json
import os
import shlex
import shutil
import subprocess
import time
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Optional

from sovara.common.logger import create_file_logger
from sovara.common.constants import (
    MAIN_SERVER_LOG,
    SERVER_INACTIVITY_TIMEOUT,
    RUN_ORPHAN_TIMEOUT,
    SOVARA_GIT_DIR,
)
from sovara.server.database import DB
from sovara.server.graph_models import RunGraph

logger = create_file_logger(MAIN_SERVER_LOG)


class Run:
    """Represents a running so-record process."""

    def __init__(self, run_id: str, project_id: str = None, project_root: str = None):
        self.run_id = run_id
        self.project_id = project_id
        self.project_root = project_root
        self.status = "running"
        self.command: Optional[str] = None
        self.sse_connected = False
        self.registered_at = time.time()
        self.runtime_started_at: Optional[float] = None


class ServerState:
    """Manages all server state: runs, graphs, connections."""

    RUN_PAGE_SIZE = 50
    BROADCAST_DEBOUNCE_MS = 100

    def __init__(self):
        # Run state
        self.runs: dict[str, Run] = {}
        self.run_graphs: dict[str, RunGraph] = {}
        self.rerun_run_ids: set[str] = set()
        # Runtime checkpointing can happen inside add-node handling, which
        # already holds this lock while mutating run_graphs.
        self.lock = threading.RLock()

        # WebSocket connections
        self.ui_websockets: set = set()  # set of WebSocket connections

        # SSE queues for runners (run_id -> asyncio.Queue)
        self.runner_event_queues: dict[str, asyncio.Queue] = {}

        # Child service lifecycle status (e.g. inference server)
        self.service_statuses: dict[str, dict[str, str | None]] = {}

        # Inactivity tracking
        self._last_activity_time = time.time()

        # Debounced broadcast
        self._broadcast_timer: Optional[threading.Timer] = None
        self._broadcast_lock = threading.Lock()

        # asyncio loop reference (set during lifespan)
        self._loop: Optional[asyncio.AbstractEventLoop] = None

        # Reference to uvicorn.Server for clean shutdown via should_exit
        self._uvicorn_server = None

        # Git versioning
        self._git_available: Optional[bool] = None
        self._git_initialized_projects: set = set()
        self._git_base_dir = os.path.abspath(SOVARA_GIT_DIR)
        self._git_executor = ThreadPoolExecutor(max_workers=1)

        # Trace chat request tracking
        self._trace_chat_generation_by_run: dict[str, int] = {}
        self._trace_chat_active_generation: dict[str, int] = {}
        self._trace_chat_cancelled_generations: set[tuple[str, int]] = set()

        # Claude proxy client registrations keyed by run_id/client_id.
        self._claude_proxy_clients: dict[str, dict[str, dict[str, str]]] = {}
        self._claude_sdk_pending_tool_uses: dict[str, dict[str, dict[str, object]]] = {}

    def touch_activity(self):
        """Reset inactivity timer."""
        self._last_activity_time = time.time()

    def check_inactivity(self) -> bool:
        """Return True if server should shut down due to inactivity."""
        if self.ui_websockets:
            return False
        return (time.time() - self._last_activity_time) >= SERVER_INACTIVITY_TIMEOUT

    def request_shutdown(self) -> None:
        """Request a clean server shutdown via uvicorn's should_exit flag."""
        if self._uvicorn_server:
            logger.info("Setting uvicorn should_exit=True for clean shutdown")
            self._uvicorn_server.should_exit = True
        else:
            logger.warning("No uvicorn server reference, cannot shut down cleanly")

    def get_service_status_snapshot(self) -> dict[str, dict[str, str | None]]:
        with self.lock:
            return {
                service: {"status": payload.get("status"), "detail": payload.get("detail")}
                for service, payload in self.service_statuses.items()
            }

    def set_service_status(self, service: str, status: str, detail: str | None = None) -> None:
        with self.lock:
            next_payload = {"status": status, "detail": detail}
            if self.service_statuses.get(service) == next_payload:
                return
            self.service_statuses[service] = next_payload
        self.schedule_broadcast(
            {
                "type": "service_status",
                "service": service,
                "status": status,
                "detail": detail,
            }
        )

    # ============================================================
    # Broadcasting
    # ============================================================

    async def broadcast_to_all_uis(self, msg: dict) -> None:
        """Broadcast a message to all UI WebSocket connections."""
        data = json.dumps(msg)
        for ws in list(self.ui_websockets):
            try:
                await ws.send_text(data)
            except Exception as e:
                logger.error(f"Error broadcasting to UI: {e}")
                self.ui_websockets.discard(ws)

    async def broadcast_graph_update(self, run_id: str) -> None:
        """Broadcast current graph state for a run to all UIs."""
        if run_id in self.run_graphs:
            try:
                active_edit = DB.get_active_edit(run_id)
            except Exception:
                active_edit = None
            await self.broadcast_to_all_uis(
                {
                    "type": "graph_update",
                    "run_id": run_id,
                    "session_id": run_id,
                    "payload": self.run_graphs[run_id].to_metadata_dict(),
                    "active_runtime_seconds": self.get_persisted_active_runtime_seconds(run_id),
                    "active_edit": active_edit,
                }
            )

    def notify_project_list_changed(self) -> None:
        """Broadcast a signal so UIs refetch their project list."""
        self.schedule_broadcast({"type": "project_list_changed"})

    def notify_user_changed(self) -> None:
        """Broadcast a signal so UIs refetch the local user profile."""
        self.schedule_broadcast({"type": "user_changed"})

    def notify_db_settings_changed(self) -> None:
        """Broadcast a signal so UIs refetch the active DB configuration."""
        self.schedule_broadcast({"type": "db_settings_changed"})

    def notify_run_list_changed(self) -> None:
        """Schedule a debounced broadcast of the run list."""
        with self._broadcast_lock:
            if self._broadcast_timer is not None:
                self._broadcast_timer.cancel()
            self._broadcast_timer = threading.Timer(
                self.BROADCAST_DEBOUNCE_MS / 1000,
                self._trigger_broadcast,
            )
            self._broadcast_timer.daemon = True
            self._broadcast_timer.start()

    def _trigger_broadcast(self) -> None:
        """Called by debounce timer -- schedules async broadcast on the event loop."""
        if self._loop and self._loop.is_running():
            asyncio.run_coroutine_threadsafe(self.broadcast_run_list_to_uis(), self._loop)

    async def broadcast_run_list_to_uis(self) -> None:
        """Broadcast running + first page of finished runs to all UIs."""
        run_map, running_ids = self.get_run_snapshot()

        running_rows = DB.get_runs_by_ids(running_ids)
        finished_rows = DB.get_runs_excluding_ids(
            running_ids,
            limit=self.RUN_PAGE_SIZE,
        )
        finished_count = DB.get_run_count_excluding_ids(running_ids)
        has_more = finished_count > self.RUN_PAGE_SIZE

        runs = [self._format_run_row(row, run_map) for row in running_rows + finished_rows]
        await self.broadcast_to_all_uis({"type": "run_list", "runs": runs, "has_more": has_more})

    def _format_run_row(self, row, run_map) -> dict:
        """Convert a DB run row to a dict for the frontend."""
        row_dict = dict(row)
        run_id = row_dict["run_id"]
        run = run_map.get(run_id)
        status = run.status if run else "finished"

        timestamp = row_dict["timestamp"]
        if hasattr(timestamp, "isoformat"):
            timestamp = timestamp.isoformat()
        elif hasattr(timestamp, "strftime"):
            timestamp = timestamp.strftime("%Y-%m-%d %H:%M:%S")
        else:
            try:
                dt = datetime.strptime(str(timestamp), "%Y-%m-%d %H:%M:%S")
                timestamp = dt.isoformat()
            except Exception:
                pass

        return {
            "run_id": run_id,
            "session_id": run_id,
            "status": status,
            "timestamp": timestamp,
            "runtime_seconds": row_dict["runtime_seconds"],
            "active_runtime_seconds": row_dict["active_runtime_seconds"],
            "version_date": row_dict["version_date"],
            "name": row_dict["name"],
            "run_name": row_dict["name"],
            "custom_metrics": row_dict["custom_metrics"],
            "thumb_label": row_dict["thumb_label"],
            "tags": row_dict.get("tags", []),
            "project_id": row_dict.get("project_id") or (run.project_id if run else None),
        }

    # ============================================================
    # Helpers
    # ============================================================

    def begin_trace_chat_request(self, run_id: str) -> int:
        with self.lock:
            generation = self._trace_chat_generation_by_run.get(run_id, 0) + 1
            self._trace_chat_generation_by_run[run_id] = generation
            self._trace_chat_active_generation[run_id] = generation
            self._trace_chat_cancelled_generations.discard((run_id, generation))
            return generation

    def cancel_trace_chat_request(self, run_id: str) -> int | None:
        with self.lock:
            generation = self._trace_chat_active_generation.get(run_id)
            if generation is None:
                return None
            self._trace_chat_cancelled_generations.add((run_id, generation))
            return generation

    def is_trace_chat_request_current(self, run_id: str, generation: int) -> bool:
        with self.lock:
            return self._trace_chat_active_generation.get(run_id) == generation

    def is_trace_chat_request_cancelled(self, run_id: str, generation: int) -> bool:
        with self.lock:
            return (run_id, generation) in self._trace_chat_cancelled_generations

    def finish_trace_chat_request(self, run_id: str, generation: int) -> None:
        with self.lock:
            if self._trace_chat_active_generation.get(run_id) == generation:
                self._trace_chat_active_generation.pop(run_id, None)
            self._trace_chat_cancelled_generations.discard((run_id, generation))

    def _clear_run_ui(self, run_id: str) -> None:
        """Clear UI state for a run."""
        empty_graph = RunGraph.empty()
        self.run_graphs[run_id] = empty_graph
        DB.update_graph_topology(run_id, empty_graph)

    def clear_run_ui_and_schedule_broadcast(self, run_id: str) -> None:
        """Clear UI state and schedule broadcast updates."""
        self._clear_run_ui(run_id)
        empty_graph = self.run_graphs[run_id]
        self.schedule_broadcast(
            {
                "type": "graph_update",
                "run_id": run_id,
                "payload": empty_graph.to_dict(),
                "active_runtime_seconds": self.get_persisted_active_runtime_seconds(run_id),
                "active_edit": DB.get_active_edit(run_id),
            }
        )

    def start_run_attempt(
        self,
        run_id: str,
        project_id: str | None = None,
        project_root: str | None = None,
        clear_active_runtime: bool = True,
        reset_runner_connection: bool = False,
    ) -> Run:
        """Mark a run as actively running and reset its in-memory timer."""
        DB.reset_occurrence_counters(run_id=run_id)
        self.clear_claude_proxy_clients(run_id)
        self.clear_claude_sdk_pending_tool_uses(run_id)
        with self.lock:
            run = self.runs.get(run_id)
            if run is None:
                run = Run(run_id, project_id=project_id, project_root=project_root)
                self.runs[run_id] = run
            if project_id is not None:
                run.project_id = project_id
            if project_root is not None:
                run.project_root = project_root
            run.status = "running"
            run.runtime_started_at = time.perf_counter()
            if reset_runner_connection:
                run.sse_connected = False
                run.registered_at = time.time()
        DB.update_run_log(run_id, "")
        self.schedule_broadcast(
            {
                "type": "run_log_update",
                "run_id": run_id,
                "log_text": "",
                "replace": True,
            }
        )
        if clear_active_runtime:
            DB.clear_active_runtime_seconds(run_id)
        return run

    def register_claude_proxy_client(
        self,
        run_id: str,
        client_id: str,
        upstream_base_url: str,
        stack_trace: str | None = None,
    ) -> None:
        with self.lock:
            clients = self._claude_proxy_clients.setdefault(run_id, {})
            clients[client_id] = {
                "upstream_base_url": upstream_base_url,
                "stack_trace": stack_trace or "",
            }

    def get_claude_proxy_client(self, run_id: str, client_id: str) -> dict[str, str] | None:
        with self.lock:
            clients = self._claude_proxy_clients.get(run_id, {})
            client = clients.get(client_id)
            return dict(client) if client is not None else None

    def clear_claude_proxy_clients(self, run_id: str) -> None:
        with self.lock:
            self._claude_proxy_clients.pop(run_id, None)

    def register_claude_sdk_pending_tool_use(
        self,
        run_id: str,
        tool_use_id: str,
        payload: dict[str, object],
    ) -> None:
        with self.lock:
            pending = self._claude_sdk_pending_tool_uses.setdefault(run_id, {})
            pending[tool_use_id] = dict(payload)

    def pop_claude_sdk_pending_tool_use(
        self, run_id: str, tool_use_id: str
    ) -> dict[str, object] | None:
        with self.lock:
            pending = self._claude_sdk_pending_tool_uses.get(run_id, {})
            payload = pending.pop(tool_use_id, None)
            if not pending:
                self._claude_sdk_pending_tool_uses.pop(run_id, None)
            return dict(payload) if payload is not None else None

    def clear_claude_sdk_pending_tool_uses(self, run_id: str) -> None:
        with self.lock:
            self._claude_sdk_pending_tool_uses.pop(run_id, None)

    def get_live_runtime_seconds(self, run_id: str) -> float | None:
        """Return the current elapsed runtime for a running run."""
        with self.lock:
            run = self.runs.get(run_id)
            started_at = run.runtime_started_at if run else None
        if started_at is None:
            return None
        return max(0.0, time.perf_counter() - started_at)

    def get_persisted_active_runtime_seconds(self, run_id: str) -> float | None:
        """Return the last persisted active runtime checkpoint for a run."""
        row = DB.get_run_detail(run_id)
        if row is None:
            return None
        return row["active_runtime_seconds"]

    def checkpoint_run_runtime(self, run_id: str) -> float | None:
        """Persist the current runtime checkpoint for a live run."""
        elapsed = self.get_live_runtime_seconds(run_id)
        if elapsed is None:
            return None
        DB.update_active_runtime_seconds(run_id, elapsed)
        return elapsed

    def finalize_run_runtime(self, run_id: str) -> float | None:
        """Finalize the current run attempt and preserve the first canonical runtime."""
        elapsed = self.get_live_runtime_seconds(run_id)
        if elapsed is None:
            return None
        DB.finalize_runtime(run_id, elapsed)
        with self.lock:
            run = self.runs.get(run_id)
            if run:
                run.runtime_started_at = None
        return elapsed

    def checkpoint_interrupted_run_runtime(self, run_id: str) -> float | None:
        """Persist the best-known runtime for an interrupted attempt without finalizing it."""
        elapsed = self.get_live_runtime_seconds(run_id)
        if elapsed is None:
            return None
        DB.update_active_runtime_seconds(run_id, elapsed)
        with self.lock:
            run = self.runs.get(run_id)
            if run:
                run.runtime_started_at = None
        return elapsed

    def mark_active_edit_not_consumed(self, run_id: str) -> None:
        active_edit = DB.mark_active_edit_not_consumed(run_id)
        if active_edit is not None:
            self.schedule_graph_update(run_id)

    def sweep_dead_runs(self) -> list[str]:
        """Mark runs whose runner died before SSE connected as finished."""
        now = time.time()
        swept_run_ids: list[str] = []
        for run in list(self.runs.values()):
            if (
                run.status == "running"
                and run.run_id in self.runner_event_queues
                and not run.sse_connected
                and now - run.registered_at > RUN_ORPHAN_TIMEOUT
            ):
                logger.info(f"Sweeping orphaned run {run.run_id}")
                self.checkpoint_interrupted_run_runtime(run.run_id)
                self.mark_active_edit_not_consumed(run.run_id)
                run.status = "finished"
                self.runner_event_queues.pop(run.run_id, None)
                swept_run_ids.append(run.run_id)
        return swept_run_ids

    def get_run_snapshot(self) -> tuple[dict[str, Run], set[str]]:
        """Return a fresh snapshot of runs after reconciling orphaned runners."""
        self.sweep_dead_runs()
        with self.lock:
            run_map = dict(self.runs)
        running_ids = {rid for rid, run in run_map.items() if run.status == "running"}
        return run_map, running_ids

    def load_finished_runs(self) -> None:
        """Load finished runs from database into the in-memory run map."""
        try:
            rows = DB.get_finished_runs()
            for row in rows:
                run_id = row["run_id"]
                if run_id not in self.runs:
                    run = Run(run_id)
                    run.status = "finished"
                    self.runs[run_id] = run
        except Exception as e:
            logger.warning(f"Failed to load finished runs: {e}")

    # ============================================================
    # Git Versioning
    # ============================================================

    def _is_git_available(self) -> bool:
        if self._git_available is None:
            self._git_available = shutil.which("git") is not None
            if not self._git_available:
                logger.warning("git not found, code versioning disabled")
        return self._git_available

    def _git_dir_for_project(self, project_id: str) -> str:
        return os.path.join(self._git_base_dir, project_id)

    def _run_git(self, project_id: str, project_root: str, *args, check=True):
        git_dir = self._git_dir_for_project(project_id)
        env = os.environ.copy()
        env["GIT_DIR"] = git_dir
        env["GIT_WORK_TREE"] = project_root
        return subprocess.run(
            ["git"] + list(args),
            env=env,
            cwd=project_root,
            check=check,
            capture_output=True,
            text=True,
            timeout=30,
        )

    @staticmethod
    def _serialize_git_commit_timestamp(raw_timestamp: str) -> Optional[str]:
        try:
            dt = datetime.fromisoformat(raw_timestamp.strip())
        except ValueError:
            return None

        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)

        return DB.serialize_timestamp(dt.astimezone(timezone.utc))

    def _get_head_commit_timestamp(self, project_id: str, project_root: str) -> Optional[str]:
        result = self._run_git(project_id, project_root, "log", "-1", "--format=%cI", "HEAD")
        return self._serialize_git_commit_timestamp(result.stdout)

    def _ensure_git_initialized(self, project_id: str, project_root: str) -> bool:
        if project_id in self._git_initialized_projects:
            return True
        if not self._is_git_available():
            return False

        git_dir = self._git_dir_for_project(project_id)
        try:
            lock_file = os.path.join(git_dir, "index.lock")
            if os.path.exists(lock_file):
                os.remove(lock_file)
                logger.info(f"Removed stale git index.lock for project {project_id}")

            if os.path.exists(os.path.join(git_dir, "HEAD")):
                self._git_initialized_projects.add(project_id)
                return True

            os.makedirs(git_dir, exist_ok=True)
            self._run_git(project_id, project_root, "init")
            self._run_git(project_id, project_root, "config", "user.name", "Sovara Code Versioner")
            self._run_git(project_id, project_root, "config", "user.email", "sovara@localhost")
            self._git_initialized_projects.add(project_id)
            return True
        except (subprocess.SubprocessError, OSError) as e:
            logger.error(f"Failed to init git: {e}")
            return False

    def _commit_and_get_version_timestamp(
        self, project_id: str, project_root: str
    ) -> Optional[str]:
        if not self._ensure_git_initialized(project_id, project_root):
            return None
        try:
            self._run_git(project_id, project_root, "add", ".")
            result = self._run_git(
                project_id, project_root, "diff", "--cached", "--quiet", check=False
            )

            if result.returncode != 0:
                now = datetime.now(timezone.utc)
                self._run_git(
                    project_id, project_root, "commit", "-m", now.isoformat(timespec="seconds")
                )

            return self._get_head_commit_timestamp(project_id, project_root)
        except (subprocess.SubprocessError, subprocess.TimeoutExpired) as e:
            logger.error(f"Git operation failed: {e}")
            return None

    def _do_git_version(self, run_id: str, project_id: str, project_root: str) -> None:
        """Background thread: commit files and update run version_date."""
        version_date = self._commit_and_get_version_timestamp(project_id, project_root)
        if version_date:
            DB.update_run_version_date(run_id, version_date)
        self.notify_run_list_changed()

    def request_git_version(self, run_id: str, project_id: str, project_root: str) -> None:
        """Submit async git versioning in the background."""
        self._git_executor.submit(self._do_git_version, run_id, project_id, project_root)

    # ============================================================
    # Process Spawning
    # ============================================================

    def spawn_run_process(self, run_id: str, child_run_id: str) -> None:
        """Spawn a new run process with the original command and environment."""
        try:
            cwd, command, environment = DB.get_exec_command(run_id)
            if not command:
                return

            self.rerun_run_ids.add(child_run_id)

            env = os.environ.copy()
            env.update(environment)
            env.pop("SOVARA_ACTIVE_RUN", None)
            env.pop("SOVARA_REUSE_RUN_ID", None)
            env["SOVARA_RUN_ID"] = run_id
            env["SOVARA_REUSE_RUN_ID"] = "1"

            args = shlex.split(command)
            subprocess.Popen(args, cwd=cwd, env=env, close_fds=True, start_new_session=True)

            run = self.runs.get(child_run_id)
            if run:
                run.status = "running"
                DB.update_timestamp(child_run_id, datetime.now(timezone.utc))
                self.notify_run_list_changed()

        except Exception as e:
            logger.error(f"Failed to spawn run process: {e}")

    # ============================================================
    # Runner SSE events
    # ============================================================

    async def send_runner_event(self, run_id: str, event: dict) -> None:
        """Push an event to a runner's SSE queue."""
        q = self.runner_event_queues.get(run_id)
        if q:
            await q.put(event)
        else:
            logger.warning(f"No SSE queue for run {run_id}")

    # ============================================================
    # Sync scheduling helpers (for use from def endpoints in thread pool)
    # ============================================================

    def _can_schedule(self) -> bool:
        return self._loop is not None and self._loop.is_running()

    # Cosmetic: we only create the coroutine after checking the loop is running,
    # to avoid "coroutine was never awaited" RuntimeWarnings during startup/shutdown.

    def schedule_broadcast(self, msg: dict) -> None:
        """Schedule a broadcast to all UIs from sync context."""
        if self._can_schedule():
            asyncio.run_coroutine_threadsafe(self.broadcast_to_all_uis(msg), self._loop)

    def schedule_graph_update(self, run_id: str) -> None:
        """Schedule a graph update broadcast from sync context."""
        if self._can_schedule():
            asyncio.run_coroutine_threadsafe(self.broadcast_graph_update(run_id), self._loop)

    def schedule_runner_event(self, run_id: str, event: dict) -> None:
        """Schedule an SSE event push from sync context."""
        if self._can_schedule():
            asyncio.run_coroutine_threadsafe(self.send_runner_event(run_id, event), self._loop)
