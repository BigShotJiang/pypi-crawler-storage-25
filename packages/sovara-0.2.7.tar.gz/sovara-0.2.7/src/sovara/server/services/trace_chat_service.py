"""Trace chat orchestration and persistence helpers."""

import asyncio

from fastapi import HTTPException

from sovara.common.user import read_user_id
from sovara.server.database import DB
from sovara.server.graph_analysis import inference_server
from sovara.server.llm_settings import normalize_user_llm_settings_row
from sovara.server.state import ServerState, logger
from sovara.server.third_party_model_catalog import (
    derive_third_party_vendor,
    get_third_party_vendor_auth_type,
    requires_third_party_base_url,
)

TRACE_CHAT_CANCELED_DETAIL = "Trace chat canceled"
TRACE_CHAT_TIMEOUT_SECONDS = 120.0
TRACE_CHAT_UNAVAILABLE_DETAIL = "Trace chat service is not ready"
TRACE_CHAT_PRIMARY_SETUP_DETAIL = (
    "Trace chat needs Smart Primary Model set up first. "
    "Open Settings from the sidebar and finish setting up Smart Primary Model, then try again."
)


def _extract_http_error_detail(resp) -> str:
    try:
        data = resp.json()
    except ValueError:
        text = resp.text.strip()
        return text or "Chat error"

    if isinstance(data, dict):
        detail = data.get("detail")
        if isinstance(detail, str) and detail.strip():
            return detail
        error = data.get("error")
        if isinstance(error, str) and error.strip():
            return error

    return "Chat error"


def get_trace_chat_history(run_id: str) -> list[dict]:
    return DB.get_trace_chat_history(run_id)


def update_trace_chat_history(run_id: str, history: list[dict]) -> list[dict]:
    DB.update_trace_chat_history(run_id, history)
    return DB.get_trace_chat_history(run_id)


def clear_trace_chat_history(run_id: str) -> None:
    DB.clear_trace_chat_history(run_id)


def _trim_text(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    return stripped or None


def _trace_chat_primary_setup_detail() -> str | None:
    user_id = read_user_id()
    row = DB.get_user(user_id) if user_id else None
    settings = normalize_user_llm_settings_row(row)["primary"]

    if settings["connection_type"] == "locally_hosted":
        if _trim_text(settings.get("model_name")) and _trim_text(settings.get("base_url")):
            return None
        return TRACE_CHAT_PRIMARY_SETUP_DETAIL

    vendor = derive_third_party_vendor(settings.get("model_name"))
    auth_type = get_third_party_vendor_auth_type(vendor)
    if vendor is None or _trim_text(settings.get("model_name")) is None:
        return TRACE_CHAT_PRIMARY_SETUP_DETAIL
    if requires_third_party_base_url(vendor) and _trim_text(settings.get("base_url")) is None:
        return TRACE_CHAT_PRIMARY_SETUP_DETAIL
    if auth_type == "api_key" and _trim_text(settings.get("api_key")) is None:
        return TRACE_CHAT_PRIMARY_SETUP_DETAIL
    if auth_type == "aws_credentials" and (
        _trim_text(settings.get("aws_region")) is None
        or _trim_text(settings.get("aws_access_key_id")) is None
        or _trim_text(settings.get("aws_secret_access_key")) is None
    ):
        return TRACE_CHAT_PRIMARY_SETUP_DETAIL
    if auth_type == "vertex_credentials" and (
        _trim_text(settings.get("vertex_project")) is None
        or _trim_text(settings.get("vertex_location")) is None
    ):
        return TRACE_CHAT_PRIMARY_SETUP_DETAIL
    return None


async def _ensure_inference_server_ready() -> None:
    try:
        await asyncio.to_thread(inference_server.start)
    except Exception as exc:
        logger.error("Trace chat service could not start inference server: %s", exc)
        raise HTTPException(503, TRACE_CHAT_UNAVAILABLE_DETAIL) from exc


async def prefetch_trace(run_id: str, state: ServerState) -> dict[str, str]:
    run_map, _running_ids = state.get_run_snapshot()
    run = run_map.get(run_id)
    if run and run.status == "running":
        return {"status": "skipped", "reason": "run_still_active"}

    import httpx

    from sovara.common.constants import HOST, INFERENCE_PORT

    try:
        await _ensure_inference_server_ready()
    except HTTPException:
        return {"status": "skipped", "reason": "inference_unavailable"}

    async with httpx.AsyncClient() as client:
        try:
            await client.post(
                f"http://{HOST}:{INFERENCE_PORT}/prefetch/{run_id}",
                timeout=5.0,
            )
        except httpx.HTTPError as exc:
            logger.warning("Trace prefetch proxy failed for run %s: %s", run_id, exc)
            return {"status": "skipped", "reason": "inference_unavailable"}
    return {"status": "prefetching"}


async def chat_with_trace(
    run_id: str,
    message: str,
    history: list[dict],
    state: ServerState,
) -> dict:
    import httpx

    from sovara.common.constants import HOST, INFERENCE_PORT

    setup_detail = _trace_chat_primary_setup_detail()
    if setup_detail is not None:
        raise HTTPException(400, setup_detail)

    generation = state.begin_trace_chat_request(run_id)
    request_history = [*history, {"role": "user", "content": message}]
    response_history = list(history)

    def is_cancelled_or_stale() -> bool:
        return (
            state.is_trace_chat_request_cancelled(run_id, generation)
            or not state.is_trace_chat_request_current(run_id, generation)
        )

    async def request_answer() -> dict:
        await _ensure_inference_server_ready()
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    f"http://{HOST}:{INFERENCE_PORT}/chat/{run_id}",
                    json={"message": message, "history": history},
                    timeout=TRACE_CHAT_TIMEOUT_SECONDS,
                )
        except httpx.TimeoutException:
            if is_cancelled_or_stale():
                raise HTTPException(409, TRACE_CHAT_CANCELED_DETAIL) from None
            logger.error("Trace chat proxy timed out after %.1fs for run %s", TRACE_CHAT_TIMEOUT_SECONDS, run_id)
            raise HTTPException(
                504,
                f"Trace chat timed out after {int(TRACE_CHAT_TIMEOUT_SECONDS)} seconds",
            ) from None
        except httpx.HTTPError as exc:
            if is_cancelled_or_stale():
                raise HTTPException(409, TRACE_CHAT_CANCELED_DETAIL) from None
            logger.error("Trace chat proxy failed for run %s: %s", run_id, exc)
            raise HTTPException(502, "Could not reach inference server") from exc

        if resp.status_code != 200:
            detail = _extract_http_error_detail(resp)
            if is_cancelled_or_stale() or detail == TRACE_CHAT_CANCELED_DETAIL:
                raise HTTPException(409, TRACE_CHAT_CANCELED_DETAIL)
            raise HTTPException(resp.status_code, detail)

        try:
            return resp.json()
        except ValueError as exc:
            logger.error("Inference server returned invalid JSON for run %s", run_id)
            raise HTTPException(502, "Invalid response from inference server") from exc

    try:
        data = await request_answer()

        if is_cancelled_or_stale():
            raise HTTPException(409, TRACE_CHAT_CANCELED_DETAIL)

        answer = data.get("answer")
        if isinstance(answer, str):
            response_history = request_history + [{"role": "assistant", "content": answer}]
            try:
                response_history = update_trace_chat_history(
                    run_id,
                    response_history,
                )
            except Exception as exc:
                logger.warning("Trace chat post-persist failed for run %s: %s", run_id, exc)

        return {
            **data,
            "history": response_history,
        }
    finally:
        state.finish_trace_chat_request(run_id, generation)


async def abort_trace_chat(run_id: str, state: ServerState) -> dict[str, str]:
    import httpx

    from sovara.common.constants import HOST, INFERENCE_PORT

    generation = state.cancel_trace_chat_request(run_id)
    if generation is None:
        return {"status": "idle"}
    try:
        await _ensure_inference_server_ready()
        async with httpx.AsyncClient() as client:
            await client.post(
                f"http://{HOST}:{INFERENCE_PORT}/chat/{run_id}/abort",
                timeout=5.0,
            )
    except Exception as exc:
        logger.warning("Trace chat abort proxy failed for run %s: %s", run_id, exc)
    return {"status": "cancelling"}
