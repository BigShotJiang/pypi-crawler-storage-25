from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Literal
from urllib.parse import urlsplit, urlunsplit

import httpx

from sovara.common.constants import MAIN_SERVER_LOG
from sovara.common.logger import create_file_logger

LocalModelProvider = Literal[
    "vllm",
    "ollama",
    "huggingface",
    "llama_cpp",
    "localai",
    "lm_studio",
    "oobabooga",
    "fastchat",
    "openai_api_compatible",
]

logger = create_file_logger(MAIN_SERVER_LOG, logger_name="sovara.llm_provider_catalog")


@dataclass(frozen=True)
class LocalModelProviderSpec:
    key: LocalModelProvider
    label: str
    default_base_url: str
    litellm_model_prefix: str
    append_v1_to_base_url: bool


LOCAL_MODEL_PROVIDER_SPECS: tuple[LocalModelProviderSpec, ...] = (
    LocalModelProviderSpec(
        key="vllm",
        label="vLLM",
        default_base_url="http://localhost:8000/v1",
        litellm_model_prefix="hosted_vllm/",
        append_v1_to_base_url=True,
    ),
    LocalModelProviderSpec(
        key="ollama",
        label="Ollama",
        default_base_url="127.0.0.1:11434",
        litellm_model_prefix="ollama_chat/",
        append_v1_to_base_url=False,
    ),
    LocalModelProviderSpec(
        key="huggingface",
        label="Hugging Face TGI",
        default_base_url="127.0.0.1:8000",
        litellm_model_prefix="huggingface/",
        append_v1_to_base_url=False,
    ),
    LocalModelProviderSpec(
        key="llama_cpp",
        label="llama.cpp",
        default_base_url="127.0.0.1:8080",
        litellm_model_prefix="openai/",
        append_v1_to_base_url=True,
    ),
    LocalModelProviderSpec(
        key="localai",
        label="LocalAI",
        default_base_url="http://localhost:8080/v1",
        litellm_model_prefix="openai/",
        append_v1_to_base_url=True,
    ),
    LocalModelProviderSpec(
        key="lm_studio",
        label="LM Studio",
        default_base_url="127.0.0.1:1234",
        litellm_model_prefix="lm_studio/",
        append_v1_to_base_url=True,
    ),
    LocalModelProviderSpec(
        key="oobabooga",
        label="oobabooga",
        default_base_url="http://127.0.0.1:7860",
        litellm_model_prefix="oobabooga/",
        append_v1_to_base_url=False,
    ),
    LocalModelProviderSpec(
        key="fastchat",
        label="FastChat",
        default_base_url="127.0.0.1:8000",
        litellm_model_prefix="openai/",
        append_v1_to_base_url=True,
    ),
    LocalModelProviderSpec(
        key="openai_api_compatible",
        label="Other (uses OpenAI API)",
        default_base_url="127.0.0.1:8000",
        litellm_model_prefix="openai/",
        append_v1_to_base_url=True,
    ),
)

DEFAULT_LOCAL_MODEL_PROVIDER: LocalModelProvider = LOCAL_MODEL_PROVIDER_SPECS[0].key

LOCAL_MODEL_PROVIDER_BY_KEY: dict[LocalModelProvider, LocalModelProviderSpec] = {
    spec.key: spec for spec in LOCAL_MODEL_PROVIDER_SPECS
}

LOCAL_MODEL_INPUT_PREFIXES: tuple[str, ...] = tuple(
    dict.fromkeys(
        [spec.litellm_model_prefix for spec in LOCAL_MODEL_PROVIDER_SPECS]
        + ["vllm/", "ollama/", "llamafile/"]
    )
)
LOCAL_MODEL_DISCOVERY_TIMEOUT_SECONDS = 3.0


def _trim_text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    return stripped or None


def normalize_local_model_provider(value: Any) -> LocalModelProvider:
    if isinstance(value, str) and value in LOCAL_MODEL_PROVIDER_BY_KEY:
        return value
    return DEFAULT_LOCAL_MODEL_PROVIDER


def strip_local_model_prefix(model_name: str | None) -> str | None:
    trimmed = _trim_text(model_name)
    if not trimmed:
        return None
    for prefix in LOCAL_MODEL_INPUT_PREFIXES:
        if trimmed.startswith(prefix):
            return trimmed[len(prefix) :]
    return trimmed


def build_litellm_local_model_name(local_provider: LocalModelProvider, model_name: str) -> str:
    normalized_model_name = strip_local_model_prefix(model_name) or model_name.strip()
    prefix = LOCAL_MODEL_PROVIDER_BY_KEY[local_provider].litellm_model_prefix
    return f"{prefix}{normalized_model_name}"


def normalize_local_base_url(local_provider: LocalModelProvider, base_url: str | None) -> str | None:
    trimmed = _trim_text(base_url)
    if not trimmed:
        return None

    with_scheme = trimmed if "://" in trimmed else f"http://{trimmed}"
    parsed = urlsplit(with_scheme)
    path = parsed.path.rstrip("/")
    if LOCAL_MODEL_PROVIDER_BY_KEY[local_provider].append_v1_to_base_url:
        if not path:
            path = "/v1"
    else:
        path = path or ""
    return urlunsplit((parsed.scheme or "http", parsed.netloc, path, "", ""))


def serialize_local_model_provider_specs() -> list[dict[str, Any]]:
    return [
        {
            "value": spec.key,
            "label": spec.label,
            "default_base_url": spec.default_base_url,
            "append_v1_to_base_url": spec.append_v1_to_base_url,
            "supports_model_discovery": supports_local_model_discovery(spec.key),
        }
        for spec in LOCAL_MODEL_PROVIDER_SPECS
    ]


def supports_local_model_discovery(local_provider: LocalModelProvider) -> bool:
    return local_provider in LOCAL_MODEL_DISCOVERY_FETCHERS


def _normalize_discovered_model_names(values: Iterable[Any]) -> list[str]:
    normalized: dict[str, None] = {}
    for value in values:
        trimmed = _trim_text(value)
        if trimmed:
            normalized[trimmed] = None
    return list(normalized)


def _fetch_ollama_model_names(base_url: str) -> list[str]:
    response = httpx.get(
        f"{base_url.rstrip('/')}/api/tags",
        timeout=LOCAL_MODEL_DISCOVERY_TIMEOUT_SECONDS,
        follow_redirects=True,
    )
    response.raise_for_status()
    payload = response.json()
    models = payload.get("models")
    if not isinstance(models, list):
        return []
    return _normalize_discovered_model_names(
        model.get("name") if isinstance(model, dict) else model
        for model in models
    )


def _fetch_openai_style_model_names(base_url: str) -> list[str]:
    response = httpx.get(
        f"{base_url.rstrip('/')}/models",
        timeout=LOCAL_MODEL_DISCOVERY_TIMEOUT_SECONDS,
        follow_redirects=True,
    )
    response.raise_for_status()
    payload = response.json()
    models = payload.get("data")
    if not isinstance(models, list):
        return []
    return _normalize_discovered_model_names(
        model.get("id") if isinstance(model, dict) else model
        for model in models
    )


LOCAL_MODEL_DISCOVERY_FETCHERS: dict[LocalModelProvider, Any] = {
    "ollama": _fetch_ollama_model_names,
    "vllm": _fetch_openai_style_model_names,
    "llama_cpp": _fetch_openai_style_model_names,
    "localai": _fetch_openai_style_model_names,
    "lm_studio": _fetch_openai_style_model_names,
}


def discover_local_model_names(
    local_provider: LocalModelProvider,
    base_url: str | None,
) -> tuple[str, list[str]]:
    provider_spec = LOCAL_MODEL_PROVIDER_BY_KEY[local_provider]
    normalized_base_url = normalize_local_base_url(
        local_provider,
        base_url or provider_spec.default_base_url,
    )
    if not normalized_base_url:
        raise ValueError("Endpoint is required for Locally hosted.")
    if not supports_local_model_discovery(local_provider):
        raise ValueError(f"Model discovery is not supported for {provider_spec.label}.")

    try:
        fetch_model_names = LOCAL_MODEL_DISCOVERY_FETCHERS[local_provider]
        return normalized_base_url, fetch_model_names(normalized_base_url)
    except Exception as exc:
        logger.warning(
            "local model discovery failed local_provider=%s base_url=%s detail=%s",
            local_provider,
            normalized_base_url,
            exc,
        )
        raise
