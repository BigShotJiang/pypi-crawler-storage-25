from __future__ import annotations

from copy import deepcopy
from typing import Any, Literal, Mapping, TypedDict, cast
from urllib.parse import urlsplit, urlunsplit

from sovara.server.llm_provider_catalog import (
    DEFAULT_LOCAL_MODEL_PROVIDER,
    LocalModelProvider,
    build_litellm_local_model_name,
    normalize_local_base_url,
    normalize_local_model_provider,
    strip_local_model_prefix,
)
from sovara.server.third_party_model_catalog import (
    derive_third_party_vendor,
    get_third_party_vendor_auth_type,
    requires_third_party_base_url,
    uses_openai_compatible_third_party_runtime,
)

LLMConnectionType = Literal["third_party_api", "locally_hosted"]
LegacyLlmProvider = Literal["anthropic", "together", "hosted_vllm"]
TierName = Literal["primary", "helper", "ultra_helper", "embedding", "reranker"]
InferTier = Literal["expensive", "cheap", "ultra-cheap"]
USER_LLM_TIERS: tuple[TierName, ...] = ("primary", "helper", "ultra_helper", "embedding", "reranker")
INFER_TIER_TO_SETTINGS_TIER: dict[InferTier, TierName] = {
    "expensive": "primary",
    "cheap": "helper",
    "ultra-cheap": "ultra_helper",
}


class UserLlmTierSettings(TypedDict):
    connection_type: LLMConnectionType
    local_provider: LocalModelProvider
    model_name: str
    api_key: str | None
    aws_region: str | None
    aws_access_key_id: str | None
    aws_secret_access_key: str | None
    vertex_project: str | None
    vertex_location: str | None
    vertex_credentials: str | None
    base_url: str | None


class UserLlmSettings(TypedDict):
    primary: UserLlmTierSettings
    helper: UserLlmTierSettings
    ultra_helper: UserLlmTierSettings
    embedding: UserLlmTierSettings
    reranker: UserLlmTierSettings


API_KEY_PREVIEW_MASK = "*" * 16
API_KEY_PREVIEW_VISIBLE_CHARS = 3
TIER_DB_FIELD_NAMES = (
    "connection_type",
    "local_provider",
    "model_name",
    "api_key",
    "aws_region",
    "aws_access_key_id",
    "aws_secret_access_key",
    "vertex_project",
    "vertex_location",
    "vertex_credentials",
    "base_url",
)


def _tier_db_columns(prefix: TierName) -> dict[str, str]:
    return {field: f"llm_{prefix}_{field}" for field in TIER_DB_FIELD_NAMES}


def _legacy_tier_db_columns(prefix: TierName) -> dict[str, str]:
    return {
        "provider": f"llm_{prefix}_provider",
        "api_base": f"llm_{prefix}_api_base",
        "ip": f"llm_{prefix}_ip",
    }


DEFAULT_USER_LLM_SETTINGS: UserLlmSettings = {
    "primary": {
        "connection_type": "third_party_api",
        "local_provider": DEFAULT_LOCAL_MODEL_PROVIDER,
        "model_name": "together_ai/Qwen/Qwen3.5-397B-A17B",
        "api_key": None,
        "aws_region": None,
        "aws_access_key_id": None,
        "aws_secret_access_key": None,
        "vertex_project": None,
        "vertex_location": None,
        "vertex_credentials": None,
        "base_url": None,
    },
    "helper": {
        "connection_type": "third_party_api",
        "local_provider": DEFAULT_LOCAL_MODEL_PROVIDER,
        "model_name": "together_ai/Qwen/Qwen3.5-9B",
        "api_key": None,
        "aws_region": None,
        "aws_access_key_id": None,
        "aws_secret_access_key": None,
        "vertex_project": None,
        "vertex_location": None,
        "vertex_credentials": None,
        "base_url": None,
    },
    "ultra_helper": {
        "connection_type": "third_party_api",
        "local_provider": DEFAULT_LOCAL_MODEL_PROVIDER,
        "model_name": "together_ai/Qwen/Qwen3.5-9B",
        "api_key": None,
        "aws_region": None,
        "aws_access_key_id": None,
        "aws_secret_access_key": None,
        "vertex_project": None,
        "vertex_location": None,
        "vertex_credentials": None,
        "base_url": None,
    },
    "embedding": {
        "connection_type": "third_party_api",
        "local_provider": DEFAULT_LOCAL_MODEL_PROVIDER,
        "model_name": "cohere/embed-v4.0",
        "api_key": None,
        "aws_region": None,
        "aws_access_key_id": None,
        "aws_secret_access_key": None,
        "vertex_project": None,
        "vertex_location": None,
        "vertex_credentials": None,
        "base_url": None,
    },
    "reranker": {
        "connection_type": "third_party_api",
        "local_provider": DEFAULT_LOCAL_MODEL_PROVIDER,
        "model_name": "cohere/rerank-v3.5",
        "api_key": None,
        "aws_region": None,
        "aws_access_key_id": None,
        "aws_secret_access_key": None,
        "vertex_project": None,
        "vertex_location": None,
        "vertex_credentials": None,
        "base_url": None,
    },
}

USER_LLM_DB_COLUMNS = {tier: _tier_db_columns(tier) for tier in USER_LLM_TIERS}

LEGACY_USER_LLM_DB_COLUMNS = {tier: _legacy_tier_db_columns(tier) for tier in USER_LLM_TIERS}

LEGACY_PROVIDER_MODEL_PREFIXES: dict[LegacyLlmProvider, str] = {
    "anthropic": "anthropic",
    "together": "together_ai",
    "hosted_vllm": "hosted_vllm",
}

LOCAL_MODEL_DEFAULTS: dict[TierName, str] = {
    "primary": "Meta-Llama-3.1-70B-Instruct",
    "helper": "Meta-Llama-3.1-8B-Instruct",
    "ultra_helper": "Meta-Llama-3.1-8B-Instruct",
    "embedding": "nomic-embed-text",
    "reranker": "bge-reranker-v2-m3",
}

LEGACY_PROVIDER_DEFAULT_MODELS: dict[TierName, dict[Literal["anthropic", "together"], str]] = {
    "primary": {
        "anthropic": "anthropic/claude-sonnet-4-5",
        "together": "together_ai/Qwen/Qwen3.5-397B-A17B",
    },
    "helper": {
        "anthropic": "anthropic/claude-haiku-4-5",
        "together": "together_ai/Qwen/Qwen3.5-9B",
    },
    "ultra_helper": {
        "anthropic": "anthropic/claude-haiku-4-5",
        "together": "together_ai/Qwen/Qwen3.5-9B",
    },
    "embedding": {
        "anthropic": "cohere/embed-v4.0",
        "together": "cohere/embed-v4.0",
    },
    "reranker": {
        "anthropic": "cohere/rerank-v3.5",
        "together": "cohere/rerank-v3.5",
    },
}


def _trim_text(value: Any) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    return stripped or None


def build_secret_preview(secret: str | None) -> str | None:
    trimmed = _trim_text(secret)
    if not trimmed:
        return None
    if trimmed.startswith("sk-"):
        visible = trimmed[3 : 3 + API_KEY_PREVIEW_VISIBLE_CHARS]
        return f"sk-{visible}{API_KEY_PREVIEW_MASK}"
    return f"{trimmed[:API_KEY_PREVIEW_VISIBLE_CHARS]}{API_KEY_PREVIEW_MASK}"


def build_api_key_preview(api_key: str | None) -> str | None:
    return build_secret_preview(api_key)


def third_party_runtime_model_name(model_name: str | None, vendor: str | None) -> str | None:
    trimmed_model_name = _trim_text(model_name)
    trimmed_vendor = _trim_text(vendor)
    if not trimmed_model_name:
        return None
    if not uses_openai_compatible_third_party_runtime(trimmed_vendor):
        return trimmed_model_name
    prefix = f"{trimmed_vendor}/"
    if trimmed_vendor and trimmed_model_name.startswith(prefix):
        return trimmed_model_name[len(prefix) :]
    return trimmed_model_name


def _mapping_get(row: Mapping[str, Any], key: str) -> Any:
    try:
        return row[key]
    except (KeyError, IndexError, TypeError):
        return None


def _legacy_api_base_to_base_url(api_base: str | None) -> str | None:
    trimmed = _trim_text(api_base)
    if not trimmed:
        return None
    if "://" not in trimmed:
        return trimmed.removesuffix("/v1").rstrip("/") or trimmed
    parsed = urlsplit(trimmed)
    path = parsed.path.rstrip("/")
    if path == "/v1":
        path = ""
    return urlunsplit((parsed.scheme, parsed.netloc, path, "", ""))


def _normalize_current_row_tier(row: Mapping[str, Any], tier: TierName) -> UserLlmTierSettings:
    default_tier = DEFAULT_USER_LLM_SETTINGS[tier]
    db_columns = USER_LLM_DB_COLUMNS[tier]
    raw_connection_type = _trim_text(_mapping_get(row, db_columns["connection_type"]))

    if raw_connection_type == "third_party_api":
        model_name = _trim_text(_mapping_get(row, db_columns["model_name"])) or default_tier["model_name"]
        vendor = derive_third_party_vendor(model_name)
        auth_type = get_third_party_vendor_auth_type(vendor)
        return {
            "connection_type": "third_party_api",
            "local_provider": normalize_local_model_provider(_mapping_get(row, db_columns["local_provider"])),
            "model_name": model_name,
            "api_key": (
                _trim_text(_mapping_get(row, db_columns["api_key"]))
                if auth_type == "api_key"
                else None
            ),
            "aws_region": (
                _trim_text(_mapping_get(row, db_columns["aws_region"]))
                if auth_type == "aws_credentials"
                else None
            ),
            "aws_access_key_id": (
                _trim_text(_mapping_get(row, db_columns["aws_access_key_id"]))
                if auth_type == "aws_credentials"
                else None
            ),
            "aws_secret_access_key": (
                _trim_text(_mapping_get(row, db_columns["aws_secret_access_key"]))
                if auth_type == "aws_credentials"
                else None
            ),
            "vertex_project": (
                _trim_text(_mapping_get(row, db_columns["vertex_project"]))
                if auth_type == "vertex_credentials"
                else None
            ),
            "vertex_location": (
                _trim_text(_mapping_get(row, db_columns["vertex_location"]))
                if auth_type == "vertex_credentials"
                else None
            ),
            "vertex_credentials": (
                _trim_text(_mapping_get(row, db_columns["vertex_credentials"]))
                if auth_type == "vertex_credentials"
                else None
            ),
            "base_url": (
                _trim_text(_mapping_get(row, db_columns["base_url"]))
                if requires_third_party_base_url(vendor)
                else None
            ),
        }

    if raw_connection_type == "locally_hosted":
        return {
            "connection_type": "locally_hosted",
            "local_provider": normalize_local_model_provider(_mapping_get(row, db_columns["local_provider"])),
            "model_name": strip_local_model_prefix(_mapping_get(row, db_columns["model_name"]))
            or LOCAL_MODEL_DEFAULTS[tier],
            "api_key": None,
            "aws_region": None,
            "aws_access_key_id": None,
            "aws_secret_access_key": None,
            "vertex_project": None,
            "vertex_location": None,
            "vertex_credentials": None,
            "base_url": _trim_text(_mapping_get(row, db_columns["base_url"])),
        }

    return deepcopy(default_tier)


def _migrate_legacy_row_tier(row: Mapping[str, Any], tier: TierName) -> UserLlmTierSettings:
    default_tier = DEFAULT_USER_LLM_SETTINGS[tier]
    legacy_columns = LEGACY_USER_LLM_DB_COLUMNS[tier]
    raw_provider = _trim_text(_mapping_get(row, legacy_columns["provider"]))
    legacy_api_base = _trim_text(_mapping_get(row, legacy_columns["api_base"]))
    legacy_ip = _trim_text(_mapping_get(row, legacy_columns["ip"]))
    model_name = _trim_text(_mapping_get(row, USER_LLM_DB_COLUMNS[tier]["model_name"]))

    if legacy_ip or raw_provider == "hosted_vllm":
        return {
            "connection_type": "locally_hosted",
            "local_provider": DEFAULT_LOCAL_MODEL_PROVIDER,
            "model_name": strip_local_model_prefix(model_name) or LOCAL_MODEL_DEFAULTS[tier],
            "api_key": None,
            "aws_region": None,
            "aws_access_key_id": None,
            "aws_secret_access_key": None,
            "vertex_project": None,
            "vertex_location": None,
            "vertex_credentials": None,
            "base_url": legacy_ip or _legacy_api_base_to_base_url(legacy_api_base),
        }

    if raw_provider in {"anthropic", "together"}:
        legacy_prefix = LEGACY_PROVIDER_MODEL_PREFIXES[raw_provider]
        resolved_model_name = model_name or LEGACY_PROVIDER_DEFAULT_MODELS[tier][raw_provider]
        if not resolved_model_name.startswith(f"{legacy_prefix}/"):
            resolved_model_name = f"{legacy_prefix}/{resolved_model_name}"
        return {
            "connection_type": "third_party_api",
            "local_provider": DEFAULT_LOCAL_MODEL_PROVIDER,
            "model_name": resolved_model_name,
            "api_key": None,
            "aws_region": None,
            "aws_access_key_id": None,
            "aws_secret_access_key": None,
            "vertex_project": None,
            "vertex_location": None,
            "vertex_credentials": None,
            "base_url": None,
        }

    return deepcopy(default_tier)


def normalize_user_llm_settings_row(row: Mapping[str, Any] | None) -> UserLlmSettings:
    if row is None:
        return deepcopy(DEFAULT_USER_LLM_SETTINGS)

    return {tier: _normalize_current_row_tier(row, tier) for tier in USER_LLM_TIERS}


def migrate_user_llm_settings_row(row: Mapping[str, Any] | None) -> UserLlmSettings:
    settings = normalize_user_llm_settings_row(row)
    if row is None:
        return settings

    for tier in USER_LLM_TIERS:
        db_columns = USER_LLM_DB_COLUMNS[tier]
        if _trim_text(_mapping_get(row, db_columns["connection_type"])) in {"third_party_api", "locally_hosted"}:
            continue
        settings[tier] = _migrate_legacy_row_tier(row, tier)
    return settings


def serialize_user_llm_settings_for_client(settings: Mapping[str, Mapping[str, Any]]) -> dict[str, dict[str, Any]]:
    serialized = deepcopy(settings)
    for tier in USER_LLM_TIERS:
        tier_settings = serialized[tier]
        vendor = (
            derive_third_party_vendor(tier_settings.get("model_name"))
            if tier_settings.get("connection_type") == "third_party_api"
            else None
        )
        auth_type = get_third_party_vendor_auth_type(vendor)
        api_key = (
            _trim_text(tier_settings.get("api_key"))
            if tier_settings.get("connection_type") == "third_party_api" and auth_type == "api_key"
            else None
        )
        aws_region = (
            _trim_text(tier_settings.get("aws_region"))
            if tier_settings.get("connection_type") == "third_party_api" and auth_type == "aws_credentials"
            else None
        )
        aws_access_key_id = (
            _trim_text(tier_settings.get("aws_access_key_id"))
            if tier_settings.get("connection_type") == "third_party_api" and auth_type == "aws_credentials"
            else None
        )
        aws_secret_access_key = (
            _trim_text(tier_settings.get("aws_secret_access_key"))
            if tier_settings.get("connection_type") == "third_party_api" and auth_type == "aws_credentials"
            else None
        )
        vertex_project = (
            _trim_text(tier_settings.get("vertex_project"))
            if tier_settings.get("connection_type") == "third_party_api" and auth_type == "vertex_credentials"
            else None
        )
        vertex_location = (
            _trim_text(tier_settings.get("vertex_location"))
            if tier_settings.get("connection_type") == "third_party_api" and auth_type == "vertex_credentials"
            else None
        )
        vertex_credentials = (
            _trim_text(tier_settings.get("vertex_credentials"))
            if tier_settings.get("connection_type") == "third_party_api" and auth_type == "vertex_credentials"
            else None
        )
        tier_settings["api_key"] = None
        tier_settings["aws_region"] = aws_region
        tier_settings["aws_access_key_id"] = None
        tier_settings["aws_secret_access_key"] = None
        tier_settings["vertex_project"] = vertex_project
        tier_settings["vertex_location"] = vertex_location
        tier_settings["vertex_credentials"] = None
        tier_settings["third_party_vendor"] = vendor
        tier_settings["has_api_key"] = api_key is not None
        tier_settings["api_key_preview"] = build_secret_preview(api_key)
        tier_settings["has_aws_access_key_id"] = aws_access_key_id is not None
        tier_settings["aws_access_key_id_preview"] = build_secret_preview(aws_access_key_id)
        tier_settings["has_aws_secret_access_key"] = aws_secret_access_key is not None
        tier_settings["aws_secret_access_key_preview"] = build_secret_preview(aws_secret_access_key)
        tier_settings["has_vertex_credentials"] = vertex_credentials is not None
        tier_settings["vertex_credentials_preview"] = build_secret_preview(vertex_credentials)
        tier_settings.pop("clear_api_key", None)
        tier_settings.pop("clear_aws_access_key_id", None)
        tier_settings.pop("clear_aws_secret_access_key", None)
    return serialized


def flatten_user_llm_settings(settings: Mapping[str, Mapping[str, Any]]) -> dict[str, str | None]:
    flattened: dict[str, str | None] = {}
    for tier in USER_LLM_TIERS:
        tier_settings = settings[tier]
        db_columns = USER_LLM_DB_COLUMNS[tier]
        connection_type = tier_settings["connection_type"]
        vendor = (
            _trim_text(tier_settings.get("third_party_vendor"))
            or derive_third_party_vendor(tier_settings.get("model_name"))
        )
        auth_type = get_third_party_vendor_auth_type(vendor) if connection_type == "third_party_api" else "api_key"

        flattened[db_columns["connection_type"]] = connection_type
        flattened[db_columns["local_provider"]] = normalize_local_model_provider(tier_settings.get("local_provider"))
        flattened[db_columns["model_name"]] = _trim_text(tier_settings.get("model_name")) or DEFAULT_USER_LLM_SETTINGS[tier]["model_name"]
        flattened[db_columns["api_key"]] = (
            _trim_text(tier_settings.get("api_key"))
            if connection_type == "third_party_api" and auth_type == "api_key"
            else None
        )
        flattened[db_columns["aws_region"]] = (
            _trim_text(tier_settings.get("aws_region"))
            if connection_type == "third_party_api" and auth_type == "aws_credentials"
            else None
        )
        flattened[db_columns["aws_access_key_id"]] = (
            _trim_text(tier_settings.get("aws_access_key_id"))
            if connection_type == "third_party_api" and auth_type == "aws_credentials"
            else None
        )
        flattened[db_columns["aws_secret_access_key"]] = (
            _trim_text(tier_settings.get("aws_secret_access_key"))
            if connection_type == "third_party_api" and auth_type == "aws_credentials"
            else None
        )
        flattened[db_columns["vertex_project"]] = (
            _trim_text(tier_settings.get("vertex_project"))
            if connection_type == "third_party_api" and auth_type == "vertex_credentials"
            else None
        )
        flattened[db_columns["vertex_location"]] = (
            _trim_text(tier_settings.get("vertex_location"))
            if connection_type == "third_party_api" and auth_type == "vertex_credentials"
            else None
        )
        flattened[db_columns["vertex_credentials"]] = (
            _trim_text(tier_settings.get("vertex_credentials"))
            if connection_type == "third_party_api" and auth_type == "vertex_credentials"
            else None
        )
        flattened[db_columns["base_url"]] = (
            _trim_text(tier_settings.get("base_url"))
            if connection_type == "locally_hosted"
            or (connection_type == "third_party_api" and requires_third_party_base_url(vendor))
            else None
        )
    return flattened


def build_litellm_request_config(
    row: Mapping[str, Any] | None,
    tier: InferTier | str = "expensive",
) -> dict[str, str]:
    settings = normalize_user_llm_settings_row(row)
    tier_name = INFER_TIER_TO_SETTINGS_TIER.get(cast(InferTier, tier))
    if tier_name is None and tier in USER_LLM_TIERS:
        tier_name = cast(TierName, tier)
    if tier_name is None:
        tier_name = "primary"
    tier_settings = settings[tier_name]

    if tier_settings["connection_type"] == "locally_hosted":
        local_provider = tier_settings["local_provider"]
        request_config = {
            "model": build_litellm_local_model_name(local_provider, tier_settings["model_name"]),
        }
        base_url = normalize_local_base_url(local_provider, tier_settings["base_url"])
        if base_url:
            request_config["api_base"] = base_url
        return request_config

    vendor = derive_third_party_vendor(tier_settings["model_name"])
    request_config = {
        "model": third_party_runtime_model_name(tier_settings["model_name"], vendor) or tier_settings["model_name"],
    }
    auth_type = get_third_party_vendor_auth_type(vendor)
    if uses_openai_compatible_third_party_runtime(vendor):
        request_config["custom_llm_provider"] = "openai"
    elif vendor:
        request_config["custom_llm_provider"] = vendor
    if auth_type == "api_key" and tier_settings["api_key"]:
        request_config["api_key"] = tier_settings["api_key"]
    if requires_third_party_base_url(vendor) and tier_settings["base_url"]:
        request_config["api_base"] = tier_settings["base_url"]
    if auth_type == "aws_credentials":
        if tier_settings["aws_region"]:
            request_config["aws_region_name"] = tier_settings["aws_region"]
        if tier_settings["aws_access_key_id"]:
            request_config["aws_access_key_id"] = tier_settings["aws_access_key_id"]
        if tier_settings["aws_secret_access_key"]:
            request_config["aws_secret_access_key"] = tier_settings["aws_secret_access_key"]
    if auth_type == "vertex_credentials":
        if tier_settings["vertex_project"]:
            request_config["vertex_project"] = tier_settings["vertex_project"]
        if tier_settings["vertex_location"]:
            request_config["vertex_location"] = tier_settings["vertex_location"]
        if tier_settings["vertex_credentials"]:
            request_config["vertex_credentials"] = tier_settings["vertex_credentials"]
    return request_config
