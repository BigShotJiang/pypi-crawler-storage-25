"""Handlers for messages received from the UI.

These operate on ServerState and have no socket dependencies.
Broadcasting is handled by the route/events layer after calling these handlers.
"""

import json

from sovara.server.database import DB
from sovara.server.graph_models import RunGraph
from sovara.server.handlers.handler_utils import logger


def _load_graph_for_edit(state, run_id: str) -> RunGraph | None:
    """Return a mutable graph for a run, loading it from DB if needed."""
    graph = state.run_graphs.get(run_id)
    if graph is not None:
        return graph

    row = DB.get_graph(run_id)
    if not row or not row["graph_topology"]:
        return None

    graph = RunGraph.from_json_string(row["graph_topology"])
    state.run_graphs[run_id] = graph
    return graph


def _to_show_json(payload: str | None) -> str | None:
    if not payload:
        return None
    try:
        parsed = json.loads(payload)
    except (TypeError, json.JSONDecodeError):
        return None
    to_show = parsed.get("to_show")
    if to_show is None:
        return None
    return json.dumps(to_show)


def handle_edit_input(state, msg: dict) -> None:
    """Handle input edit from UI."""
    run_id = msg["run_id"]
    node_uuid = msg["node_uuid"]
    new_input = msg["value"]

    graph = _load_graph_for_edit(state, run_id)
    node_label = node_uuid
    node = None
    if graph:
        node = graph.get_node_by_uuid(node_uuid)
        if node:
            node_label = node.label

    overwrite = DB.set_input_overwrite(run_id, node_uuid, new_input, node_label=node_label)
    if overwrite and graph:
        if node:
            node.input = new_input  # graph stores to_show for display
            node.llm_verdict = None
        DB.update_graph_topology(run_id, graph)


def handle_edit_output(state, msg: dict) -> None:
    """Handle output edit from UI."""
    run_id = msg["run_id"]
    node_uuid = msg["node_uuid"]
    new_output = msg["value"]

    graph = _load_graph_for_edit(state, run_id)
    node_label = node_uuid
    node = None
    if graph:
        node = graph.get_node_by_uuid(node_uuid)
        if node:
            node_label = node.label

    overwrite = DB.set_output_overwrite(run_id, node_uuid, new_output, node_label=node_label)
    if overwrite and graph:
        if node:
            node.output = new_output  # graph stores to_show for display
            node.llm_verdict = None
        DB.update_graph_topology(run_id, graph)


def handle_discard_active_edit(state, run_id: str) -> dict | None:
    active_edit = DB.discard_active_edit(run_id)
    if active_edit is None:
        return None

    graph = _load_graph_for_edit(state, run_id)
    if graph:
        node = graph.get_node_by_uuid(active_edit["node_uuid"])
        row = DB.get_llm_call_full(run_id, active_edit["node_uuid"])
        if node and row:
            if active_edit["field"] == "input":
                restored = _to_show_json(row["input"])
                if restored is not None:
                    node.input = restored
            else:
                restored = _to_show_json(row["output"])
                if restored is not None:
                    node.output = restored
            node.llm_verdict = row["llm_verdict"]
            DB.update_graph_topology(run_id, graph)

    return active_edit


def handle_update_node(state, msg: dict) -> None:
    """Handle updateNode message for updating node properties like label."""
    run_id = msg.get("run_id")
    node_uuid = msg.get("node_uuid")
    field = msg.get("field")
    value = msg.get("value")

    if not all([run_id, node_uuid, field]):
        logger.error(f"Missing required fields in updateNode message: {msg}")
        return

    graph = _load_graph_for_edit(state, run_id)
    if graph:
        node = graph.get_node_by_uuid(node_uuid)
        if node and hasattr(node, field):
            setattr(node, field, value)
        DB.update_graph_topology(run_id, graph)
    else:
        logger.warning(f"Run {run_id} not found in run_graphs")


def handle_update_llm_verdicts(state, run_id: str, verdict_updates: list[dict[str, str]]) -> int:
    graph = _load_graph_for_edit(state, run_id)
    updates_applied = 0

    for update in verdict_updates:
        node_uuid = update.get("node_uuid")
        llm_verdict = update.get("llm_verdict")
        if not node_uuid:
            continue

        row = DB.get_llm_call_full(run_id, node_uuid)
        if not row:
            continue
        if row["llm_verdict"] == llm_verdict:
            continue

        DB.set_llm_verdict(run_id, node_uuid, llm_verdict)
        if graph:
            node = graph.get_node_by_uuid(node_uuid)
            if node is not None:
                node.llm_verdict = llm_verdict
        updates_applied += 1

    if updates_applied and graph:
        DB.update_graph_topology(run_id, graph)

    return updates_applied


def handle_update_run_name(state, msg: dict) -> None:
    """Handle run name update from UI."""
    run_id = msg.get("run_id")
    name = msg.get("name")
    if run_id and name is not None:
        DB.update_run_name(run_id, name)
        state.notify_run_list_changed()


def handle_update_thumb_label(state, msg: dict) -> None:
    """Handle run thumb label update from UI."""
    run_id = msg.get("run_id")
    thumb_label = msg.get("thumb_label")
    if run_id:
        DB.update_thumb_label(run_id, thumb_label)
        state.notify_run_list_changed()


def handle_update_notes(state, msg: dict) -> None:
    """Handle run notes update from UI."""
    run_id = msg.get("run_id")
    notes = msg.get("notes")
    if run_id and notes is not None:
        DB.update_notes(run_id, notes)


def handle_erase(state, msg: dict) -> None:
    """Handle erase request from UI (clears LLM calls, not the run)."""
    run_id = msg.get("run_id")
    DB.erase(run_id)
    DB.clear_active_edit(run_id)


def handle_delete_runs(state, msg: dict) -> int:
    """Handle deleting one or more finished runs from UI."""
    run_ids = list(dict.fromkeys(msg.get("run_ids") or []))
    if not run_ids:
        return 0

    deleted = DB.delete_runs(run_ids)

    for run_id in run_ids:
        state.runs.pop(run_id, None)
        state.run_graphs.pop(run_id, None)
        state.runner_event_queues.pop(run_id, None)
        state.rerun_run_ids.discard(run_id)

    state.notify_run_list_changed()
    state.notify_project_list_changed()
    return deleted
