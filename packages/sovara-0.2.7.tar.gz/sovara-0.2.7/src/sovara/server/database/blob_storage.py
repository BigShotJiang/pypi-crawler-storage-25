"""Blob storage for large LLM call payload values.

Any string value inside an LLM call JSON payload that exceeds
BLOB_EXTERNALIZATION_THRESHOLD characters is written to the local filesystem
and replaced with a reference marker:

    {"__sovara_ref__": "<sha256hex>"}

This keeps the database rows small across all backends (SQLite, MongoDB, Postgres)
and avoids hitting document size limits (e.g. MongoDB's 16 MB hard cap).

The inverse operation (restore) expands markers back to their original string
content so the runner can replay calls transparently from cache.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from flatten_json import flatten as _flatten_complete

from sovara.common.constants import BLOB_EXTERNALIZATION_THRESHOLD, SOVARA_BLOB_DIR
from sovara.runner.monkey_patching.api_parser import ordered_unflatten_list

_REF_KEY = "__sovara_ref__"
_SEP = "."
_MARKER_SUFFIX = f"{_SEP}{_REF_KEY}"


def _blob_dir() -> Path:
    path = Path(SOVARA_BLOB_DIR)
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_blob_path(ref_id: str) -> Path:
    return Path(SOVARA_BLOB_DIR) / f"{ref_id}.bin"


# ---------------------------------------------------------------------------
# Externalize: flatten JSON, replace large strings with FS references
# ---------------------------------------------------------------------------

def externalize(json_str: str) -> str:
    """Return a new JSON string with large string values replaced by FS references.

    The input_hash must be computed from the original json_str *before* calling
    this function so that cache keys are unaffected by externalization.
    """
    try:
        obj = json.loads(json_str)
    except (TypeError, json.JSONDecodeError):
        return json_str

    flat = _flatten_complete(obj, separator=_SEP)
    changed = False
    result: dict[str, Any] = {}
    for k, v in flat.items():
        if isinstance(v, str) and len(v) > BLOB_EXTERNALIZATION_THRESHOLD:
            ref_id = hashlib.sha256(v.encode("utf-8")).hexdigest()
            blob_path = _blob_dir() / f"{ref_id}.bin"
            if not blob_path.exists():
                blob_path.write_text(v, encoding="utf-8")
            result[k] = {_REF_KEY: ref_id}
            changed = True
        else:
            result[k] = v

    if not changed:
        return json_str
    return json.dumps(ordered_unflatten_list(result, "."))


# ---------------------------------------------------------------------------
# Restore: flatten JSON, expand FS references back to original strings
# ---------------------------------------------------------------------------

def restore(json_str: str) -> str:
    """Return a new JSON string with FS references expanded back to their original string values."""
    try:
        obj = json.loads(json_str)
    except (TypeError, json.JSONDecodeError):
        return json_str

    flat = _flatten_complete(obj, separator=_SEP)
    changed = False
    result: dict[str, Any] = {}
    skip: set[str] = set()
    for k, v in flat.items():
        if k in skip:
            continue
        if k.endswith(_MARKER_SUFFIX) and isinstance(v, str):
            parent_key = k[: -len(_MARKER_SUFFIX)]
            blob_path = get_blob_path(v)
            if blob_path.exists():
                result[parent_key] = blob_path.read_text(encoding="utf-8")
            else:
                # Blob file missing — keep marker so the runner fails gracefully.
                result[parent_key] = {_REF_KEY: v}
            skip.add(k)
            changed = True
        else:
            result[k] = v

    if not changed:
        return json_str
    return json.dumps(ordered_unflatten_list(result, "."))


def read_blob(ref_id: str) -> str | None:
    """Read raw blob content by ref_id. Returns None if the blob does not exist."""
    blob_path = get_blob_path(ref_id)
    if not blob_path.exists():
        return None
    return blob_path.read_text(encoding="utf-8")


def is_valid_ref_id(ref_id: str) -> bool:
    """Return True if ref_id is a valid SHA-256 hex digest (64 lowercase hex chars)."""
    return len(ref_id) == 64 and all(c in "0123456789abcdef" for c in ref_id)
