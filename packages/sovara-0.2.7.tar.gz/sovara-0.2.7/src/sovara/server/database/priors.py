import json
import uuid
from typing import Any

from sovara.common.utils import hash_input
from sovara.server.priors_backend.constants import DEFAULT_PRIORS_LATENCY_TIER


class PriorsMixin:
    @staticmethod
    def _decode_json_column(raw_value: Any, fallback: Any):
        if raw_value in (None, ""):
            return fallback
        try:
            return json.loads(raw_value)
        except (TypeError, json.JSONDecodeError):
            return fallback

    def _normalize_prior_retrieval_row(self, row):
        if row is None:
            return None
        raw_context = row["raw_context"] or ""
        processed_context = row["processed_context"] or ""
        retrieval_latency_ms = row["retrieval_latency_ms"]
        return {
            "retrieval_id": row["retrieval_id"],
            "run_id": row["run_id"],
            "node_uuid": row["node_uuid"],
            "raw_context": raw_context,
            "processed_context": processed_context,
            "inherited_prior_ids": self._decode_json_column(row["inherited_prior_ids_json"], []),
            "retrieved_priors": self._decode_json_column(row["retrieved_priors_json"], []),
            "applied_priors": self._decode_json_column(row["applied_priors_json"], []),
            "rendered_priors_block": row["rendered_priors_block"] or "",
            "injection_anchor": self._decode_json_column(row["injection_anchor_json"], None),
            "model": row["model"],
            "latency_tier": row["latency_tier"] or DEFAULT_PRIORS_LATENCY_TIER,
            "timeout_ms": row["timeout_ms"],
            "retrieval_latency_ms": retrieval_latency_ms,
            "prior_coverage": row["prior_coverage"],
            "groundedness": row["prior_coverage"],
            "groundedness_total_importance": row["groundedness_total_importance"],
            "groundedness_grounded_importance": row["groundedness_grounded_importance"],
            "groundedness_guidance_points": self._decode_json_column(
                row["groundedness_guidance_points_json"], []
            ),
            "adherence_status": row["adherence_status"],
            "prior_adherence": row["prior_adherence"],
            "severity_weighted_prior_adherence": row["severity_weighted_prior_adherence"],
            "relevant_prior_count": row["relevant_prior_count"],
            "followed_relevant_prior_count": row["followed_relevant_prior_count"],
            "violated_relevant_prior_count": row["violated_relevant_prior_count"],
            "total_non_adherence_severity": row["total_non_adherence_severity"],
            "max_non_adherence_severity": row["max_non_adherence_severity"],
            "prior_adherence_items": self._decode_json_column(
                row["prior_adherence_items_json"], []
            ),
            "retrieval_status": row["retrieval_status"],
            "coverage_status": row["coverage_status"],
            "warning_message": row["warning_message"],
            "error_message": row["error_message"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    @staticmethod
    def _normalize_cache_pairs(pairs: list[dict[str, Any]] | None) -> list[dict[str, str]]:
        normalized: list[dict[str, str]] = []
        for pair in pairs or []:
            key = pair.get("key")
            value = pair.get("value")
            if isinstance(key, str) and isinstance(value, str):
                normalized.append({"key": key, "value": value})
        return normalized

    @staticmethod
    def _normalize_prior_ids(prior_ids: list[str] | None) -> list[str]:
        ordered_unique: list[str] = []
        for prior_id in prior_ids or []:
            if prior_id and prior_id not in ordered_unique:
                ordered_unique.append(prior_id)
        return ordered_unique

    @staticmethod
    def _normalized_ignore_prior_ids_json(ignore_prior_ids: list[str] | None) -> str:
        unique_sorted = sorted({prior_id for prior_id in (ignore_prior_ids or []) if prior_id})
        return json.dumps(unique_sorted)

    @staticmethod
    def _stable_json(value: Any) -> str:
        return json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str
        )

    def _prior_coverage_cache_fingerprint(
        self,
        *,
        processed_context: str,
        llm_output: Any,
        priors: list[dict[str, Any]],
        judge_model: str,
        judge_tier: str,
        reasoning_effort: str,
        prompt_version: str,
    ) -> dict[str, str]:
        normalized_processed_context = str(processed_context or "")
        llm_output_json = self._stable_json(llm_output)
        priors_json = self._stable_json(priors or [])
        payload = {
            "processed_context_hash": hash_input(normalized_processed_context),
            "llm_output_hash": hash_input(llm_output_json),
            "priors_hash": hash_input(priors_json),
            "judge_model": str(judge_model or ""),
            "judge_tier": str(judge_tier or ""),
            "reasoning_effort": str(reasoning_effort or ""),
            "prompt_version": str(prompt_version or ""),
        }
        return {
            **payload,
            "cache_key": hash_input(self._stable_json(payload)),
        }

    def copy_prior_retrievals(self, old_run_id, new_run_id):
        self.backend.copy_prior_retrievals_query(old_run_id, new_run_id)

    def get_prior_retrieval_by_id(self, retrieval_id):
        row = self.backend.get_prior_retrieval_by_id_query(retrieval_id)
        return self._normalize_prior_retrieval_row(row)

    def lookup_prefix_cache(
        self,
        *,
        user_id: str,
        project_id: str,
        base_path: str,
        model: str,
        clean_pairs: list[dict[str, Any]] | None,
    ) -> dict[str, Any] | None:
        normalized_pairs = self._normalize_cache_pairs(clean_pairs)
        if not normalized_pairs:
            return None

        rows = self.backend.get_prefix_cache_candidates_query(
            user_id,
            project_id,
            base_path,
            model,
            normalized_pairs[0]["key"],
            len(normalized_pairs),
        )
        for row in rows:
            cached_clean_pairs = self._decode_json_column(row["clean_pairs_json"], [])
            pair_count = int(row["pair_count"])
            if normalized_pairs[:pair_count] != cached_clean_pairs:
                continue
            return {
                "matched_pair_count": pair_count,
                "injected_pairs": self._decode_json_column(row["injected_pairs_json"], []),
                "prior_ids": self._decode_json_column(row["prior_ids_json"], []),
            }
        return None

    def store_prefix_cache(
        self,
        *,
        user_id: str,
        project_id: str,
        base_path: str,
        model: str,
        clean_pairs: list[dict[str, Any]] | None,
        injected_pairs: list[dict[str, Any]] | None,
        prior_ids: list[str] | None,
    ) -> None:
        normalized_clean_pairs = self._normalize_cache_pairs(clean_pairs)
        normalized_injected_pairs = self._normalize_cache_pairs(injected_pairs)
        if not normalized_clean_pairs or len(normalized_clean_pairs) != len(
            normalized_injected_pairs
        ):
            return

        self.backend.upsert_prefix_cache_query(
            user_id,
            project_id,
            base_path,
            model,
            normalized_clean_pairs[0]["key"],
            len(normalized_clean_pairs),
            json.dumps(normalized_clean_pairs, ensure_ascii=False, separators=(",", ":")),
            json.dumps(normalized_injected_pairs, ensure_ascii=False, separators=(",", ":")),
            json.dumps(
                self._normalize_prior_ids(prior_ids), ensure_ascii=False, separators=(",", ":")
            ),
        )

    def clear_scope_prefix_cache(self, *, user_id: str, project_id: str) -> None:
        self.backend.clear_scope_prefix_cache_query(user_id, project_id)

    def clear_all_prefix_cache(self) -> None:
        self.backend.clear_all_prefix_cache_query()

    def get_cached_retrieval(
        self,
        *,
        user_id: str,
        project_id: str,
        priors_revision: int,
        base_path: str,
        model: str,
        context: str,
        ignore_prior_ids: list[str] | None = None,
    ) -> dict[str, Any] | None:
        row = self.backend.get_cached_retrieval_query(
            user_id,
            project_id,
            priors_revision,
            base_path,
            model,
            hash_input(context or ""),
            self._normalized_ignore_prior_ids_json(ignore_prior_ids),
        )
        if row is None:
            return None
        return self._decode_json_column(row["response_json"], None)

    def store_cached_retrieval(
        self,
        *,
        user_id: str,
        project_id: str,
        priors_revision: int,
        base_path: str,
        model: str,
        context: str,
        ignore_prior_ids: list[str] | None,
        response: dict[str, Any],
    ) -> None:
        self.backend.upsert_retrieval_cache_query(
            user_id,
            project_id,
            priors_revision,
            base_path,
            model,
            hash_input(context or ""),
            self._normalized_ignore_prior_ids_json(ignore_prior_ids),
            json.dumps(response, sort_keys=True),
        )

    def clear_all_retrieval_cache(self) -> None:
        self.backend.clear_all_retrieval_cache_query()

    def get_priors_scope(self, *, user_id: str, project_id: str) -> dict[str, Any] | None:
        row = self.backend.get_priors_scope_query(user_id, project_id)
        if row is None:
            return None
        return {
            "user_id": str(row["user_id"]),
            "project_id": str(row["project_id"]),
            "revision": int(row["revision"]),
            "updated_at": str(row["updated_at"]),
        }

    def ensure_priors_scope(
        self,
        *,
        user_id: str,
        project_id: str,
        revision: int = 1,
        updated_at: str,
    ) -> dict[str, Any]:
        row = self.backend.ensure_priors_scope_query(user_id, project_id, revision, updated_at)
        return {
            "user_id": str(row["user_id"]),
            "project_id": str(row["project_id"]),
            "revision": int(row["revision"]),
            "updated_at": str(row["updated_at"]),
        }

    def bump_priors_scope_revision(
        self, *, user_id: str, project_id: str, updated_at: str
    ) -> dict[str, Any]:
        row = self.backend.bump_priors_scope_revision_query(user_id, project_id, updated_at)
        return {
            "user_id": str(row["user_id"]),
            "project_id": str(row["project_id"]),
            "revision": int(row["revision"]),
            "updated_at": str(row["updated_at"]),
        }

    def get_prior_retrieval(self, run_id, node_uuid):
        row = self.backend.get_prior_retrieval_query(run_id, node_uuid)
        return self._normalize_prior_retrieval_row(row)

    def get_prior_retrievals_for_run(self, run_id):
        rows = self.backend.get_prior_retrievals_for_run_query(run_id)
        return [self._normalize_prior_retrieval_row(row) for row in rows]

    def upsert_prior_retrieval(
        self,
        run_id: str,
        node_uuid: str | None = None,
        *,
        retrieval_id: str | None = None,
        raw_context: str = "",
        processed_context: str = "",
        inherited_prior_ids: list[str] | None = None,
        retrieved_priors: list[dict[str, Any]] | None = None,
        applied_priors: list[dict[str, Any]] | None = None,
        rendered_priors_block: str = "",
        injection_anchor: dict[str, Any] | None = None,
        model: str | None = None,
        latency_tier: str = DEFAULT_PRIORS_LATENCY_TIER,
        timeout_ms: int | None = None,
        retrieval_latency_ms: int | None = None,
        prior_coverage: int | None = None,
        groundedness_total_importance: int | None = None,
        groundedness_grounded_importance: int | None = None,
        groundedness_guidance_points: list[dict[str, Any]] | None = None,
        adherence_status: str = "not_requested",
        prior_adherence: int | None = None,
        severity_weighted_prior_adherence: int | None = None,
        relevant_prior_count: int | None = None,
        followed_relevant_prior_count: int | None = None,
        violated_relevant_prior_count: int | None = None,
        total_non_adherence_severity: int | None = None,
        max_non_adherence_severity: int | None = None,
        prior_adherence_items: list[dict[str, Any]] | None = None,
        retrieval_status: str = "pending",
        coverage_status: str = "not_requested",
        warning_message: str | None = None,
        error_message: str | None = None,
    ) -> str:
        effective_retrieval_id = retrieval_id
        stale_retrieval_id: str | None = None
        if node_uuid:
            existing = self.backend.get_prior_retrieval_query(run_id, node_uuid)
            if existing is not None:
                incoming_is_unscored = prior_coverage is None and coverage_status == "not_requested"
                existing_applied_priors = self._decode_json_column(
                    existing["applied_priors_json"], []
                )
                if (
                    incoming_is_unscored
                    and existing["coverage_status"] == "complete"
                    and existing["prior_coverage"] is not None
                    and (existing["raw_context"] or "") == (raw_context or "")
                    and (existing["processed_context"] or "") == (processed_context or "")
                    and self._stable_json(existing_applied_priors)
                    == self._stable_json(applied_priors or [])
                ):
                    prior_coverage = existing["prior_coverage"]
                    groundedness_total_importance = existing["groundedness_total_importance"]
                    groundedness_grounded_importance = existing["groundedness_grounded_importance"]
                    groundedness_guidance_points = self._decode_json_column(
                        existing["groundedness_guidance_points_json"], []
                    )
                    coverage_status = "complete"
                if (
                    incoming_is_unscored
                    and existing["adherence_status"] == "complete"
                    and existing["prior_adherence"] is not None
                    and (existing["raw_context"] or "") == (raw_context or "")
                    and (existing["processed_context"] or "") == (processed_context or "")
                    and self._stable_json(existing_applied_priors)
                    == self._stable_json(applied_priors or [])
                ):
                    adherence_status = "complete"
                    prior_adherence = existing["prior_adherence"]
                    severity_weighted_prior_adherence = existing[
                        "severity_weighted_prior_adherence"
                    ]
                    relevant_prior_count = existing["relevant_prior_count"]
                    followed_relevant_prior_count = existing["followed_relevant_prior_count"]
                    violated_relevant_prior_count = existing["violated_relevant_prior_count"]
                    total_non_adherence_severity = existing["total_non_adherence_severity"]
                    max_non_adherence_severity = existing["max_non_adherence_severity"]
                    prior_adherence_items = self._decode_json_column(
                        existing["prior_adherence_items_json"], []
                    )
                effective_retrieval_id = existing["retrieval_id"]
                if retrieval_id and retrieval_id != effective_retrieval_id:
                    provided = self.backend.get_prior_retrieval_by_id_query(retrieval_id)
                    if (
                        provided is not None
                        and provided["run_id"] == run_id
                        and provided["node_uuid"] is None
                    ):
                        stale_retrieval_id = retrieval_id
        if effective_retrieval_id is None:
            effective_retrieval_id = str(uuid.uuid4())

        self.backend.upsert_prior_retrieval_query(
            effective_retrieval_id,
            run_id,
            node_uuid,
            raw_context,
            processed_context,
            json.dumps(inherited_prior_ids or []),
            json.dumps(retrieved_priors or []),
            json.dumps(applied_priors or []),
            rendered_priors_block,
            json.dumps(injection_anchor) if injection_anchor is not None else None,
            model,
            latency_tier,
            timeout_ms,
            retrieval_latency_ms,
            prior_coverage,
            retrieval_status,
            coverage_status,
            warning_message,
            error_message,
            groundedness_total_importance,
            groundedness_grounded_importance,
            json.dumps(groundedness_guidance_points or []),
            adherence_status,
            prior_adherence,
            severity_weighted_prior_adherence,
            relevant_prior_count,
            followed_relevant_prior_count,
            violated_relevant_prior_count,
            total_non_adherence_severity,
            max_non_adherence_severity,
            json.dumps(prior_adherence_items or []),
        )
        if stale_retrieval_id is not None:
            self.backend.delete_prior_retrieval_by_id_query(stale_retrieval_id)
        return effective_retrieval_id

    def update_prior_coverage(
        self,
        retrieval_id: str,
        *,
        prior_coverage: int | None,
        coverage_status: str,
        groundedness_details: dict[str, Any] | None = None,
    ) -> None:
        total_importance, grounded_importance, guidance_points_json = (
            self._groundedness_detail_columns(groundedness_details)
        )
        self.backend.update_prior_coverage_query(
            retrieval_id,
            prior_coverage,
            coverage_status,
            total_importance,
            grounded_importance,
            guidance_points_json,
        )

    def _groundedness_detail_columns(
        self, groundedness_details: dict[str, Any] | None
    ) -> tuple[int | None, int | None, str]:
        if not groundedness_details:
            return None, None, "[]"
        total_importance = groundedness_details.get("total_importance")
        grounded_importance = groundedness_details.get("grounded_importance")
        guidance_points = groundedness_details.get("guidance_points")
        return (
            int(total_importance) if total_importance is not None else None,
            int(grounded_importance) if grounded_importance is not None else None,
            json.dumps(guidance_points or [], ensure_ascii=False, separators=(",", ":")),
        )

    def get_pending_prior_coverage_jobs(self, limit: int = 20) -> list[dict[str, Any]]:
        rows = self.backend.get_pending_prior_coverage_jobs_query(limit)
        return [self._normalize_prior_retrieval_row(row) for row in rows]

    def update_prior_adherence(
        self,
        retrieval_id: str,
        *,
        adherence_status: str,
        adherence_details: dict[str, Any] | None = None,
    ) -> None:
        self.backend.update_prior_adherence_query(
            retrieval_id,
            adherence_status,
            *self._adherence_detail_columns(adherence_details),
        )

    def _adherence_detail_columns(
        self, adherence_details: dict[str, Any] | None
    ) -> tuple[
        int | None, int | None, int | None, int | None, int | None, int | None, int | None, str
    ]:
        if not adherence_details:
            return None, None, None, None, None, None, None, "[]"
        return (
            self._optional_int(adherence_details.get("prior_adherence")),
            self._optional_int(adherence_details.get("severity_weighted_prior_adherence")),
            self._optional_int(adherence_details.get("relevant_prior_count")),
            self._optional_int(adherence_details.get("followed_relevant_prior_count")),
            self._optional_int(adherence_details.get("violated_relevant_prior_count")),
            self._optional_int(adherence_details.get("total_non_adherence_severity")),
            self._optional_int(adherence_details.get("max_non_adherence_severity")),
            json.dumps(
                adherence_details.get("prior_adherence_items") or [],
                ensure_ascii=False,
                separators=(",", ":"),
            ),
        )

    @staticmethod
    def _optional_int(value: Any) -> int | None:
        return int(value) if value is not None else None

    def get_cached_prior_coverage(
        self,
        *,
        processed_context: str,
        llm_output: Any,
        priors: list[dict[str, Any]],
        judge_model: str,
        judge_tier: str,
        reasoning_effort: str,
        prompt_version: str,
    ) -> dict[str, Any] | None:
        fingerprint = self._prior_coverage_cache_fingerprint(
            processed_context=processed_context,
            llm_output=llm_output,
            priors=priors,
            judge_model=judge_model,
            judge_tier=judge_tier,
            reasoning_effort=reasoning_effort,
            prompt_version=prompt_version,
        )
        row = self.backend.get_prior_coverage_cache_query(fingerprint["cache_key"])
        if row is None:
            return None
        return {
            "cache_key": row["cache_key"],
            "prior_coverage": row["prior_coverage"],
            "groundedness_details": {
                "guidance_points": self._decode_json_column(row["guidance_points_json"], []),
                "total_importance": row["total_importance"],
                "grounded_importance": row["grounded_importance"],
                "groundedness": row["prior_coverage"],
            },
        }

    def store_cached_prior_coverage(
        self,
        *,
        processed_context: str,
        llm_output: Any,
        priors: list[dict[str, Any]],
        judge_model: str,
        judge_tier: str,
        reasoning_effort: str,
        prompt_version: str,
        prior_coverage: int,
        groundedness_details: dict[str, Any] | None = None,
    ) -> str:
        fingerprint = self._prior_coverage_cache_fingerprint(
            processed_context=processed_context,
            llm_output=llm_output,
            priors=priors,
            judge_model=judge_model,
            judge_tier=judge_tier,
            reasoning_effort=reasoning_effort,
            prompt_version=prompt_version,
        )
        self.backend.upsert_prior_coverage_cache_query(
            fingerprint["cache_key"],
            fingerprint["processed_context_hash"],
            fingerprint["llm_output_hash"],
            fingerprint["priors_hash"],
            judge_model,
            judge_tier,
            reasoning_effort,
            prompt_version,
            prior_coverage,
            *self._groundedness_detail_columns(groundedness_details),
        )
        return fingerprint["cache_key"]

    def get_cached_prior_adherence(
        self,
        *,
        processed_context: str,
        llm_output: Any,
        priors: list[dict[str, Any]],
        judge_model: str,
        judge_tier: str,
        reasoning_effort: str,
        prompt_version: str,
    ) -> dict[str, Any] | None:
        fingerprint = self._prior_coverage_cache_fingerprint(
            processed_context=processed_context,
            llm_output=llm_output,
            priors=priors,
            judge_model=judge_model,
            judge_tier=judge_tier,
            reasoning_effort=reasoning_effort,
            prompt_version=prompt_version,
        )
        row = self.backend.get_prior_adherence_cache_query(fingerprint["cache_key"])
        if row is None:
            return None
        return {
            "cache_key": row["cache_key"],
            "adherence_details": {
                "prior_adherence_items": self._decode_json_column(
                    row["prior_adherence_items_json"], []
                ),
                "relevant_prior_count": row["relevant_prior_count"],
                "followed_relevant_prior_count": row["followed_relevant_prior_count"],
                "violated_relevant_prior_count": row["violated_relevant_prior_count"],
                "total_non_adherence_severity": row["total_non_adherence_severity"],
                "max_non_adherence_severity": row["max_non_adherence_severity"],
                "prior_adherence": row["prior_adherence"],
                "severity_weighted_prior_adherence": row["severity_weighted_prior_adherence"],
            },
        }

    def store_cached_prior_adherence(
        self,
        *,
        processed_context: str,
        llm_output: Any,
        priors: list[dict[str, Any]],
        judge_model: str,
        judge_tier: str,
        reasoning_effort: str,
        prompt_version: str,
        adherence_details: dict[str, Any],
    ) -> str:
        fingerprint = self._prior_coverage_cache_fingerprint(
            processed_context=processed_context,
            llm_output=llm_output,
            priors=priors,
            judge_model=judge_model,
            judge_tier=judge_tier,
            reasoning_effort=reasoning_effort,
            prompt_version=prompt_version,
        )
        self.backend.upsert_prior_adherence_cache_query(
            fingerprint["cache_key"],
            fingerprint["processed_context_hash"],
            fingerprint["llm_output_hash"],
            fingerprint["priors_hash"],
            judge_model,
            judge_tier,
            reasoning_effort,
            prompt_version,
            *self._adherence_detail_columns(adherence_details),
        )
        return fingerprint["cache_key"]

    def get_priors_applied_for_run(self, run_id):
        rows = self.backend.get_priors_applied_for_run_query(run_id)
        return [
            {
                "prior_id": row["prior_id"],
                "run_id": row["run_id"],
                "node_uuid": row["node_uuid"],
                "name": row["name"] or "Unknown Run",
            }
            for row in rows
        ]

    def get_runs_for_prior(self, prior_id):
        rows = self.backend.get_priors_applied_query(prior_id)
        return [
            {
                "runId": row["run_id"],
                "nodeUuid": row["node_uuid"],
                "name": row["name"] or "Unknown Run",
            }
            for row in rows
        ]

    def add_prior_applied(self, prior_id, run_id, node_uuid=None):
        self.backend.add_prior_applied_query(prior_id, run_id, node_uuid)

    def remove_prior_applied(self, prior_id, run_id, node_uuid=None):
        self.backend.remove_prior_applied_query(prior_id, run_id, node_uuid)

    def delete_priors_applied_for_prior(self, prior_id):
        self.backend.delete_priors_applied_for_prior_query(prior_id)
