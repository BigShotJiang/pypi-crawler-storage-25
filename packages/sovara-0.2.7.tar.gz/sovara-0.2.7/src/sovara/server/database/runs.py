import json
from collections import defaultdict
from datetime import datetime, timezone

from sovara.common.custom_metrics import get_metric_kind
from sovara.server.database.blob_storage import externalize, restore
from sovara.server.graph_models import RunGraph

from ._shared import BadRequestError, ResourceNotFoundError


class RunsMixin:
    @staticmethod
    def parse_custom_metrics(raw_metrics):
        if isinstance(raw_metrics, dict):
            return raw_metrics
        if not raw_metrics:
            return {}
        try:
            parsed = json.loads(raw_metrics)
        except Exception:
            return {}
        return parsed if isinstance(parsed, dict) else {}

    @staticmethod
    def serialize_timestamp(timestamp):
        if timestamp is None or isinstance(timestamp, str):
            return timestamp
        if isinstance(timestamp, datetime):
            if timestamp.tzinfo is not None:
                timestamp = timestamp.astimezone(timezone.utc).replace(tzinfo=None)
            return timestamp.strftime("%Y-%m-%d %H:%M:%S")
        raise TypeError(f"Unsupported timestamp type: {type(timestamp)!r}")

    @staticmethod
    def normalize_thumb_label(raw_value):
        if raw_value is None:
            return None
        return bool(raw_value)

    @staticmethod
    def normalize_runtime_seconds(raw_value):
        if raw_value is None:
            return None
        return max(0.0, float(raw_value))

    @staticmethod
    def _metric_storage_values(metric_kind, value):
        if metric_kind == "bool":
            return int(bool(value)), None, None
        if metric_kind == "int":
            return None, int(value), None
        return None, None, float(value)

    def _build_run_metric_rows(self, run_id, project_id, metrics):
        rows = []
        for key, value in metrics.items():
            metric_kind = get_metric_kind(value)
            bool_value, int_value, float_value = self._metric_storage_values(metric_kind, value)
            rows.append((
                run_id,
                project_id,
                key,
                metric_kind,
                bool_value,
                int_value,
                float_value,
            ))
        return rows

    def _normalize_run_row(self, row):
        normalized = dict(row)
        normalized["custom_metrics"] = self.parse_custom_metrics(normalized.get("custom_metrics"))
        normalized["thumb_label"] = self.normalize_thumb_label(normalized.get("thumb_label"))
        normalized["runtime_seconds"] = self.normalize_runtime_seconds(normalized.get("runtime_seconds"))
        normalized["active_runtime_seconds"] = self.normalize_runtime_seconds(
            normalized.get("active_runtime_seconds")
        )
        normalized["tags"] = list(normalized.get("tags") or [])
        normalized["active_edit"] = self._normalize_active_edit_row(normalized)
        return normalized

    @staticmethod
    def _normalize_active_edit_row(row):
        node_uuid = row.get("active_edit_node_uuid")
        node_label = row.get("active_edit_node_label")
        field = row.get("active_edit_field")
        status = row.get("active_edit_status")
        if not node_uuid or field not in {"input", "output"} or status not in {"pending", "not_consumed"}:
            return None
        return {
            "node_uuid": node_uuid,
            "node_label": node_label or node_uuid,
            "field": field,
            "status": status,
        }

    @staticmethod
    def _normalize_trace_chat_history(raw_value):
        if not raw_value:
            return []

        try:
            parsed = json.loads(raw_value)
        except (TypeError, json.JSONDecodeError):
            return []

        if not isinstance(parsed, list):
            return []

        normalized = []
        for item in parsed:
            if not isinstance(item, dict):
                return []
            role = item.get("role")
            content = item.get("content")
            if role not in ("user", "assistant") or not isinstance(content, str):
                return []
            normalized.append({"role": role, "content": content})
        return normalized

    def _serialize_trace_chat_history(self, history):
        if not isinstance(history, list):
            raise BadRequestError("Trace chat history must be a list.")

        normalized = []
        for index, item in enumerate(history):
            if not isinstance(item, dict):
                raise BadRequestError(f"Trace chat message {index} must be an object.")
            role = item.get("role")
            content = item.get("content")
            if role not in ("user", "assistant"):
                raise BadRequestError(f"Trace chat message {index} has invalid role: {role!r}.")
            if not isinstance(content, str):
                raise BadRequestError(f"Trace chat message {index} content must be a string.")
            normalized.append({"role": role, "content": content})

        return json.dumps(normalized)

    def _get_tags_for_runs_map(self, run_ids):
        rows = self.backend.get_tags_for_runs_query(run_ids)
        tags_by_run: dict[str, list[dict[str, str]]] = defaultdict(list)
        for row in rows:
            tags_by_run[row["run_id"]].append(self._normalize_tag_row(row))
        return tags_by_run

    def _attach_tags_to_rows(self, rows):
        normalized_rows = [self._normalize_run_row(row) for row in rows]
        run_ids = [row["run_id"] for row in normalized_rows]
        tags_by_run = self._get_tags_for_runs_map(run_ids)
        for row in normalized_rows:
            row["tags"] = tags_by_run.get(row["run_id"], [])
        return normalized_rows

    def erase(self, run_id):
        """Erase run data."""
        default_graph = json.dumps({"nodes": [], "edges": []})
        self.backend.delete_llm_calls_query(run_id)
        self.backend.update_run_graph_topology_query(default_graph, run_id)

    def add_run(
        self,
        run_id,
        name,
        timestamp,
        cwd,
        command,
        environment,
        parent_run_id=None,
        version_date=None,
        project_id=None,
        user_id=None,
    ):
        from sovara.common.constants import DEFAULT_LOG, DEFAULT_NOTE

        default_graph = json.dumps({"nodes": [], "edges": []})
        parent_run_id = parent_run_id if parent_run_id else run_id
        env_json = json.dumps(environment)
        serialized_timestamp = self.serialize_timestamp(timestamp)

        self.backend.add_run_query(
            run_id,
            parent_run_id,
            name,
            default_graph,
            serialized_timestamp,
            cwd,
            command,
            env_json,
            DEFAULT_NOTE,
            DEFAULT_LOG,
            version_date,
            project_id,
            user_id,
        )

    def update_graph_topology(self, run_id: str, graph: RunGraph) -> None:
        graph_json = externalize(graph.to_json_string())
        self.backend.update_run_graph_topology_query(graph_json, run_id)

    def update_timestamp(self, run_id, timestamp):
        self.backend.update_run_timestamp_query(self.serialize_timestamp(timestamp), run_id)

    def update_runtime_seconds(self, run_id, runtime_seconds):
        normalized = self.normalize_runtime_seconds(runtime_seconds)
        self.backend.update_run_runtime_seconds_query(normalized, run_id)

    def update_active_runtime_seconds(self, run_id, active_runtime_seconds):
        normalized = self.normalize_runtime_seconds(active_runtime_seconds)
        self.backend.update_run_active_runtime_seconds_query(normalized, run_id)

    def clear_active_runtime_seconds(self, run_id):
        self.backend.clear_run_active_runtime_seconds_query(run_id)

    def get_active_edit(self, run_id):
        row = self.backend.get_run_active_edit_query(run_id)
        if row is None:
            raise ResourceNotFoundError(f"Run not found: {run_id}")
        return self._normalize_active_edit_row(dict(row))

    def upsert_active_edit(self, run_id, node_uuid, node_label, field):
        if field not in {"input", "output"}:
            raise BadRequestError(f"Unsupported edit field: {field}")
        existing = self.get_active_edit(run_id)
        if existing and (existing["node_uuid"] != node_uuid or existing["field"] != field):
            raise BadRequestError(
                "Only one node edit can be active per run. Discard the current draft before editing another node."
            )
        self.backend.set_run_active_edit_query(
            node_uuid,
            node_label or node_uuid,
            field,
            "pending",
            run_id,
        )
        return {
            "node_uuid": node_uuid,
            "node_label": node_label or node_uuid,
            "field": field,
            "status": "pending",
        }

    def mark_active_edit_pending(self, run_id):
        existing = self.get_active_edit(run_id)
        if existing is None:
            return None
        if existing["status"] != "pending":
            self.backend.update_run_active_edit_status_query("pending", run_id)
            existing["status"] = "pending"
        return existing

    def mark_active_edit_not_consumed(self, run_id):
        existing = self.get_active_edit(run_id)
        if existing is None or existing["status"] != "pending":
            return existing
        self.backend.update_run_active_edit_status_query("not_consumed", run_id)
        existing["status"] = "not_consumed"
        return existing

    def clear_active_edit(self, run_id):
        existing = self.get_active_edit(run_id)
        if existing is None:
            return None
        self.backend.clear_run_active_edit_query(run_id)
        return existing

    def checkpoint_active_runtime(self, run_id, active_runtime_seconds=None):
        if active_runtime_seconds is None:
            from sovara.runner.context_manager import get_run_runtime_seconds

            active_runtime_seconds = get_run_runtime_seconds(run_id)
        if active_runtime_seconds is None:
            return None
        normalized = self.normalize_runtime_seconds(active_runtime_seconds)
        self.backend.update_run_active_runtime_seconds_query(normalized, run_id)
        return normalized

    def finalize_runtime(self, run_id, runtime_seconds):
        normalized = self.normalize_runtime_seconds(runtime_seconds)
        self.backend.finalize_run_runtime_query(normalized, run_id)
        return normalized

    def update_run_name(self, run_id, name):
        self.backend.update_run_name_query(name, run_id)

    def update_thumb_label(self, run_id, thumb_label):
        self.backend.update_run_thumb_label_query(thumb_label, run_id)

    def update_notes(self, run_id, notes):
        self.backend.update_run_notes_query(notes, run_id)

    def update_run_log(self, run_id, log_text):
        self.backend.set_run_log_query(log_text, run_id)

    def append_run_log(self, run_id, log_chunk):
        if not log_chunk:
            return
        self.backend.append_run_log_query(log_chunk, run_id)

    def get_run_log(self, run_id):
        row = self.backend.get_run_log_query(run_id)
        if row is None:
            return None
        return row["log"] or ""

    def update_command(self, run_id, command):
        self.backend.update_run_command_query(command, run_id)

    def get_trace_chat_history(self, run_id):
        row = self.backend.get_run_trace_chat_history_query(run_id)
        if row is None:
            raise ResourceNotFoundError(f"Run not found: {run_id}")
        return self._normalize_trace_chat_history(row["trace_chat_history"])

    def get_run_scope(self, run_id):
        return self.backend.get_run_scope_query(run_id)

    def update_trace_chat_history(self, run_id, history):
        existing = self.backend.get_run_trace_chat_history_query(run_id)
        if existing is None:
            raise ResourceNotFoundError(f"Run not found: {run_id}")
        self.backend.update_run_trace_chat_history_query(
            self._serialize_trace_chat_history(history),
            run_id,
        )

    def set_trace_chat_history_json(self, run_id, trace_chat_history_json):
        existing = self.backend.get_run_trace_chat_history_query(run_id)
        if existing is None:
            raise ResourceNotFoundError(f"Run not found: {run_id}")
        self.backend.update_run_trace_chat_history_query(trace_chat_history_json, run_id)

    def clear_trace_chat_history(self, run_id):
        existing = self.backend.get_run_trace_chat_history_query(run_id)
        if existing is None:
            raise ResourceNotFoundError(f"Run not found: {run_id}")
        self.backend.update_run_trace_chat_history_query("[]", run_id)

    def update_run_version_date(self, run_id, version_date):
        self.backend.update_run_version_date_query(
            self.serialize_timestamp(version_date),
            run_id,
        )

    def add_metrics(self, run_id, metrics):
        row = self.backend.get_run_metrics_context_query(run_id)
        if row is None:
            raise ResourceNotFoundError(f"Run not found: {run_id}")

        existing_metrics = self.parse_custom_metrics(row["custom_metrics"])
        repeated_keys = sorted(set(existing_metrics) & set(metrics))
        if repeated_keys:
            repeated = ", ".join(repeated_keys)
            raise BadRequestError(f"Metrics already logged for this run: {repeated}")

        project_id = row["project_id"]
        project_metric_kind_rows = []
        if project_id:
            existing_kinds = {
                item["metric_key"]: item["metric_kind"]
                for item in self.backend.get_project_metric_kinds_query(project_id)
            }
            for key, value in metrics.items():
                kind = get_metric_kind(value)
                existing_kind = existing_kinds.get(key)
                if existing_kind and existing_kind != kind:
                    raise BadRequestError(
                        f"Metric '{key}' is already registered as kind '{existing_kind}' "
                        "for this project."
                    )
            for key, value in metrics.items():
                if key not in existing_kinds:
                    project_metric_kind_rows.append((
                        project_id,
                        key,
                        get_metric_kind(value),
                    ))

        updated_metrics = {**existing_metrics, **metrics}
        self.backend.persist_run_metrics_query(
            run_id,
            json.dumps(updated_metrics, sort_keys=True),
            self._build_run_metric_rows(run_id, project_id, metrics),
            project_metric_kind_rows,
        )
        return updated_metrics

    def get_run_table_view(self, project_id, exclude_ids, filters, sort_key, sort_dir, limit, offset):
        query_filters = {
            "name": filters.get("name"),
            "run_id": filters.get("run_id"),
            "version_date": filters.get("version_date"),
            "timestamp_from": filters.get("timestamp_from"),
            "timestamp_to": filters.get("timestamp_to"),
            "latency_min": filters.get("latency_min"),
            "latency_max": filters.get("latency_max"),
            "thumb_label": filters.get("thumb_label", []),
            "tag_ids": filters.get("tag_ids", []),
            "custom_metrics": filters.get("custom_metrics", {}),
        }

        rows, total = self.backend.query_runs_filtered(
            project_id,
            exclude_ids,
            query_filters,
            sort_key,
            sort_dir,
            limit,
            offset,
            user_id=self.user_id,
        )
        custom_metric_columns = self.backend.get_project_custom_metric_columns_query(project_id)
        return self._attach_tags_to_rows(rows), total, custom_metric_columns

    def get_finished_runs(self, project_id=None):
        return self.backend.get_finished_runs_query(project_id=project_id, user_id=self.user_id)

    def get_all_runs_sorted(self, limit=None, offset=0, project_id=None):
        rows = self.backend.get_all_runs_sorted_query(
            limit=limit,
            offset=offset,
            project_id=project_id,
            user_id=self.user_id,
        )
        return self._attach_tags_to_rows(rows)

    def get_runs_by_ids(self, run_ids, project_id=None):
        rows = self.backend.get_runs_by_ids_query(run_ids, project_id=project_id, user_id=self.user_id)
        return self._attach_tags_to_rows(rows)

    def get_runs_excluding_ids(self, run_ids, limit=None, offset=0, project_id=None):
        rows = self.backend.get_runs_excluding_ids_query(
            run_ids,
            limit=limit,
            offset=offset,
            project_id=project_id,
            user_id=self.user_id,
        )
        return self._attach_tags_to_rows(rows)

    def get_run_count(self, project_id=None):
        return self.backend.get_run_count_query(project_id=project_id, user_id=self.user_id)

    def get_run_count_excluding_ids(self, run_ids, project_id=None):
        return self.backend.get_run_count_excluding_ids_query(
            run_ids,
            project_id=project_id,
            user_id=self.user_id,
        )

    def get_runs_filtered(self, project_id, exclude_ids, filters, sort_col, sort_dir, limit, offset):
        rows, total = self.backend.query_runs_filtered(
            project_id,
            exclude_ids,
            filters,
            sort_col,
            sort_dir,
            limit,
            offset,
            user_id=self.user_id,
        )
        return self._attach_tags_to_rows(rows), total

    def get_runs_timeseries(self, project_id, time_from, time_to, bucket_seconds):
        return self.backend.get_runs_timeseries_query(
            project_id,
            time_from,
            time_to,
            bucket_seconds,
            user_id=self.user_id,
        )

    def get_duration_timeseries(self, project_id, time_from, time_to, bucket_seconds):
        return self.backend.get_duration_timeseries_query(
            project_id,
            time_from,
            time_to,
            bucket_seconds,
            user_id=self.user_id,
        )

    def get_distinct_versions(self, project_id=None):
        rows = self.backend.get_distinct_versions_query(project_id, user_id=self.user_id)
        return [row["version_date"] for row in rows]

    def get_run_detail(self, run_id):
        row = self.backend.get_run_detail_query(run_id)
        if row is None:
            return None
        return self._attach_tags_to_rows([row])[0]

    def get_graph(self, run_id):
        return self.backend.get_run_graph_topology_query(run_id)

    def set_graph_topology_json(self, run_id, graph_json):
        if self.backend.get_run_graph_topology_query(run_id) is None:
            raise ResourceNotFoundError(f"Run not found: {run_id}")
        self.backend.update_run_graph_topology_query(graph_json, run_id)

    def get_parent_environment(self, parent_run_id):
        return self.backend.get_run_environment_query(parent_run_id)

    def get_exec_command(self, run_id):
        row = self.backend.get_run_exec_info_query(run_id)
        if row is None:
            return None, None, None
        return row["cwd"], row["command"], json.loads(row["environment"])

    def clear_db(self):
        self.backend.delete_all_runs_query()
        self.backend.delete_all_llm_calls_query()

    def delete_runs(self, run_ids):
        return self.backend.delete_runs_by_ids_query(run_ids, user_id=self.user_id)

    def delete_runs_by_ids(self, run_ids, user_id=None):
        return self.backend.delete_runs_by_ids_query(run_ids, user_id=user_id)

    def get_run_name(self, run_id):
        row = self.backend.get_run_name_query(run_id)
        if not row:
            return []
        return [row["name"]]

    def find_run_ids_by_prefix(self, run_id_prefix):
        rows = self.backend.find_run_ids_by_prefix_query(run_id_prefix)
        return [row["run_id"] for row in rows]

    def get_next_run_index(self, project_id=None):
        return self.backend.get_next_run_index_query(project_id=project_id, user_id=self.user_id)

    def get_run_metadata(self, run_id):
        row = self.backend.get_run_metadata_query(run_id)
        if row is None:
            return None
        return self._normalize_run_row(row)
