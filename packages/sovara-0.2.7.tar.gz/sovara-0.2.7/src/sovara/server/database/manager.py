import threading
from collections import defaultdict

from ._shared import BadRequestError, ResourceNotFoundError
from .llm_calls import LlmCallsMixin
from .priors import PriorsMixin
from .projects import ProjectsMixin
from .runs import RunsMixin
from .users import UsersMixin


def _create_backend():
    """Instantiate the configured database backend.

    The backend is selected by reading the effective DB configuration via
    ``get_db_config()``, which honours config.yaml first, then the
    ``SOVARA_DB_BACKEND`` environment variable, then falls back to ``"sqlite"``.

    Supported values: ``"sqlite"``, ``"mongodb"``, ``"postgresql"``.

    Raises ``ValueError`` for unrecognised backend names so misconfigurations
    are caught at startup rather than silently falling back.
    """
    from sovara.common.config import get_db_config

    db_cfg = get_db_config()
    name = db_cfg["backend"].strip().lower()

    if name == "sqlite":
        from sovara.server.database.sqlite.backend import SQLiteBackend
        return SQLiteBackend()

    if name == "mongodb":
        from sovara.server.database.mongodb.backend import MongoBackend
        return MongoBackend()

    if name == "postgresql":
        from sovara.server.database.postgresql.backend import PostgreSQLBackend
        return PostgreSQLBackend()

    raise ValueError(
        f"Unknown database backend {name!r}. "
        "Set db_backend in config.yaml or SOVARA_DB_BACKEND to 'sqlite', 'mongodb', or 'postgresql'."
    )


class DatabaseManager(UsersMixin, ProjectsMixin, RunsMixin, LlmCallsMixin, PriorsMixin):
    """Manages database operations using a pluggable backend."""

    def __init__(self):
        self._occurrence_counters: dict[tuple[str, str], int] = defaultdict(int)
        self._occurrence_lock = threading.Lock()

    @property
    def user_id(self):
        from sovara.common.user import read_user_id

        return read_user_id()

    @property
    def backend(self):
        if not hasattr(self, "_backend_instance"):
            self._backend_instance = _create_backend()
        return self._backend_instance

    def reset_backend(self) -> None:
        """Drop the cached backend so the next access creates a fresh one.

        Called after the user changes DB settings at runtime.  Any in-flight
        requests that have already acquired ``self.backend`` will complete
        against the old backend; only new accesses pick up the new one.
        """
        # Reset connection-level state for the currently active backend type
        # so that the new backend starts with clean connections.
        try:
            from sovara.common.config import get_db_config
            current_name = get_db_config()["backend"].strip().lower()
            if current_name == "sqlite":
                from sovara.server.database.sqlite.connection import reset_connection as _reset
                _reset()
            elif current_name == "mongodb":
                from sovara.server.database.mongodb.connection import reset_client as _reset
                _reset()
            elif current_name == "postgresql":
                from sovara.server.database.postgresql.connection import reset_connection as _reset
                _reset()
        except Exception:
            pass  # Best-effort; backend will be re-created regardless

        if hasattr(self, "_backend_instance"):
            del self._backend_instance

        with self._occurrence_lock:
            self._occurrence_counters.clear()

    def clear_connections(self) -> None:
        clear = getattr(self.backend, "clear_connections", None)
        if callable(clear):
            clear()

    def close_all_connections(self) -> None:
        close = getattr(self.backend, "close_all_connections", None)
        if callable(close):
            close()


DB = DatabaseManager()
