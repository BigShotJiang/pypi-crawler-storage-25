"""MongoDB connection management.

A single ``MongoClient`` is shared across threads (pymongo is thread-safe by
design).  Connection is lazy: the client is created on first use.
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pymongo
    from pymongo.database import Database

_client_lock = threading.Lock()
_client: "pymongo.MongoClient | None" = None
_db: "Database | None" = None


def _get_pymongo():
    try:
        import pymongo  # noqa: F401
        return pymongo
    except ImportError as exc:
        raise ImportError(
            "pymongo is required for the MongoDB backend.  "
            "Install it with: pip install pymongo"
        ) from exc


def get_db():
    """Return the shared ``pymongo.database.Database`` instance."""
    global _client, _db

    if _db is not None:
        return _db

    with _client_lock:
        if _db is not None:
            return _db

        pymongo = _get_pymongo()
        from sovara.common.config import get_db_config
        db_cfg = get_db_config()

        _client = pymongo.MongoClient(
            db_cfg["mongodb_uri"],
            serverSelectionTimeoutMS=5_000,
            connectTimeoutMS=5_000,
            socketTimeoutMS=30_000,
        )
        _db = _client[db_cfg["mongodb_db"]]
        _ensure_indexes(_db)
        return _db


def reset_client() -> None:
    """Close and discard the shared MongoClient so it is recreated on next use.

    Called when the user switches DB backend at runtime.
    """
    global _client, _db
    with _client_lock:
        if _client is not None:
            try:
                _client.close()
            except Exception:
                pass
        _client = None
        _db = None


def _ensure_indexes(db) -> None:
    """Create indexes that mirror the SQLite schema's INDEX definitions."""
    # runs – timestamp desc, project lookup
    db.runs.create_index([("timestamp", -1)], background=True)
    db.runs.create_index(
        [("project_id", 1), ("timestamp", -1)], background=True
    )
    db.runs.create_index([("user_id", 1)], background=True)
    # runs – unique (parent_run_id, name) constraint (sparse because name can be NULL)
    db.runs.create_index(
        [("parent_run_id", 1), ("name", 1)],
        unique=True,
        sparse=True,
        background=True,
    )
    # llm_calls – original input lookup
    db.llm_calls.create_index(
        [("run_id", 1), ("input_hash", 1)], background=True
    )
    # prefix_cache
    db.prefix_cache.create_index(
        [("user_id", 1), ("project_id", 1), ("base_path", 1), ("model", 1), ("clean_pairs_json", 1)],
        unique=True,
        background=True,
    )
    # retrieval_cache
    db.retrieval_cache.create_index(
        [
            ("user_id", 1),
            ("project_id", 1),
            ("priors_revision", 1),
            ("base_path", 1),
            ("model", 1),
            ("context_hash", 1),
            ("ignore_prior_ids_json", 1),
        ],
        unique=True,
        background=True,
    )
    # user_project_locations – unique (user_id, project_location)
    db.user_project_locations.create_index(
        [("user_id", 1), ("project_location", 1)],
        unique=True,
        background=True,
    )
    # prior_retrievals – pk (run_id, node_uuid)
    db.prior_retrievals.create_index(
        [("run_id", 1), ("node_uuid", 1)],
        unique=True,
        background=True,
    )
    # runs – run_id_clean allows efficient prefix search (find_run_ids_by_prefix_query)
    db.runs.create_index([("run_id_clean", 1)], background=True)
    # priors_applied
    db.priors_applied.create_index(
        [("prior_id", 1), ("run_id", 1), ("node_uuid", 1)],
        unique=True,
        sparse=True,
        background=True,
    )
    # project_metric_kinds
    db.project_metric_kinds.create_index(
        [("project_id", 1), ("metric_key", 1)],
        unique=True,
        background=True,
    )
    # run_metric_values
    db.run_metric_values.create_index(
        [("run_id", 1), ("metric_key", 1)],
        unique=True,
        background=True,
    )
    # project_tags – unique (project_id, name)
    db.project_tags.create_index(
        [("project_id", 1), ("name", 1)],
        unique=True,
        background=True,
    )
    # run_tags – pk (run_id, tag_id)
    db.run_tags.create_index(
        [("run_id", 1), ("tag_id", 1)],
        unique=True,
        background=True,
    )
    # priors_scopes
    db.priors_scopes.create_index(
        [("user_id", 1), ("project_id", 1)],
        unique=True,
        background=True,
    )
