"""MongoBackend – implements DatabaseBackend using MongoDB collections.

Design notes
============
* All IDs that were SQLite PRIMARY KEYs are stored as ``_id`` in MongoDB.
* Composite PKs (run_id + node_uuid, etc.) are encoded as a single string
  ``"<a>|<b>"`` stored in ``_id``.
* ``sqlite3.Row`` dict-like access is emulated: every helper that returns
  a document converts it with ``_row()`` / ``_rows()`` which remove the
  internal ``_id`` field and expose the original columns as top-level keys.
* Atomic multi-document operations use pymongo sessions where available
  (requires MongoDB 4.x+ in replica-set or standalone mode with sessions).
  If sessions are not supported the operations are still correct for the
  current use-cases (each individual write is atomic).
"""

from __future__ import annotations

import json
import re
import threading
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any

from sovara.server.database.mongodb.connection import get_db
from sovara.server.priors_backend.constants import (
    DEFAULT_PRIORS_LATENCY_TIER,
    DEFAULT_PRIORS_TRACK_ADHERENCE,
    DEFAULT_PRIORS_TRACK_GROUNDEDNESS,
)


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _now_utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def _row(doc: dict | None, *, drop_id: bool = True) -> dict | None:
    """Convert a MongoDB document to a plain dict mimicking sqlite3.Row access."""
    if doc is None:
        return None
    result = dict(doc)
    if drop_id and "_id" in result:
        del result["_id"]
    return result


def _rows(docs, *, drop_id: bool = True) -> list[dict]:
    return [_row(d, drop_id=drop_id) for d in docs if d is not None]


def _compound_id(*parts: str) -> str:
    return "|".join(parts)


class MongoBackend:
    """MongoDB implementation of the DatabaseBackend protocol."""

    # ──────────────────────────────────────────────────────────────────────────
    # Users
    # ──────────────────────────────────────────────────────────────────────────

    def upsert_user_query(self, user_id: str, full_name: str, email: str) -> None:
        db = get_db()
        db.users.update_one(
            {"_id": user_id},
            {
                "$set": {"full_name": full_name, "email": email},
                "$setOnInsert": {"_id": user_id, "created_at": _now_utc()},
            },
            upsert=True,
        )

    def get_user_query(self, user_id: str) -> dict[str, Any] | None:
        db = get_db()
        doc = db.users.find_one({"_id": user_id})
        if doc is None:
            return None
        result = _row(doc)
        result["user_id"] = user_id
        return result

    def update_user_llm_settings_query(
        self, user_id: str, llm_settings: dict[str, Any]
    ) -> None:
        db = get_db()
        db.users.update_one({"_id": user_id}, {"$set": llm_settings})

    def delete_user_query(self, user_id: str) -> None:
        db = get_db()
        # Find project IDs this user belongs to
        locations = list(db.user_project_locations.find({"user_id": user_id}))
        project_ids = list({loc["project_id"] for loc in locations})

        for project_id in project_ids:
            # Delete project if this user is the only one
            other_users = db.user_project_locations.count_documents(
                {"project_id": project_id, "user_id": {"$ne": user_id}}
            )
            if other_users == 0:
                self.delete_project_query(project_id)

        # Delete user's runs (not already deleted by project deletion)
        run_ids = [
            r["_id"] for r in db.runs.find({"user_id": user_id}, {"_id": 1})
        ]
        if run_ids:
            db.llm_calls.delete_many({"run_id": {"$in": run_ids}})
            db.prior_retrievals.delete_many({"run_id": {"$in": run_ids}})
            db.run_tags.delete_many({"run_id": {"$in": run_ids}})
            db.run_metric_values.delete_many({"run_id": {"$in": run_ids}})
            db.runs.delete_many({"_id": {"$in": run_ids}})

        db.priors_scopes.delete_many({"user_id": user_id})
        db.user_project_locations.delete_many({"user_id": user_id})
        db.users.delete_one({"_id": user_id})

    # ──────────────────────────────────────────────────────────────────────────
    # Projects
    # ──────────────────────────────────────────────────────────────────────────

    def upsert_project_query(
        self,
        project_id: str,
        name: str,
        description: str | None,
        priors_latency_tier: str | None = None,
        priors_track_groundedness: bool | None = None,
        priors_track_adherence: bool | None = None,
    ) -> None:
        if priors_latency_tier is None:
            priors_latency_tier = DEFAULT_PRIORS_LATENCY_TIER
        if priors_track_groundedness is None:
            priors_track_groundedness = DEFAULT_PRIORS_TRACK_GROUNDEDNESS
        if priors_track_adherence is None:
            priors_track_adherence = DEFAULT_PRIORS_TRACK_ADHERENCE

        db = get_db()
        db.projects.update_one(
            {"_id": project_id},
            {
                "$set": {
                    "name": name,
                    "description": description,
                    "priors_latency_tier": priors_latency_tier,
                    "priors_track_groundedness": bool(priors_track_groundedness),
                    "priors_track_adherence": bool(priors_track_adherence),
                },
                "$setOnInsert": {
                    "_id": project_id,
                    "created_at": _now_utc(),
                    "last_run_at": None,
                },
            },
            upsert=True,
        )

    def get_project_query(self, project_id: str) -> dict[str, Any] | None:
        db = get_db()
        doc = db.projects.find_one({"_id": project_id})
        if doc is None:
            return None
        result = _row(doc)
        result["project_id"] = project_id
        return result

    def get_all_projects_query(
        self, user_id: str | None = None
    ) -> list[dict[str, Any]]:
        db = get_db()
        if user_id:
            locs = db.user_project_locations.find({"user_id": user_id})
            project_ids = list({loc["project_id"] for loc in locs})
            cursor = db.projects.find(
                {"_id": {"$in": project_ids}},
                sort=[("last_run_at", -1)],
            )
        else:
            cursor = db.projects.find({}, sort=[("last_run_at", -1)])
        results = []
        for doc in cursor:
            r = _row(doc)
            r["project_id"] = doc["_id"]
            results.append(r)
        return results

    def update_project_last_run_at_query(self, project_id: str) -> None:
        db = get_db()
        db.projects.update_one(
            {"_id": project_id}, {"$set": {"last_run_at": _now_utc()}}
        )

    def get_project_user_count_query(self, project_id: str) -> int:
        db = get_db()
        return db.user_project_locations.distinct(
            "user_id", {"project_id": project_id}
        ).__len__()

    def get_project_tag_count_query(self, project_id: str) -> int:
        db = get_db()
        return db.project_tags.count_documents({"project_id": project_id})

    def get_run_tag_count_query(self, run_id: str) -> int:
        db = get_db()
        return db.run_tags.count_documents({"run_id": run_id})

    def delete_project_query(self, project_id: str) -> None:
        db = get_db()
        run_ids = [
            r["_id"]
            for r in db.runs.find({"project_id": project_id}, {"_id": 1})
        ]
        if run_ids:
            db.llm_calls.delete_many({"run_id": {"$in": run_ids}})
            db.prior_retrievals.delete_many({"run_id": {"$in": run_ids}})
            db.run_tags.delete_many({"run_id": {"$in": run_ids}})
            db.run_metric_values.delete_many({"run_id": {"$in": run_ids}})
            db.runs.delete_many({"_id": {"$in": run_ids}})
        db.priors_scopes.delete_many({"project_id": project_id})
        db.project_metric_kinds.delete_many({"project_id": project_id})
        db.project_tags.delete_many({"project_id": project_id})
        db.user_project_locations.delete_many({"project_id": project_id})
        db.projects.delete_one({"_id": project_id})

    # Project locations

    def upsert_project_location_query(
        self, user_id: str, project_id: str, project_location: str
    ) -> None:
        db = get_db()
        db.user_project_locations.update_one(
            {"user_id": user_id, "project_location": project_location},
            {"$set": {"project_id": project_id}},
            upsert=True,
        )

    def get_project_at_location_query(
        self, user_id: str, project_location: str
    ) -> list[dict[str, Any]]:
        db = get_db()
        return _rows(db.user_project_locations.find(
            {"user_id": user_id, "project_location": project_location}
        ))

    def get_user_project_locations_query(
        self, user_id: str
    ) -> list[dict[str, Any]]:
        db = get_db()
        return _rows(db.user_project_locations.find({"user_id": user_id}))

    def get_project_locations_query(
        self, user_id: str, project_id: str
    ) -> list[dict[str, Any]]:
        db = get_db()
        return _rows(
            db.user_project_locations.find(
                {"user_id": user_id, "project_id": project_id}
            )
        )

    def get_all_project_locations_query(
        self, project_id: str
    ) -> list[dict[str, Any]]:
        db = get_db()
        return _rows(
            db.user_project_locations.find({"project_id": project_id})
        )

    def delete_project_location_query(
        self, user_id: str, project_id: str, project_location: str
    ) -> None:
        db = get_db()
        db.user_project_locations.delete_one(
            {
                "user_id": user_id,
                "project_id": project_id,
                "project_location": project_location,
            }
        )

    # Tags

    def get_project_tags_query(self, project_id: str) -> list[dict[str, Any]]:
        db = get_db()
        docs = db.project_tags.find(
            {"project_id": project_id},
            sort=[("name_lower", 1), ("_id", 1)],
        )
        return [self._tag_row(d) for d in docs]

    def get_project_tag_query(self, tag_id: str) -> dict[str, Any] | None:
        db = get_db()
        doc = db.project_tags.find_one({"_id": tag_id})
        return self._tag_row(doc) if doc else None

    def get_project_tag_by_name_query(
        self, project_id: str, name: str
    ) -> dict[str, Any] | None:
        db = get_db()
        doc = db.project_tags.find_one(
            {"project_id": project_id, "name": {"$regex": f"^{re.escape(name)}$", "$options": "i"}}
        )
        return self._tag_row(doc) if doc else None

    def get_project_tags_by_ids_query(
        self, project_id: str, tag_ids: list[str]
    ) -> list[dict[str, Any]]:
        if not tag_ids:
            return []
        db = get_db()
        docs = db.project_tags.find(
            {"_id": {"$in": tag_ids}, "project_id": project_id},
            sort=[("name_lower", 1), ("_id", 1)],
        )
        return [self._tag_row(d) for d in docs]

    def insert_project_tag_query(
        self, tag_id: str, project_id: str, name: str, color: str
    ) -> None:
        db = get_db()
        db.project_tags.insert_one(
            {
                "_id": tag_id,
                "tag_id": tag_id,
                "project_id": project_id,
                "name": name,
                "name_lower": name.lower(),
                "color": color,
                "created_at": _now_utc(),
            }
        )

    def delete_project_tag_query(self, project_id: str, tag_id: str) -> None:
        db = get_db()
        db.run_tags.delete_many({"tag_id": tag_id})
        db.project_tags.delete_one({"_id": tag_id, "project_id": project_id})

    def get_tags_for_runs_query(
        self, run_ids: list[str]
    ) -> list[dict[str, Any]]:
        if not run_ids:
            return []
        db = get_db()
        rt_docs = list(db.run_tags.find({"run_id": {"$in": run_ids}}))
        if not rt_docs:
            return []
        tag_ids = [d["tag_id"] for d in rt_docs]
        tag_map = {
            d["_id"]: d
            for d in db.project_tags.find({"_id": {"$in": tag_ids}})
        }
        results = []
        for rt in sorted(rt_docs, key=lambda d: (d["run_id"],)):
            tag = tag_map.get(rt["tag_id"])
            if tag:
                results.append(
                    {
                        "run_id": rt["run_id"],
                        "tag_id": tag["_id"],
                        "project_id": tag["project_id"],
                        "name": tag["name"],
                        "color": tag["color"],
                        "created_at": tag["created_at"],
                    }
                )
        return results

    def replace_run_tags_query(self, run_id: str, tag_ids: list[str]) -> None:
        db = get_db()
        db.run_tags.delete_many({"run_id": run_id})
        if tag_ids:
            db.run_tags.insert_many(
                [{"run_id": run_id, "tag_id": tid} for tid in tag_ids]
            )

    # Metric kinds

    def get_project_metric_kinds_query(
        self, project_id: str
    ) -> list[dict[str, Any]]:
        db = get_db()
        return _rows(
            db.project_metric_kinds.find(
                {"project_id": project_id}, sort=[("metric_key", 1)]
            )
        )

    def get_project_custom_metric_columns_query(
        self, project_id: str
    ) -> list[dict[str, Any]]:
        if not project_id:
            return []
        db = get_db()
        columns = []
        for row in self.get_project_metric_kinds_query(project_id):
            metric_key = row["metric_key"]
            metric_kind = row["metric_kind"]
            if metric_kind == "bool":
                exists = db.run_metric_values.find_one(
                    {
                        "project_id": project_id,
                        "metric_key": metric_key,
                        "metric_kind": "bool",
                    }
                )
                if exists:
                    columns.append(
                        {
                            "key": metric_key,
                            "kind": metric_kind,
                            "values": [False, True],
                        }
                    )
                continue
            value_field = "int_value" if metric_kind == "int" else "float_value"
            pipeline = [
                {
                    "$match": {
                        "project_id": project_id,
                        "metric_key": metric_key,
                        "metric_kind": metric_kind,
                        value_field: {"$ne": None},
                    }
                },
                {
                    "$group": {
                        "_id": None,
                        "min_value": {"$min": f"${value_field}"},
                        "max_value": {"$max": f"${value_field}"},
                    }
                },
            ]
            result = list(db.run_metric_values.aggregate(pipeline))
            if not result or result[0]["min_value"] is None:
                continue
            columns.append(
                {
                    "key": metric_key,
                    "kind": metric_kind,
                    "min": result[0]["min_value"],
                    "max": result[0]["max_value"],
                }
            )
        return columns

    def upsert_project_metric_kind_query(
        self, project_id: str, metric_key: str, metric_kind: str
    ) -> None:
        db = get_db()
        db.project_metric_kinds.update_one(
            {"project_id": project_id, "metric_key": metric_key},
            {"$set": {"metric_kind": metric_kind}},
            upsert=True,
        )

    # ──────────────────────────────────────────────────────────────────────────
    # Runs
    # ──────────────────────────────────────────────────────────────────────────

    def add_run_query(
        self,
        run_id: str,
        parent_run_id: str,
        name: str | None,
        default_graph: str,
        timestamp: str | None,
        cwd: str | None,
        command: str | None,
        env_json: str,
        default_note: str,
        default_log: str,
        version_date: str | None,
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> None:
        db = get_db()
        doc = {
            "_id": run_id,
            "run_id": run_id,
            "run_id_clean": run_id.lower().replace("-", ""),
            "parent_run_id": parent_run_id,
            "project_id": project_id,
            "user_id": user_id,
            "name": name,
            "graph_topology": default_graph,
            "timestamp": timestamp,
            "runtime_seconds": None,
            "active_runtime_seconds": None,
            "cwd": cwd,
            "command": command,
            "environment": env_json,
            "version_date": version_date,
            "custom_metrics": "{}",
            "thumb_label": None,
            "notes": default_note,
            "log": default_log,
            "trace_chat_history": "[]",
            "active_edit_node_uuid": None,
            "active_edit_node_label": None,
            "active_edit_field": None,
            "active_edit_status": None,
        }
        db.runs.replace_one({"_id": run_id}, doc, upsert=True)

    def update_run_graph_topology_query(
        self, graph_json: str, run_id: str
    ) -> None:
        get_db().runs.update_one(
            {"_id": run_id}, {"$set": {"graph_topology": graph_json}}
        )

    def get_run_active_edit_query(self, run_id: str) -> dict[str, Any] | None:
        doc = get_db().runs.find_one(
            {"_id": run_id},
            {
                "active_edit_node_uuid": 1,
                "active_edit_node_label": 1,
                "active_edit_field": 1,
                "active_edit_status": 1,
            },
        )
        if doc is None:
            return None
        return {
            "active_edit_node_uuid": doc.get("active_edit_node_uuid"),
            "active_edit_node_label": doc.get("active_edit_node_label"),
            "active_edit_field": doc.get("active_edit_field"),
            "active_edit_status": doc.get("active_edit_status"),
        }

    def set_run_active_edit_query(
        self,
        node_uuid: str,
        node_label: str,
        field: str,
        status: str,
        run_id: str,
    ) -> None:
        get_db().runs.update_one(
            {"_id": run_id},
            {
                "$set": {
                    "active_edit_node_uuid": node_uuid,
                    "active_edit_node_label": node_label,
                    "active_edit_field": field,
                    "active_edit_status": status,
                }
            },
        )

    def update_run_active_edit_status_query(
        self, status: str, run_id: str
    ) -> None:
        get_db().runs.update_one(
            {"_id": run_id}, {"$set": {"active_edit_status": status}}
        )

    def clear_run_active_edit_query(self, run_id: str) -> None:
        get_db().runs.update_one(
            {"_id": run_id},
            {
                "$set": {
                    "active_edit_node_uuid": None,
                    "active_edit_node_label": None,
                    "active_edit_field": None,
                    "active_edit_status": None,
                }
            },
        )

    def update_run_timestamp_query(self, timestamp: str, run_id: str) -> None:
        get_db().runs.update_one(
            {"_id": run_id}, {"$set": {"timestamp": timestamp}}
        )

    def update_run_runtime_seconds_query(
        self, runtime_seconds: float | None, run_id: str
    ) -> None:
        get_db().runs.update_one(
            {"_id": run_id}, {"$set": {"runtime_seconds": runtime_seconds}}
        )

    def update_run_active_runtime_seconds_query(
        self, active_runtime_seconds: float | None, run_id: str
    ) -> None:
        get_db().runs.update_one(
            {"_id": run_id},
            {"$set": {"active_runtime_seconds": active_runtime_seconds}},
        )

    def finalize_run_runtime_query(
        self, runtime_seconds: float, run_id: str
    ) -> None:
        db = get_db()
        doc = db.runs.find_one({"_id": run_id}, {"runtime_seconds": 1})
        existing = doc.get("runtime_seconds") if doc else None
        final = existing if existing is not None else runtime_seconds
        db.runs.update_one(
            {"_id": run_id},
            {"$set": {"runtime_seconds": final, "active_runtime_seconds": None}},
        )

    def clear_run_active_runtime_seconds_query(self, run_id: str) -> None:
        get_db().runs.update_one(
            {"_id": run_id}, {"$set": {"active_runtime_seconds": None}}
        )

    def update_run_name_query(self, name: str, run_id: str) -> None:
        get_db().runs.update_one({"_id": run_id}, {"$set": {"name": name}})

    def update_run_notes_query(self, notes: str, run_id: str) -> None:
        get_db().runs.update_one({"_id": run_id}, {"$set": {"notes": notes}})

    def set_run_log_query(self, log_text: str, run_id: str) -> None:
        get_db().runs.update_one({"_id": run_id}, {"$set": {"log": log_text}})

    def append_run_log_query(self, log_chunk: str, run_id: str) -> None:
        # MongoDB has no native string-append operator; fetch + update is safe
        # enough for the logging use-case (sequential writes per run).
        db = get_db()
        doc = db.runs.find_one({"_id": run_id}, {"log": 1})
        existing = (doc or {}).get("log") or ""
        db.runs.update_one(
            {"_id": run_id}, {"$set": {"log": existing + log_chunk}}
        )

    def get_run_log_query(self, run_id: str) -> dict[str, Any] | None:
        doc = get_db().runs.find_one({"_id": run_id}, {"log": 1})
        if doc is None:
            return None
        return {"log": doc.get("log")}

    def get_run_trace_chat_history_query(
        self, run_id: str
    ) -> dict[str, Any] | None:
        doc = get_db().runs.find_one(
            {"_id": run_id}, {"trace_chat_history": 1}
        )
        if doc is None:
            return None
        return {"trace_chat_history": doc.get("trace_chat_history", "[]")}

    def get_run_scope_query(self, run_id: str) -> dict[str, Any] | None:
        doc = get_db().runs.find_one(
            {"_id": run_id}, {"project_id": 1, "user_id": 1}
        )
        if doc is None:
            return None
        return {"project_id": doc.get("project_id"), "user_id": doc.get("user_id")}

    def update_run_trace_chat_history_query(
        self, trace_chat_history: str, run_id: str
    ) -> None:
        get_db().runs.update_one(
            {"_id": run_id},
            {"$set": {"trace_chat_history": trace_chat_history}},
        )

    def update_run_command_query(self, command: str, run_id: str) -> None:
        get_db().runs.update_one(
            {"_id": run_id}, {"$set": {"command": command}}
        )

    def update_run_version_date_query(
        self, version_date: str | None, run_id: str
    ) -> None:
        get_db().runs.update_one(
            {"_id": run_id}, {"$set": {"version_date": version_date}}
        )

    def update_run_log_query(
        self, updated_log: str, graph_json: str, run_id: str
    ) -> None:
        get_db().runs.update_one(
            {"_id": run_id},
            {"$set": {"log": updated_log, "graph_topology": graph_json}},
        )

    def update_run_custom_metrics_query(
        self, custom_metrics_json: str, run_id: str
    ) -> None:
        get_db().runs.update_one(
            {"_id": run_id}, {"$set": {"custom_metrics": custom_metrics_json}}
        )

    def persist_run_metrics_query(
        self,
        run_id: str,
        custom_metrics_json: str,
        metric_rows: list[tuple],
        project_metric_kind_rows: tuple | list = (),
    ) -> None:
        db = get_db()
        db.runs.update_one(
            {"_id": run_id}, {"$set": {"custom_metrics": custom_metrics_json}}
        )
        for row in metric_rows:
            # row: (run_id, project_id, key, kind, bool_val, int_val, float_val)
            r_run_id, project_id, metric_key, metric_kind, bv, iv, fv = row
            db.run_metric_values.update_one(
                {"run_id": r_run_id, "metric_key": metric_key},
                {
                    "$set": {
                        "run_id": r_run_id,
                        "project_id": project_id,
                        "metric_key": metric_key,
                        "metric_kind": metric_kind,
                        "bool_value": bv,
                        "int_value": iv,
                        "float_value": fv,
                    }
                },
                upsert=True,
            )
        for row in project_metric_kind_rows:
            p_id, m_key, m_kind = row
            db.project_metric_kinds.update_one(
                {"project_id": p_id, "metric_key": m_key},
                {"$set": {"metric_kind": m_kind}},
                upsert=True,
            )

    def update_run_thumb_label_query(
        self, thumb_label: int | None, run_id: str
    ) -> None:
        get_db().runs.update_one(
            {"_id": run_id}, {"$set": {"thumb_label": thumb_label}}
        )

    def get_run_metrics_context_query(
        self, run_id: str
    ) -> dict[str, Any] | None:
        doc = get_db().runs.find_one(
            {"_id": run_id}, {"project_id": 1, "custom_metrics": 1}
        )
        if doc is None:
            return None
        return {
            "project_id": doc.get("project_id"),
            "custom_metrics": doc.get("custom_metrics", "{}"),
        }

    def get_run_tag_context_query(self, run_id: str) -> dict[str, Any] | None:
        doc = get_db().runs.find_one(
            {"_id": run_id}, {"project_id": 1, "user_id": 1}
        )
        if doc is None:
            return None
        return {
            "project_id": doc.get("project_id"),
            "user_id": doc.get("user_id"),
        }

    def get_runs_timeseries_query(
        self,
        project_id: str,
        time_from: str,
        time_to: str,
        bucket_seconds: int,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        db = get_db()
        match: dict[str, Any] = {
            "project_id": project_id,
            "$expr": {"$eq": ["$parent_run_id", "$run_id"]},
            "timestamp": {"$gte": time_from, "$lte": time_to},
        }
        if user_id:
            match["user_id"] = user_id
        pipeline = [
            {"$match": match},
            {
                "$addFields": {
                    "bucket": {
                        "$multiply": [
                            {
                                "$toLong": {
                                    "$divide": [
                                        {"$toLong": {"$toDate": "$timestamp"}},
                                        bucket_seconds * 1000,
                                    ]
                                }
                            },
                            bucket_seconds,
                        ]
                    }
                }
            },
            {"$group": {"_id": "$bucket", "count": {"$sum": 1}}},
            {"$sort": {"_id": 1}},
        ]
        results = []
        for doc in db.runs.aggregate(pipeline):
            bucket_start = datetime.utcfromtimestamp(doc["_id"]).strftime(
                "%Y-%m-%d %H:%M:%S"
            )
            results.append({"bucket_start": bucket_start, "count": doc["count"]})
        return results

    def get_duration_timeseries_query(
        self,
        project_id: str,
        time_from: str,
        time_to: str,
        bucket_seconds: int,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        db = get_db()
        match: dict[str, Any] = {
            "project_id": project_id,
            "$expr": {"$eq": ["$parent_run_id", "$run_id"]},
            "runtime_seconds": {"$ne": None},
            "timestamp": {"$gte": time_from, "$lte": time_to},
        }
        if user_id:
            match["user_id"] = user_id
        pipeline = [
            {"$match": match},
            {
                "$addFields": {
                    "bucket": {
                        "$multiply": [
                            {
                                "$toLong": {
                                    "$divide": [
                                        {"$toLong": {"$toDate": "$timestamp"}},
                                        bucket_seconds * 1000,
                                    ]
                                }
                            },
                            bucket_seconds,
                        ]
                    }
                }
            },
            {
                "$group": {
                    "_id": "$bucket",
                    "values": {"$push": "$runtime_seconds"},
                }
            },
            {"$sort": {"_id": 1}},
        ]
        results = []
        for doc in db.runs.aggregate(pipeline):
            vals = sorted(doc["values"])
            n = len(vals)
            avg = sum(vals) / n if n else 0.0
            # P95 via linear interpolation
            if n == 0:
                p95 = 0.0
            elif n == 1:
                p95 = vals[0]
            else:
                idx = 0.95 * (n - 1)
                lo = int(idx)
                hi = lo + 1
                p95 = (
                    vals[-1]
                    if hi >= n
                    else vals[lo] + (idx - lo) * (vals[hi] - vals[lo])
                )
            bucket_start = datetime.utcfromtimestamp(doc["_id"]).strftime(
                "%Y-%m-%d %H:%M:%S"
            )
            results.append(
                {
                    "bucket_start": bucket_start,
                    "avg": round(avg, 3),
                    "p95": round(p95, 3),
                }
            )
        return results

    def get_finished_runs_query(
        self, project_id: str | None = None, user_id: str | None = None
    ) -> list[dict[str, Any]]:
        db = get_db()
        flt: dict[str, Any] = {}
        if project_id:
            flt["project_id"] = project_id
        if user_id:
            flt["user_id"] = user_id
        return [
            {"run_id": d["_id"], "timestamp": d.get("timestamp")}
            for d in db.runs.find(flt, {"timestamp": 1}, sort=[("timestamp", -1)])
        ]

    def _run_list_doc(self, doc: dict) -> dict:
        return {
            "run_id": doc["_id"],
            "project_id": doc.get("project_id"),
            "timestamp": doc.get("timestamp"),
            "runtime_seconds": doc.get("runtime_seconds"),
            "active_runtime_seconds": doc.get("active_runtime_seconds"),
            "name": doc.get("name"),
            "version_date": doc.get("version_date"),
            "custom_metrics": doc.get("custom_metrics", "{}"),
            "thumb_label": doc.get("thumb_label"),
            # These will be filled by the mixin's tag-attachment logic
            "tags": [],
            "active_edit_node_uuid": doc.get("active_edit_node_uuid"),
            "active_edit_node_label": doc.get("active_edit_node_label"),
            "active_edit_field": doc.get("active_edit_field"),
            "active_edit_status": doc.get("active_edit_status"),
        }

    def get_all_runs_sorted_query(
        self,
        limit: int | None = None,
        offset: int = 0,
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        db = get_db()
        flt: dict[str, Any] = {}
        if project_id:
            flt["project_id"] = project_id
        if user_id:
            flt["user_id"] = user_id
        cursor = db.runs.find(flt, sort=[("timestamp", -1)]).skip(offset)
        if limit is not None:
            cursor = cursor.limit(limit)
        return [self._run_list_doc(d) for d in cursor]

    def get_runs_by_ids_query(
        self,
        run_ids: list[str],
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        if not run_ids:
            return []
        db = get_db()
        flt: dict[str, Any] = {"_id": {"$in": run_ids}}
        if project_id:
            flt["project_id"] = project_id
        if user_id:
            flt["user_id"] = user_id
        return [
            self._run_list_doc(d)
            for d in db.runs.find(flt, sort=[("timestamp", -1)])
        ]

    def get_runs_excluding_ids_query(
        self,
        run_ids: list[str],
        limit: int | None = None,
        offset: int = 0,
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        db = get_db()
        flt: dict[str, Any] = {}
        if run_ids:
            flt["_id"] = {"$nin": run_ids}
        if project_id:
            flt["project_id"] = project_id
        if user_id:
            flt["user_id"] = user_id
        cursor = db.runs.find(flt, sort=[("timestamp", -1)]).skip(offset)
        if limit is not None:
            cursor = cursor.limit(limit)
        return [self._run_list_doc(d) for d in cursor]

    def get_run_count_query(
        self, project_id: str | None = None, user_id: str | None = None
    ) -> int:
        db = get_db()
        flt: dict[str, Any] = {}
        if project_id:
            flt["project_id"] = project_id
        if user_id:
            flt["user_id"] = user_id
        return db.runs.count_documents(flt)

    def get_run_count_excluding_ids_query(
        self,
        run_ids: list[str],
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> int:
        db = get_db()
        flt: dict[str, Any] = {}
        if run_ids:
            flt["_id"] = {"$nin": run_ids}
        if project_id:
            flt["project_id"] = project_id
        if user_id:
            flt["user_id"] = user_id
        return db.runs.count_documents(flt)

    def query_runs_filtered(
        self,
        project_id: str,
        exclude_ids: list[str],
        filters: dict[str, Any],
        sort_col: str,
        sort_dir: str,
        limit: int,
        offset: int,
        user_id: str | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        db = get_db()
        flt: dict[str, Any] = {"project_id": project_id}
        if exclude_ids:
            flt["_id"] = {"$nin": exclude_ids}
        if user_id:
            flt["user_id"] = user_id

        filters = filters or {}
        if filters.get("name"):
            flt["name"] = {"$regex": filters["name"], "$options": "i"}
        if filters.get("run_id"):
            flt["run_id"] = {"$regex": filters["run_id"], "$options": "i"}
        if filters.get("version_date"):
            flt["version_date"] = {"$in": filters["version_date"]}
        if filters.get("timestamp_from"):
            flt.setdefault("timestamp", {})["$gte"] = str(filters["timestamp_from"])
        if filters.get("timestamp_to"):
            flt.setdefault("timestamp", {})["$lte"] = str(filters["timestamp_to"])

        # Thumb label filter
        label_tokens = [
            t for t in filters.get("thumb_label", []) if t in {"up", "down", "none"}
        ]
        if label_tokens:
            label_conditions: list[dict] = []
            if "up" in label_tokens:
                label_conditions.append({"thumb_label": 1})
            if "down" in label_tokens:
                label_conditions.append({"thumb_label": 0})
            if "none" in label_tokens:
                label_conditions.append({"thumb_label": None})
            flt["$or"] = label_conditions

        # Tag filters – each tag_id must appear in run_tags for this run
        for tag_id in filters.get("tag_ids", []) or []:
            tagged_run_ids = [
                d["run_id"]
                for d in db.run_tags.find({"tag_id": tag_id}, {"run_id": 1})
            ]
            flt.setdefault("_id", {})
            flt["_id"] = {"$in": tagged_run_ids}

        # Sort
        mongo_sort_key = {
            "runId": "run_id",
            "name": "name",
            "timestamp": "timestamp",
            "latency": "runtime_seconds",
            "thumbLabel": "thumb_label",
        }.get(sort_col, "timestamp")
        direction = -1 if str(sort_dir).lower() == "desc" else 1

        total = db.runs.count_documents(flt)
        cursor = (
            db.runs.find(flt, sort=[(mongo_sort_key, direction)])
            .skip(offset)
            .limit(limit)
        )
        return [self._run_list_doc(d) for d in cursor], total

    def get_distinct_versions_query(
        self, project_id: str | None = None, user_id: str | None = None
    ) -> list[dict[str, Any]]:
        db = get_db()
        flt: dict[str, Any] = {"version_date": {"$ne": None}}
        if project_id:
            flt["project_id"] = project_id
        if user_id:
            flt["user_id"] = user_id
        values = db.runs.distinct("version_date", flt)
        return [{"version_date": v} for v in values]

    def get_run_detail_query(self, run_id: str) -> dict[str, Any] | None:
        doc = get_db().runs.find_one({"_id": run_id})
        if doc is None:
            return None
        result = self._run_list_doc(doc)
        # Add extra fields present in the detail view
        for field in ("notes", "log", "success", "environment", "cwd", "command"):
            result[field] = doc.get(field)
        return result

    def get_run_graph_topology_query(self, run_id: str) -> dict[str, Any] | None:
        doc = get_db().runs.find_one({"_id": run_id}, {"graph_topology": 1})
        if doc is None:
            return None
        return {"graph_topology": doc.get("graph_topology")}

    def get_run_environment_query(
        self, parent_run_id: str
    ) -> dict[str, Any] | None:
        doc = get_db().runs.find_one(
            {"_id": parent_run_id}, {"environment": 1}
        )
        if doc is None:
            return None
        return {"environment": doc.get("environment")}

    def get_run_exec_info_query(self, run_id: str) -> dict[str, Any] | None:
        doc = get_db().runs.find_one(
            {"_id": run_id}, {"cwd": 1, "command": 1, "environment": 1}
        )
        if doc is None:
            return None
        return {
            "cwd": doc.get("cwd"),
            "command": doc.get("command"),
            "environment": doc.get("environment"),
        }

    def delete_all_runs_query(self) -> None:
        db = get_db()
        db.llm_calls.delete_many({})
        db.prior_retrievals.delete_many({})
        db.run_tags.delete_many({})
        db.run_metric_values.delete_many({})
        db.runs.delete_many({})

    def delete_runs_by_ids_query(
        self, run_ids: list[str], user_id: str | None = None
    ) -> Any:
        if not run_ids:
            return 0
        db = get_db()
        flt: dict[str, Any] = {"_id": {"$in": run_ids}}
        if user_id:
            flt["user_id"] = user_id
        actual_ids = [d["_id"] for d in db.runs.find(flt, {"_id": 1})]
        if not actual_ids:
            return 0
        db.llm_calls.delete_many({"run_id": {"$in": actual_ids}})
        db.prior_retrievals.delete_many({"run_id": {"$in": actual_ids}})
        db.run_tags.delete_many({"run_id": {"$in": actual_ids}})
        db.run_metric_values.delete_many({"run_id": {"$in": actual_ids}})
        result = db.runs.delete_many({"_id": {"$in": actual_ids}})
        return result.deleted_count

    def get_run_name_query(self, run_id: str) -> dict[str, Any] | None:
        doc = get_db().runs.find_one({"_id": run_id}, {"name": 1})
        if doc is None:
            return None
        return {"name": doc.get("name")}

    def find_run_ids_by_prefix_query(
        self, run_id_prefix: str
    ) -> list[dict[str, Any]]:
        db = get_db()
        # Normalise: remove hyphens and compare lowercase.
        # run_id_clean is stored and indexed so this avoids a full collection scan.
        prefix_clean = re.escape(run_id_prefix.lower().replace("-", ""))
        docs = db.runs.find(
            {"run_id_clean": {"$regex": f"^{prefix_clean}"}},
            {"_id": 1},
            sort=[("timestamp", -1)],
        )
        return [{"run_id": d["_id"]} for d in docs]

    def get_run_log_success_graph_query(
        self, run_id: str
    ) -> dict[str, Any] | None:
        doc = get_db().runs.find_one(
            {"_id": run_id}, {"log": 1, "graph_topology": 1}
        )
        if doc is None:
            return None
        return {"log": doc.get("log"), "graph_topology": doc.get("graph_topology")}

    def get_next_run_index_query(
        self, project_id: str | None = None, user_id: str | None = None
    ) -> int:
        db = get_db()
        flt: dict[str, Any] = {}
        if project_id:
            flt["project_id"] = project_id
        if user_id:
            flt["user_id"] = user_id
        return db.runs.count_documents(flt) + 1

    def get_run_metadata_query(self, run_id: str) -> dict[str, Any] | None:
        doc = get_db().runs.find_one({"_id": run_id})
        if doc is None:
            return None
        return {
            "run_id": doc["_id"],
            "parent_run_id": doc.get("parent_run_id"),
            "name": doc.get("name"),
            "timestamp": doc.get("timestamp"),
            "custom_metrics": doc.get("custom_metrics", "{}"),
            "thumb_label": doc.get("thumb_label"),
            "notes": doc.get("notes"),
            "log": doc.get("log"),
            "graph_topology": doc.get("graph_topology"),
            "version_date": doc.get("version_date"),
            # active_edit fields expected by _normalize_run_row
            "active_edit_node_uuid": doc.get("active_edit_node_uuid"),
            "active_edit_node_label": doc.get("active_edit_node_label"),
            "active_edit_field": doc.get("active_edit_field"),
            "active_edit_status": doc.get("active_edit_status"),
            "tags": [],
            "active_runtime_seconds": doc.get("active_runtime_seconds"),
            "runtime_seconds": doc.get("runtime_seconds"),
        }

    # ──────────────────────────────────────────────────────────────────────────
    # LLM calls
    # ──────────────────────────────────────────────────────────────────────────

    def set_input_overwrite_query(
        self, input_overwrite: str, run_id: str, node_uuid: str
    ) -> None:
        get_db().llm_calls.update_one(
            {"run_id": run_id, "node_uuid": node_uuid},
            {"$set": {"input_overwrite": input_overwrite}},
        )

    def set_output_overwrite_query(
        self, output_overwrite: str, run_id: str, node_uuid: str
    ) -> None:
        get_db().llm_calls.update_one(
            {"run_id": run_id, "node_uuid": node_uuid},
            {"$set": {"output_overwrite": output_overwrite}},
        )

    def clear_input_overwrite_query(self, run_id: str, node_uuid: str) -> None:
        get_db().llm_calls.update_one(
            {"run_id": run_id, "node_uuid": node_uuid},
            {"$set": {"input_overwrite": None}},
        )

    def clear_output_overwrite_query(self, run_id: str, node_uuid: str) -> None:
        get_db().llm_calls.update_one(
            {"run_id": run_id, "node_uuid": node_uuid},
            {"$set": {"output_overwrite": None}},
        )

    def delete_llm_calls_query(self, run_id: str) -> None:
        db = get_db()
        db.prior_retrievals.delete_many({"run_id": run_id})
        db.llm_calls.delete_many({"run_id": run_id})

    def delete_all_llm_calls_query(self) -> None:
        db = get_db()
        db.prior_retrievals.delete_many({})
        db.llm_calls.delete_many({})

    def get_subrun_by_parent_and_name_query(
        self, parent_run_id: str, name: str
    ) -> dict[str, Any] | None:
        doc = get_db().runs.find_one(
            {"parent_run_id": parent_run_id, "name": name}, {"_id": 1}
        )
        if doc is None:
            return None
        return {"run_id": doc["_id"]}

    def get_parent_run_id_query(self, run_id: str) -> dict[str, Any] | None:
        doc = get_db().runs.find_one({"_id": run_id}, {"parent_run_id": 1})
        if doc is None:
            return None
        return {"parent_run_id": doc.get("parent_run_id")}

    def get_llm_call_by_run_and_hash_query(
        self, run_id: str, input_hash: str, offset: int = 0
    ) -> dict[str, Any] | None:
        docs = list(
            get_db().llm_calls.find(
                {"run_id": run_id, "input_hash": input_hash},
                {
                    "node_uuid": 1,
                    "input": 1,
                    "input_overwrite": 1,
                    "output": 1,
                    "output_overwrite": 1,
                    "status": 1,
                    "latency_seconds": 1,
                    "error": 1,
                },
            ).skip(offset).limit(1)
        )
        return _row(docs[0]) if docs else None

    def insert_llm_call_with_output_query(
        self,
        run_id: str,
        input_pickle: str,
        input_hash: str,
        node_uuid: str,
        api_type: str,
        output_pickle: str,
        stack_trace: str | None = None,
        node_kind: str | None = None,
        prompt_suffix_json: str = "[]",
    ) -> None:
        db = get_db()
        db.llm_calls.update_one(
            {"run_id": run_id, "node_uuid": node_uuid},
            {
                "$set": {
                    "run_id": run_id,
                    "node_uuid": node_uuid,
                    "input": input_pickle,
                    "input_hash": input_hash,
                    "output": output_pickle,
                    "output_overwrite": None,
                    "api_type": api_type,
                    "stack_trace": stack_trace,
                    "node_kind": node_kind,
                    "prompt_suffix_json": prompt_suffix_json,
                    "status": "success",
                    "error": None,
                    "latency_seconds": None,
                }
            },
            upsert=True,
        )

    def copy_llm_calls_query(self, old_run_id: str, new_run_id: str) -> None:
        db = get_db()
        docs = list(db.llm_calls.find({"run_id": old_run_id}))
        for doc in docs:
            new_doc = {k: v for k, v in doc.items() if k != "_id"}
            new_doc["run_id"] = new_run_id
            db.llm_calls.insert_one(new_doc)

    def find_node_uuids_by_prefix_query(
        self, run_id: str, node_uuid_prefix: str
    ) -> list[dict[str, Any]]:
        db = get_db()
        prefix_clean = node_uuid_prefix.lower().replace("-", "")
        docs = list(db.llm_calls.find({"run_id": run_id}, {"node_uuid": 1}))
        return [
            {"node_uuid": d["node_uuid"]}
            for d in docs
            if d["node_uuid"].lower().replace("-", "").startswith(prefix_clean)
        ]

    def get_llm_call_input_api_type_query(
        self, run_id: str, node_uuid: str
    ) -> dict[str, Any] | None:
        doc = get_db().llm_calls.find_one(
            {"run_id": run_id, "node_uuid": node_uuid},
            {"input": 1, "api_type": 1, "input_overwrite": 1},
        )
        return _row(doc)

    def get_llm_call_output_api_type_query(
        self, run_id: str, node_uuid: str
    ) -> dict[str, Any] | None:
        doc = get_db().llm_calls.find_one(
            {"run_id": run_id, "node_uuid": node_uuid},
            {"output": 1, "output_overwrite": 1, "api_type": 1},
        )
        return _row(doc)

    def get_llm_calls_for_run_query(self, run_id: str) -> list[dict[str, Any]]:
        return _rows(get_db().llm_calls.find({"run_id": run_id}))

    def get_llm_call_full_query(
        self, run_id: str, node_uuid: str
    ) -> dict[str, Any] | None:
        doc = get_db().llm_calls.find_one(
            {"run_id": run_id, "node_uuid": node_uuid}
        )
        return _row(doc)

    def begin_llm_call_query(
        self,
        run_id: str,
        input_pickle: str,
        input_hash: str,
        node_uuid: str,
        api_type: str,
        stack_trace: str | None = None,
        node_kind: str | None = None,
        prompt_suffix_json: str = "[]",
    ) -> None:
        get_db().llm_calls.insert_one(
            {
                "run_id": run_id,
                "node_uuid": node_uuid,
                "input": input_pickle,
                "input_hash": input_hash,
                "api_type": api_type,
                "stack_trace": stack_trace,
                "node_kind": node_kind,
                "prompt_suffix_json": prompt_suffix_json,
                "status": "in_flight",
                "error": None,
                "output": None,
                "input_overwrite": None,
                "output_overwrite": None,
                "color": None,
                "label": None,
                "llm_verdict": None,
                "input_tokens": None,
                "output_tokens": None,
                "latency_seconds": None,
                "timestamp": _now_utc(),
            }
        )

    def mark_llm_call_in_flight_query(self, run_id: str, node_uuid: str) -> None:
        get_db().llm_calls.update_one(
            {"run_id": run_id, "node_uuid": node_uuid},
            {
                "$set": {
                    "status": "in_flight",
                    "error": None,
                    "latency_seconds": None,
                }
            },
        )

    def finalize_llm_call_query(
        self,
        run_id: str,
        node_uuid: str,
        *,
        input_pickle: str | None = None,
        input_hash: str | None = None,
        output_json: str | None = None,
        status: str,
        latency_seconds: float | None = None,
        error_json: str | None = None,
        stack_trace: str | None = None,
        node_kind: str | None = None,
        prompt_suffix_json: str | None = None,
        consume_edit_field: str | None = None,
        clear_output: bool = False,
    ) -> None:
        updates: dict[str, Any] = {"status": status, "error": error_json}
        if input_pickle is not None:
            updates["input"] = input_pickle
        if input_hash is not None:
            updates["input_hash"] = input_hash
        if output_json is not None:
            updates["output"] = output_json
            # Extract token counts inline (mirrors the SQLite implementation)
            try:
                out = json.loads(output_json)
                raw = out.get("raw") if isinstance(out, dict) else None
                if isinstance(raw, dict):
                    content = raw.get("content")
                    if isinstance(content, dict):
                        usage = content.get("usage") or content.get("usageMetadata") or {}
                        inp_tok = usage.get("prompt_tokens") or usage.get("input_tokens") or usage.get("promptTokenCount")
                        out_tok = usage.get("completion_tokens") or usage.get("output_tokens") or usage.get("candidatesTokenCount")
                        if inp_tok is not None:
                            updates["input_tokens"] = int(inp_tok)
                        if out_tok is not None:
                            updates["output_tokens"] = int(out_tok)
            except Exception:
                pass
        elif clear_output:
            updates["output"] = None
        if latency_seconds is not None:
            updates["latency_seconds"] = latency_seconds
        if stack_trace is not None:
            updates["stack_trace"] = stack_trace
        if node_kind is not None:
            updates["node_kind"] = node_kind
        if prompt_suffix_json is not None:
            updates["prompt_suffix_json"] = prompt_suffix_json
        if consume_edit_field == "input":
            updates["input_overwrite"] = None
        if consume_edit_field == "output":
            updates["output_overwrite"] = None

        get_db().llm_calls.update_one(
            {"run_id": run_id, "node_uuid": node_uuid},
            {"$set": updates},
        )

    def set_llm_verdict_query(
        self, run_id: str, node_uuid: str, llm_verdict: str | None
    ) -> None:
        get_db().llm_calls.update_one(
            {"run_id": run_id, "node_uuid": node_uuid},
            {"$set": {"llm_verdict": llm_verdict}},
        )

    def get_tokens_timeseries_query(
        self,
        project_id: str,
        time_from: str,
        time_to: str,
        bucket_seconds: int,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        db = get_db()
        run_flt: dict[str, Any] = {
            "project_id": project_id,
            "$expr": {"$eq": ["$parent_run_id", "$run_id"]},
            "timestamp": {"$gte": time_from, "$lte": time_to},
        }
        if user_id:
            run_flt["user_id"] = user_id
        top_level_run_ids = [
            d["_id"] for d in db.runs.find(run_flt, {"_id": 1, "timestamp": 1})
        ]
        run_ts_map = {
            d["_id"]: d.get("timestamp")
            for d in db.runs.find({"_id": {"$in": top_level_run_ids}}, {"timestamp": 1})
        }

        pipeline = [
            {
                "$match": {
                    "run_id": {"$in": top_level_run_ids},
                    "input_tokens": {"$ne": None},
                    "output_tokens": {"$ne": None},
                    "node_kind": "llm",
                }
            },
        ]
        # Enrich with timestamp from runs, then bucket
        lc_docs = list(db.llm_calls.aggregate(pipeline))
        buckets: dict[int, dict[str, int]] = defaultdict(
            lambda: {"input_tokens": 0, "output_tokens": 0}
        )
        for doc in lc_docs:
            ts_str = run_ts_map.get(doc["run_id"])
            if not ts_str:
                continue
            try:
                ts_epoch = int(
                    datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S")
                    .replace(tzinfo=timezone.utc)
                    .timestamp()
                )
            except (ValueError, TypeError):
                continue
            bucket_key = (ts_epoch // bucket_seconds) * bucket_seconds
            buckets[bucket_key]["input_tokens"] += doc.get("input_tokens") or 0
            buckets[bucket_key]["output_tokens"] += doc.get("output_tokens") or 0

        results = []
        for bk in sorted(buckets):
            bs = datetime.utcfromtimestamp(bk).strftime("%Y-%m-%d %H:%M:%S")
            results.append(
                {
                    "bucket_start": bs,
                    "input_tokens": buckets[bk]["input_tokens"],
                    "output_tokens": buckets[bk]["output_tokens"],
                }
            )
        return results

    # ──────────────────────────────────────────────────────────────────────────
    # Priors
    # ──────────────────────────────────────────────────────────────────────────

    def copy_prior_retrievals_query(
        self, old_run_id: str, new_run_id: str
    ) -> None:
        db = get_db()
        docs = list(db.prior_retrievals.find({"run_id": old_run_id}))
        for doc in docs:
            new_doc = {k: v for k, v in doc.items() if k != "_id"}
            retrieval_id = str(uuid.uuid4())
            new_doc["_id"] = retrieval_id
            new_doc["retrieval_id"] = retrieval_id
            new_doc["run_id"] = new_run_id
            db.prior_retrievals.update_one(
                {"run_id": new_run_id, "node_uuid": new_doc["node_uuid"]},
                {"$setOnInsert": new_doc},
                upsert=True,
            )

    def get_prior_retrieval_by_id_query(
        self, retrieval_id: str
    ) -> dict[str, Any] | None:
        doc = get_db().prior_retrievals.find_one({"retrieval_id": retrieval_id})
        return _row(doc)

    def delete_prior_retrieval_by_id_query(self, retrieval_id: str) -> None:
        get_db().prior_retrievals.delete_one({"retrieval_id": retrieval_id})

    def get_prior_retrieval_query(
        self, run_id: str, node_uuid: str
    ) -> dict[str, Any] | None:
        doc = get_db().prior_retrievals.find_one(
            {"run_id": run_id, "node_uuid": node_uuid},
            sort=[("updated_at", -1), ("retrieval_id", -1)],
        )
        return _row(doc)

    def get_prior_retrievals_for_run_query(
        self, run_id: str
    ) -> list[dict[str, Any]]:
        return _rows(
            get_db().prior_retrievals.find(
                {"run_id": run_id},
                sort=[("created_at", 1), ("node_uuid", 1)],
            )
        )

    def upsert_prior_retrieval_query(
        self,
        retrieval_id: str,
        run_id: str,
        node_uuid: str | None,
        raw_context: str,
        processed_context: str,
        inherited_prior_ids_json: str,
        retrieved_priors_json: str,
        applied_priors_json: str,
        rendered_priors_block: str,
        injection_anchor_json: str | None,
        model: str | None,
        latency_tier: str,
        timeout_ms: int | None,
        retrieval_latency_ms: int | None,
        prior_coverage: int | None,
        retrieval_status: str,
        coverage_status: str,
        warning_message: str | None,
        error_message: str | None,
        groundedness_total_importance: int | None,
        groundedness_grounded_importance: int | None,
        groundedness_guidance_points_json: str,
        adherence_status: str,
        prior_adherence: int | None,
        severity_weighted_prior_adherence: int | None,
        relevant_prior_count: int | None,
        followed_relevant_prior_count: int | None,
        violated_relevant_prior_count: int | None,
        total_non_adherence_severity: int | None,
        max_non_adherence_severity: int | None,
        prior_adherence_items_json: str,
    ) -> None:
        now = _now_utc()
        get_db().prior_retrievals.update_one(
            {"retrieval_id": retrieval_id},
            {
                "$set": {
                    "retrieval_id": retrieval_id,
                    "run_id": run_id,
                    "node_uuid": node_uuid,
                    "raw_context": raw_context,
                    "processed_context": processed_context,
                    "inherited_prior_ids_json": inherited_prior_ids_json,
                    "retrieved_priors_json": retrieved_priors_json,
                    "applied_priors_json": applied_priors_json,
                    "rendered_priors_block": rendered_priors_block,
                    "injection_anchor_json": injection_anchor_json,
                    "model": model,
                    "latency_tier": latency_tier,
                    "timeout_ms": timeout_ms,
                    "retrieval_latency_ms": retrieval_latency_ms,
                    "prior_coverage": prior_coverage,
                    "retrieval_status": retrieval_status,
                    "coverage_status": coverage_status,
                    "warning_message": warning_message,
                    "error_message": error_message,
                    "groundedness_total_importance": groundedness_total_importance,
                    "groundedness_grounded_importance": groundedness_grounded_importance,
                    "groundedness_guidance_points_json": groundedness_guidance_points_json,
                    "adherence_status": adherence_status,
                    "prior_adherence": prior_adherence,
                    "severity_weighted_prior_adherence": severity_weighted_prior_adherence,
                    "relevant_prior_count": relevant_prior_count,
                    "followed_relevant_prior_count": followed_relevant_prior_count,
                    "violated_relevant_prior_count": violated_relevant_prior_count,
                    "total_non_adherence_severity": total_non_adherence_severity,
                    "max_non_adherence_severity": max_non_adherence_severity,
                    "prior_adherence_items_json": prior_adherence_items_json,
                    "updated_at": now,
                },
                "$setOnInsert": {
                    "_id": retrieval_id,
                    "retrieval_id": retrieval_id,
                    "run_id": run_id,
                    "node_uuid": node_uuid,
                    "created_at": now,
                },
            },
            upsert=True,
        )

    def update_prior_coverage_query(
        self,
        retrieval_id: str,
        prior_coverage: int | None,
        coverage_status: str,
        groundedness_total_importance: int | None,
        groundedness_grounded_importance: int | None,
        groundedness_guidance_points_json: str,
    ) -> None:
        get_db().prior_retrievals.update_one(
            {"retrieval_id": retrieval_id},
            {
                "$set": {
                    "prior_coverage": prior_coverage,
                    "coverage_status": coverage_status,
                    "groundedness_total_importance": groundedness_total_importance,
                    "groundedness_grounded_importance": groundedness_grounded_importance,
                    "groundedness_guidance_points_json": groundedness_guidance_points_json,
                    "updated_at": _now_utc(),
                }
            },
        )

    def update_prior_adherence_query(
        self,
        retrieval_id: str,
        adherence_status: str,
        prior_adherence: int | None,
        severity_weighted_prior_adherence: int | None,
        relevant_prior_count: int | None,
        followed_relevant_prior_count: int | None,
        violated_relevant_prior_count: int | None,
        total_non_adherence_severity: int | None,
        max_non_adherence_severity: int | None,
        prior_adherence_items_json: str,
    ) -> None:
        get_db().prior_retrievals.update_one(
            {"retrieval_id": retrieval_id},
            {
                "$set": {
                    "adherence_status": adherence_status,
                    "prior_adherence": prior_adherence,
                    "severity_weighted_prior_adherence": severity_weighted_prior_adherence,
                    "relevant_prior_count": relevant_prior_count,
                    "followed_relevant_prior_count": followed_relevant_prior_count,
                    "violated_relevant_prior_count": violated_relevant_prior_count,
                    "total_non_adherence_severity": total_non_adherence_severity,
                    "max_non_adherence_severity": max_non_adherence_severity,
                    "prior_adherence_items_json": prior_adherence_items_json,
                    "updated_at": _now_utc(),
                }
            },
        )

    def get_pending_prior_coverage_jobs_query(self, limit: int) -> list[dict[str, Any]]:
        return _rows(
            get_db().prior_retrievals.find(
                {
                    "$or": [
                        {"coverage_status": "pending"},
                        {"adherence_status": "pending"},
                    ]
                },
                sort=[("created_at", 1), ("retrieval_id", 1)],
                limit=limit,
            )
        )

    def get_prior_coverage_cache_query(self, cache_key: str) -> dict[str, Any] | None:
        doc = get_db().prior_coverage_cache.find_one({"cache_key": cache_key})
        return _row(doc)

    def upsert_prior_coverage_cache_query(
        self,
        cache_key: str,
        processed_context_hash: str,
        llm_output_hash: str,
        priors_hash: str,
        judge_model: str,
        judge_tier: str,
        reasoning_effort: str,
        prompt_version: str,
        prior_coverage: int,
        total_importance: int | None,
        grounded_importance: int | None,
        guidance_points_json: str,
    ) -> None:
        get_db().prior_coverage_cache.update_one(
            {"cache_key": cache_key},
            {
                "$set": {
                    "cache_key": cache_key,
                    "processed_context_hash": processed_context_hash,
                    "llm_output_hash": llm_output_hash,
                    "priors_hash": priors_hash,
                    "judge_model": judge_model,
                    "judge_tier": judge_tier,
                    "reasoning_effort": reasoning_effort,
                    "prompt_version": prompt_version,
                    "prior_coverage": prior_coverage,
                    "total_importance": total_importance,
                    "grounded_importance": grounded_importance,
                    "guidance_points_json": guidance_points_json,
                    "updated_at": _now_utc(),
                },
                "$setOnInsert": {"_id": cache_key, "created_at": _now_utc()},
            },
            upsert=True,
        )

    def get_prior_adherence_cache_query(self, cache_key: str) -> dict[str, Any] | None:
        doc = get_db().prior_adherence_cache.find_one({"cache_key": cache_key})
        return _row(doc)

    def upsert_prior_adherence_cache_query(
        self,
        cache_key: str,
        processed_context_hash: str,
        llm_output_hash: str,
        priors_hash: str,
        judge_model: str,
        judge_tier: str,
        reasoning_effort: str,
        prompt_version: str,
        prior_adherence: int | None,
        severity_weighted_prior_adherence: int | None,
        relevant_prior_count: int | None,
        followed_relevant_prior_count: int | None,
        violated_relevant_prior_count: int | None,
        total_non_adherence_severity: int | None,
        max_non_adherence_severity: int | None,
        prior_adherence_items_json: str,
    ) -> None:
        get_db().prior_adherence_cache.update_one(
            {"cache_key": cache_key},
            {
                "$set": {
                    "cache_key": cache_key,
                    "processed_context_hash": processed_context_hash,
                    "llm_output_hash": llm_output_hash,
                    "priors_hash": priors_hash,
                    "judge_model": judge_model,
                    "judge_tier": judge_tier,
                    "reasoning_effort": reasoning_effort,
                    "prompt_version": prompt_version,
                    "prior_adherence": prior_adherence,
                    "severity_weighted_prior_adherence": severity_weighted_prior_adherence,
                    "relevant_prior_count": relevant_prior_count,
                    "followed_relevant_prior_count": followed_relevant_prior_count,
                    "violated_relevant_prior_count": violated_relevant_prior_count,
                    "total_non_adherence_severity": total_non_adherence_severity,
                    "max_non_adherence_severity": max_non_adherence_severity,
                    "prior_adherence_items_json": prior_adherence_items_json,
                    "updated_at": _now_utc(),
                },
                "$setOnInsert": {"_id": cache_key, "created_at": _now_utc()},
            },
            upsert=True,
        )

    def get_priors_scope_query(
        self, user_id: str, project_id: str
    ) -> dict[str, Any] | None:
        doc = get_db().priors_scopes.find_one(
            {"user_id": user_id, "project_id": project_id}
        )
        return _row(doc)

    def ensure_priors_scope_query(
        self,
        user_id: str,
        project_id: str,
        revision: int,
        updated_at: str,
    ) -> dict[str, Any]:
        db = get_db()
        db.priors_scopes.update_one(
            {"user_id": user_id, "project_id": project_id},
            {
                "$setOnInsert": {
                    "user_id": user_id,
                    "project_id": project_id,
                    "revision": revision,
                    "updated_at": updated_at,
                }
            },
            upsert=True,
        )
        doc = db.priors_scopes.find_one(
            {"user_id": user_id, "project_id": project_id}
        )
        return _row(doc)

    def bump_priors_scope_revision_query(
        self, user_id: str, project_id: str, updated_at: str
    ) -> dict[str, Any]:
        db = get_db()
        # Upsert with revision=1 if not present, then atomically increment
        db.priors_scopes.update_one(
            {"user_id": user_id, "project_id": project_id},
            {
                "$setOnInsert": {
                    "user_id": user_id,
                    "project_id": project_id,
                    "revision": 0,
                    "updated_at": updated_at,
                }
            },
            upsert=True,
        )
        doc = db.priors_scopes.find_one_and_update(
            {"user_id": user_id, "project_id": project_id},
            {"$inc": {"revision": 1}, "$set": {"updated_at": updated_at}},
            return_document=True,  # pymongo.ReturnDocument.AFTER
        )
        return _row(doc)

    def get_prefix_cache_candidates_query(
        self,
        user_id: str,
        project_id: str,
        base_path: str,
        model: str,
        first_key: str,
        pair_count_limit: int,
    ) -> list[dict[str, Any]]:
        return _rows(
            get_db().prefix_cache.find(
                {
                    "user_id": user_id,
                    "project_id": project_id,
                    "base_path": base_path,
                    "model": model,
                    "first_key": first_key,
                    "pair_count": {"$lte": pair_count_limit},
                },
                sort=[("pair_count", -1)],
            )
        )

    def upsert_prefix_cache_query(
        self,
        user_id: str,
        project_id: str,
        base_path: str,
        model: str,
        first_key: str,
        pair_count: int,
        clean_pairs_json: str,
        injected_pairs_json: str,
        prior_ids_json: str,
    ) -> None:
        get_db().prefix_cache.update_one(
            {
                "user_id": user_id,
                "project_id": project_id,
                "base_path": base_path,
                "model": model,
                "clean_pairs_json": clean_pairs_json,
            },
            {
                "$set": {
                    "injected_pairs_json": injected_pairs_json,
                    "prior_ids_json": prior_ids_json,
                    "updated_at": _now_utc(),
                },
                "$setOnInsert": {
                    "user_id": user_id,
                    "project_id": project_id,
                    "base_path": base_path,
                    "model": model,
                    "first_key": first_key,
                    "pair_count": pair_count,
                    "clean_pairs_json": clean_pairs_json,
                    "created_at": _now_utc(),
                },
            },
            upsert=True,
        )

    def clear_scope_prefix_cache_query(
        self, user_id: str, project_id: str
    ) -> None:
        get_db().prefix_cache.delete_many(
            {"user_id": user_id, "project_id": project_id}
        )

    def clear_all_prefix_cache_query(self) -> None:
        get_db().prefix_cache.delete_many({})

    def get_cached_retrieval_query(
        self,
        user_id: str,
        project_id: str,
        priors_revision: int,
        base_path: str,
        model: str,
        context_hash: str,
        ignore_prior_ids_json: str,
    ) -> dict[str, Any] | None:
        doc = get_db().retrieval_cache.find_one(
            {
                "user_id": user_id,
                "project_id": project_id,
                "priors_revision": priors_revision,
                "base_path": base_path,
                "model": model,
                "context_hash": context_hash,
                "ignore_prior_ids_json": ignore_prior_ids_json,
            }
        )
        return _row(doc)

    def upsert_retrieval_cache_query(
        self,
        user_id: str,
        project_id: str,
        priors_revision: int,
        base_path: str,
        model: str,
        context_hash: str,
        ignore_prior_ids_json: str,
        response_json: str,
    ) -> None:
        get_db().retrieval_cache.update_one(
            {
                "user_id": user_id,
                "project_id": project_id,
                "priors_revision": priors_revision,
                "base_path": base_path,
                "model": model,
                "context_hash": context_hash,
                "ignore_prior_ids_json": ignore_prior_ids_json,
            },
            {
                "$set": {"response_json": response_json, "updated_at": _now_utc()},
                "$setOnInsert": {
                    "user_id": user_id,
                    "project_id": project_id,
                    "priors_revision": priors_revision,
                    "base_path": base_path,
                    "model": model,
                    "context_hash": context_hash,
                    "ignore_prior_ids_json": ignore_prior_ids_json,
                    "created_at": _now_utc(),
                },
            },
            upsert=True,
        )

    def clear_all_retrieval_cache_query(self) -> None:
        get_db().retrieval_cache.delete_many({})

    def get_priors_applied_for_run_query(
        self, run_id: str
    ) -> list[dict[str, Any]]:
        db = get_db()
        docs = list(
            db.priors_applied.find(
                {"run_id": run_id}, sort=[("applied_at", -1)]
            )
        )
        run_names: dict[str, str | None] = {}
        for doc in docs:
            rid = doc["run_id"]
            if rid not in run_names:
                r = db.runs.find_one({"_id": rid}, {"name": 1})
                run_names[rid] = r.get("name") if r else None
        return [
            {
                "prior_id": d["prior_id"],
                "run_id": d["run_id"],
                "node_uuid": d.get("node_uuid"),
                "name": run_names.get(d["run_id"]),
            }
            for d in docs
        ]

    def get_priors_applied_query(self, prior_id: str) -> list[dict[str, Any]]:
        db = get_db()
        docs = list(
            db.priors_applied.find(
                {"prior_id": prior_id}, sort=[("applied_at", -1)]
            )
        )
        run_names: dict[str, str | None] = {}
        for doc in docs:
            rid = doc["run_id"]
            if rid not in run_names:
                r = db.runs.find_one({"_id": rid}, {"name": 1})
                run_names[rid] = r.get("name") if r else None
        return [
            {
                "run_id": d["run_id"],
                "node_uuid": d.get("node_uuid"),
                "name": run_names.get(d["run_id"]),
            }
            for d in docs
        ]

    def add_prior_applied_query(
        self, prior_id: str, run_id: str, node_uuid: str | None = None
    ) -> None:
        get_db().priors_applied.update_one(
            {"prior_id": prior_id, "run_id": run_id, "node_uuid": node_uuid},
            {
                "$setOnInsert": {
                    "prior_id": prior_id,
                    "run_id": run_id,
                    "node_uuid": node_uuid,
                    "applied_at": _now_utc(),
                }
            },
            upsert=True,
        )

    def remove_prior_applied_query(
        self, prior_id: str, run_id: str, node_uuid: str | None = None
    ) -> None:
        if node_uuid:
            get_db().priors_applied.delete_one(
                {"prior_id": prior_id, "run_id": run_id, "node_uuid": node_uuid}
            )
        else:
            get_db().priors_applied.delete_one(
                {"prior_id": prior_id, "run_id": run_id, "node_uuid": None}
            )

    def delete_priors_applied_for_prior_query(self, prior_id: str) -> None:
        get_db().priors_applied.delete_many({"prior_id": prior_id})

    # ──────────────────────────────────────────────────────────────────────────
    # Internal helpers
    # ──────────────────────────────────────────────────────────────────────────

    @staticmethod
    def _tag_row(doc: dict | None) -> dict | None:
        if doc is None:
            return None
        return {
            "tag_id": doc.get("_id") or doc.get("tag_id"),
            "project_id": doc.get("project_id"),
            "name": doc.get("name"),
            "color": doc.get("color"),
            "created_at": doc.get("created_at"),
        }


# _re_escape was replaced by the stdlib re.escape() which is correct for PCRE patterns.

# Verify the class satisfies the protocol at import time (development safety check).
from sovara.server.database.backend_protocol import DatabaseBackend  # noqa: E402
assert isinstance(MongoBackend(), DatabaseBackend), (
    "MongoBackend does not satisfy DatabaseBackend protocol"
)
