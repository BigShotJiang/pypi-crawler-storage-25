"""PostgreSQLBackend – stub implementation of the DatabaseBackend protocol.

All methods raise ``NotImplementedError``.  Implement them incrementally,
following the same patterns as ``SQLiteBackend`` and ``MongoBackend``.

To activate: set ``SOVARA_DB_BACKEND=postgresql`` and ``SOVARA_PG_DSN``
(see ``sovara.common.constants``).
"""

from __future__ import annotations

from typing import Any


class PostgreSQLBackend:
    """PostgreSQL implementation of the DatabaseBackend protocol (stub)."""

    # ──────────────────────────────────────────────────────────────────────────
    # Users
    # ──────────────────────────────────────────────────────────────────────────

    def upsert_user_query(self, user_id: str, full_name: str, email: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.upsert_user_query")

    def get_user_query(self, user_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_user_query")

    def update_user_llm_settings_query(
        self, user_id: str, llm_settings: dict[str, Any]
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_user_llm_settings_query")

    def delete_user_query(self, user_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.delete_user_query")

    # ──────────────────────────────────────────────────────────────────────────
    # Projects
    # ──────────────────────────────────────────────────────────────────────────

    def upsert_project_query(
        self,
        project_id: str,
        name: str,
        description: str | None,
        priors_latency_tier: str | None = None,
        priors_track_groundedness: bool | None = None,
        priors_track_adherence: bool | None = None,
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.upsert_project_query")

    def get_project_query(self, project_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_project_query")

    def get_all_projects_query(
        self, user_id: str | None = None
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_all_projects_query")

    def update_project_last_run_at_query(self, project_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_project_last_run_at_query")

    def get_project_user_count_query(self, project_id: str) -> int:
        raise NotImplementedError("PostgreSQLBackend.get_project_user_count_query")

    def get_project_tag_count_query(self, project_id: str) -> int:
        raise NotImplementedError("PostgreSQLBackend.get_project_tag_count_query")

    def get_run_tag_count_query(self, run_id: str) -> int:
        raise NotImplementedError("PostgreSQLBackend.get_run_tag_count_query")

    def delete_project_query(self, project_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.delete_project_query")

    # Project locations

    def upsert_project_location_query(
        self, user_id: str, project_id: str, project_location: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.upsert_project_location_query")

    def get_project_at_location_query(
        self, user_id: str, project_location: str
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_project_at_location_query")

    def get_user_project_locations_query(self, user_id: str) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_user_project_locations_query")

    def get_project_locations_query(
        self, user_id: str, project_id: str
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_project_locations_query")

    def get_all_project_locations_query(
        self, project_id: str
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_all_project_locations_query")

    def delete_project_location_query(
        self, user_id: str, project_id: str, project_location: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.delete_project_location_query")

    # Tags

    def get_project_tags_query(self, project_id: str) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_project_tags_query")

    def get_project_tag_query(self, tag_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_project_tag_query")

    def get_project_tag_by_name_query(
        self, project_id: str, name: str
    ) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_project_tag_by_name_query")

    def get_project_tags_by_ids_query(
        self, project_id: str, tag_ids: list[str]
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_project_tags_by_ids_query")

    def insert_project_tag_query(
        self, tag_id: str, project_id: str, name: str, color: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.insert_project_tag_query")

    def delete_project_tag_query(self, project_id: str, tag_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.delete_project_tag_query")

    def get_tags_for_runs_query(self, run_ids: list[str]) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_tags_for_runs_query")

    def replace_run_tags_query(self, run_id: str, tag_ids: list[str]) -> None:
        raise NotImplementedError("PostgreSQLBackend.replace_run_tags_query")

    # Metric kinds

    def get_project_metric_kinds_query(
        self, project_id: str
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_project_metric_kinds_query")

    def get_project_custom_metric_columns_query(
        self, project_id: str
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_project_custom_metric_columns_query")

    def upsert_project_metric_kind_query(
        self, project_id: str, metric_key: str, metric_kind: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.upsert_project_metric_kind_query")

    # ──────────────────────────────────────────────────────────────────────────
    # Runs
    # ──────────────────────────────────────────────────────────────────────────

    def add_run_query(
        self,
        run_id: str,
        parent_run_id: str,
        name: str | None,
        default_graph: str,
        timestamp: str | None,
        cwd: str | None,
        command: str | None,
        env_json: str,
        default_note: str,
        default_log: str,
        version_date: str | None,
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.add_run_query")

    def update_run_graph_topology_query(self, graph_json: str, run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_run_graph_topology_query")

    def get_run_active_edit_query(self, run_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_run_active_edit_query")

    def set_run_active_edit_query(
        self, node_uuid: str, node_label: str, field: str, status: str, run_id: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.set_run_active_edit_query")

    def update_run_active_edit_status_query(self, status: str, run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_run_active_edit_status_query")

    def clear_run_active_edit_query(self, run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.clear_run_active_edit_query")

    def update_run_timestamp_query(self, timestamp: str, run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_run_timestamp_query")

    def update_run_runtime_seconds_query(
        self, runtime_seconds: float | None, run_id: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_run_runtime_seconds_query")

    def update_run_active_runtime_seconds_query(
        self, active_runtime_seconds: float | None, run_id: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_run_active_runtime_seconds_query")

    def finalize_run_runtime_query(self, runtime_seconds: float, run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.finalize_run_runtime_query")

    def clear_run_active_runtime_seconds_query(self, run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.clear_run_active_runtime_seconds_query")

    def update_run_name_query(self, name: str, run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_run_name_query")

    def update_run_notes_query(self, notes: str, run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_run_notes_query")

    def set_run_log_query(self, log_text: str, run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.set_run_log_query")

    def append_run_log_query(self, log_chunk: str, run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.append_run_log_query")

    def get_run_log_query(self, run_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_run_log_query")

    def get_run_trace_chat_history_query(self, run_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_run_trace_chat_history_query")

    def get_run_scope_query(self, run_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_run_scope_query")

    def update_run_trace_chat_history_query(
        self, trace_chat_history: str, run_id: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_run_trace_chat_history_query")

    def update_run_command_query(self, command: str, run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_run_command_query")

    def update_run_version_date_query(
        self, version_date: str | None, run_id: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_run_version_date_query")

    def update_run_log_query(
        self, updated_log: str, graph_json: str, run_id: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_run_log_query")

    def update_run_custom_metrics_query(
        self, custom_metrics_json: str, run_id: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_run_custom_metrics_query")

    def persist_run_metrics_query(
        self,
        run_id: str,
        custom_metrics_json: str,
        metric_rows: list[tuple],
        project_metric_kind_rows: tuple | list = (),
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.persist_run_metrics_query")

    def update_run_thumb_label_query(
        self, thumb_label: int | None, run_id: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_run_thumb_label_query")

    def get_run_metrics_context_query(self, run_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_run_metrics_context_query")

    def get_run_tag_context_query(self, run_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_run_tag_context_query")

    def get_runs_timeseries_query(
        self,
        project_id: str,
        time_from: str,
        time_to: str,
        bucket_seconds: int,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_runs_timeseries_query")

    def get_duration_timeseries_query(
        self,
        project_id: str,
        time_from: str,
        time_to: str,
        bucket_seconds: int,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_duration_timeseries_query")

    def get_finished_runs_query(
        self, project_id: str | None = None, user_id: str | None = None
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_finished_runs_query")

    def get_all_runs_sorted_query(
        self,
        limit: int | None = None,
        offset: int = 0,
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_all_runs_sorted_query")

    def get_runs_by_ids_query(
        self,
        run_ids: list[str],
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_runs_by_ids_query")

    def get_runs_excluding_ids_query(
        self,
        run_ids: list[str],
        limit: int | None = None,
        offset: int = 0,
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_runs_excluding_ids_query")

    def get_run_count_query(
        self, project_id: str | None = None, user_id: str | None = None
    ) -> int:
        raise NotImplementedError("PostgreSQLBackend.get_run_count_query")

    def get_run_count_excluding_ids_query(
        self,
        run_ids: list[str],
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> int:
        raise NotImplementedError("PostgreSQLBackend.get_run_count_excluding_ids_query")

    def query_runs_filtered(
        self,
        project_id: str,
        exclude_ids: list[str],
        filters: dict[str, Any],
        sort_col: str,
        sort_dir: str,
        limit: int,
        offset: int,
        user_id: str | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        raise NotImplementedError("PostgreSQLBackend.query_runs_filtered")

    def get_distinct_versions_query(
        self, project_id: str | None = None, user_id: str | None = None
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_distinct_versions_query")

    def get_run_detail_query(self, run_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_run_detail_query")

    def get_run_graph_topology_query(self, run_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_run_graph_topology_query")

    def get_run_environment_query(
        self, parent_run_id: str
    ) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_run_environment_query")

    def get_run_exec_info_query(self, run_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_run_exec_info_query")

    def delete_all_runs_query(self) -> None:
        raise NotImplementedError("PostgreSQLBackend.delete_all_runs_query")

    def delete_runs_by_ids_query(
        self, run_ids: list[str], user_id: str | None = None
    ) -> Any:
        raise NotImplementedError("PostgreSQLBackend.delete_runs_by_ids_query")

    def get_run_name_query(self, run_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_run_name_query")

    def find_run_ids_by_prefix_query(
        self, run_id_prefix: str
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.find_run_ids_by_prefix_query")

    def get_run_log_success_graph_query(
        self, run_id: str
    ) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_run_log_success_graph_query")

    def get_next_run_index_query(
        self, project_id: str | None = None, user_id: str | None = None
    ) -> int:
        raise NotImplementedError("PostgreSQLBackend.get_next_run_index_query")

    def get_run_metadata_query(self, run_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_run_metadata_query")

    # ──────────────────────────────────────────────────────────────────────────
    # LLM calls
    # ──────────────────────────────────────────────────────────────────────────

    def set_input_overwrite_query(
        self, input_overwrite: str, run_id: str, node_uuid: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.set_input_overwrite_query")

    def set_output_overwrite_query(
        self, output_overwrite: str, run_id: str, node_uuid: str
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.set_output_overwrite_query")

    def clear_input_overwrite_query(self, run_id: str, node_uuid: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.clear_input_overwrite_query")

    def clear_output_overwrite_query(self, run_id: str, node_uuid: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.clear_output_overwrite_query")

    def delete_llm_calls_query(self, run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.delete_llm_calls_query")

    def delete_all_llm_calls_query(self) -> None:
        raise NotImplementedError("PostgreSQLBackend.delete_all_llm_calls_query")

    def get_subrun_by_parent_and_name_query(
        self, parent_run_id: str, name: str
    ) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_subrun_by_parent_and_name_query")

    def get_parent_run_id_query(self, run_id: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_parent_run_id_query")

    def get_llm_call_by_run_and_hash_query(
        self, run_id: str, input_hash: str, offset: int = 0
    ) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_llm_call_by_run_and_hash_query")

    def insert_llm_call_with_output_query(
        self,
        run_id: str,
        input_pickle: str,
        input_hash: str,
        node_uuid: str,
        api_type: str,
        output_pickle: str,
        stack_trace: str | None = None,
        node_kind: str | None = None,
        prompt_suffix_json: str = "[]",
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.insert_llm_call_with_output_query")

    def copy_llm_calls_query(self, old_run_id: str, new_run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.copy_llm_calls_query")

    def find_node_uuids_by_prefix_query(
        self, run_id: str, node_uuid_prefix: str
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.find_node_uuids_by_prefix_query")

    def get_llm_call_input_api_type_query(
        self, run_id: str, node_uuid: str
    ) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_llm_call_input_api_type_query")

    def get_llm_call_output_api_type_query(
        self, run_id: str, node_uuid: str
    ) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_llm_call_output_api_type_query")

    def get_llm_calls_for_run_query(self, run_id: str) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_llm_calls_for_run_query")

    def get_llm_call_full_query(
        self, run_id: str, node_uuid: str
    ) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_llm_call_full_query")

    def begin_llm_call_query(
        self,
        run_id: str,
        input_pickle: str,
        input_hash: str,
        node_uuid: str,
        api_type: str,
        stack_trace: str | None = None,
        node_kind: str | None = None,
        prompt_suffix_json: str = "[]",
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.begin_llm_call_query")

    def mark_llm_call_in_flight_query(self, run_id: str, node_uuid: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.mark_llm_call_in_flight_query")

    def finalize_llm_call_query(
        self,
        run_id: str,
        node_uuid: str,
        *,
        input_pickle: str | None = None,
        input_hash: str | None = None,
        output_json: str | None = None,
        status: str,
        latency_seconds: float | None = None,
        error_json: str | None = None,
        stack_trace: str | None = None,
        node_kind: str | None = None,
        prompt_suffix_json: str | None = None,
        consume_edit_field: str | None = None,
        clear_output: bool = False,
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.finalize_llm_call_query")

    def set_llm_verdict_query(
        self, run_id: str, node_uuid: str, llm_verdict: str | None
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.set_llm_verdict_query")

    def get_tokens_timeseries_query(
        self,
        project_id: str,
        time_from: str,
        time_to: str,
        bucket_seconds: int,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_tokens_timeseries_query")

    # ──────────────────────────────────────────────────────────────────────────
    # Priors
    # ──────────────────────────────────────────────────────────────────────────

    def copy_prior_retrievals_query(self, old_run_id: str, new_run_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.copy_prior_retrievals_query")

    def get_prior_retrieval_by_id_query(
        self, retrieval_id: str
    ) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_prior_retrieval_by_id_query")

    def delete_prior_retrieval_by_id_query(self, retrieval_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.delete_prior_retrieval_by_id_query")

    def get_prior_retrieval_query(
        self, run_id: str, node_uuid: str
    ) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_prior_retrieval_query")

    def get_prior_retrievals_for_run_query(
        self, run_id: str
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_prior_retrievals_for_run_query")

    def upsert_prior_retrieval_query(
        self,
        retrieval_id: str,
        run_id: str,
        node_uuid: str | None,
        raw_context: str,
        processed_context: str,
        inherited_prior_ids_json: str,
        retrieved_priors_json: str,
        applied_priors_json: str,
        rendered_priors_block: str,
        injection_anchor_json: str | None,
        model: str | None,
        latency_tier: str,
        timeout_ms: int | None,
        retrieval_latency_ms: int | None,
        prior_coverage: int | None,
        retrieval_status: str,
        coverage_status: str,
        warning_message: str | None,
        error_message: str | None,
        groundedness_total_importance: int | None,
        groundedness_grounded_importance: int | None,
        groundedness_guidance_points_json: str,
        adherence_status: str,
        prior_adherence: int | None,
        severity_weighted_prior_adherence: int | None,
        relevant_prior_count: int | None,
        followed_relevant_prior_count: int | None,
        violated_relevant_prior_count: int | None,
        total_non_adherence_severity: int | None,
        max_non_adherence_severity: int | None,
        prior_adherence_items_json: str,
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.upsert_prior_retrieval_query")

    def update_prior_coverage_query(
        self,
        retrieval_id: str,
        prior_coverage: int | None,
        coverage_status: str,
        groundedness_total_importance: int | None,
        groundedness_grounded_importance: int | None,
        groundedness_guidance_points_json: str,
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_prior_coverage_query")

    def update_prior_adherence_query(
        self,
        retrieval_id: str,
        adherence_status: str,
        prior_adherence: int | None,
        severity_weighted_prior_adherence: int | None,
        relevant_prior_count: int | None,
        followed_relevant_prior_count: int | None,
        violated_relevant_prior_count: int | None,
        total_non_adherence_severity: int | None,
        max_non_adherence_severity: int | None,
        prior_adherence_items_json: str,
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.update_prior_adherence_query")

    def get_pending_prior_coverage_jobs_query(self, limit: int) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_pending_prior_coverage_jobs_query")

    def get_prior_coverage_cache_query(self, cache_key: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_prior_coverage_cache_query")

    def upsert_prior_coverage_cache_query(
        self,
        cache_key: str,
        processed_context_hash: str,
        llm_output_hash: str,
        priors_hash: str,
        judge_model: str,
        judge_tier: str,
        reasoning_effort: str,
        prompt_version: str,
        prior_coverage: int,
        total_importance: int | None,
        grounded_importance: int | None,
        guidance_points_json: str,
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.upsert_prior_coverage_cache_query")

    def get_prior_adherence_cache_query(self, cache_key: str) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_prior_adherence_cache_query")

    def upsert_prior_adherence_cache_query(
        self,
        cache_key: str,
        processed_context_hash: str,
        llm_output_hash: str,
        priors_hash: str,
        judge_model: str,
        judge_tier: str,
        reasoning_effort: str,
        prompt_version: str,
        prior_adherence: int | None,
        severity_weighted_prior_adherence: int | None,
        relevant_prior_count: int | None,
        followed_relevant_prior_count: int | None,
        violated_relevant_prior_count: int | None,
        total_non_adherence_severity: int | None,
        max_non_adherence_severity: int | None,
        prior_adherence_items_json: str,
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.upsert_prior_adherence_cache_query")

    def get_priors_scope_query(
        self, user_id: str, project_id: str
    ) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_priors_scope_query")

    def ensure_priors_scope_query(
        self,
        user_id: str,
        project_id: str,
        revision: int,
        updated_at: str,
    ) -> dict[str, Any]:
        raise NotImplementedError("PostgreSQLBackend.ensure_priors_scope_query")

    def bump_priors_scope_revision_query(
        self, user_id: str, project_id: str, updated_at: str
    ) -> dict[str, Any]:
        raise NotImplementedError("PostgreSQLBackend.bump_priors_scope_revision_query")

    def get_prefix_cache_candidates_query(
        self,
        user_id: str,
        project_id: str,
        base_path: str,
        model: str,
        first_key: str,
        pair_count_limit: int,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_prefix_cache_candidates_query")

    def upsert_prefix_cache_query(
        self,
        user_id: str,
        project_id: str,
        base_path: str,
        model: str,
        first_key: str,
        pair_count: int,
        clean_pairs_json: str,
        injected_pairs_json: str,
        prior_ids_json: str,
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.upsert_prefix_cache_query")

    def clear_scope_prefix_cache_query(self, user_id: str, project_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.clear_scope_prefix_cache_query")

    def clear_all_prefix_cache_query(self) -> None:
        raise NotImplementedError("PostgreSQLBackend.clear_all_prefix_cache_query")

    def get_cached_retrieval_query(
        self,
        user_id: str,
        project_id: str,
        priors_revision: int,
        base_path: str,
        model: str,
        context_hash: str,
        ignore_prior_ids_json: str,
    ) -> dict[str, Any] | None:
        raise NotImplementedError("PostgreSQLBackend.get_cached_retrieval_query")

    def upsert_retrieval_cache_query(
        self,
        user_id: str,
        project_id: str,
        priors_revision: int,
        base_path: str,
        model: str,
        context_hash: str,
        ignore_prior_ids_json: str,
        response_json: str,
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.upsert_retrieval_cache_query")

    def clear_all_retrieval_cache_query(self) -> None:
        raise NotImplementedError("PostgreSQLBackend.clear_all_retrieval_cache_query")

    def get_priors_applied_for_run_query(
        self, run_id: str
    ) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_priors_applied_for_run_query")

    def get_priors_applied_query(self, prior_id: str) -> list[dict[str, Any]]:
        raise NotImplementedError("PostgreSQLBackend.get_priors_applied_query")

    def add_prior_applied_query(
        self, prior_id: str, run_id: str, node_uuid: str | None = None
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.add_prior_applied_query")

    def remove_prior_applied_query(
        self, prior_id: str, run_id: str, node_uuid: str | None = None
    ) -> None:
        raise NotImplementedError("PostgreSQLBackend.remove_prior_applied_query")

    def delete_priors_applied_for_prior_query(self, prior_id: str) -> None:
        raise NotImplementedError("PostgreSQLBackend.delete_priors_applied_for_prior_query")


# Verify the class satisfies the protocol at import time (development safety check).
from sovara.server.database.backend_protocol import DatabaseBackend  # noqa: E402
assert isinstance(PostgreSQLBackend(), DatabaseBackend), (
    "PostgreSQLBackend does not satisfy DatabaseBackend protocol"
)
