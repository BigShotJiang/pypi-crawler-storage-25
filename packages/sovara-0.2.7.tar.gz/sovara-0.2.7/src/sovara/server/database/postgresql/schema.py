"""PostgreSQL DDL – placeholder schema for the PostgreSQL backend.

Run ``init_db()`` once (e.g. from server startup) to create all tables.
Tables mirror the SQLite schema defined in ``sqlite/schema.py``.
"""

from __future__ import annotations

from sovara.server.database.postgresql.connection import get_conn

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
    user_id             TEXT PRIMARY KEY,
    full_name           TEXT,
    email               TEXT,
    created_at          TEXT,
    primary_provider    TEXT,
    primary_model       TEXT,
    primary_api_key     TEXT,
    helper_provider     TEXT,
    helper_model        TEXT,
    helper_api_key      TEXT
);

CREATE TABLE IF NOT EXISTS projects (
    project_id   TEXT PRIMARY KEY,
    name         TEXT NOT NULL,
    description  TEXT,
    created_at   TEXT,
    last_run_at  TEXT
);

CREATE TABLE IF NOT EXISTS project_metric_kinds (
    project_id  TEXT NOT NULL,
    metric_key  TEXT NOT NULL,
    metric_type TEXT,
    PRIMARY KEY (project_id, metric_key)
);

CREATE TABLE IF NOT EXISTS project_tags (
    tag_id      TEXT PRIMARY KEY,
    project_id  TEXT NOT NULL,
    name        TEXT NOT NULL,
    color       TEXT,
    created_at  TEXT
);

CREATE TABLE IF NOT EXISTS runs (
    run_id                   TEXT PRIMARY KEY,
    run_id_clean             TEXT,
    parent_run_id            TEXT,
    project_id               TEXT,
    user_id                  TEXT,
    name                     TEXT,
    graph_topology           TEXT,
    timestamp                TEXT,
    runtime_seconds          REAL,
    active_runtime_seconds   REAL,
    cwd                      TEXT,
    command                  TEXT,
    environment              TEXT,
    version_date             TEXT,
    custom_metrics           TEXT,
    thumb_label              TEXT,
    notes                    TEXT,
    log                      TEXT,
    trace_chat_history       TEXT,
    active_edit_node_uuid    TEXT,
    active_edit_node_label   TEXT,
    active_edit_field        TEXT,
    active_edit_status       TEXT
);

CREATE INDEX IF NOT EXISTS idx_runs_project_timestamp ON runs (project_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_runs_user          ON runs (user_id);
CREATE INDEX IF NOT EXISTS idx_runs_run_id_clean  ON runs (run_id_clean);

CREATE TABLE IF NOT EXISTS run_tags (
    run_id  TEXT NOT NULL,
    tag_id  TEXT NOT NULL,
    PRIMARY KEY (run_id, tag_id)
);

CREATE TABLE IF NOT EXISTS run_metric_values (
    run_id      TEXT NOT NULL,
    metric_key  TEXT NOT NULL,
    bool_value  BOOLEAN,
    int_value   BIGINT,
    float_value DOUBLE PRECISION,
    PRIMARY KEY (run_id, metric_key)
);

CREATE TABLE IF NOT EXISTS llm_calls (
    run_id        TEXT NOT NULL,
    node_uuid     TEXT NOT NULL,
    input_json    TEXT,
    output_json   TEXT,
    input_hash    TEXT,
    status        TEXT,
    input_tokens  INTEGER,
    output_tokens INTEGER,
    started_at    REAL,
    latency_seconds REAL,
    PRIMARY KEY (run_id, node_uuid)
);

CREATE INDEX IF NOT EXISTS idx_llm_calls_input_hash ON llm_calls (run_id, input_hash);

CREATE TABLE IF NOT EXISTS user_project_locations (
    user_id          TEXT NOT NULL,
    project_id       TEXT NOT NULL,
    project_location TEXT NOT NULL,
    UNIQUE (user_id, project_location)
);

CREATE TABLE IF NOT EXISTS prior_retrievals (
    id          SERIAL PRIMARY KEY,
    run_id      TEXT NOT NULL,
    node_uuid   TEXT NOT NULL,
    prior_id    TEXT,
    UNIQUE (run_id, node_uuid)
);

CREATE TABLE IF NOT EXISTS priors_applied (
    id         SERIAL PRIMARY KEY,
    prior_id   TEXT,
    run_id     TEXT,
    node_uuid  TEXT,
    UNIQUE (prior_id, run_id, node_uuid)
);

CREATE TABLE IF NOT EXISTS prefix_cache (
    user_id           TEXT NOT NULL,
    project_id        TEXT NOT NULL,
    base_path         TEXT NOT NULL,
    model             TEXT NOT NULL,
    clean_pairs_json  TEXT NOT NULL,
    result_json       TEXT,
    UNIQUE (user_id, project_id, base_path, model, clean_pairs_json)
);

CREATE TABLE IF NOT EXISTS retrieval_cache (
    user_id                TEXT NOT NULL,
    project_id             TEXT NOT NULL,
    priors_revision        TEXT NOT NULL,
    base_path              TEXT NOT NULL,
    model                  TEXT NOT NULL,
    context_hash           TEXT NOT NULL,
    ignore_prior_ids_json  TEXT NOT NULL,
    result_json            TEXT,
    UNIQUE (user_id, project_id, priors_revision, base_path, model, context_hash, ignore_prior_ids_json)
);
"""


def init_db() -> None:
    """Create all tables and indexes (idempotent)."""
    conn = get_conn()
    with conn.cursor() as cur:
        cur.execute(_SCHEMA_SQL)
    conn.commit()
