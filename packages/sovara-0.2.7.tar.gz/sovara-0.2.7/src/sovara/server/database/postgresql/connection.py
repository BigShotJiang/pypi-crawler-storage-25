"""PostgreSQL connection management.

Uses ``psycopg2`` (``psycopg2-binary`` is already a project dependency).
A single connection is created per process on first use; it is not a pool
(add pgbouncer or switch to asyncpg + a pool if concurrency is required).
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import psycopg2

_conn_lock = threading.Lock()
_conn = None


def _get_psycopg2():
    try:
        import psycopg2  # noqa: F401
        import psycopg2.extras  # noqa: F401
        return psycopg2
    except ImportError as exc:
        raise ImportError(
            "psycopg2 is required for the PostgreSQL backend.  "
            "Install it with: pip install psycopg2-binary"
        ) from exc


def get_conn():
    """Return a shared ``psycopg2`` connection (thread-safe, lazy init)."""
    global _conn

    if _conn is not None and not _conn.closed:
        return _conn

    with _conn_lock:
        if _conn is not None and not _conn.closed:
            return _conn

        psycopg2 = _get_psycopg2()
        from sovara.common.config import get_db_config
        db_cfg = get_db_config()

        _conn = psycopg2.connect(db_cfg["pg_dsn"])
        # Return dicts instead of tuples so callers can use column names.
        _conn.cursor_factory = psycopg2.extras.RealDictCursor
        return _conn


def close_conn() -> None:
    """Close the shared connection (e.g. during server shutdown)."""
    global _conn
    with _conn_lock:
        if _conn is not None and not _conn.closed:
            _conn.close()
        _conn = None


def reset_connection() -> None:
    """Alias for close_conn() used by the runtime backend-switch flow."""
    close_conn()
