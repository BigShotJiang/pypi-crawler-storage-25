from collections.abc import Callable
import json
import random
import time
import uuid
from typing import Any

from sovara.common.constants import MAIN_SERVER_LOG
from sovara.common.logger import create_file_logger
from sovara.server.database.blob_storage import externalize, restore
from sovara.runner.monkey_patching.api_parser import (
    api_obj_to_json_str,
    func_kwargs_to_json_str,
    json_str_to_api_obj,
    json_str_to_original_inp_dict,
    merge_filtered_into_raw,
)

from ._shared import BadRequestError, CacheOutput, ResourceNotFoundError


logger = create_file_logger(MAIN_SERVER_LOG, logger_name="sovara.server.database.llm_calls")


class LlmCallsMixin:
    _VALID_LLM_VERDICTS = {"correct", "incorrect", "uncertain"}

    _RUNTIME_PRIORS_API_TYPES = {
        "httpx.Client.send",
        "httpx.AsyncClient.send",
        "aiohttp.ClientSession._request",
        "requests.Session.send",
        "urllib3.HTTPConnectionPool.urlopen",
        "claude_code.messages",
    }

    def _next_occurrence(self, run_id: str, input_hash: str) -> int:
        """Return and increment the lookup count for (run_id, input_hash)."""
        with self._occurrence_lock:
            key = (run_id, input_hash)
            occurrence = self._occurrence_counters[key]
            self._occurrence_counters[key] += 1
            return occurrence

    def next_cache_occurrence(self, run_id: str, input_hash: str) -> int:
        return self._next_occurrence(run_id, input_hash)

    def reset_occurrence_counters(self, run_id: str | None = None) -> None:
        with self._occurrence_lock:
            if run_id is None:
                self._occurrence_counters.clear()
                return

            keys_to_delete = [key for key in self._occurrence_counters if key[0] == run_id]
            for key in keys_to_delete:
                del self._occurrence_counters[key]

    @staticmethod
    def _serialize_node_error(error_payload: dict[str, Any] | None) -> str | None:
        if error_payload is None:
            return None
        return json.dumps(error_payload, sort_keys=True)

    @staticmethod
    def _status_and_error_for_output(output_obj: Any, api_type: str) -> tuple[str, str | None]:
        from sovara.runner.node_execution import extract_node_error

        error_payload = extract_node_error(output_obj, api_type)
        return (
            ("error", LlmCallsMixin._serialize_node_error(error_payload))
            if error_payload
            else ("success", None)
        )

    @staticmethod
    def _exception_error_json(exc: Exception, api_type: str) -> str:
        from sovara.runner.node_execution import exception_to_node_error

        return json.dumps(exception_to_node_error(exc, api_type), sort_keys=True)

    def _should_prepare_runtime_priors(
        self,
        *,
        prepare_runtime_priors: bool,
        node_kind: str | None,
        api_type: str,
    ) -> bool:
        return (
            prepare_runtime_priors
            and node_kind == "llm"
            and api_type in self._RUNTIME_PRIORS_API_TYPES
        )

    def set_input_overwrite(self, run_id, node_uuid, new_input, node_label: str | None = None):
        """UI sends to_show data; merge into original raw to build full format for the runner."""
        try:
            new_to_show = json.loads(new_input)
        except json.JSONDecodeError as exc:
            raise BadRequestError(
                f"Invalid input JSON for run_id={run_id}, node_uuid={node_uuid}: {exc.msg}."
            ) from exc

        row = self.backend.get_llm_call_input_api_type_query(run_id, node_uuid)
        if not row:
            raise ResourceNotFoundError(
                f"Input node not found for run_id={run_id}, node_uuid={node_uuid}."
            )

        try:
            original = json.loads(row["input"])
        except (TypeError, json.JSONDecodeError) as exc:
            raise BadRequestError(
                f"Stored input payload is invalid for run_id={run_id}, node_uuid={node_uuid}."
            ) from exc

        if not isinstance(original, dict) or "raw" not in original or "to_show" not in original:
            raise BadRequestError(
                f"Stored input payload is incomplete for run_id={run_id}, node_uuid={node_uuid}."
            )

        if json.dumps(new_to_show, sort_keys=True) == json.dumps(
            original["to_show"], sort_keys=True
        ):
            return None

        merged_raw = merge_filtered_into_raw(original["raw"], new_to_show)
        overwrite = json.dumps({"raw": merged_raw, "to_show": new_to_show})
        self.upsert_active_edit(run_id, node_uuid, node_label or node_uuid, "input")
        self.backend.set_input_overwrite_query(overwrite, run_id, node_uuid)
        return overwrite

    def set_output_overwrite(
        self, run_id, node_uuid, new_output: str, node_label: str | None = None
    ):
        """UI sends to_show data; merge into original raw to build full format for the runner."""
        try:
            new_to_show = json.loads(new_output)
        except json.JSONDecodeError as exc:
            raise BadRequestError(
                f"Invalid output JSON for run_id={run_id}, node_uuid={node_uuid}: {exc.msg}."
            ) from exc

        row = self.backend.get_llm_call_output_api_type_query(run_id, node_uuid)
        if not row:
            raise ResourceNotFoundError(
                f"Output node not found for run_id={run_id}, node_uuid={node_uuid}."
            )
        if row["output"] is None:
            raise BadRequestError(
                f"No stored output is available for run_id={run_id}, node_uuid={node_uuid}."
            )

        try:
            original = json.loads(row["output"])
        except (TypeError, json.JSONDecodeError) as exc:
            raise BadRequestError(
                f"Stored output payload is invalid for run_id={run_id}, node_uuid={node_uuid}."
            ) from exc

        if not isinstance(original, dict) or "raw" not in original or "to_show" not in original:
            raise BadRequestError(
                f"Stored output payload is incomplete for run_id={run_id}, node_uuid={node_uuid}."
            )

        try:
            merged_raw = merge_filtered_into_raw(original["raw"], new_to_show)
            overwrite = json.dumps({"raw": merged_raw, "to_show": new_to_show})

            json_str_to_api_obj(overwrite, row["api_type"])
            self.upsert_active_edit(run_id, node_uuid, node_label or node_uuid, "output")
            self.backend.set_output_overwrite_query(overwrite, run_id, node_uuid)
            return overwrite
        except Exception as e:
            raise BadRequestError(
                f"Invalid output edit for run_id={run_id}, node_uuid={node_uuid}: {e}"
            ) from e

    def discard_active_edit(self, run_id):
        active_edit = self.get_active_edit(run_id)
        if active_edit is None:
            return None
        if active_edit["field"] == "input":
            self.backend.clear_input_overwrite_query(run_id, active_edit["node_uuid"])
        else:
            self.backend.clear_output_overwrite_query(run_id, active_edit["node_uuid"])
        self.clear_active_edit(run_id)
        return active_edit

    def get_subrun_id(self, parent_run_id, name):
        result = self.backend.get_subrun_by_parent_and_name_query(parent_run_id, name)
        if result is None:
            return None
        return result["run_id"]

    def get_parent_run_id(self, run_id):
        """
        Get parent run ID with retry logic to handle race conditions.

        Since runs can be inserted and immediately restarted, there can be a race
        condition where the restart handler tries to read parent_run_id before the
        insert transaction is committed. This method retries a few times with short delays.
        """
        max_retries = 3
        retry_delay = 0.05

        for attempt in range(max_retries):
            result = self.backend.get_parent_run_id_query(run_id)
            if result is not None:
                return result["parent_run_id"]

            if attempt < max_retries - 1:
                logger.debug(
                    f"Parent run not found for {run_id}, retrying in {retry_delay}s "
                    f"(attempt {attempt + 1}/{max_retries})"
                )
                time.sleep(retry_delay)

        logger.error(f"Failed to find parent run for {run_id} after {max_retries} attempts")
        raise ResourceNotFoundError(f"Run not found: {run_id}")

    def get_in_out(
        self,
        input_dict: dict,
        api_type: str,
        *,
        prepare_runtime_priors: bool = False,
        prior_preparer: Callable[[dict, str], Any] | None = None,
    ) -> CacheOutput:
        """Get input/output for an LLM call, handling caching, overwrites, and priors."""
        from sovara.common.utils import hash_input, set_seed
        from sovara.runner.context_manager import get_run_id
        from sovara.runner.monkey_patching.patching_utils import capture_stack_trace, get_node_kind

        stack_trace = capture_stack_trace()
        run_id = get_run_id()
        node_kind = get_node_kind(input_dict, api_type)
        prior_result = None
        original_transport_json = func_kwargs_to_json_str(input_dict, api_type)
        should_prepare_runtime_priors = self._should_prepare_runtime_priors(
            prepare_runtime_priors=prepare_runtime_priors,
            node_kind=node_kind,
            api_type=api_type,
        )

        def restore_original_transport_input() -> dict:
            return json_str_to_original_inp_dict(original_transport_json, input_dict, api_type)

        working_input_dict = input_dict
        if should_prepare_runtime_priors:
            from sovara.runner.priors import prepare_llm_call_for_priors

            preparer = prior_preparer or prepare_llm_call_for_priors
            prior_result = preparer(input_dict, api_type)
            working_input_dict = prior_result.executed_input_dict

        input_pickle = func_kwargs_to_json_str(working_input_dict, api_type)
        input_hash = hash_input(input_pickle)

        occurrence = self._next_occurrence(run_id, input_hash)
        row = self.backend.get_llm_call_by_run_and_hash_query(run_id, input_hash, offset=occurrence)

        if row is None:
            logger.debug(f"Cache miss: run_id {str(run_id)[:4]}, input_hash {str(input_hash)[:4]}")
            node_uuid = str(uuid.uuid4())
            self.backend.begin_llm_call_query(
                run_id,
                externalize(input_pickle),
                input_hash,
                node_uuid,
                api_type,
                stack_trace,
                node_kind,
                prior_result.prompt_suffix_json if prior_result is not None else "[]",
            )
            set_seed(node_uuid)
            return CacheOutput(
                input_dict=working_input_dict,
                output=None,
                node_uuid=node_uuid,
                input_pickle=input_pickle,
                input_hash=input_hash,
                run_id=run_id,
                stack_trace=stack_trace,
                node_kind=node_kind,
                prompt_suffix_json=(
                    prior_result.prompt_suffix_json if prior_result is not None else "[]"
                ),
                prior_result=prior_result,
                started_at=time.perf_counter(),
                latency_seconds=None,
            )

        node_uuid = row["node_uuid"]
        output = None
        consumed_edit_field = None

        if row["input_overwrite"] is not None:
            logger.debug(
                f"Cache hit (input overwritten): run_id {str(run_id)[:4]}, "
                f"input_hash {str(input_hash)[:4]}"
            )
            restore_original_transport_input()
            working_input_dict = json_str_to_original_inp_dict(
                restore(row["input_overwrite"]),
                input_dict,
                api_type,
            )
            if should_prepare_runtime_priors:
                from sovara.runner.priors import prepare_llm_call_for_priors

                preparer = prior_preparer or prepare_llm_call_for_priors
                prior_result = preparer(working_input_dict, api_type)
                prior_result.restore_original_input = restore_original_transport_input
                working_input_dict = prior_result.executed_input_dict
            input_pickle = func_kwargs_to_json_str(working_input_dict, api_type)
            input_hash = hash_input(input_pickle)
            consumed_edit_field = "input"
            self.backend.mark_llm_call_in_flight_query(run_id, node_uuid)

        elif row["output_overwrite"] is not None:
            output = json_str_to_api_obj(restore(row["output_overwrite"]), api_type)
            status, error_json = self._status_and_error_for_output(output, api_type)
            self.finalize_llm_call(
                run_id,
                node_uuid,
                status=status,
                output_json=row["output_overwrite"],
                error_json=error_json,
                consume_edit_field="output",
            )
            logger.debug(
                f"Cache hit (output overwritten): run_id {str(run_id)[:4]}, "
                f"input_hash {str(input_hash)[:4]}"
            )
        elif row["output"] is not None:
            output = json_str_to_api_obj(restore(row["output"]), api_type)
            logger.debug(
                f"Cache hit (output set): run_id {str(run_id)[:4]}, input_hash {str(input_hash)[:4]}"
            )
        else:
            self.backend.mark_llm_call_in_flight_query(run_id, node_uuid)

        set_seed(node_uuid)
        return CacheOutput(
            input_dict=working_input_dict,
            output=output,
            node_uuid=node_uuid,
            input_pickle=input_pickle,
            input_hash=input_hash,
            run_id=run_id,
            stack_trace=stack_trace,
            node_kind=node_kind,
            prompt_suffix_json=(
                prior_result.prompt_suffix_json if prior_result is not None else "[]"
            ),
            prior_result=prior_result,
            consumed_edit_field=consumed_edit_field,
            started_at=None if output is not None else time.perf_counter(),
            latency_seconds=row["latency_seconds"],
        )

    def cache_output(
        self, cache_result: CacheOutput, output_obj: Any, api_type: str, cache: bool = True
    ) -> None:
        """Cache the output of an LLM call."""
        from sovara.common.utils import set_seed

        random.seed()
        node_uuid = cache_result.node_uuid or str(uuid.uuid4())
        output_json_str = api_obj_to_json_str(output_obj, api_type)
        status, error_json = self._status_and_error_for_output(output_obj, api_type)
        latency_seconds = None
        if cache_result.started_at is not None:
            latency_seconds = max(0.0, time.perf_counter() - cache_result.started_at)

        self.finalize_llm_call(
            cache_result.run_id,
            node_uuid,
            status=status,
            input_pickle=cache_result.input_pickle,
            input_hash=cache_result.input_hash,
            output_json=output_json_str,
            latency_seconds=latency_seconds,
            error_json=error_json,
            stack_trace=cache_result.stack_trace,
            node_kind=cache_result.node_kind,
            prompt_suffix_json=cache_result.prompt_suffix_json,
            consume_edit_field=cache_result.consumed_edit_field,
        )
        cache_result.output = output_obj
        cache_result.node_uuid = node_uuid
        cache_result.latency_seconds = latency_seconds
        set_seed(node_uuid)

    def cache_exception(self, cache_result: CacheOutput, exc: Exception, api_type: str) -> None:
        node_uuid = cache_result.node_uuid or str(uuid.uuid4())
        latency_seconds = None
        if cache_result.started_at is not None:
            latency_seconds = max(0.0, time.perf_counter() - cache_result.started_at)
        self.finalize_llm_call(
            cache_result.run_id,
            node_uuid,
            status="error",
            input_pickle=cache_result.input_pickle,
            input_hash=cache_result.input_hash,
            latency_seconds=latency_seconds,
            error_json=self._exception_error_json(exc, api_type),
            stack_trace=cache_result.stack_trace,
            node_kind=cache_result.node_kind,
            prompt_suffix_json=cache_result.prompt_suffix_json,
            consume_edit_field=cache_result.consumed_edit_field,
            clear_output=True,
        )
        cache_result.node_uuid = node_uuid
        cache_result.latency_seconds = latency_seconds

    def insert_llm_call_with_output(
        self,
        run_id,
        input_pickle,
        input_hash,
        node_uuid,
        api_type,
        output_pickle,
        stack_trace=None,
        node_kind=None,
        prompt_suffix_json="[]",
    ):
        self.backend.insert_llm_call_with_output_query(
            run_id,
            externalize(input_pickle),
            input_hash,
            node_uuid,
            api_type,
            externalize(output_pickle),
            stack_trace,
            node_kind,
            prompt_suffix_json,
        )

    def delete_llm_calls(self, run_id):
        return self.backend.delete_llm_calls_query(run_id)

    def delete_all_llm_calls(self):
        return self.backend.delete_all_llm_calls_query()

    def begin_llm_call(
        self,
        run_id,
        input_pickle,
        input_hash,
        node_uuid,
        api_type,
        stack_trace=None,
        node_kind=None,
        prompt_suffix_json="[]",
    ):
        self.backend.begin_llm_call_query(
            run_id,
            externalize(input_pickle),
            input_hash,
            node_uuid,
            api_type,
            stack_trace,
            node_kind,
            prompt_suffix_json,
        )

    def finalize_llm_call(
        self,
        run_id,
        node_uuid,
        *,
        status,
        input_pickle=None,
        input_hash=None,
        output_json=None,
        latency_seconds=None,
        error_json=None,
        stack_trace=None,
        node_kind=None,
        prompt_suffix_json=None,
        consume_edit_field=None,
        clear_output=False,
    ):
        self.backend.finalize_llm_call_query(
            run_id,
            node_uuid,
            input_pickle=externalize(input_pickle) if input_pickle is not None else None,
            input_hash=input_hash,
            output_json=externalize(output_json) if output_json is not None else None,
            status=status,
            latency_seconds=latency_seconds,
            error_json=error_json,
            stack_trace=stack_trace,
            node_kind=node_kind,
            prompt_suffix_json=prompt_suffix_json,
            consume_edit_field=consume_edit_field,
            clear_output=clear_output,
        )
        if output_json is not None or clear_output:
            self._reset_prior_coverage_for_output_change(run_id, node_uuid)
        if consume_edit_field in {"input", "output"}:
            active_edit = self.get_active_edit(run_id)
            if (
                active_edit
                and active_edit["node_uuid"] == node_uuid
                and active_edit["field"] == consume_edit_field
            ):
                self.clear_active_edit(run_id)
        self.checkpoint_active_runtime(run_id)

    def _reset_prior_coverage_for_output_change(self, run_id: str, node_uuid: str) -> None:
        try:
            retrieval = self.get_prior_retrieval(run_id, node_uuid)
            if retrieval is None:
                return
            self.update_prior_coverage(
                retrieval["retrieval_id"],
                prior_coverage=None,
                coverage_status="not_requested",
            )
            self.update_prior_adherence(
                retrieval["retrieval_id"],
                adherence_status="not_requested",
            )
        except Exception:
            logger.debug(
                "Failed to reset prior coverage for output change: run_id=%s node_uuid=%s",
                run_id,
                node_uuid,
                exc_info=True,
            )

    def find_node_uuids_by_prefix(self, run_id, node_uuid_prefix):
        rows = self.backend.find_node_uuids_by_prefix_query(run_id, node_uuid_prefix)
        return [row["node_uuid"] for row in rows]

    def query_one_llm_call_input(self, run_id, node_uuid):
        return self.backend.get_llm_call_input_api_type_query(run_id, node_uuid)

    def query_one_llm_call_output(self, run_id, node_uuid):
        return self.backend.get_llm_call_output_api_type_query(run_id, node_uuid)

    def get_llm_calls_for_run(self, run_id):
        return self.backend.get_llm_calls_for_run_query(run_id)

    def get_llm_call_full(self, run_id, node_uuid):
        return self.backend.get_llm_call_full_query(run_id, node_uuid)

    def copy_llm_calls(self, old_run_id, new_run_id):
        self.backend.copy_llm_calls_query(old_run_id, new_run_id)

    def set_llm_verdict(self, run_id: str, node_uuid: str, llm_verdict: str | None) -> None:
        if llm_verdict is not None and llm_verdict not in self._VALID_LLM_VERDICTS:
            raise BadRequestError(f"Unsupported llm verdict: {llm_verdict!r}")
        self.backend.set_llm_verdict_query(run_id, node_uuid, llm_verdict)

    def get_tokens_timeseries(self, project_id, time_from, time_to, bucket_seconds):
        return self.backend.get_tokens_timeseries_query(
            project_id,
            time_from,
            time_to,
            bucket_seconds,
            user_id=self.user_id,
        )
