"""SQLite connection management.

Uses a small bounded pool of reusable SQLite connections under WAL mode so the
server can handle threadpool churn without leaking file descriptors. A
generation counter invalidates pooled handles after global shutdown cleanup.
"""

import os
import sqlite3
import threading
import weakref
from contextlib import contextmanager
from typing import Iterator

from sovara.common.constants import SOVARA_DB_PATH
from sovara.common.logger import logger

_schema_initialized = False
_init_lock = threading.Lock()
_pool_lock = threading.Lock()
_pool_condition = threading.Condition(_pool_lock)
_idle_connections: list[tuple[int, sqlite3.Connection]] = []
_in_use_connections: dict[int, tuple[sqlite3.Connection, int]] = {}
_open_connection_count = 0
_connection_generation = 0


def _configured_pool_size() -> int:
    raw_value = os.environ.get("SOVARA_SQLITE_POOL_SIZE", "8")
    try:
        pool_size = int(raw_value)
    except ValueError:
        logger.warning(
            "Invalid SOVARA_SQLITE_POOL_SIZE=%r; falling back to 8",
            raw_value,
        )
        return 8
    if pool_size < 1:
        logger.warning(
            "Non-positive SOVARA_SQLITE_POOL_SIZE=%r; using 1 instead",
            raw_value,
        )
        return 1
    return pool_size


_pool_size = _configured_pool_size()


def _get_db_path() -> str:
    """Return the effective SQLite file path, honouring config.yaml over env var."""
    import sovara.server.database.sqlite.connection as _self
    return os.path.join(_self.SOVARA_DB_PATH, "runs.sqlite")


def _create_connection():
    """Open a fresh SQLite connection."""
    global _schema_initialized

    db_path = _get_db_path()
    os.makedirs(os.path.dirname(db_path), exist_ok=True)

    conn = sqlite3.connect(
        db_path,
        timeout=30.0,
        check_same_thread=False,
    )
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=10000")

    if not _schema_initialized:
        with _init_lock:
            if not _schema_initialized:
                from .schema import init_db

                init_db(conn)
                _schema_initialized = True

    return conn


def _close_connections(connections: list[sqlite3.Connection]) -> None:
    for conn in connections:
        try:
            conn.close()
        except Exception as exc:
            logger.warning("Error closing SQLite connection: %s", exc)


def _checkout_connection() -> tuple[sqlite3.Connection, int]:
    global _open_connection_count

    while True:
        stale_connections: list[sqlite3.Connection] = []
        create_generation: int | None = None
        with _pool_condition:
            while _idle_connections:
                generation, conn = _idle_connections.pop()
                if generation != _connection_generation:
                    _open_connection_count -= 1
                    stale_connections.append(conn)
                    continue
                _in_use_connections[id(conn)] = (conn, generation)
                break
            else:
                if _open_connection_count < _pool_size:
                    _open_connection_count += 1
                    create_generation = _connection_generation
                else:
                    _pool_condition.wait()
                    continue
                conn = None
                generation = None

        _close_connections(stale_connections)

        if conn is not None and generation is not None:
            return conn, generation

        try:
            conn = _create_connection()
        except Exception:
            with _pool_condition:
                _open_connection_count -= 1
                _pool_condition.notify()
            raise

        with _pool_condition:
            if create_generation != _connection_generation:
                _open_connection_count -= 1
                _pool_condition.notify()
                should_close = True
            else:
                _in_use_connections[id(conn)] = (conn, create_generation)
                should_close = False
        if should_close:
            _close_connections([conn])
            continue
        return conn, create_generation


def _return_connection(conn: sqlite3.Connection, generation: int) -> None:
    global _open_connection_count

    should_close = False
    with _pool_condition:
        entry = _in_use_connections.pop(id(conn), None)
        if entry is None:
            should_close = True
        elif generation != _connection_generation:
            _open_connection_count -= 1
            should_close = True
        else:
            _idle_connections.append((generation, conn))
        _pool_condition.notify()

    if should_close:
        _close_connections([conn])


class _PooledConnectionHandle:
    """Borrowed SQLite connection that returns itself to the pool on close."""

    def __init__(self, conn: sqlite3.Connection, generation: int):
        self._conn = conn
        self._finalizer = weakref.finalize(self, _return_connection, conn, generation)

    def _ensure_open(self) -> sqlite3.Connection:
        conn = self._conn
        if conn is None:
            raise sqlite3.ProgrammingError("Cannot operate on a released pooled SQLite connection.")
        return conn

    @property
    def connection_id(self) -> int:
        return id(self._ensure_open())

    def close(self) -> None:
        if self._finalizer.alive:
            self._finalizer()
        self._conn = None

    def __enter__(self) -> "_PooledConnectionHandle":
        self._ensure_open()
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        self.close()
        return False

    def __getattr__(self, name: str):
        return getattr(self._ensure_open(), name)


def get_conn() -> _PooledConnectionHandle:
    """Borrow a SQLite connection from the bounded pool.

    Use as a context manager so the connection is promptly returned:

        with get_conn() as conn:
            conn.execute("SELECT 1")
    """
    conn, generation = _checkout_connection()
    return _PooledConnectionHandle(conn, generation)


@contextmanager
def transaction() -> Iterator[_PooledConnectionHandle]:
    """Borrow a connection and wrap the block in a commit/rollback scope."""
    with get_conn() as conn:
        try:
            yield conn
        except Exception:
            conn.rollback()
            raise
        else:
            conn.commit()


def reset_connection() -> None:
    """Reset lazy-init state so the next get_conn() re-initialises the schema.

    Called when the user switches DB backend at runtime.
    """
    global _schema_initialized
    with _init_lock:
        _schema_initialized = False


def query_one(sql, params=()):
    with get_conn() as conn:
        cursor = conn.cursor()
        try:
            cursor.execute(sql, params)
            return cursor.fetchone()
        finally:
            cursor.close()


def query_all(sql, params=()):
    with get_conn() as conn:
        cursor = conn.cursor()
        try:
            cursor.execute(sql, params)
            return cursor.fetchall()
        finally:
            cursor.close()


def execute(sql, params=()):
    with transaction() as conn:
        cursor = conn.cursor()
        try:
            cursor.execute(sql, params)
            return cursor.lastrowid
        finally:
            cursor.close()


def clear_connections():
    """Backward-compatible alias for clearing pooled SQLite state."""
    close_all_connections()


def close_all_connections():
    """Close idle pooled connections and invalidate checked-out handles."""
    global _connection_generation, _open_connection_count

    with _pool_condition:
        idle_connections = [conn for _generation, conn in _idle_connections]
        _idle_connections.clear()
        _open_connection_count -= len(idle_connections)
        _connection_generation += 1
        _pool_condition.notify_all()

    _close_connections(idle_connections)
