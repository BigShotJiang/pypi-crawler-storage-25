import json
import sqlite3

from sovara.common.constants import MAIN_SERVER_LOG
from sovara.common.custom_metrics import get_metric_kind
from sovara.common.logger import create_file_logger
from sovara.server.llm_settings import TIER_DB_FIELD_NAMES, USER_LLM_DB_COLUMNS, USER_LLM_TIERS
from sovara.server.priors_backend.constants import (
    DEFAULT_PRIORS_LATENCY_TIER,
    DEFAULT_PRIORS_TRACK_ADHERENCE,
    DEFAULT_PRIORS_TRACK_GROUNDEDNESS,
    LATENCY_TIERS,
)


logger = create_file_logger(MAIN_SERVER_LOG, logger_name="sovara.server.database.sqlite.schema")


def init_db(conn):
    c = conn.cursor()
    user_llm_columns_sql = ",\n            ".join(
        f"{USER_LLM_DB_COLUMNS[tier][field]} TEXT"
        for tier in USER_LLM_TIERS
        for field in TIER_DB_FIELD_NAMES
    )

    c.execute(
        f"""
        CREATE TABLE IF NOT EXISTS users (
            user_id TEXT PRIMARY KEY,
            full_name TEXT NOT NULL,
            email TEXT NOT NULL,
            {user_llm_columns_sql},
            created_at TIMESTAMP DEFAULT (datetime('now'))
        )
    """
    )

    c.execute(
        f"""
        CREATE TABLE IF NOT EXISTS projects (
            project_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            priors_latency_tier TEXT NOT NULL DEFAULT 'MEDIUM'
                CHECK (priors_latency_tier IN ('LOW', 'MEDIUM', 'HIGH')),
            priors_track_groundedness INTEGER NOT NULL DEFAULT 0
                CHECK (priors_track_groundedness IN (0, 1)),
            priors_track_adherence INTEGER NOT NULL DEFAULT 0
                CHECK (priors_track_adherence IN (0, 1)),
            created_at TIMESTAMP DEFAULT (datetime('now')),
            last_run_at TIMESTAMP
        )
    """
    )

    c.execute(
        """
        CREATE TABLE IF NOT EXISTS runs (
            run_id TEXT PRIMARY KEY,
            parent_run_id TEXT,
            project_id TEXT,
            user_id TEXT,
            graph_topology TEXT,
            timestamp TIMESTAMP DEFAULT (datetime('now')),
            runtime_seconds REAL,
            active_runtime_seconds REAL,
            cwd TEXT,
            command TEXT,
            environment TEXT,
            version_date TEXT,
            name TEXT,
            success TEXT CHECK (success IN ('', 'Satisfactory', 'Failed')),
            custom_metrics TEXT NOT NULL DEFAULT '{}',
            thumb_label INTEGER CHECK (thumb_label IN (0, 1)),
            notes TEXT,
            log TEXT,
            trace_chat_history TEXT NOT NULL DEFAULT '[]',
            active_edit_node_uuid TEXT,
            active_edit_node_label TEXT,
            active_edit_field TEXT CHECK (active_edit_field IN ('input', 'output')),
            active_edit_status TEXT CHECK (active_edit_status IN ('pending', 'not_consumed')),
            FOREIGN KEY (parent_run_id) REFERENCES runs (run_id),
            FOREIGN KEY (project_id) REFERENCES projects (project_id),
            FOREIGN KEY (user_id) REFERENCES users (user_id),
            UNIQUE (parent_run_id, name)
        )
    """
    )

    c.execute(
        """
        CREATE TABLE IF NOT EXISTS project_metric_kinds (
            project_id TEXT NOT NULL,
            metric_key TEXT NOT NULL,
            metric_kind TEXT NOT NULL CHECK (metric_kind IN ('bool', 'int', 'float')),
            PRIMARY KEY (project_id, metric_key),
            FOREIGN KEY (project_id) REFERENCES projects (project_id)
        )
    """
    )
    _ensure_run_metric_values_table(conn)

    c.execute(
        """
        CREATE TABLE IF NOT EXISTS project_tags (
            tag_id TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            name TEXT NOT NULL COLLATE NOCASE,
            color TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT (datetime('now')),
            FOREIGN KEY (project_id) REFERENCES projects (project_id),
            UNIQUE (project_id, name)
        )
    """
    )
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS run_tags (
            run_id TEXT NOT NULL,
            tag_id TEXT NOT NULL,
            PRIMARY KEY (run_id, tag_id),
            FOREIGN KEY (run_id) REFERENCES runs (run_id),
            FOREIGN KEY (tag_id) REFERENCES project_tags (tag_id)
        )
    """
    )
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS llm_calls (
            run_id TEXT,
            node_uuid TEXT,
            input TEXT,
            input_hash TEXT,
            input_overwrite TEXT,
            output TEXT,
            output_overwrite TEXT,
            color TEXT,
            label TEXT,
            api_type TEXT,
            node_kind TEXT CHECK (node_kind IN ('llm', 'mcp', 'tool')),
            prompt_suffix_json TEXT NOT NULL DEFAULT '[]',
            stack_trace TEXT,
            status TEXT NOT NULL DEFAULT 'success' CHECK (status IN ('in_flight', 'success', 'error')),
            latency_seconds REAL,
            error TEXT,
            llm_verdict TEXT CHECK (llm_verdict IN ('correct', 'incorrect', 'uncertain')),
            input_tokens INTEGER,
            output_tokens INTEGER,
            timestamp TIMESTAMP DEFAULT (datetime('now')),
            PRIMARY KEY (run_id, node_uuid),
            FOREIGN KEY (run_id) REFERENCES runs (run_id)
        )
    """
    )
    c.execute(
        """
        CREATE INDEX IF NOT EXISTS original_input_lookup ON llm_calls(run_id, input_hash)
    """
    )
    c.execute(
        """
        CREATE INDEX IF NOT EXISTS runs_timestamp_idx ON runs(timestamp DESC)
    """
    )
    c.execute(
        """
        CREATE INDEX IF NOT EXISTS runs_project_idx ON runs(project_id, timestamp DESC)
    """
    )
    c.execute(
        """
        CREATE INDEX IF NOT EXISTS project_tags_project_idx ON project_tags(project_id, name)
    """
    )
    c.execute(
        """
        CREATE INDEX IF NOT EXISTS run_tags_run_idx ON run_tags(run_id)
    """
    )
    c.execute(
        """
        CREATE INDEX IF NOT EXISTS run_tags_tag_idx ON run_tags(tag_id)
    """
    )
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS user_project_locations (
            user_id TEXT NOT NULL,
            project_id TEXT NOT NULL,
            project_location TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (user_id),
            FOREIGN KEY (project_id) REFERENCES projects (project_id),
            UNIQUE (user_id, project_location)
        )
    """
    )
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS priors_applied (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            prior_id TEXT NOT NULL,
            run_id TEXT NOT NULL,
            node_uuid TEXT,
            applied_at TIMESTAMP DEFAULT (datetime('now')),
            FOREIGN KEY (run_id) REFERENCES runs (run_id),
            UNIQUE (prior_id, run_id, node_uuid)
        )
    """
    )
    c.execute(
        """
        CREATE INDEX IF NOT EXISTS priors_applied_prior_idx ON priors_applied(prior_id)
    """
    )

    conn.commit()
    _ensure_user_schema(conn)
    _ensure_project_schema(conn)
    _ensure_run_schema(conn)


def _metric_storage_values(metric_kind, value):
    if metric_kind == "bool":
        return int(bool(value)), None, None
    if metric_kind == "int":
        return None, int(value), None
    return None, None, float(value)


def _iter_run_metric_rows(run_id, project_id, raw_custom_metrics):
    if isinstance(raw_custom_metrics, dict):
        parsed = raw_custom_metrics
    elif raw_custom_metrics:
        try:
            parsed = json.loads(raw_custom_metrics)
        except (TypeError, json.JSONDecodeError):
            return
    else:
        return

    if not isinstance(parsed, dict):
        return

    for metric_key, value in parsed.items():
        if not isinstance(metric_key, str):
            continue
        if not isinstance(value, (bool, int, float)):
            continue
        metric_kind = get_metric_kind(value)
        bool_value, int_value, float_value = _metric_storage_values(metric_kind, value)
        yield (
            run_id,
            project_id,
            metric_key,
            metric_kind,
            bool_value,
            int_value,
            float_value,
        )


def _ensure_run_metric_values_table(conn):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS run_metric_values (
            run_id TEXT NOT NULL,
            project_id TEXT,
            metric_key TEXT NOT NULL,
            metric_kind TEXT NOT NULL CHECK (metric_kind IN ('bool', 'int', 'float')),
            bool_value INTEGER CHECK (bool_value IN (0, 1)),
            int_value INTEGER,
            float_value REAL,
            PRIMARY KEY (run_id, metric_key),
            FOREIGN KEY (run_id) REFERENCES runs (run_id),
            FOREIGN KEY (project_id) REFERENCES projects (project_id)
        )
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS run_metric_values_run_idx
        ON run_metric_values(run_id)
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS run_metric_values_project_key_kind_idx
        ON run_metric_values(project_id, metric_key, metric_kind)
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS run_metric_values_bool_idx
        ON run_metric_values(project_id, metric_key, bool_value, run_id)
        WHERE metric_kind = 'bool'
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS run_metric_values_int_idx
        ON run_metric_values(project_id, metric_key, int_value, run_id)
        WHERE metric_kind = 'int'
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS run_metric_values_float_idx
        ON run_metric_values(project_id, metric_key, float_value, run_id)
        WHERE metric_kind = 'float'
        """
    )


def _backfill_run_metric_values(conn):
    rows = conn.execute(
        """
        SELECT run_id, project_id, custom_metrics
        FROM runs
        WHERE custom_metrics IS NOT NULL AND custom_metrics != '{}'
        """
    ).fetchall()
    if not rows:
        return

    metric_rows = []
    metric_kinds = set()
    for row in rows:
        run_id = row["run_id"]
        project_id = row["project_id"]
        for metric_row in _iter_run_metric_rows(run_id, project_id, row["custom_metrics"]):
            metric_rows.append(metric_row)
            if project_id:
                metric_kinds.add((project_id, metric_row[2], metric_row[3]))

    if not metric_rows:
        return

    cursor = conn.cursor()
    cursor.executemany(
        """
        INSERT OR REPLACE INTO run_metric_values (
            run_id,
            project_id,
            metric_key,
            metric_kind,
            bool_value,
            int_value,
            float_value
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        metric_rows,
    )
    if metric_kinds:
        cursor.executemany(
            """
            INSERT INTO project_metric_kinds (project_id, metric_key, metric_kind)
            VALUES (?, ?, ?)
            ON CONFLICT(project_id, metric_key) DO UPDATE SET metric_kind=excluded.metric_kind
            """,
            sorted(metric_kinds),
        )
    conn.commit()
    logger.info(
        "Backfilled run_metric_values rows=%d metric_keys=%d", len(metric_rows), len(metric_kinds)
    )


def _ensure_user_schema(conn):
    columns = {row["name"] for row in conn.execute("PRAGMA table_info(users)").fetchall()}
    for tier in USER_LLM_TIERS:
        for field_name in TIER_DB_FIELD_NAMES:
            column_name = USER_LLM_DB_COLUMNS[tier][field_name]
            if column_name not in columns:
                conn.execute(f"ALTER TABLE users ADD COLUMN {column_name} TEXT")

    if "llm_primary_ip" in columns:
        conn.execute(
            """
            UPDATE users
            SET llm_primary_base_url = COALESCE(llm_primary_base_url, llm_primary_ip)
            WHERE llm_primary_ip IS NOT NULL
            """
        )
    if "llm_helper_ip" in columns:
        conn.execute(
            """
            UPDATE users
            SET llm_helper_base_url = COALESCE(llm_helper_base_url, llm_helper_ip)
            WHERE llm_helper_ip IS NOT NULL
            """
        )

    _migrate_legacy_user_settings(conn)
    conn.commit()


def _migrate_legacy_user_settings(conn):
    from sovara.server.llm_settings import flatten_user_llm_settings, migrate_user_llm_settings_row

    update_columns = [
        USER_LLM_DB_COLUMNS[tier][field_name]
        for tier in USER_LLM_TIERS
        for field_name in TIER_DB_FIELD_NAMES
    ]
    update_sql = f"""
        UPDATE users
        SET {", ".join(f"{column}=?" for column in update_columns)}
        WHERE user_id=?
    """

    for row in conn.execute("SELECT * FROM users").fetchall():
        settings = migrate_user_llm_settings_row(row)
        flattened = flatten_user_llm_settings(settings)
        conn.execute(
            update_sql,
            tuple(flattened[column] for column in update_columns) + (row["user_id"],),
        )


def _ensure_run_schema(conn):
    had_run_metric_values = (
        conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='run_metric_values'"
        ).fetchone()
        is not None
    )
    columns = {row["name"] for row in conn.execute("PRAGMA table_info(runs)").fetchall()}
    if "color_preview" in columns:
        _drop_runs_color_preview_column(conn)
        columns = {row["name"] for row in conn.execute("PRAGMA table_info(runs)").fetchall()}
    if "trace_chat_history" not in columns:
        conn.execute("ALTER TABLE runs ADD COLUMN trace_chat_history TEXT NOT NULL DEFAULT '[]'")
    if "custom_metrics" not in columns:
        conn.execute("ALTER TABLE runs ADD COLUMN custom_metrics TEXT NOT NULL DEFAULT '{}'")
    if "thumb_label" not in columns:
        conn.execute(
            "ALTER TABLE runs ADD COLUMN thumb_label INTEGER CHECK (thumb_label IN (0, 1))"
        )
    if "runtime_seconds" not in columns:
        conn.execute("ALTER TABLE runs ADD COLUMN runtime_seconds REAL")
    if "active_runtime_seconds" not in columns:
        conn.execute("ALTER TABLE runs ADD COLUMN active_runtime_seconds REAL")
    if "active_edit_node_uuid" not in columns:
        conn.execute("ALTER TABLE runs ADD COLUMN active_edit_node_uuid TEXT")
    if "active_edit_node_label" not in columns:
        conn.execute("ALTER TABLE runs ADD COLUMN active_edit_node_label TEXT")
    if "active_edit_field" not in columns:
        conn.execute(
            "ALTER TABLE runs ADD COLUMN active_edit_field TEXT CHECK (active_edit_field IN ('input', 'output'))"
        )
    if "active_edit_status" not in columns:
        conn.execute(
            "ALTER TABLE runs ADD COLUMN active_edit_status TEXT CHECK (active_edit_status IN ('pending', 'not_consumed'))"
        )
    _ensure_llm_calls_schema(conn)
    _ensure_prior_schema(conn)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS project_metric_kinds (
            project_id TEXT NOT NULL,
            metric_key TEXT NOT NULL,
            metric_kind TEXT NOT NULL CHECK (metric_kind IN ('bool', 'int', 'float')),
            PRIMARY KEY (project_id, metric_key),
            FOREIGN KEY (project_id) REFERENCES projects (project_id)
        )
    """
    )
    _ensure_run_metric_values_table(conn)
    if not had_run_metric_values:
        _backfill_run_metric_values(conn)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS project_tags (
            tag_id TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            name TEXT NOT NULL COLLATE NOCASE,
            color TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT (datetime('now')),
            FOREIGN KEY (project_id) REFERENCES projects (project_id),
            UNIQUE (project_id, name)
        )
    """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS run_tags (
            run_id TEXT NOT NULL,
            tag_id TEXT NOT NULL,
            PRIMARY KEY (run_id, tag_id),
            FOREIGN KEY (run_id) REFERENCES runs (run_id),
            FOREIGN KEY (tag_id) REFERENCES project_tags (tag_id)
        )
    """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS project_tags_project_idx ON project_tags(project_id, name)
    """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS runs_timestamp_idx ON runs(timestamp DESC)
    """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS runs_project_idx ON runs(project_id, timestamp DESC)
    """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS run_tags_run_idx ON run_tags(run_id)
    """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS run_tags_tag_idx ON run_tags(tag_id)
    """
    )
    conn.commit()


def _ensure_project_schema(conn):
    columns = {row["name"] for row in conn.execute("PRAGMA table_info(projects)").fetchall()}
    if "priors_latency_tier" not in columns:
        conn.execute(
            "ALTER TABLE projects ADD COLUMN priors_latency_tier TEXT NOT NULL DEFAULT 'MEDIUM' "
            "CHECK (priors_latency_tier IN ('LOW', 'MEDIUM', 'HIGH'))"
        )
    if "priors_track_groundedness" not in columns:
        conn.execute(
            "ALTER TABLE projects ADD COLUMN priors_track_groundedness INTEGER NOT NULL DEFAULT 0 "
            "CHECK (priors_track_groundedness IN (0, 1))"
        )
    if "priors_track_adherence" not in columns:
        conn.execute(
            "ALTER TABLE projects ADD COLUMN priors_track_adherence INTEGER NOT NULL DEFAULT 0 "
            "CHECK (priors_track_adherence IN (0, 1))"
        )
    conn.execute(
        "UPDATE projects SET priors_latency_tier=? WHERE priors_latency_tier IS NULL OR priors_latency_tier=''",
        (DEFAULT_PRIORS_LATENCY_TIER,),
    )
    conn.execute(
        "UPDATE projects SET priors_track_groundedness=? WHERE priors_track_groundedness IS NULL",
        (int(DEFAULT_PRIORS_TRACK_GROUNDEDNESS),),
    )
    conn.execute(
        "UPDATE projects SET priors_track_adherence=? WHERE priors_track_adherence IS NULL",
        (int(DEFAULT_PRIORS_TRACK_ADHERENCE),),
    )
    conn.commit()


def _drop_runs_color_preview_column(conn):
    try:
        conn.execute("ALTER TABLE runs DROP COLUMN color_preview")
        return
    except sqlite3.OperationalError:
        logger.info("Falling back to table rebuild to remove runs.color_preview")

    conn.execute(
        """
        CREATE TABLE runs_new (
            run_id TEXT PRIMARY KEY,
            parent_run_id TEXT,
            project_id TEXT,
            user_id TEXT,
            graph_topology TEXT,
            timestamp TIMESTAMP DEFAULT (datetime('now')),
            runtime_seconds REAL,
            active_runtime_seconds REAL,
            cwd TEXT,
            command TEXT,
            environment TEXT,
            version_date TEXT,
            name TEXT,
            success TEXT CHECK (success IN ('', 'Satisfactory', 'Failed')),
            custom_metrics TEXT NOT NULL DEFAULT '{}',
            thumb_label INTEGER CHECK (thumb_label IN (0, 1)),
            notes TEXT,
            log TEXT,
            trace_chat_history TEXT NOT NULL DEFAULT '[]',
            active_edit_node_uuid TEXT,
            active_edit_node_label TEXT,
            active_edit_field TEXT CHECK (active_edit_field IN ('input', 'output')),
            active_edit_status TEXT CHECK (active_edit_status IN ('pending', 'not_consumed')),
            FOREIGN KEY (parent_run_id) REFERENCES runs (run_id),
            FOREIGN KEY (project_id) REFERENCES projects (project_id),
            FOREIGN KEY (user_id) REFERENCES users (user_id),
            UNIQUE (parent_run_id, name)
        )
        """
    )
    conn.execute(
        """
        INSERT INTO runs_new (
            run_id,
            parent_run_id,
            project_id,
            user_id,
            graph_topology,
            timestamp,
            runtime_seconds,
            active_runtime_seconds,
            cwd,
            command,
            environment,
            version_date,
            name,
            success,
            custom_metrics,
            thumb_label,
            notes,
            log,
            trace_chat_history,
            active_edit_node_uuid,
            active_edit_node_label,
            active_edit_field,
            active_edit_status
        )
        SELECT
            run_id,
            parent_run_id,
            project_id,
            user_id,
            graph_topology,
            timestamp,
            runtime_seconds,
            active_runtime_seconds,
            cwd,
            command,
            environment,
            version_date,
            name,
            success,
            custom_metrics,
            thumb_label,
            notes,
            log,
            COALESCE(trace_chat_history, '[]'),
            active_edit_node_uuid,
            active_edit_node_label,
            active_edit_field,
            active_edit_status
        FROM runs
        """
    )
    conn.execute("DROP TABLE runs")
    conn.execute("ALTER TABLE runs_new RENAME TO runs")


def _ensure_llm_calls_schema(conn):
    columns = {row["name"] for row in conn.execute("PRAGMA table_info(llm_calls)").fetchall()}
    if "node_kind" not in columns:
        conn.execute(
            "ALTER TABLE llm_calls ADD COLUMN node_kind TEXT CHECK (node_kind IN ('llm', 'mcp', 'tool'))"
        )
    if "input_delta_json" in columns and "prompt_suffix_json" not in columns:
        conn.execute("ALTER TABLE llm_calls RENAME COLUMN input_delta_json TO prompt_suffix_json")
        columns = {row["name"] for row in conn.execute("PRAGMA table_info(llm_calls)").fetchall()}
    if "prompt_suffix_json" not in columns:
        conn.execute(
            "ALTER TABLE llm_calls ADD COLUMN prompt_suffix_json TEXT NOT NULL DEFAULT '[]'"
        )
    if "output_overwrite" not in columns:
        conn.execute("ALTER TABLE llm_calls ADD COLUMN output_overwrite TEXT")
    if "status" not in columns:
        conn.execute(
            "ALTER TABLE llm_calls ADD COLUMN status TEXT NOT NULL DEFAULT 'success' "
            "CHECK (status IN ('in_flight', 'success', 'error'))"
        )
    if "latency_seconds" not in columns:
        conn.execute("ALTER TABLE llm_calls ADD COLUMN latency_seconds REAL")
    if "error" not in columns:
        conn.execute("ALTER TABLE llm_calls ADD COLUMN error TEXT")
    if "llm_verdict" not in columns:
        conn.execute(
            "ALTER TABLE llm_calls ADD COLUMN llm_verdict TEXT "
            "CHECK (llm_verdict IN ('correct', 'incorrect', 'uncertain'))"
        )
    if "input_tokens" not in columns:
        conn.execute("ALTER TABLE llm_calls ADD COLUMN input_tokens INTEGER")
    if "output_tokens" not in columns:
        conn.execute("ALTER TABLE llm_calls ADD COLUMN output_tokens INTEGER")
    conn.commit()


def _ensure_prior_schema(conn):
    dropped_legacy_lessons_applied = (
        conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='lessons_applied'"
        ).fetchone()
        is not None
    )
    conn.execute("DROP TABLE IF EXISTS lessons_applied")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS priors_scopes (
            user_id TEXT NOT NULL,
            project_id TEXT NOT NULL,
            revision INTEGER NOT NULL DEFAULT 1,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (user_id, project_id)
        )
        """
    )
    _ensure_prior_retrievals_table(conn)
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS prior_retrievals_run_idx ON prior_retrievals(run_id)
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS prior_retrievals_run_node_idx
        ON prior_retrievals(run_id, node_uuid)
        """
    )
    conn.execute(
        """
        CREATE UNIQUE INDEX IF NOT EXISTS prior_retrievals_run_node_uidx
        ON prior_retrievals(run_id, node_uuid)
        WHERE node_uuid IS NOT NULL
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS prior_retrievals_coverage_status_idx
        ON prior_retrievals(coverage_status, created_at)
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS prefix_cache (
            user_id TEXT NOT NULL,
            project_id TEXT NOT NULL,
            base_path TEXT NOT NULL,
            model TEXT NOT NULL,
            first_key TEXT NOT NULL,
            pair_count INTEGER NOT NULL,
            clean_pairs_json TEXT NOT NULL,
            injected_pairs_json TEXT NOT NULL,
            prior_ids_json TEXT NOT NULL DEFAULT '[]',
            created_at TIMESTAMP DEFAULT (datetime('now')),
            updated_at TIMESTAMP DEFAULT (datetime('now')),
            PRIMARY KEY (user_id, project_id, base_path, model, clean_pairs_json)
        )
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS prefix_cache_scope_idx
        ON prefix_cache(user_id, project_id, base_path, model, first_key, pair_count DESC)
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS retrieval_cache (
            user_id TEXT NOT NULL,
            project_id TEXT NOT NULL,
            priors_revision INTEGER NOT NULL,
            base_path TEXT NOT NULL,
            model TEXT NOT NULL,
            context_hash TEXT NOT NULL,
            ignore_prior_ids_json TEXT NOT NULL,
            response_json TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT (datetime('now')),
            updated_at TIMESTAMP DEFAULT (datetime('now')),
            PRIMARY KEY (
                user_id,
                project_id,
                priors_revision,
                base_path,
                model,
                context_hash,
                ignore_prior_ids_json
            )
        )
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS retrieval_cache_scope_idx
        ON retrieval_cache(user_id, project_id, priors_revision)
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS prior_coverage_cache (
            cache_key TEXT PRIMARY KEY,
            processed_context_hash TEXT NOT NULL,
            llm_output_hash TEXT NOT NULL,
            priors_hash TEXT NOT NULL,
            judge_model TEXT NOT NULL,
            judge_tier TEXT NOT NULL,
            reasoning_effort TEXT NOT NULL,
            prompt_version TEXT NOT NULL,
            prior_coverage INTEGER NOT NULL,
            total_importance INTEGER,
            grounded_importance INTEGER,
            guidance_points_json TEXT NOT NULL DEFAULT '[]',
            created_at TIMESTAMP DEFAULT (datetime('now')),
            updated_at TIMESTAMP DEFAULT (datetime('now'))
        )
        """
    )
    coverage_cache_columns = {
        row["name"] for row in conn.execute("PRAGMA table_info(prior_coverage_cache)").fetchall()
    }
    if "total_importance" not in coverage_cache_columns:
        conn.execute("ALTER TABLE prior_coverage_cache ADD COLUMN total_importance INTEGER")
    if "grounded_importance" not in coverage_cache_columns:
        conn.execute("ALTER TABLE prior_coverage_cache ADD COLUMN grounded_importance INTEGER")
    if "guidance_points_json" not in coverage_cache_columns:
        conn.execute(
            "ALTER TABLE prior_coverage_cache "
            "ADD COLUMN guidance_points_json TEXT NOT NULL DEFAULT '[]'"
        )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS prior_coverage_cache_config_idx
        ON prior_coverage_cache(judge_model, judge_tier, reasoning_effort, prompt_version)
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS prior_adherence_cache (
            cache_key TEXT PRIMARY KEY,
            processed_context_hash TEXT NOT NULL,
            llm_output_hash TEXT NOT NULL,
            priors_hash TEXT NOT NULL,
            judge_model TEXT NOT NULL,
            judge_tier TEXT NOT NULL,
            reasoning_effort TEXT NOT NULL,
            prompt_version TEXT NOT NULL,
            prior_adherence INTEGER NOT NULL,
            severity_weighted_prior_adherence INTEGER NOT NULL,
            relevant_prior_count INTEGER NOT NULL,
            followed_relevant_prior_count INTEGER NOT NULL,
            violated_relevant_prior_count INTEGER NOT NULL,
            total_non_adherence_severity INTEGER NOT NULL,
            max_non_adherence_severity INTEGER NOT NULL,
            prior_adherence_items_json TEXT NOT NULL DEFAULT '[]',
            created_at TIMESTAMP DEFAULT (datetime('now')),
            updated_at TIMESTAMP DEFAULT (datetime('now'))
        )
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS prior_adherence_cache_config_idx
        ON prior_adherence_cache(judge_model, judge_tier, reasoning_effort, prompt_version)
        """
    )
    if dropped_legacy_lessons_applied:
        logger.info("Dropped legacy lessons_applied table")
    conn.commit()


def _ensure_prior_retrievals_table(conn):
    table_exists = (
        conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='prior_retrievals'"
        ).fetchone()
        is not None
    )
    if not table_exists:
        _create_prior_retrievals_table(conn)
        return

    columns = {
        row["name"] for row in conn.execute("PRAGMA table_info(prior_retrievals)").fetchall()
    }
    expected_columns = {
        "retrieval_id",
        "run_id",
        "node_uuid",
        "raw_context",
        "processed_context",
        "inherited_prior_ids_json",
        "retrieved_priors_json",
        "applied_priors_json",
        "rendered_priors_block",
        "injection_anchor_json",
        "model",
        "latency_tier",
        "timeout_ms",
        "retrieval_latency_ms",
        "prior_coverage",
        "retrieval_status",
        "coverage_status",
        "warning_message",
        "error_message",
        "created_at",
        "updated_at",
    }
    detail_columns = {
        "groundedness_total_importance": "INTEGER",
        "groundedness_grounded_importance": "INTEGER",
        "groundedness_guidance_points_json": "TEXT NOT NULL DEFAULT '[]'",
        "adherence_status": (
            "TEXT NOT NULL DEFAULT 'not_requested' "
            "CHECK (adherence_status IN ('not_requested', 'pending', 'complete', 'failed'))"
        ),
        "prior_adherence": "INTEGER",
        "severity_weighted_prior_adherence": "INTEGER",
        "relevant_prior_count": "INTEGER",
        "followed_relevant_prior_count": "INTEGER",
        "violated_relevant_prior_count": "INTEGER",
        "total_non_adherence_severity": "INTEGER",
        "max_non_adherence_severity": "INTEGER",
        "prior_adherence_items_json": "TEXT NOT NULL DEFAULT '[]'",
    }
    if expected_columns.issubset(columns):
        for column, definition in detail_columns.items():
            if column not in columns:
                conn.execute(f"ALTER TABLE prior_retrievals ADD COLUMN {column} {definition}")
        return

    missing_columns = sorted(expected_columns - columns)
    raise RuntimeError(
        "Unsupported legacy prior_retrievals schema detected. "
        "Reset the local SQLite database before starting this version. "
        f"Missing canonical columns: {', '.join(missing_columns)}"
    )


def _create_prior_retrievals_table(conn):
    latency_tier_checks = ", ".join(repr(tier) for tier in LATENCY_TIERS)
    conn.execute(
        f"""
        CREATE TABLE IF NOT EXISTS prior_retrievals (
            retrieval_id TEXT PRIMARY KEY,
            run_id TEXT NOT NULL,
            node_uuid TEXT,
            raw_context TEXT NOT NULL DEFAULT '',
            processed_context TEXT NOT NULL DEFAULT '',
            inherited_prior_ids_json TEXT NOT NULL DEFAULT '[]',
            retrieved_priors_json TEXT NOT NULL DEFAULT '[]',
            applied_priors_json TEXT NOT NULL DEFAULT '[]',
            rendered_priors_block TEXT NOT NULL DEFAULT '',
            injection_anchor_json TEXT,
            model TEXT,
            latency_tier TEXT NOT NULL DEFAULT '{DEFAULT_PRIORS_LATENCY_TIER}'
                CHECK (latency_tier IN ({latency_tier_checks})),
            timeout_ms INTEGER,
            retrieval_latency_ms INTEGER,
            prior_coverage INTEGER,
            groundedness_total_importance INTEGER,
            groundedness_grounded_importance INTEGER,
            groundedness_guidance_points_json TEXT NOT NULL DEFAULT '[]',
            adherence_status TEXT NOT NULL DEFAULT 'not_requested'
                CHECK (adherence_status IN ('not_requested', 'pending', 'complete', 'failed')),
            prior_adherence INTEGER,
            severity_weighted_prior_adherence INTEGER,
            relevant_prior_count INTEGER,
            followed_relevant_prior_count INTEGER,
            violated_relevant_prior_count INTEGER,
            total_non_adherence_severity INTEGER,
            max_non_adherence_severity INTEGER,
            prior_adherence_items_json TEXT NOT NULL DEFAULT '[]',
            retrieval_status TEXT NOT NULL DEFAULT 'pending'
                CHECK (retrieval_status IN ('pending', 'complete', 'failed')),
            coverage_status TEXT NOT NULL DEFAULT 'not_requested'
                CHECK (coverage_status IN ('not_requested', 'pending', 'complete', 'failed')),
            warning_message TEXT,
            error_message TEXT,
            created_at TIMESTAMP DEFAULT (datetime('now')),
            updated_at TIMESTAMP DEFAULT (datetime('now')),
            FOREIGN KEY (run_id) REFERENCES runs (run_id)
        )
        """
    )
