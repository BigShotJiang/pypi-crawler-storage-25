from .connection import execute, query_all, query_one, transaction


def copy_prior_retrievals_query(old_run_id, new_run_id):
    execute(
        """
        INSERT INTO prior_retrievals (
            retrieval_id, run_id, node_uuid, raw_context, processed_context,
            inherited_prior_ids_json, retrieved_priors_json, applied_priors_json,
            rendered_priors_block, injection_anchor_json, model, latency_tier,
            timeout_ms, retrieval_latency_ms, prior_coverage, retrieval_status,
            coverage_status, warning_message, error_message,
            groundedness_total_importance, groundedness_grounded_importance,
            groundedness_guidance_points_json, adherence_status, prior_adherence,
            severity_weighted_prior_adherence, relevant_prior_count,
            followed_relevant_prior_count, violated_relevant_prior_count,
            total_non_adherence_severity, max_non_adherence_severity,
            prior_adherence_items_json, created_at, updated_at
        )
        SELECT lower(hex(randomblob(16))), ?, node_uuid, raw_context, processed_context,
               inherited_prior_ids_json, retrieved_priors_json, applied_priors_json,
               rendered_priors_block, injection_anchor_json, model, latency_tier,
               timeout_ms, retrieval_latency_ms, prior_coverage, retrieval_status,
               coverage_status, warning_message, error_message,
               groundedness_total_importance, groundedness_grounded_importance,
               groundedness_guidance_points_json, adherence_status, prior_adherence,
               severity_weighted_prior_adherence, relevant_prior_count,
               followed_relevant_prior_count, violated_relevant_prior_count,
               total_non_adherence_severity, max_non_adherence_severity,
               prior_adherence_items_json, created_at, updated_at
        FROM prior_retrievals WHERE run_id=?
        """,
        (new_run_id, old_run_id),
    )


def get_prior_retrieval_by_id_query(retrieval_id):
    return query_one(
        """
        SELECT retrieval_id, run_id, node_uuid, raw_context, processed_context,
               inherited_prior_ids_json, retrieved_priors_json, applied_priors_json,
               rendered_priors_block, injection_anchor_json, model, latency_tier,
               timeout_ms, retrieval_latency_ms, prior_coverage, retrieval_status,
               coverage_status, warning_message, error_message,
               groundedness_total_importance, groundedness_grounded_importance,
               groundedness_guidance_points_json, adherence_status, prior_adherence,
               severity_weighted_prior_adherence, relevant_prior_count,
               followed_relevant_prior_count, violated_relevant_prior_count,
               total_non_adherence_severity, max_non_adherence_severity,
               prior_adherence_items_json, created_at, updated_at
        FROM prior_retrievals
        WHERE retrieval_id=?
        """,
        (retrieval_id,),
    )


def delete_prior_retrieval_by_id_query(retrieval_id):
    execute(
        """
        DELETE FROM prior_retrievals
        WHERE retrieval_id=?
        """,
        (retrieval_id,),
    )


def get_prior_retrieval_query(run_id, node_uuid):
    return query_one(
        """
        SELECT retrieval_id, run_id, node_uuid, raw_context, processed_context,
               inherited_prior_ids_json, retrieved_priors_json, applied_priors_json,
               rendered_priors_block, injection_anchor_json, model, latency_tier,
               timeout_ms, retrieval_latency_ms, prior_coverage, retrieval_status,
               coverage_status, warning_message, error_message,
               groundedness_total_importance, groundedness_grounded_importance,
               groundedness_guidance_points_json, adherence_status, prior_adherence,
               severity_weighted_prior_adherence, relevant_prior_count,
               followed_relevant_prior_count, violated_relevant_prior_count,
               total_non_adherence_severity, max_non_adherence_severity,
               prior_adherence_items_json, created_at, updated_at
        FROM prior_retrievals
        WHERE run_id=? AND node_uuid=?
        ORDER BY updated_at DESC, retrieval_id DESC
        LIMIT 1
        """,
        (run_id, node_uuid),
    )


def get_prior_retrievals_for_run_query(run_id):
    return query_all(
        """
        SELECT retrieval_id, run_id, node_uuid, raw_context, processed_context,
               inherited_prior_ids_json, retrieved_priors_json, applied_priors_json,
               rendered_priors_block, injection_anchor_json, model, latency_tier,
               timeout_ms, retrieval_latency_ms, prior_coverage, retrieval_status,
               coverage_status, warning_message, error_message,
               groundedness_total_importance, groundedness_grounded_importance,
               groundedness_guidance_points_json, adherence_status, prior_adherence,
               severity_weighted_prior_adherence, relevant_prior_count,
               followed_relevant_prior_count, violated_relevant_prior_count,
               total_non_adherence_severity, max_non_adherence_severity,
               prior_adherence_items_json, created_at, updated_at
        FROM prior_retrievals
        WHERE run_id=?
        ORDER BY created_at ASC, node_uuid ASC
        """,
        (run_id,),
    )


def upsert_prior_retrieval_query(
    retrieval_id,
    run_id,
    node_uuid,
    raw_context,
    processed_context,
    inherited_prior_ids_json,
    retrieved_priors_json,
    applied_priors_json,
    rendered_priors_block,
    injection_anchor_json,
    model,
    latency_tier,
    timeout_ms,
    retrieval_latency_ms,
    prior_coverage,
    retrieval_status,
    coverage_status,
    warning_message,
    error_message,
    groundedness_total_importance,
    groundedness_grounded_importance,
    groundedness_guidance_points_json,
    adherence_status,
    prior_adherence,
    severity_weighted_prior_adherence,
    relevant_prior_count,
    followed_relevant_prior_count,
    violated_relevant_prior_count,
    total_non_adherence_severity,
    max_non_adherence_severity,
    prior_adherence_items_json,
):
    execute(
        """
        INSERT INTO prior_retrievals (
            retrieval_id, run_id, node_uuid, raw_context, processed_context,
            inherited_prior_ids_json, retrieved_priors_json, applied_priors_json,
            rendered_priors_block, injection_anchor_json, model, latency_tier,
            timeout_ms, retrieval_latency_ms, prior_coverage, retrieval_status,
            coverage_status, warning_message, error_message,
            groundedness_total_importance, groundedness_grounded_importance,
            groundedness_guidance_points_json, adherence_status, prior_adherence,
            severity_weighted_prior_adherence, relevant_prior_count,
            followed_relevant_prior_count, violated_relevant_prior_count,
            total_non_adherence_severity, max_non_adherence_severity,
            prior_adherence_items_json
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT (retrieval_id)
        DO UPDATE SET
            run_id = excluded.run_id,
            node_uuid = excluded.node_uuid,
            raw_context = excluded.raw_context,
            processed_context = excluded.processed_context,
            inherited_prior_ids_json = excluded.inherited_prior_ids_json,
            retrieved_priors_json = excluded.retrieved_priors_json,
            applied_priors_json = excluded.applied_priors_json,
            rendered_priors_block = excluded.rendered_priors_block,
            injection_anchor_json = excluded.injection_anchor_json,
            model = excluded.model,
            latency_tier = excluded.latency_tier,
            timeout_ms = excluded.timeout_ms,
            retrieval_latency_ms = excluded.retrieval_latency_ms,
            prior_coverage = excluded.prior_coverage,
            retrieval_status = excluded.retrieval_status,
            coverage_status = excluded.coverage_status,
            warning_message = excluded.warning_message,
            error_message = excluded.error_message,
            groundedness_total_importance = excluded.groundedness_total_importance,
            groundedness_grounded_importance = excluded.groundedness_grounded_importance,
            groundedness_guidance_points_json = excluded.groundedness_guidance_points_json,
            adherence_status = excluded.adherence_status,
            prior_adherence = excluded.prior_adherence,
            severity_weighted_prior_adherence = excluded.severity_weighted_prior_adherence,
            relevant_prior_count = excluded.relevant_prior_count,
            followed_relevant_prior_count = excluded.followed_relevant_prior_count,
            violated_relevant_prior_count = excluded.violated_relevant_prior_count,
            total_non_adherence_severity = excluded.total_non_adherence_severity,
            max_non_adherence_severity = excluded.max_non_adherence_severity,
            prior_adherence_items_json = excluded.prior_adherence_items_json,
            updated_at = datetime('now')
        """,
        (
            retrieval_id,
            run_id,
            node_uuid,
            raw_context,
            processed_context,
            inherited_prior_ids_json,
            retrieved_priors_json,
            applied_priors_json,
            rendered_priors_block,
            injection_anchor_json,
            model,
            latency_tier,
            timeout_ms,
            retrieval_latency_ms,
            prior_coverage,
            retrieval_status,
            coverage_status,
            warning_message,
            error_message,
            groundedness_total_importance,
            groundedness_grounded_importance,
            groundedness_guidance_points_json,
            adherence_status,
            prior_adherence,
            severity_weighted_prior_adherence,
            relevant_prior_count,
            followed_relevant_prior_count,
            violated_relevant_prior_count,
            total_non_adherence_severity,
            max_non_adherence_severity,
            prior_adherence_items_json,
        ),
    )


def update_prior_coverage_query(
    retrieval_id,
    prior_coverage,
    coverage_status,
    groundedness_total_importance,
    groundedness_grounded_importance,
    groundedness_guidance_points_json,
):
    execute(
        """
        UPDATE prior_retrievals
        SET prior_coverage=?,
            coverage_status=?,
            groundedness_total_importance=?,
            groundedness_grounded_importance=?,
            groundedness_guidance_points_json=?,
            updated_at=datetime('now')
        WHERE retrieval_id=?
        """,
        (
            prior_coverage,
            coverage_status,
            groundedness_total_importance,
            groundedness_grounded_importance,
            groundedness_guidance_points_json,
            retrieval_id,
        ),
    )


def update_prior_adherence_query(
    retrieval_id,
    adherence_status,
    prior_adherence,
    severity_weighted_prior_adherence,
    relevant_prior_count,
    followed_relevant_prior_count,
    violated_relevant_prior_count,
    total_non_adherence_severity,
    max_non_adherence_severity,
    prior_adherence_items_json,
):
    execute(
        """
        UPDATE prior_retrievals
        SET adherence_status=?,
            prior_adherence=?,
            severity_weighted_prior_adherence=?,
            relevant_prior_count=?,
            followed_relevant_prior_count=?,
            violated_relevant_prior_count=?,
            total_non_adherence_severity=?,
            max_non_adherence_severity=?,
            prior_adherence_items_json=?,
            updated_at=datetime('now')
        WHERE retrieval_id=?
        """,
        (
            adherence_status,
            prior_adherence,
            severity_weighted_prior_adherence,
            relevant_prior_count,
            followed_relevant_prior_count,
            violated_relevant_prior_count,
            total_non_adherence_severity,
            max_non_adherence_severity,
            prior_adherence_items_json,
            retrieval_id,
        ),
    )


def get_pending_prior_coverage_jobs_query(limit):
    return query_all(
        """
        SELECT retrieval_id, run_id, node_uuid, raw_context, processed_context,
               inherited_prior_ids_json, retrieved_priors_json, applied_priors_json,
               rendered_priors_block, injection_anchor_json, model, latency_tier,
               timeout_ms, retrieval_latency_ms, prior_coverage, retrieval_status,
               coverage_status, warning_message, error_message,
               groundedness_total_importance, groundedness_grounded_importance,
               groundedness_guidance_points_json, adherence_status, prior_adherence,
               severity_weighted_prior_adherence, relevant_prior_count,
               followed_relevant_prior_count, violated_relevant_prior_count,
               total_non_adherence_severity, max_non_adherence_severity,
               prior_adherence_items_json, created_at, updated_at
        FROM prior_retrievals
        WHERE coverage_status='pending' OR adherence_status='pending'
        ORDER BY created_at ASC, retrieval_id ASC
        LIMIT ?
        """,
        (limit,),
    )


def get_prior_coverage_cache_query(cache_key):
    return query_one(
        """
        SELECT cache_key, prior_coverage, total_importance,
               grounded_importance, guidance_points_json
        FROM prior_coverage_cache
        WHERE cache_key=?
        """,
        (cache_key,),
    )


def upsert_prior_coverage_cache_query(
    cache_key,
    processed_context_hash,
    llm_output_hash,
    priors_hash,
    judge_model,
    judge_tier,
    reasoning_effort,
    prompt_version,
    prior_coverage,
    total_importance,
    grounded_importance,
    guidance_points_json,
):
    execute(
        """
        INSERT INTO prior_coverage_cache (
            cache_key,
            processed_context_hash,
            llm_output_hash,
            priors_hash,
            judge_model,
            judge_tier,
            reasoning_effort,
            prompt_version,
            prior_coverage,
            total_importance,
            grounded_importance,
            guidance_points_json
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT (cache_key)
        DO UPDATE SET
            prior_coverage=excluded.prior_coverage,
            total_importance=excluded.total_importance,
            grounded_importance=excluded.grounded_importance,
            guidance_points_json=excluded.guidance_points_json,
            updated_at=datetime('now')
        """,
        (
            cache_key,
            processed_context_hash,
            llm_output_hash,
            priors_hash,
            judge_model,
            judge_tier,
            reasoning_effort,
            prompt_version,
            prior_coverage,
            total_importance,
            grounded_importance,
            guidance_points_json,
        ),
    )


def get_prior_adherence_cache_query(cache_key):
    return query_one(
        """
        SELECT cache_key, prior_adherence, severity_weighted_prior_adherence,
               relevant_prior_count, followed_relevant_prior_count,
               violated_relevant_prior_count, total_non_adherence_severity,
               max_non_adherence_severity, prior_adherence_items_json
        FROM prior_adherence_cache
        WHERE cache_key=?
        """,
        (cache_key,),
    )


def upsert_prior_adherence_cache_query(
    cache_key,
    processed_context_hash,
    llm_output_hash,
    priors_hash,
    judge_model,
    judge_tier,
    reasoning_effort,
    prompt_version,
    prior_adherence,
    severity_weighted_prior_adherence,
    relevant_prior_count,
    followed_relevant_prior_count,
    violated_relevant_prior_count,
    total_non_adherence_severity,
    max_non_adherence_severity,
    prior_adherence_items_json,
):
    execute(
        """
        INSERT INTO prior_adherence_cache (
            cache_key,
            processed_context_hash,
            llm_output_hash,
            priors_hash,
            judge_model,
            judge_tier,
            reasoning_effort,
            prompt_version,
            prior_adherence,
            severity_weighted_prior_adherence,
            relevant_prior_count,
            followed_relevant_prior_count,
            violated_relevant_prior_count,
            total_non_adherence_severity,
            max_non_adherence_severity,
            prior_adherence_items_json
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT (cache_key)
        DO UPDATE SET
            prior_adherence=excluded.prior_adherence,
            severity_weighted_prior_adherence=excluded.severity_weighted_prior_adherence,
            relevant_prior_count=excluded.relevant_prior_count,
            followed_relevant_prior_count=excluded.followed_relevant_prior_count,
            violated_relevant_prior_count=excluded.violated_relevant_prior_count,
            total_non_adherence_severity=excluded.total_non_adherence_severity,
            max_non_adherence_severity=excluded.max_non_adherence_severity,
            prior_adherence_items_json=excluded.prior_adherence_items_json,
            updated_at=datetime('now')
        """,
        (
            cache_key,
            processed_context_hash,
            llm_output_hash,
            priors_hash,
            judge_model,
            judge_tier,
            reasoning_effort,
            prompt_version,
            prior_adherence,
            severity_weighted_prior_adherence,
            relevant_prior_count,
            followed_relevant_prior_count,
            violated_relevant_prior_count,
            total_non_adherence_severity,
            max_non_adherence_severity,
            prior_adherence_items_json,
        ),
    )


def get_priors_scope_query(user_id, project_id):
    return query_one(
        """
        SELECT user_id, project_id, revision, updated_at
        FROM priors_scopes
        WHERE user_id=? AND project_id=?
        """,
        (user_id, project_id),
    )


def ensure_priors_scope_query(user_id, project_id, revision, updated_at):
    execute(
        """
        INSERT OR IGNORE INTO priors_scopes (user_id, project_id, revision, updated_at)
        VALUES (?, ?, ?, ?)
        """,
        (user_id, project_id, revision, updated_at),
    )
    return get_priors_scope_query(user_id, project_id)


def bump_priors_scope_revision_query(user_id, project_id, updated_at):
    with transaction() as conn:
        conn.execute(
            """
            INSERT OR IGNORE INTO priors_scopes (user_id, project_id, revision, updated_at)
            VALUES (?, ?, 1, ?)
            """,
            (user_id, project_id, updated_at),
        )
        conn.execute(
            """
            UPDATE priors_scopes
            SET revision=revision+1, updated_at=?
            WHERE user_id=? AND project_id=?
            """,
            (updated_at, user_id, project_id),
        )
        row = conn.execute(
            """
            SELECT user_id, project_id, revision, updated_at
            FROM priors_scopes
            WHERE user_id=? AND project_id=?
            """,
            (user_id, project_id),
        ).fetchone()
        return row


def get_prefix_cache_candidates_query(
    user_id, project_id, base_path, model, first_key, pair_count_limit
):
    return query_all(
        """
        SELECT pair_count, clean_pairs_json, injected_pairs_json, prior_ids_json
        FROM prefix_cache
        WHERE user_id=?
          AND project_id=?
          AND base_path=?
          AND model=?
          AND first_key=?
          AND pair_count<=?
        ORDER BY pair_count DESC
        """,
        (user_id, project_id, base_path, model, first_key, pair_count_limit),
    )


def upsert_prefix_cache_query(
    user_id,
    project_id,
    base_path,
    model,
    first_key,
    pair_count,
    clean_pairs_json,
    injected_pairs_json,
    prior_ids_json,
):
    execute(
        """
        INSERT INTO prefix_cache (
            user_id,
            project_id,
            base_path,
            model,
            first_key,
            pair_count,
            clean_pairs_json,
            injected_pairs_json,
            prior_ids_json
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT (user_id, project_id, base_path, model, clean_pairs_json)
        DO UPDATE SET
            injected_pairs_json=excluded.injected_pairs_json,
            prior_ids_json=excluded.prior_ids_json,
            updated_at=datetime('now')
        """,
        (
            user_id,
            project_id,
            base_path,
            model,
            first_key,
            pair_count,
            clean_pairs_json,
            injected_pairs_json,
            prior_ids_json,
        ),
    )


def clear_scope_prefix_cache_query(user_id, project_id):
    execute("DELETE FROM prefix_cache WHERE user_id=? AND project_id=?", (user_id, project_id))


def clear_all_prefix_cache_query():
    execute("DELETE FROM prefix_cache")


def get_cached_retrieval_query(
    user_id,
    project_id,
    priors_revision,
    base_path,
    model,
    context_hash,
    ignore_prior_ids_json,
):
    return query_one(
        """
        SELECT response_json
        FROM retrieval_cache
        WHERE user_id=?
          AND project_id=?
          AND priors_revision=?
          AND base_path=?
          AND model=?
          AND context_hash=?
          AND ignore_prior_ids_json=?
        """,
        (
            user_id,
            project_id,
            priors_revision,
            base_path,
            model,
            context_hash,
            ignore_prior_ids_json,
        ),
    )


def upsert_retrieval_cache_query(
    user_id,
    project_id,
    priors_revision,
    base_path,
    model,
    context_hash,
    ignore_prior_ids_json,
    response_json,
):
    execute(
        """
        INSERT INTO retrieval_cache (
            user_id,
            project_id,
            priors_revision,
            base_path,
            model,
            context_hash,
            ignore_prior_ids_json,
            response_json
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT (
            user_id,
            project_id,
            priors_revision,
            base_path,
            model,
            context_hash,
            ignore_prior_ids_json
        )
        DO UPDATE SET
            response_json=excluded.response_json,
            updated_at=datetime('now')
        """,
        (
            user_id,
            project_id,
            priors_revision,
            base_path,
            model,
            context_hash,
            ignore_prior_ids_json,
            response_json,
        ),
    )


def clear_all_retrieval_cache_query():
    execute("DELETE FROM retrieval_cache")


def get_priors_applied_for_run_query(run_id):
    return query_all(
        """
        SELECT pa.prior_id, pa.run_id, pa.node_uuid, e.name as name
        FROM priors_applied pa
        LEFT JOIN runs e ON pa.run_id = e.run_id
        WHERE pa.run_id = ?
        ORDER BY pa.applied_at DESC
        """,
        (run_id,),
    )


def get_priors_applied_query(prior_id):
    return query_all(
        """
        SELECT pa.run_id, pa.node_uuid, e.name as name
        FROM priors_applied pa
        LEFT JOIN runs e ON pa.run_id = e.run_id
        WHERE pa.prior_id = ?
        ORDER BY pa.applied_at DESC
        """,
        (prior_id,),
    )


def add_prior_applied_query(prior_id, run_id, node_uuid=None):
    execute(
        """
        INSERT OR IGNORE INTO priors_applied (prior_id, run_id, node_uuid)
        VALUES (?, ?, ?)
        """,
        (prior_id, run_id, node_uuid),
    )


def remove_prior_applied_query(prior_id, run_id, node_uuid=None):
    if node_uuid:
        execute(
            "DELETE FROM priors_applied WHERE prior_id = ? AND run_id = ? AND node_uuid = ?",
            (prior_id, run_id, node_uuid),
        )
    else:
        execute(
            "DELETE FROM priors_applied WHERE prior_id = ? AND run_id = ? AND node_uuid IS NULL",
            (prior_id, run_id),
        )


def delete_priors_applied_for_prior_query(prior_id):
    execute("DELETE FROM priors_applied WHERE prior_id = ?", (prior_id,))
