from .connection import execute, query_all, query_one
import json as _json


def _extract_tokens_from_output_json(output_json_str: str) -> tuple[int | None, int | None]:
    """Extract (input_tokens, output_tokens) from a serialized LLM response JSON.

    Handles non-streaming (content.usage) and SSE streaming (sse.events) for
    OpenAI-compatible, Anthropic, and Gemini response formats.
    Returns (None, None) on any parse failure or when usage data is absent.
    """
    try:
        out = _json.loads(output_json_str)
    except Exception:
        return None, None

    def _extract_from_usage(usage: dict) -> tuple[int | None, int | None]:
        """Read tokens from an OpenAI, Anthropic, or Gemini usage dict."""
        if not isinstance(usage, dict):
            return None, None
        # OpenAI-compatible
        inp = usage.get("prompt_tokens")
        out_ = usage.get("completion_tokens")
        if inp is not None or out_ is not None:
            return _to_int(inp), _to_int(out_)
        # Anthropic
        inp = usage.get("input_tokens")
        out_ = usage.get("output_tokens")
        if inp is not None or out_ is not None:
            return _to_int(inp), _to_int(out_)
        # Gemini
        inp = usage.get("promptTokenCount")
        out_ = usage.get("candidatesTokenCount")
        if inp is not None or out_ is not None:
            return _to_int(inp), _to_int(out_)
        return None, None

    def _to_int(v) -> int | None:
        try:
            return int(v) if v is not None else None
        except (TypeError, ValueError):
            return None

    # ── Non-streaming ─────────────────────────────────────────────────────────
    # Stored format: {"raw": {"_obj_str": "...", "content": {...response...}}, "to_show": {...}}
    raw = out.get("raw")
    if not isinstance(raw, dict):
        return None, None

    content = raw.get("content")
    if isinstance(content, dict):
        # OpenAI / Anthropic
        usage = content.get("usage")
        if isinstance(usage, dict):
            inp, outp = _extract_from_usage(usage)
            if inp is not None or outp is not None:
                return inp, outp
        # Gemini
        usage = content.get("usageMetadata")
        if isinstance(usage, dict):
            inp, outp = _extract_from_usage(usage)
            if inp is not None or outp is not None:
                return inp, outp

    # ── SSE streaming ────────────────────────────────────────────────────────────
    sse = raw.get("sse")
    if isinstance(sse, dict):
        events = sse.get("events", [])
        inp_acc, outp_acc = None, None
        for event in events:
            data = event.get("data") if isinstance(event, dict) else None
            if not isinstance(data, dict):
                continue
            # Anthropic SSE: message_start contains input_tokens
            if data.get("type") == "message_start":
                message = data.get("message", {})
                usage = message.get("usage", {})
                i, _ = _extract_from_usage(usage)
                if i is not None:
                    inp_acc = (inp_acc or 0) + i
            # Anthropic SSE: message_delta contains output_tokens
            elif data.get("type") == "message_delta":
                usage = data.get("usage", {})
                _, o = _extract_from_usage(usage)
                if o is not None:
                    outp_acc = (outp_acc or 0) + o
            # OpenAI SSE: last chunk with usage (stream_options.include_usage)
            else:
                usage = data.get("usage")
                if isinstance(usage, dict):
                    i, o = _extract_from_usage(usage)
                    if i is not None:
                        inp_acc = i  # last wins (OpenAI sends full cumulative count)
                    if o is not None:
                        outp_acc = o
        if inp_acc is not None or outp_acc is not None:
            return inp_acc, outp_acc

    return None, None


def set_input_overwrite_query(input_overwrite, run_id, node_uuid):
    execute(
        "UPDATE llm_calls SET input_overwrite=? WHERE run_id=? AND node_uuid=?",
        (input_overwrite, run_id, node_uuid),
    )


def set_output_overwrite_query(output_overwrite, run_id, node_uuid):
    execute(
        "UPDATE llm_calls SET output_overwrite=? WHERE run_id=? AND node_uuid=?",
        (output_overwrite, run_id, node_uuid),
    )


def clear_input_overwrite_query(run_id, node_uuid):
    execute(
        "UPDATE llm_calls SET input_overwrite=NULL WHERE run_id=? AND node_uuid=?",
        (run_id, node_uuid),
    )


def clear_output_overwrite_query(run_id, node_uuid):
    execute(
        "UPDATE llm_calls SET output_overwrite=NULL WHERE run_id=? AND node_uuid=?",
        (run_id, node_uuid),
    )


def delete_llm_calls_query(run_id):
    execute("DELETE FROM prior_retrievals WHERE run_id=?", (run_id,))
    execute("DELETE FROM llm_calls WHERE run_id=?", (run_id,))


def get_subrun_by_parent_and_name_query(parent_run_id, name):
    return query_one(
        "SELECT run_id FROM runs WHERE parent_run_id = ? AND name = ?",
        (parent_run_id, name),
    )


def get_parent_run_id_query(run_id):
    return query_one("SELECT parent_run_id FROM runs WHERE run_id=?", (run_id,))


def get_llm_call_by_run_and_hash_query(run_id, input_hash, offset=0):
    return query_one(
        """
        SELECT node_uuid, input, input_overwrite, output, output_overwrite, status, latency_seconds, error
        FROM llm_calls
        WHERE run_id=? AND input_hash=?
        ORDER BY rowid
        LIMIT 1 OFFSET ?
        """,
        (run_id, input_hash, offset),
    )


def insert_llm_call_with_output_query(
    run_id,
    input_pickle,
    input_hash,
    node_uuid,
    api_type,
    output_pickle,
    stack_trace=None,
    node_kind=None,
    prompt_suffix_json="[]",
):
    execute(
        """
        INSERT INTO llm_calls (
            run_id, input, input_hash, node_uuid, api_type, output, stack_trace, node_kind,
            prompt_suffix_json, output_overwrite, status, latency_seconds, error
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, 'success', NULL, NULL)
        ON CONFLICT (run_id, node_uuid)
        DO UPDATE SET
            input = excluded.input,
            input_hash = excluded.input_hash,
            output = excluded.output,
            output_overwrite = NULL,
            stack_trace = excluded.stack_trace,
            node_kind = COALESCE(excluded.node_kind, llm_calls.node_kind),
            prompt_suffix_json = excluded.prompt_suffix_json,
            status = 'success',
            error = NULL
        """,
        (
            run_id,
            input_pickle,
            input_hash,
            node_uuid,
            api_type,
            output_pickle,
            stack_trace,
            node_kind,
            prompt_suffix_json,
        ),
    )


def copy_llm_calls_query(old_run_id, new_run_id):
    execute(
        """
        INSERT INTO llm_calls (
            run_id,
            node_uuid,
            input,
            input_hash,
            input_overwrite,
            output,
            output_overwrite,
            color,
            label,
            api_type,
            node_kind,
            prompt_suffix_json,
            stack_trace,
            status,
            latency_seconds,
            error,
            llm_verdict,
            timestamp
        )
        SELECT ?, node_uuid, input, input_hash, input_overwrite, output, output_overwrite, color, label, api_type,
               node_kind, prompt_suffix_json, stack_trace, status, latency_seconds, error, llm_verdict, timestamp
        FROM llm_calls WHERE run_id=?
        """,
        (new_run_id, old_run_id),
    )


def delete_all_llm_calls_query():
    execute("DELETE FROM prior_retrievals")
    execute("DELETE FROM llm_calls")


def find_node_uuids_by_prefix_query(run_id, node_uuid_prefix):
    return query_all(
        """
        SELECT node_uuid
        FROM llm_calls
        WHERE run_id=? AND REPLACE(LOWER(node_uuid), '-', '') LIKE ?
        ORDER BY rowid
        """,
        (run_id, f"{node_uuid_prefix.lower()}%",),
    )


def get_llm_call_input_api_type_query(run_id, node_uuid):
    return query_one(
        "SELECT input, api_type, input_overwrite FROM llm_calls WHERE run_id=? AND node_uuid=?",
        (run_id, node_uuid),
    )


def get_llm_call_output_api_type_query(run_id, node_uuid):
    return query_one(
        "SELECT output, output_overwrite, api_type FROM llm_calls WHERE run_id=? AND node_uuid=?",
        (run_id, node_uuid),
    )


def get_llm_calls_for_run_query(run_id):
    return query_all(
        """
        SELECT node_uuid, input, input_overwrite, output, output_overwrite, api_type, node_kind,
               prompt_suffix_json, label, timestamp, status, latency_seconds, error, llm_verdict
        FROM llm_calls
        WHERE run_id=?
        ORDER BY rowid
        """,
        (run_id,),
    )


def get_llm_call_full_query(run_id, node_uuid):
    return query_one(
        """
        SELECT node_uuid, input, input_hash, input_overwrite, output, output_overwrite, api_type, node_kind,
               prompt_suffix_json, label, timestamp, stack_trace, status, latency_seconds, error, llm_verdict
        FROM llm_calls
        WHERE run_id=? AND node_uuid=?
        """,
        (run_id, node_uuid),
    )


def begin_llm_call_query(
    run_id,
    input_pickle,
    input_hash,
    node_uuid,
    api_type,
    stack_trace=None,
    node_kind=None,
    prompt_suffix_json="[]",
):
    execute(
        """
        INSERT INTO llm_calls (
            run_id, node_uuid, input, input_hash, api_type, stack_trace, node_kind,
            prompt_suffix_json, status, error
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'in_flight', NULL)
        """,
        (
            run_id,
            node_uuid,
            input_pickle,
            input_hash,
            api_type,
            stack_trace,
            node_kind,
            prompt_suffix_json,
        ),
    )


def mark_llm_call_in_flight_query(run_id, node_uuid):
    execute(
        """
        UPDATE llm_calls
        SET status='in_flight',
            error=NULL,
            latency_seconds=NULL
        WHERE run_id=? AND node_uuid=?
        """,
        (run_id, node_uuid),
    )


def finalize_llm_call_query(
    run_id,
    node_uuid,
    *,
    input_pickle=None,
    input_hash=None,
    output_json=None,
    status,
    latency_seconds=None,
    error_json=None,
    stack_trace=None,
    node_kind=None,
    prompt_suffix_json=None,
    consume_edit_field=None,
    clear_output=False,
):
    updates = [
        "status=?",
        "error=?",
    ]
    params = [status, error_json]

    if input_pickle is not None:
        updates.append("input=?")
        params.append(input_pickle)
    if input_hash is not None:
        updates.append("input_hash=?")
        params.append(input_hash)
    if output_json is not None:
        updates.append("output=?")
        params.append(output_json)
        _in_tok, _out_tok = _extract_tokens_from_output_json(output_json)
        if _in_tok is not None:
            updates.append("input_tokens=?")
            params.append(_in_tok)
        if _out_tok is not None:
            updates.append("output_tokens=?")
            params.append(_out_tok)
    elif clear_output:
        updates.append("output=NULL")
    if latency_seconds is not None:
        updates.append("latency_seconds=?")
        params.append(latency_seconds)
    if stack_trace is not None:
        updates.append("stack_trace=?")
        params.append(stack_trace)
    if node_kind is not None:
        updates.append("node_kind=?")
        params.append(node_kind)
    if prompt_suffix_json is not None:
        updates.append("prompt_suffix_json=?")
        params.append(prompt_suffix_json)
    if consume_edit_field == "input":
        updates.append("input_overwrite=NULL")
    if consume_edit_field == "output":
        updates.append("output_overwrite=NULL")

    params.extend([run_id, node_uuid])
    execute(
        f"UPDATE llm_calls SET {', '.join(updates)} WHERE run_id=? AND node_uuid=?",
        tuple(params),
    )


def set_llm_verdict_query(run_id, node_uuid, llm_verdict):
    execute(
        "UPDATE llm_calls SET llm_verdict=? WHERE run_id=? AND node_uuid=?",
        (llm_verdict, run_id, node_uuid),
    )


def get_tokens_timeseries_query(project_id, time_from, time_to, bucket_seconds, user_id=None):
    """Return summed input/output tokens bucketed by time interval.

    Each row has:
      bucket_start   TEXT  – ISO-8601 datetime of the bucket's start (UTC)
      input_tokens   INT   – total input tokens across top-level runs in that bucket
      output_tokens  INT   – total output tokens across top-level runs in that bucket

    Only llm_calls rows where both input_tokens and output_tokens are non-NULL are
    counted, joined to top-level runs (parent_run_id = run_id) for the given project.
    """
    conditions = [
        "r.project_id = ?",
        "r.parent_run_id = r.run_id",
        "r.timestamp >= ?",
        "r.timestamp <= ?",
        "lc.input_tokens IS NOT NULL",
        "lc.output_tokens IS NOT NULL",
        "lc.node_kind = 'llm'",
    ]
    where_params: list = [project_id, time_from, time_to]
    if user_id:
        conditions.append("r.user_id = ?")
        where_params.append(user_id)
    where = " AND ".join(conditions)
    sql = f"""
        SELECT
            datetime(
                CAST(strftime('%s', r.timestamp) / ? AS INTEGER) * ?,
                'unixepoch'
            ) AS bucket_start,
            SUM(lc.input_tokens)  AS input_tokens,
            SUM(lc.output_tokens) AS output_tokens
        FROM llm_calls lc
        JOIN runs r ON r.run_id = lc.run_id
        WHERE {where}
        GROUP BY CAST(strftime('%s', r.timestamp) / ? AS INTEGER)
        ORDER BY bucket_start ASC
    """
    params = (bucket_seconds, bucket_seconds) + tuple(where_params) + (bucket_seconds,)
    return query_all(sql, params)
