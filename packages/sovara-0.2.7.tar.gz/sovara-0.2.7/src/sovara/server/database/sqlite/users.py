from sovara.server.llm_settings import TIER_DB_FIELD_NAMES, USER_LLM_DB_COLUMNS, USER_LLM_TIERS

from .connection import execute, query_all, query_one


USER_LLM_SELECT_COLUMNS = [
    USER_LLM_DB_COLUMNS[tier][field]
    for tier in USER_LLM_TIERS
    for field in TIER_DB_FIELD_NAMES
]


def upsert_user_query(user_id, full_name, email):
    execute(
        "INSERT OR IGNORE INTO users (user_id, full_name, email) VALUES (?, ?, ?)",
        (user_id, full_name, email),
    )
    execute(
        "UPDATE users SET full_name=?, email=? WHERE user_id=?",
        (full_name, email, user_id),
    )


def get_user_query(user_id):
    select_columns = ",\n            ".join(["user_id", "full_name", "email", *USER_LLM_SELECT_COLUMNS])
    return query_one(
        f"""
        SELECT
            {select_columns}
        FROM users
        WHERE user_id=?
        """,
        (user_id,),
    )


def update_user_llm_settings_query(user_id, llm_settings):
    assignments = ",\n            ".join(f"{column}=?" for column in USER_LLM_SELECT_COLUMNS)
    execute(
        f"""
        UPDATE users
        SET {assignments}
        WHERE user_id=?
        """,
        (
            *(llm_settings[column] for column in USER_LLM_SELECT_COLUMNS),
            user_id,
        ),
    )


def delete_user_query(user_id):
    from .projects import delete_project_query
    from .runs import _delete_runs_data

    project_ids = [
        row["project_id"]
        for row in query_all(
            "SELECT DISTINCT project_id FROM user_project_locations WHERE user_id=?",
            (user_id,),
        )
    ]
    project_users: dict[str, set[str]] = {}
    for project_id in project_ids:
        rows = query_all(
            "SELECT DISTINCT user_id FROM user_project_locations WHERE project_id=?",
            (project_id,),
        )
        project_users[project_id] = {row["user_id"] for row in rows}
    for project_id, users in project_users.items():
        if users == {user_id}:
            delete_project_query(project_id)

    runs = query_all("SELECT run_id FROM runs WHERE user_id=?", (user_id,))
    _delete_runs_data([run["run_id"] for run in runs])
    execute("DELETE FROM priors_scopes WHERE user_id=?", (user_id,))
    execute("DELETE FROM user_project_locations WHERE user_id=?", (user_id,))
    execute("DELETE FROM users WHERE user_id=?", (user_id,))
