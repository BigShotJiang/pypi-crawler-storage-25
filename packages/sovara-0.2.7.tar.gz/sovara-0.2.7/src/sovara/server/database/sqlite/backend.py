"""SQLiteBackend – wraps all sqlite/*_query module-level functions into a single
class that satisfies the ``DatabaseBackend`` protocol.

No existing sqlite/*_query functions are modified.  This class is a thin
delegation layer only.
"""

from __future__ import annotations

from typing import Any

from sovara.server.database.backend_protocol import DatabaseBackend
from sovara.server.priors_backend.constants import (
    DEFAULT_PRIORS_LATENCY_TIER,
    DEFAULT_PRIORS_TRACK_ADHERENCE,
    DEFAULT_PRIORS_TRACK_GROUNDEDNESS,
)

# Import the underlying module-level query functions from each SQLite module.
from . import llm_calls as _lc
from . import priors as _pr
from . import projects as _pj
from . import runs as _ru
from . import users as _us


class SQLiteBackend:
    """Concrete backend implementation backed by SQLite."""

    # ──────────────────────────────────────────────────────────────────────────
    # Users
    # ──────────────────────────────────────────────────────────────────────────

    def upsert_user_query(self, user_id: str, full_name: str, email: str) -> None:
        _us.upsert_user_query(user_id, full_name, email)

    def get_user_query(self, user_id: str) -> dict[str, Any] | None:
        return _us.get_user_query(user_id)

    def update_user_llm_settings_query(
        self, user_id: str, llm_settings: dict[str, Any]
    ) -> None:
        _us.update_user_llm_settings_query(user_id, llm_settings)

    def delete_user_query(self, user_id: str) -> None:
        _us.delete_user_query(user_id)

    # ──────────────────────────────────────────────────────────────────────────
    # Projects
    # ──────────────────────────────────────────────────────────────────────────

    def upsert_project_query(
        self,
        project_id: str,
        name: str,
        description: str | None,
        priors_latency_tier: str | None = None,
        priors_track_groundedness: bool | None = None,
        priors_track_adherence: bool | None = None,
    ) -> None:
        _pj.upsert_project_query(
            project_id,
            name,
            description,
            priors_latency_tier or DEFAULT_PRIORS_LATENCY_TIER,
            (
                priors_track_groundedness
                if priors_track_groundedness is not None
                else DEFAULT_PRIORS_TRACK_GROUNDEDNESS
            ),
            (
                priors_track_adherence
                if priors_track_adherence is not None
                else DEFAULT_PRIORS_TRACK_ADHERENCE
            ),
        )

    def get_project_query(self, project_id: str) -> dict[str, Any] | None:
        return _pj.get_project_query(project_id)

    def get_all_projects_query(
        self, user_id: str | None = None
    ) -> list[dict[str, Any]]:
        return _pj.get_all_projects_query(user_id=user_id)

    def update_project_last_run_at_query(self, project_id: str) -> None:
        _pj.update_project_last_run_at_query(project_id)

    def get_project_user_count_query(self, project_id: str) -> int:
        return _pj.get_project_user_count_query(project_id)

    def get_project_tag_count_query(self, project_id: str) -> int:
        return _pj.get_project_tag_count_query(project_id)

    def get_run_tag_count_query(self, run_id: str) -> int:
        return _pj.get_run_tag_count_query(run_id)

    def delete_project_query(self, project_id: str) -> None:
        _pj.delete_project_query(project_id)

    # Project locations

    def upsert_project_location_query(
        self, user_id: str, project_id: str, project_location: str
    ) -> None:
        _pj.upsert_project_location_query(user_id, project_id, project_location)

    def get_project_at_location_query(
        self, user_id: str, project_location: str
    ) -> list[dict[str, Any]]:
        return _pj.get_project_at_location_query(user_id, project_location)

    def get_user_project_locations_query(
        self, user_id: str
    ) -> list[dict[str, Any]]:
        return _pj.get_user_project_locations_query(user_id)

    def get_project_locations_query(
        self, user_id: str, project_id: str
    ) -> list[dict[str, Any]]:
        return _pj.get_project_locations_query(user_id, project_id)

    def get_all_project_locations_query(
        self, project_id: str
    ) -> list[dict[str, Any]]:
        return _pj.get_all_project_locations_query(project_id)

    def delete_project_location_query(
        self, user_id: str, project_id: str, project_location: str
    ) -> None:
        _pj.delete_project_location_query(user_id, project_id, project_location)

    # Tags

    def get_project_tags_query(self, project_id: str) -> list[dict[str, Any]]:
        return _pj.get_project_tags_query(project_id)

    def get_project_tag_query(self, tag_id: str) -> dict[str, Any] | None:
        return _pj.get_project_tag_query(tag_id)

    def get_project_tag_by_name_query(
        self, project_id: str, name: str
    ) -> dict[str, Any] | None:
        return _pj.get_project_tag_by_name_query(project_id, name)

    def get_project_tags_by_ids_query(
        self, project_id: str, tag_ids: list[str]
    ) -> list[dict[str, Any]]:
        return _pj.get_project_tags_by_ids_query(project_id, tag_ids)

    def insert_project_tag_query(
        self, tag_id: str, project_id: str, name: str, color: str
    ) -> None:
        _pj.insert_project_tag_query(tag_id, project_id, name, color)

    def delete_project_tag_query(self, project_id: str, tag_id: str) -> None:
        _pj.delete_project_tag_query(project_id, tag_id)

    def get_tags_for_runs_query(
        self, run_ids: list[str]
    ) -> list[dict[str, Any]]:
        return _pj.get_tags_for_runs_query(run_ids)

    def replace_run_tags_query(self, run_id: str, tag_ids: list[str]) -> None:
        _pj.replace_run_tags_query(run_id, tag_ids)

    # Metric kinds

    def get_project_metric_kinds_query(
        self, project_id: str
    ) -> list[dict[str, Any]]:
        return _pj.get_project_metric_kinds_query(project_id)

    def get_project_custom_metric_columns_query(
        self, project_id: str
    ) -> list[dict[str, Any]]:
        return _pj.get_project_custom_metric_columns_query(project_id)

    def upsert_project_metric_kind_query(
        self, project_id: str, metric_key: str, metric_kind: str
    ) -> None:
        _pj.upsert_project_metric_kind_query(project_id, metric_key, metric_kind)

    # ──────────────────────────────────────────────────────────────────────────
    # Runs
    # ──────────────────────────────────────────────────────────────────────────

    def add_run_query(
        self,
        run_id: str,
        parent_run_id: str,
        name: str | None,
        default_graph: str,
        timestamp: str | None,
        cwd: str | None,
        command: str | None,
        env_json: str,
        default_note: str,
        default_log: str,
        version_date: str | None,
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> None:
        _ru.add_run_query(
            run_id,
            parent_run_id,
            name,
            default_graph,
            timestamp,
            cwd,
            command,
            env_json,
            default_note,
            default_log,
            version_date,
            project_id,
            user_id,
        )

    def update_run_graph_topology_query(self, graph_json: str, run_id: str) -> None:
        _ru.update_run_graph_topology_query(graph_json, run_id)

    def get_run_active_edit_query(self, run_id: str) -> dict[str, Any] | None:
        return _ru.get_run_active_edit_query(run_id)

    def set_run_active_edit_query(
        self,
        node_uuid: str,
        node_label: str,
        field: str,
        status: str,
        run_id: str,
    ) -> None:
        _ru.set_run_active_edit_query(node_uuid, node_label, field, status, run_id)

    def update_run_active_edit_status_query(self, status: str, run_id: str) -> None:
        _ru.update_run_active_edit_status_query(status, run_id)

    def clear_run_active_edit_query(self, run_id: str) -> None:
        _ru.clear_run_active_edit_query(run_id)

    def update_run_timestamp_query(self, timestamp: str, run_id: str) -> None:
        _ru.update_run_timestamp_query(timestamp, run_id)

    def update_run_runtime_seconds_query(
        self, runtime_seconds: float | None, run_id: str
    ) -> None:
        _ru.update_run_runtime_seconds_query(runtime_seconds, run_id)

    def update_run_active_runtime_seconds_query(
        self, active_runtime_seconds: float | None, run_id: str
    ) -> None:
        _ru.update_run_active_runtime_seconds_query(active_runtime_seconds, run_id)

    def finalize_run_runtime_query(self, runtime_seconds: float, run_id: str) -> None:
        _ru.finalize_run_runtime_query(runtime_seconds, run_id)

    def clear_run_active_runtime_seconds_query(self, run_id: str) -> None:
        _ru.clear_run_active_runtime_seconds_query(run_id)

    def update_run_name_query(self, name: str, run_id: str) -> None:
        _ru.update_run_name_query(name, run_id)

    def update_run_notes_query(self, notes: str, run_id: str) -> None:
        _ru.update_run_notes_query(notes, run_id)

    def set_run_log_query(self, log_text: str, run_id: str) -> None:
        _ru.set_run_log_query(log_text, run_id)

    def append_run_log_query(self, log_chunk: str, run_id: str) -> None:
        _ru.append_run_log_query(log_chunk, run_id)

    def get_run_log_query(self, run_id: str) -> dict[str, Any] | None:
        return _ru.get_run_log_query(run_id)

    def get_run_trace_chat_history_query(
        self, run_id: str
    ) -> dict[str, Any] | None:
        return _ru.get_run_trace_chat_history_query(run_id)

    def get_run_scope_query(self, run_id: str) -> dict[str, Any] | None:
        return _ru.get_run_scope_query(run_id)

    def update_run_trace_chat_history_query(
        self, trace_chat_history: str, run_id: str
    ) -> None:
        _ru.update_run_trace_chat_history_query(trace_chat_history, run_id)

    def update_run_command_query(self, command: str, run_id: str) -> None:
        _ru.update_run_command_query(command, run_id)

    def update_run_version_date_query(
        self, version_date: str | None, run_id: str
    ) -> None:
        _ru.update_run_version_date_query(version_date, run_id)

    def update_run_log_query(
        self, updated_log: str, graph_json: str, run_id: str
    ) -> None:
        _ru.update_run_log_query(updated_log, graph_json, run_id)

    def update_run_custom_metrics_query(
        self, custom_metrics_json: str, run_id: str
    ) -> None:
        _ru.update_run_custom_metrics_query(custom_metrics_json, run_id)

    def persist_run_metrics_query(
        self,
        run_id: str,
        custom_metrics_json: str,
        metric_rows: list[tuple],
        project_metric_kind_rows: tuple | list = (),
    ) -> None:
        _ru.persist_run_metrics_query(
            run_id, custom_metrics_json, metric_rows, project_metric_kind_rows
        )

    def update_run_thumb_label_query(
        self, thumb_label: int | None, run_id: str
    ) -> None:
        _ru.update_run_thumb_label_query(thumb_label, run_id)

    def get_run_metrics_context_query(
        self, run_id: str
    ) -> dict[str, Any] | None:
        return _ru.get_run_metrics_context_query(run_id)

    def get_run_tag_context_query(self, run_id: str) -> dict[str, Any] | None:
        return _ru.get_run_tag_context_query(run_id)

    def get_runs_timeseries_query(
        self,
        project_id: str,
        time_from: str,
        time_to: str,
        bucket_seconds: int,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        return _ru.get_runs_timeseries_query(
            project_id, time_from, time_to, bucket_seconds, user_id=user_id
        )

    def get_duration_timeseries_query(
        self,
        project_id: str,
        time_from: str,
        time_to: str,
        bucket_seconds: int,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        return _ru.get_duration_timeseries_query(
            project_id, time_from, time_to, bucket_seconds, user_id=user_id
        )

    def get_finished_runs_query(
        self, project_id: str | None = None, user_id: str | None = None
    ) -> list[dict[str, Any]]:
        return _ru.get_finished_runs_query(project_id=project_id, user_id=user_id)

    def get_all_runs_sorted_query(
        self,
        limit: int | None = None,
        offset: int = 0,
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        return _ru.get_all_runs_sorted_query(
            limit=limit, offset=offset, project_id=project_id, user_id=user_id
        )

    def get_runs_by_ids_query(
        self,
        run_ids: list[str],
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        return _ru.get_runs_by_ids_query(
            run_ids, project_id=project_id, user_id=user_id
        )

    def get_runs_excluding_ids_query(
        self,
        run_ids: list[str],
        limit: int | None = None,
        offset: int = 0,
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        return _ru.get_runs_excluding_ids_query(
            run_ids, limit=limit, offset=offset, project_id=project_id, user_id=user_id
        )

    def get_run_count_query(
        self, project_id: str | None = None, user_id: str | None = None
    ) -> int:
        return _ru.get_run_count_query(project_id=project_id, user_id=user_id)

    def get_run_count_excluding_ids_query(
        self,
        run_ids: list[str],
        project_id: str | None = None,
        user_id: str | None = None,
    ) -> int:
        return _ru.get_run_count_excluding_ids_query(
            run_ids, project_id=project_id, user_id=user_id
        )

    def query_runs_filtered(
        self,
        project_id: str,
        exclude_ids: list[str],
        filters: dict[str, Any],
        sort_col: str,
        sort_dir: str,
        limit: int,
        offset: int,
        user_id: str | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        return _ru.query_runs_filtered(
            project_id,
            exclude_ids,
            filters,
            sort_col,
            sort_dir,
            limit,
            offset,
            user_id=user_id,
        )

    def get_distinct_versions_query(
        self, project_id: str | None = None, user_id: str | None = None
    ) -> list[dict[str, Any]]:
        return _ru.get_distinct_versions_query(project_id, user_id=user_id)

    def get_run_detail_query(self, run_id: str) -> dict[str, Any] | None:
        return _ru.get_run_detail_query(run_id)

    def get_run_graph_topology_query(self, run_id: str) -> dict[str, Any] | None:
        return _ru.get_run_graph_topology_query(run_id)

    def get_run_environment_query(
        self, parent_run_id: str
    ) -> dict[str, Any] | None:
        return _ru.get_run_environment_query(parent_run_id)

    def get_run_exec_info_query(self, run_id: str) -> dict[str, Any] | None:
        return _ru.get_run_exec_info_query(run_id)

    def delete_all_runs_query(self) -> None:
        _ru.delete_all_runs_query()

    def delete_runs_by_ids_query(
        self, run_ids: list[str], user_id: str | None = None
    ) -> Any:
        return _ru.delete_runs_by_ids_query(run_ids, user_id=user_id)

    def get_run_name_query(self, run_id: str) -> dict[str, Any] | None:
        return _ru.get_run_name_query(run_id)

    def find_run_ids_by_prefix_query(
        self, run_id_prefix: str
    ) -> list[dict[str, Any]]:
        return _ru.find_run_ids_by_prefix_query(run_id_prefix)

    def get_run_log_success_graph_query(
        self, run_id: str
    ) -> dict[str, Any] | None:
        return _ru.get_run_log_success_graph_query(run_id)

    def get_next_run_index_query(
        self, project_id: str | None = None, user_id: str | None = None
    ) -> int:
        return _ru.get_next_run_index_query(project_id=project_id, user_id=user_id)

    def get_run_metadata_query(self, run_id: str) -> dict[str, Any] | None:
        return _ru.get_run_metadata_query(run_id)

    # ──────────────────────────────────────────────────────────────────────────
    # LLM calls
    # ──────────────────────────────────────────────────────────────────────────

    def set_input_overwrite_query(
        self, input_overwrite: str, run_id: str, node_uuid: str
    ) -> None:
        _lc.set_input_overwrite_query(input_overwrite, run_id, node_uuid)

    def set_output_overwrite_query(
        self, output_overwrite: str, run_id: str, node_uuid: str
    ) -> None:
        _lc.set_output_overwrite_query(output_overwrite, run_id, node_uuid)

    def clear_input_overwrite_query(self, run_id: str, node_uuid: str) -> None:
        _lc.clear_input_overwrite_query(run_id, node_uuid)

    def clear_output_overwrite_query(self, run_id: str, node_uuid: str) -> None:
        _lc.clear_output_overwrite_query(run_id, node_uuid)

    def delete_llm_calls_query(self, run_id: str) -> None:
        _lc.delete_llm_calls_query(run_id)

    def delete_all_llm_calls_query(self) -> None:
        _lc.delete_all_llm_calls_query()

    def get_subrun_by_parent_and_name_query(
        self, parent_run_id: str, name: str
    ) -> dict[str, Any] | None:
        return _lc.get_subrun_by_parent_and_name_query(parent_run_id, name)

    def get_parent_run_id_query(self, run_id: str) -> dict[str, Any] | None:
        return _lc.get_parent_run_id_query(run_id)

    def get_llm_call_by_run_and_hash_query(
        self, run_id: str, input_hash: str, offset: int = 0
    ) -> dict[str, Any] | None:
        return _lc.get_llm_call_by_run_and_hash_query(run_id, input_hash, offset=offset)

    def insert_llm_call_with_output_query(
        self,
        run_id: str,
        input_pickle: str,
        input_hash: str,
        node_uuid: str,
        api_type: str,
        output_pickle: str,
        stack_trace: str | None = None,
        node_kind: str | None = None,
        prompt_suffix_json: str = "[]",
    ) -> None:
        _lc.insert_llm_call_with_output_query(
            run_id,
            input_pickle,
            input_hash,
            node_uuid,
            api_type,
            output_pickle,
            stack_trace,
            node_kind,
            prompt_suffix_json,
        )

    def copy_llm_calls_query(self, old_run_id: str, new_run_id: str) -> None:
        _lc.copy_llm_calls_query(old_run_id, new_run_id)

    def find_node_uuids_by_prefix_query(
        self, run_id: str, node_uuid_prefix: str
    ) -> list[dict[str, Any]]:
        return _lc.find_node_uuids_by_prefix_query(run_id, node_uuid_prefix)

    def get_llm_call_input_api_type_query(
        self, run_id: str, node_uuid: str
    ) -> dict[str, Any] | None:
        return _lc.get_llm_call_input_api_type_query(run_id, node_uuid)

    def get_llm_call_output_api_type_query(
        self, run_id: str, node_uuid: str
    ) -> dict[str, Any] | None:
        return _lc.get_llm_call_output_api_type_query(run_id, node_uuid)

    def get_llm_calls_for_run_query(self, run_id: str) -> list[dict[str, Any]]:
        return _lc.get_llm_calls_for_run_query(run_id)

    def get_llm_call_full_query(
        self, run_id: str, node_uuid: str
    ) -> dict[str, Any] | None:
        return _lc.get_llm_call_full_query(run_id, node_uuid)

    def begin_llm_call_query(
        self,
        run_id: str,
        input_pickle: str,
        input_hash: str,
        node_uuid: str,
        api_type: str,
        stack_trace: str | None = None,
        node_kind: str | None = None,
        prompt_suffix_json: str = "[]",
    ) -> None:
        _lc.begin_llm_call_query(
            run_id,
            input_pickle,
            input_hash,
            node_uuid,
            api_type,
            stack_trace,
            node_kind,
            prompt_suffix_json,
        )

    def mark_llm_call_in_flight_query(self, run_id: str, node_uuid: str) -> None:
        _lc.mark_llm_call_in_flight_query(run_id, node_uuid)

    def finalize_llm_call_query(
        self,
        run_id: str,
        node_uuid: str,
        *,
        input_pickle: str | None = None,
        input_hash: str | None = None,
        output_json: str | None = None,
        status: str,
        latency_seconds: float | None = None,
        error_json: str | None = None,
        stack_trace: str | None = None,
        node_kind: str | None = None,
        prompt_suffix_json: str | None = None,
        consume_edit_field: str | None = None,
        clear_output: bool = False,
    ) -> None:
        _lc.finalize_llm_call_query(
            run_id,
            node_uuid,
            input_pickle=input_pickle,
            input_hash=input_hash,
            output_json=output_json,
            status=status,
            latency_seconds=latency_seconds,
            error_json=error_json,
            stack_trace=stack_trace,
            node_kind=node_kind,
            prompt_suffix_json=prompt_suffix_json,
            consume_edit_field=consume_edit_field,
            clear_output=clear_output,
        )

    def set_llm_verdict_query(
        self, run_id: str, node_uuid: str, llm_verdict: str | None
    ) -> None:
        _lc.set_llm_verdict_query(run_id, node_uuid, llm_verdict)

    def get_tokens_timeseries_query(
        self,
        project_id: str,
        time_from: str,
        time_to: str,
        bucket_seconds: int,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        return _lc.get_tokens_timeseries_query(
            project_id, time_from, time_to, bucket_seconds, user_id=user_id
        )

    # ──────────────────────────────────────────────────────────────────────────
    # Priors
    # ──────────────────────────────────────────────────────────────────────────

    def copy_prior_retrievals_query(
        self, old_run_id: str, new_run_id: str
    ) -> None:
        _pr.copy_prior_retrievals_query(old_run_id, new_run_id)

    def get_prior_retrieval_by_id_query(
        self, retrieval_id: str
    ) -> dict[str, Any] | None:
        return _pr.get_prior_retrieval_by_id_query(retrieval_id)

    def delete_prior_retrieval_by_id_query(self, retrieval_id: str) -> None:
        _pr.delete_prior_retrieval_by_id_query(retrieval_id)

    def get_prior_retrieval_query(
        self, run_id: str, node_uuid: str
    ) -> dict[str, Any] | None:
        return _pr.get_prior_retrieval_query(run_id, node_uuid)

    def get_prior_retrievals_for_run_query(
        self, run_id: str
    ) -> list[dict[str, Any]]:
        return _pr.get_prior_retrievals_for_run_query(run_id)

    def upsert_prior_retrieval_query(
        self,
        retrieval_id: str,
        run_id: str,
        node_uuid: str | None,
        raw_context: str,
        processed_context: str,
        inherited_prior_ids_json: str,
        retrieved_priors_json: str,
        applied_priors_json: str,
        rendered_priors_block: str,
        injection_anchor_json: str | None,
        model: str | None,
        latency_tier: str,
        timeout_ms: int | None,
        retrieval_latency_ms: int | None,
        prior_coverage: int | None,
        retrieval_status: str,
        coverage_status: str,
        warning_message: str | None,
        error_message: str | None,
        groundedness_total_importance: int | None,
        groundedness_grounded_importance: int | None,
        groundedness_guidance_points_json: str,
        adherence_status: str,
        prior_adherence: int | None,
        severity_weighted_prior_adherence: int | None,
        relevant_prior_count: int | None,
        followed_relevant_prior_count: int | None,
        violated_relevant_prior_count: int | None,
        total_non_adherence_severity: int | None,
        max_non_adherence_severity: int | None,
        prior_adherence_items_json: str,
    ) -> None:
        _pr.upsert_prior_retrieval_query(
            retrieval_id,
            run_id,
            node_uuid,
            raw_context,
            processed_context,
            inherited_prior_ids_json,
            retrieved_priors_json,
            applied_priors_json,
            rendered_priors_block,
            injection_anchor_json,
            model,
            latency_tier,
            timeout_ms,
            retrieval_latency_ms,
            prior_coverage,
            retrieval_status,
            coverage_status,
            warning_message,
            error_message,
            groundedness_total_importance,
            groundedness_grounded_importance,
            groundedness_guidance_points_json,
            adherence_status,
            prior_adherence,
            severity_weighted_prior_adherence,
            relevant_prior_count,
            followed_relevant_prior_count,
            violated_relevant_prior_count,
            total_non_adherence_severity,
            max_non_adherence_severity,
            prior_adherence_items_json,
        )

    def update_prior_coverage_query(
        self,
        retrieval_id: str,
        prior_coverage: int | None,
        coverage_status: str,
        groundedness_total_importance: int | None,
        groundedness_grounded_importance: int | None,
        groundedness_guidance_points_json: str,
    ) -> None:
        _pr.update_prior_coverage_query(
            retrieval_id,
            prior_coverage,
            coverage_status,
            groundedness_total_importance,
            groundedness_grounded_importance,
            groundedness_guidance_points_json,
        )

    def update_prior_adherence_query(
        self,
        retrieval_id: str,
        adherence_status: str,
        prior_adherence: int | None,
        severity_weighted_prior_adherence: int | None,
        relevant_prior_count: int | None,
        followed_relevant_prior_count: int | None,
        violated_relevant_prior_count: int | None,
        total_non_adherence_severity: int | None,
        max_non_adherence_severity: int | None,
        prior_adherence_items_json: str,
    ) -> None:
        _pr.update_prior_adherence_query(
            retrieval_id,
            adherence_status,
            prior_adherence,
            severity_weighted_prior_adherence,
            relevant_prior_count,
            followed_relevant_prior_count,
            violated_relevant_prior_count,
            total_non_adherence_severity,
            max_non_adherence_severity,
            prior_adherence_items_json,
        )

    def get_pending_prior_coverage_jobs_query(self, limit: int) -> list[dict[str, Any]]:
        return _pr.get_pending_prior_coverage_jobs_query(limit)

    def get_prior_coverage_cache_query(self, cache_key: str) -> dict[str, Any] | None:
        return _pr.get_prior_coverage_cache_query(cache_key)

    def upsert_prior_coverage_cache_query(
        self,
        cache_key: str,
        processed_context_hash: str,
        llm_output_hash: str,
        priors_hash: str,
        judge_model: str,
        judge_tier: str,
        reasoning_effort: str,
        prompt_version: str,
        prior_coverage: int,
        total_importance: int | None,
        grounded_importance: int | None,
        guidance_points_json: str,
    ) -> None:
        _pr.upsert_prior_coverage_cache_query(
            cache_key,
            processed_context_hash,
            llm_output_hash,
            priors_hash,
            judge_model,
            judge_tier,
            reasoning_effort,
            prompt_version,
            prior_coverage,
            total_importance,
            grounded_importance,
            guidance_points_json,
        )

    def get_prior_adherence_cache_query(self, cache_key: str) -> dict[str, Any] | None:
        return _pr.get_prior_adherence_cache_query(cache_key)

    def upsert_prior_adherence_cache_query(
        self,
        cache_key: str,
        processed_context_hash: str,
        llm_output_hash: str,
        priors_hash: str,
        judge_model: str,
        judge_tier: str,
        reasoning_effort: str,
        prompt_version: str,
        prior_adherence: int | None,
        severity_weighted_prior_adherence: int | None,
        relevant_prior_count: int | None,
        followed_relevant_prior_count: int | None,
        violated_relevant_prior_count: int | None,
        total_non_adherence_severity: int | None,
        max_non_adherence_severity: int | None,
        prior_adherence_items_json: str,
    ) -> None:
        _pr.upsert_prior_adherence_cache_query(
            cache_key,
            processed_context_hash,
            llm_output_hash,
            priors_hash,
            judge_model,
            judge_tier,
            reasoning_effort,
            prompt_version,
            prior_adherence,
            severity_weighted_prior_adherence,
            relevant_prior_count,
            followed_relevant_prior_count,
            violated_relevant_prior_count,
            total_non_adherence_severity,
            max_non_adherence_severity,
            prior_adherence_items_json,
        )

    def get_priors_scope_query(
        self, user_id: str, project_id: str
    ) -> dict[str, Any] | None:
        return _pr.get_priors_scope_query(user_id, project_id)

    def ensure_priors_scope_query(
        self,
        user_id: str,
        project_id: str,
        revision: int,
        updated_at: str,
    ) -> dict[str, Any]:
        return _pr.ensure_priors_scope_query(user_id, project_id, revision, updated_at)

    def bump_priors_scope_revision_query(
        self, user_id: str, project_id: str, updated_at: str
    ) -> dict[str, Any]:
        return _pr.bump_priors_scope_revision_query(user_id, project_id, updated_at)

    def get_prefix_cache_candidates_query(
        self,
        user_id: str,
        project_id: str,
        base_path: str,
        model: str,
        first_key: str,
        pair_count_limit: int,
    ) -> list[dict[str, Any]]:
        return _pr.get_prefix_cache_candidates_query(
            user_id, project_id, base_path, model, first_key, pair_count_limit
        )

    def upsert_prefix_cache_query(
        self,
        user_id: str,
        project_id: str,
        base_path: str,
        model: str,
        first_key: str,
        pair_count: int,
        clean_pairs_json: str,
        injected_pairs_json: str,
        prior_ids_json: str,
    ) -> None:
        _pr.upsert_prefix_cache_query(
            user_id,
            project_id,
            base_path,
            model,
            first_key,
            pair_count,
            clean_pairs_json,
            injected_pairs_json,
            prior_ids_json,
        )

    def clear_scope_prefix_cache_query(self, user_id: str, project_id: str) -> None:
        _pr.clear_scope_prefix_cache_query(user_id, project_id)

    def clear_all_prefix_cache_query(self) -> None:
        _pr.clear_all_prefix_cache_query()

    def get_cached_retrieval_query(
        self,
        user_id: str,
        project_id: str,
        priors_revision: int,
        base_path: str,
        model: str,
        context_hash: str,
        ignore_prior_ids_json: str,
    ) -> dict[str, Any] | None:
        return _pr.get_cached_retrieval_query(
            user_id,
            project_id,
            priors_revision,
            base_path,
            model,
            context_hash,
            ignore_prior_ids_json,
        )

    def upsert_retrieval_cache_query(
        self,
        user_id: str,
        project_id: str,
        priors_revision: int,
        base_path: str,
        model: str,
        context_hash: str,
        ignore_prior_ids_json: str,
        response_json: str,
    ) -> None:
        _pr.upsert_retrieval_cache_query(
            user_id,
            project_id,
            priors_revision,
            base_path,
            model,
            context_hash,
            ignore_prior_ids_json,
            response_json,
        )

    def clear_all_retrieval_cache_query(self) -> None:
        _pr.clear_all_retrieval_cache_query()

    def get_priors_applied_for_run_query(
        self, run_id: str
    ) -> list[dict[str, Any]]:
        return _pr.get_priors_applied_for_run_query(run_id)

    def get_priors_applied_query(self, prior_id: str) -> list[dict[str, Any]]:
        return _pr.get_priors_applied_query(prior_id)

    def add_prior_applied_query(
        self, prior_id: str, run_id: str, node_uuid: str | None = None
    ) -> None:
        _pr.add_prior_applied_query(prior_id, run_id, node_uuid)

    def remove_prior_applied_query(
        self, prior_id: str, run_id: str, node_uuid: str | None = None
    ) -> None:
        _pr.remove_prior_applied_query(prior_id, run_id, node_uuid)

    def delete_priors_applied_for_prior_query(self, prior_id: str) -> None:
        _pr.delete_priors_applied_for_prior_query(prior_id)

    # ──────────────────────────────────────────────────────────────────────────
    # Low-level escape hatches (used by tests)
    # ──────────────────────────────────────────────────────────────────────────

    def query_all(self, sql: str, params: tuple = ()) -> list:
        from .connection import query_all as _query_all
        return _query_all(sql, params)

    def query_one(self, sql: str, params: tuple = ()):
        from .connection import query_one as _query_one
        return _query_one(sql, params)


# Verify the class satisfies the protocol at import time (development safety check).
assert isinstance(SQLiteBackend(), DatabaseBackend), (
    "SQLiteBackend does not satisfy DatabaseBackend protocol"
)
