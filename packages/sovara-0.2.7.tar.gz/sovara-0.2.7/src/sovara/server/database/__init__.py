import importlib

from ._shared import BadRequestError, ResourceNotFoundError
from .backend_protocol import DatabaseBackend
from .manager import DB, DatabaseManager


def __getattr__(name: str):
    if name == "sqlite":
        return importlib.import_module(f"{__name__}.sqlite")
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "BadRequestError",
    "DatabaseBackend",
    "DB",
    "DatabaseManager",
    "ResourceNotFoundError",
    "sqlite",
]
