"""Helpers for persisting trace-chat verification verdicts to the main server."""

from __future__ import annotations

from typing import Iterable

import httpx


_VERDICT_MAP = {
    "CORRECT": "correct",
    "WRONG": "incorrect",
    "UNCERTAIN": "uncertain",
}


def persist_step_verdicts(trace, verdicts: Iterable[tuple[int, str]]) -> None:
    from sovara.common.constants import HOST, PORT

    if not trace.run_id:
        return

    updates: list[dict[str, str]] = []
    for index, verdict in verdicts:
        llm_verdict = _VERDICT_MAP.get(verdict)
        if llm_verdict is None:
            continue
        if index < 0 or index >= len(trace.records):
            continue
        node_uuid = trace.records[index].node_uuid
        if not node_uuid:
            continue
        updates.append({"node_uuid": node_uuid, "llm_verdict": llm_verdict})

    if not updates:
        return

    try:
        resp = httpx.post(
            f"http://{HOST}:{PORT}/internal/runner/llm/verdicts",
            json={"run_id": trace.run_id, "verdicts": updates},
            timeout=10.0,
        )
        resp.raise_for_status()
    except Exception:
        # Verification itself should still succeed even if persistence fails.
        return
