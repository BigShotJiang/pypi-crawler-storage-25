"""
Inference sub-server for heavier graph analysis computations.

Spawned as a child process by the main server on startup and terminated on shutdown.
Exposes a REST API on INFERENCE_PORT. Add compute-heavy routes here rather than
burdening the main server's event loop.

Lifecycle (called by main server lifespan in app.py):
    inference_server.start()   # spawns subprocess
    inference_server.stop()    # terminates it
"""

import asyncio
import atexit
import hashlib
import json
import os
import signal
import subprocess
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from typing import Callable, Optional
from urllib.error import URLError
from urllib.request import urlopen

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from sovara.common.constants import INFERENCE_SERVER_LOG
from sovara.common.lifecycle import (
    LIFECYCLE_STDIO_ENV,
    emit_lifecycle_event,
    parse_lifecycle_line,
)
from sovara.common.logger import create_file_logger
from sovara.common.runtime import build_so_server_command
from fastapi import Request
from sovara.server.graph_models import RunGraph
from sovara.server.graph_analysis.trace_chat.cancel import TraceChatCancelled

# ============================================================
# Sub-server app
# ============================================================

app = FastAPI()
logger = create_file_logger(INFERENCE_SERVER_LOG)


@app.get("/health")
def health():
    return {"status": "ok"}


# ============================================================
# Trace cache and background prefetch pool
# ============================================================

# _trace_cache stores {"trace": Trace, "fp": str} per run_id.
# The fingerprint hashes graph node content (input/output) so the cache
# is invalidated on edits and reruns (which rebuild the graph).
_trace_cache: dict = {}
_prefetch_futures: dict[str, Future] = {}
_chat_cancel_events: dict[str, threading.Event] = {}
_pool = ThreadPoolExecutor(max_workers=4)


def _log_preview(text: str, max_len: int = 160) -> str:
    compact = " ".join(str(text).split()).strip()
    if len(compact) <= max_len:
        return compact
    return compact[:max_len] + "..."


def _graph_fingerprint(graph_data: dict) -> str:
    """Hash graph node content to detect trace-relevant changes."""
    def _node_identity(node: dict) -> str:
        # Persisted graph nodes use `uuid`; keep `id` as a fallback for any
        # older payloads that may still flow through this code path.
        return str(node.get("uuid") or node.get("id") or "")

    content = "\n".join(
        f"{_node_identity(n)}|{n.get('input', '')}|{n.get('output', '')}|{n.get('name', '')}"
        for n in graph_data.get("nodes", [])
    )
    return hashlib.md5(content.encode()).hexdigest()


def _build_trace_from_graph(graph_data: dict):
    """Build a Trace object from graph topology data.

    The graph is the single source of truth: it is cleared on rerun and
    updated on edit, so it always reflects the current trace state.
    """
    from sovara.server.graph_analysis.trace_chat.utils.trace import (
        Trace,
        build_trace_record_from_to_show,
    )

    graph = RunGraph.from_dict(graph_data)
    nodes = sorted(graph.nodes, key=lambda node: (node.step_id, node.uuid))
    if not nodes:
        return None

    records = []
    for node in nodes:
        try:
            to_show_in = json.loads(node.input or "{}")
            to_show_out = json.loads(node.output or "{}")
        except (json.JSONDecodeError, TypeError):
            continue

        records.append(build_trace_record_from_to_show(
            to_show_in,
            to_show_out,
            index=len(records),
            correct=True if node.llm_verdict == "correct" else False if node.llm_verdict == "incorrect" else None,
            llm_verdict=node.llm_verdict,
            name=node.raw_node_name or node.label or "",
            node_uuid=node.uuid,
        ))

    if not records:
        return None
    return Trace.from_records(records)


def _get_trace_for_run(run_id: str):
    """Return (trace, is_new) — is_new=True when the trace was rebuilt."""
    from sovara.server.database import DB

    graph_row = DB.get_graph(run_id)
    if not graph_row or not graph_row["graph_topology"]:
        return None, False

    graph = RunGraph.from_json_string(graph_row["graph_topology"])
    graph_data = graph.to_dict()
    if not graph_data.get("nodes"):
        return None, False

    fp = _graph_fingerprint(graph_data)

    cached = _trace_cache.get(run_id)
    if cached and cached["fp"] == fp:
        return cached["trace"], False

    trace = _build_trace_from_graph(graph_data)
    if trace:
        trace.run_id = run_id
        _trace_cache[run_id] = {"trace": trace, "fp": fp}
    return trace, True


def _ensure_prefetch_future(run_id: str, trace, *, is_new: bool) -> Future:
    if is_new:
        stale = _prefetch_futures.pop(run_id, None)
        if stale is not None and not stale.done():
            logger.info("Prefetch dropped stale running future run_id=%s", run_id)

    future = _prefetch_futures.get(run_id)
    if future is not None:
        if future.cancelled():
            future = None
        elif future.done():
            try:
                if future.exception() is not None:
                    future = None
            except Exception:
                future = None

    if future is None:
        from sovara.server.graph_analysis.trace_chat.tools.summarize_trace import _generate_summary

        future = _pool.submit(_generate_summary, trace)
        future._sovara_started_at = time.monotonic()
        future._sovara_run_id = run_id
        _prefetch_futures[run_id] = future
        logger.info(
            "Prefetch queued run_id=%s steps=%d is_new=%s",
            run_id,
            len(trace),
            is_new,
        )

        def _log_done(done_future: Future) -> None:
            started_at = getattr(done_future, "_sovara_started_at", None)
            elapsed = (
                max(0.0, time.monotonic() - started_at)
                if started_at is not None else 0.0
            )
            if done_future.cancelled():
                logger.warning(
                    "Prefetch future cancelled run_id=%s after %.1fs",
                    run_id,
                    elapsed,
                )
                return
            try:
                summary = done_future.result()
                logger.info(
                    "Prefetch future complete run_id=%s elapsed=%.1fs summary_chars=%d",
                    run_id,
                    elapsed,
                    len(summary),
                )
            except Exception as exc:
                logger.error(
                    "Prefetch future failed run_id=%s after %.1fs: %s",
                    run_id,
                    elapsed,
                    exc,
                )

        if hasattr(future, "add_done_callback"):
            future.add_done_callback(_log_done)
    else:
        started_at = getattr(future, "_sovara_started_at", None)
        elapsed = (
            max(0.0, time.monotonic() - started_at)
            if started_at is not None else 0.0
        )
        state = "done" if future.done() else "running"
        logger.info(
            "Prefetch reusing existing future run_id=%s state=%s age=%.1fs",
            run_id,
            state,
            elapsed,
        )

    return future


# ============================================================
# Chat endpoint
# ============================================================

class ChatRequest(BaseModel):
    message: str
    history: list = Field(default_factory=list)


@app.post("/chat/{run_id}/abort", status_code=202)
def abort_chat(run_id: str):
    cancel_event = _chat_cancel_events.get(run_id)
    if cancel_event is None:
        logger.info("Trace chat abort requested for idle run_id=%s", run_id)
        return {"status": "idle"}
    cancel_event.set()
    logger.info("Trace chat abort requested for run_id=%s", run_id)
    return {"status": "cancelling"}


@app.post("/prefetch/{run_id}", status_code=202)
def prefetch(run_id: str):
    """Fire-and-forget: build trace + start summary prefetch. Returns immediately."""
    def _do():
        try:
            trace, is_new = _get_trace_for_run(run_id)
            if trace is None:
                logger.warning("Prefetch skipped for run_id=%s: no trace found", run_id)
                return
            logger.info(
                "Trace chat opened from prefetch run_id=%s steps=%d is_new=%s",
                run_id,
                len(trace),
                is_new,
            )
            _ensure_prefetch_future(run_id, trace, is_new=is_new)
            logger.info("Prefetch queued for run_id=%s steps=%d", run_id, len(trace))
        except Exception:
            logger.exception("Prefetch failed for run_id=%s", run_id)
    _pool.submit(_do)
    return {"status": "prefetching"}


@app.post("/chat/{run_id}")
async def chat(run_id: str, req: ChatRequest, request: Request):
    trace_chat_id = request.headers.get("x-sovara-trace-chat-id", "-")
    logger.info(
        "Trace chat request: id=%s run_id=%s history_messages=%d message=%s",
        trace_chat_id,
        run_id,
        len(req.history),
        _log_preview(req.message),
    )

    cancel_event = threading.Event()
    _chat_cancel_events[run_id] = cancel_event
    try:
        try:
            trace, is_new = await asyncio.to_thread(_get_trace_for_run, run_id)
        except TraceChatCancelled as exc:
            logger.info("Trace chat request cancelled for run_id=%s", run_id)
            raise HTTPException(409, str(exc))
        except Exception:
            logger.exception("Failed to load trace for run_id=%s", run_id)
            raise

        if trace is None:
            logger.warning("Trace chat rejected for run_id=%s: no LLM calls found", run_id)
            raise HTTPException(400, "No LLM calls found for this run")

        # (Re-)prefetch summary on first request or when the trace changed after a rerun/edit
        prefetch_future = _ensure_prefetch_future(run_id, trace, is_new=is_new)

        from sovara.server.graph_analysis.trace_chat.main import handle_question
        try:
            result = await asyncio.to_thread(
                handle_question,
                req.message,
                trace,
                req.history,
                prefetch_future,
                cancel_event,
            )
        except TraceChatCancelled as exc:
            logger.info("Trace chat request cancelled for run_id=%s", run_id)
            raise HTTPException(409, str(exc))
        except Exception:
            logger.exception("Trace chat request failed for run_id=%s", run_id)
            raise
    finally:
        if _chat_cancel_events.get(run_id) is cancel_event:
            _chat_cancel_events.pop(run_id, None)

    logger.info(
        "Trace chat response ready: id=%s run_id=%s answer_chars=%d edits_applied=%s",
        trace_chat_id,
        run_id,
        len(result.get("answer", "")),
        result.get("edits_applied", False),
    )
    return result


# ============================================================
# Lifecycle (called from main server lifespan)
# ============================================================

_process: Optional[subprocess.Popen] = None
_state_condition = threading.Condition(threading.RLock())
_state = "stopped"
_state_detail: str | None = None
_stop_requested = False
_state_listeners: set[Callable[[str, str | None], None]] = set()
_START_TIMEOUT_SECONDS = 15.0


def _notify_state_listeners(status: str, detail: str | None) -> None:
    listeners = list(_state_listeners)
    for listener in listeners:
        try:
            listener(status, detail)
        except Exception:
            logger.exception("Inference state listener failed")


def _set_state(status: str, detail: str | None = None) -> None:
    with _state_condition:
        global _state, _state_detail
        _state = status
        _state_detail = detail
        _state_condition.notify_all()
    _notify_state_listeners(status, detail)


def get_status() -> dict[str, str | None]:
    with _state_condition:
        return {"status": _state, "detail": _state_detail}


def add_state_listener(listener: Callable[[str, str | None], None]) -> None:
    with _state_condition:
        _state_listeners.add(listener)
        status = _state
        detail = _state_detail
    listener(status, detail)


def remove_state_listener(listener: Callable[[str, str | None], None]) -> None:
    with _state_condition:
        _state_listeners.discard(listener)


def _handle_child_lifecycle_event(event: dict) -> None:
    if event.get("component") != "inference":
        return

    state = event.get("state")
    message = event.get("message")
    detail = message if isinstance(message, str) else None

    if state == "starting":
        _set_state("starting")
    elif state == "ready":
        _set_state("ready")
    elif state == "failed":
        _set_state("failed", detail or "Inference server failed during startup")


def _start_child_output_reader(process: subprocess.Popen) -> None:
    if process.stdout is None:
        return

    def _reader() -> None:
        try:
            with open(INFERENCE_SERVER_LOG, "a", encoding="utf-8") as log_file:
                for raw_line in process.stdout:
                    if not raw_line:
                        break
                    log_file.write(raw_line)
                    log_file.flush()
                    line = raw_line.rstrip("\r\n")
                    event = parse_lifecycle_line(line)
                    if event is not None:
                        _handle_child_lifecycle_event(event)
        except Exception:
            logger.exception("Inference server stdout reader crashed")
        finally:
            try:
                process.stdout.close()
            except Exception:
                pass

    reader = threading.Thread(target=_reader, name="sovara-inference-stdout", daemon=True)
    reader.start()


def _start_child_waiter(process: subprocess.Popen) -> None:
    def _wait_for_exit() -> None:
        returncode = process.wait()
        with _state_condition:
            tracked = _process is process
            stopping = _stop_requested
            if tracked:
                globals()["_process"] = None
        _remove_pid_file()
        if stopping or returncode == 0:
            _set_state("stopped")
            return
        _set_state("failed", f"Inference server exited with code {returncode}")

    waiter = threading.Thread(target=_wait_for_exit, name="sovara-inference-waiter", daemon=True)
    waiter.start()


def _read_pid_file() -> Optional[int]:
    from sovara.common.constants import INFERENCE_SERVER_PID

    try:
        with open(INFERENCE_SERVER_PID, encoding="utf-8") as f:
            raw = f.read().strip()
    except FileNotFoundError:
        return None
    except OSError:
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


def _write_pid_file(pid: int) -> None:
    from sovara.common.constants import INFERENCE_SERVER_PID

    os.makedirs(os.path.dirname(INFERENCE_SERVER_PID), exist_ok=True)
    with open(INFERENCE_SERVER_PID, "w", encoding="utf-8") as f:
        f.write(f"{pid}\n")


def _remove_pid_file() -> None:
    from sovara.common.constants import INFERENCE_SERVER_PID

    try:
        os.remove(INFERENCE_SERVER_PID)
    except FileNotFoundError:
        pass
    except OSError:
        pass


def _pid_is_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _wait_for_pid_exit(pid: int, timeout: float) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not _pid_is_alive(pid):
            return True
        time.sleep(0.05)
    return not _pid_is_alive(pid)


def _terminate_pid(pid: int, timeout: float = 5.0) -> None:
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    except OSError:
        return
    if _wait_for_pid_exit(pid, timeout):
        return
    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        return
    except OSError:
        return
    _wait_for_pid_exit(pid, timeout)


def _is_inference_server_running(host: str, port: int, timeout: float = 1.0) -> bool:
    try:
        with urlopen(f"http://{host}:{port}/health", timeout=timeout) as response:
            return response.status == 200
    except (OSError, URLError):
        return False


def start() -> None:
    """Spawn the inference server as a supervised child process and wait until ready."""
    global _process, _stop_requested
    from sovara.common.constants import HOST, INFERENCE_PORT, INFERENCE_SERVER_LOG

    deadline = time.monotonic() + _START_TIMEOUT_SECONDS

    while True:
        with _state_condition:
            process = _process
            state = _state
            if process is not None and process.poll() is not None:
                _process = None
                process = None
            if process is not None and state == "ready":
                return
            if process is not None and state == "starting":
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                _state_condition.wait(timeout=remaining)
                continue
            break

    if (tracked_pid := _read_pid_file()) is not None and not _pid_is_alive(tracked_pid):
        _remove_pid_file()
    if _is_inference_server_running(HOST, INFERENCE_PORT):
        _set_state("ready")
        return

    os.makedirs(os.path.dirname(INFERENCE_SERVER_LOG), exist_ok=True)
    env = os.environ.copy()
    env[LIFECYCLE_STDIO_ENV] = "1"
    env["PYTHONUNBUFFERED"] = "1"

    process = subprocess.Popen(
        build_so_server_command(
            "_serve-inference",
            "--host",
            HOST,
            "--port",
            str(INFERENCE_PORT),
        ),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        close_fds=True,
        env=env,
    )
    with _state_condition:
        _process = process
        _stop_requested = False
    _set_state("starting")
    _start_child_output_reader(process)
    _start_child_waiter(process)

    while True:
        with _state_condition:
            if _process is process and _state == "ready" and process.poll() is None:
                return
            if _state == "failed":
                detail = _state_detail or "Inference server failed during startup"
                break
            if process.poll() is not None:
                detail = _state_detail or f"Inference server exited with code {process.returncode}"
                break
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                detail = (
                    f"Inference server did not become ready within {int(_START_TIMEOUT_SECONDS)} seconds"
                )
                break
            _state_condition.wait(timeout=remaining)

    _set_state("failed", detail)
    if process.poll() is None:
        try:
            process.terminate()
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
        except Exception:
            pass
    raise RuntimeError(detail)


def stop() -> None:
    """Terminate the inference server child process."""
    global _process, _stop_requested
    process = _process
    _stop_requested = True
    if process is not None and process.poll() is None:
        _set_state("stopping")
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
        finally:
            _process = None
            _remove_pid_file()
            _set_state("stopped")
        return
    _process = None
    pid = _read_pid_file()
    if pid is None:
        _set_state("stopped")
        return
    if not _pid_is_alive(pid):
        _remove_pid_file()
        _set_state("stopped")
        return
    _set_state("stopping")
    _terminate_pid(pid, timeout=5.0)
    _remove_pid_file()
    _set_state("stopped")


def _install_pid_file_cleanup() -> None:
    _write_pid_file(os.getpid())

    def _cleanup(*_args) -> None:
        _remove_pid_file()
        raise SystemExit(0)

    atexit.register(_remove_pid_file)
    signal.signal(signal.SIGTERM, _cleanup)
    signal.signal(signal.SIGINT, _cleanup)


# ============================================================
# Entry point (when spawned as subprocess)
# ============================================================

def serve(host: str = "127.0.0.1", port: int = 5961) -> None:
    import uvicorn

    _install_pid_file_cleanup()
    logger.info("Inference server starting on %s:%s", host, port)
    emit_lifecycle_event("inference", "starting", host=host, port=port, pid=os.getpid())

    uv_config = uvicorn.Config(app, host=host, port=port, log_level="warning")
    uv_server = uvicorn.Server(uv_config)

    def _emit_ready_when_started() -> None:
        while not uv_server.started and not uv_server.should_exit:
            time.sleep(0.05)
        if uv_server.started:
            emit_lifecycle_event("inference", "ready", host=host, port=port, pid=os.getpid())

    ready_notifier = threading.Thread(
        target=_emit_ready_when_started,
        name="sovara-inference-ready-notifier",
        daemon=True,
    )
    ready_notifier.start()

    try:
        uv_server.run()
    except Exception as exc:
        emit_lifecycle_event(
            "inference",
            "failed",
            host=host,
            port=port,
            pid=os.getpid(),
            message=str(exc),
        )
        raise
    finally:
        emit_lifecycle_event("inference", "stopped", host=host, port=port, pid=os.getpid())


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5961)
    args = parser.parse_args()
    serve(host=args.host, port=args.port)
