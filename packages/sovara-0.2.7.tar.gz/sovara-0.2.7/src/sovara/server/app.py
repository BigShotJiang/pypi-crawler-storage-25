"""
FastAPI application factory.
"""

import asyncio
import json
import os
import sys
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from starlette.concurrency import iterate_in_threadpool

from sovara.common.logger import create_file_logger
from sovara.common.constants import MAIN_SERVER_LOG, MAIN_SERVER_STARTUP_LOCK
from sovara.server.database import DB
from sovara.server.state import ServerState
from sovara.server.graph_analysis import inference_server
from sovara.server.priors_backend.llm.lesson_retriever import shutdown_retrieval_process_pool
from sovara.server.priors_backend.storage import PriorStoreWriteLockedError
from sovara.server.web_app_assets import is_reserved_path, resolve_web_app_file

logger = create_file_logger(MAIN_SERVER_LOG)


def _inference_server_disabled() -> bool:
    return os.environ.get("SOVARA_DISABLE_INFERENCE_SERVER") == "1"


def _clear_startup_lock() -> None:
    try:
        os.remove(MAIN_SERVER_STARTUP_LOCK)
    except FileNotFoundError:
        pass
    except Exception as exc:
        logger.warning("Could not remove startup lock %s: %s", MAIN_SERVER_STARTUP_LOCK, exc)


def _request_target(request: Request) -> str:
    query = request.url.query
    return f"{request.url.path}?{query}" if query else request.url.path


def _stringify_error_payload(value) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value.strip() or None
    try:
        return json.dumps(value, sort_keys=True, ensure_ascii=False)
    except Exception:
        text = str(value).strip()
        return text or None


async def _response_body_bytes(response) -> bytes | None:
    body = getattr(response, "body", None)
    if isinstance(body, (bytes, bytearray)):
        return bytes(body) if body else None

    body_iterator = getattr(response, "body_iterator", None)
    if body_iterator is None:
        return None

    chunks: list[bytes] = []
    if hasattr(body_iterator, "__aiter__"):
        async for chunk in body_iterator:
            if isinstance(chunk, str):
                chunk = chunk.encode("utf-8")
            if isinstance(chunk, (bytes, bytearray)) and chunk:
                chunks.append(bytes(chunk))
    else:
        for chunk in body_iterator:
            if isinstance(chunk, str):
                chunk = chunk.encode("utf-8")
            if isinstance(chunk, (bytes, bytearray)) and chunk:
                chunks.append(bytes(chunk))

    if not chunks:
        return None

    response.body_iterator = iterate_in_threadpool(iter(chunks))
    return b"".join(chunks)


async def _response_detail(response) -> str | None:
    body = await _response_body_bytes(response)
    if not body:
        return None

    try:
        data = json.loads(body.decode("utf-8"))
    except Exception:
        try:
            text = body.decode("utf-8").strip()
        except Exception:
            return None
        return text or None

    if isinstance(data, dict):
        detail = data.get("detail")
        detail_text = _stringify_error_payload(detail)
        if detail_text:
            return detail_text
        error = data.get("error")
        error_text = _stringify_error_payload(error)
        if error_text:
            return error_text

    return _stringify_error_payload(data)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize server state, start background tasks, clean up on shutdown."""
    state = ServerState()
    state._loop = asyncio.get_running_loop()
    app.state.server_state = state
    inference_enabled = not _inference_server_disabled()

    def _handle_inference_state(status: str, detail: str | None) -> None:
        state.set_service_status("inference", status, detail)

    if inference_enabled:
        inference_server.add_state_listener(_handle_inference_state)
    else:
        state.set_service_status(
            "inference",
            "disabled",
            "Disabled by SOVARA_DISABLE_INFERENCE_SERVER",
        )
    monitor_task: asyncio.Task | None = None

    try:
        # Wire up uvicorn server reference for clean shutdown (set by so_server.py)
        uv_server = getattr(app.state, "uvicorn_server", None)
        if uv_server:
            state._uvicorn_server = uv_server

        # Load finished runs from DB
        state.load_finished_runs()

        # Start child sub-servers
        if inference_enabled:
            inference_server.start()

        # Start inactivity monitor
        async def inactivity_monitor():
            while True:
                await asyncio.sleep(60)
                if state.check_inactivity():
                    logger.info("Inactivity timeout reached, shutting down...")
                    state.request_shutdown()
                    return

        monitor_task = asyncio.create_task(inactivity_monitor())

        logger.info("Server ready")
        _clear_startup_lock()
        yield
    finally:
        if monitor_task is not None:
            monitor_task.cancel()
            try:
                await monitor_task
            except asyncio.CancelledError:
                pass

        shutdown_retrieval_process_pool()
        if inference_enabled:
            inference_server.stop()
            inference_server.remove_state_listener(_handle_inference_state)
        DB.close_all_connections()


def create_app() -> FastAPI:
    app = FastAPI(lifespan=lifespan)

    @app.exception_handler(PriorStoreWriteLockedError)
    async def handle_prior_store_write_lock(request: Request, exc: PriorStoreWriteLockedError):
        del request
        return JSONResponse(status_code=409, content={"detail": str(exc)})

    @app.middleware("http")
    async def touch_server_activity(request: Request, call_next):
        state = getattr(request.app.state, "server_state", None)
        if state is not None:
            state.touch_activity()
        try:
            response = await call_next(request)
        except Exception:
            logger.exception(
                "HTTP request crashed method=%s path=%s",
                request.method,
                _request_target(request),
            )
            raise

        if response.status_code >= 400:
            detail = await _response_detail(response)
            if detail:
                logger.warning(
                    "HTTP request failed method=%s path=%s status=%s detail=%s",
                    request.method,
                    _request_target(request),
                    response.status_code,
                    detail,
                )
            else:
                logger.warning(
                    "HTTP request failed method=%s path=%s status=%s",
                    request.method,
                    _request_target(request),
                    response.status_code,
                )
        return response

    from sovara.server.routes.runner import router as runner_router
    from sovara.server.routes.ui import router as ui_router
    from sovara.server.routes.events import router as events_router
    from sovara.server.routes.internal import router as internal_router
    from sovara.server.routes.claude_proxy import router as claude_proxy_router
    from sovara.server.priors_backend.routes import router as priors_router

    app.include_router(runner_router)
    app.include_router(ui_router)
    app.include_router(events_router)
    app.include_router(internal_router)
    app.include_router(claude_proxy_router)
    app.include_router(priors_router)

    @app.get("/health")
    async def health():
        return {
            "status": "ok",
            "service": "sovara",
            "python_executable": sys.executable,
        }

    @app.get("/", include_in_schema=False)
    async def web_app_index():
        index_path = resolve_web_app_file("/")
        if index_path is None:
            raise HTTPException(status_code=404, detail="Sovara web app assets are not available.")
        return FileResponse(index_path)

    @app.api_route("/{full_path:path}", methods=["GET", "HEAD"], include_in_schema=False)
    async def web_app_files(full_path: str):
        request_path = f"/{full_path}" if full_path else "/"
        if is_reserved_path(request_path):
            raise HTTPException(status_code=404, detail="Not Found")

        asset_path = resolve_web_app_file(request_path)
        if asset_path is not None:
            return FileResponse(asset_path)

        if Path(full_path).suffix:
            raise HTTPException(status_code=404, detail="Not Found")

        index_path = resolve_web_app_file("/")
        if index_path is None:
            raise HTTPException(status_code=404, detail="Sovara web app assets are not available.")
        return FileResponse(index_path)

    return app


def get_state(request: Request) -> ServerState:
    """FastAPI dependency to get server state."""
    return request.app.state.server_state
