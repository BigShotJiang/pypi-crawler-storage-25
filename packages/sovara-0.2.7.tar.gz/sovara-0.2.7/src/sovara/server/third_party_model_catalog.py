from __future__ import annotations

from functools import lru_cache
from typing import Any, Literal, TypedDict

import litellm

ThirdPartyVendorAuthType = Literal["api_key", "aws_credentials", "vertex_credentials"]
ThirdPartyModelKind = Literal["chat", "embedding", "rerank"]
THIRD_PARTY_VENDOR_AUTH_TYPES: dict[str, ThirdPartyVendorAuthType] = {
    "bedrock": "aws_credentials",
    "vertex_ai": "vertex_credentials",
}
MANUAL_ENDPOINT_VENDORS = frozenset({"azure", "azure_ai"})
MANUAL_MODEL_ENTRY_VENDORS = MANUAL_ENDPOINT_VENDORS
THIRD_PARTY_BASE_URL_VENDORS = MANUAL_ENDPOINT_VENDORS
STATIC_THIRD_PARTY_VENDORS = MANUAL_ENDPOINT_VENDORS
OPENAI_COMPATIBLE_THIRD_PARTY_VENDORS = MANUAL_ENDPOINT_VENDORS
VENDOR_LABELS = {
    "ai21": "AI21",
    "amazon_nova": "Amazon Nova API",
    "anthropic": "Anthropic",
    "azure": "Azure OpenAI",
    "azure_ai": "Azure AI",
    "bedrock": "Amazon Bedrock",
    "fireworks_ai": "Fireworks AI",
    "gemini": "Gemini",
    "openai": "OpenAI",
    "openrouter": "OpenRouter",
    "together_ai": "Together AI",
    "vertex_ai": "Vertex AI",
    "xai": "xAI",
}


class ThirdPartyVendorOption(TypedDict):
    value: str
    label: str
    auth_type: ThirdPartyVendorAuthType


class ThirdPartyModelOption(TypedDict):
    value: str
    label: str


class ThirdPartyModelCatalog(TypedDict):
    third_party_vendors: list[ThirdPartyVendorOption]
    third_party_models_by_vendor: dict[str, list[ThirdPartyModelOption]]


def _trim_text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    return stripped or None


def derive_third_party_vendor(model_name: str | None) -> str | None:
    trimmed = _trim_text(model_name)
    if not trimmed or "/" not in trimmed:
        return None
    provider, _ = trimmed.split("/", 1)
    return provider or None


def canonicalize_vendor_model_name(vendor: str, model_name: str | None) -> str | None:
    normalized_vendor = _trim_text(vendor)
    normalized_model_name = _trim_text(model_name)
    if not normalized_vendor or not normalized_model_name:
        return None
    if normalized_model_name.startswith(f"{normalized_vendor}/"):
        return normalized_model_name
    return f"{normalized_vendor}/{normalized_model_name}"


def get_third_party_vendor_auth_type(vendor: str | None) -> ThirdPartyVendorAuthType:
    normalized_vendor = _trim_text(vendor)
    return THIRD_PARTY_VENDOR_AUTH_TYPES.get(normalized_vendor or "", "api_key")


def uses_manual_third_party_model_entry(vendor: str | None) -> bool:
    normalized_vendor = _trim_text(vendor)
    return bool(normalized_vendor) and normalized_vendor in MANUAL_MODEL_ENTRY_VENDORS


def requires_third_party_base_url(vendor: str | None) -> bool:
    normalized_vendor = _trim_text(vendor)
    return bool(normalized_vendor) and normalized_vendor in THIRD_PARTY_BASE_URL_VENDORS


def uses_openai_compatible_third_party_runtime(vendor: str | None) -> bool:
    normalized_vendor = _trim_text(vendor)
    return bool(normalized_vendor) and normalized_vendor in OPENAI_COMPATIBLE_THIRD_PARTY_VENDORS


def _display_model_name(vendor: str, model_name: str) -> str:
    prefix = f"{vendor}/"
    if model_name.startswith(prefix):
        return model_name[len(prefix) :]
    return model_name


def _vendor_label(vendor: str) -> str:
    if vendor in VENDOR_LABELS:
        return VENDOR_LABELS[vendor]
    return vendor.replace("_", " ").replace("-", " ").title()


def _model_metadata(vendor: str, model_name: str) -> dict[str, Any] | None:
    return (
        litellm.model_cost.get(model_name)
        or litellm.model_cost.get(_display_model_name(vendor, model_name))
    )


def _should_include_catalog_model(vendor: str, model_name: str, kind: ThirdPartyModelKind) -> bool:
    metadata = _model_metadata(vendor, model_name)
    if not isinstance(metadata, dict):
        return kind == "chat"
    mode = metadata.get("mode")
    if kind == "chat":
        return mode in {None, "", "chat"}
    if kind == "embedding":
        return mode == "embedding"
    return mode == "rerank"


def _normalize_catalog_models_for_vendor(
    vendor: str,
    models: Any,
    kind: ThirdPartyModelKind,
) -> list[ThirdPartyModelOption]:
    normalized: list[ThirdPartyModelOption] = []
    seen: set[str] = set()
    for raw_model in models or []:
        canonical = canonicalize_vendor_model_name(vendor, raw_model)
        if canonical is None or canonical in seen:
            continue
        if not _should_include_catalog_model(vendor, canonical, kind):
            continue
        normalized.append(
            {
                "value": canonical,
                "label": _display_model_name(vendor, canonical),
            }
        )
        seen.add(canonical)
    normalized.sort(key=lambda item: item["label"].lower())
    return normalized


@lru_cache(maxsize=None)
def get_third_party_model_catalog(kind: ThirdPartyModelKind = "chat") -> ThirdPartyModelCatalog:
    models_by_vendor: dict[str, list[ThirdPartyModelOption]] = {}

    for vendor in sorted(litellm.models_by_provider.keys()):
        if uses_manual_third_party_model_entry(vendor):
            continue
        models = _normalize_catalog_models_for_vendor(
            vendor,
            litellm.models_by_provider.get(vendor),
            kind,
        )
        if models:
            models_by_vendor[vendor] = models

    vendors = [
        {
            "value": vendor,
            "label": _vendor_label(vendor),
            "auth_type": get_third_party_vendor_auth_type(vendor),
        }
        for vendor in sorted(models_by_vendor.keys() | STATIC_THIRD_PARTY_VENDORS, key=lambda item: _vendor_label(item).lower())
    ]

    return {
        "third_party_vendors": vendors,
        "third_party_models_by_vendor": models_by_vendor,
    }
