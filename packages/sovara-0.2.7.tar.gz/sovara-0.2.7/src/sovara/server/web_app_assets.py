"""Helpers for locating and serving the packaged desktop web app."""

from __future__ import annotations

import os
import sys
from pathlib import Path

from sovara.common.constants import SOVARA_INSTALL_DIR

WEB_APP_DIR_ENV = "SOVARA_WEB_APP_DIR"
RESERVED_PREFIXES = (
    "/api/v1",
    "/health",
    "/internal",
    "/runner",
    "/ui",
    "/ws",
)


def is_reserved_path(path: str) -> bool:
    return any(path == prefix or path.startswith(f"{prefix}/") for prefix in RESERVED_PREFIXES)


def get_web_app_build_dir() -> Path | None:
    candidates: list[Path] = []

    env_path = os.environ.get(WEB_APP_DIR_ENV)
    if env_path:
        candidates.append(Path(env_path).expanduser())

    if getattr(sys, "_MEIPASS", None):
        candidates.append(Path(sys._MEIPASS) / "sovara" / "assets" / "web_app")

    install_dir = Path(SOVARA_INSTALL_DIR)
    candidates.append(install_dir / "assets" / "web_app")
    candidates.append(install_dir.parent.parent / "ui" / "web_app" / "dist")

    seen: set[Path] = set()
    for candidate in candidates:
        resolved = candidate.resolve()
        if resolved in seen:
            continue
        seen.add(resolved)
        if (resolved / "index.html").is_file():
            return resolved
    return None


def resolve_web_app_file(url_path: str) -> Path | None:
    build_dir = get_web_app_build_dir()
    if build_dir is None:
        return None

    parts = [part for part in Path(url_path.lstrip("/")).parts if part not in ("", ".")]
    if any(part == ".." for part in parts):
        return None

    candidate = (build_dir.joinpath(*parts) if parts else build_dir / "index.html").resolve()
    try:
        candidate.relative_to(build_dir)
    except ValueError:
        return None

    if candidate.is_file():
        return candidate
    return None
