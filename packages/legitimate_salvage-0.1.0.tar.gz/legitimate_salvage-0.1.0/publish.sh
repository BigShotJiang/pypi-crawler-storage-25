#!/usr/bin/env bash
# Publish legitimate-salvage to PyPI.
# Uses credentials from ~/.pypirc.
# Self-contained: creates an ephemeral venv via uv.
#
# Usage:
#   ./publish.sh          # build + upload
#   ./publish.sh --dry    # build only (no upload)
set -euo pipefail

DRY_RUN=false
[[ "${1:-}" == "--dry" ]] && DRY_RUN=true

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

VENV="$ROOT/.build-venv"

echo "==> Cleaning previous builds..."
rm -rf dist/ build/ legitimate_salvage/labextension "$VENV"

echo "==> Creating build environment..."
uv venv "$VENV" --quiet
# shellcheck disable=SC1091
source "$VENV/bin/activate"
uv pip install --quiet "jupyterlab>=4,<5" build twine hatch-jupyter-builder hatch-nodejs-version

echo "==> Building JS extension..."
jlpm install
jlpm build:prod

echo "==> Building Python package..."
python -m build

echo ""
echo "==> Built artifacts:"
ls -lh dist/

if $DRY_RUN; then
    echo ""
    echo "Dry run — skipping upload. Run without --dry to publish."
    rm -rf "$VENV"
    exit 0
fi

echo ""
echo "==> Uploading to PyPI..."
twine upload dist/* --verbose

VERSION=$(python -c 'from legitimate_salvage._version import __version__; print(__version__)')
echo ""
echo "Done. Published legitimate-salvage $VERSION"

# rm -rf "$VENV"
