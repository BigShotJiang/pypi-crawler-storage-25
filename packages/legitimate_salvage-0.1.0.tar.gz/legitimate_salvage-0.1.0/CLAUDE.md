# CLAUDE.md

This file provides guidance to Claude Code when working with code in this repository.

## Project Overview

**legitimate-salvage** is a JupyterLab 4 theme extension. Currently ships two dark themes:

- **Rocinante** — cool cyan/teal palette
- **Amber** — warm amber/orange palette

More themes will be added over time. The architecture is designed to make adding new themes straightforward — define a palette in `src/palettes.ts`, register it in `src/index.ts`, and add its `data-jp-theme-name` to the CSS selectors in `style/index.css`.

## Commands

```bash
# Install dependencies
jlpm install

# Development build
jlpm build

# Production build
jlpm build:prod

# Install extension locally (editable)
pip install -e .

# Verify extension is registered
jupyter labextension list

# Publish to PyPI (uses ~/.pypirc credentials, self-contained via uv)
./publish.sh            # build + upload
./publish.sh --dry      # build only, no upload

# Run JupyterLab for testing
jupyter lab --no-browser
```

These commands require a Python environment with JupyterLab 4 installed. The `publish.sh` script is self-contained — it creates an ephemeral `.build-venv/` via `uv` with all needed dependencies and cleans it up after.

## Architecture

### How Multiple Themes Work From One Extension

JupyterLab's `themePath` in `package.json` only supports one CSS file. We work around this:

1. **`src/palettes.ts`** defines each theme's color palette as a TypeScript object implementing `IThemePalette`. Exports `generateVariablesCSS()` which maps a palette to all `--jp-*` CSS variables.
2. **`src/index.ts`** registers each theme via `manager.register()`. Each theme's `load()` injects its palette as a `<style>` element into the document head, then loads the shared structural CSS via `manager.loadCSS()`. The `unload()` removes the injected `<style>`.
3. **`style/index.css`** is the shared structural CSS. All colors reference `--jp-*` variables — no hardcoded hex values. Selectors list all theme names (e.g., `body[data-jp-theme-name='rocinante'], body[data-jp-theme-name='amber']`).

### Adding a New Theme

1. Define a new `IThemePalette` object in `src/palettes.ts`
2. Add a `manager.register()` call in `src/index.ts` (copy an existing one, change the name and palette)
3. Add the new theme's `data-jp-theme-name` to every selector group in `style/index.css`
4. Rebuild

### Key Files

| File | Purpose |
|------|---------|
| `src/index.ts` | Plugin entry — registers all themes with `IThemeManager` |
| `src/palettes.ts` | Color palettes, `IThemePalette` interface, CSS variable generation, DOM injection |
| `style/index.css` | Shared structural CSS (cells, tabs, sidebar, tables, markdown, output areas, etc.) |
| `legitimate_salvage/__init__.py` | Python package entry + labextension path registration |
| `pyproject.toml` | Python/PyPI package config (hatchling build) |
| `package.json` | npm config, JupyterLab extension metadata, linter configs |
| `publish.sh` | Self-contained PyPI publish script (uses `uv`) |

### Naming Conventions

- **PyPI / npm package name**: `legitimate-salvage` (hyphens)
- **Python package directory**: `legitimate_salvage/` (underscores)
- **Theme names** (in JupyterLab UI): lowercase, set via `name` field in `manager.register()` (e.g., `'rocinante'`, `'amber'`)
- **CSS selectors**: `body[data-jp-theme-name='<theme-name>']`
- **Plugin ID**: `legitimate-salvage:plugin`

### Palette → JupyterLab Variable Mapping

Each `IThemePalette` has semantic color roles that map to JupyterLab and CodeMirror variables:

| Palette Role | JupyterLab Usage |
|---|---|
| `bg`, `bgAlt`, `bgHl`, `bgRegion` | `--jp-layout-color0` through `--jp-layout-color3` |
| `fg`, `fgDim`, `fgBright` | `--jp-ui-font-color*`, `--jp-content-font-color*` |
| `accent`, `accentBright`, `accentDark` | `--jp-brand-color*`, syntax keyword/builtin/operator |
| `green` | Syntax strings |
| `orange` | Syntax numbers/constants/atoms |
| `yellow` | Syntax types |
| `red` | Syntax tags, errors |
| `blue` | Syntax attributes, info |
| `border` | `--jp-border-color*` |

### Build Output

`jlpm build` compiles TypeScript to `lib/` and produces the labextension in `legitimate_salvage/labextension/`. The labextension directory is build output — don't edit files in it directly.

## Design Principles

- **No runtime customization** — well-crafted static themes, not a runtime color picker.
- **Maximize content-to-chrome ratio** — no backdrop-filter blur, no transform hover animations, no text-shadow glow effects. Let the content breathe.
- **Hierarchy through typography, not decoration** — headings use size/weight, not glow or colored boxes.
- **All colors via CSS custom properties** — the structural CSS never hardcodes hex values. Theme differentiation is purely through variable injection.

## Things to Watch Out For

- **`data-jp-theme-name` must match the `name` field** in `manager.register()`, not the package name.
- **Sidebar icon visibility** depends on `--jp-icon-contrast-color*` and `--jp-inverse-layout-color*` variables being set to light-enough values. If icons disappear, check these in `palettes.ts`.
- **Pandas DataFrame tables** use inline styles — CSS overrides need `!important` on `.dataframe thead th` and `.dataframe tbody td` to take effect.
- **Matplotlib/plotnine figure internals** cannot be themed via CSS — users need `plt.style.use('dark_background')` in their notebook code. The CSS only controls the container/border.
- **`publish.sh` is self-contained** — it uses `uv` to create an ephemeral `.build-venv/` with all dependencies. No conda or system Python env is assumed.
