import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';

import { IThemeManager } from '@jupyterlab/apputils';

import {
  rocinantePalette,
  amberPalette,
  injectThemeVariables,
  removeThemeVariables
} from './palettes';

/**
 * Rocinante + Amber theme extension for JupyterLab.
 *
 * Registers two dark themes from a single plugin:
 * - Rocinante: cool cyan palette (The Expanse aesthetic)
 * - Amber: warm amber palette (retro console aesthetic)
 *
 * Both themes load the same structural CSS; only the CSS custom
 * properties differ (injected at load time from palettes.ts).
 */
const plugin: JupyterFrontEndPlugin<void> = {
  id: 'legitimate-salvage:plugin',
  autoStart: true,
  requires: [IThemeManager],
  activate: (app: JupyterFrontEnd, manager: IThemeManager) => {
    const style = 'legitimate-salvage/index.css';

    manager.register({
      name: 'rocinante',
      displayName: 'Rocinante',
      isLight: false,
      themeScrollbars: true,
      load: () => {
        injectThemeVariables('rocinante', rocinantePalette);
        return manager.loadCSS(style);
      },
      unload: () => {
        removeThemeVariables('rocinante');
        return Promise.resolve(undefined);
      }
    });

    manager.register({
      name: 'amber',
      displayName: 'Amber',
      isLight: false,
      themeScrollbars: true,
      load: () => {
        injectThemeVariables('amber', amberPalette);
        return manager.loadCSS(style);
      },
      unload: () => {
        removeThemeVariables('amber');
        return Promise.resolve(undefined);
      }
    });
  }
};

export default plugin;
