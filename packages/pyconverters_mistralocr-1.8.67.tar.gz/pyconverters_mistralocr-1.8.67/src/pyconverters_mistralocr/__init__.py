"""Convert PDF to structured text using MistralOCR"""

__version__ = "1.8.67"
