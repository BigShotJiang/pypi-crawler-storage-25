"""Smoke-test the facade modules for de441-spectral."""

from __future__ import annotations

import pytest

def _assert_dunder_all_resolves(module) -> None:
    missing = [n for n in module.__all__ if not hasattr(module, n)]
    assert not missing, f"{module.__name__}: __all__ lists missing names: {missing}"

def test_bridge_facade() -> None:
    from ephemerides_spectral import bridge
    _assert_dunder_all_resolves(bridge)
    assert hasattr(bridge, "get_system_state")
    assert hasattr(bridge, "get_local_view")
    assert hasattr(bridge, "get_eclipse_probability")

def test_version_facade() -> None:
    from ephemerides_spectral import version
    assert hasattr(version, "__version__")
    assert isinstance(version.__version__, str)
