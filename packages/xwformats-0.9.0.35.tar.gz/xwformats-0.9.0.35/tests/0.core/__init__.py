"""
Core tests for xwformats.
"""
