#!/usr/bin/env python3
#exonware/xwformats/src/exonware/xwformats/formats/text/__init__.py
"""
Enterprise text serialization formats.

Company: eXonware.com
Author: Eng. Muhammad AlShehri
Email: connect@exonware.com
Version: 0.9.0.35
Generation Date: 02-Nov-2025

Note: xwformats text scope currently includes RON only.
      Basic XML/JSON/YAML/TOML support is available in xwsystem core.
"""

from .ron import RonSerializer

__all__ = [
    "RonSerializer",
]


