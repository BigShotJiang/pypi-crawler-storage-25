"""Tests for the Python Coffrify HTTP client.

Uses the `responses` library to mock the `requests` calls — gives us
precise control over status codes, headers, and call counts without
hitting the real API.
"""

from __future__ import annotations

import json
from typing import Any

import pytest
import responses

from coffrify import Coffrify, CoffrifyAPIError


API_URL = "https://api.coffrify.test"
API_KEY = "cfy_live_test_00000000000000000000000000000000"


def make_client(**kwargs: Any) -> Coffrify:
    """Spawn a client wired to the mock API host. Disable backoff for fast tests."""
    return Coffrify(
        api_key=API_KEY,
        api_url=API_URL,
        retry_base_delay=0.001,
        **kwargs,
    )


# ─────────────────────────── happy path ───────────────────────────


@responses.activate
def test_get_sends_auth_and_request_id_headers() -> None:
    responses.add(
        responses.GET, f"{API_URL}/v1/transfers",
        json={"data": [], "has_more": False}, status=200,
    )
    client = make_client()
    out = client.transfers.list()
    assert out == {"data": [], "has_more": False}

    call = responses.calls[0].request
    assert call.headers["Authorization"] == f"Bearer {API_KEY}"
    assert call.headers["User-Agent"].startswith("coffrify-python/")
    # Auto-generated request id (UUID format)
    rid = call.headers.get("X-Coffrify-Request-Id")
    assert rid and len(rid) == 36


@responses.activate
def test_workspace_id_is_propagated_as_query_param() -> None:
    responses.add(
        responses.GET, f"{API_URL}/v1/transfers",
        json={}, status=200,
    )
    client = make_client(workspace_id="ws_abc")
    client.transfers.list()
    call = responses.calls[0].request
    assert "workspace_id=ws_abc" in call.url
    assert "limit=20" in call.url  # default


# ─────────────────────────── idempotency ───────────────────────────


@responses.activate
def test_post_auto_injects_idempotency_key() -> None:
    responses.add(
        responses.POST, f"{API_URL}/v1/transfers",
        json={"transfer": {"id": "trf_1"}}, status=201,
    )
    client = make_client()
    client.transfers.create(files=[{"name": "a.pdf", "size": 100}])
    call = responses.calls[0].request
    idem = call.headers.get("Idempotency-Key")
    assert idem and len(idem) == 36


@responses.activate
def test_caller_provided_idempotency_key_wins() -> None:
    responses.add(
        responses.POST, f"{API_URL}/v1/transfers",
        json={}, status=201,
    )
    client = make_client()
    client.transfers.create(
        files=[{"name": "a.pdf", "size": 100}],
        idempotency_key="deadbeef-1234-5678-9abc-def012345678",
    )
    call = responses.calls[0].request
    assert call.headers["Idempotency-Key"] == "deadbeef-1234-5678-9abc-def012345678"


@responses.activate
def test_auto_idempotency_disabled() -> None:
    responses.add(
        responses.POST, f"{API_URL}/v1/transfers",
        json={}, status=201,
    )
    client = make_client(auto_idempotency=False)
    client.transfers.create(files=[{"name": "a.pdf", "size": 100}])
    call = responses.calls[0].request
    assert call.headers.get("Idempotency-Key") is None


# ─────────────────────────── retries ───────────────────────────


@responses.activate
def test_retries_on_503_then_succeeds() -> None:
    responses.add(responses.GET, f"{API_URL}/v1/transfers", status=503, json={})
    responses.add(responses.GET, f"{API_URL}/v1/transfers", status=200, json={"data": []})
    client = make_client(max_retries=3)
    out = client.transfers.list()
    assert out == {"data": []}
    assert len(responses.calls) == 2


@responses.activate
def test_retries_on_429() -> None:
    responses.add(responses.GET, f"{API_URL}/v1/transfers", status=429, json={})
    responses.add(responses.GET, f"{API_URL}/v1/transfers", status=429, json={})
    responses.add(responses.GET, f"{API_URL}/v1/transfers", status=200, json={"data": []})
    client = make_client(max_retries=5)
    out = client.transfers.list()
    assert out == {"data": []}
    assert len(responses.calls) == 3


@responses.activate
def test_does_not_retry_on_401() -> None:
    responses.add(
        responses.GET, f"{API_URL}/v1/transfers",
        status=401, json={"error": {"code": "invalid_api_key", "message": "Bad key"}},
    )
    client = make_client(max_retries=3)
    with pytest.raises(CoffrifyAPIError) as exc:
        client.transfers.list()
    assert exc.value.status == 401
    assert len(responses.calls) == 1


@responses.activate
def test_gives_up_after_max_retries() -> None:
    for _ in range(4):
        responses.add(
            responses.GET, f"{API_URL}/v1/transfers",
            status=502, json={"error": {"code": "bad_gateway", "message": "upstream"}},
        )
    client = make_client(max_retries=3)
    with pytest.raises(CoffrifyAPIError) as exc:
        client.transfers.list()
    assert exc.value.status == 502
    # 1 initial + 3 retries = 4
    assert len(responses.calls) == 4


# ─────────────────────────── error parsing ───────────────────────────


@responses.activate
def test_surfaces_error_code_and_message() -> None:
    responses.add(
        responses.POST, f"{API_URL}/v1/transfers",
        status=422,
        json={"error": {"code": "validation_error", "message": "name is required"}},
    )
    client = make_client()
    with pytest.raises(CoffrifyAPIError) as exc:
        client.transfers.create(files=[{"name": "x", "size": 1}])
    assert exc.value.status == 422
    assert "validation_error" in str(exc.value) or "name is required" in str(exc.value)


# ─────────────────────────── constructor validation ───────────────────────────


def test_rejects_invalid_api_key_format() -> None:
    with pytest.raises(ValueError):
        Coffrify(api_key="wrong_format")


def test_accepts_test_keys() -> None:
    client = Coffrify(api_key="cfy_test_00000000000000000000000000000000")
    assert client.api_key.startswith("cfy_test_")


# ─────────────────────────── new methods (rotate / test_event / iterate) ───────────────────────────


@responses.activate
def test_api_keys_rotate() -> None:
    responses.add(
        responses.POST, f"{API_URL}/v1/api-keys/akey_1/rotate",
        status=200, json={"key": "cof_live_new", "old_key_id": "akey_1"},
    )
    client = make_client()
    out = client.api_keys.rotate("akey_1", grace_days=3)
    assert out["key"] == "cof_live_new"
    body = json.loads(responses.calls[0].request.body)
    assert body["grace_days"] == 3


@responses.activate
def test_webhooks_rotate_secret_passes_grace_hours() -> None:
    responses.add(
        responses.POST, f"{API_URL}/v1/webhooks?action=rotate_secret",
        status=200, match_querystring=False,
        json={"secret": "whsec_new", "secret_grace_until": "2026-05-18T12:00:00Z"},
    )
    client = make_client()
    out = client.webhooks.rotate_secret("wh_1", grace_hours=48)
    assert out["secret"] == "whsec_new"
    body = json.loads(responses.calls[0].request.body)
    assert body == {"id": "wh_1", "grace_hours": 48}


@responses.activate
def test_webhooks_test_with_custom_event_type() -> None:
    responses.add(
        responses.POST, f"{API_URL}/v1/webhooks?action=test",
        status=200, match_querystring=False,
        json={"ok": True, "status": 200, "duration_ms": 42},
    )
    client = make_client()
    client.webhooks.test("wh_1", event_type="transfer.created", data={"x": 1})
    body = json.loads(responses.calls[0].request.body)
    assert body == {"id": "wh_1", "event_type": "transfer.created", "data": {"x": 1}}


@responses.activate
def test_transfers_iterate_follows_cursor() -> None:
    responses.add(
        responses.GET, f"{API_URL}/v1/transfers",
        status=200,
        json={"data": [{"id": "trf_1"}, {"id": "trf_2"}], "has_more": True, "next_cursor": "cur_abc"},
    )
    responses.add(
        responses.GET, f"{API_URL}/v1/transfers",
        status=200,
        json={"data": [{"id": "trf_3"}], "has_more": False, "next_cursor": None},
    )
    client = make_client()
    ids = [t["id"] for t in client.transfers.iterate(page_size=2)]
    assert ids == ["trf_1", "trf_2", "trf_3"]
    assert len(responses.calls) == 2
    # Second call should carry the cursor
    assert "cursor=cur_abc" in responses.calls[1].request.url


@responses.activate
def test_transfers_iterate_max_items_cap() -> None:
    responses.add(
        responses.GET, f"{API_URL}/v1/transfers",
        status=200,
        json={"data": [{"id": f"trf_{i}"} for i in range(10)], "has_more": True, "next_cursor": "x"},
    )
    client = make_client()
    out = list(client.transfers.iterate(max_items=3))
    assert len(out) == 3
    assert out[-1]["id"] == "trf_2"
