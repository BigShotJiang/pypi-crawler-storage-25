"""Tests for the Python SDK's webhook verification helpers.

Covers both signature formats (Coffrify legacy + Standard Webhooks),
multi-secret accept-list (rotation grace), tolerance window, and
malformed input.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from typing import Tuple
from unittest.mock import patch

import pytest

from coffrify.webhooks import (
    SIGNATURE_VERSION,
    VerifyResult,
    verify,
    verify_from_headers,
)


# ─────────────────────────── helpers ───────────────────────────


def _key_bytes(secret: str) -> bytes:
    """Mirror the SDK's _resolve_key logic."""
    if secret.startswith("whsec_") and len(secret) > 8:
        try:
            return bytes.fromhex(secret[6:])
        except ValueError:
            pass
    return secret.encode("utf-8")


def _sign_legacy(secret: str, body: str, ts: int) -> str:
    digest = hmac.new(_key_bytes(secret), f"{ts}.{body}".encode("utf-8"), hashlib.sha256).hexdigest()
    return f"t={ts},{SIGNATURE_VERSION}={digest}"


def _sign_standard(secret: str, body: str, webhook_id: str, ts: int) -> str:
    digest = hmac.new(_key_bytes(secret), f"{webhook_id}.{ts}.{body}".encode("utf-8"), hashlib.sha256).digest()
    return f"{SIGNATURE_VERSION},{base64.b64encode(digest).decode('ascii')}"


SECRET = "whsec_" + "ab" * 32
SECRET_2 = "whsec_" + "cd" * 32
SECRET_BAD = "whsec_" + "ef" * 32
RAW = json.dumps({"id": "evt_test", "type": "ping", "data": {"ok": True}}, sort_keys=False)


# ─────────────────────────── legacy ───────────────────────────


class TestVerifyLegacy:
    def setup_method(self) -> None:
        # Freeze time so signatures don't expire mid-test.
        self._patcher = patch("time.time", return_value=1_777_000_000.0)
        self._patcher.start()

    def teardown_method(self) -> None:
        self._patcher.stop()

    def test_valid_signature_parses_event(self) -> None:
        ts = int(time.time())
        header = _sign_legacy(SECRET, RAW, ts)
        r = verify(RAW, header, SECRET)
        assert r.valid is True
        assert r.event["id"] == "evt_test"  # type: ignore[index]
        assert r.matched_secret_index == 0

    def test_tampered_body_rejected(self) -> None:
        ts = int(time.time())
        header = _sign_legacy(SECRET, RAW, ts)
        tampered = RAW.replace("evt_test", "evt_hacked")
        r = verify(tampered, header, SECRET)
        assert r.valid is False
        assert r.reason == "mismatch"

    def test_wrong_secret_rejected(self) -> None:
        ts = int(time.time())
        header = _sign_legacy(SECRET, RAW, ts)
        r = verify(RAW, header, SECRET_BAD)
        assert r.valid is False
        assert r.reason == "mismatch"

    def test_expired_rejected(self) -> None:
        ts = int(time.time()) - 3600
        header = _sign_legacy(SECRET, RAW, ts)
        r = verify(RAW, header, SECRET, tolerance_seconds=300)
        assert r.valid is False
        assert r.reason == "expired"

    def test_empty_header_malformed(self) -> None:
        r = verify(RAW, "", SECRET)
        assert r.valid is False
        assert r.reason == "malformed"

    def test_rotation_grace_accepts_previous_secret(self) -> None:
        ts = int(time.time())
        # Signed with the OLD secret — caller passes [new, old]
        header = _sign_legacy(SECRET_2, RAW, ts)
        r = verify(RAW, header, [SECRET, SECRET_2])
        assert r.valid is True
        assert r.matched_secret_index == 1


# ─────────────────────────── Standard Webhooks ───────────────────────────


class TestVerifyFromHeaders:
    def setup_method(self) -> None:
        self._patcher = patch("time.time", return_value=1_777_000_000.0)
        self._patcher.start()

    def teardown_method(self) -> None:
        self._patcher.stop()

    def _std_headers(self, secret: str, body: str = RAW) -> dict[str, str]:
        ts = int(time.time())
        wid = "evt_test"
        return {
            "webhook-id": wid,
            "webhook-timestamp": str(ts),
            "webhook-signature": _sign_standard(secret, body, wid, ts),
        }

    def test_valid_standard_webhooks_payload(self) -> None:
        r = verify_from_headers(RAW, self._std_headers(SECRET), SECRET)
        assert r.valid is True
        assert r.event["type"] == "ping"  # type: ignore[index]

    def test_works_with_mixed_case_header_keys(self) -> None:
        h = self._std_headers(SECRET)
        # Simulate frameworks that normalize differently (Title-Case, all-caps, …)
        mixed = {"Webhook-Id": h["webhook-id"], "WEBHOOK-TIMESTAMP": h["webhook-timestamp"], "Webhook-Signature": h["webhook-signature"]}
        r = verify_from_headers(RAW, mixed, SECRET)
        assert r.valid is True

    def test_works_with_iterable_of_pairs(self) -> None:
        h = self._std_headers(SECRET)
        pairs = list(h.items())
        r = verify_from_headers(RAW, pairs, SECRET)
        assert r.valid is True

    def test_multiple_signatures_space_separated(self) -> None:
        ts = int(time.time())
        wid = "evt_test"
        good = _sign_standard(SECRET, RAW, wid, ts)
        decoy = "v1,not-a-valid-base64-sig"
        headers = {
            "webhook-id": wid,
            "webhook-timestamp": str(ts),
            "webhook-signature": f"{decoy} {good}",
        }
        r = verify_from_headers(RAW, headers, SECRET)
        assert r.valid is True

    def test_rotation_grace_accepts_previous_secret(self) -> None:
        # Signed with OLD secret, accept-list = [new, old]
        r = verify_from_headers(RAW, self._std_headers(SECRET_2), [SECRET, SECRET_2])
        assert r.valid is True
        assert r.matched_secret_index == 1

    def test_rotation_rejects_unknown_secret(self) -> None:
        r = verify_from_headers(RAW, self._std_headers(SECRET_BAD), [SECRET, SECRET_2])
        assert r.valid is False
        assert r.reason == "mismatch"

    def test_falls_back_to_legacy_when_std_headers_absent(self) -> None:
        ts = int(time.time())
        headers = {"x-coffrify-signature": _sign_legacy(SECRET, RAW, ts)}
        r = verify_from_headers(RAW, headers, SECRET)
        assert r.valid is True

    def test_no_headers_at_all(self) -> None:
        r = verify_from_headers(RAW, {}, SECRET)
        assert r.valid is False
        assert r.reason == "malformed"

    def test_tampered_body_rejected(self) -> None:
        r = verify_from_headers(RAW.replace("ok", "no"), self._std_headers(SECRET), SECRET)
        assert r.valid is False
        assert r.reason == "mismatch"

    def test_expired_rejected(self) -> None:
        # Build a header with an old timestamp
        ts = int(time.time()) - 600  # 10 min ago
        wid = "evt_test"
        headers = {
            "webhook-id": wid,
            "webhook-timestamp": str(ts),
            "webhook-signature": _sign_standard(SECRET, RAW, wid, ts),
        }
        r = verify_from_headers(RAW, headers, SECRET, tolerance_seconds=300)
        assert r.valid is False
        assert r.reason == "expired"


# ─────────────────────────── result API ───────────────────────────


def test_verify_result_dataclass_repr() -> None:
    r = VerifyResult(valid=True, reason=None, event={"type": "ping"}, matched_secret_index=0)
    assert r.valid is True
    assert r.event == {"type": "ping"}
