"""Coffrify exceptions."""

from typing import Any, Optional


class CoffrifyError(Exception):
    """Base Coffrify exception."""


class CoffrifyAPIError(CoffrifyError):
    """API returned an error response."""

    def __init__(
        self,
        message: str,
        status: int,
        code: Optional[str] = None,
        details: Optional[Any] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(message)
        self.status = status
        self.code = code
        self.details = details
        self.request_id = request_id

    def __repr__(self) -> str:
        return (
            f"CoffrifyAPIError(status={self.status}, code={self.code!r}, "
            f"message={str(self)!r}, request_id={self.request_id!r})"
        )
