"""
Coffrify Python SDK
~~~~~~~~~~~~~~~~~~~

Encrypted file transfer infrastructure.

>>> from coffrify import Coffrify
>>> client = Coffrify(api_key="cfy_live_...")
>>> transfer = client.transfers.create(
...     files=[{"name": "report.pdf", "size": 1240000}],
...     expires_in_hours=72,
...     password="secret",
... )
>>> print(transfer["share_url"])

Webhook verification :

>>> from coffrify.webhooks import verify
>>> result = verify(raw_body, signature_header, secret)
>>> if result.valid:
...     event = result.event
"""

from .client import Coffrify
from .errors import CoffrifyError, CoffrifyAPIError
from .webhooks import verify, verify_from_headers, VerifyResult

__version__ = "0.2.0"
__all__ = [
    "Coffrify",
    "CoffrifyError",
    "CoffrifyAPIError",
    "verify",
    "verify_from_headers",
    "VerifyResult",
]
