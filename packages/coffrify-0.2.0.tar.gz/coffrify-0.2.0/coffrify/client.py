"""Coffrify HTTP client with auto-retry and idempotency keys."""

from __future__ import annotations

import os
import time
import uuid
from typing import Any, Dict, Iterator, List, Optional

import requests

from .errors import CoffrifyAPIError

__version__ = "0.2.0"

RETRYABLE_STATUS = {408, 429, 500, 502, 503, 504}
WRITE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}


class _Resource:
    def __init__(self, client: "Coffrify"):
        self._client = client


class _Transfers(_Resource):
    def list(
        self,
        limit: int = 20,
        cursor: Optional[str] = None,
        offset: int = 0,
        status: Optional[str] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        elif offset:
            params["offset"] = offset
        if status:
            params["status"] = status
        return self._client._request("GET", "/transfers", params=params)

    def iterate(
        self,
        page_size: int = 50,
        status: Optional[str] = None,
        max_items: Optional[int] = None,
    ) -> Iterator[Dict[str, Any]]:
        """Cursor-paginated generator over the workspace's transfers."""
        page_size = max(1, min(page_size, 100))
        cursor: Optional[str] = None
        yielded = 0
        while True:
            page = self.list(limit=page_size, cursor=cursor, status=status)
            items = page.get("data") or page.get("transfers") or []
            if not items:
                return
            for it in items:
                if max_items is not None and yielded >= max_items:
                    return
                yield it
                yielded += 1
            if not page.get("has_more") or not page.get("next_cursor"):
                return
            cursor = page["next_cursor"]

    def get(self, transfer_id: str) -> Dict[str, Any]:
        return self._client._request("GET", f"/transfers/{transfer_id}")

    def create(
        self,
        files: List[Dict[str, Any]],
        expires_in_hours: Optional[int] = None,
        max_downloads: Optional[int] = None,
        password: Optional[str] = None,
        watermark_text: Optional[str] = None,
        burn_after_read: Optional[bool] = None,
        transfer_title: Optional[str] = None,
        notes: Optional[str] = None,
        ip_allowlist: Optional[List[str]] = None,
        geo_allowlist: Optional[List[str]] = None,
        require_totp: Optional[bool] = None,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        body = {"files": files}
        for k, v in [
            ("expires_in_hours", expires_in_hours),
            ("max_downloads", max_downloads),
            ("password", password),
            ("watermark_text", watermark_text),
            ("burn_after_read", burn_after_read),
            ("transfer_title", transfer_title),
            ("notes", notes),
            ("ip_allowlist", ip_allowlist),
            ("geo_allowlist", geo_allowlist),
            ("require_totp", require_totp),
        ]:
            if v is not None:
                body[k] = v
        return self._client._request("POST", "/transfers", json=body, idempotency_key=idempotency_key)

    def delete(self, transfer_id: str) -> Dict[str, Any]:
        return self._client._request("DELETE", f"/transfers/{transfer_id}")


class _Webhooks(_Resource):
    def list(self) -> Dict[str, Any]:
        return self._client._request("GET", "/webhooks")

    def create(self, name: str, url: str, events: List[str], description: Optional[str] = None) -> Dict[str, Any]:
        body = {"name": name, "url": url, "events": events}
        if description:
            body["description"] = description
        return self._client._request("POST", "/webhooks", json=body)

    def update(self, webhook_id: str, **updates) -> Dict[str, Any]:
        return self._client._request("PATCH", "/webhooks", json={"id": webhook_id, **updates})

    def delete(self, webhook_id: str) -> Dict[str, Any]:
        return self._client._request("DELETE", "/webhooks", json={"id": webhook_id})

    def deliveries(self, webhook_id: str, limit: int = 50) -> Dict[str, Any]:
        return self._client._request("GET", f"/webhooks/{webhook_id}/deliveries", params={"limit": limit})

    def test(
        self,
        webhook_id: str,
        event_type: Optional[str] = None,
        data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Send a sandbox event to the webhook.

        Defaults to a `ping`. Pass `event_type` to ship a representative
        payload for any catalog event (e.g. ``transfer.created``,
        ``api_key.revoked``). ``data`` overrides the default sample.
        Receiver gets ``X-Coffrify-Test-Delivery: true``.
        """
        body: Dict[str, Any] = {"id": webhook_id}
        if event_type is not None:
            body["event_type"] = event_type
        if data is not None:
            body["data"] = data
        return self._client._request("POST", "/webhooks?action=test", json=body)

    def rotate_secret(self, webhook_id: str, grace_hours: int = 24) -> Dict[str, Any]:
        """Rotate the webhook signing secret. Both old and new secrets stay
        valid for ``grace_hours`` (0…168, default 24).
        """
        return self._client._request(
            "POST",
            "/webhooks?action=rotate_secret",
            json={"id": webhook_id, "grace_hours": grace_hours},
        )

    def replay(self, delivery_id: str) -> Dict[str, Any]:
        """Replay a past delivery. Preserves the original ``event_id`` so
        receivers can dedupe via ``webhook-id``."""
        return self._client._request(
            "POST",
            "/webhooks?action=replay",
            json={"delivery_id": delivery_id},
        )


class _ApiKeys(_Resource):
    def list(self) -> Dict[str, Any]:
        return self._client._request("GET", "/api-keys")

    def create(
        self,
        name: str,
        scopes: Optional[List[str]] = None,
        environment: str = "live",
        expires_in_days: Optional[int] = None,
        allowed_ips: Optional[List[str]] = None,
        max_uses: Optional[int] = None,
    ) -> Dict[str, Any]:
        body = {"name": name, "environment": environment}
        for k, v in [
            ("scopes", scopes),
            ("expires_in_days", expires_in_days),
            ("allowed_ips", allowed_ips),
            ("max_uses", max_uses),
        ]:
            if v is not None:
                body[k] = v
        return self._client._request("POST", "/api-keys", json=body)

    def revoke(self, key_id: str) -> Dict[str, Any]:
        return self._client._request("DELETE", f"/api-keys/{key_id}")

    def rotate(self, key_id: str, grace_days: int = 7) -> Dict[str, Any]:
        """Rotate an API key. Returns the new ``key`` value; the previous key
        stays valid for ``grace_days`` (max 30) before being revoked.
        """
        return self._client._request(
            "POST",
            f"/api-keys/{key_id}/rotate",
            json={"grace_days": grace_days},
        )


class _Audit(_Resource):
    def list(
        self,
        action: Optional[str] = None,
        actor_id: Optional[str] = None,
        resource_type: Optional[str] = None,
        since: Optional[str] = None,
        until: Optional[str] = None,
        limit: int = 100,
        cursor: Optional[str] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {"limit": limit}
        for k, v in [
            ("action", action), ("actor_id", actor_id),
            ("resource_type", resource_type), ("since", since), ("until", until),
            ("cursor", cursor),
        ]:
            if v is not None:
                params[k] = v
        return self._client._request("GET", "/audit", params=params)

    def iterate(
        self,
        action: Optional[str] = None,
        actor_id: Optional[str] = None,
        resource_type: Optional[str] = None,
        since: Optional[str] = None,
        until: Optional[str] = None,
        page_size: int = 100,
        max_items: Optional[int] = None,
    ) -> Iterator[Dict[str, Any]]:
        """Cursor-paginated generator over audit log entries."""
        page_size = max(1, min(page_size, 500))
        cursor: Optional[str] = None
        yielded = 0
        while True:
            page = self.list(
                action=action, actor_id=actor_id, resource_type=resource_type,
                since=since, until=until, limit=page_size, cursor=cursor,
            )
            items = page.get("data") or page.get("entries") or []
            if not items:
                return
            for it in items:
                if max_items is not None and yielded >= max_items:
                    return
                yield it
                yielded += 1
            if not page.get("has_more") or not page.get("next_cursor"):
                return
            cursor = page["next_cursor"]


class Coffrify:
    """Coffrify API client.

    :param api_key: Your API key (cfy_live_... or cfy_test_...)
    :param api_url: Override API base URL (default https://api.coffrify.com)
    :param workspace_id: Optional workspace override
    :param timeout: Request timeout in seconds (default 30)
    :param max_retries: Auto-retry attempts on 5xx/429 (default 3)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_url: Optional[str] = None,
        workspace_id: Optional[str] = None,
        timeout: int = 30,
        max_retries: int = 3,
        retry_base_delay: float = 0.5,
        auto_idempotency: bool = True,
    ):
        api_key = api_key or os.environ.get("COFFRIFY_API_KEY")
        if not api_key:
            raise ValueError("api_key required (or set COFFRIFY_API_KEY env var)")
        if not api_key.startswith("cfy_"):
            raise ValueError("api_key must start with 'cfy_'")

        self.api_key = api_key
        self.api_url = (api_url or os.environ.get("COFFRIFY_API_URL") or "https://api.coffrify.com").rstrip("/")
        self.workspace_id = workspace_id
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_base_delay = retry_base_delay
        self.auto_idempotency = auto_idempotency

        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "User-Agent": f"coffrify-python/{__version__}",
        })

        self.transfers = _Transfers(self)
        self.webhooks = _Webhooks(self)
        self.api_keys = _ApiKeys(self)
        self.audit = _Audit(self)

    def _request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        url = f"{self.api_url}/v1{path}"
        if self.workspace_id:
            params = (params or {}).copy()
            params["workspace_id"] = self.workspace_id

        headers = {
            "X-Coffrify-Request-Id": str(uuid.uuid4()),
        }

        # Auto-inject Idempotency-Key on writes
        if method in WRITE_METHODS and self.auto_idempotency:
            if idempotency_key:
                headers["Idempotency-Key"] = idempotency_key
            else:
                headers["Idempotency-Key"] = str(uuid.uuid4())
        elif idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        last_error: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                resp = self._session.request(
                    method, url,
                    params=params,
                    json=json,
                    headers=headers,
                    timeout=self.timeout,
                )

                if resp.status_code < 400:
                    if not resp.content:
                        return {}
                    return resp.json()

                if resp.status_code in RETRYABLE_STATUS and attempt < self.max_retries:
                    time.sleep(self.retry_base_delay * (2 ** attempt))
                    continue

                # Parse error body
                try:
                    body = resp.json()
                    err = body.get("error", {}) if isinstance(body, dict) else {}
                    raise CoffrifyAPIError(
                        message=err.get("message") or f"HTTP {resp.status_code}",
                        status=resp.status_code,
                        code=err.get("code"),
                        details=body,
                        request_id=resp.headers.get("X-Request-Id"),
                    )
                except ValueError:
                    raise CoffrifyAPIError(
                        message=f"HTTP {resp.status_code}: {resp.text[:200]}",
                        status=resp.status_code,
                    )

            except requests.RequestException as e:
                last_error = e
                if attempt < self.max_retries:
                    time.sleep(self.retry_base_delay * (2 ** attempt))
                    continue
                raise CoffrifyAPIError(message=f"Network error: {e}", status=0) from e

        if last_error:
            raise last_error  # pragma: no cover
        raise CoffrifyAPIError(message="Unknown error", status=0)
