"""Webhook HMAC signature verification.

Two signature formats are supported :
  - Coffrify legacy : ``X-Coffrify-Signature: t=<ts>,v1=<hex_hmac>``
  - Standard Webhooks (https://www.standardwebhooks.com/) : three headers
        webhook-id        : <stable per-delivery id, also used for dedup>
        webhook-timestamp : <unix seconds>
        webhook-signature : v1,<base64 hmac>   (space-separated for rotation)

``verify_from_headers()`` auto-detects the format and verifies. Pass a
``list`` of secrets to ``verify`` to accept the previous secret during a
rotation grace window.
"""

from __future__ import annotations

import base64
import hmac
import hashlib
import json
import time
from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Optional, Sequence, Union


SIGNATURE_VERSION = "v1"


@dataclass
class VerifyResult:
    valid: bool
    reason: Optional[str] = None
    event: Optional[dict] = None
    matched_secret_index: Optional[int] = None


# ─────────────────────────── helpers ───────────────────────────


def _resolve_key(secret: str) -> bytes:
    """``whsec_<hex>`` → raw key bytes; otherwise the string encoded as UTF-8.

    Matches the convention used by the Coffrify server signer + the JS SDK.
    """
    if secret.startswith("whsec_") and len(secret) > 8:
        hexpart = secret[6:]
        try:
            return bytes.fromhex(hexpart)
        except ValueError:
            pass
    return secret.encode("utf-8")


def _normalize_secrets(secret_or_secrets: Union[str, Sequence[str]]) -> list[str]:
    if isinstance(secret_or_secrets, str):
        return [secret_or_secrets]
    return [s for s in secret_or_secrets if s]


def _try_load_event(raw_body: str) -> Optional[dict]:
    try:
        return json.loads(raw_body)
    except (json.JSONDecodeError, TypeError):
        return None


# ─────────────────────────── legacy verify ───────────────────────────


def verify(
    raw_body: str,
    signature_header: Optional[str],
    secret: Union[str, Sequence[str]],
    tolerance_seconds: int = 300,
) -> VerifyResult:
    """Verify the legacy ``X-Coffrify-Signature`` header.

    Pass a list of secrets to accept the previous secret during a rotation
    grace window. The first matching secret wins; its index is reported via
    ``matched_secret_index``.
    """
    if not signature_header:
        return VerifyResult(valid=False, reason="malformed")

    parts = [p.strip() for p in signature_header.split(",")]
    ts_part = next((p for p in parts if p.startswith("t=")), None)
    sig_part = next((p for p in parts if p.startswith(f"{SIGNATURE_VERSION}=")), None)
    if not ts_part or not sig_part:
        return VerifyResult(valid=False, reason="malformed")

    try:
        ts = int(ts_part[2:])
    except ValueError:
        return VerifyResult(valid=False, reason="invalid_timestamp")

    if abs(int(time.time()) - ts) > tolerance_seconds:
        return VerifyResult(valid=False, reason="expired")

    provided_hex = sig_part[len(SIGNATURE_VERSION) + 1 :]
    msg = f"{ts}.{raw_body}".encode("utf-8")

    secrets = _normalize_secrets(secret)
    if not secrets:
        return VerifyResult(valid=False, reason="no_secret")

    for idx, s in enumerate(secrets):
        expected = hmac.new(_resolve_key(s), msg, hashlib.sha256).hexdigest()
        if hmac.compare_digest(expected, provided_hex):
            event = _try_load_event(raw_body)
            return VerifyResult(valid=event is not None,
                                reason=None if event else "malformed",
                                event=event,
                                matched_secret_index=idx)

    return VerifyResult(valid=False, reason="mismatch")


# ─────────────────────────── Standard Webhooks verify ───────────────────────────


def _read_header(headers: Union[Mapping[str, Any], Iterable[tuple[str, Any]]], name: str) -> Optional[str]:
    """Case-insensitive header lookup. Accepts dict, list-of-pairs, or any Mapping."""
    if hasattr(headers, "items"):
        pairs = headers.items()  # type: ignore[union-attr]
    else:
        pairs = headers  # already an iterable of pairs
    lower = name.lower()
    for k, v in pairs:
        if str(k).lower() == lower:
            if isinstance(v, (list, tuple)):
                return str(v[0]) if v else None
            return str(v)
    return None


def verify_from_headers(
    raw_body: str,
    headers: Union[Mapping[str, Any], Iterable[tuple[str, Any]]],
    secret: Union[str, Sequence[str]],
    tolerance_seconds: int = 300,
) -> VerifyResult:
    """Verify a webhook from a request headers object.

    Auto-detects Standard Webhooks (``webhook-id`` / ``webhook-timestamp`` /
    ``webhook-signature``) vs the legacy Coffrify header. Standard Webhooks
    is preferred when present.

    Works with :class:`werkzeug.EnvironHeaders`, FastAPI ``request.headers``,
    Django ``request.headers``, plain ``dict``, or any Mapping.
    """
    secrets = _normalize_secrets(secret)
    if not secrets:
        return VerifyResult(valid=False, reason="no_secret")

    std_id = _read_header(headers, "webhook-id")
    std_ts = _read_header(headers, "webhook-timestamp")
    std_sig = _read_header(headers, "webhook-signature")

    if std_id and std_ts and std_sig:
        try:
            ts = int(std_ts)
        except ValueError:
            return VerifyResult(valid=False, reason="invalid_timestamp")
        if abs(int(time.time()) - ts) > tolerance_seconds:
            return VerifyResult(valid=False, reason="expired")

        candidates: list[str] = []
        for piece in std_sig.split():
            if piece.startswith(f"{SIGNATURE_VERSION},"):
                candidates.append(piece[len(SIGNATURE_VERSION) + 1 :])
        if not candidates:
            return VerifyResult(valid=False, reason="malformed")

        msg = f"{std_id}.{ts}.{raw_body}".encode("utf-8")
        for idx, s in enumerate(secrets):
            expected = hmac.new(_resolve_key(s), msg, hashlib.sha256).digest()
            for c in candidates:
                try:
                    provided = base64.b64decode(c, validate=False)
                except Exception:
                    continue
                if hmac.compare_digest(expected, provided):
                    event = _try_load_event(raw_body)
                    return VerifyResult(valid=event is not None,
                                        reason=None if event else "malformed",
                                        event=event,
                                        matched_secret_index=idx)
        return VerifyResult(valid=False, reason="mismatch")

    # Fallback to legacy header.
    legacy = _read_header(headers, "x-coffrify-signature")
    if legacy:
        return verify(raw_body, legacy, secret, tolerance_seconds)
    return VerifyResult(valid=False, reason="malformed")


__all__ = [
    "SIGNATURE_VERSION",
    "VerifyResult",
    "verify",
    "verify_from_headers",
]
