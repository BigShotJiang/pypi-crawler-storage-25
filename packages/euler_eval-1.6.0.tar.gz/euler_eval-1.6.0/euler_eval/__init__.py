"""Depth evaluation package."""
