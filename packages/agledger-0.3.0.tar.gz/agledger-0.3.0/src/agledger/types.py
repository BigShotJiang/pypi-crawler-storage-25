"""
AGLedger SDK — Type definitions.
Mirrors the TypeScript SDK types. All models are Pydantic v2.
"""

from __future__ import annotations

from typing import Any, Generic, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Contract Types
# ---------------------------------------------------------------------------

ContractType = Literal[
    "ACH-PROC-v1",
    "ACH-DLVR-v1",
    "ACH-DATA-v1",
    "ACH-TXN-v1",
    "ACH-ORCH-v1",
    "ACH-COMM-v1",
    "ACH-AUTH-v1",
    "ACH-INFRA-v1",
    "ACH-DEL-v1",
    "ACH-ANALYZE-v1",
    "ACH-COORD-v1",
    "ACH-MON-v1",
    "ACH-REVIEW-v1",
]

# ---------------------------------------------------------------------------
# Mandate
# ---------------------------------------------------------------------------

MandateStatus = Literal[
    "CREATED",
    "PROPOSED",
    "ACTIVE",
    "PROCESSING",
    "REVISION_REQUESTED",
    "FULFILLED",
    "FAILED",
    "REMEDIATED",
    "EXPIRED",
    "CANCELLED",
    "REJECTED",
]

MandateTransitionAction = Literal["register", "activate", "settle", "cancel", "refund"]

OperatingMode = Literal["cleartext", "encrypted"]
VerificationMode = Literal["auto", "principal", "gated"]
RiskClassification = Literal["high", "limited", "minimal", "unclassified"]


class Mandate(BaseModel):
    """A mandate — a registered commitment between a principal and a performer."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    """Unique mandate ID (UUID)."""
    enterprise_id: str = Field(alias="enterpriseId")
    """Enterprise that owns this mandate."""
    agent_id: str | None = Field(None, alias="agentId")
    """Agent assigned to this mandate."""
    contract_type: str = Field(alias="contractType")
    """Agentic Contract Specification type (e.g., 'ACH-PROC-v1')."""
    contract_version: str = Field(alias="contractVersion")
    """Version of the contract schema."""
    platform: str
    """Platform where this mandate operates."""
    platform_ref: str | None = Field(None, alias="platformRef")
    """External reference ID on the platform."""
    status: MandateStatus | str
    """Current lifecycle status."""
    criteria: dict[str, Any]
    """Acceptance criteria — what the performer must deliver."""
    tolerance: dict[str, Any] | None = None
    """Tolerance bands for numeric criteria."""
    deadline: str | None = None
    """ISO 8601 deadline for completion."""
    commission_pct: float | None = Field(None, alias="commissionPct")
    """Commission percentage for the performing agent."""
    operating_mode: OperatingMode | str | None = Field(None, alias="operatingMode")
    """Operating mode: cleartext (default) or encrypted."""
    verification_mode: VerificationMode | str | None = Field(None, alias="verificationMode")
    """Verification mode: auto, principal, or gated."""
    risk_classification: RiskClassification | str | None = Field(None, alias="riskClassification")
    """EU AI Act risk classification."""
    eu_ai_act_domain: str | None = Field(None, alias="euAiActDomain")
    """EU AI Act domain."""
    human_oversight: dict[str, Any] | None = Field(None, alias="humanOversight")
    """Human oversight configuration for EU AI Act compliance."""
    last_verdict_reason: str | None = Field(None, alias="lastVerdictReason")
    """Reason from the most recent principal verdict."""
    last_verdict_at: str | None = Field(None, alias="lastVerdictAt")
    """ISO 8601 timestamp of the most recent principal verdict."""
    acceptance_status: Literal["PROPOSED", "ACCEPTED", "REJECTED", "COUNTER_PROPOSED"] | None = Field(None, alias="acceptanceStatus")
    """Performer's response to a proposed mandate."""
    project_ref: str | None = Field(None, alias="projectRef")
    """Project grouping reference for related mandates."""
    parent_mandate_id: str | None = Field(None, alias="parentMandateId")
    """Parent mandate ID in a delegation chain."""
    root_mandate_id: str | None = Field(None, alias="rootMandateId")
    """Root mandate ID at the top of the delegation chain."""
    chain_depth: int | None = Field(None, alias="chainDepth")
    """Depth in the delegation chain (0 = root)."""
    last_transition_reason: str | None = Field(None, alias="lastTransitionReason")
    """Reason provided for the last state transition."""
    last_transition_by: str | None = Field(None, alias="lastTransitionBy")
    """Actor who triggered the last state transition."""
    submission_count: int = Field(alias="submissionCount")
    """Number of receipt submissions so far."""
    max_submissions: int | None = Field(None, alias="maxSubmissions")
    """Maximum allowed submissions, or None for unlimited."""
    version: int
    """Optimistic concurrency version."""
    created_at: str = Field(alias="createdAt")
    """ISO 8601 creation timestamp."""
    updated_at: str = Field(alias="updatedAt")
    """ISO 8601 last update timestamp."""
    activated_at: str | None = Field(None, alias="activatedAt")
    """ISO 8601 timestamp when the mandate was activated."""
    fulfilled_at: str | None = Field(None, alias="fulfilledAt")
    """ISO 8601 timestamp when the mandate was fulfilled."""
    next_actions: list[str] | None = Field(None, alias="nextActions")
    """Valid next actions from current state."""
    valid_transitions: list[str] | None = Field(None, alias="validTransitions")
    """Valid target statuses from current state."""
    receipt_hint: dict[str, Any] | None = Field(None, alias="receiptHint")
    """Hint for receipt evidence fields."""
    advisory_warnings: list[dict[str, Any]] | None = Field(None, alias="advisoryWarnings")
    """Advisory enforcement warnings."""
    schema_url: str | None = Field(None, alias="schemaUrl")
    """URL to the contract type schema definition."""
    verification_checks: dict[str, Any] | None = Field(None, alias="verificationChecks")
    """Verification check results."""
    verification_outcome: str | None = Field(None, alias="verificationOutcome")
    """Overall verification outcome: PASS, FAIL, or None."""
    principal_agent_id: str | None = Field(None, alias="principalAgentId")
    """Agent ID of the principal (for A2A mandates)."""
    principal_type: str | None = Field(None, alias="principalType")
    """Principal type: enterprise or agent."""
    child_mandate_ids: list[str] | None = Field(None, alias="childMandateIds")
    """IDs of child mandates in delegation chain."""
    commission_amount: float | None = Field(None, alias="commissionAmount")
    """Calculated commission amount."""
    constraint_inheritance: str | None = Field(None, alias="constraintInheritance")
    """Constraint inheritance mode from parent."""
    no_op: bool | None = Field(None, alias="noOp")
    """True when a transition was a no-op."""
    project_id: str | None = Field(None, alias="projectId")
    """Project ID for grouping related mandates."""
    external_task_id: str | None = Field(None, alias="externalTaskId")
    """External task ID from the caller's system."""
    depends_on: list[str] | None = Field(None, alias="dependsOn")
    """Mandate IDs this mandate depends on."""
    enforcement_overrides: dict[str, Any] | None = Field(None, alias="enforcementOverrides")
    """Per-field enforcement overrides."""
    metadata: dict[str, Any] | None = None
    """Arbitrary metadata attached to the mandate."""
    acceptance_responded_at: str | None = Field(None, alias="acceptanceRespondedAt")
    """ISO 8601 timestamp when performer responded to proposal."""
    references: list[dict[str, Any]] | None = None
    """External references attached to this mandate."""


# ---------------------------------------------------------------------------
# Receipt
# ---------------------------------------------------------------------------

class Receipt(BaseModel):
    """A receipt — structured evidence submitted by a performer."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    """Unique receipt ID."""
    mandate_id: str = Field(alias="mandateId")
    """Mandate this receipt is for."""
    agent_id: str = Field(alias="agentId")
    """Agent that submitted the receipt."""
    evidence: dict[str, Any]
    """Evidence of completion."""
    evidence_hash: str | None = Field(None, alias="evidenceHash")
    """SHA-256 hash of the evidence payload."""
    structural_validation: str | None = Field(None, alias="structuralValidation")
    """Structural validation result."""
    warnings: list[str] | None = None
    """Validation warnings."""
    mandate_status: MandateStatus | str | None = Field(None, alias="mandateStatus")
    """Mandate status after receipt submission."""
    validation_errors: list[str] | None = Field(None, alias="validationErrors")
    """Validation errors, if any."""
    idempotency_key: str | None = Field(None, alias="idempotencyKey")
    """Client-supplied idempotency key."""
    created_at: str = Field(alias="createdAt")
    """ISO 8601 creation timestamp."""


# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------


class VerificationResult(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    mandate_id: str = Field(alias="mandateId")
    receipts: list[dict[str, Any]] = Field(default_factory=list)
    overall_status: str = Field(alias="overallStatus")


# ---------------------------------------------------------------------------
# Disputes
# ---------------------------------------------------------------------------

DisputeStatus = Literal[
    "OPENED", "TIER_1_REVIEW", "EVIDENCE_WINDOW", "TIER_2_REVIEW",
    "ESCALATED", "TIER_3_ARBITRATION", "RESOLVED", "WITHDRAWN",
]


class Dispute(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    mandate_id: str = Field(alias="mandateId")
    initiated_by_role: str = Field(alias="initiatedByRole")
    initiated_by_id: str = Field(alias="initiatedById")
    grounds: str
    context: str | None = None
    status: DisputeStatus | str
    current_tier: int = Field(alias="currentTier")
    outcome: str | None = None
    resolution_rationale: str | None = Field(None, alias="resolutionRationale")
    fee_charged_to: str | None = Field(None, alias="feeChargedTo")
    fee_amount: float | None = Field(None, alias="feeAmount")
    fee_currency: str | None = Field(None, alias="feeCurrency")
    evidence_window_closes_at: str | None = Field(None, alias="evidenceWindowClosesAt")
    created_at: str = Field(alias="createdAt")
    resolved_at: str | None = Field(None, alias="resolvedAt")


# ---------------------------------------------------------------------------
# Webhooks
# ---------------------------------------------------------------------------

WebhookEventType = Literal[
    "mandate.created",
    "mandate.registered",
    "mandate.activated",
    "mandate.receipt_submitted",
    "mandate.receipt_invalid",
    "mandate.verification_complete",
    "mandate.fulfilled",
    "mandate.settled",
    "mandate.failed",
    "mandate.expired",
    "mandate.cancelled",
    "mandate.proposed",
    "mandate.proposal_accepted",
    "mandate.proposal_rejected",
    "mandate.delegated",
    "signal.emitted",
    "dispute.opened",
    "dispute.resolved",
    "proxy.session.synced",
    "proxy.mandate.detected",
    "proxy.mandate.formalized",
    "mandate.revision_requested",
    "federation.mandate.offered",
    "federation.mandate.accepted",
    "federation.mandate.state_changed",
    "federation.settlement.signal",
    "federation.gateway.registered",
    "federation.gateway.revoked",
    "mandate.reference_added",
    "agent.reference_added",
]


class Webhook(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    url: str
    event_types: list[str] | None = Field(None, alias="eventTypes")
    is_active: bool = Field(alias="isActive")
    format: str = "standard"
    secret: str | None = None
    created_at: str = Field(alias="createdAt")


# ---------------------------------------------------------------------------
# Outcome (Principal Verdict)
# ---------------------------------------------------------------------------


class OutcomeResult(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    mandate_id: str = Field(alias="mandateId")
    receipt_id: str = Field(alias="receiptId")
    outcome: str
    signal: str
    reporter_type: str = Field(alias="reporterType")
    reported_at: str = Field(alias="reportedAt")


# ---------------------------------------------------------------------------
# Mandate Summary
# ---------------------------------------------------------------------------


class MandateStatusSummary(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    counts_by_status: dict[str, int] = Field(alias="countsByStatus")
    total: int


# ---------------------------------------------------------------------------
# Compliance Records
# ---------------------------------------------------------------------------


class ComplianceRecord(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    mandate_id: str = Field(alias="mandateId")
    enterprise_id: str = Field(alias="enterpriseId")
    record_type: str = Field(alias="recordType")
    attestation: dict[str, Any]
    attested_by: str = Field(alias="attestedBy")
    attested_at: str = Field(alias="attestedAt")
    created_at: str = Field(alias="createdAt")


# ---------------------------------------------------------------------------
# Audit Stream (SIEM)
# ---------------------------------------------------------------------------


class AuditStreamResult(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    events: list[dict[str, Any]] = Field(default_factory=list)
    cursor: str | None = None
    has_more: bool = Field(False, alias="hasMore")


# ---------------------------------------------------------------------------
# Reputation
# ---------------------------------------------------------------------------


class ReputationScore(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    agent_id: str = Field(alias="agentId")
    contract_type: str = Field(alias="contractType")
    reliability_score: float = Field(alias="reliabilityScore")
    accuracy_score: float = Field(alias="accuracyScore")
    efficiency_score: float = Field(alias="efficiencyScore")
    composite_score: float = Field(alias="compositeScore")
    confidence_level: str = Field(alias="confidenceLevel")
    formula_version: str = Field(alias="formulaVersion")
    total_mandates: int = Field(alias="totalMandates")
    total_passed: int = Field(alias="totalPassed")
    total_verified: int = Field(alias="totalVerified")
    last_updated_at: str = Field(alias="lastUpdatedAt")


# ---------------------------------------------------------------------------
# Events
# ---------------------------------------------------------------------------


class Event(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    mandate_id: str = Field(alias="mandateId")
    event_type: str = Field(alias="eventType")
    actor: str
    actor_id: str | None = Field(None, alias="actorId")
    timestamp: str
    changes: dict[str, Any] | None = None
    details: dict[str, Any] | None = None


class AuditChain(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    mandate_id: str = Field(alias="mandateId")
    chain_start: str = Field(alias="chainStart")
    entries: list[dict[str, Any]] = Field(default_factory=list)
    is_valid: bool = Field(alias="isValid")


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------


class DashboardSummary(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    total_mandates: int = Field(alias="totalMandates")
    active_count: int = Field(alias="activeCount")
    fulfilled_count: int = Field(alias="fulfilledCount")
    disputed_count: int = Field(alias="disputedCount")


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

AccountType = Literal["enterprise", "agent", "platform"]


class AccountProfile(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    api_key_id: str = Field(alias="apiKeyId")
    role: AccountType | str
    owner_id: str = Field(alias="ownerId")
    owner_type: str = Field(alias="ownerType")
    trust_level: str = Field(alias="trustLevel")
    scopes: list[str] | None = None
    name: str | None = None
    email: str | None = None
    verified_at: str | None = Field(None, alias="verifiedAt")
    created_at: str | None = Field(None, alias="createdAt")


class RegisterResult(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    api_key: str = Field(alias="apiKey")
    sandbox_mode: bool = Field(alias="sandboxMode")
    verification_required: str = Field(alias="verificationRequired")


# ---------------------------------------------------------------------------
# Enterprise Agent Approval
# ---------------------------------------------------------------------------


class EnterpriseAgentRecord(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    enterprise_id: str = Field(alias="enterpriseId")
    agent_id: str = Field(alias="agentId")
    display_name: str | None = Field(None, alias="displayName")
    status: str
    created_at: str = Field(alias="createdAt")
    updated_at: str | None = Field(None, alias="updatedAt")


# ---------------------------------------------------------------------------
# Pagination
# ---------------------------------------------------------------------------

T = TypeVar("T")


class Page(BaseModel, Generic[T]):
    """Unified page type for all list endpoints."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    data: list[T]  # type: ignore[type-var]
    has_more: bool = Field(alias="hasMore")
    next_cursor: str | None = Field(None, alias="nextCursor")
    total: int | None = None


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


class HealthResponse(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    status: str
    version: str | None = None
    uptime: float | None = None
    database: str | None = None
    timestamp: str


class StatusComponent(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    name: str
    status: str
    latency_ms: float | None = Field(None, alias="latencyMs")


class StatusResponse(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    status: str
    components: list[StatusComponent] = []
    active_incidents: list[dict[str, Any]] = Field(default=[], alias="activeIncidents")
    uptime: float
    timestamp: str


class ConformanceResponse(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    protocol_version: str = Field(alias="protocolVersion")
    features: list[str] = []
    contract_types: list[str] = Field(default=[], alias="contractTypes")
    max_batch_size: int | None = Field(None, alias="maxBatchSize")
    rate_limits: dict[str, Any] | None = Field(None, alias="rateLimits")


# ---------------------------------------------------------------------------
# A2A Protocol
# ---------------------------------------------------------------------------


class AgentCard(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    name: str
    description: str | None = None
    url: str
    capabilities: dict[str, Any] | None = None
    skills: list[dict[str, Any]] | None = None


# ---------------------------------------------------------------------------
# Agent Profile
# ---------------------------------------------------------------------------


class AgentProfile(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    name: str
    slug: str
    agent_class: str | None = Field(None, alias="agentClass")
    owner_ref: str | None = Field(None, alias="ownerRef")
    org_unit: str | None = Field(None, alias="orgUnit")
    description: str | None = None
    enterprise_id: str | None = Field(None, alias="enterpriseId")
    trust_level: str = Field(alias="trustLevel")
    verification_method: str | None = Field(None, alias="verificationMethod")
    agent_card_url: str | None = Field(None, alias="agentCardUrl")
    created_at: str = Field(alias="createdAt")
    updated_at: str = Field(alias="updatedAt")


# ---------------------------------------------------------------------------
# Verification Status
# ---------------------------------------------------------------------------


class VerificationStatus(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    mandate_id: str = Field(alias="mandateId")
    status: str
    outcome: str | None = None
    signal: str | None = None


# ---------------------------------------------------------------------------
# Webhook Ping
# ---------------------------------------------------------------------------


class WebhookTestResult(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    success: bool
    status_code: int | None = Field(None, alias="statusCode")
    response_time_ms: int | None = Field(None, alias="responseTimeMs")


# ---------------------------------------------------------------------------
# Dashboard Detail Types
# ---------------------------------------------------------------------------


class DashboardAlert(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    severity: str
    message: str
    created_at: str = Field(alias="createdAt")


class DashboardAgent(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    name: str
    trust_level: str = Field(alias="trustLevel")
    mandate_count: int = Field(0, alias="mandateCount")


# ---------------------------------------------------------------------------
# Project
# ---------------------------------------------------------------------------


class Project(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    name: str
    description: str | None = None
    status: str = "active"
    enterprise_id: str = Field(alias="enterpriseId")
    created_at: str = Field(alias="createdAt")
    updated_at: str = Field(alias="updatedAt")


# ---------------------------------------------------------------------------
# Capabilities
# ---------------------------------------------------------------------------


class AgentCapabilities(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    agent_id: str = Field(alias="agentId")
    capabilities: list[str] = []


# ---------------------------------------------------------------------------
# Compliance Export
# ---------------------------------------------------------------------------


class ComplianceExport(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    status: str
    format: str
    created_at: str = Field(alias="createdAt")
    download_url: str | None = Field(None, alias="downloadUrl")


class AiImpactAssessment(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    mandate_id: str = Field(alias="mandateId")
    risk_level: str = Field(alias="riskLevel")
    domain: str
    human_oversight: bool | None = Field(None, alias="humanOversight")
    created_at: str = Field(alias="createdAt")


class EuAiActReport(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    mandates_assessed: int = Field(0, alias="mandatesAssessed")
    high_risk_count: int = Field(0, alias="highRiskCount")
    generated_at: str = Field(alias="generatedAt")
