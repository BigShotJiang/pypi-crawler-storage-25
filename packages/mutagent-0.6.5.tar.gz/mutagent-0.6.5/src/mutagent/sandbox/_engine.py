"""执行引擎 — 黑名单 builtins + REPL 语义。"""

import ast
import builtins
import io
import traceback as _tb_mod
from contextlib import redirect_stdout, redirect_stderr
from typing import Any


# 必须排除的 builtins（安全边界）
_BLOCKED_BUILTINS = frozenset({
    'eval', 'exec', 'compile', '__import__',
    'open', 'breakpoint', 'input',
    'exit', 'quit', 'help',
})

# 从 builtins 模块取全集，排除黑名单
_SAFE_BUILTINS = {
    name: getattr(builtins, name)
    for name in dir(builtins)
    if not name.startswith('_') and name not in _BLOCKED_BUILTINS
}
# 保留 __build_class__（class 语句需要）和 __name__
_SAFE_BUILTINS['__build_class__'] = builtins.__build_class__
_SAFE_BUILTINS['__name__'] = '<pysandbox>'


def execute(code: str, namespace: dict[str, Any],
            state: dict[str, Any] | None = None) -> dict[str, Any]:
    """在受限环境中执行 Python 代码。

    Args:
        code: 要执行的 Python 代码
        namespace: 注入的函数和对象（命名空间对象、自省函数等）
        state: 跨步骤共享状态（REPL 模式）。None 时变量存入临时 dict

    Returns:
        {"result": Any, "stdout": str, "stderr": str}
        失败时返回 {"error": str, "traceback": str}
    """
    # 构建 globals：安全 builtins + 注入的命名空间
    globals_dict = {}
    globals_dict['__builtins__'] = dict(_SAFE_BUILTINS)
    globals_dict.update(namespace)

    # locals 用于 REPL 状态保持
    locals_dict = state if state is not None else {}

    stdout_buf = io.StringIO()
    stderr_buf = io.StringIO()

    try:
        with redirect_stdout(stdout_buf), redirect_stderr(stderr_buf):
            # REPL 语义：最后一条表达式自动返回值
            tree = ast.parse(code, '<pysandbox>', 'exec')

            # AST 检查：禁止 import
            for node in ast.walk(tree):
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    raise SyntaxError("import statements are not supported")

            last_expr_value = None
            if tree.body and isinstance(tree.body[-1], ast.Expr):
                last_expr = tree.body.pop()
                if tree.body:
                    exec(compile(ast.Module(body=tree.body, type_ignores=[]),
                                 '<pysandbox>', 'exec'),
                         globals_dict, locals_dict)
                last_expr_value = eval(
                    compile(ast.Expression(body=last_expr.value),
                            '<pysandbox>', 'eval'),
                    globals_dict, locals_dict)
            else:
                exec(compile(tree, '<pysandbox>', 'exec'),
                     globals_dict, locals_dict)

            # 优先使用显式 result 变量
            result = locals_dict.get('result')
            if result is None:
                result = last_expr_value

        return {
            "result": result,
            "stdout": stdout_buf.getvalue(),
            "stderr": stderr_buf.getvalue(),
        }

    except SyntaxError as e:
        return {"error": f"SyntaxError: {e}", "traceback": ""}
    except Exception as e:
        tb = _filter_traceback(e)
        return {"error": f"{type(e).__name__}: {e}", "traceback": tb}


def _filter_traceback(exc: BaseException) -> str:
    """过滤 traceback，去掉引擎入口帧，保留 <pysandbox> 及其下游所有帧。"""
    frames = _tb_mod.extract_tb(exc.__traceback__)
    # 找到第一个 <pysandbox> 帧，从那里开始保留
    start = next((i for i, f in enumerate(frames) if f.filename == '<pysandbox>'), None)
    if start is None:
        return ""
    kept = frames[start:]
    # 外部函数帧：隐藏文件路径，只保留函数名
    cleaned = []
    for f in kept:
        if f.filename != '<pysandbox>':
            cleaned.append(_tb_mod.FrameSummary('<external>', 0, f.name))
        else:
            cleaned.append(f)
    lines = ["Traceback (most recent call last):"]
    lines.extend(_tb_mod.format_list(cleaned))
    return "".join(lines).rstrip()
