"""ISCWSA error models for computing wellbore positional uncertainty."""

import os
import numpy as np
import yaml
from .errors.tool_errors import ToolError
from .utils import cov_from_vec

# TODO: there's likely an issue with TVD versus TVDSS that
# needs to be resolved. This model assumes TVD relative to
# rig floor, but often a TVDSS is provided instead (with a
# negative value for rig floor elevation).

ACCURACY = 1e-4
PATH = os.path.dirname(__file__)
TOOL_INDEX_FILENAME = os.path.join(
    '', *[PATH, 'errors', 'tool_index.yaml']
)


def get_tool_index():
    """Load the tool error model index from the bundled YAML file.

    Returns
    -------
    dict
        Mapping of tool model names to their configuration parameters.
    """
    with open(TOOL_INDEX_FILENAME, 'r') as f:
        tool_index = yaml.safe_load(f)
    return tool_index


def get_error_models(tool_index=None):
    """Return a list of available error model short names.

    Parameters
    ----------
    tool_index : dict, optional
        Pre-loaded tool index dict. If None, loads from disk.

    Returns
    -------
    list of str
        Short names of all registered error models.
    """
    if tool_index is None:
        tool_index = get_tool_index()
    error_models = [
        v['Short Name']
        for _, v in tool_index.items()
    ]
    return error_models


TOOL_INDEX = get_tool_index()
ERROR_MODELS = get_error_models(TOOL_INDEX)


class ErrorModel():
    """
    A class to initiate the field parameters and error magnitudes
    for subsequent error calculations.

    Attributes
    ----------
    error_model : str
        Name of the error model used (e.g. ``'ISCWSA MWD Rev5'``).
    survey : welleng.survey.Survey
        The input Survey object.
    errors : welleng.errors.tool_errors.ToolError
        ToolError object containing per-source error magnitudes and
        covariance data.
    survey_rad : numpy.ndarray
        Array of (md, inc_rad, azi_true_rad) per station, shape (n, 3).
    drdp : numpy.ndarray
        Jacobian of position with respect to survey parameters (depth,
        inclination, azimuth) in NEV coordinates.
    cov_NEVs : numpy.ndarray
        Summed covariance matrices in NEV coordinates per station, shape
        (n, 3, 3). Accessible via ``errors.cov_NEVs``.
    """

    class Error:
        '''
        Standard components of a well bore survey error.
        '''
        def __init__(
            self,
            code,
            propagation,
            e_DIA,
            cov_DIA,
            e_NEV,
            e_NEV_star,
            sigma_e_NEV,
            cov_NEV
        ):
            """Initialize an Error with computed error vectors and covariances.

            Parameters
            ----------
            code : str
                The error source code identifier.
            propagation : str
                Propagation type ('systematic', 'random', 'global',
                or 'within_pad').
            e_DIA : numpy.ndarray
                Error vectors in Depth-Inclination-Azimuth coordinates.
            cov_DIA : numpy.ndarray
                Covariance matrices in DIA coordinates.
            e_NEV : numpy.ndarray
                Error vectors in North-East-Vertical coordinates.
            e_NEV_star : numpy.ndarray
                Single-station NEV error vectors.
            sigma_e_NEV : numpy.ndarray
                Cumulative NEV error vectors.
            cov_NEV : numpy.ndarray
                Covariance matrices in NEV coordinates.
            """
            self.code = code
            self.propagation = propagation
            self.e_DIA = e_DIA
            self.cov_DIA = cov_DIA
            self.e_NEV = e_NEV
            self.e_NEV_star = e_NEV_star
            self.sigma_e_NEV = sigma_e_NEV
            self.cov_NEV = cov_NEV

    def __init__(
        self,
        survey,
        error_model="ISCWSA MWD Rev5",
    ):
        """Initialize the error model for a given survey.

        Parameters
        ----------
        survey : welleng.survey.Survey
            The survey to compute errors for.
        error_model : str, optional
            Name of the error model to apply.
        """

        # error_models = ERROR_MODELS
        assert error_model in ERROR_MODELS, "Unrecognized error model"
        self.error_model = error_model
        self.survey = survey

        self.survey_rad = np.stack((
            self.survey.md,
            self.survey.inc_rad,
            self.survey.azi_true_rad
        ), axis=-1)

        self.survey_drdp = self.survey_rad
        self.drdp = self._drdp(self.survey_drdp)
        self.drdp_sing = self._drdp_sing(self.survey_drdp)

        # if self.error_model.split("_")[0] == "iscwsa":
        #     self.errors = iscwsaMwd(
        #         error=self,
        #         model=self.error_model
        #     )

        for k, v in TOOL_INDEX.items():
            if v['Short Name'] == self.error_model:
                model = k
                break

        self.errors = ToolError(
            error=self,
            model=model
        )

    def _e_NEV(self, e_DIA):
        D, I, A = e_DIA.T
        arr = np.column_stack([
            (self.drdp[:, 0] + self.drdp[:, 9]) * D
            + (self.drdp[:, 3] + self.drdp[:, 12]) * I
            + (self.drdp[:, 6] + self.drdp[:, 15]) * A,

            (self.drdp[:, 1] + self.drdp[:, 10]) * D
            + (self.drdp[:, 4] + self.drdp[:, 13]) * I
            + (self.drdp[:, 7] + self.drdp[:, 16]) * A,

            (self.drdp[:, 2] + self.drdp[:, 11]) * D
            + (self.drdp[:, 5] + self.drdp[:, 14]) * I
            + (self.drdp[:, 8] + self.drdp[:, 17]) * A,
        ])

        arr[0] = 0

        return arr

    def _e_NEV_star(self, e_DIA):
        D, I, A = e_DIA.T
        arr = np.column_stack([
            self.drdp[:, 0] * D
            + self.drdp[:, 3] * I
            + self.drdp[:, 6] * A,

            self.drdp[:, 1] * D
            + self.drdp[:, 4] * I
            + self.drdp[:, 7] * A,

            self.drdp[:, 2] * D
            + self.drdp[:, 5] * I
            + self.drdp[:, 8] * A
        ])

        arr[0] = 0

        return arr

    def _sigma_e_NEV_systematic(self, e_NEV, e_NEV_star):
        return e_NEV_star + np.vstack(
            (
                e_NEV[0],
                np.cumsum(e_NEV, axis=0)[:-1]
            )
        )

    def _generate_error(
        self,
        code,
        e_DIA,
        propagation='systematic',
        NEV=True,
        e_NEV=None,
        e_NEV_star=None
    ):
        if not NEV:
            return e_DIA
        else:
            cov_DIA = cov_from_vec(e_DIA)
            if e_NEV is None:
                e_NEV = self._e_NEV(e_DIA)
                e_NEV_star = self._e_NEV_star(e_DIA)
            if propagation in ('systematic', 'global', 'within_pad'):
                sigma_e_NEV = self._sigma_e_NEV_systematic(e_NEV, e_NEV_star)
                cov_NEV = cov_from_vec(sigma_e_NEV)
            elif propagation == 'random':
                sigma_e_NEV = np.cumsum(cov_from_vec(e_NEV), axis=0)
                cov_NEV = np.add(
                    cov_from_vec(e_NEV_star),
                    np.concatenate(
                        (
                            np.zeros((1, 3, 3)),
                            sigma_e_NEV[:-1]
                        ), axis=0)
                    )
            else:
                return

            return ErrorModel.Error(
                code,
                propagation,
                e_DIA,
                cov_DIA,
                e_NEV,
                e_NEV_star,
                sigma_e_NEV,
                cov_NEV
            )

    def drk_dDepth(self, survey):
        """Derivative of position with respect to measured depth at each station.

        Equal to 0.5 * (unit_vec[i] + unit_vec[i+1]) in NEV coordinates --
        the direction-cosine part of minimum curvature without the RF or
        delta_md.

        Parameters
        ----------
        survey : array_like
            Survey stations as (md, inc_rad, azi_rad) rows.

        Returns
        -------
        numpy.ndarray
            Shape (n, 3) array of NEV derivatives.
        """
        _, inc1, azi1 = np.array(survey[:-1]).T
        _, inc2, azi2 = np.array(survey[1:]).T
        si1, si2 = np.sin(inc1), np.sin(inc2)
        ca1, ca2 = np.cos(azi1), np.cos(azi2)
        sa1, sa2 = np.sin(azi1), np.sin(azi2)
        NEV = 0.5 * np.stack((
            si1 * ca1 + si2 * ca2,       # N
            si1 * sa1 + si2 * sa2,       # E
            np.cos(inc1) + np.cos(inc2), # V
        ), axis=-1)
        return np.vstack((np.zeros((1, 3)), NEV))

    def drk_dInc(self, survey):
        """Derivative of position with respect to inclination at each station.

        Parameters
        ----------
        survey : array_like
            Survey stations as (md, inc_rad, azi_rad) rows.

        Returns
        -------
        numpy.ndarray
            Shape (n, 3) array of NEV derivatives.
        """
        md1, inc1, azi1 = np.array(survey[:-1]).T
        md2, inc2, azi2 = np.array(survey[1:]).T
        delta_md = md2 - md1

        N = np.array(0.5 * ((delta_md) * np.cos(inc2) * np.cos(azi2)))
        E = np.array(0.5 * ((delta_md) * np.cos(inc2) * np.sin(azi2)))
        V = np.array(0.5 * (-delta_md * np.sin(inc2)))

        if self.error_model.lower().split()[-1] != 'rev4':
            N[0] *= 2

        return np.vstack(
            (
                np.array(np.zeros((1, 3))),
                np.stack((N, E, V), axis=-1)
            )
        )

    def drk_dAz(self, survey):
        """Derivative of position with respect to azimuth at each station.

        Parameters
        ----------
        survey : array_like
            Survey stations as (md, inc_rad, azi_rad) rows.

        Returns
        -------
        numpy.ndarray
            Shape (n, 3) array of NEV derivatives.
        """
        md1, inc1, azi1 = np.array(survey[:-1]).T
        md2, inc2, azi2 = np.array(survey[1:]).T
        delta_md = md2 - md1

        N = np.array(-0.5 * ((delta_md) * np.sin(inc2) * np.sin(azi2)))
        E = np.array(0.5 * ((delta_md) * np.sin(inc2) * np.cos(azi2)))
        V = np.zeros_like(N)

        return np.vstack(
            (
                np.array(np.zeros((1, 3))),
                np.stack((N, E, V), axis=-1)
            )
        )

    def drkplus1_dDepth(self, survey):
        """Derivative of next-station position with respect to measured depth.

        Parameters
        ----------
        survey : array_like
            Survey stations as (md, inc_rad, azi_rad) rows.

        Returns
        -------
        numpy.ndarray
            Shape (n, 3) array of NEV derivatives.
        """
        return np.vstack(
            (
                self.drk_dDepth(survey)[1:] * -1,
                np.array(np.zeros((1, 3)))
            )
        )

    def drkplus1_dInc(self, survey):
        """Derivative of next-station position with respect to inclination.

        Parameters
        ----------
        survey : array_like
            Survey stations as (md, inc_rad, azi_rad) rows.

        Returns
        -------
        numpy.ndarray
            Shape (n, 3) array of NEV derivatives.
        """

        md2, inc2, azi2 = np.array(survey[:-1]).T
        md3, inc3, azi3 = np.array(survey[1:]).T
        delta_md = md3 - md2

        N = np.array(0.5 * ((delta_md) * np.cos(inc2) * np.cos(azi2)))
        E = np.array(0.5 * ((delta_md) * np.cos(inc2) * np.sin(azi2)))
        V = np.array(0.5 * (-(delta_md) * np.sin(inc2)))

        return np.vstack(
            (
                np.stack((N, E, V), axis=-1),
                np.array(np.zeros((1, 3)))
            )
        )

    def drkplus1_dAz(self, survey):
        """Derivative of next-station position with respect to azimuth.

        Parameters
        ----------
        survey : array_like
            Survey stations as (md, inc_rad, azi_rad) rows.

        Returns
        -------
        numpy.ndarray
            Shape (n, 3) array of NEV derivatives.
        """
        md2, inc2, azi2 = np.array(survey[:-1]).T
        md3, inc3, azi3 = np.array(survey[1:]).T
        delta_md = md3 - md2

        N = np.array(-0.5 * ((delta_md) * np.sin(inc2) * np.sin(azi2)))
        E = np.array(0.5 * ((delta_md) * np.sin(inc2) * np.cos(azi2)))
        V = np.zeros_like(N)

        return np.vstack(
            (
                np.stack((N, E, V), axis=-1),
                np.array(np.zeros((1, 3)))
            )
        )

    def _drdp(self, survey):
        '''
        Jacobian of position wrt survey parameters, computed in a single trig
        pass.  Returns array of shape (n, 18): columns 0-2 drk_dDepth,
        3-5 drk_dInc, 6-8 drk_dAz, 9-11 drkplus1_dDepth,
        12-14 drkplus1_dInc, 15-17 drkplus1_dAz.
        '''
        survey = np.array(survey)
        n = len(survey)
        md, inc, azi = survey.T
        si, ci = np.sin(inc), np.cos(inc)
        sa, ca = np.sin(azi), np.cos(azi)
        half_dmd = 0.5 * np.diff(md)          # shape (n-1,)

        result = np.zeros((n, 18))

        # drk_dDepth: rows 1..n-1
        dc_N = 0.5 * (si[:-1] * ca[:-1] + si[1:] * ca[1:])
        dc_E = 0.5 * (si[:-1] * sa[:-1] + si[1:] * sa[1:])
        dc_V = 0.5 * (ci[:-1] + ci[1:])
        result[1:, 0] = dc_N
        result[1:, 1] = dc_E
        result[1:, 2] = dc_V

        # drk_dInc: rows 1..n-1 (wrt inc at station i+1)
        result[1:, 3] = half_dmd * ci[1:] * ca[1:]
        result[1:, 4] = half_dmd * ci[1:] * sa[1:]
        result[1:, 5] = -half_dmd * si[1:]
        if self.error_model.lower().split()[-1] != 'rev4':
            result[1, 3] *= 2

        # drk_dAz: rows 1..n-1 (wrt azi at station i+1)
        result[1:, 6] = -half_dmd * si[1:] * sa[1:]
        result[1:, 7] = half_dmd * si[1:] * ca[1:]

        # drkplus1_dDepth: rows 0..n-2 (negated dc)
        result[:-1, 9]  = -dc_N
        result[:-1, 10] = -dc_E
        result[:-1, 11] = -dc_V

        # drkplus1_dInc: rows 0..n-2 (wrt inc at station i)
        result[:-1, 12] = half_dmd * ci[:-1] * ca[:-1]
        result[:-1, 13] = half_dmd * ci[:-1] * sa[:-1]
        result[:-1, 14] = -half_dmd * si[:-1]

        # drkplus1_dAz: rows 0..n-2 (wrt azi at station i)
        result[:-1, 15] = -half_dmd * si[:-1] * sa[:-1]
        result[:-1, 16] = half_dmd * si[:-1] * ca[:-1]

        return result

    def _drdp_sing(self, survey):
        '''
        survey1 is previous survey station (with inc and azi in radians)
        survey2 is current survey station
        survey3 is next survey station (with inc and azi in radians)
        '''
        md1, inc1, azi1 = np.array(survey[:-2]).T
        md2, inc2, azi2 = np.array(survey[1:-1]).T
        md3, inc3, azi3 = np.array(survey[2:]).T
        double_delta_md = md3 - md1
        delta_md = md2 - md1

        return dict(
            double_delta_md=double_delta_md,
            delta_md=delta_md,
            azi2=azi2
        )


def get_errors(error):
    """Extract the six unique covariance components from a 3x3 NEV matrix.

    Parameters
    ----------
    error : numpy.ndarray
        A 3x3 covariance matrix in NEV coordinates.

    Returns
    -------
    list
        [nn, ee, vv, ne, nv, ev] covariance components.
    """
    nn, ne, nv = error[0]
    _, ee, ev = error[1]
    _, __, vv = error[2]

    return [nn, ee, vv, ne, nv, ev]


def make_diagnostic_data(survey):
    """Build a per-station diagnostic breakdown of all error model components.

    Parameters
    ----------
    survey : welleng.survey.Survey
        A welleng Survey with an attached ErrorModel (survey.err).

    Returns
    -------
    dict
        Nested dict keyed by MD, then error code, containing the six
        unique covariance components and a TOTAL row summing all codes.
    """
    diagnostic = {}
    dia = np.stack((survey.md, survey.inc_deg, survey.azi_grid_deg), axis=1)
    for i, d in enumerate(survey.md):
        diagnostic[d] = {}
        total = []
        for k, v in survey.err.errors.errors.items():
            diagnostic[d][k] = get_errors(v.cov_NEV[i])
            total.extend(diagnostic[d][k])
        diagnostic[d]['TOTAL'] = np.sum((np.array(
            total
        ).reshape(-1, len(diagnostic[d][k]))), axis=0)
    return diagnostic
