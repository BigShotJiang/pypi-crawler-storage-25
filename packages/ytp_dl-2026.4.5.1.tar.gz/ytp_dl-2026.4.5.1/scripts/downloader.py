#!/usr/bin/env python3
from __future__ import annotations

import os
import shlex
import shutil
import subprocess
import time
import signal
import threading
from collections import deque
from typing import Callable, Deque, List, Optional, Tuple
from urllib.parse import urlparse

# =========================
# Config / constants
# =========================
VENV_PATH = os.environ.get("YTPDL_VENV", "/opt/yt-dlp-mullvad/venv")
YTDLP_BIN = os.path.join(VENV_PATH, "bin", "yt-dlp")
MULLVAD_LOCATION = os.environ.get("YTPDL_MULLVAD_LOCATION", "us")

MODERN_UA = os.environ.get(
    "YTPDL_USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36",
)

FFMPEG_BIN = shutil.which("ffmpeg") or "ffmpeg"
DEFAULT_OUT_DIR = os.environ.get("YTPDL_DOWNLOAD_DIR", "/root")

# Hard timeout for a single job (kills stuck yt-dlp/ffmpeg). Set 0 to disable.
JOB_TIMEOUT_S = int(os.environ.get("YTPDL_JOB_TIMEOUT_S", "1800"))

# Keep error payloads readable.
_MAX_ERR_LINES = 80
_MAX_ERR_CHARS = 4000


# =========================
# Shell helpers
# =========================
def _run_argv_capture(argv: List[str]) -> Tuple[int, str]:
    res = subprocess.run(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    return res.returncode, (res.stdout or "")


def _run_argv(argv: List[str], check: bool = True) -> str:
    rc, out = _run_argv_capture(argv)
    if check and rc != 0:
        cmd = " ".join(shlex.quote(p) for p in argv)
        raise RuntimeError(f"Command failed: {cmd}\n{out}")
    return out


def _tail(out: str) -> str:
    lines = (out or "").splitlines()
    tail_lines = lines[-_MAX_ERR_LINES:]
    txt = "\n".join(tail_lines)
    if len(txt) > _MAX_ERR_CHARS:
        txt = txt[-_MAX_ERR_CHARS:]
    return txt.strip()


# =========================
# Environment / Mullvad
# =========================
def validate_environment() -> None:
    if not os.path.exists(YTDLP_BIN):
        raise RuntimeError(f"yt-dlp not found at {YTDLP_BIN}")
    if shutil.which(FFMPEG_BIN) is None:
        raise RuntimeError("ffmpeg not found on PATH")


def _mullvad_present() -> bool:
    return shutil.which("mullvad") is not None


def mullvad_logged_in() -> bool:
    if not _mullvad_present():
        return False
    res = subprocess.run(
        ["mullvad", "account", "get"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    return "not logged in" not in (res.stdout or "").lower()


def require_mullvad_login() -> None:
    if _mullvad_present() and not mullvad_logged_in():
        raise RuntimeError("Mullvad not logged in. Run: mullvad account login <ACCOUNT>")


def mullvad_connect(location: Optional[str] = None) -> None:
    if not _mullvad_present():
        return
    loc = (location or MULLVAD_LOCATION).strip()
    _run_argv(["mullvad", "disconnect"], check=False)
    if loc:
        _run_argv(["mullvad", "relay", "set", "location", loc], check=False)
    _run_argv(["mullvad", "connect"], check=False)


def mullvad_wait_connected(timeout: int = 20) -> bool:
    if not _mullvad_present():
        return True
    for _ in range(timeout):
        res = subprocess.run(
            ["mullvad", "status"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        if "Connected" in (res.stdout or ""):
            return True
        time.sleep(1)
    return False


# =========================
# Provider helpers
# =========================
def _hostname(url: str) -> str:
    try:
        return (urlparse(url).hostname or "").lower()
    except Exception:
        return ""


def _is_soundcloud_url(url: str) -> bool:
    host = _hostname(url)
    return host == "soundcloud.com" or host.endswith(".soundcloud.com")


# =========================
# yt-dlp helpers (streaming-only)
# =========================
def _common_flags() -> List[str]:
    # --no-playlist prevents accidental channel/playlist pulls
    return [
        "--no-playlist",
        "--retries",
        "10",
        "--fragment-retries",
        "10",
        "--retry-sleep",
        "exp=1:30",
        "--user-agent",
        MODERN_UA,
        "--no-cache-dir",
        "--ignore-config",
        "--embed-metadata",
        "--sleep-interval",
        "1",
    ]


def _extract_final_path_from_tail(stdout: str, out_dir: str) -> Optional[str]:
    candidates: List[str] = []
    out_dir = os.path.abspath(out_dir)

    for raw in (stdout or "").splitlines():
        line = (raw or "").strip()
        if not line:
            continue

        if os.path.isabs(line) and line.startswith(out_dir):
            candidates.append(line.strip("'\""))
            continue

        if "Merging formats into" in line and "\"" in line:
            try:
                merged = line.split("Merging formats into", 1)[1].strip()
                if merged.startswith("\"") and merged.endswith("\""):
                    merged = merged[1:-1]
                elif merged.startswith("\""):
                    merged = merged.split("\"", 2)[1]
                if merged:
                    if not os.path.isabs(merged):
                        merged = os.path.join(out_dir, merged)
                    candidates.append(merged.strip("'\""))
            except Exception:
                pass
            continue

        if "Destination:" in line:
            try:
                p = line.split("Destination:", 1)[1].strip().strip("'\"")
                if p and not os.path.isabs(p):
                    p = os.path.join(out_dir, p)
                if p:
                    candidates.append(p)
            except Exception:
                pass
            continue

        if "] " in line and " has already been downloaded" in line:
            try:
                p = (
                    line.split("] ", 1)[1]
                    .split(" has already been downloaded", 1)[0]
                    .strip()
                    .strip("'\"")
                )
                if p and not os.path.isabs(p):
                    p = os.path.join(out_dir, p)
                if p:
                    candidates.append(p)
            except Exception:
                pass

    for p in reversed(candidates):
        if p and os.path.exists(p):
            return os.path.abspath(p)

    try:
        best_path = None
        best_mtime = -1.0
        for name in os.listdir(out_dir):
            if name.endswith((".part", ".ytdl", ".tmp")):
                continue
            full = os.path.join(out_dir, name)
            if not os.path.isfile(full):
                continue
            mt = os.path.getmtime(full)
            if mt > best_mtime:
                best_mtime = mt
                best_path = full
        if best_path:
            return os.path.abspath(best_path)
    except Exception:
        pass

    return None


def _build_ytdlp_argv(
    *,
    url: str,
    out_dir: str,
    fmt: str,
    merge_output_format: Optional[str],
    extract_mp3: bool,
) -> List[str]:
    out_dir = os.path.abspath(out_dir)
    out_tpl = os.path.join(out_dir, "%(title)s.%(ext)s")

    argv = [
        YTDLP_BIN,
        "-f",
        fmt,
        *(_common_flags()),
        "--output",
        out_tpl,
        "--print",
        "after_move:filepath",
        "--progress",
        "--newline",
        "--no-color",
    ]

    if extract_mp3:
        argv.extend(
            [
                "--extract-audio",
                "--audio-format",
                "mp3",
                "--audio-quality",
                "0",
            ]
        )

    if merge_output_format:
        argv.extend(["--merge-output-format", merge_output_format])

    argv.append(url)
    return argv


def _download_with_format_stream(
    *,
    url: str,
    out_dir: str,
    fmt: str,
    merge_output_format: Optional[str],
    extract_mp3: bool,
    on_line: Callable[[str], None],
) -> str:
    out_dir = os.path.abspath(out_dir)
    os.makedirs(out_dir, exist_ok=True)

    argv = _build_ytdlp_argv(
        url=url,
        out_dir=out_dir,
        fmt=fmt,
        merge_output_format=merge_output_format,
        extract_mp3=extract_mp3,
    )

    tail_lines: Deque[str] = deque(maxlen=_MAX_ERR_LINES)
    candidates: List[str] = []

    def _maybe_add_candidate(p: str) -> None:
        p = (p or "").strip().strip("'\"")
        if not p:
            return
        if not os.path.isabs(p):
            p = os.path.join(out_dir, p)
        candidates.append(p)

    proc = subprocess.Popen(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        start_new_session=True,
    )

    assert proc.stdout is not None

    stop_killer = threading.Event()

    def _killer():
        t = int(JOB_TIMEOUT_S)
        if t <= 0:
            return
        if stop_killer.wait(t):
            return
        if proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

    threading.Thread(target=_killer, daemon=True).start()

    try:
        for line in proc.stdout:
            s = (line or "").rstrip("\n")
            if not s:
                continue

            on_line(s)
            tail_lines.append(s)

            if os.path.isabs(s) and s.startswith(out_dir):
                _maybe_add_candidate(s)

            if "Merging formats into" in s and "\"" in s:
                try:
                    merged = s.split("Merging formats into", 1)[1].strip()
                    if merged.startswith("\"") and merged.endswith("\""):
                        merged = merged[1:-1]
                    elif merged.startswith("\""):
                        merged = merged.split("\"", 2)[1]
                    _maybe_add_candidate(merged)
                except Exception:
                    pass

            if "Destination:" in s:
                try:
                    p = s.split("Destination:", 1)[1].strip()
                    _maybe_add_candidate(p)
                except Exception:
                    pass

        rc = proc.wait()
    finally:
        stop_killer.set()
        try:
            proc.stdout.close()
        except Exception:
            pass

    for p in reversed(candidates):
        if p and os.path.exists(p):
            return os.path.abspath(p)

    tail_txt = "\n".join(tail_lines)
    final_path = _extract_final_path_from_tail(tail_txt, out_dir)
    if final_path and os.path.exists(final_path):
        return os.path.abspath(final_path)

    if rc != 0:
        raise RuntimeError(f"yt-dlp failed (format: {fmt})\n{_tail(tail_txt)}")
    raise RuntimeError(f"Download completed but output file not found (format: {fmt})\n{_tail(tail_txt)}")


def _fmt_mp4_apple_safe(cap: int) -> str:
    return (
        f"bv*[height<={cap}][ext=mp4][vcodec~='^(avc1|h264)']"
        f"+ba[ext=m4a][acodec~='^mp4a']"
        f"/b[height<={cap}][ext=mp4][vcodec~='^(avc1|h264)'][acodec~='^mp4a']"
    )


def _fmt_best(cap: int) -> str:
    return f"bv*[height<={cap}]+ba/b[height<={cap}]"


def _fmt_soundcloud_audio_safe() -> str:
    """
    Prefer direct/non-HLS audio first for SoundCloud, then fall back.
    This avoids relying on a fragmented/HLS variant when a cleaner
    progressive source is available.
    """
    return (
        "bestaudio[protocol!=m3u8_native][protocol!=m3u8][ext=mp3]"
        "/bestaudio[protocol!=m3u8_native][protocol!=m3u8][ext=m4a]"
        "/bestaudio[protocol!=m3u8_native][protocol!=m3u8]"
        "/bestaudio"
    )


def download_video(
    *,
    url: str,
    resolution: int | None = 1080,
    extension: Optional[str] = None,
    out_dir: str = DEFAULT_OUT_DIR,
    on_line: Callable[[str], None],
) -> str:
    if not url:
        raise RuntimeError("Missing URL")

    out_dir = os.path.abspath(out_dir)
    os.makedirs(out_dir, exist_ok=True)

    validate_environment()

    require_mullvad_login()
    mullvad_connect(MULLVAD_LOCATION)
    if not mullvad_wait_connected():
        raise RuntimeError("Mullvad connection failed")

    try:
        mode = (extension or "mp4").lower().strip()
        cap = int(resolution or 1080)

        if mode == "mp3":
            if _is_soundcloud_url(url):
                on_line("[info] SoundCloud detected; preferring direct audio source before MP3 extraction.")
                try:
                    return _download_with_format_stream(
                        url=url,
                        out_dir=out_dir,
                        fmt=_fmt_soundcloud_audio_safe(),
                        merge_output_format=None,
                        extract_mp3=True,
                        on_line=on_line,
                    )
                except Exception as first_error:
                    on_line("[info] SoundCloud direct-audio preference failed; falling back to generic bestaudio.")
                    on_line(f"[debug] {first_error}")
                    return _download_with_format_stream(
                        url=url,
                        out_dir=out_dir,
                        fmt="bestaudio",
                        merge_output_format=None,
                        extract_mp3=True,
                        on_line=on_line,
                    )

            return _download_with_format_stream(
                url=url,
                out_dir=out_dir,
                fmt="bestaudio",
                merge_output_format=None,
                extract_mp3=True,
                on_line=on_line,
            )

        if mode == "best":
            try:
                return _download_with_format_stream(
                    url=url,
                    out_dir=out_dir,
                    fmt=_fmt_best(cap),
                    merge_output_format=None,
                    extract_mp3=False,
                    on_line=on_line,
                )
            except Exception:
                return _download_with_format_stream(
                    url=url,
                    out_dir=out_dir,
                    fmt=_fmt_mp4_apple_safe(cap),
                    merge_output_format="mp4",
                    extract_mp3=False,
                    on_line=on_line,
                )

        return _download_with_format_stream(
            url=url,
            out_dir=out_dir,
            fmt=_fmt_mp4_apple_safe(cap),
            merge_output_format="mp4",
            extract_mp3=False,
            on_line=on_line,
        )

    finally:
        if _mullvad_present():
            _run_argv(["mullvad", "disconnect"], check=False)