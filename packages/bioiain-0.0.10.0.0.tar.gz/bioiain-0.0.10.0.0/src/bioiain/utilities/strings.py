
from unidecode import unidecode
from ..utilities.logging import log



def clean_string(string:str, allow:list[str]=(".", "_"), remove_newlines:bool=True) -> str:
    """
    Remove unwanted characters from string.
    :param string: String to clean
    :param allow: List of special characters allowed (default ".", "_")
    :param remove_newlines: whether tho remove "\n" (default True)
    :return: Clean string
    """
    string = unidecode(str(string))
    if remove_newlines:
        string = string.replace("\n", "")
    r = ''.join(e for e in string if e.isalnum() or e in allow)
    return r


def get_digits(string:str, allow:list[str]=("."), integer:bool= False):
    """
    Parse digits within a string as int or float.
    :param string: Target string
    :param allow: List of special characters to allow (default ".")
    :param integer: Parse as int, default False -> parsed as float
    :return: Parsed int/float
    """
    try:
        if integer:
            return int(''.join(e for e in unidecode(str(string)) if e.isdigit() or e in allow))
        else:
            return float(''.join(e for e in unidecode(str(string)) if e.isdigit() or e in allow))
    except:
        log("warning", "No digits found in: {}".format(string))
        log(0, ''.join(e for e in unidecode(str(string)) if e.isdigit() or e in allow))
        return None



def string_to_list(line:str, delimiter:str=" ") -> list:
    """
    Split string by the specified delimiter. Empty (or \n) are removed.
    :param line: String to split
    :param delimiter: Delimiter to split at (default " ")
    :return: List of strings
    """
    l = line.split(delimiter)
    nl = []
    for c in l:
        c = c.strip()
        if c == "" or c == "\n":
            continue
        nl.append(c)
    return nl


def add_front_0(string, digits=2, zero = "0"):
    ret = ""
    string = str(string)
    for i in range(digits-len(string)):
        ret += zero
    ret += string
    return ret



def str_to_list_with_literals(str, delimiter=" ", literal_delimiters=["\"","\'"], keep_delimiters=False, remove=["\n"],
                              check_open_literal=False) -> list|tuple[list, bool]:
    out = []
    for r in remove:
        str = str.replace(r, "")
    str = str.strip()
    strings = str.split(delimiter)
    in_literal = False
    literal_delim = None
    literal = None
    #print("IN:", strings)

    for n, s in enumerate(strings):
        #print(n, s)
        if s == "":
            if in_literal:
                literal += delimiter
                print(repr(literal))
            continue
        if s[0] in literal_delimiters and not in_literal:
            in_literal = True
            literal_delim = s[0]
            if not keep_delimiters:
                s = s[1:]
            literal = ""
        if s == "":
            continue
        if s[-1] == literal_delim:
            literal_delim = None
            if not keep_delimiters:
                s = s[:-1]
        if in_literal:
            literal += delimiter+s
        else:
            if s in remove:
                continue
            out.append(s)
            continue
        if in_literal and literal_delim is None:
            in_literal = False
            out.append(literal)
    if in_literal:
        out.append(literal)
    #print("OUT:", out)
    if check_open_literal:
        return out, in_literal
    return out




