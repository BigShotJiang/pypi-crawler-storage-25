# SPDX-FileCopyrightText: 2024-present Leander (lpnlp202111) <leander.lacroix.dev@protonmail.com>
#
# SPDX-License-Identifier: MIT

from importlib.metadata import version

from .dataproxy import DataProxy
from .fitparameters import FitParameters

__all__ = ["__version__", "DataProxy", "FitParameters"]

__version__ = version("saltworks")
