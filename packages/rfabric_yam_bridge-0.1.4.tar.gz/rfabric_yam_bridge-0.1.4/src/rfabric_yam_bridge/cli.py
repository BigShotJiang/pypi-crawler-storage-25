"""Command-line entry point for the standalone YAM bridge.

Two modes, picked by which CAN flags are supplied:

* **Single-arm**: ``--can-channel can0`` (and optionally ``--gripper``).
  The bridge runs a single un-tagged arm; control payloads with no
  ``arm`` field land here.
* **Bimanual**: ``--left-channel can0 --right-channel can1`` (and the
  matching gripper flags). The bridge runs two arms tagged ``left`` /
  ``right``; control payloads must carry a matching ``arm`` field.

Mixing the two modes is rejected so an operator typo can't silently
spawn the wrong arm topology.
"""

from __future__ import annotations

import argparse
import logging
import signal
from collections.abc import Sequence
from pathlib import Path

from rfabric_yam_bridge.arm import (
    DEFAULT_GRIPPER_VELOCITY_GAIN,
    DEFAULT_VELOCITY_GAIN_RAD_PER_S,
    YamArm,
    YamArmConfig,
    make_yam_arm,
)
from rfabric_yam_bridge.bridge import (
    DEFAULT_INTEGRATION_HZ,
    DEFAULT_SOCKET_MODE,
    DEFAULT_SOCKET_PATH,
    DEFAULT_STATE_PUBLISH_HZ,
    DEFAULT_WATCHDOG_MS,
    BridgeConfig,
    YamBridge,
)

LOG = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# argparse
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rfabric-yam-bridge",
        description="Bridge i2rt YAM arms onto the rFabric realtime control UDS.",
    )

    # Single-arm flags
    parser.add_argument(
        "--can-channel",
        help="CAN interface for a single-arm setup (e.g. can0). Mutually exclusive with --left-channel/--right-channel.",
    )
    parser.add_argument("--arm-type", default="yam", help="i2rt ArmType for a single-arm setup (default: yam).")
    parser.add_argument(
        "--gripper",
        default="linear_4310",
        help="i2rt GripperType for a single-arm setup (default: linear_4310).",
    )
    parser.add_argument(
        "--home",
        type=_parse_joint_floats,
        default={},
        metavar="JOINT=RAD[,JOINT=RAD...]",
        help="Per-joint home pose for a single-arm setup (default: all zeros).",
    )
    parser.add_argument(
        "--velocity-gain",
        type=_parse_joint_floats,
        default={},
        metavar="JOINT=RAD/S[,JOINT=RAD/S...]",
        help=(
            "Per-joint rad/s gain at full normalised input for a single-arm setup. "
            f"Defaults: arm joints = {DEFAULT_VELOCITY_GAIN_RAD_PER_S} rad/s, "
            f"gripper = {DEFAULT_GRIPPER_VELOCITY_GAIN}."
        ),
    )

    # Bimanual flags — mirror the single-arm set with --left-/--right- prefixes.
    for arm in ("left", "right"):
        parser.add_argument(
            f"--{arm}-channel",
            help=f"CAN interface for the {arm} arm in a bimanual setup.",
        )
        parser.add_argument(
            f"--{arm}-arm-type",
            default="yam",
            help=f"i2rt ArmType for the {arm} arm (default: yam).",
        )
        parser.add_argument(
            f"--{arm}-gripper",
            default="linear_4310",
            help=f"i2rt GripperType for the {arm} arm (default: linear_4310).",
        )
        parser.add_argument(
            f"--{arm}-home",
            type=_parse_joint_floats,
            default={},
            metavar="JOINT=RAD[,JOINT=RAD...]",
            help=f"Per-joint home pose for the {arm} arm.",
        )
        parser.add_argument(
            f"--{arm}-velocity-gain",
            type=_parse_joint_floats,
            default={},
            metavar="JOINT=RAD/S[,JOINT=RAD/S...]",
            help=f"Per-joint rad/s gain at full normalised input for the {arm} arm.",
        )

    # Bridge-wide knobs
    parser.add_argument(
        "--socket-path",
        type=Path,
        default=DEFAULT_SOCKET_PATH,
        help="UDS path the rFabric agent connects into (default: $XDG_RUNTIME_DIR/rfabric/control.sock).",
    )
    parser.add_argument(
        "--socket-mode",
        type=lambda value: int(value, 8),
        default=DEFAULT_SOCKET_MODE,
        help=f"Octal socket-file permissions (default: {oct(DEFAULT_SOCKET_MODE)}).",
    )
    parser.add_argument(
        "--integration-hz",
        type=float,
        default=DEFAULT_INTEGRATION_HZ,
        help=f"Frequency of the bridge's velocity → position integration tick (default: {DEFAULT_INTEGRATION_HZ:g} Hz).",
    )
    parser.add_argument(
        "--state-publish-hz",
        type=float,
        default=DEFAULT_STATE_PUBLISH_HZ,
        help=f"Frequency at which observations are mirrored back to the agent (default: {DEFAULT_STATE_PUBLISH_HZ:g} Hz).",
    )
    parser.add_argument(
        "--watchdog-ms",
        type=int,
        default=DEFAULT_WATCHDOG_MS,
        help=f"Per-arm freshness window before the bridge zeroes velocity (default: {DEFAULT_WATCHDOG_MS} ms).",
    )
    parser.add_argument(
        "--log-level",
        default="info",
        choices=["debug", "info", "warning", "error"],
        help="Log level for the bridge process.",
    )

    return parser


def _parse_joint_floats(value: str) -> dict[str, float]:
    """Parse ``joint1=0.5,gripper=0.0`` into ``{'joint1': 0.5, 'gripper': 0.0}``."""

    result: dict[str, float] = {}
    for raw_token in value.split(","):
        token = raw_token.strip()
        if not token:
            continue
        joint, separator, magnitude = token.partition("=")
        if not separator or not joint or not magnitude:
            raise argparse.ArgumentTypeError(f"expected JOINT=NUMBER, got {raw_token!r}")
        try:
            result[joint.strip()] = float(magnitude)
        except ValueError as err:
            raise argparse.ArgumentTypeError(f"could not parse {raw_token!r} as JOINT=NUMBER") from err
    return result


# ---------------------------------------------------------------------------
# Wiring
# ---------------------------------------------------------------------------


def _build_arms(args: argparse.Namespace) -> list[YamArm]:
    single = args.can_channel is not None
    bimanual = args.left_channel is not None or args.right_channel is not None
    if single and bimanual:
        raise SystemExit(
            "rfabric-yam-bridge: --can-channel cannot be combined with --left-channel/--right-channel"
        )
    if not single and not bimanual:
        raise SystemExit(
            "rfabric-yam-bridge: pass --can-channel for single-arm or --left-channel and --right-channel for bimanual"
        )
    if bimanual and (args.left_channel is None or args.right_channel is None):
        raise SystemExit("rfabric-yam-bridge: bimanual mode requires both --left-channel and --right-channel")

    if single:
        config = YamArmConfig(
            can_channel=args.can_channel,
            arm_type_name=args.arm_type,
            gripper_type_name=args.gripper,
            home_pose=args.home,
            velocity_gain=args.velocity_gain,
        )
        return [make_yam_arm(tag="", config=config)]

    arms: list[YamArm] = []
    for arm_tag in ("left", "right"):
        config = YamArmConfig(
            can_channel=getattr(args, f"{arm_tag}_channel"),
            arm_type_name=getattr(args, f"{arm_tag}_arm_type"),
            gripper_type_name=getattr(args, f"{arm_tag}_gripper"),
            home_pose=getattr(args, f"{arm_tag}_home"),
            velocity_gain=getattr(args, f"{arm_tag}_velocity_gain"),
        )
        arms.append(make_yam_arm(tag=arm_tag, config=config))
    return arms


def _build_bridge_config(args: argparse.Namespace) -> BridgeConfig:
    return BridgeConfig(
        socket_path=args.socket_path,
        socket_mode=args.socket_mode,
        integration_hz=args.integration_hz,
        state_publish_hz=args.state_publish_hz,
        watchdog_ms=args.watchdog_ms,
    )


def _install_signal_handlers(bridge: YamBridge) -> None:
    def _handle(_signum: int, _frame: object) -> None:
        LOG.info("rfabric_yam_bridge: signal received, shutting down")
        bridge.shutdown()

    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, _handle)


def main(argv: Sequence[str] | None = None) -> None:
    args = _build_parser().parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    arms = _build_arms(args)
    bridge = YamBridge(config=_build_bridge_config(args), arms=arms)
    _install_signal_handlers(bridge)
    bridge.start()
    bridge.run_forever()


if __name__ == "__main__":
    main()
