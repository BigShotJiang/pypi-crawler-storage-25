"""Apply an operator-side `ControlPayload` to a `YamArm`'s state.

The mapping rule is uniform across payload kinds:

* **Position-shaped** (`joint_targets`, `joint_deltas`, `home`) update
  ``arm.latest_target`` directly and zero ``arm.latest_velocity``.
* **Velocity-shaped** (`joint_velocity`) updates ``arm.latest_velocity``
  and leaves ``arm.latest_target`` to be advanced by the bridge's
  integration tick.
* **Cartesian** (`end_effector`) runs IK on the arm slice, writes the
  converged joints back into ``arm.latest_target``, and overrides the
  gripper slot from the discrete operator state.
* **Hold** (`stop`, watchdog stale, malformed) zeroes
  ``arm.latest_velocity`` and leaves ``latest_target`` unchanged so the
  next integration tick replays the last good pose.

This module is the single place where wire-shaped operator payloads
become i2rt-shaped numeric updates — every other module sees only
``arm.latest_target`` / ``arm.latest_velocity``.
"""

from __future__ import annotations

import logging
import time

import numpy as np

from rfabric_control_wire import (
    GRIPPER_CLOSE,
    GRIPPER_HOLD,
    GRIPPER_OPEN,
    ControlPayload,
    EndEffectorPayload,
    HeartbeatPayload,
    HomePayload,
    JointDeltasPayload,
    JointTargetsPayload,
    JointVelocityPayload,
    StopPayload,
)

from rfabric_yam_bridge.arm import HOME_INTERPOLATION_SECONDS, YamArm

LOG = logging.getLogger(__name__)


def apply_payload(arm: YamArm, payload: ControlPayload) -> None:
    """Update `arm`'s control state from the parsed `payload`.

    Heartbeat payloads are accepted and ignored (they only refresh the
    arm's freshness clock so the watchdog doesn't trip on a quiet
    operator stream).
    """

    if isinstance(payload, JointTargetsPayload):
        _apply_joint_targets(arm, payload)
    elif isinstance(payload, JointDeltasPayload):
        _apply_joint_deltas(arm, payload)
    elif isinstance(payload, JointVelocityPayload):
        _apply_joint_velocity(arm, payload)
    elif isinstance(payload, EndEffectorPayload):
        _apply_end_effector(arm, payload)
    elif isinstance(payload, StopPayload):
        _apply_stop(arm)
    elif isinstance(payload, HomePayload):
        _apply_home(arm)
    elif isinstance(payload, HeartbeatPayload):
        _refresh_liveness(arm)
    else:
        LOG.warning("rfabric_yam_bridge: arm %r received unhandled payload %r", arm.tag, payload)
        _apply_stop(arm)


def hold_position(arm: YamArm) -> None:
    """Watchdog cue: zero velocity, leave the cached target alone.

    The integration tick replays ``latest_target`` every cycle, so this
    naturally collapses into "freeze where we last commanded".
    """

    with arm.lock():
        arm.latest_velocity = np.zeros_like(arm.latest_velocity)


# ----------------------------------------------------------------------
# Position-shaped payloads
# ----------------------------------------------------------------------


def _apply_joint_targets(arm: YamArm, payload: JointTargetsPayload) -> None:
    target = _vector_from_joint_dict(arm, payload.joints, base=arm.latest_target)
    with arm.lock():
        arm.latest_target = target
        arm.latest_velocity = np.zeros_like(arm.latest_velocity)
    _refresh_control(arm)


def _apply_joint_deltas(arm: YamArm, payload: JointDeltasPayload) -> None:
    delta = _vector_from_joint_dict(arm, payload.joints, base=np.zeros(arm.num_dofs))
    with arm.lock():
        arm.latest_target = arm.latest_target + delta
        arm.latest_velocity = np.zeros_like(arm.latest_velocity)
    _refresh_control(arm)


def _apply_home(arm: YamArm) -> None:
    home_target = arm.home_target_vector()
    # `move_joints` is a blocking interpolation in i2rt; we drive it
    # directly so the operator gets a smooth predictable approach
    # rather than a single 100 Hz integration step that would clip to
    # `latest_target += latest_velocity * dt` on the next tick.
    arm.robot.move_joints(home_target, time_interval_s=HOME_INTERPOLATION_SECONDS)
    with arm.lock():
        arm.latest_target = home_target.copy()
        arm.latest_velocity = np.zeros_like(arm.latest_velocity)
    _refresh_control(arm)


# ----------------------------------------------------------------------
# Velocity-shaped payloads
# ----------------------------------------------------------------------


def _apply_joint_velocity(arm: YamArm, payload: JointVelocityPayload) -> None:
    normalised = _vector_from_joint_dict(arm, payload.joints, base=np.zeros(arm.num_dofs))
    velocity = normalised * arm.velocity_gain_vector()
    with arm.lock():
        arm.latest_velocity = velocity
    _refresh_control(arm)


# ----------------------------------------------------------------------
# Cartesian payload
# ----------------------------------------------------------------------


def _apply_end_effector(arm: YamArm, payload: EndEffectorPayload) -> None:
    solver = arm.get_ik_solver()
    if solver is None:
        LOG.warning(
            "rfabric_yam_bridge: arm %r received `end_effector` but no IK model is available; holding",
            arm.tag,
        )
        hold_position(arm)
        return
    arm_joints = arm.arm_joints_view()
    delta = np.array([payload.delta_x, payload.delta_y, payload.delta_z], dtype=float)
    result = solver.step(arm_joints=arm_joints, delta_xyz=delta)
    if not result.success:
        # Solver did not converge — fall back to a hold so the watchdog
        # keeps charge of safety.
        hold_position(arm)
        return
    new_target = arm.latest_target.copy()
    arm_count = result.arm_joints.shape[0]
    new_target[:arm_count] = result.arm_joints
    if arm.has_gripper:
        assert arm.gripper_index is not None
        gripper_low, gripper_high = _gripper_bounds(arm)
        new_target[arm.gripper_index] = _gripper_state_to_target(payload.gripper, gripper_low, gripper_high)
    with arm.lock():
        arm.latest_target = new_target
        arm.latest_velocity = np.zeros_like(arm.latest_velocity)
    _refresh_control(arm)


def _gripper_bounds(arm: YamArm) -> tuple[float, float]:
    limits = arm.joint_limits
    if arm.gripper_index is None or limits is None:
        return (0.0, 1.0)
    low, high = float(limits[arm.gripper_index, 0]), float(limits[arm.gripper_index, 1])
    if np.isnan(low) or np.isnan(high):
        return (0.0, 1.0)
    return low, high


def _gripper_state_to_target(state: int, low: float, high: float) -> float:
    if state == GRIPPER_OPEN:
        return high
    if state == GRIPPER_CLOSE:
        return low
    if state == GRIPPER_HOLD:
        return (low + high) * 0.5
    return (low + high) * 0.5


# ----------------------------------------------------------------------
# Hold
# ----------------------------------------------------------------------


def _apply_stop(arm: YamArm) -> None:
    hold_position(arm)
    _refresh_control(arm)


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------


def _refresh_control(arm: YamArm) -> None:
    """Mark that a motion command just arrived. The watchdog checks this."""
    now = time.monotonic()
    arm.last_payload_at = now
    arm.last_control_at = now


def _refresh_liveness(arm: YamArm) -> None:
    """Mark that a heartbeat arrived. Does NOT reset the motion watchdog."""
    arm.last_payload_at = time.monotonic()


def _vector_from_joint_dict(
    arm: YamArm,
    joints: dict[str, float],
    base: np.ndarray,
) -> np.ndarray:
    """Layer per-joint values onto a base vector following i2rt's ordering.

    Unknown joint names raise — silently dropping them would let an
    operator UI typo turn into an unnoticed missed-axis command.
    """

    vector = np.array(base, dtype=float, copy=True)
    if vector.shape != (arm.num_dofs,):
        raise ValueError(
            f"base vector shape {vector.shape} mismatches arm DoFs {(arm.num_dofs,)}"
        )
    for joint_name, value in joints.items():
        if joint_name not in arm.joint_names:
            LOG.warning(
                "rfabric_yam_bridge: arm %r received unknown joint %r in payload; ignoring",
                arm.tag,
                joint_name,
            )
            continue
        vector[arm.joint_names.index(joint_name)] = float(value)
    return vector
