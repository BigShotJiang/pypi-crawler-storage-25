"""Thin wrapper around i2rt's `Kinematics` for the `end_effector` payload.

i2rt already ships a differential IK solver (`i2rt.robots.kinematics.Kinematics`)
backed by `mink` + `mujoco`, with the same URDF/MJCF the live
`MotorChainRobot` uses for gravity compensation. This module borrows that
solver and adapts it to the bridge's per-frame Cartesian-delta semantics:
the operator UI emits a small XYZ delta in the world frame; we add it to
the current EE pose, hand the result to the IK solver seeded with the
arm's current joint vector, and propagate the converged 6-DOF answer
back to the bridge as a fresh `latest_target[:6]` slice.

Loaded lazily — the import sits behind `_load_kinematics()` so robots
that never receive an `end_effector` frame (the common case) don't pay
the `mujoco`/`mink` import-time cost on bridge startup.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from i2rt.robots.kinematics import Kinematics

LOG = logging.getLogger(__name__)

# Site name baked into the YAM MJCF (see i2rt/i2rt/robots/kinematics.py main()).
DEFAULT_END_EFFECTOR_SITE = "grasp_site"

# Cap on a single-frame Cartesian step in metres. Larger deltas are
# clamped before IK so a runaway operator slider can't ask the solver
# for an unreachable target on one frame.
DEFAULT_MAX_LINEAR_STEP_M = 0.05


@dataclass
class IKResult:
    """Outcome of one Cartesian-delta solve, suitable for direct dispatch."""

    success: bool
    arm_joints: np.ndarray
    target_pose_world: np.ndarray


class EndEffectorIK:
    """Per-arm IK solver with an internal `current_pose` tracker."""

    def __init__(
        self,
        xml_path: str,
        site_name: str = DEFAULT_END_EFFECTOR_SITE,
        max_linear_step_m: float = DEFAULT_MAX_LINEAR_STEP_M,
    ) -> None:
        self._xml_path = xml_path
        self._site_name = site_name
        self._max_linear_step_m = max_linear_step_m
        self._kinematics: Kinematics | None = None
        self._current_pose_world: np.ndarray | None = None

    def _load_kinematics(self) -> Kinematics:
        if self._kinematics is None:
            from i2rt.robots.kinematics import Kinematics

            self._kinematics = Kinematics(self._xml_path, site_name=self._site_name)
        return self._kinematics

    def reset(self, arm_joints: np.ndarray) -> None:
        """Recompute the cached EE pose from the current arm joint vector."""

        kinematics = self._load_kinematics()
        self._current_pose_world = kinematics.fk(arm_joints, site_name=self._site_name).copy()

    def step(self, arm_joints: np.ndarray, delta_xyz: np.ndarray) -> IKResult:
        """Apply one Cartesian-delta step.

        ``arm_joints`` is the arm's current 6-DOF joint vector (no gripper).
        ``delta_xyz`` is the operator-emitted world-frame delta in metres.
        Returns the converged joint vector, or the seed unchanged on a
        non-converged solve so the caller's hold-position watchdog stays in
        charge of safety.
        """

        kinematics = self._load_kinematics()
        if self._current_pose_world is None:
            self.reset(arm_joints)
        assert self._current_pose_world is not None

        clamped_delta = self._clamp_delta(delta_xyz)
        target_pose = self._current_pose_world.copy()
        target_pose[:3, 3] = target_pose[:3, 3] + clamped_delta

        success, q = kinematics.ik(
            target_pose=target_pose,
            site_name=self._site_name,
            init_q=arm_joints,
        )
        if not success:
            LOG.debug("rfabric_yam_bridge: EE IK did not converge; holding previous joints")
            return IKResult(success=False, arm_joints=arm_joints, target_pose_world=self._current_pose_world)

        # Only commit the new EE pose on a successful solve so a transient
        # unreachable target doesn't drift the cached frame.
        self._current_pose_world = target_pose
        return IKResult(success=True, arm_joints=np.asarray(q, dtype=float), target_pose_world=target_pose)

    def _clamp_delta(self, delta_xyz: np.ndarray) -> np.ndarray:
        magnitude = float(np.linalg.norm(delta_xyz))
        if magnitude <= self._max_linear_step_m or magnitude == 0.0:
            return delta_xyz
        return delta_xyz * (self._max_linear_step_m / magnitude)
