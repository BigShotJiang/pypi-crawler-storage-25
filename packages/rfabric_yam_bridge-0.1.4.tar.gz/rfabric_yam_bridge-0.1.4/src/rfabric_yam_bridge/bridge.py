"""UDS server, integration tick, and state publisher for the YAM bridge.

Topology (mirror of the lerobot ``rfabric_remote`` teleoperator):

::

    rFabric agent ──UDS──▶ Bridge.accept_loop  ──▶ apply_payload(arm, ...)
                                                          │
                                                          ▼
                                          arm.latest_target / latest_velocity
                                                          │
                                                          ▼
                                Bridge.integration_tick  ──▶  arm.robot.command_joint_pos(...)
                                                          ▲
                                                          │
                                Bridge.state_publish_loop ──▶  STATE_KIND frame back to agent

All threads coordinate through three locks: the per-arm ``YamArm.lock()``
for control state, ``self._client_lock`` for the active socket, and
``self._stop_event`` for clean shutdown.
"""

from __future__ import annotations

import logging
import os
import socket
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np

from rfabric_control_wire import (
    CONTROL_KIND,
    MODE_KIND,
    STATE_KIND,
    Frame,
    FrameError,
    PayloadError,
    now_ts_ns,
    parse_control_payload,
    read_frame,
    write_frame,
)

from rfabric_yam_bridge.arm import YamArm
from rfabric_yam_bridge.mapping import apply_payload, hold_position

LOG = logging.getLogger(__name__)

import os

_XDG_RUNTIME = Path(os.environ.get("XDG_RUNTIME_DIR", "/run"))
DEFAULT_SOCKET_PATH = _XDG_RUNTIME / "rfabric" / "control.sock"
DEFAULT_SOCKET_MODE = 0o666
DEFAULT_INTEGRATION_HZ = 100.0
DEFAULT_STATE_PUBLISH_HZ = 30.0
DEFAULT_WATCHDOG_MS = 200
DEFAULT_ACCEPT_MIN_BACKOFF_MS = 50
DEFAULT_ACCEPT_MAX_BACKOFF_MS = 2_000

_DEFAULT_ACCEPTS: tuple[str, ...] = (
    "joint_targets",
    "joint_deltas",
    "joint_velocity",
    "end_effector",
    "stop",
    "home",
)


@dataclass(frozen=True)
class BridgeConfig:
    """Bridge-wide knobs (per-arm config lives on `YamArmConfig`)."""

    socket_path: Path = DEFAULT_SOCKET_PATH
    socket_mode: int = DEFAULT_SOCKET_MODE
    integration_hz: float = DEFAULT_INTEGRATION_HZ
    state_publish_hz: float = DEFAULT_STATE_PUBLISH_HZ
    watchdog_ms: int = DEFAULT_WATCHDOG_MS
    accept_min_backoff_ms: int = DEFAULT_ACCEPT_MIN_BACKOFF_MS
    accept_max_backoff_ms: int = DEFAULT_ACCEPT_MAX_BACKOFF_MS
    accepts: tuple[str, ...] = _DEFAULT_ACCEPTS


class YamBridge:
    """Run a UDS bridge serving one or more `YamArm` instances."""

    def __init__(self, config: BridgeConfig, arms: Iterable[YamArm]) -> None:
        self.config = config
        self._arms: dict[str, YamArm] = {arm.tag: arm for arm in arms}
        if not self._arms:
            raise ValueError("YamBridge requires at least one arm")

        self._listener: socket.socket | None = None
        self._client_lock = threading.Lock()
        self._client_socket: socket.socket | None = None

        self._stop_event = threading.Event()
        self._threads: list[threading.Thread] = []

        self._observation_seq = 0
        self._velocity_gains: dict[str, np.ndarray] = {
            tag: arm.velocity_gain_vector() for tag, arm in self._arms.items()
        }

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        self._open_listener()
        self._spawn(self._accept_loop, name="rfabric_yam_accept")
        self._spawn(self._integration_loop, name="rfabric_yam_integration")
        self._spawn(self._state_publish_loop, name="rfabric_yam_state")
        LOG.info(
            "rfabric_yam_bridge: listening on %s (arms=%s, integration_hz=%.1f, state_hz=%.1f, watchdog=%dms)",
            self.config.socket_path,
            sorted(self._arms),
            self.config.integration_hz,
            self.config.state_publish_hz,
            self.config.watchdog_ms,
        )

    def shutdown(self) -> None:
        self._stop_event.set()
        self._close_client()
        listener = self._listener
        self._listener = None
        if listener is not None:
            try:
                listener.close()
            except OSError:
                pass
            try:
                Path(self.config.socket_path).unlink()
            except FileNotFoundError:
                pass
            except OSError as err:
                LOG.warning("rfabric_yam_bridge: failed to remove socket file: %s", err)
        for thread in self._threads:
            if thread.is_alive():
                thread.join(timeout=2.0)
        for arm in self._arms.values():
            arm.close()

    def run_forever(self) -> None:
        """Block until SIGINT / `shutdown()`. Convenience for the CLI."""

        try:
            self._stop_event.wait()
        except KeyboardInterrupt:
            LOG.info("rfabric_yam_bridge: interrupted")
        finally:
            self.shutdown()

    # ------------------------------------------------------------------
    # UDS lifecycle
    # ------------------------------------------------------------------

    def _open_listener(self) -> None:
        socket_path = Path(self.config.socket_path)
        socket_path.parent.mkdir(parents=True, exist_ok=True)
        if socket_path.exists():
            try:
                socket_path.unlink()
            except OSError as err:
                LOG.warning("rfabric_yam_bridge: cannot remove stale socket %s: %s", socket_path, err)
        listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        listener.setblocking(True)
        listener.bind(str(socket_path))
        os.chmod(str(socket_path), self.config.socket_mode)
        listener.listen(1)
        self._listener = listener

    def _accept_loop(self) -> None:
        listener = self._listener
        if listener is None:
            return
        backoff_ms = self.config.accept_min_backoff_ms
        while not self._stop_event.is_set():
            try:
                client_sock, _ = listener.accept()
            except OSError as err:
                if self._stop_event.is_set():
                    return
                LOG.warning("rfabric_yam_bridge: accept failed (%s); backing off %dms", err, backoff_ms)
                self._stop_event.wait(backoff_ms / 1000.0)
                backoff_ms = min(backoff_ms * 2, self.config.accept_max_backoff_ms)
                continue
            backoff_ms = self.config.accept_min_backoff_ms
            self._handle_client(client_sock)

    def _handle_client(self, client_sock: socket.socket) -> None:
        with self._client_lock:
            self._client_socket = client_sock
        client_sock.settimeout(None)
        LOG.info("rfabric_yam_bridge: agent connected")
        try:
            self._send_capabilities(client_sock)
            while not self._stop_event.is_set():
                try:
                    frame = read_frame(client_sock)
                except FrameError as err:
                    LOG.warning("rfabric_yam_bridge: dropping malformed frame: %s", err)
                    break
                if frame is None:
                    LOG.info("rfabric_yam_bridge: agent disconnected (clean EOF)")
                    break
                self._on_inbound_frame(frame)
        finally:
            self._close_client()
            for arm in self._arms.values():
                hold_position(arm)

    def _close_client(self) -> None:
        with self._client_lock:
            client_sock = self._client_socket
            self._client_socket = None
        if client_sock is not None:
            try:
                client_sock.close()
            except OSError:
                pass

    def _send_capabilities(self, client_sock: socket.socket) -> None:
        # Advertise every configured arm tag (including the empty tag
        # single-arm setups use) plus the per-arm joint schema. The
        # operator UI keys its joint-control surface off `joints` so it
        # renders exactly the joints this follower actually owns rather
        # than guessing a hardcoded SO-101 layout.
        arm_tags = sorted(self._arms)
        payload = {
            "kind": "capabilities",
            "accepts": list(self.config.accepts),
            "arms": arm_tags,
            "joints": {tag: list(self._arms[tag].joint_names) for tag in arm_tags},
        }
        frame = Frame(kind=MODE_KIND, seq=0, ts_ns=now_ts_ns(), payload=payload)
        try:
            write_frame(client_sock, frame)
        except (OSError, FrameError) as err:
            LOG.warning("rfabric_yam_bridge: failed to publish capability frame: %s", err)

    # ------------------------------------------------------------------
    # Inbound frame handling
    # ------------------------------------------------------------------

    def _on_inbound_frame(self, frame: Frame) -> None:
        if frame.kind != CONTROL_KIND and frame.kind != MODE_KIND:
            LOG.debug("rfabric_yam_bridge: ignoring inbound %s frame", frame.kind)
            return
        try:
            payload = parse_control_payload(frame.payload)
        except PayloadError as err:
            LOG.warning("rfabric_yam_bridge: dropping malformed payload: %s", err)
            return
        arm = self._arms.get(payload.arm) or self._arms.get("")
        if arm is None:
            LOG.warning(
                "rfabric_yam_bridge: payload arm tag %r does not match any configured arm (%s)",
                payload.arm,
                sorted(self._arms),
            )
            return
        apply_payload(arm, payload)

    # ------------------------------------------------------------------
    # Integration tick
    # ------------------------------------------------------------------

    def _integration_loop(self) -> None:
        period = 1.0 / max(self.config.integration_hz, 1.0)
        watchdog_seconds = self.config.watchdog_ms / 1000.0
        last_tick = time.monotonic()
        while not self._stop_event.is_set():
            self._stop_event.wait(period)
            if self._stop_event.is_set():
                return
            now = time.monotonic()
            dt = now - last_tick
            last_tick = now
            for arm in self._arms.values():
                self._tick_arm(arm, dt=dt, now=now, watchdog_seconds=watchdog_seconds)

    def _tick_arm(self, arm: YamArm, *, dt: float, now: float, watchdog_seconds: float) -> None:
        with arm.lock():
            stale = (
                arm.last_control_at is None
                or (now - arm.last_control_at) > watchdog_seconds
            )
            if stale:
                arm.latest_velocity = np.zeros_like(arm.latest_velocity)
            arm.latest_target = arm.latest_target + arm.latest_velocity * dt
            arm.latest_target = self._clip_target(arm, arm.latest_target)
            target_to_send = arm.latest_target.copy()
        try:
            arm.robot.command_joint_pos(target_to_send)
        except Exception as err:
            LOG.warning("rfabric_yam_bridge: arm %r command_joint_pos failed: %s", arm.tag, err)

    def _clip_target(self, arm: YamArm, target: np.ndarray) -> np.ndarray:
        limits = arm.joint_limits
        if limits is None:
            return target
        clipped = target.copy()
        for index in range(arm.num_dofs):
            low, high = limits[index, 0], limits[index, 1]
            if not np.isnan(low):
                clipped[index] = max(clipped[index], low)
            if not np.isnan(high):
                clipped[index] = min(clipped[index], high)
        return clipped

    # ------------------------------------------------------------------
    # State publish loop
    # ------------------------------------------------------------------

    def _state_publish_loop(self) -> None:
        period = 1.0 / max(self.config.state_publish_hz, 0.1)
        while not self._stop_event.is_set():
            self._stop_event.wait(period)
            if self._stop_event.is_set():
                return
            with self._client_lock:
                client_sock = self._client_socket
            if client_sock is None:
                continue
            for arm in self._arms.values():
                self._publish_arm_state(client_sock, arm)

    def _publish_arm_state(self, client_sock: socket.socket, arm: YamArm) -> None:
        try:
            snapshot = arm.observation_snapshot()
        except Exception as err:
            LOG.debug("rfabric_yam_bridge: arm %r observation snapshot failed: %s", arm.tag, err)
            return
        self._observation_seq += 1
        payload = {"kind": "snapshot", "values": snapshot}
        if arm.tag:
            payload["arm"] = arm.tag
        frame = Frame(
            kind=STATE_KIND,
            seq=self._observation_seq,
            ts_ns=now_ts_ns(),
            payload=payload,
        )
        try:
            write_frame(client_sock, frame)
        except (OSError, FrameError) as err:
            LOG.debug("rfabric_yam_bridge: state publish failed (%s); waiting for reconnect", err)
            self._close_client()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _spawn(self, target, name: str) -> None:
        thread = threading.Thread(target=target, name=name, daemon=True)
        thread.start()
        self._threads.append(thread)
