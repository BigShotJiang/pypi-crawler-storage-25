"""Per-arm runtime wrapper around an i2rt `MotorChainRobot`.

A `YamArm` owns:

- The underlying i2rt robot (created via `get_yam_robot`).
- A canonical joint-name list (`joint1..joint6` plus optional `gripper`).
- The arm's current ``latest_target`` (absolute joint vector in i2rt's
  internal ordering) and ``latest_velocity`` (per-joint normalised
  velocities scaled by the per-joint ``velocity_gain`` to give rad/s).
- Operator-configurable knobs: ``home_pose``, ``velocity_gain``.
- A lazily-initialised IK solver (only loaded when the first
  ``end_effector`` payload arrives).

Threading: every accessor takes ``self._lock`` so the bridge's UDS
listener thread, integration tick thread, and state-publish thread can
all touch the per-arm state safely. The lock is held for short scalar
copies only; the underlying ``MotorChainRobot.command_joint_pos`` does
its own locking.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import numpy as np

from rfabric_yam_bridge.ik import EndEffectorIK

if TYPE_CHECKING:
    from i2rt.robots.motor_chain_robot import MotorChainRobot

LOG = logging.getLogger(__name__)

ARM_JOINT_PREFIX = "joint"
GRIPPER_JOINT_NAME = "gripper"
DEFAULT_VELOCITY_GAIN_RAD_PER_S = 0.5
DEFAULT_GRIPPER_VELOCITY_GAIN = 1.0
HOME_INTERPOLATION_SECONDS = 2.0


@dataclass(frozen=True)
class YamArmConfig:
    """Operator-supplied configuration for one YAM arm."""

    can_channel: str
    arm_type_name: str = "yam"
    gripper_type_name: str = "linear_4310"
    home_pose: dict[str, float] = field(default_factory=dict)
    velocity_gain: dict[str, float] = field(default_factory=dict)
    end_effector_xml_path: str | None = None


class YamArm:
    """One YAM arm + the per-arm state every payload kind mutates."""

    def __init__(self, tag: str, config: YamArmConfig, robot: MotorChainRobot) -> None:
        self.tag = tag
        self.config = config
        self.robot = robot
        self._lock = threading.Lock()

        self.joint_names = self._derive_joint_names()
        self._gripper_index = self._resolve_gripper_index()
        self._joint_limits = self._extract_joint_limits()

        # `latest_target` is in i2rt's internal joint ordering: arm joints
        # first, then gripper if present. Always shape (num_dofs,).
        initial_pos = np.asarray(self.robot.get_joint_pos(), dtype=float).copy()
        if initial_pos.shape != (self.num_dofs,):
            raise RuntimeError(
                f"i2rt robot reported {initial_pos.shape} joint vector but {self.num_dofs} DoFs were expected"
            )
        self.latest_target = initial_pos
        self.latest_velocity = np.zeros(self.num_dofs, dtype=float)
        self.last_command_at = time.monotonic()
        # Updated by any payload (including heartbeats) — general liveness.
        self.last_payload_at: float | None = None
        # Updated only by motion payloads (velocity, targets, deltas, EE).
        # The watchdog checks this so heartbeats don't mask a stale operator.
        self.last_control_at: float | None = None

        self._ik: EndEffectorIK | None = None

    @property
    def num_dofs(self) -> int:
        return self.robot.num_dofs()

    @property
    def has_gripper(self) -> bool:
        return self._gripper_index is not None

    @property
    def gripper_index(self) -> int | None:
        return self._gripper_index

    @property
    def joint_limits(self) -> np.ndarray | None:
        return self._joint_limits

    def velocity_gain_vector(self) -> np.ndarray:
        gains = np.full(self.num_dofs, DEFAULT_VELOCITY_GAIN_RAD_PER_S, dtype=float)
        if self.has_gripper:
            assert self._gripper_index is not None
            gains[self._gripper_index] = DEFAULT_GRIPPER_VELOCITY_GAIN
        for joint_name, override in self.config.velocity_gain.items():
            if joint_name not in self.joint_names:
                LOG.warning(
                    "rfabric_yam_bridge: ignoring velocity_gain override for unknown joint %r on arm %r",
                    joint_name,
                    self.tag,
                )
                continue
            gains[self.joint_names.index(joint_name)] = float(override)
        return gains

    def home_target_vector(self) -> np.ndarray:
        target = np.zeros(self.num_dofs, dtype=float)
        for joint_name, value in self.config.home_pose.items():
            if joint_name not in self.joint_names:
                LOG.warning(
                    "rfabric_yam_bridge: ignoring home_pose override for unknown joint %r on arm %r",
                    joint_name,
                    self.tag,
                )
                continue
            target[self.joint_names.index(joint_name)] = float(value)
        return target

    def get_ik_solver(self) -> EndEffectorIK | None:
        """Return the per-arm IK solver, lazily constructing it on first use.

        Returns ``None`` if no MJCF/URDF path was supplied — the bridge
        translates that into a hold-position cue for `end_effector` frames
        rather than crashing.
        """

        if self._ik is not None:
            return self._ik
        xml_path = self.config.end_effector_xml_path
        if xml_path is None:
            return None
        self._ik = EndEffectorIK(xml_path)
        self._ik.reset(self.arm_joints_view())
        return self._ik

    def arm_joints_view(self) -> np.ndarray:
        """The arm-only slice of `latest_target` (no gripper)."""

        with self._lock:
            if self.has_gripper:
                assert self._gripper_index is not None
                return self.latest_target[: self._gripper_index].copy()
            return self.latest_target.copy()

    def lock(self) -> threading.Lock:
        return self._lock

    def observation_snapshot(self) -> dict[str, float]:
        """Flat scalar snapshot for the outbound `state` frame."""

        observation = self.robot.get_observations()
        snapshot: dict[str, float] = {}
        joint_pos = np.asarray(observation.get("joint_pos", []), dtype=float).flatten()
        joint_vel = np.asarray(observation.get("joint_vel", []), dtype=float).flatten()
        for index, value in enumerate(joint_pos):
            snapshot[f"{ARM_JOINT_PREFIX}{index + 1}.pos"] = float(value)
        for index, value in enumerate(joint_vel):
            snapshot[f"{ARM_JOINT_PREFIX}{index + 1}.vel"] = float(value)
        gripper_pos = observation.get("gripper_pos")
        if gripper_pos is not None:
            snapshot[f"{GRIPPER_JOINT_NAME}.pos"] = float(np.asarray(gripper_pos).flatten()[0])
        gripper_vel = observation.get("gripper_vel")
        if gripper_vel is not None:
            snapshot[f"{GRIPPER_JOINT_NAME}.vel"] = float(np.asarray(gripper_vel).flatten()[0])
        return snapshot

    def _derive_joint_names(self) -> list[str]:
        # i2rt's `MotorChainRobot.get_observations` reports ``joint_pos`` for
        # arm joints and ``gripper_pos`` for the optional gripper. Mirror
        # that contract here so name → index lookups are stable across
        # arm types.
        observation = self.robot.get_observations()
        arm_count = int(np.asarray(observation.get("joint_pos", [])).size)
        names = [f"{ARM_JOINT_PREFIX}{index + 1}" for index in range(arm_count)]
        if observation.get("gripper_pos") is not None:
            names.append(GRIPPER_JOINT_NAME)
        return names

    def _resolve_gripper_index(self) -> int | None:
        if GRIPPER_JOINT_NAME not in self.joint_names:
            return None
        return self.joint_names.index(GRIPPER_JOINT_NAME)

    def _extract_joint_limits(self) -> np.ndarray | None:
        # `MotorChainRobot._joint_limits` is the in-memory copy of the URDF
        # joint limits (arm joints only — gripper is bounded by
        # `_gripper_limits`). We expose a (num_dofs, 2) array with NaN
        # in any unbounded slot so the integration tick can clip with a
        # single ``np.clip``.
        limits = np.full((self.num_dofs, 2), np.nan, dtype=float)
        arm_limits = getattr(self.robot, "_joint_limits", None)
        if arm_limits is not None:
            arm_limits = np.asarray(arm_limits, dtype=float)
            arm_count = arm_limits.shape[0]
            limits[:arm_count, :] = arm_limits
        gripper_limits = getattr(self.robot, "_gripper_limits", None)
        if gripper_limits is not None and self._gripper_index is not None:
            gripper_array = np.asarray(gripper_limits, dtype=float).flatten()
            limits[self._gripper_index, 0] = float(np.min(gripper_array))
            limits[self._gripper_index, 1] = float(np.max(gripper_array))
        return limits

    def close(self) -> None:
        try:
            self.robot.close()
        except Exception as err:
            LOG.warning("rfabric_yam_bridge: arm %r close raised %s", self.tag, err)


def make_yam_arm(tag: str, config: YamArmConfig) -> YamArm:
    """Construct a `YamArm` from a config; resolves the i2rt arm/gripper enums."""

    from i2rt.robots.get_robot import get_yam_robot
    from i2rt.robots.utils import ArmType, GripperType, combine_arm_and_gripper_xml

    arm_type = ArmType.from_string_name(config.arm_type_name)
    gripper_type = GripperType.from_string_name(config.gripper_type_name)
    robot = get_yam_robot(
        channel=config.can_channel,
        arm_type=arm_type,
        gripper_type=gripper_type,
        zero_gravity_mode=False,
    )

    # Resolve the same MJCF the live robot is using so the IK solver
    # works against an identical kinematic model. We do this once here
    # so the lazy IK construction has the path on hand.
    end_effector_xml_path = config.end_effector_xml_path
    if end_effector_xml_path is None:
        try:
            end_effector_xml_path = combine_arm_and_gripper_xml(arm_type, gripper_type)
        except Exception as err:
            LOG.warning(
                "rfabric_yam_bridge: arm %r could not derive MJCF path for IK (%s); "
                "`end_effector` payloads will hold position",
                tag,
                err,
            )

    resolved_config = YamArmConfig(
        can_channel=config.can_channel,
        arm_type_name=config.arm_type_name,
        gripper_type_name=config.gripper_type_name,
        home_pose=dict(config.home_pose),
        velocity_gain=dict(config.velocity_gain),
        end_effector_xml_path=end_effector_xml_path,
    )
    return YamArm(tag=tag, config=resolved_config, robot=robot)


def coerce_int(value: Any, default: int) -> int:
    """Best-effort int coercion that never raises on bridge-relevant input."""

    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return default
    return int(value)
