# rfabric-yam-bridge

Standalone bridge between the rFabric realtime control UDS and an i2rt YAM
arm (single or bimanual). Pip-install this package on the robot host, run
the `rfabric-yam-bridge` CLI as a systemd unit, and the rFabric agent will
drive your YAM the moment an operator session opens.

## Install

`i2rt` is not on PyPI. Install both in one step:

```bash
uv tool install rfabric-yam-bridge \
  --with "i2rt @ git+https://github.com/i2rt-robotics/i2rt.git"
```

## Run

Single arm:

```bash
rfabric-yam-bridge --can-channel can0 --gripper linear_4310
```

Bimanual:

```bash
rfabric-yam-bridge \
    --left-channel can0  --left-gripper linear_4310 \
    --right-channel can1 --right-gripper linear_4310
```

The socket defaults to `$XDG_RUNTIME_DIR/rfabric/control.sock` (typically
`/run/user/<uid>/rfabric/control.sock`). Override with `--socket-path` when
running under a systemd unit that pre-creates `/run/rfabric/`.

The bridge:

- Binds the UDS, accepts a single client (the rFabric agent), and
  decodes inbound length-prefixed CBOR `Frame`s.
- Maps every operator payload kind (`joint_targets`, `joint_deltas`,
  `joint_velocity`, `end_effector`, `stop`, `home`) into the same
  per-arm latest target / latest velocity, integrated by a single
  fixed-rate tick (default 100 Hz) into `MotorChainRobot.command_joint_pos`.
- Mirrors live joint state back to the operator UI as `state` frames at
  `--state-publish-hz` (default 30 Hz).
- Drops any per-arm command stream older than `--watchdog-ms` so the arm
  freezes when the operator UI stutters; the i2rt motor 400 ms safety
  timeout is the second line of defence.

The wire format is the same one consumed by the lerobot `rfabric_remote`
teleoperator — both surfaces share the `rfabric-control-wire` package.
