"""
Fixed pipeline order and helpers to map Optuna trial params to pipeline step configs.
"""

from typing import Any, Dict, Tuple

# Physical pipeline step order used by OptunaOptimizer:
# baseline → smoothing → derivative → truncation → normalization
PIPELINE_FIXED_ORDER: Tuple[str, ...] = (
    "baseline",
    "smoothing",
    "derivative",
    "truncation",
    "normalization",
)

# Extra categorical values for combined smoothing / derivative Optuna dimension
DERIVATIVE_FIRST = "derivative_first"
DERIVATIVE_SECOND = "derivative_second"


def _smooth_params_dict_from_flat(params: Dict[str, Any], smooth_method: str) -> Dict[str, Any]:
    """Rebuild smoothing kwargs from flattened Optuna parameter names."""
    smooth_params: Dict[str, Any] = {}
    if smooth_method == "savgol":
        smooth_params["polyorder"] = params.get("sg_polyorder", 2)
        smooth_params["window_length"] = params.get("sg_window_length", 11)
    elif smooth_method == "wavelet":
        smooth_params["wavelet"] = params.get("wavelet", "db2")
        smooth_params["level"] = 1
        smooth_params["mode"] = "soft"
    elif smooth_method == "local_poly":
        smooth_params["bandwidth"] = params.get("lp_bandwidth", 3)
        smooth_params["iterations"] = params.get("lp_iterations", 0)
    elif smooth_method == "whittaker":
        smooth_params["Lambda"] = params.get("smooth_whittaker_lambda", 1e1)
    elif smooth_method == "gcv_spline":
        pass
    elif smooth_method in ["moving_average", "hanning", "hamming", "bartlett", "blackman"]:
        smooth_params["window_length"] = params.get("window_length", 11)
    return smooth_params


def restore_smoothing_derivative_step_configs(params: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Build ``smoothing`` and ``derivative`` step_configs from flat Optuna trial params.

    Uses ``smoothing_derivative`` (combined search) when present; otherwise falls back
    to legacy ``smoothing`` + integral ``derivative`` order.
    """
    sd = params.get("smoothing_derivative")

    if sd is None:
        smooth_method = params.get("smoothing", "none")
        smooth_params = _smooth_params_dict_from_flat(params, smooth_method)
        d_order = int(params.get("derivative", 0))
        if d_order > 0:
            derivative_cfg = {
                "method": "savgol",
                "parameters": {
                    "order": d_order,
                    "window_length": params.get("derivative_window_length", 11),
                    "polyorder": params.get("derivative_polyorder", 2),
                },
            }
        else:
            derivative_cfg = {"method": "none", "parameters": {}}
        return {"method": smooth_method, "parameters": smooth_params}, derivative_cfg

    if sd == DERIVATIVE_FIRST:
        return (
            {"method": "none", "parameters": {}},
            {
                "method": "savgol",
                "parameters": {"order": 1, "window_length": 11, "polyorder": 2},
            },
        )
    if sd == DERIVATIVE_SECOND:
        return (
            {"method": "none", "parameters": {}},
            {
                "method": "savgol",
                "parameters": {"order": 2, "window_length": 11, "polyorder": 2},
            },
        )

    smooth_method = sd
    smooth_params = _smooth_params_dict_from_flat(params, smooth_method)
    return {"method": smooth_method, "parameters": smooth_params}, {"method": "none", "parameters": {}}
