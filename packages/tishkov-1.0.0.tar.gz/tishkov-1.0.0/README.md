# Tishkov AI

Self-learning AI with Sigma-reflections and ABC-verification.

## Install
```
pip install tishkov
```

## Quick Start
```python
from tishkov import TishkovAI
ai = TishkovAI()
ai.add_concept("X","cat")
ai.learn(50)
ai.discover()
```
