from setuptools import setup
setup(name="tishkov",version="1.0.0",author="Vladislav Tishkov",description="Tishkov AI — Self-learning framework",packages=["tishkov"],install_requires=["torch","numpy"],python_requires=">=3.9")
