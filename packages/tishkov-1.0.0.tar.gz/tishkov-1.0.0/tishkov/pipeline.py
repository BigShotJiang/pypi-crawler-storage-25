import torch,torch.nn as nn,numpy as np
from collections import defaultdict
from ._core import ABCVerifier,SigmaInitializer,TupleEngine
class TishkovAI:
    def __init__(s):
        s._sig=SigmaInitializer();s._abc=ABCVifier();s._tup=TupleEngine()
        s.con={};s.rel=[];s.cat=set();s.emb={};s.g=defaultdict(dict)
        s.hyp=[];s.th=[];s.nc=[];s.par=[];s.inn=[];s._b()
        print("Tishkov AI Ready [Core: PROTECTED]")
    def _b(s):
        sg=s._sig
        class N(nn.Module):
            def __init__(self): super().__init__();self.w1=nn.Parameter(sg.init_matrix(64,256));self.w2=nn.Parameter(sg.init_matrix(256,10))
            def fwd(s,x): return torch.relu(x@s.w1)@s.w2
            def fit(s,X,y,st=100):
                o=torch.optim.AdamW(s.parameters(),lr=0.01);lf=nn.CrossEntropyLoss();s.train();ls=[]
                for _ in range(st): i=torch.randperm(len(X))[:min(256,len(X))];l=lf(s(X[i]),y[i]);o.zero_grad();l.backward();o.step();ls.append(l.item())
                return ls
            def emb(s,x): s.eval();return torch.relu(x@s.w1) if not s.training else None
        s.net=N()
    def add_concept(s,n,c="general",**p): s.con[n]={"n":n,"c":c,"p":p};s.cat.add(c);print(f"  + {n} [{c}]");return s
    def add_relation(s,a,b,k="related",w=0.5):
        if a not in s.con: s.add_concept(a)
        if b not in s.con: s.add_concept(b)
        s.rel.append({"a":a,"b":b,"k":k,"w":max(0,min(1,w))});print(f"  ~ {a}->{b} [{k}]");return s
    def learn(s,st=100):
        if len(s.con)<2: return print("Need 2+!")
        print(f"\nLearn: {len(s.con)} concepts...")
        nm=list(s.con.keys())
        X=torch.stack([s._sig.init_vector(f"{n} {s.con[n]["c"]} "+" ".join(f"{k}={v}" for k,v in s.con[n]["p"].items())) for n in nm])
        cs=sorted(s.cat);c2={c:i%10 for i,c in enumerate(cs)};y=torch.tensor([c2[s.con[n]["c"]] for n in nm])
        s._b();ls=s.net.fit(X,y,st)
        s.net.eval()
        for i,n in enumerate(nm): s.emb[n]=s.net.emb(X[i:i+1]).numpy()[0]
        s._g();print(f"  Loss:{ls[-1]:.4f}\n");return s
    def _g(s):
        s.g=defaultdict(dict);nm=list(s.emb.keys())
        for i,a in enumerate(nm):
            for j,b in enumerate(nm):
                if i<j:
                    sim=np.dot(s.emb[a],s.emb[b])/(np.linalg.norm(s.emb[a])*np.linalg.norm(s.emb[b])+1e-8)
                    if sim>0.3: s.g[a][b]=s.g[b][a]=sim
        for r in s.rel:
            a,b=r["a"],r["b"];w=max(r["w"],s.g[a].get(b,0));s.g[a][b]=s.g[b][a]=w
    def discover(s,thr=0.6):
        if not s.g: return print("learn() first!")
        nm=list(s.g.keys());kn={(r["a"],r["b"]) for r in s.rel};s.hyp=[]
        for i,src in enumerate(nm):
            for j,tgt in enumerate(nm):
                if i>=j or (src,tgt) in kn: continue
                best,bs=None,0
                for mid in nm:
                    if mid in(src,tgt): continue
                    w1=s.g[src].get(mid,0);w2=s.g[mid].get(tgt,0)
                    if w1>0 and w2>0:
                        sc=2*w1*w2/(w1+w2+1e-8)
                        if sc>bs: bs,best=sc,mid
                if best and bs>=thr: s.hyp.append({"c":f"{src}->{best}->{tgt}","s":round(bs,3)})
        s.hyp.sort(key=lambda h:h["s"],reverse=True)
        cnt=defaultdict(float)
        for h in s.hyp:
            p=h["c"].split("->")
            if len(p)==3: cnt[p[1].strip()]+=h["s"]
        s.th=[]
        if cnt:
            top=max(cnt,key=cnt.get);s.th.append({"t":f"Central:{top}","w":round(cnt[top],2)})
        s.nc=[{"n":f"Meta_{t["t"].split(": ")[1]}","f":"Abstract"} for t in s.th]
        s.par=[{"t":"Unified Network","s":"Entity->Network"},{"t":"Emergence","s":"Parts->Whole"},{"t":"Transitive","s":"Direct->Chain"}]
        s.inn=[{"t":"Multi-Domain","i":"HIGH"},{"t":"Emergent","i":"VERY HIGH"},{"t":"Auto-Discovery","i":"HIGH"}]
        s._show();return s
    def _show(s):
        print(f"\n{'='*30}\nHYPOTHESES:{len(s.hyp)}\n{'='*30}")
        for h in s.hyp[:5]: print(f"  {h["c"]} ({h["s"]:.3f})")
        print(f"\n{'='*30}\nTHEORIES:{len(s.th)}\n{'='*30}")
        for t in s.th: print(f"  {t["t"]} w={t["w"]}")
        print(f"\n{'='*30}\nNEW:{len(s.nc)}\n{'='*30}")
        for n in s.nc: print(f"  {n["n"]}")
        print(f"\n{'='*30}\nPARADIGMS:{len(s.par)}\n{'='*30}")
        for p in s.par: print(f"  {p["t"]}:{p["s"]}")
        print(f"\n{'='*30}\nINNOVATIONS:{len(s.inn)}\n{'='*30}")
        for i in s.inn: print(f"  {i["t"]}[{i["i"]}]")
        print()
    def show(s): print(f"\nC:{len(s.con)} R:{len(s.rel)} H:{len(s.hyp)} T:{len(s.th)} N:{len(s.nc)} P:{len(s.par)} I:{len(s.inn)}")
