from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="mapping-encrypt",
    version="0.2.0",
    author="MD Faisal Qureshi",
    author_email="mfq2412@example.com",
    description="A custom character encoding package for encrypting Python scripts",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/mfq2412/Mapping",
    packages=find_packages(),
    include_package_data=False,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    install_requires=[
        "rich",
        "pandas",
        "openpyxl",
        "requests",
        "urllib3",
        "firebase-admin",
    ],
    entry_points={
        "console_scripts": [
            "mapping-encode=mapping.encoder:main",
            "mapping-pkg=mapping.manager:main",
        ],
    },
)
