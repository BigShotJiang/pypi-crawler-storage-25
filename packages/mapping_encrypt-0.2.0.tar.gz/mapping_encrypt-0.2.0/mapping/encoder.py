#!/usr/bin/env python3
"""
Encoder script for encrypting Python files using the mapping
"""

import json
import random
import string
import os
import argparse

DELIM = "|"

def generate_placeholder(ch):
    """Generate a random placeholder for a character"""
    charset = string.ascii_letters + string.digits
    return ''.join(random.choice(charset) for _ in range(4))

def load_mapping(mapping_file):
    """Load existing mapping from file"""
    if os.path.exists(mapping_file):
        with open(mapping_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_mapping(mapping, mapping_file):
    """Save mapping to file"""
    with open(mapping_file, "w", encoding="utf-8") as f:
        json.dump(mapping, f, ensure_ascii=False, indent=4)

def encode_file(input_file, output_file=None, mapping_file=None, update_mapping=False):
    """
    Encode a Python file using the character mapping.

    Args:
        input_file (str): Path to the input Python file
        output_file (str): Path to the output encoded file (default: input_file with _encoded suffix)
        mapping_file (str): Path to the mapping JSON file (default: mapping.json in package dir)
        update_mapping (bool): Whether to update the mapping file with new characters (default: False)

    Returns:
        tuple: (output_file_path, number_of_new_characters_added)
    """
    # Determine mapping file location
    if mapping_file is None:
        package_dir = os.path.dirname(os.path.abspath(__file__))
        mapping_file = os.path.join(package_dir, "mapping.json")

    # Load existing mapping
    mapping = load_mapping(mapping_file)

    # Read input file
    with open(input_file, "r", encoding="utf-8") as f:
        text = f.read()

    # Encode text
    encoded_tokens = []
    new_chars_added = 0
    missing_chars = []

    for ch in text:
        if ch not in mapping:
            if update_mapping:
                mapping[ch] = generate_placeholder(ch)
                new_chars_added += 1
                print(f"Added missing character {repr(ch)} with encoding {mapping[ch]}")
            else:
                missing_chars.append(repr(ch))
                encoded_tokens.append("????")  # Placeholder for missing character
        else:
            encoded_tokens.append(mapping[ch])

    if missing_chars and not update_mapping:
        print(f"Warning: {len(set(missing_chars))} unique characters not in mapping: {set(missing_chars)}")
        print("Use --update-mapping flag to add them automatically")

    encoded_text = DELIM.join(encoded_tokens)

    # Determine output file
    if output_file is None:
        base, ext = os.path.splitext(input_file)
        output_file = f"{base}_encoded{ext}"

    # Write encoded file
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(f'import mapping\n\n')
        f.write(f'encoded_string = "{encoded_text}"\n\n')
        f.write(f'decoded_string = mapping.decode(encoded_string)\n\n')
        f.write(f'exec(decoded_string)\n')

    # Save updated mapping if needed
    if update_mapping and new_chars_added > 0:
        save_mapping(mapping, mapping_file)
        print(f"Mapping updated and saved to {mapping_file}")

    print(f"Encoded script saved to {output_file}")
    return output_file, new_chars_added

def main():
    """Command-line interface for the encoder"""
    parser = argparse.ArgumentParser(
        description="Encode Python files using custom character mapping"
    )
    parser.add_argument("input", help="Input Python file to encode")
    parser.add_argument("-o", "--output", help="Output file path (default: input_encoded.py)")
    parser.add_argument("-m", "--mapping", help="Path to mapping.json file")
    parser.add_argument("-u", "--update-mapping", action="store_true",
                        help="Update mapping file with new characters")

    args = parser.parse_args()

    encode_file(args.input, args.output, args.mapping, args.update_mapping)

if __name__ == "__main__":
    main()
