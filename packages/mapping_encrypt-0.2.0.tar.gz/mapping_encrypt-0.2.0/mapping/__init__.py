import requests

__version__ = "0.2.0"

_WORKER_URL = "https://mapping-worker.email-ecf.workers.dev"
_API_KEY = "3834dcbc09e5bbdab4f47c10e0fd7c201df6d5efee46b6759331cbf594b4f590"
_HEADERS = {"X-API-Key": _API_KEY, "Content-Type": "application/json"}


def decode(encoded_string, delimiter="|", strict=False):
    response = requests.post(
        f"{_WORKER_URL}/decode",
        json={"encoded": encoded_string, "delimiter": delimiter, "strict": strict},
        headers=_HEADERS,
    )
    response.raise_for_status()
    return response.json()["decoded"]


def encode(text, delimiter="|"):
    response = requests.post(
        f"{_WORKER_URL}/encode",
        json={"text": text, "delimiter": delimiter},
        headers=_HEADERS,
    )
    response.raise_for_status()
    return response.json()["encoded"]


__all__ = ["decode", "encode", "__version__"]
