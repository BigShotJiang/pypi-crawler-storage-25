import subprocess
import sys
from rich.progress import Progress, SpinnerColumn, TextColumn

PACKAGE = "mapping-encrypt"


def _run_pip(args):
    result = subprocess.run(
        [sys.executable, "-m", "pip"] + args,
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def _run_with_spinner(message, pip_args):
    with Progress(SpinnerColumn(), TextColumn("[bold blue]{task.description}"), transient=True) as progress:
        progress.add_task(message, total=None)
        return _run_pip(pip_args)


def main():
    import argparse
    parser = argparse.ArgumentParser(prog="mapping-pkg")
    sub = parser.add_subparsers(dest="cmd")
    sub.add_parser("install")
    sub.add_parser("uninstall")
    sub.add_parser("reinstall")
    args = parser.parse_args()

    if args.cmd == "install":
        ok = _run_with_spinner(f"Installing {PACKAGE}...", ["install", "-q", "-q", PACKAGE])
        print("Done." if ok else "Install failed.")
        if not ok:
            sys.exit(1)

    elif args.cmd == "uninstall":
        ok = _run_with_spinner(f"Uninstalling {PACKAGE}...", ["uninstall", "-y", "-q", PACKAGE])
        print("Done." if ok else "Uninstall failed.")
        if not ok:
            sys.exit(1)

    elif args.cmd == "reinstall":
        ok1 = _run_with_spinner(f"Removing {PACKAGE}...", ["uninstall", "-y", "-q", PACKAGE])
        if not ok1:
            print("Remove failed.")
            sys.exit(1)
        ok2 = _run_with_spinner(f"Installing {PACKAGE}...", ["install", "-q", "-q", PACKAGE])
        print("Done." if ok2 else "Install failed.")
        if not ok2:
            sys.exit(1)

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
