## Install

```bash
pip install mapping-encrypt -q -q
```

## Upgrade

```bash
pip install --upgrade mapping-encrypt -q -q
```

## Uninstall

```bash
mapping-pkg uninstall
```

## Reinstall

```bash
mapping-pkg reinstall
```
