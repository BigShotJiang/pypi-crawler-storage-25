"""Filesystem configuration models for local runner execution.

These models define a typed API for selecting filesystem behavior in
`Agent(..., filesystem=...)` when running with the local LangGraph runner.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from __future__ import annotations

from pathlib import Path, PurePosixPath
from typing import Any, Literal

from gllm_core.utils import LoggerManager
from pydantic import BaseModel, StrictBool, StrictInt, StrictStr, field_validator

logger = LoggerManager().get_logger(__name__)


class FilesystemConfig(BaseModel):
    """Base type for filesystem configuration models.

    Subclasses represent concrete backend choices and validation rules.
    """

    def model_dump(self, **_: Any) -> dict[str, Any]:
        """Serialize to dictionary for API transport.

        Returns:
            Dictionary representation of the config for backend API.
        """
        return {"backend": "in_memory"}


class InMemoryConfig(FilesystemConfig):
    """In-memory filesystem configuration.

    Attributes:
        backend (Literal["in_memory"]): Backend selector used by resolver logic.
    """

    backend: Literal["in_memory"] = "in_memory"

    def model_dump(self, **_: Any) -> dict[str, Any]:
        """Serialize to dictionary for API transport.

        Returns:
            Dictionary representation of the config for backend API.
        """
        return {"backend": "in_memory"}


class LocalDiskConfig(FilesystemConfig):
    """Local-disk filesystem configuration.

    Attributes:
        backend (Literal["local_disk"]): Backend selector used by resolver logic.
        base_directory (str): Existing directory used as filesystem root.
        allow_execute (bool): Enables execute-tool command execution for local runs.
    """

    backend: Literal["local_disk"] = "local_disk"
    base_directory: str
    allow_execute: bool = False

    @field_validator("base_directory")
    @classmethod
    def _validate_base_directory(cls, value: str) -> str:
        """Validate that base_directory exists and log warning if not.

        In remote deployment mode, the base_directory is not used (backend
        auto-generates a temp directory), so the warning can be safely ignored.

        Args:
            value: Candidate directory path.

        Returns:
            The directory path (always accepted, warning logged if missing).
        """
        path = Path(value)
        if not path.is_dir():
            logger.warning(
                f"base_directory does not exist: {value}. This is expected for remote deployment and will be ignored."
            )
        return str(path)

    def model_dump(self, **_: Any) -> dict[str, Any]:
        """Serialize to dictionary for API transport.

        Note: base_directory is intentionally stripped for security in remote mode.
        The backend auto-generates a temp directory.

        Returns:
            Dictionary representation of the config for backend API.
        """
        return {"backend": "local_disk"}


class SandboxConfig(FilesystemConfig):
    """Filesystem configuration for the sandbox backend."""

    backend: Literal["sandbox"] = "sandbox"
    base_dir: StrictStr = "/workspace"
    timeout_seconds: StrictInt = 300
    allow_execute: StrictBool = True

    @field_validator("base_dir")
    @classmethod
    def _validate_base_dir(cls, value: str) -> str:
        """Validate that base_dir is a non-empty absolute POSIX path without traversal."""
        path = PurePosixPath(value)
        normalized = path.as_posix().strip()
        # Reject empty, non-absolute, or root paths
        if not normalized or not normalized.startswith("/") or normalized == "/":
            raise ValueError("base_dir must be a non-empty absolute POSIX path")
        # Reject any path containing parent directory traversal
        if ".." in path.parts:
            raise ValueError("base_dir must not contain parent directory traversal (..)")
        return normalized

    @field_validator("timeout_seconds")
    @classmethod
    def _validate_timeout_seconds(cls, value: int) -> int:
        """Validate that timeout_seconds is a positive integer."""
        if value <= 0:
            raise ValueError("timeout_seconds must be a positive integer")
        return value

    def model_dump(self, **_: Any) -> dict[str, Any]:
        """Serialize sandbox settings for deploy and runtime overrides."""
        return {
            "backend": "sandbox",
            "base_dir": self.base_dir,
            "timeout_seconds": self.timeout_seconds,
            "allow_execute": self.allow_execute,
        }
