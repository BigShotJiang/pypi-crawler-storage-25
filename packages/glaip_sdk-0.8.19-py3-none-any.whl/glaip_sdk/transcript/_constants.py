"""Internal transcript-export constants and error messages shared across SDK run paths.

Authors:
    Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)
"""

_EXPORT_DIR_REQUIRES_EXPORT_MSG = "export_dir can only be used when export=True"
_ASYNC_EXPORT_NOT_SUPPORTED_MSG = (
    "Transcript export is not supported for async runs in MVP. Use Agent.run(..., export=True) instead."
)
DEFAULT_EXPORT_DIRNAME = "aip-agent-runs"
