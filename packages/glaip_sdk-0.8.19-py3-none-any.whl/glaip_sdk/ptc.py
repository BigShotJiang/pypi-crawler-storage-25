"""Programmatic Tool Calling (PTC) configuration for SDK runs.

This module provides the PTC class for configuring sandboxed code execution
for agent runs. PTC enables agents to call execute_ptc_code and use MCP
tools programmatically in an E2B sandbox for local and remote execution paths.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from __future__ import annotations

from typing import Any

from glaip_sdk.exceptions import ValidationError


class PTC:
    """Configuration for Programmatic Tool Calling in SDK runs.

    PTC allows agents to execute Python code in a sandboxed E2B environment
    with access to registered MCP tools.

    Example:
        >>> from glaip_sdk.ptc import PTC
        >>> from glaip_sdk.agents import Agent
        >>>
        >>> ptc = PTC(enabled=True)
        >>> agent = Agent(
        ...     name="ptc_demo",
        ...     instruction="Use execute_ptc_code for multi-tool workflows.",
        ...     mcps=[my_mcp],
        ...     ptc=ptc,
        ... )
        >>> agent.run("Analyze the repo", local=True)

    Custom timeouts and prompts:
        >>> ptc = PTC(
        ...     enabled=True,
        ...     sandbox_timeout=180.0,
        ...     prompt={"mode": "full", "include_example": False},
        ... )

    Custom sandbox packages:
        >>> ptc = PTC(enabled=True, ptc_packages=["pandas==2.2.0"])

    Args:
        enabled: Whether PTC is enabled. Must be True to activate PTC.
            When False, all other fields are ignored (toggle-friendly).
        sandbox_timeout: Maximum execution time in seconds for sandbox code.
            Defaults to 120.0 seconds.
        default_tool_timeout: Default timeout in seconds for MCP tool calls
            executed from the sandbox. Defaults to 60.0 seconds.
        sandbox_template: Sandbox template identifier. Defaults to
            "aip-agents-ptc-v1".
        prompt: Prompt configuration for PTC tool description.
            Can be a dict with "mode" and "include_example" keys.
            Defaults to None (uses aip-agents default).
        custom_tools: NOT SUPPORTED. Raises ValidationError if provided
            when enabled=True. Custom tools are auto-derived from Agent.tools.
        ptc_packages: Additional packages to install in the sandbox.
            If None (default), aip-agents uses smart package selection.
            If set (including empty list), packages are additive to defaults.

    Raises:
        ValidationError: If custom_tools is provided when enabled=True.
    """

    def __init__(
        self,
        *,
        enabled: bool = False,
        sandbox_timeout: float = 120.0,
        default_tool_timeout: float = 60.0,
        sandbox_template: str | None = "aip-agents-ptc-v1",
        prompt: dict[str, Any] | None = None,
        custom_tools: list[Any] | None = None,
        ptc_packages: list[str] | None = None,
    ):
        """Initialize PTC configuration.

        Args:
            enabled: Whether PTC is enabled. Must be True to activate.
            sandbox_timeout: Sandbox execution timeout in seconds.
            default_tool_timeout: Default timeout in seconds for MCP tool calls.
            sandbox_template: Sandbox template identifier.
            prompt: Prompt configuration dict.
            custom_tools: Custom tools (NOT SUPPORTED; auto-derived from Agent.tools).
            ptc_packages: Additional sandbox packages. None preserves aip-agents defaults.

        Raises:
            ValidationError: If custom_tools is provided when enabled=True.
        """
        self.enabled = enabled
        self.sandbox_timeout = sandbox_timeout
        self.default_tool_timeout = default_tool_timeout
        self.sandbox_template = sandbox_template
        self.prompt = prompt
        self._custom_tools = custom_tools
        self._ptc_packages = ptc_packages

        if self.enabled:
            self._validate_constraints()

    @property
    def ptc_packages(self) -> list[str] | None:
        """Return the ptc_packages configuration."""
        return self._ptc_packages

    def _validate_constraints(self) -> None:
        """Validate that unsupported features are not used.

        Raises:
            ValidationError: If unsupported or invalid values are provided.
        """
        if self._custom_tools is not None:
            msg = (
                "ptc.custom_tools is not supported in the SDK yet. "
                "Custom tools are auto-derived from Agent.tools. "
                "Per-tool PTC selection will be added in a future release."
            )
            raise ValidationError(msg)

        if self.default_tool_timeout <= 0:
            msg = "ptc.default_tool_timeout must be > 0 when PTC is enabled."
            raise ValidationError(msg)

        if self.sandbox_template == "" or (
            isinstance(self.sandbox_template, str) and not self.sandbox_template.strip()
        ):
            msg = "ptc.sandbox_template must be a non-empty string when provided."
            raise ValidationError(msg)

    def to_dict(self) -> dict[str, Any]:
        """Convert PTC config to dictionary format.

        Returns:
            Dictionary representation of PTC config.
        """
        result: dict[str, Any] = {
            "enabled": self.enabled,
        }

        if self.enabled:
            result["sandbox_timeout"] = self.sandbox_timeout
            result["default_tool_timeout"] = self.default_tool_timeout
            if self.sandbox_template is not None:
                result["sandbox_template"] = self.sandbox_template
            if self.prompt is not None:
                result["prompt"] = self.prompt
            if self._ptc_packages is not None:
                result["ptc_packages"] = self._ptc_packages

        return result

    def __repr__(self) -> str:
        """Return string representation of PTC config."""
        if not self.enabled:
            return "PTC(enabled=False)"

        parts = [f"enabled={self.enabled}"]
        if abs(self.sandbox_timeout - 120.0) > 1e-9:
            parts.append(f"sandbox_timeout={self.sandbox_timeout}")
        if abs(self.default_tool_timeout - 60.0) > 1e-9:
            parts.append(f"default_tool_timeout={self.default_tool_timeout}")
        if self.sandbox_template != "aip-agents-ptc-v1":
            parts.append(f"sandbox_template={self.sandbox_template!r}")
        if self.prompt is not None:
            parts.append(f"prompt={self.prompt!r}")
        if self._ptc_packages is not None:
            parts.append(f"ptc_packages={self._ptc_packages!r}")

        return f"PTC({', '.join(parts)})"
