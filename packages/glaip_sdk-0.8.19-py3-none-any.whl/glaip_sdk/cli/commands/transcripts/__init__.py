"""Slash transcript helpers (no top-level CLI command registration)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click
from rich.table import Table

from glaip_sdk.cli.core.output import parse_json_line
from glaip_sdk.cli.transcript import export_cached_transcript
from glaip_sdk.cli.transcript.history import HistoryEntry
from glaip_sdk.cli.transcript.viewer import ViewerContext, run_viewer_session


def _history_table(entries: list[HistoryEntry]) -> Table:
    """Build a compact transcript-history table for slash fallback rendering."""
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Run ID", style="bold")
    table.add_column("Agent")
    table.add_column("Started (UTC)")
    table.add_column("Duration")
    table.add_column("Status")

    for entry in entries:
        started = entry.started_at_iso or "-"
        duration = str(entry.duration_seconds) if entry.duration_seconds is not None else "-"
        agent = entry.agent_name or entry.agent_id or "-"
        marker = " !" if entry.warning else ""
        table.add_row(
            f"{entry.run_id}{marker}",
            str(agent),
            started,
            duration,
            str(entry.status or "-"),
        )
    return table


def _load_transcript_text(entry: HistoryEntry) -> tuple[Path, str]:
    """Load transcript text for a history entry or raise a click-facing error."""
    transcript_path = entry.resolved_path or entry.expected_path
    if transcript_path is None or not transcript_path.exists():
        raise click.ClickException(f"Transcript file missing for run {entry.run_id}.")
    try:
        return transcript_path, transcript_path.read_text(encoding="utf-8")
    except OSError as exc:  # pragma: no cover - filesystem edge
        raise click.ClickException(str(exc)) from exc


def _decode_transcript(transcript_text: str) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Decode JSONL transcript payload into `(meta, events)`."""
    meta: dict[str, Any] = {}
    events: list[dict[str, Any]] = []
    for raw_line in transcript_text.splitlines():
        payload = parse_json_line(raw_line)
        if not isinstance(payload, dict):
            continue
        if payload.get("type") == "meta" and not meta:
            meta = payload
            continue
        events.append(payload)
    return meta, events


def _maybe_launch_transcript_viewer(
    entry: HistoryEntry,
    meta: dict[str, Any],
    events: list[dict[str, Any]],
    *,
    console_override: Any | None = None,
    force: bool = False,
    initial_view: str = "default",
) -> bool:
    """Attempt to launch the interactive transcript viewer."""
    console = console_override
    if console is None or not getattr(console, "is_terminal", False):
        return False
    if not force:
        return False

    viewer_ctx = ViewerContext(
        manifest_entry=dict(entry.manifest or {}),
        events=list(events),
        default_output=str(meta.get("renderer_output") or ""),
        final_output=str(meta.get("final_output") or ""),
        stream_started_at=None,
        meta=dict(meta or {}),
    )

    def _export_callback(destination: Path) -> Path:
        run_id = str(entry.run_id or "")
        if not run_id:
            raise FileNotFoundError("Run id is missing for export.")
        return export_cached_transcript(destination=destination, run_id=run_id)

    try:
        run_viewer_session(console, viewer_ctx, _export_callback, initial_view=initial_view)
    except Exception:
        return False
    return True


def _render_transcript_display(
    entry: HistoryEntry,
    manifest_path: Path,
    transcript_path: Path,
    meta: dict[str, Any],
    events: list[dict[str, Any]],
) -> str:
    """Render plain-text transcript detail output."""
    lines = [f"Manifest: {manifest_path} · {entry.run_id} · {transcript_path}"]
    if meta:
        lines.append(json.dumps(meta, ensure_ascii=False))
    for event in events:
        lines.append(json.dumps(event, ensure_ascii=False))
    lines.append("")
    lines.append("Transcript Events")
    if not events:
        lines.append("(none)")
    return "\n".join(lines) + "\n"


__all__ = [
    "_history_table",
    "_load_transcript_text",
    "_decode_transcript",
    "_maybe_launch_transcript_viewer",
    "_render_transcript_display",
]
