# pyright: reportGeneralTypeIssues=false
"""Multi-select picker overlays for tools and MCPs in `/agents`."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from rich.text import Text as RichText

from glaip_sdk.cli.slash.tui.agent_picker_confirm_modal import AgentPickerConfirmModal
from glaip_sdk.cli.slash.tui.agent_picker_shared import (
    CHECKMARK,
    TEXTUAL_SUPPORTED,
    BaseAgentPickerScreen,
    DataTableType,
    PickerLayoutConfig,
    PickerOption,
    StaticType,
    build_picker_css,
    filter_picker_options,
    summarize_picker_labels,
)
from glaip_sdk.cli.slash.tui.agent_picker_shared import (
    Binding as SharedBinding,
)

RESOURCE_LAYOUT = PickerLayoutConfig(
    prefix="resource-picker",
    card_width=96,
    card_height=30,
    columns=("Sel", "Name", "Info"),
    apply_label="Apply",
)


@dataclass(frozen=True)
class AgentResourcePickerInput:
    """Payload used by the tools/MCPs picker screen."""

    title: str
    search_placeholder: str
    options: tuple[PickerOption, ...]
    selected_ids: tuple[str, ...] = ()


class AgentToolsPickerScreen(BaseAgentPickerScreen):
    """Modal multi-select picker reused for tools and MCP attachments."""

    LAYOUT = RESOURCE_LAYOUT
    CSS = build_picker_css("AgentToolsPickerScreen", RESOURCE_LAYOUT)
    if SharedBinding:
        BINDINGS = [
            SharedBinding("escape", "cancel", "Cancel", priority=True),
            SharedBinding("enter", "apply", "Apply", priority=True),
            SharedBinding("space", "toggle_selection", "Toggle", priority=True),
            SharedBinding("up", "move_up", "Up", priority=True, show=False),
            SharedBinding("down", "move_down", "Down", priority=True, show=False),
        ]
    else:  # pragma: no cover - optional dependency missing
        BINDINGS = []

    def __init__(self, payload: AgentResourcePickerInput) -> None:
        """Store the resource picker payload and current multi-select state."""
        super().__init__(title=payload.title, search_placeholder=payload.search_placeholder)
        self._payload = payload
        self._filtered_options: list[PickerOption] = list(payload.options)
        self._selected_ids: set[str] = {item for item in payload.selected_ids if item}

    def _refresh_table(self) -> None:
        query = self.query_one(f"#{self._picker_id('search')}").value if self.is_mounted else ""
        current_id = self._selected_option_id()
        self._filtered_options = filter_picker_options(self._payload.options, query)
        table = self.query_one(f"#{self._picker_id('table')}", DataTableType)
        table.clear(columns=False)
        for option in self._filtered_options:
            is_selected = option.id in self._selected_ids
            state_cell = RichText(CHECKMARK, style="bold #7dd3a0") if is_selected else RichText("", style="#5b738a")
            name_style = "bold #f5fbff" if is_selected else "#d7e4f2"
            info_style = "#b9c8d6" if is_selected else "#8fa4ba"
            table.add_row(
                state_cell,
                RichText(option.label, style=name_style),
                RichText(option.detail or "-", style=info_style),
            )
        self._set_cursor_for_option(current_id)
        self._refresh_summary()
        self._refresh_status()

    def _labels_for_ids(self, ids: set[str] | tuple[str, ...]) -> list[str]:
        selected_set = {item for item in ids if item}
        payload_lookup = {option.id: option.label for option in self._payload.options}
        return [payload_lookup[option_id] for option_id in payload_lookup if option_id in selected_set]

    def _selected_labels(self) -> list[str]:
        return self._labels_for_ids(self._selected_ids)

    def _current_labels(self) -> list[str]:
        return self._labels_for_ids(self._payload.selected_ids)

    def _highlighted_label(self) -> str:
        highlighted_id = self._selected_option_id()
        for option in self._filtered_options:
            if option.id == highlighted_id:
                return option.label
        return "none"

    def _refresh_summary(self) -> None:
        current_labels = self._current_labels()
        pending_labels = self._selected_labels()
        summary = RichText()
        summary.append(f"Current ({len(current_labels)}): ", style="bold #8fa4ba")
        summary.append(summarize_picker_labels(current_labels), style="#f5fbff")
        summary.append("\n")
        summary.append(f"Pending ({len(pending_labels)}): ", style="bold #8fa4ba")
        summary.append(summarize_picker_labels(pending_labels), style="bold #7dd3a0" if pending_labels else "#f5fbff")
        self.query_one(f"#{self._picker_id('summary')}", StaticType).update(summary)

    def _refresh_status(self) -> None:
        if not self._filtered_options:
            text = "No matching resources. Adjust search or press Esc to cancel."
        else:
            text = (
                f"{len(self._filtered_options)} shown. Highlighted: {self._highlighted_label()}. "
                "Space toggles, Apply or Enter opens confirmation, Esc cancels."
            )
        self.query_one(f"#{self._picker_id('status')}", StaticType).update(text)

    def action_toggle_selection(self) -> None:
        """Toggle the highlighted resource in the pending selection set."""
        option_id = self._selected_option_id()
        if not option_id:
            return
        if option_id in self._selected_ids:
            self._selected_ids.remove(option_id)
        else:
            self._selected_ids.add(option_id)
        self._refresh_table()

    def action_apply(self) -> None:
        """Open confirmation and dismiss only after a confirmed resource update."""
        selected_ids = sorted(self._selected_ids)
        if selected_ids == sorted(item for item in self._payload.selected_ids if item):
            self.dismiss(selected_ids)
            return

        lines = (
            f"Current: {summarize_picker_labels(self._current_labels())}",
            f"Pending: {summarize_picker_labels(self._selected_labels())}",
            f"Selected count: {len(selected_ids)}",
        )
        modal_title = self._payload.title.replace("Select", "Confirm", 1) + " Update"
        self.app.push_screen(
            AgentPickerConfirmModal(title=modal_title, lines=lines),
            lambda confirmed: self._confirm_apply_selection(selected_ids, confirmed),
        )

    def _confirm_apply_selection(self, selected_ids: list[str], confirmed: bool | None) -> None:
        if confirmed:
            self.dismiss(selected_ids)

    def on_data_table_row_selected(self, event: Any) -> None:
        """Toggle the highlighted resource when the table emits a row selection event."""
        if getattr(event.data_table, "id", "") != self._picker_id("table"):
            return
        self.action_toggle_selection()


__all__ = [
    "AgentResourcePickerInput",
    "AgentToolsPickerScreen",
    "TEXTUAL_SUPPORTED",
]
