"""Shared layout constants for history-style TUI screens."""

from __future__ import annotations

HISTORY_LEFT_PANE_PERCENT = 55
HISTORY_RIGHT_PANE_PERCENT = 45

STATUS_COLUMN_WIDTH = 4
COMPACT_STARTED_COLUMN_WIDTH = 14
