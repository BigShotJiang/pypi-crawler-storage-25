"""Command palette helpers for Textual-based GL AIP SDK TUIs."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import Any

try:  # pragma: no cover - optional dependency guard
    from textual.binding import Binding
except Exception:  # pragma: no cover - textual unavailable
    Binding = None  # type: ignore[assignment]

from glaip_sdk.cli.slash.tui.keybind_registry import (
    KeybindRegistry,
    format_key_sequence,
    parse_key_sequence,
)

_IGNORED_BINDING_ACTIONS = frozenset({"command_palette", "noop"})


@dataclass(frozen=True)
class PaletteAction:
    """A single floating command palette entry."""

    action_id: str
    title: str
    category: str
    searchable_text: str
    callback: Callable[[], Any]
    hint_text: str | None = None
    merge_key: str | None = None
    callback_rank: int = 100
    display_rank: int = 500

    @property
    def display_text(self) -> str:
        """Return the primary row label shown in the palette."""
        return self.title


def build_palette_actions(app: object) -> list[PaletteAction]:
    """Build palette actions from registered keybinds, bindings, and slash routes."""
    actions: list[PaletteAction] = []
    seen: set[str] = set()

    for action in _collect_registry_actions(app):
        if action.action_id in seen:
            continue
        seen.add(action.action_id)
        actions.append(action)

    for action in _collect_binding_actions(app):
        if action.action_id in seen:
            continue
        seen.add(action.action_id)
        actions.append(action)

    for action in _collect_slash_actions(app):
        if action.action_id in seen:
            continue
        seen.add(action.action_id)
        actions.append(action)

    return _sort_palette_actions(_merge_palette_actions(actions))


def filter_palette_actions(actions: Sequence[PaletteAction], query: str) -> list[PaletteAction]:
    """Return actions sorted by best fuzzy match for the query."""
    normalized = " ".join(str(query or "").strip().lower().split())
    if not normalized:
        return _sort_palette_actions(actions)

    scored: list[tuple[int, int, PaletteAction]] = []
    for index, action in enumerate(actions):
        score = _match_score(action, normalized)
        if score is None:
            continue
        scored.append((score, index, action))

    scored.sort(key=lambda item: (-item[0], item[2].display_rank, item[1], item[2].title.lower()))
    return [action for _, _, action in scored]


def _collect_registry_actions(app: object) -> list[PaletteAction]:
    keybinds = _get_keybind_registry(app)
    if keybinds is None:
        return []

    actions: list[PaletteAction] = []
    for action_name in keybinds.actions():
        keybind = keybinds.get(action_name)
        if keybind is None:
            continue
        title = keybind.description or _title_from_action(action_name)
        search = " ".join(filter(None, (title, keybind.description, keybind.category or "", action_name)))
        metadata = _resolve_palette_metadata(
            app,
            method_name="get_palette_action_metadata",
            action=action_name,
            title=title,
            category=keybind.category or "Action",
            hint_text=keybinds.format(action_name) or None,
        )
        if metadata.get("hidden"):
            continue
        actions.append(
            PaletteAction(
                action_id=f"action:{action_name}",
                title=str(metadata.get("title", title)),
                category=str(metadata.get("category", keybind.category or "Action")),
                searchable_text=_append_search_keywords(search, metadata.get("keywords")),
                callback=_make_action_callback(app, action_name),
                hint_text=str(metadata.get("hint_text", keybinds.format(action_name) or "")) or None,
                merge_key=_coerce_optional_str(metadata.get("merge_key")),
                callback_rank=int(metadata.get("callback_rank", 100)),
                display_rank=int(metadata.get("display_rank", 500)),
            )
        )
    return actions


def _collect_binding_actions(app: object) -> list[PaletteAction]:
    bindings = getattr(app, "BINDINGS", ())
    actions: list[PaletteAction] = []

    for binding in bindings:
        normalized = _normalize_binding(binding)
        if normalized is None:
            continue
        if not normalized.description or normalized.action in _IGNORED_BINDING_ACTIONS:
            continue
        title = normalized.description.strip()
        hint_text = _format_binding_hint(normalized)
        search = " ".join(filter(None, (title, normalized.action, hint_text or "", "Action")))
        metadata = _resolve_palette_metadata(
            app,
            method_name="get_palette_action_metadata",
            action=normalized.action,
            title=title,
            category="Action",
            hint_text=hint_text,
        )
        if metadata.get("hidden"):
            continue
        actions.append(
            PaletteAction(
                action_id=f"action:{normalized.action}",
                title=str(metadata.get("title", title)),
                category=str(metadata.get("category", "Action")),
                searchable_text=_append_search_keywords(search, metadata.get("keywords")),
                callback=_make_action_callback(app, normalized.action),
                hint_text=str(metadata.get("hint_text", hint_text or "")) or None,
                merge_key=_coerce_optional_str(metadata.get("merge_key")),
                callback_rank=int(metadata.get("callback_rank", 100)),
                display_rank=int(metadata.get("display_rank", 500)),
            )
        )

    return actions


def _collect_slash_actions(app: object) -> list[PaletteAction]:
    slash_commands = getattr(app, "_slash_commands", ())
    actions: list[PaletteAction] = []

    for command in slash_commands:
        name = getattr(command, "name", "")
        description = getattr(command, "description", "")
        aliases = tuple(getattr(command, "aliases", ()) or ())
        route = getattr(command, "route", "transition")
        if not name:
            continue
        hint_text = ", ".join(dict.fromkeys((name, *aliases)))
        search = " ".join(filter(None, (name, name.lstrip("/"), description, *aliases, route, "Slash")))
        metadata = _resolve_palette_metadata(
            app,
            method_name="get_palette_slash_metadata",
            action=name,
            title=description or name,
            category="Slash",
            hint_text=hint_text,
            route=route,
            aliases=aliases,
        )
        if metadata.get("hidden"):
            continue
        actions.append(
            PaletteAction(
                action_id=f"slash:{name}",
                title=str(metadata.get("title", description or name)),
                category=str(metadata.get("category", "Slash")),
                searchable_text=_append_search_keywords(search, metadata.get("keywords")),
                callback=_make_slash_callback(app, name),
                hint_text=str(metadata.get("hint_text", hint_text)) or None,
                merge_key=_coerce_optional_str(metadata.get("merge_key")),
                callback_rank=int(metadata.get("callback_rank", 50)),
                display_rank=int(metadata.get("display_rank", 500)),
            )
        )

    return actions


def _normalize_binding(binding: object) -> Any | None:
    if Binding is None:
        return None
    if isinstance(binding, Binding):
        return binding
    if isinstance(binding, Sequence) and len(binding) >= 2:
        key = str(binding[0])
        action = str(binding[1])
        description = str(binding[2]) if len(binding) >= 3 else ""
        return Binding(key, action, description)
    return None


def _get_keybind_registry(app: object) -> KeybindRegistry | None:
    ctx = getattr(app, "ctx", None)
    if ctx is not None:
        return getattr(ctx, "keybinds", None)
    return None


def _format_binding_hint(binding: Any) -> str | None:
    key_display = binding.key_display or ""
    if key_display:
        return key_display

    sequence = parse_key_sequence(binding.key)
    if not sequence:
        return None
    return format_key_sequence(sequence)


def _make_action_callback(app: object, action: str) -> Callable[[], Any]:
    def callback() -> Any:
        runner = getattr(app, "run_action", None)
        if callable(runner):
            schedule = getattr(app, "call_next", None)
            if callable(schedule):
                schedule(runner, action)
                return None
            return runner(action)
        return None

    return callback


def _make_slash_callback(app: object, command_name: str) -> Callable[[], Any]:
    def callback() -> Any:
        runner = getattr(app, "run_palette_slash_command", None)
        if callable(runner):
            return runner(command_name)
        return None

    return callback


def _title_from_action(action: str) -> str:
    token = action.split(".")[-1]
    return token.replace("_", " ").title()


def _resolve_palette_metadata(app: object, *, method_name: str, **kwargs: Any) -> dict[str, Any]:
    resolver = getattr(app, method_name, None)
    if not callable(resolver):
        return {}
    resolved = resolver(**kwargs)
    if not isinstance(resolved, dict):
        return {}
    return resolved


def _append_search_keywords(base: str, extra_keywords: object) -> str:
    keywords: list[str] = []
    if isinstance(extra_keywords, str):
        keywords.append(extra_keywords)
    elif isinstance(extra_keywords, Sequence):
        keywords.extend(str(keyword) for keyword in extra_keywords if keyword)
    return " ".join(filter(None, (base, *keywords)))


def _coerce_optional_str(value: object) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    return normalized or None


def _merge_palette_actions(actions: Sequence[PaletteAction]) -> list[PaletteAction]:
    merged: list[PaletteAction] = []
    index_by_key: dict[str, int] = {}

    for action in actions:
        merge_key = action.merge_key or action.action_id
        existing_index = index_by_key.get(merge_key)
        if existing_index is None:
            index_by_key[merge_key] = len(merged)
            merged.append(action)
            continue

        current = merged[existing_index]
        merged[existing_index] = _combine_palette_actions(current, action)

    return merged


def _sort_palette_actions(actions: Sequence[PaletteAction]) -> list[PaletteAction]:
    """Return actions in explicit suggested-order rank for blank-query display."""
    indexed_actions = list(enumerate(actions))
    indexed_actions.sort(key=lambda item: (item[1].display_rank, item[0], item[1].title.lower()))
    return [action for _, action in indexed_actions]


def _combine_palette_actions(left: PaletteAction, right: PaletteAction) -> PaletteAction:
    primary, secondary = (left, right)
    if right.callback_rank < left.callback_rank:
        primary, secondary = (right, left)

    hints = _merge_hint_text(left.hint_text, right.hint_text)
    search = " ".join(
        dict.fromkeys(
            part for part in (left.searchable_text, right.searchable_text, left.title, right.title, hints or "") if part
        )
    )

    return PaletteAction(
        action_id=primary.action_id,
        title=primary.title,
        category=primary.category,
        searchable_text=search,
        callback=primary.callback,
        hint_text=hints,
        merge_key=primary.merge_key or secondary.merge_key,
        callback_rank=min(left.callback_rank, right.callback_rank),
        display_rank=min(left.display_rank, right.display_rank),
    )


def _merge_hint_text(*hint_values: str | None) -> str | None:
    tokens: list[str] = []
    for hint in hint_values:
        if not hint:
            continue
        tokens.extend(part.strip() for part in hint.split(",") if part.strip())

    merged = ", ".join(dict.fromkeys(tokens))
    return merged or None


def _match_score(action: PaletteAction, query: str) -> int | None:
    title = action.title.lower()
    hint = (action.hint_text or "").lower()
    combined = f"{title} {action.category.lower()} {hint} {action.searchable_text.lower()}"

    if query == title:
        return 1000
    if title.startswith(query):
        return 900 - title.index(query)
    if query in title:
        return 800 - title.index(query)
    if hint and hint.startswith(query):
        return 760
    if query in combined:
        return 700 - combined.index(query)

    tokens = [token for token in query.split() if token]
    if tokens and all(token in combined for token in tokens):
        return 620

    if len(query) > 3:
        return None

    subsequence_score = _subsequence_penalty(combined, query)
    if subsequence_score is None:
        return None
    return 500 - subsequence_score


def _subsequence_penalty(candidate: str, query: str) -> int | None:
    position = -1
    indices: list[int] = []
    for character in query:
        position = candidate.find(character, position + 1)
        if position < 0:
            return None
        indices.append(position)

    if len(indices) <= 1:
        return indices[0] if indices else 0
    return sum(current - previous - 1 for previous, current in zip(indices, indices[1:], strict=False))


_EXIT_WORKSPACE_TITLE = "Exit workspace"

PALETTE_ACTION_METADATA: dict[str, dict[str, Any]] = {
    "close_overlay_or_exit": {
        "title": _EXIT_WORKSPACE_TITLE,
        "category": "Navigation",
        "merge_key": "exit-surface",
        "keywords": ("close", "quit", "escape", "esc", "exit", "back"),
        "callback_rank": 80,
    },
    "quit": {
        "title": _EXIT_WORKSPACE_TITLE,
        "category": "Navigation",
        "merge_key": "exit-surface",
        "keywords": ("close", "quit", "escape", "esc", "exit", "back"),
        "callback_rank": 90,
    },
    "quick_agents_selector": {
        "title": "Browse agents",
        "category": "Command",
        "merge_key": "open-agents",
        "keywords": ("agents", "/agents", "browse agents", "open workspace"),
        "callback_rank": 120,
    },
    "toggle_sidebar": {
        "title": "Toggle agent details",
        "category": "View",
        "merge_key": "toggle-agent-sidebar",
        "keywords": ("details", "sidebar", "agent details"),
    },
    "transcript_hint": {
        "title": "Open transcript viewer",
        "category": "Command",
        "merge_key": "open-transcripts",
        "keywords": ("transcript", "/transcripts", "history", "viewer"),
        "callback_rank": 120,
    },
    "transcript_page_up": {
        "title": "Scroll transcript up",
        "category": "Navigation",
        "keywords": ("page up", "scroll up", "transcript"),
    },
    "transcript_page_down": {
        "title": "Scroll transcript down",
        "category": "Navigation",
        "keywords": ("page down", "scroll down", "transcript"),
    },
    "copy_last_details": {
        "title": "Copy agent details snapshot",
        "category": "Clipboard",
        "keywords": ("copy", "details", "clipboard"),
    },
}

PALETTE_SLASH_METADATA: dict[str, dict[str, Any]] = {
    "/exit": {
        "title": _EXIT_WORKSPACE_TITLE,
        "category": "Navigation",
        "merge_key": "exit-surface",
        "keywords": ("close", "quit", "exit", "back"),
        "callback_rank": 50,
    },
    "/q": {
        "title": _EXIT_WORKSPACE_TITLE,
        "category": "Navigation",
        "merge_key": "exit-surface",
        "keywords": ("close", "quit", "exit", "back"),
        "callback_rank": 50,
    },
    "/agents": {
        "title": "Browse agents",
        "category": "Command",
        "merge_key": "open-agents",
        "keywords": ("agents", "browse agents", "selector", "open workspace"),
        "callback_rank": 50,
    },
    "/transcripts": {
        "title": "Open transcript viewer",
        "category": "Command",
        "merge_key": "open-transcripts",
        "keywords": ("transcripts", "history", "viewer"),
        "callback_rank": 50,
    },
    "/help": {
        "title": "Browse available commands",
        "category": "Command",
        "keywords": ("help", "commands", "shortcuts"),
        "callback_rank": 50,
    },
    "/details": {
        "title": "View agent details",
        "category": "Command",
        "keywords": ("details", "agent details", "snapshot"),
        "callback_rank": 50,
    },
    "/status": {
        "title": "View status",
        "category": "Command",
        "keywords": ("status", "health", "diagnostics"),
        "callback_rank": 50,
    },
    "/mcps": {
        "title": "Manage MCP connections",
        "category": "Command",
        "keywords": ("mcps", "mcp", "connections", "attach", "detach"),
        "callback_rank": 50,
    },
    "/models": {
        "title": "Change active model",
        "category": "Command",
        "keywords": ("models", "model", "switch model"),
        "callback_rank": 50,
    },
    "/tools": {
        "title": "Manage tools",
        "category": "Command",
        "keywords": ("tools", "attach", "detach", "enabled tools"),
        "callback_rank": 50,
    },
    "/prompt": {
        "title": "Edit agent instructions",
        "category": "Command",
        "keywords": ("prompt", "instructions", "system prompt"),
        "callback_rank": 50,
    },
    "/runs": {
        "title": "Browse run history",
        "category": "Command",
        "keywords": ("runs", "history", "activity"),
        "callback_rank": 50,
    },
    "/schedules": {
        "title": "Manage recurring schedules",
        "category": "Command",
        "keywords": ("schedules", "recurring runs", "cron"),
        "callback_rank": 50,
    },
    "/accounts": {
        "title": "Manage accounts",
        "category": "Command",
        "keywords": ("accounts", "switch account"),
        "callback_rank": 50,
    },
    "/update": {
        "title": "Update CLI",
        "category": "Command",
        "keywords": ("update", "upgrade", "cli"),
        "callback_rank": 50,
    },
}


def get_palette_action_static_metadata(action: str) -> dict[str, Any]:
    """Return static metadata for an action from the palette metadata map."""
    normalized = action.split(".")[-1]
    return PALETTE_ACTION_METADATA.get(normalized, {})


def get_palette_slash_static_metadata(command: str) -> dict[str, Any]:
    """Return static metadata for a slash command from the palette metadata map."""
    return PALETTE_SLASH_METADATA.get(command, {})
