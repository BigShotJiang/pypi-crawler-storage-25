"""Shared timestamp formatting helpers for TUI tables."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any


def format_compact_table_timestamp(
    value: Any,
    *,
    now: datetime | None = None,
    placeholder: str = "-",
) -> str:
    """Format timestamps for dense TUI table display.

    Rules:
    - Missing value -> placeholder
    - Under 1 minute -> ``Ns ago``
    - Under 1 hour -> ``Nmin ago``
    - Under 24 hours -> ``Nh ago``
    - Under 30 days -> ``Nd ago``
    - 30+ days -> ``N month ago`` or ``N months ago``

    All calculations and clock rendering use UTC.
    """
    if value is None:
        return placeholder
    if not isinstance(value, datetime):
        return str(value)

    try:
        dt_utc = _as_utc(value)
        ref_utc = _as_utc(now or datetime.now(UTC))
        delta_seconds = int((ref_utc - dt_utc).total_seconds())
        if delta_seconds < 0:
            # Clock skew / future values still stay in compact "ago" shape.
            return "1s ago"

        magnitude = delta_seconds

        if magnitude < 60:
            label = f"{magnitude}s"
        elif magnitude < 3600:
            amount = max(1, magnitude // 60)
            unit = "min"
            label = f"{amount}{unit}"
        elif magnitude < 86400:
            amount = max(1, magnitude // 3600)
            unit = "h"
            label = f"{amount}{unit}"
        elif magnitude < 30 * 86400:
            amount = max(1, magnitude // 86400)
            unit = "d"
            label = f"{amount}{unit}"
        else:
            amount = max(1, magnitude // (30 * 86400))
            unit = " month" if amount == 1 else " months"
            label = f"{amount}{unit}"

        return f"{label} ago"
    except Exception:
        return str(value)


def _as_utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        # Treat naive datetimes as UTC (not local timezone)
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


def format_utc_absolute_timestamp(
    value: Any,
    placeholder: str = "-",
) -> str:
    """Format timestamps as absolute UTC for detail views.

    Shows full datetime in format: "Jan 15 2026 08:30:45 UTC"

    Args:
        value: datetime to format
        placeholder: shown for None/invalid values
    """
    if value is None:
        return placeholder
    if not isinstance(value, datetime):
        return str(value)

    try:
        dt_utc = _as_utc(value)
        return dt_utc.strftime("%b %d %Y %H:%M:%S UTC")
    except Exception:
        return str(value)


__all__ = ["format_compact_table_timestamp", "format_utc_absolute_timestamp"]
