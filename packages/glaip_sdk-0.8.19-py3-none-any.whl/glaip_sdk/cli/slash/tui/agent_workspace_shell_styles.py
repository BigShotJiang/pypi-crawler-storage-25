"""Styling helpers for the agent workspace shell TUI."""

from __future__ import annotations

from glaip_sdk.cli.slash.tui.styles import load_tcss_template


def build_workspace_css(ui: dict[str, str]) -> str:
    """Build workspace CSS from a standard `.tcss` template."""
    return load_tcss_template(
        "agent_workspace_shell.tcss",
        {
            "screen": ui["screen"],
            "workspace": ui["workspace"],
            "heading": ui["heading"],
            "muted": ui["muted"],
            "text": ui["text"],
            "border": ui["border"],
            "panel_alt": ui["panel_alt"],
            "accent": ui["accent"],
            "brand": ui["brand"],
            "panel": ui["panel"],
        },
    )
