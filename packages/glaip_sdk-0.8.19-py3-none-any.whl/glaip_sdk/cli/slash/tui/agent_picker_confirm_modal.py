"""Confirmation modal for `/agents` picker updates."""

from __future__ import annotations

from typing import Any, cast

try:  # pragma: no cover - optional dependency
    from textual.app import ComposeResult
    from textual.binding import Binding
    from textual.containers import Horizontal, Vertical
    from textual.screen import ModalScreen
    from textual.widgets import Button, Static
except Exception:  # pragma: no cover - optional dependency
    ComposeResult = None  # type: ignore[assignment]
    Binding = None  # type: ignore[assignment]
    Horizontal = None  # type: ignore[assignment]
    Vertical = None  # type: ignore[assignment]
    ModalScreen = None  # type: ignore[assignment]
    Button = None  # type: ignore[assignment]
    Static = None  # type: ignore[assignment]


TEXTUAL_SUPPORTED = ModalScreen is not None and Button is not None and Static is not None

_ConfirmBase = cast(Any, ModalScreen) if ModalScreen is not None else cast(Any, object)
StaticType = cast(Any, Static)
ButtonType = cast(Any, Button)
HorizontalType = cast(Any, Horizontal)
VerticalType = cast(Any, Vertical)


class AgentPickerConfirmModal(_ConfirmBase):  # type: ignore[misc]
    """Modal that requires explicit confirmation before picker saves."""

    CSS = """
    AgentPickerConfirmModal {
        align: center middle;
        background: rgba(6, 10, 16, 0.82);
    }

    #picker-confirm-card {
        width: 78;
        max-width: 92vw;
        border: round #40b4e5;
        background: #101923;
        padding: 1 2;
        layout: vertical;
    }

    #picker-confirm-title {
        color: #f2b266;
        text-style: bold;
        margin-bottom: 1;
    }

    .picker-confirm-line {
        color: #d7e4f2;
        background: #142131;
        border: round #28455f;
        padding: 0 1;
        margin-bottom: 1;
    }

    #picker-confirm-warning {
        color: #8fa4ba;
        margin-bottom: 1;
    }

    #picker-confirm-actions {
        height: auto;
        align-horizontal: right;
    }
    """

    if Binding:
        BINDINGS = [
            Binding("escape", "cancel", "Cancel", priority=True),
            Binding("enter", "confirm", "Confirm", priority=True),
        ]
    else:  # pragma: no cover - optional dependency missing
        BINDINGS = []

    def __init__(self, *, title: str, lines: tuple[str, ...], confirm_label: str = "Apply") -> None:
        """Store modal copy and button labels for one picker confirmation."""
        super().__init__()
        self._title = title
        self._lines = tuple(line for line in lines if str(line).strip())
        self._confirm_label = confirm_label

    def compose(self) -> ComposeResult:  # type: ignore[override]
        """Compose the confirmation card and action buttons."""
        if not TEXTUAL_SUPPORTED:
            return  # pragma: no cover  # type: ignore[return-value]
        with VerticalType(id="picker-confirm-card"):
            yield StaticType(self._title, id="picker-confirm-title")
            for index, line in enumerate(self._lines):
                yield StaticType(line, classes="picker-confirm-line", id=f"picker-confirm-line-{index}")
            yield StaticType(
                "Press Apply to persist this update, or Cancel to keep editing.", id="picker-confirm-warning"
            )
            with HorizontalType(id="picker-confirm-actions"):
                yield ButtonType(self._confirm_label, id="picker-confirm-apply", variant="primary")
                yield ButtonType("Cancel", id="picker-confirm-cancel")

    def on_mount(self) -> None:
        """Focus the primary action so Enter confirms quickly."""
        try:
            self.query_one("#picker-confirm-apply", ButtonType).focus()
        except Exception:  # pragma: no cover - best effort focus
            pass

    def action_confirm(self) -> None:
        """Dismiss the modal with an affirmative confirmation."""
        self.dismiss(True)

    def action_cancel(self) -> None:
        """Dismiss the modal without applying changes."""
        self.dismiss(None)

    def on_button_pressed(self, event: Any) -> None:
        """Route confirm/cancel button presses to modal actions."""
        button_id = getattr(event.button, "id", "")
        if button_id == "picker-confirm-apply":
            self.action_confirm()
            return
        if button_id == "picker-confirm-cancel":
            self.action_cancel()


__all__ = ["AgentPickerConfirmModal", "TEXTUAL_SUPPORTED"]
