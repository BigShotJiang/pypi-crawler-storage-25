"""Shared helpers for palette `/accounts`.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from typing import Any

from glaip_sdk.cli.masking import mask_api_key_display


def build_account_status_string(row: dict[str, Any], *, use_markup: bool = False) -> str:
    """Build status string for an account row.

    When `use_markup` is True, returns Rich markup strings for Textual/Rich rendering;
    when False, returns plain text for console output.
    """
    if row.get("active"):
        return "[bold green]● active[/]" if use_markup else "● active"
    return ""


def build_account_rows(
    accounts: dict[str, dict[str, str]],
    active_account: str | None,
) -> list[dict[str, str | bool]]:
    """Build account rows for display from accounts dict.

    Args:
        accounts: Dictionary mapping account names to account data.
        active_account: Name of the currently active account.

    Returns:
        List of account row dictionaries with name, api_url, masked_key, and active.
    """
    rows: list[dict[str, str | bool]] = []
    for name, account in sorted(accounts.items()):
        rows.append(
            {
                "name": name,
                "api_url": account.get("api_url", ""),
                "masked_key": mask_api_key_display(account.get("api_key", "")),
                "active": name == active_account,
            }
        )
    return rows
