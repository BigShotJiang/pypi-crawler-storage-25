"""Allow running as `python -m simurgh_dns`."""

from simurgh_dns.cli import main

main()
