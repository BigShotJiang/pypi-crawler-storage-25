"""simurgh-dns: A cross-platform CLI tool to benchmark public DNS servers."""

__version__ = "0.1.0"
