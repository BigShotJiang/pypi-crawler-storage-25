# LEARNED.md — pythonDeveloper

> Auto-updated by the pythonDeveloper skill. Every correction, preference, and discovered convention is recorded here. Rules in this file override defaults in SKILL.md.

## Corrections

<!-- User corrections to generated code. Format: - YYYY-MM-DD: rule description -->

## Preferences

<!-- User stated preferences. Format: - YYYY-MM-DD: preference description -->

## Discovered Conventions

<!-- Implicit project patterns found by analysis. Format: - YYYY-MM-DD: convention description -->
