## Summary

<!-- Brief description of what this PR does -->

## Changes

-

## Type of Change

- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update
- [ ] Refactoring

## Testing

- [ ] Existing tests pass (`uv run pytest`)
- [ ] New tests added (if applicable)
- [ ] Linting passes (`uv run ruff check src/ tests/`)

## Notes

<!-- Any additional context, screenshots, or considerations -->
