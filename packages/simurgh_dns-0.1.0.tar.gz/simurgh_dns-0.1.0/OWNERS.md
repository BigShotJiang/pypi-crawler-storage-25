# Project Owners

## Maintainer

**Alireza Soltani**

- GitHub: [@alirezasoltani](https://github.com/alirezasoltani)
- Role: Primary maintainer and creator

## Responsibilities

- Reviewing and merging pull requests
- Managing releases and PyPI publishing
- Triaging issues and setting project direction

## Decision Making

- Bug fixes and minor improvements can be merged by any maintainer
- New features or breaking changes require discussion in a GitHub issue first
- Security fixes are prioritized and fast-tracked
