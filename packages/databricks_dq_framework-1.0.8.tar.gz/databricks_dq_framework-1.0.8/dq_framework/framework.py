"""
DQFramework — Top-level facade
================================
Single entry point for the Data Quality Assessment Framework on Databricks.

Orchestrates all steps in the equivalent order to the SQL Server scripts:

    dq = DQFramework(spark, catalog="main", schema="dq")
    dq.setup()                          # Script_00 + Script_01
    dq.generate_rule_functions()        # p_DQ_GenerateRuleFunctions
    dq.run_assessment(schema_name=...) # p_DQ_DataAssessmentRules
"""

from __future__ import annotations

import logging
import uuid
from typing import Optional

from dq_framework.ddl_framework_tables import DDL_STATEMENTS, TABLE_ORDER, FRAMEWORK_SEEDED_TABLES, USER_CONFIG_TABLES
from dq_framework.seed_master_data import seed_master_data, BUILTIN_VALIDATORS, add_invalid_keyword, add_custom_pattern
from dq_framework.engine.generate_rule_functions import (
    FunctionRegistry,
    generate_rule_functions,
    register_validator,
    custom_validator_registry,
)
from dq_framework.engine.resolve_pattern_rules import resolve_patterns
from dq_framework.engine.data_assessment_rules import DQRunner
from dq_framework.reporting.views import create_reporting_views
from dq_framework.config import ConfigManager

logger = logging.getLogger(__name__)


class DQFramework:
    """
    Data Quality Assessment Framework for Databricks.

    Parameters
    ----------
    spark
        Active SparkSession.
    catalog
        Unity Catalog name.  Pass ``""`` to use the legacy Hive metastore.
    schema
        Schema / database for framework tables.  Default: ``"dq"``.
    """

    def __init__(self, spark, catalog: str = "", schema: str = "dq"):
        self.spark = spark
        self.catalog = catalog
        self.dq_schema = schema
        self._registry = FunctionRegistry()
        self._runner: Optional[DQRunner] = None

        # Register all built-in custom validators (email rules etc.)
        for name, fn in BUILTIN_VALIDATORS.items():
            register_validator(name, fn)

    # ------------------------------------------------------------------
    # Setup (equivalent to Script_00 + Script_01)
    # ------------------------------------------------------------------

    def setup(self, seed_data: bool = True) -> None:
        """
        Create the framework schema and all Delta tables, then seed master
        reference data.

        Equivalent to running Script_00_DDL_Framework_Tables.sql followed by
        Script_01_Master_Reference_Data.sql.

        Idempotency
        -----------
        Safe to call multiple times on the same catalog/schema:
        - ``CREATE SCHEMA IF NOT EXISTS`` — no-op if schema exists
        - ``CREATE TABLE IF NOT EXISTS`` — no-op if table exists
        - Master data seeding uses INSERT-ONLY MERGE — never overwrites
          existing rows (user modifications and custom keywords are preserved)

        Two kinds of tables
        -------------------
        FRAMEWORK-MANAGED (auto-seeded):
            masterDataCategory  — 27 data type classifications
            masterPattern       — 118 built-in validation patterns
            Users MAY add custom patterns using _ID >= 1000.

        USER-MANAGED (empty after setup, populated by project team):
            masterField, configFieldValues, configFieldAllowedPattern,
            configCustomQuery, mapDQChecks
            → Use ``dq.config`` (ConfigManager) or raw Spark SQL to populate.

        RESULTS (auto-populated by ``run_assessment()``):
            auditDQChecks, statDQChecks

        Parameters
        ----------
        seed_data
            If True (default) seed the 27 categories and 118 patterns.
            Pass False on subsequent calls to skip reseeding (INSERT-ONLY
            MERGE means it is harmless either way, but False is faster).

        Raises
        ------
        RuntimeError
            If ``catalog`` is specified but does not exist in Unity Catalog.
        """
        self._verify_catalog()
        self._create_schema()
        self._create_tables()
        create_reporting_views(self.spark, self.catalog, self.dq_schema)
        if seed_data:
            seed_master_data(self.spark, self.catalog, self.dq_schema)
            logger.info(
                "Framework-managed master data seeded successfully. "
                "User-managed tables (masterField, configFieldValues, "
                "configFieldAllowedPattern, configCustomQuery, mapDQChecks) "
                "are empty — populate them via dq.config or Spark SQL."
            )

    def _verify_catalog(self) -> None:
        """
        Verify that the specified Unity Catalog exists before trying to use it.
        Provides a helpful error message rather than a cryptic Spark exception.
        """
        if not self.catalog:
            return  # Legacy Hive metastore — no catalog check needed
        try:
            catalogs = [r["catalog"] for r in
                        self.spark.sql("SHOW CATALOGS").collect()]
            if self.catalog not in catalogs:
                raise RuntimeError(
                    f"Unity Catalog '{self.catalog}' does not exist. "
                    f"Available catalogs: {catalogs}. "
                    f"Create it first with: CREATE CATALOG `{self.catalog}`"
                )
        except Exception as exc:
            if "does not exist" in str(exc):
                raise
            # SHOW CATALOGS may not be supported in all environments — skip check
            logger.debug("Could not verify catalog existence: %s", exc)

    def _create_schema(self) -> None:
        fqn = (f"`{self.catalog}`.`{self.dq_schema}`"
               if self.catalog else f"`{self.dq_schema}`")
        self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {fqn}")
        logger.info("Schema ready: %s", fqn)

    def _create_tables(self) -> None:
        for table_name in TABLE_ORDER:
            ddl = DDL_STATEMENTS[table_name]
            fqn = self._fqn(table_name)
            rendered = ddl.format(fqn=fqn)
            self.spark.sql(rendered)
            table_type = (
                "[FRAMEWORK-MANAGED]" if table_name in FRAMEWORK_SEEDED_TABLES
                else "[USER-MANAGED]"   if table_name in USER_CONFIG_TABLES
                else "[RESULTS]"
            )
            logger.info("Table ready: %s  %s", fqn, table_type)

    def _fqn(self, table_name: str) -> str:
        if self.catalog:
            return f"`{self.catalog}`.`{self.dq_schema}`.`{table_name}`"
        return f"`{self.dq_schema}`.`{table_name}`"

    # ------------------------------------------------------------------
    # ConfigManager — Python API for user configuration
    # ------------------------------------------------------------------

    @property
    def config(self) -> ConfigManager:
        """
        Python API for populating user-managed configuration tables.

        Equivalent to writing INSERT/MERGE statements in Script_02.

        Example
        -------
        dq.config.register_field(1, 'Source.SRC_Party.FIRST_NAME', data_category_type_id=2) \\
                 .set_field_values(1, 'Source.SRC_Party.FIRST_NAME', min_data_length=2, max_data_length=20) \\
                 .block_category(1, 'Source.SRC_Party.FIRST_NAME', 'DataEmptiness') \\
                 .allow_pattern(2, 'Source.SRC_Party.FIRST_NAME', 'Has Hyphen') \\
                 .add_mapping(1, 'Source.SRC_Party.FIRST_NAME',
                              target_schema_name='Curated',
                              target_table_name='Individual_Denorm',
                              target_field_name='FIRST_NAME')
        dq.config.show_config_summary()
        """
        return ConfigManager(self.spark, self.catalog, self.dq_schema)

    # ------------------------------------------------------------------
    # Custom keyword / pattern management
    # ------------------------------------------------------------------

    def add_invalid_keyword(
        self,
        keyword: str,
        pattern_id: int,
        priority: int = 30,
        description: str = None,
    ) -> "DQFramework":
        """
        Add a project-specific invalid keyword to ``masterPattern``.

        The InvalidKeyword check fires when the keyword comprises >= 50%
        of the value (case-insensitive) — same threshold as the built-in
        40 keywords.

        After calling this, re-run ``generate_rule_functions()`` for the
        new keyword to take effect.

        Parameters
        ----------
        keyword
            The keyword to detect (e.g. 'nodata', 'noemail', 'notset').
        pattern_id
            Must be >= 1000.  Framework reserves IDs 1–999.

        Example
        -------
        dq.add_invalid_keyword('nodata',  pattern_id=1000)
        dq.add_invalid_keyword('noemail', pattern_id=1001)
        dq.generate_rule_functions()
        """
        add_invalid_keyword(
            self.spark, self.catalog, self.dq_schema,
            keyword, pattern_id, priority, description
        )
        return self

    def add_custom_pattern(
        self,
        pattern_id: int,
        pattern_category: str,
        pattern_name: str,
        pattern_priority: int,
        pattern_value: str = None,
        pattern_subcategory: str = None,
        pattern_description: str = None,
    ) -> "DQFramework":
        """
        Add any custom validation pattern to ``masterPattern``.

        After adding:
        1. Add allow/block rules in ``configFieldAllowedPattern``.
        2. Register a Python check function if needed (for custom categories).
        3. Re-run ``generate_rule_functions()``.

        pattern_id must be >= 1000.
        """
        add_custom_pattern(
            self.spark, self.catalog, self.dq_schema,
            pattern_id, pattern_category, pattern_name, pattern_priority,
            pattern_value, pattern_subcategory, pattern_description
        )
        return self

    # ------------------------------------------------------------------
    # Custom validator registration
    # ------------------------------------------------------------------

    def register_validator(self, name: str, fn) -> "DQFramework":
        """
        Register a Python callable as a named custom validator for use in
        ``configCustomQuery.CustomQuery``.

        Parameters
        ----------
        name
            The string to store in ``configCustomQuery.CustomQueryPython``.
        fn
            A callable ``(value: str | None) -> bool`` that returns True when
            the condition is matched.

        Returns self for method chaining.
        """
        register_validator(name, fn)
        return self

    # ------------------------------------------------------------------
    # generate_rule_functions (equivalent to p_DQ_GenerateRuleFunctions)
    # ------------------------------------------------------------------

    def generate_rule_functions(self, execution_id: Optional[str] = None) -> None:
        """
        Build field-level checker functions from the configuration tables.

        Equivalent to ``EXEC [dq].[p_DQ_GenerateRuleFunctions]``.

        Must be called (or re-called) whenever any configuration table is
        modified: masterField, configFieldValues, configFieldAllowedPattern,
        or configCustomQuery.

        Parameters
        ----------
        execution_id
            Optional batch identifier embedded in log output.
        """
        if execution_id is None:
            execution_id = str(uuid.uuid4())

        # Load config tables
        cfap = [row.asDict() for row in
                self.spark.table(self._fqn("configFieldAllowedPattern"))
                    .filter("IsActive = true").collect()]
        mp   = [row.asDict() for row in
                self.spark.table(self._fqn("masterPattern"))
                    .filter("IsActive = true").collect()]
        fv   = [row.asDict() for row in
                self.spark.table(self._fqn("configFieldValues"))
                    .filter("IsActive = true").collect()]
        cq   = [row.asDict() for row in
                self.spark.table(self._fqn("configCustomQuery"))
                    .filter("IsActive = true AND CustomQuery IS NOT NULL").collect()]

        # L0A: Resolve pattern precedence
        resolved = resolve_patterns(cfap, mp)

        # Generate and register field checkers
        generate_rule_functions(resolved, fv, cq, self._registry, execution_id)

        logger.info(
            "generate_rule_functions complete. %d functions in registry.",
            len(self._registry)
        )

        fn_list = sorted(self._registry.list_functions())
        print(f"✓ generate_rule_functions complete — {len(fn_list)} field checker(s) registered:")
        for fn in fn_list:
            sql_count = len(self._registry.get_sql_expressions(fn))
            suffix = f"  [{sql_count} SQL expr]" if sql_count else ""
            print(f"  • {fn}{suffix}")

        # Warn about DQ functions referenced in mapDQChecks that have no checker
        # in the registry — meaning no rules were configured for them in any
        # config table.  The assessment runner skips these silently; this warning
        # surfaces the gap so users can act on it.
        mapped_fn_names = {
            row["DQFunctionName"]
            for row in self.spark.table(self._fqn("mapDQChecks"))
                .filter("IsActive = true")
                .select("DQFunctionName")
                .distinct()
                .collect()
        }
        registered_names = set(self._registry.list_functions())
        no_rules = [fn for fn in sorted(mapped_fn_names) if fn not in registered_names]
        if no_rules:
            print(f"\n  ⚠  {len(no_rules)} mapped DQ function(s) have no rules configured"
                  f" — skipped by assessment (add rules to include them):")
            for fn in no_rules:
                print(f"     • {fn}")

    # ------------------------------------------------------------------
    # run_assessment (equivalent to p_DQ_DataAssessmentRules)
    # ------------------------------------------------------------------

    def run_assessment(
        self,
        schema_name: Optional[str] = None,
        table_name: Optional[str] = None,
        field_name: Optional[str] = None,
        reset_eligible_flag: bool = False,
        enable_output: bool = True,
        execution_id: Optional[str] = None,
    ) -> str:
        """
        Execute the DQ assessment against curated Delta tables.

        Equivalent to ``EXEC [dq].[p_DQ_DataAssessmentRules]``.

        Parameters
        ----------
        schema_name
            Curated schema to assess.  None = all schemas.
        table_name
            Specific table to assess.  None = all tables in schema.
        field_name
            Specific field to assess.  None = all fields in table.
        reset_eligible_flag
            True = reset DQEligible / DQViolations / DQFields on previously
            failed rows (WHERE DQEligible = 0) and exit.
            False = run full assessment.
        enable_output
            True = display violation and quality score results.
        execution_id
            Supply a fixed UUID for grouped tracking; None generates a new one.

        Returns
        -------
        The ExecutionID used for this batch (use to filter reporting views).

        Examples
        --------
        # Assess all fields in the Curated schema:
        exec_id = dq.run_assessment(schema_name="Curated")

        # Assess a single table:
        exec_id = dq.run_assessment(schema_name="Curated",
                                    table_name="Individual_Denorm")

        # Reset DQ flags before re-assessment:
        dq.run_assessment(schema_name="Curated", reset_eligible_flag=True,
                          enable_output=False)
        """
        if not self._registry:
            raise RuntimeError(
                "Function registry is empty. Run generate_rule_functions() first. "
                "If you just called setup(), you also need to populate the user-managed "
                "config tables (masterField, configFieldAllowedPattern, configCustomQuery, "
                "mapDQChecks) via dq.config or Spark SQL before generating functions."
            )

        runner = DQRunner(self.spark, self.catalog, self.dq_schema, self._registry)
        return runner.run(
            schema_name=schema_name,
            table_name=table_name,
            field_name=field_name,
            reset_eligible_flag=reset_eligible_flag,
            enable_output=enable_output,
            execution_id=execution_id,
        )

    # ------------------------------------------------------------------
    # Convenience reporting helpers
    # ------------------------------------------------------------------

    def violations(self, execution_id: str = None):
        """Return a DataFrame of all violations for the given execution."""
        from dq_framework.reporting.views import query_violations
        return query_violations(self.spark, self.catalog, self.dq_schema, execution_id)

    def quality_scores(self, execution_id: str = None):
        """Return a DataFrame of quality scores per field for the given execution."""
        from dq_framework.reporting.views import query_quality_scores
        return query_quality_scores(self.spark, self.catalog, self.dq_schema, execution_id)

    def fields_below_threshold(self, threshold: float = 80.0):
        """Return fields with PercentageQualified below the given threshold."""
        from dq_framework.reporting.views import query_fields_below_threshold
        return query_fields_below_threshold(self.spark, self.catalog, self.dq_schema, threshold)

    def summary_by_table(self):
        """Return aggregated quality score per curated table."""
        from dq_framework.reporting.views import query_summary_by_table
        return query_summary_by_table(self.spark, self.catalog, self.dq_schema)

    # ------------------------------------------------------------------
    # Guide / help
    # ------------------------------------------------------------------

    def guide(self) -> None:
        """Print a concise usage guide for the DQ Framework."""
        import dq_framework as _dqf
        print(f"""
╔══════════════════════════════════════════════════════════════════════╗
║       Databricks DQ Non-Functional Assessment Framework  v{_dqf.__version__:<9}║
╚══════════════════════════════════════════════════════════════════════╝

WORKFLOW  (run steps in order)
──────────────────────────────────────────────────────────────────────
 1. dq.setup()
      Creates 9 Delta tables + 2 views in your DQ schema.
      Seeds 27 data categories and 118 built-in validation patterns.
      Safe to re-run (idempotent).

 2. dq.config.<method>(...)           ← populate 5 user-managed tables
      Define what to check and where to check it (see CONFIG below).

 3. dq.generate_rule_functions()
      Reads your config tables and builds one in-memory Python checker
      per field definition.  Re-run whenever config changes.

 4. exec_id = dq.run_assessment(schema_name="YourSchema")
      Runs all checkers against your curated Delta tables.
      Writes DQEligible / DQViolations / DQFields back to each row.
      Returns an ExecutionID for filtering results.

 5. dq.violations(exec_id).display()
    dq.quality_scores(exec_id).display()
    dq.summary_by_table().display()
    dq.fields_below_threshold(threshold=80).display()

──────────────────────────────────────────────────────────────────────
CONFIG — two patterns for FullFieldName
──────────────────────────────────────────────────────────────────────
 Pattern A  — Reusable rule (recommended for generic checks)
   FullFieldName = 'email_address'
   Define the DQ rules once.  Map the same definition to as many
   physical columns and tables as needed via mapDQChecks.
   Use when: the same validation logic applies across multiple tables
   (e.g. every email column everywhere follows the same rules).

 Pattern B  — Column-specific rule
   FullFieldName = 'Schema.Table.ColumnName'
   Rules are tied to one exact column.
   Use when: a column has unique constraints not shared anywhere else.

 Both patterns can coexist.  Mix freely.

──────────────────────────────────────────────────────────────────────
CONFIG METHODS  (dq.config.<method>)
──────────────────────────────────────────────────────────────────────
 register_field(full_field_name, data_category_type_id)
      Register a field definition and its data category (1-27).
      Required before adding any rules for a field.

 set_field_values(full_field_name, ...)
      L01 check: min/max character length.
      L04 check: min/max lexicographic value range.

 add_pattern_rule(full_field_name, is_pattern_allowed, ...)
      L03 check: allow or block a named pattern, sub-category, or
      entire category from the 118 built-in patterns.
      block_category / allow_pattern / block_pattern are shortcuts.

 add_custom_query(full_field_name, expression, is_condition_allowed, ...)
      L02 check: custom validation expression.
      custom_query_type='REGEX'  — regex applied via re.search()
      custom_query_type='SQL'    — Spark SQL with @InputValue placeholder,
                                   applied at DataFrame level via F.expr()
      custom_query_type='PYTHON' — named validator (register_validator)

 add_mapping(full_field_name, target_schema, target_table, target_field)
      Links a field definition to a physical column in a curated table.
      One field definition can map to many physical columns.
      The assessment engine uses this table to know what to scan.

──────────────────────────────────────────────────────────────────────
VALIDATION LEVELS  (applied in order, early-exit on first failure)
──────────────────────────────────────────────────────────────────────
 L01  Data length range        set_field_values(min_data_length, max_data_length)
 L02  Custom expression        add_custom_query(expression, ...)
 L03  Built-in pattern check   add_pattern_rule(pattern_name / category, ...)
 L04  Data value range         set_field_values(min_data_value, max_data_value)
 L99  Default PASS             (reached only if all prior levels pass)

──────────────────────────────────────────────────────────────────────
OTHER METHODS
──────────────────────────────────────────────────────────────────────
 dq.config.show_config_summary()     Overview of row counts + config health
 dq.config.verify_config()           FK integrity check before assessment
 dq.add_invalid_keyword(word)        Extend the InvalidKeyword pattern list
 dq.add_custom_pattern(...)          Add a custom regex to masterPattern
 dq.register_validator(name, fn)     Register a Python callable for L02 PYTHON
 dq.run_assessment(reset_eligible_flag=True)  Clear prior DQ flags and re-run
""".rstrip())
