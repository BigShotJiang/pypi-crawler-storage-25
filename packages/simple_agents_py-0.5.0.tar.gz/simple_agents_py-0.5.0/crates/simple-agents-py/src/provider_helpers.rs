use simple_agent_type::prelude::{ApiKey, Provider, Result, SimpleAgentsError};
use simple_agent_type::telemetry::ApiFormat;
use simple_agents_providers::openai::OpenAiCompatProvider;
use std::sync::Arc;
use std::time::Duration;

pub(crate) fn build_provider(
    api_key: &str,
    base_url: Option<&str>,
    api_format: Option<&str>,
    timeout: Option<Duration>,
) -> Result<Arc<dyn Provider>> {
    let key = ApiKey::new(api_key)?;
    let format = parse_api_format(api_format)?;
    let provider = match base_url {
        Some(url) => OpenAiCompatProvider::with_base_url_and_format_and_timeout(
            key,
            url.to_string(),
            format,
            timeout,
        )?,
        None => match timeout {
            Some(duration) => {
                OpenAiCompatProvider::new_with_format_and_timeout(key, format, duration)?
            }
            None => OpenAiCompatProvider::new_with_format(key, format)?,
        },
    };
    Ok(Arc::new(provider))
}

/// Build a provider using the provider-name API.
///
/// `provider` must be "openai" (only supported name). `api_key` is used if
/// provided; otherwise `OPENAI_API_KEY` env var is read. `base_url` overrides
/// the default endpoint. Any other provider name returns "Unknown provider: X".
pub(crate) fn build_provider_from_name(
    provider: &str,
    api_key: Option<&str>,
    base_url: Option<&str>,
    api_format: Option<&str>,
    timeout: Option<Duration>,
) -> Result<Arc<dyn Provider>> {
    let key_required = |name: &str| {
        api_key.map(str::to_string).ok_or_else(|| {
            SimpleAgentsError::Config(format!(
                "api_key is required for provider '{name}' when OPENAI_API_KEY is not used"
            ))
        })
    };

    match provider {
        "openai" => {
            let key = if let Some(k) = api_key {
                k.to_string()
            } else {
                std::env::var("OPENAI_API_KEY").map_err(|_| {
                    SimpleAgentsError::Config(
                        "OPENAI_API_KEY environment variable not set".to_string(),
                    )
                })?
            };
            build_provider(&key, base_url, api_format, timeout)
        }
        // OpenAI-compatible HTTP shape; used for multi-provider demos/tests (routing).
        "anthropic" => {
            let key = key_required("anthropic")?;
            let base = base_url.unwrap_or("https://api.anthropic.com/v1");
            build_provider(&key, Some(base), api_format, timeout)
        }
        "openrouter" => {
            let key = key_required("openrouter")?;
            let base = base_url.unwrap_or("https://openrouter.ai/api/v1");
            build_provider(&key, Some(base), api_format, timeout)
        }
        other => Err(SimpleAgentsError::Config(format!(
            "Unknown provider: {other}"
        ))),
    }
}

fn parse_api_format(api_format: Option<&str>) -> Result<ApiFormat> {
    match api_format {
        Some("responses") => Ok(ApiFormat::Responses),
        Some("chat_completions") | None => Ok(ApiFormat::ChatCompletions),
        Some(other) => Err(SimpleAgentsError::Config(format!(
            "unknown api_format '{other}'; expected 'chat_completions' or 'responses'"
        ))),
    }
}
