import requests
import time
import os
import uuid
from typing import List, Optional, Any

class SwarmResult:
    """The structured result returned to the developer."""
    def __init__(self, text: str, trace: List[dict], session_id: str, status: str):
        self.text = text
        self.trace = trace
        self.session_id = session_id
        self.status = status

    def __repr__(self):
        return f"SwarmResult(status={self.status}, session_id={self.session_id}, text='{self.text[:50]}...')"

class AIPClient:
    def __init__(self, host: str, token: str, session_id: Optional[str] = None):
        self.host = host.rstrip('/')
        self.session = requests.Session()
        self.session.headers.update({"X-AIP-Token": token})
        self.session_id = session_id

    def get_state(self):
        r = self.session.get(f"{self.host}/state", params={"session_id": self.session_id})
        r.raise_for_status()
        return r.json()

    def run(self, goal: str, models: List[str], max_rounds: int = 15) -> SwarmResult:
        """Execute a swarm debate and return the final converged result."""
        # Seed the network with a session_id
        r = self.session.post(f"{self.host}/seed", params={"goal": goal, "session_id": self.session_id})
        r.raise_for_status()
        data = r.json()
        self.session_id = data.get("session_id")
        
        print(f"[*] Swarm Session: {self.session_id}")
        print(f"[*] Models Participating: {', '.join(models)}")
        
        rounds = 0
        while rounds < max_rounds:
            state = self.get_state()
            if state["status"] in ["halted", "silent_equilibrium"]:
                history = state.get("history", [])
                final_text = history[-1]["content"] if history else "No consensus reached."
                return SwarmResult(text=final_text, trace=history, session_id=self.session_id, status=state["status"])
            
            rounds += 1
            time.sleep(2)
        
        # Timeout/Max rounds reached
        state = self.get_state()
        history = state.get("history", [])
        return SwarmResult(
            text="Maximum convergence rounds reached without final agreement.", 
            trace=history, 
            session_id=self.session_id, 
            status="timeout"
        )

def solve(goal: str, models: Optional[List[str]] = None, host: Optional[str] = None, token: Optional[str] = None, max_rounds: int = 15) -> SwarmResult:
    """The simplest entry point for developers. Returns a SwarmResult object."""
    host = host or os.getenv("AIP_HOST_URL", "http://127.0.0.1:8000")
    token = token or os.getenv("AIP_HOST_KEY")
    models = models or ["gpt-4o", "claude-3-5-sonnet-20240620"]
    
    if not token:
        raise ValueError("AIP_HOST_KEY environment variable is missing for authentication.")
        
    client = AIPClient(host, token)
    return client.run(goal, models, max_rounds=max_rounds)

