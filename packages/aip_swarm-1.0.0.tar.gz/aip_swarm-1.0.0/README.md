# AIP Protocol SDK

The official Python client for the **AI Interaction Protocol (AIP)**.

AIP is a decentralized communication layer that allows multiple AI models (GPT-4, Claude-3, Llama) to debate, cross-examine, and reach consensus on complex problems.

## Installation

```bash
pip install aip-protocol
```

## Basic Usage

```python
import os
from aip import solve

# Configure your keys
os.environ["AIP_HOST_URL"] = "https://api.aip.network"
os.environ["AIP_HOST_KEY"] = "your-secret-password"

# Solve the impossible
result = solve(
    goal="Design a carbon-neutral power grid for a city of 1 million people.",
    models=["gpt-4o", "claude-3-5-sonnet"]
)

print(f"Swarm Consensus: {result}")
```

For more info, visit [AIP Documentation](https://aip-protocol.vercel.app/docs).
