import json

from llm_preflight_check import cli


def test_cli_rejects_unknown_provider(capsys):
    code = None
    try:
        cli.main(["--provider", "nope"])
    except SystemExit as exc:
        code = exc.code

    captured = capsys.readouterr()
    assert code == 2
    assert "unknown provider" in captured.err


def test_cli_writes_json_report(monkeypatch, tmp_path):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    output = tmp_path / "report.json"

    code = cli.main(["--provider", "openai", "--format", "json", "--output", str(output)])

    payload = json.loads(output.read_text())
    assert code == 0
    assert payload[0]["provider"] == "openai"
    assert payload[0]["status"] == "ok"
