import json

from llm_preflight_check.core import exit_code, extract_models, parse_required_models, run_checks


def test_missing_cloud_keys_are_reported_without_live_calls():
    results = run_checks(["openai"], env={}, live=False)

    assert results[0].provider == "openai"
    assert results[0].status == "missing"
    assert exit_code(results) == 1


def test_ollama_can_use_default_host_without_env():
    results = run_checks(["ollama"], env={}, live=False)

    assert results[0].status == "ok"
    assert "localhost:11434" in results[0].endpoint


def test_required_models_warn_without_live_verification():
    required = parse_required_models(["openai:not-a-built-in-hint"])
    results = run_checks(["openai"], env={"OPENAI_API_KEY": "sk-test"}, require_models=required)

    assert results[0].status == "warn"
    assert results[0].missing_models == ["not-a-built-in-hint"]
    assert exit_code(results, strict_warnings=True) == 1


def test_live_check_fails_when_required_model_is_absent():
    def fake_transport(url, headers, timeout):
        assert headers["Authorization"] == "Bearer sk-test"
        return 200, json.dumps({"data": [{"id": "gpt-4o-mini"}]})

    results = run_checks(
        ["openai"],
        env={"OPENAI_API_KEY": "sk-test"},
        live=True,
        require_models={"openai": ["gpt-4.1"]},
        transport=fake_transport,
    )

    assert results[0].status == "fail"
    assert results[0].missing_models == ["gpt-4.1"]
    assert exit_code(results) == 2


def test_extract_models_supports_ollama_shape():
    body = json.dumps({"models": [{"name": "llama3.2"}, {"name": "qwen2.5-coder"}]})

    assert extract_models("ollama", body) == ["llama3.2", "qwen2.5-coder"]
