from __future__ import annotations

import argparse
from pathlib import Path
import sys

from . import __version__
from .core import DEFAULT_TIMEOUT, exit_code, parse_required_models, run_checks
from .report import render_html, render_json, render_markdown, render_table


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="llm-preflight-check",
        description="Check LLM provider keys, endpoints, and required model names before a run.",
    )
    parser.add_argument(
        "-p",
        "--provider",
        action="append",
        help="Provider to check: openai, anthropic, deepseek, or ollama. Repeatable.",
    )
    parser.add_argument("--live", action="store_true", help="Call provider model-list endpoints.")
    parser.add_argument(
        "--require-model",
        action="append",
        default=[],
        metavar="PROVIDER:MODEL",
        help="Fail if a provider does not expose a required model. Repeatable.",
    )
    parser.add_argument(
        "--format",
        choices=["table", "json", "markdown", "html"],
        default="table",
        help="Report format.",
    )
    parser.add_argument("-o", "--output", help="Write the report to a file instead of stdout.")
    parser.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT, help="Live check timeout in seconds.")
    parser.add_argument("--strict-warnings", action="store_true", help="Return a failing exit code for warnings.")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        required = parse_required_models(args.require_model)
        results = run_checks(
            args.provider,
            live=args.live,
            timeout=args.timeout,
            require_models=required,
        )
    except ValueError as exc:
        parser.error(str(exc))

    report = render(results, args.format)
    if args.output:
        Path(args.output).write_text(report, encoding="utf-8")
    else:
        sys.stdout.write(report + ("\n" if not report.endswith("\n") else ""))
    return exit_code(results, strict_warnings=args.strict_warnings)


def render(results, report_format: str) -> str:
    if report_format == "json":
        return render_json(results)
    if report_format == "markdown":
        return render_markdown(results)
    if report_format == "html":
        return render_html(results)
    return render_table(results)


if __name__ == "__main__":
    raise SystemExit(main())
