from __future__ import annotations

import json
from html import escape

from .core import CheckResult


def render_table(results: list[CheckResult]) -> str:
    rows = [["Provider", "Status", "Env", "Endpoint", "Message"]]
    for result in results:
        rows.append([result.provider, result.status, result.env_var, result.endpoint, details(result)])
    widths = [max(len(row[index]) for row in rows) for index in range(len(rows[0]))]
    lines = []
    for index, row in enumerate(rows):
        lines.append("  ".join(cell.ljust(widths[pos]) for pos, cell in enumerate(row)))
        if index == 0:
            lines.append("  ".join("-" * width for width in widths))
    return "\n".join(lines)


def render_json(results: list[CheckResult]) -> str:
    return json.dumps([result.__dict__ for result in results], indent=2, sort_keys=True)


def render_markdown(results: list[CheckResult]) -> str:
    lines = [
        "# LLM Preflight Report",
        "",
        "| Provider | Status | Env | Latency | Details |",
        "| --- | --- | --- | --- | --- |",
    ]
    for result in results:
        latency = "" if result.elapsed_ms is None else f"{result.elapsed_ms} ms"
        lines.append(
            f"| {result.provider} | {result.status} | `{result.env_var}` | {latency} | {details(result)} |"
        )
    return "\n".join(lines) + "\n"


def render_html(results: list[CheckResult]) -> str:
    cards = []
    for result in results:
        latency = "" if result.elapsed_ms is None else f"<span>{result.elapsed_ms} ms</span>"
        models = ", ".join(result.models_seen[:6])
        missing = ", ".join(result.missing_models)
        cards.append(
            f"""
      <article class="card {escape(result.status)}">
        <div><strong>{escape(result.provider)}</strong><span>{escape(result.status)}</span></div>
        <p>{escape(result.message)}</p>
        <code>{escape(result.env_var)}</code>
        <small>{escape(result.endpoint)}</small>
        {latency}
        <small>{escape("models: " + models) if models else ""}</small>
        <small>{escape("missing: " + missing) if missing else ""}</small>
      </article>"""
        )
    return f"""<!doctype html>
<html lang="en">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LLM Preflight Report</title>
<style>
body {{ font-family: ui-sans-serif, system-ui, sans-serif; margin: 32px; color: #172026; background: #f7f7f4; }}
main {{ max-width: 980px; margin: 0 auto; }}
h1 {{ font-size: 28px; margin: 0 0 18px; }}
.grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 12px; }}
.card {{ background: white; border: 1px solid #d8ddd6; border-left-width: 6px; border-radius: 8px; padding: 14px; }}
.card div {{ display: flex; justify-content: space-between; gap: 12px; }}
.ok {{ border-left-color: #237a57; }} .warn {{ border-left-color: #9d6b19; }}
.missing, .fail {{ border-left-color: #b42318; }}
p {{ min-height: 44px; }} code, small, span {{ display: block; margin-top: 8px; overflow-wrap: anywhere; }}
</style>
<main>
  <h1>LLM Preflight Report</h1>
  <section class="grid">{''.join(cards)}
  </section>
</main>
</html>
"""


def details(result: CheckResult) -> str:
    parts = [result.message]
    if result.elapsed_ms is not None:
        parts.append(f"{result.elapsed_ms} ms")
    if result.missing_models:
        parts.append("missing " + ", ".join(result.missing_models))
    return "; ".join(parts)
