from __future__ import annotations

from dataclasses import dataclass, field
import json
import os
import time
from typing import Callable, Iterable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


DEFAULT_TIMEOUT = 4.0

PROVIDERS = {
    "openai": {
        "env": "OPENAI_API_KEY",
        "url": "https://api.openai.com/v1/models",
        "auth": "bearer",
        "known": ["gpt-4.1", "gpt-4o", "gpt-4o-mini", "o3", "o4-mini"],
    },
    "anthropic": {
        "env": "ANTHROPIC_API_KEY",
        "url": "https://api.anthropic.com/v1/models",
        "auth": "anthropic",
        "known": ["claude-3-5-sonnet-latest", "claude-3-5-haiku-latest", "claude-3-opus-latest"],
    },
    "deepseek": {
        "env": "DEEPSEEK_API_KEY",
        "url": "https://api.deepseek.com/models",
        "auth": "bearer",
        "known": ["deepseek-chat", "deepseek-reasoner"],
    },
    "ollama": {
        "env": "OLLAMA_HOST",
        "url": "http://localhost:11434/api/tags",
        "auth": "none",
        "known": ["llama3.1", "llama3.2", "mistral", "qwen2.5-coder"],
    },
}


@dataclass
class CheckResult:
    provider: str
    status: str
    message: str
    env_var: str
    endpoint: str
    elapsed_ms: int | None = None
    models_seen: list[str] = field(default_factory=list)
    missing_models: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.status == "ok"


Transport = Callable[[str, dict[str, str], float], tuple[int, str]]


def default_transport(url: str, headers: dict[str, str], timeout: float) -> tuple[int, str]:
    request = Request(url, headers=headers)
    try:
        with urlopen(request, timeout=timeout) as response:
            return response.status, response.read().decode("utf-8", errors="replace")
    except HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        return exc.code, body
    except URLError as exc:
        raise ConnectionError(str(exc.reason)) from exc
    except TimeoutError as exc:
        raise ConnectionError("request timed out") from exc


def normalize_providers(names: Iterable[str] | None) -> list[str]:
    if not names:
        return list(PROVIDERS)
    normalized: list[str] = []
    for name in names:
        lowered = name.strip().lower()
        if lowered not in PROVIDERS:
            valid = ", ".join(PROVIDERS)
            raise ValueError(f"unknown provider '{name}'. valid providers: {valid}")
        if lowered not in normalized:
            normalized.append(lowered)
    return normalized


def parse_required_models(values: Iterable[str] | None) -> dict[str, list[str]]:
    required: dict[str, list[str]] = {}
    for value in values or []:
        if ":" not in value:
            raise ValueError("--require-model must use provider:model")
        provider, model = value.split(":", 1)
        provider = provider.strip().lower()
        model = model.strip()
        if provider not in PROVIDERS:
            raise ValueError(f"unknown provider in --require-model: {provider}")
        if not model:
            raise ValueError("--require-model cannot use an empty model name")
        required.setdefault(provider, []).append(model)
    return required


def run_checks(
    providers: Iterable[str] | None = None,
    *,
    env: dict[str, str] | None = None,
    live: bool = False,
    timeout: float = DEFAULT_TIMEOUT,
    require_models: dict[str, list[str]] | None = None,
    transport: Transport = default_transport,
) -> list[CheckResult]:
    env = env if env is not None else dict(os.environ)
    require_models = require_models or {}
    results: list[CheckResult] = []

    for provider in normalize_providers(providers):
        config = PROVIDERS[provider]
        env_var = config["env"]
        endpoint = endpoint_for(provider, env)
        secret = env.get(env_var, "").strip()
        required = require_models.get(provider, [])

        if provider != "ollama" and not secret:
            results.append(
                CheckResult(
                    provider,
                    "missing",
                    f"{env_var} is not set",
                    env_var,
                    endpoint,
                    missing_models=required,
                )
            )
            continue

        if not live:
            known = set(config["known"])
            missing = [model for model in required if model not in known]
            status = "ok" if not missing else "warn"
            message = "configuration present; live endpoint not checked"
            if provider == "ollama" and not env.get(env_var):
                message = "using default local Ollama host; live endpoint not checked"
            if missing:
                message = "required model not in built-in model hints; run --live to verify"
            results.append(
                CheckResult(
                    provider,
                    status,
                    message,
                    env_var,
                    endpoint,
                    models_seen=list(config["known"]),
                    missing_models=missing,
                )
            )
            continue

        results.append(check_live(provider, endpoint, secret, env_var, timeout, required, transport))

    return results


def endpoint_for(provider: str, env: dict[str, str]) -> str:
    if provider == "ollama":
        host = env.get("OLLAMA_HOST", "").strip().rstrip("/")
        return f"{host or 'http://localhost:11434'}/api/tags"
    return PROVIDERS[provider]["url"]


def check_live(
    provider: str,
    endpoint: str,
    secret: str,
    env_var: str,
    timeout: float,
    required: list[str],
    transport: Transport,
) -> CheckResult:
    headers = headers_for(provider, secret)
    started = time.perf_counter()
    try:
        status_code, body = transport(endpoint, headers, timeout)
        elapsed_ms = int((time.perf_counter() - started) * 1000)
    except ConnectionError as exc:
        return CheckResult(provider, "fail", str(exc), env_var, endpoint)

    if status_code < 200 or status_code >= 300:
        message = summarize_http_error(status_code, body)
        return CheckResult(provider, "fail", message, env_var, endpoint, elapsed_ms=elapsed_ms)

    models = extract_models(provider, body)
    missing = [model for model in required if model not in models]
    status = "ok" if not missing else "fail"
    message = "endpoint reachable"
    if missing:
        message = "required model missing from endpoint response"
    return CheckResult(
        provider,
        status,
        message,
        env_var,
        endpoint,
        elapsed_ms=elapsed_ms,
        models_seen=models[:12],
        missing_models=missing,
    )


def headers_for(provider: str, secret: str) -> dict[str, str]:
    auth = PROVIDERS[provider]["auth"]
    if auth == "bearer":
        return {"Authorization": f"Bearer {secret}"}
    if auth == "anthropic":
        return {"x-api-key": secret, "anthropic-version": "2023-06-01"}
    return {}


def extract_models(provider: str, body: str) -> list[str]:
    try:
        payload = json.loads(body or "{}")
    except json.JSONDecodeError:
        return []

    rows = payload.get("models") if provider == "ollama" else payload.get("data")
    if not isinstance(rows, list):
        return []

    models: list[str] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        value = row.get("name") if provider == "ollama" else row.get("id")
        if isinstance(value, str) and value:
            models.append(value)
    return sorted(set(models))


def summarize_http_error(status_code: int, body: str) -> str:
    clean = " ".join(body.split())
    if len(clean) > 120:
        clean = clean[:117] + "..."
    return f"HTTP {status_code}" + (f": {clean}" if clean else "")


def exit_code(results: list[CheckResult], *, strict_warnings: bool = False) -> int:
    if any(result.status == "fail" for result in results):
        return 2
    if any(result.status == "missing" for result in results):
        return 1
    if strict_warnings and any(result.status == "warn" for result in results):
        return 1
    return 0
