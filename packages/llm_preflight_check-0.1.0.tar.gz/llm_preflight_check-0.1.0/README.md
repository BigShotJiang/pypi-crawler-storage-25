![Terminal report screenshot](docs/terminal-report.svg)

# llm-preflight-check

`llm-preflight-check` is a local CLI for checking whether your LLM provider configuration is ready before a demo, batch job, support workflow, or agent run.

It checks:

- required environment variables for OpenAI, Anthropic, DeepSeek, and Ollama
- default or configured provider endpoints
- optional live model-list requests
- required model names such as `openai:gpt-4.1` or `ollama:qwen2.5-coder`
- table, JSON, Markdown, and HTML reports for local use or CI artifacts

No runtime dependencies are required.

## Install

```bash
pip install llm-preflight-check
```

For local development:

```bash
python3 -m pip install -e .
```

## Quick Start

Check local configuration without making network calls:

```bash
llm-preflight-check
```

Check only OpenAI and Ollama:

```bash
llm-preflight-check --provider openai --provider ollama
```

Run live endpoint checks and require specific models:

```bash
llm-preflight-check --live \
  --require-model openai:gpt-4.1 \
  --require-model ollama:qwen2.5-coder
```

Write a Markdown handoff report:

```bash
llm-preflight-check --format markdown --output llm-preflight.md
```

Use strict warnings in CI:

```bash
llm-preflight-check --require-model openai:gpt-4.1 --strict-warnings
```

Exit codes:

- `0`: all selected checks passed
- `1`: a required cloud provider key is missing, or warnings are strict
- `2`: a live check failed or a required live model is missing

## Providers

| Provider | Env var | Default endpoint |
| --- | --- | --- |
| OpenAI | `OPENAI_API_KEY` | `https://api.openai.com/v1/models` |
| Anthropic | `ANTHROPIC_API_KEY` | `https://api.anthropic.com/v1/models` |
| DeepSeek | `DEEPSEEK_API_KEY` | `https://api.deepseek.com/models` |
| Ollama | `OLLAMA_HOST` | `http://localhost:11434/api/tags` |

Ollama does not require an API key. If `OLLAMA_HOST` is not set, the CLI assumes `http://localhost:11434`.

## Report Formats

```bash
llm-preflight-check --format table
llm-preflight-check --format json
llm-preflight-check --format markdown
llm-preflight-check --format html --output report.html
```

## Development

```bash
python3 -m pytest
PYTHONPATH=src python3 -m llm_preflight_check.cli --provider ollama
python3 -m build --no-isolation
python3 -m twine check dist/*
```

## License

MIT
