"""
browser.py — no longer used in cine-tmux v2.

cine-tmux v2 uses enc-dec.app for all server-side token computation.
No browser (Playwright/Chromium) is needed.
"""

from __future__ import annotations

import os
import re
import time
from typing import Dict, List, Optional

from loguru import logger

def _find_chromium() -> Optional[str]:
    """
    Find a usable Chromium binary in order of preference:
      1. CHROMIUM_PATH env var (user override)
      2. Playwright's own installed chromium (via `playwright install chromium`)
         — works on ARM64 Termux, Linux, macOS
      3. System PATH (chromium / chromium-browser / google-chrome)
      4. Termux pkg-installed chromium (x86_64 only)
    """
    import glob, shutil

    # 1. User override via env var
    env = os.environ.get("CHROMIUM_PATH") or os.environ.get("PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH")
    if env and os.path.isfile(env):
        return env

    # 2. Playwright's own chromium install (~/.cache/ms-playwright/chromium-*/...)
    #    Works on Linux x86_64 AND ARM64 (Termux, Raspberry Pi, etc.)
    home = os.path.expanduser("~")
    for cache_dir in [
        os.path.join(home, ".cache", "ms-playwright"),
        os.path.join(home, ".local", "share", "ms-playwright"),
        # Termux home
        "/data/data/com.termux/files/home/.cache/ms-playwright",
    ]:
        for pattern in [
            "chromium-*/chrome-linux64/chrome",
            "chromium-*/chrome-linux/chrome",
        ]:
            matches = sorted(glob.glob(os.path.join(cache_dir, pattern)), reverse=True)
            if matches and os.path.isfile(matches[0]):
                return matches[0]

    # 3. System PATH
    for name in ("chromium-browser", "chromium", "google-chrome", "google-chrome-stable"):
        found = shutil.which(name)
        if found:
            return found

    # 4. Termux pkg path (x86_64 only — not in ARM64 Termux repos)
    termux_prefix = os.environ.get("PREFIX", "/data/data/com.termux/files/usr")
    for name in ("chromium-browser", "chromium"):
        p = os.path.join(termux_prefix, "bin", name)
        if os.path.isfile(p):
            return p

    return None

_UA = (
    "Mozilla/5.0 (Linux; Android 11; Pixel 5) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Mobile Safari/537.36"
)


class BrowserSession:
    """
    Thin Playwright wrapper. Call open() before use, close() when done.
    Use as a context manager or through CineClient which manages lifetime.
    """

    def __init__(self, base_url: str = "https://123cine.to", headless: bool = True):
        self.base_url = base_url.rstrip("/")
        self.headless = headless
        self._pw = None
        self._browser = None
        self._ctx = None
        self._page = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def open(self):
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            raise RuntimeError(
                "Playwright is not installed.\n"
                "Run:  pip install playwright\n"
                "Then: python3 -m playwright install chromium"
            )

        logger.info("Starting browser…")
        self._pw = sync_playwright().start()

        kwargs: dict = dict(
            headless=self.headless,
            args=[
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
            ],
        )
        chrome = _find_chromium()
        if chrome:
            logger.debug(f"Using chromium: {chrome}")
            kwargs["executable_path"] = chrome

        try:
            self._browser = self._pw.chromium.launch(**kwargs)
        except Exception as e:
            msg = str(e)
            if "Executable doesn't exist" in msg or "not found" in msg.lower():
                raise RuntimeError(
                    "Chromium is not installed for Playwright.\n\n"
                    "Fix: run this command once —\n"
                    "  python3 -m playwright install chromium\n\n"
                    "This downloads ~300 MB to ~/.cache/ms-playwright/\n"
                    "On Termux: pkg install python fzf ffmpeg mpv  (first)\n"
                    "then:       pip install cine-tmux\n"
                    "then:       python3 -m playwright install chromium"
                ) from e
            raise
        self._ctx = self._browser.new_context(
            user_agent=_UA,
            viewport={"width": 390, "height": 844},
            locale="en-US",
            timezone_id="America/New_York",
        )
        self._ctx.add_init_script(
            "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
        )
        self._page = self._ctx.new_page()
        logger.debug("Browser ready.")

    def close(self):
        for attr, stop in [("_page", "close"), ("_ctx", "close"),
                            ("_browser", "close"), ("_pw", "stop")]:
            obj = getattr(self, attr, None)
            if obj:
                try:
                    getattr(obj, stop)()
                except Exception:
                    pass
                setattr(self, attr, None)

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, *_):
        self.close()

    # ------------------------------------------------------------------
    # Internal: navigate to watch page and wait
    # ------------------------------------------------------------------

    def _goto_watch(self, watch_uri: str, wait_secs: float = 6.0):
        url = self.base_url + watch_uri
        try:
            self._page.goto(url, wait_until="domcontentloaded", timeout=30_000)
        except Exception as e:
            logger.debug(f"Page load (non-fatal): {e}")
        self._page.wait_for_timeout(int(wait_secs * 1000))

    # ------------------------------------------------------------------
    # 1. Extract `_` token from the episodes API request
    # ------------------------------------------------------------------

    def extract_episodes_token(self, title_id: str, watch_uri: str) -> Optional[str]:
        """
        Load the watch page and capture the signed `_` token from the
        network request: GET /api/v1/titles/{id}/episodes?_={token}

        The page's Alpine.js fires this automatically on load.
        """
        logger.info(f"Extracting API token via browser: {watch_uri}")
        captured: dict = {}

        def on_request(req):
            url = req.url
            if f"/api/v1/titles/{title_id}/episodes" in url and "?_=" in url:
                m = re.search(r"[?&]_=([A-Za-z0-9_\-]+)", url)
                if m:
                    captured["token"] = m.group(1)

        self._page.on("request", on_request)
        try:
            self._goto_watch(watch_uri, wait_secs=0)
            # Wait up to 12 s for the episodes request to fire
            deadline = time.time() + 12
            while time.time() < deadline and "token" not in captured:
                self._page.wait_for_timeout(300)
        finally:
            self._page.remove_listener("request", on_request)

        tok = captured.get("token")
        if tok:
            logger.debug(f"Token captured: {tok[:12]}…")
        else:
            logger.warning("Episodes token not captured.")
        return tok

    # ------------------------------------------------------------------
    # 2. Get link IDs for an episode
    # ------------------------------------------------------------------

    def get_episode_links(self, episode_id: str, watch_uri: str) -> List[Dict]:
        """
        Intercept the /api/v1/episodes/{ep_id} response that the page's JS
        fires (with the session cookie) to get the list of streaming links.

        Returns list of {id, name, quality}.
        """
        logger.info(f"Fetching links for episode {episode_id}")
        captured: dict = {}

        def on_response(resp):
            if f"/api/v1/episodes/{episode_id}" in resp.url and resp.status == 200:
                try:
                    data = resp.json()
                    result = data.get("result", {})
                    links = result.get("links") or result.get("servers") or []
                    if links:
                        captured["links"] = links
                except Exception as e:
                    logger.debug(f"Episode response parse error: {e}")

        # If we're already on the watch page this session, stay there.
        # Otherwise navigate.
        self._page.on("response", on_response)
        try:
            # The page fires /api/v1/episodes/{ep_id} after clicking a server button.
            # For movies it fires automatically; for TV, click the episode item.
            self._page.wait_for_timeout(2000)

            # Try clicking the episode item if present (TV shows)
            for sel in [
                f"[data-id='{episode_id}']",
                "[data-ep='1']",
                ".ep-item:first-child",
                ".episode-item:first-child",
            ]:
                try:
                    self._page.click(sel, timeout=2000)
                    self._page.wait_for_timeout(2000)
                    break
                except Exception:
                    pass

            # Wait for the response to be captured
            deadline = time.time() + 8
            while time.time() < deadline and "links" not in captured:
                self._page.wait_for_timeout(300)
        finally:
            self._page.remove_listener("response", on_response)

        if not captured.get("links"):
            logger.warning(
                f"No links captured for episode {episode_id}. "
                "The site may require a logged-in account. "
                "Run: cine --setup  to save your session cookie."
            )
            return []

        return [
            {
                "id": lk.get("id") or lk.get("lid") or lk.get("link_id") or "",
                "name": lk.get("name") or lk.get("server") or f"Server {i+1}",
                "quality": lk.get("quality") or lk.get("resolution") or "",
            }
            for i, lk in enumerate(captured["links"])
        ]

    # ------------------------------------------------------------------
    # 3. Resolve embed URL for a chosen link
    # ------------------------------------------------------------------

    def get_embed_url(self, link_id: str, watch_uri: str) -> Optional[str]:
        """
        Click the server button for link_id and intercept the
        /api/v1/links/{link_id} response to get the embed iframe URL.
        """
        logger.info(f"Resolving embed URL for link {link_id}")
        captured: dict = {}

        def on_response(resp):
            if f"/api/v1/links/{link_id}" in resp.url and resp.status == 200:
                try:
                    data = resp.json()
                    result = data.get("result", {})
                    embed = (
                        result.get("url")
                        or result.get("link")
                        or result.get("embed")
                        or result.get("src")
                    )
                    if embed:
                        captured["embed"] = embed
                except Exception as e:
                    logger.debug(f"Link response parse error: {e}")

        self._page.on("response", on_response)
        try:
            # Click the server button that corresponds to this link
            for sel in [
                f"[data-id='{link_id}']",
                f"[data-lid='{link_id}']",
                f"[data-link='{link_id}']",
                ".server-item:first-child",
                ".btn-server:first-child",
            ]:
                try:
                    self._page.click(sel, timeout=3000)
                    self._page.wait_for_timeout(2000)
                    break
                except Exception:
                    pass

            # Wait for embed URL capture
            deadline = time.time() + 8
            while time.time() < deadline and "embed" not in captured:
                self._page.wait_for_timeout(300)
        finally:
            self._page.remove_listener("response", on_response)

        if not captured.get("embed"):
            logger.warning(f"Embed URL not captured for link {link_id}.")
        return captured.get("embed")

    # ------------------------------------------------------------------
    # 4. Capture .m3u8 from an embed page
    # ------------------------------------------------------------------

    def get_m3u8_from_embed(self, embed_url: str) -> Optional[str]:
        """
        Open the embed URL in a fresh tab and capture the .m3u8 URL from
        network requests. Returns the master (or only) playlist URL.
        """
        captured: dict = {}
        embed_page = self._ctx.new_page()

        def on_req(req):
            u = req.url
            if ".m3u8" in u:
                if "master" in u.lower():
                    captured.setdefault("master", u)
                else:
                    captured.setdefault("playlist", u)

        def on_resp(resp):
            u = resp.url
            ct = resp.headers.get("content-type", "")
            if ".m3u8" in u or "mpegurl" in ct.lower():
                if "master" in u.lower():
                    captured["master"] = u
                else:
                    captured.setdefault("playlist", u)

        embed_page.on("request", on_req)
        embed_page.on("response", on_resp)

        try:
            logger.info(f"Loading embed: {embed_url}")
            embed_page.goto(embed_url, wait_until="domcontentloaded", timeout=25_000)
            embed_page.wait_for_timeout(3000)

            # Try to click a play button
            for sel in [".play-btn", ".vjs-big-play-button", "[class*='play']", "button"]:
                if captured:
                    break
                try:
                    embed_page.click(sel, timeout=1500)
                    embed_page.wait_for_timeout(2500)
                except Exception:
                    pass

            # Wait longer if still nothing
            if not captured:
                deadline = time.time() + 10
                while time.time() < deadline and not captured:
                    embed_page.wait_for_timeout(400)

            # Last resort: scan page source for m3u8 URLs
            if not captured:
                content = embed_page.content()
                m3u8s = re.findall(r'https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*', content)
                if m3u8s:
                    captured["master"] = m3u8s[0]

        except Exception as e:
            logger.debug(f"Embed page error: {e}")
        finally:
            embed_page.remove_listener("request", on_req)
            embed_page.remove_listener("response", on_resp)
            try:
                embed_page.close()
            except Exception:
                pass

        result = captured.get("master") or captured.get("playlist")
        if result:
            logger.debug(f"m3u8 captured: {result[:80]}…")
        else:
            logger.warning("No .m3u8 stream found in embed page.")
        return result
