"""
cine-tmux: Movie & TV downloader for Termux.

Uses yFlix (1movies/solarmovie) as the source and enc-dec.app for
server-side token computation — no browser or cloudscraper required.
"""

__version__ = "2.0.0"
__author__ = "cine-tmux contributors"
