"""Centralized logger for cine-tmux."""

import sys
from loguru import logger as _logger

_logger.remove()

_logger.add(
    sys.stderr,
    level="INFO",
    format=(
        "<green>{time:HH:mm:ss}</green> | "
        "<level>{level: <8}</level> | "
        "<level>{message}</level>"
    ),
    colorize=True,
)

log = _logger

info = _logger.info
error = _logger.error
warning = _logger.warning
success = _logger.success
debug = _logger.debug
critical = _logger.critical
exception = _logger.exception
