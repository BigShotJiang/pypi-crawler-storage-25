"""Config manager for cine-tmux. Reads/writes ~/.config/cine-tmux/config.ini"""

import configparser
import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "cine-tmux"
CONFIG_FILE = CONFIG_DIR / "config.ini"

DEFAULTS = {
    "download": {
        "directory": "/sdcard/cine",
        "workers": "4",
        "quality": "best",
    },
    "stream": {
        "player": "mpv",
    },
    "behavior": {
        "verbose": "false",
    },
}

_COMMENTS = {
    ("download", "directory"): "Where to save downloaded movies/episodes",
    ("download", "workers"): "Parallel HLS segment download workers (1-8)",
    ("download", "quality"): "Preferred quality: best, 1080p, 720p, 480p",
    ("stream", "player"): "Media player for --play mode (mpv recommended on Termux)",
    ("behavior", "verbose"): "Enable debug output (true/false)",
}


def _ensure_config() -> configparser.ConfigParser:
    cfg = configparser.ConfigParser()
    for section, values in DEFAULTS.items():
        cfg[section] = values
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if CONFIG_FILE.exists():
        cfg.read(CONFIG_FILE)
    else:
        _write_config(cfg)
    return cfg


def _write_config(cfg: configparser.ConfigParser):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        f.write("# cine-tmux configuration\n")
        f.write("# Edit with: cine --config edit\n\n")
        for section in cfg.sections():
            f.write(f"[{section}]\n")
            for key in cfg[section]:
                comment = _COMMENTS.get((section, key))
                if comment:
                    f.write(f"# {comment}\n")
                f.write(f"{key} = {cfg[section][key]}\n")
            f.write("\n")


def load_config() -> configparser.ConfigParser:
    return _ensure_config()


def get(section: str, key: str, fallback=None):
    cfg = _ensure_config()
    return cfg.get(section, key, fallback=fallback)


def get_base_url() -> str:
    return get("site", "base_url", fallback="https://123cine.to").rstrip("/")


def get_download_dir() -> str:
    val = get("download", "directory", fallback=str(Path.home() / "Downloads" / "Movies"))
    return os.path.expanduser(val)


def get_workers() -> int:
    try:
        return max(1, min(8, int(get("download", "workers", fallback="4"))))
    except (ValueError, TypeError):
        return 4


def get_quality() -> str:
    return get("download", "quality", fallback="best")


def get_player() -> str:
    return get("stream", "player", fallback="mpv")


def is_verbose() -> bool:
    val = get("behavior", "verbose", fallback="false")
    return val.lower() in ("true", "1", "yes")


def cmd_show_config():
    from rich.console import Console
    from rich.syntax import Syntax
    console = Console()
    _ensure_config()
    console.print(f"\n[bold cyan]Config file:[/bold cyan] {CONFIG_FILE}\n")
    if CONFIG_FILE.exists():
        content = CONFIG_FILE.read_text()
        console.print(Syntax(content, "ini", theme="monokai", line_numbers=True))
    else:
        console.print("[yellow]No config file found, showing defaults.[/yellow]")


def cmd_edit_config():
    import subprocess
    import shutil
    _ensure_config()
    editor = os.environ.get("EDITOR", "")
    for candidate in [editor, "nano", "vi", "vim"]:
        if candidate and shutil.which(candidate):
            subprocess.run([candidate, str(CONFIG_FILE)])
            return
    from rich.console import Console
    Console().print(f"[yellow]No editor found. Edit manually:[/yellow] {CONFIG_FILE}")
