"""Constants for cine-tmux."""

import os
from pathlib import Path

YFLIX_BASE = "https://yflix.to"
YFLIX_AJAX = "https://yflix.to/ajax"
ENC_DEC_API = "https://enc-dec.app/api"
ENC_DEC_DB = "https://enc-dec.app/db"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/137.0.0.0 Safari/537.36"
)

MAX_RETRIES = 3
TIMEOUT = 30
BACKOFF_FACTOR = 2

BASE_DATA_DIR = os.path.join(Path.home(), ".config", "cine-tmux")
CACHE_DIR = os.path.join(Path.home(), ".cache", "cine-tmux")

_termux_sdcard = "/sdcard/cine"
_fallback_dir = os.path.join(Path.home(), "Movies", "cine")
BASE_DOWNLOAD_DIR = (
    _termux_sdcard
    if os.path.isdir("/sdcard")
    else _fallback_dir
)

os.makedirs(BASE_DATA_DIR, exist_ok=True)
os.makedirs(CACHE_DIR, exist_ok=True)
