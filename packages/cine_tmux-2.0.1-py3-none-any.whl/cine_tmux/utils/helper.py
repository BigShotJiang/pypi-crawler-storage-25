"""Utility helpers for cine-tmux."""

import re
import shutil


def sanitize_filename(name: str) -> str:
    """Sanitizes a string to be a valid filename."""
    name = name.lstrip(".")
    name = re.sub(r'[<>/\\|:"*?]', "", name)
    name = re.sub(r"\s+", " ", name).strip()
    return name or "Unknown"


def check_dependencies() -> list:
    """Returns list of missing dependencies with install instructions."""
    missing = []
    if shutil.which("ffmpeg") is None:
        missing.append(("ffmpeg", "pkg install ffmpeg"))
    if shutil.which("fzf") is None:
        missing.append(("fzf", "pkg install fzf"))
    return missing


def format_size(bytes_count: int) -> str:
    """Formats byte count into human-readable string."""
    for unit in ["B", "KB", "MB", "GB"]:
        if bytes_count < 1024:
            return f"{bytes_count:.1f} {unit}"
        bytes_count /= 1024
    return f"{bytes_count:.1f} TB"


def detect_player(preferred: str = "") -> str | None:
    """Returns the first available media player."""
    candidates = [preferred] if preferred else []
    candidates += ["mpv", "vlc", "ffplay", "mplayer"]
    for p in candidates:
        if p and shutil.which(p):
            return p
    return None
