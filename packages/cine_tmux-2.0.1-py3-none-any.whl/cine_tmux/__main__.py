"""Entry point for `python -m cine_tmux`."""
from .main import main

if __name__ == "__main__":
    main()
