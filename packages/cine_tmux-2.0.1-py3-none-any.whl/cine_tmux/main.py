"""
Entry point for cine-tmux.

Download movies and TV shows (yFlix / 1movies / solarmovie) in your Termux terminal.
Uses enc-dec.app for server-side token computation — no browser required.

Termux setup (one-time):
  pkg install python fzf ffmpeg mpv
  pip install cine-tmux

Usage:
  cine "avengers endgame"             search and download interactively
  cine --browse movie                 browse latest movies
  cine --browse tv                    browse latest TV shows
  cine --browse movie --genre action  browse action movies
  cine "naruto" --type tv -e 1-10    batch-download TV episodes 1-10
  cine "inception" --quality 720p    download at 720p
  cine "interstellar" --play          stream in mpv
  cine --config show                  show config
  cine --config edit                  edit config in $EDITOR
"""

from __future__ import annotations

import argparse
import sys

from loguru import logger

from .utils import config


def _setup_logger(verbose: bool):
    logger.remove()
    level = "DEBUG" if verbose else "INFO"
    logger.add(
        sys.stderr,
        level=level,
        format="<level>{level: <8}</level> | {message}",
        colorize=True,
    )


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="cine",
        description="Movie & TV downloader for Termux — yFlix + enc-dec.app, no browser needed",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  cine "avengers"                       search and download interactively
  cine --browse movie                   browse latest movies
  cine --browse tv                      browse TV shows
  cine --browse movie --genre action    browse action movies
  cine "breaking bad" --type tv         search TV shows only
  cine "inception" --quality 720p       download in 720p
  cine "naruto" --type tv -e 1-10       batch download episodes 1-10
  cine "interstellar" --play            stream in mpv
  cine --config show                    show current config
  cine --config edit                    edit config in $EDITOR
        """,
    )

    p.add_argument("query", nargs="?", default="", help="Title to search for")
    p.add_argument("--browse", "-b", choices=["movie", "tv"],
                   metavar="{movie,tv}", default=None,
                   help="Browse latest movies or TV shows")
    p.add_argument("--genre", "-g", default="",
                   help="Filter browse by genre: action, drama, thriller, comedy, …")
    p.add_argument("--type", "-t", dest="content_type", choices=["movie", "tv"],
                   default=None, help="Filter search to movie or tv")
    p.add_argument("--quality", "-q", default=None,
                   help="Preferred quality: best, 1080p, 720p, 480p (default: best)")
    p.add_argument("--episodes", "-e", dest="episode_range", default=None,
                   help="Episode range for TV: '1', '1-5', '1,3,5'")
    p.add_argument("--output", "-o", dest="download_dir", default=None,
                   help="Download directory (overrides config)")
    p.add_argument("--play", action="store_true", default=False,
                   help="Stream in mpv instead of downloading")
    p.add_argument("--player", default=None,
                   help="Media player for --play (default: mpv)")
    p.add_argument("--server", dest="link_index", type=int, default=0, metavar="N",
                   help="Which server to use, 0-based (default: 0)")
    p.add_argument("--no-interactive", dest="non_interactive",
                   action="store_true", default=False,
                   help="Auto-select first result/server (batch mode)")
    p.add_argument("--config", choices=["show", "edit"], metavar="{show,edit}",
                   default=None, help="Config: show or edit")
    p.add_argument("--verbose", "-v", action="store_true", default=False,
                   help="Enable debug logging")
    p.add_argument("--version", action="version", version="cine-tmux 2.0.1")

    return p


def main():
    """Entry point for `cine` and `cine-dl` commands."""
    parser = build_parser()
    args = parser.parse_args()

    verbose = args.verbose or (
        config.get("behavior", "verbose", fallback="false").lower() == "true"
    )
    _setup_logger(verbose)

    if args.config == "show":
        config.cmd_show_config()
        return
    if args.config == "edit":
        config.cmd_edit_config()
        return

    quality = args.quality or config.get_quality()
    download_dir = args.download_dir or config.get_download_dir()
    player = args.player or config.get_player()

    from .cli.commands import cmd_search, cmd_browse

    common = dict(
        download_dir=download_dir,
        quality=quality,
        play=args.play,
        player=player,
        non_interactive=args.non_interactive,
        episode_range=args.episode_range,
        link_index=args.link_index,
        content_type=args.content_type,
        verbose=verbose,
    )

    try:
        if args.browse:
            cmd_browse(kind=args.browse, genre=args.genre, **common)
        elif args.query:
            cmd_search(query=args.query, **common)
        else:
            from .cli.interactive import run_interactive_mode
            run_interactive_mode()
    except KeyboardInterrupt:
        logger.info("Interrupted.")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        if verbose:
            raise
        sys.exit(1)


if __name__ == "__main__":
    main()
