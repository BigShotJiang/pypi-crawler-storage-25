"""
yFlix (1movies / solarmovie) client using enc-dec.app for token computation.

Same approach as kai-tmux but for movies and TV shows:
  - Search/browse via enc-dec.app flix database or yflix.to HTML
  - Episode IDs come from the database (no browser token needed)
  - Streaming tokens computed server-side by enc-dec.app
  - Stream URLs extracted from rapidshare/megaup hosters via enc-dec.app decryptors
  - Pure requests — no browser, no cloudscraper

Flow:
  1. search()          → database search → list of titles with episode IDs
  2. get_servers(eid)  → enc eid → ajax links list → parse HTML → server/lid list
  3. get_stream(lid)   → enc lid → ajax links view → dec → hoster embed URL
  4. extract_hls(url)  → fetch hoster /media/ endpoint → dec-rapid/dec-mega → HLS URL
"""

from __future__ import annotations

import re
import time
from typing import Dict, List, Optional
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup
from loguru import logger

from ..utils.constants import (
    ENC_DEC_API,
    ENC_DEC_DB,
    YFLIX_AJAX,
    YFLIX_BASE,
    USER_AGENT,
    TIMEOUT,
)


HEADERS_YFLIX = {
    "User-Agent": USER_AGENT,
    "Referer": YFLIX_BASE + "/",
    "Accept": "application/json",
}

HEADERS_API = {
    "User-Agent": USER_AGENT,
    "Accept": "application/json",
}


def _get(url: str, params: dict = None, headers: dict = None, retries: int = 3) -> Optional[requests.Response]:
    h = {**HEADERS_API, **(headers or {})}
    for attempt in range(retries):
        try:
            r = requests.get(url, params=params, headers=h, timeout=TIMEOUT)
            return r
        except Exception as e:
            if attempt == retries - 1:
                logger.debug(f"GET {url} failed: {e}")
                return None
            time.sleep(1.5 ** attempt)
    return None


def _post(url: str, json_body: dict, headers: dict = None, retries: int = 3) -> Optional[requests.Response]:
    h = {**HEADERS_API, **(headers or {})}
    for attempt in range(retries):
        try:
            r = requests.post(url, json=json_body, headers=h, timeout=TIMEOUT)
            return r
        except Exception as e:
            if attempt == retries - 1:
                logger.debug(f"POST {url} failed: {e}")
                return None
            time.sleep(1.5 ** attempt)
    return None


def _validate_api(data: dict, path: str) -> Optional[dict]:
    if not data or data.get("status") != 200:
        logger.debug(f"API error at {path}: {data.get('error', 'unknown') if data else 'no response'}")
        return None
    return data.get("result")


class YFlixClient:
    """
    Orchestrates enc-dec.app database + yflix.to AJAX + hoster decryptors.
    Pure requests, no browser required.
    """

    def __init__(self):
        self._session = requests.Session()
        self._session.headers.update(HEADERS_API)

    def search(self, query: str, kind: Optional[str] = None) -> List[Dict]:
        """
        Search the enc-dec.app flix database.
        Returns list of normalised title dicts with pre-loaded episode IDs.
        """
        params = {"query": query}
        if kind in ("movie", "tv"):
            params["type"] = kind

        r = _get(f"{ENC_DEC_DB}/flix/search", params=params)
        if not r or r.status_code != 200:
            logger.debug(f"Database search failed: {getattr(r, 'status_code', 'no response')}")
            return []

        try:
            entries = r.json()
        except Exception:
            return []

        results = []
        for entry in entries:
            norm = _normalize_entry(entry)
            if norm:
                results.append(norm)
        return results

    def browse(self, kind: str = "movie", genre: str = "") -> List[Dict]:
        """
        Browse yflix.to home page or genre page and parse title cards.
        Fetches full DB entry for each title found so episode IDs are available.
        """
        if genre:
            url = f"{YFLIX_BASE}/genre/{genre}"
        else:
            url = f"{YFLIX_BASE}/home"

        r = _get(url, headers={"Accept": "text/html", "Referer": YFLIX_BASE + "/"})
        if not r or r.status_code != 200:
            logger.debug(f"Browse page failed: {getattr(r, 'status_code', 'no response')}")
            return []

        cards = _parse_yflix_cards(r.text, kind)

        results = []
        for card in cards:
            flix_id = card.get("id", "")
            if not flix_id:
                continue
            entry = self.get_by_flix_id(flix_id)
            if entry:
                results.append(entry)
            else:
                results.append(card)
        return results

    def get_by_flix_id(self, flix_id: str) -> Optional[Dict]:
        """Look up a title by its yFlix ID in the enc-dec.app database."""
        r = _get(f"{ENC_DEC_DB}/flix/find", params={"flix_id": flix_id})
        if not r or r.status_code != 200:
            return None
        try:
            entries = r.json()
            if entries:
                return _normalize_entry(entries[0])
        except Exception:
            pass
        return None

    def get_by_tmdb_id(self, tmdb_id: str, kind: Optional[str] = None) -> Optional[Dict]:
        """Look up a title by TMDB ID."""
        params = {"tmdb_id": tmdb_id}
        if kind:
            params["type"] = kind
        r = _get(f"{ENC_DEC_DB}/flix/find", params=params)
        if not r or r.status_code != 200:
            return None
        try:
            entries = r.json()
            if entries:
                return _normalize_entry(entries[0])
        except Exception:
            pass
        return None

    def get_servers(self, eid: str) -> Dict[str, List[Dict]]:
        """
        Get streaming servers for a given episode ID.

        Returns dict: { 'default': [{'name': 'Server 1', 'lid': '...', 'sid': '...'}, ...] }
        """
        enc_r = _get(f"{ENC_DEC_API}/enc-movies-flix", params={"text": eid})
        if not enc_r or enc_r.status_code != 200:
            logger.debug("enc-movies-flix failed for eid")
            return {}
        try:
            enc_eid = enc_r.json()["result"]
        except Exception:
            return {}

        servers_r = _get(
            f"{YFLIX_AJAX}/links/list",
            params={"eid": eid, "_": enc_eid},
            headers=HEADERS_YFLIX,
        )
        if not servers_r or servers_r.status_code != 200:
            logger.debug("links/list failed")
            return {}
        try:
            servers_html = servers_r.json().get("result", "")
        except Exception:
            return {}

        parse_r = _post(f"{ENC_DEC_API}/parse-html", json_body={"text": servers_html})
        if not parse_r or parse_r.status_code != 200:
            logger.debug("parse-html failed")
            return {}
        try:
            parsed = parse_r.json().get("result", {})
        except Exception:
            return {}

        result: Dict[str, List[Dict]] = {}
        for stype, server_map in parsed.items():
            servers_list = []
            for slot, srv in server_map.items():
                servers_list.append({
                    "name": srv.get("name", f"Server {slot}"),
                    "lid": srv.get("lid", ""),
                    "sid": srv.get("sid", ""),
                })
            if servers_list:
                result[stype] = servers_list
        return result

    def get_embed_url(self, lid: str) -> Optional[str]:
        """
        Resolve the hoster embed URL for a given link ID.
        Returns the hoster embed URL (e.g. rapidshare /e/... or megaup /e/...).
        """
        enc_r = _get(f"{ENC_DEC_API}/enc-movies-flix", params={"text": lid})
        if not enc_r or enc_r.status_code != 200:
            return None
        try:
            enc_lid = enc_r.json()["result"]
        except Exception:
            return None

        view_r = _get(
            f"{YFLIX_AJAX}/links/view",
            params={"id": lid, "_": enc_lid},
            headers=HEADERS_YFLIX,
        )
        if not view_r or view_r.status_code != 200:
            return None
        try:
            encrypted = view_r.json().get("result", "")
        except Exception:
            return None

        dec_r = _post(f"{ENC_DEC_API}/dec-movies-flix", json_body={"text": encrypted})
        if not dec_r or dec_r.status_code != 200:
            return None
        try:
            result = _validate_api(dec_r.json(), "dec-movies-flix")
            if result:
                return result.get("url")
        except Exception:
            pass
        return None

    def extract_hls(self, embed_url: str) -> Optional[str]:
        """
        Extract the HLS (.m3u8) URL from a hoster embed URL.
        Supports rapidshare and megaup hosters (both use the same pattern).

        Response format from dec-rapid / dec-mega:
          { "sources": [{"file": "https://....m3u8"}], "tracks": [...] }
        """
        if "/e/" not in embed_url:
            logger.debug(f"Unknown hoster URL format: {embed_url[:60]}")
            return None

        # Strip query params before building media URL
        base_embed = embed_url.split("?")[0]
        referer = base_embed.split("/e/")[0] + "/"
        media_url = base_embed.replace("/e/", "/media/")

        hoster_headers = {
            "User-Agent": USER_AGENT,
            "Accept": "application/json",
            "Referer": referer,
        }

        media_r = _get(media_url, headers=hoster_headers)
        if not media_r or media_r.status_code != 200:
            logger.debug(f"Hoster /media/ request failed: {getattr(media_r, 'status_code', 'no response')}")
            return None
        try:
            encrypted = media_r.json().get("result", "")
        except Exception:
            logger.debug("Hoster /media/ response is not JSON")
            return None

        if "mega" in embed_url:
            dec_endpoint = f"{ENC_DEC_API}/dec-mega"
        else:
            dec_endpoint = f"{ENC_DEC_API}/dec-rapid"

        dec_r = _post(
            dec_endpoint,
            json_body={"text": encrypted, "agent": USER_AGENT},
        )
        if not dec_r or dec_r.status_code != 200:
            logger.debug(f"Decryption failed: {dec_endpoint}")
            return None
        try:
            result = _validate_api(dec_r.json(), dec_endpoint)
            if result:
                # rapidshare/megaup format: {"sources": [{"file": "..."}], "tracks": [...]}
                sources = result.get("sources") or []
                if sources and isinstance(sources, list):
                    file_url = sources[0].get("file")
                    if file_url:
                        return file_url
                # fallback for other formats
                url = result.get("url") or result.get("stream") or result.get("source")
                if url:
                    return url
        except Exception:
            pass
        return None

    def get_variants(self, master_url: str, referer: str = "") -> List[Dict]:
        """Parse quality variants from a master .m3u8 playlist."""
        try:
            hdr = {"User-Agent": USER_AGENT}
            if referer:
                hdr["Referer"] = referer
            r = requests.get(master_url, timeout=TIMEOUT, headers=hdr)
            r.raise_for_status()
            return _parse_master_playlist(master_url, r.text)
        except Exception as e:
            logger.debug(f"Master playlist fetch failed: {e}")
            return []


def _normalize_entry(entry: dict) -> Optional[Dict]:
    """Convert a database entry to a normalised title dict."""
    if not entry:
        return None
    info = entry.get("info", {}) if isinstance(entry.get("info"), dict) else {}
    episodes_raw = entry.get("episodes", {})

    flix_id = info.get("flix_id", "")
    if not flix_id:
        return None

    watch_path = info.get("flix_watch", "")
    uri = f"/{watch_path}" if watch_path and not watch_path.startswith("/") else watch_path

    seasons = _parse_db_episodes(episodes_raw)

    return {
        "id": flix_id,
        "title": info.get("title_en", "Unknown"),
        "type": info.get("type", "movie"),
        "year": (info.get("year") or "")[:4],
        "tmdb_id": info.get("tmdb_id", ""),
        "imdb_id": info.get("imdb_id", ""),
        "uri": uri,
        "poster": "",
        "rating": "",
        "seasons": seasons,
    }


def _parse_db_episodes(episodes_raw: dict) -> List[Dict]:
    """
    Convert the database episodes dict to our internal season/episode list.

    DB format: { "1": { "1": { "title": "...", "eid": "..." }, ... }, ... }
    Output:    [ { "number": 1, "episodes": [ { "number": 1, "title": "...", "id": "..." }, ... ] } ]
    """
    if not isinstance(episodes_raw, dict):
        return []
    seasons = []
    for s_num_str in sorted(episodes_raw.keys(), key=lambda x: int(x) if x.isdigit() else 0):
        s_num = int(s_num_str) if s_num_str.isdigit() else 0
        eps_raw = episodes_raw[s_num_str]
        if not isinstance(eps_raw, dict):
            continue
        episodes = []
        for e_num_str in sorted(eps_raw.keys(), key=lambda x: int(x) if x.isdigit() else 0):
            e_num = int(e_num_str) if e_num_str.isdigit() else 0
            ep = eps_raw[e_num_str]
            if isinstance(ep, dict):
                eid = ep.get("eid", "")
                title = ep.get("title", "")
                if eid:
                    episodes.append({
                        "number": e_num,
                        "title": title,
                        "id": eid,
                    })
        if episodes:
            seasons.append({"number": s_num, "episodes": episodes})
    return seasons


def _parse_yflix_cards(html: str, kind: str = "movie") -> List[Dict]:
    """Extract title cards from yflix.to page HTML."""
    soup = BeautifulSoup(html, "html.parser")
    results = []
    seen: set = set()

    for a in soup.find_all("a", href=re.compile(r"/watch/")):
        href = a.get("href", "")
        if not href or href in seen:
            continue
        seen.add(href)

        slug = href.replace("/watch/", "").strip("/")
        parts = slug.rsplit(".", 1)
        flix_id = parts[-1] if len(parts) > 1 else slug
        card_kind = "tv" if slug.startswith("tv-") else "movie"

        if kind and card_kind != kind:
            continue

        title = ""
        parent = a.parent
        if parent:
            for cls in ["detail", "film-name", "title"]:
                el = parent.find(["div", "h3", "span"], class_=cls)
                if el:
                    title = el.get_text(strip=True)
                    break
        if not title:
            title = a.get("title") or a.get("aria-label") or ""
        if not title:
            name_part = slug.rsplit(".", 1)[0]
            name_part = re.sub(r"^(movie|tv)-", "", name_part)
            title = name_part.replace("-", " ").title()

        results.append({
            "id": flix_id,
            "title": title,
            "type": card_kind,
            "year": "",
            "uri": href,
            "poster": "",
            "rating": "",
            "seasons": [],
        })

    return results


def _parse_master_playlist(master_url: str, text: str) -> List[Dict]:
    """Parse quality variants from a master m3u8 playlist."""
    variants = []
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("#EXT-X-STREAM-INF"):
            res_m = re.search(r"RESOLUTION=(\d+)x(\d+)", line)
            bw_m = re.search(r"BANDWIDTH=(\d+)", line)
            height = int(res_m.group(2)) if res_m else 0
            bw = int(bw_m.group(1)) if bw_m else 0
            url_line = lines[i + 1] if i + 1 < len(lines) else ""
            if url_line and not url_line.startswith("#"):
                seg_url = url_line if url_line.startswith("http") else urljoin(master_url, url_line)
                variants.append({
                    "height": height,
                    "bandwidth": bw,
                    "quality": f"{height}p" if height else "unknown",
                    "url": seg_url,
                })
    variants.sort(key=lambda v: v["height"], reverse=True)
    return variants
