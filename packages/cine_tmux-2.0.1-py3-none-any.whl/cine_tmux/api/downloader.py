"""
HLS segment downloader for cine-tmux.

Downloads all segments from an m3u8 playlist using parallel workers,
then muxes them into a single .mp4 using ffmpeg.
"""

import os
import re
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, List, Optional
from urllib.parse import urljoin, urlparse

import requests
from tqdm import tqdm

from loguru import logger
from ..utils.helper import format_size


_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Linux; Android 11; Pixel 5) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Mobile Safari/537.36"
    ),
}


class Downloader:
    def __init__(self, workers: int = 4):
        self.workers = workers
        self.session = requests.Session()
        self.session.headers.update(_HEADERS)

    # ------------------------------------------------------------------
    # Playlist helpers
    # ------------------------------------------------------------------

    def fetch_playlist(self, playlist_url: str, output_dir: str) -> Optional[str]:
        """Download the m3u8 playlist file and return its local path."""
        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, "playlist.m3u8")
        if os.path.exists(path):
            logger.info("Resuming: playlist already cached.")
            return path
        try:
            r = self.session.get(playlist_url, timeout=20)
            r.raise_for_status()
            with open(path, "w", encoding="utf-8") as f:
                f.write(r.text)
            return path
        except Exception as e:
            logger.error(f"Failed to download playlist: {e}")
            return None

    def parse_playlist(self, playlist_path: str, playlist_url: str) -> Optional[dict]:
        """Parse m3u8 playlist and return segment details."""
        if not os.path.exists(playlist_path):
            return None

        segments = []
        key_url = None
        iv_hex = None
        total_duration = 0.0

        with open(playlist_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line.startswith("#EXT-X-KEY"):
                    uri_m = re.search(r'URI="([^"]+)"', line)
                    iv_m = re.search(r'IV=0x([0-9a-fA-F]+)', line)
                    if uri_m:
                        raw_key = uri_m.group(1)
                        key_url = raw_key if raw_key.startswith("http") else urljoin(playlist_url, raw_key)
                    if iv_m:
                        iv_hex = iv_m.group(1)
                elif line.startswith("#EXTINF:"):
                    try:
                        total_duration += float(line.split(":")[1].split(",")[0])
                    except (ValueError, IndexError):
                        pass
                elif line and not line.startswith("#"):
                    seg_url = line if line.startswith("http") else urljoin(playlist_url, line)
                    segments.append(seg_url)

        if not segments:
            logger.error("No segments found in playlist.")
            return None

        return {
            "segments": segments,
            "key_url": key_url,
            "iv_hex": iv_hex,
            "duration": total_duration,
        }

    # ------------------------------------------------------------------
    # Segment download
    # ------------------------------------------------------------------

    def _download_segment(self, seg_url: str, output_path: str, key: Optional[bytes], iv: bytes) -> int:
        """Download and optionally decrypt a single segment. Returns bytes written."""
        if os.path.exists(output_path):
            return os.path.getsize(output_path)

        for attempt in range(3):
            try:
                r = self.session.get(seg_url, timeout=30, stream=True)
                r.raise_for_status()
                data = r.content
                break
            except Exception as e:
                if attempt == 2:
                    logger.error(f"Segment failed: {os.path.basename(output_path)} — {e}")
                    return 0
                time.sleep(2 ** attempt)
        else:
            return 0

        if key:
            try:
                from Crypto.Cipher import AES
                while len(data) % 16 != 0:
                    data += b"\x00"
                cipher = AES.new(key, AES.MODE_CBC, iv)
                data = cipher.decrypt(data)
            except Exception as e:
                logger.warning(f"Decryption failed for {os.path.basename(output_path)}: {e}")

        with open(output_path, "wb") as f:
            f.write(data)
        return len(data)

    def download_segments(self, playlist_details: dict, playlist_url: str, output_dir: str) -> bool:
        """Download all segments using parallel workers."""
        segments = playlist_details["segments"]
        key_url = playlist_details.get("key_url")
        iv_hex = playlist_details.get("iv_hex")

        # Fetch decryption key if present
        key = None
        if key_url:
            try:
                r = self.session.get(key_url, timeout=10)
                r.raise_for_status()
                key = r.content
                logger.debug(f"Encryption key fetched ({len(key)} bytes)")
            except Exception as e:
                logger.warning(f"Could not fetch decryption key: {e}")

        # Build list of (seg_url, output_path, iv) tuples
        tasks = []
        for idx, seg_url in enumerate(segments):
            seg_name = f"seg_{idx:06d}.ts"
            out_path = os.path.join(output_dir, seg_name)
            if iv_hex:
                iv = bytes.fromhex(iv_hex.zfill(32))
            else:
                iv = idx.to_bytes(16, "big")
            tasks.append((seg_url, out_path, key, iv))

        pending = [(u, p, k, iv) for u, p, k, iv in tasks if not os.path.exists(p)]
        if not pending:
            logger.info("All segments already downloaded.")
            return True

        logger.info(f"Downloading {len(pending)} segments ({len(tasks) - len(pending)} cached)…")
        total_bytes = 0
        start = time.time()
        failed = []

        with tqdm(total=len(pending), unit="seg", desc="Segments", ncols=80) as pbar:
            with ThreadPoolExecutor(max_workers=self.workers) as ex:
                futs = {ex.submit(self._download_segment, u, p, k, iv): p for u, p, k, iv in pending}
                for fut in as_completed(futs):
                    n = fut.result()
                    if n == 0:
                        failed.append(futs[fut])
                    else:
                        total_bytes += n
                    elapsed = time.time() - start
                    speed = total_bytes / elapsed if elapsed > 0 else 0
                    pbar.set_postfix_str(f"{format_size(int(speed))}/s")
                    pbar.update(1)

        if failed:
            logger.warning(f"{len(failed)} segments failed. Try again to resume.")
            return False

        return True

    # ------------------------------------------------------------------
    # Muxing
    # ------------------------------------------------------------------

    def mux(
        self,
        segment_dir: str,
        output_path: str,
        total_duration: float = 0.0,
        progress_cb: Optional[Callable[[int], None]] = None,
    ) -> bool:
        """Concatenate .ts segments into a single .mp4 using ffmpeg."""
        ffmpeg = os.environ.get("FFMPEG") or shutil.which("ffmpeg")
        if not ffmpeg:
            logger.error("ffmpeg not found. Install: pkg install ffmpeg")
            return False

        # Write concat file in segment order
        file_list = os.path.join(segment_dir, "concat.txt")
        segs = sorted(
            [f for f in os.listdir(segment_dir) if f.startswith("seg_") and f.endswith(".ts")]
        )
        if not segs:
            logger.error("No .ts segments found to mux.")
            return False

        with open(file_list, "w") as f:
            for s in segs:
                f.write(f"file '{os.path.join(segment_dir, s)}'\n")

        cmd = [
            ffmpeg, "-y",
            "-f", "concat", "-safe", "0",
            "-i", file_list,
            "-c", "copy",
            output_path,
            "-progress", "pipe:1",
            "-loglevel", "error",
        ]

        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            universal_newlines=True, bufsize=1,
        )

        for line in iter(proc.stdout.readline, ""):
            if total_duration > 0 and "out_time_ms=" in line and progress_cb:
                try:
                    ms = int(line.split("=")[1].strip())
                    pct = min(100, int((ms / 1_000_000 / total_duration) * 100))
                    progress_cb(pct)
                except (ValueError, IndexError):
                    pass

        proc.wait()
        if proc.returncode == 0:
            if progress_cb:
                progress_cb(100)
            shutil.rmtree(segment_dir, ignore_errors=True)
            return True
        else:
            logger.error(f"ffmpeg exited with code {proc.returncode}")
            return False

    # ------------------------------------------------------------------
    # Full pipeline
    # ------------------------------------------------------------------

    def download(
        self,
        playlist_url: str,
        output_path: str,
        title: str = "Video",
    ) -> bool:
        """
        Full download pipeline:
          1. Fetch playlist
          2. Download all segments
          3. Mux into mp4
        """
        seg_dir = output_path.replace(".mp4", "_segments")
        os.makedirs(seg_dir, exist_ok=True)

        playlist_path = self.fetch_playlist(playlist_url, seg_dir)
        if not playlist_path:
            return False

        details = self.parse_playlist(playlist_path, playlist_url)
        if not details:
            return False

        logger.info(
            f"Playlist: {len(details['segments'])} segments, "
            f"~{details['duration']:.0f}s"
        )

        ok = self.download_segments(details, playlist_url, seg_dir)
        if not ok:
            return False

        logger.info(f"Muxing → {output_path}")
        with tqdm(total=100, desc="Muxing", unit="%", ncols=80, leave=False) as pbar:
            def cb(pct):
                pbar.n = pct
                pbar.refresh()
            success = self.mux(seg_dir, output_path, details["duration"], cb)

        if success:
            logger.success(f"Saved: {output_path}")
        return success
