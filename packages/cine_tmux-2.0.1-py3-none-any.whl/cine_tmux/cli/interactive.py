"""Interactive launcher shown when cine is run with no arguments."""

from rich.console import Console
from rich.panel import Panel
import questionary

console = Console()

_GENRES = [
    "action", "adventure", "animation", "comedy", "crime",
    "documentary", "drama", "fantasy", "horror", "mystery",
    "romance", "sci-fi", "thriller", "western",
]


def run_interactive_mode():
    console.print(Panel.fit(
        "[bold cyan]cine-tmux[/bold cyan] — Movie & TV downloader for Termux\n"
        "[dim]Run [bold]cine --help[/bold] for all CLI options[/dim]",
        border_style="cyan",
    ))

    action = questionary.select(
        "What would you like to do?",
        choices=[
            "Search for a movie or TV show",
            "Browse latest movies",
            "Browse latest TV shows",
            "Browse by genre",
            "Show config",
            "Quit",
        ],
    ).ask()

    if not action or action == "Quit":
        return

    from .commands import cmd_search, cmd_browse
    from ..utils import config

    common = dict(
        download_dir=config.get_download_dir(),
        quality=config.get_quality(),
        play=False,
        player=config.get_player(),
        non_interactive=False,
        episode_range=None,
        link_index=0,
        verbose=False,
    )

    if action == "Search for a movie or TV show":
        query = questionary.text("Enter search query:").ask()
        if query:
            cmd_search(query=query, **common)

    elif action == "Browse latest movies":
        cmd_browse(kind="movie", genre="", **common)

    elif action == "Browse latest TV shows":
        cmd_browse(kind="tv", genre="", **common)

    elif action == "Browse by genre":
        kind = questionary.select("Movie or TV?", choices=["movie", "tv"]).ask()
        genre = questionary.select("Choose genre:", choices=_GENRES).ask()
        if kind and genre:
            cmd_browse(kind=kind, genre=genre, **common)

    elif action == "Show config":
        config.cmd_show_config()
