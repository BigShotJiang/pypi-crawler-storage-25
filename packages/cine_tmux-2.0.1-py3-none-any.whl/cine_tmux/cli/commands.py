"""
CLI commands for cine-tmux.

cmd_search  — search the enc-dec.app flix database then interactively download/play
cmd_browse  — browse yflix.to home page or genre pages
"""

from __future__ import annotations

import os
import subprocess
from typing import Dict, List, Optional

import questionary
from pyfzf.pyfzf import FzfPrompt
from rich.console import Console
from rich.table import Table

from ..api.client import YFlixClient
from ..api.downloader import Downloader
from ..utils import config
from ..utils.helper import sanitize_filename, detect_player
from loguru import logger

console = Console()


def _fzf_pick(items: List[Dict], key: str = "title",
              multi: bool = False, prompt: str = "Select") -> List[Dict]:
    if not items:
        return []
    fzf = FzfPrompt()
    labels = [f"{i+1}. {item.get(key, str(item))}" for i, item in enumerate(items)]
    opts = f"--prompt='{prompt} > '"
    if multi:
        opts += " --multi --bind space:toggle"
    try:
        selected = fzf.prompt(labels, opts)
    except Exception:
        return []
    chosen = []
    for sel in selected:
        try:
            idx = int(sel.split(".")[0]) - 1
            if 0 <= idx < len(items):
                chosen.append(items[idx])
        except (ValueError, IndexError):
            pass
    return chosen


def _pick_one(items: List[Dict], key: str = "title",
              prompt: str = "Select") -> Optional[Dict]:
    chosen = _fzf_pick(items, key=key, multi=False, prompt=prompt)
    return chosen[0] if chosen else None


def _print_titles(items: List[Dict]):
    table = Table(title="Results", show_lines=True)
    table.add_column("#", style="dim", width=4)
    table.add_column("Title", style="bold cyan")
    table.add_column("Type", style="magenta", width=6)
    table.add_column("Year", style="dim", width=6)
    for i, item in enumerate(items, 1):
        table.add_row(str(i), item.get("title", "?"),
                      item.get("type", "?"), str(item.get("year", "")))
    console.print(table)


def _print_seasons(seasons: List[Dict]):
    table = Table(title="Seasons", show_lines=True)
    table.add_column("#", style="dim", width=4)
    table.add_column("Season", style="bold cyan")
    table.add_column("Episodes", style="dim", width=10)
    for s in seasons:
        table.add_row(
            str(s["number"]),
            f"Season {s['number']}",
            str(len(s.get("episodes", []))),
        )
    console.print(table)


def _print_episodes(episodes: List[Dict]):
    table = Table(title="Episodes", show_lines=True)
    table.add_column("Ep", width=6, style="dim")
    table.add_column("Title", style="cyan")
    for ep in episodes:
        table.add_row(str(ep.get("number", "?")), ep.get("title") or "(no title)")
    console.print(table)


def _print_servers(servers: Dict[str, List[Dict]]):
    table = Table(title="Streaming Servers", show_lines=True)
    table.add_column("#", width=4, style="dim")
    table.add_column("Type", style="dim", width=10)
    table.add_column("Server", style="bold cyan")
    i = 1
    for stype, srv_list in servers.items():
        for srv in srv_list:
            table.add_row(str(i), stype, srv.get("name", "?"))
            i += 1
    console.print(table)


def _print_variants(variants: List[Dict]):
    table = Table(title="Quality Options", show_lines=True)
    table.add_column("#", width=4, style="dim")
    table.add_column("Quality", style="bold green")
    for i, v in enumerate(variants, 1):
        table.add_row(str(i), v.get("quality", "?"))
    console.print(table)


def _output_path(title: str, download_dir: str,
                 season: int = 0, ep_num: Optional[int] = None) -> str:
    safe = sanitize_filename(title)
    folder = os.path.join(download_dir, safe)
    os.makedirs(folder, exist_ok=True)
    if season and ep_num is not None:
        filename = f"{safe} S{season:02d}E{ep_num:02d}.mp4"
    elif ep_num is not None:
        filename = f"{safe} Episode {ep_num:02d}.mp4"
    else:
        filename = f"{safe}.mp4"
    return os.path.join(folder, filename)


def _play_stream(url: str, title: str, player: str, referer: str = ""):
    p = detect_player(player)
    if not p:
        logger.error("No media player found. Install mpv: pkg install mpv")
        return
    logger.info(f"Playing with {p}: {title}")
    cmd = [p]
    if p == "mpv":
        cmd += [f"--title={title}", "--network-timeout=30"]
        if referer:
            cmd += [f"--referrer={referer}"]
    cmd.append(url)
    try:
        subprocess.run(cmd)
    except Exception as e:
        logger.error(f"Player error: {e}")


def _choose_quality(variants: List[Dict], quality: str) -> str:
    if not variants:
        return ""
    if quality == "best":
        return variants[0]["url"]
    try:
        target = int(quality.replace("p", ""))
        for v in variants:
            if v["height"] <= target:
                return v["url"]
        return variants[-1]["url"]
    except (ValueError, TypeError):
        return variants[0]["url"]


def _flatten_servers(servers: Dict[str, List[Dict]]) -> List[Dict]:
    """Flatten server dict into a list with stype field."""
    flat = []
    for stype, srv_list in servers.items():
        for srv in srv_list:
            flat.append({**srv, "stype": stype})
    return flat


def _download_episode(
    client: YFlixClient,
    downloader: Downloader,
    title: str,
    eid: str,
    play: bool,
    player: str,
    quality: str,
    download_dir: str,
    season: int = 0,
    ep_num: Optional[int] = None,
    non_interactive: bool = False,
    link_index: int = 0,
):
    """Core pipeline for a single episode or movie."""
    out_path = _output_path(title, download_dir, season, ep_num)
    if not play and os.path.exists(out_path):
        logger.success(f"Already downloaded: {out_path}")
        return

    logger.info("Fetching streaming servers…")
    servers = client.get_servers(eid)
    if not servers:
        logger.error("No streaming servers found.")
        return

    flat_servers = _flatten_servers(servers)
    _print_servers(servers)

    if non_interactive:
        chosen_srv = flat_servers[min(link_index, len(flat_servers) - 1)]
    else:
        srv_labels = [
            {"title": f"[{s['stype']}] {s['name']}", **s}
            for s in flat_servers
        ]
        picked = _pick_one(srv_labels, key="title", prompt="Choose server")
        if not picked:
            logger.info("No server selected.")
            return
        chosen_srv = picked

    lid = chosen_srv.get("lid", "")
    if not lid:
        logger.error("No link ID for selected server.")
        return

    logger.info(f"Resolving embed for server: {chosen_srv.get('name', lid)}")
    embed_url = client.get_embed_url(lid)
    if not embed_url:
        logger.error("Could not resolve embed URL — try a different server.")
        return

    logger.info("Extracting HLS stream…")
    master_url = client.extract_hls(embed_url)
    if not master_url:
        logger.error("No stream URL found from hoster — try a different server.")
        return

    referer = embed_url.split("/e/")[0] + "/" if "/e/" in embed_url else ""

    variants = client.get_variants(master_url, referer=referer)
    if variants:
        _print_variants(variants)
        playlist_url = _choose_quality(variants, quality)
    else:
        playlist_url = master_url

    logger.info(f"Stream: {playlist_url[:80]}…")

    if play:
        _play_stream(playlist_url, title, player, referer=referer)
    else:
        downloader.download(playlist_url, out_path, title)


def _handle_movie(
    client: YFlixClient,
    downloader: Downloader,
    item: Dict,
    play: bool,
    player: str,
    quality: str,
    download_dir: str,
    non_interactive: bool,
    link_index: int,
):
    title = item.get("title", "Unknown")
    seasons = item.get("seasons", [])

    if not seasons:
        logger.error("No episode data found for this title.")
        return

    all_eps = seasons[0].get("episodes", [])
    if not all_eps:
        logger.error("No episodes in season data.")
        return

    episode = all_eps[0]
    eid = episode.get("id", "")
    if not eid:
        logger.error("No episode ID found.")
        return

    _download_episode(
        client, downloader, title, eid,
        play, player, quality, download_dir,
        non_interactive=non_interactive, link_index=link_index,
    )


def _handle_tv_show(
    client: YFlixClient,
    downloader: Downloader,
    item: Dict,
    play: bool,
    player: str,
    quality: str,
    download_dir: str,
    episode_range: Optional[str],
    non_interactive: bool,
    link_index: int,
):
    title = item.get("title", "Unknown")
    seasons = item.get("seasons", [])

    if not seasons:
        logger.warning("No season data — treating as single file.")
        _handle_movie(client, downloader, item, play, player, quality,
                      download_dir, non_interactive, link_index)
        return

    if non_interactive:
        chosen_season = seasons[0]
    elif len(seasons) == 1:
        chosen_season = seasons[0]
    else:
        _print_seasons(seasons)
        season_labels = [
            {"title": f"Season {s['number']} ({len(s.get('episodes', []))} eps)", **s}
            for s in seasons
        ]
        picked = _pick_one(season_labels, key="title", prompt="Choose season")
        if not picked:
            return
        chosen_season = picked

    season_num = chosen_season.get("number", 1)
    episodes = chosen_season.get("episodes", [])

    if not episodes:
        logger.warning(f"Season {season_num} has no episodes.")
        return

    _print_episodes(episodes)

    if episode_range:
        max_ep = max((e.get("number", 0) for e in episodes), default=1)
        ep_nums = _parse_range(episode_range, max_ep)
        selected_eps = [e for e in episodes if e.get("number") in ep_nums]
    elif non_interactive:
        selected_eps = [episodes[0]]
    else:
        ep_labels = [
            {"title": f"E{e['number']:02d} — {e.get('title') or ''}",
             **e}
            for e in episodes
        ]
        picked_eps = _fzf_pick(ep_labels, key="title", multi=True, prompt="Pick episode(s)")
        if not picked_eps:
            return
        picked_ids = {p["id"] for p in picked_eps}
        selected_eps = [e for e in episodes if e.get("id") in picked_ids]
        if not selected_eps:
            selected_eps = picked_eps

    if not selected_eps:
        logger.info("No episodes selected.")
        return

    for ep in selected_eps:
        eid = ep.get("id", "")
        ep_num = ep.get("number") or 0

        logger.info(f"Processing S{season_num:02d}E{ep_num:02d}: {title}")
        _download_episode(
            client, downloader, title, eid,
            play, player, quality, download_dir,
            season=season_num, ep_num=ep_num,
            non_interactive=non_interactive, link_index=link_index,
        )


def _parse_range(rng: str, max_ep: int) -> set:
    nums: set = set()
    for part in rng.split(","):
        part = part.strip()
        if "-" in part:
            try:
                a, b = part.split("-")
                nums.update(range(int(a), int(b) + 1))
            except ValueError:
                pass
        else:
            try:
                nums.add(int(part))
            except ValueError:
                pass
    return {n for n in nums if 1 <= n <= max_ep}


def cmd_search(
    query: str,
    download_dir: str,
    quality: str = "best",
    play: bool = False,
    player: str = "",
    non_interactive: bool = False,
    episode_range: Optional[str] = None,
    link_index: int = 0,
    content_type: Optional[str] = None,
    verbose: bool = False,
    **kwargs,
):
    """Search for a title and interactively download or play it."""
    client = YFlixClient()
    downloader = Downloader(workers=config.get_workers())

    logger.info(f"Searching: {query}")
    results = client.search(query, kind=content_type)

    if not results:
        logger.warning("No results found.")
        return

    _print_titles(results)

    if non_interactive:
        selected = [results[0]]
    else:
        selected = _fzf_pick(results, key="title", multi=True, prompt="Pick title(s)")

    if not selected:
        logger.info("Nothing selected.")
        return

    for item in selected:
        title = item.get("title", "Unknown")
        kind = item.get("type", "movie")
        console.print(f"\n[bold green]→ {title}[/bold green] [{kind}]")

        if kind == "tv":
            _handle_tv_show(
                client, downloader, item,
                play, player, quality, download_dir,
                episode_range, non_interactive, link_index,
            )
        else:
            _handle_movie(
                client, downloader, item,
                play, player, quality, download_dir,
                non_interactive, link_index,
            )


def cmd_browse(
    kind: str = "movie",
    genre: str = "",
    download_dir: str = "",
    quality: str = "best",
    play: bool = False,
    player: str = "",
    non_interactive: bool = False,
    episode_range: Optional[str] = None,
    link_index: int = 0,
    content_type: Optional[str] = None,
    verbose: bool = False,
    **kwargs,
):
    """Browse latest movies or TV shows from yflix.to home page or a genre page."""
    download_dir = download_dir or config.get_download_dir()
    client = YFlixClient()
    downloader = Downloader(workers=config.get_workers())

    if genre:
        logger.info(f"Browsing {kind} / genre: {genre}…")
    else:
        logger.info(f"Browsing latest {kind}s…")

    items = client.browse(kind=kind, genre=genre)

    if not items:
        logger.warning("No items found. Try: cine --browse movie")
        return

    _print_titles(items)

    if non_interactive:
        selected = [items[0]]
    else:
        selected = _fzf_pick(items, key="title", multi=True, prompt="Pick title(s)")

    if not selected:
        return

    for item in selected:
        title = item.get("title", "Unknown")
        item_kind = item.get("type", kind)
        console.print(f"\n[bold green]→ {title}[/bold green] [{item_kind}]")

        if item_kind == "tv":
            _handle_tv_show(
                client, downloader, item,
                play, player, quality, download_dir,
                episode_range, non_interactive, link_index,
            )
        else:
            _handle_movie(
                client, downloader, item,
                play, player, quality, download_dir,
                non_interactive, link_index,
            )
