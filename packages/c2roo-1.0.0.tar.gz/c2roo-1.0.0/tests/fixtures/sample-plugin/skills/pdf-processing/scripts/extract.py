print("placeholder extraction script")
