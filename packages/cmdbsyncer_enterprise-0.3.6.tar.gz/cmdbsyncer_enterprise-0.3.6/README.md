# cmdbsyncer-enterprise

Commercial add-on for [cmdbsyncer](https://github.com/Kuhn-Ruess-GmbH/cmdbsyncer)
by Kuhn & Ruess GmbH. Adds licensed enterprise features to the open-source core
via a graceful import mechanism — the OSS stays fully functional without this
package.

## Features

| Feature key        | Description                                              |
| ------------------ | -------------------------------------------------------- |
| `remote_user`      | Web-server-provided `REMOTE_USER` single sign-on login   |
| `ldap_login`       | LDAP / Active Directory bind authentication with group-based role mapping |
| `secrets_manager`  | Pull account passwords from external vaults instead of the local DB; supports KeePass, LastPass, HashiCorp Vault, AWS Secrets Manager, environment variables |
| `json_logging`     | ECS-shaped JSON log stream on stdout for cloud log collectors (Loki, OpenSearch / Elastic, CloudWatch, Datadog, Splunk, Fluent Bit / Vector) |
| `audit_log`        | Append-only, WORM-style audit trail with auto-captured CRUD on Accounts/Users/CronGroups/Rules/SecretStores, login events, webhook triggers, and field-level diffs (secrets redacted) |
| `audit_siem_streaming` | Extends `audit_log`: fans every audit entry out to external SIEMs (Splunk HEC, syslog TCP/TLS, generic HTTPS webhook) so compliance teams get read-only, append-only copies outside of CMDBsyncer's own database |
| `notifications`    | Rule-matched alert routing to Slack, MS Teams, email and generic webhooks — with deduplication, cooldowns and rate-limits. Consumes cron failures, license expiry, and (when co-licensed) audit events |
| `oidc_login`       | Native OpenID Connect client — log in directly against Azure AD / Entra ID, Okta, Keycloak, Google Workspace, Auth0 without a reverse-proxy in front |
| `webhook_signatures` | Hardens the OSS `/cron/trigger` endpoint with HMAC-SHA256 request signing, replay-protection via timestamp window, and per-group IP allowlists |
| `prometheus_metrics` | Exposes `/metrics` in Prometheus text format; generates gauges from live Mongo state per scrape (cron status, freshness, host counts). Optional Bearer-token auth via env var |
| `scheduled_backup` | Encrypted Mongo dumps to any S3-compatible object storage (AWS / GCS / Azure / MinIO / B2 / Wasabi / DO Spaces) with gzip + optional GPG encryption, retention policy, and a built-in `enterprise-backup_run` cron task. `boto3` + `mongodump` required on the syncer host |
| `approval_workflow`| 4-Eyes gate on sensitive resource types (configurable per type). Mutations stage as `PendingChange` rows; a different admin reviews the diff and approves/rejects. Requester-cannot-approve-own is hard-enforced. Every submit/approve/reject is audited and routable via notifications. Secrets are redacted in the diff view but kept in the payload so password rotations still apply on approval |
| `license_info`     | Always registered — exposes the active license claims to the OSS via `run_hook('license_info')` |

Additional features are enabled by the license claims and registered at import
time. See *Adding a feature* below.

### Supported secret vaults (`secrets_manager` feature)

| Provider                  | Store type     | Extra dependency        | Authentication                                              |
| ------------------------- | -------------- | ----------------------- | ----------------------------------------------------------- |
| KeePass (`.kdbx` file)    | `keepass`      | `pip install pykeepass` | Master password from an env var and/or a keyfile on disk    |
| LastPass                  | `lastpass`     | `lpass` CLI on PATH     | `lpass login <user>` once as the syncer OS user (no DB secret) |
| HashiCorp Vault (KV v1/v2)| `vault`        | `pip install hvac`      | Token read from a named env var; namespaces supported       |
| AWS Secrets Manager       | `aws_secrets`  | `pip install boto3`     | Standard AWS credential chain (IAM role, env, profile, SSO) |
| Environment variable      | `envvar`       | none                    | The value lives in the syncer process env                   |

All providers lazy-import their SDKs, so a single install does not force
unused dependencies onto the host. Convenience extras:

```sh
pip install 'cmdbsyncer-enterprise[keepass]'
pip install 'cmdbsyncer-enterprise[vault]'
pip install 'cmdbsyncer-enterprise[aws]'
pip install 'cmdbsyncer-enterprise[secrets-all]'  # keepass + vault + aws
```

## Architecture

```text
+------------------+       +----------------------------+
|  cmdbsyncer      |       |  cmdbsyncer_enterprise     |
|  (OSS)           |       |  (this package)            |
|                  |       |                            |
|  application/    |       |  __init__.py               |
|    enterprise.py |<------+    load_and_verify()       |
|    run_hook(...) |       |    register_feature(...)   |
+------------------+       +----------------------------+
                                    ^
                                    | reads
                                    |
                           /etc/cmdbsyncer/license.jwt
                           (RS256-signed, verified against
                            embedded public_key.pem)
```

- The OSS module `application/enterprise.py` imports `cmdbsyncer_enterprise`
  inside a `try/except ImportError`. If the package is absent, missing a
  license, or the license is invalid/expired, the import fails silently and
  all enterprise hooks become no-ops.
- On a valid license, this package registers each feature listed in the
  license claims against the OSS hook registry, binding it to its handler.
- OSS call sites use `run_hook('<feature_name>', ...)`; a missing hook
  returns `None` and the OSS falls back to its default behaviour.

## Requirements

- Python 3.10+
- cmdbsyncer OSS installed in the same environment
- `joserfc >= 1.6` (JWT license verification)
- `ldap3 >= 2.9` (only used when the `ldap_login` feature is licensed)
- Optional per-provider, only when `secrets_manager` is licensed *and* the
  corresponding store type is used: `pykeepass` (KeePass), `hvac` (Vault),
  `boto3` (AWS Secrets Manager), and the `lpass` CLI (LastPass).
  Install via the extras: `pip install 'cmdbsyncer-enterprise[secrets-all]'`.

## Installation (customer)

```sh
pip install cmdbsyncer-enterprise
```

Place the license file provided by Kuhn & Ruess GmbH **next to your
`local_config.py`** — that's the directory the pip install already uses
for runtime config, so no extra directory is required:

```text
<dir of local_config.py>/license.jwt
```

To use a custom path instead:

```sh
export CMDBSYNCER_LICENSE=/opt/cmdbsyncer/license.jwt
```

Restart cmdbsyncer. On successful activation you will see a log line like:

```text
cmdbsyncer-enterprise active (license CUST-2026-001, customer Acme Corp,
expires 1778284800, features ['remote_user'])
```

If the log stays silent and enterprise features are inactive, check the
application log for the `ImportError` message — it will name the exact
failure (missing file, bad signature, expired).

## Configuration

### `remote_user` feature

Enable it in cmdbsyncer's `local_config.py`:

```python
REMOTE_USER_LOGIN = True
```

Your reverse proxy (Apache / nginx / etc.) must authenticate the user and
set the `REMOTE_USER` WSGI environ variable. Make sure the proxy strips
any client-supplied value before forwarding the request — otherwise
anyone could impersonate any user by sending the header directly.

Users matched by `request.remote_user` are resolved against the `name`
field of the cmdbsyncer user model; disabled users are rejected.

### `ldap_login` feature

Authenticates users against an LDAP / Active Directory server. Configure
in cmdbsyncer's `local_config.py`:

```python
# Required
LDAP_SERVER = 'ldaps://ldap.example.com'

# Option A: direct bind — build the user DN from a template
LDAP_USER_DN_TEMPLATE = 'uid={username},ou=people,dc=example,dc=com'

# Option B: search-then-bind — use a service account to locate the user
LDAP_BIND_USER = 'cn=svc-cmdbsyncer,ou=services,dc=example,dc=com'
LDAP_BIND_PASSWORD = '...'
LDAP_SEARCH_BASE = 'dc=example,dc=com'
LDAP_SEARCH_FILTER = '(mail={email})'

# Attribute used for the display name (default: 'cn')
LDAP_NAME_ATTR = 'cn'

# Optional: require the user to be in this group
LDAP_REQUIRED_GROUP = 'cn=cmdbsyncer-users,ou=groups,dc=example,dc=com'

# Optional: create a local user on first successful bind (default: True)
LDAP_AUTO_CREATE = True

# Optional: map LDAP groups to cmdbsyncer roles. Re-evaluated on every login.
LDAP_ROLE_MAPPING = {
    'cn=cmdbsyncer-admins,ou=groups,dc=example,dc=com': {
        'global_admin': True,
    },
    'cn=cmdbsyncer-users,ou=groups,dc=example,dc=com': {
        'roles': ['viewer'],
        'api_roles': ['api_read'],
    },
}
```

Either `LDAP_USER_DN_TEMPLATE` (direct bind) or `LDAP_BIND_USER`
(search-then-bind) must be set. On each successful login the user's
`roles`, `api_roles`, and `global_admin` flag are recomputed from the
current LDAP group membership — removing a user from an LDAP group
revokes the corresponding permissions on their next login. If LDAP
rejects the credentials the handler returns `None` and the OSS falls
back to local authentication.

### `secrets_manager` feature

Activates two new admin sections under *Secrets Manager*:

1. **Secret Stores** — one entry per external vault (KeePass file,
   LastPass session, Vault server, AWS account, or "environment").
2. **Account Bindings** — per-Account link: "this Account pulls its
   password from that entry in that store."

Resolution happens transparently inside `get_account_by_name` in the
OSS: bound accounts return the vault value, unbound accounts keep
using the local encrypted `password_crypted` field. No changes are
required in any plugin — all existing Checkmk, Netbox, Jira, SQL,
Ansible syncs pick up the vault value automatically.

**Entry-path conventions per provider**

| Provider      | `entry_path` format                                                        |
| ------------- | -------------------------------------------------------------------------- |
| `keepass`     | `Root/Group/Subgroup/EntryName`                                            |
| `lastpass`    | `EntryName` — append `#username` or `#<field>` for non-password fields     |
| `vault`       | `kv/prod/checkmk` — append `#password` to pick a JSON key (default `password`) |
| `aws_secrets` | `prod/checkmk` (SecretId or ARN) — append `#password` for JSON secrets     |
| `envvar`      | The env-var name (e.g. `CMK_PROD_PASSWORD`)                                |

**Master secret storage**

No provider stores its master credential in the syncer DB:

- **KeePass** reads the master password from a named env var and/or a
  keyfile; at least one of the two must be set on the store.
- **LastPass** relies on an out-of-band `lpass login <user>` session;
  the CLI manages its own encrypted credential cache.
- **Vault** reads its token from a named env var — rotate via AppRole
  or renew externally; the client picks up the new value on next use.
- **AWS Secrets Manager** uses the standard credential chain — prefer
  IAM instance/task roles so no static keys exist anywhere.
- **envvar** is the pass-through: whatever process starts the syncer
  owns the secret.

**Rotation**

KeePass files are mtime-cached for 5 seconds, so edits in the .kdbx
are picked up on the next request. Vault tokens rotate automatically
on env-var change. AWS/LastPass use their respective upstream session
refresh semantics.

### `json_logging` feature

Replaces the default text log handler with an Elastic Common Schema
(ECS 8.11) JSON stream on stdout. Designed for container / cloud
deployments where a sidecar (Fluent Bit, Vector, Promtail, the
CloudWatch / Datadog agent, Splunk Universal Forwarder) scrapes
stdout and ships it to the log backend.

**Enable it** — just install the license with the `json_logging`
claim and restart the app. Every log line coming out of the syncer
becomes a one-line JSON document shaped like:

```json
{
  "@timestamp": "2026-04-23T09:05:12.487Z",
  "log": {"level": "info", "logger": "debug"},
  "message": "Checkmk Host Export",
  "ecs": {"version": "8.11.0"},
  "service": {"name": "cmdbsyncer", "environment": "prod", "version": "3.12.14"},
  "host": {"name": "syncer-7f4b"},
  "process": {"pid": 17},
  "url": {"path": "/api/v1/syncer/cron/trigger/prod-cmk"},
  "http": {"request": {"method": "POST"}},
  "trace": {"id": "4bf92f3577b34da6a3ce929d0e0e4736"},
  "client": {"ip": "10.0.12.44"},
  "event": {
    "source": "Checkmk Host Export",
    "category": "app",
    "outcome": "success",
    "details": {"created": "3", "updated": "17", "deleted": "0"}
  },
  "affected_hosts": ["web-01", "web-02"]
}
```

Python exceptions add `error.type`, `error.message`, and
`error.stack_trace`.

**Config knobs** (`local_config.py`):

| Key                      | Default   | Purpose                                       |
| ------------------------ | --------- | --------------------------------------------- |
| `JSON_LOGGING_ENABLED`   | `True`    | Override to `False` to keep text output even with the license active |
| `JSON_LOGGING_STREAM`    | `stdout`  | `stdout` or `stderr`                          |
| `JSON_LOGGING_LEVEL`     | `INFO`    | Any standard Python level name                |

**Environment variables** picked up automatically into ECS fields:

| Env var                                        | Populates              |
| ---------------------------------------------- | ---------------------- |
| `OTEL_SERVICE_NAME`, `SERVICE_NAME`            | `service.name`         |
| `DEPLOYMENT_ENVIRONMENT`, `ENV`                | `service.environment`  |
| `CMDBSYNCER_VERSION`, `SERVICE_VERSION`        | `service.version`      |
| `AWS_REGION`, `CLOUD_REGION`                   | `cloud.region`         |

Trace IDs are read first-match from these request headers:
`X-Request-ID`, `X-Cloud-Trace-Context`, `X-Amzn-Trace-Id`,
`traceparent`.

**Notes**

- The Mongo-backed `LogEntry` collection is unchanged — it still
  holds the structured application log for the admin UI. JSON
  stdout is an *additional* stream aimed at external aggregators.
- Werkzeug's default request log is dialed down to `WARNING` to
  avoid one JSON line per asset request. Raise
  `JSON_LOGGING_LEVEL=DEBUG` to restore it.
- `local_config.py` can add fields to every record: pass them as
  environment variables and add them to `_ENV_MAPPING` in a future
  contribution, or set `labels.*` via `logger.info(..., extra={...})`.

### `audit_log` feature

Activates an append-only audit trail under a new *Audit Log* admin
category. Records:

- **Login events** — success, failure (with reason: wrong password,
  user disabled, OTP missing/invalid), logout. LDAP and remote-user
  logins are tagged by method.
- **Webhook triggers** — accepted (with auth method) and rejected
  (with reason: webhook disabled / token mismatch), including the
  source IP.
- **CRUD on tracked models** — `Account`, `User`, `CronGroup`,
  `Config`, `CustomAttributeRule`, `Rule`, `SecretStore`,
  `AccountSecretBinding`. Created / updated / deleted with
  field-level diffs (before/after) for every changed field except
  sensitive values (`password`, `password_crypted`, `webhook_token`,
  `master_password_env`, `vault_token_env`, `tfa_secret`) which are
  stored as `***REDACTED***`. High-churn fields (`last_start`,
  `last_ended`, `last_success_at`, `next_run`, `is_running`,
  `last_login`, …) are excluded from diffs to keep the signal-to-
  noise ratio high.
- **Host** is intentionally **not** tracked — sync runs would
  produce millions of rows.

**WORM semantics**

The admin view exposes audit entries read-only: `can_create`,
`can_edit`, and `can_delete` are all `False`. A dedicated **Prune
entries older than 365 days** bulk action is available for
retention — it deletes in bulk and records *itself* as an
`audit.pruned` entry, so every prune is traceable.

**Export**

The admin list supports CSV and JSON export for compliance
evidence. Fields map straight onto standard audit-log columns
(timestamp, actor, event, target, outcome, changes).

**Fields on every entry**

| Field            | Populates                                                 |
| ---------------- | --------------------------------------------------------- |
| `timestamp`      | UTC datetime, ms precision                                |
| `event_type`     | Dot-separated identifier (`account.updated`, `user.login.success`, `webhook.triggered`) |
| `outcome`        | `success` / `failure`                                     |
| `actor_type`     | `user` / `system` / `cron` / `api_token` / `webhook` / `anonymous` |
| `actor_id`       | User ObjectId where applicable                            |
| `actor_name`     | Email (users) or identifier (tokens/webhooks)             |
| `actor_ip`       | Remote address from the HTTP request                      |
| `target_type`    | Name of the affected model class                          |
| `target_id`      | ObjectId of the target document                           |
| `target_name`    | Human-readable (`__str__`) rendering of the target        |
| `changes`        | `{field: {before: X, after: Y}}` — sensitive values redacted |
| `metadata`       | Free-form extra context (login method, rejection reason)  |
| `request_method` / `request_path` / `user_agent` / `trace_id` | HTTP request context, trace IDs from the JSON-logging headers |

**No extra configuration**

Install the enterprise package with the `audit_log` license claim
and restart — the feature is active. No tables to create (Mongo is
schemaless), no indices to build by hand (the model declares them).

### `audit_siem_streaming` feature

Requires `audit_log`. Adds a new *Audit Log → SIEM Sinks* admin view
with one row per external destination. On every persisted
`AuditEntry`, a background worker ships a copy to every enabled
sink. The local Mongo collection remains the primary store.

Supported sink types:

| Type             | What it does                                                       |
| ---------------- | ------------------------------------------------------------------ |
| `splunk_hec`     | HTTPS POST to Splunk HEC with `Authorization: Splunk <token>`. Token is pulled from `token_env`, never persisted. Optional `splunk_index` / `splunk_source` / `splunk_sourcetype`. |
| `syslog_tcp`     | RFC5424 framed message over plain TCP                              |
| `syslog_tls`     | Same, over TLS (default port 6514)                                 |
| `https_webhook`  | JSON POST to your own HTTPS endpoint (optional Bearer token via `token_env`) |

Delivery is asynchronous (bounded queue, background thread) so SIEM
hiccups never back-pressure login, cron ticks or audit writes.

### `notifications` feature

Activates two new admin sections under *Notifications*:

1. **Channels** — where to send. Types: `slack`, `msteams`, `email`,
   `webhook`. Each channel supports a "Send test notification"
   bulk action so operators can verify config without triggering a
   real failure.
2. **Rules** — what to send and when. Each rule has:
   - Regex matchers on `event_type`, `source`, `target`
   - `severity_min` gate (`info` / `warning` / `error` / `critical`)
   - Optional `outcome` filter (alert only on `failure`)
   - N channels to fire
   - Jinja templates for title and message
   - `cooldown_minutes` + `max_per_hour` per dedup-key for rate-limiting

**Event sources wired out of the box**

- `cron.group.failed` / `cron.group.recovered` from the OSS cron runner
- Audit events (when `audit_log` is co-licensed) — every `AuditEntry`
  is fed into the dispatcher, so rules can route `webhook.rejected`
  to `#security` or `user.login.failure` to a SIEM webhook
- License expiry warnings (todo: fired by a dedicated startup check)

**Slack channel specifics**

Block Kit message with a severity-coloured header. Optional `@mention`
and channel override (`#custom-channel`). Configure an incoming-webhook
URL in Slack, paste it into the channel, done.

**MS Teams channel specifics**

Adaptive Card v1.4 posted to an incoming-webhook URL (classic or
Workflows-based). Severity drives the accent colour.

**Email channel specifics**

Reuses the OSS SMTP config from `local_config.py` (no separate SMTP
setup). Multiple recipients, configurable subject prefix.

**Generic webhook channel specifics**

Raw JSON POST with `X-Signature-SHA256` (HMAC-SHA256 of the body)
when `webhook_secret_env` is set — GitHub-/Stripe-style so your
receiver can verify authenticity. Extra headers (e.g. `Authorization`)
are settable per channel.

**Dispatch semantics**

Runs in a background worker thread with a bounded queue. A slow or
unreachable Slack/SMTP endpoint never blocks the caller (login, cron
tick, audit save). Queue overflow is logged and dropped (bounded).

### `oidc_login` feature

Native OIDC client — no Apache/Nginx reverse-proxy needed. Works
with Azure AD / Entra ID, Okta, Keycloak, Google Workspace, Auth0,
or any OIDC-compliant IdP.

Enable in `local_config.py`:

```python
OIDC_LOGIN = True
OIDC_ISSUER = 'https://login.microsoftonline.com/<tenant>/v2.0'
OIDC_CLIENT_ID = '<app-id>'
OIDC_CLIENT_SECRET_ENV = 'OIDC_CLIENT_SECRET'  # preferred
# or:
# OIDC_CLIENT_SECRET = '<raw secret>'
OIDC_SCOPES = ['openid', 'email', 'profile', 'groups']
OIDC_GROUPS_CLAIM = 'groups'
OIDC_REQUIRED_GROUP = 'cmdbsyncer-users'   # optional
OIDC_AUTO_CREATE = True
OIDC_ROLE_MAPPING = {
    'cmdbsyncer-admins': {'global_admin': True},
    'cmdbsyncer-ops':    {'roles': ['host', 'log']},
}
```

Routes:

- `GET /oidc/login` — kicks off the authorization-code flow
- `GET /oidc/callback` — IdP redirects back here; tokens are
  exchanged and the user is logged in

Users are looked up locally by email (`email` claim by default,
configurable via `OIDC_EMAIL_CLAIM`). `OIDC_AUTO_CREATE` provisions
new users on first login; group membership maps to roles via
`OIDC_ROLE_MAPPING` — same union-of-groups semantics as LDAP role
mapping, so permissions can be driven entirely from the IdP. Every
login (success, failure, required-group missing, token exchange
failure) is recorded in the audit log when `audit_log` is co-licensed.

## Development setup (internal)

```sh
git clone git@github.com:Kuhn-Ruess-GmbH/cmdbsyncer-enterprise.git
cd cmdbsyncer-enterprise

# Generate the RSA keypair once (keep private_key.pem OUT of the repo):
openssl genrsa -out private_key.pem 4096
openssl rsa -in private_key.pem -pubout \
    -out src/cmdbsyncer_enterprise/public_key.pem

# Install the package editable into the cmdbsyncer venv for testing:
cd /path/to/cmdbsyncer
./venv/bin/pip install -e /path/to/cmdbsyncer-enterprise
```

`private_key.pem` and all `*.jwt` files are `.gitignore`-d. Store the
private key in the company password manager — it is the root of trust
for every customer license ever issued.

## Issuing a license

```sh
./tools/issue_license.py \
    --customer "Acme Corp" \
    --license-id CUST-2026-001 \
    --features remote_user ldap_login \
    --days 365 \
    --private-key ./private_key.pem \
    --out license.jwt
```

Claims written into the JWT:

| Claim        | Meaning                                  |
| ------------ | ---------------------------------------- |
| `license_id` | Unique identifier for the license        |
| `customer`   | Customer name (free text)                |
| `features`   | List of feature keys to enable           |
| `iat`        | Issued-at (Unix timestamp, UTC)          |
| `exp`        | Expiry (Unix timestamp, UTC) — enforced  |

Deliver `license.jwt` plus the matching wheel to the customer.

## Building a release wheel

```sh
make build
```

The sdist and wheel land in `dist/`. The embedded `public_key.pem` is
shipped as package data (see `pyproject.toml`).

## Publishing to PyPI

The package itself contains no secrets — only the RSA **public** key is
shipped. Private key and customer licenses are never part of the wheel,
so publishing to the public PyPI is safe. Without a matching license
file the package is a pure no-op.

### One-time setup

1. Create an account on [PyPI](https://pypi.org/account/register/).
2. Generate an API token at *Account settings → API tokens*. Scope it
   to the `cmdbsyncer-enterprise` project once it exists; for the very
   first upload the token must be account-wide.
3. Copy the token into `./.pypirc` (gitignored, `chmod 600`) by
   replacing `pypi-REPLACE_WITH_YOUR_TOKEN`:

   ```ini
   [distutils]
   index-servers =
       pypi

   [pypi]
   username = __token__
   password = pypi-<your-token>
   ```

4. Install the publishing tools into the venv:

   ```sh
   pip install --upgrade build twine
   ```

### Release procedure

1. Bump `version` in `pyproject.toml` (PyPI refuses re-uploads of an
   existing version).
2. Run the full release pipeline:

   ```sh
   make release
   ```

   This runs `clean → build → check → upload → tag` and pushes the
   git tag `v<version>`.

Individual targets are available for partial runs:

```sh
make build     # sdist + wheel into dist/
make check     # twine check dist/*
make upload    # twine upload using ./.pypirc
make tag       # git tag & push v<version>
make clean     # remove build artefacts
make version   # print current version
```

After publication customers install with:

```sh
pip install cmdbsyncer-enterprise
```

and still need their individual `license.jwt` for any feature to
activate.

## Adding a feature

1. **OSS side** — in cmdbsyncer, add a hook call where the feature belongs:

   ```python
   from application.enterprise import run_hook
   result = run_hook('my_feature', arg1, arg2)
   if result:
       ...
   ```

2. **Enterprise side** — implement the handler:

   ```text
   src/cmdbsyncer_enterprise/<area>/<module>.py
   ```

3. Wire it into the feature map in
   `src/cmdbsyncer_enterprise/__init__.py`:

   ```python
   from .<area>.<module> import my_handler

   _feature_hooks = {
       'remote_user': remote_user_login_handler,
       'ldap_login': ldap_login_handler,
       'my_feature': my_handler,
   }
   ```

4. Include `my_feature` in the `--features` list when issuing licenses.

## License

Proprietary — Copyright (c) Kuhn & Ruess GmbH. All rights reserved.
Use requires a valid license agreement.
