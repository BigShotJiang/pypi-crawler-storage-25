"""
Small UI helpers shared across enterprise admin views.

`doc_badge(key)` — returns a `rules.HTML` element that renders the same
"Documentation" badge the OSS views already use, pointing at the
Enterprise user docs. Keeping it centralised means a doc-URL change is
one edit, not a grep-and-replace across ten views.

`intro(title, body)` — renders a soft-coloured explanation block at the
top of a form so admins don't have to read the docs for every field.
Handy on views like "Webhook Policies" where the menu label is not
self-explanatory.
"""
from flask_admin.form import rules
from application.docu_links import docu_links


def doc_badge(key):
    """
    Produce a `rules.HTML` with a "Documentation" pill linking to
    docs.cmdbsyncer.de/<path>. `key` is a key from the OSS `docu_links`
    dict — typically `ent_<feature>`.
    """
    url = docu_links.get(key, docu_links['ent_overview'])
    return rules.HTML(
        f'<i class="fa fa-info"></i>'
        f'<a href="{url}" target="_blank" class="badge badge-light">'
        f'Documentation</a>'
    )


def intro(title, body):
    """
    Render an inline explanation block at the top of a form. Plain HTML
    so it doesn't depend on a specific Bootstrap version — the subtle
    border + muted background works in both BS3/BS4 templates.
    """
    return rules.HTML(
        f'<div style="padding:0.75rem 1rem;margin-bottom:1rem;'
        f'border-left:3px solid #3498db;background:#f6f8fa;'
        f'color:#24292e;">'
        f'<strong>{title}</strong><br>'
        f'<span style="font-size:0.92em;">{body}</span>'
        f'</div>'
    )
