"""
Webhook Signatures (Enterprise feature: `webhook_signatures`).

Upgrades the community `/api/v1/syncer/cron/trigger/<group>` endpoint
with cryptographic request signing (HMAC-SHA256, Stripe/GitHub-style),
replay-protection via a timestamp window, and per-group IP allowlists.

Enforced only for CronGroups that have an enabled `WebhookPolicy`
attached — groups without one keep using the plain token auth from
the OSS endpoint, so the feature can be rolled out group-by-group.
"""
from .verifier import webhook_auth
from .views import register_admin_views

__all__ = ['webhook_auth', 'register_admin_views']
