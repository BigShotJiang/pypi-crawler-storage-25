"""
Admin view for WebhookPolicy — attach a policy per CronGroup, show
the current signing secret (read-only), offer a regenerate action.
"""
from flask import flash
from flask_admin.actions import action
from flask_admin.form import rules
from flask_login import current_user

from application.views.default import DefaultModelView

from .models import WebhookPolicy
from .._ui import doc_badge, intro
from application.views._form_sections import modern_form, section


class WebhookPolicyView(DefaultModelView):
    column_list = ('group', 'enabled', 'require_signature',
                   'timestamp_window_seconds', 'ip_allowlist')
    column_sortable_list = ('group', 'enabled', 'require_signature')

    column_editable_list = ['enabled', 'require_signature']

    form_rules = [
        doc_badge('ent_webhook_signatures'),
        intro(
            'What are Webhook Policies?',
            'A Webhook Policy hardens the trigger endpoint '
            '<code>POST /api/v1/syncer/cron/trigger/&lt;group&gt;</code> for '
            'the cron group you attach it to. Policies let external '
            'systems (GitHub Actions, Jenkins, Netbox hooks, …) fire a '
            'sync without carrying a plain token: requests must be '
            'signed with HMAC-SHA256 over <code>&lt;timestamp&gt;.&lt;body&gt;</code> '
            'and arrive from an allowed source IP. Groups <em>without</em> '
            'a policy keep using the simple token auth from the OSS '
            'endpoint, so you can enable this per group gradually. '
            'See the docs for a ready-to-copy sender script.',
        ),
        *modern_form(
            section('1', 'main', 'Target',
                    'Which cron group this policy hardens.',
                    [rules.Field('group'),
                     rules.Field('enabled')]),
            section('2', 'cond', 'HMAC signature',
                    'Cryptographic request signing and replay protection.',
                    [rules.Field('require_signature'),
                     rules.Field('signing_secret'),
                     rules.Field('timestamp_window_seconds')]),
            section('3', 'out', 'IP allowlist',
                    'Optional: restrict accepted source IPs or CIDRs.',
                    [rules.Field('ip_allowlist')]),
        ),
    ]

    form_widget_args = {
        'signing_secret': {
            'readonly': True,
            'placeholder': 'Generated automatically. Use "Regenerate" to rotate.',
        },
        'timestamp_window_seconds': {
            'placeholder': 'Seconds of clock skew tolerated (default 300)',
        },
        'ip_allowlist': {
            'placeholder': 'e.g. 10.0.0.0/8, 192.168.1.42, 2001:db8::/32  (blank = any)',
        },
    }

    def on_model_change(self, form, model, is_created):
        model.ensure_signing_secret()
        return super().on_model_change(form, model, is_created)

    @action('regenerate_signing_secret',
            'Regenerate signing secret',
            'Rotate the signing secret? All clients using the old secret '
            'will immediately fail signature validation.')
    def action_regenerate_signing_secret(self, ids):
        count = 0
        for policy in WebhookPolicy.objects(id__in=ids):
            policy.regenerate_signing_secret()
            policy.save()
            count += 1
        flash(f'Signing secret regenerated on {count} policy(ies)', 'success')

    def is_accessible(self):
        return current_user.is_authenticated and current_user.has_right('cron')


def register_admin_views(admin):
    admin.add_view(WebhookPolicyView(
        WebhookPolicy, name="Webhook Policies",
        category="Security",
        endpoint="webhook_policies",
        menu_icon_type='fa', menu_icon_value='fa-signature',
    ))
