"""
Per-CronGroup webhook security policy.

Stored in a separate Enterprise-owned collection so the OSS CronGroup
model stays untouched. One policy per CronGroup (unique index).
"""
import secrets
from application import db
from application.models.cron import CronGroup


def _generate_signing_secret():
    return secrets.token_urlsafe(48)


class WebhookPolicy(db.Document):
    """
    Security policy attached to a single CronGroup. When `enabled` is
    true the OSS trigger endpoint routes through the verifier before
    falling through to its own token auth. Missing-policy groups keep
    using the original token-only flow.
    """
    group = db.ReferenceField(document_type=CronGroup, required=True, unique=True,
                              reverse_delete_rule=2)  # CASCADE
    enabled = db.BooleanField(default=True)

    require_signature = db.BooleanField(
        default=True,
        help_text="Reject requests that do not carry a valid "
                  "X-Signature-SHA256 and X-Timestamp header",
    )
    signing_secret = db.StringField()
    timestamp_window_seconds = db.IntField(
        default=300,
        help_text="Reject requests whose X-Timestamp is older (or newer) "
                  "than this many seconds — protects against replay",
    )

    ip_allowlist = db.StringField(
        help_text="Comma-separated IPv4/IPv6 CIDRs. Blank = any source",
    )

    meta = {
        'strict': False,
        'indexes': [{'fields': ['group'], 'unique': True}],
    }

    def ensure_signing_secret(self):
        if not self.signing_secret:
            self.signing_secret = _generate_signing_secret()

    def regenerate_signing_secret(self):
        self.signing_secret = _generate_signing_secret()

    def __str__(self):
        return f"WebhookPolicy({self.group.name if self.group else '?'})"
