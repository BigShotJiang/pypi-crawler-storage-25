"""
Validator hook. Returns one of:

    'ok'   — signature + IP + timestamp all valid; OSS skips its own auth
    dict   — validation failed ({status, error}); OSS returns that verbatim
    None   — no policy attached or the policy is disabled; OSS falls
             back to its own token/user auth

Never raises to the caller — a bug here must not lock out all
webhook callers.
"""
import hashlib
import hmac
import ipaddress
import logging
import time

from mongoengine.errors import DoesNotExist

from .models import WebhookPolicy

log = logging.getLogger(__name__)


def _ip_in_allowlist(remote, allowlist_str):
    """Accept IPv4/IPv6, single addresses or CIDRs. Returns True if empty."""
    allowlist_str = (allowlist_str or '').strip()
    if not allowlist_str:
        return True
    if not remote:
        return False
    try:
        remote_ip = ipaddress.ip_address(remote)
    except ValueError:
        return False
    for entry in allowlist_str.split(','):
        entry = entry.strip()
        if not entry:
            continue
        try:
            net = ipaddress.ip_network(entry, strict=False)
        except ValueError:
            continue
        if remote_ip in net:
            return True
    return False


def _verify_signature(policy, request):
    ts_header = request.headers.get('X-Timestamp')
    sig_header = request.headers.get('X-Signature-SHA256', '')
    if not ts_header or not sig_header:
        return {'ok': False, 'status': 401,
                'error': 'Missing X-Timestamp or X-Signature-SHA256 header'}
    try:
        ts = int(ts_header)
    except ValueError:
        return {'ok': False, 'status': 401,
                'error': 'X-Timestamp is not a unix timestamp'}

    window = int(policy.timestamp_window_seconds or 300)
    if abs(time.time() - ts) > window:
        return {'ok': False, 'status': 401,
                'error': 'X-Timestamp outside the allowed window'}

    if not policy.signing_secret:
        return {'ok': False, 'status': 500,
                'error': 'Signing secret not configured on the server'}

    body = request.get_data() or b''
    signed = f'{ts}.'.encode('utf-8') + body
    expected = hmac.new(
        policy.signing_secret.encode('utf-8'), signed, hashlib.sha256,
    ).hexdigest()
    provided = sig_header.removeprefix('sha256=').strip()
    if not hmac.compare_digest(expected, provided):
        return {'ok': False, 'status': 401, 'error': 'Invalid signature'}
    return 'ok'


def webhook_auth(group, request):
    """
    Called by the OSS trigger endpoint before its own token check.
    Returns 'ok' / dict / None — see module docstring.
    """
    try:
        policy = WebhookPolicy.objects.get(group=group, enabled=True)
    except DoesNotExist:
        return None

    if not _ip_in_allowlist(request.remote_addr, policy.ip_allowlist):
        return {'ok': False, 'status': 403,
                'error': f'Source IP {request.remote_addr} not in allowlist'}

    if policy.require_signature:
        result = _verify_signature(policy, request)
        return result

    # Policy exists (so IP allowlist was just enforced), but signatures are
    # disabled → fall through so the OSS token auth still runs.
    return None
