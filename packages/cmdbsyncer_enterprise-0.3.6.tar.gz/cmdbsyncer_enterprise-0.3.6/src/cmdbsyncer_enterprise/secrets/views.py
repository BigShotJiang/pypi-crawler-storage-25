"""
Admin views for the Secrets Manager.

Registered lazily via `register_admin_views(admin)`, which the OSS app
invokes through the enterprise hook registry. If the license does not
activate `secrets_manager`, `register_admin_views` is never called and
the views/menu entries never exist — community installs stay clean.
"""
from flask_admin.form import rules
from flask_login import current_user
from markupsafe import Markup

from application.views.default import DefaultModelView

from .models import SecretStore, AccountSecretBinding
from .._ui import doc_badge, intro
from application.views._form_sections import modern_form, section


_TYPE_COLOR = {
    'keepass':     '#7b68ee',  # violet
    'lastpass':    '#d93025',  # red
    'vault':       '#1f6feb',  # blue
    'aws_secrets': '#ff9900',  # orange
    'envvar':      '#6c757d',  # grey
}


def _format_type(_v, _c, m, _p):
    """Colored badge so the list view groups visually by provider."""
    if not m.type:
        return ''
    color = _TYPE_COLOR.get(m.type, '#777')
    return Markup(
        f'<span class="badge" style="background:{color};color:#fff;">'
        f'{m.type}</span>'
    )


class SecretStoreView(DefaultModelView):
    """Manage external vaults (KeePass, LastPass, Vault, AWS SM, envvar)."""

    column_list = ('name', 'type', 'enabled', 'description')
    # Default sort by type → same-provider stores cluster together in
    # the list view, addressing the "group by service" UX ask.
    column_default_sort = 'type'
    column_sortable_list = ('name', 'type', 'enabled')
    column_filters = ('type', 'enabled')

    column_formatters = {
        'type': _format_type,
    }

    form_widget_args = {
        'master_password_env': {
            'placeholder': 'KeePass: env var name holding the master password',
        },
        'keyfile_path': {
            'placeholder': 'KeePass: optional keyfile path',
        },
        'kdbx_path': {
            'placeholder': 'KeePass: absolute path to the .kdbx file',
        },
        'lastpass_username': {
            'placeholder': 'LastPass: username the `lpass login` session belongs to',
        },
        'vault_url': {
            'placeholder': 'Vault: e.g. https://vault.example.com:8200',
        },
        'vault_token_env': {
            'placeholder': 'Vault: env var name holding the token',
        },
        'vault_namespace': {
            'placeholder': 'Vault: namespace (Enterprise only)',
        },
        'vault_mount_point': {
            'placeholder': 'Vault: KV mount (default: secret)',
        },
        'vault_kv_version': {
            'placeholder': 'Vault: 1 or 2 (default: 2)',
        },
        'aws_region': {
            'placeholder': 'AWS: e.g. eu-central-1',
        },
        'aws_profile': {
            'placeholder': 'AWS: boto3 profile name (blank = default chain)',
        },
    }

    # Group the fields per provider so admins see immediately which
    # ones apply to the type they just picked. Fields from other
    # providers remain in the form (MongoEngine stores them all on
    # one document) but are collapsed into their own section header
    # so the visual separation is unambiguous.
    form_rules = [
        doc_badge('ent_secrets_manager'),
        intro(
            'Secret Stores',
            'A Secret Store is a pointer to an external vault. Create one per '
            'backend (e.g. one per Vault server, one per .kdbx file) — then '
            'link individual Accounts to it via <em>Account Bindings</em>. '
            'Fill only the fields that belong to the selected <em>type</em>; '
            'the others are ignored. Secret material (master password, '
            'Vault token, AWS keys) is read from env vars — never from the '
            'syncer database.',
        ),
        *modern_form(
            section('1', 'main', 'General',
                    'Identity of this Secret Store and which provider '
                    'backend it points at.',
                    [rules.Field('name'),
                     rules.Field('type'),
                     rules.Field('enabled'),
                     rules.Field('description')]),
            section('2', 'cond', 'KeePass (.kdbx)',
                    'Only used when type = keepass. Master password is '
                    'read from the env var, never stored here.',
                    [rules.Field('kdbx_path'),
                     rules.Field('keyfile_path'),
                     rules.Field('master_password_env')]),
            section('3', 'out', 'HashiCorp Vault',
                    'Only used when type = vault. Token is read from the '
                    'env var named by `vault_token_env`.',
                    [rules.Field('vault_url'),
                     rules.Field('vault_token_env'),
                     rules.Field('vault_namespace'),
                     rules.Field('vault_mount_point'),
                     rules.Field('vault_kv_version')]),
            section('4', 'aux', 'Other Backends',
                    'LastPass (needs the `lpass` CLI logged in as the '
                    'syncer user) and AWS Secrets Manager.',
                    [rules.Field('lastpass_username'),
                     rules.Field('aws_region'),
                     rules.Field('aws_profile')]),
        ),
    ]

    def is_accessible(self):
        return current_user.is_authenticated and current_user.has_right('account')


class AccountSecretBindingView(DefaultModelView):
    """Bind accounts to an entry in a SecretStore."""

    column_list = ('account', 'store', 'entry_path', 'field', 'enabled')
    column_sortable_list = ('account', 'store', 'enabled')
    column_filters = ('enabled', 'field')

    form_widget_args = {
        'entry_path': {
            'placeholder': "KeePass: 'Root/Infra/checkmk-prod' · "
                           "LastPass: entry name (append '#username' for that field) · "
                           "Vault: 'kv/prod/checkmk#password' · "
                           "AWS: 'prod/checkmk#password' · "
                           "envvar: the env var name",
        },
    }

    form_rules = [
        doc_badge('ent_secrets_manager'),
        intro(
            'Account Bindings',
            'Link a cmdbsyncer <em>Account</em> to an entry in a <em>Secret Store</em>. '
            'Once bound, the Account\'s password is pulled from the vault '
            'on every sync; the local encrypted password is ignored. '
            'Delete the binding to fall back to the local password.',
        ),
        *modern_form(
            section('1', 'main', 'Binding',
                    'Which Account is bound to which Secret Store.',
                    [rules.Field('account'),
                     rules.Field('store')]),
            section('2', 'cond', 'Entry',
                    'Path inside the store and which field on the entry '
                    'is the password.',
                    [rules.Field('entry_path'),
                     rules.Field('field')]),
            section('3', 'out', 'Activation',
                    '',
                    [rules.Field('enabled')]),
        ),
    ]

    def is_accessible(self):
        return current_user.is_authenticated and current_user.has_right('account')


def register_admin_views(admin):
    """Hook entrypoint. Called once from the OSS app at startup."""
    admin.add_view(SecretStoreView(
        SecretStore, name="Secret Stores",
        category="Security",
        menu_icon_type='fa', menu_icon_value='fa-lock',
    ))
    admin.add_view(AccountSecretBindingView(
        AccountSecretBinding, name="Account Bindings",
        category="Security",
        menu_icon_type='fa', menu_icon_value='fa-link',
    ))
