"""
Secrets Manager (Enterprise feature: `secrets_manager`).

Lets accounts fetch their password from an external vault instead of the
locally-encrypted Account.password_crypted field. The OSS resolver hook
(`application.helpers.get_account._resolve_password`) calls into us on
every account lookup; when a binding exists, we pull the fresh value
from the configured provider (KeePass today, more later).
"""
from .resolver import resolve_secret
from .views import register_admin_views

__all__ = ['resolve_secret', 'register_admin_views']
