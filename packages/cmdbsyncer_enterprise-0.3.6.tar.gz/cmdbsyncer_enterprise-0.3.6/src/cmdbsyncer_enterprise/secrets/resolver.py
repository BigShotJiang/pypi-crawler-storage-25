"""
OSS-facing resolver hook. Registered as the `resolve_secret` hook so the
OSS `_resolve_password` helper calls us on every account lookup.
"""
import logging

from mongoengine.errors import DoesNotExist

from .models import AccountSecretBinding
from .providers import fetch, SecretResolutionError

log = logging.getLogger(__name__)


def resolve_secret(account):
    """
    Return the externally-stored password for `account`, or None if the
    account is not bound to a store (→ OSS falls back to the local
    encrypted password). Errors are logged and re-raised so a
    misconfigured store doesn't silently serve a stale local password.
    """
    try:
        binding = AccountSecretBinding.objects.get(
            account=account, field='password', enabled=True,
        )
    except DoesNotExist:
        return None

    if not binding.store or not binding.store.enabled:
        log.info(
            "Secret binding for account %s is disabled or missing store",
            account.name,
        )
        return None

    try:
        return fetch(binding.store, binding.entry_path)
    except SecretResolutionError:
        raise
    except Exception as exp:  # pylint: disable=broad-exception-caught
        # Wrap so the OSS side sees one consistent exception type and we
        # don't leak provider-specific details into generic code paths.
        log.exception("Secret resolution failed for account %s", account.name)
        raise SecretResolutionError(
            f"Could not resolve secret for account {account.name!r}: {exp}"
        ) from exp
