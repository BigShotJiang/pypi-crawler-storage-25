"""
Provider helpers that must NOT live in `providers/__init__.py`.

Putting them here avoids the "from . import split_field" back-reference
that turns into a partially-initialized-module error the moment
`providers/__init__.py` eagerly imports a sibling provider that needs
the helper at module scope.
"""


class SecretResolutionError(Exception):
    """Raised when a provider cannot deliver the requested secret."""


def split_field(entry_path, default_field='password'):
    """
    Split "path/to/secret#field" into ("path/to/secret", "field"). For
    providers whose secret is a map (Vault, AWS SM). Without `#…` we
    return `(entry_path, default_field)`.
    """
    if not entry_path:
        return entry_path, default_field
    if '#' in entry_path:
        path, _, field = entry_path.partition('#')
        return path, (field or default_field)
    return entry_path, default_field
