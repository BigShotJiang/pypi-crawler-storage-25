"""
Environment variable provider.

Simplest possible provider: entry_path IS the env var name. Useful for
K8s / Docker deployments where secrets are already mounted as env
vars by the orchestrator — no separate vault needed.
"""
import os


def fetch(_store, entry_path):
    name = (entry_path or '').strip()
    if not name:
        raise RuntimeError("Empty env var name")
    value = os.environ.get(name)
    if value is None:
        raise RuntimeError(f"Env var {name!r} is not set on the syncer host")
    if value == '':
        raise RuntimeError(f"Env var {name!r} is empty")
    return value
