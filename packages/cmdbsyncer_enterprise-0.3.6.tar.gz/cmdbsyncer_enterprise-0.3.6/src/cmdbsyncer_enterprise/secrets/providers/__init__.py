"""
Provider dispatch. Each provider exports a single `fetch(store, entry_path)`
that returns the secret string or raises SecretResolutionError.
"""
from ._utils import SecretResolutionError, split_field  # noqa: F401 — re-exported for callers

from .keepass import fetch as _keepass_fetch
from .lastpass import fetch as _lastpass_fetch
from .vault import fetch as _vault_fetch
from .aws_secrets import fetch as _aws_fetch
from .envvar import fetch as _envvar_fetch


_PROVIDERS = {
    'keepass': _keepass_fetch,
    'lastpass': _lastpass_fetch,
    'vault': _vault_fetch,
    'aws_secrets': _aws_fetch,
    'envvar': _envvar_fetch,
}


def fetch(store, entry_path):
    """Look up the secret in the provider configured on `store`."""
    provider = _PROVIDERS.get(store.type)
    if provider is None:
        raise SecretResolutionError(f"Unknown store type: {store.type}")
    return provider(store, entry_path)
