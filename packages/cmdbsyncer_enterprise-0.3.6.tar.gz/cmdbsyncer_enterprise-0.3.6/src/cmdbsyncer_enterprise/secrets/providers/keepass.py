"""
KeePass (.kdbx) provider.

Opens a kdbx database on every fetch — fine for the sync rates we see,
and it avoids the nasty "kdbx changed on disk, we're still serving the
stale password" class of bugs. A short in-process cache (5 s TTL) keeps
a bulk run that resolves 500 hosts from the same store fast.
"""
import os
import time
import threading
import logging

log = logging.getLogger(__name__)

# (store_id, mtime) -> (timestamp, pykeepass-instance)
_kp_cache = {}
_kp_cache_lock = threading.Lock()
_CACHE_TTL_SECONDS = 5


def _open_kdbx(store):
    """Load and unlock the kdbx for `store`. Returns a PyKeePass handle."""
    # Imported lazily so installs without pykeepass still load the rest
    # of the enterprise package — only customers who actually configure a
    # KeePass store need the dependency.
    try:
        from pykeepass import PyKeePass  # pylint: disable=import-outside-toplevel
    except ImportError as exp:
        raise RuntimeError(
            "pykeepass is required for the KeePass secrets provider. "
            "Install with `pip install pykeepass`."
        ) from exp

    kdbx_path = (store.kdbx_path or '').strip()
    if not kdbx_path or not os.path.isfile(kdbx_path):
        raise RuntimeError(f"KeePass file not found: {kdbx_path!r}")

    master = None
    if store.master_password_env:
        master = os.environ.get(store.master_password_env)
        if master is None:
            raise RuntimeError(
                f"Env var {store.master_password_env!r} for KeePass master "
                f"password is not set on the syncer host"
            )

    keyfile = (store.keyfile_path or '').strip() or None
    if keyfile and not os.path.isfile(keyfile):
        raise RuntimeError(f"KeePass keyfile not found: {keyfile!r}")

    if not master and not keyfile:
        raise RuntimeError(
            "KeePass store needs either a master-password env var or a "
            "keyfile; neither was configured."
        )

    return PyKeePass(kdbx_path, password=master, keyfile=keyfile)


def _get_kdbx(store):
    """Cached kdbx handle, keyed by file mtime so on-disk edits invalidate."""
    kdbx_path = (store.kdbx_path or '').strip()
    if not kdbx_path:
        raise RuntimeError("KeePass store has no kdbx_path")

    try:
        mtime = os.path.getmtime(kdbx_path)
    except OSError as exp:
        raise RuntimeError(f"Cannot stat KeePass file {kdbx_path!r}: {exp}") from exp

    key = (str(store.id), mtime)
    now = time.monotonic()
    with _kp_cache_lock:
        cached = _kp_cache.get(key)
        if cached and now - cached[0] < _CACHE_TTL_SECONDS:
            return cached[1]
        handle = _open_kdbx(store)
        _kp_cache[key] = (now, handle)
        # Drop entries for older mtimes of the same store — the new one
        # supersedes them, and we don't want unbounded memory growth.
        for stale_key in [k for k in _kp_cache if k[0] == key[0] and k[1] != key[1]]:
            _kp_cache.pop(stale_key, None)
        return handle


def fetch(store, entry_path):
    """Return the password of `entry_path` in the given KeePass store."""
    kp = _get_kdbx(store)
    # KeePass paths are slash-separated. Leading/trailing slashes are a
    # very common copy-paste artefact from the KeePass UI.
    parts = [p for p in (entry_path or '').strip('/').split('/') if p]
    if not parts:
        raise RuntimeError("Empty KeePass entry path")

    entry = kp.find_entries(path=parts, first=True)
    if entry is None:
        raise RuntimeError(f"KeePass entry not found at path {entry_path!r}")
    if entry.password is None:
        raise RuntimeError(f"KeePass entry at {entry_path!r} has no password")
    return entry.password
