"""
LastPass provider — wraps the official `lpass` CLI.

No Python SDK exists (the unofficial libraries are unmaintained and
reverse-engineer an undocumented API). The CLI is maintained by GoTo /
LastPass, handles the session encryption correctly, and can be logged
in out-of-band once per host with `lpass login <user>` — exactly what
one wants for an unattended syncer.

No long-lived master password is stored on the syncer side.
"""
import subprocess
import shutil
import logging

log = logging.getLogger(__name__)

_SHORT_TIMEOUT = 10


def _lpass_binary():
    path = shutil.which('lpass')
    if not path:
        raise RuntimeError(
            "lpass CLI not found on PATH. Install from "
            "https://github.com/lastpass/lastpass-cli and run "
            "`lpass login <user>` once as the syncer OS user."
        )
    return path


def _require_logged_in(binary, username):
    """
    `lpass status` prints the logged-in user or exits non-zero. We
    surface a clear error instead of letting `lpass show` return cryptic
    "Could not find …" later.
    """
    result = subprocess.run(  # noqa: S603
        [binary, 'status', '-q'],
        capture_output=True, text=True, timeout=_SHORT_TIMEOUT, check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(
            "lpass is not logged in. Run `lpass login <user>` as the "
            "syncer OS user to create a session."
        )
    if username and username.lower() not in result.stdout.lower():
        raise RuntimeError(
            f"lpass session is for a different user than configured "
            f"({username!r} expected). Re-run `lpass login {username}`."
        )


def fetch(store, entry_path):
    """
    Return the password for `entry_path` from LastPass. The path is the
    LastPass entry name (or unique id). Append `#username` or
    `#<field>` to pick a different field than the default password.
    """
    binary = _lpass_binary()
    _require_logged_in(binary, (store.lastpass_username or '').strip())

    entry, _, field = (entry_path or '').strip().partition('#')
    if not entry:
        raise RuntimeError("Empty LastPass entry")

    if field and field != 'password':
        cmd = [binary, 'show', '--field', field, entry]
    else:
        cmd = [binary, 'show', '--password', entry]

    result = subprocess.run(  # noqa: S603
        cmd, capture_output=True, text=True, timeout=_SHORT_TIMEOUT, check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"lpass show failed for {entry!r}: "
            f"{result.stderr.strip() or result.stdout.strip() or 'unknown error'}"
        )
    value = result.stdout.rstrip('\n')
    if not value:
        raise RuntimeError(f"LastPass entry {entry!r} returned an empty value")
    return value
