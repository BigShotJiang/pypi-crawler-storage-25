"""
HashiCorp Vault provider (KV v1 and v2).

Uses `hvac`, the canonical Python client. Token is read from a named
env var, never from the DB. Namespaces (Vault Enterprise) are
supported via `vault_namespace`.
"""
import os
import threading
import logging

from ._utils import split_field

log = logging.getLogger(__name__)

_client_lock = threading.Lock()
_client_cache = {}


def _get_client(store):
    """
    One hvac.Client per (store_id, token). Tokens rotate (e.g. renewal
    via AppRole), so we key on the token value too — picking up a
    refreshed env var without a restart.
    """
    try:
        import hvac  # pylint: disable=import-outside-toplevel
    except ImportError as exp:
        raise RuntimeError(
            "hvac is required for the Vault secrets provider. "
            "Install with `pip install hvac`."
        ) from exp

    url = (store.vault_url or '').strip()
    if not url:
        raise RuntimeError("Vault store has no vault_url configured")

    token_env = (store.vault_token_env or '').strip()
    if not token_env:
        raise RuntimeError("Vault store has no vault_token_env configured")
    token = os.environ.get(token_env)
    if not token:
        raise RuntimeError(
            f"Env var {token_env!r} for the Vault token is not set on the "
            f"syncer host"
        )

    namespace = (store.vault_namespace or '').strip() or None
    key = (str(store.id), token, namespace)
    with _client_lock:
        client = _client_cache.get(key)
        if client is not None and client.is_authenticated():
            return client
        client = hvac.Client(url=url, token=token, namespace=namespace)
        if not client.is_authenticated():
            raise RuntimeError("Vault token rejected — authentication failed")
        _client_cache[key] = client
        # Evict older tokens for the same store/namespace so rotation
        # doesn't keep stale clients alive.
        for stale_key in [
            k for k in _client_cache
            if k[0] == key[0] and k[2] == key[2] and k[1] != key[1]
        ]:
            _client_cache.pop(stale_key, None)
        return client


def fetch(store, entry_path):
    client = _get_client(store)

    mount_point = (store.vault_mount_point or '').strip() or 'secret'
    kv_version = store.vault_kv_version or 2

    path, field = split_field(entry_path, default_field='password')
    if not path:
        raise RuntimeError("Empty Vault path")

    # hvac's KV v2 path strips leading slashes; match the UX users see in
    # the Vault UI by accepting either form.
    path = path.lstrip('/')

    try:
        if kv_version == 1:
            resp = client.secrets.kv.v1.read_secret(
                path=path, mount_point=mount_point,
            )
            data = resp['data']
        else:
            resp = client.secrets.kv.v2.read_secret_version(
                path=path, mount_point=mount_point, raise_on_deleted_version=True,
            )
            data = resp['data']['data']
    except Exception as exp:
        raise RuntimeError(
            f"Vault read failed at {mount_point}/{path}: {exp}"
        ) from exp

    if field not in data:
        raise RuntimeError(
            f"Vault secret at {mount_point}/{path} has no field "
            f"{field!r} (available: {sorted(data.keys())})"
        )
    value = data[field]
    if value is None or value == '':
        raise RuntimeError(f"Vault field {field!r} is empty at {path}")
    return str(value)
