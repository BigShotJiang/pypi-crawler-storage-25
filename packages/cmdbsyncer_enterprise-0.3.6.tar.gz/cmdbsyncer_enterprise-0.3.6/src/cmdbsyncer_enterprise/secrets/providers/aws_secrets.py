"""
AWS Secrets Manager provider.

Uses boto3 and the standard AWS credential chain (env vars, EC2/ECS
instance role, SSO, ~/.aws/credentials). No credentials are stored in
the syncer DB; a profile name can be set on the store when multiple
profiles are needed on one host.

Secrets can be plain strings or JSON documents. For JSON, append
`#<field>` to the entry path to pick a key; default `password`.
"""
import json
import logging

from ._utils import split_field

log = logging.getLogger(__name__)


def _get_client(store):
    try:
        import boto3  # pylint: disable=import-outside-toplevel
    except ImportError as exp:
        raise RuntimeError(
            "boto3 is required for the AWS Secrets Manager provider. "
            "Install with `pip install boto3`."
        ) from exp

    region = (store.aws_region or '').strip() or None
    profile = (store.aws_profile or '').strip() or None
    session = boto3.session.Session(profile_name=profile, region_name=region)
    return session.client('secretsmanager')


def fetch(store, entry_path):
    client = _get_client(store)

    secret_id, field = split_field(entry_path, default_field='password')
    if not secret_id:
        raise RuntimeError("Empty AWS Secrets Manager SecretId")

    try:
        resp = client.get_secret_value(SecretId=secret_id)
    except Exception as exp:
        raise RuntimeError(
            f"AWS Secrets Manager read failed for {secret_id!r}: {exp}"
        ) from exp

    # `SecretString` is the common case. `SecretBinary` is rare — decode
    # it as utf-8 and treat like a string so operators don't have to
    # remember which one they used.
    raw = resp.get('SecretString')
    if raw is None and resp.get('SecretBinary') is not None:
        raw = resp['SecretBinary'].decode('utf-8')
    if raw is None:
        raise RuntimeError(f"AWS secret {secret_id!r} has no value")

    # If the blob looks like JSON and we were asked for a specific
    # field, parse it. A plain string without a `#field` suffix is
    # returned as-is.
    stripped = raw.lstrip()
    if stripped.startswith('{'):
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            data = None
        if isinstance(data, dict):
            if field not in data:
                raise RuntimeError(
                    f"AWS secret {secret_id!r} has no field {field!r} "
                    f"(available: {sorted(data.keys())})"
                )
            value = data[field]
            if value is None or value == '':
                raise RuntimeError(
                    f"AWS secret field {field!r} is empty"
                )
            return str(value)
    return raw
