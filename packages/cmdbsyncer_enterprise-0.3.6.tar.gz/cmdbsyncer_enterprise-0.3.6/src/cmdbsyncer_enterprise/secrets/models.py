"""
Mongo models owned by the enterprise secrets manager.

Kept in their own collections so community installs — which never import
this module — stay untouched. Account-side, we only reference the
Account by ObjectId; no schema change on the OSS Account model.

Fields are grouped per provider on the same document rather than split
into subclasses, because Flask-Admin renders EmbeddedDocuments poorly
and admins rarely configure more than a handful of stores.
"""
from application import db
from application.models.account import Account


STORE_TYPES = [
    ('keepass', 'KeePass (.kdbx file)'),
    ('lastpass', 'LastPass (via lpass CLI)'),
    ('vault', 'HashiCorp Vault (KV v1/v2)'),
    ('aws_secrets', 'AWS Secrets Manager'),
    ('envvar', 'Environment variable'),
]


class SecretStore(db.Document):
    """
    One external vault instance the syncer knows about. A store is the
    "where" (file path, server URL, …); the Binding is the "which entry".
    """
    name = db.StringField(required=True, unique=True)
    type = db.StringField(choices=STORE_TYPES, required=True)
    enabled = db.BooleanField(default=True)
    description = db.StringField()

    # KeePass
    kdbx_path = db.StringField()
    keyfile_path = db.StringField()
    # Name of the env var holding the master password. We deliberately do
    # NOT persist the master password in the DB — the whole point of using
    # KeePass is that the syncer's DB is not the source of truth.
    master_password_env = db.StringField()

    # LastPass (uses the official `lpass` CLI; user must be logged in on
    # the syncer host out-of-band via `lpass login <user>`).
    lastpass_username = db.StringField()

    # HashiCorp Vault
    vault_url = db.StringField()
    vault_token_env = db.StringField()
    vault_namespace = db.StringField()
    vault_mount_point = db.StringField()  # default 'secret'
    vault_kv_version = db.IntField()      # 1 or 2, default 2

    # AWS Secrets Manager
    aws_region = db.StringField()
    aws_profile = db.StringField()        # boto3 profile name; blank = default chain

    meta = {'strict': False}

    def __str__(self):
        return f"{self.name} ({self.type})"


class AccountSecretBinding(db.Document):
    """
    "Account X pulls its password from Store Y at path Z."

    `entry_path` is provider-specific. For providers whose secret is a
    map (Vault, AWS Secrets Manager), append `#<field>` to pick a field
    — e.g. `kv/prod/checkmk#password`. Without `#…` the default key is
    `password`.
    """
    account = db.ReferenceField(document_type=Account, required=True,
                                reverse_delete_rule=2)  # CASCADE
    store = db.ReferenceField(document_type=SecretStore, required=True)
    entry_path = db.StringField(
        required=True,
        help_text="Path inside the store. For Vault/AWS append '#field' "
                  "to pick a JSON key; default is 'password'."
    )
    field = db.StringField(choices=[('password', 'password')],
                           default='password')
    enabled = db.BooleanField(default=True)

    meta = {
        'strict': False,
        'indexes': [
            {'fields': ['account', 'field'], 'unique': True},
        ],
    }

    def __str__(self):
        return f"{self.account} -> {self.store}:{self.entry_path}"
