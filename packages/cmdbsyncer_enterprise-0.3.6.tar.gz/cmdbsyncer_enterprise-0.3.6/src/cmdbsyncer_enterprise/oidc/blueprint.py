"""
Flask blueprint for OIDC login / callback.

Config keys expected on the OSS `app.config` (set in `local_config.py`):

    OIDC_LOGIN          = True                 # master switch
    OIDC_ACCOUNT        = 'entra-id'           # name of a Syncer Account:
                                               #   address  = OIDC issuer URL
                                               #   username = client id
                                               #   password = client secret
    OIDC_SCOPES         = ['openid', 'email', 'profile']
    OIDC_EMAIL_CLAIM    = 'email'              # claim holding the user's email
    OIDC_NAME_CLAIM     = 'name'               # claim for the display name
    OIDC_GROUPS_CLAIM   = 'groups'             # claim carrying group ids
    OIDC_REQUIRED_GROUP = ''                   # optional gate
    OIDC_AUTO_CREATE    = True                 # auto-create local user on first login
    OIDC_ROLE_MAPPING   = {                    # group → perms
        'cmdbsyncer-admins': {'global_admin': True},
        'cmdbsyncer-ops':    {'roles': ['host', 'log']},
    }

Implementation uses `requests` for the HTTP dance (discovery, token exchange,
userinfo) and `joserfc` for JWT validation of the ID token — no authlib.
"""
import logging
import secrets
import threading
import time
from datetime import datetime, timedelta
from urllib.parse import urlencode

import requests
from flask import (
    Blueprint, abort, current_app, flash, redirect, request, session, url_for,
)
from flask_login import login_user
from joserfc import jwt
from joserfc.errors import JoseError
from joserfc.jwk import KeySet

from application.helpers.audit import audit
from application.helpers.get_account import (
    AccountNotFoundError,
    get_account_by_name,
)
from application.models.user import User

log = logging.getLogger(__name__)

OIDC_BP = Blueprint('oidc', __name__, url_prefix='/oidc')

_SESSION_STATE = 'oidc_state'
_SESSION_NONCE = 'oidc_nonce'

# Per-issuer cache of the discovery document + JWKS. The JWKS rotates at the
# IdP so we cap both with a short TTL and invalidate on verification failure.
_DISCOVERY_TTL = 3600
_JWKS_TTL = 900
_lock = threading.Lock()
_discovery_cache = {}   # issuer -> (ts, doc)
_jwks_cache = {}        # jwks_uri -> (ts, KeySet)


def _oidc_account(config):
    """Resolve the Syncer Account holding the OIDC issuer + client creds.

    Returns a dict with keys ``issuer`` (URL), ``client_id`` and
    ``client_secret`` — the three values OIDC needs to talk to the
    identity provider. Runs through ``get_account_by_name`` so an
    Enterprise Secrets Manager binding applies transparently.
    """
    name = (config.get('OIDC_ACCOUNT') or '').strip()
    if not name:
        raise RuntimeError("OIDC_ACCOUNT is not set in local_config.py")
    try:
        account = get_account_by_name(name)
    except AccountNotFoundError as exc:
        raise RuntimeError(
            f"OIDC_ACCOUNT={name!r} — Account not found or disabled"
        ) from exc
    issuer = (account.get('address') or '').strip().rstrip('/')
    client_id = (account.get('username') or '').strip()
    client_secret = account.get('password') or ''
    if not issuer or not client_id or not client_secret:
        raise RuntimeError(
            f"OIDC_ACCOUNT={name!r} must set Address (issuer URL), "
            f"Username (client id) and Password (client secret)"
        )
    return {
        'issuer': issuer,
        'client_id': client_id,
        'client_secret': client_secret,
    }


def _discovery(issuer):
    """Return the discovery document for `issuer`, cached for an hour."""
    issuer = issuer.rstrip('/')
    with _lock:
        cached = _discovery_cache.get(issuer)
        if cached and time.monotonic() - cached[0] < _DISCOVERY_TTL:
            return cached[1]
    url = f'{issuer}/.well-known/openid-configuration'
    resp = requests.get(url, timeout=10)
    resp.raise_for_status()
    doc = resp.json()
    with _lock:
        _discovery_cache[issuer] = (time.monotonic(), doc)
    return doc


def _jwks(jwks_uri, force=False):
    """Return a joserfc KeySet for `jwks_uri`, cached 15 minutes."""
    with _lock:
        cached = _jwks_cache.get(jwks_uri)
        if not force and cached and time.monotonic() - cached[0] < _JWKS_TTL:
            return cached[1]
    resp = requests.get(jwks_uri, timeout=10)
    resp.raise_for_status()
    keyset = KeySet.import_key_set(resp.json())
    with _lock:
        _jwks_cache[jwks_uri] = (time.monotonic(), keyset)
    return keyset


def _oidc_config(config):
    """Read the OIDC Account + app.config into the flat dict this module uses."""
    account = _oidc_account(config)
    return {
        **account,
        'scopes': config.get('OIDC_SCOPES') or ['openid', 'email', 'profile'],
    }


@OIDC_BP.route('/login')
def login():
    """Start the authorization-code flow."""
    if not current_app.config.get('OIDC_LOGIN'):
        flash('OIDC login is disabled', 'danger')
        return redirect(url_for('auth.login'))

    try:
        params = _oidc_config(current_app.config)
        doc = _discovery(params['issuer'])
    except Exception as exp:  # pylint: disable=broad-exception-caught
        log.exception("OIDC discovery failed")
        audit('user.login.failure', outcome='failure',
              metadata={'method': 'oidc', 'reason': 'setup_error'})
        flash(f'OIDC configuration error: {exp}', 'danger')
        return redirect(url_for('auth.login'))

    state = secrets.token_urlsafe(32)
    nonce = secrets.token_urlsafe(32)
    session[_SESSION_STATE] = state
    session[_SESSION_NONCE] = nonce

    query = urlencode({
        'response_type': 'code',
        'client_id': params['client_id'],
        'redirect_uri': url_for('oidc.callback', _external=True),
        'scope': ' '.join(params['scopes']),
        'state': state,
        'nonce': nonce,
    })
    return redirect(f"{doc['authorization_endpoint']}?{query}")


def _exchange_code(params, doc, code):
    """POST to the token endpoint and return the parsed response."""
    resp = requests.post(
        doc['token_endpoint'],
        data={
            'grant_type': 'authorization_code',
            'code': code,
            'redirect_uri': url_for('oidc.callback', _external=True),
            'client_id': params['client_id'],
            'client_secret': params['client_secret'],
        },
        timeout=10,
    )
    resp.raise_for_status()
    return resp.json()


def _verify_id_token(params, doc, id_token, nonce):
    """Validate an ID token against the IdP's JWKS and expected claims.

    Retries once against a refreshed JWKS on signature failure — the IdP may
    have rotated keys since we last fetched.
    """
    jwks_uri = doc['jwks_uri']
    for attempt in (0, 1):
        keyset = _jwks(jwks_uri, force=bool(attempt))
        try:
            token = jwt.decode(id_token, keyset)
            break
        except JoseError:
            if attempt:
                raise
    claims = token.claims
    registry = jwt.JWTClaimsRegistry(
        iss={'essential': True, 'value': doc.get('issuer', params['issuer'])},
        aud={'essential': True, 'value': params['client_id']},
        exp={'essential': True},
        iat={'essential': True},
    )
    registry.validate(claims)
    if nonce and claims.get('nonce') != nonce:
        raise JoseError("id_token nonce mismatch")
    return claims


def _userinfo(doc, access_token):
    """Call the userinfo endpoint with the bearer access token."""
    endpoint = doc.get('userinfo_endpoint')
    if not endpoint or not access_token:
        return {}
    resp = requests.get(
        endpoint,
        headers={'Authorization': f'Bearer {access_token}'},
        timeout=10,
    )
    if resp.status_code != 200:
        return {}
    try:
        return resp.json() or {}
    except ValueError:
        return {}


@OIDC_BP.route('/callback')
def callback():  # pylint: disable=too-many-return-statements,too-many-branches,too-many-locals
    config = current_app.config

    error = request.args.get('error')
    if error:
        audit('user.login.failure', outcome='failure',
              metadata={'method': 'oidc', 'reason': 'idp_error',
                        'error': error,
                        'description': request.args.get('error_description')})
        flash(f'OIDC login failed: {error}', 'danger')
        return redirect(url_for('auth.login'))

    code = request.args.get('code')
    state = request.args.get('state')
    expected_state = session.pop(_SESSION_STATE, None)
    nonce = session.pop(_SESSION_NONCE, None)

    if not code or not state or not expected_state or state != expected_state:
        audit('user.login.failure', outcome='failure',
              metadata={'method': 'oidc', 'reason': 'state_mismatch'})
        flash('OIDC login failed — state mismatch', 'danger')
        return redirect(url_for('auth.login'))

    try:
        params = _oidc_config(config)
        doc = _discovery(params['issuer'])
        token = _exchange_code(params, doc, code)
    except Exception as exp:  # pylint: disable=broad-exception-caught
        log.info("OIDC token exchange failed: %s", exp)
        audit('user.login.failure', outcome='failure',
              metadata={'method': 'oidc', 'reason': 'token_exchange_failed'})
        flash('OIDC login failed', 'danger')
        return redirect(url_for('auth.login'))

    id_token = token.get('id_token')
    if not id_token:
        audit('user.login.failure', outcome='failure',
              metadata={'method': 'oidc', 'reason': 'no_id_token'})
        flash('OIDC login failed — no id_token returned', 'danger')
        return redirect(url_for('auth.login'))

    try:
        claims = _verify_id_token(params, doc, id_token, nonce)
    except JoseError as exp:
        log.info("OIDC id_token verification failed: %s", exp)
        audit('user.login.failure', outcome='failure',
              metadata={'method': 'oidc', 'reason': 'id_token_invalid'})
        flash('OIDC login failed — id_token invalid', 'danger')
        return redirect(url_for('auth.login'))

    # Merge userinfo claims (some IdPs put groups only there, not in id_token).
    try:
        info = _userinfo(doc, token.get('access_token'))
    except Exception:  # pylint: disable=broad-exception-caught
        info = {}
    if info:
        merged = dict(claims)
        merged.update(info)
        claims = merged

    email_claim = config.get('OIDC_EMAIL_CLAIM', 'email')
    email = (claims.get(email_claim) or '').lower()
    if not email:
        audit('user.login.failure', outcome='failure',
              metadata={'method': 'oidc', 'reason': 'no_email_claim'})
        flash('OIDC token has no email claim', 'danger')
        return redirect(url_for('auth.login'))

    groups = claims.get(config.get('OIDC_GROUPS_CLAIM', 'groups')) or []
    if isinstance(groups, str):
        groups = [groups]
    groups = [str(g) for g in groups]

    required = (config.get('OIDC_REQUIRED_GROUP') or '').strip()
    if required and required not in groups:
        audit('user.login.failure', outcome='failure',
              actor_name=email,
              metadata={'method': 'oidc',
                        'reason': 'required_group_missing',
                        'required_group': required})
        flash('Access denied — you are not in the required group', 'danger')
        return redirect(url_for('auth.login'))

    user_result = User.objects(email=email, disabled__ne=True)
    if user_result:
        user = user_result[0]
        is_new = False
    elif config.get('OIDC_AUTO_CREATE', True):
        user = User(
            email=email,
            name=claims.get(config.get('OIDC_NAME_CLAIM', 'name')) or email,
            date_added=datetime.now(),
        )
        is_new = True
    else:
        audit('user.login.failure', outcome='failure',
              actor_name=email,
              metadata={'method': 'oidc',
                        'reason': 'no_local_user_and_autocreate_off'})
        flash('Access denied — no local user and auto-create is off', 'danger')
        return redirect(url_for('auth.login'))

    if _apply_role_mapping(user, config.get('OIDC_ROLE_MAPPING') or {}, groups) \
            or is_new:
        user.save()

    session.clear()
    login_user(
        user, remember=False,
        duration=timedelta(hours=(config.get('ADMIN_SESSION_HOURS') or 8)),
    )
    user.last_login = datetime.now()
    user.save()
    audit('user.login.success',
          actor_type='user',
          actor_id=str(user.id),
          actor_name=user.email,
          metadata={'method': 'oidc', 'idp': params['issuer']})
    return redirect(url_for('admin.index'))


def _apply_role_mapping(user, mapping, groups):
    """Same union-of-group-permissions pattern as LDAP role mapping."""
    if not mapping:
        return False
    group_set = {g.lower() for g in groups}
    new_roles, new_api_roles, global_admin = set(), set(), False
    for group_key, perms in mapping.items():
        if group_key.lower() not in group_set:
            continue
        new_roles.update(perms.get('roles', []))
        new_api_roles.update(perms.get('api_roles', []))
        if perms.get('global_admin'):
            global_admin = True
    changed = False
    if set(user.roles or []) != new_roles:
        user.roles = sorted(new_roles)
        changed = True
    if set(user.api_roles or []) != new_api_roles:
        user.api_roles = sorted(new_api_roles)
        changed = True
    if bool(user.global_admin) != global_admin:
        user.global_admin = global_admin
        changed = True
    return changed


def register_blueprint(app):
    """Attach the blueprint to the OSS Flask app. Idempotent."""
    if 'oidc' in app.blueprints:
        return
    app.register_blueprint(OIDC_BP)
    log.info("OIDC login blueprint registered at /oidc/")
