"""
OpenID Connect (Enterprise feature: `oidc_login`).

Native OIDC client that lets CMDBsyncer talk to Azure AD / Entra ID,
Okta, Keycloak, Google Workspace, Auth0 or any other OIDC-compliant
IdP without needing an Apache/Nginx `mod_auth_openidc` proxy in
front.

Exposes:

    /oidc/login     — kicks off the authorization-code flow
    /oidc/callback  — IdP redirects back here, we exchange the code
                      for tokens and log the user in

Discovery-URL-based config; no hand-rolled JWKS handling. Group/role
mapping reuses the same `*_ROLE_MAPPING` pattern the LDAP module
uses so admins have one mental model.
"""
from application.helpers.plugins import register_plugin_type

from .blueprint import register_blueprint

__all__ = ['register_blueprint']


# OIDC issuer + client credentials live on a Syncer Account of this type.
register_plugin_type(
    'oidc_idp',
    'OIDC identity provider',
    description=('Outbound OIDC client credentials: Address is the '
                 'issuer discovery URL, Username is the client id, '
                 'Password is the client secret.'),
    account_presets={'address': 'https://login.microsoftonline.com/<tenant>/v2.0'},
    account_custom_field_presets={},
)
