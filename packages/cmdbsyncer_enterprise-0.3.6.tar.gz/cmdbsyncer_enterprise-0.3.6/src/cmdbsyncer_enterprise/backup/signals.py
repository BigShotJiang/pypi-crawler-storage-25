"""
Keep an auto-managed CronGroup in sync with each BackupConfig.

Every BackupConfig produces a protected CronGroup named
``Backup: <config-name>``. The group has a single GroupEntry that
calls the per-config task ``enterprise-backup_run:<config-name>``.
Operators see the group like any other cron in the UI; they can
pause it (toggle ``enabled``) or move its time window, but cannot
delete it directly — deletion is driven by deleting the BackupConfig
itself, which removes the protection flag and then the group.
"""
import logging

from mongoengine import signals

from application.models.cron import CronGroup, GroupEntry

from .cron_register import ensure_registered, unregister, _task_name

log = logging.getLogger(__name__)

GROUP_NAME_PREFIX = 'Backup: '


def _group_name(config_name):
    return f'{GROUP_NAME_PREFIX}{config_name}'


def _sync_cron_group(config):
    """Create or update the protected CronGroup for this BackupConfig."""
    ensure_registered(config.name)

    name = _group_name(config.name)
    group = CronGroup.objects(name=name).first()
    if group is None:
        group = CronGroup(name=name)

    group.protected = True
    group.enabled = bool(config.enabled and config.schedule_enabled)
    group.interval = config.interval or 'daily'
    group.custom_interval_in_minutes = config.custom_interval_in_minutes
    group.timerange_from = config.timerange_from or '0'
    group.timerange_to = config.timerange_to or '24'

    job = GroupEntry(name=config.name, command=_task_name(config.name))
    group.jobs = [job]
    group.save()


def _drop_cron_group(config_name):
    """Remove the protected group and unregister the task."""
    group = CronGroup.objects(name=_group_name(config_name)).first()
    if group is not None:
        # Bypass the protected-delete guard: the owning BackupConfig is
        # going away, so the group must follow.
        group.protected = False
        group.save()
        group.delete()
    unregister(config_name)


def _handle_post_save(sender, document, **kwargs):  # pylint: disable=unused-argument
    try:
        _sync_cron_group(document)
    except Exception:  # pylint: disable=broad-exception-caught
        log.exception("Failed to sync CronGroup for BackupConfig %s",
                      document.name)


def _handle_pre_delete(sender, document, **kwargs):  # pylint: disable=unused-argument
    try:
        _drop_cron_group(document.name)
    except Exception:  # pylint: disable=broad-exception-caught
        log.exception("Failed to drop CronGroup for BackupConfig %s",
                      document.name)


def connect_signals():
    """Wire mongoengine signals on BackupConfig. Idempotent."""
    from .models import BackupConfig  # local import: DB must be ready
    signals.post_save.connect(_handle_post_save, sender=BackupConfig)
    signals.pre_delete.connect(_handle_pre_delete, sender=BackupConfig)
