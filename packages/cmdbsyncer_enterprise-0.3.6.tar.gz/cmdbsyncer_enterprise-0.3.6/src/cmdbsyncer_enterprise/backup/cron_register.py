"""
Register one cronjob *per* BackupConfig as a task family.

Each BackupConfig ``foo`` becomes a separate cronjob named
``enterprise-backup_run:foo``. Two consequences:

* The CronGroup task dropdown lists every backup individually, so
  there's no need for the old "Account.name == BackupConfig.name"
  trick to identify which config to run.
* The auto-managed CronGroup ``Backup: foo`` references the matching
  task by name and needs no Account at all.

Tasks are registered in three places:

* on app boot (``register_all_known``) — to populate the in-memory
  registry from existing BackupConfigs in the DB,
* on save of a BackupConfig (``ensure_registered``) — so a freshly
  created backup is immediately runnable without restart,
* on rename — the old name is unregistered, the new one added.
"""
import logging

from application import cron_register
from application.helpers.cron import register_cronjob

from .runner import run_backup

log = logging.getLogger(__name__)

TASK_PREFIX = 'enterprise-backup_run:'


def _task_name(config_name):
    return f'{TASK_PREFIX}{config_name}'


def _make_runner(config_name):
    """Return a closure bound to a specific BackupConfig name."""
    def _task(account=None, debug=False):  # pylint: disable=unused-argument
        log.info("Running backup config %s", config_name)
        run_backup(config_name)
    _task.__name__ = f'backup_run_{config_name}'
    return _task


def ensure_registered(config_name):
    """Idempotently register the per-config cronjob task."""
    register_cronjob(_task_name(config_name), _make_runner(config_name))


def unregister(config_name):
    """Drop a per-config task — used when a BackupConfig is renamed/deleted."""
    cron_register.pop(_task_name(config_name), None)


def register_all_known():
    """Populate the cron registry from every existing BackupConfig.

    Called once at app boot, after the DB connection is up. Safe to
    re-invoke (registration is idempotent).
    """
    from .models import BackupConfig  # local import: DB must be ready
    for cfg in BackupConfig.objects.only('name'):
        ensure_registered(cfg.name)
