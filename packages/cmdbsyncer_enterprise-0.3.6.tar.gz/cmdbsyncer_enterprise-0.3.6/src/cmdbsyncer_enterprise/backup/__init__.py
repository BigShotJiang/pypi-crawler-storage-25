"""
Scheduled Backups (Enterprise feature: `scheduled_backup`).

Encrypted Mongo dumps pushed to S3-compatible object storage on a
schedule. Supports AWS S3, GCS (via S3-compat), Azure Blob, MinIO,
Backblaze B2, Wasabi, and DigitalOcean Spaces through a single
boto3 codepath (any endpoint that speaks the S3 API).

Features:
- `mongodump` → gzip → optional GPG encryption → S3 upload
- Retention policy: auto-delete backups older than N days
- CLI `cmdbsyncer enterprise backup run|restore|list`
- Cron integration: a BackupConfig acts as a standard cronjob task
- Emits an audit event `backup.succeeded` / `backup.failed` for every
  run, notifies via the notifications feature (if co-licensed)
"""
from application.helpers.plugins import register_plugin_type

from .models import BackupConfig, BackupHistory
from .runner import run_backup, list_backups, restore_backup
from .views import register_admin_views
from .cron_register import register_all_known
from .signals import connect_signals

__all__ = [
    'BackupConfig', 'BackupHistory',
    'run_backup', 'list_backups', 'restore_backup',
    'register_admin_views', 'register_all_known', 'connect_signals',
]


# Backup destinations live on a Syncer Account of this plugin type.
register_plugin_type(
    's3_storage',
    'S3-compatible object storage',
    description=('Outbound credentials for AWS S3, GCS, Azure Blob, '
                 'MinIO, B2, Wasabi, DO Spaces or any other S3 API.'),
    account_presets={
        # Blank for AWS; set for non-AWS S3-compat endpoints.
        'address': '',
    },
    account_custom_field_presets={
        'region': '',   # AWS region, e.g. eu-central-1
    },
)
