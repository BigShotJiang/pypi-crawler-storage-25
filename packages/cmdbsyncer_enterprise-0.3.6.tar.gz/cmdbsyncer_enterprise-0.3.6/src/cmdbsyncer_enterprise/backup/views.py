"""
Admin views for BackupConfig (editable) and BackupHistory (read-only).
"""
from datetime import datetime

from flask import flash
from flask_admin.actions import action
from flask_admin.form import rules
from flask_login import current_user
from markupsafe import Markup

from application.views._form_fields import AccountSelectField
from application.views.default import DefaultModelView

from .models import BackupConfig, BackupHistory
from .runner import run_backup
from .._ui import doc_badge, intro
from application.views._form_sections import modern_form, section


def _format_status(_v, _c, m, _p):
    color = {'success': '#27ae60', 'running': '#2980b9',
             'failure': '#c0392b'}.get(m.status, '#999')
    return Markup(
        f'<span class="badge" style="background:{color};color:#fff;">'
        f'{m.status}</span>'
    )


def _format_dt(_v, _c, m, p):
    value = getattr(m, p)
    return value.strftime('%Y-%m-%d %H:%M:%S UTC') if value else ''


def _format_size(_v, _c, m, _p):
    if not m.size_bytes:
        return ''
    size = m.size_bytes
    for unit in ('B', 'KB', 'MB', 'GB'):
        if size < 1024:
            return f'{size:.1f} {unit}'
        size /= 1024
    return f'{size:.1f} TB'


class BackupConfigView(DefaultModelView):
    column_list = ('name', 'enabled', 'destination_type', 'bucket',
                   'local_path', 'encryption', 'retention_days',
                   'interval')
    column_sortable_list = ('name', 'enabled', 'destination_type', 'bucket')

    form_rules = [
        doc_badge('ent_scheduled_backup'),
        intro(
            'Backup Configurations',
            'Encrypted <code>mongodump</code> snapshots pushed to an '
            'S3-compatible object store (AWS, GCS, Azure, MinIO, B2, '
            'Wasabi, DO Spaces) or written to a local filesystem path '
            '(mount a CIFS/NFS share at the OS level and point '
            '<code>local_path</code> at it). The schedule below is '
            'auto-managed: a protected CronGroup <code>Backup: '
            '&lt;name&gt;</code> is created on save and removed on '
            'delete. Credentials live on the linked Account record.',
        ),
        *modern_form(
            section('1', 'main', 'General',
                    'Identity, activation and destination kind.',
                    [rules.Field('name'),
                     rules.Field('enabled'),
                     rules.Field('description'),
                     rules.Field('destination_type')]),
            section('2', 'cond', 'Local / Network Share',
                    'Only used when destination_type = local. Mount a '
                    'CIFS/NFS share at the OS level and point here.',
                    [rules.Field('local_path')]),
            section('3', 'out', 'Object Storage',
                    'Only used when destination_type = s3. Pick a '
                    'Syncer Account for the S3 credentials: Address '
                    '= endpoint URL (blank for AWS default), Username '
                    '= access key (blank for the default credential '
                    'chain), Password = secret access key; an optional '
                    'custom field `region` overrides the AWS region.',
                    [rules.Field('bucket'),
                     rules.Field('prefix'),
                     rules.Field('account'),
                     rules.Field('s3_sse')]),
            section('4', 'aux', 'Encryption & Retention',
                    'GPG client-side encryption (recipient key must be in '
                    'the syncer user\'s keyring) and rotation policy.',
                    [rules.Field('compression'),
                     rules.Field('encryption'),
                     rules.Field('gpg_recipient'),
                     rules.Field('retention_days')]),
            section('5', 'cond', 'Schedule',
                    'When the backup runs. The CronGroup '
                    '<code>Backup: &lt;name&gt;</code> mirrors these '
                    'fields automatically.',
                    [rules.Field('schedule_enabled'),
                     rules.Field('interval'),
                     rules.Field('custom_interval_in_minutes'),
                     rules.Field('timerange_from'),
                     rules.Field('timerange_to')]),
        ),
    ]

    form_widget_args = {
        'local_path': {
            'placeholder': '/var/backups/cmdbsyncer  (or a mounted CIFS/NFS share)',
        },
        's3_sse': {
            'placeholder': 'AES256 or aws:kms',
        },
        'gpg_recipient': {
            'placeholder': 'recipient@example.com  (used with encryption=gpg)',
        },
    }

    form_overrides = {
        'account': AccountSelectField,
    }

    @action('run_now', 'Run backup now',
            'Trigger the selected backup immediately? Runs inline; long '
            'dumps will take a while.')
    def action_run_now(self, ids):
        ok, err = 0, 0
        for cfg in BackupConfig.objects(id__in=ids):
            try:
                run_backup(cfg.name)
                ok += 1
            except Exception as exp:  # pylint: disable=broad-exception-caught
                err += 1
                flash(f'{cfg.name}: {exp}', 'error')
        if ok:
            flash(f'{ok} backup(s) completed successfully', 'success')
        if err:
            flash(f'{err} backup(s) failed — see errors above', 'error')

    def is_accessible(self):
        return (
            current_user.is_authenticated
            and (current_user.has_right('account') or current_user.global_admin)
        )


class BackupHistoryView(DefaultModelView):
    can_create = False
    can_edit = False
    can_delete = False
    can_export = True
    export_types = ['csv']

    column_extra_row_actions = []

    column_default_sort = ('started_at', True)

    column_list = ('started_at', 'config_name', 'status', 'duration_seconds',
                   'size_bytes', 'object_key', 'error')
    column_sortable_list = ('started_at', 'config_name', 'status')

    column_formatters = {
        'started_at': _format_dt,
        'ended_at': _format_dt,
        'status': _format_status,
        'size_bytes': _format_size,
    }

    def is_accessible(self):
        return (
            current_user.is_authenticated
            and (current_user.has_right('account') or current_user.global_admin)
        )


def register_admin_views(admin):
    admin.add_view(BackupConfigView(
        BackupConfig, name="Backup Configs",
        category="Backups",
        endpoint="backup_configs",
        menu_icon_type='fa', menu_icon_value='fa-archive',
    ))
    admin.add_view(BackupHistoryView(
        BackupHistory, name="Backup History",
        category="Backups",
        endpoint="backup_history",
        menu_icon_type='fa', menu_icon_value='fa-history',
    ))
