"""
Backup configuration and history.

One `BackupConfig` per destination — most customers have just one,
but the model supports multiple (e.g. daily-to-S3 + weekly-to-local
for tiered retention, or S3 + mounted CIFS share for geo-redundancy).
"""
from application import db
from application.models.cron import intervals as CRON_INTERVALS, hours as CRON_HOURS


COMPRESSION_CHOICES = [
    ('gzip', 'gzip'),
    ('none', 'none'),
]

ENCRYPTION_CHOICES = [
    ('none', 'no encryption (destination-side encryption only)'),
    ('gpg', 'GPG encryption to a recipient public key'),
]

STATUS_CHOICES = [
    ('running', 'running'),
    ('success', 'success'),
    ('failure', 'failure'),
]

DESTINATION_CHOICES = [
    ('s3', 'S3-compatible object storage'),
    ('local', 'Local filesystem path (incl. mounted network share)'),
]


class BackupConfig(db.Document):
    """A backup destination + policy."""
    name = db.StringField(required=True, unique=True)
    enabled = db.BooleanField(default=True)
    description = db.StringField()

    destination_type = db.StringField(
        choices=DESTINATION_CHOICES, default='s3',
        help_text="Where the encrypted dump goes. Use 'local' with a "
                  "mounted CIFS/NFS share for on-prem backups.",
    )

    # Destination: local filesystem (destination_type='local')
    local_path = db.StringField(
        help_text="Absolute directory on the syncer host for "
                  "destination_type=local. Mount CIFS/NFS shares at "
                  "the OS level and point this at the mount point. "
                  "The directory must exist and be writable by the "
                  "syncer process.",
    )

    # Destination: S3-compatible object storage (destination_type='s3')
    bucket = db.StringField()
    prefix = db.StringField(default='cmdbsyncer/')
    # Syncer Account that carries the S3 credentials:
    #   ``address``  — endpoint URL (blank = AWS S3)
    #   ``username`` — access key id  (blank = default AWS credential chain)
    #   ``password`` — secret access key
    #   ``custom_fields.region`` — optional AWS region override
    account = db.StringField()
    s3_sse = db.StringField(
        help_text="Server-side encryption header, e.g. AES256 or aws:kms. "
                  "Blank = no SSE header (object storage may still "
                  "enforce encryption at rest).",
    )

    # Processing
    compression = db.StringField(choices=COMPRESSION_CHOICES, default='gzip')
    encryption = db.StringField(choices=ENCRYPTION_CHOICES, default='none')
    gpg_recipient = db.StringField(
        help_text="For encryption=gpg: the key id or email whose public "
                  "key should wrap the archive. The key must be in the "
                  "syncer OS user's keyring.",
    )

    # Retention (days). 0 = keep forever.
    retention_days = db.IntField(default=30)

    # Schedule. The Backup feature auto-manages a CronGroup per config,
    # named ``Backup: <name>``, so operators don't have to wire one up
    # by hand. The CronGroup is marked ``protected`` and can be edited
    # (e.g. paused) but not deleted from the Cron view; deleting the
    # BackupConfig removes it.
    schedule_enabled = db.BooleanField(
        default=True,
        help_text="Run on the schedule below. Disable to pause the "
                  "auto-managed CronGroup without deleting it.",
    )
    interval = db.StringField(
        choices=CRON_INTERVALS, default='daily',
        help_text="How often the backup runs. 'Once Daily' means: at the "
                  "first cron tick inside the time-of-day window below.",
    )
    custom_interval_in_minutes = db.IntField(
        help_text="Optional override in minutes (takes precedence over "
                  "interval if set).",
    )
    timerange_from = db.StringField(choices=CRON_HOURS, default='2')
    timerange_to = db.StringField(choices=CRON_HOURS, default='6')

    meta = {'strict': False}

    def clean(self):
        """Reject incomplete configs early — before a cron job discovers them."""
        dest = self.destination_type or 's3'
        if dest == 's3':
            if not self.bucket:
                raise db.ValidationError(
                    "destination_type=s3 requires a bucket"
                )
        elif dest == 'local':
            if not (self.local_path or '').strip():
                raise db.ValidationError(
                    "destination_type=local requires local_path"
                )
        if self.encryption == 'gpg' and not (self.gpg_recipient or '').strip():
            raise db.ValidationError(
                "encryption=gpg requires gpg_recipient"
            )

    def __str__(self):
        if (self.destination_type or 's3') == 'local':
            return f"{self.name} → file://{self.local_path}"
        return f"{self.name} → s3://{self.bucket}/{self.prefix}"


class BackupHistory(db.Document):
    """One row per attempted backup run."""
    config_name = db.StringField(required=True)
    started_at = db.DateTimeField(required=True)
    ended_at = db.DateTimeField()
    status = db.StringField(choices=STATUS_CHOICES, default='running')
    object_key = db.StringField()
    size_bytes = db.IntField()
    error = db.StringField()
    duration_seconds = db.FloatField()

    meta = {
        'strict': False,
        'indexes': [
            {'fields': ['-started_at']},
            {'fields': ['config_name', '-started_at']},
        ],
    }

    def __str__(self):
        return f"{self.config_name} {self.started_at:%Y-%m-%d %H:%M} [{self.status}]"
