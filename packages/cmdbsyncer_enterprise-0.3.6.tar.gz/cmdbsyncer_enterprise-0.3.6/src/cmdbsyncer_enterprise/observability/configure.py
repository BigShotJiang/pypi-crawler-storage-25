"""
Install the ECS JSON pipeline on the OSS app logger.

Called once at startup via `run_hook('configure_logging', app, logger)`.
Strips existing console handlers and replaces them with a single
stdout-bound StreamHandler carrying the ECS formatter. The Python
root logger is also rewired so third-party library log output
(mongoengine, ldap3, urllib3 …) reaches the same JSON pipeline.

Toggles via `local_config.py`:

    JSON_LOGGING_ENABLED = True    # default: enabled when license active
    JSON_LOGGING_STREAM  = 'stdout' # 'stdout' (default) or 'stderr'
    JSON_LOGGING_LEVEL   = 'INFO'   # any standard Python level name
"""
import logging
import sys

from .ecs_formatter import EcsJsonFormatter


def _resolve_stream(app):
    choice = (app.config.get('JSON_LOGGING_STREAM') or 'stdout').lower()
    return sys.stderr if choice == 'stderr' else sys.stdout


def _resolve_level(app, fallback):
    name = app.config.get('JSON_LOGGING_LEVEL')
    if not name:
        return fallback
    level = logging.getLevelName(str(name).upper())
    return level if isinstance(level, int) else fallback


def configure_logging(app, logger):
    """
    Swap the OSS text pipeline for ECS JSON on stdout.

    - Removes all handlers from the `debug` logger *and* the root
      logger so we don't emit the same event in two shapes.
    - Installs one `StreamHandler` with our formatter on the root
      logger; `debug` propagates into it.
    - Propagate-heavy third-party loggers (uvicorn/werkzeug/mongoengine)
      keep working because they inherit the root handler.
    """
    if not app.config.get('JSON_LOGGING_ENABLED', True):
        # License present but the customer explicitly turned it off.
        return

    formatter = EcsJsonFormatter()
    handler = logging.StreamHandler(_resolve_stream(app))
    handler.setFormatter(formatter)

    # Wipe existing handlers — they would double-emit in the old text
    # format. Keep things on the root so every logger inherits.
    root = logging.getLogger()
    for existing in list(root.handlers):
        root.removeHandler(existing)
    root.addHandler(handler)
    root.setLevel(_resolve_level(app, logging.INFO))

    # The OSS bootstraps its own `debug` logger. Strip its handlers so
    # it propagates up to root (single emission) rather than having
    # its own text handler next to ours.
    for existing in list(logger.handlers):
        logger.removeHandler(existing)
    logger.propagate = True

    # Werkzeug's request log is noisy in JSON form but users can
    # re-enable it explicitly via JSON_LOGGING_LEVEL=DEBUG.
    logging.getLogger('werkzeug').setLevel(
        _resolve_level(app, logging.WARNING)
    )

    # Emit a marker so operators can confirm the pipeline is live.
    logger.info(
        "ECS JSON logging active",
        extra={'event_source': 'enterprise.observability',
               'event_details': {'stream': _resolve_stream(app).name}},
    )
