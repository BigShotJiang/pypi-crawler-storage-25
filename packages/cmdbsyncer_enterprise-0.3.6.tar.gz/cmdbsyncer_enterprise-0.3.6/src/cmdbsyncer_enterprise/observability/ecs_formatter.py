"""
Elastic Common Schema (ECS) JSON log formatter.

Emits one JSON object per log record on a single line. Field naming
follows ECS 8.11 so Elasticsearch / OpenSearch pick it up without
ingest-pipeline work, and aggregators like Loki, Datadog and
CloudWatch parse it out of the box.

Core fields always present:

    @timestamp           ISO-8601 UTC with milliseconds + 'Z'
    log.level            debug / info / warning / error / critical
    log.logger           Python logger name
    message              Human-readable message
    ecs.version          "8.11.0"
    service.name         From OTEL_SERVICE_NAME or SERVICE_NAME (default: cmdbsyncer)
    service.environment  From DEPLOYMENT_ENVIRONMENT or ENV if set
    service.version      From CMDBSYNCER_VERSION if set
    host.name            socket.gethostname()
    process.pid          os.getpid()

Flask-request-context fields (when a request is in flight):

    url.path             request.path
    http.request.method  request.method
    trace.id             X-Request-ID / X-Cloud-Trace-Context / X-Amzn-Trace-Id (first match)
    client.ip            request.remote_addr

Application event fields added by `log.log()`:

    event.source         Source string (e.g. "Checkmk Host Export")
    event.category       Always "app" for user-facing events
    event.outcome        "failure" when has_error, else "success"
    event.details.<k>    Structured detail fields (one per original detail)
    affected_hosts       List of hostnames

Exceptions:

    error.type           Exception class name
    error.message        Exception message
    error.stack_trace    Formatted traceback
"""
import json
import logging
import os
import socket
import traceback as tb_mod
from datetime import datetime, timezone

_ECS_VERSION = "8.11.0"
_HOSTNAME = socket.gethostname()
_PID = os.getpid()

# Attributes that live on every LogRecord by default — skipping them
# when walking `record.__dict__` lets callers add arbitrary `extra=`
# fields without collisions.
_RESERVED_RECORD_ATTRS = frozenset({
    'name', 'msg', 'args', 'levelname', 'levelno', 'pathname', 'filename',
    'module', 'exc_info', 'exc_text', 'stack_info', 'lineno', 'funcName',
    'created', 'msecs', 'relativeCreated', 'thread', 'threadName',
    'processName', 'process', 'message', 'asctime', 'taskName',
})

# Env var → ECS field mapping. Env var names follow the OpenTelemetry
# convention first, generic fallbacks second, so containers that
# already set OTEL_* get picked up without extra config.
_ENV_MAPPING = (
    ('service.name', ('OTEL_SERVICE_NAME', 'SERVICE_NAME'), 'cmdbsyncer'),
    ('service.environment', ('DEPLOYMENT_ENVIRONMENT', 'ENV'), None),
    ('service.version', ('CMDBSYNCER_VERSION', 'SERVICE_VERSION'), None),
    ('cloud.region', ('AWS_REGION', 'CLOUD_REGION'), None),
)


def _nested_set(target, dotted_key, value):
    """Turn 'service.name' into target['service']['name'] = value."""
    parts = dotted_key.split('.')
    cursor = target
    for part in parts[:-1]:
        cursor = cursor.setdefault(part, {})
    cursor[parts[-1]] = value


def _env_baseline():
    """Snapshot of static service fields. Called once at formatter init."""
    fields = {}
    for ecs_key, env_candidates, default in _ENV_MAPPING:
        value = next((os.environ.get(k) for k in env_candidates
                      if os.environ.get(k)), default)
        if value:
            _nested_set(fields, ecs_key, value)
    _nested_set(fields, 'host.name', _HOSTNAME)
    _nested_set(fields, 'process.pid', _PID)
    fields['ecs'] = {'version': _ECS_VERSION}
    return fields


def _extract_flask_context():
    """Non-raising extraction of Flask request-context fields."""
    try:
        from flask import request, has_request_context  # pylint: disable=import-outside-toplevel
    except ImportError:
        return {}
    try:
        if not has_request_context():
            return {}
    except RuntimeError:
        return {}
    fields = {}
    try:
        _nested_set(fields, 'url.path', request.path)
        _nested_set(fields, 'http.request.method', request.method)
        if request.remote_addr:
            _nested_set(fields, 'client.ip', request.remote_addr)
        # Common trace-id headers, first-match wins. CloudRun/GCP uses
        # X-Cloud-Trace-Context, AWS ALB uses X-Amzn-Trace-Id, most
        # ingress setups use X-Request-ID.
        for header in ('X-Request-ID', 'X-Cloud-Trace-Context',
                       'X-Amzn-Trace-Id', 'traceparent'):
            trace = request.headers.get(header)
            if trace:
                _nested_set(fields, 'trace.id', trace)
                break
    except Exception:  # pylint: disable=broad-except
        # Log formatting must never fail the request — swallow.
        return {}
    return fields


class EcsJsonFormatter(logging.Formatter):
    """JSON formatter producing ECS-shaped records."""

    def __init__(self):
        super().__init__()
        self._baseline = _env_baseline()

    def format(self, record):  # noqa: A003 — logging API
        doc = {
            '@timestamp': datetime.fromtimestamp(
                record.created, tz=timezone.utc
            ).strftime('%Y-%m-%dT%H:%M:%S.') + f'{int(record.msecs):03d}Z',
            'log': {
                'level': record.levelname.lower(),
                'logger': record.name,
            },
            'message': record.getMessage(),
        }

        # Static host/service block.
        for k, v in self._baseline.items():
            doc.setdefault(k, v)

        # Flask request context (if any).
        for k, v in _extract_flask_context().items():
            doc.setdefault(k, v)

        # Application event fields emitted by `log.log()`.
        source = getattr(record, 'event_source', None)
        if source:
            _nested_set(doc, 'event.source', source)
            _nested_set(doc, 'event.category', 'app')
        if getattr(record, 'event_has_error', False):
            _nested_set(doc, 'event.outcome', 'failure')
        elif source:
            _nested_set(doc, 'event.outcome', 'success')
        details = getattr(record, 'event_details', None)
        if isinstance(details, dict) and details:
            _nested_set(doc, 'event.details', details)
        affected = getattr(record, 'event_affected_hosts', None)
        if affected:
            doc['affected_hosts'] = list(affected)

        # Exception info.
        if record.exc_info:
            exc_type, exc_val, _ = record.exc_info
            _nested_set(doc, 'error.type', exc_type.__name__ if exc_type else '')
            _nested_set(doc, 'error.message', str(exc_val) if exc_val else '')
            _nested_set(doc, 'error.stack_trace',
                        ''.join(tb_mod.format_exception(*record.exc_info)))

        # Any other `extra=` fields the caller passed (besides the
        # event_* ones already handled). Namespaced under `labels.` so
        # they never collide with ECS top-level fields.
        known_extra = {'event_source', 'event_details',
                       'event_affected_hosts', 'event_has_error'}
        for key, value in record.__dict__.items():
            if key in _RESERVED_RECORD_ATTRS or key in known_extra:
                continue
            if key.startswith('_'):
                continue
            doc.setdefault('labels', {})[key] = _stringify(value)

        return json.dumps(doc, default=_stringify, separators=(',', ':'))


def _stringify(value):
    """Defensive fallback so an unserialisable value never kills logging."""
    try:
        json.dumps(value)
        return value
    except (TypeError, ValueError):
        return str(value)
