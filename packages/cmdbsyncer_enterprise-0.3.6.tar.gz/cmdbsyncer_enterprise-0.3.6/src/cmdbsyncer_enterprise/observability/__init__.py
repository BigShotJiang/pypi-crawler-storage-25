"""
Structured / JSON logging (Enterprise feature: `json_logging`).

Replaces the text log handler with an ECS-compatible JSON handler on
stdout, so cloud log collectors (Fluent Bit / Vector / Filebeat /
CloudWatch agent / Datadog agent / Loki Promtail) pick up the stream
without field-mapping work.

No-op when the feature is not licensed — community installs keep the
default text formatter.
"""
from .configure import configure_logging

__all__ = ['configure_logging']
