"""
Mongo-owned collections for Notification Routing.

`NotificationChannel` and `NotificationRule` now live in OSS
(`application.models.notification_channel`, `.notification_rule`) so
any notification pipeline shares one collection + one admin UI.
Enterprise only ships:

- The dispatcher (Jinja templates, cooldown, rate-limiting) that
  consumes the shared rules; see `dispatcher.py`.
- `NotificationState` — per-dedup-key bookkeeping (last sent,
  suppressed count) so cooldowns survive a restart.
- `activate()` in `__init__.py`, which extends the channel-type
  dropdown with Slack / MS Teams / generic webhook.
"""
from datetime import datetime
from application import db

# Re-exported for callers that still do
#   `from cmdbsyncer_enterprise.notifications.models import NotificationChannel`
# or the same for NotificationRule. Safe to drop once all consumers
# import from application.models.* directly.
from application.models.notification_channel import NotificationChannel  # noqa: F401
from application.models.notification_rule import NotificationRule, SEVERITIES  # noqa: F401


class NotificationState(db.Document):
    """
    Per dedup-key state so cooldowns survive a restart. TTL-indexed so
    stale entries self-expire after a day of inactivity.
    """
    dedup_key = db.StringField(required=True, unique=True)
    last_sent_at = db.DateTimeField()
    suppressed_since = db.DateTimeField()
    suppressed_count = db.IntField(default=0)
    # Rolling window counter for max_per_hour
    hour_window_start = db.DateTimeField()
    hour_window_count = db.IntField(default=0)

    meta = {
        'strict': False,
        'indexes': [
            {'fields': ['dedup_key']},
            # TTL: purge keys untouched for >24h
            {'fields': ['last_sent_at'],
             'expireAfterSeconds': 86400},
        ],
    }

    def touch(self):
        self.last_sent_at = datetime.utcnow()
