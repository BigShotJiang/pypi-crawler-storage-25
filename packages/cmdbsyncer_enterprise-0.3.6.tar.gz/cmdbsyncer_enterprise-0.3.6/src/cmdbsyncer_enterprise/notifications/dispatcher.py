"""
Rule-matching + deduplicated dispatch for notifications.

The public entry points are:

    notify_event(event_type, **context)
        The OSS hook. Called by `application.helpers.notify.notify`
        for cron failures, license expiry, secret-resolution failures,
        etc.

    dispatch_audit_event(entry)
        Invoked by the audit recorder on every saved AuditEntry so
        rules can match on login failures, webhook rejections, etc.
        without the OSS having to call notify() for every audit event
        manually.

Dispatch runs in a background thread so slow Slack/SMTP endpoints
don't back-pressure the caller (login, cron tick, audit save).
"""
import logging
import queue
import re
import threading
from datetime import datetime, timedelta

from jinja2 import Environment, BaseLoader, select_autoescape
from mongoengine.errors import DoesNotExist, NotUniqueError

from . import channels
from .models import NotificationChannel, NotificationRule, NotificationState

log = logging.getLogger(__name__)

_SEVERITY_ORDER = {'info': 0, 'warning': 1, 'error': 2, 'critical': 3}

_jinja = Environment(
    loader=BaseLoader(),
    autoescape=select_autoescape(disabled_extensions=('txt', 'md')),
    trim_blocks=True, lstrip_blocks=True,
)


_queue = queue.Queue(maxsize=1000)
_worker_started = threading.Lock()
_worker_running = False


def _start_worker():
    """Spawn the dispatch worker lazily on first event."""
    global _worker_running  # pylint: disable=global-statement
    with _worker_started:
        if _worker_running:
            return
        thread = threading.Thread(
            target=_worker_loop, name='notification-dispatcher', daemon=True,
        )
        thread.start()
        _worker_running = True


def _worker_loop():
    while True:
        event_type, context = _queue.get()
        try:
            _dispatch(event_type, context)
        except Exception:  # pylint: disable=broad-exception-caught
            log.exception("Notification dispatch failed for %s", event_type)
        finally:
            _queue.task_done()


def _match(value, pattern):
    """Empty pattern = match everything. Otherwise regex."""
    if not pattern:
        return True
    try:
        return bool(re.search(pattern, str(value or '')))
    except re.error:
        log.warning("Invalid regex in notification rule: %r", pattern)
        return False


def _select_rules(event):
    """Return the rules (in priority order) that match this event."""
    matching = []
    event_severity = _SEVERITY_ORDER.get(
        event.get('severity', 'info'), 0,
    )
    for rule in NotificationRule.objects(enabled=True).order_by('priority'):
        if not _match(event.get('event_type'), rule.event_type_match):
            continue
        if not _match(event.get('source'), rule.source_match):
            continue
        if not _match(event.get('target'), rule.target_match):
            continue
        if rule.outcome_match and event.get('outcome') != rule.outcome_match:
            continue
        rule_min = _SEVERITY_ORDER.get(rule.severity_min or 'info', 0)
        if event_severity < rule_min:
            continue
        matching.append(rule)
        if not rule.continue_after_match:
            break
    return matching


def _render(template, event):
    if not template:
        return None
    try:
        return _jinja.from_string(template).render(**event)
    except Exception as exp:  # pylint: disable=broad-exception-caught
        log.warning("Jinja render failed: %s", exp)
        return None


def _allow_send(rule, dedup_key):
    """
    Enforce cooldown + max_per_hour. Atomic on single Mongo doc via
    find_and_modify style upsert.
    """
    now = datetime.utcnow()
    try:
        state = NotificationState.objects.get(dedup_key=dedup_key)
    except DoesNotExist:
        state = NotificationState(dedup_key=dedup_key,
                                  hour_window_start=now,
                                  hour_window_count=0)

    if state.last_sent_at:
        cooldown = timedelta(minutes=int(rule.cooldown_minutes or 0))
        if now - state.last_sent_at < cooldown:
            state.suppressed_count = (state.suppressed_count or 0) + 1
            state.suppressed_since = state.suppressed_since or now
            try:
                state.save()
            except NotUniqueError:
                pass
            return False

    window_start = state.hour_window_start or now
    if now - window_start >= timedelta(hours=1):
        state.hour_window_start = now
        state.hour_window_count = 0
    if state.hour_window_count >= int(rule.max_per_hour or 0) > 0:
        state.suppressed_count = (state.suppressed_count or 0) + 1
        state.save()
        return False

    state.last_sent_at = now
    state.hour_window_count = (state.hour_window_count or 0) + 1
    state.suppressed_since = None
    try:
        state.save()
    except NotUniqueError:
        pass
    return True


def _payload_from_event(event, rule):
    """Build the channel payload — render templates, carry details."""
    payload = dict(event)
    if rule.title_template:
        payload['title'] = _render(rule.title_template, event) or payload.get('title')
    if rule.message_template:
        payload['message'] = _render(rule.message_template, event) or payload.get('message')
    return payload


def _dispatch(event_type, context):
    event = dict(context)
    event.setdefault('event_type', event_type)
    event.setdefault('severity', 'info')

    rules = _select_rules(event)
    if not rules:
        return

    for rule in rules:
        dedup_key = event.get('dedup_key') or f"rule:{rule.id}:{event_type}"
        if not _allow_send(rule, dedup_key):
            log.info("Suppressed by cooldown/ratelimit: %s (%s)",
                     event_type, dedup_key)
            continue
        payload = _payload_from_event(event, rule)
        for ch_ref in rule.channels:
            try:
                channel = ch_ref if isinstance(ch_ref, NotificationChannel) \
                    else NotificationChannel.objects.get(id=ch_ref.id)
            except DoesNotExist:
                continue
            if not channel.enabled:
                continue
            try:
                channels.send(channel, payload)
            except Exception as exp:  # pylint: disable=broad-exception-caught
                log.warning("Channel %r send failed: %s", channel.name, exp)


def _enqueue(event_type, context):
    _start_worker()
    try:
        _queue.put_nowait((event_type, context))
    except queue.Full:
        log.warning(
            "Notification queue full (1000 pending), dropping event %s",
            event_type,
        )


def notify_event(event_type, **context):
    """Public OSS-facing hook."""
    _enqueue(event_type, context)


def dispatch_audit_event(entry):
    """
    Forward an AuditEntry into the notification pipeline. Called by the
    audit recorder after the entry is persisted, so rules can route
    security events (login failures, webhook rejections) without the
    OSS having to call notify() everywhere.
    """
    severity = 'warning' if entry.outcome == 'failure' else 'info'
    # Elevate certain event types regardless of outcome.
    if any(entry.event_type.startswith(prefix) for prefix in (
        'webhook.rejected', 'user.login.failure', 'secret.resolution',
    )):
        severity = 'warning' if severity == 'info' else 'error'

    _enqueue(entry.event_type, {
        'event_type': entry.event_type,
        'severity': severity,
        'outcome': entry.outcome,
        'source': 'audit',
        'title': f"Audit: {entry.event_type}",
        'message': entry.message or '',
        'actor_name': entry.actor_name,
        'actor_ip': entry.actor_ip,
        'target': entry.target_name or '',
        'target_type': entry.target_type or '',
        'target_id': entry.target_id or '',
        'details': entry.metadata or {},
        'trace_id': entry.trace_id,
        'dedup_key': f"audit:{entry.event_type}:{entry.actor_name or ''}:"
                     f"{entry.target_type or ''}:{entry.target_id or ''}",
    })
