"""
Microsoft Teams incoming-webhook channel.

Produces an Adaptive Card with a coloured accent bar. Teams webhook
URLs are typically ``*.webhook.office.com/webhookb2/...`` — use the
new Workflows-based ones for MS 365 tenants.

Reads the webhook URL from the Syncer Account referenced by
``channel.account`` (the Account's ``address``).
"""
import requests

from . import resolve_account


_COLOR = {
    'info': 'good',
    'warning': 'warning',
    'error': 'attention',
    'critical': 'attention',
}


def send(channel, payload):
    account = resolve_account(channel)
    url = (account.get('address') or '').strip()
    if not url:
        raise RuntimeError(
            f"MS Teams channel {channel.name!r}: account {account.get('name')!r} "
            f"has no address (webhook URL)"
        )

    title = payload.get('title') or payload.get('event_type') or 'Notification'
    message = payload.get('message') or ''
    severity = payload.get('severity', 'info')

    facts = []
    for key in ('source', 'event_type', 'target', 'outcome'):
        if value := payload.get(key):
            facts.append({'title': key, 'value': str(value)})
    for key, value in (payload.get('details') or {}).items():
        facts.append({'title': key, 'value': str(value)})

    body_items = [
        {
            'type': 'TextBlock',
            'text': title,
            'weight': 'Bolder',
            'size': 'Large',
            'color': _COLOR.get(severity, 'default'),
            'wrap': True,
        },
    ]
    if message:
        body_items.append({'type': 'TextBlock', 'text': message, 'wrap': True})
    if facts:
        body_items.append({'type': 'FactSet', 'facts': facts})

    actions = []
    if runbook := payload.get('runbook_url'):
        actions.append({
            'type': 'Action.OpenUrl',
            'title': 'Runbook',
            'url': runbook,
        })

    card = {
        'type': 'message',
        'attachments': [{
            'contentType': 'application/vnd.microsoft.card.adaptive',
            'content': {
                '$schema': 'http://adaptivecards.io/schemas/adaptive-card.json',
                'type': 'AdaptiveCard',
                'version': '1.4',
                'body': body_items,
                'actions': actions,
            },
        }],
    }

    resp = requests.post(url, json=card, timeout=10)
    resp.raise_for_status()
