"""
Slack incoming-webhook channel.

Renders a Block Kit message with a severity-coloured header so
failures stand out in the channel. Optional mention (``@netops``,
``<!subteam^...>``, ``<!here>``) is injected above the header.

Reads the webhook URL and all per-channel overrides from the Syncer
Account referenced by ``channel.account`` — ``address`` is the URL,
and optional ``custom_fields`` ``slack_channel`` / ``slack_mention``
override the target room and user mention.
"""
import requests

from . import resolve_account


_COLOR = {
    'info': '#3498db',
    'warning': '#f39c12',
    'error': '#e74c3c',
    'critical': '#c0392b',
}

_EMOJI = {
    'info': ':information_source:',
    'warning': ':warning:',
    'error': ':x:',
    'critical': ':rotating_light:',
}


def _blocks(payload):
    severity = payload.get('severity', 'info')
    emoji = _EMOJI.get(severity, ':bell:')
    title = payload.get('title') or payload.get('event_type') or 'Notification'
    message = payload.get('message') or ''
    blocks = [{
        'type': 'header',
        'text': {'type': 'plain_text', 'text': f'{emoji} {title}'},
    }]
    if message:
        blocks.append({
            'type': 'section',
            'text': {'type': 'mrkdwn', 'text': message},
        })
    fields = []
    for key in ('source', 'event_type', 'target', 'outcome'):
        value = payload.get(key)
        if value:
            fields.append({
                'type': 'mrkdwn',
                'text': f'*{key}:* `{value}`',
            })
    if fields:
        blocks.append({'type': 'section', 'fields': fields})
    details = payload.get('details') or {}
    if details:
        detail_lines = '\n'.join(
            f'• *{k}:* `{v}`' for k, v in sorted(details.items())
        )
        blocks.append({
            'type': 'section',
            'text': {'type': 'mrkdwn', 'text': detail_lines},
        })
    if runbook := payload.get('runbook_url'):
        blocks.append({
            'type': 'actions',
            'elements': [{
                'type': 'button',
                'text': {'type': 'plain_text', 'text': 'Runbook'},
                'url': runbook,
            }],
        })
    return blocks


def send(channel, payload):
    account = resolve_account(channel)
    url = (account.get('address') or '').strip()
    if not url:
        raise RuntimeError(
            f"Slack channel {channel.name!r}: account {account.get('name')!r} "
            f"has no address (webhook URL)"
        )

    body = {
        'attachments': [{
            'color': _COLOR.get(payload.get('severity', 'info'), '#cccccc'),
            'blocks': _blocks(payload),
        }],
    }
    if slack_channel := (account.get('slack_channel') or '').strip():
        body['channel'] = slack_channel
    if mention := (account.get('slack_mention') or '').strip():
        body['text'] = mention

    resp = requests.post(url, json=body, timeout=10)
    resp.raise_for_status()
