"""
Channel dispatch. Each type module exports ``send(channel, payload)``.

``payload`` is a dict: ``{title, message, severity, source, event_type,
target, details, trace_id, runbook_url}``.

Outbound config (endpoint URL, signing secret, per-integration
details) lives on a Syncer Account referenced by ``channel.account``.
Dispatchers call :func:`resolve_account` to pull it through
``get_account_by_name`` so any Enterprise Secrets Manager binding
applies transparently.
"""
from application.helpers.get_account import (
    AccountNotFoundError,
    get_account_by_name,
)


def resolve_account(channel, required=True):
    """Return the resolved Account dict for ``channel``, or None.

    Raises RuntimeError with a user-facing message when ``required`` and
    the Account cannot be loaded. The returned dict carries ``address``
    (URL), ``username``, ``password`` and every ``custom_fields`` entry
    flattened to a top-level key — same shape as other plugins see.
    """
    name = (channel.account or '').strip()
    if not name:
        if required:
            raise RuntimeError(
                f"Channel {channel.name!r} has no Account configured"
            )
        return None
    try:
        return get_account_by_name(name)
    except AccountNotFoundError as exc:
        raise RuntimeError(
            f"Channel {channel.name!r}: Account {name!r} not found or disabled"
        ) from exc


# Dispatcher submodules read ``resolve_account`` from this module, so
# their imports happen only after the helper above is in place.
from .slack import send as _slack_send      # noqa: E402
from .msteams import send as _msteams_send  # noqa: E402
from .email import send as _email_send      # noqa: E402
from .webhook import send as _webhook_send  # noqa: E402


_CHANNEL_SENDERS = {
    'slack': _slack_send,
    'msteams': _msteams_send,
    'email': _email_send,
    'webhook': _webhook_send,
}


def send(channel, payload):
    """Dispatch `payload` through the provider configured on `channel`."""
    sender = _CHANNEL_SENDERS.get(channel.type)
    if sender is None:
        raise RuntimeError(f"Unknown notification channel type: {channel.type}")
    return sender(channel, payload)
