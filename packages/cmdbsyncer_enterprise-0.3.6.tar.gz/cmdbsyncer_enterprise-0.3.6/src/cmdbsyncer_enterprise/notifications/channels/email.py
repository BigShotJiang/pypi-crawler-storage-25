"""
Email channel — reuses the OSS `application.modules.email.send_email`
helper so SMTP settings configured in `local_config.py` apply. No
separate SMTP config in the notification channel — operators only
pick recipients and a subject prefix.
"""
from application.modules.email import send_email


def _render_html(payload):
    title = payload.get('title') or payload.get('event_type') or 'Notification'
    rows = []
    for key in ('event_type', 'severity', 'source', 'target', 'outcome',
                'actor_name', 'actor_ip', 'trace_id'):
        if value := payload.get(key):
            rows.append(
                f"<tr><td style='padding:4px 8px;color:#666;'>"
                f"{key}</td><td style='padding:4px 8px;'><code>{value}</code></td></tr>"
            )
    for key, value in (payload.get('details') or {}).items():
        rows.append(
            f"<tr><td style='padding:4px 8px;color:#666;'>"
            f"{key}</td><td style='padding:4px 8px;'><code>{value}</code></td></tr>"
        )
    html = (
        f"<h2>{title}</h2>"
        f"<p>{payload.get('message') or ''}</p>"
        f"<table style='border-collapse:collapse;border:1px solid #ddd;'>"
        f"{''.join(rows)}"
        f"</table>"
    )
    if runbook := payload.get('runbook_url'):
        html += f'<p><a href="{runbook}">Runbook</a></p>'
    return html


def send(channel, payload):
    recipients = [r.strip() for r in (channel.email_recipients or '').split(',')
                  if r.strip()]
    if not recipients:
        raise RuntimeError(
            f"Email channel {channel.name!r} has no recipients configured"
        )
    prefix = (channel.email_subject_prefix or '[CMDBsyncer]').strip()
    subject = (f"{prefix} {payload.get('severity', '').upper() or 'INFO'}: "
               f"{payload.get('title') or payload.get('event_type') or 'Notification'}")
    # send_email currently renders a template; we pre-render HTML and
    # pass it via a context key the template can emit directly. If
    # the template is not present the helper falls back to the text.
    for recipient in recipients:
        send_email(
            recipient, subject, 'email/notification',
            notification=payload, rendered_html=_render_html(payload),
        )
