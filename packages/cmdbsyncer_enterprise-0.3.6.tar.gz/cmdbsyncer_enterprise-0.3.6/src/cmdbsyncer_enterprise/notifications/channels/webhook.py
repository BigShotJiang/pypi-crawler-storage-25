"""
Generic HTTP webhook channel.

Posts the payload as JSON. Supports optional HMAC-SHA256 signing —
same style as GitHub / Stripe webhooks:

    X-Signature-SHA256: sha256=<hex digest of body>
    X-Timestamp: <unix seconds>       (add timestamp to body for replay-protection on the receiver)

Endpoint URL, signing secret and extra request headers come from the
Syncer Account referenced by ``channel.account``:

- ``address``           — webhook URL
- ``password``          — HMAC-SHA256 signing secret (optional)
- ``custom_fields``
    - ``extra_headers`` — dict or ``key: value`` lines of additional
                          headers (for example ``Authorization``)
"""
import hashlib
import hmac
import time

import requests

from . import resolve_account


def _parse_extra_headers(raw):
    if not raw:
        return {}
    if isinstance(raw, dict):
        return {str(k): str(v) for k, v in raw.items()}
    headers = {}
    for line in str(raw).splitlines():
        if ':' in line:
            k, v = line.split(':', 1)
            headers[k.strip()] = v.strip()
    return headers


def send(channel, payload):
    account = resolve_account(channel)
    url = (account.get('address') or '').strip()
    if not url:
        raise RuntimeError(
            f"Webhook channel {channel.name!r}: account {account.get('name')!r} "
            f"has no address (webhook URL)"
        )

    import json as _json
    body = _json.dumps({
        'timestamp': int(time.time()),
        'payload': payload,
    }, separators=(',', ':'), default=str).encode('utf-8')

    headers = {'Content-Type': 'application/json'}
    for key, value in _parse_extra_headers(account.get('extra_headers')).items():
        headers[key] = value

    secret = account.get('password') or ''
    if secret:
        signature = hmac.new(
            secret.encode('utf-8'), body, hashlib.sha256
        ).hexdigest()
        headers['X-Signature-SHA256'] = f'sha256={signature}'

    resp = requests.post(url, data=body, headers=headers, timeout=10)
    resp.raise_for_status()
