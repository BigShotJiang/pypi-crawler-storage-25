"""
No admin views left here.

`NotificationChannel` and `NotificationRule` both live in OSS
(`application.views.notification_channel`, `.notification_rule`).
Enterprise's contribution is the dispatcher (`dispatcher.py`) and the
extra channel-type registrations in `__init__.py`. The registrar hook
is kept for API compatibility with the enterprise package loader.
"""


def register_admin_views(admin):
    """No-op — all notification UIs come from OSS."""
    # Left as a stub so `_admin_view_registrars.append(...)` in
    # `cmdbsyncer_enterprise.__init__` stays valid without needing a
    # conditional. Removing this would break older license payloads
    # that import the symbol.
