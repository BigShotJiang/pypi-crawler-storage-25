"""
Notification Routing (Enterprise feature: ``notifications``).

Dispatches events from ``notify(event_type, **context)`` (cron failures,
recoveries, license expiry, secret-resolution failures, security events)
to configured channels (Slack, MS Teams, Email, generic webhook)
according to user-defined rules with deduplication and cooldown.

Integrates with the audit log: every audit event also passes through
the notification pipeline, so rules can route ``user.login.failure``
or ``webhook.rejected`` to a ``#security`` channel.

Enterprise also registers three Syncer Account plugin types at
activation (``slack``, ``msteams``, ``webhook``) so operators can pick
them from the New-Account flow — each comes with the right custom-
field presets for the integration.
"""
from application.helpers.plugins import register_plugin_type
from application.models.notification_channel import register_channel_type

from .dispatcher import notify_event, dispatch_audit_event
from .views import register_admin_views

__all__ = ['notify_event', 'dispatch_audit_event', 'register_admin_views',
           'activate']


def activate():
    """Extend OSS with the Enterprise channel types + Account plugins.

    Idempotent — safe to call on every process start.
    """
    register_channel_type('slack',   'Slack')
    register_channel_type('msteams', 'MS Teams')
    register_channel_type('webhook', 'Webhook')

    register_plugin_type(
        'slack',
        'Slack',
        description='Notification delivery to a Slack workspace.',
        account_presets={'address': 'https://hooks.slack.com/services/...'},
        account_custom_field_presets={
            'slack_channel': '',    # e.g. '#alerts' — overrides the webhook default
            'slack_mention': '',    # '<!here>' | '@netops' | '<!subteam^...>'
        },
    )
    register_plugin_type(
        'msteams',
        'MS Teams',
        description='Notification delivery to a Microsoft Teams channel.',
        account_presets={'address': 'https://<tenant>.webhook.office.com/...'},
        account_custom_field_presets={},
    )
    register_plugin_type(
        'webhook',
        'Webhook',
        description=('Notification delivery to a generic HTTPS webhook. '
                     'Password is the optional HMAC-SHA256 signing secret.'),
        account_presets={'address': 'https://webhook.example.com/hook'},
        account_custom_field_presets={
            'extra_headers': '',    # 'Authorization: Bearer …\nX-Source: cmdbsyncer'
        },
    )


# Activate at import time. The feature-gate machinery only imports this
# module when the `notifications` feature is licensed, so unlicensed
# installs never see the additional options.
activate()
