"""
License loading and verification.

Reads a JWT license file from `CMDBSYNCER_LICENSE`. If that env var is
unset, the loader defaults to `license.jwt` next to the customer's
`local_config.py` — the same directory customers already use for
runtime config on pip installs.

Hard failures (missing file, bad signature, malformed token) raise
ImportError so the OSS `application.enterprise` graceful-import path
kicks in. **Expiry is intentionally treated as a soft warning, not a
hard error**: the license keeps loading with all features active and
operators see a warning in the GUI / API. This is a deliberate policy
decision — locking customers out of their own data on the day a
license lapses creates an outage; nudging them with a warning does
not. Same idea for `max_hosts`: enforced as a warning only.
"""
import importlib.util
import os
import time
from pathlib import Path

from joserfc import jwt
from joserfc.jwk import RSAKey
from joserfc.errors import JoseError

_PUBKEY_PATH = Path(__file__).parent / "public_key.pem"


def _default_license_path():
    """
    Resolve `license.jwt` next to `local_config.py`. `find_spec` returns
    the file path from whichever entry in `sys.path` wins, without
    actually importing the module — so this works even before
    `local_config` has been loaded by the application itself.
    """
    try:
        spec = importlib.util.find_spec('local_config')
    except (ImportError, ValueError):
        spec = None
    if spec and spec.origin:
        return str(Path(spec.origin).parent / 'license.jwt')
    raise ImportError(
        "Enterprise license not found: `local_config.py` is not on sys.path, "
        "so the default license location cannot be resolved. Set the "
        "CMDBSYNCER_LICENSE environment variable to the license file path."
    )


def load_and_verify():
    """Return verified license claims as a dict, or raise ImportError.

    Expired tokens are *not* an ImportError — the dict is returned with
    all claims intact so callers can render a warning. Use the helpers
    in this module (or the `license_warnings` hook) to inspect state.
    """
    license_path = os.environ.get('CMDBSYNCER_LICENSE') or _default_license_path()
    public_key = RSAKey.import_key(_PUBKEY_PATH.read_bytes())

    try:
        token = Path(license_path).read_text(encoding='utf-8').strip()
    except FileNotFoundError as exp:
        raise ImportError(f"Enterprise license not found: {exp}") from exp

    try:
        # Skip JWTClaimsRegistry — it would reject an expired `exp` and
        # raise. We want expiry to be a soft warning, not an outage.
        decoded = jwt.decode(token, public_key, algorithms=['RS256'])
    except JoseError as exp:
        raise ImportError(f"Enterprise license invalid: {exp}") from exp

    return dict(decoded.claims)


# Warn 30 days before a license lapses so operators have time to renew.
EXPIRY_WARN_SECONDS = 30 * 86400


def expiry_state(claims, now=None):
    """
    Classify the license expiry. Returns one of:

    * ``'ok'``                     — more than 30 days left
    * ``'expiring'``               — within 30 days of expiry
    * ``'expired'``                — past expiry
    * ``'unknown'``                — no `exp` claim in the token

    `now` is a unix timestamp; defaults to wall-clock time.
    """
    exp = claims.get('exp') if claims else None
    if not isinstance(exp, (int, float)):
        return 'unknown'
    now = now if now is not None else time.time()
    if now >= exp:
        return 'expired'
    if exp - now <= EXPIRY_WARN_SECONDS:
        return 'expiring'
    return 'ok'


def host_count_state(claims, current_count):
    """
    Classify the host count vs. license cap. Returns:

    * ``'ok'``           — under cap (or no cap set, i.e. unlimited)
    * ``'over'``         — current_count > max_hosts

    `max_hosts == 0` (or missing) means unlimited.
    """
    cap = claims.get('max_hosts') if claims else None
    if not cap:  # 0 / None / missing → unlimited
        return 'ok'
    try:
        cap_int = int(cap)
    except (TypeError, ValueError):
        return 'ok'
    if cap_int <= 0:
        return 'ok'
    return 'over' if current_count > cap_int else 'ok'
