"""
Prometheus metrics endpoint (Enterprise feature: `prometheus_metrics`).

Exposes `/metrics` in Prometheus text format for scraping. The third
observability pillar next to JSON logs and the audit trail: numeric
health, SLO timers, "how long since X" timestamps.
"""
from .blueprint import register_blueprint

__all__ = ['register_blueprint']
