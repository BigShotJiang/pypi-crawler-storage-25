"""
Prometheus `/metrics` endpoint.

Metrics are **generated on scrape** from the Mongo state — there's no
persistent in-process counter state to maintain. That keeps the
endpoint stateless, crash-safe, and consistent across multiple
replicas (HA deployments).

Authentication reuses the Syncer's Basic-Auth layer: create a Syncer
User with the ``metrics`` API role and point the scraper at the same
credentials it would use for any other API endpoint.
"""
import logging
import time

from flask import Blueprint, Response

from application.api import require_api_role

log = logging.getLogger(__name__)

PROMETHEUS_BP = Blueprint('prometheus', __name__)


def _metrics_text():  # pylint: disable=too-many-locals
    """
    Build the Prometheus exposition format by hand. Cheaper and less
    dependency-heavy than pulling in `prometheus_client` just for a
    one-line render, and sidesteps its global-registry singleton quirks.
    """
    # Imports are local so test harnesses that don't configure mongo can
    # still import the blueprint file without triggering a connect.
    from application.enterprise import run_hook  # pylint: disable=import-outside-toplevel
    from application.models.cron import CronGroup, CronStats  # pylint: disable=import-outside-toplevel
    from application.models.host import Host  # pylint: disable=import-outside-toplevel

    lines = []

    def _metric(name, help_text, mtype='gauge'):
        lines.append(f'# HELP {name} {help_text}')
        lines.append(f'# TYPE {name} {mtype}')

    def _emit(name, value, labels=None):
        if labels:
            label_str = ','.join(
                f'{k}="{_escape(str(v))}"' for k, v in labels.items()
            )
            lines.append(f'{name}{{{label_str}}} {value}')
        else:
            lines.append(f'{name} {value}')

    def _escape(v):
        return v.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')

    now = time.time()

    # --- License info
    _metric('cmdbsyncer_info',
            'Constant 1 with build / license metadata')
    info = run_hook('license_info') or {}
    _emit('cmdbsyncer_info', 1, {
        'customer': info.get('customer') or '',
        'license_id': info.get('license_id') or '',
        'exp': str(info.get('exp') or ''),
    })

    # --- Cron groups
    _metric('cmdbsyncer_cron_group_enabled',
            'CronGroup.enabled (1 = enabled, 0 = disabled)')
    _metric('cmdbsyncer_cron_group_running',
            'CronStats.is_running (1 while a group is executing)')
    _metric('cmdbsyncer_cron_group_failure',
            'CronStats.failure for the last run (1 = last run failed)')
    _metric('cmdbsyncer_cron_group_last_start_timestamp_seconds',
            'Unix timestamp of the last start')
    _metric('cmdbsyncer_cron_group_last_end_timestamp_seconds',
            'Unix timestamp of the last end')
    _metric('cmdbsyncer_cron_group_last_success_timestamp_seconds',
            'Unix timestamp of the last *successful* end')
    _metric('cmdbsyncer_cron_group_last_duration_seconds',
            'Duration of the last completed run')
    _metric('cmdbsyncer_cron_group_next_run_timestamp_seconds',
            'Unix timestamp when the group is next eligible to run')

    stats_by_group = {s.group: s for s in CronStats.objects}
    for group in CronGroup.objects:
        gname = group.name
        labels = {'group': gname}
        _emit('cmdbsyncer_cron_group_enabled',
              1 if group.enabled else 0, labels)
        stats = stats_by_group.get(gname)
        if stats:
            _emit('cmdbsyncer_cron_group_running',
                  1 if stats.is_running else 0, labels)
            _emit('cmdbsyncer_cron_group_failure',
                  1 if stats.failure else 0, labels)
            _emit('cmdbsyncer_cron_group_last_start_timestamp_seconds',
                  stats.last_start.timestamp() if stats.last_start else 0,
                  labels)
            _emit('cmdbsyncer_cron_group_last_end_timestamp_seconds',
                  stats.last_ended.timestamp() if stats.last_ended else 0,
                  labels)
            _emit('cmdbsyncer_cron_group_last_success_timestamp_seconds',
                  stats.last_success_at.timestamp() if stats.last_success_at else 0,
                  labels)
            if stats.last_start and stats.last_ended:
                duration = (stats.last_ended - stats.last_start).total_seconds()
                _emit('cmdbsyncer_cron_group_last_duration_seconds',
                      max(0, duration), labels)
            _emit('cmdbsyncer_cron_group_next_run_timestamp_seconds',
                  stats.next_run.timestamp() if stats.next_run else 0,
                  labels)

    # --- Hosts / Objects
    _metric('cmdbsyncer_hosts_total',
            'Number of host documents currently known to the syncer')
    _metric('cmdbsyncer_hosts_stale_24h_total',
            'Hosts whose last_import_seen is older than 24h')

    _emit('cmdbsyncer_hosts_total',
          Host.objects(is_object=False).count())
    from datetime import datetime, timedelta  # pylint: disable=import-outside-toplevel
    cutoff = datetime.now() - timedelta(hours=24)
    _emit('cmdbsyncer_hosts_stale_24h_total',
          Host.objects(is_object=False, last_import_seen__lt=cutoff).count())

    # --- Scrape marker
    _metric('cmdbsyncer_metrics_scrape_duration_seconds',
            'Time the syncer spent building this metrics response',
            mtype='gauge')
    _emit('cmdbsyncer_metrics_scrape_duration_seconds',
          round(time.time() - now, 4))

    return '\n'.join(lines) + '\n'


@PROMETHEUS_BP.route('/metrics')
@require_api_role('metrics')
def metrics():
    try:
        body = _metrics_text()
    except Exception:  # pylint: disable=broad-exception-caught
        log.exception("Metrics generation failed")
        # Emit a degraded response that Prometheus parses but flags:
        body = (
            '# HELP cmdbsyncer_scrape_error 1 when the last scrape failed\n'
            '# TYPE cmdbsyncer_scrape_error gauge\n'
            'cmdbsyncer_scrape_error 1\n'
        )
    return Response(body, mimetype='text/plain; version=0.0.4; charset=utf-8')


def register_blueprint(app):
    if 'prometheus' in app.blueprints:
        return
    app.register_blueprint(PROMETHEUS_BP)
    # CSRF exemption: scrapers send vanilla GETs, no form token.
    try:
        from application import csrf  # pylint: disable=import-outside-toplevel
        csrf.exempt(PROMETHEUS_BP)
    except ImportError:
        pass
    log.info("Prometheus metrics endpoint registered at /metrics")
