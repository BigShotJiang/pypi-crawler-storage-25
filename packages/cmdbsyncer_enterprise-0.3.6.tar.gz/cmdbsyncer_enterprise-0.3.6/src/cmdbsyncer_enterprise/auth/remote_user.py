"""
Remote user login handler.

Invoked by the OSS `auth.views.login` view via the enterprise hook registry.
Receives the Flask request and returns a matching User instance (or None).
"""
from application.models.user import User


def login_handler(request):
    """Look up the user named by `request.remote_user`. Returns User or None."""
    name = request.remote_user
    if not name:
        return None

    user_result = User.objects(name=name, disabled__ne=True)
    if not user_result:
        return None

    return user_result[0]
