"""
LDAP login handler.

Invoked by the OSS `auth.views.login` view via the enterprise hook registry.
Receives email and plaintext password, returns a matching User instance on
successful LDAP bind, or None to let the OSS code fall through to local auth.
"""
import logging
from datetime import datetime

from flask import current_app
from ldap3 import Server, Connection, ALL, SUBTREE, BASE
from ldap3.core.exceptions import LDAPException
from ldap3.utils.dn import safe_dn

from application.models.user import User

log = logging.getLogger(__name__)


def _username_from_email(email):
    return email.split('@', 1)[0]


def _extract_attrs(entry, name_attr):
    groups = [str(g) for g in entry['memberOf']] if 'memberOf' in entry else []
    name = str(entry[name_attr]) if name_attr in entry else None
    return {'groups': groups, 'name': name}


def _read_user_attrs(conn, user_dn, name_attr):
    conn.search(
        search_base=user_dn,
        search_filter='(objectClass=*)',
        search_scope=BASE,
        attributes=['memberOf', name_attr],
    )
    if not conn.entries:
        return {'groups': [], 'name': None}
    return _extract_attrs(conn.entries[0], name_attr)


def _direct_bind(server, template, email, password, name_attr):
    user_dn = template.format(username=_username_from_email(email), email=email)
    conn = Connection(server, user=user_dn, password=password, auto_bind=True)
    attrs = _read_user_attrs(conn, user_dn, name_attr)
    conn.unbind()
    return attrs


def _search_bind(server, config, email, password):
    bind_user = config['LDAP_BIND_USER']
    bind_pw = config['LDAP_BIND_PASSWORD']
    search_base = config['LDAP_SEARCH_BASE']
    search_filter = config['LDAP_SEARCH_FILTER'].format(
        email=email, username=_username_from_email(email)
    )
    name_attr = config['LDAP_NAME_ATTR']

    conn = Connection(server, user=bind_user, password=bind_pw, auto_bind=True)
    conn.search(
        search_base=search_base,
        search_filter=search_filter,
        search_scope=SUBTREE,
        attributes=['memberOf', name_attr],
    )
    if not conn.entries:
        conn.unbind()
        return None

    entry = conn.entries[0]
    user_dn = entry.entry_dn
    attrs = _extract_attrs(entry, name_attr)
    conn.unbind()

    user_conn = Connection(server, user=user_dn, password=password, auto_bind=True)
    user_conn.unbind()
    return attrs


def _group_matches(required, groups):
    target = safe_dn(required).lower()
    return any(safe_dn(g).lower() == target for g in groups)


def _resolve_user(email, attrs, auto_create):
    """
    Look up a local user by email. Returns (user, is_new) on success,
    (None, False) when the lookup should block the login.
    """
    user_result = User.objects(email=email)
    if user_result:
        user = user_result[0]
        if user.disabled:
            log.info("LDAP bind ok for %s but local user is disabled", email)
            return None, False
        return user, False

    if not auto_create:
        log.info("LDAP bind ok for %s but no matching local user exists", email)
        return None, False

    log.info("Auto-creating LDAP user %s", email)
    user = User(
        email=email,
        name=(attrs.get('name') or email),
        date_added=datetime.now(),
    )
    return user, True


def _apply_role_mapping(user, mapping, groups):
    """Recompute user.roles/api_roles/global_admin from LDAP group memberships."""
    if not mapping:
        return False

    norm_groups = {safe_dn(g).lower() for g in groups}

    new_roles = set()
    new_api_roles = set()
    global_admin = False
    for group_dn, perms in mapping.items():
        if safe_dn(group_dn).lower() not in norm_groups:
            continue
        new_roles.update(perms.get('roles', []))
        new_api_roles.update(perms.get('api_roles', []))
        if perms.get('global_admin'):
            global_admin = True

    changed = False
    if set(user.roles or []) != new_roles:
        user.roles = sorted(new_roles)
        changed = True
    if set(user.api_roles or []) != new_api_roles:
        user.api_roles = sorted(new_api_roles)
        changed = True
    if bool(user.global_admin) != global_admin:
        user.global_admin = global_admin
        changed = True
    return changed


def login_handler(email, password):
    """
    Authenticate `email`/`password` against LDAP. On successful bind the local
    user is looked up (or auto-created) and their roles are synced from the
    configured LDAP_ROLE_MAPPING. Returns the User instance or None.
    Raises on configuration/connection errors.
    """
    if not email or not password:
        return None

    config = current_app.config
    if not config.get('LDAP_SERVER'):
        raise RuntimeError("LDAP_SERVER not configured")

    server = Server(config['LDAP_SERVER'], get_info=ALL)
    template = config.get('LDAP_USER_DN_TEMPLATE')
    name_attr = config.get('LDAP_NAME_ATTR') or 'cn'

    try:
        if template:
            attrs = _direct_bind(server, template, email, password, name_attr)
        else:
            if not config.get('LDAP_BIND_USER'):
                raise RuntimeError(
                    "LDAP_USER_DN_TEMPLATE or LDAP_BIND_USER must be configured"
                )
            attrs = _search_bind(server, config, email, password)
            if attrs is None:
                log.info("LDAP user not found for %s", email)
                return None
    except LDAPException as exp:
        log.info("LDAP bind failed for %s: %s", email, exp)
        return None

    groups = attrs['groups']
    required_group = config.get('LDAP_REQUIRED_GROUP')
    if required_group and not _group_matches(required_group, groups):
        log.info("LDAP user %s not in required group %s", email, required_group)
        return None

    user, is_new = _resolve_user(email, attrs, config.get('LDAP_AUTO_CREATE', True))
    if user is None:
        return None

    role_changed = _apply_role_mapping(
        user, config.get('LDAP_ROLE_MAPPING') or {}, groups,
    )
    if is_new or role_changed:
        user.save()
    return user
