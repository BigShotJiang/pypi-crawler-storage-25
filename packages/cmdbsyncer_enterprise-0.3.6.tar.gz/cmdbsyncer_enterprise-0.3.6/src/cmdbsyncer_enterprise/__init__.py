"""
cmdbsyncer enterprise add-on.

On import, verifies the deployed license file and registers the licensed
features with the OSS `application.enterprise` registry. A missing,
malformed or wrongly-signed license raises ImportError so the OSS code
falls back to Community Edition cleanly. Expiry is intentionally a soft
warning (every feature stays active, the GUI shows a banner) — see the
policy note in `license.py`.

Feature submodules are imported only when the corresponding license feature
is active, so customers without `scheduled_backup` never pull in `boto3`,
customers without the KeePass secrets provider never need `pykeepass`, and
so on. The license dictates the install footprint.
"""
import logging

from application.enterprise import register_feature

from .license import load_and_verify, expiry_state, host_count_state

log = logging.getLogger(__name__)

_license = load_and_verify()
_active_features = _license.get('features', [])

# Admin-view registrars run once from the OSS app at startup. Only the
# ones whose feature is licensed end up in the list, so community installs
# (and licenses without a given feature) never see the menu.
_admin_view_registrars = []

# Blueprint registrars run once from the OSS app before the admin is
# attached (so their routes beat the admin catch-all). Each feature
# that wants its own Flask routes appends a one-arg callable here.
_blueprint_registrars = []


if 'remote_user' in _active_features:
    from .auth.remote_user import login_handler as _remote_user_login_handler
    register_feature('remote_user', _remote_user_login_handler)

if 'ldap_login' in _active_features:
    from .auth.ldap_login import login_handler as _ldap_login_handler
    register_feature('ldap_login', _ldap_login_handler)

if 'secrets_manager' in _active_features:
    from .secrets import resolve_secret, register_admin_views as _register_secrets_admin_views
    register_feature('secrets_manager', resolve_secret)
    _admin_view_registrars.append(_register_secrets_admin_views)

if 'json_logging' in _active_features:
    # The license claim name is user-facing ("what you bought"), the
    # hook name is call-site-facing ("what the OSS calls"). Mapping
    # them explicitly keeps both free to change without breaking the
    # other side.
    from .observability import configure_logging as _configure_json_logging
    register_feature('json_logging')
    register_feature('configure_logging', _configure_json_logging)

if 'audit_log' in _active_features:
    # OSS calls `has_feature('audit_log')` to gate the helper and
    # `run_hook('audit_event', ...)` for each event. We deliberately
    # do NOT connect MongoEngine signals here — at this point the OSS
    # has only imported its own core models, not the plugin ones
    # (Checkmk rules, Netbox models, …). Those get imported later
    # when admin views are registered. `connect_signals()` runs from
    # inside `_register_audit_admin_views` instead, after every model
    # has had a chance to land in the MongoEngine registry.
    from .audit_log import (
        audit_event as _audit_event,
        register_admin_views as _register_audit_admin_views,
    )
    register_feature('audit_log')
    register_feature('audit_event', _audit_event)
    _admin_view_registrars.append(_register_audit_admin_views)

if 'notifications' in _active_features:
    from .notifications import (
        notify_event as _notify_event,
        register_admin_views as _register_notifications_admin_views,
    )
    register_feature('notifications')
    register_feature('notify_event', _notify_event)
    _admin_view_registrars.append(_register_notifications_admin_views)

if 'audit_siem_streaming' in _active_features:
    # Extends `audit_log` — no separate admin-view registrar because
    # the SIEM sink view ships together with the audit-log views.
    register_feature('audit_siem_streaming')

if 'webhook_signatures' in _active_features:
    from .webhook_signatures import (
        webhook_auth as _webhook_auth,
        register_admin_views as _register_webhook_signatures_admin_views,
    )
    register_feature('webhook_signatures')
    register_feature('webhook_auth', _webhook_auth)
    _admin_view_registrars.append(_register_webhook_signatures_admin_views)

if 'oidc_login' in _active_features:
    from .oidc import register_blueprint as _register_oidc_blueprint
    register_feature('oidc_login')
    _blueprint_registrars.append(_register_oidc_blueprint)

if 'prometheus_metrics' in _active_features:
    from .prometheus import register_blueprint as _register_prometheus_blueprint
    register_feature('prometheus_metrics')
    _blueprint_registrars.append(_register_prometheus_blueprint)

if 'scheduled_backup' in _active_features:
    from .backup import (
        register_admin_views as _register_backup_admin_views,
        register_all_known as _register_backup_tasks,
        connect_signals as _connect_backup_signals,
    )
    register_feature('scheduled_backup')
    # Wire mongoengine signals at import time so BackupConfig.save() in
    # the CLI / migrations / tests also fans out to its CronGroup.
    # connect_signals only touches the Document class, not the DB.
    _connect_backup_signals()

    def _register_backup(admin):
        # By the time admin views mount the DB is connected, so it's
        # finally safe to enumerate existing BackupConfigs and register
        # one cronjob task per config (task family).
        _register_backup_tasks()
        _register_backup_admin_views(admin)

    _admin_view_registrars.append(_register_backup)

if 'approval_workflow' in _active_features:
    from .approval import (
        register_admin_views as _register_approval_admin_views,
        wrap_admin_views as _wrap_admin_views_for_approval,
    )
    register_feature('approval_workflow')
    _admin_view_registrars.append(_register_approval_admin_views)
else:
    _wrap_admin_views_for_approval = None


def _register_all_blueprints(app):
    for fn in _blueprint_registrars:
        fn(app)


register_feature('register_blueprints', _register_all_blueprints)


def _register_all_admin_views(admin):
    for fn in _admin_view_registrars:
        fn(admin)
    # Approval workflow must wrap AFTER every other registrar has
    # added its views — otherwise enterprise-owned views would be
    # added post-wrap and their CRUD methods stay unwrapped.
    if _wrap_admin_views_for_approval is not None:
        _wrap_admin_views_for_approval(admin)
    # Audit signal connection runs LAST so every model class that any
    # registrar (OSS or enterprise) has imported is in the MongoEngine
    # registry. Earlier timing would miss plugin-owned models. The
    # function is idempotent so a double-invocation is safe.
    if 'audit_log' in _active_features:
        from .audit_log.signals import connect_signals  # pylint: disable=import-outside-toplevel
        connect_signals()


register_feature('register_admin_views', _register_all_admin_views)


def _license_info():
    """
    Enriched license payload for the GUI / API.

    Adds soft-warning state on top of the raw JWT claims:

    * ``expiry_state``     — 'ok' / 'expiring' / 'expired' / 'unknown'
    * ``host_count_state`` — 'ok' / 'over' (only when max_hosts > 0)
    * ``current_hosts``    — actual Host count, or None if uncapped /
                             the lookup fails (which must never break
                             the license page).

    A claim ``max_hosts`` of 0 / missing means "unlimited" and the
    host count is not queried.
    """
    info = dict(_license)
    info['expiry_state'] = expiry_state(info)
    cap = info.get('max_hosts') or 0
    info['current_hosts'] = None
    info['host_count_state'] = 'ok'
    if cap and int(cap) > 0:
        try:
            from application.models.host import Host  # pylint: disable=import-outside-toplevel
            current = Host.objects.count()
            info['current_hosts'] = current
            info['host_count_state'] = host_count_state(info, current)
        except Exception:  # pylint: disable=broad-exception-caught
            log.exception("license_info: host count lookup failed")
    return info


register_feature('license_info', _license_info)

log.info(
    "cmdbsyncer-enterprise active (license %s, customer %s, expires %s, features %s)",
    _license.get('license_id'),
    _license.get('customer'),
    _license.get('exp'),
    _license.get('features'),
)
