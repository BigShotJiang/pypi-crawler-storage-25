"""
Admin view for audit entries. Read-only, filterable, exportable.

`can_create / can_edit / can_delete` are all `False` — the audit table
is immutable from the UI. Retention pruning is a dedicated admin
action that itself records an audit entry, so operators can still
trim the collection but every trim is itself auditable.
"""
from datetime import datetime, timedelta

from flask import flash
from flask_admin.actions import action
from flask_admin.contrib.mongoengine.filters import FilterLike, FilterEqual
from flask_admin.form import rules
from flask_login import current_user
from markupsafe import Markup, escape

from application.views._form_fields import AccountSelectField
from application.views.default import DefaultModelView

from .models import AuditEntry
from .recorder import audit_event
from .siem import AuditSink
from .._ui import doc_badge, intro
from application.views._form_sections import modern_form, section


def _format_timestamp(_view, _context, model, _name):
    if model.timestamp:
        return model.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')
    return ''


def _format_outcome(_view, _context, model, _name):
    if model.outcome == 'failure':
        return Markup(
            '<span class="badge" style="background:#c0392b;color:#fff;">failure</span>'
        )
    return Markup(
        '<span class="badge" style="background:#27ae60;color:#fff;">success</span>'
    )


def _format_changes(_view, _context, model, _name):
    if not model.changes:
        return ''
    rows = []
    for field, pair in sorted(model.changes.items()):
        before = escape(str(pair.get('before', '')))
        after = escape(str(pair.get('after', '')))
        rows.append(
            f'<tr><td><code>{escape(field)}</code></td>'
            f'<td>{before}</td><td>&rarr;</td><td>{after}</td></tr>'
        )
    return Markup(
        '<table style="font-size:0.9em;border-collapse:collapse;">'
        + ''.join(rows) + '</table>'
    )


def _format_metadata(_view, _context, model, _name):
    if not model.metadata:
        return ''
    items = [f'<code>{escape(str(k))}</code>: {escape(str(v))}'
             for k, v in sorted(model.metadata.items())]
    return Markup('<br>'.join(items))


class AuditEntryView(DefaultModelView):
    """Read-only audit trail."""

    can_create = False
    can_edit = False
    can_delete = False
    can_export = True
    export_types = ['csv', 'json']

    column_extra_row_actions = []  # no clone icon

    column_default_sort = ('timestamp', True)

    column_list = (
        'timestamp', 'event_type', 'outcome',
        'actor_name', 'actor_ip',
        'target_type', 'target_name',
        'changes', 'metadata',
    )

    column_sortable_list = (
        'timestamp', 'event_type', 'outcome',
        'actor_name', 'target_type',
    )

    column_filters = (
        FilterLike('event_type', 'Event type'),
        FilterEqual('outcome', 'Outcome',
                    options=(('success', 'success'), ('failure', 'failure'))),
        FilterLike('actor_name', 'Actor'),
        FilterLike('target_type', 'Target type'),
        FilterLike('target_name', 'Target name'),
        FilterLike('actor_ip', 'Actor IP'),
    )

    column_formatters = {
        'timestamp': _format_timestamp,
        'outcome': _format_outcome,
        'changes': _format_changes,
        'metadata': _format_metadata,
    }

    column_labels = {
        'actor_name': 'Actor',
        'actor_ip': 'IP',
        'target_type': 'Target',
        'target_name': 'Target name',
    }

    page_size = 50

    @action('prune_old_entries',
            'Prune entries older than 365 days',
            'Delete all audit entries older than 365 days? This action is '
            'itself recorded in the audit log.')
    def action_prune_old_entries(self, _ids):
        """Explicit retention action — itself audited."""
        cutoff = datetime.utcnow() - timedelta(days=365)
        deleted = AuditEntry.objects(timestamp__lt=cutoff).delete()
        actor = current_user.email if current_user.is_authenticated else 'system'
        audit_event(
            'audit.pruned',
            actor_type='user',
            actor_id=str(current_user.id) if current_user.is_authenticated else None,
            actor_name=actor,
            metadata={'cutoff': cutoff.isoformat(), 'deleted': deleted},
            message=f'Pruned {deleted} audit entries older than 365 days',
        )
        flash(f'Pruned {deleted} audit entries', 'success')

    def is_accessible(self):
        return (
            current_user.is_authenticated
            and (current_user.has_right('log') or current_user.global_admin)
        )


class AuditSinkView(DefaultModelView):
    """External SIEM destinations for live audit streaming."""
    column_list = ('name', 'type', 'enabled', 'description')
    column_sortable_list = ('name', 'type', 'enabled')

    form_columns = (
        'name', 'type', 'enabled', 'description',
        'account', 'verify_tls',
        'splunk_index', 'splunk_source', 'splunk_sourcetype',
    )

    form_widget_args = {
        'splunk_index': {'placeholder': 'Splunk HEC: target index (optional)'},
        'splunk_source': {'placeholder': 'Splunk HEC: event source (optional)'},
        'splunk_sourcetype': {'placeholder': 'Splunk HEC: event sourcetype (optional)'},
    }

    form_rules = [
        doc_badge('ent_audit_log'),
        intro(
            'SIEM Sinks',
            'Fan every audit entry out to an external SIEM in real time. '
            'The local Mongo audit collection remains the primary store; '
            'this copy is write-only and lives outside the syncer, so a '
            'Mongo-savvy insider cannot retroactively tamper with it.',
        ),
        *modern_form(
            section('1', 'main', 'General',
                    'Name, sink type and activation.',
                    [rules.Field('name'),
                     rules.Field('type'),
                     rules.Field('enabled'),
                     rules.Field('description')]),
            section('2', 'cond', 'Connection',
                    'Syncer Account carrying the endpoint. Splunk HEC '
                    'and HTTPS webhook: Address = URL, Password = HEC '
                    'token / Bearer token. Syslog: Address = host, '
                    'custom field `port` overrides the default '
                    '(514 TCP / 6514 TLS).',
                    [rules.Field('account'),
                     rules.Field('verify_tls')]),
            section('3', 'out', 'Splunk HEC metadata',
                    'Optional: override Splunk index / source / sourcetype.',
                    [rules.Field('splunk_index'),
                     rules.Field('splunk_source'),
                     rules.Field('splunk_sourcetype')]),
        ),
    ]

    form_overrides = {
        'account': AccountSelectField,
    }

    def is_accessible(self):
        return (
            current_user.is_authenticated
            and (current_user.has_right('log') or current_user.global_admin)
        )


def register_admin_views(admin):
    """Hook entrypoint. Called once at startup when the license is active."""
    admin.add_view(AuditEntryView(
        AuditEntry, name="Audit Log",
        category="Compliance",
        endpoint="audit_log",
        menu_icon_type='fa', menu_icon_value='fa-history',
    ))
    admin.add_view(AuditSinkView(
        AuditSink, name="SIEM Sinks",
        category="Compliance",
        endpoint="audit_sinks",
        menu_icon_type='fa', menu_icon_value='fa-share-alt',
    ))
    # Signal connection is done from the top-level
    # `_register_all_admin_views` so it runs after *every* registrar
    # — this ensures late-imported plugin and enterprise models are
    # in the MongoEngine registry before we walk it.
