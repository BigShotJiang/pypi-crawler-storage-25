"""
MongoEngine signal handlers that auto-record CRUD on tracked models.

`pre_save` captures the pre-change snapshot so `post_save` can diff.
Sensitive fields are redacted, high-churn fields (timestamps, counters)
are ignored to keep the audit signal-to-noise ratio high.

The tracked model list is narrow on purpose — auditing Host would
produce millions of rows per sync and would drown the real events.
"""
import logging
from mongoengine import signals
from mongoengine.errors import DoesNotExist

from .recorder import audit_event

log = logging.getLogger(__name__)

# Field names we never store a before/after pair for — their content is
# either a secret or noise we don't want to flood the audit table with.
_REDACTED_FIELDS = frozenset({
    'password', 'password_crypted', 'webhook_token',
    'master_password_env', 'vault_token_env',
    'tfa_secret', 'totp_secret',
})

# Fields that flap every save and are not interesting for audit diffs.
_IGNORED_DIFF_FIELDS = frozenset({
    'last_login', 'date_password',
    'last_start', 'last_ended', 'last_success_at', 'next_run',
    'is_running', 'last_message', 'all_messages', 'pid',
    'run_once_next',
})


def _safe(value):
    """Coerce a value into something JSON/BSON-safe for the audit row."""
    if value is None:
        return None
    if isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (list, tuple, set)):
        return [_safe(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _safe(v) for k, v in value.items()}
    return str(value)


def _redact(field_name, value):
    if field_name in _REDACTED_FIELDS:
        return None if value in (None, '', False) else '***REDACTED***'
    return _safe(value)


def _capture_previous(sender, document):
    """Store the DB state on the document so post_save can diff."""
    if not document.pk:
        return
    try:
        previous = sender.objects.get(pk=document.pk)
    except DoesNotExist:
        return
    document._audit_previous = {  # pylint: disable=protected-access
        name: getattr(previous, name, None)
        for name in document._fields  # pylint: disable=protected-access
        if not name.startswith('_') and name not in _IGNORED_DIFF_FIELDS
    }


def _compute_diff(document):
    prev = getattr(document, '_audit_previous', None)
    if not prev:
        return {}
    diff = {}
    for name, old in prev.items():
        if name in _IGNORED_DIFF_FIELDS:
            continue
        new = getattr(document, name, None)
        if old != new:
            diff[name] = {
                'before': _redact(name, old),
                'after': _redact(name, new),
            }
    return diff


def _make_save_handler(prefix, tracked_fields=None):
    """
    Returns a post_save handler. `tracked_fields`, if given, restricts
    the diff to a subset — useful for models that save often but only
    a few columns are audit-worthy.
    """
    def handler(sender, document, created=False, **_kwargs):
        try:
            event_type = f"{prefix}.{'created' if created else 'updated'}"
            diff = _compute_diff(document)
            if tracked_fields is not None:
                diff = {k: v for k, v in diff.items() if k in tracked_fields}
            # Skip noisy "updated" events with no interesting field change.
            if not created and not diff:
                return
            audit_event(
                event_type,
                target_type=sender.__name__,
                target_id=str(document.id),
                target_name=str(document),
                changes=diff,
            )
        except Exception:  # pylint: disable=broad-exception-caught
            log.exception("Audit save-handler failed for %s", sender.__name__)
    return handler


def _make_delete_handler(prefix):
    def handler(sender, document, **_kwargs):
        try:
            audit_event(
                f"{prefix}.deleted",
                target_type=sender.__name__,
                target_id=str(document.id) if document.id else None,
                target_name=str(document),
            )
        except Exception:  # pylint: disable=broad-exception-caught
            log.exception("Audit delete-handler failed for %s", sender.__name__)
    return handler


def _pre_save_handler(sender, document, **_kwargs):  # pylint: disable=unused-argument
    _capture_previous(sender, document)


# Model class names to skip entirely. Either too high-volume (Host gets
# millions of writes per sync run), circular (auditing the audit log
# is recursive), or transient system state that would just add noise.
_SKIP_CLASSES = frozenset({
    'Host',                 # millions per sync
    'LogEntry',             # circular with log.log
    'CronStats',            # system state, edited by cron runner
    'State',                # change counter, updated on every request
    'AuditEntry',           # WORM / recursion
    'PendingChange',        # approval queue internals
    'NotificationState',    # transient cooldown state
    'BackupHistory',        # system-written
    'CheckmkObjectCache',   # cache
    'DefaultAttributeCache',
    'TagCache',
    'HostCache',
})

# Per-class field filter. Saves on these classes are audited *only*
# when one of the listed fields changed — everything else is silent.
# Keeps the signal-to-noise ratio high on models that get touched by
# sync code for reasons admins don't care about.
_TRACKED_FIELDS_BY_CLASS = {
    'CronGroup': {
        'name', 'enabled', 'interval', 'custom_interval_in_minutes',
        'timerange_from', 'timerange_to',
        'continue_on_error', 'webhook_enabled', 'jobs',
    },
}


def _camel_to_snake(name):
    """ExampleName → example_name. Used as the event-type prefix."""
    out = []
    for i, ch in enumerate(name):
        if ch.isupper() and i and not name[i - 1].isupper():
            out.append('_')
        out.append(ch.lower())
    return ''.join(out)


def _audit_candidates():
    """
    Walk MongoEngine's registry of concrete Document subclasses and
    return the ones owned by the app. Enterprise- and OSS-owned models
    are in scope; unrelated libraries (flask-mongoengine helpers, etc.)
    are not.
    """
    # Import lazily: mongoengine is a transitive dep so we don't want
    # to force-load it at module import time.
    from mongoengine.base.common import _document_registry  # pylint: disable=import-outside-toplevel

    candidates = []
    for key, cls in _document_registry.items():
        module = getattr(cls, '__module__', '') or ''
        if not (module.startswith('application.')
                or module.startswith('cmdbsyncer_enterprise.')):
            continue
        class_name = cls.__name__
        if class_name in _SKIP_CLASSES:
            continue
        # Skip embedded documents (they have no per-save mongo cycle).
        if not hasattr(cls, '_get_collection'):
            continue
        # Deduplication: the registry keys may include namespaced
        # aliases. Only emit each class once.
        if cls in {c for _, c in candidates}:
            continue
        candidates.append((class_name, cls))
    return candidates


_connected = set()
# Blinker's Signal.connect() uses weak references by default, so a
# receiver with no other live reference is silently garbage-collected
# — its sender list ends up empty and the signal "doesn't fire".
# `_make_save_handler` / `_make_delete_handler` return fresh closures;
# without a strong reference they would vanish the moment
# connect_signals() returns. We keep them alive in this module-level
# list so they stick for the life of the process.
_strong_handler_refs = []


def connect_signals():
    """
    Discover every concrete Document class in OSS + Enterprise and
    attach audit handlers. Missing classes (e.g. a plugin that isn't
    installed) are naturally omitted because they aren't in the
    MongoEngine registry. High-churn / circular models are filtered
    via `_SKIP_CLASSES`.

    Idempotent: each class is wired exactly once, so multiple calls
    are safe. In practice we're called from `register_admin_views` —
    once per process.
    """
    tracked, skipped = [], 0
    for class_name, model_cls in _audit_candidates():
        if model_cls in _connected:
            skipped += 1
            continue
        prefix = _camel_to_snake(class_name)
        tracked_fields = _TRACKED_FIELDS_BY_CLASS.get(class_name)

        save_handler = _make_save_handler(prefix, tracked_fields)
        delete_handler = _make_delete_handler(prefix)
        # Keep strong refs so blinker's weakref-based registry doesn't
        # garbage-collect them out of existence.
        _strong_handler_refs.extend([save_handler, delete_handler])

        signals.pre_save.connect(_pre_save_handler, sender=model_cls,
                                 weak=False)
        signals.post_save.connect(save_handler, sender=model_cls,
                                  weak=False)
        signals.post_delete.connect(delete_handler, sender=model_cls,
                                    weak=False)
        _connected.add(model_cls)
        tracked.append(f"{class_name} → {prefix}")

    log.info("Audit: tracking %d model class(es) (skipped %d already-wired): %s",
             len(tracked), skipped, ', '.join(sorted(tracked)))
