"""
SIEM streaming — optional real-time forwarding of every audit entry
to an external SIEM (Splunk HEC, syslog over TCP/TLS, HTTPS webhook).

The Mongo `AuditEntry` collection remains the primary store; this is
an additional fan-out so compliance teams get audit events in their
write-once SIEM even if someone with Mongo write access tried to
manipulate the local collection.

Delivery is async via a background thread with a bounded queue.
Failures are logged but never block the recorder — the local audit
entry has already been persisted by the time we get here.
"""
import json
import logging
import queue
import socket
import ssl
import threading
import time
from datetime import datetime, timezone

import requests

from application import db
from application.helpers.get_account import (
    AccountNotFoundError,
    get_account_by_name,
)

log = logging.getLogger(__name__)


def _resolve_account(sink, purpose):
    """Return the resolved account dict for `sink.account`.

    Raises RuntimeError with a user-facing message when the account is
    missing, disabled or not set at all.
    """
    name = (sink.account or '').strip()
    if not name:
        raise RuntimeError(f"{purpose} sink {sink.name!r} has no Account")
    try:
        return get_account_by_name(name)
    except AccountNotFoundError as exc:
        raise RuntimeError(
            f"{purpose} sink {sink.name!r}: Account {name!r} "
            f"not found or disabled"
        ) from exc


SINK_TYPES = [
    ('syslog_tcp', 'Syslog (TCP, RFC5424)'),
    ('syslog_tls', 'Syslog (TCP/TLS)'),
    ('splunk_hec', 'Splunk HEC (HTTP Event Collector)'),
    ('https_webhook', 'Generic HTTPS webhook (JSON)'),
]


class AuditSink(db.Document):
    """External SIEM target for audit-entry streaming.

    Endpoint and credentials live on the Syncer Account referenced by
    ``account``. Per sink type:

    - ``splunk_hec``    — ``address``=URL, ``password``=HEC token
    - ``https_webhook`` — ``address``=URL, ``password``=Bearer token (optional)
    - ``syslog_tcp``    — ``address``=host, ``custom_fields.port``=port (default 514)
    - ``syslog_tls``    — ``address``=host, ``custom_fields.port``=port (default 6514)
    """
    name = db.StringField(required=True, unique=True)
    type = db.StringField(choices=SINK_TYPES, required=True)
    enabled = db.BooleanField(default=True)
    description = db.StringField()

    # Syncer Account carrying the endpoint address and any token.
    account = db.StringField()
    verify_tls = db.BooleanField(default=True)

    # Splunk HEC metadata
    splunk_index = db.StringField()
    splunk_source = db.StringField()
    splunk_sourcetype = db.StringField()

    meta = {'strict': False}

    def __str__(self):
        return f"{self.name} ({self.type})"


_queue = queue.Queue(maxsize=2000)
_worker_started = threading.Lock()
_worker_running = False
_HOSTNAME = socket.gethostname()


def _start_worker():
    global _worker_running  # pylint: disable=global-statement
    with _worker_started:
        if _worker_running:
            return
        thread = threading.Thread(
            target=_worker_loop, name='audit-siem-streamer', daemon=True,
        )
        thread.start()
        _worker_running = True


def _worker_loop():
    while True:
        entry_doc = _queue.get()
        try:
            for sink in AuditSink.objects(enabled=True):
                try:
                    _send(sink, entry_doc)
                except Exception:  # pylint: disable=broad-exception-caught
                    log.exception("SIEM stream to %r failed", sink.name)
        finally:
            _queue.task_done()


def _entry_to_json(entry):
    """ECS-like JSON shape so most SIEMs pick fields up without mapping."""
    ts = entry.timestamp or datetime.now(timezone.utc)
    doc = {
        '@timestamp': ts.strftime('%Y-%m-%dT%H:%M:%S.') +
                      f'{int(ts.microsecond / 1000):03d}Z',
        'ecs': {'version': '8.11.0'},
        'event': {
            'kind': 'event',
            'category': 'audit',
            'type': entry.event_type,
            'outcome': entry.outcome,
        },
        'message': entry.message or entry.event_type,
        'host': {'name': _HOSTNAME},
        'service': {'name': 'cmdbsyncer'},
        'user': {
            'name': entry.actor_name,
            'id': entry.actor_id,
            'type': entry.actor_type,
        },
        'source': {'ip': entry.actor_ip} if entry.actor_ip else {},
        'target': {
            'type': entry.target_type,
            'id': entry.target_id,
            'name': entry.target_name,
        } if entry.target_type else {},
        'changes': entry.changes or {},
        'labels': entry.metadata or {},
    }
    if entry.trace_id:
        doc['trace'] = {'id': entry.trace_id}
    return doc


def _send(sink, doc):
    if sink.type == 'splunk_hec':
        _send_splunk_hec(sink, doc)
    elif sink.type == 'syslog_tcp':
        _send_syslog(sink, doc, use_tls=False)
    elif sink.type == 'syslog_tls':
        _send_syslog(sink, doc, use_tls=True)
    elif sink.type == 'https_webhook':
        _send_webhook(sink, doc)
    else:
        raise RuntimeError(f"Unknown sink type {sink.type!r}")


def _send_splunk_hec(sink, doc):
    account = _resolve_account(sink, 'Splunk HEC')
    url = (account.get('address') or '').strip()
    if not url:
        raise RuntimeError(
            f"Splunk HEC sink {sink.name!r}: account {account.get('name')!r} "
            f"has no address (URL)"
        )
    token = (account.get('password') or '').strip()
    if not token:
        raise RuntimeError(
            f"Splunk HEC sink {sink.name!r}: account {account.get('name')!r} "
            f"has no password (HEC token)"
        )

    hec_event = {
        'event': doc,
        'time': int(time.time()),
        'host': _HOSTNAME,
    }
    if sink.splunk_index:
        hec_event['index'] = sink.splunk_index
    if sink.splunk_source:
        hec_event['source'] = sink.splunk_source
    if sink.splunk_sourcetype:
        hec_event['sourcetype'] = sink.splunk_sourcetype

    resp = requests.post(
        url, json=hec_event,
        headers={'Authorization': f'Splunk {token}'},
        verify=bool(sink.verify_tls), timeout=10,
    )
    resp.raise_for_status()


def _send_webhook(sink, doc):
    account = _resolve_account(sink, 'Webhook')
    url = (account.get('address') or '').strip()
    if not url:
        raise RuntimeError(
            f"Webhook sink {sink.name!r}: account {account.get('name')!r} "
            f"has no address (URL)"
        )
    headers = {'Content-Type': 'application/json'}
    if token := (account.get('password') or '').strip():
        headers['Authorization'] = f'Bearer {token}'
    resp = requests.post(
        url, json=doc, headers=headers,
        verify=bool(sink.verify_tls), timeout=10,
    )
    resp.raise_for_status()


def _syslog_priority(outcome):
    # Facility 16 (local0) * 8 + severity. error → 3, warning → 4, info → 6.
    severity = 3 if outcome == 'failure' else 6
    return 16 * 8 + severity


def _syslog_frame(sink, doc):
    """RFC5424 framing with structured data from the audit entry."""
    priority = _syslog_priority(doc.get('event', {}).get('outcome', 'success'))
    timestamp = doc.get('@timestamp')
    app_name = 'cmdbsyncer'
    procid = doc.get('host', {}).get('name', '-')
    msgid = doc.get('event', {}).get('type', 'AUDIT')
    message = json.dumps(doc, separators=(',', ':'), default=str)
    return (
        f'<{priority}>1 {timestamp} {_HOSTNAME} {app_name} {procid} '
        f'{msgid} - {message}\n'
    )


def _send_syslog(sink, doc, use_tls):
    account = _resolve_account(sink, 'Syslog')
    host = (account.get('address') or '').strip()
    if not host:
        raise RuntimeError(
            f"Syslog sink {sink.name!r}: account {account.get('name')!r} "
            f"has no address (host)"
        )
    try:
        port = int(account.get('port') or (6514 if use_tls else 514))
    except (TypeError, ValueError) as exc:
        raise RuntimeError(
            f"Syslog sink {sink.name!r}: account {account.get('name')!r} "
            f"has a non-integer custom field 'port'"
        ) from exc
    frame = _syslog_frame(sink, doc).encode('utf-8')

    sock = socket.create_connection((host, port), timeout=10)
    try:
        if use_tls:
            context = ssl.create_default_context()
            if not sink.verify_tls:
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
            sock = context.wrap_socket(sock, server_hostname=host)
        octet_prefix = f'{len(frame)} '.encode('ascii')
        sock.sendall(octet_prefix + frame)
    finally:
        sock.close()


def stream(entry):
    """Public entry: enqueue a saved AuditEntry for SIEM delivery."""
    _start_worker()
    try:
        doc = _entry_to_json(entry)
        _queue.put_nowait(doc)
    except queue.Full:
        log.warning("SIEM streaming queue full, dropping audit entry")
    except Exception:  # pylint: disable=broad-exception-caught
        log.exception("SIEM streaming enqueue failed")
