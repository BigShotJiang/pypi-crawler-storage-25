"""
Audit Log (Enterprise feature: `audit_log`).

Append-only record of security- and compliance-relevant events:
  - User logins (success / failure / logout)
  - CRUD on Account, User, CronGroup, CustomAttributeRule, SecretStore,
    AccountSecretBinding (field-level diffs, sensitive values redacted)
  - Webhook triggers (accepted / rejected)
  - Cron-group runs (started / finished / failed)
  - Secret-store rotations

Records are immutable from the admin UI (`can_edit/can_delete=False`).
Retention pruning is an explicit admin action that itself logs an
audit entry.
"""
from application.helpers.plugins import register_plugin_type

from .recorder import audit_event
from .signals import connect_signals
from .views import register_admin_views

__all__ = ['audit_event', 'connect_signals', 'register_admin_views']


# SIEM streaming targets live on Syncer Accounts of these plugin types.
register_plugin_type(
    'splunk_hec',
    'Splunk HEC (HTTP Event Collector)',
    description='Outbound credentials for a Splunk HEC endpoint.',
    account_presets={'address': 'https://splunk.example.com:8088/services/collector'},
    account_custom_field_presets={},
)
register_plugin_type(
    'syslog_server',
    'Syslog server (TCP / TLS)',
    description='Outbound target for SIEM streaming over syslog.',
    account_presets={'address': 'rsyslog.example.com'},
    account_custom_field_presets={
        'port': '',   # default 514 (TCP) / 6514 (TLS)
    },
)
