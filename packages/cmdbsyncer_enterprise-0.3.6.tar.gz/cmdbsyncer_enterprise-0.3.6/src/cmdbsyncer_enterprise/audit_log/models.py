"""
Audit log storage.

One `AuditEntry` per event. Fields are flat so the default Flask-Admin
export (CSV / JSON) works without custom serialisers — compliance
auditors drop the CSV straight into Excel / their evidence folder.

Actor identifiers are stored as plain strings (not ReferenceField to
User) on purpose: users may be deleted, but audit entries must survive
forever. Foreign-key semantics would either block deletion or leave
dangling references.
"""
from application import db


ACTOR_TYPES = [
    ('user', 'User'),
    ('system', 'System'),
    ('cron', 'Cron'),
    ('api_token', 'API Token'),
    ('webhook', 'Webhook'),
    ('anonymous', 'Anonymous'),
]

OUTCOMES = [
    ('success', 'success'),
    ('failure', 'failure'),
]


class AuditEntry(db.Document):
    """Immutable audit record. Append-only from the admin UI."""

    timestamp = db.DateTimeField(required=True)

    # Who
    actor_type = db.StringField(choices=ACTOR_TYPES, default='system')
    actor_id = db.StringField()
    actor_name = db.StringField()
    actor_ip = db.StringField()

    # What
    event_type = db.StringField(required=True)
    outcome = db.StringField(choices=OUTCOMES, default='success')
    message = db.StringField()

    # On whom
    target_type = db.StringField()
    target_id = db.StringField()
    target_name = db.StringField()

    # Details
    changes = db.DictField()      # {field: {before: X, after: Y}}
    metadata = db.DictField()     # free-form

    # HTTP context
    request_method = db.StringField()
    request_path = db.StringField()
    user_agent = db.StringField()
    trace_id = db.StringField()

    meta = {
        'strict': False,
        'indexes': [
            {'fields': ['-timestamp']},
            {'fields': ['event_type']},
            {'fields': ['target_type', 'target_id']},
            {'fields': ['actor_name']},
            {'fields': ['outcome']},
        ],
    }

    def __str__(self):
        who = self.actor_name or self.actor_type or 'unknown'
        target = f" {self.target_type}:{self.target_name}" if self.target_type else ''
        return f"{self.timestamp:%Y-%m-%d %H:%M:%S} [{self.event_type}] {who}{target}"
