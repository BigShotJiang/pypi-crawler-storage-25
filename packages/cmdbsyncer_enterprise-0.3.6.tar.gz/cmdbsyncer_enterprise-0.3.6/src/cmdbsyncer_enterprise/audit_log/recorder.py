"""
Hook implementation: persist one AuditEntry per event.

Field names accepted in `context` match the OSS `audit(event_type, **)`
helper:

    actor_type, actor_id, actor_name, actor_ip
    target_type, target_id, target_name
    changes, metadata, message, outcome
    request_method, request_path, user_agent, trace_id
"""
import logging
from datetime import datetime, timezone

from application.enterprise import has_feature

from .models import AuditEntry

log = logging.getLogger(__name__)

# Whitelist of top-level context keys that map straight onto AuditEntry.
# Anything else a caller passes ends up folded into `metadata` so no
# information is silently dropped.
_TOP_LEVEL_KEYS = frozenset({
    'actor_type', 'actor_id', 'actor_name', 'actor_ip',
    'target_type', 'target_id', 'target_name',
    'changes', 'metadata', 'message', 'outcome',
    'request_method', 'request_path', 'user_agent', 'trace_id',
})


def audit_event(event_type, **context):
    """Record a single audit event. Never raises to the caller."""
    try:
        # MongoEngine signal handlers (and any other direct caller that
        # bypasses application.helpers.audit.audit) wouldn't otherwise
        # know who triggered the event. Pull actor / request context
        # from the live Flask request when one is in flight, but never
        # overwrite values the caller passed explicitly.
        from application.helpers.audit import web_context  # pylint: disable=import-outside-toplevel
        for key, value in web_context().items():
            context.setdefault(key, value)

        fields = {'event_type': event_type,
                  'timestamp': datetime.now(timezone.utc)}
        extra_metadata = {}
        for key, value in context.items():
            if key in _TOP_LEVEL_KEYS:
                fields[key] = value
            else:
                extra_metadata[key] = value

        if extra_metadata:
            merged = dict(fields.get('metadata') or {})
            merged.update(extra_metadata)
            fields['metadata'] = merged

        # Default actor_type so the row is still queryable even when
        # the call site forgot to set it (e.g. system-triggered events).
        fields.setdefault('actor_type', 'system')
        fields.setdefault('outcome', 'success')

        entry = AuditEntry(**fields)
        entry.save()

        # If the notifications feature is also licensed, route the
        # audit event into the dispatcher. Kept inside the recorder
        # so plugin code that only calls `audit()` gets notifications
        # for free — no duplicate `notify()` call required.
        if has_feature('notifications'):
            try:
                from cmdbsyncer_enterprise.notifications.dispatcher import (  # pylint: disable=import-outside-toplevel
                    dispatch_audit_event,
                )
                dispatch_audit_event(entry)
            except Exception:  # pylint: disable=broad-exception-caught
                log.exception(
                    "Notification dispatch for audit %s failed", event_type,
                )

        # If SIEM streaming is licensed, fan the entry out to all
        # configured external sinks (Splunk HEC / syslog / webhook).
        if has_feature('audit_siem_streaming'):
            try:
                from .siem import stream  # pylint: disable=import-outside-toplevel
                stream(entry)
            except Exception:  # pylint: disable=broad-exception-caught
                log.exception("SIEM streaming for %s failed", event_type)
    except Exception:  # pylint: disable=broad-exception-caught
        log.exception("Failed to record audit event %s", event_type)
