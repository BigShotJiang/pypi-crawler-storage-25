"""
Template-side hooks for the approval workflow.

Exposes `pending_approval_count` and `pending_approval_url` to every
rendered template so the navbar can show "N waiting" without each
view having to pass the count explicitly. Counting is scoped to the
current user's visibility: if they can't access the queue, they see
nothing.
"""
import logging

from flask_login import current_user

log = logging.getLogger(__name__)


def _pending_count():
    """Zero on any error — we never want the navbar to crash."""
    try:
        if not current_user or not current_user.is_authenticated:
            return 0
        # Same access rule as the PendingChangeView: 'account' role or
        # global_admin. Read cheap: count-only, no documents fetched.
        if not (current_user.has_right('account')
                or current_user.global_admin):
            return 0
        from .models import PendingChange  # pylint: disable=import-outside-toplevel
        return PendingChange.objects(status='pending').count()
    except Exception:  # pylint: disable=broad-exception-caught
        return 0


def _pending_url():
    """URL for the badge to link to."""
    try:
        from flask import url_for  # pylint: disable=import-outside-toplevel
        return url_for('pending_changes.index_view')
    except Exception:  # pylint: disable=broad-exception-caught
        return '#'


def register_context_processor(app):
    """Attach the context processor once, at admin-view registration time."""
    @app.context_processor
    def _inject():
        return {
            'pending_approval_count': _pending_count(),
            'pending_approval_url': _pending_url(),
        }
