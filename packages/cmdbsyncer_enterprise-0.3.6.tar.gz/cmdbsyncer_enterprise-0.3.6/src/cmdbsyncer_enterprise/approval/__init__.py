"""
4-Eyes Approval Workflow (Enterprise feature: `approval_workflow`).

Configurable per-resource-type gate: mutations on gated types are
queued as `PendingChange` rows instead of hitting Mongo directly.
A second admin reviews the diff and approves or rejects. The
requester cannot approve their own submission (hard gate).

Integrates with the other enterprise features:
  - Audit Log: every submit / approve / reject is audited
  - Notifications: approval events fan out to operators
  - Secrets redaction: sensitive fields are masked in the diff view
    but the raw value is kept so the change can still be applied
"""
from .intercept import wrap_admin_views
from .views import register_admin_views

__all__ = ['wrap_admin_views', 'register_admin_views']
