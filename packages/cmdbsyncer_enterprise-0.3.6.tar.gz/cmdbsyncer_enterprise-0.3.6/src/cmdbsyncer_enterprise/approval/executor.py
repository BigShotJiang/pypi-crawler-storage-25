"""
Apply an approved pending change to the target collection.

We bypass MongoEngine and write through the raw pymongo driver so
nested EmbeddedDocuments, ReferenceFields and dynamic sub-docs
round-trip byte-for-byte — `setattr()`-based restoration would need
each field type's deserialiser, which is fragile.

The admin form's own validation already ran at submit time, so the
stored payload is known-good.
"""
import logging
from datetime import datetime

from bson import ObjectId

from .classes import RESOURCE_CLASSES

log = logging.getLogger(__name__)


class ApplyError(Exception):
    """Raised when applying an approved change fails."""


def _prepare_payload(payload):
    """Strip `_id`; cast stringified ObjectIds back to ObjectId where sensible."""
    if not payload:
        return {}
    data = dict(payload)
    data.pop('_id', None)
    return data


def apply_pending(pc):
    """
    Apply a pending change. Updates `pc` with the outcome fields and
    saves it back.
    """
    model_class = RESOURCE_CLASSES.get(pc.resource_type)
    if model_class is None:
        raise ApplyError(
            f"Resource type {pc.resource_type!r} not available on this instance"
        )

    collection = model_class._get_collection()  # pylint: disable=protected-access

    try:
        if pc.operation == 'create':
            data = _prepare_payload(pc.after_payload)
            result = collection.insert_one(data)
            pc.resource_id = str(result.inserted_id)
        elif pc.operation == 'update':
            if not pc.resource_id:
                raise ApplyError("Update PendingChange has no resource_id")
            data = _prepare_payload(pc.after_payload)
            # replace_one is used rather than $set so deletions of
            # fields (setting them to None or removing keys) are
            # honoured — $set would leave stale fields behind.
            try:
                oid = ObjectId(pc.resource_id)
            except Exception as exp:  # pylint: disable=broad-exception-caught
                raise ApplyError(f"Invalid resource_id: {exp}") from exp
            result = collection.replace_one({'_id': oid}, data)
            if result.matched_count == 0:
                raise ApplyError(
                    "Target document no longer exists (was it deleted "
                    "outside the approval workflow?)"
                )
        elif pc.operation == 'delete':
            if not pc.resource_id:
                raise ApplyError("Delete PendingChange has no resource_id")
            try:
                oid = ObjectId(pc.resource_id)
            except Exception as exp:  # pylint: disable=broad-exception-caught
                raise ApplyError(f"Invalid resource_id: {exp}") from exp
            result = collection.delete_one({'_id': oid})
            if result.deleted_count == 0:
                raise ApplyError(
                    "Target document no longer exists"
                )
        else:
            raise ApplyError(f"Unknown operation {pc.operation!r}")

        pc.status = 'applied'
        pc.applied_at = datetime.utcnow()
        pc.error_message = None
    except ApplyError:
        raise
    except Exception as exp:  # pylint: disable=broad-exception-caught
        raise ApplyError(str(exp)) from exp
    finally:
        pc.save()
