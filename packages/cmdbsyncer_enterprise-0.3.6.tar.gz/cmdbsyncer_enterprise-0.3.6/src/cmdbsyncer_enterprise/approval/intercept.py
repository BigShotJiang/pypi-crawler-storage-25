"""
Flask-Admin view interception.

At app startup we iterate `admin._views`, and for every ModelView
whose model is present in `RESOURCE_CLASSES` we wrap its
`create_model` / `update_model` / `delete_model` methods. The
wrappers check a short-TTL cache: if an `ApprovalPolicy` is
enabled for this model, the mutation is queued as a `PendingChange`
instead of being persisted.

Policies can be created/updated at runtime; the TTL cache (5s)
makes the lookup cheap without requiring a restart after policy
changes.
"""
import logging
import time
from datetime import datetime

from flask import flash
from flask_login import current_user
from mongoengine.errors import DoesNotExist

from application.helpers.audit import audit
from application.helpers.notify import notify

from .classes import RESOURCE_CLASSES, EXCLUDED_MODEL_NAMES
from .models import ApprovalPolicy, PendingChange
from .serialize import serialize

log = logging.getLogger(__name__)

_CACHE_TTL = 5
_gated_cache = {}  # model_name -> (timestamp, bool)


def _is_gated(model_name):
    now = time.time()
    cached = _gated_cache.get(model_name)
    if cached and cached[0] > now - _CACHE_TTL:
        return cached[1]
    try:
        ApprovalPolicy.objects.get(resource_type=model_name, enabled=True)
        value = True
    except DoesNotExist:
        value = False
    _gated_cache[model_name] = (now, value)
    return value


def _current_user_tuple():
    try:
        if current_user and current_user.is_authenticated:
            return (str(current_user.id),
                    current_user.email or current_user.name or 'unknown')
    except Exception:  # pylint: disable=broad-exception-caught
        pass
    return (None, 'system')


def _emit_submitted(pc):
    uid, uname = _current_user_tuple()
    # The audit entry records the *queueing*, not the actual resource
    # mutation — the mutation only happens once a different admin
    # clicks Approve. We spell that out in the `message` so log
    # readers don't misread the `success` outcome as "the resource
    # was changed".
    audit('approval.submitted',
          actor_type='user', actor_id=uid, actor_name=uname,
          target_type=pc.resource_type,
          target_id=pc.resource_id, target_name=pc.resource_name,
          message=(f'Queued for approval — {pc.resource_type} '
                   f'`{pc.resource_name}` is NOT yet modified '
                   f'(pending #{pc.id}).'),
          metadata={'operation': pc.operation,
                    'stage': 'queued',
                    'pending_change_id': str(pc.id)})
    notify('approval.submitted', severity='warning', source='approval',
           title=f"Approval requested: {pc.operation} {pc.resource_type} "
                 f"{pc.resource_name or 'new'}",
           message=(f"{uname} submitted a {pc.operation} on "
                    f"{pc.resource_type} `{pc.resource_name}` — "
                    f"needs a second admin."),
           dedup_key=f'approval:submitted:{pc.id}',
           details={'requester': uname,
                    'operation': pc.operation,
                    'resource_type': pc.resource_type,
                    'resource_name': pc.resource_name or ''})


def _queue_create(model_class, form):
    temp = model_class()
    form.populate_obj(temp)
    uid, uname = _current_user_tuple()
    pc = PendingChange(
        resource_type=model_class.__name__,
        resource_id=None,
        resource_name=str(temp) or None,
        operation='create',
        before_payload={},
        after_payload=serialize(temp),
        requester_id=uid, requester_name=uname,
        submitted_at=datetime.utcnow(),
    )
    pc.save()
    _emit_submitted(pc)
    flash('Change submitted for approval — another admin must approve '
          'it before it takes effect.', 'info')
    # Return the unsaved instance so Flask-Admin's create_view treats
    # this as success and redirects instead of re-rendering the form.
    return temp


def _queue_update(model_class, form, existing):
    before = serialize(existing)
    # Populate a *cloned* instance so the live DB object stays
    # untouched — `form.populate_obj` mutates in place.
    clone_data = existing.to_mongo().to_dict()
    clone = model_class._from_son(clone_data)  # pylint: disable=protected-access
    form.populate_obj(clone)
    after = serialize(clone)

    uid, uname = _current_user_tuple()
    pc = PendingChange(
        resource_type=model_class.__name__,
        resource_id=str(existing.id),
        resource_name=str(existing),
        operation='update',
        before_payload=before,
        after_payload=after,
        requester_id=uid, requester_name=uname,
        submitted_at=datetime.utcnow(),
    )
    pc.save()
    _emit_submitted(pc)
    flash('Change submitted for approval — the original record is '
          'unchanged until a second admin approves.', 'info')
    return True


def _queue_delete(model_class, existing):
    uid, uname = _current_user_tuple()
    pc = PendingChange(
        resource_type=model_class.__name__,
        resource_id=str(existing.id),
        resource_name=str(existing),
        operation='delete',
        before_payload=serialize(existing),
        after_payload={},
        requester_id=uid, requester_name=uname,
        submitted_at=datetime.utcnow(),
    )
    pc.save()
    _emit_submitted(pc)
    flash('Deletion submitted for approval — the record stays in place '
          'until a second admin approves.', 'info')
    return True


def _patch_view(view, model_class):
    """Wrap a single Flask-Admin view's CRUD methods."""
    name = model_class.__name__
    original_create = view.create_model
    original_update = view.update_model
    original_delete = view.delete_model

    def create_model(form):
        if not _is_gated(name):
            return original_create(form)
        try:
            return _queue_create(model_class, form)
        except Exception as exp:  # pylint: disable=broad-exception-caught
            log.exception("Approval: queue_create failed for %s", name)
            flash(f'Could not queue change: {exp}', 'error')
            return False

    def update_model(form, model):
        if not _is_gated(name):
            return original_update(form, model)
        try:
            return _queue_update(model_class, form, model)
        except Exception as exp:  # pylint: disable=broad-exception-caught
            log.exception("Approval: queue_update failed for %s", name)
            flash(f'Could not queue change: {exp}', 'error')
            return False

    def delete_model(model):
        if not _is_gated(name):
            return original_delete(model)
        try:
            return _queue_delete(model_class, model)
        except Exception as exp:  # pylint: disable=broad-exception-caught
            log.exception("Approval: queue_delete failed for %s", name)
            flash(f'Could not queue deletion: {exp}', 'error')
            return False

    view.create_model = create_model
    view.update_model = update_model
    view.delete_model = delete_model


def wrap_admin_views(admin):
    """Install the interception on every tracked ModelView."""
    wrapped = 0
    for view in admin._views:  # pylint: disable=protected-access
        model = getattr(view, 'model', None)
        if model is None:
            continue
        name = model.__name__
        if name in EXCLUDED_MODEL_NAMES:
            continue
        if name not in RESOURCE_CLASSES:
            # Model isn't on the gated list at all — skip to keep the
            # no-policy path identical to the unwrapped one.
            continue
        _patch_view(view, model)
        wrapped += 1
    log.info("Approval: wrapped %d admin view(s)", wrapped)
