"""
Approval queue storage.

`ApprovalPolicy` — which resource types require approval.
`PendingChange` — one row per queued mutation.

Payload fields carry the raw BSON-compatible dict so `replace_one`
can restore them verbatim on approve. The diff renderer redacts
sensitive fields for display; the stored value is kept intact so
applying an approved password-change actually works.
"""
from application import db
from application.models.user import User


RESOURCE_TYPES = [
    ('Account', 'Account'),
    ('User', 'User'),
    ('CronGroup', 'CronGroup'),
    ('CustomAttributeRule', 'Custom Attribute Rule'),
    ('Rule', 'Syncer Rule'),
    ('SecretStore', 'Secret Store'),
    ('AccountSecretBinding', 'Account Secret Binding'),
    ('WebhookPolicy', 'Webhook Policy'),
    ('NotificationChannel', 'Notification Channel'),
    ('NotificationRule', 'Notification Rule'),
    ('BackupConfig', 'Backup Config'),
    ('AuditSink', 'Audit SIEM Sink'),
]

OPERATIONS = [
    ('create', 'create'),
    ('update', 'update'),
    ('delete', 'delete'),
]

STATUSES = [
    ('pending', 'pending'),
    ('approved', 'approved'),
    ('rejected', 'rejected'),
    ('applied', 'applied'),
    ('error', 'error'),
]


class SelfApprovalGrant(db.Document):
    """
    Break-glass permission: users listed here may approve their own
    submissions. Stored separately from the OSS `User` so activating
    it leaves the community schema untouched, and so revoking it is
    a clean `.delete()` on this collection — no field to reset on
    the user document.

    Every self-approval produced under a grant emits a distinct
    `approval.self_approved` audit event, so compliance reviews can
    filter those out of the normal approval stream.

    The `user` ReferenceField deletes the grant automatically when
    the underlying User is removed — a lingering grant on a deleted
    user would be a silent security hole.
    """
    user = db.ReferenceField(document_type=User, required=True, unique=True,
                             reverse_delete_rule=2)  # CASCADE
    granted_by = db.StringField()
    granted_at = db.DateTimeField()
    reason = db.StringField()
    expires_at = db.DateTimeField()   # optional — unlimited if None

    meta = {
        'strict': False,
        'indexes': [{'fields': ['user'], 'unique': True}],
    }

    def __str__(self):
        if self.user:
            return f"self-approve: {self.user.email or self.user.name}"
        return "self-approve: <unknown user>"


class ApprovalPolicy(db.Document):
    """Which resource types require a second admin's approval."""
    resource_type = db.StringField(choices=RESOURCE_TYPES,
                                   required=True, unique=True)
    enabled = db.BooleanField(default=True)
    description = db.StringField()

    meta = {'strict': False,
            'indexes': [{'fields': ['resource_type'], 'unique': True}]}

    def __str__(self):
        return f"{self.resource_type} ({'enabled' if self.enabled else 'disabled'})"


class PendingChange(db.Document):
    """A queued mutation awaiting a second admin's decision."""
    resource_type = db.StringField(required=True)
    resource_id = db.StringField()  # None for create
    resource_name = db.StringField()
    operation = db.StringField(choices=OPERATIONS, required=True)

    # Raw BSON-compatible snapshots used for display (via the redacting
    # formatter) and for apply-on-approve (via replace_one).
    before_payload = db.DictField()
    after_payload = db.DictField()

    requester_id = db.StringField()
    requester_name = db.StringField()
    submitted_at = db.DateTimeField(required=True)

    status = db.StringField(choices=STATUSES, default='pending')
    approver_id = db.StringField()
    approver_name = db.StringField()
    decided_at = db.DateTimeField()
    reject_reason = db.StringField()
    applied_at = db.DateTimeField()
    error_message = db.StringField()

    meta = {
        'strict': False,
        'indexes': [
            {'fields': ['-submitted_at']},
            {'fields': ['status']},
            {'fields': ['resource_type', 'resource_id']},
            {'fields': ['requester_id']},
        ],
    }

    def __str__(self):
        return (f"{self.operation} {self.resource_type}:"
                f"{self.resource_name or self.resource_id or 'new'} "
                f"[{self.status}]")
