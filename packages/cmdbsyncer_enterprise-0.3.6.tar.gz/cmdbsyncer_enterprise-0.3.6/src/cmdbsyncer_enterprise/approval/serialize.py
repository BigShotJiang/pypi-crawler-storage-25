"""
Document ↔ BSON-compatible dict helpers.

The approval queue stores documents as plain dicts so MongoDB's
`replace_one` / `insert_one` can round-trip them exactly. MongoEngine's
`to_mongo()` gives us SON, which we normalise to a pure Python dict.
"""
from datetime import datetime

import bson


# Same list as the audit log — fields whose value we must never show
# in the admin diff view. The underlying payload still contains the
# real value so the change can be applied on approval.
REDACTED_FIELDS = frozenset({
    'password', 'password_crypted', 'webhook_token',
    'master_password_env', 'vault_token_env',
    'tfa_secret', 'totp_secret', 'signing_secret',
})


def _to_python(value):
    """BSON types → plain Python for Mongo-dict storage."""
    if isinstance(value, bson.ObjectId):
        return str(value)
    if isinstance(value, dict):
        return {k: _to_python(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_to_python(v) for v in value]
    if isinstance(value, datetime):
        return value
    return value


def serialize(document):
    """Dump a MongoEngine document to a plain dict (ObjectId → str)."""
    raw = document.to_mongo().to_dict()
    return _to_python(raw)


def redact_for_display(payload):
    """Return a copy of `payload` with REDACTED_FIELDS masked."""
    if not payload:
        return {}
    out = {}
    for key, value in payload.items():
        if key in REDACTED_FIELDS:
            out[key] = '***REDACTED***' if value else value
        elif isinstance(value, dict):
            out[key] = redact_for_display(value)
        else:
            out[key] = value
    return out
