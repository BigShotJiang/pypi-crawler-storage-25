"""
Admin views for Approval Policies and Pending Changes.

`ApprovalPolicyView` — who is gated
`PendingChangeView`  — the queue + Approve / Reject bulk actions

The requester-cannot-approve-own gate is enforced in the action
handlers. An "error" status entry preserves the attempt history
so operators can see why an apply failed after approval.
"""
from datetime import datetime

from flask import flash
from flask_admin.actions import action
from flask_admin.contrib.mongoengine.filters import FilterEqual, FilterLike
from flask_admin.form import rules
from flask_login import current_user
from markupsafe import Markup, escape

from application.helpers.audit import audit
from application.helpers.notify import notify
from application.views.default import DefaultModelView

from .executor import ApplyError, apply_pending
from .models import ApprovalPolicy, PendingChange, SelfApprovalGrant
from .serialize import redact_for_display
from .._ui import doc_badge, intro
from application.views._form_sections import modern_form, section


def _self_approval_allowed(user_id):
    """
    True if `user_id` is on the SelfApprovalGrant list and any
    optional expiry is still in the future. Safe for admin-path use:
    returns False on any lookup error, never raises.
    """
    from datetime import datetime  # pylint: disable=import-outside-toplevel
    from mongoengine.errors import DoesNotExist  # pylint: disable=import-outside-toplevel
    from bson import ObjectId  # pylint: disable=import-outside-toplevel
    if not user_id:
        return False
    try:
        oid = ObjectId(user_id) if not isinstance(user_id, ObjectId) else user_id
        grant = SelfApprovalGrant.objects.get(user=oid)
    except (DoesNotExist, Exception):  # pylint: disable=broad-exception-caught
        return False
    if grant.expires_at and grant.expires_at < datetime.utcnow():
        return False
    return True


# --------------------------------------------------------------------- UI helpers


def _fmt_status(_v, _c, m, _p):
    color = {
        'pending': '#f39c12',
        'approved': '#3498db',
        'rejected': '#95a5a6',
        'applied': '#27ae60',
        'error': '#c0392b',
    }.get(m.status, '#7f8c8d')
    return Markup(
        f'<span class="badge" style="background:{color};color:#fff;">'
        f'{m.status}</span>'
    )


def _fmt_dt(_v, _c, m, p):
    value = getattr(m, p)
    return value.strftime('%Y-%m-%d %H:%M:%S UTC') if value else ''


def _fmt_diff(_v, _c, m, _p):
    before = redact_for_display(m.before_payload or {})
    after = redact_for_display(m.after_payload or {})
    if m.operation == 'create':
        return _render_single_side(after, tag='new')
    if m.operation == 'delete':
        return _render_single_side(before, tag='removed')
    rows = []
    for key in sorted(set(before) | set(after)):
        if key.startswith('_'):
            continue
        b = before.get(key, '<absent>')
        a = after.get(key, '<absent>')
        if b == a:
            continue
        rows.append(
            f'<tr><td><code>{escape(str(key))}</code></td>'
            f'<td style="color:#c0392b;">{escape(str(b))}</td>'
            f'<td>&rarr;</td>'
            f'<td style="color:#27ae60;">{escape(str(a))}</td></tr>'
        )
    if not rows:
        return Markup('<em>no field change</em>')
    return Markup(
        '<table style="font-size:0.9em;border-collapse:collapse;">'
        + ''.join(rows) + '</table>'
    )


def _render_single_side(payload, tag):
    rows = [
        f'<tr><td><code>{escape(str(k))}</code></td>'
        f'<td>{escape(str(v))}</td></tr>'
        for k, v in sorted(payload.items())
        if not str(k).startswith('_')
    ]
    return Markup(
        f'<div style="font-size:0.9em;"><em>{tag}</em>'
        '<table style="border-collapse:collapse;">'
        + ''.join(rows) + '</table></div>'
    )


# --------------------------------------------------------------------- Views


class ApprovalPolicyView(DefaultModelView):
    """Which resource types require a second admin's signature."""
    column_list = ('resource_type', 'enabled', 'description')
    column_sortable_list = ('resource_type', 'enabled')
    column_editable_list = ['enabled']

    form_columns = ('resource_type', 'enabled', 'description')

    form_rules = [
        doc_badge('ent_approval_workflow'),
        intro(
            'Approval Policies',
            'Mark a resource type here and any create / update / delete on '
            'that type will stage as a <em>Pending Change</em> instead of '
            'hitting Mongo directly. A different admin then reviews the '
            'diff on the <em>Pending Changes</em> page and approves or '
            'rejects. Requester-cannot-approve-own is hard-enforced unless '
            'the user has a <em>Self-Approval Grant</em>.',
        ),
        *modern_form(
            section('1', 'main', 'Policy',
                    'Which resource type is gated by the 4-eyes flow '
                    'and whether the gate is active.',
                    [rules.Field('resource_type'),
                     rules.Field('enabled'),
                     rules.Field('description')]),
        ),
    ]

    def is_accessible(self):
        return (
            current_user.is_authenticated
            and current_user.global_admin
        )


class PendingChangeView(DefaultModelView):
    """The approval queue. Read-only; actions do the real work."""

    can_create = False
    can_edit = False
    can_delete = False
    can_export = True
    export_types = ['csv', 'json']

    column_extra_row_actions = []

    column_default_sort = ('submitted_at', True)

    column_list = (
        'submitted_at', 'resource_type', 'operation',
        'resource_name', 'requester_name',
        'status', 'approver_name', 'decided_at',
        'diff',
    )
    column_labels = {'diff': 'Changes'}
    column_sortable_list = (
        'submitted_at', 'resource_type', 'operation',
        'status', 'requester_name',
    )
    column_filters = (
        FilterEqual('status', 'Status',
                    options=[(s, s) for s in
                             ('pending', 'approved', 'rejected',
                              'applied', 'error')]),
        FilterLike('resource_type', 'Resource type'),
        FilterLike('requester_name', 'Requester'),
        FilterLike('approver_name', 'Approver'),
        FilterEqual('operation', 'Operation',
                    options=[('create', 'create'),
                             ('update', 'update'),
                             ('delete', 'delete')]),
    )

    column_formatters = {
        'status': _fmt_status,
        'submitted_at': _fmt_dt,
        'decided_at': _fmt_dt,
        'diff': _fmt_diff,
    }

    page_size = 50

    def _approver_tuple(self):
        if current_user and current_user.is_authenticated:
            return (str(current_user.id),
                    current_user.email or current_user.name)
        return (None, 'system')

    def _notify_decision(self, pc, verdict, reason=None):
        severity = 'info' if verdict == 'approved' else 'warning'
        notify(
            f'approval.{verdict}',
            severity=severity, source='approval',
            title=f'Approval {verdict}: {pc.operation} '
                  f'{pc.resource_type} {pc.resource_name}',
            message=(f'Approved by {pc.approver_name}.'
                     if verdict == 'approved'
                     else f'Rejected by {pc.approver_name}'
                          + (f': {reason}' if reason else '')),
            dedup_key=f'approval:{verdict}:{pc.id}',
            details={'requester': pc.requester_name,
                     'approver': pc.approver_name,
                     'resource_type': pc.resource_type,
                     'resource_name': pc.resource_name or ''},
        )

    @action('approve', 'Approve selected',
            'Approve the selected pending change(s)? The mutation will '
            'be applied immediately.')
    def action_approve(self, ids):
        aid, aname = self._approver_tuple()
        self_allowed = _self_approval_allowed(aid)
        applied, self_applied, skipped, failed = 0, 0, 0, 0
        for pc in PendingChange.objects(id__in=ids, status='pending'):
            is_self = (pc.requester_id == aid)
            if is_self and not self_allowed:
                flash(f'Cannot approve your own submission: {pc}', 'error')
                skipped += 1
                continue
            pc.approver_id = aid
            pc.approver_name = aname
            pc.decided_at = datetime.utcnow()
            pc.status = 'approved'
            pc.save()
            try:
                apply_pending(pc)
                event_type = ('approval.self_approved' if is_self
                              else 'approval.approved')
                if is_self:
                    self_applied += 1
                else:
                    applied += 1
                audit(event_type,
                      target_type=pc.resource_type,
                      target_id=pc.resource_id,
                      target_name=pc.resource_name,
                      message=(f'Approved and applied: {pc.operation} '
                               f'{pc.resource_type} `{pc.resource_name}`.'),
                      metadata={'operation': pc.operation,
                                'requester': pc.requester_name,
                                'approver': aname,
                                'stage': 'applied',
                                'self_approval': is_self,
                                'pending_change_id': str(pc.id)})
                # The apply ran through raw pymongo (replace_one /
                # insert_one / delete_one) and therefore bypassed
                # MongoEngine's pre_save/post_save signals — our
                # audit signal handlers never fire. Emit a synthetic
                # `<resource>.<operation>` entry so the target
                # resource's history is still searchable by its own
                # event_type (e.g. `account.updated`).
                resource_event = (
                    f"{pc.resource_type.lower()}."
                    f"{'created' if pc.operation == 'create' else pc.operation + 'd'}"
                )
                audit(resource_event,
                      target_type=pc.resource_type,
                      target_id=pc.resource_id,
                      target_name=pc.resource_name,
                      metadata={'via': 'approval_workflow',
                                'requester': pc.requester_name,
                                'approver': aname,
                                'pending_change_id': str(pc.id)})
                self._notify_decision(
                    pc,
                    'self_approved' if is_self else 'approved',
                )
            except ApplyError as exp:
                failed += 1
                pc.status = 'error'
                pc.error_message = str(exp)
                pc.save()
                audit('approval.apply_failed', outcome='failure',
                      target_type=pc.resource_type,
                      target_id=pc.resource_id,
                      target_name=pc.resource_name,
                      metadata={'operation': pc.operation,
                                'approver': aname,
                                'self_approval': is_self,
                                'error': str(exp),
                                'pending_change_id': str(pc.id)})
                flash(f'Apply failed for {pc}: {exp}', 'error')

        if applied:
            flash(f'Applied {applied} approved change(s)', 'success')
        if self_applied:
            flash(f'Applied {self_applied} self-approved change(s). '
                  f'Every self-approval is recorded as '
                  f'`approval.self_approved` in the audit log.',
                  'warning')
        if skipped:
            flash(f'Skipped {skipped} same-requester submission(s) '
                  f'(no self-approval grant on your account)',
                  'warning')
        if failed:
            flash(f'{failed} change(s) could not be applied — see error column',
                  'error')

    @action('reject', 'Reject selected',
            'Reject the selected pending change(s)? They will stay in '
            'the history as rejected.')
    def action_reject(self, ids):
        aid, aname = self._approver_tuple()
        self_allowed = _self_approval_allowed(aid)
        rejected, skipped = 0, 0
        for pc in PendingChange.objects(id__in=ids, status='pending'):
            if pc.requester_id == aid and not self_allowed:
                flash(f'Cannot reject your own submission: {pc}', 'error')
                skipped += 1
                continue
            pc.approver_id = aid
            pc.approver_name = aname
            pc.decided_at = datetime.utcnow()
            pc.status = 'rejected'
            # With a bulk action we can't collect a reason interactively;
            # operators can add one via a custom reject-with-reason view
            # in a future iteration.
            pc.reject_reason = 'Rejected via bulk action'
            pc.save()
            audit('approval.rejected',
                  target_type=pc.resource_type,
                  target_id=pc.resource_id,
                  target_name=pc.resource_name,
                  metadata={'operation': pc.operation,
                            'requester': pc.requester_name,
                            'approver': aname,
                            'reason': pc.reject_reason,
                            'pending_change_id': str(pc.id)})
            self._notify_decision(pc, 'rejected', pc.reject_reason)
            rejected += 1

        if rejected:
            flash(f'Rejected {rejected} change(s)', 'success')
        if skipped:
            flash(f'Skipped {skipped} same-requester submission(s)', 'warning')

    def is_accessible(self):
        return (
            current_user.is_authenticated
            and (current_user.has_right('account') or current_user.global_admin)
        )


class SelfApprovalGrantView(DefaultModelView):
    """
    Break-glass list: users allowed to approve their own submissions.

    Grants should be rare and accountable — the list view shows who
    granted what and when, every grant creation/deletion lands in the
    audit log via the generic MongoEngine signal hook, and every
    self-approval itself fires `approval.self_approved`.
    """
    column_list = ('user', 'granted_by', 'granted_at',
                   'expires_at', 'reason')
    column_sortable_list = ('granted_at', 'expires_at')

    form_columns = ('user', 'granted_by', 'granted_at',
                    'expires_at', 'reason')

    form_rules = [
        doc_badge('ent_approval_workflow'),
        intro(
            'Self-Approval Grants',
            'Break-glass permission: users on this list may approve their '
            '<em>own</em> submissions on the Pending Changes page. '
            'Every self-approval fires a distinct <code>approval.self_approved</code> '
            'audit event so compliance reviews can filter them out of the '
            'regular approval stream. Use sparingly — typically only for '
            'solo on-call scenarios. Consider setting <code>expires_at</code>.',
        ),
        *modern_form(
            section('1', 'main', 'Grantee',
                    'Which user is allowed to approve their own submissions.',
                    [rules.Field('user')]),
            section('2', 'cond', 'Grant Details',
                    'Who granted it, when and until when. A documented '
                    'reason is expected for audit review.',
                    [rules.Field('granted_by'),
                     rules.Field('granted_at'),
                     rules.Field('expires_at'),
                     rules.Field('reason')]),
        ),
    ]

    form_widget_args = {
        'expires_at': {
            'placeholder': 'Leave blank for "never expires"',
        },
        'reason': {
            'placeholder': 'Why this user is allowed to self-approve '
                           '(audit trail)',
            'rows': 2,
        },
    }

    def on_model_change(self, form, model, is_created):
        """Auto-fill `granted_by` / `granted_at` for the current admin."""
        from datetime import datetime  # pylint: disable=import-outside-toplevel
        if is_created:
            if not model.granted_at:
                model.granted_at = datetime.utcnow()
            if not model.granted_by and current_user.is_authenticated:
                model.granted_by = current_user.email or current_user.name
        return super().on_model_change(form, model, is_created)

    def is_accessible(self):
        return (
            current_user.is_authenticated
            and current_user.global_admin
        )


def register_admin_views(admin):
    admin.add_view(PendingChangeView(
        PendingChange, name="Pending Changes",
        category="Compliance",
        endpoint="pending_changes",
        menu_icon_type='fa', menu_icon_value='fa-hourglass-half',
    ))
    admin.add_view(ApprovalPolicyView(
        ApprovalPolicy, name="Approval Policies",
        category="Compliance",
        endpoint="approval_policies",
        menu_icon_type='fa', menu_icon_value='fa-user-shield',
    ))
    admin.add_view(SelfApprovalGrantView(
        SelfApprovalGrant, name="Self-Approval Grants",
        category="Compliance",
        endpoint="self_approval_grants",
        menu_icon_type='fa', menu_icon_value='fa-id-badge',
    ))

    # Template context processor so the navbar can show a waiting-
    # approvals badge without each view passing the count explicitly.
    from .templating import register_context_processor  # pylint: disable=import-outside-toplevel
    register_context_processor(admin.app)
