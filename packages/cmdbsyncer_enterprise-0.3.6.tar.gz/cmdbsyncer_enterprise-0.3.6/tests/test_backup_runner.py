"""Unit tests for the local-destination backup pipeline helpers."""
import io
import os
import shutil
import tempfile
import time
import unittest

from tests import load_real

# Load the real modules once per test run; relative imports in runner.py
# resolve via sys.modules entries set up by the bootstrap.
load_real("cmdbsyncer_enterprise.backup.models",
          os.path.join("backup", "models.py"))
runner = load_real("cmdbsyncer_enterprise.backup.runner",
                   os.path.join("backup", "runner.py"))


class _Cfg:
    def __init__(self, local_path, name, retention_days=0):
        self.local_path = local_path
        self.name = name
        self.retention_days = retention_days


class LocalDestinationTests(unittest.TestCase):
    def setUp(self):
        self.mnt = tempfile.mkdtemp(prefix="backup-test-")
        self.addCleanup(shutil.rmtree, self.mnt, ignore_errors=True)
        self.cfg = _Cfg(self.mnt, "smoke")

    def test_local_dir_creates_per_config_subdir(self):
        target = runner._local_dir(self.cfg)
        self.assertEqual(target, os.path.join(self.mnt, "smoke"))
        self.assertTrue(os.path.isdir(target))

    def test_local_dir_rejects_relative_path(self):
        with self.assertRaisesRegex(RuntimeError, "absolute"):
            runner._local_dir(_Cfg("relative/path", "x"))

    def test_local_dir_rejects_blank_path(self):
        with self.assertRaisesRegex(RuntimeError, "requires"):
            runner._local_dir(_Cfg("", "x"))

    def test_write_local_produces_file_with_correct_size(self):
        payload = b"hello " * 20_000
        path, size = runner._write_local(
            self.cfg, io.BytesIO(payload), "20260101T000000Z.gz",
        )
        self.assertEqual(path, os.path.join(self.mnt, "smoke",
                                            "20260101T000000Z.gz"))
        self.assertEqual(size, len(payload))
        self.assertEqual(os.path.getsize(path), len(payload))

    def test_write_local_leaves_no_tmp_sibling_on_success(self):
        runner._write_local(
            self.cfg, io.BytesIO(b"data"), "ok.gz",
        )
        target_dir = os.path.join(self.mnt, "smoke")
        tmps = [n for n in os.listdir(target_dir) if n.endswith(".tmp")]
        self.assertEqual(tmps, [])

    def test_write_local_cleans_up_tmp_on_failure(self):
        class Boom(io.RawIOBase):
            def __init__(self):
                self.n = 0

            def readable(self):
                return True

            def readinto(self, b):
                self.n += 1
                if self.n > 2:
                    raise RuntimeError("boom")
                b[:5] = b"part\n"
                return 5

        with self.assertRaises(RuntimeError):
            runner._write_local(self.cfg, Boom(), "fails.gz")
        target_dir = os.path.join(self.mnt, "smoke")
        self.assertFalse(os.path.exists(os.path.join(target_dir, "fails.gz")))
        tmps = [n for n in os.listdir(target_dir) if n.endswith(".tmp")]
        self.assertEqual(tmps, [])

    def test_prune_old_local_removes_files_beyond_retention(self):
        runner._local_dir(self.cfg)  # ensure directory exists
        recent = os.path.join(self.mnt, "smoke", "recent.gz")
        with open(recent, "wb") as f:
            f.write(b"recent")
        stale = os.path.join(self.mnt, "smoke", "stale.gz")
        with open(stale, "wb") as f:
            f.write(b"stale")
        old_mtime = time.time() - 10 * 86400
        os.utime(stale, (old_mtime, old_mtime))

        self.cfg.retention_days = 7
        deleted = runner._prune_old_local(self.cfg)

        self.assertEqual(deleted, 1)
        self.assertFalse(os.path.exists(stale))
        self.assertTrue(os.path.exists(recent))

    def test_prune_old_local_is_noop_when_retention_is_zero(self):
        runner._local_dir(self.cfg)
        path = os.path.join(self.mnt, "smoke", "file.gz")
        with open(path, "wb") as f:
            f.write(b"x")
        old_mtime = time.time() - 365 * 86400
        os.utime(path, (old_mtime, old_mtime))

        self.cfg.retention_days = 0
        self.assertEqual(runner._prune_old_local(self.cfg), 0)
        self.assertTrue(os.path.exists(path))


if __name__ == "__main__":
    unittest.main()
