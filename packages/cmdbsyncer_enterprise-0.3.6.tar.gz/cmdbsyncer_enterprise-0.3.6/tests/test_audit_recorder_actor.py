"""
Regression: signal-fired audit events were dropping the actor.

Before the fix, MongoEngine signal handlers (and any other direct caller
that bypasses application.helpers.audit.audit) called the recorder
without an actor — actor_type silently fell back to 'system'. The
recorder now folds in the request-bound web_context() with setdefault
semantics, so direct callers inside a request get the actor for free.
"""
import os
import sys
import unittest
from unittest.mock import MagicMock, patch

from tests import load_real

# Stub the AuditEntry model so save() doesn't touch a database. We
# capture every constructor kwarg so the test can assert what got
# persisted.
_audit_models = sys.modules.setdefault(
    "cmdbsyncer_enterprise.audit_log",
    __import__("types").ModuleType("cmdbsyncer_enterprise.audit_log"),
)
_audit_models.__path__ = [os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "src", "cmdbsyncer_enterprise", "audit_log",
)]

_models_stub = __import__("types").ModuleType(
    "cmdbsyncer_enterprise.audit_log.models")


class _CapturingAuditEntry:
    """Captures kwargs without hitting Mongo."""
    last = None

    def __init__(self, **kwargs):
        type(self).last = kwargs

    def save(self):
        return self


_models_stub.AuditEntry = _CapturingAuditEntry
sys.modules["cmdbsyncer_enterprise.audit_log.models"] = _models_stub

recorder = load_real(
    "cmdbsyncer_enterprise.audit_log.recorder",
    os.path.join("audit_log", "recorder.py"),
)


class AuditRecorderActorTests(unittest.TestCase):

    def setUp(self):
        _CapturingAuditEntry.last = None

    def test_actor_filled_from_web_context_when_caller_is_silent(self):
        """A bare audit_event() inside a request inherits the actor."""
        with patch("application.helpers.audit.web_context", return_value={
                'actor_type': 'user',
                'actor_id': 'abc123',
                'actor_name': 'alice@example.com',
                'actor_ip': '10.0.0.1',
                'request_method': 'POST',
                'request_path': '/admin/crongroup/edit/?id=1',
        }), patch.object(recorder, 'has_feature', return_value=False):
            recorder.audit_event(
                'cron_group.updated',
                target_type='CronGroup',
                target_id='1',
                target_name='nightly',
                changes={'enabled': {'before': True, 'after': False}},
            )

        captured = _CapturingAuditEntry.last
        self.assertEqual(captured['actor_type'], 'user')
        self.assertEqual(captured['actor_id'], 'abc123')
        self.assertEqual(captured['actor_name'], 'alice@example.com')
        self.assertEqual(captured['actor_ip'], '10.0.0.1')
        self.assertEqual(captured['request_method'], 'POST')
        self.assertEqual(captured['target_name'], 'nightly')

    def test_explicit_actor_wins_over_web_context(self):
        """Callers that pass an actor explicitly are never overridden."""
        with patch("application.helpers.audit.web_context", return_value={
                'actor_type': 'user',
                'actor_id': 'request-user',
                'actor_name': 'alice@example.com',
        }), patch.object(recorder, 'has_feature', return_value=False):
            recorder.audit_event(
                'webhook.fired',
                actor_type='webhook',
                actor_id='wh-7',
                actor_name='deploy-bot',
            )

        captured = _CapturingAuditEntry.last
        self.assertEqual(captured['actor_type'], 'webhook')
        self.assertEqual(captured['actor_id'], 'wh-7')
        self.assertEqual(captured['actor_name'], 'deploy-bot')

    def test_actor_defaults_to_system_outside_request_context(self):
        """No request, no explicit actor → still falls back to 'system'."""
        with patch("application.helpers.audit.web_context", return_value={}), \
                patch.object(recorder, 'has_feature', return_value=False):
            recorder.audit_event('cron.tick')

        captured = _CapturingAuditEntry.last
        self.assertEqual(captured['actor_type'], 'system')


if __name__ == "__main__":
    unittest.main()
