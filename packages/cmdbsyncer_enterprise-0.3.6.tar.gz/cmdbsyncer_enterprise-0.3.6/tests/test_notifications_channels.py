"""
Tests for the notification channel modules.

Coverage:
  - MS Teams adaptive card structure (severity colour, facts, message body)
  - Slack Block Kit structure (header, section fields, optional runbook)
  - Generic webhook HMAC signing (X-Signature-SHA256 matches body hash)

Endpoint URL, signing secret and per-integration details live on the
Syncer Account referenced by ``channel.account``; the tests stub the
account resolver to return the values directly.
"""
import hashlib
import hmac
import json
import os
import types
import unittest
from unittest.mock import patch

from tests import load_real

channels_pkg = load_real(
    "cmdbsyncer_enterprise.notifications.channels",
    os.path.join("notifications", "channels", "__init__.py"),
)
msteams = load_real(
    "cmdbsyncer_enterprise.notifications.channels.msteams",
    os.path.join("notifications", "channels", "msteams.py"),
)
slack = load_real(
    "cmdbsyncer_enterprise.notifications.channels.slack",
    os.path.join("notifications", "channels", "slack.py"),
)
webhook = load_real(
    "cmdbsyncer_enterprise.notifications.channels.webhook",
    os.path.join("notifications", "channels", "webhook.py"),
)


class _Channel(types.SimpleNamespace):
    pass


def _stub_account(target_module, account):
    """Patch ``resolve_account`` on a channel module so the test supplies
    the account dict directly instead of querying Mongo."""
    return patch.object(target_module, "resolve_account",
                        lambda channel, required=True: account)


class MSTeamsTests(unittest.TestCase):
    def test_card_contains_title_message_and_facts(self):
        channel = _Channel(name="ops", account="teams-ops")
        account = {"name": "teams-ops",
                   "address": "https://example.test/wh"}
        payload = {
            "title": "Backup failed",
            "message": "mongodump timed out",
            "severity": "error",
            "source": "backup",
            "event_type": "backup.failed",
            "details": {"attempt": 2},
        }
        with _stub_account(msteams, account), \
                patch.object(msteams.requests, "post") as post:
            post.return_value.raise_for_status.return_value = None
            msteams.send(channel, payload)

        self.assertEqual(post.call_count, 1)
        sent = post.call_args.kwargs["json"]
        body_items = sent["attachments"][0]["content"]["body"]
        title_item = body_items[0]
        self.assertEqual(title_item["text"], "Backup failed")
        self.assertEqual(title_item["color"], "attention")
        self.assertIn("mongodump timed out",
                      [b.get("text") for b in body_items
                       if b.get("type") == "TextBlock"])
        facts = [b for b in body_items if b.get("type") == "FactSet"][0]
        fact_titles = {f["title"] for f in facts["facts"]}
        self.assertIn("source", fact_titles)
        self.assertIn("attempt", fact_titles)

    def test_missing_webhook_url_raises(self):
        channel = _Channel(name="ops", account="teams-ops")
        account = {"name": "teams-ops", "address": ""}
        with _stub_account(msteams, account), \
                self.assertRaisesRegex(RuntimeError, "address"):
            msteams.send(channel, {"title": "x"})


class SlackTests(unittest.TestCase):
    def test_blocks_include_header_and_section_for_message(self):
        channel = _Channel(name="ops", account="slack-ops")
        account = {"name": "slack-ops",
                   "address": "https://hooks.slack.test/"}
        payload = {
            "title": "Rule export ok",
            "message": "42 objects updated",
            "severity": "info",
            "source": "netbox",
            "event_type": "export.success",
        }
        with _stub_account(slack, account), \
                patch.object(slack.requests, "post") as post:
            post.return_value.raise_for_status.return_value = None
            slack.send(channel, payload)

        sent = post.call_args.kwargs["json"]
        blocks = sent["attachments"][0]["blocks"]
        self.assertEqual(blocks[0]["type"], "header")
        self.assertIn("Rule export ok", blocks[0]["text"]["text"])
        section_texts = [b["text"]["text"] for b in blocks
                         if b.get("type") == "section" and "text" in b]
        self.assertTrue(any("42 objects updated" in t for t in section_texts))

    def test_mention_prepended_when_configured(self):
        channel = _Channel(name="ops", account="slack-ops")
        account = {"name": "slack-ops",
                   "address": "https://hooks.slack.test/",
                   "slack_channel": "#alerts",
                   "slack_mention": "<!subteam^S123>"}
        payload = {"title": "oh no", "severity": "critical",
                   "message": "everything"}
        with _stub_account(slack, account), \
                patch.object(slack.requests, "post") as post:
            post.return_value.raise_for_status.return_value = None
            slack.send(channel, payload)
        sent = post.call_args.kwargs["json"]
        self.assertEqual(sent["text"], "<!subteam^S123>")
        self.assertEqual(sent["channel"], "#alerts")
        self.assertIn("<!subteam^S123>", json.dumps(sent))


class WebhookTests(unittest.TestCase):
    def test_unsigned_post_uses_url_and_sets_content_type(self):
        channel = _Channel(name="gen", account="wh-gen")
        account = {"name": "wh-gen", "address": "https://wh.test/hook",
                   "password": ""}
        with _stub_account(webhook, account), \
                patch.object(webhook.requests, "post") as post:
            post.return_value.raise_for_status.return_value = None
            webhook.send(channel, {"hello": "world"})

        call = post.call_args
        self.assertEqual(call.args[0], "https://wh.test/hook")
        self.assertEqual(call.kwargs["headers"]["Content-Type"],
                         "application/json")
        self.assertNotIn("X-Signature-SHA256", call.kwargs["headers"])
        body = call.kwargs["data"]
        parsed = json.loads(body)
        self.assertEqual(parsed["payload"], {"hello": "world"})
        self.assertIsInstance(parsed["timestamp"], int)

    def test_signed_post_matches_expected_hmac(self):
        channel = _Channel(name="gen", account="wh-gen")
        account = {"name": "wh-gen", "address": "https://wh.test/hook",
                   "password": "s3cr3t"}
        with _stub_account(webhook, account), \
                patch.object(webhook.requests, "post") as post:
            post.return_value.raise_for_status.return_value = None
            webhook.send(channel, {"k": "v"})

        call = post.call_args
        body = call.kwargs["data"]
        sig_header = call.kwargs["headers"]["X-Signature-SHA256"]
        self.assertTrue(sig_header.startswith("sha256="))
        expected = hmac.new(b"s3cr3t", body, hashlib.sha256).hexdigest()
        self.assertEqual(sig_header, f"sha256={expected}")

    def test_missing_url_raises(self):
        channel = _Channel(name="gen", account="wh-gen")
        account = {"name": "wh-gen", "address": "", "password": ""}
        with _stub_account(webhook, account), \
                self.assertRaisesRegex(RuntimeError, "address"):
            webhook.send(channel, {"k": "v"})


if __name__ == "__main__":
    unittest.main()
