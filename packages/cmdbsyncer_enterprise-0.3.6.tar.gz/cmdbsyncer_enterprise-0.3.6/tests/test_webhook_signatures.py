"""
Tests for the webhook_signatures verifier.

Covers:
  - IP allowlist (IPv4, IPv6, CIDR, blank = allow-any)
  - HMAC-SHA256 signature matching with and without the sha256= prefix
  - Timestamp window enforcement
  - Header/secret misconfiguration error surface
"""
import hashlib
import hmac
import os
import time
import types
import unittest

from tests import load_real

verifier = load_real(
    "cmdbsyncer_enterprise.webhook_signatures.verifier",
    os.path.join("webhook_signatures", "verifier.py"),
)


class IPAllowlistTests(unittest.TestCase):
    def test_empty_allowlist_allows_any_remote(self):
        self.assertTrue(verifier._ip_in_allowlist("10.1.2.3", ""))
        self.assertTrue(verifier._ip_in_allowlist(None, ""))

    def test_exact_ipv4_match(self):
        self.assertTrue(verifier._ip_in_allowlist(
            "203.0.113.7", "203.0.113.7"))
        self.assertFalse(verifier._ip_in_allowlist(
            "203.0.113.8", "203.0.113.7"))

    def test_cidr_match_ipv4(self):
        self.assertTrue(verifier._ip_in_allowlist(
            "10.0.0.42", "10.0.0.0/8"))
        self.assertFalse(verifier._ip_in_allowlist(
            "11.0.0.1", "10.0.0.0/8"))

    def test_multiple_entries_comma_separated(self):
        allow = "192.0.2.1, 198.51.100.0/24"
        self.assertTrue(verifier._ip_in_allowlist("192.0.2.1", allow))
        self.assertTrue(verifier._ip_in_allowlist("198.51.100.99", allow))
        self.assertFalse(verifier._ip_in_allowlist("203.0.113.1", allow))

    def test_ipv6_cidr(self):
        self.assertTrue(verifier._ip_in_allowlist(
            "2001:db8::1", "2001:db8::/32"))
        self.assertFalse(verifier._ip_in_allowlist(
            "2001:dead::1", "2001:db8::/32"))

    def test_invalid_remote_rejected(self):
        self.assertFalse(verifier._ip_in_allowlist(
            "not-an-ip", "0.0.0.0/0"))

    def test_blank_remote_with_non_empty_allowlist_rejected(self):
        self.assertFalse(verifier._ip_in_allowlist("", "10.0.0.0/8"))

    def test_invalid_cidr_entry_is_skipped(self):
        # One bad entry mustn't invalidate the others.
        self.assertTrue(verifier._ip_in_allowlist(
            "10.0.0.1", "bogus, 10.0.0.0/8"))


class _Policy(types.SimpleNamespace):
    pass


class _Request:
    def __init__(self, headers, body=b""):
        self.headers = headers
        self._body = body

    def get_data(self):
        return self._body


class SignatureVerificationTests(unittest.TestCase):
    def setUp(self):
        self.secret = "topsecret"
        self.policy = _Policy(
            signing_secret=self.secret,
            timestamp_window_seconds=300,
        )

    def _sign(self, ts, body):
        signed = f"{ts}.".encode() + body
        return hmac.new(self.secret.encode(), signed,
                        hashlib.sha256).hexdigest()

    def test_valid_signature_passes(self):
        ts = int(time.time())
        body = b'{"event":"x"}'
        req = _Request({
            "X-Timestamp": str(ts),
            "X-Signature-SHA256": "sha256=" + self._sign(ts, body),
        }, body)
        self.assertEqual(verifier._verify_signature(self.policy, req), "ok")

    def test_valid_signature_without_sha256_prefix_passes(self):
        ts = int(time.time())
        body = b"abc"
        req = _Request({
            "X-Timestamp": str(ts),
            "X-Signature-SHA256": self._sign(ts, body),
        }, body)
        self.assertEqual(verifier._verify_signature(self.policy, req), "ok")

    def test_missing_headers_fails(self):
        req = _Request({})
        result = verifier._verify_signature(self.policy, req)
        self.assertEqual(result["status"], 401)
        self.assertIn("X-Timestamp", result["error"])

    def test_non_numeric_timestamp_fails(self):
        req = _Request({"X-Timestamp": "notanint",
                        "X-Signature-SHA256": "sha256=deadbeef"})
        result = verifier._verify_signature(self.policy, req)
        self.assertEqual(result["status"], 401)

    def test_old_timestamp_fails(self):
        old = int(time.time()) - 9999
        body = b"x"
        req = _Request({
            "X-Timestamp": str(old),
            "X-Signature-SHA256": "sha256=" + self._sign(old, body),
        }, body)
        result = verifier._verify_signature(self.policy, req)
        self.assertEqual(result["status"], 401)
        self.assertIn("window", result["error"])

    def test_missing_secret_reports_server_error(self):
        ts = int(time.time())
        req = _Request({
            "X-Timestamp": str(ts),
            "X-Signature-SHA256": "sha256=" + "0" * 64,
        }, b"")
        self.policy.signing_secret = ""
        result = verifier._verify_signature(self.policy, req)
        self.assertEqual(result["status"], 500)

    def test_signature_mismatch_fails(self):
        ts = int(time.time())
        req = _Request({
            "X-Timestamp": str(ts),
            "X-Signature-SHA256": "sha256=" + "0" * 64,
        }, b"anything")
        result = verifier._verify_signature(self.policy, req)
        self.assertEqual(result["status"], 401)
        self.assertEqual(result["error"], "Invalid signature")


if __name__ == "__main__":
    unittest.main()
