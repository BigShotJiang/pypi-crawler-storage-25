"""
Tests for enterprise auth login handlers.

Coverage:
  - remote_user: returns the matching User or None.
  - ldap_login: blank inputs short-circuit, missing server raises,
    group-mapping computes roles from LDAP memberOf.
"""
import os
import types
import unittest
from unittest.mock import MagicMock, patch

from tests import load_real

remote_user = load_real(
    "cmdbsyncer_enterprise.auth.remote_user",
    os.path.join("auth", "remote_user.py"),
)


class RemoteUserTests(unittest.TestCase):
    def setUp(self):
        self.user = types.SimpleNamespace(name="alice", disabled=False)
        self.request = types.SimpleNamespace(remote_user="alice")

    def test_missing_remote_user_returns_none(self):
        req = types.SimpleNamespace(remote_user="")
        self.assertIsNone(remote_user.login_handler(req))

    def test_user_found_is_returned(self):
        with patch.object(remote_user, "User") as User:
            User.objects.return_value = [self.user]
            result = remote_user.login_handler(self.request)
        self.assertIs(result, self.user)

    def test_user_not_found_returns_none(self):
        with patch.object(remote_user, "User") as User:
            User.objects.return_value = []
            result = remote_user.login_handler(self.request)
        self.assertIsNone(result)


# --- LDAP login --------------------------------------------------------------
# ldap_login imports ldap3 lazily at module scope. Patch the module objects so
# tests don't need a live LDAP server.

class _FakeLDAPConnection:
    def __init__(self, entries):
        self.entries = entries

    def search(self, *a, **kw):
        return None

    def unbind(self):
        return None


class _FakeLDAPEntry:
    def __init__(self, dn, attrs):
        self.entry_dn = dn
        self._attrs = attrs

    def __contains__(self, key):
        return key in self._attrs

    def __getitem__(self, key):
        return self._attrs[key]


class LDAPLoginRoleMappingTests(unittest.TestCase):
    """_apply_role_mapping is independent of ldap3 — test it directly."""

    @classmethod
    def setUpClass(cls):
        cls.ldap_login = load_real(
            "cmdbsyncer_enterprise.auth.ldap_login",
            os.path.join("auth", "ldap_login.py"),
        )

    def setUp(self):
        self.user = types.SimpleNamespace(
            roles=[], api_roles=[], global_admin=False,
        )

    def test_role_mapping_applied_from_groups(self):
        mapping = {
            "cn=admins,dc=x": {"global_admin": True, "roles": ["admin"]},
            "cn=readers,dc=x": {"api_roles": ["api_read"]},
        }
        groups = ["cn=admins,dc=x", "cn=other,dc=x"]
        changed = self.ldap_login._apply_role_mapping(self.user, mapping, groups)
        self.assertTrue(changed)
        self.assertTrue(self.user.global_admin)
        self.assertEqual(self.user.roles, ["admin"])
        self.assertEqual(self.user.api_roles, [])  # readers not matched

    def test_role_mapping_no_change_returns_false(self):
        self.user.roles = ["admin"]
        self.user.global_admin = True
        mapping = {"cn=admins,dc=x": {"global_admin": True, "roles": ["admin"]}}
        changed = self.ldap_login._apply_role_mapping(
            self.user, mapping, ["cn=admins,dc=x"],
        )
        self.assertFalse(changed)

    def test_group_match_is_case_insensitive_and_normalised(self):
        mapping = {"CN=Admins,DC=X": {"roles": ["admin"]}}
        changed = self.ldap_login._apply_role_mapping(
            self.user, mapping, ["cn=admins,dc=x"],
        )
        self.assertTrue(changed)
        self.assertEqual(self.user.roles, ["admin"])


class LDAPLoginGroupMatchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ldap_login = load_real(
            "cmdbsyncer_enterprise.auth.ldap_login",
            os.path.join("auth", "ldap_login.py"),
        )

    def test_matches_is_case_insensitive(self):
        self.assertTrue(self.ldap_login._group_matches(
            "cn=admins,dc=x",
            ["CN=Admins,DC=X", "cn=other"],
        ))

    def test_does_not_match_disjoint(self):
        self.assertFalse(self.ldap_login._group_matches(
            "cn=admins,dc=x",
            ["cn=readers,dc=x"],
        ))


if __name__ == "__main__":
    unittest.main()
