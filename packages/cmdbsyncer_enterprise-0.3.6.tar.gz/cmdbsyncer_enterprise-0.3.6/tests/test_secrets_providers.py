"""
Tests for the enterprise secret providers.

Coverage:
  - envvar: basic lookup, empty value, missing var all raise/return as expected.
  - keepass: using the dev.kdbx fixture from the OSS repo (dev/keepass/dev.kdbx)
    verify entry lookup by path and that missing entries raise.
"""
import os
import types
import unittest
from unittest.mock import patch

from tests import load_real

envvar = load_real(
    "cmdbsyncer_enterprise.secrets.providers.envvar",
    os.path.join("secrets", "providers", "envvar.py"),
)
keepass = load_real(
    "cmdbsyncer_enterprise.secrets.providers.keepass",
    os.path.join("secrets", "providers", "keepass.py"),
)


_DEV_KDBX = os.path.abspath(os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "..", "..", "cmdbsyncer-testing", "fixtures", "keepass", "dev.kdbx",
))


class EnvVarProviderTests(unittest.TestCase):
    def test_returns_value_when_var_set(self):
        with patch.dict(os.environ, {"MYSECRET": "hunter2"}, clear=False):
            self.assertEqual(envvar.fetch(None, "MYSECRET"), "hunter2")

    def test_raises_when_var_missing(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("NOPE_NEVER_SET", None)
            with self.assertRaisesRegex(RuntimeError, "not set"):
                envvar.fetch(None, "NOPE_NEVER_SET")

    def test_raises_when_var_blank(self):
        with patch.dict(os.environ, {"BLANK": ""}, clear=False):
            with self.assertRaisesRegex(RuntimeError, "empty"):
                envvar.fetch(None, "BLANK")

    def test_blank_path_is_rejected(self):
        with self.assertRaisesRegex(RuntimeError, "Empty"):
            envvar.fetch(None, "")


class _Store(types.SimpleNamespace):
    pass


@unittest.skipUnless(os.path.isfile(_DEV_KDBX),
                     f"fixture not found at {_DEV_KDBX}")
class KeePassProviderTests(unittest.TestCase):
    """Integration tests against the reproducible dev.kdbx fixture."""

    def setUp(self):
        os.environ["DEV_KEEPASS_PASSWORD"] = "test1234"
        self.store = _Store(
            id="dev",
            kdbx_path=_DEV_KDBX,
            master_password_env="DEV_KEEPASS_PASSWORD",
            keyfile_path="",
        )

    def tearDown(self):
        keepass._kp_cache.clear()
        os.environ.pop("DEV_KEEPASS_PASSWORD", None)

    def test_fetch_returns_password_for_known_path(self):
        self.assertEqual(
            keepass.fetch(self.store, "accounts/checkmk-api"),
            "secret-checkmk-api",
        )

    def test_fetch_tolerates_leading_slash(self):
        self.assertEqual(
            keepass.fetch(self.store, "/hosts/host1"),
            "secret-host1",
        )

    def test_fetch_raises_for_missing_entry(self):
        with self.assertRaisesRegex(RuntimeError, "not found"):
            keepass.fetch(self.store, "accounts/does-not-exist")

    def test_fetch_raises_for_empty_path(self):
        with self.assertRaisesRegex(RuntimeError, "Empty"):
            keepass.fetch(self.store, "")

    def test_fetch_raises_when_master_password_env_not_set(self):
        del os.environ["DEV_KEEPASS_PASSWORD"]
        keepass._kp_cache.clear()
        with self.assertRaisesRegex(RuntimeError, "DEV_KEEPASS_PASSWORD"):
            keepass.fetch(self.store, "accounts/checkmk-api")


if __name__ == "__main__":
    unittest.main()
