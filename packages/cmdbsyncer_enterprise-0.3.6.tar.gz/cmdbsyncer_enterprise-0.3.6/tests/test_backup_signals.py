"""Tests for the BackupConfig <-> CronGroup auto-sync signals."""
import os
import unittest
from unittest.mock import MagicMock, patch

from tests import load_real

cron_register_mod = load_real(
    "cmdbsyncer_enterprise.backup.cron_register",
    os.path.join("backup", "cron_register.py"),
)
signals = load_real(
    "cmdbsyncer_enterprise.backup.signals",
    os.path.join("backup", "signals.py"),
)


class _Cfg:
    def __init__(self, name, enabled=True, schedule_enabled=True,
                 interval='daily', custom_interval_in_minutes=None,
                 timerange_from='2', timerange_to='6'):
        self.name = name
        self.enabled = enabled
        self.schedule_enabled = schedule_enabled
        self.interval = interval
        self.custom_interval_in_minutes = custom_interval_in_minutes
        self.timerange_from = timerange_from
        self.timerange_to = timerange_to


class CronGroupSyncTests(unittest.TestCase):

    def test_creates_protected_group_on_first_save(self):
        config = _Cfg("smoke")
        with patch.object(signals, 'CronGroup') as Group, \
             patch.object(signals, 'GroupEntry') as Entry, \
             patch.object(signals, 'ensure_registered') as ensure:
            Group.objects.return_value.first.return_value = None
            instance = MagicMock(name="new-group")
            Group.return_value = instance

            signals._sync_cron_group(config)

            Group.assert_called_once_with(name='Backup: smoke')
            ensure.assert_called_once_with('smoke')
            self.assertTrue(instance.protected)
            self.assertTrue(instance.enabled)
            self.assertEqual(instance.interval, 'daily')
            self.assertEqual(instance.timerange_from, '2')
            self.assertEqual(instance.timerange_to, '6')
            instance.save.assert_called_once()
            Entry.assert_called_once_with(
                name='smoke', command='enterprise-backup_run:smoke',
            )

    def test_disabled_when_either_flag_off(self):
        config = _Cfg("smoke", enabled=True, schedule_enabled=False)
        with patch.object(signals, 'CronGroup') as Group, \
             patch.object(signals, 'GroupEntry'), \
             patch.object(signals, 'ensure_registered'):
            existing = MagicMock(name="existing-group")
            Group.objects.return_value.first.return_value = existing

            signals._sync_cron_group(config)

            self.assertFalse(existing.enabled)
            existing.save.assert_called_once()

    def test_drop_clears_protection_then_deletes(self):
        with patch.object(signals, 'CronGroup') as Group, \
             patch.object(signals, 'unregister') as unreg:
            existing = MagicMock(name="existing")
            existing.protected = True
            Group.objects.return_value.first.return_value = existing

            signals._drop_cron_group("smoke")

            self.assertFalse(existing.protected)
            existing.save.assert_called_once()
            existing.delete.assert_called_once()
            unreg.assert_called_once_with("smoke")

    def test_drop_is_noop_when_group_missing(self):
        with patch.object(signals, 'CronGroup') as Group, \
             patch.object(signals, 'unregister') as unreg:
            Group.objects.return_value.first.return_value = None
            signals._drop_cron_group("ghost")
            unreg.assert_called_once_with("ghost")


class TaskFamilyTests(unittest.TestCase):

    def test_task_name_is_prefixed_with_config_name(self):
        self.assertEqual(
            cron_register_mod._task_name("nightly"),
            "enterprise-backup_run:nightly",
        )

    def test_runner_closure_calls_run_backup_with_correct_name(self):
        with patch.object(cron_register_mod, 'run_backup') as run:
            task = cron_register_mod._make_runner("nightly")
            task(account="ignored", debug=True)
            run.assert_called_once_with("nightly")


if __name__ == "__main__":
    unittest.main()
