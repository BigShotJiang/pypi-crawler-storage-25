"""
Tests for the license soft-warning helpers.

Expiry is intentionally a soft warning, not a hard error: the runtime
keeps every licensed feature active and the operator sees a banner.
Same for max_hosts.
"""
import sys
import time
import types
import unittest

# Stub joserfc — license.py imports the JWT helpers at module load,
# but the helpers under test (expiry_state / host_count_state) don't
# touch them at all.
for _name in ('joserfc', 'joserfc.jwk', 'joserfc.errors'):
    sys.modules.setdefault(_name, types.ModuleType(_name))
sys.modules['joserfc'].jwt = types.SimpleNamespace(decode=lambda *a, **kw: None)
sys.modules['joserfc.jwk'].RSAKey = type('RSAKey', (), {
    'import_key': staticmethod(lambda *a, **kw: None),
})
sys.modules['joserfc.errors'].JoseError = type('JoseError', (Exception,), {})

from tests import load_real  # noqa: E402

license_mod = load_real(
    "cmdbsyncer_enterprise.license",
    "license.py",
)


class ExpiryStateTests(unittest.TestCase):

    def test_unknown_when_exp_missing(self):
        self.assertEqual(license_mod.expiry_state({}), 'unknown')

    def test_unknown_when_exp_not_numeric(self):
        self.assertEqual(license_mod.expiry_state({'exp': 'soon'}), 'unknown')

    def test_ok_when_far_in_future(self):
        future = time.time() + 365 * 86400
        self.assertEqual(license_mod.expiry_state({'exp': future}), 'ok')

    def test_expiring_inside_warn_window(self):
        soon = time.time() + 7 * 86400
        self.assertEqual(license_mod.expiry_state({'exp': soon}), 'expiring')

    def test_expired_when_exp_in_past(self):
        past = time.time() - 1
        self.assertEqual(license_mod.expiry_state({'exp': past}), 'expired')

    def test_now_arg_overrides_wallclock(self):
        # 100s before exp at fixed_now → 'expiring' because <= 30 days
        exp = 1_700_000_000
        self.assertEqual(
            license_mod.expiry_state({'exp': exp}, now=exp - 100),
            'expiring',
        )


class HostCountStateTests(unittest.TestCase):

    def test_unlimited_when_max_hosts_zero(self):
        self.assertEqual(license_mod.host_count_state({'max_hosts': 0}, 9999),
                         'ok')

    def test_unlimited_when_claim_missing(self):
        self.assertEqual(license_mod.host_count_state({}, 9999), 'ok')

    def test_unlimited_when_claim_not_numeric(self):
        self.assertEqual(
            license_mod.host_count_state({'max_hosts': 'unlimited'}, 9999),
            'ok',
        )

    def test_under_cap_is_ok(self):
        self.assertEqual(
            license_mod.host_count_state({'max_hosts': 100}, 50), 'ok',
        )

    def test_at_cap_is_ok(self):
        self.assertEqual(
            license_mod.host_count_state({'max_hosts': 100}, 100), 'ok',
        )

    def test_over_cap(self):
        self.assertEqual(
            license_mod.host_count_state({'max_hosts': 100}, 101), 'over',
        )


if __name__ == "__main__":
    unittest.main()
