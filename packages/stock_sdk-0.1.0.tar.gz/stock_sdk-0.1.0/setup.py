"""hamuna-stock-sdk - Hamuna股票数据SDK"""

from setuptools import setup, find_packages

VERSION = "0.1.0"

setup(
    name="stock-sdk",
    version=VERSION,
    description="Hamuna股票数据SDK",
    author="hamuna",
    packages=find_packages(where='stock_sdk'),
    package_dir={'': 'stock_sdk'},
    python_requires=">=3.12",
    install_requires=[
        "eltdx",
        "httpx>=0.27.0",
        "pandas>=2.0.0",
        "fake-useragent>=1.5.1",
    ]
)