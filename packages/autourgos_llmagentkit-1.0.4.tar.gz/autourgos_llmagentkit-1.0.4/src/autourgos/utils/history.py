import os
import json
from datetime import datetime
from typing import Any, Dict, List, Optional

class AgentHistoryLogger:
    """
    Logs agent interaction steps sequentially to a dynamically created markdown file
    in an 'Agent History' folder in the user's current working directory.
    """
    def __init__(self, agent_name: str, enabled: bool):
        self.agent_name = agent_name
        self.enabled = enabled
        self.filepath = None

    def start_task(self, query: str):
        if not self.enabled:
            return

        base_dir = os.path.join(os.getcwd(), "Agent History")
        os.makedirs(base_dir, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"Task_{timestamp}.md"
        self.filepath = os.path.join(base_dir, filename)

        try:
            with open(self.filepath, 'w', encoding='utf-8') as f:
                f.write(f"# Task Session: {self.agent_name}\n")
                f.write(f"**Started At:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                f.write(f"## Initial Query\n{query}\n\n---\n\n")
        except Exception as e:
            print(f"Warning: Failed to start history log: {e}")
            self.enabled = False

    def log_iteration(
        self, 
        iteration_num: int, 
        thought: Optional[str] = None, 
        tools: Optional[List[Dict[str, Any]]] = None, 
        observations: Optional[List[Any]] = None
    ):
        if not self.enabled or not self.filepath:
            return

        try:
            val_to_append = f"## Iteration {iteration_num}\n\n"
            
            if thought:
                val_to_append += f"### Thought\n{thought}\n\n"
            
            if tools:
                val_to_append += "### Action (Tools)\n"
                for t in tools:
                    # Handle varying tool formats internally
                    t_name = t.get("tool") or t.get("name") or "Unknown tool"
                    params = t.get("params", {})
                    if params is None:
                        params = {}
                        
                    # Prettify the JSON parameters safely
                    try:
                        if isinstance(params, str):
                            try:
                                params = json.loads(params)
                            except json.JSONDecodeError:
                                pass
                        
                        if isinstance(params, (dict, list)):
                            params_str = json.dumps(params, indent=2)
                        else:
                            params_str = str(params)
                    except Exception:
                        params_str = str(params)

                    val_to_append += f"**Tool:** `{t_name}`\n"
                    val_to_append += f"**Parameters:**\n```json\n{params_str}\n```\n\n"
            
            if observations:
                val_to_append += "### Observations\n"
                for obs in observations:
                    if isinstance(obs, dict) and "result" in obs:
                        tool_name = obs.get("tool", "Result")
                        # Some results might be long text or contain markdown themselves
                        val_to_append += f"**{tool_name}**:\n"
                        val_to_append += f"{obs['result']}\n\n"
                    else:
                        val_to_append += "**Result**:\n"
                        val_to_append += f"{str(obs)}\n\n"

            val_to_append += "---\n\n"

            with open(self.filepath, 'a', encoding='utf-8') as f:
                f.write(val_to_append)
                
        except Exception as e:
            print(f"Warning: Failed to append to history log: {e}")

    def log_final(self, answer: str):
        if not self.enabled or not self.filepath:
            return

        try:
            with open(self.filepath, 'a', encoding='utf-8') as f:
                f.write(f"## Final Answer\n{answer}\n")
        except Exception as e:
            print(f"Warning: Failed to finalize history log: {e}")
