﻿"""Tests for v0.13.3 incremental KV append via concat_along_seq + step_append."""

from __future__ import annotations

import torch

from tiny_turboquant.kv.compression import (
    CompressedTensor,
    TinyTurboKVCache,
)
from tiny_turboquant.kv.policy import resolve_kv_policy


def _make(seed: int, seq: int):
    g = torch.Generator().manual_seed(seed)
    return torch.randn(1, 2, seq, 16, generator=g, dtype=torch.float32)


def test_concat_along_seq_matches_full_quantize():
    x_full = _make(0, 12)
    x_a = x_full[..., :8, :].contiguous()
    x_b = x_full[..., 8:, :].contiguous()
    bits = 8
    ct_full = CompressedTensor.from_tensor(x_full, bits=bits)
    ct_a = CompressedTensor.from_tensor(x_a, bits=bits)
    ct_b = CompressedTensor.from_tensor(x_b, bits=bits)
    merged = ct_a.concat_along_seq(ct_b)
    deq_full = ct_full.dequantize(dtype=torch.float32)
    deq_merged = merged.dequantize(dtype=torch.float32)
    # Each piece used its own per-row scale/offset so the values aren't bit-identical,
    # but seq dimension must agree and the rows must be a row-wise re-quantization
    # of the corresponding rows of x_full.
    assert deq_merged.shape == deq_full.shape
    deq_a = ct_a.dequantize(dtype=torch.float32)
    deq_b = ct_b.dequantize(dtype=torch.float32)
    assert torch.allclose(deq_merged[..., :8, :], deq_a, atol=1e-5)
    assert torch.allclose(deq_merged[..., 8:, :], deq_b, atol=1e-5)


def test_step_append_keeps_old_rows_and_grows_seq():
    policy = resolve_kv_policy("fp16k-q8v")
    # Simulate two layers worth of past_key_values, each (1, 2, 8, 16).
    k0 = _make(1, 8)
    v0 = _make(2, 8)
    k1 = _make(3, 8)
    v1 = _make(4, 8)
    past_prefill = ((k0, v0), (k1, v1))
    cache = TinyTurboKVCache.from_past_key_values(past_prefill, policy, dense_dtype=torch.float32)
    assert cache.seq_len() == 8
    snap_layer0_first_rows = cache.layers[0].key.dequantize(dtype=torch.float32)[..., :8, :].clone()

    # Append one new row per layer.
    k0_new_row = torch.randn(1, 2, 1, 16)
    v0_new_row = torch.randn(1, 2, 1, 16)
    k1_new_row = torch.randn(1, 2, 1, 16)
    v1_new_row = torch.randn(1, 2, 1, 16)
    past_step = (
        (torch.cat([k0, k0_new_row], dim=-2), torch.cat([v0, v0_new_row], dim=-2)),
        (torch.cat([k1, k1_new_row], dim=-2), torch.cat([v1, v1_new_row], dim=-2)),
    )
    cache2 = cache.step_append(past_step)
    assert cache2.seq_len() == 9
    # Old rows should round-trip to the same dequantized values as before.
    after_layer0_first_rows = cache2.layers[0].key.dequantize(dtype=torch.float32)[..., :8, :]
    assert torch.allclose(after_layer0_first_rows, snap_layer0_first_rows, atol=1e-5)
