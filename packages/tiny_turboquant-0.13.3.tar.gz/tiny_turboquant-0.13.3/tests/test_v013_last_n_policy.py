"""Tests for v0.13.3 last-N layer policy and KL divergence helpers."""

from __future__ import annotations

import torch

from tiny_turboquant.kv.policy import resolve_kv_policy
from tiny_turboquant.validation.quality import (
    build_niah_prompt,
    kl_divergence_per_step,
    summarize_kl_series,
)
from tiny_turboquant.validation.backend import compare_logits


def test_last_n_policy_overrides_trailing_layers():
    p = resolve_kv_policy("fp16k-int4v-last8-fp16")
    total = 40
    middle = p.layer_policy(10, total)
    tail = p.layer_policy(35, total)
    # Middle layer keeps the base 16/4 contract.
    assert middle.key_bits == 16
    assert middle.value_bits == 4
    # Last-N tail switches to fp16 K + fp16 V.
    assert tail.key_bits == 16
    assert tail.value_bits == 16


def test_last_n_count_matches_field():
    p = resolve_kv_policy("q8k-int4v-last8-q8v")
    total = 32
    for i in range(total):
        eff = p.layer_policy(i, total)
        if i >= total - 8:
            assert eff.value_bits == 8
        else:
            assert eff.value_bits == 4


def test_kl_divergence_identical_logits_is_zero():
    g = torch.Generator().manual_seed(0)
    logits = [torch.randn(1, 32, generator=g) for _ in range(4)]
    kld = kl_divergence_per_step(logits, logits)
    assert len(kld) == 4
    for k in kld:
        assert k < 1e-6


def test_kl_divergence_positive_for_perturbed_logits():
    g = torch.Generator().manual_seed(0)
    base = [torch.randn(1, 32, generator=g) for _ in range(4)]
    cand = [b + 0.5 * torch.randn_like(b) for b in base]
    kld = kl_divergence_per_step(base, cand)
    assert all(k > 0.0 for k in kld)


def test_summarize_kl_series_fields():
    g = torch.Generator().manual_seed(0)
    base = [torch.randn(1, 32, generator=g) for _ in range(8)]
    cand = [b + 0.1 * torch.randn_like(b) for b in base]
    r = summarize_kl_series(
        prompt="x",
        baseline_policy="fp16",
        candidate_policy="fp16k-q8v",
        base_logits=base,
        cand_logits=cand,
        max_new_tokens=8,
    )
    assert r.kld_mean >= 0.0
    assert r.kld_max >= r.kld_mean
    assert 0.0 <= r.same_top1_ratio <= 1.0


def test_compare_logits_exposes_kl_and_prob_metrics():
    g = torch.Generator().manual_seed(0)
    base = [torch.randn(1, 32, generator=g) for _ in range(4)]
    cand = [b + 0.05 * torch.randn_like(b) for b in base]
    rep = compare_logits(base, cand)
    assert "kl_divergence_mean" in rep
    assert "delta_p_rms_mean" in rep
    assert "same_top5_ratio" in rep


def test_build_niah_prompt_contains_needle_digits():
    prompt, digits = build_niah_prompt(target_context_chars=500, needle_position_ratio=0.5)
    assert digits in prompt
    assert "passkey" in prompt.lower()
