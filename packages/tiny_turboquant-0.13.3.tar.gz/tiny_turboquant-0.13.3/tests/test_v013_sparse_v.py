﻿"""Tests for v0.13.3 sparse-V SDPA monkey patch."""

from __future__ import annotations

import math

import torch
import torch.nn.functional as F

from tiny_turboquant.backends.hf.sparse_v import sparse_v_sdpa


def _qkv(seed=0, b=1, h=2, q=4, k=8, d=8):
    g = torch.Generator().manual_seed(seed)
    Q = torch.randn(b, h, q, d, generator=g)
    K = torch.randn(b, h, k, d, generator=g)
    V = torch.randn(b, h, k, d, generator=g)
    return Q, K, V


def test_sparse_v_threshold_zero_matches_reference_sdpa():
    Q, K, V = _qkv()
    ref = F.scaled_dot_product_attention(Q, K, V)
    with sparse_v_sdpa(threshold=0.0):
        out = F.scaled_dot_product_attention(Q, K, V)
    # SDPA is restored on exit; the result inside should still match because
    # threshold=0 turns sparse-V into pure manual SDPA (no masking).
    assert out.shape == ref.shape
    assert torch.allclose(out, ref, atol=1e-4)


def test_sparse_v_restores_original_sdpa_on_exit():
    original = F.scaled_dot_product_attention
    with sparse_v_sdpa(threshold=1e-6):
        assert F.scaled_dot_product_attention is not original
    assert F.scaled_dot_product_attention is original


def test_sparse_v_records_skip_stats():
    Q, K, V = _qkv()
    with sparse_v_sdpa(threshold=0.5) as stats:
        F.scaled_dot_product_attention(Q, K, V)
    # With a high threshold most weights get masked, so skip ratio should be > 0.
    assert stats.calls == 1
    assert stats.total_positions > 0
    assert stats.overall_skip_ratio > 0.0


def test_sparse_v_low_threshold_yields_close_to_reference():
    Q, K, V = _qkv()
    ref = F.scaled_dot_product_attention(Q, K, V)
    with sparse_v_sdpa(threshold=1e-8):
        out = F.scaled_dot_product_attention(Q, K, V)
    # 1e-8 is below numerical noise; output should be effectively identical.
    assert torch.allclose(out, ref, atol=1e-3)
