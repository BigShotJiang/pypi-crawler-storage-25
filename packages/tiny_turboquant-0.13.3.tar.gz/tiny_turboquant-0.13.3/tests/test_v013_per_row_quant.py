﻿"""Tests for the v0.13.3 per-row affine quantizer with norm correction."""

from __future__ import annotations

import pytest
import torch

from tiny_turboquant.kv.compression import CompressedTensor


def _make_kv(shape=(1, 2, 8, 16), seed=0):
    g = torch.Generator().manual_seed(seed)
    return torch.randn(*shape, generator=g, dtype=torch.float32)


@pytest.mark.parametrize("bits", [4, 8])
def test_per_row_blocking_activates_for_block_aligned_tensors(bits: int):
    x = _make_kv((1, 2, 8, 16))
    ct = CompressedTensor.from_tensor(x, bits=bits)
    assert ct.block_axis == -2, "per-row path should activate when last_dim * bits % 8 == 0"
    # n_blocks = batch * heads * seq = 1 * 2 * 8 = 16 rows of length 16.
    assert ct.n_blocks == 16
    assert ct.scale.shape == (16,)
    assert ct.offset.shape == (16,)


def test_norm_correction_is_recorded_and_shrinks_row_error():
    x = _make_kv((1, 2, 8, 16))
    bits = 4
    with_nc = CompressedTensor.from_tensor(x, bits=bits, norm_correction=True)
    without_nc = CompressedTensor.from_tensor(x, bits=bits, norm_correction=False)
    assert with_nc.norm_correction is not None
    assert without_nc.norm_correction is None
    d_with = with_nc.dequantize(dtype=torch.float32)
    d_without = without_nc.dequantize(dtype=torch.float32)
    # Row-wise norm should be much closer to the original with norm correction.
    rows_in = x.reshape(-1, x.shape[-1])
    rows_w = d_with.reshape(-1, x.shape[-1])
    rows_wo = d_without.reshape(-1, x.shape[-1])
    err_w = (rows_in.norm(dim=-1) - rows_w.norm(dim=-1)).abs().mean()
    err_wo = (rows_in.norm(dim=-1) - rows_wo.norm(dim=-1)).abs().mean()
    assert err_w <= err_wo + 1e-6


def test_per_row_dequantize_shape_matches_input():
    x = _make_kv((1, 2, 8, 16))
    ct = CompressedTensor.from_tensor(x, bits=8)
    deq = ct.dequantize(dtype=torch.float32)
    assert deq.shape == x.shape


def test_storage_savings_for_low_bits():
    # int4 per-row should still beat fp16 dense for this shape.
    x = _make_kv((1, 2, 8, 16))
    ct = CompressedTensor.from_tensor(x, bits=4)
    dense_fp16 = x.numel() * 2
    assert ct.storage_bytes() < dense_fp16, (ct.storage_bytes(), dense_fp16)
