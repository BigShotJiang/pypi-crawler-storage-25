from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tiny_turboquant.kv.compression import CompressedTensor, TinyTurboKVCache
from tiny_turboquant.kv.policy import available_kv_policies, resolve_kv_policy


def test_v012_policy_registry_contains_backend_defaults():
    names = available_kv_policies()
    assert "fp16" in names
    assert "q8k-q8v" in names
    assert "q8k-int4v" in names
    assert resolve_kv_policy("q8k-int4v").boundary_layer_count == 2


def test_v012_compressed_tensor_roundtrip_shape_and_storage():
    torch.manual_seed(120)
    x = torch.randn(1, 2, 8, 16, dtype=torch.float32)
    c = CompressedTensor.from_tensor(x, bits=4)
    y = c.dequantize(dtype=x.dtype)
    assert y.shape == x.shape
    assert c.storage_bytes() < c.dense_bytes(dtype_bytes=4)
    assert torch.isfinite(y).all()


def test_v012_tiny_turbo_kv_cache_roundtrip_tuple():
    torch.manual_seed(121)
    past = tuple((torch.randn(1, 2, 8, 16), torch.randn(1, 2, 8, 16)) for _ in range(6))
    cache = TinyTurboKVCache.from_past_key_values(past, "q8k-int4v")
    dense = cache.to_past_key_values(dtype=torch.float32)
    assert len(dense) == 6
    assert dense[0][0].shape == past[0][0].shape
    report = cache.to_dict()
    assert report["policy"] == "q8k-int4v"
    assert report["compressed_storage_bytes"] < report["dense_fp16_bytes"]
    assert report["layer_policies"][0].endswith("boundary-q8")
    assert report["layer_policies"][2] == "q8k-int4v"


def test_v012_cli_lists_policies_without_hf_download():
    result = subprocess.run(
        [sys.executable, "-m", "tiny_turboquant.cli", "bench", "--list-policies"],
        cwd=str(__import__("pathlib").Path(__file__).resolve().parents[1]),
        check=True,
        capture_output=True,
        text=True,
    )
    assert "q8k-q8v" in result.stdout
    assert "q8k-int4v" in result.stdout


def test_v0121_kv_cache_accepts_extended_layer_entries():
    torch.manual_seed(122)
    k = torch.randn(1, 2, 8, 16)
    v = torch.randn(1, 2, 8, 16)
    aux = torch.randn(1)
    past = ((k, v, aux, "ignored"),)
    cache = TinyTurboKVCache.from_past_key_values(past, "q8k-q8v")
    dense = cache.to_past_key_values(dtype=torch.float32)
    assert len(dense) == 1
    assert len(dense[0]) == 2
    assert dense[0][0].shape == k.shape
    assert dense[0][1].shape == v.shape


class _FakeHFCache:
    def __init__(self, past):
        self._past = past

    def to_legacy_cache(self):
        return self._past


def test_v0121_kv_cache_accepts_hf_cache_object_with_extended_entries():
    torch.manual_seed(123)
    k = torch.randn(1, 2, 8, 16)
    v = torch.randn(1, 2, 8, 16)
    past = _FakeHFCache(((k, v, None),))
    cache = TinyTurboKVCache.from_past_key_values(past, "fp16")
    dense = cache.to_past_key_values(dtype=torch.float32)
    assert dense[0][0].shape == k.shape
    assert dense[0][1].shape == v.shape


def test_cache_records_new_transformers_cache_format():
    import torch
    from tiny_turboquant.kv.compression import TinyTurboKVCache

    class FakeDynamicCache:
        def __init__(self, legacy):
            self._legacy = legacy
        def to_legacy_cache(self):
            return self._legacy
        def get_seq_length(self):
            return self._legacy[0][0].shape[-2]

    k = torch.randn(1, 2, 4, 8)
    v = torch.randn(1, 2, 4, 8)
    cache = TinyTurboKVCache.from_past_key_values(FakeDynamicCache(((k, v),)), "q8k-q8v")
    assert cache.source_requires_cache_object is True
    assert cache.source_cache_type == "FakeDynamicCache"
    assert cache.to_past_key_values()[0][0].shape == k.shape


def test_cache_accepts_legacy_extra_fields():
    import torch
    from tiny_turboquant.kv.compression import TinyTurboKVCache

    k = torch.randn(1, 2, 4, 8)
    v = torch.randn(1, 2, 4, 8)
    extra = torch.ones(1)
    cache = TinyTurboKVCache.from_past_key_values(((k, v, extra),), "q8k-q8v")
    dense = cache.to_past_key_values()
    assert len(dense[0]) == 2
    assert dense[0][0].shape == k.shape
    assert cache.source_requires_cache_object is False


def test_v01203_quality_metrics_detect_first_divergence():
    from tiny_turboquant.validation.backend import (
        first_divergence,
        same_prefix_len,
        token_match_count,
        quality_verdict,
    )

    baseline = [1, 2, 3, 4]
    candidate = [1, 2, 9, 4]
    idx, payload = first_divergence(baseline, candidate)
    assert same_prefix_len(baseline, candidate) == 2
    assert token_match_count(baseline, candidate) == 3
    assert idx == 2
    assert payload["baseline_token_id"] == 3
    assert payload["candidate_token_id"] == 9
    assert quality_verdict(1.0, 1.0, True, 0.95) == "exact-match"
    assert quality_verdict(0.8, 0.75, False, 0.95) == "prefix-stable-then-diverged"
    assert quality_verdict(0.2, 0.2, False, 0.95) == "diverged"


def test_v01203_step_and_logit_comparison_reports_top1_divergence():
    from tiny_turboquant.validation.backend import compare_logits, compare_step_traces

    base_steps = [{"step": 0, "token_id": 10, "top1_id": 10, "top1_logit": 4.0}]
    cand_steps = [{"step": 0, "token_id": 11, "top1_id": 11, "top1_logit": 3.0}]
    step_report = compare_step_traces(base_steps, cand_steps)
    assert step_report["steps_compared"] == 1
    assert step_report["top1_match_ratio"] == 0.0
    assert step_report["first_generated_divergence"]["candidate_token_id"] == 11

    base_logits = [torch.tensor([[0.0, 2.0, 1.0]])]
    cand_logits = [torch.tensor([[0.0, 1.0, 3.0]])]
    logit_report = compare_logits(base_logits, cand_logits)
    assert logit_report["enabled"] is True
    assert logit_report["steps_compared"] == 1
    assert logit_report["top1_match_ratio"] == 0.0
    assert logit_report["first_top1_divergence"]["baseline_top1_id"] == 1
    assert logit_report["first_top1_divergence"]["candidate_top1_id"] == 2


def test_v01204_quality_stable_policies_exist_and_boundary_is_fp16():
    from tiny_turboquant.kv.policy import resolve_kv_policy

    fp16k_q8v = resolve_kv_policy("fp16k-q8v")
    assert fp16k_q8v.key_bits == 16
    assert fp16k_q8v.value_bits == 8
    assert fp16k_q8v.recommendation_class() == "safe_for_short_qa"

    boundary = resolve_kv_policy("boundary-fp16-fp16k-q8v")
    first = boundary.layer_policy(0, 24)
    middle = boundary.layer_policy(12, 24)
    last = boundary.layer_policy(23, 24)
    assert first.key_bits == 16 and first.value_bits == 16
    assert middle.key_bits == 16 and middle.value_bits == 8
    assert last.key_bits == 16 and last.value_bits == 16


def test_v01204_kv_cache_uses_quality_stable_boundary_layer_map():
    import torch
    from tiny_turboquant.kv.compression import TinyTurboKVCache

    torch.manual_seed(124)
    past = tuple((torch.randn(1, 2, 4, 8), torch.randn(1, 2, 4, 8)) for _ in range(6))
    cache = TinyTurboKVCache.from_past_key_values(past, "boundary-fp16-fp16k-q8v")
    report = cache.to_dict()
    assert report["policy"] == "boundary-fp16-fp16k-q8v"
    assert report["policy_recommendation_class"] == "safe_for_short_qa"
    assert report["layer_policies"][0].endswith("boundary-fp16")
    assert report["layer_policies"][2] == "boundary-fp16-fp16k-q8v"
    assert report["layer_policies"][-1].endswith("boundary-fp16")


def test_v01204_policy_recommendation_hints_key_compression():
    from tiny_turboquant.validation.backend import GenerationComparison, policy_quality_recommendation

    comparison = GenerationComparison(
        prompt="p",
        baseline_text="a",
        candidate_text="b",
        baseline_generated="a",
        candidate_generated="b",
        same_prefix_tokens=3,
        baseline_tokens=32,
        candidate_tokens=32,
        exact_text_match=False,
        exact_generated_match=False,
        first_divergence_index=4,
        first_divergence={"index": 4, "baseline_token_id": 1, "candidate_token_id": 2},
        token_match_count=4,
        token_match_ratio=0.125,
        prefix_match_ratio=0.125,
        length_delta=0,
    )
    rec = policy_quality_recommendation(
        baseline_policy="fp16",
        candidate_policy="q8k-q8v",
        verdict="diverged",
        comparison=comparison,
        summary={"candidate_memory_saved_pct": 50.0},
    )
    assert rec["status"] == "unstable"
    assert "K controls attention routing" in rec["cause_hint"]
    assert "fp16k-q8v" in rec["next_action"]


def test_v01205_exact_match_recommendation_hint_is_positive():
    from tiny_turboquant.validation.backend import GenerationComparison, policy_quality_recommendation

    comparison = GenerationComparison(
        prompt="p",
        baseline_text="same",
        candidate_text="same",
        baseline_generated="same",
        candidate_generated="same",
        same_prefix_tokens=8,
        baseline_tokens=8,
        candidate_tokens=8,
        exact_text_match=True,
        exact_generated_match=True,
        first_divergence_index=None,
        first_divergence=None,
        token_match_count=8,
        token_match_ratio=1.0,
        prefix_match_ratio=1.0,
        length_delta=0,
    )
    rec = policy_quality_recommendation(
        baseline_policy="fp16",
        candidate_policy="fp16k-q8v",
        verdict="exact-match",
        comparison=comparison,
        summary={"candidate_memory_saved_pct": 25.0},
    )
    assert rec["status"] == "safe_for_this_prompt"
    assert "preserved the exact token path" in rec["cause_hint"]
    assert "changed the token path" not in rec["cause_hint"]


def test_v01205_policy_matrix_selects_exact_match_highest_memory():
    from tiny_turboquant.validation.backend import policy_matrix_markdown

    report = {
        "model": "fake",
        "baseline_policy": "fp16",
        "decode_mode": "greedy",
        "max_new_tokens": 4,
        "recommended_policy": "fp16k-q8v",
        "recommendation_reason": "selected highest-memory-saving exact-match compressed policy",
        "rows": [
            {"policy": "fp16", "quality_verdict": "exact-match", "exact_generated_match": True, "token_match_ratio": 1.0, "prefix_match_ratio": 1.0, "first_divergence_index": None, "memory_saved_pct": 0.0, "compression_ratio": 1.0, "tokens_per_second_ratio": 1.0},
            {"policy": "fp16k-q8v", "quality_verdict": "exact-match", "exact_generated_match": True, "token_match_ratio": 1.0, "prefix_match_ratio": 1.0, "first_divergence_index": None, "memory_saved_pct": 25.0, "compression_ratio": 1.33, "tokens_per_second_ratio": 0.5},
        ],
    }
    md = policy_matrix_markdown(report)
    assert "Recommended policy: `fp16k-q8v`" in md
    assert "| fp16k-q8v | exact-match | yes |" in md


def test_v01205_cli_defaults_to_fp16k_q8v():
    from tiny_turboquant.cli import build_parser

    parser = build_parser()
    bench_args = parser.parse_args(["bench"])
    validate_args = parser.parse_args(["validate"])
    assert bench_args.kv_policy == "fp16k-q8v"
    assert validate_args.candidate == "fp16k-q8v"


def test_v01205_compare_policies_parser_exists():
    from tiny_turboquant.cli import build_parser

    parser = build_parser()
    args = parser.parse_args(["compare-policies", "--summary-only"])
    assert args.cmd == "compare-policies"
    assert "fp16k-q8v" in args.policies


def test_v0121_policy_matrix_falls_back_to_fp16_when_no_compressed_exact_match():
    from tiny_turboquant.validation.backend import policy_matrix_markdown

    report = {
        "model": "fake",
        "baseline_policy": "fp16",
        "decode_mode": "greedy",
        "max_new_tokens": 4,
        "recommended_policy": "fp16",
        "recommendation_reason": "no compressed policy exact-matched; use fp16 baseline and treat best compressed candidate as risky",
        "best_risky_policy": "fp16k-q8v",
        "exact_compressed_policies": [],
        "unsafe_policies": ["fp16k-q8v", "q8k-q8v"],
        "rows": [
            {"policy": "fp16", "quality_verdict": "exact-match", "exact_generated_match": True, "token_match_ratio": 1.0, "prefix_match_ratio": 1.0, "first_divergence_index": None, "memory_saved_pct": 0.0, "compression_ratio": 1.0, "tokens_per_second_ratio": 1.0},
            {"policy": "fp16k-q8v", "quality_verdict": "diverged", "exact_generated_match": False, "token_match_ratio": 0.9, "prefix_match_ratio": 0.8, "first_divergence_index": 12, "memory_saved_pct": 25.0, "compression_ratio": 1.33, "tokens_per_second_ratio": 0.5},
        ],
    }
    md = policy_matrix_markdown(report)
    assert "Recommended policy: `fp16`" in md
    assert "Best risky compressed policy: `fp16k-q8v`" in md
    assert "Unsafe compressed policies: `fp16k-q8v, q8k-q8v`" in md


def test_v0121_validate_and_compare_have_no_per_step_flags():
    from tiny_turboquant.cli import build_parser

    parser = build_parser()
    validate_args = parser.parse_args(["validate", "--no-per-step"])
    compare_args = parser.parse_args(["compare-policies", "--no-per-step", "--summary-only"])
    assert validate_args.no_per_step is True
    assert compare_args.no_per_step is True


def test_v013_policy_matrix_does_not_mark_exact_match_as_risky():
    from tiny_turboquant.validation.backend import policy_matrix_markdown

    report = {
        "model": "fake",
        "baseline_policy": "fp16",
        "decode_mode": "greedy",
        "max_new_tokens": 4,
        "recommended_policy": "fp16k-q8v",
        "recommendation_reason": "selected highest-memory-saving exact-match compressed policy",
        "best_risky_policy": None,
        "exact_compressed_policies": ["fp16k-q8v"],
        "unsafe_policies": ["q8k-q8v"],
        "rows": [
            {"policy": "fp16", "quality_verdict": "exact-match", "exact_generated_match": True, "token_match_ratio": 1.0, "prefix_match_ratio": 1.0, "first_divergence_index": None, "memory_saved_pct": 0.0, "compression_ratio": 1.0, "tokens_per_second_ratio": 1.0},
            {"policy": "fp16k-q8v", "quality_verdict": "exact-match", "exact_generated_match": True, "token_match_ratio": 1.0, "prefix_match_ratio": 1.0, "first_divergence_index": None, "memory_saved_pct": 25.0, "compression_ratio": 1.33, "tokens_per_second_ratio": 0.5},
            {"policy": "q8k-q8v", "quality_verdict": "diverged", "exact_generated_match": False, "token_match_ratio": 0.2, "prefix_match_ratio": 0.2, "first_divergence_index": 7, "memory_saved_pct": 50.0, "compression_ratio": 2.0, "tokens_per_second_ratio": 0.4},
        ],
    }
    md = policy_matrix_markdown(report)
    assert "Recommended policy: `fp16k-q8v`" in md
    assert "Best risky compressed policy: `None`" in md
