﻿"""Compressed KV policy definitions for the tiny-turboquant serving backend.

The policy layer is intentionally small.  It describes how K and V should be
stored between decode steps.  It does not claim fused compressed attention; the
v0.13.3 HF backend dequantizes the stored cache before calling the model again.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable


@dataclass(frozen=True)
class KVPolicy:
    """Storage policy for a compressed KV cache.

    Parameters
    ----------
    name:
        Public policy name used by the CLI and server.
    key_bits/value_bits:
        Bit width used for K and V storage.  ``16`` means dense fp16/bf16/fp32
        storage is preserved for that tensor.
    key_mode/value_mode:
        Human-readable storage mode.  In v0.13.3, ``turbo4`` is still an alias for
        the int4 affine storage path so the serving UX can stabilize before
        fused TurboQuant kernels land.
    boundary_layer_count:
        First/last N transformer layers protected for safer defaults.
    boundary_key_bits/boundary_value_bits:
        Optional explicit boundary-layer storage bits.  When omitted, boundary
        protection keeps each tensor at least q8.  For quality-stable policies,
        these fields keep boundary layers dense fp16.
    """

    name: str
    key_bits: int
    value_bits: int
    key_mode: str = "affine"
    value_mode: str = "affine"
    boundary_layer_count: int = 0
    description: str = ""
    boundary_key_bits: int | None = None
    boundary_value_bits: int | None = None
    # v0.13.3: optional last-N layer protection. When both boundary and
    # last-N are set, last-N takes precedence on the affected trailing layers.
    last_n_layers_count: int = 0
    last_n_key_bits: int | None = None
    last_n_value_bits: int | None = None

    @property
    def compress_keys(self) -> bool:
        return self.key_bits < 16

    @property
    def compress_values(self) -> bool:
        return self.value_bits < 16

    @property
    def is_fp16(self) -> bool:
        return self.key_bits >= 16 and self.value_bits >= 16

    def layer_policy(self, layer_index: int, total_layers: int | None) -> "KVPolicy":
        """Return the effective policy for a layer.

        Order of precedence:
          1. ``last_n_layers_count``  â€” protects the trailing N layers.
          2. ``boundary_layer_count`` â€” protects the first + last N layers.
          3. middle layers use the policy's base key/value bits.
        """
        if total_layers is None:
            return self
        i = int(layer_index)
        n = int(total_layers)
        # 1. last-N protection (Mode 2 style)
        if self.last_n_layers_count > 0 and i >= max(0, n - self.last_n_layers_count):
            key_bits = int(self.last_n_key_bits if self.last_n_key_bits is not None else max(self.key_bits, 8))
            value_bits = int(self.last_n_value_bits if self.last_n_value_bits is not None else max(self.value_bits, 8))
            suffix = "last-n-fp16" if key_bits >= 16 and value_bits >= 16 else "last-n-q8"
            return KVPolicy(
                name=f"{self.name}:{suffix}",
                key_bits=key_bits,
                value_bits=value_bits,
                key_mode="dense" if key_bits >= 16 else "affine",
                value_mode="dense" if value_bits >= 16 else "affine",
                boundary_layer_count=0,
                description=f"last-N layer protected with K{key_bits}/V{value_bits} storage",
            )
        # 2. boundary protection (LA-V7 style)
        if self.boundary_layer_count <= 0:
            return self
        protect = i < self.boundary_layer_count or i >= max(0, n - self.boundary_layer_count)
        if not protect:
            return self
        key_bits = int(self.boundary_key_bits if self.boundary_key_bits is not None else max(self.key_bits, 8))
        value_bits = int(self.boundary_value_bits if self.boundary_value_bits is not None else max(self.value_bits, 8))
        suffix = "boundary-fp16" if key_bits >= 16 and value_bits >= 16 else "boundary-q8"
        return KVPolicy(
            name=f"{self.name}:{suffix}",
            key_bits=key_bits,
            value_bits=value_bits,
            key_mode="dense" if key_bits >= 16 else "affine",
            value_mode="dense" if value_bits >= 16 else "affine",
            boundary_layer_count=0,
            description=f"boundary layer protected with K{key_bits}/V{value_bits} storage",
        )

    def recommendation_class(self) -> str:
        """Coarse policy recommendation for README/JSON reporting."""
        if self.is_fp16:
            return "baseline"
        if self.key_bits >= 16 and self.value_bits >= 8:
            return "safe_for_short_qa"
        if self.boundary_key_bits == 16 and self.boundary_value_bits == 16 and self.key_bits >= 16:
            return "safe_for_short_qa"
        if self.key_bits >= 8 and self.value_bits >= 8:
            return "quality_sensitive"
        return "risky"


POLICIES: Dict[str, KVPolicy] = {
    "fp16": KVPolicy("fp16", 16, 16, "dense", "dense", 0, "store the Hugging Face KV cache densely"),
    "q8k-q8v": KVPolicy("q8k-q8v", 8, 8, "affine", "affine", 0, "q8 key + q8 value cache; memory-efficient but quality-sensitive on Qwen-style models"),
    "fp16k-q8v": KVPolicy("fp16k-q8v", 16, 8, "dense", "affine", 0, "quality-first policy: preserve K routing in fp16, compress V to q8"),
    "fp16k-int4v": KVPolicy("fp16k-int4v", 16, 4, "dense", "affine", 2, "preserve K in fp16, compress V to int4 with boundary protection"),
    "q8k-int4v": KVPolicy("q8k-int4v", 8, 4, "affine", "affine", 2, "q8 keys with int4 values and q8 boundary protection"),
    "q8k-turbo4v": KVPolicy("q8k-turbo4v", 8, 4, "affine", "turbo4-alias", 2, "serving UX alias for q8 keys + 4-bit value storage"),
    "boundary-fp16-q8k-q8v": KVPolicy(
        "boundary-fp16-q8k-q8v",
        8,
        8,
        "affine",
        "affine",
        2,
        "first/last 2 layers fp16; middle layers q8 K and q8 V",
        boundary_key_bits=16,
        boundary_value_bits=16,
    ),
    "boundary-fp16-fp16k-q8v": KVPolicy(
        "boundary-fp16-fp16k-q8v",
        16,
        8,
        "dense",
        "affine",
        2,
        "boundary-safe policy: first/last 2 layers fp16; middle layers fp16 K and q8 V",
        boundary_key_bits=16,
        boundary_value_bits=16,
    ),
    # v0.13.3: layer-adaptive Mode 2. Last-N protection is experimental and
    # must be validated per model before being treated as quality-safe.
    "fp16k-int4v-last8-fp16": KVPolicy(
        "fp16k-int4v-last8-fp16",
        16,
        4,
        "dense",
        "affine",
        0,
        "fp16 K with int4 V on all but the last 8 layers; last 8 layers kept fp16 K + fp16 V",
        last_n_layers_count=8,
        last_n_key_bits=16,
        last_n_value_bits=16,
    ),
    "q8k-int4v-last8-q8v": KVPolicy(
        "q8k-int4v-last8-q8v",
        8,
        4,
        "affine",
        "affine",
        0,
        "q8 K with int4 V on all but the last 8 layers; last 8 layers kept q8 K + q8 V",
        last_n_layers_count=8,
        last_n_key_bits=8,
        last_n_value_bits=8,
    ),
    # Aggressive low-bit V with boundary and last-N protection.
    "fp16k-int4v-boundary-last": KVPolicy(
        "fp16k-int4v-boundary-last",
        16,
        4,
        "dense",
        "affine",
        2,
        "fp16 K + int4 V on middle layers; first 2 layers fp16 K+V; last 8 layers fp16 K + q8 V because last-N overrides trailing boundary protection",
        boundary_key_bits=16,
        boundary_value_bits=16,
        last_n_layers_count=8,
        last_n_key_bits=16,
        last_n_value_bits=8,
    ),
}


def available_kv_policies() -> list[str]:
    return sorted(POLICIES)


def resolve_kv_policy(name: str | KVPolicy) -> KVPolicy:
    if isinstance(name, KVPolicy):
        return name
    key = str(name).strip().lower()
    if key not in POLICIES:
        allowed = ", ".join(available_kv_policies())
        raise ValueError(f"unknown KV policy {name!r}; expected one of: {allowed}")
    return POLICIES[key]


def policy_table(policies: Iterable[str] | None = None) -> str:
    names = list(policies or available_kv_policies())
    lines = ["Policy | K | V | Boundary | Description", "---|---:|---:|---:|---"]
    for name in names:
        p = resolve_kv_policy(name)
        lines.append(f"{p.name} | {p.key_bits} | {p.value_bits} | {p.boundary_layer_count} | {p.description}")
    return "\n".join(lines)
