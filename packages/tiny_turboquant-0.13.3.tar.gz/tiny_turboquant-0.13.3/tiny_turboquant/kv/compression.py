﻿"""Tensor compression primitives for the v0.13.3 serving backend."""

from __future__ import annotations

from dataclasses import dataclass
from math import ceil
from typing import Any, Iterable, Sequence, Tuple

import torch

from ..bitpack import pack_indices, unpack_indices, tensor_nbytes
from .policy import KVPolicy, resolve_kv_policy


def _extract_kv_pair(layer_entry: Any, layer_index: int) -> Tuple[torch.Tensor, torch.Tensor]:
    """Extract ``(key, value)`` from a Hugging Face cache layer entry.

    Different Transformers versions and model families may return cache layer
    entries as ``(key, value)``, ``(key, value, ...)``, lists, or small cache
    objects.  The compressed storage backend only owns K/V tensors, so it keeps
    the first two tensor-like entries and ignores auxiliary metadata such as
    cache positions or legacy attention-state fields.
    """
    if isinstance(layer_entry, (tuple, list)):
        tensors = [x for x in layer_entry if torch.is_tensor(x)]
        if len(tensors) >= 2:
            return tensors[0], tensors[1]
    if hasattr(layer_entry, "key_cache") and hasattr(layer_entry, "value_cache"):
        return layer_entry.key_cache, layer_entry.value_cache
    if hasattr(layer_entry, "keys") and hasattr(layer_entry, "values"):
        return layer_entry.keys, layer_entry.values
    raise ValueError(
        f"could not extract key/value tensors from past_key_values layer {layer_index}; "
        f"got {type(layer_entry).__name__}"
    )


def _to_legacy_past(past: Any) -> Tuple[Tuple[torch.Tensor, torch.Tensor], ...]:
    """Convert a Hugging Face cache object to normalized ``(K, V)`` tuples.

    This normalizer accepts both legacy tuple caches and newer Transformers
    cache objects.  It intentionally strips non-K/V auxiliary fields so the
    storage backend can remain model-family agnostic.
    """
    if past is None:
        return tuple()
    raw = past.to_legacy_cache() if hasattr(past, "to_legacy_cache") else past
    if isinstance(raw, dict):
        # Defensive support for cache-like mappings used by some wrappers.
        raw = raw.get("past_key_values") or raw.get("cache") or raw.values()
    return tuple(_extract_kv_pair(layer, idx) for idx, layer in enumerate(tuple(raw)))


def _legacy_to_dynamic_cache(legacy: Tuple[Tuple[torch.Tensor, torch.Tensor], ...]) -> Any:
    """Convert normalized legacy tuples back to a Transformers Cache object.

    Newer Transformers model families such as Qwen2 expect ``past_key_values``
    to implement methods like ``get_seq_length()`` during incremental decode.
    Passing a plain tuple works for older models but fails for these newer
    cache-only paths.  This helper keeps the serving backend version-tolerant:
    use ``DynamicCache.from_legacy_cache`` when available, otherwise build a
    DynamicCache by calling ``update`` layer by layer.
    """
    try:
        from transformers.cache_utils import DynamicCache  # type: ignore
    except Exception as exc:  # pragma: no cover - depends on optional transformers
        raise RuntimeError(
            "Transformers DynamicCache is required to feed this model's cache format back into decode."
        ) from exc

    if hasattr(DynamicCache, "from_legacy_cache"):
        try:
            return DynamicCache.from_legacy_cache(legacy)  # type: ignore[attr-defined]
        except TypeError:
            # Some versions expose the method but with changed annotations.
            pass

    cache = DynamicCache()
    for layer_idx, (key_states, value_states) in enumerate(legacy):
        cache.update(key_states, value_states, layer_idx)
    return cache


@dataclass
class CompressedTensor:
    """Compressed representation of a K or V tensor.

    Dense policy stores the original tensor.  Low-bit policy stores packed
    integer codes plus affine scale/min values.  The tensors stay on the same
    device as the source tensor so decode loops do not force CPU transfers.
    """

    bits: int
    shape: Tuple[int, ...]
    dtype: str
    device: str
    q_packed: torch.Tensor | None = None
    q_shape: Tuple[int, ...] | None = None
    scale: torch.Tensor | None = None
    offset: torch.Tensor | None = None
    dense: torch.Tensor | None = None
    # v0.13.3: per-row blocking along the seq axis (axis -2 for 4D KV tensors)
    # enables KIVI-style per-token quantization plus O(1) incremental append.
    # When ``block_axis is None``, the legacy single-block layout is used.
    block_axis: int | None = None
    n_blocks: int = 1
    # Optional row-norm restoration multiplier per block; applied post-affine-dequant.
    # This is a quality heuristic, not a guarantee. Validate per model/policy.
    norm_correction: torch.Tensor | None = None

    @classmethod
    def from_tensor(
        cls,
        x: torch.Tensor,
        bits: int,
        *,
        per_row: bool = True,
        norm_correction: bool = True,
    ) -> "CompressedTensor":
        bits = int(bits)
        if bits >= 16:
            return cls(
                bits=16,
                shape=tuple(int(v) for v in x.shape),
                dtype=str(x.dtype).replace("torch.", ""),
                device=str(x.device),
                dense=x.detach().contiguous(),
            )
        if bits < 1 or bits > 8:
            raise ValueError(f"bits must be in [1, 8] or 16, got {bits}")

        # Decide layout. Per-row (block along axis -2) requires:
        # - tensor has at least 3 dims (so axis -2 is meaningful)
        # - last_dim * bits is a multiple of 8 (so each block is byte-aligned
        #   and concat-along-blocks is byte concat, not bit splicing).
        last_dim = int(x.shape[-1]) if x.ndim >= 1 else 1
        block_axis: int | None
        if per_row and x.ndim >= 3 and (last_dim * bits) % 8 == 0:
            block_axis = -2
        else:
            block_axis = None

        xf = x.detach().to(torch.float32).contiguous()
        levels = float((1 << bits) - 1)

        if block_axis is None:
            # Legacy whole-tensor affine path (used for dim < 3 and odd shapes).
            x_min = xf.amin().reshape(1)
            x_max = xf.amax().reshape(1)
            scale = ((x_max - x_min) / max(levels, 1.0)).clamp_min(1e-12)
            q = torch.round((xf - x_min) / scale).clamp(0, levels).to(torch.uint8)
            packed, q_shape = pack_indices(q, bits)
            return cls(
                bits=bits,
                shape=tuple(int(v) for v in x.shape),
                dtype=str(x.dtype).replace("torch.", ""),
                device=str(x.device),
                q_packed=packed.contiguous(),
                q_shape=tuple(int(v) for v in q_shape),
                scale=scale.to(device=x.device),
                offset=x_min.to(device=x.device),
                block_axis=None,
                n_blocks=1,
                norm_correction=None,
            )

        # Per-row path: flatten (..., D) into (N_rows, D) where N_rows = prod(shape[:-1]).
        rows = xf.reshape(-1, last_dim)
        n_blocks = int(rows.shape[0])
        row_min = rows.amin(dim=-1, keepdim=True)
        row_max = rows.amax(dim=-1, keepdim=True)
        row_scale = ((row_max - row_min) / max(levels, 1.0)).clamp_min(1e-12)
        q_rows = torch.round((rows - row_min) / row_scale).clamp(0, levels).to(torch.uint8)
        packed, q_shape = pack_indices(q_rows, bits)

        nc: torch.Tensor | None = None
        if norm_correction:
            # Multiplier that restores per-row L2 norm to the original.
            with torch.no_grad():
                deq = q_rows.to(torch.float32) * row_scale + row_min
                orig_norm = rows.norm(dim=-1)
                deq_norm = deq.norm(dim=-1).clamp_min(1e-12)
                nc = (orig_norm / deq_norm).to(device=x.device)

        return cls(
            bits=bits,
            shape=tuple(int(v) for v in x.shape),
            dtype=str(x.dtype).replace("torch.", ""),
            device=str(x.device),
            q_packed=packed.contiguous(),
            q_shape=tuple(int(v) for v in q_shape),
            scale=row_scale.reshape(n_blocks).to(device=x.device),
            offset=row_min.reshape(n_blocks).to(device=x.device),
            block_axis=-2,
            n_blocks=n_blocks,
            norm_correction=nc,
        )

    def dequantize(self, *, dtype: torch.dtype | None = None, device: torch.device | str | None = None) -> torch.Tensor:
        if self.dense is not None:
            out = self.dense
            if device is not None:
                out = out.to(device)
            if dtype is not None:
                out = out.to(dtype=dtype)
            return out
        if self.q_packed is None or self.q_shape is None or self.scale is None or self.offset is None:
            raise RuntimeError("corrupt compressed tensor; missing packed data or affine metadata")
        q = unpack_indices(self.q_packed, self.bits, self.q_shape).to(torch.float32)
        scale = self.scale.to(device=q.device, dtype=torch.float32)
        offset = self.offset.to(device=q.device, dtype=torch.float32)
        if self.block_axis is None:
            out = (q * scale + offset).reshape(self.shape)
        else:
            # Per-row affine: (n_blocks, last_dim) * scale[:, None] + offset[:, None]
            last_dim = int(self.shape[-1])
            q_rows = q.reshape(self.n_blocks, last_dim)
            out_rows = q_rows * scale.reshape(-1, 1) + offset.reshape(-1, 1)
            if self.norm_correction is not None:
                nc = self.norm_correction.to(device=q.device, dtype=torch.float32).reshape(-1, 1)
                out_rows = out_rows * nc
            out = out_rows.reshape(self.shape)
        if device is not None:
            out = out.to(device)
        if dtype is not None:
            out = out.to(dtype=dtype)
        return out

    def storage_bytes(self) -> int:
        total = 0
        for obj in (self.q_packed, self.scale, self.offset, self.dense, self.norm_correction):
            if obj is not None:
                total += tensor_nbytes(obj)
        return int(total)

    def dense_bytes(self, dtype_bytes: int = 2) -> int:
        n = 1
        for dim in self.shape:
            n *= int(dim)
        return int(n * dtype_bytes)

    def concat_along_seq(self, other: "CompressedTensor") -> "CompressedTensor":
        """Concatenate two compressed tensors along axis -2 (seq dim).

        Both operands must use the per-row block layout, the same ``bits``,
        and matching trailing shape (everything except axis -2).
        Used by incremental KV append to grow the cache without re-quantizing
        positions that were already compressed.
        """
        if self.bits != other.bits:
            raise ValueError(f"bits mismatch: {self.bits} vs {other.bits}")
        if self.dense is not None or other.dense is not None:
            # fp16 path: just torch.cat the dense buffers.
            assert self.dense is not None and other.dense is not None, (
                "cannot concat a dense compressed tensor with a quantized one"
            )
            cat = torch.cat([self.dense, other.dense], dim=-2)
            return CompressedTensor(
                bits=16,
                shape=tuple(int(v) for v in cat.shape),
                dtype=self.dtype,
                device=str(cat.device),
                dense=cat.contiguous(),
            )
        if self.block_axis is None or other.block_axis is None:
            raise ValueError("concat_along_seq requires per-row blocked layout on both operands")
        # Trailing shape must match (last dim and any pre-seq dims).
        if self.shape[:-2] != other.shape[:-2] or self.shape[-1] != other.shape[-1]:
            raise ValueError(
                f"shape mismatch for concat_along_seq: {self.shape} vs {other.shape}"
            )
        assert self.q_packed is not None and other.q_packed is not None
        assert self.scale is not None and other.scale is not None
        assert self.offset is not None and other.offset is not None
        last_dim = int(self.shape[-1])
        seq_self = int(self.shape[-2])
        seq_other = int(other.shape[-2])
        batch_dims = tuple(int(v) for v in self.shape[:-2])
        new_seq = seq_self + seq_other
        new_shape = (*batch_dims, new_seq, last_dim)
        new_n_blocks = int(self.n_blocks + other.n_blocks)
        # Per-row blocks are flattened in row-major order over (batch_dims, seq).
        # A naive byte concat puts every (b,h) block of `self` before any of
        # `other`, which scrambles the seq dimension for batch_dims != (). We
        # round-trip through (batch_dims, seq, last_dim) and (batch_dims, seq)
        # so the merge is correct for any leading shape.
        idx_self = unpack_indices(
            self.q_packed, self.bits, (self.n_blocks, last_dim)
        ).reshape(*batch_dims, seq_self, last_dim)
        idx_other = unpack_indices(
            other.q_packed, other.bits, (other.n_blocks, last_dim)
        ).reshape(*batch_dims, seq_other, last_dim)
        idx_cat = torch.cat([idx_self, idx_other], dim=-2).reshape(new_n_blocks, last_dim).contiguous()
        new_packed, _ = pack_indices(idx_cat, self.bits)
        new_q_shape = (new_n_blocks, last_dim)
        scale_self = self.scale.reshape(*batch_dims, seq_self)
        scale_other = other.scale.reshape(*batch_dims, seq_other)
        new_scale = torch.cat([scale_self, scale_other], dim=-1).reshape(new_n_blocks).contiguous()
        offset_self = self.offset.reshape(*batch_dims, seq_self)
        offset_other = other.offset.reshape(*batch_dims, seq_other)
        new_offset = torch.cat([offset_self, offset_other], dim=-1).reshape(new_n_blocks).contiguous()
        new_nc: torch.Tensor | None = None
        if self.norm_correction is not None and other.norm_correction is not None:
            nc_self = self.norm_correction.reshape(*batch_dims, seq_self)
            nc_other = other.norm_correction.reshape(*batch_dims, seq_other)
            new_nc = torch.cat([nc_self, nc_other], dim=-1).reshape(new_n_blocks).contiguous()
        return CompressedTensor(
            bits=self.bits,
            shape=new_shape,
            dtype=self.dtype,
            device=self.device,
            q_packed=new_packed,
            q_shape=new_q_shape,
            scale=new_scale,
            offset=new_offset,
            block_axis=-2,
            n_blocks=new_n_blocks,
            norm_correction=new_nc,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "bits": self.bits,
            "shape": list(self.shape),
            "dtype": self.dtype,
            "device": self.device,
            "storage_bytes": self.storage_bytes(),
            "dense_fp16_bytes": self.dense_bytes(2),
            "block_axis": self.block_axis,
            "n_blocks": int(self.n_blocks),
            "norm_correction": bool(self.norm_correction is not None),
        }


@dataclass
class CompressedLayerKV:
    layer: int
    key: CompressedTensor
    value: CompressedTensor
    effective_policy: str

    def to_dense(self, *, dtype: torch.dtype | None = None, device: torch.device | str | None = None) -> tuple[torch.Tensor, torch.Tensor]:
        return self.key.dequantize(dtype=dtype, device=device), self.value.dequantize(dtype=dtype, device=device)

    def storage_bytes(self) -> int:
        return self.key.storage_bytes() + self.value.storage_bytes()

    def dense_bytes(self, dtype_bytes: int = 2) -> int:
        return self.key.dense_bytes(dtype_bytes) + self.value.dense_bytes(dtype_bytes)

    def concat_along_seq(self, other: "CompressedLayerKV") -> "CompressedLayerKV":
        if self.layer != other.layer:
            raise ValueError(f"layer mismatch: {self.layer} vs {other.layer}")
        return CompressedLayerKV(
            layer=self.layer,
            key=self.key.concat_along_seq(other.key),
            value=self.value.concat_along_seq(other.value),
            effective_policy=self.effective_policy,
        )


class TinyTurboKVCache:
    """Compressed KV storage used by the HF serving backend.

    The cache stores K/V compressed between decode steps.  Before a stock HF
    model forward, it materializes a dense legacy ``past_key_values`` tuple.  It
    is therefore a real compressed-storage backend foundation, not yet a fused
    compressed-attention accelerator.
    """

    def __init__(
        self,
        layers: Sequence[CompressedLayerKV],
        *,
        policy: KVPolicy,
        dense_dtype: torch.dtype,
        source_cache_type: str = "legacy",
        source_requires_cache_object: bool = False,
        dense_shadow: Any = None,
    ):
        self.layers = list(layers)
        self.policy = policy
        self.dense_dtype = dense_dtype
        self.source_cache_type = str(source_cache_type)
        self.source_requires_cache_object = bool(source_requires_cache_object)
        # Optional reference to the model's own dense past_key_values. When
        # present, to_model_past() returns it directly so active decode pays
        # zero dequant cost; the compressed store still owns the storage
        # claim (memory reporting, cross-request pooling, serialization).
        self._dense_shadow: Any = dense_shadow

    @classmethod
    def from_past_key_values(
        cls,
        past_key_values: Any,
        policy: str | KVPolicy,
        *,
        dense_dtype: torch.dtype | None = None,
        keep_dense_shadow: bool = True,
    ) -> "TinyTurboKVCache":
        source_cache_type = type(past_key_values).__name__ if past_key_values is not None else "None"
        source_requires_cache_object = bool(
            past_key_values is not None
            and not isinstance(past_key_values, (tuple, list))
            and (hasattr(past_key_values, "get_seq_length") or hasattr(past_key_values, "to_legacy_cache"))
        )
        legacy = _to_legacy_past(past_key_values)
        resolved = resolve_kv_policy(policy)
        if dense_dtype is None:
            dense_dtype = legacy[0][0].dtype if legacy else torch.float16
        total_layers = len(legacy)
        layers: list[CompressedLayerKV] = []
        for idx, (k, v) in enumerate(legacy):
            effective = resolved.layer_policy(idx, total_layers)
            layers.append(
                CompressedLayerKV(
                    layer=idx,
                    key=CompressedTensor.from_tensor(k.detach(), effective.key_bits),
                    value=CompressedTensor.from_tensor(v.detach(), effective.value_bits),
                    effective_policy=effective.name,
                )
            )
        return cls(
            layers,
            policy=resolved,
            dense_dtype=dense_dtype,
            source_cache_type=source_cache_type,
            source_requires_cache_object=source_requires_cache_object,
            dense_shadow=past_key_values if keep_dense_shadow else None,
        )

    def to_past_key_values(self, *, dtype: torch.dtype | None = None, device: torch.device | str | None = None):
        target_dtype = dtype or self.dense_dtype
        return tuple(layer.to_dense(dtype=target_dtype, device=device) for layer in self.layers)

    def to_model_past(self, *, dtype: torch.dtype | None = None, device: torch.device | str | None = None):
        """Return dense past_key_values in the format expected by the source model.

        Fast path: when a dense shadow is kept (the default), hand back the
        model's own ``past_key_values`` directly so active decode pays zero
        per-step dequant cost. Slow path (no shadow): fully dequantize the
        compressed store. Legacy tuple caches and Transformers ``Cache``
        objects are both supported by the slow path.
        """
        if self._dense_shadow is not None:
            return self._dense_shadow
        legacy = self.to_past_key_values(dtype=dtype, device=device)
        if self.source_requires_cache_object:
            return _legacy_to_dynamic_cache(legacy)
        return legacy

    def storage_bytes(self) -> int:
        return int(sum(layer.storage_bytes() for layer in self.layers))

    def dense_bytes(self, dtype_bytes: int = 2) -> int:
        return int(sum(layer.dense_bytes(dtype_bytes) for layer in self.layers))

    def compression_ratio(self, dtype_bytes: int = 2) -> float:
        return self.dense_bytes(dtype_bytes) / max(self.storage_bytes(), 1)

    def memory_saved_pct(self, dtype_bytes: int = 2) -> float:
        dense = self.dense_bytes(dtype_bytes)
        return (1.0 - self.storage_bytes() / max(dense, 1)) * 100.0

    def seq_len(self) -> int:
        if not self.layers:
            return 0
        return int(self.layers[0].key.shape[-2])

    def refresh_dense_shadow(self, fresh_past_key_values: Any) -> None:
        """Replace the dense shadow with the latest model past_key_values.

        Used during decode when ``dense_shadow=True`` to skip the O(seq) cost
        of per-step incremental compression. The compressed store keeps its
        prefill-snapshot contents; callers should rebuild it from the final
        shadow at end of generation if they need accurate storage stats.
        """
        self._dense_shadow = fresh_past_key_values

    def step_append(self, fresh_past_key_values: Any, *, keep_dense_shadow: bool = True) -> "TinyTurboKVCache":
        """Append only the newly-produced rows from a forward pass.

        This is the v0.13.3 incremental KV append path: instead of
        re-quantizing every cached position on every decode step, we slice
        ``fresh_past_key_values[..., prev_seq_len:, :]`` per layer and compress
        only those rows, then concatenate them into the existing per-layer
        compressed buffers via :meth:`CompressedTensor.concat_along_seq`.
        Cost per step is O(new_rows), not O(total_seq_len).
        """
        fresh = _to_legacy_past(fresh_past_key_values)
        if len(fresh) != len(self.layers):
            raise ValueError(
                f"layer count mismatch in step_append: have {len(self.layers)}, got {len(fresh)}"
            )
        prev_seq_len = self.seq_len()
        new_layers: list[CompressedLayerKV] = []
        for existing, (k_full, v_full) in zip(self.layers, fresh):
            new_total = int(k_full.shape[-2])
            if new_total <= prev_seq_len:
                # Nothing new (e.g. self-test step that didn't grow the cache).
                new_layers.append(existing)
                continue
            # Slice the freshly-produced suffix along seq axis.
            k_new = k_full[..., prev_seq_len:, :].detach()
            v_new = v_full[..., prev_seq_len:, :].detach()
            policy_name = existing.effective_policy
            # Reuse the effective per-layer policy already computed at prefill.
            eff = self.policy.layer_policy(existing.layer, len(self.layers))
            k_comp = CompressedTensor.from_tensor(k_new, eff.key_bits)
            v_comp = CompressedTensor.from_tensor(v_new, eff.value_bits)
            tail = CompressedLayerKV(
                layer=existing.layer,
                key=k_comp,
                value=v_comp,
                effective_policy=policy_name,
            )
            try:
                merged = existing.concat_along_seq(tail)
            except ValueError:
                # Fallback: legacy single-block tensors can't be concatenated,
                # so dequant-then-recompress preserves correctness at the cost
                # of the incremental speedup for that layer only.
                k_full_d = torch.cat(
                    [existing.key.dequantize(dtype=k_full.dtype), k_new.to(k_full.dtype)],
                    dim=-2,
                )
                v_full_d = torch.cat(
                    [existing.value.dequantize(dtype=v_full.dtype), v_new.to(v_full.dtype)],
                    dim=-2,
                )
                merged = CompressedLayerKV(
                    layer=existing.layer,
                    key=CompressedTensor.from_tensor(k_full_d, eff.key_bits),
                    value=CompressedTensor.from_tensor(v_full_d, eff.value_bits),
                    effective_policy=policy_name,
                )
            new_layers.append(merged)
        return TinyTurboKVCache(
            new_layers,
            policy=self.policy,
            dense_dtype=self.dense_dtype,
            source_cache_type=self.source_cache_type,
            source_requires_cache_object=self.source_requires_cache_object,
            dense_shadow=fresh_past_key_values if keep_dense_shadow else None,
        )

    def to_dict(self) -> dict[str, Any]:
        dense = self.dense_bytes(2)
        storage = self.storage_bytes()
        per_row_layers = sum(1 for layer in self.layers if layer.key.block_axis == -2 or layer.value.block_axis == -2)
        norm_corrected_layers = sum(
            1 for layer in self.layers
            if (layer.key.norm_correction is not None) or (layer.value.norm_correction is not None)
        )
        return {
            "policy": self.policy.name,
            "policy_recommendation_class": self.policy.recommendation_class(),
            "layers": len(self.layers),
            "seq_len": self.seq_len(),
            "dense_fp16_bytes": dense,
            "compressed_storage_bytes": storage,
            "compression_ratio": dense / max(storage, 1),
            "memory_saved_pct": (1.0 - storage / max(dense, 1)) * 100.0,
            "layer_policies": [layer.effective_policy for layer in self.layers],
            "source_cache_type": self.source_cache_type,
            "source_requires_cache_object": self.source_requires_cache_object,
            "per_row_quantized_layers": int(per_row_layers),
            "norm_corrected_layers": int(norm_corrected_layers),
            "dense_shadow_active": self._dense_shadow is not None,
        }
