"""Small OpenAI-compatible HTTP server for the HF compressed-KV backend."""

from __future__ import annotations

import json
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from time import time
from typing import Any

from .. import __version__
from ..backends.hf import TinyTurboHFEngine


@dataclass
class ServerConfig:
    model: str
    kv_policy: str = "fp16k-q8v"
    host: str = "127.0.0.1"
    port: int = 8000
    device: str = "auto"
    dtype: str = "auto"
    max_new_tokens: int = 128
    cache_mode: str = "dense-shadow"
    local_files_only: bool = False
    trust_remote_code: bool = False


def _messages_to_prompt(messages: list[dict[str, Any]]) -> str:
    parts: list[str] = []
    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        parts.append(f"{role}: {content}")
    parts.append("assistant:")
    return "\n".join(parts)


def make_handler(engine: TinyTurboHFEngine, config: ServerConfig):
    class TinyTurboHandler(BaseHTTPRequestHandler):
        server_version = f"tiny-turboquant/{__version__}"

        def _send_json(self, payload: dict[str, Any], status: int = 200) -> None:
            raw = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self) -> None:  # noqa: N802
            if self.path == "/health":
                self._send_json({"status": "ok", "model": config.model, "kv_policy": config.kv_policy, "cache_mode": config.cache_mode})
            else:
                self._send_json({"error": "not found"}, status=404)

        def do_POST(self) -> None:  # noqa: N802
            try:
                length = int(self.headers.get("Content-Length", "0"))
                body = self.rfile.read(length).decode("utf-8")
                req = json.loads(body or "{}")
                max_tokens = int(req.get("max_tokens", req.get("max_new_tokens", config.max_new_tokens)))
                if self.path.endswith("/chat/completions"):
                    prompt = _messages_to_prompt(req.get("messages", []))
                    result = engine.generate(prompt, max_new_tokens=max_tokens)
                    self._send_json({
                        "id": f"chatcmpl-tiny-tq-{int(time())}",
                        "object": "chat.completion",
                        "created": int(time()),
                        "model": config.model,
                        "choices": [{
                            "index": 0,
                            "message": {"role": "assistant", "content": result.generated_text},
                            "finish_reason": "stop",
                        }],
                        "usage": {
                            "prompt_tokens": result.input_tokens,
                            "completion_tokens": result.output_tokens,
                            "total_tokens": result.input_tokens + result.output_tokens,
                        },
                        "tiny_turboquant": result.cache_report,
                    })
                elif self.path.endswith("/completions"):
                    prompt = str(req.get("prompt", ""))
                    result = engine.generate(prompt, max_new_tokens=max_tokens)
                    self._send_json({
                        "id": f"cmpl-tiny-tq-{int(time())}",
                        "object": "text_completion",
                        "created": int(time()),
                        "model": config.model,
                        "choices": [{"index": 0, "text": result.generated_text, "finish_reason": "stop"}],
                        "usage": {
                            "prompt_tokens": result.input_tokens,
                            "completion_tokens": result.output_tokens,
                            "total_tokens": result.input_tokens + result.output_tokens,
                        },
                        "tiny_turboquant": result.cache_report,
                    })
                else:
                    self._send_json({"error": "not found"}, status=404)
            except Exception as exc:  # pragma: no cover
                self._send_json({"error": repr(exc)}, status=500)

        def log_message(self, fmt: str, *args: Any) -> None:
            return

    return TinyTurboHandler


def run_server(config: ServerConfig) -> None:
    engine = TinyTurboHFEngine(
        config.model,
        kv_policy=config.kv_policy,
        device=config.device,
        dtype=config.dtype,
        cache_mode=config.cache_mode,
        local_files_only=config.local_files_only,
        trust_remote_code=config.trust_remote_code,
    ).load()
    httpd = ThreadingHTTPServer((config.host, int(config.port)), make_handler(engine, config))
    print(json.dumps({"status": "serving", "host": config.host, "port": config.port, "model": config.model, "kv_policy": config.kv_policy, "cache_mode": config.cache_mode}, indent=2))
    httpd.serve_forever()
