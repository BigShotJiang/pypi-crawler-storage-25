"""Experimental Sparse-V attention patch for the HF compressed-KV backend.

Sparse-V masks very small attention weights before the final ``attention @ V``
accumulation. This can reduce effective V work at long context, but this
implementation is intentionally experimental: it monkey-patches
``torch.nn.functional.scaled_dot_product_attention`` and may bypass optimized
FlashAttention/SDPA kernels. It should be treated as a measurement hook, not a
production speedup claim.

The context manager reports how often it was actually called. If ``calls == 0``,
the loaded model did not route through ``torch.nn.functional.scaled_dot_product_attention``
under the patch, so Sparse-V was enabled but not applied.
"""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Iterator

import math
import torch
import torch.nn.functional as F


@dataclass
class SparseVStats:
    """Aggregate counters for one or more sparse-V attention calls."""

    calls: int = 0
    skipped_positions: int = 0
    total_positions: int = 0
    threshold: float = 1e-6
    last_skip_ratio: float = 0.0
    per_call_skip_ratio: list[float] = field(default_factory=list)

    def record(self, skipped: int, total: int) -> None:
        self.calls += 1
        self.skipped_positions += int(skipped)
        self.total_positions += int(total)
        ratio = float(skipped) / max(total, 1)
        self.last_skip_ratio = ratio
        self.per_call_skip_ratio.append(ratio)

    @property
    def overall_skip_ratio(self) -> float:
        return self.skipped_positions / max(self.total_positions, 1)

    def to_dict(self) -> dict[str, float | int | str | bool]:
        payload: dict[str, float | int | str | bool] = {
            "enabled": True,
            "threshold": self.threshold,
            "calls": self.calls,
            "applied": self.calls > 0,
            "skipped_positions": self.skipped_positions,
            "total_positions": self.total_positions,
            "overall_skip_ratio": self.overall_skip_ratio,
            "last_skip_ratio": self.last_skip_ratio,
        }
        if self.calls == 0:
            payload["warning"] = (
                "Sparse-V was enabled but no SDPA calls were intercepted; "
                "this model/backend may not route through torch.nn.functional.scaled_dot_product_attention."
            )
        return payload


def _manual_sdpa_with_sparse_v(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    attn_mask: torch.Tensor | None = None,
    dropout_p: float = 0.0,
    is_causal: bool = False,
    scale: float | None = None,
    enable_gqa: bool | None = None,
    *,
    threshold: float,
    stats: SparseVStats | None = None,
) -> torch.Tensor:
    """Manual scaled-dot-product attention with sparse-V gating.

    Implements the same contract as ``F.scaled_dot_product_attention`` for the
    shapes used by HuggingFace causal attention. After computing softmax
    weights, we zero out positions whose weight is below ``threshold`` before
    multiplying by V. This follows the sparse-V idea, but this implementation is
    experimental and must be benchmarked per model/backend.
    """
    d_k = query.shape[-1]
    scale_value = (1.0 / math.sqrt(d_k)) if scale is None else float(scale)

    # GQA support: broadcast K/V heads to match Q heads when caller signals it.
    if enable_gqa and key.shape[-3] != query.shape[-3]:
        repeat = query.shape[-3] // key.shape[-3]
        key = key.repeat_interleave(repeat, dim=-3)
        value = value.repeat_interleave(repeat, dim=-3)

    # scores: (..., Lq, Lk)
    scores = torch.matmul(query, key.transpose(-2, -1)) * scale_value

    if is_causal:
        Lq, Lk = scores.shape[-2], scores.shape[-1]
        causal = torch.ones(Lq, Lk, dtype=torch.bool, device=scores.device).tril(diagonal=Lk - Lq)
        scores = scores.masked_fill(~causal, float("-inf"))

    if attn_mask is not None:
        if attn_mask.dtype == torch.bool:
            scores = scores.masked_fill(~attn_mask, float("-inf"))
        else:
            scores = scores + attn_mask

    weights = F.softmax(scores, dim=-1)
    if dropout_p > 0.0:
        weights = F.dropout(weights, p=dropout_p)

    # Sparse-V gate: mask weights below threshold, then renormalize so the
    # remaining attention mass still sums to 1. Renormalization preserves the
    # output distribution shape; without it small kept weights would shrink.
    if threshold > 0.0:
        keep = weights >= threshold
        masked = weights * keep
        denom = masked.sum(dim=-1, keepdim=True).clamp_min(1e-12)
        weights = masked / denom
        if stats is not None:
            total = int(keep.numel())
            kept = int(keep.sum().item())
            stats.record(skipped=total - kept, total=total)

    return torch.matmul(weights, value)


@contextmanager
def sparse_v_sdpa(threshold: float = 1e-6) -> Iterator[SparseVStats]:
    """Context manager that monkey-patches SDPA with the sparse-V gate.

    Replaces ``torch.nn.functional.scaled_dot_product_attention`` for the
    duration of the ``with`` block, restoring the original implementation on
    exit. Yields a :class:`SparseVStats` instance that captures per-call
    skip ratios so callers can report them in benchmark JSON.

    HuggingFace attention layers call SDPA through this function reference,
    so patching it here transparently affects every layer of the wrapped
    model without changing model code.
    """
    stats = SparseVStats(threshold=float(threshold))
    original = F.scaled_dot_product_attention

    def patched(*args, **kwargs):
        # Normalize positional vs keyword to the manual signature.
        return _manual_sdpa_with_sparse_v(
            *args, **kwargs, threshold=float(threshold), stats=stats
        )

    F.scaled_dot_product_attention = patched  # type: ignore[assignment]
    try:
        yield stats
    finally:
        F.scaled_dot_product_attention = original  # type: ignore[assignment]
