﻿"""Hugging Face compressed-KV generation backend."""

from __future__ import annotations

from dataclasses import dataclass, field
from time import perf_counter
from typing import Any

import torch

from ... import __version__

from ...kv.compression import TinyTurboKVCache
from ...kv.policy import KVPolicy, resolve_kv_policy
from .sparse_v import sparse_v_sdpa


@dataclass
class TinyTurboGenerateResult:
    prompt: str
    text: str
    generated_text: str
    input_tokens: int
    output_tokens: int
    kv_policy: str
    elapsed_seconds: float
    tokens_per_second: float
    cache_report: dict[str, Any]
    token_ids: list[int] = field(default_factory=list)
    per_step: list[dict[str, Any]] = field(default_factory=list)
    logits: list[torch.Tensor] = field(default_factory=list, repr=False)

    def to_dict(self, *, include_per_step: bool = True) -> dict[str, Any]:
        payload = {
            "prompt": self.prompt,
            "text": self.text,
            "generated_text": self.generated_text,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "kv_policy": self.kv_policy,
            "elapsed_seconds": self.elapsed_seconds,
            "tokens_per_second": self.tokens_per_second,
            "cache_report": self.cache_report,
            "token_ids": self.token_ids,
            "backend_boundary": f"compressed KV is stored between decode steps; v{__version__} dequantizes before stock HF attention",
        }
        if include_per_step and self.per_step:
            payload["per_step"] = self.per_step
        return payload


class TinyTurboHFEngine:
    """Minimal compressed-KV serving engine for Hugging Face decoder models.

    This engine intentionally starts conservative: it stores the cache compressed
    between forward passes and materializes dense past_key_values for the next
    stock Hugging Face call.  That is enough to make the package a real runtime
    backend foundation without pretending fused compressed attention is done.
    """

    def __init__(
        self,
        model_name: str,
        *,
        kv_policy: str | KVPolicy = "fp16k-q8v",
        device: str = "auto",
        dtype: str = "auto",
        local_files_only: bool = False,
        trust_remote_code: bool = False,
        cache_mode: str = "dense-shadow",
        incremental_kv: bool = True,
        sparse_v: bool = False,
        sparse_v_threshold: float = 1e-6,
        dense_shadow: bool | None = None,
    ) -> None:
        self.model_name = model_name
        self.policy = resolve_kv_policy(kv_policy)
        self.device = self._resolve_device(device)
        self.dtype = self._resolve_dtype(dtype, self.device)
        self.local_files_only = local_files_only
        self.trust_remote_code = trust_remote_code
        # v0.13.3 cache modes:
        #   dense-shadow: keep a dense HF cache during active decode for speed,
        #                 rebuild/report compressed storage at the end.
        #   compressed:   materialize from compressed storage each step; lower active
        #                 KV residency but much slower on stock HF attention.
        if dense_shadow is not None:
            # Backward-compatible override for older callers.
            cache_mode = "dense-shadow" if bool(dense_shadow) else "compressed"
        cache_mode = str(cache_mode).lower().replace("_", "-")
        if cache_mode not in {"dense-shadow", "compressed"}:
            raise ValueError("cache_mode must be 'dense-shadow' or 'compressed'")
        self.cache_mode = cache_mode
        self.incremental_kv = bool(incremental_kv)
        self.sparse_v = bool(sparse_v)
        self.sparse_v_threshold = float(sparse_v_threshold)
        self.dense_shadow = cache_mode == "dense-shadow"
        self.tokenizer = None
        self.model = None

    @staticmethod
    def _resolve_device(device: str) -> str:
        if device == "auto":
            return "cuda" if torch.cuda.is_available() else "cpu"
        if device == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but torch.cuda.is_available() is false")
        return device

    @staticmethod
    def _resolve_dtype(dtype: str, device: str) -> torch.dtype:
        key = str(dtype).lower()
        if key == "auto":
            return torch.float16 if device == "cuda" else torch.float32
        if key in {"float16", "fp16", "half"}:
            return torch.float16
        if key in {"bfloat16", "bf16"}:
            return torch.bfloat16
        if key in {"float32", "fp32"}:
            return torch.float32
        raise ValueError(f"unsupported dtype {dtype!r}")

    def load(self) -> "TinyTurboHFEngine":
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
        except Exception as exc:  # pragma: no cover
            raise ImportError(
                "transformers is required for the HF serving backend. "
                "Install with: pip install 'tiny-turboquant[hf]'"
            ) from exc
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.model_name,
            local_files_only=self.local_files_only,
            trust_remote_code=self.trust_remote_code,
        )
        if self.tokenizer.pad_token_id is None and self.tokenizer.eos_token_id is not None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.model = AutoModelForCausalLM.from_pretrained(
            self.model_name,
            torch_dtype=self.dtype,
            local_files_only=self.local_files_only,
            trust_remote_code=self.trust_remote_code,
        ).to(self.device)
        self.model.eval()
        return self

    def _ensure_loaded(self) -> None:
        if self.model is None or self.tokenizer is None:
            self.load()

    def generate(
        self,
        prompt: str,
        *,
        max_new_tokens: int = 64,
        temperature: float = 0.0,
        stop_on_eos: bool = True,
        seed: int = 123,
        collect_logits: bool = False,
        collect_per_step: bool = True,
        deterministic: bool = True,
    ) -> TinyTurboGenerateResult:
        self._ensure_loaded()
        assert self.model is not None and self.tokenizer is not None
        torch.manual_seed(int(seed))
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(int(seed))
        if deterministic:
            try:
                torch.use_deterministic_algorithms(True, warn_only=True)
            except Exception:
                pass
        encoded = self.tokenizer(prompt, return_tensors="pt")
        input_ids = encoded["input_ids"].to(self.device)
        attention_mask = encoded.get("attention_mask")
        if attention_mask is not None:
            attention_mask = attention_mask.to(self.device)
        generated: list[int] = []
        per_step: list[dict[str, Any]] = []
        logits_trace: list[torch.Tensor] = []
        compressed_cache: TinyTurboKVCache | None = None
        next_input = input_ids
        t0 = perf_counter()
        # Sparse-V is a model-wide attention transform, so it has to wrap the
        # entire decode loop. When disabled it is a no-op nullcontext.
        from contextlib import nullcontext
        sparse_ctx = sparse_v_sdpa(self.sparse_v_threshold) if self.sparse_v else nullcontext()
        sparse_stats = None
        with torch.no_grad(), sparse_ctx as _sv_stats:
            sparse_stats = _sv_stats
            for step in range(int(max_new_tokens)):
                if compressed_cache is None:
                    outputs = self.model(input_ids=next_input, attention_mask=attention_mask, use_cache=True, return_dict=True)
                else:
                    past = compressed_cache.to_model_past(dtype=self.dtype, device=self.device)
                    outputs = self.model(input_ids=next_input, past_key_values=past, use_cache=True, return_dict=True)
                logits = outputs.logits[:, -1, :]
                logits_f = logits.detach().to(torch.float32)
                top_values, top_indices = torch.topk(logits_f, k=min(5, logits_f.shape[-1]), dim=-1)
                if collect_logits:
                    logits_trace.append(logits_f.cpu())
                if temperature and temperature > 0:
                    probs = torch.softmax(logits / float(temperature), dim=-1)
                    next_token = torch.multinomial(probs, num_samples=1)
                    decode_mode = "sample"
                else:
                    next_token = torch.argmax(logits, dim=-1, keepdim=True)
                    decode_mode = "greedy"
                token_id = int(next_token.item())
                generated.append(token_id)
                if collect_per_step:
                    per_step.append({
                        "step": step,
                        "token_id": token_id,
                        "decode_mode": decode_mode,
                        "top1_id": int(top_indices[0, 0].item()),
                        "top1_logit": float(top_values[0, 0].item()),
                        "top5_ids": [int(x) for x in top_indices[0].tolist()],
                        "top5_logits": [float(x) for x in top_values[0].tolist()],
                    })
                if compressed_cache is None or not self.incremental_kv:
                    compressed_cache = TinyTurboKVCache.from_past_key_values(
                        outputs.past_key_values,
                        self.policy,
                        dense_dtype=self.dtype,
                        keep_dense_shadow=self.dense_shadow,
                    )
                elif self.dense_shadow:
                    # Fast path: only refresh the dense shadow. Skip per-step
                    # compressed-store maintenance; rebuild once at end of
                    # decode for accurate memory_saved_pct reporting.
                    compressed_cache.refresh_dense_shadow(outputs.past_key_values)
                else:
                    # Incremental path: only the newly produced row is
                    # compressed and concatenated. Falls back transparently
                    # for legacy single-block tensors inside ``step_append``.
                    compressed_cache = compressed_cache.step_append(
                        outputs.past_key_values,
                        keep_dense_shadow=self.dense_shadow,
                    )
                next_input = next_token.to(self.device)
                attention_mask = None
                if stop_on_eos and self.tokenizer.eos_token_id is not None and token_id == int(self.tokenizer.eos_token_id):
                    break
        elapsed = perf_counter() - t0
        # If the dense shadow fast-path was used, the compressed store still
        # holds its prefill-snapshot seq_len. Rebuild it once from the final
        # dense KV so memory_saved_pct and seq_len reflect the full sequence.
        if (
            self.dense_shadow
            and self.incremental_kv
            and compressed_cache is not None
            and compressed_cache._dense_shadow is not None
            and compressed_cache.seq_len() < int(input_ids.shape[-1]) + len(generated)
        ):
            compressed_cache = TinyTurboKVCache.from_past_key_values(
                compressed_cache._dense_shadow,
                self.policy,
                dense_dtype=self.dtype,
                keep_dense_shadow=False,
            )
        gen_text = self.tokenizer.decode(generated, skip_special_tokens=True)
        full_text = prompt + gen_text
        cache_report = compressed_cache.to_dict() if compressed_cache is not None else {}
        if sparse_stats is not None:
            cache_report["sparse_v"] = sparse_stats.to_dict()
        else:
            cache_report["sparse_v"] = {"enabled": False}
        cache_report["cache_mode"] = self.cache_mode
        cache_report["incremental_kv"] = self.incremental_kv
        cache_report["dense_shadow_during_decode"] = bool(self.dense_shadow)
        dense_bytes = int(cache_report.get("dense_fp16_bytes") or 0)
        compressed_bytes = int(cache_report.get("compressed_storage_bytes") or 0)
        cache_report["active_dense_shadow_bytes"] = dense_bytes if self.dense_shadow else 0
        cache_report["compressed_at_rest_saved_pct"] = float(cache_report.get("memory_saved_pct") or 0.0)
        if self.dense_shadow:
            # Conservative accounting: active decode holds the fp16 HF cache and
            # a compressed bookkeeping object. This is not an active-memory-saving mode.
            effective_active = dense_bytes + compressed_bytes
        else:
            effective_active = compressed_bytes
        cache_report["effective_active_kv_bytes"] = int(effective_active)
        cache_report["active_decode_memory_saved_pct"] = (1.0 - effective_active / max(dense_bytes, 1)) * 100.0 if dense_bytes else 0.0
        return TinyTurboGenerateResult(
            prompt=prompt,
            text=full_text,
            generated_text=gen_text,
            input_tokens=int(input_ids.shape[-1]),
            output_tokens=len(generated),
            kv_policy=self.policy.name,
            elapsed_seconds=elapsed,
            tokens_per_second=len(generated) / max(elapsed, 1e-9),
            cache_report=cache_report,
            token_ids=generated,
            per_step=per_step,
            logits=logits_trace,
        )


def load_hf_engine(**kwargs: Any) -> TinyTurboHFEngine:
    return TinyTurboHFEngine(**kwargs).load()
