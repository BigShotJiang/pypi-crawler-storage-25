﻿"""Validation and benchmark helpers for the compressed-KV HF backend."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from ..backends.hf import TinyTurboHFEngine
from ..kv.policy import available_kv_policies, resolve_kv_policy


@dataclass
class GenerationComparison:
    prompt: str
    baseline_text: str
    candidate_text: str
    baseline_generated: str
    candidate_generated: str
    same_prefix_tokens: int
    baseline_tokens: int
    candidate_tokens: int
    exact_text_match: bool
    exact_generated_match: bool
    first_divergence_index: int | None
    first_divergence: dict[str, Any] | None
    token_match_count: int
    token_match_ratio: float
    prefix_match_ratio: float
    length_delta: int

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__.copy()


def same_prefix_len(a: list[int], b: list[int]) -> int:
    n = 0
    for x, y in zip(a, b):
        if x != y:
            break
        n += 1
    return n


def token_match_count(a: list[int], b: list[int]) -> int:
    return sum(1 for x, y in zip(a, b) if x == y)


def first_divergence(a: list[int], b: list[int]) -> tuple[int | None, dict[str, Any] | None]:
    for idx, (x, y) in enumerate(zip(a, b)):
        if x != y:
            return idx, {"index": idx, "baseline_token_id": int(x), "candidate_token_id": int(y)}
    if len(a) != len(b):
        idx = min(len(a), len(b))
        return idx, {
            "index": idx,
            "baseline_token_id": int(a[idx]) if idx < len(a) else None,
            "candidate_token_id": int(b[idx]) if idx < len(b) else None,
            "reason": "length mismatch",
        }
    return None, None


def compare_step_traces(base_steps: list[dict[str, Any]], cand_steps: list[dict[str, Any]]) -> dict[str, Any]:
    compared = min(len(base_steps), len(cand_steps))
    if compared == 0:
        return {"steps_compared": 0, "top1_match_count": 0, "top1_match_ratio": 0.0}
    top1_matches = 0
    generated_matches = 0
    first_top1_divergence = None
    first_generated_divergence = None
    for i in range(compared):
        b = base_steps[i]
        c = cand_steps[i]
        if int(b.get("top1_id", -1)) == int(c.get("top1_id", -2)):
            top1_matches += 1
        elif first_top1_divergence is None:
            first_top1_divergence = {
                "step": i,
                "baseline_top1_id": b.get("top1_id"),
                "candidate_top1_id": c.get("top1_id"),
                "baseline_top1_logit": b.get("top1_logit"),
                "candidate_top1_logit": c.get("top1_logit"),
            }
        if int(b.get("token_id", -1)) == int(c.get("token_id", -2)):
            generated_matches += 1
        elif first_generated_divergence is None:
            first_generated_divergence = {
                "step": i,
                "baseline_token_id": b.get("token_id"),
                "candidate_token_id": c.get("token_id"),
            }
    return {
        "steps_compared": compared,
        "top1_match_count": top1_matches,
        "top1_match_ratio": top1_matches / max(compared, 1),
        "generated_token_match_count": generated_matches,
        "generated_token_match_ratio": generated_matches / max(compared, 1),
        "first_top1_divergence": first_top1_divergence,
        "first_generated_divergence": first_generated_divergence,
    }


def compare_logits(base_logits: list[torch.Tensor], cand_logits: list[torch.Tensor]) -> dict[str, Any]:
    compared = min(len(base_logits), len(cand_logits))
    if compared == 0:
        return {"enabled": False, "steps_compared": 0}
    max_abs_values: list[float] = []
    mean_abs_values: list[float] = []
    cosine_values: list[float] = []
    # v0.13.3: KL divergence + same-top-p and prob-RMS metrics. These
    # signals are more sensitive than token-match ratio and remain useful
    # even when generated trajectories diverge.
    kld_values: list[float] = []
    same_top5_count = 0
    same_top10_count = 0
    delta_p_rms_values: list[float] = []
    top1_matches = 0
    first_top1_divergence = None
    for i in range(compared):
        b = base_logits[i].to(torch.float32).reshape(1, -1)
        c = cand_logits[i].to(torch.float32).reshape(1, -1)
        delta = (b - c).abs()
        max_abs_values.append(float(delta.max().item()))
        mean_abs_values.append(float(delta.mean().item()))
        cos = torch.nn.functional.cosine_similarity(b, c, dim=-1)
        cosine_values.append(float(cos.item()))
        # Probability-space metrics.
        bp = torch.nn.functional.log_softmax(b, dim=-1)
        cp = torch.nn.functional.log_softmax(c, dim=-1)
        # KL( baseline || candidate ) = sum p_b * (log p_b - log p_c).
        p_b = bp.exp()
        kld = torch.sum(p_b * (bp - cp), dim=-1).clamp_min(0.0)
        kld_values.append(float(kld.item()))
        # |p_b - p_c| RMS, a sharper "did the distribution actually change"
        # signal than |logit| deltas alone.
        delta_p = (p_b - cp.exp())
        delta_p_rms_values.append(float(torch.sqrt((delta_p * delta_p).mean()).item()))
        # Same-top-k indicator (5 and 10).
        k5 = min(5, b.shape[-1])
        k10 = min(10, b.shape[-1])
        b_top_k5 = set(int(x) for x in torch.topk(b, k5, dim=-1).indices[0].tolist())
        c_top_k5 = set(int(x) for x in torch.topk(c, k5, dim=-1).indices[0].tolist())
        b_top_k10 = set(int(x) for x in torch.topk(b, k10, dim=-1).indices[0].tolist())
        c_top_k10 = set(int(x) for x in torch.topk(c, k10, dim=-1).indices[0].tolist())
        if b_top_k5 == c_top_k5:
            same_top5_count += 1
        if b_top_k10 == c_top_k10:
            same_top10_count += 1
        b_top = int(torch.argmax(b, dim=-1).item())
        c_top = int(torch.argmax(c, dim=-1).item())
        if b_top == c_top:
            top1_matches += 1
        elif first_top1_divergence is None:
            first_top1_divergence = {
                "step": i,
                "baseline_top1_id": b_top,
                "candidate_top1_id": c_top,
                "max_abs_logit_delta": max_abs_values[-1],
                "mean_abs_logit_delta": mean_abs_values[-1],
                "logit_cosine": cosine_values[-1],
                "kl_divergence": kld_values[-1],
            }
    return {
        "enabled": True,
        "steps_compared": compared,
        "top1_match_count": top1_matches,
        "top1_match_ratio": top1_matches / max(compared, 1),
        "max_abs_logit_delta_mean": sum(max_abs_values) / compared,
        "max_abs_logit_delta_max": max(max_abs_values),
        "mean_abs_logit_delta_mean": sum(mean_abs_values) / compared,
        "logit_cosine_mean": sum(cosine_values) / compared,
        "logit_cosine_min": min(cosine_values),
        "kl_divergence_mean": sum(kld_values) / compared,
        "kl_divergence_max": max(kld_values),
        "delta_p_rms_mean": sum(delta_p_rms_values) / compared,
        "delta_p_rms_max": max(delta_p_rms_values),
        "same_top5_count": same_top5_count,
        "same_top5_ratio": same_top5_count / max(compared, 1),
        "same_top10_count": same_top10_count,
        "same_top10_ratio": same_top10_count / max(compared, 1),
        "first_top1_divergence": first_top1_divergence,
        "note": "Logit deltas are compared step-by-step. After generated tokens diverge, contexts differ, so later logit deltas measure downstream divergence as well as cache error.",
    }


def quality_verdict(prefix_ratio: float, token_ratio: float, exact: bool, threshold: float) -> str:
    if exact:
        return "exact-match"
    if prefix_ratio >= threshold and token_ratio >= threshold:
        return "near-stable"
    if prefix_ratio >= max(0.5, threshold * 0.75):
        return "prefix-stable-then-diverged"
    return "diverged"


def policy_summary(base: Any, cand: Any) -> dict[str, Any]:
    base_cache = base.cache_report or {}
    cand_cache = cand.cache_report or {}
    return {
        "baseline_policy": base.kv_policy,
        "candidate_policy": cand.kv_policy,
        "baseline_tokens_per_second": base.tokens_per_second,
        "candidate_tokens_per_second": cand.tokens_per_second,
        "tokens_per_second_ratio_candidate_over_baseline": cand.tokens_per_second / max(base.tokens_per_second, 1e-9),
        "baseline_memory_saved_pct": float(base_cache.get("memory_saved_pct", 0.0)),
        "candidate_memory_saved_pct": float(cand_cache.get("memory_saved_pct", 0.0)),
        "candidate_compression_ratio": float(cand_cache.get("compression_ratio", 1.0)),
        "baseline_compressed_storage_bytes": int(base_cache.get("compressed_storage_bytes", 0)),
        "candidate_compressed_storage_bytes": int(cand_cache.get("compressed_storage_bytes", 0)),
        "dense_fp16_bytes": int(cand_cache.get("dense_fp16_bytes", base_cache.get("dense_fp16_bytes", 0))),
    }




def policy_quality_recommendation(
    *,
    baseline_policy: str,
    candidate_policy: str,
    verdict: str,
    comparison: GenerationComparison,
    summary: dict[str, Any],
) -> dict[str, Any]:
    """Explain whether a candidate policy is safe enough for the current run.

    This is intentionally rule-based. v0.13.3 corrects the default policy
    after Qwen validation showed ``fp16k-q8v`` exact-matched a 64-token prompt
    while boundary-only V compression diverged.
    """
    base = resolve_kv_policy(baseline_policy)
    cand = resolve_kv_policy(candidate_policy)
    memory_saved = float(summary.get("candidate_memory_saved_pct", 0.0))
    exact = verdict == "exact-match"
    early_divergence = comparison.first_divergence_index is not None and comparison.first_divergence_index <= max(8, comparison.baseline_tokens // 4)

    if exact and memory_saved > 0:
        status = "safe_for_this_prompt"
    elif exact:
        status = "safe_for_this_prompt"
    elif verdict == "near-stable":
        status = "near_stable"
    elif verdict == "prefix-stable-then-diverged":
        status = "risky_for_long_generation"
    else:
        status = "unstable"

    if cand.is_fp16 and base.is_fp16:
        cause = "self-test: both baseline and candidate use dense fp16 KV"
        next_action = "backend deterministic self-test passed" if exact else "investigate decode-loop determinism before testing compression"
    elif exact and memory_saved > 0:
        cause = "candidate preserved the exact token path while reducing KV storage"
        next_action = "prefer this policy over lower-memory candidates unless a broader prompt suite exposes divergence"
    elif exact:
        cause = "candidate preserved the exact token path under strict token-level validation"
        next_action = "use as baseline or compare against compressed policies"
    elif cand.key_bits < 16 and early_divergence:
        cause = "candidate compresses K; K controls attention routing and can flip close top-1 logits"
        next_action = "try fp16k-q8v before boundary or q8 K policies"
    elif cand.key_bits >= 16 and cand.value_bits < 16 and verdict == "diverged":
        cause = "K is protected; divergence is more likely from value compression or accumulated dequantization drift"
        next_action = "try shorter outputs, collect logits, or keep fp16 for sensitive prompts"
    elif cand.boundary_layer_count > 0 and verdict == "diverged":
        cause = "boundary protection was enabled but middle-layer compression still changed generation"
        next_action = "try fp16k-q8v; recent Qwen validation favored full V-only q8 over boundary-protected V-only q8"
    else:
        cause = "candidate changed the token path under strict token-level validation"
        next_action = "compare policies and choose the exact-match candidate with highest memory saving"

    return {
        "status": status,
        "candidate_policy_class": cand.recommendation_class(),
        "memory_saved_pct": memory_saved,
        "early_divergence": bool(early_divergence),
        "cause_hint": cause,
        "next_action": next_action,
        "safe_default_order": [
            "fp16",
            "fp16k-q8v",
            "boundary-fp16-fp16k-q8v",
            "boundary-fp16-q8k-q8v",
            "q8k-q8v",
            "q8k-int4v",
        ],
    }


def _generation_report_from_results(
    *,
    model: str,
    prompt: str,
    baseline_policy: str,
    candidate_policy: str,
    base: Any,
    cand: Any,
    quality_threshold: float,
    temperature: float,
    include_per_step_payload: bool = True,
) -> dict[str, Any]:
    prefix = same_prefix_len(base.token_ids, cand.token_ids)
    matches = token_match_count(base.token_ids, cand.token_ids)
    denom = max(len(base.token_ids), len(cand.token_ids), 1)
    min_denom = max(min(len(base.token_ids), len(cand.token_ids)), 1)
    div_idx, div_payload = first_divergence(base.token_ids, cand.token_ids)
    comparison = GenerationComparison(
        prompt=prompt,
        baseline_text=base.text,
        candidate_text=cand.text,
        baseline_generated=base.generated_text,
        candidate_generated=cand.generated_text,
        same_prefix_tokens=prefix,
        baseline_tokens=len(base.token_ids),
        candidate_tokens=len(cand.token_ids),
        exact_text_match=base.token_ids == cand.token_ids,
        exact_generated_match=base.generated_text == cand.generated_text,
        first_divergence_index=div_idx,
        first_divergence=div_payload,
        token_match_count=matches,
        token_match_ratio=matches / denom,
        prefix_match_ratio=prefix / min_denom,
        length_delta=len(cand.token_ids) - len(base.token_ids),
    )
    verdict = quality_verdict(
        comparison.prefix_match_ratio,
        comparison.token_match_ratio,
        comparison.exact_text_match,
        quality_threshold,
    )
    summary = policy_summary(base, cand)
    return {
        "model": model,
        "baseline_policy": baseline_policy,
        "candidate_policy": candidate_policy,
        "quality_threshold": quality_threshold,
        "decode_mode": "greedy" if temperature <= 0 else "sample",
        "self_test": baseline_policy == "fp16" and candidate_policy == "fp16",
        "comparison": comparison.to_dict(),
        "step_comparison": compare_step_traces(base.per_step, cand.per_step),
        "logit_comparison": compare_logits(base.logits, cand.logits),
        "policy_summary": summary,
        "policy_recommendation": policy_quality_recommendation(
            baseline_policy=baseline_policy,
            candidate_policy=candidate_policy,
            verdict=verdict,
            comparison=comparison,
            summary=summary,
        ),
        "quality_verdict": verdict,
        "baseline": base.to_dict(include_per_step=include_per_step_payload),
        "candidate": cand.to_dict(include_per_step=include_per_step_payload),
        "boundary": "This validates compressed KV storage in the HF decode loop; it is not a fused-kernel throughput claim.",
    }


def compare_backend_generation(
    *,
    model: str,
    prompt: str,
    candidate_policy: str,
    baseline_policy: str = "fp16",
    max_new_tokens: int = 32,
    device: str = "auto",
    dtype: str = "auto",
    local_files_only: bool = False,
    trust_remote_code: bool = False,
    seed: int = 123,
    temperature: float = 0.0,
    collect_logits: bool = False,
    quality_threshold: float = 0.95,
    include_per_step_payload: bool = True,
) -> dict[str, Any]:
    baseline_engine = TinyTurboHFEngine(
        model,
        kv_policy=baseline_policy,
        device=device,
        dtype=dtype,
        local_files_only=local_files_only,
        trust_remote_code=trust_remote_code,
    ).load()
    candidate_engine = TinyTurboHFEngine(
        model,
        kv_policy=candidate_policy,
        device=device,
        dtype=dtype,
        local_files_only=local_files_only,
        trust_remote_code=trust_remote_code,
    )
    candidate_engine.tokenizer = baseline_engine.tokenizer
    candidate_engine.model = baseline_engine.model
    base = baseline_engine.generate(
        prompt,
        max_new_tokens=max_new_tokens,
        seed=seed,
        temperature=temperature,
        collect_logits=collect_logits,
        deterministic=temperature <= 0,
    )
    cand = base if baseline_policy == candidate_policy else candidate_engine.generate(
        prompt,
        max_new_tokens=max_new_tokens,
        seed=seed,
        temperature=temperature,
        collect_logits=collect_logits,
        deterministic=temperature <= 0,
    )
    return _generation_report_from_results(
        model=model,
        prompt=prompt,
        baseline_policy=baseline_policy,
        candidate_policy=candidate_policy,
        base=base,
        cand=cand,
        quality_threshold=quality_threshold,
        temperature=temperature,
        include_per_step_payload=include_per_step_payload,
    )


def default_policy_compare_order() -> list[str]:
    return [
        "fp16",
        "fp16k-q8v",
        "boundary-fp16-fp16k-q8v",
        "boundary-fp16-q8k-q8v",
        "q8k-q8v",
        "q8k-int4v",
        "fp16k-int4v-last8-fp16",
        "q8k-int4v-last8-q8v",
        "fp16k-int4v-boundary-last",
    ]


def compare_policy_matrix(
    *,
    model: str,
    prompt: str,
    policies: list[str] | None = None,
    baseline_policy: str = "fp16",
    max_new_tokens: int = 32,
    device: str = "auto",
    dtype: str = "auto",
    local_files_only: bool = False,
    trust_remote_code: bool = False,
    seed: int = 123,
    temperature: float = 0.0,
    collect_logits: bool = False,
    quality_threshold: float = 0.95,
    include_per_step_payload: bool = True,
) -> dict[str, Any]:
    """Compare multiple compressed-KV policies against one dense baseline.

    The model is loaded once, then reused for all candidate policies. The
    recommendation chooses the exact-match candidate with the highest memory
    saving; otherwise it falls back to the highest token-match ratio.
    """
    requested = list(policies or default_policy_compare_order())
    unknown = [p for p in requested if p not in available_kv_policies()]
    if unknown:
        raise ValueError(f"unknown KV policies in comparison: {unknown}")

    baseline_engine = TinyTurboHFEngine(
        model,
        kv_policy=baseline_policy,
        device=device,
        dtype=dtype,
        local_files_only=local_files_only,
        trust_remote_code=trust_remote_code,
    ).load()
    base = baseline_engine.generate(
        prompt,
        max_new_tokens=max_new_tokens,
        seed=seed,
        temperature=temperature,
        collect_logits=collect_logits,
        deterministic=temperature <= 0,
    )

    rows: list[dict[str, Any]] = []
    reports: dict[str, Any] = {}
    for name in requested:
        candidate_engine = TinyTurboHFEngine(
            model,
            kv_policy=name,
            device=device,
            dtype=dtype,
            local_files_only=local_files_only,
            trust_remote_code=trust_remote_code,
        )
        candidate_engine.tokenizer = baseline_engine.tokenizer
        candidate_engine.model = baseline_engine.model
        cand = base if name == baseline_policy else candidate_engine.generate(
            prompt,
            max_new_tokens=max_new_tokens,
            seed=seed,
            temperature=temperature,
            collect_logits=collect_logits,
            deterministic=temperature <= 0,
        )
        report = _generation_report_from_results(
            model=model,
            prompt=prompt,
            baseline_policy=baseline_policy,
            candidate_policy=name,
            base=base,
            cand=cand,
            quality_threshold=quality_threshold,
            temperature=temperature,
            include_per_step_payload=include_per_step_payload,
        )
        reports[name] = report
        cmp = report["comparison"]
        summ = report["policy_summary"]
        rows.append({
            "policy": name,
            "quality_verdict": report["quality_verdict"],
            "exact_generated_match": bool(cmp.get("exact_generated_match")),
            "token_match_ratio": float(cmp.get("token_match_ratio", 0.0)),
            "prefix_match_ratio": float(cmp.get("prefix_match_ratio", 0.0)),
            "first_divergence_index": cmp.get("first_divergence_index"),
            "memory_saved_pct": float(summ.get("candidate_memory_saved_pct", 0.0)),
            "compression_ratio": float(summ.get("candidate_compression_ratio", 1.0)),
            "tokens_per_second": float(summ.get("candidate_tokens_per_second", 0.0)),
            "tokens_per_second_ratio": float(summ.get("tokens_per_second_ratio_candidate_over_baseline", 0.0)),
            "recommendation_status": report["policy_recommendation"].get("status"),
        })

    exact_rows = [r for r in rows if r["exact_generated_match"] and r["policy"] != baseline_policy]
    compressed_rows = [r for r in rows if r["policy"] != baseline_policy]
    risky_rows = [r for r in compressed_rows if not r["exact_generated_match"]]
    best_risky = max(
        risky_rows,
        key=lambda r: (r["token_match_ratio"], r["prefix_match_ratio"], r["memory_saved_pct"]),
        default=None,
    )
    best_quality_memory = max(exact_rows, key=lambda r: (r["memory_saved_pct"], r["tokens_per_second_ratio"]), default=None)
    best_quality_speed = max(exact_rows, key=lambda r: (r["tokens_per_second_ratio"], r["memory_saved_pct"]), default=None)
    if exact_rows:
        best = best_quality_memory
        reason = "selected highest-memory-saving exact-match compressed policy"
    else:
        best = next((r for r in rows if r["policy"] == baseline_policy), rows[0] if rows else {})
        reason = "no compressed policy exact-matched; use fp16 baseline and treat best compressed candidate as risky"

    unsafe_policies = [r["policy"] for r in risky_rows]
    exact_compressed_policies = [r["policy"] for r in exact_rows]

    return {
        "model": model,
        "baseline_policy": baseline_policy,
        "quality_threshold": quality_threshold,
        "decode_mode": "greedy" if temperature <= 0 else "sample",
        "prompt": prompt,
        "max_new_tokens": max_new_tokens,
        "policies": requested,
        "rows": rows,
        "recommended_policy": best.get("policy") if best else None,
        "recommendation_reason": reason,
        "best_quality_memory_policy": best_quality_memory.get("policy") if best_quality_memory else None,
        "best_quality_speed_policy": best_quality_speed.get("policy") if best_quality_speed else None,
        "best_risky_policy": best_risky.get("policy") if best_risky else None,
        "best_risky_policy_token_match_ratio": best_risky.get("token_match_ratio") if best_risky else None,
        "exact_compressed_policies": exact_compressed_policies,
        "unsafe_policies": unsafe_policies,
        "reports": reports,
        "boundary": "Policy comparison validates compressed KV storage quality; it is not a fused-kernel throughput claim.",
    }


def policy_matrix_markdown(report: dict[str, Any]) -> str:
    lines = [
        "# tiny-turboquant policy comparison",
        "",
        f"- Model: `{report.get('model')}`",
        f"- Baseline: `{report.get('baseline_policy')}`",
        f"- Decode mode: `{report.get('decode_mode')}`",
        f"- Max new tokens: `{report.get('max_new_tokens')}`",
        f"- Recommended policy: `{report.get('recommended_policy')}`",
        f"- Recommendation reason: {report.get('recommendation_reason')}",
        f"- Best quality-memory compressed policy: `{report.get('best_quality_memory_policy')}`",
        f"- Best quality-speed compressed policy: `{report.get('best_quality_speed_policy')}`",
        f"- Best risky compressed policy: `{report.get('best_risky_policy')}`",
        f"- Exact-match compressed policies: `{', '.join(report.get('exact_compressed_policies', [])) or 'none'}`",
        f"- Unsafe compressed policies: `{', '.join(report.get('unsafe_policies', [])) or 'none'}`",
        "",
        "| Policy | Verdict | Exact | Token match | Prefix match | First divergence | Memory saved % | Compression | TPS ratio |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in report.get("rows", []):
        lines.append(
            "| {policy} | {quality_verdict} | {exact} | {token:.4f} | {prefix:.4f} | {div} | {mem:.2f} | {comp:.3f}x | {tps:.3f} |".format(
                policy=row.get("policy"),
                quality_verdict=row.get("quality_verdict"),
                exact="yes" if row.get("exact_generated_match") else "no",
                token=float(row.get("token_match_ratio", 0.0)),
                prefix=float(row.get("prefix_match_ratio", 0.0)),
                div=row.get("first_divergence_index"),
                mem=float(row.get("memory_saved_pct", 0.0)),
                comp=float(row.get("compression_ratio", 1.0)),
                tps=float(row.get("tokens_per_second_ratio", 0.0)),
            )
        )
    lines.extend(["", report.get("boundary", "")])
    return "\n".join(lines)
