"""Validation helpers for the compressed-KV backend."""

from .backend import (
    GenerationComparison,
    compare_logits,
    compare_step_traces,
    first_divergence,
    policy_quality_recommendation,
    policy_summary,
    quality_verdict,
    same_prefix_len,
    token_match_count,
)
from .quality import (
    KLSeriesResult,
    NIAHResult,
    build_niah_prompt,
    kl_divergence_per_step,
    niah_passkey_test,
    summarize_kl_series,
)

__all__ = [
    "GenerationComparison",
    "compare_logits",
    "compare_step_traces",
    "first_divergence",
    "policy_quality_recommendation",
    "policy_summary",
    "quality_verdict",
    "same_prefix_len",
    "token_match_count",
    "KLSeriesResult",
    "NIAHResult",
    "build_niah_prompt",
    "kl_divergence_per_step",
    "niah_passkey_test",
    "summarize_kl_series",
]
