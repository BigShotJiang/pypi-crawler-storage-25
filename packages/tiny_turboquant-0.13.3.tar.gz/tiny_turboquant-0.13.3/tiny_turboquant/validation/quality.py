﻿"""Quality harnesses for v0.13.3: KL@D series and NIAH passkey test.

These mirror what the external ``turboquant_plus`` benchmarks gate on:
  * KL divergence per decode step over a fixed reference prompt
    (1.0e-04 is "perfectly safe", 1.0e-02 starts to be visible).
  * Needle-in-a-haystack passkey recall at long context, which is a more
    sensitive proxy for "did the cache lose information" than perplexity.

They are intentionally small and self-contained so they can be invoked from
the CLI, from tests, and from the cross-model smoke example without pulling
in a full eval framework.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import math

import torch


@dataclass
class KLSeriesResult:
    """Per-step KL divergence between two engines on the same prompt."""

    prompt: str
    max_new_tokens: int
    baseline_policy: str
    candidate_policy: str
    kld_per_step: list[float] = field(default_factory=list)
    kld_mean: float = 0.0
    kld_max: float = 0.0
    kld_p95: float = 0.0
    same_top1_ratio: float = 0.0
    same_top5_ratio: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "prompt": self.prompt,
            "max_new_tokens": self.max_new_tokens,
            "baseline_policy": self.baseline_policy,
            "candidate_policy": self.candidate_policy,
            "kld_per_step": self.kld_per_step,
            "kld_mean": self.kld_mean,
            "kld_max": self.kld_max,
            "kld_p95": self.kld_p95,
            "same_top1_ratio": self.same_top1_ratio,
            "same_top5_ratio": self.same_top5_ratio,
        }


def kl_divergence_per_step(
    base_logits: list[torch.Tensor],
    cand_logits: list[torch.Tensor],
) -> list[float]:
    """KL( baseline || candidate ) per decode step, in nats.

    Both inputs are lists of last-token logits in step order. Returns a list
    of length ``min(len(base_logits), len(cand_logits))`` of non-negative
    KL values. A value below ~1e-4 is statistically indistinguishable from
    the baseline; values above ~1e-2 typically correlate with visible
    generation drift.
    """
    n = min(len(base_logits), len(cand_logits))
    out: list[float] = []
    for i in range(n):
        b = base_logits[i].to(torch.float32).reshape(1, -1)
        c = cand_logits[i].to(torch.float32).reshape(1, -1)
        bp = torch.nn.functional.log_softmax(b, dim=-1)
        cp = torch.nn.functional.log_softmax(c, dim=-1)
        p_b = bp.exp()
        kld = torch.sum(p_b * (bp - cp), dim=-1).clamp_min(0.0)
        out.append(float(kld.item()))
    return out


def summarize_kl_series(
    *,
    prompt: str,
    baseline_policy: str,
    candidate_policy: str,
    base_logits: list[torch.Tensor],
    cand_logits: list[torch.Tensor],
    max_new_tokens: int,
) -> KLSeriesResult:
    kld = kl_divergence_per_step(base_logits, cand_logits)
    n = len(kld)
    if n == 0:
        return KLSeriesResult(
            prompt=prompt,
            max_new_tokens=max_new_tokens,
            baseline_policy=baseline_policy,
            candidate_policy=candidate_policy,
        )
    sorted_k = sorted(kld)
    p95_idx = min(n - 1, int(math.ceil(0.95 * n)) - 1)
    top1 = 0
    top5 = 0
    for i in range(min(len(base_logits), len(cand_logits))):
        b = base_logits[i].to(torch.float32).reshape(-1)
        c = cand_logits[i].to(torch.float32).reshape(-1)
        if int(torch.argmax(b).item()) == int(torch.argmax(c).item()):
            top1 += 1
        k5 = min(5, b.shape[-1])
        b_top = set(int(x) for x in torch.topk(b, k5).indices.tolist())
        c_top = set(int(x) for x in torch.topk(c, k5).indices.tolist())
        if b_top == c_top:
            top5 += 1
    return KLSeriesResult(
        prompt=prompt,
        max_new_tokens=max_new_tokens,
        baseline_policy=baseline_policy,
        candidate_policy=candidate_policy,
        kld_per_step=kld,
        kld_mean=sum(kld) / n,
        kld_max=max(kld),
        kld_p95=sorted_k[p95_idx],
        same_top1_ratio=top1 / max(n, 1),
        same_top5_ratio=top5 / max(n, 1),
    )


@dataclass
class NIAHResult:
    """Needle-in-a-haystack passkey recall."""

    context_tokens: int
    needle: str
    needle_position_ratio: float
    expected: str
    generated: str
    passed: bool

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__.copy()


def build_niah_prompt(
    *,
    haystack_unit: str = "The grass is green. The sky is blue. The sun is yellow. ",
    needle: str = "The passkey is 73921. Remember it carefully.",
    target_context_chars: int = 2000,
    needle_position_ratio: float = 0.5,
    question: str = " What is the passkey?",
) -> tuple[str, str]:
    """Construct an NIAH prompt.

    Returns ``(prompt, expected_substring)``. The expected substring is the
    passkey digits, which a recall-preserving model should emit verbatim.
    """
    needle_position_ratio = max(0.0, min(1.0, float(needle_position_ratio)))
    filler_len = max(0, target_context_chars - len(needle))
    prefix_len = int(filler_len * needle_position_ratio)
    suffix_len = filler_len - prefix_len
    # Repeat haystack_unit to fill prefix/suffix.
    reps_prefix = (prefix_len // max(len(haystack_unit), 1)) + 1
    reps_suffix = (suffix_len // max(len(haystack_unit), 1)) + 1
    prefix = (haystack_unit * reps_prefix)[:prefix_len]
    suffix = (haystack_unit * reps_suffix)[:suffix_len]
    prompt = prefix + needle + suffix + question
    # Pull the digit run out of the needle for verification.
    digits = "".join(ch for ch in needle if ch.isdigit())
    return prompt, digits


def niah_passkey_test(
    engine: Any,
    *,
    target_context_chars: int = 2000,
    needle_position_ratio: float = 0.5,
    max_new_tokens: int = 32,
) -> NIAHResult:
    """Run a single NIAH passkey check against an engine that exposes ``generate``.

    The engine contract matches :class:`tiny_turboquant.backends.hf.TinyTurboHFEngine`:
    ``generate(prompt, *, max_new_tokens=...) -> result with .generated_text``.
    """
    prompt, expected = build_niah_prompt(
        target_context_chars=target_context_chars,
        needle_position_ratio=needle_position_ratio,
    )
    result = engine.generate(prompt, max_new_tokens=max_new_tokens)
    generated = getattr(result, "generated_text", "") or ""
    passed = expected and expected in generated
    return NIAHResult(
        context_tokens=int(getattr(result, "input_tokens", 0)),
        needle=expected,
        needle_position_ratio=needle_position_ratio,
        expected=expected,
        generated=generated,
        passed=bool(passed),
    )
