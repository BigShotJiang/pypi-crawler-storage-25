﻿"""Cross-model smoke test for v0.13.3.

The biggest validation lesson is: test across many small models before
claiming any policy is good. A policy that looks stable on one architecture
can fail badly on another.

This script runs the same prompt under the same KV policy across a small
zoo of locally-available HF models and reports KL@D + token-match parity.
Models that aren't downloaded (or that need a license) are skipped with a
clear message â€” the script does not try to fetch anything from the network.

Usage::

    python -m examples.cross_model_smoke --policies fp16,fp16k-q8v,fp16k-int4v-last8-fp16

If ``--policies`` is omitted, the script runs the default trio:
    * fp16            (baseline)
    * fp16k-q8v       (current default)
    * fp16k-int4v-last8-fp16 (v0.13.3 Mode-2 policy)
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any

from tiny_turboquant.backends.hf import TinyTurboHFEngine
from tiny_turboquant.validation.backend import compare_logits


DEFAULT_MODELS = [
    "Qwen/Qwen2.5-0.5B",
    "HuggingFaceTB/SmolLM2-135M",
    "HuggingFaceTB/SmolLM2-360M",
    "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
    "google/gemma-3-270m",
]

DEFAULT_POLICIES = [
    "fp16",
    "fp16k-q8v",
    "fp16k-int4v-last8-fp16",
]


def _try_run(model_name: str, policy: str, prompt: str, max_new_tokens: int) -> dict[str, Any]:
    try:
        eng = TinyTurboHFEngine(
            model_name,
            kv_policy=policy,
            local_files_only=True,  # never touch the network
        ).load()
    except Exception as exc:
        return {"model": model_name, "policy": policy, "status": "skipped", "reason": str(exc)[:200]}
    try:
        result = eng.generate(prompt, max_new_tokens=max_new_tokens, collect_logits=True)
        return {
            "model": model_name,
            "policy": policy,
            "status": "ok",
            "tokens_per_second": result.tokens_per_second,
            "generated_text": result.generated_text,
            "memory_saved_pct": result.cache_report.get("memory_saved_pct"),
            "logits": result.logits,  # not serialized; only used in-process
        }
    except Exception as exc:
        return {"model": model_name, "policy": policy, "status": "error", "reason": str(exc)[:200]}


def main() -> int:
    ap = argparse.ArgumentParser(description="Cross-model smoke test")
    ap.add_argument("--models", default=",".join(DEFAULT_MODELS))
    ap.add_argument("--policies", default=",".join(DEFAULT_POLICIES))
    ap.add_argument("--prompt", default="The capital of France is")
    ap.add_argument("--max-new-tokens", type=int, default=32)
    ap.add_argument("--json", action="store_true", help="emit machine-readable JSON instead of text")
    args = ap.parse_args()

    models = [m.strip() for m in args.models.split(",") if m.strip()]
    policies = [p.strip() for p in args.policies.split(",") if p.strip()]
    if not policies:
        print("no policies specified", file=sys.stderr)
        return 2
    baseline_policy = policies[0]

    grid: list[dict[str, Any]] = []
    for model in models:
        baseline = _try_run(model, baseline_policy, args.prompt, args.max_new_tokens)
        for policy in policies:
            if policy == baseline_policy:
                row = {
                    "model": model,
                    "policy": policy,
                    "status": baseline["status"],
                    "is_baseline": True,
                    "tokens_per_second": baseline.get("tokens_per_second"),
                    "generated_text": baseline.get("generated_text"),
                    "memory_saved_pct": baseline.get("memory_saved_pct"),
                }
                grid.append(row)
                continue
            cand = _try_run(model, policy, args.prompt, args.max_new_tokens)
            row: dict[str, Any] = {
                "model": model,
                "policy": policy,
                "status": cand["status"],
                "is_baseline": False,
                "tokens_per_second": cand.get("tokens_per_second"),
                "generated_text": cand.get("generated_text"),
                "memory_saved_pct": cand.get("memory_saved_pct"),
            }
            if baseline.get("status") == "ok" and cand.get("status") == "ok":
                report = compare_logits(baseline["logits"], cand["logits"])
                row["kl_divergence_mean"] = report.get("kl_divergence_mean")
                row["kl_divergence_max"] = report.get("kl_divergence_max")
                row["top1_match_ratio"] = report.get("top1_match_ratio")
                row["same_top5_ratio"] = report.get("same_top5_ratio")
                row["exact_text_match"] = (cand.get("generated_text") == baseline.get("generated_text"))
            grid.append(row)

    # Drop logits from skipped/error rows that may still hold them.
    for row in grid:
        row.pop("logits", None)

    if args.json:
        print(json.dumps({"rows": grid, "baseline_policy": baseline_policy}, indent=2, default=str))
        return 0

    # Pretty text output.
    width = max((len(r["model"]) for r in grid), default=12) + 2
    pwidth = max((len(r["policy"]) for r in grid), default=12) + 2
    print(f"baseline policy: {baseline_policy}\n")
    print(f"{'model'.ljust(width)}{'policy'.ljust(pwidth)}{'status'.ljust(10)}{'KL mean':>10}  {'top1':>7}  {'mem%':>6}")
    print("-" * (width + pwidth + 35))
    for row in grid:
        kl = row.get("kl_divergence_mean")
        kl_str = f"{kl:.2e}" if isinstance(kl, (int, float)) else "-"
        top1 = row.get("top1_match_ratio")
        top1_str = f"{top1*100:.1f}%" if isinstance(top1, (int, float)) else "-"
        mem = row.get("memory_saved_pct")
        mem_str = f"{mem:.1f}" if isinstance(mem, (int, float)) else "-"
        print(
            f"{row['model'].ljust(width)}{row['policy'].ljust(pwidth)}{str(row['status']).ljust(10)}"
            f"{kl_str:>10}  {top1_str:>7}  {mem_str:>6}"
        )
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
