"""MeetingSession: orchestrates the detect → record → transcribe → stop lifecycle."""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Optional

from meeting_helper.live_transcript import LiveTranscriptWriter

if TYPE_CHECKING:
    from meeting_helper.buffer import SentenceBuffer
    from meeting_helper.config import AppConfig
    from meeting_helper.meeting_detector import MeetingInfo

logger = logging.getLogger(__name__)


class ProactiveMonitor:
    """Watches the transcript buffer and fires Claude queries automatically.

    Trigger rule: new sentence ends with '?' + 1 second of silence after it.

    Constraints:
    - 60s minimum cooldown between proactive fires
    - 30s cooldown after any manual query
    - Never interrupts an in-progress response
    - Buffer is never cleared — manual queries still have full context
    """

    SILENCE_SECS = 2.0  # silence after question before firing

    def __init__(self, config, buffer) -> None:
        self._config = config
        self._buffer = buffer
        self._pending_sentence: str | None = None
        self._timer: threading.Timer | None = None
        self._fire_id: int = 0
        self._lock = threading.Lock()
        self._enabled: bool = True

    def set_enabled(self, enabled: bool) -> None:
        self._enabled = enabled
        if not enabled:
            self._cancel_pending()
        logger.info("Proactive monitor %s", "enabled" if enabled else "disabled")

    def is_enabled(self) -> bool:
        return self._enabled

    def notify_manual_query(self) -> None:
        """Cancel any pending proactive trigger when user manually queries."""
        self._cancel_pending()

    def on_sentence(self, sentence: str) -> None:
        """Called by SentenceBuffer on every new final sentence."""
        if not self._enabled:
            return
        if not sentence.rstrip().endswith("?"):
            self._cancel_pending()
            return
        with self._lock:
            if self._timer:
                self._timer.cancel()
                self._timer = None
            self._pending_sentence = sentence
            self._fire_id += 1
            current_id = self._fire_id
        # Start the 1s silence timer, passing fire_id to detect stale firings
        t = threading.Timer(self.SILENCE_SECS, self._maybe_fire, args=(current_id,))
        t.daemon = True
        with self._lock:
            self._timer = t
        t.start()

    def _cancel_pending(self, cancel_sentence: bool = True) -> None:
        with self._lock:
            if self._timer:
                self._timer.cancel()
                self._timer = None
            if cancel_sentence:
                self._pending_sentence = None
                self._fire_id += 1  # invalidate any running timer

    def _maybe_fire(self, fire_id: int) -> None:
        with self._lock:
            if fire_id != self._fire_id:
                return  # Stale timer — a newer question arrived, skip
            sentence = self._pending_sentence
            self._pending_sentence = None
            self._timer = None

        if not sentence:
            return

        from meeting_helper.state import state
        if state.status == "processing":
            logger.debug("Proactive: skipped (response in progress)")
            return

        logger.info("Proactive: firing for question: %s", sentence[:80])

        loop = state.asyncio_loop
        if loop is not None:
            import asyncio
            asyncio.run_coroutine_threadsafe(
                self._fire(sentence), loop
            )

    async def _fire(self, question: str) -> None:
        from meeting_helper.ai.client import handle_query
        from meeting_helper.state import state
        await handle_query(state, self._config)

    def stop(self) -> None:
        self._cancel_pending()


class AutoContextSelector:
    """Periodically selects relevant repos/knowledge based on transcript + history.

    Runs every `interval_secs` seconds during an active session. Uses Claude Haiku
    to pick from the low-level index, then accumulates selections (never removes).
    """

    def __init__(self, config, buffer, interval_secs: int = 60) -> None:
        self._config = config
        self._buffer = buffer
        self._interval = interval_secs
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._enabled = True

    def set_enabled(self, enabled: bool) -> None:
        self._enabled = enabled

    def is_enabled(self) -> bool:
        return self._enabled

    def start(self) -> None:
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        logger.info("AutoContextSelector started (interval=%ds)", self._interval)

    def stop(self) -> None:
        self._stop_event.set()

    def _run(self) -> None:
        # Wait the full interval before first check
        self._stop_event.wait(timeout=self._interval)
        while not self._stop_event.is_set():
            if not self._enabled:
                self._stop_event.wait(timeout=self._interval)
                continue
            try:
                import asyncio
                asyncio.run(self._select_and_apply())
            except Exception as exc:
                logger.warning("AutoContextSelector error: %s", exc)
            self._stop_event.wait(timeout=self._interval)

    async def _select_and_apply(self) -> None:
        from meeting_helper.ai.client import _select_context
        from meeting_helper.context_loader import build_selective_context, get_repos_from_workspaces
        from meeting_helper.ai.prompts import build_system_prompt
        from meeting_helper.state import state

        # Skip while a past conversation is attached — we don't want to clobber
        # the user's deliberately-pinned context.
        if state.attached_conversation is not None:
            logger.debug(
                "AutoContextSelector skipped: conversation attached (%s)",
                state.attached_conversation.get("title"),
            )
            return

        transcript = self._buffer.get_last_n_as_text(self._config.sentence_window * 3)
        if not transcript.strip():
            return

        index = state.auto_context_index
        if not index:
            return

        history = state.conversation_history[-4:]
        selection = await _select_context(index, transcript, history, self._config)

        # Accumulate: union with existing selection (never shrink)
        prev = state.auto_context_selection
        new_repos = sorted(set(prev.get("repos", [])) | set(selection.get("repos", [])))
        new_knowledge = sorted(set(prev.get("knowledge", [])) | set(selection.get("knowledge", [])))
        accumulated = {"repos": new_repos, "knowledge": new_knowledge}

        if accumulated == prev:
            logger.debug("AutoContextSelector: no new context to add")
            return

        state.auto_context_selection = accumulated

        # Map repo names → full paths
        all_repos = {r["name"]: r["path"] for r in get_repos_from_workspaces(
            self._config.repos_workspaces or ([self._config.repos_workspace] if self._config.repos_workspace else []),
            ignored=self._config.ignored_repos,
        )}
        selected_paths = [all_repos[n] for n in new_repos if n in all_repos]
        kp = (self._config.knowledge_paths or [self._config.knowledge_path] if self._config.knowledge_path else [])[0] if (self._config.knowledge_paths or self._config.knowledge_path) else ""

        context_block = build_selective_context(selected_paths, kp, new_knowledge)
        state.system_prompt = build_system_prompt(context_block)

        added_repos = sorted(set(new_repos) - set(prev.get("repos", [])))
        added_knowledge = sorted(set(new_knowledge) - set(prev.get("knowledge", [])))
        logger.info("Auto-context updated: +repos=%s +knowledge=%s", added_repos, added_knowledge)

        # Broadcast to overlay/GUI
        loop = state.asyncio_loop
        if loop and not loop.is_closed():
            import asyncio
            asyncio.run_coroutine_threadsafe(
                _broadcast_auto_context(accumulated, added_repos, added_knowledge), loop
            )


async def _broadcast_auto_context(accumulated: dict, added_repos: list, added_knowledge: list) -> None:
    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({
            "type": "context_updated",
            "repos": accumulated["repos"],
            "knowledge": accumulated["knowledge"],
            "added_repos": added_repos,
            "added_knowledge": added_knowledge,
        })
    except Exception:
        pass


def _transcriber_display_name(transcriber, config) -> str:
    """Return a human-readable name for the active transcriber."""
    from meeting_helper.audio.transcriber import RemoteWhisperTranscriber
    if transcriber is None:
        return "none"
    if isinstance(transcriber, RemoteWhisperTranscriber):
        return f"Whisper (remote: {config.whisper_host})"
    if config.deepgram_api_key and hasattr(transcriber, '_api_key'):
        return "Deepgram"
    return "Whisper (local)"


class MeetingSession:
    """Manages the full lifecycle of meeting recording and transcription.

    States: idle → active → stopping → idle
    Runs in its own background thread.
    """

    def __init__(
        self,
        config: AppConfig,
        self_buffer: SentenceBuffer,
        other_buffer: SentenceBuffer,
        on_meeting_start: Callable[[MeetingInfo], None],
        on_meeting_end: Callable[[Optional[Path]], None],
    ) -> None:
        self._config = config
        self._self_buffer = self_buffer
        self._other_buffer = other_buffer
        self._on_meeting_start = on_meeting_start
        self._on_meeting_end = on_meeting_end
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._self_transcriber = None
        self._other_transcriber = None
        self._capture = None

    def start(self) -> None:
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()

    def manual_start(self) -> None:
        """Kick off a full session manually (no mic detection)."""
        from meeting_helper.meeting_detector import MeetingInfo
        info = MeetingInfo(app_name="Manual", meeting_name="Manual Recording", window_title="", is_active=True)
        self._manual_stop = threading.Event()
        t = threading.Thread(target=self._run_manual_session, args=(info,), daemon=True)
        t.start()

    def swap_transcriber(self, preferred_transcriber: str, config: "AppConfig") -> str:
        """Hot-swap both transcribers mid-session. Returns new transcriber display name."""
        from meeting_helper.audio.transcriber import create_transcriber

        if self._self_transcriber is not None:
            self._self_transcriber.stop()
        if self._other_transcriber is not None:
            self._other_transcriber.stop()

        if self._capture is None:
            logger.warning("swap_transcriber: no active audio capture")
            return "none"

        self._self_transcriber = create_transcriber(
            audio_capture=self._capture.self_stream,
            transcript_buffer=self._self_buffer,
            deepgram_api_key=config.deepgram_api_key,
            transcription_language=config.transcription_language,
            preferred_transcriber=preferred_transcriber,
            whisper_host=config.whisper_host,
        )
        self._other_transcriber = create_transcriber(
            audio_capture=self._capture.other_stream,
            transcript_buffer=self._other_buffer,
            deepgram_api_key=config.deepgram_api_key,
            transcription_language=config.transcription_language,
            preferred_transcriber=preferred_transcriber,
            whisper_host=config.whisper_host,
        )
        t_name = _transcriber_display_name(self._self_transcriber, config)
        logger.info("Transcribers hot-swapped to: %s", t_name)
        return t_name

    def manual_stop(self) -> None:
        """Stop a manually-started session."""
        if hasattr(self, "_manual_stop"):
            self._manual_stop.set()

    def _run_manual_session(self, meeting_info: MeetingInfo) -> None:
        """Run a full session triggered manually — ends on manual_stop().

        Restarts the daemon after the session ends so the next manual start
        gets a fresh PortAudio context, matching the auto-detect path.
        Without this, subsequent manual starts fail silently because the
        PortAudio/CoreAudio state is stale after capture.stop().
        """
        try:
            self._run_active_session(meeting_info, stop_event=self._manual_stop)
        except Exception as exc:
            logger.error("Manual session error: %s", exc, exc_info=True)
        # _run_active_session's finally block already fired _on_meeting_end;
        # spawn a fresh daemon so the next manual session starts clean.
        self._restart_daemon()

    def _restart_daemon(self) -> None:
        """Spawn a fresh daemon process and exit, giving the next meeting a clean PortAudio state."""
        import subprocess, sys, os
        try:
            executable = sys.executable
            subprocess.Popen(
                [executable, "-m", "meeting_helper"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
            logger.info("MeetingSession: spawned fresh daemon — exiting current process")
            os._exit(0)
        except Exception as exc:
            logger.warning("MeetingSession: could not restart daemon: %s", exc)

    def _run(self) -> None:
        """Main loop: detect meeting → start capture/transcription → wait for end."""
        if not self._config.auto_start_record:
            logger.info("MeetingSession: auto_start_record disabled — waiting for manual start")
            self._stop_event.wait()
            return

        # ALL audio imports happen HERE (after daemon fork)
        from meeting_helper.meeting_detector import MeetingMonitor

        monitor = MeetingMonitor()
        logger.info("MeetingSession: watching for meetings (mic-based detection)...")

        while not self._stop_event.is_set():
            started, ended, meeting_info = monitor.check()

            if started and meeting_info:
                logger.info("Meeting detected: %s (%s)", meeting_info.app_name, meeting_info.meeting_name or "unnamed")
                _portaudio_retries = 0
                while not self._stop_event.is_set():
                    try:
                        self._run_active_session(meeting_info)
                        break  # session ended normally
                    except Exception as exc:
                        msg = str(exc)
                        if "PaErrorCode -9986" in msg or "PortAudio" in msg or "InputStream" in msg:
                            _portaudio_retries += 1
                            if _portaudio_retries <= 5:
                                logger.warning("PortAudio mic error (attempt %d/5) — retrying in 3s: %s", _portaudio_retries, exc)
                                self._stop_event.wait(timeout=3.0)
                                continue
                        logger.error("MeetingSession: session error: %s", exc, exc_info=True)
                        break
                monitor.set_meeting_ended()
                # Cooldown: wait for mic to fully release before re-monitoring
                logger.info("MeetingSession: cooldown before re-watching...")
                self._stop_event.wait(timeout=1.0)
                # Restart daemon to get a fresh PortAudio context for the next meeting
                self._restart_daemon()
                logger.info("MeetingSession: back to watching for meetings...")
            else:
                self._stop_event.wait(timeout=2.0)  # poll every 2s (matching meeting-noter)

    def _run_active_session(self, meeting_info: MeetingInfo,
                             stop_event: Optional[threading.Event] = None) -> None:
        """Capture + transcribe + record until meeting app releases the mic.

        No silence detection — recording continues as long as the meeting app
        holds the microphone. Only MicProbe ends the session (or stop_event for manual).
        """
        from meeting_helper.audio.capture import CombinedAudioCapture
        from meeting_helper.audio.transcriber import create_transcriber
        from meeting_helper.audio.encoder import RecordingSession
        from meeting_helper.daemon import MicProbe

        from meeting_helper.state import state as app_state
        # Reset per-session task list before notifying anyone
        app_state.session_tasks = []
        self._on_meeting_start(meeting_info)

        self._capture = CombinedAudioCapture(sample_rate=16000)
        capture = self._capture
        self._self_transcriber = None
        self._other_transcriber = None
        recording = None
        saved_path = None
        live_transcript_path = None
        live_writer = None
        self_listener = None
        other_listener = None

        # Proactive monitor — only active when enabled in config
        # Watches user-side speech (self_buffer) for "?" triggers.
        proactive = None
        if self._config.proactive_answers:
            proactive = ProactiveMonitor(self._config, self._self_buffer)
            self._self_buffer.add_sentence_listener(proactive.on_sentence)
            app_state.proactive_monitor = proactive
            logger.info("Proactive answers enabled")

        # Topic worker — maintains state.current_topic from self-buffer speech (C3)
        topic_worker = None
        try:
            from meeting_helper.topic_worker import TopicWorker
            topic_worker = TopicWorker(self._config, self._self_buffer)
            topic_worker.start()
            app_state.topic_worker = topic_worker
        except Exception as exc:
            logger.warning("Failed to start topic worker: %s", exc)
            topic_worker = None

        # Pre-load the active-sprint ticket cache so the topic picker has its
        # candidate list ready from the first TopicWorker cycle (no cold-start
        # window where the banner is blank).
        try:
            from meeting_helper.ai.client import refresh_sprint_tickets
            loop = app_state.asyncio_loop
            if loop is not None:
                asyncio.run_coroutine_threadsafe(
                    refresh_sprint_tickets(app_state, force=True), loop
                )
        except Exception as exc:
            logger.warning("Failed to schedule sprint cache preload: %s", exc)

        # Auto-context selector — periodically picks relevant repos/knowledge
        # Driven by self_buffer (user speech) for now.
        auto_ctx = None
        if self._config.auto_context_enabled:
            auto_ctx = AutoContextSelector(
                self._config, self._self_buffer,
                interval_secs=self._config.auto_context_interval,
            )
            auto_ctx.start()
            app_state.auto_context_selector = auto_ctx

        try:
            capture.start()
            app_state.audio_active = True
            logger.info("Audio capture started (system_audio=%s)", capture.has_system_audio)

            # Start two transcribers — one per role (C2)
            self._self_transcriber = create_transcriber(
                audio_capture=capture.self_stream,
                transcript_buffer=self._self_buffer,
                deepgram_api_key=self._config.deepgram_api_key,
                transcription_language=self._config.transcription_language,
                preferred_transcriber=self._config.preferred_transcriber,
                whisper_host=self._config.whisper_host,
            )
            self._other_transcriber = create_transcriber(
                audio_capture=capture.other_stream,
                transcript_buffer=self._other_buffer,
                deepgram_api_key=self._config.deepgram_api_key,
                transcription_language=self._config.transcription_language,
                preferred_transcriber=self._config.preferred_transcriber,
                whisper_host=self._config.whisper_host,
            )

            # Update daemon metadata with transcriber name
            from meeting_helper.daemon import write_meta
            t_name = _transcriber_display_name(self._self_transcriber, self._config)
            write_meta(self._config, transcriber_name=t_name)
            app_state.transcriber_name = t_name
            logger.info("Transcribers running: %s", t_name)

            # Broadcast info to overlay
            loop = app_state.asyncio_loop
            if loop:
                import asyncio
                from meeting_helper.server.websocket import broadcast_info
                asyncio.run_coroutine_threadsafe(broadcast_info(), loop)

            # Always record to MP3
            recordings_dir = self._config.recordings_dir
            recordings_dir.mkdir(parents=True, exist_ok=True)
            recording = RecordingSession(
                output_dir=recordings_dir,
                sample_rate=capture.sample_rate,
                channels=capture.channels,
                meeting_name=meeting_info.meeting_name or meeting_info.app_name,
            )
            mp3_path = recording.start()
            live_transcript_path = mp3_path.with_suffix(".live.txt")
            logger.info("Recording to: %s", mp3_path.name)

            # Stream every finalized sentence to .live.txt as `[MM:SS] ROLE: text`.
            # Both transcribers fan out through SentenceBuffer's listener hook;
            # the writer serializes the cross-thread file access.
            live_writer = LiveTranscriptWriter(live_transcript_path, t0=time.monotonic())
            self_listener = lambda s: live_writer.append("SELF", s)
            other_listener = lambda s: live_writer.append("OTHER", s)
            self._self_buffer.add_sentence_listener(self_listener)
            self._other_buffer.add_sentence_listener(other_listener)

            mic_probe = MicProbe(probe_interval=2.0, settle_time=0.3, required_off_count=1)
            is_manual = stop_event is not None

            while not self._stop_event.is_set():
                # Manual session: check stop_event
                if is_manual and stop_event.is_set():
                    logger.info("Manual session stopped by user")
                    break

                audio = capture.get_audio(timeout=0.5)
                if audio is None:
                    continue

                audio_flat = audio[:, 0] if audio.ndim > 1 else audio

                # Write to MP3
                if recording.is_active:
                    recording.write(audio)

                # MicProbe: only end auto sessions — manual sessions ignore mic release
                if not is_manual and mic_probe.should_probe(time.time()):
                    if mic_probe.probe(capture):
                        logger.info("MicProbe: meeting app released mic — ending session")
                        break

        except Exception as exc:
            logger.error("Session error: %s", exc)
        finally:
            if proactive is not None:
                proactive.stop()
                self._self_buffer.remove_sentence_listener(proactive.on_sentence)
                app_state.proactive_monitor = None
            if topic_worker is not None:
                try:
                    topic_worker.stop()
                except Exception as exc:
                    logger.warning("topic_worker stop failed: %s", exc)
                app_state.topic_worker = None
            if auto_ctx is not None:
                auto_ctx.stop()
            app_state.auto_context_selector = None
            # Clear any attached past Claude Code conversation so the next
            # meeting starts clean.
            app_state.attached_conversation = None
            if self._self_transcriber is not None:
                self._self_transcriber.stop()
                self._self_transcriber = None
            if self._other_transcriber is not None:
                self._other_transcriber.stop()
                self._other_transcriber = None

            capture.stop()
            self._capture = None
            app_state.audio_active = False

            # Detach the streaming writer and release the file handle. Every
            # finalized sentence has already been written by the listener.
            if self_listener is not None:
                self._self_buffer.remove_sentence_listener(self_listener)
            if other_listener is not None:
                self._other_buffer.remove_sentence_listener(other_listener)
            if live_writer is not None:
                try:
                    live_writer.close()
                except Exception as exc:
                    logger.warning("live_writer close failed: %s", exc)

            # Finalize MP3
            if recording is not None and recording.is_active:
                saved_path, duration = recording.stop()
                if saved_path:
                    logger.info("Recording saved: %s (%.1fs)", saved_path.name, duration)

            # Persist extracted tasks alongside the recording
            tasks_target = saved_path if saved_path is not None else live_transcript_path
            if tasks_target is not None and app_state.session_tasks:
                try:
                    from meeting_helper import tasks as tasks_mod
                    tasks_path = tasks_target.with_suffix(".tasks.json")
                    tasks_mod.save_tasks(tasks_path, list(app_state.session_tasks))
                    logger.info("Tasks saved: %s (%d items)",
                                tasks_path.name, len(app_state.session_tasks))
                except Exception as exc:
                    logger.warning("Failed to save tasks: %s", exc)
            app_state.session_tasks = []

            self._self_buffer.clear()
            self._other_buffer.clear()
            self._on_meeting_end(saved_path)
