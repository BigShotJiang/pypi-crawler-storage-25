"""Shared mutable state for the daemon process."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    import aiohttp.web
    from meeting_helper.buffer import SentenceBuffer


class AppState:
    """Thread-safe shared state for the running daemon."""

    def __init__(self) -> None:
        self.asyncio_loop: asyncio.AbstractEventLoop | None = None
        self.self_buffer: SentenceBuffer | None = None
        self.other_buffer: SentenceBuffer | None = None
        self.ws_clients: set[aiohttp.web.WebSocketResponse] = set()

        # Processing status (drives tray icon + overlay status dot)
        self.status: Literal["idle", "listening", "processing"] = "idle"

        # Last full AI response (sent to late-joining viewers)
        self.last_response: str = ""
        self.last_cards: list[dict] = []

        # Conversation history: list of {"role": "user"|"assistant", "content": ...}
        # Cleared between meetings, kept within a meeting across queries.
        self.conversation_history: list = []

        self.started_at: float = 0.0
        self.audio_active: bool = False
        self.shutdown_event: asyncio.Event | None = None

        # Meeting-specific
        self.meeting_info: object | None = None  # MeetingInfo from meeting_detector
        self.session_active: bool = False
        self.overlay_proc: object | None = None  # subprocess.Popen
        self.overlay_visible: bool = False

        # Current system prompt (can be rebuilt mid-session via workspace change)
        self.system_prompt: str = ""

        # When non-None, a past Claude Code conversation is attached as primary context.
        # AutoContextSelector skips while this is set; cleared on session stop.
        # Shape: {"session_id", "title", "repo", "attached_at", "chars", "truncated"}
        self.attached_conversation: dict | None = None

        # Proactive monitor + auto-context selector (set during active session, None otherwise)
        self.proactive_monitor: object | None = None
        self.auto_context_selector: object | None = None

        # Local-todo MCP client (lazy: subprocess spawns on first use)
        self.local_todo: object | None = None

        # Topic worker state — refreshed every ~5s while a session is active
        self.current_topic: dict = {
            "topic": "",
            "ticket_ids": [],
            "search_query": "",
            "last_user_statement": "",
        }
        self.current_topic_cards: list[dict] = []
        self.topic_worker: object | None = None  # TopicWorker instance during session

        # Cached active-sprint tickets across all boards. Loaded at session
        # start and refreshed periodically by TopicWorker. Used as the
        # constrained list the LLM picks from when identifying the current
        # topic — robust to transcription noise that would break a raw
        # keyword search.
        self.sprint_tickets: list[dict] = []
        self.sprint_tickets_loaded_at: float = 0.0

        # Hot Moment — when monotonic() < hot_moment_until, TopicWorker also
        # consumes other_buffer sentences (otherwise mic-only). Re-armed by
        # any engagement signal: own speech, query submission, brief click.
        self.hot_moment_until: float = 0.0

        # Wallclock timestamp of the last query we built a prompt for.
        # Used by `_extract_likely_question` to ignore sentences that already
        # produced an AI answer — prevents the hotkey from re-asking a stale
        # question when the topic has shifted but the old `?` is still in the
        # rolling buffer.
        self.last_query_at: float = 0.0

        # Auto-context: low-level index + accumulated selection for current meeting
        self.auto_context_index: str = ""
        self.auto_context_selection: dict = {"repos": [], "knowledge": []}

        # MeetingSession instance (for manual start/stop)
        self.meeting_session: object | None = None

        # Current AI streaming task (for query cancellation)
        self.active_query: asyncio.Task | None = None

        # Info bar state (broadcast to overlay via "info" messages)
        self.transcriber_name: str = ""
        self.ai_model: str = ""

        # Tasks extracted during the current session (cleared on session start,
        # persisted to <recording>.tasks.json on session end).
        self.session_tasks: list[dict] = []

        # Live observability counters — surfaced in the copilot toolbar so the
        # user can see what the daemon is actually doing during a meeting.
        # Reset on session start (see daemon._broadcast_meeting_started).
        self.ai_call_count: int = 0
        self.ai_calls_by_kind: dict[str, int] = {}
        self.local_todo_call_count: int = 0
        self.local_todo_calls_by_kind: dict[str, int] = {}
        self.last_local_todo_action: str = ""
        self.last_local_todo_at: float = 0.0

    def record_ai_call(self, kind: str = "ai") -> None:
        self.ai_call_count += 1
        self.ai_calls_by_kind[kind] = self.ai_calls_by_kind.get(kind, 0) + 1

    def record_local_todo_call(self, action: str) -> None:
        self.local_todo_call_count += 1
        # Bucket by leading verb (e.g. "search 'ENGT-4212'" -> "search")
        kind = action.split(" ", 1)[0] if action else "call"
        self.local_todo_calls_by_kind[kind] = self.local_todo_calls_by_kind.get(kind, 0) + 1
        self.last_local_todo_action = action
        self.last_local_todo_at = time.time()

    def reset_session_stats(self) -> None:
        self.ai_call_count = 0
        self.ai_calls_by_kind = {}
        self.local_todo_call_count = 0
        self.local_todo_calls_by_kind = {}
        self.last_local_todo_action = ""
        self.last_local_todo_at = 0.0

    @property
    def sentence_buffer(self) -> "SentenceBuffer | None":
        """Back-compat alias to self_buffer. Existing callers (extract_tasks,
        transcript polling, etc.) keep working without per-call rewriting.
        Newer callers should read self_buffer / other_buffer explicitly."""
        return self.self_buffer

    @sentence_buffer.setter
    def sentence_buffer(self, value: "SentenceBuffer | None") -> None:
        self.self_buffer = value

    def is_hot_moment(self) -> bool:
        """True while the user is actively engaged (within the Hot Moment window)."""
        return time.monotonic() < self.hot_moment_until

    def arm_hot_moment(self, window_sec: float) -> None:
        """Re-stamp the Hot Moment to expire ``window_sec`` from now.

        A non-positive window is a no-op (Hot Moment effectively disabled).
        """
        if window_sec <= 0:
            return
        self.hot_moment_until = time.monotonic() + window_sec

    def hot_moment_until_wallclock(self) -> float:
        """Convert ``hot_moment_until`` (monotonic) into a wall-clock timestamp
        so GUI clients can compute time-remaining without their own monotonic
        clock. Returns 0.0 when Hot Moment is idle."""
        if not self.is_hot_moment():
            return 0.0
        seconds_left = self.hot_moment_until - time.monotonic()
        return time.time() + max(0.0, seconds_left)


# Module-level singleton
state = AppState()
