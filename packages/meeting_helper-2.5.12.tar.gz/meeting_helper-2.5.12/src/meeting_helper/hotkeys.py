"""Global hotkey listener using pynput.

Hotkey map:
  2×Cmd          → trigger Claude query
"""

from __future__ import annotations

import asyncio
import io
import logging
import math
import struct
import threading
import time
import wave
from typing import TYPE_CHECKING

from pynput import keyboard

if TYPE_CHECKING:
    from meeting_helper.config import AppConfig

logger = logging.getLogger(__name__)

_DOUBLE_TAP_THRESHOLD = 0.4

_current_keys: set = set()
_last_cmd_release: float = 0.0
_cmd_was_solo: bool = True


def _beep(freq: float, duration: float = 0.07, volume: float = 0.4) -> None:
    """Play a short sine-wave tone via NSSound."""
    def _play():
        try:
            sr = 44100
            n = int(sr * duration)
            fade_samples = int(sr * 0.01)
            frames = bytearray()
            for i in range(n):
                s = math.sin(2 * math.pi * freq * i / sr) * volume
                if i >= n - fade_samples:
                    s *= (n - i) / fade_samples
                frames += struct.pack('<h', max(-32767, min(32767, int(s * 32767))))
            buf = io.BytesIO()
            with wave.open(buf, 'wb') as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(sr)
                wf.writeframes(bytes(frames))
            from AppKit import NSSound
            from Foundation import NSData
            data = NSData.dataWithBytes_length_(buf.getvalue(), len(buf.getvalue()))
            sound = NSSound.alloc().initWithData_(data)
            if sound:
                sound.setVolume_(min(1.0, volume * 2))
                sound.play()
                time.sleep(duration + 0.05)
        except Exception:
            pass
    threading.Thread(target=_play, daemon=True).start()


def _schedule(coro):
    from meeting_helper.state import state
    loop = state.asyncio_loop
    if loop is not None:
        asyncio.run_coroutine_threadsafe(coro, loop)


def _is_meeting_active() -> bool:
    from meeting_helper.state import state
    return state.session_active


def _do_trigger_query(config: "AppConfig"):
    if not _is_meeting_active():
        return

    _beep(660, 0.08)

    async def _query():
        from meeting_helper.ai.client import handle_query
        from meeting_helper.state import state
        await handle_query(state, config)

    _schedule(_query())


def start_hotkey_listener(config: "AppConfig") -> None:
    """Start the pynput keyboard listener in a daemon thread."""
    _CMD_KEYS = {keyboard.Key.cmd, keyboard.Key.cmd_l, keyboard.Key.cmd_r}

    def on_press(key):
        global _cmd_was_solo

        _current_keys.add(key)

        if key not in _CMD_KEYS and _current_keys & _CMD_KEYS:
            _cmd_was_solo = False

    def on_release(key):
        global _last_cmd_release, _cmd_was_solo

        _current_keys.discard(key)

        if key in _CMD_KEYS:
            now = time.time()
            if _cmd_was_solo and (now - _last_cmd_release) < _DOUBLE_TAP_THRESHOLD:
                logger.info("Hotkey: 2×Cmd (query)")
                threading.Thread(target=lambda: _do_trigger_query(config), daemon=True).start()
                _last_cmd_release = 0.0
            else:
                _last_cmd_release = now
            _cmd_was_solo = True

    listener = keyboard.Listener(on_press=on_press, on_release=on_release)
    t = threading.Thread(target=listener.run, daemon=True)
    t.start()
    logger.info("Hotkey listener started")
