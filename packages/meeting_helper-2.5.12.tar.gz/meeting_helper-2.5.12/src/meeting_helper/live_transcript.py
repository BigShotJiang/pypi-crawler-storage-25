"""Append-only writer for `.live.txt` — a chronological conversation log.

Each finalized sentence becomes one line: ``[MM:SS] ROLE: text``. Times are
measured from ``t0`` (typically the moment recording started). For meetings
longer than an hour the format extends to ``[H:MM:SS]``.

Both transcribers (SELF / OTHER) share one writer; ``append`` is thread-safe.
"""

from __future__ import annotations

import threading
import time
from pathlib import Path
from typing import Callable, Optional, TextIO


class LiveTranscriptWriter:
    def __init__(
        self,
        path: Path,
        t0: float,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._t0 = t0
        self._clock = clock
        self._lock = threading.Lock()
        self._fh: Optional[TextIO] = open(path, "a", encoding="utf-8")

    def append(self, role: str, text: str) -> None:
        text = text.strip()
        if not text:
            return
        elapsed = max(0, int(self._clock() - self._t0))
        h, rem = divmod(elapsed, 3600)
        m, s = divmod(rem, 60)
        ts = f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"
        line = f"[{ts}] {role}: {text}\n"
        with self._lock:
            if self._fh is None:
                return
            self._fh.write(line)
            self._fh.flush()

    def close(self) -> None:
        with self._lock:
            if self._fh is not None:
                try:
                    self._fh.close()
                finally:
                    self._fh = None
