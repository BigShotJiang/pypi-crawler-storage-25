"""Conversation thread — data model + Flet rendering for the Copilot screen.

The data model (`ConversationThread`) is a pure-Python class with no Flet
dependency, so it can be unit-tested without a Page. The Flet view
(`ConversationView`) wraps the model and adds rendering, autoscroll,
and source-card display. Added in a later task.
"""

from __future__ import annotations

import re
import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field

# Pattern for the source-ticket header lines the AI prefixes its replies with.
# Format: "> [TICKET-ID] Title". Treated as theme-aware chips, NOT as
# markdown blockquote (which renders almost-invisibly on dark themes).
_SOURCE_HEADER_RE = re.compile(r"^\s*>\s*\[([^\]]+)\]\s*(.+?)\s*$")


def _split_source_headers(text: str) -> tuple[list[tuple[str, str]], str]:
    """Pull leading `> [TICKET-ID] Title` lines off the front of `text`.

    Returns ``(headers, body)`` where ``headers`` is ``[(ticket_id, title), ...]``
    in source order. Stops at the first non-header, non-blank line. Blank lines
    inside the header block are tolerated and skipped. If no headers are found,
    returns ``([], text)`` unchanged.
    """
    if not text:
        return [], text
    lines = text.split("\n")
    headers: list[tuple[str, str]] = []
    consumed = 0
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped:
            # Blank line — keep going only if it's still inside the leading block
            consumed = i + 1
            continue
        m = _SOURCE_HEADER_RE.match(stripped)
        if m is None:
            break
        headers.append((m.group(1).strip(), m.group(2).strip()))
        consumed = i + 1
    if not headers:
        return [], text
    body = "\n".join(lines[consumed:]).lstrip("\n")
    return headers, body

# Roles a turn can have. UI styling differs per role.
TurnRole = str  # "self" | "other" | "you" | "ai" | "brief"


@dataclass
class Turn:
    role: TurnRole
    text: str
    cards: list[dict] = field(default_factory=list)
    ts: float = field(default_factory=time.time)


class ConversationThread:
    """In-memory conversation. UI-free; testable as plain Python."""

    MAX_TURNS = 500

    def __init__(self) -> None:
        self._turns: deque[Turn] = deque(maxlen=self.MAX_TURNS)
        self._streaming: Turn | None = None

    @property
    def turns(self) -> list[Turn]:
        return list(self._turns)

    def append(
        self,
        role: TurnRole,
        text: str,
        cards: list[dict] | None = None,
    ) -> Turn:
        turn = Turn(role=role, text=text, cards=list(cards) if cards else [])
        self._turns.append(turn)
        return turn

    # Speaker-burst window: if the previous turn is the same `self`/`other`
    # speaker and was added within this many seconds, extend it instead of
    # creating a new turn. Avoids the "many tiny messages" pain.
    SPEAKER_BURST_WINDOW_SEC = 30.0

    def append_or_extend_transcript(self, role: TurnRole, text: str) -> tuple[Turn, bool]:
        """Append a transcribed sentence; merge with the previous turn if the
        same speaker is still in their burst window.

        Returns ``(turn, extended)`` — ``extended=True`` means the previous
        turn was mutated (caller should re-render it), ``False`` means a new
        turn was appended (caller should render the new row).
        """
        text = text.strip()
        if not text:
            # No-op: return a sentinel so callers can branch cleanly.
            empty = Turn(role=role, text="")
            return (empty, False)

        last = self._turns[-1] if self._turns else None
        if (
            last is not None
            and last.role == role
            and (time.time() - last.ts) <= self.SPEAKER_BURST_WINDOW_SEC
        ):
            sep = " " if last.text and not last.text.endswith((" ", "\n")) else ""
            last.text = f"{last.text}{sep}{text}"
            return (last, True)

        return (self.append(role, text), False)

    def begin_streaming(self, role: TurnRole) -> Turn:
        """Open a new streaming turn. Subsequent append_chunk() calls extend it."""
        turn = Turn(role=role, text="")
        self._turns.append(turn)
        self._streaming = turn
        return turn

    def append_chunk(self, text: str) -> Turn:
        """Append text to the in-flight streaming turn.

        If no streaming turn is open (e.g. a chunk arrived without a prior
        begin_streaming() call due to a race), opens a new `ai` turn
        conservatively.
        """
        if self._streaming is None:
            self.begin_streaming("ai")
        assert self._streaming is not None  # for type-checkers
        self._streaming.text += text
        return self._streaming

    def end_streaming(self, cards: list[dict] | None = None) -> Turn | None:
        turn = self._streaming
        if turn is not None and cards:
            turn.cards = list(cards)
        self._streaming = None
        return turn

    def clear(self) -> None:
        self._turns.clear()
        self._streaming = None


# ---------------------------------------------------------------------------
# Flet rendering
# ---------------------------------------------------------------------------

import webbrowser  # noqa: E402

import flet as ft  # noqa: E402

# Role styling constants
# Brand accents — kept as explicit hex; they read well on both themes.
TEAL = "#4ec9b0"
GREEN = "#3fb950"
BLUE = "#1f6feb"
SELF_BORDER = GREEN
OTHER_BORDER = BLUE
# Bubble backgrounds use Material 3 surface tokens so they adapt to theme.
# All three are in the SURFACE_CONTAINER family to keep `on_surface` text
# readable on either theme (avoiding ON_TERTIARY_CONTAINER mismatch risk
# with `ft.Markdown` which paints with `on_surface` by default).
YOU_BG = ft.Colors.SURFACE_CONTAINER_LOW
AI_BG = ft.Colors.SURFACE_CONTAINER
BRIEF_BG = ft.Colors.SURFACE_CONTAINER_HIGH

ROLE_ICON = {
    "self": "🎤",
    "other": "🔊",
    "you": "👤",
    "ai": "🤖",
    "brief": "📋",
}

ROLE_LABEL = {
    "self": "You said",
    "other": "Other said",
    "you": "You",
    "ai": "AI",
    "brief": "Brief",
}


def _format_ts(ts: float) -> str:
    return time.strftime("%H:%M", time.localtime(ts))


class ConversationView(ft.Container):
    """Flet rendering of a ConversationThread.

    Wraps an internal ``ft.ListView`` (``auto_scroll=False`` so ``scroll_to``
    works). The view tracks whether the user is currently pinned to the
    bottom — when they scroll up to read older content, ``is_following()``
    flips to ``False`` and the screen stops yanking them down on new turns.
    Scrolling back to the bottom re-arms the follow.

    Streaming updates are cheap: each turn keeps a reference to its body
    widget (``ft.Markdown`` for ai/brief, ``ft.Text`` for you). On
    ``notify_updated`` the body's value is mutated in place — no Container
    rebuild — so each chunk of streamed AI text shows up immediately.
    """

    # How close to the bottom (in pixels) still counts as "following". A small
    # buffer avoids toggling off on a tiny rubber-band overscroll.
    NEAR_BOTTOM_THRESHOLD_PX = 60.0

    def __init__(
        self,
        thread: ConversationThread,
        on_following_changed: "Callable[[bool], None] | None" = None,
    ) -> None:
        self._thread = thread
        # id(turn) -> (row Container, body widget, cards-container Column)
        self._row_for_turn: dict[int, tuple[ft.Control, ft.Control, ft.Column]] = {}
        # id(turn) -> headers Column (only present for ai/brief turns that
        # surfaced source-ticket lead-in chips). Kept in a separate dict so
        # we don't break the established 3-tuple contract above.
        self._headers_for_turn: dict[int, ft.Column] = {}
        self._following = True
        self._on_following_changed = on_following_changed
        self._list = ft.ListView(
            spacing=8,
            auto_scroll=False,
            expand=True,
            on_scroll=self._handle_scroll,
            scroll_interval=120,
        )
        super().__init__(content=self._list, expand=True)

    # ----------------------------- following / scroll API

    def is_following(self) -> bool:
        return self._following

    def force_follow(self) -> None:
        """Re-arm autoscroll (used when the user takes a deliberate action,
        e.g. clicking Send or the resume-autoscroll button)."""
        self._set_following(True)

    async def scroll_to_bottom(self) -> None:
        try:
            await self._list.scroll_to(offset=-1, duration=0)
        except Exception:
            pass

    def _set_following(self, value: bool) -> None:
        if self._following == value:
            return
        self._following = value
        if self._on_following_changed is not None:
            try:
                self._on_following_changed(value)
            except Exception:
                pass

    def _handle_scroll(self, e: "ft.OnScrollEvent") -> None:
        try:
            distance_from_bottom = e.max_scroll_extent - e.pixels
        except Exception:
            return
        self._set_following(distance_from_bottom <= self.NEAR_BOTTOM_THRESHOLD_PX)

    def is_rendered(self, turn: Turn) -> bool:
        return id(turn) in self._row_for_turn

    # ------------------------------------------------------------ public API

    def render_all(self) -> None:
        """Initial full render — call once after mounting."""
        self._list.controls = []
        self._row_for_turn.clear()
        for turn in self._thread.turns:
            self._append_turn(turn)
        self._safe_update()

    def notify_appended(self, turn: Turn) -> None:
        """Caller invokes this after a fresh ``thread.append(...)`` or ``begin_streaming(...)``.

        This method only mutates state. The owning screen is expected to call
        ``page.update()`` once per WS message to flush.
        """
        self._append_turn(turn)

    def notify_updated(self, turn: Turn) -> None:
        """Update an existing turn's body in place (cheap; no Container rebuild)."""
        entry = self._row_for_turn.get(id(turn))
        if entry is None:
            # turn isn't on screen yet (raced with append)
            self.notify_appended(turn)
            return
        _row, body, _cards_col = entry
        # For ai/brief turns the AI may stream a "> [TICKET-ID] Title" header
        # block at the top — strip those lines into themed chips, leaving the
        # body markdown clean. The chip column is updated in place too.
        text = turn.text or ""
        if turn.role in ("ai", "brief"):
            headers, body_text = _split_source_headers(text)
            headers_col = self._headers_for_turn.get(id(turn))
            if headers_col is not None:
                headers_col.controls = [self._render_source_header(h) for h in headers]
                headers_col.visible = bool(headers)
        else:
            body_text = text
        if isinstance(body, ft.Markdown):
            body.value = body_text
        elif isinstance(body, ft.Text):
            body.value = body_text

    def notify_cleared(self) -> None:
        self._list.controls = []
        self._row_for_turn.clear()
        self._headers_for_turn.clear()

    # ------------------------------------------------------------ rendering

    def _append_turn(self, turn: Turn) -> None:
        row, body, cards_col = self._build_turn(turn)
        self._list.controls.append(row)
        self._row_for_turn[id(turn)] = (row, body, cards_col)

    def _build_turn(self, turn: Turn) -> tuple[ft.Control, ft.Control, ft.Column]:
        """Build a row Container for a turn, returning (container, body widget, cards column).

        Body widget is held by reference so streaming chunks update it in place.
        cards column is empty initially; cards from `done` get appended into it.
        """
        icon = ROLE_ICON.get(turn.role, "•")
        label = ROLE_LABEL.get(turn.role, turn.role)
        ts = _format_ts(turn.ts)
        header = ft.Row(
            [
                ft.Text(f"{icon} {label}", size=11, weight=ft.FontWeight.W_600,
                        color=ft.Colors.ON_SURFACE_VARIANT),
                ft.Text(ts, size=11, color=ft.Colors.OUTLINE),
            ],
            spacing=8,
        )

        # Pull "> [TICKET-ID] Title" lead-in lines off the front of ai/brief
        # text so we can paint them as theme-aware chips instead of letting
        # them render as washed-out markdown blockquote.
        headers: list[tuple[str, str]] = []
        body_text = turn.text or ""
        if turn.role in ("ai", "brief"):
            headers, body_text = _split_source_headers(body_text)

        body: ft.Control
        if turn.role in ("ai", "brief"):
            body = ft.Markdown(
                body_text,
                selectable=True,
                extension_set=ft.MarkdownExtensionSet.GITHUB_WEB,
            )
        else:
            body = ft.Text(body_text, size=13, selectable=True)

        headers_col = ft.Column(
            controls=[self._render_source_header(h) for h in headers],
            spacing=4,
            visible=bool(headers),
        )
        if turn.role in ("ai", "brief"):
            self._headers_for_turn[id(turn)] = headers_col

        # The brief is meant to be read aloud — source-card boxes underneath
        # are visual clutter that distract from the spoken script, so we no
        # longer render them. Card data still rides on the turn for any
        # downstream consumer that wants it.
        cards_col = ft.Column([], spacing=4)

        bg = {
            "you": YOU_BG,
            "ai": AI_BG,
            "brief": BRIEF_BG,
        }.get(turn.role)
        border = None
        padding = ft.padding.symmetric(horizontal=10, vertical=6)
        if turn.role == "self":
            border = ft.border.only(left=ft.BorderSide(3, SELF_BORDER))
            padding = ft.padding.only(left=10, top=4, bottom=4, right=10)
        elif turn.role == "other":
            border = ft.border.only(left=ft.BorderSide(3, OTHER_BORDER))
            padding = ft.padding.only(left=10, top=4, bottom=4, right=10)

        return (
            ft.Container(
                content=ft.Column([header, headers_col, body, cards_col], spacing=4),
                bgcolor=bg,
                border=border,
                border_radius=6 if bg else 0,
                padding=padding,
            ),
            body,
            cards_col,
        )

    def _render_source_header(self, header: tuple[str, str]) -> ft.Control:
        """Render one `[TICKET-ID] Title` chip.

        Uses Material 3 surface tokens so the chip stays legible on both
        light and dark themes — `SECONDARY_CONTAINER` for the bg pairs
        with `ON_SECONDARY_CONTAINER` text guaranteed by the theme.
        """
        ticket_id, title = header
        return ft.Container(
            content=ft.Row(
                [
                    ft.Text(
                        f"[{ticket_id}]",
                        size=11,
                        weight=ft.FontWeight.W_700,
                        color=ft.Colors.ON_SECONDARY_CONTAINER,
                        no_wrap=True,
                    ),
                    ft.Text(
                        title,
                        size=11,
                        color=ft.Colors.ON_SECONDARY_CONTAINER,
                        weight=ft.FontWeight.W_500,
                        expand=True,
                    ),
                ],
                spacing=6,
                tight=True,
            ),
            bgcolor=ft.Colors.SECONDARY_CONTAINER,
            border_radius=6,
            padding=ft.padding.symmetric(horizontal=8, vertical=4),
        )

    def _render_one_card(self, c: dict) -> ft.Control:
        meta_parts: list[str] = []
        if c.get("status"):
            meta_parts.append(c["status"])
        if c.get("sprint"):
            meta_parts.append(f"Sprint {c['sprint']}")
        if c.get("due"):
            meta_parts.append(f"Due {c['due']}")
        meta = "  ·  ".join(meta_parts)
        head = f"[{c.get('id', '?')}] {c.get('title', '')}"
        url = c.get("url")

        def _open(_e: ft.ControlEvent) -> None:
            if url:
                webbrowser.open(url)

        return ft.Container(
            content=ft.Column([
                ft.Text(head, weight=ft.FontWeight.W_600, size=12),
                ft.Text(meta, size=10, color=ft.Colors.ON_SURFACE_VARIANT)
                    if meta else ft.Container(),
            ], spacing=2),
            padding=8,
            border=ft.border.all(1, ft.Colors.OUTLINE_VARIANT),
            border_radius=6,
            on_click=_open if url else None,
            tooltip=url or None,
        )

    def _safe_update(self) -> None:
        try:
            self.update()
        except Exception:
            pass
