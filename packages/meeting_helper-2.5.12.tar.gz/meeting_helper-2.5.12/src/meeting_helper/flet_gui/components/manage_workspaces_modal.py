"""Manage Workspaces — single Flet AlertDialog with create/rename/delete."""

from __future__ import annotations

from typing import Callable

import flet as ft

from meeting_helper.config import (
    create_workspace,
    delete_workspace,
    list_workspaces,
    load_state,
    rename_workspace,
)


class ManageWorkspacesModal:
    """Encapsulates the dialog and its mutation flows.

    `on_change` fires after any successful create/rename/delete so the
    caller can refresh the dropdown and any other dependent UI.
    """

    def __init__(self, page: ft.Page, on_change: Callable[[], None]):
        self._page = page
        self._on_change = on_change
        self._dialog: ft.AlertDialog | None = None
        self._list_column: ft.Column | None = None
        self._create_form: ft.Container | None = None

    def open(self) -> None:
        # Drop any stale dialog from a prior open() call
        if self._dialog is not None:
            try:
                self._page.overlay.remove(self._dialog)
            except ValueError:
                pass
            self._dialog = None

        self._list_column = ft.Column(spacing=4, tight=True)
        self._create_form = ft.Container(visible=False)

        new_btn = ft.OutlinedButton(
            "+ New workspace",
            icon=ft.Icons.ADD,
            on_click=lambda e: self._show_create_form(),
        )

        self._dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("Workspaces"),
            content=ft.Container(
                width=420,
                content=ft.Column(
                    [
                        self._list_column,
                        ft.Divider(),
                        new_btn,
                        self._create_form,
                    ],
                    tight=True,
                    spacing=12,
                ),
            ),
            actions=[
                ft.TextButton("Close", on_click=lambda e: self._close()),
            ],
        )
        self._refresh_list()
        self._page.overlay.append(self._dialog)
        self._dialog.open = True
        self._page.update()

    def _close(self) -> None:
        if self._dialog:
            self._dialog.open = False
            self._page.update()

    def _refresh_list(self) -> None:
        active = load_state()["active_workspace"]
        names = list_workspaces()
        rows = [self._row(n, active, len(names)) for n in names]
        if self._list_column:
            self._list_column.controls = rows
        if self._dialog and self._dialog.open:
            self._page.update()

    def _row(self, name: str, active: str, total: int) -> ft.Control:
        is_active = name == active
        is_only = total <= 1
        delete_disabled = is_active or is_only
        delete_tip = (
            "Cannot delete the active workspace. Switch away first."
            if is_active
            else "Cannot delete the last remaining workspace."
            if is_only
            else "Delete workspace"
        )

        return ft.Row(
            [
                ft.Text(name, expand=True, weight=ft.FontWeight.W_500),
                ft.Container(
                    content=ft.Text("Active", size=10),
                    visible=is_active,
                    bgcolor=ft.Colors.with_opacity(0.15, ft.Colors.PRIMARY),
                    padding=ft.padding.symmetric(horizontal=8, vertical=2),
                    border_radius=10,
                ),
                ft.IconButton(
                    icon=ft.Icons.EDIT_OUTLINED,
                    icon_size=16,
                    tooltip="Rename",
                    on_click=lambda e, n=name: self._show_rename(n),
                ),
                ft.IconButton(
                    icon=ft.Icons.DELETE_OUTLINE,
                    icon_size=16,
                    tooltip=delete_tip,
                    disabled=delete_disabled,
                    on_click=lambda e, n=name: self._confirm_delete(n),
                ),
            ],
            spacing=4,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def _show_rename(self, name: str) -> None:
        field = ft.TextField(value=name, autofocus=True, dense=True)
        error = ft.Text("", color=ft.Colors.ERROR, size=12)

        def save(_e):
            new = (field.value or "").strip()
            if new == name:
                self._refresh_list()
                return
            try:
                rename_workspace(name, new)
            except ValueError as exc:
                error.value = str(exc)
                self._page.update()
                return
            self._on_change()
            self._refresh_list()

        def cancel(_e):
            self._refresh_list()

        if self._list_column:
            self._list_column.controls = [
                ft.Row(
                    [
                        field,
                        ft.IconButton(icon=ft.Icons.CHECK, on_click=save),
                        ft.IconButton(icon=ft.Icons.CLOSE, on_click=cancel),
                    ],
                    spacing=4,
                ),
                error,
            ]
            self._page.update()

    def _confirm_delete(self, name: str) -> None:
        field = ft.TextField(
            label=f"Type {name!r} to confirm",
            dense=True,
            autofocus=True,
        )
        error = ft.Text("", color=ft.Colors.ERROR, size=12)

        def confirm(_e):
            if (field.value or "").strip() != name:
                error.value = "Name does not match."
                self._page.update()
                return
            try:
                delete_workspace(name)
            except ValueError as exc:
                error.value = str(exc)
                self._page.update()
                return
            self._on_change()
            self._refresh_list()

        def cancel(_e):
            self._refresh_list()

        if self._list_column:
            self._list_column.controls = [
                ft.Text(f"Delete workspace '{name}'?", weight=ft.FontWeight.W_500),
                ft.Text(
                    "Recordings on disk are NOT deleted, only the JSON config.",
                    size=11,
                    color=ft.Colors.ON_SURFACE_VARIANT,
                ),
                field,
                error,
                ft.Row([
                    ft.TextButton("Cancel", on_click=cancel),
                    ft.FilledButton(
                        "Delete",
                        bgcolor=ft.Colors.ERROR,
                        on_click=confirm,
                    ),
                ], alignment=ft.MainAxisAlignment.END),
            ]
            self._page.update()

    def _show_create_form(self) -> None:
        if not self._create_form:
            return
        name_field = ft.TextField(label="Name", autofocus=True, dense=True)
        copy_check = ft.Checkbox(label="Copy settings from current workspace", value=False)
        error = ft.Text("", color=ft.Colors.ERROR, size=12)

        def submit(_e):
            name = (name_field.value or "").strip()
            try:
                copy_from = load_state()["active_workspace"] if copy_check.value else None
                create_workspace(name, copy_from=copy_from)
            except ValueError as exc:
                error.value = str(exc)
                self._page.update()
                return
            self._create_form.visible = False
            self._on_change()
            self._refresh_list()

        def cancel(_e):
            self._create_form.visible = False
            self._page.update()

        self._create_form.content = ft.Column(
            [
                name_field,
                copy_check,
                error,
                ft.Row(
                    [
                        ft.TextButton("Cancel", on_click=cancel),
                        ft.FilledButton("Create", on_click=submit),
                    ],
                    alignment=ft.MainAxisAlignment.END,
                ),
            ],
            tight=True,
            spacing=8,
        )
        self._create_form.visible = True
        self._page.update()
