"""BriefPanel — renders the {script, cards} response from POST /brief.

The brief is meant to be read aloud at standup, so this view shows ONLY the
script. The `cards` field on the payload is accepted for compatibility but
intentionally not surfaced — ticket-id boxes underneath the script clutter
what is supposed to be a spoken narrative.
"""

from __future__ import annotations

import flet as ft


class BriefPanel(ft.Column):
    def __init__(self):
        super().__init__(spacing=8, visible=False)
        self._script = ft.Markdown(
            "",
            selectable=True,
            extension_set=ft.MarkdownExtensionSet.GITHUB_WEB,
        )
        self.controls = [
            ft.Container(
                content=self._script,
                padding=12,
                bgcolor=ft.Colors.SURFACE_CONTAINER_HIGH,
                border_radius=8,
            ),
        ]

    def render(self, payload: dict):
        self._script.value = payload.get("script", "") or ""
        self.visible = True
        self.update()

    def show_error(self, message: str):
        self._script.value = f"**(error)** {message}"
        self.visible = True
        self.update()
