"""Copilot screen — during-meeting surface (toolbar, topic, conversation, tasks)."""

from __future__ import annotations

import asyncio
import json
import threading
import time
import urllib.error
import urllib.request
from typing import TYPE_CHECKING

import websockets

import flet as ft

from meeting_helper.flet_gui.components.conversation import (
    ConversationThread,
    ConversationView,
)
from meeting_helper.flet_gui.components.pill import Pill, PillOption
from meeting_helper.flet_gui.components.tasks_panel import TasksPanel
from meeting_helper.flet_gui.components.topic_strip import TopicStrip

if TYPE_CHECKING:
    from meeting_helper.config import Config

TEAL = "#4ec9b0"
ERROR_RED = "#f14c4c"

_PROVIDER_OPTIONS = [
    PillOption(key="claude", label="Claude"),
    PillOption(key="gemini", label="Gemini"),
    PillOption(key="local", label="Ollama (Free)"),
]

_TRANSCRIBER_OPTIONS = [
    PillOption(key="whisper", label="Whisper (Free)"),
    PillOption(key="deepgram", label="Deepgram"),
]

_MODEL_OPTIONS_BY_PROVIDER: dict[str, list[PillOption]] = {
    "claude": [
        PillOption(key="sonnet", label="Sonnet"),
        PillOption(key="opus", label="Opus"),
        PillOption(key="haiku", label="Haiku"),
    ],
    "gemini": [
        PillOption(key="flash", label="Flash"),
        PillOption(key="pro", label="Pro"),
    ],
    "local": [],
}

_PROVIDER_TO_MODEL_KEY = {
    "claude": "claude_model",
    "gemini": "gemini_model",
    "local": "local_model",
}


class CopilotScreen(ft.Column):
    def __init__(self, page: ft.Page, config: "Config") -> None:
        super().__init__(expand=True, spacing=0)
        self._page = page
        self._config = config
        self._port = config.port
        self._daemon_running = False
        self._session_active = False
        self._syncing_provider = False
        # Track the canonical current provider/transcriber so model-pill
        # selections don't have to guess from display labels (they used to
        # infer the provider from `self._provider_pill.label`, which lagged
        # the actual state and produced invalid combos like Claude+Flash).
        self._current_provider: str = "claude"
        self._current_transcriber: str = "whisper"
        # Suppress provider polling for this many seconds after a user click,
        # so the periodic /provider GET doesn't overwrite the user's just-made
        # selection while the daemon is still processing the POST.
        self._provider_poll_suppressed_until: float = 0.0
        self._PROVIDER_POLL_SUPPRESS_SEC = 5.0
        # Workspace readiness flags (filled by /provider polling). Optimistic
        # defaults match how the daemon used to behave before these flags
        # existed — controls show until we hear otherwise.
        self._local_todo_configured: bool = True
        self._provider_configured: bool = True

        # ---------------- toolbar ----------------
        self._status_icon = ft.Icon(ft.Icons.CIRCLE, color=ft.Colors.OUTLINE, size=12)
        self._status_text = ft.Text("Stopped", size=12, color=ft.Colors.ON_SURFACE_VARIANT)

        # Engagement (Hot Moment) indicator — sits next to the recording status pill.
        self._engagement_dot = ft.Icon(
            ft.Icons.RADIO_BUTTON_UNCHECKED,
            color=ft.Colors.OUTLINE,
            size=10,
        )
        self._engagement_text = ft.Text(
            "Idle",
            size=12,
            color=ft.Colors.ON_SURFACE_VARIANT,
        )
        self._engagement_pill = ft.Container(
            content=ft.Row(
                [self._engagement_dot, self._engagement_text],
                spacing=4,
                tight=True,
            ),
            tooltip="Idle — listening to mic only. Speak or send a query to engage.",
            padding=ft.padding.symmetric(horizontal=8, vertical=2),
            border=ft.border.all(1, ft.Colors.OUTLINE_VARIANT),
            border_radius=10,
            visible=False,
        )
        # Hot Moment countdown state. Updated by `_set_engagement` and a
        # per-second ticker thread launched in `_ensure_countdown_ticker`.
        self._engagement_until_wallclock: float = 0.0
        self._engagement_ticker_running: bool = False

        self._session_btn = ft.IconButton(
            icon=ft.Icons.FIBER_MANUAL_RECORD,
            icon_color="#238636",
            tooltip="Start recording",
            on_click=self._on_session_toggle,
        )

        self._transcriber_pill = Pill(
            label="Whisper",
            options=_TRANSCRIBER_OPTIONS,
            on_select=self._on_transcriber_select,
        )
        self._provider_pill = Pill(
            label="Claude",
            options=_PROVIDER_OPTIONS,
            on_select=self._on_provider_select,
        )
        self._model_pill = Pill(
            label="Sonnet",
            options=_MODEL_OPTIONS_BY_PROVIDER["claude"],
            on_select=self._on_model_select,
        )

        self._brief_btn_label = ft.Text("Brief", color="white", weight=ft.FontWeight.W_500)
        self._brief_btn = ft.ElevatedButton(
            content=self._brief_btn_label,
            icon=ft.Icons.DESCRIPTION,
            bgcolor="#1f6feb",
            color="white",
            tooltip="Generate Brief",
            on_click=self._on_brief_clicked,
        )
        self._clear_btn = ft.IconButton(
            icon=ft.Icons.DELETE_OUTLINE,
            tooltip="Clear conversation",
            on_click=self._on_clear_clicked,
        )
        self._autoscroll_btn = ft.IconButton(
            icon=ft.Icons.VERTICAL_ALIGN_BOTTOM,
            icon_color=TEAL,
            tooltip="Auto-scroll on (following bottom)",
            on_click=self._on_autoscroll_clicked,
        )

        # Live counters — totals only, displayed as a compact pill that sits
        # in the *left* group (after the model pill) so the right-side action
        # buttons don't shift. Tooltip shows per-kind breakdown for debugging.
        self._ai_count_text = ft.Text(
            "0", size=11, color=ft.Colors.ON_SURFACE_VARIANT, no_wrap=True,
        )
        self._todo_count_text = ft.Text(
            "0", size=11, color=ft.Colors.ON_SURFACE_VARIANT, no_wrap=True,
        )
        self._stats_pill = ft.Container(
            content=ft.Row(
                [
                    ft.Icon(ft.Icons.AUTO_AWESOME, size=12, color=ft.Colors.ON_SURFACE_VARIANT),
                    self._ai_count_text,
                    ft.Container(width=4),
                    ft.Icon(ft.Icons.CHECKLIST, size=12, color=ft.Colors.ON_SURFACE_VARIANT),
                    self._todo_count_text,
                ],
                spacing=4,
                tight=True,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            tooltip="AI calls · local-todo calls (this meeting)",
            padding=ft.padding.symmetric(horizontal=10, vertical=4),
            border=ft.border.all(1, ft.Colors.OUTLINE_VARIANT),
            border_radius=999,
            visible=False,
        )

        toolbar = ft.Container(
            content=ft.Row(
                [
                    ft.Row([self._status_icon, self._status_text], spacing=6),
                    self._engagement_pill,
                    self._session_btn,
                    ft.Container(width=4),
                    self._transcriber_pill,
                    self._provider_pill,
                    self._model_pill,
                    self._stats_pill,
                    ft.Container(expand=True),
                    self._brief_btn,
                    self._autoscroll_btn,
                    self._clear_btn,
                ],
                spacing=8,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.padding.symmetric(horizontal=16, vertical=8),
            bgcolor=ft.Colors.SURFACE_CONTAINER_HIGH,
        )

        # ---------------- topic strip ----------------
        self._topic_strip = TopicStrip(on_explain=self._on_explain_topic)
        self._topic_strip_container = ft.Container(
            content=self._topic_strip,
            padding=ft.padding.symmetric(horizontal=16, vertical=8),
            border=ft.border.only(bottom=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT)),
            visible=False,  # only shown during an active meeting
        )

        # ---------------- conversation + tasks panel ----------------
        self._thread = ConversationThread()
        self._view = ConversationView(
            self._thread,
            on_following_changed=self._on_view_following_changed,
        )

        self._tasks_panel = TasksPanel(title="Tasks")
        self._extract_btn_label = ft.Text("Extract Task", color="white", weight=ft.FontWeight.W_500)
        self._extract_btn = ft.ElevatedButton(
            content=self._extract_btn_label,
            icon=ft.Icons.ADD_TASK,
            bgcolor="#1f6feb",
            color="white",
            on_click=self._on_extract_task,
        )
        tasks_pane = ft.Container(
            content=ft.Column(
                [self._extract_btn, self._tasks_panel],
                spacing=10,
                expand=True,
            ),
            width=280,
            padding=ft.padding.symmetric(horizontal=12, vertical=10),
            border=ft.border.only(left=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT)),
        )

        body_row = ft.Row(
            [
                ft.Container(
                    content=self._view,
                    expand=True,
                    padding=ft.padding.symmetric(horizontal=16, vertical=10),
                ),
                tasks_pane,
            ],
            expand=True,
            spacing=0,
        )

        # ---------------- ask AI input ----------------
        self._query_input = ft.TextField(
            hint_text="Ask AI…  (Enter to send)",
            dense=True,
            border_radius=8,
            text_size=13,
            on_submit=self._on_send,
            expand=True,
        )
        self._send_btn = ft.ElevatedButton(
            "➤ Send",
            on_click=self._on_send,
        )
        self._trigger_btn = ft.IconButton(
            icon=ft.Icons.AUTO_AWESOME,
            icon_color=TEAL,
            tooltip="Ask AI from current context (same as 2×Cmd)",
            on_click=self._on_trigger_query,
        )
        input_row = ft.Container(
            content=ft.Row(
                [self._query_input, self._trigger_btn, self._send_btn],
                spacing=8,
            ),
            padding=ft.padding.symmetric(horizontal=16, vertical=10),
            bgcolor=ft.Colors.SURFACE_CONTAINER_HIGH,
        )

        # ---------------- empty state (daemon down) ----------------
        self._empty_state = ft.Container(
            content=ft.Column(
                [
                    ft.Icon(ft.Icons.AUTO_AWESOME, size=48, color=ft.Colors.OUTLINE),
                    ft.Text("Daemon not running", size=18, weight=ft.FontWeight.W_600),
                    ft.Text(
                        "Start with: meeting-helper start",
                        size=13, color=ft.Colors.ON_SURFACE_VARIANT,
                    ),
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=12,
            ),
            alignment=ft.Alignment(0, 0),
            expand=True,
        )

        self._live_body = ft.Column(
            [self._topic_strip_container, body_row, input_row],
            spacing=0,
            expand=True,
        )

        self._content_stack = ft.Container(content=self._live_body, expand=True)
        self._toolbar_container = toolbar
        self.controls = [toolbar, self._content_stack]

        self._start_provider_polling()
        self._page.run_thread(self._seed_topic)
        self._start_ws_subscription()
        self._start_tasks_polling()
        self._start_stats_polling()

    # ------------------------------------------------ public lifecycle

    def update_status(self, daemon_running: bool, session_active: bool, meeting_name: str) -> None:
        was_session_active = self._session_active
        self._daemon_running = daemon_running
        self._session_active = session_active
        if session_active:
            self._status_icon.color = ERROR_RED
            self._status_text.value = f"Recording: {meeting_name}" if meeting_name else "Recording"
            self._status_text.color = ERROR_RED
            self._session_btn.icon = ft.Icons.STOP
            self._session_btn.icon_color = ERROR_RED
            self._session_btn.tooltip = "Stop recording"
            self._session_btn.visible = True
        elif daemon_running:
            self._status_icon.color = TEAL
            self._status_text.value = "Ready"
            self._status_text.color = TEAL
            self._session_btn.icon = ft.Icons.FIBER_MANUAL_RECORD
            self._session_btn.icon_color = "#238636"
            self._session_btn.tooltip = "Start recording"
            self._session_btn.visible = True
        else:
            self._status_icon.color = ft.Colors.OUTLINE
            self._status_text.value = "Stopped"
            self._status_text.color = ft.Colors.ON_SURFACE_VARIANT
            self._session_btn.visible = False

        # In-meeting actions are hidden entirely when no meeting is active.
        # Brief, Auto-scroll, Clear and Extract Task have no meaning outside
        # a live session — no transcript, no conversation, no warm cards.
        in_meeting = session_active
        self._extract_btn.visible = in_meeting
        self._autoscroll_btn.visible = in_meeting
        self._clear_btn.visible = in_meeting
        self._trigger_btn.visible = in_meeting
        self._stats_pill.visible = in_meeting
        self._topic_strip_container.visible = in_meeting
        # Brief + provider/model pills also depend on workspace readiness.
        self._apply_readiness_visibility()

        # If a meeting just ended, wipe per-meeting state so the GUI doesn't
        # dangle (topic banner, tasks list, engagement countdown, conversation).
        if was_session_active and not session_active:
            self._reset_for_new_meeting()

        # Toggle empty state: when daemon is down, replace the whole body.
        if daemon_running:
            if self._content_stack.content is self._empty_state:
                self._content_stack.content = self._live_body
        else:
            self._content_stack.content = self._empty_state

        # Engagement pill follows the same daemon-down hide rule as the session button.
        self._engagement_pill.visible = daemon_running

        try:
            self._page.update()
        except Exception:
            pass

    def _reset_for_new_meeting(self) -> None:
        """Wipe per-meeting state — topic banner, tasks panel, engagement
        countdown, conversation thread. Called when a meeting ends so the GUI
        doesn't dangle stale content from the previous meeting.
        """
        # Conversation
        self._thread.clear()
        self._view.notify_cleared()
        self._view.force_follow()
        # Topic banner — full clear (current + history)
        self._topic_strip.clear()
        # Tasks panel
        self._tasks_panel.set_tasks([])
        # Engagement pill
        self._set_engagement(False, 0.0)

    def _set_engagement(self, active: bool, until_wallclock: float = 0.0) -> None:
        """Update the Engagement pill icon, label, color, and tooltip.

        When ``active`` is True and ``until_wallclock > 0``, also kick off a
        per-second countdown ticker that updates the label like
        ``Active · 9:54`` and locally flips to Idle when the timer expires
        (so the UI reflects the transition without waiting for the next
        daemon ticker tick).
        """
        # Cancel any in-flight countdown ticker — we'll restart if still active.
        self._engagement_until_wallclock = until_wallclock if active else 0.0

        if active:
            self._engagement_dot.name = ft.Icons.CIRCLE
            self._engagement_dot.color = TEAL
            self._engagement_text.color = TEAL
            self._engagement_pill.tooltip = (
                "Engaged — TopicWorker is listening to both you and others."
            )
            self._refresh_engagement_label()
            self._ensure_countdown_ticker()
        else:
            self._engagement_dot.name = ft.Icons.RADIO_BUTTON_UNCHECKED
            self._engagement_dot.color = ft.Colors.OUTLINE
            self._engagement_text.value = "Idle"
            self._engagement_text.color = ft.Colors.ON_SURFACE_VARIANT
            self._engagement_pill.tooltip = (
                "Idle — listening to mic only. Speak or send a query to engage."
            )

    def _refresh_engagement_label(self) -> None:
        """Recompute the `Active · M:SS` label from the current `until_wallclock`."""
        import time as _time
        if self._engagement_until_wallclock <= 0:
            self._engagement_text.value = "Active"
            return
        secs = int(round(self._engagement_until_wallclock - _time.time()))
        if secs <= 0:
            # Expired locally — flip to Idle visually. The daemon's ticker
            # will confirm with an engagement_status event shortly.
            self._engagement_until_wallclock = 0.0
            self._engagement_dot.name = ft.Icons.RADIO_BUTTON_UNCHECKED
            self._engagement_dot.color = ft.Colors.OUTLINE
            self._engagement_text.value = "Idle"
            self._engagement_text.color = ft.Colors.ON_SURFACE_VARIANT
            self._engagement_pill.tooltip = (
                "Idle — listening to mic only. Speak or send a query to engage."
            )
            return
        m, s = divmod(secs, 60)
        self._engagement_text.value = f"Active · {m}:{s:02d}"

    def _ensure_countdown_ticker(self) -> None:
        """Start the per-second ticker if not already running."""
        if self._engagement_ticker_running:
            return
        self._engagement_ticker_running = True

        def _tick() -> None:
            import threading as _threading
            while self._engagement_until_wallclock > 0:
                _threading.Event().wait(1.0)
                self._refresh_engagement_label()
                try:
                    self._engagement_text.update()
                except Exception:
                    pass
            self._engagement_ticker_running = False

        self._page.run_thread(_tick)

    def on_activate(self) -> None:
        # Force a provider sync the moment the user opens the screen.
        self._page.run_thread(self._poll_provider)

    def on_workspace_changed(self) -> None:
        from meeting_helper.config import get_config
        self.config = get_config()
        # Rebind websocket loop to the new daemon port (next reconnect picks it up)
        self._port = self.config.port
        # Clear conversation, brief, topic, sources panels so we don't show
        # state from the previous workspace.
        reset = getattr(self, "_reset_for_new_meeting", None)
        if callable(reset):
            reset()
        try:
            self.update()
        except Exception:
            pass

    # ------------------------------------------------ provider syncing

    def _start_provider_polling(self) -> None:
        def _poll() -> None:
            while True:
                self._poll_provider()
                threading.Event().wait(3)

        self._page.run_thread(_poll)

    # ------------------------------------------------ stats polling
    #
    # Polls /health every 3s for AI + local-todo call counters and renders
    # a compact summary in the toolbar. Hidden outside an active meeting
    # (counters reset on session start).

    def _start_stats_polling(self) -> None:
        def _poll() -> None:
            while True:
                self._poll_stats()
                threading.Event().wait(3)

        self._page.run_thread(_poll)

    def _poll_stats(self) -> None:
        if not self._session_active:
            return
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self._port}/health")
            with urllib.request.urlopen(req, timeout=1) as resp:
                data = json.loads(resp.read().decode())
        except Exception:
            return

        stats = data.get("stats") or {}
        ai = int(stats.get("ai_calls", 0))
        td = int(stats.get("local_todo_calls", 0))
        self._ai_count_text.value = str(ai)
        self._todo_count_text.value = str(td)

        # Per-kind breakdown lives in the tooltip — visible on hover, doesn't
        # affect the pill width so the toolbar layout stays stable.
        ai_kinds = stats.get("ai_calls_by_kind") or {}
        td_kinds = stats.get("local_todo_calls_by_kind") or {}
        last_action = stats.get("last_local_todo_action") or ""
        ai_breakdown = ", ".join(f"{k}={v}" for k, v in sorted(ai_kinds.items())) or "(none)"
        td_breakdown = ", ".join(f"{k}={v}" for k, v in sorted(td_kinds.items())) or "(none)"
        tooltip = (
            f"AI calls: {ai} ({ai_breakdown})\n"
            f"Local-todo calls: {td} ({td_breakdown})"
        )
        if last_action:
            tooltip += f"\nLast todo action: {last_action}"
        self._stats_pill.tooltip = tooltip

        try:
            self._stats_pill.update()
        except Exception:
            pass

    def _poll_provider(self) -> None:
        # Skip polling for a few seconds after a user click. Without this, the
        # 3 s background poll fetches the OLD provider state from the daemon
        # (the POST may still be in flight or transcriber-swap is blocking
        # the daemon's handler) and overwrites the user's just-made selection.
        if time.monotonic() < self._provider_poll_suppressed_until:
            return
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self._port}/provider")
            with urllib.request.urlopen(req, timeout=1) as resp:
                data = json.loads(resp.read().decode())
        except Exception:
            return

        self._syncing_provider = True
        try:
            provider = data.get("provider", "claude")
            self._current_provider = provider
            self._provider_pill.set_label(_label_for(_PROVIDER_OPTIONS, provider, "Claude"))

            model_key = _PROVIDER_TO_MODEL_KEY.get(provider, "claude_model")
            model_val = data.get(model_key, "")
            opts = _MODEL_OPTIONS_BY_PROVIDER.get(provider, [])
            if provider == "local" and model_val:
                opts = [PillOption(key=model_val, label=model_val)]
            self._model_pill.set_options(opts)
            if model_val:
                self._model_pill.set_label(_label_for(opts, model_val, model_val))

            transcriber = data.get("transcriber", "whisper")
            self._current_transcriber = transcriber
            self._transcriber_pill.set_label(
                _label_for(_TRANSCRIBER_OPTIONS, transcriber, "Whisper")
            )

            # Readiness flags drive control visibility (Brief, provider/model
            # pills). Default to True if the daemon predates these fields so
            # we don't hide everything against an old daemon.
            self._local_todo_configured = bool(
                data.get("local_todo_configured", True)
            )
            self._provider_configured = bool(
                data.get("provider_configured", True)
            )
            self._apply_readiness_visibility()

            try:
                self._page.update()
            except Exception:
                pass
        finally:
            self._syncing_provider = False

    def _apply_readiness_visibility(self) -> None:
        """Toggle Brief / provider / model controls based on workspace setup.

        - Brief button needs an in-progress meeting AND a local-todo MCP — no
          point offering it when there are no tasks to summarize.
        - Provider + model pills are pointless when no AI provider is set up
          (no key for Claude/Gemini and not opted into local), since there's
          nothing to switch between.
        """
        in_meeting = self._session_active
        self._brief_btn.visible = in_meeting and self._local_todo_configured
        self._provider_pill.visible = self._provider_configured
        self._model_pill.visible = self._provider_configured

    def _suppress_provider_poll(self) -> None:
        """Pause provider polling for a few seconds after a user action so the
        poll loop doesn't snap the UI back to a stale daemon state."""
        self._provider_poll_suppressed_until = (
            time.monotonic() + self._PROVIDER_POLL_SUPPRESS_SEC
        )

    def _on_transcriber_select(self, key: str) -> None:
        if self._syncing_provider:
            return
        self._current_transcriber = key
        self._transcriber_pill.set_label(
            _label_for(_TRANSCRIBER_OPTIONS, key, key.title())
        )
        self._suppress_provider_poll()
        self._post_provider({"transcriber": key})

    def _on_provider_select(self, key: str) -> None:
        if self._syncing_provider:
            return
        # Track the canonical provider locally — `_on_model_select` reads this
        # rather than inferring from the displayed pill label.
        self._current_provider = key
        self._provider_pill.set_label(_label_for(_PROVIDER_OPTIONS, key, key.title()))
        # Reset model options for the new provider before posting.
        opts = _MODEL_OPTIONS_BY_PROVIDER.get(key, [])
        self._model_pill.set_options(opts)
        first_model = opts[0].key if opts else None
        body: dict = {"provider": key}
        if first_model:
            body[_PROVIDER_TO_MODEL_KEY[key]] = first_model
            self._model_pill.set_label(opts[0].label)
        self._suppress_provider_poll()
        self._post_provider(body)

    def _on_model_select(self, key: str) -> None:
        if self._syncing_provider:
            return
        # Use the canonical provider state — NOT the pill label, which can
        # lag behind the actual state during fast switching.
        provider = self._current_provider or "claude"
        model_key = _PROVIDER_TO_MODEL_KEY.get(provider, "claude_model")
        # Reflect the new model label immediately for instant feedback.
        opts = _MODEL_OPTIONS_BY_PROVIDER.get(provider, []) or self._model_pill.options
        self._model_pill.set_label(_label_for(opts, key, key))
        self._suppress_provider_poll()
        self._post_provider({model_key: key})

    def _post_provider(self, body: dict) -> None:
        def _do() -> None:
            try:
                data = json.dumps(body).encode()
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}/provider",
                    data=data,
                    headers={"Content-Type": "application/json"},
                )
                urllib.request.urlopen(req, timeout=10)
            except Exception:
                pass

        self._page.run_thread(_do)

        self._page.run_thread(_do)

    # ------------------------------------------------ topic + query handlers

    def _seed_topic(self) -> None:
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self._port}/current_topic")
            with urllib.request.urlopen(req, timeout=2) as resp:
                data = json.loads(resp.read().decode())
            topic_info = data.get("topic", {}) or {}
            topic = (topic_info.get("topic") or "").strip()
            tickets = topic_info.get("ticket_ids") or []
            if topic:
                self._topic_strip.set_topic(topic, tickets)
        except Exception:
            pass

    def _on_explain_topic(self, topic: str) -> None:
        text = f"Explain more about {topic}"
        self._thread.append("you", text)
        self._view.notify_appended(self._thread.turns[-1])
        self._view.force_follow()
        self._page.update()
        self._page.run_task(self._view.scroll_to_bottom)
        self._post_query(text)

    def _post_query(self, text: str) -> None:
        def _do() -> None:
            try:
                body = json.dumps({"text": text}).encode()
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}/query",
                    data=body,
                    headers={"Content-Type": "application/json"},
                )
                urllib.request.urlopen(req, timeout=120)
            except Exception:
                pass
        self._page.run_thread(_do)

    # ------------------------------------------------ websocket subscription

    def _start_ws_subscription(self) -> None:
        # Run on the page's actual asyncio loop (not a worker thread). With
        # run_thread + new_event_loop, every `.update()` from the WS handler
        # crosses both a thread and a loop boundary, which serializes UI
        # updates and makes streaming feel sluggish. run_task keeps everything
        # on the page's loop so widget mutations + page.update() are direct.
        self._page.run_task(self._ws_loop)

    async def _ws_loop(self) -> None:
        while True:
            url = f"ws://127.0.0.1:{self._port}/ws"
            try:
                async with websockets.connect(url) as ws:
                    async for raw in ws:
                        try:
                            msg = json.loads(raw)
                        except Exception:
                            continue
                        await self._dispatch_ws_event(msg)
                        # One batched flush per WS message — much cheaper than
                        # per-widget update() calls and produces a single,
                        # consistent paint per event.
                        try:
                            self._page.update()
                        except Exception:
                            pass
            except Exception:
                # Reconnect after a short backoff.
                await asyncio.sleep(2)

    async def _dispatch_ws_event(self, msg: dict) -> None:
        kind = msg.get("type")
        if kind == "transcript":
            # SELF / OTHER sentences flow into the conversation thread so the
            # chat reads like a real meeting log. Consecutive sentences from
            # the same speaker (within SPEAKER_BURST_WINDOW_SEC) merge into
            # the same turn instead of spawning a new bubble per sentence.
            #
            # IMPORTANT: ignore interim transcripts here. Both Deepgram and
            # Whisper fire many growing-prefix interims per utterance ("so",
            # "so hello", "so hello everyone", …); appending each one stacks
            # repeated phrases inside the bubble. Only the FINAL transcript
            # belongs in the chat record. The overlay still shows interims
            # in its own live-preview labels.
            if msg.get("interim"):
                return
            role = msg.get("role")
            text = (msg.get("text") or "").strip()
            if not text or role not in ("self", "other"):
                return
            turn, extended = self._thread.append_or_extend_transcript(role, text)
            if extended:
                self._view.notify_updated(turn)
            else:
                self._view.notify_appended(turn)
            self._page.update()
            if self._view.is_following():
                await self._view.scroll_to_bottom()
            return
        elif kind == "topic":
            topic = msg.get("topic") or ""
            tickets = msg.get("ticket_ids") or []
            self._topic_strip.set_topic(topic, tickets)
            hm = msg.get("hot_moment") or {}
            self._set_engagement(
                bool(hm.get("active")),
                float(hm.get("until_wallclock") or 0.0),
            )
        elif kind == "start":
            # AI is starting to stream a response. Open an empty `ai` turn now;
            # subsequent `chunk` events will fill it in.
            turn = self._thread.begin_streaming("ai")
            self._view.notify_appended(turn)
            self._page.update()
            if self._view.is_following():
                await self._view.scroll_to_bottom()
            return
        elif kind == "meeting_status":
            active = bool(msg.get("active"))
            meeting_name = msg.get("meeting_name") or msg.get("app") or ""
            # Flip the toolbar status the moment the daemon reports the new
            # state — much faster than the global 3 s /health poll.
            self.update_status(True, active, meeting_name)
            if active:
                # New meeting → fresh conversation per the spec.
                self._thread.clear()
                self._view.notify_cleared()
        elif kind == "meeting_ended":
            # update_status already calls _reset_for_new_meeting on the
            # active→inactive transition. The explicit cleanup call here is
            # idempotent and covers the case where update_status was already
            # called by the polling loop just before this WS event.
            self.update_status(True, False, "")
            self._reset_for_new_meeting()
        elif kind == "engagement_status":
            self._set_engagement(
                bool(msg.get("active")),
                float(msg.get("until_wallclock") or 0.0),
            )
        elif kind == "chunk":
            text = msg.get("text") or ""
            if text:
                turn = self._thread.append_chunk(text)
                # If this is the first chunk of a new turn, render it; else update.
                if not self._view.is_rendered(turn):
                    self._view.notify_appended(turn)
                else:
                    self._view.notify_updated(turn)
                self._page.update()
                await self._view.scroll_to_bottom()
                return
        elif kind == "done":
            cards = msg.get("cards") or msg.get("items") or None
            turn = self._thread.end_streaming(cards=cards)
            if turn is not None:
                self._view.notify_updated(turn)
                self._page.update()
                await self._view.scroll_to_bottom()
                return
        elif kind == "brief":
            # Brief comes as a full payload (script + cards); append as one turn.
            script = msg.get("script") or ""
            cards = msg.get("cards") or []
            turn = self._thread.append("brief", script, cards=cards)
            self._view.notify_appended(turn)
            self._page.update()
            if self._view.is_following():
                await self._view.scroll_to_bottom()
            return
        elif kind == "cards":
            cards = msg.get("items") or msg.get("cards") or []
            # Attach to the last ai turn if there is one.
            for turn in reversed(self._thread.turns):
                if turn.role == "ai":
                    turn.cards = list(cards)
                    self._view.notify_updated(turn)
                    break

    # ------------------------------------------------ ask AI input handler

    def _on_send(self, _e: ft.ControlEvent) -> None:
        text = (self._query_input.value or "").strip()
        if not text:
            return
        self._query_input.value = ""
        try:
            self._query_input.update()
        except Exception:
            pass
        turn = self._thread.append("you", text)
        self._view.notify_appended(turn)
        self._view.force_follow()
        self._page.update()
        self._page.run_task(self._view.scroll_to_bottom)
        self._post_query(text)

    # ------------------------------------------------ trigger-query handler
    #
    # Mirrors the 2xCmd hotkey: posts to /query/trigger so the daemon runs
    # handle_query() with no typed text — the AI reply uses the current
    # transcript + topic context.

    def _on_trigger_query(self, _e: ft.ControlEvent) -> None:
        if not self._session_active:
            return
        self._trigger_btn.disabled = True
        try:
            self._trigger_btn.update()
        except Exception:
            pass

        def _do() -> None:
            try:
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}/query/trigger",
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                urllib.request.urlopen(req, timeout=60).read()
            except Exception as exc:
                turn = self._thread.append("ai", f"**(error)** {exc}")
                self._view.notify_appended(turn)
            finally:
                self._trigger_btn.disabled = False
                try:
                    self._trigger_btn.update()
                except Exception:
                    pass

        self._page.run_thread(_do)

    # ------------------------------------------------ brief button handler

    def _on_brief_clicked(self, _e: ft.ControlEvent) -> None:
        self._brief_btn.disabled = True
        self._brief_btn_label.value = "Generating…"
        try:
            self._brief_btn.update()
        except Exception:
            pass

        def _do() -> None:
            try:
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}/brief",
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                urllib.request.urlopen(req, timeout=120).read()
            except urllib.error.HTTPError as exc:
                try:
                    body_str = exc.read().decode()
                    err = json.loads(body_str).get("error", str(exc))
                except Exception:
                    err = str(exc)
                turn = self._thread.append("brief", f"**(error)** {err}")
                self._view.notify_appended(turn)
            except Exception as exc:
                turn = self._thread.append("brief", f"**(error)** {exc}")
                self._view.notify_appended(turn)
            finally:
                self._brief_btn.disabled = False
                self._brief_btn_label.value = "Brief"
                try:
                    self._brief_btn.update()
                except Exception:
                    pass

        self._page.run_thread(_do)

    def _on_clear_clicked(self, _e: ft.ControlEvent) -> None:
        self._thread.clear()
        self._view.notify_cleared()
        self._view.force_follow()

    # ------------------------------------------------ autoscroll indicator

    def _on_view_following_changed(self, following: bool) -> None:
        """Update the toolbar autoscroll button to reflect follow state."""
        if following:
            self._autoscroll_btn.icon = ft.Icons.VERTICAL_ALIGN_BOTTOM
            self._autoscroll_btn.icon_color = TEAL
            self._autoscroll_btn.tooltip = "Auto-scroll on (following bottom)"
        else:
            self._autoscroll_btn.icon = ft.Icons.PAUSE_CIRCLE_OUTLINE
            self._autoscroll_btn.icon_color = ft.Colors.TERTIARY
            self._autoscroll_btn.tooltip = "Paused — click to resume auto-scroll"
        try:
            self._autoscroll_btn.update()
        except Exception:
            pass

    def _on_autoscroll_clicked(self, _e: ft.ControlEvent) -> None:
        """User clicked the indicator: jump to bottom and re-arm following."""
        self._view.force_follow()
        self._page.run_task(self._view.scroll_to_bottom)

    # ------------------------------------------------ session toggle

    def _on_session_toggle(self, _e: ft.ControlEvent) -> None:
        was_active = self._session_active
        endpoint = "/session/stop" if was_active else "/session/start"

        # Optimistic visual feedback so the user gets immediate response.
        # The daemon broadcasts `meeting_status` over WS the moment the
        # session is actually live (or stopped) — the WS handler picks it up
        # and calls update_status with the real state. Don't poll /health
        # here: the daemon sets session_active a few seconds after returning
        # 200 from /session/start (audio capture + transcribers spin up
        # asynchronously), and an early poll would clobber the optimistic
        # label with stale "Ready".
        self._session_btn.disabled = True
        self._status_text.value = "Stopping…" if was_active else "Starting…"
        self._status_text.color = ft.Colors.TERTIARY
        self._status_icon.color = ft.Colors.TERTIARY
        try:
            self._page.update()
        except Exception:
            pass

        def _do() -> None:
            try:
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}{endpoint}",
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                )
                urllib.request.urlopen(req, timeout=5)
            except Exception:
                pass
            # Re-enable the button immediately; the WS event will deliver the
            # real state when the daemon reaches it.
            self._session_btn.disabled = False
            try:
                self._page.update()
            except Exception:
                pass

        self._page.run_thread(_do)

    # ------------------------------------------------ extract task handler

    def _on_extract_task(self, _e: ft.ControlEvent) -> None:
        self._extract_btn.disabled = True
        self._extract_btn_label.value = "Extracting…"
        try:
            self._extract_btn.update()
        except Exception:
            pass

        def _do() -> None:
            try:
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}/extract-task",
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                urllib.request.urlopen(req, timeout=60).read()
            except Exception:
                pass
            finally:
                self._extract_btn.disabled = False
                self._extract_btn_label.value = "Extract Task"
                try:
                    self._extract_btn.update()
                except Exception:
                    pass

        self._page.run_thread(_do)

    # ------------------------------------------------ tasks polling

    def _start_tasks_polling(self) -> None:
        def _poll() -> None:
            while True:
                self._poll_tasks()
                threading.Event().wait(2)

        self._page.run_thread(_poll)

    def _poll_tasks(self) -> None:
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self._port}/tasks")
            with urllib.request.urlopen(req, timeout=2) as resp:
                data = json.loads(resp.read())
            tasks = data.get("tasks", [])
            current_ids = [t.get("id") for t in self._tasks_panel._tasks]
            new_ids = [t.get("id") for t in tasks]
            if current_ids != new_ids:
                self._tasks_panel.set_tasks(tasks)
        except Exception:
            pass


def _label_for(options: list[PillOption], key: str, default: str) -> str:
    for o in options:
        if o.key == key:
            return o.label
    return default


def _key_for(options: list[PillOption], label: str, default: str) -> str:
    for o in options:
        if o.label == label:
            return o.key
    return default
