"""WebSocket endpoint and broadcast helper."""

from __future__ import annotations

import json
import logging

from aiohttp import web, WSMsgType

from meeting_helper.state import state

logger = logging.getLogger(__name__)


async def ws_handler(request: web.Request) -> web.WebSocketResponse:
    ws = web.WebSocketResponse()
    await ws.prepare(request)

    state.ws_clients.add(ws)
    logger.info("Client connected (total=%d)", len(state.ws_clients))

    # Send current status
    await ws.send_str(json.dumps({"type": "status", "value": state.status}))

    # Send info bar state. Carries the daemon's idea of "is the workspace ready
    # to use feature X" so dependent UIs can hide controls accordingly.
    await ws.send_str(json.dumps(_build_info_message(request.app.get("config"))))

    # Send current meeting info if active
    if state.meeting_info:
        info = state.meeting_info
        await ws.send_str(json.dumps({
            "type": "meeting_status",
            "active": True,
            "app": getattr(info, "app_name", ""),
            "meeting_name": getattr(info, "meeting_name", "") or "",
        }))

    # Send last response for late-joining clients
    if state.last_response:
        await ws.send_str(json.dumps({"type": "done", "full_text": state.last_response}))

    # NOTE: We deliberately do NOT replay state.last_brief on reconnect.
    # An earlier attempt to replay it caused a 30-second flap loop: the GUI
    # disconnected mid-broadcast when the brief's large topic+cards payload
    # arrived, the reconnect handler then re-sent the brief, the GUI died
    # again on it, repeat for 30s. Streaming AI chunks broadcast during that
    # window were silently lost. Live broadcast is sufficient now that stale
    # GUI processes are cleaned up at startup (see flet_gui/app.py).

    # Send current session tasks snapshot
    await ws.send_str(json.dumps({
        "type": "tasks",
        "tasks": list(state.session_tasks),
    }))

    # Send currently attached past conversation, if any
    if state.attached_conversation:
        ac = state.attached_conversation
        await ws.send_str(json.dumps({
            "type": "conversation_attached",
            "session_id": ac.get("session_id"),
            "title": ac.get("title"),
            "repo": ac.get("repo"),
            "chars": ac.get("chars", 0),
            "truncated": ac.get("truncated", False),
            "turn_count": ac.get("turn_count", 0),
        }))

    try:
        async for msg in ws:
            if msg.type in (WSMsgType.CLOSE, WSMsgType.ERROR):
                break
    finally:
        state.ws_clients.discard(ws)
        logger.info("Client disconnected (total=%d)", len(state.ws_clients))

    return ws


# Fields rendered by the GUI conversation-card view + overlay card view.
# Used to slim local-todo records before broadcasting them over the WebSocket.
# Full task records carry body_md, history (full event log), comments,
# mr_links, thread_links, search_tsv, custom_fields — easily 10-50 KB per
# record. ~10 cards in a single frame can exceed the GUI's `websockets` client
# default max-message-size and disconnect it mid-broadcast.
_BROADCAST_CARD_FIELDS = (
    "id", "title", "status", "sprint", "sprint_name", "due", "url",
    "kind", "board_id", "board_name",
)


def slim_card_for_broadcast(card: dict) -> dict:
    """Return a copy of *card* with only the fields the UIs render."""
    return {k: card[k] for k in _BROADCAST_CARD_FIELDS if k in card}


def _build_info_message(config=None) -> dict:
    """Compose the `info` payload, including readiness flags when config is reachable.

    `config` is optional because some legacy callers don't have one in scope;
    we fall back to `get_config()` so the flags are still populated.
    """
    try:
        if config is None:
            from meeting_helper.config import get_config
            config = get_config()
    except Exception:
        config = None
    msg: dict = {
        "type": "info",
        "transcriber": state.transcriber_name,
        "model": state.ai_model,
    }
    if config is not None:
        try:
            msg["local_todo_configured"] = config.local_todo_configured
            msg["provider_configured"] = config.provider_configured
        except Exception:
            pass
    return msg


async def broadcast_info() -> None:
    """Broadcast current info bar state to all clients."""
    await broadcast(_build_info_message())


async def broadcast(message: dict) -> None:
    """Send a JSON message to all connected WebSocket clients."""
    if not state.ws_clients:
        return

    data = json.dumps(message)
    dead = set()

    for ws in list(state.ws_clients):
        try:
            await ws.send_str(data)
        except Exception:
            dead.add(ws)

    state.ws_clients -= dead
