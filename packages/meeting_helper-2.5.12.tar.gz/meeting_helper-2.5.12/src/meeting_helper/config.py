"""Configuration management for Meeting Helper."""

from __future__ import annotations

import functools
import json
import os
import re
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

HOME = Path.home()
DEFAULT_CONFIG_DIR = HOME / ".config" / "meeting-helper"
CONFIG_FILE = DEFAULT_CONFIG_DIR / "config.json"
PID_FILE = HOME / ".meeting-helper.pid"
GUI_PID_FILE = HOME / ".meeting-helper-gui.pid"
MENUBAR_PID_FILE = HOME / ".meeting-helper-menubar.pid"
META_FILE = HOME / ".meeting-helper.meta.json"
LOG_FILE = HOME / ".meeting-helper.log"

STATE_FILE = DEFAULT_CONFIG_DIR / "state.json"
WORKSPACES_DIR = DEFAULT_CONFIG_DIR / "workspaces"
LEGACY_CONFIG_FILE = DEFAULT_CONFIG_DIR / "config.json"
LEGACY_BACKUP = DEFAULT_CONFIG_DIR / "config.json.pre-workspaces.bak"
WORKSPACE_NAME_RE = re.compile(r"^[a-zA-Z0-9_-]{1,40}$")
DEFAULT_WORKSPACE_NAME = "default"

CLAUDE_MODELS = {
    "sonnet": "claude-sonnet-4-6",
    "opus": "claude-opus-4-6",
    "haiku": "claude-haiku-4-5-20251001",
}

GEMINI_MODELS = {
    "flash": "gemini-2.5-flash",
    "pro": "gemini-2.5-pro",
}

DEFAULT_CONFIG: dict[str, Any] = {
    "anthropic_api_key": "",
    "google_api_key": "",
    "deepgram_api_key": "",
    "port": 7891,
    "recordings_dir": str(HOME / "meetings"),
    "repos_workspaces": [],
    "repos": [],
    "knowledge_paths": [],
    "sentence_window": 5,
    "max_history_turns": 5,
    "claude_model": "sonnet",
    "gemini_model": "flash",
    "max_tokens": 2048,
    "transcription_language": "en",
    "silence_timeout": 30,
    "hot_moment_window_minutes": 10.0,
    "setup_complete": False,
    "favorites": [],
    "proactive_answers": False,
    "auto_context_enabled": False,
    "auto_context_interval": 10,
    "ignored_repos": [],      # repo folder names to never load
    "ignored_knowledge": [],  # knowledge folder names to never load
    "preferred_provider": "",        # "" = claude (default), "gemini", "local" = ollama
    "ollama_host": "http://localhost:11434",
    "local_model": "qwen2.5-coder:3b",
    "local_todo_mcp": {
        "type": "stdio",
        "command": "npx",
        "args": ["@local-todo/mcp"],
        "env": {},
        "url": "",
        "headers": {},
    },
    "preferred_transcriber": "",     # "" = auto, "whisper", "deepgram"
    "whisper_host": "",              # "" = local whisper, "http://host:8000" = remote
    "auto_start_record": True,       # auto-detect mic and start session
    "show_menubar_icon": True,
    "menubar_icon": "MH",
}


def validate_workspace_name(name: str) -> None:
    """Raise ValueError if `name` is not a valid workspace name."""
    if not isinstance(name, str) or not WORKSPACE_NAME_RE.match(name):
        raise ValueError(
            f"Invalid workspace name: {name!r}. "
            f"Must match {WORKSPACE_NAME_RE.pattern}."
        )


def workspace_path(name: str) -> Path:
    """Return the JSON path for workspace `name`. Validates the name."""
    validate_workspace_name(name)
    return WORKSPACES_DIR / f"{name}.json"


def load_state() -> dict:
    """Read state.json. Return safe defaults if missing or corrupt."""
    defaults = {"active_workspace": DEFAULT_WORKSPACE_NAME, "workspace_order": []}
    if not STATE_FILE.exists():
        return defaults
    try:
        with open(STATE_FILE) as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return defaults
    if not isinstance(data, dict):
        return defaults
    active = data.get("active_workspace") or DEFAULT_WORKSPACE_NAME
    order = data.get("workspace_order") or []
    if not isinstance(active, str) or not isinstance(order, list):
        return defaults
    return {"active_workspace": active, "workspace_order": [str(n) for n in order]}


def save_state(state: dict) -> None:
    """Atomically write state.json."""
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".json.tmp")
    with open(tmp, "w") as f:
        json.dump(state, f, indent=2)
    os.replace(tmp, STATE_FILE)


def list_workspaces() -> list[str]:
    """Return workspace names in `workspace_order`, with any unlisted files
    appended alphabetically. Skips files whose stem is not a valid workspace name."""
    if not WORKSPACES_DIR.exists():
        return []
    on_disk = set()
    for p in WORKSPACES_DIR.iterdir():
        if p.suffix != ".json":
            continue
        stem = p.stem
        if not WORKSPACE_NAME_RE.match(stem):
            continue
        on_disk.add(stem)
    order = load_state()["workspace_order"]
    ordered = [n for n in order if n in on_disk]
    listed = set(ordered)
    extras = sorted(on_disk - listed)
    return ordered + extras


def migrate_legacy_config() -> None:
    """One-shot migration: legacy config.json -> workspaces/default.json + state.json.

    Idempotent. If `workspaces/` already contains at least one *.json, does nothing.
    Always writes a `.bak` of the legacy file before deleting it.
    """
    WORKSPACES_DIR.mkdir(parents=True, exist_ok=True)
    if any(WORKSPACES_DIR.glob("*.json")):
        return  # already migrated

    default_path = WORKSPACES_DIR / f"{DEFAULT_WORKSPACE_NAME}.json"

    if LEGACY_CONFIG_FILE.exists():
        backup_path = LEGACY_BACKUP
        if backup_path.exists():
            backup_path = LEGACY_BACKUP.with_name(
                LEGACY_BACKUP.name + f"-{int(time.time())}"
            )
        shutil.copy2(LEGACY_CONFIG_FILE, backup_path)
        os.replace(LEGACY_CONFIG_FILE, default_path)
    else:
        with open(default_path, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)

    save_state({
        "active_workspace": DEFAULT_WORKSPACE_NAME,
        "workspace_order": [DEFAULT_WORKSPACE_NAME],
    })


def create_workspace(name: str, copy_from: str | None = None) -> None:
    """Create a new workspace JSON file. Raises ValueError if name invalid or already exists."""
    target = workspace_path(name)
    if target.exists():
        raise ValueError(f"Workspace {name!r} already exists")

    if copy_from:
        src = workspace_path(copy_from)
        if not src.exists():
            raise ValueError(f"Source workspace {copy_from!r} not found")
        shutil.copy2(src, target)
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        data = dict(DEFAULT_CONFIG)
        data["recordings_dir"] = str(HOME / "meetings" / name)
        with open(target, "w") as f:
            json.dump(data, f, indent=2)

    state = load_state()
    if name not in state["workspace_order"]:
        state["workspace_order"].append(name)
        save_state(state)


def delete_workspace(name: str) -> None:
    """Delete a workspace JSON file. Refuses if active or last remaining."""
    state = load_state()
    workspaces = list_workspaces()
    if len(workspaces) <= 1:
        raise ValueError(f"Cannot delete last workspace {name!r}")
    if name == state["active_workspace"]:
        raise ValueError(f"Cannot delete active workspace {name!r}")

    target = workspace_path(name)
    if target.exists():
        target.unlink()
    state["workspace_order"] = [n for n in state["workspace_order"] if n != name]
    save_state(state)


def rename_workspace(old: str, new: str) -> None:
    """Rename a workspace. Validates `new`, refuses if target exists."""
    src = workspace_path(old)
    dst = workspace_path(new)
    if not src.exists():
        raise ValueError(f"Workspace {old!r} not found")
    if dst.exists():
        raise ValueError(f"Workspace {new!r} already exists")

    os.replace(src, dst)
    state = load_state()
    state["workspace_order"] = [
        new if n == old else n for n in state["workspace_order"]
    ]
    if state["active_workspace"] == old:
        state["active_workspace"] = new
    save_state(state)


def set_active_workspace(name: str) -> None:
    """Update state.json to mark `name` as the active workspace.

    Also clears the cached global Config so the next get_config() reloads.
    """
    if not workspace_path(name).exists():
        raise ValueError(f"Workspace {name!r} not found")
    state = load_state()
    state["active_workspace"] = name
    if name not in state["workspace_order"]:
        state["workspace_order"].append(name)
    save_state(state)
    global _config
    _config = None


class Config:
    """JSON-backed configuration manager — backed by a per-workspace file."""

    def __init__(
        self,
        config_path: Path | None = None,
        *,
        workspace: str | None = None,
    ):
        # Ensure migration has run and a workspace exists on disk
        migrate_legacy_config()
        if not any(WORKSPACES_DIR.glob("*.json")):
            # Self-heal: no workspaces -> create default
            default_path = WORKSPACES_DIR / f"{DEFAULT_WORKSPACE_NAME}.json"
            default_path.parent.mkdir(parents=True, exist_ok=True)
            with open(default_path, "w") as f:
                json.dump(DEFAULT_CONFIG, f, indent=2)
            save_state({
                "active_workspace": DEFAULT_WORKSPACE_NAME,
                "workspace_order": [DEFAULT_WORKSPACE_NAME],
            })

        if config_path is not None:
            self.config_path = config_path
        elif workspace is not None:
            self.config_path = workspace_path(workspace)
        else:
            active = load_state()["active_workspace"]
            target = workspace_path(active)
            if not target.exists():
                # Active workspace file missing -> fall back to default
                try:
                    import logging
                    logging.getLogger(__name__).warning(
                        f"Active workspace {active!r} missing; falling back to default"
                    )
                except Exception:
                    pass
                target = workspace_path(DEFAULT_WORKSPACE_NAME)
                save_state({
                    "active_workspace": DEFAULT_WORKSPACE_NAME,
                    "workspace_order": load_state()["workspace_order"] or [DEFAULT_WORKSPACE_NAME],
                })
            self.config_path = target

        self._data: dict[str, Any] = {}
        self.load()

    def load(self) -> None:
        if self.config_path.exists():
            try:
                with open(self.config_path) as f:
                    self._data = json.load(f)
            except (json.JSONDecodeError, IOError):
                self._data = {}
        else:
            self._data = {}
        # Migrate single-value fields to lists
        if "repos_workspace" in self._data and "repos_workspaces" not in self._data:
            old = self._data.pop("repos_workspace", "")
            self._data["repos_workspaces"] = [old] if old else []
        if "knowledge_path" in self._data and "knowledge_paths" not in self._data:
            old = self._data.pop("knowledge_path", "")
            self._data["knowledge_paths"] = [old] if old else []
        # Migrate legacy flat-list MCP command to structured shape before defaults kick in
        if "local_todo_mcp" not in self._data and "local_todo_mcp_command" in self._data:
            legacy = self._data.pop("local_todo_mcp_command")
            if isinstance(legacy, list) and legacy:
                self._data["local_todo_mcp"] = {
                    "type": "stdio",
                    "command": legacy[0], "args": list(legacy[1:]), "env": {},
                    "url": "", "headers": {},
                }
            elif isinstance(legacy, str) and legacy.strip():
                parts = legacy.strip().split()
                self._data["local_todo_mcp"] = {
                    "type": "stdio",
                    "command": parts[0], "args": parts[1:], "env": {},
                    "url": "", "headers": {},
                }
        for key, value in DEFAULT_CONFIG.items():
            if key not in self._data:
                self._data[key] = value

    def save(self) -> None:
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, "w") as f:
            json.dump(self._data, f, indent=2)

    @property
    def anthropic_api_key(self) -> str:
        return (self._data.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", "")).strip()

    @anthropic_api_key.setter
    def anthropic_api_key(self, value: str) -> None:
        self._data["anthropic_api_key"] = value

    @property
    def google_api_key(self) -> str:
        return (self._data.get("google_api_key") or os.environ.get("GOOGLE_API_KEY", "")).strip()

    @google_api_key.setter
    def google_api_key(self, value: str) -> None:
        self._data["google_api_key"] = value

    @property
    def deepgram_api_key(self) -> str:
        return self._data.get("deepgram_api_key", "").strip()

    @deepgram_api_key.setter
    def deepgram_api_key(self, value: str) -> None:
        self._data["deepgram_api_key"] = value

    @property
    def port(self) -> int:
        return int(self._data.get("port", 7891))

    @port.setter
    def port(self, value: int) -> None:
        self._data["port"] = value

    @property
    def recordings_dir(self) -> Path:
        return Path(self._data["recordings_dir"]).expanduser()

    @recordings_dir.setter
    def recordings_dir(self, value: Path | str) -> None:
        self._data["recordings_dir"] = str(value)

    @property
    def repos_workspaces(self) -> list[str]:
        return list(self._data.get("repos_workspaces", []))

    @repos_workspaces.setter
    def repos_workspaces(self, value: list[str]) -> None:
        self._data["repos_workspaces"] = value

    @property
    def repos_workspace(self) -> str:
        """Compat: first workspace or empty string."""
        ws = self._data.get("repos_workspaces", [])
        return ws[0] if ws else ""

    @repos_workspace.setter
    def repos_workspace(self, value: str) -> None:
        """Compat: set as single-element list."""
        self._data["repos_workspaces"] = [value] if value else []

    def is_favorite(self, filename: str) -> bool:
        return filename in self._data.get("favorites", [])

    def add_favorite(self, filename: str) -> None:
        favs = self._data.setdefault("favorites", [])
        if filename not in favs:
            favs.append(filename)
        self.save()

    def remove_favorite(self, filename: str) -> None:
        favs = self._data.get("favorites", [])
        if filename in favs:
            favs.remove(filename)
        self.save()

    @property
    def repos(self) -> list[str]:
        return self._data.get("repos", [])

    @repos.setter
    def repos(self, value: list[str]) -> None:
        self._data["repos"] = value

    @property
    def knowledge_paths(self) -> list[str]:
        return list(self._data.get("knowledge_paths", []))

    @knowledge_paths.setter
    def knowledge_paths(self, value: list[str]) -> None:
        self._data["knowledge_paths"] = value

    @property
    def knowledge_path(self) -> str:
        """Compat: first knowledge path or empty string."""
        paths = self._data.get("knowledge_paths", [])
        return paths[0] if paths else ""

    @knowledge_path.setter
    def knowledge_path(self, value: str) -> None:
        """Compat: set as single-element list."""
        self._data["knowledge_paths"] = [value] if value else []

    @property
    def sentence_window(self) -> int:
        return int(self._data.get("sentence_window", 5))

    @sentence_window.setter
    def sentence_window(self, value: int) -> None:
        self._data["sentence_window"] = value

    @property
    def max_history_turns(self) -> int:
        return int(self._data.get("max_history_turns", 5))

    @max_history_turns.setter
    def max_history_turns(self, value: int) -> None:
        self._data["max_history_turns"] = value

    @property
    def claude_model(self) -> str:
        alias = self._data.get("claude_model", "sonnet")
        return CLAUDE_MODELS.get(alias, alias)

    @claude_model.setter
    def claude_model(self, value: str) -> None:
        self._data["claude_model"] = value

    @property
    def gemini_model(self) -> str:
        alias = self._data.get("gemini_model", "flash")
        return GEMINI_MODELS.get(alias, alias)

    @gemini_model.setter
    def gemini_model(self, value: str) -> None:
        self._data["gemini_model"] = value

    @property
    def max_tokens(self) -> int:
        return int(self._data.get("max_tokens", 2048))

    @max_tokens.setter
    def max_tokens(self, value: int) -> None:
        self._data["max_tokens"] = value

    @property
    def transcription_language(self) -> str:
        return self._data.get("transcription_language", "en")

    @transcription_language.setter
    def transcription_language(self, value: str) -> None:
        self._data["transcription_language"] = value

    @property
    def silence_timeout(self) -> int:
        return int(self._data.get("silence_timeout", 30))

    @silence_timeout.setter
    def silence_timeout(self, value: int) -> None:
        self._data["silence_timeout"] = value

    @property
    def hot_moment_window_minutes(self) -> float:
        return float(self._data.get("hot_moment_window_minutes", 10.0))

    @hot_moment_window_minutes.setter
    def hot_moment_window_minutes(self, value: float) -> None:
        self._data["hot_moment_window_minutes"] = float(value)

    @property
    def proactive_answers(self) -> bool:
        return bool(self._data.get("proactive_answers", False))

    @proactive_answers.setter
    def proactive_answers(self, value: bool) -> None:
        self._data["proactive_answers"] = value

    @property
    def ignored_repos(self) -> list[str]:
        return list(self._data.get("ignored_repos", []))

    @ignored_repos.setter
    def ignored_repos(self, value: list[str]) -> None:
        self._data["ignored_repos"] = value

    @property
    def ignored_knowledge(self) -> list[str]:
        return list(self._data.get("ignored_knowledge", []))

    @ignored_knowledge.setter
    def ignored_knowledge(self, value: list[str]) -> None:
        self._data["ignored_knowledge"] = value

    @property
    def preferred_provider(self) -> str:
        return self._data.get("preferred_provider", "").strip()

    @preferred_provider.setter
    def preferred_provider(self, value: str) -> None:
        self._data["preferred_provider"] = value

    @property
    def ollama_host(self) -> str:
        return self._data.get("ollama_host", "http://localhost:11434").strip()

    @ollama_host.setter
    def ollama_host(self, value: str) -> None:
        self._data["ollama_host"] = value

    @property
    def local_model(self) -> str:
        return self._data.get("local_model", "qwen2.5-coder:3b").strip()

    @local_model.setter
    def local_model(self, value: str) -> None:
        self._data["local_model"] = value

    @property
    def local_todo_mcp(self) -> dict:
        """Structured MCP config:
            {"type": "stdio", "command": str, "args": list[str], "env": dict, "url": "", "headers": {}}
            {"type": "http",  "command": "", "args": [], "env": {}, "url": str, "headers": dict}
        """
        cfg = self._data.get("local_todo_mcp")
        if cfg is None:
            # Migrate from legacy flat-list shape if present
            legacy = self._data.get("local_todo_mcp_command")
            if isinstance(legacy, list) and legacy:
                cfg = {"type": "stdio", "command": legacy[0], "args": list(legacy[1:]),
                       "env": {}, "url": "", "headers": {}}
            elif isinstance(legacy, str) and legacy.strip():
                parts = legacy.strip().split()
                cfg = {"type": "stdio", "command": parts[0], "args": parts[1:],
                       "env": {}, "url": "", "headers": {}}
            else:
                cfg = {"type": "stdio", "command": "npx", "args": ["@local-todo/mcp"],
                       "env": {}, "url": "", "headers": {}}

        # Detect type if missing — http if url is set, else stdio
        kind = (cfg.get("type") or "").strip().lower()
        if kind not in ("stdio", "http"):
            kind = "http" if (cfg.get("url") or "").strip() else "stdio"

        # Normalize all fields defensively
        command = str(cfg.get("command", "")).strip()
        args = cfg.get("args", []) or []
        if isinstance(args, str):
            args = args.split()
        env = cfg.get("env", {}) or {}
        if not isinstance(env, dict):
            env = {}
        url = str(cfg.get("url", "")).strip()
        headers = cfg.get("headers", {}) or {}
        if not isinstance(headers, dict):
            headers = {}

        return {
            "type": kind,
            "command": command,
            "args": list(args),
            "env": dict(env),
            "url": url,
            "headers": dict(headers),
        }

    @local_todo_mcp.setter
    def local_todo_mcp(self, value: dict) -> None:
        if not isinstance(value, dict):
            raise ValueError("local_todo_mcp must be a dict")
        kind = (value.get("type") or "stdio").strip().lower()
        if kind not in ("stdio", "http"):
            kind = "stdio"
        self._data["local_todo_mcp"] = {
            "type": kind,
            "command": str(value.get("command", "")).strip(),
            "args": list(value.get("args", []) or []),
            "env": dict(value.get("env", {}) or {}),
            "url": str(value.get("url", "")).strip(),
            "headers": dict(value.get("headers", {}) or {}),
        }
        # Drop the legacy key on first save with new shape
        self._data.pop("local_todo_mcp_command", None)

    @property
    def local_todo_mcp_command(self) -> list[str]:
        """Back-compat: flat list form, only valid for stdio."""
        cfg = self.local_todo_mcp
        if cfg.get("type") != "stdio" or not cfg.get("command"):
            return []
        return [cfg["command"], *cfg["args"]]

    @property
    def preferred_transcriber(self) -> str:
        return self._data.get("preferred_transcriber", "").strip()

    @preferred_transcriber.setter
    def preferred_transcriber(self, value: str) -> None:
        self._data["preferred_transcriber"] = value

    @property
    def whisper_host(self) -> str:
        return self._data.get("whisper_host", "").strip()

    @whisper_host.setter
    def whisper_host(self, value: str) -> None:
        self._data["whisper_host"] = value

    @property
    def auto_start_record(self) -> bool:
        return bool(self._data.get("auto_start_record", True))

    @auto_start_record.setter
    def auto_start_record(self, value: bool) -> None:
        self._data["auto_start_record"] = value

    @property
    def show_menubar_icon(self) -> bool:
        return bool(self._data.get("show_menubar_icon", True))

    @show_menubar_icon.setter
    def show_menubar_icon(self, value: bool) -> None:
        self._data["show_menubar_icon"] = value

    @property
    def menubar_icon(self) -> str:
        return self._data.get("menubar_icon", "MH")

    @menubar_icon.setter
    def menubar_icon(self, value: str) -> None:
        self._data["menubar_icon"] = value

    @property
    def auto_context_enabled(self) -> bool:
        return bool(self._data.get("auto_context_enabled", True))

    @auto_context_enabled.setter
    def auto_context_enabled(self, value: bool) -> None:
        self._data["auto_context_enabled"] = value

    @property
    def auto_context_interval(self) -> int:
        return int(self._data.get("auto_context_interval", 60))

    @auto_context_interval.setter
    def auto_context_interval(self, value: int) -> None:
        self._data["auto_context_interval"] = value

    @property
    def local_todo_configured(self) -> bool:
        """True iff the workspace has an MCP transport set up.

        Stdio: requires a `command`. HTTP: requires a `url`. Used by the GUI
        to decide whether to surface the Brief button (which is meaningless
        without a task tracker behind it).
        """
        cfg = self.local_todo_mcp
        if (cfg.get("type") or "").strip().lower() == "http":
            return bool((cfg.get("url") or "").strip())
        return bool((cfg.get("command") or "").strip())

    @property
    def provider_configured(self) -> bool:
        """True iff at least one AI provider has the credentials/runtime to run.

        Claude requires `anthropic_api_key`, Gemini requires `google_api_key`.
        Local (Ollama) has no key — opting in via `preferred_provider == "local"`
        IS the configuration. Used by the GUI to hide the provider/model picker
        when there is nothing to pick between.
        """
        if self.anthropic_api_key.strip():
            return True
        if self.google_api_key.strip():
            return True
        if self.preferred_provider.strip().lower() == "local":
            return True
        return False

    @property
    def setup_complete(self) -> bool:
        return self._data.get("setup_complete", False)

    @setup_complete.setter
    def setup_complete(self, value: bool) -> None:
        self._data["setup_complete"] = value

    def to_app_config(self) -> AppConfig:
        """Build runtime AppConfig — starts with NO workspace context.

        User selectively loads repos/knowledge via the Dashboard context
        selector during a meeting.
        """
        from meeting_helper.ai.prompts import build_system_prompt

        system_prompt = build_system_prompt("")

        return AppConfig(
            anthropic_api_key=self.anthropic_api_key,
            deepgram_api_key=self.deepgram_api_key,
            port=self.port,
            recordings_dir=self.recordings_dir,
            repos_workspaces=self.repos_workspaces,
            repos_workspace=self.repos_workspace,
            repos=list(self.repos),
            knowledge_paths=self.knowledge_paths,
            knowledge_path=self.knowledge_path,
            sentence_window=self.sentence_window,
            max_history_turns=self.max_history_turns,
            claude_model=self.claude_model,
            claude_model_alias=self._data.get("claude_model", "sonnet"),
            gemini_model=self.gemini_model,
            gemini_model_alias=self._data.get("gemini_model", "flash"),
            google_api_key=self.google_api_key,
            max_tokens=self.max_tokens,
            transcription_language=self.transcription_language,
            silence_timeout=self.silence_timeout,
            proactive_answers=self.proactive_answers,
            auto_context_enabled=self.auto_context_enabled,
            auto_context_interval=self.auto_context_interval,
            ignored_repos=self.ignored_repos,
            ignored_knowledge=self.ignored_knowledge,
            preferred_provider=self.preferred_provider,
            ollama_host=self.ollama_host,
            local_model=self.local_model,
            preferred_transcriber=self.preferred_transcriber,
            whisper_host=self.whisper_host,
            auto_start_record=self.auto_start_record,
            system_prompt=system_prompt,
            local_todo_mcp=dict(self.local_todo_mcp),
        )

    def __getitem__(self, key: str) -> Any:
        return self._data.get(key, DEFAULT_CONFIG.get(key))

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[key] = value


@dataclass
class AppConfig:
    """Immutable runtime config used by the daemon."""

    anthropic_api_key: str = ""
    google_api_key: str = ""
    deepgram_api_key: str = ""
    port: int = 7891
    recordings_dir: Path = field(default_factory=lambda: Path.home() / "meetings")
    repos_workspaces: list[str] = field(default_factory=list)
    repos_workspace: str = ""  # compat: first element
    repos: list[str] = field(default_factory=list)
    knowledge_paths: list[str] = field(default_factory=list)
    knowledge_path: str = ""  # compat: first element
    sentence_window: int = 5
    max_history_turns: int = 5
    claude_model: str = "claude-sonnet-4-6"
    claude_model_alias: str = "sonnet"
    gemini_model: str = "gemini-2.5-flash"
    gemini_model_alias: str = "flash"
    max_tokens: int = 2048
    transcription_language: str = "en"
    silence_timeout: int = 30
    hot_moment_window_minutes: float = 10.0
    proactive_answers: bool = False
    auto_context_enabled: bool = True
    auto_context_interval: int = 10
    ignored_repos: list[str] = field(default_factory=list)
    ignored_knowledge: list[str] = field(default_factory=list)
    preferred_provider: str = ""
    ollama_host: str = "http://localhost:11434"
    local_model: str = "qwen2.5-coder:3b"
    preferred_transcriber: str = ""
    whisper_host: str = ""
    auto_start_record: bool = True
    system_prompt: str = ""
    local_todo_mcp: dict = field(default_factory=lambda: {
        "type": "stdio", "command": "", "args": [], "env": {},
        "url": "", "headers": {},
    })

    @property
    def local_todo_mcp_command(self) -> list[str]:
        """Back-compat: flat list form, only valid for stdio."""
        cfg = self.local_todo_mcp or {}
        if cfg.get("type", "stdio") != "stdio" or not cfg.get("command"):
            return []
        return [cfg["command"], *list(cfg.get("args", []) or [])]

    # The /provider GET handler reads these from whichever config the daemon
    # holds in `request.app["config"]` — which is an AppConfig at runtime,
    # not a Config. Keep the two surfaces in sync so the readiness flags
    # work without per-call attribute checks.
    @property
    def local_todo_configured(self) -> bool:
        cfg = self.local_todo_mcp or {}
        if (cfg.get("type") or "").strip().lower() == "http":
            return bool((cfg.get("url") or "").strip())
        return bool((cfg.get("command") or "").strip())

    @property
    def provider_configured(self) -> bool:
        if (self.anthropic_api_key or "").strip():
            return True
        if (self.google_api_key or "").strip():
            return True
        if (self.preferred_provider or "").strip().lower() == "local":
            return True
        return False


# Global config instance (lazy loaded)
_config: Config | None = None


def get_config(reload: bool = False, workspace: str | None = None) -> Config:
    """Get the cached active-workspace Config, OR a fresh peek for `workspace`.

    - No `workspace` arg: returns the cached global, loading it on first call.
    - With `workspace`: ALWAYS returns a fresh Config for that workspace
      (does NOT replace the cached global). Use this for read-only peeks.
    """
    global _config
    if workspace is not None:
        return Config(workspace=workspace)
    if _config is None:
        _config = Config()
    elif reload:
        _config.load()
    return _config


def require_setup(f):
    """Decorator: ensures config directories exist."""
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        config = get_config()
        config.recordings_dir.mkdir(parents=True, exist_ok=True)
        return f(*args, **kwargs)
    return wrapper
