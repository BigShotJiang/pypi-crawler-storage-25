"""Shared workspace-switch helpers used by the GUI and the menu bar.

Switching a workspace is a coordinated dance:
  1. Verify no active recording (block if there is).
  2. Tell the running daemon to shut down.
  3. Wait for its PID file to clear.
  4. Update state.json.
  5. Spawn a new daemon (caller-supplied `spawn` callable).

The caller controls daemon spawning so the GUI process and menu bar process
can use their existing CLI-discovery logic.
"""

from __future__ import annotations

import json
import os
import signal
import threading
import time
import urllib.request
from dataclasses import dataclass
from typing import Callable

from meeting_helper.config import (
    PID_FILE,
    get_config,
    load_state,
    set_active_workspace,
    workspace_path,
)


SOFT_SHUTDOWN_TIMEOUT_S = 6.0   # wait for SIGTERM-triggered clean exit
HARD_KILL_TIMEOUT_S = 3.0       # additional wait after SIGKILL
_switch_lock = threading.Lock()


@dataclass
class SwitchResult:
    ok: bool
    error: str = ""
    transient: bool = False  # True for "try again later" cases (lock held, recording active)


def _get_health() -> dict | None:
    """Return /health JSON, or None if the daemon isn't responding."""
    try:
        port = get_config().port
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=1) as resp:
            return json.loads(resp.read().decode())
    except Exception:
        return None


def _post_shutdown() -> bool:
    """POST /shutdown to the active daemon. Return True on success."""
    try:
        port = get_config().port
        req = urllib.request.Request(
            f"http://127.0.0.1:{port}/shutdown",
            data=b"{}",
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=2)
        return True
    except Exception:
        return False


def _read_pid() -> int | None:
    """Return the PID from PID_FILE, or None if missing/invalid."""
    try:
        return int(PID_FILE.read_text().strip())
    except (OSError, ValueError):
        return None


def _is_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _wait_for_pid_clear(timeout: float) -> bool:
    """Poll until PID_FILE disappears or its PID is no longer alive."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not PID_FILE.exists():
            return True
        pid = _read_pid()
        if pid is None or not _is_alive(pid):
            return True
        time.sleep(0.1)
    return False


def _stop_current_daemon() -> bool:
    """Soft-kill via /shutdown (SIGTERM). If still alive after timeout, SIGKILL.
    Returns True once the daemon is gone (PID file cleared OR process dead).
    """
    pid = _read_pid()
    _post_shutdown()
    if _wait_for_pid_clear(SOFT_SHUTDOWN_TIMEOUT_S):
        return True

    # Soft kill failed — escalate to SIGKILL
    if pid is None:
        pid = _read_pid()
    if pid is not None and _is_alive(pid):
        try:
            os.kill(pid, signal.SIGKILL)
        except (OSError, ProcessLookupError):
            pass
    if _wait_for_pid_clear(HARD_KILL_TIMEOUT_S):
        # Stale PID file may linger if SIGKILL skipped the atexit cleanup
        try:
            PID_FILE.unlink(missing_ok=True)
        except OSError:
            pass
        return True
    return False


def switch_workspace(name: str, *, spawn: Callable[[], None]) -> SwitchResult:
    """Switch to workspace `name`. Returns SwitchResult.

    Concurrent calls are serialized — a second call that arrives while a
    switch is in flight returns immediately with an error.

    Args:
      name: target workspace name (must exist on disk).
      spawn: callable that starts a fresh daemon (typically a subprocess.Popen
             of `meeting-helper start`).
    """
    if not _switch_lock.acquire(blocking=False):
        return SwitchResult(
            ok=False,
            transient=True,
            error="Another workspace switch is already in progress.",
        )
    try:
        if not workspace_path(name).exists():
            return SwitchResult(ok=False, error=f"Workspace {name!r} not found")

        health = _get_health()
        if health and health.get("session_active"):
            return SwitchResult(
                ok=False,
                transient=True,
                error="A recording is in progress. Stop the current recording before switching workspaces.",
            )

        if health is not None:
            if not _stop_current_daemon():
                return SwitchResult(
                    ok=False,
                    error="Current daemon would not stop, even after force-kill. Try again.",
                )

        set_active_workspace(name)
        try:
            spawn()
        except Exception as e:
            return SwitchResult(ok=False, error=f"Failed to spawn daemon: {e}")
        return SwitchResult(ok=True)
    finally:
        _switch_lock.release()
