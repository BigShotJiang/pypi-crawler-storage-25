"""LiveTranscriptWriter — append-only transcript file with timestamps + role labels."""

from __future__ import annotations

import threading
from pathlib import Path

from meeting_helper.buffer import SentenceBuffer
from meeting_helper.live_transcript import LiveTranscriptWriter


def test_appends_lines_with_mm_ss_timestamp(tmp_path: Path):
    path = tmp_path / "x.live.txt"

    # Fake clock: one value per append() call.
    times = iter([112.5, 115.0, 121.9])
    writer = LiveTranscriptWriter(path, t0=100.0, clock=lambda: next(times))
    writer.append("SELF", "Let's start with the deploy plan.")
    writer.append("OTHER", "I pushed the migration last night.")
    writer.append("SELF", "Did the staging tests pass?")
    writer.close()

    assert path.read_text() == (
        "[00:12] SELF: Let's start with the deploy plan.\n"
        "[00:15] OTHER: I pushed the migration last night.\n"
        "[00:21] SELF: Did the staging tests pass?\n"
    )


def test_uses_h_mm_ss_format_after_one_hour(tmp_path: Path):
    path = tmp_path / "x.live.txt"
    writer = LiveTranscriptWriter(path, t0=0.0, clock=lambda: 3725.0)  # 1h 02m 05s
    writer.append("SELF", "Long meeting.")
    writer.close()

    assert path.read_text() == "[1:02:05] SELF: Long meeting.\n"


def test_empty_or_whitespace_text_is_dropped(tmp_path: Path):
    path = tmp_path / "x.live.txt"
    times = iter([0.0, 1.0, 2.0])
    writer = LiveTranscriptWriter(path, t0=0.0, clock=lambda: next(times))
    writer.append("SELF", "")
    writer.append("OTHER", "   ")
    writer.close()

    assert path.read_text() == ""


def test_append_after_close_is_noop(tmp_path: Path):
    path = tmp_path / "x.live.txt"
    times = iter([0.0, 1.0])
    writer = LiveTranscriptWriter(path, t0=0.0, clock=lambda: next(times))
    writer.close()
    writer.append("SELF", "ignored")  # must not raise

    assert path.read_text() == ""


def test_negative_elapsed_clamped_to_zero(tmp_path: Path):
    """Clock skew (clock() < t0) shouldn't produce a negative timestamp."""
    path = tmp_path / "x.live.txt"
    writer = LiveTranscriptWriter(path, t0=100.0, clock=lambda: 50.0)
    writer.append("SELF", "out of order")
    writer.close()

    assert path.read_text() == "[00:00] SELF: out of order\n"


def test_concurrent_appends_from_two_threads_serialize(tmp_path: Path):
    """SELF and OTHER transcribers fire callbacks from different threads —
    every line must land intact (not interleaved mid-line)."""
    path = tmp_path / "x.live.txt"
    # Stable elapsed=0 — focus on line atomicity, not timestamps.
    writer = LiveTranscriptWriter(path, t0=0.0, clock=lambda: 0.0)

    N = 200

    def push(role: str) -> None:
        for i in range(N):
            writer.append(role, f"{role}-line-{i}")

    t1 = threading.Thread(target=push, args=("SELF",))
    t2 = threading.Thread(target=push, args=("OTHER",))
    t1.start(); t2.start(); t1.join(); t2.join()
    writer.close()

    lines = path.read_text().splitlines()
    assert len(lines) == 2 * N
    # Every line must be well-formed — never split or merged.
    self_lines = [l for l in lines if "SELF" in l]
    other_lines = [l for l in lines if "OTHER" in l]
    assert len(self_lines) == N
    assert len(other_lines) == N
    # Per-role ordering is preserved (each thread is sequential).
    assert self_lines == [f"[00:00] SELF: SELF-line-{i}" for i in range(N)]
    assert other_lines == [f"[00:00] OTHER: OTHER-line-{i}" for i in range(N)]


def test_listener_wiring_writes_through_sentence_buffer(tmp_path: Path):
    """Same listener pattern used in MeetingSession: SentenceBuffer.append_final
    fans out to a registered callback that calls writer.append(role, sentence)."""
    path = tmp_path / "x.live.txt"
    times = iter([5.0, 10.0])
    writer = LiveTranscriptWriter(path, t0=0.0, clock=lambda: next(times))

    self_buf = SentenceBuffer(role="self")
    other_buf = SentenceBuffer(role="other")
    self_listener = lambda s: writer.append("SELF", s)
    other_listener = lambda s: writer.append("OTHER", s)
    self_buf.add_sentence_listener(self_listener)
    other_buf.add_sentence_listener(other_listener)

    self_buf.append_final("hello")
    other_buf.append_final("hi back")

    self_buf.remove_sentence_listener(self_listener)
    other_buf.remove_sentence_listener(other_listener)
    writer.close()

    # Removed listeners stop firing.
    self_buf.append_final("after-remove")

    assert path.read_text() == (
        "[00:05] SELF: hello\n"
        "[00:10] OTHER: hi back\n"
    )
