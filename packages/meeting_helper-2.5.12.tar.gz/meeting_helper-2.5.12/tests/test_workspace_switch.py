"""Tests for the shared workspace switch utility."""

from __future__ import annotations

import json
from unittest.mock import patch, MagicMock

import pytest

from meeting_helper import workspace_switch
from meeting_helper import config as config_mod


@pytest.fixture
def workspaces(tmp_path, monkeypatch):
    ws_dir = tmp_path / "workspaces"
    ws_dir.mkdir()
    for n in ["default", "work"]:
        (ws_dir / f"{n}.json").write_text(json.dumps({"port": 7891}))
    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", ws_dir)
    monkeypatch.setattr(config_mod, "STATE_FILE", tmp_path / "state.json")
    monkeypatch.setattr(config_mod, "LEGACY_CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr(config_mod, "LEGACY_BACKUP", tmp_path / "config.json.pre-workspaces.bak")
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default", "work"]})
    config_mod._config = None
    return tmp_path


def test_switch_blocks_when_session_active(workspaces):
    with patch.object(workspace_switch, "_get_health", return_value={"session_active": True}):
        result = workspace_switch.switch_workspace("work", spawn=lambda: None)
    assert result.ok is False
    assert "recording" in result.error.lower()
    assert config_mod.load_state()["active_workspace"] == "default"


def test_switch_blocks_when_target_missing(workspaces):
    with patch.object(workspace_switch, "_get_health", return_value={"session_active": False}):
        result = workspace_switch.switch_workspace("nonexistent", spawn=lambda: None)
    assert result.ok is False
    assert "not found" in result.error.lower()


def test_switch_happy_path(workspaces):
    spawn_called = MagicMock()
    with patch.object(workspace_switch, "_get_health", return_value={"session_active": False}), \
         patch.object(workspace_switch, "_stop_current_daemon", return_value=True):
        result = workspace_switch.switch_workspace("work", spawn=spawn_called)

    assert result.ok is True
    assert config_mod.load_state()["active_workspace"] == "work"
    spawn_called.assert_called_once()


def test_switch_aborts_if_pid_does_not_clear(workspaces):
    spawn_called = MagicMock()
    with patch.object(workspace_switch, "_get_health", return_value={"session_active": False}), \
         patch.object(workspace_switch, "_stop_current_daemon", return_value=False):
        result = workspace_switch.switch_workspace("work", spawn=spawn_called)

    assert result.ok is False
    assert "would not stop" in result.error.lower()
    spawn_called.assert_not_called()
    assert config_mod.load_state()["active_workspace"] == "default"


def test_switch_skips_shutdown_if_daemon_not_running(workspaces):
    spawn_called = MagicMock()
    with patch.object(workspace_switch, "_get_health", return_value=None), \
         patch.object(workspace_switch, "_stop_current_daemon") as stop_call:
        result = workspace_switch.switch_workspace("work", spawn=spawn_called)

    assert result.ok is True
    assert config_mod.load_state()["active_workspace"] == "work"
    spawn_called.assert_called_once()
    stop_call.assert_not_called()


def test_stop_current_daemon_escalates_to_sigkill(workspaces, monkeypatch):
    """When SIGTERM doesn't clean up in soft window, _stop_current_daemon SIGKILLs."""
    pid_file = workspaces / "fake.pid"
    pid_file.write_text("99999")  # bogus PID
    monkeypatch.setattr(workspace_switch, "PID_FILE", pid_file)
    monkeypatch.setattr(workspace_switch, "SOFT_SHUTDOWN_TIMEOUT_S", 0.1)
    monkeypatch.setattr(workspace_switch, "HARD_KILL_TIMEOUT_S", 0.1)
    kills = []
    monkeypatch.setattr(workspace_switch, "_post_shutdown", lambda: True)
    monkeypatch.setattr(workspace_switch, "_is_alive", lambda pid: False)  # process never alive
    monkeypatch.setattr(
        workspace_switch.os, "kill",
        lambda pid, sig: kills.append((pid, sig)),
    )

    # _is_alive=False means _wait_for_pid_clear returns True on first poll;
    # soft path succeeds, no SIGKILL needed.
    assert workspace_switch._stop_current_daemon() is True
    assert kills == []  # never escalated
