"""Tests for `_format_cards_markdown` — the cards block in the system prompt."""

from meeting_helper.ai.client import _format_cards_markdown


def test_thin_card_renders_title_and_meta():
    cards = [
        {
            "id": "110",
            "title": "Status remapper",
            "status": "done",
            "priority": "medium",
        }
    ]
    out = _format_cards_markdown(cards)
    assert "[110]" in out
    assert "Status remapper" in out
    assert "done" in out
    assert "P:medium" in out


def test_hydrated_card_includes_body_and_comments():
    cards = [
        {
            "id": "110",
            "title": "Status remapper",
            "status": "done",
            "body_md": "The remapper used to silently drop numeric severities. Fixed by adding type coercion.",
            "comments": [
                {
                    "id": "c1",
                    "body_md": "PR merged. Backfill scheduled for tomorrow.",
                    "created_at": "2026-05-01T10:00:00Z",
                    "author_user_id": "alice",
                },
                {
                    "id": "c2",
                    "body_md": "Initial investigation: numeric values from vendor.",
                    "created_at": "2026-04-30T14:00:00Z",
                    "author_user_id": "bob",
                },
            ],
        }
    ]
    out = _format_cards_markdown(cards)
    assert "Body:" in out
    assert "silently drop numeric severities" in out
    assert "Recent comments" in out
    assert "PR merged" in out
    assert "Initial investigation" in out


def test_comments_sorted_most_recent_first():
    cards = [
        {
            "id": "1",
            "title": "X",
            "comments": [
                {"id": "old", "body_md": "OLDER", "created_at": "2026-01-01T00:00:00Z"},
                {"id": "new", "body_md": "NEWER", "created_at": "2026-05-01T00:00:00Z"},
            ],
        }
    ]
    out = _format_cards_markdown(cards)
    # NEWER should appear before OLDER in the rendered text
    assert out.index("NEWER") < out.index("OLDER")


def test_long_body_is_truncated():
    long_body = "lorem ipsum " * 500
    cards = [{"id": "1", "title": "X", "body_md": long_body}]
    out = _format_cards_markdown(cards)
    # Body section is present but capped — the full repeated phrase wouldn't fit
    assert "Body:" in out
    assert len(out) < len(long_body)  # truncated
    assert "…" in out


def test_no_comments_section_when_none():
    cards = [{"id": "1", "title": "X", "body_md": "Just a body."}]
    out = _format_cards_markdown(cards)
    assert "Body:" in out
    assert "Recent comments" not in out


def test_empty_cards_returns_empty_string():
    assert _format_cards_markdown([]) == ""


def test_linked_docs_listed_when_present():
    cards = [
        {
            "id": "1",
            "title": "X",
            "linked_docs": [
                {"id": "d1", "title": "Migration plan"},
                {"id": "d2", "title": "API contract"},
            ],
        }
    ]
    out = _format_cards_markdown(cards)
    assert "Linked docs" in out
    assert "Migration plan" in out
    assert "API contract" in out
