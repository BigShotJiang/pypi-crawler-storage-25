"""Tests for workspace-aware config helpers."""

from __future__ import annotations

import json

import pytest

from meeting_helper import config as config_mod


def test_validate_workspace_name_accepts_valid():
    config_mod.validate_workspace_name("default")
    config_mod.validate_workspace_name("client-x")
    config_mod.validate_workspace_name("work_2026")
    config_mod.validate_workspace_name("a")
    config_mod.validate_workspace_name("a" * 40)


@pytest.mark.parametrize("name", [
    "",
    "a" * 41,
    "with space",
    "with/slash",
    "with.dot",
    "with:colon",
    "../escape",
])
def test_validate_workspace_name_rejects_invalid(name):
    with pytest.raises(ValueError):
        config_mod.validate_workspace_name(name)


def test_workspace_path_returns_under_workspaces_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", tmp_path / "workspaces")
    p = config_mod.workspace_path("work")
    assert p == tmp_path / "workspaces" / "work.json"


def test_workspace_path_validates_name(tmp_path, monkeypatch):
    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", tmp_path / "workspaces")
    with pytest.raises(ValueError):
        config_mod.workspace_path("../escape")


def test_load_state_returns_defaults_when_missing(tmp_path, monkeypatch):
    monkeypatch.setattr(config_mod, "STATE_FILE", tmp_path / "state.json")
    state = config_mod.load_state()
    assert state == {"active_workspace": "default", "workspace_order": []}


def test_load_state_returns_defaults_when_corrupt(tmp_path, monkeypatch):
    sf = tmp_path / "state.json"
    sf.write_text("{not valid json")
    monkeypatch.setattr(config_mod, "STATE_FILE", sf)
    state = config_mod.load_state()
    assert state == {"active_workspace": "default", "workspace_order": []}


def test_save_state_round_trips(tmp_path, monkeypatch):
    sf = tmp_path / "state.json"
    monkeypatch.setattr(config_mod, "STATE_FILE", sf)
    config_mod.save_state({"active_workspace": "work", "workspace_order": ["default", "work"]})
    assert json.loads(sf.read_text()) == {
        "active_workspace": "work",
        "workspace_order": ["default", "work"],
    }


def test_save_state_creates_parent_dir(tmp_path, monkeypatch):
    sf = tmp_path / "nested" / "state.json"
    monkeypatch.setattr(config_mod, "STATE_FILE", sf)
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default"]})
    assert sf.exists()


def _seed_workspaces(tmp_path, monkeypatch, names):
    ws_dir = tmp_path / "workspaces"
    ws_dir.mkdir()
    for n in names:
        (ws_dir / f"{n}.json").write_text("{}")
    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", ws_dir)
    monkeypatch.setattr(config_mod, "STATE_FILE", tmp_path / "state.json")


def test_list_workspaces_empty_when_dir_missing(tmp_path, monkeypatch):
    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", tmp_path / "workspaces")
    monkeypatch.setattr(config_mod, "STATE_FILE", tmp_path / "state.json")
    assert config_mod.list_workspaces() == []


def test_list_workspaces_uses_workspace_order(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["work", "default", "client"])
    config_mod.save_state({
        "active_workspace": "default",
        "workspace_order": ["default", "work", "client"],
    })
    assert config_mod.list_workspaces() == ["default", "work", "client"]


def test_list_workspaces_appends_unlisted_alphabetically(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["work", "default", "zeta", "alpha"])
    config_mod.save_state({
        "active_workspace": "default",
        "workspace_order": ["default", "work"],
    })
    assert config_mod.list_workspaces() == ["default", "work", "alpha", "zeta"]


def test_list_workspaces_skips_invalid_filenames(tmp_path, monkeypatch):
    ws_dir = tmp_path / "workspaces"
    ws_dir.mkdir()
    (ws_dir / "default.json").write_text("{}")
    (ws_dir / "with space.json").write_text("{}")
    (ws_dir / "notjson.txt").write_text("nope")
    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", ws_dir)
    monkeypatch.setattr(config_mod, "STATE_FILE", tmp_path / "state.json")
    assert config_mod.list_workspaces() == ["default"]


def test_create_workspace_writes_default_config(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default"])
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default"]})

    config_mod.create_workspace("work")

    new_path = tmp_path / "workspaces" / "work.json"
    assert new_path.exists()
    data = json.loads(new_path.read_text())
    for key in config_mod.DEFAULT_CONFIG:
        assert key in data
    expected_dir = str(config_mod.HOME / "meetings" / "work")
    assert data["recordings_dir"] == expected_dir
    state = config_mod.load_state()
    assert state["workspace_order"] == ["default", "work"]


def test_create_workspace_copy_from(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default"])
    (tmp_path / "workspaces" / "default.json").write_text(json.dumps({"port": 9999}))
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default"]})

    config_mod.create_workspace("work", copy_from="default")

    data = json.loads((tmp_path / "workspaces" / "work.json").read_text())
    assert data["port"] == 9999


def test_create_workspace_rejects_duplicate(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default"])
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default"]})
    with pytest.raises(ValueError, match="already exists"):
        config_mod.create_workspace("default")


def test_delete_workspace_removes_file_and_order_entry(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default", "work"])
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default", "work"]})

    config_mod.delete_workspace("work")

    assert not (tmp_path / "workspaces" / "work.json").exists()
    assert config_mod.load_state()["workspace_order"] == ["default"]


def test_delete_workspace_refuses_active(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default", "work"])
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default", "work"]})
    with pytest.raises(ValueError, match="active"):
        config_mod.delete_workspace("default")


def test_delete_workspace_refuses_last_one(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default"])
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default"]})
    with pytest.raises(ValueError, match="last"):
        config_mod.delete_workspace("default")


def test_rename_workspace_moves_file(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default", "work"])
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default", "work"]})

    config_mod.rename_workspace("work", "client")

    assert not (tmp_path / "workspaces" / "work.json").exists()
    assert (tmp_path / "workspaces" / "client.json").exists()
    assert config_mod.load_state()["workspace_order"] == ["default", "client"]


def test_rename_workspace_updates_active(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default"])
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default"]})

    config_mod.rename_workspace("default", "main")

    state = config_mod.load_state()
    assert state["active_workspace"] == "main"
    assert state["workspace_order"] == ["main"]


def test_rename_workspace_rejects_existing_target(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default", "work"])
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default", "work"]})
    with pytest.raises(ValueError, match="already exists"):
        config_mod.rename_workspace("work", "default")


def test_set_active_workspace_updates_state(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default", "work"])
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default", "work"]})

    config_mod.set_active_workspace("work")

    assert config_mod.load_state()["active_workspace"] == "work"


def test_set_active_workspace_rejects_unknown(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default"])
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default"]})
    with pytest.raises(ValueError, match="not found"):
        config_mod.set_active_workspace("nonexistent")


def test_config_loads_active_workspace(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default", "work"])
    (tmp_path / "workspaces" / "work.json").write_text(json.dumps({"port": 8888}))
    config_mod.save_state({"active_workspace": "work", "workspace_order": ["default", "work"]})

    cfg = config_mod.Config()
    assert cfg.port == 8888
    assert cfg.config_path == tmp_path / "workspaces" / "work.json"


def test_config_loads_explicit_workspace(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default", "work"])
    (tmp_path / "workspaces" / "work.json").write_text(json.dumps({"port": 8888}))
    (tmp_path / "workspaces" / "default.json").write_text(json.dumps({"port": 7777}))
    config_mod.save_state({"active_workspace": "work", "workspace_order": ["default", "work"]})

    cfg = config_mod.Config(workspace="default")
    assert cfg.port == 7777


def test_config_self_heals_empty_workspaces_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", tmp_path / "workspaces")
    monkeypatch.setattr(config_mod, "STATE_FILE", tmp_path / "state.json")
    monkeypatch.setattr(config_mod, "LEGACY_CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr(config_mod, "LEGACY_BACKUP", tmp_path / "config.json.pre-workspaces.bak")

    cfg = config_mod.Config()
    assert (tmp_path / "workspaces" / "default.json").exists()
    assert cfg.config_path == tmp_path / "workspaces" / "default.json"


def test_get_config_returns_fresh_instance_for_explicit_workspace(tmp_path, monkeypatch):
    _seed_workspaces(tmp_path, monkeypatch, ["default", "work"])
    (tmp_path / "workspaces" / "work.json").write_text(json.dumps({"port": 8888}))
    (tmp_path / "workspaces" / "default.json").write_text(json.dumps({"port": 7777}))
    config_mod.save_state({"active_workspace": "default", "workspace_order": ["default", "work"]})
    config_mod._config = None

    main = config_mod.get_config()
    peek = config_mod.get_config(workspace="work")
    assert main.port == 7777
    assert peek.port == 8888
    assert config_mod.get_config() is main
