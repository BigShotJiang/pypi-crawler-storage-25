"""Migration tests for legacy config.json -> workspaces/default.json."""

from __future__ import annotations

import json
import time

import pytest

from meeting_helper import config as config_mod


@pytest.fixture
def fake_config_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(config_mod, "DEFAULT_CONFIG_DIR", tmp_path)
    monkeypatch.setattr(config_mod, "WORKSPACES_DIR", tmp_path / "workspaces")
    monkeypatch.setattr(config_mod, "STATE_FILE", tmp_path / "state.json")
    monkeypatch.setattr(config_mod, "LEGACY_CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr(
        config_mod, "LEGACY_BACKUP", tmp_path / "config.json.pre-workspaces.bak"
    )
    return tmp_path


def test_migration_no_legacy_file_creates_default(fake_config_dir):
    config_mod.migrate_legacy_config()
    assert (fake_config_dir / "workspaces" / "default.json").exists()
    state = json.loads((fake_config_dir / "state.json").read_text())
    assert state == {"active_workspace": "default", "workspace_order": ["default"]}
    assert not (fake_config_dir / "config.json.pre-workspaces.bak").exists()


def test_migration_legacy_file_copies_and_backs_up(fake_config_dir):
    legacy_payload = {"anthropic_api_key": "sk-test", "port": 7891}
    (fake_config_dir / "config.json").write_text(json.dumps(legacy_payload))

    config_mod.migrate_legacy_config()

    migrated = json.loads(
        (fake_config_dir / "workspaces" / "default.json").read_text()
    )
    assert migrated == legacy_payload
    backup = json.loads(
        (fake_config_dir / "config.json.pre-workspaces.bak").read_text()
    )
    assert backup == legacy_payload
    assert not (fake_config_dir / "config.json").exists()


def test_migration_idempotent(fake_config_dir):
    (fake_config_dir / "workspaces").mkdir()
    (fake_config_dir / "workspaces" / "default.json").write_text(
        json.dumps({"already": "migrated"})
    )

    config_mod.migrate_legacy_config()

    data = json.loads(
        (fake_config_dir / "workspaces" / "default.json").read_text()
    )
    assert data == {"already": "migrated"}


def test_migration_backup_collision_uses_timestamp(fake_config_dir, monkeypatch):
    (fake_config_dir / "config.json").write_text(json.dumps({"v": 1}))
    (fake_config_dir / "config.json.pre-workspaces.bak").write_text(
        json.dumps({"prior": "backup"})
    )

    monkeypatch.setattr(time, "time", lambda: 1746345600)
    config_mod.migrate_legacy_config()

    assert json.loads(
        (fake_config_dir / "config.json.pre-workspaces.bak").read_text()
    ) == {"prior": "backup"}
    new_backup = fake_config_dir / "config.json.pre-workspaces.bak-1746345600"
    assert new_backup.exists()
    assert json.loads(new_backup.read_text()) == {"v": 1}
