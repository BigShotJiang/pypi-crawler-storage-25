import numpy as np
import matplotlib.pyplot as plt

class CurveAnalyzer:
    def __init__(self, x_data, y_data):
        self.x = np.array(x_data)
        self.y = np.array(y_data)
        
    def lagrange_interpolation(self, xp):
        n = len(self.x)
        yp = 0
        for i in range(n):
            p = 1
            for j in range(n):
                if i != j:
                    p *= (xp - self.x[j]) / (self.x[i] - self.x[j])
            yp += p * self.y[i]
        return yp

    def polynomial_fit(self, degree):
        coeff = np.polyfit(self.x, self.y, degree)
        return np.poly1d(coeff)

    def compare_and_plot(self, xp, degree=2):
        poly = self.polynomial_fit(degree)
        yp_lagrange = self.lagrange_interpolation(xp)
        yp_fit = poly(xp)
        
        # Plotting logic... (আপনার আগের কোডের প্লট অংশটি এখানে ক্লাসের ভেতরে থাকবে)
        return yp_lagrange, yp_fit
