"""trucktrack — high-performance Python package backed by Rust.

Public API is re-exported here from the compiled `_core` extension and from
the pure-Python `generate` and `partition` subpackages.
"""

from __future__ import annotations

from trucktrack._core import __version__
from trucktrack.generate import (
    ErrorConfig,
    RouteSegment,
    TracePoint,
    TripConfig,
    default_error_profile,
    generate_trace,
    traces_to_csv,
    traces_to_parquet,
)
from trucktrack.io import (
    process_dataframe_in_rust,
    process_parquet_in_rust,
    read_dataset,
    read_parquet,
)
from trucktrack.partition import (
    assign_partitions,
    classify_and_partition_key,
    partition_existing_parquet,
    partition_points,
    write_partitions,
    write_trips_partitioned,
)
from trucktrack.pipeline import compact_partitions, run_pipeline
from trucktrack.query import (
    ChunkIndex,
    scan_matched_trip,
    scan_matched_truck,
    scan_partitioned_trip,
    scan_partitioned_truck,
    scan_raw_truck,
)
from trucktrack.splitters import (
    filter_traffic_stops,
    filter_traffic_stops_file,
    split_by_observation_gap,
    split_by_observation_gap_file,
    split_by_stops,
    split_by_stops_file,
)

__all__ = [
    "__version__",
    "read_parquet",
    "read_dataset",
    "process_parquet_in_rust",
    "process_dataframe_in_rust",
    "filter_traffic_stops",
    "filter_traffic_stops_file",
    "split_by_observation_gap",
    "split_by_observation_gap_file",
    "split_by_stops",
    "split_by_stops_file",
    # generate
    "ErrorConfig",
    "RouteSegment",
    "TracePoint",
    "TripConfig",
    "default_error_profile",
    "generate_trace",
    "traces_to_csv",
    "traces_to_parquet",
    # partition
    "assign_partitions",
    "classify_and_partition_key",
    "partition_existing_parquet",
    "partition_points",
    "write_partitions",
    "write_trips_partitioned",
    # pipeline
    "compact_partitions",
    "run_pipeline",
    # query
    "ChunkIndex",
    "scan_raw_truck",
    "scan_partitioned_truck",
    "scan_partitioned_trip",
    "scan_matched_truck",
    "scan_matched_trip",
]
