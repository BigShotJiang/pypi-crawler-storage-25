import os
import sys
import shutil

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm

CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".jax")
PACKAGE_NAME = "jax-ai-assistant"
console = Console()


def _remove_config_dir() -> bool:
    if os.path.exists(CONFIG_DIR):
        shutil.rmtree(CONFIG_DIR)
        return True
    return False


def _find_pip_executable() -> str:
    # Tenta pip no mesmo diretório do executável Python (funciona em venv e global)
    python_dir = os.path.dirname(sys.executable)

    # Windows: Scripts\pip.exe  |  Unix: bin/pip
    for candidate in ["pip", "pip3", "pip.exe"]:
        path = os.path.join(python_dir, "Scripts", candidate) if os.name == "nt" \
            else os.path.join(python_dir, candidate)
        if os.path.isfile(path):
            return path

    # Fallback: usa python -m pip via execv
    return sys.executable


def run_uninstall(keep_config: bool = False):
    console.print()

    config_line = (
        "  [yellow]•[/yellow] Suas configurações em [cyan]~/.jax/[/cyan] (chave de API)\n"
        if not keep_config
        else "  [green]✓[/green] Suas configurações em [cyan]~/.jax/[/cyan] serão [bold]mantidas[/bold]\n"
    )

    console.print(
        Panel(
            "[bold red]Desinstalar o Jax AI[/bold red]\n\n"
            "Esta ação irá remover:\n"
            f"  [yellow]•[/yellow] O pacote [cyan]{PACKAGE_NAME}[/cyan] e o comando [cyan]jax[/cyan]\n"
            + config_line +
            "\n[dim]Arquivos .java / .sql que você criou não serão afetados.[/dim]",
            border_style="red",
            padding=(1, 2),
        )
    )

    confirmed = Confirm.ask("\n[bold]Deseja continuar com a desinstalação?[/bold]", default=False)
    if not confirmed:
        console.print("\n[dim]Desinstalação cancelada.[/dim]\n")
        return

    console.print()

    # 1. Remove configurações (se aplicável)
    if not keep_config:
        with console.status("[yellow]Removendo configurações...[/yellow]"):
            removed = _remove_config_dir()
        if removed:
            console.print("  [green]✓[/green] Configurações removidas [dim](~/.jax/)[/dim]")
        else:
            console.print("  [dim]– Nenhuma configuração encontrada para remover.[/dim]")
    else:
        console.print("  [green]✓[/green] Configurações mantidas [dim](~/.jax/)[/dim]")

    console.print(f"  [yellow]→[/yellow] Iniciando desinstalação de [cyan]{PACKAGE_NAME}[/cyan]...\n")

    pip_exec = _find_pip_executable()

    if pip_exec == sys.executable:
        # Fallback: python -m pip uninstall
        args = [sys.executable, "-m", "pip", "uninstall", PACKAGE_NAME, "-y"]
    else:
        args = [pip_exec, "uninstall", PACKAGE_NAME, "-y"]

    try:
        os.execv(args[0], args)
        # Tudo abaixo desta linha nunca executa — os.execv não retorna
    except OSError as e:
        console.print(
            f"\n  [red]✗[/red] Não foi possível executar o pip automaticamente: {e}\n\n"
            f"  Execute manualmente:\n"
            f"  [cyan]pip uninstall {PACKAGE_NAME}[/cyan]\n"
        )