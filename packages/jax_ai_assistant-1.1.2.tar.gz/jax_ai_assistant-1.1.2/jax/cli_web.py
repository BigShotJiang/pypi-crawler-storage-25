import sys
import time
import threading
import webbrowser

from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule

from jax.cli_config import get_api_key

console = Console()


def _open_browser_delayed(url: str, delay: float = 1.8):
    """Abre o navegador após um pequeno delay para o servidor subir primeiro."""
    time.sleep(delay)
    webbrowser.open(url)


def run_web(host: str = "127.0.0.1", port: int = 8000):
    # Verifica chave de API antes de subir o servidor
    api_key = get_api_key()
    if not api_key:
        console.print(
            Panel(
                "[bold red]Chave de API não configurada![/bold red]\n\n"
                "Execute o comando abaixo e tente novamente:\n\n"
                "[cyan]  jax config --api-key SUA_CHAVE_GEMINI[/cyan]\n\n"
                "Obtenha sua chave em: [cyan]https://aistudio.google.com/app/apikey[/cyan]",
                border_style="red",
                padding=(1, 2),
            )
        )
        sys.exit(1)

    url = f"http://{host}:{port}/template/chat"

    console.print()
    console.print(
        Panel(
            "[bold yellow]Jax AI — Interface Web[/bold yellow]\n\n"
            f"  Servidor : [cyan]http://{host}:{port}[/cyan]\n"
            f"  Chat     : [cyan]{url}[/cyan]\n\n"
            "  [dim]Use Ctrl+C para encerrar o servidor.[/dim]\n"
            "  [dim]O navegador abrirá automaticamente em instantes...[/dim]",
            border_style="yellow",
            padding=(1, 2),
        )
    )
    console.print(Rule("[dim]uvicorn log[/dim]"))

    # Abre o navegador em background após o servidor subir
    browser_thread = threading.Thread(target=_open_browser_delayed, args=(url,), daemon=True)
    browser_thread.start()

    try:
        import uvicorn
        from jax.main import app  # noqa: F401 — valida o import antes de subir

        uvicorn.run(
            "jax.main:app",
            host=host,
            port=port,
            reload=False,
        )
    except KeyboardInterrupt:
        pass
    except ImportError as e:
        console.print(
            Panel(
                f"[bold red]Erro ao carregar a aplicação:[/bold red] {e}\n\n"
                "Certifique-se de que o pacote está instalado corretamente:\n"
                "[cyan]pip install --upgrade jax-ai-assistant[/cyan]",
                border_style="red",
                padding=(1, 2),
            )
        )
        sys.exit(1)

    console.print()
    console.print(Rule("[dim]servidor encerrado[/dim]"))
    console.print()