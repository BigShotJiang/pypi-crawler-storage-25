""" gitodo-bin-win32-x64-msvc """


def main() -> None:
    print("  gitodo-bin-win32-x64-msvc  ")
