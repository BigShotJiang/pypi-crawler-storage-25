"""Auto-generated example: Result Var: 1D input."""

import math

import bencher as bn


class ResponseTimer(bn.ParametrizedSweep):
    """Measures HTTP request latency across endpoints and concurrency levels."""

    endpoint = bn.StringSweep(["api/users", "api/orders"], doc="API endpoint")
    concurrency = bn.FloatSweep(default=50, bounds=[1, 100], doc="Concurrent requests")

    latency = bn.ResultFloat(units="ms", doc="Response latency")

    def benchmark(self):
        base = {"api/users": 12.0, "api/orders": 25.0}[self.endpoint]
        self.latency = base + 0.5 * math.log1p(self.concurrency)


def example_result_var_1d(run_cfg: bn.BenchRunCfg | None = None) -> bn.Bench:
    """Result Var: 1D input."""
    bench = ResponseTimer().to_bench(run_cfg)
    bench.plot_sweep(
        input_vars=["concurrency"],
        result_vars=["latency"],
        description="Demonstrates a scalar numeric metric with units with 1D input sweep.",
    )

    return bench


if __name__ == "__main__":
    bn.run(example_result_var_1d, level=3)
