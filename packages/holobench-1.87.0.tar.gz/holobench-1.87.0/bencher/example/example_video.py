import bencher as bn
import numpy as np
from PIL import Image
import colorcet as cc
import numpy.typing as npt


def apply_colormap(data: npt.NDArray) -> npt.NDArray:
    """Apply a perceptually uniform colormap to the data"""
    # Normalize data to [0, 1]
    normalized = (data - data.min()) / (data.max() - data.min())
    # Convert hex colors to RGB values using numpy's frombuffer
    colors = np.array(
        [np.frombuffer(bytes.fromhex(c.lstrip("#")), dtype=np.uint8) for c in cc.rainbow]
    )
    # Map normalized values to colormap indices
    indices = (normalized * (len(colors) - 1)).astype(int)
    # Create RGB array from the colormap
    return colors[indices]


class TuringPattern(bn.ParametrizedSweep):
    alpha = bn.FloatSweep(default=2.8e-4, bounds=(2e-4, 5e-3))
    beta = bn.FloatSweep(default=5e-3, bounds=(1e-3, 9e-3))
    tau = bn.FloatSweep(default=0.1, bounds=(0.01, 0.5))
    k = bn.FloatSweep(default=-0.005, bounds=(-0.01, 0.01))

    size = bn.IntSweep(default=30, bounds=(30, 200), doc="size of the 2D grid")
    time = bn.FloatSweep(default=20.0, bounds=(1, 100), doc="total time of simulation")
    dt = bn.FloatSweep(default=0.001, doc="simulation time step")

    video = bn.ResultVideo()
    score = bn.ResultFloat()
    img = bn.ResultImage()
    img_extracted = bn.ResultImage()

    def laplacian(self, Z, dx):
        Ztop = Z[0:-2, 1:-1]
        Zleft = Z[1:-1, 0:-2]
        Zbottom = Z[2:, 1:-1]
        Zright = Z[1:-1, 2:]
        Zcenter = Z[1:-1, 1:-1]
        return (Ztop + Zleft + Zbottom + Zright - 4 * Zcenter) / dx**2

    def update(self, U, V, dx):
        # We compute the Laplacian of u and v.
        deltaU = self.laplacian(U, dx)
        deltaV = self.laplacian(V, dx)
        # We take the values of u and v inside the grid.
        Uc = U[1:-1, 1:-1]
        Vc = V[1:-1, 1:-1]
        # We update the variables.
        U[1:-1, 1:-1], V[1:-1, 1:-1] = (
            Uc + self.dt * (self.alpha * deltaU + Uc - Uc**3 - Vc + self.k),
            Vc + self.dt * (self.beta * deltaV + Uc - Vc) / self.tau,
        )
        # Neumann conditions: derivatives at the edges
        # are null.
        for Z in (U, V):
            Z[0, :] = Z[1, :]
            Z[-1, :] = Z[-2, :]
            Z[:, 0] = Z[:, 1]
            Z[:, -1] = Z[:, -2]

    def benchmark(self):
        n = int(self.time / self.dt)
        dx = 2.0 / self.size

        U = np.random.rand(self.size, self.size)
        V = np.random.rand(self.size, self.size)

        vid_writer = bn.VideoWriter()
        for i in range(n):
            self.update(U, V, dx)
            if i % 500 == 0:
                # Apply colormap to create RGB image
                rgb = apply_colormap(U)
                # Create PIL image with alpha channel
                img = Image.fromarray(rgb, "RGB").convert("RGBA")
                img = img.resize((200, 200), Image.Resampling.LANCZOS)
                rgb_alpha = np.array(img)
                vid_writer.append(rgb_alpha)

        self.img = bn.add_image(rgb_alpha)
        self.video = vid_writer.write()
        self.img_extracted = bn.video_writer.VideoWriter.extract_frame(self.video)
        print("img path", self.img_extracted)
        self.score = self.alpha + self.beta


def example_video(run_cfg: bn.BenchRunCfg | None = None) -> bn.Bench:
    bench = TuringPattern().to_bench(run_cfg)

    bench.plot_sweep(
        "Turing patterns with different parameters",
        input_vars=["alpha", "beta"],
        result_vars=["video"],
    )

    return bench


def example_video_tap(run_cfg: bn.BenchRunCfg | None = None) -> bn.Bench:  # pragma: no cover
    bench = TuringPattern().to_bench(run_cfg)
    res = bench.plot_sweep(input_vars=["alpha", "beta"])

    bench.report.append(res.to_video_grid(result_types=(bn.ResultVideo)))

    res = bench.plot_sweep(input_vars=["alpha"])
    bench.report.append(
        res.to_video_grid(
            result_types=(bn.ResultVideo),
            compose_method_list=[bn.ComposeType.right],
        )
    )

    bench.worker_class_instance.get_results_only()

    return bench


if __name__ == "__main__":
    bn.run(example_video_tap, level=2)
