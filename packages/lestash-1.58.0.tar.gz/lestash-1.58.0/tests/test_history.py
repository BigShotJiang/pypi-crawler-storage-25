"""Tests for item history tracking and schema migrations."""

import sqlite3

from lestash.core.database import (
    SCHEMA_VERSION,
    apply_migrations,
    get_connection,
    get_db_path,
    get_schema_version,
    mark_recent_history,
    max_history_id,
    upsert_item,
)
from lestash.models.item import ItemCreate


class TestSchemaMigrations:
    """Test schema versioning and migrations."""

    def test_new_database_has_current_version(self, test_db):
        """New databases should have the current schema version."""
        with get_connection(test_db) as conn:
            version = get_schema_version(conn)
            assert version == SCHEMA_VERSION

    def test_apply_migrations_is_idempotent(self, test_db):
        """Calling apply_migrations multiple times should be safe."""
        with get_connection(test_db) as conn:
            # Apply migrations twice
            apply_migrations(conn)
            applied2 = apply_migrations(conn)

            # Second call should apply nothing
            assert applied2 == 0

            # Version should still be current
            assert get_schema_version(conn) == SCHEMA_VERSION

    def test_migrations_applied_on_connection(self, test_db):
        """get_connection should automatically apply pending migrations."""
        # Manually reset version to 0 (simulating old database)
        db_path = get_db_path(test_db)
        with sqlite3.connect(db_path) as conn:
            conn.execute("PRAGMA user_version = 0")
            # Drop all tables created by migrations to simulate pre-migration state
            conn.execute("DROP TABLE IF EXISTS item_history")
            conn.execute("DROP TRIGGER IF EXISTS capture_item_history")
            conn.execute("DROP TABLE IF EXISTS person_profiles")
            conn.execute("DROP TABLE IF EXISTS post_cache")
            conn.commit()

        # Now get_connection should apply migrations
        with get_connection(test_db) as conn:
            version = get_schema_version(conn)
            assert version == SCHEMA_VERSION

            # History table should exist
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='item_history'"
            )
            assert cursor.fetchone() is not None


class TestHistoryTableCreation:
    """Test that history table is created correctly."""

    def test_item_history_table_exists(self, test_db):
        """Verify item_history table is created on init."""
        with get_connection(test_db) as conn:
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='item_history'"
            )
            assert cursor.fetchone() is not None

    def test_item_history_has_required_columns(self, test_db):
        """Verify all required columns exist."""
        with get_connection(test_db) as conn:
            cursor = conn.execute("PRAGMA table_info(item_history)")
            columns = {row[1] for row in cursor.fetchall()}
            expected = {
                "id",
                "item_id",
                "content_old",
                "title_old",
                "author_old",
                "url_old",
                "metadata_old",
                "is_own_content_old",
                "parent_id_old",
                "changed_at",
                "change_reason",
                "change_type",
            }
            assert expected.issubset(columns)


class TestHistoryTrigger:
    """Test automatic history capture on updates."""

    def test_trigger_captures_content_change(self, test_db):
        """Updating content should create history record."""
        with get_connection(test_db) as conn:
            # Insert item
            conn.execute(
                "INSERT INTO items (source_type, source_id, content) VALUES (?, ?, ?)",
                ("test", "id1", "old content"),
            )
            conn.commit()

            # Update content
            conn.execute(
                "UPDATE items SET content = ? WHERE source_id = ?",
                ("new content", "id1"),
            )
            conn.commit()

            # Verify history captured
            cursor = conn.execute("SELECT content_old FROM item_history WHERE item_id = 1")
            history = cursor.fetchone()
            assert history is not None
            assert history[0] == "old content"

    def test_trigger_captures_author_change(self, test_db):
        """Updating author should create history record."""
        with get_connection(test_db) as conn:
            conn.execute(
                "INSERT INTO items (source_type, source_id, content, author) VALUES (?, ?, ?, ?)",
                ("test", "id1", "content", "old_author"),
            )
            conn.commit()

            conn.execute(
                "UPDATE items SET author = ? WHERE source_id = ?",
                ("new_author", "id1"),
            )
            conn.commit()

            cursor = conn.execute("SELECT author_old FROM item_history WHERE item_id = 1")
            history = cursor.fetchone()
            assert history[0] == "old_author"

    def test_trigger_captures_metadata_change(self, test_db):
        """Updating metadata should create history record."""
        with get_connection(test_db) as conn:
            conn.execute(
                "INSERT INTO items (source_type, source_id, content, metadata) VALUES (?, ?, ?, ?)",
                ("test", "id1", "content", '{"old": "data"}'),
            )
            conn.commit()

            conn.execute(
                "UPDATE items SET metadata = ? WHERE source_id = ?",
                ('{"new": "data"}', "id1"),
            )
            conn.commit()

            cursor = conn.execute("SELECT metadata_old FROM item_history WHERE item_id = 1")
            history = cursor.fetchone()
            assert history[0] == '{"old": "data"}'

    def test_trigger_does_not_fire_on_no_change(self, test_db):
        """No history record if content/author/metadata unchanged."""
        with get_connection(test_db) as conn:
            conn.execute(
                "INSERT INTO items (source_type, source_id, content, url) VALUES (?, ?, ?, ?)",
                ("test", "id1", "content", "http://old.url"),
            )
            conn.commit()

            # Update only URL (not tracked by trigger)
            conn.execute(
                "UPDATE items SET url = ? WHERE source_id = ?",
                ("http://new.url", "id1"),
            )
            conn.commit()

            cursor = conn.execute("SELECT COUNT(*) FROM item_history")
            assert cursor.fetchone()[0] == 0

    def test_trigger_captures_title_change(self, test_db):
        """Updating title should create history record with title_old."""
        with get_connection(test_db) as conn:
            conn.execute(
                "INSERT INTO items (source_type, source_id, content, title) VALUES (?, ?, ?, ?)",
                ("test", "id1", "content", "old title"),
            )
            conn.commit()

            conn.execute(
                "UPDATE items SET title = ? WHERE source_id = ?",
                ("new title", "id1"),
            )
            conn.commit()

            cursor = conn.execute("SELECT title_old FROM item_history WHERE item_id = 1")
            assert cursor.fetchone()[0] == "old title"

    def test_trigger_captures_parent_id_change(self, test_db):
        """Updating parent_id should create history record with parent_id_old."""
        with get_connection(test_db) as conn:
            parent_a_id = conn.execute(
                "INSERT INTO items (source_type, source_id, content) VALUES (?, ?, ?)",
                ("test", "parent-a", "parent A"),
            ).lastrowid
            parent_b_id = conn.execute(
                "INSERT INTO items (source_type, source_id, content) VALUES (?, ?, ?)",
                ("test", "parent-b", "parent B"),
            ).lastrowid
            child_id = conn.execute(
                "INSERT INTO items (source_type, source_id, content, parent_id) "
                "VALUES (?, ?, ?, ?)",
                ("test", "child", "child", parent_a_id),
            ).lastrowid
            conn.commit()

            conn.execute(
                "UPDATE items SET parent_id = ? WHERE source_id = ?",
                (parent_b_id, "child"),
            )
            conn.commit()

            cursor = conn.execute(
                "SELECT parent_id_old FROM item_history WHERE item_id = ?",
                (child_id,),
            )
            assert cursor.fetchone()[0] == parent_a_id

    def test_trigger_captures_changed_at_timestamp(self, test_db):
        """History record should have timestamp."""
        with get_connection(test_db) as conn:
            conn.execute(
                "INSERT INTO items (source_type, source_id, content) VALUES (?, ?, ?)",
                ("test", "id1", "old"),
            )
            conn.commit()

            conn.execute("UPDATE items SET content = 'new' WHERE source_id = 'id1'")
            conn.commit()

            cursor = conn.execute("SELECT changed_at FROM item_history WHERE item_id = 1")
            changed_at = cursor.fetchone()[0]
            assert changed_at is not None


class TestHistoryWithUpsert:
    """Test history works with ON CONFLICT upsert pattern."""

    def test_upsert_triggers_history_on_update(self, test_db):
        """Upsert that updates should create history."""
        with get_connection(test_db) as conn:
            # First insert
            conn.execute(
                """INSERT INTO items (source_type, source_id, content, author)
                   VALUES (?, ?, ?, ?)""",
                ("linkedin", "post-123", "CREATE ugcPosts", None),
            )
            conn.commit()

            # Upsert with new content
            conn.execute(
                """INSERT INTO items (source_type, source_id, content, author)
                   VALUES (?, ?, ?, ?)
                   ON CONFLICT(source_type, source_id) DO UPDATE SET
                       content = excluded.content,
                       author = excluded.author""",
                ("linkedin", "post-123", "Actual post content here", "urn:li:person:abc"),
            )
            conn.commit()

            # Verify history
            cursor = conn.execute("SELECT content_old, author_old FROM item_history")
            history = cursor.fetchone()
            assert history[0] == "CREATE ugcPosts"
            assert history[1] is None

    def test_upsert_insert_does_not_create_history(self, test_db):
        """Upsert that inserts (no conflict) should not create history."""
        with get_connection(test_db) as conn:
            conn.execute(
                """INSERT INTO items (source_type, source_id, content)
                   VALUES (?, ?, ?)
                   ON CONFLICT(source_type, source_id) DO UPDATE SET
                       content = excluded.content""",
                ("linkedin", "new-post", "Fresh content"),
            )
            conn.commit()

            cursor = conn.execute("SELECT COUNT(*) FROM item_history")
            assert cursor.fetchone()[0] == 0


class TestChangeReason:
    """Test that the change_reason taxonomy is wired through the right callers."""

    def test_helper_marks_only_rows_after_snapshot(self, test_db):
        with get_connection(test_db) as conn:
            conn.execute(
                "INSERT INTO items (source_type, source_id, content) VALUES (?, ?, ?)",
                ("test", "id1", "v1"),
            )
            conn.commit()

            conn.execute("UPDATE items SET content = 'v2' WHERE source_id = 'id1'")
            conn.commit()
            pre_max = max_history_id(conn)

            conn.execute("UPDATE items SET content = 'v3' WHERE source_id = 'id1'")
            conn.commit()

            mark_recent_history(conn, pre_max, "custom-reason")
            conn.commit()

            rows = conn.execute(
                "SELECT content_old, change_reason FROM item_history ORDER BY id"
            ).fetchall()
            assert rows[0]["content_old"] == "v1"
            assert rows[0]["change_reason"] == "api-update"
            assert rows[1]["content_old"] == "v2"
            assert rows[1]["change_reason"] == "custom-reason"

    def test_helper_with_item_ids_scopes_update(self, test_db):
        """mark_recent_history(..., item_ids=[X]) must not touch other items' rows."""
        with get_connection(test_db) as conn:
            a_id = conn.execute(
                "INSERT INTO items (source_type, source_id, content) VALUES (?, ?, ?)",
                ("test", "a", "a-v1"),
            ).lastrowid
            b_id = conn.execute(
                "INSERT INTO items (source_type, source_id, content) VALUES (?, ?, ?)",
                ("test", "b", "b-v1"),
            ).lastrowid
            conn.commit()

            pre_max = max_history_id(conn)
            conn.execute("UPDATE items SET content = ? WHERE id = ?", ("a-v2", a_id))
            conn.execute("UPDATE items SET content = ? WHERE id = ?", ("b-v2", b_id))
            conn.commit()

            mark_recent_history(conn, pre_max, "scoped", item_ids=[a_id])
            conn.commit()

            a_reason = conn.execute(
                "SELECT change_reason FROM item_history WHERE item_id = ?", (a_id,)
            ).fetchone()[0]
            b_reason = conn.execute(
                "SELECT change_reason FROM item_history WHERE item_id = ?", (b_id,)
            ).fetchone()[0]
            assert a_reason == "scoped"
            assert b_reason == "api-update"

    def test_helper_with_empty_item_ids_is_noop(self, test_db):
        with get_connection(test_db) as conn:
            item_id = conn.execute(
                "INSERT INTO items (source_type, source_id, content) VALUES (?, ?, ?)",
                ("test", "a", "v1"),
            ).lastrowid
            conn.commit()
            pre_max = max_history_id(conn)
            conn.execute("UPDATE items SET content = ? WHERE id = ?", ("v2", item_id))
            conn.commit()

            mark_recent_history(conn, pre_max, "scoped", item_ids=[])
            conn.commit()

            reason = conn.execute(
                "SELECT change_reason FROM item_history WHERE item_id = ?", (item_id,)
            ).fetchone()[0]
            assert reason == "api-update"

    def test_upsert_item_marks_history_as_sync(self, test_db):
        with get_connection(test_db) as conn:
            upsert_item(
                conn,
                ItemCreate(
                    source_type="linkedin",
                    source_id="post-1",
                    content="original",
                ),
            )
            upsert_item(
                conn,
                ItemCreate(
                    source_type="linkedin",
                    source_id="post-1",
                    content="updated",
                ),
            )

            rows = conn.execute("SELECT change_reason, content_old FROM item_history").fetchall()
            assert len(rows) == 1
            assert rows[0]["change_reason"] == "sync"
            assert rows[0]["content_old"] == "original"

    def test_pdf_enricher_marks_history_as_enricher(self, test_db):
        from lestash.core.pdf_enrich.persistence import mark_source_unavailable

        with get_connection(test_db) as conn:
            item_id = conn.execute(
                "INSERT INTO items (source_type, source_id, content, metadata) VALUES (?, ?, ?, ?)",
                ("arxiv", "2401.0001", "abstract", '{"existing": "meta"}'),
            ).lastrowid
            conn.commit()

            mark_source_unavailable(conn, item_id)

            rows = conn.execute(
                "SELECT change_reason FROM item_history WHERE item_id = ?",
                (item_id,),
            ).fetchall()
            assert len(rows) == 1
            assert rows[0]["change_reason"] == "enricher"


class TestHistoryDuplicateCleanup:
    """Test the migration 9 cleanup query that removes duplicate sync history rows."""

    CLEANUP_SQL = """
        DELETE FROM item_history
        WHERE id NOT IN (
            SELECT MIN(ih.id) FROM item_history ih
            JOIN items i ON i.id = ih.item_id
            WHERE i.source_type IN ('linkedin', 'youtube', 'audible', 'bluesky')
            GROUP BY ih.item_id,
                     COALESCE(ih.content_old, ''),
                     COALESCE(ih.title_old, ''),
                     COALESCE(ih.metadata_old, '')
        )
        AND item_id IN (
            SELECT id FROM items
            WHERE source_type IN ('linkedin', 'youtube', 'audible', 'bluesky')
        );
    """

    def test_cleanup_removes_duplicate_sync_rows_keeping_earliest(self, test_db):
        with get_connection(test_db) as conn:
            conn.execute(
                "INSERT INTO items (source_type, source_id, content) VALUES (?, ?, ?)",
                ("linkedin", "post-1", "current"),
            )
            conn.commit()
            for _ in range(3):
                conn.execute(
                    """INSERT INTO item_history
                       (item_id, content_old, title_old, metadata_old, change_reason)
                       VALUES (1, 'same', 'same', '{}', 'api-update')""",
                )
            conn.commit()

            conn.execute(self.CLEANUP_SQL)
            conn.commit()

            cursor = conn.execute("SELECT COUNT(*) FROM item_history WHERE item_id = 1")
            assert cursor.fetchone()[0] == 1

    def test_cleanup_preserves_distinct_versions(self, test_db):
        with get_connection(test_db) as conn:
            conn.execute(
                "INSERT INTO items (source_type, source_id, content) VALUES (?, ?, ?)",
                ("linkedin", "post-1", "current"),
            )
            conn.commit()
            for content in ("v1", "v2", "v3"):
                conn.execute(
                    """INSERT INTO item_history
                       (item_id, content_old, change_reason)
                       VALUES (1, ?, 'api-update')""",
                    (content,),
                )
            conn.commit()

            conn.execute(self.CLEANUP_SQL)
            conn.commit()

            cursor = conn.execute("SELECT COUNT(*) FROM item_history WHERE item_id = 1")
            assert cursor.fetchone()[0] == 3

    def test_cleanup_does_not_touch_non_sync_sources(self, test_db):
        with get_connection(test_db) as conn:
            conn.execute(
                "INSERT INTO items (source_type, source_id, content) VALUES (?, ?, ?)",
                ("note", "n1", "current"),
            )
            conn.commit()
            for _ in range(3):
                conn.execute(
                    """INSERT INTO item_history
                       (item_id, content_old, change_reason)
                       VALUES (1, 'same', 'api-update')""",
                )
            conn.commit()

            conn.execute(self.CLEANUP_SQL)
            conn.commit()

            cursor = conn.execute("SELECT COUNT(*) FROM item_history WHERE item_id = 1")
            assert cursor.fetchone()[0] == 3

    def test_cleanup_is_idempotent(self, test_db):
        with get_connection(test_db) as conn:
            conn.execute(
                "INSERT INTO items (source_type, source_id, content) VALUES (?, ?, ?)",
                ("linkedin", "post-1", "current"),
            )
            conn.commit()
            for _ in range(3):
                conn.execute(
                    """INSERT INTO item_history
                       (item_id, content_old, change_reason)
                       VALUES (1, 'same', 'api-update')""",
                )
            conn.commit()

            conn.execute(self.CLEANUP_SQL)
            conn.commit()
            cursor = conn.execute("SELECT COUNT(*) FROM item_history WHERE item_id = 1")
            first = cursor.fetchone()[0]

            conn.execute(self.CLEANUP_SQL)
            conn.commit()
            cursor = conn.execute("SELECT COUNT(*) FROM item_history WHERE item_id = 1")
            second = cursor.fetchone()[0]

            assert first == second == 1


class TestHistoryCascadeDelete:
    """Test history cleanup when items deleted."""

    def test_history_deleted_when_item_deleted(self, test_db):
        """History records should be deleted with item (CASCADE)."""
        with get_connection(test_db) as conn:
            conn.execute(
                "INSERT INTO items (source_type, source_id, content) VALUES (?, ?, ?)",
                ("test", "id1", "old"),
            )
            conn.commit()

            conn.execute("UPDATE items SET content = 'new' WHERE source_id = 'id1'")
            conn.commit()

            # Verify history exists
            cursor = conn.execute("SELECT COUNT(*) FROM item_history")
            assert cursor.fetchone()[0] == 1

            # Delete item
            conn.execute("DELETE FROM items WHERE source_id = 'id1'")
            conn.commit()

            # History should be gone
            cursor = conn.execute("SELECT COUNT(*) FROM item_history")
            assert cursor.fetchone()[0] == 0
