"""A python lib for degree calculations and conversions."""
from .degrees import (Degree,
                      degree2radius,
                      radius2degree,
                      convert_to_360)
from .version import version_info

__all__ = ["Degree",
           "degree2radius",
           "radius2degree",
           "convert_to_360",
           "version_info"]
