from collections import namedtuple as _nt

_version_type = _nt(
    '_version_type',
    ['major',
     'minor',
     'micro',
     'releaselevel',
     'serial'],
    defaults=(0,)
)

version_info = _version_type(0, 1, 2, 'final', 0)
