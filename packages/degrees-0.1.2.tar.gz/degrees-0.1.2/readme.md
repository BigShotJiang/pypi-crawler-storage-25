# The documentation is moved to <a href="https://www.bilibili.com/opus/1190229802480566289">here</a>.

> ## Note:
> ### 1. You had better use your computer to read the documentation. If you are using your phone, please change your mode to "computer mode".
> ### 2. This version is the same as the version 0.1.1(deleted because did not upload successfully).