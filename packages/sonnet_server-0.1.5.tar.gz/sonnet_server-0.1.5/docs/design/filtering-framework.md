# Filtering Framework

Declarative, composable, AST-based query compilation. The core translates a
`FilterExpr` AST into SQLAlchemy clauses given a set of `FilterDef`
declarations. The framework has no opinion about what tables, columns, or
domain types exist -- all of that is supplied by the caller.

The AST can be built from any source: HTTP query params, a `q=` expression
string, programmatic construction in service code, GraphQL resolvers,
background jobs, or CLI tools. HTTP is one entry point, not the only one.

---

## Problem

Anywhere code needs to turn user-supplied or programmatic filter criteria
into SQLAlchemy WHERE clauses, the naive approach -- one `if param:
query = query.where(...)` per field -- does not scale. It duplicates
validation, makes testing awkward, and cannot support complex boolean
expressions (OR, NOT, grouping).

The requirements:

- **Declarative.** What is filterable is declared as data, not control flow.
- **Composable.** Envelope columns, JSONB content columns, and typed compound
  values (quantities, codings) all feed the same compiler.
- **Layered.** AST definition, SQL compilation, and optional HTTP parsing are
  separate concerns with hard boundaries.
- **Testable.** Every layer is independently testable without infrastructure.
- **Extensible.** New domain types (quantity, coding, period) plug in without
  touching the framework.

---

## Architecture

```mermaid
graph TB
    subgraph "Entry Points"
        HTTP["HTTP query params<br/><i>api/list_params.py</i>"]
        QParser["q= expression parser<br/><i>parse_query(str)</i>"]
        Prog["Programmatic construction<br/><i>FilterTerm / FilterAnd / FilterOr</i>"]
    end

    AST["FilterExpr AST"]

    HTTP --> AST
    QParser --> AST
    Prog --> AST

    subgraph "Declaration (how FilterDefs are produced)"
        Static["Static<br/>hand-written FilterDef lists"]
        DBWalker["DB model walker<br/><i>filter_defs_from_db_model()</i>"]
        SchemaWalker["Schema walker<br/><i>filter_defs_from_schema()</i>"]
        BuildDefs["build_filter_defs()<br/><i>combines DB + schema walkers</i>"]
        DBWalker --> BuildDefs
        SchemaWalker --> BuildDefs
    end

    DEFS["list of FilterDef"]
    Static --> DEFS
    BuildDefs --> DEFS

    subgraph "Compilation"
        Compiler["compile_filter()<br/><i>database/filtering/compiler.py</i>"]
        TypedCompilers["Typed value compilers<br/><i>quantity, coding, ... (caller-supplied)</i>"]
        TypedCompilers -.-> Compiler
    end

    AST --> Compiler
    DEFS --> Compiler
    Compiler --> SA["SQLAlchemy WHERE clause"]
```

The framework has three layers with strict import boundaries:

```mermaid
graph LR
    subgraph "utils/filtering/"
        direction TB
        A1["types.py -- AST nodes"]
        A2["filter_defs.py -- FilterDef, FilterOperator"]
        A3["parser.py -- Lark LALR parser"]
        A4["value_parsers.py -- ParsedQuantity, ParsedCoding"]
        A5["schema_walker.py -- JSON Schema to FilterDefs"]
        A6["db_model_walker.py -- SQLModel to FilterDefs"]
    end

    subgraph "database/filtering/"
        direction TB
        B1["compiler.py -- AST to SQLAlchemy"]
    end

    subgraph "api/"
        direction TB
        C1["list_params.py -- HTTP to FilterExpr"]
    end

    B1 -->|imports| A2
    C1 -->|imports| A2

    style A1 fill:#e8f4e8
    style A2 fill:#e8f4e8
    style A3 fill:#e8f4e8
    style A4 fill:#e8f4e8
    style A5 fill:#e8f4e8
    style A6 fill:#e8f4e8
    style B1 fill:#e8e4f4
    style C1 fill:#f4e8e4
```

| Layer | Imports | No imports from |
|---|---|---|
| `utils/filtering/` | stdlib, Pydantic | SQLAlchemy, FastAPI, any module |
| `database/filtering/` | SQLAlchemy, `utils/filtering/` | FastAPI, any module |
| `api/list_params.py` | FastAPI, `utils/filtering/` | SQLAlchemy, any module |
| Service layer | `utils/filtering/`, `database/filtering/` | `api/` |
| `modules/<name>/filters.py` | `utils/filtering/` only | everything else |

### Usage examples

```python
# From HTTP (via FilterableListParams)
clause = compile_filter(page.filter_expr, DbModel, page.filter_defs, ...)

# From service code (programmatic)
expr = FilterAnd(children=[
    FilterTerm(field="status", op="eq", value="active"),
    FilterTerm(field="org_id", op="eq", value=org_id),
])
clause = compile_filter(expr, DbModel, my_filter_defs, ...)

# From a parsed q= string (any context)
expr = parse_query('status = "active" AND $.risk_score >= 7.5')
clause = compile_filter(expr, DbModel, my_filter_defs, ...)
```

---

## FilterDef

A `FilterDef` is the unit of declaration. It describes one filterable field:
what DB column it maps to, which operators are allowed, and whether the field
lives inside a JSONB structure.

```python
FilterDef(
    key="status",           # query param name and AST field name
    column="status",        # DB column (defaults to key when not set)
    operators=[FilterOperator.EQ],
    required=False,
    json_path=None,         # None for scalar columns
    json_is_array=False,
    json_value_type=None,   # None for scalar; "quantity", "coding", etc. for typed JSONB
    label=None,             # optional human-readable label for UI
)
```

The compiler rejects unknown fields and disallowed operators with `ValueError`.

### Operators

| Operator | Grammar symbol | SQL pattern |
|---|---|---|
| `eq` | `=` | `column = value` |
| `neq` | `!=` | `column != value` |
| `like` | `~` | `column ILIKE '%value%'` |
| `prefix` | `^` | `column LIKE 'value%'` |
| `gt` `gte` `lt` `lte` | `>` `>=` `<` `<=` | comparison |
| `in` | flat params only | `column IN (...)` |
| `json_contains` | `=` in q (auto-promoted) | `column @> '...'::jsonb` |
| `json_path_isnull` | `__isnull` suffix | `column -> 'key' IS NULL` |
| `isnull` | `__isnull` suffix | `column IS NULL` |

---

## Levels of use

The framework supports three levels of use, from fully static to fully
dynamic. They compose freely -- a single endpoint can mix all three.

---

### Level 1 -- Static FilterDefs (hardcoded)

The simplest case. Declare a list of `FilterDef`s by hand, pass to
`FilterableListParams.dependency()`. Used for well-known, stable fields.

```python
# modules/audit_trail/filters.py
AUDIT_TRAIL_FILTERS: list[FilterDef] = [
    FilterDef(key="org_id",    operators=[FilterOperator.EQ], required=True),
    FilterDef(key="action",    operators=[FilterOperator.PREFIX, FilterOperator.EQ]),
    FilterDef(
        key="actor_id", column="actors",
        operators=[FilterOperator.JSON_CONTAINS],
        json_path=["id"], json_is_array=True,
    ),
    FilterDef(key="occurred_after",  column="occurred_at", operators=[FilterOperator.GTE]),
    FilterDef(key="occurred_before", column="occurred_at", operators=[FilterOperator.LT]),
]
```

```python
# api.py
@router.get("")
def list_events(params: FilterableListParams = Depends(
    FilterableListParams.dependency(AUDIT_TRAIL_FILTERS)
)):
    return service.list_page(params.to_filter_page())

# service.py
def list_page(self, page: FilterPage) -> PageResult:
    clause = compile_filter(page.filter_expr, AuditLogEvent, page.filter_defs)
    ...
```

---

### Level 2 -- DB model introspection

`filter_defs_from_db_model` derives `FilterDef`s by inspecting a SQLModel
table's columns. One `FilterDef` per queryable scalar column. JSONB columns
are skipped -- they are handled separately.

```python
from sonnet_server.utils.filtering import filter_defs_from_db_model

envelope_defs = filter_defs_from_db_model(
    Patient,
    skip_fields=frozenset({"is_deleted", "created_by", "updated_by"}),
    json_columns=frozenset({"extensions"}),  # these are handled by schema walker
)
```

Column type mapping:

| SQLAlchemy type | Operators |
|---|---|
| String, Text, Enum | EQ, LIKE |
| Integer, Float, Numeric | EQ, GTE, LTE, GT, LT |
| DateTime, Date | EQ, GTE, LTE, GT, LT |
| Boolean, UUID | EQ |
| JSON / JSONB | skipped |

---

### Level 3 -- Schema-driven JSONB filtering

`filter_defs_from_schema` walks a JSON Schema document and produces
`FilterDef`s for every filterable leaf property inside the JSONB column.

Given this schema for a JSONB `extensions` column:

```json
{
  "type": "object",
  "properties": {
    "preferred_language": { "type": "string" },
    "risk_score":         { "type": "number" },
    "addresses": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "city":    { "type": "string" },
          "country": { "type": "string" }
        }
      }
    }
  }
}
```

The simplest call -- no `$ref`s, no typed values:

```python
from sonnet_server.utils.filtering import filter_defs_from_schema

defs = filter_defs_from_schema(schema)
```

The walker emits:

```
preferred_language   EQ, LIKE
risk_score           EQ, GTE, LTE, GT, LT
addresses.city       EQ, LIKE    json_is_array=True
addresses.country    EQ, LIKE    json_is_array=True
```

The returned `FilterDef`s have bare relative keys and no column set.
The caller binds them to the actual DB column and key prefix -- or uses
`build_filter_defs` (see next section) which does this automatically.

#### `$ref` resolution

When a schema uses `$ref` for shared type definitions, provide a
`resolver` -- a callable that maps a `$ref` URI to a schema dict.
Tests use a plain dict lookup. Production wraps a schema registry.

The walker resolves each `$ref`, recurses into the resolved schema,
and emits `FilterDef`s for its leaf properties -- exactly as for inline
objects. Chains of `$ref`s (a `$ref` resolving to a schema that contains
another `$ref`) are followed automatically. Cycles are detected and
silently skipped -- no endless loops.

The resolver type is `Callable[[str], dict | None]` -- a single URI in,
a schema dict or `None` out. When the resolution logic needs extra
context (a registry instance, a DB session, a cache), use a closure:

```python
from sonnet_server.utils.filtering import filter_defs_from_schema, RefResolver

# Tests: plain dict lookup
resolver: RefResolver = {"https://schemas.example.com/address": ADDRESS_SCHEMA}.get

# Production: close over a registry instance
def make_resolver(registry: SchemaRegistryService) -> RefResolver:
    def resolve(uri: str) -> dict | None:
        hit = registry.get_by_uri(uri)
        return hit.document if hit else None
    return resolve

resolver = make_resolver(my_registry)

defs = filter_defs_from_schema(schema.document, resolver=resolver)
```

#### Typed compound values

Some `$ref`s point to compound types (e.g. quantity, coding) that should
not be recursed into but instead treated as opaque leaves with a special
compilation strategy. The `typed_ref_map` parameter declares these:
it maps a `$ref` URI to a `json_value_type` name. The walker emits a
typed `FilterDef` instead of recursing into the schema. The type name
is the key into `typed_compilers` at compilation time.

```python
TYPED_REFS = {
    "https://types.example.com/quantity": "quantity",
    "https://types.example.com/coding":   "coding",
}

raw_defs = filter_defs_from_schema(
    schema.document,
    resolver=resolver,
    typed_ref_map=TYPED_REFS,
    skip_properties=frozenset({"_extensions"}),
)
# raw_defs have bare relative keys: "temperature", "addresses.city", etc.
# caller applies column and prefix:
content_defs = [
    d.model_copy(update={"key": f"content.{d.key}", "column": "content"})
    for d in raw_defs
]
```

See [Typed compound values](#typed-compound-values) below for how typed
compilers are implemented and wired.

---

### Level 3 convenience -- `build_filter_defs`

`build_filter_defs` combines DB model introspection and schema walking in one
call. This is the normal entry point when you have a table with JSONB columns
backed by schema documents.

`JsonColumnBinding` is declared next to the DB model -- it binds a specific
JSONB column on a specific table to its schema document and query alias.

```python
# modules/patients/models/db.py

class Patient(SQLModel, table=True):
    __tablename__ = "patients"
    id: UUID = Field(primary_key=True)
    first_name: str
    birth_date: date
    status: str
    extensions: dict | None = Field(sa_column=sa.Column(sa.JSON))
    is_deleted: bool = Field(default=False)

PATIENT_JSON_BINDINGS = [
    JsonColumnBinding(
        column="extensions",
        alias="$",              # query prefix; defaults to column name when omitted
        document=None,          # loaded from schema registry at runtime
        typed_ref_map={},       # empty for scalar-only schemas
        skip_properties=frozenset({"_extensions"}),
    ),
]
```

```python
# Example: consumer-side filter setup
# modules/patients/filters.py

from functools import lru_cache
from sonnet_server.utils.filtering import build_filter_defs, FilterDef, RefResolver
from my_app.modules.schema_registry import get_schema_registry_service  # consumer domain import

_EXTENSIONS_URI = "https://schemas.example.com/patient-extensions/v1"

def _make_resolver() -> RefResolver:
    registry = get_schema_registry_service()
    def resolve(uri: str) -> dict | None:
        hit = registry.get_by_uri(uri)
        return hit.document if hit else None
    return resolve

@lru_cache(maxsize=32)
def _build(definition_id: str, version: int) -> list[FilterDef]:
    """Cached per schema version -- rebuilds only when schema changes."""
    registry = get_schema_registry_service()
    schema = registry.get_by_uri(_EXTENSIONS_URI)
    return build_filter_defs(
        Patient,
        resolver=_make_resolver(),
        json_bindings=[
            JsonColumnBinding(
                column="extensions",
                alias="$",
                document=schema.document,
            ),
        ],
    )

def get_patient_filter_defs() -> list[FilterDef]:
    schema = get_schema_registry_service().get_by_uri(_EXTENSIONS_URI)
    if schema is None:
        return build_filter_defs(Patient, resolver=lambda _: None)
    return _build(schema.definition_id, schema.version)
```

The result is a merged list of envelope + content FilterDefs:

```
id              column=id           EQ
first_name      column=first_name   EQ, LIKE
birth_date      column=birth_date   EQ, GTE, LTE, GT, LT
status          column=status       EQ, LIKE
$.preferred_language  column=extensions  json_path=["preferred_language"]  EQ, LIKE
$.risk_score          column=extensions  json_path=["risk_score"]           EQ, GTE, ...
$.addresses.city      column=extensions  json_path=["city"]  json_is_array=True  EQ, LIKE
$.addresses.country   column=extensions  json_path=["country"]  json_is_array=True  EQ, LIKE
```

Query examples:

```
?status=active&q=$.risk_score >= 7.5
?q=first_name ~ "Anna" AND $.preferred_language = "de"
?q=$.addresses.city = "Berlin" AND status = "active"
```

Multiple JSONB columns work the same way -- add one `JsonColumnBinding` per
column, each with its own alias and schema document.

---

## Typed compound values

Some JSONB fields contain structured compound values that require special
SQL treatment. A quantity (`{"value": 38.4, "unit": "Cel"}`) cannot be
filtered with a plain scalar comparison -- it needs to decompose into a
numeric comparison on `value` and an equality check on `code`.

The framework supports this through typed value compilers. The framework
itself has no built-in knowledge of any compound type. All type knowledge
lives in compiler functions supplied by the caller.

### Defining a typed compiler

```python
from sonnet_server.database.filtering import TypedValueCompilerFn, navigate_json
from sonnet_server.utils.filtering.value_parsers import parse_quantity
import sqlalchemy as sa

_OP_MAP = {
    "eq": lambda col, val: col == val,
    "gte": lambda col, val: col >= val,
    "lte": lambda col, val: col <= val,
    "gt":  lambda col, val: col >  val,
    "lt":  lambda col, val: col <  val,
}

def compile_quantity(column, fdef, op, raw_value):
    """Compiles "38.0[Cel]" -> numeric comparison + optional unit check."""
    parsed = parse_quantity(raw_value)   # ParsedQuantity(value=38.0, unit="Cel")
    value_path = navigate_json(column, fdef.json_path + ["value"])
    clause = _OP_MAP[op](sa.cast(value_path, sa.Float), parsed.value)
    if parsed.unit:
        unit_path = navigate_json(column, fdef.json_path + ["code"])
        clause = sa.and_(clause, unit_path == parsed.unit)
    return clause

def compile_coding(column, fdef, op, raw_value):
    """Compiles "http://snomed.info/sct|73211009" -> JSONB containment."""
    parsed = parse_coding(raw_value)     # ParsedCoding(system="http://...", code="73211009")
    containment = {"code": parsed.code}
    if parsed.system:
        containment["system"] = parsed.system
    return build_json_containment(column, fdef.json_path, containment, fdef.json_is_array)
```

### Wiring typed compilers

Typed compilers are passed directly to `compile_filter` via the
`typed_compilers` parameter. The framework never touches a global registry
for this -- injection is explicit, tests get full isolation.

```python
MY_TYPED_COMPILERS: dict[str, TypedValueCompilerFn] = {
    "quantity": compile_quantity,
    "coding":   compile_coding,
}

clause = compile_filter(
    page.filter_expr,
    ClinicalRecord,
    page.filter_defs,
    typed_compilers=MY_TYPED_COMPILERS,
)
```

A global registry (`register_typed_value_compiler`) is available for
production startup convenience. When `typed_compilers` is `None`,
`compile_filter` falls back to the global registry. For tests, always
pass the dict explicitly.

### Wiring typed refs into the schema walker

The `typed_ref_map` on `JsonColumnBinding` (or passed directly to
`filter_defs_from_schema`) tells the walker which `$ref` URIs map to which
`json_value_type` name. The name is the key into `typed_compilers`.

```python
CLINICAL_TYPED_REFS = {
    "hds://types/quantity/v1":         "quantity",
    "hds://types/coding/v1":           "coding",
    "hds://types/codeable-concept/v1": "codeable_concept",
}

CLINICAL_JSON_BINDINGS = [
    JsonColumnBinding(
        column="content",
        alias="content",
        document=archetype_schema,
        typed_ref_map=CLINICAL_TYPED_REFS,
        skip_properties=frozenset({"_extensions"}),
    ),
]
```

When the walker encounters a property with
`"$ref": "hds://types/quantity/v1"`, it emits a `FilterDef` with
`json_value_type="quantity"`. The compiler then looks up `"quantity"` in
`typed_compilers` and delegates the clause generation to `compile_quantity`.

Query:

```
?q=content.temperature >= "38.0[Cel]" AND content.bodySite = "http://snomed.info/sct|21974007"
```

The `>=` on a quantity field compiles to:

```sql
CAST(content -> 'temperature' ->> 'value' AS FLOAT) >= 38.0
AND content -> 'temperature' ->> 'code' = 'Cel'
```

The `=` on a coding field compiles to:

```sql
content @> '{"bodySite": {"system": "http://snomed.info/sct", "code": "21974007"}}'::jsonb
```

---

## q= expression syntax

The `q=` parameter accepts a full boolean expression. Any declared
`FilterDef` key is valid in `q=`, including JSONB content fields and typed
fields.

```
?q=status = "active" AND $.risk_score >= 7.5
?q=first_name ~ "Anna" OR first_name ~ "Anne"
?q=(content.systolic >= "140[mm[Hg]]" AND content.diastolic >= "90[mm[Hg]]") OR content.systolic >= "180[mm[Hg]]"
```

Flat params and `q=` can coexist. The server AND-merges both sources:

```
?patient_id=pat_01&status=valid&q=content.temperature >= "38.0[Cel]"
```

resolves to:

```
patient_id = "pat_01"
AND status = "valid"
AND content.temperature >= "38.0[Cel]"
```

### Syntax reference

| Token | Operator | Meaning |
|---|---|---|
| `=` | `eq` | exact match |
| `!=` | `neq` | not equal |
| `~` | `like` | contains / substring |
| `^` | `prefix` | starts-with |
| `>` `>=` `<` `<=` | `gt` `gte` `lt` `lte` | comparison |
| `AND` | | conjunction (case-insensitive) |
| `OR` | | disjunction (case-insensitive) |
| `NOT` | | negation (case-insensitive) |
| `(...)` | | grouping |

Operator precedence: NOT > AND > OR. Values can be quoted (`"value"`) or
unquoted. Nested ANDs and ORs are flattened.

### EQ promotion for JSON_CONTAINS fields

When `=` is used in `q=` on a field whose only allowed operator is
`json_contains`, the compiler promotes it automatically:

```
actor_id = user_alice   ->   actors @> '[{"id": "user_alice"}]'::jsonb
```

This makes `actor_id = user_alice` in a `q=` expression behave identically
to the flat param `?actor_id=user_alice`.

---

## Required filters

`required=True` on a `FilterDef` causes the dependency to reject requests
that omit that filter with 400. Used for mandatory scoping fields such as
`org_id` or `patient_id`.

```python
FilterDef(key="patient_id", operators=[FilterOperator.EQ], required=True)
```

Required filters can be satisfied by either flat params or the `q=`
expression. `collect_fields()` extracts all field names from the parsed AST
to support this check.

---

## Module structure

```
utils/filtering/
  __init__.py           -- public surface
  types.py              -- AST nodes
  filter_defs.py        -- FilterDef, FilterOperator, FilterPage,
                           missing_required_filters()
  parser.py             -- parse_query(str) -> FilterExpr  (Lark LALR)
  value_parsers.py      -- ParsedQuantity, ParsedCoding,
                           parse_quantity(), parse_coding()
  schema_walker.py      -- filter_defs_from_schema(), RefResolver
  db_model_walker.py    -- filter_defs_from_db_model(),
                           JsonColumnBinding, build_filter_defs()

database/filtering/
  __init__.py           -- public surface
  compiler.py           -- compile_filter(), TypedValueCompilerFn,
                           navigate_json(), build_json_containment(),
                           register_typed_value_compiler()
```

---

## ListParams hierarchy

```
ListParams                  -- limit, offset, search
  SortableListParams        -- + sort with field allowlisting
  FilterableListParams      -- + filter_expr, filter_defs
                               .to_filter_page() -> FilterPage
```

`FilterableListParams` carries the parsed AST and filter defs. It does not
compile -- that is the service layer's responsibility. `to_filter_page()`
extracts `filter_expr`, `filter_defs`, `limit`, and `offset` into a
`FilterPage` dataclass. Services accept `FilterPage`, not
`FilterableListParams`, so they have no dependency on the FastAPI layer.

---

## Schema registry integration

`SchemaRegistryService.get_by_uri(uri)` resolves a schema document by its
canonical `$id` URI. This is the production implementation of `RefResolver`:

```python
def _make_resolver(registry: SchemaRegistryService) -> RefResolver:
    def resolve(uri: str) -> dict | None:
        hit = registry.get_by_uri(uri)
        return hit.document if hit else None
    return resolve
```

The `FilterDef` list derived from a schema document is cached by
`(definition_id, version)`. When a new schema version is published, the
cache misses once, rebuilds, and is warm again for all subsequent requests.
This pattern is the caller's responsibility -- the filter framework has no
built-in cache.
