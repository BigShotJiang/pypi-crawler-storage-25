# CrudRepository -- Generic CRUD Layer

> Status: Implemented
> Last updated: 2026-02-19

## Problem

Every entity service repeats the same operations: list, get, create, update,
soft-delete, optimistic locking, timestamp stamping, DB-to-response-model
conversion. This is boilerplate that should not be written per entity.

## Design Goals

- Generic over DB model and response model types.
- Configurable via a Pydantic config object -- behaviour driven by config,
  not by subclass overrides.
- Two usage patterns -- **inheritance** for standard CRUD entities,
  **composition** for restricted or non-standard entities. Both are supported.
- Extensible without changing existing consumers. Custom lookup fields, soft
  delete, optimistic locking, and filters are all driven by config or method
  arguments.
- No magic -- transparent, readable, easy to debug.

## Non-Goals

- Does not replace the service layer. Entity services still own entity-specific
  logic (server-generated IDs, domain validation, scoped queries).
- Does not generate API routes.
- Does not handle relationships or joins. Each entity handles those explicitly.
- No async (matches the existing sync SQLModel pattern).

## Two Usage Patterns

### Inheritance (standard CRUD entities)

Entity service inherits from `CrudRepository`. Standard operations (`list`,
`get`, `update`, `delete`, `exists`) are inherited directly -- no delegation
wrappers needed. Only entity-specific logic is overridden.

```python
class WidgetService(CrudRepository[Widget, WidgetResponse]):
    crud_config = CrudConfig(
        db_model=Widget,
        response_model=WidgetResponse,
        lookup_field="slug",
        soft_delete=True,
        order_by="name",
    )

    # Inherited: list, list_page, get, update, delete, exists

    def create(self, session, data, by=None):
        return super().create(session, data, by=by, extra={"slug": generate_slug()})
```

**Use when:** the entity has standard CRUD semantics and the public method
names (`list`, `get`, `create`, `update`, `delete`) are appropriate.

### Composition (restricted or non-standard entities)

Entity service holds a `CrudRepository` instance and exposes only the
operations it needs. Useful when inheritance would expose methods that should
not exist (e.g. a read-only service should not inherit `create`, `update`,
`delete`).

```python
class AuditLogService:
    _crud = CrudRepository(CrudConfig(
        db_model=AuditLogEntry,
        response_model=AuditLogResponse,
        lookup_field="id",
        soft_delete=False,
    ))

    def list(self, session, tenant_id, filters=None):
        return self._crud.list(session, filters=[AuditLogEntry.tenant_id == tenant_id])

    def get(self, session, id):
        return self._crud.get(session, id)

    # No create, update, delete exposed
```

**Use when:** the entity has non-standard access semantics (read-only,
write-only, scoped access) or the standard method names are not appropriate.

## Config Model

All behaviour is driven by `CrudConfig`, a Pydantic model passed at
construction time. Validation runs at construction -- typos in field names
raise `ValueError` immediately.

```
CrudConfig
  db_model: type[TDb]             -- The SQLModel table class
  response_model: type[TResponse] -- The Pydantic response model
  lookup_field: str               -- Column name used for get/update/delete
                                     (default: "id")
  soft_delete: bool | None        -- Use is_deleted flag instead of hard delete
                                     (default: None = auto-detected from db_model)
  optimistic_locking: bool | None -- Enforce version check on updates
                                     (default: None = auto-detected from db_model)
  order_by: str | None            -- Default sort column name (default: None)
  order_asc: bool                 -- Sort direction (default: True = ascending)

  # Derived capabilities (set automatically by model_validator, not by caller)
  has_soft_delete: bool           -- Resolved from soft_delete or db_model inspection
  has_optimistic_locking: bool    -- Resolved from optimistic_locking or db_model inspection
  has_timestamps: bool            -- True when db_model has created_at and updated_at
  has_stamp_by: bool              -- True when db_model has created_by and updated_by
```

Future additions extend the config without changing call sites. See
`docs/design/list-api.md` for the `list_page` pagination design.

## Interface

```
CrudRepository[TDb, TResponse]

  list(session, filters?) -> list[TResponse]
  list_page(session, limit, offset, filters?, sort?) -> PageResult[TResponse]
  get(session, value) -> TResponse | None
  create(session, data, by?, extra?) -> TResponse
  update(session, value, data, by?) -> TResponse
  delete(session, value, by?) -> None
  exists(session, value) -> bool

  # Internal helpers (not part of public API)
  _base_query(filters?) -> Select
  _find(session, value) -> TDb | None
  _stamp_update(record, by) -> None
```

- `value` is the lookup value for the configured `lookup_field`.
- `by` is the user or system performing the operation, written to
  `created_by` / `updated_by`. Optional -- `None` when no auth context is
  available.
- `data` is any Pydantic model. `model_dump()` is called internally.
- `filters` is a list of SQLAlchemy column expressions applied to `list`.

`PageResult` is defined in `models/page_result.py`. It wraps results in
a `data` + `meta` envelope with pagination metadata (`total`, `limit`,
`offset`, `has_next`, `has_prev`). See `docs/design/list-api.md` for the
full pagination design.

## Behaviour by Operation

### list

- `SELECT * FROM db_model`
- If `has_soft_delete`: adds `WHERE is_deleted = false`.
- If `order_by` is set: adds `ORDER BY {column} ASC/DESC`.
- Optional `filters` are ANDed in.
- Returns `list[TResponse]` via `to_response_model`.

### list_page

- Same base query as `list` (via shared `_base_query` helper).
- Executes a `COUNT(*)` over the filtered base query for `total`.
- Applies `sort` expressions (or falls back to `order_by` from config).
- Applies `OFFSET` and `LIMIT`.
- Returns `PageResult[TResponse]` with computed `has_next` / `has_prev`.

### get

- Queries by `lookup_field = value`.
- If `has_soft_delete`: also filters `is_deleted = false`.
- Returns `TResponse` or `None`.

### create

- Merges `data.model_dump()` with `extra` (extra fields take precedence).
- Sets `version=1`, `created_at`, `updated_at` via `arrow.utcnow()`.
- Sets `created_by` and `updated_by` if `by` is provided.
- Commits, refreshes, returns `TResponse`.

### update

- Finds record via `_find`. Raises `ResourceNotFoundError` if missing.
- If `has_optimistic_locking`: checks `record.version == data.version`,
  raises `VersionConflictError` on mismatch.
- Applies `sqlmodel_update` with `data.model_dump(exclude={"version"})`.
- Calls `_stamp_update(record, by)`: increments `version`, sets `updated_at`,
  `updated_by`.
- Commits, refreshes, returns `TResponse`.

### delete (soft)

- Finds record via `_find`. Raises `ResourceNotFoundError` if missing.
- Sets `is_deleted=True`.
- Calls `_stamp_update(record, by)`.
- Commits. Returns `None`.

### delete (hard)

- Finds record via `_find`. Raises `ResourceNotFoundError` if missing.
- `session.delete(record)`. Commits. Returns `None`.

### exists

- Delegates to `_find`. Returns `True` if a record is found, `False` otherwise.
- Soft delete filter applies when `has_soft_delete` is True.

## `extra` on create

The `extra` parameter injects fields that are not part of the input model --
typically server-generated values (IDs, slugs, computed fields).

```python
super().create(session, data, by=by, extra={"slug": generate_slug()})
```

`extra` is merged after `data.model_dump()`. Fields in `extra` take
precedence over fields in `data`.

## DB Model Requirements

Capabilities are auto-detected from the db_model at `CrudConfig` construction
time. `lookup_field` and `order_by` field names are validated at init --
misconfigured models raise `ValueError` immediately, not at the first DB call.

| Field        | Auto-detected when present | Notes                               |
|---|---|---|
| `version`    | `has_optimistic_locking`   | Integer, default 1. Can be overridden via `optimistic_locking=False`. |
| `created_at` | `has_timestamps`           | Datetime. Detected together with `updated_at`. |
| `updated_at` | `has_timestamps`           | Datetime. Detected together with `created_at`. |
| `is_deleted` | `has_soft_delete`          | Boolean, default False. Can be overridden via `soft_delete=False`. |
| `created_by` | `has_stamp_by`             | String, nullable. If absent, `by` is silently ignored on create. |
| `updated_by` | `has_stamp_by`             | String, nullable. If absent, `by` is silently ignored on update/delete. |

None of these fields are strictly required. The repository adapts its
behaviour based on which capabilities are detected (or explicitly configured).

## Implementation Notes

### Location

- `CrudConfig` -- `database/crud/config.py`
- `CrudRepository` -- `database/crud/repository.py`
- `PageResult` -- `models/page_result.py`
- Public exports -- `database/crud/__init__.py`

`database/crud/` is explicitly not domain-specific code. It is a candidate
for extraction into a shared package.

### Type parameters

`CrudRepository[TDb, TResponse]` uses `Generic[TDb, TResponse]` where:
- `TDb` is bound to `SQLModel`.
- `TResponse` is bound to `BaseModel`.

Input and base models are not type parameters -- they are only used at call
sites. This keeps the generic surface minimal.

### Config at class level (inheritance pattern)

`crud_config` is declared as a class attribute. `__init__` detects it via
`hasattr` and does not require subclasses to call `super().__init__()`:

```python
class WidgetService(CrudRepository[Widget, WidgetResponse]):
    crud_config = CrudConfig(...)
```

### Lookup

`_find` builds the filter dynamically from `lookup_field`:

```python
col = getattr(cfg.db_model, cfg.lookup_field)
statement = select(cfg.db_model).where(col == value)
```

`lookup_field` is validated against the DB model at `CrudConfig` construction
time.

### Timestamps

All timestamps use `arrow.utcnow().datetime`. `_stamp_update` is the single
place that increments `version` and sets `updated_at` / `updated_by` --
called by both `update` and soft `delete`.

### Exceptions

- `ResourceNotFoundError` -- raised by `update` and `delete` when the record
  is not found. (`get` returns `None` instead of raising.)
- `VersionConflictError` -- raised by `update` when `has_optimistic_locking`
  is True and versions do not match.

Both are defined in `exceptions.py`. Exception handlers map them to
HTTP 404 / 409 respectively.
