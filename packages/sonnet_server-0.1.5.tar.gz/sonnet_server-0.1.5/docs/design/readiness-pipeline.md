# Readiness Pipeline

## Status

Implemented. Annotation-based registration complete. Server pipeline auto-built
from registry. CLI pipelines remain imperative.

## Problem

The server needs to verify its dependencies (database, messaging) before accepting
traffic, and report the result through the `/health-check` endpoint. The checks must
run at startup, and again on each health-check request with appropriate caching for
expensive operations.

The secondary constraint is extensibility: adding a new check or a new stage should
not require editing a central wiring file. New modules that own their own checks
should be able to register them without touching shared infrastructure.

## Design

### Concepts

**Check** -- a single verifiable condition. Implements `ReadinessCheck`, has a name,
runs `_execute()` and returns a `ReadinessCheckResult`. Two configuration flags:

- `is_critical` -- if True, failure stops the enclosing stage immediately.
- `run_once` -- if True, the result is cached after the first execution. Subsequent
  calls return the cached result. Useful for checks whose condition cannot change
  after startup (e.g. DB initialization).

**Stage** -- a named, ordered group of checks. Configuration flags:

- `is_critical` -- if True, stage failure stops the entire pipeline.
- `fail_fast` -- if True, stop the stage on the first check failure (subsequent
  checks in the stage are skipped and reported as skipped).

**Pipeline** -- executes stages in declaration order. Transitions the server through
`STARTING -> CHECKING -> OPERATIONAL | DEGRADED | ERROR`.

### Server state transitions

```
STARTING
  |
  v
CHECKING  (pipeline begins)
  |
  +-- all stages pass                 --> OPERATIONAL
  |
  +-- non-critical stage fails        --> DEGRADED
  |
  +-- critical stage fails            --> ERROR
```

`DEGRADED` means the server is serving traffic but something is wrong (e.g. schema
is behind). `ERROR` means the server did not start cleanly.

### Check statuses

| Status | Meaning |
|---|---|
| `success` | Check passed |
| `warning` | Check passed with caveats |
| `failed` | Check failed |
| `not_applicable` | Check skipped because precondition not met (expected) |
| `skip_stage` | Check signals remaining checks in stage should be skipped |
| `skipped` | Check was skipped due to fail-fast or a prior skip_stage result |

### Annotation-based registration

Stages and checks register themselves via decorators at import time, mirroring
the `@handles` pattern in the messaging system. No central wiring file.

```python
# stages.py -- marker classes only, no behavior
@readiness_stage(order=1, is_critical=False, fail_fast=True)
class DatabaseStage:
    """Database connectivity and schema validation."""

@readiness_stage(order=2, is_critical=False, fail_fast=False)
class MessagingStage:
    """Message broker connectivity."""


# checks/database_health_check.py
@readiness_check(stage=DatabaseStage, is_critical=True, run_once=False, order=2)
class DatabaseHealthCheck(ReadinessCheck):
    def _execute(self) -> ReadinessCheckResult:
        ...
```

`checks/__init__.py` imports all stage and check modules to trigger registration,
then `build_pipeline_from_registry()` assembles the pipeline from the global
registries.

Stage execution order is controlled by `order=` on `@readiness_stage`. Check
execution order within a stage is controlled by `order=` on `@readiness_check`.

### Registry isolation in tests

Both decorators accept an optional `registry=` parameter. Pass an isolated
`StageRegistry()` or `CheckRegistry()` instance in tests to avoid polluting the
global singletons:

```python
isolated = StageRegistry()

@readiness_stage(order=1, registry=isolated)
class MyStage:
    pass
```

### CLI pipelines

CLI operations (`server check`, `server-cli db check`) use their own
imperative pipeline builders in `cli/checks/pipeline_builders.py`. They pick
specific check classes by hand because they need different subsets with different
stage configuration (e.g. basic connection check before running migrations, full
schema check after). CLI pipelines are not affected by the registry.

## Current pipeline (server)

| Order | Stage | fail_fast | is_critical | Checks (in order) |
|---|---|---|---|---|
| 1 | `database` | yes | no | `db_initialization` (critical, run_once), `database_health_check` (critical), `database_schema` |
| 2 | `messaging` | no | no | `messaging_check` (run_once) |

## Adding a new check

1. Create the check class in the appropriate location (currently `checks/`,
   eventually inside the owning module).
2. Decorate with `@readiness_check(stage=<StageClass>, ...)`.
3. Import the module in `checks/__init__.py` to trigger registration.

No other files need to change.

## Adding a new stage

1. Add a marker class in `checks/stages.py` decorated with `@readiness_stage(order=N)`.
2. Write checks that reference the new stage class.

## Key files

```
readiness_pipeline/
  base.py          -- ReadinessCheck ABC
  builder.py       -- ReadinessPipelineBuilder (imperative, used by CLI)
  enums.py         -- CheckStatus, ServerState
  executor.py      -- PipelineExecutor (runs stages in order)
  stage.py         -- ReadinessStage (runs checks, handles fail_fast)
  check_executor.py -- CheckExecutor (runs a single check, wraps exceptions)
  processor.py     -- ResultProcessor (aggregates results, handles skip_stage)
  calculator.py    -- ResultCalculator (derives server state from stage results)
  pipeline.py      -- ReadinessPipeline (top-level, manages server state transitions)
  registry.py      -- StageRegistry, CheckRegistry, decorators, build_pipeline_from_registry

checks/
  stages.py        -- DatabaseStage, MessagingStage (marker classes)
  database_initialization.py
  database_health_check.py
  database_schema_check.py
  messaging_check.py
  __init__.py      -- triggers registration, exposes get_readiness_pipeline()

cli/checks/
  pipeline_builders.py  -- imperative CLI pipeline builders (stays separate)
```

## API

`GET /health-check` returns the result of the last pipeline execution. The pipeline
runs at startup and on every request (checks with `run_once=True` return cached
results). Response shape:

```json
{
  "status": "ok",
  "server_state": "operational",
  "checks": [
    {
      "check_name": "db_initialization",
      "stage_name": "database",
      "status": "success",
      "message": "...",
      "details": {},
      "run_once": true,
      "executed_at": "2026-03-13T16:32:59Z",
      "execution_time_ms": 0.04
    }
  ]
}
```

`status` is `"ok"` when `server_state` is `operational`, `"degraded"` when degraded,
`"error"` when in error state.
