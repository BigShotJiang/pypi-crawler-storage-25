# Managed Cache

> Status: Implemented (Phase 1 + Phase 2)
> Last updated: 2026-03-15
> Issues: #34 (closed), #35 (closed)

## Problem

The server has two independent TTLCache implementations with nearly
identical structure:

| Cache | Location | Cross-process sync |
|---|---|---|
| Schema definitions | `schema_registry/services/schema_registry_client.py` | Yes -- `SchemaDefinitionChanged` event via PgChannel |
| Audit event action map | `audit_events/services/audit_event_service.py` | No -- planned (#22) |

Both follow the same pattern: `cachetools.TTLCache` with a `_MISSING`
sentinel, lazy read-through population, `None`-caching for absent
entries, and TTL as a safety net against missed invalidation. The schema
registry client adds three invalidation granularities (single key, owner
prefix, full clear) and cross-process sync via the messaging router. The
audit event cache has only full-clear invalidation and no cross-process
sync.

More caches will be needed as the platform grows (tenant config,
application settings, HDS schema resolution, terminology expansions).
Each new cache currently requires:

1. Copy-pasting the TTLCache + sentinel boilerplate.
2. Defining a module-specific event type (e.g. `FooChanged`).
3. Writing a module-specific listener that calls the right invalidation method.
4. Wiring the event to the messaging router at bootstrap.
5. Adding introspection properties ad hoc.
6. Adding a manual invalidation endpoint ad hoc.

Steps 2-4 are the most error-prone. The audit event cache skipped them
entirely (#22 is still open), meaning multi-instance deployments serve
stale action mappings indefinitely within the TTL window.

## Solution

Extract a shared `ManagedCache[K, V]` class that encapsulates the
read-through, invalidation, cross-process sync, and introspection
patterns. Each module provides only the cache-miss loader function. The
cache module handles everything else.

The cache module lives at `sonnet_server/cache/` -- shared infrastructure,
same level as `sonnet_server/messaging/` and `sonnet_server/database/`.

## Architecture

### Read path

```
Consumer
    |
    v
ManagedCache.get(key)
    |
    +-- hit --> return cached value
    |
    +-- miss --> loader(key) --> store in backend --> return value
```

The loader is a plain callable provided by the owning module. It
typically runs a DB query via the service layer.

### Write / invalidation path

```
Service mutates data
    |
    v
ManagedCache.invalidate(key)            <-- local eviction
    |
    v
MessageRouter.emit(CacheInvalidated)    <-- cross-process fan-out
    |
    v  (messaging transport -- PgChannel, NATS, ...)
    |
Other processes receive CacheInvalidated
    |
    v
CacheRegistry.get(cache_name).evict(key)  <-- remote eviction
```

A single event type (`CacheInvalidated`) and a single listener serve
all caches. No per-module event types or listeners needed for cache
invalidation.

Modules that need domain-specific events for purposes beyond cache
invalidation (audit logging, downstream processing) continue to emit
their own events. Cache invalidation is decoupled from domain semantics.

### Distributed and near-cache modes

```
NEAR_CACHE mode:

ManagedCache.aget(key)
    |
    +-- L1 LocalBackend (in-process, fast, replicated)
    |       |  miss
    |       v
    +-- L2 DistributedBackend / Redis (shared, larger, network hop)
    |       |  miss
    |       v
    +-- aload() --> DB
```

The backend is pluggable. `LocalBackend` (TTLCache wrapper) supports
`LOCAL` and `REPLICATED` modes. `DistributedBackend` (Redis) supports
`DISTRIBUTED` mode. `NearCacheBackend` composes L1 (LocalBackend) +
L2 (DistributedBackend) for `NEAR_CACHE` mode. The `_create_backend`
factory in `cache.py` selects the correct backend based on `CacheMode`.

L2 failure handling: `NearCacheBackend` degrades gracefully when Redis
is unreachable -- L1 continues serving, failures are logged at DEBUG
level, and TTL bounds the staleness window.

Cross-process invalidation always goes through the messaging transport --
the same `CacheInvalidated` event regardless of backend. No coupling between
cache mode and transport implementation.

### Sync vs async API

`LOCAL` and `REPLICATED` modes use `LocalBackend` (in-process dict)
and expose a **synchronous** API: `get`, `get_or_load`, `put`,
`invalidate`, `invalidate_all`.

`DISTRIBUTED` and `NEAR_CACHE` modes use async backends (Redis) and
expose an **async** API: `aget`, `aget_or_load`, `aput`,
`ainvalidate`, `ainvalidate_all`. Async overrides use `aload()` instead
of `load()` (default `aload()` delegates to `load()` so sync loaders
work with the async API).

Consumers choose the API based on the cache mode. Existing `REPLICATED`
caches use the sync API unchanged. Future `DISTRIBUTED` caches use
the async API in async FastAPI handlers.

## Design

### CacheConfig

Pydantic model for cache configuration. Serializable for logging,
admin API responses, and debug output.

```python
class CacheConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    name: str                         # unique identifier, e.g. "schema_definitions"
    maxsize: int = 512                # maximum entries before LRU eviction
    ttl: int = 300                    # seconds, safety net expiration
    mode: CacheMode = CacheMode.REPLICATED  # deployment mode
```

Cache subclasses declare config as class attributes. `ManagedCache.__init__`
materializes them into a `CacheConfig` instance:

```python
class MyCache(ManagedCache[str, MyModel | None]):
    name = "my_cache"
    maxsize = 256
    ttl = 300
    mode = CacheMode.REPLICATED   # default, explicit for clarity

    def load(self, key: str) -> MyModel | None: ...
```

The `CacheConfig` instance is accessible as `self.config` and
serializes cleanly:

```python
cache = MyCache()
cache.config
# CacheConfig(name='my_cache', maxsize=256, ttl=300, mode=<CacheMode.REPLICATED: 'replicated'>)
cache.config.model_dump()
# {'name': 'my_cache', 'maxsize': 256, 'ttl': 300, 'mode': 'replicated'}
```

`name` is the cache identity. It appears in log messages, the
`CacheInvalidated` event payload, and the cache endpoints.
It must be unique across all caches in the process.

`mode` determines the deployment mode (see `CacheMode` enum).
`REPLICATED` (default) emits `CacheInvalidated` events for cross-process
fan-out. `LOCAL` disables event emission. `DISTRIBUTED` uses Redis
(no events needed -- inherently consistent). `NEAR_CACHE` combines
L1 local + L2 Redis with event-driven L1 eviction.

### CacheStats

Pydantic model for runtime cache statistics. Returned by the admin
API and available on every cache instance.

```python
class CacheStats(BaseModel):
    config: CacheConfig
    size: int
    hits: int
    misses: int
    invalidations: int
    hit_rate: float
```

`CacheStats` embeds `CacheConfig` so that a single `stats()` call
returns both configuration and runtime counters. This serializes
directly to the admin API response without transformation.

### CacheBackend protocol

```python
class CacheBackend(Protocol[K, V]):
    def get(self, key: K) -> V | Missing: ...
    def put(self, key: K, value: V) -> None: ...
    def delete(self, key: K) -> bool: ...
    def delete_by(self, predicate: Callable[[K], bool]) -> int: ...
    def clear(self) -> int: ...
    def keys(self) -> list[K]: ...
    def __len__(self) -> int: ...
    @property
    def maxsize(self) -> int: ...
```

`Missing` is a sentinel type (not `None`) to distinguish cache miss
from cached `None`. Same pattern as today's `_MISSING`, but shared.

`delete_by` enables prefix-style invalidation (e.g. "all entries where
`key[0] == owner_id`") without coupling the backend to key structure.

### LocalBackend

Wraps `cachetools.TTLCache`. Used for `LOCAL` and `REPLICATED` modes,
and as the L1 tier in `NEAR_CACHE` mode. LRU eviction at `maxsize`,
TTL expiration, and `None` caching via the `MISSING` sentinel.

### ManagedCache[K, V]

The core abstraction. Generic over key type `K` and value type `V`.
Designed to be subclassed -- each cache is a concrete class that
declares its config via class attributes and provides a `load()` method.

```python
class ManagedCache(Generic[K, V]):
    # -- Class attributes (override in subclass for declarative style) --
    name: str                              # required, unique identifier
    maxsize: int = 512                     # maximum entries before LRU eviction
    ttl: int = 300                         # seconds, safety net expiration
    mode: CacheMode = CacheMode.REPLICATED # deployment mode

    def __init__(
        self,
        config: CacheConfig | None = None,
        backend: CacheBackend[K, V] | None = None,
    ) -> None:
        """Build CacheConfig from class attributes (or use provided config),
        create backend.

        For declarative use: called by the CacheRegistry on first get().
        For programmatic use: called directly with an explicit config.
        """
        ...

    # -- Optional overrides --
    def load(self, key: K) -> V: ...         # sync read-through (LOCAL/REPLICATED)
    async def aload(self, key: K) -> V: ...  # async read-through (DISTRIBUTED/NEAR_CACHE)

    # -- Sync API (LOCAL / REPLICATED) --
    def get(self, key: K) -> V | Missing: ...
    def get_or_load(self, key: K) -> V: ...
    def put(self, key: K, value: V) -> None: ...
    def invalidate(self, key: K) -> None: ...
    def invalidate_by(self, predicate: Callable[[K], bool]) -> int: ...
    def invalidate_all(self) -> int: ...

    # -- Async API (all modes, required for DISTRIBUTED/NEAR_CACHE) --
    async def aget(self, key: K) -> V | Missing: ...
    async def aget_or_load(self, key: K) -> V: ...
    async def aput(self, key: K, value: V) -> None: ...
    async def ainvalidate(self, key: K) -> None: ...
    async def ainvalidate_all(self) -> int: ...

    # -- Introspection --
    @property
    def config(self) -> CacheConfig: ...
    @property
    def size(self) -> int: ...
    @property
    def stats(self) -> CacheStats: ...
```

The constructor has two modes:

- **Declarative** (no `config` argument): reads class attributes
  (`name`, `maxsize`, `ttl`, `mode`), merges with any `@cache`
  decorator overrides, and builds a `CacheConfig`. The `_create_backend`
  factory selects the correct backend for the mode. This is how the
  `CacheRegistry` creates instances.
- **Programmatic** (explicit `config`): uses the provided `CacheConfig`
  directly. For dynamic or test caches.

#### Read: get vs get_or_load

Two read methods accommodate both usage styles:

**`get(key)`** checks the backend only. Returns the cached value on
hit, or `MISSING` on miss. Does not call `load()`. The caller decides
what to do on miss.

**`get_or_load(key)`** checks the backend. On miss, calls `load(key)`,
stores the result (including `None`), and returns it. Raises
`NotImplementedError` if `load()` is not overridden. This is the
read-through convenience method.

Both increment hit/miss counters.

#### put

**`put(key, value)`** stores a value in the backend directly. Used
when the domain code handles loading itself and wants to populate the
cache explicitly.

#### load (optional)

**`load(key)`** is called by `get_or_load()` on cache miss. Override
it to enable the read-through pattern. If not overridden, the default
raises `NotImplementedError` -- the cache is then used in get/put
mode only.

#### Invalidation

**`invalidate(key)`** evicts a single entry from the backend. In
`REPLICATED` and `NEAR_CACHE` modes, emits a `CacheInvalidated` event
via the message router for cross-process fan-out. The event carries
the cache name and a serialized key.

**`invalidate_by(predicate)`** evicts all entries where `predicate(key)`
returns `True`. Useful for owner-scoped invalidation. Emits a single
`CacheInvalidated` event with `scope="all"` and `key=None` (receivers
must clear their entire cache because predicates cannot be serialized
across processes). In practice, the predicate pattern covers the
existing `invalidate_owner(owner_id)` use case.

**`invalidate_all()`** clears the entire backend. Emits a
`CacheInvalidated` event with `key=None`.

Counters are process-local and not persisted. They reset on process
restart. Useful for operational dashboards and health checks.

### CacheInvalidated event

A single event type for all caches. Replaces per-module invalidation
events for cache purposes.

```python
class CacheInvalidated(BaseModel):
    cache_name: str
    key: str | None = None       # JSON-serialized key, or None for full clear
    scope: Literal["key", "all"] = "key"
```

When `scope="key"` and `key` is set, the receiver evicts that single
entry. When `scope="all"` or `key` is `None`, the receiver clears the
entire cache. The `invalidate_by` path emits `scope="all"` because
predicate functions cannot be serialized across processes.

### @cache decorator

Registers a `ManagedCache` subclass with the `CacheRegistry` at import
time. Same pattern as `@handles` which registers handlers in the
`HandlerRegistry` at import time.

```python
from sonnet_server.cache import cache, ManagedCache


@cache
class ActionCache(ManagedCache[str, str | None]):
    name = "audit_event_actions"
    maxsize = 256
    ttl = 300

    def load(self, action: str) -> str | None:
        ...
```

The decorator can optionally carry config overrides, similar to how
`@handles` carries a `retry` policy:

```python
@cache(maxsize=1024, ttl=600)
class ActionCache(ManagedCache[str, str | None]):
    name = "audit_event_actions"

    def load(self, action: str) -> str | None:
        ...
```

Annotation values override class attributes. This is useful when the
same cache class is reused with different tuning (unlikely but
possible), or when you prefer to keep config out of the class body.

Under the hood, the decorator calls
`get_cache_registry().register_class(cls, **overrides)`. The class is
stored but not instantiated yet -- instantiation is lazy (see below).

### CacheRegistry

Central registry that owns the lifecycle of all caches in the process.
Serves four purposes:

1. **Class registration** -- `@cache` registers cache classes at import time.
2. **Lazy instantiation** -- the registry creates the singleton instance
   on first `get()` call (not at import time).
3. **Invalidation dispatch** -- the `CacheInvalidated` listener looks
   up the target cache by name and calls `evict()` on it.
4. **Admin introspection** -- the admin API lists all caches with
   config and stats.

```python
class CacheRegistry:
    # -- Registration (import time) --
    def register_class(self, cls: type[ManagedCache], **overrides) -> None: ...

    # -- Access (runtime, lazy instantiation) --
    def get(self, key: type[ManagedCache] | str) -> ManagedCache | None: ...

    # -- Introspection --
    def all(self) -> list[ManagedCache]: ...
    def names(self) -> list[str]: ...
    def stats(self) -> list[CacheStats]: ...
    def configs(self) -> list[CacheConfig]: ...

    # -- Lifecycle --
    def clear(self) -> None: ...    # for testing teardown

@lru_cache
def get_cache_registry() -> CacheRegistry:
    """Singleton CacheRegistry instance."""
    return CacheRegistry()
```

**`register_class(cls, **overrides)`** stores the cache class and any
config overrides. Called by the `@cache` decorator at import time. Does
not create the instance yet. Validates `name` uniqueness immediately.

**`get(key)`** accepts either the cache class or the cache name string.
On first call for a given cache, creates the instance (reads class
attributes + overrides, builds `CacheConfig`, creates `LocalBackend`).
Subsequent calls return the same instance.

```python
# By class (type-safe, preferred in service code)
cache = get_cache_registry().get(ActionCache)

# By name (used by admin API and CacheInvalidated listener)
cache = get_cache_registry().get("audit_event_actions")
```

**`configs()`** returns `CacheConfig` for all registered caches,
including those not yet instantiated. Useful for admin introspection
("what caches are defined?") without forcing instantiation.

**`stats()`** returns `CacheStats` for instantiated caches only
(stats require a live instance with counters).

#### Registration and instantiation lifecycle

```
Module import (e.g. audit_event_service.py)
    |
    v
@cache decorator runs
    |
    v
get_cache_registry().register_class(ActionCache)
    |  -> stores class + config overrides
    |  -> validates name uniqueness
    |  -> does NOT create instance
    v
Class is registered, config is queryable
    ...
    (later, at runtime)
    ...
Service calls get_cache_registry().get(ActionCache)
    |
    v  (first call only)
Registry creates ActionCache() instance
    |  -> reads class attributes + overrides
    |  -> builds CacheConfig
    |  -> creates LocalBackend
    v
Cache instance is live, discoverable by class or name
    |
    v  (all subsequent calls)
get(ActionCache) returns the same instance
```

This two-phase lifecycle (register at import, instantiate on first use)
mirrors how `@handles` works: handlers are registered at import time
but only wired to channels at bootstrap.

#### Why the registry owns instances (not the cache class)

- **Single source of truth.** One place manages all cache instances.
  No hidden singletons scattered across module files.
- **Lazy instantiation.** Caches that are never accessed (e.g. in a
  test that only exercises one module) are never created.
- **Admin visibility.** The registry can list all registered caches
  (including not-yet-instantiated ones) for diagnostic purposes.
- **Testability.** Tests can `clear()` the registry between runs to
  ensure isolation. No `@lru_cache` to reset.

### Listener

One listener handles all cache invalidation events:

```python
@handles(CacheInvalidated)
async def on_cache_invalidated(event: CacheInvalidated) -> None:
    cache = get_cache_registry().get(event.cache_name)
    if cache is None:
        return  # cache not present in this process -- expected, not an error
    if event.key is not None and event.scope == "key":
        cache.evict(deserialize_key(event.key))
    else:
        cache.evict_all()
```

`evict` / `evict_all` are internal methods that bypass event emission
(to avoid infinite loops). The public `invalidate` / `invalidate_all`
methods emit events and then call `evict` / `evict_all` locally.

### Partial deployments

When the modular monolith is split into separate processes, not all
caches are present in every process. A terminology process does not
have `ActionCache`; an auditing process does not have
`SchemaDefinitionCache`. This is safe at two levels:

**1. Broker level.** All processes share the same PgChannel (or NATS
subject) and receive all `CacheInvalidated` events. If a process does
not have the cache module deployed at all, the `CacheInvalidated`
event type is not in its TypeRegistry. The broker dispatcher silently
ignores it (returns `None` from `_resolve_event_class`). No error, no
warning.

**2. Listener level.** If a process has the cache module but not a
specific cache (e.g. it has `SchemaDefinitionCache` but not
`ActionCache`), the listener runs but `get_cache_registry().get(name)`
returns `None`. The listener returns silently. No error, no warning.

| Scenario | Behavior | Log level |
|---|---|---|
| Process has the cache | Evict locally | TRACE (if logging eviction) |
| Process has cache module but not this cache | Listener no-ops | None |
| Process does not have cache module | Event ignored at broker level | None |

**Important:** the `cache is None` path must **not** log at WARNING or
ERROR level. It is normal and expected in partial deployments. TRACE
or DEBUG at most, and only when explicitly enabled for cache debugging.

## Defining a cache

Three ways to define a cache, from highest to lowest level:

### 1. Declarative (standard -- recommended)

Subclass `ManagedCache`, declare config as class attributes, annotate
with `@cache`. The registry manages the singleton instance.

```python
from sonnet_server.cache import cache, ManagedCache


@cache
class SchemaDefinitionCache(ManagedCache[tuple[str, str | None], SchemaDefinitionResponse | None]):
    """Cached schema definitions, keyed by (owner_id, scope_id)."""

    name = "schema_definitions"
    maxsize = 512
    ttl = 300

    def load(self, key: tuple[str, str | None]) -> SchemaDefinitionResponse | None:
        return get_schema_registry_service().get_active(key[0], key[1])
```

Use it:

```python
from sonnet_server.cache import get_cache_registry

cache = get_cache_registry().get(SchemaDefinitionCache)
schema = cache.get_or_load(("trs_abc", None))
```

### 2. Declarative with annotation config

Same as above, but config values are passed via the `@cache` decorator
instead of (or in addition to) class attributes. Annotation values
override class attributes.

```python
@cache(maxsize=1024, ttl=600)
class SchemaDefinitionCache(ManagedCache[tuple[str, str | None], SchemaDefinitionResponse | None]):
    name = "schema_definitions"

    def load(self, key: tuple[str, str | None]) -> SchemaDefinitionResponse | None:
        return get_schema_registry_service().get_active(key[0], key[1])
```

### 3. Programmatic (low-level)

Create a `ManagedCache` directly and register it manually. No class
definition needed. For one-off, dynamic, or test caches.

```python
from sonnet_server.cache import ManagedCache, CacheConfig, get_cache_registry

my_cache = ManagedCache(
    config=CacheConfig(name="my_dynamic_cache", maxsize=64, ttl=120),
)
get_cache_registry().register_instance(my_cache)

# Use it
my_cache.put("key", "value")
my_cache.get("key")
```

This is the lowest level. The declarative forms build on top of it.

### What the base class provides

| Class attribute | Type | Default | Purpose |
|---|---|---|---|
| `name` | `str` | (required) | Unique identifier, used in events, logs, admin API |
| `maxsize` | `int` | `512` | Maximum entries before LRU eviction |
| `ttl` | `int` | `300` | Seconds, safety net expiration |
| `mode` | `CacheMode` | `REPLICATED` | Deployment mode: `LOCAL`, `REPLICATED`, `DISTRIBUTED`, `NEAR_CACHE` |

| Method / property | Inherited | Override? | Notes |
|---|---|---|---|
| `load(key) -> value` | raises `NotImplementedError` | Override for sync read-through | `LOCAL` / `REPLICATED` |
| `aload(key) -> value` | delegates to `load()` | Override for async read-through | `DISTRIBUTED` / `NEAR_CACHE` |
| `get(key)` | yes | Rarely | Sync, returns `MISSING` on miss |
| `get_or_load(key)` | yes | Rarely | Sync, calls `load()` on miss |
| `put(key, value)` | yes | Rarely | Sync |
| `invalidate(key)` | yes | Rarely | Sync, emits event in REPLICATED/NEAR_CACHE |
| `invalidate_by(predicate)` | yes | Rarely | Sync |
| `invalidate_all()` | yes | Rarely | Sync |
| `aget(key)` | yes | Rarely | Async variant |
| `aget_or_load(key)` | yes | Rarely | Async, calls `aload()` on miss |
| `aput(key, value)` | yes | Rarely | Async variant |
| `ainvalidate(key)` | yes | Rarely | Async variant |
| `ainvalidate_all()` | yes | Rarely | Async variant |
| `config`, `size`, `stats` | yes | No | Sync, always available |

### Two usage styles

#### Style A -- Read-through (cache handles loading)

Override `load()`. Use `get_or_load()`. The cache fetches on miss.

```python
@cache
class ActionCache(ManagedCache[str, str | None]):
    """Maps audit event action strings to type_id."""

    name = "audit_event_actions"
    maxsize = 256
    ttl = 300

    def load(self, action: str) -> str | None:
        session = get_current_session()
        record = session.exec(
            select(AuditEvent).where(AuditEvent.action == action)
        ).first()
        return record.type_id if record is not None else None
```

Service:

```python
def resolve_action(self, action: str) -> str | None:
    return get_cache_registry().get(ActionCache).get_or_load(action)
```

Use when: loading is a simple lookup that the cache class can own.

#### Style B -- Explicit get/put (domain code handles loading)

Do not override `load()`. Use `get()` + `put()`. The domain code
controls when and how data enters the cache.

```python
@cache
class ActionCache(ManagedCache[str, str | None]):
    """Maps audit event action strings to type_id."""

    name = "audit_event_actions"
    maxsize = 256
    ttl = 300
    # no load() -- domain code manages population
```

Service:

```python
def resolve_action(self, action: str) -> str | None:
    action_cache = get_cache_registry().get(ActionCache)
    cached = action_cache.get(action)
    if cached is not MISSING:
        return cached
    # Domain logic: transform, validate, conditional loading...
    type_id = self._resolve_from_db(action)
    action_cache.put(action, type_id)
    return type_id
```

Use when: loading logic depends on service state, requires
transformation, is conditional, or the cache is populated as a
side effect of another operation (e.g. cache-aside after a write).

Both styles share the same invalidation, cross-process sync,
introspection, and admin API. The choice is purely about who
owns the loading logic.

### Adding domain-specific methods

Subclasses can add convenience methods for domain-specific
invalidation patterns:

```python
@cache
class SchemaDefinitionCache(ManagedCache[tuple[str, str | None], SchemaDefinitionResponse | None]):
    ...

    def invalidate_owner(self, owner_id: str) -> None:
        """Evict all entries for an owner (any scope)."""
        self.invalidate_by(lambda k: k[0] == owner_id)
```

### Where cache classes live

Cache classes live in the module that owns the data. The `@cache`
decorator registers them with the `CacheRegistry` at import time --
no central wiring file needed.

```
modules/schema_registry/
    services/
        schema_registry_client.py   <-- @cache SchemaDefinitionCache
modules/audit_events/
    services/
        audit_event_service.py      <-- @cache ActionCache
```

This follows the same pattern as `@handles`: definitions are local
to the module, registration is automatic on import, wiring is
handled by the infrastructure layer.

## Usage

The module provides two things: a **loader** (what to fetch on cache
miss) and **invalidation calls** (when cached data is stale). The cache
module handles everything else: storage, TTL, sentinel, cross-process
sync, stats.

### Responsibilities

| Concern | Module (consumer) | Cache module |
|---|---|---|
| What to cache | Provides `load()` override or explicit `put()` calls | Stores, evicts by LRU/TTL |
| When to invalidate | Calls `invalidate()` / `invalidate_all()` after mutations | Evicts locally, emits `CacheInvalidated` for fan-out |
| How to store | -- | Backend (TTLCache / Redis), LRU eviction, TTL expiry |
| Cross-process sync | -- | Automatic via `CacheInvalidated` event + messaging router |
| Introspection | -- | `config`, `stats`, admin API (all Pydantic, serializable) |

### AuditEventService example (before / after)

This is the `audit_events` module, which caches the `action -> type_id`
mapping used on every audit trail event ingestion.

**Before** -- manual TTLCache, sentinel, read-through, no cross-process
sync:

```python
_CACHE_MAX_SIZE = 256
_CACHE_TTL = 300
_MISSING = object()

class AuditEventService(CrudRepository[AuditEvent, AuditEventResponse]):

    def __init__(self) -> None:
        super().__init__()
        self._action_cache: TTLCache[str, str | None] = TTLCache(
            maxsize=_CACHE_MAX_SIZE, ttl=_CACHE_TTL,
        )

    def resolve_action(self, action: str) -> str | None:
        cached = self._action_cache.get(action, _MISSING)
        if cached is not _MISSING:
            return cached
        session = get_current_session()
        record = session.exec(
            select(AuditEvent).where(AuditEvent.action == action)
        ).first()
        type_id = record.type_id if record is not None else None
        self._action_cache[action] = type_id
        return type_id

    def invalidate_action_cache(self) -> None:
        count = len(self._action_cache)
        if count:
            self._action_cache.clear()

    def create(self, data, by=None, **kwargs):
        result = super().create(data, by=by, extra={...}, **kwargs)
        self.invalidate_action_cache()
        return result

    def update(self, value, data, by=None):
        result = super().update(value, data, by=by)
        self.invalidate_action_cache()
        return result

    def delete(self, value, by=None):
        super().delete(value, by=by)
        self.invalidate_action_cache()
```

**After** -- cache defined as a decorated class, accessed via registry:

```python
# -- Cache definition (in same file or separate) --------------------

@cache
class ActionCache(ManagedCache[str, str | None]):
    """Maps audit event action strings to type_id."""

    name = "audit_event_actions"
    maxsize = 256
    ttl = 300

    def load(self, action: str) -> str | None:
        session = get_current_session()
        record = session.exec(
            select(AuditEvent).where(AuditEvent.action == action)
        ).first()
        return record.type_id if record is not None else None


# -- Service --------------------------------------------------------

class AuditEventService(CrudRepository[AuditEvent, AuditEventResponse]):

    def resolve_action(self, action: str) -> str | None:
        return get_cache_registry().get(ActionCache).get_or_load(action)

    def create(self, data, by=None, **kwargs):
        result = super().create(data, by=by, extra={...}, **kwargs)
        get_cache_registry().get(ActionCache).invalidate_all()
        return result

    def update(self, value, data, by=None):
        result = super().update(value, data, by=by)
        get_cache_registry().get(ActionCache).invalidate_all()
        return result

    def delete(self, value, by=None):
        super().delete(value, by=by)
        get_cache_registry().get(ActionCache).invalidate_all()
```

What changed:

| Concern | Before | After |
|---|---|---|
| Cache definition | Inline TTLCache + sentinel + constants | `@cache` class with declarative attributes |
| Cache lifecycle | Created in service `__init__` | Registry-managed singleton |
| Read-through | 7 lines (get/check sentinel/query/store) | `get(ActionCache).get_or_load(action)` |
| Sentinel | Manual `_MISSING` object + comparison | Internal to `ManagedCache` |
| Module-level constants | `_CACHE_MAX_SIZE`, `_CACHE_TTL`, `_MISSING` | Class attributes on `ActionCache` |
| Local invalidation | `self._action_cache.clear()` | `.invalidate_all()` |
| Cross-process sync | Missing (open issue #22) | Automatic -- `invalidate_all()` emits `CacheInvalidated`, PgChannel fans out, generic listener evicts in every other process |
| Introspection | None | `.config`, `.stats` available via admin endpoint |

What did **not** change:

- The module still owns the DB query (in `ActionCache.load()`).
- The module still decides **when** to invalidate (after create/update/delete).
- The public API (`resolve_action`) is unchanged for callers.

### SchemaRegistryClient example

The schema registry client has a richer invalidation surface (single
key, owner prefix, full clear). The cache class adds a domain-specific
`invalidate_owner()` method:

```python
@cache
class SchemaDefinitionCache(ManagedCache[tuple[str, str | None], SchemaDefinitionResponse | None]):
    """Cached schema definitions, keyed by (owner_id, scope_id)."""

    name = "schema_definitions"
    maxsize = 512
    ttl = 300

    def load(self, key: tuple[str, str | None]) -> SchemaDefinitionResponse | None:
        return get_schema_registry_service().get_active(key[0], key[1])

    def invalidate_owner(self, owner_id: str) -> None:
        """Evict all entries for an owner (any scope)."""
        self.invalidate_by(lambda k: k[0] == owner_id)
```

The `SchemaRegistryClient` accesses the cache via the registry:

```python
class SchemaRegistryClient:

    @property
    def _cache(self) -> SchemaDefinitionCache:
        return get_cache_registry().get(SchemaDefinitionCache)

    def get_schema_definition(self, owner_id, scope_id=None):
        return self._cache.get_or_load((owner_id, scope_id))

    def invalidate(self, owner_id, scope_id=None):
        self._cache.invalidate((owner_id, scope_id))

    def invalidate_owner(self, owner_id):
        self._cache.invalidate_owner(owner_id)

    def invalidate_all(self):
        self._cache.invalidate_all()
```

The `SchemaDefinitionChanged` event and its listener remain for domain
semantics (other modules may subscribe for non-cache reasons), but the
listener body simplifies to calling `invalidate()` / `invalidate_all()`
which already handles cross-process fan-out.

### Adding a cache to a new module

Define the class with `@cache`, access via registry. Cross-process
sync, introspection, and admin invalidation work out of the box.

```python
@cache
class TenantConfigCache(ManagedCache[str, TenantConfig | None]):
    """Cached tenant configuration, keyed by tenant_id."""

    name = "tenant_config"
    maxsize = 128
    ttl = 600

    def load(self, tenant_id: str) -> TenantConfig | None:
        session = get_current_session()
        return session.exec(
            select(TenantConfig).where(TenantConfig.tenant_id == tenant_id)
        ).first()


class TenantConfigService:

    def get_config(self, tenant_id: str) -> TenantConfig | None:
        return get_cache_registry().get(TenantConfigCache).get_or_load(tenant_id)

    def update_config(self, tenant_id: str, data) -> TenantConfig:
        result = self._do_update(tenant_id, data)
        get_cache_registry().get(TenantConfigCache).invalidate(tenant_id)
        return result
```

## Cache endpoints

Cache endpoints are system-level routes (like `/ping`, `/health-check`,
`/messaging`, `/messaging/ping`), not domain routes under `/api`. They are always
enabled and profile-independent.

```
GET  /cache                       --> 200, list all caches with stats
GET  /cache/configs               --> 200, list all registered caches (including not-yet-instantiated)
GET  /cache/ping                  --> 200, built-in round-trip verification (put-get-invalidate)
GET  /cache/{name}                --> 200, single cache detail (lazy instantiation)
POST /cache/{name}/invalidate     --> 204, clears a named cache
POST /cache/invalidate            --> 204, clears all caches
```

Mounted in `app.py` alongside other system routers:

```python
app.include_router(cache_router, prefix="")
```

### Introspection response

`GET /cache` returns all registered caches with their current stats.
This is the primary diagnostic tool for cache health.

```json
{
  "caches": [
    {
      "config": {
        "name": "schema_definitions",
        "maxsize": 512,
        "ttl": 300,
        "mode": "replicated"
      },
      "size": 42,
      "hits": 18340,
      "misses": 42,
      "invalidations": 7,
      "hit_rate": 0.998
    },
    {
      "config": {
        "name": "audit_event_actions",
        "maxsize": 256,
        "ttl": 300,
        "mode": "replicated"
      },
      "size": 12,
      "hits": 95021,
      "misses": 12,
      "invalidations": 3,
      "hit_rate": 0.999
    }
  ]
}
```

The response is the direct serialization of `CacheStats.model_dump()`
for each registered cache. No transformation needed -- the Pydantic
models serialize directly to the API response.

The endpoint reads from `get_cache_registry().stats()` which iterates
over all registered caches and collects their `CacheStats`. Counters
are process-local and reset on restart.

### Single cache detail

`GET /cache/{name}` returns the `CacheStats` for a single cache,
or 404 if the name is not registered.

### Diagnostic signals

| Signal | Meaning |
|---|---|
| `hit_rate` close to 1.0 | Cache is effective, most reads avoid DB |
| `hit_rate` low | Cache too small, TTL too short, or data changes frequently |
| `size` near `maxsize` | Cache is full, LRU eviction is active -- consider increasing `maxsize` |
| `invalidations` high | Frequent writes -- verify this is expected |

The existing `POST /api/schema_definitions/cache/invalidate` can be
kept as an alias or deprecated in favor of the generic endpoint.

## Module layout

```
sonnet_server/cache/
    __init__.py            -- public surface: ManagedCache, CacheConfig,
                              CacheMode, CacheStats, cache, get_cache_registry
    cache.py               -- ManagedCache[K, V] base class + _create_backend factory
    config.py              -- CacheMode, CacheConfig, CacheStats (Pydantic models)
    registry.py            -- CacheRegistry singleton, @cache decorator
    serialization.py       -- shared key/value serialization (JSON)
    events.py              -- CacheInvalidated event
    listeners.py           -- @handles(CacheInvalidated) dispatcher
    api.py                 -- /cache router (system endpoints) + PingCache
    backends/
        __init__.py        -- CacheBackend protocol, MissingSentinel, MISSING
        local.py           -- LocalBackend (LOCAL, REPLICATED modes)
        distributed.py     -- DistributedBackend / Redis (DISTRIBUTED mode)
        near_cache.py      -- NearCacheBackend: L1 + L2 (NEAR_CACHE mode)
```

## Phases

### Phase 1 -- Extract and consolidate (implemented)

- `ManagedCache` base class with `LocalBackend`
- `CacheMode` enum: `LOCAL`, `REPLICATED`, `DISTRIBUTED`, `NEAR_CACHE`
- `CacheConfig`, `CacheStats` (Pydantic models), `CacheRegistry`
- `CacheInvalidated` event (Pydantic model) and generic listener
- Migrate `SchemaRegistryClient` to `@cache SchemaDefinitionCache` (mode: `REPLICATED`)
- Migrate `AuditEventService` to `@cache ActionCache` (mode: `REPLICATED`, closes #22)
- Cache system endpoints (`GET /cache`, `GET /cache/{name}`, `POST /cache/{name}/invalidate`)

### Phase 2 -- Distributed and near-cache modes (implemented)

- `DistributedBackend` (Redis) implementing async `CacheBackend` protocol
- `NearCacheBackend` composing `LocalBackend` (L1) + `DistributedBackend` (L2)
- Shared `serialization.py` for JSON key/value encoding
- Async API on `ManagedCache`: `aget`, `aget_or_load`, `aput`, `ainvalidate`, `ainvalidate_all`
- `get_redis_pool()` singleton, `SONNET_SERVER_CACHE_STORE` setting
- `CacheStoreCheck` readiness check (pings Redis on startup)
- `NearCacheBackend` graceful L2 failure handling (L1 continues serving)
- Unit tests via `fakeredis`, integration tests via Redis 7 testcontainer

### Phase 3 -- Advanced features (deferred)

- Cache warming (pre-populate on startup from DB or distributed store)
- Cache-aside write-through (update cache on write, not just invalidate)
- Per-key TTL (different expiration for different entry types)
- Metrics export (Prometheus counters for hit/miss/eviction)

## Decisions

### Transport for cache invalidation events

See [ADR-0011](../../../docs/adr/0011-cache-invalidation-transport.md).

Summary: `CacheInvalidated` events are emitted via `get_message_router().emit()`
with no cache-module-level transport configuration. If a dedicated channel
is needed for cache events, configure it in the messaging router -- the
cache module does not change.

## Thread safety

Same model as today: assumes a single async event loop per process
(standard uvicorn/FastAPI). Multi-process deployments are safe (each
process has its own `ManagedCache` instance with its own `LocalBackend`).
Cross-process coherence is handled by the messaging layer. If threaded
workers are introduced, `LocalBackend` must be wrapped with a lock.

## Files

| File | Role |
|---|---|
| `cache/__init__.py` | Public surface (`ManagedCache`, `CacheMode`, `CacheConfig`, `CacheStats`, `cache`, `get_cache_registry`, `MISSING`) |
| `cache/cache.py` | `ManagedCache[K, V]` base class + `_create_backend` factory |
| `cache/config.py` | `CacheMode` enum, `CacheConfig`, `CacheStats` (Pydantic models) |
| `cache/serialization.py` | Shared JSON key/value serialization |
| `cache/registry.py` | `CacheRegistry` singleton, `@cache` decorator |
| `cache/events.py` | `CacheInvalidated` event (Pydantic model) |
| `cache/listeners.py` | Generic invalidation listener |
| `cache/api.py` | `/cache` system endpoints + `PingCache` |
| `cache/backends/__init__.py` | `CacheBackend` protocol, `MissingSentinel`, `MISSING` |
| `cache/backends/local.py` | `LocalBackend` (LOCAL, REPLICATED modes) |
| `cache/backends/distributed.py` | `DistributedBackend` / Redis (DISTRIBUTED mode) + `get_redis_pool` |
| `cache/backends/near_cache.py` | `NearCacheBackend`: L1 + L2 (NEAR_CACHE mode) |
