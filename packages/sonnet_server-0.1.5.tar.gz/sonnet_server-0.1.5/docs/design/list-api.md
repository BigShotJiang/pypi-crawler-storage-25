# List API Design -- Sorting, Filtering, Pagination

> Status: Implemented (offset pagination + sorting + search)
> Last updated: 2026-02-19

## Problem

Every list endpoint needs sorting, filtering, and pagination. Without a
consistent pattern these are implemented ad hoc per entity, producing
inconsistent query param names, different response shapes, and a client
that has to handle each endpoint differently.

---

## Research Summary

Before deciding, we surveyed how major production APIs handle this.

### Stripe

- **Pagination**: cursor-based. `starting_after` and `ending_before` take an
  object ID. Default limit 10, max 100.
- **Envelope**: `{ data: [], has_more: bool, url: string, object: "list" }`.
  No total count.
- **Sorting**: not exposed -- results are always reverse chronological.
- **Filtering**: simple query params per resource.

### GitHub REST API

- **Pagination**: offset-based. `page` + `per_page` (default 30, max 100).
  Navigation via RFC 5988 `Link` response headers (`rel="next"`, `rel="prev"`,
  `rel="first"`, `rel="last"`). No total count in body -- `X-Total-Count`
  header on some endpoints.
- **Envelope**: plain array. Pagination metadata only in headers.
- **Sorting**: `sort=field` + `direction=asc|desc`.
- **Filtering**: simple query params.

### Linear (GraphQL-first, REST secondary)

- **Pagination**: relay-style cursor. `after`, `before`, `first`, `last`.
- **Envelope**: `{ nodes: [], pageInfo: { hasNextPage, endCursor, startCursor } }`.
  No total count.
- **Filtering**: filter objects passed as query params or GraphQL variables.

### Observations

- **Cursor pagination** is universal for time-series / append-only data
  (Stripe, Linear). Avoids the "page drift" problem when records are inserted
  mid-pagination.
- **Offset pagination** is used by GitHub for browsable, manageable lists
  where jumping to a specific page is useful and total count matters for UI.
- **Stripe's envelope** (`data` + `has_more`) is the most widely copied
  pattern. Simple, unambiguous.
- **Total count** is conspicuously absent from Stripe and Linear. GitHub
  provides it via header. It is expensive on large tables (requires a
  separate `COUNT(*)` query) but necessary for a traditional pager UI.
- **Plain array responses** (GitHub) are simplest but lock out pagination
  metadata without a breaking change.
- **GraphQL-first APIs** (Linear, Shopify) are deprecating REST list endpoints
  entirely in favour of GraphQL.

---

## TanStack Query (client-side) implications

The control app uses TanStack Query. Key constraints that shape the API design:

1. **Query key = all params.** TanStack Query automatically refetches when
   the query key changes. Filters, sort, and pagination must all be
   representable as stable, serialisable values.

2. **URL is the source of truth** for list state (pagination, filters, sort).
   TkDodo (React Query maintainer) recommends `useSearchParams` so that list
   state is bookmarkable and survives browser back/forward.

3. **`placeholderData: keepPreviousData`** prevents flash-of-empty while
   paginating. The client needs `has_next` / `has_prev` booleans to disable
   navigation buttons while placeholder data is shown.

4. **`select` for envelope transformation.** The client transforms the
   response envelope inside TanStack Query's `select` option, not in the
   component. The API envelope shape only needs to be consistent -- the
   exact field names are abstracted away in query hooks.

5. **Invalidation after mutation.** After create/update/delete, the client
   calls `invalidateQueries({ queryKey: ['organizations'] })` which
   invalidates all list variants (all pages, all filter combinations) at
   once. This works because query keys are structured hierarchically:
   `['organizations', 'list', { params }]`.

---

## Decisions

### Pagination

**Two modes, chosen per entity type:**

#### Offset pagination -- for manageable entity lists

Used for: organizations, event types, users, and other configuration entities
where total count is meaningful and jumping to a page is a valid use case.

```
GET /api/organizations?limit=20&offset=0
```

Response:
```json
{
  "data": [...],
  "meta": {
    "total": 342,
    "limit": 20,
    "offset": 0,
    "has_next": true,
    "has_prev": false
  }
}
```

- `total` enables a pager UI ("Page 1 of 18").
- `has_next` / `has_prev` are derived convenience booleans -- the client
  should not have to compute `offset + limit < total`.
- Default `limit` is 20. Max `limit` is 100 (enforced server-side).
- If `limit` is not provided, the server uses the default. If `limit` exceeds
  the max, the server clamps it silently.

**Why not cursor here:** offset pagination is adequate at our scale (up to
tens of thousands of records per entity). Cursor pagination adds complexity
without benefit when total count and page jumping are required.

**Why not plain array:** adding pagination metadata later would be a breaking
change. We ship the envelope from day one even when the full result fits on
one page.

**Why not RFC 5988 Link headers only (GitHub style):** headers are invisible
in most REST clients and harder to consume in TanStack Query. The envelope
is self-contained and more practical.

#### Cursor pagination -- for time-series / high-volume data

Used for: events, audit logs, and any append-only entity where volume is
high and total count is not meaningful.

```
GET /api/events?limit=50&cursor=eyJpZCI6IjAxOWM3NiJ9
```

Response:
```json
{
  "data": [...],
  "meta": {
    "limit": 50,
    "has_next": true,
    "next_cursor": "eyJpZCI6IjAxOWM3NiJ9",
    "has_prev": false,
    "prev_cursor": null
  }
}
```

- Cursor is an opaque base64-encoded string. Clients treat it as a token,
  never parse it.
- No `total` -- counting millions of rows is expensive and not useful for
  an infinite-scroll / load-more pattern.
- `has_prev` + `prev_cursor` enable backward navigation if needed.

**Why not offset here:** offset on a high-volume time-series table with
frequent inserts causes page drift (records skipped or duplicated as pages
are fetched). Cursor pagination is stable.

### Sorting

Single `sort` parameter. Field name for ascending, `-field` prefix for
descending. Multiple fields comma-separated.

```
GET /api/organizations?sort=name
GET /api/organizations?sort=-created_at
GET /api/organizations?sort=-created_at,name
```

- `-` prefix for descending is concise and widely understood (JSON:API,
  many major APIs).
- `CrudConfig.order_by` defines the server default applied when `sort` is
  absent. If no default is configured, the database's natural order applies
  (effectively insertion order for Postgres).
- The API layer validates that requested sort fields are on the allowlist for
  the entity. Unknown sort fields return 400.

**Rejected alternatives:**
- `sort_by=name&order=asc` -- two params for one concept, more verbose.
- `orderBy=name asc` -- mixing field and direction in a single string value
  is harder to parse and less standard.

### Filtering

Two mechanisms:

- **`search=`** -- case-insensitive substring match on the primary text field
  (`ILIKE '%value%'`). Used by CRUD entity endpoints (`SortableListParams`).
- **Flat field params + `q=` expression** -- declarative field filters and a
  human-readable boolean query string. Used by filterable endpoints
  (organizations, users, audit trail) via `FilterableListParams`. Both sources
  are AND-merged server-side.

Query expression operator symbols: `=` (eq), `!=` (neq), `~` (contains /
substring), `^` (starts-with / prefix), `>` `>=` `<` `<=` (comparison).
`~` aligns with JQL semantics. `^` is the prefix/starts-with operator.

Full protocol, operator reference, and `FilterDef` mechanics:
`docs/design/filtering-framework.md`.

Soft-deleted records are always excluded at the repository level; no
`is_deleted` filter is exposed to clients.

### Response envelope

All list endpoints return the same envelope shape. Entity-specific response
models are in `data`. The `meta` object is fixed.

```json
{
  "data": [ { ...entity fields... } ],
  "meta": {
    "total": 342,
    "limit": 20,
    "offset": 0,
    "has_next": true,
    "has_prev": false
  }
}
```

`total` is omitted for cursor-paginated endpoints (replaced by `next_cursor`
and `prev_cursor`).

**Why `data` + `meta` and not flat:**
- Flat responses (`{ items: [], total: 0, ... }`) mix entity data with
  metadata at the same level. Clients that destructure the response have to
  explicitly exclude metadata fields.
- The `data` / `meta` split is unambiguous and consistent regardless of
  entity type.

**Why not Stripe's shape (`{ data: [], has_more: bool }`):**
- Stripe omits `total` intentionally (too expensive at their scale).
  At our scale, `total` is cheap and required for a pager UI.

---

## Layer responsibilities

```
HTTP Request
    |
    v
API layer (FastAPI route)
  - Parse and validate query params (limit, offset, sort, search, filters)
  - Enforce allowlists (valid sort fields, valid filter fields)
  - Call service method with typed params
    |
    v
Service layer
  - Translate sort param to SQLAlchemy column expression
  - Translate search param to ILIKE filter
  - Translate entity-specific filter params to SQLAlchemy expressions
  - Call repository list_page / list_cursor
    |
    v
Repository (CrudRepository)
  - Execute SELECT with WHERE, ORDER BY, LIMIT, OFFSET
  - Execute COUNT(*) for total (offset mode only)
  - Return PageResult[TResponse] (already contains data + meta envelope)
    |
    v
API layer
  - Return PageResult directly as HTTP 200
```

The repository does not know about query params or HTTP. The API layer does
not build SQLAlchemy expressions. The service layer owns the translation.

---

## Repository interface additions

```
CrudRepository[TDb, TResponse]

  # Existing
  list(session, filters?) -> list[TResponse]

  # New -- offset pagination
  list_page(session, limit, offset, filters?, sort?) -> PageResult[TResponse]

  # New -- cursor pagination
  list_cursor(session, limit, cursor?, filters?, sort?) -> CursorResult[TResponse]
```

`PageResult` and `CursorResult` are generic Pydantic models. `PageResult`
uses a nested `data` + `meta` structure matching the response envelope:

```python
class PageMeta(BaseModel):
    total: int
    limit: int
    offset: int
    has_next: bool
    has_prev: bool

class PageResult(BaseModel, Generic[T]):
    data: list[T]
    meta: PageMeta

    @classmethod
    def of(cls, items, total, limit, offset) -> PageResult[T]:
        """Factory that computes has_next / has_prev from the arguments."""

class CursorResult(BaseModel, Generic[T]):
    data: list[T]
    meta: CursorMeta  # Not yet implemented

class CursorMeta(BaseModel):
    limit: int
    has_next: bool
    next_cursor: str | None
    has_prev: bool
    prev_cursor: str | None
```

The repository returns `PageResult` directly -- the API layer does not need
to wrap the response in an additional envelope.

The existing `list` method is kept unchanged for internal use (e.g. populating
dropdowns, seeding, bulk operations that do not need pagination).

---

## What is not in scope

- **Full-text search** -- `search` is `ILIKE` only. Full-text search (Postgres
  `tsvector`, Elasticsearch) is a future concern.
- **Field selection** (`?fields=id,name`) -- not needed now; GraphQL handles
  this.
- **Bulk export** -- no `limit=all` or streaming endpoint. Maximum page size
  is 100. Bulk export is a separate concern.
- **Infinite scroll / `useInfiniteQuery`** -- the client uses standard
  `useQuery` with explicit page controls. `useInfiniteQuery` is not needed
  for the current UI patterns.
