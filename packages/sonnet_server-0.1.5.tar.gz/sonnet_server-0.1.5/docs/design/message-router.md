# Messaging -- Event Routing and Delivery

## Status

Implemented. All phases complete. PgChannel (default) and NatsChannel are live and
benchmarked. Publisher protocol and dynamic sink management added for outbound-only
delivery.

## Problem

The legacy in-process event bus could not deliver events to other server processes
(cross-process cache invalidation fails silently with multiple workers) or publish
domain events to external message brokers for external consumers.

These are not separate problems. They are one problem: routing events to multiple
destinations. The solution is a router that treats in-process handlers and
broker-backed channels uniformly.

## Pattern Lineage

This design follows the **Content-Based Router** pattern from *Enterprise Integration
Patterns* (Hohpe/Woolf, 2003). The same pattern is implemented in MassTransit (.NET),
Wolverine (.NET), Spring Cloud Stream (Java), and Axon Framework (Java):

- **Channel is an atomic destination.** One instance = one protocol + one connection +
  one destination. No sub-topics.
- **In-process dispatch is just another channel.** Not a special case.
- **Emitter is transport-unaware.** The publish call never mentions the destination.
- **Wiring is programmatic.** Code-based configuration at startup.

## Core Concepts

### Event

A Pydantic `BaseModel` instance. A fact that happened. Immutable. The emitter
creates it, everyone else reads it.

### Channel

A named, bidirectional delivery path for events. One instance = one protocol +
one connection + one destination (one NATS subject, one Postgres NOTIFY channel).

Three concrete implementations:

- **`PgChannel`** -- Postgres LISTEN/NOTIFY. Default channel, auto-derived from
  `DATABASE_URL`. Zero extra configuration required. Publish opens a short-lived
  connection per call. The listener uses a persistent connection with automatic
  reconnect and exponential backoff.

- **`NatsChannel`** -- NATS pub/sub. Requires `nats-py` (`pip install sonnet-server[nats]`).
  Single persistent connection for both publish and subscribe. nats-py handles
  reconnection natively.

- **`InProcessChannel`** -- in-process dispatch. Calls handlers directly without
  serialization. `supports_dispatch()` returns `True`.  Available via `memory://`
  broker URL. Used for testing and explicit opt-out from cross-process delivery.

Want two Kafka topics? Two `KafkaChannel` instances. The router sees them as
independent channels.

### Publisher

An outbound-only sink for events. Minimal protocol: `name`, `url`, `publish()`,
`ping()`, `start()`, `stop()`. No `subscribe()`, no `add_handler()`, no
`dispatch()`.

Use `Publisher` for dynamic outbound sinks where the server only sends and
external consumers subscribe independently -- for example, per-tenant audit trail
forwarding to an external NATS subject or Kafka topic.

The `url` property stores the original broker URL the publisher was created from
(e.g. `nats+publish://host:4222?subject=audit.tenant_a`). Used for reconciliation:
compare against desired config from DB to detect whether a publisher needs replacing.

`NatsPublisher` is the NATS implementation. It connects on `start()` but does not
subscribe. Registered under the `nats+publish://` scheme.

### Sink

`Sink = Channel | Publisher`. The router's `bind()` accepts either. On emit, the
router delivers to all bound sinks. For `Channel` it uses `publish()` or
`dispatch()` depending on `supports_dispatch()`. For `Publisher` it always uses
`publish()`.

### Binding

Connects an event type to a sink. An event type can be bound to multiple sinks.
A sink can carry multiple event types. An optional `predicate` restricts delivery
to matching events.

### MessageRouter

The central coordinator. Holds bindings (event type -> sinks). On `emit(event)`,
looks up all sinks bound to that event type and delivers to each.

Services call `router.emit(event)` and know nothing about channels or publishers.

## Three Layers

Strict separation of concerns. Each layer knows only its own concern.

| Layer | Knows about | Does not know about |
|---|---|---|
| Service (publish) | Event types, router | Channels, brokers, handlers |
| Handler (consume) | Event types | Channels, brokers, who emitted |
| Wiring (route) | Event types, channels, handlers | Business logic |

### Service layer (publish)

```python
class AuditTrailService:
    def ingest(self, tenant_id: str, event: AuditLogEventPayload) -> AuditLogEventResponse:
        # ... validate, persist ...
        get_message_router().emit(AuditTrailEventReceived(event_id=response.id, ...))
        return response
```

### Handler layer (consume)

Handlers are plain async functions decorated with `@handles`:

```python
from sonnet_server.messaging import handles

@handles(SchemaDefinitionChanged)
async def on_schema_changed(event: SchemaDefinitionChanged) -> None:
    get_schema_registry_client().invalidate(event.owner_id, event.scope_id)
```

The `@handles` decorator registers the handler in the global `HandlerRegistry` at import
time. The wiring layer reads the registry at bootstrap and assigns channels -- handlers
never reference channels directly.

Class-based handlers with constructor DI are also supported:

```python
@handles(AuditTrailEventReceived)
class AuditDeliveryHandler:
    def __init__(self, delivery_service: DeliveryService):
        self._delivery = delivery_service  # injected from ServiceRegistry

    async def handle(self, event: AuditTrailEventReceived) -> None:
        await self._delivery.send(event)
```

### Wiring layer (route)

`messaging/wiring.py` is the only place that knows about channel topology. It creates
the internal channel and wires all `@handles` handlers to it at bootstrap:

```python
def bootstrap_messaging() -> MessageRouter:
    router = get_message_router()
    channel = _create_channel()      # PgChannel by default
    router.wire_handlers(channel)    # wires all @handles handlers
    return router
```

Additional outbound sinks (per-tenant forwarding, external audit delivery) are added
via `router.bind()` after bootstrap -- for example, from a DB-loaded sink configuration.

## Routing

The event type is the primary routing key. Two maps:

```
bindings:  event_type -> [Binding(sink, predicate), ...]   publish side
           managed per channel                              consume side
```

`bind()` and `subscribe()` are independent:

```python
# Outbound-only publisher: forward audit events per tenant, no local handler
router.bind(
    AuditTrailEventReceived,
    NatsPublisher("audit.tenant_a", "nats://broker:4222"),
    predicate=lambda e: e.tenant_id == "tnt_a",
)

# Inbound only: receive schema changes from the broker
router.subscribe(SchemaDefinitionChanged, pg_channel, on_schema_changed)

# Both: publish AND consume (cross-process fan-out)
router.bind(SchemaDefinitionChanged, pg_channel)
router.subscribe(SchemaDefinitionChanged, pg_channel, on_schema_changed)
```

### Content-based filtering

An optional `predicate` on `bind()` restricts delivery to matching events:

```python
# All audit events -> global analytics sink
router.bind(AuditTrailEventReceived, nats_analytics)

# Only events for tenant_a -> tenant-specific sink
router.bind(AuditTrailEventReceived, nats_tenant_a,
            predicate=lambda e: e.tenant_id == "tnt_a")
```

Predicates run in the router before serialization. Filtered-out events are never
serialized or sent to the sink.

## Emit Methods

| Method | Context | Behavior |
|---|---|---|
| `router.emit(event)` | async or sync | Fire-and-forget. Schedules task if loop running, else submits to thread pool. |
| `await router.emit_and_wait(event)` | async | Waits for in-process results. Broker channels receive but results are not awaited. |
| `router.emit_sync(event)` | sync | Blocking. Waits for in-process results. |
| `await router.emit_to(event, name)` | async | Emit directly to a named sink, bypassing bindings. For service-driven outbound delivery. |

`emit_to` is the primary API for domain modules that need to publish events to
a specific outbound destination (e.g. a per-tenant publisher loaded from DB config).
The sink must be registered with the router by name. If the name is not found, a
warning is logged and delivery is skipped.

## Dynamic Sink Management

The router manages the full lifecycle of dynamically added sinks. Domain modules
own the _what_ (read config from DB, know the URLs). The router owns the _how_
(lifecycle, serialization, delivery).

### Sink management methods

| Method | Behavior |
|---|---|
| `router.add_sink(sink)` | Register a sink (no start). Implicit on `bind()`. |
| `await router.add_and_start_sink(sink)` | Register and start immediately. For sinks added after bootstrap. |
| `router.get_sink(name)` | Look up a sink by name. Returns `None` if not found. |
| `router.get_sinks_by_prefix(prefix)` | Return all sinks whose name starts with the prefix. For reconciliation. |
| `await router.remove_sink(name)` | Stop and remove a sink by name. Cleans up all bindings. No-op if not found. |
| `await router.replace_sink(name, new)` | Atomic swap: transfer bindings, start new, stop old. Minimises delivery gap. |

### Reconciliation pattern

Domain modules reconcile router state against DB config using prefix-based
sink naming. All sinks owned by a module share a name prefix (e.g. `auditing-`).

```python
# In a @handles(SinkConfigChanged) handler or startup routine:
factory = get_channel_factory()
active = {s.name: s for s in router.get_sinks_by_prefix("auditing-")}
desired = load_sink_configs_from_db()  # returns {name: url}

# Remove stale sinks
for name in set(active) - set(desired):
    await router.remove_sink(name)

# Add new or replace changed sinks
for name, url in desired.items():
    if name not in active:
        publisher = factory.create(url)
        await router.add_and_start_sink(publisher)
    elif active[name].url != url:
        publisher = factory.create(url)
        await router.replace_sink(name, publisher)
```

Reconciliation is idempotent by name. When triggered via `@handles(SinkConfigChanged)`
over the internal PgChannel, every server instance receives the event and reconciles
independently -- no coordinator needed.

## Handler Execution Pipeline

Every handler invocation passes through a composable middleware chain before
reaching the actual handler. Cross-cutting concerns (retry, logging, future:
timeout, circuit breaker) are implemented as standalone middleware functions
and composed in `HandlerExecutor`.

### Middleware chain

The chain signature:

```python
type NextCall = Callable[[Handler, BaseModel], Awaitable[Any]]
type HandlerMiddlewareFn = Callable[[Handler, BaseModel, NextCall], Awaitable[Any]]
```

Each middleware receives the handler, the event, and a `call_next` that invokes
the next middleware (or the handler at the end of the chain). The executor
builds the chain once at construction and calls it on every invocation.

Default stack (outermost first):

```
retry_middleware -> logging_middleware -> _invoke_handler
```

Adding a new cross-cutting concern means writing a new middleware function
and prepending it to `DEFAULT_MIDDLEWARE` or passing a custom list to
`HandlerExecutor`. Nothing else changes.

```python
async def my_middleware(
    handler: Handler,
    event: BaseModel,
    call_next: NextCall,
) -> Any:
    # before
    result = await call_next(handler, event)
    # after
    return result

executor = HandlerExecutor(middlewares=[my_middleware, *DEFAULT_MIDDLEWARE])
```

### Retry with backoff

`retry_middleware` reads the active `RetryPolicy` from a contextvar set by
the executor before calling the chain. Handlers declare their policy via
`@handles`:

```python
from sonnet_server.messaging import handles, RetryPolicy

@handles(AuditTrailEventReceived, retry=RetryPolicy(max_attempts=3, base_delay=0.2))
async def on_audit_event(event: AuditTrailEventReceived) -> None:
    await deliver(event)
```

| Parameter | Default | Description |
|---|---|---|
| `max_attempts` | 1 (no retry) | Total attempts including the first. Must be >= 1. |
| `base_delay` | 0.1s | Initial delay between retries. |
| `backoff_multiplier` | 2.0 | Multiplier applied to delay after each retry. |
| `max_delay` | 10.0s | Upper bound on delay. |

On failure `retry_middleware` retries with exponential backoff. After all
attempts are exhausted the exception is returned (not raised) for error
isolation. Each failed attempt is logged at WARNING; the final failure at
ERROR.

Default: no retry. Handlers opt in explicitly.

### Structured logging

`logging_middleware` wraps the inner chain and logs every invocation with
handler name, event type, duration, and outcome. It does not catch exceptions
-- they propagate up to `retry_middleware`.

| Outcome | Level | Format |
|---|---|---|
| Success | INFO | `Handler 'name' completed for EventType in X.Xms` |
| Transient failure (retrying) | WARNING | `Handler 'name' failed for EventType (attempt N/M) retrying in X.Xs: ErrorType: message` |
| Final failure | ERROR | `Handler 'name' failed for EventType (attempt N/M): ErrorType: message` |

### Correlation context

Every event published through the router carries three tracing fields in
the CloudEvents envelope:

- **`id`** -- unique identifier for this event (UUID, generated on publish).

- **`correlation_id`** -- the same value across an entire causal chain of
  events. Event A triggers a handler that emits event B which triggers a
  handler that emits event C -- all three share the same `correlation_id`.
  If no correlation ID exists in the current context (root event), the
  event's own `id` is used.

- **`causation_id`** -- the `id` of the immediate parent event that caused
  this one. Answers "what specific event triggered _this_ event?"

Example chain:

```
Event A (id=1, correlation_id=1, causation_id=null)     -- root
  -> handler emits Event B
Event B (id=2, correlation_id=1, causation_id=1)        -- caused by A
  -> handler emits Event C
Event C (id=3, correlation_id=1, causation_id=2)        -- caused by B
```

Propagation uses Python `contextvars`. On the receive side, the broker
channel extracts `id` and `correlation_id` from the envelope and sets
context vars before calling handlers. When a handler emits a new event,
the router reads the context: `correlation_id` is inherited, `causation_id`
is set to the current event's `id`. No handler code changes required.

```python
from sonnet_server.messaging import get_correlation_id, get_causation_id

@handles(SomeEvent)
async def on_some_event(event: SomeEvent) -> None:
    # Available automatically during handler execution
    cid = get_correlation_id()
    # Emitting here inherits the correlation chain automatically
    router.emit(DerivedEvent(...))
```

In-process dispatch (`InProcessChannel`) does not reset correlation context --
it inherits whatever is set in the current context.

## Serialization (broker channels)

Events published to broker-backed channels use the **CloudEvents v1.0** envelope,
structured content mode (JSON body):

```json
{
  "id": "a1b2c3d4-...",
  "type": "app.schema_definition_changed",
  "correlation_id": "550e8400-...",
  "causation_id": "6ba7b810-...",
  "data": { "action": "updated", "owner_id": "aet_xxx", ... }
}
```

The `type` field is the dispatch key on the receive side. The `TypeRegistry` maps
between CloudEvents type strings and Pydantic classes. Type names are auto-derived
from class names (`SchemaDefinitionChanged` -> `app.schema_definition_changed`) via
`type_registry.ensure_registered()`, called automatically during `wire_handlers()`.

`correlation_id` and `causation_id` are added automatically by the router (see
Correlation Context below).

`InProcessChannel` skips serialization entirely -- it passes the Pydantic object directly.

## ChannelFactory

Broker channels and publishers are created by URL scheme via `ChannelFactory`. Channel
modules register a creator function under their scheme at import time:

```python
get_channel_factory().register("nats", lambda url: NatsChannel(...))
get_channel_factory().register("nats+publish", lambda url: NatsPublisher(...))
```

The wiring layer calls `get_channel_factory().create(url)` without knowing the type.

### Registered schemes

| Scheme | Type | Notes |
|---|---|---|
| `postgres://` | `PgChannel` | Explicit DSN with `?channel=name` |
| `postgres+listen://` | `PgChannel` | Derives DSN from `DATABASE_URL` |
| `memory://` | `InProcessChannel` | In-process only, no cross-process delivery |
| `nats://` | `NatsChannel` | Bidirectional pub/sub, requires `nats-py` |
| `nats+publish://` | `NatsPublisher` | Outbound-only, requires `nats-py` |

### Broker URL configuration

```bash
# Default (no setting needed): PgChannel from DATABASE_URL, channel=sonnet_internal
# SONNET_SERVER_MESSAGE_BROKER=

# Explicit Postgres DSN (use when DATABASE_URL goes through a pooler)
SONNET_SERVER_MESSAGE_BROKER=postgres://user:pass@host:5432/db?channel=sonnet_internal

# Custom channel name, still reusing DATABASE_URL
SONNET_SERVER_MESSAGE_BROKER=postgres+listen://?channel=my_channel

# NATS
SONNET_SERVER_MESSAGE_BROKER=nats://localhost:4222?subject=sonnet_internal

# In-process only (testing, opt-out from cross-process delivery)
SONNET_SERVER_MESSAGE_BROKER=memory://
```

## Default Channel: PgChannel

When `SONNET_SERVER_MESSAGE_BROKER` is not set, a `PgChannel` is auto-derived from
`SONNET_SERVER_DATABASE_URL` with channel name `sonnet_internal`. Zero extra configuration
required since Postgres is always present.

### Postgres LISTEN/NOTIFY constraints

- Requires a **direct connection** -- PgBouncer in transaction mode breaks `LISTEN`.
  For Supabase: use port 5432, not the pooler (port 6543).
- **8 KB payload limit** on `pg_notify`. Handled by the claim-check pattern on large
  events and a size guard in `PgChannel.publish()`.
- **Fan-out**: all connections `LISTEN`-ing on the same channel receive every `NOTIFY`.
  This is the cross-process cache invalidation mechanism.

### Benchmarks (local Postgres, 10 concurrent clients)

| Metric | PgChannel | NatsChannel |
|---|---|---|
| Requests/sec | 540 | 4,128 |
| Mean latency | 18 ms | 2.4 ms |
| P99 latency | 44 ms | 12 ms |
| Dropped messages (20s) | 0 | 0 |

PgChannel is 7.6x slower due to a new psycopg connection per publish call. Both are
well within typical expected load (dozens of events per minute).

## System Endpoints

Two system endpoints are available for messaging introspection and verification:

```
GET  /messaging       --> 200, router status, sinks, bindings, handlers
POST /messaging/ping  --> 202, emit a test event through the full pipeline
```

### Introspection

`GET /messaging` returns the full messaging topology: whether the router is started,
all registered sinks with reachability, event-type-to-sink bindings, registered
handlers, and available channel factory schemes. This is the passive diagnostic
counterpart to the active ping endpoint.

```bash
curl -s http://localhost:5891/messaging | jq .
```

### Smoke test

`POST /messaging/ping` emits a `MessagingPingEvent` through the full pipeline:

```bash
curl -X POST http://localhost:5891/messaging/ping
# {"trace_id": "...", "channel": "PgChannel", "channel_name": "sonnet_internal"}
```

Check the server log for `messaging ping received (trace_id=...)` to confirm the
full emit -> channel -> dispatch path is working. The `trace_id` in the log matches
the response.

## Current State

Three events are live on the messaging router:

| Event | Emitter | Handler | Purpose |
|---|---|---|---|
| `SchemaDefinitionChanged` | `SchemaRegistryService` | `schema_registry/listeners.py` | Invalidate `SchemaRegistryClient` cache cross-process |
| `AuditTrailEventReceived` | `AuditTrailService` | `audit_trail/listeners.py` | Debug log (POC -- production sinks added via `router.bind()`) |
| `MessagingPingEvent` | `POST /messaging/ping` | `messaging/listeners.py` | Smoke test pipeline |

Default channel: `PgChannel("sonnet_internal")`, derived from `DATABASE_URL`.

## Singleton Access

```python
from sonnet_server.messaging import get_message_router, handles

router = get_message_router()   # @lru_cache singleton
```

The `HandlerRegistry` and `ChannelFactory` are also `@lru_cache` singletons accessed
via `get_handler_registry()` and `get_channel_factory()`.

## Considered Alternatives

### EventBus with bolted-on transport

The earlier design kept the in-process event bus as primary and added an `EventTransport`
protocol as a secondary concern for cross-process replication. This did not extend to
external delivery without adding a third concept ("sinks"). The channel model is simpler:
one concept covers all three cases.

### FastStream

FastStream provides a unified API across NATS, Redis, Kafka, and RabbitMQ with Pydantic
serialization. Rejected because it has no in-process/in-memory broker -- every emit would
require a network round-trip. Building a conforming in-memory broker would require
~500-800 lines against private `_internal` APIs. Remains a candidate if consumers split
into separate services.

### Shared cache (Redis)

Moving caches to Redis eliminates per-process state but replaces in-process lookups with
network hops on every validation call. The point of caching is avoiding the network.

## Relates To

- `SchemaRegistryClient` design: `server/docs/design/schema-registry-client.md`
