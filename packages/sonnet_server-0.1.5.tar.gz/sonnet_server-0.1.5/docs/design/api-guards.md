# API Guards

> Status: Implemented
> Last updated: 2026-03-17

## Problem

Cross-cutting request preconditions -- tenant scoping, authentication,
role-based access -- must run before endpoint logic. Today each endpoint
wires its own validation (or omits it). This leads to duplication,
inconsistency, and a brittle migration path when new preconditions are
introduced.

The server needs a composable mechanism where:

1. Guards are standalone, reusable FastAPI dependencies.
2. Routers declare which guards apply to all their endpoints.
3. Individual endpoints can add stricter guards without repeating the
   router-level ones.
4. Guards that are not yet implemented (e.g. authentication) can exist as
   no-ops, wired into routers today, and replaced with real logic later
   without touching any router or endpoint code.

## Design

### Concepts

**Guard** -- a FastAPI dependency that enforces a precondition on a request.
If the precondition fails, the guard raises an `HTTPException` and the
endpoint never runs. If it succeeds, it may:

- Return a typed result that endpoints can inject (e.g. `TenantContext`).
- Set ambient context via `ContextVar` so services deeper in the call stack
  can read it without parameter passing.
- Return `None` (no-op guards, pure precondition checks).

**Guard chain** -- an ordered list of guards applied to a router. All guards
run before any endpoint on that router. FastAPI caches dependency results
per request, so a guard that appears at both router and endpoint level
executes only once.

**Guarded router** -- a router factory that composes a DB session dependency
with zero or more guard dependencies. Replaces `db_router()` for endpoints
that need cross-cutting preconditions.

### Guarded router factory

A single factory in `api/dependencies.py`:

```python
def guarded_router(*guards, **kwargs) -> APIRouter:
    existing = kwargs.pop("dependencies", [])
    return APIRouter(
        dependencies=[Depends(get_db_session)] + [Depends(g) for g in guards] + existing,
        **kwargs,
    )
```

The DB session dependency is always first (same as `db_router()` today).
Guards follow in declaration order. Additional dependencies passed via
`dependencies=` are appended last.

### Composing guards

Guards are plain FastAPI dependencies. They compose by stacking them in
the `guarded_router()` call:

```python
from sonnet_server.guards import require_auth, require_tenant, require_role

# Auth + tenant scoped
router = guarded_router(require_auth, require_tenant, tags=["audit_trail"])

# Auth + tenant + role restriction
router = guarded_router(require_auth, require_tenant, require_role("admin"), tags=["settings"])

# Auth only, no tenant scope
router = guarded_router(require_auth, tags=["tenants"])

# No guards, just DB session (equivalent to db_router())
router = guarded_router(tags=["system"])
```

### Per-endpoint guard escalation

Router-level guards run on every endpoint. Individual endpoints can add
stricter guards without repeating the router-level ones. FastAPI caches
dependency results per request, so a guard declared at both levels
executes only once:

```python
router = guarded_router(require_auth, require_tenant, tags=["organizations"])

@router.get("/")
def list_orgs(tenant: TenantContext = Depends(require_tenant)):
    ...  # any authenticated user with tenant access

@router.delete("/{org_id}")
def delete_org(
    org_id: str,
    _: None = Depends(require_role("admin")),  # stricter on this endpoint
):
    ...
```

### Ambient context via ContextVar

Guards that produce request-scoped state set a `ContextVar`, mirroring
the database session pattern (`_current_session` / `get_current_session()`
in `database/connection.py`). This allows any service in the call stack
to read the value without receiving it as a parameter.

Example pattern:

```python
_current_tenant: ContextVar[TenantContext | None] = ContextVar("_current_tenant", default=None)

def get_current_tenant() -> TenantContext:
    ctx = _current_tenant.get()
    if ctx is None:
        raise RuntimeError("No tenant context -- called outside a tenant-scoped request")
    return ctx

def require_tenant(...) -> TenantContext:
    # ... validate ...
    _current_tenant.set(context)
    return context
```

Services call `get_current_tenant()`. Services that run outside request
context (background jobs, CLI) must pass the value explicitly, same as
they use `borrow_db_session()` instead of `get_current_session()`.

ContextVar propagation rules are identical to `_current_session` (see
`database-session-management.md`):

| Context | Propagates? |
|---|---|
| Async tasks (`asyncio.create_task`) | Yes (copy at creation) |
| `anyio.to_thread.run_sync` (sync endpoints) | Yes (copy at dispatch) |
| `ThreadPoolExecutor` (fire-and-forget) | No -- must pass explicitly |

### Dependency inversion for guard implementations

Guard infrastructure lives in `guards.py` at the package root
(infrastructure layer). Concrete validation logic often lives in domain
modules (e.g. tenant validation in the `organizations` module).
Infrastructure must not import from domain modules.

The solution uses the same protocol-slot-registration pattern established
in the messaging system (`ChannelFactory.register`) and the readiness
pipeline (`@readiness_check`):

1. **Infrastructure** defines a `Protocol` and a module-level slot
   (`_validator: Protocol | None`), plus `set_*()` / `get_*()` accessors.
2. **Domain module** implements the protocol using its own services.
3. **Wiring layer** (`services/di.py`) imports both sides and connects
   them at startup, before any request can arrive.

```
guards.py (infrastructure)            domain module
  SomeValidator (Protocol)               ConcreteValidator
  _validator slot                          implements Protocol
  set_validator() / get_validator()        uses domain services
  require_something()  ---calls--->  get_validator().validate(...)
                    ^                        |
                    |                   set_validator()
                    |                        |
                services/di.py          wires at startup
```

Infrastructure depends only on the protocol. The domain module depends
on infrastructure (to know the protocol shape). Neither imports the other.
Only `di.py` imports both -- and that is its explicit job.

## Relation to existing patterns

| Pattern | Existing example | Guard equivalent |
|---|---|---|
| Protocol + slot + registration | `ChannelFactory.register()` | `set_tenant_validator()` |
| ContextVar ambient context | `_current_session` / `get_current_session()` | `_current_tenant` / `get_current_tenant()` |
| Router-level dependency | `db_router()` with `Depends(get_db_session)` | `guarded_router()` with guard chain |
| Wiring in `di.py` | `register_factory(TenantService, ...)` | `set_tenant_validator(...)` |

## Key files

| File | Role |
|---|---|
| `guards.py` | Guard dependencies, protocols (`CredentialValidator`, `TenantValidator`, `TenantAccessChecker`), ContextVars |
| `api/dependencies.py` | `guarded_router()`, `db_router()`, `auth_router()`, `tenant_router()` factories |
| `services/di.py` | Wires domain implementations into guard slots at startup |

## Open questions

### db_router deprecation

`guarded_router()` with no guards is functionally identical to `db_router()`.
Whether to deprecate `db_router()` or keep it as a convenience alias is
deferred.

### GraphQL guard integration

GraphQL resolvers use `get_context()` as their dependency entry point.
Guard integration for GraphQL will follow the same ContextVar pattern but
may need a different wiring mechanism. Deferred until GraphQL endpoints
need guard enforcement.

### Guard ordering enforcement

Guards are passed as positional args to `guarded_router()`. The framework
does not enforce ordering (e.g. that `require_auth` comes before
`require_tenant`). This is left to convention and code review. If it
becomes a source of bugs, a declarative ordering mechanism can be added
later.
