# Database Session Management

> Status: Implemented
> Last updated: 2026-02-22

## Overview

Sessions are managed through two public entry points in `database/connection.py`.
All service and repository code obtains the active session via `get_current_session()`
from a `ContextVar` -- no session parameter appears on any service method signature.

The decision to use a `ContextVar` is recorded in `docs/adr/0003-ambient-session-via-context-var.md`.
This document covers the implementation: why each piece is built the way it is,
where the session lifecycle boundaries are, and what must not change.

---

## Two entry points

### `get_db_session()` -- FastAPI requests

An async generator used exclusively as a FastAPI dependency.

```python
async def get_db_session() -> AsyncGenerator[Session]:
    session = _create_session()          # pure in-memory, no I/O
    _current_session.set(session)
    try:
        yield session
    except Exception as e:
        session.rollback()
        raise
    finally:
        _current_session.set(None)
        session.close()
```

Applied at router level via `db_router()`:

```python
router = db_router(tags=["organizations"])   # all routes on this router get a session
```

**Must be an async generator.** If converted to a sync generator, the ContextVar
set breaks. See the section below on why.

### `borrow_db_session()` -- everything outside FastAPI

A synchronous context manager for CLI commands, health checks, alembic utilities,
background threads, and tests.

```python
with borrow_db_session() as session:
    service.do_something()

with borrow_db_session(commit=True) as session:
    session.add(record)
```

Unlike `get_db_session`, this function probes the connection before yielding (see
startup resilience below). It is not suitable for high-frequency use.

---

## Session creation internals

### `_create_session()` -- pure in-memory

```python
def _create_session() -> Session:
    return Session(get_engine())
```

`Session()` does no I/O. The pool does not check out a physical connection until
the first statement executes. Used by `get_db_session` only.

### `_create_session_with_probe()` -- startup resilience

```python
@retry(stop=stop_after_attempt(5), wait=wait_exponential(...), ...)
def _create_session_with_probe() -> Session:
    session = Session(get_engine())
    try:
        session.exec(text("SELECT 1"))
        return session
    except (SQLAlchemyError, OperationalError) as e:
        session.close()           # close before disposal to return connection to pool first
        _engine.dispose()
        _engine = None
        raise
```

Creates a fresh `Session` on every attempt. The session is closed before the
engine is disposed so the connection is properly returned before the pool is torn
down. Used by `borrow_db_session` only.

**Why `borrow_db_session` probes but `get_db_session` does not:**

`borrow_db_session` is called at startup time (health checks, alembic, CLI) when
the database may not yet be ready. Retry with exponential backoff is acceptable
because there is no client waiting on a live HTTP response.

`get_db_session` is called per-request. Retrying a live request with exponential
backoff would spike latency unacceptably. More importantly, a mid-request connection
failure after a write cannot be safely retried -- you cannot know whether the write
committed before the connection dropped. The correct response is to fail fast with
503 (handled by the global `OperationalError` exception handler).

---

## Connection pool

The engine is configured with:

```python
create_engine(
    database_url,
    pool_pre_ping=True,    # silently replaces stale idle connections at checkout
    pool_size=5,
    max_overflow=10,
    pool_recycle=3600,
    pool_timeout=30,
)
```

`pool_pre_ping=True` is the primary mechanism for handling stale connections during
normal operation. When a connection has been idle, the pool issues a lightweight
`SELECT 1` before handing it to the session. This is transparent to all application
code and adds no per-request overhead when connections are healthy.

The explicit `SELECT 1` in `_create_session_with_probe` is separate and serves a
different purpose: verifying the database is reachable at startup, not just that
a pooled connection is still alive.

---

## Why `get_db_session` must be an async generator

FastAPI resolves sync generator dependencies via `contextmanager_in_threadpool`,
which calls `run_in_threadpool(cm.__enter__)`. This means:

1. The generator's body up to `yield` (including `_current_session.set(session)`)
   runs in **worker thread A**.
2. `anyio.to_thread.run_sync` copies the current async context **before** dispatching
   to thread A. The ContextVar change inside thread A is invisible outside it.
3. The sync endpoint function runs in **worker thread B**, which gets a context
   snapshot from step 2 -- where `_current_session` is still `None`.
4. The first `get_current_session()` call in a service raises `RuntimeError`.

As an async generator, `get_db_session` runs directly on the event loop. The
`_current_session.set(session)` call happens in the event loop's own context before
any thread dispatch. When sync endpoints are dispatched via `run_in_threadpool`,
`anyio` calls `copy_context()` at that point -- after the ContextVar is already set.
The worker thread receives the correct context snapshot.

**Do not convert `get_db_session` to a sync generator.** The failure is silent at
startup and only manifests as a `RuntimeError` on the first request.

---

## Failure handling

### Stale connections (steady state)

Handled transparently by `pool_pre_ping`. No application code involved.

### Database down during a request

The first `session.exec()` or `session.commit()` raises `OperationalError`. This
propagates out of the endpoint body and is caught by the global exception handler:

```
OperationalError  ->  503 Service Unavailable  {"error": "database_unavailable"}
SQLAlchemyError   ->  500 Internal Server Error {"error": "database_error"}
```

`OperationalError` is registered before `SQLAlchemyError` because it is a subclass.
FastAPI matches by exact type first, then MRO, so registration order matters.

### Database not ready at startup

`borrow_db_session` calls `_create_session_with_probe`, which retries up to 5
times with exponential backoff (1s to 10s). On each failure the engine is disposed
and rebuilt so the retry attempts a fresh pool against the (hopefully now-available)
database.

The server startup pipeline calls `borrow_db_session` via the `DatabaseHealthCheck`
readiness check. If all retries fail, the startup pipeline fails and the process
exits with code 1.

---

## ContextVar propagation rules

`_current_session` is a `ContextVar`. Its propagation behaviour:

| Context | Propagates? | Notes |
|---|---|---|
| Async tasks (`asyncio.create_task`) | Yes (copy) | Task gets a snapshot at creation time. Changes after creation are not visible. |
| `anyio.to_thread.run_sync` | Yes (copy) | Thread gets snapshot at dispatch time. This is how sync endpoints see the session set by the async generator dependency. |
| `ThreadPoolExecutor` (fire-and-forget) | No | Threads spawned via `concurrent.futures` do not inherit `contextvars` context. |
| `asyncio.run` in a new thread | No | Creates a fresh event loop with a fresh context. |

**Fire-and-forget handlers** (via `EventBus.emit_fire_and_forget`) run in a
`ThreadPoolExecutor` with `asyncio.run`. They cannot call `get_current_session()`.
They must open their own session with `borrow_db_session()` if they need database
access.

**GraphQL resolvers** run inside the same async context as `get_context` (the
context getter dependency). The `get_db_session` async generator sets the ContextVar
before `get_context` returns, so resolvers that call services (which call
`get_current_session()`) work correctly.

---

## Session ownership per call site

| Call site | Entry point | Session opened by |
|---|---|---|
| REST endpoints (via `db_router`) | `get_db_session` | Router-level dependency |
| GraphQL resolvers (via `get_context`) | `get_db_session` | `get_context` dependency |
| Startup health checks | `borrow_db_session` | `DatabaseHealthCheck._execute` |
| Alembic utilities | `borrow_db_session` | `AlembicManager` methods |
| Advisory locks | `borrow_db_session` | `advisory_lock`, `try_advisory_lock` |
| Fire-and-forget handlers | `borrow_db_session` | Handler must open its own |
| Tests | `borrow_db_session` | Test fixture or test body |

---

## Adding a new module

1. Create the router with `db_router(...)` -- no session parameter needed anywhere.
2. Services call `get_current_session()` to obtain the session.
3. No other session-related code is required.

```python
# api/widgets.py
router = db_router(tags=["widgets"])

@router.post("/widgets")
def create_widget(data: WidgetInput, service: WidgetService = Depends(get_widget_service)):
    return service.create(data)   # service calls get_current_session() internally

# services/widget_service.py
def create(self, data: WidgetInput) -> WidgetResponse:
    session = get_current_session()
    ...
```

---

## Key files

| File | Role |
|---|---|
| `database/connection.py` | `ContextVar`, `get_current_session`, `_create_session`, `_create_session_with_probe`, `borrow_db_session`, `get_db_session` |
| `database/__init__.py` | Re-exports `get_current_session`, `get_db_session`, `borrow_db_session` |
| `api/dependencies.py` | `db_router()` helper |
| `exception_handlers.py` | `OperationalError` -> 503, `SQLAlchemyError` -> 500 |
| `docs/adr/0003-ambient-session-via-context-var.md` | Decision record |
