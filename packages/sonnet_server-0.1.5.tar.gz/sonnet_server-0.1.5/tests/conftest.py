"""Pytest configuration for automatic test marking based on directory."""

import os
import sys

import pytest

# Add the src directory to the Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))


@pytest.fixture(autouse=True)
def reset_sonnet_settings():
    """Reset the settings singleton between tests.

    Prevents one test's ``init_settings()`` call or ``get_settings()``
    lazy-init from leaking into subsequent tests.
    """
    from sonnet_server.settings import reset_settings

    reset_settings()
    yield
    reset_settings()


def pytest_collection_modifyitems(items):
    """Automatically mark tests based on their directory location."""
    for item in items:
        test_path = str(item.fspath.relto(item.session.fspath))

        if "tests/unit" in test_path:
            item.add_marker(pytest.mark.unit)
        elif "tests/integration" in test_path:
            item.add_marker(pytest.mark.integration)
        else:
            item.add_marker(pytest.mark.unit)
