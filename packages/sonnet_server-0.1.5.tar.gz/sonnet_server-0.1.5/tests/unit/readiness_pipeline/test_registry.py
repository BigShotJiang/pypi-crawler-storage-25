"""Tests for readiness pipeline annotation-based registration."""

import pytest

from sonnet_server.readiness_pipeline.base import ReadinessCheck
from sonnet_server.readiness_pipeline.models import ReadinessCheckResult
from sonnet_server.readiness_pipeline.registry import (
    CheckEntry,
    CheckRegistry,
    StageMeta,
    StageRegistry,
    _stage_name,
    build_pipeline_from_registry,
    readiness_check,
    readiness_stage,
)

# -- Test fixtures ----------------------------------------------------------


class _SampleCheck(ReadinessCheck):
    """A minimal check for testing."""

    def __init__(self, name: str = "sample", is_critical: bool = False, run_once: bool = False):
        super().__init__(name, is_critical, run_once)

    def _execute(self) -> ReadinessCheckResult:
        return self.success("ok")


class _AnotherCheck(ReadinessCheck):
    def __init__(self, name: str = "another", is_critical: bool = False, run_once: bool = False):
        super().__init__(name, is_critical, run_once)

    def _execute(self) -> ReadinessCheckResult:
        return self.success("ok")


class _ThirdCheck(ReadinessCheck):
    def __init__(self, name: str = "third", is_critical: bool = False, run_once: bool = False):
        super().__init__(name, is_critical, run_once)

    def _execute(self) -> ReadinessCheckResult:
        return self.success("ok")


# -- StageRegistry -----------------------------------------------------------


class TestStageRegistry:
    def test_register_and_retrieve(self):
        registry = StageRegistry()

        class MyStage:
            pass

        meta = StageMeta(order=1, description="test", is_critical=False, fail_fast=True)
        registry.register(MyStage, meta)
        assert registry.get_meta(MyStage) is meta
        assert registry.size == 1

    def test_register_duplicate_raises(self):
        registry = StageRegistry()

        class MyStage:
            pass

        meta = StageMeta(order=1, description="test", is_critical=False, fail_fast=True)
        registry.register(MyStage, meta)
        with pytest.raises(ValueError, match="already registered"):
            registry.register(MyStage, meta)

    def test_get_stages_ordered(self):
        registry = StageRegistry()

        class First:
            pass

        class Second:
            pass

        class Third:
            pass

        registry.register(Third, StageMeta(order=3, description="", is_critical=False, fail_fast=False))
        registry.register(First, StageMeta(order=1, description="", is_critical=False, fail_fast=True))
        registry.register(Second, StageMeta(order=2, description="", is_critical=False, fail_fast=False))

        ordered = registry.get_stages_ordered()
        assert [cls for cls, _ in ordered] == [First, Second, Third]

    def test_clear(self):
        registry = StageRegistry()

        class MyStage:
            pass

        registry.register(MyStage, StageMeta(order=1, description="", is_critical=False, fail_fast=True))
        registry.clear()
        assert registry.size == 0


# -- CheckRegistry -----------------------------------------------------------


class TestCheckRegistry:
    def test_register_and_retrieve(self):
        registry = CheckRegistry()

        class MyStage:
            pass

        entry = CheckEntry(check_class=_SampleCheck, stage_class=MyStage, is_critical=False, run_once=False)
        registry.register(entry)
        assert registry.size == 1

    def test_get_checks_for_stage(self):
        registry = CheckRegistry()

        class StageA:
            pass

        class StageB:
            pass

        entry_a = CheckEntry(check_class=_SampleCheck, stage_class=StageA, is_critical=False, run_once=False, order=1)
        entry_b = CheckEntry(check_class=_AnotherCheck, stage_class=StageB, is_critical=False, run_once=False)

        registry.register(entry_a)
        registry.register(entry_b)

        assert len(registry.get_checks_for_stage(StageA)) == 1
        assert len(registry.get_checks_for_stage(StageB)) == 1
        assert registry.get_checks_for_stage(StageA)[0].check_class is _SampleCheck

    def test_checks_ordered_within_stage(self):
        registry = CheckRegistry()

        class MyStage:
            pass

        registry.register(CheckEntry(check_class=_ThirdCheck, stage_class=MyStage, is_critical=False, run_once=False, order=3))
        registry.register(CheckEntry(check_class=_SampleCheck, stage_class=MyStage, is_critical=False, run_once=False, order=1))
        registry.register(CheckEntry(check_class=_AnotherCheck, stage_class=MyStage, is_critical=False, run_once=False, order=2))

        checks = registry.get_checks_for_stage(MyStage)
        assert [e.check_class for e in checks] == [_SampleCheck, _AnotherCheck, _ThirdCheck]

    def test_clear(self):
        registry = CheckRegistry()

        class MyStage:
            pass

        registry.register(CheckEntry(check_class=_SampleCheck, stage_class=MyStage, is_critical=False, run_once=False))
        registry.clear()
        assert registry.size == 0


# -- @readiness_stage decorator -----------------------------------------------


class TestReadinessStageDecorator:
    def test_sets_attribute(self):
        from sonnet_server.readiness_pipeline.registry import _STAGE_ATTR

        isolated = StageRegistry()

        @readiness_stage(order=10, description="test stage", registry=isolated)
        class TestStage:
            pass

        meta = getattr(TestStage, _STAGE_ATTR)
        assert meta.order == 10
        assert meta.description == "test stage"
        assert isolated.size == 1

    def test_uses_docstring_as_default_description(self):
        from sonnet_server.readiness_pipeline.registry import _STAGE_ATTR

        isolated = StageRegistry()

        @readiness_stage(order=11, registry=isolated)
        class DocStage:
            """My docstring description."""

        meta = getattr(DocStage, _STAGE_ATTR)
        assert meta.description == "My docstring description."


# -- @readiness_check decorator -----------------------------------------------


class TestReadinessCheckDecorator:
    def test_sets_attribute(self):
        from sonnet_server.readiness_pipeline.registry import _CHECK_ATTR

        isolated = CheckRegistry()

        class _FakeStage:
            pass

        @readiness_check(stage=_FakeStage, is_critical=True, run_once=True, order=5, registry=isolated)
        class MyCheck(ReadinessCheck):
            def __init__(self, name="my_check", is_critical=False, run_once=False):
                super().__init__(name, is_critical, run_once)

            def _execute(self):
                return self.success("ok")

        entry = getattr(MyCheck, _CHECK_ATTR)
        assert entry.stage_class is _FakeStage
        assert entry.is_critical is True
        assert entry.run_once is True
        assert entry.order == 5
        assert isolated.size == 1


# -- _stage_name helper -------------------------------------------------------


class TestStageName:
    def test_strips_stage_suffix(self):
        class DatabaseStage:
            pass

        assert _stage_name(DatabaseStage) == "database"

    def test_camel_to_snake(self):
        class MyCustomStage:
            pass

        assert _stage_name(MyCustomStage) == "my_custom"

    def test_no_stage_suffix(self):
        class Messaging:
            pass

        assert _stage_name(Messaging) == "messaging"

    def test_single_word(self):
        class CacheStage:
            pass

        assert _stage_name(CacheStage) == "cache"


# -- build_pipeline_from_registry -------------------------------------------


class TestBuildPipelineFromRegistry:
    def test_builds_pipeline_with_stages_and_checks(self):
        stage_reg = StageRegistry()
        check_reg = CheckRegistry()

        class StageA:
            pass

        class StageB:
            pass

        stage_reg.register(StageA, StageMeta(order=1, description="first", is_critical=False, fail_fast=True))
        stage_reg.register(StageB, StageMeta(order=2, description="second", is_critical=False, fail_fast=False))

        check_reg.register(CheckEntry(check_class=_SampleCheck, stage_class=StageA, is_critical=True, run_once=True, order=1))
        check_reg.register(CheckEntry(check_class=_AnotherCheck, stage_class=StageA, is_critical=False, run_once=False, order=2))
        check_reg.register(CheckEntry(check_class=_ThirdCheck, stage_class=StageB, is_critical=False, run_once=False))

        pipeline = build_pipeline_from_registry(stage_reg, check_reg)
        assert len(pipeline.stages) == 2
        assert pipeline.stages[0].name == "stage_a"
        assert pipeline.stages[1].name == "stage_b"
        assert len(pipeline.stages[0].checks) == 2
        assert len(pipeline.stages[1].checks) == 1

    def test_empty_registry_builds_empty_pipeline(self):
        pipeline = build_pipeline_from_registry(StageRegistry(), CheckRegistry())
        assert len(pipeline.stages) == 0

    def test_stage_with_no_checks_is_still_created(self):
        stage_reg = StageRegistry()

        class EmptyStage:
            pass

        stage_reg.register(EmptyStage, StageMeta(order=1, description="empty", is_critical=False, fail_fast=False))

        pipeline = build_pipeline_from_registry(stage_reg, CheckRegistry())
        assert len(pipeline.stages) == 1
        assert len(pipeline.stages[0].checks) == 0

    def test_check_inherits_is_critical_and_run_once(self):
        stage_reg = StageRegistry()
        check_reg = CheckRegistry()

        class MyStage:
            pass

        stage_reg.register(MyStage, StageMeta(order=1, description="s", is_critical=False, fail_fast=True))
        check_reg.register(CheckEntry(check_class=_SampleCheck, stage_class=MyStage, is_critical=True, run_once=True))

        pipeline = build_pipeline_from_registry(stage_reg, check_reg)
        check = pipeline.stages[0].checks[0]
        assert check.is_critical is True
        assert check.run_once is True

    def test_stage_ordering_respected(self):
        stage_reg = StageRegistry()
        check_reg = CheckRegistry()

        class Late:
            pass

        class Early:
            pass

        stage_reg.register(Late, StageMeta(order=10, description="late", is_critical=False, fail_fast=False))
        stage_reg.register(Early, StageMeta(order=1, description="early", is_critical=False, fail_fast=True))

        pipeline = build_pipeline_from_registry(stage_reg, check_reg)
        assert pipeline.stages[0].name == "early"
        assert pipeline.stages[1].name == "late"
