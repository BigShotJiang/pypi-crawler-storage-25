"""Tests for CacheRegistry and @cache decorator."""

import pytest

from sonnet_server.cache import CacheConfig, CacheMode, ManagedCache, cache
from sonnet_server.cache.registry import CacheRegistry, get_cache_registry

# -- Test cache classes (not decorated, to avoid polluting the global registry) --


class AlphaCache(ManagedCache[str, str]):
    name = "alpha"
    maxsize = 64
    ttl = 120


class BetaCache(ManagedCache[str, int]):
    name = "beta"
    maxsize = 128
    ttl = 600
    sync = False


@pytest.fixture
def registry():
    return CacheRegistry()


# -- Registration --


class TestRegistration:
    def test_register_class(self, registry):
        registry.register_class(AlphaCache)
        assert "alpha" in registry.names()

    def test_register_multiple(self, registry):
        registry.register_class(AlphaCache)
        registry.register_class(BetaCache)
        assert set(registry.names()) == {"alpha", "beta"}

    def test_duplicate_name_raises(self, registry):
        registry.register_class(AlphaCache)
        with pytest.raises(ValueError, match="already registered"):
            registry.register_class(AlphaCache)

    def test_register_class_with_overrides(self, registry):
        registry.register_class(AlphaCache, maxsize=1024, ttl=900)
        configs = registry.configs()
        assert len(configs) == 1
        assert configs[0].maxsize == 1024
        assert configs[0].ttl == 900

    def test_missing_name_raises(self, registry):
        class NoNameCache(ManagedCache[str, str]):
            pass

        with pytest.raises(ValueError, match="must define a 'name'"):
            registry.register_class(NoNameCache)

    def test_size(self, registry):
        assert registry.size == 0
        registry.register_class(AlphaCache)
        assert registry.size == 1


# -- Lazy instantiation --


class TestLazyInstantiation:
    def test_not_instantiated_on_register(self, registry):
        registry.register_class(AlphaCache)
        # all() returns only instantiated caches
        assert registry.all() == []

    def test_get_by_class_creates_instance(self, registry):
        registry.register_class(AlphaCache)
        instance = registry.get(AlphaCache)
        assert isinstance(instance, AlphaCache)
        assert instance.config.name == "alpha"

    def test_get_by_name_creates_instance(self, registry):
        registry.register_class(AlphaCache)
        instance = registry.get("alpha")
        assert isinstance(instance, AlphaCache)

    def test_get_returns_singleton(self, registry):
        registry.register_class(AlphaCache)
        a = registry.get(AlphaCache)
        b = registry.get(AlphaCache)
        assert a is b

    def test_get_by_class_and_name_same_instance(self, registry):
        registry.register_class(AlphaCache)
        by_class = registry.get(AlphaCache)
        by_name = registry.get("alpha")
        assert by_class is by_name

    def test_get_unknown_returns_none(self, registry):
        assert registry.get("nonexistent") is None
        assert registry.get(AlphaCache) is None

    def test_config_overrides_applied(self, registry):
        registry.register_class(AlphaCache, maxsize=2048)
        instance = registry.get(AlphaCache)
        assert instance.config.maxsize == 2048
        # Class attribute unchanged
        assert AlphaCache.maxsize == 64


# -- Introspection --


class TestIntrospection:
    def test_configs_without_instantiation(self, registry):
        registry.register_class(AlphaCache)
        registry.register_class(BetaCache)
        configs = registry.configs()
        assert len(configs) == 2
        names = {c.name for c in configs}
        assert names == {"alpha", "beta"}

    def test_stats_only_instantiated(self, registry):
        registry.register_class(AlphaCache)
        registry.register_class(BetaCache)
        assert registry.stats() == []

        registry.get(AlphaCache)
        stats = registry.stats()
        assert len(stats) == 1
        assert stats[0].config.name == "alpha"

    def test_all_returns_instantiated(self, registry):
        registry.register_class(AlphaCache)
        registry.register_class(BetaCache)
        registry.get(AlphaCache)
        instances = registry.all()
        assert len(instances) == 1
        assert isinstance(instances[0], AlphaCache)


# -- Register instance (programmatic) --


class TestRegisterInstance:
    def test_register_instance(self, registry):
        instance = AlphaCache(config=CacheConfig(name="manual", maxsize=32, ttl=60, mode=CacheMode.LOCAL))
        registry.register_instance(instance)
        assert registry.get("manual") is instance

    def test_register_instance_duplicate_name_raises(self, registry):
        registry.register_class(AlphaCache)
        instance = AlphaCache(config=CacheConfig(name="alpha", maxsize=32, ttl=60, mode=CacheMode.LOCAL))
        with pytest.raises(ValueError, match="already registered"):
            registry.register_instance(instance)


# -- Clear (test teardown) --


class TestClear:
    def test_clear_removes_all(self, registry):
        registry.register_class(AlphaCache)
        registry.get(AlphaCache)
        registry.clear()
        assert registry.size == 0
        assert registry.names() == []
        assert registry.all() == []
        assert registry.get(AlphaCache) is None


# -- @cache decorator --


@pytest.fixture(autouse=False)
def clean_global_registry():
    """Yield, then remove any test-registered caches from the global registry."""
    yield
    reg = get_cache_registry()
    for name in ("decorator_test_bare", "decorator_test_overrides"):
        reg._by_name.pop(name, None)
    # Remove by class is trickier; clear only the specific entries by name key
    reg._by_class = {
        cls: e
        for cls, e in reg._by_class.items()
        if e.instance is None or e.instance.config.name not in ("decorator_test_bare", "decorator_test_overrides")
    }


class TestCacheDecorator:
    def test_bare_decorator(self, clean_global_registry):
        @cache
        class MyCache(ManagedCache[str, str]):
            name = "decorator_test_bare"
            maxsize = 10
            ttl = 60

        # Decorated class is registered in the global registry
        assert MyCache.name == "decorator_test_bare"
        assert hasattr(MyCache, "__cache_registered__")

    def test_decorator_with_overrides(self, clean_global_registry):
        @cache(maxsize=2048, ttl=900)
        class MyCache2(ManagedCache[str, str]):
            name = "decorator_test_overrides"
            maxsize = 10
            ttl = 60

        assert hasattr(MyCache2, "__cache_registered__")
