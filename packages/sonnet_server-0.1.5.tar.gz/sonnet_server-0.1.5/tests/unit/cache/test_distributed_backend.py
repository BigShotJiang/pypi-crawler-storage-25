"""Tests for DistributedBackend and NearCacheBackend using a fake Redis.

Uses ``fakeredis`` for in-memory Redis emulation -- no real Redis needed.
"""

import pytest

pytest.importorskip("fakeredis", reason="fakeredis not installed -- skipping distributed backend tests")

import fakeredis.aioredis as fakeredis

from sonnet_server.cache.backends import MISSING
from sonnet_server.cache.backends.distributed import DistributedBackend
from sonnet_server.cache.backends.local import LocalBackend
from sonnet_server.cache.backends.near_cache import NearCacheBackend


def make_distributed(name: str = "test_cache", ttl: int = 300) -> DistributedBackend:
    """Create a DistributedBackend wired to a fake Redis server."""
    backend = DistributedBackend(cache_name=name, ttl=ttl, maxsize=64)
    # Inject fake Redis client factory
    fake_server = fakeredis.FakeServer()

    def _fake_client():
        return fakeredis.FakeRedis(server=fake_server, decode_responses=True)

    backend._client = _fake_client
    return backend


# -- DistributedBackend --


class TestDistributedBackendGetPut:
    @pytest.mark.asyncio
    async def test_get_miss_returns_missing(self):
        b = make_distributed()
        assert await b.get("absent") is MISSING

    @pytest.mark.asyncio
    async def test_put_and_get(self):
        b = make_distributed()
        await b.put("key", "value")
        assert await b.get("key") == "value"

    @pytest.mark.asyncio
    async def test_caches_none(self):
        b = make_distributed()
        await b.put("key", None)
        result = await b.get("key")
        assert result is None
        assert result is not MISSING

    @pytest.mark.asyncio
    async def test_tuple_key(self):
        b = make_distributed()
        await b.put(("owner", "scope"), "schema")
        assert await b.get(("owner", "scope")) == "schema"
        assert await b.get(("owner", "other")) is MISSING

    @pytest.mark.asyncio
    async def test_namespacing_isolates_caches(self):
        """Keys from different caches do not collide."""
        b1 = make_distributed(name="cache_a")
        b2 = make_distributed(name="cache_b")
        # Wire both to a shared fake server
        fake_server = fakeredis.FakeServer()
        b1._client = lambda: fakeredis.FakeRedis(server=fake_server, decode_responses=True)
        b2._client = lambda: fakeredis.FakeRedis(server=fake_server, decode_responses=True)

        await b1.put("key", "from_a")
        assert await b2.get("key") is MISSING
        assert await b1.get("key") == "from_a"


class TestDistributedBackendDelete:
    @pytest.mark.asyncio
    async def test_delete_existing(self):
        b = make_distributed()
        await b.put("key", "value")
        assert await b.delete("key") is True
        assert await b.get("key") is MISSING

    @pytest.mark.asyncio
    async def test_delete_absent(self):
        b = make_distributed()
        assert await b.delete("absent") is False

    @pytest.mark.asyncio
    async def test_delete_by_predicate(self):
        b = make_distributed()
        await b.put(("a", "1"), "v1")
        await b.put(("a", "2"), "v2")
        await b.put(("b", "1"), "v3")
        count = await b.delete_by(lambda k: isinstance(k, tuple) and k[0] == "a")
        assert count == 2
        assert await b.get(("b", "1")) == "v3"
        assert await b.get(("a", "1")) is MISSING

    @pytest.mark.asyncio
    async def test_clear(self):
        b = make_distributed()
        await b.put("a", 1)
        await b.put("b", 2)
        count = await b.clear()
        assert count == 2
        assert await b.get("a") is MISSING
        assert await b.get("b") is MISSING


class TestDistributedBackendKeys:
    @pytest.mark.asyncio
    async def test_keys(self):
        b = make_distributed()
        await b.put("a", 1)
        await b.put("b", 2)
        keys = list(await b.keys())
        assert set(keys) == {"a", "b"}

    @pytest.mark.asyncio
    async def test_len(self):
        b = make_distributed()
        await b.put("a", 1)
        await b.put("b", 2)
        assert await b.len() == 2

    def test_maxsize(self):
        b = DistributedBackend(cache_name="x", ttl=60, maxsize=128)
        assert b.maxsize == 128


# -- NearCacheBackend --


def make_near_cache(name: str = "test_near") -> NearCacheBackend:
    l1 = LocalBackend(maxsize=10, ttl=300)
    l2 = make_distributed(name=name)
    return NearCacheBackend(l1=l1, l2=l2)


class TestNearCacheBackend:
    @pytest.mark.asyncio
    async def test_l2_miss_returns_missing(self):
        nc = make_near_cache()
        assert await nc.get("absent") is MISSING

    @pytest.mark.asyncio
    async def test_put_populates_both_tiers(self):
        nc = make_near_cache()
        await nc.put("key", "value")
        # L1 hit
        assert nc._l1.get("key") == "value"
        # L2 hit
        assert await nc._l2.get("key") == "value"

    @pytest.mark.asyncio
    async def test_l1_hit_skips_l2(self):
        nc = make_near_cache()
        nc._l1.put("key", "local")
        # L2 has a different value -- L1 should win
        await nc._l2.put("key", "remote")
        assert await nc.get("key") == "local"

    @pytest.mark.asyncio
    async def test_l2_hit_populates_l1(self):
        nc = make_near_cache()
        await nc._l2.put("key", "from_l2")
        # L1 is empty
        assert nc._l1.get("key") is MISSING
        result = await nc.get("key")
        assert result == "from_l2"
        # L1 now populated
        assert nc._l1.get("key") == "from_l2"

    @pytest.mark.asyncio
    async def test_delete_removes_from_both_tiers(self):
        nc = make_near_cache()
        await nc.put("key", "value")
        deleted = await nc.delete("key")
        assert deleted is True
        assert nc._l1.get("key") is MISSING
        assert await nc._l2.get("key") is MISSING

    @pytest.mark.asyncio
    async def test_clear_removes_from_both_tiers(self):
        nc = make_near_cache()
        await nc.put("a", 1)
        await nc.put("b", 2)
        count = await nc.clear()
        assert count == 2  # L1 count
        assert nc._l1.get("a") is MISSING
        assert await nc._l2.get("a") is MISSING

    def test_evict_local_only(self):
        nc = make_near_cache()
        nc._l1.put("key", "value")
        nc.evict_local("key")
        assert nc._l1.get("key") is MISSING

    def test_evict_local_all(self):
        nc = make_near_cache()
        nc._l1.put("a", 1)
        nc._l1.put("b", 2)
        count = nc.evict_local_all()
        assert count == 2
        assert len(nc._l1) == 0

    def test_maxsize_returns_l1(self):
        nc = make_near_cache()
        assert nc.maxsize == 10

    def test_len_returns_l1_size(self):
        nc = make_near_cache()
        nc._l1.put("a", 1)
        nc._l1.put("b", 2)
        assert len(nc) == 2


# -- Edge cases --


class TestDistributedEdgeCases:
    @pytest.mark.asyncio
    async def test_delete_by_no_match(self):
        b = make_distributed()
        await b.put("key", "value")
        count = await b.delete_by(lambda k: False)
        assert count == 0
        assert await b.get("key") == "value"

    @pytest.mark.asyncio
    async def test_clear_empty(self):
        b = make_distributed()
        assert await b.clear() == 0

    @pytest.mark.asyncio
    async def test_len_empty(self):
        b = make_distributed()
        assert await b.len() == 0

    def test_sync_len_returns_zero(self):
        b = make_distributed()
        assert len(b) == 0

    @pytest.mark.asyncio
    async def test_nested_dict_value(self):
        b = make_distributed()
        nested = {"outer": {"inner": [1, 2, 3]}, "flag": True}
        await b.put("nested", nested)
        assert await b.get("nested") == nested

    @pytest.mark.asyncio
    async def test_unicode_value(self):
        b = make_distributed()
        await b.put("greet", "Hallo Welt")
        assert await b.get("greet") == "Hallo Welt"


# -- NearCache L2 failure resilience --


class TestNearCacheL2Failure:
    """Tests that NearCacheBackend degrades gracefully when L2 is unavailable."""

    def _make_failing_near_cache(self):
        """NearCacheBackend where L2 raises on every operation."""
        l1 = LocalBackend(maxsize=10, ttl=300)
        l2 = make_distributed(name="failing")

        def _broken_client():
            from unittest.mock import AsyncMock, MagicMock

            mock = AsyncMock()
            mock.get.side_effect = ConnectionError("Redis unavailable")
            mock.setex.side_effect = ConnectionError("Redis unavailable")
            mock.delete.side_effect = ConnectionError("Redis unavailable")
            # scan_iter must be a sync method that returns an async iterator
            mock.scan_iter = MagicMock(side_effect=ConnectionError("Redis unavailable"))
            return mock

        l2._client = _broken_client
        l2._client_instance = None  # reset lazy client
        return NearCacheBackend(l1=l1, l2=l2)

    @pytest.mark.asyncio
    async def test_get_degrades_to_missing_on_l2_failure(self):
        nc = self._make_failing_near_cache()
        # L1 miss + L2 failure = MISSING (not an exception)
        assert await nc.get("key") is MISSING

    @pytest.mark.asyncio
    async def test_get_serves_from_l1_when_l2_fails(self):
        nc = self._make_failing_near_cache()
        nc._l1.put("key", "local_value")
        # L1 hit -- L2 never consulted
        assert await nc.get("key") == "local_value"

    @pytest.mark.asyncio
    async def test_put_succeeds_in_l1_when_l2_fails(self):
        nc = self._make_failing_near_cache()
        # Should not raise -- L1 write succeeds, L2 failure logged
        await nc.put("key", "value")
        assert nc._l1.get("key") == "value"

    @pytest.mark.asyncio
    async def test_delete_succeeds_in_l1_when_l2_fails(self):
        nc = self._make_failing_near_cache()
        nc._l1.put("key", "value")
        deleted = await nc.delete("key")
        assert deleted is True
        assert nc._l1.get("key") is MISSING

    @pytest.mark.asyncio
    async def test_clear_succeeds_in_l1_when_l2_fails(self):
        nc = self._make_failing_near_cache()
        nc._l1.put("a", 1)
        nc._l1.put("b", 2)
        count = await nc.clear()
        assert count == 2
        assert len(nc._l1) == 0
