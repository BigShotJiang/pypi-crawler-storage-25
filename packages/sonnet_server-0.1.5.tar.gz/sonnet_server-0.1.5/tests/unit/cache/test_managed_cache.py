"""Tests for ManagedCache base class."""

import pytest

from sonnet_server.cache import MISSING, CacheConfig, CacheMode, ManagedCache


class SimpleCache(ManagedCache[str, str | None]):
    """Test cache with read-through."""

    name = "test_simple"
    maxsize = 10
    ttl = 300

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.load_calls: list[str] = []

    def load(self, key: str) -> str | None:
        self.load_calls.append(key)
        if key == "missing":
            return None
        return f"value_for_{key}"


class NoLoadCache(ManagedCache[str, str]):
    """Test cache without load() override (get/put mode only)."""

    name = "test_no_load"
    maxsize = 10
    ttl = 300


@pytest.fixture
def simple_cache():
    return SimpleCache(config=CacheConfig(name="test_simple", maxsize=10, ttl=300, mode=CacheMode.LOCAL))


@pytest.fixture
def no_load_cache():
    return NoLoadCache(config=CacheConfig(name="test_no_load", maxsize=10, ttl=300, mode=CacheMode.LOCAL))


# -- Read-through (get_or_load) --


class TestGetOrLoad:
    def test_miss_calls_load(self, simple_cache):
        result = simple_cache.get_or_load("foo")
        assert result == "value_for_foo"
        assert simple_cache.load_calls == ["foo"]

    def test_hit_does_not_call_load(self, simple_cache):
        simple_cache.get_or_load("foo")
        simple_cache.load_calls.clear()
        result = simple_cache.get_or_load("foo")
        assert result == "value_for_foo"
        assert simple_cache.load_calls == []

    def test_caches_none(self, simple_cache):
        result = simple_cache.get_or_load("missing")
        assert result is None
        # Second call should not invoke load
        simple_cache.load_calls.clear()
        result = simple_cache.get_or_load("missing")
        assert result is None
        assert simple_cache.load_calls == []

    def test_no_load_raises(self, no_load_cache):
        with pytest.raises(NotImplementedError):
            no_load_cache.get_or_load("key")

    def test_load_error_does_not_corrupt_miss_counter(self):
        """Miss counter must not increment when load() raises."""

        class FailingCache(ManagedCache[str, str]):
            name = "failing"
            maxsize = 10
            ttl = 300

            def load(self, key: str) -> str:
                raise RuntimeError("db unavailable")

        c = FailingCache(config=CacheConfig(name="failing", maxsize=10, ttl=300, mode=CacheMode.LOCAL))
        with pytest.raises(RuntimeError):
            c.get_or_load("key")
        # Miss counter must be 0 -- the load failed so no miss was recorded
        assert c.stats.misses == 0


# -- Explicit get/put --


class TestGetPut:
    def test_get_miss(self, no_load_cache):
        assert no_load_cache.get("absent") is MISSING

    def test_put_and_get(self, no_load_cache):
        no_load_cache.put("key", "value")
        assert no_load_cache.get("key") == "value"

    def test_put_none_distinguishable_from_missing(self, no_load_cache):
        no_load_cache.put("key", None)
        result = no_load_cache.get("key")
        assert result is None
        assert result is not MISSING


# -- Invalidation --


class TestInvalidation:
    def test_invalidate_single_key(self, simple_cache):
        simple_cache.get_or_load("foo")
        simple_cache.invalidate("foo")
        assert simple_cache.get("foo") is MISSING

    def test_invalidate_absent_key(self, simple_cache):
        # Should not raise
        simple_cache.invalidate("absent")

    def test_invalidate_by_predicate(self):
        # Use a tuple-keyed cache to match the actual key type
        tuple_cache: ManagedCache[tuple[str, str], str] = ManagedCache(
            config=CacheConfig(name="tuple_test", maxsize=10, ttl=300, mode=CacheMode.LOCAL)
        )
        tuple_cache.put(("a", "1"), "v1")
        tuple_cache.put(("a", "2"), "v2")
        tuple_cache.put(("b", "1"), "v3")
        count = tuple_cache.invalidate_by(lambda k: k[0] == "a")
        assert count == 2
        assert tuple_cache.get(("b", "1")) == "v3"

    def test_invalidate_all(self, simple_cache):
        simple_cache.get_or_load("foo")
        simple_cache.get_or_load("bar")
        count = simple_cache.invalidate_all()
        assert count == 2
        assert simple_cache.get("foo") is MISSING
        assert simple_cache.get("bar") is MISSING

    def test_invalidate_all_empty(self, simple_cache):
        assert simple_cache.invalidate_all() == 0


# -- Eviction (internal, no event emission) --


class TestEviction:
    def test_evict_single(self, simple_cache):
        simple_cache.get_or_load("foo")
        simple_cache.evict("foo")
        assert simple_cache.get("foo") is MISSING

    def test_evict_all(self, simple_cache):
        simple_cache.get_or_load("foo")
        simple_cache.get_or_load("bar")
        simple_cache.evict_all()
        assert simple_cache.size == 0


# -- Stats --


class TestStats:
    def test_initial_stats(self, simple_cache):
        stats = simple_cache.stats
        assert stats.config.name == "test_simple"
        assert stats.size == 0
        assert stats.hits == 0
        assert stats.misses == 0
        assert stats.invalidations == 0
        assert stats.hit_rate == 0.0

    def test_stats_after_operations(self, simple_cache):
        simple_cache.get_or_load("foo")  # miss
        simple_cache.get_or_load("foo")  # hit
        simple_cache.get_or_load("bar")  # miss
        simple_cache.invalidate("foo")

        stats = simple_cache.stats
        assert stats.hits == 1
        assert stats.misses == 2
        assert stats.invalidations == 1
        assert stats.size == 1  # "bar" remains
        assert stats.hit_rate == pytest.approx(1 / 3)

    def test_stats_serializable(self, simple_cache):
        simple_cache.get_or_load("foo")
        data = simple_cache.stats.model_dump()
        assert isinstance(data, dict)
        assert data["config"]["name"] == "test_simple"
        assert "hits" in data
        assert "hit_rate" in data


# -- Config --


class TestConfig:
    def test_config_from_explicit(self, simple_cache):
        assert simple_cache.config.name == "test_simple"
        assert simple_cache.config.maxsize == 10
        assert simple_cache.config.ttl == 300
        assert simple_cache.config.mode == CacheMode.LOCAL
        assert simple_cache.config.sync is False  # LOCAL mode does not sync

    def test_config_from_class_attributes(self):
        c = SimpleCache()
        assert c.config.name == "test_simple"
        assert c.config.maxsize == 10
        assert c.config.ttl == 300
        assert c.config.mode == CacheMode.REPLICATED  # class default
        assert c.config.sync is True  # REPLICATED mode syncs

    def test_config_frozen(self, simple_cache):
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            simple_cache.config.name = "changed"

    def test_config_serializable(self, simple_cache):
        data = simple_cache.config.model_dump()
        assert data == {"name": "test_simple", "maxsize": 10, "ttl": 300, "mode": "local"}

    def test_missing_name_raises(self):
        with pytest.raises(ValueError, match="must define a 'name'"):
            ManagedCache()


# -- Repr --


class TestRepr:
    def test_repr(self, simple_cache):
        r = repr(simple_cache)
        assert "SimpleCache" in r
        assert "test_simple" in r
