"""Tests for LocalBackend (TTLCache wrapper)."""

import time

import pytest

from sonnet_server.cache.backends import MISSING
from sonnet_server.cache.backends.local import LocalBackend


@pytest.fixture
def backend():
    return LocalBackend(maxsize=10, ttl=300)


class TestGetPut:
    def test_get_miss_returns_missing(self, backend):
        assert backend.get("absent") is MISSING

    def test_put_and_get(self, backend):
        backend.put("key", "value")
        assert backend.get("key") == "value"

    def test_put_none_is_cached(self, backend):
        backend.put("key", None)
        result = backend.get("key")
        assert result is None
        assert result is not MISSING

    def test_put_overwrites(self, backend):
        backend.put("key", "v1")
        backend.put("key", "v2")
        assert backend.get("key") == "v2"

    def test_tuple_key(self, backend):
        backend.put(("owner", "scope"), "schema")
        assert backend.get(("owner", "scope")) == "schema"
        assert backend.get(("owner", "other")) is MISSING


class TestDelete:
    def test_delete_existing(self, backend):
        backend.put("key", "value")
        assert backend.delete("key") is True
        assert backend.get("key") is MISSING

    def test_delete_absent(self, backend):
        assert backend.delete("absent") is False

    def test_delete_by_predicate(self, backend):
        backend.put(("a", "1"), "v1")
        backend.put(("a", "2"), "v2")
        backend.put(("b", "1"), "v3")
        count = backend.delete_by(lambda k: k[0] == "a")
        assert count == 2
        assert backend.get(("a", "1")) is MISSING
        assert backend.get(("a", "2")) is MISSING
        assert backend.get(("b", "1")) == "v3"

    def test_delete_by_no_match(self, backend):
        backend.put("key", "value")
        count = backend.delete_by(lambda k: False)
        assert count == 0
        assert backend.get("key") == "value"


class TestClear:
    def test_clear_returns_count(self, backend):
        backend.put("a", 1)
        backend.put("b", 2)
        assert backend.clear() == 2

    def test_clear_empty(self, backend):
        assert backend.clear() == 0

    def test_clear_removes_all(self, backend):
        backend.put("a", 1)
        backend.put("b", 2)
        backend.clear()
        assert backend.get("a") is MISSING
        assert backend.get("b") is MISSING


class TestIntrospection:
    def test_len(self, backend):
        assert len(backend) == 0
        backend.put("a", 1)
        assert len(backend) == 1

    def test_maxsize(self, backend):
        assert backend.maxsize == 10

    def test_keys(self, backend):
        backend.put("a", 1)
        backend.put("b", 2)
        assert set(backend.keys()) == {"a", "b"}


class TestEvictionAndTTL:
    def test_lru_eviction(self):
        small = LocalBackend(maxsize=2, ttl=300)
        small.put("a", 1)
        small.put("b", 2)
        small.put("c", 3)  # evicts "a"
        assert small.get("a") is MISSING
        assert len(small) == 2

    @pytest.mark.slow
    def test_ttl_expiration(self):
        # Uses real wall-clock sleep; 1.1s to give cachetools 100ms margin.
        short = LocalBackend(maxsize=10, ttl=1)
        short.put("key", "value")
        assert short.get("key") == "value"
        time.sleep(1.1)
        assert short.get("key") is MISSING
