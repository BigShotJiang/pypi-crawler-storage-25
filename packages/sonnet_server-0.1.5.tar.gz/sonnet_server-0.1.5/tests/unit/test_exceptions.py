"""Tests for shared exception classes."""

from sonnet_server.exceptions import DuplicateResourceError


class TestDuplicateResourceError:
    """Tests for DuplicateResourceError message formatting."""

    def test_with_field_and_value(self):
        e = DuplicateResourceError("User", "email", "a@b.com")
        assert "email" in str(e)
        assert "a@b.com" in str(e)
        assert "User" in str(e)

    def test_with_field_only(self):
        e = DuplicateResourceError("User", "email")
        assert "email" in str(e)
        assert "User" in str(e)

    def test_with_no_field(self):
        e = DuplicateResourceError("User")
        assert "User" in str(e)

    def test_attributes_stored(self):
        e = DuplicateResourceError("Organization", "org_id", "org_abc123")
        assert e.resource_type == "Organization"
        assert e.field == "org_id"
        assert e.value == "org_abc123"

    def test_none_field_and_value(self):
        e = DuplicateResourceError("User", None, None)
        assert "User" in str(e)
        assert e.field is None
        assert e.value is None
