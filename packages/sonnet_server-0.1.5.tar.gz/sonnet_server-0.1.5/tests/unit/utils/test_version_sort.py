"""Tests for version_sort utility -- version comparison and pick_latest."""

import pytest

from sonnet_server.utils.version_sort import (
    DEFAULT_ALGORITHM,
    VALID_ALGORITHMS,
    pick_latest,
    version_sort_key,
)

# -----------------------------------------------------------------------
# Helper
# -----------------------------------------------------------------------


class Row:
    """Minimal stand-in for a DB row with version/status/algorithm fields."""

    def __init__(self, version: str, status: str = "active", algorithm: str = "natural"):
        self.content_version = version
        self.status = status
        self.version_algorithm = algorithm

    def __repr__(self) -> str:
        return f"Row({self.content_version!r}, {self.status})"


# -----------------------------------------------------------------------
# version_sort_key -- natural
# -----------------------------------------------------------------------


class TestNaturalSortKey:
    def test_numeric_segments(self):
        assert version_sort_key("10", "natural") > version_sort_key("9", "natural")

    def test_dotted_versions(self):
        assert version_sort_key("1.10.0", "natural") > version_sort_key("1.9.0", "natural")

    def test_mixed_alpha_numeric(self):
        assert version_sort_key("v2", "natural") > version_sort_key("v1", "natural")

    def test_year_versions(self):
        assert version_sort_key("2026", "natural") > version_sort_key("2025", "natural")

    def test_equal_versions(self):
        assert version_sort_key("1.0", "natural") == version_sort_key("1.0", "natural")


# -----------------------------------------------------------------------
# version_sort_key -- semver
# -----------------------------------------------------------------------


class TestSemverSortKey:
    def test_major_minor_patch(self):
        assert version_sort_key("2.0.0", "semver") > version_sort_key("1.9.9", "semver")

    def test_prerelease_lower_than_release(self):
        assert version_sort_key("1.0.0", "semver") > version_sort_key("1.0.0-beta", "semver")

    def test_prerelease_ordering(self):
        assert version_sort_key("1.0.0-beta.2", "semver") > version_sort_key("1.0.0-beta.1", "semver")

    def test_missing_patch(self):
        assert version_sort_key("2.1", "semver") > version_sort_key("2.0", "semver")

    def test_major_only(self):
        assert version_sort_key("3", "semver") > version_sort_key("2", "semver")


# -----------------------------------------------------------------------
# version_sort_key -- integer
# -----------------------------------------------------------------------


class TestIntegerSortKey:
    def test_numeric(self):
        assert version_sort_key("20", "integer") > version_sort_key("3", "integer")

    def test_non_numeric_sorts_lowest(self):
        assert version_sort_key("1", "integer") > version_sort_key("abc", "integer")

    def test_two_non_numeric_equal(self):
        assert version_sort_key("foo", "integer") == version_sort_key("bar", "integer")


# -----------------------------------------------------------------------
# version_sort_key -- date
# -----------------------------------------------------------------------


class TestDateSortKey:
    def test_iso_dates(self):
        assert version_sort_key("2026-03-10", "date") > version_sort_key("2025-12-31", "date")

    def test_same_date(self):
        assert version_sort_key("2025-01-01", "date") == version_sort_key("2025-01-01", "date")


# -----------------------------------------------------------------------
# version_sort_key -- alpha
# -----------------------------------------------------------------------


class TestAlphaSortKey:
    def test_case_insensitive(self):
        assert version_sort_key("Beta", "alpha") == version_sort_key("beta", "alpha")

    def test_ordering(self):
        assert version_sort_key("gamma", "alpha") > version_sort_key("beta", "alpha")


# -----------------------------------------------------------------------
# version_sort_key -- unknown algorithm
# -----------------------------------------------------------------------


class TestUnknownAlgorithm:
    def test_falls_back_to_natural(self):
        assert version_sort_key("10", "bogus") > version_sort_key("9", "bogus")


# -----------------------------------------------------------------------
# pick_latest -- basic
# -----------------------------------------------------------------------


class TestPickLatestBasic:
    def test_single_row(self):
        row = Row("1.0")
        assert pick_latest([row], version_key=lambda r: r.content_version) is row

    def test_empty_raises(self):
        with pytest.raises(ValueError, match="empty"):
            pick_latest([], version_key=lambda r: r.content_version)

    def test_highest_version_wins(self):
        rows = [Row("1.0"), Row("2.0"), Row("1.5")]
        result = pick_latest(rows, version_key=lambda r: r.content_version)
        assert result.content_version == "2.0"


# -----------------------------------------------------------------------
# pick_latest -- status preference
# -----------------------------------------------------------------------


class TestPickLatestStatusPreference:
    def test_active_preferred_over_higher_draft(self):
        rows = [Row("2025", "active"), Row("2026", "draft")]
        result = pick_latest(
            rows,
            version_key=lambda r: r.content_version,
            status_key=lambda r: r.status,
        )
        assert result.content_version == "2025"
        assert result.status == "active"

    def test_highest_active_when_multiple_active(self):
        rows = [Row("1.0", "active"), Row("3.0", "active"), Row("2.0", "active")]
        result = pick_latest(
            rows,
            version_key=lambda r: r.content_version,
            status_key=lambda r: r.status,
        )
        assert result.content_version == "3.0"

    def test_highest_draft_when_no_active(self):
        rows = [Row("1.0", "draft"), Row("2.0", "draft")]
        result = pick_latest(
            rows,
            version_key=lambda r: r.content_version,
            status_key=lambda r: r.status,
        )
        assert result.content_version == "2.0"

    def test_retired_treated_like_draft(self):
        rows = [Row("1.0", "retired"), Row("2.0", "active")]
        result = pick_latest(
            rows,
            version_key=lambda r: r.content_version,
            status_key=lambda r: r.status,
        )
        assert result.content_version == "2.0"

    def test_without_status_key_ignores_status(self):
        rows = [Row("2025", "active"), Row("2026", "draft")]
        result = pick_latest(rows, version_key=lambda r: r.content_version)
        assert result.content_version == "2026"


# -----------------------------------------------------------------------
# pick_latest -- algorithm_key
# -----------------------------------------------------------------------


class TestPickLatestWithAlgorithmKey:
    def test_semver_algorithm_from_row(self):
        rows = [Row("1.9.0", "active", "semver"), Row("2.0.0-beta", "draft", "semver")]
        result = pick_latest(
            rows,
            version_key=lambda r: r.content_version,
            algorithm_key=lambda r: r.version_algorithm,
            status_key=lambda r: r.status,
        )
        assert result.content_version == "1.9.0"

    def test_integer_algorithm_from_row(self):
        rows = [Row("3", "active", "integer"), Row("20", "active", "integer"), Row("10", "draft", "integer")]
        result = pick_latest(
            rows,
            version_key=lambda r: r.content_version,
            algorithm_key=lambda r: r.version_algorithm,
            status_key=lambda r: r.status,
        )
        assert result.content_version == "20"

    def test_date_algorithm_from_row(self):
        rows = [Row("2025-01-15", "active", "date"), Row("2025-12-01", "active", "date"), Row("2026-03-10", "draft", "date")]
        result = pick_latest(
            rows,
            version_key=lambda r: r.content_version,
            algorithm_key=lambda r: r.version_algorithm,
            status_key=lambda r: r.status,
        )
        assert result.content_version == "2025-12-01"

    def test_alpha_algorithm_from_row(self):
        rows = [Row("beta", "active", "alpha"), Row("gamma", "draft", "alpha"), Row("alpha", "active", "alpha")]
        result = pick_latest(
            rows,
            version_key=lambda r: r.content_version,
            algorithm_key=lambda r: r.version_algorithm,
            status_key=lambda r: r.status,
        )
        assert result.content_version == "beta"


# -----------------------------------------------------------------------
# pick_latest -- explicit algorithm override
# -----------------------------------------------------------------------


class TestPickLatestAlgorithmOverride:
    def test_override_ignores_row_algorithm(self):
        # Rows say "natural" but we force "integer".
        rows = [Row("10", "active", "natural"), Row("9", "active", "natural")]
        result = pick_latest(
            rows,
            version_key=lambda r: r.content_version,
            algorithm_key=lambda r: r.version_algorithm,
            algorithm="integer",
        )
        assert result.content_version == "10"


# -----------------------------------------------------------------------
# pick_latest -- edge cases
# -----------------------------------------------------------------------


class TestPickLatestEdgeCases:
    def test_none_version_treated_as_empty(self):
        """Row with None version should not crash, sorts lowest."""

        class NoneRow:
            content_version = None
            status = "active"

        rows = [NoneRow(), Row("1.0")]
        result = pick_latest(rows, version_key=lambda r: r.content_version)
        assert result.content_version == "1.0"

    def test_default_algorithm_is_natural(self):
        assert DEFAULT_ALGORITHM == "natural"

    def test_valid_algorithms_list(self):
        assert set(VALID_ALGORITHMS) == {"natural", "semver", "integer", "date", "alpha"}
