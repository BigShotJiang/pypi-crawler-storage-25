"""Tests for the JSON Schema validation utility."""

import pytest

from sonnet_server.utils.json_schema import ValidationResult, validate_instance, validate_schema

# ---------------------------------------------------------------------------
# validate_schema -- meta-validation
# ---------------------------------------------------------------------------


class TestValidateSchema:
    """Verify that validate_schema correctly meta-validates JSON Schema documents."""

    def test_valid_minimal_schema(self):
        """An empty object is a valid JSON Schema (matches anything)."""
        result = validate_schema({})
        assert result.valid is True
        assert result.errors == []

    def test_valid_object_schema(self):
        """A well-formed object schema passes."""
        schema = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer", "minimum": 0},
            },
            "required": ["name"],
        }
        result = validate_schema(schema)
        assert result.valid is True

    def test_valid_schema_with_draft_declaration(self):
        """A schema declaring $schema Draft 2020-12 passes."""
        schema = {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "properties": {"color": {"type": "string"}},
        }
        result = validate_schema(schema)
        assert result.valid is True

    def test_valid_schema_with_x_extensions(self):
        """Custom x- extension keywords are allowed per spec."""
        schema = {
            "type": "object",
            "properties": {
                "color": {
                    "type": "string",
                    "x-ui-widget": "color-picker",
                    "x-ui-options": {"palette": "material"},
                },
                "icon": {
                    "type": "string",
                    "x-ui-widget": "icon-picker",
                },
            },
            "additionalProperties": False,
        }
        result = validate_schema(schema)
        assert result.valid is True

    def test_invalid_type_value(self):
        """An invalid type value is rejected."""
        schema = {"type": "not-a-valid-type"}
        result = validate_schema(schema)
        assert result.valid is False
        assert len(result.errors) >= 1
        assert "not-a-valid-type" in result.errors[0].message

    def test_invalid_nested_property(self):
        """An invalid type in a nested property is caught."""
        schema = {
            "type": "object",
            "properties": {
                "name": {"type": "bogus"},
            },
        }
        result = validate_schema(schema)
        assert result.valid is False
        assert len(result.errors) >= 1

    def test_invalid_minimum_type(self):
        """minimum must be a number, not a string."""
        schema = {
            "type": "object",
            "properties": {
                "age": {"type": "integer", "minimum": "zero"},
            },
        }
        result = validate_schema(schema)
        assert result.valid is False
        assert len(result.errors) >= 1

    def test_result_type(self):
        """validate_schema always returns a ValidationResult."""
        assert isinstance(validate_schema({}), ValidationResult)
        assert isinstance(validate_schema({"type": "bogus"}), ValidationResult)

    @pytest.mark.parametrize("non_dict", ["not a schema", 42, None, [1, 2]])
    def test_non_dict_input_is_invalid(self, non_dict):
        """A non-dict value is not a valid JSON Schema document."""
        result = validate_schema(non_dict)
        assert result.valid is False
        assert len(result.errors) == 1


# ---------------------------------------------------------------------------
# validate_instance -- instance validation
# ---------------------------------------------------------------------------


class TestValidateInstance:
    """Verify that validate_instance checks instances against schemas."""

    @pytest.fixture
    def object_schema(self):
        return {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer", "minimum": 0},
            },
            "required": ["name"],
            "additionalProperties": False,
        }

    def test_valid_instance(self, object_schema):
        result = validate_instance({"name": "Alice", "age": 30}, object_schema)
        assert result.valid is True
        assert result.errors == []

    def test_valid_instance_optional_field_omitted(self, object_schema):
        """Optional fields can be omitted."""
        result = validate_instance({"name": "Alice"}, object_schema)
        assert result.valid is True

    def test_missing_required_field(self, object_schema):
        result = validate_instance({"age": 30}, object_schema)
        assert result.valid is False
        assert any("name" in e.message for e in result.errors)

    def test_wrong_type(self, object_schema):
        result = validate_instance({"name": 42}, object_schema)
        assert result.valid is False
        assert any("type" in e.message for e in result.errors)

    def test_additional_property_rejected(self, object_schema):
        result = validate_instance({"name": "Alice", "extra": True}, object_schema)
        assert result.valid is False
        assert any("extra" in e.message for e in result.errors)

    def test_minimum_violated(self, object_schema):
        result = validate_instance({"name": "Alice", "age": -1}, object_schema)
        assert result.valid is False

    def test_multiple_errors_collected(self, object_schema):
        """All errors are collected, not just the first."""
        result = validate_instance({"age": "old", "extra": True}, object_schema)
        assert result.valid is False
        assert len(result.errors) >= 2

    def test_valid_against_any_schema(self):
        """An empty schema matches any instance."""
        assert validate_instance(42, {}).valid is True
        assert validate_instance("hello", {}).valid is True
        assert validate_instance(None, {}).valid is True
        assert validate_instance([1, 2], {}).valid is True

    def test_schema_with_x_extensions_ignored_during_instance_validation(self):
        """x- extension keywords do not affect instance validation."""
        schema = {
            "type": "object",
            "properties": {
                "color": {
                    "type": "string",
                    "x-ui-widget": "color-picker",
                },
            },
        }
        result = validate_instance({"color": "#ff0000"}, schema)
        assert result.valid is True

    def test_error_paths(self):
        """Error path points to the exact failing location in the instance."""
        schema = {
            "type": "object",
            "properties": {
                "address": {
                    "type": "object",
                    "properties": {
                        "zip": {"type": "string"},
                    },
                },
            },
        }
        result = validate_instance({"address": {"zip": 12345}}, schema)
        assert result.valid is False
        assert len(result.errors) == 1
        assert result.errors[0].path == ["address", "zip"]

    def test_result_type(self):
        """validate_instance always returns a ValidationResult."""
        assert isinstance(validate_instance({}, {}), ValidationResult)
        assert isinstance(validate_instance("bad", {"type": "object"}), ValidationResult)


# ---------------------------------------------------------------------------
# validate_instance -- $ref resolution
# ---------------------------------------------------------------------------


class TestValidateInstanceRefResolution:
    """Verify that validate_instance resolves external $ref URIs via callback."""

    ADDRESS_SCHEMA: dict = {
        "type": "object",
        "properties": {
            "street": {"type": "string"},
            "city": {"type": "string"},
        },
        "required": ["street", "city"],
    }

    PERSON_SCHEMA: dict = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "address": {"$ref": "urn:example:address"},
        },
        "required": ["name", "address"],
    }

    @pytest.fixture
    def resolve_ref(self):
        """A resolve_ref callback that knows one schema."""
        schemas = {
            "urn:example:address": self.ADDRESS_SCHEMA,
        }

        def _resolve(uri: str) -> dict:
            return schemas[uri]  # raises KeyError if unknown

        return _resolve

    def test_valid_instance_with_ref(self, resolve_ref):
        """A valid instance passes when the $ref is resolved."""
        instance = {"name": "Alice", "address": {"street": "123 Main", "city": "Springfield"}}
        result = validate_instance(instance, self.PERSON_SCHEMA, resolve_ref=resolve_ref)
        assert result.valid is True

    def test_invalid_instance_with_ref(self, resolve_ref):
        """Validation errors from a $ref-resolved schema are reported."""
        instance = {"name": "Alice", "address": {"street": "123 Main"}}
        result = validate_instance(instance, self.PERSON_SCHEMA, resolve_ref=resolve_ref)
        assert result.valid is False
        assert any("city" in e.message for e in result.errors)

    def test_unresolvable_ref(self):
        """An unresolvable $ref produces a validation error, not an exception."""
        schema = {
            "type": "object",
            "properties": {"x": {"$ref": "urn:example:nonexistent"}},
        }

        def _resolve(uri: str) -> dict:
            raise KeyError(uri)

        result = validate_instance({"x": {}}, schema, resolve_ref=_resolve)
        assert result.valid is False
        assert len(result.errors) == 1
        assert "Unresolvable" in result.errors[0].message

    def test_ref_callback_not_called_without_refs(self, resolve_ref):
        """The resolve_ref callback is not called when there are no $ref URIs."""
        call_count = 0
        original = resolve_ref

        def _counting_resolve(uri: str) -> dict:
            nonlocal call_count
            call_count += 1
            return original(uri)

        schema = {"type": "object", "properties": {"x": {"type": "integer"}}}
        result = validate_instance({"x": 42}, schema, resolve_ref=_counting_resolve)
        assert result.valid is True
        assert call_count == 0

    def test_local_ref_valid_without_callback(self):
        """A valid instance passes when using a local $ref without a resolve_ref callback."""
        schema = {
            "type": "object",
            "$defs": {
                "color": {"type": "string", "enum": ["red", "green", "blue"]},
            },
            "properties": {
                "favorite": {"$ref": "#/$defs/color"},
            },
        }
        result = validate_instance({"favorite": "red"}, schema)
        assert result.valid is True

    def test_local_ref_invalid_without_callback(self):
        """A value not matching a local $ref produces a validation error."""
        schema = {
            "type": "object",
            "$defs": {
                "color": {"type": "string", "enum": ["red", "green", "blue"]},
            },
            "properties": {
                "favorite": {"$ref": "#/$defs/color"},
            },
        }
        result = validate_instance({"favorite": "purple"}, schema)
        assert result.valid is False

    def test_chained_refs(self):
        """A $ref that itself contains a $ref to another external schema."""
        inner_schema = {
            "type": "object",
            "properties": {"zip": {"type": "string", "pattern": "^[0-9]{5}$"}},
            "required": ["zip"],
        }
        outer_schema = {
            "type": "object",
            "properties": {
                "location": {"$ref": "urn:example:location"},
            },
        }
        location_schema = {
            "type": "object",
            "properties": {
                "postal": {"$ref": "urn:example:postal"},
            },
            "required": ["postal"],
        }
        schemas = {
            "urn:example:location": location_schema,
            "urn:example:postal": inner_schema,
        }

        def _resolve(uri: str) -> dict:
            return schemas[uri]

        # Valid
        result = validate_instance(
            {"location": {"postal": {"zip": "12345"}}},
            outer_schema,
            resolve_ref=_resolve,
        )
        assert result.valid is True

        # Invalid -- zip wrong format
        result = validate_instance(
            {"location": {"postal": {"zip": "bad"}}},
            outer_schema,
            resolve_ref=_resolve,
        )
        assert result.valid is False

    def test_none_resolve_ref_same_as_omitted(self):
        """Passing resolve_ref=None behaves identically to omitting it."""
        schema = {"type": "integer"}
        result = validate_instance(42, schema, resolve_ref=None)
        assert result.valid is True
