"""Tests for version utility module (setuptools-scm based)."""

from sonnet_server.utils.version import get_version, parse_version


class TestParseVersion:
    """Test cases for parse_version with setuptools-scm format."""

    def test_release_tag(self):
        """Exact release tag: '0.1.0'."""
        base, post, commit, dirty, ts = parse_version("0.1.0")
        assert base == "0.1.0"
        assert post is None
        assert commit is None
        assert dirty is False
        assert ts is None

    def test_dev_with_commit(self):
        """Dev version with commit hash: '0.1.1.dev5+g7295a81'."""
        base, post, commit, dirty, ts = parse_version("0.1.1.dev5+g7295a81")
        assert base == "0.1.1"
        assert post == "5"
        assert commit == "7295a81"
        assert dirty is False
        assert ts is None

    def test_dev_with_commit_and_date(self):
        """Dev version with commit and date: '0.1.1.dev5+g7295a81.d20260308'."""
        base, post, commit, dirty, ts = parse_version("0.1.1.dev5+g7295a81.d20260308")
        assert base == "0.1.1"
        assert post == "5"
        assert commit == "7295a81"
        assert dirty is True
        assert ts == "20260308"

    def test_post_release(self):
        """Post-release: '0.1.0.post3+gabcdef0'."""
        base, post, commit, dirty, ts = parse_version("0.1.0.post3+gabcdef0")
        assert base == "0.1.0"
        assert post == "3"
        assert commit == "abcdef0"
        assert dirty is False

    def test_no_local_part(self):
        """Version with dev but no local segment: '0.2.0.dev0'."""
        base, post, commit, dirty, ts = parse_version("0.2.0.dev0")
        assert base == "0.2.0"
        assert post == "0"
        assert commit is None
        assert dirty is False

    def test_unparseable_version(self):
        """Fallback for unknown formats."""
        base, post, commit, dirty, ts = parse_version("unknown")
        assert base == "unknown"
        assert post is None
        assert commit is None
        assert dirty is False
        assert ts is None


class TestGetVersion:
    """Test get_version returns a VersionInfo model."""

    def test_returns_version_info(self):
        """get_version should return a VersionInfo with at least a base version."""
        result = get_version()
        assert result.full_version
        assert result.version
        assert "." in result.version or result.version == "0.0.0-dev"
