"""Tests for _extract_unique_violation helper in CrudRepository."""

from unittest.mock import MagicMock

from sqlalchemy.exc import IntegrityError

from sonnet_server.database.crud.repository import _extract_unique_violation


def _make_integrity_error(detail: str) -> IntegrityError:
    """Build an IntegrityError whose orig.__str__() returns the given detail string."""
    orig = MagicMock()
    orig.__str__ = MagicMock(return_value=detail)
    return IntegrityError(statement=None, params=None, orig=orig)


class TestExtractUniqueViolation:
    """Tests for _extract_unique_violation."""

    def test_single_column_violation(self):
        """Standard single-column PostgreSQL unique violation."""
        exc = _make_integrity_error(
            'ERROR:  duplicate key value violates unique constraint "users_username_key"\n'
            "DETAIL:  Key (username)=(alice) already exists."
        )
        field, value = _extract_unique_violation(exc)
        assert field == "username"
        assert value == "alice"

    def test_single_column_email(self):
        exc = _make_integrity_error("DETAIL:  Key (email)=(alice@example.com) already exists.")
        field, value = _extract_unique_violation(exc)
        assert field == "email"
        assert value == "alice@example.com"

    def test_composite_column_violation(self):
        """Composite unique constraint returns both column names."""
        exc = _make_integrity_error("DETAIL:  Key (space_id, username)=(sp_123, alice) already exists.")
        field, value = _extract_unique_violation(exc)
        assert field == "space_id, username"
        assert value == "sp_123, alice"

    def test_unrecognized_format_returns_none(self):
        """SQLite or unrecognized error format returns (None, None)."""
        exc = _make_integrity_error("UNIQUE constraint failed: users.username")
        field, value = _extract_unique_violation(exc)
        assert field is None
        assert value is None

    def test_no_orig_falls_back_to_exc_str(self):
        """When orig is None, falls back to str(exc)."""
        exc = IntegrityError(statement=None, params=None, orig=None)
        # No PG-style detail -- should return (None, None) gracefully.
        field, value = _extract_unique_violation(exc)
        assert field is None
        assert value is None
