"""Tests for the GraphQL context class."""

from unittest.mock import MagicMock, patch

import pytest
from fastapi import Request
from sqlmodel import Session

from sonnet_server.graphql.context import GraphQLContext
from sonnet_server.services.registry import ServiceRegistry


class MockService:
    """A mock service class for testing."""

    def __init__(self, value: str = "default"):
        """Initialize with a value."""
        self.value = value

    def get_value(self) -> str:
        """Get the service value."""
        return self.value


@pytest.fixture
def mock_db_session():
    """Create a mock database session."""
    return MagicMock(spec=Session)


@pytest.fixture
def mock_request():
    """Create a mock request."""
    return Request({"type": "http"})


@pytest.fixture
def test_registry():
    """Create a test registry."""
    return ServiceRegistry()


@pytest.fixture
def patch_registry(test_registry):
    """Patch the get_service_registry function to return our test registry."""
    with patch("sonnet_server.graphql.context.get_service_registry", return_value=test_registry):
        yield test_registry


def test_graphql_context_service_access(mock_request, mock_db_session, patch_registry):
    """Test that the GraphQL context can access services from the registry."""
    # Register a test service in our patched registry
    test_service = MockService("test_value")
    patch_registry.register_singleton(MockService, test_service)
    # Create a context that will use our patched registry
    context = GraphQLContext(db_session=mock_db_session, request=mock_request)
    # Get the service from the context
    retrieved_service = context.service(MockService)
    # Verify it's the same service we registered
    assert retrieved_service is test_service
    assert retrieved_service.get_value() == "test_value"


def test_graphql_context_additional_values(mock_request, mock_db_session):
    """Test that the GraphQL context can store additional values."""
    context = GraphQLContext(db_session=mock_db_session, request=mock_request, custom_value="custom", another_value=42)
    assert context.custom_value == "custom"
    assert context.another_value == 42
    assert context.db_session is mock_db_session
    assert context.request is mock_request


@pytest.mark.usefixtures("patch_registry")
def test_graphql_context_service_not_found(mock_request, mock_db_session):
    """Test that the GraphQL context raises an error for unregistered services.

    patch_registry is applied via usefixtures to ensure the registry is
    clean and isolated for this test, without the fixture appearing as an
    unused parameter.
    """
    context = GraphQLContext(db_session=mock_db_session, request=mock_request)
    with pytest.raises(KeyError, match="Service MockService not registered"):
        context.service(MockService)
