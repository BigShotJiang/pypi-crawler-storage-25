"""Tests for InProcessChannel and HandlerExecutor."""

import pytest
from pydantic import BaseModel

from sonnet_server.messaging.channels.in_process import InProcessChannel
from sonnet_server.messaging.types import HandlerExecutor


class SampleEvent(BaseModel):
    value: str


class OtherEvent(BaseModel):
    count: int


@pytest.fixture
def channel():
    return InProcessChannel("test")


# -- Handler registration --------------------------------------------------


class TestHandlerRegistration:
    def test_add_handler(self, channel):
        async def handler(event: SampleEvent):
            pass

        channel.add_handler(SampleEvent, handler)
        assert channel.get_handler_count(SampleEvent) == 1

    def test_add_multiple_handlers(self, channel):
        async def h1(event: SampleEvent):
            pass

        async def h2(event: SampleEvent):
            pass

        channel.add_handler(SampleEvent, h1)
        channel.add_handler(SampleEvent, h2)
        assert channel.get_handler_count(SampleEvent) == 2

    def test_has_handler(self, channel):
        async def handler(event: SampleEvent):
            pass

        assert not channel.has_handler(SampleEvent, handler)
        channel.add_handler(SampleEvent, handler)
        assert channel.has_handler(SampleEvent, handler)

    def test_remove_handler(self, channel):
        async def handler(event: SampleEvent):
            pass

        channel.add_handler(SampleEvent, handler)
        assert channel.remove_handler(SampleEvent, handler)
        assert channel.get_handler_count(SampleEvent) == 0

    def test_remove_nonexistent_handler(self, channel):
        async def handler(event: SampleEvent):
            pass

        assert not channel.remove_handler(SampleEvent, handler)

    def test_handlers_isolated_per_event_type(self, channel):
        async def h1(event: SampleEvent):
            pass

        async def h2(event: OtherEvent):
            pass

        channel.add_handler(SampleEvent, h1)
        channel.add_handler(OtherEvent, h2)
        assert channel.get_handler_count(SampleEvent) == 1
        assert channel.get_handler_count(OtherEvent) == 1


# -- Dispatch ---------------------------------------------------------------


class TestDispatch:
    @pytest.mark.anyio
    async def test_dispatch_calls_handler(self, channel):
        received = []

        async def handler(event: SampleEvent):
            received.append(event.value)
            return "ok"

        channel.add_handler(SampleEvent, handler)
        results = await channel.dispatch(SampleEvent(value="hello"))

        assert received == ["hello"]
        assert results == ["ok"]

    @pytest.mark.anyio
    async def test_dispatch_multiple_handlers(self, channel):
        received = []

        async def h1(event: SampleEvent):
            received.append(f"h1:{event.value}")

        async def h2(event: SampleEvent):
            received.append(f"h2:{event.value}")

        channel.add_handler(SampleEvent, h1)
        channel.add_handler(SampleEvent, h2)
        await channel.dispatch(SampleEvent(value="x"))

        assert sorted(received) == ["h1:x", "h2:x"]

    @pytest.mark.anyio
    async def test_dispatch_no_handlers(self, channel):
        results = await channel.dispatch(SampleEvent(value="ignored"))
        assert results == []

    @pytest.mark.anyio
    async def test_dispatch_wrong_event_type(self, channel):
        async def handler(event: SampleEvent):
            pass

        channel.add_handler(SampleEvent, handler)
        results = await channel.dispatch(OtherEvent(count=1))
        assert results == []

    @pytest.mark.anyio
    async def test_error_isolation(self, channel):
        results_collected = []

        async def failing_handler(_event: SampleEvent):
            raise ValueError("boom")

        async def good_handler(_event: SampleEvent):
            results_collected.append("ok")
            return "success"

        channel.add_handler(SampleEvent, failing_handler)
        channel.add_handler(SampleEvent, good_handler)
        results = await channel.dispatch(SampleEvent(value="test"))

        assert results_collected == ["ok"]
        assert len(results) == 2
        exceptions = [r for r in results if isinstance(r, Exception)]
        successes = [r for r in results if r == "success"]
        assert len(exceptions) == 1
        assert isinstance(exceptions[0], ValueError)
        assert str(exceptions[0]) == "boom"
        assert len(successes) == 1

    @pytest.mark.anyio
    async def test_event_isolation(self):
        channel = InProcessChannel("test", isolate_events=True)
        events_seen = []

        async def handler(event: SampleEvent):
            events_seen.append(id(event))

        channel.add_handler(SampleEvent, handler)
        channel.add_handler(SampleEvent, handler)
        await channel.dispatch(SampleEvent(value="test"))

        assert len(events_seen) == 2
        assert events_seen[0] != events_seen[1]

    @pytest.mark.anyio
    async def test_event_isolation_override(self):
        channel = InProcessChannel("test", isolate_events=False)
        events_seen = []

        async def handler(event: SampleEvent):
            events_seen.append(id(event))

        channel.add_handler(SampleEvent, handler)
        channel.add_handler(SampleEvent, handler)

        await channel.dispatch(SampleEvent(value="test"), isolate=True)
        assert events_seen[0] != events_seen[1]


# -- Class-based handlers ---------------------------------------------------


class TestClassBasedHandlers:
    @pytest.mark.anyio
    async def test_class_handler_with_handle_method(self, channel):
        received = []

        class MyHandler:
            async def handle(self, event: SampleEvent):
                received.append(event.value)
                return "class_handled"

        channel.add_handler(SampleEvent, MyHandler)
        results = await channel.dispatch(SampleEvent(value="from_class"))

        assert received == ["from_class"]
        assert results == ["class_handled"]

    @pytest.mark.anyio
    async def test_class_handler_without_handle_raises(self, channel):
        class BadHandler:
            pass

        channel.add_handler(SampleEvent, BadHandler)
        results = await channel.dispatch(SampleEvent(value="test"))

        assert len(results) == 1
        assert isinstance(results[0], AttributeError)
        assert "must have a 'handle' method" in str(results[0])


# -- HandlerExecutor directly -----------------------------------------------


class TestHandlerExecutor:
    @pytest.fixture
    def executor(self):
        return HandlerExecutor()

    @pytest.mark.anyio
    async def test_execute_function_handler(self, executor):
        async def handler(event: SampleEvent):
            return event.value

        result = await executor.execute(handler, SampleEvent(value="direct"))
        assert result == "direct"

    @pytest.mark.anyio
    async def test_execute_class_handler(self, executor):
        class Handler:
            async def handle(self, event: SampleEvent):
                return f"handled:{event.value}"

        result = await executor.execute(Handler, SampleEvent(value="cls"))
        assert result == "handled:cls"

    @pytest.mark.anyio
    async def test_execute_failing_handler_returns_exception(self, executor):
        async def handler(_event: SampleEvent):
            raise RuntimeError("test error")

        result = await executor.execute(handler, SampleEvent(value="x"))
        assert isinstance(result, RuntimeError)
        assert str(result) == "test error"

    @pytest.mark.anyio
    async def test_execute_class_without_handle(self, executor):
        class NoHandle:
            pass

        result = await executor.execute(NoHandle, SampleEvent(value="x"))
        assert isinstance(result, AttributeError)


# -- Channel protocol methods ----------------------------------------------


class TestProtocolMethods:
    @pytest.mark.anyio
    async def test_start_stop_are_noops(self, channel):
        await channel.start()
        await channel.stop()

    @pytest.mark.anyio
    async def test_publish_raises(self, channel):
        with pytest.raises(NotImplementedError):
            await channel.publish("type", b"data")

    @pytest.mark.anyio
    async def test_subscribe_raises(self, channel):
        with pytest.raises(NotImplementedError):
            await channel.subscribe("type", lambda x: None)

    def test_name(self, channel):
        assert channel.name == "test"

    def test_supports_dispatch(self, channel):
        assert channel.supports_dispatch() is True
