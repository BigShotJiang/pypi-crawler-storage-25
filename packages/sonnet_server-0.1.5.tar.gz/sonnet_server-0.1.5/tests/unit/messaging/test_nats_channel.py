"""Unit tests for NatsChannel and NatsPublisher.

All tests mock nats-py -- no real NATS server required.
Integration tests (real NATS) are out of scope for the unit suite.
"""

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from pydantic import BaseModel

pytest.importorskip("nats", reason="nats-py optional dependency not installed (pip install sonnet-server[nats])")

from sonnet_server.messaging.channels.nats import (
    NatsChannel,
    NatsPublisher,
    _create_from_nats_publish_url,
    _create_from_nats_url,
    _server_url_from_parsed,
    _subject_from_url,
)

# -- Test event types -------------------------------------------------------


class SampleEvent(BaseModel):
    value: str


# -- URL helpers ------------------------------------------------------------


class TestUrlHelpers:
    def test_subject_from_url(self):
        from urllib.parse import urlparse

        parsed = urlparse("nats://localhost:4222?subject=sonnet_internal")
        assert _subject_from_url(parsed) == "sonnet_internal"

    def test_subject_missing_raises(self):
        from urllib.parse import urlparse

        parsed = urlparse("nats://localhost:4222")
        with pytest.raises(ValueError, match="Missing 'subject'"):
            _subject_from_url(parsed)

    def test_server_url_strips_subject(self):
        from urllib.parse import urlparse

        parsed = urlparse("nats://user:pass@host:4222?subject=sonnet_internal&token=abc")
        url = _server_url_from_parsed(parsed)
        assert "subject" not in url
        assert "token=abc" in url
        assert "host:4222" in url

    def test_server_url_no_extra_params(self):
        from urllib.parse import urlparse

        parsed = urlparse("nats://localhost:4222?subject=test")
        url = _server_url_from_parsed(parsed)
        assert url == "nats://localhost:4222"

    def test_server_url_preserves_scheme(self):
        from urllib.parse import urlparse

        parsed = urlparse("nats://localhost:4222?subject=test")
        url = _server_url_from_parsed(parsed)
        assert url.startswith("nats://")


# -- ChannelFactory creator -------------------------------------------------


class TestChannelFactoryCreator:
    def test_create_from_nats_url(self):
        from urllib.parse import urlparse

        parsed = urlparse("nats://localhost:4222?subject=sonnet_internal")
        ch = _create_from_nats_url(parsed)
        assert isinstance(ch, NatsChannel)
        assert ch.name == "sonnet_internal"

    def test_factory_registered_scheme(self):
        from sonnet_server.messaging.types import get_channel_factory

        schemes = get_channel_factory().get_schemes()
        assert "nats" in schemes


# -- NatsChannel properties -------------------------------------------------


class TestNatsChannelProperties:
    def test_name(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        assert ch.name == "sonnet_internal"

    def test_supports_dispatch_false(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        assert ch.supports_dispatch() is False

    @pytest.mark.anyio
    async def test_dispatch_raises(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        with pytest.raises(NotImplementedError):
            await ch.dispatch(SampleEvent(value="x"))


# -- publish ----------------------------------------------------------------


class TestNatsChannelPublish:
    @pytest.mark.anyio
    async def test_publish_sends_to_nats(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        mock_nc = AsyncMock()
        mock_nc.is_closed = False
        ch._nc = mock_nc

        payload = json.dumps({"type": "sonnet.test", "data": {"value": "x"}}).encode()
        await ch.publish("sonnet.test", payload)

        mock_nc.publish.assert_called_once_with("sonnet_internal", payload)

    @pytest.mark.anyio
    async def test_publish_when_not_connected_logs_error(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        # _nc is None -- not connected
        payload = json.dumps({"type": "sonnet.test", "data": {}}).encode()
        # should not raise, just log error
        await ch.publish("sonnet.test", payload)

    @pytest.mark.anyio
    async def test_publish_when_closed_logs_error(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        mock_nc = AsyncMock()
        mock_nc.is_closed = True
        ch._nc = mock_nc

        payload = json.dumps({"type": "sonnet.test", "data": {}}).encode()
        await ch.publish("sonnet.test", payload)
        mock_nc.publish.assert_not_called()


# -- subscribe / add_handler ------------------------------------------------


class TestNatsChannelSubscribe:
    @pytest.mark.anyio
    async def test_subscribe_registers_callback(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        received = []

        async def callback(data: bytes):
            received.append(data)

        await ch.subscribe("sonnet.test", callback)
        assert len(ch._callbacks.get("sonnet.test", [])) == 1

    def test_add_handler_registers_pydantic_handler(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")

        async def handler(event: SampleEvent):
            pass

        ch.add_handler(SampleEvent, handler)
        assert SampleEvent in ch._pydantic_handlers
        assert len(ch._pydantic_handlers[SampleEvent]) == 1


# -- _dispatch_payload (inherited from BrokerChannel) -----------------------


class TestNatsChannelDispatch:
    @pytest.mark.anyio
    async def test_dispatches_to_raw_callback(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        received = []

        async def callback(data: bytes):
            received.append(json.loads(data))

        await ch.subscribe("sonnet.test", callback)
        await ch._dispatch_payload(json.dumps({"type": "sonnet.test", "data": {"value": "hi"}}).encode())

        assert len(received) == 1
        assert received[0]["data"]["value"] == "hi"

    @pytest.mark.anyio
    async def test_dispatches_to_pydantic_handler(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        received = []

        async def handler(event: SampleEvent):
            received.append(event.value)

        ch.add_handler(SampleEvent, handler)

        mock_router = MagicMock()
        mock_router.type_registry.get_class.return_value = SampleEvent
        with patch("sonnet_server.messaging.get_message_router", return_value=mock_router):
            await ch._dispatch_payload(json.dumps({"type": "sonnet.sample", "data": {"value": "hello"}}).encode())

        assert received == ["hello"]

    @pytest.mark.anyio
    async def test_ignores_invalid_json(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        await ch._dispatch_payload(b"not-json")

    @pytest.mark.anyio
    async def test_ignores_missing_type_field(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        await ch._dispatch_payload(json.dumps({"data": {}}).encode())


# -- ping -------------------------------------------------------------------


class TestNatsChannelPing:
    def test_ping_success(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        mock_sock = MagicMock()
        with patch("sonnet_server.messaging.channels.nats.socket.create_connection", return_value=mock_sock):
            assert ch.ping() is True
        mock_sock.close.assert_called_once()

    def test_ping_failure(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        with patch("sonnet_server.messaging.channels.nats.socket.create_connection", side_effect=OSError("refused")):
            assert ch.ping() is False

    def test_ping_default_port(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost")
        mock_sock = MagicMock()
        with patch("sonnet_server.messaging.channels.nats.socket.create_connection", return_value=mock_sock) as mock_connect:
            ch.ping()
            # default NATS port is 4222
            mock_connect.assert_called_once_with(("localhost", 4222), timeout=3)


# -- lifecycle --------------------------------------------------------------


class TestNatsChannelLifecycle:
    @pytest.mark.anyio
    async def test_start_connects_and_subscribes(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")

        mock_nc = AsyncMock()
        mock_nc.is_closed = False
        mock_sub = AsyncMock()
        mock_nc.subscribe.return_value = mock_sub

        with patch("nats.connect", return_value=mock_nc) as mock_connect:
            await ch.start()

        mock_connect.assert_called_once()
        # Verify connect was called with the server URL
        call_args = mock_connect.call_args
        assert call_args[0][0] == "nats://localhost:4222"
        # Verify subscribe was called with the subject
        mock_nc.subscribe.assert_called_once()
        call_args = mock_nc.subscribe.call_args
        assert call_args[0][0] == "sonnet_internal"
        assert ch._nc is mock_nc
        assert ch._sub is mock_sub

    @pytest.mark.anyio
    async def test_stop_drains_and_closes(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        mock_nc = AsyncMock()
        mock_nc.is_closed = False
        ch._nc = mock_nc

        await ch.stop()

        mock_nc.drain.assert_called_once()
        assert ch._nc is None
        assert ch._sub is None

    @pytest.mark.anyio
    async def test_stop_before_start_is_safe(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        await ch.stop()  # should not raise

    @pytest.mark.anyio
    async def test_stop_handles_drain_error(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        mock_nc = AsyncMock()
        mock_nc.is_closed = False
        mock_nc.drain.side_effect = RuntimeError("drain failed")
        ch._nc = mock_nc

        # should not raise -- drain errors are caught
        await ch.stop()
        assert ch._nc is None

    @pytest.mark.anyio
    async def test_stop_skips_if_already_closed(self):
        ch = NatsChannel("sonnet_internal", "nats://localhost:4222")
        mock_nc = AsyncMock()
        mock_nc.is_closed = True
        ch._nc = mock_nc

        await ch.stop()
        mock_nc.drain.assert_not_called()


# -- NatsPublisher ----------------------------------------------------------


class TestNatsPublisherCreator:
    def test_create_from_nats_publish_url(self):
        from urllib.parse import urlparse

        parsed = urlparse("nats+publish://localhost:4222?subject=audit.events")
        pub = _create_from_nats_publish_url(parsed)
        assert isinstance(pub, NatsPublisher)
        assert pub.name == "audit.events"

    def test_factory_registered_scheme(self):
        from sonnet_server.messaging.types import get_channel_factory

        schemes = get_channel_factory().get_schemes()
        assert "nats+publish" in schemes


class TestNatsPublisherProperties:
    def test_name(self):
        pub = NatsPublisher("audit.events", "nats://localhost:4222")
        assert pub.name == "audit.events"

    def test_url_stored(self):
        pub = NatsPublisher("audit.events", "nats://localhost:4222", url="nats+publish://localhost:4222?subject=audit.events")
        assert pub.url == "nats+publish://localhost:4222?subject=audit.events"

    def test_url_default_empty(self):
        pub = NatsPublisher("audit.events", "nats://localhost:4222")
        assert pub.url == ""

    def test_factory_creator_stores_url(self):
        from urllib.parse import urlparse

        original_url = "nats+publish://localhost:4222?subject=audit.events"
        parsed = urlparse(original_url)
        pub = _create_from_nats_publish_url(parsed)
        assert pub.url == original_url

    def test_satisfies_publisher_protocol(self):
        from sonnet_server.messaging.types import Publisher

        pub = NatsPublisher("audit.events", "nats://localhost:4222")
        assert isinstance(pub, Publisher)

    def test_does_not_satisfy_channel_protocol(self):
        from sonnet_server.messaging.types import Channel

        pub = NatsPublisher("audit.events", "nats://localhost:4222")
        assert not isinstance(pub, Channel)


class TestNatsPublisherPublish:
    @pytest.mark.anyio
    async def test_publish_sends_to_nats(self):
        pub = NatsPublisher("audit.events", "nats://localhost:4222")
        mock_nc = AsyncMock()
        mock_nc.is_closed = False
        pub._nc = mock_nc

        payload = json.dumps({"type": "sonnet.test", "data": {}}).encode()
        await pub.publish("sonnet.test", payload)

        mock_nc.publish.assert_called_once_with("audit.events", payload)

    @pytest.mark.anyio
    async def test_publish_when_not_connected_logs_error(self):
        pub = NatsPublisher("audit.events", "nats://localhost:4222")
        payload = json.dumps({"type": "sonnet.test", "data": {}}).encode()
        await pub.publish("sonnet.test", payload)  # should not raise

    @pytest.mark.anyio
    async def test_publish_when_closed_logs_error(self):
        pub = NatsPublisher("audit.events", "nats://localhost:4222")
        mock_nc = AsyncMock()
        mock_nc.is_closed = True
        pub._nc = mock_nc

        await pub.publish("sonnet.test", b"payload")
        mock_nc.publish.assert_not_called()


class TestNatsPublisherPing:
    def test_ping_success(self):
        pub = NatsPublisher("audit.events", "nats://localhost:4222")
        mock_sock = MagicMock()
        with patch("sonnet_server.messaging.channels.nats.socket.create_connection", return_value=mock_sock):
            assert pub.ping() is True

    def test_ping_failure(self):
        pub = NatsPublisher("audit.events", "nats://localhost:4222")
        with patch("sonnet_server.messaging.channels.nats.socket.create_connection", side_effect=OSError("refused")):
            assert pub.ping() is False


class TestNatsPublisherLifecycle:
    @pytest.mark.anyio
    async def test_start_connects_without_subscribing(self):
        pub = NatsPublisher("audit.events", "nats://localhost:4222")
        mock_nc = AsyncMock()
        mock_nc.is_closed = False

        with patch("nats.connect", return_value=mock_nc) as mock_connect:
            await pub.start()

        mock_connect.assert_called_once()
        call_args = mock_connect.call_args
        assert call_args[0][0] == "nats://localhost:4222"
        mock_nc.subscribe.assert_not_called()
        assert pub._nc is mock_nc

    @pytest.mark.anyio
    async def test_stop_drains_and_clears(self):
        pub = NatsPublisher("audit.events", "nats://localhost:4222")
        mock_nc = AsyncMock()
        mock_nc.is_closed = False
        pub._nc = mock_nc

        await pub.stop()

        mock_nc.drain.assert_called_once()
        assert pub._nc is None

    @pytest.mark.anyio
    async def test_stop_before_start_is_safe(self):
        pub = NatsPublisher("audit.events", "nats://localhost:4222")
        await pub.stop()  # should not raise

    @pytest.mark.anyio
    async def test_stop_handles_drain_error(self):
        pub = NatsPublisher("audit.events", "nats://localhost:4222")
        mock_nc = AsyncMock()
        mock_nc.is_closed = False
        mock_nc.drain.side_effect = RuntimeError("drain failed")
        pub._nc = mock_nc

        await pub.stop()
        assert pub._nc is None
