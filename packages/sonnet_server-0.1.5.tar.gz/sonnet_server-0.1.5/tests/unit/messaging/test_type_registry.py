"""Tests for TypeRegistry, Binding, HandlerRegistry, @handles decorator,
RetryPolicy, HandlerExecutor, and correlation context."""

import pytest
from pydantic import BaseModel

from sonnet_server.messaging.types import (
    _HANDLES_ATTR,
    DEFAULT_MIDDLEWARE,
    Binding,
    HandlerExecutor,
    HandlerRegistry,
    RetryPolicy,
    TypeRegistry,
    _causation_id_var,
    _correlation_id_var,
    _derive_type_name,
    get_causation_id,
    get_correlation_id,
    handles,
    logging_middleware,
    new_event_id,
    retry_middleware,
)


class EventA(BaseModel):
    value: str


class EventB(BaseModel):
    count: int


class EventC(BaseModel):
    flag: bool


class EventASub(EventA):
    """Subclass of EventA for inheritance tests."""

    extra: str = ""


# -- TypeRegistry -----------------------------------------------------------


@pytest.fixture
def registry():
    return TypeRegistry()


class TestTypeRegistry:
    def test_register_and_lookup_by_name(self, registry):
        registry.register("sonnet.event_a", EventA)
        assert registry.get_class("sonnet.event_a") is EventA

    def test_register_and_lookup_by_class(self, registry):
        registry.register("sonnet.event_a", EventA)
        assert registry.get_type_name(EventA) == "sonnet.event_a"

    def test_is_registered(self, registry):
        assert not registry.is_registered(EventA)
        registry.register("sonnet.event_a", EventA)
        assert registry.is_registered(EventA)

    def test_lookup_unregistered_name(self, registry):
        assert registry.get_class("nonexistent") is None

    def test_lookup_unregistered_class(self, registry):
        assert registry.get_type_name(EventA) is None

    def test_register_same_mapping_twice(self, registry):
        registry.register("sonnet.event_a", EventA)
        registry.register("sonnet.event_a", EventA)  # idempotent

    def test_register_name_conflict(self, registry):
        registry.register("sonnet.event_a", EventA)
        with pytest.raises(ValueError, match="already registered to EventA"):
            registry.register("sonnet.event_a", EventB)

    def test_register_class_conflict(self, registry):
        registry.register("sonnet.event_a", EventA)
        with pytest.raises(ValueError, match="already registered as"):
            registry.register("sonnet.different_name", EventA)

    def test_multiple_registrations(self, registry):
        registry.register("sonnet.event_a", EventA)
        registry.register("sonnet.event_b", EventB)
        registry.register("sonnet.event_c", EventC)

        assert registry.get_class("sonnet.event_a") is EventA
        assert registry.get_class("sonnet.event_b") is EventB
        assert registry.get_class("sonnet.event_c") is EventC
        assert registry.get_type_name(EventA) == "sonnet.event_a"
        assert registry.get_type_name(EventB) == "sonnet.event_b"
        assert registry.get_type_name(EventC) == "sonnet.event_c"

    def test_subclass_not_matched_by_parent(self, registry):
        """Subclass is a distinct type -- not found via parent registration."""
        registry.register("sonnet.event_a", EventA)
        assert registry.get_type_name(EventASub) is None
        assert not registry.is_registered(EventASub)

    def test_subclass_registered_independently(self, registry):
        """Subclass can be registered with its own type name."""
        registry.register("sonnet.event_a", EventA)
        registry.register("sonnet.event_a_sub", EventASub)
        assert registry.get_type_name(EventA) == "sonnet.event_a"
        assert registry.get_type_name(EventASub) == "sonnet.event_a_sub"

    def test_ensure_registered_auto_derives(self, registry):
        """ensure_registered creates a type name if not already registered."""
        type_name = registry.ensure_registered(EventA)
        assert type_name == "sonnet.event_a"
        assert registry.get_class("sonnet.event_a") is EventA

    def test_ensure_registered_returns_existing(self, registry):
        """ensure_registered returns existing name if already registered."""
        registry.register("sonnet.custom_name", EventA)
        type_name = registry.ensure_registered(EventA)
        assert type_name == "sonnet.custom_name"

    def test_ensure_registered_idempotent(self, registry):
        """Calling ensure_registered twice does not raise."""
        registry.ensure_registered(EventA)
        registry.ensure_registered(EventA)
        assert registry.get_type_name(EventA) == "sonnet.event_a"


class TestDeriveTypeName:
    def test_simple_camel_case(self):
        assert _derive_type_name(EventA) == "sonnet.event_a"

    def test_multi_word_camel_case(self):
        class SchemaDefinitionChanged(BaseModel):
            pass

        assert _derive_type_name(SchemaDefinitionChanged) == "sonnet.schema_definition_changed"

    def test_consecutive_uppercase(self):
        class HTTPError(BaseModel):
            pass

        # Consecutive uppercase letters are not split (only lower->upper boundaries)
        assert _derive_type_name(HTTPError) == "sonnet.httperror"

    def test_already_lowercase(self):
        class simple(BaseModel):  # noqa: N801
            pass

        assert _derive_type_name(simple) == "sonnet.simple"


# -- Binding ----------------------------------------------------------------


class TestBinding:
    def test_accepts_without_predicate(self):
        """Binding with no predicate accepts all events."""

        class FakeChannel:
            name = "fake"

        binding = Binding(FakeChannel())
        assert binding.accepts(EventA(value="anything"))

    def test_accepts_with_passing_predicate(self):
        class FakeChannel:
            name = "fake"

        binding = Binding(FakeChannel(), predicate=lambda e: e.value == "yes")
        assert binding.accepts(EventA(value="yes"))

    def test_rejects_with_failing_predicate(self):
        class FakeChannel:
            name = "fake"

        binding = Binding(FakeChannel(), predicate=lambda e: e.value == "yes")
        assert not binding.accepts(EventA(value="no"))


# -- HandlerRegistry -------------------------------------------------------


class TestHandlerRegistry:
    @pytest.fixture
    def registry(self):
        return HandlerRegistry()

    def test_register_and_get(self, registry):
        async def handler(event: EventA):
            pass

        registry.register(EventA, handler)
        entries = registry.get_handlers()
        assert len(entries) == 1
        assert entries[0] == (EventA, handler)

    def test_get_handlers_filtered(self, registry):
        async def ha(event: EventA):
            pass

        async def hb(event: EventB):
            pass

        registry.register(EventA, ha)
        registry.register(EventB, hb)

        assert len(registry.get_handlers(EventA)) == 1
        assert registry.get_handlers(EventA)[0][1] is ha
        assert len(registry.get_handlers(EventB)) == 1

    def test_get_event_types(self, registry):
        async def ha(event: EventA):
            pass

        async def hb(event: EventB):
            pass

        registry.register(EventA, ha)
        registry.register(EventB, hb)
        types = registry.get_event_types()
        assert set(types) == {EventA, EventB}

    def test_size(self, registry):
        assert registry.size == 0

        async def handler(event: EventA):
            pass

        registry.register(EventA, handler)
        assert registry.size == 1

    def test_clear(self, registry):
        async def handler(event: EventA):
            pass

        registry.register(EventA, handler)
        registry.clear()
        assert registry.size == 0

    def test_multiple_handlers_same_event(self, registry):
        async def h1(event: EventA):
            pass

        async def h2(event: EventA):
            pass

        registry.register(EventA, h1)
        registry.register(EventA, h2)
        assert len(registry.get_handlers(EventA)) == 2


# -- @handles decorator -----------------------------------------------------


class TestHandlesDecorator:
    def test_sets_attribute(self):
        """Decorator sets _handles_event on the function."""

        # Use a local registry to avoid polluting the global one
        @handles(EventA)
        async def handler(event: EventA):
            pass

        assert getattr(handler, _HANDLES_ATTR) is EventA

    def test_registers_in_global_registry(self):
        """Decorator registers the handler in the global handler registry."""
        from sonnet_server.messaging.types import get_handler_registry

        registry = get_handler_registry()
        initial_size = registry.size

        @handles(EventB)
        async def my_test_handler(event: EventB):
            pass

        assert registry.size == initial_size + 1
        # Find our handler
        entries = registry.get_handlers(EventB)
        handlers = [h for _, h in entries if h is my_test_handler]
        assert len(handlers) == 1

    def test_preserves_function(self):
        """Decorator returns the original function unchanged."""

        @handles(EventA)
        async def handler(_event: EventA):
            return "result"

        assert handler.__name__ == "handler"

    def test_handles_with_retry_registers_in_registry(self):
        from sonnet_server.messaging.types import get_handler_registry

        registry = get_handler_registry()

        policy = RetryPolicy(max_attempts=5)

        @handles(EventB, retry=policy)
        async def handler_with_retry(_event: EventB):
            pass

        entries = registry.get_entries(EventB)
        # Find our handler
        matching = [e for e in entries if e.handler is handler_with_retry]
        assert len(matching) == 1
        assert matching[0].retry is policy

    def test_handles_without_retry_has_no_retry(self):
        from sonnet_server.messaging.types import NO_RETRY, get_handler_registry

        registry = get_handler_registry()

        @handles(EventC)
        async def handler_no_retry(_event: EventC):
            pass

        entries = registry.get_entries(EventC)
        matching = [e for e in entries if e.handler is handler_no_retry]
        assert len(matching) == 1
        assert matching[0].retry is NO_RETRY


# -- RetryPolicy -------------------------------------------------------------


class TestRetryPolicy:
    def test_defaults(self):
        p = RetryPolicy()
        assert p.max_attempts == 1
        assert p.base_delay == 0.1
        assert p.backoff_multiplier == 2.0
        assert p.max_delay == 10.0

    def test_custom_values(self):
        p = RetryPolicy(max_attempts=5, base_delay=0.5, backoff_multiplier=3.0, max_delay=30.0)
        assert p.max_attempts == 5
        assert p.base_delay == 0.5

    def test_invalid_max_attempts(self):
        with pytest.raises(ValueError, match="max_attempts must be >= 1"):
            RetryPolicy(max_attempts=0)

    def test_frozen(self):
        p = RetryPolicy()
        with pytest.raises(AttributeError):
            p.max_attempts = 5


# -- HandlerExecutor ---------------------------------------------------------


class TestHandlerExecutor:
    @pytest.mark.anyio
    async def test_execute_returns_result(self):
        executor = HandlerExecutor()

        async def handler(event: EventA):
            return f"got:{event.value}"

        result = await executor.execute(handler, EventA(value="x"))
        assert result == "got:x"

    @pytest.mark.anyio
    async def test_execute_returns_exception_on_failure(self):
        executor = HandlerExecutor()

        async def handler(_event: EventA):
            raise ValueError("boom")

        result = await executor.execute(handler, EventA(value="x"))
        assert isinstance(result, ValueError)
        assert str(result) == "boom"

    @pytest.mark.anyio
    async def test_execute_with_retry_retries_on_failure(self):
        executor = HandlerExecutor()
        attempts = []

        async def handler(_event: EventA):
            attempts.append(1)
            if len(attempts) < 3:
                raise RuntimeError("transient")
            return "ok"

        policy = RetryPolicy(max_attempts=3, base_delay=0.01)
        result = await executor.execute(handler, EventA(value="x"), retry=policy)
        assert result == "ok"
        assert len(attempts) == 3

    @pytest.mark.anyio
    async def test_execute_with_retry_exhausted_returns_error(self):
        executor = HandlerExecutor()
        attempts = []

        async def handler(_event: EventA):
            attempts.append(1)
            raise RuntimeError("permanent")

        policy = RetryPolicy(max_attempts=2, base_delay=0.01)
        result = await executor.execute(handler, EventA(value="x"), retry=policy)
        assert isinstance(result, RuntimeError)
        assert len(attempts) == 2

    @pytest.mark.anyio
    async def test_execute_no_retry_by_default(self):
        executor = HandlerExecutor()
        attempts = []

        async def handler(_event: EventA):
            attempts.append(1)
            raise RuntimeError("fail")

        result = await executor.execute(handler, EventA(value="x"))
        assert isinstance(result, RuntimeError)
        assert len(attempts) == 1


# -- Correlation context -----------------------------------------------------


class TestCorrelationContext:
    def test_default_is_none(self):
        _correlation_id_var.set(None)
        _causation_id_var.set(None)
        assert get_correlation_id() is None
        assert get_causation_id() is None

    def test_set_and_get(self):
        _correlation_id_var.set("corr-123")
        _causation_id_var.set("cause-456")
        assert get_correlation_id() == "corr-123"
        assert get_causation_id() == "cause-456"
        # Clean up
        _correlation_id_var.set(None)
        _causation_id_var.set(None)

    def test_new_event_id_is_unique(self):
        id1 = new_event_id()
        id2 = new_event_id()
        assert id1 != id2
        assert len(id1) == 36  # UUID format


# -- Middleware chain --------------------------------------------------------


class TestMiddlewareChain:
    @pytest.mark.anyio
    async def test_custom_middleware_wraps_handler(self):
        """Custom middleware can intercept before and after handler."""
        calls = []

        async def tracking_middleware(handler, event, call_next):
            calls.append("before")
            result = await call_next(handler, event)
            calls.append("after")
            return result

        async def handler(_event: EventA):
            calls.append("handler")
            return "done"

        executor = HandlerExecutor(middlewares=[tracking_middleware])
        result = await executor.execute(handler, EventA(value="x"))
        assert result == "done"
        assert calls == ["before", "handler", "after"]

    @pytest.mark.anyio
    async def test_middleware_order_is_outer_to_inner(self):
        """First middleware in list is outermost (runs first before, last after)."""
        order = []

        async def first(handler, event, call_next):
            order.append("first-before")
            result = await call_next(handler, event)
            order.append("first-after")
            return result

        async def second(handler, event, call_next):
            order.append("second-before")
            result = await call_next(handler, event)
            order.append("second-after")
            return result

        async def handler(_event: EventA):
            order.append("handler")
            return "done"

        executor = HandlerExecutor(middlewares=[first, second])
        await executor.execute(handler, EventA(value="x"))
        assert order == ["first-before", "second-before", "handler", "second-after", "first-after"]

    @pytest.mark.anyio
    async def test_empty_middleware_still_executes_handler(self):
        """Empty middleware list falls through to _invoke_handler directly."""
        received = []

        async def handler(event: EventA):
            received.append(event.value)
            return "ok"

        executor = HandlerExecutor(middlewares=[])
        result = await executor.execute(handler, EventA(value="direct"))
        assert result == "ok"
        assert received == ["direct"]

    @pytest.mark.anyio
    async def test_default_middleware_stack(self):
        """DEFAULT_MIDDLEWARE contains retry and logging middlewares."""
        assert retry_middleware in DEFAULT_MIDDLEWARE
        assert logging_middleware in DEFAULT_MIDDLEWARE
        assert DEFAULT_MIDDLEWARE.index(retry_middleware) < DEFAULT_MIDDLEWARE.index(logging_middleware)

    @pytest.mark.anyio
    async def test_middleware_exception_propagates_to_outer(self):
        """Exceptions propagate through the chain to outer middleware."""
        caught = []

        async def outer(handler, event, call_next):
            try:
                return await call_next(handler, event)
            except ValueError as e:
                caught.append(str(e))
                return None

        async def handler(_event: EventA):
            raise ValueError("propagated")

        executor = HandlerExecutor(middlewares=[outer])
        result = await executor.execute(handler, EventA(value="x"))
        assert result is None
        assert caught == ["propagated"]

    @pytest.mark.anyio
    async def test_retry_middleware_standalone(self):
        """retry_middleware reads _retry_policy_var and retries on failure."""
        from sonnet_server.messaging.types import _retry_policy_var

        attempts = []

        async def handler(_event: EventA):
            attempts.append(1)
            if len(attempts) < 3:
                raise RuntimeError("transient")
            return "recovered"

        async def terminal(h, e):
            return await h(e)

        _retry_policy_var.set(RetryPolicy(max_attempts=3, base_delay=0.01))
        result = await retry_middleware(handler, EventA(value="x"), terminal)
        assert result == "recovered"
        assert len(attempts) == 3

    @pytest.mark.anyio
    async def test_logging_middleware_standalone(self):
        """logging_middleware passes result through and does not swallow exceptions."""
        received = []

        async def handler(event: EventA):
            received.append(event.value)
            return "logged"

        async def terminal(h, e):
            return await h(e)

        result = await logging_middleware(handler, EventA(value="x"), terminal)
        assert result == "logged"
        assert received == ["x"]

    @pytest.mark.anyio
    async def test_logging_middleware_propagates_exception(self):
        """logging_middleware does not catch exceptions -- they propagate up."""

        async def handler(_event: EventA):
            raise RuntimeError("unhandled")

        async def terminal(h, e):
            return await h(e)

        with pytest.raises(RuntimeError, match="unhandled"):
            await logging_middleware(handler, EventA(value="x"), terminal)
