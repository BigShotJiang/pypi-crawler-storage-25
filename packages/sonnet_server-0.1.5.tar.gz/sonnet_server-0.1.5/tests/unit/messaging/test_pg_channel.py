"""Unit tests for PgChannel.

All tests mock psycopg -- no real Postgres connection required.
Integration tests (real DB) are out of scope for the unit suite.
"""

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from pydantic import BaseModel

from sonnet_server.messaging.channels.postgres import (
    PgChannel,
    _channel_name_from_url,
    _create_from_explicit_url,
    _create_from_shorthand_url,
    _dsn_from_parsed,
    to_psycopg_dsn,
)

# -- Test event types -------------------------------------------------------


class SampleEvent(BaseModel):
    value: str


# -- to_psycopg_dsn --------------------------------------------------------


class TestToPsycopgDsn:
    def test_strips_sqlalchemy_dialect(self):
        url = "postgresql+psycopg://user:pass@host:5432/db"
        assert to_psycopg_dsn(url) == "postgresql://user:pass@host:5432/db"

    def test_plain_postgresql_unchanged(self):
        url = "postgresql://user:pass@host:5432/db"
        assert to_psycopg_dsn(url) == url

    def test_postgres_scheme_unchanged(self):
        url = "postgres://user:pass@host:5432/db"
        assert to_psycopg_dsn(url) == url

    def test_preserves_query_params(self):
        url = "postgresql+psycopg://user:pass@host:5432/db?sslmode=require"
        assert to_psycopg_dsn(url) == "postgresql://user:pass@host:5432/db?sslmode=require"


# -- URL helpers ------------------------------------------------------------


class TestUrlHelpers:
    def test_channel_name_from_url(self):
        from urllib.parse import urlparse

        parsed = urlparse("postgres://host/db?channel=sonnet.internal")
        assert _channel_name_from_url(parsed) == "sonnet.internal"

    def test_channel_name_missing_raises(self):
        from urllib.parse import urlparse

        parsed = urlparse("postgres://host/db")
        with pytest.raises(ValueError, match="Missing 'channel'"):
            _channel_name_from_url(parsed)

    def test_dsn_strips_channel_param(self):
        from urllib.parse import urlparse

        parsed = urlparse("postgres://user:pass@host:5432/db?sslmode=require&channel=sonnet.internal")
        dsn = _dsn_from_parsed(parsed)
        assert "channel" not in dsn
        assert "sslmode=require" in dsn
        assert "host" in dsn

    def test_dsn_scheme_normalized_to_postgresql(self):
        from urllib.parse import urlparse

        parsed = urlparse("postgres://host:5432/db?channel=test")
        dsn = _dsn_from_parsed(parsed)
        assert dsn.startswith("postgresql://")


# -- ChannelFactory creators ------------------------------------------------


class TestChannelFactoryCreators:
    def test_create_from_explicit_url(self):
        from urllib.parse import urlparse

        parsed = urlparse("postgres://user:pass@host:5432/db?sslmode=require&channel=sonnet.internal")
        ch = _create_from_explicit_url(parsed)
        assert isinstance(ch, PgChannel)
        assert ch.name == "sonnet.internal"

    def test_create_from_shorthand_url(self):
        from urllib.parse import urlparse

        parsed = urlparse("postgres+listen://?channel=sonnet.internal")
        with patch("sonnet_server.settings.get_settings") as mock_settings:
            mock_settings.return_value.database_url = "postgresql+psycopg://user:pass@host:5432/db"
            ch = _create_from_shorthand_url(parsed)
        assert isinstance(ch, PgChannel)
        assert ch.name == "sonnet.internal"

    def test_create_from_shorthand_url_no_database_url_raises(self):
        from urllib.parse import urlparse

        parsed = urlparse("postgres+listen://?channel=sonnet.internal")
        with patch("sonnet_server.settings.get_settings") as mock_settings:
            mock_settings.return_value.database_url = None
            with pytest.raises(ValueError, match="SONNET_SERVER_DATABASE_URL"):
                _create_from_shorthand_url(parsed)

    def test_factory_registered_schemes(self):
        from sonnet_server.messaging.types import get_channel_factory

        schemes = get_channel_factory().get_schemes()
        assert "postgres" in schemes
        assert "postgres+listen" in schemes


# -- PgChannel properties ---------------------------------------------------


class TestPgChannelProperties:
    def test_name(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        assert ch.name == "sonnet.internal"

    def test_supports_dispatch_false(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        assert ch.supports_dispatch() is False

    @pytest.mark.anyio
    async def test_dispatch_raises(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        with pytest.raises(NotImplementedError):
            await ch.dispatch(SampleEvent(value="x"))


# -- publish ----------------------------------------------------------------


class TestPgChannelPublish:
    @pytest.mark.anyio
    async def test_publish_calls_pg_notify(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        payload = json.dumps({"type": "sonnet.test", "data": {"value": "x"}}).encode()

        mock_conn = AsyncMock()
        with patch("psycopg.AsyncConnection.connect", return_value=mock_conn):
            await ch.publish("sonnet.test", payload)

        mock_conn.set_autocommit.assert_called_once_with(True)
        mock_conn.execute.assert_called_once()
        call_args = mock_conn.execute.call_args[0]
        assert "pg_notify" in call_args[0]
        assert call_args[1][0] == "sonnet.internal"
        mock_conn.close.assert_called_once()

    @pytest.mark.anyio
    async def test_publish_skips_oversized_payload(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        # 8001 byte payload
        oversized = ("x" * 8001).encode("utf-8")

        with patch("psycopg.AsyncConnection.connect") as mock_connect:
            await ch.publish("sonnet.test", oversized)
            mock_connect.assert_not_called()

    @pytest.mark.anyio
    async def test_publish_raises_on_connection_error(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        payload = json.dumps({"type": "sonnet.test", "data": {}}).encode()

        with patch("psycopg.AsyncConnection.connect", side_effect=OSError("connection refused")), pytest.raises(OSError):
            await ch.publish("sonnet.test", payload)


# -- subscribe / add_handler ------------------------------------------------


class TestPgChannelSubscribe:
    @pytest.mark.anyio
    async def test_subscribe_registers_callback(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        received = []

        async def callback(data: bytes):
            received.append(data)

        await ch.subscribe("sonnet.test", callback)
        assert len(ch._callbacks.get("sonnet.test", [])) == 1

    def test_add_handler_registers_pydantic_handler(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")

        async def handler(event: SampleEvent):
            pass

        ch.add_handler(SampleEvent, handler)
        assert SampleEvent in ch._pydantic_handlers
        assert len(ch._pydantic_handlers[SampleEvent]) == 1


# -- _dispatch_payload ------------------------------------------------------


class TestPgChannelDispatch:
    @pytest.mark.anyio
    async def test_dispatches_to_raw_callback(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        received = []

        async def callback(data: bytes):
            received.append(json.loads(data))

        await ch.subscribe("sonnet.test", callback)
        await ch._dispatch_payload(json.dumps({"type": "sonnet.test", "data": {"value": "hi"}}).encode())

        assert len(received) == 1
        assert received[0]["data"]["value"] == "hi"

    @pytest.mark.anyio
    async def test_dispatches_to_pydantic_handler(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        received = []

        async def handler(event: SampleEvent):
            received.append(event.value)

        ch.add_handler(SampleEvent, handler)

        # Mock the TypeRegistry resolution: type string -> Pydantic class
        mock_router = MagicMock()
        mock_router.type_registry.get_class.return_value = SampleEvent
        with patch("sonnet_server.messaging.get_message_router", return_value=mock_router):
            await ch._dispatch_payload(json.dumps({"type": "sonnet.sample", "data": {"value": "hello"}}).encode())

        assert received == ["hello"]

    @pytest.mark.anyio
    async def test_ignores_invalid_json(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        # should not raise
        await ch._dispatch_payload(b"not-json")

    @pytest.mark.anyio
    async def test_ignores_missing_type_field(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        # should not raise
        await ch._dispatch_payload(json.dumps({"data": {}}).encode())

    @pytest.mark.anyio
    async def test_no_handler_for_type_is_silent(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        # should not raise -- unknown type just has no handlers
        await ch._dispatch_payload(json.dumps({"type": "unknown.event", "data": {}}).encode())

    @pytest.mark.anyio
    async def test_callback_error_does_not_stop_other_callbacks(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        received = []

        async def bad_callback(_data: bytes):
            raise RuntimeError("boom")

        async def good_callback(_data: bytes):
            received.append("ok")

        await ch.subscribe("sonnet.test", bad_callback)
        await ch.subscribe("sonnet.test", good_callback)
        await ch._dispatch_payload(json.dumps({"type": "sonnet.test", "data": {}}).encode())

        assert received == ["ok"]


# -- lifecycle --------------------------------------------------------------


class TestPgChannelLifecycle:
    @pytest.mark.anyio
    async def test_stop_before_start_is_safe(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")
        await ch.stop()  # should not raise

    @pytest.mark.anyio
    async def test_start_creates_listener_task(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")

        mock_conn = AsyncMock()
        # notifies() returns an async generator that yields nothing then stops
        mock_conn.notifies = MagicMock(return_value=_empty_async_gen())

        with patch("psycopg.AsyncConnection.connect", return_value=mock_conn):
            await ch.start()
            assert ch._listener_task is not None
            await ch.stop()

    @pytest.mark.anyio
    async def test_stop_cancels_listener_task(self):
        ch = PgChannel("sonnet.internal", "postgresql://host/db")

        mock_conn = AsyncMock()
        mock_conn.notifies = MagicMock(return_value=_hanging_async_gen())

        with patch("psycopg.AsyncConnection.connect", return_value=mock_conn):
            await ch.start()
            await asyncio.sleep(0)  # let listener task start
            await ch.stop()
            assert ch._listener_task is None


async def _empty_async_gen():
    """Async generator that yields nothing -- simulates no notifications."""
    return
    yield  # make it an async generator


async def _hanging_async_gen():
    """Async generator that hangs until cancelled."""
    try:
        await asyncio.sleep(9999)
        yield  # never reached
    except asyncio.CancelledError:
        return
