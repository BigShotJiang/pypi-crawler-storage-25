"""Tests for MessageRouter."""

import asyncio

import pytest
from pydantic import BaseModel

from sonnet_server.messaging import MessageRouter
from sonnet_server.messaging.channels.in_process import InProcessChannel


class EventA(BaseModel):
    value: str


class EventB(BaseModel):
    count: int


@pytest.fixture
def router():
    return MessageRouter()


@pytest.fixture
def local():
    return InProcessChannel("local")


# -- Binding ----------------------------------------------------------------


class TestBinding:
    def test_bind_registers_channel(self, router, local):
        router.bind(EventA, local)
        assert router.get_sink("local") is local

    def test_bind_creates_binding(self, router, local):
        router.bind(EventA, local)
        bindings = router.get_bindings(EventA)
        assert len(bindings) == 1
        assert bindings[0].sink is local

    def test_bind_multiple_channels(self, router):
        ch1 = InProcessChannel("ch1")
        ch2 = InProcessChannel("ch2")
        router.bind(EventA, ch1)
        router.bind(EventA, ch2)
        bindings = router.get_bindings(EventA)
        assert len(bindings) == 2

    def test_bind_duplicate_ignored(self, router, local):
        router.bind(EventA, local)
        router.bind(EventA, local)
        assert len(router.get_bindings(EventA)) == 1

    def test_bind_with_predicate(self, router, local):
        def value_predicate(e):
            return e.value == "x"

        router.bind(EventA, local, predicate=value_predicate)
        bindings = router.get_bindings(EventA)
        assert len(bindings) == 1
        assert bindings[0].predicate is value_predicate

    def test_unbind(self, router, local):
        router.bind(EventA, local)
        router.unbind(EventA, local)
        assert len(router.get_bindings(EventA)) == 0

    def test_unbind_nonexistent(self, router, local):
        router.unbind(EventA, local)  # should not raise


# -- Channel management -----------------------------------------------------


class TestSinkManagement:
    def test_add_sink(self, router, local):
        router.add_sink(local)
        assert router.get_sink("local") is local

    def test_add_sink_duplicate_same_instance(self, router, local):
        router.add_sink(local)
        router.add_sink(local)  # no error

    def test_add_sink_duplicate_different_instance(self, router):
        ch1 = InProcessChannel("same-name")
        ch2 = InProcessChannel("same-name")
        router.add_sink(ch1)
        with pytest.raises(ValueError, match="already registered"):
            router.add_sink(ch2)

    @pytest.mark.anyio
    async def test_remove_sink_removes_bindings(self, router, local):
        router.bind(EventA, local)
        router.bind(EventB, local)
        await router.remove_sink("local")
        assert router.get_sink("local") is None
        assert len(router.get_bindings(EventA)) == 0
        assert len(router.get_bindings(EventB)) == 0

    @pytest.mark.anyio
    async def test_remove_sink_nonexistent_is_noop(self, router):
        await router.remove_sink("does-not-exist")  # should not raise

    def test_get_sink_names(self, router):
        ch1 = InProcessChannel("alpha")
        ch2 = InProcessChannel("beta")
        router.add_sink(ch1)
        router.add_sink(ch2)
        assert sorted(router.get_sink_names()) == ["alpha", "beta"]

    def test_get_sinks_by_prefix(self, router):
        ch1 = InProcessChannel("auditing-tenant-a")
        ch2 = InProcessChannel("auditing-tenant-b")
        ch3 = InProcessChannel("internal")
        router.add_sink(ch1)
        router.add_sink(ch2)
        router.add_sink(ch3)
        result = router.get_sinks_by_prefix("auditing-")
        assert len(result) == 2
        assert ch3 not in result

    def test_get_sinks_by_prefix_no_match(self, router):
        router.add_sink(InProcessChannel("internal"))
        assert router.get_sinks_by_prefix("auditing-") == []

    @pytest.mark.anyio
    async def test_replace_sink(self, router):
        old = InProcessChannel("my-sink")
        new = InProcessChannel("my-sink")
        router.bind(EventA, old)
        await router.replace_sink("my-sink", new)
        assert router.get_sink("my-sink") is new
        bindings = router.get_bindings(EventA)
        assert len(bindings) == 1
        assert bindings[0].sink is new

    @pytest.mark.anyio
    async def test_replace_sink_name_mismatch_raises(self, router):
        router.add_sink(InProcessChannel("old-name"))
        with pytest.raises(ValueError, match="does not match"):
            await router.replace_sink("old-name", InProcessChannel("wrong-name"))

    @pytest.mark.anyio
    async def test_replace_sink_not_registered_adds_it(self, router):
        new = InProcessChannel("brand-new")
        await router.replace_sink("brand-new", new)
        assert router.get_sink("brand-new") is new

    @pytest.mark.anyio
    async def test_add_and_start_sink(self, router):
        ch = InProcessChannel("dynamic")
        await router.add_and_start_sink(ch)
        assert router.get_sink("dynamic") is ch


# -- Subscribe --------------------------------------------------------------


class TestSubscribe:
    def test_subscribe_registers_handler(self, router, local):
        async def handler(event: EventA):
            pass

        router.subscribe(EventA, local, handler)
        assert local.has_handler(EventA, handler)

    def test_subscribe_registers_channel(self, router):
        ch = InProcessChannel("auto-registered")

        async def handler(event: EventA):
            pass

        router.subscribe(EventA, ch, handler)
        assert router.get_sink("auto-registered") is ch


# -- Emit -------------------------------------------------------------------


class TestEmit:
    @pytest.mark.anyio
    async def test_emit_and_wait_basic(self, router, local):
        received = []

        async def handler(event: EventA):
            received.append(event.value)
            return "done"

        router.bind(EventA, local)
        router.subscribe(EventA, local, handler)
        results = await router.emit_and_wait(EventA(value="hello"))

        assert received == ["hello"]
        assert results == ["done"]

    @pytest.mark.anyio
    async def test_emit_and_wait_no_bindings(self, router):
        results = await router.emit_and_wait(EventA(value="ignored"))
        assert results == []

    @pytest.mark.anyio
    async def test_emit_and_wait_multiple_channels(self, router):
        ch1 = InProcessChannel("ch1")
        ch2 = InProcessChannel("ch2")
        received = []

        async def h1(event: EventA):
            received.append(f"ch1:{event.value}")
            return "r1"

        async def h2(event: EventA):
            received.append(f"ch2:{event.value}")
            return "r2"

        router.bind(EventA, ch1)
        router.bind(EventA, ch2)
        router.subscribe(EventA, ch1, h1)
        router.subscribe(EventA, ch2, h2)

        results = await router.emit_and_wait(EventA(value="x"))
        assert sorted(received) == ["ch1:x", "ch2:x"]
        assert sorted(results) == ["r1", "r2"]

    @pytest.mark.anyio
    async def test_emit_and_wait_with_predicate(self, router):
        ch_all = InProcessChannel("all")
        ch_filtered = InProcessChannel("filtered")
        received = {"all": [], "filtered": []}

        async def h_all(event: EventA):
            received["all"].append(event.value)

        async def h_filtered(event: EventA):
            received["filtered"].append(event.value)

        router.bind(EventA, ch_all)
        router.bind(EventA, ch_filtered, predicate=lambda e: e.value == "match")
        router.subscribe(EventA, ch_all, h_all)
        router.subscribe(EventA, ch_filtered, h_filtered)

        await router.emit_and_wait(EventA(value="no-match"))
        await router.emit_and_wait(EventA(value="match"))

        assert received["all"] == ["no-match", "match"]
        assert received["filtered"] == ["match"]

    @pytest.mark.anyio
    async def test_emit_and_wait_channel_override(self, router):
        ch1 = InProcessChannel("ch1")
        ch2 = InProcessChannel("ch2")
        received = {"ch1": [], "ch2": []}

        async def h1(event: EventA):
            received["ch1"].append(event.value)

        async def h2(event: EventA):
            received["ch2"].append(event.value)

        router.bind(EventA, ch1)
        router.bind(EventA, ch2)
        router.subscribe(EventA, ch1, h1)
        router.subscribe(EventA, ch2, h2)

        await router.emit_and_wait(EventA(value="targeted"), sinks=[ch2])
        assert received["ch1"] == []
        assert received["ch2"] == ["targeted"]

    @pytest.mark.anyio
    async def test_emit_and_wait_multiple_event_types(self, router, local):
        received = {"a": [], "b": []}

        async def ha(event: EventA):
            received["a"].append(event.value)

        async def hb(event: EventB):
            received["b"].append(event.count)

        router.bind(EventA, local)
        router.bind(EventB, local)
        router.subscribe(EventA, local, ha)
        router.subscribe(EventB, local, hb)

        await router.emit_and_wait(EventA(value="x"))
        await router.emit_and_wait(EventB(count=42))

        assert received["a"] == ["x"]
        assert received["b"] == [42]

    @pytest.mark.anyio
    async def test_emit_fire_and_forget_from_async(self, router, local):
        """emit() from an async context schedules a task."""
        received = []

        async def handler(event: EventA):
            received.append(event.value)

        router.bind(EventA, local)
        router.subscribe(EventA, local, handler)

        router.emit(EventA(value="async-ff"))
        # Give the task a chance to run
        await asyncio.sleep(0.05)
        assert received == ["async-ff"]

    @pytest.mark.anyio
    async def test_emit_predicate_that_raises(self, router):
        """A predicate that raises should not crash the router."""
        ch = InProcessChannel("ch")
        received = []

        async def handler(event: EventA):
            received.append(event.value)

        def bad_predicate(_event):
            raise RuntimeError("predicate error")

        router.bind(EventA, ch, predicate=bad_predicate)
        router.subscribe(EventA, ch, handler)

        # The predicate raises, so the binding should be skipped.
        # This documents current behavior: the exception propagates.
        with pytest.raises(RuntimeError, match="predicate error"):
            await router.emit_and_wait(EventA(value="test"))

    def test_emit_sync(self, router, local):
        """emit_sync() works from a synchronous context."""
        received = []

        async def handler(event: EventA):
            received.append(event.value)
            return "sync_result"

        router.bind(EventA, local)
        router.subscribe(EventA, local, handler)

        results = router.emit_sync(EventA(value="sync-test"))
        assert received == ["sync-test"]
        assert results == ["sync_result"]


# -- emit_to -----------------------------------------------------------------


class TestEmitTo:
    @pytest.mark.anyio
    async def test_emit_to_named_sink(self, router):
        ch = InProcessChannel("my-sink")
        received = []

        async def handler(event: EventA):
            received.append(event.value)

        router.add_sink(ch)
        router.subscribe(EventA, ch, handler)

        await router.emit_to(EventA(value="direct"), "my-sink")
        assert received == ["direct"]

    @pytest.mark.anyio
    async def test_emit_to_unknown_sink_logs_warning(self, router):
        # Should not raise -- just log a warning
        await router.emit_to(EventA(value="lost"), "nonexistent")

    @pytest.mark.anyio
    async def test_emit_to_bypasses_bindings(self, router):
        """emit_to delivers to the named sink regardless of bindings."""
        ch1 = InProcessChannel("sink-a")
        ch2 = InProcessChannel("sink-b")
        received = {"a": [], "b": []}

        async def h1(event: EventA):
            received["a"].append(event.value)

        async def h2(event: EventA):
            received["b"].append(event.value)

        router.bind(EventA, ch1)
        router.subscribe(EventA, ch1, h1)
        router.subscribe(EventA, ch2, h2)

        # emit_to sink-b only -- ch1 binding should not fire
        await router.emit_to(EventA(value="targeted"), "sink-b")
        assert received["a"] == []
        assert received["b"] == ["targeted"]


# -- Lifecycle ---------------------------------------------------------------


class TestLifecycle:
    @pytest.mark.anyio
    async def test_start_stop(self, router, local):
        router.add_sink(local)
        await router.start()
        await router.stop()

    @pytest.mark.anyio
    async def test_stop_cleans_executor(self, router, local):
        router.bind(EventA, local)
        # Force executor creation
        router._get_executor()
        assert router._sync_executor is not None
        await router.stop()
        assert router._sync_executor is None


# -- Introspection -----------------------------------------------------------


class TestIntrospection:
    def test_get_registered_event_types(self, router, local):
        router.bind(EventA, local)
        router.bind(EventB, local)
        types = router.get_registered_event_types()
        assert set(types) == {EventA, EventB}

    def test_get_registered_event_types_empty(self, router):
        assert router.get_registered_event_types() == []


# -- Subclass routing -------------------------------------------------------


class EventASub(EventA):
    extra: str = ""


class TestSubclassRouting:
    @pytest.mark.anyio
    async def test_subclass_does_not_match_parent_binding(self, router, local):
        """Emitting a subclass does not trigger parent's binding."""
        received = []

        async def handler(event: EventA):
            received.append(event.value)

        router.bind(EventA, local)
        router.subscribe(EventA, local, handler)

        await router.emit_and_wait(EventASub(value="sub", extra="x"))
        assert received == [], "Subclass should not match parent binding"

    @pytest.mark.anyio
    async def test_subclass_with_own_binding(self, router, local):
        """Subclass with its own binding works independently."""
        received_parent = []
        received_sub = []

        async def h_parent(event: EventA):
            received_parent.append(event.value)

        async def h_sub(event: EventASub):
            received_sub.append(event.extra)

        router.bind(EventA, local)
        router.bind(EventASub, local)
        router.subscribe(EventA, local, h_parent)
        router.subscribe(EventASub, local, h_sub)

        await router.emit_and_wait(EventA(value="parent"))
        await router.emit_and_wait(EventASub(value="child", extra="data"))

        assert received_parent == ["parent"]
        assert received_sub == ["data"]


# -- wire_handlers -----------------------------------------------------------


class TestWireHandlers:
    @pytest.mark.anyio
    async def test_wire_handlers_from_registry(self, router):
        """wire_handlers reads the handler registry and wires all handlers."""
        from sonnet_server.messaging.types import get_handler_registry

        registry = get_handler_registry()

        # Save and replace global registry
        saved = list(registry._entries)
        registry.clear()

        received = []

        async def ha(event: EventA):
            received.append(f"a:{event.value}")

        async def hb(event: EventB):
            received.append(f"b:{event.count}")

        registry.register(EventA, ha)
        registry.register(EventB, hb)

        try:
            local = InProcessChannel("test-wire")
            count = router.wire_handlers(local)
            assert count == 2

            await router.emit_and_wait(EventA(value="x"))
            await router.emit_and_wait(EventB(count=42))
            assert sorted(received) == ["a:x", "b:42"]
        finally:
            # Restore global registry
            registry.clear()
            registry._entries.extend(saved)


# -- Correlation context in emit -------------------------------------------


class TestCorrelationInEmit:
    @pytest.mark.anyio
    async def test_correlation_id_set_during_handler(self, router):
        """Handlers see the correlation_id set by the dispatch context."""
        from sonnet_server.messaging.types import _correlation_id_var

        ch = InProcessChannel("local")
        captured_id = []

        async def handler(_event: EventA):
            captured_id.append(_correlation_id_var.get())

        router.bind(EventA, ch)
        router.subscribe(EventA, ch, handler)

        _correlation_id_var.set("test-corr-id")
        try:
            await router.emit_and_wait(EventA(value="x"))
            # In-process dispatch does not change correlation context
            # (only broker dispatch sets it from the envelope)
            assert captured_id == ["test-corr-id"]
        finally:
            _correlation_id_var.set(None)

    @pytest.mark.anyio
    async def test_wire_handlers_filtered_by_event_type(self, router):
        """wire_handlers with event_types filter only wires matching handlers."""
        from sonnet_server.messaging.types import get_handler_registry

        registry = get_handler_registry()

        saved = list(registry._entries)
        registry.clear()

        received = []

        async def ha(_event: EventA):
            received.append("a")

        async def hb(_event: EventB):
            received.append("b")

        registry.register(EventA, ha)
        registry.register(EventB, hb)

        try:
            local = InProcessChannel("test-wire-filtered")
            count = router.wire_handlers(local, event_types=[EventA])
            assert count == 1

            await router.emit_and_wait(EventA(value="x"))
            await router.emit_and_wait(EventB(count=1))
            assert received == ["a"]
        finally:
            registry.clear()
            registry._entries.extend(saved)
