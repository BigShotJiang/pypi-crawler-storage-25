"""Tests for the schema walker.

All tests use plain dict resolvers -- no DB, no framework, no domain knowledge.
The typed_ref_map and skip_properties are always caller-supplied.
"""

from sonnet_server.utils.filtering.filter_defs import FilterDef, FilterOperator
from sonnet_server.utils.filtering.schema_walker import RefResolver, filter_defs_from_schema

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

# A minimal "quantity" schema -- the walker never looks inside it, it is a leaf.
_QUANTITY_SCHEMA = {
    "type": "object",
    "properties": {
        "value": {"type": "number"},
        "unit": {"type": "string"},
    },
}

# A minimal "coding" schema -- also a leaf.
_CODING_SCHEMA = {
    "type": "object",
    "properties": {
        "system": {"type": "string"},
        "code": {"type": "string"},
    },
}

# Address schema stored externally (used in $ref tests).
_ADDRESS_SCHEMA = {
    "type": "object",
    "properties": {
        "city": {"type": "string"},
        "country": {"type": "string"},
        "zip": {"type": "string"},
    },
}

# Typed ref map -- caller-owned, no domain URIs in the walker.
_TYPED_REFS: dict[str, str] = {
    "https://types.example.com/quantity": "quantity",
    "https://types.example.com/coding": "coding",
}

# Resolver for external schemas.
_RESOLVER: RefResolver = {
    "https://schemas.example.com/address": _ADDRESS_SCHEMA,
    "https://types.example.com/quantity": _QUANTITY_SCHEMA,
    "https://types.example.com/coding": _CODING_SCHEMA,
}.get

_NO_RESOLVER: RefResolver = lambda uri: None  # noqa: E731


def _keys(defs: list[FilterDef]) -> set[str]:
    return {d.key for d in defs}


def _by_key(defs: list[FilterDef], key: str) -> FilterDef:
    return next(d for d in defs if d.key == key)


# ---------------------------------------------------------------------------
# Patient schema: the motivating example
# ---------------------------------------------------------------------------


class TestPatientSchema:
    """Simple patient with two scalar fields and an array of addresses."""

    PATIENT_SCHEMA = {
        "$id": "https://schemas.example.com/patient",
        "type": "object",
        "properties": {
            "first_name": {"type": "string"},
            "birth_date": {"type": "string", "format": "date"},
            "addresses": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "city": {"type": "string"},
                        "country": {"type": "string"},
                    },
                },
            },
        },
    }

    def _defs(self):
        return filter_defs_from_schema(self.PATIENT_SCHEMA, resolver=_NO_RESOLVER, typed_ref_map={})

    def test_emits_three_scalar_fields(self):
        assert _keys(self._defs()) == {
            "first_name",
            "birth_date",
            "addresses.city",
            "addresses.country",
        }

    def test_first_name_is_string_with_eq_and_like(self):
        d = _by_key(self._defs(), "first_name")
        assert FilterOperator.EQ in d.operators
        assert FilterOperator.LIKE in d.operators
        assert d.json_path == ["first_name"]
        assert d.json_is_array is False

    def test_birth_date_has_comparison_operators(self):
        d = _by_key(self._defs(), "birth_date")
        assert FilterOperator.GTE in d.operators
        assert FilterOperator.LTE in d.operators
        assert FilterOperator.EQ in d.operators

    def test_address_fields_have_json_is_array(self):
        d_city = _by_key(self._defs(), "addresses.city")
        d_country = _by_key(self._defs(), "addresses.country")
        assert d_city.json_is_array is True
        assert d_country.json_is_array is True

    def test_address_fields_have_correct_json_path(self):
        d = _by_key(self._defs(), "addresses.city")
        assert d.json_path == ["city"]

    def test_column_defaults_to_empty(self):
        """Walker returns bare defs -- column is set by the caller."""
        for d in self._defs():
            assert d.column == ""

    def test_explicit_column_and_prefix(self):
        defs = filter_defs_from_schema(
            self.PATIENT_SCHEMA,
            resolver=_NO_RESOLVER,
            typed_ref_map={},
            column="data",
            prefix="data",
        )
        for d in defs:
            assert d.column == "data"
            assert d.key.startswith("data.")


# ---------------------------------------------------------------------------
# $ref to external schema
# ---------------------------------------------------------------------------


class TestRefResolution:
    """Array of addresses defined via $ref."""

    SCHEMA_WITH_REF = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "addresses": {
                "type": "array",
                "items": {"$ref": "https://schemas.example.com/address"},
            },
        },
    }

    def _defs(self):
        return filter_defs_from_schema(self.SCHEMA_WITH_REF, resolver=_RESOLVER, typed_ref_map=_TYPED_REFS)

    def test_resolves_ref_and_emits_address_fields(self):
        assert "addresses.city" in _keys(self._defs())
        assert "addresses.country" in _keys(self._defs())
        assert "addresses.zip" in _keys(self._defs())

    def test_address_fields_are_array(self):
        d = _by_key(self._defs(), "addresses.city")
        assert d.json_is_array is True

    def test_unknown_ref_is_skipped(self):
        schema = {
            "type": "object",
            "properties": {
                "thing": {"$ref": "https://unknown.example.com/thing"},
            },
        }
        defs = filter_defs_from_schema(schema, resolver=_RESOLVER, typed_ref_map=_TYPED_REFS)
        assert defs == []


# ---------------------------------------------------------------------------
# Typed refs
# ---------------------------------------------------------------------------


class TestTypedRefs:
    """Properties that reference known typed compound types."""

    SCHEMA = {
        "type": "object",
        "properties": {
            "temperature": {"$ref": "https://types.example.com/quantity"},
            "body_site": {"$ref": "https://types.example.com/coding"},
            "diagnoses": {
                "type": "array",
                "items": {"$ref": "https://types.example.com/coding"},
            },
        },
    }

    def _defs(self):
        return filter_defs_from_schema(self.SCHEMA, resolver=_RESOLVER, typed_ref_map=_TYPED_REFS)

    def test_quantity_gets_json_value_type(self):
        d = _by_key(self._defs(), "temperature")
        assert d.json_value_type == "quantity"
        assert d.json_is_array is False

    def test_coding_gets_json_value_type(self):
        d = _by_key(self._defs(), "body_site")
        assert d.json_value_type == "coding"

    def test_array_of_typed_ref(self):
        d = _by_key(self._defs(), "diagnoses")
        assert d.json_value_type == "coding"
        assert d.json_is_array is True

    def test_typed_ref_gets_comparison_operators(self):
        d = _by_key(self._defs(), "temperature")
        assert FilterOperator.EQ in d.operators
        assert FilterOperator.GTE in d.operators
        assert FilterOperator.LTE in d.operators

    def test_typed_ref_is_not_recursed_into(self):
        # quantity has sub-properties (value, unit) -- walker must not emit them
        keys = _keys(self._defs())
        assert "temperature.value" not in keys
        assert "temperature.unit" not in keys


# ---------------------------------------------------------------------------
# Skip properties
# ---------------------------------------------------------------------------


class TestSkipProperties:
    SCHEMA = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "_extensions": {"type": "object"},
            "_internal": {"type": "string"},
        },
    }

    def test_skipped_properties_not_emitted(self):
        defs = filter_defs_from_schema(
            self.SCHEMA,
            resolver=_NO_RESOLVER,
            typed_ref_map={},
            skip_properties=frozenset({"_extensions", "_internal"}),
        )
        assert _keys(defs) == {"name"}

    def test_no_skip_emits_all(self):
        defs = filter_defs_from_schema(
            self.SCHEMA,
            resolver=_NO_RESOLVER,
            typed_ref_map={},
        )
        assert "_extensions" in _keys(defs) or "_internal" in _keys(defs)


# ---------------------------------------------------------------------------
# Scalar types
# ---------------------------------------------------------------------------


class TestScalarTypes:
    SCHEMA = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "score": {"type": "number"},
            "count": {"type": "integer"},
            "active": {"type": "boolean"},
            "birth_date": {"type": "string", "format": "date"},
            "updated_at": {"type": "string", "format": "date-time"},
        },
    }

    def _defs(self):
        return filter_defs_from_schema(self.SCHEMA, resolver=_NO_RESOLVER, typed_ref_map={})

    def test_string_has_eq_and_like(self):
        d = _by_key(self._defs(), "name")
        assert d.operators == [FilterOperator.EQ, FilterOperator.LIKE]

    def test_number_has_comparison_operators(self):
        d = _by_key(self._defs(), "score")
        assert FilterOperator.GTE in d.operators
        assert FilterOperator.LT in d.operators

    def test_integer_has_comparison_operators(self):
        d = _by_key(self._defs(), "count")
        assert FilterOperator.GTE in d.operators

    def test_boolean_has_only_eq(self):
        d = _by_key(self._defs(), "active")
        assert d.operators == [FilterOperator.EQ]

    def test_date_has_comparison_operators(self):
        d = _by_key(self._defs(), "birth_date")
        assert FilterOperator.GTE in d.operators
        assert FilterOperator.LTE in d.operators

    def test_datetime_has_comparison_operators(self):
        d = _by_key(self._defs(), "updated_at")
        assert FilterOperator.GTE in d.operators


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_empty_properties_returns_empty(self):
        schema = {"type": "object", "properties": {}}
        assert filter_defs_from_schema(schema, _NO_RESOLVER, {}) == []

    def test_no_properties_key_returns_empty(self):
        schema = {"type": "object"}
        assert filter_defs_from_schema(schema, _NO_RESOLVER, {}) == []

    def test_array_without_items_is_skipped(self):
        schema = {
            "type": "object",
            "properties": {
                "tags": {"type": "array"},
            },
        }
        assert filter_defs_from_schema(schema, _NO_RESOLVER, {}) == []

    def test_cycle_protection(self):
        """Self-referencing schema does not loop infinitely."""
        schema = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "children": {
                    "type": "array",
                    "items": {"$ref": "https://schemas.example.com/node"},
                },
            },
        }
        # Resolver returns the same schema -- potential infinite loop.
        cyclic_resolver: RefResolver = lambda uri: schema  # noqa: E731
        # Must terminate without error.
        defs = filter_defs_from_schema(schema, cyclic_resolver, {})
        assert any(d.key == "name" for d in defs)

    def test_nested_object_inline(self):
        schema = {
            "type": "object",
            "properties": {
                "address": {
                    "type": "object",
                    "properties": {
                        "city": {"type": "string"},
                        "country": {"type": "string"},
                    },
                },
            },
        }
        defs = filter_defs_from_schema(schema, _NO_RESOLVER, {})
        assert "address.city" in _keys(defs)
        assert "address.country" in _keys(defs)

    def test_json_path_reflects_nesting(self):
        schema = {
            "type": "object",
            "properties": {
                "address": {
                    "type": "object",
                    "properties": {
                        "city": {"type": "string"},
                    },
                },
            },
        }
        defs = filter_defs_from_schema(schema, _NO_RESOLVER, {})
        d = _by_key(defs, "address.city")
        assert d.json_path == ["address", "city"]

    def test_json_path_accumulates_through_deep_nesting(self):
        """Two levels of inline objects: json_path must include all ancestors."""
        schema = {
            "type": "object",
            "properties": {
                "patient": {
                    "type": "object",
                    "properties": {
                        "contact": {
                            "type": "object",
                            "properties": {
                                "phone": {"type": "string"},
                                "email": {"type": "string"},
                            },
                        },
                        "name": {"type": "string"},
                    },
                },
            },
        }
        defs = filter_defs_from_schema(schema, _NO_RESOLVER, {})
        assert "patient.contact.phone" in _keys(defs)
        assert "patient.contact.email" in _keys(defs)
        assert "patient.name" in _keys(defs)

        d_phone = _by_key(defs, "patient.contact.phone")
        assert d_phone.json_path == ["patient", "contact", "phone"]

        d_name = _by_key(defs, "patient.name")
        assert d_name.json_path == ["patient", "name"]

    def test_array_items_json_path_is_relative(self):
        """Array item properties have json_path relative to the item, not the root."""
        schema = {
            "type": "object",
            "properties": {
                "addresses": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "city": {"type": "string"},
                        },
                    },
                },
            },
        }
        defs = filter_defs_from_schema(schema, _NO_RESOLVER, {})
        d = _by_key(defs, "addresses.city")
        # Array items use containment (@>), so json_path is relative to the item
        assert d.json_path == ["city"]
        assert d.json_is_array is True
