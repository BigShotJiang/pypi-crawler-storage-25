"""Tests for the DB model walker.

Uses locally defined SQLModel table classes -- no dependency on domain modules
domain models, no DB connection required.
"""

from datetime import datetime
from uuid import UUID

import pytest
import sqlalchemy as sa
from pydantic import ValidationError
from sqlmodel import Field, SQLModel

from sonnet_server.utils.filtering.db_model_walker import JsonColumnBinding, build_filter_defs, filter_defs_from_db_model
from sonnet_server.utils.filtering.filter_defs import FilterDef, FilterOperator
from sonnet_server.utils.filtering.schema_walker import RefResolver

# ---------------------------------------------------------------------------
# Test models
# ---------------------------------------------------------------------------


class PatientRecord(SQLModel, table=True):
    """Envelope + JSONB content model for walker tests."""

    __tablename__ = "test_patient_records"

    id: UUID = Field(primary_key=True)
    patient_id: str = Field(nullable=False)
    status: str = Field(nullable=False)
    record_type: str = Field(nullable=False)
    score: float | None = Field(default=None)
    count: int | None = Field(default=None)
    active: bool = Field(default=True)
    record_time: datetime | None = Field(default=None)

    # JSONB columns -- should be skipped when passed as json_columns
    content: dict | None = Field(default=None, sa_column=sa.Column(sa.JSON))
    extensions: dict | None = Field(default=None, sa_column=sa.Column(sa.JSON))

    # Internal fields -- skipped by default
    is_deleted: bool = Field(default=False)
    created_by: str | None = Field(default=None)
    updated_by: str | None = Field(default=None)


class MinimalModel(SQLModel, table=True):
    """Model with only a primary key -- edge case."""

    __tablename__ = "test_minimal"
    id: UUID = Field(primary_key=True)


class NotATableModel(SQLModel):
    """SQLModel base class without table=True -- no __table__."""

    name: str | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _keys(defs: list[FilterDef]) -> set[str]:
    return {d.key for d in defs}


def _by_key(defs: list[FilterDef], key: str) -> FilterDef:
    return next(d for d in defs if d.key == key)


# ---------------------------------------------------------------------------
# Basic field detection
# ---------------------------------------------------------------------------


class TestBasicFieldDetection:
    def _defs(self, **kwargs):
        return filter_defs_from_db_model(PatientRecord, **kwargs)

    def test_string_fields_emitted(self):
        defs = self._defs(skip_fields=frozenset(), json_columns=frozenset())
        assert "patient_id" in _keys(defs)
        assert "status" in _keys(defs)
        assert "record_type" in _keys(defs)

    def test_float_field_emitted(self):
        defs = self._defs(skip_fields=frozenset(), json_columns=frozenset())
        assert "score" in _keys(defs)

    def test_int_field_emitted(self):
        defs = self._defs(skip_fields=frozenset(), json_columns=frozenset())
        assert "count" in _keys(defs)

    def test_bool_field_emitted(self):
        defs = self._defs(skip_fields=frozenset(), json_columns=frozenset())
        assert "active" in _keys(defs)

    def test_datetime_field_emitted(self):
        defs = self._defs(skip_fields=frozenset(), json_columns=frozenset())
        assert "record_time" in _keys(defs)


# ---------------------------------------------------------------------------
# Operators per type
# ---------------------------------------------------------------------------


class TestOperators:
    def _defs(self):
        return filter_defs_from_db_model(
            PatientRecord,
            skip_fields=frozenset(),
            json_columns=frozenset(),
        )

    def test_string_has_eq_and_like(self):
        d = _by_key(self._defs(), "patient_id")
        assert d.operators == [FilterOperator.EQ, FilterOperator.LIKE]

    def test_float_has_comparison_operators(self):
        d = _by_key(self._defs(), "score")
        assert FilterOperator.GTE in d.operators
        assert FilterOperator.LTE in d.operators
        assert FilterOperator.EQ in d.operators

    def test_int_has_comparison_operators(self):
        d = _by_key(self._defs(), "count")
        assert FilterOperator.GT in d.operators
        assert FilterOperator.LT in d.operators

    def test_bool_has_only_eq(self):
        d = _by_key(self._defs(), "active")
        assert d.operators == [FilterOperator.EQ]

    def test_datetime_has_comparison_operators(self):
        d = _by_key(self._defs(), "record_time")
        assert FilterOperator.GTE in d.operators
        assert FilterOperator.LTE in d.operators

    def test_uuid_has_only_eq(self):
        d = _by_key(self._defs(), "id")
        assert d.operators == [FilterOperator.EQ]


# ---------------------------------------------------------------------------
# JSON columns skipped when declared
# ---------------------------------------------------------------------------


class TestJsonColumns:
    def test_json_columns_skipped_when_declared(self):
        defs = filter_defs_from_db_model(
            PatientRecord,
            skip_fields=frozenset(),
            json_columns=frozenset({"content", "extensions"}),
        )
        assert "content" not in _keys(defs)
        assert "extensions" not in _keys(defs)

    def test_json_columns_present_when_not_declared(self):
        # Without json_columns, the JSON type is detected and skipped
        # internally by _operators_for_column (returns None for JSON type).
        defs = filter_defs_from_db_model(
            PatientRecord,
            skip_fields=frozenset(),
            json_columns=frozenset(),
        )
        # JSON columns are always skipped by the type detector regardless
        assert "content" not in _keys(defs)
        assert "extensions" not in _keys(defs)

    def test_json_columns_explicit_skip_same_result(self):
        defs_implicit = filter_defs_from_db_model(
            PatientRecord,
            skip_fields=frozenset(),
            json_columns=frozenset(),
        )
        defs_explicit = filter_defs_from_db_model(
            PatientRecord,
            skip_fields=frozenset(),
            json_columns=frozenset({"content", "extensions"}),
        )
        assert _keys(defs_implicit) == _keys(defs_explicit)


# ---------------------------------------------------------------------------
# skip_fields
# ---------------------------------------------------------------------------


class TestSkipFields:
    def test_default_skip_excludes_internal_fields(self):
        defs = filter_defs_from_db_model(PatientRecord)
        keys = _keys(defs)
        assert "is_deleted" not in keys
        assert "created_by" not in keys
        assert "updated_by" not in keys

    def test_explicit_skip_excludes_named_fields(self):
        defs = filter_defs_from_db_model(
            PatientRecord,
            skip_fields=frozenset({"patient_id", "status"}),
        )
        assert "patient_id" not in _keys(defs)
        assert "status" not in _keys(defs)

    def test_empty_skip_includes_internal_fields(self):
        defs = filter_defs_from_db_model(
            PatientRecord,
            skip_fields=frozenset(),
        )
        # is_deleted is a bool, should appear when not skipped
        assert "is_deleted" in _keys(defs)

    def test_additional_skip_on_top_of_default(self):
        from sonnet_server.utils.filtering.db_model_walker import _DEFAULT_SKIP

        defs = filter_defs_from_db_model(
            PatientRecord,
            skip_fields=_DEFAULT_SKIP | frozenset({"score", "count"}),
        )
        assert "score" not in _keys(defs)
        assert "count" not in _keys(defs)


# ---------------------------------------------------------------------------
# FilterDef structure
# ---------------------------------------------------------------------------


class TestFilterDefStructure:
    def test_key_and_column_are_the_same(self):
        defs = filter_defs_from_db_model(PatientRecord)
        for d in defs:
            assert d.key == d.column

    def test_no_json_path(self):
        defs = filter_defs_from_db_model(PatientRecord)
        for d in defs:
            assert d.json_path is None

    def test_json_is_array_false(self):
        defs = filter_defs_from_db_model(PatientRecord)
        for d in defs:
            assert d.json_is_array is False

    def test_json_value_type_none(self):
        defs = filter_defs_from_db_model(PatientRecord)
        for d in defs:
            assert d.json_value_type is None


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# build_filter_defs -- convenience API
# ---------------------------------------------------------------------------

_EXTENSIONS_SCHEMA = {
    "type": "object",
    "properties": {
        "preferred_language": {"type": "string"},
        "insurance_number": {"type": "string"},
        "risk_score": {"type": "number"},
    },
}

_NO_RESOLVER: RefResolver = lambda uri: None  # noqa: E731


class TestBuildFilterDefs:
    def _build(self, **kwargs):
        return build_filter_defs(PatientRecord, resolver=_NO_RESOLVER, **kwargs)

    def test_no_json_bindings_returns_envelope_only(self):
        defs = self._build()
        keys = _keys(defs)
        assert "patient_id" in keys
        assert "status" in keys
        # JSONB columns silently skipped by type detector
        assert "content" not in keys
        assert "extensions" not in keys

    def test_json_schema_emits_content_fields(self):
        defs = self._build(
            json_bindings=[
                JsonColumnBinding(column="extensions", document=_EXTENSIONS_SCHEMA),
            ]
        )
        keys = _keys(defs)
        assert "extensions.preferred_language" in keys
        assert "extensions.insurance_number" in keys
        assert "extensions.risk_score" in keys

    def test_json_schema_fields_have_correct_column(self):
        defs = self._build(
            json_bindings=[
                JsonColumnBinding(column="extensions", document=_EXTENSIONS_SCHEMA),
            ]
        )
        for d in defs:
            if d.key.startswith("extensions."):
                assert d.column == "extensions"

    def test_envelope_fields_not_duplicated_for_json_column(self):
        defs = self._build(
            json_bindings=[
                JsonColumnBinding(column="extensions", document=_EXTENSIONS_SCHEMA),
            ]
        )
        # "extensions" must not appear as a raw scalar key
        assert "extensions" not in _keys(defs)

    def test_custom_alias(self):
        defs = self._build(
            json_bindings=[
                JsonColumnBinding(
                    column="extensions",
                    document=_EXTENSIONS_SCHEMA,
                    alias="ext",
                ),
            ]
        )
        keys = _keys(defs)
        assert "ext.preferred_language" in keys
        assert "ext.risk_score" in keys
        assert "extensions.preferred_language" not in keys

    def test_alias_defaults_to_column_name(self):
        defs = self._build(
            json_bindings=[
                JsonColumnBinding(column="extensions", document=_EXTENSIONS_SCHEMA),
            ]
        )
        assert "extensions.risk_score" in _keys(defs)

    def test_dollar_alias(self):
        """$ is a valid alias for addressing the JSONB root directly."""
        defs = self._build(
            json_bindings=[
                JsonColumnBinding(
                    column="extensions",
                    document=_EXTENSIONS_SCHEMA,
                    alias="$",
                ),
            ]
        )
        keys = _keys(defs)
        assert "$.preferred_language" in keys
        assert "$.risk_score" in keys
        assert "extensions.preferred_language" not in keys

        # column is still the DB column, not the alias
        for d in defs:
            if d.key.startswith("$."):
                assert d.column == "extensions"

    def test_multiple_json_columns(self):
        content_schema = {
            "type": "object",
            "properties": {
                "temperature": {"type": "number"},
            },
        }
        defs = self._build(
            json_bindings=[
                JsonColumnBinding(column="content", document=content_schema),
                JsonColumnBinding(column="extensions", document=_EXTENSIONS_SCHEMA),
            ]
        )
        keys = _keys(defs)
        assert "content.temperature" in keys
        assert "extensions.risk_score" in keys
        # Neither raw column as scalar
        assert "content" not in keys
        assert "extensions" not in keys

    def test_skip_properties_respected(self):
        defs = self._build(
            json_bindings=[
                JsonColumnBinding(
                    column="extensions",
                    document=_EXTENSIONS_SCHEMA,
                    skip_properties=frozenset({"preferred_language"}),
                ),
            ]
        )
        assert "extensions.preferred_language" not in _keys(defs)
        assert "extensions.risk_score" in _keys(defs)

    def test_envelope_and_content_ordering(self):
        defs = self._build(
            json_bindings=[
                JsonColumnBinding(column="extensions", document=_EXTENSIONS_SCHEMA),
            ]
        )
        envelope_keys = {d.key for d in defs if d.json_path is None}
        content_keys = {d.key for d in defs if d.json_path is not None}
        # Envelope defs come first
        envelope_indices = [i for i, d in enumerate(defs) if d.key in envelope_keys]
        content_indices = [i for i, d in enumerate(defs) if d.key in content_keys]
        assert max(envelope_indices) < min(content_indices)

    def test_skip_fields_propagated(self):
        from sonnet_server.utils.filtering.db_model_walker import _DEFAULT_SKIP

        defs = self._build(
            skip_fields=_DEFAULT_SKIP | frozenset({"score"}),
        )
        assert "score" not in _keys(defs)

    def test_returns_list_of_filter_def(self):
        defs = self._build()
        assert isinstance(defs, list)
        assert all(isinstance(d, FilterDef) for d in defs)


class TestJsonColumnBinding:
    def test_defaults(self):
        js = JsonColumnBinding(column="extensions", document={})
        assert js.alias is None
        assert js.typed_ref_map == {}
        assert js.skip_properties == frozenset()

    def test_column_required(self):
        with pytest.raises(ValidationError):
            JsonColumnBinding(document={})  # type: ignore[call-arg]

    def test_document_required(self):
        with pytest.raises(ValidationError):
            JsonColumnBinding(column="extensions")  # type: ignore[call-arg]

    def test_effective_alias_returns_alias_when_set(self):
        js = JsonColumnBinding(column="extensions", document={}, alias="$")
        assert js.effective_alias == "$"

    def test_effective_alias_falls_back_to_column(self):
        js = JsonColumnBinding(column="extensions", document={})
        assert js.effective_alias == "extensions"

    def test_custom_values(self):
        js = JsonColumnBinding(
            column="content",
            document={"type": "object"},
            alias="c",
            typed_ref_map={"https://types.example.com/quantity": "quantity"},
            skip_properties=frozenset({"_extensions"}),
        )
        assert js.alias == "c"
        assert js.effective_alias == "c"
        assert js.typed_ref_map == {"https://types.example.com/quantity": "quantity"}
        assert js.skip_properties == frozenset({"_extensions"})


class TestEdgeCases:
    def test_model_without_table_raises(self):
        with pytest.raises(TypeError, match="__table__"):
            filter_defs_from_db_model(NotATableModel)

    def test_minimal_model_returns_uuid_field(self):
        defs = filter_defs_from_db_model(MinimalModel, skip_fields=frozenset())
        assert "id" in _keys(defs)
        assert _by_key(defs, "id").operators == [FilterOperator.EQ]

    def test_returns_list_of_filter_def(self):
        defs = filter_defs_from_db_model(PatientRecord)
        assert isinstance(defs, list)
        assert all(isinstance(d, FilterDef) for d in defs)
