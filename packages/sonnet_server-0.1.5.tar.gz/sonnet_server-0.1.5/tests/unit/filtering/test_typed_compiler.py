"""Tests for typed value compilation via dependency injection.

These tests demonstrate how a domain layer would:
1. Define value parser functions for its data types
2. Build a typed_compilers dict mapping type names to compiler functions
3. Declare FilterDefs that reference the type names
4. Pass the compilers dict to compile_filter() for full isolation

The framework knows nothing about "quantity" or "coding" -- all type
knowledge lives in the compiler functions provided by the caller.
"""

from typing import Any

import pytest
import sqlalchemy as sa
from sqlmodel import Field, SQLModel

from sonnet_server.database.filtering.compiler import (
    TypedValueCompilerFn,
    build_json_containment,
    compile_filter,
    navigate_json,
)
from sonnet_server.utils.filtering import (
    FilterAnd,
    FilterDef,
    FilterOperator,
    FilterTerm,
)
from sonnet_server.utils.filtering.value_parsers import parse_coding, parse_quantity

# ---------------------------------------------------------------------------
# Mock model: envelope + JSONB content
# ---------------------------------------------------------------------------


class MockRecord(SQLModel, table=True):
    """Generic envelope + JSONB content model for typed compiler tests."""

    __tablename__ = "mock_records"

    id: str = Field(primary_key=True)
    record_owner: str = Field(nullable=False)
    record_type: str = Field(nullable=False)
    status: str = Field(nullable=False)
    content: dict = Field(sa_column=sa.Column(sa.JSON, nullable=False))


# ---------------------------------------------------------------------------
# Domain-specific typed value compilers (what a domain layer would implement)
# ---------------------------------------------------------------------------


def compile_quantity(column: Any, fdef: FilterDef, op: str, raw_value: str) -> sa.ColumnElement:
    """Compile a quantity filter: ``38.0[Cel]`` → numeric comparison + optional unit check."""
    if not fdef.json_path:
        raise ValueError(f"Typed quantity filter '{fdef.key}' requires json_path")

    parsed = parse_quantity(raw_value)
    obj = navigate_json(column, fdef.json_path)

    val_text = obj.op("->>")("value")
    val_numeric = sa.cast(val_text, sa.Numeric)
    numeric_literal = sa.cast(sa.literal(parsed.value), sa.Numeric)

    comparison_ops = {
        FilterOperator.EQ: val_numeric == numeric_literal,
        FilterOperator.GT: val_numeric > numeric_literal,
        FilterOperator.GTE: val_numeric >= numeric_literal,
        FilterOperator.LT: val_numeric < numeric_literal,
        FilterOperator.LTE: val_numeric <= numeric_literal,
    }
    if op not in comparison_ops:
        raise ValueError(f"Operator '{op}' not supported for quantity filter '{fdef.key}'")

    clauses = [comparison_ops[op]]
    if parsed.unit:
        clauses.append(obj.op("->>")("code") == parsed.unit)

    return sa.and_(*clauses) if len(clauses) > 1 else clauses[0]


def compile_coding(column: Any, fdef: FilterDef, _op: str, raw_value: str) -> sa.ColumnElement:
    """Compile a coding filter: ``system|code`` → JSONB containment."""
    if not fdef.json_path:
        raise ValueError(f"Typed coding filter '{fdef.key}' requires json_path")

    parsed = parse_coding(raw_value)

    target: dict[str, str] = {"code": parsed.code}
    if parsed.system:
        target["system"] = parsed.system

    containment: dict | list = [target] if fdef.json_is_array else target
    return build_json_containment(column, fdef.json_path, containment)


# ---------------------------------------------------------------------------
# Typed compiler registry -- local dict, no global state mutation
# ---------------------------------------------------------------------------

TEST_TYPED_COMPILERS: dict[str, TypedValueCompilerFn] = {
    "quantity": compile_quantity,
    "coding": compile_coding,
    "codeable_concept": compile_coding,
}


# ---------------------------------------------------------------------------
# FilterDef examples: how a domain layer would declare filterable fields
# ---------------------------------------------------------------------------

ENVELOPE_FILTERS = [
    FilterDef(key="record_owner", operators=[FilterOperator.EQ], required=True),
    FilterDef(key="record_type", operators=[FilterOperator.EQ, FilterOperator.IN]),
    FilterDef(key="status", operators=[FilterOperator.EQ]),
]

SENSOR_READING_FILTERS = [
    FilterDef(
        key="content.temperature",
        column="content",
        operators=[FilterOperator.EQ, FilterOperator.GT, FilterOperator.GTE, FilterOperator.LT, FilterOperator.LTE],
        json_path=["temperature"],
        json_value_type="quantity",
    ),
    FilterDef(
        key="content.location",
        column="content",
        operators=[FilterOperator.EQ, FilterOperator.JSON_CONTAINS],
        json_path=["location"],
        json_value_type="coding",
    ),
]

TAGGED_ITEM_FILTERS = [
    FilterDef(
        key="content.code",
        column="content",
        operators=[FilterOperator.EQ, FilterOperator.JSON_CONTAINS],
        json_path=["code", "tags"],
        json_is_array=True,
        json_value_type="codeable_concept",
    ),
]

DUAL_MEASUREMENT_FILTERS = [
    FilterDef(
        key="content.pressure_high",
        column="content",
        operators=[FilterOperator.EQ, FilterOperator.GT, FilterOperator.GTE, FilterOperator.LT, FilterOperator.LTE],
        json_path=["pressure_high"],
        json_value_type="quantity",
    ),
    FilterDef(
        key="content.pressure_low",
        column="content",
        operators=[FilterOperator.EQ, FilterOperator.GT, FilterOperator.GTE, FilterOperator.LT, FilterOperator.LTE],
        json_path=["pressure_low"],
        json_value_type="quantity",
    ),
]


_SENTINEL = object()


def _compile(expr, filters, compilers=_SENTINEL):
    """Compile with test compilers by default."""
    resolved = TEST_TYPED_COMPILERS if compilers is _SENTINEL else compilers
    return compile_filter(expr, MockRecord, filters, typed_compilers=resolved)


def _sql(clause: sa.ColumnElement) -> str:
    return str(clause.compile(compile_kwargs={"literal_binds": True}))


# ---------------------------------------------------------------------------
# Quantity tests
# ---------------------------------------------------------------------------


class TestTypedQuantity:
    ALL_FILTERS = ENVELOPE_FILTERS + SENSOR_READING_FILTERS

    def test_gte_with_unit(self):
        """38.0[Cel] → numeric >= AND unit = 'Cel'."""
        expr = FilterTerm(field="content.temperature", op="gte", value="38.0[Cel]")
        sql = _sql(_compile(expr, self.ALL_FILTERS))
        assert ">=" in sql
        assert "38.0" in sql
        assert "Cel" in sql

    def test_gt_without_unit(self):
        """38.0 → numeric > only, no unit constraint."""
        expr = FilterTerm(field="content.temperature", op="gt", value="38.0")
        sql = _sql(_compile(expr, self.ALL_FILTERS))
        assert ">" in sql
        assert "38.0" in sql
        assert "Cel" not in sql

    def test_lt(self):
        expr = FilterTerm(field="content.temperature", op="lt", value="36.0[Cel]")
        sql = _sql(_compile(expr, self.ALL_FILTERS))
        assert "<" in sql
        assert "36.0" in sql
        assert "Cel" in sql

    def test_eq(self):
        expr = FilterTerm(field="content.temperature", op="eq", value="37.0[Cel]")
        sql = _sql(_compile(expr, self.ALL_FILTERS))
        assert "37.0" in sql
        assert "Cel" in sql

    def test_unsupported_operator_raises(self):
        expr = FilterTerm(field="content.temperature", op="like", value="38")
        with pytest.raises(ValueError, match="not allowed"):
            _compile(expr, self.ALL_FILTERS)


class TestTypedQuantityDualMeasurement:
    ALL_FILTERS = ENVELOPE_FILTERS + DUAL_MEASUREMENT_FILTERS

    def test_high_and_low_combined(self):
        """pressure_high >= 140[psi] AND pressure_low >= 90[psi]."""
        expr = FilterAnd(
            children=[
                FilterTerm(field="content.pressure_high", op="gte", value="140[psi]"),
                FilterTerm(field="content.pressure_low", op="gte", value="90[psi]"),
            ]
        )
        sql = _sql(_compile(expr, self.ALL_FILTERS))
        assert "AND" in sql
        assert "140" in sql
        assert "90" in sql
        assert "psi" in sql


# ---------------------------------------------------------------------------
# Coding tests
# ---------------------------------------------------------------------------


class TestTypedCoding:
    ALL_FILTERS = ENVELOPE_FILTERS + SENSOR_READING_FILTERS

    def test_system_and_code(self):
        expr = FilterTerm(field="content.location", op="eq", value="http://systems.example.com/regions|EU-WEST")
        sql = _sql(_compile(expr, self.ALL_FILTERS))
        assert "@>" in sql
        assert "EU-WEST" in sql
        assert "regions" in sql

    def test_code_only(self):
        expr = FilterTerm(field="content.location", op="eq", value="EU-WEST")
        sql = _sql(_compile(expr, self.ALL_FILTERS))
        assert "@>" in sql
        assert "EU-WEST" in sql

    def test_short_alias_passthrough(self):
        """Alias resolution is the domain's job -- framework passes through."""
        expr = FilterTerm(field="content.location", op="eq", value="regions|EU-WEST")
        sql = _sql(_compile(expr, self.ALL_FILTERS))
        assert "@>" in sql
        assert "regions" in sql
        assert "EU-WEST" in sql


# ---------------------------------------------------------------------------
# CodeableConcept tests
# ---------------------------------------------------------------------------


class TestTypedCodeableConcept:
    ALL_FILTERS = ENVELOPE_FILTERS + TAGGED_ITEM_FILTERS

    def test_system_and_code_in_array(self):
        expr = FilterTerm(
            field="content.code",
            op="eq",
            value="http://taxonomies.example.com/categories|CAT-42",
        )
        sql = _sql(_compile(expr, self.ALL_FILTERS))
        assert "@>" in sql
        assert "CAT-42" in sql
        assert "categories" in sql

    def test_code_only_in_array(self):
        expr = FilterTerm(field="content.code", op="eq", value="CAT-42")
        sql = _sql(_compile(expr, self.ALL_FILTERS))
        assert "@>" in sql
        assert "CAT-42" in sql


# ---------------------------------------------------------------------------
# Registry tests
# ---------------------------------------------------------------------------


class TestTypedValueCompilers:
    """Tests that the typed_compilers DI mechanism works correctly."""

    def test_unregistered_type_raises(self):
        """Using a json_value_type with no matching compiler raises."""
        defs = [
            FilterDef(
                key="content.x",
                column="content",
                operators=[FilterOperator.EQ],
                json_path=["x"],
                json_value_type="unknown_type",
            ),
        ]
        expr = FilterTerm(field="content.x", op="eq", value="42")
        with pytest.raises(ValueError, match="No typed value compiler registered for 'unknown_type'"):
            _compile(expr, defs)

    def test_empty_compilers_dict_raises(self):
        """An empty compilers dict means no types are known."""
        expr = FilterTerm(field="content.temperature", op="gte", value="38.0[Cel]")
        with pytest.raises(ValueError, match="No typed value compiler registered for 'quantity'"):
            _compile(expr, ENVELOPE_FILTERS + SENSOR_READING_FILTERS, compilers={})

    def test_custom_type_via_local_dict(self):
        """Domain code can pass arbitrary types via typed_compilers."""

        def compile_custom(_column: Any, _fdef: FilterDef, _op: str, raw_value: str) -> sa.ColumnElement:
            return sa.literal(raw_value == "magic").self_group()

        defs = [
            FilterDef(
                key="content.magic",
                column="content",
                operators=[FilterOperator.EQ],
                json_path=["magic"],
                json_value_type="custom_magic",
            ),
        ]
        expr = FilterTerm(field="content.magic", op="eq", value="magic")
        clause = _compile(expr, defs, compilers={"custom_magic": compile_custom})
        assert clause is not None


# ---------------------------------------------------------------------------
# Combined: envelope + content filters (the full mixed query pattern)
# ---------------------------------------------------------------------------


class TestCombinedEnvelopeAndContent:
    """Full query: envelope + typed content filters in one expression."""

    ALL_FILTERS = ENVELOPE_FILTERS + SENSOR_READING_FILTERS

    def test_full_mixed_query(self):
        """owner + type + status + temperature >= 38.0[Cel] + location = EU-WEST."""
        expr = FilterAnd(
            children=[
                FilterTerm(field="record_owner", op="eq", value="owner_01JK"),
                FilterTerm(field="record_type", op="eq", value="sensor/temperature"),
                FilterTerm(field="status", op="eq", value="valid"),
                FilterTerm(field="content.temperature", op="gte", value="38.0[Cel]"),
                FilterTerm(field="content.location", op="eq", value="http://systems.example.com/regions|EU-WEST"),
            ]
        )
        sql = _sql(_compile(expr, self.ALL_FILTERS))

        assert "record_owner" in sql
        assert "owner_01JK" in sql
        assert "record_type" in sql
        assert "sensor/temperature" in sql
        assert "38.0" in sql
        assert "Cel" in sql
        assert "@>" in sql
        assert "EU-WEST" in sql
        assert sql.count("AND") >= 4

    def test_cross_content_type_query(self):
        all_filters = ENVELOPE_FILTERS + TAGGED_ITEM_FILTERS
        expr = FilterAnd(
            children=[
                FilterTerm(field="record_owner", op="eq", value="owner_01JK"),
                FilterTerm(field="record_type", op="in", value="inventory/widget,inventory/gadget"),
                FilterTerm(field="status", op="eq", value="valid"),
                FilterTerm(field="content.code", op="eq", value="http://taxonomies.example.com/categories|CAT-99"),
            ]
        )
        sql = _sql(_compile(expr, all_filters))
        assert "IN" in sql
        assert "widget" in sql
        assert "gadget" in sql
        assert "@>" in sql
        assert "CAT-99" in sql
