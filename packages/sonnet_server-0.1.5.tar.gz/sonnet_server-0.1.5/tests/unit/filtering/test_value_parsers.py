"""Tests for typed value parsers (quantity, coding)."""

import pytest

from sonnet_server.utils.filtering.value_parsers import (
    ParsedCoding,
    ParsedQuantity,
    parse_coding,
    parse_quantity,
)


class TestParseQuantity:
    """Parse compact quantity syntax: value[unit]."""

    def test_plain_number(self):
        assert parse_quantity("38.0") == ParsedQuantity(value="38.0", unit=None)

    def test_integer(self):
        assert parse_quantity("120") == ParsedQuantity(value="120", unit=None)

    def test_with_unit(self):
        assert parse_quantity("38.0[Cel]") == ParsedQuantity(value="38.0", unit="Cel")

    def test_with_unit_mmhg(self):
        assert parse_quantity("120[mm[Hg]]") == ParsedQuantity(value="120", unit="mm[Hg]")

    def test_with_unit_kg(self):
        assert parse_quantity("75.5[kg]") == ParsedQuantity(value="75.5", unit="kg")

    def test_negative_value(self):
        assert parse_quantity("-2.5[Cel]") == ParsedQuantity(value="-2.5", unit="Cel")

    def test_strips_whitespace(self):
        assert parse_quantity("  38.0[Cel]  ") == ParsedQuantity(value="38.0", unit="Cel")

    def test_empty_raises(self):
        with pytest.raises(ValueError, match="must not be empty"):
            parse_quantity("")

    def test_whitespace_only_raises(self):
        with pytest.raises(ValueError, match="must not be empty"):
            parse_quantity("   ")

    def test_unclosed_bracket_raises(self):
        with pytest.raises(ValueError, match="unclosed bracket"):
            parse_quantity("38.0[Cel")

    def test_no_numeric_part_raises(self):
        with pytest.raises(ValueError, match="no numeric part"):
            parse_quantity("[Cel]")


class TestParseCoding:
    """Parse compact coding syntax: system|code."""

    def test_plain_code(self):
        assert parse_coding("ABC123") == ParsedCoding(system=None, code="ABC123")

    def test_system_and_code(self):
        result = parse_coding("http://systems.example.com/colors|ABC123")
        assert result == ParsedCoding(system="http://systems.example.com/colors", code="ABC123")

    def test_short_alias(self):
        result = parse_coding("colors|ABC123")
        assert result == ParsedCoding(system="colors", code="ABC123")

    def test_code_with_dot(self):
        result = parse_coding("categories|X06.9")
        assert result == ParsedCoding(system="categories", code="X06.9")

    def test_strips_whitespace(self):
        result = parse_coding("  colors | ABC123  ")
        assert result == ParsedCoding(system="colors", code="ABC123")

    def test_empty_system_treated_as_none(self):
        result = parse_coding("|ABC123")
        assert result == ParsedCoding(system=None, code="ABC123")

    def test_empty_raises(self):
        with pytest.raises(ValueError, match="must not be empty"):
            parse_coding("")

    def test_empty_code_after_pipe_raises(self):
        with pytest.raises(ValueError, match="no code after"):
            parse_coding("colors|")

    def test_empty_code_after_pipe_whitespace_raises(self):
        with pytest.raises(ValueError, match="no code after"):
            parse_coding("colors|   ")
