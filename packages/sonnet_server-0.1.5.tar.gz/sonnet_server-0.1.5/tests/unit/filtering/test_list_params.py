"""Tests for missing_required_filters and q param integration."""

from sonnet_server.utils.filtering import (
    FilterDef,
    FilterOperator,
    collect_fields,
    missing_required_filters,
    parse_query,
)

FILTERS = [
    FilterDef(key="org_id", column="org_id", operators=[FilterOperator.EQ], required=True),
    FilterDef(key="action", column="action", operators=[FilterOperator.PREFIX, FilterOperator.EQ]),
    FilterDef(key="outcome", column="outcome", operators=[FilterOperator.EQ]),
]


class TestMissingRequiredFilters:
    """Tests for missing_required_filters()."""

    def test_all_required_present_returns_empty(self):
        missing = missing_required_filters(FILTERS, {"org_id"})
        assert missing == []

    def test_required_missing_returns_key(self):
        missing = missing_required_filters(FILTERS, set())
        assert missing == ["org_id"]

    def test_optional_missing_is_not_reported(self):
        missing = missing_required_filters(FILTERS, {"org_id"})
        assert "action" not in missing
        assert "outcome" not in missing

    def test_multiple_required_all_missing_reports_all(self):
        filters = [
            FilterDef(key="org_id", column="org_id", operators=[FilterOperator.EQ], required=True),
            FilterDef(key="action", column="action", operators=[FilterOperator.EQ], required=True),
        ]
        missing = missing_required_filters(filters, set())
        assert "org_id" in missing
        assert "action" in missing

    def test_multiple_required_one_present_reports_missing_only(self):
        filters = [
            FilterDef(key="org_id", column="org_id", operators=[FilterOperator.EQ], required=True),
            FilterDef(key="action", column="action", operators=[FilterOperator.EQ], required=True),
        ]
        missing = missing_required_filters(filters, {"org_id"})
        assert missing == ["action"]

    def test_no_required_filters_always_empty(self):
        filters = [
            FilterDef(key="action", column="action", operators=[FilterOperator.EQ]),
            FilterDef(key="outcome", column="outcome", operators=[FilterOperator.EQ]),
        ]
        missing = missing_required_filters(filters, set())
        assert missing == []


class TestRequiredWithQExpression:
    """Tests for required filter enforcement when q param provides fields.

    Simulates the dependency logic: flat param keys + collect_fields(q_expr)
    are combined into present_keys before checking required filters.
    """

    def test_required_satisfied_by_q_expression(self):
        q_expr = parse_query('org_id = "org_1" AND action ~ "user."')
        present_keys = collect_fields(q_expr)
        missing = missing_required_filters(FILTERS, present_keys)
        assert missing == []

    def test_required_missing_from_q_expression(self):
        q_expr = parse_query('action ~ "user."')
        present_keys = collect_fields(q_expr)
        missing = missing_required_filters(FILTERS, present_keys)
        assert missing == ["org_id"]

    def test_required_from_flat_params_and_q_combined(self):
        flat_keys = {"org_id"}
        q_expr = parse_query('outcome = "failure" OR outcome = "error"')
        present_keys = flat_keys | collect_fields(q_expr)
        missing = missing_required_filters(FILTERS, present_keys)
        assert missing == []

    def test_required_from_nested_not(self):
        q_expr = parse_query('org_id = "org_1" AND NOT outcome = "success"')
        present_keys = collect_fields(q_expr)
        missing = missing_required_filters(FILTERS, present_keys)
        assert missing == []
