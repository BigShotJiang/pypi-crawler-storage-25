"""Tests for the query string parser (parse_query)."""

import pytest

from sonnet_server.utils.filtering import (
    FilterAnd,
    FilterGroup,
    FilterNot,
    FilterOr,
    FilterTerm,
    parse_query,
)
from sonnet_server.utils.filtering.filter_defs import FilterOperator


class TestSingleTerm:
    def test_eq_quoted(self):
        expr = parse_query('org_id = "org_1"')
        assert isinstance(expr, FilterTerm)
        assert expr.field == "org_id"
        assert expr.op == FilterOperator.EQ
        assert expr.value == "org_1"

    def test_eq_unquoted(self):
        expr = parse_query("outcome = success")
        assert isinstance(expr, FilterTerm)
        assert expr.value == "success"

    def test_neq(self):
        expr = parse_query('outcome != "success"')
        assert isinstance(expr, FilterTerm)
        assert expr.op == FilterOperator.NEQ

    def test_like(self):
        expr = parse_query('name ~ "acme"')
        assert isinstance(expr, FilterTerm)
        assert expr.op == FilterOperator.LIKE
        assert expr.value == "acme"

    def test_prefix(self):
        expr = parse_query('action ^ "user."')
        assert isinstance(expr, FilterTerm)
        assert expr.op == FilterOperator.PREFIX
        assert expr.value == "user."

    def test_gte(self):
        expr = parse_query('occurred_at >= "2026-01-01T00:00:00Z"')
        assert isinstance(expr, FilterTerm)
        assert expr.op == FilterOperator.GTE

    def test_lte(self):
        expr = parse_query('occurred_at <= "2026-12-31T00:00:00Z"')
        assert isinstance(expr, FilterTerm)
        assert expr.op == FilterOperator.LTE

    def test_gt(self):
        expr = parse_query("count > 5")
        assert isinstance(expr, FilterTerm)
        assert expr.op == FilterOperator.GT

    def test_lt(self):
        expr = parse_query("count < 10")
        assert isinstance(expr, FilterTerm)
        assert expr.op == FilterOperator.LT


class TestAndCombination:
    def test_two_terms(self):
        expr = parse_query('org_id = "org_1" AND outcome = "failure"')
        assert isinstance(expr, FilterAnd)
        assert len(expr.children) == 2
        assert expr.children[0].field == "org_id"
        assert expr.children[1].field == "outcome"

    def test_three_terms_flattened(self):
        expr = parse_query('org_id = "org_1" AND outcome = "failure" AND action = "x"')
        assert isinstance(expr, FilterAnd)
        assert len(expr.children) == 3

    def test_case_insensitive_and(self):
        expr = parse_query('org_id = "org_1" and outcome = "failure"')
        assert isinstance(expr, FilterAnd)


class TestOrCombination:
    def test_two_terms(self):
        expr = parse_query('outcome = "failure" OR outcome = "error"')
        assert isinstance(expr, FilterOr)
        assert len(expr.children) == 2

    def test_three_terms_flattened(self):
        expr = parse_query('outcome = "a" OR outcome = "b" OR outcome = "c"')
        assert isinstance(expr, FilterOr)
        assert len(expr.children) == 3

    def test_case_insensitive_or(self):
        expr = parse_query('outcome = "failure" or outcome = "error"')
        assert isinstance(expr, FilterOr)


class TestNot:
    def test_not_term(self):
        expr = parse_query('NOT outcome = "success"')
        assert isinstance(expr, FilterNot)
        assert isinstance(expr.child, FilterTerm)

    def test_case_insensitive_not(self):
        expr = parse_query('not outcome = "success"')
        assert isinstance(expr, FilterNot)


class TestPrecedence:
    def test_not_binds_tighter_than_and(self):
        # NOT outcome = "success" AND org_id = "x"
        # should parse as (NOT outcome = "success") AND org_id = "x"
        expr = parse_query('NOT outcome = "success" AND org_id = "org_1"')
        assert isinstance(expr, FilterAnd)
        assert isinstance(expr.children[0], FilterNot)
        assert isinstance(expr.children[1], FilterTerm)

    def test_and_binds_tighter_than_or(self):
        # a AND b OR c should parse as (a AND b) OR c
        expr = parse_query('org_id = "x" AND action = "y" OR outcome = "z"')
        assert isinstance(expr, FilterOr)
        assert isinstance(expr.children[0], FilterAnd)
        assert isinstance(expr.children[1], FilterTerm)


class TestGrouping:
    def test_group_changes_precedence(self):
        # org_id AND (outcome OR outcome) -- group forces OR first
        expr = parse_query('org_id = "org_1" AND (outcome = "failure" OR outcome = "error")')
        assert isinstance(expr, FilterAnd)
        assert len(expr.children) == 2
        assert isinstance(expr.children[1], FilterGroup)
        assert isinstance(expr.children[1].child, FilterOr)

    def test_nested_groups(self):
        expr = parse_query('(org_id = "org_1" AND action = "x") OR outcome = "failure"')
        assert isinstance(expr, FilterOr)
        assert isinstance(expr.children[0], FilterGroup)
        assert isinstance(expr.children[0].child, FilterAnd)


class TestErrors:
    def test_empty_string_raises(self):
        with pytest.raises(ValueError, match="Invalid query expression"):
            parse_query("")

    def test_missing_value_raises(self):
        with pytest.raises(ValueError, match="Invalid query expression"):
            parse_query("org_id =")

    def test_unknown_operator_raises(self):
        with pytest.raises(ValueError, match="Invalid query expression"):
            parse_query("org_id ?? org_1")

    def test_old_tilde_prefix_no_longer_means_prefix(self):
        # ~ now maps to LIKE (contains), not PREFIX.
        expr = parse_query('action ~ "user."')
        assert expr.op == FilterOperator.LIKE

    def test_caret_prefix(self):
        # ^ is the grammar symbol for PREFIX (starts-with).
        expr = parse_query('action ^ "user."')
        assert expr.op == FilterOperator.PREFIX
