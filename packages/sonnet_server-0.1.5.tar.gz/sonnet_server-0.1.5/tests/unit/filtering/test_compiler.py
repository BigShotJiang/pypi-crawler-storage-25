"""Tests for the SQLAlchemy filter compiler."""

from datetime import datetime
from uuid import UUID

import pytest
import sqlalchemy as sa
from sqlmodel import Field, SQLModel

from sonnet_server.database.filtering.compiler import compile_filter
from sonnet_server.utils.filtering import (
    FilterAnd,
    FilterDef,
    FilterGroup,
    FilterNot,
    FilterOperator,
    FilterOr,
    FilterTerm,
)


# Test DB model
class MockEvent(SQLModel, table=True):
    __tablename__ = "mock_events"

    id: str = Field(primary_key=True)
    org_id: str = Field(nullable=False)
    action: str = Field(nullable=False)
    outcome: str = Field(nullable=False)
    parent_id: UUID | None = Field(default=None, nullable=True)
    occurred_at: datetime = Field(
        sa_column=sa.Column(sa.DateTime(timezone=True), nullable=False),
    )
    actors: list = Field(sa_column=sa.Column(sa.JSON, nullable=False))
    source: dict = Field(sa_column=sa.Column(sa.JSON, nullable=False))


# Standard filter defs for testing
TEST_FILTERS = [
    FilterDef(key="org_id", column="org_id", operators=[FilterOperator.EQ]),
    FilterDef(key="action", column="action", operators=[FilterOperator.EQ, FilterOperator.PREFIX]),
    FilterDef(key="outcome", operators=[FilterOperator.EQ, FilterOperator.NEQ, FilterOperator.IN]),
    FilterDef(
        key="occurred_after",
        column="occurred_at",
        operators=[FilterOperator.GTE],
    ),
    FilterDef(
        key="occurred_before",
        column="occurred_at",
        operators=[FilterOperator.LT],
    ),
    FilterDef(
        key="actor_id",
        column="actors",
        operators=[FilterOperator.JSON_CONTAINS],
        json_path=["id"],
        json_is_array=True,
    ),
    FilterDef(
        key="source_id",
        column="source",
        operators=[FilterOperator.JSON_CONTAINS],
        json_path=["id"],
        json_is_array=False,
    ),
    FilterDef(key="parent_id", operators=[FilterOperator.EQ, FilterOperator.IS_NULL]),
]


def _compile_str(clause: sa.ColumnElement) -> str:
    """Render a clause to string for assertion (dialect-independent)."""
    return str(clause.compile(compile_kwargs={"literal_binds": True}))


class TestEmptyExpressions:
    """Tests for empty / trivial expressions."""

    def test_empty_and_returns_true(self):
        clause = compile_filter(FilterAnd(children=[]), MockEvent, TEST_FILTERS)
        assert str(clause) == "true"

    def test_empty_or_returns_false(self):
        clause = compile_filter(FilterOr(children=[]), MockEvent, TEST_FILTERS)
        assert str(clause) == "false"


class TestScalarOperators:
    """Tests for scalar (non-JSON) filter operations."""

    def test_eq(self):
        expr = FilterTerm(field="org_id", op="eq", value="org_1")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert "org_id" in compiled
        assert "'org_1'" in compiled

    def test_prefix(self):
        expr = FilterTerm(field="action", op="prefix", value="user.")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert "LIKE" in compiled
        assert "'user.%'" in compiled

    def test_neq(self):
        expr = FilterTerm(field="outcome", op="neq", value="success")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert "!=" in compiled or "<>" in compiled

    def test_gte(self):
        expr = FilterTerm(field="occurred_after", op="gte", value="2026-02-21T00:00:00Z")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert ">=" in compiled

    def test_lt(self):
        expr = FilterTerm(field="occurred_before", op="lt", value="2026-02-22T00:00:00Z")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert "<" in compiled

    def test_in_operator(self):
        expr = FilterTerm(field="outcome", op="in", value="failure,error")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert "IN" in compiled
        assert "'failure'" in compiled
        assert "'error'" in compiled

    def test_in_operator_strips_whitespace(self):
        expr = FilterTerm(field="outcome", op="in", value=" failure , error ")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert "'failure'" in compiled
        assert "'error'" in compiled
        # Whitespace should not appear inside the values
        assert "' failure'" not in compiled
        assert "'error '" not in compiled

    def test_in_operator_empty_raises(self):
        expr = FilterTerm(field="outcome", op="in", value="  ")
        with pytest.raises(ValueError, match="IN filter requires at least one value"):
            compile_filter(expr, MockEvent, TEST_FILTERS)

    def test_in_operator_over_limit_raises(self):
        value = ",".join(str(i) for i in range(101))
        expr = FilterTerm(field="outcome", op="in", value=value)
        with pytest.raises(ValueError, match="IN filter exceeds maximum"):
            compile_filter(expr, MockEvent, TEST_FILTERS)

    def test_like_operator(self):
        like_filters = [
            FilterDef(key="outcome", operators=[FilterOperator.LIKE]),
        ]
        expr = FilterTerm(field="outcome", op="like", value="fail")
        clause = compile_filter(expr, MockEvent, like_filters)
        compiled = _compile_str(clause)
        assert "LIKE" in compiled.upper()
        assert "%fail%" in compiled


class TestJsonContains:
    """Tests for JSON containment operations."""

    def test_json_contains_array_column(self):
        expr = FilterTerm(field="actor_id", op="json_contains", value="user_1")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        # Should produce: actors::JSONB @> '[{"id": "user_1"}]'::jsonb
        assert "@>" in compiled
        assert "user_1" in compiled

    def test_json_contains_object_column(self):
        expr = FilterTerm(field="source_id", op="json_contains", value="auth-svc")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        # Should produce: source::JSONB @> '{"id": "auth-svc"}'::jsonb
        assert "@>" in compiled
        assert "auth-svc" in compiled


class TestBooleanComposition:
    """Tests for AND, OR, NOT, GROUP composition."""

    def test_and_of_terms(self):
        expr = FilterAnd(
            children=[
                FilterTerm(field="org_id", op="eq", value="org_1"),
                FilterTerm(field="outcome", op="eq", value="failure"),
            ]
        )
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert "AND" in compiled

    def test_or_of_terms(self):
        expr = FilterOr(
            children=[
                FilterTerm(field="outcome", op="eq", value="failure"),
                FilterTerm(field="outcome", op="eq", value="error"),
            ]
        )
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert "OR" in compiled

    def test_not(self):
        expr = FilterNot(child=FilterTerm(field="outcome", op="eq", value="success"))
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        # SA may optimize NOT (x = y) to x != y
        assert "NOT" in compiled or "!=" in compiled or "<>" in compiled

    def test_group_is_transparent(self):
        inner = FilterTerm(field="org_id", op="eq", value="org_1")
        grouped = FilterGroup(child=inner)
        clause_inner = _compile_str(compile_filter(inner, MockEvent, TEST_FILTERS))
        clause_grouped = _compile_str(compile_filter(grouped, MockEvent, TEST_FILTERS))
        assert clause_inner == clause_grouped

    def test_complex_nested(self):
        """org_id = 'org_1' AND (outcome = 'failure' OR outcome = 'error')"""
        expr = FilterAnd(
            children=[
                FilterTerm(field="org_id", op="eq", value="org_1"),
                FilterGroup(
                    child=FilterOr(
                        children=[
                            FilterTerm(field="outcome", op="eq", value="failure"),
                            FilterTerm(field="outcome", op="eq", value="error"),
                        ]
                    )
                ),
            ]
        )
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert "AND" in compiled
        assert "OR" in compiled


class TestValidation:
    """Tests for field and operator validation."""

    def test_unknown_field_raises(self):
        expr = FilterTerm(field="bogus", op="eq", value="x")
        with pytest.raises(ValueError, match="Unknown filter field 'bogus'"):
            compile_filter(expr, MockEvent, TEST_FILTERS)

    def test_disallowed_operator_raises(self):
        # org_id only allows "eq"
        expr = FilterTerm(field="org_id", op="prefix", value="org_")
        with pytest.raises(ValueError, match="Operator 'prefix' not allowed"):
            compile_filter(expr, MockEvent, TEST_FILTERS)

    def test_json_contains_without_path_raises(self):
        bad_defs = [
            FilterDef(key="bad", column="actors", operators=[FilterOperator.JSON_CONTAINS]),
        ]
        expr = FilterTerm(field="bad", op="json_contains", value="x")
        with pytest.raises(ValueError, match="json_contains requires json_path"):
            compile_filter(expr, MockEvent, bad_defs)


class TestEqPromotion:
    """Tests for auto-promotion of EQ to the field's default operator.

    Query expressions use `=` for equality, which maps to FilterOperator.EQ.
    When a field only allows JSON_CONTAINS (or another non-EQ default),
    the compiler should auto-promote EQ to the field's default operator
    so that `actor_id = user_alice` works the same way as `?actor_id=user_alice`.
    """

    def test_eq_promoted_to_json_contains_for_array(self):
        expr = FilterTerm(field="actor_id", op="eq", value="user_1")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert "@>" in compiled
        assert "user_1" in compiled

    def test_eq_promoted_to_json_contains_for_object(self):
        expr = FilterTerm(field="source_id", op="eq", value="auth-svc")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert "@>" in compiled
        assert "auth-svc" in compiled

    def test_eq_not_promoted_when_eq_is_allowed(self):
        """EQ should not be promoted when the field explicitly allows it."""
        expr = FilterTerm(field="org_id", op="eq", value="org_1")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        # Should be a plain = comparison, not @>
        assert "@>" not in compiled
        assert "org_1" in compiled

    def test_non_eq_operator_not_promoted(self):
        """Non-EQ operators should never be promoted, even when disallowed."""
        expr = FilterTerm(field="actor_id", op="prefix", value="user_")
        with pytest.raises(ValueError, match="Operator 'prefix' not allowed"):
            compile_filter(expr, MockEvent, TEST_FILTERS)


class TestIsNullOperator:
    """Tests for the IS_NULL operator.

    The IS_NULL operator is used via the __isnull query param suffix
    (e.g. ?parent_id__isnull=true). The compiler produces IS NULL or
    IS NOT NULL depending on the value.
    """

    def test_isnull_true_produces_is_null(self):
        expr = FilterTerm(field="parent_id", op="isnull", value="true")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert "IS NULL" in compiled.upper()
        assert "'true'" not in compiled

    def test_isnull_false_produces_is_not_null(self):
        expr = FilterTerm(field="parent_id", op="isnull", value="false")
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        compiled = _compile_str(clause)
        assert "IS NOT NULL" in compiled.upper()
        assert "'false'" not in compiled

    def test_isnull_true_case_insensitive(self):
        for variant in ("True", "TRUE"):
            expr = FilterTerm(field="parent_id", op="isnull", value=variant)
            clause = compile_filter(expr, MockEvent, TEST_FILTERS)
            compiled = _compile_str(clause)
            assert "IS NULL" in compiled.upper(), f"expected IS NULL for value={variant!r}"

    def test_isnull_false_case_insensitive(self):
        for variant in ("False", "FALSE"):
            expr = FilterTerm(field="parent_id", op="isnull", value=variant)
            clause = compile_filter(expr, MockEvent, TEST_FILTERS)
            compiled = _compile_str(clause)
            assert "IS NOT NULL" in compiled.upper(), f"expected IS NOT NULL for value={variant!r}"

    def test_isnull_invalid_value_raises(self):
        expr = FilterTerm(field="parent_id", op="isnull", value="yes")
        with pytest.raises(ValueError, match="IS_NULL operator requires 'true' or 'false'"):
            compile_filter(expr, MockEvent, TEST_FILTERS)

    def test_eq_on_nullable_field_is_plain_equality(self):
        """EQ on a field with IS_NULL support should still do plain = comparison."""
        test_uuid = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
        expr = FilterTerm(field="parent_id", op="eq", value=test_uuid)
        clause = compile_filter(expr, MockEvent, TEST_FILTERS)
        # Cannot use _compile_str with literal_binds for UUID columns,
        # so verify the clause structure directly.
        compiled = str(clause)
        assert "parent_id" in compiled
        assert "IS NULL" not in compiled.upper()
        assert "IS NOT NULL" not in compiled.upper()

    def test_isnull_not_allowed_raises(self):
        """IS_NULL on a field that does not declare it should raise."""
        expr = FilterTerm(field="org_id", op="isnull", value="true")
        with pytest.raises(ValueError, match="Operator 'isnull' not allowed"):
            compile_filter(expr, MockEvent, TEST_FILTERS)


class TestJsonPathIsNull:
    """Tests for the JSON_PATH_IS_NULL operator.

    Checks whether a path inside a JSONB column is NULL or absent.
    Produces: column -> 'key1' -> 'key2' IS [NOT] NULL.
    """

    JSON_PATH_FILTERS = [
        FilterDef(
            key="parent_ref",
            column="source",
            operators=[FilterOperator.JSON_PATH_IS_NULL],
            json_path=["parent", "reference"],
        ),
        FilterDef(
            key="report_ref",
            column="source",
            operators=[FilterOperator.JSON_PATH_IS_NULL],
            json_path=["relatedReportReference"],
        ),
    ]

    def test_json_path_isnull_true(self):
        expr = FilterTerm(field="parent_ref", op="json_path_isnull", value="true")
        clause = compile_filter(expr, MockEvent, self.JSON_PATH_FILTERS)
        compiled = _compile_str(clause)
        assert "IS NULL" in compiled.upper()
        assert "->" in compiled

    def test_json_path_isnull_false(self):
        expr = FilterTerm(field="parent_ref", op="json_path_isnull", value="false")
        clause = compile_filter(expr, MockEvent, self.JSON_PATH_FILTERS)
        compiled = _compile_str(clause)
        assert "IS NOT NULL" in compiled.upper()
        assert "->" in compiled

    def test_json_path_isnull_case_insensitive(self):
        for variant in ("True", "TRUE"):
            expr = FilterTerm(field="parent_ref", op="json_path_isnull", value=variant)
            clause = compile_filter(expr, MockEvent, self.JSON_PATH_FILTERS)
            compiled = _compile_str(clause)
            assert "IS NULL" in compiled.upper()

    def test_json_path_isnull_invalid_value_raises(self):
        expr = FilterTerm(field="parent_ref", op="json_path_isnull", value="yes")
        with pytest.raises(ValueError, match="JSON_PATH_IS_NULL operator requires 'true' or 'false'"):
            compile_filter(expr, MockEvent, self.JSON_PATH_FILTERS)

    def test_json_path_isnull_without_path_raises(self):
        bad_defs = [
            FilterDef(key="bad", column="source", operators=[FilterOperator.JSON_PATH_IS_NULL]),
        ]
        expr = FilterTerm(field="bad", op="json_path_isnull", value="true")
        with pytest.raises(ValueError, match="json_path_isnull requires json_path"):
            compile_filter(expr, MockEvent, bad_defs)

    def test_single_segment_path(self):
        expr = FilterTerm(field="report_ref", op="json_path_isnull", value="true")
        clause = compile_filter(expr, MockEvent, self.JSON_PATH_FILTERS)
        compiled = _compile_str(clause)
        assert "IS NULL" in compiled.upper()
        assert "->" in compiled

    def test_combined_with_other_filters(self):
        """Combine JSON path null check with scalar filters via AND."""
        all_defs = TEST_FILTERS + self.JSON_PATH_FILTERS
        expr = FilterAnd(
            children=[
                FilterTerm(field="org_id", op="eq", value="org_1"),
                FilterTerm(field="parent_ref", op="json_path_isnull", value="true"),
                FilterTerm(field="report_ref", op="json_path_isnull", value="true"),
            ]
        )
        clause = compile_filter(expr, MockEvent, all_defs)
        compiled = _compile_str(clause)
        assert "AND" in compiled
        assert "IS NULL" in compiled.upper()
