"""Tests for the filter expression AST types."""

from sonnet_server.utils.filtering import (
    EMPTY_FILTER,
    FilterAnd,
    FilterDef,
    FilterGroup,
    FilterNot,
    FilterOperator,
    FilterOr,
    FilterTerm,
    collect_fields,
)


class TestFilterTerm:
    """Tests for FilterTerm leaf nodes."""

    def test_default_operator_is_eq(self):
        term = FilterTerm(field="org_id", value="org_1")
        assert term.op == "eq"

    def test_explicit_operator(self):
        term = FilterTerm(field="action", op="prefix", value="patient.")
        assert term.op == "prefix"

    def test_type_discriminator(self):
        term = FilterTerm(field="org_id", value="org_1")
        assert term.type == "term"


class TestFilterAnd:
    """Tests for AND conjunction."""

    def test_empty_and(self):
        expr = FilterAnd(children=[])
        assert expr.type == "and"
        assert len(expr.children) == 0

    def test_and_with_terms(self):
        expr = FilterAnd(
            children=[
                FilterTerm(field="org_id", value="org_1"),
                FilterTerm(field="action", op="prefix", value="user."),
            ]
        )
        assert len(expr.children) == 2


class TestFilterOr:
    """Tests for OR disjunction."""

    def test_or_with_terms(self):
        expr = FilterOr(
            children=[
                FilterTerm(field="outcome", value="failure"),
                FilterTerm(field="outcome", value="error"),
            ]
        )
        assert expr.type == "or"
        assert len(expr.children) == 2


class TestFilterNot:
    """Tests for NOT negation."""

    def test_not_wraps_term(self):
        expr = FilterNot(child=FilterTerm(field="outcome", value="success"))
        assert expr.type == "not"
        assert expr.child.type == "term"


class TestFilterGroup:
    """Tests for explicit grouping."""

    def test_group_wraps_or(self):
        inner = FilterOr(
            children=[
                FilterTerm(field="outcome", value="failure"),
                FilterTerm(field="outcome", value="error"),
            ]
        )
        expr = FilterGroup(child=inner)
        assert expr.type == "group"
        assert expr.child.type == "or"


class TestNestedExpressions:
    """Tests for complex nested expression trees."""

    def test_and_of_or(self):
        """org_id = 'org_1' AND (outcome = 'failure' OR outcome = 'error')"""
        expr = FilterAnd(
            children=[
                FilterTerm(field="org_id", value="org_1"),
                FilterGroup(
                    child=FilterOr(
                        children=[
                            FilterTerm(field="outcome", value="failure"),
                            FilterTerm(field="outcome", value="error"),
                        ]
                    )
                ),
            ]
        )
        assert expr.type == "and"
        assert len(expr.children) == 2
        assert expr.children[1].type == "group"

    def test_not_inside_and(self):
        """org_id = 'org_1' AND NOT outcome = 'success'"""
        expr = FilterAnd(
            children=[
                FilterTerm(field="org_id", value="org_1"),
                FilterNot(child=FilterTerm(field="outcome", value="success")),
            ]
        )
        assert len(expr.children) == 2
        assert expr.children[1].type == "not"


class TestEmptyFilter:
    """Tests for the EMPTY_FILTER sentinel."""

    def test_empty_filter_is_and(self):
        assert EMPTY_FILTER.type == "and"

    def test_empty_filter_has_no_children(self):
        assert len(EMPTY_FILTER.children) == 0


class TestCollectFields:
    """Tests for collect_fields()."""

    def test_single_term(self):
        expr = FilterTerm(field="org_id", op="eq", value="x")
        assert collect_fields(expr) == {"org_id"}

    def test_and_with_multiple_terms(self):
        expr = FilterAnd(
            children=[
                FilterTerm(field="org_id", value="x"),
                FilterTerm(field="action", value="y"),
            ]
        )
        assert collect_fields(expr) == {"org_id", "action"}

    def test_nested_or_and_not(self):
        expr = FilterAnd(
            children=[
                FilterTerm(field="org_id", value="x"),
                FilterOr(
                    children=[
                        FilterTerm(field="outcome", value="a"),
                        FilterNot(child=FilterTerm(field="action", value="b")),
                    ]
                ),
            ]
        )
        assert collect_fields(expr) == {"org_id", "outcome", "action"}

    def test_group(self):
        expr = FilterGroup(child=FilterTerm(field="org_id", value="x"))
        assert collect_fields(expr) == {"org_id"}

    def test_empty_and(self):
        assert collect_fields(FilterAnd(children=[])) == set()


class TestFilterDef:
    """Tests for FilterDef declarations."""

    def test_required_defaults_to_false(self):
        fdef = FilterDef(key="org_id", column="org_id", operators=[FilterOperator.EQ])
        assert fdef.required is False

    def test_required_can_be_set(self):
        fdef = FilterDef(key="org_id", column="org_id", operators=[FilterOperator.EQ], required=True)
        assert fdef.required is True

    def test_required_round_trips(self):
        fdef = FilterDef(key="org_id", column="org_id", operators=[FilterOperator.EQ], required=True)
        data = fdef.model_dump()
        restored = FilterDef(**data)
        assert restored.required is True


class TestSerialization:
    """Tests for JSON round-tripping (client-server compatibility)."""

    def test_term_round_trip(self):
        term = FilterTerm(field="org_id", op="eq", value="org_1")
        data = term.model_dump()
        restored = FilterTerm(**data)
        assert restored.field == "org_id"
        assert restored.op == "eq"
        assert restored.value == "org_1"

    def test_complex_expr_round_trip(self):
        expr = FilterAnd(
            children=[
                FilterTerm(field="org_id", value="org_1"),
                FilterOr(
                    children=[
                        FilterTerm(field="outcome", value="failure"),
                        FilterTerm(field="outcome", value="error"),
                    ]
                ),
            ]
        )
        data = expr.model_dump()
        restored = FilterAnd(**data)
        assert restored.type == "and"
        assert len(restored.children) == 2
        assert restored.children[1].type == "or"
