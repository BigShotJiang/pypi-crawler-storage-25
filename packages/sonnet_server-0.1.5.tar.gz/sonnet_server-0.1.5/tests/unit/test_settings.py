"""Tests for sonnet_server.config.Settings behavior."""

from typing import Any

import pytest

from sonnet_server.settings import Settings, get_settings, init_settings


def test_settings_defaults(monkeypatch: pytest.MonkeyPatch):
    """Defaults should be stable even if external env or .env sets values.

    We explicitly delete both upper & lower case variants and bypass .env loading
    by passing `_env_file=None`.
    """
    for var in [
        "SONNET_SERVER_HOST",
        "SONNET_SERVER_PORT",
        "SONNET_SERVER_LOG_LEVEL",
        "SONNET_SERVER_SQL_LOG",
        "SONNET_SERVER_RELOAD",
        "sonnet_server_host",
        "sonnet_server_port",
    ]:
        monkeypatch.delenv(var, raising=False)
    s = Settings(_env_file=None)  # ignore project .env file if present
    assert s.host == "0.0.0.0"
    assert s.port == 8080
    assert s.log_level == "INFO"
    assert s.sql_log is False
    assert s.reload is False


def test_env_overrides(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("SONNET_SERVER_HOST", "127.0.0.1")
    monkeypatch.setenv("SONNET_SERVER_PORT", "9090")
    monkeypatch.setenv("SONNET_SERVER_SQL_LOG", "true")
    monkeypatch.setenv("SONNET_SERVER_RELOAD", "false")
    s = Settings()  # new instance reads env
    assert s.host == "127.0.0.1"
    assert s.port == 9090
    assert s.sql_log is True
    assert s.reload is False


def test_case_insensitive_env_name(monkeypatch: pytest.MonkeyPatch):
    # lower-case variable name should still be picked up due to case_sensitive=False
    monkeypatch.setenv("sonnet_server_host", "10.10.10.10")  # type: ignore[arg-type]
    s = Settings()
    assert s.host == "10.10.10.10"


def test_get_settings_singleton():
    # Both calls return the same object (global singleton set on first access).
    a = get_settings()
    b = get_settings()
    assert a is b


def test_get_settings_not_affected_by_new_env(monkeypatch: pytest.MonkeyPatch):
    # Once get_settings() creates the singleton, later env changes do not affect it.
    first = get_settings()
    original_host = first.host
    monkeypatch.setenv("SONNET_SERVER_HOST", "203.0.113.5")
    second = get_settings()
    assert second is first
    assert second.host == original_host  # singleton not replaced


@pytest.mark.parametrize(
    "override,expected",
    [
        ({"host": "1.1.1.1"}, "1.1.1.1"),
        ({"port": 1234}, 1234),
    ],
)
def test_direct_instantiation_with_overrides(override: dict[str, Any], expected: Any):
    s = Settings(**override)
    # pick first and assert value
    key = next(iter(override.keys()))
    assert getattr(s, key) == expected


def test_model_dump_contains_all_core_fields():
    s = Settings()
    data = s.model_dump()
    for field in ["host", "port", "log_level", "sql_log", "reload", "database_url"]:
        assert field in data


def test_database_url_override(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("SONNET_SERVER_DATABASE_URL", "postgresql+psycopg://u:p@h/db")
    s = Settings()
    assert s.database_url == "postgresql+psycopg://u:p@h/db"


def test_init_settings_consumer_registration():
    # Consumer subclass with a different prefix.
    from pydantic_settings import SettingsConfigDict

    class ConsumerSettings(Settings):
        model_config = SettingsConfigDict(env_prefix="MY_APP_", case_sensitive=False, extra="ignore")

    consumer = ConsumerSettings()
    init_settings(consumer)

    # get_settings() now returns the consumer's instance.
    assert get_settings() is consumer


def test_init_settings_replaces_previous():
    first = Settings()
    init_settings(first)
    assert get_settings() is first

    second = Settings()
    init_settings(second)
    assert get_settings() is second
    assert get_settings() is not first
