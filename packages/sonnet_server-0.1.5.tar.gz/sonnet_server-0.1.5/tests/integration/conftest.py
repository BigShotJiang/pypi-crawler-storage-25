"""Fixtures for integration tests."""
