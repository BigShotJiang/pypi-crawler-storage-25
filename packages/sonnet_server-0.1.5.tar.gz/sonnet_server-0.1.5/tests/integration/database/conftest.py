"""Fixtures for database integration tests.

Uses testcontainers to spin up a real PostgreSQL 18 instance. Docker must
be running. Tests are marked ``integration`` and skipped by default in
``task test`` (which runs ``-m unit`` only).
"""

from __future__ import annotations

import pytest
from sqlmodel import Session, create_engine
from testcontainers.postgres import PostgresContainer

from sonnet_server.database import override_session


@pytest.fixture(scope="session")
def pg_container():
    """Provide a PostgreSQL 18 container for the test session.

    Starts once, shared across all database integration tests, stopped
    at the end of the session.
    """
    with PostgresContainer("postgres:18", username="test", password="test", dbname="test_db") as container:
        yield container


@pytest.fixture(scope="session")
def pg_url(pg_container) -> str:
    """Return the PostgreSQL connection URL for the test container.

    Replaces ``psycopg2`` with ``psycopg`` since the project uses
    psycopg v3.
    """
    return pg_container.get_connection_url().replace("psycopg2", "psycopg")


@pytest.fixture(scope="session")
def pg_engine(pg_url):
    """Create a SQLAlchemy engine connected to the test PostgreSQL."""
    engine = create_engine(pg_url)
    yield engine
    engine.dispose()


@pytest.fixture(name="session")
def session_fixture(pg_engine):
    """Provide a PostgreSQL session for each test.

    Each test runs in a transaction that is rolled back after the test,
    ensuring test isolation without recreating tables.
    """
    connection = pg_engine.connect()
    transaction = connection.begin()
    session = Session(bind=connection)
    with override_session(session):
        yield session
    session.close()
    transaction.rollback()
    connection.close()
