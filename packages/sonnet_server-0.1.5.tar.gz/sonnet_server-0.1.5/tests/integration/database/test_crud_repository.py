"""Tests for CrudRepository and CrudConfig.

Uses a real PostgreSQL 18 instance via testcontainers. Docker must be
running. Tests are marked ``integration`` and skipped by default in
``task test`` (which runs ``-m unit`` only).

Test models are defined locally -- no dependency on domain domain models.
Container and session fixtures are in ``conftest.py``.
"""

from datetime import datetime
from uuid import UUID, uuid4

import pytest
from pydantic import BaseModel
from sqlmodel import Field, Session, SQLModel, select

from sonnet_server.database.crud import CrudConfig, CrudRepository
from sonnet_server.exceptions import ResourceNotFoundError, VersionConflictError

# ------------------------------------------------------------------
# Test models (no dependency on domain domain code)
# ------------------------------------------------------------------


class WidgetBase(SQLModel):
    """Base model for widgets."""

    id: UUID | None = None
    slug: str | None = None
    name: str | None = None
    description: str | None = None
    is_deleted: bool | None = None
    version: int | None = None


class Widget(WidgetBase, table=True):
    """Widget DB model."""

    __tablename__ = "widgets"

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    slug: str = Field(unique=True, index=True, nullable=False)
    name: str = Field(nullable=False)
    description: str | None = Field(default=None)
    is_deleted: bool = Field(default=False, nullable=False)
    version: int = Field(default=1, nullable=False)

    # Audit fields
    created_at: datetime | None = Field(default=None)
    updated_at: datetime | None = Field(default=None)
    created_by: str | None = Field(default=None)
    updated_by: str | None = Field(default=None)


class WidgetResponse(BaseModel):
    """Widget response model."""

    id: UUID
    slug: str
    name: str
    description: str | None = None
    version: int


class WidgetInput(BaseModel):
    """Widget create input."""

    name: str
    description: str | None = None


class WidgetUpdate(BaseModel):
    """Widget update input."""

    name: str | None = None
    description: str | None = None
    version: int


# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------


@pytest.fixture(scope="session", autouse=True)
def _create_tables(pg_engine):
    """Create test tables once per session, drop at the end."""
    Widget.__table__.create(bind=pg_engine, checkfirst=True)
    yield
    Widget.__table__.drop(bind=pg_engine, checkfirst=True)


@pytest.fixture
def repo_soft():
    """CrudRepository with soft_delete=True, lookup by slug."""
    return CrudRepository(
        CrudConfig(
            db_model=Widget,
            response_model=WidgetResponse,
            lookup_field="slug",
            soft_delete=True,
            optimistic_locking=True,
            order_by="name",
        )
    )


@pytest.fixture
def repo_hard():
    """CrudRepository with soft_delete=False, lookup by slug."""
    return CrudRepository(
        CrudConfig(
            db_model=Widget,
            response_model=WidgetResponse,
            lookup_field="slug",
            soft_delete=False,
            optimistic_locking=True,
            order_by="name",
        )
    )


def _make_widget(session: Session, slug: str, name: str) -> Widget:
    """Helper: insert a widget directly into the DB."""
    w = Widget(slug=slug, name=name)
    session.add(w)
    session.flush()
    session.refresh(w)
    return w


# ------------------------------------------------------------------
# CrudConfig tests
# ------------------------------------------------------------------


@pytest.mark.integration
class TestCrudConfig:
    def test_valid_config(self):
        cfg = CrudConfig(db_model=Widget, response_model=WidgetResponse, lookup_field="slug")
        assert cfg.lookup_field == "slug"
        # Widget has is_deleted and version -- both auto-detected
        assert cfg.has_soft_delete is True
        assert cfg.has_optimistic_locking is True

    def test_defaults(self):
        cfg = CrudConfig(db_model=Widget, response_model=WidgetResponse)
        assert cfg.lookup_field == "id"
        assert cfg.order_by is None
        assert cfg.order_asc is True
        # Widget has is_deleted and version -- both auto-detected
        assert cfg.has_soft_delete is True
        assert cfg.has_optimistic_locking is True

    def test_explicit_override_disables_auto_detection(self):
        cfg = CrudConfig(db_model=Widget, response_model=WidgetResponse, soft_delete=False, optimistic_locking=False)
        assert cfg.has_soft_delete is False
        assert cfg.has_optimistic_locking is False

    def test_capabilities_detected(self):
        cfg = CrudConfig(db_model=Widget, response_model=WidgetResponse)
        assert cfg.has_timestamps is True
        assert cfg.has_stamp_by is True

    def test_invalid_lookup_field(self):
        with pytest.raises(ValueError, match="lookup_field 'nonexistent'"):
            CrudConfig(db_model=Widget, response_model=WidgetResponse, lookup_field="nonexistent")

    def test_invalid_order_by(self):
        with pytest.raises(ValueError, match="order_by field 'nonexistent'"):
            CrudConfig(db_model=Widget, response_model=WidgetResponse, order_by="nonexistent")

    def test_missing_config_on_init(self):
        with pytest.raises(ValueError, match="CrudRepository requires a CrudConfig"):
            CrudRepository()


# ------------------------------------------------------------------
# Inheritance pattern tests
# ------------------------------------------------------------------


@pytest.mark.integration
class TestInheritancePattern:
    def test_inherits_operations(self, session):
        """Service inheriting CrudRepository gets all operations."""

        class WidgetService(CrudRepository[Widget, WidgetResponse]):
            crud_config = CrudConfig(
                db_model=Widget,
                response_model=WidgetResponse,
                lookup_field="slug",
                soft_delete=True,
                order_by="name",
            )

        svc = WidgetService()
        assert hasattr(svc, "list")
        assert hasattr(svc, "get")
        assert hasattr(svc, "create")
        assert hasattr(svc, "update")
        assert hasattr(svc, "delete")
        assert hasattr(svc, "exists")

    def test_override_create(self, session):
        """Subclass can override create to inject extra fields."""

        class WidgetService(CrudRepository[Widget, WidgetResponse]):
            crud_config = CrudConfig(
                db_model=Widget,
                response_model=WidgetResponse,
                lookup_field="slug",
                soft_delete=True,
            )

            def create(self, data, by=None):
                return super().create(data, by=by, extra={"slug": "generated-slug"})

        svc = WidgetService()
        result = svc.create(WidgetInput(name="Test"))
        assert result.slug == "generated-slug"
        assert result.name == "Test"


# ------------------------------------------------------------------
# list tests
# ------------------------------------------------------------------


@pytest.mark.integration
class TestList:
    def test_list_empty(self, session, repo_soft):
        assert repo_soft.list() == []

    def test_list_returns_all_non_deleted(self, session, repo_soft):
        _make_widget(session, "alpha", "Alpha")
        _make_widget(session, "beta", "Beta")
        results = repo_soft.list()
        assert len(results) == 2
        assert all(isinstance(r, WidgetResponse) for r in results)

    def test_list_excludes_deleted(self, session, repo_soft):
        w = _make_widget(session, "alpha", "Alpha")
        _make_widget(session, "beta", "Beta")
        w.is_deleted = True
        session.add(w)
        session.flush()

        results = repo_soft.list()
        assert len(results) == 1
        assert results[0].slug == "beta"

    def test_list_ordered_by_name(self, session, repo_soft):
        _make_widget(session, "z-slug", "Zebra")
        _make_widget(session, "a-slug", "Apple")
        results = repo_soft.list()
        assert results[0].name == "Apple"
        assert results[1].name == "Zebra"

    def test_list_with_filters(self, session, repo_soft):
        _make_widget(session, "alpha", "Alpha")
        _make_widget(session, "beta", "Beta")
        results = repo_soft.list(filters=[Widget.slug == "alpha"])
        assert len(results) == 1
        assert results[0].slug == "alpha"

    def test_list_hard_delete_includes_all(self, session, repo_hard):
        _make_widget(session, "alpha", "Alpha")
        _make_widget(session, "beta", "Beta")
        results = repo_hard.list()
        assert len(results) == 2


# ------------------------------------------------------------------
# get tests
# ------------------------------------------------------------------


@pytest.mark.integration
class TestGet:
    def test_get_existing(self, session, repo_soft):
        _make_widget(session, "my-slug", "My Widget")
        result = repo_soft.get("my-slug")
        assert result is not None
        assert isinstance(result, WidgetResponse)
        assert result.slug == "my-slug"
        assert result.name == "My Widget"

    def test_get_missing(self, session, repo_soft):
        with pytest.raises(ResourceNotFoundError):
            repo_soft.get("nonexistent")

    def test_get_deleted_returns_none(self, session, repo_soft):
        w = _make_widget(session, "deleted-slug", "Deleted")
        w.is_deleted = True
        session.add(w)
        session.flush()

        with pytest.raises(ResourceNotFoundError):
            repo_soft.get("deleted-slug")

    def test_get_hard_delete_mode_finds_deleted(self, session, repo_hard):
        """Hard delete mode does not filter is_deleted on get."""
        w = _make_widget(session, "slug", "Widget")
        w.is_deleted = True
        session.add(w)
        session.flush()

        result = repo_hard.get("slug")
        assert result is not None


# ------------------------------------------------------------------
# create tests
# ------------------------------------------------------------------


@pytest.mark.integration
class TestCreate:
    def test_create_basic(self, session, repo_soft):
        result = repo_soft.create(WidgetInput(name="New Widget"), extra={"slug": "new-slug"})
        assert isinstance(result, WidgetResponse)
        assert result.name == "New Widget"
        assert result.slug == "new-slug"
        assert result.version == 1

    def test_create_sets_audit_fields(self, session, repo_soft):
        repo_soft.create(WidgetInput(name="Widget"), by="test-user", extra={"slug": "slug-1"})
        w = session.exec(select(Widget).where(Widget.slug == "slug-1")).first()
        assert w.created_by == "test-user"
        assert w.updated_by == "test-user"
        assert w.created_at is not None
        assert w.updated_at is not None

    def test_create_without_by_leaves_audit_null(self, session, repo_soft):
        repo_soft.create(WidgetInput(name="Widget"), extra={"slug": "slug-2"})
        w = session.exec(select(Widget).where(Widget.slug == "slug-2")).first()
        assert w.created_by is None
        assert w.updated_by is None

    def test_create_extra_takes_precedence(self, session, repo_soft):
        """Extra fields override data fields."""
        result = repo_soft.create(
            WidgetInput(name="From Input"),
            extra={"slug": "s", "name": "From Extra"},
        )
        assert result.name == "From Extra"


# ------------------------------------------------------------------
# update tests
# ------------------------------------------------------------------


@pytest.mark.integration
class TestUpdate:
    def test_update_basic(self, session, repo_soft):
        _make_widget(session, "upd-slug", "Original")
        result = repo_soft.update("upd-slug", WidgetUpdate(name="Updated", version=1))
        assert result.name == "Updated"
        assert result.version == 2

    def test_update_version_conflict(self, session, repo_soft):
        _make_widget(session, "vc-slug", "Widget")
        with pytest.raises(VersionConflictError):
            repo_soft.update("vc-slug", WidgetUpdate(name="X", version=99))

    def test_update_not_found(self, session, repo_soft):
        with pytest.raises(ResourceNotFoundError):
            repo_soft.update("ghost", WidgetUpdate(name="X", version=1))

    def test_update_deleted_not_found(self, session, repo_soft):
        w = _make_widget(session, "del-slug", "Widget")
        w.is_deleted = True
        session.add(w)
        session.flush()

        with pytest.raises(ResourceNotFoundError):
            repo_soft.update("del-slug", WidgetUpdate(name="X", version=1))

    def test_update_sets_updated_by(self, session, repo_soft):
        _make_widget(session, "ub-slug", "Widget")
        repo_soft.update("ub-slug", WidgetUpdate(name="Updated", version=1), by="editor")
        w = session.exec(select(Widget).where(Widget.slug == "ub-slug")).first()
        assert w.updated_by == "editor"


# ------------------------------------------------------------------
# delete tests
# ------------------------------------------------------------------


@pytest.mark.integration
class TestDelete:
    def test_soft_delete(self, session, repo_soft):
        _make_widget(session, "del-me", "Widget")
        repo_soft.delete("del-me")

        # Should not appear in list
        assert repo_soft.list() == []

        # But record still in DB
        w = session.exec(select(Widget).where(Widget.slug == "del-me")).first()
        assert w is not None
        assert w.is_deleted is True
        assert w.version == 2

    def test_hard_delete(self, session, repo_hard):
        _make_widget(session, "del-me", "Widget")
        repo_hard.delete("del-me")

        w = session.exec(select(Widget).where(Widget.slug == "del-me")).first()
        assert w is None

    def test_delete_not_found(self, session, repo_soft):
        with pytest.raises(ResourceNotFoundError):
            repo_soft.delete("ghost")

    def test_delete_already_deleted(self, session, repo_soft):
        w = _make_widget(session, "gone", "Widget")
        w.is_deleted = True
        session.add(w)
        session.flush()

        with pytest.raises(ResourceNotFoundError):
            repo_soft.delete("gone")


# ------------------------------------------------------------------
# exists tests
# ------------------------------------------------------------------


@pytest.mark.integration
class TestExists:
    def test_exists_true(self, session, repo_soft):
        _make_widget(session, "present", "Widget")
        assert repo_soft.exists("present") is True

    def test_exists_false(self, session, repo_soft):
        assert repo_soft.exists("absent") is False

    def test_exists_deleted_is_false(self, session, repo_soft):
        w = _make_widget(session, "deleted", "Widget")
        w.is_deleted = True
        session.add(w)
        session.flush()

        assert repo_soft.exists("deleted") is False


# ------------------------------------------------------------------
# list_page tests
# ------------------------------------------------------------------


@pytest.mark.integration
class TestListPage:
    def test_empty(self, session, repo_soft):
        result = repo_soft.list_page(limit=10, offset=0)
        assert result.data == []
        assert result.meta.total == 0
        assert result.meta.has_next is False
        assert result.meta.has_prev is False

    def test_single_page(self, session, repo_soft):
        for i in range(5):
            _make_widget(session, f"slug-{i}", f"Widget {i}")
        result = repo_soft.list_page(limit=10, offset=0)
        assert len(result.data) == 5
        assert result.meta.total == 5
        assert result.meta.has_next is False
        assert result.meta.has_prev is False

    def test_first_page(self, session, repo_soft):
        for i in range(10):
            _make_widget(session, f"slug-{i:02}", f"Widget {i:02}")
        result = repo_soft.list_page(limit=3, offset=0)
        assert len(result.data) == 3
        assert result.meta.total == 10
        assert result.meta.has_next is True
        assert result.meta.has_prev is False
        assert result.meta.limit == 3
        assert result.meta.offset == 0

    def test_middle_page(self, session, repo_soft):
        for i in range(10):
            _make_widget(session, f"slug-{i:02}", f"Widget {i:02}")
        result = repo_soft.list_page(limit=3, offset=3)
        assert len(result.data) == 3
        assert result.meta.has_next is True
        assert result.meta.has_prev is True

    def test_last_page(self, session, repo_soft):
        for i in range(10):
            _make_widget(session, f"slug-{i:02}", f"Widget {i:02}")
        result = repo_soft.list_page(limit=3, offset=9)
        assert len(result.data) == 1
        assert result.meta.has_next is False
        assert result.meta.has_prev is True

    def test_excludes_deleted(self, session, repo_soft):
        w = _make_widget(session, "deleted", "Deleted")
        _make_widget(session, "alive", "Alive")
        w.is_deleted = True
        session.add(w)
        session.flush()
        result = repo_soft.list_page(limit=10, offset=0)
        assert result.meta.total == 1
        assert result.data[0].slug == "alive"

    def test_with_filter(self, session, repo_soft):
        _make_widget(session, "alpha", "Alpha")
        _make_widget(session, "beta", "Beta")
        _make_widget(session, "gamma", "Gamma")
        result = repo_soft.list_page(limit=10, offset=0, filters=[Widget.name != "Beta"])
        assert result.meta.total == 2
        assert all(r.name != "Beta" for r in result.data)

    def test_custom_sort(self, session, repo_soft):
        _make_widget(session, "z-slug", "Zebra")
        _make_widget(session, "a-slug", "Apple")
        _make_widget(session, "m-slug", "Mango")
        result = repo_soft.list_page(limit=10, offset=0, sort=[Widget.name.desc()])
        assert result.data[0].name == "Zebra"
        assert result.data[-1].name == "Apple"

    def test_default_sort_fallback(self, session, repo_soft):
        """When sort=None, falls back to CrudConfig.order_by (name asc)."""
        _make_widget(session, "z-slug", "Zebra")
        _make_widget(session, "a-slug", "Apple")
        result = repo_soft.list_page(limit=10, offset=0)
        assert result.data[0].name == "Apple"
        assert result.data[1].name == "Zebra"
