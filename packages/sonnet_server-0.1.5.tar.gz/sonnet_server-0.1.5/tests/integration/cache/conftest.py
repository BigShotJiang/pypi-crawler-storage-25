"""Fixtures for distributed cache integration tests.

Uses testcontainers to spin up a real Redis instance. Docker must be
running. Tests are marked ``integration`` and skipped by default in
``task test`` (which runs ``-m unit`` only).
"""

from __future__ import annotations

import pytest
from testcontainers.redis import RedisContainer

from sonnet_server.cache.backends.distributed import DistributedBackend


@pytest.fixture(scope="session")
def redis_container():
    """Provide a Redis container for the test session.

    Starts a real Redis 7 instance in Docker. The container is shared
    across all integration tests in this session and stopped at the end.
    """
    with RedisContainer("redis:7") as container:
        yield container


@pytest.fixture(scope="session")
def redis_url(redis_container) -> str:
    """Return the Redis connection URL for the test container."""
    host = redis_container.get_container_host_ip()
    port = redis_container.get_exposed_port(6379)
    return f"redis://{host}:{port}/0"


def make_backend(redis_url: str, cache_name: str, ttl: int = 60) -> DistributedBackend:
    """Create a DistributedBackend connected to the test Redis.

    Helper used by fixtures and tests that need multiple backends.
    """
    import redis.asyncio as aioredis

    pool = aioredis.ConnectionPool.from_url(redis_url, decode_responses=True)
    backend = DistributedBackend(cache_name=cache_name, ttl=ttl, maxsize=64)
    backend._client_instance = aioredis.Redis(connection_pool=pool)
    return backend


@pytest.fixture
async def distributed_backend(redis_url, request) -> DistributedBackend:
    """Create a DistributedBackend connected to the test Redis.

    Each test gets a backend with a unique cache name derived from the
    test name to prevent key collisions between tests.
    """
    cache_name = f"inttest_{request.node.name}"
    backend = make_backend(redis_url, cache_name)
    yield backend
    await backend.clear()
