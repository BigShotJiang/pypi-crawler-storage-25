"""Integration tests for DistributedBackend against a real Redis instance.

Requires Docker to be running. Skipped when running ``task test`` (unit only).
Run with: ``pytest -m integration tests/integration/cache/``
"""

from __future__ import annotations

import pytest

from sonnet_server.cache.backends import MISSING
from sonnet_server.cache.backends.local import LocalBackend
from sonnet_server.cache.backends.near_cache import NearCacheBackend
from tests.integration.cache.conftest import make_backend


@pytest.mark.integration
class TestDistributedBackendRealRedis:
    """Basic operations against a real Redis."""

    @pytest.mark.asyncio
    async def test_put_and_get(self, distributed_backend):
        await distributed_backend.put("key", "value")
        assert await distributed_backend.get("key") == "value"

    @pytest.mark.asyncio
    async def test_get_miss(self, distributed_backend):
        assert await distributed_backend.get("nonexistent") is MISSING

    @pytest.mark.asyncio
    async def test_caches_none(self, distributed_backend):
        await distributed_backend.put("null_key", None)
        result = await distributed_backend.get("null_key")
        assert result is None
        assert result is not MISSING

    @pytest.mark.asyncio
    async def test_tuple_key(self, distributed_backend):
        await distributed_backend.put(("owner", "scope"), {"schema": True})
        result = await distributed_backend.get(("owner", "scope"))
        assert result == {"schema": True}

    @pytest.mark.asyncio
    async def test_delete(self, distributed_backend):
        await distributed_backend.put("key", "value")
        assert await distributed_backend.delete("key") is True
        assert await distributed_backend.get("key") is MISSING

    @pytest.mark.asyncio
    async def test_delete_nonexistent(self, distributed_backend):
        assert await distributed_backend.delete("nonexistent") is False

    @pytest.mark.asyncio
    async def test_delete_by_predicate(self, distributed_backend):
        await distributed_backend.put(("a", "1"), "v1")
        await distributed_backend.put(("a", "2"), "v2")
        await distributed_backend.put(("b", "1"), "v3")
        count = await distributed_backend.delete_by(lambda k: isinstance(k, tuple) and k[0] == "a")
        assert count == 2
        assert await distributed_backend.get(("a", "1")) is MISSING
        assert await distributed_backend.get(("b", "1")) == "v3"

    @pytest.mark.asyncio
    async def test_clear(self, distributed_backend):
        await distributed_backend.put("x", 1)
        await distributed_backend.put("y", 2)
        count = await distributed_backend.clear()
        assert count == 2
        assert await distributed_backend.get("x") is MISSING

    @pytest.mark.asyncio
    async def test_keys(self, distributed_backend):
        await distributed_backend.put("a", 1)
        await distributed_backend.put("b", 2)
        keys = set(await distributed_backend.keys())
        assert keys == {"a", "b"}

    @pytest.mark.asyncio
    async def test_len(self, distributed_backend):
        await distributed_backend.put("a", 1)
        await distributed_backend.put("b", 2)
        assert await distributed_backend.len() == 2

    @pytest.mark.asyncio
    async def test_namespace_isolation(self, redis_url):
        """Two backends with different cache names do not see each other's keys."""
        b1 = make_backend(redis_url, cache_name="ns_a")
        b2 = make_backend(redis_url, cache_name="ns_b")

        await b1.put("shared_key", "from_a")
        assert await b2.get("shared_key") is MISSING
        assert await b1.get("shared_key") == "from_a"

        await b1.clear()
        await b2.clear()


@pytest.mark.integration
class TestNearCacheBackendRealRedis:
    """NearCacheBackend integration tests with real Redis as L2."""

    @pytest.fixture
    def near_cache(self, distributed_backend) -> NearCacheBackend:
        l1 = LocalBackend(maxsize=10, ttl=300)
        return NearCacheBackend(l1=l1, l2=distributed_backend)

    @pytest.mark.asyncio
    async def test_l1_miss_l2_hit_populates_l1(self, near_cache):
        """L2 hit promotes to L1."""
        await near_cache._l2.put("key", "from_redis")
        assert near_cache._l1.get("key") is MISSING

        result = await near_cache.get("key")
        assert result == "from_redis"
        # L1 now has it
        assert near_cache._l1.get("key") == "from_redis"

    @pytest.mark.asyncio
    async def test_put_writes_both_tiers(self, near_cache):
        await near_cache.put("key", "value")
        assert near_cache._l1.get("key") == "value"
        assert await near_cache._l2.get("key") == "value"

    @pytest.mark.asyncio
    async def test_delete_removes_both_tiers(self, near_cache):
        await near_cache.put("key", "value")
        await near_cache.delete("key")
        assert near_cache._l1.get("key") is MISSING
        assert await near_cache._l2.get("key") is MISSING

    @pytest.mark.asyncio
    async def test_clear_removes_both_tiers(self, near_cache):
        await near_cache.put("a", 1)
        await near_cache.put("b", 2)
        await near_cache.clear()
        assert len(near_cache._l1) == 0
        assert await near_cache._l2.len() == 0

    @pytest.mark.asyncio
    async def test_evict_local_only_preserves_l2(self, near_cache):
        """Evicting L1 should not touch L2."""
        await near_cache.put("key", "value")
        near_cache.evict_local("key")
        assert near_cache._l1.get("key") is MISSING
        assert await near_cache._l2.get("key") == "value"

    @pytest.mark.asyncio
    async def test_l1_hit_skips_l2(self, near_cache):
        """L1 hit should return without consulting L2."""
        near_cache._l1.put("key", "local")
        await near_cache._l2.put("key", "remote")
        assert await near_cache.get("key") == "local"
