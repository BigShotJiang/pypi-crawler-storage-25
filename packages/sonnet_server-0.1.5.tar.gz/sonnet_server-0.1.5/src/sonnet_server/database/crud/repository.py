"""Generic CRUD repository for database access.

CrudRepository provides list, get, create, update, and delete operations
parameterized by DB model and response model types. All behaviour is
driven by CrudConfig.

Sessions are obtained from the ambient context via get_current_session().
Callers must ensure a session is active (via borrow_db_session() or the
db_router FastAPI dependency) before calling any repository method.

Two usage patterns:
  - Inheritance: entity service inherits CrudRepository and declares
    crud_config as a class attribute. Standard operations are inherited.
  - Composition: entity service holds a CrudRepository instance and
    exposes only the operations it needs (e.g. read-only services).
"""

import re
from typing import Any, Generic, TypeVar

import arrow
from loguru import logger
from pydantic import BaseModel
from sqlalchemy.exc import IntegrityError
from sqlmodel import SQLModel, func, select
from sqlmodel import col as sql_col

from sonnet_server.database.connection import get_current_session
from sonnet_server.database.crud.config import CrudConfig
from sonnet_server.database.filtering import compile_filter
from sonnet_server.exceptions import DuplicateResourceError, ResourceNotFoundError, SealedResourceError, VersionConflictError
from sonnet_server.models.page_result import PageResult
from sonnet_server.utils.filtering import FilterPage
from sonnet_server.utils.model_converter import to_response_model

TDb = TypeVar("TDb", bound=SQLModel)
TResponse = TypeVar("TResponse", bound=BaseModel)


def _extract_unique_violation(exc: IntegrityError) -> tuple[str | None, str | None]:
    """Extract field name and value from a PostgreSQL unique-violation error.

    PostgreSQL unique violations include a ``DETAIL`` line in the format:
        Key (column)=(value) already exists.

    For composite unique constraints the format is:
        Key (col1, col2)=(val1, val2) already exists.

    The field group may therefore contain multiple column names separated
    by commas. Driver-specific: assumes psycopg2/psycopg3 error formatting.
    Returns (None, None) on SQLite or unrecognized formats.

    Returns:
        (field_name, value) if extractable, otherwise (None, None).
    """
    detail = str(exc.orig) if exc.orig else str(exc)
    match = re.search(r"Key \((.+?)\)=\((.+)\) already exists", detail)
    if match:
        return match.group(1), match.group(2)
    return None, None


class CrudRepository(Generic[TDb, TResponse]):
    """Generic CRUD repository for database access.

    Provides list, get, create, update, and delete operations driven
    by a CrudConfig instance. Handles soft delete, optimistic locking,
    timestamp stamping, and DB-to-response-model conversion.

    All methods use the ambient session from get_current_session(). The
    caller is responsible for ensuring a session is active.

    Usage (inheritance):
        class OrganizationService(CrudRepository[Organization, OrganizationResponse]):
            crud_config = CrudConfig(
                db_model=Organization,
                response_model=OrganizationResponse,
                lookup_field="org_id",
                order_by="name",
                search_field="name",
            )

            def create(self, data, by=None):
                return super().create(data, by=by, extra={"org_id": generate_short_id(16)})

    Usage (composition):
        class AuditLogService:
            _repo = CrudRepository(CrudConfig(
                db_model=AuditLogEntry,
                response_model=AuditLogResponse,
                lookup_field="id",
            ))

            def list(self, filters=None):
                return self._repo.list(filters=filters)
    """

    # Declare as class attribute in subclasses when using inheritance pattern.
    crud_config: CrudConfig

    def __init__(self, config: CrudConfig | None = None) -> None:
        """Initialise the repository.

        Args:
            config: CrudConfig instance. Required when using composition.
                When using inheritance, declare crud_config as a class
                attribute instead and omit this argument.

        Raises:
            ValueError: If no config is provided and no crud_config class
                attribute is declared.
        """
        if config is not None:
            self.crud_config = config
        elif not hasattr(self, "crud_config"):
            msg = (
                "CrudRepository requires a CrudConfig. Either pass config= to "
                "__init__ or declare crud_config as a class attribute."
            )
            raise ValueError(msg)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def list(
        self,
        filters: list[Any] | None = None,
    ) -> list[TResponse]:
        """List records, optionally filtered.

        Applies soft delete filter and default ordering from config.
        Additional filters can be passed as SQLAlchemy column expressions.

        Args:
            filters: Optional list of SQLAlchemy filter expressions.

        Returns:
            List of response model instances.
        """
        session = get_current_session()
        cfg = self.crud_config
        statement = self._base_query(filters)

        if cfg.order_by:
            col = getattr(cfg.db_model, cfg.order_by)
            statement = statement.order_by(col.asc() if cfg.order_asc else col.desc())

        records = session.exec(statement).all()
        return [to_response_model(r, cfg.response_model) for r in records]

    def list_page(
        self,
        limit: int,
        offset: int,
        filters: list[Any] | None = None,
        sort: list[Any] | None = None,
        search: str | None = None,
    ) -> PageResult[TResponse]:
        """List records with offset pagination, returning a PageResult envelope.

        Args:
            limit: Maximum number of records to return. The caller is
                responsible for enforcing any maximum limit.
            offset: Number of records to skip.
            filters: Optional list of SQLAlchemy filter expressions (ANDed).
            sort: Optional list of SQLAlchemy order expressions. When None,
                falls back to the CrudConfig default order_by if set.
            search: Optional search term. When provided and search_field is
                configured in CrudConfig, applies a case-insensitive
                substring match (ilike) on that column.

        Returns:
            PageResult containing the page of items and pagination metadata.
        """
        session = get_current_session()
        cfg = self.crud_config

        all_filters = list(filters) if filters else []
        if search and cfg.search_field:
            search_col = sql_col(getattr(cfg.db_model, cfg.search_field))
            all_filters.append(search_col.ilike(f"%{search}%"))

        base = self._base_query(all_filters or None)

        # COUNT -- same filters, no order/limit/offset
        count_stmt = select(func.count()).select_from(base.subquery())
        total = session.exec(count_stmt).one()

        # Data query -- add sort, limit, offset
        data_stmt = base
        if sort:
            data_stmt = data_stmt.order_by(*sort)
        elif cfg.order_by:
            col = getattr(cfg.db_model, cfg.order_by)
            data_stmt = data_stmt.order_by(col.asc() if cfg.order_asc else col.desc())

        data_stmt = data_stmt.offset(offset).limit(limit)
        records = session.exec(data_stmt).all()
        items = [to_response_model(r, cfg.response_model) for r in records]

        return PageResult.of(items, total=total, limit=limit, offset=offset)

    def get(self, value: Any) -> TResponse:
        """Get a single record by the configured lookup field.

        Applies soft delete filter when configured.

        Args:
            value: Lookup value for the configured lookup_field.

        Returns:
            Response model instance.

        Raises:
            ResourceNotFoundError: If the record is not found (or is soft-deleted).
        """
        record = self._find(value)
        if record is None:
            raise ResourceNotFoundError(self.crud_config.db_model.__name__, value)
        return to_response_model(record, self.crud_config.response_model)

    def create(
        self,
        data: BaseModel,
        by: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> TResponse:
        """Create a new record.

        Args:
            data: Input model with field values.
            by: User or system identifier for created_by/updated_by.
            extra: Additional fields to set on the DB model that are not
                part of the input model (e.g. server-generated org_id).
                Fields in extra take precedence over fields in data.

        Returns:
            Response model instance of the created record.
        """
        session = get_current_session()
        cfg = self.crud_config

        record_data = data.model_dump()
        if extra:
            record_data.update(extra)

        record_data["version"] = 1
        if cfg.has_timestamps:
            now = arrow.utcnow().datetime
            record_data["created_at"] = now
            record_data["updated_at"] = now
        if by is not None and cfg.has_stamp_by:
            record_data["created_by"] = by
            record_data["updated_by"] = by

        record = cfg.db_model(**record_data)
        session.add(record)
        try:
            session.commit()
        except IntegrityError as e:
            session.rollback()
            field, value = _extract_unique_violation(e)
            if field is None:
                logger.warning("Could not extract unique violation detail from IntegrityError: {}", e)
            raise DuplicateResourceError(cfg.db_model.__name__, field, value) from e
        session.refresh(record)

        logger.info(
            "Created {} ({}={})",
            cfg.db_model.__name__,
            cfg.lookup_field,
            getattr(record, cfg.lookup_field),
        )
        return to_response_model(record, cfg.response_model)

    def update(
        self,
        value: Any,
        data: BaseModel,
        by: str | None = None,
    ) -> TResponse:
        """Update an existing record with optimistic locking.

        Args:
            value: Lookup value for the configured lookup_field.
            data: Update model. Must include version field when
                optimistic_locking is enabled.
            by: User or system identifier for updated_by.

        Returns:
            Response model instance of the updated record.

        Raises:
            ResourceNotFoundError: If the record is not found.
            VersionConflictError: If version mismatch (when optimistic_locking=True).
        """
        session = get_current_session()
        cfg = self.crud_config
        record = self._find(value)
        if record is None:
            raise ResourceNotFoundError(cfg.db_model.__name__, value)

        self._check_sealed(record)

        if cfg.has_optimistic_locking:
            # Safety net for dynamic or untyped callers. Properly typed update
            # models (e.g. OrganizationUpdate) declare version as a required
            # field, so Pydantic rejects missing versions before we get here.
            incoming_version = getattr(data, "version", None)
            if incoming_version is None:
                msg = f"version is required for {cfg.db_model.__name__} updates"
                raise ValueError(msg)
            if record.version != incoming_version:
                raise VersionConflictError(
                    expected_version=incoming_version,
                    current_version=record.version,
                )

        update_data = data.model_dump(exclude={"version"}, exclude_unset=True)
        record.sqlmodel_update(update_data)
        self._stamp_update(record, by)

        session.add(record)
        try:
            session.commit()
        except IntegrityError as e:
            session.rollback()
            field, val = _extract_unique_violation(e)
            if field is None:
                logger.warning("Could not extract unique violation detail from IntegrityError: {}", e)
            raise DuplicateResourceError(cfg.db_model.__name__, field, val) from e
        session.refresh(record)

        logger.info(
            "Updated {} ({}={}, version={})",
            cfg.db_model.__name__,
            cfg.lookup_field,
            value,
            record.version,
        )
        return to_response_model(record, cfg.response_model)

    def delete(self, value: Any, by: str | None = None) -> None:
        """Delete a record (soft or hard depending on config).

        Args:
            value: Lookup value for the configured lookup_field.
            by: User or system identifier for updated_by (soft delete only).

        Raises:
            ResourceNotFoundError: If the record is not found.
        """
        session = get_current_session()
        cfg = self.crud_config
        record = self._find(value)
        if record is None:
            raise ResourceNotFoundError(cfg.db_model.__name__, value)

        self._check_sealed(record)

        if cfg.has_soft_delete:
            record.is_deleted = True
            self._stamp_update(record, by)
            session.add(record)
            session.commit()
            logger.info(
                "Soft-deleted {} ({}={})",
                cfg.db_model.__name__,
                cfg.lookup_field,
                value,
            )
        else:
            session.delete(record)
            session.commit()
            logger.info(
                "Deleted {} ({}={})",
                cfg.db_model.__name__,
                cfg.lookup_field,
                value,
            )

    def list_filter_page(self, page: FilterPage, *, extra_filters: list[Any] | None = None) -> PageResult[TResponse]:
        """List records using the declarative filter framework with pagination.

        Compiles the FilterPage expression into a SQLAlchemy where clause via
        compile_filter, applies soft-delete, and uses the CrudConfig order_by
        for sorting. Replaces per-service list_page overrides -- services that
        accept a FilterPage delegate here instead of reimplementing the query.

        When the state machine arrives, the policy (allowed transitions) stays
        in the service; only the mechanics here need updating if the query
        shape changes.

        Args:
            page: Resolved filter expression and pagination parameters,
                produced by FilterableListParams.to_filter_page().
            extra_filters: Optional list of additional SQLAlchemy where
                clauses applied alongside the compiled filter expression.
                Use for server-side constraints that are not exposed as
                client-facing filters (e.g. is_tenant scope).

        Returns:
            PageResult containing the page of items and pagination metadata.
        """
        session = get_current_session()
        cfg = self.crud_config
        where_clause = compile_filter(page.filter_expr, cfg.db_model, page.filter_defs)

        base = self._base_query(filters=extra_filters).where(where_clause)

        total = session.exec(select(func.count()).select_from(base.subquery())).one()

        data_stmt = base
        if cfg.order_by:
            col = getattr(cfg.db_model, cfg.order_by)
            data_stmt = data_stmt.order_by(col.asc() if cfg.order_asc else col.desc())
        data_stmt = data_stmt.offset(page.offset).limit(page.limit)

        records = session.exec(data_stmt).all()
        items = [to_response_model(r, cfg.response_model) for r in records]

        return PageResult.of(items, total=total, limit=page.limit, offset=page.offset)

    def exists(self, value: Any) -> bool:
        """Check whether a record exists for the given lookup value.

        Applies soft delete filter when configured.

        Args:
            value: Lookup value for the configured lookup_field.

        Returns:
            True if a matching (non-deleted) record exists.
        """
        return self._find(value) is not None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _check_sealed(self, record: TDb) -> None:
        """Raise SealedResourceError if the record is sealed.

        Called before any write operation (update, delete, status transition).
        Only runs when has_seal_check is True (i.e. the model has is_sealed).

        Raises:
            SealedResourceError: If record.is_sealed is True.
        """
        if self.crud_config.has_seal_check and getattr(record, "is_sealed", False):
            cfg = self.crud_config
            identifier = str(getattr(record, cfg.lookup_field, "unknown"))
            raise SealedResourceError(cfg.db_model.__name__, identifier)

    def _commit_record(self, record: TDb, by: str | None) -> TDb:
        """Stamp, persist, and refresh a mutated DB record.

        Centralises the session.add / commit / refresh cycle so callers
        (e.g. _transition_status) do not manage sessions directly. Applies
        _stamp_update (version bump, updated_at via arrow, updated_by) before
        committing. Wraps IntegrityError as DuplicateResourceError with the
        same field/value extraction used by create and update.

        Args:
            record: The already-mutated DB model instance to persist.
            by: User or system identifier for updated_by. None leaves it unchanged.

        Returns:
            The refreshed DB model instance (same object, post-commit state).

        Raises:
            DuplicateResourceError: On unique constraint violation.
        """
        session = get_current_session()
        cfg = self.crud_config
        self._check_sealed(record)
        self._stamp_update(record, by)
        session.add(record)
        try:
            session.commit()
        except IntegrityError as e:
            session.rollback()
            field, value = _extract_unique_violation(e)
            if field is None:
                logger.warning("Could not extract unique violation detail from IntegrityError: {}", e)
            raise DuplicateResourceError(cfg.db_model.__name__, field, value) from e
        session.refresh(record)
        return record

    def _stamp_update(self, record: TDb, by: str | None) -> None:
        """Increment version and set updated_at / updated_by on a DB record.

        Called by update and soft-delete before committing.

        Args:
            record: The DB model instance to stamp.
            by: User or system identifier for updated_by. None leaves the
                field unchanged.
        """
        record.version += 1
        if self.crud_config.has_timestamps:
            record.updated_at = arrow.utcnow().datetime
        if by is not None and self.crud_config.has_stamp_by:
            record.updated_by = by

    def _base_query(self, filters: list[Any] | None = None):
        """Build a base SELECT with soft-delete and caller-supplied filters.

        Used by list, list_page, and any future query methods to avoid
        duplicating the soft-delete and filter-application logic.

        Args:
            filters: Optional list of SQLAlchemy filter expressions.

        Returns:
            SQLAlchemy Select statement.
        """
        cfg = self.crud_config
        statement = select(cfg.db_model)

        if cfg.has_soft_delete:
            statement = statement.where(cfg.db_model.is_deleted.is_(False))

        if filters:
            for f in filters:
                statement = statement.where(f)

        return statement

    def _find(self, value: Any) -> TDb | None:
        """Find a DB record by the configured lookup field.

        Applies soft delete filter when configured.

        Args:
            value: Lookup value.

        Returns:
            DB model instance or None.
        """
        session = get_current_session()
        cfg = self.crud_config
        col = getattr(cfg.db_model, cfg.lookup_field)
        statement = select(cfg.db_model).where(col == value)

        if cfg.has_soft_delete:
            statement = statement.where(cfg.db_model.is_deleted.is_(False))

        return session.exec(statement).first()

    def _find_or_raise(self, value: Any) -> TDb:
        """Find a DB record by the configured lookup field or raise ResourceNotFoundError.

        Args:
            value: Lookup value for the configured lookup_field.

        Returns:
            DB model instance.

        Raises:
            ResourceNotFoundError: If the record is not found (or is soft-deleted).
        """
        record = self._find(value)
        if record is None:
            raise ResourceNotFoundError(self.crud_config.db_model.__name__, value)
        return record
