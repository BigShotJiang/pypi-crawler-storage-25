"""Generic CRUD repository for database access.

Provides CrudRepository and CrudConfig for building reusable,
configurable data access layers. Not project-specific -- generic
for extraction into a shared package.
"""

from sonnet_server.database.crud.config import CrudConfig
from sonnet_server.database.crud.repository import CrudRepository

__all__ = ["CrudConfig", "CrudRepository"]
