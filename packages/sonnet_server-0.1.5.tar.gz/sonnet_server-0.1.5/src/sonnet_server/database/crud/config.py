"""Configuration model for CrudRepository.

CrudConfig drives all CrudRepository behaviour. Keeping configuration
as a Pydantic model ensures it is validated at construction time and
is self-documenting.

Capabilities are derived once at construction by inspecting the db_model.
The repository reads them as plain booleans -- no per-call introspection.

Auto-detection rules (apply when the flag is not explicitly set):
  soft_delete        -- enabled when db_model has 'is_deleted'
  optimistic_locking -- enabled when db_model has 'version'
  has_timestamps     -- enabled when db_model has 'created_at' and 'updated_at'
  has_stamp_by       -- enabled when db_model has 'created_by' and 'updated_by'
"""

from typing import Any

from pydantic import BaseModel, ConfigDict, field_validator, model_validator


class CrudConfig(BaseModel):
    """Configuration for a CrudRepository instance.

    All CrudRepository behaviour is driven by this config object.
    Pass an instance to CrudRepository at construction time, or declare
    it as a class attribute when using the inheritance pattern.

    Attributes:
        db_model: The SQLModel table class to operate on.
        response_model: The Pydantic response model to convert DB records to.
        lookup_field: Column name used for get/update/delete lookups.
            Defaults to "id". Set to "org_id", "type_key", etc. as needed.
        soft_delete: When True, delete sets is_deleted=True instead of
            removing the row. List and get filter out deleted records.
            When None (default), auto-detected from db_model.
        optimistic_locking: When True, update checks the version field
            and raises VersionConflictError on mismatch.
            When None (default), auto-detected from db_model.
        order_by: Default sort column name for list queries. None means
            no default ordering.
        order_asc: Sort direction for order_by. True = ascending.
        search_field: Column name for case-insensitive substring search
            in list_page. When set and a search term is provided,
            list_page applies an ilike filter automatically. None means
            the caller must build search filters manually.

    Derived capabilities (set automatically, do not pass explicitly):
        has_soft_delete: Resolved soft_delete capability.
        has_optimistic_locking: Resolved optimistic_locking capability.
        has_timestamps: True when db_model has 'created_at' and 'updated_at'.
        has_stamp_by: True when db_model has 'created_by' and 'updated_by'.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    db_model: type[Any]
    response_model: type[Any]
    lookup_field: str = "id"
    soft_delete: bool | None = None
    optimistic_locking: bool | None = None
    order_by: str | None = None
    order_asc: bool = True
    search_field: str | None = None

    # Derived capabilities -- set by model_validator, not by the caller.
    has_soft_delete: bool = False
    has_optimistic_locking: bool = False
    has_timestamps: bool = False
    has_stamp_by: bool = False
    has_seal_check: bool = False

    @field_validator("lookup_field")
    @classmethod
    def validate_lookup_field(cls, v: str, info: Any) -> str:
        """Validate that lookup_field exists on the db_model."""
        db_model = info.data.get("db_model")
        if db_model is not None and not hasattr(db_model, v):
            msg = f"lookup_field '{v}' does not exist on {db_model.__name__}"
            raise ValueError(msg)
        return v

    @field_validator("order_by")
    @classmethod
    def validate_order_by(cls, v: str | None, info: Any) -> str | None:
        """Validate that order_by field exists on the db_model."""
        if v is None:
            return v
        db_model = info.data.get("db_model")
        if db_model is not None and not hasattr(db_model, v):
            msg = f"order_by field '{v}' does not exist on {db_model.__name__}"
            raise ValueError(msg)
        return v

    @field_validator("search_field")
    @classmethod
    def validate_search_field(cls, v: str | None, info: Any) -> str | None:
        """Validate that search_field exists on the db_model."""
        if v is None:
            return v
        db_model = info.data.get("db_model")
        if db_model is not None and not hasattr(db_model, v):
            msg = f"search_field '{v}' does not exist on {db_model.__name__}"
            raise ValueError(msg)
        return v

    @model_validator(mode="after")
    def derive_capabilities(self) -> CrudConfig:
        """Derive model capabilities by inspecting db_model once at construction."""
        model = self.db_model

        self.has_soft_delete = self.soft_delete if self.soft_delete is not None else hasattr(model, "is_deleted")

        self.has_optimistic_locking = (
            self.optimistic_locking if self.optimistic_locking is not None else hasattr(model, "version")
        )

        self.has_timestamps = hasattr(model, "created_at") and hasattr(model, "updated_at")

        self.has_stamp_by = hasattr(model, "created_by") and hasattr(model, "updated_by")

        self.has_seal_check = hasattr(model, "is_sealed")

        return self
