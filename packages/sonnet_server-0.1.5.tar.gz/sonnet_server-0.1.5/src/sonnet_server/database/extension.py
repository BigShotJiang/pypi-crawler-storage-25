"""Database extension -- manages engine lifecycle and activates checks.

Disposes the database engine on shutdown. Imports the database readiness
check modules during startup, which triggers decorator-based registration
in the pipeline registry. If this extension is not used, no database
checks appear in the pipeline.

See ``checks/__init__.py`` for the stage registration ownership model.
All deferred imports follow the convention documented in ``extensions.py``.
"""

from __future__ import annotations

from loguru import logger

from sonnet_server.extensions import Extension
from sonnet_server.settings import Settings


class DatabaseExtension(Extension):
    """Database engine lifecycle management."""

    @property
    def name(self) -> str:
        return "database"

    async def on_startup(self, settings: Settings) -> None:
        if not settings.database_url:
            logger.warning("DatabaseExtension: no DATABASE_URL configured, skipping")
            return

        # Import check modules to trigger @readiness_check decorator registration.
        # Stage classes are already registered by checks/__init__.py.
        import sonnet_server.checks.database_health_check  # noqa: F401
        import sonnet_server.checks.database_initialization  # noqa: F401
        import sonnet_server.checks.database_schema_check  # noqa: F401

        logger.info("DatabaseExtension: database checks registered")

    async def on_shutdown(self) -> None:
        from sonnet_server.database import dispose_db

        dispose_db()
