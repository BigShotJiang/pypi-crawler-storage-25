"""Database configuration and connection setup.

Refactored to lazily create the SQLModel engine after application settings
have been loaded / possibly overridden by CLI flags. This prevents premature
failure on import when `SONNET_SERVER_DATABASE_URL` is not yet set or will be
provided via command line.
"""

from collections.abc import AsyncGenerator, Generator
from contextlib import contextmanager
from contextvars import ContextVar

from fastapi import HTTPException
from loguru import logger
from sqlalchemy.exc import SQLAlchemyError
from sqlmodel import Session, create_engine, text
from tenacity import before_sleep_log, retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from sonnet_server.settings import get_settings

_engine = None  # type: ignore[var-annotated]

# Ambient session for the current execution context (request or background task).
# Set by borrow_db_session() and get_db_session(). Services call
# get_current_session() instead of accepting a session parameter.
_current_session: ContextVar[Session | None] = ContextVar("_current_session", default=None)


def get_current_session() -> Session:
    """Return the ambient session for the current execution context.

    Raises:
        RuntimeError: If called outside a borrow_db_session or get_db_session scope.
    """
    session = _current_session.get()
    if session is None:
        raise RuntimeError(
            "No active database session in the current context. "
            "Ensure the call is made within a borrow_db_session() scope "
            "or a FastAPI endpoint using the db_router."
        )
    return session


@contextmanager
def override_session(session: Session) -> Generator[Session]:
    """Set the ambient session for the current context, yielding it back.

    Intended for integration tests that create their own Session (e.g. an
    in-memory SQLite session) and need CrudRepository methods -- which call
    get_current_session() -- to see it.

    Not for production use. Production code should use borrow_db_session()
    or the FastAPI get_db_session() dependency.

    Args:
        session: The session to install as the ambient session.

    Yields:
        The same session, for convenience.
    """
    token = _current_session.set(session)
    try:
        yield session
    finally:
        _current_session.reset(token)


def _build_engine():  # type: ignore[return-value]
    """Create and return a new engine from current settings.

    Raises:
        ValueError: if database URL not configured.
    """
    settings = get_settings()
    # Prefer sqlalchemy_url if the consumer provides it (e.g. coco-rag normalises
    # postgres:// → postgresql+psycopg:// for SQLAlchemy while keeping the raw URL
    # for psycopg's own ConnectionPool which does not accept the +dialect suffix).
    database_url = getattr(settings, "sqlalchemy_url", None) or settings.database_url
    if not database_url:
        raise ValueError("Database URL missing: provide SONNET_SERVER_DATABASE_URL env or --database-url CLI argument")
    connect_args = {"connect_timeout": 10}
    engine_local = create_engine(
        database_url,
        pool_pre_ping=True,
        pool_recycle=3600,
        pool_size=5,
        max_overflow=10,
        pool_timeout=30,
        echo=settings.sql_log,
        connect_args=connect_args,
    )
    logger.info("SQL echo is {}", "enabled" if settings.sql_log else "disabled")
    return engine_local


def get_engine():  # type: ignore[return-value]
    """Return a singleton engine instance, creating it lazily.

    If the engine exists but connections fail, it will be disposed and recreated.
    This handles cases where the database wasn't ready when the engine was first created.
    """
    global _engine
    if _engine is None:
        _engine = _build_engine()
    return _engine


def is_initialized() -> bool:
    """Check if database already initialized"""
    global _engine
    return _engine is not None


def init_db() -> None:
    """Initialize the database, no implicit database table creation."""
    logger.info("Initializing database...")
    # SQLAlchemy logging should already be set up by setup_logging()


def dispose_db() -> None:
    """Dispose of the database engine if it was created."""
    global _engine
    if _engine is not None:
        logger.info("Closing database connections")
        _engine.dispose()
        _engine = None


def _create_session() -> Session:
    """Create a session object. Pure in-memory -- no I/O, no retry needed.

    Session() does not check out a connection from the pool. The pool checks
    out a connection lazily on the first statement executed against the session.
    pool_pre_ping=True handles stale connection detection at that point.

    Returns:
        Session: A new session ready for use.
    """
    return Session(get_engine())


@retry(
    stop=stop_after_attempt(5),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    reraise=True,
    retry=retry_if_exception_type(SQLAlchemyError),
    before_sleep=before_sleep_log(logger, "DEBUG"),
)
def _create_session_with_probe() -> Session:
    """Create a session and verify it can reach the database, with retry.

    This is the only place a real network round-trip is made unconditionally.
    It exists solely for startup resilience: when borrow_db_session() is called
    before the database is ready (health checks, CLI commands, alembic runs).

    A fresh Session is created on every attempt so that after an engine disposal
    the retry does not reuse a session bound to a dead pool.

    Per-request sessions (get_db_session) do NOT call this. The pool's own
    pre-ping is sufficient there, and retrying a live request with exponential
    backoff would spike latency unacceptably.

    Returns:
        Session: A verified, open session.

    Raises:
        SQLAlchemyError: Re-raised after all retries exhausted.
    """
    global _engine
    session = Session(get_engine())
    try:
        session.exec(text("SELECT 1"))
        return session
    except SQLAlchemyError as e:
        session.close()
        if _engine is not None:
            logger.warning("Database probe failed, disposing engine for retry...")
            _engine.dispose()
            _engine = None
        logger.error("Database connection probe failed: {}", e)
        raise


@contextmanager
def borrow_db_session(*, commit: bool = False) -> Generator[Session]:
    """Public context manager for ad-hoc database usage.

    Creates a database session with retry logic and yields it to the caller.
    Will attempt to connect to the database with exponential backoff.
    If the database is not ready, it will retry up to 5 times.

    Args:
        commit: If True, auto-commit on clean exit and rollback on error.
                If False (default), the caller manages transactions.

    Use this function for health checks, utility scripts, or any
    non-FastAPI context. For FastAPI route handlers, use get_db_session()
    as a dependency instead.

    Examples:
        Read-only (default):
            with borrow_db_session() as session:
                results = session.exec(select(MyModel))

        Auto-commit:
            with borrow_db_session(commit=True) as session:
                session.add(record)
    """
    session = _create_session_with_probe()
    session_id = id(session)
    _current_session.set(session)

    try:
        yield session
        if commit:
            session.commit()
    except Exception as e:  # noqa: BLE001
        if commit:
            session.rollback()
        if not isinstance(e, HTTPException):
            logger.error("Error during database session {}: {}", session_id, e)
        raise
    finally:
        _current_session.set(None)
        session.close()
        logger.trace("Database session {} closed and resources released", session_id)


async def get_db_session() -> AsyncGenerator[Session]:
    """FastAPI dependency yielding a database session.

    Sets the ambient session context var for the duration of the request
    so services can call get_current_session() without a session parameter.

    Must be an async generator: sync generator dependencies run their __enter__
    in a worker thread via contextmanager_in_threadpool, so any ContextVar set
    there is invisible to the endpoint (which runs in a different thread with a
    separate context snapshot). As an async generator, this runs directly on the
    event loop and the ContextVar is visible to all downstream code.

    Session creation (_create_session) is pure in-memory -- Session() does no
    I/O, and pool_pre_ping handles stale connections at first-use checkout.
    No thread dispatch is needed here.

    Usage at router level (preferred):
        router = APIRouter(dependencies=[Depends(get_db_session)])
    """
    session = _create_session()
    session_id = id(session)
    _current_session.set(session)
    logger.trace("Request session {} opened", session_id)
    try:
        yield session
    except Exception as e:  # noqa: BLE001
        session.rollback()
        if not isinstance(e, HTTPException):
            logger.error("Error during request session {}: {}", session_id, e)
        raise
    finally:
        _current_session.set(None)
        session.close()
        logger.trace("Request session {} closed", session_id)
