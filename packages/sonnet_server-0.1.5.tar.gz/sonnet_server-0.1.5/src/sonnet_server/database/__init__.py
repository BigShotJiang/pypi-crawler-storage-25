"""Database package for Sonnet server.

Public surface for the database module. Import from here::

    from sonnet_server.database import (
        borrow_db_session, get_current_session, get_db_session, get_engine,
        init_db, dispose_db, is_initialized, override_session,
        AlembicManager,
        AdvisoryLock, advisory_lock, try_advisory_lock,
        DatabaseExtension,
    )
"""

from .advisory_lock import AdvisoryLock, advisory_lock, try_advisory_lock
from .alembic_utils import AlembicManager
from .connection import (
    borrow_db_session,
    dispose_db,
    get_current_session,
    get_db_session,
    get_engine,
    init_db,
    is_initialized,
    override_session,
)
from .extension import DatabaseExtension

__all__ = [
    # Connection functions
    "borrow_db_session",
    "get_current_session",
    "get_db_session",
    "get_engine",
    "is_initialized",
    "init_db",
    "dispose_db",
    "override_session",
    # Alembic utilities
    "AlembicManager",
    # Advisory lock utilities
    "AdvisoryLock",
    "advisory_lock",
    "try_advisory_lock",
    # Extension
    "DatabaseExtension",
]
