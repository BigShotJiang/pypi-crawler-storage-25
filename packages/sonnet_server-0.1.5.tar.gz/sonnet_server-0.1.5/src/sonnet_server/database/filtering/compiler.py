"""SQLAlchemy filter compiler -- walks a FilterExpr AST and produces clauses.

The compiler validates each term against the provided FilterDef list,
ensuring only declared fields and operators are accepted. Unknown fields
or disallowed operators raise ValueError.

Typed value compilation
~~~~~~~~~~~~~~~~~~~~~~~

FilterDefs with ``json_value_type`` delegate to a typed value compiler
function. Domain code provides its compilers via two mechanisms:

1. **Dependency injection (preferred for testability).** Pass a
   ``typed_compilers`` dict to ``compile_filter``::

       compilers = {"quantity": compile_quantity, "coding": compile_coding}
       clause = compile_filter(expr, db_model, filter_defs, typed_compilers=compilers)

2. **Global registry (convenience for production startup).** Register
   once at import time via ``register_typed_value_compiler``::

       register_typed_value_compiler("quantity", compile_quantity)

   When ``typed_compilers`` is not passed (or is None), the compiler
   falls back to the global registry.

The framework provides no built-in typed value compilers. All domain-
specific types (quantity, coding, etc.) must be provided by the domain
layer.

Usage:
    from sonnet_server.database.filtering import compile_filter

    clause = compile_filter(expr, db_model=AuditLogEvent, filter_defs=AUDIT_TRAIL_FILTERS)
    query = select(AuditLogEvent).where(clause)
"""

import json
from collections.abc import Callable
from typing import Any

import sqlalchemy as sa

from sonnet_server.utils.filtering.filter_defs import FilterDef, FilterOperator
from sonnet_server.utils.filtering.types import (
    FilterAnd,
    FilterExpr,
    FilterGroup,
    FilterNot,
    FilterOr,
    FilterTerm,
)

# ---------------------------------------------------------------------------
# Typed value compiler registry
# ---------------------------------------------------------------------------

TypedValueCompilerFn = Callable[[Any, FilterDef, str, str], sa.ColumnElement]
"""Signature: (column, filter_def, operator, raw_value) -> clause."""

_typed_value_compilers: dict[str, TypedValueCompilerFn] = {}


def register_typed_value_compiler(type_name: str, compiler_fn: TypedValueCompilerFn) -> None:
    """Register a typed value compiler for a given json_value_type.

    Domain code calls this at import/startup time to teach the compiler
    how to handle domain-specific value types.

    Args:
        type_name: The json_value_type string (e.g. "quantity", "coding").
        compiler_fn: A function (column, fdef, op, raw_value) -> SA clause.
    """
    _typed_value_compilers[type_name] = compiler_fn


# ---------------------------------------------------------------------------
# Helpers exposed for use by typed value compiler implementations
# ---------------------------------------------------------------------------


def navigate_json(column: Any, path: list[str]) -> Any:
    """Navigate into a JSONB column using the ``->`` operator.

    Useful for typed value compiler implementations that need to extract
    nested values from a JSONB column.

    Example::

        obj = navigate_json(column, ["temperature"])
        val = obj.op("->>")("value")  # text extraction
    """
    navigated = column
    for key in path:
        navigated = navigated.op("->")(key)
    return navigated


def build_json_containment(
    column: Any,
    json_path: list[str],
    target: dict | list,
) -> sa.ColumnElement:
    """Build a JSONB containment clause (``@>``) with path nesting.

    Wraps the target in the json_path structure and produces a parameterized
    containment check. Useful for typed value compiler implementations.

    Args:
        column: The SA column reference (JSONB column).
        json_path: Path to nest the target in, outermost first.
        target: The containment target (dict or list of dicts).

    Example::

        # content @> '{"tags": {"values": [{"name": "priority"}]}}'
        build_json_containment(col, ["tags", "values"], [{"name": "priority"}])
    """
    containment: dict | list = target
    for key in reversed(json_path):
        containment = {key: containment}
    jsonb_value = sa.cast(sa.literal(json.dumps(containment)), sa.dialects.postgresql.JSONB)
    return column.op("@>")(jsonb_value)


# ---------------------------------------------------------------------------
# Main compiler
# ---------------------------------------------------------------------------


def compile_filter(
    expr: FilterExpr,
    db_model: Any,
    filter_defs: list[FilterDef],
    typed_compilers: dict[str, TypedValueCompilerFn] | None = None,
) -> sa.ColumnElement:
    """Compile a FilterExpr AST into a SQLAlchemy clause.

    Args:
        expr: The filter expression tree to compile.
        db_model: The SQLModel table class to resolve column references.
        filter_defs: Allowed filter definitions for validation.
        typed_compilers: Domain-specific typed value compilers. When
            provided, these are used for FilterDefs with json_value_type.
            When None, falls back to the global registry populated via
            register_typed_value_compiler().

    Returns:
        A SQLAlchemy clause element suitable for .where().
        Returns sa.true() for empty expressions.

    Raises:
        ValueError: If a field is not declared or an operator is not allowed.
    """
    defs_by_key = {d.key: d for d in filter_defs}
    resolved_compilers = typed_compilers if typed_compilers is not None else _typed_value_compilers
    return _compile(expr, db_model, defs_by_key, resolved_compilers)


def _compile(
    expr: FilterExpr,
    db_model: Any,
    defs_by_key: dict[str, FilterDef],
    typed_compilers: dict[str, TypedValueCompilerFn],
) -> sa.ColumnElement:
    """Recursive compiler dispatch."""
    if isinstance(expr, FilterTerm):
        return _compile_term(expr, db_model, defs_by_key, typed_compilers)
    if isinstance(expr, FilterAnd):
        if not expr.children:
            return sa.true()
        clauses = [_compile(child, db_model, defs_by_key, typed_compilers) for child in expr.children]
        return sa.and_(*clauses)
    if isinstance(expr, FilterOr):
        if not expr.children:
            return sa.false()
        clauses = [_compile(child, db_model, defs_by_key, typed_compilers) for child in expr.children]
        return sa.or_(*clauses)
    if isinstance(expr, FilterNot):
        return sa.not_(_compile(expr.child, db_model, defs_by_key, typed_compilers))
    if isinstance(expr, FilterGroup):
        return _compile(expr.child, db_model, defs_by_key, typed_compilers)

    raise ValueError(f"Unknown filter expression type: {type(expr)}")


def _compile_term(
    term: FilterTerm,
    db_model: Any,
    defs_by_key: dict[str, FilterDef],
    typed_compilers: dict[str, TypedValueCompilerFn],
) -> sa.ColumnElement:
    """Compile a single filter term to a SQLAlchemy clause."""
    fdef = defs_by_key.get(term.field)
    if fdef is None:
        allowed = ", ".join(sorted(defs_by_key.keys()))
        raise ValueError(f"Unknown filter field '{term.field}'. Allowed: {allowed}")

    op = term.op

    # Promote EQ to JSON_CONTAINS for fields that only support JSON containment.
    # Query expressions use `=` as the only non-symbol equality token, but
    # JSON_CONTAINS fields (actor_id, target_id, etc.) cannot use SQL equality.
    # This makes `actor_id = user_alice` in a q expression behave identically to
    # the flat param `?actor_id=user_alice`, which uses the default operator.
    # Promotion is intentionally limited to EQ -> JSON_CONTAINS; other mismatches
    # are rejected so that operator intent is always explicit.
    if op == FilterOperator.EQ and FilterOperator.JSON_CONTAINS in fdef.operators and op not in fdef.operators:
        op = FilterOperator.JSON_CONTAINS

    if op not in fdef.operators:
        allowed_ops = ", ".join(sorted(fdef.operators))
        raise ValueError(f"Operator '{op}' not allowed for field '{term.field}'. Allowed: {allowed_ops}")

    column = getattr(db_model, fdef.resolved_column)
    value = term.value

    # Typed value compilation: delegate to the provided compiler function.
    if fdef.json_value_type:
        compiler_fn = typed_compilers.get(fdef.json_value_type)
        if compiler_fn is None:
            raise ValueError(
                f"No typed value compiler registered for '{fdef.json_value_type}' "
                f"(used by field '{fdef.key}'). "
                f"Pass typed_compilers to compile_filter() or register globally "
                f"via register_typed_value_compiler()."
            )
        return compiler_fn(column, fdef, op, value)

    if op == FilterOperator.JSON_CONTAINS:
        return _compile_json_contains(column, fdef.json_path, value, fdef.json_is_array)

    if op == FilterOperator.JSON_PATH_IS_NULL:
        return _compile_json_path_isnull(column, fdef.json_path, value)

    return _compile_scalar(column, op, value)


_IN_MAX = 100


def _parse_in_values(value: str) -> list[str]:
    """Parse and validate a comma-separated IN filter value.

    Strips whitespace from each element. Raises ValueError if the list
    is empty or exceeds _IN_MAX elements.
    """
    items = [v.strip() for v in value.split(",") if v.strip()]
    if not items:
        raise ValueError("IN filter requires at least one value")
    if len(items) > _IN_MAX:
        raise ValueError(f"IN filter exceeds maximum of {_IN_MAX} values (got {len(items)})")
    return items


def _compile_isnull(column: Any, value: str) -> sa.ColumnElement:
    """Compile an IS NULL / IS NOT NULL clause.

    Accepts "true" or "false" (case-insensitive).
    """
    lower = value.lower()
    if lower == "true":
        return column.is_(None)
    if lower == "false":
        return column.is_not(None)
    raise ValueError(f"IS_NULL operator requires 'true' or 'false', got '{value}'")


def _compile_comparison(column: Any, op: str, value: str) -> sa.ColumnElement:
    """Compile a typed comparison (gt, gte, lt, lte).

    Casts the raw string value to the column's SQL type so PostgreSQL
    compares correctly (e.g. timestamptz >= '...'::timestamptz).
    """
    typed_value = sa.literal(value).cast(column.type)
    ops = {
        FilterOperator.GT: column > typed_value,
        FilterOperator.GTE: column >= typed_value,
        FilterOperator.LT: column < typed_value,
        FilterOperator.LTE: column <= typed_value,
    }
    if op not in ops:
        raise ValueError(f"Unsupported operator: {op}")
    return ops[op]


def _compile_scalar(
    column: Any,
    op: str,
    value: str,
) -> sa.ColumnElement:
    """Compile a scalar (non-JSON) filter operation.

    Handles: eq, neq, isnull, prefix, like, in, gt, gte, lt, lte.

    IS_NULL accepts "true" or "false" (case-insensitive) and produces
    ``column IS NULL`` or ``column IS NOT NULL`` respectively.

    For comparison operators (gt, gte, lt, lte) the raw string value is
    cast to the column's SQL type so that PostgreSQL can compare correctly
    (e.g. timestamp >= '2026-...'::timestamptz instead of >= varchar).
    """
    if op == FilterOperator.EQ:
        return column == sa.literal(value).cast(column.type)
    if op == FilterOperator.NEQ:
        return column != sa.literal(value).cast(column.type)
    if op == FilterOperator.IS_NULL:
        return _compile_isnull(column, value)
    if op == FilterOperator.PREFIX:
        return column.like(f"{value}%")
    if op == FilterOperator.LIKE:
        return column.ilike(f"%{value}%")
    if op == FilterOperator.IN:
        return column.in_(_parse_in_values(value))
    return _compile_comparison(column, op, value)


def _compile_json_path_isnull(
    column: Any,
    json_path: list[str] | None,
    value: str,
) -> sa.ColumnElement:
    """Compile a JSON path IS NULL / IS NOT NULL check.

    Navigates into a JSONB column using the ``->`` operator for each path
    segment, then checks whether the terminal value is NULL (path absent
    or explicitly null).

    Args:
        column: The SA column reference (JSONB column).
        json_path: Path segments into the JSON structure.
            E.g. ["parent", "reference"] -> column -> 'parent' -> 'reference'.
        value: "true" for IS NULL, "false" for IS NOT NULL.
    """
    if not json_path:
        raise ValueError("json_path_isnull requires json_path on the FilterDef")

    navigated = navigate_json(column, json_path)

    lower = value.lower()
    if lower == "true":
        return navigated.is_(None)
    if lower == "false":
        return navigated.is_not(None)
    raise ValueError(f"JSON_PATH_IS_NULL operator requires 'true' or 'false', got '{value}'")


def _compile_json_contains(
    column: Any,
    json_path: list[str] | None,
    value: str,
    is_array: bool = False,
) -> sa.ColumnElement:
    """Compile a JSON containment query.

    For array columns (e.g. actor): actor::jsonb @> '[{"id": "value"}]'
    For object columns (e.g. source): source::jsonb @> '{"id": "value"}'

    Args:
        column: The SA column reference.
        json_path: Path into the JSON to build the containment target.
            E.g. ["id"] -> {"id": "value"}.
        value: The value to match.
        is_array: If True, wraps the target in a list for array containment.
    """
    if not json_path:
        raise ValueError("json_contains requires json_path on the FilterDef")

    # Build the leaf target: the last path segment holds the value,
    # preceding segments are nesting keys delegated to build_json_containment.
    leaf = {json_path[-1]: value}
    target: dict | list = [leaf] if is_array else leaf
    return build_json_containment(column, json_path[:-1], target)
