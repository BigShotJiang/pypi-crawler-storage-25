"""Server profile configuration and parsing.

This module handles the server profile configuration which determines
which profile-gated extensions are active (REST, GraphQL, MCP, etc.).

Valid profile names are not hardcoded here. They are derived from the
set of registered profile extensions in the ``ExtensionRegistry``.
``parse_profile()`` accepts the valid set as a parameter so that any
profile declared by any extension is automatically accepted.
"""

from functools import lru_cache


class ProfileManager:
    """Manages server profile configuration state.

    This class follows the singleton pattern to maintain active profiles
    throughout the application lifecycle.
    """

    def __init__(self):
        self._active_profiles: set[str] | None = None

    def set_active_profiles(self, profiles: set[str]) -> None:
        """Set the active profiles (called during app startup).

        Args:
            profiles: Set of active profile names
        """
        self._active_profiles = profiles

    def get_active_profiles(self) -> set[str]:
        """Get the active profiles set.

        Returns:
            Set of active profile names.

        Note:
            If profiles haven't been set yet, returns an empty set.
            Callers should ensure ``set_active_profiles`` is called during
            startup before this is used.
        """
        if self._active_profiles is None:
            return set()
        return self._active_profiles


@lru_cache
def get_profile_manager() -> ProfileManager:
    """Get or create the singleton ProfileManager instance.

    Returns:
        The ProfileManager instance.
    """
    return ProfileManager()


def set_active_profiles(profiles: set[str]) -> None:
    """Set the active profiles (called during app startup).

    Args:
        profiles: Set of active profile names
    """
    get_profile_manager().set_active_profiles(profiles)


def get_active_profiles() -> set[str]:
    """Get the active profiles set.

    Returns:
        Set of active profile names. Empty set if not yet initialized.
    """
    return get_profile_manager().get_active_profiles()


def parse_profile(config: str | None, valid: set[str]) -> set[str]:
    """Parse server profile configuration.

    Args:
        config: Comma-separated profile names (case-insensitive), None, or
                empty string. None or empty string enables all valid profiles.
        valid: Complete set of valid profile names. Derived from all registered
               profile extensions in the ``ExtensionRegistry``.

    Returns:
        Set of enabled profile names in lowercase.

    Raises:
        ValueError: If any requested profile is not in ``valid``.

    Examples:
        >>> parse_profile(None, {"rest", "graphql"})
        {'rest', 'graphql'}
        >>> parse_profile("", {"rest", "graphql"})
        {'rest', 'graphql'}
        >>> parse_profile("REST", {"rest", "graphql"})
        {'rest'}
        >>> parse_profile("rest,mcp", {"rest", "graphql", "mcp"})
        {'rest', 'mcp'}
    """
    # Empty, None, or whitespace-only means all valid profiles enabled
    if not config or not config.strip():
        return set(valid)

    # Parse input (case-insensitive), convert to lowercase
    profiles = {p.strip().lower() for p in config.split(",") if p.strip()}

    # Validate against the caller-supplied valid set
    invalid = profiles - valid
    if invalid:
        raise ValueError(f"Invalid profile(s): {invalid}. Valid: {', '.join(sorted(valid))}")

    return profiles


__all__ = ["parse_profile", "get_active_profiles", "set_active_profiles", "get_profile_manager"]
