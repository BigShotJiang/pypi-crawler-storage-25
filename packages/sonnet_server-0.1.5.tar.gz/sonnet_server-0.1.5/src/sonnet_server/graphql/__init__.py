"""GraphQL package for Sonnet server.

Public surface for the graphql module::

    from sonnet_server.graphql import (
        GraphQLContext,
        get_authenticated_context,
        get_tenant_context,
    )

Sonnet provides ``GraphQLContext`` and two ready-to-use context getter
functions that wire the guard system into GraphQL -- use them as the
``context_getter`` argument to ``GraphQLRouter``::

    from sonnet_server.graphql import get_tenant_context
    graphql_router = GraphQLRouter(schema, context_getter=get_tenant_context)

Sonnet also provides ``GraphQLExtension`` (in ``sonnet_server.api``) as a
base class. Consumers subclass it and override ``routers()`` to supply their
own strawberry schema::

    from sonnet_server.api import GraphQLExtension

    class MyGraphQLExtension(GraphQLExtension):
        def routers(self):
            from myapp.graphql.router import create_graphql_router
            return [create_graphql_router()]

Note: importing this module pulls in strawberry.
Only import in modules that already depend on the ``[graphql]`` extra.
"""

from sonnet_server.graphql.context import GraphQLContext, get_authenticated_context, get_tenant_context

__all__ = ["GraphQLContext", "get_authenticated_context", "get_tenant_context"]
