"""GraphQL context with service registry and guard integration."""

from typing import Any, TypeVar

from fastapi import Depends, Request
from strawberry.fastapi import BaseContext

from sonnet_server.guards import AuthContext, TenantContext, require_auth, require_tenant
from sonnet_server.services.registry import get_service_registry

T = TypeVar("T")


class GraphQLContext(BaseContext):
    """Enhanced GraphQL context with service registry access.

    Use one of the provided context getter functions as the ``context_getter``
    argument to ``GraphQLRouter`` rather than writing a bare getter with no
    guard enforcement::

        from sonnet_server.graphql.context import get_authenticated_context

        graphql_router = GraphQLRouter(schema, context_getter=get_authenticated_context)

    For endpoints that also need tenant context::

        from sonnet_server.graphql.context import get_tenant_context

        graphql_router = GraphQLRouter(schema, context_getter=get_tenant_context)

    For consumers that need additional dependencies (e.g. a domain-specific
    database connection), compose with the sonnet getters using ``Depends``::

        from sonnet_server.graphql.context import get_authenticated_context

        async def get_context(
            base: GraphQLContext = Depends(get_authenticated_context),
            cdb: CypherGraphDB = Depends(get_graphdb),
        ) -> MyGraphQLContext:
            base.cdb = cdb
            return base
    """

    def __init__(self, request: Request, **kwargs: Any):
        """Initialise the GraphQL context.

        Args:
            request: The FastAPI request object.
            **kwargs: Additional context values set as attributes (e.g. cdb=...).
        """
        super().__init__()
        self.request = request
        self._registry = get_service_registry()

        for key, value in kwargs.items():
            setattr(self, key, value)

    def service(self, service_type: type[T]) -> T:
        """Get a service by type from the registry.

        Args:
            service_type: The type of the service to retrieve.

        Returns:
            An instance of the requested service.

        Raises:
            KeyError: If the service is not registered.
        """
        try:
            return self._registry.get(service_type)
        except KeyError as e:
            raise KeyError(f"Service {service_type.__name__} not registered") from e


# ---------------------------------------------------------------------------
# Ready-to-use context getter functions for GraphQLRouter(context_getter=...)
# ---------------------------------------------------------------------------


async def get_authenticated_context(
    request: Request,
    _auth: AuthContext = Depends(require_auth),
) -> GraphQLContext:
    """Context getter that enforces authentication.

    Sets the ambient ``_current_auth`` ContextVar via ``require_auth`` before
    the resolver runs. Resolvers and services call ``get_current_auth()`` to
    read the identity -- exactly the same as REST endpoints on ``auth_router``.

    Use as ``context_getter`` on any GraphQL endpoint that requires a logged-in
    user but does not need tenant scoping::

        graphql_router = GraphQLRouter(schema, context_getter=get_authenticated_context)
    """
    return GraphQLContext(request=request)


async def get_tenant_context(
    request: Request,
    _tenant: TenantContext = Depends(require_tenant),
) -> GraphQLContext:
    """Context getter that enforces authentication + tenant context.

    Chains ``require_auth`` → ``require_tenant`` (FastAPI resolves the
    dependency chain automatically). Sets both ``_current_auth`` and
    ``_current_tenant`` ContextVars before the resolver runs.

    Use as ``context_getter`` on any GraphQL endpoint that needs full tenant
    scoping -- the standard choice for multi-tenant GraphQL APIs::

        graphql_router = GraphQLRouter(schema, context_getter=get_tenant_context)
    """
    return GraphQLContext(request=request)
