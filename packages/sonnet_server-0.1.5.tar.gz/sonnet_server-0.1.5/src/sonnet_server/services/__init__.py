"""Service layer for Sonnet server.

Public surface for the services module::

    from sonnet_server.services import (
        ServiceRegistry, get_service_registry,
        HealthCheckService, HealthCheckResult, get_health_check_service,
        register_core_services,
    )
"""

from sonnet_server.services.di import register_core_services
from sonnet_server.services.health_check_service import HealthCheckResult, HealthCheckService, get_health_check_service
from sonnet_server.services.registry import ServiceRegistry, get_service_registry

__all__ = [
    # Service registry
    "ServiceRegistry",
    "get_service_registry",
    # Health check service
    "HealthCheckResult",
    "HealthCheckService",
    "get_health_check_service",
    # DI / wiring
    "register_core_services",
]
