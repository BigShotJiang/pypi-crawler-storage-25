"""Dependency injection setup module.

This module provides core infrastructure service registration.
Consumer projects call ``register_core_services()`` first, then
register their own domain services on top.
"""

from loguru import logger

from sonnet_server.services.health_check_service import HealthCheckService, get_health_check_service
from sonnet_server.services.registry import ServiceRegistry


def register_core_services(registry: ServiceRegistry) -> None:
    """Register core infrastructure services in the service registry.

    Core services are registered as factories because they are lightweight
    and their get_*_service() functions already provide singleton behavior via @lru_cache.

    Consumer projects should call this first, then register their own
    domain services:

        register_core_services(registry)
        registry.register_factory(MyService, get_my_service)

    Args:
        registry: Service registry instance to register services in
    """
    logger.debug("Registering core services in DI container")

    registry.register_factory(HealthCheckService, get_health_check_service)
