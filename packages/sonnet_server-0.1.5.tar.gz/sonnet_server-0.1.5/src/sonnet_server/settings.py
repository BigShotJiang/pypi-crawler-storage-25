"""Application configuration using Pydantic Settings.

Base settings class for all sonnet-server consumers. The ``Settings`` class
defines infrastructure fields (host, port, database_url, etc.) with the
default ``SONNET_SERVER_`` env prefix. Consumer projects subclass it, override
``model_config`` with their own prefix (e.g. ``MY_APP_``), and call
``init_settings()`` to make the instance globally available.

Lifecycle::

    # my_app/settings.py
    from sonnet_server.settings import Settings as SonnetSettings, init_settings

    class Settings(SonnetSettings):
        model_config = SettingsConfigDict(env_prefix="MY_APP_", ...)

    @lru_cache
    def get_settings() -> Settings:
        return Settings()

    # Module-level: registers with sonnet-server on first import.
    init_settings(get_settings())

All sonnet-server internals call ``get_settings()`` from this module. After
``init_settings()``, they receive the consumer's instance (with the consumer's
env prefix and extra fields).

For standalone / test usage, ``get_settings()`` falls back to a plain
``Settings()`` with the default ``SONNET_SERVER_`` prefix.
"""

from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime application settings.

    Attributes map directly to environment variables using the ``SONNET_SERVER_``
    prefix (case-insensitive). For example, ``host`` <- ``SONNET_SERVER_HOST``.
    """

    # Server settings
    # These settings control the behavior of the Sonnet server itself.
    host: str = Field(
        default="0.0.0.0",
        description="Host interface to bind the server",
    )  # fmt: skip
    port: int = Field(
        default=8080,
        description="Server port",
    )  # fmt: skip
    log_level: Literal["TRACE", "DEBUG", "INFO", "WARNING", "ERROR"] = Field(
        default="INFO",
        description="Application log level",
    )
    reload: bool = Field(
        default=False,
        description="Enable auto-reload in development",
    )  # fmt: skip
    sql_log: bool = Field(
        default=False,
        description="Enable SQL query logging",
    )  # fmt: skip
    database_url: str | None = Field(
        default=None,
        description="Database connection string",
    )  # fmt: skip
    check_only: bool = Field(
        default=False,
        description="Run readiness checks only, then exit (without starting server)",
    )  # fmt: skip
    profiles: str | None = Field(
        default=None,
        description="Server profiles: rest, graphql, or comma-separated combination. Empty/None enables all.",
    )  # fmt: skip

    # Cache store
    cache_store: str | None = Field(
        default=None,
        description=(
            "Cache store URL for DISTRIBUTED and NEAR_CACHE modes. "
            "When not set, only LOCAL and REPLICATED modes are available. "
            "Example: redis://localhost:6379/0"
        ),
    )  # fmt: skip

    # Messaging
    message_broker: str | None = Field(
        default=None,
        description=(
            "Broker URL for internal event delivery. "
            "When not set, defaults to PgChannel derived from DATABASE_URL using message_channel as the channel name. "
            "Format: <scheme>://<host>?<params>. "
            "Examples: "
            "postgres+listen://?channel=my_channel (reuse DATABASE_URL, custom channel name), "
            "postgres://user:pass@host:5432/db?channel=my_channel (explicit DSN for pooler setups), "
            "memory:// (in-process only, no cross-process delivery). "
            "When MESSAGE_BROKER includes a ?channel= parameter, it takes precedence over message_channel."
        ),
    )  # fmt: skip
    message_channel: str = Field(
        default="sonnet_internal",
        description=(
            "Default Postgres NOTIFY channel name for the auto-derived PgChannel. "
            "Only used when MESSAGE_BROKER is not set. "
            "Consumers typically override this with a project-specific name "
            "(e.g. atlas_internal, cgdb_internal)."
        ),
    )  # fmt: skip

    @field_validator("log_level", mode="before")
    @classmethod
    def validate_log_level(cls, v: str | None) -> str:
        """Normalize and validate log level."""
        if v is None:
            return "INFO"

        # Normalize to uppercase
        v_upper = str(v).upper()

        # Validate against allowed values
        allowed = {"TRACE", "DEBUG", "INFO", "WARNING", "ERROR"}
        if v_upper not in allowed:
            raise ValueError(f"Invalid log level: {v}. Must be one of: {', '.join(sorted(allowed))}")

        return v_upper

    model_config = SettingsConfigDict(
        env_prefix="SONNET_SERVER_",  # Prefix for env vars
        case_sensitive=False,
        extra="ignore",  # Ignore unexpected env vars
        env_file=".env",  # Optional .env loading (if present)
        env_file_encoding="utf-8",
    )


_settings: Settings | None = None


def get_settings() -> Settings:
    """Return the active settings instance.

    If a consumer has called ``init_settings()`` with a subclass instance,
    that instance is returned. Otherwise a default ``Settings()`` with the
    ``SONNET_SERVER_`` prefix is created on first access -- correct for
    standalone usage and tests, but consumer projects should always call
    ``init_settings()`` explicitly.
    """
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def init_settings(settings: Settings) -> None:
    """Initialize the global settings with a consumer-provided instance.

    Consumer projects subclass ``Settings`` with their own env prefix and
    project-specific fields, then call this function at the bottom of
    their ``settings.py`` module -- at import time, before any
    sonnet-server infrastructure code (extensions, database, messaging,
    etc.) reads settings.

    This is the canonical way for consumers to wire their configuration::

        # my_app/settings.py
        from sonnet_server.settings import Settings as SonnetSettings, init_settings

        class Settings(SonnetSettings):
            model_config = SettingsConfigDict(env_prefix="MY_APP_", ...)

        @lru_cache
        def get_settings() -> Settings:
            return Settings()

        init_settings(get_settings())  # module-level registration

    Safe to call multiple times (e.g. on dev-server hot-reload). Each
    call replaces the previous instance.

    Args:
        settings: A ``Settings`` (sub)class instance.
    """
    global _settings
    _settings = settings


def reset_settings() -> None:
    """Reset the global settings to uninitialized state.

    Intended for test teardown only.
    """
    global _settings
    _settings = None


__all__ = ["Settings", "get_settings", "init_settings", "reset_settings"]
