"""Global exception handlers for the FastAPI application.

This module contains custom exception handlers that convert
application exceptions into proper HTTP responses.
"""

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from loguru import logger
from sqlalchemy.exc import OperationalError, SQLAlchemyError

from sonnet_server.exceptions import (
    InvalidStatusTransitionError,
    ResourceNotFoundError,
    SealedResourceError,
    VersionConflictError,
)


async def version_conflict_handler(request: Request, exc: VersionConflictError) -> JSONResponse:
    """Handle optimistic locking conflicts.

    Returns HTTP 409 Conflict when a resource was modified by another client
    between read and update.
    """
    logger.warning("Version conflict on {}: {}", request.url.path, exc)
    return JSONResponse(
        status_code=409,
        content={
            "error": "version_conflict",
            "message": str(exc),
            "detail": {
                "expected_version": exc.expected_version,
                "current_version": exc.current_version,
            },
        },
    )


async def resource_not_found_handler(request: Request, exc: ResourceNotFoundError) -> JSONResponse:
    """Handle missing resource lookups.

    Returns HTTP 404 Not Found when a requested resource does not exist.
    """
    logger.warning("Resource not found on {}: {}", request.url.path, exc)
    return JSONResponse(
        status_code=404,
        content={
            "error": "not_found",
            "message": str(exc),
            "detail": {
                "resource_type": exc.resource_type,
                "identifier": str(exc.identifier),
            },
        },
    )


async def invalid_status_transition_handler(request: Request, exc: InvalidStatusTransitionError) -> JSONResponse:
    """Handle invalid status transition attempts.

    Returns HTTP 409 Conflict when a status transition is not permitted
    given the resource's current state.
    """
    logger.warning("Invalid status transition on {}: {}", request.url.path, exc)
    return JSONResponse(
        status_code=409,
        content={
            "error": "invalid_status_transition",
            "message": str(exc),
            "detail": {
                "resource_type": exc.resource_type,
                "identifier": str(exc.identifier),
                "current_status": exc.current,
                "requested_status": exc.requested,
            },
        },
    )


async def sealed_resource_handler(request: Request, exc: SealedResourceError) -> JSONResponse:
    """Handle write attempts on sealed (system-protected) records.

    Returns HTTP 409 Conflict. Sealed records can be read but not modified
    or deleted through the API.
    """
    logger.warning("Write attempt on sealed resource on {}: {}", request.url.path, exc)
    return JSONResponse(
        status_code=409,
        content={
            "error": "sealed_resource",
            "message": str(exc),
            "detail": {
                "resource_type": exc.resource_type,
                "identifier": exc.identifier,
            },
        },
    )


async def operational_error_handler(request: Request, exc: OperationalError) -> JSONResponse:
    """Handle database connectivity failures.

    OperationalError covers connection drops, timeouts, and pool exhaustion --
    transient infrastructure failures that the client can retry. Returns 503
    rather than 500 so upstream load balancers and clients can distinguish
    a code bug from a database outage.
    """
    logger.error("Database connectivity error on {}: {}", request.url.path, exc)
    return JSONResponse(
        status_code=503,
        content={
            "error": "database_unavailable",
            "message": "Database is temporarily unavailable. Please retry.",
        },
    )


async def sqlalchemy_error_handler(request: Request, exc: SQLAlchemyError) -> JSONResponse:
    """Handle unexpected database errors that are not connectivity failures.

    SQLAlchemyError (excluding OperationalError, which is registered separately
    and takes priority) covers constraint violations, type errors, and query
    errors. These indicate a bug or bad input rather than infrastructure failure
    and map to 500.
    """
    logger.error("Unexpected database error on {}: {}", request.url.path, exc)
    return JSONResponse(
        status_code=500,
        content={
            "error": "database_error",
            "message": "An unexpected database error occurred.",
        },
    )


def register_exception_handlers(app: FastAPI) -> None:
    """Register all custom exception handlers with the FastAPI app.

    Args:
        app: The FastAPI application instance
    """
    app.add_exception_handler(VersionConflictError, version_conflict_handler)
    app.add_exception_handler(ResourceNotFoundError, resource_not_found_handler)
    app.add_exception_handler(InvalidStatusTransitionError, invalid_status_transition_handler)
    app.add_exception_handler(SealedResourceError, sealed_resource_handler)
    # Starlette looks up handlers by exact type first, then walks the MRO of
    # the raised exception. OperationalError (subclass of SQLAlchemyError) gets
    # 503; all other SQLAlchemyError subclasses fall through to the base handler
    # and get 500.
    app.add_exception_handler(OperationalError, operational_error_handler)
    app.add_exception_handler(SQLAlchemyError, sqlalchemy_error_handler)
    logger.debug("Registered exception handlers")
