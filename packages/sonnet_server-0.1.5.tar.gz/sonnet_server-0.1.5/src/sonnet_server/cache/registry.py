"""Cache registry and @cache decorator.

The ``CacheRegistry`` owns the lifecycle of all caches: class
registration at import time, lazy singleton instantiation on first
access, admin introspection, and test teardown.

The ``@cache`` decorator registers ``ManagedCache`` subclasses with
the global registry -- same pattern as ``@handles`` for event handlers.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Any, TypeVar, overload

from loguru import logger

from sonnet_server.cache.config import CacheConfig, CacheStats

T = TypeVar("T")

# Attribute set on decorated classes for inspection
_CACHE_ATTR = "__cache_registered__"


class _CacheEntry:
    """Internal bookkeeping for a registered cache class."""

    __slots__ = ("cls", "config_overrides", "instance")

    def __init__(self, cls: type, config_overrides: dict[str, Any]) -> None:
        self.cls = cls
        self.config_overrides = config_overrides
        self.instance: Any | None = None


class CacheRegistry:
    """Central registry that owns the lifecycle of all managed caches.

    - **Import time**: ``@cache`` registers classes via ``register_class()``.
    - **Runtime**: ``get()`` returns the singleton instance, creating it
      lazily on first access.
    - **Introspection**: ``configs()`` and ``stats()`` for the admin endpoint.
    - **Testing**: ``clear()`` resets all state between test runs.
    """

    def __init__(self) -> None:
        self._by_class: dict[type, _CacheEntry] = {}
        self._by_name: dict[str, _CacheEntry] = {}

    def register_class(self, cls: type, **overrides: Any) -> None:
        """Register a ``ManagedCache`` subclass. Called by ``@cache`` at import time.

        Does not create the instance -- that happens on first ``get()`` call.

        Raises:
            ValueError: If a cache with the same name is already registered.
        """
        # Resolve the name from overrides or class attribute
        name = overrides.get("name") or getattr(cls, "name", "")
        if not name:
            raise ValueError(f"Cache class {cls.__name__} must define a 'name' attribute")
        if name in self._by_name:
            existing = self._by_name[name]
            raise ValueError(f"Cache name '{name}' is already registered by {existing.cls.__name__}")

        entry = _CacheEntry(cls, overrides)
        self._by_class[cls] = entry
        self._by_name[name] = entry
        logger.trace("Cache registered: {} (class={})", name, cls.__name__)

    def register_instance(self, instance: Any) -> None:
        """Register a pre-built ``ManagedCache`` instance (programmatic use).

        Raises:
            ValueError: If a cache with the same name is already registered.
        """
        name = instance.config.name
        if name in self._by_name:
            raise ValueError(f"Cache name '{name}' is already registered")

        entry = _CacheEntry(type(instance), {})
        entry.instance = instance
        self._by_class[type(instance)] = entry
        self._by_name[name] = entry
        logger.trace("Cache instance registered: {}", name)

    @overload
    def get(self, key: type[T]) -> T: ...

    @overload
    def get(self, key: str) -> Any: ...

    def get(self, key: type | str) -> Any:
        """Return the singleton cache instance, creating it lazily on first access.

        Args:
            key: Cache class (type-safe, preferred in service code) or
                 cache name string (for admin API and invalidation listener).

        Returns:
            The ``ManagedCache`` instance, or ``None`` if not registered.
        """
        entry = self._by_name.get(key) if isinstance(key, str) else self._by_class.get(key)

        if entry is None:
            return None

        if entry.instance is None:
            entry.instance = self._create_instance(entry)

        return entry.instance

    def all(self) -> list[Any]:
        """Return all instantiated cache instances."""
        return [e.instance for e in self._by_name.values() if e.instance is not None]

    def names(self) -> list[str]:
        """Return all registered cache names (including not-yet-instantiated)."""
        return list(self._by_name.keys())

    def configs(self) -> list[CacheConfig]:
        """Return configs for all registered caches (including not-yet-instantiated).

        For caches not yet instantiated, builds the config from class
        attributes and decorator overrides without creating the instance.
        """
        result = []
        for entry in self._by_name.values():
            if entry.instance is not None:
                result.append(entry.instance.config)
            else:
                result.append(self._build_config(entry))
        return result

    def stats(self) -> list[CacheStats]:
        """Return stats for all instantiated caches."""
        return [e.instance.stats for e in self._by_name.values() if e.instance is not None]

    def clear(self) -> None:
        """Remove all registrations and instances. For test teardown."""
        self._by_class.clear()
        self._by_name.clear()

    @property
    def size(self) -> int:
        """Number of registered caches (including not-yet-instantiated)."""
        return len(self._by_name)

    def _create_instance(self, entry: _CacheEntry) -> Any:
        """Create a cache instance from a registered class + overrides."""
        config = self._build_config(entry)
        instance = entry.cls(config=config)
        logger.trace("Cache instantiated: {} (class={})", config.name, entry.cls.__name__)
        return instance

    def _build_config(self, entry: _CacheEntry) -> CacheConfig:
        """Build CacheConfig from class attributes + decorator overrides."""
        cls = entry.cls
        overrides = entry.config_overrides
        return CacheConfig(
            name=overrides.get("name") or cls.name,
            maxsize=overrides.get("maxsize", cls.maxsize),
            ttl=overrides.get("ttl", cls.ttl),
            mode=overrides.get("mode", cls.mode),
        )


@lru_cache
def get_cache_registry() -> CacheRegistry:
    """Get or create the singleton CacheRegistry instance.

    Returns:
        The CacheRegistry instance.
    """
    return CacheRegistry()


# -- @cache decorator --


def cache(_cls: type | None = None, **overrides: Any):
    """Decorator that registers a ``ManagedCache`` subclass with the ``CacheRegistry``.

    Can be used bare or with config overrides::

        @cache
        class MyCache(ManagedCache[str, str]):
            name = "my_cache"
            ...

        @cache(maxsize=1024, ttl=600)
        class MyCache(ManagedCache[str, str]):
            name = "my_cache"
            ...

    Annotation values override class attributes.
    """

    def decorator(cls: type) -> type:
        get_cache_registry().register_class(cls, **overrides)
        setattr(cls, _CACHE_ATTR, True)
        return cls

    if _cls is not None:
        # Bare @cache (no parentheses)
        return decorator(_cls)
    # @cache(...) with arguments
    return decorator
