"""Cache system endpoints.

System-level routes for cache introspection and operational control.
Mounted alongside ``/ping``, ``/health-check``, ``/messaging/ping``.

Includes a built-in ``PingCache`` for operational verification:
``GET /cache/ping`` performs a put-get-invalidate round-trip and returns
pass/fail without depending on domain-specific code paths.
"""

from __future__ import annotations

from typing import Literal

import arrow
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from sonnet_server.cache.backends import MISSING
from sonnet_server.cache.cache import ManagedCache
from sonnet_server.cache.config import CacheConfig, CacheMode, CacheStats
from sonnet_server.cache.registry import cache, get_cache_registry

router = APIRouter(tags=["System"])


# -- Built-in test cache for operational verification -----------------------


@cache
class PingCache(ManagedCache[str, str]):
    """Built-in test cache for operational verification.

    Always registered. Used by ``GET /cache/ping`` to verify the cache
    infrastructure is working end-to-end (put, get, invalidate).
    Not used by any domain code.
    """

    name = "_ping"
    maxsize = 4
    ttl = 60
    mode = CacheMode.LOCAL  # no cross-process sync needed for a self-test


class CacheListResponse(BaseModel):
    """Response for GET /cache."""

    caches: list[CacheStats]


class CacheConfigListResponse(BaseModel):
    """Response for GET /cache/configs (includes not-yet-instantiated)."""

    configs: list[CacheConfig]


@router.get("/cache", response_model=CacheListResponse)
async def list_caches() -> CacheListResponse:
    """List all registered caches with runtime statistics.

    Returns stats for all instantiated caches. Caches that have been
    registered but never accessed are not included (they have no
    runtime stats yet). Use GET /cache/configs to see all registered
    caches including not-yet-instantiated ones.
    """
    return CacheListResponse(caches=get_cache_registry().stats())


@router.get("/cache/configs", response_model=CacheConfigListResponse)
async def list_cache_configs() -> CacheConfigListResponse:
    """List configuration for all registered caches.

    Includes caches that have not been instantiated yet. Useful for
    verifying which caches are registered without forcing instantiation.
    """
    return CacheConfigListResponse(configs=get_cache_registry().configs())


class CachePingResponse(BaseModel):
    """Response for GET /cache/ping."""

    status: Literal["ok", "fail"]
    detail: str
    timestamp: str


@router.get("/cache/ping", response_model=CachePingResponse)
async def ping_cache() -> CachePingResponse:
    """Verify cache infrastructure with a put-get-invalidate round-trip.

    Uses the built-in ``PingCache`` to test the full cache lifecycle
    without depending on domain caches or DB access. Returns 200 with
    ``status: "ok"`` on success, ``status: "fail"`` with detail on failure.
    """
    timestamp = arrow.utcnow().isoformat()
    ping = get_cache_registry().get(PingCache)
    if ping is None:
        return CachePingResponse(status="fail", detail="PingCache not registered", timestamp=timestamp)

    test_key = "_ping"
    test_value = timestamp

    try:
        # put
        ping.put(test_key, test_value)

        # get
        result = ping.get(test_key)
        if result is MISSING or result != test_value:
            return CachePingResponse(
                status="fail", detail=f"get returned {result!r}, expected {test_value!r}", timestamp=timestamp
            )

        # invalidate
        ping.invalidate(test_key)
        after = ping.get(test_key)
        if after is not MISSING:
            return CachePingResponse(status="fail", detail="invalidate did not evict entry", timestamp=timestamp)

        return CachePingResponse(status="ok", detail="put-get-invalidate round-trip passed", timestamp=timestamp)

    except (ValueError, RuntimeError, AttributeError, LookupError) as e:
        return CachePingResponse(status="fail", detail=str(e), timestamp=timestamp)


# Static path /cache/invalidate must be registered before the
# parameterized /cache/{name} routes to take priority in routing.
@router.post("/cache/invalidate", status_code=204)
async def invalidate_all_caches() -> None:
    """Clear all entries in all registered caches.

    Only affects instantiated caches. Caches that have never been
    accessed are skipped (they have no entries to clear).
    """
    for managed_cache in get_cache_registry().all():
        managed_cache.invalidate_all()


@router.post("/cache/{name}/expire", status_code=200)
async def expire_cache(name: str) -> dict:
    """Remove TTL-expired entries from a named cache.

    Non-expired entries are kept. Only affects local/L1 storage --
    distributed backends (Redis) handle TTL expiration server-side.
    Returns 404 if the cache name is not registered.
    Returns the number of expired entries removed.
    """
    registry = get_cache_registry()
    managed_cache = registry.get(name)
    if managed_cache is None:
        raise HTTPException(status_code=404, detail=f"Cache '{name}' not found")
    return {"expired": managed_cache.expire()}


@router.post("/cache/expire", status_code=200)
async def expire_all_caches() -> dict:
    """Remove TTL-expired entries from all instantiated caches.

    Non-expired entries are kept. Only affects local/L1 storage --
    distributed backends (Redis) handle TTL expiration server-side.
    Returns the total number of expired entries removed.
    """
    total = 0
    for managed_cache in get_cache_registry().all():
        total += managed_cache.expire()
    return {"expired": total}


@router.get("/cache/{name}", response_model=CacheStats)
async def get_cache_detail(name: str) -> CacheStats:
    """Get stats for a single cache by name.

    Instantiates the cache on first access if it has not been used yet.
    Returns 404 if the cache name is not registered.
    """
    registry = get_cache_registry()
    managed_cache = registry.get(name)
    if managed_cache is None:
        raise HTTPException(status_code=404, detail=f"Cache '{name}' not found")
    return managed_cache.stats


@router.post("/cache/{name}/invalidate", status_code=204)
async def invalidate_cache(name: str) -> None:
    """Clear all entries in a named cache.

    Returns 404 if the cache name is not registered. Cross-process
    invalidation happens automatically via the messaging transport
    for caches in ``REPLICATED`` or ``NEAR_CACHE`` mode.
    """
    registry = get_cache_registry()
    managed_cache = registry.get(name)
    if managed_cache is None:
        raise HTTPException(status_code=404, detail=f"Cache '{name}' not found")
    managed_cache.invalidate_all()
