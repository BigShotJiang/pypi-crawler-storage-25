"""Cache extension -- contributes cache management routes and activates checks.

The cache subsystem is lazy by design: caches are registered at import
time via the @cache decorator and instantiated on first access. This
extension contributes the /cache/* system routes. The cache readiness
check is only registered when a distributed cache store is configured
(``cache_store`` setting), since local-only mode requires no external
reachability check.

See ``checks/__init__.py`` for the stage registration ownership model.
All deferred imports follow the convention documented in ``extensions.py``.
"""

from __future__ import annotations

from fastapi import APIRouter
from loguru import logger

from sonnet_server.extensions import Extension
from sonnet_server.settings import Settings


class CacheExtension(Extension):
    """Cache subsystem route contribution and check activation."""

    @property
    def name(self) -> str:
        return "cache"

    async def on_startup(self, settings: Settings) -> None:
        if settings.cache_store:
            # Import check module to trigger @readiness_check decorator registration.
            # Stage classes are already registered by checks/__init__.py.
            import sonnet_server.checks.cache_store_check  # noqa: F401

            logger.info("CacheExtension: distributed cache store configured")
        else:
            logger.debug("CacheExtension: local-only mode (no CACHE_STORE)")

    def routers(self) -> list[APIRouter]:
        from sonnet_server.cache.api import router as cache_router

        return [cache_router]
