"""ManagedCache -- generic base class for declarative caching.

Subclass this to define a cache. Declare configuration via class
attributes, optionally override ``load()`` / ``aload()`` for read-through
caching. Register with ``@cache`` decorator. Access via ``CacheRegistry``.

## Sync vs async API

``LOCAL`` and ``REPLICATED`` modes use ``LocalBackend`` (in-process dict)
and expose a **synchronous** API: ``get``, ``get_or_load``, ``put``,
``invalidate``, ``invalidate_all``.

``DISTRIBUTED`` and ``NEAR_CACHE`` modes use async backends (Redis) and
expose an **async** API: ``aget``, ``aget_or_load``, ``aput``,
``ainvalidate``, ``ainvalidate_all``. These methods are also available on
sync-mode caches (they delegate to the local backend) so consumers can
use the async API uniformly if preferred.

See ``server/docs/design/managed-cache.md`` for full design.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Generic, TypeVar

from loguru import logger

from sonnet_server.cache.backends import MISSING, MissingSentinel
from sonnet_server.cache.backends.local import LocalBackend
from sonnet_server.cache.config import CacheConfig, CacheMode, CacheStats
from sonnet_server.cache.serialization import serialize_key

K = TypeVar("K")
V = TypeVar("V")

_ASYNC_MODES = frozenset({CacheMode.DISTRIBUTED, CacheMode.NEAR_CACHE})


def _create_backend(config: CacheConfig):
    """Instantiate the correct backend for a given cache mode."""
    match config.mode:
        case CacheMode.LOCAL | CacheMode.REPLICATED:
            return LocalBackend(maxsize=config.maxsize, ttl=config.ttl)
        case CacheMode.DISTRIBUTED:
            from sonnet_server.cache.backends.distributed import DistributedBackend

            return DistributedBackend(cache_name=config.name, ttl=config.ttl, maxsize=config.maxsize)
        case CacheMode.NEAR_CACHE:
            from sonnet_server.cache.backends.distributed import DistributedBackend
            from sonnet_server.cache.backends.near_cache import NearCacheBackend

            return NearCacheBackend(
                l1=LocalBackend(maxsize=config.maxsize, ttl=config.ttl),
                l2=DistributedBackend(cache_name=config.name, ttl=config.ttl, maxsize=config.maxsize),
            )


class ManagedCache(Generic[K, V]):
    """Generic cache with read-through, invalidation, and introspection.

    **Declarative usage** (recommended)::

        @cache
        class ActionCache(ManagedCache[str, str | None]):
            name = "audit_event_actions"
            maxsize = 256
            ttl = 300
            mode = CacheMode.REPLICATED

            def load(self, action: str) -> str | None:
                ...

    **Programmatic usage**::

        mc = ManagedCache(config=CacheConfig(name="dynamic", maxsize=64, ttl=120))
        mc.put("key", "value")

    The ``CacheRegistry`` manages singleton instances for declarative
    caches. Direct construction is for dynamic or test caches.

    Note on concurrent access: ``get_or_load`` / ``aget_or_load`` do not
    guard against duplicate ``load()`` calls from concurrent coroutines
    that both observe a miss before either stores the result. Under the
    single asyncio event loop this is safe (no data corruption) but may
    cause redundant DB queries. For caches where ``load()`` is expensive
    and concurrent misses are likely, an asyncio.Lock per key can be
    added in a future revision.
    """

    # -- Class attributes (override in subclass) --
    name: str = ""
    maxsize: int = 512
    ttl: int = 300
    mode: CacheMode = CacheMode.REPLICATED

    def __init__(
        self,
        config: CacheConfig | None = None,
        backend=None,
    ) -> None:
        if config is not None:
            self._config = config
        else:
            if not self.name:
                raise ValueError(f"{type(self).__name__} must define a 'name' class attribute")
            self._config = CacheConfig(
                name=self.name,
                maxsize=self.maxsize,
                ttl=self.ttl,
                mode=self.mode,
            )

        self._backend = backend or _create_backend(self._config)

        # Counters (process-local, reset on restart)
        self._hits: int = 0
        self._misses: int = 0
        self._invalidations: int = 0

    @property
    def _is_async(self) -> bool:
        return self._config.mode in _ASYNC_MODES

    # -- Optional overrides --

    def load(self, key: K) -> V:
        """Override for sync read-through (LOCAL / REPLICATED mode).

        Called on cache miss by ``get_or_load()``. If not overridden,
        ``get_or_load()`` raises ``NotImplementedError``.
        """
        raise NotImplementedError(f"{type(self).__name__} does not implement load() -- use get() + put() instead")

    async def aload(self, key: K) -> V:
        """Override for async read-through (DISTRIBUTED / NEAR_CACHE mode).

        Called on cache miss by ``aget_or_load()``. Default delegates to
        ``load()`` so sync implementations work with the async API.
        """
        return self.load(key)

    # -- Sync read/write (LOCAL / REPLICATED) --

    def get(self, key: K) -> V | MissingSentinel:
        """Check backend only. Return cached value or ``MISSING`` on miss.

        For LOCAL / REPLICATED mode only. Use ``aget`` for async modes.
        """
        result = self._backend.get(key)
        if result is MISSING:
            self._misses += 1
        else:
            self._hits += 1
        return result

    def get_or_load(self, key: K) -> V:
        """Sync read-through: check backend, call ``load()`` on miss.

        For LOCAL / REPLICATED mode only. Use ``aget_or_load`` for async modes.
        Raises ``NotImplementedError`` if ``load()`` is not overridden.
        """
        result = self._backend.get(key)
        if result is not MISSING:
            self._hits += 1
            return result  # type: ignore[return-value]

        value = self.load(key)
        self._backend.put(key, value)
        self._misses += 1
        return value

    def put(self, key: K, value: V) -> None:
        """Store a value directly (sync). For LOCAL / REPLICATED mode."""
        self._backend.put(key, value)

    # -- Async read/write (DISTRIBUTED / NEAR_CACHE) --

    async def aget(self, key: K) -> V | MissingSentinel:
        """Check backend only (async). Return cached value or ``MISSING``."""
        result = await self._backend.get(key) if self._is_async else self._backend.get(key)
        if result is MISSING:
            self._misses += 1
        else:
            self._hits += 1
        return result

    async def aget_or_load(self, key: K) -> V:
        """Async read-through: check backend, call ``aload()`` on miss.

        Works for all modes. Raises ``NotImplementedError`` if ``load()``
        / ``aload()`` is not overridden.
        """
        result = await self._backend.get(key) if self._is_async else self._backend.get(key)
        if result is not MISSING:
            self._hits += 1
            return result  # type: ignore[return-value]

        value = await self.aload(key)
        if self._is_async:
            await self._backend.put(key, value)
        else:
            self._backend.put(key, value)
        self._misses += 1
        return value

    async def aput(self, key: K, value: V) -> None:
        """Store a value directly (async). Works for all modes."""
        if self._is_async:
            await self._backend.put(key, value)
        else:
            self._backend.put(key, value)

    # -- Sync invalidation (LOCAL / REPLICATED) --

    def invalidate(self, key: K) -> None:
        """Evict a single entry (sync) and emit cross-process event if sync mode."""
        deleted = self._backend.delete(key)
        if deleted:
            self._invalidations += 1
        if self._config.sync:
            self._emit_invalidation(key=key)

    def invalidate_by(self, predicate: Callable[[K], bool]) -> int:
        """Evict all entries matching predicate (sync). Emit full-clear event."""
        count = self._backend.delete_by(predicate)
        self._invalidations += count
        if self._config.sync and count > 0:
            self._emit_invalidation(key=None)
        return count

    def invalidate_all(self) -> int:
        """Clear all entries (sync) and emit cross-process event if sync mode."""
        count = self._backend.clear()
        if count > 0:
            self._invalidations += count
        if self._config.sync:
            self._emit_invalidation(key=None)
        return count

    # -- Async invalidation (DISTRIBUTED / NEAR_CACHE) --

    async def ainvalidate(self, key: K) -> None:
        """Evict a single entry (async) and emit cross-process event."""
        deleted = await self._backend.delete(key) if self._is_async else self._backend.delete(key)
        if deleted:
            self._invalidations += 1
        if self._config.sync:
            self._emit_invalidation(key=key)

    async def ainvalidate_all(self) -> int:
        """Clear all entries (async) and emit cross-process event."""
        count = await self._backend.clear() if self._is_async else self._backend.clear()
        if count > 0:
            self._invalidations += count
        if self._config.sync:
            self._emit_invalidation(key=None)
        return count

    # -- Internal eviction (called by listener, no event emission) --

    def evict(self, key: K) -> None:
        """Evict a single entry without emitting events. Used by invalidation listener.

        For NEAR_CACHE mode, evicts from L1 only (L2 is authoritative).
        All backends implement ``evict_local`` uniformly.
        """
        deleted = self._backend.evict_local(key)
        if deleted:
            self._invalidations += 1

    def evict_all(self) -> None:
        """Clear all entries without emitting events. Used by invalidation listener.

        For NEAR_CACHE mode, clears L1 only (L2 is authoritative).
        All backends implement ``evict_local_all`` uniformly.
        """
        count = self._backend.evict_local_all()
        if count > 0:
            self._invalidations += count

    # -- Expiration --

    def expire(self) -> int:
        """Remove only TTL-expired entries from local storage.

        Non-expired entries are kept. For ``NEAR_CACHE`` mode, expires L1
        only. For ``DISTRIBUTED`` mode, this is a no-op (Redis handles TTL
        server-side). Returns count of removed entries.
        """
        if hasattr(self._backend, "expire"):
            return self._backend.expire()
        return 0

    # -- Introspection --

    @property
    def config(self) -> CacheConfig:
        return self._config

    @property
    def size(self) -> int:
        """Current number of entries.

        For ``DISTRIBUTED`` mode, returns 0 (size requires async Redis SCAN
        -- use ``aget_size()`` for an accurate count).
        For ``NEAR_CACHE`` mode, returns the L1 (local) size only.
        All backends implement ``__len__`` for the sync path.
        """
        return len(self._backend)

    async def aget_size(self) -> int:
        """Async size for DISTRIBUTED / NEAR_CACHE mode."""
        if self._is_async:
            return await self._backend.len()
        return len(self._backend)

    @property
    def stats(self) -> CacheStats:
        return CacheStats(
            config=self._config,
            size=self.size,
            hits=self._hits,
            misses=self._misses,
            invalidations=self._invalidations,
        )

    # -- Cross-process invalidation --

    def _emit_invalidation(self, key: K | None) -> None:
        """Emit a CacheInvalidated event via the message router.

        Best-effort: if the router is unavailable (e.g. during startup or
        in tests without a configured channel), the error is logged at DEBUG
        and the local eviction already performed is the authoritative action.
        TTL expiry is the safety net for other processes.
        """
        try:
            from sonnet_server.cache.events import CacheInvalidated
            from sonnet_server.messaging import get_message_router

            event = CacheInvalidated(
                cache_name=self._config.name,
                key=serialize_key(key) if key is not None else None,
                scope="key" if key is not None else "all",
            )
            get_message_router().emit(event)
        except (RuntimeError, AttributeError, LookupError) as e:
            logger.debug("Failed to emit CacheInvalidated for '{}': {}", self._config.name, e)

    def __repr__(self) -> str:
        return f"<{type(self).__name__} name={self._config.name!r} size={self.size}/{self._config.maxsize}>"
