"""Cache invalidation event.

A single event type for all managed caches. Replaces per-module
invalidation events for cache purposes. Delivered via the configured
messaging transport for cross-process cache coherence.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, model_validator


class CacheInvalidated(BaseModel):
    """Emitted when a managed cache entry is invalidated.

    Carries enough context for the generic listener to dispatch
    eviction to the correct cache by name.

    Invariant: ``key`` is set iff ``scope == "key"``.

    Attributes:
        cache_name: Name of the cache (matches ``CacheConfig.name``).
        key: JSON-serialized key for single-entry eviction, or ``None``
            for full-clear.
        scope: ``"key"`` for single entry, ``"all"`` for full clear.
    """

    cache_name: str
    key: str | None = None
    scope: Literal["key", "all"] = "key"

    @model_validator(mode="after")
    def _validate_key_scope_consistent(self) -> CacheInvalidated:
        if (self.scope == "key") != (self.key is not None):
            raise ValueError("'key' must be set when scope='key' and None when scope='all'")
        return self
