"""Shared serialization utilities for cache keys and values.

Used by both the ``DistributedBackend`` (Redis key/value encoding) and
the cache invalidation listener (key deserialization from events).
"""

from __future__ import annotations

import json
from typing import Any


def serialize_key(key: object) -> str:
    """Serialize a cache key to JSON string.

    Keys must be JSON-primitive types: str, int, float, None, or tuples
    of primitives (serialized as JSON arrays).

    Raises ``TypeError`` if the key is not JSON-serializable.
    """
    return json.dumps(key)


def deserialize_key(serialized: str) -> object:
    """Deserialize a JSON-encoded cache key.

    JSON arrays are recursively converted to tuples so composite keys
    (e.g. ``(owner_id, scope_id)``) round-trip correctly and remain
    hashable for use as dict keys.
    """
    return _lists_to_tuples(json.loads(serialized))


def serialize_value(value: object) -> str:
    """Serialize a cache value to JSON string for Redis storage.

    Values must be JSON-serializable. Pydantic models should be converted
    to dicts via ``model_dump(mode="json")`` before caching, or the cache's
    ``load()`` method should return JSON-native types.

    Raises ``TypeError`` if the value is not JSON-serializable.
    """
    return json.dumps(value)


def deserialize_value(raw: bytes | str) -> Any:
    """Deserialize a JSON value from Redis."""
    return json.loads(raw)


def _lists_to_tuples(value: object) -> object:
    """Recursively convert JSON arrays (lists) to tuples.

    Required because JSON has no tuple type -- tuples are serialized as
    arrays and must be converted back to tuples for use as hashable
    cache keys.
    """
    if isinstance(value, list):
        return tuple(_lists_to_tuples(item) for item in value)
    return value
