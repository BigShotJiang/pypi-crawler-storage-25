"""Generic cache invalidation listener.

One listener handles all cache invalidation events. Dispatches to
the correct cache via the ``CacheRegistry`` by name. Safe for partial
deployments where not all caches are present in every process.
"""

from __future__ import annotations

from loguru import logger

from sonnet_server.cache.events import CacheInvalidated
from sonnet_server.cache.registry import get_cache_registry
from sonnet_server.cache.serialization import deserialize_key
from sonnet_server.messaging.types import handles


@handles(CacheInvalidated)
async def on_cache_invalidated(event: CacheInvalidated) -> None:
    """Dispatch cache eviction based on a cross-process invalidation event.

    If the named cache is not registered in this process (partial
    deployment), silently returns. This is expected and must not log
    at WARNING or ERROR level.
    """
    cache = get_cache_registry().get(event.cache_name)
    if cache is None:
        logger.trace("Ignoring CacheInvalidated for unknown cache '{}'", event.cache_name)
        return

    if event.key is not None and event.scope == "key":
        key = deserialize_key(event.key)
        cache.evict(key)
        logger.trace("Evicted key from cache '{}' (cross-process)", event.cache_name)
    else:
        cache.evict_all()
        logger.trace("Evicted all from cache '{}' (cross-process)", event.cache_name)
