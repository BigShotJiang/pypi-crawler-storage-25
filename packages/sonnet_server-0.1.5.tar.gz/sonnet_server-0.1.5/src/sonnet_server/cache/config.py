"""Cache configuration and statistics models.

Pydantic models used for cache introspection, admin API responses,
and debug output. All models are serializable via ``model_dump()``.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, computed_field


class CacheMode(StrEnum):
    """Cache deployment mode.

    Determines the backend used and whether invalidation events are
    broadcast across process instances. Terminology follows industry
    conventions (Hazelcast, Ehcache, Infinispan).

    ``LOCAL``
        In-process TTLCache, no cross-process sync. Suitable for
        single-instance deployments or data where TTL-bounded staleness
        is acceptable. No ``CacheInvalidated`` events emitted.

    ``REPLICATED``
        In-process TTLCache with event-driven invalidation broadcast via
        the messaging transport. Each process holds its own copy; copies
        are kept coherent via ``CacheInvalidated`` events. This is the
        default for multi-instance deployments.

    ``DISTRIBUTED``
        Shared out-of-process cache (e.g. Redis, Memcached). All
        instances read and write the same store. Inherently consistent --
        no invalidation events needed. Planned for Phase 2.

    ``NEAR_CACHE``
        Two-tier: in-process L1 (fast, private) backed by a shared L2
        (authoritative). L1 evictions are broadcast via ``CacheInvalidated``
        events. Planned for Phase 2.
    """

    LOCAL = "local"
    REPLICATED = "replicated"
    DISTRIBUTED = "distributed"
    NEAR_CACHE = "near_cache"


# Modes that require CacheInvalidated event emission on invalidation
_SYNC_MODES = frozenset({CacheMode.REPLICATED, CacheMode.NEAR_CACHE})


class CacheConfig(BaseModel):
    """Immutable configuration for a single managed cache instance.

    Materialized from class attributes on a ``ManagedCache`` subclass
    (and optional ``@cache`` decorator overrides) at registration time.
    """

    model_config = ConfigDict(frozen=True)

    name: str
    """Unique identifier. Appears in events, log messages, and the cache endpoint."""

    maxsize: int = 512
    """Maximum entries before LRU eviction. For near-cache, applies to L1 only."""

    ttl: int = 300
    """Safety-net expiration in seconds."""

    mode: CacheMode = CacheMode.REPLICATED
    """Cache deployment mode. See :class:`CacheMode` for full description."""

    @property
    def sync(self) -> bool:
        """Whether this mode requires cross-process invalidation event emission."""
        return self.mode in _SYNC_MODES


class CacheStats(BaseModel):
    """Runtime statistics for a managed cache instance.

    Embeds ``CacheConfig`` so a single ``stats`` call returns both
    configuration and counters. Serializes directly to the ``/cache``
    endpoint response.

    Only constructed by ``ManagedCache.stats``; do not construct manually.
    """

    config: CacheConfig
    size: int
    hits: int = 0
    misses: int = 0
    invalidations: int = 0

    @computed_field  # type: ignore[prop-decorator]
    @property
    def hit_rate(self) -> float:
        """Fraction of reads that were cache hits. Zero when no reads have occurred."""
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0.0
