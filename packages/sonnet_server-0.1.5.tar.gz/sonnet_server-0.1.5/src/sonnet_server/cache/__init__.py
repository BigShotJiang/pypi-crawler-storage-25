"""Managed cache infrastructure.

Public surface for the cache module. Import from here::

    from sonnet_server.cache import (
        ManagedCache, cache, get_cache_registry, CacheRegistry,
        CacheConfig, CacheMode, CacheStats, CacheExtension, MISSING,
    )
"""

from sonnet_server.cache.backends import MISSING, MissingSentinel
from sonnet_server.cache.cache import ManagedCache
from sonnet_server.cache.config import CacheConfig, CacheMode, CacheStats
from sonnet_server.cache.extension import CacheExtension
from sonnet_server.cache.registry import CacheRegistry, cache, get_cache_registry

__all__ = [
    "MISSING",
    "MissingSentinel",
    "ManagedCache",
    "CacheConfig",
    "CacheMode",
    "CacheStats",
    "CacheExtension",
    "CacheRegistry",
    "cache",
    "get_cache_registry",
]
