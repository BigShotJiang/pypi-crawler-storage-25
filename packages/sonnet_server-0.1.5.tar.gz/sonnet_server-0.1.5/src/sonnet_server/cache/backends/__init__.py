"""Cache backend protocol and sentinel types.

Defines the ``CacheBackend`` protocol that all backends implement,
and the ``MISSING`` sentinel used to distinguish cache misses from
cached ``None`` values.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from enum import Enum, auto
from typing import Protocol, TypeVar, runtime_checkable

K = TypeVar("K")
V = TypeVar("V")


class MissingSentinel(Enum):
    """Sentinel type to distinguish cache miss from cached ``None``.

    Exposed as a public type so consumers can annotate variables that
    hold the result of ``ManagedCache.get()``::

        result: str | MissingSentinel = cache.get(key)
        if result is MISSING:
            ...
    """

    MISSING = auto()


MISSING = MissingSentinel.MISSING
"""Sentinel value returned by ``CacheBackend.get()`` on cache miss.

Use ``is MISSING`` to check::

    result = backend.get(key)
    if result is MISSING:
        ...  # cache miss
"""


@runtime_checkable
class CacheBackend(Protocol[K, V]):
    """Protocol for pluggable cache storage backends.

    All cache modes (``LOCAL``, ``REPLICATED``, ``DISTRIBUTED``,
    ``NEAR_CACHE``) use this protocol. The current implementation is
    ``LocalBackend`` (TTLCache wrapper), used for ``LOCAL`` and
    ``REPLICATED`` modes. Phase 2 will add a ``DistributedBackend``
    (e.g. Redis) for ``DISTRIBUTED`` and ``NEAR_CACHE`` modes.

    Implementation notes for backend authors:

    - ``maxsize`` must be a ``@property``, not a class-level attribute,
      so it reflects the actual runtime capacity.
    - ``delete_by(predicate)`` applies a Python callable to keys.
      This is straightforward for in-process backends (``LOCAL``,
      ``REPLICATED``). For remote backends (``DISTRIBUTED``), it
      requires key enumeration (e.g. Redis ``SCAN``) and may be
      costly at scale. Remote backends may choose to implement this
      as a full ``clear()`` when key enumeration is impractical.
    - ``keys()`` has the same caveat for remote backends -- returning
      all keys requires a full scan.
    """

    def get(self, key: K) -> V | MissingSentinel:
        """Return cached value or ``MISSING`` on miss."""
        ...

    def put(self, key: K, value: V) -> None:
        """Store a value."""
        ...

    def delete(self, key: K) -> bool:
        """Remove a single entry. Return True if the key existed."""
        ...

    def delete_by(self, predicate: Callable[[K], bool]) -> int:
        """Remove all entries where ``predicate(key)`` is True.

        Return count of removed entries.

        Remote backends (``DISTRIBUTED``, ``NEAR_CACHE``) may implement
        this as a full clear if key enumeration is impractical.
        """
        ...

    def clear(self) -> int:
        """Remove all entries. Return count of removed entries."""
        ...

    def keys(self) -> Iterable[K]:
        """Return all keys currently in the cache.

        Remote backends may incur a full key scan (e.g. Redis ``SCAN``).
        Avoid calling this on hot paths in ``DISTRIBUTED`` or ``NEAR_CACHE`` mode.
        """
        ...

    def __len__(self) -> int:
        """Return current number of entries."""
        ...

    @property
    def maxsize(self) -> int:
        """Return maximum capacity. Must be a property, not a class attribute.

        For ``DISTRIBUTED`` backends, ``maxsize`` reflects the configured
        limit passed to the backend constructor. The actual Redis memory
        limit is controlled separately via ``maxmemory`` policy.
        """
        ...

    def evict_local(self, key: K) -> bool:
        """Evict a single entry from local storage.

        For ``LocalBackend``: alias for ``delete()``.
        For ``DistributedBackend``: no-op (no local state).
        For ``NearCacheBackend``: evicts from L1 only.
        Used by the invalidation listener to evict without emitting events.
        """
        ...

    def evict_local_all(self) -> int:
        """Clear all entries from local storage. Return count.

        Same semantics as ``evict_local`` but for all entries.
        """
        ...
