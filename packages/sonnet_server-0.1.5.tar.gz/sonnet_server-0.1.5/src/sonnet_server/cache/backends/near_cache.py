"""Near-cache backend: in-process L1 backed by distributed L2.

Used for ``CacheMode.NEAR_CACHE``. Composes a ``LocalBackend`` (L1,
fast, private to the process) with a ``DistributedBackend`` (L2, shared
across all instances).

Read path:
    1. Check L1. On hit, return immediately.
    2. On L1 miss, check L2. On hit, populate L1 and return.
    3. On L2 miss, return ``MISSING`` (caller calls ``load()``).

Write path (put):
    Write L1 (sync, always succeeds), then L2 (async, best-effort).

L2 failure handling:
    L2 is best-effort. If Redis is unreachable, L1 still serves the cache.
    Failures are logged at DEBUG level. TTL bounds the staleness window.

All methods are async (because L2 is async). Consumers must use the async
cache API (``aget``, ``aget_or_load``, etc.).
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from typing import Generic, TypeVar

from loguru import logger

from sonnet_server.cache.backends import MISSING, MissingSentinel
from sonnet_server.cache.backends.distributed import DistributedBackend
from sonnet_server.cache.backends.local import LocalBackend

K = TypeVar("K")
V = TypeVar("V")


class NearCacheBackend(Generic[K, V]):
    """Two-tier async cache backend: LocalBackend (L1) + DistributedBackend (L2).

    L2 failures are handled gracefully -- L1 continues to serve while
    L2 is unavailable. This is the core resilience property of near-cache.
    """

    def __init__(self, l1: LocalBackend, l2: DistributedBackend) -> None:
        self._l1 = l1
        self._l2 = l2

    async def get(self, key: K) -> V | MissingSentinel:
        """Check L1 first. On miss, check L2 and populate L1."""
        result = self._l1.get(key)
        if result is not MISSING:
            return result

        try:
            result = await self._l2.get(key)
        except Exception as e:
            logger.debug("NearCache L2 get failed (degrading to L1 miss): {}", e)
            return MISSING

        if result is not MISSING:
            self._l1.put(key, result)
        return result

    async def put(self, key: K, value: V) -> None:
        """Write to L1 (always) and L2 (best-effort)."""
        self._l1.put(key, value)
        try:
            await self._l2.put(key, value)
        except Exception as e:
            logger.debug("NearCache L2 put failed (L1 has the value): {}", e)

    async def delete(self, key: K) -> bool:
        """Remove from L1 and L2 (best-effort). Return True if key existed in L1."""
        l1_deleted = self._l1.delete(key)
        try:
            await self._l2.delete(key)
        except Exception as e:
            logger.debug("NearCache L2 delete failed (L1 evicted, L2 will expire via TTL): {}", e)
        return l1_deleted

    async def delete_by(self, predicate: Callable[[K], bool]) -> int:
        """Remove matching entries from L1 and L2 (best-effort). Return L1 count."""
        l1_count = self._l1.delete_by(predicate)
        try:
            await self._l2.delete_by(predicate)
        except Exception as e:
            logger.debug("NearCache L2 delete_by failed: {}", e)
        return l1_count

    async def clear(self) -> int:
        """Clear L1 and L2 (best-effort). Return L1 count."""
        l1_count = self._l1.clear()
        try:
            await self._l2.clear()
        except Exception as e:
            logger.debug("NearCache L2 clear failed: {}", e)
        return l1_count

    async def keys(self) -> Iterable[K]:
        """Return keys from L1 (fast, local view -- L2 may have more)."""
        return self._l1.keys()

    async def len(self) -> int:
        """Return L1 size (local view)."""
        return len(self._l1)

    def __len__(self) -> int:
        """Sync len: returns L1 size."""
        return len(self._l1)

    def evict_local(self, key: K) -> bool:
        """Evict a single entry from L1 only. Used by the invalidation listener."""
        return self._l1.delete(key)

    def evict_local_all(self) -> int:
        """Clear L1 only. Used by the invalidation listener."""
        return self._l1.clear()

    def expire(self) -> int:
        """Remove TTL-expired entries from L1. L2 handles TTL server-side."""
        return self._l1.expire()

    @property
    def maxsize(self) -> int:
        """L1 maximum capacity."""
        return self._l1.maxsize
