"""Local in-process cache backend backed by cachetools.TTLCache.

Used for ``CacheMode.LOCAL`` (no cross-process sync) and
``CacheMode.REPLICATED`` (in-process + event-driven invalidation
broadcast). Also serves as the L1 tier in ``CacheMode.NEAR_CACHE``.

Provides LRU eviction at ``maxsize``, TTL expiration, and ``None``
caching via the ``MISSING`` sentinel.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from typing import Generic, TypeVar

from cachetools import TTLCache

from sonnet_server.cache.backends import MISSING, MissingSentinel

K = TypeVar("K")
V = TypeVar("V")


class LocalBackend(Generic[K, V]):
    """TTLCache wrapper implementing the ``CacheBackend`` protocol."""

    def __init__(self, maxsize: int, ttl: int) -> None:
        self._cache: TTLCache[K, V] = TTLCache(maxsize=maxsize, ttl=ttl)

    def get(self, key: K) -> V | MissingSentinel:
        """Return cached value or ``MISSING`` on miss."""
        return self._cache.get(key, MISSING)  # type: ignore[return-value]  # TTLCache.get returns V | Default

    def put(self, key: K, value: V) -> None:
        """Store a value."""
        self._cache[key] = value

    def delete(self, key: K) -> bool:
        """Remove a single entry."""
        try:
            del self._cache[key]
            return True
        except KeyError:
            return False

    def delete_by(self, predicate: Callable[[K], bool]) -> int:
        """Remove all entries where ``predicate(key)`` is True."""
        keys_to_delete = [k for k in self._cache if predicate(k)]
        for k in keys_to_delete:
            self._cache.pop(k, None)
        return len(keys_to_delete)

    def clear(self) -> int:
        """Remove all entries."""
        count = len(self._cache)
        self._cache.clear()
        return count

    def keys(self) -> Iterable[K]:
        """Return all keys currently in the cache."""
        return list(self._cache.keys())

    def __len__(self) -> int:
        return len(self._cache)

    def evict_local(self, key: K) -> bool:
        """Evict a single entry. Alias for ``delete`` -- uniform interface with ``NearCacheBackend``."""
        return self.delete(key)

    def evict_local_all(self) -> int:
        """Clear all entries. Alias for ``clear`` -- uniform interface with ``NearCacheBackend``."""
        return self.clear()

    def expire(self) -> int:
        """Remove only TTL-expired entries. Return count of removed entries.

        Non-expired entries are kept. Uses ``TTLCache.expire()`` which is
        a lazy eviction pass -- it checks timestamps and removes entries
        whose TTL has elapsed.
        """
        before = len(self._cache)
        self._cache.expire()
        return before - len(self._cache)

    @property
    def maxsize(self) -> int:
        return self._cache.maxsize
