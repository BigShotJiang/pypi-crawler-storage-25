"""Distributed cache backend backed by Redis.

Used for ``CacheMode.DISTRIBUTED`` (all instances share one store) and
as the L2 tier in ``CacheMode.NEAR_CACHE``.

All methods are async. Consumers using ``DISTRIBUTED`` or ``NEAR_CACHE``
mode must use the async cache API (``aget``, ``aget_or_load``, etc.).

Key design decisions:

- Keys are namespaced as ``{cache_name}:{serialized_key}`` to prevent
  collisions between caches sharing the same Redis instance.
- Values are JSON-serialized via ``cache.serialization``. Types must be
  JSON-native (str, int, float, bool, None, list, dict). Raises
  ``TypeError`` if non-serializable.
- TTL is enforced via Redis ``SETEX`` matching ``CacheConfig.ttl``.
- ``maxsize`` is advisory: returned by the property, but Redis memory is
  controlled globally via ``maxmemory`` policy on the Redis server.
- ``delete_by`` and ``keys()`` require full key enumeration via Redis
  ``SCAN``. O(n) in the number of keys for this cache. Avoid on hot paths
  for large caches.
- One ``Redis`` client (wrapping the shared connection pool) is held per
  ``DistributedBackend`` instance and created lazily on first use.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from functools import lru_cache
from typing import Generic, TypeVar

from loguru import logger

from sonnet_server.cache.backends import MISSING, MissingSentinel
from sonnet_server.cache.serialization import deserialize_key, deserialize_value, serialize_key, serialize_value

K = TypeVar("K")
V = TypeVar("V")

_KEY_SEP = ":"


def _make_redis_key(cache_name: str, key: object) -> str:
    """Build a namespaced Redis key: ``{cache_name}:{serialize_key(key)}``."""
    return f"{cache_name}{_KEY_SEP}{serialize_key(key)}"


def _parse_cache_key(cache_name: str, redis_key: str) -> object:
    """Extract and deserialize the cache key from a namespaced Redis key."""
    prefix = f"{cache_name}{_KEY_SEP}"
    return deserialize_key(redis_key[len(prefix) :])


@lru_cache
def get_redis_pool():
    """Get or create the singleton Redis async connection pool.

    Reads ``SONNET_SERVER_CACHE_STORE`` from settings. Raises
    ``RuntimeError`` if the setting is not configured.
    """
    import redis.asyncio as aioredis

    from sonnet_server.settings import get_settings

    url = get_settings().cache_store
    if url is None:
        raise RuntimeError(
            "SONNET_SERVER_CACHE_STORE is not configured. "
            "Set it to a Redis URL (e.g. redis://localhost:6379/0) "
            "to use DISTRIBUTED or NEAR_CACHE mode."
        )
    pool = aioredis.ConnectionPool.from_url(url, decode_responses=True)
    logger.debug("Redis connection pool created for cache store: {}", url)
    return pool


class DistributedBackend(Generic[K, V]):
    """Async Redis-backed cache backend.

    One ``Redis`` client per instance, created lazily from the shared
    connection pool. The pool manages connection lifecycle.

    Each instance is tied to one logical cache identified by ``cache_name``.
    Keys are namespaced in Redis as ``{cache_name}:{json(key)}``.
    """

    def __init__(self, cache_name: str, ttl: int, maxsize: int = 0) -> None:
        self._cache_name = cache_name
        self._ttl = ttl
        self._maxsize = maxsize
        self._client_instance = None

    def _client(self):
        """Return the lazily-created Redis client."""
        if self._client_instance is None:
            import redis.asyncio as aioredis

            self._client_instance = aioredis.Redis(connection_pool=get_redis_pool())
        return self._client_instance

    def _rkey(self, key: K) -> str:
        return _make_redis_key(self._cache_name, key)

    def _scan_pattern(self) -> str:
        return f"{self._cache_name}{_KEY_SEP}*"

    async def get(self, key: K) -> V | MissingSentinel:
        """Return cached value or ``MISSING`` on miss."""
        raw = await self._client().get(self._rkey(key))
        return MISSING if raw is None else deserialize_value(raw)

    async def put(self, key: K, value: V) -> None:
        """Store a value with TTL."""
        await self._client().setex(self._rkey(key), self._ttl, serialize_value(value))

    async def delete(self, key: K) -> bool:
        """Remove a single entry. Return True if the key existed."""
        return await self._client().delete(self._rkey(key)) > 0

    async def delete_by(self, predicate: Callable[[K], bool]) -> int:
        """Remove all entries where ``predicate(key)`` is True.

        Requires full key enumeration via Redis SCAN. O(n) in the number
        of keys for this cache.
        """
        client = self._client()
        keys_to_delete = []
        async for redis_key in client.scan_iter(match=self._scan_pattern()):
            cache_key = _parse_cache_key(self._cache_name, redis_key)
            if predicate(cache_key):  # type: ignore[arg-type]
                keys_to_delete.append(redis_key)
        if keys_to_delete:
            await client.delete(*keys_to_delete)
        return len(keys_to_delete)

    async def clear(self) -> int:
        """Remove all entries for this cache. Return count."""
        client = self._client()
        keys = [k async for k in client.scan_iter(match=self._scan_pattern())]
        if keys:
            await client.delete(*keys)
        return len(keys)

    async def keys(self) -> Iterable[K]:
        """Return all keys currently in the cache. Requires Redis SCAN."""
        result = []
        async for redis_key in self._client().scan_iter(match=self._scan_pattern()):
            result.append(_parse_cache_key(self._cache_name, redis_key))
        return result

    async def len(self) -> int:
        """Return current number of entries. Requires Redis SCAN."""
        count = 0
        async for _ in self._client().scan_iter(match=self._scan_pattern()):
            count += 1
        return count

    def __len__(self) -> int:
        """Sync len: returns 0. Use ``await backend.len()`` for actual count."""
        return 0

    def evict_local(self, key: K) -> bool:
        """No-op for distributed backend (no local state to evict). Returns False."""
        return False

    def evict_local_all(self) -> int:
        """No-op for distributed backend (no local state to evict). Returns 0."""
        return 0

    @property
    def maxsize(self) -> int:
        """Advisory maximum capacity (not enforced by Redis)."""
        return self._maxsize
