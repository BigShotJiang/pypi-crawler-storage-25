"""Common exceptions for the server.

This module contains reusable exception classes that can be used
across different services and modules.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal
from uuid import UUID

if TYPE_CHECKING:
    from sonnet_server.utils.json_schema import SchemaValidationError


class VersionConflictError(Exception):
    """Raised when optimistic locking fails due to version mismatch.

    This exception can be used by any service that implements optimistic locking
    with version numbers to prevent concurrent modification conflicts.
    """

    def __init__(self, expected_version: int, current_version: int):
        self.expected_version = expected_version
        self.current_version = current_version
        super().__init__(f"Version conflict: expected {expected_version}, current is {current_version}")


class InvalidStatusTransitionError(Exception):
    """Raised when a status transition is not permitted.

    Used when an entity's current status does not allow the requested action.
    """

    def __init__(self, resource_type: str, identifier: str | UUID | int, current: str, requested: str):
        self.resource_type = resource_type
        self.identifier = identifier
        self.current = current
        self.requested = requested
        super().__init__(f"{resource_type} '{identifier}' cannot transition from '{current}' to '{requested}'")


class ResourceNotFoundError(Exception):
    """Raised when a resource doesn't exist.

    Generic exception for any resource that cannot be found by its identifier.
    """

    def __init__(self, resource_type: str, identifier: str | UUID | int):
        self.resource_type = resource_type
        self.identifier = identifier
        super().__init__(f"{resource_type} not found: {identifier}")


class InvalidSchemaError(Exception):
    """Raised when JSON Schema validation fails.

    The ``kind`` field distinguishes two origins:

    - ``"meta"``: the schema document itself is not valid JSON Schema
      (raised by the schema registry on create/update).
    - ``"instance"``: a data payload does not conform to a registered
      schema (raised by domain services on write).

    Carries structured error details so that API handlers can return them
    in the response body.
    """

    def __init__(
        self,
        errors: list[SchemaValidationError],
        kind: Literal["meta", "instance"] = "instance",
        context: str = "Validation",
    ):
        self.errors = errors
        self.kind = kind
        count = len(errors)
        summary = errors[0].message if errors else "unknown error"
        super().__init__(f"{context} failed ({count} error(s)): {summary}")


class SealedResourceError(Exception):
    """Raised when a write operation is attempted on a sealed (system-protected) record.

    Sealed records cannot be updated, deleted, or have status transitions applied.
    They can only be read. Sealing is set by system operations (e.g. seed) and
    is independent of the record's lifecycle status.
    """

    def __init__(self, resource_type: str, identifier: str):
        self.resource_type = resource_type
        self.identifier = identifier
        super().__init__(f"{resource_type} '{identifier}' is sealed and cannot be modified")


class DuplicateResourceError(Exception):
    """Raised when a unique constraint is violated on create or update.

    Extracts the constraint name and conflicting value from the database
    IntegrityError when possible.
    """

    def __init__(self, resource_type: str, field: str | None = None, value: str | None = None):
        self.resource_type = resource_type
        self.field = field
        self.value = value
        if field and value:
            msg = f"{resource_type} with {field} '{value}' already exists"
        elif field:
            msg = f"{resource_type} with duplicate {field}"
        else:
            msg = f"Duplicate {resource_type}"
        super().__init__(msg)
