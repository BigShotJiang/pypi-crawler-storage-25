"""Global constants for the Sonnet server.

This module defines constants used throughout the application to avoid
hardcoded strings and make the codebase more maintainable.

Profile name constants are not defined here. Profile names are declared
by each profile extension (RestExtension, GraphQLExtension, etc.) and
derived dynamically from the extension registry. This allows new profiles
to be added without modifying this module.
"""

# Readiness pipeline stage names
STAGE_DATABASE = "database"
STAGE_MESSAGING = "messaging"
