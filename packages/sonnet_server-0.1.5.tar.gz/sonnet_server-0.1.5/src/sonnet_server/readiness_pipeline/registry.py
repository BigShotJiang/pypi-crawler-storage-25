"""Annotation-based registration for readiness stages and checks.

Provides ``@readiness_stage`` and ``@readiness_check`` decorators for
declarative registration. The server pipeline is built automatically
from the registries. CLI pipelines remain imperative.

Usage::

    @readiness_stage(order=1, is_critical=False, fail_fast=True)
    class DatabaseStage:
        '''Database connectivity and schema validation.'''

    @readiness_check(stage=DatabaseStage, is_critical=True, run_once=True)
    class DatabaseHealthCheck(ReadinessCheck):
        def _execute(self) -> ReadinessCheckResult:
            ...

    # Build server pipeline from all registered stages + checks:
    pipeline = build_pipeline_from_registry()
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from functools import lru_cache

from loguru import logger

from sonnet_server.readiness_pipeline.base import ReadinessCheck
from sonnet_server.readiness_pipeline.builder import ReadinessPipelineBuilder
from sonnet_server.readiness_pipeline.pipeline import ReadinessPipeline

# Attribute names set on decorated classes by the decorators.
_STAGE_ATTR = "_readiness_stage_meta"
_CHECK_ATTR = "_readiness_check_meta"


# -- Stage registry ---------------------------------------------------------


@dataclass(frozen=True, slots=True)
class StageMeta:
    """Metadata attached to a stage class by @readiness_stage."""

    order: int
    description: str
    is_critical: bool
    fail_fast: bool


class StageRegistry:
    """Collects stage classes annotated with @readiness_stage.

    Populated automatically on import. The pipeline builder reads the
    registry to create stages in the declared order.
    """

    def __init__(self) -> None:
        self._entries: dict[type, StageMeta] = {}

    def register(self, stage_class: type, meta: StageMeta) -> None:
        if stage_class in self._entries:
            raise ValueError(f"Stage class {stage_class.__name__} already registered")
        self._entries[stage_class] = meta
        logger.trace("StageRegistry: registered {} (order={})", stage_class.__name__, meta.order)

    def get_meta(self, stage_class: type) -> StageMeta | None:
        return self._entries.get(stage_class)

    def get_stages_ordered(self) -> list[tuple[type, StageMeta]]:
        """Return all registered stages sorted by order."""
        return sorted(self._entries.items(), key=lambda item: item[1].order)

    @property
    def size(self) -> int:
        return len(self._entries)

    def clear(self) -> None:
        """Remove all entries (for testing)."""
        self._entries.clear()


@lru_cache
def get_stage_registry() -> StageRegistry:
    return StageRegistry()


def readiness_stage(
    *,
    order: int,
    description: str = "",
    is_critical: bool = False,
    fail_fast: bool = True,
    registry: StageRegistry | None = None,
):
    """Decorator that registers a class as a readiness pipeline stage.

    The decorated class is a marker -- it holds no behavior. Checks
    reference it via ``@readiness_check(stage=MyStage)`` for type-safe
    stage assignment.

    Args:
        order: Execution order (lower runs first). Stages with the same
               order are independent and run in registration order.
        description: Human-readable description. Defaults to the class
                     docstring or the class name.
        is_critical: If True, stage failure stops the entire pipeline.
        fail_fast: If True, stop the stage on first check failure.
        registry: Target registry. Defaults to the global singleton.
                  Pass an isolated instance in tests.
    """

    def decorator(cls: type) -> type:
        desc = description or (cls.__doc__ or "").strip().split("\n")[0] or cls.__name__
        meta = StageMeta(order=order, description=desc, is_critical=is_critical, fail_fast=fail_fast)
        setattr(cls, _STAGE_ATTR, meta)
        (registry or get_stage_registry()).register(cls, meta)
        return cls

    return decorator


# -- Check registry ---------------------------------------------------------


@dataclass(frozen=True, slots=True)
class CheckEntry:
    """A registered check class with its stage and configuration."""

    check_class: type[ReadinessCheck]
    stage_class: type
    is_critical: bool
    run_once: bool
    order: int = field(default=0)


class CheckRegistry:
    """Collects check classes annotated with @readiness_check.

    Populated automatically on import. The pipeline builder reads the
    registry to assign checks to their declared stages.
    """

    def __init__(self) -> None:
        self._entries: list[CheckEntry] = []

    def register(self, entry: CheckEntry) -> None:
        self._entries.append(entry)
        logger.trace(
            "CheckRegistry: registered {} for stage {}",
            entry.check_class.__name__,
            entry.stage_class.__name__,
        )

    def get_checks_for_stage(self, stage_class: type) -> list[CheckEntry]:
        """Return all checks for a stage, sorted by order."""
        return sorted(
            [e for e in self._entries if e.stage_class is stage_class],
            key=lambda e: e.order,
        )

    def get_all(self) -> list[CheckEntry]:
        return list(self._entries)

    @property
    def size(self) -> int:
        return len(self._entries)

    def clear(self) -> None:
        """Remove all entries (for testing)."""
        self._entries.clear()


@lru_cache
def get_check_registry() -> CheckRegistry:
    return CheckRegistry()


def readiness_check(
    *,
    stage: type,
    is_critical: bool = False,
    run_once: bool = False,
    order: int = 0,
    registry: CheckRegistry | None = None,
):
    """Decorator that registers a ReadinessCheck subclass for a stage.

    The check class must extend ``ReadinessCheck``. It is instantiated
    (with no arguments) when the pipeline is built from the registry.

    Args:
        stage: Stage class (decorated with ``@readiness_stage``) this
               check belongs to. Type-safe -- typos are caught by the IDE.
        is_critical: If True, check failure stops the pipeline stage.
        run_once: If True, result is cached after first execution.
        order: Execution order within the stage (lower runs first).
        registry: Target registry. Defaults to the global singleton.
                  Pass an isolated instance in tests.
    """

    def decorator(cls: type[ReadinessCheck]) -> type[ReadinessCheck]:
        entry = CheckEntry(
            check_class=cls,
            stage_class=stage,
            is_critical=is_critical,
            run_once=run_once,
            order=order,
        )
        setattr(cls, _CHECK_ATTR, entry)
        (registry or get_check_registry()).register(entry)
        return cls

    return decorator


# -- Pipeline builder from registry ----------------------------------------


def build_pipeline_from_registry(
    stage_registry: StageRegistry | None = None,
    check_registry: CheckRegistry | None = None,
) -> ReadinessPipeline:
    """Build a ReadinessPipeline from all registered stages and checks.

    Creates stages in order, instantiates each check class, and adds
    it to the appropriate stage. Checks within a stage are ordered by
    their ``order`` parameter.

    Args:
        stage_registry: Override the global stage registry (for testing).
        check_registry: Override the global check registry (for testing).

    Returns:
        A fully assembled ReadinessPipeline.
    """
    stages = (stage_registry or get_stage_registry()).get_stages_ordered()
    checks = check_registry or get_check_registry()
    builder = ReadinessPipelineBuilder()

    for stage_class, meta in stages:
        stage = builder.add_stage(
            name=_stage_name(stage_class),
            description=meta.description,
            is_critical=meta.is_critical,
            fail_fast=meta.fail_fast,
        )

        for entry in checks.get_checks_for_stage(stage_class):
            check_instance = entry.check_class()
            check_instance.is_critical = entry.is_critical
            check_instance.run_once = entry.run_once
            stage.add_check(check_instance)

    logger.debug(
        "Built pipeline from registry: {} stages, {} checks",
        len(stages),
        checks.size,
    )
    return builder.build()


def _stage_name(stage_class: type) -> str:
    """Derive a stage name from the class name.

    Converts CamelCase to snake_case and strips trailing ``_stage``
    if present. Example: ``DatabaseStage`` -> ``database``,
    ``MessagingStage`` -> ``messaging``.
    """
    name = stage_class.__name__
    snake = re.sub(r"(?<=[a-z0-9])([A-Z])", r"_\1", name).lower()
    if snake.endswith("_stage"):
        snake = snake[: -len("_stage")]
    return snake
