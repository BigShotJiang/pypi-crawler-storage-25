"""Server readiness pipeline module with pipeline architecture.

This module provides a readiness verification system with pipeline architecture:
- Pipeline stages group related checks
- Sequential execution with proper failure handling
- Critical stages and checks control execution flow
- Rich reporting with hierarchical results
- Annotation-based check registration via @readiness_stage / @readiness_check

The pipeline runtime is decoupled from specific check implementations.
Check implementations and pipeline configuration are in the checks submodule.
"""

from .base import ReadinessCheck
from .builder import FluentReadinessPipelineBuilder, ReadinessPipelineBuilder
from .enums import CheckStatus, ServerState
from .models import ReadinessCheckResult, ReadinessPipelineResult, ReadinessStageResult
from .pipeline import ReadinessPipeline
from .registry import (
    CheckRegistry,
    StageRegistry,
    build_pipeline_from_registry,
    get_check_registry,
    get_stage_registry,
    readiness_check,
    readiness_stage,
)
from .stage import ReadinessStage

__all__ = [
    # Core models
    "CheckStatus",
    "ReadinessStageResult",
    "ReadinessCheck",
    "ReadinessPipelineResult",
    "ReadinessCheckResult",
    "ServerState",
    # Pipeline components
    "ReadinessStage",
    "ReadinessPipeline",
    "ReadinessPipelineBuilder",
    "FluentReadinessPipelineBuilder",
    # Registry
    "CheckRegistry",
    "StageRegistry",
    "build_pipeline_from_registry",
    "get_check_registry",
    "get_stage_registry",
    "readiness_check",
    "readiness_stage",
]
