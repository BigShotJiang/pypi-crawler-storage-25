"""Shared API error serialization utilities.

Helpers for converting application exceptions into structured
HTTPException detail dicts. Centralising this prevents duplication
across API modules.
"""

from sonnet_server.exceptions import InvalidSchemaError


def invalid_schema_detail(e: InvalidSchemaError) -> dict:
    """Serialize an InvalidSchemaError into an HTTPException detail dict."""
    return {
        "message": str(e),
        "errors": [{"message": err.message, "path": err.path, "schema_path": err.schema_path} for err in e.errors],
    }
