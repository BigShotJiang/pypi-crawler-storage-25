"""Profile-gated API extensions.

Each extension declares a profile name. The ExtensionRegistry only
starts and mounts these extensions when their profile is in the active
profile set. Adding a new profile-gated capability (e.g. MCP, agents)
follows the same pattern: subclass Extension, declare a profile name,
return routers and a router_prefix.
"""

from __future__ import annotations

from fastapi import APIRouter

from sonnet_server.extensions import Extension


class RestExtension(Extension):
    """REST API profile extension.

    Mounts the full domain REST router at /api when the 'rest' profile
    is active. Active by default (all profiles enabled when not configured).
    """

    @property
    def name(self) -> str:
        return "rest"

    @property
    def profile(self) -> str:
        return "rest"

    @property
    def router_prefix(self) -> str:
        return "/api"

    def routers(self) -> list[APIRouter]:
        from sonnet_server.api.api_router import router as api_router

        return [api_router]


class GraphQLExtension(Extension):
    """GraphQL profile extension base class.

    Mounts the GraphQL router at /graphql when the 'graphql' profile
    is active. Active by default (all profiles enabled when not configured).

    Consumers must subclass this and override ``routers()`` to supply their
    own strawberry schema. Sonnet does not provide a schema -- it only provides
    the profile/name/router_prefix plumbing and the ``GraphQLContext`` base::

        from sonnet_server.api import GraphQLExtension
        from sonnet_server.graphql import GraphQLContext

        class MyGraphQLExtension(GraphQLExtension):
            def routers(self):
                from myapp.graphql.router import create_graphql_router
                return [create_graphql_router()]
    """

    @property
    def name(self) -> str:
        return "graphql"

    @property
    def profile(self) -> str:
        return "graphql"

    @property
    def router_prefix(self) -> str:
        return "/graphql"

    def routers(self) -> list[APIRouter]:
        raise NotImplementedError(
            f"{type(self).__name__} must override routers() to provide a GraphQL schema. "
            "See GraphQLExtension docstring for the expected pattern."
        )
