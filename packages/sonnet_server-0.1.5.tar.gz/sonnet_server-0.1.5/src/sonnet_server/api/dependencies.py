"""API dependencies and router factories for FastAPI endpoints.

Three router factories compose guard levels:

    db_router()      -- DB session only. Public or mixed-guard endpoints.
    auth_router()    -- DB session + require_auth. Authenticated, no tenant.
    tenant_router()  -- DB session + require_auth + require_tenant. Full guard.

All three are convenience wrappers around guarded_router(*guards), which
applies arbitrary guard dependencies to all routes on the router.
"""

from collections.abc import Callable

from fastapi import APIRouter, Depends

from sonnet_server.database import get_db_session
from sonnet_server.guards import require_auth, require_tenant
from sonnet_server.services.registry import get_service_registry


def service[T](service_type: type[T]) -> Callable[[], T]:
    """FastAPI dependency that provides a service by type.

    Args:
        service_type: The type of service to retrieve from the registry

    Returns:
        A callable that returns the requested service instance

    Example:
        ```python
        @router.get("/endpoint")
        def endpoint(service: MyService = Depends(service(MyService))):
            return service.do_something()
        ```
    """

    def get_service() -> T:
        registry = get_service_registry()
        return registry.get(service_type)

    return get_service


def guarded_router(*dependencies: Callable, **kwargs) -> APIRouter:
    """Create an APIRouter with arbitrary router-level dependencies.

    Dependencies are applied to every endpoint on the router automatically.
    Use the named factories (``db_router``, ``auth_router``, ``tenant_router``)
    for common combinations, or call ``guarded_router`` directly when you
    need a custom composition (e.g. two different session types).

    Args:
        *dependencies: Callables applied as router-level dependencies.
        **kwargs: Passed through to APIRouter (prefix, tags, etc.)

    Returns:
        APIRouter with the given dependencies pre-applied.

    Example::

        # opsdb + graphdb session (both ambient)
        router = guarded_router(get_db_session, get_graphdb_session)
    """
    existing = kwargs.pop("dependencies", [])
    deps = [*(Depends(d) for d in dependencies), *existing]
    return APIRouter(dependencies=deps, **kwargs)


def db_router(**kwargs) -> APIRouter:
    """Create a router with opsdb session only. No authentication.

    For public endpoints or routers with mixed per-endpoint guards
    (e.g. auth.py where login is public but /me requires auth).
    Establishes an ambient opsdb session via ``get_current_session()``.
    """
    return guarded_router(get_db_session, **kwargs)


def auth_router(**kwargs) -> APIRouter:
    """Create a router with opsdb session + require_auth.

    For authenticated endpoints that do not need tenant context.
    """
    return guarded_router(get_db_session, require_auth, **kwargs)


def tenant_router(**kwargs) -> APIRouter:
    """Create a router with opsdb session + require_auth + require_tenant.

    Standard router for all opsdb data endpoints. Ensures every request
    has a validated user identity and an active tenant context.
    """
    return guarded_router(get_db_session, require_auth, require_tenant, **kwargs)
