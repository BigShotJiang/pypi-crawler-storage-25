"""Shared query parameter models for paginated list endpoints.

Pydantic-based hierarchy for list endpoint query params:

  ListParams              -- base: limit, offset, search
  SortableListParams      -- adds sort with field allowlisting
  FilterableListParams    -- adds declarative filter framework (AST-based)

Usage in a route:

    _params = SortableListParams.dependency(allowed_sort_fields=["name", "created_at"])

    @router.get("/widgets")
    def list_widgets(
        params: Annotated[SortableListParams, Depends(_params)],
        ...
    ):
        sort = params.sort_expressions(WidgetModel)
        result = widget_service.list_page(session, params.limit, params.offset, sort=sort)

    _audit_params = FilterableListParams.dependency(filter_defs=AUDIT_TRAIL_FILTERS)

    @router.get("/log")
    def list_audit_trail(
        params: Annotated[FilterableListParams, Depends(_audit_params)],
        ...
    ):
        clause = compile_filter(params.filter_expr, AuditLogEvent, params.filter_defs)
        result = service.list_page(clause, params.limit, params.offset)
"""

from typing import Any

from fastapi import HTTPException, Query, Request, status
from pydantic import BaseModel, Field

from sonnet_server.utils.filtering import (
    FilterAnd,
    FilterDef,
    FilterExpr,
    FilterOperator,
    FilterPage,
    FilterTerm,
    collect_fields,
    missing_required_filters,
    parse_query,
)

DEFAULT_LIMIT = 20
MAX_LIMIT = 100


def _parse_isnull_param(
    key: str,
    value: str,
    defs_by_key: dict[str, FilterDef],
) -> FilterTerm:
    """Parse a ``?field__isnull=true/false`` query param into a FilterTerm.

    Routes to JSON_PATH_IS_NULL when the field has a json_path, or to
    IS_NULL for plain relational columns.

    Raises HTTPException 400 if the base field is unknown or does not
    declare IS_NULL or JSON_PATH_IS_NULL in its operators list.
    """
    base_key = key[: -len("__isnull")]
    fdef = defs_by_key.get(base_key)
    if fdef is None:
        allowed = ", ".join(sorted(defs_by_key.keys()))
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unknown filter field '{base_key}' (from '{key}'). Allowed: {allowed}",
        )

    # Pick the right operator: JSON_PATH_IS_NULL for JSONB path fields,
    # IS_NULL for plain relational columns. A field should never declare
    # both -- JSON_PATH_IS_NULL takes precedence if it does.
    if FilterOperator.JSON_PATH_IS_NULL in fdef.operators:
        return FilterTerm(field=base_key, op=FilterOperator.JSON_PATH_IS_NULL, value=value)

    if FilterOperator.IS_NULL not in fdef.operators:
        allowed_ops = ", ".join(sorted(fdef.operators))
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(f"Operator '{FilterOperator.IS_NULL}' not allowed for field '{base_key}'. Allowed: {allowed_ops}"),
        )
    return FilterTerm(field=base_key, op=FilterOperator.IS_NULL, value=value)


def _parse_field_param(
    key: str,
    value: str,
    defs_by_key: dict[str, FilterDef],
) -> FilterTerm:
    """Parse a ``?field=value`` query param into a FilterTerm.

    Uses the field's first declared operator as the default.
    Raises HTTPException 400 if the field is unknown.
    """
    fdef = defs_by_key.get(key)
    if fdef is None:
        allowed = ", ".join(sorted(defs_by_key.keys()))
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unknown filter field '{key}'. Allowed: {allowed}",
        )
    return FilterTerm(field=key, op=fdef.operators[0], value=value)


class ListParams(BaseModel):
    """Base pagination and search parameters for all list endpoints.

    Attributes:
        limit: Page size (1..100, default 20).
        offset: Number of records to skip (default 0).
        search: Optional freetext search string.
    """

    limit: int = Field(default=DEFAULT_LIMIT, ge=1, le=MAX_LIMIT)
    offset: int = Field(default=0, ge=0)
    search: str | None = None


class SortableListParams(ListParams):
    """List parameters with sort support for CRUD entity endpoints.

    Extends ListParams with a sort string and field allowlisting.

    Attributes:
        sort: Comma-separated field names. Prefix with '-' for descending.
        allowed_sort_fields: Allowlist of valid sort field names (excluded from
            the JSON schema so it does not appear as a query parameter).
    """

    model_config = {"json_schema_extra": {"exclude": ["allowed_sort_fields"]}}

    sort: str | None = None
    allowed_sort_fields: list[str] = Field(default_factory=list, exclude=True)

    def model_post_init(self, __context: Any) -> None:
        """Validate sort fields after construction."""
        self._validate_sort()

    @classmethod
    def dependency(cls, allowed_sort_fields: list[str]):
        """Return a FastAPI dependency factory for a specific entity.

        Args:
            allowed_sort_fields: Field names that may be used in the sort param.

        Returns:
            A callable that FastAPI can use as a Depends() target.
        """

        def _dep(
            limit: int = Query(default=DEFAULT_LIMIT, ge=1, le=MAX_LIMIT),
            offset: int = Query(default=0, ge=0),
            sort: str | None = Query(default=None),
            search: str | None = Query(default=None, min_length=1),
        ) -> SortableListParams:
            return cls(
                limit=limit,
                offset=offset,
                sort=sort,
                search=search,
                allowed_sort_fields=allowed_sort_fields,
            )

        return _dep

    def sort_expressions(self, db_model: Any) -> list[Any] | None:
        """Translate the sort param into SQLAlchemy order expressions.

        Parses comma-separated field names. A leading '-' means descending.

        Args:
            db_model: The SQLModel table class to resolve column references.

        Returns:
            List of SQLAlchemy order expressions, or None if no sort param.
        """
        if not self.sort:
            return None

        expressions = []
        for part in self.sort.split(","):
            part = part.strip()
            if part.startswith("-"):
                column = getattr(db_model, part[1:])
                expressions.append(column.desc())
            else:
                column = getattr(db_model, part)
                expressions.append(column.asc())
        return expressions

    def _validate_sort(self) -> None:
        """Raise 400 if any sort field is not in the allowlist."""
        if not self.sort:
            return
        for part in self.sort.split(","):
            field_name = part.strip().lstrip("-")
            if field_name not in self.allowed_sort_fields:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=(f"Invalid sort field '{field_name}'. Allowed: {', '.join(sorted(self.allowed_sort_fields))}"),
                )


_FILTER_RESERVED_PARAMS = {"limit", "offset", "search", "q"}


class FilterableListParams(ListParams):
    """List parameters with declarative filter support.

    Extends ListParams with filter expressions parsed from query params
    into a FilterExpr AST. The AST can be compiled to SQLAlchemy clauses
    via compile().

    Supports two input paths that are AND-merged:
    - Flat query params matching declared FilterDef keys (simple filters).
      Two forms are accepted:
        ?field=value            uses the field's default operator
        ?field__isnull=true     IS NULL (field must declare IS_NULL operator)
        ?field__isnull=false    IS NOT NULL
    - A `q` query param containing a query expression (complex boolean logic)

    Unknown flat params are rejected with 400.

    Attributes:
        filter_expr: The parsed filter expression tree.
        filter_defs: Declared filter definitions (excluded from schema).
    """

    filter_expr: FilterExpr = Field(default_factory=lambda: FilterAnd(children=[]), exclude=True)
    filter_defs: list[FilterDef] = Field(default_factory=list, exclude=True)

    @classmethod
    def dependency(
        cls,
        filter_defs: list[FilterDef],
        extra_reserved: set[str] | None = None,
    ):
        """Return a FastAPI dependency factory for a filterable endpoint.

        Parses two input sources into a single FilterExpr AST:
        1. Flat query params matching FilterDef keys -> FilterTerms (AND-combined)
        2. Optional `q` param -> parsed via parse_query() into a full FilterExpr
        Both are AND-merged. Required filters can come from either source.
        Unknown flat params are rejected with 400.

        Args:
            filter_defs: Allowed filter field definitions.
            extra_reserved: Additional query param names that should be
                ignored by the filter parser (endpoint-specific non-filter
                params like ``with_ancestors``).

        Returns:
            A callable that FastAPI can use as a Depends() target.
        """
        defs_by_key = {d.key: d for d in filter_defs}
        reserved = _FILTER_RESERVED_PARAMS | (extra_reserved or set())

        async def _dep(
            request: Request,
            limit: int = Query(default=DEFAULT_LIMIT, ge=1, le=MAX_LIMIT),
            offset: int = Query(default=0, ge=0),
            search: str | None = Query(default=None, min_length=1),
            q: str | None = Query(
                default=None,
                description='Query expression (e.g. \'action ~ "user." AND outcome = "failure"\')',
            ),
        ) -> FilterableListParams:
            # 1. Parse flat query params into FilterTerms.
            #
            # Two forms are supported (the __isnull check MUST come first
            # so "field__isnull" keys are not rejected as unknown fields):
            #   ?field=value            -- field's default operator
            #   ?field__isnull=true     -- IS NULL
            #   ?field__isnull=false    -- IS NOT NULL
            terms: list[FilterTerm] = []
            present_keys: set[str] = set()

            for key, value in request.query_params.multi_items():
                if key in reserved:
                    continue
                if key.endswith("__isnull"):
                    term = _parse_isnull_param(key, value, defs_by_key)
                    present_keys.add(term.field)
                else:
                    term = _parse_field_param(key, value, defs_by_key)
                    present_keys.add(term.field)
                terms.append(term)

            # 2. Parse q param if present and AND-merge with flat terms
            q_expr: FilterExpr | None = None
            if q:
                try:
                    q_expr = parse_query(q)
                except ValueError as e:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=str(e),
                    ) from e
                present_keys |= collect_fields(q_expr)

            # 3. Enforce required filters across both sources
            missing = missing_required_filters(filter_defs, present_keys)
            if missing:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Required filter(s) missing: {', '.join(missing)}",
                )

            # 4. Build final expression: AND-merge flat terms with q expression
            children: list[FilterExpr] = list(terms)
            if q_expr is not None:
                children.append(q_expr)
            expr: FilterExpr = FilterAnd(children=children)

            return cls(
                limit=limit,
                offset=offset,
                search=search,
                filter_expr=expr,
                filter_defs=filter_defs,
            )

        return _dep

    def to_filter_page(self) -> FilterPage:
        """Extract filter and pagination state as a transport-agnostic FilterPage.

        Services accept FilterPage rather than FilterableListParams so they
        do not depend on the FastAPI api/ layer.
        """
        return FilterPage(
            filter_expr=self.filter_expr,
            filter_defs=self.filter_defs,
            limit=self.limit,
            offset=self.offset,
        )
