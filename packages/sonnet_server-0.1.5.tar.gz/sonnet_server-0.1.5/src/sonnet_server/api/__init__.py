"""API package.

Public surface for the api module::

    from sonnet_server.api import (
        auth_router, db_router, guarded_router, service, tenant_router,
        invalid_schema_detail,
        FilterableListParams, SortableListParams,
        RestExtension, GraphQLExtension,
    )
"""

from sonnet_server.api.dependencies import auth_router, db_router, guarded_router, service, tenant_router
from sonnet_server.api.error_utils import invalid_schema_detail
from sonnet_server.api.extensions import GraphQLExtension, RestExtension
from sonnet_server.api.list_params import FilterableListParams, SortableListParams
from sonnet_server.api.ping import router as ping_router

__all__ = [
    # Guard-tier router factories
    "auth_router",
    "db_router",
    "guarded_router",
    "service",
    "tenant_router",
    # Error utilities
    "invalid_schema_detail",
    # Extension classes
    "GraphQLExtension",
    "RestExtension",
    # List parameter models
    "FilterableListParams",
    "SortableListParams",
    # Built-in routers
    "ping_router",
]
