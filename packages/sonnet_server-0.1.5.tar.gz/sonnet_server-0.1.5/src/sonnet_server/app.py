"""FastAPI application factory for sonnet-server consumers.

Provides :func:`create_app` -- a batteries-included factory that wires up
the full server lifecycle (logging, DI, profiles, extensions, readiness
checks, routers, home page) from a small set of consumer-supplied parameters.

Using the factory is optional. All building blocks (``ExtensionRegistry``,
``setup_logging``, ``register_exception_handlers``, etc.) remain public so
consumers can compose their own ``app.py`` when the factory does not fit.

Typical usage::

    # consumer app.py
    from sonnet_server.app import create_app
    from sonnet_server.extensions import create_extension_registry
    from sonnet_server.database.extension import DatabaseExtension

    from my_server.api.extensions import RestExtension
    from my_server.services.di import register_all_services
    import my_server.checks  # noqa: F401 -- registers domain checks

    _registry = create_extension_registry(DatabaseExtension(), RestExtension())

    app, perform_startup_checks = create_app(
        extension_registry=_registry,
        register_services=register_all_services,
        title="My Server",
        server_name="my_server",
    )

Escape hatch -- build your own app::

    # Skip the factory entirely; all primitives are still importable.
    from fastapi import FastAPI
    from sonnet_server.exception_handlers import register_exception_handlers
    ...
    app = FastAPI(lifespan=my_lifespan, ...)
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from contextlib import AsyncExitStack, asynccontextmanager
from typing import TYPE_CHECKING

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from loguru import logger

from sonnet_server.api.health_check import router as health_router
from sonnet_server.api.ping import router as ping_router
from sonnet_server.api.version import router as version_router
from sonnet_server.exception_handlers import register_exception_handlers
from sonnet_server.extensions import ExtensionRegistry
from sonnet_server.logging import setup_logging, setup_sqlalchemy_logging
from sonnet_server.profile import get_active_profiles, parse_profile, set_active_profiles
from sonnet_server.services.health_check_service import get_health_check_service
from sonnet_server.services.registry import ServiceRegistry, get_service_registry
from sonnet_server.settings import Settings, get_settings
from sonnet_server.utils.home import get_home_template_dir
from sonnet_server.utils.version import VersionInfo, get_version

if TYPE_CHECKING:
    from pathlib import Path

#: Type alias for the ``perform_startup_checks`` coroutine returned
#: by :func:`create_app`.
StartupChecksFn = Callable[[Settings], Awaitable[None]]


def _log_startup_check_results(health_result) -> None:
    """Log startup check results and raise SystemExit on ERROR state."""
    from sonnet_server.readiness_pipeline.enums import ServerState

    if health_result.server_state == ServerState.ERROR:
        logger.error("Startup readiness checks failed - critical infrastructure issues")
        logger.error("Server state: {}", health_result.server_state)
        raise SystemExit(1)
    elif health_result.server_state == ServerState.DEGRADED:
        logger.warning("Server starting in degraded state - some non-critical features unavailable")
        logger.info("Server state: {}", health_result.server_state)
    else:
        logger.info("All startup readiness checks passed successfully")
        logger.info("Server state: {}", health_result.server_state)


async def _run_readiness_checks() -> None:
    """Run the readiness pipeline and exit on ERROR state."""
    logger.info("Running startup readiness checks")
    health_result = get_health_check_service().perform_health_check()
    _log_startup_check_results(health_result)


def _log_endpoints_summary(
    settings: Settings,
    extension_registry: ExtensionRegistry,
    active_profiles: set[str],
    title: str = "Sonnet Server",
    version: str = "",
) -> None:
    """Log server name, version, URL, available endpoints, active profiles, and extensions."""
    server_url = f"http://{settings.host}:{settings.port}"
    version_str = f" {version}" if version else ""
    logger.info("Starting {}{}", title, version_str)
    logger.info("Server running at: {}", server_url)

    endpoints: list[tuple[str, str]] = [
        ("Home", "/"),
        ("Health Check", "/health-check"),
        ("Ping", "/ping"),
        ("Version", "/version"),
        ("OpenAPI Schema", "/openapi.json"),
        ("API Docs", "/docs"),
        ("ReDoc", "/redoc"),
    ]

    for ext in extension_registry.extensions:
        if ext.profile is not None and ext.profile in active_profiles:
            if ext.router_prefix:
                endpoints.append((ext.name.upper(), ext.router_prefix))
            # Support optional summary_endpoints() hook for extensions that
            # expose multiple sub-paths (e.g. MCP with SSE + messages).
            if hasattr(ext, "summary_endpoints"):
                endpoints.extend(ext.summary_endpoints())

    logger.info("Available endpoints:")
    for name, path in endpoints:
        logger.info("   {}: {}{}", name, server_url, path)

    logger.info("Active profiles: {}", ", ".join(sorted(active_profiles)) or "none")
    logger.info("Active extensions: {}", ", ".join(ext.name for ext in extension_registry.extensions))


async def _bootstrap(
    settings: Settings,
    register_services: Callable[[ServiceRegistry], None],
    extension_registry: ExtensionRegistry,
) -> set[str]:
    """Shared bootstrap sequence for lifespan and CLI checks.

    Sets up logging, DI, profiles, and starts extensions. Returns active
    profiles so the caller can continue with profile-specific work.
    """
    setup_logging(log_level=settings.log_level)
    setup_sqlalchemy_logging()
    register_services(get_service_registry())

    active_profiles = parse_profile(settings.profiles, valid=extension_registry.profile_names)
    set_active_profiles(active_profiles)

    await extension_registry.startup(settings, active_profiles)
    return active_profiles


def create_app(
    extension_registry: ExtensionRegistry,
    register_services: Callable[[ServiceRegistry], None],
    *,
    title: str = "Sonnet Server",
    description: str = "",
    server_name: str = "sonnet_server",
    cors_origins: list[str] | None = None,
    extra_exception_handlers: Callable[[FastAPI], None] | None = None,
    home_template_dir: Path | str | None = None,
    get_settings_fn: Callable[[], Settings] = get_settings,
) -> tuple[FastAPI, StartupChecksFn]:
    """Create a fully configured FastAPI application.

    Wires up the complete server lifecycle: logging, DI, profiles,
    extensions, readiness checks, system routers, home page, and CORS.
    Returns the ``FastAPI`` instance and a ``perform_startup_checks``
    coroutine for use by CLI ``check`` commands.

    Args:
        extension_registry: Pre-built registry (use ``create_extension_registry()``).
        register_services: Consumer's DI wiring function (e.g. ``register_all_services``).
        title: Server title for FastAPI docs and home page (default: "Sonnet Server").
        description: FastAPI OpenAPI description string.
        server_name: Package name for version lookup (default: "sonnet_server").
        cors_origins: Allowed CORS origins (default: ``["*"]``).
        extra_exception_handlers: Optional callable to register **domain-specific**
            exception handlers on top of sonnet-server's defaults. Must **not** call
            ``register_exception_handlers`` itself -- the factory handles base handlers.
        home_template_dir: Custom template directory for the home page.
            When ``None`` (default), uses sonnet-server's built-in template.
        get_settings_fn: Settings getter (default: ``get_settings``). Override
            in tests or when using a different settings instance.

    Returns:
        A ``(app, perform_startup_checks)`` tuple.
        ``perform_startup_checks`` is an async callable that bootstraps and runs
        the readiness pipeline without starting the HTTP server.

    Example::

        app, perform_startup_checks = create_app(
            extension_registry=_registry,
            register_services=register_all_services,
            title="My Server",
            server_name="my_server",
        )
    """
    _cors_origins = cors_origins if cors_origins is not None else ["*"]
    _template_dir = get_home_template_dir(home_template_dir)
    _version_info: VersionInfo = get_version(server_name)

    # -- Lifespan ----------------------------------------------------------

    @asynccontextmanager
    async def _lifespan(_app: FastAPI):
        settings = get_settings_fn()
        _app.state.settings = settings  # type: ignore[attr-defined]

        active_profiles = await _bootstrap(settings, register_services, extension_registry)
        _app.state.active_profiles = active_profiles  # type: ignore[attr-defined]

        await _run_readiness_checks()

        extension_registry.mount_routers(_app, active_profiles)
        _app.state.templates = Jinja2Templates(directory=_template_dir)  # type: ignore[attr-defined]

        _log_endpoints_summary(settings, extension_registry, active_profiles, title=title, version=_version_info.version)

        # Enter sub-app lifespan contexts for started extensions that need them
        # (e.g. FastMCP's StreamableHTTPSessionManager). Only started extensions
        # are included -- unstarted extensions may not have valid state.
        # AsyncExitStack exits all contexts before extension shutdown runs.
        async with AsyncExitStack() as stack:
            for ext in extension_registry.started:
                ctx = ext.lifespan_context(_app)
                if ctx is not None:
                    logger.debug("Entering lifespan context for extension: {}", ext.name)
                    await stack.enter_async_context(ctx)

            yield

            logger.info("{} shutting down", title)
            await extension_registry.shutdown()

    # -- App ---------------------------------------------------------------

    app = FastAPI(
        lifespan=_lifespan,
        title=title,
        description=description,
        version=_version_info.version,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    register_exception_handlers(app)
    if extra_exception_handlers is not None:
        extra_exception_handlers(app)

    app.include_router(health_router, prefix="")
    app.include_router(ping_router, prefix="")
    app.include_router(version_router, prefix="/version")

    for _ext_router, _ext_prefix in extension_registry.infrastructure_routers():
        app.include_router(_ext_router, prefix=_ext_prefix)

    @app.get("/", response_class=HTMLResponse)
    async def read_root(request: Request):
        """Serve the home page."""
        health_service = get_health_check_service()
        server_state = health_service.get_server_state().value
        active_profile = get_active_profiles()

        context = {
            "request": request,
            "server_title": title,
            "version": _version_info.version,
            "full_version": _version_info.full_version,
            "server_state": server_state,
            "build_timestamp": _version_info.build_timestamp,
            "profile": active_profile,
            "profile_display": ", ".join(sorted(active_profile)),
        }
        return request.app.state.templates.TemplateResponse(request, "index.html", context)

    # -- perform_startup_checks --------------------------------------------

    async def perform_startup_checks(app_settings: Settings) -> None:
        """Bootstrap and run readiness checks without starting the HTTP server.

        Used by CLI ``check`` commands. Sets up logging, DI, profiles, and
        extensions before executing the readiness pipeline.

        Args:
            app_settings: Application settings (may carry CLI overrides).
        """
        await _bootstrap(app_settings, register_services, extension_registry)
        logger.info("{} performing startup checks", title)
        await _run_readiness_checks()

    return app, perform_startup_checks


__all__ = ["StartupChecksFn", "create_app"]
