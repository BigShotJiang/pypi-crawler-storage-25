"""DB model walker -- derives FilterDef list by inspecting a SQLModel table class.

Provides two levels of API:

1. ``filter_defs_from_db_model`` -- low-level. Walks the SQLAlchemy columns
   of a SQLModel table and produces a FilterDef for every queryable scalar
   column. JSONB/JSON columns are skipped (they are handled by the schema
   walker).

2. ``build_filter_defs`` -- high-level convenience. Combines the DB model
   walker and the schema walker in one call. Declare which JSONB columns
   have schemas and get the full merged FilterDef list back.

This module has no domain, no HTTP, no DB connection dependencies.
It only imports SQLAlchemy type classes for column type detection and the
filtering primitives from this package.

Column type mapping
-------------------
    String / Text / Enum   -> EQ, LIKE
    Integer / BigInteger   -> EQ, GTE, LTE, GT, LT
    Float / Numeric        -> EQ, GTE, LTE, GT, LT
    Boolean                -> EQ
    DateTime / Date        -> EQ, GTE, LTE, GT, LT
    UUID                   -> EQ
    JSON / JSONB           -> skipped (managed by schema walker)
    ARRAY                  -> skipped
    everything else        -> skipped (conservative default)

Simple usage (convenience API)
-------------------------------
    from sonnet_server.utils.filtering.db_model_walker import (
        build_filter_defs,
        JsonColumnBinding,
    )

    # Defined next to the DB model:
    RECORD_JSON_BINDINGS = [
        JsonColumnBinding(
            column="extensions",
            alias="$",              # optional -- defaults to column name
            document=extensions_schema,
        ),
    ]

    defs = build_filter_defs(MyRecord, resolver=my_resolver, json_bindings=RECORD_JSON_BINDINGS)
    # $.risk_score >= 7.5   ->  extensions -> 'risk_score' cast to float >= 7.5

Full control (low-level API)
-----------------------------
    from sonnet_server.utils.filtering.db_model_walker import filter_defs_from_db_model
    from sonnet_server.utils.filtering.schema_walker import filter_defs_from_schema

    envelope_defs = filter_defs_from_db_model(
        MyRecord,
        skip_fields=_DEFAULT_SKIP,
        json_columns=frozenset({"extensions"}),
    )
    raw = filter_defs_from_schema(extensions_schema, resolver)
    extension_defs = [
        d.model_copy(update={"key": f"extensions.{d.key}", "column": "extensions"})
        for d in raw
    ]
    all_defs = envelope_defs + extension_defs
"""

from __future__ import annotations

from typing import Any

import sqlalchemy as sa
from pydantic import BaseModel, Field

from sonnet_server.utils.filtering.filter_defs import FilterDef, FilterOperator
from sonnet_server.utils.filtering.schema_walker import RefResolver, filter_defs_from_schema

# Standard fields that are almost always internal implementation details.
# The caller can override this by passing an explicit skip_fields set.
_DEFAULT_SKIP: frozenset[str] = frozenset(
    {
        "is_deleted",
        "created_by",
        "updated_by",
    }
)

# SQLAlchemy type classes that map to comparison operators.
_COMPARISON_TYPES = (
    sa.Integer,
    sa.BigInteger,
    sa.SmallInteger,
    sa.Float,
    sa.Numeric,
    sa.DateTime,
    sa.Date,
)

_STRING_TYPES = (
    sa.String,
    sa.Text,
    sa.Enum,
)

_EQ_ONLY_TYPES = (
    sa.Boolean,
    sa.Uuid,
)

# JSON column types -- managed by schema walker, never emit scalar FilterDef.
_JSON_TYPES = (sa.JSON,)

# Array types -- skip entirely.
_ARRAY_TYPES = (sa.ARRAY,)

_COMPARISON_OPERATORS: list[FilterOperator] = [
    FilterOperator.EQ,
    FilterOperator.GTE,
    FilterOperator.LTE,
    FilterOperator.GT,
    FilterOperator.LT,
]

_STRING_OPERATORS: list[FilterOperator] = [
    FilterOperator.EQ,
    FilterOperator.LIKE,
]

_EQ_OPERATORS: list[FilterOperator] = [
    FilterOperator.EQ,
]


def filter_defs_from_db_model(
    db_model: type[Any],
    skip_fields: frozenset[str] = _DEFAULT_SKIP,
    json_columns: frozenset[str] = frozenset(),
) -> list[FilterDef]:
    """Derive a FilterDef list by inspecting a SQLModel table class.

    Produces one FilterDef per queryable scalar column. JSON/JSONB columns
    listed in ``json_columns`` are skipped -- they are handled by the
    schema walker and should not produce a raw blob FilterDef.

    Args:
        db_model: A SQLModel class with ``table=True``. Must have a
            ``__table__`` attribute (i.e. a mapped table class, not a
            base/mixin).
        skip_fields: Column names to exclude entirely. Defaults to
            the standard internal fields (is_deleted, created_by,
            updated_by). Pass an explicit set to override -- callers
            that want to include updated_by can do so.
        json_columns: Column names that hold JSON/JSONB managed by the
            schema walker. These are skipped here so the caller can
            attach schema-derived FilterDefs for them instead.

    Returns:
        List of FilterDef instances, one per queryable scalar column.

    Raises:
        TypeError: If db_model does not have a ``__table__`` attribute.
    """
    if not hasattr(db_model, "__table__"):
        raise TypeError(f"{db_model!r} does not have a __table__ attribute. Pass a SQLModel class with table=True.")

    defs: list[FilterDef] = []

    for col in db_model.__table__.columns:
        name = col.name

        if name in skip_fields:
            continue

        if name in json_columns:
            continue

        ops = _operators_for_column(col)
        if ops is None:
            continue

        defs.append(
            FilterDef(
                key=name,
                column=name,
                operators=ops,
            )
        )

    return defs


# ---------------------------------------------------------------------------
# Convenience API -- combines DB model walker and schema walker
# ---------------------------------------------------------------------------


class JsonColumnBinding(BaseModel):
    """Binds a concrete DB column to its JSON Schema document and query alias.

    Lives next to the DB model definition -- it describes how a specific JSONB
    column on a specific table is structured and how it is addressed in queries.
    The schema document itself is agnostic; this binding is what makes it
    concrete.

    Attributes:
        column: DB column name on the table (e.g. "extensions").
        document: The JSON Schema document dict describing the column content.
        alias: Query key prefix for emitted FilterDef keys. Optional -- when
            not set, defaults to ``column`` (e.g. column="extensions" produces
            keys like "extensions.risk_score"). Use "$" to address the JSONB
            root without repeating the column name (e.g. "$.risk_score").
        typed_ref_map: Mapping from $ref URI to json_value_type name for any
            compound types referenced by this schema. Empty dict means all
            fields are scalar.
        skip_properties: Schema property names to exclude from filter
            generation (e.g. extension points, internal fields).
    """

    column: str
    document: dict
    alias: str | None = None
    typed_ref_map: dict[str, str] = Field(default_factory=dict)
    skip_properties: frozenset[str] = frozenset()

    @property
    def effective_alias(self) -> str:
        """Query key prefix -- alias if set, otherwise the column name."""
        return self.alias if self.alias is not None else self.column


def build_filter_defs(
    db_model: type[Any],
    resolver: RefResolver,
    json_bindings: list[JsonColumnBinding] | None = None,
    skip_fields: frozenset[str] = _DEFAULT_SKIP,
) -> list[FilterDef]:
    """Build a complete FilterDef list from a DB model and its JSONB bindings.

    Convenience wrapper that combines ``filter_defs_from_db_model`` and
    ``filter_defs_from_schema`` in one call. For full control over operators
    or per-field overrides, use the two functions directly.

    Args:
        db_model: SQLModel table class (must have ``table=True``).
        resolver: RefResolver for $ref resolution in JSON Schema documents.
        json_bindings: One entry per JSONB column that has a schema. Each
            binding declares the column name, the schema document, an optional
            query alias (defaults to the column name), an optional typed ref
            map, and optional skip_properties.
        skip_fields: DB column names to exclude from the envelope defs.
            Defaults to the standard internal fields (is_deleted, created_by,
            updated_by).

    Returns:
        Merged list of FilterDefs: envelope columns first, then content fields
        for each JsonColumnBinding in declaration order.
    """
    json_bindings = json_bindings or []

    # Derive the set of JSONB column names so the DB walker skips them.
    json_column_names = frozenset(jb.column for jb in json_bindings)

    envelope_defs = filter_defs_from_db_model(
        db_model,
        skip_fields=skip_fields,
        json_columns=json_column_names,
    )

    content_defs: list[FilterDef] = []
    for jb in json_bindings:
        raw = filter_defs_from_schema(
            schema=jb.document,
            resolver=resolver,
            typed_ref_map=jb.typed_ref_map,
            skip_properties=jb.skip_properties,
        )
        content_defs.extend(
            d.model_copy(
                update={
                    "key": f"{jb.effective_alias}.{d.key}",
                    "column": jb.column,
                }
            )
            for d in raw
        )

    return envelope_defs + content_defs


# ---------------------------------------------------------------------------
# Internal
# ---------------------------------------------------------------------------


def _operators_for_column(col: sa.Column) -> list[FilterOperator] | None:
    """Return the operator list for a column, or None to skip it."""
    col_type = col.type

    # Unwrap TypeDecorator (e.g. SQLModel's AutoString wraps sa.String).
    # impl_instance gives the underlying concrete type.
    if isinstance(col_type, sa.TypeDecorator):
        col_type = col_type.impl_instance

    # JSON/JSONB -- skip, managed by schema walker.
    if isinstance(col_type, _JSON_TYPES):
        return None

    # Array -- skip.
    if isinstance(col_type, _ARRAY_TYPES):
        return None

    # String types -- EQ and LIKE.
    if isinstance(col_type, _STRING_TYPES):
        return _STRING_OPERATORS

    # Numeric and date types -- full comparison set.
    if isinstance(col_type, _COMPARISON_TYPES):
        return _COMPARISON_OPERATORS

    # Boolean and UUID -- equality only.
    if isinstance(col_type, _EQ_ONLY_TYPES):
        return _EQ_OPERATORS

    # Unknown type -- skip conservatively.
    return None
