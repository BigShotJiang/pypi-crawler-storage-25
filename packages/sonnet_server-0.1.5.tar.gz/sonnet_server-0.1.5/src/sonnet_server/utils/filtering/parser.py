"""Query string parser -- parses a human-readable filter expression into a FilterExpr AST.

Uses Lark (PEG grammar, no code generation) to parse a query expression into
the same FilterExpr tree that the query param path and JSON AST path produce.
All three input paths feed the same compile_filter() call.

Grammar summary:

    field = "acme" AND outcome = "failure"
    action ^ "user." AND (outcome = "failure" OR outcome = "error")
    name ~ "acme" AND status = "active"
    NOT outcome = "success"

Operators:
    =    eq          exact match
    !=   neq         not equal
    ~    like        contains / substring  (ILIKE '%val%')  -- aligns with JQL ~
    ^    prefix      starts-with           (LIKE 'val%')
    >    gt
    >=   gte
    <    lt
    <=   lte

Values must be quoted strings ("value") or unquoted tokens (no spaces, no
parentheses). Field names are unquoted lowercase identifiers.

Operator precedence (high to low): NOT > AND > OR.
"""

from lark import Lark, Transformer, v_args

from sonnet_server.utils.filtering.filter_defs import FilterOperator
from sonnet_server.utils.filtering.types import (
    FilterAnd,
    FilterExpr,
    FilterGroup,
    FilterNot,
    FilterOr,
    FilterTerm,
)

_GRAMMAR = r"""
    ?expr    : or_expr

    ?or_expr  : and_expr
              | or_expr _OR and_expr   -> or_

    ?and_expr : not_expr
              | and_expr _AND not_expr -> and_

    ?not_expr : atom
              | _NOT atom              -> not_

    ?atom    : term
             | "(" expr ")"          -> group

    term     : FIELD OP VALUE        -> term

    OP       : ">=" | "<=" | "!=" | ">" | "<" | "=" | "~" | "^"
    _AND.1   : /AND/i
    _OR.1    : /OR/i
    _NOT.1   : /NOT/i
    FIELD    : /[a-z][a-z0-9_]*/
    VALUE    : ESCAPED_STRING | /[^\s()]+/

    %import common.ESCAPED_STRING
    %import common.WS
    %ignore WS
"""

_OP_MAP = {
    "=": FilterOperator.EQ,
    "!=": FilterOperator.NEQ,
    "~": FilterOperator.LIKE,
    "^": FilterOperator.PREFIX,
    ">": FilterOperator.GT,
    ">=": FilterOperator.GTE,
    "<": FilterOperator.LT,
    "<=": FilterOperator.LTE,
}

_parser = Lark(_GRAMMAR, start="expr", parser="lalr")


@v_args(inline=True)
class _FilterTransformer(Transformer):
    def term(self, field, op, value) -> FilterTerm:
        raw = str(value)
        # Strip surrounding quotes from ESCAPED_STRING
        if raw.startswith('"') and raw.endswith('"'):
            raw = raw[1:-1]
        return FilterTerm(
            field=str(field),
            op=_OP_MAP[str(op)],
            value=raw,
        )

    def and_(self, left, right) -> FilterAnd:
        # Flatten nested ands into a single children list
        children = []
        for node in (left, right):
            if isinstance(node, FilterAnd):
                children.extend(node.children)
            else:
                children.append(node)
        return FilterAnd(children=children)

    def or_(self, left, right) -> FilterOr:
        children = []
        for node in (left, right):
            if isinstance(node, FilterOr):
                children.extend(node.children)
            else:
                children.append(node)
        return FilterOr(children=children)

    def not_(self, child) -> FilterNot:
        return FilterNot(child=child)

    def group(self, child) -> FilterGroup:
        return FilterGroup(child=child)


def parse_query(q: str) -> FilterExpr:
    """Parse a query string into a FilterExpr AST.

    Accepts a query expression syntax with field = value terms combined with
    AND, OR, NOT and parenthesised grouping.

    Args:
        q: The query string to parse.

    Returns:
        A FilterExpr AST ready for compile_filter().

    Raises:
        ValueError: If the query string cannot be parsed.

    Examples:
        parse_query('org_id = "org_1"')
        parse_query('action ^ "user." AND outcome = "failure"')
        parse_query('name ~ "acme" AND status = "active"')
        parse_query('org_id = "org_1" AND (outcome = "failure" OR outcome = "error")')
        parse_query('NOT outcome = "success"')
    """
    try:
        tree = _parser.parse(q)
        return _FilterTransformer().transform(tree)
    except Exception as e:
        # Lark raises several exception types (UnexpectedCharacters, UnexpectedEOF,
        # VisitError, etc.) from different hierarchies. Normalise all parse errors
        # to ValueError so callers have a single exception type to handle.
        raise ValueError(f"Invalid query expression: {e}") from e
