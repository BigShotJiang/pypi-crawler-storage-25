"""Schema walker -- derives FilterDef list from a JSON Schema document.

Walks a JSON Schema document and produces a FilterDef for every filterable
leaf property. Both inline properties and $ref references are handled
transparently.

The walker is fully domain-agnostic. It knows only about JSON Schema
structure (properties, type, $ref, items, format). All domain knowledge
is supplied by the caller:

- ``resolver``: maps a $ref URI to a schema dict. In tests this is a
  plain dict lookup. In production it wraps whatever service provides
  schema documents.

- ``typed_ref_map``: maps a $ref URI to a ``json_value_type`` name. The
  walker uses this to emit typed FilterDefs instead of scalar ones when
  a property references a known compound type. The caller owns this
  mapping entirely.

- ``skip_properties``: property names to exclude from filter generation.
  The caller decides what is not filterable (extension points, internal
  fields, etc.).

Supported leaf types
--------------------
- Primitive scalars (string, number, integer, boolean):
  emits EQ for all; additionally GTE/LTE/GT/LT for numeric types.
- String with format "date" or "date-time":
  emits EQ/GTE/LTE/GT/LT (date comparison semantics).
- String: emits EQ and LIKE.
- $ref in typed_ref_map: emits a typed FilterDef (json_value_type set).
- Arrays of objects: recurses into items, marks FilterDefs json_is_array=True.
- Arrays of a known typed ref: emits a single typed FilterDef with
  json_is_array=True.

Skipped
-------
- Properties in skip_properties.
- $ref URIs not in typed_ref_map and not resolvable (resolver returned None).
- anyOf / oneOf / allOf at property level (ambiguous structure, skipped).
- Properties with no resolvable type.

Cycle protection
----------------
The _seen frozenset tracks $ref URIs visited in the current path. Circular
chains are silently skipped.

Usage
-----
    from sonnet_server.utils.filtering.schema_walker import (
        RefResolver,
        filter_defs_from_schema,
    )

    # Domain-owned type map
    MY_TYPED_REFS = {
        "https://example.com/types/quantity": "quantity",
        "https://example.com/types/coding":   "coding",
    }

    # Test resolver -- no DB
    resolver: RefResolver = {
        "https://example.com/types/address": ADDRESS_SCHEMA,
    }.get

    defs = filter_defs_from_schema(
        my_schema,
        resolver=resolver,
        typed_ref_map=MY_TYPED_REFS,
        skip_properties=frozenset({"_extensions"}),
    )
"""

from __future__ import annotations

from collections.abc import Callable

from sonnet_server.utils.filtering.filter_defs import FilterDef, FilterOperator

# Callable that maps a $ref URI to a JSON Schema dict, or None
# when the URI cannot be resolved.
RefResolver = Callable[[str], dict | None]


def _noop_resolver(_uri: str) -> None:
    """Default resolver that resolves nothing. Used when no $ref resolution is needed."""
    return None


# Operators emitted per JSON Schema primitive type.
_SCALAR_OPERATORS: dict[str, list[FilterOperator]] = {
    "string": [FilterOperator.EQ, FilterOperator.LIKE],
    "number": [FilterOperator.EQ, FilterOperator.GTE, FilterOperator.LTE, FilterOperator.GT, FilterOperator.LT],
    "integer": [FilterOperator.EQ, FilterOperator.GTE, FilterOperator.LTE, FilterOperator.GT, FilterOperator.LT],
    "boolean": [FilterOperator.EQ],
}

# Date / date-time strings get comparison operators.
_DATE_OPERATORS: list[FilterOperator] = [
    FilterOperator.EQ,
    FilterOperator.GTE,
    FilterOperator.LTE,
    FilterOperator.GT,
    FilterOperator.LT,
]

# Operators for typed compound values (quantity, coding, ...).
# The typed value compiler for each type may enforce further restrictions,
# but we advertise the full comparison set here.
_TYPED_OPERATORS: list[FilterOperator] = [
    FilterOperator.EQ,
    FilterOperator.GTE,
    FilterOperator.LTE,
    FilterOperator.GT,
    FilterOperator.LT,
]


def filter_defs_from_schema(
    schema: dict,
    resolver: RefResolver = _noop_resolver,
    typed_ref_map: dict[str, str] | None = None,
    column: str = "",
    prefix: str = "",
    skip_properties: frozenset[str] = frozenset(),
    json_is_array: bool = False,
    _seen: frozenset[str] = frozenset(),
    _json_path: list[str] | None = None,
) -> list[FilterDef]:
    """Derive a FilterDef list from a JSON Schema document.

    Returns bare FilterDefs with relative keys by default -- no column or
    prefix applied. The caller (e.g. ``build_filter_defs``) maps them onto
    the correct DB column and key prefix. Pass ``column`` and ``prefix``
    explicitly only when calling this function directly without
    ``build_filter_defs``.

    Args:
        schema: A JSON Schema dict (already loaded, not a URI).
        resolver: Callable mapping a $ref URI to a schema dict or None.
            Defaults to a no-op resolver that resolves nothing.
        typed_ref_map: Mapping from $ref URI to json_value_type name.
            Caller-owned -- the walker has no built-in type knowledge.
            Defaults to empty (no typed values).
        column: DB column name for emitted FilterDefs. Empty string by
            default -- set by the caller after walking.
        prefix: Dot-separated key prefix for FilterDef keys. Empty string
            by default -- set by the caller after walking.
        skip_properties: Property names to exclude from filter generation.
        json_is_array: Whether this document is the items schema of an
            array. Propagated to emitted FilterDefs.
        _seen: URIs already visited in this recursion path (cycle guard).
        _json_path: Accumulated JSON path segments from parent objects.
            Internal -- callers should not set this. Used to build the
            full ``->`` navigation path for nested inline objects.

    Returns:
        List of FilterDef instances, one per filterable leaf property.
    """
    effective_typed_ref_map = typed_ref_map if typed_ref_map is not None else {}
    parent_path = _json_path or []

    schema = _resolve_ref(schema, resolver, effective_typed_ref_map, _seen)
    if schema is None:
        return []

    properties: dict | None = schema.get("properties")
    if not properties:
        return []

    defs: list[FilterDef] = []

    for prop_name, prop_schema in properties.items():
        if prop_name in skip_properties:
            continue

        resolved = _resolve_ref(prop_schema, resolver, effective_typed_ref_map, _seen)
        if resolved is None:
            continue

        key = f"{prefix}.{prop_name}" if prefix else prop_name
        prop_json_path = [*parent_path, prop_name]

        emitted = _emit(
            schema=resolved,
            original_ref=prop_schema.get("$ref"),
            key=key,
            column=column,
            json_path=prop_json_path,
            json_is_array=json_is_array,
            resolver=resolver,
            typed_ref_map=effective_typed_ref_map,
            skip_properties=skip_properties,
            prefix=key,
            _seen=_seen,
        )
        defs.extend(emitted)

    return defs


# ---------------------------------------------------------------------------
# Internal
# ---------------------------------------------------------------------------


def _emit(
    schema: dict,
    original_ref: str | None,
    key: str,
    column: str,
    json_path: list[str],
    json_is_array: bool,
    resolver: RefResolver,
    typed_ref_map: dict[str, str],
    skip_properties: frozenset[str],
    prefix: str,
    _seen: frozenset[str],
) -> list[FilterDef]:
    """Emit FilterDef(s) for a single resolved property schema."""

    # Typed ref: the original $ref URI is in typed_ref_map.
    if original_ref and original_ref in typed_ref_map:
        return [
            FilterDef(
                key=key,
                column=column,
                operators=_TYPED_OPERATORS,
                json_path=json_path,
                json_is_array=json_is_array,
                json_value_type=typed_ref_map[original_ref],
            )
        ]

    schema_type = schema.get("type")

    # Array: recurse into items.
    if schema_type == "array":
        return _emit_array(
            schema=schema,
            key=key,
            column=column,
            json_path=json_path,
            resolver=resolver,
            typed_ref_map=typed_ref_map,
            skip_properties=skip_properties,
            prefix=prefix,
            _seen=_seen,
        )

    # Scalar primitive.
    ops = _scalar_ops(schema)
    if ops:
        return [
            FilterDef(
                key=key,
                column=column,
                operators=ops,
                json_path=json_path,
                json_is_array=json_is_array,
            )
        ]

    # Nested inline object: recurse. Pass json_path as accumulator so
    # child properties build the full -> navigation path.
    if schema_type == "object" and schema.get("properties"):
        return filter_defs_from_schema(
            schema=schema,
            resolver=resolver,
            typed_ref_map=typed_ref_map,
            column=column,
            prefix=prefix,
            skip_properties=skip_properties,
            json_is_array=json_is_array,
            _seen=_seen,
            _json_path=json_path,
        )

    return []


def _emit_array(
    schema: dict,
    key: str,
    column: str,
    json_path: list[str],
    resolver: RefResolver,
    typed_ref_map: dict[str, str],
    skip_properties: frozenset[str],
    prefix: str,
    _seen: frozenset[str],
) -> list[FilterDef]:
    """Emit FilterDef(s) for an array property."""
    items_raw: dict | None = schema.get("items")
    if not items_raw:
        return []

    original_ref = items_raw.get("$ref")

    # Track the ref URI before resolving so we can add it to _seen for
    # recursive calls. This is the key cycle-guard step: if the items $ref
    # was already visited in this path, _resolve_ref returns None and we
    # stop. If not, we add it to _seen before recursing further.
    seen_with_ref = (_seen | {original_ref}) if original_ref and original_ref not in typed_ref_map else _seen

    items = _resolve_ref(items_raw, resolver, typed_ref_map, _seen)
    if items is None:
        return []

    # Array of a known typed ref.
    if original_ref and original_ref in typed_ref_map:
        return [
            FilterDef(
                key=key,
                column=column,
                operators=_TYPED_OPERATORS,
                json_path=json_path,
                json_is_array=True,
                json_value_type=typed_ref_map[original_ref],
            )
        ]

    # Array of scalars.
    ops = _scalar_ops(items)
    if ops:
        return [
            FilterDef(
                key=key,
                column=column,
                operators=ops,
                json_path=json_path,
                json_is_array=True,
            )
        ]

    # Array of objects: recurse into items properties, mark is_array.
    if items.get("type") == "object" and items.get("properties"):
        return filter_defs_from_schema(
            schema=items,
            resolver=resolver,
            typed_ref_map=typed_ref_map,
            column=column,
            prefix=prefix,
            skip_properties=skip_properties,
            json_is_array=True,
            _seen=seen_with_ref,
        )

    return []


def _resolve_ref(
    schema: dict,
    resolver: RefResolver,
    typed_ref_map: dict[str, str],
    seen: frozenset[str],
) -> dict | None:
    """Resolve a $ref if present. Returns the schema as-is if no $ref.

    Does not resolve refs that are in typed_ref_map -- those are leaves,
    not containers to recurse into.

    Returns None on cycle or unresolvable ref.
    """
    if not isinstance(schema, dict):
        return None
    ref = schema.get("$ref")
    if ref is None:
        return schema
    # Typed refs are leaves -- return the original schema so the caller
    # can detect the ref and emit a typed FilterDef.
    if ref in typed_ref_map:
        return schema
    if ref in seen:
        return None
    resolved = resolver(ref)
    if resolved is None:
        return None
    return _resolve_ref(resolved, resolver, typed_ref_map, seen | {ref})


def _scalar_ops(schema: dict) -> list[FilterOperator] | None:
    """Return operator list for a scalar schema, or None if not scalar."""
    json_type = schema.get("type")
    if json_type == "string":
        fmt = schema.get("format", "")
        if fmt in ("date", "date-time"):
            return _DATE_OPERATORS
        return _SCALAR_OPERATORS["string"]
    return _SCALAR_OPERATORS.get(json_type)
