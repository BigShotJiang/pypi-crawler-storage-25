"""Filter expression AST -- mirrors the client-side FilterExpr.

A lightweight boolean expression tree for search and filtering. Designed
to start simple (a flat AND list of terms) and grow to support full
boolean queries (AND, OR, NOT, grouping) without breaking callers.

The server-side AST is structurally identical to the client-side
FilterExpr defined in control/src/lib/search/types.ts. Expressions
can be serialized as JSON and passed between client and server.

No DB, no HTTP, no framework dependencies -- pure Python + Pydantic.
"""

from typing import Annotated, Literal

from pydantic import BaseModel, Field


class FilterTerm(BaseModel):
    """A single field/operator/value filter -- the leaf node of a FilterExpr.

    Attributes:
        field: The filter field key (e.g. "org_id", "action").
        op: The operator (e.g. "eq", "prefix", "gte"). Defaults to "eq".
        value: The filter value as a string. Type coercion happens at
            compilation time based on the FilterDef.
    """

    type: Literal["term"] = "term"
    field: str
    op: str = "eq"
    value: str


class FilterAnd(BaseModel):
    """Conjunction: all children must match."""

    type: Literal["and"] = "and"
    children: list[FilterExpr] = Field(default_factory=list)


class FilterOr(BaseModel):
    """Disjunction: at least one child must match."""

    type: Literal["or"] = "or"
    children: list[FilterExpr] = Field(default_factory=list)


class FilterNot(BaseModel):
    """Negation: child must not match."""

    type: Literal["not"] = "not"
    child: FilterExpr


class FilterGroup(BaseModel):
    """Explicit grouping (parentheses).

    Semantically identical to its child -- used to preserve user intent
    when round-tripping the expression.
    """

    type: Literal["group"] = "group"
    child: FilterExpr


FilterExpr = Annotated[
    FilterTerm | FilterAnd | FilterOr | FilterNot | FilterGroup,
    Field(discriminator="type"),
]

# Rebuild models now that FilterExpr is defined (forward references)
FilterAnd.model_rebuild()
FilterOr.model_rebuild()
FilterNot.model_rebuild()
FilterGroup.model_rebuild()

EMPTY_FILTER: FilterExpr = FilterAnd(children=[])


def collect_fields(expr: FilterExpr) -> set[str]:
    """Extract all field names from a FilterExpr tree.

    Walks the AST and returns the set of unique field keys referenced by
    FilterTerm nodes. Used to check that required filters are present
    in a parsed expression.
    """
    if isinstance(expr, FilterTerm):
        return {expr.field}
    if isinstance(expr, (FilterAnd, FilterOr)):
        result: set[str] = set()
        for child in expr.children:
            result |= collect_fields(child)
        return result
    if isinstance(expr, (FilterNot, FilterGroup)):
        return collect_fields(expr.child)
    # Unreachable: FilterExpr is a closed union of the five types above.
    return set()  # pragma: no cover
