"""Filtering framework -- transport-agnostic, DB-agnostic.

Pure AST types and filter field definitions. The AST mirrors the client-side
FilterExpr tree (control/src/lib/search/types.ts) so expressions can be
passed from client to server without transformation.

DB-specific compilation lives in database/filtering/.
"""

from sonnet_server.utils.filtering.db_model_walker import JsonColumnBinding, build_filter_defs, filter_defs_from_db_model
from sonnet_server.utils.filtering.filter_defs import FilterDef, FilterOperator, FilterPage, missing_required_filters
from sonnet_server.utils.filtering.parser import parse_query
from sonnet_server.utils.filtering.schema_walker import RefResolver, filter_defs_from_schema
from sonnet_server.utils.filtering.types import (
    EMPTY_FILTER,
    FilterAnd,
    FilterExpr,
    FilterGroup,
    FilterNot,
    FilterOr,
    FilterTerm,
    collect_fields,
)
from sonnet_server.utils.filtering.value_parsers import ParsedCoding, ParsedQuantity, parse_coding, parse_quantity

__all__ = [
    "EMPTY_FILTER",
    "FilterAnd",
    "FilterDef",
    "FilterExpr",
    "FilterGroup",
    "FilterNot",
    "FilterOperator",
    "FilterOr",
    "FilterPage",
    "FilterTerm",
    "ParsedCoding",
    "ParsedQuantity",
    "collect_fields",
    "missing_required_filters",
    "parse_coding",
    "parse_quantity",
    "parse_query",
    "filter_defs_from_schema",
    "JsonColumnBinding",
    "build_filter_defs",
    "filter_defs_from_db_model",
    "RefResolver",
]
