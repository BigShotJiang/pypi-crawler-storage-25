"""Filter field definitions -- declares what is filterable and how.

FilterDef is the contract between the endpoint declaration and the query
compiler. Each def says: this field key maps to this DB column, supports
these operators, and optionally targets a path inside a JSON column.

FilterPage carries the resolved filter expression plus pagination parameters.
It is the type accepted by service methods so they do not depend on FastAPI.

No DB, no HTTP dependencies -- pure data declarations.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING

from pydantic import BaseModel

if TYPE_CHECKING:
    from sonnet_server.utils.filtering.types import FilterExpr


class FilterOperator(StrEnum):
    """Supported filter operators.

    Each operator maps to a specific SQL clause pattern in the compiler.
    Query grammar symbols:

        =        EQ        exact match
        !=       NEQ       not equal
        ~        LIKE      substring / contains  (ILIKE '%val%')
        ^        PREFIX    starts-with           (LIKE 'val%')
        >        GT        greater than
        >=       GTE       greater than or equal
        <        LT        less than
        <=       LTE       less than or equal
        (suffix) IS_NULL   null check (?field__isnull=true/false, case-insensitive)

    IS_NULL is not expressed inline in query expressions. It is activated
    by appending the ``__isnull`` suffix to the flat query param name
    (e.g. ``?parent_id__isnull=true``). The field must declare IS_NULL
    in its FilterDef operators list.

    JSON_PATH_IS_NULL checks whether a path inside a JSONB column is
    NULL or absent. It requires ``json_path`` on the FilterDef. Activated
    via the same ``__isnull`` suffix (e.g. ``?parent_ref__isnull=true``).
    Produces: ``column -> 'key1' -> 'key2' IS NULL``.
    """

    EQ = "eq"
    NEQ = "neq"
    PREFIX = "prefix"
    LIKE = "like"
    GT = "gt"
    GTE = "gte"
    LT = "lt"
    LTE = "lte"
    IN = "in"
    IS_NULL = "isnull"
    JSON_CONTAINS = "json_contains"
    JSON_PATH_IS_NULL = "json_path_isnull"


class FilterDef(BaseModel):
    """Declaration of a filterable field.

    Attributes:
        key: Query parameter / AST field name (e.g. "org_id", "actor_id").
        column: DB column name. Defaults to key when not specified. Override
            when the query param name differs from the column name (e.g.
            key="actor_id", column="actors").
        operators: Allowed operators for this field. The compiler rejects
            any operator not in this list. The first operator is the default
            used when parsing query parameters.
        required: If True, the dependency raises 400 when this filter key
            is absent from the request. Use for mandatory scoping fields
            such as org_id.
        json_path: For JSON columns, the path into the JSON structure to
            match against. E.g. ["id"] for actors column means
            actors @> '[{"id": "value"}]'.
        json_is_array: Whether the JSON column stores an array. When True,
            the containment target is wrapped in a list:
            '[{"id": "value"}]' vs '{"id": "value"}'.
        json_value_type: Typed value parser identifier. When set, the
            compiler parses the filter value as a compound type and produces
            a compound SQL clause. Built-in types: "quantity" (``38.0[Cel]``),
            "coding" (``system|code``). None means plain scalar value.
        label: Human-readable label for documentation and client UI.
            Optional -- the client may define its own labels.
    """

    key: str
    column: str | None = None
    operators: list[FilterOperator]
    required: bool = False
    json_path: list[str] | None = None
    json_is_array: bool = False
    json_value_type: str | None = None
    label: str | None = None

    @property
    def resolved_column(self) -> str:
        """DB column name, defaulting to key when column is not specified."""
        return self.column if self.column is not None else self.key


@dataclass
class FilterPage:
    """Resolved filter expression plus pagination parameters.

    Produced by the HTTP layer (FilterableListParams) and consumed by the
    service layer. Keeping this type in utils/ means service methods never
    need to import from api/.

    Attributes:
        filter_expr: The parsed and merged filter expression tree.
        filter_defs: Filter definitions used to compile the expression.
        limit: Page size.
        offset: Number of records to skip.
    """

    filter_expr: FilterExpr
    filter_defs: list[FilterDef] = field(default_factory=list)
    limit: int = 20
    offset: int = 0


def missing_required_filters(filter_defs: list[FilterDef], present_keys: set[str]) -> list[str]:
    """Return keys of required filter defs absent from present_keys.

    Pure function -- no HTTP, no framework dependencies. Used by endpoint
    layers to enforce required filters before query execution.

    Args:
        filter_defs: All declared filter definitions.
        present_keys: Keys that were present in the request.

    Returns:
        List of required keys that are missing. Empty if all satisfied.
    """
    return [d.key for d in filter_defs if d.required and d.key not in present_keys]
