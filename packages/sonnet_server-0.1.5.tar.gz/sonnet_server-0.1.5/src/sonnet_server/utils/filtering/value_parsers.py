"""Typed value parsers -- reusable building blocks for compound filter values.

This module provides parser functions for common value patterns. These are
**not** automatically wired into the compiler. Domain code registers them
via ``register_typed_value_compiler`` in ``database/filtering/compiler.py``.

No DB, no HTTP dependencies -- pure parsing.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ParsedQuantity:
    """A numeric value with an optional unit."""

    value: str
    unit: str | None = None


@dataclass(frozen=True, slots=True)
class ParsedCoding:
    """A code with an optional system qualifier."""

    system: str | None
    code: str


def parse_quantity(raw: str) -> ParsedQuantity:
    """Parse a quantity value string.

    Syntax: ``<number>`` or ``<number>[<unit>]``

    Examples::

        parse_quantity("38.0")       → ParsedQuantity("38.0", None)
        parse_quantity("38.0[Cel]")  → ParsedQuantity("38.0", "Cel")
        parse_quantity("120[mm[Hg]]") → ParsedQuantity("120", "mm[Hg]")

    Raises:
        ValueError: If the value cannot be parsed.
    """
    raw = raw.strip()
    if not raw:
        raise ValueError("Quantity value must not be empty")

    if "[" in raw:
        first_bracket = raw.index("[")
        if not raw.endswith("]"):
            raise ValueError(f"Invalid quantity value: unclosed bracket in '{raw}'")
        value_part = raw[:first_bracket]
        unit_part = raw[first_bracket + 1 : -1]
        if not value_part:
            raise ValueError(f"Invalid quantity value: no numeric part in '{raw}'")
        return ParsedQuantity(value=value_part, unit=unit_part)

    return ParsedQuantity(value=raw, unit=None)


def parse_coding(raw: str) -> ParsedCoding:
    """Parse a coding value string.

    Syntax: ``<code>`` or ``<system>|<code>``

    The pipe ``|`` separates the optional system qualifier from the code.
    The system part can be a full URI or a short alias -- resolution of
    aliases to full URIs is the responsibility of the caller.

    Examples::

        parse_coding("ABC123")                                     → ParsedCoding(None, "ABC123")
        parse_coding("http://systems.example.com/colors|ABC123")   → ParsedCoding("http://systems.example.com/colors", "ABC123")
        parse_coding("my_system|ABC123")                           → ParsedCoding("my_system", "ABC123")

    Raises:
        ValueError: If the value is empty or the code part is empty.
    """
    raw = raw.strip()
    if not raw:
        raise ValueError("Coding value must not be empty")

    if "|" in raw:
        system, code = raw.split("|", 1)
        system = system.strip()
        code = code.strip()
        if not code:
            raise ValueError(f"Invalid coding value: no code after '|' in '{raw}'")
        return ParsedCoding(system=system or None, code=code)

    return ParsedCoding(system=None, code=raw)
