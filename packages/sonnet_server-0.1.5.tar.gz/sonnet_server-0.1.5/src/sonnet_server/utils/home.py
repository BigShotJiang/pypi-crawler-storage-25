"""Utilities for the home page template."""

from importlib.resources import files as pkg_files
from pathlib import Path


def get_home_template_dir(override: Path | str | None = None) -> str:
    """Return the directory containing the home page template.

    Consumers can provide their own ``home/`` directory containing an
    ``index.html`` template to replace the default sonnet-server splash page.
    If no override is given, the built-in sonnet-server template is used.

    The returned directory is suitable for passing directly to
    ``fastapi.templating.Jinja2Templates``.

    Args:
        override: Path to a directory containing a custom ``index.html``.
                  When ``None`` (default), uses the built-in template.

    Returns:
        Absolute path to the template directory as a string.

    Example::

        # Use built-in template with custom title
        template_dir = get_home_template_dir()

        # Use consumer-supplied template
        from importlib.resources import files as pkg_files
        template_dir = get_home_template_dir(
            pkg_files("my_server").joinpath("home")
        )
    """
    if override is not None:
        return str(override)
    return str(pkg_files("sonnet_server").joinpath("home"))
