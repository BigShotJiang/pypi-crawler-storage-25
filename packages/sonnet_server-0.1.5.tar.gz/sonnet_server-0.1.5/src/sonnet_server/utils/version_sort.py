"""Version comparison and sorting utilities.

Provides a cross-cutting mechanism for determining "latest" among
multiple versions of the same logical resource (identified by URI or
name). Aligned with FHIR R5 CodeSystem.versionAlgorithm.

Supported algorithms:
    natural  -- natural sort (default). Splits on digit/non-digit
                boundaries and compares segments numerically where
                possible. Handles "2025", "10", "1.2.3" correctly.
    semver   -- semantic versioning (major.minor.patch). Pre-release
                labels sort lower than release.
    integer  -- numeric cast. Non-numeric values sort to -inf.
    date     -- ISO date string comparison (lexicographic on ISO dates).
    alpha    -- case-insensitive alphabetical.

Usage:
    from sonnet_server.utils.version_sort import pick_latest

    latest = pick_latest(rows, key=lambda r: r.content_version,
                         algorithm=r.version_algorithm)
"""

import re

from loguru import logger

VALID_ALGORITHMS = ("natural", "semver", "integer", "date", "alpha")
DEFAULT_ALGORITHM = "natural"


def _natural_sort_key(version: str) -> list:
    """Split version string into numeric and non-numeric segments for natural comparison."""
    parts = re.split(r"(\d+)", version)
    return [int(p) if p.isdigit() else p.lower() for p in parts if p]


def _semver_sort_key(version: str) -> tuple:
    """Parse a semver-like string into a comparable tuple.

    Handles major.minor.patch with optional pre-release suffix.
    Non-conforming strings fall back to natural sort key.
    """
    match = re.match(r"^(\d+)(?:\.(\d+))?(?:\.(\d+))?(?:-(.+))?$", version)
    if not match:
        return (0, 0, 0, 0, _natural_sort_key(version))
    major = int(match.group(1))
    minor = int(match.group(2) or 0)
    patch = int(match.group(3) or 0)
    # Pre-release sorts lower than release (release = no suffix = high).
    pre = match.group(4)
    pre_rank = 0 if pre else 1
    pre_key = _natural_sort_key(pre) if pre else []
    return (major, minor, patch, pre_rank, pre_key)


def _integer_sort_key(version: str) -> int:
    """Parse version as integer. Non-numeric values sort to lowest."""
    try:
        return int(version)
    except ValueError, TypeError:
        return -1


def _date_sort_key(version: str) -> str:
    """ISO date strings are lexicographically sortable."""
    return version


def _alpha_sort_key(version: str) -> str:
    """Case-insensitive alphabetical comparison."""
    return version.lower()


def version_sort_key(version: str, algorithm: str = DEFAULT_ALGORITHM):
    """Return a sort key for the given version string and algorithm.

    Args:
        version: The version string to produce a sort key for.
        algorithm: One of the VALID_ALGORITHMS.

    Returns:
        A comparable value suitable for sorted() or max().
    """
    if algorithm == "natural":
        return _natural_sort_key(version)
    if algorithm == "semver":
        return _semver_sort_key(version)
    if algorithm == "integer":
        return _integer_sort_key(version)
    if algorithm == "date":
        return _date_sort_key(version)
    if algorithm == "alpha":
        return _alpha_sort_key(version)
    logger.warning("Unknown version_algorithm '{}', falling back to natural", algorithm)
    return _natural_sort_key(version)


def pick_latest(rows, *, version_key, algorithm_key=None, status_key=None, algorithm: str | None = None):
    """Pick the latest row from a list, preferring active status and highest version.

    Args:
        rows: Iterable of row objects (must be non-empty).
        version_key: Callable that extracts the version string from a row.
        algorithm_key: Callable that extracts the version_algorithm from a row.
                       Ignored if ``algorithm`` is explicitly provided.
        status_key: Callable that extracts the status string from a row.
                    When provided, active rows are preferred over non-active.
        algorithm: Explicit algorithm override. When set, algorithm_key is ignored.

    Returns:
        The single "latest" row.

    Raises:
        ValueError: If rows is empty.
    """
    items = list(rows)
    if not items:
        raise ValueError("Cannot pick latest from empty list")
    if len(items) == 1:
        return items[0]

    # Determine algorithm from the first row if not explicitly provided.
    if algorithm is None and algorithm_key is not None:
        algorithm = algorithm_key(items[0]) or DEFAULT_ALGORITHM
    if algorithm is None:
        algorithm = DEFAULT_ALGORITHM

    def sort_key(row):
        # Primary: active status preferred (1 = active, 0 = other).
        active_rank = 0
        if status_key is not None:
            active_rank = 1 if status_key(row) == "active" else 0
        # Secondary: version comparison.
        ver = version_key(row) or ""
        return (active_rank, version_sort_key(ver, algorithm))

    return max(items, key=sort_key)
