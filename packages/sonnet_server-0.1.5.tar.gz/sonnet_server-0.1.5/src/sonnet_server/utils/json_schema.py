"""JSON Schema validation utilities.

Thin wrapper around the ``jsonschema`` library. All JSON Schema
validation in the application flows through this module so that the
underlying library can be replaced without touching callers.

Two concerns are addressed:

1. **Meta-validation** -- verify that a dict is a valid JSON Schema
   document conforming to Draft 2020-12.
2. **Instance validation** -- verify that a JSON-compatible value
   conforms to a given JSON Schema document, with optional external
   ``$ref`` resolution via a caller-supplied callback.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from jsonschema import Draft202012Validator, SchemaError, ValidationError
from referencing import Registry, Resource
from referencing.exceptions import Unresolvable
from referencing.jsonschema import DRAFT202012

# -- Result types -----------------------------------------------------------


@dataclass(frozen=True, slots=True)
class SchemaValidationError:
    """Single validation error with location context."""

    message: str
    path: list[str] = field(default_factory=list)
    schema_path: list[str] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class ValidationResult:
    """Outcome of a validation call.

    ``valid`` is True when no errors were found. ``errors`` contains
    structured error details when validation fails.
    """

    valid: bool
    errors: list[SchemaValidationError] = field(default_factory=list)


# -- Public API -------------------------------------------------------------


def validate_schema(document: dict[str, Any]) -> ValidationResult:
    """Validate that *document* is a valid JSON Schema (Draft 2020-12).

    Unknown keywords (e.g. ``x-ui-widget``) are allowed per spec -- they
    are treated as annotations and do not cause validation failures.

    Args:
        document: The schema document to validate.

    Returns:
        ValidationResult indicating success or listing errors.
    """
    try:
        Draft202012Validator.check_schema(document)
    except SchemaError as exc:
        errors = [
            SchemaValidationError(
                message=exc.message,
                path=[str(p) for p in exc.path],
                schema_path=[str(p) for p in exc.schema_path],
            ),
        ]
        return ValidationResult(valid=False, errors=errors)
    return ValidationResult(valid=True)


def validate_instance(
    instance: Any,
    schema: dict[str, Any],
    resolve_ref: Callable[[str], dict[str, Any]] | None = None,
) -> ValidationResult:
    """Validate a JSON-compatible *instance* against a JSON Schema.

    The schema is assumed to be valid (call :func:`validate_schema`
    first if unsure). Collects all errors rather than failing on the
    first one.

    Local ``$ref`` references (``#/$defs/...``) are resolved
    automatically by the underlying library. External ``$ref`` URIs
    (e.g. ``urn:example:address``) require a *resolve_ref* callback that
    maps a URI string to the referenced schema document. This keeps the
    public API library-agnostic -- callers never import the underlying
    ``referencing`` package.

    Args:
        instance: The value to validate (dict, list, scalar, ...).
        schema: A valid JSON Schema document (Draft 2020-12).
        resolve_ref: Optional callback that resolves an external ``$ref``
            URI to a JSON Schema document (plain dict).  When *None*,
            external ``$ref`` URIs will produce a validation error.
            The callback should raise ``KeyError`` if the URI cannot be
            resolved; this is translated into a validation error.

    Returns:
        ValidationResult indicating success or listing all errors.

    Example::

        # Schema that references an external definition by URI.
        schema = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "address": {"$ref": "urn:example:address"},
            },
            "required": ["name", "address"],
        }

        # A lookup function that returns the referenced schema dict.
        # In practice this would call SchemaRegistryClient.get_schema().
        def resolve_ref(uri: str) -> dict:
            schemas = {
                "urn:example:address": {
                    "type": "object",
                    "properties": {
                        "street": {"type": "string"},
                        "city": {"type": "string"},
                    },
                    "required": ["street", "city"],
                },
            }
            return schemas[uri]  # KeyError if unknown

        result = validate_instance(
            {"name": "Alice", "address": {"street": "1 Main St", "city": "Zurich"}},
            schema,
            resolve_ref=resolve_ref,
        )
        assert result.valid is True
    """
    registry = _build_registry(resolve_ref) if resolve_ref is not None else Registry()
    validator = Draft202012Validator(schema, registry=registry)

    try:
        raw_errors: list[ValidationError] = sorted(
            validator.iter_errors(instance),
            key=lambda e: list(e.path),
        )
    except Unresolvable as exc:
        # An external $ref could not be resolved.
        return ValidationResult(
            valid=False,
            errors=[SchemaValidationError(message=f"Unresolvable $ref: {exc}")],
        )

    if not raw_errors:
        return ValidationResult(valid=True)

    errors = [
        SchemaValidationError(
            message=err.message,
            path=[str(p) for p in err.path],
            schema_path=[str(p) for p in err.schema_path],
        )
        for err in raw_errors
    ]
    return ValidationResult(valid=False, errors=errors)


# -- Internal helpers -------------------------------------------------------


def _build_registry(resolve_ref: Callable[[str], dict[str, Any]]) -> Registry:
    """Build a ``referencing.Registry`` backed by *resolve_ref*.

    The registry uses lazy retrieval: schemas are fetched on demand the
    first time a ``$ref`` URI is encountered during validation. This
    keeps the public API library-agnostic -- callers provide a plain
    ``Callable[[str], dict]`` and never import ``referencing`` directly.
    """

    def _retrieve(uri: str) -> Resource:
        # Let KeyError propagate -- referencing catches it and raises
        # Unresolvable, which we handle in validate_instance.
        contents = resolve_ref(uri)
        return Resource.from_contents(contents, default_specification=DRAFT202012)

    return Registry(retrieve=_retrieve)
