"""Model builder utilities for creating Pydantic models dynamically."""

import types
from typing import Any, Union, get_args, get_origin

from pydantic import BaseModel
from pydantic import create_model as pydantic_create_model


def _unwrap_optional(annotation: Any) -> Any:
    """Unwrap ``T | None`` to ``T``.

    If the annotation is a Union of exactly one concrete type and
    ``NoneType``, returns the concrete type. Otherwise returns the
    annotation unchanged.
    """
    origin = get_origin(annotation)
    if origin is Union or origin is types.UnionType:
        args = [a for a in get_args(annotation) if a is not type(None)]
        if len(args) == 1:
            return args[0]
    return annotation


class ModelBuilder:
    """Builder class for creating models with a fluent API."""

    def __init__(self, base_model: type[BaseModel]):
        """Initialize the builder with a base model.

        Args:
            base_model: The base model to inherit from
        """
        self.base_model = base_model
        self.model_name = None
        self.included_fields = None
        self.excluded_fields = None
        self.required_fields: list[str] | None = None
        self.model_config = None
        self.field_overrides = {}
        self.all_fields = True
        self.api_model = False

    def with_name(self, name: str) -> ModelBuilder:
        """Set the name for the model.

        Args:
            name: Name for the new model

        Returns:
            Self for method chaining
        """
        self.model_name = name
        return self

    def include(self, fields: list[str]) -> ModelBuilder:
        """Include only specified fields from the base model.

        Args:
            fields: List of field names to include

        Returns:
            Self for method chaining
        """
        self.included_fields = fields
        self.excluded_fields = None
        return self

    def exclude(self, fields: list[str]) -> ModelBuilder:
        """Exclude specified fields from the base model.

        Args:
            fields: List of field names to exclude

        Returns:
            Self for method chaining
        """
        self.excluded_fields = fields
        self.included_fields = None
        return self

    def require(self, fields: list[str]) -> ModelBuilder:
        """Mark fields as required (strip Optional and remove default).

        Use this to promote nullable base-model fields to required in
        derived API input models. The field's inner type is unwrapped
        from ``T | None`` and the default is removed so Pydantic treats
        it as required.

        Args:
            fields: List of field names to make required.

        Returns:
            Self for method chaining.
        """
        self.required_fields = fields
        return self

    def with_config(self, config: dict[str, Any]) -> ModelBuilder:
        """Set model configuration.

        Args:
            config: Dictionary with model configuration

        Returns:
            Self for method chaining
        """
        self.model_config = config
        return self

    def with_all_fields(self, all_fields: bool) -> ModelBuilder:
        """Set whether to include all fields from the base model.

        Only relevant if neither include nor exclude is specified.

        Args:
            all_fields: Whether to include all fields from the base model

        Returns:
            Self for method chaining
        """
        self.all_fields = all_fields
        return self

    def with_api_model(self, api_model: bool) -> ModelBuilder:
        """Set whether this is an API model.

        If true, will add {"extra": "forbid"} to the model config
        unless explicitly overridden by with_config.

        Args:
            api_model: Whether this is an API model

        Returns:
            Self for method chaining
        """
        self.api_model = api_model
        return self

    def override_field(self, field_name: str, annotation: Any, default: Any = ...) -> ModelBuilder:
        """Override a field's type and default value.

        Args:
            field_name: Name of the field to override
            annotation: Type annotation for the field
            default: Default value for the field

        Returns:
            Self for method chaining
        """
        self.field_overrides[field_name] = (annotation, default)
        return self

    def _get_field_default(self, field_info) -> Any:
        """Extract the default value from a field.

        Args:
            field_info: Field information from the model

        Returns:
            Default value or ... if no default
        """
        return field_info.default if field_info.default is not ... else ...

    def _validate_required_fields(self, required: set[str]) -> None:
        """Raise ValueError if any required field name is not on the base model."""
        for req in required:
            if req not in self.base_model.model_fields:
                msg = f"required_fields: '{req}' does not exist on {self.base_model.__name__}"
                raise ValueError(msg)

    def _resolve_field(
        self,
        field_name: str,
        required: set[str],
        fields: dict[str, tuple[Any, Any]],
    ) -> None:
        """Add a single field to the output dict, applying required promotion if needed.

        When not promoting to required, the full FieldInfo is passed so that
        aliases, serialization aliases, and other field metadata are preserved
        in the derived model.
        """
        if field_name not in self.base_model.model_fields:
            return
        field_info = self.base_model.model_fields[field_name]
        if field_name in required:
            # Required promotion: strip Optional and remove default/FieldInfo.
            # Aliases are intentionally dropped here -- required fields in
            # Input models are typically populated by field name, not alias.
            fields[field_name] = (_unwrap_optional(field_info.annotation), ...)
        else:
            # Preserve full FieldInfo so aliases and other metadata carry through.
            fields[field_name] = (field_info.annotation, field_info)

    def _get_included_fields(self) -> dict[str, tuple[Any, Any]]:
        """Get fields to include based on include/exclude settings.

        Returns:
            Dictionary of field definitions
        """
        required = set(self.required_fields) if self.required_fields else set()
        self._validate_required_fields(required)

        fields: dict[str, tuple[Any, Any]] = {}

        if self.included_fields is not None:
            # Case 1: Only include specified fields
            for field in self.included_fields:
                self._resolve_field(field, required, fields)
        elif self.excluded_fields is not None:
            # Case 2: Include all fields except those explicitly excluded
            for field in self.base_model.model_fields:
                if field not in self.excluded_fields:
                    self._resolve_field(field, required, fields)
        elif self.all_fields:
            # Case 3: Include all fields
            for field in self.base_model.model_fields:
                self._resolve_field(field, required, fields)

        return fields

    def _create_model(self, fields: dict[str, tuple[Any, Any]]) -> type[BaseModel]:
        """Create a Pydantic model with the given fields.

        Args:
            fields: Dictionary of field definitions

        Returns:
            New Pydantic model
        """
        model_config = self.model_config or {}
        if self.api_model and "extra" not in model_config:
            model_config["extra"] = "forbid"
        model = pydantic_create_model(self.model_name, __module__=__name__, **fields)
        model.model_config.update(model_config)
        return model

    def build(self) -> type[BaseModel]:
        """Build and return the model.

        Returns:
            A new Pydantic model with the selected fields

        Raises:
            ValueError: If model_name is not set
        """
        if not self.model_name:
            raise ValueError("Model name must be set using with_name() before building")
        fields = self._get_included_fields()
        fields.update(self.field_overrides)
        return self._create_model(fields)


def create_model_builder(base_model: type[BaseModel]) -> ModelBuilder:
    """Create a model builder for the given base model.

    Args:
        base_model: The base model to inherit from

    Returns:
        A ModelBuilder instance for fluent API usage
    """
    return ModelBuilder(base_model)


def create_model(
    base_model: type[BaseModel],
    name: str,
    fields: list[str] | None = None,
    excluded_fields: list[str] | None = None,
    required_fields: list[str] | None = None,
    config: dict[str, Any] | None = None,
    field_overrides: dict[str, tuple[Any, Any]] | None = None,
    all_fields: bool = True,
    api_model: bool = False,
    **field_override_kwargs: Any,
) -> type[BaseModel]:
    """Create a model based on a base model with various customizations.

    This is a unified function that can handle all model creation cases:
    - Create a model with only specified fields (include)
    - Create a model excluding specified fields (exclude)
    - Create a complete model with all fields

    Args:
        base_model: The base model to inherit from
        name: Name for the new model
        fields: Optional list of field names to include (takes precedence over excluded_fields)
        excluded_fields: Optional list of field names to exclude (only used if fields is None)
        required_fields: Optional list of field names to make required. Strips
            ``T | None`` to ``T`` and removes the default so Pydantic treats
            the field as mandatory. Useful for Input models where the base
            model has all fields nullable.
        config: Optional model configuration
        field_overrides: Optional field overrides as {field_name: (annotation, default)}
        all_fields: Whether to include all fields from the base model (only used if fields and excluded_fields are None)
        api_model: Whether this is an API model (if true, adds {"extra": "forbid"} to config unless explicitly overridden)
        **field_override_kwargs: Direct field overrides as keyword arguments
            Format: field_name=(annotation, default)

    Returns:
        A new Pydantic model with the selected fields

    Examples:
        # Create a model with only specific fields
        OrganizationResponse = create_model(
            OrganizationBase,
            "OrganizationResponse",
            fields=["id", "org_id", "name"],
        )

        # Create a model excluding specific fields
        OrganizationInput = create_model(
            OrganizationBase,
            "OrganizationInput",
            excluded_fields=["id", "org_id", "version"],
        )

        # Create an input model with required fields
        UserInput = create_model(
            UserBase,
            "UserInput",
            excluded_fields=["id", "user_id", "status"],
            required_fields=["username"],
            api_model=True,
        )

        # Create an API model with extra fields forbidden
        OrganizationUpdate = create_model(
            OrganizationBase,
            "OrganizationUpdate",
            api_model=True,
        )
    """
    builder = create_model_builder(base_model).with_name(name).with_all_fields(all_fields)
    if fields is not None:
        builder = builder.include(fields)
    elif excluded_fields is not None:
        builder = builder.exclude(excluded_fields)
    if required_fields:
        builder = builder.require(required_fields)
    if config:
        builder = builder.with_config(config)
    if field_overrides:
        for field_name, (annotation, default) in field_overrides.items():
            builder = builder.override_field(field_name, annotation, default)
    for field_name, override in field_override_kwargs.items():
        if isinstance(override, tuple) and len(override) == 2:
            annotation, default = override
            builder = builder.override_field(field_name, annotation, default)
    builder = builder.with_api_model(api_model)
    return builder.build()
