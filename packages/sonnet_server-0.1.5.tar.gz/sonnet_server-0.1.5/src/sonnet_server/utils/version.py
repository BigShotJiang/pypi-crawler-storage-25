"""Version utility module for Sonnet server.

Uses importlib.metadata to read version from setuptools-scm (derived from git tags).
"""

import re
from importlib.metadata import PackageNotFoundError, version

from loguru import logger
from pydantic import BaseModel


class VersionInfo(BaseModel):
    """Version information model."""

    full_version: str
    version: str
    post_count: str | None = None
    git_commit: str | None = None
    is_dirty: bool = False
    build_timestamp: str | None = None


def get_version(package: str = "sonnet_server") -> VersionInfo:
    """Get the version information for a package with fallback for development.

    Args:
        package: The importlib.metadata package name to read the version from.
            Defaults to ``"sonnet_server"``. Consumer projects pass their own
            package name, e.g. ``get_version("cypher_graphdb_server")``.

    Returns:
        VersionInfo model with parsed version components.
    """
    try:
        full_version = version(package)
        logger.info("Package version: {}", full_version)
        base_version, post_count, git_commit, is_dirty, build_timestamp = parse_version(full_version)
    except PackageNotFoundError:
        logger.warning("Package not installed, using fallback version")
        full_version = "0.0.0-dev"
        base_version = full_version
        post_count = None
        git_commit = None
        is_dirty = False
        build_timestamp = None

    return VersionInfo(
        version=base_version,
        full_version=full_version,
        post_count=post_count,
        git_commit=git_commit,
        is_dirty=is_dirty,
        build_timestamp=build_timestamp,
    )


def parse_version(version_str: str) -> tuple[str, str | None, str | None, bool, str | None]:
    """Parse version string into its components.

    Args:
        version_str: Version string (e.g., "0.1.0", "0.1.1.dev5+g7295a81.d20260308")

    Returns:
        tuple of (base_version, post_count, git_commit, is_dirty, build_timestamp)
    """
    base_version_match = re.match(r"^(\d+\.\d+\.\d+)", version_str)
    base_version = base_version_match.group(1) if base_version_match else version_str

    post_match = re.search(r"\.(?:post|dev)(\d+)", version_str)
    post_count = post_match.group(1) if post_match else None

    git_match = re.search(r"\+g([a-f0-9]+)", version_str)
    git_commit = git_match.group(1) if git_match else None

    is_dirty = ".d" in version_str and bool(re.search(r"\.d\d{8}", version_str))

    timestamp_match = re.search(r"\.d(\d{8})", version_str)
    build_timestamp = timestamp_match.group(1) if timestamp_match else None

    return base_version, post_count, git_commit, is_dirty, build_timestamp
