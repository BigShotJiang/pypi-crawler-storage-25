"""Utility package for the Sonnet server.

Public surface for the utils module::

    from sonnet_server.utils import (
        ModelBuilder, create_model, create_model_builder,
        to_response_model, update_model_fields,
        generate_short_id, to_base36,
        SchemaValidationError, ValidationResult, validate_instance, validate_schema,
        resolve_list_page, strawberry_to_pydantic,
        get_version, parse_version, VersionInfo, pick_latest,
        get_content_type_from_path, get_mime_type_from_path,
    )
"""

from sonnet_server.utils.file_utils import get_content_type_from_path, get_mime_type_from_path
from sonnet_server.utils.home import get_home_template_dir
from sonnet_server.utils.id_generator import generate_short_id, to_base36
from sonnet_server.utils.json_schema import SchemaValidationError, ValidationResult, validate_instance, validate_schema
from sonnet_server.utils.model_builder import ModelBuilder, create_model, create_model_builder
from sonnet_server.utils.model_converter import to_response_model, update_model_fields
from sonnet_server.utils.version import VersionInfo, get_version, parse_version
from sonnet_server.utils.version_sort import pick_latest


def __getattr__(name: str):
    """Lazily expose graphql utilities to avoid circular import with database.crud."""
    if name in ("resolve_list_page", "strawberry_to_pydantic"):
        from sonnet_server.utils import graphql as _gql

        return getattr(_gql, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Model builder
    "ModelBuilder",
    "create_model",
    "create_model_builder",
    # Model converter
    "to_response_model",
    "update_model_fields",
    # ID generation
    "generate_short_id",
    "to_base36",
    # JSON schema
    "SchemaValidationError",
    "ValidationResult",
    "validate_instance",
    "validate_schema",
    # GraphQL utilities
    "resolve_list_page",
    "strawberry_to_pydantic",
    # Version utilities
    "VersionInfo",
    "get_version",
    "parse_version",
    "pick_latest",
    # File utilities
    "get_content_type_from_path",
    "get_mime_type_from_path",
    # Home template (internal use, kept for backward compat)
    "get_home_template_dir",
]
