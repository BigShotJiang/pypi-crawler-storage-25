"""Generic GraphQL resolver utilities.

Shared helpers that any GraphQL resolver can use to expose list endpoints
with search and pagination via the existing filtering framework.

GraphQL list resolvers use the base CrudRepository.list_page directly
(bypassing any service-level override) because service overrides accept a
FilterPage object -- a REST-layer concept. GraphQL resolvers own their own
search/filter translation and call the base implementation with raw kwargs.
"""

from typing import Any

from pydantic import BaseModel

from sonnet_server.database.crud import CrudRepository
from sonnet_server.database.filtering import compile_filter
from sonnet_server.utils.filtering import FilterDef, parse_query
from sonnet_server.utils.filtering.types import FilterExpr

_MAX_LIMIT = 200


def strawberry_to_pydantic[T: BaseModel](strawberry_obj: Any, model_class: type[T]) -> T:
    """Convert a Strawberry input object to a Pydantic model preserving unset semantics.

    Strawberry's default to_pydantic() sets all fields explicitly (unset optional
    fields become None), so Pydantic considers every field "set". This breaks
    model_dump(exclude_unset=True) in update operations -- the service layer
    applies None to fields the client never sent, causing constraint violations.

    This helper constructs the Pydantic model with only the fields that have
    non-None values, and marks exactly those as the "fields_set" so that
    exclude_unset=True works correctly downstream.

    Limitation: cannot distinguish "client sent null" from "client did not send
    the field" -- both map to None and are excluded. This is acceptable for
    update inputs where optional fields are either provided with a value or
    omitted entirely.

    Args:
        strawberry_obj: The Strawberry input type instance.
        model_class: The target Pydantic model class.

    Returns:
        A Pydantic model instance with only the provided fields marked as set.
    """
    provided = {k: v for k, v in vars(strawberry_obj).items() if v is not None}
    return model_class.model_construct(_fields_set=set(provided.keys()), **provided)


def resolve_list_page(
    service: CrudRepository,
    *,
    search: str | None = None,
    limit: int = 50,
    filter_defs: list[FilterDef] | None = None,
    q: str | None = None,
) -> list[Any]:
    """Resolve a paginated list with optional search and filter expression.

    Designed for use in GraphQL resolvers. Calls CrudRepository.list_page
    directly on the base class so that service-level overrides (which accept
    a FilterPage) are bypassed. GraphQL resolvers handle their own filtering.

    For simple substring search, pass search= and leave filter_defs/q as None.
    For expression-based filtering (q= grammar), pass filter_defs and q.
    Both can be combined -- they are AND-merged before compilation.

    Args:
        service: The CrudRepository subclass instance (e.g. OrganizationService).
        search: Optional substring search term. Applied as ILIKE on the
            CrudConfig.search_field when set.
        limit: Maximum records to return. Capped at _MAX_LIMIT.
        filter_defs: Declared FilterDef list for expression-based filtering.
            Required when q= is used.
        q: Optional filter expression string (same grammar as the REST q=
            param). Parsed via parse_query and compiled against filter_defs.

    Returns:
        List of response model instances.
    """
    capped_limit = min(max(1, limit), _MAX_LIMIT)

    if q and filter_defs:
        expr: FilterExpr = parse_query(q)
        clause = compile_filter(expr, service.crud_config.db_model, filter_defs)
        return CrudRepository.list_page(
            service,
            limit=capped_limit,
            offset=0,
            filters=[clause],
            search=search,
        ).data

    return CrudRepository.list_page(
        service,
        limit=capped_limit,
        offset=0,
        search=search,
    ).data
