"""Generic pagination response models.

PageResult is the standard envelope for offset-paginated list endpoints.
All REST list endpoints that use offset pagination return this shape.
"""

from typing import Generic, TypeVar

from pydantic import BaseModel

T = TypeVar("T")


class PageMeta(BaseModel):
    """Pagination metadata included in every paginated list response."""

    total: int
    limit: int
    offset: int
    has_next: bool
    has_prev: bool


class PageResult(BaseModel, Generic[T]):
    """Standard envelope for offset-paginated list endpoints.

    Attributes:
        data: The page of items.
        meta: Pagination metadata (total, limit, offset, has_next, has_prev).

    Example response:
        {
            "data": [...],
            "meta": {
                "total": 342,
                "limit": 20,
                "offset": 0,
                "has_next": true,
                "has_prev": false
            }
        }
    """

    data: list[T]
    meta: PageMeta

    @classmethod
    def of(cls, items: list[T], total: int, limit: int, offset: int) -> PageResult[T]:
        """Construct a PageResult from query results and pagination params.

        Args:
            items: The page of items.
            total: Total number of matching records across all pages.
            limit: Page size used for this query.
            offset: Offset used for this query.

        Returns:
            PageResult with computed has_next / has_prev.
        """
        return cls(
            data=items,
            meta=PageMeta(
                total=total,
                limit=limit,
                offset=offset,
                has_next=offset + len(items) < total,
                has_prev=offset > 0,
            ),
        )
