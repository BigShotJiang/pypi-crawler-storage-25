"""Readiness pipeline stage definitions.

Each stage is a marker class decorated with @readiness_stage. Checks
reference these classes for type-safe stage assignment.
"""

from sonnet_server.readiness_pipeline.registry import readiness_stage


@readiness_stage(order=1, is_critical=False, fail_fast=True)
class DatabaseStage:
    """Database connectivity and schema validation."""


@readiness_stage(order=2, is_critical=False, fail_fast=False)
class MessagingStage:
    """Message broker connectivity."""


@readiness_stage(order=3, is_critical=False, fail_fast=False)
class CacheStoreStage:
    """Cache store connectivity (only when DISTRIBUTED or NEAR_CACHE caches are registered)."""
