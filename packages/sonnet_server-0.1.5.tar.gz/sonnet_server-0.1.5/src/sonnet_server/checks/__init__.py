"""Readiness check registry and pipeline factory.

The pipeline is built from the global ``@readiness_stage`` /
``@readiness_check`` decorator registries. Checks and stages are
registered when their modules are imported.

Stage registration ownership
-----------------------------
``stages.py`` is imported here once, making ``checks/__init__`` the single
owner of stage registration. Extensions import only their own check modules
(e.g. ``database_health_check``, ``messaging_check``) -- not ``stages``.
The stage classes already exist in the registry by the time extension check
modules reference them.

Extension check activation
---------------------------
Extensions are responsible for importing their check modules during
``on_startup()``. This ensures only checks for active extensions appear
in the pipeline. If no extensions import check modules, the pipeline
contains stages with no checks and the server starts in OPERATIONAL state.

Pipeline construction
----------------------
``get_readiness_pipeline`` is intentionally not cached. The pipeline is
built from the global decorator registries at call time. Because extensions
import check modules during startup, caching the pipeline would require
strict call ordering guarantees. Building fresh on each call is cheap
(two small registry iterations) and removes the ordering dependency.
"""

from sonnet_server.readiness_pipeline import ReadinessPipeline
from sonnet_server.readiness_pipeline.registry import build_pipeline_from_registry

from . import stages as _stages  # noqa: F401 -- registers all stage classes once


def get_readiness_pipeline() -> ReadinessPipeline:
    """Build the readiness pipeline from all registered stages and checks.

    Stages are always present (registered by importing this module).
    Checks appear only for extensions that imported their check modules
    during ``on_startup``.

    Returns:
        ReadinessPipeline: A freshly built pipeline instance.
    """
    return build_pipeline_from_registry()


__all__ = [
    "get_readiness_pipeline",
]
