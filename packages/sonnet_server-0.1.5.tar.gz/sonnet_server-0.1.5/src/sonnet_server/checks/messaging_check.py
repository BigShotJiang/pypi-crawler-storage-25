"""Messaging channel readiness check for the readiness pipeline."""

from loguru import logger

from sonnet_server.checks.stages import MessagingStage
from sonnet_server.readiness_pipeline import ReadinessCheck, ReadinessCheckResult
from sonnet_server.readiness_pipeline.registry import readiness_check


@readiness_check(stage=MessagingStage, is_critical=False, run_once=True)
class MessagingCheck(ReadinessCheck):
    """Readiness check for the internal messaging channel.

    Verifies that the messaging router is bootstrapped and the transport
    is reachable (SELECT 1 for Postgres, no-op for in-process). Reports
    channel type and name.
    """

    def __init__(self, name: str = "messaging_check", is_critical: bool = False, run_once: bool = True):
        """Initialize the messaging check.

        Args:
            name: Name of this check.
            is_critical: Whether failure stops the pipeline stage.
                         Defaults to False -- messaging issues should not
                         prevent the server from starting.
            run_once: Cache the result (default True -- topology is fixed at startup).
        """
        super().__init__(name, is_critical, run_once)

    def _execute(self) -> ReadinessCheckResult:
        """Inspect the bootstrapped message router and report channel info."""
        logger.info("Checking messaging channel configuration")

        try:
            from sonnet_server.messaging import get_message_router
            from sonnet_server.messaging.types import get_channel_factory

            router = get_message_router()
            factory = get_channel_factory()
            channel_names = router.get_sink_names()

            # Common detail fields included in every outcome
            infra = {
                "available_schemes": factory.schemes,
                "sink_count": len(router.sink_names),
                "handler_count": router.handler_count,
            }

            if not channel_names:
                return self.warning(
                    "Messaging router has no channels configured",
                    {"channel_type": "none", "channel_name": "none", **infra},
                )

            channel_name = channel_names[0]
            channel = router.get_sink(channel_name)
            channel_type = type(channel).__name__

            reachable = channel.ping()
            logger.debug("Messaging: channel={} ({}) reachable={}", channel_name, channel_type, reachable)

            if not reachable:
                return self.failed(
                    f"Messaging channel '{channel_name}' ({channel_type}) transport unreachable",
                    {"channel_type": channel_type, "channel_name": channel_name, **infra},
                )

            return self.success(
                f"Messaging channel '{channel_name}' ({channel_type}) ready",
                {"channel_type": channel_type, "channel_name": channel_name, **infra},
            )

        except (ImportError, OSError, RuntimeError, ValueError) as e:
            logger.error("Messaging check failed: {}", e)
            return self.failed(f"Messaging check failed: {e}")
