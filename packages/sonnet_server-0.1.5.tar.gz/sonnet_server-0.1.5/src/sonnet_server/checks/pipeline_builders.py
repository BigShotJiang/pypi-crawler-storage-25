"""Reusable pipeline stage builders for Sonnet server template.

This module provides functions to build common pipeline stages that can be
reused across different applications.
"""

from sonnet_server.constants import STAGE_DATABASE, STAGE_MESSAGING
from sonnet_server.readiness_pipeline import ReadinessPipelineBuilder

# Import essential checks only
from .database_health_check import DatabaseHealthCheck
from .database_initialization import DatabaseInitializationCheck
from .database_schema_check import DatabaseSchemaCheck
from .messaging_check import MessagingCheck


def add_database_stage(builder: ReadinessPipelineBuilder) -> ReadinessPipelineBuilder:
    """Add database validation stage to pipeline.

    Includes:
    - Database initialization check
    - Database health check
    - Database schema check (validates schema state, no auto-migration)

    Args:
        builder: Pipeline builder to add stage to

    Returns:
        Builder with database stage added (for chaining)
    """
    (
        builder.add_stage(
            name=STAGE_DATABASE,
            description="Database checks",
            is_critical=False,
            fail_fast=True,
        )
        .add_check(DatabaseInitializationCheck())
        .add_check(DatabaseHealthCheck())
        .add_check(DatabaseSchemaCheck())
    )
    return builder


def add_messaging_stage(builder: ReadinessPipelineBuilder) -> ReadinessPipelineBuilder:
    """Add messaging channel check stage to pipeline.

    Runs after the database stage -- the messaging channel (PgChannel by
    default) depends on the database connection being healthy.

    Includes:
    - Messaging channel configuration check (channel type, name,
      registered event types, handler count).

    Args:
        builder: Pipeline builder to add stage to.

    Returns:
        Builder with messaging stage added (for chaining).
    """
    (
        builder.add_stage(
            name=STAGE_MESSAGING,
            description="Messaging checks",
            is_critical=False,
            fail_fast=False,
        ).add_check(MessagingCheck())
    )
    return builder
