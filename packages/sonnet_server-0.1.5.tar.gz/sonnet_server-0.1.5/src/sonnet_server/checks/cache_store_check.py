"""Cache store readiness check for the readiness pipeline.

Only runs when ``SONNET_SERVER_CACHE_STORE`` is configured and at least
one registered cache uses ``DISTRIBUTED`` or ``NEAR_CACHE`` mode.
Skipped (success) otherwise.
"""

from loguru import logger

from sonnet_server.checks.stages import CacheStoreStage
from sonnet_server.readiness_pipeline import ReadinessCheck, ReadinessCheckResult
from sonnet_server.readiness_pipeline.registry import readiness_check


@readiness_check(stage=CacheStoreStage, is_critical=False, run_once=True)
class CacheStoreCheck(ReadinessCheck):
    """Readiness check for the distributed cache store (Redis).

    Verifies that the Redis connection pool can reach the configured
    cache store. Reports the store URL (host only, no credentials).
    Skipped when no distributed caches are registered.
    """

    def __init__(self, name: str = "cache_store_check", is_critical: bool = False, run_once: bool = True):
        super().__init__(name, is_critical, run_once)

    def _execute(self) -> ReadinessCheckResult:
        from sonnet_server.cache.config import CacheMode
        from sonnet_server.cache.registry import get_cache_registry
        from sonnet_server.settings import get_settings

        cache_store = get_settings().cache_store

        # Skip if not configured
        if cache_store is None:
            return self.success("Cache store not configured -- DISTRIBUTED/NEAR_CACHE modes unavailable")

        # Skip if no caches require it
        registry = get_cache_registry()
        distributed_caches = [
            c.config.name for c in registry.all() if c.config.mode in (CacheMode.DISTRIBUTED, CacheMode.NEAR_CACHE)
        ]
        # Also check registered-but-not-yet-instantiated caches
        distributed_configs = [
            cfg.name for cfg in registry.configs() if cfg.mode in (CacheMode.DISTRIBUTED, CacheMode.NEAR_CACHE)
        ]
        all_distributed = list(dict.fromkeys(distributed_configs + distributed_caches))

        if not all_distributed:
            return self.success(
                "Cache store configured but no DISTRIBUTED/NEAR_CACHE caches registered",
                {"cache_store_url": _redact_url(cache_store)},
            )

        # Ping Redis using the shared connection pool (same pool the caches will use)
        try:
            import asyncio

            import redis.asyncio as aioredis

            from sonnet_server.cache.backends.distributed import get_redis_pool

            async def _ping() -> bool:
                client = aioredis.Redis(connection_pool=get_redis_pool())
                try:
                    return await client.ping()
                finally:
                    await client.aclose()

            reachable = asyncio.run(_ping())

            detail = {
                "cache_store_url": _redact_url(cache_store),
                "distributed_caches": all_distributed,
            }

            if not reachable:
                logger.error("Cache store ping failed: {}", _redact_url(cache_store))
                return self.failed("Cache store unreachable", detail)

            logger.debug("Cache store reachable: {}", _redact_url(cache_store))
            return self.success(
                f"Cache store ready ({len(all_distributed)} distributed cache(s))",
                detail,
            )

        except (ConnectionError, OSError, RuntimeError, ValueError, TimeoutError) as e:
            logger.error("Cache store check failed: {}", e)
            return self.failed(f"Cache store check failed: {e}", {"cache_store_url": _redact_url(cache_store)})
        except ImportError:
            return self.failed("redis package not installed", {"cache_store_url": _redact_url(cache_store)})


def _redact_url(url: str) -> str:
    """Strip credentials from the URL for safe logging."""
    from urllib.parse import urlparse, urlunparse

    parsed = urlparse(url)
    redacted = parsed._replace(netloc=f"{parsed.hostname}:{parsed.port}" if parsed.port else parsed.hostname or "")
    return urlunparse(redacted)
