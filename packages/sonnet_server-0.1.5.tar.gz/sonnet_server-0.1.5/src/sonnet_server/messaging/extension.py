"""Messaging extension -- manages MessageRouter lifecycle and activates checks.

Bootstraps the message router on startup, starts the transport, and
stops it on shutdown. Contributes the /messaging and /messaging/ping
system routes. Imports the messaging readiness check module during
startup to register it in the pipeline.

See ``checks/__init__.py`` for the stage registration ownership model.
All deferred imports follow the convention documented in ``extensions.py``.
"""

from __future__ import annotations

from fastapi import APIRouter
from loguru import logger

from sonnet_server.extensions import Extension
from sonnet_server.messaging import MessageRouter
from sonnet_server.settings import Settings


class MessagingExtension(Extension):
    """Message router lifecycle management."""

    def __init__(self) -> None:
        self._router: MessageRouter | None = None

    @property
    def name(self) -> str:
        return "messaging"

    async def on_startup(self, settings: Settings) -> None:
        # Skip if no channel source is available. Either an explicit MESSAGE_BROKER
        # or a DATABASE_URL (to derive the default PgChannel) is required.
        if not settings.database_url and not settings.message_broker:
            logger.info("MessagingExtension: no DATABASE_URL or MESSAGE_BROKER configured, skipping")
            return

        # Import check module to trigger @readiness_check decorator registration.
        # Stage classes are already registered by checks/__init__.py.
        import sonnet_server.checks.messaging_check  # noqa: F401
        from sonnet_server.messaging.wiring import bootstrap_messaging

        self._router = bootstrap_messaging()
        await self._router.start()

    async def on_shutdown(self) -> None:
        if self._router is not None:
            await self._router.stop()

    def routers(self) -> list[APIRouter]:
        from sonnet_server.messaging.api import router as messaging_router

        return [messaging_router]
