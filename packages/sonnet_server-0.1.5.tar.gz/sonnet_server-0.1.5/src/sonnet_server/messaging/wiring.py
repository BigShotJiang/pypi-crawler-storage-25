"""Messaging bootstrap -- wires channels, bindings, and subscriptions.

Called once from the application lifespan. The bootstrap:

1. **Creates the internal channel** -- a single channel for all internal
   messaging. Defaults to PgChannel derived from DATABASE_URL. Can be
   overridden via SONNET_SERVER_MESSAGE_BROKER:
   - ``postgres+listen://?channel=...`` or ``postgres://...?channel=...`` -- PgChannel
   - ``memory://`` -- InProcessChannel (for testing or explicit opt-out)
   When MESSAGE_BROKER is not set, a PgChannel is created automatically
   from DATABASE_URL using the ``message_channel`` setting as the channel name.
2. **Wires handlers** -- reads the HandlerRegistry and subscribes every
   @handles handler to the channel.

Module-specific external channels (Kafka for audit delivery, webhooks,
etc.) are separate bindings added by the module itself, not part of
bootstrap wiring.

Precondition: all modules with @handles-annotated listeners must be
imported before calling bootstrap_messaging(). Module __init__.py
files import their own listeners.py, so this happens naturally through
the normal import chain.

This module has no domain imports.
"""

from __future__ import annotations

from urllib.parse import urlparse

from loguru import logger

from sonnet_server.messaging import MessageRouter, get_channel_factory, get_message_router
from sonnet_server.messaging.channels.postgres import PgChannel, to_psycopg_dsn
from sonnet_server.messaging.types import Channel
from sonnet_server.settings import get_settings


def bootstrap_messaging() -> MessageRouter:
    """Create and wire the message router.

    Returns:
        The configured MessageRouter instance.
    """
    router = get_message_router()

    # Single internal channel
    channel = _create_channel()
    router.add_sink(channel)

    # Wire all @handles handlers to the channel
    handler_count = router.wire_handlers(channel)

    logger.info(
        "Messaging bootstrap complete ({} handlers wired to '{}', {} event types)",
        handler_count,
        channel.name,
        len(router.get_registered_event_types()),
    )
    return router


def _create_channel() -> Channel:
    """Create the internal messaging channel.

    Priority:
    1. SONNET_SERVER_MESSAGE_BROKER explicitly set -> use ChannelFactory
    2. No MESSAGE_BROKER -> derive PgChannel from DATABASE_URL
    """
    settings = get_settings()

    if settings.message_broker:
        channel = get_channel_factory().create(settings.message_broker)
        if channel is not None:
            logger.info("Internal channel '{}' from {}", channel.name, _redact_url(settings.message_broker))
            return channel
        logger.warning("Unknown broker scheme in {}, falling back to PgChannel from DATABASE_URL", settings.message_broker)

    # Default: PgChannel from DATABASE_URL
    if not settings.database_url:
        raise RuntimeError(
            "SONNET_SERVER_DATABASE_URL is required to create the default PgChannel. "
            "Set DATABASE_URL or set SONNET_SERVER_MESSAGE_BROKER=memory:// to use in-process dispatch."
        )
    dsn = to_psycopg_dsn(settings.database_url)
    channel = PgChannel(channel_name=settings.message_channel, dsn=dsn)
    logger.info("Internal channel '{}' (default, derived from DATABASE_URL)", channel.name)
    return channel


def _redact_url(url: str) -> str:
    """Redact credentials from a URL for safe logging."""
    parsed = urlparse(url)
    if parsed.password:
        return url.replace(f":{parsed.password}@", ":***@")
    return url
