"""Postgres LISTEN/NOTIFY channel.

Uses a dedicated psycopg AsyncConnection (outside the SQLAlchemy pool)
to publish via pg_notify and receive notifications via LISTEN.

One PgChannel instance = one Postgres NOTIFY channel name. Multiple
processes listening on the same channel name all receive every notification
-- this is the fan-out mechanism used for cross-process cache invalidation.

Design constraints:
- The listener connection must use autocommit=True (required for LISTEN).
- The connection must be direct (not through PgBouncer in transaction mode).
  For Supabase: use the direct connection URL (port 5432), not the pooler
  (port 6543).
- The publish connection is a short-lived connection per publish call.
  pg_notify() works inside transactions so autocommit is not required there,
  but we use autocommit for simplicity.

URL schemes handled by the ChannelFactory registration at the bottom:
- postgres+listen://?channel=<name>  -- derive DSN from database_url setting
- postgres://<host>/<db>?channel=<name>  -- explicit DSN

The channel name in the URL query string maps to the Postgres NOTIFY channel
(a simple identifier, max 63 chars). It is also used as the PgChannel.name.
"""

from __future__ import annotations

import asyncio
import contextlib
from urllib.parse import ParseResult, parse_qs, urlunparse

from loguru import logger

from sonnet_server.messaging.channels.broker import BrokerChannel

# Reconnect backoff: initial 1s, doubles each attempt, cap at 30s.
_RECONNECT_INITIAL = 1.0
_RECONNECT_MAX = 30.0


def to_psycopg_dsn(sqlalchemy_url: str) -> str:
    """Strip the SQLAlchemy dialect suffix from a database URL.

    Converts ``postgresql+psycopg://...`` to ``postgresql://...``.
    Plain ``postgresql://...`` and ``postgres://...`` are returned unchanged.
    """
    return sqlalchemy_url.replace("postgresql+psycopg://", "postgresql://", 1)


class PgChannel(BrokerChannel):
    """Postgres LISTEN/NOTIFY channel.

    Publishes via ``pg_notify()`` on a short-lived connection.
    Subscribes via ``LISTEN`` on a persistent dedicated connection
    that runs a background task for the lifetime of the channel.

    The channel name (used as both PgChannel.name and the Postgres
    NOTIFY channel identifier) is taken from the ``channel`` query
    parameter of the broker URL.
    """

    def __init__(self, channel_name: str, dsn: str) -> None:
        """Create a PgChannel.

        Args:
            channel_name: Postgres NOTIFY channel identifier (max 63 chars).
                          Also used as this channel's name in the router.
            dsn: psycopg-compatible connection string (no +psycopg dialect prefix).
        """
        super().__init__(channel_name)
        self._dsn = dsn
        self._listener_task: asyncio.Task | None = None
        self._stop_event: asyncio.Event | None = None
        logger.trace("PgChannel '{}' created", channel_name)

    # -- Broker protocol ------------------------------------------------

    async def publish(self, event_type: str, payload: bytes) -> None:
        """Publish a serialized event via pg_notify.

        Opens a short-lived autocommit connection, sends the notification,
        and closes it. The payload must be a UTF-8 encoded JSON string
        within Postgres's 8 KB NOTIFY payload limit.

        Args:
            event_type: CloudEvents type string (stored in envelope, not used for routing here).
            payload: UTF-8 encoded JSON bytes.
        """
        import psycopg

        if len(payload) > 8000:
            logger.warning(
                "PgChannel '{}': payload for {} exceeds 8 KB ({} bytes), skipping notify",
                self._name,
                event_type,
                len(payload),
            )
            return

        text_payload = payload.decode("utf-8")
        conn = await psycopg.AsyncConnection.connect(self._dsn)
        try:
            await conn.set_autocommit(True)
            await conn.execute("SELECT pg_notify(%s, %s)", (self._name, text_payload))
            logger.debug("PgChannel '{}': published {}", self._name, event_type)
        except Exception as e:
            logger.error("PgChannel '{}': publish failed: {}", self._name, e)
            raise
        finally:
            with contextlib.suppress(Exception):
                await conn.close()

    # -- Lifecycle -------------------------------------------------------

    def ping(self) -> bool:
        """Check Postgres connectivity with SELECT 1 on a fresh sync connection.

        Uses a short-lived synchronous connection so this can be called
        from synchronous contexts (e.g. the readiness pipeline check executor).

        Returns:
            True if the connection succeeds, False otherwise.
        """
        import psycopg

        try:
            conn = psycopg.connect(self._dsn)
            try:
                conn.execute("SELECT 1")
            finally:
                with contextlib.suppress(Exception):
                    conn.close()
            return True
        except Exception as e:
            logger.warning("PgChannel '{}': ping failed: {}", self._name, e)
            return False

    async def start(self) -> None:
        """Start the background listener task."""
        self._stop_event = asyncio.Event()
        self._listener_task = asyncio.create_task(
            self._listen_loop(),
            name=f"pg-listen-{self._name}",
        )
        logger.info("PgChannel '{}': listener started", self._name)

    async def stop(self) -> None:
        """Stop the background listener task and close connections."""
        if self._stop_event is not None:
            self._stop_event.set()
        if self._listener_task is not None:
            self._listener_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._listener_task
            self._listener_task = None
        logger.info("PgChannel '{}': listener stopped", self._name)

    # -- Internal --------------------------------------------------------

    async def _listen_loop(self) -> None:
        """Background task: connect, LISTEN, dispatch notifications.

        Reconnects with exponential backoff on connection errors.
        Stops cleanly when stop() sets the stop event.
        """
        import psycopg

        backoff = _RECONNECT_INITIAL

        while self._stop_event is not None and not self._stop_event.is_set():
            conn = None
            try:
                conn = await psycopg.AsyncConnection.connect(self._dsn)
                await conn.set_autocommit(True)
                await conn.execute(f"LISTEN {self._name}")
                logger.debug("PgChannel '{}': LISTEN registered", self._name)
                backoff = _RECONNECT_INITIAL  # reset on successful connect

                async for notify in conn.notifies():
                    if self._stop_event.is_set():
                        break
                    await self._dispatch_payload(notify.payload.encode("utf-8"))

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(
                    "PgChannel '{}': connection error: {}. Reconnecting in {:.0f}s",
                    self._name,
                    e,
                    backoff,
                )
                try:
                    await asyncio.wait_for(self._stop_event.wait(), timeout=backoff)
                    break  # stop event fired during backoff
                except TimeoutError:
                    pass  # backoff elapsed, retry
                backoff = min(backoff * 2, _RECONNECT_MAX)
            finally:
                if conn is not None:
                    with contextlib.suppress(Exception):
                        await conn.close()


# -- ChannelFactory registration -----------------------------------------


def _channel_name_from_url(parsed: ParseResult) -> str:
    """Extract the channel name from the URL query string."""
    params = parse_qs(parsed.query)
    names = params.get("channel", [])
    if not names:
        raise ValueError(f"Missing 'channel' query parameter in broker URL: {parsed.geturl()}")
    return names[0]


def _dsn_from_parsed(parsed: ParseResult) -> str:
    """Build a plain psycopg DSN from a ParseResult.

    Strips the query parameter 'channel' (our own) and reconstructs
    the URL with scheme 'postgresql'.
    """
    from urllib.parse import urlencode

    params = parse_qs(parsed.query)
    params.pop("channel", None)
    query = urlencode({k: v[0] for k, v in params.items()})
    return urlunparse(("postgresql", parsed.netloc, parsed.path, "", query, ""))


def _create_from_explicit_url(parsed: ParseResult) -> PgChannel:
    """Create a PgChannel from a full postgres:// URL."""
    channel_name = _channel_name_from_url(parsed)
    dsn = _dsn_from_parsed(parsed)
    return PgChannel(channel_name=channel_name, dsn=dsn)


def _create_from_shorthand_url(parsed: ParseResult) -> PgChannel:
    """Create a PgChannel from a postgres+listen:// URL.

    Derives the DSN from SONNET_SERVER_DATABASE_URL. The URL only needs
    the channel query parameter:

        postgres+listen://?channel=sonnet.internal
    """
    from sonnet_server.settings import get_settings

    channel_name = _channel_name_from_url(parsed)
    database_url = get_settings().database_url
    if not database_url:
        raise ValueError("SONNET_SERVER_DATABASE_URL is required when using postgres+listen:// broker URL")
    dsn = to_psycopg_dsn(database_url)
    return PgChannel(channel_name=channel_name, dsn=dsn)


def _register() -> None:
    """Register PgChannel creators with the ChannelFactory."""
    from sonnet_server.messaging.types import get_channel_factory

    factory = get_channel_factory()
    factory.register("postgres", _create_from_explicit_url)
    factory.register("postgres+listen", _create_from_shorthand_url)


_register()
