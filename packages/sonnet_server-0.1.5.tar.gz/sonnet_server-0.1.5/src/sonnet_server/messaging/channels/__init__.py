"""Channel implementations for the message router."""

from .broker import BrokerChannel
from .in_process import InProcessChannel
from .postgres import PgChannel

# NatsChannel requires the optional nats-py dependency.
# Import triggers ChannelFactory registration for the nats:// scheme.
try:
    from .nats import NatsChannel, NatsPublisher  # noqa: F401

    __all__ = ["BrokerChannel", "InProcessChannel", "NatsChannel", "NatsPublisher", "PgChannel"]
except ImportError:
    __all__ = ["BrokerChannel", "InProcessChannel", "PgChannel"]
