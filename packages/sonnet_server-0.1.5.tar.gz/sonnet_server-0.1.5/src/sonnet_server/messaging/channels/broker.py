"""Base class for broker-backed channels (Postgres, NATS, etc.).

Provides the shared dispatch logic used by all broker-backed channels:
- CloudEvents JSON envelope parsing
- Raw byte callback dispatch (event_type string keyed)
- Pydantic handler dispatch via TypeRegistry resolution
- Handler and callback registration

Concrete channels (PgChannel, NatsChannel, ...) inherit from BrokerChannel
and implement the transport-specific methods: publish(), start(), stop(),
ping().
"""

from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from typing import Any

from loguru import logger
from pydantic import BaseModel

from sonnet_server.messaging.types import (
    Handler,
    HandlerExecutor,
    _causation_id_var,
    _correlation_id_var,
    _current_event_id_var,
    handler_display_name,
    new_event_id,
)


class BrokerChannel:
    """Shared base for broker-backed channels.

    Handles CloudEvents envelope parsing, handler registration, and
    dispatch. Subclasses provide the transport layer (publish, subscribe,
    start, stop, ping).

    The channel name is used in log messages and as the router identifier.
    """

    def __init__(self, name: str) -> None:
        self._name = name
        # Raw byte callbacks keyed by CloudEvents type string.
        self._callbacks: dict[str, list[Callable[[bytes], Awaitable[None]]]] = {}
        # Pydantic handlers keyed by Pydantic class, resolved from
        # CloudEvents type string via TypeRegistry at dispatch time.
        self._pydantic_handlers: dict[type[BaseModel], list[Handler]] = {}
        self._executor = HandlerExecutor()

    @property
    def name(self) -> str:
        return self._name

    def supports_dispatch(self) -> bool:
        """Broker-backed channels do not support in-process dispatch."""
        return False

    async def dispatch(self, event: BaseModel, *, isolate: bool | None = None) -> list[Any]:
        raise NotImplementedError(f"{type(self).__name__} does not support in-process dispatch -- use publish/subscribe")

    # -- Handler registration -------------------------------------------

    def add_handler(self, event_type: type[BaseModel], handler: Handler) -> None:
        """Register a Pydantic handler for a specific event type.

        Called by the router wiring layer. At dispatch time, the TypeRegistry
        resolves the CloudEvents type string to the Pydantic class.

        Args:
            event_type: Pydantic BaseModel class.
            handler: Async function or class with handle() method.
        """
        if event_type not in self._pydantic_handlers:
            self._pydantic_handlers[event_type] = []
        self._pydantic_handlers[event_type].append(handler)
        logger.trace(
            "{} '{}': registered handler {} for {}",
            type(self).__name__,
            self._name,
            handler_display_name(handler),
            event_type.__name__,
        )

    async def subscribe(self, event_type: str, callback: Callable[[bytes], Awaitable[None]]) -> None:
        """Register a raw byte callback for a CloudEvents type string.

        Args:
            event_type: CloudEvents type string to filter on.
            callback: Async callable receiving raw payload bytes.
        """
        if event_type not in self._callbacks:
            self._callbacks[event_type] = []
        self._callbacks[event_type].append(callback)
        logger.trace("{} '{}': subscribed callback for event_type='{}'", type(self).__name__, self._name, event_type)

    # -- Dispatch -------------------------------------------------------

    async def _dispatch_payload(self, payload: bytes) -> None:
        """Parse a broker payload and invoke registered handlers.

        The payload must be a UTF-8 encoded JSON object with at least a
        ``type`` field (CloudEvents type string) and a ``data`` field.

        Extracts ``correlation_id`` and ``causation_id`` from the
        envelope (if present) and sets them in context vars before
        calling handlers. This enables automatic propagation when a
        handler emits further events.

        Args:
            payload: Raw bytes received from the broker.
        """
        try:
            text = payload.decode("utf-8")
            envelope = json.loads(text)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as e:
            logger.warning("{} '{}': invalid payload: {}", type(self).__name__, self._name, e)
            return

        event_type_name = envelope.get("type")
        if not event_type_name:
            logger.warning("{} '{}': payload missing 'type' field", type(self).__name__, self._name)
            return

        # Set correlation context from envelope for handler propagation.
        # correlation_id: inherited from envelope (or new if missing)
        # causation_id: this event's own causation (who triggered it)
        # current_event_id: this event's id -- becomes causation_id for
        #   any new events emitted by the handler
        event_id = envelope.get("id") or new_event_id()
        correlation_id = envelope.get("correlation_id") or event_id
        _correlation_id_var.set(correlation_id)
        _causation_id_var.set(envelope.get("causation_id"))
        _current_event_id_var.set(event_id)

        # Raw byte callbacks
        for callback in self._callbacks.get(event_type_name, []):
            try:
                await callback(payload)
            except Exception as e:
                logger.error(
                    "{} '{}': callback error for {}: {}",
                    type(self).__name__,
                    self._name,
                    event_type_name,
                    e,
                )

        # Pydantic handlers: resolve CloudEvents type -> class via TypeRegistry
        event_class = self._resolve_event_class(event_type_name)
        if event_class is None:
            return

        handlers = self._pydantic_handlers.get(event_class, [])
        if not handlers:
            return

        data = envelope.get("data", {})
        try:
            event = event_class.model_validate(data)
        except Exception as e:
            logger.error(
                "{} '{}': deserialization failed for {}: {}",
                type(self).__name__,
                self._name,
                event_type_name,
                e,
            )
            return

        # Look up retry policies from the router
        handler_retries = self._get_handler_retries()

        for handler in handlers:
            retry = handler_retries.get(id(handler))
            try:
                await self._executor.execute(handler, event, retry=retry)
            except Exception as e:
                logger.error(
                    "{} '{}': handler error for {}: {}",
                    type(self).__name__,
                    self._name,
                    event_type_name,
                    e,
                )

    def _get_handler_retries(self) -> dict[int, Any]:
        """Retrieve retry policies from the router (lazy lookup)."""
        try:
            from sonnet_server.messaging import get_message_router

            retries = get_message_router()._handler_retries
            return retries if isinstance(retries, dict) else {}
        except ImportError, RuntimeError, AttributeError:
            return {}

    def _resolve_event_class(self, type_name: str) -> type[BaseModel] | None:
        """Resolve a CloudEvents type string to a Pydantic class via TypeRegistry.

        Returns None if no Pydantic handlers are registered (early exit)
        or if the type name is not in the registry.
        """
        if not self._pydantic_handlers:
            return None

        from sonnet_server.messaging import get_message_router

        return get_message_router().type_registry.get_class(type_name)
