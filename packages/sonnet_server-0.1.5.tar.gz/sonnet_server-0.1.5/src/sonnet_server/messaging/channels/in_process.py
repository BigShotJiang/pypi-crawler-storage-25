"""In-process channel -- direct handler dispatch without serialization.

This channel calls handlers directly with the Pydantic event object.
No serialization, no network. It is the equivalent of the legacy
EventBus for local dispatch.

Features:
- Concurrent handler execution via asyncio.gather
- DI injection via HandlerExecutor
- Error isolation (handler failures do not affect other handlers)
- Event isolation (optional deep copy per handler)
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import Any
from urllib.parse import ParseResult, parse_qs

from loguru import logger
from pydantic import BaseModel

from sonnet_server.messaging.types import Handler, HandlerExecutor, handler_display_name


class InProcessChannel:
    """In-process event dispatch channel.

    Passes Pydantic event objects directly to handlers without
    serialization. Supports the ``dispatch()`` / ``add_handler()``
    path of the Channel protocol.
    """

    def __init__(self, name: str, *, isolate_events: bool = False) -> None:
        self._name = name
        self._isolate_events = isolate_events
        self._handlers: dict[type[BaseModel], list[Handler]] = {}
        self._executor = HandlerExecutor()
        logger.debug("InProcessChannel '{}' created (isolate_events={})", name, isolate_events)

    @property
    def name(self) -> str:
        return self._name

    def supports_dispatch(self) -> bool:
        """In-process channels support direct dispatch."""
        return True

    # -- Broker protocol (not supported) --------------------------------

    async def publish(self, event_type: str, payload: bytes) -> None:
        raise NotImplementedError("InProcessChannel does not support broker publish -- use dispatch()")

    async def subscribe(self, event_type: str, callback: Callable[[bytes], Awaitable[None]]) -> None:
        raise NotImplementedError("InProcessChannel does not support broker subscribe -- use add_handler()")

    # -- Lifecycle (no-op) -----------------------------------------------

    def ping(self) -> bool:
        """In-process channel is always reachable."""
        return True

    async def start(self) -> None:
        pass

    async def stop(self) -> None:
        pass

    # -- Direct dispatch API ---------------------------------------------

    def add_handler(self, event_type: type[BaseModel], handler: Handler) -> None:
        """Register a handler for an event type."""
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        self._handlers[event_type].append(handler)
        logger.debug(
            "InProcessChannel '{}': registered handler for {}: {}",
            self._name,
            event_type.__name__,
            handler_display_name(handler),
        )

    def remove_handler(self, event_type: type[BaseModel], handler: Handler) -> bool:
        """Remove a specific handler. Returns True if found and removed."""
        if event_type in self._handlers:
            try:
                self._handlers[event_type].remove(handler)
                return True
            except ValueError:
                pass
        return False

    def has_handler(self, event_type: type[BaseModel], handler: Handler) -> bool:
        """Check whether a specific handler is registered."""
        return handler in self._handlers.get(event_type, [])

    def get_handler_count(self, event_type: type[BaseModel]) -> int:
        """Get the number of handlers registered for an event type."""
        return len(self._handlers.get(event_type, []))

    async def dispatch(self, event: BaseModel, *, isolate: bool | None = None) -> list[Any]:
        """Dispatch an event to all registered handlers and return results.

        Args:
            event: The event to dispatch.
            isolate: Override per-call event isolation. None uses channel default.

        Returns:
            List of handler results (including exceptions for failed handlers).
        """
        event_type = type(event)
        handlers = self._handlers.get(event_type, [])

        if not handlers:
            logger.debug("InProcessChannel '{}': no handlers for {}", self._name, event_type.__name__)
            return []

        logger.debug("InProcessChannel '{}': dispatching {} to {} handlers", self._name, event_type.__name__, len(handlers))

        should_isolate = isolate if isolate is not None else self._isolate_events

        tasks = []
        for handler in handlers:
            handler_event = event.model_copy(deep=True) if should_isolate else event
            tasks.append(self._executor.execute(handler, handler_event))

        results = await asyncio.gather(*tasks, return_exceptions=True)

        successful = sum(1 for r in results if not isinstance(r, Exception))
        failed = len(results) - successful
        if failed > 0:
            logger.warning(
                "InProcessChannel '{}': {} {} handlers succeeded, {} failed", self._name, event_type.__name__, successful, failed
            )

        return list(results)


# -- ChannelFactory registration -----------------------------------------


def _create_from_memory_url(parsed: ParseResult) -> InProcessChannel:
    """Create an InProcessChannel from a memory:// URL.

    The channel name defaults to 'local'. An optional ``name`` query
    parameter overrides it::

        memory://              -> InProcessChannel("local")
        memory://?name=test    -> InProcessChannel("test")
    """
    params = parse_qs(parsed.query)
    names = params.get("name", ["local"])
    return InProcessChannel(names[0])


def _register() -> None:
    """Register InProcessChannel creator with the ChannelFactory."""
    from sonnet_server.messaging.types import get_channel_factory

    get_channel_factory().register("memory", _create_from_memory_url)


_register()
