"""NATS channel -- pub/sub via a NATS server.

Uses the nats-py async client to publish and subscribe to a NATS subject.
All processes subscribed to the same subject receive every message (fan-out).

nats-py handles reconnection natively -- no manual reconnect loop needed
(unlike PgChannel). Connection options (reconnect_time_wait, max_reconnect_attempts)
are passed through to ``nats.connect()``.

URL scheme handled by the ChannelFactory registration at the bottom:
- nats://<host>:<port>?subject=<name>

The ``subject`` query parameter maps to the NATS subject used for
publish/subscribe. It is also used as the NatsChannel.name.

Requires the ``nats`` optional dependency::

    pip install sonnet-server[nats]
"""

from __future__ import annotations

import socket
from typing import TYPE_CHECKING
from urllib.parse import ParseResult, parse_qs, urlencode, urlparse, urlunparse

from loguru import logger

from sonnet_server.messaging.channels.broker import BrokerChannel

if TYPE_CHECKING:
    import nats as nats_lib

# Default NATS reconnect settings.
_RECONNECT_TIME_WAIT = 1  # seconds between reconnect attempts
_MAX_RECONNECT_ATTEMPTS = -1  # unlimited


class NatsChannel(BrokerChannel):
    """NATS pub/sub channel.

    Publishes via ``nc.publish(subject, payload)`` on a persistent connection.
    Subscribes via ``nc.subscribe(subject, cb=handler)`` -- the callback
    receives ``nats.aio.client.Msg`` objects whose ``.data`` attribute is
    the raw payload bytes, forwarded to ``_dispatch_payload()``.

    The connection is established in ``start()`` and closed in ``stop()``.
    nats-py handles automatic reconnection internally.
    """

    def __init__(self, subject: str, server_url: str) -> None:
        """Create a NatsChannel.

        Args:
            subject: NATS subject name (e.g. ``my_app_internal``).
                     Also used as this channel's name in the router.
            server_url: NATS server URL (e.g. ``nats://localhost:4222``).
        """
        super().__init__(subject)
        self._server_url = server_url
        self._nc: nats_lib.NATS | None = None
        self._sub: nats_lib.Subscription | None = None
        logger.debug("NatsChannel '{}' created (server={})", subject, server_url)

    # -- Broker protocol ------------------------------------------------

    async def publish(self, event_type: str, payload: bytes) -> None:
        """Publish a serialized event to the NATS subject.

        Args:
            event_type: CloudEvents type string (for logging, not used in routing).
            payload: Raw bytes (CloudEvents JSON envelope).
        """
        if self._nc is None or self._nc.is_closed:
            logger.error("NatsChannel '{}': not connected, cannot publish {}", self._name, event_type)
            return

        await self._nc.publish(self._name, payload)
        logger.debug("NatsChannel '{}': published {}", self._name, event_type)

    # -- Lifecycle -------------------------------------------------------

    def ping(self) -> bool:
        """Check NATS server reachability via a TCP connect.

        Uses a plain TCP connection (synchronous) so this can be called
        from the readiness pipeline check executor. Does not require an
        active nats-py client.

        Returns:
            True if the TCP connection succeeds, False otherwise.
        """
        try:
            parsed = urlparse(self._server_url)
            host = parsed.hostname or "localhost"
            port = parsed.port or 4222
            sock = socket.create_connection((host, port), timeout=3)
            sock.close()
            return True
        except (OSError, ValueError) as e:
            logger.warning("NatsChannel '{}': ping failed: {}", self._name, e)
            return False

    async def start(self) -> None:
        """Connect to NATS and subscribe to the subject."""
        import nats

        async def _error_cb(e: Exception) -> None:
            logger.error("NatsChannel '{}': client error: {}", self._name, e)

        async def _disconnected_cb() -> None:
            logger.warning("NatsChannel '{}': disconnected from server", self._name)

        async def _reconnected_cb() -> None:
            logger.info("NatsChannel '{}': reconnected to server", self._name)

        self._nc = await nats.connect(
            self._server_url,
            reconnect_time_wait=_RECONNECT_TIME_WAIT,
            max_reconnect_attempts=_MAX_RECONNECT_ATTEMPTS,
            error_cb=_error_cb,
            disconnected_cb=_disconnected_cb,
            reconnected_cb=_reconnected_cb,
        )

        async def _on_message(msg) -> None:
            await self._dispatch_payload(msg.data)

        self._sub = await self._nc.subscribe(self._name, cb=_on_message)
        logger.info("NatsChannel '{}': connected and subscribed (server={})", self._name, self._server_url)

    async def stop(self) -> None:
        """Drain pending messages and close the NATS connection."""
        if self._nc is not None and not self._nc.is_closed:
            try:
                await self._nc.drain()
            except Exception as e:  # intentional: stop() must never raise; nats drain errors vary
                logger.warning("NatsChannel '{}': drain error: {}", self._name, e)
            self._nc = None
            self._sub = None
        logger.info("NatsChannel '{}': stopped", self._name)


# -- ChannelFactory registration -----------------------------------------


def _subject_from_url(parsed: ParseResult) -> str:
    """Extract the subject name from the URL query string."""
    params = parse_qs(parsed.query)
    subjects = params.get("subject", [])
    if not subjects:
        raise ValueError(f"Missing 'subject' query parameter in broker URL: {parsed.geturl()}")
    return subjects[0]


def _server_url_from_parsed(parsed: ParseResult) -> str:
    """Reconstruct the NATS server URL without our custom query params.

    Strips the ``subject`` query parameter (our own routing key) and
    rebuilds the URL with the original scheme, host, port, and any
    remaining query parameters (e.g. auth tokens).
    """
    params = parse_qs(parsed.query)
    params.pop("subject", None)
    query = urlencode({k: v[0] for k, v in params.items()}) if params else ""
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", query, ""))


class NatsPublisher:
    """Outbound-only NATS publisher.

    Connects to a NATS server and publishes events to a subject.
    Does not subscribe -- use this for one-way outbound sinks
    (e.g. per-tenant audit trail forwarding) where the server only
    sends and external consumers subscribe independently.

    Unlike NatsChannel, start() only connects without subscribing.
    """

    def __init__(self, subject: str, server_url: str, url: str = "") -> None:
        """Create a NatsPublisher.

        Args:
            subject: NATS subject name. Also used as this publisher's name.
            server_url: NATS server URL (e.g. ``nats://localhost:4222``).
            url: Original broker URL this publisher was created from (e.g.
                 ``nats+publish://localhost:4222?subject=audit.events``).
                 Stored for reconciliation -- compare against desired config
                 to detect whether this publisher needs replacing.
        """
        self._name = subject
        self._server_url = server_url
        self._url = url
        self._nc: nats_lib.NATS | None = None
        logger.debug("NatsPublisher '{}' created (server={})", subject, server_url)

    @property
    def name(self) -> str:
        return self._name

    @property
    def url(self) -> str:
        return self._url

    async def publish(self, event_type: str, payload: bytes) -> None:
        """Publish a serialized event to the NATS subject."""
        if self._nc is None or self._nc.is_closed:
            logger.error("NatsPublisher '{}': not connected, cannot publish {}", self._name, event_type)
            return
        await self._nc.publish(self._name, payload)
        logger.debug("NatsPublisher '{}': published {}", self._name, event_type)

    def ping(self) -> bool:
        """Check NATS server reachability via a TCP connect."""
        try:
            parsed = urlparse(self._server_url)
            host = parsed.hostname or "localhost"
            port = parsed.port or 4222
            sock = socket.create_connection((host, port), timeout=3)
            sock.close()
            return True
        except (OSError, ValueError) as e:
            logger.warning("NatsPublisher '{}': ping failed: {}", self._name, e)
            return False

    async def start(self) -> None:
        """Connect to NATS (no subscription)."""
        import nats

        async def _error_cb(e: Exception) -> None:
            logger.error("NatsPublisher '{}': client error: {}", self._name, e)

        async def _disconnected_cb() -> None:
            logger.warning("NatsPublisher '{}': disconnected from server", self._name)

        async def _reconnected_cb() -> None:
            logger.info("NatsPublisher '{}': reconnected to server", self._name)

        self._nc = await nats.connect(
            self._server_url,
            reconnect_time_wait=_RECONNECT_TIME_WAIT,
            max_reconnect_attempts=_MAX_RECONNECT_ATTEMPTS,
            error_cb=_error_cb,
            disconnected_cb=_disconnected_cb,
            reconnected_cb=_reconnected_cb,
        )
        logger.info("NatsPublisher '{}': connected (server={})", self._name, self._server_url)

    async def stop(self) -> None:
        """Drain pending messages and close the NATS connection."""
        if self._nc is not None and not self._nc.is_closed:
            try:
                await self._nc.drain()
            except Exception as e:  # intentional: stop() must never raise; nats drain errors vary
                logger.warning("NatsPublisher '{}': drain error: {}", self._name, e)
            self._nc = None
        logger.info("NatsPublisher '{}': stopped", self._name)


def _create_from_nats_url(parsed: ParseResult) -> NatsChannel:
    """Create a NatsChannel from a nats:// URL."""
    subject = _subject_from_url(parsed)
    server_url = _server_url_from_parsed(parsed)
    return NatsChannel(subject=subject, server_url=server_url)


def _create_from_nats_publish_url(parsed: ParseResult) -> NatsPublisher:
    """Create a NatsPublisher from a nats+publish:// URL."""
    subject = _subject_from_url(parsed)
    server_url = _server_url_from_parsed(parsed)
    # Restore scheme to nats:// for the actual server URL
    server_url = server_url.replace("nats+publish://", "nats://", 1)
    return NatsPublisher(subject=subject, server_url=server_url, url=parsed.geturl())


def _register() -> None:
    """Register NatsChannel and NatsPublisher creators with the ChannelFactory.

    Guarded by an import check -- if nats-py is not installed, neither
    scheme is registered and the factory will return None with a warning.
    """
    try:
        import nats  # noqa: F401
    except ImportError:
        logger.debug("nats-py not installed -- nats:// and nats+publish:// schemes not available")
        return

    from sonnet_server.messaging.types import get_channel_factory

    factory = get_channel_factory()
    factory.register("nats", _create_from_nats_url)
    factory.register("nats+publish", _create_from_nats_publish_url)


_register()
