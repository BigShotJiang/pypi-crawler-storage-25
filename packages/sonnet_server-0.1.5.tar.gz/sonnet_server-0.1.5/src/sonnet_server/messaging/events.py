"""Infrastructure events for the messaging subsystem."""

from __future__ import annotations

import uuid

from pydantic import BaseModel, Field


class MessagingPingEvent(BaseModel):
    """Test event for verifying the messaging pipeline end-to-end.

    Emitted by POST /messaging/ping. A registered handler logs receipt,
    confirming that the full emit -> channel -> dispatch path is working.
    The trace_id correlates the emit with the handler log line.
    """

    trace_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
