"""Messaging system endpoints.

System-level routes for messaging introspection and operational verification.
Mounted alongside ``/ping``, ``/health-check``, ``/cache``.

``GET /messaging`` returns router status, sinks, bindings, handlers, and
registered event types -- the messaging equivalent of ``GET /cache``.

``POST /messaging/ping`` performs an active round-trip smoke test by emitting
a ``MessagingPingEvent`` through the full pipeline.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from sonnet_server.messaging import (
    Channel,
    MessagingPingEvent,
    get_channel_factory,
    get_handler_registry,
    get_message_router,
    handler_display_name,
)

router = APIRouter(tags=["System"])


# -- Response models --------------------------------------------------------


class SinkInfo(BaseModel):
    """Summary of a single sink (channel or publisher)."""

    name: str
    type: str
    reachable: bool
    supports_dispatch: bool | None = None


class BindingInfo(BaseModel):
    """An event type bound to one or more sinks."""

    event_type: str
    sinks: list[str]
    has_predicate: bool


class HandlerInfo(BaseModel):
    """A registered handler for an event type."""

    event_type: str
    handler: str


class MessagingStatusResponse(BaseModel):
    """Response for GET /messaging."""

    started: bool
    sink_count: int
    handler_count: int
    available_schemes: list[str]
    sinks: list[SinkInfo]
    bindings: list[BindingInfo]
    handlers: list[HandlerInfo]
    event_types: list[str]


class MessagingPingResponse(BaseModel):
    """Response from POST /messaging/ping."""

    trace_id: str
    channel: str
    channel_name: str


# -- Endpoints --------------------------------------------------------------


@router.get("/messaging", response_model=MessagingStatusResponse)
async def messaging_status() -> MessagingStatusResponse:
    """Return messaging router status and topology.

    Reports whether the router is started, all registered sinks with
    reachability, event-type-to-sink bindings, registered handlers,
    and available channel factory schemes. This is the passive
    introspection counterpart to the active ``POST /messaging/ping``
    smoke test.
    """
    router_instance = get_message_router()
    factory = get_channel_factory()
    handler_registry = get_handler_registry()

    # Sinks -- sink_names is already sorted
    sink_infos = []
    for name in router_instance.sink_names:
        sink = router_instance.get_sink(name)
        if sink is None:
            continue
        sink_infos.append(
            SinkInfo(
                name=sink.name,
                type=type(sink).__name__,
                reachable=sink.ping(),
                supports_dispatch=sink.supports_dispatch() if isinstance(sink, Channel) else None,
            )
        )

    # Bindings and event types -- single pass over get_registered_event_types()
    registered_event_types = router_instance.get_registered_event_types()
    binding_infos = []
    for event_type in registered_event_types:
        bindings = router_instance.get_bindings(event_type)
        binding_infos.append(
            BindingInfo(
                event_type=event_type.__name__,
                sinks=[b.sink.name for b in bindings],
                has_predicate=any(b.predicate is not None for b in bindings),
            )
        )
    binding_infos.sort(key=lambda b: b.event_type)

    # Handlers
    handler_infos = []
    for entry in handler_registry.get_entries():
        handler_infos.append(
            HandlerInfo(
                event_type=entry.event_type.__name__,
                handler=handler_display_name(entry.handler),
            )
        )
    handler_infos.sort(key=lambda h: (h.event_type, h.handler))

    event_type_names = sorted(et.__name__ for et in registered_event_types)

    return MessagingStatusResponse(
        started=router_instance.started,
        sink_count=len(sink_infos),
        handler_count=handler_registry.size,
        available_schemes=factory.schemes,
        sinks=sink_infos,
        bindings=binding_infos,
        handlers=handler_infos,
        event_types=event_type_names,
    )


@router.post("/messaging/ping", status_code=202, response_model=MessagingPingResponse)
async def messaging_ping() -> MessagingPingResponse:
    """Emit a test event through the messaging pipeline.

    Emits a MessagingPingEvent through the router. The registered handler
    logs receipt with a trace_id -- check the server log to confirm the
    full emit -> channel -> dispatch path is working.

    Returns 202 Accepted since broker-backed channels (PgChannel, NatsChannel)
    deliver asynchronously -- the handler may fire after the response is sent.
    """
    router_instance = get_message_router()
    bindings = router_instance.get_bindings(MessagingPingEvent)
    if not bindings:
        raise HTTPException(status_code=503, detail="No channel bound for MessagingPingEvent -- router not wired")
    channel = bindings[0].sink
    event = MessagingPingEvent()
    router_instance.emit(event)
    return MessagingPingResponse(
        trace_id=event.trace_id,
        channel=type(channel).__name__,
        channel_name=channel.name,
    )
