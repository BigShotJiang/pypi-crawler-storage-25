"""Messaging -- event routing and delivery.

Public surface for the messaging module. Import from here::

    from sonnet_server.messaging import (
        handles, get_message_router, MessageRouter,
        MessagingExtension,
        InProcessChannel, PgChannel,
        RetryPolicy, Channel, HandlerRegistry,
    )

Provides a message router that routes events to channels. Channels
abstract over delivery mechanisms: in-process dispatch, NATS, Kafka,
Redis, etc. Services call router.emit(event) and know nothing about
the underlying transport.

Two ways to register handlers:

1. Annotation-based (preferred for domain handlers)::

    from sonnet_server.messaging import handles

    @handles(SchemaDefinitionChanged)
    async def on_schema_changed(event):
        ...

   Handlers auto-register on import. The wiring layer assigns channels.

2. Programmatic (for dynamic or infrastructure wiring)::

    router.bind(MyEvent, local)
    router.subscribe(MyEvent, local, my_handler)
"""

from functools import lru_cache

from . import listeners as _listeners  # noqa: F401 -- triggers @handles registration
from .channels.in_process import InProcessChannel
from .channels.postgres import PgChannel
from .events import MessagingPingEvent
from .router import MessageRouter
from .types import (
    DEFAULT_MIDDLEWARE,
    Channel,
    ChannelFactory,
    HandlerEntry,
    HandlerExecutor,
    HandlerMiddlewareFn,
    HandlerRegistry,
    Publisher,
    RetryPolicy,
    Sink,
    TypeRegistry,
    get_causation_id,
    get_channel_factory,
    get_correlation_id,
    get_handler_registry,
    handler_display_name,
    handles,
    logging_middleware,
    retry_middleware,
)


def __getattr__(name: str):
    """Lazily expose MessagingExtension to avoid circular import."""
    if name == "MessagingExtension":
        from sonnet_server.messaging.extension import MessagingExtension

        return MessagingExtension
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "Channel",
    "ChannelFactory",
    "DEFAULT_MIDDLEWARE",
    "HandlerEntry",
    "HandlerExecutor",
    "HandlerMiddlewareFn",
    "HandlerRegistry",
    "InProcessChannel",
    "MessageRouter",
    "MessagingExtension",
    "MessagingPingEvent",
    "PgChannel",
    "Publisher",
    "RetryPolicy",
    "Sink",
    "TypeRegistry",
    "get_causation_id",
    "get_channel_factory",
    "get_correlation_id",
    "get_handler_registry",
    "get_message_router",
    "handler_display_name",
    "handles",
    "logging_middleware",
    "retry_middleware",
]


@lru_cache
def get_message_router() -> MessageRouter:
    """Get or create the singleton MessageRouter instance.

    Returns:
        The MessageRouter instance.
    """
    return MessageRouter()
