"""Messaging types and protocols.

Defines the Channel protocol, handler executor, type registry,
handler registry with @handles decorator, and supporting types
used by the MessageRouter.
"""

from __future__ import annotations

import asyncio
import contextvars
import inspect
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any, Protocol, runtime_checkable

import arrow
from loguru import logger
from pydantic import BaseModel

type EventPredicate = Callable[[BaseModel], bool]
"""Predicate for content-based filtering on bindings."""

type Handler = Callable[..., Any]
"""Handler callable -- async function or class with handle() method."""

type NextCall = Callable[[Handler, BaseModel], Awaitable[Any]]
"""The call_next signature passed to each middleware."""

type HandlerMiddlewareFn = Callable[[Handler, BaseModel, NextCall], Awaitable[Any]]
"""A middleware function that wraps a handler invocation.

Receives the handler, the event, and a ``call_next`` callable that invokes
the next middleware (or the actual handler at the end of the chain).
Must return the result of ``await call_next(handler, event)`` (or a
replacement result).

Example::

    async def my_middleware(
        handler: Handler,
        event: BaseModel,
        call_next: NextCall,
    ) -> Any:
        # before
        result = await call_next(handler, event)
        # after
        return result
"""

# Attribute name used by the @handles decorator to store event type metadata.
_HANDLES_ATTR = "_handles_event"

# -- Correlation context ------------------------------------------------

_correlation_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar("correlation_id", default=None)
_causation_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar("causation_id", default=None)
_current_event_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar("current_event_id", default=None)


def get_correlation_id() -> str | None:
    """Return the current correlation ID from context, or None."""
    return _correlation_id_var.get()


def get_causation_id() -> str | None:
    """Return the current causation ID from context, or None."""
    return _causation_id_var.get()


def new_event_id() -> str:
    """Generate a new event ID (UUID)."""
    return str(uuid.uuid4())


# -- Retry policy -------------------------------------------------------


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    """Configurable retry policy for handler execution.

    Attached to handlers via ``@handles(EventType, retry=RetryPolicy(...))``.
    Default: no retry (max_attempts=1).

    Args:
        max_attempts: Total attempts (1 = no retry). Must be >= 1.
        base_delay: Initial delay in seconds between retries.
        backoff_multiplier: Multiplier applied to delay after each retry.
        max_delay: Upper bound on delay in seconds.
    """

    max_attempts: int = 1
    base_delay: float = 0.1
    backoff_multiplier: float = 2.0
    max_delay: float = 10.0

    def __post_init__(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("max_attempts must be >= 1")


NO_RETRY = RetryPolicy()

# Contextvar for passing the active retry policy into the middleware chain.
# Set by HandlerExecutor.execute() before calling the chain.
_retry_policy_var: contextvars.ContextVar[RetryPolicy | None] = contextvars.ContextVar("retry_policy", default=None)


@runtime_checkable
class Publisher(Protocol):
    """An outbound-only delivery path for events.

    Minimal protocol for publish-only sinks (e.g. external audit trail
    delivery to NATS or Kafka). Consumers subscribe independently --
    the server only sends.

    Use this for dynamic outbound sinks loaded from DB configuration
    (e.g. per-tenant audit trail forwarding). The router's bind() accepts
    both Channel and Publisher.
    """

    @property
    def name(self) -> str:
        """Unique publisher identifier."""
        ...

    @property
    def url(self) -> str:
        """Transport URL this publisher was created from.

        Used for reconciliation: compare against desired config to detect
        whether a publisher needs to be replaced.
        """
        ...

    async def publish(self, event_type: str, payload: bytes) -> None:
        """Publish a serialized event to this publisher's destination."""
        ...

    def ping(self) -> bool:
        """Check whether the transport is reachable (synchronous).

        Returns:
            True if the transport is reachable, False otherwise.
        """
        ...

    async def start(self) -> None:
        """Open connections."""
        ...

    async def stop(self) -> None:
        """Close connections, drain buffers."""
        ...


@runtime_checkable
class Channel(Protocol):
    """A delivery path for events.

    Each instance represents one destination: one NATS subject, one
    Kafka topic, one Redis channel, or in-process dispatch. The
    connection and destination are fixed at construction time.

    Channels support two dispatch modes:

    - **Broker-backed** (NATS, Kafka, Redis): use ``publish()`` and
      ``subscribe()`` with serialized bytes. The channel handles
      serialization and network I/O.

    - **In-process**: use ``dispatch()`` and ``add_handler()`` with
      Pydantic event objects directly. No serialization.

    A channel must support at least one mode. The router calls
    ``supports_dispatch()`` to determine which path to use.
    """

    @property
    def name(self) -> str:
        """Unique channel identifier."""
        ...

    def supports_dispatch(self) -> bool:
        """Return True if this channel supports direct in-process dispatch.

        When True, the router calls dispatch() and add_handler()
        instead of publish() and subscribe().
        """
        ...

    async def publish(self, event_type: str, payload: bytes) -> None:
        """Publish a serialized event to this channel's destination."""
        ...

    async def subscribe(self, event_type: str, callback: Callable[[bytes], Awaitable[None]]) -> None:
        """Register a callback for events arriving on this channel."""
        ...

    def add_handler(self, event_type: type[BaseModel], handler: Handler) -> None:
        """Register a handler for direct dispatch (in-process channels only)."""
        ...

    async def dispatch(self, event: BaseModel, *, isolate: bool | None = None) -> list[Any]:
        """Dispatch an event to registered handlers (in-process channels only).

        Returns a list of handler results (including exceptions).
        """
        ...

    def ping(self) -> bool:
        """Check whether the channel's transport is reachable.

        For broker-backed channels, performs a lightweight synchronous
        connectivity check (e.g. SELECT 1 for Postgres). For in-process
        channels, always returns True. Synchronous so it can be called
        from the readiness pipeline check executor.

        Returns:
            True if the transport is reachable, False otherwise.
        """
        ...

    async def start(self) -> None:
        """Open connections, begin listening."""
        ...

    async def stop(self) -> None:
        """Close connections, drain buffers."""
        ...


type Sink = Channel | Publisher
"""A Channel or Publisher -- anything the router can bind an event type to."""


class Binding:
    """Connects an event type to a channel or publisher with an optional predicate.

    Internal data structure used by the router. Not part of the public API.
    """

    __slots__ = ("sink", "predicate")

    def __init__(self, sink: Sink, predicate: EventPredicate | None = None) -> None:
        self.sink = sink
        self.predicate = predicate

    def accepts(self, event: BaseModel) -> bool:
        """Return True if this binding accepts the event (predicate passes or no predicate)."""
        if self.predicate is None:
            return True
        return self.predicate(event)


# -- Handler middleware -------------------------------------------------


async def retry_middleware(handler: Handler, event: BaseModel, call_next: NextCall) -> Any:
    """Middleware that retries the handler on failure using the active RetryPolicy.

    Reads the policy from ``_retry_policy_var`` (set by HandlerExecutor before
    calling the chain). If no policy is set, falls back to NO_RETRY.

    On transient failure logs at WARNING with attempt count and delay.
    On final failure logs at ERROR and returns the exception (error isolation).
    """
    policy = _retry_policy_var.get() or NO_RETRY
    handler_name = handler_display_name(handler)
    event_type_name = type(event).__name__
    last_error: Exception | None = None

    for attempt in range(1, policy.max_attempts + 1):
        try:
            return await call_next(handler, event)
        except Exception as e:
            last_error = e
            if attempt < policy.max_attempts:
                delay = min(policy.base_delay * (policy.backoff_multiplier ** (attempt - 1)), policy.max_delay)
                logger.warning(
                    "Handler '{}' failed for {} (attempt {}/{}) retrying in {:.1f}s: {}: {}",
                    handler_name,
                    event_type_name,
                    attempt,
                    policy.max_attempts,
                    delay,
                    type(e).__name__,
                    e,
                )
                await asyncio.sleep(delay)
            else:
                logger.error(
                    "Handler '{}' failed for {} (attempt {}/{}): {}: {}",
                    handler_name,
                    event_type_name,
                    attempt,
                    policy.max_attempts,
                    type(e).__name__,
                    e,
                )

    return last_error


async def logging_middleware(handler: Handler, event: BaseModel, call_next: NextCall) -> Any:
    """Middleware that logs handler invocation timing and outcome.

    Logs at INFO on success with duration. Exceptions propagate upward
    to be caught by retry_middleware (or returned as error isolation).
    """
    handler_name = handler_display_name(handler)
    event_type_name = type(event).__name__
    start_time = arrow.utcnow().float_timestamp
    result = await call_next(handler, event)
    duration_ms = (arrow.utcnow().float_timestamp - start_time) * 1000
    logger.info(
        "Handler '{}' completed for {} in {:.1f}ms",
        handler_name,
        event_type_name,
        duration_ms,
    )
    return result


DEFAULT_MIDDLEWARE: list[HandlerMiddlewareFn] = [retry_middleware, logging_middleware]
"""Default middleware stack applied to every handler invocation.

Order: retry_middleware wraps logging_middleware wraps _invoke_handler.
This means the timing in logging_middleware reflects a single attempt,
and retry_middleware sees the exception to decide whether to retry.
"""


def _build_chain(middlewares: list[HandlerMiddlewareFn], terminal: NextCall) -> NextCall:
    """Compose a list of middlewares into a single NextCall.

    Builds from right to left so the first middleware in the list is
    the outermost wrapper. The ``terminal`` callable is the innermost
    node (the actual handler invocation with DI).
    """
    chain = terminal
    for middleware in reversed(middlewares):
        # Capture current values to avoid closure-over-loop-variable bug
        current_mw = middleware
        current_next = chain

        async def make_call(h: Handler, e: BaseModel, mw=current_mw, nxt=current_next) -> Any:
            return await mw(h, e, nxt)

        chain = make_call
    return chain


class HandlerExecutor:
    """Executes event handlers through a configurable middleware chain.

    The chain is: middleware[0] -> middleware[1] -> ... -> _invoke_handler.
    Default stack: retry_middleware -> logging_middleware -> _invoke_handler.

    Cross-cutting concerns (retry, logging, timeout, circuit breaker) are
    implemented as middleware functions and composed here. Adding a new
    concern means adding a new middleware to the stack -- HandlerExecutor
    itself does not change.

    The retry policy is passed via ``_retry_policy_var`` contextvar so
    retry_middleware can read it without a signature change.
    """

    def __init__(self, middlewares: list[HandlerMiddlewareFn] | None = None) -> None:
        mws = middlewares if middlewares is not None else DEFAULT_MIDDLEWARE
        self._chain = _build_chain(mws, _invoke_handler)

    async def execute(self, handler: Handler, event: BaseModel, retry: RetryPolicy | None = None) -> Any:
        """Execute a handler through the middleware chain.

        Sets the retry policy in context before calling the chain so
        retry_middleware can read it. Returns the handler result, or
        the exception on final failure (error isolation).

        Args:
            handler: Async function or class with handle() method.
            event: Pydantic event instance.
            retry: Optional retry policy. None means no retry (NO_RETRY).
        """
        _retry_policy_var.set(retry or NO_RETRY)
        return await self._chain(handler, event)


async def _invoke_handler(handler: Handler, event: BaseModel) -> Any:
    """Terminal node of the middleware chain: invoke the handler with DI.

    Supports both async function handlers and class-based handlers
    (instantiated with DI, called via handle()).
    """
    if inspect.isclass(handler):
        return await _invoke_class_handler(handler, event)
    return await _invoke_function_handler(handler, event)


async def _invoke_class_handler(handler_class: type, event: BaseModel) -> Any:
    """Instantiate a class-based handler with DI and call handle()."""
    sig = inspect.signature(handler_class.__init__)
    params = list(sig.parameters.values())[1:]  # skip self
    kwargs = _resolve_dependencies(params) if params else {}
    instance = handler_class(**kwargs)
    handler_method = getattr(instance, "handle", None)
    if handler_method is None:
        raise AttributeError(f"Handler class {handler_class.__name__} must have a 'handle' method")
    return await handler_method(event)


async def _invoke_function_handler(handler: Handler, event: BaseModel) -> Any:
    """Execute a function handler, injecting dependencies for extra parameters."""
    sig = inspect.signature(handler)
    params = list(sig.parameters.values())
    if len(params) <= 1:
        return await handler(event)
    kwargs = _resolve_dependencies(params[1:])
    return await handler(event, **kwargs)


class TypeRegistry:
    """Bidirectional map between CloudEvents type strings and Pydantic classes.

    Used by broker-backed channels to serialize (class -> type string)
    and deserialize (type string -> class) events.
    """

    def __init__(self) -> None:
        self._name_to_class: dict[str, type[BaseModel]] = {}
        self._class_to_name: dict[type[BaseModel], str] = {}

    def register(self, type_name: str, event_class: type[BaseModel]) -> None:
        """Register a bidirectional mapping.

        Args:
            type_name: CloudEvents type string (e.g. "sonnet.schema_definition.changed").
            event_class: Pydantic model class.

        Raises:
            ValueError: If the type name or class is already registered with a different mapping.
        """
        existing_class = self._name_to_class.get(type_name)
        if existing_class is not None and existing_class is not event_class:
            raise ValueError(
                f"Type name '{type_name}' already registered to {existing_class.__name__},"
                f" cannot re-register to {event_class.__name__}"
            )

        existing_name = self._class_to_name.get(event_class)
        if existing_name is not None and existing_name != type_name:
            raise ValueError(
                f"Class {event_class.__name__} already registered as '{existing_name}', cannot re-register as '{type_name}'"
            )

        self._name_to_class[type_name] = event_class
        self._class_to_name[event_class] = type_name

    def get_class(self, type_name: str) -> type[BaseModel] | None:
        """Look up a Pydantic class by CloudEvents type string."""
        return self._name_to_class.get(type_name)

    def get_type_name(self, event_class: type[BaseModel]) -> str | None:
        """Look up a CloudEvents type string by Pydantic class."""
        return self._class_to_name.get(event_class)

    def is_registered(self, event_class: type[BaseModel]) -> bool:
        """Check if a class is registered."""
        return event_class in self._class_to_name

    def ensure_registered(self, event_class: type[BaseModel]) -> str:
        """Register a class with an auto-derived type name if not already registered.

        The auto-derived name converts CamelCase to a dotted lowercase
        string prefixed with ``sonnet.``.  For example::

            SchemaDefinitionChanged -> sonnet.schema_definition_changed
            AuditTrailEventReceived -> sonnet.audit_trail_event_received

        Returns:
            The CloudEvents type name (existing or newly created).
        """
        existing = self._class_to_name.get(event_class)
        if existing is not None:
            return existing
        type_name = _derive_type_name(event_class)
        self.register(type_name, event_class)
        return type_name


@dataclass(slots=True)
class HandlerEntry:
    """A registered handler with its event type and retry policy."""

    event_type: type[BaseModel]
    handler: Handler
    retry: RetryPolicy = field(default=NO_RETRY)


class HandlerRegistry:
    """Collects handlers annotated with @handles.

    The registry is populated automatically when modules are imported
    (the @handles decorator calls register()). The wiring layer reads
    the registry and decides which channel each handler is subscribed to.

    This decouples handler declaration (domain concern) from channel
    assignment (infrastructure concern).
    """

    def __init__(self) -> None:
        self._entries: list[HandlerEntry] = []

    def register(self, event_type: type[BaseModel], handler: Handler, retry: RetryPolicy | None = None) -> None:
        """Register a handler for an event type."""
        self._entries.append(HandlerEntry(event_type=event_type, handler=handler, retry=retry or NO_RETRY))
        logger.trace("HandlerRegistry: registered {} for {}", handler_display_name(handler), event_type.__name__)

    def get_entries(self, event_type: type[BaseModel] | None = None) -> list[HandlerEntry]:
        """Return registered entries, optionally filtered by event type.

        Args:
            event_type: If provided, return only entries for this type.
                        If None, return all entries.

        Returns:
            List of HandlerEntry instances.
        """
        if event_type is None:
            return list(self._entries)
        return [e for e in self._entries if e.event_type is event_type]

    def get_handlers(self, event_type: type[BaseModel] | None = None) -> list[tuple[type[BaseModel], Handler]]:
        """Return registered handlers as (event_type, handler) pairs.

        Backward-compatible convenience method. Use get_entries() when
        retry policy is needed.
        """
        return [(e.event_type, e.handler) for e in self.get_entries(event_type)]

    def get_event_types(self) -> list[type[BaseModel]]:
        """Return all distinct event types that have registered handlers."""
        seen: dict[int, type[BaseModel]] = {}
        for entry in self._entries:
            seen[id(entry.event_type)] = entry.event_type
        return list(seen.values())

    @property
    def size(self) -> int:
        return len(self._entries)

    def clear(self) -> None:
        """Remove all entries (for testing)."""
        self._entries.clear()


@lru_cache
def get_handler_registry() -> HandlerRegistry:
    """Get or create the singleton HandlerRegistry instance.

    Returns:
        The HandlerRegistry instance.
    """
    return HandlerRegistry()


def handles(event_type: type[BaseModel], *, retry: RetryPolicy | None = None):
    """Decorator that marks a function as a handler for an event type.

    The handler is automatically registered in the global HandlerRegistry
    on import. The wiring layer reads the registry at bootstrap time and
    subscribes each handler to the appropriate channel.

    The handler knows nothing about channels or transport -- it only
    declares which event type it handles.

    Args:
        event_type: Pydantic BaseModel class to handle.
        retry: Optional retry policy. None means no retry (default).

    Usage::

        @handles(SchemaDefinitionChanged)
        async def on_schema_changed(event: SchemaDefinitionChanged) -> None:
            client.invalidate(event.owner_id, event.scope_id)

        @handles(AuditTrailEventReceived, retry=RetryPolicy(max_attempts=3))
        async def on_audit_event(event: AuditTrailEventReceived) -> None:
            await deliver(event)
    """

    def decorator(fn: Handler) -> Handler:
        setattr(fn, _HANDLES_ATTR, event_type)
        get_handler_registry().register(event_type, fn, retry=retry)
        return fn

    return decorator


class ChannelFactory:
    """Creates broker-backed channels from a URL.

    Each channel type registers a creator function under its URL scheme.
    The factory parses the URL, looks up the scheme, and delegates to the
    registered creator.

    Channel modules register themselves on import::

        from sonnet_server.messaging.types import get_channel_factory

        def _create_nats(parsed_url) -> Sink:
            ...

        get_channel_factory().register("nats", _create_nats)

    The wiring layer calls the factory without knowing about specific
    channel types::

        channel = get_channel_factory().create(url)
    """

    def __init__(self) -> None:
        self._creators: dict[str, Callable[[Any], Sink]] = {}

    def register(self, scheme: str, creator: Callable[[Any], Sink]) -> None:
        """Register a channel or publisher creator for a URL scheme.

        Args:
            scheme: URL scheme (e.g. "nats", "redis", "kafka"). Case-insensitive.
            creator: Callable that receives a ``urllib.parse.ParseResult``
                     and returns a ``Channel`` or ``Publisher`` instance.
        """
        key = scheme.lower()
        if key in self._creators:
            raise ValueError(f"Channel scheme '{key}' already registered")
        self._creators[key] = creator
        logger.trace("ChannelFactory: registered scheme '{}'", key)

    @property
    def schemes(self) -> list[str]:
        """Return the registered URL schemes, sorted alphabetically."""
        return sorted(self._creators)

    def create(self, url: str) -> Sink | None:
        """Create a channel or publisher from a broker URL.

        Parses the URL, looks up the scheme in the registry, and
        calls the registered creator. Returns None if the scheme
        is not recognized.

        Args:
            url: Broker URL (e.g. "nats://localhost:4222?subject=sonnet.internal").

        Returns:
            A Channel or Publisher instance, or None if the scheme is unknown.
        """
        from urllib.parse import urlparse

        parsed = urlparse(url)
        key = parsed.scheme.lower()

        creator = self._creators.get(key)
        if creator is None:
            logger.warning("Unknown channel scheme '{}' in URL: {}", key, url)
            return None

        return creator(parsed)

    def get_schemes(self) -> list[str]:
        """Return all registered URL schemes."""
        return list(self._creators.keys())

    @property
    def size(self) -> int:
        return len(self._creators)


@lru_cache
def get_channel_factory() -> ChannelFactory:
    """Get or create the singleton ChannelFactory instance.

    Returns:
        The ChannelFactory instance.
    """
    return ChannelFactory()


# -- Private helpers --------------------------------------------------------


def handler_display_name(handler: Handler) -> str:
    """Return a human-readable name for a handler (for logging and introspection)."""
    return getattr(handler, "__qualname__", None) or getattr(handler, "__name__", repr(handler))


def _derive_type_name(event_class: type[BaseModel]) -> str:
    """Derive a CloudEvents type name from a Pydantic class name.

    Converts CamelCase to dotted lowercase with ``sonnet.`` prefix::

        SchemaDefinitionChanged -> sonnet.schema_definition_changed
        AuditTrailEventReceived -> sonnet.audit_trail_event_received
    """
    import re

    name = event_class.__name__
    # Insert underscore before uppercase letters (except the first)
    snake = re.sub(r"(?<=[a-z0-9])([A-Z])", r"_\1", name).lower()
    return f"sonnet.{snake}"


def _resolve_dependencies(parameters: list[inspect.Parameter]) -> dict[str, Any]:
    """Resolve dependencies from the ServiceRegistry for handler parameters.

    Returns an empty dict if the registry is not available (e.g. in tests).
    Logs a warning if the registry import fails, since this likely
    indicates a misconfigured environment.
    """
    kwargs: dict[str, Any] = {}
    try:
        from sonnet_server.services.registry import get_service_registry

        registry = get_service_registry()
        for param in parameters:
            if param.annotation == inspect.Parameter.empty:
                continue
            try:
                service = registry.get(param.annotation)
                kwargs[param.name] = service
            except KeyError, AttributeError:
                pass
    except ImportError:
        logger.warning("ServiceRegistry not available -- handlers will be called without dependency injection")
    return kwargs
