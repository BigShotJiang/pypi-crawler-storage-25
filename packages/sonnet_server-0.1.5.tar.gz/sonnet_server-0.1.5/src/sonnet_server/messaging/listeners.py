"""Built-in handlers for messaging infrastructure events."""

from __future__ import annotations

from loguru import logger

from sonnet_server.messaging.events import MessagingPingEvent
from sonnet_server.messaging.types import handles


@handles(MessagingPingEvent)
async def on_messaging_ping(event: MessagingPingEvent) -> None:
    """Log receipt of a MessagingPingEvent.

    Confirms that the full emit -> channel -> dispatch path is working.
    The trace_id in the log correlates with the POST /messaging/ping request.
    """
    logger.info("messaging ping received (trace_id={})", event.trace_id)
