"""Message router -- routes events to channels based on bindings.

The router is the central coordinator. It holds bindings (event type
-> channels) and subscriptions (channel + event type -> handlers).
On emit, it looks up all channels bound to the event type and delivers
to each.

Services call router.emit(event) and know nothing about channels.
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import json
import threading
from typing import Any

from loguru import logger
from pydantic import BaseModel

from sonnet_server.messaging.types import (
    Binding,
    Channel,
    EventPredicate,
    Handler,
    Sink,
    TypeRegistry,
    _current_event_id_var,
    get_correlation_id,
    new_event_id,
)


class MessageRouter:
    """Routes events to channels and publishers based on bindings.

    Two internal maps:
    - bindings: event_type -> [Binding(sink, predicate), ...]  (publish side)
    - sinks: name -> Channel | Publisher                        (lifecycle)

    The router delivers events to all bound sinks on emit. For Channels
    it delegates to the channel's own dispatch mechanism (in-process or
    broker). For Publishers it always uses publish().
    """

    def __init__(self) -> None:
        self._bindings: dict[type[BaseModel], list[Binding]] = {}
        self._sinks: dict[str, Sink] = {}
        self._type_registry = TypeRegistry()
        self._handler_retries: dict[int, Any] = {}  # id(handler) -> RetryPolicy
        self._executor_lock = threading.Lock()
        self._sync_executor: concurrent.futures.ThreadPoolExecutor | None = None
        self._started = False
        logger.trace("MessageRouter initialized")

    @property
    def started(self) -> bool:
        """Return True if the router has been started."""
        return self._started

    @property
    def type_registry(self) -> TypeRegistry:
        """Access the type registry for event type registration."""
        return self._type_registry

    @property
    def sink_names(self) -> list[str]:
        """Return the names of all registered sinks, sorted alphabetically."""
        return sorted(self._sinks)

    @property
    def handler_count(self) -> int:
        """Return the total number of registered handler entries."""
        from sonnet_server.messaging.types import get_handler_registry

        return get_handler_registry().size

    # -- Sink management ------------------------------------------------

    def add_sink(self, sink: Sink) -> None:
        """Register a channel or publisher with the router.

        The router tracks all sinks for lifecycle management (start/stop).
        Sinks are also registered implicitly on first bind() call.

        Does NOT start the sink -- call start_sink() or router.start()
        for lifecycle management.
        """
        if sink.name in self._sinks:
            existing = self._sinks[sink.name]
            if existing is not sink:
                raise ValueError(f"Sink name '{sink.name}' already registered to a different instance")
            return
        self._sinks[sink.name] = sink
        logger.trace("Sink '{}' registered ({})", sink.name, type(sink).__name__)

    async def add_and_start_sink(self, sink: Sink) -> None:
        """Register a sink and start it immediately.

        Use this for dynamic sinks added after router.start() has been
        called (e.g. per-tenant publishers loaded from DB config).
        """
        self.add_sink(sink)
        await sink.start()
        logger.debug("Sink '{}' started dynamically", sink.name)

    def get_sink(self, name: str) -> Sink | None:
        """Look up a channel or publisher by name."""
        return self._sinks.get(name)

    def get_sinks_by_prefix(self, prefix: str) -> list[Sink]:
        """Return all sinks whose name starts with the given prefix.

        Used for reconciliation: a domain module queries its own sinks
        (e.g. ``auditing-``) and diffs against desired DB config to
        determine which sinks to add, remove, or replace.
        """
        return [s for name, s in self._sinks.items() if name.startswith(prefix)]

    async def remove_sink(self, name: str) -> None:
        """Stop and remove a sink by name.

        Removes all bindings for this sink, stops it, and deregisters it.
        No-op if the name is not registered.
        """
        sink = self._sinks.get(name)
        if sink is None:
            return
        for event_type in list(self._bindings.keys()):
            self._bindings[event_type] = [b for b in self._bindings[event_type] if b.sink is not sink]
            if not self._bindings[event_type]:
                del self._bindings[event_type]
        await sink.stop()
        self._sinks.pop(name, None)
        logger.debug("Sink '{}' stopped and removed", name)

    async def replace_sink(self, name: str, new_sink: Sink) -> None:
        """Replace a named sink atomically: stop old, start new, rebind.

        Transfers all bindings from the old sink to the new one, then
        stops the old sink and starts the new one. If no sink with
        ``name`` is registered, the new sink is simply added and started.

        The new sink must have the same name as the old one.
        """
        if new_sink.name != name:
            raise ValueError(f"New sink name '{new_sink.name}' does not match expected name '{name}'")

        old_sink = self._sinks.get(name)

        if old_sink is not None and old_sink is new_sink:
            return

        # Transfer bindings from old sink to new sink
        for _event_type, bindings in self._bindings.items():
            for binding in bindings:
                if binding.sink is old_sink:
                    binding.sink = new_sink

        # Swap in registry
        self._sinks[name] = new_sink

        # Lifecycle: start new first, then stop old (minimise gap)
        await new_sink.start()
        if old_sink is not None:
            await old_sink.stop()

        logger.debug("Sink '{}' replaced ({})", name, type(new_sink).__name__)

    # -- Binding (publish side) -----------------------------------------

    def bind(
        self,
        event_type: type[BaseModel],
        channel: Sink,
        predicate: EventPredicate | None = None,
    ) -> None:
        """Bind an event type to a channel or publisher.

        When this event type is emitted, the router delivers it to
        this sink (in addition to any other bound sinks).

        Args:
            event_type: Pydantic BaseModel class.
            channel: Target Channel or Publisher.
            predicate: Optional filter. Only events where predicate(event)
                       returns True are delivered. None means all events.
        """
        self.add_sink(channel)

        if event_type not in self._bindings:
            self._bindings[event_type] = []

        for existing in self._bindings[event_type]:
            if existing.sink is channel and existing.predicate is predicate:
                return

        self._bindings[event_type].append(Binding(sink=channel, predicate=predicate))
        logger.trace("Bound {} -> '{}' ({})", event_type.__name__, channel.name, type(channel).__name__)

    def unbind(self, event_type: type[BaseModel], channel: Sink) -> None:
        """Remove all bindings of an event type to a sink."""
        if event_type in self._bindings:
            self._bindings[event_type] = [b for b in self._bindings[event_type] if b.sink is not channel]
            if not self._bindings[event_type]:
                del self._bindings[event_type]

    # -- Subscribe (consume side) ---------------------------------------

    def subscribe(
        self,
        event_type: type[BaseModel],
        channel: Channel,
        handler: Handler,
    ) -> None:
        """Subscribe a handler to events arriving on a channel.

        Only full Channel instances support subscriptions -- Publishers
        are outbound-only and cannot be subscribed to.

        For channels that support direct dispatch (in-process), the
        handler is registered directly. For broker-backed channels,
        the handler is called when an event of the given type arrives.

        Args:
            event_type: Event type to handle.
            channel: Source channel (must be a full Channel, not a Publisher).
            handler: Async function or class with handle() method.
        """
        self.add_sink(channel)
        channel.add_handler(event_type, handler)
        logger.trace("Subscribed handler to channel '{}' for {}", channel.name, event_type.__name__)

    def wire_handlers(
        self,
        channel: Channel,
        event_types: list[type[BaseModel]] | None = None,
    ) -> int:
        """Wire all registered @handles handlers to a channel.

        Only full Channel instances support handler wiring -- Publishers
        are outbound-only.

        Reads the global HandlerRegistry and subscribes each handler
        to the given channel. Also creates bindings (event_type -> channel)
        for every wired event type. Retry policies from @handles are
        stored in ``_handler_retries`` for use during dispatch.

        Args:
            channel: Target channel for the handlers.
            event_types: If provided, only wire handlers for these event
                          types. If None, wire all registered handlers.

        Returns:
            Number of handlers wired.
        """
        from sonnet_server.messaging.types import get_handler_registry

        registry = get_handler_registry()
        entries = registry.get_entries()
        count = 0

        needs_type_registry = not channel.supports_dispatch()

        for entry in entries:
            if event_types is not None and entry.event_type not in event_types:
                continue
            self.bind(entry.event_type, channel)
            self.subscribe(entry.event_type, channel, entry.handler)
            # Store retry policy for handler lookup during dispatch
            self._handler_retries[id(entry.handler)] = entry.retry
            # Broker channels need event types registered for serialization/deserialization
            if needs_type_registry:
                self._type_registry.ensure_registered(entry.event_type)
            count += 1

        logger.trace("Wired {} handlers to channel '{}'", count, channel.name)
        return count

    # -- Emit -----------------------------------------------------------

    def emit(
        self,
        event: BaseModel,
        sinks: list[Sink] | None = None,
    ) -> None:
        """Emit an event (fire-and-forget).

        Schedules delivery as an async task if a loop is running,
        otherwise submits to a background thread. Returns immediately
        in both cases.

        Delivers to all sinks bound to this event type. If
        ``sinks`` is provided, delivers only to those sinks
        instead of the bindings.
        """
        loop = asyncio._get_running_loop()
        if loop is not None:
            loop.create_task(self._deliver(event, sinks))
        else:
            self._get_executor().submit(asyncio.run, self._deliver(event, sinks))

    async def emit_and_wait(
        self,
        event: BaseModel,
        sinks: list[Sink] | None = None,
    ) -> list[Any]:
        """Emit an event and wait for in-process handler results.

        Returns results from channels that support direct dispatch
        only. Broker-backed channels and publishers receive the event
        but their downstream consumers are asynchronous.
        """
        return await self._deliver(event, sinks)

    def emit_sync(
        self,
        event: BaseModel,
        sinks: list[Sink] | None = None,
    ) -> list[Any]:
        """Emit synchronously and wait for in-process results.

        Use from synchronous contexts (e.g. readiness checks).
        """
        loop = asyncio._get_running_loop()
        if loop is not None:
            future = self._get_executor().submit(asyncio.run, self._deliver(event, sinks))
            return future.result()
        return asyncio.run(self._deliver(event, sinks))

    async def emit_to(self, event: BaseModel, sink_name: str) -> None:
        """Emit an event directly to a named sink, bypassing bindings.

        Use this when a service needs to publish an event to a specific
        outbound destination (e.g. a per-tenant publisher) that was
        registered dynamically from DB config.

        The sink must be registered with the router. If the name is not
        found, a warning is logged and delivery is skipped.

        Args:
            event: Pydantic event to deliver.
            sink_name: Name of the target sink (as registered via add_sink()).
        """
        sink = self._sinks.get(sink_name)
        if sink is None:
            logger.warning("emit_to: sink '{}' not found, skipping delivery of {}", sink_name, type(event).__name__)
            return
        await self._deliver_to_sink(sink, event, [])

    # -- Lifecycle ------------------------------------------------------

    async def start(self) -> None:
        """Start all registered sinks."""
        for sink in self._sinks.values():
            await sink.start()
        self._started = True
        logger.debug("MessageRouter started ({} sinks)", len(self._sinks))

    async def stop(self) -> None:
        """Stop all sinks and release resources."""
        for sink in self._sinks.values():
            await sink.stop()
        with self._executor_lock:
            if self._sync_executor is not None:
                self._sync_executor.shutdown(wait=True)
                self._sync_executor = None
        self._started = False
        logger.debug("MessageRouter stopped")

    # -- Introspection --------------------------------------------------

    def get_bindings(self, event_type: type[BaseModel]) -> list[Binding]:
        """Get all bindings for an event type."""
        return list(self._bindings.get(event_type, []))

    def get_registered_event_types(self) -> list[type[BaseModel]]:
        """Get all event types that have bindings."""
        return list(self._bindings.keys())

    def get_sink_names(self) -> list[str]:
        """Get names of all registered sinks."""
        return list(self._sinks.keys())

    # -- Internal -------------------------------------------------------

    def _get_executor(self) -> concurrent.futures.ThreadPoolExecutor:
        """Get or create the shared thread pool executor (thread-safe)."""
        with self._executor_lock:
            if self._sync_executor is None:
                self._sync_executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
            return self._sync_executor

    async def _deliver(self, event: BaseModel, sinks: list[Sink] | None = None) -> list[Any]:
        """Deliver an event to bound sinks. Returns in-process results."""
        event_type = type(event)
        in_process_results: list[Any] = []

        if sinks is not None:
            for sink in sinks:
                await self._deliver_to_sink(sink, event, in_process_results)
        else:
            for binding in self._bindings.get(event_type, []):
                if not binding.accepts(event):
                    continue
                await self._deliver_to_sink(binding.sink, event, in_process_results)

        return in_process_results

    async def _deliver_to_sink(self, sink: Sink, event: BaseModel, in_process_results: list[Any]) -> None:
        """Deliver an event to a single sink (Channel or Publisher)."""
        if isinstance(sink, Channel) and sink.supports_dispatch():
            results = await sink.dispatch(event)
            in_process_results.extend(results)
        else:
            await self._publish_to_broker(sink, event)

    async def _publish_to_broker(self, sink: Sink, event: BaseModel) -> None:
        """Serialize an event and publish to a broker-backed sink.

        Includes correlation_id and causation_id in the CloudEvents
        envelope for distributed tracing. If no correlation_id is set
        in the current context, a new one is generated.
        """
        event_type = type(event)
        type_name = self._type_registry.get_type_name(event_type)

        if type_name is None:
            logger.warning(
                "Event type {} not registered in type registry, skipping publish to '{}'", event_type.__name__, sink.name
            )
            return

        event_id = new_event_id()
        correlation_id = get_correlation_id() or event_id
        # causation_id = the id of the event currently being handled (if any)
        causation_id = _current_event_id_var.get()

        envelope = {
            "id": event_id,
            "type": type_name,
            "correlation_id": correlation_id,
            "causation_id": causation_id,
            "data": event.model_dump(mode="json"),
        }
        payload = json.dumps(envelope).encode("utf-8")

        try:
            await sink.publish(type_name, payload)
            logger.debug("Published {} to '{}' ({})", event_type.__name__, sink.name, type(sink).__name__)
        except Exception:
            logger.exception("Failed to publish {} to '{}'", event_type.__name__, sink.name)
