"""CLI module for sonnet-server.

Provides command-line interface for administrative tasks like database management.
"""

from sonnet_server.cli.app import app

__all__ = ["app"]
