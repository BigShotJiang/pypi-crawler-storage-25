"""CLI entry point.

Usage:
    python -m sonnet_server.cli db check
    python -m sonnet_server.cli db upgrade
    sonnet-server-cli db check
    sonnet-server-cli db upgrade
"""

import sys

from loguru import logger

import sonnet_server
from sonnet_server.cli.app import app


def _configure_cli_logging() -> None:
    """Configure loguru for CLI (compact format: level + message, no timestamps)."""
    logger.remove()  # Remove default handler
    logger.add(
        sys.stderr,
        format="<level>{level: <8}</level> | <level>{message}</level>",
        level="INFO",
        colorize=True,
    )
    # Enable logging for the server package
    logger.enable(sonnet_server.__name__)


def main() -> None:
    """CLI entry point with logging configuration."""
    _configure_cli_logging()
    app()


if __name__ == "__main__":
    main()
