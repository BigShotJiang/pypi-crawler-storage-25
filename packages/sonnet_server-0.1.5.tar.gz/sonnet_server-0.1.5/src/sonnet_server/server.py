"""Server startup utilities for sonnet-server consumers.

Provides :func:`run_uvicorn` -- a convenience wrapper around the
uvicorn lifecycle (Config, Server, logging wiring, reload supervisor)
that consumers call from their ``main.py`` ``run`` command.

Using this helper is optional. All uvicorn primitives remain directly
importable for consumers that need full control.
"""

from __future__ import annotations

from typing import Any

import uvicorn

from sonnet_server.logging import wire_uvicorn_logging
from sonnet_server.settings import Settings


def run_uvicorn(app_module: str, settings: Settings, **uvicorn_kwargs: Any) -> None:
    """Start a uvicorn server and block until it exits.

    Handles the full uvicorn lifecycle:
    - Builds ``uvicorn.Config`` from ``settings`` and any extra kwargs
    - Wires uvicorn loggers through loguru (must happen after Config.__init__)
    - Runs the reload supervisor (``ChangeReload``) when ``settings.reload`` is
      ``True``, otherwise runs the server directly

    Extra keyword arguments are forwarded verbatim to ``uvicorn.Config``,
    allowing consumers to pass ``reload_dirs``, ``reload_includes``,
    ``reload_excludes``, or any other uvicorn option.

    Args:
        app_module: Dotted import path to the ASGI app (e.g. ``"my_server.app:app"``).
        settings: Application settings -- ``host``, ``port``, and ``reload`` are read
            from here; everything else can be overridden via ``uvicorn_kwargs``.
        **uvicorn_kwargs: Additional arguments forwarded to ``uvicorn.Config``.

    Example::

        from sonnet_server.server import run_uvicorn
        from my_server.settings import get_settings

        run_uvicorn("my_server.app:app", get_settings())

        # With reload dirs for development:
        run_uvicorn(
            "my_server.app:app",
            get_settings(),
            reload_dirs=["/path/to/models", "/path/to/config"],
            reload_includes=["*.py", "*.yaml"],
        )
    """
    config = uvicorn.Config(
        app_module,
        host=settings.host,
        port=settings.port,
        reload=settings.reload,
        log_config=None,
        **uvicorn_kwargs,
    )
    server = uvicorn.Server(config)

    # Wire uvicorn loggers through loguru after Config.__init__ has installed
    # its own handlers (uvicorn resets handlers during __init__).
    wire_uvicorn_logging()

    if config.should_reload:
        from uvicorn.supervisors import ChangeReload

        sock = config.bind_socket()
        ChangeReload(config, target=server.run, sockets=[sock]).run()
    else:
        server.run()


__all__ = ["run_uvicorn"]
