"""Guard dependencies, security protocols, and ambient request context.

Guards are FastAPI dependencies that enforce request preconditions
(authentication, tenant validation, tenant access). They raise
HTTPException on failure and set ContextVars for downstream code.

CredentialValidator, TenantValidator, and TenantAccessChecker use
dependency inversion: protocols are defined here (infrastructure),
implementations live in domain modules (authn, organizations, users),
and di.py wires them at startup.

This module is infrastructure -- it has no imports from domain modules.
"""

from contextvars import ContextVar
from dataclasses import dataclass
from typing import Protocol

from fastapi import Depends, Header, HTTPException

_WWW_AUTHENTICATE = {"WWW-Authenticate": "Bearer"}


# ---------------------------------------------------------------------------
# AuthContext -- ambient auth identity for the current request
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AuthContext:
    """Authenticated identity for the current request.

    Set by require_auth, read by services via get_current_auth().
    """

    user_id: str
    username: str
    email: str | None = None
    tenant_id: str | None = None


_current_auth: ContextVar[AuthContext | None] = ContextVar("_current_auth", default=None)


def get_current_auth() -> AuthContext:
    """Return the auth context for the current request.

    Raises:
        RuntimeError: If called outside a require_auth scope.
    """
    ctx = _current_auth.get()
    if ctx is None:
        raise RuntimeError("No auth context -- called outside a require_auth-protected request")
    return ctx


# ---------------------------------------------------------------------------
# TenantContext -- ambient tenant identity for the current request
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TenantContext:
    """Validated tenant identity for the current request.

    Set by require_tenant, read by services via get_current_tenant().
    """

    org_id: str
    name: str
    status: str
    is_platform_tenant: bool = False


_current_tenant: ContextVar[TenantContext | None] = ContextVar("_current_tenant", default=None)


def get_current_tenant() -> TenantContext:
    """Return the tenant context for the current request.

    Raises:
        RuntimeError: If called outside a require_tenant scope.
    """
    ctx = _current_tenant.get()
    if ctx is None:
        raise RuntimeError("No tenant context -- called outside a require_tenant-protected request")
    return ctx


# ---------------------------------------------------------------------------
# CredentialValidator protocol -- dependency inversion
# ---------------------------------------------------------------------------


class CredentialValidator(Protocol):
    """Validates a bearer token and returns an AuthContext.

    Current implementation: JwtCredentialValidator (authn module).
    Future: dispatch on token type for machine identity tokens
    (see machine-identities.md).
    """

    def validate(self, bearer_token: str) -> AuthContext | None:
        """Validate a bearer token.

        Args:
            bearer_token: Raw token string (without "Bearer " prefix).

        Returns:
            AuthContext if valid, None if invalid.
        """
        ...


# Set during application startup by di.py. Re-set on dev server hot-reload.
_credential_validator: CredentialValidator | None = None


def set_credential_validator(validator: CredentialValidator) -> None:
    """Register the credential validator implementation.

    Called from di.py during service wiring. Idempotent -- re-registration
    replaces the previous validator (needed for dev server hot-reload).
    """
    global _credential_validator  # noqa: PLW0603
    _credential_validator = validator


def get_credential_validator() -> CredentialValidator:
    """Return the registered credential validator.

    Raises:
        RuntimeError: If no validator has been registered.
    """
    if _credential_validator is None:
        raise RuntimeError("No CredentialValidator registered -- call set_credential_validator() at startup")
    return _credential_validator


# ---------------------------------------------------------------------------
# TenantValidator protocol -- dependency inversion
# ---------------------------------------------------------------------------


class TenantValidator(Protocol):
    """Validates a tenant org_id and returns a TenantContext.

    Implementation: OrganizationTenantValidator (organizations module).
    Registered in di.py via set_tenant_validator().
    """

    def validate(self, org_id: str) -> TenantContext | None:
        """Validate a tenant organization.

        Args:
            org_id: Organization business key.

        Returns:
            TenantContext if the org is valid and active, None otherwise.
        """
        ...


# Set during application startup by di.py. Re-set on dev server hot-reload.
_tenant_validator: TenantValidator | None = None


def set_tenant_validator(validator: TenantValidator) -> None:
    """Register the tenant validator implementation.

    Called from di.py during service wiring. Idempotent -- re-registration
    replaces the previous validator (needed for dev server hot-reload).
    """
    global _tenant_validator  # noqa: PLW0603
    _tenant_validator = validator


def get_tenant_validator() -> TenantValidator:
    """Return the registered tenant validator.

    Raises:
        RuntimeError: If no validator has been registered.
    """
    if _tenant_validator is None:
        raise RuntimeError("No TenantValidator registered -- call set_tenant_validator() at startup")
    return _tenant_validator


# ---------------------------------------------------------------------------
# TenantAccessChecker protocol -- dependency inversion
# ---------------------------------------------------------------------------


class TenantAccessChecker(Protocol):
    """Checks whether a user has access to a given tenant.

    Implementation: TenantAssignmentService (users module).
    Registered in di.py via set_tenant_access_checker().
    """

    def has_tenant_access(self, user_id: str, org_id: str) -> bool:
        """Check if a user has access to a tenant.

        Args:
            user_id: User identifier.
            org_id: Organization business key.

        Returns:
            True if access is granted, False otherwise.
        """
        ...


# Set during application startup by di.py. Re-set on dev server hot-reload.
_tenant_access_checker: TenantAccessChecker | None = None


def set_tenant_access_checker(checker: TenantAccessChecker) -> None:
    """Register the tenant access checker implementation.

    Called from di.py during service wiring. Idempotent -- re-registration
    replaces the previous checker (needed for dev server hot-reload).
    """
    global _tenant_access_checker  # noqa: PLW0603
    _tenant_access_checker = checker


def get_tenant_access_checker() -> TenantAccessChecker:
    """Return the registered tenant access checker.

    Raises:
        RuntimeError: If no checker has been registered.
    """
    if _tenant_access_checker is None:
        raise RuntimeError("No TenantAccessChecker registered -- call set_tenant_access_checker() at startup")
    return _tenant_access_checker


# ---------------------------------------------------------------------------
# require_auth -- FastAPI dependency
# ---------------------------------------------------------------------------


def require_auth(
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> AuthContext:
    """FastAPI dependency that enforces authentication.

    Extracts the Bearer token from the Authorization header,
    validates it via the registered CredentialValidator, and
    sets the ambient AuthContext ContextVar.

    Returns:
        AuthContext for the authenticated user.

    Raises:
        HTTPException 401: If the token is missing, malformed, or invalid.
    """
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing authorization header", headers=_WWW_AUTHENTICATE)

    if not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=401,
            detail="Invalid authorization header format",
            headers=_WWW_AUTHENTICATE,
        )

    token = authorization[7:]  # len("Bearer ") == 7
    if not token:
        raise HTTPException(status_code=401, detail="Missing bearer token", headers=_WWW_AUTHENTICATE)

    validator = get_credential_validator()
    auth_context = validator.validate(token)
    if auth_context is None:
        raise HTTPException(status_code=401, detail="Invalid or expired token", headers=_WWW_AUTHENTICATE)

    _current_auth.set(auth_context)
    return auth_context


# ---------------------------------------------------------------------------
# require_tenant -- FastAPI dependency
# ---------------------------------------------------------------------------


def require_tenant(auth: AuthContext = Depends(require_auth)) -> TenantContext:
    """FastAPI dependency that enforces tenant context.

    Reads the tenant_id from the authenticated JWT claims, validates the
    organization via the registered TenantValidator (cached), verifies
    the user has access via the registered TenantAccessChecker, and sets
    the ambient TenantContext ContextVar.

    Must be composed after require_auth -- takes AuthContext as a dependency.

    Returns:
        TenantContext for the active tenant.

    Raises:
        HTTPException 400: If the token carries no tenant_id claim.
        HTTPException 403: If the org is inactive, not found, or user lacks access.
    """
    org_id = auth.tenant_id
    if not org_id:
        raise HTTPException(status_code=400, detail="No tenant selected -- switch to a tenant first")

    tenant_ctx = get_tenant_validator().validate(org_id)
    if tenant_ctx is None:
        raise HTTPException(status_code=403, detail="Invalid or inactive tenant")

    access_checker = get_tenant_access_checker()
    if not access_checker.has_tenant_access(auth.user_id, org_id):
        raise HTTPException(status_code=403, detail="Access to this tenant is not allowed")

    _current_tenant.set(tenant_ctx)
    return tenant_ctx
