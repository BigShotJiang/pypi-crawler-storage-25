"""Extension protocol for lifecycle-aware subsystems.

An extension is a subsystem that hooks into the server lifecycle to add
capabilities: database connectivity, messaging, caching, observability,
etc. Each extension is opt-in -- a consumer declares which extensions
it uses; everything else is absent.

The core server handles only: FastAPI app creation, settings, logging,
DI, exception handling, and system endpoints (/ping, /version,
/health-check). Everything else is an extension.

Two kinds of extension
-----------------------
**Infrastructure extensions** (``profile`` is ``None``) are always active
when registered. They start unconditionally and mount their system routes
at the top level. Examples: ``DatabaseExtension``, ``MessagingExtension``,
``CacheExtension``.

**Profile extensions** (``profile`` returns a string) are conditionally
active based on the server profile configuration. They only start and
mount routes when their profile name is in the active profile set.
Examples: ``RestExtension`` (profile ``"rest"``), ``GraphQLExtension``
(profile ``"graphql"``), ``McpExtension`` (profile ``"mcp"``).

Profile resolution
-------------------
The ``ExtensionRegistry`` derives the set of valid profile names from all
registered profile extensions. ``parse_profile()`` accepts this set at
call time -- no profile names are hardcoded in the library. When
``profiles=None`` (no config), all registered profiles are active.

Startup order
--------------
1. Infrastructure extensions start in registration order.
2. Profile extensions start in registration order, but only those whose
   profile is in the active set.
3. Shutdown runs in reverse order for all extensions that started.

Import conventions in extension methods
---------------------------------------
Extensions use deferred (local) imports inside ``on_startup``, ``on_shutdown``,
and ``routers`` to avoid circular imports and to keep module-level imports
minimal. Only ``Extension``, ``Settings``, and ``APIRouter`` -- which are
resolved before any extension is instantiated -- are imported at the top level.
All subsystem imports (database, messaging, cache, check modules) are deferred.
"""

from __future__ import annotations

import abc

from fastapi import APIRouter, FastAPI
from loguru import logger

from sonnet_server.settings import Settings


class Extension(abc.ABC):
    """Base class for lifecycle-aware server extensions.

    Subclass this and override the hooks you need. All methods are
    no-ops by default so extensions only implement what they use.

    Extensions must declare a unique ``name`` (abstract property).

    Profile-gated extensions also declare a ``profile`` name. The registry
    only starts them when their profile is in the active set.
    """

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Unique identifier for this extension (e.g. 'database', 'rest').

        Used in log messages and startup summaries. Must be unique across
        all extensions registered in a single server.
        """

    @property
    def profile(self) -> str | None:
        """Profile name that gates this extension, or ``None`` if always active.

        When ``None`` (default), the extension starts unconditionally.
        When set (e.g. ``"rest"``, ``"graphql"``, ``"mcp"``), the extension
        only starts when its profile name is in the active profile set.
        """
        return None

    @property
    def router_prefix(self) -> str:
        """URL prefix for routers returned by ``routers()``.

        Infrastructure extensions default to ``""`` (top-level mount).
        Profile extensions override this to declare their own prefix
        (e.g. ``"/api"``, ``"/graphql"``).
        """
        return ""

    async def on_startup(self, settings: Settings) -> None:  # noqa: B027
        """Called during server startup (lifespan entry).

        Import check modules, initialize connections, bootstrap subsystems.
        Called in registration order. Override only if needed.
        """

    async def on_shutdown(self) -> None:  # noqa: B027
        """Called during server shutdown (lifespan exit).

        Dispose connections, stop background tasks. Called in
        reverse registration order. Override only if needed.
        """

    def routers(self) -> list[APIRouter]:
        """Return routers to mount on the app.

        For infrastructure extensions, routers are mounted at the top level
        (``router_prefix`` defaults to ``""``).
        For profile extensions, routers are mounted at ``router_prefix``.
        """
        return []

    def lifespan_context(self, app: FastAPI) -> object | None:
        """Return an async context manager for this extension's lifespan, or ``None``.

        When a sub-application requires its own lifespan (e.g. FastMCP's
        ``StreamableHTTPSessionManager``), override this method to return the
        context manager. ``create_app()`` will nest it inside the main
        application lifespan using ``AsyncExitStack``.

        Most extensions do not need this -- ``on_startup`` / ``on_shutdown``
        is sufficient for the majority of use cases.

        Returns:
            An async context manager, or ``None`` (default, no-op).

        Example::

            def lifespan_context(self, app: FastAPI):
                return self._sub_app.router.lifespan_context(app)
        """
        return None

    def mount(self, app: FastAPI) -> None:  # noqa: B027
        """Mount ASGI sub-applications or inject routes directly onto the app.

        Called after ``on_startup`` completes, alongside ``mount_routers()``.
        Override this when ``routers()`` is not sufficient -- for example when
        an extension wraps a third-party ASGI application (MCP, WebSocket
        server, admin UI) whose routes cannot be expressed as an
        ``APIRouter``.

        Most extensions do not need this and should leave it as a no-op.
        Use ``routers()`` for standard FastAPI routers.
        """


class ExtensionRegistry:
    """Manages registered extensions and drives their lifecycle."""

    def __init__(self) -> None:
        self._extensions: list[Extension] = []
        self._started: list[Extension] = []  # tracks which extensions actually started

    def register(self, extension: Extension) -> None:
        """Register an extension. Order matters -- startup runs in registration order."""
        self._extensions.append(extension)
        logger.debug("Extension registered: {}", extension.name)

    @property
    def extensions(self) -> list[Extension]:
        """All registered extensions (started or not)."""
        return list(self._extensions)

    @property
    def started(self) -> list[Extension]:
        """Extensions that successfully completed ``on_startup``."""
        return list(self._started)

    @property
    def profile_names(self) -> set[str]:
        """Set of profile names declared by all registered profile extensions."""
        return {ext.profile for ext in self._extensions if ext.profile is not None}

    def infrastructure_routers(self) -> list[tuple[APIRouter, str]]:
        """Return (router, prefix) pairs from all infrastructure extensions.

        Infrastructure extensions (``profile=None``) are always active and
        their routers are mounted at app creation time so they appear in the
        OpenAPI schema unconditionally.
        """
        result: list[tuple[APIRouter, str]] = []
        for ext in self._extensions:
            if ext.profile is None:
                for router in ext.routers():
                    result.append((router, ext.router_prefix))
        return result

    def mount_routers(self, app: FastAPI, active_profiles: set[str]) -> None:
        """Mount routers and ASGI sub-applications from active profile extensions.

        Calls ``routers()`` for standard FastAPI router mounting and ``mount()``
        for extensions that need direct app-level integration (ASGI sub-apps,
        injected routes).

        Only profile extensions (``profile`` is not ``None``) are handled
        here -- infrastructure routers are mounted at app creation time via
        ``infrastructure_routers()``.
        """
        for ext in self._extensions:
            if ext.profile is None:
                continue  # already mounted at creation time
            if ext.profile not in active_profiles:
                logger.debug("Extension routes skipped (profile '{}' not active): {}", ext.profile, ext.name)
                continue
            for router in ext.routers():
                app.include_router(router, prefix=ext.router_prefix)
            ext.mount(app)

    async def startup(self, settings: Settings, active_profiles: set[str]) -> None:
        """Start all active extensions in registration order.

        Infrastructure extensions start unconditionally.
        Profile extensions start only when their profile is active.
        Started extensions are tracked for shutdown.
        """
        self._started = []
        for ext in self._extensions:
            if ext.profile is not None and ext.profile not in active_profiles:
                logger.debug("Extension skipped (profile '{}' not active): {}", ext.profile, ext.name)
                continue
            logger.info("Starting extension: {}", ext.name)
            await ext.on_startup(settings)
            self._started.append(ext)

    async def shutdown(self) -> None:
        """Shut down all started extensions in reverse order.

        Errors during shutdown are logged and swallowed so that all
        extensions have a chance to clean up even if one fails.
        Broad exception catching is intentional here -- shutdown teardown
        is the one context where continuity matters more than propagation.
        """
        for ext in reversed(self._started):
            logger.info("Stopping extension: {}", ext.name)
            try:
                await ext.on_shutdown()
            except Exception as e:  # noqa: BLE001 -- intentional: resilient shutdown
                logger.error("Error shutting down extension {}: {}", ext.name, e)


def create_extension_registry(*extensions: Extension) -> ExtensionRegistry:
    """Create a registry pre-populated with the given extensions."""
    registry = ExtensionRegistry()
    for ext in extensions:
        registry.register(ext)
    return registry
