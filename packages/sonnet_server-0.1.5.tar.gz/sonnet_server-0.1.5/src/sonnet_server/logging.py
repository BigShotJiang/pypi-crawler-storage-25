"""Logging configuration for the Sonnet server."""

import logging
import sys

from loguru import logger

_ALWAYS_WARNING_LOGGERS = frozenset(
    {
        "huggingface_hub",
        "sentence_transformers",
        "filelock",
        "watchfiles",
        "httpx",
        "httpcore",
    }
)


class InterceptHandler(logging.Handler):
    """Intercept standard logging messages toward loguru."""

    def emit(self, record):
        # Suppress known noisy third-party loggers below WARNING regardless of app level
        root_name = record.name.split(".")[0]
        if root_name in _ALWAYS_WARNING_LOGGERS and record.levelno < logging.WARNING:
            return

        # Get corresponding loguru level if it exists
        try:
            level = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno

        # Find caller from where the logged message originated
        frame, depth = logging.currentframe(), 2
        while frame and frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1

        logger.opt(depth=depth, exception=record.exc_info).log(level, record.getMessage())


def setup_logging(log_level: str):
    """Configure loguru logging for the entire application.

    Args:
        log_level: Log level to use (from settings, which handles env vars and CLI args).
    """
    # Ensure log level is uppercase
    log_level = log_level.upper()

    # Configure loguru
    logger.remove()  # Remove default handler

    # Custom format with timestamps and source location (uncomment for richer logs):
    # log_format = (
    #     "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
    #     "<level>{level: <8}</level> | "
    #     "<cyan>{module}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
    #     "<level>{message}</level>"
    # )
    # logger.add(sys.stderr, level=log_level, colorize=True, format=log_format)

    logger.add(
        sys.stderr,
        level=log_level,
        colorize=True,
    )

    logger.info("Log level set to: {}", log_level)

    # Redirect all standard logging to loguru
    logging.basicConfig(handlers=[InterceptHandler()], level=0, force=True)

    # Configure all existing loggers to use our handler
    for name in logging.root.manager.loggerDict:
        logging_logger = logging.getLogger(name)
        logging_logger.handlers = [InterceptHandler()]
        logging_logger.propagate = False

    # Set third-party library loggers to the same level as the application
    # This gives consistent behavior - user controls all logging with one setting
    # Map loguru's TRACE to Python logging's DEBUG (standard logging doesn't have TRACE)
    stdlib_log_level = "DEBUG" if log_level == "TRACE" else log_level
    for noisy_logger in ("openai", "urllib3", "asyncio"):
        logging.getLogger(noisy_logger).setLevel(stdlib_log_level)

    # Suppress overly verbose third-party loggers (always WARNING regardless of app level).
    # Applied AFTER the loggerDict loop above so it is not overwritten by that loop.
    # These libraries log at INFO even on cache hits — not useful at INFO in production.
    for verbose_logger in ("watchfiles", "huggingface_hub", "sentence_transformers", "filelock"):
        logging.getLogger(verbose_logger).setLevel(logging.WARNING)

    # SQLAlchemy follows the app log level, but never below WARNING unless the user
    # explicitly enables sql_log (which sets engine echo=True separately).
    # Note: SQLAlchemy uses "sqlalchemy.engine.Engine" (capital E) as its actual
    # logger name, not "sqlalchemy.engine.base".
    _apply_sqlalchemy_levels(log_level)


def wire_uvicorn_logging() -> None:
    """Route uvicorn loggers through loguru.

    Must be called AFTER uvicorn.Config() is instantiated. Uvicorn installs its
    own handlers during Config.__init__, overwriting any handlers set before that
    call. Calling this function afterwards replaces them with InterceptHandler so
    all uvicorn output flows through loguru and is consistently colorized.
    """
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        uv = logging.getLogger(name)
        uv.handlers = [InterceptHandler()]
        uv.propagate = False


def _apply_sqlalchemy_levels(log_level: str):
    """Set SQLAlchemy logger levels consistent with the app log level.

    Must be called from setup_logging() and setup_sqlalchemy_logging() to ensure
    levels survive handler re-wiring and late logger creation by create_engine().
    """
    stdlib_level = "DEBUG" if log_level in ("DEBUG", "TRACE") else "WARNING"
    for sa_logger in _SA_LOGGER_NAMES:
        logging.getLogger(sa_logger).setLevel(stdlib_level)


# All SQLAlchemy logger names that need management. "sqlalchemy.engine.Engine"
# (capital E) is the actual logger SQLAlchemy uses for query output.
_SA_LOGGER_NAMES = (
    "sqlalchemy",
    "sqlalchemy.engine",
    "sqlalchemy.engine.Engine",
    "sqlalchemy.dialects",
    "sqlalchemy.pool",
)


def setup_sqlalchemy_logging():
    """Configure SQLAlchemy logging to use loguru.

    Called after setup_logging() to wire InterceptHandler on SQLAlchemy loggers
    and re-apply the correct level (handler assignment resets the level).
    """
    for logger_name in _SA_LOGGER_NAMES:
        logging_logger = logging.getLogger(logger_name)
        logging_logger.handlers = [InterceptHandler()]
        logging_logger.propagate = False

    # Re-apply levels since handler assignment above does not preserve them
    from sonnet_server.settings import get_settings

    _apply_sqlalchemy_levels(get_settings().log_level)
