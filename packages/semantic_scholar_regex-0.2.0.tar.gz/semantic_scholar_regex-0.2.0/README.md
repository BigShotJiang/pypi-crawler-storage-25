# Semantic Scholar Regex MCP Server

An MCP (Model Context Protocol) server for searching and analyzing academic papers
via the [Semantic Scholar API](https://www.semanticscholar.org/product/api),
with regex-powered filtering and statistical analysis.

## Features

- **Regex-powered search**: Write regex patterns and have them automatically
  transformed into Semantic Scholar API-compatible queries
- **Post-filtering**: Apply the original regex to returned fields (title,
  abstract) for precise filtering
- **Statistical analysis**: Compute author counts, publication year
  distributions, and field availability stats
- **Multi-API support** (optional): Also fetches from OpenAlex and Crossref
  with cross-source deduplication
- **MCP-native**: Exposes tools for use with any MCP client (Claude, etc.)

## Tools

### `search_papers`
Search Semantic Scholar with regex filtering. Returns papers matching your
pattern, with optional regex post-filtering on title and abstract.

### `get_paper_stats`
Fetch papers and compute statistics: field availability, author counts, and
publication year distributions.

### `build_extended_query`
Preview how a regex query gets transformed for the Semantic Scholar API.

## Usage

### Via `uvx` (recommended)

```bash
uvx semantic-scholar-regex
```

### Via `uv run`

```bash
uv run --with semantic-scholar-regex semantic-scholar-regex
```

### From source

```bash
git clone ...
cd semantic-scholar-regex
uv run src/semantic_scholar_regex
```

### With Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "semantic-scholar-regex": {
      "command": "uvx",
      "args": ["semantic-scholar-regex"]
    }
  }
}
```

## Development

```bash
uv sync
uv run semantic-scholar-regex
```
