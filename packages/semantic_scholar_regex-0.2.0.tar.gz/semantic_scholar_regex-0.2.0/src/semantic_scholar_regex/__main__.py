"""Entry point for ``python -m semantic_scholar_regex``."""
from .server import main

main()
