"""API fetching and regex utility functions for the Semantic Scholar MCP server.

Based on patterns from literature_review_bulk.py (multi-API literature review script).
"""

from __future__ import annotations

import logging
import re
import time
from typing import Any, Optional
from urllib.parse import quote

import requests

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_FIELDS = (
    "externalIds,authors,title,year,publicationDate,abstract,"
    "publicationTypes,journal,referenceCount,citationCount,"
    "isOpenAccess,openAccessPdf"
)

# How long to wait between pagination requests (be polite to the API)
DEFAULT_API_DELAY = 0.5  # seconds

# Maximum number of retries for transient errors
MAX_RETRIES = 3

# ---------------------------------------------------------------------------
# Regex query transformation
# ---------------------------------------------------------------------------


def build_extended_query(query: str, search_type: str = "limited") -> str:
    """Transform a regex query into a Semantic Scholar API-compatible query.

    The original regex may contain complex patterns like ``\\b(?:hip\\W+(?:\\w+\\W+){0,6}?surgery)\\b``.
    This function extracts individual search terms from the regex and joins them
    with either AND (``limited``) or OR (``extended``) operators.

    Args:
        query: A regex pattern.
        search_type:
            - ``"limited"``: terms joined with AND (`` + ``).
            - ``"extended"``: terms joined with OR (`` | ``).
            - any other value: terms joined with a space.

    Returns:
        A plain-text query string suitable for the Semantic Scholar API.
    """
    if search_type == "limited":
        query_operator = " + "
    elif search_type == "extended":
        query_operator = " | "
    else:
        query_operator = " "

    extended_query = query_operator.join(
        list(
            dict.fromkeys(
                [
                    "".join(x).replace(".*", "*").replace(".+", "*").replace(".?", "*")
                    for x in re.findall(
                        r'(?:"(.*?)")|(?:\'(.*?)\')|(?:([a-zA-Z-]{3,}[.*+?]{0,2}))',
                        query,
                    )
                ]
            )
        )
    )
    return extended_query


# ---------------------------------------------------------------------------
# DOI / title normalization (from the reference literature_review_bulk.py)
# ---------------------------------------------------------------------------


def normalize_doi(doi: Optional[str]) -> Optional[str]:
    """Normalise a DOI for deduplication.

    Strips common URL prefixes and lowercases the value.

    Args:
        doi: A DOI string, possibly with a URL prefix.

    Returns:
        A clean, lowercased DOI string, or ``None`` if input is not a string.
    """
    if not isinstance(doi, str):
        return None
    return (
        doi.replace("https://doi.org/", "")
        .replace("http://dx.doi.org/", "")
        .strip()
        .lower()
    )


def normalize_title(title: Optional[str]) -> str:
    """Normalise a title for deduplication.

    Strips non-alphanumeric characters and lowercases.

    Args:
        title: A paper title.

    Returns:
        A clean, lowercased, alphanumeric-only version of the title.
    """
    if not isinstance(title, str):
        return ""
    return re.sub(r"[\W_]+", "", title.lower())


# ---------------------------------------------------------------------------
# OpenAlex abstract reconstruction (from the reference)
# ---------------------------------------------------------------------------


def reconstruct_openalex_abstract(inverted_index: Optional[dict]) -> str:
    """Reconstruct readable abstract text from an OpenAlex inverted index.

    OpenAlex stores abstracts as an inverted index to save space. This function
    reconstructs the original text.

    Args:
        inverted_index: The OpenAlex ``abstract_inverted_index`` dict, e.g.
            ``{"word": [0, 3], "another": [1, 4]}``.

    Returns:
        The reconstructed abstract string, or an empty string on failure.
    """
    if not inverted_index:
        return ""
    try:
        length = max(max(positions) for positions in inverted_index.values()) + 1
        abstract_list = [""] * length
        for word, positions in inverted_index.items():
            for pos in positions:
                abstract_list[pos] = word
        return " ".join(abstract_list)
    except (ValueError, TypeError, KeyError):
        return ""


# ---------------------------------------------------------------------------
# Semantic Scholar API fetching with error handling and rate limiting
# ---------------------------------------------------------------------------


def fetch_all_papers(
    extended_query: str,
    fields: str = DEFAULT_FIELDS,
    max_retrieval: int = 10_000_000,
    api_delay: float = DEFAULT_API_DELAY,
) -> list[dict[str, Any]]:
    """Paginate through the Semantic Scholar bulk API and return all papers.

    Incorporates retry logic and polite rate limiting (inspired by the
    ``literature_review_bulk.py`` reference script).

    Args:
        extended_query: The transformed query string (output of
            :func:`build_extended_query`).
        fields: Comma-separated Semantic Scholar field names to retrieve.
        max_retrieval: Maximum number of papers to retrieve.
        api_delay: Seconds to wait between pagination requests.

    Returns:
        A list of paper dicts as returned by the API.
    """
    url = (
        f"https://api.semanticscholar.org/graph/v1/paper/search/bulk"
        f"?query={quote(extended_query)}&fields={fields}"
    )

    papers: list[dict[str, Any]] = []
    retrieved = 0
    token: Optional[str] = None

    while retrieved < max_retrieval:
        request_url = f"{url}&token={token}" if token else url

        data = _request_with_retry(request_url)
        if data is None:
            logger.warning("Stopping due to repeated API failures.")
            break

        if "data" in data:
            papers.extend(data["data"])
            retrieved += len(data["data"])

        token = data.get("token")
        if not token:
            break

        # Polite delay between pagination requests (from the reference script)
        if api_delay > 0:
            time.sleep(api_delay)

    logger.info("Retrieved %d papers from Semantic Scholar.", retrieved)
    return papers


def _request_with_retry(url: str, max_retries: int = MAX_RETRIES) -> Optional[dict]:
    """Make a GET request with retry logic for transient errors.

    Args:
        url: The URL to request.
        max_retries: Number of times to retry on failure.

    Returns:
        The JSON response dict, or ``None`` if all retries failed.
    """
    for attempt in range(1, max_retries + 1):
        try:
            r = requests.get(url, timeout=30)
            r.raise_for_status()
            return r.json()
        except requests.exceptions.Timeout:
            logger.warning("Request timed out (attempt %d/%d).", attempt, max_retries)
        except requests.exceptions.HTTPError as e:
            status = e.response.status_code if e.response is not None else "unknown"
            logger.warning("HTTP %s error (attempt %d/%d).", status, attempt, max_retries)
            if status == 429:  # Too Many Requests
                time.sleep(5 * attempt)
            elif status in (400, 404):
                return None  # Non-retryable client errors
        except requests.exceptions.ConnectionError:
            logger.warning("Connection error (attempt %d/%d).", attempt, max_retries)
        except Exception:
            logger.exception("Unexpected error (attempt %d/%d).", attempt, max_retries)

        if attempt < max_retries:
            time.sleep(2 ** attempt)  # Exponential backoff

    return None


# ---------------------------------------------------------------------------
# Regex post-filtering
# ---------------------------------------------------------------------------


def apply_regex_filter(
    papers: list[dict[str, Any]],
    query: str,
    regex_search_fields: list[str],
    match_mode: str = "any",
) -> list[dict[str, Any]]:
    """Filter papers by applying the original regex to specified fields.

    Args:
        papers: List of paper dicts from the API.
        query: The original regex pattern.
        regex_search_fields: Field names to search against (e.g.
            ``["title", "abstract"]``).
        match_mode:
            - ``"any"``: Keep paper if *any* field matches (OR logic).
            - ``"all"``: Keep paper if *all* fields match (AND logic).

    Returns:
        Filtered list of paper dicts, each with an added
        ``_regex_matches`` key showing per-field match results.
    """
    filtered: list[dict[str, Any]] = []
    for paper in papers:
        field_matches: dict[str, bool] = {}
        for field in regex_search_fields:
            value = paper.get(field)
            if value and isinstance(value, str):
                field_matches[field] = bool(re.search(query, value, re.IGNORECASE))
            else:
                field_matches[field] = False

        if match_mode == "all":
            keep = all(field_matches.values())
        else:
            keep = any(field_matches.values())

        if keep:
            paper_copy = dict(paper)
            paper_copy["_regex_matches"] = field_matches
            filtered.append(paper_copy)

    return filtered
