"""MCP Server for Semantic Scholar Bulk Regex Search with multi-API support."""

__version__ = "0.2.0"

from .server import main

__all__ = ["main"]
