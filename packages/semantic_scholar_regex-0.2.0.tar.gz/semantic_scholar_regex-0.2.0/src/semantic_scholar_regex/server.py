"""MCP Server for Semantic Scholar Bulk Regex Search.

Exposes three tools to MCP clients:
  - ``search_papers``: Search Semantic Scholar with regex filtering
  - ``get_paper_stats``: Compute statistics on a list of papers
  - ``build_extended_query``: Preview how a regex query gets transformed
"""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import FastMCP

from . import api, stats

logger = logging.getLogger(__name__)

mcp = FastMCP("semantic-scholar-regex")


# ---------------------------------------------------------------------------
# MCP Tools
# ---------------------------------------------------------------------------


@mcp.tool()
def build_extended_query(
    query: str,
    search_type: str = "limited",
) -> dict[str, str]:
    """Preview how a regex query is transformed for the Semantic Scholar API.

    Args:
        query: A regex pattern (e.g. ``\\b(?:hip\\W+(?:\\w+\\W+){0,6}?surgery)\\b``).
        search_type:
            - ``"limited"``: terms joined with AND (`` + ``).
            - ``"extended"``: terms joined with OR (`` | ``).

    Returns:
        A dict with the original query, the transformed query, and the
        search type.
    """
    extended_query = api.build_extended_query(query, search_type)
    return {
        "original_query": query,
        "extended_query": extended_query,
        "search_type": search_type,
    }


@mcp.tool()
def search_papers(
    query: str,
    search_type: str = "limited",
    fields: str = api.DEFAULT_FIELDS,
    max_retrieval: int = 10_000,
    regex_search_fields: str = "title,abstract",
    match_mode: str = "any",
    apply_regex_filter: bool = True,
    limit: int = 50,
) -> dict[str, Any]:
    """Search Semantic Scholar with regex filtering.

    Fetches papers via the bulk API, then optionally re-filters results
    by applying the original regex to the specified fields.

    Args:
        query: Regex pattern to search for.
        search_type:
            - ``"limited"`` (AND) or ``"extended"`` (OR) for the API query.
        fields: Comma-separated Semantic Scholar field names to retrieve.
        max_retrieval: Max papers to fetch from the API.
        regex_search_fields: Comma-separated field names to apply regex on.
        match_mode:
            - ``"any"``: paper kept if *any* regex field matches (OR).
            - ``"all"``: paper kept only if *all* regex fields match (AND).
        apply_regex_filter: Whether to apply regex post-filtering.
        limit: Max number of papers to return in the response.

    Returns:
        A dict with metadata (query, counts) and the ``papers`` list.
    """
    extended_query = api.build_extended_query(query, search_type)
    papers = api.fetch_all_papers(extended_query, fields, max_retrieval)

    total_from_api = len(papers)

    if apply_regex_filter:
        rsf = [f.strip() for f in regex_search_fields.split(",")]
        papers = api.apply_regex_filter(papers, query, rsf, match_mode)

    returned = papers[:limit]

    return {
        "original_query": query,
        "extended_query": extended_query,
        "total_from_api": total_from_api,
        "total_after_regex_filter": len(papers),
        "returned_count": len(returned),
        "limit": limit,
        "papers": returned,
    }


@mcp.tool()
def get_paper_stats(
    query: str,
    search_type: str = "limited",
    fields: str = api.DEFAULT_FIELDS,
    max_retrieval: int = 10_000,
) -> dict[str, Any]:
    """Fetch papers from Semantic Scholar and compute statistics.

    Returns data availability, author count stats, and publication year stats.

    Args:
        query: Regex pattern to search for.
        search_type:
            - ``"limited"`` (AND) or ``"extended"`` (OR).
        fields: Comma-separated Semantic Scholar field names to retrieve.
        max_retrieval: Max papers to fetch from the API.

    Returns:
        A dict with ``total_papers``, ``field_availability``, ``authors``,
        and ``publication_year``.
    """
    extended_query = api.build_extended_query(query, search_type)
    papers = api.fetch_all_papers(extended_query, fields, max_retrieval)
    result = stats.compute_stats(papers)
    result["original_query"] = query
    result["extended_query"] = extended_query
    return result


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the MCP server.

    This is the console_scripts entry point defined in pyproject.toml.
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    mcp.run()


if __name__ == "__main__":
    main()
