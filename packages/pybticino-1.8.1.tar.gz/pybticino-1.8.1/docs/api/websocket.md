# WebsocketClient

::: pybticino.websocket.WebsocketClient
