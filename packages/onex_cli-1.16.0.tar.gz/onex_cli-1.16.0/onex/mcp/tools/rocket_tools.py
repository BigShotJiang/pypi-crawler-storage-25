"""
onex-rocket MCP tools for the onex CLI.

Add this to the onex MCP server to expose code graph tools to Claude Code.
All tools call the onex-rocket API server — no local binary needed.

URL resolution order:
    1. api_url parameter (passed from server.py)
    2. ROCKET_API_URL env var
    3. rocket_url from ~/.onex/environments.json (active environment)
    4. Fallback: http://localhost:7432

Usage in onex/mcp/server.py:
    from onex.mcp.tools.rocket_tools import register_rocket_tools
    register_rocket_tools(mcp)
"""

import json
import os
import urllib.parse
from pathlib import Path
from typing import Optional

import httpx


def _resolve_rocket_url(explicit_url: Optional[str] = None) -> str:
    """Resolve the onex-rocket API URL from multiple sources."""
    # 1. Explicit parameter
    if explicit_url:
        return explicit_url

    # 2. Environment variable
    env_url = os.environ.get("ROCKET_API_URL")
    if env_url:
        return env_url

    # 3. Read from ~/.onex/environments.json (same config as onex CLI)
    try:
        onex_dir = Path.home() / '.onex'
        active_env = 'local'
        active_file = onex_dir / 'active-env'
        if active_file.exists():
            active_env = active_file.read_text().strip()

        env_file = onex_dir / 'environments.json'
        if env_file.exists():
            with env_file.open() as f:
                data = json.load(f)
            env_data = data.get(active_env, {})
            if env_data.get('rocket_url'):
                return env_data['rocket_url']
    except Exception:
        pass

    # 4. Fallback: try test runner server (VPN), then localhost
    defaults = {
        'local': 'http://10.0.0.3:7432',
        'dev': 'http://10.0.0.3:7432',
        'staging': 'http://10.0.0.3:7432',
    }
    return defaults.get(active_env, 'http://10.0.0.3:7432')


def _detect_git_repo() -> Optional[dict]:
    """Detect the current git repo's remote URL, name, and branch.

    Returns {"url": "https://...", "name": "repo-name", "branch": "main"} or None.

    The graph_name includes the branch for non-main branches:
      main     -> "onex-platform"         (default, shared by all devs)
      dev      -> "onex-platform"         (same as main for common branches)
      feature  -> "onex-platform@feature" (branch-specific graph)
    """
    import subprocess

    def _run_git(*args):
        r = subprocess.run(
            ['git'] + list(args),
            capture_output=True, text=True, timeout=5
        )
        return r.stdout.strip() if r.returncode == 0 else None

    try:
        # Get remote URL
        remote_url = _run_git('remote', 'get-url', 'origin')
        if not remote_url:
            return None

        # Normalize to HTTPS URL for the API
        # git@github.com:Org/repo.git -> https://github.com/Org/repo.git
        if remote_url.startswith('git@'):
            remote_url = remote_url.replace(':', '/').replace('git@', 'https://')

        # Extract repo name from URL (last path segment without .git)
        base_name = remote_url.rstrip('/').rsplit('/', 1)[-1]
        if base_name.endswith('.git'):
            base_name = base_name[:-4]

        # Detect current branch
        branch = _run_git('rev-parse', '--abbrev-ref', 'HEAD') or 'main'

        # Map branch to graph name and index branch:
        #   main / master / hotfix/* -> repo-name        (main graph)
        #   dev / develop / feature/* -> repo-name@dev    (dev graph)
        #   preview                   -> repo-name@preview (preview graph)
        if branch in ('main', 'master') or branch.startswith('hotfix/'):
            graph_name = base_name
            index_branch = 'main'
        elif branch in ('dev', 'develop') or branch.startswith('feature/'):
            graph_name = f"{base_name}@dev"
            index_branch = 'dev'
        elif branch == 'preview':
            graph_name = f"{base_name}@preview"
            index_branch = 'preview'
        else:
            # Unknown branch pattern — fall back to main graph
            graph_name = base_name
            index_branch = 'main'

        return {
            "url": remote_url,
            "name": base_name,
            "graph_name": graph_name,
            "branch": index_branch,
        }
    except Exception:
        return None


def register_rocket_tools(mcp, api_url: Optional[str] = None):
    """Register all onex-rocket tools on an existing FastMCP server."""

    base_url = _resolve_rocket_url(api_url)
    client = httpx.Client(base_url=base_url, timeout=30.0)
    _indexed_repos: set = set()  # track repos already indexed this session

    def _get(path: str, params: dict = None) -> str:
        """Make GET request to rocket API, return JSON string."""
        try:
            resp = client.get(f"/api/v1/{path}", params=params or {})
            resp.raise_for_status()
            return resp.text
        except httpx.HTTPError as e:
            return f'{{"error": "{str(e)}"}}'

    def _post(path: str, data: dict) -> str:
        """Make POST request to rocket API, return JSON string."""
        try:
            resp = client.post(f"/api/v1/{path}", json=data)
            resp.raise_for_status()
            return resp.text
        except httpx.HTTPError as e:
            return f'{{"error": "{str(e)}"}}'

    def _ensure_repo_indexed():
        """Auto-index the current git repo if not already in the graph.

        Uses branch-aware naming:
          main/dev/preview  -> "repo-name"       (shared graph, auto-reindexed)
          feature/hotfix    -> "repo-name@branch" (on-demand, indexed once)

        Only checks once per graph_name per session.
        """
        repo_info = _detect_git_repo()
        if not repo_info:
            return

        graph_name = repo_info["graph_name"]
        if graph_name in _indexed_repos:
            return

        # Check if already in graph
        try:
            resp = client.get("/api/v1/stats", timeout=5)
            if resp.status_code == 200:
                stats = resp.json()
                by_repo = stats.get("by_repo", {})
                if graph_name in by_repo:
                    _indexed_repos.add(graph_name)
                    return
        except Exception:
            return

        # Not in graph — trigger index
        try:
            client.post("/api/v1/index", json={
                "url": repo_info["url"],
                "name": graph_name,
                "branch": repo_info["branch"],
            }, timeout=120)
            _indexed_repos.add(graph_name)
        except Exception:
            pass  # best-effort, don't block the tool call

    def _get_current_graph_name() -> Optional[str]:
        """Get the graph name for the current repo+branch.

        Returns the graph_name that tools should query against,
        or None if not in a git repo.
        """
        repo_info = _detect_git_repo()
        if not repo_info:
            return None
        return repo_info["graph_name"]

    # ================================================================
    # IMPORTANT: Graph context for AI agents
    # The code graph indexes the MAIN branch only. Results do not reflect
    # the developer's current working branch. Use graph results for
    # architectural understanding and main-branch analysis, not for
    # validating uncommitted or feature-branch changes.
    # ================================================================

    # ================================================================
    # BEST FOR: Tracing call chains and understanding data flow
    # ================================================================

    @mcp.tool()
    def rocket_trace_path(from_symbol: str, to_symbol: str, max_hops: int = 10) -> str:
        """Find the call/dependency chain between two symbols.
        BEST FOR: "how does data flow from A to B?", "what's the path from HTTP handler to database?".
        50% faster and more accurate than manually reading files."""
        return _get("trace", {"from": from_symbol, "to": to_symbol, "max_hops": max_hops})

    @mcp.tool()
    def rocket_get_dependents(global_id: str, max_hops: int = 5) -> str:
        """Find ALL symbols that transitively depend on a given symbol.
        BEST FOR: "what breaks if I change this?", "what's the blast radius?".
        Catches indirect callers that grep misses."""
        return _get(f"symbols/{urllib.parse.quote(global_id, safe='')}/dependents", {"max_hops": max_hops})

    @mcp.tool()
    def rocket_get_dependencies(global_id: str, max_hops: int = 5) -> str:
        """Find all symbols that a given symbol depends on (transitively).
        BEST FOR: "what does this function need to work?"."""
        return _get(f"symbols/{urllib.parse.quote(global_id, safe='')}/dependencies", {"max_hops": max_hops})

    # ================================================================
    # BEST FOR: Whole-codebase analysis
    # ================================================================

    @mcp.tool()
    def rocket_find_dead_code(repo: str = "") -> str:
        """Find functions/methods never called anywhere in the codebase.
        BEST FOR: "what code can I safely delete?". Grep can't do this — only a graph can determine zero callers.
        If repo is omitted, auto-detects from current git repo and branch."""
        _ensure_repo_indexed()
        repo = repo or _get_current_graph_name() or "unknown"
        return _get(f"repo/{repo}/dead-code")

    @mcp.tool()
    def rocket_find_hotspots(repo: str = "", limit: int = 20) -> str:
        """Find the most depended-on symbols, ranked by caller count.
        BEST FOR: "what are the riskiest parts?", "what should we test most?".
        If repo is omitted, auto-detects from current git repo and branch."""
        _ensure_repo_indexed()
        repo = repo or _get_current_graph_name() or "unknown"
        return _get(f"repo/{repo}/hotspots", {"limit": limit})

    @mcp.tool()
    def rocket_find_cycles(repo: str = "") -> str:
        """Find circular dependencies in the codebase.
        BEST FOR: "are there any import cycles?", architectural analysis.
        If repo is omitted, auto-detects from current git repo and branch."""
        _ensure_repo_indexed()
        repo = repo or _get_current_graph_name() or "unknown"
        return _get(f"repo/{repo}/cycles")

    @mcp.tool()
    def rocket_get_repo_map(repo: str = "") -> str:
        """Get a bird's-eye view of the entire repo: all files with their key symbols.
        BEST FOR: understanding project structure, onboarding. Much faster than reading files one by one.
        If repo is omitted, auto-detects from current git repo and branch."""
        _ensure_repo_indexed()
        repo = repo or _get_current_graph_name() or "unknown"
        return _get(f"repo/{repo}/map")

    @mcp.tool()
    def rocket_rename_impact(name: str, kind: str = "", repo: str = "") -> str:
        """Analyze the full impact of renaming a symbol: affected files, broken signatures, test files.
        BEST FOR: refactoring planning, cross-codebase renames."""
        params = {"name": name}
        if kind:
            params["kind"] = kind
        if repo:
            params["repo"] = repo
        return _get("rename-impact", params)

    @mcp.tool()
    def rocket_get_impact(global_id: str, max_hops: int = 5) -> str:
        """Analyze what would break if a symbol changes. Returns transitive dependents by repo."""
        return _get(f"symbols/{urllib.parse.quote(global_id, safe='')}/impact", {"max_hops": max_hops})

    # ================================================================
    # BEST FOR: Understanding how code is used
    # ================================================================

    @mcp.tool()
    def rocket_get_usage_examples(global_id: str, limit: int = 10) -> str:
        """Find real code examples showing how a symbol is used, with actual source snippets.
        BEST FOR: "how do I call this function?", "show me examples of using this API"."""
        return _get(f"symbols/{urllib.parse.quote(global_id, safe='')}/usage", {"limit": limit})

    @mcp.tool()
    def rocket_get_symbol_context(global_id: str, context_lines: int = 5) -> str:
        """Get a symbol's definition with source code, plus its callers and callees.
        BEST FOR: deep-diving into a specific function/method."""
        return _get(f"symbols/{urllib.parse.quote(global_id, safe='')}/context", {"context_lines": context_lines})

    @mcp.tool()
    def rocket_get_test_coverage(name: str, repo: str = "") -> str:
        """Find which test functions cover a given symbol.
        BEST FOR: "is this function tested?", "which tests should I run?"."""
        params = {"name": name}
        if repo:
            params["repo"] = repo
        return _get("test-coverage", params)

    # ================================================================
    # Symbol lookup and search
    # ================================================================

    @mcp.tool()
    def rocket_find_symbol(name: str, kind: str = "", repo: str = "", language: str = "") -> str:
        """Find a symbol by name. Returns matching functions/classes/types with file paths.
        For simple lookups, grep may be equally fast. Better for structured results and follow-up queries."""
        params = {"name": name}
        if kind:
            params["kind"] = kind
        if repo:
            params["repo"] = repo
        if language:
            params["language"] = language
        return _get("symbols", params)

    @mcp.tool()
    def rocket_get_references(global_id: str) -> str:
        """Find direct callers/references to a symbol."""
        return _get(f"symbols/{urllib.parse.quote(global_id, safe='')}/references")

    # ================================================================
    # Git history and stats
    # ================================================================

    @mcp.tool()
    def rocket_get_file_churn(repo: str = "", limit: int = 20) -> str:
        """Get files ranked by change frequency. BEST FOR: identifying unstable/buggy code.
        If repo is omitted, auto-detects from current git repo and branch."""
        _ensure_repo_indexed()
        repo = repo or _get_current_graph_name() or "unknown"
        return _get(f"repo/{repo}/churn", {"limit": limit})

    @mcp.tool()
    def rocket_stats() -> str:
        """Get graph statistics: total nodes/edges, breakdown by kind and repo.
        NOTE: The graph indexes the MAIN branch only. Results do not reflect feature branches or uncommitted changes.
        Auto-indexes the current repo if not already in the graph."""
        _ensure_repo_indexed()
        return _get("stats")

    @mcp.tool()
    def rocket_health() -> str:
        """Check if the onex-rocket server is running and healthy."""
        return _get("health")

    # ================================================================
    # Index management
    # ================================================================

    @mcp.tool()
    def rocket_index(path: str = "", url: str = "", name: str = "", branch: str = "main") -> str:
        """Index a repository into the code graph. Use path for local repos, url for git repos."""
        data = {"branch": branch}
        if path:
            data["path"] = path
        if url:
            data["url"] = url
        if name:
            data["name"] = name
        return _post("index", data)
