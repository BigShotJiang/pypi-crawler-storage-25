# Changelog

## 0.7.0 (2026-05-15)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/Vitable-Inc/vitable-connect-python/compare/v0.6.0...v0.7.0)

### Features

* **api:** api update ([be238bd](https://github.com/Vitable-Inc/vitable-connect-python/commit/be238bdfa91087968a214e85c1b1f2e3ae3956ba))
* **api:** api update ([d2cf53f](https://github.com/Vitable-Inc/vitable-connect-python/commit/d2cf53f72ca61c63bea8aa21512153d65dac5267))
* **api:** manual updates ([d3b3b22](https://github.com/Vitable-Inc/vitable-connect-python/commit/d3b3b226b1f3604bb0bd209e1fd8d5ce6e568346))
* **internal/types:** support eagerly validating pydantic iterators ([a5abdda](https://github.com/Vitable-Inc/vitable-connect-python/commit/a5abddaf5c4d164c0207fd9df357a2f663fd50e3))
* support setting headers via env ([3ca51fa](https://github.com/Vitable-Inc/vitable-connect-python/commit/3ca51fa4ae7ec750ee3a82fa9f8551de2d73c705))


### Bug Fixes

* **client:** add missing f-string prefix in file type error message ([004c0b9](https://github.com/Vitable-Inc/vitable-connect-python/commit/004c0b9a537063e354d79079b9927559be504392))
* use correct field name format for multipart file arrays ([6e86a19](https://github.com/Vitable-Inc/vitable-connect-python/commit/6e86a1953203a86f6cf66ede8e4e296de047eb8e))


### Chores

* **internal:** more robust bootstrap script ([0a150fe](https://github.com/Vitable-Inc/vitable-connect-python/commit/0a150fea1af9f9c0e41ef27d8b3dd87b16e20900))
* **internal:** reformat pyproject.toml ([3547294](https://github.com/Vitable-Inc/vitable-connect-python/commit/3547294e7a4bb987f8b7ef66aebd612bdbfb22f5))

## 0.6.0 (2026-04-18)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/Vitable-Inc/vitable-connect-python/compare/v0.5.0...v0.6.0)

### Features

* **api:** api update ([ce09b27](https://github.com/Vitable-Inc/vitable-connect-python/commit/ce09b27923e4d550edf0090b17de2471a2b9487e))


### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([a146ca8](https://github.com/Vitable-Inc/vitable-connect-python/commit/a146ca8b4396978eb085d9e35669b8de9b88eea6))
* ensure file data are only sent as 1 parameter ([4f40996](https://github.com/Vitable-Inc/vitable-connect-python/commit/4f409963112717020cd8f0cd8a9cfd3938e56fc8))


### Performance Improvements

* **client:** optimize file structure copying in multipart requests ([ef0dd2c](https://github.com/Vitable-Inc/vitable-connect-python/commit/ef0dd2c111eb6c05a486150ea8b6243768b0d7d9))

## 0.5.0 (2026-03-27)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/Vitable-Inc/vitable-connect-python/compare/v0.4.0...v0.5.0)

### Features

* **internal:** implement indices array format for query and form serialization ([20179b1](https://github.com/Vitable-Inc/vitable-connect-python/commit/20179b1aa30918ed29ef03f6e577546a893f9a7a))

## 0.4.0 (2026-03-25)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/Vitable-Inc/vitable-connect-python/compare/v0.3.0...v0.4.0)

### Features

* **api:** api update ([cbeb23a](https://github.com/Vitable-Inc/vitable-connect-python/commit/cbeb23af9f69f3d6601a572ca1ad477e3a0a7604))


### Chores

* **ci:** skip lint on metadata-only changes ([ae2ea7a](https://github.com/Vitable-Inc/vitable-connect-python/commit/ae2ea7a1799256a5647a1361e5290f1ac0a3053f))

## 0.3.0 (2026-03-24)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/Vitable-Inc/vitable-connect-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([79cb703](https://github.com/Vitable-Inc/vitable-connect-python/commit/79cb7035cf622d851378bd2ddef1522aa47a0982))


### Chores

* **internal:** update gitignore ([46e8e0a](https://github.com/Vitable-Inc/vitable-connect-python/commit/46e8e0a89c1202cbd204fac742eee4418bf29957))

## 0.2.0 (2026-03-20)

Full Changelog: [v0.1.2...v0.2.0](https://github.com/Vitable-Inc/vitable-connect-python/compare/v0.1.2...v0.2.0)

### Features

* **api:** api update ([2d17eba](https://github.com/Vitable-Inc/vitable-connect-python/commit/2d17ebab7f730aa1a9a9cba0044d7bd1f05ef3d7))
* **api:** manual updates ([61e9959](https://github.com/Vitable-Inc/vitable-connect-python/commit/61e9959f83e9d2de1c974e9d04349efba0c03589))
* **api:** manual updates ([311d294](https://github.com/Vitable-Inc/vitable-connect-python/commit/311d294e50fb62fde627e0e0619064ff05018cb7))
* **api:** manual updates ([81fa03e](https://github.com/Vitable-Inc/vitable-connect-python/commit/81fa03e7036aeb56052384dfbd31de5f554d2d74))


### Bug Fixes

* **deps:** bump minimum typing-extensions version ([4f315a4](https://github.com/Vitable-Inc/vitable-connect-python/commit/4f315a4488437d128364f288ae1a2e526aceb639))
* **pydantic:** do not pass `by_alias` unless set ([7d698a1](https://github.com/Vitable-Inc/vitable-connect-python/commit/7d698a13ec079a12c7681ce236abf4aa9ea765fa))
* sanitize endpoint path params ([5d252df](https://github.com/Vitable-Inc/vitable-connect-python/commit/5d252df080bd65d8227cff938a47fc2c0be43c64))


### Chores

* **internal:** tweak CI branches ([96b210d](https://github.com/Vitable-Inc/vitable-connect-python/commit/96b210d9f4ace8c61d48775f1cf840e8fcb18d44))
* update SDK settings ([b5d7c3a](https://github.com/Vitable-Inc/vitable-connect-python/commit/b5d7c3a4a61e8b7beb84a7c2c184d1c4237b324a))
* update SDK settings ([5749036](https://github.com/Vitable-Inc/vitable-connect-python/commit/57490368bcb31217dc0c9ca08d7757f1c3f03400))
* update SDK settings ([f29a924](https://github.com/Vitable-Inc/vitable-connect-python/commit/f29a9244a92c5205cd978c2adc176b9428c0be4f))

## 0.1.2 (2026-03-15)

Full Changelog: [v0.1.1...v0.1.2](https://github.com/Vitable-Inc/vitable-connect-python/compare/v0.1.1...v0.1.2)

### Chores

* update SDK settings ([edacf2c](https://github.com/Vitable-Inc/vitable-connect-python/commit/edacf2c85b5c78a54c3691223d181da0c4b2d27e))
* update SDK settings ([5462ee2](https://github.com/Vitable-Inc/vitable-connect-python/commit/5462ee2a354f9d756ba2e03cdca95ab44850e352))

## 0.1.1 (2026-03-15)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/Vitable-Inc/vitable-connect-python/compare/v0.1.0...v0.1.1)

### Chores

* update SDK settings ([cd3b35f](https://github.com/Vitable-Inc/vitable-connect-python/commit/cd3b35f6f860a3e41f868098eaed4cfe39f9812d))
* update SDK settings ([375f1e8](https://github.com/Vitable-Inc/vitable-connect-python/commit/375f1e81bf537e90bd4d54d41e433dbf8560a2e4))

## 0.1.0 (2026-03-15)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/Vitable-Inc/vitable-connect-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([667eed2](https://github.com/Vitable-Inc/vitable-connect-python/commit/667eed26c19537612e1d945523aa9b782fa0d83d))
* **api:** manual updates ([ee1b326](https://github.com/Vitable-Inc/vitable-connect-python/commit/ee1b326e854727d73d0bec48c97d4dc680d06cfb))
* **api:** manual updates ([c6773ab](https://github.com/Vitable-Inc/vitable-connect-python/commit/c6773abcca47609d1b5a7a9ccbeaffb64bf78194))
* **api:** manual updates ([24510e4](https://github.com/Vitable-Inc/vitable-connect-python/commit/24510e4c0305594da91455e032d359e8ff41e7a6))
* **api:** manual updates for 0.0.1 ([b6507fe](https://github.com/Vitable-Inc/vitable-connect-python/commit/b6507fee183f47cef7327a71f8b4949686cf0053))


### Bug Fixes

* ensure streams are always closed ([7fcce2a](https://github.com/Vitable-Inc/vitable-connect-python/commit/7fcce2af30d77a8fe4cfc387ac553e3a14aa1cb2))
* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([01c6584](https://github.com/Vitable-Inc/vitable-connect-python/commit/01c6584018f20aef86cf2a2a0ee2ac811898a574))
* use async_to_httpx_files in patch method ([4aa431e](https://github.com/Vitable-Inc/vitable-connect-python/commit/4aa431ec74d320c83e718980a9a74322223696b9))


### Chores

* add missing docstrings ([7486482](https://github.com/Vitable-Inc/vitable-connect-python/commit/7486482e46d7b866a10328c7537769f44249c37b))
* **ci:** bump uv version ([74f7244](https://github.com/Vitable-Inc/vitable-connect-python/commit/74f724414d1805a0dfc1eab672b7e9fb21c48b66))
* **ci:** skip uploading artifacts on stainless-internal branches ([24d02a6](https://github.com/Vitable-Inc/vitable-connect-python/commit/24d02a6f8bdcb6f2de398c51c673c078a5ccc87a))
* configure new SDK language ([ccd61da](https://github.com/Vitable-Inc/vitable-connect-python/commit/ccd61dad2038a70f73ec60220e89675532ed5e84))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([39137b7](https://github.com/Vitable-Inc/vitable-connect-python/commit/39137b70fb97c358e6c44769544088f70e7ccd6a))
* **docs:** use environment variables for authentication in code snippets ([a3caad5](https://github.com/Vitable-Inc/vitable-connect-python/commit/a3caad5c7ef028623891bf3f6a6850db2c6aba97))
* format all `api.md` files ([55cca23](https://github.com/Vitable-Inc/vitable-connect-python/commit/55cca23dd91a01c58dda3b1a3f37f8c438819d00))
* **internal:** add `--fix` argument to lint script ([040488a](https://github.com/Vitable-Inc/vitable-connect-python/commit/040488a8f0fbbacb81dbed57d823b6f421deb8de))
* **internal:** add missing files argument to base client ([94f5cc6](https://github.com/Vitable-Inc/vitable-connect-python/commit/94f5cc6a2609b47ccd42ecb9a4226494719dfe54))
* **internal:** add request options to SSE classes ([e77e21d](https://github.com/Vitable-Inc/vitable-connect-python/commit/e77e21d0d5ec96ab7f8503cbc157b386157d8f54))
* **internal:** bump dependencies ([79fc12e](https://github.com/Vitable-Inc/vitable-connect-python/commit/79fc12e83874b482cf239ee27f08c82d981ee950))
* **internal:** codegen related update ([f23f0ff](https://github.com/Vitable-Inc/vitable-connect-python/commit/f23f0ff38f78f92553e8e7035bf69c6507abe9a1))
* **internal:** codegen related update ([d2aa4f5](https://github.com/Vitable-Inc/vitable-connect-python/commit/d2aa4f53016ac31f848e46e9eadcd313ea5e38be))
* **internal:** fix lint error on Python 3.14 ([d4044ca](https://github.com/Vitable-Inc/vitable-connect-python/commit/d4044caa72fceda0c4fe1523461ae2164bbc98fb))
* **internal:** make `test_proxy_environment_variables` more resilient ([92eae8a](https://github.com/Vitable-Inc/vitable-connect-python/commit/92eae8a46d8d2214190500bb982459399f3c5e7f))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([e2cbec5](https://github.com/Vitable-Inc/vitable-connect-python/commit/e2cbec575768adbf8f3ec70ad14f89d5600389b5))
* **internal:** refactor authentication internals ([5050fe1](https://github.com/Vitable-Inc/vitable-connect-python/commit/5050fe1d1bc945a5f73f7e89390730179c9ed806))
* **internal:** remove mock server code ([a611093](https://github.com/Vitable-Inc/vitable-connect-python/commit/a611093dbe8d79e6d87e5535b503391fb72240e2))
* speedup initial import ([5c171ba](https://github.com/Vitable-Inc/vitable-connect-python/commit/5c171ba86cde9e105740eef77b56a2d4775dfa4e))
* update lockfile ([46fd22c](https://github.com/Vitable-Inc/vitable-connect-python/commit/46fd22c853059f80119d94490b13bd2b97289af1))
* update mock server docs ([2c8915c](https://github.com/Vitable-Inc/vitable-connect-python/commit/2c8915c6ad19db22f33e7cd52ea729615e009e58))
* update SDK settings ([4bde5c3](https://github.com/Vitable-Inc/vitable-connect-python/commit/4bde5c377461c595665bdbd3e13cf8a3c837d0b2))
* update SDK settings ([299f91c](https://github.com/Vitable-Inc/vitable-connect-python/commit/299f91c1cba012878dd76f104358521f0ca6a29f))
* update SDK settings ([e4ab81a](https://github.com/Vitable-Inc/vitable-connect-python/commit/e4ab81a88c4304bd917e8a2884f25162629b9278))
* update SDK settings ([25bf803](https://github.com/Vitable-Inc/vitable-connect-python/commit/25bf803a5aea7fc821e4bf517ba18416dfab6039))
* update SDK settings ([fca5cc6](https://github.com/Vitable-Inc/vitable-connect-python/commit/fca5cc63014e2d7c1eb74f93c951e29a1875855c))
* update SDK settings ([c331e7e](https://github.com/Vitable-Inc/vitable-connect-python/commit/c331e7e60ebd406a89efbcb955600071a79d7580))
* update SDK settings ([7ff81a7](https://github.com/Vitable-Inc/vitable-connect-python/commit/7ff81a719f5846cadf2fdea414bdaf232d22d8bf))
* update SDK settings ([0203a28](https://github.com/Vitable-Inc/vitable-connect-python/commit/0203a283b17e4ddaceb1c630a89e832e0d057856))
* update SDK settings ([ecb955c](https://github.com/Vitable-Inc/vitable-connect-python/commit/ecb955c5da5fe3f860b9a9471ee2bd279e5a2ce2))
* update SDK settings ([667632c](https://github.com/Vitable-Inc/vitable-connect-python/commit/667632ccdf1a6d62ecc13a21b7abb26fb2944b88))
