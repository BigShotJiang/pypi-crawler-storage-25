# Changelog

All notable changes to `text-case` are documented here.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.5.0] — 2026-05-03

### Added
- **Unicode beyond Latin-1**: tokenizer now correctly handles Cyrillic, Greek, CJK, Arabic, Hebrew and any other Unicode script. CamelCase boundaries detected across scripts (e.g., `helloМир` → `hello_мир`). Strict mode accepts any Unicode letter (Issue #13).

### Changed
- Replaced stdlib `re` with the `regex` package to enable `\p{L}` / `\p{Lu}` / `\p{Ll}` / `\p{Nd}` Unicode property escapes.
- Added `regex>=2024.5.10` runtime dependency.

## [0.4.0] — 2026-05-03

### Added
- `--strict` flag on every `to-*` CLI subcommand and `strict=False` keyword on `convert()` — rejects input containing any character outside the identifier-safe set (letters, digits, whitespace, `_`, `-`, `.`) (Issue #16).

## [0.3.0] — 2026-05-03

### Added
- New `to-dot` CLI subcommand and `dot` case target — converts to `dot.notation.case` (Issue #15).
- `_DELIM_RE` now also accepts `.` as a delimiter so dot inputs round-trip correctly.

## [0.2.0] — 2026-05-03

### Added
- `--version` top-level CLI flag — prints `textcase <version>` and exits 0 (Issue #14).

## [0.1.0] — 2026-05-02

### Added
- Initial release of `text-case` Python CLI (Issue #1).
- `text_case.converter.convert(text, *, to)`: pure case conversion supporting `snake`, `camel`, `pascal`, `kebab`, `screaming`, `title` targets.
- Cross-format input detection: handles camelCase, PascalCase, snake_case, kebab-case, SCREAMING_SNAKE_CASE, plain space-separated, and any mix of those.
- Unicode preservation (Latin-1 range) through case conversions.
- Idempotency: input already in the target format is a no-op.
- Typer-based CLI with six subcommands: `to-snake`, `to-camel`, `to-pascal`, `to-kebab`, `to-screaming`, `to-title`.
- Stdin support — pipe input when no CLI argument is provided.
- 100% test coverage on `text_case.converter` and `text_case.cli` (55 tests across `test_converter.py` and `test_cli.py`).
- ADR-0001 documenting tech-stack picks (Typer, pytest, ruff, mypy, black, hatchling).
- GitHub Actions CI workflow (`text-case-ci.yml`): ruff + black + mypy + pytest + pip-audit on every push touching `projects/text-case/`.

[0.1.0]: https://github.com/brunoraniere2003/project-factory/releases/tag/v0.1.0
[Unreleased]: https://github.com/brunoraniere2003/project-factory/compare/v0.1.0...HEAD
