# ADR-0001: Typer + pytest + ruff/mypy/black for `text-case`

**Status**: Accepted — 2026-05-02

## Context

`text-case` is a small CLI that converts text between identifier cases. Although tiny in scope, it must be **senior-grade**: type-hinted, 100% covered, properly packaged, lint-clean. The choice of CLI framework, test runner, and code-quality tools sets the bar for every future Project Factory project.

## Decision

| Concern         | Pick           | Rationale                                                                |
|-----------------|----------------|--------------------------------------------------------------------------|
| CLI framework   | **Typer**      | Decorator-based, autogenerates `--help`, ergonomics far ahead of argparse for small CLIs. |
| Test runner     | **pytest**     | Industry default; parametrize ergonomics; ecosystem.                     |
| Coverage        | **pytest-cov** | Standard plugin; `--cov-fail-under=100` enforces in CI.                  |
| Linter          | **ruff**       | 100× faster than flake8/pylint, replaces them entirely.                  |
| Formatter       | **black**      | Opinionated, no debate.                                                  |
| Type checker    | **mypy** strict | Senior-grade type hygiene.                                              |
| Build backend   | **hatchling**  | Modern PEP 517, simple config.                                           |
| Pre-commit      | **pre-commit** | Catches violations before the commit lands.                              |

## Considered alternatives

- **argparse** (stdlib): rejected — verbose, no ergonomic decorators, less LLM-friendly.
- **Click**: solid but more boilerplate than Typer for the same surface.
- **fire**: too magic; reflection-based introspection is brittle for type-checked code.
- **Pydantic** for input validation: overkill — pure string-to-string conversion has no nested data structures to validate. Plain `Literal` types + a frozenset check are enough.

## Consequences

- One runtime dependency (`typer>=0.12.0`). Typer pulls in Click as a transitive — acceptable, both well-trusted, MIT.
- Strict mypy means every public function has explicit type annotations. Minor friction for future development; pays dividends in IDE feedback and refactor safety.
- Coverage at 100% is non-negotiable; CI fails below that. Forces a test for every branch.
- `match` was originally used for the case dispatch; coverage tooling reported an implicit unreachable branch on it, so the implementation was refactored to a flat `if`-chain. Documented in commit `bbdb304`.
