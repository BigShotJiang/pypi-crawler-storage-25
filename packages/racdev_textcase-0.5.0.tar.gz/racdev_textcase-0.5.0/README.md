# text-case

Senior-grade Python CLI for converting text between identifier cases.

`text-case` converts a string between the six common identifier cases — **snake_case**, **camelCase**, **PascalCase**, **kebab-case**, **SCREAMING_SNAKE_CASE**, **Title Case** — accepting input as a CLI argument or via stdin. It detects word boundaries from any input format (camelCase, PascalCase, snake_case, kebab-case, SCREAMING_SNAKE_CASE, space-separated, or any mix).

## Install

```bash
pip install text-case
```

Local development:

```bash
git clone https://github.com/brunoraniere2003/project-factory.git
cd project-factory/projects/text-case
python3.12 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

## Usage

```bash
$ textcase to-snake "Hello World"
hello_world

$ textcase to-camel "hello world"
helloWorld

$ textcase to-pascal "hello world"
HelloWorld

$ textcase to-kebab "Hello World"
hello-world

$ textcase to-screaming "hello world"
HELLO_WORLD

$ textcase to-title "hello_world"
Hello World
```

### Stdin support

```bash
$ echo "helloWorld" | textcase to-snake
hello_world
```

### Cross-format conversion

`text-case` detects word boundaries from any input format:

```bash
$ textcase to-snake "helloWorld"
hello_world

$ textcase to-camel "HELLO_WORLD"
helloWorld

$ textcase to-pascal "hello-world_test case"
HelloWorldTestCase
```

### Edge cases

- **Idempotent**: converting input that is already in the target format is a no-op.
- **Unicode preserved**: Latin-1 characters (e.g., `Olá`, `Á`) round-trip correctly.
- **Empty input**: rejected with a non-zero exit code.

## Development

```bash
# Run tests + coverage (must be 100%)
pytest

# Lint + format-check + type-check
ruff check .
black --check .
mypy --strict src

# All-in-one
pre-commit run --all-files
```

## Architecture

See [`docs/adr/0001-typer-and-pytest.md`](docs/adr/0001-typer-and-pytest.md) for design rationale.

Three-layer module:

```
text_case/
├── __init__.py        # Public API (re-exports `convert`)
├── converter.py       # Pure functions: case conversions
└── cli.py             # Typer-based CLI (thin wrapper)
```

## Methodology

Built by the **Project Factory AI team** following a 15-step methodology cycle on every change. See [`CLAUDE.md`](../../CLAUDE.md) at the factory root.

- 🗂️ **Voyager** (PM) — spec
- 🧠 **Apollo** (TL) — design + review
- 🌿💻♻️📚 **Falcon** (ENG) — branch, implement, refactor, document
- 🧪 **Hubble** (QA) — failing tests first (RED)
- 🚀 **Atlas** (DevOps) — ship

## License

MIT
