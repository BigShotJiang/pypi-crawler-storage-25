"""Pure case conversion functions.

Public API:
    ``convert(text: str, *, to: CaseTarget) -> str``
"""

from __future__ import annotations

from typing import Final, Literal

import regex as re

CaseTarget = Literal[
    "snake",
    "camel",
    "pascal",
    "kebab",
    "screaming",
    "title",
    "dot",
]

_VALID_TARGETS: Final[frozenset[str]] = frozenset(
    {"snake", "camel", "pascal", "kebab", "screaming", "title", "dot"}
)

# Insert a space at lowercase/digit-to-uppercase transitions (Unicode-wide).
_LOWER_UPPER_RE: Final = re.compile(r"(\p{Ll}|\p{Nd})(\p{Lu})")

# Insert a space at acronym-to-word transitions (e.g. "ABCDef" -> "ABC Def").
_ACRONYM_WORD_RE: Final = re.compile(r"(\p{Lu})(\p{Lu}\p{Ll})")

# Splits the normalised string on whitespace, underscore, hyphen, or dot.
_DELIM_RE: Final = re.compile(r"[\s_.-]+")

# Strict mode: allow any Unicode letter (\p{L}) or digit (\p{Nd}) plus delimiters.
_STRICT_INVALID_RE: Final = re.compile(r"[^\p{L}\p{Nd}\s_.-]")


def _tokenize(text: str) -> list[str]:
    """Split ``text`` into lowercase tokens regardless of input case format."""
    s = _LOWER_UPPER_RE.sub(r"\1 \2", text)
    s = _ACRONYM_WORD_RE.sub(r"\1 \2", s)
    fragments = _DELIM_RE.split(s)
    return [f.lower() for f in fragments if f]


def convert(text: str, *, to: CaseTarget, strict: bool = False) -> str:
    """Convert ``text`` to the target case format.

    Args:
        text: Input string. Must be non-empty and not whitespace-only.
        to: Target case. One of: ``snake``, ``camel``, ``pascal``, ``kebab``,
            ``screaming``, ``title``, ``dot``.
        strict: When True, reject input containing any character outside the
            identifier-safe set (letters, digits, whitespace, ``_``, ``-``, ``.``).
            Defaults to False (legacy permissive behavior).

    Returns:
        The converted string.

    Raises:
        ValueError: If ``text`` is empty / whitespace-only, ``to`` is not a known
            case, or (``strict=True``) ``text`` contains an invalid character.
    """
    if to not in _VALID_TARGETS:
        raise ValueError(f"unknown target case: {to!r}")
    if not text or not text.strip():
        raise ValueError("input text is empty")

    if strict:
        bad = _STRICT_INVALID_RE.search(text)
        if bad:
            raise ValueError(
                f"strict mode: input contains invalid character {bad.group()!r} "
                f"at position {bad.start()}"
            )

    tokens = _tokenize(text)
    if not tokens:
        raise ValueError("input text is empty")

    if to == "snake":
        return "_".join(tokens)
    if to == "camel":
        return tokens[0] + "".join(t.capitalize() for t in tokens[1:])
    if to == "pascal":
        return "".join(t.capitalize() for t in tokens)
    if to == "kebab":
        return "-".join(tokens)
    if to == "screaming":
        return "_".join(t.upper() for t in tokens)
    if to == "title":
        return " ".join(t.capitalize() for t in tokens)
    # to == "dot" (exhaustive over CaseTarget after up-front validation)
    return ".".join(tokens)
