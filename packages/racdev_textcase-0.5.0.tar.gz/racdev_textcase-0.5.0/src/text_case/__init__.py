"""text-case: CLI to convert text between identifier cases."""

from text_case.converter import convert

__version__ = "0.5.0"
__all__ = ["__version__", "convert"]
