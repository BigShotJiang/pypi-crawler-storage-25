"""Typer-based CLI entrypoint for text-case."""

from __future__ import annotations

import sys

import typer

from text_case import __version__
from text_case.converter import CaseTarget, convert


def _version_callback(value: bool) -> None:
    """Print the version and exit (eager so it runs before subcommand parsing)."""
    if value:
        typer.echo(f"textcase {__version__}")
        raise typer.Exit()


app = typer.Typer(
    name="textcase",
    help=(
        "Convert text between identifier cases "
        "(snake / camel / pascal / kebab / screaming / title / dot)."
    ),
    no_args_is_help=True,
    add_completion=False,
)


@app.callback()
def _root(
    version: bool = typer.Option(
        False,
        "--version",
        callback=_version_callback,
        is_eager=True,
        help="Print the version and exit.",
    ),
) -> None:
    """Top-level callback exposing the --version flag."""


def _resolve_input(text: str | None) -> str:
    """Resolve the input text from argv or stdin.

    Raises ``typer.BadParameter`` if no usable input is provided.
    """
    if text is None or text == "":
        text = sys.stdin.read()
    text = text.strip()
    if not text:
        raise typer.BadParameter("Input text is empty.")
    return text


def _emit(target: CaseTarget, text: str | None, strict: bool) -> None:
    """Convert ``text`` to ``target`` and print to stdout."""
    resolved = _resolve_input(text)
    try:
        typer.echo(convert(resolved, to=target, strict=strict))
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc


_STRICT_OPT = typer.Option(
    False,
    "--strict",
    help="Reject input containing characters outside [letters, digits, whitespace, _, -, .].",
)


@app.command("to-snake")
def to_snake(
    text: str | None = typer.Argument(None),
    strict: bool = _STRICT_OPT,
) -> None:
    """Convert input to snake_case."""
    _emit("snake", text, strict)


@app.command("to-camel")
def to_camel(
    text: str | None = typer.Argument(None),
    strict: bool = _STRICT_OPT,
) -> None:
    """Convert input to camelCase."""
    _emit("camel", text, strict)


@app.command("to-pascal")
def to_pascal(
    text: str | None = typer.Argument(None),
    strict: bool = _STRICT_OPT,
) -> None:
    """Convert input to PascalCase."""
    _emit("pascal", text, strict)


@app.command("to-kebab")
def to_kebab(
    text: str | None = typer.Argument(None),
    strict: bool = _STRICT_OPT,
) -> None:
    """Convert input to kebab-case."""
    _emit("kebab", text, strict)


@app.command("to-screaming")
def to_screaming(
    text: str | None = typer.Argument(None),
    strict: bool = _STRICT_OPT,
) -> None:
    """Convert input to SCREAMING_SNAKE_CASE."""
    _emit("screaming", text, strict)


@app.command("to-title")
def to_title(
    text: str | None = typer.Argument(None),
    strict: bool = _STRICT_OPT,
) -> None:
    """Convert input to Title Case."""
    _emit("title", text, strict)


@app.command("to-dot")
def to_dot(
    text: str | None = typer.Argument(None),
    strict: bool = _STRICT_OPT,
) -> None:
    """Convert input to dot.notation.case."""
    _emit("dot", text, strict)


if __name__ == "__main__":  # pragma: no cover
    app()
