"""Failing tests for text_case.converter — RED phase (Hubble, Issue #1).

Coverage targets:
- Happy path: every (input case, target case) pair documented in the spec
- Edge cases: empty, single word, idempotent (already in target), unicode, mixed delimiters
- Errors: empty string raises ValueError, unknown 'to' raises ValueError
"""

from __future__ import annotations

import pytest

from text_case.converter import convert

# ---------- Happy path: every (input format, target case) pair ----------


@pytest.mark.parametrize(
    ("text", "to", "expected"),
    [
        # From space-separated input
        ("Hello World", "snake", "hello_world"),
        ("hello world", "camel", "helloWorld"),
        ("hello world", "pascal", "HelloWorld"),
        ("Hello World", "kebab", "hello-world"),
        ("hello world", "screaming", "HELLO_WORLD"),
        ("hello_world", "title", "Hello World"),
        # From snake_case input
        ("hello_world", "camel", "helloWorld"),
        ("hello_world", "pascal", "HelloWorld"),
        ("hello_world", "kebab", "hello-world"),
        ("hello_world", "screaming", "HELLO_WORLD"),
        # From camelCase input
        ("helloWorld", "snake", "hello_world"),
        ("helloWorld", "kebab", "hello-world"),
        ("helloWorld", "screaming", "HELLO_WORLD"),
        ("helloWorld", "title", "Hello World"),
        # From PascalCase input
        ("HelloWorld", "snake", "hello_world"),
        ("HelloWorld", "kebab", "hello-world"),
        ("HelloWorld", "screaming", "HELLO_WORLD"),
        # From kebab-case input
        ("hello-world", "snake", "hello_world"),
        ("hello-world", "camel", "helloWorld"),
        ("hello-world", "pascal", "HelloWorld"),
        # From SCREAMING_SNAKE_CASE input
        ("HELLO_WORLD", "snake", "hello_world"),
        ("HELLO_WORLD", "camel", "helloWorld"),
        ("HELLO_WORLD", "title", "Hello World"),
    ],
)
def test_convert_happy_path(text: str, to: str, expected: str) -> None:
    """Each (input format, target format) pair converts as documented."""
    assert convert(text, to=to) == expected  # type: ignore[arg-type]


# ---------- Single-word edge cases ----------


@pytest.mark.parametrize(
    ("text", "to", "expected"),
    [
        ("hello", "snake", "hello"),
        ("hello", "kebab", "hello"),
        ("Hello", "camel", "hello"),
        ("hello", "pascal", "Hello"),
        ("hello", "screaming", "HELLO"),
        ("hello", "title", "Hello"),
    ],
)
def test_single_word_inputs(text: str, to: str, expected: str) -> None:
    assert convert(text, to=to) == expected  # type: ignore[arg-type]


# ---------- Idempotency: already in target = no-op ----------


@pytest.mark.parametrize(
    ("text", "to"),
    [
        ("hello_world", "snake"),
        ("helloWorld", "camel"),
        ("HelloWorld", "pascal"),
        ("hello-world", "kebab"),
        ("HELLO_WORLD", "screaming"),
        ("Hello World", "title"),
    ],
)
def test_idempotent_when_already_in_target(text: str, to: str) -> None:
    """Converting input already in the target format yields the same string."""
    assert convert(text, to=to) == text  # type: ignore[arg-type]


# ---------- Unicode preserved ----------


def test_unicode_preserved_lowercase() -> None:
    """Unicode letters preserved through case conversion (lowercased target)."""
    assert convert("Olá Mundo", to="snake") == "olá_mundo"


def test_unicode_preserved_uppercase() -> None:
    """Unicode letters uppercased correctly for screaming."""
    assert convert("olá mundo", to="screaming") == "OLÁ_MUNDO"


# ---------- Mixed delimiters normalized ----------


def test_mixed_delimiters_normalized() -> None:
    """Multiple delimiter types in one input are all treated as word boundaries."""
    assert convert("hello-world_test case", to="snake") == "hello_world_test_case"


# ---------- Errors ----------


def test_empty_string_raises() -> None:
    """Empty input raises ValueError."""
    with pytest.raises(ValueError, match="empty"):
        convert("", to="snake")


def test_whitespace_only_raises() -> None:
    """Whitespace-only input raises ValueError."""
    with pytest.raises(ValueError, match="empty"):
        convert("   ", to="snake")


def test_unknown_target_raises() -> None:
    """Unknown 'to' value raises ValueError."""
    with pytest.raises(ValueError, match="unknown"):
        convert("hello world", to="bogus")  # type: ignore[arg-type]


def test_only_delimiters_raises() -> None:
    """Input that contains only delimiter characters yields no tokens and raises."""
    with pytest.raises(ValueError, match="empty"):
        convert("___", to="snake")


def test_only_hyphens_raises() -> None:
    with pytest.raises(ValueError, match="empty"):
        convert("---", to="snake")


# ---------- to-dot (Issue #15) ----------


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("Hello World", "hello.world"),
        ("helloWorld", "hello.world"),
        ("HelloWorld", "hello.world"),
        ("hello_world", "hello.world"),
        ("hello-world", "hello.world"),
        ("HELLO_WORLD", "hello.world"),
    ],
)
def test_convert_to_dot_happy_path(text: str, expected: str) -> None:
    """Every input format converts to dot.notation."""
    assert convert(text, to="dot") == expected


def test_convert_to_dot_single_word() -> None:
    assert convert("hello", to="dot") == "hello"


def test_convert_to_dot_idempotent() -> None:
    """Already-in-dot input is a no-op."""
    assert convert("hello.world", to="dot") == "hello.world"


def test_convert_dot_to_snake() -> None:
    """dot input round-trips to snake."""
    assert convert("hello.world", to="snake") == "hello_world"


def test_convert_dot_to_camel() -> None:
    """dot input round-trips to camel."""
    assert convert("hello.world", to="camel") == "helloWorld"


# ---------- --strict mode (Issue #16) ----------


def test_strict_rejects_punctuation() -> None:
    with pytest.raises(ValueError, match=r"strict.*invalid"):
        convert("Hello! World", to="snake", strict=True)


def test_strict_rejects_emoji() -> None:
    with pytest.raises(ValueError, match=r"strict.*invalid"):
        convert("Hello 👋", to="snake", strict=True)


def test_strict_rejects_question_mark() -> None:
    with pytest.raises(ValueError, match=r"strict.*invalid"):
        convert("hello?world", to="snake", strict=True)


def test_strict_accepts_clean_input() -> None:
    assert convert("Hello World", to="snake", strict=True) == "hello_world"


def test_strict_accepts_latin1_unicode() -> None:
    assert convert("Olá Mundo", to="snake", strict=True) == "olá_mundo"


def test_strict_accepts_underscore_dot_hyphen() -> None:
    """All native delimiters allowed in strict mode."""
    assert convert("hello_world.test-case", to="snake", strict=True) == "hello_world_test_case"


def test_non_strict_default_keeps_legacy() -> None:
    """strict=False (default) accepts non-identifier chars (legacy behavior)."""
    # Should NOT raise — legacy behavior tokenizes "Hello!" as one token
    result = convert("Hello! World", to="snake")
    assert "world" in result


# ---------- Unicode beyond Latin-1 (Issue #13) ----------


def test_cyrillic_space_separated() -> None:
    assert convert("Привет Мир", to="snake") == "привет_мир"


def test_cyrillic_camelcase_boundary() -> None:
    """Cyrillic camelCase is detected as a boundary."""
    assert convert("ПриветМир", to="snake") == "привет_мир"


def test_mixed_script_camelcase() -> None:
    """Latin-to-Cyrillic camelCase boundary."""
    assert convert("helloМир", to="snake") == "hello_мир"


def test_greek_uppercase_to_snake() -> None:
    assert convert("ΓΕΙΑ ΣΑΣ", to="snake") == "γεια_σας"


def test_cjk_space_separated() -> None:
    """CJK has no case; space-delimited tokens preserved."""
    assert convert("こんにちは 世界", to="snake") == "こんにちは_世界"


def test_arabic_space_separated() -> None:
    assert convert("مرحبا عالم", to="snake") == "مرحبا_عالم"


def test_strict_accepts_cyrillic() -> None:
    """Strict mode accepts any Unicode letter."""
    assert convert("Привет", to="snake", strict=True) == "привет"


def test_strict_accepts_cjk() -> None:
    assert convert("世界", to="snake", strict=True) == "世界"


def test_strict_still_rejects_emoji() -> None:
    """Emoji is not a letter — strict mode rejects."""
    with pytest.raises(ValueError, match=r"strict.*invalid"):
        convert("Hello 👋", to="snake", strict=True)
