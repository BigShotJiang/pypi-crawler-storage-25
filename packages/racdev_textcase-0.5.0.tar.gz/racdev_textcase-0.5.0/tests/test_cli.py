"""Failing tests for text_case.cli — RED phase (Hubble, Issue #1).

Uses Typer's CliRunner. Each subcommand:
- accepts a text arg
- accepts stdin if no arg
- exits non-zero on empty / missing input
- exits non-zero on unknown subcommand
"""

from __future__ import annotations

import pytest
from typer.testing import CliRunner

from text_case.cli import app

runner = CliRunner()


# ---------- Each subcommand happy path (with text arg) ----------


@pytest.mark.parametrize(
    ("subcommand", "input_text", "expected_stdout"),
    [
        ("to-snake", "Hello World", "hello_world"),
        ("to-camel", "hello world", "helloWorld"),
        ("to-pascal", "hello world", "HelloWorld"),
        ("to-kebab", "Hello World", "hello-world"),
        ("to-screaming", "hello world", "HELLO_WORLD"),
        ("to-title", "hello_world", "Hello World"),
        ("to-dot", "Hello World", "hello.world"),
    ],
)
def test_subcommand_with_arg(subcommand: str, input_text: str, expected_stdout: str) -> None:
    result = runner.invoke(app, [subcommand, input_text])
    assert result.exit_code == 0
    assert expected_stdout in result.stdout


# ---------- Stdin support ----------


def test_stdin_input_to_snake() -> None:
    result = runner.invoke(app, ["to-snake"], input="Hello World\n")
    assert result.exit_code == 0
    assert "hello_world" in result.stdout


def test_stdin_input_to_camel() -> None:
    result = runner.invoke(app, ["to-camel"], input="hello world\n")
    assert result.exit_code == 0
    assert "helloWorld" in result.stdout


# ---------- Help ----------


def test_help_lists_all_subcommands() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    expected_subs = [
        "to-snake",
        "to-camel",
        "to-pascal",
        "to-kebab",
        "to-screaming",
        "to-title",
        "to-dot",
    ]
    for sub in expected_subs:
        assert sub in result.stdout


# ---------- Errors ----------


def test_empty_arg_exits_nonzero() -> None:
    result = runner.invoke(app, ["to-snake", ""])
    assert result.exit_code != 0


def test_unknown_subcommand_exits_nonzero() -> None:
    result = runner.invoke(app, ["to-bogus", "hello"])
    assert result.exit_code != 0


def test_no_arg_no_stdin_exits_nonzero() -> None:
    """No arg and empty stdin → exit nonzero."""
    result = runner.invoke(app, ["to-snake"], input="")
    assert result.exit_code != 0


# ---------- --strict flag (Issue #16) ----------


def test_to_snake_strict_rejects_special_chars() -> None:
    result = runner.invoke(app, ["to-snake", "--strict", "Hello! World"])
    assert result.exit_code != 0


def test_to_snake_strict_accepts_clean_input() -> None:
    result = runner.invoke(app, ["to-snake", "--strict", "Hello World"])
    assert result.exit_code == 0
    assert "hello_world" in result.stdout


def test_to_dot_strict_rejects_special() -> None:
    result = runner.invoke(app, ["to-dot", "--strict", "foo@bar"])
    assert result.exit_code != 0


# ---------- --version flag (Issue #14) ----------


def test_version_long_flag_prints_version_and_exits_zero() -> None:
    """--version prints 'textcase <version>' and exits 0."""
    from text_case import __version__

    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert f"textcase {__version__}" in result.stdout


def test_version_matches_dunder_version() -> None:
    """The version printed by --version matches text_case.__version__ exactly."""
    from text_case import __version__

    result = runner.invoke(app, ["--version"])
    assert __version__ in result.stdout


def test_version_does_not_require_subcommand() -> None:
    """--version works without any subcommand (eager option)."""
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    # Should not error out asking for a subcommand
    assert "Missing command" not in result.stdout
    assert "Usage" not in result.stdout or "textcase" in result.stdout
