"""Healing strategies registry and built-in strategies."""
import re
from typing import Any, Dict, List, Optional

from .types import HealingAction, HealingStatus


class Strategy:
    """Base strategy class for healing actions."""
    name: str = "base"
    confidence: float = 0.0
    patterns: List[str] = []

    def match(self, error_type: str, error_msg: str) -> bool:
        """Check if this strategy matches the error."""
        return any(re.search(p, error_msg, re.IGNORECASE) for p in self.patterns)

    def execute(self, error: Exception, context: Dict) -> HealingAction:
        """Execute the healing action."""
        raise NotImplementedError


class RateLimitStrategy(Strategy):
    """Handle rate limit errors with backoff."""
    name = "rate_limit"
    confidence = 0.9
    patterns = [r"rate.?limit", r"too many requests", r"429", r"quota exceeded"]

    def execute(self, error: Exception, context: Dict) -> HealingAction:
        return HealingAction(
            strategy_name=self.name,
            status=HealingStatus.HEALED,
            action="backoff_and_retry",
            modified_params=context,
            metadata={"backoff_seconds": 60}
        )


class AuthRefreshStrategy(Strategy):
    """Handle authentication errors."""
    name = "auth_refresh"
    confidence = 0.85
    patterns = [r"unauthorized", r"401", r"invalid.?api.?key", r"token.?expired", r"authentication failed"]

    def execute(self, error: Exception, context: Dict) -> HealingAction:
        return HealingAction(
            strategy_name=self.name,
            status=HealingStatus.HEALED,
            action="refresh_auth_and_retry",
            modified_params=context
        )


class ModelFallbackStrategy(Strategy):
    """Handle model not found errors with fallback."""
    name = "model_fallback"
    confidence = 0.8
    patterns = [r"model.?not.?found", r"invalid.?model", r"404", r"does not exist"]

    def execute(self, error: Exception, context: Dict) -> HealingAction:
        params = dict(context)
        if "model" in params:
            params["model"] = self._get_fallback(params["model"])
        return HealingAction(
            strategy_name=self.name,
            status=HealingStatus.HEALED,
            action="fallback_model",
            modified_params=params
        )

    @staticmethod
    def _get_fallback(model: str) -> str:
        fallbacks = {
            "gpt-4": "gpt-3.5-turbo",
            "gpt-4-turbo": "gpt-3.5-turbo",
            "claude-3-opus": "claude-3-sonnet",
            "deepseek-chat": "deepseek-coder"
        }
        return fallbacks.get(model, model)


class NetworkRetryStrategy(Strategy):
    """Handle network errors with retry."""
    name = "network_retry"
    confidence = 0.7
    patterns = [r"timeout", r"connection", r"network", r"ECONNRESET", r"ETIMEDOUT"]

    def execute(self, error: Exception, context: Dict) -> HealingAction:
        attempt = context.get("attempt", 1)
        return HealingAction(
            strategy_name=self.name,
            status=HealingStatus.HEALED,
            action="retry_with_backoff",
            modified_params=context,
            metadata={"backoff_seconds": min(2 ** attempt, 30)}
        )


class StrategyRegistry:
    """Registry for managing healing strategies."""

    def __init__(self):
        self._strategies: List[Strategy] = [
            RateLimitStrategy(),
            AuthRefreshStrategy(),
            ModelFallbackStrategy(),
            NetworkRetryStrategy()
        ]

    def register(self, strategy: Strategy):
        """Register a new strategy."""
        self._strategies.append(strategy)

    def match(self, error_type: str, error_msg: str, context: Optional[Dict] = None) -> Optional[Strategy]:
        """Find the best matching strategy for an error."""
        matches = [(s, s.confidence) for s in self._strategies if s.match(error_type, error_msg)]
        if not matches:
            return None
        matches.sort(key=lambda x: x[1], reverse=True)
        return matches[0][0]

    @property
    def strategies(self) -> List[str]:
        """Return list of registered strategy names."""
        return [s.name for s in self._strategies]
