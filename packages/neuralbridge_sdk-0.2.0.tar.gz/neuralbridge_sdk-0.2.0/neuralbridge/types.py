"""Type definitions for NeuralBridge SDK."""
from enum import Enum
from typing import Any, Dict, Optional


class HealingStatus(Enum):
    """Status of a healing action."""
    HEALED = "healed"
    PARTIAL = "partial"
    FAILED = "failed"
    SKIPPED = "skipped"


class DiagnosisResult:
    """Result of error diagnosis."""

    def __init__(
        self,
        error_type: str,
        error_message: str,
        recommended_strategy: Optional[Any] = None,
        confidence: float = 0.0,
        context: Optional[Dict] = None
    ):
        self.error_type = error_type
        self.error_message = error_message
        self.recommended_strategy = recommended_strategy
        self.confidence = confidence
        self.context = context or {}

    def __repr__(self):
        return f"DiagnosisResult(error={self.error_type}, confidence={self.confidence:.2f}, strategy={self.recommended_strategy})"


class HealingAction:
    """Action to heal from an error."""

    def __init__(
        self,
        strategy_name: str,
        status: HealingStatus,
        action: str,
        modified_params: Optional[Dict] = None,
        metadata: Optional[Dict] = None
    ):
        self.strategy_name = strategy_name
        self.status = status
        self.action = action
        self.modified_params = modified_params
        self.metadata = metadata or {}

    def __repr__(self):
        return f"HealingAction(strategy={self.strategy_name}, status={self.status.value}, action={self.action})"
