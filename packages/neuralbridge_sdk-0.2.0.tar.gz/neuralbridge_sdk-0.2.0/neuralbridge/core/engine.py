"""NeuralBridge Core - Self-healing Engine (V8.2)"""
import hashlib
import re
import time
import threading
import requests
from collections import defaultdict, deque
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any

from .types import (ModelPerformance, RecoveryRecord, AdaptiveTimeout, DynamicBackoff, FaultPredictor, RequestProfile)
from .strategies import CASCADE_STRATEGIES, DEFAULT_CASCADE, FAULT_MODEL_MAPPING


class FlywheelEngine:
    """NeuralBridge self-healing decision engine - 4-layer cascade recovery."""

    def __init__(self, api_key: str, base_url: str = "https://api.openai.com/v1",
                 models: Optional[List[str]] = None, primary_model: str = "gpt-4o",
                 fallback_models: Optional[List[str]] = None):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.primary_model = primary_model
        self.fallback_models = fallback_models or ["gpt-4o-mini"]
        self.all_models = [primary_model] + self.fallback_models
        self.model_performance: Dict[str, ModelPerformance] = {m: ModelPerformance(model_name=m) for m in self.all_models}
        self.response_time_history: deque = deque(maxlen=50)
        self.dynamic_backoff = DynamicBackoff()
        self.fault_predictor = FaultPredictor()
        self.adaptive_timeout = AdaptiveTimeout()
        self.recovery_records: List[RecoveryRecord] = []
        self.lock = threading.Lock()
        self.diagnosis_stats: Dict[str, int] = defaultdict(int)
        self._timeout_consecutive_failures = 0

    def diagnose(self, error_msg=None, status_code=None, response_data=None):
        fault_type, confidence = "internal_error", 0.5
        
        if error_msg:
            el = str(error_msg).lower()
            if any(p in el for p in ["timeout", "timed out", "timed_out", "connection timeout"]):
                fault_type, confidence = "connection_timeout", 0.95
            elif any(p in el for p in ["model", "invalid", "not found", "does not exist"]):
                fault_type, confidence = "model_not_found", 0.90
            elif any(p in el for p in ["rate limit", "rate_limit", "429", "too many requests"]):
                fault_type, confidence = "rate_limit_exceeded", 0.95
            elif any(p in el for p in ["context", "length", "too long", "token limit", "exceeded"]):
                fault_type, confidence = "context_length_exceeded", 0.85
            elif any(p in el for p in ["overload", "503", "unavailable"]):
                fault_type, confidence = "service_overloaded", 0.90
            elif any(p in el for p in ["safety", "blocked", "content", "filter"]):
                fault_type, confidence = "content_safety_blocked", 0.80
            elif any(p in el for p in ["401", "unauthorized", "api key", "invalid key"]):
                fault_type, confidence = "invalid_api_key", 0.95
            elif any(p in el for p in ["500", "internal"]):
                fault_type, confidence = "internal_error", 0.85

        if status_code:
            sc_map = {408: ("connection_timeout", 0.90), 429: ("rate_limit_exceeded", 0.95),
                      503: ("service_overloaded", 0.90), 401: ("invalid_api_key", 0.95)}
            if status_code in sc_map:
                ft, c = sc_map[status_code]
                fault_type, confidence = ft, max(confidence, c)
            elif status_code == 400:
                if "model" in str(error_msg or "").lower():
                    fault_type, confidence = "model_not_found", max(confidence, 0.85)
                elif "context" in str(error_msg or "").lower():
                    fault_type, confidence = "context_length_exceeded", max(confidence, 0.85)

        self.diagnosis_stats[fault_type] += 1
        return fault_type, confidence

    def select_best_model(self, fault_type=None, prefer_speed=False, prefer_reliability=False):
        if fault_type and fault_type in FAULT_MODEL_MAPPING:
            return self._select_by_strategy(FAULT_MODEL_MAPPING[fault_type]["select_strategy"])

        best_model, best_score = self.primary_model, -1
        for model in self.all_models:
            perf = self.model_performance.get(model, ModelPerformance(model_name=model))
            if prefer_speed:
                score = max(0, 1 - perf.avg_latency_ms / 10000) * 0.7 + perf.success_rate * 0.3
            elif prefer_reliability:
                score = perf.success_rate * 0.7 + max(0, 1 - perf.avg_latency_ms / 10000) * 0.3
            else:
                score = perf.get_score()

            if fault_type == "connection_timeout":
                score *= 1 - (perf.timeout_count / max(1, perf.success_count + perf.timeout_count)) * 0.5

            if score > best_score:
                best_score, best_model = score, model

        return best_model

    def _select_by_strategy(self, strategy):
        if strategy == "speed_priority":
            return min(self.all_models, key=lambda m: self.model_performance.get(m, ModelPerformance(model_name=m)).avg_latency_ms)
        if strategy == "load_balance":
            return self.fallback_models[0] if self.primary_model == self.all_models[0] else self.primary_model
        if strategy == "reliability_priority":
            return max(self.all_models, key=lambda m: self.model_performance.get(m, ModelPerformance(model_name=m)).success_rate)
        return self.primary_model

    def generate_fault_fingerprint(self, fault_type, error_msg, model):
        pattern_hash = hashlib.md5(str(error_msg)[:50].encode()).hexdigest()[:8]
        timestamp = datetime.now().strftime("%Y%m%d%H")
        return hashlib.sha256(f"{fault_type}:{pattern_hash}:{model}:{timestamp}".encode()).hexdigest()[:16]

    def analyze_request(self, messages, kwargs):
        total_tokens = sum(len(str(m.get("content", "")).split()) * 1.3 for m in messages)
        complexity = "high" if total_tokens > 2000 or kwargs.get("max_tokens", 2048) > 2000 else ("medium" if total_tokens > 500 else "low")
        return RequestProfile(
            complexity=complexity,
            estimated_tokens=int(total_tokens),
            streaming=kwargs.get("stream", False),
            has_system_prompt=any(m.get("role") == "system" for m in messages),
            max_tokens_requested=kwargs.get("max_tokens", 2048),
            temperature=kwargs.get("temperature", 0.7)
        )

    def degrade_request(self, messages, fault_type, profile=None):
        info = {"action": "no_degradation", "changes": []}

        if fault_type == "context_length_exceeded":
            preserved = [m for m in messages if m.get("role") in ("system", "user")]
            other = [m for m in messages if m.get("role") not in ("system", "user")]
            return preserved + other[-2:], {"action": "smart_truncate"}

        if fault_type == "content_safety_blocked":
            triggers = ["暴力", "色情", "政治", "敏感", "违法", "hack", "porn", "violent"]
            degraded = []
            for m in messages:
                content = m.get("content", "")
                for w in triggers:
                    content = re.sub(w, "[redacted]", content, flags=re.IGNORECASE)
                degraded.append({"role": m.get("role"), "content": content})
            return degraded, {"action": "prompt_rewrite"}

        return messages, info

    def _execute_request(self, messages, model=None, timeout=60, **kwargs):
        model = model or self.primary_model
        start = time.time()
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {"model": model, "messages": messages}
        for key in ("max_tokens", "temperature", "top_p", "stream"):
            if key in kwargs:
                payload[key] = kwargs[key]

        try:
            resp = requests.post(f"{self.base_url}/chat/completions", headers=headers, json=payload, timeout=timeout)
            latency_ms = (time.time() - start) * 1000
            self.response_time_history.append(latency_ms)

            if resp.status_code == 200:
                return {"success": True, "response": resp.json(), "status_code": 200}, latency_ms

            err = resp.json() if resp.content else {}
            return {"success": False, "error": err.get("error", {}).get("message", f"HTTP {resp.status_code}"),
                    "error_code": err.get("error", {}).get("code"), "status_code": resp.status_code}, latency_ms

        except requests.exceptions.Timeout:
            latency_ms = (time.time() - start) * 1000
            self.dynamic_backoff.record_result(False, latency_ms, is_timeout=True)
            return {"success": False, "error": "Request timeout", "error_code": "timeout"}, latency_ms

        except Exception as e:
            return {"success": False, "error": str(e)}, (time.time() - start) * 1000

    def _check_success(self, response):
        if not response or not isinstance(response, dict):
            return False
        if response.get("success") is True:
            return True
        rd = response.get("response", {})
        return isinstance(rd, dict) and bool(rd.get("choices"))

    def record_model_result(self, model, success, latency_ms, is_timeout=False, is_rate_limit=False):
        with self.lock:
            if model not in self.model_performance:
                self.model_performance[model] = ModelPerformance(model_name=model)
            perf = self.model_performance[model]
            if success:
                perf.record_success(latency_ms)
                self._timeout_consecutive_failures = 0
            else:
                perf.record_failure(is_timeout, is_rate_limit)
                if is_timeout:
                    self._timeout_consecutive_failures += 1

    def cascade_recover(self, initial_error, messages, original_model=None, **kwargs):
        start = time.time()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        model = original_model or self.primary_model

        fault_type, confidence = self.diagnose(
            error_msg=initial_error.get("error"),
            status_code=initial_error.get("status_code")
        )

        if fault_type == "connection_timeout":
            model = self.fallback_models[0] if model == self.primary_model else self.primary_model

        fingerprint = self.generate_fault_fingerprint(fault_type, initial_error.get("error", ""), model)
        need_predictive = self.fault_predictor.record_fault(fingerprint)
        profile = self.analyze_request(messages, kwargs)

        current_messages, current_model, current_kwargs = messages, model, kwargs.copy()
        cascade_level, strategy_used, strategy_params = 0, "", {}
        recovery_response, recovery_latency_ms = None, 0.0
        total_attempts = 0

        for strategy in CASCADE_STRATEGIES.get(fault_type, DEFAULT_CASCADE):
            cascade_level = strategy["level"]
            strategy_used = strategy.get("name", strategy["action"])
            strategy_params = strategy.copy()
            total_attempts += 1

            action = strategy["action"]
            timeout_override = strategy.get("timeout_override", 60)

            if action == "predictive_switch":
                if need_predictive:
                    new_model = self.select_best_model(fault_type)
                    if new_model != current_model:
                        current_model = new_model
                        strategy_params["switched_to"] = new_model
                    current_kwargs["timeout"] = timeout_override
                    response, latency = self._execute_request(current_messages, current_model, **current_kwargs)
                    recovery_response, recovery_latency_ms = response, latency
                    if self._check_success(response):
                        self.record_model_result(current_model, True, latency)
                        break
                    need_predictive = False
                continue

            if action == "immediate_model_switch":
                new_model = self.fallback_models[0] if current_model == self.primary_model else self.primary_model
                if new_model != current_model:
                    current_model = new_model
                    strategy_params["switched_to"] = new_model
                current_kwargs["timeout"] = timeout_override
                response, latency = self._execute_request(current_messages, current_model, **current_kwargs)
                recovery_response, recovery_latency_ms = response, latency
                if self._check_success(response):
                    self.record_model_result(current_model, True, latency)
                    break
                self.record_model_result(current_model, False, latency, is_timeout="timeout" in str(response).lower())
                continue

            if action == "dynamic_backoff_switch_retry":
                new_model = self.fallback_models[0] if current_model == self.primary_model else self.primary_model
                if new_model != current_model:
                    current_model = new_model
                    strategy_params["switched_to"] = new_model
                time.sleep(strategy.get("wait_before_retry", 3))
                current_kwargs["timeout"] = timeout_override
                response, latency = self._execute_request(current_messages, current_model, **current_kwargs)
                is_timeout = "timeout" in str(response).lower()
                self.dynamic_backoff.record_result(self._check_success(response), latency, is_timeout)
                recovery_response, recovery_latency_ms = response, latency
                if self._check_success(response):
                    self.record_model_result(current_model, True, latency)
                    break
                self.record_model_result(current_model, False, latency, is_timeout=is_timeout)
                continue

            if action == "dynamic_backoff_retry":
                time.sleep(self.dynamic_backoff.calculate_delay(fault_type))
                current_kwargs["timeout"] = timeout_override
                response, latency = self._execute_request(current_messages, current_model, **current_kwargs)
                recovery_response, recovery_latency_ms = response, latency
                if self._check_success(response):
                    self.record_model_result(current_model, True, latency)
                    break
                self.record_model_result(current_model, False, latency)
                continue

            if action == "fault_model_mapping_switch":
                new_model = self.select_best_model(fault_type)
                if new_model != current_model:
                    current_model = new_model
                    strategy_params["switched_to"] = new_model
                current_kwargs["timeout"] = timeout_override
                response, latency = self._execute_request(current_messages, current_model, **current_kwargs)
                recovery_response, recovery_latency_ms = response, latency
                if self._check_success(response):
                    self.record_model_result(current_model, True, latency)
                    break
                self.record_model_result(current_model, False, latency)
                continue

            if action == "smart_truncate":
                degraded, deg = self.degrade_request(current_messages, fault_type, profile)
                current_messages = degraded
                strategy_params["degradation"] = deg
                current_kwargs["timeout"] = timeout_override
                response, latency = self._execute_request(current_messages, current_model, **current_kwargs)
                recovery_response, recovery_latency_ms = response, latency
                if self._check_success(response):
                    self.record_model_result(current_model, True, latency)
                    break
                self.record_model_result(current_model, False, latency)
                continue

            if action in ("basic_retry", "extended_wait_retry"):
                if action == "extended_wait_retry":
                    time.sleep(strategy.get("wait_seconds", 10))
                current_kwargs["timeout"] = timeout_override
                response, latency = self._execute_request(current_messages, current_model, **current_kwargs)
                recovery_response, recovery_latency_ms = response, latency
                if self._check_success(response):
                    self.record_model_result(current_model, True, latency)
                    break
                self.record_model_result(current_model, False, latency)
                continue

            if action == "model_switch":
                current_model = self.fallback_models[0] if current_model == self.primary_model else self.primary_model
                strategy_params["switched_to"] = current_model
                current_kwargs["timeout"] = timeout_override
                response, latency = self._execute_request(current_messages, current_model, **current_kwargs)
                recovery_response, recovery_latency_ms = response, latency
                if self._check_success(response):
                    self.record_model_result(current_model, True, latency)
                    break
                self.record_model_result(current_model, False, latency)
                continue

            if action == "request_degrade":
                degraded, deg = self.degrade_request(current_messages, fault_type, profile)
                current_messages = degraded
                strategy_params["degradation"] = deg
                current_kwargs["timeout"] = timeout_override
                response, latency = self._execute_request(current_messages, current_model, **current_kwargs)
                recovery_response, recovery_latency_ms = response, latency
                if self._check_success(response):
                    self.record_model_result(current_model, True, latency)
                    break
                self.record_model_result(current_model, False, latency)
                continue

        total_time_ms = (time.time() - start) * 1000
        recovered = self._check_success(recovery_response) if recovery_response else False

        record = RecoveryRecord(
            timestamp=timestamp,
            fault_type=fault_type,
            diagnosis_confidence=confidence,
            first_error=initial_error.get("error", ""),
            cascade_level=cascade_level,
            strategy_used=strategy_used,
            strategy_params=strategy_params,
            recovered=recovered,
            total_attempts=total_attempts,
            total_time_ms=total_time_ms,
            fault_fingerprint=fingerprint,
            recovery_latency_ms=recovery_latency_ms
        )
        self.recovery_records.append(record)

        return recovery_response, record
