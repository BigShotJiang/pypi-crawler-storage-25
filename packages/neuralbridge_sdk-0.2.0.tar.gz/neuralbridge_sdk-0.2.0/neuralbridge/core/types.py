"""NeuralBridge Core - Types and Data Structures"""
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any, Tuple


class FaultCategory(Enum):
    NETWORK = "network"
    AUTH = "authentication"
    REQUEST = "request"
    RESPONSE = "response"
    SYSTEM = "system"
    BUSINESS = "business"
    ROUTING = "routing"


class FaultSeverity(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


class CascadeLevel(Enum):
    LAYER_0_PREDICTIVE = 0
    LAYER_1_SMART_RETRY = 1
    LAYER_2_SMART_SWITCH = 2
    LAYER_3_REQUEST_DEGRADE = 3


@dataclass
class ModelPerformance:
    model_name: str
    success_count: int = 0
    failure_count: int = 0
    total_latency_ms: float = 0.0
    timeout_count: int = 0
    last_used: float = 0.0
    last_success: float = 0.0
    rate_limit_count: int = 0

    @property
    def success_rate(self) -> float:
        total = self.success_count + self.failure_count
        return self.success_count / total if total > 0 else 0.5

    @property
    def avg_latency_ms(self) -> float:
        total_calls = self.success_count + self.timeout_count
        return self.total_latency_ms / total_calls if total_calls > 0 else 5000.0

    def record_success(self, latency_ms: float):
        self.success_count += 1
        self.total_latency_ms += latency_ms
        self.last_success = self.last_used = _now()

    def record_failure(self, is_timeout: bool = False, is_rate_limit: bool = False):
        self.failure_count += 1
        self.last_used = _now()
        if is_timeout:
            self.timeout_count += 1
        if is_rate_limit:
            self.rate_limit_count += 1

    def get_score(self) -> float:
        return self.success_rate * 0.6 + max(0, 1 - (self.avg_latency_ms / 10000)) * 0.4


@dataclass
class RecoveryRecord:
    timestamp: str
    fault_type: str
    diagnosis_confidence: float
    first_error: str
    cascade_level: int
    strategy_used: str
    strategy_params: Dict
    recovered: bool
    total_attempts: int
    total_time_ms: float
    fault_fingerprint: str = ""
    recovery_latency_ms: float = 0.0


@dataclass
class AdaptiveTimeout:
    base_timeout_ms: int = 30000
    history_window: int = 20
    multiplier: float = 1.5
    min_timeout_ms: int = 5000
    max_timeout_ms: int = 180000

    def calculate(self, avg_response_time: Optional[float] = None) -> int:
        if avg_response_time:
            calculated = int(avg_response_time * self.multiplier)
        else:
            calculated = self.base_timeout_ms
        return max(self.min_timeout_ms, min(self.max_timeout_ms, calculated))


@dataclass
class DynamicBackoff:
    base_delay_s: float = 1.0
    max_delay_s: float = 60.0
    min_delay_s: float = 1.0
    timeout_min_delay_s: float = 3.0
    last_response_time_ms: float = 0.0
    last_timeout_ms: float = 0.0
    consecutive_timeouts: int = 0

    def calculate_delay(self, fault_type: Optional[str] = None) -> float:
        if self.last_timeout_ms > 0 or (fault_type and "timeout" in fault_type.lower()):
            base_delay = max(3.0, min(self.last_timeout_ms / 1000 * 0.5, 15.0)) if self.last_timeout_ms > 0 else self.timeout_min_delay_s
            if self.consecutive_timeouts > 0:
                base_delay = min(base_delay * (1 + self.consecutive_timeouts * 0.2), self.max_delay_s)
            return base_delay
        
        if self.last_response_time_ms > 0:
            if self.last_response_time_ms < 1000:
                delay = max(self.min_delay_s, 1.0)
            elif self.last_response_time_ms < 5000:
                delay = 1.5
            elif self.last_response_time_ms < 10000:
                delay = 2.0
            else:
                delay = max(3.0, self.last_response_time_ms / 1000 * 0.3)
            return min(delay, self.max_delay_s)
        
        return self.base_delay_s

    def record_result(self, success: bool, latency_ms: float, is_timeout: bool = False):
        self.last_response_time_ms = latency_ms
        if is_timeout:
            self.last_timeout_ms = latency_ms
            self.consecutive_timeouts += 1
        else:
            self.last_timeout_ms = 0.0
            self.consecutive_timeouts = 0


@dataclass
class FaultPredictor:
    fingerprint_history: Dict[str, List[float]] = field(default_factory=dict)
    prediction_threshold: int = 3

    def record_fault(self, fingerprint: str) -> bool:
        import time as _time
        now = _time.time()
        if fingerprint not in self.fingerprint_history:
            self.fingerprint_history[fingerprint] = []
        self.fingerprint_history[fingerprint].append(now)
        self.fingerprint_history[fingerprint] = [t for t in self.fingerprint_history[fingerprint] if now - t < 3600]
        return len(self.fingerprint_history[fingerprint]) >= self.prediction_threshold

    def should_predictive_switch(self, fingerprint: str) -> bool:
        return fingerprint in self.fingerprint_history and len(self.fingerprint_history[fingerprint]) >= self.prediction_threshold


@dataclass
class RequestProfile:
    complexity: str
    estimated_tokens: int
    streaming: bool
    has_system_prompt: bool
    max_tokens_requested: int
    temperature: float


def _now() -> float:
    import time as _time
    return _time.time()
