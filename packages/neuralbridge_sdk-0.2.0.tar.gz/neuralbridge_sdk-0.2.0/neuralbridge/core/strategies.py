"""NeuralBridge Core - Recovery Strategies"""
from typing import Dict, List, Any

FAULT_MODEL_MAPPING: Dict[str, Dict[str, Any]] = {
    "connection_timeout": {"select_strategy": "speed_priority"},
    "rate_limit_exceeded": {"select_strategy": "load_balance"},
    "context_length_exceeded": {"select_strategy": "context_window"},
    "internal_error": {"select_strategy": "reliability_priority"},
}

CASCADE_STRATEGIES: Dict[str, List[Dict[str, Any]]] = {
    "connection_timeout": [
        {"level": 0, "name": "predictive_model_switch", "action": "predictive_switch", "trigger_on_fingerprint_count": 2},
        {"level": 1, "name": "immediate_model_switch", "action": "immediate_model_switch", "timeout_override": 60},
        {"level": 1, "name": "dynamic_backoff_switch_retry", "action": "dynamic_backoff_switch_retry", "timeout_override": 60, "wait_before_retry": 3},
        {"level": 2, "name": "fault_model_mapping_switch", "action": "fault_model_mapping_switch", "select_by": "fault_type_mapping", "timeout_override": 60},
    ],
    "rate_limit_exceeded": [
        {"level": 0, "name": "predictive_load_balance", "action": "predictive_load_balance", "trigger_on_fingerprint_count": 1},
        {"level": 1, "name": "dynamic_backoff_retry", "action": "dynamic_backoff_retry", "use_adaptive_backoff": True},
    ],
    "service_overloaded": [{"level": 1, "name": "extended_wait_retry", "action": "extended_wait_retry", "wait_seconds": 10}],
    "model_not_found": [{"level": 2, "name": "fault_model_mapping_switch", "action": "fault_model_mapping_switch", "select_by": "fault_type_mapping"}],
    "internal_error": [{"level": 2, "name": "fault_model_mapping_switch", "action": "fault_model_mapping_switch", "select_by": "fault_type_mapping"}],
    "context_length_exceeded": [{"level": 3, "name": "smart_truncate", "action": "smart_truncate", "preserve_ratio": 0.8, "preserve_system": True, "preserve_recent": True}],
    "content_safety_blocked": [{"level": 3, "name": "rewrite_prompt", "action": "rewrite_prompt", "remove_triggers": True}],
}

DEFAULT_CASCADE: List[Dict[str, Any]] = [
    {"level": 0, "name": "predictive_switch", "action": "predictive_switch"},
    {"level": 1, "name": "basic_retry", "action": "basic_retry"},
    {"level": 2, "name": "model_switch", "action": "model_switch"},
    {"level": 3, "name": "request_degrade", "action": "request_degrade"},
]
