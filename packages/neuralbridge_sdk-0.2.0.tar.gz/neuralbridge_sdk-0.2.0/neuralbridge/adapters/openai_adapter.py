"""NeuralBridge OpenAI Adapter - Drop-in replacement for openai.OpenAI"""
import time
from typing import List, Dict, Any, Optional

from ..core.engine import FlywheelEngine


class ChatCompletions:
    """Chat completions interface compatible with OpenAI API."""

    def __init__(self, engine: FlywheelEngine):
        self.engine = engine

    def create(self, model: str = None, messages: List[Dict[str, str]] = None, **kwargs):
        """Create chat completion with automatic fault recovery."""
        if messages is None:
            raise ValueError("messages parameter is required")

        model = model or self.engine.primary_model
        
        # First attempt with original model
        response, latency = self.engine._execute_request(messages, model, **kwargs)

        if self.engine._check_success(response):
            self.engine.record_model_result(model, True, latency)
            return self._format_response(response["response"])

        # Cascade recovery
        self.engine.record_model_result(model, False, latency)
        recovered_response, record = self.engine.cascade_recover(
            initial_error=response,
            messages=messages,
            original_model=model,
            **kwargs
        )

        if record.recovered:
            return self._format_response(recovered_response["response"])
        else:
            raise Exception(f"Recovery failed after {record.total_attempts} attempts. "
                          f"Fault: {record.fault_type}, Strategy: {record.strategy_used}")

    def _format_response(self, response_data: Dict) -> Any:
        """Format response to match OpenAI API structure."""
        class Choice:
            def __init__(self, index, message, finish_reason):
                self.index = index
                self.message = message
                self.finish_reason = finish_reason

        class Message:
            def __init__(self, role, content):
                self.role = role
                self.content = content

        class Usage:
            def __init__(self, prompt_tokens, completion_tokens, total_tokens):
                self.prompt_tokens = prompt_tokens
                self.completion_tokens = completion_tokens
                self.total_tokens = total_tokens

        class ChatCompletion:
            def __init__(self, data):
                self.id = data.get("id", "")
                self.object = "chat.completion"
                self.created = int(time.time())
                self.model = data.get("model", "")
                choices_data = data.get("choices", [])
                self.choices = []
                for c in choices_data:
                    msg = c.get("message", {})
                    message_obj = Message(msg.get("role", "assistant"), msg.get("content", ""))
                    choice_obj = Choice(c.get("index", 0), message_obj, c.get("finish_reason", "stop"))
                    self.choices.append(choice_obj)
                usage_data = data.get("usage", {})
                self.usage = Usage(
                    usage_data.get("prompt_tokens", 0),
                    usage_data.get("completion_tokens", 0),
                    usage_data.get("total_tokens", 0)
                )

        return ChatCompletion(response_data)


class NeuralBridge:
    """
    Self-healing decision engine for AI API calls.
    Drop-in replacement for openai.OpenAI with automatic fault diagnosis and cascade recovery.
    """

    def __init__(self, api_key: str, base_url: str = "https://api.openai.com/v1",
                 primary_model: str = "gpt-4o", fallback_models: Optional[List[str]] = None):
        """
        Initialize NeuralBridge client.

        Args:
            api_key: API key for authentication
            base_url: Base URL for API endpoint
            primary_model: Primary model to use (default: gpt-4o)
            fallback_models: List of fallback models (default: ["gpt-4o-mini"])
        """
        self.engine = FlywheelEngine(
            api_key=api_key,
            base_url=base_url,
            primary_model=primary_model,
            fallback_models=fallback_models
        )
        self.chat = type('Chat', (), {'completions': ChatCompletions(self.engine)})()

    def get_recovery_stats(self) -> Dict[str, Any]:
        """Get statistics about recovery operations."""
        return {
            "total_recovery_attempts": len(self.engine.recovery_records),
            "successful_recoveries": sum(1 for r in self.engine.recovery_records if r.recovered),
            "diagnosis_stats": dict(self.engine.diagnosis_stats),
            "model_performance": {
                model: {
                    "success_rate": perf.success_rate,
                    "avg_latency_ms": perf.avg_latency_ms,
                    "total_calls": perf.success_count + perf.failure_count
                }
                for model, perf in self.engine.model_performance.items()
            }
        }

    def clear_history(self):
        """Clear recovery history and reset performance metrics."""
        self.engine.recovery_records.clear()
        self.engine.diagnosis_stats.clear()
        for perf in self.engine.model_performance.values():
            perf.success_count = 0
            perf.failure_count = 0
            perf.total_latency_ms = 0.0
            perf.timeout_count = 0
            perf.rate_limit_count = 0
