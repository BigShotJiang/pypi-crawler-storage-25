"""Core NeuralBridge engine - Self-healing decision engine for AI APIs."""
import time
import logging
from typing import Any, Callable, Dict, Optional

from .strategies import StrategyRegistry
from .types import DiagnosisResult, HealingAction, HealingStatus

logger = logging.getLogger(__name__)


class NeuralBridge:
    """Self-healing decision engine for AI APIs."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        max_retries: int = 3,
        timeout: float = 30.0,
        enable_evolution: bool = True,
    ):
        self.api_key = api_key
        self.base_url = base_url
        self.max_retries = max_retries
        self.timeout = timeout
        self.enable_evolution = enable_evolution
        self._registry = StrategyRegistry()
        self._history: list = []
        self._stats = {"total_calls": 0, "healed_calls": 0, "failed_calls": 0}

    def diagnose(self, error: Exception, context: Optional[Dict] = None) -> DiagnosisResult:
        """Diagnose the error and recommend a healing strategy."""
        self._stats["total_calls"] += 1
        error_type = type(error).__name__
        error_msg = str(error)
        strategy = self._registry.match(error_type, error_msg, context)
        
        result = DiagnosisResult(
            error_type=error_type,
            error_message=error_msg,
            recommended_strategy=strategy,
            confidence=strategy.confidence if strategy else 0.0,
            context=context or {},
        )
        self._history.append(result)
        return result

    def heal(self, func: Optional[Callable] = None, api_call: Optional[Callable] = None, **kwargs) -> Any:
        """Execute function with self-healing retry logic."""
        target = func or api_call
        if target is None:
            raise ValueError("Must provide func or api_call")
        
        last_error = None
        for attempt in range(self.max_retries):
            try:
                result = target(**kwargs)
                self._stats["healed_calls"] += 1
                return result
            except Exception as e:
                last_error = e
                diagnosis = self.diagnose(e, {"attempt": attempt + 1})
                
                if diagnosis.recommended_strategy:
                    action = diagnosis.recommended_strategy.execute(e, diagnosis.context)
                    if action.status == HealingStatus.HEALED:
                        try:
                            healed_kwargs = action.modified_params or kwargs
                            result = target(**healed_kwargs)
                            self._stats["healed_calls"] += 1
                            return result
                        except Exception:
                            continue
                
                if attempt < self.max_retries - 1:
                    wait_time = min(2 ** attempt, 10)
                    time.sleep(wait_time)
        
        self._stats["failed_calls"] += 1
        raise last_error

    @property
    def stats(self) -> Dict:
        """Return current statistics."""
        return self._stats.copy()

    def reset_stats(self):
        """Reset all statistics and history."""
        self._stats = {"total_calls": 0, "healed_calls": 0, "failed_calls": 0}
        self._history.clear()
