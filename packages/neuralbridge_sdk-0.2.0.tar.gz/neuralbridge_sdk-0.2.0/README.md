# NeuralBridge SDK

Self-healing decision engine for AI API calls. Drop-in replacement for `openai.OpenAI` with automatic fault diagnosis, cascade recovery, and transparent model switching.

## Install

```bash
pip install neuralbridge
```

## Quick Start

```python
from neuralbridge import NeuralBridge

client = NeuralBridge(
    api_key="sk-xxx",
    primary_model="gpt-4o",
    fallback_models=["gpt-4o-mini"]
)

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}]
)
print(response.choices[0].message.content)
```

## 4-Layer Cascade Recovery

| Layer | Strategy | When |
|-------|----------|------|
| LAYER 0 | Predictive model switch | Same fault pattern seen 3+ times |
| LAYER 1 | Smart retry + immediate model switch | Timeout, rate limit |
| LAYER 2 | Fault-model mapping switch | Model not found, internal error |
| LAYER 3 | Request degradation | Context too long, content blocked |

## License

MIT
