from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.mg_gov_error_response import MgGovErrorResponse
    from .....models.mg_gov_o_data_response import MgGovODataResponse
    from .....models.rule_set_dto import RuleSetDto

class RuleSetsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /governance/environmentGroups/{groupId}/ruleSets
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new RuleSetsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/governance/environmentGroups/{groupId}/ruleSets?api-version={api%2Dversion}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[RuleSetsRequestBuilderGetQueryParameters]] = None) -> Optional[MgGovODataResponse]:
        """
        Returns the Rule Set for the given environment group.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[MgGovODataResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        from .....models.mg_gov_error_response import MgGovErrorResponse

        error_mapping: dict[str, type[ParsableFactory]] = {
            "400": MgGovErrorResponse,
            "401": MgGovErrorResponse,
            "403": MgGovErrorResponse,
            "500": MgGovErrorResponse,
        }
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.mg_gov_o_data_response import MgGovODataResponse

        return await self.request_adapter.send_async(request_info, MgGovODataResponse, error_mapping)
    
    async def post(self,body: RuleSetDto, request_configuration: Optional[RequestConfiguration[RuleSetsRequestBuilderPostQueryParameters]] = None) -> Optional[RuleSetDto]:
        """
        Creates the Rule Set for the environment group.
        param body: Rule Set data transfer object.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[RuleSetDto]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        from .....models.mg_gov_error_response import MgGovErrorResponse

        error_mapping: dict[str, type[ParsableFactory]] = {
            "400": MgGovErrorResponse,
            "401": MgGovErrorResponse,
            "403": MgGovErrorResponse,
            "500": MgGovErrorResponse,
        }
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.rule_set_dto import RuleSetDto

        return await self.request_adapter.send_async(request_info, RuleSetDto, error_mapping)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[RuleSetsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Returns the Rule Set for the given environment group.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_post_request_information(self,body: RuleSetDto, request_configuration: Optional[RequestConfiguration[RuleSetsRequestBuilderPostQueryParameters]] = None) -> RequestInformation:
        """
        Creates the Rule Set for the environment group.
        param body: Rule Set data transfer object.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> RuleSetsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: RuleSetsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return RuleSetsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class RuleSetsRequestBuilderGetQueryParameters():
        """
        Returns the Rule Set for the given environment group.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "api_version":
                return "api%2Dversion"
            return original_name
        
        # The API version.
        api_version: Optional[str] = None

    
    @dataclass
    class RuleSetsRequestBuilderGetRequestConfiguration(RequestConfiguration[RuleSetsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class RuleSetsRequestBuilderPostQueryParameters():
        """
        Creates the Rule Set for the environment group.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "api_version":
                return "api%2Dversion"
            return original_name
        
        # The API version.
        api_version: Optional[str] = None

    
    @dataclass
    class RuleSetsRequestBuilderPostRequestConfiguration(RequestConfiguration[RuleSetsRequestBuilderPostQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

