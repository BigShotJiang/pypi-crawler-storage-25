from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID
from warnings import warn

if TYPE_CHECKING:
    from ...models.mg_gov_error_response import MgGovErrorResponse
    from ...models.mg_gov_o_data_response import MgGovODataResponse
    from .item.with_rule_set_item_request_builder import WithRuleSetItemRequestBuilder

class RuleSetsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /governance/ruleSets
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new RuleSetsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/governance/ruleSets?api-version={api%2Dversion}{&%24expand*,%24filter*,%24select*,%24skiptoken*,%24top*}", path_parameters)
    
    def by_rule_set_id(self,rule_set_id: UUID) -> WithRuleSetItemRequestBuilder:
        """
        Gets an item from the ApiSdk.governance.ruleSets.item collection
        param rule_set_id: The unique identifier of the Rule Set.
        Returns: WithRuleSetItemRequestBuilder
        """
        if rule_set_id is None:
            raise TypeError("rule_set_id cannot be null.")
        from .item.with_rule_set_item_request_builder import WithRuleSetItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["ruleSetId"] = rule_set_id
        return WithRuleSetItemRequestBuilder(self.request_adapter, url_tpl_params)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[RuleSetsRequestBuilderGetQueryParameters]] = None) -> Optional[MgGovODataResponse]:
        """
        Returns all the Rule Sets under the given tenant with OData pagination support.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[MgGovODataResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        from ...models.mg_gov_error_response import MgGovErrorResponse

        error_mapping: dict[str, type[ParsableFactory]] = {
            "400": MgGovErrorResponse,
            "401": MgGovErrorResponse,
            "403": MgGovErrorResponse,
            "500": MgGovErrorResponse,
        }
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ...models.mg_gov_o_data_response import MgGovODataResponse

        return await self.request_adapter.send_async(request_info, MgGovODataResponse, error_mapping)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[RuleSetsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Returns all the Rule Sets under the given tenant with OData pagination support.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> RuleSetsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: RuleSetsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return RuleSetsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class RuleSetsRequestBuilderGetQueryParameters():
        """
        Returns all the Rule Sets under the given tenant with OData pagination support.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "api_version":
                return "api%2Dversion"
            if original_name == "expand":
                return "%24expand"
            if original_name == "filter":
                return "%24filter"
            if original_name == "select":
                return "%24select"
            if original_name == "skiptoken":
                return "%24skiptoken"
            if original_name == "top":
                return "%24top"
            return original_name
        
        # The API version.
        api_version: Optional[str] = None

        # OData expand query option.
        expand: Optional[str] = None

        # OData filter query option.
        filter: Optional[str] = None

        # OData select query option.
        select: Optional[str] = None

        # OData skip token for pagination.
        skiptoken: Optional[str] = None

        # OData top query option to limit results.
        top: Optional[int] = None

    
    @dataclass
    class RuleSetsRequestBuilderGetRequestConfiguration(RequestConfiguration[RuleSetsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

