from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID
from warnings import warn

if TYPE_CHECKING:
    from ...models.power_platform_request_snapshot_result_without_pages_user_per_flow_capacity_source_record import PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceRecord
    from .flow_context_summary.flow_context_summary_request_builder import FlowContextSummaryRequestBuilder
    from .tenant_context_summary.tenant_context_summary_request_builder import TenantContextSummaryRequestBuilder
    from .user_context_summary.user_context_summary_request_builder import UserContextSummaryRequestBuilder

class UserPerFlowCapacitySourceRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /licensing/UserPerFlowCapacitySource
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new UserPerFlowCapacitySourceRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/licensing/UserPerFlowCapacitySource?api-version={api%2Dversion}&startDate={startDate}{&endDate*,environmentId*,flowContext*,flowLicenseCategorization*,pageNumber*,pageSize*,resourceId*,userId*}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[UserPerFlowCapacitySourceRequestBuilderGetQueryParameters]] = None) -> Optional[PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceRecord]:
        """
        Get user per flow capacity source data with pagination and filtering options.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceRecord]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ...models.power_platform_request_snapshot_result_without_pages_user_per_flow_capacity_source_record import PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceRecord

        return await self.request_adapter.send_async(request_info, PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceRecord, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[UserPerFlowCapacitySourceRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Get user per flow capacity source data with pagination and filtering options.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> UserPerFlowCapacitySourceRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: UserPerFlowCapacitySourceRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return UserPerFlowCapacitySourceRequestBuilder(self.request_adapter, raw_url)
    
    @property
    def flow_context_summary(self) -> FlowContextSummaryRequestBuilder:
        """
        The FlowContextSummary property
        """
        from .flow_context_summary.flow_context_summary_request_builder import FlowContextSummaryRequestBuilder

        return FlowContextSummaryRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def tenant_context_summary(self) -> TenantContextSummaryRequestBuilder:
        """
        The TenantContextSummary property
        """
        from .tenant_context_summary.tenant_context_summary_request_builder import TenantContextSummaryRequestBuilder

        return TenantContextSummaryRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def user_context_summary(self) -> UserContextSummaryRequestBuilder:
        """
        The UserContextSummary property
        """
        from .user_context_summary.user_context_summary_request_builder import UserContextSummaryRequestBuilder

        return UserContextSummaryRequestBuilder(self.request_adapter, self.path_parameters)
    
    @dataclass
    class UserPerFlowCapacitySourceRequestBuilderGetQueryParameters():
        """
        Get user per flow capacity source data with pagination and filtering options.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "api_version":
                return "api%2Dversion"
            if original_name == "end_date":
                return "endDate"
            if original_name == "environment_id":
                return "environmentId"
            if original_name == "flow_context":
                return "flowContext"
            if original_name == "flow_license_categorization":
                return "flowLicenseCategorization"
            if original_name == "page_number":
                return "pageNumber"
            if original_name == "page_size":
                return "pageSize"
            if original_name == "resource_id":
                return "resourceId"
            if original_name == "start_date":
                return "startDate"
            if original_name == "user_id":
                return "userId"
            return original_name
        
        # The API version.
        api_version: Optional[str] = None

        # The end date for the query range. Defaults to current UTC time if not provided.
        end_date: Optional[datetime.datetime] = None

        # Filter by environment identifier.
        environment_id: Optional[UUID] = None

        # Filter by flow context.
        flow_context: Optional[str] = None

        # Filter by flow license categorization.
        flow_license_categorization: Optional[str] = None

        # The page number for pagination.
        page_number: Optional[int] = None

        # The page size for pagination.
        page_size: Optional[int] = None

        # Filter by resource identifier.
        resource_id: Optional[str] = None

        # The start date for the query range.
        start_date: Optional[datetime.datetime] = None

        # Filter by user identifier.
        user_id: Optional[str] = None

    
    @dataclass
    class UserPerFlowCapacitySourceRequestBuilderGetRequestConfiguration(RequestConfiguration[UserPerFlowCapacitySourceRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

