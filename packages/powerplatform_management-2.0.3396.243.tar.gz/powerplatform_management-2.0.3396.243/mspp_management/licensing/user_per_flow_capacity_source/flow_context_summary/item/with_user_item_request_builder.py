from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID
from warnings import warn

if TYPE_CHECKING:
    from .....models.power_platform_request_snapshot_result_without_pages_user_per_flow_capacity_source_flow_context_record import PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceFlowContextRecord

class WithUserItemRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /licensing/UserPerFlowCapacitySource/FlowContextSummary/{userId}
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new WithUserItemRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/licensing/UserPerFlowCapacitySource/FlowContextSummary/{userId}?api-version={api%2Dversion}&startDate={startDate}{&endDate*,environmentId*,pageNumber*,pageSize*}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[WithUserItemRequestBuilderGetQueryParameters]] = None) -> Optional[PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceFlowContextRecord]:
        """
        Get flow context summary for a specific user's per flow capacity source.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceFlowContextRecord]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.power_platform_request_snapshot_result_without_pages_user_per_flow_capacity_source_flow_context_record import PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceFlowContextRecord

        return await self.request_adapter.send_async(request_info, PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceFlowContextRecord, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[WithUserItemRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Get flow context summary for a specific user's per flow capacity source.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> WithUserItemRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: WithUserItemRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return WithUserItemRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class WithUserItemRequestBuilderGetQueryParameters():
        """
        Get flow context summary for a specific user's per flow capacity source.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "api_version":
                return "api%2Dversion"
            if original_name == "end_date":
                return "endDate"
            if original_name == "environment_id":
                return "environmentId"
            if original_name == "page_number":
                return "pageNumber"
            if original_name == "page_size":
                return "pageSize"
            if original_name == "start_date":
                return "startDate"
            return original_name
        
        # The API version.
        api_version: Optional[str] = None

        # The end date for the query range. Defaults to current UTC time if not provided.
        end_date: Optional[datetime.datetime] = None

        # Filter by environment identifier.
        environment_id: Optional[UUID] = None

        # The page number for pagination.
        page_number: Optional[int] = None

        # The page size for pagination.
        page_size: Optional[int] = None

        # The start date for the query range.
        start_date: Optional[datetime.datetime] = None

    
    @dataclass
    class WithUserItemRequestBuilderGetRequestConfiguration(RequestConfiguration[WithUserItemRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

