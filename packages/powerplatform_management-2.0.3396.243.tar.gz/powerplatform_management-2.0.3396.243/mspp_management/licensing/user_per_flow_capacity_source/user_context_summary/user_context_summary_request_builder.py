from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID
from warnings import warn

if TYPE_CHECKING:
    from ....models.power_platform_request_snapshot_result_without_pages_user_per_flow_capacity_source_user_context_record import PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceUserContextRecord
    from .item.with_user_item_request_builder import WithUserItemRequestBuilder

class UserContextSummaryRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /licensing/UserPerFlowCapacitySource/UserContextSummary
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new UserContextSummaryRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/licensing/UserPerFlowCapacitySource/UserContextSummary?api-version={api%2Dversion}&startDate={startDate}{&endDate*,environmentId*,pageNumber*,pageSize*}", path_parameters)
    
    def by_user_id(self,user_id: UUID) -> WithUserItemRequestBuilder:
        """
        Gets an item from the ApiSdk.licensing.UserPerFlowCapacitySource.UserContextSummary.item collection
        param user_id: The user identifier.
        Returns: WithUserItemRequestBuilder
        """
        if user_id is None:
            raise TypeError("user_id cannot be null.")
        from .item.with_user_item_request_builder import WithUserItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["userId"] = user_id
        return WithUserItemRequestBuilder(self.request_adapter, url_tpl_params)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[UserContextSummaryRequestBuilderGetQueryParameters]] = None) -> Optional[PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceUserContextRecord]:
        """
        Get the user per flow capacity source user context summary.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceUserContextRecord]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ....models.power_platform_request_snapshot_result_without_pages_user_per_flow_capacity_source_user_context_record import PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceUserContextRecord

        return await self.request_adapter.send_async(request_info, PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceUserContextRecord, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[UserContextSummaryRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Get the user per flow capacity source user context summary.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> UserContextSummaryRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: UserContextSummaryRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return UserContextSummaryRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class UserContextSummaryRequestBuilderGetQueryParameters():
        """
        Get the user per flow capacity source user context summary.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "api_version":
                return "api%2Dversion"
            if original_name == "end_date":
                return "endDate"
            if original_name == "environment_id":
                return "environmentId"
            if original_name == "page_number":
                return "pageNumber"
            if original_name == "page_size":
                return "pageSize"
            if original_name == "start_date":
                return "startDate"
            return original_name
        
        # The API version.
        api_version: Optional[str] = None

        # The end date for the query range. Defaults to current UTC time if not provided.
        end_date: Optional[datetime.datetime] = None

        # Filter by environment identifier.
        environment_id: Optional[UUID] = None

        # The page number for pagination.
        page_number: Optional[int] = None

        # The page size for pagination.
        page_size: Optional[int] = None

        # The start date for the query range.
        start_date: Optional[datetime.datetime] = None

    
    @dataclass
    class UserContextSummaryRequestBuilderGetRequestConfiguration(RequestConfiguration[UserContextSummaryRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

