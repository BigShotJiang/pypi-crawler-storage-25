from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .connections.connections_request_builder import ConnectionsRequestBuilder
    from .connectors.connectors_request_builder import ConnectorsRequestBuilder

class WithEnvironmentItemRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /connectivity/environments/{environmentId}
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new WithEnvironmentItemRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/connectivity/environments/{environmentId}", path_parameters)
    
    @property
    def connections(self) -> ConnectionsRequestBuilder:
        """
        The connections property
        """
        from .connections.connections_request_builder import ConnectionsRequestBuilder

        return ConnectionsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def connectors(self) -> ConnectorsRequestBuilder:
        """
        The connectors property
        """
        from .connectors.connectors_request_builder import ConnectorsRequestBuilder

        return ConnectorsRequestBuilder(self.request_adapter, self.path_parameters)
    

