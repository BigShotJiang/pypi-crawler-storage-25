from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .........models.test_set_collection import TestSetCollection
    from .item.with_test_set_item_request_builder import WithTestSetItemRequestBuilder

class TestsetsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /copilotstudio/environments/{EnvironmentId}/bots/{BotId}/api/makerevaluation/testsets
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new TestsetsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/copilotstudio/environments/{EnvironmentId}/bots/{BotId}/api/makerevaluation/testsets?api-version={api%2Dversion}", path_parameters)
    
    def by_test_set_id(self,test_set_id: str) -> WithTestSetItemRequestBuilder:
        """
        Gets an item from the ApiSdk.copilotstudio.environments.item.bots.item.api.makerevaluation.testsets.item collection
        param test_set_id: The test set ID.
        Returns: WithTestSetItemRequestBuilder
        """
        if test_set_id is None:
            raise TypeError("test_set_id cannot be null.")
        from .item.with_test_set_item_request_builder import WithTestSetItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["TestSetId"] = test_set_id
        return WithTestSetItemRequestBuilder(self.request_adapter, url_tpl_params)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[TestsetsRequestBuilderGetQueryParameters]] = None) -> Optional[TestSetCollection]:
        """
        Retrieves the list of test sets for a bot in a specified environment.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[TestSetCollection]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .........models.test_set_collection import TestSetCollection

        return await self.request_adapter.send_async(request_info, TestSetCollection, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[TestsetsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Retrieves the list of test sets for a bot in a specified environment.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> TestsetsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: TestsetsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return TestsetsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class TestsetsRequestBuilderGetQueryParameters():
        """
        Retrieves the list of test sets for a bot in a specified environment.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "api_version":
                return "api%2Dversion"
            return original_name
        
        # The API version.
        api_version: Optional[str] = None

    
    @dataclass
    class TestsetsRequestBuilderGetRequestConfiguration(RequestConfiguration[TestsetsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

