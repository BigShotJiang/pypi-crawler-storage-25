from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from ......models.create_environment_request_linked_metadata import CreateEnvironmentRequestLinkedMetadata
    from ......models.operation_execution_result import OperationExecutionResult
    from ......models.validation_response import ValidationResponse

class LinkRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /environmentmanagement/provisioning/environments/{environmentId}/link
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new LinkRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/environmentmanagement/provisioning/environments/{environmentId}/link?api-version={api%2Dversion}", path_parameters)
    
    async def patch(self,body: CreateEnvironmentRequestLinkedMetadata, request_configuration: Optional[RequestConfiguration[LinkRequestBuilderPatchQueryParameters]] = None) -> Optional[OperationExecutionResult]:
        """
        Links a Dataverse instance to an existing environment.
        param body: Metadata for the linked Dataverse environment.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[OperationExecutionResult]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_patch_request_information(
            body, request_configuration
        )
        from ......models.validation_response import ValidationResponse

        error_mapping: dict[str, type[ParsableFactory]] = {
            "400": ValidationResponse,
        }
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ......models.operation_execution_result import OperationExecutionResult

        return await self.request_adapter.send_async(request_info, OperationExecutionResult, error_mapping)
    
    def to_patch_request_information(self,body: CreateEnvironmentRequestLinkedMetadata, request_configuration: Optional[RequestConfiguration[LinkRequestBuilderPatchQueryParameters]] = None) -> RequestInformation:
        """
        Links a Dataverse instance to an existing environment.
        param body: Metadata for the linked Dataverse environment.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.PATCH, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json, text/plain;q=0.9")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> LinkRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: LinkRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return LinkRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class LinkRequestBuilderPatchQueryParameters():
        """
        Links a Dataverse instance to an existing environment.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "api_version":
                return "api%2Dversion"
            return original_name
        
        # The API version.
        api_version: Optional[str] = None

    
    @dataclass
    class LinkRequestBuilderPatchRequestConfiguration(RequestConfiguration[LinkRequestBuilderPatchQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

