from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .create.create_request_builder import CreateRequestBuilder
    from .environments.environments_request_builder import EnvironmentsRequestBuilder
    from .locations.locations_request_builder import LocationsRequestBuilder

class ProvisioningRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /environmentmanagement/provisioning
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ProvisioningRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/environmentmanagement/provisioning", path_parameters)
    
    @property
    def create(self) -> CreateRequestBuilder:
        """
        The create property
        """
        from .create.create_request_builder import CreateRequestBuilder

        return CreateRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def environments(self) -> EnvironmentsRequestBuilder:
        """
        The environments property
        """
        from .environments.environments_request_builder import EnvironmentsRequestBuilder

        return EnvironmentsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def locations(self) -> LocationsRequestBuilder:
        """
        The locations property
        """
        from .locations.locations_request_builder import LocationsRequestBuilder

        return LocationsRequestBuilder(self.request_adapter, self.path_parameters)
    

