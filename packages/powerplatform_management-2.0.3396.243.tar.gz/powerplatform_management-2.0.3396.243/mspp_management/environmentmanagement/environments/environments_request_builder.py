from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from ...models.environment_list import EnvironmentList
    from .item.environment_item_request_builder import EnvironmentItemRequestBuilder

class EnvironmentsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /environmentmanagement/environments
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new EnvironmentsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/environmentmanagement/environments?api-version={api%2Dversion}{&%24filter*,%24orderby*,%24select*,%24skip*,%24top*,ids*}", path_parameters)
    
    def by_environment_id(self,environment_id: str) -> EnvironmentItemRequestBuilder:
        """
        Gets an item from the ApiSdk.environmentmanagement.environments.item collection
        param environment_id: The environment ID.
        Returns: EnvironmentItemRequestBuilder
        """
        if environment_id is None:
            raise TypeError("environment_id cannot be null.")
        from .item.environment_item_request_builder import EnvironmentItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["environment%2Did"] = environment_id
        return EnvironmentItemRequestBuilder(self.request_adapter, url_tpl_params)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[EnvironmentsRequestBuilderGetQueryParameters]] = None) -> Optional[EnvironmentList]:
        """
        Returns a list of environments available for the authenticated user.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[EnvironmentList]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ...models.environment_list import EnvironmentList

        return await self.request_adapter.send_async(request_info, EnvironmentList, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[EnvironmentsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Returns a list of environments available for the authenticated user.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> EnvironmentsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: EnvironmentsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return EnvironmentsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class EnvironmentsRequestBuilderGetQueryParameters():
        """
        Returns a list of environments available for the authenticated user.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "api_version":
                return "api%2Dversion"
            if original_name == "filter":
                return "%24filter"
            if original_name == "orderby":
                return "%24orderby"
            if original_name == "select":
                return "%24select"
            if original_name == "skip":
                return "%24skip"
            if original_name == "top":
                return "%24top"
            if original_name == "ids":
                return "ids"
            return original_name
        
        # The API version.
        api_version: Optional[str] = None

        # OData filter expression to restrict the set of environments returned. Supported filter properties include `dataverseId`, `type`, `geo`, `state`, `environmentGroupId`, and `domainName`.
        filter: Optional[str] = None

        # Comma-separated list of environment IDs to retrieve. When specified, only environments matching these IDs are returned.
        ids: Optional[list[str]] = None

        # OData order-by expression for sorting the results.
        orderby: Optional[str] = None

        # Comma-separated list of properties to include in the response.
        select: Optional[str] = None

        # Number of environments to skip before returning results.
        skip: Optional[int] = None

        # Maximum number of environments to return.
        top: Optional[int] = None

    
    @dataclass
    class EnvironmentsRequestBuilderGetRequestConfiguration(RequestConfiguration[EnvironmentsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

