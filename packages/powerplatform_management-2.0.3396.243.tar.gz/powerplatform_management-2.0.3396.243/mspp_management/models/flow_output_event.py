from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .action_event_base import ActionEventBase
    from .flow_output_properties import FlowOutputProperties

from .action_event_base import ActionEventBase

@dataclass
class FlowOutputEvent(ActionEventBase, Parsable):
    """
    Event representing the final output of the flow run.
    """
    # Properties of a flow output event.
    properties: Optional[FlowOutputProperties] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> FlowOutputEvent:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: FlowOutputEvent
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return FlowOutputEvent()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .action_event_base import ActionEventBase
        from .flow_output_properties import FlowOutputProperties

        from .action_event_base import ActionEventBase
        from .flow_output_properties import FlowOutputProperties

        fields: dict[str, Callable[[Any], None]] = {
            "properties": lambda n : setattr(self, 'properties', n.get_object_value(FlowOutputProperties)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("properties", self.properties)
    

