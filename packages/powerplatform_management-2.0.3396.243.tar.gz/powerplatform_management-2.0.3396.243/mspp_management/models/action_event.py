from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .action_suggestion_request_event import ActionSuggestionRequestEvent
    from .action_validation_response_event import ActionValidationResponseEvent
    from .connector_action_end_event import ConnectorActionEndEvent
    from .connector_action_start_event import ConnectorActionStartEvent
    from .flow_output_event import FlowOutputEvent
    from .thought_event import ThoughtEvent
    from .trigger_event import TriggerEvent

@dataclass
class ActionEvent(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes ActionSuggestionRequestEvent, ActionValidationResponseEvent, ConnectorActionEndEvent, ConnectorActionStartEvent, FlowOutputEvent, ThoughtEvent, TriggerEvent
    """
    # Composed type representation for type ActionSuggestionRequestEvent
    action_suggestion_request_event: Optional[ActionSuggestionRequestEvent] = None
    # Composed type representation for type ActionValidationResponseEvent
    action_validation_response_event: Optional[ActionValidationResponseEvent] = None
    # Composed type representation for type ConnectorActionEndEvent
    connector_action_end_event: Optional[ConnectorActionEndEvent] = None
    # Composed type representation for type ConnectorActionStartEvent
    connector_action_start_event: Optional[ConnectorActionStartEvent] = None
    # Composed type representation for type FlowOutputEvent
    flow_output_event: Optional[FlowOutputEvent] = None
    # Composed type representation for type ThoughtEvent
    thought_event: Optional[ThoughtEvent] = None
    # Composed type representation for type TriggerEvent
    trigger_event: Optional[TriggerEvent] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ActionEvent:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ActionEvent
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("type")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = ActionEvent()
        if mapping_value and mapping_value.casefold() == "ActionSuggestionRequest".casefold():
            from .action_suggestion_request_event import ActionSuggestionRequestEvent

            result.action_suggestion_request_event = ActionSuggestionRequestEvent()
        elif mapping_value and mapping_value.casefold() == "ActionValidationResponse".casefold():
            from .action_validation_response_event import ActionValidationResponseEvent

            result.action_validation_response_event = ActionValidationResponseEvent()
        elif mapping_value and mapping_value.casefold() == "ConnectorActionEnd".casefold():
            from .connector_action_end_event import ConnectorActionEndEvent

            result.connector_action_end_event = ConnectorActionEndEvent()
        elif mapping_value and mapping_value.casefold() == "ConnectorActionStart".casefold():
            from .connector_action_start_event import ConnectorActionStartEvent

            result.connector_action_start_event = ConnectorActionStartEvent()
        elif mapping_value and mapping_value.casefold() == "Output".casefold():
            from .flow_output_event import FlowOutputEvent

            result.flow_output_event = FlowOutputEvent()
        elif mapping_value and mapping_value.casefold() == "Thought".casefold():
            from .thought_event import ThoughtEvent

            result.thought_event = ThoughtEvent()
        elif mapping_value and mapping_value.casefold() == "Trigger".casefold():
            from .trigger_event import TriggerEvent

            result.trigger_event = TriggerEvent()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .action_suggestion_request_event import ActionSuggestionRequestEvent
        from .action_validation_response_event import ActionValidationResponseEvent
        from .connector_action_end_event import ConnectorActionEndEvent
        from .connector_action_start_event import ConnectorActionStartEvent
        from .flow_output_event import FlowOutputEvent
        from .thought_event import ThoughtEvent
        from .trigger_event import TriggerEvent

        if self.action_suggestion_request_event:
            return self.action_suggestion_request_event.get_field_deserializers()
        if self.action_validation_response_event:
            return self.action_validation_response_event.get_field_deserializers()
        if self.connector_action_end_event:
            return self.connector_action_end_event.get_field_deserializers()
        if self.connector_action_start_event:
            return self.connector_action_start_event.get_field_deserializers()
        if self.flow_output_event:
            return self.flow_output_event.get_field_deserializers()
        if self.thought_event:
            return self.thought_event.get_field_deserializers()
        if self.trigger_event:
            return self.trigger_event.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.action_suggestion_request_event:
            writer.write_object_value(None, self.action_suggestion_request_event)
        elif self.action_validation_response_event:
            writer.write_object_value(None, self.action_validation_response_event)
        elif self.connector_action_end_event:
            writer.write_object_value(None, self.connector_action_end_event)
        elif self.connector_action_start_event:
            writer.write_object_value(None, self.connector_action_start_event)
        elif self.flow_output_event:
            writer.write_object_value(None, self.flow_output_event)
        elif self.thought_event:
            writer.write_object_value(None, self.thought_event)
        elif self.trigger_event:
            writer.write_object_value(None, self.trigger_event)
    

