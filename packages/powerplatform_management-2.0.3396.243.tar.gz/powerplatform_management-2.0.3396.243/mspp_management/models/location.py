from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class Location(Parsable):
    """
    Represents a location/geo for environment provisioning.
    """
    # Whether database provisioning is allowed.
    can_provision_database: Optional[bool] = None
    # The location code.
    code: Optional[str] = None
    # The display name.
    display_name: Optional[str] = None
    # Whether this is the default location.
    is_default: Optional[bool] = None
    # Whether this location is disabled.
    is_disabled: Optional[bool] = None
    # The location name.
    name: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Location:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Location
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Location()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "canProvisionDatabase": lambda n : setattr(self, 'can_provision_database', n.get_bool_value()),
            "code": lambda n : setattr(self, 'code', n.get_str_value()),
            "displayName": lambda n : setattr(self, 'display_name', n.get_str_value()),
            "isDefault": lambda n : setattr(self, 'is_default', n.get_bool_value()),
            "isDisabled": lambda n : setattr(self, 'is_disabled', n.get_bool_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("canProvisionDatabase", self.can_provision_database)
        writer.write_str_value("code", self.code)
        writer.write_str_value("displayName", self.display_name)
        writer.write_bool_value("isDefault", self.is_default)
        writer.write_bool_value("isDisabled", self.is_disabled)
        writer.write_str_value("name", self.name)
    

