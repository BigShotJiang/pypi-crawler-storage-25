from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .base64_thought_image_format import Base64ThoughtImage_format

@dataclass
class Base64ThoughtImage(AdditionalDataHolder, Parsable):
    """
    A base64-encoded image associated with a thought.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # MIME type of the image.
    content_type: Optional[str] = None
    # Base64-encoded image data.
    data: Optional[str] = None
    # Encoding format. Always base64.
    format: Optional[Base64ThoughtImage_format] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Base64ThoughtImage:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Base64ThoughtImage
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Base64ThoughtImage()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .base64_thought_image_format import Base64ThoughtImage_format

        from .base64_thought_image_format import Base64ThoughtImage_format

        fields: dict[str, Callable[[Any], None]] = {
            "contentType": lambda n : setattr(self, 'content_type', n.get_str_value()),
            "data": lambda n : setattr(self, 'data', n.get_str_value()),
            "format": lambda n : setattr(self, 'format', n.get_enum_value(Base64ThoughtImage_format)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("contentType", self.content_type)
        writer.write_str_value("data", self.data)
        writer.write_enum_value("format", self.format)
        writer.write_additional_data_value(self.additional_data)
    

