from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .conversation_transcript_message import ConversationTranscriptMessage
    from .conversation_transcript_tool import ConversationTranscriptTool

@dataclass
class ConversationTranscriptRequest(AdditionalDataHolder, Parsable):
    """
    The request portion of a conversation transcript.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Messages in the conversation request.
    messages: Optional[list[ConversationTranscriptMessage]] = None
    # The tool choice strategy.
    tool_choice: Optional[str] = None
    # Tools available during the conversation.
    tools: Optional[list[ConversationTranscriptTool]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConversationTranscriptRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConversationTranscriptRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConversationTranscriptRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .conversation_transcript_message import ConversationTranscriptMessage
        from .conversation_transcript_tool import ConversationTranscriptTool

        from .conversation_transcript_message import ConversationTranscriptMessage
        from .conversation_transcript_tool import ConversationTranscriptTool

        fields: dict[str, Callable[[Any], None]] = {
            "messages": lambda n : setattr(self, 'messages', n.get_collection_of_object_values(ConversationTranscriptMessage)),
            "toolChoice": lambda n : setattr(self, 'tool_choice', n.get_str_value()),
            "tools": lambda n : setattr(self, 'tools', n.get_collection_of_object_values(ConversationTranscriptTool)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("messages", self.messages)
        writer.write_str_value("toolChoice", self.tool_choice)
        writer.write_collection_of_object_values("tools", self.tools)
        writer.write_additional_data_value(self.additional_data)
    

