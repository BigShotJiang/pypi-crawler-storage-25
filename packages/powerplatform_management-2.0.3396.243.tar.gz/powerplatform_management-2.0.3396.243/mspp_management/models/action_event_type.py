from enum import Enum

class ActionEventType(str, Enum):
    NotSpecified = "NotSpecified",
    Trigger = "Trigger",
    Thought = "Thought",
    ConnectorActionStart = "ConnectorActionStart",
    ConnectorActionEnd = "ConnectorActionEnd",
    ActionValidationResponse = "ActionValidationResponse",
    ActionSuggestionRequest = "ActionSuggestionRequest",
    Output = "Output",

