from enum import Enum

class FinOpsUpdateCadence(str, Enum):
    EveryUpdate = "EveryUpdate",
    EveryOtherUpdate = "EveryOtherUpdate",
    Regulated = "Regulated",

