from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class UserPerFlowCapacitySourceTenantContextSummaryRecord(Parsable):
    """
    Tenant-level context summary for per flow capacity source.
    """
    # Number of users who have exceeded their capacity limits.
    count_of_users_exceeding_capacity: Optional[int] = None
    # Number of users who are within their capacity limits.
    count_of_users_in_compliance: Optional[int] = None
    # Number of users without any license.
    count_of_users_without_a_license: Optional[int] = None
    # Number of users using premium features without a premium license.
    count_of_users_without_premium_license_using_premium_features: Optional[int] = None
    # The context in which flows were executed.
    flow_context: Optional[str] = None
    # The tenant identifier.
    tenant_id: Optional[UUID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> UserPerFlowCapacitySourceTenantContextSummaryRecord:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: UserPerFlowCapacitySourceTenantContextSummaryRecord
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return UserPerFlowCapacitySourceTenantContextSummaryRecord()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "countOfUsersExceedingCapacity": lambda n : setattr(self, 'count_of_users_exceeding_capacity', n.get_int_value()),
            "countOfUsersInCompliance": lambda n : setattr(self, 'count_of_users_in_compliance', n.get_int_value()),
            "countOfUsersWithoutALicense": lambda n : setattr(self, 'count_of_users_without_a_license', n.get_int_value()),
            "countOfUsersWithoutPremiumLicenseUsingPremiumFeatures": lambda n : setattr(self, 'count_of_users_without_premium_license_using_premium_features', n.get_int_value()),
            "flowContext": lambda n : setattr(self, 'flow_context', n.get_str_value()),
            "tenantId": lambda n : setattr(self, 'tenant_id', n.get_uuid_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("countOfUsersExceedingCapacity", self.count_of_users_exceeding_capacity)
        writer.write_int_value("countOfUsersInCompliance", self.count_of_users_in_compliance)
        writer.write_int_value("countOfUsersWithoutALicense", self.count_of_users_without_a_license)
        writer.write_int_value("countOfUsersWithoutPremiumLicenseUsingPremiumFeatures", self.count_of_users_without_premium_license_using_premium_features)
        writer.write_str_value("flowContext", self.flow_context)
        writer.write_uuid_value("tenantId", self.tenant_id)
    

