from enum import Enum

class MgGovFilterType(str, Enum):
    NotSpecified = "NotSpecified",
    Include = "Include",
    Exclude = "Exclude",

