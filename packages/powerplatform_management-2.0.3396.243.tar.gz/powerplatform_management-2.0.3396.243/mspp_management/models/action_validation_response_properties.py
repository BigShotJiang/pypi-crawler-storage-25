from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .action_response import ActionResponse

@dataclass
class ActionValidationResponseProperties(AdditionalDataHolder, Parsable):
    """
    Properties of an action validation response event.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # User response to an action validation request.
    response: Optional[ActionResponse] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ActionValidationResponseProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ActionValidationResponseProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ActionValidationResponseProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .action_response import ActionResponse

        from .action_response import ActionResponse

        fields: dict[str, Callable[[Any], None]] = {
            "response": lambda n : setattr(self, 'response', n.get_enum_value(ActionResponse)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("response", self.response)
        writer.write_additional_data_value(self.additional_data)
    

