from enum import Enum

class Base64ThoughtImage_format(str, Enum):
    Base64 = "base64",

