from enum import Enum

class ProtectionLevel(str, Enum):
    NotSpecified = "NotSpecified",
    Basic = "Basic",
    Standard = "Standard",

