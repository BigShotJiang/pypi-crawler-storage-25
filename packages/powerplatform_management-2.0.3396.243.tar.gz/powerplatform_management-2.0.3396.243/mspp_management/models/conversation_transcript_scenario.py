from enum import Enum

class ConversationTranscriptScenario(str, Enum):
    WorkflowsAgentRuntime = "WorkflowsAgentRuntime",
    WorkflowsAgentAuthoring = "WorkflowsAgentAuthoring",

