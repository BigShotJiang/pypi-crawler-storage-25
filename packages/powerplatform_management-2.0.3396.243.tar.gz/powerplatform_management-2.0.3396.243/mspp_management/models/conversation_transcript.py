from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .conversation_transcript_request import ConversationTranscriptRequest
    from .conversation_transcript_response import ConversationTranscriptResponse
    from .conversation_transcript_system_metadata import ConversationTranscriptSystemMetadata

@dataclass
class ConversationTranscript(AdditionalDataHolder, Parsable):
    """
    A single conversation transcript record.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The user object ID.
    object_id: Optional[str] = None
    # The request portion of a conversation transcript.
    request: Optional[ConversationTranscriptRequest] = None
    # Request correlation ID for tracing.
    request_correlation_id: Optional[str] = None
    # The response portion of a conversation transcript.
    response: Optional[ConversationTranscriptResponse] = None
    # Service request correlation ID for tracing.
    service_request_correlation_id: Optional[str] = None
    # System metadata for a conversation transcript.
    system_metadata: Optional[ConversationTranscriptSystemMetadata] = None
    # The tenant ID.
    tenant_id: Optional[str] = None
    # Timestamp of the conversation.
    timestamp: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConversationTranscript:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConversationTranscript
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConversationTranscript()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .conversation_transcript_request import ConversationTranscriptRequest
        from .conversation_transcript_response import ConversationTranscriptResponse
        from .conversation_transcript_system_metadata import ConversationTranscriptSystemMetadata

        from .conversation_transcript_request import ConversationTranscriptRequest
        from .conversation_transcript_response import ConversationTranscriptResponse
        from .conversation_transcript_system_metadata import ConversationTranscriptSystemMetadata

        fields: dict[str, Callable[[Any], None]] = {
            "objectId": lambda n : setattr(self, 'object_id', n.get_str_value()),
            "request": lambda n : setattr(self, 'request', n.get_object_value(ConversationTranscriptRequest)),
            "requestCorrelationId": lambda n : setattr(self, 'request_correlation_id', n.get_str_value()),
            "response": lambda n : setattr(self, 'response', n.get_object_value(ConversationTranscriptResponse)),
            "serviceRequestCorrelationId": lambda n : setattr(self, 'service_request_correlation_id', n.get_str_value()),
            "systemMetadata": lambda n : setattr(self, 'system_metadata', n.get_object_value(ConversationTranscriptSystemMetadata)),
            "tenantId": lambda n : setattr(self, 'tenant_id', n.get_str_value()),
            "timestamp": lambda n : setattr(self, 'timestamp', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("objectId", self.object_id)
        writer.write_object_value("request", self.request)
        writer.write_str_value("requestCorrelationId", self.request_correlation_id)
        writer.write_object_value("response", self.response)
        writer.write_str_value("serviceRequestCorrelationId", self.service_request_correlation_id)
        writer.write_object_value("systemMetadata", self.system_metadata)
        writer.write_str_value("tenantId", self.tenant_id)
        writer.write_datetime_value("timestamp", self.timestamp)
        writer.write_additional_data_value(self.additional_data)
    

