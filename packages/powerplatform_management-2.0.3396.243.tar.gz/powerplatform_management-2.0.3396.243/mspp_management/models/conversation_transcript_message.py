from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .conversation_transcript_tool_call import ConversationTranscriptToolCall

@dataclass
class ConversationTranscriptMessage(AdditionalDataHolder, Parsable):
    """
    A message in the conversation.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Text content of the message.
    content: Optional[str] = None
    # Whether this message contains customer content.
    is_customer_content: Optional[bool] = None
    # Name of the message sender, if applicable.
    name: Optional[str] = None
    # Role of the message sender (e.g. user, assistant, system, tool).
    role: Optional[str] = None
    # ID of the tool call this message is responding to.
    tool_call_id: Optional[str] = None
    # Tool calls made in this message.
    tool_calls: Optional[list[ConversationTranscriptToolCall]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConversationTranscriptMessage:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConversationTranscriptMessage
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConversationTranscriptMessage()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .conversation_transcript_tool_call import ConversationTranscriptToolCall

        from .conversation_transcript_tool_call import ConversationTranscriptToolCall

        fields: dict[str, Callable[[Any], None]] = {
            "content": lambda n : setattr(self, 'content', n.get_str_value()),
            "isCustomerContent": lambda n : setattr(self, 'is_customer_content', n.get_bool_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "role": lambda n : setattr(self, 'role', n.get_str_value()),
            "toolCallId": lambda n : setattr(self, 'tool_call_id', n.get_str_value()),
            "toolCalls": lambda n : setattr(self, 'tool_calls', n.get_collection_of_object_values(ConversationTranscriptToolCall)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("content", self.content)
        writer.write_bool_value("isCustomerContent", self.is_customer_content)
        writer.write_str_value("name", self.name)
        writer.write_str_value("role", self.role)
        writer.write_str_value("toolCallId", self.tool_call_id)
        writer.write_collection_of_object_values("toolCalls", self.tool_calls)
        writer.write_additional_data_value(self.additional_data)
    

