from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ConvertTrialToProductionRequest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Enable Content Delivery Network (CDN) for the website
    enable_c_d_n: Optional[bool] = None
    # Enable Web Application Firewall (WAF) for the website
    enable_w_a_f: Optional[bool] = None
    # Use Dynamics 365 Portal Add-On License for the website
    use_dynamics365_portal_add_on_license: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConvertTrialToProductionRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConvertTrialToProductionRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConvertTrialToProductionRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "EnableCDN": lambda n : setattr(self, 'enable_c_d_n', n.get_bool_value()),
            "EnableWAF": lambda n : setattr(self, 'enable_w_a_f', n.get_bool_value()),
            "UseDynamics365PortalAddOnLicense": lambda n : setattr(self, 'use_dynamics365_portal_add_on_license', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("EnableCDN", self.enable_c_d_n)
        writer.write_bool_value("EnableWAF", self.enable_w_a_f)
        writer.write_bool_value("UseDynamics365PortalAddOnLicense", self.use_dynamics365_portal_add_on_license)
        writer.write_additional_data_value(self.additional_data)
    

