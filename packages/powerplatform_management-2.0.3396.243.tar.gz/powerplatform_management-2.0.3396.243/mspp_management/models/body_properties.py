from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .content_type_category import ContentTypeCategory

@dataclass
class BodyProperties(AdditionalDataHolder, Parsable):
    """
    Body content of an action output.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Category of the body content type.
    category: Optional[ContentTypeCategory] = None
    # Length of the body content in bytes.
    content_length: Optional[int] = None
    # MIME type of the body content.
    content_type: Optional[str] = None
    # File name, if the body represents a file.
    file_name: Optional[str] = None
    # URL to retrieve the body content if not inlined.
    value_link: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> BodyProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: BodyProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return BodyProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .content_type_category import ContentTypeCategory

        from .content_type_category import ContentTypeCategory

        fields: dict[str, Callable[[Any], None]] = {
            "category": lambda n : setattr(self, 'category', n.get_enum_value(ContentTypeCategory)),
            "contentLength": lambda n : setattr(self, 'content_length', n.get_int_value()),
            "contentType": lambda n : setattr(self, 'content_type', n.get_str_value()),
            "fileName": lambda n : setattr(self, 'file_name', n.get_str_value()),
            "valueLink": lambda n : setattr(self, 'value_link', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("category", self.category)
        writer.write_int_value("contentLength", self.content_length)
        writer.write_str_value("contentType", self.content_type)
        writer.write_str_value("fileName", self.file_name)
        writer.write_str_value("valueLink", self.value_link)
        writer.write_additional_data_value(self.additional_data)
    

