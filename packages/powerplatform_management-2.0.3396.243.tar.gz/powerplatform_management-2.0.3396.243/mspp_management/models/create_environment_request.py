from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .create_environment_request_billing_policy import CreateEnvironmentRequestBillingPolicy
    from .create_environment_request_cluster import CreateEnvironmentRequestCluster
    from .create_environment_request_fin_ops_metadata import CreateEnvironmentRequestFinOpsMetadata
    from .create_environment_request_governance import CreateEnvironmentRequestGovernance
    from .create_environment_request_linked_metadata import CreateEnvironmentRequestLinkedMetadata
    from .create_environment_request_parent_group import CreateEnvironmentRequestParentGroup
    from .environment_sku import EnvironmentSku
    from .user_identity import UserIdentity

@dataclass
class CreateEnvironmentRequest(Parsable):
    """
    Request model for provisioning a new environment.
    """
    # Billing policy for the environment.
    billing_policy: Optional[CreateEnvironmentRequestBillingPolicy] = None
    # Cluster configuration.
    cluster: Optional[CreateEnvironmentRequestCluster] = None
    # Microsoft 365 Group Id to be linked to the Teams environment during provisioning. This property is not applicable for non-Teams environments.
    connected_group_id_for_teams_environment: Optional[str] = None
    # The type of database to create (e.g., CommonDataService).
    database_type: Optional[str] = None
    # An optional description for the environment.
    description: Optional[str] = None
    # The display name of the environment.
    display_name: Optional[str] = None
    # The environment SKU.
    environment_sku: Optional[EnvironmentSku] = None
    # FinOps metadata for environment provisioning.
    fin_ops_metadata: Optional[CreateEnvironmentRequestFinOpsMetadata] = None
    # Governance configuration.
    governance_configuration: Optional[CreateEnvironmentRequestGovernance] = None
    # Metadata for the linked Dataverse environment.
    linked_environment_metadata: Optional[CreateEnvironmentRequestLinkedMetadata] = None
    # The location where the environment will be provisioned.
    location: Optional[str] = None
    # Parent environment group.
    parent_environment_group: Optional[CreateEnvironmentRequestParentGroup] = None
    # Represents the identity of a user.
    used_by: Optional[UserIdentity] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CreateEnvironmentRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CreateEnvironmentRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CreateEnvironmentRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .create_environment_request_billing_policy import CreateEnvironmentRequestBillingPolicy
        from .create_environment_request_cluster import CreateEnvironmentRequestCluster
        from .create_environment_request_fin_ops_metadata import CreateEnvironmentRequestFinOpsMetadata
        from .create_environment_request_governance import CreateEnvironmentRequestGovernance
        from .create_environment_request_linked_metadata import CreateEnvironmentRequestLinkedMetadata
        from .create_environment_request_parent_group import CreateEnvironmentRequestParentGroup
        from .environment_sku import EnvironmentSku
        from .user_identity import UserIdentity

        from .create_environment_request_billing_policy import CreateEnvironmentRequestBillingPolicy
        from .create_environment_request_cluster import CreateEnvironmentRequestCluster
        from .create_environment_request_fin_ops_metadata import CreateEnvironmentRequestFinOpsMetadata
        from .create_environment_request_governance import CreateEnvironmentRequestGovernance
        from .create_environment_request_linked_metadata import CreateEnvironmentRequestLinkedMetadata
        from .create_environment_request_parent_group import CreateEnvironmentRequestParentGroup
        from .environment_sku import EnvironmentSku
        from .user_identity import UserIdentity

        fields: dict[str, Callable[[Any], None]] = {
            "billingPolicy": lambda n : setattr(self, 'billing_policy', n.get_object_value(CreateEnvironmentRequestBillingPolicy)),
            "cluster": lambda n : setattr(self, 'cluster', n.get_object_value(CreateEnvironmentRequestCluster)),
            "connectedGroupIdForTeamsEnvironment": lambda n : setattr(self, 'connected_group_id_for_teams_environment', n.get_str_value()),
            "databaseType": lambda n : setattr(self, 'database_type', n.get_str_value()),
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "displayName": lambda n : setattr(self, 'display_name', n.get_str_value()),
            "environmentSku": lambda n : setattr(self, 'environment_sku', n.get_enum_value(EnvironmentSku)),
            "finOpsMetadata": lambda n : setattr(self, 'fin_ops_metadata', n.get_object_value(CreateEnvironmentRequestFinOpsMetadata)),
            "governanceConfiguration": lambda n : setattr(self, 'governance_configuration', n.get_object_value(CreateEnvironmentRequestGovernance)),
            "linkedEnvironmentMetadata": lambda n : setattr(self, 'linked_environment_metadata', n.get_object_value(CreateEnvironmentRequestLinkedMetadata)),
            "location": lambda n : setattr(self, 'location', n.get_str_value()),
            "parentEnvironmentGroup": lambda n : setattr(self, 'parent_environment_group', n.get_object_value(CreateEnvironmentRequestParentGroup)),
            "usedBy": lambda n : setattr(self, 'used_by', n.get_object_value(UserIdentity)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("billingPolicy", self.billing_policy)
        writer.write_object_value("cluster", self.cluster)
        writer.write_str_value("connectedGroupIdForTeamsEnvironment", self.connected_group_id_for_teams_environment)
        writer.write_str_value("databaseType", self.database_type)
        writer.write_str_value("description", self.description)
        writer.write_str_value("displayName", self.display_name)
        writer.write_enum_value("environmentSku", self.environment_sku)
        writer.write_object_value("finOpsMetadata", self.fin_ops_metadata)
        writer.write_object_value("governanceConfiguration", self.governance_configuration)
        writer.write_object_value("linkedEnvironmentMetadata", self.linked_environment_metadata)
        writer.write_str_value("location", self.location)
        writer.write_object_value("parentEnvironmentGroup", self.parent_environment_group)
        writer.write_object_value("usedBy", self.used_by)
    

