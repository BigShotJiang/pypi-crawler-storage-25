from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .action_output_properties import ActionOutputProperties
    from .action_status import ActionStatus
    from .response_metadata_properties import ResponseMetadataProperties

@dataclass
class ConnectorActionEndProperties(AdditionalDataHolder, Parsable):
    """
    Properties of a connector action end event.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Error code from the failed operation, if available.
    error_code: Optional[str] = None
    # Whether the runtime can retry a failed action.
    is_retryable: Optional[bool] = None
    # Output data from a connector action.
    outputs: Optional[ActionOutputProperties] = None
    # Metadata extracted from a connector action response.
    response_metadata: Optional[ResponseMetadataProperties] = None
    # Status of a connector action execution.
    status: Optional[ActionStatus] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConnectorActionEndProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConnectorActionEndProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConnectorActionEndProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .action_output_properties import ActionOutputProperties
        from .action_status import ActionStatus
        from .response_metadata_properties import ResponseMetadataProperties

        from .action_output_properties import ActionOutputProperties
        from .action_status import ActionStatus
        from .response_metadata_properties import ResponseMetadataProperties

        fields: dict[str, Callable[[Any], None]] = {
            "errorCode": lambda n : setattr(self, 'error_code', n.get_str_value()),
            "isRetryable": lambda n : setattr(self, 'is_retryable', n.get_bool_value()),
            "outputs": lambda n : setattr(self, 'outputs', n.get_object_value(ActionOutputProperties)),
            "responseMetadata": lambda n : setattr(self, 'response_metadata', n.get_object_value(ResponseMetadataProperties)),
            "status": lambda n : setattr(self, 'status', n.get_enum_value(ActionStatus)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("errorCode", self.error_code)
        writer.write_bool_value("isRetryable", self.is_retryable)
        writer.write_object_value("outputs", self.outputs)
        writer.write_object_value("responseMetadata", self.response_metadata)
        writer.write_enum_value("status", self.status)
        writer.write_additional_data_value(self.additional_data)
    

