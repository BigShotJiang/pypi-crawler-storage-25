from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .conversation_transcript_tool_call import ConversationTranscriptToolCall

@dataclass
class ConversationTranscriptCompletion(AdditionalDataHolder, Parsable):
    """
    A completion generated in the conversation response.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Reason the completion finished (e.g. stop, tool_calls).
    finish_reason: Optional[str] = None
    # Generated text content.
    text: Optional[str] = None
    # Tool calls requested by the completion.
    tool_calls: Optional[list[ConversationTranscriptToolCall]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConversationTranscriptCompletion:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConversationTranscriptCompletion
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConversationTranscriptCompletion()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .conversation_transcript_tool_call import ConversationTranscriptToolCall

        from .conversation_transcript_tool_call import ConversationTranscriptToolCall

        fields: dict[str, Callable[[Any], None]] = {
            "finishReason": lambda n : setattr(self, 'finish_reason', n.get_str_value()),
            "text": lambda n : setattr(self, 'text', n.get_str_value()),
            "toolCalls": lambda n : setattr(self, 'tool_calls', n.get_collection_of_object_values(ConversationTranscriptToolCall)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("finishReason", self.finish_reason)
        writer.write_str_value("text", self.text)
        writer.write_collection_of_object_values("toolCalls", self.tool_calls)
        writer.write_additional_data_value(self.additional_data)
    

