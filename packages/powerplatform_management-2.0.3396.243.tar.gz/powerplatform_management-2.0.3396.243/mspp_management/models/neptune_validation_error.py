from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.api_error import APIError
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .i_error_detail import IErrorDetail
    from .neptune_validation_error_message import NeptuneValidationErrorMessage

@dataclass
class NeptuneValidationError(APIError, Parsable):
    # The code property
    code: Optional[str] = None
    # The details property
    details: Optional[list[IErrorDetail]] = None
    # The errorMessage property
    error_message: Optional[NeptuneValidationErrorMessage] = None
    # The key property
    key: Optional[str] = None
    # The message property
    message: Optional[str] = None
    # The target property
    target: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NeptuneValidationError:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NeptuneValidationError
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NeptuneValidationError()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .i_error_detail import IErrorDetail
        from .neptune_validation_error_message import NeptuneValidationErrorMessage

        from .i_error_detail import IErrorDetail
        from .neptune_validation_error_message import NeptuneValidationErrorMessage

        fields: dict[str, Callable[[Any], None]] = {
            "code": lambda n : setattr(self, 'code', n.get_str_value()),
            "details": lambda n : setattr(self, 'details', n.get_collection_of_object_values(IErrorDetail)),
            "errorMessage": lambda n : setattr(self, 'error_message', n.get_object_value(NeptuneValidationErrorMessage)),
            "key": lambda n : setattr(self, 'key', n.get_str_value()),
            "message": lambda n : setattr(self, 'message', n.get_str_value()),
            "target": lambda n : setattr(self, 'target', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("code", self.code)
        writer.write_collection_of_object_values("details", self.details)
        writer.write_object_value("errorMessage", self.error_message)
        writer.write_str_value("key", self.key)
        writer.write_str_value("message", self.message)
        writer.write_str_value("target", self.target)
    
    @property
    def primary_message(self) -> Optional[str]:
        """
        The primary error message.
        """
        return super().message

