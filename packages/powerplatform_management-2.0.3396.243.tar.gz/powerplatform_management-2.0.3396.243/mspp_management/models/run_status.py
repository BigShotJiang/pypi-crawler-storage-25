from enum import Enum

class RunStatus(str, Enum):
    NotSpecified = "NotSpecified",
    Running = "Running",
    Succeeded = "Succeeded",
    Failed = "Failed",
    Canceled = "Canceled",
    Waiting = "Waiting",
    FailedWithRetry = "FailedWithRetry",

