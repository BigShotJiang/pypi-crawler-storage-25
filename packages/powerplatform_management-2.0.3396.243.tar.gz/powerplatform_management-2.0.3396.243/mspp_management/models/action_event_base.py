from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .action_event_type import ActionEventType

@dataclass
class ActionEventBase(AdditionalDataHolder, Parsable):
    """
    Common properties shared by all action event types.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Unique identifier for this action.
    action_id: Optional[str] = None
    # IDs of actions that preceded this one.
    previous_action_ids: Optional[list[str]] = None
    # Timestamp of the event.
    time: Optional[datetime.datetime] = None
    # The type of action event.
    type: Optional[ActionEventType] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ActionEventBase:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ActionEventBase
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ActionEventBase()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .action_event_type import ActionEventType

        from .action_event_type import ActionEventType

        fields: dict[str, Callable[[Any], None]] = {
            "actionId": lambda n : setattr(self, 'action_id', n.get_str_value()),
            "previousActionIds": lambda n : setattr(self, 'previous_action_ids', n.get_collection_of_primitive_values(str)),
            "time": lambda n : setattr(self, 'time', n.get_datetime_value()),
            "type": lambda n : setattr(self, 'type', n.get_enum_value(ActionEventType)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("actionId", self.action_id)
        writer.write_collection_of_primitive_values("previousActionIds", self.previous_action_ids)
        writer.write_datetime_value("time", self.time)
        writer.write_enum_value("type", self.type)
        writer.write_additional_data_value(self.additional_data)
    

