from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .action_event_base import ActionEventBase
    from .connector_action_start_properties import ConnectorActionStartProperties
    from .running_action_type import RunningActionType

from .action_event_base import ActionEventBase

@dataclass
class ConnectorActionStartEvent(ActionEventBase, Parsable):
    """
    Event marking the start of a connector action execution.
    """
    # Properties of a connector action start event.
    properties: Optional[ConnectorActionStartProperties] = None
    # Execution model of the connector action.
    running_action_type: Optional[RunningActionType] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConnectorActionStartEvent:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConnectorActionStartEvent
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConnectorActionStartEvent()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .action_event_base import ActionEventBase
        from .connector_action_start_properties import ConnectorActionStartProperties
        from .running_action_type import RunningActionType

        from .action_event_base import ActionEventBase
        from .connector_action_start_properties import ConnectorActionStartProperties
        from .running_action_type import RunningActionType

        fields: dict[str, Callable[[Any], None]] = {
            "properties": lambda n : setattr(self, 'properties', n.get_object_value(ConnectorActionStartProperties)),
            "runningActionType": lambda n : setattr(self, 'running_action_type', n.get_enum_value(RunningActionType)),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_object_value("properties", self.properties)
        writer.write_enum_value("runningActionType", self.running_action_type)
    

