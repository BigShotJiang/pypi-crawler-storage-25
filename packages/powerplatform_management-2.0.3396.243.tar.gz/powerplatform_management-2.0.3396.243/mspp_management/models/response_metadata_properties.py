from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .sensitivity_label_properties import SensitivityLabelProperties

@dataclass
class ResponseMetadataProperties(AdditionalDataHolder, Parsable):
    """
    Metadata extracted from a connector action response.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Sensitivity label information from a connector response.
    sensitivity_label: Optional[SensitivityLabelProperties] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ResponseMetadataProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ResponseMetadataProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ResponseMetadataProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .sensitivity_label_properties import SensitivityLabelProperties

        from .sensitivity_label_properties import SensitivityLabelProperties

        fields: dict[str, Callable[[Any], None]] = {
            "sensitivityLabel": lambda n : setattr(self, 'sensitivity_label', n.get_object_value(SensitivityLabelProperties)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("sensitivityLabel", self.sensitivity_label)
        writer.write_additional_data_value(self.additional_data)
    

