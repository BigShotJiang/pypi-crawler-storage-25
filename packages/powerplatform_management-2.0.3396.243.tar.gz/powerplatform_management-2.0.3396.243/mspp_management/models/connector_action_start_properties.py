from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .action_properties import ActionProperties
    from .connector_action_start_properties_inputs import ConnectorActionStartProperties_inputs
    from .link_properties import LinkProperties
    from .validation_properties import ValidationProperties

@dataclass
class ConnectorActionStartProperties(AdditionalDataHolder, Parsable):
    """
    Properties of a connector action start event.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Identifies the connector action being invoked.
    action: Optional[ActionProperties] = None
    # Input data for the connector action.
    inputs: Optional[ConnectorActionStartProperties_inputs] = None
    # Reference to content stored externally.
    inputs_link: Optional[LinkProperties] = None
    # Validation requirements for a connector action.
    validation: Optional[ValidationProperties] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConnectorActionStartProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConnectorActionStartProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConnectorActionStartProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .action_properties import ActionProperties
        from .connector_action_start_properties_inputs import ConnectorActionStartProperties_inputs
        from .link_properties import LinkProperties
        from .validation_properties import ValidationProperties

        from .action_properties import ActionProperties
        from .connector_action_start_properties_inputs import ConnectorActionStartProperties_inputs
        from .link_properties import LinkProperties
        from .validation_properties import ValidationProperties

        fields: dict[str, Callable[[Any], None]] = {
            "action": lambda n : setattr(self, 'action', n.get_object_value(ActionProperties)),
            "inputs": lambda n : setattr(self, 'inputs', n.get_object_value(ConnectorActionStartProperties_inputs)),
            "inputsLink": lambda n : setattr(self, 'inputs_link', n.get_object_value(LinkProperties)),
            "validation": lambda n : setattr(self, 'validation', n.get_object_value(ValidationProperties)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("action", self.action)
        writer.write_object_value("inputs", self.inputs)
        writer.write_object_value("inputsLink", self.inputs_link)
        writer.write_object_value("validation", self.validation)
        writer.write_additional_data_value(self.additional_data)
    

