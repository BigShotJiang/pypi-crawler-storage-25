from enum import Enum

class ContentTypeCategory(str, Enum):
    NotSpecified = "NotSpecified",
    Text = "Text",
    Json = "Json",
    Other = "Other",

