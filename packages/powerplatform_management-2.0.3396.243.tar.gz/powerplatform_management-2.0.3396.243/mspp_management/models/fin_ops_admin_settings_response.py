from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .fin_ops_day_of_week import FinOpsDayOfWeek
    from .fin_ops_update_cadence import FinOpsUpdateCadence

@dataclass
class FinOpsAdminSettingsResponse(AdditionalDataHolder, Parsable):
    """
    Finance and Operations Maintenance response.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Cadence for major version application updates.
    maintenance_window_cadence: Optional[FinOpsUpdateCadence] = None
    # The preferred days of week for RunOne Updates.
    maintenance_window_days_of_week: Optional[list[FinOpsDayOfWeek]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> FinOpsAdminSettingsResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: FinOpsAdminSettingsResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return FinOpsAdminSettingsResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .fin_ops_day_of_week import FinOpsDayOfWeek
        from .fin_ops_update_cadence import FinOpsUpdateCadence

        from .fin_ops_day_of_week import FinOpsDayOfWeek
        from .fin_ops_update_cadence import FinOpsUpdateCadence

        fields: dict[str, Callable[[Any], None]] = {
            "maintenanceWindowCadence": lambda n : setattr(self, 'maintenance_window_cadence', n.get_enum_value(FinOpsUpdateCadence)),
            "maintenanceWindowDaysOfWeek": lambda n : setattr(self, 'maintenance_window_days_of_week', n.get_collection_of_enum_values(FinOpsDayOfWeek)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("maintenanceWindowCadence", self.maintenance_window_cadence)
        writer.write_collection_of_enum_values("maintenanceWindowDaysOfWeek", self.maintenance_window_days_of_week)
        writer.write_additional_data_value(self.additional_data)
    

