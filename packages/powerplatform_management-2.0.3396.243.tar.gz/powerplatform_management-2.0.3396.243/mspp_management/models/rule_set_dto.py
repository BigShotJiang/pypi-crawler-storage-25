from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .mg_gov_policy_environment_filter import MgGovPolicyEnvironmentFilter
    from .rule_set_parameters import RuleSetParameters

@dataclass
class RuleSetDto(AdditionalDataHolder, Parsable):
    """
    Rule Set data transfer object.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Defines the environment filters.
    environment_filter: Optional[MgGovPolicyEnvironmentFilter] = None
    # The ID of the Rule Set.
    id: Optional[str] = None
    # The last modified timestamp.
    last_modified: Optional[datetime.datetime] = None
    # The Rule Set parameters.
    parameters: Optional[list[RuleSetParameters]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> RuleSetDto:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: RuleSetDto
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return RuleSetDto()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .mg_gov_policy_environment_filter import MgGovPolicyEnvironmentFilter
        from .rule_set_parameters import RuleSetParameters

        from .mg_gov_policy_environment_filter import MgGovPolicyEnvironmentFilter
        from .rule_set_parameters import RuleSetParameters

        fields: dict[str, Callable[[Any], None]] = {
            "environmentFilter": lambda n : setattr(self, 'environment_filter', n.get_object_value(MgGovPolicyEnvironmentFilter)),
            "id": lambda n : setattr(self, 'id', n.get_str_value()),
            "lastModified": lambda n : setattr(self, 'last_modified', n.get_datetime_value()),
            "parameters": lambda n : setattr(self, 'parameters', n.get_collection_of_object_values(RuleSetParameters)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("environmentFilter", self.environment_filter)
        writer.write_str_value("id", self.id)
        writer.write_datetime_value("lastModified", self.last_modified)
        writer.write_collection_of_object_values("parameters", self.parameters)
        writer.write_additional_data_value(self.additional_data)
    

