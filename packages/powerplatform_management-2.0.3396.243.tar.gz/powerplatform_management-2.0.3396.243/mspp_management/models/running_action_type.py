from enum import Enum

class RunningActionType(str, Enum):
    NotSpecified = "NotSpecified",
    Synchronous = "Synchronous",
    Webhook = "Webhook",

