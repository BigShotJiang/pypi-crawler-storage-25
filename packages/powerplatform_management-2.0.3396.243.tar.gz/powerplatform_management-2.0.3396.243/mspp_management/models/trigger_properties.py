from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .link_properties import LinkProperties
    from .trigger_properties_inputs import TriggerProperties_inputs

@dataclass
class TriggerProperties(AdditionalDataHolder, Parsable):
    """
    Properties of a trigger event.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Trigger input data.
    inputs: Optional[TriggerProperties_inputs] = None
    # Reference to content stored externally.
    inputs_link: Optional[LinkProperties] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TriggerProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TriggerProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TriggerProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .link_properties import LinkProperties
        from .trigger_properties_inputs import TriggerProperties_inputs

        from .link_properties import LinkProperties
        from .trigger_properties_inputs import TriggerProperties_inputs

        fields: dict[str, Callable[[Any], None]] = {
            "inputs": lambda n : setattr(self, 'inputs', n.get_object_value(TriggerProperties_inputs)),
            "inputsLink": lambda n : setattr(self, 'inputs_link', n.get_object_value(LinkProperties)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("inputs", self.inputs)
        writer.write_object_value("inputsLink", self.inputs_link)
        writer.write_additional_data_value(self.additional_data)
    

