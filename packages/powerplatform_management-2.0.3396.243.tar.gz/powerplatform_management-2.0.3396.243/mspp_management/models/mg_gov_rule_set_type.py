from enum import Enum

class MgGovRuleSetType(str, Enum):
    NotSpecified = "NotSpecified",
    Sharing = "Sharing",
    AdminDigest = "AdminDigest",
    SolutionChecker = "SolutionChecker",
    MakerOnboarding = "MakerOnboarding",
    Lifecycle = "Lifecycle",
    Copilot = "Copilot",
    CrossGeoCopilotDataMovement = "CrossGeoCopilotDataMovement",
    GenerativeAISettings = "GenerativeAISettings",
    CopilotAuth = "CopilotAuth",
    FlowAutomationRestrictions = "FlowAutomationRestrictions",

