from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .template_availability import TemplateAvailability

@dataclass
class EnvironmentTemplate(Parsable):
    # The availability property
    availability: Optional[list[TemplateAvailability]] = None
    # The displayName property
    display_name: Optional[str] = None
    # The isCustomerEngagement property
    is_customer_engagement: Optional[bool] = None
    # The isSupportedForResetOperation property
    is_supported_for_reset_operation: Optional[bool] = None
    # The name property
    name: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EnvironmentTemplate:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EnvironmentTemplate
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EnvironmentTemplate()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .template_availability import TemplateAvailability

        from .template_availability import TemplateAvailability

        fields: dict[str, Callable[[Any], None]] = {
            "availability": lambda n : setattr(self, 'availability', n.get_collection_of_object_values(TemplateAvailability)),
            "displayName": lambda n : setattr(self, 'display_name', n.get_str_value()),
            "isCustomerEngagement": lambda n : setattr(self, 'is_customer_engagement', n.get_bool_value()),
            "isSupportedForResetOperation": lambda n : setattr(self, 'is_supported_for_reset_operation', n.get_bool_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("availability", self.availability)
        writer.write_str_value("displayName", self.display_name)
        writer.write_bool_value("isCustomerEngagement", self.is_customer_engagement)
        writer.write_bool_value("isSupportedForResetOperation", self.is_supported_for_reset_operation)
        writer.write_str_value("name", self.name)
    

