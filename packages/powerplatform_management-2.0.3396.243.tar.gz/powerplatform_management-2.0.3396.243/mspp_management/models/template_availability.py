from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .disabled_reason import DisabledReason
    from .environment_sku import EnvironmentSku

@dataclass
class TemplateAvailability(Parsable):
    # The disabledReason property
    disabled_reason: Optional[DisabledReason] = None
    # The environment SKU.
    environment_sku: Optional[EnvironmentSku] = None
    # The isDisabled property
    is_disabled: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TemplateAvailability:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TemplateAvailability
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TemplateAvailability()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .disabled_reason import DisabledReason
        from .environment_sku import EnvironmentSku

        from .disabled_reason import DisabledReason
        from .environment_sku import EnvironmentSku

        fields: dict[str, Callable[[Any], None]] = {
            "disabledReason": lambda n : setattr(self, 'disabled_reason', n.get_object_value(DisabledReason)),
            "environmentSku": lambda n : setattr(self, 'environment_sku', n.get_enum_value(EnvironmentSku)),
            "isDisabled": lambda n : setattr(self, 'is_disabled', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("disabledReason", self.disabled_reason)
        writer.write_enum_value("environmentSku", self.environment_sku)
        writer.write_bool_value("isDisabled", self.is_disabled)
    

