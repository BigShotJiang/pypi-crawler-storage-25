from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class EnvironmentCurrency(Parsable):
    # The code property
    code: Optional[str] = None
    # The isTenantDefault property
    is_tenant_default: Optional[bool] = None
    # The symbol property
    symbol: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EnvironmentCurrency:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EnvironmentCurrency
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EnvironmentCurrency()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "code": lambda n : setattr(self, 'code', n.get_str_value()),
            "isTenantDefault": lambda n : setattr(self, 'is_tenant_default', n.get_bool_value()),
            "symbol": lambda n : setattr(self, 'symbol', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("code", self.code)
        writer.write_bool_value("isTenantDefault", self.is_tenant_default)
        writer.write_str_value("symbol", self.symbol)
    

