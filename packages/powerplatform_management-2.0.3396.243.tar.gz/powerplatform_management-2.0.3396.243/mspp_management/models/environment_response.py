from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .environment_response_retention_details import EnvironmentResponse_retentionDetails
    from .fin_ops_metadata import FinOpsMetadata
    from .principal import Principal

@dataclass
class EnvironmentResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Indicates whether admin-only mode is enabled or disabled for the environment.
    admin_mode: Optional[str] = None
    # The Azure region of the environment.
    azure_region: Optional[str] = None
    # Indicates whether background operations are enabled or disabled for the environment.
    background_operations_state: Optional[str] = None
    # The cluster category the environment is in.
    cluster_category: Optional[str] = None
    # The ID of the AAD group connected to the environment.
    connected_group_id: Optional[str] = None
    # The createdBy property
    created_by: Optional[Principal] = None
    # The creation date and time of the environment.
    created_date_time: Optional[datetime.datetime] = None
    # The createdFor property
    created_for: Optional[Principal] = None
    # The ID of the Dataverse database (organization) associated with the environment.
    dataverse_id: Optional[str] = None
    # The deletion date and time of the environment.
    deleted_date_time: Optional[datetime.datetime] = None
    # The display name of the environment.
    display_name: Optional[str] = None
    # The domain name of the Dataverse database associated with the environment.
    domain_name: Optional[str] = None
    # The ID of the environment group to which this environment belongs.
    environment_group_id: Optional[str] = None
    # Metadata describing a linked FinOps environment.
    fin_ops_metadata: Optional[FinOpsMetadata] = None
    # The geographical region of the environment.
    geo: Optional[str] = None
    # The ID of the environment.
    id: Optional[str] = None
    # The protection level applied to the environment.
    protection_level: Optional[str] = None
    # The retention details of the environment.
    retention_details: Optional[EnvironmentResponse_retentionDetails] = None
    # The security group that controls access to the environment.
    security_group_id: Optional[str] = None
    # The current state of the environment.
    state: Optional[str] = None
    # The ID of the tenant that the environment belongs to.
    tenant_id: Optional[str] = None
    # The type (SKU) of the environment.
    type: Optional[str] = None
    # The URL of the Dataverse database associated with the environment.
    url: Optional[str] = None
    # The version of the Dataverse database associated with the environment.
    version: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EnvironmentResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EnvironmentResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EnvironmentResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .environment_response_retention_details import EnvironmentResponse_retentionDetails
        from .fin_ops_metadata import FinOpsMetadata
        from .principal import Principal

        from .environment_response_retention_details import EnvironmentResponse_retentionDetails
        from .fin_ops_metadata import FinOpsMetadata
        from .principal import Principal

        fields: dict[str, Callable[[Any], None]] = {
            "adminMode": lambda n : setattr(self, 'admin_mode', n.get_str_value()),
            "azureRegion": lambda n : setattr(self, 'azure_region', n.get_str_value()),
            "backgroundOperationsState": lambda n : setattr(self, 'background_operations_state', n.get_str_value()),
            "clusterCategory": lambda n : setattr(self, 'cluster_category', n.get_str_value()),
            "connectedGroupId": lambda n : setattr(self, 'connected_group_id', n.get_str_value()),
            "createdBy": lambda n : setattr(self, 'created_by', n.get_object_value(Principal)),
            "createdDateTime": lambda n : setattr(self, 'created_date_time', n.get_datetime_value()),
            "createdFor": lambda n : setattr(self, 'created_for', n.get_object_value(Principal)),
            "dataverseId": lambda n : setattr(self, 'dataverse_id', n.get_str_value()),
            "deletedDateTime": lambda n : setattr(self, 'deleted_date_time', n.get_datetime_value()),
            "displayName": lambda n : setattr(self, 'display_name', n.get_str_value()),
            "domainName": lambda n : setattr(self, 'domain_name', n.get_str_value()),
            "environmentGroupId": lambda n : setattr(self, 'environment_group_id', n.get_str_value()),
            "finOpsMetadata": lambda n : setattr(self, 'fin_ops_metadata', n.get_object_value(FinOpsMetadata)),
            "geo": lambda n : setattr(self, 'geo', n.get_str_value()),
            "id": lambda n : setattr(self, 'id', n.get_str_value()),
            "protectionLevel": lambda n : setattr(self, 'protection_level', n.get_str_value()),
            "retentionDetails": lambda n : setattr(self, 'retention_details', n.get_object_value(EnvironmentResponse_retentionDetails)),
            "securityGroupId": lambda n : setattr(self, 'security_group_id', n.get_str_value()),
            "state": lambda n : setattr(self, 'state', n.get_str_value()),
            "tenantId": lambda n : setattr(self, 'tenant_id', n.get_str_value()),
            "type": lambda n : setattr(self, 'type', n.get_str_value()),
            "url": lambda n : setattr(self, 'url', n.get_str_value()),
            "version": lambda n : setattr(self, 'version', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("adminMode", self.admin_mode)
        writer.write_str_value("azureRegion", self.azure_region)
        writer.write_str_value("backgroundOperationsState", self.background_operations_state)
        writer.write_str_value("clusterCategory", self.cluster_category)
        writer.write_str_value("connectedGroupId", self.connected_group_id)
        writer.write_object_value("createdBy", self.created_by)
        writer.write_datetime_value("createdDateTime", self.created_date_time)
        writer.write_object_value("createdFor", self.created_for)
        writer.write_str_value("dataverseId", self.dataverse_id)
        writer.write_datetime_value("deletedDateTime", self.deleted_date_time)
        writer.write_str_value("displayName", self.display_name)
        writer.write_str_value("domainName", self.domain_name)
        writer.write_str_value("environmentGroupId", self.environment_group_id)
        writer.write_object_value("finOpsMetadata", self.fin_ops_metadata)
        writer.write_str_value("geo", self.geo)
        writer.write_str_value("id", self.id)
        writer.write_str_value("protectionLevel", self.protection_level)
        writer.write_object_value("retentionDetails", self.retention_details)
        writer.write_str_value("securityGroupId", self.security_group_id)
        writer.write_str_value("state", self.state)
        writer.write_str_value("tenantId", self.tenant_id)
        writer.write_str_value("type", self.type)
        writer.write_str_value("url", self.url)
        writer.write_str_value("version", self.version)
        writer.write_additional_data_value(self.additional_data)
    

