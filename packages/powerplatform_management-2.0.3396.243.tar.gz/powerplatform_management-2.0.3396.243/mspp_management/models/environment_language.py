from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class EnvironmentLanguage(Parsable):
    # The isTenantDefault property
    is_tenant_default: Optional[bool] = None
    # The localeId property
    locale_id: Optional[int] = None
    # The localizedName property
    localized_name: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EnvironmentLanguage:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EnvironmentLanguage
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EnvironmentLanguage()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "isTenantDefault": lambda n : setattr(self, 'is_tenant_default', n.get_bool_value()),
            "localeId": lambda n : setattr(self, 'locale_id', n.get_int_value()),
            "localizedName": lambda n : setattr(self, 'localized_name', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("isTenantDefault", self.is_tenant_default)
        writer.write_int_value("localeId", self.locale_id)
        writer.write_str_value("localizedName", self.localized_name)
    

