from enum import Enum

class MgGovResourceType(str, Enum):
    NotSpecified = "NotSpecified",
    Flow = "Flow",
    App = "App",
    AuthoringBot = "AuthoringBot",
    UsersBot = "UsersBot",

