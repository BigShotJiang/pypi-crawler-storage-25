from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .user_per_flow_capacity_source_user_context_record import UserPerFlowCapacitySourceUserContextRecord

@dataclass
class PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceUserContextRecord(Parsable):
    """
    Paginated result container for user context summary records.
    """
    # The current page number.
    current_page: Optional[int] = None
    # Collection of user context summary records.
    records: Optional[list[UserPerFlowCapacitySourceUserContextRecord]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceUserContextRecord:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceUserContextRecord
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PowerPlatformRequestSnapshotResultWithoutPagesUserPerFlowCapacitySourceUserContextRecord()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .user_per_flow_capacity_source_user_context_record import UserPerFlowCapacitySourceUserContextRecord

        from .user_per_flow_capacity_source_user_context_record import UserPerFlowCapacitySourceUserContextRecord

        fields: dict[str, Callable[[Any], None]] = {
            "currentPage": lambda n : setattr(self, 'current_page', n.get_int_value()),
            "records": lambda n : setattr(self, 'records', n.get_collection_of_object_values(UserPerFlowCapacitySourceUserContextRecord)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("currentPage", self.current_page)
        writer.write_collection_of_object_values("records", self.records)
    

