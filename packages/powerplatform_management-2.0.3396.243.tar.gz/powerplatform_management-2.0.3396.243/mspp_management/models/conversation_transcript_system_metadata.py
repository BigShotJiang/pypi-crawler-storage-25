from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .conversation_transcript_scenario import ConversationTranscriptScenario

@dataclass
class ConversationTranscriptSystemMetadata(AdditionalDataHolder, Parsable):
    """
    System metadata for a conversation transcript.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The scenario under which the conversation occurred.
    scenario: Optional[ConversationTranscriptScenario] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConversationTranscriptSystemMetadata:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConversationTranscriptSystemMetadata
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConversationTranscriptSystemMetadata()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .conversation_transcript_scenario import ConversationTranscriptScenario

        from .conversation_transcript_scenario import ConversationTranscriptScenario

        fields: dict[str, Callable[[Any], None]] = {
            "scenario": lambda n : setattr(self, 'scenario', n.get_enum_value(ConversationTranscriptScenario)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_enum_value("scenario", self.scenario)
        writer.write_additional_data_value(self.additional_data)
    

