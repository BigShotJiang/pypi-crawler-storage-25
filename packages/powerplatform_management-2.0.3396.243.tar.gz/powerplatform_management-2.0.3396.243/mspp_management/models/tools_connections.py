from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .connection import Connection

@dataclass
class ToolsConnections(AdditionalDataHolder, Parsable):
    """
    A tool along with the corresponding user connections to use for a maker evaluation run.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The Dataverse bot ID.
    bot_id: Optional[str] = None
    # Bot schema name.
    bot_schema_name: Optional[str] = None
    # A list of connections.
    connections: Optional[list[Connection]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ToolsConnections:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ToolsConnections
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ToolsConnections()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .connection import Connection

        from .connection import Connection

        fields: dict[str, Callable[[Any], None]] = {
            "botId": lambda n : setattr(self, 'bot_id', n.get_str_value()),
            "botSchemaName": lambda n : setattr(self, 'bot_schema_name', n.get_str_value()),
            "connections": lambda n : setattr(self, 'connections', n.get_collection_of_object_values(Connection)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("botId", self.bot_id)
        writer.write_str_value("botSchemaName", self.bot_schema_name)
        writer.write_collection_of_object_values("connections", self.connections)
        writer.write_additional_data_value(self.additional_data)
    

