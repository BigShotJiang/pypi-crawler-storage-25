from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .test_case_result import TestCaseResult

@dataclass
class TestRun(AdditionalDataHolder, Parsable):
    """
    The response payload for a get evaluation run details request.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The CDS bot ID where the evaluation run is executed.
    cds_bot_id: Optional[UUID] = None
    # The timestamp when the evaluation run ended.
    end_time: Optional[datetime.datetime] = None
    # The environment ID where the evaluation run is executed.
    environment_id: Optional[str] = None
    # The unique identifier for this evaluation run.
    id: Optional[UUID] = None
    # The MCS connection ID used in the evaluation run.
    mcs_connection_id: Optional[str] = None
    # The name of the evaluation run.
    name: Optional[str] = None
    # The ID of the owner who initiated the evaluation run.
    owner_id: Optional[str] = None
    # The timestamp when the evaluation run started.
    start_time: Optional[datetime.datetime] = None
    # The test cases and their results in the evaluation run.
    test_cases_results: Optional[list[TestCaseResult]] = None
    # The ID of the object model test set entity record that the run is associated with.
    test_set_id: Optional[UUID] = None
    # Number of test cases included in the evaluation run.
    total_test_cases: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TestRun:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TestRun
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TestRun()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .test_case_result import TestCaseResult

        from .test_case_result import TestCaseResult

        fields: dict[str, Callable[[Any], None]] = {
            "cdsBotId": lambda n : setattr(self, 'cds_bot_id', n.get_uuid_value()),
            "endTime": lambda n : setattr(self, 'end_time', n.get_datetime_value()),
            "environmentId": lambda n : setattr(self, 'environment_id', n.get_str_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "mcsConnectionId": lambda n : setattr(self, 'mcs_connection_id', n.get_str_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "ownerId": lambda n : setattr(self, 'owner_id', n.get_str_value()),
            "startTime": lambda n : setattr(self, 'start_time', n.get_datetime_value()),
            "testCasesResults": lambda n : setattr(self, 'test_cases_results', n.get_collection_of_object_values(TestCaseResult)),
            "testSetId": lambda n : setattr(self, 'test_set_id', n.get_uuid_value()),
            "totalTestCases": lambda n : setattr(self, 'total_test_cases', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_uuid_value("cdsBotId", self.cds_bot_id)
        writer.write_datetime_value("endTime", self.end_time)
        writer.write_str_value("environmentId", self.environment_id)
        writer.write_uuid_value("id", self.id)
        writer.write_str_value("mcsConnectionId", self.mcs_connection_id)
        writer.write_str_value("name", self.name)
        writer.write_str_value("ownerId", self.owner_id)
        writer.write_datetime_value("startTime", self.start_time)
        writer.write_collection_of_object_values("testCasesResults", self.test_cases_results)
        writer.write_uuid_value("testSetId", self.test_set_id)
        writer.write_int_value("totalTestCases", self.total_test_cases)
        writer.write_additional_data_value(self.additional_data)
    

