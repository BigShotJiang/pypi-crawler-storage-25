from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class AdvisorActionResult(AdditionalDataHolder, Parsable):
    """
    The result of an action performed on a resource
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Final status of the action request
    action_final_result: Optional[str] = None
    # The error message associated with any error encountered during the action execution
    error: Optional[str] = None
    # The error code associated with any error encountered during the action execution
    error_code: Optional[str] = None
    # The unique ID of the resource for which the action was performed
    resource_id: Optional[str] = None
    # The status code of the action request for the given resource
    status_code: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AdvisorActionResult:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AdvisorActionResult
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AdvisorActionResult()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "actionFinalResult": lambda n : setattr(self, 'action_final_result', n.get_str_value()),
            "error": lambda n : setattr(self, 'error', n.get_str_value()),
            "errorCode": lambda n : setattr(self, 'error_code', n.get_str_value()),
            "resourceId": lambda n : setattr(self, 'resource_id', n.get_str_value()),
            "statusCode": lambda n : setattr(self, 'status_code', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("actionFinalResult", self.action_final_result)
        writer.write_str_value("error", self.error)
        writer.write_str_value("errorCode", self.error_code)
        writer.write_str_value("resourceId", self.resource_id)
        writer.write_int_value("statusCode", self.status_code)
        writer.write_additional_data_value(self.additional_data)
    

