from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class NeptuneValidationErrorMessage(Parsable):
    # The code property
    code: Optional[str] = None
    # The helpLink property
    help_link: Optional[str] = None
    # The message property
    message: Optional[str] = None
    # The operationCode property
    operation_code: Optional[str] = None
    # The target property
    target: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NeptuneValidationErrorMessage:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NeptuneValidationErrorMessage
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NeptuneValidationErrorMessage()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "code": lambda n : setattr(self, 'code', n.get_str_value()),
            "helpLink": lambda n : setattr(self, 'help_link', n.get_str_value()),
            "message": lambda n : setattr(self, 'message', n.get_str_value()),
            "operationCode": lambda n : setattr(self, 'operation_code', n.get_str_value()),
            "target": lambda n : setattr(self, 'target', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("code", self.code)
        writer.write_str_value("helpLink", self.help_link)
        writer.write_str_value("message", self.message)
        writer.write_str_value("operationCode", self.operation_code)
        writer.write_str_value("target", self.target)
    

