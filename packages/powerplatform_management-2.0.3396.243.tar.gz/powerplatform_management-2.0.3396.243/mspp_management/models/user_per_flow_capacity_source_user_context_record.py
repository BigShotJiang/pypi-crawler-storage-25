from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class UserPerFlowCapacitySourceUserContextRecord(Parsable):
    """
    User context summary for per flow capacity source.
    """
    # The date of consumption.
    consumption_date: Optional[datetime.datetime] = None
    # The context in which flows were executed.
    flow_context: Optional[str] = None
    # The license categorization of the flows.
    flow_license_categorization: Optional[str] = None
    # The tenant identifier.
    tenant_id: Optional[UUID] = None
    # The total capacity available for the user.
    total_capacity: Optional[int] = None
    # The total consumption units for the user.
    total_consumption: Optional[int] = None
    # The total number of flows executed by the user.
    total_flows: Optional[int] = None
    # The user identifier.
    user_id: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> UserPerFlowCapacitySourceUserContextRecord:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: UserPerFlowCapacitySourceUserContextRecord
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return UserPerFlowCapacitySourceUserContextRecord()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "consumptionDate": lambda n : setattr(self, 'consumption_date', n.get_datetime_value()),
            "flowContext": lambda n : setattr(self, 'flow_context', n.get_str_value()),
            "flowLicenseCategorization": lambda n : setattr(self, 'flow_license_categorization', n.get_str_value()),
            "tenantId": lambda n : setattr(self, 'tenant_id', n.get_uuid_value()),
            "totalCapacity": lambda n : setattr(self, 'total_capacity', n.get_int_value()),
            "totalConsumption": lambda n : setattr(self, 'total_consumption', n.get_int_value()),
            "totalFlows": lambda n : setattr(self, 'total_flows', n.get_int_value()),
            "userId": lambda n : setattr(self, 'user_id', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("consumptionDate", self.consumption_date)
        writer.write_str_value("flowContext", self.flow_context)
        writer.write_str_value("flowLicenseCategorization", self.flow_license_categorization)
        writer.write_uuid_value("tenantId", self.tenant_id)
        writer.write_int_value("totalCapacity", self.total_capacity)
        writer.write_int_value("totalConsumption", self.total_consumption)
        writer.write_int_value("totalFlows", self.total_flows)
        writer.write_str_value("userId", self.user_id)
    

