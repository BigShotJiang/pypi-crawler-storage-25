from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .action_output_properties_headers import ActionOutputProperties_headers
    from .body_properties import BodyProperties

@dataclass
class ActionOutputProperties(AdditionalDataHolder, Parsable):
    """
    Output data from a connector action.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Body content of an action output.
    body: Optional[BodyProperties] = None
    # Response headers from the connector.
    headers: Optional[ActionOutputProperties_headers] = None
    # HTTP status code of the connector response.
    status_code: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ActionOutputProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ActionOutputProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ActionOutputProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .action_output_properties_headers import ActionOutputProperties_headers
        from .body_properties import BodyProperties

        from .action_output_properties_headers import ActionOutputProperties_headers
        from .body_properties import BodyProperties

        fields: dict[str, Callable[[Any], None]] = {
            "body": lambda n : setattr(self, 'body', n.get_object_value(BodyProperties)),
            "headers": lambda n : setattr(self, 'headers', n.get_object_value(ActionOutputProperties_headers)),
            "statusCode": lambda n : setattr(self, 'status_code', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("body", self.body)
        writer.write_object_value("headers", self.headers)
        writer.write_int_value("statusCode", self.status_code)
        writer.write_additional_data_value(self.additional_data)
    

