from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .action_properties import ActionProperties

@dataclass
class ActionSuggestionRequestProperties(AdditionalDataHolder, Parsable):
    """
    Properties of an action suggestion request event.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Identifies the connector action being invoked.
    action: Optional[ActionProperties] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ActionSuggestionRequestProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ActionSuggestionRequestProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ActionSuggestionRequestProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .action_properties import ActionProperties

        from .action_properties import ActionProperties

        fields: dict[str, Callable[[Any], None]] = {
            "action": lambda n : setattr(self, 'action', n.get_object_value(ActionProperties)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("action", self.action)
        writer.write_additional_data_value(self.additional_data)
    

