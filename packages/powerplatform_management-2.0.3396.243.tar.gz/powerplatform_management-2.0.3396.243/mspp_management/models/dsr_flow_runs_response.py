from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .dsr_flow_run_data import DsrFlowRunData

@dataclass
class DsrFlowRunsResponse(AdditionalDataHolder, Parsable):
    """
    Response containing flow run action history for DSR export.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The workflow ID.
    flow_id: Optional[str] = None
    # URL to retrieve the next page of results, if available.
    next_link: Optional[str] = None
    # List of flow run data entries.
    value: Optional[list[DsrFlowRunData]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DsrFlowRunsResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DsrFlowRunsResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DsrFlowRunsResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .dsr_flow_run_data import DsrFlowRunData

        from .dsr_flow_run_data import DsrFlowRunData

        fields: dict[str, Callable[[Any], None]] = {
            "flowId": lambda n : setattr(self, 'flow_id', n.get_str_value()),
            "nextLink": lambda n : setattr(self, 'next_link', n.get_str_value()),
            "value": lambda n : setattr(self, 'value', n.get_collection_of_object_values(DsrFlowRunData)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("flowId", self.flow_id)
        writer.write_str_value("nextLink", self.next_link)
        writer.write_collection_of_object_values("value", self.value)
        writer.write_additional_data_value(self.additional_data)
    

