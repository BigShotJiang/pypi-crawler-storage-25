from enum import Enum

class ActionStatus(str, Enum):
    NotSpecified = "NotSpecified",
    Succeeded = "Succeeded",
    Failed = "Failed",

