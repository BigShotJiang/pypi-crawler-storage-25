from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .conversation_transcript_function import ConversationTranscriptFunction

@dataclass
class ConversationTranscriptToolCall(AdditionalDataHolder, Parsable):
    """
    A tool call within a conversation.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Function details of a tool call.
    function: Optional[ConversationTranscriptFunction] = None
    # Unique identifier of the tool call.
    id: Optional[str] = None
    # Type of the tool call.
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ConversationTranscriptToolCall:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ConversationTranscriptToolCall
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ConversationTranscriptToolCall()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .conversation_transcript_function import ConversationTranscriptFunction

        from .conversation_transcript_function import ConversationTranscriptFunction

        fields: dict[str, Callable[[Any], None]] = {
            "function": lambda n : setattr(self, 'function', n.get_object_value(ConversationTranscriptFunction)),
            "id": lambda n : setattr(self, 'id', n.get_str_value()),
            "type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("function", self.function)
        writer.write_str_value("id", self.id)
        writer.write_str_value("type", self.type)
        writer.write_additional_data_value(self.additional_data)
    

