from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class RunStatusResponse(AdditionalDataHolder, Parsable):
    """
    The response payload from triggering an evaluation run request.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The URI to poll for the evaluation run results.
    callback_uri: Optional[str] = None
    # The timestamp when the last status update occurred.
    last_updated_at: Optional[datetime.datetime] = None
    # The unique identifier for this evaluation run.
    run_id: Optional[UUID] = None
    # The number of test cases processed so far in the evaluation run.
    test_cases_processed: Optional[int] = None
    # Total number of test cases to be processed in the evaluation run.
    total_test_cases: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> RunStatusResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: RunStatusResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return RunStatusResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "callbackUri": lambda n : setattr(self, 'callback_uri', n.get_str_value()),
            "lastUpdatedAt": lambda n : setattr(self, 'last_updated_at', n.get_datetime_value()),
            "runId": lambda n : setattr(self, 'run_id', n.get_uuid_value()),
            "testCasesProcessed": lambda n : setattr(self, 'test_cases_processed', n.get_int_value()),
            "totalTestCases": lambda n : setattr(self, 'total_test_cases', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("callbackUri", self.callback_uri)
        writer.write_datetime_value("lastUpdatedAt", self.last_updated_at)
        writer.write_uuid_value("runId", self.run_id)
        writer.write_int_value("testCasesProcessed", self.test_cases_processed)
        writer.write_int_value("totalTestCases", self.total_test_cases)
        writer.write_additional_data_value(self.additional_data)
    

