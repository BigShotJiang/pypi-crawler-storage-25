from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .metric import Metric

@dataclass
class TestCaseResult(AdditionalDataHolder, Parsable):
    """
    The result of a test case in a maker evaluation run.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The list of grader metrics associated with the test case.
    metrics_results: Optional[list[Metric]] = None
    # The ID of the object model entity that the test case is sourced from.
    test_case_id: Optional[UUID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TestCaseResult:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TestCaseResult
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TestCaseResult()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .metric import Metric

        from .metric import Metric

        fields: dict[str, Callable[[Any], None]] = {
            "metricsResults": lambda n : setattr(self, 'metrics_results', n.get_collection_of_object_values(Metric)),
            "testCaseId": lambda n : setattr(self, 'test_case_id', n.get_uuid_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("metricsResults", self.metrics_results)
        writer.write_uuid_value("testCaseId", self.test_case_id)
        writer.write_additional_data_value(self.additional_data)
    

