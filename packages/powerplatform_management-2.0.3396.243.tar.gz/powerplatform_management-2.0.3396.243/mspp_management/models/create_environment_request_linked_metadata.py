from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .create_environment_request_currency import CreateEnvironmentRequestCurrency
    from .create_environment_request_linked_metadata_template_metadata import CreateEnvironmentRequestLinkedMetadata_templateMetadata

@dataclass
class CreateEnvironmentRequestLinkedMetadata(Parsable):
    """
    Metadata for the linked Dataverse environment.
    """
    # The base language code (e.g., 1033 for English).
    base_language: Optional[int] = None
    # Currency settings for environment provisioning.
    currency: Optional[CreateEnvironmentRequestCurrency] = None
    # The domain name.
    domain_name: Optional[str] = None
    # The security group ID.
    security_group_id: Optional[str] = None
    # A JSON object payload customized for the selected templates.
    template_metadata: Optional[CreateEnvironmentRequestLinkedMetadata_templateMetadata] = None
    # The templates to apply.
    templates: Optional[list[str]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CreateEnvironmentRequestLinkedMetadata:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CreateEnvironmentRequestLinkedMetadata
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CreateEnvironmentRequestLinkedMetadata()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .create_environment_request_currency import CreateEnvironmentRequestCurrency
        from .create_environment_request_linked_metadata_template_metadata import CreateEnvironmentRequestLinkedMetadata_templateMetadata

        from .create_environment_request_currency import CreateEnvironmentRequestCurrency
        from .create_environment_request_linked_metadata_template_metadata import CreateEnvironmentRequestLinkedMetadata_templateMetadata

        fields: dict[str, Callable[[Any], None]] = {
            "baseLanguage": lambda n : setattr(self, 'base_language', n.get_int_value()),
            "currency": lambda n : setattr(self, 'currency', n.get_object_value(CreateEnvironmentRequestCurrency)),
            "domainName": lambda n : setattr(self, 'domain_name', n.get_str_value()),
            "securityGroupId": lambda n : setattr(self, 'security_group_id', n.get_str_value()),
            "templateMetadata": lambda n : setattr(self, 'template_metadata', n.get_object_value(CreateEnvironmentRequestLinkedMetadata_templateMetadata)),
            "templates": lambda n : setattr(self, 'templates', n.get_collection_of_primitive_values(str)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("baseLanguage", self.base_language)
        writer.write_object_value("currency", self.currency)
        writer.write_str_value("domainName", self.domain_name)
        writer.write_str_value("securityGroupId", self.security_group_id)
        writer.write_object_value("templateMetadata", self.template_metadata)
        writer.write_collection_of_primitive_values("templates", self.templates)
    

