from enum import Enum

class ActionResponse(str, Enum):
    NotSpecified = "NotSpecified",
    Approved = "Approved",
    Rejected = "Rejected",
    Pending = "Pending",

