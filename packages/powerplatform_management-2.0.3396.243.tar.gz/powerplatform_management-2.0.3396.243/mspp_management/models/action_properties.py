from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .api_properties import ApiProperties
    from .connection_properties import ConnectionProperties
    from .operation_properties import OperationProperties

@dataclass
class ActionProperties(AdditionalDataHolder, Parsable):
    """
    Identifies the connector action being invoked.
    """
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # Identifies the API for a connector action.
    api: Optional[ApiProperties] = None
    # Connection details for a connector action.
    connection: Optional[ConnectionProperties] = None
    # Whether this is an agent-to-agent server call.
    is_a2a_server_call: Optional[bool] = None
    # Identifies the specific operation within a connector.
    operation: Optional[OperationProperties] = None
    # Name of the server handling the action.
    server_name: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ActionProperties:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ActionProperties
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ActionProperties()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .api_properties import ApiProperties
        from .connection_properties import ConnectionProperties
        from .operation_properties import OperationProperties

        from .api_properties import ApiProperties
        from .connection_properties import ConnectionProperties
        from .operation_properties import OperationProperties

        fields: dict[str, Callable[[Any], None]] = {
            "api": lambda n : setattr(self, 'api', n.get_object_value(ApiProperties)),
            "connection": lambda n : setattr(self, 'connection', n.get_object_value(ConnectionProperties)),
            "isA2aServerCall": lambda n : setattr(self, 'is_a2a_server_call', n.get_bool_value()),
            "operation": lambda n : setattr(self, 'operation', n.get_object_value(OperationProperties)),
            "serverName": lambda n : setattr(self, 'server_name', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("api", self.api)
        writer.write_object_value("connection", self.connection)
        writer.write_bool_value("isA2aServerCall", self.is_a2a_server_call)
        writer.write_object_value("operation", self.operation)
        writer.write_str_value("serverName", self.server_name)
        writer.write_additional_data_value(self.additional_data)
    

