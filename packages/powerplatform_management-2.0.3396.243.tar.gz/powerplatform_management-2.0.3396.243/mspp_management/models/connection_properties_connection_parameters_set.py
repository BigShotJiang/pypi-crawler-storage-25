from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .connection_properties_connection_parameters_set_values import Connection_properties_connectionParametersSet_values

@dataclass
class Connection_properties_connectionParametersSet(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The name property
    name: Optional[str] = None
    # The values property
    values: Optional[Connection_properties_connectionParametersSet_values] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Connection_properties_connectionParametersSet:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Connection_properties_connectionParametersSet
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Connection_properties_connectionParametersSet()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .connection_properties_connection_parameters_set_values import Connection_properties_connectionParametersSet_values

        from .connection_properties_connection_parameters_set_values import Connection_properties_connectionParametersSet_values

        fields: dict[str, Callable[[Any], None]] = {
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "values": lambda n : setattr(self, 'values', n.get_object_value(Connection_properties_connectionParametersSet_values)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("name", self.name)
        writer.write_object_value("values", self.values)
        writer.write_additional_data_value(self.additional_data)
    

