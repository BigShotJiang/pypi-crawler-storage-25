from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .....models.fin_ops_admin_settings_response import FinOpsAdminSettingsResponse
    from .....models.fin_ops_error_response import FinOpsErrorResponse
    from .....models.update_fin_ops_admin_settings_request_body import UpdateFinOpsAdminSettingsRequestBody

class FinopsadminsettingsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /dynamics/environments/{environmentId}/finopsadminsettings
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new FinopsadminsettingsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/dynamics/environments/{environmentId}/finopsadminsettings?api-version={api%2Dversion}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[FinopsadminsettingsRequestBuilderGetQueryParameters]] = None) -> Optional[FinOpsAdminSettingsResponse]:
        """
        Retrieves the F&O maintenance settings for an environment managed by Power Platform admin center.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[FinOpsAdminSettingsResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        from .....models.fin_ops_error_response import FinOpsErrorResponse

        error_mapping: dict[str, type[ParsableFactory]] = {
            "400": FinOpsErrorResponse,
            "401": FinOpsErrorResponse,
            "403": FinOpsErrorResponse,
            "404": FinOpsErrorResponse,
            "500": FinOpsErrorResponse,
        }
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.fin_ops_admin_settings_response import FinOpsAdminSettingsResponse

        return await self.request_adapter.send_async(request_info, FinOpsAdminSettingsResponse, error_mapping)
    
    async def put(self,body: UpdateFinOpsAdminSettingsRequestBody, request_configuration: Optional[RequestConfiguration[FinopsadminsettingsRequestBuilderPutQueryParameters]] = None) -> Optional[FinOpsAdminSettingsResponse]:
        """
        Updates the F&O maintenance settings for an environment managed by Power Platform admin center.
        param body: Request body for updating Finance and Operations Maintenance.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[FinOpsAdminSettingsResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_put_request_information(
            body, request_configuration
        )
        from .....models.fin_ops_error_response import FinOpsErrorResponse

        error_mapping: dict[str, type[ParsableFactory]] = {
            "400": FinOpsErrorResponse,
            "401": FinOpsErrorResponse,
            "403": FinOpsErrorResponse,
            "404": FinOpsErrorResponse,
            "500": FinOpsErrorResponse,
        }
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .....models.fin_ops_admin_settings_response import FinOpsAdminSettingsResponse

        return await self.request_adapter.send_async(request_info, FinOpsAdminSettingsResponse, error_mapping)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[FinopsadminsettingsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        Retrieves the F&O maintenance settings for an environment managed by Power Platform admin center.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_put_request_information(self,body: UpdateFinOpsAdminSettingsRequestBody, request_configuration: Optional[RequestConfiguration[FinopsadminsettingsRequestBuilderPutQueryParameters]] = None) -> RequestInformation:
        """
        Updates the F&O maintenance settings for an environment managed by Power Platform admin center.
        param body: Request body for updating Finance and Operations Maintenance.
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.PUT, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> FinopsadminsettingsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: FinopsadminsettingsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return FinopsadminsettingsRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class FinopsadminsettingsRequestBuilderGetQueryParameters():
        """
        Retrieves the F&O maintenance settings for an environment managed by Power Platform admin center.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "api_version":
                return "api%2Dversion"
            return original_name
        
        # The API version.
        api_version: Optional[str] = None

    
    @dataclass
    class FinopsadminsettingsRequestBuilderGetRequestConfiguration(RequestConfiguration[FinopsadminsettingsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class FinopsadminsettingsRequestBuilderPutQueryParameters():
        """
        Updates the F&O maintenance settings for an environment managed by Power Platform admin center.
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "api_version":
                return "api%2Dversion"
            return original_name
        
        # The API version.
        api_version: Optional[str] = None

    
    @dataclass
    class FinopsadminsettingsRequestBuilderPutRequestConfiguration(RequestConfiguration[FinopsadminsettingsRequestBuilderPutQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

