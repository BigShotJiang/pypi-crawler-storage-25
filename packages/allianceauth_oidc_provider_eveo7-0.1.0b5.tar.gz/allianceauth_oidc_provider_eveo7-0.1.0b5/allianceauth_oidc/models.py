"""Custom OAuth2 Application model with AA state/group access policy."""

from allianceauth.authentication.models import State
from django.contrib.auth.models import Group
from django.core.validators import URLValidator
from django.db import models
from django.utils.translation import gettext_lazy as _
from oauth2_provider.models import AbstractApplication
from typing_extensions import override

from .constants import PERM_ACCESS_OIDC_CODENAME


class AllianceAuthApplication(AbstractApplication):
    """OAuth2 Application restricted by Alliance Auth states and groups."""

    logo_url = models.URLField(
        max_length=1024,
        blank=True,
        default="",
        # The default URLValidator allows ftp/ftps too, which are useless
        # for an `<img src>` and only widen the surface for stored XSS via
        # `data:`/`javascript:` hand-crafted around browser quirks.
        # Restrict to the two schemes we actually render.
        validators=[URLValidator(schemes=["http", "https"])],
        help_text=_(
            "URL to the application's icon (128x128). Can be a local static-file URL or an absolute http(s) URL."  # noqa: E501
        ),
    )
    states = models.ManyToManyField(State, blank=True)
    groups = models.ManyToManyField(Group, blank=True)
    active = models.BooleanField(default=True)
    debug_mode = models.BooleanField(
        default=False,
        help_text=_(
            "Enables additional OIDC debug logging (INFO). Secrets/tokens are always redacted/masked according to settings."  # noqa: E501
        ),
    )
    pkce_required = models.BooleanField(
        default=True,
        verbose_name=_("PKCE required"),
        help_text=_(
            "If enabled, this application must use PKCE on the authorization endpoint (RFC 7636 / 9700). Disable only for known-incompatible clients; new applications default to enabled."  # noqa: E501
        ),
    )

    @override
    def is_usable(self, request):
        """
        Return whether the application is usable.

        The ``request`` argument is required by django-oauth-toolkit's
        ``AbstractApplication`` contract (parameter name must match for type-
        checker override compatibility) but unused — the active flag is a
        property of the app itself, independent of the incoming
        ``oauthlib.common.Request``. The ``@override`` decorator makes the
        contract a checker-enforced invariant: if DOT ever renames or
        removes ``is_usable``, mypy / basedpyright fails the build instead
        of silently letting ``active=False`` apps issue tokens.
        """
        return self.active

    class Meta:
        # `ordering` makes the admin changelist's pagination stable.
        # Without it, PostgreSQL returns rows in storage order, which
        # shifts as updates rewrite tuples — page 2 today is not page 2
        # tomorrow. `name` matches the admin's primary search field.
        ordering = ("name",)
        verbose_name = _("Alliance Auth OIDC application")
        verbose_name_plural = _("Alliance Auth OIDC applications")
        permissions = [
            (
                PERM_ACCESS_OIDC_CODENAME,
                _("Can Authenticate External Apps with OIDC"),
            )
        ]
