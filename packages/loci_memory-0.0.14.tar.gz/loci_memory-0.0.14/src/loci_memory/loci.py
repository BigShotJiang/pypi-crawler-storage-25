# loci_memory.py
from typing import Any, Dict, List, TypedDict, Union
from mcp.server.fastmcp import FastMCP          #   Framework for building MCP Applications
import os                                       #   Python os Module
import argparse                                 #   Argument parser
from holographic import HolographicMemoryProvider

# Create an MCP server
mcp = FastMCP(
        "LOCI",
        instructions="Provides memory capabilities to an LLM. Start with get_summary() for an overview.")

# Global variables

memory_provider = HolographicMemoryProvider()

#
#   Create Parser
#
def create_parser():
    """Create and return the argument parser."""
    parser = argparse.ArgumentParser(description='FastMCP server for Holographic Memory')
    parser.add_argument('--data-dir',
                       default=os.getenv('LOCI_DATA_DIR'),
                       help='Directory for persistent client data')

    return parser

#
#   Memory Tools
#
@mcp.tool(
    name="Prompt",
    description="Holographic Memory Prompt."
)
async def system_prompt_block() ->str:
    return memory_provider.system_prompt_block()

@mcp.tool(
    name="Tool.Schemas",
    description="Returns the available tool names, their description and it's parameters"
)
async def get_tool_schemas() -> List[Dict[str, Any]]:
    return memory_provider.get_tool_schemas()

@mcp.tool(
    name="Tool.Call",
    description="""Perform Storage/Retrievel of memories.
        Usage rules available by calling Tool.Schemas
    """
)
async def handle_tool_call(tool_name: str, args: Dict[str, Any]) -> str:
    return memory_provider.handle_tool_call(tool_name, args)


def main():
    """Entry point for the Holographic Memory server."""
    parser = create_parser()
    parser.add_argument(
        "--transport",
        type=str,
        choices=["stdio", "http"],
        default="stdio",
        help="Transport mode: 'stdio' or 'http'",
    )
    args = parser.parse_args()
   
    # Initialize memory Provider
    memory_provider.initialize("")

    # Initialize and run the server
    print("Starting MCP server")
    transport_mode = "streamable-http" if args.transport == "http" else args.transport
    print(f"Running in {transport_mode} mode")
    mcp.run(transport=transport_mode)

    #   http://localhost:8000/mcp


#
#   Declare the tool set
#
"""
@mcp.tool(
   name="find_products",           # Custom tool name for the LLM
    description="Search the product catalog with optional category filtering.", # Custom description
    tags={"catalog", "search"},      # Optional tags for organization/filtering
    meta={"version": "1.2", "author": "product-team"}  # Custom metadata
)
def test_test(
query: str,
max_results: int = 10,            # Optional - has default value
category: str | None = None       # Optional - can be None
) -> list[dict]:
    "" "Internal function description (ignored if description is provided above)." ""
    # Implementation...
    print(f"Searching for '{query}' in category '{category}'")
    return [{"id": 2, "name": "Another Product"}]
"""

if __name__ == "__main__":
    mcp.run()
    #main()
