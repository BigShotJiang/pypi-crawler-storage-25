"""Tests for `mosesaic orchestrate` command."""
from __future__ import annotations

from typing import Iterator
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from mosesaic.cli.main import app

runner = CliRunner()


# ── SSE line helpers ──────────────────────────────────────────────────────────

def _sse_lines(*events: dict | str) -> Iterator[str]:
    """Yield SSE-formatted lines from dicts or raw data strings."""
    import json
    for event in events:
        if isinstance(event, dict):
            yield f"data: {json.dumps(event)}"
        else:
            yield f"data: {event}"


# ── Mock builders ─────────────────────────────────────────────────────────────

def _mock_post_resp(run_id: str = "run-abc-123") -> MagicMock:
    resp = MagicMock()
    resp.is_success = True
    resp.json.return_value = {"run_id": run_id, "status": "running"}
    return resp


def _mock_stream_ctx(lines: list[str]) -> MagicMock:
    """Return a mock context manager whose iter_lines() yields *lines*."""
    stream_resp = MagicMock()
    stream_resp.__enter__ = MagicMock(return_value=stream_resp)
    stream_resp.__exit__ = MagicMock(return_value=False)
    stream_resp.iter_lines = MagicMock(return_value=iter(lines))
    return stream_resp


def _mock_client(post_resp: MagicMock, stream_resp: MagicMock, get_resp: MagicMock | None = None) -> MagicMock:
    """Return a mock httpx.Client that uses *post_resp* for POST and *stream_resp* for SSE.

    *get_resp* is returned for GET calls (used for the result fetch after stream).
    Defaults to a non-success response so existing tests are unaffected.
    """
    if get_resp is None:
        get_resp = MagicMock()
        get_resp.is_success = False
    client = MagicMock()
    client.__enter__ = MagicMock(return_value=client)
    client.__exit__ = MagicMock(return_value=False)
    client.post = MagicMock(return_value=post_resp)
    client.stream = MagicMock(return_value=stream_resp)
    client.get = MagicMock(return_value=get_resp)
    return client


# ── Tests ─────────────────────────────────────────────────────────────────────

def test_orchestrate_happy_path():
    """Full run: POST → stream events → [DONE] → success."""
    lines = list(_sse_lines(
        {"from": "chief_director", "to": "clarify_director", "type": "task", "payload": ""},
        {"from": "clarify_director", "to": "build_director", "type": "task", "payload": ""},
        {"status": "completed", "result": "All phases complete"},
        "[DONE]",
    ))
    post_resp = _mock_post_resp("run-123")
    stream_ctx = _mock_stream_ctx(lines)
    client = _mock_client(post_resp, stream_ctx)

    with patch("httpx.Client", return_value=client):
        result = runner.invoke(app, ["orchestrate", "Add a health check endpoint"])

    assert result.exit_code == 0
    assert "Orchestrating" in result.output
    assert "run-123" in result.output
    assert "complete" in result.output.lower()


def test_orchestrate_shows_phases():
    """Phase director transitions are printed as they arrive."""
    lines = list(_sse_lines(
        {"from": "wf", "to": "clarify_director", "type": "task", "payload": ""},
        {"from": "wf", "to": "build_director", "type": "task", "payload": ""},
        {"status": "completed"},
        "[DONE]",
    ))
    post_resp = _mock_post_resp()
    stream_ctx = _mock_stream_ctx(lines)
    client = _mock_client(post_resp, stream_ctx)

    with patch("httpx.Client", return_value=client):
        result = runner.invoke(app, ["orchestrate", "Fix the bug"])

    assert result.exit_code == 0
    assert "Clarify" in result.output
    assert "Build" in result.output


def test_orchestrate_connect_error():
    """ConnectError → user-friendly message, exit 1."""
    import httpx

    with patch("httpx.Client") as MockClient:
        mock = MagicMock()
        mock.__enter__ = MagicMock(return_value=mock)
        mock.__exit__ = MagicMock(return_value=False)
        mock.post.side_effect = httpx.ConnectError("refused")
        MockClient.return_value = mock

        result = runner.invoke(app, ["orchestrate", "Add feature"])

    assert result.exit_code == 1
    assert "Cannot connect" in result.output


def test_orchestrate_server_error():
    """Non-2xx POST response → error message, exit 1."""
    post_resp = MagicMock()
    post_resp.is_success = False
    post_resp.status_code = 500
    post_resp.text = "internal server error"

    client = MagicMock()
    client.__enter__ = MagicMock(return_value=client)
    client.__exit__ = MagicMock(return_value=False)
    client.post = MagicMock(return_value=post_resp)

    with patch("httpx.Client", return_value=client):
        result = runner.invoke(app, ["orchestrate", "do something"])

    assert result.exit_code == 1
    assert "500" in result.output


def test_orchestrate_timeout():
    """httpx.TimeoutException during streaming → error message, exit 1."""
    import httpx

    post_resp = _mock_post_resp()

    stream_ctx = MagicMock()
    stream_ctx.__enter__ = MagicMock(return_value=stream_ctx)
    stream_ctx.__exit__ = MagicMock(return_value=False)
    stream_ctx.iter_lines = MagicMock(side_effect=httpx.TimeoutException("timed out"))

    client = _mock_client(post_resp, stream_ctx)

    with patch("httpx.Client", return_value=client):
        result = runner.invoke(app, ["orchestrate", "slow task", "--timeout", "1"])

    assert result.exit_code == 1
    assert "did not complete" in result.output


def test_orchestrate_failed_status():
    """status=failed in SSE → error message, exit 1."""
    lines = list(_sse_lines(
        {"status": "failed", "result": "build error"},
        "[DONE]",
    ))
    post_resp = _mock_post_resp()
    stream_ctx = _mock_stream_ctx(lines)
    client = _mock_client(post_resp, stream_ctx)

    with patch("httpx.Client", return_value=client):
        result = runner.invoke(app, ["orchestrate", "broken prompt"])

    assert result.exit_code == 1


def test_orchestrate_custom_server_url():
    """--server flag sets the base URL on both the POST client and stream client."""
    lines = list(_sse_lines({"status": "completed"}, "[DONE]"))
    post_resp = _mock_post_resp()
    stream_ctx = _mock_stream_ctx(lines)
    client = _mock_client(post_resp, stream_ctx)

    with patch("httpx.Client", return_value=client) as MockClient:
        runner.invoke(app, ["orchestrate", "task", "--server", "http://remote:9000"])

    assert len(MockClient.call_args_list) == 3
    for i, call in enumerate(MockClient.call_args_list):
        assert call[1].get("base_url") == "http://remote:9000", f"Client call {i} had wrong base_url"


def test_orchestrate_done_without_status_event():
    """[DONE] with no status event → treated as completed."""
    lines = list(_sse_lines("[DONE]"))
    post_resp = _mock_post_resp()
    stream_ctx = _mock_stream_ctx(lines)
    client = _mock_client(post_resp, stream_ctx)

    with patch("httpx.Client", return_value=client):
        result = runner.invoke(app, ["orchestrate", "simple task"])

    assert result.exit_code == 0


def test_orchestrate_stream_connect_error():
    """ConnectError during SSE streaming → error message, exit 1."""
    import httpx

    post_resp = _mock_post_resp()

    stream_ctx = MagicMock()
    stream_ctx.__enter__ = MagicMock(return_value=stream_ctx)
    stream_ctx.__exit__ = MagicMock(return_value=False)
    stream_ctx.iter_lines = MagicMock(side_effect=httpx.ConnectError("dropped"))

    client = _mock_client(post_resp, stream_ctx)

    with patch("httpx.Client", return_value=client):
        result = runner.invoke(app, ["orchestrate", "something"])

    assert result.exit_code == 1
    assert "Lost connection" in result.output


def test_orchestrate_malformed_sse_lines_ignored():
    """Malformed JSON lines in SSE stream are skipped; valid ones still processed."""
    lines = list(_sse_lines(
        "not-even-data",          # no 'data: ' prefix — skipped
        '{"broken": json}',       # will be emitted as data: but malformed — skipped
        {"from": "wf", "to": "build_director", "type": "task", "payload": ""},
        {"status": "completed"},
        "[DONE]",
    ))
    # Replace the second entry (already has no 'data: ' prefix handling)
    # Make one line have 'data: ' but invalid JSON
    lines[1] = "data: {broken json}"
    post_resp = _mock_post_resp()
    stream_ctx = _mock_stream_ctx(lines)
    client = _mock_client(post_resp, stream_ctx)

    with patch("httpx.Client", return_value=client):
        result = runner.invoke(app, ["orchestrate", "robust task"])

    assert result.exit_code == 0
    assert "Build" in result.output


def test_orchestrate_renders_cost_table():
    """CLI fetches /orchestrate/{run_id} after stream and renders cost table."""
    import json as _json

    lines = list(_sse_lines(
        {"from": "wf", "to": "clarify_director", "type": "task", "payload": ""},
        {"status": "completed"},
        "[DONE]",
    ))
    post_resp = _mock_post_resp("run-cost-123")
    stream_ctx = _mock_stream_ctx(lines)

    get_resp = MagicMock()
    get_resp.is_success = True
    get_resp.json.return_value = {
        "run_id": "run-cost-123",
        "status": "completed",
        "error": None,
        "completed_at": "2026-04-09T12:00:00",
        "request_type": "feature",
        "phases_run": ["clarify", "architect"],
        "reasoning": "Standard feature.",
        "total_cost_usd": 0.025,
        "run_log": [
            {"phase": "clarify", "summary": "Requirements clarified.", "cost_usd": 0.012},
            {"phase": "architect", "summary": "Design spec produced.", "cost_usd": 0.013},
        ],
    }
    client = _mock_client(post_resp, stream_ctx, get_resp)

    with patch("httpx.Client", return_value=client):
        result = runner.invoke(app, ["orchestrate", "Add a health check"])

    assert result.exit_code == 0
    assert "clarify" in result.output
    assert "architect" in result.output
    assert "$0.013" in result.output
    assert "Total" in result.output
    assert "$0.025" in result.output
