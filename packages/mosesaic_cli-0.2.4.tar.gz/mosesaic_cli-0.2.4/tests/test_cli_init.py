"""Tests for `mosesaic init` CLI command."""
from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from mosesaic.cli.main import app

runner = CliRunner()


# ── Template mode ─────────────────────────────────────────────────────────────

def test_init_template_creates_mosesaic_toml(tmp_path):
    """mosesaic init writes mosesaic.toml in cwd."""
    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(app, ["init"], catch_exceptions=False)
    assert result.exit_code == 0
    assert "Written" in result.output
    assert "mosesaic.toml" in result.output


def test_init_template_file_content(tmp_path):
    """mosesaic init writes a file containing [server] and [[provider]] blocks."""
    with runner.isolated_filesystem(temp_dir=tmp_path):
        runner.invoke(app, ["init"])
        content = Path("mosesaic.toml").read_text()
    assert "[server]" in content
    assert "[[provider]]" in content
    assert "host = " in content
    assert "port = " in content


def test_init_template_errors_if_file_exists(tmp_path):
    """mosesaic init exits 1 if mosesaic.toml already exists."""
    with runner.isolated_filesystem(temp_dir=tmp_path):
        Path("mosesaic.toml").write_text("# existing")
        result = runner.invoke(app, ["init"])
    assert result.exit_code == 1
    assert "already exists" in result.output.lower() or "already exists" in (result.stderr or "").lower()


def test_init_force_overwrites_existing(tmp_path):
    """mosesaic init --force overwrites an existing mosesaic.toml."""
    with runner.isolated_filesystem(temp_dir=tmp_path):
        Path("mosesaic.toml").write_text("# old")
        result = runner.invoke(app, ["init", "--force"])
        content = Path("mosesaic.toml").read_text()
    assert result.exit_code == 0
    assert content != "# old"
    assert "[server]" in content


def test_init_creates_home_mosesaic_dir(tmp_path, monkeypatch):
    """mosesaic init creates ~/.mosesaic/ if it doesn't exist."""
    fake_home = tmp_path / "fake_home"
    fake_home.mkdir()
    monkeypatch.setenv("HOME", str(fake_home))  # Path.home() reads HOME on POSIX
    with runner.isolated_filesystem(temp_dir=tmp_path):
        runner.invoke(app, ["init"])
    assert (fake_home / ".mosesaic").exists()


# ── Interactive mode ──────────────────────────────────────────────────────────

def test_init_interactive_single_provider_with_key(tmp_path):
    """Interactive mode with Anthropic + key writes api_key to file."""
    inputs = "1\nsk-ant-test\n"  # pick Anthropic, enter key
    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(app, ["init", "--interactive"], input=inputs, catch_exceptions=False)
        content = Path("mosesaic.toml").read_text()
    assert result.exit_code == 0
    assert 'name = "anthropic"' in content
    assert 'api_key = "sk-ant-test"' in content


def test_init_interactive_blank_key_omits_api_key(tmp_path):
    """Interactive mode with blank key omits api_key field (env var used at runtime)."""
    inputs = "1\n\n"  # pick Anthropic, blank key
    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(app, ["init", "--interactive"], input=inputs, catch_exceptions=False)
        content = Path("mosesaic.toml").read_text()
    assert result.exit_code == 0
    assert 'name = "anthropic"' in content
    assert "api_key" not in content


def test_init_interactive_ollama_no_key_prompt(tmp_path):
    """Interactive mode with Ollama writes base_url, no API key prompt."""
    inputs = "6\n"  # pick Ollama only
    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(app, ["init", "--interactive"], input=inputs, catch_exceptions=False)
        content = Path("mosesaic.toml").read_text()
    assert result.exit_code == 0
    assert 'name = "ollama"' in content
    assert 'base_url = "http://localhost:11434"' in content
    assert "api_key" not in content


def test_init_interactive_skip_zero(tmp_path):
    """Interactive mode with 0 writes no providers (only [server] block)."""
    inputs = "0\n"
    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(app, ["init", "--interactive"], input=inputs, catch_exceptions=False)
        content = Path("mosesaic.toml").read_text()
    assert result.exit_code == 0
    assert "[server]" in content
    assert "[[provider]]" not in content


def test_init_interactive_multiple_providers(tmp_path):
    """Interactive mode with '1 3' writes Anthropic + Gemini blocks."""
    inputs = "1 3\nsk-ant-key\nAIza-key\n"
    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(app, ["init", "--interactive"], input=inputs, catch_exceptions=False)
        content = Path("mosesaic.toml").read_text()
    assert result.exit_code == 0
    assert 'name = "anthropic"' in content
    assert 'name = "gemini"' in content
    assert 'api_key = "sk-ant-key"' in content
    assert 'api_key = "AIza-key"' in content
