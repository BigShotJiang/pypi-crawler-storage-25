"""Shared fixtures for CLI tests."""
import textwrap
from pathlib import Path

import pytest


@pytest.fixture
def agent_file(tmp_path: Path) -> Path:
    """Write a minimal agent Python file and return its path."""
    content = textwrap.dedent("""
        from mosesaic.core.agent import agent
        from mosesaic.core.context import AgentContext

        @agent(name="greeter")
        async def greeter(ctx: AgentContext) -> None:
            msg = await ctx.receive()
            # agent exits cleanly after receiving one message
    """)
    p = tmp_path / "test_agents.py"
    p.write_text(content)
    return p


@pytest.fixture
def event_log_file(tmp_path: Path) -> Path:
    """Write a minimal event log JSON file and return its path."""
    import json
    log = [
        {
            "from_agent": "__runtime__",
            "to_agent": "greeter",
            "type": "task",
            "payload": "hello",
            "trace_id": "00000000-0000-0000-0000-000000000001",
        },
        {
            "from_agent": "greeter",
            "to_agent": "writer",
            "type": "result",
            "payload": "done",
            "trace_id": "00000000-0000-0000-0000-000000000001",
        },
    ]
    p = tmp_path / "events.json"
    p.write_text(json.dumps(log))
    return p
