"""Tests for `mosesaic replay` command."""
from pathlib import Path
from typer.testing import CliRunner
from mosesaic.cli.main import app

runner = CliRunner()


def test_replay_dry_run(event_log_file: Path, agent_file: Path):
    spec = f"{agent_file}:greeter"
    result = runner.invoke(app, [
        "replay", str(event_log_file),
        "--agent", spec,
        "--dry-run",
    ])
    assert result.exit_code == 0
    assert "Would replay" in result.output
    assert "greeter" in result.output


def test_replay_no_matching_messages(event_log_file: Path, tmp_path: Path):
    """Agent with different name — no messages match."""
    import textwrap
    f = tmp_path / "other.py"
    f.write_text(textwrap.dedent("""
        from mosesaic.core.agent import agent
        from mosesaic.core.context import AgentContext

        @agent(name="other-agent")
        async def other_agent(ctx: AgentContext) -> None:
            await ctx.receive()
    """))
    spec = f"{f}:other_agent"
    result = runner.invoke(app, [
        "replay", str(event_log_file),
        "--agent", spec,
        "--dry-run",
    ])
    assert result.exit_code == 0
    assert "No messages" in result.output


def test_replay_executes(event_log_file: Path, agent_file: Path):
    spec = f"{agent_file}:greeter"
    result = runner.invoke(app, [
        "replay", str(event_log_file),
        "--agent", spec,
        "--timeout", "5",
    ])
    assert result.exit_code == 0
    assert "Replay complete" in result.output


def test_replay_missing_log():
    result = runner.invoke(app, [
        "replay", "/no/such/file.json",
        "--agent", "mod:agent",
    ])
    assert result.exit_code == 1
