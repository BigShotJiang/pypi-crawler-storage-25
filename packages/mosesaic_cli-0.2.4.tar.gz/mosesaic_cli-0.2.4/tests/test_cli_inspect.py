"""Tests for `mosesaic inspect` command."""
from pathlib import Path
from typer.testing import CliRunner
from mosesaic.cli.main import app

runner = CliRunner()


def test_inspect_shows_events(event_log_file: Path):
    result = runner.invoke(app, ["inspect", str(event_log_file)])
    assert result.exit_code == 0
    assert "__runtime__" in result.output
    assert "greeter" in result.output


def test_inspect_filter_by_agent(event_log_file: Path):
    result = runner.invoke(app, ["inspect", str(event_log_file), "--agent", "greeter"])
    assert result.exit_code == 0
    assert "greeter" in result.output


def test_inspect_filter_by_trace(event_log_file: Path):
    result = runner.invoke(app, ["inspect", str(event_log_file), "--trace", "00000000"])
    assert result.exit_code == 0
    assert "greeter" in result.output


def test_inspect_filter_no_match(event_log_file: Path):
    result = runner.invoke(app, ["inspect", str(event_log_file), "--trace", "ffffffff"])
    assert result.exit_code == 0
    assert "No matching" in result.output


def test_inspect_missing_file():
    result = runner.invoke(app, ["inspect", "/nonexistent/events.json"])
    assert result.exit_code == 1


def test_inspect_invalid_json(tmp_path: Path):
    bad = tmp_path / "bad.json"
    bad.write_text("not json {{{")
    result = runner.invoke(app, ["inspect", str(bad)])
    assert result.exit_code == 1
