"""Tests for `mosesaic serve` CLI command."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from mosesaic.cli.main import app

runner = CliRunner()


def test_serve_delegates_to_serve_main():
    """mosesaic serve delegates to mosesaic.team.serve.main."""
    mock_serve = MagicMock()
    with patch.dict("sys.modules", {"mosesaic.team.serve": MagicMock(main=mock_serve)}):
        result = runner.invoke(app, ["serve"])
    assert result.exit_code == 0
    mock_serve.assert_called_once_with(host=None, port=None, with_mcp=False)


def test_serve_with_mcp_flag():
    """mosesaic serve --with-mcp passes with_mcp=True."""
    mock_serve = MagicMock()
    with patch.dict("sys.modules", {"mosesaic.team.serve": MagicMock(main=mock_serve)}):
        result = runner.invoke(app, ["serve", "--with-mcp"])
    assert result.exit_code == 0
    mock_serve.assert_called_once_with(host=None, port=None, with_mcp=True)


def test_serve_host_port_flags():
    """mosesaic serve --host / --port are forwarded to serve.main."""
    mock_serve = MagicMock()
    with patch.dict("sys.modules", {"mosesaic.team.serve": MagicMock(main=mock_serve)}):
        result = runner.invoke(app, ["serve", "--host", "0.0.0.0", "--port", "9000"])
    assert result.exit_code == 0
    mock_serve.assert_called_once_with(host="0.0.0.0", port=9000, with_mcp=False)


def test_serve_import_error_prints_install_hint():
    """mosesaic serve prints a helpful error and exits 1 if mosesaic-team is not installed."""
    import sys
    # Setting sys.modules entry to None causes ImportError when the module is imported.
    # Save + restore all mosesaic.team.* entries around the test.
    saved = {k: v for k, v in sys.modules.items() if "mosesaic.team" in k}
    for k in saved:
        del sys.modules[k]
    sys.modules["mosesaic.team.serve"] = None  # type: ignore[assignment]
    try:
        result = runner.invoke(app, ["serve"])
    finally:
        for k in [k for k in sys.modules if "mosesaic.team" in k]:
            del sys.modules[k]
        sys.modules.update(saved)
    assert result.exit_code == 1
    assert "mosesaic-team" in result.output
