"""Tests for `mosesaic agents` command."""
from pathlib import Path
from typer.testing import CliRunner
from mosesaic.cli.main import app

runner = CliRunner()


def test_agents_lists_definitions(agent_file: Path):
    result = runner.invoke(app, ["agents", str(agent_file)])
    assert result.exit_code == 0
    assert "greeter" in result.output


def test_agents_no_definitions(tmp_path: Path):
    empty = tmp_path / "empty.py"
    empty.write_text("x = 1\n")
    result = runner.invoke(app, ["agents", str(empty)])
    assert result.exit_code == 0
    assert "No agents found" in result.output


def test_agents_missing_file():
    result = runner.invoke(app, ["agents", "/nonexistent/file.py"])
    assert result.exit_code == 1
