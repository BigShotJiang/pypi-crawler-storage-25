"""Tests for `mosesaic run` command."""
from pathlib import Path
from typer.testing import CliRunner
from mosesaic.cli.main import app

runner = CliRunner()


def test_run_agent_with_payload(agent_file: Path):
    spec = f"{agent_file}:greeter"
    result = runner.invoke(app, ["run", spec, "--payload", "hello", "--timeout", "5"])
    assert result.exit_code == 0
    assert "completed" in result.output


def test_run_agent_with_json_payload(agent_file: Path):
    spec = f"{agent_file}:greeter"
    result = runner.invoke(app, ["run", spec, "--payload", '{"key": "value"}', "--timeout", "5"])
    assert result.exit_code == 0


def test_run_with_log_flag(agent_file: Path):
    spec = f"{agent_file}:greeter"
    result = runner.invoke(app, ["run", spec, "--payload", "test", "--log", "--timeout", "5"])
    assert result.exit_code == 0
    assert "Event Log" in result.output


def test_run_invalid_spec():
    result = runner.invoke(app, ["run", "no_colon_here"])
    assert result.exit_code == 1


def test_run_missing_attribute(agent_file: Path):
    spec = f"{agent_file}:nonexistent"
    result = runner.invoke(app, ["run", spec])
    assert result.exit_code == 1


def test_run_timeout(tmp_path: Path):
    """Agent that never exits — should timeout."""
    import textwrap
    f = tmp_path / "blocking.py"
    f.write_text(textwrap.dedent("""
        from mosesaic.core.agent import agent
        from mosesaic.core.context import AgentContext
        import anyio

        @agent(name="blocker")
        async def blocker(ctx: AgentContext) -> None:
            await anyio.sleep(9999)  # never exits
    """))
    spec = f"{f}:blocker"
    result = runner.invoke(app, ["run", spec, "--timeout", "0.1"])
    assert result.exit_code == 1
    assert "did not complete" in result.output
