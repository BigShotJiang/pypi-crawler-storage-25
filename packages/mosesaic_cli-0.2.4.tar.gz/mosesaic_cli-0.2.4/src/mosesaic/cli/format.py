"""Rich formatting helpers shared across CLI commands."""
from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text

if TYPE_CHECKING:
    from mosesaic.core.message import AgentMessage

console = Console()
err_console = Console(stderr=True)


def print_event_log(messages: list[AgentMessage], title: str = "Event Log") -> None:
    table = Table(title=title, show_lines=True)
    table.add_column("#", style="dim", width=4)
    table.add_column("From", style="cyan")
    table.add_column("To", style="green")
    table.add_column("Type", style="yellow")
    table.add_column("Payload", style="white", no_wrap=False, max_width=60)
    table.add_column("Trace ID", style="dim", width=12)

    for i, msg in enumerate(messages):
        payload_str = str(msg.payload)
        if len(payload_str) > 80:
            payload_str = payload_str[:77] + "..."
        table.add_row(
            str(i),
            msg.from_agent,
            msg.to_agent,
            msg.type.value,
            payload_str,
            str(msg.trace_id)[:8],
        )
    console.print(table)


def print_cost_summary(total_usd: float, by_agent: dict[str, float] | None = None) -> None:
    table = Table(title="Cost Summary", show_lines=True)
    table.add_column("Agent", style="cyan")
    table.add_column("Cost (USD)", style="green", justify="right")

    if by_agent:
        for agent_name, cost in sorted(by_agent.items(), key=lambda x: -x[1]):
            table.add_row(agent_name, f"${cost:.6f}")
        table.add_row("[bold]TOTAL[/bold]", f"[bold]${total_usd:.6f}[/bold]")
    else:
        table.add_row("all agents", f"${total_usd:.6f}")

    console.print(table)


def print_agent_status(agents: list[dict]) -> None:
    table = Table(title="Registered Agents", show_lines=True)
    table.add_column("Name", style="cyan")
    table.add_column("Budget", style="yellow", justify="right")
    table.add_column("Max Restarts", justify="center")
    table.add_column("On Failure", style="dim")

    for a in agents:
        budget = f"${a['budget_usd']:.2f}" if a.get("budget_usd") else "unlimited"
        table.add_row(
            a["name"],
            budget,
            str(a.get("max_restarts", 3)),
            a.get("on_failure", "restart"),
        )
    console.print(table)


def print_error(msg: str) -> None:
    err_console.print(f"[bold red]Error:[/bold red] {msg}")


def print_success(msg: str) -> None:
    console.print(f"[bold green]✓[/bold green] {msg}")


def print_info(msg: str) -> None:
    console.print(f"[dim]{msg}[/dim]")
