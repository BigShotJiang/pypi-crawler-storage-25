"""Dynamic agent loader — imports agent definitions from Python modules."""
from __future__ import annotations

import importlib
import importlib.util
import sys
from pathlib import Path

from mosesaic.core.agent import AgentDefinition


def load_agent(spec: str) -> AgentDefinition:
    """Load an agent definition from a module:attribute spec.

    Args:
        spec: Either "module.path:agent_name" or "/path/to/file.py:agent_name"

    Returns:
        AgentDefinition instance

    Raises:
        SystemExit: if the module cannot be loaded or attribute not found
    """
    if ":" not in spec:
        raise ValueError(
            f"Invalid agent spec '{spec}'. "
            "Use 'module.path:agent_name' or '/path/to/file.py:agent_name'"
        )

    module_path, attr_name = spec.rsplit(":", 1)

    # File path spec: /path/to/file.py:agent_name
    if module_path.endswith(".py") or "/" in module_path:
        path = Path(module_path).resolve()
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        module_name = path.stem
        spec_obj = importlib.util.spec_from_file_location(module_name, path)
        module = importlib.util.module_from_spec(spec_obj)
        sys.modules[module_name] = module
        spec_obj.loader.exec_module(module)
    else:
        # Python module path: mosesaic.examples.researcher:researcher
        module = importlib.import_module(module_path)

    obj = getattr(module, attr_name, None)
    if obj is None:
        raise AttributeError(f"'{attr_name}' not found in '{module_path}'")
    if not isinstance(obj, AgentDefinition):
        raise TypeError(
            f"'{attr_name}' is a {type(obj).__name__}, expected AgentDefinition. "
            "Did you forget the @agent decorator?"
        )
    return obj


def load_agents_from_module(module_spec: str) -> list[AgentDefinition]:
    """Load all AgentDefinition objects from a module."""
    if module_spec.endswith(".py") or "/" in module_spec:
        path = Path(module_spec).resolve()
        spec_obj = importlib.util.spec_from_file_location(path.stem, path)
        module = importlib.util.module_from_spec(spec_obj)
        spec_obj.loader.exec_module(module)
    else:
        module = importlib.import_module(module_spec)

    return [
        obj for obj in vars(module).values()
        if isinstance(obj, AgentDefinition)
    ]
