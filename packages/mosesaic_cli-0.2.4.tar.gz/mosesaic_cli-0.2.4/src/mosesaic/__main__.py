"""Support `python -m mosesaic` as an alias for the `mosesaic` CLI command."""
from mosesaic.cli.main import app

app()
