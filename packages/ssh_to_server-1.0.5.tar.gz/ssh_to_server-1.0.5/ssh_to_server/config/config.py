import tomllib
from pathlib import Path

import click

from ..utils.ssh_config import parse

CONFIG_PATH = Path.home() / ".config" / "ssh-to-server" / "config.toml"

DEFAULTS = {
    "ssh": {
        "config_path": str(Path.home() / ".ssh" / "config"),
    }
}


def load() -> dict:
    if not CONFIG_PATH.exists():
        return DEFAULTS

    try:
        with CONFIG_PATH.open("rb") as f:
            user_config = tomllib.load(f)
    except (OSError, tomllib.TOMLDecodeError) as e:
        raise click.ClickException(f"Failed to read config file {CONFIG_PATH}: {e}") from e

    config = DEFAULTS.copy()
    for section, values in user_config.items():
        config[section] = {**DEFAULTS.get(section, {}), **values}

    return config


def return_hosts() -> list[dict]:
    cfg = load()
    return parse(cfg["ssh"]["config_path"])


def return_config_file_path() -> str:
    return str(CONFIG_PATH)
