from pathlib import Path

import click


def parse(config_path: str) -> list[dict]:
    path = Path(config_path).expanduser()
    if not path.exists():
        return []

    try:
        content = path.read_text()
    except OSError as e:
        raise click.ClickException(f"Failed to read SSH config {path}: {e}") from e

    hosts = []
    current: dict | None = None

    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        key, _, value = line.partition(" ")
        key = key.lower()
        value = value.strip()

        if key == "host":
            if current is not None:
                hosts.append(current)
            current = {"host": value}
        elif current is not None:
            current[key] = value

    if current is not None:
        hosts.append(current)

    return hosts
