import os
import subprocess

import click
import questionary
from prompt_toolkit.formatted_text import FormattedText

from .config.config import return_config_file_path, return_hosts
from .utils.tag_line import get_random_tagline


def _label(host: dict) -> str:
    return f"{host.get('user', '')}@{host.get('hostname', host['host'])}"


@click.command()
def main():
    try:
        _main()
    except (KeyboardInterrupt, click.exceptions.Abort):
        click.echo("\033[0m")  # reset terminal color
        click.secho("  Aborted.", fg="yellow")


def _main():
    hosts = return_hosts()

    if not hosts:
        click.secho("No hosts found.", fg="red", bold=True)
        click.secho(f"Add hosts to your SSH config: {return_config_file_path()}", fg="yellow")
        return

    tagline = get_random_tagline()
    title = f"  SSH To Server  · {tagline} · "
    border = "─" * (len(title) - 1)
    click.secho(f"\n  ┌{border}┐", fg="cyan")
    click.secho(f" {title}", fg="cyan", bold=True)
    click.secho(f"  └{border}┘\n", fg="cyan")

    for idx, host in enumerate(hosts, start=1):
        num = click.style(f"{idx:>2}.", fg="cyan", bold=True)
        name = click.style(host["host"], bold=True)
        label = click.style(_label(host), fg="bright_black")
        click.echo(f"  {num} {name}  {label}")

    click.echo()

    selected = None
    while selected is None:
        raw = click.prompt(
            click.style("  Enter number or press Enter to use arrow keys", fg="bright_black"),
            default="",
            show_default=False,
            prompt_suffix="\n  > ",
        )

        if raw.strip().isdigit():
            n = int(raw.strip())
            if 1 <= n <= len(hosts):
                selected = hosts[n - 1]
            else:
                click.secho(f"\n  Invalid number. Choose between 1 and {len(hosts)}.\n", fg="red")
        elif raw.strip() == "":
            command_to_clear_console = "cls" if os.name == "nt" else "clear"
            subprocess.run(command_to_clear_console, shell=True)

            choices = [
                questionary.Choice(
                    title=FormattedText(
                        [
                            ("fg:ansicyan bold", f"{idx:>2}. "),
                            ("bold", host["host"]),
                            ("", "  "),
                            ("fg:ansibrightblack", _label(host)),
                        ]
                    ),  # type: ignore
                    value=host,
                )
                for idx, host in enumerate(hosts, start=1)
            ]
            selected = questionary.select(
                "Select a host:",
                choices=choices,
                use_indicator=True,
            ).ask()
            if selected is None:
                return
        else:
            click.secho("\n  Invalid input. Enter a number or press Enter.\n", fg="red")

    name = click.style(selected["host"], bold=True)
    label = click.style(_label(selected), fg="bright_black")
    click.secho("\n  Connecting to ", nl=False, fg="green")
    click.echo(f"{name}  {label}\n")

    import shutil

    if not shutil.which("ssh"):
        raise click.ClickException("ssh binary not found. Please install OpenSSH.")

    os.execvp("ssh", ["ssh", selected["host"]])
