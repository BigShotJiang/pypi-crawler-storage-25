from ssh_to_server.config.config import DEFAULTS, load


def test_returns_defaults_when_no_config_file(tmp_path, monkeypatch):
    monkeypatch.setattr("ssh_to_server.config.config.CONFIG_PATH", tmp_path / "nonexistent.toml")
    cfg = load()
    assert cfg == DEFAULTS


def test_loads_ssh_config_path(tmp_path, monkeypatch):
    config_file = tmp_path / "config.toml"
    config_file.write_text('[ssh]\nconfig_path = "/custom/path/config"\n')
    monkeypatch.setattr("ssh_to_server.config.config.CONFIG_PATH", config_file)
    cfg = load()
    assert cfg["ssh"]["config_path"] == "/custom/path/config"


def test_merges_with_defaults(tmp_path, monkeypatch):
    config_file = tmp_path / "config.toml"
    config_file.write_text("[ssh]\n")
    monkeypatch.setattr("ssh_to_server.config.config.CONFIG_PATH", config_file)
    cfg = load()
    assert "config_path" in cfg["ssh"]


def test_unknown_section_is_included(tmp_path, monkeypatch):
    config_file = tmp_path / "config.toml"
    config_file.write_text("[ui]\ncolor = true\n")
    monkeypatch.setattr("ssh_to_server.config.config.CONFIG_PATH", config_file)
    cfg = load()
    assert cfg["ui"]["color"] is True
