import textwrap

import pytest

from ssh_to_server.utils.ssh_config import parse


@pytest.fixture
def config_file(tmp_path):
    def _write(content):
        p = tmp_path / "config"
        p.write_text(textwrap.dedent(content))
        return str(p)

    return _write


def test_parses_single_host(config_file):
    path = config_file("""
        Host myserver
          HostName 192.168.1.1
          User admin
          IdentityFile ~/.ssh/id_rsa
    """)
    hosts = parse(path)
    assert len(hosts) == 1
    assert hosts[0]["host"] == "myserver"
    assert hosts[0]["hostname"] == "192.168.1.1"
    assert hosts[0]["user"] == "admin"
    assert hosts[0]["identityfile"] == "~/.ssh/id_rsa"


def test_parses_multiple_hosts(config_file):
    path = config_file("""
        Host web
          HostName web.example.com
          User deploy

        Host db
          HostName db.example.com
          User root
    """)
    hosts = parse(path)
    assert len(hosts) == 2
    assert hosts[0]["host"] == "web"
    assert hosts[1]["host"] == "db"


def test_ignores_comments_and_blank_lines(config_file):
    path = config_file("""
        # This is a comment

        Host myserver
          # Another comment
          HostName 10.0.0.1
          User ubuntu
    """)
    hosts = parse(path)
    assert len(hosts) == 1
    assert hosts[0]["hostname"] == "10.0.0.1"


def test_keys_are_lowercased(config_file):
    path = config_file("""
        Host srv
          HostName example.com
          User root
          IdentityFile ~/.ssh/key
    """)
    hosts = parse(path)
    assert "hostname" in hosts[0]
    assert "identityfile" in hosts[0]
    assert "HostName" not in hosts[0]


def test_returns_empty_list_for_missing_file():
    hosts = parse("/nonexistent/path/config")
    assert hosts == []


def test_returns_empty_list_for_empty_file(config_file):
    path = config_file("")
    hosts = parse(path)
    assert hosts == []
