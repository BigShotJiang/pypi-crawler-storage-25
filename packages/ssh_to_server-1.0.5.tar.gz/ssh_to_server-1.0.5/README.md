# ssh-to-server

![CI](https://github.com/LucasDaSilva96/Py-SSH/actions/workflows/ci.yml/badge.svg)
![PyPI](https://img.shields.io/pypi/v/ssh-to-server)
![Python](https://img.shields.io/pypi/pyversions/ssh-to-server)
![License](https://img.shields.io/pypi/l/ssh-to-server)

A CLI tool that reads your `~/.ssh/config` and lets you SSH into servers interactively — no need to remember hostnames or IPs.
![Cover Image](./ssh-to-server-py.png)

## Features

- Lists all hosts from `~/.ssh/config`
- Select by number or navigate with arrow keys
- Respects all SSH config settings (`User`, `IdentityFile`, `Port`, etc.)
- Works on macOS, Linux, and Windows

## Requirements

- Python 3.11+
- OpenSSH (`ssh` binary available in PATH)

## Installation

The recommended way is with [uv](https://docs.astral.sh/uv/), a fast Python package manager that handles the Python version automatically:

```bash
uv tool install ssh-to-server
```

Or with pip, ensuring you use Python 3.11+:

```bash
pip install ssh-to-server                    # if your default Python is 3.11+
python3.11 -m pip install ssh-to-server      # to target a specific version
```

## Usage

```bash
ssh-to-server
```

You'll see a numbered list of your hosts. Type a number and press Enter to connect directly, or press Enter without a number to use the arrow-key selector.

## Configuration

The tool reads hosts from `~/.ssh/config` by default. You can override this by creating `~/.config/ssh-to-server/config.toml`:

```toml
[ssh]
config_path = "~/dotfiles/ssh/config"
```

### SSH config format

If you don't have a `~/.ssh/config` yet, here's an example:

```
Host my-server
  HostName 192.168.1.10
  User ubuntu
  IdentityFile ~/.ssh/id_ed25519

Host work-vpn
  HostName vpn.example.com
  User alice
  Port 2222
```

## Contributing

Contributions are welcome. Please open an issue first to discuss what you'd like to change.

```bash
git clone https://github.com/LucasDaSilva96/Py-SSH
cd Py-SSH
uv sync
uv run ssh-to-server

# Run tests
uv run pytest

# Lint
uv run ruff check .
```

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.
