#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

# import sys
import re

def encode_0001 ( infile, codepage = 'focal', auto_no = 0, verbose = False):
    outbuf = []
    program_length = 0
    line_no = 0
    labels = []

    # Write the PCB (Program Control Block).
    # Placeholder, will be overwritten if we know the programm length.
    outbuf.append( b'\x4D\x41\x49\x4E\x00\x00\x20\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x80\x00\x00')
    program_length += 24

    # Split line into line number + whatever + comment.

    # No spaces or one space may be typed between the line number and the label field.

    # ^(\d+):    Group 1 - Matches one or more digits at the start of the line.
    # " ?"       No spaces or one space.
    # (.*?):     Group 2 -
    # ((!.*)?)$: Group 3 -
    p = re.compile( "^(\d+) ?(.*?)((!.*)?)$")

    # First pass: Collect labels.
    for line in infile:
        m = re.match( p, line.rstrip( ))

        # if verbose:
        #     print( f">{m.group(1)}< >{m.group(2)}< >{m.group(3)}<")

        # Strip spaces to ignore empty label column.
        label = m.group(2)[0:6].rstrip( )

        if label:
            # But pad labels to distinguish labels like "ERR" and "ERRNO".
            labels.append( f"{label:6s}")

    labels = set( labels)

    if verbose:
        print( labels)

    # Reset file pointer to start.
    infile.seek( 0)

    # Second pass:
    for line in infile:
        if verbose:
            print( line.rstrip( ))

        m = re.match( p, line.rstrip( ))

        if verbose:
            print( f">{m.group(1)}< >{m.group(2)}< >{m.group(3)}<")

        # Replace the line number.
        if auto_no:
            line_no += auto_no
            line_number = bytes.fromhex( f"{line_no:04}")
        else:
            line_number = bytes.fromhex( f"{int( m.group(1)):04}")

        label = m.group(2)[0:6].rstrip( )
        opcode = m.group(2)[7:10].rstrip( )
        arguments = m.group(2)[10:] # .rstrip( )
        comment = m.group(3)[1:]

        if verbose:
            print( f"label >{label}< opcode >{opcode}< arguments >{arguments}< comment >{comment}<")

        buf = b''

        if label:
            buf = buf + b'\xFF' + bytes( f"{label:6s}", codepage)

        if opcode:
            buf = buf + bytes( opcode, codepage)

        if arguments:
            # if "D R" == arguments[0:3]:
            if " " == arguments[1]:
                arguments = arguments[:1] + arguments[2:]
            # else:
            elif " " == arguments[0]:
                arguments = arguments[1:]

            if opcode in [ "GLO"]:
                buf = buf + b'\xFF' + bytes( f"{arguments.rstrip( ):7s}", codepage)
            elif opcode in [ "DEF", "NAM"]:
                buf = buf + b'\xFF' + bytes( f"{arguments.rstrip( ):6s}", codepage)
            else:
                # Add some spaces so that the 6 character long labels will match.
                arguments = arguments + "      "
                label = [label for label in labels if(label in arguments)]
                if label:
                    # We found a matching label.
                    # print( f"LABEL {label}")
                    # There is only one label.
                    arguments = arguments.split( label[0])
                    # arguments[1] is always empty.
                    # print( f"LABEL >{arguments[0]}< >{arguments[1]}<")
                    # Prefix it with the label token.
                    buf = buf + bytes( arguments[0], codepage) + b'\xFF' + bytes( label[0], codepage)
                else:
                    buf = buf + bytes( arguments.rstrip( ), codepage)

        if comment:
            buf = buf + b'\xFE' + bytes( comment, codepage)

        buf = buf + b'\x0E'

        line_length = len( buf)
        buf = line_number[::-1] + line_length.to_bytes( 1, 'little') + buf

        outbuf.append( buf)
        program_length += line_length + 3

    if verbose:
        print( f"{program_length:04X} {program_length}")

    outbuf.append( b'\x99\xA9\x02\x19\x0E')
    program_length += 5

    # print( f"{program_length:04X} {program_length}")

    # Write the PCB (Program Control Block).
    outbuf[0] =  b'\x4D\x41\x49\x4E\x00\x00\x20' + program_length.to_bytes( 2, 'little') + b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x80\x00\x00'

    for x in outbuf:
        yield x
