#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import gpib
import time # sleep

class SS80:
    """This class implements the SS/80 command set."""

    # https://linux-gpib.sourceforge.io/doc_html/reference-function-ibeot.html
    # If send_eoi is non-zero, then the EOI line will be asserted with
    # the last byte sent by calls to ibwrt() and related functions.
    EOT = 1

    # https://linux-gpib.sourceforge.io/doc_html/reference-function-ibeos.html
    # The least significant 8 bits of eosmode specify the eos character. You may
    # also bitwise-or one or more of the following bits to set the eos mode:
    REOS = 0x400 # Enable termination of reads when eos character is received.
    XEOS = 0x800 # Assert the EOI line whenever the eos character is sent during writes.
    BIN = 0x1000 # Match eos character using all 8 bits (instead of only looking at the 7 least significant bits).

    @classmethod
    def is_ss80 ( cls, board: int, pad: int) -> bool:
        """Test if this is a SS/80 drive by trying to reach the required listeners"""

        for sad in [ 0x05, 0x0E, 0x10]:
            try:
                if not gpib.listener( board, pad, 0x60 + sad):
                    # print( f"SS80 pad {pad:2} sad 0x{sad:02x}: Not a listener")
                    return False

            except:
                print( f"SS80 pad {pad:2} sad 0x{sad:02x}: An exception occurred")
                return False

        return True

    def __init__ ( self, board: int, pad: int):
        self.ppmask = 0x80 >> pad

        self.con_05 = gpib.dev( board, pad, 0x60 + 0x05, gpib.T1s, self.EOT) # Command
        self.con_0E = gpib.dev( board, pad, 0x60 + 0x0E, gpib.T1s, self.EOT) # Execution
        self.con_10 = gpib.dev( board, pad, 0x60 + 0x10, gpib.T100s, self.EOT) # Reporting


    def __del__(self):
        gpib.close( self.con_05)
        gpib.close( self.con_0E)
        gpib.close( self.con_10)


    def QSTAT ( self, msg = "QSTAT"):
        qstat = gpib.read( self.con_10, 1)

        if b'\x00' != qstat and msg:
            print( f"QSTAT {qstat} {msg}")

        return qstat

    # Request Status
    def request_status ( self):
        # Command
        gpib.write \
            ( self.con_05
            ,   b'\x0D'
            )

        # Execution
        res = gpib.read( self.con_0E, 20)

        # Reporting
        qstat = self.QSTAT( "REQUEST STATUS")

        # if b'\x00' != qstat:
        #     return

        if b'\x00' == qstat:
            # print( f"Request Status {res}")
            # b'\x00\xff\x00\x00\x00\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
            # 4-61
            # byte 7 byte 8
            # ACCESS ERRORS FIELD < 0 33 34 35 36 37 0 0 > < 40 41 0 43 44 0 0 0 >
            # 35 = Not Ready
            # The device is not ready, probably because the medium has not been loaded.
            if 0x00 == res[6]:
                pass
            elif 0x10 == res[6]:
                print( "Error 130 : DISC")
            # 36 = Write Protect
            # The selected volume is write protected and the current command failed because of that.
            elif 0x08 == res[6]:
                print( "Error 60 : WRITE PROTECT")
            else:
                print( "Error 42 : DON'T KNOW")

        return res

    # Read Self-Test
    def read_self_test ( self):
        return gpib.read( self.con_1F, 5)

    # Write Loopback
    def write_loopback ( self, data):
        gpib.write( self.con_1E, data)

    # Read Loopback
    def read_loopback ( self):
        return gpib.read( self.con_1E, 255)

    # Seek
    def seek ( self, unit = 0, address = 0):
        return

    # Locate and Read
    def locate_and_read ( self, unit = 0, address = 0, size = 256):
        # Command
        gpib.write \
            ( self.con_05
            # ,   b'\x20' # Unit 0
            #     b'\x40' # Volume 0
                # SUBSET 80 FOR FIXED AND FLEXIBLE DISC DRIVES (HP-IB IMPLEMENT ATION)
                # SET UNIT
                # 4-83
                # FORMAT: Set Unit opcode = <0010YYYY>
                # YYYY = Unit number (1111=Device controller)
            ,   (0x20 | unit).to_bytes( 1, 'big')
              + b'\x40' # Volume 0
                b'\x10' # Address
                # b'\x00\x00\x00\x00\x00\x00'
              + address.to_bytes( 6, 'big')
              + b'\x18\x00\x00\x01\x00' # Length 256
                b'\x00' # Opcode
            )

        # Execution
        res = gpib.read( self.con_0E, 256)

        # Reporting
        qstat = self.QSTAT( "LOCATE AND READ")

        if b'\x00' != qstat:
            self.request_status( )
        #     return

        return res


    # Locate and Write
    def locate_and_write ( self, buf, unit = 0, address = 0, size = 256):
        # Command
        gpib.write \
            ( self.con_05
            # ,   b'\x20' # Unit 0
            #     b'\x40' # Volume 0
                # SUBSET 80 FOR FIXED AND FLEXIBLE DISC DRIVES (HP-IB IMPLEMENT ATION)
                # SET UNIT
                # 4-83
                # FORMAT: Set Unit opcode = <0010YYYY>
                # YYYY = Unit number (1111=Device controller)
            ,   (0x20 | unit).to_bytes( 1, 'big')
              + b'\x40' # Volume 0
                b'\x10' # Address
                # b'\x00\x00\x00\x00\x00\x00'
              + address.to_bytes( 6, 'big')
              + b'\x18\x00\x00\x01\x00' # Length 256
                b'\x02' # Opcode
            )

        # Execution
        gpib.write \
            ( self.con_0E
            , buf
            )

        # Reporting
        qstat = self.QSTAT( "LOCATE AND WRITE")

        if b'\x00' != qstat:
            self.request_status( )
        #     return

        return qstat


    # Format
    def request_format ( self, unit, option, interleave, databyte):

        # Command
        gpib.write \
            ( self.con_05
            # ,   b'\x20' # Unit 0
            #     b'\x40' # Volume 0
                # SUBSET 80 FOR FIXED AND FLEXIBLE DISC DRIVES (HP-IB IMPLEMENT ATION)
                # SET UNIT
                # 4-83
                # FORMAT: Set Unit opcode = <0010YYYY>
                # YYYY = Unit number (1111=Device controller)
            ,   (0x20 | unit).to_bytes( 1, 'big')
              + b'\x40' # Volume 0
                b'\x37' # INITIALIZE MEDIA
                b'\x00' # 00000YYY, 000 = retaining all spares
              + interleave.to_bytes( 1, 'big')
            )

        # Execution
        # Reporting

        # Formatting needs around 18 sec on my 9121D and around 90 sec on my 9123D.
        # (The manual states that the 9123D is doing verification as well)

        # DSJ (QSTAT) will timeout regardless of the timeout settings.
        # Added my own ibrpp call to python.
        # TODO: Check if I made a mistake with timout or wait.

        # Parallel poll is used as an additional means of communication between the 9121D/S and the
        # Bus Controller. If the 9121D/S is ready to accept the next part of a command sequence, it will
        # respond to the parallel poll conducted by the Bus Controller.

        # Looks like the XyphroLabs USbGpib V2 is not able to handle parallel poll.
        # Fallback to wait.

        # The try block lets you test a block of code for errors.
        try:
            while True:
                # ppres = gpib.parallel_poll( 0) # board
                ppres = gpib.parallel_poll( self.con_05) # device
                print( f"{ppres:08b} {ppres:02x} {self.ppmask:02x}")
                if self.ppmask & ppres:
                    break
                time.sleep( 1)

        # The except block lets you handle the error.
        except gpib.GpibError:
            t = 90
            print( f"parallel poll failed, waiting {t} s")
            while t:
                time.sleep(1)
                t -= 1
                print( f"{t}")

        # The else block lets you execute code when there is no error.
        else:
            pass

        # The finally block lets you execute code, regardless of the result of the try- and except blocks.
        finally:
            pass

        qstat = self.QSTAT( "INITIALIZE")

        if b'\x00' != qstat:
            self.request_status( )

        return qstat
