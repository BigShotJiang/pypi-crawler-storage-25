#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

# import sys
import os

from . import encfocal

from .encode_0001 import encode_0001
from .encode_E010 import encode_E010

def main ( ) -> int:
    import argparse

    parser = argparse.ArgumentParser \
        ( formatter_class = argparse.ArgumentDefaultsHelpFormatter
        , description = 'Convert a plain text file into a LIF file, supported file types are 0001 (85ASM) and E010 (DTA8x)'
        )

    parser.add_argument( "source")
    parser.add_argument( "destination")

    # codepage: 'ascii', 'cp1252', 'utf-8', 'focal'
    # parser.add_argument( "-c", "--codepage", help="codepage", default="focal")
    parser.add_argument( "-c", "--codepage", help=argparse.SUPPRESS, default="focal")

    parser.add_argument( "-v", "--verbose", help="verbose mode", action="store_true")
    parser.add_argument( "-x", "--extended", help="extended mode", action="store_true")
    parser.add_argument( "-n", "--number", help="automatic line numbering", type=int, default=0)

    args = parser.parse_args( )

    with open( args.source, "r") as source:
        filename, file_extension = os.path.splitext( args.source)

        with open( args.destination, "wb") as target:
            if '.ASM' == file_extension:
                for line in encode_0001( source, codepage = args.codepage, auto_no = args.number, verbose = args.verbose):
                    target.write( line)
            elif '.BAS' == file_extension:
                for line in encode_E010( source, codepage = args.codepage, auto_no = args.number, verbose = args.verbose):
                    target.write( line)
            else:
                pass

    return 0
