""" Python Character Mapping Codec focal generated from 'MAPPINGS/FOCAL.TXT' with gencodec.py.

"""#"

import codecs

### Codec APIs

class Codec(codecs.Codec):

    def encode(self, input, errors='strict'):
        return codecs.charmap_encode(input, errors, encoding_table)

    def decode(self, input, errors='strict'):
        return codecs.charmap_decode(input, errors, decoding_table)

class IncrementalEncoder(codecs.IncrementalEncoder):
    def encode(self, input, final=False):
        return codecs.charmap_encode(input, self.errors, encoding_table)[0]

class IncrementalDecoder(codecs.IncrementalDecoder):
    def decode(self, input, final=False):
        return codecs.charmap_decode(input, self.errors, decoding_table)[0]

class StreamWriter(Codec, codecs.StreamWriter):
    pass

class StreamReader(Codec, codecs.StreamReader):
    pass

### encodings module API

def getregentry():
    return codecs.CodecInfo(
        name='focal',
        encode=Codec().encode,
        decode=Codec().decode,
        incrementalencoder=IncrementalEncoder,
        incrementaldecoder=IncrementalDecoder,
        streamreader=StreamReader,
        streamwriter=StreamWriter,
    )


### Decoding Table

decoding_table = (
    '\x00'      #  0x00 -> BLACK LEFT-POINTING TRIANGLE                 # ◀     HP
    '\xbf'      #  0x01 -> INVERTED QUESTION MARK                       # ¿     CP437,CP850
    # 'x'         #  0x02 -> LATIN SMALL LETTER X WITH COMBINING OVERLINE # ?     HP
    '\ufffe'    #  0x02 -> COMBINED
    # '\u0274'    #  0x03 -> LATIN LETTER SMALL CAPITAL N WITH COMBINING OVERLINE # ?     HP
    '\ufffe'    #  0x03 -> COMBINED
    '\u03b1'    #  0x04 -> GREEK SMALL LETTER ALPHA                     # α     CP437,CP850
    '\u03b2'    #  0x05 -> GREEK SMALL LETTER BETA                      # ß     AtariST
    '\u0393'    #  0x06 -> GREEK CAPITAL LETTER GAMMA                   # Γ     CP437,CP850
    # 'n'         #  0x07 -> LATIN SMALL LETTER N WITH COMBINING OVERLINE # ?     HP
    '\ufffe'    #  0x07 -> COMBINED
    '\u0394'    #  0x08 -> GREEK CAPITAL LETTER DELTA                   # Δ     HP
    '\u03c3'    #  0x09 -> GREEK SMALL LETTER SIGMA                     # σ     CP437,CP850
    '\u2190'    #  0x0A -> UPWARDS ARROW                                # ↑     HP
    '\u03bb'    #  0x0B -> GREEK SMALL LETTER LAMDA                     # λ     HP
    '\xb5'      #  0x0C -> MICRO SIGN                                   # µ     CP437,CP850
    '\n'        #  0x0D -> LINE FEED                                    # <LF>  ISO646
    '\u03c4'    #  0x0E -> GREEK SMALL LETTER TAU                       # τ     CP437,CP850
    '\u03a6'    #  0x0F -> GREEK CAPITAL LETTER PHI                     # Φ     CP437,CP850
    '\u0398'    #  0x10 -> GREEK CAPITAL LETTER THETA                   # Θ     CP437,CP850
    '\u03a9'    #  0x11 -> GREEK CAPITAL LETTER OMEGA                   # Ω     CP437,CP850
    '\u03b4'    #  0x12 -> GREEK SMALL LETTER DELTA                     # δ     CP437,CP850
    '\xc5'      #  0x13 -> LATIN CAPITAL LETTER A WITH RING ABOVE       # Å     CP437,CP850
    '\xe5'      #  0x14 -> LATIN SMALL LETTER A WITH RING ABOVE         # å     CP437,CP850
    '\xc4'      #  0x15 -> LATIN CAPITAL LETTER A WITH DIAERESIS        # Ä     CP437,CP850
    '\xe4'      #  0x16 -> LATIN SMALL LETTER A WITH DIAERESIS          # ä     CP437,CP850
    '\xd6'      #  0x17 -> LATIN CAPITAL LETTER O WITH DIAERESIS        # Ö     CP437,CP850
    '\xf6'      #  0x18 -> LATIN SMALL LETTER O WITH DIAERESIS          # ö     CP437,CP850
    '\xdc'      #  0x19 -> LATIN CAPITAL LETTER U WITH DIAERESIS        # Ü     CP437,CP850
    '\xfc'      #  0x1A -> LATIN SMALL LETTER U WITH DIAERESIS          # ü     CP437,CP850
    '\xc6'      #  0x1B -> LATIN CAPITAL LETTER AE                      # Æ     CP437,CP850
    '\u0153'    #  0x1C -> LATIN SMALL LIGATURE OE                      # œ     AtariST
    '\xb2'      #  0x1D -> SUPERSCRIPT TWO                              # ²     CP437,CP850
    '\xa3'      #  0x1E -> POUND SIGN                                   # £     CP437,CP850
    '\u2591'    #  0x1F -> LIGHT SHADE                                  # ░     HP
    ' '         #  0x20 -> SPACE                                        # <SP>  ISO646
    '!'         #  0x21 -> EXCLAMATION MARK                             # !     ASCII
    '"'         #  0x22 -> QUOTATION MARK                               # "     ASCII
    '#'         #  0x23 -> NUMBER SIGN                                  # #     ASCII
    '$'         #  0x24 -> DOLLAR SIGN                                  # $     ASCII
    '%'         #  0x25 -> PERCENT SIGN                                 # %     ASCII
    '&'         #  0x26 -> AMPERSAND                                    # &     ASCII
    "'"         #  0x27 -> APOSTROPHE                                   # '     ASCII
    '('         #  0x28 -> LEFT PARENTHESIS                             # (     ASCII
    ')'         #  0x29 -> RIGHT PARENTHESIS                            # )     ASCII
    '*'         #  0x2A -> ASTERISK                                     # *     ASCII
    '+'         #  0x2B -> PLUS SIGN                                    # +     ASCII
    ','         #  0x2C -> COMMA                                        # ,     ASCII
    '-'         #  0x2D -> HYPHEN-MINUS                                 # -     ASCII
    '.'         #  0x2E -> FULL STOP                                    # .     ASCII
    '/'         #  0x2F -> SOLIDUS                                      # /     ASCII
    '0'         #  0x30 -> DIGIT ZERO                                   # 0     ASCII
    '1'         #  0x31 -> DIGIT ONE                                    # 1     ASCII
    '2'         #  0x32 -> DIGIT TWO                                    # 2     ASCII
    '3'         #  0x33 -> DIGIT THREE                                  # 3     ASCII
    '4'         #  0x34 -> DIGIT FOUR                                   # 4     ASCII
    '5'         #  0x35 -> DIGIT FIVE                                   # 5     ASCII
    '6'         #  0x36 -> DIGIT SIX                                    # 6     ASCII
    '7'         #  0x37 -> DIGIT SEVEN                                  # 7     ASCII
    '8'         #  0x38 -> DIGIT EIGHT                                  # 8     ASCII
    '9'         #  0x39 -> DIGIT NINE                                   # 9     ASCII
    ':'         #  0x3A -> COLON                                        # :     ASCII
    ';'         #  0x3B -> SEMICOLON                                    # ;     ASCII
    '<'         #  0x3C -> LESS-THAN SIGN                               # <     ASCII
    '='         #  0x3D -> EQUALS SIGN                                  # =     ASCII
    '>'         #  0x3E -> GREATER-THAN SIGN                            # >     ASCII
    '?'         #  0x3F -> QUESTION MARK                                # ?     ASCII
    '@'         #  0x40 -> COMMERCIAL AT                                # @     ASCII
    'A'         #  0x41 -> LATIN CAPITAL LETTER A                       # A     ASCII
    'B'         #  0x42 -> LATIN CAPITAL LETTER B                       # B     ASCII
    'C'         #  0x43 -> LATIN CAPITAL LETTER C                       # C     ASCII
    'D'         #  0x44 -> LATIN CAPITAL LETTER D                       # D     ASCII
    'E'         #  0x45 -> LATIN CAPITAL LETTER E                       # E     ASCII
    'F'         #  0x46 -> LATIN CAPITAL LETTER F                       # F     ASCII
    'G'         #  0x47 -> LATIN CAPITAL LETTER G                       # G     ASCII
    'H'         #  0x48 -> LATIN CAPITAL LETTER H                       # H     ASCII
    'I'         #  0x49 -> LATIN CAPITAL LETTER I                       # I     ASCII
    'J'         #  0x4A -> LATIN CAPITAL LETTER J                       # J     ASCII
    'K'         #  0x4B -> LATIN CAPITAL LETTER K                       # K     ASCII
    'L'         #  0x4C -> LATIN CAPITAL LETTER L                       # L     ASCII
    'M'         #  0x4D -> LATIN CAPITAL LETTER M                       # M     ASCII
    'N'         #  0x4E -> LATIN CAPITAL LETTER N                       # N     ASCII
    'O'         #  0x4F -> LATIN CAPITAL LETTER O                       # O     ASCII
    'P'         #  0x50 -> LATIN CAPITAL LETTER P                       # P     ASCII
    'Q'         #  0x51 -> LATIN CAPITAL LETTER Q                       # Q     ASCII
    'R'         #  0x52 -> LATIN CAPITAL LETTER R                       # R     ASCII
    'S'         #  0x53 -> LATIN CAPITAL LETTER S                       # S     ASCII
    'T'         #  0x54 -> LATIN CAPITAL LETTER T                       # T     ASCII
    'U'         #  0x55 -> LATIN CAPITAL LETTER U                       # U     ASCII
    'V'         #  0x56 -> LATIN CAPITAL LETTER V                       # V     ASCII
    'W'         #  0x57 -> LATIN CAPITAL LETTER W                       # W     ASCII
    'X'         #  0x58 -> LATIN CAPITAL LETTER X                       # X     ASCII
    'Y'         #  0x59 -> LATIN CAPITAL LETTER Y                       # Y     ASCII
    'Z'         #  0x5A -> LATIN CAPITAL LETTER Z                       # Z     ASCII
    '['         #  0x5B -> LEFT SQUARE BRACKET                          # [     ASCII
    '\\'        #  0x5C -> REVERSE SOLIDUS                              # \     ASCII
    ']'         #  0x5D -> RIGHT SQUARE BRACKET                         # ]     ASCII
    '^'         #  0x5E -> CIRCUMFLEX ACCENT                            # ^     ASCII
    '_'         #  0x5F -> LOW LINE                                     # _     ASCII
    '`'         #  0x60 -> GRAVE ACCENT                                 # `     ASCII
    'a'         #  0x61 -> LATIN SMALL LETTER A                         # a     ASCII
    'b'         #  0x62 -> LATIN SMALL LETTER B                         # b     ASCII
    'c'         #  0x63 -> LATIN SMALL LETTER C                         # c     ASCII
    'd'         #  0x64 -> LATIN SMALL LETTER D                         # d     ASCII
    'e'         #  0x65 -> LATIN SMALL LETTER E                         # e     ASCII
    'f'         #  0x66 -> LATIN SMALL LETTER F                         # f     ASCII
    'g'         #  0x67 -> LATIN SMALL LETTER G                         # g     ASCII
    'h'         #  0x68 -> LATIN SMALL LETTER H                         # h     ASCII
    'i'         #  0x69 -> LATIN SMALL LETTER I                         # i     ASCII
    'j'         #  0x6A -> LATIN SMALL LETTER J                         # j     ASCII
    'k'         #  0x6B -> LATIN SMALL LETTER K                         # k     ASCII
    'l'         #  0x6C -> LATIN SMALL LETTER L                         # l     ASCII
    'm'         #  0x6D -> LATIN SMALL LETTER M                         # m     ASCII
    'n'         #  0x6E -> LATIN SMALL LETTER N                         # n     ASCII
    'o'         #  0x6F -> LATIN SMALL LETTER O                         # o     ASCII
    'p'         #  0x70 -> LATIN SMALL LETTER P                         # p     ASCII
    'q'         #  0x71 -> LATIN SMALL LETTER Q                         # q     ASCII
    'r'         #  0x72 -> LATIN SMALL LETTER R                         # r     ASCII
    's'         #  0x73 -> LATIN SMALL LETTER S                         # s     ASCII
    't'         #  0x74 -> LATIN SMALL LETTER T                         # t     ASCII
    'u'         #  0x75 -> LATIN SMALL LETTER U                         # u     ASCII
    'v'         #  0x76 -> LATIN SMALL LETTER V                         # v     ASCII
    'w'         #  0x77 -> LATIN SMALL LETTER W                         # w     ASCII
    'x'         #  0x78 -> LATIN SMALL LETTER X                         # x     ASCII
    'y'         #  0x79 -> LATIN SMALL LETTER Y                         # y     ASCII
    'z'         #  0x7A -> LATIN SMALL LETTER Z                         # z     ASCII
    '\u03c0'    #  0x7B -> GREEK SMALL LETTER PI                        # π     CP437,CP850
    '|'         #  0x7C -> VERTICAL LINE                                # |     ASCII
    '\u2192'    #  0x7D -> RIGHTWARDS ARROW                             # →     HP
    '\u03a3'    #  0x7E -> GREEK CAPITAL LETTER SIGMA                   # Σ     CP437,CP850
    '\u22a6'    #  0x7F -> ASSERTION (HP APPEND)                        # ⊦     HP
    '\ufffe'    #  0x80 -> UNDEFINED
    '\ufffe'    #  0x81 -> UNDEFINED
    '\ufffe'    #  0x82 -> UNDEFINED
    '\ufffe'    #  0x83 -> UNDEFINED
    '\ufffe'    #  0x84 -> UNDEFINED
    '\ufffe'    #  0x85 -> UNDEFINED
    '\ufffe'    #  0x86 -> UNDEFINED
    '\ufffe'    #  0x87 -> UNDEFINED
    '\ufffe'    #  0x88 -> UNDEFINED
    '\ufffe'    #  0x89 -> UNDEFINED
    '\ufffe'    #  0x8A -> UNDEFINED
    '\ufffe'    #  0x8B -> UNDEFINED
    '\ufffe'    #  0x8C -> UNDEFINED
    '\ufffe'    #  0x8D -> UNDEFINED
    '\ufffe'    #  0x8E -> UNDEFINED
    '\ufffe'    #  0x8F -> UNDEFINED
    '\ufffe'    #  0x90 -> UNDEFINED
    '\ufffe'    #  0x91 -> UNDEFINED
    '\ufffe'    #  0x92 -> UNDEFINED
    '\ufffe'    #  0x93 -> UNDEFINED
    '\ufffe'    #  0x94 -> UNDEFINED
    '\ufffe'    #  0x95 -> UNDEFINED
    '\ufffe'    #  0x96 -> UNDEFINED
    '\ufffe'    #  0x97 -> UNDEFINED
    '\ufffe'    #  0x98 -> UNDEFINED
    '\ufffe'    #  0x99 -> UNDEFINED
    '\ufffe'    #  0x9A -> UNDEFINED
    '\ufffe'    #  0x9B -> UNDEFINED
    '\ufffe'    #  0x9C -> UNDEFINED
    '\ufffe'    #  0x9D -> UNDEFINED
    '\ufffe'    #  0x9E -> UNDEFINED
    '\ufffe'    #  0x9F -> UNDEFINED
    '\ufffe'    #  0xA0 -> UNDEFINED
    '\ufffe'    #  0xA1 -> UNDEFINED
    '\ufffe'    #  0xA2 -> UNDEFINED
    '\ufffe'    #  0xA3 -> UNDEFINED
    '\ufffe'    #  0xA4 -> UNDEFINED
    '\ufffe'    #  0xA5 -> UNDEFINED
    '\ufffe'    #  0xA6 -> UNDEFINED
    '\ufffe'    #  0xA7 -> UNDEFINED
    '\ufffe'    #  0xA8 -> UNDEFINED
    '\ufffe'    #  0xA9 -> UNDEFINED
    '\ufffe'    #  0xAA -> UNDEFINED
    '\ufffe'    #  0xAB -> UNDEFINED
    '\ufffe'    #  0xAC -> UNDEFINED
    '\ufffe'    #  0xAD -> UNDEFINED
    '\ufffe'    #  0xAE -> UNDEFINED
    '\ufffe'    #  0xAF -> UNDEFINED
    '\ufffe'    #  0xB0 -> UNDEFINED
    '\ufffe'    #  0xB1 -> UNDEFINED
    '\ufffe'    #  0xB2 -> UNDEFINED
    '\ufffe'    #  0xB3 -> UNDEFINED
    '\ufffe'    #  0xB4 -> UNDEFINED
    '\ufffe'    #  0xB5 -> UNDEFINED
    '\ufffe'    #  0xB6 -> UNDEFINED
    '\ufffe'    #  0xB7 -> UNDEFINED
    '\ufffe'    #  0xB8 -> UNDEFINED
    '\ufffe'    #  0xB9 -> UNDEFINED
    '\ufffe'    #  0xBA -> UNDEFINED
    '\ufffe'    #  0xBB -> UNDEFINED
    '\ufffe'    #  0xBC -> UNDEFINED
    '\ufffe'    #  0xBD -> UNDEFINED
    '\ufffe'    #  0xBE -> UNDEFINED
    '\ufffe'    #  0xBF -> UNDEFINED
    '\ufffe'    #  0xC0 -> UNDEFINED
    '\ufffe'    #  0xC1 -> UNDEFINED
    '\ufffe'    #  0xC2 -> UNDEFINED
    '\ufffe'    #  0xC3 -> UNDEFINED
    '\ufffe'    #  0xC4 -> UNDEFINED
    '\ufffe'    #  0xC5 -> UNDEFINED
    '\ufffe'    #  0xC6 -> UNDEFINED
    '\ufffe'    #  0xC7 -> UNDEFINED
    '\ufffe'    #  0xC8 -> UNDEFINED
    '\ufffe'    #  0xC9 -> UNDEFINED
    '\ufffe'    #  0xCA -> UNDEFINED
    '\ufffe'    #  0xCB -> UNDEFINED
    '\ufffe'    #  0xCC -> UNDEFINED
    '\ufffe'    #  0xCD -> UNDEFINED
    '\ufffe'    #  0xCE -> UNDEFINED
    '\ufffe'    #  0xCF -> UNDEFINED
    '\ufffe'    #  0xD0 -> UNDEFINED
    '\ufffe'    #  0xD1 -> UNDEFINED
    '\ufffe'    #  0xD2 -> UNDEFINED
    '\ufffe'    #  0xD3 -> UNDEFINED
    '\ufffe'    #  0xD4 -> UNDEFINED
    '\ufffe'    #  0xD5 -> UNDEFINED
    '\ufffe'    #  0xD6 -> UNDEFINED
    '\ufffe'    #  0xD7 -> UNDEFINED
    '\ufffe'    #  0xD8 -> UNDEFINED
    '\ufffe'    #  0xD9 -> UNDEFINED
    '\ufffe'    #  0xDA -> UNDEFINED
    '\ufffe'    #  0xDB -> UNDEFINED
    '\ufffe'    #  0xDC -> UNDEFINED
    '\ufffe'    #  0xDD -> UNDEFINED
    '\ufffe'    #  0xDE -> UNDEFINED
    '\ufffe'    #  0xDF -> UNDEFINED
    '\ufffe'    #  0xE0 -> UNDEFINED
    '\ufffe'    #  0xE1 -> UNDEFINED
    '\ufffe'    #  0xE2 -> UNDEFINED
    '\ufffe'    #  0xE3 -> UNDEFINED
    '\ufffe'    #  0xE4 -> UNDEFINED
    '\ufffe'    #  0xE5 -> UNDEFINED
    '\ufffe'    #  0xE6 -> UNDEFINED
    '\ufffe'    #  0xE7 -> UNDEFINED
    '\ufffe'    #  0xE8 -> UNDEFINED
    '\ufffe'    #  0xE9 -> UNDEFINED
    '\ufffe'    #  0xEA -> UNDEFINED
    '\ufffe'    #  0xEB -> UNDEFINED
    '\ufffe'    #  0xEC -> UNDEFINED
    '\ufffe'    #  0xED -> UNDEFINED
    '\ufffe'    #  0xEE -> UNDEFINED
    '\ufffe'    #  0xEF -> UNDEFINED
    '\ufffe'    #  0xF0 -> UNDEFINED
    '\ufffe'    #  0xF1 -> UNDEFINED
    '\ufffe'    #  0xF2 -> UNDEFINED
    '\ufffe'    #  0xF3 -> UNDEFINED
    '\ufffe'    #  0xF4 -> UNDEFINED
    '\ufffe'    #  0xF5 -> UNDEFINED
    '\ufffe'    #  0xF6 -> UNDEFINED
    '\ufffe'    #  0xF7 -> UNDEFINED
    '\ufffe'    #  0xF8 -> UNDEFINED
    '\ufffe'    #  0xF9 -> UNDEFINED
    '\ufffe'    #  0xFA -> UNDEFINED
    '\ufffe'    #  0xFB -> UNDEFINED
    '\ufffe'    #  0xFC -> UNDEFINED
    '\ufffe'    #  0xFD -> UNDEFINED
    '\ufffe'    #  0xFE -> UNDEFINED
    '\ufffe'    #  0xFF -> UNDEFINED
)

### Encoding table
encoding_table = codecs.charmap_build(decoding_table)

