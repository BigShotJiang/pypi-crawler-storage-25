#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import os

from .ss80 import SS80

class SS80File:
    """This class is an [informal] interface providing needed "file" functions."""

    # Actually this information should come from the volume header.
    # But all is set to 0 there.
    # tracks_per_surface
    # surfaces
    # sectors_per_track
    SECTOR_SIZE = 256

    def __init__ ( self, board, pad, unit, verbose = False):
        self.verbose = verbose

        self.ss80 = SS80( board, pad)
        self.unit = unit

        self.amigo = self.ss80 # Fix lif80init
        self.protocol = self.ss80 # Fix lif80init

        # # HOLDOFF
        if verbose:
            print( "Holdoff")

        qstat = self.ss80.QSTAT( None)
        if verbose:
            print( qstat)

        qstat = self.ss80.QSTAT( None)
        if verbose:
            print( qstat)

        # REQUEST STATUS
        status = self.ss80.request_status( )

        if verbose:
            print( "Request Status")
            print( status)

        self.offset = self.SECTOR_SIZE
        self.buf = None
        self.seek( 0)

    def seek ( self, offset, whence = os.SEEK_SET):
        # We only support SEEK_SET for now.

        # Only allow sector aligned seek.
        if 0 != offset % self.SECTOR_SIZE:
            exit( -1)

        # Invalidate buffer.
        self.offset = self.SECTOR_SIZE
        self.buf = None

        # capacity = cylinders * heads * sectors * SECTOR_SIZE
        # 270336   = 33        * 2     * 16      * 256

        self.address = offset // self.SECTOR_SIZE

        return offset


    def tell ( self):
        offset = self.address * self.SECTOR_SIZE
        return offset


    def read ( self, size = 256):
        res = b''

        # print( f"read address {self.address}")

        while size:
            # Remaining bytes in buffer.
            avail = self.SECTOR_SIZE - self.offset

            # If there are none, read the next sector.
            if 0 == avail:
                self.buf = self.ss80.locate_and_read( unit = self.unit, address = self.address, size = self.SECTOR_SIZE)
                self.offset = 0
                avail = self.SECTOR_SIZE # - self.offset
                self.address += 1

            n = size if avail > size else avail

            # print( f"read size {size:6} offs {self.offset:3} avail {avail:3} n {n:3}")

            res = res + self.buf[self.offset:self.offset+n]
            size -= n
            self.offset += n

        return res

    def write ( self, buf):
        size = len( buf)

        print( f"write address {self.address}")

        for n in range( 0, size, self.SECTOR_SIZE):
            self.ss80.locate_and_write( buf, unit = self.unit, address = self.address, size = self.SECTOR_SIZE)
            self.address += 1

        return size
