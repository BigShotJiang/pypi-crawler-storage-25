#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

# 00085-90447 HP-85 Mass Storage ROM Manual
# Page 57
# Packing Files
# The *PACK* statement fills in *NULL* file gaps created when files are purged without a *0* purge code.

import sys
import argparse
import os

from .lif_error import LifError

from .source import Source
from .target import Target

def _pack_file ( source, target):

    file_size = source.file_size( )

    target.purge( )
    target.find_free_spot( file_size, True)

    # We need some additional information from the source file.
    target.fix_from( source)

    target.write_file( source)

    return


def main ( ) -> int:
    # Parse the command line arguments.
    parser = argparse.ArgumentParser \
        ( formatter_class = argparse.ArgumentDefaultsHelpFormatter
        , description = 'Fills in NULL file gaps created when files are purged without a 0 purge code'
        )

    # parser.add_argument( "source")
    parser.add_argument( "destination")

    # codepage: 'ascii', 'cp1252', 'utf-8', 'focal'
    # parser.add_argument( "-c", "--codepage", help="codepage", default="focal")
    parser.add_argument( "-c", "--codepage", help=argparse.SUPPRESS, default="focal")
    parser.add_argument( "-m", "--mass-storage", help="MASS STORAGE IS", default=os.getenv( 'MASS_STORAGE', ":."))

    parser.add_argument( "-v", "--verbose", help="verbose mode", action="store_true")
    parser.add_argument( "-x", "--extended", help="extended mode", action="store_true")

    args = parser.parse_args( )

    try:
        # Instantiate source and target.
        source = Source( args.destination, args)
        source.open( )

        target = Target( args.destination, args)
        target.open( )

        # pack does not take a file name.
        if target.file_name_dec:
            raise LifError( 126) # "Error 126 : MSUS"

        empty_dir_entry = False

        for d in source.get_dir_entries( ):
            if args.verbose:
                print( f"{d.file_name( ).decode( args.codepage):10}  {d.file_type( ):04X}  {d.bytes_per_record( ):5}  {d.file_length( ):5}  {d.file_start( ):5}  {d.bytes_per_file( ):5}  {d.bytes_per_record( ) * d.file_length( ):5}  {d.creation_date( )}")

            if d.is_purged( ):
                empty_dir_entry = True
            elif empty_dir_entry:
                if args.verbose:
                    print( "pack")

                source.file_name_dec = d.file_name( ).decode( args.codepage)
                source.file_name = d.file_name( )
                source.dir_entry = d

                target.file_name_dec = d.file_name( ).decode( args.codepage)
                target.file_name = d.file_name( )

                _pack_file( source, target)

        # Set all purged to available.
        target.pack( )

    except LifError as e:
        print( e)
        return e.code

    return 0
