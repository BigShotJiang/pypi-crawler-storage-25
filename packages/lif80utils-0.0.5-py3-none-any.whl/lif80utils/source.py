#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys  # exit
import os   # path
import stat # S_ISBLK

from .lif_error import LifError

from .source_lif import SourceLif
from .source_linux import SourceLinux

#
#
#

def Source ( _lifpath: str, args):
    """Factory Method"""

    from . import lifpath
    file_name_dec, _, image = lifpath.split( _lifpath, args)

    # |         | linux device    | ":/dev/floppy" |
    if os.path.exists( image) and stat.S_ISBLK( os.stat( image).st_mode):
        if args.verbose:
            print( "Source is Linux device")

        print( "not implemented")
        sys.exit( -1)

    # |         | linux directory | ":directory/"  |
    elif os.path.isdir( image):
        if args.verbose:
            print( "Source is Linux directory")

        return SourceLinux( file_name_dec, image, args)

    # |         | image file      | ":image"       | n/a
    elif os.path.isfile( image):
        if args.verbose:
            print( "Source is LIF image file")

        return SourceLif( open( image, "rb"), file_name_dec, image, args)

    # |         | gpib device     | ":Dnnn"        |
    else:
        if args.verbose:
            print( "Source is GPIB device")

        from . import msus
        file = msus.open( image, args.verbose)

        if file:
            return SourceLif( file, file_name_dec, image, args)

    raise LifError( 130) # "Error 130 : DISC"
