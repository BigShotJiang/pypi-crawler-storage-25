#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

SECTOR_SIZE = 256

outbuf = []
n = SECTOR_SIZE
n_sectors = 0

def write_line ( buf, verbose = False):
    global n, n_sectors

    l = len( buf)
    buf = l.to_bytes( 2, 'little') + buf

    size = len( buf) + 1 # 0xDF, 0xCF
    left = n - size

    if verbose:
        print( f"{len( buf):2} >{buf}<")
        print( f"have {n:3} need {size:2} left {left:2} ", end = '')

    # Pad sector.
    if n <= 3:
        pad_sector( )

    if n >= size:
        if verbose:
            print( "Start of line")

        outbuf.append( b'\xdf') #  Start of line.
        outbuf.append( buf)
        n -= size
    else:
        if verbose:
            print( "Split accross sector end")

        outbuf.append( b'\xcf') # Split accross sector end.
        n -= 1
        outbuf.append( buf[:n])
        # n -= n
        # TODO: This will fail if the rest of the line is larger then SECTOR_SIZE.
        #       But that is actually not possible, since there is no place to write a 0xCF.
        buf = buf[n:]
        l = len( buf)
        buf = b'\x6f' + l.to_bytes( 2, 'little') + buf
        size = len( buf)

        n = SECTOR_SIZE
        n_sectors += 1

        left = n - size

        if verbose:
            print( f"{len( buf):2} >{buf}<")
            print( f"have {n:3} need {size:2} left {left:2} ", end = '')
            print( "Split continue")

        outbuf.append( buf)
        n -= size

def pad_sector ( verbose = False):
    """Pad sector."""
    global n, n_sectors

    if n:
        outbuf.append( b'\xef')
        n -= 1

    outbuf.append( b'\xff' * n)

    n = SECTOR_SIZE
    n_sectors += 1

def encode_E010 ( infile, codepage = 'focal', auto_no = 0, verbose = False):
    global n

    for line in infile:
        if verbose:
            print( f"{len( line):2} >{line}<")

        # Remove trailing whitespace.
        line = line.rstrip( )

        if verbose:
            print( f"{len( line):2} >{line}<")

        # Encode line and add CR.
        buf = bytes( line, codepage) + b'\x0d'
        write_line( buf, verbose)

    write_line( b'', verbose) # DF 00 00

    # Pad sector.
    pad_sector( )

    # There are extra sectors added at the end of the file padded with FF. Testet with
    # LOAD "FTBALL:D701"
    # SAVE "FTBALL:D700"
    # on the emulator.
    #
    # TODO: Was there a reason for that?
    n_pad_sectors = n_sectors % 6

    if n_pad_sectors:
        if verbose:
            print ( f"sectors: {n_sectors} {n_pad_sectors} {6 - n_pad_sectors}")

        outbuf.append( b'\xff' * (6 - n_pad_sectors) * SECTOR_SIZE)


    for x in outbuf:
        yield x


















