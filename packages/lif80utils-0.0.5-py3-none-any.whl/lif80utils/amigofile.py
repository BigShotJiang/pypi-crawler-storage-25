#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import os

from .amigo import Amigo
from .lif_error import LifError

class AmigoFile:
    """This class is an [informal] interface providing needed "file" functions."""

    # Actually this information should come from the volume header.
    # But all is set to 0 there.
    # tracks_per_surface
    # surfaces
    # sectors_per_track
    SECTOR_SIZE = 256

    def __init__ ( self, board, pad, unit, verbose = False):
        self.verbose = verbose

        self.amigo = Amigo( board, pad)
        self.unit = unit

        self.protocol = self.amigo

        dsj = self.amigo.dsj( )

        # if b'\x00' != dsj:
        if self.verbose:
            print( f"{dsj} HOLDOFF STATE")

        # Request status
        res = self.amigo.request_status( unit)

        if self.verbose:
            print( f"{res[0]:08b} {res[1]:08b} {res[2]:08b} {res[3]:08b}")

        tttt = (res[2] & 0x1E) >> 1
        r    = (res[2] & 0x01) >> 0
        w    = (res[3] & 0x40) >> 6
        ss   = (res[3] & 0x03) >> 0

        if self.verbose:
            print( f" TTTT {tttt:04b}")
            print( f"    R {r}")
            print( f"    W {w}")
            print( f"   SS {ss:02b}")

        if 0 != ss:
            raise LifError( 130) # "Error 130 : DISC"

        # TTTT 0110
        self.cylinders = 33
        self.heads = 2
        self.sectors = 16

        # self.offset = self.SECTOR_SIZE
        # self.buf = None
        self.seek( 0)

    def seek ( self, offset, whence = os.SEEK_SET):
        # We only support SEEK_SET for now.

        # Only allow sector aligned seek.
        if 0 != offset % self.SECTOR_SIZE:
            exit( -1)

        # Invalidate buffer.
        self.offset = self.SECTOR_SIZE
        self.buf = None

        # capacity = cylinders * heads * sectors * SECTOR_SIZE
        # 270336   = 33        * 2     * 16      * 256

        sector = offset // self.SECTOR_SIZE

        cylinder = sector // self.sectors
        cylinder = cylinder // self.heads

        head = (sector % (self.sectors * self.heads)) // self.sectors
        sector = sector % self.sectors

        self.amigo.seek( self.unit, cylinder, head, sector)

        return offset


    def tell ( self):
        offset = 0

        log = self.amigo.request_logical( )

        cylinder = int.from_bytes( log[0:2], byteorder='big')
        head = log[2]
        sector = log[3]

        offset += cylinder * self.sectors * self.heads
        offset +=            self.sectors * head
        offset +=            sector

        offset *= self.SECTOR_SIZE

        if self.verbose:
            print( f"LOG C {cylinder:02} H {head} S {sector:02} {offset:06x}")

        return offset


    def read ( self, size = 256):
        res = b''

        while size:
            # Remaining bytes in buffer.
            avail = self.SECTOR_SIZE - self.offset

            # If there are none, read the next sector.
            if 0 == avail:
                dsj = self.amigo.buffered_read( self.unit)

                if b'\x00' == dsj:
                    self.buf = self.amigo.receive( self.SECTOR_SIZE)
                    self.offset = 0
                    avail = self.SECTOR_SIZE # - self.offset
                else:
                    return res

            n = size if avail > size else avail

            res = res + self.buf[self.offset:self.offset+n]
            size -= n
            self.offset += n

        return res

    def write ( self, buf):
        size = len( buf)

        for n in range( 0, size, self.SECTOR_SIZE):
            dsj = self.amigo.buffered_write( self.unit)

            if b'\x00' == dsj:
                dsj = self.amigo.send( buf[n:n + self.SECTOR_SIZE])
            else:
                return  None

        return size
