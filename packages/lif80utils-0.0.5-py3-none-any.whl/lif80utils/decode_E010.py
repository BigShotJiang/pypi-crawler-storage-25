#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

# My notes on decoding E010 format LIF images for HP-85
# https://github.com/magore/hp85disk/blob/master/lif/lif-notes.txt
#
# ef [ff]* = end of data in this sector (no size) , pad with ff's optionally if there is room
# df size = string
# cf size = split accross sector end "6f size" at start of next sector
#        but the 6f size bytes are not included in cf size! (yuck!)
# 6f size = split continue (always starts at sector boundry)
# df 00 00 ef [ff]* = EOF (df size = 0) ef send of sector and optional padding
#
# cf 29 00 (19 is to sector end) (new sector start with 6F 10 00 (10 is remainder)
# So 29 = 19 and 10 (yuck!)

import sys
import re

#
#
#

SECTOR_SIZE = 256


def decode_E010 ( infile, codepage = 'focal', verbose = False):

    n = SECTOR_SIZE

    while True:
        b = infile.read( 1)
        n -= 1

        # if not b:
        #     print( "End of file")
        #     break

        if b == b'\xdf': # Start of line.
            l = infile.read( 2)
            n -= 2

            # Length of line including CR.
            len = int.from_bytes( l, "little")
            # print( f'DF {l} {len}')

            if 0 == len:
                # print( "End of program")
                break

            s = infile.read( len)
            n -= len
            # print( s.translate(trantab).decode( codepage), end = '')

            yield s.decode( codepage, 'combined')

            # yield s[:-1].decode( codepage, 'combined')

            if 0 == n:
                n = SECTOR_SIZE

        elif b == b'\xcf': # Split accross sector end.
            l = infile.read( 2)
            n -= 2

            # Length of line including CR.
            len = int.from_bytes( l, "little")
            # print( f'CF {l} {len}')

            if len > n:
                len = n

            s = infile.read( len)
            n -= len
            # print( s.translate(trantab).decode( codepage), end = '')
            # yield s.decode( codepage, 'combined')
            n = SECTOR_SIZE

        elif b == b'\x6f': # Split continue.
            l = infile.read( 2)
            n -= 2

            # Length of line including CR.
            len = int.from_bytes( l, "little")
            # print( f'6F {l} {len}')

            # s = infile.read( len)
            s += infile.read( len)
            n -= len

            yield s.decode( codepage, 'combined')

        elif b == b'\xef': # Pad sector.
            while True:
                b = infile.read( 1)

                # TODO: Is that smart? Actually I know the size of the sector.
                if b != b'\xff':
                    # print( f'EF {n}')
                    infile.seek(-1, 1) # goes back by one relative to current position
                    n = SECTOR_SIZE
                    break

                n -= 1
        else:
            print( "Unexpected")
            break

