#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys  # exit

from . import encfocal
from .lif import LifImage, LifDirectory
from .lif_error import LifError

#
#
#

class TargetLif:
    def __init__ ( self, file, file_name_dec, image, args):
        if args.verbose:
            print( f"{self.__init__.__qualname__}")

        self.args = args
        self.image = image
        self.file_name_dec = file_name_dec
        self.file_name = f"{file_name_dec:10}".encode( args.codepage)

        self.vol = LifImage( file, verbose = args.verbose)

        self.dir_seek = 0xFFFF
        self.dir_entry = None

    def open ( self):
        self.vol.read_volume_sector( )

    def get_raw_file ( self):
        return self.vol.file

    def fix_from ( self, source):

        return

    def find_dir_entry ( self):
        if self.args.verbose:
            print( f"{self.find_dir_entry.__qualname__}")

        # Set the pointer to the directory start
        self.vol.dir_entry_start( )

        for _ in range( self.vol.no_dir_entries( )):
            d = LifDirectory( self.vol.dir_entry_next( ))

            if self.args.verbose:
                print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

            # Skip purged entries.
            if d.is_purged( ):
                continue

            # File name not found.
            if d.is_avail( ):
                break

            # The target file exists.
            if self.file_name == d.file_name( ):
                self.dir_entry = d
                return True

        return False

    def find_free_spot ( self, file_size:int, as_avail:bool = False):
        if self.args.verbose:
            print( f"{self.find_free_spot.__qualname__}")

        quotient, remainder = divmod( file_size, self.vol.SECTOR_SIZE)
        file_length = quotient + bool( remainder)

        # Get the LIF Volume Sector.
        v = self.vol.v

        file_start_block = v.dir_start_block( ) + v.no_dir_sectors( )

        # To decide between
        # Directory space is exhausted: "Error 124 : FILES".
        # Available space is exhausted: "Error 128 : FULL".
        empty_dir_entry = False

        # Set the pointer to the directory start
        self.vol.dir_entry_start( )

        for _ in range( self.vol.no_dir_entries( )):
            seek = self.vol.file.tell( )
            d = LifDirectory( self.vol.dir_entry_next( ))

            if self.args.verbose:
                print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

            # Or the next available.
            if d.is_avail( ) or (as_avail and d.is_purged( )):
                empty_dir_entry = True
                d.writeable( )
                d.file_start( file_start_block)
                d.file_length( file_length)
                d.readonly( )

                if self.args.verbose:
                    print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

                self.dir_seek = seek
                self.dir_entry = d
                return 0

            # Take the first purged big enough.
            # The no of recs will not be touched.
            # But what will happen with E010? Terrible things!
            if d.is_purged( ):
                empty_dir_entry = True
                if d.file_length( ) >= file_length:
                    self.dir_seek = seek
                    self.dir_entry = d
                    return 0

            # Keep track of the used sectors
            # TODO: Check if there is enough space remaining in the volume.
            if file_start_block < d.file_start( ) + d.file_length( ):
                file_start_block = d.file_start( ) + d.file_length( )

        if empty_dir_entry:
            raise LifError( 128) # Available space is exhausted: "Error 128 : FULL".

        raise LifError( 124) # Directory space is exhausted: "Error 124 : FILES".


    def purge ( self, as_avail:bool = False):
        if self.args.verbose:
            print( f"{self.purge.__qualname__}")

        file_found = False

        # Set the pointer to the directory start
        self.vol.dir_entry_start( )

        for _ in range( self.vol.no_dir_entries( )):
            d = LifDirectory( self.vol.dir_entry_next( ))

            if self.args.verbose:
                print( f"- >{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

            # File name not found.
            if d.is_avail( ):
                if file_found:
                    return
                else:
                    break

            # Skip purged entries.
            if d.is_purged( ):
                if file_found:
                    pass
                else:
                    continue

            # The target file exists.
            if file_found or (self.file_name == d.file_name( )):
                file_found = True

                self.dir_entry = d

                # Write dir entry.
                d.writeable( )

                # Even if this is the last valid file in the directory, the file type
                # will be set to 'purged' (0x0000) rather than 'available' (0xFFFF).

                # Purge code of 0.
                if as_avail:
                    d.file_type( 0xFFFF)
                else:
                    d.file_type( 0x0000)

                d.readonly( )

                if self.args.verbose:
                    print( f"+ >{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

                self.vol.dir_entry_write( d.dir_entry)

                if as_avail:
                    pass
                else:
                    return

        raise LifError( 67) # file not found: "Error 67 : FILE NAME"

    def rename ( self, new_file_name):
        if self.args.verbose:
            print( f"{self.rename.__qualname__}")

        # The only characters that should not be used in the file name portion of a file specifier are .(period), :(colon) and "(quotes).
        if any( (c in set( '.:"')) for c in new_file_name):
            raise LifError( 67) # Invalid filename: "Error 67 : FILE NAME"

        # The target file exists.
        if self.find_dir_entry( ):
            seek = self.dir_seek
            d = self.dir_entry

            # Write dir entry.
            d.writeable( )

            d.file_name( f"{new_file_name:10}".encode( self.args.codepage))

            d.readonly( )

            if self.args.verbose:
                print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

            self.vol.dir_entry_write( d.dir_entry)

            return

        raise LifError( 67) # File not found: "Error 67 : FILE NAME"

    def write_file ( self, source):
        if self.args.verbose:
            print( f"{self.write_file.__qualname__}")

        d = self.dir_entry
        d.writeable( )
        d.file_name( self.file_name)
        d.file_type( source.dir_entry.file_type( ))
        d.bytes_per_file( source.dir_entry.bytes_per_file( ))
        d.bytes_per_record( source.dir_entry.bytes_per_record( ))

        if self.args.extended:
            d.creation_date( source.dir_entry.creation_date( ))

        d.fix( )
        d.readonly( )

        if self.args.verbose:
            print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

        self.vol.dir_entry_write( d.dir_entry)

        data = source.read_file( )
        self.vol.file.seek( self.vol.SECTOR_SIZE * d.file_start( ), 0)
        self.vol.file.write( data)

        # TODO: Fill unused blocks with 0xFF.
        if 0 == source.dir_entry.bytes_per_file( ): # E010
            if self.args.verbose:
                print( f">{d.file_length( ):2} {source.dir_entry.file_length( ):2}")

            unused_blocks = d.file_length( ) - source.dir_entry.file_length( )

            self.vol.file.write( b'\xFF' * (unused_blocks * self.vol.SECTOR_SIZE))

        return

    def request_format ( self) -> int:
        if self.args.verbose:
            print( f"{self.request_format.__qualname__}")

        self.vol.file.amigo.request_format \
            ( unit = self.vol.file.unit
            , option = 0x82
            , interleave = self.args.interleave
            , databyte = self.args.databyte
            )

        return 0

    def assign_vol_label ( self, new_volume_label: str):
        """Assign volume label"""

        if self.args.verbose:
            print( f"{self.assign_vol_label.__qualname__}")

        # The only characters that you should not use in volume labels are: .(period), :(colon) and "(quotes).
        if any( char in new_volume_label for char in [ '.', ':', '"']):
            raise LifError( 89) # Found with emulator but not in the manuals:"Error 89 : INVALID PARAM".

        vol_label = f"{new_volume_label:6}".encode( self.args.codepage)

        # Get the LIF Volume Sector.
        v = self.vol.v

        v.writeable( )
        v.vol_label( vol_label)
        v.readonly( )

        # Rewrite the Volume Sector.
        self.vol.file.seek( 0, 0)
        self.vol.file.write( self.vol.v.volume_sector)

        return

    def pack ( self):
        if self.args.verbose:
            print( f"{self.pack.__qualname__}")

        # Set the pointer to the directory start
        self.vol.dir_entry_start( )

        for _ in range( self.vol.no_dir_entries( )):
            seek = self.vol.file.tell( )
            d = LifDirectory( self.vol.dir_entry_next( ))

            if self.args.verbose:
                print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

            if d.is_avail( ):
                break

            # Set all purged to available.
            if d.is_purged( ):
                if self.args.verbose:
                    print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

                d.writeable( )
                d.file_type( 0xFFFF)
                d.file_length( 0x7FFF)
                d.readonly( )

                self.dir_seek = seek
                self.dir_entry = d

                self.vol.dir_entry_write( d.dir_entry)
