#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

# 00085-90447 HP-85 Mass Storage ROM Manual
# Page 56
# Purging Files
# When a purge code of *0* is included, the spedified file and all files after it on the storage medium are
# purged. The directory does not create *NULL* files; the directory will contain a listing for only those files
# up to (and not including) the file specified in the *PURGE* statement.

import sys
import argparse
import os

from .lif_error import LifError

from .target import Target

def main ( ) -> int:
    # Parse the command line arguments.
    parser = argparse.ArgumentParser \
        ( formatter_class = argparse.ArgumentDefaultsHelpFormatter
        , description = 'Remove the named file from the directory'
        )

    parser.add_argument( "destination")

    # codepage: 'ascii', 'cp1252', 'utf-8', 'focal'
    # parser.add_argument( "-c", "--codepage", help="codepage", default="focal")
    parser.add_argument( "-c", "--codepage", help=argparse.SUPPRESS, default="focal")
    parser.add_argument( "-m", "--mass-storage", help="MASS STORAGE IS", default=os.getenv( 'MASS_STORAGE', ":."))

    parser.add_argument( "-p", "--purge-code", help="purge code", type=int, default=1)

    parser.add_argument( "-v", "--verbose", help="verbose mode", action="store_true")
    parser.add_argument( "-x", "--extended", help="extended mode", action="store_true")

    args = parser.parse_args( )

    try:
        # purge only writes to a target.
        target = Target( args.destination, args)
        target.open( )

        # Remove the file.
        target.purge( 0 == args.purge_code)

    except LifError as e:
        print( e)
        return e.code

    return 0
