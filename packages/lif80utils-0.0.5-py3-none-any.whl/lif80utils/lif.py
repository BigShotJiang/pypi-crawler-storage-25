#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

# HP-85 BASIC PROGRAM CONTROL BLOCK
# https://groups.io/g/hpseries80/wiki/1846
# DISK LAYOUT

# VOLUME SECTORS

# BYTES   DESCRIPTION
# -----   -----------------------------------------------------------
#   0-1   LIF identifier, must be 0x80, 0x00 (0x8000)
#   2-7   6-character volume LABEL
#  8-11   directory start block (always 0,0,0,2 = 0x00000002)
# 12-13   LIF identifer for System 3000 machines (always 0x10,0 = 0x1000)
# 14-15   always 0
# 16-19   # of sectors in DIRECTORY (usually 0,0,0,something)
# 20-21   LIF version number (always 0,1 = 0x0001)
# 22-23   always 0
# 24-27   number of tracks per surface
# 28-31   number of surfaces
# 32-35   number of sectors per track
# 36-41   date and time that the volume was initialized (YY,MM,DD,HH,mm,SS)
#         All date values are in BCD format.  YY is (year-1900). HH is 0-23.

class LifVolume:

    def __init__ ( self, volume_sector):
        self.volume_sector = volume_sector

    def lif_identifier ( self) -> int:
        return int.from_bytes( self.volume_sector[0:2], byteorder='big')

    def vol_label ( self, value: bytes = None) -> bytes:
        if value is not None:
            # Volume labels longer than six characters are truncated to six characters.
            self.volume_sector[2:8] = value[0:6]

        return self.volume_sector[2:8]

    def dir_start_block ( self) -> int:
        return int.from_bytes( self.volume_sector[8:12], byteorder='big')

    def lif_identifier_3000 ( self) -> int:
        return int.from_bytes( self.volume_sector[12:14], byteorder='big')

    def no_dir_sectors ( self, value: int = None) -> int:
        if value is not None:
            self.volume_sector[16:20] = value.to_bytes( 4, 'big')

        return int.from_bytes( self.volume_sector[16:20], byteorder='big')

    def lif_version ( self) -> int:
        return int.from_bytes( self.volume_sector[20:22], byteorder='big')

    def tracks_per_surface ( self) -> int:
        return int.from_bytes( self.volume_sector[24:28], byteorder='big')

    def surfaces ( self) -> int:
        return int.from_bytes( self.volume_sector[28:32], byteorder='big')

    def sectors_per_track ( self) -> int:
        return int.from_bytes( self.volume_sector[32:26], byteorder='big')

    def init_date ( self):
        return self.volume_sector[36:42].hex( )

    def writeable ( self):
        self.volume_sector = bytearray( self.volume_sector)

    def readonly ( self):
        self.volume_sector = bytes( self.volume_sector)

# DIRECTORY SECTORS

# BYTE	DESCRIPTION
#   ----	------------------------------------------------
#   0-9	10-character file name (blank filled)
#   10	upper byte of file TYPE (see below)
#   11	lower byte of file TYPE
#   12-15	START of FILE (most signicant byte first)
#   16-19	LENGTH of FILE in sectors (most significant byte first)
#   20-25	file CREATION DATE (YY MM DD HH MM SS, all=00 on Series 80)
#   26	always 0x80
#   27	always 0x01 entire file is on this volume
#   28*	lower byte of # of BYTES in this FILE
#   29*	upper byte of # of BYTES in this FILE
#   30*	lower byte of BYTES per LOGICAL RECORD
#   31*	upper byte of BYTES per LOGICAL RECORD

# Note that MOST values in LIF discs' VOLUME and DIRECTORY sectors are
# stored in "big-endian" format (most significant byte first, least
# significant byte last).

# The Series 80 CPU was "little-endian", it stored the least significant
# byte first (at the lower address) and the most significant byte last
# (at the upper address).

# That's why the last two entries in the directory entries (bytes/file
# and bytes/record) were stored in byte-reversed order from the other
# "official" LIF values.

# The FILE TYPE value (WORD) was:
#
#    TYPE  Meaning
#   ------ ------------------------------------------

#   0xE004 Series 80 **** extended file type (85 ASSM, etc)
#   0xE00C Series 80 86/87 GRAF
#   0xE014 Series 80 86/87 ASSM
#   0xE01C Series 80 ROOT
#   0xE024 Series 80 86/87 PSET
#   0xE02C Series 80 86/87 BKUP
#   0xE034 Series 80 86/87 FORM
#   0xE084 Series 80 86/87 MIKSAM

class LifDirectory:
    ft2ext = \
        { 0x0000: 'NULL' #   0x0000 PURGE'd (deleted) file
        , 0x0001: '****' #   0x0001 LIF ASCII file
        , 0xE008: 'BPGM' #   0xE008 Series 80 BPGM binary program
        , 0xE009: 'BPGM' #   0xE009 Series 80 BPGM binary program (file security 3)
        , 0xE00A: 'BPGM' #   0xE00A Series 80 BPGM binary program (file security 2)
        , 0xE010: 'DATA' #   0xE010 Series 80 DATA
        , 0xE011: 'DATA' #   0xE011 Series 80 DATA (file security 3)
        , 0xE012: 'DATA' #   0xE012 Series 80 DATA (file security 2)
        , 0xE020: 'PROG' #   0xE020 Series 80 PROG Basic program
        , 0xE021: 'PROG' #   0xE021 Series 80 PROG Basic program (file security 3)
        , 0xE022: 'PROG' #   0xE022 Series 80 PROG Basic program (file security 2)
        , 0xFFFF: 'NEXT' #   0xFFFF NEXT available (unused directory slot) file
        }

    def __init__ ( self, dir_entry):
        self.dir_entry = dir_entry

    def file_name ( self, value: bytes = None) -> bytes:
        if value is not None:
            self.dir_entry[0:10] = value[0:10]

        return self.dir_entry[0:10]

    def file_type ( self, value: int = None) -> int:
        if value is not None:
            self.dir_entry[10:12] = value.to_bytes( 2, 'big')

        return int.from_bytes( self.dir_entry[10:12], byteorder='big')

    def file_type_str ( self) -> str:
        return self.ft2ext.get( self.file_type( ), f"{self.file_type( ):04X}")

    def file_start ( self, value: int = None) -> int:
        if value is not None:
            self.dir_entry[12:16] = value.to_bytes( 4, 'big')

        return int.from_bytes( self.dir_entry[12:16], byteorder='big')

    def file_length ( self, value: int = None) -> int:
        if value is not None:
            self.dir_entry[16:20] = value.to_bytes( 4, 'big')

        return int.from_bytes( self.dir_entry[16:20], byteorder='big')

    def bytes_per_file ( self, value: int = None) -> int:
        if value is not None:
            self.dir_entry[28:30] = value.to_bytes( 2, 'little')

        return int.from_bytes( self.dir_entry[28:30], byteorder='little')

    def bytes_per_record ( self, value: int = None) -> int:
        if value is not None:
            self.dir_entry[30:32] = value.to_bytes( 2, 'little')

        return int.from_bytes( self.dir_entry[30:32], byteorder='little')

    def creation_date ( self, value: str = None) -> str:
        if value is not None:
            self.dir_entry[20:26] = bytes.fromhex( value)

        return self.dir_entry[20:26].hex( )

    def writeable ( self):
        self.dir_entry = bytearray( self.dir_entry)

    def readonly ( self):
        self.dir_entry = bytes( self.dir_entry)

    def is_purged ( self) -> bool:
        return 0x0000 == self.file_type( )

    def is_avail ( self) -> bool:
        return 0xFFFF == self.file_type( )

    def fix ( self):
        self.dir_entry[26:28] = b'\x80\x01'

#
#
#

class RawImage:
    SECTOR_SIZE = 256

    def __init__ ( self, file, verbose = False):
        self.file = file
        self.verbose = verbose

    def read_sector ( self):
        return self.file.read( self.SECTOR_SIZE)



#
#
#

class LifImage ( RawImage):
    LIF_IDENTIFIER = 0x8000
    LIF_IDENTIFIER_3000 = 0x1000

    DIR_ENTRY_SIZE = 32
    DIR_ENTRIES_PER_SECTOR = 8

    codepage = 'ascii'

    def read_volume_sector ( self):

        volume_sector = self.read_sector( ) # Sector 0: Volume sector.

        v = LifVolume( volume_sector)
        self.v = v # for lif80info

        if self.LIF_IDENTIFIER != v.lif_identifier( ):
            print( "ERROR: LIF identifier")
            exit( -1)

        if self.LIF_IDENTIFIER_3000 != v.lif_identifier_3000( ):
            print( "ERROR: LIF identifier System 3000")
            exit( -1)

        if self.verbose:
            print( f">{v.vol_label( )}< {v.dir_start_block( ):x} {v.no_dir_sectors( )} {v.tracks_per_surface( )} {v.surfaces( )} {v.sectors_per_track( )} {v.init_date( )}")
            print( )

        # self.file.read( 256) # Sector 1: Empty 2nd volume sector.

        self.vol_label       = v.vol_label( )
        self.dir_start_block = v.dir_start_block( )
        self.no_dir_sectors  = v.no_dir_sectors( )

    def no_dir_entries ( self):
        return self.no_dir_sectors * self.DIR_ENTRIES_PER_SECTOR

    def dir_entry_start ( self):
        # Set the pointer to the first directory sector.
        self.dir_seek = self.SECTOR_SIZE * self.dir_start_block
        self.file.seek( self.dir_seek, 0) # SEEK_SET
        # Force reading of the first directory sector (in dir_entry_next).
        self.dir_seek -= self.SECTOR_SIZE
        self.dir_offset = self.SECTOR_SIZE - self.DIR_ENTRY_SIZE

    def dir_entry_next ( self):
        # For amigofile_buffered:
        # return self.file.read( self.DIR_ENTRY_SIZE)

        self.dir_offset += self.DIR_ENTRY_SIZE

        if self.SECTOR_SIZE == self.dir_offset:
            self.dir_seek += self.SECTOR_SIZE
            self.dir_offset = 0
            self.dir_sector = self.read_sector( )

        return self.dir_sector[self.dir_offset:self.dir_offset + self.DIR_ENTRY_SIZE + 1]

    def dir_entry_write ( self, dir_entry):
        # For amigofile_buffered:
        # print( f">{self.dir_seek + self.dir_offset:x}")
        # self.file.seek( self.dir_seek + self.dir_offset, 0) # SEEK_SET
        # self.file.write( dir_entry)

        # For amigofile:
        dir_sector = bytearray( self.dir_sector)
        dir_sector[self.dir_offset:self.dir_offset + self.DIR_ENTRY_SIZE + 1] = dir_entry
        self.dir_sector = bytes( dir_sector)

        self.file.seek( self.dir_seek, 0) # SEEK_SET
        self.file.write( self.dir_sector)
