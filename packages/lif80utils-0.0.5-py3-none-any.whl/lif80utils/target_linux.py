#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys  # exit
import os   # path

from .lif_error import LifError

#
#
#

class TargetLinux:
    def __init__ ( self, file_name_dec, image, args):
        if args.verbose:
            print( f"{self.__init__.__qualname__}")

        self.args = args
        self.image = image
        self.file_name_dec = file_name_dec
        self.raw_file = None

    def open ( self):

        return

    def get_raw_file ( self):
        if self.args.verbose:
            print( f"{self.get_raw_file.__qualname__}")

        if not self.raw_file:
            outpath = os.path.join( self.image, self.file_name_dec)
            self.raw_file = open( outpath, "wb")

        return self.raw_file

    def fix_from ( self, source):
        if self.args.verbose:
            print( f"{self.fix_from.__qualname__}")

        filename = self.file_name_dec.rstrip( )

        if self.args.extended:
            if not filename:
                filename = source.file_name_dec.rstrip( )

        basename, _, extension = filename.partition( '.')

        if not extension:
            extension = f"{source.dir_entry.file_type( ):04X}"

        self.file_name_dec = f"{basename}.{extension}"

        return

    def find_dir_entry ( self):
        if self.args.verbose:
            print( f"{self.find_dir_entry.__qualname__}")

        outpath = os.path.join( self.image, self.file_name_dec)

        if os.path.exists( outpath):
            return True

        return False


    def find_free_spot ( self, file_size):
        if self.args.verbose:
            print( f"{self.find_free_spot.__qualname__}")

        return


    def write_file ( self, source):
        if self.args.verbose:
            print( f"{self.write_file.__qualname__}")

        with self.get_raw_file( ) as outfile:
            outfile.write( source.read_file( ))

        # "Close" the file.
        self.raw_file = None

        return

    def rename ( self, new_file_name):
        if self.args.verbose:
            print( f"{self.rename.__qualname__}")

        sys.exit( "Linux directory is not supported.")

    def purge ( self):
        if self.args.verbose:
            print( f"{self.purge.__qualname__}")

        outpath = os.path.join( self.image, self.file_name_dec)

        if os.path.exists( outpath):
            os.remove( outpath)
            return

        raise LifError( 67) # file not found: "Error 67 : FILE NAME"

    def request_format ( self) -> int:
        if self.args.verbose:
            print( f"{self.request_format.__qualname__}")

        raw_target = self.get_raw_file( )

        raw_target.write( bytes( [self.args.databyte]) * self.args.size)
        raw_target.seek( 0, 0) # TODO: Does the phys disc seek back to 0?

        return 0

    def assign_vol_label ( self, new_volume_label: str):
        if self.args.verbose:
            print( f"{self.assign_vol_label.__qualname__}")

        sys.exit( "Linux directory is not supported.")
