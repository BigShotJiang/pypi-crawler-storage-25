#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

# import sys
import argparse
import os

from .lif_error import LifError

from .source import Source
from .target import Target

def main ( ) -> int:
    # Parse the command line arguments.
    parser = argparse.ArgumentParser \
        ( formatter_class = argparse.ArgumentDefaultsHelpFormatter
        , description = 'Assign a volume label to a LIF image'
        )

    parser.add_argument( "destination", help="old file specifier")
    parser.add_argument( "new_volume_label", nargs='?', help="new volume label")

    # codepage: 'ascii', 'cp1252', 'utf-8', 'focal'
    # parser.add_argument( "-c", "--codepage", help="codepage", default="focal")
    parser.add_argument( "-c", "--codepage", help=argparse.SUPPRESS, default="focal")
    parser.add_argument( "-m", "--mass-storage", help="MASS STORAGE IS", default=os.getenv( 'MASS_STORAGE', ":."))

    parser.add_argument( "-v", "--verbose", help="verbose mode", action="store_true")
    parser.add_argument( "-x", "--extended", help="extended mode", action="store_true")

    args = parser.parse_args( )

    try:
        if args.new_volume_label:
            # label only writes to a target.
            target = Target( args.destination, args)

            # label does not take a file name.
            if target.file_name_dec:
                raise LifError( 126) # "Error 126 : MSUS"

            target.open( )

            target.assign_vol_label( args.new_volume_label)

        else:
            # label reads only from a source.
            source = Source( args.destination, args)

            # label does not take a file name.
            if source.file_name_dec:
                raise LifError( 126) # "Error 126 : MSUS"

            source.open( )

            # Get the LIF Volume Sector.
            v = source.vol.v

            print( v.vol_label( ).decode( args.codepage))

    except LifError as e:
        print( e)
        return e.code

    return 0
