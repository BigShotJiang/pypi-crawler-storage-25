#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys  # exit

from . import encfocal
from .lif import LifImage, LifDirectory
from .lif_error import LifError

#
#
#

class SourceLif:
    def __init__ ( self, file, file_name_dec, image, args):
        if args.verbose:
            print( f"{self.__init__.__qualname__}")

        self.args = args
        self.image = image
        self.file_name_dec = file_name_dec
        self.file_name = f"{file_name_dec:10}".encode( args.codepage)

        self.vol = LifImage( file, verbose = args.verbose)

        self.dir_seek = 0xFFFF
        self.dir_entry = None

    def open ( self):
        self.vol.read_volume_sector( )

    def get_volume_label ( self) -> str:
        if self.args.verbose:
            print( f"{self.get_volume_label.__qualname__}")

        return self.vol.vol_label.decode( self.args.codepage).rstrip( )

    def get_dir_entries ( self):
        if self.args.verbose:
            print( f"{self.get_dir_entries.__qualname__}")

        dir_entries = [ ]

        # Set the pointer to the directory start
        self.vol.dir_entry_start( )

        for _ in range( self.vol.no_dir_entries( )):
            d = LifDirectory( self.vol.dir_entry_next( ))

            if d.is_avail( ):
                break

            dir_entries.append( d)

        return dir_entries

    def find_dir_entry ( self):
        if self.args.verbose:
            print( f"{self.find_dir_entry.__qualname__}")

        # Set the pointer to the directory start
        self.vol.dir_entry_start( )

        for _ in range( self.vol.no_dir_entries( )):
            d = LifDirectory( self.vol.dir_entry_next( ))

            if self.args.verbose:
                print( f"{d.file_name( )} {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

            # Skip purged entries.
            if d.is_purged( ):
                continue

            # File name not found.
            if d.is_avail( ):
                break

            # The source file exists.
            if self.file_name == d.file_name( ):
                self.dir_entry = d
                return True

        return False

    def file_size ( self):
        if self.args.verbose:
            print( f"{self.file_size.__qualname__}")

        d = self.dir_entry

        if self.args.verbose:
            print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

        bytes_per_file = d.bytes_per_file( )

        # E010 always use whole blocks and write a 0 len.
        if 0 == bytes_per_file: # E010
            bytes_per_file = d.bytes_per_record( ) * d.file_length( )

        return bytes_per_file

    def read_file ( self):
        if self.args.verbose:
            print( f"{self.read_file.__qualname__}")

        d = self.dir_entry

        if self.args.verbose:
            print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

        self.vol.file.seek( self.vol.SECTOR_SIZE * d.file_start( ), 0)

        file_size = self.file_size( )

        return self.vol.file.read( file_size)

