#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import os

import sys
import contextlib

from .renum_ASM import renum_ASM
from .renum_BAS import renum_BAS

# How to handle both `with open(...)` and `sys.stdout` nicely?
# https://stackoverflow.com/questions/17602878/how-to-handle-both-with-open-and-sys-stdout-nicely
@contextlib.contextmanager
def smart_open ( filename=None, mode="r"):
    if filename and filename != '-':
        fh = open( filename, mode)
    else:
        fh = sys.stdout

    try:
        yield fh
    finally:
        if fh is not sys.stdout:
            fh.close( )


def main ( ) -> int:
    import argparse

    parser = argparse.ArgumentParser \
        ( formatter_class = argparse.ArgumentDefaultsHelpFormatter
        , description = 'Automatic line numbering of .BAS and .ASM files'
        )

    parser.add_argument( "source")
    parser.add_argument( "destination", nargs='?', default="-")

    parser.add_argument( "-v", "--verbose", help="verbose mode", action="store_true")
    parser.add_argument( "-n", "--number", help="numbering increment", type=int, default=10)
    parser.add_argument( "-s", "--start", help="numbering start", type=int, default=10)

    args = parser.parse_args( )

    with open( args.source, "r") as source:
        with smart_open( args.destination, "w") as target:
            filename, file_extension = os.path.splitext( args.source)

            if '.ASM' == file_extension:
                for line in renum_ASM( source, start = args.start, increment = args.number, verbose = args.verbose):
                    target.write( line)
            elif '.BAS' == file_extension:
                for line in renum_BAS( source, start = args.start, increment = args.number, verbose = args.verbose):
                    target.write( line)
            else:
                pass

    return 0
