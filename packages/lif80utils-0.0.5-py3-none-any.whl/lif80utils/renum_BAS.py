#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import re

def renum_BAS ( infile, start:int = 10, increment:int = 10, verbose:bool = False):

    if not increment:
        # Nothing to do.
        for line in infile:
            yield line
    else:
        line_no = start
        line_dict = {}
        line_reg = re.compile( '[^"\s]\S*|".+?"') # Split a string by spaces, preserving quoted substrings.

        # First pass: Create line number dictionary.
        for line in infile:
            line_split = re.findall( line_reg, line)
            line_dict[line_split[0]] = str( line_no)
            line_no += increment

        if verbose:
            print( line_dict)

        # Reset file pointer to start.
        infile.seek( 0)

        # Second pass:
        for line in infile:
            line_split = re.findall( line_reg, line)

            if verbose:
                print( line_split)

            # Replace the line number.
            line_split[0] = line_dict[line_split[0]]

            # GOTO and THEN are always the word before last.
            if line_split[-2] in [ 'GOTO', 'THEN']:
                line_split[-1] = line_dict[line_split[-1]]

            if verbose:
                print( line_split)

            yield ' '.join( line_split)
            yield '\n'

    return
