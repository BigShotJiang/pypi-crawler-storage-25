#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import re

def renum_ASM ( infile, start:int = 10, increment:int = 10, verbose:bool = False):

    if not increment:
        # Nothing to do.
        for line in infile:
            yield line
    else:
        line_no = start
        p = re.compile( "^(\d+)(.*)$") # Split line into line number + whatever.

        for line in infile:
            if verbose:
                print( line)

            m = re.match( p, line)

            if verbose:
                print( f">{m.group(1)}< >{m.group(2)}<")

            # Replace the line number.
            yield f"{line_no}{m.group(2)}\n"

            if increment:
                line_no += increment
