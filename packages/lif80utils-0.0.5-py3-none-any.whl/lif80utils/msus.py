#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import re
import sys # exit

from .lif_error import LifError

# 00085-90447 HP-85 Mass Storage ROM Manual
# Page 11
#
# Mass Storage Unit Specifier
# ...
# The msus string has the following form:
#
# ": device type [interface select code  device address  drive number] "
#
# All msus character strings begin with a colon.
#
# The device type identifies the type of mass storage device being accessed, either disc or tape. The symbol
# :D specifies disc and :T specifies the internal tape drive, if present.
# ...
# All of the optional parameters in the msus (interface select code, device address, drive number) must be
# included when specifying a flexible disc drive unit. The optional parameters are omitted when specifying
# the internal tape unit on the HP-85.
#
# The interface select code identifies the HP-IB interface to which the mass storage unit if attached. The
# interface select code is factory preset to 7, but may be reset to an integer 3 through 10. An interface select
# code greater than 10 is interpreted as 10.
#
# The device address, an integer from 0 through 7, matches the number set on the device address switch on
# the mass storage unit.
#
# The drive number, an integer from 0 through 3, specifies the drive on the master or add-on unit you wish
# to access.

# 00085-90139 HP-85 Mass Storage ROM Pocket Guide
#
# T = The HP-85 tape unit. When you specify “T” the other parameters are ignored.
# D = Disc (any character other than T specifies disc).

# Some error messages generated with the emulator.
#
# :D702   130 : DISC
# :D909   131 : TIME-OUT
# :A700   130 : DISC              OK on HP-87
# :A7000  126 : MSUS
# :D1000  131 : TIME-OUT
# :D701   130 : DISC              not initialized
# :T8888888                       is OK
# :T      62 : CARTRIDGE OUT
# :T      126 : MSUS              HP-87

def open ( msus: str, verbose: bool = False):
    # If the first character is a "T" the following characters are ignored.
    if 'T' == msus[0]:
        raise LifError( 62) # HP 85 with no tape in drive: "Error 62 : CARTRIDGE OUT"
        # raise LifError( 126) # HP 87 which has no internal tape drive: "Error 126 : MSUS"

    # Check if this is a valid MSUS.
    # Using the GPIB card also interface select code 0 through 2 are valid.
    # The HP-85/87 does not check the range of the device address or the drive number.
    # match = re.match( '^([DT])(\d{1,2})([0-7])([0-3])$', msus) # HP-85
    # match = re.match( '^([A-Z])(\d{1,2})([0-7])([0-3])$', msus) # HP-87
    # If there is no device with the given address always Error 131 : TIME-OUT is returned.
    # Error 130 : DISC is returned if the device exists but
    # - there is no disc in the drive.
    # - the disc is not initialized.
    # - the drive number is not valid or the drive does not exist.
    match = re.match( '^([DT])(\d{1,2})([0-9])([0-9])$', msus) # HP-85
    # match = re.match( '^([A-Z])(\d{1,2})([0-9])([0-9])$', msus) # HP-87

    if not match:
        # Since a non-existing file is an invalid MSUS it is not possible to distinguish between the error codes.
        raise LifError( 126) # "Error 126 : MSUS"
        # raise LifError( 130) # "Error 130 : DISC"

    if verbose:
        print( match.groups( ))

    board = int( match[2])
    pad   = int( match[3])
    unit  = int( match[4])

    # An interface select code greater than 10 is interpreted as 10.
    if 10 < board:
        board = 10

    from .amigofile import AmigoFile
    from .ss80 import SS80
    from .ss80file import SS80File

    if SS80.is_ss80( board, pad):
        if verbose:
            print ( "This is a SS/80 drive")

        return SS80File( board, pad, unit, verbose = verbose)
    else:
        if verbose:
            print ( "This is an Amigo drive")

        return AmigoFile( board, pad, unit, verbose = verbose)

    # Never reached.
    raise LifError( 130) # "Error 130 : DISC"
