#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys  # exit
import os   # path
import stat # S_ISREG
import datetime # datetime

from .lif_error import LifError

from . import encfocal
from .lif import LifImage, LifDirectory

#
#
#

class SourceLinux:
    def __init__ ( self, file_name_dec, image, args):
        if args.verbose:
            print( f"{self.__init__.__qualname__}")

        self.args = args
        self.image = image
        self.file_name_dec = file_name_dec
        self.file_name = f"{file_name_dec.rpartition( '.')[0]:10}".encode( args.codepage)

        self.dir_entry = LifDirectory( bytearray( LifImage.DIR_ENTRY_SIZE))

    def open ( self):

        return

    def find_dir_entry ( self):
        if self.args.verbose:
            print( f"{self.find_dir_entry.__qualname__}")

        file_stat = os.stat( os.path.join( self.image, self.file_name_dec))

        if stat.S_ISREG( file_stat.st_mode):
            # Write dir entry.
            d = self.dir_entry

            d.file_name( self.file_name)
            d.file_type( int( self.file_name_dec.rpartition( '.')[2], 16))

            file_size = file_stat.st_size

            if 0xE010 == d.file_type( ):
                d.bytes_per_file( 0)
            else:
                d.bytes_per_file( file_size)

            quotient, remainder = divmod( file_size, LifImage.SECTOR_SIZE)
            file_length = quotient + bool( remainder)

            d.file_length( file_length)

            d.bytes_per_record( LifImage.SECTOR_SIZE)

            # st_ctime: It represents the time of most recent metadata change on Unix and creation time on Windows. It is expressed in seconds.
            ctime = datetime.datetime.fromtimestamp( file_stat.st_ctime, tz=datetime.timezone.utc)

            d.creation_date( ctime.strftime( "%y%m%d%H%M%S"))
            d.readonly( )

            if self.args.verbose:
                print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

            return True

        return False

    def read_file ( self):
        if self.args.verbose:
            print( f"{self.read_file.__qualname__}")

        file_size = self.file_size( )

        return open( os.path.join( self.image, self.file_name_dec), 'rb').read( file_size)

    def file_size ( self):
        if self.args.verbose:
            print( f"{self.file_size.__qualname__}")

        d = self.dir_entry

        if self.args.verbose:
            print( f">{d.file_name( )}< {d.file_type( ):04X} {d.file_start( ):3} {d.file_length( ):2} {d.bytes_per_file( ):5} {d.bytes_per_record( ) * d.file_length( ):5} {d.creation_date( )}")

        bytes_per_file = d.bytes_per_file( )

        if 0 == bytes_per_file: # E010
            bytes_per_file = d.bytes_per_record( ) * d.file_length( )

        return bytes_per_file
