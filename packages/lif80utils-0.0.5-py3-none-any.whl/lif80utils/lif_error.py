#
# This file is part of the lif80utils distribution (https://codeberg.org/Boeingflieger/lif80utils).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

class LifError ( Exception):

    def __init__ ( self, code):
        self.code = code
        self.message = self.CONDITION.get( code, "DON'T KNOW")

        # Pass the message to the base Exception class
        super( ).__init__( f"Error {self.code} : {self.message}")

# Attribute must be initialized.
LifError.CONDITION = \
    {  42: "DON'T KNOW"      # If called with 42 or as placeholder in case a 42 exists.
    ,  60: "WRITE PROTECT"   # The mass storage medium is write-protected.
    ,  62: "CARTRIDGE OUT"   # HP 85 with no tape in drive.
    ,  63: "DUP NAME"        # File exists.
    ,  67: "FILE NAME"       # File not found. Invalid filename.
    ,  89: "INVALID PARAM"   # Found with emulator but not in the manuals.
    , 124: "FILES"           # Directory space is exhausted.
    , 126: "MSUS"            # The specified mass storage unit specifier is invalid.
    , 128: "FULL"            # Available space is exhausted.
    , 130: "DISC"            # The storage medium is not initialized, the drive latch is open, or the drive number specified is not present.
    }
