from solve_and_graph import SolveAndGraphQuadratics

sgq = SolveAndGraphQuadratics(a='', b='', c='')
sgq.main_loop()
