"""LeaderProxy — reverse proxy sitting in front of llama-cpp-server (Phase 7a).

Sits on port 8099, forwards inference requests to llama-cpp-server on :8100.
Tunnel ingress points here instead of directly at the inference server.

Responsibilities:
  - Authoritative Bearer auth BEFORE requests reach llama-cpp-server
  - Per-request logging: request-id, peer IP, model, latency, tokens
  - /v1/debug/status: GPU utilization, VRAM, temperature, uptime
  - /v1/debug/last-requests: ring buffer of last 100 requests
  - Injects X-Maxim-* response headers for peer-side trace enrichment

Design: stdlib http.server for the listener side, maxim.utils.http
(httpx) for upstream forwarding (post Plan 1 R1). No FastAPI/uvicorn dep.
Adds ~1-2ms per request vs direct llama-cpp-server access.

Supersedes debug_status_server.py (which only served /v1/debug/status).
"""

from __future__ import annotations

import collections
import json
import logging
import os
import re
import secrets
import subprocess
import sys
import threading
import time

# ── Input validation ─────────────────────────────────────────────────────────

_BRANCH_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._/-]*$")

# Shared state for async install — written by the install thread, read by
# the /v1/debug/install-status endpoint. Dict (not dataclass) so the
# background thread can mutate in place without import gymnastics.
_install_status: dict[str, Any] = {
    "status": "idle",
    "installed": [],
    "pip_output": "",
    "error": "",
    "started_by": "",
}


def _remote_update_allowed() -> bool:
    """True iff ``MAXIM_ALLOW_REMOTE_UPDATE`` is set to a truthy value."""
    return os.environ.get("MAXIM_ALLOW_REMOTE_UPDATE", "").strip().lower() in (
        "1",
        "true",
        "t",
        "yes",
        "y",
        "on",
    )


def _validate_branch(branch: str) -> str:
    """Validate and return a sanitized branch name.

    Raises ``ValueError`` for names that could cause unexpected git behavior:
    path traversal (``..``), flag injection (leading ``-``), or invalid chars.
    """
    branch = str(branch).strip()
    if not branch:
        raise ValueError("Empty branch name")
    if ".." in branch:
        raise ValueError(f"Branch name contains '..': {branch!r}")
    if branch.startswith("-"):
        raise ValueError(f"Branch name starts with '-': {branch!r}")
    if not _BRANCH_RE.match(branch):
        raise ValueError(f"Invalid branch name: {branch!r}")
    return branch


def _sanitize_git_output(text: str | None, max_len: int = 300) -> str:
    """Remove file system paths and truncate for safe error reporting."""
    if not text:
        return ""
    # Replace absolute paths that could leak system info
    text = re.sub(r"/[\w./-]{5,}", "<path>", text)
    return text[-max_len:] if len(text) > max_len else text


from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from pathlib import Path
from typing import Any

logger = logging.getLogger("maxim.leader_proxy")

DEFAULT_PROXY_PORT = 8099
DEFAULT_UPSTREAM_PORT = 8100
_MAX_RECENT_REQUESTS = 100
_INFERENCE_PROXY_TIMEOUT_S = 300.0
"""Timeout for leader-proxy → llama-cpp-server inference calls.

60s (the former value) is too short for Qwen-14B on long-context prompts —
prefill alone can take 10-20s, leaving <40s for generation. 300s covers
worst-case long-context + long-output on mid-range hardware and matches the
peer backend's default ``timeout_s``.
"""


# ─── GPU metrics ──────────────────────────────────────────────────────────


def _query_nvidia_smi() -> dict[str, Any] | None:
    """Query nvidia-smi for GPU metrics. Returns None if unavailable."""
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if result.returncode != 0:
            return None
        line = result.stdout.strip().split("\n")[0]
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 4:
            return None
        return {
            "utilization_pct": float(parts[0]),
            "vram_used_gb": round(float(parts[1]) / 1024, 2),
            "vram_total_gb": round(float(parts[2]) / 1024, 2),
            "temperature_c": float(parts[3]),
        }
    except Exception:
        return None


def _current_llama_server_n_ctx(port: int) -> int | None:
    """Return the n_ctx the running llama-cpp-server is configured for, or None.

    Probes ``/v1/models`` on the upstream llama-cpp-server for
    ``context_length``, falling back to process command-line inspection on
    Linux. Shared by :func:`check_vram_pressure` in ``doctor/checks.py``
    and :func:`_handle_debug_vram` in this module.
    """
    import socket

    try:
        req_bytes = (f"GET /v1/models HTTP/1.0\r\nHost: 127.0.0.1:{port}\r\n\r\n").encode()
        with socket.create_connection(("127.0.0.1", port), timeout=2.0) as s:
            s.sendall(req_bytes)
            raw = b""
            while True:
                chunk = s.recv(4096)
                if not chunk:
                    break
                raw += chunk
        body = raw.split(b"\r\n\r\n", 1)[-1]
        data = json.loads(body)
        for model in data.get("data", []):
            ctx = model.get("context_length") or model.get("n_ctx") or model.get("max_context_length")
            if ctx:
                return int(ctx)
    except Exception:
        pass

    # Process args fallback — best-effort, cross-platform
    try:
        import platform as _platform

        system = _platform.system().lower()
        if system == "linux":
            import glob

            for cmdline_path in glob.glob("/proc/*/cmdline"):
                try:
                    with open(cmdline_path, "rb") as f:
                        args = f.read().split(b"\x00")
                    args_str = [a.decode("utf-8", errors="ignore") for a in args]
                    if any("llama" in a for a in args_str):
                        for i, arg in enumerate(args_str):
                            if arg in ("--ctx-size", "-c", "--n-ctx") and i + 1 < len(args_str):
                                return int(args_str[i + 1])
                            if arg.startswith("--ctx-size="):
                                return int(arg.split("=", 1)[1])
                except Exception:
                    continue
    except Exception:
        pass
    return None


# ─── log ring buffer ─────────────────────────────────────────────────────

_MAX_LOG_LINES = 500


class _LogBuffer(logging.Handler):
    """Logging handler that captures records into a thread-safe ring buffer.

    Installed on the root 'maxim' logger so all subsystem logs are captured.
    The /v1/debug/logs endpoint reads from this buffer.
    """

    def __init__(self, maxlen: int = _MAX_LOG_LINES) -> None:
        super().__init__()
        self._buffer: collections.deque[dict[str, Any]] = collections.deque(maxlen=maxlen)
        self._lock = threading.Lock()
        self._seq = 0

    def emit(self, record: logging.LogRecord) -> None:
        try:
            entry = {
                "seq": self._seq,
                "ts": record.created,
                "level": record.levelname,
                "logger": record.name,
                "message": self.format(record),
            }
            with self._lock:
                self._buffer.append(entry)
                self._seq += 1
        except Exception:
            pass  # Never crash the logging system

    def get_since(self, since_ts: float = 0.0, since_seq: int = -1, limit: int = 200) -> list[dict[str, Any]]:
        """Return log entries after the given timestamp or sequence number."""
        with self._lock:
            if since_seq >= 0:
                entries = [e for e in self._buffer if e["seq"] > since_seq]
            else:
                entries = [e for e in self._buffer if e["ts"] > since_ts]
        return entries[-limit:]

    def latest_seq(self) -> int:
        with self._lock:
            return self._seq - 1 if self._seq > 0 else -1


# Singleton — installed once, shared across handler instances via class attr.
_log_buffer: _LogBuffer | None = None


def _ensure_log_buffer() -> _LogBuffer:
    """Install the log buffer handler on the maxim logger (idempotent)."""
    global _log_buffer
    if _log_buffer is not None:
        return _log_buffer
    _log_buffer = _LogBuffer()
    _log_buffer.setFormatter(logging.Formatter("%(message)s"))
    _log_buffer.setLevel(logging.DEBUG)
    logging.getLogger("maxim").addHandler(_log_buffer)
    return _log_buffer


# ─── request ring buffer ──────────────────────────────────────────────────


class _RequestLog:
    """Thread-safe ring buffer of recent request records."""

    def __init__(self, maxlen: int = _MAX_RECENT_REQUESTS) -> None:
        self._buffer: collections.deque[dict[str, Any]] = collections.deque(maxlen=maxlen)
        self._lock = threading.Lock()
        self._total: int = 0

    def record(self, entry: dict[str, Any]) -> None:
        with self._lock:
            self._buffer.append(entry)
            self._total += 1

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {
                "total_requests": self._total,
                "recent": list(self._buffer),
            }


# ─── proxy handler ────────────────────────────────────────────────────────


class _ProxyHandler(BaseHTTPRequestHandler):
    """Reverse-proxy handler with auth, logging, and debug endpoints."""

    # HTTP/1.1 is required for Transfer-Encoding: chunked.  Without this,
    # BaseHTTPRequestHandler defaults to HTTP/1.0 which doesn't support
    # chunked responses, and _proxy_request() would have to buffer the entire
    # llama-cpp response before sending — causing Cloudflare 524 timeouts on
    # long-inference requests (~105-125s generation time > Cloudflare's edge
    # timeout). HTTP/1.1 is a superset of HTTP/1.0 for all non-proxy paths.
    protocol_version = "HTTP/1.1"

    # Set by the server factory (class-level attrs)
    api_key: str | None = None
    upstream_url: str = "http://127.0.0.1:8100"
    request_log: _RequestLog | None = None
    lane_metrics: Any = None  # LaneMetrics instance for the large tier
    concurrency_semaphore: threading.Semaphore | None = None  # Phase 7b
    rate_limiter: Any = None  # PeerRateLimiter instance (Phase 7b)
    start_time: float = 0.0

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        # Route to structured logger instead of stderr
        pass

    # ─── admission control (Phase 7b) ────────────────────────────────

    def _check_admission(self) -> bool:
        """Check concurrency cap + per-peer rate limit. Returns True if allowed."""
        # Per-peer rate limit
        if self.rate_limiter is not None:
            peer_key = self.client_address[0]  # bucket by IP; all peers share one cluster key
            if not self.rate_limiter.try_acquire(peer_key):
                self._send_json(
                    429,
                    {
                        "error": "Rate limit exceeded",
                        "retry_after_s": 1,
                    },
                )
                logger.info(
                    "proxy: rate-limited peer=%s",
                    self.client_address[0],
                )
                return False
        # Concurrency cap
        if self.concurrency_semaphore is not None:
            if not self.concurrency_semaphore.acquire(blocking=False):
                queue_depth = self._queue_depth()
                self._send_json(
                    429,
                    {
                        "error": "Too many concurrent requests",
                        "queue_depth": queue_depth,
                    },
                )
                logger.info(
                    "proxy: concurrency-limited peer=%s depth=%d",
                    self.client_address[0],
                    queue_depth,
                )
                return False
        return True

    def _release_concurrency(self) -> None:
        """Release the concurrency semaphore after a proxied request completes."""
        if self.concurrency_semaphore is not None:
            self.concurrency_semaphore.release()

    def _queue_depth(self) -> int:
        """Approximate in-flight request count for X-Maxim-Queue-Depth header."""
        if self.lane_metrics is not None:
            return self.lane_metrics.current_in_flight
        return 0

    # Maximum request body size (1 MB). Prevents memory exhaustion from oversized payloads.
    MAX_BODY_SIZE = 1_048_576

    def _read_body(self, max_size: int | None = None) -> bytes | None:
        """Read request body with size limit. Returns None if no body or over limit."""
        limit = max_size or self.MAX_BODY_SIZE
        content_length = int(self.headers.get("Content-Length", 0))
        if content_length <= 0:
            return None
        if content_length > limit:
            self._send_json(413, {"error": f"Request body too large (max {limit} bytes)"})
            return None
        return self.rfile.read(content_length)

    # ─── auth ─────────────────────────────────────────────────────────

    def _check_auth(self) -> bool:
        """Enforce Bearer auth. Returns True if authorized."""
        if not self.api_key:
            return True
        auth = self.headers.get("Authorization", "")
        if secrets.compare_digest(auth, f"Bearer {self.api_key}"):
            return True
        # Log enough to diagnose mismatches without leaking the full key
        expected_prefix = self.api_key[:6] if self.api_key else "?"
        got_prefix = auth[7:13] if auth.startswith("Bearer ") else repr(auth[:20])
        logger.warning(
            "Auth failed: peer=%s expected=%s... got=%s...",
            self.client_address[0],
            expected_prefix,
            got_prefix,
        )
        self._send_json(401, {"error": "Invalid API key"})
        return False

    # ─── debug endpoints (served directly, not proxied) ───────────────

    def _handle_debug_status(self) -> None:
        gpu = _query_nvidia_smi()
        # Include active LLM model info from lane_backends
        active_model = None
        llm_uptime_s = None
        try:
            import maxim.runtime.llm_server as _srv

            active_model = _srv._active_model
            if _srv._llm_start_time is not None:
                llm_uptime_s = round(time.time() - _srv._llm_start_time, 1)
        except Exception:
            pass

        # Lane metrics (infer lane)
        lane_metrics = None
        try:
            from maxim.models.language.lane_metrics import get_metrics_registry

            m = get_metrics_registry().get("large")
            lane_metrics = {
                "total_requests": m.total_requests,
                "in_flight": m.current_in_flight,
                "avg_latency_ms": round(m.avg_latency_ms, 1) if m.avg_latency_ms else None,
            }
        except Exception:
            pass

        self._send_json(
            200,
            {
                "status": "ok",
                "maxim_uptime_s": round(time.time() - self.start_time, 1),
                "llm_model": active_model,
                "llm_uptime_s": llm_uptime_s,
                "gpu": gpu,
                "infer_lane": lane_metrics,
                "timestamp": time.time(),
            },
        )

    def _handle_debug_heartbeat(self) -> None:
        try:
            from maxim.runtime.heartbeat import get_heartbeat_monitor

            self._send_json(200, get_heartbeat_monitor().snapshot())
        except Exception:
            # Fallback: at least return system metrics
            try:
                from maxim.runtime.system_metrics import collect_all

                self._send_json(200, collect_all())
            except Exception:
                self._send_json(200, {"error": "heartbeat not available"})

    def _handle_debug_metrics(self) -> None:
        try:
            from maxim.models.language.lane_metrics import get_metrics_registry

            self._send_json(200, get_metrics_registry().snapshot())
        except Exception:
            self._send_json(200, {})

    def _handle_debug_version(self) -> None:
        try:
            from maxim import get_version_info

            self._send_json(200, get_version_info())
        except Exception:
            self._send_json(200, {"version": "unknown"})

    def _handle_debug_logs(self) -> None:
        """GET /v1/debug/logs?since_seq=N&limit=200 — return recent log lines."""
        buf = _ensure_log_buffer()

        # Parse query params
        from urllib.parse import parse_qs, urlparse

        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        since_seq = int(params.get("since_seq", ["-1"])[0])
        since_ts = float(params.get("since_ts", ["0"])[0])
        limit = min(int(params.get("limit", ["200"])[0]), 500)

        entries = buf.get_since(since_ts=since_ts, since_seq=since_seq, limit=limit)
        self._send_json(
            200,
            {
                "entries": entries,
                "count": len(entries),
                "latest_seq": buf.latest_seq(),
            },
        )

    def _handle_debug_ping(self) -> None:
        """GET /v1/debug/ping — identify this service as LeaderProxy.

        Unlike /v1/debug/version (which llama-cpp-server could also serve),
        this endpoint is ONLY served by LeaderProxy. Peers use it to confirm
        the tunnel is routing to the proxy (port 8099), not directly to the
        upstream inference server (port 8100).

        Includes ``llm_ready`` field so peers can distinguish "proxy up" from
        "LLM model loaded and ready to serve inference."
        """
        llm_ready = self._probe_upstream_ready()
        self._send_json(
            200,
            {
                "service": "LeaderProxy",
                "proxy_port": self.server.server_address[1],
                "upstream": self.upstream_url,
                "auth_enabled": bool(self.api_key),
                "uptime_s": round(time.time() - self.start_time, 1),
                "llm_ready": llm_ready,
            },
        )

    def _probe_upstream_ready(self) -> bool:
        """Check if the upstream LLM server is responding to /v1/models.

        A fast probe (1.5s timeout) — returns True only if the upstream
        returns HTTP 200 or 401 (auth-gated but alive). Returns False on
        connection refused, timeout, or any error (model still loading).

        Sends the same API key the proxy uses — the upstream llama-cpp-server
        may have been started with --api_key, in which case unauthenticated
        probes get 401 and would never report ready.
        """
        from maxim.utils import http as _http

        probe = f"{self.upstream_url}/v1/models"
        headers: dict[str, str] = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        try:
            resp = _http.fetch_url(
                probe,
                method="GET",
                headers=headers,
                timeout=_http.TimeoutPolicy(connect_s=0.8, read_s=1.5, total_s=2.0),
            )
            return resp.status == 200
        except _http.HTTPAuthError:
            # 401 means the server is up but auth failed — still "ready"
            return True
        except Exception:
            return False

    def _handle_debug_last_requests(self) -> None:
        if self.request_log is None:
            self._send_json(200, {"total_requests": 0, "recent": []})
            return
        # Restrict to localhost for security
        peer = self.client_address[0]
        if peer not in ("127.0.0.1", "::1"):
            self._send_json(403, {"error": "localhost only"})
            return
        self._send_json(200, self.request_log.snapshot())

    def _handle_debug_vram(self) -> None:
        """GET /v1/debug/vram — VRAM projection and live nvidia-smi metrics.

        Returns the leader's current VRAM state as JSON. Calls
        :func:`project_vram_usage` from ``runtime/lane_models.py`` (the
        pure-data helper that both ``check_vram_pressure`` and
        ``_check_vram_spillover_risk`` already delegate to) and formats
        the ``VRAMProjection`` dataclass + live nvidia-smi ratio into a
        JSON response.

        503 if nvidia-smi is unavailable (not a GPU node).
        """
        gpu = _query_nvidia_smi()
        if gpu is None:
            self._send_json(
                503,
                {
                    "error": "nvidia-smi unavailable",
                    "fix": "This endpoint requires an NVIDIA GPU with nvidia-smi installed.",
                },
            )
            return

        # Import thresholds from the single source of truth in lane_models.
        from maxim.runtime.lane_models import (
            _SPILLOVER_RATIO,
            _SPILLOVER_WARN_RATIO,
            project_vram_usage,
        )

        vram_used_gb = float(gpu.get("vram_used_gb") or 0.0)
        vram_total_gb = float(gpu.get("vram_total_gb") or 0.0)
        ratio = round(vram_used_gb / vram_total_gb, 4) if vram_total_gb > 0 else 0.0

        live = {
            "vram_used_gb": vram_used_gb,
            "vram_total_gb": vram_total_gb,
            "vram_utilization_pct": gpu.get("utilization_pct"),
            "temperature_c": gpu.get("temperature_c"),
            "ratio": ratio,
            "spillover": ratio > _SPILLOVER_RATIO,
            "warning": ratio > _SPILLOVER_WARN_RATIO,
        }

        # Build projection from active model + running n_ctx.
        projection = None
        try:
            import maxim.runtime.llm_server as _srv

            active_profile = _srv._active_model
            if active_profile:
                # Extract port from upstream_url (always http://127.0.0.1:{port}).
                try:
                    from urllib.parse import urlparse

                    upstream_port = urlparse(self.upstream_url).port or DEFAULT_UPSTREAM_PORT
                except Exception:
                    upstream_port = DEFAULT_UPSTREAM_PORT
                running_n_ctx = _current_llama_server_n_ctx(upstream_port)
                if running_n_ctx and running_n_ctx > 0:
                    from maxim.models.language.config import _BUILTIN_PROFILES

                    profile_meta = _BUILTIN_PROFILES.get(active_profile, {})
                    vram_proj = project_vram_usage(
                        active_profile,
                        profile_meta,
                        running_n_ctx,
                        vram_total_gb,
                    )
                    if vram_proj is not None:
                        projection = {
                            "profile": vram_proj.profile,
                            "n_ctx": vram_proj.n_ctx,
                            "weights_gb": vram_proj.weights_gb,
                            "kv_cache_gb": round(vram_proj.kv_cache_gb, 3),
                            "headroom_gb": round(vram_proj.headroom_gb, 3),
                            "projected_total_gb": round(vram_proj.projected_total_gb, 3),
                            "physical_vram_gb": vram_proj.physical_vram_gb,
                            "spillover_risk": vram_proj.spillover_risk,
                            "recommended_n_ctx": vram_proj.recommended_n_ctx,
                        }
        except Exception:
            logger.debug("vram endpoint: projection unavailable", exc_info=True)

        self._send_json(
            200,
            {
                "live": live,
                "projection": projection,
                "thresholds": {
                    "spillover_ratio": _SPILLOVER_RATIO,
                    "warn_ratio": _SPILLOVER_WARN_RATIO,
                },
                "timestamp": time.time(),
            },
        )

    def _is_debug_path(self, path: str) -> bool:
        stripped = path.rstrip("/").split("?")[0]
        return stripped in (
            "/v1/debug/ping",
            "/v1/debug/status",
            "/v1/debug/heartbeat",
            "/v1/debug/metrics",
            "/v1/debug/version",
            "/v1/debug/logs",
            "/v1/debug/last-requests",
            "/v1/debug/vram",
            "/v1/debug/deps",
            "/v1/debug/install-status",
        )

    def _route_debug(self, path: str) -> None:
        stripped = path.rstrip("/").split("?")[0]
        if stripped == "/v1/debug/ping":
            self._handle_debug_ping()
        elif stripped == "/v1/debug/status":
            self._handle_debug_status()
        elif stripped == "/v1/debug/heartbeat":
            self._handle_debug_heartbeat()
        elif stripped == "/v1/debug/metrics":
            self._handle_debug_metrics()
        elif stripped == "/v1/debug/version":
            self._handle_debug_version()
        elif stripped == "/v1/debug/logs":
            self._handle_debug_logs()
        elif stripped == "/v1/debug/last-requests":
            self._handle_debug_last_requests()
        elif stripped == "/v1/debug/vram":
            self._handle_debug_vram()
        elif stripped == "/v1/debug/deps":
            self._handle_debug_deps()
        elif stripped == "/v1/debug/install-status":
            self._send_json(200, dict(_install_status))
        else:
            self._send_json(404, {"error": "Not found"})

    # ─── reverse proxy ────────────────────────────────────────────────

    def _proxy_request(self, method: str) -> None:
        """Forward the request to the upstream llama-cpp-server."""
        from maxim.utils import http as _http

        request_id = self.headers.get("X-Maxim-Request-Id", "")
        peer_ip = self.client_address[0]
        t0 = time.time()

        # Read request body
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length) if content_length > 0 else None

        # Build upstream request — forward client headers verbatim
        upstream = f"{self.upstream_url}{self.path}"

        # Forward headers (skip hop-by-hop)
        skip_headers = {
            "host",
            "connection",
            "transfer-encoding",
            "proxy-connection",
            "keep-alive",
            "content-length",  # httpx sets this from the body automatically
        }
        forwarded_headers: dict[str, str] = {}
        for key, val in self.headers.items():
            if key.lower() not in skip_headers:
                forwarded_headers[key] = val

        # Forward to upstream — use raw_proxy_forward_streaming to stream
        # chunks as they arrive from llama-cpp-server.  This prevents
        # Cloudflare 524 timeouts: the edge sees the first byte of the
        # response as soon as the model starts generating (~0.5s), rather
        # than waiting for the full 105-125s inference to complete before
        # any data is sent downstream.  protocol_version="HTTP/1.1" (set
        # on the class) enables Transfer-Encoding: chunked on this path.
        #
        # For connection/timeout failures the stream never opens — fall
        # through to the buffered 502 path instead.
        resp_code = 502
        resp_headers: dict[str, str] = {}
        resp_body = b""
        server_ms: float | None = None
        gpu: dict | None = None
        elapsed_ms: float = 0.0

        stream: "_http.StreamingResponse | None" = None
        try:
            stream = _http.raw_proxy_forward_streaming(
                upstream,
                method,
                headers=forwarded_headers,
                body=body,
                timeout=_INFERENCE_PROXY_TIMEOUT_S,
            )
            resp_code = stream.status
            resp_headers = dict(stream.headers)
            server_ms_raw = resp_headers.get("openai-processing-ms") or resp_headers.get("Openai-Processing-Ms")
            if server_ms_raw:
                try:
                    server_ms = float(server_ms_raw)
                except (ValueError, TypeError):
                    pass

            elapsed_ms = (time.time() - t0) * 1000

            # Headers are available immediately (before body) — send them
            # now so Cloudflare and the peer know the response has started.
            self.send_response(resp_code)
            # Forward upstream headers; strip hop-by-hop and content-length
            # (we're using chunked encoding so content-length is invalid).
            skip_resp_headers = {"transfer-encoding", "connection", "keep-alive", "content-length"}
            for key, val in resp_headers.items():
                if key.lower() not in skip_resp_headers:
                    self.send_header(key, val)
            # Inject Maxim trace headers
            self.send_header("X-Maxim-Proxy-Ms", f"{elapsed_ms:.0f}")
            self.send_header("X-Maxim-Queue-Depth", f"{self._queue_depth()}")
            if server_ms is not None:
                self.send_header("X-Maxim-Server-Ms", f"{server_ms:.0f}")
            gpu = _query_nvidia_smi()
            if gpu is not None:
                self.send_header("X-Maxim-GPU-Util", f"{gpu['utilization_pct']:.0f}")
                self.send_header("X-Maxim-GPU-VRAM", f"{gpu['vram_used_gb']:.1f}/{gpu['vram_total_gb']:.0f}")
                if gpu.get("temperature_c") is not None:
                    self.send_header("X-Maxim-GPU-Temp", f"{gpu['temperature_c']:.0f}")
            self.send_header("Transfer-Encoding", "chunked")
            self.end_headers()

            # Stream body — write each chunk in HTTP/1.1 chunked format so
            # the peer receives tokens progressively.  Accumulate locally
            # for post-send usage logging (body is at most a few KB for
            # non-streaming chat completions).
            body_chunks: list[bytes] = []
            try:
                for chunk in stream.iter_bytes(chunk_size=16384):
                    if chunk:
                        body_chunks.append(chunk)
                        self.wfile.write(f"{len(chunk):x}\r\n".encode())
                        self.wfile.write(chunk)
                        self.wfile.write(b"\r\n")
                        self.wfile.flush()
            except Exception as chunk_err:
                # Mid-stream failure: log with request context so operators
                # can correlate with the peer-side dispatch_exhausted and
                # distinguish upstream crashes from client disconnects.
                logger.warning(
                    "Upstream stream interrupted (req=%s peer=%s path=%s chunks=%d elapsed_ms=%.0f): %s",
                    request_id[:8] if request_id else "none",
                    peer_ip,
                    self.path,
                    len(body_chunks),
                    (time.time() - t0) * 1000,
                    chunk_err,
                )
            # HTTP/1.1 chunked terminator
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
            resp_body = b"".join(body_chunks)

        except _http.HTTPError as e:
            # Typed HTTP failure from httpx (connection error, timeout, etc.)
            # — stream never opened, return a 502 with our error body.
            err_type = type(e).__name__
            logger.warning("Upstream error: %s: %s", err_type, e.fix_hint)
            resp_code = 502
            resp_body = json.dumps(
                {
                    "error": "Upstream connection failed — LLM server may be restarting",
                    "retry_after_s": 5,
                }
            ).encode()
            resp_headers = {}
        except Exception as e:
            # Anything else — log single line (no traceback for transient
            # connect errors during server respawn).
            err_type = type(e).__name__
            err_msg = str(e)
            if "Connection refused" in err_msg or "Connection reset" in err_msg:
                logger.warning("Upstream unavailable: %s (server may be restarting)", err_type)
            else:
                logger.warning("Upstream connection error: %s: %s", err_type, err_msg)
            resp_code = 502
            resp_body = json.dumps(
                {
                    "error": "Upstream connection failed — LLM server may be restarting",
                    "retry_after_s": 5,
                }
            ).encode()
            resp_headers = {}
        finally:
            if stream is not None:
                stream.close()

        # Error paths: stream never opened — send buffered 502 response.
        if stream is None:
            elapsed_ms = (time.time() - t0) * 1000
            gpu = _query_nvidia_smi()
            self.send_response(resp_code)
            self.send_header("Content-Type", "application/json")
            self.send_header("X-Maxim-Proxy-Ms", f"{elapsed_ms:.0f}")
            self.send_header("X-Maxim-Queue-Depth", f"{self._queue_depth()}")
            if gpu is not None:
                self.send_header("X-Maxim-GPU-Util", f"{gpu['utilization_pct']:.0f}")
            self.send_header("Content-Length", str(len(resp_body)))
            self.end_headers()
            self.wfile.write(resp_body)

        # Extract token counts from response body
        input_tokens = 0
        output_tokens = 0
        model = ""
        try:
            if resp_code == 200 and resp_body:
                data = json.loads(resp_body)
                usage = data.get("usage", {})
                input_tokens = usage.get("prompt_tokens", 0)
                output_tokens = usage.get("completion_tokens", 0)
                model = data.get("model", "")
        except Exception:
            pass

        # Log the request
        log_entry = {
            "request_id": request_id,
            "peer_ip": peer_ip,
            "method": method,
            "path": self.path,
            "model": model,
            "status": resp_code,
            "latency_ms": round(elapsed_ms, 1),
            "server_ms": round(server_ms, 1) if server_ms is not None else None,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "gpu": gpu,
            "timestamp": time.time(),
        }

        if self.request_log is not None:
            self.request_log.record(log_entry)

        # Phase 8: record into LaneMetrics for doctor / admission control
        if self.lane_metrics is not None and "/chat/completions" in self.path:
            self.lane_metrics.record_call(
                elapsed_ms,
                success=(resp_code == 200),
                kind="remote",
                input_tokens=input_tokens,
                output_tokens=output_tokens,
            )

        # Structured log line
        parts = [
            f"req={request_id[:8]}" if request_id else "req=none",
            f"peer={peer_ip}",
            f"{method} {self.path}",
            f"status={resp_code}",
            f"latency={elapsed_ms:.0f}ms",
        ]
        if server_ms is not None:
            parts.append(f"server={server_ms:.0f}ms")
        if input_tokens or output_tokens:
            parts.append(f"tokens={input_tokens}+{output_tokens}")
        if gpu:
            parts.append(f"gpu={gpu['utilization_pct']:.0f}%")
            parts.append(f"vram={gpu['vram_used_gb']:.1f}/{gpu['vram_total_gb']:.0f}G")
        logger.info("proxy: %s", " ".join(parts))

    # ─── admin endpoints ──────────────────────────────────────────────

    def _handle_admin_update(self) -> None:
        """POST /v1/admin/update — git pull + pip install on the leader.

        Requires MAXIM_ALLOW_REMOTE_UPDATE=1 on the leader process.
        Accepts JSON body: {"branch": "main", "dry_run": true/false}
        dry_run=true (default) previews pending commits without applying.
        """
        if not _remote_update_allowed():
            self._send_json(
                403,
                {"error": "Remote update disabled. Set MAXIM_ALLOW_REMOTE_UPDATE=1 on the leader."},
            )
            return

        params = self._parse_admin_update_body()
        if params is None:
            return  # error response already sent
        branch, dry_run, force = params

        repo_root = str(Path(__file__).resolve().parents[3])
        logger.info(
            "admin/update: peer=%s branch=%s dry_run=%s force=%s repo=%s",
            self.client_address[0],
            branch,
            dry_run,
            force,
            repo_root,
        )

        # 1. Stash dirty tree if --force; bail with 409 otherwise
        stashed = self._stash_if_dirty(repo_root, force)
        if stashed is None:
            return  # error response already sent

        # 2. Fetch latest from origin
        if not self._fetch_branch(repo_root, branch):
            return  # error response already sent

        # 3. Compute pending commits + handle dry-run / up-to-date paths
        pending = self._list_pending_commits(repo_root, branch)
        if not pending:
            self._send_json(
                200,
                {
                    "status": "up_to_date",
                    "message": f"Already up to date with origin/{branch}.",
                    "commits": [],
                },
            )
            return
        if dry_run:
            self._send_json(
                200,
                {
                    "status": "preview",
                    "branch": branch,
                    "pending_commits": pending,
                    "message": f"{len(pending)} commit(s) pending. Send dry_run=false to apply.",
                },
            )
            return

        # 4. Apply git pull (with stash restore on failure)
        if not self._apply_git_pull(repo_root, branch, stashed):
            return  # error response already sent

        if stashed:
            subprocess.run(
                ["git", "stash", "pop"],
                capture_output=True,
                timeout=10,
                cwd=repo_root,
            )
            logger.info("admin/update: restored stashed changes")

        # 5. pip install + rollback on failure
        pip_output = self._run_pip_install(repo_root)
        if pip_output is None:
            return  # error response already sent (with rollback status)

        # 6. Record + reply success
        if self.request_log is not None:
            self.request_log.record(
                {
                    "type": "admin_update",
                    "peer_ip": self.client_address[0],
                    "branch": branch,
                    "commits_applied": pending,
                    "timestamp": time.time(),
                }
            )
        logger.info("admin/update: SUCCESS — %d commits applied from origin/%s", len(pending), branch)
        self._send_json(
            200,
            {
                "status": "updated",
                "branch": branch,
                "commits_applied": pending,
                "pip_output": pip_output,
                "message": f"Applied {len(pending)} commit(s). Restart maxim to load new code.",
            },
        )

    def _parse_admin_update_body(self) -> tuple[str, bool, bool] | None:
        """Parse the JSON body and validate the branch name.

        Returns ``(branch, dry_run, force)`` or ``None`` if a 400 has
        already been sent.
        """
        raw = self._read_body(max_size=4096)
        body: dict[str, Any] = {}
        if raw:
            try:
                body = json.loads(raw)
            except Exception as e:
                logger.debug("admin/update: ignoring malformed JSON body: %s", e)

        raw_branch = body.get("branch", "main")
        try:
            branch = _validate_branch(raw_branch)
        except ValueError as e:
            self._send_json(400, {"error": f"Invalid branch: {e}"})
            return None
        return branch, bool(body.get("dry_run", True)), bool(body.get("force", False))

    def _stash_if_dirty(self, repo_root: str, force: bool) -> bool | None:
        """Stash dirty working tree under ``--force``; bail with 409 otherwise.

        Returns ``True`` if a stash was created, ``False`` if the tree was
        clean, or ``None`` if a 4xx/5xx error response has already been sent.
        """
        try:
            status = subprocess.run(
                ["git", "status", "--porcelain"],
                capture_output=True,
                text=True,
                timeout=10,
                cwd=repo_root,
            )
        except Exception as e:
            logger.exception("git status failed: %s", e)
            self._send_json(500, {"error": "git status check failed"})
            return None

        if not status.stdout.strip():
            return False

        if not force:
            self._send_json(
                409,
                {
                    "error": "Working tree is dirty. Commit or stash changes first.",
                    "hint": "Use: maxim peer update --force (stashes and restores automatically)",
                    "dirty_files": status.stdout.strip().split("\n"),
                },
            )
            return None

        stash_result = subprocess.run(
            ["git", "stash", "--include-untracked"],
            capture_output=True,
            text=True,
            timeout=10,
            cwd=repo_root,
        )
        stashed = stash_result.returncode == 0 and bool(stash_result.stdout.strip())
        logger.info("admin/update: stashed dirty tree (stashed=%s)", stashed)
        return stashed

    def _fetch_branch(self, repo_root: str, branch: str) -> bool:
        """``git fetch origin <branch>``. Returns False after sending a 500."""
        try:
            subprocess.run(
                ["git", "fetch", "origin", branch],
                capture_output=True,
                text=True,
                timeout=30,
                cwd=repo_root,
                check=True,
            )
            return True
        except Exception as e:
            logger.exception("git fetch failed: %s", e)
            self._send_json(500, {"error": "git fetch failed"})
            return False

    @staticmethod
    def _list_pending_commits(repo_root: str, branch: str) -> list[str]:
        """Return the list of ``HEAD..origin/<branch>`` commit lines (oneline)."""
        try:
            log_result = subprocess.run(
                ["git", "log", f"HEAD..origin/{branch}", "--oneline"],
                capture_output=True,
                text=True,
                timeout=10,
                cwd=repo_root,
            )
            return log_result.stdout.strip().split("\n") if log_result.stdout.strip() else []
        except Exception as e:
            logger.debug("git log HEAD..origin/%s failed: %s", branch, e)
            return []

    def _apply_git_pull(self, repo_root: str, branch: str, stashed: bool) -> bool:
        """``git pull --rebase``. Restores stash and sends 500 on failure."""
        try:
            subprocess.run(
                ["git", "-c", "pull.rebase=true", "pull", "origin", branch],
                capture_output=True,
                text=True,
                timeout=60,
                cwd=repo_root,
                check=True,
            )
            return True
        except subprocess.CalledProcessError as e:
            if stashed:
                subprocess.run(
                    ["git", "stash", "pop"],
                    capture_output=True,
                    timeout=10,
                    cwd=repo_root,
                )
            self._send_json(
                500,
                {
                    "error": "git pull failed",
                    "stdout": _sanitize_git_output(e.stdout),
                    "stderr": _sanitize_git_output(e.stderr),
                },
            )
            return False

    def _run_pip_install(self, repo_root: str) -> str | None:
        """Run ``pip install -e .`` and roll back on failure.

        Returns the (truncated) pip stdout on success, or ``None`` if an
        error response has already been sent (with rollback status).
        """
        try:
            pip_result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "-e", "."],
                capture_output=True,
                text=True,
                timeout=120,
                cwd=repo_root,
            )
        except Exception as e:
            logger.exception("pip install failed: %s", e)
            self._send_json(500, {"error": "pip install failed"})
            return None

        pip_output = pip_result.stdout[-500:] if pip_result.stdout else ""
        if pip_result.returncode == 0:
            return pip_output

        # Rollback: revert git + reinstall
        rollback = subprocess.run(
            ["git", "checkout", "HEAD~1"],
            capture_output=True,
            timeout=10,
            cwd=repo_root,
        )
        rollback_ok = rollback.returncode == 0
        reinstall = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-e", "."],
            capture_output=True,
            timeout=120,
            cwd=repo_root,
        )
        reinstall_ok = reinstall.returncode == 0
        if not rollback_ok or not reinstall_ok:
            logger.error(
                "admin/update: ROLLBACK INCOMPLETE — git=%s pip=%s",
                "ok" if rollback_ok else "FAILED",
                "ok" if reinstall_ok else "FAILED",
            )
        rollback_status = "complete" if (rollback_ok and reinstall_ok) else "INCOMPLETE"
        self._send_json(
            500,
            {
                "error": f"pip install failed, rollback {rollback_status}",
                "pip_stderr": _sanitize_git_output(pip_result.stderr),
                "rollback_git": "ok" if rollback_ok else "failed",
                "rollback_pip": "ok" if reinstall_ok else "failed",
            },
        )
        return None

    def _handle_admin_install(self) -> None:
        """POST /v1/admin/install — install packages on the leader.

        Requires MAXIM_ALLOW_REMOTE_UPDATE=1 on the leader process.
        Accepts JSON body: {"extras": ["semantic", "llm-torch"], "packages": ["some-pkg"]}
        Extras are installed as pymaxim[extra], raw packages via pip install.
        """
        if not _remote_update_allowed():
            self._send_json(
                403,
                {"error": "Remote install disabled. Set MAXIM_ALLOW_REMOTE_UPDATE=1 on the leader."},
            )
            return

        try:
            content_length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(content_length) if content_length else b"{}"
            params = json.loads(raw)
        except Exception as e:
            self._send_json(400, {"error": f"Invalid JSON body: {e}"})
            return

        extras = params.get("extras", [])
        packages = params.get("packages", [])

        if not extras and not packages:
            self._send_json(400, {"error": "No extras or packages specified."})
            return

        # ── Input validation — allowlist-only to prevent command injection ──
        _ALLOWED_EXTRAS = {
            "semantic",
            "llm-llama",
            "llm-server",
            "llm-torch",
            "llm-anthropic",
            "llm-openai",
            "vision",
            "audio",
            "reachy",
            "comms",
            "search",
            "temporal",
            "training",
            "tts",
            "yolo",
            "database",
        }
        # Strict pattern: alphanumeric, hyphens, dots, underscores only.
        # Rejects shell metacharacters, paths, URLs, version specifiers.
        _SAFE_PKG_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,100}$")

        for extra in extras:
            if extra not in _ALLOWED_EXTRAS:
                self._send_json(
                    400,
                    {"error": f"Unknown extra: {extra!r}. Allowed: {sorted(_ALLOWED_EXTRAS)}"},
                )
                return

        for pkg in packages:
            if not _SAFE_PKG_RE.match(pkg):
                self._send_json(
                    400,
                    {"error": f"Invalid package name: {pkg!r}. Only alphanumeric, hyphens, dots, underscores allowed."},
                )
                return

        # ── Build pip install commands ────────────────────────────────────
        # SECURITY: rebuild values from allowlist lookups — never pass the
        # original user strings to subprocess. This severs the dataflow
        # chain that static analyzers trace from request body to exec.
        repo_root = str(Path(__file__).resolve().parents[3])
        installed: list[str] = []
        pip_cmds: list[list[str]] = []

        # Rebuild extras from the allowlist (not from user input)
        safe_extras = [e for e in _ALLOWED_EXTRAS if e in extras]
        if safe_extras:
            extra_str = ",".join(safe_extras)
            spec = f".[{extra_str}]"
            pip_cmds.append([sys.executable, "-m", "pip", "install", spec])
            installed.extend(f"pymaxim[{e}]" for e in safe_extras)

        # Rebuild package names via regex match groups (severs taint chain)
        safe_packages: list[str] = []
        for pkg in packages:
            m = _SAFE_PKG_RE.match(pkg)
            if m:
                safe_packages.append(m.group(0))
        if safe_packages:
            pip_cmds.append([sys.executable, "-m", "pip", "install", *safe_packages])
            installed.extend(safe_packages)

        # Respond immediately — pip runs in a background thread to avoid
        # Cloudflare tunnel timeouts (524) on long-running installs.
        # Peer polls /v1/debug/install-status for completion.
        def _run_pip_background() -> None:
            for cmd in pip_cmds:
                try:
                    r = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        timeout=600,
                        cwd=repo_root,
                    )
                    _install_status["pip_output"] += (r.stdout or "")[-500:]
                    if r.returncode != 0:
                        _install_status["status"] = "error"
                        _install_status["error"] = r.stderr[-500:] if r.stderr else "pip failed"
                        return
                except Exception as exc:
                    _install_status["status"] = "error"
                    _install_status["error"] = str(exc)
                    return
            _install_status["status"] = "ok"

        # Store status in the module-level dict so the debug endpoint can read it
        _install_status.update(
            {
                "status": "running",
                "installed": installed,
                "pip_output": "",
                "error": "",
                "started_by": self.client_address[0],
            }
        )

        logger.info("admin/install: %s from peer %s (async)", installed, self.client_address[0])
        t = threading.Thread(target=_run_pip_background, name="admin.install", daemon=True)
        t.start()

        self._send_json(
            202,
            {
                "status": "started",
                "installed": installed,
                "message": "Install started. Poll /v1/debug/install-status for progress.",
            },
        )

    def _handle_debug_deps(self) -> None:
        """GET /v1/debug/deps — show installed packages relevant to maxim."""
        # Check which optional extras are importable
        extra_checks = {
            "semantic": "sentence_transformers",
            "llm-llama": "llama_cpp",
            "llm-torch": "torch",
            "llm-anthropic": "anthropic",
            "llm-openai": "openai",
            "vision": "cv2",
            "audio": "sounddevice",
            "search": "duckduckgo_search",
            "tts": "piper",
            "yolo": "ultralytics",
        }

        extras: dict[str, bool] = {}
        for extra_name, import_name in extra_checks.items():
            try:
                __import__(import_name)
                extras[extra_name] = True
            except ImportError:
                extras[extra_name] = False

        # Key packages with versions
        key_packages = [
            "numpy",
            "scipy",
            "pyyaml",
            "torch",
            "sentence-transformers",
            "anthropic",
            "openai",
            "open-clip-torch",
            "opencv-python",
            "pymaxim",
        ]
        packages: dict[str, str] = {}
        try:
            from importlib.metadata import version as pkg_version

            for pkg in key_packages:
                try:
                    packages[pkg] = pkg_version(pkg)
                except Exception:
                    pass
        except ImportError:
            pass

        self._send_json(200, {"extras": extras, "packages": packages})

    def _handle_admin_restart(self) -> None:
        """POST /v1/admin/restart — soft-restart the maxim process via os.execv.

        Replaces the current process image with a fresh Python invocation,
        reloading all code. Same PID, clean import cycle. Gated by
        MAXIM_ALLOW_REMOTE_UPDATE (if you trust remote code pulls, you
        trust remote restarts).

        Accepts JSON body: {"delay_s": 1.5} (default 1.5s delay so the
        HTTP response reaches the peer before the process replaces itself).
        """
        if os.environ.get("MAXIM_ALLOW_REMOTE_UPDATE", "").strip().lower() not in (
            "1",
            "true",
            "t",
            "yes",
            "y",
            "on",
        ):
            self._send_json(
                403,
                {
                    "error": "Remote restart disabled. Set MAXIM_ALLOW_REMOTE_UPDATE=1 on the leader.",
                },
            )
            return

        # Parse optional delay from body
        raw = self._read_body(max_size=4096)
        body: dict[str, Any] = {}
        if raw:
            try:
                body = json.loads(raw)
            except Exception:
                pass

        delay_s = max(0.5, min(float(body.get("delay_s", 1.5)), 10.0))

        uptime = round(time.time() - self.start_time, 1)
        logger.info(
            "admin/restart: peer=%s delay=%.1fs uptime=%.1fs",
            self.client_address[0],
            delay_s,
            uptime,
        )

        # Send response BEFORE restarting — the peer needs to receive this
        self._send_json(
            200,
            {
                "status": "restarting",
                "message": f"Restart initiated (delay {delay_s}s). Process will reload.",
                "uptime_s": uptime,
            },
        )

        # Schedule the restart on a background thread so the response
        # is fully flushed before os.execv replaces the process image.
        def _do_restart() -> None:
            time.sleep(delay_s)
            # Kill LLM server + cloudflared before replacing process image.
            # os.execv() does NOT fire atexit handlers, so we must clean up
            # child processes explicitly to prevent ghost servers.
            try:
                from maxim.runtime.lane_backends import stop_active_spawner

                stop_active_spawner()
                logger.info("admin/restart: LLM server stopped")
            except Exception as e:
                logger.warning("admin/restart: failed to stop LLM server: %s", e)
            try:
                from maxim.runtime.local_server_spawner import kill_stale_llm_servers

                kill_stale_llm_servers()
                logger.info("admin/restart: cleaned stale servers")
            except Exception:
                pass
            logger.info("admin/restart: executing os.execv — goodbye")
            # Re-exec with the original command line
            os.execv(sys.executable, [sys.executable] + sys.argv)

        t = threading.Thread(target=_do_restart, name="admin.restart", daemon=True)
        t.start()

    def _handle_admin_llm_swap(self) -> None:
        """POST /v1/admin/llm-swap — hot-swap the LLM model.

        Stops the current llama-cpp-server, resolves the new profile to a
        GGUF path, and starts a fresh server.  Does NOT restart the Maxim
        process — LeaderProxy stays alive throughout.

        Body: {"model": "qwen2.5-14b"}
        """
        if os.environ.get("MAXIM_ALLOW_REMOTE_UPDATE", "").strip().lower() not in (
            "1",
            "true",
            "t",
            "yes",
            "y",
            "on",
        ):
            self._send_json(
                403,
                {"error": "Remote LLM swap disabled. Set MAXIM_ALLOW_REMOTE_UPDATE=1 on the leader."},
            )
            return

        raw = self._read_body(max_size=4096)  # Admin body should be tiny
        body: dict[str, Any] = {}
        if raw:
            try:
                body = json.loads(raw)
            except Exception:
                self._send_json(400, {"error": "Invalid JSON body"})
                return

        model = str(body.get("model", "")).strip()
        if not model:
            self._send_json(400, {"error": "Missing 'model' field in request body"})
            return

        logger.info("admin/llm-swap: peer=%s model=%s", self.client_address[0], model)

        try:
            from maxim.runtime.lane_backends import swap_llm_server

            result = swap_llm_server(model, logger=logger)
            self._send_json(200, result)
        except ValueError as e:
            self._send_json(400, {"error": str(e)})
        except FileNotFoundError as e:
            msg = str(e)
            parts = msg.split("|", 1)
            # Sanitize — don't leak file paths in error responses
            safe_error = re.sub(r"/[\w./-]{5,}", "<path>", parts[0])
            resp: dict[str, Any] = {"error": safe_error}
            if len(parts) > 1:
                resp["hint"] = re.sub(r"/[\w./-]{5,}", "<path>", parts[1])
            self._send_json(404, resp)
        except RuntimeError as e:
            if "already in progress" in str(e):
                self._send_json(409, {"error": "LLM swap already in progress"})
            else:
                logger.error("LLM swap failed: %s", e)
                self._send_json(500, {"error": "LLM swap failed. Check server logs."})

    # ─── HTTP method dispatchers ──────────────────────────────────────

    def _is_localhost(self) -> bool:
        """Check if the request originates from localhost."""
        addr = self.client_address[0] if self.client_address else ""
        return addr in ("127.0.0.1", "::1", "localhost")

    def do_GET(self) -> None:  # noqa: N802
        # Debug endpoints: require auth OR restrict to localhost.
        # Prevents information disclosure (GPU state, model info, logs) to
        # unauthenticated remote callers via tunnel.
        if self._is_debug_path(self.path):
            if self._is_localhost() or self._check_auth():
                self._route_debug(self.path)
            return
        if not self._check_auth():
            return
        self._proxy_request("GET")

    def do_POST(self) -> None:  # noqa: N802
        if not self._check_auth():
            return
        stripped = self.path.rstrip("/").split("?")[0]
        if stripped == "/v1/admin/update":
            self._handle_admin_update()
            return
        if stripped == "/v1/admin/restart":
            self._handle_admin_restart()
            return
        if stripped == "/v1/admin/llm-swap":
            self._handle_admin_llm_swap()
            return
        if stripped == "/v1/admin/install":
            self._handle_admin_install()
            return
        if not self._check_admission():
            return
        try:
            self._proxy_request("POST")
        finally:
            self._release_concurrency()

    def do_HEAD(self) -> None:  # noqa: N802
        if not self._check_auth():
            return
        self._proxy_request("HEAD")

    def do_OPTIONS(self) -> None:  # noqa: N802
        """Handle CORS preflight."""
        self.send_response(204)
        cors_origin = os.environ.get("MAXIM_CORS_ORIGIN", "")
        if cors_origin:
            self.send_header("Access-Control-Allow-Origin", cors_origin)
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type, X-Maxim-Request-Id")
            self.send_header("Access-Control-Max-Age", "86400")
        self.end_headers()

    # ─── helpers ──────────────────────────────────────────────────────

    def _send_json(self, code: int, body: dict) -> None:
        data = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        # Security headers
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Cache-Control", "no-store")
        cors_origin = os.environ.get("MAXIM_CORS_ORIGIN", "")
        if cors_origin:
            self.send_header("Access-Control-Allow-Origin", cors_origin)
        self.end_headers()
        self.wfile.write(data)


# ─── server lifecycle ─────────────────────────────────────────────────────


_leader_proxy_server: HTTPServer | None = None


def start_leader_proxy(
    *,
    proxy_port: int | None = None,
    upstream_port: int | None = None,
    api_key: str | None = None,
    bind_host: str = "0.0.0.0",
) -> HTTPServer | None:
    """Start the LeaderProxy in a daemon thread.

    Returns the HTTPServer instance (for shutdown), or None on failure.
    Idempotent — returns the existing server if already started.
    """
    global _leader_proxy_server
    if proxy_port is None:
        proxy_port = int(
            os.environ.get(
                "MAXIM_LEADER_PROXY_PORT",
                str(DEFAULT_PROXY_PORT),
            )
        )
    # Idempotent guard for the default port (production). Tests use custom
    # ports and should always get fresh servers.
    if _leader_proxy_server is not None and proxy_port == DEFAULT_PROXY_PORT:
        return _leader_proxy_server
    if upstream_port is None:
        upstream_port = int(
            os.environ.get(
                "MAXIM_AUTO_SPAWN_PORT",
                str(DEFAULT_UPSTREAM_PORT),
            )
        )

    upstream_url = f"http://127.0.0.1:{upstream_port}"
    request_log = _RequestLog()

    # Install log buffer handler so /v1/debug/logs can serve log lines
    _ensure_log_buffer()

    # Phase 8: get the shared large tier metrics for proxy traffic recording
    infer_metrics = None
    try:
        from maxim.models.language.lane_metrics import get_metrics_registry

        infer_metrics = get_metrics_registry().get("large")
    except Exception:
        pass

    # Phase 7b: concurrency cap + per-peer rate limiter
    try:
        max_concurrent = int(os.environ.get("MAXIM_PROXY_MAX_CONCURRENT", "4"))
    except (ValueError, TypeError):
        logger.warning("Invalid MAXIM_PROXY_MAX_CONCURRENT value, using default 4")
        max_concurrent = 4
    semaphore = threading.Semaphore(max_concurrent) if max_concurrent > 0 else None

    peer_rate_limiter = None
    try:
        from maxim.runtime.rate_limiter import PeerRateLimiter

        peer_rate_limiter = PeerRateLimiter()
        if peer_rate_limiter.enabled:
            logger.info(
                "Per-peer rate limit: %s RPM",
                os.environ.get("MAXIM_PROXY_RATE_LIMIT_RPM", "0"),
            )
    except Exception as e:
        # Rate limiter init failed — proxy will run without per-peer rate
        # limiting even if MAXIM_PROXY_RATE_LIMIT_RPM is set. This is a
        # silent security gap if the operator configured a rate limit
        # expecting protection. Log at WARNING so it's immediately visible.
        logger.warning(
            "Failed to initialize per-peer rate limiter: %s — rate limiting disabled (check MAXIM_PROXY_RATE_LIMIT_RPM config)",
            e,
        )

    handler = type(
        "ProxyHandler",
        (_ProxyHandler,),
        {
            "api_key": api_key,
            "upstream_url": upstream_url,
            "request_log": request_log,
            "lane_metrics": infer_metrics,
            "concurrency_semaphore": semaphore,
            "rate_limiter": peer_rate_limiter,
            "start_time": time.time(),
        },
    )

    # ThreadingHTTPServer handles concurrent connections from cloudflared's
    # HTTP/2 multiplexing. Plain HTTPServer is single-threaded and blocks
    # POST requests while a keep-alive GET connection is open.
    class _ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
        daemon_threads = True

    try:
        server = _ThreadingHTTPServer((bind_host, proxy_port), handler)
    except OSError as e:
        logger.warning("LeaderProxy port %d in use: %s", proxy_port, e)
        return None

    thread = threading.Thread(
        target=server.serve_forever,
        daemon=True,
        name="leader-proxy",
    )
    thread.start()

    logger.info(
        "LeaderProxy listening on %s:%d → upstream %s (auth=%s, debug endpoints enabled)",
        bind_host,
        proxy_port,
        upstream_url,
        "on" if api_key else "off",
    )
    _leader_proxy_server = server
    return server


__all__ = ["start_leader_proxy", "DEFAULT_PROXY_PORT", "DEFAULT_UPSTREAM_PORT"]
