"""
Dev agent definition — system prompt and tool registration.
"""

from shipmate.config.project import PROJECT
from shipmate.engine.tool_registry import ToolRegistry
from shipmate.tools.file_tools import (
    list_directory,
    patch_file,
    read_file,
    search_files,
    write_file,
)
from shipmate.tools.git_tools import (
    checkout_branch,
    create_branch,
    git_changed_files,
    git_commit,
    git_diff,
    git_fetch,
    git_log,
    git_push,
    git_rebase,
    git_rebase_abort,
    git_rebase_continue,
    git_status,
)
from shipmate.tools.github_tools import (
    comment_on_pr,
    create_pull_request,
    get_pr_changed_files,
    list_ai_pull_requests,
    update_pull_request,
)
from shipmate.tools.shell_tools import (
    run_ruff_check,
    run_ruff_format,
    run_shell_command,
)


def _build_safety_rules() -> str:
    rules = "\n".join(f"  - {r}" for r in PROJECT.shared_service_rules)
    return f"SHARED SERVICE RULES (MUST follow):\n{rules}"


def build_system_prompt(project_context: str = "") -> str:
    """Build the system prompt for the dev agent."""
    return f"""You are a senior backend developer working on the {PROJECT.github_repo} project.
You write clean, production-quality Python/Django code following the project's established patterns.

You have access to tools for reading/writing files, running git operations, interacting with GitHub,
and running constrained shell commands (linting, formatting).

IMPORTANT GUIDELINES:
- Read existing code before making changes. Understand patterns before modifying.
- Follow the project's coding conventions (ruff-formatted, 100 char line length, Django patterns).
- All models should inherit from core.models.TimestampedModel.
- Serializers validate at the boundary.
- Do not add unnecessary abstractions or over-engineer solutions.
- Make focused, minimal changes that accomplish the task.
- Always run ruff check and ruff format before committing.
- Write clear commit messages explaining the "why", not just the "what".

{_build_safety_rules()}

PROJECT CONTEXT:
{project_context}
"""


def create_tool_registry() -> ToolRegistry:
    """Create a tool registry with all dev agent tools registered."""
    registry = ToolRegistry()
    registry.register_all(
        # File tools
        read_file,
        write_file,
        list_directory,
        search_files,
        patch_file,
        # Git tools
        create_branch,
        checkout_branch,
        git_fetch,
        git_rebase,
        git_rebase_continue,
        git_rebase_abort,
        git_commit,
        git_push,
        git_diff,
        git_changed_files,
        git_status,
        git_log,
        # GitHub tools
        create_pull_request,
        update_pull_request,
        comment_on_pr,
        list_ai_pull_requests,
        get_pr_changed_files,
        # Shell tools
        run_shell_command,
        run_ruff_check,
        run_ruff_format,
    )
    return registry
