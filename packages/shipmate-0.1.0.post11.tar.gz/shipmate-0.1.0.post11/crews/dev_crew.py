"""
Dev crew — assembles and runs a single dev agent for one task.
"""

import logging

from shipmate.agents.dev_agent import build_system_prompt, create_tool_registry
from shipmate.config.project import PROJECT
from shipmate.engine.agent_loop import run_agent
from shipmate.engine.providers import create_provider
from shipmate.tasks.dev_task import build_task_prompt

logger = logging.getLogger(__name__)


def run_dev_crew(
    task_description: str,
    branch_name: str,
    project_context: str = "",
    is_rebase: bool = False,
) -> str:
    """
    Build and run a dev agent for a single task.

    Returns the agent's final output as a string.
    """
    provider = create_provider(
        provider=PROJECT.llm_provider,
        model=PROJECT.llm_model,
        max_tokens=PROJECT.llm_max_tokens,
    )

    system_prompt = build_system_prompt(project_context=project_context)
    task_prompt = build_task_prompt(
        task_description=task_description,
        branch_name=branch_name,
        is_rebase=is_rebase,
    )
    registry = create_tool_registry()

    logger.info(f"Running agent with {len(registry.tool_names)} tools: {registry.tool_names}")

    return run_agent(
        provider=provider,
        system_prompt=system_prompt,
        task_prompt=task_prompt,
        registry=registry,
        max_iterations=50,
    )
