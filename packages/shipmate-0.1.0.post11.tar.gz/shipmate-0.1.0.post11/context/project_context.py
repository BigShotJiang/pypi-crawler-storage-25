"""
Builds runtime context from the repo for the dev agent.

Reads key project files (CLAUDE.md, decisions, etc.) and assembles a
structured context string the agent uses to understand the codebase.
"""

from pathlib import Path

from shipmate.config.project import PROJECT


def build_project_context(repo_root: str | Path) -> str:
    """Read context files from the cloned repo and return a combined context string."""
    repo_root = Path(repo_root)
    sections: list[str] = []

    # Read each configured context file
    for rel_path in PROJECT.context_files:
        full_path = repo_root / rel_path
        if full_path.exists():
            content = full_path.read_text(encoding="utf-8", errors="replace")
            sections.append(f"## {rel_path}\n\n{content}")

    # Add tech stack summary
    tech = "\n".join(f"- {t}" for t in PROJECT.tech_stack)
    sections.append(f"## Tech Stack\n\n{tech}")

    # Add shared service safety rules
    rules = "\n".join(f"- {r}" for r in PROJECT.shared_service_rules)
    sections.append(f"## Shared Service Safety Rules\n\n{rules}")

    # Add repo structure overview (top-level dirs)
    dirs = sorted(
        d.name for d in repo_root.iterdir()
        if d.is_dir() and not d.name.startswith(".")
    )
    sections.append(f"## Top-Level Directories\n\n{', '.join(dirs)}")

    return "\n\n---\n\n".join(sections)


def build_rebase_context(
    repo_root: str | Path,
    original_task: str,
    conflicts: list[str] | None = None,
) -> str:
    """Build context for a rebase/conflict-resolution run."""
    base = build_project_context(repo_root)
    extra = [
        "## Rebase Context",
        "",
        f"Original task: {original_task}",
        "",
        "You are re-running because master has advanced since your PR was opened.",
        "Your job is to:",
        "1. Rebase your branch onto the latest master.",
        "2. Resolve any merge conflicts safely.",
        "3. Re-run validation.",
        "4. Force-push the updated branch.",
        "5. Comment on the PR with what changed.",
    ]
    if conflicts:
        extra.append("")
        extra.append("Known conflicting files:")
        for f in conflicts:
            extra.append(f"- {f}")

    return base + "\n\n---\n\n" + "\n".join(extra)
