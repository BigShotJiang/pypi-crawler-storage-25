@echo off
REM Set up shipmate's isolated Python virtual environment (Windows).
REM Run this once from the shipmate\ directory.
REM
REM Usage:
REM   cd shipmate
REM   setup_venv.bat
REM
REM After setup, activate with:
REM   .venv\Scripts\activate

cd /d "%~dp0"

echo Creating shipmate virtual environment...
python -m venv .venv

call .venv\Scripts\activate.bat

echo Installing dependencies...
pip install --upgrade pip
pip install -r requirements.txt

echo.
echo Done. Activate with:
echo   shipmate\.venv\Scripts\activate
