"""
Task prompt builder for dev agent runs.
"""

import json
import os
from datetime import datetime, timezone

from shipmate.config.project import PROJECT


def _build_metadata_json(task_description: str, branch_name: str) -> str:
    """Build the JSON metadata string the agent should embed in the PR body."""
    meta = {
        "task": task_description,
        "agent_id": os.environ.get("AGENT_ID", "unknown"),
        "branch": branch_name,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "rebase_count": int(os.environ.get("AGENT_REBASE_COUNT", "0")),
    }
    return json.dumps(meta)


def build_task_prompt(
    task_description: str,
    branch_name: str,
    is_rebase: bool = False,
) -> str:
    """Build the task prompt for the dev agent.

    Args:
        task_description: Human description of what to build/fix.
        branch_name: The git branch this work should be on.
        is_rebase: Whether this is a rebase/conflict-resolution run.

    Returns:
        The full task prompt string.
    """

    if is_rebase:
        return f"""You are re-running on branch '{branch_name}' because master has advanced.

Your job:
1. Fetch the latest from origin.
2. Rebase your branch onto origin/{PROJECT.base_branch}.
3. Resolve any merge conflicts. For simple conflicts (different parts of file, import ordering,
   migration numbering), resolve them automatically. For semantic conflicts in the same
   function/method, or contradictory changes, mark the PR as needing human review.
4. Re-run validation: ruff check --fix and ruff format.
5. Force-push the updated branch.
6. Comment on the PR explaining what changed during the rebase.

Original task for context:
{task_description}
"""

    validation_steps = "\n".join(
        f"   - `{cmd}` ({desc})" for cmd, desc in PROJECT.validation_commands
    )
    return f"""Implement the following task on branch '{branch_name}':

{task_description}

After implementing:
1. Review your changes with git_diff to make sure they are correct and complete.
2. Run validation:
{validation_steps}
3. Fix any issues found by validation.
4. Commit all changes with a clear, descriptive commit message.
5. Push the branch to origin.
6. Create a pull request using the create_pull_request tool with:
   - A clear title prefixed with '{PROJECT.pr_title_prefix}'
   - A body summarizing what you changed and why
   - A list of validation steps you ran
   - Any blockers or warnings
   - IMPORTANT: pass this exact metadata string to the metadata parameter:
     {_build_metadata_json(task_description, branch_name)}

Remember:
- Read existing code before modifying it.
- Follow project conventions.
- Make focused, minimal changes.
- Do not modify shared infrastructure destructively.
"""
