"""
PR Monitor — always-on service that watches master for new commits
and re-spawns stale AI agent containers to rebase and update their PRs.

This is NOT an agent. It's a simple polling service.

Runs as a Docker container with access to the Docker socket (to spawn
sibling agent containers).

Environment variables:
    GITHUB_TOKEN        — GitHub PAT with repo access
    ANTHROPIC_API_KEY   — passed through to spawned agents
    GITHUB_REPO         — e.g. your-org/your-repo
    BASE_BRANCH         — e.g. master
    POLL_INTERVAL       — seconds between polls (default 60)
    DOCKER_NETWORK      — Docker network agents attach to
    AGENT_IMAGE         — agent Docker image name:tag
"""

import json
import logging
import os
import re
import sys
import time
from datetime import datetime, timezone

import docker
from github import Github, GithubException

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("shipmate.monitor")

# --- PR metadata parsing ---

_META_START = "<!-- SHIPMATE_META"
_META_END = "SHIPMATE_META -->"


def decode_pr_metadata(body: str) -> dict | None:
    """Extract shipmate metadata from a PR body."""
    if not body:
        return None
    match = re.search(
        rf"{re.escape(_META_START)}\s*(\{{.*?\}})\s*{re.escape(_META_END)}",
        body,
        re.DOTALL,
    )
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            return None
    return None


class PRMonitor:
    def __init__(self):
        self.github_token = os.environ["GITHUB_TOKEN"]
        self.anthropic_key = os.environ["ANTHROPIC_API_KEY"]
        self.repo_name = os.environ["GITHUB_REPO"]
        self.base_branch = os.environ.get("BASE_BRANCH", "main")
        self.poll_interval = int(os.environ.get("POLL_INTERVAL", "60"))
        self.docker_network = os.environ["DOCKER_NETWORK"]
        self.agent_image = os.environ.get("AGENT_IMAGE", "shipmate-agent:latest")

        self.gh = Github(self.github_token)
        self.repo = self.gh.get_repo(self.repo_name)
        self.docker_client = docker.from_env()

        self.last_master_sha: str | None = None
        self.active_respawns: set[str] = set()  # branch names currently being re-spawned

    def get_master_sha(self) -> str:
        """Get the latest commit SHA on the base branch."""
        branch = self.repo.get_branch(self.base_branch)
        return branch.commit.sha

    def get_open_ai_prs(self) -> list[dict]:
        """Get all open PRs on ai/* branches with their metadata."""
        prs = []
        for pr in self.repo.get_pulls(state="open", base=self.base_branch):
            if not pr.head.ref.startswith("shipmate/"):
                continue

            meta = decode_pr_metadata(pr.body or "")
            prs.append({
                "number": pr.number,
                "title": pr.title,
                "branch": pr.head.ref,
                "head_sha": pr.head.sha,
                "meta": meta,
            })
        return prs

    def is_branch_stale(self, pr: dict) -> bool:
        """Check if a PR's branch is behind master (needs rebase)."""
        try:
            comparison = self.repo.compare(
                self.last_master_sha, pr["head_sha"]
            )
            return comparison.behind_by > 0
        except GithubException:
            # If comparison fails, assume stale
            return True

    def respawn_agent(self, pr: dict) -> None:
        """Spawn an agent container in rebase mode for a stale PR."""
        branch = pr["branch"]
        meta = pr["meta"] or {}
        task = meta.get("task", f"Rebase and update PR #{pr['number']}")
        agent_id = meta.get("agent_id", f"rebase-{pr['number']}")
        container_name = f"shipmate-{agent_id}-rebase"

        if branch in self.active_respawns:
            logger.info(f"Skipping {branch} — respawn already active")
            return

        logger.info(f"Re-spawning agent for PR #{pr['number']} ({branch})")

        # Comment on PR
        try:
            gh_pr = self.repo.get_pull(pr["number"])
            gh_pr.create_issue_comment(
                f"**PR Monitor:** Master has advanced. Re-spawning agent to rebase.\n\n"
                f"Agent: `{agent_id}`\n"
                f"Container: `{container_name}`"
            )
        except GithubException as e:
            logger.warning(f"Failed to comment on PR #{pr['number']}: {e}")

        # Remove old container if exists
        try:
            old = self.docker_client.containers.get(container_name)
            old.remove(force=True)
        except docker.errors.NotFound:
            pass

        # Spawn agent container in rebase mode
        env = {
            "GITHUB_TOKEN": self.github_token,
            "ANTHROPIC_API_KEY": self.anthropic_key,
            "GITHUB_REPO": self.repo_name,
            "AGENT_TASK": task,
            "AGENT_BRANCH": branch,
            "AGENT_ID": agent_id,
            "AGENT_REBASE": "true",
            "BASE_BRANCH": self.base_branch,
        }

        # Increment rebase count in metadata
        rebase_count = meta.get("rebase_count", 0) + 1
        env["AGENT_REBASE_COUNT"] = str(rebase_count)

        try:
            container = self.docker_client.containers.run(
                image=self.agent_image,
                name=container_name,
                environment=env,
                network=self.docker_network,
                detach=True,
            )
            self.active_respawns.add(branch)
            logger.info(f"Agent container started: {container.short_id} for {branch}")
        except docker.errors.APIError as e:
            logger.error(f"Failed to spawn agent for {branch}: {e}")

    def cleanup_finished_respawns(self) -> None:
        """Remove branches from active_respawns if their container exited."""
        to_remove = set()
        for branch in self.active_respawns:
            # Find the container for this branch
            containers = self.docker_client.containers.list(
                all=True,
                filters={"name": "shipmate-"},
            )
            for c in containers:
                # Check env vars to match branch
                if c.status in ("exited", "dead", "removed"):
                    to_remove.add(branch)

        for branch in to_remove:
            self.active_respawns.discard(branch)
            logger.info(f"Respawn finished for {branch}")

    def cleanup_merged_containers(self) -> None:
        """Remove exited agent containers whose PRs have been merged or closed."""
        try:
            containers = self.docker_client.containers.list(
                all=True,
                filters={"name": "shipmate-", "status": "exited"},
            )
        except docker.errors.APIError as e:
            logger.error(f"Failed to list containers for cleanup: {e}")
            return

        for c in containers:
            if c.name == "shipmate-monitor":
                continue

            # Extract branch from container env vars
            branch = None
            try:
                env_list = c.attrs.get("Config", {}).get("Env", [])
                for item in env_list:
                    if item.startswith("AGENT_BRANCH="):
                        branch = item.split("=", 1)[1]
                        break
            except Exception:
                continue

            if not branch:
                continue

            # Check if the PR for this branch is merged or closed
            try:
                for pr in self.repo.get_pulls(
                    state="all", head=f"{self.repo.owner.login}:{branch}"
                ):
                    if pr.merged or pr.state == "closed":
                        logger.info(
                            f"Removing container {c.name} — PR #{pr.number} "
                            f"{'merged' if pr.merged else 'closed'}"
                        )
                        c.remove()
                        break
            except GithubException as e:
                logger.warning(f"Could not check PR status for {c.name}: {e}")
            except docker.errors.APIError as e:
                logger.error(f"Failed to remove container {c.name}: {e}")

    def poll(self) -> None:
        """One polling cycle."""
        try:
            current_sha = self.get_master_sha()

            if self.last_master_sha is None:
                # First run — just record the SHA
                self.last_master_sha = current_sha
                logger.info(f"Initial master SHA: {current_sha[:8]}")
                return

            if current_sha == self.last_master_sha:
                logger.debug("Master unchanged")
                self.cleanup_finished_respawns()
                self.cleanup_merged_containers()
                return

            logger.info(
                f"Master advanced: {self.last_master_sha[:8]} -> {current_sha[:8]}"
            )
            self.last_master_sha = current_sha

            # Check all open AI PRs
            ai_prs = self.get_open_ai_prs()
            logger.info(f"Found {len(ai_prs)} open AI PR(s)")

            for pr in ai_prs:
                if self.is_branch_stale(pr):
                    logger.info(f"PR #{pr['number']} ({pr['branch']}) is stale")
                    self.respawn_agent(pr)
                else:
                    logger.info(f"PR #{pr['number']} ({pr['branch']}) is up to date")

            self.cleanup_finished_respawns()
            self.cleanup_merged_containers()

        except GithubException as e:
            logger.error(f"GitHub API error: {e}")
        except Exception as e:
            logger.error(f"Poll error: {e}", exc_info=True)

    def run(self) -> None:
        """Main loop — poll forever."""
        logger.info(f"PR Monitor starting for {self.repo_name}")
        logger.info(f"Watching branch: {self.base_branch}")
        logger.info(f"Poll interval: {self.poll_interval}s")
        logger.info(f"Agent image: {self.agent_image}")
        logger.info(f"Docker network: {self.docker_network}")

        while True:
            self.poll()
            time.sleep(self.poll_interval)


def main():
    monitor = PRMonitor()
    monitor.run()


if __name__ == "__main__":
    main()
