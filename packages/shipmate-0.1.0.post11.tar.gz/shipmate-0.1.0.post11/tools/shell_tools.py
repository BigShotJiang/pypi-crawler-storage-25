"""
Shell tools for the dev agent.

Provides constrained shell access — only pre-approved commands can run.
The agent cannot execute arbitrary shell commands.
"""

import logging
import os
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

WORKSPACE = "/workspace"

# Built-in allowed command prefixes — always available
_BUILTIN_ALLOWED_PREFIXES = (
    "ruff ",
    "pytest ",
    "pip install",
    "pip list",
    "pip show",
    "cat ",
    "head ",
    "tail ",
    "wc ",
    "diff ",
    "find ",
    "ls ",
)

# Built-in blocked patterns — always blocked
_BUILTIN_BLOCKED_PATTERNS = (
    "rm -rf",
    "rm -r /",
    "DROP ",
    "DELETE FROM",
    "TRUNCATE",
    "FLUSHALL",
    "FLUSHDB",
)


def _get_allowed_prefixes() -> tuple[str, ...]:
    """Merge built-in allowlist with project-specific additions from shipmate.yml."""
    try:
        from shipmate.config.project import PROJECT
        return _BUILTIN_ALLOWED_PREFIXES + PROJECT.allowed_shell_prefixes
    except Exception:
        return _BUILTIN_ALLOWED_PREFIXES


def _get_blocked_patterns() -> tuple[str, ...]:
    """Merge built-in blocklist with project-specific additions from shipmate.yml."""
    try:
        from shipmate.config.project import PROJECT
        return _BUILTIN_BLOCKED_PATTERNS + PROJECT.blocked_shell_patterns
    except Exception:
        return _BUILTIN_BLOCKED_PATTERNS


def _is_allowed(command: str) -> tuple[bool, str]:
    """Check if a command is in the allowlist and not blocked."""
    cmd = command.strip()
    blocked_patterns = _get_blocked_patterns()
    allowed_prefixes = _get_allowed_prefixes()

    for blocked in blocked_patterns:
        if blocked.lower() in cmd.lower():
            return False, f"Blocked: command contains '{blocked}'"

    for prefix in allowed_prefixes:
        if cmd.startswith(prefix):
            return True, ""

    return False, (
        f"Command not in allowlist. Allowed prefixes: {', '.join(allowed_prefixes)}"
    )



def run_shell_command(command: str, working_dir: str = "") -> str:
    """Run a constrained shell command in the workspace.

    Only pre-approved commands are allowed. The agent cannot run arbitrary commands.

    Args:
        command: The shell command to run.
        working_dir: Working directory relative to workspace (default: workspace root).
    """
    return _run_command(command, working_dir)


def _run_command(command: str, working_dir: str = "") -> str:
    """Internal helper to run a validated shell command."""
    allowed, reason = _is_allowed(command)
    if not allowed:
        return f"DENIED: {reason}"

    cwd = WORKSPACE
    if working_dir:
        cwd = str(Path(WORKSPACE) / working_dir)

    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=120,
            cwd=cwd,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            output += "\nSTDERR:\n" + result.stderr
        if result.returncode != 0:
            output += f"\n[exit code: {result.returncode}]"
        return output.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return "Command timed out after 120 seconds"
    except Exception as e:
        return f"Error running command: {e}"



def run_ruff_check(path: str = ".", fix: bool = True) -> str:
    """Run ruff linter on the specified path.

    Args:
        path: Path relative to workspace (default '.').
        fix: Whether to auto-fix issues (default True).
    """
    cmd = f"ruff check {'--fix ' if fix else ''}{path}"
    return _run_command(cmd)



def run_ruff_format(path: str = ".") -> str:
    """Run ruff formatter on the specified path.

    Args:
        path: Path relative to workspace (default '.').
    """
    cmd = f"ruff format {path}"
    return _run_command(cmd)
