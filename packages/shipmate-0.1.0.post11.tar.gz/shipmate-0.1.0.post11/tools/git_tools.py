"""
Git tools for the dev agent.

All operations use GitPython against the local clone inside the container.
"""

import logging
from pathlib import Path

from git import Repo
from git.exc import GitCommandError

logger = logging.getLogger(__name__)


def _get_repo(repo_path: str = "/workspace") -> Repo:
    return Repo(repo_path)



def create_branch(branch_name: str, repo_path: str = "/workspace") -> str:
    """Create and checkout a new branch from the current HEAD.

    Args:
        branch_name: Name of the branch to create.
        repo_path: Path to the git repo (default /workspace).
    """
    repo = _get_repo(repo_path)
    try:
        repo.git.checkout("-b", branch_name)
        return f"Created and checked out branch: {branch_name}"
    except GitCommandError as e:
        return f"Error creating branch: {e}"



def checkout_branch(branch_name: str, repo_path: str = "/workspace") -> str:
    """Checkout an existing branch.

    Args:
        branch_name: Name of the branch to checkout.
        repo_path: Path to the git repo.
    """
    repo = _get_repo(repo_path)
    try:
        repo.git.checkout(branch_name)
        return f"Checked out branch: {branch_name}"
    except GitCommandError as e:
        return f"Error checking out branch: {e}"



def git_fetch(remote: str = "origin", repo_path: str = "/workspace") -> str:
    """Fetch latest changes from remote.

    Args:
        remote: Remote name (default 'origin').
        repo_path: Path to the git repo.
    """
    repo = _get_repo(repo_path)
    try:
        repo.git.fetch(remote)
        return f"Fetched from {remote}"
    except GitCommandError as e:
        return f"Error fetching: {e}"



def git_rebase(onto_branch: str = "origin/master", repo_path: str = "/workspace") -> str:
    """Rebase the current branch onto another branch.

    Args:
        onto_branch: Branch to rebase onto (default 'origin/master').
        repo_path: Path to the git repo.
    """
    repo = _get_repo(repo_path)
    try:
        repo.git.rebase(onto_branch)
        return f"Successfully rebased onto {onto_branch}"
    except GitCommandError as e:
        # Check for conflicts
        try:
            status = repo.git.status()
            if "both modified" in status or "Unmerged" in status:
                return f"Rebase conflict detected. Conflicting files:\n{status}\nResolve conflicts, then use git_rebase_continue."
        except Exception:
            pass
        return f"Rebase error: {e}"



def git_rebase_continue(repo_path: str = "/workspace") -> str:
    """Continue a rebase after resolving conflicts.

    Args:
        repo_path: Path to the git repo.
    """
    repo = _get_repo(repo_path)
    try:
        repo.git.rebase("--continue")
        return "Rebase continued successfully"
    except GitCommandError as e:
        return f"Error continuing rebase: {e}"



def git_rebase_abort(repo_path: str = "/workspace") -> str:
    """Abort a rebase in progress.

    Args:
        repo_path: Path to the git repo.
    """
    repo = _get_repo(repo_path)
    try:
        repo.git.rebase("--abort")
        return "Rebase aborted"
    except GitCommandError as e:
        return f"Error aborting rebase: {e}"



def git_commit(message: str, repo_path: str = "/workspace") -> str:
    """Stage all changes and commit.

    Args:
        message: Commit message.
        repo_path: Path to the git repo.
    """
    repo = _get_repo(repo_path)
    try:
        repo.git.add("-A")
        repo.git.commit("-m", message)
        sha = repo.head.commit.hexsha[:8]
        return f"Committed: {sha} — {message}"
    except GitCommandError as e:
        return f"Error committing: {e}"



def git_push(
    branch_name: str,
    force: bool = False,
    repo_path: str = "/workspace",
) -> str:
    """Push the current branch to origin.

    Args:
        branch_name: Branch to push.
        force: Whether to force-push (use for rebased branches).
        repo_path: Path to the git repo.
    """
    repo = _get_repo(repo_path)
    try:
        args = ["origin", branch_name]
        if force:
            args.insert(0, "--force-with-lease")
        repo.git.push(*args)
        return f"Pushed {branch_name} to origin" + (" (force)" if force else "")
    except GitCommandError as e:
        return f"Error pushing: {e}"



def git_diff(
    base_branch: str = "origin/master",
    repo_path: str = "/workspace",
) -> str:
    """Show the diff between the current branch and a base branch.

    Args:
        base_branch: Branch to diff against (default 'origin/master').
        repo_path: Path to the git repo.
    """
    repo = _get_repo(repo_path)
    try:
        diff = repo.git.diff(base_branch, "--stat")
        if not diff.strip():
            return "No changes relative to " + base_branch
        return diff
    except GitCommandError as e:
        return f"Error getting diff: {e}"



def git_changed_files(
    base_branch: str = "origin/master",
    repo_path: str = "/workspace",
) -> str:
    """List files changed between the current branch and a base branch.

    Args:
        base_branch: Branch to compare against (default 'origin/master').
        repo_path: Path to the git repo.
    """
    repo = _get_repo(repo_path)
    try:
        files = repo.git.diff(base_branch, "--name-only")
        if not files.strip():
            return "No files changed relative to " + base_branch
        return files
    except GitCommandError as e:
        return f"Error listing changed files: {e}"



def git_status(repo_path: str = "/workspace") -> str:
    """Show the current git status (staged, modified, untracked files).

    Args:
        repo_path: Path to the git repo.
    """
    repo = _get_repo(repo_path)
    return repo.git.status()



def git_log(count: int = 10, repo_path: str = "/workspace") -> str:
    """Show recent git log entries.

    Args:
        count: Number of log entries to show (default 10).
        repo_path: Path to the git repo.
    """
    repo = _get_repo(repo_path)
    return repo.git.log(f"-{count}", "--oneline", "--graph")
