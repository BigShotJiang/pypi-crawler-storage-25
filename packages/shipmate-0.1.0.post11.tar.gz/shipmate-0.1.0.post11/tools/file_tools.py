"""
File system tools for the dev agent.

Constrained to the workspace directory for safety.
"""

import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)

WORKSPACE = Path("/workspace")


def _safe_path(path: str) -> Path:
    """Resolve path and ensure it's within the workspace."""
    resolved = (WORKSPACE / path).resolve()
    if not str(resolved).startswith(str(WORKSPACE.resolve())):
        raise ValueError(f"Path escapes workspace: {path}")
    return resolved


def read_file(path: str) -> str:
    """Read the contents of a file in the workspace.

    Args:
        path: Path relative to the workspace root.
    """
    try:
        target = _safe_path(path)
        if not target.exists():
            return f"File not found: {path}"
        if not target.is_file():
            return f"Not a file: {path}"
        content = target.read_text(encoding="utf-8", errors="replace")
        if len(content) > 50000:
            return content[:50000] + f"\n\n... [truncated, total {len(content)} chars]"
        return content
    except ValueError as e:
        return str(e)
    except Exception as e:
        return f"Error reading file: {e}"


def write_file(path: str, content: str) -> str:
    """Write content to a file in the workspace. Creates parent directories if needed.

    Args:
        path: Path relative to the workspace root.
        content: File content to write.
    """
    try:
        target = _safe_path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return f"Written: {path} ({len(content)} chars)"
    except ValueError as e:
        return str(e)
    except Exception as e:
        return f"Error writing file: {e}"


def list_directory(path: str = ".", max_depth: int = 2) -> str:
    """List files and directories in the workspace.

    Args:
        path: Directory path relative to workspace root (default '.').
        max_depth: Maximum depth to recurse (default 2).
    """
    try:
        target = _safe_path(path)
        if not target.exists():
            return f"Directory not found: {path}"
        if not target.is_dir():
            return f"Not a directory: {path}"

        lines: list[str] = []
        _walk_dir(target, target, 0, max_depth, lines)
        return "\n".join(lines) if lines else "(empty directory)"
    except ValueError as e:
        return str(e)
    except Exception as e:
        return f"Error listing directory: {e}"


def _walk_dir(
    root: Path, current: Path, depth: int, max_depth: int, lines: list[str]
) -> None:
    if depth > max_depth:
        return
    indent = "  " * depth
    try:
        entries = sorted(current.iterdir(), key=lambda p: (not p.is_dir(), p.name))
    except PermissionError:
        lines.append(f"{indent}[permission denied]")
        return

    for entry in entries:
        if entry.name.startswith("."):
            continue
        rel = entry.relative_to(root)
        if entry.is_dir():
            lines.append(f"{indent}{entry.name}/")
            _walk_dir(root, entry, depth + 1, max_depth, lines)
        else:
            lines.append(f"{indent}{entry.name}")


def search_files(
    pattern: str,
    path: str = ".",
    file_pattern: str = "*.py",
) -> str:
    """Search for a text pattern in files within the workspace.

    Args:
        pattern: Text or regex pattern to search for.
        path: Directory to search in (relative to workspace, default '.').
        file_pattern: Glob pattern for files to search (default '*.py').
    """
    import re

    try:
        target = _safe_path(path)
        if not target.is_dir():
            return f"Not a directory: {path}"

        regex = re.compile(pattern, re.IGNORECASE)
        matches: list[str] = []
        for filepath in target.rglob(file_pattern):
            if not filepath.is_file():
                continue
            try:
                content = filepath.read_text(encoding="utf-8", errors="replace")
                for i, line in enumerate(content.splitlines(), 1):
                    if regex.search(line):
                        rel = filepath.relative_to(WORKSPACE)
                        matches.append(f"{rel}:{i}: {line.strip()}")
            except Exception:
                continue

            if len(matches) > 100:
                matches.append("... (truncated at 100 matches)")
                break

        return "\n".join(matches) if matches else f"No matches for '{pattern}'"
    except ValueError as e:
        return str(e)
    except Exception as e:
        return f"Error searching: {e}"


def patch_file(path: str, old_text: str, new_text: str) -> str:
    """Replace a specific text block in a file. Useful for targeted edits.

    Args:
        path: Path relative to the workspace root.
        old_text: Exact text to find and replace.
        new_text: Replacement text.
    """
    try:
        target = _safe_path(path)
        if not target.exists():
            return f"File not found: {path}"
        content = target.read_text(encoding="utf-8")
        if old_text not in content:
            return f"old_text not found in {path}"
        count = content.count(old_text)
        if count > 1:
            return f"old_text found {count} times in {path} — provide more context to make it unique"
        new_content = content.replace(old_text, new_text, 1)
        target.write_text(new_content, encoding="utf-8")
        return f"Patched {path}: replaced 1 occurrence"
    except ValueError as e:
        return str(e)
    except Exception as e:
        return f"Error patching file: {e}"
