#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# shipmate launcher
#
# Initializes the environment (venv, Docker image, secrets)
# and launches dev agents or the PR monitor.
#
# Usage:
#   bash shipmate/launch.sh agent "Add pagination to /api/products/"
#   bash shipmate/launch.sh agent "Fix bug in receipts" --id my-fix --no-detach
#   bash shipmate/launch.sh monitor
#   bash shipmate/launch.sh status
#   bash shipmate/launch.sh stop-monitor
#   bash shipmate/launch.sh build
# ─────────────────────────────────────────────────────────────

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
ENV_FILE="$PROJECT_ROOT/.env"
VENV_DIR="$SCRIPT_DIR/.venv"
AGENT_IMAGE="shipmate-agent:latest"
MONITOR_IMAGE="shipmate-monitor:latest"

# Resolve python command — macOS may only have python3
if command -v python3 &> /dev/null; then
    PYTHON=python3
elif command -v python &> /dev/null; then
    PYTHON=python
else
    echo "[shipmate] ERROR: Python not found. Install Python 3.12+ and try again."
    exit 1
fi

# ── Colors ──────────────────────────────────────────────────

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No color

# Use printf for color — portable across macOS (zsh default, bash 3.2) and Linux
info()  { printf "${CYAN}[shipmate]${NC} %s\n" "$1"; }
ok()    { printf "${GREEN}[shipmate]${NC} %s\n" "$1"; }
warn()  { printf "${YELLOW}[shipmate]${NC} %s\n" "$1"; }
error() { printf "${RED}[shipmate]${NC} %s\n" "$1"; }

# ── .env loading ────────────────────────────────────────────

load_env() {
    if [[ -f "$ENV_FILE" ]]; then
        # Export all non-comment, non-empty lines
        set -a
        while IFS='=' read -r key value; do
            # Skip comments and empty lines
            [[ "$key" =~ ^#.*$ || -z "$key" ]] && continue
            # Strip surrounding quotes from value
            value="${value%\"}"
            value="${value#\"}"
            value="${value%\'}"
            value="${value#\'}"
            # Only set if not already set in environment (env var takes precedence)
            if [[ -z "${!key}" ]]; then
                export "$key=$value"
            fi
        done < "$ENV_FILE"
        set +a
    fi
}

# ── Secret validation ──────────────────────────────────────

check_secrets() {
    local missing=0

    if [[ -z "$GITHUB_TOKEN" ]]; then
        error "GITHUB_TOKEN is not set."
        missing=1
    else
        ok "GITHUB_TOKEN is set (${#GITHUB_TOKEN} chars)"
    fi

    if [[ -z "$ANTHROPIC_API_KEY" ]]; then
        error "ANTHROPIC_API_KEY is not set."
        missing=1
    else
        ok "ANTHROPIC_API_KEY is set (${#ANTHROPIC_API_KEY} chars)"
    fi

    if [[ $missing -eq 1 ]]; then
        echo ""
        if [[ -f "$ENV_FILE" ]]; then
            error "Add the missing keys to $ENV_FILE and re-run."
        else
            error "No .env file found. Creating one from template..."
            create_env_file
            error "Edit $ENV_FILE with your keys, then re-run."
        fi
        exit 1
    fi
}

create_env_file() {
    if [[ -f "$PROJECT_ROOT/.env.example" ]]; then
        cp "$PROJECT_ROOT/.env.example" "$ENV_FILE"
        ok "Created .env from .env.example"
    else
        cat > "$ENV_FILE" <<'ENVEOF'
# shipmate secrets — this file is gitignored
ANTHROPIC_API_KEY=
GITHUB_TOKEN=
ENVEOF
        ok "Created minimal .env"
    fi
}

# ── Venv setup ─────────────────────────────────────────────

ensure_venv() {
    if [[ ! -d "$VENV_DIR" ]]; then
        info "Creating shipmate virtual environment..."
        $PYTHON -m venv "$VENV_DIR"

        activate_venv
        pip install --upgrade pip --quiet
        info "Installing shipmate dependencies..."
        pip install -r "$SCRIPT_DIR/requirements.txt" --quiet
        ok "Virtual environment ready."
    else
        activate_venv
    fi
}

activate_venv() {
    if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" || "$OSTYPE" == "cygwin" ]]; then
        source "$VENV_DIR/Scripts/activate"
    else
        source "$VENV_DIR/bin/activate"
    fi
}

# ── Docker checks ──────────────────────────────────────────

check_docker() {
    if ! docker info > /dev/null 2>&1; then
        error "Docker is not running. Start Docker Desktop and try again."
        exit 1
    fi
    ok "Docker is running."
}

resolve_network() {
    # Read network from SHIPMATE_DOCKER_NETWORK env, or parse from shipmate.yml
    if [[ -n "$SHIPMATE_DOCKER_NETWORK" ]]; then
        DOCKER_NETWORK="$SHIPMATE_DOCKER_NETWORK"
    elif [[ -f "$PROJECT_ROOT/shipmate.yml" ]]; then
        # Simple yaml parse — grab docker.network value
        DOCKER_NETWORK=$(grep -A1 "^docker:" "$PROJECT_ROOT/shipmate.yml" | grep "network:" | awk '{print $2}' | tr -d '"' | tr -d "'")
    fi

    if [[ -z "$DOCKER_NETWORK" ]]; then
        error "Docker network not configured. Set SHIPMATE_DOCKER_NETWORK or docker.network in shipmate.yml."
        exit 1
    fi
}

ensure_network() {
    resolve_network
    if ! docker network ls --format '{{.Name}}' | grep -q "^${DOCKER_NETWORK}$"; then
        warn "Docker network '$DOCKER_NETWORK' not found."
        info "Starting shared services (make up)..."
        (cd "$PROJECT_ROOT" && make up)
        # Verify network was created
        if ! docker network ls --format '{{.Name}}' | grep -q "^${DOCKER_NETWORK}$"; then
            error "Network still not found after 'make up'. Check docker-compose.yml."
            exit 1
        fi
    fi
    ok "Docker network '$DOCKER_NETWORK' exists."
}

ensure_agent_image() {
    if ! docker image inspect "$AGENT_IMAGE" > /dev/null 2>&1; then
        info "Agent image not found. Building..."
        build_agent_image
    else
        ok "Agent image '$AGENT_IMAGE' exists."
    fi
}

ensure_monitor_image() {
    if ! docker image inspect "$MONITOR_IMAGE" > /dev/null 2>&1; then
        info "Monitor image not found. Building..."
        build_monitor_image
    else
        ok "Monitor image '$MONITOR_IMAGE' exists."
    fi
}

build_agent_image() {
    info "Building agent image..."
    docker build -t "$AGENT_IMAGE" "$SCRIPT_DIR"
    ok "Agent image built: $AGENT_IMAGE"
}

build_monitor_image() {
    info "Building monitor image..."
    docker build -t "$MONITOR_IMAGE" -f "$SCRIPT_DIR/monitor/Dockerfile" "$SCRIPT_DIR/monitor"
    ok "Monitor image built: $MONITOR_IMAGE"
}

# ── Commands ───────────────────────────────────────────────

cmd_agent() {
    local task="$1"
    shift

    if [[ -z "$task" ]]; then
        error "Usage: launch.sh agent \"task description\" [--id ID] [--no-detach]"
        exit 1
    fi

    load_env
    check_secrets
    check_docker
    ensure_venv
    ensure_network
    ensure_agent_image

    echo ""
    info "Launching agent..."
    echo ""
    python -m shipmate run-agent --task "$task" "$@"
}

cmd_monitor() {
    load_env
    check_secrets
    check_docker
    ensure_venv
    ensure_network
    ensure_monitor_image

    echo ""
    info "Starting PR monitor..."
    echo ""
    python -m shipmate monitor-start "$@"
}

cmd_stop_monitor() {
    ensure_venv
    python -m shipmate monitor-stop
}

cmd_status() {
    ensure_venv
    echo ""
    info "Running containers:"
    docker ps --filter "name=shipmate" --format "table {{.Names}}\t{{.Status}}\t{{.Image}}\t{{.RunningFor}}"
    echo ""
}

cmd_build() {
    check_docker
    build_agent_image
    build_monitor_image
}

# ── Task commands ─────────────────────────────────────────

cmd_task() {
    local subcmd="$1"
    shift 2>/dev/null || true

    load_env
    ensure_venv

    case "$subcmd" in
        add)
            python -m shipmate task add "$@"
            ;;
        list|ls)
            python -m shipmate task list "$@"
            ;;
        remove|rm)
            python -m shipmate task remove "$@"
            ;;
        update)
            python -m shipmate task update "$@"
            ;;
        *)
            echo "Usage: launch.sh task <add|list|remove|update> [args]"
            echo ""
            echo "  add \"description\" [-p critical|high|normal|low] [--id ID]"
            echo "  list [-s pending|running|done|failed] [--all]"
            echo "  remove <task-id>"
            echo "  update <task-id> [-p priority] [-s status] [-d description]"
            ;;
    esac
}

cmd_work() {
    load_env
    check_secrets
    check_docker
    ensure_venv
    ensure_network
    ensure_agent_image

    python -m shipmate work "$@"
}

cmd_dashboard() {
    load_env
    ensure_venv
    python -m shipmate dashboard "$@"
}

cmd_logs() {
    local agent_id="$1"
    shift 2>/dev/null || true

    if [[ -z "$agent_id" ]]; then
        error "Usage: launch.sh logs <agent-id> [-f] [-n 50]"
        exit 1
    fi

    ensure_venv
    python -m shipmate logs "$agent_id" "$@"
}

cmd_review() {
    local identifier="$1"
    shift 2>/dev/null || true

    if [[ -z "$identifier" ]]; then
        error "Usage: launch.sh review <agent-id|task-id>"
        exit 1
    fi

    ensure_venv
    python -m shipmate review "$identifier" "$@"
}

cmd_retry() {
    local identifier="$1"
    shift 2>/dev/null || true

    if [[ -z "$identifier" ]]; then
        error "Usage: launch.sh retry <agent-id|task-id> [--no-detach]"
        exit 1
    fi

    load_env
    check_secrets
    check_docker
    ensure_venv
    ensure_network
    ensure_agent_image
    python -m shipmate retry "$identifier" "$@"
}

cmd_clean() {
    load_env
    ensure_venv
    python -m shipmate clean "$@"
}

cmd_help() {
    echo ""
    echo "shipmate launcher"
    echo ""
    echo "Usage:"
    echo "  bash shipmate/launch.sh <command> [args]"
    echo ""
    echo "Task Management:"
    echo "  task add \"desc\" [-p priority]   Add a task to the queue"
    echo "  task list                       List tasks"
    echo "  task remove <id>                Remove a task"
    echo "  task update <id> [-p] [-s]      Update a task"
    echo "  work [--all] [-n count]         Launch agents for pending tasks"
    echo "  dashboard [-w]                  Show live dashboard"
    echo ""
    echo "Direct Agent Control:"
    echo "  agent \"task\" [opts]             Launch agent directly (skip queue)"
    echo "  review <id>                     Review agent's work (task, logs, PR)"
    echo "  retry <id> [--no-detach]        Re-launch agent with original context"
    echo "  logs <id> [-f]                  Show agent logs"
    echo "  status                          Show running containers"
    echo "  clean [--all] [--dry-run]       Remove exited containers (merged PRs)"
    echo ""
    echo "Infrastructure:"
    echo "  build                           Build Docker images"
    echo "  monitor                         Start PR monitor"
    echo "  stop-monitor                    Stop PR monitor"
    echo ""
    echo "Priority levels: critical, high, normal (default), low"
    echo ""
    echo "Examples:"
    echo "  launch.sh task add \"Add pagination\" -p high"
    echo "  launch.sh task add \"Fix parser bug\" -p critical"
    echo "  launch.sh task list"
    echo "  launch.sh work                    # launch next task"
    echo "  launch.sh work --all              # launch all pending"
    echo "  launch.sh work -n 3               # launch top 3"
    echo "  launch.sh dashboard -w            # live dashboard"
    echo "  launch.sh review dev-a1b2c3         # full agent review"
    echo "  launch.sh retry dev-a1b2c3          # re-launch same agent"
    echo "  launch.sh agent \"Quick fix\" --no-detach"
    echo "  launch.sh logs dev-a1b2c3 -f"
    echo "  launch.sh clean                     # remove merged PR containers"
    echo "  launch.sh clean --all               # remove all exited containers"
    echo ""
}

# ── Main ───────────────────────────────────────────────────

COMMAND="${1:-help}"
shift 2>/dev/null || true

case "$COMMAND" in
    task)          cmd_task "$@" ;;
    work)          cmd_work "$@" ;;
    dashboard)     cmd_dashboard "$@" ;;
    review)        cmd_review "$@" ;;
    retry)         cmd_retry "$@" ;;
    logs)          cmd_logs "$@" ;;
    clean)         cmd_clean "$@" ;;
    agent)         cmd_agent "$@" ;;
    monitor)       cmd_monitor "$@" ;;
    stop-monitor)  cmd_stop_monitor ;;
    status)        cmd_status ;;
    build)         cmd_build ;;
    help|--help|-h) cmd_help ;;
    *)
        error "Unknown command: $COMMAND"
        cmd_help
        exit 1
        ;;
esac
