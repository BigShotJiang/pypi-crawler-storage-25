"""
Container entrypoint — the full lifecycle of one dev agent run.

This script runs INSIDE the agent Docker container. It:
1. Reads configuration from environment variables
2. Clones the repo
3. Creates or checks out the agent branch
4. Builds project context
5. Runs the dev agent (think → tool → repeat loop)
6. (Agent handles: edit code, validate, commit, push, create/update PR)
7. Exits
"""

import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from git import Repo
from git.exc import GitCommandError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("shipmate.entrypoint")


def main() -> int:
    # --- Read env vars ---
    github_token = os.environ.get("GITHUB_TOKEN")
    task_description = os.environ.get("AGENT_TASK", "")
    branch_name = os.environ.get("AGENT_BRANCH", "")
    agent_id = os.environ.get("AGENT_ID", "unknown")
    is_rebase = os.environ.get("AGENT_REBASE", "false").lower() == "true"
    repo_name = os.environ.get("GITHUB_REPO", "")
    base_branch = os.environ.get("BASE_BRANCH", "main")
    workspace = os.environ.get("WORKSPACE", "/workspace")

    if not github_token:
        logger.error("GITHUB_TOKEN is required")
        return 1
    if not repo_name:
        logger.error("GITHUB_REPO is required")
        return 1
    if not task_description:
        logger.error("AGENT_TASK is required")
        return 1
    if not branch_name:
        logger.error("AGENT_BRANCH is required")
        return 1
    if not os.environ.get("ANTHROPIC_API_KEY"):
        logger.error("ANTHROPIC_API_KEY is required")
        return 1

    logger.info(f"Agent ID: {agent_id}")
    logger.info(f"Task: {task_description[:100]}...")
    logger.info(f"Branch: {branch_name}")
    logger.info(f"Rebase mode: {is_rebase}")

    # --- Clone repo ---
    clone_url = f"https://x-access-token:{github_token}@github.com/{repo_name}.git"
    logger.info(f"Cloning {repo_name} into {workspace}...")

    try:
        repo = Repo.clone_from(clone_url, workspace)
    except GitCommandError as e:
        # If workspace already has the repo (e.g., rebase re-run), fetch instead
        if Path(workspace).joinpath(".git").exists():
            logger.info("Workspace already has repo, fetching...")
            repo = Repo(workspace)
            repo.git.fetch("--all")
        else:
            logger.error(f"Clone failed: {e}")
            return 1

    # Configure git identity
    repo.config_writer().set_value("user", "name", f"shipmate-{agent_id}").release()
    repo.config_writer().set_value("user", "email", f"shipmate-{agent_id}@noreply.github.com").release()

    # --- Create or checkout branch ---
    try:
        if is_rebase:
            # For rebase: checkout existing branch
            logger.info(f"Checking out existing branch: {branch_name}")
            repo.git.checkout(branch_name)
        else:
            # For new work: create branch from base
            logger.info(f"Creating branch: {branch_name} from {base_branch}")
            repo.git.checkout(base_branch)
            repo.git.checkout("-b", branch_name)
    except GitCommandError:
        # Branch might exist remotely but not locally
        try:
            repo.git.checkout("-b", branch_name, f"origin/{branch_name}")
        except GitCommandError as e:
            logger.error(f"Branch setup failed: {e}")
            return 1

    # --- Install project requirements for validation tools ---
    requirements_file = os.environ.get("REQUIREMENTS_FILE", "")
    if requirements_file:
        reqs_path = Path(workspace) / requirements_file
        if reqs_path.exists():
            import subprocess
            logger.info(f"Installing project requirements from {requirements_file}...")
            subprocess.run(
                ["pip", "install", "--quiet", "--no-cache-dir", "-r", str(reqs_path)],
                cwd=workspace,
                capture_output=True,
            )

    # --- Build project context ---
    logger.info("Building project context...")

    # Add workspace to Python path so shipmate imports work
    sys.path.insert(0, workspace)

    from shipmate.context.project_context import build_project_context, build_rebase_context

    if is_rebase:
        project_context = build_rebase_context(
            workspace, task_description
        )
    else:
        project_context = build_project_context(workspace)

    # --- Run agent ---
    logger.info("Starting dev agent...")

    from shipmate.crews.dev_crew import run_dev_crew

    try:
        result = run_dev_crew(
            task_description=task_description,
            branch_name=branch_name,
            project_context=project_context,
            is_rebase=is_rebase,
        )
        logger.info(f"Crew finished. Result:\n{result}")
    except Exception as e:
        logger.error(f"Crew execution failed: {e}", exc_info=True)

        # Even on failure, try to comment on the PR if one exists
        _comment_failure(branch_name, agent_id, str(e))
        return 1

    logger.info("Agent run complete.")
    return 0


def _comment_failure(branch_name: str, agent_id: str, error: str) -> None:
    """Best-effort: comment on the PR that the agent failed."""
    try:
        from github import Github

        token = os.environ.get("GITHUB_TOKEN", "")
        repo_name = os.environ.get("GITHUB_REPO", "")
        gh = Github(token)
        repo = gh.get_repo(repo_name)

        for pr in repo.get_pulls(state="open"):
            if pr.head.ref == branch_name:
                pr.create_issue_comment(
                    f"**AI Agent `{agent_id}` failed.**\n\n"
                    f"```\n{error[:2000]}\n```\n\n"
                    "This PR may need manual attention."
                )
                break
    except Exception:
        pass  # Best effort


if __name__ == "__main__":
    sys.exit(main())
