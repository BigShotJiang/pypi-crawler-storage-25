@echo off
setlocal enabledelayedexpansion

REM ─────────────────────────────────────────────────────────
REM shipmate launcher (Windows)
REM
REM Usage:
REM   shipmate\launch.bat agent "Add pagination to /api/products/"
REM   shipmate\launch.bat agent "Fix bug" --id my-fix --no-detach
REM   shipmate\launch.bat monitor
REM   shipmate\launch.bat status
REM   shipmate\launch.bat stop-monitor
REM   shipmate\launch.bat build
REM ─────────────────────────────────────────────────────────

set "SCRIPT_DIR=%~dp0"
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"

for %%I in ("%SCRIPT_DIR%\..") do set "PROJECT_ROOT=%%~fI"

set "ENV_FILE=%PROJECT_ROOT%\.env"
set "VENV_DIR=%SCRIPT_DIR%\.venv"
set "AGENT_IMAGE=shipmate-agent:latest"
set "MONITOR_IMAGE=shipmate-monitor:latest"

set "COMMAND=%~1"
if "%COMMAND%"=="" set "COMMAND=help"

if "%COMMAND%"=="task"          goto cmd_task
if "%COMMAND%"=="work"          goto cmd_work
if "%COMMAND%"=="dashboard"     goto cmd_dashboard
if "%COMMAND%"=="review"        goto cmd_review
if "%COMMAND%"=="retry"         goto cmd_retry
if "%COMMAND%"=="logs"          goto cmd_logs
if "%COMMAND%"=="clean"         goto cmd_clean
if "%COMMAND%"=="agent"         goto cmd_agent
if "%COMMAND%"=="monitor"       goto cmd_monitor
if "%COMMAND%"=="stop-monitor"  goto cmd_stop_monitor
if "%COMMAND%"=="status"        goto cmd_status
if "%COMMAND%"=="build"         goto cmd_build
if "%COMMAND%"=="help"          goto cmd_help
if "%COMMAND%"=="--help"        goto cmd_help
if "%COMMAND%"=="-h"            goto cmd_help

echo [shipmate] Unknown command: %COMMAND%
goto cmd_help

REM ── Load .env ─────────────────────────────────────────────

:load_env
if not exist "%ENV_FILE%" goto :eof
for /f "usebackq tokens=1,* delims==" %%A in ("%ENV_FILE%") do (
    set "line=%%A"
    REM Skip comments and empty lines
    if not "!line:~0,1!"=="#" (
        if not "%%A"=="" (
            REM Only set if not already defined
            if not defined %%A (
                set "%%A=%%B"
            )
        )
    )
)
goto :eof

REM ── Check secrets ────────────────────────────────────────

:check_secrets
set "missing=0"

if not defined GITHUB_TOKEN (
    echo [shipmate] ERROR: GITHUB_TOKEN is not set.
    set "missing=1"
) else (
    echo [shipmate] OK: GITHUB_TOKEN is set.
)

if not defined ANTHROPIC_API_KEY (
    echo [shipmate] ERROR: ANTHROPIC_API_KEY is not set.
    set "missing=1"
) else (
    echo [shipmate] OK: ANTHROPIC_API_KEY is set.
)

if "%missing%"=="1" (
    echo.
    if not exist "%ENV_FILE%" (
        echo [shipmate] No .env file found. Creating from template...
        call :create_env
    )
    echo [shipmate] Add the missing keys to %ENV_FILE% and re-run.
    exit /b 1
)
goto :eof

:create_env
if exist "%PROJECT_ROOT%\.env.example" (
    copy "%PROJECT_ROOT%\.env.example" "%ENV_FILE%" >nul
    echo [shipmate] Created .env from .env.example
) else (
    (
        echo # shipmate secrets — this file is gitignored
        echo ANTHROPIC_API_KEY=
        echo GITHUB_TOKEN=
    ) > "%ENV_FILE%"
    echo [shipmate] Created minimal .env
)
goto :eof

REM ── Venv setup ───────────────────────────────────────────

:ensure_venv
if not exist "%VENV_DIR%\Scripts\activate.bat" (
    echo [shipmate] Creating virtual environment...
    python -m venv "%VENV_DIR%"
    call "%VENV_DIR%\Scripts\activate.bat"
    pip install --upgrade pip --quiet
    echo [shipmate] Installing dependencies...
    pip install -r "%SCRIPT_DIR%\requirements.txt" --quiet
    echo [shipmate] Virtual environment ready.
) else (
    call "%VENV_DIR%\Scripts\activate.bat"
)
goto :eof

REM ── Docker checks ────────────────────────────────────────

:check_docker
docker info >nul 2>&1
if errorlevel 1 (
    echo [shipmate] ERROR: Docker is not running. Start Docker Desktop and try again.
    exit /b 1
)
echo [shipmate] OK: Docker is running.
goto :eof

:resolve_network
REM Read network from SHIPMATE_DOCKER_NETWORK env or shipmate.yml
if defined SHIPMATE_DOCKER_NETWORK (
    set "DOCKER_NETWORK=%SHIPMATE_DOCKER_NETWORK%"
    goto :eof
)
if exist "%PROJECT_ROOT%\shipmate.yml" (
    for /f "tokens=2 delims=: " %%A in ('findstr /c:"  network:" "%PROJECT_ROOT%\shipmate.yml"') do (
        set "DOCKER_NETWORK=%%A"
    )
)
if not defined DOCKER_NETWORK (
    echo [shipmate] ERROR: Docker network not configured. Set SHIPMATE_DOCKER_NETWORK or docker.network in shipmate.yml.
    exit /b 1
)
goto :eof

:ensure_network
call :resolve_network || exit /b 1
docker network ls --format "{{.Name}}" | findstr /x "%DOCKER_NETWORK%" >nul 2>&1
if errorlevel 1 (
    echo [shipmate] Docker network '%DOCKER_NETWORK%' not found. Starting shared services...
    pushd "%PROJECT_ROOT%"
    make up
    popd
)
echo [shipmate] OK: Docker network '%DOCKER_NETWORK%' exists.
goto :eof

:ensure_agent_image
docker image inspect "%AGENT_IMAGE%" >nul 2>&1
if errorlevel 1 (
    echo [shipmate] Agent image not found. Building...
    call :build_agent
) else (
    echo [shipmate] OK: Agent image exists.
)
goto :eof

:ensure_monitor_image
docker image inspect "%MONITOR_IMAGE%" >nul 2>&1
if errorlevel 1 (
    echo [shipmate] Monitor image not found. Building...
    call :build_monitor
) else (
    echo [shipmate] OK: Monitor image exists.
)
goto :eof

:build_agent
echo [shipmate] Building agent image...
docker build -t "%AGENT_IMAGE%" "%SCRIPT_DIR%"
echo [shipmate] Agent image built.
goto :eof

:build_monitor
echo [shipmate] Building monitor image...
docker build -t "%MONITOR_IMAGE%" -f "%SCRIPT_DIR%\monitor\Dockerfile" "%SCRIPT_DIR%\monitor"
echo [shipmate] Monitor image built.
goto :eof

REM ── Commands ─────────────────────────────────────────────

:cmd_task
call :load_env
call :ensure_venv
REM Pass all remaining args to the Python CLI
set "TASK_ARGS="
set "skip=1"
for %%A in (%*) do (
    if !skip! gtr 0 (
        set /a skip-=1
    ) else (
        set "TASK_ARGS=!TASK_ARGS! %%A"
    )
)
python -m shipmate task %TASK_ARGS%
goto :eof

:cmd_work
call :load_env
call :check_secrets || exit /b 1
call :check_docker || exit /b 1
call :ensure_venv
call :ensure_network
call :ensure_agent_image
set "WORK_ARGS="
set "skip=1"
for %%A in (%*) do (
    if !skip! gtr 0 (
        set /a skip-=1
    ) else (
        set "WORK_ARGS=!WORK_ARGS! %%A"
    )
)
python -m shipmate work %WORK_ARGS%
goto :eof

:cmd_dashboard
call :load_env
call :ensure_venv
set "DASH_ARGS="
set "skip=1"
for %%A in (%*) do (
    if !skip! gtr 0 (
        set /a skip-=1
    ) else (
        set "DASH_ARGS=!DASH_ARGS! %%A"
    )
)
python -m shipmate dashboard %DASH_ARGS%
goto :eof

:cmd_logs
set "LOG_AGENT=%~2"
if "%LOG_AGENT%"=="" (
    echo [shipmate] Usage: launch.bat logs ^<agent-id^> [-f] [-n 50]
    exit /b 1
)
call :ensure_venv
set "LOG_ARGS="
set "skip=2"
for %%A in (%*) do (
    if !skip! gtr 0 (
        set /a skip-=1
    ) else (
        set "LOG_ARGS=!LOG_ARGS! %%A"
    )
)
python -m shipmate logs "%LOG_AGENT%" %LOG_ARGS%
goto :eof

:cmd_review
set "REVIEW_ID=%~2"
if "%REVIEW_ID%"=="" (
    echo [shipmate] Usage: launch.bat review ^<agent-id^|task-id^>
    exit /b 1
)
call :ensure_venv
set "REVIEW_ARGS="
set "skip=2"
for %%A in (%*) do (
    if !skip! gtr 0 (
        set /a skip-=1
    ) else (
        set "REVIEW_ARGS=!REVIEW_ARGS! %%A"
    )
)
python -m shipmate review "%REVIEW_ID%" %REVIEW_ARGS%
goto :eof

:cmd_retry
set "RETRY_ID=%~2"
if "%RETRY_ID%"=="" (
    echo [shipmate] Usage: launch.bat retry ^<agent-id^|task-id^> [--no-detach]
    exit /b 1
)
call :load_env
call :check_secrets || exit /b 1
call :check_docker || exit /b 1
call :ensure_venv
call :ensure_network
call :ensure_agent_image
set "RETRY_ARGS="
set "skip=2"
for %%A in (%*) do (
    if !skip! gtr 0 (
        set /a skip-=1
    ) else (
        set "RETRY_ARGS=!RETRY_ARGS! %%A"
    )
)
python -m shipmate retry "%RETRY_ID%" %RETRY_ARGS%
goto :eof

:cmd_clean
call :load_env
call :ensure_venv
set "CLEAN_ARGS="
set "skip=1"
for %%A in (%*) do (
    if !skip! gtr 0 (
        set /a skip-=1
    ) else (
        set "CLEAN_ARGS=!CLEAN_ARGS! %%A"
    )
)
python -m shipmate clean %CLEAN_ARGS%
goto :eof

:cmd_agent
set "TASK=%~2"
if "%TASK%"=="" (
    echo [shipmate] ERROR: Usage: launch.bat agent "task description" [--id ID] [--no-detach]
    exit /b 1
)

call :load_env
call :check_secrets || exit /b 1
call :check_docker || exit /b 1
call :ensure_venv
call :ensure_network
call :ensure_agent_image

echo.
echo [shipmate] Launching agent...
echo.

REM Build args: skip first two positional args (command + task), pass the rest
set "EXTRA_ARGS="
set "skip=2"
for %%A in (%*) do (
    if !skip! gtr 0 (
        set /a skip-=1
    ) else (
        set "EXTRA_ARGS=!EXTRA_ARGS! %%A"
    )
)

python -m shipmate run-agent --task "%TASK%" %EXTRA_ARGS%
goto :eof

:cmd_monitor
call :load_env
call :check_secrets || exit /b 1
call :check_docker || exit /b 1
call :ensure_venv
call :ensure_network
call :ensure_monitor_image

echo.
echo [shipmate] Starting PR monitor...
echo.

set "EXTRA_ARGS="
set "skip=1"
for %%A in (%*) do (
    if !skip! gtr 0 (
        set /a skip-=1
    ) else (
        set "EXTRA_ARGS=!EXTRA_ARGS! %%A"
    )
)

python -m shipmate monitor-start %EXTRA_ARGS%
goto :eof

:cmd_stop_monitor
call :ensure_venv
python -m shipmate monitor-stop
goto :eof

:cmd_status
echo.
echo [shipmate] Running containers:
docker ps --filter "name=shipmate" --format "table {{.Names}}\t{{.Status}}\t{{.Image}}\t{{.RunningFor}}"
echo.
goto :eof

:cmd_build
call :check_docker || exit /b 1
call :build_agent
call :build_monitor
goto :eof

:cmd_help
echo.
echo shipmate launcher
echo.
echo Usage:
echo   shipmate\launch.bat ^<command^> [args]
echo.
echo Task Management:
echo   task add "desc" [-p priority]   Add a task to the queue
echo   task list                       List tasks
echo   task remove ^<id^>                Remove a task
echo   task update ^<id^> [-p] [-s]      Update a task
echo   work [--all] [-n count]         Launch agents for pending tasks
echo   dashboard [-w]                  Show live dashboard
echo.
echo Direct Agent Control:
echo   agent "task" [opts]             Launch agent directly (skip queue)
echo   review ^<id^>                     Review agent's work (task, logs, PR)
echo   retry ^<id^> [--no-detach]        Re-launch agent with original context
echo   logs ^<id^> [-f]                  Show agent logs
echo   status                          Show running containers
echo   clean [--all] [--dry-run]       Remove exited containers (merged PRs)
echo.
echo Infrastructure:
echo   build                           Build Docker images
echo   monitor                         Start PR monitor
echo   stop-monitor                    Stop PR monitor
echo.
echo Priority levels: critical, high, normal (default), low
echo.
echo Examples:
echo   launch.bat task add "Add pagination" -p high
echo   launch.bat task add "Fix parser bug" -p critical
echo   launch.bat task list
echo   launch.bat work                    Launch next task
echo   launch.bat work --all              Launch all pending
echo   launch.bat dashboard -w            Live dashboard
echo   launch.bat review dev-a1b2c3        Review agent's work
echo   launch.bat retry dev-a1b2c3         Re-launch same agent
echo   launch.bat agent "Quick fix" --no-detach
echo   launch.bat logs dev-a1b2c3 -f
echo   launch.bat clean                    Remove merged PR containers
echo   launch.bat clean --all              Remove all exited containers
echo.
goto :eof
