"""
Host-side CLI for shipmate.

Run this on your machine (not inside a container). It launches agent containers,
builds images, manages tasks, and monitors agents.

Usage:
    python -m shipmate task add "Add pagination to /api/products/" --priority high
    python -m shipmate task list
    python -m shipmate work
    python -m shipmate work --all
    python -m shipmate dashboard
    python -m shipmate run-agent --task "..." [--id my-agent]
    python -m shipmate build
    python -m shipmate monitor-start
"""

import hashlib
import json
import os
import re
import sys
import time
from datetime import datetime, timezone

import click
import docker

from shipmate.config.project import PROJECT


def _generate_slug(task: str, max_len: int = 40) -> str:
    """Generate a URL-safe slug from a task description."""
    slug = re.sub(r"[^a-z0-9]+", "-", task.lower()).strip("-")
    if len(slug) > max_len:
        slug = slug[:max_len].rsplit("-", 1)[0]
    return slug


def _generate_agent_id(task: str) -> str:
    task_hash = hashlib.md5(task.encode()).hexdigest()[:6]
    return f"dev-{task_hash}"


def _generate_branch_name(task: str, agent_id: str) -> str:
    """Generate a unique branch name."""
    slug = _generate_slug(task)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    return f"{PROJECT.branch_prefix}/{agent_id}-{slug}-{ts}"


def _get_docker_client() -> docker.DockerClient:
    return docker.from_env()


def _validate_env() -> tuple[str, str]:
    """Validate required env vars, return (github_token, anthropic_key)."""
    github_token = os.environ.get("GITHUB_TOKEN", "")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")

    if not github_token:
        click.echo("Error: GITHUB_TOKEN not set.", err=True)
        sys.exit(1)
    if not anthropic_key:
        click.echo("Error: ANTHROPIC_API_KEY not set.", err=True)
        sys.exit(1)
    if not PROJECT.github_repo:
        click.echo("Error: GITHUB_REPO not configured. Set in shipmate.yml or SHIPMATE_GITHUB_REPO.", err=True)
        sys.exit(1)
    if not PROJECT.docker_network:
        click.echo("Error: Docker network not configured. Set in shipmate.yml or SHIPMATE_DOCKER_NETWORK.", err=True)
        sys.exit(1)

    return github_token, anthropic_key


def _launch_agent_container(
    task: str,
    agent_id: str,
    branch: str,
    github_token: str,
    anthropic_key: str,
    base_branch: str | None = None,
    rebase: bool = False,
    detach: bool = True,
) -> str | None:
    """Launch an agent container. Returns container short_id if detached, None if foreground."""
    base = base_branch or PROJECT.base_branch
    image = f"{PROJECT.agent_image_name}:{PROJECT.agent_image_tag}"
    container_name = f"shipmate-{agent_id}"

    env = {
        "GITHUB_TOKEN": github_token,
        "ANTHROPIC_API_KEY": anthropic_key,
        "GITHUB_REPO": PROJECT.github_repo,
        "AGENT_TASK": task,
        "AGENT_BRANCH": branch,
        "AGENT_ID": agent_id,
        "AGENT_REBASE": str(rebase).lower(),
        "BASE_BRANCH": base,
        "REQUIREMENTS_FILE": PROJECT.requirements_file,
    }

    client = _get_docker_client()

    # Remove old container with same name if exists
    try:
        old = client.containers.get(container_name)
        old.remove(force=True)
    except docker.errors.NotFound:
        pass

    try:
        container = client.containers.run(
            image=image,
            name=container_name,
            environment=env,
            network=PROJECT.docker_network,
            detach=detach,
            remove=not detach,
        )
    except docker.errors.ImageNotFound:
        click.echo(f"\nImage '{image}' not found. Run: python -m shipmate build", err=True)
        return None
    except docker.errors.APIError as e:
        click.echo(f"\nDocker error: {e}", err=True)
        return None

    if detach:
        return container.short_id
    return None


# ═══════════════════════════════════════════════════════════
# CLI Groups
# ═══════════════════════════════════════════════════════════

@click.group()
def cli():
    """shipmate — autonomous dev agent launcher."""
    pass


# ── Task Management ─────────────────────────────────────────

@cli.group()
def task():
    """Manage the task queue."""
    pass


@task.command("add")
@click.argument("description")
@click.option("--priority", "-p", default="normal",
              type=click.Choice(["critical", "high", "normal", "low"]),
              help="Task priority (default: normal).")
@click.option("--id", "task_id", default=None, help="Custom task ID (auto-generated if omitted).")
def task_add(description: str, priority: str, task_id: str | None):
    """Add a new task to the queue.

    DESCRIPTION is what you want the agent to do.

    Examples:
      task add "Add pagination to /api/products/" --priority high
      task add "Fix receipt parser bug" --priority critical --id fix-parser
    """
    from shipmate.task_manager import add_task

    try:
        t = add_task(description, priority=priority, task_id=task_id)
        click.echo(f"Task added: {t['id']} [{t['priority']}]")
        click.echo(f"  {t['description']}")
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


def _fmt_time(iso_str: str | None) -> str:
    """Format an ISO timestamp to a short readable string, or '--' if empty."""
    if not iso_str:
        return "--"
    try:
        # Handle both timezone-aware and naive timestamps
        ts = iso_str.replace("+00:00", "").replace("Z", "")
        # Parse and format as short datetime
        dt = datetime.fromisoformat(ts)
        return dt.strftime("%m/%d %H:%M")
    except Exception:
        return iso_str[:16]


def _fmt_duration(start_str: str | None, end_str: str | None) -> str:
    """Calculate duration between two ISO timestamps."""
    if not start_str or not end_str:
        return ""
    try:
        start = datetime.fromisoformat(start_str.replace("+00:00", "").replace("Z", ""))
        end = datetime.fromisoformat(end_str.replace("+00:00", "").replace("Z", ""))
        delta = end - start
        total_secs = int(delta.total_seconds())
        if total_secs < 0:
            return ""
        if total_secs < 60:
            return f"{total_secs}s"
        if total_secs < 3600:
            return f"{total_secs // 60}m {total_secs % 60}s"
        hours = total_secs // 3600
        mins = (total_secs % 3600) // 60
        return f"{hours}h {mins}m"
    except Exception:
        return ""


def _get_live_agent_status(agent_id: str, docker_client) -> tuple[str, str]:
    """Look up live Docker container status. Returns (status, color)."""
    if not agent_id:
        return ("--", "white")
    container_name = f"shipmate-{agent_id}"
    try:
        c = docker_client.containers.get(container_name)
        if c.status == "running":
            return ("RUNNING", "cyan")
        elif c.status == "exited":
            exit_code = c.attrs.get("State", {}).get("ExitCode", -1)
            if exit_code == 0:
                return ("DONE", "green")
            else:
                return (f"FAIL({exit_code})", "red")
        else:
            return (c.status.upper(), "yellow")
    except docker.errors.NotFound:
        return ("--", "white")
    except Exception:
        return ("?", "yellow")


def _get_live_pr_status(branch: str, gh_repo) -> tuple[str, str, str]:
    """Look up live PR status on GitHub. Returns (status, color, pr_url)."""
    if not gh_repo or not branch:
        return ("--", "white", "")
    try:
        owner = gh_repo.owner.login
        # Check all PRs for this branch
        for pr in gh_repo.get_pulls(state="all", head=f"{owner}:{branch}"):
            url = pr.html_url
            if pr.merged:
                return ("MERGED", "green", url)
            elif pr.state == "open":
                return ("OPEN", "cyan", url)
            elif pr.state == "closed":
                return ("DECLINED", "red", url)
        return ("NO PR", "yellow", "")
    except Exception:
        return ("?", "yellow", "")


@task.command("list")
@click.option("--status", "-s", default=None,
              type=click.Choice(["pending", "running", "done", "failed", "cancelled"]),
              help="Filter by task status.")
@click.option("--priority", "-p", default=None,
              type=click.Choice(["critical", "high", "normal", "low"]),
              help="Filter by priority.")
@click.option("--all", "show_all", is_flag=True, help="Show all tasks including done/failed.")
def task_list(status: str | None, priority: str | None, show_all: bool):
    """List tasks with live agent and PR status."""
    from shipmate.task_manager import list_tasks, PRIORITY_ORDER

    tasks = list_tasks(status=status, priority=priority)

    if not show_all and not status:
        tasks = [t for t in tasks if t.get("status") not in ("cancelled",)]

    if not tasks:
        click.echo("No tasks found.")
        return

    # Sort by priority then created_at
    tasks.sort(key=lambda t: (
        PRIORITY_ORDER.get(t.get("priority", "normal"), 2),
        t.get("created_at", ""),
    ))

    # Live lookups
    docker_client = _get_docker_client()
    gh_repo = _get_gh_repo()

    pri_sym = {"critical": "!!!", "high": " !!", "normal": "  .", "low": "  -"}

    click.echo("")
    click.echo(f"  {'PRI':>3}  {'ID':<22} {'AGENT':<10} {'PR':<10} {'ADDED':<12} {'STARTED':<12} {'COMPLETED':<12} DESCRIPTION")
    click.echo(f"  {'---':>3}  {'--':<22} {'-----':<10} {'--':<10} {'-----':<12} {'-------':<12} {'---------':<12} -----------")

    for t in tasks:
        pri = pri_sym.get(t.get("priority", "normal"), "  .")
        tid = t.get("id", "?")[:22]
        desc = t.get("description", "")[:45]
        agent_id = t.get("agent_id", "")
        branch = t.get("branch", "")

        # Timestamps
        added = _fmt_time(t.get("created_at"))
        started = _fmt_time(t.get("started_at"))
        completed = _fmt_time(t.get("finished_at"))

        # Live agent status
        if agent_id:
            agent_str, agent_color = _get_live_agent_status(agent_id, docker_client)
        else:
            agent_str, agent_color = ("QUEUED", "white")

        # Live PR status
        if branch and agent_id:
            pr_str, pr_color, pr_url = _get_live_pr_status(branch, gh_repo)
        else:
            pr_str, pr_color, pr_url = ("--", "white", "")

        # Build the line
        line_start = f"  {pri:>3}  {tid:<22} "
        agent_part = click.style(f"{agent_str:<10}", fg=agent_color)
        pr_part = click.style(f"{pr_str:<10}", fg=pr_color)
        time_part = f"{added:<12} {started:<12} {completed:<12} "
        click.echo(line_start + agent_part + pr_part + time_part + desc)

        # Show PR URL and duration on next line if available
        extra = ""
        if pr_url:
            extra += pr_url
        duration = _fmt_duration(t.get("started_at"), t.get("finished_at"))
        if duration:
            extra += f"  (duration: {duration})" if extra else f"duration: {duration}"
        if extra:
            click.echo(f"       {extra}")

    click.echo("")

    # Also sync task states silently so ai_tasks.yml stays in sync
    _sync_task_states(verbose=False)


@task.command("remove")
@click.argument("task_id")
def task_remove(task_id: str):
    """Remove a task from the queue."""
    from shipmate.task_manager import remove_task

    if remove_task(task_id):
        click.echo(f"Removed: {task_id}")
    else:
        click.echo(f"Task not found: {task_id}", err=True)
        sys.exit(1)


@task.command("update")
@click.argument("task_id")
@click.option("--priority", "-p",
              type=click.Choice(["critical", "high", "normal", "low"]),
              help="New priority.")
@click.option("--status", "-s",
              type=click.Choice(["pending", "running", "done", "failed", "cancelled"]),
              help="New status.")
@click.option("--description", "-d", help="New description.")
def task_update(task_id: str, priority: str | None, status: str | None, description: str | None):
    """Update a task's priority, status, or description."""
    from shipmate.task_manager import update_task

    updates = {}
    if priority:
        updates["priority"] = priority
    if status:
        updates["status"] = status
    if description:
        updates["description"] = description

    if not updates:
        click.echo("Nothing to update. Use --priority, --status, or --description.", err=True)
        sys.exit(1)

    try:
        t = update_task(task_id, **updates)
        click.echo(f"Updated: {t['id']} [{t.get('priority')}] {t.get('status')}")
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


# ── Work — launch agents from the task queue ────────────────

@cli.command()
@click.option("--all", "launch_all", is_flag=True, help="Launch agents for ALL pending tasks.")
@click.option("--count", "-n", default=1, type=int, help="Number of tasks to launch (default: 1).")
@click.option("--no-detach", is_flag=True, help="Run in foreground (only with single task).")
def work(launch_all: bool, count: int, no_detach: bool):
    """Pick up pending tasks and launch agents for them.

    By default, launches the next highest-priority pending task.
    Use --all to launch agents for every pending task, or -n 3 for the top 3.
    """
    from shipmate.task_manager import mark_running, mark_failed, pending_tasks_by_priority

    github_token, anthropic_key = _validate_env()

    pending = pending_tasks_by_priority()
    if not pending:
        click.echo("No pending tasks. Add one with: python -m shipmate task add \"...\"")
        return

    if launch_all:
        to_launch = pending
    else:
        to_launch = pending[:count]

    if no_detach and len(to_launch) > 1:
        click.echo("Warning: --no-detach only works with a single task. Launching first task only.")
        to_launch = to_launch[:1]

    click.echo(f"\nLaunching {len(to_launch)} task(s)...\n")

    for t in to_launch:
        agent_id = _generate_agent_id(t["description"])
        branch = _generate_branch_name(t["description"], agent_id)
        detach = not no_detach

        click.echo(f"  [{t['priority']:>8}] {t['id']}")
        click.echo(f"           {t['description'][:70]}")
        click.echo(f"           agent={agent_id}  branch={branch[:50]}...")

        # Mark running in task queue
        mark_running(t["id"], agent_id, branch)

        # Launch container
        result = _launch_agent_container(
            task=t["description"],
            agent_id=agent_id,
            branch=branch,
            github_token=github_token,
            anthropic_key=anthropic_key,
            detach=detach,
        )

        if result:
            click.echo(f"           container={result}")
        elif detach:
            # Launch failed
            mark_failed(t["id"])
            click.echo(f"           FAILED to launch")

        click.echo("")

    if len(to_launch) > 1:
        click.echo(f"Follow logs: docker logs -f shipmate-<agent-id>")


# ── Dashboard ───────────────────────────────────────────────

@cli.command()
def dashboard():
    """Live-updating dashboard with task queue, agents, and results."""
    import signal
    from shipmate.task_manager import list_tasks, PRIORITY_ORDER
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.layout import Layout
    from rich.text import Text
    from rich import box

    # Color mapping from click colors to rich styles
    COLOR_MAP = {
        "cyan": "cyan",
        "green": "green",
        "red": "red",
        "yellow": "yellow",
        "white": "dim white",
    }
    PRI_STYLE = {
        "critical": ("!!!", "bold red"),
        "high": ("!!", "yellow"),
        "normal": (".", "dim white"),
        "low": ("-", "dim"),
    }

    # Force color output in mintty/Git Bash which Rich can't auto-detect
    force_color = os.environ.get("TERM_PROGRAM") == "mintty" or "MINGW" in os.environ.get("MSYSTEM", "")
    console = Console(force_terminal=True) if force_color else Console()

    def _get_session_status() -> tuple[str, str]:
        """Get session uptime from monitor container. Returns (text, style)."""
        try:
            client = _get_docker_client()
            monitor = client.containers.get("shipmate-monitor")
            started_str = monitor.attrs.get("State", {}).get("StartedAt", "")
            if monitor.status == "running" and started_str:
                # Docker returns ISO format like 2026-03-28T12:00:00.123456789Z
                started = datetime.fromisoformat(started_str.split(".")[0])
                elapsed = datetime.utcnow() - started
                total_secs = int(elapsed.total_seconds())
                hours, remainder = divmod(total_secs, 3600)
                minutes, seconds = divmod(remainder, 60)
                if hours:
                    time_str = f"{hours}h {minutes:02d}m {seconds:02d}s"
                else:
                    time_str = f"{minutes}m {seconds:02d}s"
                return (f"session {time_str}", "green")
            elif monitor.status == "exited":
                return ("session stopped", "red")
            else:
                return (f"session {monitor.status}", "yellow")
        except Exception:
            return ("session inactive", "dim")

    def build_display():
        _sync_task_states(verbose=False)

        tasks = list_tasks()
        client = _get_docker_client()
        containers = client.containers.list(all=True, filters={"name": "shipmate-"})
        gh_repo = _get_gh_repo()

        # ── Header ──
        header = Text()
        header.append("shipmate dashboard", style="bold cyan")
        header.append("  |  ", style="dim")
        session_text, session_style = _get_session_status()
        header.append(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), style="white")
        header.append("  |  ", style="dim")
        header.append(session_text, style=session_style)
        header.append("  |  ", style="dim")
        header.append(f"{PROJECT.github_repo}", style="dim cyan")
        header.append(f"  ({PROJECT.base_branch})", style="dim")

        # ── Running containers table ──
        running = [c for c in containers if c.status == "running"]
        run_table = Table(
            box=box.SIMPLE_HEAVY,
            show_header=True,
            header_style="bold",
            expand=True,
            padding=(0, 1),
        )
        run_table.add_column("Container", style="cyan", ratio=2)
        run_table.add_column("Branch", style="yellow", ratio=2)
        run_table.add_column("Task", ratio=4)

        if running:
            for c in running:
                task_desc = ""
                branch = ""
                try:
                    for e in c.attrs.get("Config", {}).get("Env", []):
                        if e.startswith("AGENT_TASK="):
                            task_desc = e.split("=", 1)[1][:60]
                        elif e.startswith("AGENT_BRANCH="):
                            branch = e.split("=", 1)[1]
                except Exception:
                    pass
                run_table.add_row(c.name, branch, task_desc)
        else:
            run_table.add_row("[dim](none)[/dim]", "", "")

        # ── Task queue table ──
        tasks.sort(key=lambda t: (
            PRIORITY_ORDER.get(t.get("priority", "normal"), 2),
            t.get("created_at", ""),
        ))

        task_table = Table(
            box=box.SIMPLE_HEAVY,
            show_header=True,
            header_style="bold",
            expand=True,
            padding=(0, 1),
        )
        task_table.add_column("Pri", justify="center", width=3)
        task_table.add_column("Task ID", ratio=2)
        task_table.add_column("Agent", justify="center", width=10)
        task_table.add_column("PR", justify="center", width=10)
        task_table.add_column("Started", justify="center", width=12)
        task_table.add_column("Completed", justify="center", width=12)
        task_table.add_column("Duration", justify="center", width=9)
        task_table.add_column("Description", ratio=3)

        if tasks:
            for t in tasks:
                pri_label, pri_style = PRI_STYLE.get(
                    t.get("priority", "normal"), (".", "dim white")
                )
                tid = t.get("id", "?")[:22]
                desc = t.get("description", "")[:40]
                agent_id = t.get("agent_id", "")
                branch = t.get("branch", "")

                started = _fmt_time(t.get("started_at"))
                completed = _fmt_time(t.get("finished_at"))
                duration = _fmt_duration(t.get("started_at"), t.get("finished_at"))

                if agent_id:
                    agent_str, agent_color = _get_live_agent_status(agent_id, client)
                else:
                    agent_str, agent_color = ("QUEUED", "white")

                if branch and agent_id:
                    pr_str, pr_color, pr_url = _get_live_pr_status(branch, gh_repo)
                else:
                    pr_str, pr_color, pr_url = ("--", "white", "")

                agent_styled = f"[{COLOR_MAP.get(agent_color, 'white')}]{agent_str}[/]"
                pr_styled = f"[{COLOR_MAP.get(pr_color, 'white')}]{pr_str}[/]"

                task_table.add_row(
                    f"[{pri_style}]{pri_label}[/]",
                    tid,
                    agent_styled,
                    pr_styled,
                    f"[dim]{started}[/]",
                    f"[dim]{completed}[/]",
                    f"[dim]{duration}[/]" if duration else "[dim]--[/]",
                    desc,
                )
        else:
            task_table.add_row("", "[dim](no tasks)[/dim]", "", "", "", "", "", "")

        # ── Recently exited ──
        exited = [c for c in containers if c.status == "exited"]
        exit_table = None
        if exited:
            exit_table = Table(
                box=box.SIMPLE_HEAVY,
                show_header=True,
                header_style="bold",
                expand=True,
                padding=(0, 1),
            )
            exit_table.add_column("Container", style="dim", ratio=3)
            exit_table.add_column("Result", justify="center", width=12)

            for c in exited[:5]:
                exit_code = c.attrs.get("State", {}).get("ExitCode", -1)
                if exit_code == 0:
                    result = "[green]OK[/green]"
                else:
                    result = f"[red]FAIL ({exit_code})[/red]"
                exit_table.add_row(c.name, result)

        # ── Compose output ──
        from rich.console import Group
        parts = [
            header,
            Text(""),
            Panel(run_table, title="[bold]Running Containers[/bold]", border_style="cyan"),
            Panel(task_table, title="[bold]Task Queue[/bold]", border_style="blue"),
        ]
        if exit_table:
            parts.append(
                Panel(exit_table, title="[bold]Recently Exited[/bold]", border_style="dim")
            )

        parts.append(Text("  Refreshing every 5s. Press Ctrl+C to exit.", style="dim"))

        return Group(*parts)

    from rich.live import Live
    try:
        with Live(
            build_display(),
            console=console,
            refresh_per_second=0.2,
            screen=False,
        ) as live:
            if hasattr(signal, "SIGWINCH"):
                signal.signal(signal.SIGWINCH, lambda *_: live.update(build_display()))
            while True:
                time.sleep(5)
                live.update(build_display())
    except KeyboardInterrupt:
        console.print("\n[dim]Dashboard stopped.[/dim]")


# ── Sync — reconcile task states with reality ───────────────

def _find_pr_url(gh_repo, branch: str) -> str:
    """Look up PR URL for a branch on GitHub."""
    if not gh_repo or not branch:
        return ""
    try:
        owner = gh_repo.owner.login
        # Check open PRs first
        for pr in gh_repo.get_pulls(state="open", head=f"{owner}:{branch}"):
            return pr.html_url
        # Then closed/merged
        for pr in gh_repo.get_pulls(state="all", head=f"{owner}:{branch}"):
            return pr.html_url
    except Exception:
        pass
    return ""


def _get_gh_repo():
    """Try to connect to GitHub and return the repo object."""
    try:
        from github import Github
        token = os.environ.get("GITHUB_TOKEN", "")
        if token and PROJECT.github_repo:
            return Github(token).get_repo(PROJECT.github_repo)
    except Exception:
        pass
    return None


def _sync_task_states(verbose: bool = False) -> None:
    """Check tasks against container state and GitHub PRs, update accordingly."""
    from shipmate.task_manager import list_tasks, update_task

    all_tasks = list_tasks()
    if not all_tasks:
        return

    client = _get_docker_client()
    gh_repo = _get_gh_repo()

    for t in all_tasks:
        agent_id = t.get("agent_id", "")
        branch = t.get("branch", "")
        status = t.get("status", "")

        # Backfill missing PR URLs for done tasks
        if status == "done" and not t.get("pr_url") and branch:
            pr_url = _find_pr_url(gh_repo, branch)
            if pr_url:
                update_task(t["id"], pr_url=pr_url)
                if verbose:
                    click.echo(f"  Backfilled PR: {t['id']} -> {pr_url}")
            continue

        # Only process running tasks for status changes
        if status != "running":
            continue

        container_name = f"shipmate-{agent_id}"

        # Check container status
        container = None
        try:
            container = client.containers.get(container_name)
        except docker.errors.NotFound:
            pass

        if container and container.status == "running":
            continue

        if container and container.status == "exited":
            exit_code = container.attrs.get("State", {}).get("ExitCode", -1)

            if exit_code == 0:
                pr_url = _find_pr_url(gh_repo, branch)
                update_task(t["id"], status="done", pr_url=pr_url, finished_at=datetime.now().isoformat())
                if verbose:
                    click.echo(f"  Synced: {t['id']} -> done" + (f" (PR: {pr_url})" if pr_url else ""))
            else:
                update_task(t["id"], status="failed", finished_at=datetime.now().isoformat())
                if verbose:
                    click.echo(f"  Synced: {t['id']} -> failed (exit code {exit_code})")

        elif not container:
            update_task(t["id"], status="failed", finished_at=datetime.now().isoformat())
            if verbose:
                click.echo(f"  Synced: {t['id']} -> failed (container not found)")


@cli.command()
def sync():
    """Sync task statuses with container state and GitHub PRs.

    Checks all 'running' tasks, looks up their containers, and updates
    status to 'done' (with PR URL) or 'failed' based on reality.
    """
    click.echo("Syncing task states...")
    _sync_task_states(verbose=True)
    click.echo("Done.")


# ── Direct agent launch (existing) ─────────────────────────

@cli.command("run-agent")
@click.option("--task", "-t", required=True, help="Task description for the agent.")
@click.option("--id", "agent_id", default=None, help="Agent ID (auto-generated if omitted).")
@click.option("--branch", "-b", default=None, help="Branch name (auto-generated if omitted).")
@click.option("--base-branch", default=None, help="Base branch.")
@click.option("--rebase", is_flag=True, help="Run in rebase/conflict-resolution mode.")
@click.option("--detach/--no-detach", default=True, help="Run in background (default: yes).")
def run_agent(task: str, agent_id: str | None, branch: str | None, base_branch: str | None, rebase: bool, detach: bool):
    """Launch a dev agent directly (bypasses task queue)."""
    github_token, anthropic_key = _validate_env()

    if not agent_id:
        agent_id = _generate_agent_id(task)
    if not branch:
        branch = _generate_branch_name(task, agent_id)

    click.echo(f"Launching agent '{agent_id}'")
    click.echo(f"  Task:   {task[:80]}")
    click.echo(f"  Branch: {branch}")
    click.echo(f"  Rebase: {rebase}")

    result = _launch_agent_container(
        task=task,
        agent_id=agent_id,
        branch=branch,
        github_token=github_token,
        anthropic_key=anthropic_key,
        base_branch=base_branch,
        rebase=rebase,
        detach=detach,
    )

    if result:
        click.echo(f"\nContainer started: {result}")
        click.echo(f"  Follow logs: docker logs -f shipmate-{agent_id}")
    elif detach:
        sys.exit(1)
    else:
        click.echo("\nAgent finished.")


# ── Build ───────────────────────────────────────────────────

@cli.command()
@click.option("--no-cache", is_flag=True, help="Build without Docker cache.")
def build(no_cache: bool):
    """Build the agent Docker image."""
    import subprocess

    shipmate_dir = os.path.dirname(os.path.abspath(__file__))
    image = f"{PROJECT.agent_image_name}:{PROJECT.agent_image_tag}"

    click.echo(f"Building agent image: {image}")
    cmd = ["docker", "build", "-t", image, shipmate_dir]
    if no_cache:
        cmd.insert(3, "--no-cache")

    result = subprocess.run(cmd)
    if result.returncode == 0:
        click.echo(f"\nImage built: {image}")
    else:
        click.echo("\nBuild failed.", err=True)
        sys.exit(1)


@cli.command("build-monitor")
@click.option("--no-cache", is_flag=True, help="Build without Docker cache.")
def build_monitor(no_cache: bool):
    """Build the PR monitor Docker image."""
    import subprocess

    monitor_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "monitor")
    image = f"{PROJECT.monitor_image_name}:{PROJECT.monitor_image_tag}"

    click.echo(f"Building monitor image: {image}")
    cmd = ["docker", "build", "-t", image, monitor_dir]
    if no_cache:
        cmd.insert(3, "--no-cache")

    result = subprocess.run(cmd)
    if result.returncode == 0:
        click.echo(f"\nImage built: {image}")
    else:
        click.echo("\nBuild failed.", err=True)
        sys.exit(1)


# ── Monitor ─────────────────────────────────────────────────

@cli.command("monitor-start")
@click.option("--interval", default=None, type=int, help="Poll interval in seconds.")
def monitor_start(interval: int | None):
    """Start the PR monitor container."""
    github_token, anthropic_key = _validate_env()

    client = _get_docker_client()
    container_name = "shipmate-monitor"
    image = f"{PROJECT.monitor_image_name}:{PROJECT.monitor_image_tag}"

    env = {
        "GITHUB_TOKEN": github_token,
        "ANTHROPIC_API_KEY": anthropic_key,
        "GITHUB_REPO": PROJECT.github_repo,
        "BASE_BRANCH": PROJECT.base_branch,
        "POLL_INTERVAL": str(interval or PROJECT.monitor_poll_interval_seconds),
        "DOCKER_NETWORK": PROJECT.docker_network,
        "AGENT_IMAGE": f"{PROJECT.agent_image_name}:{PROJECT.agent_image_tag}",
    }

    try:
        old = client.containers.get(container_name)
        click.echo("Stopping old monitor...")
        old.remove(force=True)
    except docker.errors.NotFound:
        pass

    try:
        container = client.containers.run(
            image=image,
            name=container_name,
            environment=env,
            volumes={"/var/run/docker.sock": {"bind": "/var/run/docker.sock", "mode": "rw"}},
            network=PROJECT.docker_network,
            detach=True,
            restart_policy={"Name": "unless-stopped"},
        )
        click.echo(f"Monitor started: {container.short_id}")
        click.echo(f"  Follow logs: docker logs -f {container_name}")
    except docker.errors.ImageNotFound:
        click.echo(f"\nImage '{image}' not found. Run: python -m shipmate build-monitor", err=True)
        sys.exit(1)
    except docker.errors.APIError as e:
        click.echo(f"\nDocker error: {e}", err=True)
        sys.exit(1)


@cli.command("monitor-stop")
def monitor_stop():
    """Stop the PR monitor container."""
    client = _get_docker_client()
    try:
        container = client.containers.get("shipmate-monitor")
        container.remove(force=True)
        click.echo("Monitor stopped.")
    except docker.errors.NotFound:
        click.echo("Monitor is not running.")


# ── Agent listing ───────────────────────────────────────────

@cli.command("list-agents")
@click.option("--all", "show_all", is_flag=True, help="Include exited containers.")
def list_agents(show_all: bool):
    """List agent containers."""
    client = _get_docker_client()
    containers = client.containers.list(all=show_all, filters={"name": "shipmate-"})
    if not containers:
        click.echo("No agent containers found." + (" Try --all to include exited." if not show_all else ""))
        return

    click.echo("")
    click.echo(f"  {'NAME':<30} {'STATUS':<15} {'ID':<12} TASK")
    click.echo(f"  {'----':<30} {'------':<15} {'--':<12} ----")
    for c in containers:
        task_desc = _get_container_env(c, "AGENT_TASK")[:40]
        click.echo(f"  {c.name:<30} {c.status:<15} {c.short_id:<12} {task_desc}")
    click.echo("")


# ── Container env helper ────────────────────────────────────

def _get_container_env(container, key: str) -> str:
    """Extract an environment variable value from a container's config."""
    try:
        for env in container.attrs.get("Config", {}).get("Env", []):
            if env.startswith(f"{key}="):
                return env.split("=", 1)[1]
    except Exception:
        pass
    return ""


def _find_container(identifier: str):
    """Find a container by agent ID, task ID, or container name."""
    client = _get_docker_client()
    container_name = identifier if identifier.startswith("shipmate-") else f"shipmate-{identifier}"

    # Try direct name match
    try:
        return client.containers.get(container_name)
    except docker.errors.NotFound:
        pass

    # Try matching by task ID in the task queue
    try:
        from shipmate.task_manager import get_task
        task = get_task(identifier)
        if task and task.get("agent_id"):
            agent_name = f"shipmate-{task['agent_id']}"
            try:
                return client.containers.get(agent_name)
            except docker.errors.NotFound:
                pass
    except Exception:
        pass

    # Try fuzzy match across all containers
    all_containers = client.containers.list(all=True, filters={"name": "shipmate-"})
    for c in all_containers:
        if identifier in c.name:
            return c
        if identifier in _get_container_env(c, "AGENT_TASK"):
            return c

    return None


# ── Logs shortcut ───────────────────────────────────────────

@cli.command()
@click.argument("identifier")
@click.option("--follow", "-f", is_flag=True, help="Follow log output.")
@click.option("--tail", "-n", default=50, help="Number of lines to show (default: 50).")
def logs(identifier: str, follow: bool, tail: int):
    """Show logs for an agent container.

    IDENTIFIER can be the agent ID, task ID, or container name.
    """
    import subprocess

    container = _find_container(identifier)
    if not container:
        click.echo(f"Container not found: {identifier}", err=True)
        click.echo("Use 'list-agents --all' to see all containers.")
        sys.exit(1)

    cmd = ["docker", "logs", f"--tail={tail}"]
    if follow:
        cmd.append("-f")
    cmd.append(container.name)

    click.echo(f"Showing logs for: {container.name} ({container.status})")
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        pass


# ── Review ──────────────────────────────────────────────────

@cli.command()
@click.argument("identifier")
@click.option("--logs-lines", "-n", default=30, help="Number of log lines to show (default: 30).")
def review(identifier: str, logs_lines: int):
    """Review an agent's work — show its task, branch, status, and recent logs.

    IDENTIFIER can be the agent ID, task ID, or container name.
    """
    container = _find_container(identifier)
    if not container:
        click.echo(f"Container not found: {identifier}", err=True)
        click.echo("Use 'list-agents --all' to see all containers.")
        sys.exit(1)

    # Extract metadata from container env
    task_desc = _get_container_env(container, "AGENT_TASK")
    agent_id = _get_container_env(container, "AGENT_ID")
    branch = _get_container_env(container, "AGENT_BRANCH")
    is_rebase = _get_container_env(container, "AGENT_REBASE")

    exit_code = container.attrs.get("State", {}).get("ExitCode", "?")
    started = container.attrs.get("State", {}).get("StartedAt", "?")[:19]
    finished = container.attrs.get("State", {}).get("FinishedAt", "?")[:19]

    click.echo("")
    click.echo("=" * 60)
    click.echo(f"  Agent Review: {container.name}")
    click.echo("=" * 60)
    click.echo(f"  Status:    {container.status}" + (f" (exit code: {exit_code})" if container.status == "exited" else ""))
    click.echo(f"  Agent ID:  {agent_id}")
    click.echo(f"  Task:      {task_desc}")
    click.echo(f"  Branch:    {branch}")
    click.echo(f"  Rebase:    {is_rebase}")
    click.echo(f"  Started:   {started}")
    if container.status == "exited":
        click.echo(f"  Finished:  {finished}")

    # Check if there's a matching task in the queue
    try:
        from shipmate.task_manager import list_tasks
        for t in list_tasks():
            if t.get("agent_id") == agent_id:
                click.echo(f"  Task ID:   {t['id']}")
                click.echo(f"  Priority:  {t.get('priority', '?')}")
                if t.get("pr_url"):
                    click.echo(f"  PR:        {t['pr_url']}")
                break
    except Exception:
        pass

    click.echo("")
    click.echo(f"  Recent Logs (last {logs_lines} lines):")
    click.echo("  " + "-" * 50)

    try:
        log_bytes = container.logs(tail=logs_lines)
        log_output = log_bytes.decode("utf-8", errors="replace")
        for line in log_output.splitlines():
            # Sanitize box-drawing chars that fail on Windows consoles
            safe_line = line.encode("ascii", errors="replace").decode("ascii")
            click.echo(f"  {safe_line}")
    except Exception as e:
        click.echo(f"  (could not read logs: {e})")

    click.echo("")
    click.echo("  Commands:")
    click.echo(f"    retry {agent_id}          - re-launch this agent")
    click.echo(f"    logs {agent_id} -f        - follow full logs")
    click.echo("")


# ── Retry ───────────────────────────────────────────────────

@cli.command()
@click.argument("identifier")
@click.option("--no-detach", is_flag=True, help="Run in foreground.")
def retry(identifier: str, no_detach: bool):
    """Re-launch an agent with its original task and branch.

    The agent picks up the same branch and can address PR feedback,
    fix issues, or continue where it left off.

    IDENTIFIER can be the agent ID, task ID, or container name.
    """
    container = _find_container(identifier)
    if not container:
        click.echo(f"Container not found: {identifier}", err=True)
        click.echo("Use 'list-agents --all' to see all containers.")
        sys.exit(1)

    if container.status == "running":
        click.echo(f"Agent {container.name} is still running. Stop it first or wait for it to finish.")
        sys.exit(1)

    # Extract original context
    task_desc = _get_container_env(container, "AGENT_TASK")
    agent_id = _get_container_env(container, "AGENT_ID")
    branch = _get_container_env(container, "AGENT_BRANCH")
    base_branch = _get_container_env(container, "BASE_BRANCH")

    if not task_desc or not agent_id or not branch:
        click.echo("Could not recover task context from container. Missing AGENT_TASK, AGENT_ID, or AGENT_BRANCH.", err=True)
        sys.exit(1)

    github_token, anthropic_key = _validate_env()

    click.echo(f"Retrying agent '{agent_id}'")
    click.echo(f"  Task:   {task_desc[:80]}")
    click.echo(f"  Branch: {branch}")
    click.echo(f"  (re-using existing branch — agent will pick up where it left off)")

    # Remove the old container so we can reuse the name
    try:
        container.remove(force=True)
        click.echo(f"  Removed old container: {container.name}")
    except Exception:
        pass

    # Update task status if tracked
    try:
        from shipmate.task_manager import list_tasks, mark_running
        for t in list_tasks():
            if t.get("agent_id") == agent_id:
                mark_running(t["id"], agent_id, branch)
                break
    except Exception:
        pass

    result = _launch_agent_container(
        task=task_desc,
        agent_id=agent_id,
        branch=branch,
        github_token=github_token,
        anthropic_key=anthropic_key,
        base_branch=base_branch or None,
        detach=not no_detach,
    )

    if result:
        click.echo(f"\nContainer restarted: {result}")
        click.echo(f"  Follow logs: docker logs -f shipmate-{agent_id}")
    elif not no_detach:
        sys.exit(1)
    else:
        click.echo("\nAgent finished.")


# ── Clean ───────────────────────────────────────────────────

@cli.command()
@click.option("--all", "clean_all", is_flag=True, help="Remove ALL exited agent containers.")
@click.option("--dry-run", is_flag=True, help="Show what would be removed without removing.")
def clean(clean_all: bool, dry_run: bool):
    """Remove exited agent containers.

    By default, only removes containers whose PRs are merged or closed.
    Use --all to remove all exited containers regardless of PR status.
    """
    client = _get_docker_client()
    containers = client.containers.list(all=True, filters={"name": "shipmate-", "status": "exited"})

    if not containers:
        click.echo("No exited agent containers to clean.")
        return

    # Optionally check PR status for selective cleanup
    gh = None
    repo = None
    if not clean_all:
        try:
            from github import Github
            token = os.environ.get("GITHUB_TOKEN", "")
            if token and PROJECT.github_repo:
                gh = Github(token)
                repo = gh.get_repo(PROJECT.github_repo)
        except Exception:
            click.echo("Warning: Could not connect to GitHub. Use --all to force cleanup.", err=True)
            return

    to_remove = []
    to_keep = []

    for c in containers:
        # Skip the monitor container
        if c.name == "shipmate-monitor":
            continue

        branch = _get_container_env(c, "AGENT_BRANCH")
        agent_id = _get_container_env(c, "AGENT_ID")
        task_desc = _get_container_env(c, "AGENT_TASK")[:50]

        if clean_all:
            to_remove.append((c, "exited", task_desc))
            continue

        # Check if the PR for this branch is merged or closed
        if repo and branch:
            try:
                pr_merged_or_closed = False
                for pr in repo.get_pulls(state="all", head=f"{repo.owner.login}:{branch}"):
                    if pr.merged or pr.state == "closed":
                        pr_merged_or_closed = True
                        break

                if pr_merged_or_closed:
                    to_remove.append((c, "PR merged/closed", task_desc))
                else:
                    to_keep.append((c, "PR still open", task_desc))
            except Exception:
                to_keep.append((c, "could not check PR", task_desc))
        else:
            # No branch info — check if it failed (no PR created)
            exit_code = c.attrs.get("State", {}).get("ExitCode", -1)
            if exit_code != 0:
                to_remove.append((c, "failed (no PR)", task_desc))
            else:
                to_keep.append((c, "unknown status", task_desc))

    if to_remove:
        click.echo(f"\n{'Would remove' if dry_run else 'Removing'} {len(to_remove)} container(s):\n")
        for c, reason, task_desc in to_remove:
            click.echo(f"  {c.name:<30} {reason:<20} {task_desc}")
            if not dry_run:
                try:
                    c.remove()
                except Exception as e:
                    click.echo(f"    Error: {e}")

        # Also clean up done/failed tasks in the queue
        if not dry_run:
            try:
                from shipmate.task_manager import list_tasks, remove_task
                done_tasks = [t for t in list_tasks() if t.get("status") in ("done", "failed")]
                for t in done_tasks:
                    agent_id = t.get("agent_id", "")
                    # Only remove task if its container was removed
                    if any(agent_id and agent_id in c.name for c, _, _ in to_remove):
                        remove_task(t["id"])
            except Exception:
                pass
    else:
        click.echo("\nNothing to clean.")

    if to_keep:
        click.echo(f"\n  Keeping {len(to_keep)} container(s) (PR still open or status unknown):")
        for c, reason, task_desc in to_keep:
            click.echo(f"  {c.name:<30} {reason:<20} {task_desc}")

    click.echo("")


if __name__ == "__main__":
    cli()
