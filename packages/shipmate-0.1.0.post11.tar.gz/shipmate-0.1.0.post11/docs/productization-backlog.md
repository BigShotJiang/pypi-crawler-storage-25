# shipmate — Productization Backlog

Considering extracting `shipmate/` into a standalone product. The system already handles parallel autonomous dev agents with Docker isolation, task queues, PR lifecycle, auto-rebase, and auto-cleanup.

---

| # | Feature | Status | Effort | Notes |
|---|---|---|---|---|
| C1 | ~~Decouple from CrewAI~~ | ✅ Done | Medium | Replaced with native agent loop + tool registry. LLM-agnostic via provider abstraction |
| C2 | Repo/language agnostic | 🔵 Backlog | Medium | Remove hardcoded references to grocery app structure, make validation/context configurable |
| C3 | ~~Multi-LLM backend support~~ | ✅ Done | Low | Supports Anthropic and OpenAI via provider abstraction. Configure in shipmate.yml |
| C4 | Auth & multi-tenant (SaaS) | 🔵 Backlog | High | User accounts, team workspaces, billing |
| C5 | Web dashboard | 🔵 Backlog | High | Replace CLI-only dashboard with a web UI |
| C6 | GitHub App integration | 🔵 Backlog | Medium | Install as a GitHub App instead of requiring a PAT |
| C7 | Packaging & distribution | 🔵 Backlog | Medium | pip install / Docker image / hosted SaaS — decide distribution model |

---

## Status Key
- ✅ Done
- 🟡 In Progress
- 🔵 Backlog
- ⛔ Blocked
