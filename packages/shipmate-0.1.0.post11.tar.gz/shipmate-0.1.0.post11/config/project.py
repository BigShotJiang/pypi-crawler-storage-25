"""
Project configuration — loaded from environment variables and shipmate.yml.

shipmate is project-agnostic. All project-specific values come from:
  1. Environment variables (SHIPMATE_* prefix) — for secrets and simple identifiers
  2. shipmate.yml at the project root — for structured config (validation, rules, etc.)

Nothing in this file is hardcoded to any specific project.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


def _find_project_root() -> Path:
    """Walk up from cwd to find the project root (contains shipmate.yml or .git)."""
    current = Path.cwd()
    for parent in [current, *current.parents]:
        if (parent / "shipmate.yml").exists():
            return parent
        if (parent / ".git").exists():
            return parent
    return current


def _load_yaml_config(project_root: Path) -> dict[str, Any]:
    """Load shipmate.yml from the project root. Returns empty dict if not found."""
    config_path = project_root / "shipmate.yml"
    if config_path.exists():
        with open(config_path, encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    return {}


def _env(key: str, default: str = "") -> str:
    """Read an SHIPMATE_ prefixed env var."""
    return os.environ.get(f"SHIPMATE_{key}", os.environ.get(key, default))


def _parse_tuple_pairs(items: list[dict[str, str]] | None) -> tuple[tuple[str, str], ...]:
    """Convert a list of {command, description} dicts to tuple of tuples."""
    if not items:
        return ()
    return tuple((item["command"], item["description"]) for item in items)


def _parse_string_list(items: list[str] | None) -> tuple[str, ...]:
    """Convert a list of strings to a tuple."""
    if not items:
        return ()
    return tuple(items)


@dataclass(frozen=True)
class ProjectConfig:
    # GitHub
    github_repo: str = ""
    base_branch: str = "main"

    # Docker networking — agents attach to this network to reach shared services
    docker_network: str = ""

    # Branch naming
    branch_prefix: str = "shipmate/dev"

    # PR conventions
    pr_title_prefix: str = "[AI]"
    pr_label: str = "shipmate-agent"

    # Context files the agent should read for project understanding
    context_files: tuple[str, ...] = ("README.md",)

    # Validation commands (run inside agent container)
    validation_commands: tuple[tuple[str, str], ...] = ()

    # Optional validation (may fail if env not fully set up)
    optional_validation_commands: tuple[tuple[str, str], ...] = ()

    # Shared service safety rules — embedded in agent instructions
    shared_service_rules: tuple[str, ...] = ()

    # Requirements file to install in agent container (relative to repo root)
    requirements_file: str = ""

    # Agent container image
    agent_image_name: str = "shipmate-agent"
    agent_image_tag: str = "latest"

    # Monitor
    monitor_poll_interval_seconds: int = 60
    monitor_image_name: str = "shipmate-monitor"
    monitor_image_tag: str = "latest"

    # LLM
    llm_provider: str = "anthropic"
    llm_model: str = "claude-sonnet-4-6"
    llm_max_tokens: int = 8192

    # Language/framework hints for the agent
    tech_stack: tuple[str, ...] = ()

    # Shell allowlist additions (project-specific commands the agent can run)
    allowed_shell_prefixes: tuple[str, ...] = ()

    # Shell blocklist additions (project-specific commands to block)
    blocked_shell_patterns: tuple[str, ...] = ()

    # Project root path (resolved at load time)
    project_root: str = ""


def load_config() -> ProjectConfig:
    """
    Load project config from env vars + shipmate.yml.

    Priority: env var > shipmate.yml > defaults
    """
    root = _find_project_root()
    yml = _load_yaml_config(root)

    github = yml.get("github", {})
    docker = yml.get("docker", {})
    agent = yml.get("agent", {})
    monitor_cfg = yml.get("monitor", {})
    llm = yml.get("llm", {})
    shell = yml.get("shell", {})

    return ProjectConfig(
        # GitHub — env takes precedence
        github_repo=_env("GITHUB_REPO", github.get("repo", "")),
        base_branch=_env("BASE_BRANCH", github.get("base_branch", "main")),

        # Docker
        docker_network=_env("DOCKER_NETWORK", docker.get("network", "")),

        # Branch/PR
        branch_prefix=_env("BRANCH_PREFIX", github.get("branch_prefix", "shipmate/dev")),
        pr_title_prefix=github.get("pr_title_prefix", "[AI]"),
        pr_label=github.get("pr_label", "shipmate-agent"),

        # Context files
        context_files=_parse_string_list(
            yml.get("context_files")
        ) or ("README.md",),

        # Validation
        validation_commands=_parse_tuple_pairs(
            yml.get("validation_commands")
        ),
        optional_validation_commands=_parse_tuple_pairs(
            yml.get("optional_validation_commands")
        ),

        # Safety rules
        shared_service_rules=_parse_string_list(
            yml.get("shared_service_rules")
        ),

        # Requirements
        requirements_file=yml.get("requirements_file", ""),

        # Agent image
        agent_image_name=_env("AGENT_IMAGE_NAME", agent.get("image_name", "shipmate-agent")),
        agent_image_tag=_env("AGENT_IMAGE_TAG", agent.get("image_tag", "latest")),

        # Monitor
        monitor_poll_interval_seconds=int(_env(
            "POLL_INTERVAL",
            str(monitor_cfg.get("poll_interval_seconds", 60)),
        )),
        monitor_image_name=monitor_cfg.get("image_name", "shipmate-monitor"),
        monitor_image_tag=monitor_cfg.get("image_tag", "latest"),

        # LLM
        llm_provider=_env("LLM_PROVIDER", llm.get("provider", "anthropic")),
        llm_model=_env("LLM_MODEL", llm.get("model", "claude-sonnet-4-6")),
        llm_max_tokens=int(_env(
            "LLM_MAX_TOKENS",
            str(llm.get("max_tokens", 8192)),
        )),

        # Tech stack
        tech_stack=_parse_string_list(yml.get("tech_stack")),

        # Shell customization
        allowed_shell_prefixes=_parse_string_list(shell.get("allowed_prefixes")),
        blocked_shell_patterns=_parse_string_list(shell.get("blocked_patterns")),

        # Project root
        project_root=str(root),
    )


# Singleton — import this from anywhere
PROJECT = load_config()
