"""
Agent loop — the think → tool → repeat cycle.

Drives a single agent to completion by calling the LLM, dispatching tool calls,
and feeding results back until the task is done or the iteration limit is reached.
"""

import logging
from typing import Any

from shipmate.engine.providers import AnthropicProvider, OpenAIProvider
from shipmate.engine.tool_registry import ToolRegistry

logger = logging.getLogger(__name__)


def run_agent(
    provider: AnthropicProvider | OpenAIProvider,
    system_prompt: str,
    task_prompt: str,
    registry: ToolRegistry,
    max_iterations: int = 50,
) -> str:
    """
    Run an agent loop to completion.

    Args:
        provider: LLM provider instance.
        system_prompt: System/backstory prompt for the agent.
        task_prompt: The user-facing task description.
        registry: Tool registry with all available tools.
        max_iterations: Maximum number of LLM calls before stopping.

    Returns:
        The agent's final text output.
    """
    messages: list[dict[str, Any]] = [
        {"role": "user", "content": task_prompt},
    ]
    tool_schemas = registry.schemas
    total_input_tokens = 0
    total_output_tokens = 0

    for iteration in range(1, max_iterations + 1):
        logger.info(f"--- Iteration {iteration}/{max_iterations} ---")

        response = provider.create_message(
            system=system_prompt,
            messages=messages,
            tools=tool_schemas,
        )

        total_input_tokens += response.usage.get("input_tokens", 0)
        total_output_tokens += response.usage.get("output_tokens", 0)

        if response.text:
            logger.info(f"Agent: {response.text[:200]}...")

        # No tool calls — agent is done
        if not response.tool_calls:
            logger.info(
                f"Agent finished after {iteration} iterations. "
                f"Tokens: {total_input_tokens} in / {total_output_tokens} out"
            )
            return response.text

        # Build the assistant message content (text + tool_use blocks)
        assistant_content: list[dict[str, Any]] = []
        if response.text:
            assistant_content.append({"type": "text", "text": response.text})
        for tc in response.tool_calls:
            assistant_content.append({
                "type": "tool_use",
                "id": tc.id,
                "name": tc.name,
                "input": tc.input,
            })

        messages.append({"role": "assistant", "content": assistant_content})

        # Dispatch each tool call and collect results
        tool_results: list[dict[str, Any]] = []
        for tc in response.tool_calls:
            logger.info(f"Tool call: {tc.name}({_summarize_input(tc.input)})")
            result = registry.dispatch(tc.name, tc.input)
            logger.info(f"Tool result: {result[:200]}..." if len(result) > 200 else f"Tool result: {result}")
            tool_results.append({
                "type": "tool_result",
                "tool_use_id": tc.id,
                "content": result,
            })

        messages.append({"role": "user", "content": tool_results})

    logger.warning(f"Agent hit iteration limit ({max_iterations})")
    logger.info(f"Tokens: {total_input_tokens} in / {total_output_tokens} out")
    return f"Agent stopped after {max_iterations} iterations without completing the task."


def _summarize_input(input_dict: dict) -> str:
    """Create a short summary of tool input for logging."""
    parts = []
    for k, v in input_dict.items():
        val_str = str(v)
        if len(val_str) > 60:
            val_str = val_str[:60] + "..."
        parts.append(f"{k}={val_str}")
    return ", ".join(parts)
