"""
LLM provider abstraction — wraps Anthropic (and future providers) behind a
common interface for the agent loop.
"""

import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ToolCall:
    """A single tool call extracted from an LLM response."""
    id: str
    name: str
    input: dict


@dataclass
class LLMResponse:
    """Normalized response from any LLM provider."""
    text: str
    tool_calls: list[ToolCall]
    stop_reason: str
    usage: dict[str, int]


class AnthropicProvider:
    """Anthropic Claude provider using the messages API."""

    def __init__(self, model: str, max_tokens: int):
        import anthropic
        self.client = anthropic.Anthropic()
        self.model = model
        self.max_tokens = max_tokens

    def create_message(
        self,
        system: str,
        messages: list[dict],
        tools: list[dict],
    ) -> LLMResponse:
        response = self.client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            system=system,
            messages=messages,
            tools=tools,
        )

        text_parts = []
        tool_calls = []

        for block in response.content:
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                tool_calls.append(ToolCall(
                    id=block.id,
                    name=block.name,
                    input=block.input,
                ))

        return LLMResponse(
            text="\n".join(text_parts),
            tool_calls=tool_calls,
            stop_reason=response.stop_reason,
            usage={
                "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens,
            },
        )


class OpenAIProvider:
    """OpenAI-compatible provider (OpenAI, Azure, local)."""

    def __init__(self, model: str, max_tokens: int, base_url: str | None = None):
        import openai
        kwargs: dict[str, Any] = {}
        if base_url:
            kwargs["base_url"] = base_url
        self.client = openai.OpenAI(**kwargs)
        self.model = model
        self.max_tokens = max_tokens

    def _convert_tools(self, tools: list[dict]) -> list[dict]:
        """Convert Anthropic tool format to OpenAI function-calling format."""
        return [
            {
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "parameters": t["input_schema"],
                },
            }
            for t in tools
        ]

    def _convert_messages(self, system: str, messages: list[dict]) -> list[dict]:
        """Convert Anthropic message format to OpenAI format."""
        converted = [{"role": "system", "content": system}]

        for msg in messages:
            if msg["role"] == "assistant":
                # Handle assistant messages that may contain tool calls
                if isinstance(msg["content"], list):
                    text_parts = []
                    tool_calls = []
                    for block in msg["content"]:
                        if isinstance(block, dict):
                            if block.get("type") == "text":
                                text_parts.append(block["text"])
                            elif block.get("type") == "tool_use":
                                import json
                                tool_calls.append({
                                    "id": block["id"],
                                    "type": "function",
                                    "function": {
                                        "name": block["name"],
                                        "arguments": json.dumps(block["input"]),
                                    },
                                })
                    oai_msg: dict[str, Any] = {"role": "assistant"}
                    if text_parts:
                        oai_msg["content"] = "\n".join(text_parts)
                    if tool_calls:
                        oai_msg["tool_calls"] = tool_calls
                    converted.append(oai_msg)
                else:
                    converted.append(msg)
            elif msg["role"] == "user":
                # Handle tool results
                if isinstance(msg["content"], list):
                    for block in msg["content"]:
                        if isinstance(block, dict) and block.get("type") == "tool_result":
                            converted.append({
                                "role": "tool",
                                "tool_call_id": block["tool_use_id"],
                                "content": block["content"],
                            })
                else:
                    converted.append(msg)

        return converted

    def create_message(
        self,
        system: str,
        messages: list[dict],
        tools: list[dict],
    ) -> LLMResponse:
        import json

        oai_messages = self._convert_messages(system, messages)
        oai_tools = self._convert_tools(tools)

        response = self.client.chat.completions.create(
            model=self.model,
            max_tokens=self.max_tokens,
            messages=oai_messages,
            tools=oai_tools if oai_tools else None,
        )

        choice = response.choices[0]
        text = choice.message.content or ""
        tool_calls = []

        if choice.message.tool_calls:
            for tc in choice.message.tool_calls:
                tool_calls.append(ToolCall(
                    id=tc.id,
                    name=tc.function.name,
                    input=json.loads(tc.function.arguments),
                ))

        stop_reason = "end_turn" if choice.finish_reason == "stop" else choice.finish_reason

        return LLMResponse(
            text=text,
            tool_calls=tool_calls,
            stop_reason=stop_reason,
            usage={
                "input_tokens": response.usage.prompt_tokens if response.usage else 0,
                "output_tokens": response.usage.completion_tokens if response.usage else 0,
            },
        )


def create_provider(
    provider: str,
    model: str,
    max_tokens: int,
    base_url: str | None = None,
) -> AnthropicProvider | OpenAIProvider:
    """Factory to create an LLM provider by name."""
    if provider == "anthropic":
        return AnthropicProvider(model=model, max_tokens=max_tokens)
    elif provider in ("openai", "azure", "local"):
        return OpenAIProvider(model=model, max_tokens=max_tokens, base_url=base_url)
    else:
        raise ValueError(f"Unknown LLM provider: '{provider}'. Supported: anthropic, openai")
