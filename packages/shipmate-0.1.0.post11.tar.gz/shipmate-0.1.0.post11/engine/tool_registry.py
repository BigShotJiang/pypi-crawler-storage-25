"""
Tool registry — converts plain Python functions into Anthropic API tool schemas
and dispatches tool calls by name.
"""

import inspect
import logging
from typing import Any, Callable, get_type_hints

logger = logging.getLogger(__name__)

# Type mapping from Python types to JSON Schema types
_TYPE_MAP = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
}


def _parse_docstring_args(docstring: str) -> dict[str, str]:
    """Extract parameter descriptions from a Google-style Args: block."""
    descriptions: dict[str, str] = {}
    if not docstring:
        return descriptions

    in_args = False
    for line in docstring.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith("args:"):
            in_args = True
            continue
        if in_args:
            if not stripped or (not line.startswith(" ") and not line.startswith("\t")):
                break
            if ":" in stripped:
                param_part, _, desc = stripped.partition(":")
                param_name = param_part.strip()
                descriptions[param_name] = desc.strip()
    return descriptions


def _get_tool_description(func: Callable) -> str:
    """Extract the first line/paragraph of a docstring as the tool description."""
    doc = inspect.getdoc(func) or ""
    # Take everything before the Args: block
    lines = []
    for line in doc.splitlines():
        if line.strip().lower().startswith("args:"):
            break
        lines.append(line)
    return "\n".join(lines).strip()


def _build_schema(func: Callable) -> dict:
    """Build an Anthropic tool schema from a function's signature and docstring."""
    sig = inspect.signature(func)
    hints = get_type_hints(func)
    arg_docs = _parse_docstring_args(inspect.getdoc(func) or "")

    properties = {}
    required = []

    for name, param in sig.parameters.items():
        python_type = hints.get(name, str)
        json_type = _TYPE_MAP.get(python_type, "string")

        prop: dict[str, Any] = {"type": json_type}
        if name in arg_docs:
            prop["description"] = arg_docs[name]

        if param.default is inspect.Parameter.empty:
            required.append(name)
        else:
            prop["default"] = param.default

        properties[name] = prop

    return {
        "name": func.__name__,
        "description": _get_tool_description(func),
        "input_schema": {
            "type": "object",
            "properties": properties,
            "required": required,
        },
    }


class ToolRegistry:
    """Registry of tool functions with schema generation and dispatch."""

    def __init__(self):
        self._tools: dict[str, Callable] = {}
        self._schemas: list[dict] = []

    def register(self, func: Callable) -> Callable:
        """Register a tool function. Can be used as a decorator."""
        schema = _build_schema(func)
        self._tools[func.__name__] = func
        self._schemas.append(schema)
        return func

    def register_all(self, *funcs: Callable) -> None:
        """Register multiple tool functions at once."""
        for func in funcs:
            self.register(func)

    @property
    def schemas(self) -> list[dict]:
        """Return Anthropic API tool schemas for all registered tools."""
        return list(self._schemas)

    def dispatch(self, tool_name: str, tool_input: dict) -> str:
        """Call a registered tool by name with the given input dict."""
        func = self._tools.get(tool_name)
        if not func:
            return f"Error: unknown tool '{tool_name}'"

        try:
            result = func(**tool_input)
            return str(result)
        except Exception as e:
            logger.error(f"Tool '{tool_name}' failed: {e}", exc_info=True)
            return f"Error in {tool_name}: {e}"

    @property
    def tool_names(self) -> list[str]:
        return list(self._tools.keys())
