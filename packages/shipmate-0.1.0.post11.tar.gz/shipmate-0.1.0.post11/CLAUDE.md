# Shipmate — Claude Code Guide

This file is read automatically by Claude Code at session start. It contains everything needed to understand, contribute to, and extend this project.

## What This Project Is

Shipmate is a **standalone, project-agnostic framework** for running autonomous AI dev agents as Docker containers. It is installed via `pip install shipmate` and configured per-project with `shipmate.yml`.

Each agent:
- Clones the consuming project's repo into its own isolated container
- Creates a unique `shipmate/*` branch
- Reads project context files (CLAUDE.md, README, etc.) to understand the codebase
- Implements a task using an LLM (Anthropic Claude, OpenAI, etc.)
- Validates its changes (linting, formatting)
- Commits, pushes, and opens a PR with machine-readable metadata
- Exits

A persistent PR monitor watches for stale AI branches and re-spawns agents to rebase after master advances.

## How It's Used

Install shipmate and configure it per-project:

```bash
pip install shipmate
```

```
some-project/
├── shipmate.yml           # project-specific config
├── .env                   # secrets
├── shipmate_tasks.yml     # task queue state (created by the CLI)
└── ...project files
```

The consuming project provides:
- `shipmate.yml` — repo name, Docker network, validation commands, safety rules, tech stack
- `.env` — `GITHUB_TOKEN`, `ANTHROPIC_API_KEY`, and optional `SHIPMATE_*` overrides
- `shipmate_tasks.yml` — auto-managed task queue (created by the CLI)

Shipmate itself has **zero hardcoded project values**. All project-specific config comes from `shipmate.yml` and environment variables.

## Repository Layout

```
shipmate/
├── __init__.py
├── __main__.py                  # python -m shipmate entry point
├── main.py                      # Host-side CLI (click) — all commands
├── task_manager.py              # Task queue CRUD (shipmate_tasks.yml backend)
├── entrypoint.py                # Container lifecycle: clone -> branch -> crew -> push -> PR
├── Dockerfile                   # Agent container image (Python 3.12 + git + ruff + system deps)
├── requirements.txt             # Python deps: anthropic, gitpython, PyGithub, click, docker, rich
├── Makefile                     # Cross-platform make targets (Windows + macOS)
├── launch.sh                    # Launcher script (bash — macOS/Linux/WSL/Git Bash)
├── launch.bat                   # Launcher script (Windows cmd)
├── setup_venv.sh / .bat         # Venv setup scripts
├── .dockerignore
├── .gitignore
├── docker-compose.monitor.yml   # Compose file for the PR monitor
│
├── config/
│   └── project.py               # Loads config from env vars + shipmate.yml (never edit)
│
├── context/
│   └── project_context.py       # Reads repo context files -> string for agent backstory
│
├── agents/
│   └── dev_agent.py             # Agent definition (system prompt, tool registry)
│
├── tasks/
│   └── dev_task.py              # Task prompt builder (normal + rebase modes, PR metadata)
│
├── engine/
│   ├── __init__.py
│   ├── agent_loop.py            # Think → tool → repeat loop
│   ├── providers.py             # LLM provider abstraction (Anthropic, OpenAI)
│   └── tool_registry.py         # Tool schema generation + dispatch
│
├── crews/
│   └── dev_crew.py              # Dev crew assembly: provider + agent + task
│
├── tools/
│   ├── git_tools.py             # 12 git tools (branch, commit, rebase, push, diff, etc.)
│   ├── github_tools.py          # 6 GitHub tools (create/update PR, comment, list AI PRs, metadata)
│   ├── file_tools.py            # 5 file tools (read, write, list, search, patch — workspace-sandboxed)
│   └── shell_tools.py           # 3 shell tools (constrained allowlist, ruff check, ruff format)
│
├── monitor/
│   ├── Dockerfile               # Monitor container image
│   └── pr_monitor.py            # Polling service: watches master, detects stale PRs, re-spawns agents
│
└── docs/
    └── README.md                # Full documentation
```

## Architecture

### One Task = One Container

Each task gets its own Docker container with a fresh repo clone. Full filesystem isolation — no agent can interfere with another. Agents connect to the consuming project's Docker network for shared services (db, redis, etc.) but must treat them as read-only.

### Config Flow

```
Environment variable  >  shipmate.yml  >  built-in default
```

`config/project.py` reads from `SHIPMATE_*` env vars and `shipmate.yml` at the project root. It has no hardcoded values.

### Agent Lifecycle (entrypoint.py)

```
Clone repo -> Configure git identity -> Create/checkout branch
-> Install project requirements -> Build context from CLAUDE.md etc.
-> Run dev agent (think → tool → repeat) -> (agent edits code, validates, commits, pushes, opens PR)
-> Exit
```

### PR Metadata

Every AI-created PR contains a hidden metadata block:

```html
<!-- SHIPMATE_META
{"task": "...", "agent_id": "...", "branch": "...", "created_at": "...", "rebase_count": 0}
SHIPMATE_META -->
```

The monitor uses this to reconstruct and re-spawn the same task on a stale branch.

### Task Queue

`shipmate_tasks.yml` (at the consuming project root) tracks tasks with:
- `id`, `description`, `priority` (critical/high/normal/low)
- `status` (pending/running/done/failed/cancelled)
- `agent_id`, `branch`, `pr_url`
- `created_at`, `started_at`, `finished_at`

The CLI's `task list` command does **live lookups** — it checks Docker container state and GitHub PR status in real-time, not cached values.

### Shell Sandboxing

Agents cannot run arbitrary shell commands. `tools/shell_tools.py` has:
- **Built-in allowlist**: `ruff`, `pytest`, `pip`, `cat`, `head`, `tail`, `wc`, `diff`, `find`, `ls`
- **Built-in blocklist**: `rm -rf`, `DROP`, `DELETE FROM`, `TRUNCATE`, `FLUSHALL`, `FLUSHDB`
- **Project additions**: merged from `shell.allowed_prefixes` and `shell.blocked_patterns` in `shipmate.yml`

### File Sandboxing

All file tools in `tools/file_tools.py` are sandboxed to `/workspace`. Path traversal attempts are rejected.

## Key Design Decisions

### Project-Agnostic

Shipmate has zero hardcoded project references. Every project-specific value comes from `shipmate.yml` or `SHIPMATE_*` env vars. To use in a new project: `pip install shipmate`, create `shipmate.yml`, add secrets to `.env`.

### pip Distribution

Shipmate is distributed as a pip package (`pip install shipmate`). The CLI is available as both `shipmate` and `python -m shipmate` after installation. The Dockerfile and Makefile are bundled as package data.

### Shared Services Policy

Agents attach to the project's Docker network but must treat shared services as read-only:
- No running migrations against shared databases
- No flushing Redis
- No deleting MinIO objects
- Tests must use isolated per-agent test DB names

Rules are enforced at two levels: shell blocklist (hard block) and agent instructions (LLM guidance).

## CLI Commands (via Makefile)

Run from the `shipmate/` directory:

### Task Management
| Command | Description |
|---|---|
| `make task-add T="desc" P=high` | Add a task (priority: critical/high/normal/low) |
| `make task-list` | List tasks with live agent + PR status |
| `make task-list-all` | Include done/failed tasks |
| `make task-remove ID=x` | Remove a task |
| `make task-update ID=x P=critical` | Update priority/status |

### Work Execution
| Command | Description |
|---|---|
| `make work` | Launch next pending task by priority |
| `make work-all` | Launch all pending tasks in parallel |
| `make work-n N=3` | Launch top N tasks |
| `make work-live` | Launch next task in foreground |

### Agent Lifecycle
| Command | Description |
|---|---|
| `make review ID=x` | Review agent's task, branch, status, logs |
| `make retry ID=x` | Re-launch agent with same task + branch |
| `make logs ID=x` | Show last 50 log lines |
| `make logs-follow ID=x` | Follow logs live |
| `make agent T="desc"` | Launch agent directly (skip queue) |

### Monitoring
| Command | Description |
|---|---|
| `make dashboard` | Live-updating dashboard |
| `make status` | Show running containers |
| `make list-agents` | All containers including exited |
| `make sync` | Sync task states with container/PR reality |

### Lifecycle
| Command | Description |
|---|---|
| `make start` | Start work session (launch tasks + monitor) |
| `make stop` | Stop session (monitor + cleanup) |
| `make clean` | Remove containers for merged/closed PRs |
| `make clean-all` | Remove ALL exited containers |

### Infrastructure
| Command | Description |
|---|---|
| `make setup` | First-time setup (venv + Docker image) |
| `make build` | Build agent Docker image |
| `make build-monitor` | Build PR monitor image |
| `make monitor` | Start PR monitor |
| `make monitor-stop` | Stop PR monitor |

## Development Notes

### Adding a New Tool

1. Add function to the appropriate `tools/*.py` module with `@tool("name")` decorator
2. Add import + tool reference to `agents/dev_agent.py`'s tool list
3. If it's a shell command, add the prefix to `_BUILTIN_ALLOWED_PREFIXES` in `shell_tools.py`

### Adding a New Agent Type

1. Create `agents/new_agent.py` with a `create_*_agent()` function
2. Create `tasks/new_task.py` with a `create_*_task()` function
3. Create `crews/new_crew.py` with a `run_*_crew()` function
4. Add CLI command in `main.py`

### Configuration Priority

```
SHIPMATE_* env var  >  shipmate.yml value  >  built-in default
```

### Secrets

- `GITHUB_TOKEN` — clone, push, PR operations (needs `repo` + `pull_request` scopes)
- `ANTHROPIC_API_KEY` — LLM calls inside agent containers (API billing, separate from Claude subscription)
- Both passed as container env vars, never baked into images

### Testing Changes

After modifying framework code, publish to PyPI, then in each consuming project:
```bash
pip install --upgrade shipmate
shipmate build   # rebuild agent image with new code
```

### Current Status

- V1 is functional — successfully cloned, branched, coded, validated, committed, pushed, and opened a PR autonomously
- Agent uses `claude-sonnet-4-6` via Anthropic API (requires API credits, not covered by Claude subscription)
- Ruff is baked into the Docker image for validation
- PR monitor and task queue are implemented but need more production testing
- Dashboard uses `rich` for terminal UI with live refresh

### Known Issues / Future Work

- Agent container Dockerfile has system deps for Python/Django projects — needs to be more generic or configurable per project
- Monitor `cleanup_merged_containers` needs more testing
- No frontend/mobile agent specialization yet (v1 is backend-focused)
- No multi-agent collaboration within a single task
- No auto-merge capability
- Rate limiting on Anthropic API can slow agents significantly on low-tier plans
