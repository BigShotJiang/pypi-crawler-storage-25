"""
Task manager — CRUD operations for the task queue (ai_tasks.yml).

Tasks are stored in a YAML file at the project root. Each task has:
  - id: unique slug
  - description: what to do
  - priority: critical, high, normal, low
  - status: pending, running, done, failed, cancelled
  - agent_id: assigned agent (set when launched)
  - branch: git branch (set when launched)
  - pr_url: PR URL (set when agent finishes)
  - created_at: ISO timestamp
  - started_at: ISO timestamp (set when launched)
  - finished_at: ISO timestamp (set when done/failed)
"""

import hashlib
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

PRIORITY_ORDER = {"critical": 0, "high": 1, "normal": 2, "low": 3}
VALID_PRIORITIES = tuple(PRIORITY_ORDER.keys())
VALID_STATUSES = ("pending", "running", "done", "failed", "cancelled")


def _tasks_file(project_root: str | Path | None = None) -> Path:
    """Resolve the ai_tasks.yml path."""
    if project_root:
        return Path(project_root) / "ai_tasks.yml"
    # Try to find it via config
    try:
        from shipmate.config.project import PROJECT
        return Path(PROJECT.project_root) / "ai_tasks.yml"
    except Exception:
        return Path.cwd() / "ai_tasks.yml"


def _load(path: Path) -> list[dict[str, Any]]:
    """Load tasks from YAML file."""
    if not path.exists():
        return []
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if not data or "tasks" not in data:
        return []
    return data["tasks"]


def _save(path: Path, tasks: list[dict[str, Any]]) -> None:
    """Save tasks to YAML file."""
    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(
            {"tasks": tasks},
            f,
            default_flow_style=False,
            sort_keys=False,
            allow_unicode=True,
        )


def _generate_id(description: str) -> str:
    """Generate a short ID from description."""
    slug = re.sub(r"[^a-z0-9]+", "-", description.lower()).strip("-")
    if len(slug) > 30:
        slug = slug[:30].rsplit("-", 1)[0]
    short_hash = hashlib.md5(description.encode()).hexdigest()[:4]
    return f"{slug}-{short_hash}"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def list_tasks(
    project_root: str | Path | None = None,
    status: str | None = None,
    priority: str | None = None,
) -> list[dict[str, Any]]:
    """List tasks, optionally filtered by status and/or priority."""
    path = _tasks_file(project_root)
    tasks = _load(path)

    if status:
        tasks = [t for t in tasks if t.get("status") == status]
    if priority:
        tasks = [t for t in tasks if t.get("priority") == priority]

    return tasks


def get_task(task_id: str, project_root: str | Path | None = None) -> dict[str, Any] | None:
    """Get a single task by ID."""
    path = _tasks_file(project_root)
    for t in _load(path):
        if t["id"] == task_id:
            return t
    return None


def add_task(
    description: str,
    priority: str = "normal",
    task_id: str | None = None,
    project_root: str | Path | None = None,
) -> dict[str, Any]:
    """Add a new task to the queue."""
    if priority not in VALID_PRIORITIES:
        raise ValueError(f"Invalid priority '{priority}'. Must be one of: {VALID_PRIORITIES}")

    path = _tasks_file(project_root)
    tasks = _load(path)

    # Generate or validate ID
    tid = task_id or _generate_id(description)

    # Check for duplicate
    if any(t["id"] == tid for t in tasks):
        raise ValueError(f"Task ID '{tid}' already exists")

    task = {
        "id": tid,
        "description": description,
        "priority": priority,
        "status": "pending",
        "agent_id": None,
        "branch": None,
        "pr_url": None,
        "created_at": _now(),
        "started_at": None,
        "finished_at": None,
    }

    tasks.append(task)
    _save(path, tasks)
    return task


def update_task(
    task_id: str,
    project_root: str | Path | None = None,
    **updates: Any,
) -> dict[str, Any]:
    """Update a task's fields."""
    path = _tasks_file(project_root)
    tasks = _load(path)

    for t in tasks:
        if t["id"] == task_id:
            if "priority" in updates and updates["priority"] not in VALID_PRIORITIES:
                raise ValueError(f"Invalid priority. Must be one of: {VALID_PRIORITIES}")
            if "status" in updates and updates["status"] not in VALID_STATUSES:
                raise ValueError(f"Invalid status. Must be one of: {VALID_STATUSES}")
            t.update(updates)
            _save(path, tasks)
            return t

    raise ValueError(f"Task '{task_id}' not found")


def remove_task(task_id: str, project_root: str | Path | None = None) -> bool:
    """Remove a task from the queue."""
    path = _tasks_file(project_root)
    tasks = _load(path)
    original_len = len(tasks)
    tasks = [t for t in tasks if t["id"] != task_id]

    if len(tasks) == original_len:
        return False

    _save(path, tasks)
    return True


def mark_running(
    task_id: str,
    agent_id: str,
    branch: str,
    project_root: str | Path | None = None,
) -> dict[str, Any]:
    """Mark a task as running with agent info."""
    return update_task(
        task_id,
        project_root,
        status="running",
        agent_id=agent_id,
        branch=branch,
        started_at=_now(),
    )


def mark_done(
    task_id: str,
    pr_url: str = "",
    project_root: str | Path | None = None,
) -> dict[str, Any]:
    """Mark a task as done."""
    return update_task(
        task_id,
        project_root,
        status="done",
        pr_url=pr_url,
        finished_at=_now(),
    )


def mark_failed(
    task_id: str,
    project_root: str | Path | None = None,
) -> dict[str, Any]:
    """Mark a task as failed."""
    return update_task(
        task_id,
        project_root,
        status="failed",
        finished_at=_now(),
    )


def next_task(project_root: str | Path | None = None) -> dict[str, Any] | None:
    """Get the next pending task by priority (critical > high > normal > low), then FIFO."""
    pending = list_tasks(project_root, status="pending")
    if not pending:
        return None

    pending.sort(key=lambda t: (
        PRIORITY_ORDER.get(t.get("priority", "normal"), 2),
        t.get("created_at", ""),
    ))
    return pending[0]


def pending_tasks_by_priority(project_root: str | Path | None = None) -> list[dict[str, Any]]:
    """Get all pending tasks sorted by priority then FIFO."""
    pending = list_tasks(project_root, status="pending")
    pending.sort(key=lambda t: (
        PRIORITY_ORDER.get(t.get("priority", "normal"), 2),
        t.get("created_at", ""),
    ))
    return pending
