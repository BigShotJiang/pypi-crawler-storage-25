#!/usr/bin/env bash
# Set up shipmate's isolated Python virtual environment.
# Run this once from the shipmate/ directory.
#
# Usage:
#   cd shipmate
#   bash setup_venv.sh
#
# After setup, activate with:
#   source .venv/bin/activate        # Linux/macOS/WSL
#   .venv\Scripts\activate           # Windows (cmd)
#   .venv/Scripts/activate           # Windows (git bash)

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Resolve python command — macOS may only have python3
if command -v python3 &> /dev/null; then
    PYTHON=python3
elif command -v python &> /dev/null; then
    PYTHON=python
else
    echo "ERROR: Python not found. Install Python 3.12+ and try again."
    exit 1
fi

echo "Creating shipmate virtual environment..."
$PYTHON -m venv .venv

# Activate
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    source .venv/Scripts/activate
else
    source .venv/bin/activate
fi

echo "Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo ""
echo "Done. Activate with:"
echo "  source shipmate/.venv/bin/activate    # bash"
echo "  shipmate\\.venv\\Scripts\\activate       # Windows cmd"
