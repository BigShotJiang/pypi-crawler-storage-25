"""Allow running as: python -m shipmate"""

from shipmate.main import cli

if __name__ == "__main__":
    cli()
