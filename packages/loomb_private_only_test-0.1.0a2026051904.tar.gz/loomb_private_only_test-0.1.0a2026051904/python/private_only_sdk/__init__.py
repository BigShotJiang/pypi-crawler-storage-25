from ._native import add, hello_from_rust

__version__ = "0.1.0a2026051904"


def get_sdk_version() -> str:
    return __version__


__all__ = ["__version__", "add", "get_sdk_version", "hello_from_rust"]
