"""CLI for running Asta agent servers.

Usage:
    asta run [--port PORT] [--storage URL]

Discovers tasks via the 'asta.tasks' entry point group.
"""

from __future__ import annotations

import argparse
import importlib
import os
import sys
from importlib.metadata import entry_points

from asta_agent.sdk import Asta


def discover_tasks(asta: Asta) -> None:
    """Load all tasks registered via the 'asta.tasks' entry point group."""
    eps = entry_points()
    asta_eps = eps.select(group="asta.tasks") if hasattr(eps, "select") else eps.get("asta.tasks", [])
    for ep in asta_eps:
        print(f"Loading task: {ep.name} -> {ep.value}")
        fn = ep.load()
        # If not already registered (e.g. decorated at import time with @asta.task),
        # register it now
        if not any(t.fn is fn for t in asta._registry._task_defs.values()):
            asta.task(ep.name)(fn)


def main():
    parser = argparse.ArgumentParser(prog="asta", description="Asta agent server")
    sub = parser.add_subparsers(dest="command")

    run_parser = sub.add_parser("run", help="Start the agent server")
    run_parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", 9000)))
    run_parser.add_argument("--storage", type=str, default=os.environ.get("DATABASE_URL"))
    run_parser.add_argument("--name", type=str, default="Asta Agent")
    run_parser.add_argument("--description", type=str, default="")

    args = parser.parse_args()

    if args.command != "run":
        parser.print_help()
        sys.exit(1)

    asta = Asta(args.name, description=args.description, version="0.1.0")
    discover_tasks(asta)
    asta.run(port=args.port, storage=args.storage)


if __name__ == "__main__":
    main()
