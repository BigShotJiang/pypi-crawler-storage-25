"""Task registration and agent card generation."""

from __future__ import annotations

import inspect
import json
from dataclasses import dataclass, field
from typing import Any, Callable

from a2a.types import AgentCard, AgentCapabilities, AgentSkill

from asta_agent.context import AstaContext

_MISSING = object()

# Python type -> JSON Schema type
_TYPE_MAP: dict[type | str | None, str] = {
    str: "string", "str": "string",
    int: "integer", "int": "integer",
    float: "number", "float": "number",
    bool: "boolean", "bool": "boolean",
}

_CONTEXT_TYPES: set[type | str] = {AstaContext, "AstaContext"}


@dataclass
class _Param:
    name: str
    required: bool
    default: Any = _MISSING
    annotation: Any = None


@dataclass
class TaskDef:
    """A registered task definition."""
    name: str
    fn: Callable
    params: list[_Param] = field(default_factory=list)
    context_param: str | None = None

    @property
    def skill_id(self) -> str:
        return self.name.lower().replace(" ", "-")

    def input_schema(self) -> dict:
        """JSON Schema for the task's input parameters."""
        properties: dict[str, Any] = {}
        required: list[str] = []
        for p in self.params:
            prop: dict[str, Any] = {"type": _TYPE_MAP.get(p.annotation, "string")}
            if not p.required and p.default is not _MISSING:
                prop["default"] = p.default
            properties[p.name] = prop
            if p.required:
                required.append(p.name)
        schema: dict[str, Any] = {"type": "object", "properties": properties}
        if required:
            schema["required"] = required
        return schema


def extract_params(fn: Callable) -> tuple[list[_Param], str | None]:
    """Extract parameter info from a function signature.

    Returns (params, context_param_name). AstaContext params are excluded
    from params so they never appear in the public JSON schema.
    """
    sig = inspect.signature(fn)
    params: list[_Param] = []
    context_param: str | None = None
    for name, p in sig.parameters.items():
        if name in ("self", "cls"):
            continue
        annotation = p.annotation if p.annotation is not inspect.Parameter.empty else None
        if annotation in _CONTEXT_TYPES:
            context_param = name
            continue
        required = p.default is inspect.Parameter.empty
        default = _MISSING if required else p.default
        params.append(_Param(name=name, required=required, default=default, annotation=annotation))
    return params, context_param


def build_agent_card(
    name: str,
    description: str,
    version: str,
    url: str,
    tasks: list[TaskDef],
) -> AgentCard:
    """Generate an A2A AgentCard from registered tasks.

    The input JSON schema is serialized as a string in the skill's
    examples array, so clients can discover the expected input format.
    """
    skills = []
    for td in tasks:
        schema = td.input_schema()
        desc = td.fn.__doc__ or ""
        desc = desc.strip()
        skills.append(AgentSkill(
            id=td.skill_id,
            name=td.name,
            description=desc,
            tags=[],
            examples=[json.dumps(schema)],
        ))
    return AgentCard(
        name=name,
        description=description,
        version=version,
        url=url,
        capabilities=AgentCapabilities(streaming=True),
        default_input_modes=["application/json"],
        default_output_modes=["application/json"],
        skills=skills,
    )
