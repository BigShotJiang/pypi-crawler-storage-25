import numpy as np

def check_peaks(fid: np.ndarray):
    first_der = np.gradient(np.abs(fid))
    idx = []
    for i, val in enumerate(first_der[:-1]):
        if val < 0 and first_der[i+1] >= 0:
            idx.append(i+1)
    return idx

def cut_fidelity(fid: np.ndarray, idx: list, offset: int=0):
    if len(idx) > 1:
        cut = (idx[-1] + idx[-2]) // 2 + offset
    else:
        cut = 0 + offset
    return fid[cut:], cut

def fidelity_susceptibility(fid: np.ndarray):
    return np.gradient(np.gradient(np.abs(fid)))

def discrete_fidelity_susceptibility(fid: np.ndarray, a: int=1):
    dfs = (2 / (a**2))*(1 - np.abs(fid))
    return dfs

def cut_fidelity_susceptibility(fid: np.ndarray, offset: int=0, a: float=1, discr: bool=False):
    idx = check_peaks(fid)
    cut_fid, cut = cut_fidelity(fid, idx, offset)
    if discr:
        return discrete_fidelity_susceptibility(cut_fid, a), cut
    else:
        return fidelity_susceptibility(cut_fid), cut