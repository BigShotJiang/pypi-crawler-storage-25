import scipy.sparse as sp
import numpy as np

# Single-site identity
Id = sp.identity(3, format="csr")

omega = np.exp(2j*np.pi/3)
V = sp.csr_matrix([[1,0,0],[0,omega,0],[0,0,omega**2]])
U = sp.csr_matrix([[0,1,0],[0,0,1],[1,0,0]])

def kron_sparse_op(Op, i, n):
    if (i > 0) and (i < n-1):
        left = Id
        right = Id
        for k in range(i-1):
            left = sp.kron(left, Id)
        for k in range(i+1,n-1):
            right = sp.kron(Id, right)
        return sp.kron(sp.kron(left,Op),right)
    elif i == 0:
        right = Id
        for k in range(1,n-1):
            right = sp.kron(Id, right)
        return sp.kron(Op,right)
    elif i == n-1:
        left = Id
        for k in range(0,i-1):
            left = sp.kron(left, Id)        
        return sp.kron(left, Op)
    

class Lattice():
    def __init__(self, shape:None, L:None):
        self.shape = shape
        self.L = L
        self.vertices = []
        self.charges = []

    def _get_dof(self):
        if self.shape == "hex":
            return self._get_dof_hex()
        elif self.shape == "tri":
            return self._get_dof_tri()
        else:
            raise TypeError("Choose a valid shape for the triangular lattice")
        
    def _get_dof_hex(self):
        """
        _get_dof_hex

        This function returns the number of dof in a hexagonal shaped triangular lattice of side self.L.
        You can use this function to get the dimension of the whole Hilbert space.
        
        """
        all_vertices = self._get_coordinates_vertices_hex() # list of all the vertices
        bound_miss_link = (2*self.L + 2*self.L + 2*self.L + 3) # boundary links missing wrt the bulk case
        return len(all_vertices)*3 - bound_miss_link

    def _get_dof_tri(self):
        pass

    def _get_coordinates_vertices_hex(self):
        """
        _get_vertices_hex

        This function returns a list of labels for all the vertices in a hexagonal shaped
        triangular lattice of side self.L

        """
        lower_half = [(i,0,k) for k in range(self.L+1) for i in range(self.L+k+1)]
        upper_half = [(i,j,self.L) for j in range(1,self.L+1) for i in range(2*self.L-j+1)]
        return lower_half + upper_half
    
    def _labeling_strategy_hex(self):
        """
        _labeling_strategy_hex

        This function returns a list of labels for the vertices in a hexagonal shaped
        triangular lattice of side self.L. The labels are separated according to different
        contributions in the hamiltonian. In particular, we separate them in descending dimension
        of the local vertex hilbert space (3,2,1).

        """
        link_plaq_ab_1 = [(i,0,k) for k in range(self.L) for i in range(self.L+k)] # all links and plaq a and b
        link_plaq_a = [(self.L+k,0,k) for k in range(self.L)] # links 2,3 and plaq a (low right)
        link_plaq_b = [(0,j,self.L) for j in range(self.L)] # links 1,2 and plaq b (up left)
        link_plaq_ab_2 = [(i,j,self.L) for j in range(self.L) for i in range(1,2*self.L-j)] # all links and plaq a and b
        link_1 = [(i,self.L,self.L) for i in range(self.L)] # links 1 (ceiling)
        link_3 = [(2*self.L-j,j,self.L) for j in range(self.L)] # links 3 (up right)
        return [link_plaq_ab_1 + link_plaq_ab_2, link_plaq_a + link_plaq_b, link_1 + link_3]
    
    def _row_counter(self, r):
        if r <= self.L:
            return self.L+1 + r
        elif r > self.L:
            return 3*self.L + 1 - r
        
    def linearize_vertex(self, i,j,k):
        return sum([i] + [self._row_counter(r) for r in range(j+k)])
    
    def _get_vertices_dicts(self):
        self._get_vertices_dicts_coords()
        self._get_vertices_dicts_space()
        self._get_vertices_dicts_plaq_type()
        return self
    
    def _get_charges_dict(self):
        self._get_charges_dicts_coords()
        self._get_charges_vacuum()
        return self
    
    def _get_charges_dicts_coords(self):
        vertices_ham = self._labeling_strategy_hex()
        for idx, vertices in enumerate(vertices_ham):
            for v in vertices:
                self.charges.append(dict(vertex=v, linearized=self.linearize_vertex(*v), dim=3-idx))

        trivial_vertex = (self.L,self.L,self.L) 
        self.charges.append(dict(vertex=trivial_vertex, linearized=self.linearize_vertex(*trivial_vertex), dim=0))
        
        self.charges = sorted(self.charges, key=lambda x: x["linearized"])
        
        return self

    def _get_charges_vacuum(self):
        """
        _get_vertices_dicts_space

        This function add to the coordinate dicts also the dimension of every vertex hilbert space
        and the starting hilbert space for the first link in vertex relative to the total one.
        
        """
        for vertex in self.charges:
            vertex["charge"] = 1
        
        return self
    
    def _get_vertices_dicts_coords(self):
        vertices_ham = self._labeling_strategy_hex()
        for idx, vertices in enumerate(vertices_ham):
            for v in vertices:
                self.vertices.append(dict(vertex=v, linearized=self.linearize_vertex(*v), dim=3-idx))

        trivial_vertex = (self.L,self.L,self.L) 
        self.vertices.append(dict(vertex=trivial_vertex, linearized=self.linearize_vertex(*trivial_vertex), dim=0))
        
        self.vertices = sorted(self.vertices, key=lambda x: x["linearized"])
        
        return self
    
    
    def _get_vertices_dicts_space(self):
        """
        _get_vertices_dicts_space

        This function add to the coordinate dicts also the dimension of every vertex hilbert space
        and the starting hilbert space for the first link in vertex relative to the total one.
        
        """
        dims = [d["dim"] for d in self.vertices]

        hilb_start_dim = [0]
        for x in dims:
            hilb_start_dim.append(hilb_start_dim[-1] + x)

        for hs, vertex in zip(hilb_start_dim, self.vertices):
            vertex["hilbert_start"] = hs
        
        return self
    
    def _get_vertices_dicts_plaq_type(self):
        """
        _get_vertices_dicts_plaq_type

        This function adds to the vertices dictionary the type of plaquette A or B.
        This is useful to understand how to assign the local hilbert space of the links.

        """
        flag = 0
        for vertex in self.vertices:
            if vertex["dim"] == 2 and flag < self.L: 
                vertex["plaq_type"] = "A"
                flag += 1
            elif vertex["dim"] == 2 and flag >= self.L:
                vertex["plaq_type"] = "B"

            if vertex["dim"] == 3: 
                vertex["plaq_type"] = "AB"
            
            if vertex["dim"] == 1 or vertex["dim"] == 0: 
                vertex["plaq_type"] = None
        
        return self

    def links_1(self):
        link_1 = [(i,self.L,self.L) for i in range(self.L)] # links 1 (ceiling)
        link_plaq_b = [(0,j,self.L) for j in range(self.L)] # links 1,2 and plaq b (up left)
        link_plaq_ab_1 = [(i,0,k) for k in range(self.L) for i in range(self.L+k)] # all links and plaq a and b
        link_plaq_ab_2 = [(i,j,self.L) for j in range(self.L) for i in range(1,2*self.L-j)] # all links and plaq a and b
        return link_1 + link_plaq_b + link_plaq_ab_1 + link_plaq_ab_2
    
    def links_1_sites(self):
        all_links_1 = self.links_1()
        return [self.linearize_vertex(*v) for v in all_links_1]
    
    def links_2(self):
        link_plaq_a = [(self.L+k,0,k) for k in range(self.L)] # links 2,3 and plaq a (low right)
        link_plaq_b = [(0,j,self.L) for j in range(self.L)] # links 1,2 and plaq b (up left)
        link_plaq_ab_1 = [(i,0,k) for k in range(self.L) for i in range(self.L+k)] # all links and plaq a and b
        link_plaq_ab_2 = [(i,j,self.L) for j in range(self.L) for i in range(1,2*self.L-j)] # all links and plaq a and b
        return link_plaq_a + link_plaq_b + link_plaq_ab_1 + link_plaq_ab_2
    
    def links_2_sites(self):
        all_links_2 = self.links_2()
        return [self.linearize_vertex(*v) for v in all_links_2]

    def links_3(self):
        link_3 = [(2*self.L-j,j,self.L) for j in range(self.L)] # links 3 (up right)
        link_plaq_a = [(self.L+k,0,k) for k in range(self.L)] # links 2,3 and plaq a (low right)
        link_plaq_ab_1 = [(i,0,k) for k in range(self.L) for i in range(self.L+k)] # all links and plaq a and b
        link_plaq_ab_2 = [(i,j,self.L) for j in range(self.L) for i in range(1,2*self.L-j)] # all links and plaq a and b
        return link_3 + link_plaq_a + link_plaq_ab_1 + link_plaq_ab_2
    
    def links_3_sites(self):
        all_links_3 = self.links_3()
        return [self.linearize_vertex(*v) for v in all_links_3]
    
    
    def links_1_sites_hs(self):
        sites = []
        for link1 in self.links_1_sites():
            for v in self.vertices:
                if link1==v['linearized']:
                    if v['dim'] == 1:
                        site = v['hilbert_start']
                    elif v['dim'] == 2:
                        site = v['hilbert_start']
                    elif v['dim'] == 3:
                        site = v['hilbert_start']
            sites.append(site)
        return sites

    def links_2_sites_hs(self):
        sites = []
        for link2 in self.links_2_sites():
            for v in self.vertices:
                if link2==v['linearized']:
                    if v['dim'] == 2:
                        if v['plaq_type'] == "A":
                            site = v['hilbert_start']
                        elif v['plaq_type'] == "B":
                            site = v['hilbert_start'] + 1

                    elif v['dim'] == 3:
                        site = v['hilbert_start'] + 1
            sites.append(site)
        return sites

    def links_3_sites_hs(self):
        sites = []
        for link3 in self.links_3_sites():
            for v in self.vertices:
                if link3==v['linearized']:
                    if v['dim'] == 1:
                        site = v['hilbert_start']
                    
                    elif v['dim'] == 2:
                        if v['plaq_type'] == "A":
                            site = v['hilbert_start'] + 1

                    elif v['dim'] == 3:
                        site = v['hilbert_start'] + 2
            sites.append(site)
        return sites


    def plaquette_A(self):
        """
        plaquette_A

        This function gives the coordinates of the vertices that have plaquettes of type A 
        
        """
        link_plaq_a = [(self.L+k,0,k) for k in range(self.L)] # links 2,3 and plaq a (low right)
        link_plaq_ab_1 = [(i,0,k) for k in range(self.L) for i in range(self.L+k)] # all links and plaq a and b
        link_plaq_ab_2 = [(i,j,self.L) for j in range(self.L) for i in range(1,2*self.L-j)] # all links and plaq a and b
        return link_plaq_a + link_plaq_ab_1 + link_plaq_ab_2
    
    def plaquette_A_hs(self):
        """
        plaquette_A_hs

        This function finds the three links hilbert space sites in order to make a A plaquette term.
        
        """
        sites_a = []
        vertex_by_lin = {v['linearized']: v for v in self.vertices}
        for plaq_a in self.plaquette_A():

            plaq_a_lin = self.linearize_vertex(*plaq_a)
            v = vertex_by_lin[plaq_a_lin]

            if (plaq_a[1] + plaq_a[2]) < self.L:

                other_site = (plaq_a[0], plaq_a[1], plaq_a[2] + 1)
                other_site_lin = self.linearize_vertex(*other_site)

            elif (plaq_a[1] + plaq_a[2]) >= self.L:

                other_site = (plaq_a[0]-1, plaq_a[1]+1, plaq_a[2])
                other_site_lin = self.linearize_vertex(*other_site)

            v_prime = vertex_by_lin[other_site_lin]
            if v['plaq_type'] == 'A':
                sites = (v['hilbert_start'], v_prime['hilbert_start'], v['hilbert_start'] + 1)
            elif v['plaq_type'] == 'AB':
                sites = (v['hilbert_start']+1, v_prime['hilbert_start'], v['hilbert_start'] + 2)

            sites_a.append(sites)
        return sites_a

    def plaquette_B(self):
        link_plaq_b = [(0,j,self.L) for j in range(self.L)] # links 1,2 and plaq b (up left)
        link_plaq_ab_1 = [(i,0,k) for k in range(self.L) for i in range(self.L+k)] # all links and plaq a and b
        link_plaq_ab_2 = [(i,j,self.L) for j in range(self.L) for i in range(1,2*self.L-j)] # all links and plaq a and b
        return link_plaq_b + link_plaq_ab_1 + link_plaq_ab_2
    
    def plaquette_B_hs(self):
        """
        plaquette_B_hs

        This function finds the three links hilbert space sites in order to make a B plaquette term.
        
        """
        sites_b = []
        vertex_by_lin = {v['linearized']: v for v in self.vertices}
        for plaq_b in self.plaquette_B():

            plaq_b_lin = self.linearize_vertex(*plaq_b)
            v = vertex_by_lin[plaq_b_lin]

            other_site = (plaq_b[0]+1, plaq_b[1], plaq_b[2])
            other_site_lin = self.linearize_vertex(*other_site)

            v_prime = vertex_by_lin[other_site_lin]
            
            if v_prime['plaq_type'] == None:
                sites = (v['hilbert_start'], v_prime['hilbert_start'], v['hilbert_start'] + 1)
            elif v_prime['plaq_type'] == 'A':
                sites = (v['hilbert_start'], v_prime['hilbert_start']+1, v['hilbert_start'] + 1)
            elif v_prime['plaq_type'] == 'AB':
                sites = (v['hilbert_start'], v_prime['hilbert_start']+2, v['hilbert_start'] + 1)

            sites_b.append(sites)
        return sites_b

    def get_charges(self, coords: list=None, values: list=None, config: str=None):
        if config is None:
            print(coords)
        elif config == "2-max":
            values = [omega, omega] # is it possible?
            values = [omega**2, omega] 
            values = [omega, omega**2]
        elif config == "3-max":
            values = [omega, omega, omega] # is it possible?
            values = [omega**2, omega, omega] 
            values = [omega, omega**2, omega]
            values = [omega, omega, omega**2]
            values = [omega**2, omega**2, omega**2]
        for coord, value in zip(coords, values):
            for v in self.charges:
                if coord == v['vertex']:
                    v['charge'] = value

        return self

class Hamiltonian():
    def __init__(self, shape, L, g:None, lamb:None):
        self.lattice = Lattice(shape=shape, L=L)
        self.lattice._get_vertices_dicts()
        self.lattice._get_charges_dict()
        self.g = g
        self.lamb = lamb

    def ham(self):
        n = self.lattice._get_dof()
        omega = np.exp(2j*np.pi/3)
        V = sp.csr_matrix([[1,0,0],[0,omega,0],[0,0,omega**2]])
        U = sp.csr_matrix([[0,1,0],[0,0,1],[1,0,0]])
        H_links = sp.csr_matrix((3**n, 3**n))

        for site in self.lattice.links_1_sites_hs():
            H_links += kron_sparse_op(V,site,n)

        for site in self.lattice.links_2_sites_hs():
            H_links += kron_sparse_op(V,site,n)
            
        for site in self.lattice.links_3_sites_hs():
            H_links += kron_sparse_op(V,site,n)
        

        H_plaqs = sp.csr_matrix((3**n, 3**n))

        for plaq_a in self.lattice.plaquette_A_hs():
            H_plaqs += kron_sparse_op(U,plaq_a[0],n) @ (kron_sparse_op(U,plaq_a[1],n).conjugate().T) @ (kron_sparse_op(U,plaq_a[2],n).conjugate().T)

        for plaq_b in self.lattice.plaquette_B_hs():
            H_plaqs += kron_sparse_op(U,plaq_b[0],n) @ kron_sparse_op(U,plaq_b[1],n) @ (kron_sparse_op(U,plaq_b[2],n).conjugate().T)

        H = - self.g * H_links - self.lamb * H_plaqs
        H_tot = (1/2) * (H + H.conjugate().T)
        return H_tot