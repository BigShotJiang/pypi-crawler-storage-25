from qs_mps.applications.Z3.classes import *
import scipy.sparse as sp
import numpy as np

H = Hamiltonian(shape='hex', L=1, g=1, lamb=0)
Ham_Z3 = H.ham()

# add manually the gauss law
n = H.lattice._get_dof()
omega = np.exp(2j*np.pi/3)
V = sp.csr_matrix([[1,0,0],[0,omega,0],[0,0,omega**2]])
U = sp.csr_matrix([[0,1,0],[0,0,1],[1,0,0]])
H_gauss = sp.csr_matrix((3**n, 3**n))

H_gauss += sp.identity(3**n) - kron_sparse_op(V,0,n) @ kron_sparse_op(V,1,n) @ kron_sparse_op(V,2,n)
H_gauss += sp.identity(3**n) - kron_sparse_op(V,3,n) @ kron_sparse_op(V,4,n) @ kron_sparse_op(V,0,n).conjugate().T
H_gauss += sp.identity(3**n) - kron_sparse_op(V,5,n) @ kron_sparse_op(V,6,n) @ kron_sparse_op(V,2,n).conjugate().T
H_gauss += sp.identity(3**n) - kron_sparse_op(V,7,n) @ kron_sparse_op(V,8,n) @ kron_sparse_op(V,9,n) @ kron_sparse_op(V,5,n).conjugate().T @ kron_sparse_op(V,1,n).conjugate().T @ kron_sparse_op(V,4,n).conjugate().T
H_gauss += sp.identity(3**n) - kron_sparse_op(V,5,n) @ kron_sparse_op(V,7,n).conjugate().T @ kron_sparse_op(V,3,n).conjugate().T
H_gauss += sp.identity(3**n) - kron_sparse_op(V,11,n) @ kron_sparse_op(V,6,n).conjugate().T @ kron_sparse_op(V,9,n).conjugate().T
H_gauss += sp.identity(3**n) - kron_sparse_op(V,11,n).conjugate().T @ kron_sparse_op(V,8,n).conjugate().T @ kron_sparse_op(V,10,n).conjugate().T

eps = 100
Ham_Z3_G = Ham_Z3 + eps * (H_gauss + H_gauss.conjugate().T)

n_plaq = len(H.lattice.plaquette_A()) + len(H.lattice.plaquette_B())
deg_E1 = 2 * n_plaq
which = "SA"

e_tot = []
for k in [5*deg_E1, 6*deg_E1, 7*deg_E1, 8*deg_E1]:
    e_k = []
    for tol in [1e-1,1e-2,1e-3,1e-4]:
        print(f"digonalize for k={k} and tol={tol}")
        e, vec = sp.linalg.eigsh(Ham_Z3_G, which=which, k=k, tol=tol)
        e_k.append(e)
    e_tot.append(e_k)