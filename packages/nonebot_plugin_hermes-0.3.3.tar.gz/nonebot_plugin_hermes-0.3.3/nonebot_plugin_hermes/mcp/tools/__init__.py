"""nonebot-bridge MCP tools。"""
