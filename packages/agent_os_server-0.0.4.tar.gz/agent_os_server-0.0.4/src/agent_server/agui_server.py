import sys
import logging
# logging.basicConfig(
#     level=logging.INFO,
#     format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
# )
import uvicorn
from dotenv import dotenv_values
from fastapi import FastAPI
from ag_ui_adk import add_adk_fastapi_endpoint
from .utils import Utils

config = dotenv_values(".server.env")
server_config = Utils.Server.ServerConfig(
    agents_path=config.get("AGENTS_PATH", ""),
    session_service_uri=config.get("SESSION_SERVICE_URI", ""),
    memory_service_uri=config.get("MEMORY_SERVICE_URI", ""),
    user_service_uri=config.get("USER_SERVICE_URI", ""),
    trace_service_uri=config.get("TRACE_SERVICE_URI", ""),
    host=config.get("HOST", "0.0.0.0"),
    port=int(config.get("PORT", "8000"))
)


class Application:
    global server_config
    api = FastAPI(title=f"{Utils.Agent.agent_name} AGUI Server")
    api.add_middleware(Utils.Server.UserWhitelistMiddleware)
    agent_agui_runner = Utils.Agent.create_adk_agent_agui_runner(
        agents_path=server_config.agents_path,
        session_service_uri=server_config.session_service_uri,
        memory_service_uri=server_config.memory_service_uri
    )
    if agent_agui_runner is None:
        raise Exception("Agent load failed")

    add_adk_fastapi_endpoint(api, agent_agui_runner, path="/agui/api/v1/chat/completions")

    @staticmethod
    @api.get("/agui/api/v1/reload")
    async def reload():
        Application.agent_agui_runner = Utils.Agent.create_adk_agent_agui_runner(
            agents_path=server_config.agents_path,
            session_service_uri=server_config.session_service_uri,
            memory_service_uri=server_config.memory_service_uri
        )
        if Application.agent_agui_runner is None:
            logging.error("Failed to load agents")
            return {"code": 10000, "message": "Failed to load agents", "data": ""}

        return {"code": 0, "message": "", "data": "OK"}

    @staticmethod
    @api.get("/agui/api/v1/health")
    async def health_check():
        return {"code": 0, "message": "", "data": "OK"}


def main():
    global server_config
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s",
        stream=sys.stderr
    )
    uvicorn.run(Application.api, host=server_config.host, port=server_config.port)


if __name__ == '__main__':
    main()