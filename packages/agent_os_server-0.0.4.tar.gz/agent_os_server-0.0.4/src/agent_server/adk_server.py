import asyncio
import contextlib
import logging
import sys
import uvicorn

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    stream=sys.stderr
)

from collections.abc import AsyncIterable
from dotenv import dotenv_values

from fastapi import FastAPI, HTTPException, Request
from fastapi.sse import EventSourceResponse, ServerSentEvent
from pydantic import BaseModel

from google.adk.runners import Runner
from google.adk.sessions import DatabaseSessionService
from google.adk.artifacts import InMemoryArtifactService
from google.genai import types
from google.adk.apps import App
from .utils import Utils

# from agents.proxy_agent.agent import root_agent

#### ===========
# logging.basicConfig(
#     level=logging.INFO,
#     format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
# )
# logger = logging.getLogger("agent_os")
#
#
# app_name = "agent_os_app"
# session_service = DatabaseSessionService(
#     db_url="sqlite+aiosqlite:///./.resources/sqlite.db/sessions.db"
# )
#
# Runner(app=App(name=, root_agent=root_agent,plugins=))
# runner = Runner(
#     app_name=app_name,
#     agent=root_agent,
#     session_service=session_service,
#     artifact_service=InMemoryArtifactService(),
#     auto_create_session=False,
# )

#### ===========

config = dotenv_values(".server.env")
server_config = Utils.Server.ServerConfig(
    agents_path=config.get("AGENTS_PATH", ""),
    session_service_uri=config.get("SESSION_SERVICE_URI", ""),
    memory_service_uri=config.get("MEMORY_SERVICE_URI", ""),
    user_service_uri=config.get("USER_SERVICE_URI", ""),
    trace_service_uri=config.get("TRACE_SERVICE_URI", ""),
    host=config.get("HOST", "0.0.0.0"),
    port=int(config.get("PORT", "8000"))
)

class CreateSessionRequest(BaseModel):
    user_id: str


class ChatRequest(BaseModel):
    user_id: str
    session_id: str
    message: str


class Application:
    global server_config
    api = FastAPI(title=f"{Utils.Agent.agent_name} ADK Server")
    agent_app_name = f"{Utils.Agent.agent_name} ADK APP"
    api.add_middleware(Utils.Server.UserWhitelistMiddleware)
    agent_adk_runner = Utils.Agent.create_adk_agent_adk_runner(
        agents_path=server_config.agents_path,
        session_service_uri=server_config.session_service_uri,
        memory_service_uri=server_config.memory_service_uri
    )
    session_service = agent_adk_runner.session_service
    if agent_adk_runner is None:
        raise Exception("Agent load failed")

    @staticmethod
    def safe_jsonable(value):
        if value is None:
            return None

        if hasattr(value, "model_dump"):
            try:
                return value.model_dump(mode="json")
            except Exception:
                pass

        if hasattr(value, "dict"):
            try:
                return value.dict()
            except Exception:
                pass

        if isinstance(value, (str, int, float, bool, list, dict)):
            return value

        return str(value)

    @staticmethod
    async def ensure_session(user_id: str, session_id: str | None = None):
        if session_id:
            session = await Application.session_service.get_session(
                app_name=Application.agent_app_name,
                user_id=user_id,
                session_id=session_id,
            )
            if session:
                return session

            return await Application.session_service.create_session(
                app_name=Application.agent_app_name,
                user_id=user_id,
                session_id=session_id,
                state={},
            )

        return await Application.session_service.create_session(
            app_name=Application.agent_app_name,
            user_id=user_id,
            state={},
        )


    @api.post("/session/create", tags=["ADK API"])
    async def create_session(request: CreateSessionRequest):
        try:
            session = await Application.ensure_session(user_id=request.user_id)
            return {"user_id": request.user_id, "session_id": session.id}
        except Exception as e:
            logging.exception("create_session failed")
            raise HTTPException(status_code=500, detail=str(e))


    @api.post("/chat/stream", response_class=EventSourceResponse, tags=["ADK API"])
    async def chat_stream(request: ChatRequest, http_request: Request) -> AsyncIterable[ServerSentEvent]:
        """
        关键点：
        1. 这里不要 return EventSourceResponse(...)
        2. 路由函数本身直接 yield，符合 FastAPI 官方 SSE 用法
        3. 没有消息时也定期发 comment，防止连接静默
        """
        await Application.ensure_session(user_id=request.user_id, session_id=request.session_id)

        queue: asyncio.Queue[ServerSentEvent | None] = asyncio.Queue()

        async def producer():
            try:
                content = types.Content(
                    role="user",
                    parts=[types.Part(text=request.message)]
                )

                logging.info(
                    "stream start user_id=%s session_id=%s",
                    request.user_id,
                    request.session_id,
                )

                async for event in Application.agent_adk_runner.run_async(
                    user_id=request.user_id,
                    session_id=request.session_id,
                    new_message=content,
                ):
                    if event.content and event.content.parts:
                        for part in event.content.parts:
                            if getattr(part, "text", None):
                                await queue.put(
                                    ServerSentEvent(
                                        data={
                                            "type": "thinking" if getattr(part, "thought", False) else "text",
                                            "content": part.text,
                                        },
                                        event="message",
                                    )
                                )

                            if getattr(part, "function_call", None) is not None:
                                await queue.put(
                                    ServerSentEvent(
                                        data={
                                            "type": "tool_call",
                                            "delta": {
                                                "tool_name": part.function_call.name,
                                                "params": Application.safe_jsonable(part.function_call.args),
                                            },
                                        },
                                        event="message",
                                    )
                                )

                            if getattr(part, "function_response", None) is not None:
                                await queue.put(
                                    ServerSentEvent(
                                        data={
                                            "type": "tool_response",
                                            "delta": {
                                                "tool_name": part.function_response.name,
                                                "response": Application.safe_jsonable(part.function_response.response),
                                            },
                                        },
                                        event="message",
                                    )
                                )

                    if event.actions and event.actions.state_delta:
                        await queue.put(
                            ServerSentEvent(
                                data={
                                    "type": "state_update",
                                    "delta": Application.safe_jsonable(event.actions.state_delta),
                                },
                                event="message",
                            )
                        )

                    if event.is_final_response():
                        final_session = await Application.session_service.get_session(
                            app_name=Application.agent_app_name,
                            user_id=request.user_id,
                            session_id=request.session_id,
                        )
                        await queue.put(
                            ServerSentEvent(
                                data={
                                    "type": "final",
                                    "state": Application.safe_jsonable(final_session.state if final_session else None),
                                },
                                event="final",
                            )
                        )

                await queue.put(ServerSentEvent(raw_data="[DONE]", event="done"))
                logging.info(
                    "stream done user_id=%s session_id=%s",
                    request.user_id,
                    request.session_id,
                )

            except asyncio.CancelledError:
                logging.info(
                    "stream producer cancelled user_id=%s session_id=%s",
                    request.user_id,
                    request.session_id,
                )
                raise
            except Exception as e:
                logging.exception(
                    "stream producer failed user_id=%s session_id=%s",
                    request.user_id,
                    request.session_id,
                )
                await queue.put(
                    ServerSentEvent(
                        data={"type": "error", "message": str(e)},
                        event="error",
                    )
                )
            finally:
                await queue.put(None)

        producer_task = asyncio.create_task(producer())

        try:
            # 首包
            yield ServerSentEvent(comment="stream opened")

            while True:
                if await http_request.is_disconnected():
                    producer_task.cancel()
                    break

                try:
                    item = await asyncio.wait_for(queue.get(), timeout=10)
                except asyncio.TimeoutError:
                    # 空闲保活
                    yield ServerSentEvent(comment="keep-alive")
                    continue

                if item is None:
                    break

                yield item

        finally:
            if not producer_task.done():
                producer_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await producer_task


    @api.post("/chat", tags=["ADK API"])
    async def chat(request: ChatRequest):
        try:
            await Application.ensure_session(user_id=request.user_id, session_id=request.session_id)

            full_response = ""
            final_state = None

            content = types.Content(
                role="user",
                parts=[types.Part(text=request.message)]
            )

            async for event in Application.agent_adk_runner.run_async(
                user_id=request.user_id,
                session_id=request.session_id,
                new_message=content,
            ):
                if event.content and event.content.parts:
                    for part in event.content.parts:
                        if getattr(part, "text", None):
                            full_response += part.text

                if event.is_final_response():
                    final_session = await Application.session_service.get_session(
                        app_name=Application.agent_app_name,
                        user_id=request.user_id,
                        session_id=request.session_id,
                    )
                    final_state = final_session.state if final_session else None

            return {
                "response": full_response,
                "final_state": Application.safe_jsonable(final_state),
            }

        except Exception as e:
            logging.exception("chat failed")
            raise HTTPException(status_code=500, detail=str(e))


    @api.get("/session/{user_id}/{session_id}/state", tags=["ADK API"])
    async def get_session_state(user_id: str, session_id: str):
        try:
            session = await Application.session_service.get_session(
                app_name=Application.agent_app_name,
                user_id=user_id,
                session_id=session_id,
            )
            if not session:
                raise HTTPException(status_code=404, detail="Session not found")

            return {"state": Application.safe_jsonable(session.state)}

        except HTTPException:
            raise
        except Exception as e:
            logging.exception("get_session_state failed")
            raise HTTPException(status_code=500, detail=str(e))
        
def main():
    global server_config
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s",
        stream=sys.stderr
    )
    uvicorn.run(Application.api, host=server_config.host, port=server_config.port)


if __name__ == '__main__':
    main()