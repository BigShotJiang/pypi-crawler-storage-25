import os
import logging
from pydantic import BaseModel
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from google.adk.agents import BaseAgent
from google.adk.memory import InMemoryMemoryService, BaseMemoryService
from google.adk.sessions import DatabaseSessionService, InMemorySessionService, BaseSessionService
from google.adk.runners import Runner
from ag_ui_adk import ADKAgent


class Utils:
    class Service:
        @staticmethod
        def memory_service(db_uri: str) -> BaseMemoryService | None:
            """
            Memory服务
            """
            if db_uri is None:
                return None

            if db_uri == "":
                return InMemoryMemoryService()

            return InMemoryMemoryService()


        @staticmethod
        def session_service(db_url: str) -> BaseSessionService | None:
            """Session服务"""
            if db_url is None:
                return None

            if db_url == "":
                return InMemorySessionService()

            return DatabaseSessionService(db_url=db_url)

    class Agent:
        agent_name = "AgentOS"
        @staticmethod
        def load_adk_agents(agents_path: str) -> BaseAgent | None:
            """
            加载智能体配置
            :param agents_path:
            :return:
            """
            try:
                import sys
                sys.path.append(str(agents_path))
                from agents import root_agent
                return root_agent
            except Exception as e:
                logging.error(f"Failed to load agents {e}")
                return None

        @staticmethod
        def create_adk_agent_agui_runner(
                agents_path: str,
                session_service_uri: str,
                memory_service_uri: str
        ) -> ADKAgent | None:
            """
            加载智能体配置
            """
            agent: BaseAgent = Utils.Agent.load_adk_agents(agents_path)
            if agent is not None:
                return ADKAgent(
                    adk_agent=agent,
                    app_name=f"{Utils.Agent.agent_name} AGUI APP",
                    session_service=Utils.Service.session_service(db_url=session_service_uri),
                    memory_service=Utils.Service.memory_service(db_uri=memory_service_uri),
                )

            return None


        @staticmethod
        def create_adk_agent_adk_runner(
                agents_path: str,
                session_service_uri: str,
                memory_service_uri: str
        ) -> Runner | None:
            """
            加载智能体配置
            """
            agent: BaseAgent = Utils.Agent.load_adk_agents(agents_path)
            if agent is not None:
                return Runner(
                    agent=agent,
                    app_name=f"{Utils.Agent.agent_name} ADK APP",
                    session_service=Utils.Service.session_service(db_url=session_service_uri),
                    memory_service=Utils.Service.memory_service(db_uri=memory_service_uri),
                    auto_create_session=False,
                )

            return None


    class Server:
        class UserWhitelistMiddleware(BaseHTTPMiddleware):
            ALLOWED_USERS = {"alice", "bob", "charlie@example.com"}

            async def dispatch(self, request: Request, call_next):
                # 1. 可选：定义路由白名单，用于跳过验证的端点
                # 例如，一个公开的 /health 端点，无需用户验证
                if request.url.path in [
                    "/agui/api/v1/health",
                    "/agui/api/v1/reload",
                    "/agui/api/v1/chat/completions",
                    "/adk/api/v1/health",
                    "/adk/api/v1/reload",
                    "/adk/api/v1/chat/completions",
                    "/docs", "/openapi.json"
                ]:
                    return await call_next(request)

                # 2. 提取并验证用户ID
                user_id = request.headers.get("X-User-Id")
                if not user_id:
                    logging.warning(f"拒绝访问: 未提供用户ID，来自 {request.client.host}")
                    return Response("未授权: 缺少用户身份标识", status_code=401)

                if user_id not in Utils.Server.UserWhitelistMiddleware.ALLOWED_USERS:
                    logging.warning(f"拒绝访问: 用户 '{user_id}' 不在白名单内，来自 {request.client.host}")
                    return Response(f"禁止访问: 用户 '{user_id}' 无权限", status_code=403)

                # 3. 用户在白名单内，记录日志并继续处理请求
                logging.info(f"用户 '{user_id}' 通过白名单验证")
                return await call_next(request)

        class ServerConfig(BaseModel):
            # 智能体配置文件夹
            agents_path: str

            # session服务URI
            session_service_uri: str

            # memory服务URI
            memory_service_uri: str

            # 用户服务URI
            user_service_uri: str

            # trace service URI
            trace_service_uri: str

            # host
            host: str

            # port
            port: int
