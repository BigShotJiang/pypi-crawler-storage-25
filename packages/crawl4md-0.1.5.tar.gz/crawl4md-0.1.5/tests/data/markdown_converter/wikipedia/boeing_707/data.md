# Boeing 707

| Boeing 707 | |
| --- | --- |
| Eine Boeing 707 der Air India *Eine Boeing 707 der Air India* | |
| Typ | Vierstrahliges Schmalrumpfflugzeug |
| Entwurfsland | Vereinigte Staaten |
| Hersteller | Boeing Airplane Company |
| Erstflug | 20. Dezember 1957 |
| Indienststellung | 26. Oktober 1958 |
| Produktionszeit | 1957 bis 1982/1991 (zivil / militärisch) |
| Stückzahl | 1010 (inkl. 154 Boeing 720) |

Die **Boeing 707** ist ein vierstrahliger Tiefdecker mit Schmalrumpf des US-amerikanischen Flugzeugherstellers Boeing. Die Boeing 707 war – nach der De Havilland Comet – das zweite mit Strahltriebwerken ausgestattete Langstrecken-Passagierflugzeug. Sie revolutionierte zusammen mit der vergleichbaren Douglas DC-8 und anderen wirtschaftlich weit weniger erfolgreichen Flugzeugtypen dieser Zeit die zivile Luftfahrt. Insgesamt wurden 1010 Boeing 707 in verschiedenen zivilen und militärischen Versionen ausgeliefert. Heute fliegt keine Maschine mehr im zivilen Passagierliniendienst.

## Geschichte

### Vorgeschichte

*Boeing 367 (C-97)*

Seit dem Jungfernflug des ersten strahlgetriebenen Flugzeugs aus den Vereinigten Staaten von Amerika, der Bell XP-59, konstruierten zahlreiche andere Flugzeughersteller des Landes Maschinen, die mit der neuen Antriebstechnik ausgestattet waren. Während jedoch in Großbritannien mit der De Havilland Comet und in Kanada mit dem Prototyp der Avro Canada C-102 bereits erste Passagierflugzeuge mit Strahltriebwerken ausgerüstet wurden, folgten die Vereinigten Staaten von Amerika diesem Trend zunächst nicht. Gründe hierfür waren mangelnde Erfahrungen, die geringe Lebensdauer der Triebwerke, der hohe Wartungsaufwand und der exzessive Kerosinverbrauch. Ebenfalls problematisch war das Fehlen der für solche Flugzeuge notwendigen langen und gut ausgebauten Start- und Landebahnen. Daher konzentrierte sich Boeing im Bereich der Passagierluftfahrt zunächst auf die Weiterentwicklung bestehender Flugzeuge, so entstand etwa das Langstrecken-Passagierflugzeug Boeing 377. Für den militärischen Sektor entwickelte Boeing bereits strahlgetriebene Typen, beispielsweise die Boeing B-47 oder die Boeing B-52, und sammelte hier Erfahrungen. 1949 begann Boeing mit Arbeiten an der Boeing 367 (C-97). Die Planung mit dem Namen *Boeing 367-40* sah vor, das Flugzeug mit Strahltriebwerken auszustatten und es als Tankflugzeug, Transportflugzeug und Passagierflugzeug anzubieten. Beibehalten werden sollte der Rumpfquerschnitt der Boeing 367, welcher durch das Verschmelzen zweier Rümpfe nicht eine kreisrunde oder ovale, sondern eine charakteristische Form hatte, welche der Ziffer 8 glich.

Gleichzeitig verfolgte Boeing in dieser Zeit Überlegungen, den Hochgeschwindigkeitsbomber Boeing B-47 auch in einer Passagierversion mit verlängertem Rumpf für maximal 27 Passagiere anzubieten. Da dieser Umbau nicht sinnvoll erschien, konzentrierte man sich auf das Projekt Boeing 367-40.

### Entwicklung der Boeing 367-80

*Boeing 367-80*

Das Konzept der Boeing 367-40 wandelte sich schließlich zur verwirklichten Boeing 367-80, die mit der ursprünglichen 367 kaum etwas gemein hatte. Ihr Rumpfquerschnitt sah weiterhin der Ziffer 8 ähnlich, was jedoch an der Außenhaut durch eine aerodynamisch günstige Verkleidung verdeckt wurde. Die Pfeilung der Tragflächen betrug 35°, was im zivilen Flugzeugbau neuartig war. Am 2. Mai 1952 beschloss der damalige Vorstandsvorsitzende von Boeing, William McPherson Allen, die Boeing 367-80 zu entwickeln, obwohl sich bisher kein Kunde für das Flugzeug interessiert hatte. Die Kosten hierfür beliefen sich mit 16 Millionen US-Dollar auf 50 % des damaligen Gesamtumsatzes von Boeing. 1954 wurde von der United States Air Force (USAF) ein Wettbewerb für einen neuen Tanker ausgeschrieben, an dem Boeing mit der 367-80, welche auch Dash 80 (deutsch: Bindestrich 80) genannt wurde, teilnahm. Das Rollout der Maschine fand am 14. Mai 1954 statt, der Erstflug folgte am 15. Juli 1954 vom Werk Renton aus. Trotz der militärischen Ausrichtung war der Prototyp zivil als N70700 registriert.

*Boeing KC-135*

Am 5. Oktober 1954 bestellte die USAF unter der Bezeichnung KC-135 29 als Tankflugzeug ausgerüstete Boeing 367-80. Am 13. Juli 1955 gestattete die USAF Boeing, das Flugzeug auch für zivile Zwecke Kunden anzubieten; aus letzterem wurde die Boeing 707 entwickelt.

### Entwicklung der Boeing 707

Zunächst wurden durch Boeing Umfragen bei den damaligen großen Fluggesellschaften durchgeführt. Sie forderten vor allem eine verbreiterte Kabine, da sie die 3,53 m Durchmesser der Boeing 367-80 als nicht ausreichend betrachteten. Vorerst wurde daher ein Kompromiss zwischen der United States Air Force und Boeing erreicht, den Rumpfquerschnitt um 11 cm anzuheben. Ebenfalls vergrößert wurden die Tragflächen, die bei den Modellen Boeing KC-135 und Boeing 707-100 identisch sind. Aufgrund der großen strukturellen Probleme der De Havilland DH.106 Comet, welche zu mehreren Abstürzen geführt hatten, konzentrierte sich Boeing in der Testphase besonders auf strukturelle Belastungen der Flugzeugbestandteile. Zur Hilfe nahm man dafür beispielsweise große Wassertanks, in die man ganze Rümpfe der Vorserien-Boeing-707 versenkte. Große Verbesserungen konnten bei der notwendigen Startstrecke durch stärkere Triebwerke und den Einbau von Auftriebshilfen an den Tragflächen erreicht werden, auch die Langsamflugfähigkeit wurde stark verbessert.

*Douglas DC-8-21, 1972*

Große Probleme bereitete Boeing zunächst die zäh verlaufenden Verkaufsgespräche, da die zahlreichen Abstürze der de Havilland DH 106 das Image von Strahlflugzeugen belasteten und da der Anschaffungspreis von 4,5 Millionen Dollar im Vergleich zu altbewährten Flugzeugen hoch war. In dieser Situation konnten die erfolgreich und sicher fliegende Tupolew Tu-104 sowie die sich in der Entwicklung befindende Sud Aviation Caravelle Abhilfe schaffen: Diese zwangen die amerikanischen Fluggesellschaften dazu, dem Trend der Strahlflugzeuge zu folgen, um nicht den Anschluss zu verlieren. Als erste Fluggesellschaft bestellte am 13. Oktober 1955 Pan American World Airways 20 Exemplare, kaufte jedoch gleichzeitig 25 Douglas DC-8. Das 1955 offiziell verkündete Douglas-DC-8-Programm entsprach bzw. übertraf in Abmessungen und Flugleistungen dasjenige der Boeing 707. Der zu diesem Punkt größte Unterschied fand sich im Rumpfquerschnitt. So sollten bei der DC-8 sechs Passagiere pro Reihe Platz finden, bei der Boeing 707 auch nach der Verbreiterung nur fünf. Um konkurrenzfähig zu bleiben, erhöhte Boeing den Rumpfdurchmesser der 707 erneut, auf 3,76 Meter, und damit drei Zentimeter über den Rumpfdurchmesser der Douglas DC-8 hinaus. Die sehr teure Entscheidung – so mussten nicht nur die Prototypen umgebaut werden, sondern auch von nun an das Tankflugzeug Boeing KC-135 und die Boeing 707 in verschiedenen Flugzeugfertigungsstraßen gebaut werden – zahlte sich aus, denn langfristig übertrumpfte die Boeing 707 die Douglas DC-8 in den Verkaufszahlen, und der Rumpf der Boeing 707 findet sich bis heute in kaum veränderter Form bei der Boeing 737.

Das „Roll-Out“ der Boeing 707 verspätete sich durch die Rumpfverbreiterung auf den 28. Oktober 1957, der Erstflug folgte am 20. Dezember desselben Jahres. Am 18. September 1958 wurde die Boeing 707 durch die amerikanische Luftfahrtbehörde zugelassen.

Da die Flugstabilität zunächst nicht befriedigend war, wurden etwa ein Jahr nach Indienststellung der ersten 707-100 im Oktober 1958 alle neuen und fast alle bereits ausgelieferten 707-100, und -200 mit einer Verlängerung des Seitenleitwerks sowie einem zusätzlichen vertikalen Leitblech unten am Heck ausgestattet.

### Auslieferungen und Einsatz

Nachdem am 15. August 1958 die erste Boeing 707 (N709PA) ausgeliefert wurde, begann Pan Am mit der Streckenerprobung. Erklärtes Ziel war, als erste Fluggesellschaft einen Linienflug mit einem durch Strahltriebwerke angetriebenen Flugzeug über den Atlantik anzubieten, obwohl die erste Version der Boeing 707 gar nicht für eine solche Strecke ausgelegt war. Der erste Linienflug wurde am 26. Oktober 1958 von New York City mit Zwischenlandung in Neufundland nach Paris durchgeführt, wodurch man jedoch zwei Tage später als der britische Konkurrent British Overseas Airways Corporation, welcher die De Havilland Comet 4 einsetzte, einen solchen Flug unternahm. Speziell für Qantas entwickelte Boeing die Langstreckenversion Boeing 707-138 (siehe unten), welche am 24. Juli 1959 zugelassen wurde und einen um drei Meter verkürzten Rumpf besaß. Weitere Verbesserungen der Leistungen konnten durch effizientere Triebwerke erreicht werden. Insgesamt stieg dadurch die Reichweite von anfangs weniger als 5.000 km auf fast 8.500 km. Im Laufe der Zeit wurden weitere Versionen entwickelt und gebaut, die im Abschnitt Varianten genauer erläutert werden.

Die Produktion der Boeing 707 als Passagierflugzeug endete 1978. Insgesamt wurden 917 zivile Boeing 707 gebaut, viele wurden jedoch nach ihrem zivilen Dienst für militärische Aufgaben genutzt. Die Varianten der Boeing 707, die lediglich für das Militär neu gebaut wurden, produzierte Boeing bis 1991.

## Konstruktion

*Rumpfquerschnitt der Boeing 707*

Die nachfolgenden Angaben beziehen sich exemplarisch auf die Variante Boeing 707-300 für den Passagiertransport.

### Rumpf

Der Rumpf der Boeing 707 besteht aus Ganzmetall, der in Halbschalenbauweise nach dem Fail-Safe-Prinzip aufgebaut ist. Die für den Rumpf verwendeten Spanten haben unterschiedliche Radien: Die oberen Spanten sind größer als die unteren, was zur Folge hat, dass der Rumpfquerschnitt nicht oval ist, sondern eine leichte Einschnürung aufweist, ähnlich der Ziffer 8. Aufgrund der Erfahrung mit der De Havilland DH.106 Comet wurde die 707 mit sogenannten Rumpfstringern ausgerüstet, welche in die Flugzeug-Außenhaut unabhängig von der eigentlichen Beplankung eingearbeitet sind. Dadurch können sie einen entstehenden Riss in der Außenhaut stoppen und somit ein totales Versagen der Struktur verhindern.

*Rumpftür einer Boeing 707*

*Eyebrow-Fenster über den eigentlichen Cockpitfenstern*

Die Passagierkabine ist 33,99 m lang und bietet maximal 215 Passagieren Platz. Pro Reihe mit einem Mittelgang können bis zu sechs Passagiere sitzen. Normalerweise befinden sich vier Bordküchen und fünf Toiletten im Flugzeug. Auf der linken Seite können die Passagiere durch zwei je 183 cm × 86 cm große Türen an Bord gelangen. Auf der rechten Seite befinden sich zwei kleinere Türen, darüber hinaus gibt es im Bereich der Tragfläche pro Seite mindestens zwei Notausgänge. Mit den Triebwerken 2, 3 und 4 (in Flugrichtung von links gezählt) verbundene Turbokompressoren treiben die Druckkabine und die Klimaanlage an, welche von Garrett AiResearch stammen.

Unterhalb der Passagierkabine befinden sich vor und hinter dem Flügelkasten zwei Stauräume für Fracht. Der vordere ist 23,65 Kubikmeter groß und kann durch eine Klappe mit den Abmessungen 127 cm × 122 cm erreicht werden, der hintere ist 24,50 m³ groß und durch zwei 124 cm × 122 cm und 89 cm × 76 cm große Frachttüren, die hintereinander angeordnet sind, erreichbar. Sowohl der Bereich für die Passagiere als auch der für die Fracht sind als Druckkabine ausgeführt. Die insgesamt 90 Kabinenfenster sind rechteckig. Darüber hinaus gibt es kleine runde Fenster in den Türen und sechs Planscheiben sowie vier „Eyebrow-Fenster“ im Cockpit.

### Cockpit und Avionik

*Cockpit einer Boeing 707-123B im Deutschen Museum, München*

Bei der Boeing 707 bestand die Cockpit-Besatzung zunächst aus vier Mitgliedern: Flugkapitän, Erster Offizier, Flugingenieur und Navigator. Dieser verwendete Funknavigationssysteme wie unter anderem VOR/DME und LORAN-C. Zur Kommunikation stehen Kurzwellen- und Ultrakurzwellenfunkgeräte zur Verfügung. Ab der zweiten Hälfte der 1960er Jahre wurde der Navigator bei fortschrittlichen Fluggesellschaften zunehmend durch das INS-Navigationssystem ersetzt. Weitere Grundbestandteile der Avionik sind der Autopilot mit Kopplung zum Instrumentenlandesystem, das Wetterradar und ein Radarhöhenmesser. Diese Basisausrüstung konnte je nach Kundenwunsch erweitert werden.

### Tragflächen

Die Tragflächen der Boeing 707 sind jeweils um 35° gepfeilt und aus Ganzmetall nach dem Fail-Safe-Prinzip konstruiert. Die V-Stellung beträgt 7°, der Einstellwinkel 2°. In ihnen befinden sich je drei Tanks. Ein siebter Tank ist der Zentraltank im Flügelkasten. Je nach Version der Boeing 707-300 variiert das Volumen der Tanks zwischen 88.947 und 94.083 Litern. Alle Tanks sind durch Treibstoffleitungen miteinander verbunden. Im Notfall ist es möglich, maximal 2.000 Liter Kerosin pro Minute abzulassen. An der Vorderseite der Tragflächen befinden sich Krügerklappen, welche bei einer Landeklappenstellung von über 9,5° automatisch ausfahren und die sich über zwei Drittel der Tragflächenvorderkante erstrecken. Außerdem findet man auf der Vorderseite pro Tragfläche je zwei Triebwerkspylonen, in denen sich über den Triebwerken 2, 3 und 4 auch Kompressoren für die Klimaanlage und die Druckkabine befinden. Auf der Rückseite befinden sich mehrere Klappen mit verschiedenen Aufgaben: Direkt am Rumpf sind die sogenannten *fillet flaps* (Ausrundungs-Klappen) angebracht, welche die aerodynamische Lücke zwischen den Fowlerklappen und dem Rumpf füllen. Ebenfalls an der Hinterseite montiert sind Doppelspalt-Landeklappen, je zwei Querruder, wobei das äußere nur beim Landeanflug verwendet werden kann, sowie vier Rollspoiler, welche paarweise vor den Fowlerklappen angeordnet sind. Die Ansteuerung der Klappen funktioniert hydraulisch, lediglich die Querruder werden mechanisch angelenkt. Auf den Tragflächen befinden sich zudem zwei Reihen von Wirbelgeneratoren.

### Leitwerke

*Boeing 707-131B der TWA. Man beachte das Seitenleitwerk ohne Antenne.*

Auch das Leitwerk besteht aus Ganzmetall und ist freitragend konstruiert. Die gesamte Höhenflosse ist zur Trimmung mit Hilfe von Elektromotoren beweglich, an der Unterseite befinden sich Wirbel-Erzeuger, um die Piloten über die Reaktion des Höhenruders vor einem bevorstehenden Strömungsabriss zu warnen.

Das fast zehn Quadratmeter große Seitenleitwerk ist durch die nach vorne ragende, stachelförmige Hochfrequenz-Antenne besonders auffällig. An seiner Hinterkante ist eine kleine Trimmklappe vorhanden. An den Seitenleitwerken der für Trans World Airlines ausgelieferten 707-131B (-31 war TWAs Customer Code bei Boeing) wurde auf die HF-Antenne verzichtet.

In frühen Versionen der Boeing 707 befand sich unterhalb des Rumpfes noch eine kleine Heckflosse. Mit der Verbesserung der Start- und Landeleistungen durch Einführung eines größeren Höhenleitwerks und der dreiteiligen Vorflügel wurde auf diese verzichtet.

Bemerkenswert ist, dass Höhen- und Querruder nur mit aerodynamischer und ohne hydraulische Kraftverstärkung betätigt werden.

### Triebwerke

Für die Boeing 707-300 wurde das vom militärischen Pratt-&-Whitney-J57-Einstrom-Strahltriebwerk abgeleitete Pratt-&-Whitney-JT3D-Zweistrom-Strahltriebwerk in verschiedenen Versionen verwendet. Dessen Varianten unterschieden sich dadurch, dass durch den Austausch der ersten drei Verdichterstufen das Nebenstromverhältnis gesteigert werden konnte, was reduzierte Lautstärke und höhere Effizienz zur Folge hatte. Später wurden einige Boeing 707 auf CFM-International-CFM56-Triebwerke umgerüstet. Der Nennschub der Triebwerke bewegte sich um 80 kN.

### Fahrwerk

Das Fahrwerk der Boeing 707 besteht aus einem Bugfahrwerk mit Doppelbereifung und dem Hauptfahrwerk, das sich aus zwei je vierfach bereiften Einheiten zusammensetzt. Das Hauptfahrwerk ist mit einem Bremssystem von Goodyear und einem Anti-Skid-System von Hydro Air ausgestattet. Nach dem Start schwenkt das Bugfahrwerk nach vorne in eine durch zwei Klappen verschließbare Box ein. Das Hauptfahrwerk hat pro Einheit je zwei Achsen mit jeweils zwei Rädern und schwenkt in den Rumpf hinter den Flügelkasten ein.

## Varianten

### Zivile Versionen

#### 707-020 (720)

→ *Hauptartikel: Boeing 720*

*Boeing 720-023B der Aerocondor Colombia in Miami, 1975*

Mit dem kommerziellen Erfolg der Langstreckenvarianten der Boeing 707 entschloss sich Boeing, auch eine spezielle Kurz- bis Mittelstreckenvariante der 707 zu entwickeln, und bot diese den Fluggesellschaften ab 1957 als *Boeing 707-020* an, später *Boeing 720* genannt. Der Erstflug fand am 23. November 1959 statt.

Wegen grundlegender Änderungen an Tragflächen und Zelle kann man die Boeing 707-020 als eigenständiges Modell betrachten, weshalb sie als *Boeing 720* eine eigene Typenbezeichnung erhielt.

**720B** Wie auch bei anderen Versionen der Boeing 707 wurde eine Variante mit modernen Triebwerken als *Boeing 707-020B* eingeführt. Sie verfügte über Pratt-&-Whitney-JT3D-1-Turbofans mit einem Schub von jeweils 75,6 kN. Die maximale Startmasse wurde außerdem auf 106.200 kg erhöht. Der Erstflug einer 720B erfolgte am 6. Oktober 1960, weniger als ein Jahr nach dem Erstflug der Basis-720.

#### 707-100

*Boeing 707-124 der Continental Airlines*

Die *Boeing 707-100* war die erste in Serie verkaufte Variante der Boeing 707. Ihr Erstflug fand am 20. Dezember 1957 statt. Die Boeing 707-100 wurde als Mittelstreckenflugzeug zum Einsatz nationaler Flüge innerhalb der Vereinigten Staaten von Amerika konstruiert. Für Transatlantikflüge mussten Zwischenlandungen zum Auftanken durchgeführt werden. Angetrieben von vier Pratt & Whitney JT3C-6 Turbojets, können maximal 179 Passagiere transportiert werden. Insgesamt wurden 141 zivile 707-100 produziert.

**707-138**

*Boeing 707-138B der Qantas*

(38 ist der *Boeing Customer Code* für Qantas)

Eine Variante der Boeing 707-100 mit einem um drei Meter verkürzten Rumpf sowie einem optionalen Außenbehälter für ein Ersatztriebwerk baute Boeing speziell für Qantas Airways. Später wurde diese durch eine um 15 % vergrößerte Reichweite erneut verbessert und abermals exklusiv an Qantas verkauft. Die erste Auslieferung der 707-138B erfolgte am 29. Juli 1961, die letzte am 10. September 1964. Der Hollywood-Star John Travolta besitzt eine der ursprünglichen 707-138B von Qantas als Privatmaschine mit besonders luxuriöser Innenausstattung. Außen trägt die Maschine entsprechend einer Vereinbarung mit der Fluggesellschaft eine exakte Reproduktion der Bemalung der 1960er Jahre. John Travoltas Jet hat das Kennzeichen *N707JT*.

**707-100B**

*Boeing 707-100B der Cyprus Airways*

Die erste wesentliche Verbesserung der 707 führte zur *Boeing 707-100B*. Unter anderem wurde dieser Typ mit verbesserten JT3D-1-Turbofan-Triebwerken ausgestattet, die leiser, stärker und treibstoffsparender waren. Jedes Triebwerk produzierte einen Schub von 75,6 kN. Diese Version bekam auch zusätzliche Vorflügel, wie sie ursprünglich für die 720 konstruiert wurden, und ein vergrößertes Leitwerk. De facto wurden alle noch aktiven ursprünglich als -100 ausgelieferten 707 nach und nach durch Umrüstung auf den -100B-Standard gebracht. Erstflug der 707-100B war am 22. Juni 1960.

Die erste Maschine dieses Typs wurde am 25. Mai 1961 an American Airlines ausgeliefert. Das letzte von insgesamt 72 produzierten zivilen Exemplaren erhielt am 22. April 1969 ebenfalls American Airlines.

#### 707-200

*Boeing 707-200 der Braniff Airways*

Die *Boeing 707-200* wurde speziell daraufhin entwickelt, leichter zu sein und weniger Nutzlast befördern zu können als die 707-100, dies jedoch unter wesentlich extremeren Einsatzbedingungen, wie von besonders heißen oder besonders hoch gelegenen Flughäfen aus. Ausgestattet wurde die 707-200 mit leistungsstarken, auch bei der 707-300 und dem Konkurrenzmodell Douglas DC-8 verwendeten Pratt & Whitney JT4A-Turbojets mit jeweils 70,2 kN Schub. Der Erstflug des Prototyps fand am 11. Juni 1959 statt, er ging am 19. Oktober 1959 bei einem Absturz verloren. Nur fünf 707-200 wurden produziert, die zwischen 3. Dezember 1959 und 10. Februar 1960 alle an Braniff International gingen. Mit der Entwicklung des stärkeren und sparsameren Turbofan-Triebwerks, wie es bei der 707-100B zum Einsatz kam, wurde die -200 relativ schnell überflüssig, weshalb es keine B-Version dieses Typs gibt.

#### 707-300

*Boeing 707-300 der Egypt Air*

Die *Boeing 707-300* ist die erste gestreckte Version der ursprünglichen 707. Sie wurde speziell für Langstrecken ausgelegt, weshalb sie auch den Beinamen *Intercontinental* trug. Dank eines um circa 2,5 m gestreckten Rumpfs fasste die 707-300 bis zu 189 Passagiere.

Auch von dieser Serie wurden verschiedene Untervarianten produziert. Die Boeing 707-300 erreichte mit allen Varianten bis zur letzten Auslieferung im Jahr 1982 eine Gesamtstückzahl von 580 Exemplaren.

**707-300 Intercontinental**

Die *Boeing 707-300* ist eine gestreckte Version des Basismodells -100, ausgestattet mit Turbojet-Triebwerken des Typs Pratt & Whitney JT4A-3 mit einem Schub von jeweils 70,8 kN. Ein vergrößerter Flügel erlaubte es, mehr Treibstoff mitzunehmen und so eine um circa 3.000 Kilometer höhere Reichweite zu erzielen. Somit wurden für die 707 erstmals Nonstop-Flüge beispielsweise über den Atlantik möglich, ohne Zwischentankstopps einlegen zu müssen. Die maximale Abflugmasse lag bei 143.330 kg. Den Erstflug absolvierte die 707-300 am 11. Januar 1958. Erstkunde Pan Am erhielt die erste Maschine am 19. Juli 1959. Sabena erhielt gut vier Jahre später, am 17. Januar 1963, die letzte 707-300. Insgesamt wurden 69 Exemplare dieser Variante hergestellt.

**707-300B**

*Boeing 707-300B der Condor*

Die gestreckte 707-300 wurde parallel zur -100B ebenfalls überarbeitet. Die daraus resultierende -300B erhielt einige der für die -100B entwickelten Struktur-Modifikationen, sowie ähnliche Pratt-&-Whitney-JT3D-3-Turbofan-Triebwerke mit einem Schub von je 80 kN. Die maximale Startmasse wurde auf 151.950 kg erhöht und die Flügel noch einmal grundlegend überarbeitet. Das amerikanische Militär nutzte 707-300B-Frachter unter der Bezeichnung *C-18*. Eine 707-300B wurde von der United States Air Force als erste von Strahltriebwerken angetriebene Air Force One beschafft und eingesetzt. Die offizielle Bezeichnung für diese Spezialmaschine war *VC-137C*. Die erste 707-300B erhielt Pan Am am 12. April 1962. Insgesamt wurden 174 Maschinen dieses Typs produziert, sowie viele 707-300 auf den -300B-Standard gebracht. Die letzte fabrikneue 707-300B ging am 11. Juni 1975 an die argentinische Regierung.

**707-300C**

*Boeing 707-300C der Abelag Airways*

Die *Boeing 707-300C* war eine flexibel vom Frachter zur Passagiermaschine umrüstbare Version, die auch in gemischten Passagier- und Frachtkonfigurationen betrieben werden konnte. Sie war die beliebteste Variante der 300er-Serie. Die -300C verfügte gegenüber der Standard-300B über einen verstärkten Kabinenboden und eine große Frachttür links im Vorderrumpf. Kleinere Änderungen gegenüber der 707-300B umfassten unter anderem neue Fahrwerksklappen, weitere Vorflügelklappen und einen zusätzlichen Notausgang hinter dem Flügel (der für den Mischbetrieb als Frachter-/Passagiermaschine notwendig war, wenn vorn Fracht und hinten Passagiere transportiert wurden). 335 Exemplare dieser Variante wurden produziert, davon einige mit stärkeren JT3D-7-Triebwerken mit jeweils 84,4 kN Schub und einer höheren Startmasse von 152.400 kg. Obwohl sie theoretisch *convertible*, also flexibel umrüstbar waren, wurden viele Maschinen dieses Typs als reine Frachter ausgeliefert und genutzt. Die erste Auslieferung erfolgte am 2. Mai 1963 an Pan Am, die letzte am 10. März 1982 an die Luftwaffe von Marokko, welche sie als Tankflugzeug einsetzte. Da diese 707 ursprünglich zu Testzwecken (siehe *707-700*) produziert und erst später zum militärischen Tanker umgerüstet und verkauft wurde, zählt dieses Exemplar offiziell als letzte produzierte zivile 707.

**707-300B Advanced**

Die *Boeing 707-300B Advanced (707-320BA)* ist eine Modifikation der Boeing 707-300B auf den technischen Stand der -300C. Die Änderungen umfassten wie beim Modell 707-300C neue Fahrwerksklappen vorn, die neue Flügelvorderkante, geänderte Landeklappen und andere kleine Änderungen. Im Gegensatz zur 707-300C hatte die 300B Advanced keinen zusätzlichen Notausgang und keine Frachttür links hinter dem Cockpit.

#### 707-400

*Boeing 707-400 (ex. Lufthansa *D-ABOD*) in Hamburg-Fuhlsbüttel mit auf *D-ABOB* geändertem Kennzeichen*

Die *Boeing 707-400* ist eine auf Anfrage der British Overseas Airways Corporation (BOAC) von Boeing entwickelte Variante der 707-300 mit britischen Rolls-Royce Conway-Mk-508-Turbofan-Triebwerken, deren Schub je 77,8 kN beträgt. Erstkunde dieser Version war schließlich jedoch nicht BOAC, sondern die deutsche Lufthansa, welche am 24. April 1956 vier Exemplare bestellte (Vertragsunterzeichnung am 23. Januar 1957). Die erste Maschine erhielt Air India am 18. Februar 1960, die erste Maschine für die Lufthansa folgte am 25. Februar 1960 (Rollout war am 18. November 1959). Die Landung der ersten Maschine *(D-ABOB)* in Hamburg-Fuhlsbüttel erfolgte am 2. März 1960 und der Liniendienst wurde am 17. März 1960 aufgenommen. Nach nur 37 produzierten Einheiten erhielt Varig am 11. November 1963 die letzte Maschine dieses Typs. Mit der 707-400 wurden größere Seitenleitwerke eingeführt, welche von diesem Zeitpunkt an auch für alle anderen Versionen verwendet wurden.

#### 707-700 (Projekt)

Bei der *Boeing 707-700* handelt es sich um ein Testflugzeug, mit dem geprüft werden sollte, ob es wirtschaftlich sinnvoll und machbar ist, die Boeing 707 mit CFM International CFM56-Triebwerken auszustatten und möglicherweise auch ältere 707 so nachzurüsten. Der Erstflug eines als -700 ausgerüsteten Flugzeugs fand am 27. November 1979 statt. Der verwendete Prototyp war dabei die fabrikneue letzte kommerzielle Boeing 707, welche später wieder in die Version -300C zurückgebaut wurde. Grund für die Einstellung des Projekts waren die zeitgleich auf den Markt kommenden zweistrahligen Schwestermodelle Boeing 757/767, welche über ähnliche Eigenschaften verfügten und denen umgerüstete 707 keine Konkurrenz machen sollten. Die während des 707-700-Testprogramms gesammelten Daten führten schließlich zu einem Programm, in dessen Zuge die auf der 707 basierenden KC-135/C-135 der US Air Force mit den CFM56-Triebwerken nachgerüstet wurden. Einige später ausgelieferte militärische Versionen der 707 nutzten ebenfalls diesen Triebwerkstyp.

Auch Douglas verfolgte ein Programm zur Nachrüstung der Douglas DC-8-60 mit neueren Triebwerken. Viele Maschinen der DC-8-60-Serie wurden schließlich erfolgreich zu Maschinen der DC-8-70-Serie umgerüstet und erfüllten damit sehr viel striktere Lärmgrenzwerte als die 707, so dass ab den späten 1980er Jahren deutlich mehr DC-8 als 707 im kommerziellen Betrieb verblieben, obwohl die 707 ursprünglich wesentlich erfolgreicher gewesen war.

#### 707RE

*Mit neuen Triebwerken ausgestattete Boeing 707RE auf der ILA 2002*

Am 22. August 2001 hob zum ersten Mal eine als *Boeing 707RE* (*R*e-*E*ngined – mit neuen Triebwerken versehen) bezeichnete umgebaute 707-300C ab. Der von *Seven Q Seven Inc.* umgerüstete Prototyp ist mit Pratt-&-Whitney-JT8D-219 Triebwerken ausgestattet, die pro Stück einen Schub von 93 kN liefern und eine Leistungssteigerung von circa 15 % bringen sollten. Ziel war, sowohl kommerzielle 707 als auch militärische KC-135 und E-3/E-8 mit den neuen Triebwerken auszustatten. Das JT8D würde problemlos an jede Boeing 707 ohne größere Modifikationen eingebaut werden können. Obwohl ein um 23 % reduzierter Treibstoffverbrauch und ein um 40 dB niedrigerer Lärmpegel beim Start nachgewiesen werden konnten, setzte sich die Idee wegen der nach dem 11. September 2001 schrumpfenden Luftfahrt nicht durch. Nachdem sich die Branche erholt hatte, wurde im August 2008 mit den Zulassungsflügen für das Triebwerk begonnen.

### Militärische Versionen

**C-135 und Varianten (Schmalrumpf)**

*Siehe Hauptartikel: Boeing C-135, Boeing KC-135, Boeing EC-135 und Boeing RC-135.*

*EC-18B Advanced Range Instrumentation Aircraft (ARIA)*

*Ein 707-368C-Tanker der Omega Aerial Refueling Services betankt das unbemannte Experimentalflugzeug X-47, 2015*

**C-137** Als *Boeing C-137* werden Boeing-707-Flugzeuge bezeichnet, die bei der United States Air Force für militärische Zwecke eingesetzt werden. Für den Transport wichtiger Personen ausgestattete Versionen der Boeing 707 der United States Air Force sind die VC-137A, VC-137B und VC-137C. Sie wurden unter anderem als Air Force One genutzt. Die Kanadischen Streitkräfte verwenden so genannte *Boeing CC-137* als Tank- und Frachtflugzeuge. Boeing bezeichnet diese als *Boeing KC-137*.

**C-18A** Die *Boeing C-18A* ist eine Version der Boeing 707, bei der ehemals zivil genutzte Flugzeuge zu Schulungsflugzeugen umgerüstet wurden. Vier der Flugzeuge wurden zu Relaisstationen für Raumfahrt-Telemetrie mit dem Namen *Boeing EC-18B* umgebaut, eins wurde zur *Boeing E-8* umgebaut.

**EC-18B/C/D** Die *Boeing EC-18B* wird als sogenanntes Advanced Range Instrumentation Aircraft (ARIA) durch das US-Verteidigungsministerium und die NASA zur luftgestützten Radarbeobachtung von Raumschiffen und Raketen genutzt. Bei der *Boeing EC-18C* handelt es sich um eine frühe Bezeichnung der Boeing E-8, die *Boeing EC-18D* ist ein Spezialflugzeug für Versuche mit Marschflugkörpern.

*Boeing E3 Sentry*

**TC-18E, TC-18F** Die *Boeing TC-18E* ist ein Trainingsflugzeug für das Fliegende Personal der AWACS-Besatzungen, ebenfalls wie die *Boeing TC-18F*, welche jedoch zur Ausbildung für die Boeing E-6 dient.

**EC-137D** *Boeing EC-137D* wurden die zwei Prototypen des AWACS-Programms für kurze Zeit genannt.

**E-3** Die *Boeing E-3* mit dem Beinamen *Sentry* basiert auf der Boeing 707-300 und ist ein Aufklärungsflugzeug des AWACS-Programms, das bei verschiedenen Staaten bis heute in Nutzung ist. Als *Boeing KE-3A* dient das Flugzeug Saudi-Arabien zusätzlich als Tanker. Angetrieben werden die E-3 der französischen und englischen Luftstreitkräfte von CFM-56-Strahltriebwerken, die in Deutschland stationierten E-3A der NATO sowie die amerikanischen E-3B und E-3C verwenden die ursprünglichen Triebwerke vom Typ TF-33-100A.

*Boeing E-8 Joint Stars*

**E-6** Die *Boeing E-6* mit dem Beinamen *Mercury* fliegt für die United States Navy als luftgestützte Kommando- und Kommunikationszentrale. Hierfür ist sie mit einer großen Schleppantenne ausgestattet. Als Triebwerke werden CFM-56 verwendet.

**E-8** Die *Boeing E-8* mit dem Beinamen *Joint STARS* wird bei der United States Air Force zur Gefechtsfeld-Aufklärung benutzt.

## Nutzung

*Eine Boeing 707 in den Farben der Lufthansa, bis zu ihrer Verschrottung 2021 abgestellt auf dem Areal des Flughafens Berlin-Tegel*

Als eines der ersten Düsenverkehrsflugzeuge war die Boeing 707 zu ihrer Zeit wie die anderen vergleichbaren Flugzeuge ein Prestigeobjekt für jede Fluggesellschaft, entsprechend wurde sie weltweit von sehr vielen Fluggesellschaften genutzt und galt in den 1960er Jahren als Standard auf Langstreckenflügen. So entschied sich 1957 auch die deutsche Lufthansa für die Boeing 707, die bis Dezember 1984 im Einsatz blieb. Auf Grund des höheren Kerosinverbrauchs und der großen Lautstärke der Triebwerke ist der Flugzeugtyp mittlerweile bei allen großen Fluggesellschaften ausgemustert.

Mit Stand Juli 2013 waren von 1010 produzierten Exemplaren noch 147 im aktiven Dienst, fast alle davon im Rahmen von Militäreinsätzen.

Die letzte Fluggesellschaft, die noch zivile Passagierflüge mit einer Boeing 707 durchführte, war die iranische Saha Air. Am 26. Oktober 2008 feierte die Boeing 707 im Iran als erster Jet der Luftfahrtgeschichte ihren 50-jährigen Einsatz als Passagierflugzeug mit einem Linienflug der Saha Air von Teheran-Mehrabad nach Mashhad. Der Jubiläumsflug mit der Flugnummer *IRZ 160* endete allerdings nach knapp 20 Minuten Flugzeit aufgrund technischer Probleme mit der Hydraulik des Flugzeuges mit dem Kennzeichen *EP-SHU* mit einer geglückten Sicherheitslandung wieder in Teheran-Mehrabad. Am 23. April 2013 hat der Vorsitzende der iranischen Zivilluftfahrt-Organisation in einem Interview angekündigt, dass die drei verbliebenen Flugzeuge Typ Boeing 707 von Saha Air nicht mehr fliegen dürfen und damit dieser Fluggesellschaft die Lizenz entzogen wurde. Als Grund wurde die Sicherheit der Passagiere genannt. Seit 2013 werden auf der Welt keine Passagierflüge mehr mit einer Boeing 707 durchgeführt.

Militärisch jedoch ist die Boeing 707 bis heute weit verbreitet, ebenso wie ihre Schwesterflugzeuge wie die Boeing C-135 und die Boeing KC-135. Für viele Staaten diente die Boeing 707 in der Vergangenheit auch als Regierungsflugzeug, so z. B. von 1959 bis 2001 als Air Force One in den USA. Auch Deutschland nutzte den Flugzeugtyp bis 1999. Andere Länder waren u. a. Australien, Republik Kongo, Israel, Italien, Jordanien, Saudi-Arabien und Venezuela.

## Verkaufszahlen

Detaillierte Auflistung der Aufträge und Auslieferungen:

| | 707-100 | 707-200 | 707-020 (720) | 707-300 | 707-400 | Militärische Versionen | Insgesamt |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Bestellungen: | 141 | 5 | 154 | 580 | 37 | 93 | 1010 |
| Auslieferungen: | | | | | | | |

## Zwischenfälle

→ *Hauptartikel: Liste von Zwischenfällen mit der Boeing 707 und Boeing 720*

Vom Erstflug 1957 bis zum 31. Januar 2022 kam es mit Boeing 707 zu 173 Totalschäden von Flugzeugen. Das entspricht rund einem Fünftel (20,21 Prozent) aller 856 produzierten Flugzeuge dieses Typs. Bei 81 der Unfälle kamen 3032 Menschen ums Leben. In der Zahl der Totalschäden sind 19 Verluste von geparkten Maschinen inbegriffen. Insgesamt ergeben sich für die Boeing 707 8,60 Verluste pro einer Million Flüge, was – wie beim Konkurrenzmuster Douglas DC-8 mit 8,84 – über dem Durchschnittswert der 1960er und 1970er Jahre von etwa 5 liegt. Heutige Flugzeuge können im Vergleich mit Werten meist unter 0,5 sehr viel sicherer betrieben werden. Dreizehn Totalverluste mit insgesamt 280 Toten hatten eine kriegerische oder kriminelle Ursache, elf weitere gingen auf sonstige Ereignisse zurück und forderten keine Menschenleben.

## Technische Daten

*Boeing 707-300*

| Kenngröße | 707-100 | 707-138 | 707-200 | 707-020 | 707-300 | 707-400 |
| --- | --- | --- | --- | --- | --- | --- |
| Länge | 44,20 m 44,22 m (B) | 41,00 m | 44,20 m | 41,50 m 41,68 m (B) | 46,61 m | |
| Spannweite | 39,88 m | | | | 43,40 m 44,42 m (B & C) | 43,40 m |
| Flügelfläche | 226,3 m² | | | 234,2 m² | 273,7 m² 283 m² (B & C) | 273,7 m² |
| Höhe | 12,70 m | | | 12,62 m 12,55 m (B) | 12,85 m 12,83 m (B) 12,80 m (C) | 12,85 m |
| Rumpfdurchmesser | 3,76 m | | | | | |
| max. Reichweite | ca. 8.000 km 8.485 km (B) | ca. 8.500 km ca. 9.700 km (B) | ca. 6.500 km | 5.800 km 6.687 km (B) | 8.700 km 9.265 km (B) | 8.700 km |
| Reisegeschwindigkeit | Mach 0,83 885 km/h | | | | Mach 0,84 896 km/h | Mach 0,83 885 km/h |
| max. Startmasse | 117.000 kg | | | 104.000 kg 106.200 kg (B) | 141.700 kg 148.500 kg (B) 151.500 kg (C) | 141.700 kg |
| max. Sitzplätze | 179 | | | 165 | 219 | |
| typische Sitzanzahl | 110 | | | 106 | 141 | |
| Triebwerke (je 4×) | P&W JT3C-6-Turbojets à 55,2 kN *oder* P&W JT3D-1-Turbofans à 75,6 kN (B-Version) | | P&W JT4A-3-Turbojets à 70,8 kN | P&W JT3C-6-Turbojets à 60,1 kN *oder* P&W JT3D-1-Turbofans à 75,6 kN (B-Version) | P&W JT4A-3-Turbojets à 70,8 kN *oder* P&W JT3D-3-Turbofans à 80 kN (B-Version) | Rolls-Royce Conway-Mk-508-Turbofans à 77,8 kN |
| Besatzung (Cockpit) | 3 oder 4 | | | | | |
| Erstflug | 20. Dezember 1957 22. Juni 1960 (B) | 20. März 1959 13. April 1961 (B) | 11. Mai 1959 | 23. November 1959 6. Oktober 1960 (B) | 11. Januar 1959 31. Januar 1962 (B) 19. Februar 1963 (C) | 20. Mai 1959 |

## Trivia

Am 7. August 1955 flog der Testpilot Alvin M. „Tex“ Johnston mit dem ursprünglichen Prototyp, der Boeing 367-80, über Seattle eine Fassrolle. Weil dort zu diesem Zeitpunkt ein bekanntes Bootsrennen stattfand, wurde dieses Flugmanöver gefilmt. Der Pilot wurde für sein Verhalten gerügt, aber die Maschine wurde dadurch bekannt.

In dem Film *Airport* spielt eine Boeing 707 eine wichtige Nebenrolle.
