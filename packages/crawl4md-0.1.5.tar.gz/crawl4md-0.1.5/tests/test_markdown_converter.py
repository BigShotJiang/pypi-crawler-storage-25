# This file is part of the https://github.com/ixnode/crawl4md project.
#
# (c) 2026 Björn Hempel <bjoern@hempel.li>
#
# For the full copyright and license information, please view the LICENSE.md
# file that was distributed with this source code.
#
# @author: Björn Hempel <bjoern@hempel.li>
# @version: 1.0.0 (2026-05-05)
# @since 1.0.0 (2026-05-05) First version

from contextlib import redirect_stderr, redirect_stdout
import io
import os
from pathlib import Path
import unittest
import warnings

import yaml
from pydantic import BaseModel, Field

from crawl4md.config import CrawlConfig, NormalizationConfig, PreprocessingConfig, apply_profile_defaults
from crawl4md.fetch.markdown_fetcher_crawl4ai import MarkdownFetcherCrawl4AI
from crawl4md.fetch.markdown_fetcher_kreuzberg_dev import MarkdownFetcherKreuzbergDev
from tests.support.progress import run_progress_cases_async


SESSION_ROOT = Path(__file__).parent / "data" / "markdown_converter"


class MarkdownConverterSessionConfig(BaseModel):
    profile: str | None = None
    crawl: CrawlConfig = Field(default_factory=CrawlConfig)
    normalization: NormalizationConfig = Field(default_factory=NormalizationConfig)
    url: str | None = None
    preprocessing: PreprocessingConfig = Field(default_factory=PreprocessingConfig)


class MarkdownConverterSession(BaseModel):
    id: str
    title: str
    description: str
    config: MarkdownConverterSessionConfig


class MarkdownConverterSessionTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self.maxDiff = None

    async def asyncSetUp(self) -> None:
        loop = self._asyncioRunner.get_loop()
        loop.set_debug(False)

    async def test_converts_all_configured_sessions(self) -> None:
        group = os.environ.get("CRAWL4MD_MARKDOWN_CONVERTER_GROUP")
        update = os.environ.get("CRAWL4MD_MARKDOWN_CONVERTER_UPDATE") == "1"
        sessions = self._find_sessions(group=group)

        if group:
            self.assertGreater(
                len(sessions),
                0,
                f"No markdown converter test sessions found for group '{group}'.",
            )
        else:
            self.assertGreater(len(sessions), 0, "No markdown converter test sessions found.")

        session_ids = [
            self._load_config(session / "config.yml").id
            for session in sessions
        ]

        async def _run(index: int) -> None:
            session = sessions[index]
            session_name = session.relative_to(SESSION_ROOT).as_posix()

            with self.subTest(session=session_name):
                test_session = self._load_config(session / "config.yml")
                config = test_session.config
                fetcher = self._build_fetcher(config)
                html = self._load_and_normalize_html(
                    html_path=session / "data.html",
                    url=config.url,
                    fetcher=fetcher,
                )
                expected_markdown = (session / "data.md").read_text()

                converter = fetcher.build_markdown_converter()

                warnings.filterwarnings(
                    "ignore",
                    category=ResourceWarning,
                    message=r"unclosed database in <sqlite3\.Connection object at .*",
                    module=r"playwright\._impl\._local_utils",
                )

                output = io.StringIO()
                with redirect_stdout(output), redirect_stderr(output):
                    markdown = await converter.convert(html=html, url=config.url)

                if update:
                    (session / "data.md").write_text(markdown)
                    expected_markdown = markdown

                self.assertEqual(markdown, expected_markdown)

        await run_progress_cases_async(session_ids, _run)

    @staticmethod
    def _load_and_normalize_html(html_path: Path, url: str | None, fetcher: MarkdownFetcherCrawl4AI | MarkdownFetcherKreuzbergDev) -> str:
        html = html_path.read_text()

        if not url:
            return html

        html_fetcher = fetcher.build_html_fetcher(url=url)
        return html_fetcher.normalize_html(html)

    def _load_config(self, path: Path) -> MarkdownConverterSession:
        data = yaml.safe_load(path.read_text())
        data["config"] = apply_profile_defaults(data["config"])
        return MarkdownConverterSession(**data)

    async def test_crawl4ai_converter_supports_content_selector(self) -> None:
        config = MarkdownConverterSessionConfig(
            crawl=CrawlConfig(
                parser="crawl4ai",
                parse_type="markdown",
                content_selector="main",
            )
        )
        fetcher = self._build_fetcher(config)
        converter = fetcher.build_markdown_converter()
        html = (
            "<html><body>"
            "<nav><h1>Navigation</h1><p>Ignore me</p></nav>"
            "<main><h1>Content</h1><p>Keep me</p></main>"
            "</body></html>"
        )

        output = io.StringIO()
        with redirect_stdout(output), redirect_stderr(output):
            markdown = await converter.convert(html=html, url="https://example.test")

        self.assertIn("# Content", markdown)
        self.assertIn("Keep me", markdown)
        self.assertNotIn("Navigation", markdown)
        self.assertNotIn("Ignore me", markdown)

    def test_crawl4ai_config_allows_content_selector(self) -> None:
        config = CrawlConfig(
            parser="crawl4ai",
            parse_type="markdown",
            content_selector="main",
        )

        self.assertEqual(config.content_selector, "main")

    def _build_fetcher(self, config: MarkdownConverterSessionConfig) -> MarkdownFetcherCrawl4AI | MarkdownFetcherKreuzbergDev:
        if config.crawl.parser == "crawl4ai":
            return MarkdownFetcherCrawl4AI(
                config=config.preprocessing.markdown,
                normalization=config.normalization,
                parse_type=config.crawl.parse_type,
                content_selector=config.crawl.content_selector,
            )

        if config.crawl.parser == "kreuzberg-dev":
            return MarkdownFetcherKreuzbergDev(
                config=config.preprocessing.markdown,
                normalization=config.normalization,
                parse_type=config.crawl.parse_type,
                content_selector=config.crawl.content_selector,
            )

        raise ValueError(f"Unknown markdown converter parser: {config.crawl.parser}")

    def _find_sessions(self, group: str | None = None) -> list[Path]:
        if not group:
            root = SESSION_ROOT
        else:
            group_path = Path(group)
            if group_path.is_absolute() or ".." in group_path.parts:
                return []
            root = SESSION_ROOT / group_path

        return sorted(path.parent for path in root.rglob("config.yml"))


if __name__ == "__main__":
    unittest.main()
