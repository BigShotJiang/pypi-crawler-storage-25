"""
Tests for evtools.combinations — CRC.
"""

import numpy as np
import pytest
from evtools.dsvector import DSVector, Kind
from evtools.combinations import crc


FRAME_AB = ["a", "b"]
FRAME_ABC = ["a", "b", "c"]
FRAME_AHR = ["a", "h", "r"]

# m1: m({a})=0.3, m({a,b})=0.7
M1 = DSVector.from_focal(FRAME_AB, {"a": 0.3, "a,b": 0.7})

# m2: m({a})=0.5, m({b})=0.3, m({a,b})=0.2
M2 = DSVector.from_focal(FRAME_AB, {"a": 0.5, "b": 0.3, "a,b": 0.2})

# Vacuous BBA
VAC = DSVector.from_focal(FRAME_AB, {})  # all mass on Ω

# Categorical BBA: m({a}) = 1
CAT_A = DSVector.from_focal(FRAME_AB, {"a": 1.0})
CAT_B = DSVector.from_focal(FRAME_AB, {"b": 1.0})


# ---------------------------------------------------------------------------
# Correctness
# ---------------------------------------------------------------------------

def test_crc_sparse_known_result():
    # m12(A) = Σ_{B∩C=A} m1(B)·m2(C)
    # B={a}, C={a}  → A={a}:   0.3*0.5 = 0.15
    # B={a}, C={b}  → A=∅:     0.3*0.3 = 0.09
    # B={a}, C={a,b}→ A={a}:   0.3*0.2 = 0.06   → {a} total = 0.21
    # B={a,b},C={a} → A={a}:   0.7*0.5 = 0.35
    # B={a,b},C={b} → A={b}:   0.7*0.3 = 0.21
    # B={a,b},C={a,b}→A={a,b}: 0.7*0.2 = 0.14
    m12 = crc(M1, M2)
    assert np.isclose(m12[frozenset()],        0.09)
    assert np.isclose(m12[frozenset({"a"})],   0.15 + 0.06 + 0.35)
    assert np.isclose(m12[frozenset({"b"})],   0.21)
    assert np.isclose(m12[frozenset({"a","b"})], 0.14)
    assert np.isclose(sum(m12.sparse.values()), 1.0)


def test_crc_dense_matches_sparse():
    m12_sparse = crc(M1, M2, method="sparse")
    m12_dense  = crc(M1, M2, method="dense")
    assert np.allclose(m12_sparse.dense, m12_dense.dense, atol=1e-10)


def test_crc_sparse_matches_dense_3atom():
    m1 = DSVector.from_focal(FRAME_ABC, {"a": 0.3, "b,c": 0.4, "a,b,c": 0.3})
    m2 = DSVector.from_focal(FRAME_ABC, {"b": 0.2, "a,b": 0.5, "a,b,c": 0.3})
    m12_s = crc(m1, m2, method="sparse")
    m12_d = crc(m1, m2, method="dense")
    assert np.allclose(m12_s.dense, m12_d.dense, atol=1e-10)


# ---------------------------------------------------------------------------
# Algebraic properties
# ---------------------------------------------------------------------------

def test_crc_commutativity():
    assert np.allclose(crc(M1, M2).dense, crc(M2, M1).dense, atol=1e-10)


def test_crc_associativity():
    m3 = DSVector.from_focal(FRAME_AB, {"b": 0.4, "a,b": 0.6})
    lhs = crc(crc(M1, M2), m3)
    rhs = crc(M1, crc(M2, m3))
    assert np.allclose(lhs.dense, rhs.dense, atol=1e-10)


def test_crc_neutral_element_vacuous():
    # vacuous BBA is the neutral element
    assert np.allclose(crc(M1, VAC).dense, M1.dense, atol=1e-10)
    assert np.allclose(crc(VAC, M1).dense, M1.dense, atol=1e-10)


def test_crc_categorical_gives_empty_set():
    # m({a}) ∩ m({b}) → all mass on ∅ (full conflict)
    m12 = crc(CAT_A, CAT_B)
    assert np.isclose(m12[frozenset()], 1.0)


def test_crc_result_sums_to_one():
    m12 = crc(M1, M2)
    assert np.isclose(sum(m12.sparse.values()), 1.0)


def test_crc_result_kind_is_m():
    assert crc(M1, M2).kind == Kind.M


def test_crc_result_is_sparse():
    m12 = crc(M1, M2)
    assert isinstance(m12.sparse, dict)


# ---------------------------------------------------------------------------
# Operator &
# ---------------------------------------------------------------------------

def test_operator_and_matches_crc():
    assert np.allclose((M1 & M2).dense, crc(M1, M2).dense, atol=1e-10)


def test_operator_and_commutativity():
    assert np.allclose((M1 & M2).dense, (M2 & M1).dense, atol=1e-10)


# ---------------------------------------------------------------------------
# Validation errors
# ---------------------------------------------------------------------------

def test_crc_wrong_kind_raises():
    bel = M1.to_bel()
    with pytest.raises(ValueError, match="kind"):
        crc(bel, M2)


def test_crc_mismatched_frames_raises():
    m_other = DSVector.from_focal(FRAME_ABC, {"a": 0.5, "a,b,c": 0.5})
    with pytest.raises(ValueError, match="frames"):
        crc(M1, m_other)


def test_crc_unknown_method_raises():
    with pytest.raises(ValueError, match="Unknown method"):
        crc(M1, M2, method="fmt")


# ===========================================================================
# Dempster's rule
# ===========================================================================

from evtools.combinations import dempster

def test_dempster_normalizes():
    m12 = dempster(M1, M2)
    assert np.isclose(m12[frozenset()], 0.0)
    assert np.isclose(sum(m12.sparse.values()), 1.0)


def test_dempster_matches_crc_normalized():
    m12_crc = crc(M1, M2)
    conflict = m12_crc[frozenset()]
    k = 1.0 / (1.0 - conflict)
    m12_d = dempster(M1, M2)
    for subset, value in m12_crc.sparse.items():
        if subset != frozenset():
            assert np.isclose(m12_d[subset], value * k, atol=1e-10)


def test_dempster_total_conflict_raises():
    with pytest.raises(ValueError, match="fully contradictory"):
        dempster(CAT_A, CAT_B)


def test_dempster_operator():
    assert np.allclose((M1 @ M2).dense, dempster(M1, M2).dense, atol=1e-10)


def test_dempster_commutativity():
    assert np.allclose(dempster(M1, M2).dense, dempster(M2, M1).dense, atol=1e-10)


def test_dempster_sparse_dense_match():
    assert np.allclose(
        dempster(M1, M2, method="sparse").dense,
        dempster(M1, M2, method="dense").dense,
        atol=1e-10,
    )


# ===========================================================================
# DRC
# ===========================================================================

from evtools.combinations import drc

def test_drc_sparse_known_result():
    # m12(A) = Σ_{B∪C=A} m1(B)·m2(C)
    # B={a},   C={a}   → A={a}:   0.3*0.5=0.15
    # B={a},   C={b}   → A={a,b}: 0.3*0.3=0.09
    # B={a},   C={a,b} → A={a,b}: 0.3*0.2=0.06
    # B={a,b}, C={a}   → A={a,b}: 0.7*0.5=0.35
    # B={a,b}, C={b}   → A={a,b}: 0.7*0.3=0.21
    # B={a,b}, C={a,b} → A={a,b}: 0.7*0.2=0.14
    m12 = drc(M1, M2)
    assert np.isclose(m12[frozenset({"a"})],     0.15)
    assert np.isclose(m12[frozenset({"a", "b"})], 0.09 + 0.06 + 0.35 + 0.21 + 0.14)
    assert np.isclose(sum(m12.sparse.values()), 1.0)


def test_drc_sparse_dense_match():
    assert np.allclose(
        drc(M1, M2, method="sparse").dense,
        drc(M1, M2, method="dense").dense,
        atol=1e-10,
    )


def test_drc_commutativity():
    assert np.allclose(drc(M1, M2).dense, drc(M2, M1).dense, atol=1e-10)


def test_drc_associativity():
    m3 = DSVector.from_focal(FRAME_AB, {"b": 0.4, "a,b": 0.6})
    assert np.allclose(
        drc(drc(M1, M2), m3).dense,
        drc(M1, drc(M2, m3)).dense,
        atol=1e-10,
    )


def test_drc_operator():
    assert np.allclose((M1 | M2).dense, drc(M1, M2).dense, atol=1e-10)


def test_drc_result_sums_to_one():
    assert np.isclose(sum(drc(M1, M2).sparse.values()), 1.0)


# ===========================================================================
# Cautious rule
# ===========================================================================

from evtools.combinations import cautious

# Nondogmatic BBAs (m(Ω) > 0)
M1_ND = DSVector.from_focal(FRAME_AB, {"a": 0.3, "b": 0.3, "a,b": 0.4})
M2_ND = DSVector.from_focal(FRAME_AB, {"a": 0.4, "b": 0.2, "a,b": 0.4})


def test_cautious_commutativity():
    assert np.allclose(cautious(M1_ND, M2_ND).dense, cautious(M2_ND, M1_ND).dense, atol=1e-10)


def test_cautious_idempotent():
    assert np.allclose(cautious(M1_ND, M1_ND).dense, M1_ND.dense, atol=1e-10)


def test_cautious_associativity():
    M3_ND = DSVector.from_focal(FRAME_AB, {"a": 0.2, "b": 0.5, "a,b": 0.3})
    assert np.allclose(
        cautious(cautious(M1_ND, M2_ND), M3_ND).dense,
        cautious(M1_ND, cautious(M2_ND, M3_ND)).dense,
        atol=1e-10,
    )


def test_cautious_dogmatic_raises():
    m_dog = DSVector.from_focal(FRAME_AB, {"a": 0.6, "b": 0.4}, complete=False)
    with pytest.raises(ValueError, match="dogmatic"):
        cautious(m_dog, M2_ND)


def test_cautious_result_kind_m():
    assert cautious(M1_ND, M2_ND).kind == Kind.M


# ===========================================================================
# Bold rule
# ===========================================================================

from evtools.combinations import bold

# Subnormal BBAs (m(∅) > 0)
M1_SUB = DSVector.from_focal(FRAME_AB, {"": 0.1, "a": 0.4, "a,b": 0.5}, complete=False)
M2_SUB = DSVector.from_focal(FRAME_AB, {"": 0.2, "b": 0.3, "a,b": 0.5}, complete=False)


def test_bold_commutativity():
    assert np.allclose(bold(M1_SUB, M2_SUB).dense, bold(M2_SUB, M1_SUB).dense, atol=1e-10)


def test_bold_idempotent():
    assert np.allclose(bold(M1_SUB, M1_SUB).dense, M1_SUB.dense, atol=1e-10)


def test_bold_normal_raises():
    with pytest.raises(ValueError, match="normal"):
        bold(M1, M2_SUB)


def test_bold_result_kind_m():
    assert bold(M1_SUB, M2_SUB).kind == Kind.M


def test_bold_result_sums_to_one():
    assert np.isclose(sum(bold(M1_SUB, M2_SUB).sparse.values()), 1.0)


# ===========================================================================
# decombine_crc and decombine_drc
# ===========================================================================

from evtools.combinations import decombine_crc, decombine_drc

M1_C = DSVector.from_focal(FRAME_AHR, {"a": 0.4, "a,h,r": 0.6})
M2_C = DSVector.from_focal(FRAME_AHR, {"h": 0.3, "a,h,r": 0.7})
M1_D = DSVector.from_focal(FRAME_AHR, {"": 0.1, "a": 0.4, "a,h,r": 0.5}, complete=False)
M2_D = DSVector.from_focal(FRAME_AHR, {"": 0.2, "h": 0.3, "a,h,r": 0.5}, complete=False)


def test_decombine_crc_inverts_crc():
    from evtools.combinations import crc
    m12 = crc(M1_C, M2_C)
    recovered = decombine_crc(m12, M2_C)
    assert recovered.is_valid
    assert np.allclose(recovered.dense, M1_C.dense, atol=1e-6)


def test_decombine_drc_inverts_drc():
    from evtools.combinations import drc
    m12 = drc(M1_D, M2_D)
    recovered = decombine_drc(m12, M2_D)
    assert recovered.is_valid
    assert np.allclose(recovered.dense, M1_D.dense, atol=1e-6)


def test_decombine_crc_dogmatic_raises():
    m_dog = DSVector.from_focal(FRAME_AHR, {"a": 0.5, "h": 0.5}, complete=False)
    m12 = DSVector.from_focal(FRAME_AHR, {"a": 0.3, "a,h,r": 0.7})
    with pytest.raises(ValueError, match="dogmatic"):
        decombine_crc(m12, m_dog)


def test_decombine_drc_normal_raises():
    m_normal = DSVector.from_focal(FRAME_AHR, {"a": 0.5, "a,h,r": 0.5})
    m12 = DSVector.from_focal(FRAME_AHR, {"": 0.1, "a": 0.4, "a,h,r": 0.5}, complete=False)
    with pytest.raises(ValueError, match="normal"):
        decombine_drc(m12, m_normal)


def test_decombine_crc_kind_m():
    from evtools.combinations import crc
    assert decombine_crc(crc(M1_C, M2_C), M2_C).kind == Kind.M


def test_decombine_drc_kind_m():
    from evtools.combinations import drc
    assert decombine_drc(drc(M1_D, M2_D), M2_D).kind == Kind.M


# ===========================================================================
# DSVector.simple and DSVector.negative_simple
# ===========================================================================

def test_simple_mf_focal_sets():
    s = DSVector.simple(FRAME_AHR, frozenset({"a"}), beta=0.6)
    assert np.isclose(s[frozenset({"a","h","r"})], 0.6)
    assert np.isclose(s[frozenset({"a"})],          0.4)
    assert np.isclose(sum(s.sparse.values()),        1.0)


def test_simple_mf_beta1_vacuous():
    s = DSVector.simple(FRAME_AHR, frozenset({"a"}), beta=1.0)
    assert np.isclose(s[frozenset({"a","h","r"})], 1.0)


def test_simple_mf_beta0_categorical():
    s = DSVector.simple(FRAME_AHR, frozenset({"a"}), beta=0.0)
    assert np.isclose(s[frozenset({"a"})], 1.0)


def test_negative_simple_mf_focal_sets():
    ns = DSVector.negative_simple(FRAME_AHR, frozenset({"a"}), beta=0.4)
    assert np.isclose(ns[frozenset()],      0.4)
    assert np.isclose(ns[frozenset({"a"})], 0.6)
    assert np.isclose(sum(ns.sparse.values()), 1.0)


def test_negative_simple_mf_beta0_categorical():
    ns = DSVector.negative_simple(FRAME_AHR, frozenset({"a"}), beta=0.0)
    assert np.isclose(ns[frozenset({"a"})], 1.0)


def test_simple_beta_out_of_range_raises():
    with pytest.raises(ValueError, match="beta"):
        DSVector.simple(FRAME_AHR, frozenset({"a"}), beta=1.5)


def test_negative_simple_beta_out_of_range_raises():
    with pytest.raises(ValueError, match="beta"):
        DSVector.negative_simple(FRAME_AHR, frozenset({"a"}), beta=-0.1)


# ===========================================================================
# condition and decondition
# ===========================================================================

from evtools.combinations import condition, decondition
from evtools.conversions import conditioning_matrix, deconditioning_matrix

FRAME_AHR_C = ["a", "h", "r"]

# m({a})=0.3, m({h})=0.2, m({a,h})=0.1, m({a,h,r})=0.4
M_COND = DSVector.from_focal(FRAME_AHR_C, {"a": 0.3, "h": 0.2, "a,h": 0.1, "a,h,r": 0.4})
A_AH   = frozenset({"a", "h"})


class TestCondition:

    def test_known_result(self):
        # m[{a,h}]({a})   = m({a})               = 0.3
        # m[{a,h}]({h})   = m({h})               = 0.2
        # m[{a,h}]({a,h}) = m({a,h}) + m({a,h,r})= 0.1 + 0.4 = 0.5
        m_c = condition(M_COND, A_AH)
        assert np.isclose(m_c[frozenset({"a"})],     0.3)
        assert np.isclose(m_c[frozenset({"h"})],     0.2)
        assert np.isclose(m_c[frozenset({"a","h"})], 0.5)

    def test_sums_to_one(self):
        assert np.isclose(sum(condition(M_COND, A_AH).sparse.values()), 1.0)

    def test_no_focal_outside_A(self):
        m_c = condition(M_COND, A_AH)
        for subset in m_c.sparse:
            assert subset <= A_AH or subset == frozenset(), \
                f"Focal element {set(subset)} not in A∪{{∅}}"

    def test_sparse_dense_match(self):
        assert np.allclose(
            condition(M_COND, A_AH, method="sparse").dense,
            condition(M_COND, A_AH, method="dense").dense,
            atol=1e-10
        )

    def test_dense_equals_matrix_product(self):
        CA = conditioning_matrix(FRAME_AHR_C, A_AH)
        m_matrix = DSVector.from_dense(FRAME_AHR_C, CA @ M_COND.dense)
        assert np.allclose(
            m_matrix.dense,
            condition(M_COND, A_AH, method="sparse").dense,
            atol=1e-10
        )

    def test_condition_on_omega_unchanged(self):
        omega = frozenset(FRAME_AHR_C)
        assert np.allclose(condition(M_COND, omega).dense, M_COND.dense, atol=1e-10)

    def test_empty_A_raises(self):
        with pytest.raises(ValueError, match="empty"):
            condition(M_COND, frozenset())

    def test_unknown_atom_raises(self):
        with pytest.raises(ValueError, match="frame"):
            condition(M_COND, frozenset({"z"}))

    def test_wrong_kind_raises(self):
        with pytest.raises(ValueError, match="kind"):
            condition(M_COND.to_bel(), A_AH)

    def test_kind_m(self):
        assert condition(M_COND, A_AH).kind == Kind.M


class TestDecondition:

    def test_known_result(self):
        # decondition(m[A], A): B → B ∪ Ā = B ∪ {r}
        # {a}   → {a, r}
        # {h}   → {h, r}
        # {a,h} → {a, h, r}
        m_c = condition(M_COND, A_AH)
        m_d = decondition(m_c, A_AH)
        assert np.isclose(m_d[frozenset({"a","r"})],     0.3)
        assert np.isclose(m_d[frozenset({"h","r"})],     0.2)
        assert np.isclose(m_d[frozenset({"a","h","r"})], 0.5)

    def test_sums_to_one(self):
        m_c = condition(M_COND, A_AH)
        assert np.isclose(sum(decondition(m_c, A_AH).sparse.values()), 1.0)

    def test_sparse_dense_match(self):
        m_c = condition(M_COND, A_AH)
        assert np.allclose(
            decondition(m_c, A_AH, method="sparse").dense,
            decondition(m_c, A_AH, method="dense").dense,
            atol=1e-10
        )

    def test_dense_equals_matrix_product(self):
        m_c = condition(M_COND, A_AH)
        DA = deconditioning_matrix(FRAME_AHR_C, A_AH)
        m_matrix = DSVector.from_dense(FRAME_AHR_C, DA @ m_c.dense)
        assert np.allclose(
            m_matrix.dense,
            decondition(m_c, A_AH, method="sparse").dense,
            atol=1e-10
        )

    def test_round_trip(self):
        # condition(decondition(m[A], A), A) == m[A]
        m_c = condition(M_COND, A_AH)
        assert np.allclose(
            condition(decondition(m_c, A_AH), A_AH).dense,
            m_c.dense,
            atol=1e-10
        )

    def test_empty_A_raises(self):
        with pytest.raises(ValueError, match="empty"):
            decondition(M_COND, frozenset())

    def test_kind_m(self):
        assert decondition(condition(M_COND, A_AH), A_AH).kind == Kind.M


class TestConditioningMatrices:

    def test_conditioning_matrix_shape(self):
        CA = conditioning_matrix(FRAME_AHR_C, A_AH)
        assert CA.shape == (8, 8)

    def test_deconditioning_matrix_shape(self):
        DA = deconditioning_matrix(FRAME_AHR_C, A_AH)
        assert DA.shape == (8, 8)

    def test_CA_is_specialization(self):
        # Column sums = 1 (stochastic matrix)
        CA = conditioning_matrix(FRAME_AHR_C, A_AH)
        assert np.allclose(CA.sum(axis=0), 1.0)

    def test_DA_is_generalization(self):
        # Column sums = 1 (stochastic matrix)
        DA = deconditioning_matrix(FRAME_AHR_C, A_AH)
        assert np.allclose(DA.sum(axis=0), 1.0)

    def test_CA_nonnegative(self):
        assert np.all(conditioning_matrix(FRAME_AHR_C, A_AH) >= 0)

    def test_DA_nonnegative(self):
        assert np.all(deconditioning_matrix(FRAME_AHR_C, A_AH) >= 0)

    def test_CA_DA_round_trip(self):
        # CA @ DA maps every column to the same column after repass through CA
        CA = conditioning_matrix(FRAME_AHR_C, A_AH)
        DA = deconditioning_matrix(FRAME_AHR_C, A_AH)
        # CA @ DA @ CA == CA (CA is idempotent under DA)
        assert np.allclose(CA @ DA @ CA, CA, atol=1e-10)
