from __future__ import annotations

import ctypes
from typing import Any

from ._ffi import _CORE, RtActionGoalHealth
from .models import ActionGoalHealth
from .utils import as_u8_ptr


class ActionClient:
    def __init__(self, handle: ctypes.c_void_p) -> None:
        self._handle = handle
        self._closed = False

    def send_goal(self, payload: bytes | bytearray | memoryview) -> tuple[int, bool]:
        ptr, n, _keepalive = as_u8_ptr(payload)
        goal_id = ctypes.c_uint64(0)
        accepted = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_action_client_send_goal(
            self._handle,
            ptr,
            n,
            ctypes.byref(goal_id),
            ctypes.byref(accepted),
        )
        _CORE.check(status, "robotrt_action_client_send_goal")
        return int(goal_id.value), bool(accepted.value)

    def poll_feedback(self, goal_id: int, *, cap: int = 1024 * 1024) -> bytes | None:
        buf = (ctypes.c_uint8 * cap)()
        copied = ctypes.c_uint64(0)
        has_feedback = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_action_client_poll_feedback(
            self._handle,
            int(goal_id),
            buf,
            cap,
            ctypes.byref(copied),
            ctypes.byref(has_feedback),
        )
        _CORE.check(status, "robotrt_action_client_poll_feedback")
        if has_feedback.value == 0:
            return None
        return bytes(memoryview(buf)[: copied.value])

    def poll_result(self, goal_id: int, *, cap: int = 1024 * 1024) -> dict[str, Any] | None:
        status_code = ctypes.c_int32(0)
        buf = (ctypes.c_uint8 * cap)()
        copied = ctypes.c_uint64(0)
        has_result = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_action_client_poll_result(
            self._handle,
            int(goal_id),
            ctypes.byref(status_code),
            buf,
            cap,
            ctypes.byref(copied),
            ctypes.byref(has_result),
        )
        _CORE.check(status, "robotrt_action_client_poll_result")
        if has_result.value == 0:
            return None
        return {
            "status": int(status_code.value),
            "payload": bytes(memoryview(buf)[: copied.value]),
        }

    def cancel(self, goal_id: int) -> None:
        status = _CORE.lib.robotrt_action_client_cancel(self._handle, int(goal_id))
        _CORE.check(status, "robotrt_action_client_cancel")

    def goal_status(self, goal_id: int) -> int | None:
        status_code = ctypes.c_int32(0)
        has_status = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_action_client_goal_status(
            self._handle,
            int(goal_id),
            ctypes.byref(status_code),
            ctypes.byref(has_status),
        )
        _CORE.check(status, "robotrt_action_client_goal_status")
        if has_status.value == 0:
            return None
        return int(status_code.value)

    @staticmethod
    def _convert_health(raw: RtActionGoalHealth) -> ActionGoalHealth:
        return ActionGoalHealth(
            goal_id=int(raw.goal_id),
            status=int(raw.status),
            liveness=int(raw.liveness),
            heartbeat_timeout_nanos=int(raw.heartbeat_timeout_nanos) if raw.has_heartbeat_timeout else None,
            stalled_threshold_nanos=int(raw.stalled_threshold_nanos) if raw.has_stalled_threshold else None,
            last_heartbeat_at_unix_nanos=int(raw.last_heartbeat_at_unix_nanos) if raw.has_last_heartbeat else None,
            last_feedback_at_unix_nanos=int(raw.last_feedback_at_unix_nanos) if raw.has_last_feedback else None,
            last_result_at_unix_nanos=int(raw.last_result_at_unix_nanos) if raw.has_last_result else None,
        )

    def goal_health(self, goal_id: int) -> ActionGoalHealth | None:
        raw = RtActionGoalHealth()
        has_health = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_action_client_goal_health(
            self._handle,
            int(goal_id),
            ctypes.byref(raw),
            ctypes.byref(has_health),
        )
        _CORE.check(status, "robotrt_action_client_goal_health")
        if has_health.value == 0:
            return None
        return self._convert_health(raw)

    def active_goal_health(self) -> list[ActionGoalHealth]:
        copied = ctypes.c_uint64(0)
        status = _CORE.lib.robotrt_action_client_active_goal_health(
            self._handle,
            None,
            0,
            ctypes.byref(copied),
        )
        _CORE.check(status, "robotrt_action_client_active_goal_health(size)")
        if copied.value == 0:
            return []

        arr_type = RtActionGoalHealth * int(copied.value)
        raw_items = arr_type()
        status = _CORE.lib.robotrt_action_client_active_goal_health(
            self._handle,
            raw_items,
            int(copied.value),
            ctypes.byref(copied),
        )
        _CORE.check(status, "robotrt_action_client_active_goal_health(read)")
        return [self._convert_health(item) for item in raw_items[: int(copied.value)]]

    def tick_timeouts(self, *, now_unix_nanos: int = 0) -> int:
        transitioned = ctypes.c_uint32(0)
        status = _CORE.lib.robotrt_action_client_tick_timeouts(
            self._handle,
            int(now_unix_nanos),
            ctypes.byref(transitioned),
        )
        _CORE.check(status, "robotrt_action_client_tick_timeouts")
        return int(transitioned.value)

    def close(self) -> None:
        if self._closed:
            return
        status = _CORE.lib.robotrt_action_client_destroy(self._handle)
        _CORE.check(status, "robotrt_action_client_destroy")
        self._closed = True

    def __enter__(self) -> "ActionClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass


class ActionServer:
    def __init__(self, handle: ctypes.c_void_p) -> None:
        self._handle = handle
        self._closed = False

    def recv_goal(self, *, cap: int = 1024 * 1024) -> tuple[int, bytes] | None:
        goal_id = ctypes.c_uint64(0)
        buf = (ctypes.c_uint8 * cap)()
        copied = ctypes.c_uint64(0)
        has_goal = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_action_server_recv_goal(
            self._handle,
            ctypes.byref(goal_id),
            buf,
            cap,
            ctypes.byref(copied),
            ctypes.byref(has_goal),
        )
        _CORE.check(status, "robotrt_action_server_recv_goal")
        if has_goal.value == 0:
            return None
        return int(goal_id.value), bytes(memoryview(buf)[: copied.value])

    def accept_goal(self, goal_id: int) -> None:
        status = _CORE.lib.robotrt_action_server_accept_goal(self._handle, int(goal_id))
        _CORE.check(status, "robotrt_action_server_accept_goal")

    def reject_goal(self, goal_id: int, reason: str) -> None:
        status = _CORE.lib.robotrt_action_server_reject_goal(self._handle, int(goal_id), reason.encode("utf-8"))
        _CORE.check(status, "robotrt_action_server_reject_goal")

    def publish_feedback(self, goal_id: int, payload: bytes | bytearray | memoryview) -> None:
        ptr, n, _keepalive = as_u8_ptr(payload)
        status = _CORE.lib.robotrt_action_server_publish_feedback(self._handle, int(goal_id), ptr, n)
        _CORE.check(status, "robotrt_action_server_publish_feedback")

    def heartbeat(self, goal_id: int) -> None:
        status = _CORE.lib.robotrt_action_server_heartbeat(self._handle, int(goal_id))
        _CORE.check(status, "robotrt_action_server_heartbeat")

    def succeed(self, goal_id: int, payload: bytes | bytearray | memoryview) -> None:
        ptr, n, _keepalive = as_u8_ptr(payload)
        status = _CORE.lib.robotrt_action_server_succeed(self._handle, int(goal_id), ptr, n)
        _CORE.check(status, "robotrt_action_server_succeed")

    def fail(self, goal_id: int, reason: str) -> None:
        status = _CORE.lib.robotrt_action_server_fail(self._handle, int(goal_id), reason.encode("utf-8"))
        _CORE.check(status, "robotrt_action_server_fail")

    def poll_cancel(self) -> int | None:
        goal_id = ctypes.c_uint64(0)
        has_cancel = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_action_server_poll_cancel(
            self._handle,
            ctypes.byref(goal_id),
            ctypes.byref(has_cancel),
        )
        _CORE.check(status, "robotrt_action_server_poll_cancel")
        if has_cancel.value == 0:
            return None
        return int(goal_id.value)

    def confirm_cancel(self, goal_id: int) -> None:
        status = _CORE.lib.robotrt_action_server_confirm_cancel(self._handle, int(goal_id))
        _CORE.check(status, "robotrt_action_server_confirm_cancel")

    def close(self) -> None:
        if self._closed:
            return
        status = _CORE.lib.robotrt_action_server_destroy(self._handle)
        _CORE.check(status, "robotrt_action_server_destroy")
        self._closed = True

    def __enter__(self) -> "ActionServer":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass
