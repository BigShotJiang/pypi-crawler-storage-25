from __future__ import annotations

import ctypes
import os
import platform
from pathlib import Path

from ._ffi_signatures import declare_signatures
from ._ffi_types import RT_OK, RtErrorInfo
from .errors import ErrorInfo, RobotRtError


def _workspace_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _dylib_name() -> str:
    name = platform.system().lower()
    if name == "darwin":
        return "librobotrt_core_ffi.dylib"
    if name == "windows":
        return "robotrt_core_ffi.dll"
    return "librobotrt_core_ffi.so"


def _resolve_library_path() -> Path:
    env = os.environ.get("ROBOTRT_CORE_FFI_LIB")
    if env:
        p = Path(env).expanduser().resolve()
        if p.exists():
            return p
        raise FileNotFoundError(f"ROBOTRT_CORE_FFI_LIB does not exist: {p}")

    root = _workspace_root()
    direct = root / "target" / "debug" / _dylib_name()
    if direct.exists():
        return direct

    deps = root / "target" / "debug" / "deps"
    if deps.exists():
        suffixes = {".dylib", ".so", ".dll"}
        for candidate in sorted(deps.iterdir()):
            if candidate.suffix not in suffixes:
                continue
            if candidate.name.startswith("librobotrt_core_ffi") or candidate.name == _dylib_name():
                return candidate

    raise FileNotFoundError("robotrt core ffi dynamic library not found; run cargo build -p core-ffi --lib")


class CoreFfi:
    def __init__(self) -> None:
        self.library_path = _resolve_library_path()
        self.lib = ctypes.CDLL(str(self.library_path))
        declare_signatures(self.lib)

    def last_error(self) -> ErrorInfo:
        info = RtErrorInfo()
        self.lib.robotrt_error_last(ctypes.byref(info))

        needed = ctypes.c_uint32(0)
        self.lib.robotrt_error_message_copy(None, 0, ctypes.byref(needed))
        message = ""
        if needed.value > 0:
            buf = ctypes.create_string_buffer(needed.value)
            self.lib.robotrt_error_message_copy(buf, needed.value, ctypes.byref(needed))
            message = buf.value.decode("utf-8", errors="replace")

        return ErrorInfo(
            code=int(info.code),
            domain=int(info.domain),
            retryable=bool(info.retryable),
            message=message,
        )

    def check(self, status: int, context: str) -> None:
        if status == RT_OK:
            return
        raise RobotRtError(self.last_error(), context)


_CORE = CoreFfi()
