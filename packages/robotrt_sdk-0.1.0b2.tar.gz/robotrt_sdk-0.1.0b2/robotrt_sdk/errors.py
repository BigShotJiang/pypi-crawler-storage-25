from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ErrorInfo:
    code: int
    domain: int
    retryable: bool
    message: str


class RobotRtError(RuntimeError):
    def __init__(self, info: ErrorInfo, context: str | None = None) -> None:
        self.info = info
        prefix = f"{context}: " if context else ""
        super().__init__(
            f"{prefix}code={info.code} domain={info.domain} retryable={int(info.retryable)} message={info.message}"
        )
