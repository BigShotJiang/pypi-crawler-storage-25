from __future__ import annotations

import ctypes
import json
from typing import Any

from ._ffi import _CORE


class Node:
    def __init__(
        self,
        handle: ctypes.c_void_p,
        *,
        name: str | None = None,
        namespace: str | None = None,
    ) -> None:
        self._handle = handle
        self._closed = False
        self._name = name or ""
        self._namespace = namespace or ""

    @classmethod
    def create(
        cls,
        name: str | None = None,
        namespace: str | None = None,
    ) -> "Node":
        out = ctypes.c_void_p()
        name_buf = None if name is None else name.encode("utf-8")
        namespace_buf = None if namespace is None else namespace.encode("utf-8")

        status = _CORE.lib.robotrt_node_create_with_identity(
            name_buf,
            namespace_buf,
            ctypes.byref(out),
        )
        _CORE.check(status, "robotrt_node_create_with_identity")
        return cls(out, name=name, namespace=namespace)

    def name(self) -> str:
        if self._name:
            return self._name
        value = self.get_param("robotrt.node.name")
        return value or ""

    def namespace(self) -> str:
        if self._namespace:
            return self._namespace
        value = self.get_param("robotrt.node.namespace")
        return value or ""

    def close(self) -> None:
        if self._closed:
            return
        status = _CORE.lib.robotrt_node_destroy(self._handle)
        _CORE.check(status, "robotrt_node_destroy")
        self._closed = True

    def declare_param(self, key: str, value: str) -> None:
        status = _CORE.lib.robotrt_node_set_param(
            self._handle,
            key.encode("utf-8"),
            value.encode("utf-8"),
        )
        _CORE.check(status, "robotrt_node_set_param")

    def get_param(self, key: str) -> str | None:
        needed = ctypes.c_uint32(0)
        has_value = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_node_get_param_copy(
            self._handle,
            key.encode("utf-8"),
            None,
            0,
            ctypes.byref(needed),
            ctypes.byref(has_value),
        )
        _CORE.check(status, "robotrt_node_get_param_copy(size)")
        if has_value.value == 0:
            return None

        buf = ctypes.create_string_buffer(max(int(needed.value), 2))
        has_value2 = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_node_get_param_copy(
            self._handle,
            key.encode("utf-8"),
            ctypes.cast(buf, ctypes.c_void_p),
            len(buf),
            ctypes.byref(needed),
            ctypes.byref(has_value2),
        )
        _CORE.check(status, "robotrt_node_get_param_copy(read)")
        if has_value2.value == 0:
            return None
        return buf.value.decode("utf-8")

    def discovery_snapshot(self) -> dict[str, Any]:
        needed = ctypes.c_uint32(0)
        status = _CORE.lib.robotrt_node_discovery_snapshot_json_copy(
            self._handle,
            None,
            0,
            ctypes.byref(needed),
        )
        _CORE.check(status, "robotrt_node_discovery_snapshot_json_copy(size)")
        buf = ctypes.create_string_buffer(max(int(needed.value), 2))
        status = _CORE.lib.robotrt_node_discovery_snapshot_json_copy(
            self._handle,
            ctypes.cast(buf, ctypes.c_void_p),
            len(buf),
            ctypes.byref(needed),
        )
        _CORE.check(status, "robotrt_node_discovery_snapshot_json_copy(read)")
        return json.loads(buf.value.decode("utf-8"))

    def topic_qos(self, topic: str) -> dict[str, Any] | None:
        reliable = ctypes.c_uint8(0)
        depth = ctypes.c_uint64(0)
        has_profile = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_node_topic_qos(
            self._handle,
            topic.encode("utf-8"),
            ctypes.byref(reliable),
            ctypes.byref(depth),
            ctypes.byref(has_profile),
        )
        _CORE.check(status, "robotrt_node_topic_qos")
        if has_profile.value == 0:
            return None
        return {
            "reliable": bool(reliable.value),
            "depth": int(depth.value),
        }

    def create_publisher(self, topic: str) -> "Publisher":
        from .pubsub import Publisher

        out = ctypes.c_void_p()
        status = _CORE.lib.robotrt_publisher_create(self._handle, topic.encode("utf-8"), ctypes.byref(out))
        _CORE.check(status, "robotrt_publisher_create")
        qos = self.topic_qos(topic)
        depth = int(qos["depth"]) if qos is not None else 16
        return Publisher(out, qos_depth_hint=depth)

    def create_subscriber(self, topic: str) -> "Subscriber":
        from .pubsub import Subscriber

        out = ctypes.c_void_p()
        status = _CORE.lib.robotrt_subscriber_create(self._handle, topic.encode("utf-8"), ctypes.byref(out))
        _CORE.check(status, "robotrt_subscriber_create")
        qos = self.topic_qos(topic)
        depth = int(qos["depth"]) if qos is not None else 16
        return Subscriber(out, qos_depth_hint=depth)

    def create_service_client(self, service_name: str) -> "ServiceClient":
        from .service import ServiceClient

        out = ctypes.c_void_p()
        status = _CORE.lib.robotrt_service_client_create(self._handle, service_name.encode("utf-8"), ctypes.byref(out))
        _CORE.check(status, "robotrt_service_client_create")
        return ServiceClient(out)

    def create_service_server(self, service_name: str) -> "ServiceServer":
        from .service import ServiceServer

        out = ctypes.c_void_p()
        status = _CORE.lib.robotrt_service_server_create(self._handle, service_name.encode("utf-8"), ctypes.byref(out))
        _CORE.check(status, "robotrt_service_server_create")
        return ServiceServer(out)

    def create_action_client(self, action_name: str) -> "ActionClient":
        from .action import ActionClient

        out = ctypes.c_void_p()
        status = _CORE.lib.robotrt_action_client_create(self._handle, action_name.encode("utf-8"), ctypes.byref(out))
        _CORE.check(status, "robotrt_action_client_create")
        return ActionClient(out)

    def create_action_server(self, action_name: str) -> "ActionServer":
        from .action import ActionServer

        out = ctypes.c_void_p()
        status = _CORE.lib.robotrt_action_server_create(self._handle, action_name.encode("utf-8"), ctypes.byref(out))
        _CORE.check(status, "robotrt_action_server_create")
        return ActionServer(out)

    def create_mission_session(self, mission_id: int) -> "MissionSession":
        from .mission import MissionSession

        out = ctypes.c_void_p()
        status = _CORE.lib.robotrt_mission_create(self._handle, int(mission_id), ctypes.byref(out))
        _CORE.check(status, "robotrt_mission_create")
        return MissionSession(out)

    def __enter__(self) -> "Node":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass
