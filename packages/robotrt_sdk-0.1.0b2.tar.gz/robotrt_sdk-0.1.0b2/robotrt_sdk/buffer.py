from __future__ import annotations

import ctypes

from ._ffi import _CORE, RtBufferDescriptor
from .models import BufferDescriptor
from .utils import LeaseView


class BufferLease:
    def __init__(self, handle: ctypes.c_void_p) -> None:
        self._handle = handle
        self._released = False

    @classmethod
    def from_bytes(cls, payload: bytes | bytearray | memoryview) -> "BufferLease":
        view = memoryview(payload).cast("B")
        out = ctypes.c_void_p()

        if len(view) == 0:
            ptr = ctypes.POINTER(ctypes.c_uint8)()
        else:
            ptr = (ctypes.c_uint8 * len(view)).from_buffer_copy(view)

        status = _CORE.lib.robotrt_buffer_lease_create_from_bytes(
            ptr,
            len(view),
            ctypes.byref(out),
        )
        _CORE.check(status, "robotrt_buffer_lease_create_from_bytes")
        return cls(out)

    @classmethod
    def open(cls, descriptor: BufferDescriptor) -> "BufferLease":
        raw = RtBufferDescriptor(
            lease_id=descriptor.lease_id,
            payload_len=descriptor.payload_len,
            segment_index=descriptor.segment_index,
            segment_offset=descriptor.segment_offset,
            segment_capacity=descriptor.segment_capacity,
            flags=descriptor.flags,
        )
        out = ctypes.c_void_p()
        status = _CORE.lib.robotrt_buffer_lease_open_from_descriptor(ctypes.byref(raw), ctypes.byref(out))
        _CORE.check(status, "robotrt_buffer_lease_open_from_descriptor")
        return cls(out)

    def descriptor(self) -> BufferDescriptor:
        raw = RtBufferDescriptor()
        status = _CORE.lib.robotrt_buffer_lease_descriptor(self._handle, ctypes.byref(raw))
        _CORE.check(status, "robotrt_buffer_lease_descriptor")
        return BufferDescriptor(
            lease_id=int(raw.lease_id),
            payload_len=int(raw.payload_len),
            segment_index=int(raw.segment_index),
            segment_offset=int(raw.segment_offset),
            segment_capacity=int(raw.segment_capacity),
            flags=int(raw.flags),
        )

    def read_bytes(self, offset: int = 0, size: int | None = None) -> bytes:
        desc = self.descriptor()
        if offset < 0 or offset > desc.payload_len:
            raise ValueError("offset out of range")
        max_len = desc.payload_len - offset
        read_len = max_len if size is None else min(max_len, max(0, size))

        if read_len == 0:
            return b""

        buf = (ctypes.c_uint8 * read_len)()
        copied = ctypes.c_uint64(0)
        status = _CORE.lib.robotrt_buffer_lease_copy_bytes(
            self._handle,
            offset,
            buf,
            read_len,
            ctypes.byref(copied),
        )
        _CORE.check(status, "robotrt_buffer_lease_copy_bytes")
        return bytes(memoryview(buf)[: copied.value])

    def borrow_readonly(self) -> LeaseView:
        data_ptr = ctypes.POINTER(ctypes.c_uint8)()
        length = ctypes.c_uint64(0)
        status = _CORE.lib.robotrt_buffer_lease_borrow_readonly(
            self._handle,
            ctypes.byref(data_ptr),
            ctypes.byref(length),
        )
        _CORE.check(status, "robotrt_buffer_lease_borrow_readonly")

        if length.value == 0:
            address = ctypes.addressof((ctypes.c_uint8 * 0)())
        else:
            address = ctypes.addressof(data_ptr.contents)
        return LeaseView(self, address, int(length.value))

    def release(self) -> None:
        if self._released:
            return
        status = _CORE.lib.robotrt_buffer_lease_release(self._handle)
        _CORE.check(status, "robotrt_buffer_lease_release")
        self._released = True

    def __enter__(self) -> "BufferLease":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.release()

    def __del__(self) -> None:
        try:
            self.release()
        except Exception:
            pass
