from __future__ import annotations

import ctypes
import json
from typing import Any

from ._ffi import _CORE


class MissionSession:
    def __init__(self, handle: ctypes.c_void_p) -> None:
        self._handle = handle
        self._closed = False

    def open(self, name: str) -> None:
        status = _CORE.lib.robotrt_mission_open(self._handle, name.encode("utf-8"))
        _CORE.check(status, "robotrt_mission_open")

    def send_command(self, command: str) -> bool:
        accepted = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_mission_send_command(
            self._handle,
            command.encode("utf-8"),
            ctypes.byref(accepted),
        )
        _CORE.check(status, "robotrt_mission_send_command")
        return bool(accepted.value)

    def reconcile(self, checkpoint: str, pending_commands: int) -> None:
        status = _CORE.lib.robotrt_mission_reconcile(
            self._handle,
            checkpoint.encode("utf-8"),
            int(pending_commands),
        )
        _CORE.check(status, "robotrt_mission_reconcile")

    def complete_replay(self, replayed_commands: int) -> None:
        status = _CORE.lib.robotrt_mission_complete_replay(self._handle, int(replayed_commands))
        _CORE.check(status, "robotrt_mission_complete_replay")

    def send_update_text(self, text: str) -> None:
        status = _CORE.lib.robotrt_mission_send_update_text(self._handle, text.encode("utf-8"))
        _CORE.check(status, "robotrt_mission_send_update_text")

    def send_update(self, update: dict[str, Any] | str) -> None:
        payload = update if isinstance(update, str) else json.dumps(update, separators=(",", ":"))
        status = _CORE.lib.robotrt_mission_send_update_json(
            self._handle,
            payload.encode("utf-8"),
        )
        _CORE.check(status, "robotrt_mission_send_update_json")

    def heartbeat(self) -> None:
        status = _CORE.lib.robotrt_mission_heartbeat(self._handle)
        _CORE.check(status, "robotrt_mission_heartbeat")

    def next_update(self) -> dict[str, Any] | None:
        needed = ctypes.c_uint32(0)
        has_update = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_mission_next_update_json(
            self._handle,
            None,
            0,
            ctypes.byref(needed),
            ctypes.byref(has_update),
        )
        _CORE.check(status, "robotrt_mission_next_update_json(size)")
        if has_update.value == 0:
            return None

        buf = ctypes.create_string_buffer(max(needed.value, 2))
        has_update2 = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_mission_next_update_json(
            self._handle,
            ctypes.cast(buf, ctypes.c_void_p),
            len(buf),
            ctypes.byref(needed),
            ctypes.byref(has_update2),
        )
        _CORE.check(status, "robotrt_mission_next_update_json(read)")
        if has_update2.value == 0:
            return None
        return json.loads(buf.value.decode("utf-8"))

    def close(self) -> None:
        if self._closed:
            return
        status = _CORE.lib.robotrt_mission_destroy(self._handle)
        _CORE.check(status, "robotrt_mission_destroy")
        self._closed = True

    def __enter__(self) -> "MissionSession":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass
