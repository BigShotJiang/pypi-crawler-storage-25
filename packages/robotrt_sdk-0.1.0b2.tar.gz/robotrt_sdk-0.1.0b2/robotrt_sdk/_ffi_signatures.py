from __future__ import annotations

import ctypes

from ._ffi_types import RtActionGoalHealth, RtBufferDescriptor, RtErrorInfo, RtExternalBufferRef


def declare_signatures(lib: ctypes.CDLL) -> None:
    lib.robotrt_core_abi_version.argtypes = []
    lib.robotrt_core_abi_version.restype = ctypes.c_uint32

    lib.robotrt_core_protocol_version.argtypes = []
    lib.robotrt_core_protocol_version.restype = ctypes.c_uint32

    lib.robotrt_node_create.argtypes = [ctypes.POINTER(ctypes.c_void_p)]
    lib.robotrt_node_create.restype = ctypes.c_int32

    lib.robotrt_node_create_with_identity.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.POINTER(ctypes.c_void_p),
    ]
    lib.robotrt_node_create_with_identity.restype = ctypes.c_int32

    lib.robotrt_node_destroy.argtypes = [ctypes.c_void_p]
    lib.robotrt_node_destroy.restype = ctypes.c_int32

    lib.robotrt_node_set_param.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_char_p]
    lib.robotrt_node_set_param.restype = ctypes.c_int32

    lib.robotrt_node_get_param_copy.argtypes = [
        ctypes.c_void_p,
        ctypes.c_char_p,
        ctypes.c_void_p,
        ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint32),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    lib.robotrt_node_get_param_copy.restype = ctypes.c_int32

    lib.robotrt_node_discovery_snapshot_json_copy.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint32),
    ]
    lib.robotrt_node_discovery_snapshot_json_copy.restype = ctypes.c_int32

    lib.robotrt_node_topic_qos.argtypes = [
        ctypes.c_void_p,
        ctypes.c_char_p,
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    lib.robotrt_node_topic_qos.restype = ctypes.c_int32

    lib.robotrt_publisher_create.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
    lib.robotrt_publisher_create.restype = ctypes.c_int32

    lib.robotrt_publisher_publish.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint8), ctypes.c_uint64]
    lib.robotrt_publisher_publish.restype = ctypes.c_int32

    lib.robotrt_publisher_publish_buffer.argtypes = [ctypes.c_void_p, ctypes.POINTER(RtExternalBufferRef)]
    lib.robotrt_publisher_publish_buffer.restype = ctypes.c_int32

    lib.robotrt_publisher_flush.argtypes = [ctypes.c_void_p]
    lib.robotrt_publisher_flush.restype = ctypes.c_int32

    lib.robotrt_publisher_destroy.argtypes = [ctypes.c_void_p]
    lib.robotrt_publisher_destroy.restype = ctypes.c_int32

    lib.robotrt_subscriber_create.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
    lib.robotrt_subscriber_create.restype = ctypes.c_int32

    lib.robotrt_subscriber_recv.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    lib.robotrt_subscriber_recv.restype = ctypes.c_int32

    lib.robotrt_subscriber_ack.argtypes = [ctypes.c_void_p]
    lib.robotrt_subscriber_ack.restype = ctypes.c_int32

    lib.robotrt_subscriber_pending_count.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint64)]
    lib.robotrt_subscriber_pending_count.restype = ctypes.c_int32

    lib.robotrt_subscriber_destroy.argtypes = [ctypes.c_void_p]
    lib.robotrt_subscriber_destroy.restype = ctypes.c_int32

    lib.robotrt_service_client_create.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
    lib.robotrt_service_client_create.restype = ctypes.c_int32

    lib.robotrt_service_server_create.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
    lib.robotrt_service_server_create.restype = ctypes.c_int32

    lib.robotrt_service_client_call.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint64),
    ]
    lib.robotrt_service_client_call.restype = ctypes.c_int32

    lib.robotrt_service_client_call_with_deadline.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_uint64,
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint64),
    ]
    lib.robotrt_service_client_call_with_deadline.restype = ctypes.c_int32

    lib.robotrt_service_client_cancel.argtypes = [ctypes.c_void_p, ctypes.c_uint64]
    lib.robotrt_service_client_cancel.restype = ctypes.c_int32

    lib.robotrt_service_server_recv_request.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    lib.robotrt_service_server_recv_request.restype = ctypes.c_int32

    lib.robotrt_service_server_reply.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_uint64,
    ]
    lib.robotrt_service_server_reply.restype = ctypes.c_int32

    lib.robotrt_service_server_reply_error.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint64,
        ctypes.c_int32,
        ctypes.c_int32,
        ctypes.c_uint8,
        ctypes.c_char_p,
    ]
    lib.robotrt_service_server_reply_error.restype = ctypes.c_int32

    lib.robotrt_service_client_poll_response.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    lib.robotrt_service_client_poll_response.restype = ctypes.c_int32

    lib.robotrt_service_client_destroy.argtypes = [ctypes.c_void_p]
    lib.robotrt_service_client_destroy.restype = ctypes.c_int32

    lib.robotrt_service_server_destroy.argtypes = [ctypes.c_void_p]
    lib.robotrt_service_server_destroy.restype = ctypes.c_int32

    lib.robotrt_action_client_create.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
    lib.robotrt_action_client_create.restype = ctypes.c_int32

    lib.robotrt_action_server_create.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
    lib.robotrt_action_server_create.restype = ctypes.c_int32

    lib.robotrt_action_client_send_goal.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    lib.robotrt_action_client_send_goal.restype = ctypes.c_int32

    lib.robotrt_action_server_recv_goal.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    lib.robotrt_action_server_recv_goal.restype = ctypes.c_int32

    lib.robotrt_action_server_accept_goal.argtypes = [ctypes.c_void_p, ctypes.c_uint64]
    lib.robotrt_action_server_accept_goal.restype = ctypes.c_int32

    lib.robotrt_action_server_reject_goal.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.c_char_p]
    lib.robotrt_action_server_reject_goal.restype = ctypes.c_int32

    lib.robotrt_action_server_publish_feedback.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_uint64,
    ]
    lib.robotrt_action_server_publish_feedback.restype = ctypes.c_int32

    lib.robotrt_action_server_heartbeat.argtypes = [ctypes.c_void_p, ctypes.c_uint64]
    lib.robotrt_action_server_heartbeat.restype = ctypes.c_int32

    lib.robotrt_action_client_poll_feedback.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    lib.robotrt_action_client_poll_feedback.restype = ctypes.c_int32

    lib.robotrt_action_server_succeed.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_uint64,
    ]
    lib.robotrt_action_server_succeed.restype = ctypes.c_int32

    lib.robotrt_action_server_fail.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.c_char_p]
    lib.robotrt_action_server_fail.restype = ctypes.c_int32

    lib.robotrt_action_client_poll_result.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_int32),
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    lib.robotrt_action_client_poll_result.restype = ctypes.c_int32

    lib.robotrt_action_client_cancel.argtypes = [ctypes.c_void_p, ctypes.c_uint64]
    lib.robotrt_action_client_cancel.restype = ctypes.c_int32

    lib.robotrt_action_client_goal_status.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_int32),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    lib.robotrt_action_client_goal_status.restype = ctypes.c_int32

    lib.robotrt_action_client_goal_health.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint64,
        ctypes.POINTER(RtActionGoalHealth),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    lib.robotrt_action_client_goal_health.restype = ctypes.c_int32

    lib.robotrt_action_client_active_goal_health.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(RtActionGoalHealth),
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint64),
    ]
    lib.robotrt_action_client_active_goal_health.restype = ctypes.c_int32

    lib.robotrt_action_client_tick_timeouts.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint32),
    ]
    lib.robotrt_action_client_tick_timeouts.restype = ctypes.c_int32

    lib.robotrt_action_server_poll_cancel.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    lib.robotrt_action_server_poll_cancel.restype = ctypes.c_int32

    lib.robotrt_action_server_confirm_cancel.argtypes = [ctypes.c_void_p, ctypes.c_uint64]
    lib.robotrt_action_server_confirm_cancel.restype = ctypes.c_int32

    lib.robotrt_action_client_destroy.argtypes = [ctypes.c_void_p]
    lib.robotrt_action_client_destroy.restype = ctypes.c_int32

    lib.robotrt_action_server_destroy.argtypes = [ctypes.c_void_p]
    lib.robotrt_action_server_destroy.restype = ctypes.c_int32

    lib.robotrt_mission_create.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.POINTER(ctypes.c_void_p)]
    lib.robotrt_mission_create.restype = ctypes.c_int32

    lib.robotrt_mission_open.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    lib.robotrt_mission_open.restype = ctypes.c_int32

    lib.robotrt_mission_send_command.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_uint8)]
    lib.robotrt_mission_send_command.restype = ctypes.c_int32

    lib.robotrt_mission_reconcile.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32]
    lib.robotrt_mission_reconcile.restype = ctypes.c_int32

    lib.robotrt_mission_complete_replay.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    lib.robotrt_mission_complete_replay.restype = ctypes.c_int32

    lib.robotrt_mission_send_update_text.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    lib.robotrt_mission_send_update_text.restype = ctypes.c_int32

    lib.robotrt_mission_send_update_json.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    lib.robotrt_mission_send_update_json.restype = ctypes.c_int32

    lib.robotrt_mission_heartbeat.argtypes = [ctypes.c_void_p]
    lib.robotrt_mission_heartbeat.restype = ctypes.c_int32

    lib.robotrt_mission_next_update_json.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint32),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    lib.robotrt_mission_next_update_json.restype = ctypes.c_int32

    lib.robotrt_mission_destroy.argtypes = [ctypes.c_void_p]
    lib.robotrt_mission_destroy.restype = ctypes.c_int32

    lib.robotrt_buffer_lease_create_from_bytes.argtypes = [ctypes.POINTER(ctypes.c_uint8), ctypes.c_uint64, ctypes.POINTER(ctypes.c_void_p)]
    lib.robotrt_buffer_lease_create_from_bytes.restype = ctypes.c_int32

    lib.robotrt_buffer_lease_descriptor.argtypes = [ctypes.c_void_p, ctypes.POINTER(RtBufferDescriptor)]
    lib.robotrt_buffer_lease_descriptor.restype = ctypes.c_int32

    lib.robotrt_buffer_lease_open_from_descriptor.argtypes = [ctypes.POINTER(RtBufferDescriptor), ctypes.POINTER(ctypes.c_void_p)]
    lib.robotrt_buffer_lease_open_from_descriptor.restype = ctypes.c_int32

    lib.robotrt_buffer_lease_copy_bytes.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_uint64,
        ctypes.POINTER(ctypes.c_uint64),
    ]
    lib.robotrt_buffer_lease_copy_bytes.restype = ctypes.c_int32

    lib.robotrt_buffer_lease_borrow_readonly.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.POINTER(ctypes.c_uint8)),
        ctypes.POINTER(ctypes.c_uint64),
    ]
    lib.robotrt_buffer_lease_borrow_readonly.restype = ctypes.c_int32

    lib.robotrt_buffer_lease_release.argtypes = [ctypes.c_void_p]
    lib.robotrt_buffer_lease_release.restype = ctypes.c_int32

    lib.robotrt_error_last.argtypes = [ctypes.POINTER(RtErrorInfo)]
    lib.robotrt_error_last.restype = ctypes.c_int32

    lib.robotrt_error_message_copy.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32)]
    lib.robotrt_error_message_copy.restype = ctypes.c_int32

    lib.robotrt_error_clear.argtypes = []
    lib.robotrt_error_clear.restype = ctypes.c_int32
