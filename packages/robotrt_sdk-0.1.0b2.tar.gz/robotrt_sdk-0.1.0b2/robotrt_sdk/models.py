from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class BackpressureSignal(str, Enum):
    CLEAR = "clear"
    SOFT = "soft"
    HARD = "hard"


@dataclass(frozen=True)
class BufferDescriptor:
    lease_id: int
    payload_len: int
    segment_index: int
    segment_offset: int
    segment_capacity: int
    flags: int


@dataclass(frozen=True)
class ExternalBufferRef:
    buffer_id: int
    offset: int
    len: int


@dataclass(frozen=True)
class ActionGoalHealth:
    goal_id: int
    status: int
    liveness: int
    heartbeat_timeout_nanos: int | None
    stalled_threshold_nanos: int | None
    last_heartbeat_at_unix_nanos: int | None
    last_feedback_at_unix_nanos: int | None
    last_result_at_unix_nanos: int | None
