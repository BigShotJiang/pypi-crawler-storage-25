from __future__ import annotations

import itertools
import json
import socket
import time
from pathlib import Path
from typing import Any

from .errors import ErrorInfo, RobotRtError

RT_INVALID_ARGUMENT = 1
RT_NOT_FOUND = 2
RT_DEADLINE_EXCEEDED = 4
RT_FAILED_PRECONDITION = 6
RT_INTERNAL = 10
RT_UNAVAILABLE = 11
RT_DOMAIN_CORE = 0

UDP_SERVICE_WIRE_API_VERSION = "core_api.udp_service.v1"
STATUS_SERVICE_API_VERSION = "robotrt.gateway.service.v1"
STATUS_SERVICE_NAME = "/robotrt/gateway/query"
DEFAULT_DAEMON_ENDPOINT = "127.0.0.1:7588"
DEFAULT_STATUS_REPORT_PATH = "artifacts/introspection/local-loop-status.json"

_NEXT_REQUEST_ID = itertools.count(1)


def _raise_error(code: int, message: str, *, retryable: bool = False, context: str | None = None) -> None:
    raise RobotRtError(
        ErrorInfo(
            code=code,
            domain=RT_DOMAIN_CORE,
            retryable=retryable,
            message=message,
        ),
        context=context,
    )


def _normalize_mode(mode: str) -> str:
    if mode in ("embedded", "daemon"):
        return mode
    _raise_error(
        RT_INVALID_ARGUMENT,
        f"unsupported mode value: {mode} (expected embedded|daemon)",
        context="StatusClient.__init__",
    )


def _normalize_udp_endpoint(raw: str) -> str:
    endpoint = raw
    if endpoint.startswith("udp://"):
        endpoint = endpoint[6:]
    elif "://" in endpoint:
        _raise_error(
            RT_INVALID_ARGUMENT,
            f"unsupported endpoint scheme: {raw}",
            context="StatusClient._fetch_remote_snapshot",
        )

    if not endpoint:
        _raise_error(
            RT_INVALID_ARGUMENT,
            f"invalid endpoint value: {raw}",
            context="StatusClient._fetch_remote_snapshot",
        )

    return endpoint


def _parse_udp_target(endpoint: str) -> tuple[str, int]:
    host, sep, port_text = endpoint.rpartition(":")
    if not sep or not host:
        _raise_error(
            RT_INVALID_ARGUMENT,
            f"invalid endpoint format: {endpoint} (expected host:port)",
            context="StatusClient._fetch_remote_snapshot",
        )

    try:
        port = int(port_text)
    except ValueError:
        _raise_error(
            RT_INVALID_ARGUMENT,
            f"invalid endpoint port: {endpoint}",
            context="StatusClient._fetch_remote_snapshot",
        )

    if port <= 0 or port > 65535:
        _raise_error(
            RT_INVALID_ARGUMENT,
            f"endpoint port out of range: {endpoint}",
            context="StatusClient._fetch_remote_snapshot",
        )

    return host, port


def _decode_payload_bytes(payload: Any) -> bytes:
    if not isinstance(payload, list):
        _raise_error(
            RT_INTERNAL,
            "service payload is not a byte array",
            context="StatusClient._fetch_remote_snapshot",
        )

    try:
        return bytes(payload)
    except Exception as exc:  # pragma: no cover - defensive conversion path
        _raise_error(
            RT_INTERNAL,
            f"decode service payload failed: {exc}",
            context="StatusClient._fetch_remote_snapshot",
        )


class StatusClient:
    def __init__(
        self,
        *,
        mode: str = "embedded",
        endpoint: str | None = None,
        timeout_ms: int = 1000,
        report_path: str | Path = DEFAULT_STATUS_REPORT_PATH,
    ) -> None:
        self.mode = _normalize_mode(mode)
        self.endpoint = endpoint
        self.timeout_ms = int(timeout_ms)
        self.report_path = Path(report_path)

        if self.timeout_ms <= 0:
            _raise_error(
                RT_INVALID_ARGUMENT,
                f"timeout_ms must be > 0, got {self.timeout_ms}",
                context="StatusClient.__init__",
            )

    def snapshot(self) -> dict[str, Any]:
        remote_endpoint = self._resolve_remote_endpoint()
        if remote_endpoint is not None:
            return self._fetch_remote_snapshot(remote_endpoint)

        return self._load_embedded_snapshot()

    def node_list(self) -> list[str]:
        return self._list_named("nodes")

    def topic_list(self) -> list[str]:
        return self._list_named("topics")

    def service_list(self) -> list[str]:
        return self._list_named("services")

    def action_list(self) -> list[str]:
        return self._list_named("actions")

    def mission_list(self) -> list[str]:
        return self._list_named("missions")

    def node_info(self, name: str) -> dict[str, Any]:
        return self._find_exact("nodes", name, "node")

    def topic_info(self, name: str) -> dict[str, Any]:
        return self._find_exact("topics", name, "topic")

    def action_info(self, name: str) -> dict[str, Any]:
        actions = self.snapshot().get("actions", [])
        if not isinstance(actions, list):
            _raise_error(
                RT_INTERNAL,
                "snapshot.actions is not a list",
                context="StatusClient.action_info",
            )

        for action in actions:
            if not isinstance(action, dict):
                continue
            candidate = action.get("name")
            if isinstance(candidate, str) and self._action_matches(candidate, name):
                return action

        _raise_error(
            RT_NOT_FOUND,
            f"action not found: {name}",
            context="StatusClient.action_info",
        )

    def plugin_list(self, *, loaded_only: bool = False) -> list[dict[str, Any]]:
        plugins = self.snapshot().get("plugins", [])
        if not isinstance(plugins, list):
            _raise_error(
                RT_INTERNAL,
                "snapshot.plugins is not a list",
                context="StatusClient.plugin_list",
            )

        if not loaded_only:
            return [item for item in plugins if isinstance(item, dict)]

        return [item for item in plugins if isinstance(item, dict) and item.get("loaded") is True]

    def health(self) -> list[dict[str, Any]]:
        return self._list_objects("health", "StatusClient.health")

    def graph(self) -> list[dict[str, Any]]:
        return self._list_objects("edges", "StatusClient.graph")

    def action_watch(
        self,
        action_name: str | None = None,
        *,
        iterations: int = 1,
        interval_ms: int = 1000,
    ) -> list[dict[str, Any]]:
        return self._watch("actions", "action", action_name, iterations=iterations, interval_ms=interval_ms)

    def mission_watch(
        self,
        mission_name: str | None = None,
        *,
        iterations: int = 1,
        interval_ms: int = 1000,
    ) -> list[dict[str, Any]]:
        return self._watch("missions", "mission", mission_name, iterations=iterations, interval_ms=interval_ms)

    def _resolve_remote_endpoint(self) -> str | None:
        if self.mode == "daemon":
            return self.endpoint or DEFAULT_DAEMON_ENDPOINT
        if self.endpoint:
            return self.endpoint
        return None

    def _fetch_remote_snapshot(self, endpoint: str) -> dict[str, Any]:
        normalized = _normalize_udp_endpoint(endpoint)
        host, port = _parse_udp_target(normalized)

        request_id = next(_NEXT_REQUEST_ID)
        request_payload = {
            "api_version": STATUS_SERVICE_API_VERSION,
            "op": "snapshot",
        }
        request_payload_bytes = json.dumps(request_payload).encode("utf-8")
        envelope = {
            "api_version": UDP_SERVICE_WIRE_API_VERSION,
            "service": STATUS_SERVICE_NAME,
            "request_id": request_id,
            "payload": list(request_payload_bytes),
        }
        encoded = json.dumps(envelope).encode("utf-8")

        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(self.timeout_ms / 1000.0)
            try:
                sock.sendto(encoded, (host, port))
            except OSError as exc:
                _raise_error(
                    RT_UNAVAILABLE,
                    f"send status query failed: {exc}",
                    context="StatusClient._fetch_remote_snapshot",
                )

            try:
                response_bytes, _ = sock.recvfrom(1024 * 1024)
            except socket.timeout as exc:
                _raise_error(
                    RT_DEADLINE_EXCEEDED,
                    f"recv status response timed out: {exc}",
                    retryable=True,
                    context="StatusClient._fetch_remote_snapshot",
                )
            except OSError as exc:
                _raise_error(
                    RT_UNAVAILABLE,
                    f"recv status response failed: {exc}",
                    context="StatusClient._fetch_remote_snapshot",
                )

        try:
            response = json.loads(response_bytes.decode("utf-8"))
        except Exception as exc:
            _raise_error(
                RT_INTERNAL,
                f"parse service response envelope failed: {exc}",
                context="StatusClient._fetch_remote_snapshot",
            )

        self._validate_response_envelope(response, expected_request_id=request_id)

        if response.get("ok") is not True:
            reason = response.get("error") or "service response returned ok=false"
            _raise_error(
                RT_FAILED_PRECONDITION,
                str(reason),
                context="StatusClient._fetch_remote_snapshot",
            )

        payload = response.get("payload")
        payload_bytes = _decode_payload_bytes(payload)

        try:
            service_payload = json.loads(payload_bytes.decode("utf-8"))
        except Exception as exc:
            _raise_error(
                RT_INTERNAL,
                f"parse service response payload failed: {exc}",
                context="StatusClient._fetch_remote_snapshot",
            )

        if service_payload.get("api_version") != STATUS_SERVICE_API_VERSION:
            _raise_error(
                RT_INTERNAL,
                (
                    "unsupported status api_version="
                    f"{service_payload.get('api_version')} expected={STATUS_SERVICE_API_VERSION}"
                ),
                context="StatusClient._fetch_remote_snapshot",
            )

        snapshot = service_payload.get("snapshot")
        if not isinstance(snapshot, dict):
            _raise_error(
                RT_INTERNAL,
                "service payload missing snapshot object",
                context="StatusClient._fetch_remote_snapshot",
            )

        return snapshot

    def _validate_response_envelope(self, response: Any, *, expected_request_id: int) -> None:
        if not isinstance(response, dict):
            _raise_error(
                RT_INTERNAL,
                "service response envelope is not an object",
                context="StatusClient._fetch_remote_snapshot",
            )

        if response.get("api_version") != UDP_SERVICE_WIRE_API_VERSION:
            _raise_error(
                RT_INTERNAL,
                (
                    "unsupported service wire api_version="
                    f"{response.get('api_version')} expected={UDP_SERVICE_WIRE_API_VERSION}"
                ),
                context="StatusClient._fetch_remote_snapshot",
            )

        if response.get("service") != STATUS_SERVICE_NAME:
            _raise_error(
                RT_FAILED_PRECONDITION,
                (
                    "mismatched response service="
                    f"{response.get('service')} expected={STATUS_SERVICE_NAME}"
                ),
                context="StatusClient._fetch_remote_snapshot",
            )

        if response.get("request_id") != expected_request_id:
            _raise_error(
                RT_FAILED_PRECONDITION,
                (
                    "mismatched response request_id="
                    f"{response.get('request_id')} expected={expected_request_id}"
                ),
                context="StatusClient._fetch_remote_snapshot",
            )

    def _load_embedded_snapshot(self) -> dict[str, Any]:
        try:
            text = self.report_path.read_text(encoding="utf-8")
        except OSError as exc:
            _raise_error(
                RT_UNAVAILABLE,
                f"read status report failed: {exc}",
                context="StatusClient._load_embedded_snapshot",
            )

        try:
            payload = json.loads(text)
        except Exception as exc:
            _raise_error(
                RT_INTERNAL,
                f"parse status report failed: {exc}",
                context="StatusClient._load_embedded_snapshot",
            )

        if not isinstance(payload, dict):
            _raise_error(
                RT_INTERNAL,
                "status report root is not an object",
                context="StatusClient._load_embedded_snapshot",
            )

        return payload

    def _list_named(self, collection_key: str) -> list[str]:
        values = self.snapshot().get(collection_key, [])
        if not isinstance(values, list):
            _raise_error(
                RT_INTERNAL,
                f"snapshot.{collection_key} is not a list",
                context="StatusClient._list_named",
            )

        names: list[str] = []
        for value in values:
            if not isinstance(value, dict):
                continue
            name = value.get("name")
            if isinstance(name, str):
                names.append(name)
        return names

    def _list_objects(self, collection_key: str, context: str) -> list[dict[str, Any]]:
        values = self.snapshot().get(collection_key, [])
        if not isinstance(values, list):
            _raise_error(
                RT_INTERNAL,
                f"snapshot.{collection_key} is not a list",
                context=context,
            )
        return [value for value in values if isinstance(value, dict)]

    def _find_exact(self, collection_key: str, name: str, kind: str) -> dict[str, Any]:
        values = self.snapshot().get(collection_key, [])
        if not isinstance(values, list):
            _raise_error(
                RT_INTERNAL,
                f"snapshot.{collection_key} is not a list",
                context="StatusClient._find_exact",
            )

        for value in values:
            if isinstance(value, dict) and value.get("name") == name:
                return value

        _raise_error(
            RT_NOT_FOUND,
            f"{kind} not found: {name}",
            context="StatusClient._find_exact",
        )

    def _watch(
        self,
        collection_key: str,
        kind: str,
        expected_name: str | None,
        *,
        iterations: int,
        interval_ms: int,
    ) -> list[dict[str, Any]]:
        if iterations <= 0:
            _raise_error(
                RT_INVALID_ARGUMENT,
                f"iterations must be > 0, got {iterations}",
                context=f"StatusClient.{kind}_watch",
            )
        if interval_ms < 0:
            _raise_error(
                RT_INVALID_ARGUMENT,
                f"interval_ms must be >= 0, got {interval_ms}",
                context=f"StatusClient.{kind}_watch",
            )

        samples: list[dict[str, Any]] = []
        for idx in range(iterations):
            snapshot = self.snapshot()
            items = snapshot.get(collection_key, [])
            if not isinstance(items, list):
                _raise_error(
                    RT_INTERNAL,
                    f"snapshot.{collection_key} is not a list",
                    context=f"StatusClient.{kind}_watch",
                )

            filtered: list[dict[str, Any]] = []
            for item in items:
                if not isinstance(item, dict):
                    continue
                if expected_name is None:
                    filtered.append(item)
                    continue

                item_name = item.get("name")
                if not isinstance(item_name, str):
                    continue

                if kind == "action":
                    if self._action_matches(item_name, expected_name):
                        filtered.append(item)
                elif item_name == expected_name:
                    filtered.append(item)

            samples.append(
                {
                    "iteration": idx + 1,
                    "captured_at_unix_nanos": snapshot.get("captured_at_unix_nanos"),
                    collection_key: filtered,
                }
            )

            if idx + 1 < iterations:
                time.sleep(interval_ms / 1000.0)

        return samples

    @staticmethod
    def _action_matches(candidate: str, query_name: str) -> bool:
        return candidate == query_name or candidate.endswith(f"/{query_name}")
