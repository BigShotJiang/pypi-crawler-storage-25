from __future__ import annotations

import ctypes
from collections.abc import Iterable

from ._ffi import _CORE, RtExternalBufferRef
from .models import BackpressureSignal
from .models import ExternalBufferRef
from .utils import as_u8_ptr


class Publisher:
    def __init__(self, handle: ctypes.c_void_p, *, qos_depth_hint: int | None = None) -> None:
        self._handle = handle
        self._closed = False
        self._qos_depth_hint = int(qos_depth_hint or 16)
        if self._qos_depth_hint <= 0:
            self._qos_depth_hint = 16
        self._last_backpressure_hard = False

    def publish(self, payload: bytes | bytearray | memoryview) -> None:
        ptr, n, _keepalive = as_u8_ptr(payload)
        status = _CORE.lib.robotrt_publisher_publish(self._handle, ptr, n)
        try:
            _CORE.check(status, "robotrt_publisher_publish")
            self._last_backpressure_hard = False
        except Exception:
            self._last_backpressure_hard = True
            raise

    def publish_buffer(self, buffer_ref: ExternalBufferRef) -> None:
        raw = RtExternalBufferRef(
            buffer_id=int(buffer_ref.buffer_id),
            offset=int(buffer_ref.offset),
            len=int(buffer_ref.len),
        )
        status = _CORE.lib.robotrt_publisher_publish_buffer(self._handle, ctypes.byref(raw))
        try:
            _CORE.check(status, "robotrt_publisher_publish_buffer")
            self._last_backpressure_hard = False
        except Exception:
            self._last_backpressure_hard = True
            raise

    def publish_batch(self, payloads: Iterable[bytes | bytearray | memoryview]) -> int:
        accepted = 0
        for payload in payloads:
            self.publish(payload)
            accepted += 1
        return accepted

    def publish_buffer_batch(self, buffer_refs: Iterable[ExternalBufferRef]) -> int:
        accepted = 0
        for buffer_ref in buffer_refs:
            self.publish_buffer(buffer_ref)
            accepted += 1
        return accepted

    def backpressure_signal(self) -> BackpressureSignal:
        if self._last_backpressure_hard:
            return BackpressureSignal.HARD
        return BackpressureSignal.CLEAR

    def flush(self) -> None:
        status = _CORE.lib.robotrt_publisher_flush(self._handle)
        _CORE.check(status, "robotrt_publisher_flush")

    def close(self) -> None:
        if self._closed:
            return
        status = _CORE.lib.robotrt_publisher_destroy(self._handle)
        _CORE.check(status, "robotrt_publisher_destroy")
        self._closed = True

    def __enter__(self) -> "Publisher":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass


class Subscriber:
    def __init__(self, handle: ctypes.c_void_p, *, qos_depth_hint: int | None = None) -> None:
        self._handle = handle
        self._closed = False
        self._qos_depth_hint = int(qos_depth_hint or 16)
        if self._qos_depth_hint <= 0:
            self._qos_depth_hint = 16

    def recv(self, *, cap: int = 1024 * 1024) -> bytes | None:
        buf = (ctypes.c_uint8 * cap)()
        copied = ctypes.c_uint64(0)
        has_message = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_subscriber_recv(
            self._handle,
            buf,
            cap,
            ctypes.byref(copied),
            ctypes.byref(has_message),
        )
        _CORE.check(status, "robotrt_subscriber_recv")
        if has_message.value == 0:
            return None
        return bytes(memoryview(buf)[: copied.value])

    def recv_batch(self, max_items: int, *, cap: int = 1024 * 1024) -> list[bytes]:
        if max_items <= 0:
            return []

        out: list[bytes] = []
        for _ in range(max_items):
            item = self.recv(cap=cap)
            if item is None:
                break
            out.append(item)
        return out

    def ack(self) -> None:
        status = _CORE.lib.robotrt_subscriber_ack(self._handle)
        _CORE.check(status, "robotrt_subscriber_ack")

    def pending_count(self) -> int:
        pending_count = ctypes.c_uint64(0)
        status = _CORE.lib.robotrt_subscriber_pending_count(self._handle, ctypes.byref(pending_count))
        _CORE.check(status, "robotrt_subscriber_pending_count")
        return int(pending_count.value)

    def backpressure_signal(self) -> BackpressureSignal:
        pending = self.pending_count()
        if pending >= self._qos_depth_hint:
            return BackpressureSignal.HARD
        if pending / float(self._qos_depth_hint) >= 0.8:
            return BackpressureSignal.SOFT
        return BackpressureSignal.CLEAR

    def close(self) -> None:
        if self._closed:
            return
        status = _CORE.lib.robotrt_subscriber_destroy(self._handle)
        _CORE.check(status, "robotrt_subscriber_destroy")
        self._closed = True

    def __enter__(self) -> "Subscriber":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass
