from __future__ import annotations

import ctypes

RT_OK = 0


class RtErrorInfo(ctypes.Structure):
    _fields_ = [
        ("code", ctypes.c_int32),
        ("domain", ctypes.c_int32),
        ("retryable", ctypes.c_uint8),
        ("_reserved0", ctypes.c_uint8),
        ("_reserved1", ctypes.c_uint8),
        ("_reserved2", ctypes.c_uint8),
        ("message_len", ctypes.c_uint32),
    ]


class RtBufferDescriptor(ctypes.Structure):
    _fields_ = [
        ("lease_id", ctypes.c_uint64),
        ("payload_len", ctypes.c_uint64),
        ("segment_index", ctypes.c_uint32),
        ("segment_offset", ctypes.c_uint32),
        ("segment_capacity", ctypes.c_uint32),
        ("flags", ctypes.c_uint32),
    ]


class RtExternalBufferRef(ctypes.Structure):
    _fields_ = [
        ("buffer_id", ctypes.c_uint64),
        ("offset", ctypes.c_uint64),
        ("len", ctypes.c_uint64),
    ]


class RtActionGoalHealth(ctypes.Structure):
    _fields_ = [
        ("goal_id", ctypes.c_uint64),
        ("status", ctypes.c_int32),
        ("liveness", ctypes.c_int32),
        ("heartbeat_timeout_nanos", ctypes.c_uint64),
        ("stalled_threshold_nanos", ctypes.c_uint64),
        ("last_heartbeat_at_unix_nanos", ctypes.c_uint64),
        ("last_feedback_at_unix_nanos", ctypes.c_uint64),
        ("last_result_at_unix_nanos", ctypes.c_uint64),
        ("has_heartbeat_timeout", ctypes.c_uint8),
        ("has_stalled_threshold", ctypes.c_uint8),
        ("has_last_heartbeat", ctypes.c_uint8),
        ("has_last_feedback", ctypes.c_uint8),
        ("has_last_result", ctypes.c_uint8),
        ("_reserved0", ctypes.c_uint8),
        ("_reserved1", ctypes.c_uint8),
        ("_reserved2", ctypes.c_uint8),
    ]
