from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass
from enum import Enum
from typing import Callable


class RegisteredWorkKind(str, Enum):
    TIMER = "timer"
    SUBSCRIPTION = "subscription"
    SERVICE = "service"
    ACTION = "action"
    MISSION = "mission"


class CallbackGroupType(str, Enum):
    MUTUALLY_EXCLUSIVE = "mutually_exclusive"
    REENTRANT = "reentrant"


@dataclass(frozen=True)
class TimerRegistration:
    interval_nanos: int
    started_at_unix_nanos: int

    @classmethod
    def from_interval(cls, interval_nanos: int) -> "TimerRegistration":
        if interval_nanos <= 0:
            raise ValueError("interval_nanos must be > 0")
        return cls(
            interval_nanos=int(interval_nanos),
            started_at_unix_nanos=time.time_ns(),
        )


@dataclass(frozen=True)
class RegisteredWork:
    kind: RegisteredWorkKind
    timer: TimerRegistration | None = None
    name: str | None = None

    @staticmethod
    def timer_work(timer: TimerRegistration) -> "RegisteredWork":
        return RegisteredWork(kind=RegisteredWorkKind.TIMER, timer=timer)

    @staticmethod
    def named(kind: RegisteredWorkKind, name: str) -> "RegisteredWork":
        return RegisteredWork(kind=kind, name=name)


@dataclass(frozen=True)
class MultiThreadExecutorStats:
    dispatched_work_total: int
    grouped_work_total: int
    group_block_count: int
    max_parallelism: int
    completed_handler_work_total: int


class SimpleExecutor:
    def __init__(self) -> None:
        self._queue: deque[RegisteredWork] = deque()
        self._awake = False
        self._shutdown = False
        self._nodes: set[int] = set()
        self._callback_groups: dict[str, CallbackGroupType] = {}

    def spin(self) -> None:
        while self.spin_once():
            pass

    def spin_once(self, timeout_s: float | None = None) -> bool:
        if self._shutdown:
            return False
        had_work = bool(self._queue)
        if not had_work and timeout_s is not None and timeout_s > 0:
            time.sleep(float(timeout_s))
            had_work = bool(self._queue)
        if had_work:
            self._queue.popleft()
        self._awake = False
        return had_work

    def spin_until(
        self,
        predicate: Callable[[], bool],
        *,
        timeout_s: float,
        poll_interval_s: float = 0.001,
    ) -> bool:
        deadline = time.monotonic() + max(0.0, float(timeout_s))
        interval = max(0.0, float(poll_interval_s))
        while time.monotonic() <= deadline:
            if predicate():
                return True
            self.spin_once(timeout_s=interval)
        return predicate()

    def register_timer(self, timer: TimerRegistration) -> None:
        self._queue.append(RegisteredWork.timer_work(timer))

    def register_subscription(self, topic: str) -> None:
        self._queue.append(RegisteredWork.named(RegisteredWorkKind.SUBSCRIPTION, topic))

    def register_service(self, service_name: str) -> None:
        self._queue.append(RegisteredWork.named(RegisteredWorkKind.SERVICE, service_name))

    def register_action(self, action_name: str) -> None:
        self._queue.append(RegisteredWork.named(RegisteredWorkKind.ACTION, action_name))

    def register_mission(self, mission_name: str) -> None:
        self._queue.append(RegisteredWork.named(RegisteredWorkKind.MISSION, mission_name))

    def wakeup(self) -> None:
        self._awake = True

    def add_node(self, node: object) -> None:
        self._nodes.add(id(node))

    def remove_node(self, node: object) -> bool:
        token = id(node)
        if token in self._nodes:
            self._nodes.remove(token)
            return True
        return False

    def node_count(self) -> int:
        return len(self._nodes)

    def add_callback_group(
        self,
        group_id: str,
        group_type: CallbackGroupType = CallbackGroupType.REENTRANT,
    ) -> None:
        if not group_id:
            raise ValueError("group_id must not be empty")
        self._callback_groups[group_id] = group_type

    def remove_callback_group(self, group_id: str) -> bool:
        return self._callback_groups.pop(group_id, None) is not None

    def callback_group_count(self) -> int:
        return len(self._callback_groups)

    def shutdown(self) -> None:
        self._shutdown = True


@dataclass
class _PendingTimer:
    next_at_unix_nanos: int
    interval_nanos: int
    handler: Callable[[int], None]


@dataclass
class _PendingPoller:
    name: str
    poll: Callable[[], int]


@dataclass
class _PendingGroupedWork:
    kind: RegisteredWorkKind
    name: str
    poll: Callable[[], int]
    group_id: str | None = None
    group_type: CallbackGroupType = CallbackGroupType.REENTRANT
    simulated_cost_s: float = 0.002


class CallbackExecutor:
    def __init__(self) -> None:
        self._timers: list[_PendingTimer] = []
        self._subscriptions: list[_PendingPoller] = []
        self._services: list[_PendingPoller] = []
        self._missions: list[_PendingPoller] = []
        self._actions: list[_PendingPoller] = []
        self._shutdown = False
        self.last_work_count = 0
        self._nodes: set[int] = set()
        self._callback_groups: dict[str, CallbackGroupType] = {}

    def register_timer_handler(
        self,
        interval_nanos: int,
        handler: Callable[[int], None],
        *,
        start_at_unix_nanos: int | None = None,
    ) -> None:
        if interval_nanos <= 0:
            raise ValueError("interval_nanos must be > 0")
        start_at = time.time_ns() if start_at_unix_nanos is None else int(start_at_unix_nanos)
        self._timers.append(
            _PendingTimer(
                next_at_unix_nanos=start_at,
                interval_nanos=int(interval_nanos),
                handler=handler,
            )
        )

    def register_subscription_handler(self, topic: str, poll: Callable[[], int]) -> None:
        self._subscriptions.append(_PendingPoller(name=topic, poll=poll))

    def register_service_handler(self, name: str, poll: Callable[[], int]) -> None:
        self._services.append(_PendingPoller(name=name, poll=poll))

    def register_mission_handler(self, name: str, poll: Callable[[], int]) -> None:
        self._missions.append(_PendingPoller(name=name, poll=poll))

    def register_action_handler(self, name: str, poll: Callable[[], int]) -> None:
        self._actions.append(_PendingPoller(name=name, poll=poll))

    def handler_count(self) -> int:
        return (
            len(self._timers)
            + len(self._subscriptions)
            + len(self._services)
            + len(self._missions)
            + len(self._actions)
        )

    def spin(self) -> None:
        while self.spin_once():
            pass

    def spin_once(self, timeout_s: float | None = None) -> bool:
        if self._shutdown:
            return False

        now = time.time_ns()
        work = 0

        for timer in self._timers:
            if now >= timer.next_at_unix_nanos:
                timer.handler(now)
                timer.next_at_unix_nanos = now + timer.interval_nanos
                work += 1

        for poller in self._subscriptions:
            work += int(poller.poll())
        for poller in self._services:
            work += int(poller.poll())
        for poller in self._missions:
            work += int(poller.poll())
        for poller in self._actions:
            work += int(poller.poll())

        self.last_work_count = work
        if work == 0 and timeout_s is not None and timeout_s > 0:
            time.sleep(float(timeout_s))
        return work > 0

    def spin_until(
        self,
        predicate: Callable[[], bool],
        *,
        timeout_s: float,
        poll_interval_s: float = 0.001,
    ) -> bool:
        deadline = time.monotonic() + max(0.0, float(timeout_s))
        interval = max(0.0, float(poll_interval_s))
        while time.monotonic() <= deadline:
            if predicate():
                return True
            self.spin_once(timeout_s=interval)
        return predicate()

    def register_timer(self, timer: TimerRegistration) -> None:
        self.register_timer_handler(
            interval_nanos=int(timer.interval_nanos),
            handler=lambda _: None,
            start_at_unix_nanos=int(timer.started_at_unix_nanos),
        )

    def register_subscription(self, topic: str) -> None:
        self.register_subscription_handler(topic, lambda: 0)

    def register_service(self, service_name: str) -> None:
        self.register_service_handler(service_name, lambda: 0)

    def register_action(self, action_name: str) -> None:
        self.register_action_handler(action_name, lambda: 0)

    def register_mission(self, mission_name: str) -> None:
        self.register_mission_handler(mission_name, lambda: 0)

    def wakeup(self) -> None:
        return None

    def add_node(self, node: object) -> None:
        self._nodes.add(id(node))

    def remove_node(self, node: object) -> bool:
        token = id(node)
        if token in self._nodes:
            self._nodes.remove(token)
            return True
        return False

    def node_count(self) -> int:
        return len(self._nodes)

    def add_callback_group(
        self,
        group_id: str,
        group_type: CallbackGroupType = CallbackGroupType.REENTRANT,
    ) -> None:
        if not group_id:
            raise ValueError("group_id must not be empty")
        self._callback_groups[group_id] = group_type

    def remove_callback_group(self, group_id: str) -> bool:
        return self._callback_groups.pop(group_id, None) is not None

    def callback_group_count(self) -> int:
        return len(self._callback_groups)

    def shutdown(self) -> None:
        self._shutdown = True


class MultiThreadExecutor:
    def __init__(
        self,
        *,
        worker_count: int = 2,
        callback_group_enabled: bool = False,
        simulated_cost_s: float = 0.002,
    ) -> None:
        if worker_count <= 0:
            raise ValueError("worker_count must be > 0")

        self._worker_count = int(worker_count)
        self._callback_group_enabled = bool(callback_group_enabled)
        self._simulated_cost_s = float(max(0.0, simulated_cost_s))

        self._queue: deque[_PendingGroupedWork] = deque()
        self._active_mutex_groups: set[str] = set()
        self._active_workers = 0
        self._shutdown = False
        self._cv = threading.Condition()

        self._dispatched_work_total = 0
        self._grouped_work_total = 0
        self._group_block_count = 0
        self._max_parallelism = 0
        self._completed_handler_work_total = 0

        self._workers: list[threading.Thread] = []
        self._nodes: set[int] = set()
        self._callback_groups: dict[str, CallbackGroupType] = {}
        for idx in range(self._worker_count):
            t = threading.Thread(target=self._worker_loop, name=f"robotrt-sdk-mt-executor-{idx}", daemon=True)
            t.start()
            self._workers.append(t)

    def _enqueue(self, item: _PendingGroupedWork) -> None:
        with self._cv:
            if self._shutdown:
                raise RuntimeError("executor is shutdown")
            self._queue.append(item)
            self._cv.notify()

    def _is_blocked(self, item: _PendingGroupedWork) -> bool:
        if not self._callback_group_enabled:
            return False
        if item.group_id is None:
            return False
        return (
            item.group_type == CallbackGroupType.MUTUALLY_EXCLUSIVE
            and item.group_id in self._active_mutex_groups
        )

    def _take_next_work_locked(self) -> _PendingGroupedWork | None:
        if not self._queue:
            return None

        rounds = len(self._queue)
        for _ in range(rounds):
            item = self._queue.popleft()
            if self._is_blocked(item):
                self._group_block_count += 1
                self._queue.append(item)
                continue

            if (
                self._callback_group_enabled
                and item.group_id is not None
                and item.group_type == CallbackGroupType.MUTUALLY_EXCLUSIVE
            ):
                self._active_mutex_groups.add(item.group_id)

            self._dispatched_work_total += 1
            if self._callback_group_enabled and item.group_id is not None:
                self._grouped_work_total += 1

            self._active_workers += 1
            if self._active_workers > self._max_parallelism:
                self._max_parallelism = self._active_workers
            return item

        return None

    def _worker_loop(self) -> None:
        while True:
            with self._cv:
                while not self._shutdown and not self._queue:
                    self._cv.wait()

                if self._shutdown and not self._queue:
                    return

                item = self._take_next_work_locked()
                if item is None:
                    self._cv.wait(timeout=0.001)
                    continue

            if item.simulated_cost_s > 0:
                time.sleep(item.simulated_cost_s)

            produced = int(item.poll())
            if produced < 0:
                produced = 0

            with self._cv:
                self._completed_handler_work_total += produced
                if (
                    self._callback_group_enabled
                    and item.group_id is not None
                    and item.group_type == CallbackGroupType.MUTUALLY_EXCLUSIVE
                ):
                    self._active_mutex_groups.discard(item.group_id)

                self._active_workers = max(0, self._active_workers - 1)
                self._cv.notify_all()

    def _register_named(
        self,
        kind: RegisteredWorkKind,
        name: str,
        *,
        poll: Callable[[], int] | None = None,
        group_id: str | None = None,
        group_type: CallbackGroupType = CallbackGroupType.REENTRANT,
    ) -> None:
        resolved_poll = poll or (lambda: 1)
        self._enqueue(
            _PendingGroupedWork(
                kind=kind,
                name=name,
                poll=resolved_poll,
                group_id=group_id,
                group_type=group_type,
                simulated_cost_s=self._simulated_cost_s,
            )
        )

    def register_timer(self, timer: TimerRegistration) -> None:
        del timer
        self._register_named(RegisteredWorkKind.TIMER, "timer")

    def register_subscription(self, topic: str) -> None:
        self._register_named(RegisteredWorkKind.SUBSCRIPTION, topic)

    def register_subscription_handler(self, topic: str, poll: Callable[[], int]) -> None:
        self._register_named(RegisteredWorkKind.SUBSCRIPTION, topic, poll=poll)

    def register_subscription_grouped(
        self,
        topic: str,
        group_id: str,
        group_type: CallbackGroupType,
    ) -> None:
        self._callback_groups.setdefault(group_id, group_type)
        self._register_named(
            RegisteredWorkKind.SUBSCRIPTION,
            topic,
            group_id=group_id,
            group_type=group_type,
        )

    def register_subscription_handler_grouped(
        self,
        topic: str,
        group_id: str,
        group_type: CallbackGroupType,
        poll: Callable[[], int],
    ) -> None:
        self._callback_groups.setdefault(group_id, group_type)
        self._register_named(
            RegisteredWorkKind.SUBSCRIPTION,
            topic,
            poll=poll,
            group_id=group_id,
            group_type=group_type,
        )

    def pending_count(self) -> int:
        with self._cv:
            return len(self._queue)

    def wait_until_idle(self, timeout_s: float) -> bool:
        deadline = time.monotonic() + max(0.0, float(timeout_s))
        with self._cv:
            while True:
                if not self._queue and self._active_workers == 0:
                    return True
                now = time.monotonic()
                if now >= deadline:
                    return False
                self._cv.wait(timeout=deadline - now)

    def stats_snapshot(self) -> MultiThreadExecutorStats:
        with self._cv:
            return MultiThreadExecutorStats(
                dispatched_work_total=self._dispatched_work_total,
                grouped_work_total=self._grouped_work_total,
                group_block_count=self._group_block_count,
                max_parallelism=self._max_parallelism,
                completed_handler_work_total=self._completed_handler_work_total,
            )

    def spin(self) -> None:
        self.wait_until_idle(timeout_s=1.0)

    def spin_once(self, timeout_s: float | None = None) -> bool:
        with self._cv:
            if self._shutdown:
                return False
            had_work = bool(self._queue) or self._active_workers > 0
        if had_work:
            self.wait_until_idle(timeout_s=0.05)
        elif timeout_s is not None and timeout_s > 0:
            with self._cv:
                self._cv.wait(timeout=float(timeout_s))
                had_work = bool(self._queue) or self._active_workers > 0
        return had_work

    def spin_until(
        self,
        predicate: Callable[[], bool],
        *,
        timeout_s: float,
        poll_interval_s: float = 0.001,
    ) -> bool:
        deadline = time.monotonic() + max(0.0, float(timeout_s))
        interval = max(0.0, float(poll_interval_s))
        while time.monotonic() <= deadline:
            if predicate():
                return True
            self.spin_once(timeout_s=interval)
        return predicate()

    def wakeup(self) -> None:
        with self._cv:
            self._cv.notify_all()

    def add_node(self, node: object) -> None:
        with self._cv:
            self._nodes.add(id(node))

    def remove_node(self, node: object) -> bool:
        token = id(node)
        with self._cv:
            if token in self._nodes:
                self._nodes.remove(token)
                return True
            return False

    def node_count(self) -> int:
        with self._cv:
            return len(self._nodes)

    def add_callback_group(
        self,
        group_id: str,
        group_type: CallbackGroupType = CallbackGroupType.REENTRANT,
    ) -> None:
        if not group_id:
            raise ValueError("group_id must not be empty")
        with self._cv:
            self._callback_groups[group_id] = group_type

    def remove_callback_group(self, group_id: str) -> bool:
        with self._cv:
            return self._callback_groups.pop(group_id, None) is not None

    def callback_group_count(self) -> int:
        with self._cv:
            return len(self._callback_groups)

    def shutdown(self) -> None:
        with self._cv:
            if self._shutdown:
                return
            self._shutdown = True
            self._cv.notify_all()

        for t in self._workers:
            t.join(timeout=1.0)

    def __del__(self) -> None:
        try:
            self.shutdown()
        except Exception:
            pass
