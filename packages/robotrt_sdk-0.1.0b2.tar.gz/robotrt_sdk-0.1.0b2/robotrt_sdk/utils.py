from __future__ import annotations

import ctypes
from typing import Any

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .buffer import BufferLease


class LeaseView:
    def __init__(self, lease: "BufferLease", address: int, length: int) -> None:
        self._lease = lease
        self._length = length
        if length == 0:
            self._array = (ctypes.c_uint8 * 0)()
        else:
            self._array = (ctypes.c_uint8 * length).from_address(address)

    def as_memoryview(self) -> memoryview:
        return memoryview(self._array).cast("B").toreadonly()

    def __enter__(self) -> "LeaseView":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None


def as_u8_ptr(payload: bytes | bytearray | memoryview) -> tuple[Any, int, Any]:
    view = memoryview(payload).cast("B")
    if len(view) == 0:
        return ctypes.POINTER(ctypes.c_uint8)(), 0, None
    keepalive = (ctypes.c_uint8 * len(view)).from_buffer_copy(view)
    return keepalive, len(view), keepalive
