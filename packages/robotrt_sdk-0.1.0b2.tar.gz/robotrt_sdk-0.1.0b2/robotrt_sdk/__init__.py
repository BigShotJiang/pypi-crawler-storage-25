from ._ffi import _CORE
from ._version import __version__
from .core import (
    ActionClient,
    ActionGoalHealth,
    ActionServer,
    BackpressureSignal,
    CallbackGroupType,
    BufferDescriptor,
    BufferLease,
    ExternalBufferRef,
    LeaseView,
    MissionSession,
    Node,
    Publisher,
    CallbackExecutor,
    MultiThreadExecutor,
    MultiThreadExecutorStats,
    RegisteredWork,
    RegisteredWorkKind,
    ServiceClient,
    ServiceServer,
    SimpleExecutor,
    Subscriber,
    TimerRegistration,
)
from .errors import ErrorInfo, RobotRtError
from .status import StatusClient

__all__ = [
    "BufferDescriptor",
    "BufferLease",
    "ErrorInfo",
    "LeaseView",
    "Node",
    "Publisher",
    "Subscriber",
    "ServiceClient",
    "ServiceServer",
    "ActionClient",
    "ActionGoalHealth",
    "ActionServer",
    "BackpressureSignal",
    "CallbackGroupType",
    "CallbackExecutor",
    "ExternalBufferRef",
    "MissionSession",
    "MultiThreadExecutor",
    "MultiThreadExecutorStats",
    "RobotRtError",
    "RegisteredWork",
    "RegisteredWorkKind",
    "StatusClient",
    "SimpleExecutor",
    "TimerRegistration",
    "__version__",
    "abi_version",
    "protocol_version",
]


def abi_version() -> int:
    return int(_CORE.lib.robotrt_core_abi_version())


def protocol_version() -> int:
    return int(_CORE.lib.robotrt_core_protocol_version())
