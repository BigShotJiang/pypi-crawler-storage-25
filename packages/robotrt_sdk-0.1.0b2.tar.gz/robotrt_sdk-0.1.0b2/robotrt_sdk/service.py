from __future__ import annotations

import ctypes

from ._ffi import _CORE
from .utils import as_u8_ptr


class ServiceClient:
    def __init__(self, handle: ctypes.c_void_p) -> None:
        self._handle = handle
        self._closed = False

    def call(self, payload: bytes | bytearray | memoryview) -> int:
        ptr, n, _keepalive = as_u8_ptr(payload)
        request_id = ctypes.c_uint64(0)
        status = _CORE.lib.robotrt_service_client_call(self._handle, ptr, n, ctypes.byref(request_id))
        _CORE.check(status, "robotrt_service_client_call")
        return int(request_id.value)

    def call_with_deadline(self, payload: bytes | bytearray | memoryview, deadline_unix_nanos: int) -> int:
        ptr, n, _keepalive = as_u8_ptr(payload)
        request_id = ctypes.c_uint64(0)
        status = _CORE.lib.robotrt_service_client_call_with_deadline(
            self._handle,
            ptr,
            n,
            int(deadline_unix_nanos),
            ctypes.byref(request_id),
        )
        _CORE.check(status, "robotrt_service_client_call_with_deadline")
        return int(request_id.value)

    def cancel(self, request_id: int) -> None:
        status = _CORE.lib.robotrt_service_client_cancel(self._handle, int(request_id))
        _CORE.check(status, "robotrt_service_client_cancel")

    def poll_response(self, request_id: int, *, cap: int = 1024 * 1024) -> bytes | None:
        buf = (ctypes.c_uint8 * cap)()
        copied = ctypes.c_uint64(0)
        has_response = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_service_client_poll_response(
            self._handle,
            int(request_id),
            buf,
            cap,
            ctypes.byref(copied),
            ctypes.byref(has_response),
        )
        _CORE.check(status, "robotrt_service_client_poll_response")
        if has_response.value == 0:
            return None
        return bytes(memoryview(buf)[: copied.value])

    def close(self) -> None:
        if self._closed:
            return
        status = _CORE.lib.robotrt_service_client_destroy(self._handle)
        _CORE.check(status, "robotrt_service_client_destroy")
        self._closed = True

    def __enter__(self) -> "ServiceClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass


class ServiceServer:
    def __init__(self, handle: ctypes.c_void_p) -> None:
        self._handle = handle
        self._closed = False

    def recv_request(self, *, cap: int = 1024 * 1024) -> tuple[int, bytes] | None:
        request_id = ctypes.c_uint64(0)
        buf = (ctypes.c_uint8 * cap)()
        copied = ctypes.c_uint64(0)
        has_request = ctypes.c_uint8(0)
        status = _CORE.lib.robotrt_service_server_recv_request(
            self._handle,
            ctypes.byref(request_id),
            buf,
            cap,
            ctypes.byref(copied),
            ctypes.byref(has_request),
        )
        _CORE.check(status, "robotrt_service_server_recv_request")
        if has_request.value == 0:
            return None
        return int(request_id.value), bytes(memoryview(buf)[: copied.value])

    def reply(self, request_id: int, payload: bytes | bytearray | memoryview) -> None:
        ptr, n, _keepalive = as_u8_ptr(payload)
        status = _CORE.lib.robotrt_service_server_reply(self._handle, int(request_id), ptr, n)
        _CORE.check(status, "robotrt_service_server_reply")

    def reply_error(
        self,
        request_id: int,
        *,
        code: int,
        domain: int,
        retryable: bool,
        detail: str,
    ) -> None:
        status = _CORE.lib.robotrt_service_server_reply_error(
            self._handle,
            int(request_id),
            int(code),
            int(domain),
            ctypes.c_uint8(1 if retryable else 0),
            detail.encode("utf-8"),
        )
        _CORE.check(status, "robotrt_service_server_reply_error")

    def close(self) -> None:
        if self._closed:
            return
        status = _CORE.lib.robotrt_service_server_destroy(self._handle)
        _CORE.check(status, "robotrt_service_server_destroy")
        self._closed = True

    def __enter__(self) -> "ServiceServer":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass
