from __future__ import annotations

import os
import platform
import subprocess
import unittest
from pathlib import Path


def _workspace_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _dylib_name() -> str:
    system = platform.system().lower()
    if system == "darwin":
        return "librobotrt_core_ffi.dylib"
    if system == "windows":
        return "robotrt_core_ffi.dll"
    return "librobotrt_core_ffi.so"


def _find_core_ffi_dylib(root: Path) -> Path | None:
    direct = root / "target" / "debug" / _dylib_name()
    if direct.exists():
        return direct

    deps = root / "target" / "debug" / "deps"
    if deps.exists():
        for candidate in sorted(deps.iterdir()):
            if candidate.suffix not in {".dylib", ".so", ".dll"}:
                continue
            if candidate.name.startswith("librobotrt_core_ffi") or candidate.name == _dylib_name():
                return candidate
    return None


def _bootstrap_library() -> None:
    root = _workspace_root()
    dylib = _find_core_ffi_dylib(root)
    if dylib is None:
        subprocess.run(["cargo", "build", "-p", "core-ffi", "--lib"], cwd=root, check=True)
        dylib = _find_core_ffi_dylib(root)
    if dylib is None:
        raise RuntimeError("core-ffi dynamic library not found after cargo build")
    os.environ.setdefault("ROBOTRT_CORE_FFI_LIB", str(dylib))


_bootstrap_library()

import robotrt_sdk as sdk


class DataPlaneBatchTests(unittest.TestCase):
    def test_publish_and_recv_batch_order(self) -> None:
        with sdk.Node.create() as node:
            with node.create_publisher("/demo/batch/order") as pub, node.create_subscriber("/demo/batch/order") as sub:
                payloads = [b"m0", b"m1", b"m2", b"m3"]
                accepted = pub.publish_batch(payloads)
                self.assertEqual(accepted, len(payloads))

                recv = sub.recv_batch(8)
                self.assertEqual(recv, payloads)
                self.assertEqual(sub.backpressure_signal(), sdk.BackpressureSignal.CLEAR)

    def test_publish_buffer_batch_accepts_refs(self) -> None:
        with sdk.Node.create() as node:
            with node.create_publisher("/demo/batch/buffer") as pub:
                refs = [
                    sdk.ExternalBufferRef(buffer_id=101, offset=0, len=32),
                    sdk.ExternalBufferRef(buffer_id=102, offset=64, len=16),
                ]
                accepted = pub.publish_buffer_batch(refs)
                self.assertEqual(accepted, len(refs))

    def test_backpressure_signal_soft_hard_and_recover(self) -> None:
        with sdk.Node.create() as node:
            topic = "/demo/batch/backpressure"
            with node.create_publisher(topic) as pub, node.create_subscriber(topic) as sub:
                qos = node.topic_qos(topic)
                self.assertIsNotNone(qos)
                depth = int(qos["depth"]) if qos is not None else 16

                soft_threshold = max(1, (depth * 8 + 9) // 10)
                for i in range(soft_threshold):
                    pub.publish(f"soft-{i}".encode("utf-8"))
                self.assertIn(
                    sub.backpressure_signal(),
                    (sdk.BackpressureSignal.SOFT, sdk.BackpressureSignal.HARD),
                )

                for i in range(soft_threshold, depth):
                    pub.publish(f"fill-{i}".encode("utf-8"))
                self.assertEqual(sub.backpressure_signal(), sdk.BackpressureSignal.HARD)

                with self.assertRaises(sdk.RobotRtError):
                    pub.publish(b"overflow")
                self.assertEqual(pub.backpressure_signal(), sdk.BackpressureSignal.HARD)

                drained = sub.recv_batch(depth)
                self.assertEqual(len(drained), depth)

                # Reliable subscribers must ack consumed messages to release capacity.
                for _ in drained:
                    sub.ack()

                pub.publish(b"recovered")
                self.assertEqual(pub.backpressure_signal(), sdk.BackpressureSignal.CLEAR)
                self.assertEqual(sub.backpressure_signal(), sdk.BackpressureSignal.CLEAR)


if __name__ == "__main__":
    unittest.main()