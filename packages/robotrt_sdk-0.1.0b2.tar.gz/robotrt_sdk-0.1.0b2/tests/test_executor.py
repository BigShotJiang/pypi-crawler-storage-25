from __future__ import annotations

import os
import platform
import subprocess
import time
import unittest
from pathlib import Path


def _workspace_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _dylib_name() -> str:
    system = platform.system().lower()
    if system == "darwin":
        return "librobotrt_core_ffi.dylib"
    if system == "windows":
        return "robotrt_core_ffi.dll"
    return "librobotrt_core_ffi.so"


def _find_core_ffi_dylib(root: Path) -> Path | None:
    direct = root / "target" / "debug" / _dylib_name()
    if direct.exists():
        return direct

    deps = root / "target" / "debug" / "deps"
    if deps.exists():
        for candidate in sorted(deps.iterdir()):
            if candidate.suffix not in {".dylib", ".so", ".dll"}:
                continue
            if candidate.name.startswith("librobotrt_core_ffi") or candidate.name == _dylib_name():
                return candidate
    return None


def _bootstrap_library() -> None:
    root = _workspace_root()
    dylib = _find_core_ffi_dylib(root)
    if dylib is None:
        subprocess.run(["cargo", "build", "-p", "core-ffi", "--lib"], cwd=root, check=True)
        dylib = _find_core_ffi_dylib(root)
    if dylib is None:
        raise RuntimeError("core-ffi dynamic library not found after cargo build")
    os.environ.setdefault("ROBOTRT_CORE_FFI_LIB", str(dylib))


_bootstrap_library()

import robotrt_sdk as sdk


class ExecutorTests(unittest.TestCase):
    def test_node_identity_create(self) -> None:
        node = sdk.Node.create("py_node_p0", "/sdk")
        self.assertEqual(node.name(), "py_node_p0")
        self.assertEqual(node.namespace(), "/sdk")
        node.close()

    def test_simple_executor_queue_flow(self) -> None:
        executor = sdk.SimpleExecutor()
        executor.register_subscription("/demo/topic")
        executor.register_service("/demo/service")
        executor.register_action("/demo/action")

        drained = 0
        while executor.spin_once():
            drained += 1

        self.assertEqual(drained, 3)

        executor.shutdown()
        self.assertFalse(executor.spin_once())

    def test_timer_registration_validation(self) -> None:
        with self.assertRaises(ValueError):
            sdk.TimerRegistration.from_interval(0)
        with self.assertRaises(ValueError):
            sdk.TimerRegistration.from_interval(-1)

        timer = sdk.TimerRegistration.from_interval(1_000_000)
        self.assertGreater(timer.started_at_unix_nanos, 0)
        self.assertEqual(timer.interval_nanos, 1_000_000)

    def test_callback_executor_spin_once(self) -> None:
        executor = sdk.CallbackExecutor()
        timer_hits: list[int] = []

        executor.register_timer_handler(
            interval_nanos=1,
            handler=lambda now: timer_hits.append(now),
            start_at_unix_nanos=time.time_ns() - 1,
        )
        executor.register_subscription_handler("/demo/topic", lambda: 2)
        executor.register_service_handler("/demo/service", lambda: 1)
        executor.register_action_handler("/demo/action", lambda: 0)
        executor.register_mission_handler("/demo/mission", lambda: 1)

        self.assertEqual(executor.handler_count(), 5)
        self.assertTrue(executor.spin_once())
        self.assertGreaterEqual(len(timer_hits), 1)
        self.assertEqual(executor.last_work_count, 5)

        executor.shutdown()
        self.assertFalse(executor.spin_once())

    def test_multithread_executor_grouped_flow(self) -> None:
        executor = sdk.MultiThreadExecutor(worker_count=2, callback_group_enabled=True)

        for i in range(6):
            executor.register_subscription_grouped(
                f"/demo/reentrant/{i}",
                "group_reentrant",
                sdk.CallbackGroupType.REENTRANT,
            )
        for i in range(6):
            executor.register_subscription_grouped(
                f"/demo/mutex/{i}",
                "group_mutex",
                sdk.CallbackGroupType.MUTUALLY_EXCLUSIVE,
            )

        self.assertTrue(executor.wait_until_idle(timeout_s=2.0))
        stats = executor.stats_snapshot()
        self.assertGreaterEqual(stats.dispatched_work_total, 12)
        self.assertGreaterEqual(stats.grouped_work_total, 12)
        self.assertGreaterEqual(stats.max_parallelism, 2)
        self.assertGreaterEqual(stats.group_block_count, 1)

        executor.shutdown()
        self.assertFalse(executor.spin_once())

    def test_multithread_executor_handler_and_compat_surface(self) -> None:
        executor = sdk.MultiThreadExecutor(worker_count=2, callback_group_enabled=True, simulated_cost_s=0.0)

        node = object()
        executor.add_node(node)
        self.assertEqual(executor.node_count(), 1)
        executor.add_callback_group("g1", sdk.CallbackGroupType.MUTUALLY_EXCLUSIVE)
        self.assertEqual(executor.callback_group_count(), 1)

        executor.register_subscription_handler_grouped(
            "/demo/sub_handler_grouped",
            "g1",
            sdk.CallbackGroupType.MUTUALLY_EXCLUSIVE,
            lambda: 3,
        )
        executor.register_subscription_handler("/demo/sub_handler", lambda: 2)

        ok = executor.spin_until(lambda: executor.pending_count() == 0, timeout_s=2.0)
        self.assertTrue(ok)

        stats = executor.stats_snapshot()
        self.assertGreaterEqual(stats.completed_handler_work_total, 5)

        self.assertTrue(executor.remove_callback_group("g1"))
        self.assertTrue(executor.remove_node(node))
        self.assertEqual(executor.node_count(), 0)

        executor.shutdown()


if __name__ == "__main__":
    unittest.main()
