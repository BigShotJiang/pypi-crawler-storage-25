from __future__ import annotations

import platform
import socket
import subprocess
import time
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]


def _host_binary_name() -> str:
    if platform.system().lower().startswith("win"):
        return "robotrt-host.exe"
    return "robotrt-host"


def _host_binary() -> Path:
    candidate = ROOT / "target" / "debug" / _host_binary_name()
    if candidate.exists():
        return candidate

    subprocess.run(["cargo", "build", "-p", "robotrt-host"], cwd=ROOT, check=True)
    if candidate.exists():
        return candidate
    raise RuntimeError("robotrt-host binary not found after build")


def _allocate_udp_endpoint() -> str:
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.bind(("127.0.0.1", 0))
        host, port = sock.getsockname()
    return f"{host}:{port}"


def _wait_for_query(fn) -> None:
    last_error: Exception | None = None
    for _ in range(6):
        try:
            fn()
            return
        except Exception as exc:  # pragma: no cover - startup race retry
            last_error = exc
            time.sleep(0.15)
    raise RuntimeError(f"query failed after retries: {last_error}")


import robotrt_sdk as sdk


class StatusModeParityTests(unittest.TestCase):
    def test_embedded_mode_from_status_report(self) -> None:
        report = ROOT / "artifacts" / "introspection" / "local-loop-status.json"
        client = sdk.StatusClient(mode="embedded", report_path=report)

        snapshot = client.snapshot()
        self.assertIn("nodes", snapshot)
        self.assertIn("local_loop", client.node_list())
        self.assertIn("/demo/camera/raw", client.topic_list())

        node = client.node_info("local_loop")
        self.assertEqual(node["namespace"], "/demo")

        health = client.health()
        self.assertGreaterEqual(len(health), 1)

        graph = client.graph()
        self.assertGreaterEqual(len(graph), 1)

    def test_daemon_mode_query_and_watch(self) -> None:
        endpoint = _allocate_udp_endpoint()
        host_bin = _host_binary()

        child = subprocess.Popen(
            [
                str(host_bin),
                "gateway",
                "--bind",
                endpoint,
                "--source",
                "demo",
            ],
            cwd=ROOT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )

        client = sdk.StatusClient(mode="daemon", endpoint=endpoint, timeout_ms=2000)

        try:
            _wait_for_query(client.snapshot)
            self.assertIn("demo_node", client.node_list())
            self.assertIn("/demo/echo", client.service_list())

            info = client.node_info("demo_node")
            self.assertEqual(info["namespace"], "/demo")

            action = client.action_info("calibrate")
            self.assertEqual(action["name"], "/demo/calibrate")

            action_samples = client.action_watch("calibrate", iterations=2, interval_ms=50)
            self.assertEqual(len(action_samples), 2)
            self.assertEqual(action_samples[0]["iteration"], 1)

            mission_samples = client.mission_watch("demo_mission", iterations=2, interval_ms=50)
            self.assertEqual(len(mission_samples), 2)
            self.assertEqual(mission_samples[1]["iteration"], 2)
        finally:
            child.terminate()
            try:
                child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=3)
            if child.stderr is not None:
                child.stderr.close()

        self.assertIsNotNone(child.returncode)


if __name__ == "__main__":
    unittest.main()
