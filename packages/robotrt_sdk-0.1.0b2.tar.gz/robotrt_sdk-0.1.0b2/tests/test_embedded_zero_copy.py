from __future__ import annotations

import os
import platform
import subprocess
import unittest
from pathlib import Path


def _workspace_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _dylib_name() -> str:
    system = platform.system().lower()
    if system == "darwin":
        return "librobotrt_core_ffi.dylib"
    if system == "windows":
        return "robotrt_core_ffi.dll"
    return "librobotrt_core_ffi.so"


def _find_core_ffi_dylib(root: Path) -> Path | None:
    direct = root / "target" / "debug" / _dylib_name()
    if direct.exists():
        return direct

    deps = root / "target" / "debug" / "deps"
    if deps.exists():
        for candidate in sorted(deps.iterdir()):
            if candidate.suffix not in {".dylib", ".so", ".dll"}:
                continue
            if candidate.name.startswith("librobotrt_core_ffi") or candidate.name == _dylib_name():
                return candidate
    return None


def _bootstrap_library() -> None:
    root = _workspace_root()
    dylib = _find_core_ffi_dylib(root)
    if dylib is None:
        subprocess.run(["cargo", "build", "-p", "core-ffi", "--lib"], cwd=root, check=True)
        dylib = _find_core_ffi_dylib(root)
    if dylib is None:
        raise RuntimeError("core-ffi dynamic library not found after cargo build")
    os.environ.setdefault("ROBOTRT_CORE_FFI_LIB", str(dylib))


_bootstrap_library()

import robotrt_sdk as sdk


class EmbeddedZeroCopyTests(unittest.TestCase):
    def test_abi_probe(self) -> None:
        self.assertEqual(sdk.abi_version(), 1)
        self.assertEqual(sdk.protocol_version(), 1)

    def test_node_lifecycle_and_error_mapping(self) -> None:
        node = sdk.Node.create()
        raw_handle = node._handle
        node.close()

        status = sdk._CORE.lib.robotrt_node_destroy(raw_handle)
        self.assertNotEqual(status, 0)

        err = sdk._CORE.last_error()
        self.assertEqual(err.code, 6)
        self.assertEqual(err.domain, 0)
        self.assertIn("already", err.message)

    def test_zero_copy_descriptor_roundtrip_memoryview(self) -> None:
        payload = bytes((i % 251 for i in range(131072)))

        with sdk.BufferLease.from_bytes(payload) as lease:
            descriptor = lease.descriptor()
            self.assertEqual(descriptor.payload_len, len(payload))

            with sdk.BufferLease.open(descriptor) as opened:
                with opened.borrow_readonly() as borrowed:
                    view = borrowed.as_memoryview()
                    self.assertTrue(view.readonly)
                    self.assertEqual(len(view), len(payload))
                    self.assertEqual(view[:1024].tobytes(), payload[:1024])

                self.assertEqual(opened.read_bytes(2048, 256), payload[2048:2304])


if __name__ == "__main__":
    unittest.main()
