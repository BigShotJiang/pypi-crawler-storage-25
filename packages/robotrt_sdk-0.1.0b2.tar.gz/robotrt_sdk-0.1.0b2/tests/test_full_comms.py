from __future__ import annotations

import os
import platform
import subprocess
import unittest
from pathlib import Path


def _workspace_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _dylib_name() -> str:
    system = platform.system().lower()
    if system == "darwin":
        return "librobotrt_core_ffi.dylib"
    if system == "windows":
        return "robotrt_core_ffi.dll"
    return "librobotrt_core_ffi.so"


def _find_core_ffi_dylib(root: Path) -> Path | None:
    direct = root / "target" / "debug" / _dylib_name()
    if direct.exists():
        return direct

    deps = root / "target" / "debug" / "deps"
    if deps.exists():
        for candidate in sorted(deps.iterdir()):
            if candidate.suffix not in {".dylib", ".so", ".dll"}:
                continue
            if candidate.name.startswith("librobotrt_core_ffi") or candidate.name == _dylib_name():
                return candidate
    return None


def _bootstrap_library() -> None:
    root = _workspace_root()
    dylib = _find_core_ffi_dylib(root)
    if dylib is None:
        subprocess.run(["cargo", "build", "-p", "core-ffi", "--lib"], cwd=root, check=True)
        dylib = _find_core_ffi_dylib(root)
    if dylib is None:
        raise RuntimeError("core-ffi dynamic library not found after cargo build")
    os.environ.setdefault("ROBOTRT_CORE_FFI_LIB", str(dylib))


_bootstrap_library()

import robotrt_sdk as sdk


class FullCommunicationTests(unittest.TestCase):
    def test_pubsub_service_action_mission(self) -> None:
        with sdk.Node.create() as node:
            node.declare_param("robot.mode", "test")
            self.assertEqual(node.get_param("robot.mode"), "test")
            self.assertIsNone(node.get_param("missing.key"))
            self.assertIn("topics", node.discovery_snapshot())

            with node.create_publisher("demo_topic") as pub, node.create_subscriber("demo_topic") as sub:
                pub.publish(b"hello-pubsub")
                pub.publish_buffer(sdk.ExternalBufferRef(buffer_id=1, offset=0, len=5))
                pub.flush()
                qos = node.topic_qos("demo_topic")
                self.assertIsNotNone(qos)
                self.assertTrue(bool((qos or {}).get("reliable")))
                self.assertGreaterEqual(sub.pending_count(), 1)
                self.assertEqual(sub.recv(), b"hello-pubsub")
                sub.ack()

            with node.create_service_server("demo_service") as server, node.create_service_client("demo_service") as client:
                req_id = client.call(b"ping")
                got = server.recv_request()
                self.assertIsNotNone(got)
                got_id, payload = got or (0, b"")
                self.assertEqual(got_id, req_id)
                self.assertEqual(payload, b"ping")
                server.reply(got_id, b"pong")
                self.assertEqual(client.poll_response(req_id), b"pong")
                client.cancel(req_id)

            with node.create_action_server("demo_action") as server, node.create_action_client("demo_action") as client:
                goal_id, accepted = client.send_goal(b"goal-1")
                self.assertTrue(accepted)
                goal = server.recv_goal()
                self.assertIsNotNone(goal)
                recv_goal_id, recv_goal_payload = goal or (0, b"")
                self.assertEqual(recv_goal_id, goal_id)
                self.assertEqual(recv_goal_payload, b"goal-1")

                server.accept_goal(goal_id)
                server.heartbeat(goal_id)
                self.assertIsNotNone(client.goal_status(goal_id))
                self.assertIsNotNone(client.goal_health(goal_id))
                self.assertGreaterEqual(len(client.active_goal_health()), 1)
                server.publish_feedback(goal_id, b"50%")
                self.assertEqual(client.poll_feedback(goal_id), b"50%")
                self.assertGreaterEqual(client.tick_timeouts(), 0)

                server.succeed(goal_id, b"done")
                result = client.poll_result(goal_id)
                self.assertIsNotNone(result)
                self.assertEqual(result["status"], 3)
                self.assertEqual(result["payload"], b"done")

            with node.create_mission_session(42) as mission:
                mission.open("demo-mission")
                self.assertTrue(mission.send_command("start:demo"))

                mission.reconcile("cp-1", 2)
                first = mission.next_update()
                second = mission.next_update()
                self.assertIsNotNone(first)
                self.assertIsNotNone(second)

                mission.complete_replay(1)
                mission.complete_replay(1)
                mission.heartbeat()
                mission.send_update({"kind": "Progress", "current": 1, "total": 2})
                mission.send_update_text("operator-warning")

                seen_warning = False
                for _ in range(10):
                    item = mission.next_update()
                    if item is None:
                        continue
                    if item.get("kind") == "Warning":
                        seen_warning = True
                        break
                self.assertTrue(seen_warning)


if __name__ == "__main__":
    unittest.main()
