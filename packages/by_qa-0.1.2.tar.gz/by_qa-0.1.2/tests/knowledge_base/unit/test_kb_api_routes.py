"""Tests for knowledge-base API routes."""

from fastapi.testclient import TestClient

from by_qa.knowledge_base.api import routes
from by_qa.knowledge_base.api.schemas import (
    CreateDirectoryResponse,
    CreateKnowledgeBaseResponse,
    DeleteDirectoryResponse,
    DeleteKnowledgeBaseResponse,
    DeleteKnowledgeItemResponse,
    KnowledgeItemListDirItem,
    KnowledgeItemListDirResponse,
    KnowledgeItemUploadResponse,
    SearchHit,
    UpdateDirectoryResponse,
    UpdateKnowledgeBaseResponse,
)
from by_qa.knowledge_base.services.errors import (
    KnowledgeBaseConfigurationError,
    KnowledgeBaseValidationError,
)
from by_qa.main import app


class FakeKBService:
    """Service double used by route tests."""

    def __init__(self):
        self.created_requests = []
        self.created_directory_requests = []
        self.import_calls = []

    def create_knowledge_base(self, request):
        self.created_requests.append(request)
        return CreateKnowledgeBaseResponse(
            kb_code="7",
            kb_name=request.kb_name,
            kb_description=request.kb_description,
        )

    def create_directory(self, request):
        self.created_directory_requests.append(request)
        return CreateDirectoryResponse(
            kb_code=request.kb_code,
            directory_path=request.directory_path,
            directory_description=request.directory_description,
        )

    def delete_directory(self, request):
        return DeleteDirectoryResponse(
            kb_code=request.kb_code,
            directory_path=request.directory_path,
            is_deleted=True,
        )

    def update_directory(self, request):
        return UpdateDirectoryResponse(
            kb_code=request.kb_code,
            directory_path="/考勤制度/历史归档",
            directory_name=request.directory_name,
        )

    def delete_knowledge_base(self, request):
        return DeleteKnowledgeBaseResponse(kb_code=request.kb_code, is_deleted=True)

    def update_knowledge_base(self, request):
        return UpdateKnowledgeBaseResponse(
            kb_code=request.kb_code,
            kb_name=request.kb_name or "人力制度知识库",
            kb_description=request.kb_description,
        )

    def delete_knowledge_item(self, request):
        return DeleteKnowledgeItemResponse(
            kb_code=request.kb_code,
            file_path=request.file_path,
            is_deleted=True,
        )

    def upload_file(self, request):
        self.import_calls.append(request)
        return KnowledgeItemUploadResponse(
            kb_code=request.kb_code,
            file_path=request.file_path,
            file_description=request.file_description,
        )

    def file_to_markdown_index(  # pylint: disable=unused-argument
        self, request, *, document_chunking_service
    ):
        return None

    def search_v2(self, request):
        return [
            SearchHit(
                kn_code="hr-policy",
                file_path="/employee-handbook.md",
                chunk_no=1,
                chunk_id=42,
                chunk_text="员工请假应至少提前一天提交申请。",
                score=0.91,
                image_path="",
                start_line=1,
                end_line=3,
            )
        ]

    def list_dir(self, request):
        return KnowledgeItemListDirResponse(
            items=[
                KnowledgeItemListDirItem(
                    kb_code=request.kb_code,
                    name="/dir1/doc.md",
                    type="file",
                    size=100,
                )
            ]
        )

    def glob(self, request):
        return KnowledgeItemListDirResponse(
            items=[
                KnowledgeItemListDirItem(
                    kb_code=request.kb_code,
                    name="/dir1/doc.md",
                    type="file",
                    size=100,
                )
            ]
        )

    def read_file(self, request):
        return {
            "knCode": request.kb_code,
            "filePath": request.file_path,
            "startLine": request.start_line,
            "endLine": request.end_line,
            "data": "line1\nline2\n",
            "reachedEof": True,
        }

    def download_file(self, request):
        return {
            "filename": "doc.pdf",
            "media_type": "application/pdf",
            "content": b"%PDF-1.4 test payload",
        }


def make_test_client(monkeypatch, service):
    """Create a TestClient with unrelated startup dependencies stubbed out."""
    monkeypatch.setattr("by_qa.main.get_knowledge_base_service", lambda: service)
    monkeypatch.setattr(
        "by_qa.main.get_knowledge_item_ingestion_service", lambda: service
    )
    monkeypatch.setattr("by_qa.main.get_knowledge_item_search_service", lambda: service)
    monkeypatch.setattr("by_qa.main.get_document_chunking_service", lambda: object())
    monkeypatch.setattr("by_qa.main.get_adapter", lambda: object())
    monkeypatch.setattr("by_qa.main.get_instant_search_engine", lambda: object())
    return TestClient(app)


def test_create_knowledge_base_route_returns_business_response(monkeypatch):
    """POST /api/v1/knowledgeBases/create should delegate to the KB service."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)
    response = client.post(
        "/api/v1/knowledgeBases/create",
        json={
            "knName": "人力制度知识库",
            "knDescription": "公司人事制度与流程文档",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "0",
        "resultMsg": "success",
        "resultObject": {
            "knCode": "7",
            "knName": "人力制度知识库",
            "knDescription": "公司人事制度与流程文档",
        },
    }
    assert service.created_requests[0].kb_name == "人力制度知识库"


def test_create_knowledge_base_route_emits_summary_logs(monkeypatch):
    """Create route should emit request, key-step, and response summary logs."""
    service = FakeKBService()
    info_messages: list[str] = []

    monkeypatch.setattr(
        routes.logger,
        "info",
        lambda message, *args, **kwargs: info_messages.append(
            message % args if args else message
        ),
    )
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/knowledgeBases/create",
        json={
            "knName": "人力制度知识库",
            "knDescription": "公司人事制度与流程文档",
        },
    )

    assert response.status_code == 200
    assert info_messages == [
        "create_knowledge_base request received: kb_name=人力制度知识库, has_description=True",
        "create_knowledge_base resolved service: service_class=FakeKBService",
        "create_knowledge_base service call succeeded: kb_code=7",
        "create_knowledge_base response ready: code=200, kb_code=7",
    ]


def test_create_knowledge_base_route_maps_request_validation_to_documented_error(
    monkeypatch,
):
    """Create-knowledge-base validation should use the documented error envelope."""
    client = make_test_client(monkeypatch, FakeKBService())

    response = client.post(
        "/api/v1/knowledgeBases/create",
        json={"knDescription": "公司人事制度与流程文档"},
    )

    assert response.status_code == 200
    assert response.json()["resultCode"] == "-1"
    assert response.json()["resultMsg"] == "request validation failed"
    assert response.json()["resultObject"]["errors"]


def test_create_knowledge_base_route_maps_duplicate_name_to_documented_error(
    monkeypatch,
):
    """Create-knowledge-base duplicate names should use the documented error envelope."""

    class DuplicateNameKBService(FakeKBService):
        def create_knowledge_base(self, request):
            raise KnowledgeBaseValidationError(
                f"knowledge base name already exists: {request.kb_name}"
            )

    client = make_test_client(monkeypatch, DuplicateNameKBService())
    response = client.post(
        "/api/v1/knowledgeBases/create",
        json={"knName": "人力制度知识库"},
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "knowledge base name already exists: 人力制度知识库",
        "resultObject": {},
    }


def test_delete_knowledge_base_route_returns_business_response(monkeypatch):
    """Delete-knowledge-base route should delegate to the KB service."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/knowledgeBases/delete",
        json={"knCode": "hr-policy"},
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "0",
        "resultMsg": "success",
        "resultObject": {},
    }


def test_update_knowledge_base_route_returns_business_response(monkeypatch):
    """Update-knowledge-base route should delegate to the KB service."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/knowledgeBases/update",
        json={
            "knCode": "hr-policy",
            "knName": "新知识库名称",
            "knDescription": "更新后的描述",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "0",
        "resultMsg": "success",
        "resultObject": {},
    }


def test_update_knowledge_base_route_maps_duplicate_name_to_documented_error(
    monkeypatch,
):
    """Update-knowledge-base duplicate names should use the documented error envelope."""

    class DuplicateNameKBService(FakeKBService):
        def update_knowledge_base(self, request):
            raise KnowledgeBaseValidationError(
                f"knowledge base name already exists: {request.kb_name}"
            )

    client = make_test_client(monkeypatch, DuplicateNameKBService())
    response = client.post(
        "/api/v1/knowledgeBases/update",
        json={"knCode": "hr-policy", "knName": "人力制度知识库"},
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "knowledge base name already exists: 人力制度知识库",
        "resultObject": {},
    }


def test_update_knowledge_base_route_maps_unexpected_exception_to_documented_error(
    monkeypatch,
):
    """Update-knowledge-base unexpected failures should use the documented error envelope."""

    class BrokenKBService(FakeKBService):
        def update_knowledge_base(self, request):
            raise RuntimeError('column "kb_code" does not exist')

    client = make_test_client(monkeypatch, BrokenKBService())
    response = client.post(
        "/api/v1/knowledgeBases/update",
        json={"knCode": "7", "knName": "人力制度知识库"},
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": 'column "kb_code" does not exist',
        "resultObject": {},
    }


def test_create_directory_route_returns_business_response(monkeypatch):
    """Create-directory route should delegate to the KB service."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/directories/create",
        json={
            "knCode": "hr-policy",
            "directoryPath": "/考勤制度/归档",
            "directoryDescription": "考勤制度归档目录",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "0",
        "resultMsg": "success",
        "resultObject": {},
    }


def test_delete_directory_route_returns_business_response(monkeypatch):
    """Delete-directory route should delegate to the KB service."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/directories/delete",
        json={
            "knCode": "hr-policy",
            "directoryPath": "/考勤制度/归档",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "0",
        "resultMsg": "success",
        "resultObject": {},
    }


def test_delete_directory_route_maps_missing_directory_to_documented_error(monkeypatch):
    """Delete-directory should use the documented error envelope when the directory does not exist."""

    class BrokenKBService(FakeKBService):
        def delete_directory(self, request):
            raise KnowledgeBaseValidationError(
                f"directory not found: {request.directory_path}"
            )

    client = make_test_client(monkeypatch, BrokenKBService())
    response = client.post(
        "/api/v1/directories/delete",
        json={
            "knCode": "hr-policy",
            "directoryPath": "/考勤制度/归档",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "directory not found: /考勤制度/归档",
        "resultObject": {},
    }


def test_update_directory_route_returns_business_response(monkeypatch):
    """Update-directory route should delegate to the KB service."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/directories/update",
        json={
            "knCode": "hr-policy",
            "directoryPath": "/考勤制度/归档",
            "directoryName": "历史归档",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "0",
        "resultMsg": "success",
        "resultObject": {},
    }


def test_update_directory_route_maps_name_conflict_to_documented_error(monkeypatch):
    """Update-directory should use the documented error envelope for sibling name conflicts."""

    class BrokenKBService(FakeKBService):
        def update_directory(self, request):
            raise KnowledgeBaseValidationError(
                f"directory name already exists under parent: {request.directory_name}"
            )

    client = make_test_client(monkeypatch, BrokenKBService())
    response = client.post(
        "/api/v1/directories/update",
        json={
            "knCode": "hr-policy",
            "directoryPath": "/考勤制度/归档",
            "directoryName": "历史归档",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "directory name already exists under parent: 历史归档",
        "resultObject": {},
    }


def test_update_directory_route_maps_request_validation_to_standard_error(monkeypatch):
    """Update-directory validation should use the documented error envelope."""
    client = make_test_client(monkeypatch, FakeKBService())

    response = client.post(
        "/api/v1/directories/update",
        json={
            "knCode": "hr-policy",
            "directoryPath": "/考勤制度/归档",
            "directoryName": "/考勤制度",
        },
    )

    assert response.status_code == 200
    assert response.json()["resultCode"] == "-1"
    assert response.json()["resultMsg"] == "request validation failed"
    assert response.json()["resultObject"]["errors"]


def test_delete_knowledge_item_route_returns_business_response(monkeypatch):
    """Delete-knowledge-item route should delegate to the ingestion service."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/knowledge-items/delete",
        json={
            "knCode": "hr-policy",
            "filePath": "/考勤制度/异常考勤处理办法.pdf",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "0",
        "resultMsg": "success",
        "resultObject": {},
    }


def test_delete_knowledge_item_route_maps_request_validation_to_documented_error(
    monkeypatch,
):
    """Delete-knowledge-item route should return the documented validation envelope."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/knowledge-items/delete",
        json={"knCode": "hr-policy"},
    )

    assert response.status_code == 200
    assert response.json()["resultCode"] == "-1"
    assert response.json()["resultMsg"] == "request validation failed"
    assert response.json()["resultObject"]["errors"]


def test_list_dir_route_returns_filesystem_entries(monkeypatch):
    """List-dir route should delegate to the KB service."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/listDir",
        json={
            "knCode": "integration-kb",
            "directoryPath": "/dir1",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "0",
        "resultMsg": "success",
        "resultObject": {
            "data": [
                {
                    "knCode": "integration-kb",
                    "name": "/dir1/doc.md",
                    "type": "file",
                    "size": 100,
                }
            ]
        },
    }


def test_list_dir_route_emits_summary_logs(monkeypatch):
    """List-dir route should log request, service resolution, and response summary."""
    service = FakeKBService()
    info_messages: list[str] = []

    monkeypatch.setattr(
        routes.logger,
        "info",
        lambda message, *args, **kwargs: info_messages.append(
            message % args if args else message
        ),
    )
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/listDir",
        json={
            "knCode": "integration-kb",
            "directoryPath": "/dir1",
        },
    )

    assert response.status_code == 200
    assert info_messages == [
        "list_dir request received: kb_code=integration-kb, directory_path=/dir1",
        "list_dir resolved service: service_class=FakeKBService",
        "list_dir service call succeeded: directory_path=/dir1, item_count=1",
        "list_dir response ready: code=200, item_count=1",
    ]


def test_list_dir_route_requires_kb_codes(monkeypatch):
    """List-dir route should reject requests that omit knCode."""
    client = make_test_client(monkeypatch, FakeKBService())

    response = client.post(
        "/api/v1/listDir",
        json={
            "directoryPath": "/",
        },
    )

    assert response.status_code == 200
    assert response.json()["resultCode"] == "-1"
    assert response.json()["resultMsg"] == "request validation failed"
    assert response.json()["resultObject"]["errors"]


def test_list_dir_route_maps_validation_error_to_standard_error(monkeypatch):
    """List-dir business validation should use the standardized error envelope."""

    class BrokenKBService(FakeKBService):
        def list_dir(self, request):
            raise KnowledgeBaseValidationError("path contains invalid segments")

    client = make_test_client(monkeypatch, BrokenKBService())
    response = client.post(
        "/api/v1/listDir",
        json={
            "knCode": "integration-kb",
            "directoryPath": "../secret",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "path contains invalid segments",
        "resultObject": {},
    }


def test_list_dir_route_maps_missing_directory_to_documented_error(monkeypatch):
    """List-dir missing paths should map to the standardized not-found response."""

    class BrokenKBService(FakeKBService):
        def list_dir(self, request):
            raise KnowledgeBaseValidationError(
                f"directory not found: {request.directory_path}"
            )

    client = make_test_client(monkeypatch, BrokenKBService())
    response = client.post(
        "/api/v1/listDir",
        json={
            "knCode": "integration-kb",
            "directoryPath": "/missing-dir",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "directory not found: /missing-dir",
        "resultObject": {},
    }


def test_list_dir_route_maps_configuration_error_to_documented_error(monkeypatch):
    """List-dir configuration failures should use the standardized error envelope."""

    class BrokenKBService(FakeKBService):
        def list_dir(self, request):
            raise KnowledgeBaseConfigurationError("KB runtime is not configured")

    client = make_test_client(monkeypatch, BrokenKBService())
    response = client.post(
        "/api/v1/listDir",
        json={
            "knCode": "integration-kb",
            "directoryPath": "/",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "KB runtime is not configured",
        "resultObject": {},
    }


def test_glob_route_returns_matching_entries(monkeypatch):
    """Glob route should delegate to the KB service."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/glob",
        json={
            "knCode": "integration-kb",
            "pathRule": "/dir1/*.md",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "0",
        "resultMsg": "success",
        "resultObject": {
            "data": [
                {
                    "knCode": "integration-kb",
                    "name": "/dir1/doc.md",
                    "type": "file",
                    "size": 100,
                }
            ]
        },
    }


def test_glob_route_requires_kb_codes(monkeypatch):
    """Glob route should reject requests that omit knCode."""
    client = make_test_client(monkeypatch, FakeKBService())

    response = client.post(
        "/api/v1/glob",
        json={
            "pathRule": "/*.md",
        },
    )

    assert response.status_code == 200
    assert response.json()["resultCode"] == "-1"
    assert response.json()["resultMsg"] == "request validation failed"
    assert response.json()["resultObject"]["errors"]


def test_glob_route_maps_validation_error_to_standard_error(monkeypatch):
    """Glob business validation should use the standardized error envelope."""

    class BrokenKBService(FakeKBService):
        def glob(self, request):
            raise KnowledgeBaseValidationError("path contains invalid segments")

    client = make_test_client(monkeypatch, BrokenKBService())
    response = client.post(
        "/api/v1/glob",
        json={
            "knCode": "integration-kb",
            "pathRule": "../secret",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "path contains invalid segments",
        "resultObject": {},
    }


def test_glob_route_maps_configuration_error_to_documented_error(monkeypatch):
    """Glob configuration failures should use the standardized error envelope."""

    class BrokenKBService(FakeKBService):
        def glob(self, request):
            raise KnowledgeBaseConfigurationError("KB runtime is not configured")

    client = make_test_client(monkeypatch, BrokenKBService())
    response = client.post(
        "/api/v1/glob",
        json={
            "knCode": "integration-kb",
            "pathRule": "/*.md",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "KB runtime is not configured",
        "resultObject": {},
    }


def test_read_file_route_returns_requested_text(monkeypatch):
    """Read-file route should delegate to the KB service and return the documented envelope."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/readFile",
        json={
            "knCode": "hr-policy",
            "filePath": "/dir1/doc.md",
            "startLine": 1,
            "endLine": 2,
        },
    )

    assert response.status_code == 200
    body = response.json()
    assert body["resultCode"] == "0"
    assert body["resultMsg"] == "success"
    assert body["resultObject"] == {
        "knCode": "hr-policy",
        "filePath": "/dir1/doc.md",
        "startLine": 1,
        "endLine": 2,
        "data": "line1\nline2\n",
        "reachedEof": True,
    }


def test_read_file_route_returns_full_content_without_line_range(monkeypatch):
    """Read-file should return all content when startLine/endLine are omitted."""

    class FullReadKBService(FakeKBService):
        def read_file(self, request):
            return {
                "knCode": request.kb_code,
                "filePath": request.file_path,
                "data": "full content\n",
                "reachedEof": True,
            }

    client = make_test_client(monkeypatch, FullReadKBService())
    response = client.post(
        "/api/v1/readFile",
        json={
            "knCode": "hr-policy",
            "filePath": "/dir1/doc.md",
        },
    )

    assert response.status_code == 200
    body = response.json()
    assert body["resultCode"] == "0"
    assert body["resultObject"]["data"] == "full content\n"
    assert body["resultObject"]["reachedEof"] is True


def test_download_file_route_returns_binary_stream(monkeypatch):
    """Download-file should return raw file bytes with attachment headers."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/downloadFile",
        json={
            "knCode": "hr-policy",
            "filePath": "/dir1/doc.pdf",
        },
    )

    assert response.status_code == 200
    assert response.content == b"%PDF-1.4 test payload"
    assert response.headers["content-type"] == "application/pdf"
    assert response.headers["content-disposition"] == 'attachment; filename="doc.pdf"'


def test_download_file_route_supports_non_ascii_filename(monkeypatch):
    """Download-file should encode non-ASCII filenames safely in headers."""

    class UnicodeFilenameKBService(FakeKBService):
        def download_file(self, request):
            return {
                "filename": "开源项目最佳实践汇报.md",
                "media_type": "text/markdown",
                "content": b"# hello\n",
            }

    client = make_test_client(monkeypatch, UnicodeFilenameKBService())
    response = client.post(
        "/api/v1/downloadFile",
        json={
            "knCode": "demo",
            "filePath": "/考勤制度/开源项目最佳实践汇报.md",
        },
    )

    assert response.status_code == 200
    assert response.content == b"# hello\n"
    assert response.headers["content-type"].startswith("text/markdown")
    assert (
        response.headers["content-disposition"]
        == 'attachment; filename="download.md"; '
        "filename*=UTF-8''%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%E6%9C%80%E4%BD%B3%E5%AE%9E%E8%B7%B5%E6%B1%87%E6%8A%A5.md"
    )


def test_download_file_route_maps_validation_error_to_documented_error(monkeypatch):
    """Download-file validation errors should use the documented JSON envelope."""

    class BrokenKBService(FakeKBService):
        def download_file(self, request):
            raise KnowledgeBaseValidationError(f"file not found: {request.file_path}")

    client = make_test_client(monkeypatch, BrokenKBService())
    response = client.post(
        "/api/v1/downloadFile",
        json={"knCode": "hr-policy", "filePath": "/missing.pdf"},
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "file not found: /missing.pdf",
        "resultObject": {},
    }


def test_read_file_route_requires_kn_code(monkeypatch):
    """Read-file route should reject requests that omit knCode."""
    client = make_test_client(monkeypatch, FakeKBService())

    response = client.post(
        "/api/v1/readFile",
        json={
            "filePath": "/dir1/doc.md",
            "startLine": 1,
            "endLine": 2,
        },
    )

    assert response.status_code == 200
    body = response.json()
    assert body["resultCode"] == "-1"
    assert body["resultMsg"] == "request validation failed"


def test_read_file_route_maps_validation_error_to_documented_error(monkeypatch):
    """Read-file business validation should use the documented error envelope."""

    class BrokenKBService(FakeKBService):
        def read_file(self, request):
            raise KnowledgeBaseValidationError("startLine must be greater than 0")

    client = make_test_client(monkeypatch, BrokenKBService())
    response = client.post(
        "/api/v1/readFile",
        json={
            "knCode": "hr-policy",
            "filePath": "/dir1/doc.md",
            "startLine": 0,
            "endLine": 2,
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "startLine must be greater than 0",
        "resultObject": {},
    }


def test_read_file_route_maps_not_found_to_documented_error(monkeypatch):
    """Read-file missing files should use the documented error envelope."""

    class BrokenKBService(FakeKBService):
        def read_file(self, request):
            raise KnowledgeBaseValidationError(f"file not found: {request.file_path}")

    client = make_test_client(monkeypatch, BrokenKBService())
    response = client.post(
        "/api/v1/readFile",
        json={
            "knCode": "hr-policy",
            "filePath": "/dir1/missing.pdf",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "file not found: /dir1/missing.pdf",
        "resultObject": {},
    }


def test_read_file_route_maps_file_not_built_to_documented_error(monkeypatch):
    """Read-file should return an error when the file has not been built."""

    class NotBuiltKBService(FakeKBService):
        def read_file(self, request):
            raise KnowledgeBaseValidationError(f"file not built: {request.file_path}")

    client = make_test_client(monkeypatch, NotBuiltKBService())
    response = client.post(
        "/api/v1/readFile",
        json={
            "knCode": "hr-policy",
            "filePath": "/dir1/doc.pdf",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "file not built: /dir1/doc.pdf",
        "resultObject": {},
    }


def test_read_file_route_maps_configuration_error_to_documented_error(monkeypatch):
    """Read-file configuration failures should use the documented error envelope."""

    class BrokenKBService(FakeKBService):
        def read_file(self, request):
            raise KnowledgeBaseConfigurationError("read file runtime is not configured")

    client = make_test_client(monkeypatch, BrokenKBService())
    response = client.post(
        "/api/v1/readFile",
        json={
            "knCode": "hr-policy",
            "filePath": "/dir1/doc.md",
            "startLine": 1,
            "endLine": 2,
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "read file runtime is not configured",
        "resultObject": {},
    }


def test_create_knowledge_base_route_maps_configuration_error_to_documented_error(
    monkeypatch,
):
    """Missing KB runtime configuration should surface as a documented error response."""

    class MisconfiguredKBService(FakeKBService):
        def create_knowledge_base(self, request):
            raise KnowledgeBaseConfigurationError("KB_OPENGAUSS_DSN is required")

    client = make_test_client(monkeypatch, MisconfiguredKBService())
    response = client.post(
        "/api/v1/knowledgeBases/create",
        json={
            "knName": "人力制度知识库",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "KB_OPENGAUSS_DSN is required",
        "resultObject": {},
    }


def test_create_knowledge_base_route_maps_unexpected_exception_to_standard_error(
    monkeypatch,
):
    """Unexpected route failures should still use the standard KB error envelope."""

    class BrokenKBService(FakeKBService):
        def create_knowledge_base(self, request):
            raise RuntimeError("duplicate key value violates unique constraint")

    monkeypatch.setattr(
        "by_qa.main.get_knowledge_base_service", lambda: BrokenKBService()
    )
    monkeypatch.setattr(
        "by_qa.main.get_knowledge_item_ingestion_service", lambda: BrokenKBService()
    )
    monkeypatch.setattr(
        "by_qa.main.get_knowledge_item_search_service", lambda: BrokenKBService()
    )
    monkeypatch.setattr("by_qa.main.get_adapter", lambda: object())
    monkeypatch.setattr("by_qa.main.get_instant_search_engine", lambda: object())
    client = TestClient(app, raise_server_exceptions=False)
    response = client.post(
        "/api/v1/knowledgeBases/create",
        json={"knName": "Demo KB"},
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "duplicate key value violates unique constraint",
        "resultObject": {},
    }


def test_search_route_returns_chunk_oriented_business_response(monkeypatch):
    """Search route should delegate to the KB retrieval service."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/knowledge-items/search",
        json={
            "query": "员工请假制度怎么规定",
            "knCodeList": ["hr-policy"],
            "topK": 10,
            "searchMode": "mixedRecall",
        },
    )

    assert response.status_code == 200
    body = response.json()
    assert body["resultCode"] == "0"
    assert body["resultMsg"] == "success"
    hit = body["resultObject"]["data"][0]
    assert hit["knCode"] == "hr-policy"
    assert hit["filePath"] == "/employee-handbook.md"
    assert hit["chunkNo"] == 1
    assert hit["chunkId"] == 42
    assert hit["score"] == 0.91
    assert hit["imagePath"] == ""
    assert hit["startLine"] == 1
    assert hit["endLine"] == 3


def test_search_route_emits_summary_logs(monkeypatch):
    """Search route should emit sanitized request and response summary logs."""
    service = FakeKBService()
    info_messages: list[str] = []

    monkeypatch.setattr(
        routes.logger,
        "info",
        lambda message, *args, **kwargs: info_messages.append(
            message % args if args else message
        ),
    )
    client = make_test_client(monkeypatch, service)

    response = client.post(
        "/api/v1/knowledge-items/search",
        json={
            "query": "员工请假制度怎么规定",
            "knCodeList": ["hr-policy"],
            "topK": 10,
            "searchMode": "mixedRecall",
        },
    )

    assert response.status_code == 200
    assert info_messages == [
        "search_knowledge_items request received: query=员工请假制度怎么规定, kb_code_count=1, top_k=10, search_mode=mixedRecall",
        "search_knowledge_items service call succeeded: returned_count=1, top_k=10",
        "search_knowledge_items response ready: code=200, returned_count=1",
    ]


def test_search_route_maps_validation_error_to_documented_error(monkeypatch):
    """Search business validation should use the documented error envelope."""

    class BrokenSearchService(FakeKBService):
        def search_v2(self, request):
            raise KnowledgeBaseValidationError("knCodeList must not be empty")

    client = make_test_client(monkeypatch, BrokenSearchService())
    response = client.post(
        "/api/v1/knowledge-items/search",
        json={
            "query": "员工请假制度怎么规定",
            "knCodeList": ["hr-policy"],
            "topK": 5,
            "searchMode": "mixedRecall",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "knCodeList must not be empty",
        "resultObject": {},
    }


def test_search_route_maps_configuration_error_to_documented_error(monkeypatch):
    """Search configuration failures should use the documented error envelope."""

    class BrokenSearchService(FakeKBService):
        def search_v2(self, request):
            raise KnowledgeBaseConfigurationError(
                "EMBEDDING_BASE_URL is required for retrieval"
            )

    client = make_test_client(monkeypatch, BrokenSearchService())
    response = client.post(
        "/api/v1/knowledge-items/search",
        json={
            "query": "员工请假制度怎么规定",
            "knCodeList": ["hr-policy"],
            "topK": 5,
            "searchMode": "mixedRecall",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "resultCode": "-1",
        "resultMsg": "EMBEDDING_BASE_URL is required for retrieval",
        "resultObject": {},
    }


def test_search_route_rejects_invalid_search_mode(monkeypatch):
    """Search should reject requests with invalid searchMode."""
    client = make_test_client(monkeypatch, FakeKBService())
    response = client.post(
        "/api/v1/knowledge-items/search",
        json={
            "query": "test",
            "knCodeList": ["kb1"],
            "topK": 5,
            "searchMode": "invalidMode",
        },
    )

    assert response.status_code == 200
    assert response.json()["resultCode"] == "-1"
    assert response.json()["resultMsg"] == "request validation failed"


def test_search_route_rejects_non_positive_top_k(monkeypatch):
    """Search should reject requests with topK <= 0."""
    client = make_test_client(monkeypatch, FakeKBService())
    response = client.post(
        "/api/v1/knowledge-items/search",
        json={
            "query": "test",
            "knCodeList": ["kb1"],
            "topK": 0,
            "searchMode": "mixedRecall",
        },
    )

    assert response.status_code == 200
    assert response.json()["resultCode"] == "-1"
    assert response.json()["resultMsg"] == "request validation failed"


# ---------------------------------------------------------------------------
# fileToMarkdownIndex route tests
# ---------------------------------------------------------------------------


def test_file_to_markdown_index_success(monkeypatch):
    """POST /api/v1/fileToMarkdownIndex returns success envelope."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)
    response = client.post(
        "/api/v1/fileToMarkdownIndex",
        json={"knCode": "1", "filePath": "/制度/人事/请假制度.pdf"},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["resultCode"] == "0"
    assert body["resultMsg"] == "success"


def test_file_to_markdown_index_kb_not_found(monkeypatch):
    """POST /api/v1/fileToMarkdownIndex returns error when KB not found."""

    class FailingService(FakeKBService):
        def file_to_markdown_index(self, request, *, document_chunking_service):
            raise KnowledgeBaseValidationError(
                f"knowledge base not found: {request.kb_code}"
            )

    client = make_test_client(monkeypatch, FailingService())
    response = client.post(
        "/api/v1/fileToMarkdownIndex",
        json={"knCode": "999", "filePath": "/doc.pdf"},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["resultCode"] == "-1"
    assert "knowledge base not found" in body["resultMsg"]


def test_file_to_markdown_index_validation_error(monkeypatch):
    """POST /api/v1/fileToMarkdownIndex returns error on bad input."""
    service = FakeKBService()
    client = make_test_client(monkeypatch, service)
    response = client.post(
        "/api/v1/fileToMarkdownIndex",
        json={"knCode": "", "filePath": "/doc.pdf"},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["resultCode"] == "-1"
    assert body["resultMsg"] == "request validation failed"
