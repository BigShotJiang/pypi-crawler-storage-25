"""Persistence helpers for knowledge_fs_entry rows."""

from __future__ import annotations

import hashlib
from typing import Any


class KnowledgeFsEntryRepository:
    """Repository for filesystem entries backing knowledge items."""

    def create_directory_entry(
        self,
        cursor: Any,
        *,
        knowledge_base_id: int,
        full_path: str,
        directory_description: str | None = None,
    ) -> dict[str, Any] | None:
        """Create one directory node within one knowledge base path tree."""
        normalized_path = full_path.strip("/")
        if not normalized_path:
            raise ValueError("full_path must not be empty")

        current_parent_id: int | None = None
        current_path_ltree: str | None = None
        path_segments = normalized_path.split("/")

        for index, segment in enumerate(path_segments[:-1], start=1):
            existing = self._get_child_entry(
                cursor,
                knowledge_base_id=knowledge_base_id,
                parent_entry_id=current_parent_id,
                name=segment,
            )
            if existing is not None:
                if existing.get("entry_type") != "DIRECTORY":
                    missing_directory_path = "/".join(path_segments[:index])
                    raise ValueError(
                        f"parent directory not found: {missing_directory_path}"
                    )
                current_parent_id = self._row_id(existing)
                current_path_ltree = self._row_value(existing, "path_ltree")
                continue

            parent_directory = self._insert_directory_entry(
                cursor,
                knowledge_base_id=knowledge_base_id,
                parent_entry_id=current_parent_id,
                parent_path_ltree=current_path_ltree,
                name=segment,
                depth=index,
                description=None,
            )
            current_parent_id = self._row_id(parent_directory)
            current_path_ltree = self._row_value(parent_directory, "path_ltree")

        existing_directory = self._get_child_entry(
            cursor,
            knowledge_base_id=knowledge_base_id,
            parent_entry_id=current_parent_id,
            name=path_segments[-1],
        )
        if existing_directory is not None:
            raise ValueError(f"directory path already exists: {normalized_path}")

        return self._insert_directory_entry(
            cursor,
            knowledge_base_id=knowledge_base_id,
            parent_entry_id=current_parent_id,
            parent_path_ltree=current_path_ltree,
            name=path_segments[-1],
            depth=len(path_segments),
            description=directory_description,
        )

    def create_file_entry(
        self,
        cursor: Any,
        *,
        knowledge_base_id: int,
        full_path: str,
        file_description: str | None = None,
    ) -> dict[str, Any] | None:
        """Create one file entry under an existing parent directory."""
        normalized_path = full_path.strip("/")
        if not normalized_path:
            raise ValueError("full_path must not be empty")

        current_parent_id: int | None = None
        current_path_ltree: str | None = None
        path_segments = normalized_path.split("/")

        for index, segment in enumerate(path_segments[:-1], start=1):
            existing = self._get_child_entry(
                cursor,
                knowledge_base_id=knowledge_base_id,
                parent_entry_id=current_parent_id,
                name=segment,
            )
            if existing is not None:
                if existing.get("entry_type") != "DIRECTORY":
                    missing_directory_path = "/".join(path_segments[:index])
                    raise ValueError(
                        f"parent directory not found: {missing_directory_path}"
                    )
                current_parent_id = self._row_id(existing)
                current_path_ltree = self._row_value(existing, "path_ltree")
                continue

            parent_directory = self._insert_directory_entry(
                cursor,
                knowledge_base_id=knowledge_base_id,
                parent_entry_id=current_parent_id,
                parent_path_ltree=current_path_ltree,
                name=segment,
                depth=index,
                description=None,
            )
            current_parent_id = self._row_id(parent_directory)
            current_path_ltree = self._row_value(parent_directory, "path_ltree")

        existing_file = self._get_child_entry(
            cursor,
            knowledge_base_id=knowledge_base_id,
            parent_entry_id=current_parent_id,
            name=path_segments[-1],
        )
        if existing_file is not None:
            raise ValueError(f"file path already exists: /{normalized_path}")

        fetchone = getattr(cursor, "fetchone", None)
        label = self._path_label("f", len(path_segments), path_segments[-1])
        path_ltree = (
            f"{current_path_ltree}.{label}" if current_path_ltree is not None else label
        )
        cursor.execute(
            """
            INSERT INTO knowledge_fs_entry (
                knowledge_base_id,
                parent_entry_id,
                entry_type,
                is_root,
                name,
                path_ltree,
                depth,
                description,
                file_bucket_name,
                file_object_key,
                markdown_bucket_name,
                markdown_object_key,
                file_size,
                mime_type,
                checksum,
                line_count,
                created_at,
                updated_at
            )
            VALUES (
                %(knowledge_base_id)s,
                %(parent_entry_id)s,
                'FILE',
                FALSE,
                %(name)s,
                %(path_ltree)s::ltree,
                %(depth)s,
                %(description)s,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NOW(),
                NOW()
            )
            RETURNING kid, knowledge_base_id, parent_entry_id, path_ltree, name, entry_type, is_root, depth
            """,
            {
                "knowledge_base_id": knowledge_base_id,
                "parent_entry_id": current_parent_id,
                "name": path_segments[-1],
                "path_ltree": path_ltree,
                "depth": len(path_segments),
                "description": file_description,
            },
        )
        return fetchone() if callable(fetchone) else None

    def update_file_entry_storage(
        self,
        cursor: Any,
        *,
        fs_entry_id: int,
        file_description: str | None,
        file_bucket_name: str,
        file_object_key: str,
        file_size: int,
        mime_type: str,
        checksum: str,
    ) -> None:
        """Persist uploaded file object metadata on one file entry."""
        cursor.execute(
            """
            UPDATE knowledge_fs_entry
            SET description = %(description)s,
                file_bucket_name = %(file_bucket_name)s,
                file_object_key = %(file_object_key)s,
                file_size = %(file_size)s,
                mime_type = %(mime_type)s,
                checksum = %(checksum)s,
                updated_at = NOW()
            WHERE kid = %(fs_entry_id)s
              AND entry_type = 'FILE'
              AND is_deleted = FALSE
            """,
            {
                "fs_entry_id": fs_entry_id,
                "description": file_description,
                "file_bucket_name": file_bucket_name,
                "file_object_key": file_object_key,
                "file_size": file_size,
                "mime_type": mime_type,
                "checksum": checksum,
            },
        )

    def _insert_directory_entry(
        self,
        cursor: Any,
        *,
        knowledge_base_id: int,
        parent_entry_id: int | None,
        parent_path_ltree: str | None,
        name: str,
        depth: int,
        description: str | None,
    ) -> dict[str, Any] | None:
        """Insert one directory node under an existing parent."""
        fetchone = getattr(cursor, "fetchone", None)
        label = self._path_label("d", depth, name)
        path_ltree = (
            f"{parent_path_ltree}.{label}" if parent_path_ltree is not None else label
        )
        cursor.execute(
            """
            INSERT INTO knowledge_fs_entry (
                knowledge_base_id,
                parent_entry_id,
                entry_type,
                is_root,
                name,
                path_ltree,
                depth,
                description,
                created_at,
                updated_at
            )
            VALUES (
                %(knowledge_base_id)s,
                %(parent_entry_id)s,
                'DIRECTORY',
                FALSE,
                %(name)s,
                %(path_ltree)s::ltree,
                %(depth)s,
                %(description)s,
                NOW(),
                NOW()
            )
            RETURNING kid, knowledge_base_id, parent_entry_id, path_ltree, name, entry_type, is_root, depth
            """,
            {
                "knowledge_base_id": knowledge_base_id,
                "parent_entry_id": parent_entry_id,
                "name": name,
                "path_ltree": path_ltree,
                "depth": depth,
                "description": description,
            },
        )
        return fetchone() if callable(fetchone) else None

    def get_directory_by_path(
        self, cursor: Any, *, knowledge_base_id: int, full_path: str
    ) -> dict[str, Any] | None:
        """Look up one directory entry by its knowledge-base-relative path."""
        path_segments = [
            segment for segment in full_path.strip("/").split("/") if segment
        ]
        if not path_segments:
            return None
        current_parent_id: int | None = None
        current: dict[str, Any] | None = None
        for segment in path_segments:
            current = self._get_child_entry(
                cursor,
                knowledge_base_id=knowledge_base_id,
                parent_entry_id=current_parent_id,
                name=segment,
            )
            if current is None:
                return None
            current_parent_id = self._row_id(current)
        return current if current.get("entry_type") == "DIRECTORY" else None

    def get_file_by_path(
        self, cursor: Any, *, knowledge_base_id: int, full_path: str
    ) -> dict[str, Any] | None:
        """Look up one file entry by its knowledge-base-relative path."""
        path_segments = [
            segment for segment in full_path.strip("/").split("/") if segment
        ]
        if not path_segments:
            return None
        current_parent_id: int | None = None
        current: dict[str, Any] | None = None
        for segment in path_segments:
            current = self._get_child_entry(
                cursor,
                knowledge_base_id=knowledge_base_id,
                parent_entry_id=current_parent_id,
                name=segment,
            )
            if current is None:
                return None
            current_parent_id = self._row_id(current)
        if current is None or current.get("entry_type") != "FILE":
            return None
        return self._get_entry_by_id(cursor, entry_id=self._row_id(current))

    def list_children_by_parent_entry_id(
        self,
        cursor: Any,
        *,
        knowledge_base_id: int,
        parent_entry_id: int | None,
    ) -> list[dict[str, Any]]:
        """List direct children under one knowledge-base-relative directory."""
        if parent_entry_id is None:
            cursor.execute(
                """
                SELECT
                    fs.kid,
                    fs.knowledge_base_id,
                    fs.parent_entry_id,
                    fs.name,
                    CASE
                        WHEN fs.entry_type = 'DIRECTORY' THEN 'directory'
                        ELSE 'file'
                    END AS type,
                    CASE
                        WHEN fs.entry_type = 'DIRECTORY' THEN 0
                        ELSE COALESCE(fs.file_size, 0)
                    END AS size
                FROM knowledge_fs_entry fs
                WHERE fs.knowledge_base_id = %(knowledge_base_id)s
                  AND fs.parent_entry_id IS NULL
                  AND fs.is_deleted = FALSE
                ORDER BY
                    CASE WHEN fs.entry_type = 'DIRECTORY' THEN 0 ELSE 1 END,
                    lower(fs.name)
                """,
                {"knowledge_base_id": knowledge_base_id},
            )
        else:
            cursor.execute(
                """
                SELECT
                    fs.kid,
                    fs.knowledge_base_id,
                    fs.parent_entry_id,
                    fs.name,
                    CASE
                        WHEN fs.entry_type = 'DIRECTORY' THEN 'directory'
                        ELSE 'file'
                    END AS type,
                    CASE
                        WHEN fs.entry_type = 'DIRECTORY' THEN 0
                        ELSE COALESCE(fs.file_size, 0)
                    END AS size
                FROM knowledge_fs_entry fs
                WHERE fs.knowledge_base_id = %(knowledge_base_id)s
                  AND fs.parent_entry_id = %(parent_entry_id)s
                  AND fs.is_deleted = FALSE
                ORDER BY
                    CASE WHEN fs.entry_type = 'DIRECTORY' THEN 0 ELSE 1 END,
                    lower(fs.name)
                """,
                {
                    "knowledge_base_id": knowledge_base_id,
                    "parent_entry_id": parent_entry_id,
                },
            )
        return self._fetchall(cursor)

    def _get_entry_by_id(self, cursor: Any, *, entry_id: int) -> dict[str, Any] | None:
        cursor.execute(
            """
            SELECT
                kid,
                knowledge_base_id,
                parent_entry_id,
                path_ltree,
                name,
                entry_type,
                is_root,
                depth,
                description,
                file_bucket_name,
                file_object_key,
                markdown_bucket_name,
                markdown_object_key,
                file_size,
                mime_type,
                checksum
            FROM knowledge_fs_entry
            WHERE kid = %(entry_id)s
              AND is_deleted = FALSE
            """,
            {"entry_id": entry_id},
        )
        fetchone = getattr(cursor, "fetchone", None)
        return fetchone() if callable(fetchone) else None

    def _get_child_entry(
        self,
        cursor: Any,
        *,
        knowledge_base_id: int,
        parent_entry_id: int | None,
        name: str,
    ) -> dict[str, Any] | None:
        if parent_entry_id is None:
            cursor.execute(
                """
                SELECT
                    kid,
                    knowledge_base_id,
                    parent_entry_id,
                    path_ltree,
                    name,
                    entry_type,
                    is_root,
                    depth,
                    description,
                    file_bucket_name,
                    file_object_key,
                    markdown_bucket_name,
                    markdown_object_key,
                    file_size,
                    mime_type,
                    checksum
                FROM knowledge_fs_entry
                WHERE knowledge_base_id = %(knowledge_base_id)s
                  AND parent_entry_id IS NULL
                  AND name = %(name)s
                  AND is_deleted = FALSE
                """,
                {
                    "knowledge_base_id": knowledge_base_id,
                    "name": name,
                },
            )
        else:
            cursor.execute(
                """
                SELECT
                    kid,
                    knowledge_base_id,
                    parent_entry_id,
                    path_ltree,
                    name,
                    entry_type,
                    is_root,
                    depth,
                    description,
                    file_bucket_name,
                    file_object_key,
                    markdown_bucket_name,
                    markdown_object_key,
                    file_size,
                    mime_type,
                    checksum
                FROM knowledge_fs_entry
                WHERE knowledge_base_id = %(knowledge_base_id)s
                  AND parent_entry_id = %(parent_entry_id)s
                  AND name = %(name)s
                  AND is_deleted = FALSE
                """,
                {
                    "knowledge_base_id": knowledge_base_id,
                    "parent_entry_id": parent_entry_id,
                    "name": name,
                },
            )
        fetchone = getattr(cursor, "fetchone", None)
        return fetchone() if callable(fetchone) else None

    def soft_delete_by_knowledge_base_id(
        self, cursor: Any, *, knowledge_base_id: int
    ) -> None:
        """Logically delete all filesystem entries under one knowledge base."""
        cursor.execute(
            """
            UPDATE knowledge_fs_entry
            SET is_deleted = TRUE,
                updated_at = NOW()
            WHERE knowledge_base_id = %(knowledge_base_id)s
            """,
            {"knowledge_base_id": knowledge_base_id},
        )

    def soft_delete_file_entry(
        self, cursor: Any, *, knowledge_base_id: int, fs_entry_id: int
    ) -> None:
        """Logically delete one file entry by id."""
        cursor.execute(
            """
            UPDATE knowledge_fs_entry
            SET is_deleted = TRUE,
                updated_at = NOW()
            WHERE knowledge_base_id = %(knowledge_base_id)s
              AND kid = %(fs_entry_id)s
            """,
            {"knowledge_base_id": knowledge_base_id, "fs_entry_id": fs_entry_id},
        )

    def list_subtree_entry_ids(
        self, cursor: Any, *, knowledge_base_id: int, root_fs_entry_id: int
    ) -> list[int]:
        """List filesystem entry ids within one directory subtree, including the root."""
        cursor.execute(
            """
            SELECT fs.kid
            FROM knowledge_fs_entry fs
            JOIN knowledge_fs_entry root
              ON root.kid = %(root_fs_entry_id)s
            WHERE fs.knowledge_base_id = %(knowledge_base_id)s
              AND fs.is_deleted = FALSE
              AND fs.path_ltree <@ root.path_ltree
            ORDER BY fs.kid
            """,
            {
                "knowledge_base_id": knowledge_base_id,
                "root_fs_entry_id": root_fs_entry_id,
            },
        )
        return [int(row["kid"]) for row in self._fetchall(cursor)]

    def soft_delete_subtree(
        self, cursor: Any, *, knowledge_base_id: int, root_fs_entry_id: int
    ) -> None:
        """Logically delete one directory subtree, including the root entry."""
        cursor.execute(
            """
            UPDATE knowledge_fs_entry fs
            SET is_deleted = TRUE,
                updated_at = NOW()
            WHERE fs.knowledge_base_id = %(knowledge_base_id)s
              AND fs.path_ltree <@ (
                  SELECT path_ltree
                  FROM knowledge_fs_entry
                  WHERE kid = %(root_fs_entry_id)s
              )::ltree
            """,
            {
                "knowledge_base_id": knowledge_base_id,
                "root_fs_entry_id": root_fs_entry_id,
            },
        )

    def get_entry_by_id(self, cursor: Any, *, entry_id: int) -> dict[str, Any] | None:
        """Fetch one filesystem entry by id."""
        return self._get_entry_by_id(cursor, entry_id=entry_id)

    def get_child_entry(
        self,
        cursor: Any,
        *,
        knowledge_base_id: int,
        parent_entry_id: int | None,
        name: str,
    ) -> dict[str, Any] | None:
        """Fetch one direct child entry by parent and name."""
        return self._get_child_entry(
            cursor,
            knowledge_base_id=knowledge_base_id,
            parent_entry_id=parent_entry_id,
            name=name,
        )

    def get_virtual_path_by_entry_id(self, cursor: Any, *, entry_id: int) -> str | None:
        """Build the virtual path for one filesystem entry, excluding the KB root name."""
        cursor.execute(
            """
            WITH RECURSIVE item_path AS (
                SELECT kid, parent_entry_id, name, depth, is_root
                FROM knowledge_fs_entry
                WHERE kid = %(entry_id)s
                  AND is_deleted = FALSE
              UNION ALL
                SELECT parent.kid, parent.parent_entry_id, parent.name, parent.depth, parent.is_root
                FROM knowledge_fs_entry parent
                JOIN item_path child ON child.parent_entry_id = parent.kid
                WHERE parent.is_deleted = FALSE
            )
            SELECT COALESCE(string_agg(name, '/' ORDER BY depth), '')
            FROM item_path
            WHERE is_root = FALSE
            """,
            {"entry_id": entry_id},
        )
        fetchone = getattr(cursor, "fetchone", None)
        row = fetchone() if callable(fetchone) else None
        if row is None:
            return None
        if isinstance(row, dict):
            return (
                row.get("coalesce")
                or row.get("full_path")
                or next(iter(row.values()), None)
            )
        return str(row[0]) if row else None

    def rename_entry(self, cursor: Any, *, entry_id: int, new_name: str) -> None:
        """Rename one filesystem entry and rebuild its subtree path prefix."""
        cursor.execute(
            """
            SELECT kid, parent_entry_id, path_ltree, depth
            FROM knowledge_fs_entry
            WHERE kid = %(entry_id)s
              AND is_deleted = FALSE
            """,
            {"entry_id": entry_id},
        )
        fetchone = getattr(cursor, "fetchone", None)
        target = fetchone() if callable(fetchone) else None
        if target is None:
            return

        current_path_ltree = str(self._row_value(target, "path_ltree"))
        depth = int(self._row_value(target, "depth"))
        current_parent_path = ".".join(current_path_ltree.split(".")[:-1])
        new_label = self._path_label("d", depth, new_name)
        new_path_ltree = (
            f"{current_parent_path}.{new_label}" if current_parent_path else new_label
        )
        cursor.execute(
            """
            UPDATE knowledge_fs_entry fs
            SET name = CASE
                    WHEN fs.kid = %(entry_id)s THEN %(new_name)s
                    ELSE fs.name
                END,
                path_ltree = text2ltree(
                    %(new_path_ltree)s
                    || COALESCE(
                        substring(
                            fs.path_ltree::text
                            FROM char_length(%(current_path_ltree)s) + 1
                        ),
                        ''
                    )
                ),
                updated_at = NOW()
            WHERE fs.path_ltree <@ %(current_path_ltree)s::ltree
              AND fs.is_deleted = FALSE
            """,
            {
                "entry_id": entry_id,
                "new_name": new_name,
                "new_path_ltree": new_path_ltree,
                "current_path_ltree": current_path_ltree,
            },
        )

    def _fetchall(self, cursor: Any) -> list[dict[str, Any]]:
        fetchall = getattr(cursor, "fetchall", None)
        if callable(fetchall):
            return list(fetchall())
        return []

    def update_markdown_metadata(
        self,
        cursor: Any,
        *,
        fs_entry_id: int,
        markdown_bucket_name: str,
        markdown_object_key: str,
        line_count: int,
    ) -> None:
        """Update the markdown sidecar metadata on a file entry."""
        cursor.execute(
            """
            UPDATE knowledge_fs_entry
            SET markdown_bucket_name = %(markdown_bucket_name)s,
                markdown_object_key = %(markdown_object_key)s,
                line_count = %(line_count)s,
                updated_at = NOW()
            WHERE kid = %(fs_entry_id)s
            """,
            {
                "fs_entry_id": fs_entry_id,
                "markdown_bucket_name": markdown_bucket_name,
                "markdown_object_key": markdown_object_key,
                "line_count": line_count,
            },
        )

    def _path_label(self, prefix: str, depth: int, segment: str) -> str:
        digest = hashlib.md5(segment.encode("utf-8")).hexdigest()[:8]
        return f"{prefix}{depth}_{digest}"

    def _row_id(self, row: dict[str, Any]) -> int:
        return int(self._row_value(row, "kid"))

    def _row_value(self, row: dict[str, Any], key: str) -> Any:
        if isinstance(row, dict):
            if key in row:
                return row[key]
            if key == "kid" and "id" in row:
                return row["id"]
        raise KeyError(key)
