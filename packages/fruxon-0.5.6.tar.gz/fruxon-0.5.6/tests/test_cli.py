"""End-to-end CLI tests using Typer's CliRunner.

These exercise the actual Typer app — argument parsing, exit codes, the
stderr-vs-stdout split, error hints — by invoking commands in-process.
Network and the API client itself are stubbed out at the module boundary
so the tests stay fast and offline.
"""

from __future__ import annotations

import pytest
from typer.testing import CliRunner

from fruxon import credentials
from fruxon.cli import app
from fruxon.fruxon import ExecutionResult, ExecutionTrace


@pytest.fixture(autouse=True)
def isolated(tmp_path, monkeypatch):
    """Per-test config dir + cleared Fruxon env so flag/file precedence is
    deterministic. Also disables the update notifier to keep tests offline
    and silent."""
    monkeypatch.setenv("FRUXON_CONFIG_DIR", str(tmp_path))
    monkeypatch.setenv("FRUXON_NO_UPDATE_CHECK", "1")
    for var in ("FRUXON_API_KEY", "FRUXON_ORG", "FRUXON_BASE_URL"):
        monkeypatch.delenv(var, raising=False)
    return tmp_path


@pytest.fixture
def runner() -> CliRunner:
    # Click 8.3+ always keeps stderr separate from stdout on the result —
    # `result.stderr` and `result.stdout` are independent. (Older Click
    # versions required `mix_stderr=False`; the argument has been removed.)
    return CliRunner()


def _result(response: str = "Hello.") -> ExecutionResult:
    return ExecutionResult(
        response=response,
        trace=ExecutionTrace(
            agent_id="agent-1",
            agent_revision=3,
            duration=5000,
            input_cost=0.001,
            output_cost=0.002,
            total_cost=0.003,
        ),
        session_id="sess-abc",
        links=[],
        execution_record_id="rec-123",
    )


# ─────────────────────────────────────────────────────────────────────────────
# Top-level
# ─────────────────────────────────────────────────────────────────────────────


class TestTopLevel:
    def test_bare_shows_welcome_and_signed_out_tip(self, runner):
        result = runner.invoke(app, [])
        assert result.exit_code == 0
        assert "Welcome to Fruxon" in result.stderr
        # Signed-out gets the "Sign in" door plus a pointer to the
        # dashboard for users who don't have an account yet.
        assert "Sign in:" in result.stderr
        assert "fruxon login" in result.stderr
        assert "No account?" in result.stderr

    def test_bare_does_not_dump_full_help_block(self, runner):
        # The welcome tips already point at ``fruxon --help`` for the full
        # menu — repeating the entire Options/Commands table inline is a
        # wall of duplicated info.
        result = runner.invoke(app, [])
        assert result.exit_code == 0
        # The auto-generated help block always starts with ``Usage: fruxon``
        # — that's our tell that the help dump leaked into bare invocation.
        assert "Usage: fruxon" not in result.stderr

    def test_bare_signed_in_swaps_tip(self, runner):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        result = runner.invoke(app, [])
        assert "Signed in" in result.stderr
        assert "acme" in result.stderr
        # Signed-in surfaces the productive paths instead of "sign in."
        assert "fruxon agents list" in result.stderr
        assert "fruxon run" in result.stderr

    def test_bare_agent_mode_emits_json_manifest(self, runner, monkeypatch):
        """Under ``FRUXON_AGENT_MODE=1`` / ``CLAUDECODE=1`` / ``CI=true``,
        bare ``fruxon`` emits a one-line JSON manifest on stdout instead
        of the styled welcome. This is the contract AI agents (Claude
        Code, ChatGPT shell tools, etc.) pattern-match against.

        Stdout (not stderr) because agents read their parseable signal
        from stdout; one line so it composes with ``| jq``.
        """
        import json as _json

        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        monkeypatch.setenv("FRUXON_AGENT_MODE", "1")

        result = runner.invoke(app, [])
        assert result.exit_code == 0
        # No banner / chrome in stderr — the whole point is a clean
        # parseable surface for the calling program.
        assert "Welcome to Fruxon" not in result.stderr
        # Single-line JSON on stdout, parseable as-is.
        manifest = _json.loads(result.stdout.strip())
        assert manifest["name"] == "fruxon"
        assert manifest["signed_in"] is True
        assert manifest["org"] == "acme"
        # ``next`` points at the commands an LLM should reach for.
        assert "agents" in manifest["next"]
        assert "run" in manifest["next"]

    def test_bare_agent_mode_signed_out_points_at_login(self, runner, monkeypatch):
        """Agent mode with no credentials still emits a manifest — the
        ``next`` block routes the caller to login + dashboard so an LLM
        can guide the user through onboarding instead of going silent.
        """
        import json as _json

        monkeypatch.setenv("CLAUDECODE", "1")
        result = runner.invoke(app, [])
        assert result.exit_code == 0
        manifest = _json.loads(result.stdout.strip())
        assert manifest["signed_in"] is False
        assert manifest["org"] is None
        assert "login" in manifest["next"]
        assert "dashboard" in manifest["next"]

    def test_version_flag(self, runner):
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "Fruxon" in result.stderr

    def test_unknown_command_brands_error_and_suggests(self, runner):
        """Click's default 'No such command' renders as a bordered ASCII
        box that doesn't match Fruxon's UI. Our ``_FruxonTyperGroup``
        catches the miss and prints a styled ``✗`` line + a difflib
        suggestion. Same exit code (2 — Click's UsageError) so scripts
        still see a useful non-zero signal.
        """
        result = runner.invoke(app, ["agnts"])  # close to "agents"
        assert result.exit_code != 0
        assert "Unknown command" in result.stderr
        # The Click stock UI rendered errors inside a box; ours doesn't.
        assert "╭─" not in result.stderr
        # Closest-match suggestion appears for likely typos.
        assert "agents" in result.stderr

    def test_unknown_command_no_suggestion_for_unrecognizable(self, runner):
        """No suggestion when there's no close match — we fall back to
        the generic ``--help`` pointer rather than guessing wildly."""
        result = runner.invoke(app, ["xyzzy-not-a-thing"])
        assert result.exit_code != 0
        assert "Unknown command" in result.stderr
        assert "fruxon --help" in result.stderr


# ─────────────────────────────────────────────────────────────────────────────
# login / logout / whoami
# ─────────────────────────────────────────────────────────────────────────────


class TestLoginLogoutWhoami:
    def test_login_with_explicit_key_stores_credentials(self, runner, tmp_path):
        result = runner.invoke(
            app,
            ["login", "--api-key", "fxn_test", "--org", "acme", "--no-browser"],
        )
        assert result.exit_code == 0, result.stderr
        assert credentials.load().api_key == "fxn_test"
        assert credentials.load().org == "acme"

    def test_login_overwrites_existing_when_key_supplied(self, runner):
        credentials.save(credentials.StoredCredentials(api_key="old", org="old-tenant"))
        result = runner.invoke(app, ["login", "--api-key", "new", "--no-browser"])
        assert result.exit_code == 0
        # Tenant from the existing record is preserved when not overridden.
        assert credentials.load() == credentials.StoredCredentials(api_key="new", org="old-tenant")

    def test_login_prompts_for_confirmation_when_replacing(self, runner):
        credentials.save(credentials.StoredCredentials(api_key="old", org="acme"))
        # Reply "no" to the confirm prompt → existing creds untouched.
        result = runner.invoke(app, ["login", "--no-browser"], input="n\n")
        assert result.exit_code == 0
        assert credentials.load().api_key == "old"
        assert "Keeping existing" in result.stderr

    def test_login_browser_flow_polls_until_approved(self, runner, monkeypatch):
        """Default ``fruxon login`` (no ``--api-key``) runs the
        Stripe-style browser-poll flow: start a grant, open the
        verification URL, poll until the dashboard approves, save the
        minted key. Verifies the full happy path against a stubbed
        ``fruxon.cli_auth`` module.
        """
        from fruxon import cli_auth

        # Stub the network calls. ``start_grant`` returns a fake grant;
        # ``poll_grant`` returns Pending twice then Approved — the loop
        # must keep polling until it sees the terminal state.
        poll_calls = {"n": 0}

        def fake_start(base_url):
            return cli_auth.GrantStart(
                grant_code="abcdef1234567890",
                verification_url="https://app.fruxon.com/cli-auth?code=abcdef1234567890",
                expires_in_seconds=60,
                poll_interval_seconds=1,
            )

        def fake_poll(base_url, code):
            poll_calls["n"] += 1
            if poll_calls["n"] < 3:
                return cli_auth.PollPending()
            return cli_auth.PollApproved(
                api_key="fxn_minted_by_browser_flow",
                tenant_id="00000000-0000-0000-0000-000000000000",
                tenant_slug="acme-corp",
                tenant_name="Acme Corp",
            )

        monkeypatch.setattr(cli_auth, "start_grant", fake_start)
        monkeypatch.setattr(cli_auth, "poll_grant", fake_poll)
        # Avoid the real sleep — speeds tests up by ~3s otherwise.
        monkeypatch.setattr("time.sleep", lambda _seconds: None)

        result = runner.invoke(app, ["login", "--no-browser"])
        assert result.exit_code == 0, result.stderr
        # Polled at least 3 times (Pending → Pending → Approved).
        assert poll_calls["n"] >= 3
        # Minted key landed in storage. Org defaults to the tenant *slug*
        # the dashboard picked — not the opaque Guid — when no ``--org``
        # was supplied.
        creds = credentials.load()
        assert creds.api_key == "fxn_minted_by_browser_flow"
        assert creds.org == "acme-corp"

    def test_login_browser_flow_explicit_org_overrides_grant_tenant(self, runner, monkeypatch):
        """Explicit ``--org`` wins over the tenant the dashboard picked.
        Lets users override at the CLI without re-opening the browser
        page — for example, scripting a login against a sub-org."""
        from fruxon import cli_auth

        monkeypatch.setattr(
            cli_auth,
            "start_grant",
            lambda _base: cli_auth.GrantStart(
                grant_code="x" * 32,
                verification_url="https://app.fruxon.com/cli-auth?code=x",
                expires_in_seconds=60,
                poll_interval_seconds=1,
            ),
        )
        monkeypatch.setattr(
            cli_auth,
            "poll_grant",
            lambda _base, _code: cli_auth.PollApproved(
                api_key="fxn_x",
                tenant_id="00000000-0000-0000-0000-000000000000",
                tenant_slug="dashboard-pick",
                tenant_name=None,
            ),
        )
        monkeypatch.setattr("time.sleep", lambda _s: None)

        result = runner.invoke(app, ["login", "--no-browser", "--org", "cli-override"])
        assert result.exit_code == 0, result.stderr
        assert credentials.load().org == "cli-override"

    def test_login_browser_flow_expired_grant_fails_cleanly(self, runner, monkeypatch):
        """When the dashboard never approves and the grant expires, the
        CLI exits with a clear actionable error rather than spinning
        forever. The 410 Gone case from the backend maps to PollExpired."""
        from fruxon import cli_auth

        monkeypatch.setattr(
            cli_auth,
            "start_grant",
            lambda _base: cli_auth.GrantStart(
                grant_code="x" * 32,
                verification_url="https://app.fruxon.com/cli-auth?code=x",
                expires_in_seconds=60,
                poll_interval_seconds=1,
            ),
        )
        monkeypatch.setattr(cli_auth, "poll_grant", lambda _base, _code: cli_auth.PollExpired())
        monkeypatch.setattr("time.sleep", lambda _s: None)

        result = runner.invoke(app, ["login", "--no-browser"])
        assert result.exit_code == 1
        assert "expired" in result.stderr.lower()
        # Nothing was written to credentials.
        assert credentials.load().api_key is None

    def test_whoami_when_signed_out(self, runner):
        result = runner.invoke(app, ["whoami"])
        assert result.exit_code == 0
        assert "Not signed in" in result.stderr

    def test_whoami_when_signed_in(self, runner):
        credentials.save(credentials.StoredCredentials(api_key="fxn_test", org="acme"))
        result = runner.invoke(app, ["whoami"])
        assert result.exit_code == 0
        assert "credentials file" in result.stderr
        assert "acme" in result.stderr

    def test_whoami_redacts_api_key(self, runner):
        credentials.save(credentials.StoredCredentials(api_key="fxn_live_supersecret123"))
        result = runner.invoke(app, ["whoami"])
        # Only the last 4 chars survive, behind a fixed mask — no leading
        # secret entropy ("fxn", "supersecret") reaches the terminal.
        assert "supersecret" not in result.stderr
        assert "fxn" not in result.stderr
        assert "•••••t123" in result.stderr

    def test_whoami_output_json_returns_structured_state(self, runner):
        """``whoami --output json`` emits the same info as the text view
        in a parseable shape. The raw API key is NEVER included — only
        the redacted form — even when an agent is consuming the output.
        """
        import json as _json

        credentials.save(credentials.StoredCredentials(api_key="fxn_live_supersecret123", org="acme"))
        result = runner.invoke(app, ["whoami", "--output", "json"])
        assert result.exit_code == 0
        payload = _json.loads(result.stdout.strip())
        assert payload["signed_in"] is True
        assert payload["org"] == "acme"
        # Redacted only — secret bytes must never reach the parseable surface.
        assert "supersecret" not in result.stdout
        assert payload["api_key_redacted"] is not None

    def test_whoami_agent_mode_implies_json(self, runner, monkeypatch):
        import json as _json

        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        monkeypatch.setenv("CLAUDECODE", "1")
        result = runner.invoke(app, ["whoami"])
        assert result.exit_code == 0
        # Banner / chrome suppressed under agent mode.
        assert "whoami" not in result.stderr or "API key" not in result.stderr
        # Stdout carries the structured payload.
        payload = _json.loads(result.stdout.strip())
        assert payload["signed_in"] is True

    def test_logout_removes_credentials(self, runner):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        result = runner.invoke(app, ["logout"])
        assert result.exit_code == 0
        assert not credentials.credentials_path().exists()
        assert "Forgot API key" in result.stderr
        assert "Forgot org" in result.stderr

    def test_logout_idempotent_when_empty(self, runner):
        result = runner.invoke(app, ["logout"])
        assert result.exit_code == 0
        assert "No stored credentials" in result.stderr


# ─────────────────────────────────────────────────────────────────────────────
# config subcommand group
# ─────────────────────────────────────────────────────────────────────────────


class TestConfig:
    def test_list_empty(self, runner):
        result = runner.invoke(app, ["config", "list"])
        assert result.exit_code == 0
        assert "No config stored" in result.stderr

    def test_set_and_list(self, runner):
        runner.invoke(app, ["config", "set", "org=acme", "base_url=https://x"])
        result = runner.invoke(app, ["config", "list"])
        assert "acme" in result.stderr
        assert "https://x" in result.stderr

    def test_set_rejects_unknown_key(self, runner):
        result = runner.invoke(app, ["config", "set", "weird=value"])
        assert result.exit_code == 1
        assert "Unknown config key" in result.stderr

    def test_set_rejects_empty_value(self, runner):
        result = runner.invoke(app, ["config", "set", "org="])
        assert result.exit_code == 1
        assert "Empty value" in result.stderr

    def test_set_rejects_missing_equals(self, runner):
        result = runner.invoke(app, ["config", "set", "tenant"])
        assert result.exit_code == 1
        assert "Invalid assignment" in result.stderr

    def test_get_prints_value_to_stdout(self, runner):
        credentials.save(credentials.StoredCredentials(org="acme"))
        result = runner.invoke(app, ["config", "get", "org"])
        assert result.exit_code == 0
        # The value goes to stdout (so `$(fruxon config get org)` works).
        assert result.stdout.strip() == "acme"

    def test_get_returns_empty_for_unset(self, runner):
        result = runner.invoke(app, ["config", "get", "org"])
        assert result.exit_code == 0
        assert result.stdout.strip() == ""

    def test_get_rejects_unknown_key(self, runner):
        result = runner.invoke(app, ["config", "get", "nope"])
        assert result.exit_code == 1

    def test_unset_clears_only_targeted_key(self, runner):
        credentials.save(credentials.StoredCredentials(api_key="x", org="acme", base_url="https://u"))
        result = runner.invoke(app, ["config", "unset", "base_url"])
        assert result.exit_code == 0
        creds = credentials.load()
        assert creds.api_key == "x"
        assert creds.org == "acme"
        assert creds.base_url is None

    def test_unset_removes_file_when_everything_cleared(self, runner):
        credentials.save(credentials.StoredCredentials(api_key="x"))
        result = runner.invoke(app, ["config", "unset", "api_key"])
        assert result.exit_code == 0
        assert not credentials.credentials_path().exists()


# ─────────────────────────────────────────────────────────────────────────────
# doctor
# ─────────────────────────────────────────────────────────────────────────────


class TestDoctor:
    def test_signed_out_offline_fails_on_missing_api_key(self, runner):
        result = runner.invoke(app, ["doctor", "--offline"])
        # API key missing is a fail; doctor exits 1.
        assert result.exit_code == 1
        assert "API key" in result.stderr

    def test_signed_in_offline_warns_about_missing_org(self, runner):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x"))
        result = runner.invoke(app, ["doctor", "--offline"])
        # Tenant missing is just a warning, but still exits non-zero (warn ≠ ok).
        assert result.exit_code == 1
        assert "Organization" in result.stderr

    def test_signed_in_with_org_offline_passes(self, runner):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        result = runner.invoke(app, ["doctor", "--offline"])
        assert result.exit_code == 0
        assert "All checks passed" in result.stderr

    def test_output_json_returns_structured_check_results(self, runner):
        """``--output json`` emits a structured payload on stdout with one
        record per check. This is the contract scripts and AI agents read
        when they want to branch on a specific check (e.g. "is the API
        reachable?") rather than scrape styled text.
        """
        import json as _json

        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        result = runner.invoke(app, ["doctor", "--offline", "--output", "json"])
        assert result.exit_code == 0
        payload = _json.loads(result.stdout.strip())
        assert payload["overall"] in {"ok", "warn", "fail"}
        # Each check is a small dict with stable keys — title is the
        # parseable handle, status drives caller branching.
        assert any(c["title"] == "API key" for c in payload["checks"])
        assert all({"title", "status", "detail"} <= c.keys() for c in payload["checks"])

    def test_agent_mode_implies_json_default(self, runner, monkeypatch):
        """Under FRUXON_AGENT_MODE/CLAUDECODE/CI, ``fruxon doctor`` with
        no ``--output`` flag defaults to json — so LLMs/scripts get
        parseable output without having to know the flag exists.
        """
        import json as _json

        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        monkeypatch.setenv("FRUXON_AGENT_MODE", "1")
        result = runner.invoke(app, ["doctor", "--offline"])
        assert result.exit_code == 0
        # No banner / chrome — clean parseable surface.
        assert "Welcome to Fruxon" not in result.stderr
        # Stdout is the structured payload.
        payload = _json.loads(result.stdout.strip())
        assert "overall" in payload


# ─────────────────────────────────────────────────────────────────────────────
# run — uses a stubbed FruxonClient at the module boundary
# ─────────────────────────────────────────────────────────────────────────────


class TestRunSyncPath:
    def _patch_client(self, monkeypatch, *, execute=None, execute_revision=None, stream=None):
        """Replace FruxonClient with a recorder so tests don't hit the API."""

        captured: dict = {}

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, *, api_key, org, base_url):
                captured["api_key"] = api_key
                captured["org"] = org
                captured["base_url"] = base_url

            def execute(self, agent, **kwargs):
                captured["execute_args"] = (agent, kwargs)
                return execute(agent, **kwargs) if callable(execute) else _result()

            def execute_revision(self, agent, revision, **kwargs):
                captured["execute_revision_args"] = (agent, revision, kwargs)
                return execute_revision(agent, revision, **kwargs) if callable(execute_revision) else _result()

            def stream(self, agent, **kwargs):
                captured["stream_args"] = (agent, kwargs)
                if callable(stream):
                    yield from stream(agent, **kwargs)
                else:
                    yield from []

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        return captured

    def test_errors_without_api_key(self, runner):
        result = runner.invoke(app, ["run", "my-agent"])
        assert result.exit_code == 1
        assert "No API key found" in result.stderr
        assert "fruxon login" in result.stderr

    def test_errors_without_org(self, runner):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x"))
        result = runner.invoke(app, ["run", "my-agent"])
        assert result.exit_code == 1
        assert "No org found" in result.stderr

    def test_text_output_is_response_body(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch)
        result = runner.invoke(app, ["run", "my-agent", "--no-stream"])
        assert result.exit_code == 0
        assert result.stdout.strip() == "Hello."

    def test_json_output_format(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch)
        result = runner.invoke(app, ["run", "my-agent", "--no-stream", "--output", "json"])
        assert result.exit_code == 0
        assert '"response": "Hello."' in result.stdout
        assert '"sessionId": "sess-abc"' in result.stdout

    def test_json_alias_flag_was_removed(self, runner, monkeypatch):
        # ``--json`` was a redundant shortcut for ``--output json`` and got
        # removed when the run-flag surface was simplified. The canonical
        # form remains; assert the alias is rejected so we don't quietly
        # re-introduce it.
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch)
        result = runner.invoke(app, ["run", "my-agent", "--json"])
        assert result.exit_code != 0
        assert "No such option" in result.stderr or "Usage" in result.stderr

    def test_unknown_output_format_errors(self, runner):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        result = runner.invoke(app, ["run", "my-agent", "--output", "xml"])
        assert result.exit_code == 1
        assert "Unknown output format" in result.stderr
        assert "text, json, table" in result.stderr

    def test_revision_uses_execute_revision(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        captured = self._patch_client(monkeypatch)
        runner.invoke(app, ["run", "my-agent", "--revision", "42"])
        assert "execute_revision_args" in captured
        assert captured["execute_revision_args"][1] == "42"

    def test_params_flag_passed_to_client(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        captured = self._patch_client(monkeypatch)
        runner.invoke(
            app,
            [
                "run",
                "my-agent",
                "--no-stream",
                "-p",
                "question=Hello",
                "-p",
                "temp:=0.7",
            ],
        )
        agent, kwargs = captured["execute_args"]
        assert kwargs["parameters"] == {"question": "Hello", "temp": 0.7}

    def test_params_from_file(self, runner, monkeypatch, tmp_path):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        captured = self._patch_client(monkeypatch)
        f = tmp_path / "p.json"
        f.write_text('{"a": 1, "b": "two"}')
        runner.invoke(app, ["run", "my-agent", "--no-stream", "--params", str(f)])
        agent, kwargs = captured["execute_args"]
        assert kwargs["parameters"] == {"a": 1, "b": "two"}

    def test_bad_param_format_errors(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch)
        result = runner.invoke(app, ["run", "my-agent", "-p", "noequals"])
        assert result.exit_code == 1
        assert "Invalid parameter" in result.stderr or "noequals" in result.stderr

    def test_explicit_flags_beat_env_and_file(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="from_file", org="acme"))
        monkeypatch.setenv("FRUXON_API_KEY", "from_env")
        captured = self._patch_client(monkeypatch)
        runner.invoke(
            app,
            [
                "run",
                "my-agent",
                "--no-stream",
                "--api-key",
                "from_flag",
                "--org",
                "from_flag_org",
            ],
        )
        assert captured["api_key"] == "from_flag"
        assert captured["org"] == "from_flag_org"


class TestBrandingEnvKnobs:
    """Confirm the chrome respects user-facing toggles."""

    def test_no_color_disables_brand_styling(self, runner, monkeypatch):
        monkeypatch.setenv("NO_COLOR", "1")
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "Fruxon" in result.stderr

    def test_no_banner_suppresses_chrome(self, runner, monkeypatch):
        monkeypatch.setenv("FRUXON_NO_BANNER", "1")
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        result = runner.invoke(app, ["whoami"])
        assert result.exit_code == 0
        # The ✻ glyph + banner line should be absent under NO_BANNER.
        assert "✻" not in result.stderr


class TestEnvPrecedence:
    def test_env_var_used_when_no_flag_or_file(self, runner, monkeypatch):
        monkeypatch.setenv("FRUXON_API_KEY", "from_env")
        monkeypatch.setenv("FRUXON_ORG", "from_env_org")
        captured: dict = {}

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                captured.update(kwargs)

            def execute(self, agent, **kwargs):
                return _result()

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent", "--no-stream"])
        assert result.exit_code == 0
        assert captured["api_key"] == "from_env"
        assert captured["org"] == "from_env_org"


class TestRunNonStreamOutputs:
    """Coverage for the table format + the trace summary footer."""

    def _patch_client(self, monkeypatch, result):
        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def execute(self, agent, **kwargs):
                return result

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)

    def test_table_output_prints_breakdown(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch, _result("body text"))
        result = runner.invoke(app, ["run", "my-agent", "--output", "table"])
        assert result.exit_code == 0
        assert "body text" in result.stdout
        # In CliRunner stderr stays a terminal? actually no, it's a buffer,
        # so the table-on-stderr path is gated by `stderr.is_terminal`. The
        # row content is therefore NOT guaranteed in result.stderr — assert
        # we at least didn't crash.

    def test_summary_footer_only_for_text_format(self, runner, monkeypatch):
        # Cost/duration footer must NOT appear when --output json is used —
        # the JSON payload already carries the same data.
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch, _result())
        result = runner.invoke(app, ["run", "my-agent", "--no-stream", "--output", "json"])
        assert result.exit_code == 0
        # Footer is suppressed for json — assert the formatted duration
        # (``5.0s`` for the sample's 5000ms trace) doesn't leak into stderr.
        assert "5.0s" not in result.stderr

    def test_text_footer_surfaces_execution_record_id(self, runner, monkeypatch):
        # The record ID is the user's only handle for ``fruxon trace`` —
        # printing it here is what makes that command discoverable in
        # practice. Without it, nobody ever follows up.
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch, _result())
        result = runner.invoke(app, ["run", "my-agent", "--no-stream"])
        assert result.exit_code == 0
        assert "rec-123" in result.stderr

    def test_text_footer_omits_record_id_when_missing(self, runner, monkeypatch):
        # The server can omit the record ID (rare, e.g. failed pre-execution)
        # — the footer should degrade gracefully instead of printing
        # "record " with an empty value.
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        result = ExecutionResult(
            response="ok",
            trace=ExecutionTrace(
                agent_id="a",
                agent_revision=1,
                duration=100,
                input_cost=0,
                output_cost=0,
                total_cost=0,
            ),
            session_id="",
            links=[],
            execution_record_id="",
        )
        self._patch_client(monkeypatch, result)
        invocation = runner.invoke(app, ["run", "my-agent", "--no-stream"])
        assert invocation.exit_code == 0
        assert "record" not in invocation.stderr

    def test_explicit_base_url_flag_used(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        captured: dict = {}

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                captured.update(kwargs)

            def execute(self, agent, **kwargs):
                return _result()

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        runner.invoke(
            app,
            ["run", "my-agent", "--no-stream", "--base-url", "https://staging.fruxon.com"],
        )
        assert captured["base_url"] == "https://staging.fruxon.com"


class TestRunEditor:
    """``--edit KEY`` pops $EDITOR for a single parameter value."""

    def _patch_client(self, monkeypatch):
        captured: dict = {}

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def execute(self, agent, **kwargs):
                captured["parameters"] = kwargs.get("parameters")
                return _result()

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        return captured

    def test_editor_captures_saved_text(self, runner, monkeypatch, tmp_path):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        captured = self._patch_client(monkeypatch)

        # Fake $EDITOR — a shell script that writes a fixed body to the
        # tempfile it's given as $1, simulating the user typing + saving.
        editor_script = tmp_path / "fake-editor.sh"
        editor_script.write_text(
            "#!/bin/sh\n"
            'echo "# Editing parameter: prompt" > "$1"\n'
            'echo "# header" >> "$1"\n'
            'echo "Hello from the editor." >> "$1"\n'
            'echo "Second line." >> "$1"\n'
        )
        editor_script.chmod(0o755)
        monkeypatch.setenv("EDITOR", str(editor_script))
        monkeypatch.delenv("VISUAL", raising=False)

        result = runner.invoke(app, ["run", "a", "--no-stream", "--edit", "prompt"])
        assert result.exit_code == 0, result.stderr
        assert captured["parameters"] == {"prompt": "Hello from the editor.\nSecond line."}

    def test_editor_failure_surfaces_clear_error(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch)
        # Editor that doesn't exist — exercises the "not found on PATH" branch.
        monkeypatch.setenv("EDITOR", "/no/such/editor-binary")
        result = runner.invoke(app, ["run", "a", "--no-stream", "--edit", "prompt"])
        assert result.exit_code == 1
        assert "Editor" in result.stderr or "$EDITOR" in result.stderr


class TestRunMarkdown:
    """Markdown rendering for the non-stream text path."""

    def _patch_client(self, monkeypatch, response):
        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def execute(self, agent, **kwargs):
                return ExecutionResult(
                    response=response,
                    trace=ExecutionTrace(
                        agent_id="a",
                        agent_revision=1,
                        duration=0,
                        input_cost=0,
                        output_cost=0,
                        total_cost=0,
                    ),
                    session_id="",
                    links=[],
                    execution_record_id="",
                )

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)

    def test_pipe_safe_when_stdout_not_tty(self, runner, monkeypatch):
        # CliRunner captures stdout into a non-TTY buffer, so the markdown
        # path should NOT trigger — even with the default --markdown on.
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch, "# Heading\n\nSome **bold** text.")
        result = runner.invoke(app, ["run", "a", "--no-stream"])
        assert result.exit_code == 0
        # Raw markdown lands on stdout — no ANSI sequences from rich render.
        assert "# Heading" in result.stdout
        assert "**bold**" in result.stdout

    def test_markdown_toggle_flag_was_removed(self, runner, monkeypatch):
        # ``--markdown / --no-markdown`` was removed: markdown is auto-
        # detected based on stdout being a TTY, which is the right behavior
        # in every case we've observed. Assert the flag is gone so we don't
        # quietly reintroduce a useless toggle.
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch, "# Heading\n\nbody")
        result = runner.invoke(app, ["run", "a", "--no-stream", "--no-markdown"])
        assert result.exit_code != 0
        assert "No such option" in result.stderr or "Usage" in result.stderr


class TestRunFruxonErrorMapping:
    def test_authentication_error_includes_login_hint(self, runner, monkeypatch):
        from fruxon.exceptions import AuthenticationError

        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def execute(self, agent, **kwargs):
                raise AuthenticationError(status=401, title="Unauthorized", detail="bad key")

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent", "--no-stream"])
        assert result.exit_code == 1
        assert "fruxon login" in result.stderr or "API key" in result.stderr

    def test_not_found_error_hint(self, runner, monkeypatch):
        from fruxon.exceptions import NotFoundError

        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def execute(self, agent, **kwargs):
                raise NotFoundError(status=404, title="Not Found", detail="no agent")

            def list_agents(self):
                return []

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent", "--no-stream"])
        assert result.exit_code == 1
        # The hint mentions "agent identifier" — see _hint_for_run_error.
        assert "agent" in result.stderr.lower()

    def test_not_found_suggests_close_agent_match(self, runner, monkeypatch):
        """When the agent name looks like a typo, the hint surfaces the
        closest match in the org via difflib. This is what makes
        ``fruxon run projct_assistant`` recover gracefully instead of
        forcing the user to ``agents list``.
        """
        from fruxon.exceptions import NotFoundError
        from fruxon.fruxon import Agent

        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def execute(self, agent, **kwargs):
                raise NotFoundError(status=404, title="Not Found", detail="missing")

            def list_agents(self):
                return [
                    Agent(
                        id="project_assistant",
                        display_name="Project Assistant",
                        description="",
                        enabled=True,
                        current_revision=1,
                        tags=[],
                    ),
                    Agent(
                        id="logos",
                        display_name="Logos",
                        description="",
                        enabled=True,
                        current_revision=1,
                        tags=[],
                    ),
                ]

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "projct_assistant", "--no-stream"])
        assert result.exit_code == 1
        # The difflib suggestion appears in the hint — that's the whole point.
        assert "project_assistant" in result.stderr
        assert "Did you mean" in result.stderr

    def test_validation_error_extracts_missing_parameter_from_message(self, runner, monkeypatch):
        """Backend's ``Parameter X is required`` message gets parsed into
        a copy-pasteable ``fruxon run agent -p X=<value>`` hint. Until
        the API gains a structured ``code``/``data`` envelope, regex on
        the message string is how we make the UX actionable.
        """
        from fruxon.exceptions import ValidationError

        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def execute(self, agent, **kwargs):
                # Mirror the backend's actual error shape:
                # ``{"message": "Parameter user_query is required"}`` →
                # SDK puts the message into ``title``, leaving ``detail`` empty.
                raise ValidationError(
                    status=400,
                    title="Parameter user_query is required",
                    detail="",
                )

            def list_agents(self):
                return []

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "support-agent", "--no-stream"])
        assert result.exit_code == 1
        # The copy-pasteable command must appear in the hint — without
        # this, the user has no path to recovery short of ``agents get``.
        assert "-p user_query=" in result.stderr


class TestAgents:
    """Coverage for ``fruxon agents list`` and ``fruxon agents get``."""

    def _agent_obj(self, **overrides):
        from fruxon.fruxon import Agent

        defaults = {
            "id": "agent-1",
            "display_name": "Support",
            "description": "Handles tickets.",
            "enabled": True,
            "current_revision": 3,
            "tags": ["support"],
        }
        defaults.update(overrides)
        return Agent(**defaults)

    def _patch_client(self, monkeypatch, *, agents=None, get=None, parameters=None):
        captured: dict = {}

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                captured.update(kwargs)

            def list_agents(self):
                return agents or []

            def get_agent(self, agent_id):
                captured["get_id"] = agent_id
                if get is None:
                    from fruxon.exceptions import NotFoundError

                    raise NotFoundError(status=404, title="Not Found", detail="no such agent")
                return get

            def get_agent_parameters(self, agent_id, revision):
                captured["params_args"] = (agent_id, revision)
                return parameters if parameters is not None else []

        monkeypatch.setattr("fruxon.cli.agents.FruxonClient", _StubClient)
        return captured

    def test_list_errors_without_credentials(self, runner):
        result = runner.invoke(app, ["agents", "list"])
        assert result.exit_code == 1
        assert "No API key" in result.stderr or "fruxon login" in result.stderr

    def test_list_table_default(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch, agents=[self._agent_obj()])
        result = runner.invoke(app, ["agents", "list"])
        assert result.exit_code == 0
        assert "agent-1" in result.stderr
        assert "Support" in result.stderr

    def test_list_id_format_for_piping(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(
            monkeypatch,
            agents=[self._agent_obj(id="a"), self._agent_obj(id="b")],
        )
        result = runner.invoke(app, ["agents", "list", "--output", "id"])
        assert result.exit_code == 0
        assert result.stdout.strip().splitlines() == ["a", "b"]

    def test_list_json_format(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch, agents=[self._agent_obj()])
        result = runner.invoke(app, ["agents", "list", "--output", "json"])
        assert result.exit_code == 0
        import json as json_mod

        payload = json_mod.loads(result.stdout)
        assert payload[0]["id"] == "agent-1"
        assert payload[0]["displayName"] == "Support"

    def test_list_unknown_format_errors(self, runner):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        result = runner.invoke(app, ["agents", "list", "--output", "xml"])
        assert result.exit_code == 1
        assert "Unknown output format" in result.stderr

    def test_list_filters_disabled_by_default(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(
            monkeypatch,
            agents=[
                self._agent_obj(id="on", enabled=True),
                self._agent_obj(id="off", enabled=False),
            ],
        )
        result = runner.invoke(app, ["agents", "list", "--output", "id"])
        assert result.stdout.strip().splitlines() == ["on"]

    def test_list_all_includes_disabled(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(
            monkeypatch,
            agents=[
                self._agent_obj(id="on", enabled=True),
                self._agent_obj(id="off", enabled=False),
            ],
        )
        result = runner.invoke(app, ["agents", "list", "--output", "id", "--all"])
        assert sorted(result.stdout.strip().splitlines()) == ["off", "on"]

    def test_list_truly_empty_org_points_at_dashboard(self, runner, monkeypatch):
        """When the org has zero agents at all, the empty-state message
        is an onboarding moment — point the user at the dashboard so
        they can create one. The old flat "No agents to show" message
        also nudged the user toward ``--all``, which is useless when
        there are no disabled agents to reveal.
        """
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch, agents=[])
        result = runner.invoke(app, ["agents", "list"])
        assert result.exit_code == 0
        assert "No agents deployed" in result.stderr
        # Dashboard URL must appear so the user can act on the message.
        assert "fruxon.com" in result.stderr or "dashboard" in result.stderr.lower()
        # Don't suggest ``--all`` in this case — there's nothing for it to reveal.
        assert "--all" not in result.stderr

    def test_list_all_disabled_suggests_all_flag(self, runner, monkeypatch):
        """When agents exist but every one is disabled, the empty-state
        hint surfaces ``--all`` — that's the recovery path. Distinct
        from the "truly empty" case so the message actually matches
        what the user can do about it.
        """
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(
            monkeypatch,
            agents=[self._agent_obj(id="disabled-1", enabled=False)],
        )
        result = runner.invoke(app, ["agents", "list"])
        assert result.exit_code == 0
        assert "disabled" in result.stderr
        assert "--all" in result.stderr

    def test_list_empty_json_returns_empty_array(self, runner, monkeypatch):
        """``--output json`` on an empty org returns ``[]`` rather than
        a human-facing prose message. Critical for AI-agent consumers
        that pipe into ``jq`` — a prose message would crash the pipeline."""
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch, agents=[])
        result = runner.invoke(app, ["agents", "list", "--output", "json"])
        assert result.exit_code == 0
        assert result.stdout.strip() == "[]"

    def test_list_empty_id_format_returns_no_output(self, runner, monkeypatch):
        """``--output id`` on an empty org returns nothing on stdout —
        same contract as ``ls`` when a directory is empty. Stops shell
        loops cleanly without a spurious prose line on stderr."""
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch, agents=[])
        result = runner.invoke(app, ["agents", "list", "--output", "id"])
        assert result.exit_code == 0
        assert result.stdout.strip() == ""

    def test_get_renders_detail(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        captured = self._patch_client(monkeypatch, get=self._agent_obj())
        result = runner.invoke(app, ["agents", "get", "agent-1"])
        assert result.exit_code == 0
        assert captured["get_id"] == "agent-1"
        assert "Support" in result.stderr
        assert "Handles tickets." in result.stderr

    def test_get_json_output(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch, get=self._agent_obj())
        result = runner.invoke(app, ["agents", "get", "agent-1", "--output", "json"])
        assert result.exit_code == 0
        import json as json_mod

        payload = json_mod.loads(result.stdout)
        assert payload["id"] == "agent-1"

    def test_get_shows_parameters_when_available(self, runner, monkeypatch):
        """``agents get`` fetches and prints the deployed revision's input
        parameter names — the single most useful piece of information
        before invoking ``fruxon run``. Without this, users have to fail a
        request to learn what key names the agent expects.
        """
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        captured = self._patch_client(
            monkeypatch,
            get=self._agent_obj(current_revision=42),
            parameters=["user_query", "lang"],
        )
        result = runner.invoke(app, ["agents", "get", "agent-1"])
        assert result.exit_code == 0
        # Parameter names land in the rendered detail block.
        assert "user_query" in result.stderr
        assert "lang" in result.stderr
        # The "Run with" hint shows the user the exact invocation form.
        assert "-p user_query=" in result.stderr
        # The SDK was asked for the deployed revision's params.
        assert captured["params_args"] == ("agent-1", 42)

    def test_get_skips_parameters_when_no_current_revision(self, runner, monkeypatch):
        # An agent without a deployed revision has no parameters to show
        # — the SDK call should be skipped entirely, not made and ignored.
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        captured = self._patch_client(
            monkeypatch,
            get=self._agent_obj(current_revision=0),
            parameters=["should_not_be_used"],
        )
        result = runner.invoke(app, ["agents", "get", "agent-1"])
        assert result.exit_code == 0
        assert "params_args" not in captured
        assert "should_not_be_used" not in result.stderr

    def test_get_swallows_parameters_error(self, runner, monkeypatch):
        # A 404 / network failure on the :parameters endpoint shouldn't
        # tank the whole ``agents get`` — the rest of the metadata is
        # still useful and should still render.
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        from fruxon.exceptions import NotFoundError

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def get_agent(self, agent_id):
                return self._agent

            def get_agent_parameters(self, agent_id, revision):
                raise NotFoundError(status=404, title="Not Found", detail="")

            _agent = self._agent_obj()

        monkeypatch.setattr("fruxon.cli.agents.FruxonClient", _StubClient)
        result = runner.invoke(app, ["agents", "get", "agent-1"])
        assert result.exit_code == 0
        # Core agent metadata still rendered, just no parameters row.
        assert "Support" in result.stderr

    def test_get_json_includes_parameters_key(self, runner, monkeypatch):
        # JSON output should carry the parameter list under a stable key
        # so scripts can drive ``fruxon run`` programmatically.
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(
            monkeypatch,
            get=self._agent_obj(current_revision=3),
            parameters=["q"],
        )
        result = runner.invoke(app, ["agents", "get", "agent-1", "--output", "json"])
        assert result.exit_code == 0
        import json as json_mod

        payload = json_mod.loads(result.stdout)
        assert payload["parameters"] == ["q"]

    def test_get_not_found_includes_list_hint(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch, get=None)  # 404
        result = runner.invoke(app, ["agents", "get", "missing-agent"])
        assert result.exit_code == 1
        assert "missing-agent" in result.stderr
        assert "fruxon agents list" in result.stderr

    def test_get_not_found_suggests_close_match(self, runner, monkeypatch):
        """When the requested agent ID is close to one in the org's
        agent list, the hint surfaces a ``Did you mean X?`` line.
        Network failure during the lookup is swallowed and we fall back
        to the generic listing pointer — the user is already in an
        error path; a second failure on top would be hostile.
        """
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(
            monkeypatch,
            get=None,  # 404
            agents=[self._agent_obj(id="project_assistant", display_name="Project Assistant")],
        )
        result = runner.invoke(app, ["agents", "get", "projct_assistant"])
        assert result.exit_code == 1
        assert "Did you mean" in result.stderr
        assert "project_assistant" in result.stderr


class TestTrace:
    """Coverage for ``fruxon trace`` — record fetch + render."""

    def _record(self, **overrides):
        from fruxon.models import ExecutionRecord

        defaults = {
            "id": "rec-1",
            "agent_id": "agent-1",
            "agent_revision": 3,
            # Backend convention: enum values are SCREAMING_SNAKE. See
            # AgentExecutionRecordStatus.cs in fruxon-backend.
            "status": "COMPLETED",
            "start_time": 1700000000000,
            "end_time": 1700000005000,
            "input_tokens": 100,
            "output_tokens": 200,
            "total_cost": 0.001,
        }
        defaults.update(overrides)
        return ExecutionRecord(**defaults)

    def _patch_client(self, monkeypatch, *, record=None, trace_payload=None, raises=None):
        captured = {}

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def get_execution_record(self, agent, record_id):
                captured["record_args"] = (agent, record_id)
                if raises is not None:
                    raise raises
                return record

            def get_execution_trace(self, agent, record_id):
                captured["trace_args"] = (agent, record_id)
                return trace_payload or {}

        monkeypatch.setattr("fruxon.cli.trace.FruxonClient", _StubClient)
        return captured

    def test_requires_credentials(self, runner):
        result = runner.invoke(app, ["trace", "my-agent", "rec-1"])
        assert result.exit_code == 1
        assert "No API key" in result.stderr or "fruxon login" in result.stderr

    def test_renders_record_fields(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(monkeypatch, record=self._record())
        result = runner.invoke(app, ["trace", "my-agent", "rec-1", "--summary-only"])
        assert result.exit_code == 0
        assert "rec-1" in result.stderr
        assert "COMPLETED" in result.stderr
        # Sample record is 5_000_000_000 ns span → 5000ms → ``5.0s``.
        assert "5.0s" in result.stderr

    def test_summary_only_skips_trace_fetch(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        captured = self._patch_client(monkeypatch, record=self._record())
        runner.invoke(app, ["trace", "my-agent", "rec-1", "--summary-only"])
        assert "trace_args" not in captured

    def test_fetches_both_by_default(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        captured = self._patch_client(
            monkeypatch,
            record=self._record(),
            trace_payload={"trace": {"steps": []}},
        )
        result = runner.invoke(app, ["trace", "my-agent", "rec-1"])
        assert result.exit_code == 0
        assert captured["record_args"] == ("my-agent", "rec-1")
        assert captured["trace_args"] == ("my-agent", "rec-1")

    def test_renders_step_summaries(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(
            monkeypatch,
            record=self._record(),
            trace_payload={
                "trace": {
                    "steps": [
                        # ``StepTraceStatus`` enum from the backend — SUCCESS / ERROR.
                        {"kind": "llm", "name": "primary", "duration": 1200, "status": "SUCCESS"},
                        {"kind": "tool", "name": "search_web", "duration": 800, "status": "ERROR"},
                    ]
                }
            },
        )
        result = runner.invoke(app, ["trace", "my-agent", "rec-1"])
        assert result.exit_code == 0
        assert "llm" in result.stderr
        assert "search_web" in result.stderr
        # Non-success step gets the red ``ERROR`` annotation in the summary line.
        assert "ERROR" in result.stderr

    def test_json_output(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        self._patch_client(
            monkeypatch,
            record=self._record(),
            trace_payload={"trace": {"steps": [{"kind": "x"}]}},
        )
        result = runner.invoke(app, ["trace", "my-agent", "rec-1", "--output", "json"])
        assert result.exit_code == 0

        import json as json_mod

        payload = json_mod.loads(result.stdout)
        assert payload["record"]["id"] == "rec-1"
        assert payload["record"]["durationMs"] == 5000
        assert payload["trace"]["trace"]["steps"][0]["kind"] == "x"

    def test_404_includes_helpful_hint(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))
        from fruxon.exceptions import NotFoundError

        self._patch_client(
            monkeypatch,
            raises=NotFoundError(status=404, title="Not Found", detail=""),
        )
        result = runner.invoke(app, ["trace", "my-agent", "rec-missing"])
        assert result.exit_code == 1
        assert "rec-missing" in result.stderr
        assert "my-agent" in result.stderr


class TestChatRepl:
    """End-to-end coverage of the ``fruxon chat`` REPL.

    The REPL is hard to exercise interactively, but Typer's CliRunner
    accepts ``input=`` to feed stdin. We stub the streaming client to
    return canned events per turn and let the loop drive normally.
    """

    def _stub_chat_client(self, monkeypatch, *, turns):
        """Set up a stub client whose ``stream`` yields the events for the
        Nth call from ``turns[n]``. ``captured`` records the params each
        turn was sent with so tests can assert session continuity / input
        mapping."""
        captured: list[dict] = []
        call_idx = {"n": 0}

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                idx = call_idx["n"]
                call_idx["n"] += 1
                captured.append({"agent": agent, **kwargs})
                yield from turns[idx]

        monkeypatch.setattr("fruxon.cli.chat.FruxonClient", _StubClient)
        return captured

    def test_session_id_threads_across_turns(self, runner, monkeypatch):
        """First turn has no session_id; subsequent turns use the one
        returned in the previous turn's ``done`` event."""
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        turn1 = [
            StreamEvent(event="text", data={"chunk": "Hello!"}),
            StreamEvent(event="done", data={"sessionId": "sess-new", "trace": {}}),
        ]
        turn2 = [
            StreamEvent(event="text", data={"chunk": "Round 2"}),
            StreamEvent(event="done", data={"sessionId": "sess-new", "trace": {}}),
        ]
        captured = self._stub_chat_client(monkeypatch, turns=[turn1, turn2])

        # Two user messages, then an empty line to exit.
        result = runner.invoke(
            app,
            ["chat", "my-agent"],
            input="hi\nhello again\n\n",
        )
        assert result.exit_code == 0
        # First turn: no session yet. Second turn: reuses the sessionId
        # returned from the done event of turn 1.
        assert captured[0]["session_id"] is None
        assert captured[1]["session_id"] == "sess-new"
        # Default input key is `prompt`.
        assert captured[0]["parameters"] == {"prompt": "hi"}
        assert captured[1]["parameters"] == {"prompt": "hello again"}

    def test_custom_input_key_and_static_params(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        captured = self._stub_chat_client(
            monkeypatch,
            turns=[[StreamEvent(event="done", data={"trace": {}})]],
        )
        result = runner.invoke(
            app,
            [
                "chat",
                "my-agent",
                "--input-key",
                "question",
                "-p",
                "lang=en",
                "-p",
                "temp:=0.5",
            ],
            input="What time is it?\n\n",
        )
        assert result.exit_code == 0
        assert captured[0]["parameters"] == {
            "lang": "en",
            "temp": 0.5,
            "question": "What time is it?",
        }

    def test_clear_command_resets_session(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        turn1 = [StreamEvent(event="done", data={"sessionId": "abc", "trace": {}})]
        turn2 = [StreamEvent(event="done", data={"sessionId": "xyz", "trace": {}})]
        captured = self._stub_chat_client(monkeypatch, turns=[turn1, turn2])

        result = runner.invoke(
            app,
            ["chat", "my-agent"],
            input="first\n/clear\nsecond\n\n",
        )
        assert result.exit_code == 0
        assert captured[0]["session_id"] is None
        # `/clear` resets — second real turn should also have no session.
        assert captured[1]["session_id"] is None

    def test_resume_with_explicit_session(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        captured = self._stub_chat_client(
            monkeypatch,
            turns=[[StreamEvent(event="done", data={"trace": {}})]],
        )
        result = runner.invoke(
            app,
            ["chat", "my-agent", "--session", "sess-existing"],
            input="continue\n\n",
        )
        assert result.exit_code == 0
        assert captured[0]["session_id"] == "sess-existing"

    def test_help_command_prints_then_continues(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        captured = self._stub_chat_client(
            monkeypatch,
            turns=[[StreamEvent(event="done", data={"trace": {}})]],
        )
        result = runner.invoke(
            app,
            ["chat", "my-agent"],
            input="/help\nhi\n\n",
        )
        assert result.exit_code == 0
        assert "Slash commands" in result.stderr
        # Confirm /help didn't consume the next line as a message.
        assert captured[0]["parameters"]["prompt"] == "hi"

    def test_unknown_slash_command_warns_and_continues(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        captured = self._stub_chat_client(
            monkeypatch,
            turns=[[StreamEvent(event="done", data={"trace": {}})]],
        )
        result = runner.invoke(
            app,
            ["chat", "my-agent"],
            input="/nope\nhi\n\n",
        )
        assert result.exit_code == 0
        assert "Unknown command" in result.stderr
        assert captured[0]["parameters"]["prompt"] == "hi"

    def test_exits_without_credentials(self, runner):
        result = runner.invoke(app, ["chat", "my-agent"])
        assert result.exit_code == 1
        assert "No API key" in result.stderr or "fruxon login" in result.stderr

    def test_chat_verbose_flag_expands_tool_args(self, runner, monkeypatch):
        """``fruxon chat --verbose`` threads the flag down to the same
        tool renderer as ``fruxon run``. Confirm full args reach stderr
        in expanded form."""
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        turn = [
            StreamEvent(
                event="tool_call",
                data={
                    "id": "1",
                    "toolTrace": {"displayName": "search"},
                    "arguments": {"q": "discoverable-marker"},
                    "startTime": 0,
                },
            ),
            StreamEvent(event="tool_result", data={"id": "1", "endTime": 50, "status": "SUCCESS"}),
            StreamEvent(event="done", data={"trace": {}}),
        ]
        self._stub_chat_client(monkeypatch, turns=[turn])
        result = runner.invoke(
            app,
            ["chat", "my-agent", "--verbose"],
            input="hi\n\n",
        )
        assert result.exit_code == 0
        assert "discoverable-marker" in result.stderr

    def test_markdown_toggle_flag_was_removed(self, runner, monkeypatch):
        # Same rationale as the run-side toggle: auto-detect on TTY is
        # always right, the explicit flag was just noise. Pin the
        # invariant so we don't reintroduce it.
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        self._stub_chat_client(
            monkeypatch,
            turns=[[StreamEvent(event="done", data={"trace": {}})]],
        )
        result = runner.invoke(
            app,
            ["chat", "my-agent", "--no-markdown"],
            input="hi\n\n",
        )
        assert result.exit_code != 0


class TestRunStreamPath:
    def test_streams_text_chunks_to_stdout(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        events = [
            StreamEvent(event="text", data={"chunk": "Hello "}),
            StreamEvent(event="text", data={"chunk": "world"}),
            StreamEvent(event="done", data={"trace": {}}),
        ]

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                yield from events

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent"])
        assert result.exit_code == 0
        # Stream chunks land on stdout, joined with no separators.
        assert "Hello world" in result.stdout

    def test_stream_footer_surfaces_execution_record_id(self, runner, monkeypatch):
        # Same idea as the sync path: the record ID is the only hook
        # users have for ``fruxon trace`` so it has to land in the
        # streaming footer too.
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        events = [
            StreamEvent(event="text", data={"chunk": "ok"}),
            StreamEvent(
                event="done",
                data={"trace": {"duration": 100}, "executionRecordId": "rec-stream-7"},
            ),
        ]

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                yield from events

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent"])
        assert result.exit_code == 0
        assert "rec-stream-7" in result.stderr

    def test_stream_tool_calls_render_one_row_per_tool(self, runner, monkeypatch):
        """Each finished tool commits exactly one ``⏺`` row in compact
        mode — name + duration, no args, no result. The ``#N`` sequence
        tag is the stable handle a user can reference if they re-run
        with ``-v`` to see what each one actually did.
        """
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        events = [
            StreamEvent(
                event="tool_call",
                data={
                    "id": "abc",
                    "toolTrace": {"displayName": "list_commits"},
                    "arguments": {"repo": "fruxon-backend"},
                    "startTime": 100,
                },
            ),
            StreamEvent(
                event="tool_call",
                data={
                    "id": "def",
                    "toolTrace": {"displayName": "list_commits"},
                    "arguments": {"repo": "fruxon-frontend"},
                    "startTime": 110,
                },
            ),
            StreamEvent(
                event="tool_result",
                data={"id": "def", "endTime": 200, "status": "SUCCESS"},
            ),
            StreamEvent(
                event="tool_result",
                data={"id": "abc", "endTime": 300, "status": "SUCCESS"},
            ),
            StreamEvent(event="done", data={"trace": {}}),
        ]

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                yield from events

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent"])
        assert result.exit_code == 0
        # One row per tool, distinct sequence tags.
        assert "#1" in result.stderr
        assert "#2" in result.stderr
        # Each tag appears exactly once — that's the merge guarantee.
        # Two appearances would mean we're printing dispatch + completion
        # as separate rows again.
        assert result.stderr.count("#1") == 1
        assert result.stderr.count("#2") == 1
        # Compact mode deliberately hides args: the user deployed this
        # agent because they trust it; the work log is verbose-only.
        assert "fruxon-backend" not in result.stderr
        assert "fruxon-frontend" not in result.stderr
        # And no ``→`` dispatch glyph leaks through — only completion glyphs.
        assert "→" not in result.stderr
        # Two committed ``⏺`` blocks in scrollback.
        assert result.stderr.count("⏺") == 2

    def test_stream_live_region_disabled_when_stderr_not_tty(self, runner, monkeypatch):
        """The Live region only activates when stderr is a TTY.

        CliRunner captures stderr into a buffer (not a terminal), so the
        live region must be a no-op there — the test harness sees only
        the committed tool blocks, not transient spinner frames or
        cursor-movement noise. This keeps the static fallback as the
        authoritative output for pipes, CI logs, and the test suite.
        """
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        events = [
            StreamEvent(
                event="tool_call",
                data={
                    "id": "1",
                    "toolTrace": {"displayName": "ping"},
                    "arguments": {"host": "example.com"},
                    "startTime": 0,
                },
            ),
            StreamEvent(
                event="tool_result",
                data={"id": "1", "endTime": 50, "status": "SUCCESS"},
            ),
            StreamEvent(event="done", data={"trace": {}}),
        ]

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                yield from events

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent"])
        assert result.exit_code == 0
        # The committed tool block is present...
        assert "ping" in result.stderr
        assert "⏺" in result.stderr
        # ...and no live-region spinner frames / cursor-control noise
        # leaked in. Rich's "dots" spinner uses braille glyphs in
        # U+2800–U+28FF; none should reach a non-TTY buffer.
        assert not any("⠀" <= ch <= "⣿" for ch in result.stderr)

    def test_stream_compact_tools_hide_args_and_result(self, runner, monkeypatch):
        """Default (non-verbose) tool rendering shows just the name +
        duration. Args and result body are deliberately hidden —
        ``fruxon run`` users want the agent's answer, not its work log.
        Verbose mode is the opt-in for the full picture.
        """
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        long_value = "x" * 500
        events = [
            StreamEvent(
                event="tool_call",
                data={
                    "id": "1",
                    "toolTrace": {"displayName": "search"},
                    "arguments": {"q": long_value},
                    "startTime": 0,
                },
            ),
            StreamEvent(
                event="tool_result",
                data={"id": "1", "endTime": 100, "status": "SUCCESS", "result": long_value},
            ),
            StreamEvent(event="done", data={"trace": {}}),
        ]

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                yield from events

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent"])
        assert result.exit_code == 0
        # Neither the args value nor the result body leaks into the
        # compact view — they're verbose-only.
        assert long_value not in result.stderr
        # The tool name and duration do appear — that's the whole point
        # of "show which ones, not what they did."
        assert "search" in result.stderr
        assert "⏺" in result.stderr

    def test_stream_verbose_expands_args_and_result(self, runner, monkeypatch):
        """``--verbose`` / ``-v`` expands every tool call into an indented
        detail block — full args under the call, full result under the
        completion line. The CLI's pragmatic equivalent of a dropdown.
        """
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        events = [
            StreamEvent(
                event="tool_call",
                data={
                    "id": "1",
                    "toolTrace": {"displayName": "search"},
                    "arguments": {"q": "fruxon docs", "lang": "en"},
                    "startTime": 0,
                },
            ),
            StreamEvent(
                event="tool_result",
                data={
                    "id": "1",
                    "endTime": 100,
                    "status": "SUCCESS",
                    "result": "found 3 matches",
                },
            ),
            StreamEvent(event="done", data={"trace": {}}),
        ]

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                yield from events

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent", "--verbose"])
        assert result.exit_code == 0
        # Detail block carries the full arg values (not just the keys).
        assert "fruxon docs" in result.stderr
        assert "en" in result.stderr
        # Result body appears under the completion line.
        assert "found 3 matches" in result.stderr

    def test_stream_short_v_flag_alias(self, runner, monkeypatch):
        """``-v`` is the short alias for ``--verbose``. Pin it so we don't
        accidentally collide it with another option in the future."""
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        events = [
            StreamEvent(
                event="tool_call",
                data={
                    "id": "1",
                    "toolTrace": {"displayName": "noop"},
                    "arguments": {"signal": "wave"},
                    "startTime": 0,
                },
            ),
            StreamEvent(
                event="tool_result",
                data={"id": "1", "endTime": 1, "status": "SUCCESS"},
            ),
            StreamEvent(event="done", data={"trace": {}}),
        ]

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                yield from events

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent", "-v"])
        assert result.exit_code == 0
        assert "wave" in result.stderr

    def test_stream_failure_auto_expands_without_verbose(self, runner, monkeypatch):
        """Failed tools auto-expand even without ``--verbose``: that's the
        moment a user most needs the args + full error message, and asking
        them to rerun with ``-v`` is hostile UX.
        """
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        events = [
            StreamEvent(
                event="tool_call",
                data={
                    "id": "1",
                    "toolTrace": {"displayName": "fetch_url"},
                    "arguments": {"url": "https://broken.example/data.json"},
                    "startTime": 0,
                },
            ),
            StreamEvent(
                event="tool_result",
                data={
                    "id": "1",
                    "endTime": 100,
                    # Backend's StepTraceStatus uses ERROR for failures.
                    "status": "ERROR",
                    "result": "Connection refused on host broken.example",
                },
            ),
            StreamEvent(event="done", data={"trace": {}}),
        ]

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                yield from events

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        # No -v / --verbose on the CLI line.
        result = runner.invoke(app, ["run", "my-agent"])
        assert result.exit_code == 0
        # Both args and full error body land in the detail block.
        assert "https://broken.example/data.json" in result.stderr
        assert "Connection refused" in result.stderr
        # Failures share the same ``⏺`` glyph as successes but get a
        # red tint; the auto-expanded args + result body are what makes
        # a failure visually distinct in scrollback.
        assert "⏺" in result.stderr

    def test_stream_compact_success_hides_full_result_body(self, runner, monkeypatch):
        """Compact mode never spills the result body into stderr — not
        the first line, not the rest. The user opted in to "show which
        tools ran"; they did *not* opt in to "show every tool's output."
        The full payload still lives in the trace, available via
        ``fruxon trace <record>``.
        """
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        # No part of this body should reach stderr in compact mode.
        first_line = "Returned 3 matches"
        hidden_line = "buried-detail-9173"
        result_body = f"{first_line}\nmatch 1: foo\nmatch 2: bar\n{hidden_line}\nmatch 3: baz"
        events = [
            StreamEvent(
                event="tool_call",
                data={
                    "id": "1",
                    "toolTrace": {"displayName": "lookup"},
                    "arguments": {"id": "42"},
                    "startTime": 0,
                },
            ),
            StreamEvent(
                event="tool_result",
                data={
                    "id": "1",
                    "endTime": 100,
                    "status": "SUCCESS",
                    "result": result_body,
                },
            ),
            StreamEvent(event="done", data={"trace": {}}),
        ]

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                yield from events

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent"])
        assert result.exit_code == 0
        # No part of the result body leaks — every line stays hidden.
        assert first_line not in result.stderr
        assert hidden_line not in result.stderr
        # The tool name itself does appear (that's the whole compact mode).
        assert "lookup" in result.stderr

    def test_stream_tool_block_uses_tree_shape(self, runner, monkeypatch):
        """Under ``-v``, each committed tool block follows Claude Code's
        tree shape: ``⏺`` header + ``⎿`` connectors for the args block
        and result block. Verifying both glyphs are present in
        scrollback locks in the layout against future regressions to
        a flat single-line style.
        """
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        events = [
            StreamEvent(
                event="tool_call",
                data={
                    "id": "1",
                    "toolTrace": {"displayName": "search"},
                    "arguments": {"q": "fruxon"},
                    "startTime": 0,
                },
            ),
            StreamEvent(
                event="tool_result",
                data={
                    "id": "1",
                    "endTime": 50,
                    "status": "SUCCESS",
                    "result": "Found 3 matches",
                },
            ),
            StreamEvent(event="done", data={"trace": {}}),
        ]

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                yield from events

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent", "-v"])
        assert result.exit_code == 0
        # Header glyph + tree connector both present.
        assert "⏺" in result.stderr
        assert "⎿" in result.stderr
        # Verbose mode surfaces the result body under the ⎿ branch.
        assert "Found 3 matches" in result.stderr

    def test_stream_text_chunks_arrive_intact_to_stdout(self, runner, monkeypatch):
        """Text chunks delivered over the stream must reach stdout
        byte-for-byte when stdout is not a TTY (the test harness, pipes,
        CI). This is the regression that prompted the whole rewrite:
        the old Live region on stderr raced with stdout writes and
        split each token onto its own line. The new ``_StreamView``
        pipe-mode path writes raw chunks straight to stdout with no
        Rich involvement, so reassembly is exact.
        """
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        # Deliberately fragmented stream — small chunks, mid-word
        # boundaries, varying punctuation. Reassembled they must form
        # the exact target text.
        target = "Heavy engineering week, concentrated in backend + frontend + RAG."
        chunks = [
            "Heavy ",
            "eng",
            "ineering ",
            "week, ",
            "concen",
            "trated in ",
            "backend ",
            "+ ",
            "frontend ",
            "+ ",
            "R",
            "AG",
            ".",
        ]
        assert "".join(chunks) == target

        events = [StreamEvent(event="text", data={"chunk": c}) for c in chunks]
        events.append(StreamEvent(event="done", data={"trace": {}}))

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                yield from events

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent"])
        assert result.exit_code == 0
        # Exact reassembly — no extra newlines, no missing chunks.
        assert target in result.stdout

    def test_stream_renders_tool_calls_to_stderr(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        events = [
            StreamEvent(event="text", data={"chunk": "Looking…"}),
            StreamEvent(
                event="tool_call",
                data={
                    "id": "1",
                    "toolTrace": {"displayName": "search_web"},
                    "arguments": {"q": "fruxon"},
                    "startTime": 100,
                },
            ),
            StreamEvent(
                event="tool_result",
                data={"id": "1", "result": "ok", "endTime": 500, "status": "SUCCESS"},
            ),
            StreamEvent(event="done", data={"trace": {}}),
        ]

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                yield from events

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent"])
        assert result.exit_code == 0
        # Tool chrome lands on stderr — the streamed text alone stays on stdout.
        assert "search_web" in result.stderr
        assert "Looking…" in result.stdout

    def test_error_event_exits_one(self, runner, monkeypatch):
        credentials.save(credentials.StoredCredentials(api_key="fxn_x", org="acme"))

        from fruxon.fruxon import StreamEvent

        events = [StreamEvent(event="error", data={"message": "oops", "code": "BadInput"})]

        class _StubClient:
            DEFAULT_BASE_URL = "https://api.fruxon.com"

            def __init__(self, **kwargs):
                pass

            def stream(self, agent, **kwargs):
                yield from events

        monkeypatch.setattr("fruxon.cli.run.FruxonClient", _StubClient)
        result = runner.invoke(app, ["run", "my-agent"])
        assert result.exit_code == 1
        assert "oops" in result.stderr
