"""Tests for the fruxon API client."""

import io
import json
import urllib.error
import urllib.request

import pytest

from fruxon.exceptions import (
    AuthenticationError,
    ForbiddenError,
    FruxonAPIError,
    FruxonConnectionError,
    NotFoundError,
    ValidationError,
)
from fruxon.fruxon import (
    Agent,
    ExecutionResult,
    ExecutionTrace,
    FruxonClient,
    StreamEvent,
    _is_active_agent,
    _iter_sse_events,
    _parse_agent,
    _parse_execution_result,
)

SAMPLE_RESPONSE = {
    "response": "Here is your answer.",
    "trace": {
        "agentId": "agent-1",
        "agentRevision": 3,
        "createdAt": 1700000000,
        "parameters": {},
        "startTime": 1700000000,
        "endTime": 1700000005,
        "duration": 5000,
        "traces": [],
        "result": {"strValue": "Here is your answer."},
        "inputCost": 0.001,
        "outputCost": 0.002,
        "totalCost": 0.003,
    },
    "sessionId": "sess-abc",
    "links": [],
    "executionRecordId": "rec-123",
}


class _MockResponse:
    """Mock urllib response with context manager support."""

    def __init__(self, data: dict):
        self._data = json.dumps(data).encode("utf-8")

    def read(self):
        return self._data

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


@pytest.fixture
def client():
    return FruxonClient(api_key="test-key", org="test-tenant")


class TestFruxonClientInit:
    def test_stores_config(self):
        c = FruxonClient(api_key="k", org="t")
        assert c._api_key == "k"
        assert c._org == "t"
        assert c._base_url == "https://api.fruxon.com"
        assert c._timeout == 120.0

    def test_custom_base_url(self):
        c = FruxonClient(api_key="k", org="t", base_url="https://staging.fruxon.com/")
        assert c._base_url == "https://staging.fruxon.com"

    def test_custom_timeout(self):
        c = FruxonClient(api_key="k", org="t", timeout=30.0)
        assert c._timeout == 30.0


class TestFruxonClientExecute:
    def test_sends_correct_request(self, client, monkeypatch):
        """Verify URL, headers, and body are correctly constructed."""
        captured = {}

        def mock_urlopen(req, timeout=None):
            captured["url"] = req.full_url
            captured["method"] = req.method
            captured["headers"] = dict(req.headers)
            captured["body"] = json.loads(req.data.decode("utf-8"))
            captured["timeout"] = timeout
            return _MockResponse(SAMPLE_RESPONSE)

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)

        client.execute("my-agent", parameters={"q": "hello"}, session_id="sess-1")

        assert captured["url"] == "https://api.fruxon.com/v1/tenants/test-tenant/agents/my-agent:execute"
        assert captured["method"] == "POST"
        assert captured["headers"]["Content-type"] == "application/json"
        assert captured["headers"]["X-api-key"] == "test-key"
        assert captured["body"] == {"parameters": {"q": "hello"}, "sessionId": "sess-1"}
        assert captured["timeout"] == 120.0

    def test_omits_none_fields(self, client, monkeypatch):
        """Only non-None fields appear in the request body."""
        captured = {}

        def mock_urlopen(req, timeout=None):
            captured["body"] = json.loads(req.data.decode("utf-8"))
            return _MockResponse(SAMPLE_RESPONSE)

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)

        client.execute("my-agent")
        assert captured["body"] == {}

    def test_maps_chat_user(self, client, monkeypatch):
        captured = {}

        def mock_urlopen(req, timeout=None):
            captured["body"] = json.loads(req.data.decode("utf-8"))
            return _MockResponse(SAMPLE_RESPONSE)

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)

        client.execute("my-agent", chat_user={"id": "user-1", "name": "Alice"})
        assert captured["body"]["chatUser"] == {"id": "user-1", "name": "Alice"}

    def test_returns_execution_result(self, client, monkeypatch):
        monkeypatch.setattr(urllib.request, "urlopen", lambda req, timeout=None: _MockResponse(SAMPLE_RESPONSE))

        result = client.execute("my-agent")

        assert isinstance(result, ExecutionResult)
        assert result.response == "Here is your answer."
        assert result.session_id == "sess-abc"
        assert result.execution_record_id == "rec-123"
        assert isinstance(result.trace, ExecutionTrace)
        assert result.trace.agent_id == "agent-1"
        assert result.trace.agent_revision == 3
        assert result.trace.duration == 5000
        assert result.trace.input_cost == 0.001
        assert result.trace.output_cost == 0.002
        assert result.trace.total_cost == 0.003


class TestErrorHandling:
    def _make_http_error(self, status: int, body: dict | None = None):
        if body is None:
            body = {"title": "Test Error", "detail": "Something went wrong"}
        return urllib.error.HTTPError(
            url="https://api.fruxon.com/v1/test",
            code=status,
            msg="Error",
            hdrs=None,
            fp=io.BytesIO(json.dumps(body).encode("utf-8")),
        )

    def test_401_raises_authentication_error(self, client, monkeypatch):
        def mock_urlopen(req, timeout=None):
            raise self._make_http_error(401)

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)

        with pytest.raises(AuthenticationError) as exc_info:
            client.execute("my-agent")
        assert exc_info.value.status == 401

    def test_403_raises_forbidden_error(self, client, monkeypatch):
        def mock_urlopen(req, timeout=None):
            raise self._make_http_error(403)

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)

        with pytest.raises(ForbiddenError) as exc_info:
            client.execute("my-agent")
        assert exc_info.value.status == 403

    def test_404_raises_not_found_error(self, client, monkeypatch):
        def mock_urlopen(req, timeout=None):
            raise self._make_http_error(404)

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)

        with pytest.raises(NotFoundError) as exc_info:
            client.execute("my-agent")
        assert exc_info.value.status == 404

    def test_400_raises_validation_error(self, client, monkeypatch):
        def mock_urlopen(req, timeout=None):
            raise self._make_http_error(400)

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)

        with pytest.raises(ValidationError) as exc_info:
            client.execute("my-agent")
        assert exc_info.value.status == 400

    def test_422_raises_validation_error(self, client, monkeypatch):
        def mock_urlopen(req, timeout=None):
            raise self._make_http_error(422)

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)

        with pytest.raises(ValidationError) as exc_info:
            client.execute("my-agent")
        assert exc_info.value.status == 422

    def test_unknown_status_raises_api_error(self, client, monkeypatch):
        def mock_urlopen(req, timeout=None):
            raise self._make_http_error(500)

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)

        with pytest.raises(FruxonAPIError) as exc_info:
            client.execute("my-agent")
        assert exc_info.value.status == 500

    def test_malformed_error_body(self, client, monkeypatch):
        """Non-JSON error response falls back gracefully."""
        error = urllib.error.HTTPError(
            url="https://api.fruxon.com/v1/test",
            code=502,
            msg="Bad Gateway",
            hdrs=None,
            fp=io.BytesIO(b"<html>Bad Gateway</html>"),
        )

        monkeypatch.setattr(urllib.request, "urlopen", lambda req, timeout=None: (_ for _ in ()).throw(error))

        with pytest.raises(FruxonAPIError) as exc_info:
            client.execute("my-agent")
        assert exc_info.value.status == 502
        assert exc_info.value.title == "Error"

    def test_network_error_raises_connection_error(self, client, monkeypatch):
        def mock_urlopen(req, timeout=None):
            raise urllib.error.URLError("Connection refused")

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)

        with pytest.raises(FruxonConnectionError, match="Connection refused"):
            client.execute("my-agent")


class TestParseResult:
    def test_full_response(self):
        result = _parse_execution_result(SAMPLE_RESPONSE)
        assert result.response == "Here is your answer."
        assert result.session_id == "sess-abc"
        assert result.execution_record_id == "rec-123"
        assert result.trace.agent_id == "agent-1"
        assert result.trace.duration == 5000
        assert result.trace.total_cost == 0.003

    def test_missing_fields_default(self):
        result = _parse_execution_result({})
        assert result.response == ""
        assert result.session_id == ""
        assert result.execution_record_id == ""
        assert result.trace.agent_id == ""
        assert result.trace.duration == 0
        assert result.trace.total_cost == 0.0


class TestFruxonClientExecuteRevision:
    """The revision-pinned execute hits a different URL but otherwise mirrors execute()."""

    def test_sends_correct_request(self, client, monkeypatch):
        captured = {}

        def mock_urlopen(req, timeout=None):
            captured["url"] = req.full_url
            captured["body"] = json.loads(req.data.decode("utf-8"))
            return _MockResponse(SAMPLE_RESPONSE)

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)

        client.execute_revision("my-agent", "42", parameters={"q": "hi"}, session_id="sess-1")

        assert captured["url"] == ("https://api.fruxon.com/v1/tenants/test-tenant/agents/my-agent/revisions/42:execute")
        assert captured["body"] == {"parameters": {"q": "hi"}, "sessionId": "sess-1"}

    def test_returns_execution_result(self, client, monkeypatch):
        monkeypatch.setattr(urllib.request, "urlopen", lambda req, timeout=None: _MockResponse(SAMPLE_RESPONSE))
        result = client.execute_revision("my-agent", "42")
        assert isinstance(result, ExecutionResult)
        assert result.response == "Here is your answer."


class TestFruxonClientStream:
    """The streaming endpoint returns SSE events that the SDK yields as typed objects."""

    @staticmethod
    def _sse_body(*events: tuple[str, str]) -> bytes:
        # Real backend separates events with a blank line; mimic that exactly.
        return ("".join(f"event: {name}\ndata: {data}\n\n" for name, data in events)).encode("utf-8")

    @staticmethod
    def _mock_stream(payload: bytes):
        class _Stream:
            def __init__(self, raw: bytes):
                self._iter = iter(raw.splitlines(keepends=True))

            def __iter__(self):
                return self._iter

            def close(self):
                pass

        return _Stream(payload)

    def test_yields_typed_events(self, client, monkeypatch):
        body = self._sse_body(
            ("text", '{"chunk": "Hello "}'),
            ("text", '{"chunk": "world"}'),
            ("done", '{"trace": {"duration": 100}}'),
        )

        monkeypatch.setattr(urllib.request, "urlopen", lambda req, timeout=None: self._mock_stream(body))

        events = list(client.stream("my-agent", parameters={"q": "hi"}))

        assert events == [
            StreamEvent(event="text", data={"chunk": "Hello "}),
            StreamEvent(event="text", data={"chunk": "world"}),
            StreamEvent(event="done", data={"trace": {"duration": 100}}),
        ]

    def test_sends_correct_request(self, client, monkeypatch):
        captured = {}

        def mock_urlopen(req, timeout=None):
            captured["url"] = req.full_url
            captured["headers"] = dict(req.headers)
            captured["body"] = json.loads(req.data.decode("utf-8"))
            return self._mock_stream(self._sse_body(("done", "{}")))

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)

        list(client.stream("my-agent", parameters={"q": "hi"}))

        assert captured["url"] == "https://api.fruxon.com/v1/tenants/test-tenant/agents/my-agent:stream"
        assert captured["headers"]["Accept"] == "text/event-stream"
        assert captured["headers"]["X-api-key"] == "test-key"
        assert captured["body"] == {"parameters": {"q": "hi"}}

    def test_stream_text_filters_to_text_events(self, client, monkeypatch):
        body = self._sse_body(
            ("text", '{"chunk": "Hello "}'),
            ("tool_call", '{"id": "1", "toolTrace": {"displayName": "search"}}'),
            ("text", '{"chunk": "world"}'),
            # ``StepTraceStatus`` enum on the backend = SUCCESS / ERROR.
            ("tool_result", '{"id": "1", "status": "SUCCESS"}'),
            ("done", "{}"),
        )

        monkeypatch.setattr(urllib.request, "urlopen", lambda req, timeout=None: self._mock_stream(body))

        chunks = list(client.stream_text("my-agent"))
        assert chunks == ["Hello ", "world"]

    def test_ignores_sse_comments_and_heartbeats(self, client, monkeypatch):
        # `:` lines are SSE comments — used as keep-alives by some servers.
        # Bare blank lines without a preceding event should also not yield.
        raw = b': heartbeat\n\nevent: text\ndata: {"chunk": "x"}\n\n'
        monkeypatch.setattr(urllib.request, "urlopen", lambda req, timeout=None: self._mock_stream(raw))

        events = list(client.stream("my-agent"))
        assert events == [StreamEvent(event="text", data={"chunk": "x"})]


class TestSseParser:
    """_iter_sse_events handles malformed payloads without crashing the iterator."""

    @staticmethod
    def _stream(raw: bytes):
        class _S:
            def __init__(self, b: bytes):
                self._b = iter(b.splitlines(keepends=True))

            def __iter__(self):
                return self._b

            def close(self):
                pass

        return _S(raw)

    def test_multiline_data_concatenated_with_newline(self):
        raw = b"event: text\ndata: line1\ndata: line2\n\n"
        # The two `data:` lines should be joined with a literal newline before JSON parsing.
        events = list(_iter_sse_events(self._stream(raw)))
        # Not valid JSON, so it lands in `_raw` payload.
        assert events[0].event == "text"
        assert events[0].data == {"_raw": "line1\nline2"}

    def test_malformed_json_falls_back_to_raw(self):
        raw = b"event: text\ndata: not-json\n\n"
        events = list(_iter_sse_events(self._stream(raw)))
        assert events == [StreamEvent(event="text", data={"_raw": "not-json"})]


# ─────────────────────────────────────────────────────────────────────────────
# Agent discovery
# ─────────────────────────────────────────────────────────────────────────────


_AGENT_SAMPLE = {
    "id": "agent-1",
    "displayName": "Support Agent",
    "description": "Handles customer support tickets.",
    "enabled": True,
    "currentRevision": 7,
    "tags": ["support", "tier-1"],
    "type": "Native",
    "createdAt": 1700000000,
    "modifiedAt": 1700000100,
    "tenantId": "00000000-0000-0000-0000-000000000000",
}


class TestParseAgent:
    def test_full_payload(self):
        agent = _parse_agent(_AGENT_SAMPLE)
        assert agent == Agent(
            id="agent-1",
            display_name="Support Agent",
            description="Handles customer support tickets.",
            enabled=True,
            current_revision=7,
            tags=["support", "tier-1"],
        )

    def test_missing_fields_default(self):
        # The server may add/remove fields over time; defaults must be safe.
        agent = _parse_agent({})
        assert agent.id == ""
        assert agent.display_name == ""
        assert agent.enabled is False
        assert agent.current_revision == 0
        assert agent.tags == []

    def test_non_string_tags_filtered(self):
        # Defensive: if the API ever returns an unusual tag shape we don't
        # want to crash the whole list call.
        agent = _parse_agent({**_AGENT_SAMPLE, "tags": ["ok", 42, None]})
        assert agent.tags == ["ok"]

    def test_non_dict_raises(self):
        from fruxon.exceptions import FruxonAPIError

        with pytest.raises(FruxonAPIError, match="agent object"):
            _parse_agent("not a dict")


class TestActiveAgentFilter:
    def test_active_when_no_deleted_at(self):
        assert _is_active_agent(_AGENT_SAMPLE) is True

    def test_soft_deleted_filtered_out(self):
        assert _is_active_agent({**_AGENT_SAMPLE, "deletedAt": 1700000200}) is False

    def test_non_dict_dropped(self):
        assert _is_active_agent("oops") is False


class TestListAgents:
    def test_filters_soft_deleted(self, client, monkeypatch):
        payload = [
            _AGENT_SAMPLE,
            {**_AGENT_SAMPLE, "id": "agent-2", "deletedAt": 1700000200},
            {**_AGENT_SAMPLE, "id": "agent-3"},
        ]
        monkeypatch.setattr(
            urllib.request,
            "urlopen",
            lambda req, timeout=None: _MockResponse(payload),
        )

        agents = client.list_agents()
        ids = [a.id for a in agents]
        assert ids == ["agent-1", "agent-3"]

    def test_hits_correct_url(self, client, monkeypatch):
        captured = {}

        def mock_urlopen(req, timeout=None):
            captured["url"] = req.full_url
            captured["method"] = req.method
            return _MockResponse([])

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)
        client.list_agents()

        assert captured["url"] == "https://api.fruxon.com/v1/tenants/test-tenant/agents"
        assert captured["method"] == "GET"

    def test_non_list_response_raises(self, client, monkeypatch):
        from fruxon.exceptions import FruxonAPIError

        monkeypatch.setattr(
            urllib.request,
            "urlopen",
            lambda req, timeout=None: _MockResponse({"unexpected": "shape"}),
        )
        with pytest.raises(FruxonAPIError):
            client.list_agents()


class TestGetAgent:
    def test_hits_correct_url(self, client, monkeypatch):
        captured = {}

        def mock_urlopen(req, timeout=None):
            captured["url"] = req.full_url
            return _MockResponse(_AGENT_SAMPLE)

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)
        client.get_agent("my-agent")

        assert captured["url"] == "https://api.fruxon.com/v1/tenants/test-tenant/agents/my-agent"

    def test_returns_agent_object(self, client, monkeypatch):
        monkeypatch.setattr(
            urllib.request,
            "urlopen",
            lambda req, timeout=None: _MockResponse(_AGENT_SAMPLE),
        )
        agent = client.get_agent("agent-1")
        assert agent.id == "agent-1"
        assert agent.display_name == "Support Agent"

    def test_404_raises_not_found(self, client, monkeypatch):
        from fruxon.exceptions import NotFoundError

        def mock_urlopen(req, timeout=None):
            raise urllib.error.HTTPError(
                url=req.full_url,
                code=404,
                msg="Not Found",
                hdrs=None,
                fp=io.BytesIO(b'{"title":"Not Found"}'),
            )

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)
        with pytest.raises(NotFoundError):
            client.get_agent("missing")


class TestGetAgentParameters:
    """``get_agent_parameters`` powers the ``fruxon agents get`` parameters row
    and is the only programmatic way to learn an agent's input keys without
    triggering a real execution.
    """

    def test_hits_revision_parameters_url(self, client, monkeypatch):
        captured = {}

        def mock_urlopen(req, timeout=None):
            captured["url"] = req.full_url
            captured["method"] = req.get_method()
            return _MockResponse({"parameters": ["user_query"]})

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)
        client.get_agent_parameters("my-agent", 7)

        assert captured["url"] == (
            "https://api.fruxon.com/v1/tenants/test-tenant/agents/my-agent/revisions/7:parameters"
        )
        # GET-only — must not POST a body to a parameter discovery endpoint.
        assert captured["method"] == "GET"

    def test_accepts_string_revision(self, client, monkeypatch):
        captured = {}

        def mock_urlopen(req, timeout=None):
            captured["url"] = req.full_url
            return _MockResponse({"parameters": []})

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)
        # Some callers (the CLI today) pass the revision as an int; future
        # surfaces may pass a string. Both should produce the same URL.
        client.get_agent_parameters("my-agent", "12")
        assert captured["url"].endswith("/revisions/12:parameters")

    def test_returns_parameter_names(self, client, monkeypatch):
        monkeypatch.setattr(
            urllib.request,
            "urlopen",
            lambda req, timeout=None: _MockResponse({"parameters": ["a", "b", "c"]}),
        )
        assert client.get_agent_parameters("agent-1", 3) == ["a", "b", "c"]

    def test_filters_non_string_entries(self, client, monkeypatch):
        # Server might return null / numeric entries during schema drift —
        # the SDK should silently drop them so callers see a clean list.
        monkeypatch.setattr(
            urllib.request,
            "urlopen",
            lambda req, timeout=None: _MockResponse({"parameters": ["ok", None, 42, ""]}),
        )
        assert client.get_agent_parameters("agent-1", 3) == ["ok"]

    def test_handles_missing_parameters_field(self, client, monkeypatch):
        # Empty / unexpected payload shapes should produce an empty list,
        # not an exception. ``agents get`` calls this opportunistically and
        # falls back to "no parameters row" if it can't get a clean list.
        monkeypatch.setattr(
            urllib.request,
            "urlopen",
            lambda req, timeout=None: _MockResponse({}),
        )
        assert client.get_agent_parameters("agent-1", 3) == []

    def test_404_raises_not_found(self, client, monkeypatch):
        def mock_urlopen(req, timeout=None):
            raise urllib.error.HTTPError(
                url=req.full_url,
                code=404,
                msg="Not Found",
                hdrs=None,
                fp=io.BytesIO(b'{"title":"Not Found"}'),
            )

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)
        with pytest.raises(NotFoundError):
            client.get_agent_parameters("agent-1", 3)


# ─────────────────────────────────────────────────────────────────────────────
# Execution records / trace
# ─────────────────────────────────────────────────────────────────────────────


_RECORD_SAMPLE = {
    "id": "rec-1",
    "agentId": "agent-1",
    "agentRevision": 3,
    # ``AgentExecutionRecordStatus`` enum on the backend is SCREAMING_SNAKE:
    # IN_PROGRESS / WAITING_FOR_HUMAN / COMPLETED / FAILED / CANCELLED.
    "status": "COMPLETED",
    "startTime": 1700000000000,
    "endTime": 1700000005000,
    "inputTokens": 100,
    "outputTokens": 200,
    "totalCost": 0.001,
}


class TestGetExecutionRecord:
    def test_hits_correct_url(self, client, monkeypatch):
        captured = {}

        def mock_urlopen(req, timeout=None):
            captured["url"] = req.full_url
            return _MockResponse(_RECORD_SAMPLE)

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)
        client.get_execution_record("agent-1", "rec-1")
        assert captured["url"] == (
            "https://api.fruxon.com/v1/tenants/test-tenant/agents/agent-1/executionRecords/rec-1"
        )

    def test_returns_record_with_derived_duration(self, client, monkeypatch):
        monkeypatch.setattr(
            urllib.request,
            "urlopen",
            lambda req, timeout=None: _MockResponse(_RECORD_SAMPLE),
        )
        record = client.get_execution_record("agent-1", "rec-1")
        assert record.id == "rec-1"
        assert record.duration_ms == 5000  # 1700000005000 - 1700000000000

    def test_handles_in_progress_record(self, client, monkeypatch):
        # endTime=None → record is still running; duration_ms returns None
        # so callers can show "in progress" instead of a misleading 0.
        monkeypatch.setattr(
            urllib.request,
            "urlopen",
            lambda req, timeout=None: _MockResponse({**_RECORD_SAMPLE, "endTime": None}),
        )
        record = client.get_execution_record("agent-1", "rec-1")
        assert record.end_time is None
        assert record.duration_ms is None


class TestGetExecutionTrace:
    def test_hits_trace_action_url(self, client, monkeypatch):
        captured = {}

        def mock_urlopen(req, timeout=None):
            captured["url"] = req.full_url
            return _MockResponse({"trace": {"steps": []}})

        monkeypatch.setattr(urllib.request, "urlopen", mock_urlopen)
        client.get_execution_trace("agent-1", "rec-1")
        assert captured["url"].endswith("/executionRecords/rec-1:trace")

    def test_returns_raw_payload(self, client, monkeypatch):
        payload = {"trace": {"steps": [{"kind": "llm"}]}, "status": "COMPLETED"}
        monkeypatch.setattr(
            urllib.request,
            "urlopen",
            lambda req, timeout=None: _MockResponse(payload),
        )
        result = client.get_execution_trace("agent-1", "rec-1")
        assert result == payload

    def test_non_dict_response_raises(self, client, monkeypatch):
        from fruxon.exceptions import FruxonAPIError

        monkeypatch.setattr(
            urllib.request,
            "urlopen",
            lambda req, timeout=None: _MockResponse([1, 2, 3]),
        )
        with pytest.raises(FruxonAPIError):
            client.get_execution_trace("agent-1", "rec-1")
