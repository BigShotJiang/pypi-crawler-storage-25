"""``fruxon export`` — bundle a multi-file Python agent into one importable file.

Auto-detects the agent entry point by scanning for framework imports
(LangChain, CrewAI, Google ADK, etc.). When the heuristic finds more than
one candidate, the CLI surfaces them as a numbered list and lets the user
pick interactively.
"""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from fruxon.cli import app
from fruxon.ui import stderr


@app.command()
def export(
    entry_point: Annotated[
        Path | None, typer.Argument(help="Path to the main Python file. Auto-detected if omitted.")
    ] = None,
    output: Annotated[
        Path | None, typer.Option("--output", "-o", help="Write output to file instead of stdout")
    ] = None,
    copy: Annotated[bool, typer.Option("--copy", "-c", help="Copy output to clipboard")] = False,
):
    """Export a multi-file Python agent into a single file for Fruxon import.

    Auto-detects the agent entry point by scanning for framework imports
    (LangChain, CrewAI, Google ADK, etc.). You can also specify the entry
    point explicitly.

    Examples:
        fruxon export
        fruxon export graph.py
        fruxon export my_agent/main.py -o export.py
        fruxon export --copy
    """
    # Imported lazily so the export module's AST-walking machinery only
    # loads when ``fruxon export`` actually runs. Saves ~5 ms off cold
    # start for every other command.
    from rich.prompt import IntPrompt

    from fruxon.exceptions import MultipleAgentsError
    from fruxon.export import export_agent

    try:
        result = export_agent(
            str(entry_point) if entry_point else None,
            str(output) if output else None,
            stderr,
        )
    except MultipleAgentsError as e:
        choice = IntPrompt.ask(
            "\nWhich agent do you want to export?",
            choices=[str(i) for i in range(1, len(e.entry_points) + 1)],
        )
        selected_path = e.entry_points[choice - 1][0]
        result = export_agent(str(selected_path), str(output) if output else None, stderr)

    _handle_output(result, output, copy)


def _handle_output(result: str, output: Path | None, copy: bool) -> None:
    """Handle clipboard copy and stdout output."""
    if copy:
        _copy_to_clipboard(result)

    if not output and not copy:
        # Print code to stdout (not stderr) so it can be piped
        print(result)
    elif not output and copy:
        lines = result.count("\n") + 1
        stderr.print(f"[green]>[/green] {lines} lines ready to paste into Fruxon.")


def _copy_to_clipboard(text: str) -> None:
    """Copy text to system clipboard."""
    import subprocess

    for cmd in [["pbcopy"], ["xclip", "-selection", "clipboard"]]:
        try:
            process = subprocess.Popen(cmd, stdin=subprocess.PIPE)
            process.communicate(text.encode("utf-8"))
            stderr.print("[green]>[/green] Copied to clipboard.")
            return
        except FileNotFoundError:
            continue
    stderr.print("[yellow]Clipboard not available. Install xclip or use -o to write to file.[/yellow]")
