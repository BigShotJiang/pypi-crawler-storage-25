# V7 Capital MCP Server

AI-powered asset management through conversation. Manage cap tables, portfolio investments, companies, and financials via Claude Desktop, Claude Code, or any MCP client.

## Installation

```bash
pip install v7capital-mcp
```

Or with uv:

```bash
# Install uv (if not already installed)
brew install uv

# Add uv tools to PATH (one-time setup)
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc

# Install v7capital-mcp
uv tool install v7capital-mcp
```

Already installed? Update:

```bash
pip install --upgrade v7capital-mcp
# or
uv tool upgrade v7capital-mcp
```

## Authentication

```bash
v7capital-cli login
```

## Usage

### Claude Code
```bash
claude mcp add v7capital -- v7capital-mcp
```

### Claude Desktop
Add to `claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "v7capital": {
      "command": "v7capital-mcp"
    }
  }
}
```

### Claude Desktop / ChatGPT (remote OAuth — no install required)

Add as custom connector pointing to `https://mcp.v7capital.ro`. The browser will open a consent page (`/accounts/mcp-authorize`) where you log in once and approve the connection.

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `V7_API_URL` | `https://www.v7capital.ro` | API base URL the MCP container calls (OAuth + tools + token verify) |
| `MCP_BASE_URL` | `https://mcp.v7capital.ro` | Public URL of the MCP container (used in OAuth metadata) — HTTP mode only |
| `PORT` | `3000` | HTTP port for `v7capital-mcp-http` |

## Tools (~53)

- **Cap Table**: list/create funds, rounds, stakeholders, securities, transactions; get cap table; list commitments
- **Companies**: list/create/update companies, income statements, balance sheets, cash flow statements, financial metrics, KPIs, KPI values
- **Portfolio**: deal pipeline (CRUD), investments (CRU), cash flows (CRU), performance (CRU)
- **Fund Admin**: list/create/update fee costs
- **Audit**: list audit logs
