"""
V7 Capital MCP Server

FastMCP instance with all tools registered.
Entrypoints:
- v7capital-mcp: stdio transport (Claude Desktop/Code/Cursor) — credentials.json auth.
- v7capital-mcp-http: Streamable HTTP transport (Claude Desktop connector / ChatGPT) — OAuth 2.0 + PKCE.
"""

from fastmcp import FastMCP

mcp = FastMCP(
    "V7 Capital",
    instructions=(
        "V7 Capital Asset Manager — manage cap tables, portfolio investments, companies, and financials through conversation.\n\n"
        "IMPORTANT: Before using any tools, the user must have run 'v7capital-cli login' in their terminal (stdio mode) "
        "or completed the OAuth flow in the browser (remote/HTTP mode).\n\n"
        "This is a single-organization platform (V7 Capital). No context switching needed — all tools operate on V7 Capital data directly.\n\n"
        "Domains:\n"
        "- Cap Table: funds, rounds, stakeholders, securities, transactions, commitments\n"
        "- Companies: company profiles + financial statements (income, balance, cash flow, metrics, KPIs)\n"
        "- Portfolio: deal pipeline, investments, cash flows, performance\n"
        "- Fund Admin: fee costs\n"
        "- Audit: view change history"
    ),
    mask_error_details=True,
)

# Register all tools by importing tool modules
from .tools import captable  # noqa: F401, E402
from .tools import companies  # noqa: F401, E402
from .tools import portfolio  # noqa: F401, E402
from .tools import fees  # noqa: F401, E402
from .tools import audit  # noqa: F401, E402


def main():
    """Entrypoint for v7capital-mcp command. Runs stdio transport for Claude Desktop/Code/Codex."""
    mcp.run()


def main_http():
    """Entrypoint for v7capital-mcp-http command. Runs Streamable HTTP transport with OAuth 2.0 + PKCE.
    Used by Claude Desktop connector / ChatGPT / Cursor for remote authenticated access.
    Deploy as standalone container at mcp.v7capital.ro."""
    from .auth_provider import V7CapitalOAuthProvider
    from .config import MCP_BASE_URL
    import os

    port = int(os.environ.get("PORT", "8811"))
    mcp.auth = V7CapitalOAuthProvider(base_url=MCP_BASE_URL)
    mcp.run(transport="http", host="0.0.0.0", port=port)
