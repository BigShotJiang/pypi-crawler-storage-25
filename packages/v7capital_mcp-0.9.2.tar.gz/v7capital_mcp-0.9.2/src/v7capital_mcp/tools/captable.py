"""
Cap Table tools — funds, rounds, stakeholders, securities, transactions.

Read + Create only (no update/delete via MCP — admin manages lifecycle via UI).
"""

from typing import Literal

from fastmcp import Context

from ..server import mcp
from ..client import get_client


# ==========================================
# Funds
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_funds(ctx: Context) -> str:
    """List all investment funds."""
    client = await get_client(ctx)
    result = await client.get("/api/assetmanager/captable/funds")
    items = result.get("data", [])

    if not items:
        return "No funds found."

    lines = [f"Funds ({len(items)}):"]
    for f in items:
        lines.append(f"  - {f['name']} (id={f['id']}, status={f.get('status', '—')}, currency={f.get('currency', '—')})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_fund(ctx: Context, fund_id: int) -> str:
    """Get details of a specific fund by ID."""
    client = await get_client(ctx)
    result = await client.get(f"/api/assetmanager/captable/funds/{fund_id}")
    f = result.get("data")

    if not f:
        return f"Fund {fund_id} not found."

    return (
        f"Fund: {f['name']} (id={f['id']})\n"
        f"  Status: {f.get('status', '—')}\n"
        f"  Currency: {f.get('currency', '—')}\n"
        f"  Vintage: {f.get('vintage', '—')}\n"
        f"  Description: {f.get('description', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_fund(
    ctx: Context,
name: str,
    currency: str = "USD",
    status: Literal["Active", "Fundraising", "Closed", "Liquidating"] = "Active",
    vintage: int | None = None,
    description: str | None = None,
) -> str:
    """Create a new investment fund."""
    payload: dict = {"name": name, "currency": currency, "status": status}
    if vintage is not None:
        payload["vintage"] = vintage
    if description:
        payload["description"] = description

    client = await get_client(ctx)
    result = await client.post("/api/assetmanager/captable/funds", payload)
    f = result["data"]
    return f"Fund created: {f['name']} (id={f['id']}, currency={f['currency']}, status={f['status']})."


# ==========================================
# Rounds
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def get_round(ctx: Context, round_id: int) -> str:
    """Get details of a specific funding round by ID."""
    client = await get_client(ctx)
    result = await client.get(f"/api/assetmanager/captable/rounds/{round_id}")
    r = result.get("data")

    if not r:
        return f"Round {round_id} not found."

    return (
        f"Round: {r['roundName']} (id={r['id']})\n"
        f"  Type: {r.get('roundType', '—')}\n"
        f"  Fund ID: {r.get('fundId', '—')}\n"
        f"  Date: {r.get('roundDate', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": True})
async def list_rounds(ctx: Context) -> str:
    """List all funding rounds across all funds."""
    client = await get_client(ctx)
    result = await client.get("/api/assetmanager/captable/rounds")
    items = result.get("data", [])

    if not items:
        return "No rounds found."

    lines = [f"Rounds ({len(items)}):"]
    for r in items:
        lines.append(f"  - {r['roundName']} (id={r['id']}, type={r.get('roundType', '—')}, fund_id={r['fundId']}, date={r.get('roundDate', '—')})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_round(
    ctx: Context,
fund_id: int,
    round_name: str,
    round_type: Literal["Seed", "Pre Series A", "Series A", "Series B", "Series C", "Debt", "Convertible", "SAFE", "Bridge", "Secondary", "Other"],
    round_date: str,
) -> str:
    """Create a new funding round. Date format: YYYY-MM-DD."""
    client = await get_client(ctx)
    result = await client.post("/api/assetmanager/captable/rounds", {
        "fundId": fund_id,
        "roundName": round_name,
        "roundType": round_type,
        "roundDate": round_date,
    })
    r = result["data"]
    return f"Round created: {r['roundName']} (id={r['id']}, type={r['roundType']})."


# ==========================================
# Stakeholders
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def get_stakeholder(ctx: Context, stakeholder_id: int) -> str:
    """Get details of a specific stakeholder by ID."""
    client = await get_client(ctx)
    result = await client.get(f"/api/assetmanager/captable/stakeholders/{stakeholder_id}")
    s = result.get("data")

    if not s:
        return f"Stakeholder {stakeholder_id} not found."

    return (
        f"Stakeholder: {s['stakeholderName']} (id={s['id']})\n"
        f"  Type: {s.get('type', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": True})
async def list_stakeholders(ctx: Context) -> str:
    """List all stakeholders."""
    client = await get_client(ctx)
    result = await client.get("/api/assetmanager/captable/stakeholders")
    items = result.get("data", [])

    if not items:
        return "No stakeholders found."

    lines = [f"Stakeholders ({len(items)}):"]
    for s in items:
        lines.append(f"  - {s['stakeholderName']} (id={s['id']}, type={s.get('type', '—')})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_stakeholder(
    ctx: Context,
stakeholder_name: str,
    type: Literal["Fund", "Investor", "Employee"] = "Investor",
) -> str:
    """Add a stakeholder."""
    client = await get_client(ctx)
    result = await client.post("/api/assetmanager/captable/stakeholders", {
        "stakeholderName": stakeholder_name,
        "type": type,
    })
    s = result["data"]
    return f"Stakeholder created: {s['stakeholderName']} (id={s['id']}, type={s['type']})."


# ==========================================
# Securities
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def get_security(ctx: Context, security_id: int) -> str:
    """Get details of a specific security by ID."""
    client = await get_client(ctx)
    result = await client.get(f"/api/assetmanager/captable/securities/{security_id}")
    s = result.get("data")

    if not s:
        return f"Security {security_id} not found."

    price = f"\n  Issue Price: {s['issuePrice']}" if s.get("issuePrice") else ""
    return (
        f"Security: {s['securityName']} (id={s['id']})\n"
        f"  Code: {s.get('code', '—')}\n"
        f"  Type: {s.get('securityType', '—')}\n"
        f"  Currency: {s.get('currency', '—')}\n"
        f"  Round ID: {s.get('roundId', '—')}{price}"
    )


@mcp.tool(annotations={"readOnlyHint": True})
async def list_securities(ctx: Context) -> str:
    """List all securities across all rounds."""
    client = await get_client(ctx)
    result = await client.get("/api/assetmanager/captable/securities")
    items = result.get("data", [])

    if not items:
        return "No securities found."

    lines = [f"Securities ({len(items)}):"]
    for s in items:
        price = f", price={s['issuePrice']}" if s.get("issuePrice") else ""
        lines.append(f"  - {s['securityName']} (id={s['id']}, code={s['code']}, type={s['securityType']}, round_id={s['roundId']}{price})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_security(
    ctx: Context,
round_id: int,
    security_name: str,
    code: str,
    security_type: Literal["Common Shares", "Preferred Shares", "Convertible", "Warrant", "Option", "Bond"],
    currency: str = "USD",
    issue_price: float | None = None,
) -> str:
    """Create a new security class under a funding round."""
    payload: dict = {
        "roundId": round_id,
        "securityName": security_name,
        "code": code,
        "securityType": security_type,
        "currency": currency,
    }
    if issue_price is not None:
        payload["issuePrice"] = issue_price

    client = await get_client(ctx)
    result = await client.post("/api/assetmanager/captable/securities", payload)
    s = result["data"]
    return f"Security created: {s['securityName']} (id={s['id']}, type={s['securityType']}, code={s['code']})."


# ==========================================
# Transactions
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def get_transaction(ctx: Context, transaction_id: int) -> str:
    """Get details of a specific transaction by ID."""
    client = await get_client(ctx)
    result = await client.get(f"/api/assetmanager/captable/transactions/{transaction_id}")
    t = result.get("data")

    if not t:
        return f"Transaction {transaction_id} not found."

    return (
        f"Transaction (id={t['id']})\n"
        f"  Reference: {t.get('transactionReference', '—')}\n"
        f"  Type: {t.get('transactionType', '—')}\n"
        f"  Date: {t.get('transactionDate', '—')}\n"
        f"  Stakeholder ID: {t.get('stakeholderId', '—')}\n"
        f"  Security ID: {t.get('securityId', '—')}\n"
        f"  Fund ID: {t.get('fundId', '—')}\n"
        f"  Round ID: {t.get('roundId', '—')}\n"
        f"  Amount Debit: {t.get('amountDebit', 0)}\n"
        f"  Amount Credit: {t.get('amountCredit', 0)}\n"
        f"  Units Debit: {t.get('unitsDebit', 0)}\n"
        f"  Units Credit: {t.get('unitsCredit', 0)}\n"
        f"  Notes: {t.get('notes', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": True})
async def list_transactions(ctx: Context) -> str:
    """List all security transactions."""
    client = await get_client(ctx)
    result = await client.get("/api/assetmanager/captable/transactions")
    items = result.get("data", [])

    if not items:
        return "No transactions found."

    lines = [f"Transactions ({len(items)}):"]
    for t in items:
        ref = t.get("transactionReference", "—")
        ttype = t.get("transactionType", "—")
        date = t.get("transactionDate", "—")
        lines.append(f"  - {ref} | {ttype} | {date} | debit={t.get('amountDebit', 0)} credit={t.get('amountCredit', 0)}")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_transaction(
    ctx: Context,
stakeholder_id: int,
    security_id: int,
    fund_id: int,
    round_id: int,
    transaction_type: Literal["ISSUANCE", "DISTRIBUTION", "REDEMPTION", "TRANSFER_IN", "TRANSFER_OUT", "CASH_IN", "CASH_OUT", "COUPON_IN", "COUPON_OUT", "CONVERSION_IN", "CONVERSION_OUT", "SPLIT", "CONSOLIDATION", "GRANT", "VEST", "EXERCISE", "EXPIRE", "FORFEIT", "CANCEL", "DIVIDEND", "INTEREST", "ADJUSTMENT"],
    transaction_date: str,
    transaction_reference: str,
    amount_debit: float = 0,
    amount_credit: float = 0,
    units_debit: float = 0,
    units_credit: float = 0,
    notes: str | None = None,
) -> str:
    """Create a security transaction. Date format: YYYY-MM-DD. transaction_reference must be unique."""
    payload: dict = {
        "stakeholderId": stakeholder_id,
        "securityId": security_id,
        "fundId": fund_id,
        "roundId": round_id,
        "transactionType": transaction_type,
        "transactionDate": transaction_date,
        "transactionReference": transaction_reference,
        "amountDebit": amount_debit,
        "amountCredit": amount_credit,
        "unitsDebit": units_debit,
        "unitsCredit": units_credit,
    }
    if notes:
        payload["notes"] = notes

    client = await get_client(ctx)
    result = await client.post("/api/assetmanager/captable/transactions", payload)
    t = result["data"]
    return f"Transaction created (id={t['id']}, type={t['transactionType']}, ref={t['transactionReference']})."


# ==========================================
# Cap Table (computed view)
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def get_cap_table(ctx: Context) -> str:
    """Get the computed cap table — ownership breakdown by stakeholder."""
    client = await get_client(ctx)
    result = await client.get("/api/assetmanager/captable/cap-table")
    rows = result.get("data", [])

    if not rows:
        return "No cap table entries. Create stakeholders and transactions first."

    lines = [f"Cap Table ({len(rows)} entries):"]
    for row in rows:
        lines.append(
            f"  - stakeholder_id={row.get('stakeholderId')} | "
            f"security_id={row.get('securityId')} | "
            f"units={row.get('totalEquityUnits', 0)} | "
            f"ownership={row.get('ownershipPercentage', 0)}%"
        )

    return "\n".join(lines)


# ==========================================
# Commitments (read-only)
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def get_commitment(ctx: Context, commitment_id: int) -> str:
    """Get details of a specific commitment by ID."""
    client = await get_client(ctx)
    result = await client.get(f"/api/assetmanager/captable/commitments/{commitment_id}")
    c = result.get("data")

    if not c:
        return f"Commitment {commitment_id} not found."

    return (
        f"Commitment (id={c['id']})\n"
        f"  Stakeholder ID: {c.get('stakeholderId', '—')}\n"
        f"  Round ID: {c.get('roundId', '—')}\n"
        f"  Fund ID: {c.get('fundId', '—')}\n"
        f"  Security ID: {c.get('securityId', '—')}\n"
        f"  Status: {c.get('status', '—')}\n"
        f"  Pro-Rata %: {c.get('proRataPercentage', '—')}\n"
        f"  Pro-Rata Amount: {c.get('proRataAmount', '—')}\n"
        f"  Committed Amount: {c.get('committedAmount', '—')}\n"
        f"  Commitment Type: {c.get('commitmentType', '—')}\n"
        f"  Notes: {c.get('notes', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": True})
async def list_commitments(ctx: Context) -> str:
    """List all commitment invitations."""
    client = await get_client(ctx)
    result = await client.get("/api/assetmanager/captable/commitments")
    items = result.get("data", [])

    if not items:
        return "No commitments found."

    lines = [f"Commitments ({len(items)}):"]
    for c in items:
        lines.append(
            f"  - id={c['id']} | stakeholder_id={c['stakeholderId']} | "
            f"status={c['status']} | pro_rata={c.get('proRataAmount', '—')} | "
            f"committed={c.get('committedAmount', '—')}"
        )

    return "\n".join(lines)
