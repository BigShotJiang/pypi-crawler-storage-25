"""V7 Capital MCP Tools — organized by domain."""
