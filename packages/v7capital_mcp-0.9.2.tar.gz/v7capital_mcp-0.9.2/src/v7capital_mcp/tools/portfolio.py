"""
Portfolio tools — deal pipeline (CRUD), investments, cash flows, performance (CRU).

Deal pipeline is the only model with DELETE support.
Fee costs are managed separately in fees.py.
"""

from typing import Literal

from fastmcp import Context

from ..server import mcp
from ..client import get_client


# ==========================================
# Shared Literal types (match Zod schemas)
# ==========================================

DealPriority = Literal["P1", "P2", "P3", "P4", "P5"]
DealStatus = Literal["Initial Screening", "First Meeting", "Follow Up", "Due Diligence", "Negotiation", "Term Sheet", "Legal Review", "Closing", "Closed", "Rejected", "On Hold"]
SectorType = Literal["Fintech", "Healthtech", "Ecommerce", "SaaS", "AI/ML", "Blockchain", "Cleantech", "Edtech", "Enterprise", "Consumer", "Other"]
PortfolioStatus = Literal["Active", "Exited", "Written Off", "On Hold"]
InvestmentType = Literal["Equity", "Debt", "Convertible", "Warrant", "Option", "Cash"]
CompanyType = Literal["Venture Capital", "Private Equity", "Public", "Cash"]
CashFlowType = Literal["Investment", "Follow-on", "Dividend", "Interest", "Sale Proceeds", "Exit Proceeds", "Distribution", "Management Fee", "Performance Fee"]


# ==========================================
# Deal Pipeline
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_deal_pipeline(ctx: Context) -> str:
    """List all deals in the pipeline."""
    client = await get_client(ctx)
    result = await client.get("/api/assetmanager/portfolio/deal-pipeline")
    items = result.get("data", [])

    if not items:
        return "No deals found in the pipeline."

    lines = [f"Deal Pipeline ({len(items)}):"]
    for d in items:
        lines.append(
            f"  - {d['dealName']} (id={d['id']}, status={d.get('status', '—')}, "
            f"priority={d.get('priority', '—')}, round={d.get('round', '—')}, "
            f"sector={d.get('sector', '—')})"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_deal_pipeline(ctx: Context, deal_id: int) -> str:
    """Get details of a specific deal pipeline entry by ID."""
    client = await get_client(ctx)
    result = await client.get(f"/api/assetmanager/portfolio/deal-pipeline/{deal_id}")
    d = result.get("data")

    if not d:
        return f"Deal {deal_id} not found."

    return (
        f"Deal: {d['dealName']} (id={d['id']})\n"
        f"  Company ID: {d.get('companyId', '—')}\n"
        f"  Priority: {d.get('priority', '—')}\n"
        f"  Status: {d.get('status', '—')}\n"
        f"  Round: {d.get('round', '—')}\n"
        f"  Sector: {d.get('sector', '—')}\n"
        f"  Pre-Money Valuation: {d.get('preMoneyValuation', '—')}\n"
        f"  Post-Money Valuation: {d.get('postMoneyValuation', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_deal_pipeline(
    ctx: Context,
deal_name: str,
    company_id: int,
    priority: DealPriority,
    status: DealStatus,
    round: str,
    sector: SectorType,
    pre_money_valuation: float | None = None,
    post_money_valuation: float | None = None,
) -> str:
    """Create a new deal in the pipeline. Required: deal_name, company_id, priority, status, round, sector."""
    payload: dict = {
        "dealName": deal_name,
        "companyId": company_id,
        "priority": priority,
        "status": status,
        "round": round,
        "sector": sector,
    }
    if pre_money_valuation is not None:
        payload["preMoneyValuation"] = pre_money_valuation
    if post_money_valuation is not None:
        payload["postMoneyValuation"] = post_money_valuation

    client = await get_client(ctx)
    result = await client.post("/api/assetmanager/portfolio/deal-pipeline", payload)
    d = result["data"]
    return f"Deal created: {d['dealName']} (id={d['id']}, status={d.get('status', '—')})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_deal_pipeline(
    ctx: Context,
deal_id: int,
    deal_name: str | None = None,
    company_id: int | None = None,
    priority: DealPriority | None = None,
    status: DealStatus | None = None,
    round: str | None = None,
    sector: SectorType | None = None,
    pre_money_valuation: float | None = None,
    post_money_valuation: float | None = None,
) -> str:
    """Update an existing deal pipeline entry by ID."""
    payload: dict = {}
    if deal_name is not None:
        payload["dealName"] = deal_name
    if company_id is not None:
        payload["companyId"] = company_id
    if priority is not None:
        payload["priority"] = priority
    if status is not None:
        payload["status"] = status
    if round is not None:
        payload["round"] = round
    if sector is not None:
        payload["sector"] = sector
    if pre_money_valuation is not None:
        payload["preMoneyValuation"] = pre_money_valuation
    if post_money_valuation is not None:
        payload["postMoneyValuation"] = post_money_valuation

    client = await get_client(ctx)
    result = await client.put(f"/api/assetmanager/portfolio/deal-pipeline/{deal_id}", payload)
    d = result["data"]
    return f"Deal updated: {d['dealName']} (id={d['id']}, status={d.get('status', '—')})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": True})
async def delete_deal_pipeline(ctx: Context, deal_id: int) -> str:
    """Delete a deal pipeline entry by ID. This action is irreversible."""
    client = await get_client(ctx)
    await client.delete(f"/api/assetmanager/portfolio/deal-pipeline/{deal_id}")
    return f"Deal {deal_id} deleted."


# ==========================================
# Investments
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_investments(ctx: Context) -> str:
    """List all investments."""
    client = await get_client(ctx)
    result = await client.get("/api/assetmanager/portfolio/investments")
    items = result.get("data", [])

    if not items:
        return "No investments found."

    lines = [f"Investments ({len(items)}):"]
    for i in items:
        lines.append(
            f"  - id={i['id']} | company_id={i.get('companyId', '—')} | "
            f"fund_id={i.get('fundId', '—')} | type={i.get('investmentType', '—')} | "
            f"amount={i.get('investmentAmount', '—')} | status={i.get('portfolioStatus', '—')}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_investment(ctx: Context, investment_id: int) -> str:
    """Get details of a specific investment by ID."""
    client = await get_client(ctx)
    result = await client.get(f"/api/assetmanager/portfolio/investments/{investment_id}")
    i = result.get("data")

    if not i:
        return f"Investment {investment_id} not found."

    return (
        f"Investment (id={i['id']})\n"
        f"  Company ID: {i.get('companyId', '—')}\n"
        f"  Fund ID: {i.get('fundId', '—')}\n"
        f"  Round ID: {i.get('roundId', '—')}\n"
        f"  Portfolio Status: {i.get('portfolioStatus', '—')}\n"
        f"  Investment Type: {i.get('investmentType', '—')}\n"
        f"  Sector: {i.get('sector', '—')}\n"
        f"  Investment Amount: {i.get('investmentAmount', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_investment(
    ctx: Context,
company_id: int,
    fund_id: int,
    round_id: int,
    investment_type: InvestmentType,
    sector: SectorType,
    portfolio_status: PortfolioStatus = "Active",
    company_type: CompanyType = "Venture Capital",
    investment_amount: float | None = None,
    ownership_percentage: float | None = None,
    current_fair_value: float | None = None,
    number_of_shares: float | None = None,
    share_price: float | None = None,
    irr: float | None = None,
    notes: str | None = None,
) -> str:
    """Create a new investment. Required: company_id, fund_id, round_id, investment_type, sector."""
    payload: dict = {
        "companyId": company_id,
        "fundId": fund_id,
        "roundId": round_id,
        "investmentType": investment_type,
        "sector": sector,
        "portfolioStatus": portfolio_status,
        "companyType": company_type,
    }
    if investment_amount is not None:
        payload["investmentAmount"] = investment_amount
    if ownership_percentage is not None:
        payload["ownershipPercentage"] = ownership_percentage
    if current_fair_value is not None:
        payload["currentFairValue"] = current_fair_value
    if number_of_shares is not None:
        payload["numberOfShares"] = number_of_shares
    if share_price is not None:
        payload["sharePrice"] = share_price
    if irr is not None:
        payload["irr"] = irr
    if notes is not None:
        payload["notes"] = notes

    client = await get_client(ctx)
    result = await client.post("/api/assetmanager/portfolio/investments", payload)
    i = result["data"]
    return f"Investment created (id={i['id']}, company_id={i.get('companyId')}, fund_id={i.get('fundId')})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_investment(
    ctx: Context,
investment_id: int,
    company_id: int | None = None,
    fund_id: int | None = None,
    round_id: int | None = None,
    portfolio_status: PortfolioStatus | None = None,
    investment_type: InvestmentType | None = None,
    sector: SectorType | None = None,
    company_type: CompanyType | None = None,
    investment_amount: float | None = None,
    ownership_percentage: float | None = None,
    current_fair_value: float | None = None,
    number_of_shares: float | None = None,
    share_price: float | None = None,
    irr: float | None = None,
    notes: str | None = None,
) -> str:
    """Update an existing investment by ID."""
    payload: dict = {}
    if company_id is not None:
        payload["companyId"] = company_id
    if fund_id is not None:
        payload["fundId"] = fund_id
    if round_id is not None:
        payload["roundId"] = round_id
    if portfolio_status is not None:
        payload["portfolioStatus"] = portfolio_status
    if investment_type is not None:
        payload["investmentType"] = investment_type
    if sector is not None:
        payload["sector"] = sector
    if company_type is not None:
        payload["companyType"] = company_type
    if investment_amount is not None:
        payload["investmentAmount"] = investment_amount
    if ownership_percentage is not None:
        payload["ownershipPercentage"] = ownership_percentage
    if current_fair_value is not None:
        payload["currentFairValue"] = current_fair_value
    if number_of_shares is not None:
        payload["numberOfShares"] = number_of_shares
    if share_price is not None:
        payload["sharePrice"] = share_price
    if irr is not None:
        payload["irr"] = irr
    if notes is not None:
        payload["notes"] = notes

    client = await get_client(ctx)
    result = await client.put(f"/api/assetmanager/portfolio/investments/{investment_id}", payload)
    i = result["data"]
    return f"Investment updated (id={i['id']}, company_id={i.get('companyId')}, fund_id={i.get('fundId')})."


# ==========================================
# Cash Flows
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_cash_flows(ctx: Context) -> str:
    """List all cash flows."""
    client = await get_client(ctx)
    result = await client.get("/api/assetmanager/portfolio/cash-flows")
    items = result.get("data", [])

    if not items:
        return "No cash flows found."

    lines = [f"Cash Flows ({len(items)}):"]
    for c in items:
        lines.append(
            f"  - id={c['id']} | company_id={c.get('companyId', '—')} | "
            f"fund_id={c.get('fundId', '—')} | type={c.get('cashFlowType', '—')} | "
            f"date={c.get('date', '—')} | debit={c.get('amountDebit', 0)} | credit={c.get('amountCredit', 0)}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_cash_flow(ctx: Context, cash_flow_id: int) -> str:
    """Get details of a specific cash flow by ID."""
    client = await get_client(ctx)
    result = await client.get(f"/api/assetmanager/portfolio/cash-flows/{cash_flow_id}")
    c = result.get("data")

    if not c:
        return f"Cash flow {cash_flow_id} not found."

    return (
        f"Cash Flow (id={c['id']})\n"
        f"  Company ID: {c.get('companyId', '—')}\n"
        f"  Fund ID: {c.get('fundId', '—')}\n"
        f"  Round ID: {c.get('roundId', '—')}\n"
        f"  Date: {c.get('date', '—')}\n"
        f"  Amount Debit: {c.get('amountDebit', '—')}\n"
        f"  Amount Credit: {c.get('amountCredit', '—')}\n"
        f"  Cash Flow Type: {c.get('cashFlowType', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_cash_flow(
    ctx: Context,
company_id: int,
    fund_id: int,
    round_id: int,
    cash_flow_type: CashFlowType,
    date: str,
    amount_debit: float = 0,
    amount_credit: float = 0,
) -> str:
    """Create a new cash flow entry. Date format: YYYY-MM-DD.
    Provide either amount_debit OR amount_credit (not both)."""
    # Validate: debit and credit cannot both be non-zero
    if amount_debit > 0 and amount_credit > 0:
        return "Error: amount_debit and amount_credit cannot both be non-zero. Use debit for inflows, credit for outflows."
    if amount_debit == 0 and amount_credit == 0:
        return "Error: either amount_debit or amount_credit must be provided."

    payload: dict = {
        "companyId": company_id,
        "fundId": fund_id,
        "roundId": round_id,
        "cashFlowType": cash_flow_type,
        "date": date,
        "amountDebit": amount_debit,
        "amountCredit": amount_credit,
    }

    client = await get_client(ctx)
    result = await client.post("/api/assetmanager/portfolio/cash-flows", payload)
    c = result["data"]
    return f"Cash flow created (id={c['id']}, type={c.get('cashFlowType')}, date={c.get('date')})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_cash_flow(
    ctx: Context,
cash_flow_id: int,
    company_id: int | None = None,
    fund_id: int | None = None,
    round_id: int | None = None,
    cash_flow_type: CashFlowType | None = None,
    date: str | None = None,
    amount_debit: float | None = None,
    amount_credit: float | None = None,
) -> str:
    """Update an existing cash flow entry by ID. Date format: YYYY-MM-DD."""
    payload: dict = {}
    if company_id is not None:
        payload["companyId"] = company_id
    if fund_id is not None:
        payload["fundId"] = fund_id
    if round_id is not None:
        payload["roundId"] = round_id
    if cash_flow_type is not None:
        payload["cashFlowType"] = cash_flow_type
    if date is not None:
        payload["date"] = date
    if amount_debit is not None:
        payload["amountDebit"] = amount_debit
    if amount_credit is not None:
        payload["amountCredit"] = amount_credit

    client = await get_client(ctx)
    result = await client.put(f"/api/assetmanager/portfolio/cash-flows/{cash_flow_id}", payload)
    c = result["data"]
    return f"Cash flow updated (id={c['id']}, type={c.get('cashFlowType')}, date={c.get('date')})."


# ==========================================
# Performance
# ==========================================

@mcp.tool(annotations={"readOnlyHint": True})
async def list_performance(ctx: Context) -> str:
    """List all performance records."""
    client = await get_client(ctx)
    result = await client.get("/api/assetmanager/portfolio/performance")
    items = result.get("data", [])

    if not items:
        return "No performance records found."

    lines = [f"Performance ({len(items)}):"]
    for p in items:
        lines.append(
            f"  - id={p['id']} | fund_id={p.get('fundId', '—')} | "
            f"date={p.get('reportDate', '—')} | NAV={p.get('nav', '—')} | "
            f"IRR={p.get('irr', '—')} | TVPI={p.get('tvpi', '—')} | "
            f"DPI={p.get('dpi', '—')} | RVPI={p.get('rvpi', '—')}"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def get_performance(ctx: Context, performance_id: int) -> str:
    """Get details of a specific performance record by ID."""
    client = await get_client(ctx)
    result = await client.get(f"/api/assetmanager/portfolio/performance/{performance_id}")
    p = result.get("data")

    if not p:
        return f"Performance record {performance_id} not found."

    return (
        f"Performance (id={p['id']})\n"
        f"  Fund ID: {p.get('fundId', '—')}\n"
        f"  Report Date: {p.get('reportDate', '—')}\n"
        f"  NAV: {p.get('nav', '—')}\n"
        f"  IRR: {p.get('irr', '—')}\n"
        f"  TVPI: {p.get('tvpi', '—')}\n"
        f"  DPI: {p.get('dpi', '—')}\n"
        f"  RVPI: {p.get('rvpi', '—')}"
    )


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def create_performance(
    ctx: Context,
fund_id: int,
    report_date: str,
    nav: float | None = None,
    irr: float | None = None,
    tvpi: float | None = None,
    dpi: float | None = None,
    rvpi: float | None = None,
) -> str:
    """Create a new performance record. Date format: YYYY-MM-DD."""
    payload: dict = {"fundId": fund_id, "reportDate": report_date}
    if nav is not None:
        payload["nav"] = nav
    if irr is not None:
        payload["irr"] = irr
    if tvpi is not None:
        payload["tvpi"] = tvpi
    if dpi is not None:
        payload["dpi"] = dpi
    if rvpi is not None:
        payload["rvpi"] = rvpi

    client = await get_client(ctx)
    result = await client.post("/api/assetmanager/portfolio/performance", payload)
    p = result["data"]
    return f"Performance created (id={p['id']}, fund_id={p.get('fundId')}, date={p.get('reportDate')})."


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False})
async def update_performance(
    ctx: Context,
performance_id: int,
    fund_id: int | None = None,
    report_date: str | None = None,
    nav: float | None = None,
    irr: float | None = None,
    tvpi: float | None = None,
    dpi: float | None = None,
    rvpi: float | None = None,
) -> str:
    """Update an existing performance record by ID. Date format: YYYY-MM-DD."""
    payload: dict = {}
    if fund_id is not None:
        payload["fundId"] = fund_id
    if report_date is not None:
        payload["reportDate"] = report_date
    if nav is not None:
        payload["nav"] = nav
    if irr is not None:
        payload["irr"] = irr
    if tvpi is not None:
        payload["tvpi"] = tvpi
    if dpi is not None:
        payload["dpi"] = dpi
    if rvpi is not None:
        payload["rvpi"] = rvpi

    client = await get_client(ctx)
    result = await client.put(f"/api/assetmanager/portfolio/performance/{performance_id}", payload)
    p = result["data"]
    return f"Performance updated (id={p['id']}, fund_id={p.get('fundId')}, date={p.get('reportDate')})."
