"""
V7 Capital MCP Server — Configuration

API base URL read from environment variable.
Defaults to production. Override with V7_API_URL for development.

No Supabase credentials stored here — auth goes through the API
(/api/auth/login endpoint handles Supabase internally).
"""

import os

# V7 Capital API base URL — where the Next.js app is running
API_BASE_URL = os.environ.get("V7_API_URL", "https://www.v7capital.ro")

# MCP container public URL — where Claude Desktop / ChatGPT / Cursor connect.
# Used by FastMCP to advertise authorization endpoints in /.well-known/oauth-protected-resource.
MCP_BASE_URL = os.environ.get("MCP_BASE_URL", "https://mcp.v7capital.ro")

# Credentials file path — where JWT + refresh token are stored locally
CREDENTIALS_PATH = os.path.expanduser("~/.v7capital/credentials.json")

# HTTP client timeout (seconds)
REQUEST_TIMEOUT = 30.0
