"""
V7 Capital MCP Server — Credentials Management

Reads/writes JWT + refresh token to ~/.v7capital/credentials.json.
File permissions set to 600 (owner read/write only).
Password is NEVER stored — only tokens.
"""

import json
import os
from pathlib import Path
from typing import TypedDict

from .config import CREDENTIALS_PATH


class Credentials(TypedDict):
    access_token: str
    refresh_token: str
    user_email: str


def load_credentials() -> Credentials | None:
    """Load credentials from ~/.v7capital/credentials.json. Returns None if not found."""
    path = Path(CREDENTIALS_PATH)
    if not path.exists():
        return None
    try:
        with open(path) as f:
            return json.load(f)
    except (json.JSONDecodeError, KeyError):
        return None


def save_credentials(creds: Credentials) -> None:
    """Save credentials to ~/.v7capital/credentials.json with chmod 600."""
    path = Path(CREDENTIALS_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(creds, f, indent=2)
    # Owner read/write only — no group/other access
    os.chmod(path, 0o600)


def delete_credentials() -> None:
    """Delete credentials file (logout)."""
    path = Path(CREDENTIALS_PATH)
    if path.exists():
        path.unlink()
