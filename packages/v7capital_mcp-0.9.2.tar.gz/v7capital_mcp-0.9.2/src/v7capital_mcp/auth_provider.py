"""
V7 Capital MCP Server — OAuth Provider

Bridges FastMCP's OAuth flow with V7 Capital's OAuth authorization server.
Makes HTTP requests to www.v7capital.ro/api/mcp-oauth/* endpoints.

Runs as standalone process (HTTP transport) — no mount/sub-path issues.
FastMCP handles well-known, register, authorize, token routing at root automatically.

Complete OAuth 2.0 + PKCE flow:
1. Claude calls POST /register → we proxy to v7capital /api/mcp-oauth/register
2. Claude calls GET /authorize → we return URL to v7capital /api/mcp-oauth/authorize
3. Server redirects to www.v7capital.ro/accounts/mcp-authorize (consent page)
4. User clicks Allow → frontend POSTs to /api/mcp-oauth/approve → generates auth code
5. Browser redirects to http://localhost:PORT/callback?code=AUTH_CODE → Claude receives code
6. Claude calls POST /token → FastMCP validates PKCE internally, then calls exchange_authorization_code()
7. We proxy to v7capital /api/mcp-oauth/token → server generates JWT → returned
8. Claude: Connected ✓

Mirrors finpy/mcp/src/finpy_mcp/auth_provider.py — no local JWT secret in container,
verify_token() calls server /api/auth/me to validate tokens.
"""

import time
import logging
from dataclasses import dataclass
from urllib.parse import quote

import httpx
from mcp.server.auth.provider import AuthorizationParams
from mcp.shared.auth import OAuthClientInformationFull, OAuthToken
from fastmcp.server.auth import OAuthProvider, AccessToken
from mcp.server.auth.settings import ClientRegistrationOptions

from .config import API_BASE_URL, REQUEST_TIMEOUT

logger = logging.getLogger(__name__)


@dataclass
class StoredAuthorizationCode:
    """Authorization code object returned by load_authorization_code().
    Attributes required by FastMCP token handler (mcp/server/auth/handlers/token.py)."""
    code: str
    client_id: str
    redirect_uri: str
    redirect_uri_provided_explicitly: bool
    code_challenge: str
    expires_at: float = 0.0


class V7CapitalOAuthProvider(OAuthProvider):
    """OAuth provider that proxies to V7 Capital server's OAuth endpoints via HTTP.

    In-memory state (lost on container restart — users re-authenticate):
    - _clients: registered clients (FastMCP UUID → OAuthClientInformationFull)
    - _access_tokens: JWT cache for verify_token() (avoids re-decoding on every tool call)
    """

    def __init__(self, base_url: str) -> None:
        super().__init__(
            base_url=base_url,
            client_registration_options=ClientRegistrationOptions(enabled=True),
        )
        self._access_tokens: dict[str, AccessToken] = {}
        self._clients: dict[str, OAuthClientInformationFull] = {}

    # ==========================================
    # Client Registration (RFC 7591)
    # ==========================================

    async def register_client(self, client_info: OAuthClientInformationFull) -> None:
        """Proxy registration to v7capital DB and cache locally for get_client()."""
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
            r = await http.post(
                f"{API_BASE_URL}/api/mcp-oauth/register",
                json={
                    "client_id": client_info.client_id,
                    "client_name": client_info.client_name,
                    "redirect_uris": [str(u) for u in client_info.redirect_uris] if client_info.redirect_uris else None,
                    "grant_types": client_info.grant_types,
                    "token_endpoint_auth_method": client_info.token_endpoint_auth_method,
                },
            )
            if r.status_code in (200, 201):
                logger.info(f"Client registered on server: {client_info.client_id}")
        if client_info.client_id:
            self._clients[client_info.client_id] = client_info

    async def get_client(self, client_id: str) -> OAuthClientInformationFull | None:
        return self._clients.get(client_id)

    # ==========================================
    # Authorization
    # ==========================================

    async def authorize(
        self, client: OAuthClientInformationFull, params: AuthorizationParams
    ) -> str:
        """Return URL to v7capital's authorize endpoint → redirects to consent page."""
        authorize_url = (
            f"{API_BASE_URL}/api/mcp-oauth/authorize"
            f"?client_id={quote(str(client.client_id or ''))}"
            f"&redirect_uri={quote(str(params.redirect_uri))}"
            f"&code_challenge={quote(str(params.code_challenge))}"
            f"&code_challenge_method=S256"
            f"&response_type=code"
        )
        if params.state:
            authorize_url += f"&state={quote(str(params.state))}"
        if params.scopes:
            authorize_url += f"&scope={'+'.join(params.scopes)}"
        return authorize_url

    # ==========================================
    # Token Exchange
    # ==========================================

    async def load_authorization_code(
        self, client: OAuthClientInformationFull, authorization_code: str
    ) -> StoredAuthorizationCode | None:
        """Fetch auth code details from v7capital DB (FastMCP needs code_challenge for PKCE)."""
        try:
            async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
                r = await http.get(
                    f"{API_BASE_URL}/api/mcp-oauth/code/{authorization_code}",
                )
                if r.status_code != 200:
                    logger.warning(f"Auth code not found on server: {authorization_code[:10]}...")
                    return None
                data = r.json()
                return StoredAuthorizationCode(
                    code=data["code"],
                    client_id=data["client_id"],
                    redirect_uri=data["redirect_uri"],
                    redirect_uri_provided_explicitly=True,
                    code_challenge=data["code_challenge"],
                    expires_at=time.time() + 300,
                )
        except Exception as e:
            logger.warning(f"Failed to load auth code from server: {e}")
            return None

    async def exchange_authorization_code(
        self, client: OAuthClientInformationFull, authorization_code: StoredAuthorizationCode
    ) -> OAuthToken:
        """Proxy token exchange to v7capital. Called AFTER FastMCP validates PKCE internally."""
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
            r = await http.post(
                f"{API_BASE_URL}/api/mcp-oauth/token",
                json={
                    "grant_type": "authorization_code",
                    "code": authorization_code.code,
                    "client_id": client.client_id,
                    "redirect_uri": authorization_code.redirect_uri,
                },
                headers={"Content-Type": "application/json"},
            )

            if r.status_code != 200:
                data = r.json()
                raise ValueError(data.get("error_description", "Token exchange failed"))

            data = r.json()
            access_token = data["access_token"]
            refresh_token = data.get("refresh_token")

            self._access_tokens[access_token] = AccessToken(
                token=access_token,
                client_id=client.client_id or "",
                scopes=["all"],
                expires_at=int(time.time()) + data.get("expires_in", 1800),
            )

            return OAuthToken(
                access_token=access_token,
                token_type="Bearer",
                expires_in=data.get("expires_in", 1800),
                refresh_token=refresh_token,
            )

    async def exchange_refresh_token(
        self, client: OAuthClientInformationFull, refresh_token: str, scopes: list[str]
    ) -> OAuthToken:
        """Proxy refresh token exchange to v7capital."""
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
            r = await http.post(
                f"{API_BASE_URL}/api/mcp-oauth/token",
                json={
                    "grant_type": "refresh_token",
                    "refresh_token": str(refresh_token),
                    "client_id": client.client_id,
                },
                headers={"Content-Type": "application/json"},
            )

            if r.status_code != 200:
                raise ValueError("Refresh token expired or invalid")

            data = r.json()
            new_access = data["access_token"]

            self._access_tokens[new_access] = AccessToken(
                token=new_access,
                client_id=client.client_id or "",
                scopes=["all"],
                expires_at=int(time.time()) + data.get("expires_in", 1800),
            )

            return OAuthToken(
                access_token=new_access,
                token_type="Bearer",
                expires_in=data.get("expires_in", 1800),
                refresh_token=data.get("refresh_token"),
            )

    # ==========================================
    # Token Validation (called on every tool call)
    # ==========================================

    async def load_access_token(self, token: str) -> AccessToken | None:
        """Load JWT from in-memory cache. Fast path — avoids decode on every call."""
        return self._access_tokens.get(token)

    async def verify_token(self, token: str) -> AccessToken | None:
        """Verify token by calling v7capital /api/auth/me.
        Fallback when token not in cache (e.g., after MCP container restart). No local secret."""
        try:
            async with httpx.AsyncClient(timeout=10.0) as http:
                r = await http.get(
                    f"{API_BASE_URL}/api/auth/me",
                    headers={"Authorization": f"Bearer {token}"},
                )
                if r.status_code == 200:
                    if token not in self._access_tokens:
                        self._access_tokens[token] = AccessToken(
                            token=token,
                            client_id="",
                            scopes=["all"],
                            expires_at=int(time.time()) + 1800,
                        )
                    return self._access_tokens[token]
        except httpx.HTTPError as e:
            logger.warning(f"Token verification failed: {e}")
        return None

    async def load_refresh_token(
        self, client: OAuthClientInformationFull, refresh_token: str
    ) -> str | None:
        """Accept any refresh token — server validates on exchange."""
        return refresh_token

    # ==========================================
    # Revocation
    # ==========================================

    async def revoke_token(self, token) -> None:
        """Remove from in-memory cache. Server token remains valid until expiry."""
        self._access_tokens.pop(str(token), None)
