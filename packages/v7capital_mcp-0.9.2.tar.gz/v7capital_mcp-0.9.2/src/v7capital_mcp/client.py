"""
V7 Capital MCP Server — HTTP Client

Async httpx wrapper that handles:
- JWT authentication (from ~/.v7capital/credentials.json OR OAuth token)
- Automatic token refresh on 401 (stdio mode only)
- No org/entity context needed (single-org platform)

Two modes:
- Local (stdio): token read from ~/.v7capital/credentials.json (token=None)
- Remote (HTTP): token passed from OAuth flow via get_client(ctx)
"""

import httpx
from fastmcp import Context
from fastmcp.server.dependencies import get_access_token

from .config import API_BASE_URL, REQUEST_TIMEOUT
from .credentials import load_credentials, save_credentials


class V7Client:
    """HTTP client for V7 Capital API with JWT auth and auto-refresh.

    Two modes:
    - Local (stdio): token read from ~/.v7capital/credentials.json (token=None)
    - Remote (HTTP): token passed from OAuth flow (token="eyJ...")
    """

    def __init__(self, token: str | None = None) -> None:
        self.base_url = API_BASE_URL
        self._token = token  # Remote mode: JWT from OAuth header

    def _get_credentials(self) -> dict:
        """Load credentials or raise descriptive error (stdio mode only)."""
        creds = load_credentials()
        if not creds or not creds.get("access_token"):
            raise RuntimeError(
                "Not authenticated. Please run 'v7capital-cli login' in your terminal first."
            )
        return creds

    @property
    def _headers(self) -> dict:
        """Auth headers — from OAuth token (remote) or stored credentials (local)."""
        if self._token:
            return {"Authorization": f"Bearer {self._token}"}
        creds = self._get_credentials()
        return {"Authorization": f"Bearer {creds['access_token']}"}

    async def _refresh_token(self) -> bool:
        """Attempt to refresh JWT via /api/auth/refresh. Returns True if successful.
        Remote mode: no local refresh — OAuth provider handles refresh via FastMCP."""
        if self._token:
            return False

        creds = load_credentials()
        if not creds or not creds.get("refresh_token"):
            return False

        try:
            async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
                r = await http.post(
                    f"{self.base_url}/api/auth/refresh",
                    json={"refresh_token": creds["refresh_token"]},
                )
                if r.status_code == 200:
                    data = r.json()
                    creds["access_token"] = data["access_token"]
                    creds["refresh_token"] = data["refresh_token"]
                    save_credentials(creds)
                    return True
        except httpx.HTTPError:
            pass
        return False

    async def _request(self, method: str, path: str, **kwargs) -> dict:
        """Make HTTP request with auto-refresh on 401 (stdio mode only)."""
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
            r = await http.request(
                method,
                f"{self.base_url}{path}",
                headers=self._headers,
                **kwargs,
            )

            # Auto-refresh on 401 (stdio mode only — remote mode handled by FastMCP OAuth)
            if r.status_code == 401 and not self._token:
                refreshed = await self._refresh_token()
                if refreshed:
                    r = await http.request(
                        method,
                        f"{self.base_url}{path}",
                        headers=self._headers,
                        **kwargs,
                    )
                else:
                    raise RuntimeError(
                        "Session expired. Please run 'v7capital-cli login' again."
                    )

            r.raise_for_status()
            return r.json()

    async def get(self, path: str, **kwargs) -> dict:
        """GET request to V7 Capital API."""
        return await self._request("GET", path, **kwargs)

    async def post(self, path: str, data: dict) -> dict:
        """POST request to V7 Capital API."""
        return await self._request("POST", path, json=data)

    async def put(self, path: str, data: dict) -> dict:
        """PUT request to V7 Capital API."""
        return await self._request("PUT", path, json=data)

    async def delete(self, path: str) -> dict:
        """DELETE request to V7 Capital API."""
        return await self._request("DELETE", path)


# Singleton instance — used in stdio mode (no OAuth token in context)
v7 = V7Client()


async def get_client(ctx: Context) -> V7Client:
    """Get a V7Client for the current request.
    Local mode (stdio, no auth token in context): returns singleton with credentials.json.
    Remote mode (HTTP, OAuth token present): creates per-request client with user's JWT."""
    _ = ctx  # ctx kept for signature parity / future use (logging, progress, state)
    token_obj = get_access_token()
    if not token_obj:
        return v7  # stdio mode
    return V7Client(token=token_obj.token)  # OAuth mode — per-request client
