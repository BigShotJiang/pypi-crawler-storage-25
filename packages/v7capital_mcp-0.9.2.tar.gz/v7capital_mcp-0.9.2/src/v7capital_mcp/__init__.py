"""V7 Capital MCP Server — AI-powered asset management through conversation."""
