# Mayaku model configs
