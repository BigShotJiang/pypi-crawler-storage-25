"""Contract tests: assert the exact JSON shape sent to each Telegram API endpoint.

These tests let the bot methods run normally and intercept at http_post_json to verify
that required fields are present, correctly typed, and correctly valued.
"""

from __future__ import annotations

import pytest

from agentforge.approval_gates import ApprovalGates
from agentforge.rate_limiter import RateLimiter
from agentforge.telegram_adapter import ClawdiaBot


# ---------------------------------------------------------------------------
# Helpers (mirrors _make_bot from test_telegram_adapter.py)
# ---------------------------------------------------------------------------


class _MockStore:
    def get_dynamic_messages(self, *a, **kw):
        return []

    def get_thread_context(self, parent_message_id, exclude_message_ids=None):
        return [], set()

    def save_message(self, *a, **kw):
        class _M:
            id = 1
        return _M()

    def find_telegram_message(self, *, chat_id, telegram_message_id, channel_id=None):
        return None


def _make_bot(tmp_path=None) -> ClawdiaBot:
    bot = object.__new__(ClawdiaBot)
    bot.config = {
        "bot_name": "clawdia",
        "claude": {"model": "sonnet"},
        "telegram": {"max_message_length": 4096, "allowed_chat_ids": []},
        "threads": {"default": {"backend": "claude", "model": "sonnet"}},
    }
    bot.bot_name = "clawdia"
    bot.api_base = "https://example.test"
    bot.token = "test-token"
    bot.agent_api_bases = {}
    bot.thread_api_bases = {}
    bot.store = _MockStore()
    bot.rate_limiter = RateLimiter(max_per_minute=10, max_per_hour=60, max_concurrent_sessions=2)
    bot.approval_gates = ApprovalGates(root=str(tmp_path) if tmp_path else "/tmp", timeout_seconds=1)
    bot._save_usage = lambda *a, **kw: None
    bot._save_message = lambda *a, **kw: type("M", (), {"id": 1})()
    bot._log_action = lambda *a, **kw: None
    bot._save_pending_retry = lambda *a, **kw: None
    for method in (
        "_get_api_base",
        "_send_message",
        "_send_typing",
        "_start_typing_loop",
        "_set_reaction",
        "_handle_callback_query",
        "_register_commands",
        "_discover_filesystem_commands",
        "_is_active",
        "_get_state_path",
        "_get_active_state_path",
        "_builtin_status",
        "_dispatch_builtin",
        "_get_current_service_unit",
        "_append_claude_usage_summary",
        "_append_real_claude_usage",
        "_format_usage_reset_label",
        "_discover_restartable_agents",
        "_build_restart_picker",
        "_restart_agent_service",
    ):
        if hasattr(ClawdiaBot, method):
            setattr(bot, method, getattr(ClawdiaBot, method).__get__(bot, ClawdiaBot))
    return bot


def _capturing_post(calls: list) -> object:
    """Return an http_post_json replacement that records (url, payload) pairs."""
    def _post(url, data, **kw):
        calls.append((url, data))
        return {"ok": True}
    return _post


# ---------------------------------------------------------------------------
# sendMessage contracts
# ---------------------------------------------------------------------------


class TestSendMessageContract:
    """sendMessage payload must have correct field names and types."""

    def test_required_fields_present(self, monkeypatch):
        calls: list = []
        monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", _capturing_post(calls))
        bot = _make_bot()
        bot._send_message("123", "hello", None)

        assert calls, "http_post_json must be called"
        url, payload = calls[0]
        assert url.endswith("/sendMessage"), f"URL must end with /sendMessage, got: {url}"
        assert "chat_id" in payload, "chat_id is required"
        assert "text" in payload, "text is required"

    def test_chat_id_is_string(self, monkeypatch):
        calls: list = []
        monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", _capturing_post(calls))
        bot = _make_bot()
        bot._send_message("123", "hello", None)
        _, payload = calls[0]
        assert isinstance(payload["chat_id"], str), "chat_id must be a string"

    def test_no_thread_id_absent_when_none(self, monkeypatch):
        calls: list = []
        monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", _capturing_post(calls))
        bot = _make_bot()
        bot._send_message("123", "hello", None)
        _, payload = calls[0]
        assert "message_thread_id" not in payload, "message_thread_id must be absent when thread_id=None"

    def test_thread_id_is_integer_when_present(self, monkeypatch):
        calls: list = []
        monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", _capturing_post(calls))
        bot = _make_bot()
        bot._send_message("123", "hello", 11)
        _, payload = calls[0]
        assert payload["message_thread_id"] == 11
        assert isinstance(payload["message_thread_id"], int), "message_thread_id must be an integer"

    def test_reply_markup_preserved(self, monkeypatch):
        calls: list = []
        monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", _capturing_post(calls))
        bot = _make_bot()
        markup = {"inline_keyboard": [[{"text": "A", "callback_data": "a"}]]}
        bot._send_message("123", "pick one", None, reply_markup=markup)
        _, payload = calls[0]
        assert "reply_markup" in payload, "reply_markup must be forwarded"
        assert "inline_keyboard" in payload["reply_markup"], "inline_keyboard must be present"

    def test_long_message_is_chunked(self, monkeypatch):
        """Messages longer than max_message_length are sent as multiple calls."""
        calls: list = []
        monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", _capturing_post(calls))
        bot = _make_bot()
        bot.config["telegram"]["max_message_length"] = 10
        bot._send_message("123", "A" * 25, None)
        assert len(calls) == 3, f"25 chars with limit 10 → 3 chunks, got {len(calls)}"
        for _, payload in calls:
            assert len(payload["text"]) <= 10


# ---------------------------------------------------------------------------
# sendChatAction contract
# ---------------------------------------------------------------------------


class TestSendChatActionContract:
    """sendChatAction must send action=typing."""

    def test_action_is_typing(self, monkeypatch):
        calls: list = []
        monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", _capturing_post(calls))
        bot = _make_bot()
        bot._send_typing("123", None)
        assert calls
        url, payload = calls[0]
        assert url.endswith("/sendChatAction"), f"URL must end /sendChatAction, got: {url}"
        assert payload["action"] == "typing"

    def test_thread_id_included_when_present(self, monkeypatch):
        calls: list = []
        monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", _capturing_post(calls))
        bot = _make_bot()
        bot._send_typing("123", 7)
        _, payload = calls[0]
        assert payload.get("message_thread_id") == 7

    def test_thread_id_absent_when_none(self, monkeypatch):
        calls: list = []
        monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", _capturing_post(calls))
        bot = _make_bot()
        bot._send_typing("123", None)
        _, payload = calls[0]
        assert "message_thread_id" not in payload


# ---------------------------------------------------------------------------
# answerCallbackQuery contract
# ---------------------------------------------------------------------------


class TestAnswerCallbackQueryContract:
    """answerCallbackQuery must include callback_query_id."""

    def test_callback_query_id_present(self, monkeypatch, tmp_path):
        calls: list = []
        monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", _capturing_post(calls))
        bot = _make_bot(tmp_path)
        bot.config["telegram"]["allowed_chat_ids"] = ["999"]
        bot._handle_callback_query({
            "id": "cb-42",
            "data": "unrelated",
            "from": {"id": 1},
            "message": {
                "chat": {"id": "999"},
                "message_thread_id": None,
            },
        })
        cb_calls = [(u, p) for u, p in calls if "answerCallbackQuery" in u]
        assert cb_calls, "answerCallbackQuery must be called"
        _, payload = cb_calls[0]
        assert payload["callback_query_id"] == "cb-42"


# ---------------------------------------------------------------------------
# setMessageReaction contract
# ---------------------------------------------------------------------------


class TestSetMessageReactionContract:
    """setMessageReaction payload must have correct shape."""

    def test_reaction_shape(self, monkeypatch):
        calls: list = []
        monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", _capturing_post(calls))
        bot = _make_bot()
        bot._set_reaction("123", "55", "✅", None, None)
        assert calls
        url, payload = calls[0]
        assert url.endswith("/setMessageReaction"), f"URL must end /setMessageReaction, got: {url}"
        assert payload["chat_id"] == "123"
        assert payload["message_id"] == 55, "message_id must be coerced to int"
        assert isinstance(payload["message_id"], int)
        assert isinstance(payload["reaction"], list), "reaction must be a list"
        assert payload["reaction"][0] == {"type": "emoji", "emoji": "✅"}


# ---------------------------------------------------------------------------
# setMyCommands contract
# ---------------------------------------------------------------------------


class TestSetMyCommandsContract:
    """setMyCommands must register commands in multiple scopes with correct shape."""

    def test_commands_shape(self, monkeypatch):
        calls: list = []
        monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", _capturing_post(calls))
        bot = _make_bot()
        bot.config["telegram"]["allowed_chat_ids"] = ["-100555"]
        bot.config.setdefault("commands", {})
        bot._register_commands()

        cmd_calls = [(u, p) for u, p in calls if "setMyCommands" in u]
        assert cmd_calls, "setMyCommands must be called at least once"
        for _url, payload in cmd_calls:
            assert "commands" in payload
            for cmd_entry in payload["commands"]:
                assert "command" in cmd_entry, "Each command must have 'command' key"
                assert "description" in cmd_entry, "Each command must have 'description' key"
                assert isinstance(cmd_entry["command"], str)
                assert not cmd_entry["command"].startswith("/"), "command must not include leading slash"

    def test_registers_default_and_group_and_per_chat_scopes(self, monkeypatch):
        calls: list = []
        monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", _capturing_post(calls))
        bot = _make_bot()
        bot.config["telegram"]["allowed_chat_ids"] = ["-100555"]
        bot.config.setdefault("commands", {})
        bot._register_commands()

        cmd_calls = [(u, p) for u, p in calls if "setMyCommands" in u]
        scope_types = [p.get("scope", {}).get("type", "default") for _, p in cmd_calls]
        assert "default" in scope_types
        assert "all_group_chats" in scope_types
        assert "chat" in scope_types
