"""Tests for agentforge.cli.service — heartbeat timer generation and migration."""

from __future__ import annotations

import os
import subprocess
import sys
import types
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest

from agentforge.cli.init import sync_scripts
from agentforge.cli.service import (
    _write_heartbeat_units,
    service_generate,
    service_migrate_heartbeat,
)
from agentforge.paths import resolve_runtime_scripts_dir


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_heartbeat_script(root: Path) -> Path:
    """Create a minimal heartbeat.sh in the expected runtime/scripts/ location."""
    scripts_dir = resolve_runtime_scripts_dir(root)
    scripts_dir.mkdir(parents=True, exist_ok=True)
    script = scripts_dir / "heartbeat.sh"
    script.write_text("#!/bin/bash\n", encoding="utf-8")
    script.chmod(0o755)
    return script


# ---------------------------------------------------------------------------
# 1. service_generate — heartbeat ExecStart points at runtime/scripts/
# ---------------------------------------------------------------------------

def test_service_generate_heartbeat_uses_runtime_scripts_path(tmp_path, monkeypatch):
    """Generated heartbeat service must use runtime/scripts/heartbeat.sh as ExecStart."""
    monkeypatch.setenv("AGENTFORGE_ROOT", str(tmp_path))
    _make_heartbeat_script(tmp_path)

    service_dir = tmp_path / ".config" / "systemd" / "user"
    service_generate(heartbeat=True, monitoring=False, _home=tmp_path)

    hb_service = service_dir / "agentforge-heartbeat.service"
    assert hb_service.exists(), "heartbeat service file was not created"

    content = hb_service.read_text(encoding="utf-8")
    expected_path = str(resolve_runtime_scripts_dir(tmp_path) / "heartbeat.sh")
    assert expected_path in content, (
        f"ExecStart should reference {expected_path!r}, got:\n{content}"
    )


# ---------------------------------------------------------------------------
# 2. service_generate — aborts when script is still missing after sync attempt
# ---------------------------------------------------------------------------

def test_service_generate_heartbeat_aborts_if_sync_cannot_provide_script(tmp_path, monkeypatch, capsys):
    """service_generate must exit(1) with a clear message if heartbeat.sh cannot be produced."""
    monkeypatch.setenv("AGENTFORGE_ROOT", str(tmp_path))
    # sync_scripts is mocked to do nothing — script stays absent
    with patch("agentforge.cli.init.sync_scripts"):
        with pytest.raises(SystemExit) as exc_info:
            service_generate(heartbeat=True, monitoring=False, _home=tmp_path)

    assert exc_info.value.code == 1
    out = capsys.readouterr().out
    assert "heartbeat.sh" in out
    # Should point the user toward the migration command
    assert "migrate-heartbeat" in out or "agentforge update apply" in out


# ---------------------------------------------------------------------------
# 2b. service_generate — aborts when monitoring_heartbeat.sh cannot be produced
# ---------------------------------------------------------------------------

def test_service_generate_monitoring_aborts_if_sync_cannot_provide_script(tmp_path, monkeypatch, capsys):
    """service_generate must exit(1) if monitoring_heartbeat.sh cannot be produced."""
    monkeypatch.setenv("AGENTFORGE_ROOT", str(tmp_path))
    _make_heartbeat_script(tmp_path)  # heartbeat.sh present; monitoring script absent
    with patch("agentforge.cli.init.sync_scripts"):
        with pytest.raises(SystemExit) as exc_info:
            service_generate(heartbeat=True, monitoring=True, _home=tmp_path)

    assert exc_info.value.code == 1
    out = capsys.readouterr().out
    assert "monitoring_heartbeat.sh" in out


# ---------------------------------------------------------------------------
# 3. sync_scripts — copies heartbeat.sh from templates and marks it executable
# ---------------------------------------------------------------------------

def test_sync_scripts_copies_heartbeat_sh_and_marks_executable(tmp_path):
    """sync_scripts must deploy an executable heartbeat.sh to runtime/scripts/."""
    sync_scripts(tmp_path)

    scripts_dir = resolve_runtime_scripts_dir(tmp_path)
    heartbeat = scripts_dir / "heartbeat.sh"

    assert heartbeat.exists(), "heartbeat.sh was not copied by sync_scripts"
    assert os.access(heartbeat, os.X_OK), "heartbeat.sh should be executable after sync_scripts"


# ---------------------------------------------------------------------------
# 4. heartbeat.sh — heartbeat cron does not require task.md
# ---------------------------------------------------------------------------

def test_packaged_heartbeat_allows_taskless_heartbeat_cron():
    """The special heartbeat cron must query 2Do even when task.md is absent.

    Structural check on the per-agent cron dispatch block: the task.md guard
    must appear only in the non-heartbeat (else) branch, not in the heartbeat
    branch where agents may have no task.md.

    There are two 'cron_name = heartbeat' blocks in the script (one inside
    run_cron_task, one in the main loop).  We anchor on the per-agent cron
    comment which immediately precedes the relevant if/else/fi.
    """
    repo_root = Path(__file__).resolve().parents[1]
    lines = (repo_root / "src/agentforge/templates/scripts/heartbeat.sh").read_text(encoding="utf-8").splitlines()

    # Anchor: the comment that marks the per-agent cron dispatch block
    anchor = next(
        (i for i, ln in enumerate(lines) if "Heartbeat uses interval_minutes" in ln),
        None,
    )
    assert anchor is not None, "Missing per-agent cron dispatch comment in heartbeat.sh"

    heartbeat_if_line = next(
        (i for i, ln in enumerate(lines) if i > anchor and '"$cron_name" = "heartbeat"' in ln),
        None,
    )
    assert heartbeat_if_line is not None, 'Missing: if [ "$cron_name" = "heartbeat" ] in per-agent dispatch'

    # Use the indentation of the if line to find the matching else/fi at the same depth.
    if_indent = len(lines[heartbeat_if_line]) - len(lines[heartbeat_if_line].lstrip())

    def _at_same_indent(ln: str, keyword: str) -> bool:
        stripped = ln.lstrip()
        return stripped.startswith(keyword) and (len(ln) - len(stripped)) == if_indent

    else_line = next(
        (i for i, ln in enumerate(lines) if i > heartbeat_if_line and _at_same_indent(ln, "else")),
        None,
    )
    assert else_line is not None, "Missing else branch for the per-agent heartbeat if block"

    fi_line = next(
        (i for i, ln in enumerate(lines) if i > else_line and _at_same_indent(ln, "fi")),
        None,
    )
    assert fi_line is not None, "Missing fi for the per-agent heartbeat if block"

    # task.md guard must NOT appear in the heartbeat branch (if…else)
    task_md_in_heartbeat_branch = any(
        '[ -f "$task_md" ] || continue' in lines[i]
        for i in range(heartbeat_if_line, else_line)
    )
    assert not task_md_in_heartbeat_branch, (
        "task.md guard must not be in the heartbeat branch — "
        "heartbeat cron must run without task.md"
    )

    # task.md guard MUST appear in the non-heartbeat branch (else…fi)
    task_md_in_else_branch = any(
        '[ -f "$task_md" ] || continue' in lines[i]
        for i in range(else_line, fi_line)
    )
    assert task_md_in_else_branch, "task.md guard missing from the non-heartbeat else branch"


# ---------------------------------------------------------------------------
# 5. service_migrate_heartbeat — happy path (mocked systemctl)
# ---------------------------------------------------------------------------

def test_service_migrate_heartbeat_syncs_enables_and_prints_instructions(tmp_path, monkeypatch, capsys):
    """migrate-heartbeat must sync scripts, write only heartbeat units, enable timer, print instructions."""
    monkeypatch.setenv("AGENTFORGE_ROOT", str(tmp_path))

    sync_calls: list[str] = []

    def fake_sync(root, **kwargs):
        sync_calls.append(str(root))
        _make_heartbeat_script(root)

    def fake_subprocess_run(cmd, **kwargs):
        # is-active returns "active"; other calls succeed
        if "is-active" in cmd:
            return subprocess.CompletedProcess(cmd, 0, stdout="active\n", stderr="")
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    with patch("agentforge.cli.init.sync_scripts", fake_sync):
        with patch("subprocess.run", fake_subprocess_run):
            service_migrate_heartbeat(_home=tmp_path)

    # sync_scripts was called
    assert sync_calls, "sync_scripts was not called during migration"

    service_dir = tmp_path / ".config" / "systemd" / "user"

    # Only heartbeat units written — agentforge.service must NOT be present
    assert not (service_dir / "agentforge.service").exists(), (
        "migrate-heartbeat must not write agentforge.service"
    )
    assert (service_dir / "agentforge-heartbeat.service").exists()
    assert (service_dir / "agentforge-heartbeat.timer").exists()

    out = capsys.readouterr().out
    assert "✓ Timer is active" in out
    # Crontab removal instructions are printed
    assert "crontab" in out.lower()


# ---------------------------------------------------------------------------
# 6. service_migrate_heartbeat — aborts without printing instructions if timer inactive
# ---------------------------------------------------------------------------

def test_service_migrate_heartbeat_aborts_if_timer_not_active(tmp_path, monkeypatch, capsys):
    """migrate-heartbeat must exit(1) and NOT print crontab removal instructions when timer is inactive."""
    monkeypatch.setenv("AGENTFORGE_ROOT", str(tmp_path))

    def fake_sync(root, **kwargs):
        _make_heartbeat_script(root)

    def fake_subprocess_run(cmd, **kwargs):
        if "is-active" in cmd:
            return subprocess.CompletedProcess(cmd, 1, stdout="inactive\n", stderr="")
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    with patch("agentforge.cli.init.sync_scripts", fake_sync):
        with patch("subprocess.run", fake_subprocess_run):
            with pytest.raises(SystemExit) as exc_info:
                service_migrate_heartbeat(_home=tmp_path)

    assert exc_info.value.code == 1
    out = capsys.readouterr().out
    # Must NOT print crontab removal instructions when timer is not confirmed running
    assert "crontab" not in out.lower(), (
        "Should not print crontab removal instructions when timer is not active"
    )


# ---------------------------------------------------------------------------
# 7. CLI dispatch — migrate-heartbeat routes to service_migrate_heartbeat
# ---------------------------------------------------------------------------

def test_cli_dispatch_migrate_heartbeat_routes_correctly(monkeypatch):
    """_run_service with service_command='migrate-heartbeat' must call service_migrate_heartbeat."""
    from agentforge.cli import _run_service

    called_with: dict = {}

    def fake_migrate(*, name, interval_minutes, **kwargs):
        called_with["name"] = name
        called_with["interval_minutes"] = interval_minutes

    monkeypatch.setattr("agentforge.cli.service.service_migrate_heartbeat", fake_migrate)

    args = types.SimpleNamespace(
        service_command="migrate-heartbeat",
        name="agentforge",
        heartbeat_interval=5,
    )
    _run_service(args)

    assert called_with == {"name": "agentforge", "interval_minutes": 5}


def test_cli_dispatch_service_fallback_without_parser_exits_cleanly(capsys):
    """Direct _run_service calls without argparse parser metadata should still print usage."""
    from agentforge.cli import _run_service

    args = types.SimpleNamespace(service_command=None)

    with pytest.raises(SystemExit) as exc_info:
        _run_service(args)

    assert exc_info.value.code == 1
    assert "agentforge service" in capsys.readouterr().out
