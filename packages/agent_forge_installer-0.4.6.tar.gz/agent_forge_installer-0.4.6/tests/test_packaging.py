"""Packaging regressions for runtime assets and release metadata."""

from __future__ import annotations

import email
import re
import subprocess
import sys
import zipfile
from pathlib import Path


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def test_wheel_contains_runtime_command_templates_and_metadata_version(tmp_path):
    """The published wheel must carry command templates and the pyproject version."""
    repo = _repo_root()
    wheelhouse = tmp_path / "wheelhouse"
    wheelhouse.mkdir()
    pyproject = (repo / "pyproject.toml").read_text(encoding="utf-8")
    version_match = re.search(r'^version = "([^"]+)"$', pyproject, re.MULTILINE)
    assert version_match is not None
    expected_version = version_match.group(1)

    subprocess.run(
        [
            sys.executable,
            "-m",
            "pip",
            "wheel",
            "--no-deps",
            "--wheel-dir",
            str(wheelhouse),
            str(repo),
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    wheels = list(wheelhouse.glob("agent_forge_installer-*.whl"))
    assert len(wheels) == 1

    with zipfile.ZipFile(wheels[0]) as wheel:
        names = set(wheel.namelist())
        metadata_name = next(name for name in names if name.endswith(".dist-info/METADATA"))
        metadata = email.message_from_bytes(wheel.read(metadata_name))

    assert metadata["Version"] == expected_version
    assert "agentforge/templates/commands/2do/task.sh" in names
    assert "agentforge/templates/commands/2do/config.json" in names
