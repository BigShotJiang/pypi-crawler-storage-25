"""Tests for ConversationStore — §3.4 context window rules and §5 storage rules.

Product rules covered:
  §3.4  Reply thread: full thread (parent + replies) loaded, no count limit.
  §3.4  Root topic: last 4 hours, backfill to 3 when sparse, hard cap 100.
  §3.4  Current in-flight message excluded from context via exclude_message_ids.
  §5    Messages stored in SQLite with agent_name column.
  §5    Each agent reads only its own history (filtered by agent_name).
  §5    FTS5 full-text search enabled on the store.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import pytest

from agentforge.conversation_store import ConversationStore

MONTREAL = ZoneInfo("America/Montreal")

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_store(tmp_path: Path, *, base_now: datetime | None = None) -> ConversationStore:
    """Build a ConversationStore with a controllable clock."""
    db_path = str(tmp_path / "data" / "conversations.db")
    now_holder: list[datetime] = [base_now or datetime(2026, 4, 20, 12, 0, 0, tzinfo=MONTREAL)]
    return ConversationStore(db_path, now_fn=lambda: now_holder[0]), now_holder


def _save(store: ConversationStore, session: str, role: str, content: str, *, agent: str | None = None, ts: str | None = None):
    return store.save_message(session, role, content, agent_name=agent, timestamp=ts)


# ---------------------------------------------------------------------------
# §3.4 get_dynamic_messages — time window
# ---------------------------------------------------------------------------


class TestDynamicMessagesWindow:
    """§3.4: messages from last 4 hours, backfill to 3 when sparse."""

    def test_returns_messages_within_4h_window(self, tmp_path):
        """Messages posted within 4 hours are included; older ones excluded.

        Note: the backfill-to-3 rule only fires when the window has *fewer*
        than min_msgs messages. We insert 4 in-window messages so the backfill
        never triggers, then verify the 5h-old message stays out.
        """
        store, now_holder = _make_store(tmp_path, base_now=datetime(2026, 4, 20, 12, 0, 0, tzinfo=MONTREAL))
        session = "sess-window"

        # 4 messages inside the 4h window
        for i in range(4):
            ts = (now_holder[0] - timedelta(hours=1, minutes=i * 5)).strftime("%Y-%m-%d %H:%M:%S")
            _save(store, session, "user", f"inside-{i}", ts=ts)

        # 1 message outside the 4h window
        ts_out = (now_holder[0] - timedelta(hours=5)).strftime("%Y-%m-%d %H:%M:%S")
        _save(store, session, "user", "outside window", ts=ts_out)

        msgs = store.get_dynamic_messages(session, hours=4)
        contents = [m[1] for m in msgs]
        for i in range(4):
            assert f"inside-{i}" in contents
        assert "outside window" not in contents

    def test_backfills_when_window_has_fewer_than_min_msgs(self, tmp_path):
        """When fewer than min_msgs=3 messages are in the window, fetch older messages."""
        store, now_holder = _make_store(tmp_path, base_now=datetime(2026, 4, 20, 12, 0, 0, tzinfo=MONTREAL))
        session = "sess-backfill"

        # 2 recent messages (in window)
        ts_recent = (now_holder[0] - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
        # 1 old message (outside 4h window)
        ts_old = (now_holder[0] - timedelta(hours=6)).strftime("%Y-%m-%d %H:%M:%S")

        _save(store, session, "user", "msg-old-1", ts=ts_old)
        _save(store, session, "user", "msg-recent-1", ts=ts_recent)
        _save(store, session, "user", "msg-recent-2", ts=ts_recent)

        msgs = store.get_dynamic_messages(session, min_msgs=3, hours=4)
        assert len(msgs) == 3
        contents = [m[1] for m in msgs]
        assert "msg-old-1" in contents

    def test_hard_cap_at_max_msgs(self, tmp_path):
        """Hard cap: at most max_msgs messages returned regardless of window size."""
        store, now_holder = _make_store(tmp_path, base_now=datetime(2026, 4, 20, 12, 0, 0, tzinfo=MONTREAL))
        session = "sess-cap"
        ts = (now_holder[0] - timedelta(minutes=30)).strftime("%Y-%m-%d %H:%M:%S")

        for i in range(20):
            _save(store, session, "user", f"msg-{i}", ts=ts)

        msgs = store.get_dynamic_messages(session, max_msgs=10, hours=4)
        assert len(msgs) == 10

    def test_default_max_is_50(self, tmp_path):
        """Default cap is 50 messages (§3.4 product spec)."""
        store, now_holder = _make_store(tmp_path, base_now=datetime(2026, 4, 20, 12, 0, 0, tzinfo=MONTREAL))
        session = "sess-cap50"
        ts = (now_holder[0] - timedelta(minutes=30)).strftime("%Y-%m-%d %H:%M:%S")

        for i in range(70):
            _save(store, session, "user", f"m{i}", ts=ts)

        msgs = store.get_dynamic_messages(session, hours=4)
        assert len(msgs) == 50

    def test_returns_messages_in_chronological_order(self, tmp_path):
        """Messages are returned oldest-first (chronological)."""
        store, now_holder = _make_store(tmp_path, base_now=datetime(2026, 4, 20, 12, 0, 0, tzinfo=MONTREAL))
        session = "sess-order"
        base = now_holder[0]

        for i in range(5):
            ts = (base - timedelta(hours=3) + timedelta(minutes=i * 10)).strftime("%Y-%m-%d %H:%M:%S")
            _save(store, session, "user", f"msg-{i}", ts=ts)

        msgs = store.get_dynamic_messages(session, hours=4)
        contents = [m[1] for m in msgs]
        assert contents == ["msg-0", "msg-1", "msg-2", "msg-3", "msg-4"]

    def test_empty_session_returns_empty_list(self, tmp_path):
        store, _ = _make_store(tmp_path)
        msgs = store.get_dynamic_messages("nonexistent-session", hours=4)
        assert msgs == []


# ---------------------------------------------------------------------------
# §5 agent_name filtering — each agent reads only its own history
# ---------------------------------------------------------------------------


class TestAgentNameFiltering:
    """§5: messages stored with agent_name; each agent filters to its own rows."""

    def test_filters_by_agent_name(self, tmp_path):
        """get_dynamic_messages with agent_name only returns that agent's messages."""
        store, now_holder = _make_store(tmp_path, base_now=datetime(2026, 4, 20, 12, 0, 0, tzinfo=MONTREAL))
        session = "sess-multiagent"
        ts = (now_holder[0] - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")

        _save(store, session, "user", "msg from archie", agent="archie", ts=ts)
        _save(store, session, "user", "msg from victor", agent="victor", ts=ts)
        _save(store, session, "assistant", "reply from archie", agent="archie", ts=ts)

        archie_msgs = store.get_dynamic_messages(session, agent_name="archie", hours=4)
        victor_msgs = store.get_dynamic_messages(session, agent_name="victor", hours=4)

        archie_contents = [m[1] for m in archie_msgs]
        victor_contents = [m[1] for m in victor_msgs]

        assert "msg from archie" in archie_contents
        assert "reply from archie" in archie_contents
        assert "msg from victor" not in archie_contents

        assert "msg from victor" in victor_contents
        assert "msg from archie" not in victor_contents

    def test_null_agent_name_included_in_filtered_query(self, tmp_path):
        """Legacy rows with NULL agent_name are included when filtering by agent (§5 note)."""
        store, now_holder = _make_store(tmp_path, base_now=datetime(2026, 4, 20, 12, 0, 0, tzinfo=MONTREAL))
        session = "sess-legacy"
        ts = (now_holder[0] - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")

        # Row with no agent_name (NULL)
        _save(store, session, "user", "legacy msg", agent=None, ts=ts)
        # Row with specific agent_name
        _save(store, session, "user", "archie msg", agent="archie", ts=ts)

        # When filtering by archie, legacy NULL rows are included
        msgs = store.get_dynamic_messages(session, agent_name="archie", hours=4)
        contents = [m[1] for m in msgs]
        assert "legacy msg" in contents
        assert "archie msg" in contents

    def test_agent_name_stored_on_message(self, tmp_path):
        """Saved messages carry the agent_name field."""
        store, _ = _make_store(tmp_path)
        msg = store.save_message("sess", "user", "hello", agent_name="catherine")
        assert msg.agent_name == "catherine"

    def test_agent_name_retrievable_by_id(self, tmp_path):
        """get_message_by_id returns the agent_name."""
        store, _ = _make_store(tmp_path)
        saved = store.save_message("sess", "user", "hi", agent_name="victor")
        retrieved = store.get_message_by_id(saved.id)
        assert retrieved is not None
        assert retrieved.agent_name == "victor"


# ---------------------------------------------------------------------------
# §3.4 exclude_message_ids — current in-flight message excluded
# ---------------------------------------------------------------------------


class TestExcludeMessageIds:
    """§3.4 / §5: current in-flight message must be excluded from context."""

    def test_excludes_specified_message_ids(self, tmp_path):
        """exclude_message_ids removes those messages from the result."""
        store, now_holder = _make_store(tmp_path, base_now=datetime(2026, 4, 20, 12, 0, 0, tzinfo=MONTREAL))
        session = "sess-excl"
        ts = (now_holder[0] - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")

        m1 = _save(store, session, "user", "keep this", ts=ts)
        m2 = _save(store, session, "user", "exclude this", ts=ts)

        msgs = store.get_dynamic_messages(session, hours=4, exclude_message_ids={m2.id})
        contents = [m[1] for m in msgs]
        assert "keep this" in contents
        assert "exclude this" not in contents

    def test_excludes_current_message_id_from_context(self, tmp_path):
        """Simulates excluding the in-flight message to avoid prompt duplication."""
        store, now_holder = _make_store(tmp_path, base_now=datetime(2026, 4, 20, 12, 0, 0, tzinfo=MONTREAL))
        session = "sess-inflight"
        ts = (now_holder[0] - timedelta(minutes=10)).strftime("%Y-%m-%d %H:%M:%S")

        history = _save(store, session, "user", "previous message", ts=ts)
        current = _save(store, session, "user", "current in-flight message", ts=ts)

        context = store.get_dynamic_messages(session, hours=4, exclude_message_ids={current.id})
        contents = [m[1] for m in context]
        assert "current in-flight message" not in contents
        assert "previous message" in contents


# ---------------------------------------------------------------------------
# §3.4 Thread context — full thread loaded, no count limit
# ---------------------------------------------------------------------------


class TestThreadContext:
    """§3.4: Reply thread loads the full thread (parent + all replies)."""

    def test_returns_parent_and_all_replies(self, tmp_path):
        """get_thread_context returns the parent message plus all reply messages."""
        store, _ = _make_store(tmp_path)

        parent = store.save_message("sess", "user", "original question")
        r1 = store.save_message("sess", "assistant", "first reply", parent_message_id=parent.id)
        r2 = store.save_message("sess", "user", "follow-up", parent_message_id=parent.id)
        r3 = store.save_message("sess", "assistant", "second reply", parent_message_id=parent.id)

        messages, thread_ids = store.get_thread_context(parent.id)

        contents = [m[1] for m in messages]
        assert "original question" in contents
        assert "first reply" in contents
        assert "follow-up" in contents
        assert "second reply" in contents
        assert len(messages) == 4
        assert thread_ids == {parent.id, r1.id, r2.id, r3.id}

    def test_thread_ordered_chronologically(self, tmp_path):
        """Thread messages are returned oldest-first."""
        store, _ = _make_store(tmp_path)

        parent = store.save_message("sess", "user", "parent")
        r1 = store.save_message("sess", "assistant", "reply-1", parent_message_id=parent.id)
        r2 = store.save_message("sess", "user", "reply-2", parent_message_id=parent.id)

        messages, _ = store.get_thread_context(parent.id)
        assert messages[0][1] == "parent"
        assert messages[1][1] == "reply-1"
        assert messages[2][1] == "reply-2"

    def test_returns_empty_for_missing_parent(self, tmp_path):
        """Missing parent → empty list and empty set (no crash)."""
        store, _ = _make_store(tmp_path)
        messages, thread_ids = store.get_thread_context(99999)
        assert messages == []
        assert thread_ids == set()

    def test_exclude_ids_respected_in_thread_context(self, tmp_path):
        """Specific messages can be excluded from thread context too."""
        store, _ = _make_store(tmp_path)

        parent = store.save_message("sess", "user", "parent msg")
        r1 = store.save_message("sess", "assistant", "reply-a", parent_message_id=parent.id)
        r2 = store.save_message("sess", "user", "reply-b", parent_message_id=parent.id)

        messages, _ = store.get_thread_context(parent.id, exclude_message_ids={r1.id})
        contents = [m[1] for m in messages]
        assert "reply-a" not in contents
        assert "parent msg" in contents
        assert "reply-b" in contents

    def test_no_message_count_limit_on_threads(self, tmp_path):
        """Thread context has no message cap — all replies are loaded."""
        store, _ = _make_store(tmp_path)
        parent = store.save_message("sess", "user", "root")
        for i in range(120):
            store.save_message("sess", "assistant" if i % 2 == 0 else "user", f"reply-{i}", parent_message_id=parent.id)

        messages, _ = store.get_thread_context(parent.id)
        # Parent + 120 replies = 121 total — no cap applied
        assert len(messages) == 121


# ---------------------------------------------------------------------------
# §5 FTS5 full-text search
# ---------------------------------------------------------------------------


class TestFTSSearch:
    """§5: FTS5 full-text search enabled on the store."""

    def test_fts_index_exists(self, tmp_path):
        """conversations_fts virtual table exists after init."""
        store, _ = _make_store(tmp_path)
        cur = store.connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='conversations_fts'"
        )
        assert cur.fetchone() is not None

    def test_fts_finds_message_by_keyword(self, tmp_path):
        """Words inserted via save_message are searchable via FTS5."""
        store, _ = _make_store(tmp_path)
        store.save_message("sess", "user", "the quick brown fox")
        store.save_message("sess", "user", "lorem ipsum dolor")

        rows = store.connection.execute(
            "SELECT rowid FROM conversations_fts WHERE conversations_fts MATCH 'quick'"
        ).fetchall()
        assert len(rows) == 1

    def test_fts_does_not_find_absent_keyword(self, tmp_path):
        """Words not in any message yield no FTS results."""
        store, _ = _make_store(tmp_path)
        store.save_message("sess", "user", "hello world")

        rows = store.connection.execute(
            "SELECT rowid FROM conversations_fts WHERE conversations_fts MATCH 'nonexistentkeyword'"
        ).fetchall()
        assert rows == []


# ---------------------------------------------------------------------------
# §5 Basic save / retrieve
# ---------------------------------------------------------------------------


class TestSaveAndRetrieve:
    """Basic persistence contract from §5."""

    def test_save_and_get_by_id(self, tmp_path):
        store, _ = _make_store(tmp_path)
        saved = store.save_message("sess", "user", "hello", source="telegram", telegram_chat_id="-100")
        retrieved = store.get_message_by_id(saved.id)
        assert retrieved is not None
        assert retrieved.content == "hello"
        assert retrieved.role == "user"
        assert retrieved.telegram_chat_id == "-100"

    def test_returns_none_for_unknown_id(self, tmp_path):
        store, _ = _make_store(tmp_path)
        assert store.get_message_by_id(9999) is None

    def test_clear_session_deletes_messages(self, tmp_path):
        store, _ = _make_store(tmp_path)
        store.save_message("sess-to-clear", "user", "gone")
        store.save_message("sess-keep", "user", "stays")
        count = store.clear_session("sess-to-clear")
        assert count == 1
        remaining = store.get_dynamic_messages("sess-to-clear", hours=1)
        assert remaining == []
        kept = store.get_dynamic_messages("sess-keep", hours=1)
        assert len(kept) == 1

    def test_agent_name_column_added_if_missing(self, tmp_path):
        """_ensure_thread_columns is idempotent — calling init twice doesn't crash."""
        db_path = str(tmp_path / "data" / "conversations.db")
        store1 = ConversationStore(db_path)
        store2 = ConversationStore(db_path)  # re-open same file
        # Should not raise; check column still present
        cur = store2.connection.execute("PRAGMA table_info(conversations)")
        cols = {row[1] for row in cur.fetchall()}
        assert "agent_name" in cols
        assert "parent_message_id" in cols
