from __future__ import annotations

from agentforge.event_store import EventStore, initialize_event_store


def test_initialize_event_store_creates_database(tmp_path) -> None:
    db_path = tmp_path / "data" / "events.db"

    initialize_event_store(db_path)

    assert db_path.exists()


def test_event_store_persists_and_marks_processed(tmp_path) -> None:
    store = EventStore(tmp_path / "data" / "events.db")
    store.create_event(
        event_id="evt-1",
        agent="victor",
        source="github",
        event_type="new_pr",
        external_key="pr-176",
        prompt_ref="events/github/new_pr.md",
        payload={"pr_number": 176, "repo": "Martin-Rancourt/AgentForge"},
        created_at="2026-04-20T12:00:00Z",
    )

    open_events = store.list_open_events("victor")
    assert len(open_events) == 1
    assert open_events[0].external_key == "pr-176"
    assert open_events[0].prompt_ref == "events/github/new_pr.md"
    assert open_events[0].payload["pr_number"] == 176

    store.mark_processed("evt-1", processed_at="2026-04-20T12:05:00Z")

    assert store.list_open_events("victor") == []
