"""Snapshot tests for _build_system_prompt_context().

These tests assert that the exact text assembled from context files matches a
committed golden file.  To regenerate snapshots after an intentional change:

    UPDATE_SNAPSHOTS=1 python3 -m pytest tests/test_snapshots.py

Then review the diff and commit the updated .txt files.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from agentforge.claude_runner import _build_system_prompt_context


# ---------------------------------------------------------------------------
# Snapshot infrastructure
# ---------------------------------------------------------------------------

SNAPSHOT_DIR = Path(__file__).parent / "snapshots"


def _check_or_update(name: str, actual: str) -> None:
    path = SNAPSHOT_DIR / f"{name}.txt"
    if os.environ.get("UPDATE_SNAPSHOTS"):
        SNAPSHOT_DIR.mkdir(exist_ok=True)
        path.write_text(actual, encoding="utf-8")
        return
    assert path.exists(), (
        f"Snapshot '{name}' missing — run UPDATE_SNAPSHOTS=1 pytest tests/test_snapshots.py"
    )
    assert actual == path.read_text(encoding="utf-8"), (
        f"Snapshot '{name}' drifted. Regenerate with UPDATE_SNAPSHOTS=1 pytest tests/test_snapshots.py"
    )


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


# ---------------------------------------------------------------------------
# §1  All five context layers assembled correctly
# ---------------------------------------------------------------------------


def test_snapshot_all_five_layers(tmp_path: Path) -> None:
    """All five layers are present and assembled in order."""
    _write(tmp_path / "CLAUDE.md", "# Framework Guide\nCore rules here.")
    _write(tmp_path / "vault" / "Agents" / "_team" / "CLAUDE.md", "# Team Rules\nShared team policy.")
    _write(tmp_path / "vault" / "Agents" / "_team" / "memory.md", "Team fact: the answer is 42.")
    _write(tmp_path / "vault" / "Agents" / "clawdia" / "soul.md", "I am Clawdia, a helpful AI.")
    _write(tmp_path / "vault" / "Agents" / "clawdia" / "memory.md", "User's name is Martin.")

    result = _build_system_prompt_context(str(tmp_path), "clawdia")
    assert result is not None, "Expected non-None result with all layers present"
    _check_or_update("all_five_layers", result)


# ---------------------------------------------------------------------------
# §2  No agent-specific layers
# ---------------------------------------------------------------------------


def test_snapshot_no_agent_layers(tmp_path: Path) -> None:
    """Only shared layers (CLAUDE.md + _team/CLAUDE.md) — no soul/memory files."""
    _write(tmp_path / "CLAUDE.md", "# Framework Guide\nCore rules here.")
    _write(tmp_path / "vault" / "Agents" / "_team" / "CLAUDE.md", "# Team Rules\nShared team policy.")

    result = _build_system_prompt_context(str(tmp_path), "")
    assert result is not None, "Expected non-None result with shared layers present"
    _check_or_update("no_agent_layers", result)


# ---------------------------------------------------------------------------
# §3  Empty memory file is silently skipped (no ## Memory section)
# ---------------------------------------------------------------------------


def test_snapshot_empty_files_skipped(tmp_path: Path) -> None:
    """An empty memory.md must not produce a ## Memory section in the prompt."""
    _write(tmp_path / "CLAUDE.md", "# Framework Guide\nCore rules here.")
    _write(tmp_path / "vault" / "Agents" / "clawdia" / "soul.md", "I am Clawdia.")
    # Empty memory file — must be skipped
    _write(tmp_path / "vault" / "Agents" / "clawdia" / "memory.md", "")

    result = _build_system_prompt_context(str(tmp_path), "clawdia")
    assert result is not None, "Expected non-None result with soul present"
    assert "## Memory" not in result, (
        f"Empty memory.md must not produce a ## Memory section. Got:\n{result}"
    )
    _check_or_update("empty_memory_skipped", result)
