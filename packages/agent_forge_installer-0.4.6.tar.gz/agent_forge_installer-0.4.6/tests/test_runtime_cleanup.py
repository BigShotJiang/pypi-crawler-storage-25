from __future__ import annotations

import json
import subprocess
from pathlib import Path

from agentforge.runtime_cleanup import (
    cleanup_runtime,
    enabled_agent_units,
    find_manual_bot_processes,
    read_agent_states,
    stale_crontab_lines,
)


def _agent(root: Path, name: str, *, active: bool) -> None:
    agent_dir = root / "agents" / name
    (agent_dir / "data").mkdir(parents=True)
    (agent_dir / "config.json").write_text("{}", encoding="utf-8")
    (agent_dir / "data" / "state.json").write_text(
        json.dumps({"active": active}),
        encoding="utf-8",
    )


def test_read_agent_states_splits_active_and_inactive(tmp_path: Path) -> None:
    _agent(tmp_path, "architect", active=True)
    _agent(tmp_path, "christophe", active=False)

    active, inactive = read_agent_states(tmp_path)

    assert active == {"architect"}
    assert inactive == {"christophe"}


def test_enabled_agent_units_only_targets_inactive_agents(tmp_path: Path) -> None:
    service_dir = tmp_path / "systemd" / "user"
    wants = service_dir / "default.target.wants"
    wants.mkdir(parents=True)
    (wants / "agentforge-christophe.service").symlink_to(service_dir / "agentforge-christophe.service")
    (wants / "agentforge-architect.service").symlink_to(service_dir / "agentforge-architect.service")

    units = enabled_agent_units(service_dir, inactive_agents={"christophe"})

    assert units == ["agentforge-christophe.service"]


def test_enabled_agent_units_ignores_installed_but_disabled_units(tmp_path: Path) -> None:
    service_dir = tmp_path / "systemd" / "user"
    service_dir.mkdir(parents=True)
    (service_dir / "agentforge-christophe.service").write_text("[Service]\n", encoding="utf-8")

    units = enabled_agent_units(service_dir, inactive_agents={"christophe"})

    assert units == []


def test_find_manual_bot_processes_matches_instance_root(monkeypatch, tmp_path: Path) -> None:
    output = "\n".join(
        [
            "100 1 bash -lc cd /elsewhere && nohup /elsewhere/runtime/.venv/bin/agentforge bot",
            f"101 1 bash -lc cd {tmp_path} && nohup {tmp_path}/runtime/.venv/bin/agentforge bot",
            f"102 101 {tmp_path}/runtime/.venv/bin/python {tmp_path}/runtime/.venv/bin/agentforge bot",
        ]
    )

    def fake_run(*_args, **_kwargs):
        return subprocess.CompletedProcess([], 0, stdout=output, stderr="")

    monkeypatch.setattr(subprocess, "run", fake_run)

    assert find_manual_bot_processes(tmp_path) == [101, 102]


def test_find_manual_bot_processes_ignores_systemd_managed_bots(monkeypatch, tmp_path: Path) -> None:
    output = "\n".join(
        [
            "200 1 /usr/lib/systemd/systemd --user",
            f"201 200 {tmp_path}/runtime/.venv/bin/python {tmp_path}/runtime/.venv/bin/agentforge bot",
            f"202 1 bash -lc cd {tmp_path} && nohup {tmp_path}/runtime/.venv/bin/agentforge bot",
        ]
    )

    def fake_run(*_args, **_kwargs):
        return subprocess.CompletedProcess([], 0, stdout=output, stderr="")

    monkeypatch.setattr(subprocess, "run", fake_run)

    assert find_manual_bot_processes(tmp_path) == [202]


def test_stale_crontab_lines_reports_root_script_entries(monkeypatch, tmp_path: Path) -> None:
    cron = "\n".join(
        [
            "# comment",
            f"*/5 * * * * {tmp_path}/scripts/heartbeat.sh >> {tmp_path}/logs/heartbeat.log",
            f"0 6 * * * {tmp_path}/runtime/scripts/heartbeat.sh",
        ]
    )

    def fake_run(*_args, **_kwargs):
        return subprocess.CompletedProcess([], 0, stdout=cron, stderr="")

    monkeypatch.setattr(subprocess, "run", fake_run)

    assert stale_crontab_lines(tmp_path) == [
        f"*/5 * * * * {tmp_path}/scripts/heartbeat.sh >> {tmp_path}/logs/heartbeat.log"
    ]


def test_cleanup_runtime_dry_run_reports_without_stopping(monkeypatch, tmp_path: Path) -> None:
    _agent(tmp_path, "christophe", active=False)
    service_dir = tmp_path / "home" / ".config" / "systemd" / "user"
    wants = service_dir / "default.target.wants"
    wants.mkdir(parents=True)
    (wants / "agentforge-christophe.service").symlink_to(service_dir / "agentforge-christophe.service")

    monkeypatch.setattr(Path, "home", lambda: tmp_path / "home")
    monkeypatch.setattr("agentforge.runtime_cleanup._service_dir_for_root", lambda _root: service_dir)
    monkeypatch.setattr("agentforge.runtime_cleanup.find_manual_bot_processes", lambda _root: [123])
    monkeypatch.setattr("agentforge.runtime_cleanup.stale_crontab_lines", lambda _root: ["*/5 * * * * heartbeat"])

    result = cleanup_runtime(tmp_path, dry_run=True)

    assert result.inactive_agents == {"christophe"}
    assert result.stopped_processes == [123]
    assert result.disabled_units == ["agentforge-christophe.service"]
    assert result.stale_cron_lines == ["*/5 * * * * heartbeat"]
