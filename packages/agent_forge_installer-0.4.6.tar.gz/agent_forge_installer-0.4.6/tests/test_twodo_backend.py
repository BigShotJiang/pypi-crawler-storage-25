from __future__ import annotations

from datetime import datetime
import os
from pathlib import Path

import pytest

from agentforge.twodo.archive import load_archive, unpack_archive
from agentforge.twodo.backend import TwoDoBackend, render_note_block, split_note_block


def test_twodo_backend_roundtrip_local_store(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Roundtrip task",
        notes="human note",
        due_at=datetime(2026, 4, 15, 9, 30),
        recurrence_rule="daily",
        priority="high",
        actor_id="architect",
        prompt="Run the task",
    )

    fetched = backend.read_task(created.task_id)
    assert fetched is not None
    assert fetched.title == "🔁 Roundtrip task"  # recurring tasks get the 🔁 prefix
    assert fetched.list_name == "architect"
    assert fetched.due_at == datetime(2026, 4, 15, 9, 30)
    assert fetched.recurrence_rule == "daily"
    assert fetched.priority == "high"

    payload = unpack_archive(load_archive(fetched.path))
    assert payload["title"] == "🔁 Roundtrip task"
    assert payload["caluid"] == fetched.list_id
    # Prompt content is written directly to notes — no metadata block.
    assert payload["notes"] == "Run the task"
    assert "--- AgentForge ---" not in payload["notes"]


def test_twodo_backend_parses_real_reference_task_when_available() -> None:
    root = Path("/home/agentforge/Dropbox/Apps/2Do")
    sample = root / "tod" / "o_u_k_cc565be8d94148b4b7cf1bfa0c4ec3bf_p__i_0f9e7ccd10a643a680d5103847583d5f_d_.tod"
    if not sample.exists() or not os.access(sample, os.R_OK):
        pytest.skip("Real 2Do Dropbox sample is not available in this environment.")

    backend = TwoDoBackend(Path("/home/agentforge/AgentForge"))
    task = backend.read_task("0f9e7ccd10a643a680d5103847583d5f")
    assert task is not None
    assert task.title.removeprefix("🔁 ") == "Testing before Agent forge"
    assert task.notes == "91827"
    assert task.due_at is not None  # live task — don't assert specific date, it can be rescheduled
    assert task.list_name == "Inbox"
    assert task.locations
    assert task.alarms


def test_twodo_backend_reads_real_lists_and_groups_when_available() -> None:
    root = Path("/home/agentforge/Dropbox/Apps/2Do")
    col_dir = root / "col"
    cal_dir = root / "cal"
    if not col_dir.exists() or not cal_dir.exists():
        pytest.skip("Real 2Do Dropbox metadata is not available in this environment.")

    backend = TwoDoBackend(Path("/home/agentforge/AgentForge"))
    lists = backend.read_lists()
    groups = backend.read_groups()

    assert any(item.title == "Inbox" for item in lists)
    assert any(item.title == "Taches" for item in lists)
    assert groups
    assert "LISTS" in groups.values()


def test_render_note_block_returns_content_directly() -> None:
    # Prompt content goes directly in notes — no metadata block.
    rendered = render_note_block("Do the thing")
    assert rendered == "Do the thing"
    assert "--- AgentForge ---" not in rendered

    # Empty content yields empty string.
    assert render_note_block("") == ""
    assert render_note_block("  ") == ""

    # Whitespace is stripped.
    assert render_note_block("  hello  ") == "hello"


def test_complete_task_monthly_advances_without_drift(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)
    created = backend.create_task(
        list_name="architect",
        title="Monthly task",
        due_at=datetime(2026, 1, 31, 9, 0),
        recurrence_rule="monthly",
        actor_id="architect",
    )
    assert backend.complete_task(created.task_id, completed_at=datetime(2026, 1, 31, 9, 5))

    # Original task is now a completed record (mirroring 2Do app behaviour).
    original = backend.read_task(created.task_id)
    assert original is not None
    assert original.is_completed is True
    assert original.last_completed_at == datetime(2026, 1, 31, 9, 5)

    # A new task carries the next occurrence.
    all_tasks = backend.read_tasks(include_completed=False)
    next_occurrence = next((t for t in all_tasks if "Monthly task" in t.title and not t.is_completed), None)
    assert next_occurrence is not None
    assert next_occurrence.task_id != created.task_id
    assert next_occurrence.due_at == datetime(2026, 2, 28, 9, 0)
    assert next_occurrence.recurrence_rule == "monthly"


def test_twodo_backend_omits_empty_locations(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="No location task",
        notes="human note",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert "locations" not in payload


def test_repeat_from_completion_hourly_advances_from_completed_time(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)
    created = backend.create_task(
        list_name="catherine",
        title="Inbox processing",
        due_at=datetime(2026, 4, 14, 9, 0),  # overdue original schedule
        recurrence_rule="hourly",
        actor_id="catherine",
        repeat_from="completion",
    )
    assert created.repeat_from == "completion"

    # Complete the task late — next run must be 1 hour after completion, not schedule.
    assert backend.complete_task(created.task_id, completed_at=datetime(2026, 4, 15, 14, 30))

    all_tasks = backend.read_tasks(include_completed=False)
    next_occurrence = next((t for t in all_tasks if "Inbox processing" in t.title), None)
    assert next_occurrence is not None
    assert next_occurrence.task_id != created.task_id
    assert next_occurrence.due_at == datetime(2026, 4, 15, 15, 30)
    assert next_occurrence.recurrence_rule == "hourly"
    assert next_occurrence.repeat_from == "completion"

    # Native 2Do bitmask: bit 8 (256) must be set for "from completion".
    raw_payload = unpack_archive(load_archive(next_occurrence.path))
    assert int(raw_payload["repeattype"]) & 256


def test_repeat_from_schedule_roundtrip(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="catherine",
        title="Daily from completion",
        due_at=datetime(2026, 4, 14, 9, 0),
        recurrence_rule="daily",
        actor_id="catherine",
        repeat_from="completion",
    )

    fetched = backend.read_task(created.task_id)
    assert fetched is not None
    assert fetched.repeat_from == "completion"


def test_repeat_from_schedule_is_default_and_uses_zero_bitmask(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="catherine",
        title="Default repeat_from task",
        actor_id="catherine",
    )
    assert created.repeat_from == "schedule"

    payload = unpack_archive(load_archive(created.path))
    # No metadata block at all.
    assert "--- AgentForge ---" not in str(payload.get("notes", ""))
    # repeattype must not have bit 8 set (from-schedule = 0).
    assert not (int(payload.get("repeattype", "0")) & 256)


def test_twodo_backend_drops_legacy_raw_locations(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Legacy location task",
        notes="human note",
        actor_id="architect",
    )
    created.raw["locations"] = []
    backend._write_task(created)

    payload = unpack_archive(load_archive(created.path))
    assert "locations" not in payload
