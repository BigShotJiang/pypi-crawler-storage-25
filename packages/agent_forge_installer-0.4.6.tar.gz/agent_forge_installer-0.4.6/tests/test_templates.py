"""Guardrail: shipped scaffolds must not contain personal or instance-specific data."""
from __future__ import annotations

import re
from pathlib import Path

import pytest

ROOT = Path(__file__).parent.parent
TEMPLATES_DIR = ROOT / "src" / "agentforge" / "templates"
INIT_SCAFFOLD = ROOT / "src" / "agentforge" / "cli" / "init.py"

# Patterns that indicate personal/machine-specific content.
# Each entry is (description, compiled_pattern).
_PERSONAL_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    # Real email addresses (not @example.com / @yourdomain.com placeholders)
    (
        "hardcoded email address",
        re.compile(r"\b[A-Za-z0-9._%+-]+@(?!example\.com|yourdomain\.com)[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
    ),
    # UUID-format strings (potential device/simulator identifiers)
    (
        "UUID / device identifier",
        re.compile(r"\b[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\b"),
    ),
    # Known personal markers from the current instance
    (
        "known personal marker (martinrancourt / martin@ / clawdia / iPhone 17 / AB6A38FB)",
        re.compile(r"martinrancourt|martin@|clawdia|iPhone 17|AB6A38FB", re.IGNORECASE),
    ),
    # Hardcoded /home/<user> paths (other than generic $HOME or $AGENTFORGE_ROOT patterns)
    (
        "hardcoded /home/ path",
        re.compile(r"/home/(?!agentforge/AgentForge/)[a-z_][a-z0-9_-]+/"),
    ),
]


def _collect_packaged_scaffold_files() -> list[Path]:
    files = [p for p in TEMPLATES_DIR.rglob("*") if p.is_file()]
    files.append(INIT_SCAFFOLD)
    return files


@pytest.mark.parametrize("scaffold_file", _collect_packaged_scaffold_files(), ids=lambda p: str(p.relative_to(ROOT)))
def test_packaged_scaffolds_contain_no_personal_data(scaffold_file: Path) -> None:
    content = scaffold_file.read_text(encoding="utf-8", errors="replace")
    violations: list[str] = []
    for description, pattern in _PERSONAL_PATTERNS:
        matches = pattern.findall(content)
        if matches:
            violations.append(f"  [{description}]: {matches[:3]}")
    assert not violations, (
        f"{scaffold_file.relative_to(ROOT)} contains personal/instance data:\n"
        + "\n".join(violations)
    )


def test_telegram_send_template_supports_legacy_topic_fallback() -> None:
    content = (TEMPLATES_DIR / "scripts" / "telegram_send.sh").read_text(encoding="utf-8")
    assert "bot/config.json" in content
    assert "telegram.topics" in content
    assert "TELEGRAM_THREAD_" in content


def test_heartbeat_template_uses_vault_agent_tasks_with_legacy_fallback() -> None:
    content = (TEMPLATES_DIR / "scripts" / "heartbeat.sh").read_text(encoding="utf-8")
    assert "python3\" ] || PYTHON_BIN=\"python3" not in content  # sanity: no mangled shell
    assert "-m agentforge.todo_cli due" in content
    assert "-m agentforge.cron_runner" in content
    assert "--limit 1" in content
    assert "TASK_FAIL" in content
    assert 'if [ "$cron_name" = "proactive_check" ]' not in content
    assert 'if [ "$cron_name" = "daily_consolidation" ]' not in content


def test_builtin_cron_templates_exist() -> None:
    for cron_name in ("proactive_check", "daily_consolidation", "daily_learning", "weekly_consolidation"):
        cron_dir = TEMPLATES_DIR / "cron" / cron_name
        assert (cron_dir / "config.json").exists()
        assert (cron_dir / "task.md").exists()


def test_todo_command_template_exists() -> None:
    content = (TEMPLATES_DIR / "scripts" / "todo_command.sh").read_text(encoding="utf-8")
    assert "-m agentforge.todo_cli command" in content
    wrapper = (TEMPLATES_DIR / "commands" / "todo-add" / "task.sh").read_text(encoding="utf-8")
    assert "todo_command.sh" in wrapper
