"""Live smoke tests against the real Telegram API.

Skipped automatically unless env vars are set.

To run:
    AGENTFORGE_SMOKE_TOKEN=xxx AGENTFORGE_SMOKE_CHAT_ID=yyy pytest -m smoke -v
"""

from __future__ import annotations

import os
import time

import pytest

try:
    import httpx
    _HTTPX_AVAILABLE = True
except ImportError:
    _HTTPX_AVAILABLE = False


pytestmark = pytest.mark.smoke


def _skip_if_missing() -> None:
    if not _HTTPX_AVAILABLE:
        pytest.skip("httpx not installed (pip install httpx)")
    if not os.environ.get("AGENTFORGE_SMOKE_TOKEN"):
        pytest.skip("AGENTFORGE_SMOKE_TOKEN not set")
    if not os.environ.get("AGENTFORGE_SMOKE_CHAT_ID"):
        pytest.skip("AGENTFORGE_SMOKE_CHAT_ID not set")


@pytest.mark.smoke
def test_status_command_elicits_response() -> None:
    """/status must produce a bot reply within 15 seconds."""
    _skip_if_missing()

    token = os.environ["AGENTFORGE_SMOKE_TOKEN"]
    chat_id = os.environ["AGENTFORGE_SMOKE_CHAT_ID"]
    base = f"https://api.telegram.org/bot{token}"

    with httpx.Client(timeout=20) as client:
        # Capture baseline offset so we only look at new updates
        upd = client.get(f"{base}/getUpdates?timeout=0").json()
        baseline = max(
            (u["update_id"] for u in upd.get("result", [])),
            default=0,
        )

        # Send /status to the target chat
        client.post(
            f"{base}/sendMessage",
            json={"chat_id": int(chat_id), "text": "/status"},
        )

        # Poll up to 3 × 5 s for a bot reply
        found = False
        for _ in range(3):
            time.sleep(5)
            upd = client.get(f"{base}/getUpdates?offset={baseline + 1}&timeout=0").json()
            for u in upd.get("result", []):
                msg = u.get("message", {})
                text = msg.get("text") or ""
                if msg.get("from", {}).get("is_bot") and any(
                    kw in text for kw in ("Service", "CPU", "Disk", "uptime", "Status")
                ):
                    found = True
                    break
            if found:
                break

    assert found, "/status did not produce a bot reply within 15 seconds"
