from __future__ import annotations

import os
import stat
import subprocess
from pathlib import Path


def _write_executable(path: Path, content: str) -> None:
    path.write_text(content)
    path.chmod(path.stat().st_mode | stat.S_IXUSR)


def _make_fake_tooling(bin_dir: Path) -> None:
    _write_executable(
        bin_dir / "python3",
        """#!/usr/bin/env bash
set -euo pipefail
if [ "${1:-}" = "--version" ]; then
  echo "Python 3.11.9"
  exit 0
fi
if [ "${1:-}" = "-c" ]; then
  echo "3.11"
  exit 0
fi
if [ "${1:-}" = "-m" ] && [ "${2:-}" = "venv" ]; then
  mkdir -p "$3/bin"
  cat > "$3/bin/activate" <<'EOF'
# fake activate
: 
EOF
  exit 0
fi
echo "unexpected python3 args: $*" >&2
exit 1
""",
    )
    _write_executable(
        bin_dir / "pip",
        """#!/usr/bin/env bash
set -euo pipefail
exit 0
""",
    )
    _write_executable(
        bin_dir / "agentforge",
        """#!/usr/bin/env bash
set -euo pipefail
target_dir=""
while [ "$#" -gt 0 ]; do
  if [ "${1:-}" = "runtime" ]; then
    exit 0
  fi
  case "$1" in
    --dir)
      target_dir="$2"
      shift 2
      ;;
    *)
      shift
      ;;
  esac
done
mkdir -p "$target_dir/bot" "$target_dir/memory"
printf '{}' > "$target_dir/bot/config.json"
printf 'soul\\n' > "$target_dir/memory/soul.md"
exit 0
""",
    )


def _run_installer(repo_root: Path, working_dir: Path, *args: str) -> subprocess.CompletedProcess[str]:
    fake_home = working_dir / "home"
    fake_bin = working_dir / "fake-bin"
    fake_home.mkdir(parents=True, exist_ok=True)
    fake_bin.mkdir(parents=True, exist_ok=True)
    _make_fake_tooling(fake_bin)

    env = os.environ.copy()
    env["HOME"] = str(fake_home)
    env["PATH"] = f"{fake_bin}:{env['PATH']}"

    return subprocess.run(
        [str(repo_root / "install.sh"), *args],
        cwd=working_dir,
        env=env,
        text=True,
        capture_output=True,
        check=True,
    )


def test_install_script_default_target_is_canonical_and_newline_free(tmp_path: Path) -> None:
    repo_root = Path(__file__).resolve().parents[1]
    install_root = tmp_path / "instance-default"
    install_root.mkdir()

    result = _run_installer(repo_root, install_root)

    service_file = install_root / "home" / ".config" / "systemd" / "user" / "agentforge.service"
    service_text = service_file.read_text()
    working_directory_line = next(
        line for line in service_text.splitlines() if line.startswith("WorkingDirectory=")
    )
    exec_start_line = next(
        line for line in service_text.splitlines() if line.startswith("ExecStart=")
    )

    assert "🎉 Installation complete!" in result.stdout
    assert (install_root / "git-repos").is_dir()
    assert str(install_root / "runtime" / ".venv") in service_text
    assert f"WorkingDirectory={install_root}" in service_text
    assert "\n" not in working_directory_line.removeprefix("WorkingDirectory=")
    assert "\n" not in exec_start_line.removeprefix("ExecStart=")


def test_install_script_explicit_target_creates_valid_venv_path(tmp_path: Path) -> None:
    repo_root = Path(__file__).resolve().parents[1]
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    explicit_target = workspace / "nested" / "agentforge-instance"

    result = _run_installer(repo_root, workspace, str(explicit_target))

    service_file = workspace / "home" / ".config" / "systemd" / "user" / "agentforge.service"
    service_text = service_file.read_text()

    assert "✅ Virtual environment created and activated" in result.stdout
    assert explicit_target.exists()
    assert (explicit_target / "git-repos").is_dir()
    assert f"WorkingDirectory={explicit_target}" in service_text
    assert f"ExecStart={explicit_target}/runtime/.venv/bin/agentforge bot" in service_text
    assert "\r" not in service_text
