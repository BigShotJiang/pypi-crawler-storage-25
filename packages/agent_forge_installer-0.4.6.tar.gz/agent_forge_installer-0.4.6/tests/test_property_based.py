"""Property-based tests using Hypothesis.

Invariants that must hold for any input — not just hand-picked examples.
"""

from __future__ import annotations

import tempfile

from hypothesis import given, settings
from hypothesis import strategies as st

from agentforge.approval_gates import ApprovalGates
from agentforge.conversation_store import ConversationStore
from agentforge.rate_limiter import RateLimiter


# ---------------------------------------------------------------------------
# §8  RateLimiter invariants
# ---------------------------------------------------------------------------


@given(
    max_per_minute=st.integers(min_value=1, max_value=20),
    chat_ids=st.lists(st.text(min_size=1, max_size=10), min_size=0, max_size=50),
)
def test_rate_limiter_minute_bucket_never_overfills(max_per_minute: int, chat_ids: list[str]) -> None:
    """For any sequence of allow() calls, no per-minute bucket exceeds max_per_minute.

    Uses a frozen clock (all calls at t=0) so every timestamp falls in the same
    60-second window, exercising the hard boundary condition.
    """
    limiter = RateLimiter(max_per_minute=max_per_minute, max_per_hour=9999, clock=lambda: 0.0)
    for cid in chat_ids:
        limiter.allow(cid, "agent")
    for cid, bucket in limiter._minute_buckets.items():
        assert len(bucket) <= max_per_minute, (
            f"chat_id={cid!r}: bucket has {len(bucket)} entries but max is {max_per_minute}"
        )


@given(
    max_per_hour=st.integers(min_value=1, max_value=20),
    chat_ids=st.lists(st.text(min_size=1, max_size=10), min_size=0, max_size=50),
)
def test_rate_limiter_hour_bucket_never_overfills(max_per_hour: int, chat_ids: list[str]) -> None:
    """For any sequence of allow() calls, no per-hour bucket exceeds max_per_hour."""
    limiter = RateLimiter(max_per_minute=9999, max_per_hour=max_per_hour, clock=lambda: 0.0)
    for cid in chat_ids:
        limiter.allow(cid, "agent")
    for cid, bucket in limiter._hour_buckets.items():
        assert len(bucket) <= max_per_hour, (
            f"chat_id={cid!r}: hour bucket has {len(bucket)} entries but max is {max_per_hour}"
        )


@given(
    max_concurrent=st.integers(min_value=1, max_value=10),
    agent_names=st.lists(st.text(min_size=1, max_size=10), min_size=0, max_size=30),
)
def test_rate_limiter_concurrent_sessions_never_go_negative(
    max_concurrent: int, agent_names: list[str]
) -> None:
    """session_end() can be called more times than session_start() — count must never go below 0."""
    limiter = RateLimiter(max_concurrent_sessions=max_concurrent)
    for name in agent_names:
        limiter.session_start(name)
    # End twice as many as started — floor at 0 must hold
    for name in agent_names:
        limiter.session_end(name)
        limiter.session_end(name)
    for name, count in limiter._active_sessions.items():
        assert count >= 0, f"agent={name!r}: session count went negative ({count})"


# ---------------------------------------------------------------------------
# §10  ApprovalGates invariant
# ---------------------------------------------------------------------------


@given(cmd=st.text())
@settings(max_examples=500)
def test_evaluate_command_never_raises_and_returns_valid_status(cmd: str) -> None:
    """evaluate_command() never raises and always returns a valid status string."""
    with tempfile.TemporaryDirectory() as tmp:
        gates = ApprovalGates(root=tmp, timeout_seconds=1)
        result = gates.evaluate_command(cmd)
    assert result.status in {"safe", "blocked", "approval_required"}, (
        f"Unexpected status {result.status!r} for input {cmd!r}"
    )
    assert isinstance(result.reason, str)


# ---------------------------------------------------------------------------
# §3.4  ConversationStore dynamic messages cap invariant
# ---------------------------------------------------------------------------


@given(
    max_msgs=st.integers(min_value=1, max_value=100),
    stored=st.integers(min_value=0, max_value=150),
)
@settings(deadline=None)
def test_dynamic_messages_length_never_exceeds_max_msgs(max_msgs: int, stored: int) -> None:
    """get_dynamic_messages() never returns more than max_msgs entries regardless of stored count."""
    with tempfile.TemporaryDirectory() as tmp:
        store = ConversationStore(f"{tmp}/db.sqlite")
        ts = "2026-04-20 10:00:00"
        for i in range(stored):
            store.save_message("sess", "user", f"msg{i}", timestamp=ts)
        result = store.get_dynamic_messages("sess", max_msgs=max_msgs, hours=9999)
    assert len(result) <= max_msgs, (
        f"stored={stored}, max_msgs={max_msgs} → got {len(result)} messages"
    )


@given(
    min_msgs=st.integers(min_value=1, max_value=10),
    stored=st.integers(min_value=0, max_value=20),
)
@settings(deadline=None)
def test_dynamic_messages_length_never_exceeds_stored(min_msgs: int, stored: int) -> None:
    """get_dynamic_messages() never returns more messages than were stored."""
    with tempfile.TemporaryDirectory() as tmp:
        store = ConversationStore(f"{tmp}/db.sqlite")
        ts = "2026-04-20 10:00:00"
        for i in range(stored):
            store.save_message("sess", "user", f"msg{i}", timestamp=ts)
        result = store.get_dynamic_messages("sess", min_msgs=min_msgs, max_msgs=100, hours=9999)
    assert len(result) <= stored, (
        f"stored={stored}, min_msgs={min_msgs} → got {len(result)} messages (more than stored)"
    )
