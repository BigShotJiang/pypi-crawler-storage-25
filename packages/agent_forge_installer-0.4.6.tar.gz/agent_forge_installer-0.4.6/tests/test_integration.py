"""Integration tests: real ConversationStore + real RateLimiter + ClawdiaBot wired together.

Only subprocess (Claude CLI) and HTTP calls are mocked — everything else is real.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from agentforge.approval_gates import ApprovalGates
from agentforge.claude_runner import InvokeResult
from agentforge.conversation_store import ConversationStore
from agentforge.rate_limiter import RateLimiter
from agentforge.telegram_adapter import ClawdiaBot


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_wired_bot(
    tmp_path: Path,
    monkeypatch,
    *,
    invoke_calls: list | None = None,
    sent_messages: list | None = None,
) -> ClawdiaBot:
    """Build a ClawdiaBot backed by a real ConversationStore and real RateLimiter.

    Only invoke_claude (subprocess) and http_post_json (network) are stubbed.
    """
    db_path = tmp_path / "data" / "conversations.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    store = ConversationStore(str(db_path))

    bot = object.__new__(ClawdiaBot)
    bot.config = {
        "bot_name": "clawdia",
        "claude": {"model": "sonnet"},
        "telegram": {
            "max_message_length": 4096,
            "allowed_chat_ids": ["-100999"],
            "default_for_threads": [10],
            "bot_username": "clawdia",
        },
        "threads": {
            "default": {"backend": "claude", "model": "sonnet"},
            "10": {"name": "clawdia", "model": "sonnet"},
        },
        # Thread 10 is also a project topic so bot messages in it are recorded (§3.2)
        "project_topics": {
            "10": {"name": "Reporter"},
        },
    }
    bot.bot_name = "clawdia"
    bot.api_base = "https://example.test"
    bot.token = "test-token"
    bot.agent_api_bases = {}
    bot.thread_api_bases = {}
    bot.store = store
    bot.rate_limiter = RateLimiter(max_per_minute=10, max_per_hour=60, max_concurrent_sessions=2)
    bot.approval_gates = ApprovalGates(root=str(tmp_path), timeout_seconds=1)
    bot.offset = 0
    bot._save_offset = lambda: None
    bot._log_action = lambda *a, **kw: None
    bot._save_pending_retry = lambda *a, **kw: None
    bot._save_usage = lambda *a, **kw: None
    bot.agent_queues: dict = {}
    bot.agent_workers: dict = {}

    # Bind real methods that are needed
    for method in (
        "_handle_update",
        "_invoke_and_respond",
        "_should_respond_to_thread",
        "_is_monitor_thread",
        "_extract_message_text",
        "_resolve_reply_parent_message_id",
        "_record_project_topic_bot_message",
        "_is_self_bot_message",
        "_save_message",
        "_dispatch_command",
        "_dispatch_builtin",
        "_is_active",
        "_set_active",
        "_get_state_path",
        "_get_active_state_path",
        "_get_api_base",
        "_start_typing_loop",
        "_send_message",
        "_set_reaction",
        "_enqueue_task",
        "_ensure_agent_worker",
        "_worker",
        "_handle_worker_error",
        "_build_restart_picker",
        "_restart_agent_service",
        "_get_current_service_unit",
        "_discover_restartable_agents",
        "_append_claude_usage_summary",
        "_append_real_claude_usage",
        "_format_usage_reset_label",
        "_builtin_status",
    ):
        if hasattr(ClawdiaBot, method):
            setattr(bot, method, getattr(ClawdiaBot, method).__get__(bot, ClawdiaBot))

    # Capture _send_message calls
    if sent_messages is not None:
        bot._send_message = lambda *a, **kw: sent_messages.append(a)

    # Stub invoke_claude to return a fixed response
    _invoke_calls = invoke_calls if invoke_calls is not None else []

    def _fake_invoke(**kwargs):
        _invoke_calls.append(kwargs)
        return InvokeResult(text="mocked-reply", cost_usd=0.0, model="sonnet")

    monkeypatch.setattr("agentforge.telegram_adapter.invoke_claude", _fake_invoke)
    monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", lambda url, data, **kw: {"ok": True})

    return bot


def _update(text: str, msg_id: int = 1, thread_id: int = 10) -> dict:
    return {
        "update_id": msg_id,
        "message": {
            "message_id": msg_id,
            "message_thread_id": thread_id,
            "chat": {"id": "-100999", "type": "supergroup"},
            "from": {"is_bot": False, "first_name": "Martin"},
            "text": text,
        },
    }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_second_message_context_includes_first(tmp_path: Path, monkeypatch) -> None:
    """After a first exchange is persisted, the second message sees it in recent_messages."""
    invoke_calls: list[dict] = []
    bot = _make_wired_bot(tmp_path, monkeypatch, invoke_calls=invoke_calls)

    # First message
    bot._handle_update(_update("Hello from Martin", msg_id=1))
    # Drain the worker queue so the first message and its reply are persisted
    for agent_name, q in bot.agent_queues.items():
        q.join()

    # Reset invoke_calls to isolate the second invocation
    invoke_calls.clear()

    # Second message
    bot._handle_update(_update("Second message here", msg_id=2))
    for agent_name, q in bot.agent_queues.items():
        q.join()

    assert invoke_calls, "invoke_claude should have been called for the second message"
    recent = invoke_calls[-1].get("recent_messages", [])
    texts = [content for _role, content, *_ in recent]
    assert any("Hello from Martin" in t or "mocked-reply" in t for t in texts), (
        f"First message or its reply must appear in context window. Got: {texts}"
    )


def test_eleventh_message_blocked_by_rate_limiter(tmp_path: Path, monkeypatch) -> None:
    """The 11th message from the same chat within a minute is blocked by the rate limiter."""
    invoke_calls: list[dict] = []
    sent: list[tuple] = []
    bot = _make_wired_bot(tmp_path, monkeypatch, invoke_calls=invoke_calls, sent_messages=sent)
    bot.rate_limiter = RateLimiter(max_per_minute=10, max_per_hour=100, max_concurrent_sessions=5)

    # Exhaust the per-minute bucket (frozen clock: all calls at the same instant)
    for _ in range(10):
        bot.rate_limiter.allow("-100999", "clawdia")

    invoke_calls.clear()

    # Drive the 11th update — must be rate-limited
    bot._handle_update(_update("Should be blocked", msg_id=11))
    # No worker needed — rate limit fires synchronously before enqueue

    assert not invoke_calls, "invoke_claude must NOT be called when rate-limited"
    assert sent, "_send_message must send the rate-limit notice"
    assert any("⏱" in str(a) for a in sent), f"Rate-limit message should contain ⏱. Got: {sent}"


def test_bot_message_is_stored_in_real_db(tmp_path: Path, monkeypatch) -> None:
    """§3.2 end-to-end: a bot update in a threaded topic is stored in the real ConversationStore."""
    import sqlite3

    bot = _make_wired_bot(tmp_path, monkeypatch)

    # Drive a bot message update (is_bot=True, message_thread_id present)
    bot._handle_update({
        "update_id": 50,
        "message": {
            "message_id": 50,
            "message_thread_id": 10,
            "chat": {"id": "-100999", "type": "supergroup"},
            "from": {"is_bot": True, "username": "reporter_bot"},
            "text": "automated-bot-report",
        },
    })

    # Bot messages are stored synchronously (no worker needed) — check the DB directly
    db_path = tmp_path / "data" / "conversations.db"
    with sqlite3.connect(str(db_path)) as conn:
        rows = conn.execute(
            "SELECT content, agent_name FROM conversations WHERE content LIKE '%automated-bot-report%'"
        ).fetchall()

    assert rows, "Bot message must be stored in the real ConversationStore (§3.2)"
    assert rows[0][1] == "reporter_bot", f"agent_name must be 'reporter_bot', got: {rows[0][1]}"


def test_shared_message_visible_in_context(tmp_path: Path, monkeypatch) -> None:
    """A message saved without an agent_name (shared/legacy) is visible to any agent's context query."""
    invoke_calls: list[dict] = []
    bot = _make_wired_bot(tmp_path, monkeypatch, invoke_calls=invoke_calls)

    # Save a message with agent_name=None — these are visible to all agents (legacy rows)
    session_id = "tg--100999-t10"
    bot._save_message(
        session_id,
        "assistant",
        "shared-team-note",
        "-100999",
        "shared-msg-1",
        thread_id=10,
        agent_name=None,
    )

    bot._handle_update(_update("Did you see the note?", msg_id=6))
    for q in bot.agent_queues.values():
        q.join()

    assert invoke_calls, "invoke_claude should have been called"
    recent = invoke_calls[-1].get("recent_messages", [])
    texts = [content for _role, content, *_ in recent]
    assert any("shared-team-note" in t for t in texts), (
        f"Shared (agent_name=None) message must appear in context. Got: {texts}"
    )
