"""Shared SQLite conversation storage for Telegram and HTTP API access."""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from threading import Lock
from typing import Any, Callable
from zoneinfo import ZoneInfo

MONTREAL = ZoneInfo("America/Montreal")


def _default_now() -> datetime:
    return datetime.now(MONTREAL)


@dataclass
class ConversationMessage:
    id: int
    session_id: str
    timestamp: str
    role: str
    content: str
    source: str
    telegram_chat_id: str | None
    telegram_message_id: str | None
    metadata: dict[str, Any]
    parent_message_id: int | None = None
    thread_reply_count: int = 0
    agent_name: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "timestamp": self.timestamp,
            "role": self.role,
            "content": self.content,
            "source": self.source,
            "telegram_chat_id": self.telegram_chat_id,
            "telegram_message_id": self.telegram_message_id,
            "metadata": self.metadata,
            "parent_message_id": self.parent_message_id,
            "thread_reply_count": self.thread_reply_count,
            "agent_name": self.agent_name,
        }


class ConversationStore:
    """Thread-safe wrapper around the shared conversations SQLite database."""

    def __init__(
        self,
        db_path: str,
        *,
        connection: sqlite3.Connection | None = None,
        now_fn: Callable[[], datetime] | None = None,
    ) -> None:
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._connection = connection or sqlite3.connect(db_path, check_same_thread=False)
        self._connection.row_factory = sqlite3.Row
        self._lock = Lock()
        self._now_fn = now_fn or _default_now
        self.init_db()

    @property
    def connection(self) -> sqlite3.Connection:
        return self._connection

    def init_db(self) -> None:
        with self._lock:
            self._connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    timestamp TEXT NOT NULL DEFAULT (datetime('now')),
                    role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
                    content TEXT NOT NULL,
                    source TEXT NOT NULL DEFAULT 'telegram',
                    telegram_chat_id TEXT,
                    telegram_message_id TEXT,
                    metadata TEXT,
                    agent_name TEXT
                );
                CREATE TABLE IF NOT EXISTS pending_retries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    user_text TEXT NOT NULL,
                    thread_cfg TEXT NOT NULL,
                    chat_id TEXT NOT NULL,
                    thread_id TEXT,
                    created_at TEXT NOT NULL,
                    retry_after TEXT NOT NULL,
                    attempts INTEGER DEFAULT 0,
                    reason TEXT NOT NULL DEFAULT 'rate_limit'
                );
                CREATE INDEX IF NOT EXISTS idx_conversations_session
                    ON conversations(session_id);
                CREATE INDEX IF NOT EXISTS idx_conversations_timestamp
                    ON conversations(timestamp);
                CREATE INDEX IF NOT EXISTS idx_conversations_source
                    ON conversations(source);
                """
            )
            cur = self._connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='conversations_fts'"
            )
            if not cur.fetchone():
                self._connection.executescript(
                    """
                    CREATE VIRTUAL TABLE conversations_fts USING fts5(
                        content, content='conversations', content_rowid='id'
                    );
                    CREATE TRIGGER IF NOT EXISTS conversations_ai
                        AFTER INSERT ON conversations BEGIN
                        INSERT INTO conversations_fts(rowid, content)
                            VALUES (new.id, new.content);
                    END;
                    CREATE TRIGGER IF NOT EXISTS conversations_ad
                        AFTER DELETE ON conversations BEGIN
                        INSERT INTO conversations_fts(conversations_fts, rowid, content)
                            VALUES('delete', old.id, old.content);
                    END;
                    """
                )
            self._connection.commit()
        self._ensure_thread_columns()

    def _ensure_thread_columns(self) -> None:
        """Add missing columns to conversations and pending_retries if they don't exist yet."""
        with self._lock:
            retry_cols = {row[1] for row in self._connection.execute("PRAGMA table_info(pending_retries)").fetchall()}
            if "reason" not in retry_cols:
                self._connection.execute(
                    "ALTER TABLE pending_retries ADD COLUMN reason TEXT NOT NULL DEFAULT 'rate_limit'"
                )
                self._connection.commit()

            existing = {row[1] for row in self._connection.execute("PRAGMA table_info(conversations)").fetchall()}
            if "parent_message_id" not in existing:
                self._connection.execute(
                    "ALTER TABLE conversations ADD COLUMN parent_message_id INTEGER REFERENCES conversations(id)"
                )
                self._connection.execute(
                    "CREATE INDEX IF NOT EXISTS idx_conversations_parent ON conversations(parent_message_id)"
                )
                self._connection.commit()
            if "agent_name" not in existing:
                self._connection.execute(
                    "ALTER TABLE conversations ADD COLUMN agent_name TEXT"
                )
                self._connection.execute(
                    "CREATE INDEX IF NOT EXISTS idx_conversations_agent_name ON conversations(agent_name)"
                )
                self._connection.commit()

    def save_message(
        self,
        session_id: str,
        role: str,
        content: str,
        *,
        source: str = "telegram",
        telegram_chat_id: str | None = None,
        telegram_message_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        timestamp: str | None = None,
        parent_message_id: int | None = None,
        agent_name: str | None = None,
    ) -> ConversationMessage:
        ts = timestamp or self._now_fn().strftime("%Y-%m-%d %H:%M:%S")
        encoded_metadata = json.dumps(metadata) if metadata is not None else None
        with self._lock:
            cur = self._connection.execute(
                """
                INSERT INTO conversations
                (session_id, timestamp, role, content, source, telegram_chat_id, telegram_message_id, metadata, parent_message_id, agent_name)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    session_id,
                    ts,
                    role,
                    content,
                    source,
                    telegram_chat_id,
                    telegram_message_id,
                    encoded_metadata,
                    parent_message_id,
                    agent_name,
                ),
            )
            self._connection.commit()
            message_id = int(cur.lastrowid)
        return ConversationMessage(
            id=message_id,
            session_id=session_id,
            timestamp=ts,
            role=role,
            content=content,
            source=source,
            telegram_chat_id=telegram_chat_id,
            telegram_message_id=telegram_message_id,
            metadata=metadata or {},
            parent_message_id=parent_message_id,
            thread_reply_count=0,
            agent_name=agent_name,
        )

    def get_recent_messages(
        self, session_id: str, limit: int, hours: int | None = None
    ) -> list[tuple[str, str, str]]:
        if hours is not None:
            cutoff = (self._now_fn() - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
            with self._lock:
                rows = self._connection.execute(
                    """
                    SELECT role, content, timestamp FROM conversations
                    WHERE session_id = ? AND timestamp >= ?
                    ORDER BY id DESC
                    """,
                    (session_id, cutoff),
                ).fetchall()
        else:
            cutoff = (self._now_fn() - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
            with self._lock:
                rows = self._connection.execute(
                    """
                    SELECT role, content, timestamp FROM conversations
                    WHERE session_id = ? AND timestamp >= ?
                    ORDER BY id DESC LIMIT ?
                    """,
                    (session_id, cutoff, limit),
                ).fetchall()
                if len(rows) < min(limit, 3):
                    rows = self._connection.execute(
                        """
                        SELECT role, content, timestamp FROM conversations
                        WHERE session_id = ?
                        ORDER BY id DESC LIMIT ?
                        """,
                        (session_id, max(limit, 3)),
                    ).fetchall()
        ordered = list(reversed(rows))
        return [(row["role"], row["content"], row["timestamp"]) for row in ordered]

    def get_dynamic_messages(
        self,
        session_id: str,
        *,
        min_msgs: int = 3,
        max_msgs: int = 50,
        hours: int = 4,
        agent_name: str | None = None,
        exclude_message_ids: set[int] | None = None,
    ) -> list[tuple[str, str, str]]:
        """Dynamic context: messages from last `hours` hours, capped at `max_msgs`.

        The time window is the primary constraint. The message cap is a safety ceiling
        to bound prompt size and cost — default 50 per product spec (§3.4) to protect
        against unbounded prompt growth while keeping context meaningful.
        Minimum backfill of `min_msgs` is always guaranteed.

        When ``agent_name`` is provided only messages belonging to that agent are
        returned (i.e. rows where ``agent_name`` matches *or* where ``agent_name``
        is NULL — the latter covers legacy rows written before this column existed).
        Note: exclusions are applied after the SQL fetch. When many rows are excluded,
        the fallback path can still return fewer than `min_msgs`; that is acceptable for
        now because the caller uses exclusions only to avoid duplicating explicit
        thread/current-message context in the prompt.
        """
        exclude_message_ids = exclude_message_ids or set()
        fetch_limit = max(max_msgs, min_msgs) + len(exclude_message_ids)
        cutoff = (self._now_fn() - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
        if agent_name:
            with self._lock:
                windowed = self._connection.execute(
                    """SELECT id, role, content, timestamp FROM conversations
                       WHERE session_id = ? AND timestamp >= ?
                       AND (agent_name = ? OR agent_name IS NULL)
                       ORDER BY id DESC LIMIT ?""",
                    (session_id, cutoff, agent_name, fetch_limit),
                ).fetchall()
            windowed = [row for row in windowed if row["id"] not in exclude_message_ids]
            if len(windowed) >= min_msgs:
                trimmed = windowed[:max_msgs]
                return [(r["role"], r["content"], r["timestamp"]) for r in reversed(trimmed)]
            with self._lock:
                rows = self._connection.execute(
                    """SELECT id, role, content, timestamp FROM conversations
                       WHERE session_id = ?
                       AND (agent_name = ? OR agent_name IS NULL)
                       ORDER BY id DESC LIMIT ?""",
                    (session_id, agent_name, min_msgs + len(exclude_message_ids)),
                ).fetchall()
            rows = [row for row in rows if row["id"] not in exclude_message_ids]
            trimmed = rows[:min_msgs]
            return [(r["role"], r["content"], r["timestamp"]) for r in reversed(trimmed)]

        with self._lock:
            windowed = self._connection.execute(
                """SELECT id, role, content, timestamp FROM conversations
                   WHERE session_id = ? AND timestamp >= ?
                   ORDER BY id DESC LIMIT ?""",
                (session_id, cutoff, fetch_limit),
            ).fetchall()
        windowed = [row for row in windowed if row["id"] not in exclude_message_ids]
        if len(windowed) >= min_msgs:
            trimmed = windowed[:max_msgs]
            return [(r["role"], r["content"], r["timestamp"]) for r in reversed(trimmed)]
        # Backfill: window is too sparse, grab min_msgs going further back
        with self._lock:
            rows = self._connection.execute(
                """SELECT id, role, content, timestamp FROM conversations
                   WHERE session_id = ?
                   ORDER BY id DESC LIMIT ?""",
                (session_id, min_msgs + len(exclude_message_ids)),
            ).fetchall()
        rows = [row for row in rows if row["id"] not in exclude_message_ids]
        trimmed = rows[:min_msgs]
        return [(r["role"], r["content"], r["timestamp"]) for r in reversed(trimmed)]

    def clear_session(self, session_id: str) -> int:
        """Delete all messages for a session. Returns count deleted."""
        with self._lock:
            cur = self._connection.execute(
                "DELETE FROM conversations WHERE session_id = ?", (session_id,)
            )
            self._connection.commit()
            return cur.rowcount

    def list_messages(
        self,
        *,
        channel_id: str,
        limit: int = 50,
        before: str | None = None,
    ) -> list[ConversationMessage]:
        params: list[Any] = [
            f"api-channel-{channel_id}",
            f"%-t{channel_id}",
            channel_id,
        ]
        before_clause = ""
        if before:
            before_clause = "AND c.timestamp < ?"
            params.append(before)
        params.append(limit)
        query = f"""
            SELECT c.id, c.session_id, c.timestamp, c.role, c.content, c.source,
                   c.telegram_chat_id, c.telegram_message_id, c.metadata, c.parent_message_id,
                   (SELECT COUNT(*) FROM conversations r WHERE r.parent_message_id = c.id) AS thread_reply_count
            FROM conversations c
            WHERE (
                c.session_id = ?
                OR c.session_id LIKE ?
                OR json_extract(c.metadata, '$.channel') = ?
            )
            AND c.parent_message_id IS NULL
            {before_clause}
            ORDER BY c.timestamp DESC, c.id DESC
            LIMIT ?
        """
        with self._lock:
            rows = self._connection.execute(query, params).fetchall()
        return [self._row_to_message(row) for row in rows]

    def get_message_by_id(self, message_id: int) -> ConversationMessage | None:
        """Return a single message by its primary key, or None if not found."""
        with self._lock:
            row = self._connection.execute(
                "SELECT c.id, c.session_id, c.timestamp, c.role, c.content, c.source, "
                "c.telegram_chat_id, c.telegram_message_id, c.metadata, c.parent_message_id, "
                "0 AS thread_reply_count, c.agent_name FROM conversations c WHERE c.id = ?",
                (message_id,),
            ).fetchone()
        return self._row_to_message(row) if row else None

    def find_telegram_message(
        self,
        *,
        chat_id: str,
        telegram_message_id: str,
        channel_id: str | None = None,
    ) -> ConversationMessage | None:
        """Return a Telegram-backed message by chat/message id, optionally scoped to a channel."""
        query = (
            "SELECT c.id, c.session_id, c.timestamp, c.role, c.content, c.source, "
            "c.telegram_chat_id, c.telegram_message_id, c.metadata, c.parent_message_id, "
            # Keep the row shape compatible with _row_to_message.
            "0 AS thread_reply_count FROM conversations c "
            "WHERE c.telegram_chat_id = ? AND c.telegram_message_id = ?"
        )
        params: list[Any] = [chat_id, telegram_message_id]
        if channel_id is not None:
            query += " AND json_extract(c.metadata, '$.channel') = ?"
            params.append(channel_id)
        query += " ORDER BY c.id DESC LIMIT 1"
        with self._lock:
            row = self._connection.execute(query, params).fetchone()
        return self._row_to_message(row) if row else None

    def list_thread_messages(self, parent_message_id: int) -> list[ConversationMessage]:
        """Return all reply messages for a given parent message, ordered oldest-first."""
        query = """
            SELECT c.id, c.session_id, c.timestamp, c.role, c.content, c.source,
                   c.telegram_chat_id, c.telegram_message_id, c.metadata, c.parent_message_id,
                   0 AS thread_reply_count
            FROM conversations c
            WHERE c.parent_message_id = ?
            ORDER BY c.timestamp ASC, c.id ASC
        """
        with self._lock:
            rows = self._connection.execute(query, (parent_message_id,)).fetchall()
        return [self._row_to_message(row) for row in rows]

    def get_thread_context(
        self,
        parent_message_id: int,
        *,
        exclude_message_ids: set[int] | None = None,
    ) -> tuple[list[tuple[str, str, str]], set[int]]:
        """Return the full flat thread context (parent + replies) and the included ids."""
        exclude_message_ids = exclude_message_ids or set()
        parent = self.get_message_by_id(parent_message_id)
        if parent is None:
            return [], set()

        rows = [parent] + self.list_thread_messages(parent_message_id)
        filtered = [row for row in rows if row.id not in exclude_message_ids]
        all_thread_ids = {row.id for row in rows}
        messages = [(row.role, row.content, row.timestamp) for row in filtered]
        return messages, all_thread_ids

    def _row_to_message(self, row: sqlite3.Row) -> ConversationMessage:
        raw_metadata = row["metadata"]
        if isinstance(raw_metadata, bytes):
            raw_metadata = raw_metadata.decode()
        metadata = json.loads(raw_metadata) if raw_metadata else {}
        col_names = row.keys()
        parent_message_id = row["parent_message_id"] if "parent_message_id" in col_names else None
        thread_reply_count = row["thread_reply_count"] if "thread_reply_count" in col_names else 0
        agent_name = row["agent_name"] if "agent_name" in col_names else None
        return ConversationMessage(
            id=row["id"],
            session_id=row["session_id"],
            timestamp=row["timestamp"],
            role=row["role"],
            content=row["content"],
            source=row["source"],
            telegram_chat_id=row["telegram_chat_id"],
            telegram_message_id=row["telegram_message_id"],
            metadata=metadata,
            parent_message_id=parent_message_id,
            thread_reply_count=thread_reply_count,
            agent_name=agent_name,
        )
