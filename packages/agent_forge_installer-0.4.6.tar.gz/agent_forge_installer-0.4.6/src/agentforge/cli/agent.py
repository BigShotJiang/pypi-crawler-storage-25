"""Agent management commands: create, list, remove, link-vault."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from agentforge.config_models import ValidationError, load_legacy_global_config
from agentforge.paths import resolve_git_repos_root, resolve_root, resolve_vault_root
from agentforge.team_docs import ensure_team_claude_guidance, write_system_state_note

SOUL_TEMPLATE = """\
# IDENTITY OVERRIDE
You are {name_cap}. Your name is {name_cap}.

## Identity
- Name: {name_cap}
- Role: (describe this agent's role)

## Personality
- (describe personality traits)

## Language
- Technical English by default
- Switches to French if the user writes in French

## Principles
- (list guiding principles)

## Execution Mode
- Respond directly in the console (the telegram_adapter handles sending to Telegram).
- Never call `telegram_send.sh` for your main reply — that would cause duplicates.
- Use the shared `git-repos/` folder at the AgentForge root for repository clones and collaborative code work.

## Tasks
- Use your dedicated 2Do list for structured tasks.
- Treat any mention of todo, to-do, or task system as the canonical 2Do system.
- If a user asks to update one of your tasks, update that task's 2Do notes body.
- Read `/vault/Agents/{name}/memory.md` and the current 2Do task notes for durable context.

## Memory
- Read `/vault/Agents/{name}/memory.md` at the start of each session
- Write daily learnings to `/vault/Agents/{name}/daily/YYYY-MM-DD.md`
"""


def _resolve_root() -> Path:
    return resolve_root()


def _load_config(config_path: str | None = None) -> tuple[dict, Path]:
    """Load config.json and return (data, path)."""
    if config_path:
        p = Path(config_path)
    else:
        p = _resolve_root() / "bot" / "config.json"
    if not p.exists():
        print(f"Error: config not found at {p}")
        sys.exit(1)
    try:
        return load_legacy_global_config(p).model_dump(), p
    except ValidationError as exc:
        print(f"Error: invalid config at {p}: {exc}")
        sys.exit(1)


def _save_config(data: dict, path: Path) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def agent_create(
    name: str,
    *,
    backend: str = "claude",
    model: str = "sonnet",
    thread_id: int | None = None,
    config_path: str | None = None,
) -> None:
    """Create a new agent: scaffold files + update config.json."""
    name = name.lower().strip()
    if not name.isalpha():
        print(f"Error: agent name must be alphabetic, got '{name}'")
        sys.exit(1)

    root = _resolve_root()
    agent_dir = root / "agents" / name
    vault_agent_dir = resolve_vault_root(root) / "Agents" / name
    shared_git_repos_dir = resolve_git_repos_root(root)
    shared_git_repos_dir.mkdir(parents=True, exist_ok=True)

    # 1. Create agent directory structure
    if agent_dir.exists():
        print(f"Warning: agent directory already exists at {agent_dir}")
    else:
        agent_dir.mkdir(parents=True, exist_ok=True)
        (agent_dir / "plans").mkdir(exist_ok=True)
        vault_agent_dir.mkdir(parents=True, exist_ok=True)
        (vault_agent_dir / "daily").mkdir(exist_ok=True)
        (vault_agent_dir / "events").mkdir(exist_ok=True)

        # soul.md
        soul = SOUL_TEMPLATE.format(name=name, name_cap=name.capitalize())
        (vault_agent_dir / "soul.md").write_text(soul)

        # memory.md
        (vault_agent_dir / "memory.md").write_text(
            f"# Mémoire de {name.capitalize()}\n\n"
            "Faits et apprentissages accumulés au fil du temps.\n"
            "Mettre à jour seulement avec des faits durables; les tâches vivent dans 2Do.\n"
            "Les consolidations mémoire récurrentes doivent être modélisées comme tâches 2Do de l'architecte, pas comme crons séparés.\n\n"
            "---\n"
        )

        print(f"✅ Created agent files at {agent_dir}/ and {vault_agent_dir}/")

    # 2. Update config.json if thread_id provided
    if thread_id is not None:
        config, config_path_resolved = _load_config(config_path)
        tid_str = str(thread_id)

        if tid_str in config.get("threads", {}):
            existing = config["threads"][tid_str].get("name", "unknown")
            print(f"Warning: thread {thread_id} already assigned to '{existing}'. Overwriting.")

        config.setdefault("threads", {})[tid_str] = {
            "name": name,
            "backend": backend,
            "model": model,
        }

        # Also add to telegram.topics for convenience
        config.setdefault("telegram", {}).setdefault("topics", {})[name] = thread_id

        _save_config(config, config_path_resolved)
        print(f"✅ Added thread {thread_id} → '{name}' (backend={backend}, model={model}) to config.json")
        write_system_state_note(root=root, config_path=str(config_path_resolved))
    else:
        print(f"ℹ️  No --thread-id provided. Add manually to config.json when ready.")

    print(f"\nNext steps:")
    print(f"  1. Edit {vault_agent_dir}/soul.md to define the agent's personality")
    print(f"  2. Use {shared_git_repos_dir}/ for repositories shared across all agents")
    print(f"  3. Create a Telegram bot via @BotFather and add its token to .env")
    print(f"  4. Add the bot to your Telegram group")
    if thread_id is None:
        print(f"  5. Run: agentforge agent create {name} --thread-id <ID> to register the thread")


def agent_list(*, config_path: str | None = None) -> None:
    """List all configured agents."""
    config, _ = _load_config(config_path)
    root = _resolve_root()

    threads = config.get("threads", {})
    agents = []
    for tid, tcfg in threads.items():
        if tid == "default":
            continue
        name = tcfg.get("name", "unnamed")
        model = tcfg.get("model", "?")
        soul_path = resolve_vault_root(root) / "Agents" / name / "soul.md"
        if not soul_path.exists():
            soul_path = root / "agents" / name / "soul.md"
        has_soul = "✓" if soul_path.exists() else "✗"
        agents.append((tid, name, model, has_soul))

    if not agents:
        print("No agents configured.")
        return

    # Table header
    print(f"{'Thread':>8}  {'Name':<15}  {'Model':<10}  {'Soul'}")
    print(f"{'─' * 8}  {'─' * 15}  {'─' * 10}  {'─' * 4}")
    for tid, name, model, has_soul in sorted(agents, key=lambda x: x[1]):
        print(f"{tid:>8}  {name:<15}  {model:<10}  {has_soul}")


def agent_remove(
    name: str,
    *,
    keep_files: bool = False,
    config_path: str | None = None,
) -> None:
    """Remove an agent from config and optionally delete its files."""
    name = name.lower().strip()
    config, config_path_resolved = _load_config(config_path)

    # Remove from threads
    threads = config.get("threads", {})
    removed_tid = None
    for tid, tcfg in list(threads.items()):
        if tcfg.get("name") == name:
            del threads[tid]
            removed_tid = tid
            break

    # Remove from topics
    topics = config.get("telegram", {}).get("topics", {})
    if name in topics:
        del topics[name]

    # Remove from project_topics agents lists
    for pt_cfg in config.get("project_topics", {}).values():
        agents_list = pt_cfg.get("agents", [])
        if name in agents_list:
            agents_list.remove(name)

    _save_config(config, config_path_resolved)
    write_system_state_note(root=_resolve_root(), config_path=str(config_path_resolved))

    if removed_tid:
        print(f"✅ Removed '{name}' (thread {removed_tid}) from config.json")
    else:
        print(f"⚠️  Agent '{name}' not found in config threads")

    # Delete files
    if not keep_files:
        root = _resolve_root()
        agent_dir = root / "agents" / name
        if agent_dir.exists():
            import shutil
            shutil.rmtree(agent_dir)
            print(f"✅ Deleted {agent_dir}/")
        else:
            print(f"ℹ️  No agent directory at {agent_dir}")
    else:
        print(f"ℹ️  Agent files kept on disk (--keep-files)")


# Files and directories in an agent dir that belong in the vault (Obsidian-visible)
_VAULT_MD_GLOBS = ("*.md",)
_VAULT_DIRS = ("daily",)


def _relative_symlink_target(src: Path, dst: Path) -> Path:
    """Return a symlink target relative to the source path location."""
    return Path(os.path.relpath(dst, src.parent))


def _plan_vault_link(
    agent_dir: Path,
    vault_agent_dir: Path,
    agent_name: str,
) -> tuple[list[tuple[Path, Path, Path, str]], list[str], list[str]]:
    """Return planned move operations, skipped items, and blocking conflicts."""
    operations: list[tuple[Path, Path, Path, str]] = []
    skipped: list[str] = []
    conflicts: list[str] = []

    for pattern in _VAULT_MD_GLOBS:
        for src in sorted(agent_dir.glob(pattern)):
            if src.is_symlink():
                skipped.append(src.name)
                continue
            dst = vault_agent_dir / src.name
            if dst.exists() or dst.is_symlink():
                conflicts.append(f"{agent_name}: destination already exists: {dst}")
                continue
            rel_target = _relative_symlink_target(src, dst)
            operations.append((src, dst, rel_target, src.name))

    for dir_name in _VAULT_DIRS:
        src_dir = agent_dir / dir_name
        if not src_dir.exists():
            continue
        if src_dir.is_symlink():
            skipped.append(f"{dir_name}/")
            continue
        dst_dir = vault_agent_dir / dir_name
        if dst_dir.exists() or dst_dir.is_symlink():
            conflicts.append(f"{agent_name}: destination already exists: {dst_dir}")
            continue
        rel_target = _relative_symlink_target(src_dir, dst_dir)
        operations.append((src_dir, dst_dir, rel_target, f"{dir_name}/"))

    return operations, skipped, conflicts


def agent_link_vault(
    names: list[str] | None = None,
    *,
    vault_dir: str | None = None,
    dry_run: bool = False,
) -> None:
    """Move agent .md files and daily/ into vault/Agents/<name>/ and symlink back.

    This makes agent identity files (soul.md, memory.md, tasks.md, daily notes)
    visible and editable in Obsidian while keeping AgentForge's path resolution
    unchanged (symlinks are transparent to the bot).

    Safe to re-run: already-linked files are skipped.
    """
    root = _resolve_root()
    vault = Path(vault_dir) if vault_dir else resolve_vault_root(root)

    if not vault.exists():
        print(f"❌ Vault directory not found: {vault}")
        print("   Create it first or pass --vault-dir")
        sys.exit(1)

    agents_root = root / "agents"
    if names:
        agent_names = [n.lower() for n in names]
    else:
        agent_names = sorted(
            d.name for d in agents_root.iterdir()
            if d.is_dir() and not d.name.startswith("_") and d.name != "shared"
        )

    vault_agents_dir = vault / "Agents"
    if not dry_run:
        vault_agents_dir.mkdir(parents=True, exist_ok=True)

    total_planned = 0
    total_skipped = 0
    all_conflicts: list[str] = []
    plans: list[tuple[str, Path, list[tuple[Path, Path, Path, str]], list[str]]] = []

    for agent_name in agent_names:
        agent_dir = agents_root / agent_name
        if not agent_dir.exists():
            print(f"⚠️  agents/{agent_name}/ not found, skipping")
            continue

        vault_agent_dir = vault_agents_dir / agent_name
        planned_ops, skipped, conflicts = _plan_vault_link(
            agent_dir,
            vault_agent_dir,
            agent_name,
        )
        total_planned += len(planned_ops)
        total_skipped += len(skipped)
        all_conflicts.extend(conflicts)
        plans.append((agent_name, vault_agent_dir, planned_ops, skipped))

    if all_conflicts:
        print("❌ link-vault aborted; existing vault content would be overwritten:")
        for conflict in all_conflicts:
            print(f"   - {conflict}")
        print("   Resolve or remove the destination files first, then re-run.")
        sys.exit(1)

    for agent_name, vault_agent_dir, planned_ops, skipped in plans:
        if not dry_run:
            vault_agent_dir.mkdir(parents=True, exist_ok=True)
            for src, dst, rel_target, _label in planned_ops:
                src.rename(dst)
                src.symlink_to(rel_target)

        status = "🔍 (dry-run)" if dry_run else "✅"
        moved = [label for *_rest, label in planned_ops]
        if moved:
            print(f"{status} {agent_name}: moved {', '.join(moved)}")
        if skipped:
            print(f"   {agent_name}: already linked, skipped {', '.join(skipped)}")

    print()
    action = "Would move" if dry_run else "Moved"
    print(f"{action} {total_planned} item(s), skipped {total_skipped} already-linked.")
    if not dry_run and total_planned:
        print(f"Vault path: {vault_agents_dir}/")


def agent_sync_system_state(*, config_path: str | None = None) -> None:
    """Regenerate the shared read-only system state note."""
    root = _resolve_root()
    resolved_config: str | None = None
    if config_path:
        _, config_path_resolved = _load_config(config_path)
        resolved_config = str(config_path_resolved)
    else:
        default_path = root / "bot" / "config.json"
        if default_path.exists():
            resolved_config = str(default_path)
    ensure_team_claude_guidance(root=root)
    dest = write_system_state_note(root=root, config_path=resolved_config)
    print(f"✅ Synced {dest}")
