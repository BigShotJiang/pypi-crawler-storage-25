"""agentforge service — systemd service management."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from agentforge.paths import resolve_root, resolve_runtime_bin_dir, resolve_runtime_root, resolve_runtime_scripts_dir

SERVICE_TEMPLATE = """\
[Unit]
Description=AgentForge Telegram Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory={root}
ExecStart={venv_bin}/agentforge bot
EnvironmentFile={root}/.env
Environment=AGENTFORGE_ROOT={root}
Environment=AGENTFORGE_RUNTIME_ROOT={runtime_root}
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
"""

HEARTBEAT_TIMER_TEMPLATE = """\
[Unit]
Description=AgentForge Heartbeat Timer

[Timer]
OnCalendar=*:0/{interval_minutes}
Persistent=true

[Install]
WantedBy=timers.target
"""

HEARTBEAT_SERVICE_TEMPLATE = """\
[Unit]
Description=AgentForge Heartbeat
After=network-online.target

[Service]
Type=oneshot
WorkingDirectory={root}
ExecStart={scripts}/heartbeat.sh
EnvironmentFile={root}/.env
Environment=AGENTFORGE_ROOT={root}
Environment=AGENTFORGE_RUNTIME_ROOT={runtime_root}
"""

MONITORING_TIMER_TEMPLATE = """\
[Unit]
Description=AgentForge Monitoring Heartbeat Timer

[Timer]
OnCalendar=*:0/{interval_minutes}
Persistent=true

[Install]
WantedBy=timers.target
"""

MONITORING_SERVICE_TEMPLATE = """\
[Unit]
Description=AgentForge Monitoring Heartbeat
After=network-online.target

[Service]
Type=oneshot
WorkingDirectory={root}
ExecStart={scripts}/monitoring_heartbeat.sh
EnvironmentFile={root}/.env
Environment=AGENTFORGE_ROOT={root}
Environment=AGENTFORGE_RUNTIME_ROOT={runtime_root}
"""


def _resolve_root() -> Path:
    return resolve_root()


def _find_venv_bin(root: Path) -> Path:
    """Find the venv bin directory."""
    venv = resolve_runtime_bin_dir(root)
    if venv.exists():
        return venv
    # Check if we're in a venv right now
    if os.environ.get("VIRTUAL_ENV"):
        return Path(os.environ["VIRTUAL_ENV"]) / "bin"
    return venv  # default even if doesn't exist yet


def _write_heartbeat_units(
    root: Path,
    scripts_dir: Path,
    service_dir: Path,
    name: str,
    interval_minutes: int,
) -> None:
    """Write only the heartbeat service and timer unit files."""
    runtime_root = resolve_runtime_root(root)

    hb_service = service_dir / f"{name}-heartbeat.service"
    hb_timer = service_dir / f"{name}-heartbeat.timer"

    hb_service.write_text(HEARTBEAT_SERVICE_TEMPLATE.format(
        root=root,
        scripts=scripts_dir,
        runtime_root=runtime_root,
    ))
    hb_timer.write_text(HEARTBEAT_TIMER_TEMPLATE.format(
        interval_minutes=interval_minutes,
    ))
    print(f"  Created {hb_service}")
    print(f"  Created {hb_timer}")


def _ensure_runtime_script(root: Path, scripts_dir: Path, script_name: str, *, hint: str) -> Path:
    script = scripts_dir / script_name
    if script.exists():
        return script

    from agentforge.cli.init import sync_scripts

    print(f"  {script_name} not found — syncing scripts from package...")
    sync_scripts(root)
    if script.exists():
        return script

    print(f"✗ {script_name} missing at {script}")
    print(f"  {hint}")
    sys.exit(1)


def service_generate(
    *,
    name: str = "agentforge",
    heartbeat: bool = True,
    heartbeat_interval: int = 10,
    monitoring: bool = True,
    monitoring_interval: int = 5,
    _home: Path | None = None,
) -> None:
    """Generate systemd user service files."""
    root = _resolve_root()
    home = _home or Path.home()
    service_dir = home / ".config" / "systemd" / "user"
    service_dir.mkdir(parents=True, exist_ok=True)

    runtime_root = resolve_runtime_root(root)
    venv_bin = _find_venv_bin(root)
    scripts_dir = resolve_runtime_scripts_dir(root)

    # Main bot service
    service_file = service_dir / f"{name}.service"
    service_file.write_text(SERVICE_TEMPLATE.format(
        root=root,
        venv_bin=venv_bin,
        runtime_root=runtime_root,
    ))
    print(f"  Created {service_file}")

    # Heartbeat timer + service
    if heartbeat:
        _ensure_runtime_script(
            root,
            scripts_dir,
            "heartbeat.sh",
            hint="Run `agentforge service migrate-heartbeat` or `agentforge update apply` first.",
        )
        _write_heartbeat_units(root, scripts_dir, service_dir, name, heartbeat_interval)

    if monitoring:
        _ensure_runtime_script(
            root,
            scripts_dir,
            "monitoring_heartbeat.sh",
            hint="Run `agentforge update apply` first.",
        )
        monitor_service = service_dir / f"{name}-monitoring.service"
        monitor_timer = service_dir / f"{name}-monitoring.timer"
        monitor_service.write_text(MONITORING_SERVICE_TEMPLATE.format(
            root=root,
            scripts=scripts_dir,
            runtime_root=runtime_root,
        ))
        monitor_timer.write_text(MONITORING_TIMER_TEMPLATE.format(
            interval_minutes=monitoring_interval,
        ))
        print(f"  Created {monitor_service}")
        print(f"  Created {monitor_timer}")

    print()
    print("Enable and start with:")
    print(f"  systemctl --user daemon-reload")
    print(f"  systemctl --user enable --now {name}")
    if heartbeat:
        print(f"  systemctl --user enable --now {name}-heartbeat.timer")
    if monitoring:
        print(f"  systemctl --user enable --now {name}-monitoring.timer")
    print()
    print("View logs:")
    print(f"  journalctl --user -u {name} -f")


def service_migrate_heartbeat(
    *,
    name: str = "agentforge",
    interval_minutes: int = 5,
    _home: Path | None = None,
) -> None:
    """Sync packaged scripts, generate heartbeat timer units, enable and verify the timer.

    Prints safe crontab removal instructions only after the timer is confirmed active.
    Default interval is 5 minutes to match the existing crontab schedule.
    """
    from agentforge.cli.init import sync_scripts

    root = _resolve_root()
    scripts_dir = resolve_runtime_scripts_dir(root)
    heartbeat_script = scripts_dir / "heartbeat.sh"

    # Step 1: Deploy package scripts to runtime/scripts/ (idempotent)
    print("Syncing packaged scripts to runtime/scripts/...")
    sync_scripts(root)

    if not heartbeat_script.exists():
        print(f"✗ heartbeat.sh still missing at {heartbeat_script}")
        print("  Check that the agentforge package is correctly installed.")
        sys.exit(1)

    print(f"✓ Heartbeat script: {heartbeat_script}")

    # Step 2: Write only the heartbeat unit files (does NOT touch agentforge.service)
    home = _home or Path.home()
    service_dir = home / ".config" / "systemd" / "user"
    service_dir.mkdir(parents=True, exist_ok=True)

    print("\nGenerating heartbeat unit files...")
    _write_heartbeat_units(root, scripts_dir, service_dir, name, interval_minutes)

    # Step 3: Enable and start the timer
    print(f"\nEnabling {name}-heartbeat.timer...")
    try:
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            check=True, capture_output=True,
        )
        subprocess.run(
            ["systemctl", "--user", "enable", "--now", f"{name}-heartbeat.timer"],
            check=True, capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.decode(errors="replace") if exc.stderr else ""
        print(f"✗ systemctl failed: {stderr or exc}")
        sys.exit(1)
    except FileNotFoundError:
        print("✗ systemctl not found — systemd is not available on this system.")
        sys.exit(1)

    # Step 4: Verify the timer is actually active before printing removal instructions
    result = subprocess.run(
        ["systemctl", "--user", "is-active", f"{name}-heartbeat.timer"],
        capture_output=True, text=True, check=False,
    )
    timer_state = result.stdout.strip()

    if timer_state != "active":
        print(f"✗ Timer does not appear to be active (state: {timer_state!r})")
        print(f"  Investigate with: journalctl --user -u {name}-heartbeat.timer")
        sys.exit(1)

    print(f"✓ Timer is active")

    # Step 5: Print safe crontab removal instructions now that timer is confirmed running
    print()
    print("── Heartbeat timer migration complete ────────────────────────────────")
    print()
    print("The systemd heartbeat timer is now running every "
          f"{interval_minutes} minute(s).")
    print()
    print("Safe crontab removal steps:")
    print(f"  1. Confirm the timer has fired at least once:")
    print(f"       journalctl --user -u {name}-heartbeat.timer --since '10 minutes ago'")
    print(f"       systemctl --user list-timers {name}-heartbeat.timer")
    print()
    print("  2. Only after observing a successful firing, remove the old crontab entry:")
    print("       crontab -e   # as the agentforge user")
    print("       Delete the line containing: heartbeat.sh")
    print()
    print("⚠ Do NOT remove the crontab entry until the timer has been observed firing.")


def service_status(*, name: str = "agentforge") -> None:
    """Show service status."""
    try:
        result = subprocess.run(
            ["systemctl", "--user", "status", f"{name}.service"],
            capture_output=True, text=True,
        )
        print(result.stdout)
        if result.stderr:
            print(result.stderr)
    except FileNotFoundError:
        print("systemctl not found — systemd is not available on this system.")
        sys.exit(1)


def service_logs(*, name: str = "agentforge", lines: int = 50) -> None:
    """Show recent service logs."""
    try:
        subprocess.run(
            ["journalctl", "--user", "-u", f"{name}.service",
             "-n", str(lines), "--no-pager"],
        )
    except FileNotFoundError:
        print("journalctl not found — systemd is not available on this system.")
        sys.exit(1)
