"""Pydantic config schemas and loaders."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, ValidationError


class _PermissiveModel(BaseModel):
    model_config = ConfigDict(extra="allow")


class ModelTargetConfig(_PermissiveModel):
    backend: str = ""
    model: str = ""


class TelegramRuntimeConfig(_PermissiveModel):
    token_env_var: str = "AGENTFORGE_TELEGRAM_TOKEN"
    allowed_chat_ids: list[str] = Field(default_factory=list)
    private_chat_id: str = ""
    poll_interval_seconds: int = 2
    max_message_length: int = 4096
    group_chat_id: str = ""
    bot_username: str = ""
    topics: dict[str, int] = Field(default_factory=dict)
    monitor_threads: list[int] = Field(
        default_factory=list,
        description=(
            "Thread IDs to passively monitor. Agent receives messages from these "
            "threads and decides whether to react (👍) or respond."
        ),
    )


class ClaudeRuntimeConfig(_PermissiveModel):
    backend: str = ""
    model: str = "sonnet"
    models: list[ModelTargetConfig] = Field(default_factory=list)
    max_budget_usd: float = 5.0
    monthly_budget_usd: float = 20.0
    working_directory: str = ""


class ContextRuntimeConfig(_PermissiveModel):
    messages: int = 20
    hours: int = 24


class EventSourceRuntimeConfig(_PermissiveModel):
    enabled: bool = True
    source: str = ""
    event_type: str = ""
    prompt_ref: str = ""
    label: str = ""
    repo: str = ""
    mailbox: str = ""
    query: str = ""
    poll_interval_minutes: int = 5


class EventsRuntimeConfig(_PermissiveModel):
    db_path: str = "data/events.db"
    sources: list[EventSourceRuntimeConfig] = Field(default_factory=list)


class AgentRuntimeConfig(_PermissiveModel):
    name: str = ""
    telegram: TelegramRuntimeConfig = Field(default_factory=TelegramRuntimeConfig)
    claude: ClaudeRuntimeConfig = Field(default_factory=ClaudeRuntimeConfig)
    context: ContextRuntimeConfig = Field(default_factory=ContextRuntimeConfig)
    events: EventsRuntimeConfig = Field(default_factory=EventsRuntimeConfig)


class CronTaskConfig(_PermissiveModel):
    enabled: bool = True
    model: str = "haiku"
    models: list[ModelTargetConfig] = Field(default_factory=list)
    max_budget_usd: float = 0.5
    label: str = ""
    schedule: str = ""
    interval_minutes: int = 0


class CommandConfig(_PermissiveModel):
    description: str = ""
    visible: bool = True


class LegacyTelegramConfig(_PermissiveModel):
    token: str = ""
    allowed_chat_ids: list[int] = Field(default_factory=list)
    topics: dict[str, int] = Field(default_factory=dict)


class LegacyClaudeConfig(_PermissiveModel):
    backend: str = ""
    model: str = ""
    models: list[ModelTargetConfig] = Field(default_factory=list)
    max_budget_usd: float = 0.5
    monthly_budget_usd: float = 20.0


class LegacyHeartbeatConfig(_PermissiveModel):
    interval_minutes: int = 60
    max_budget_usd: float = 0.1


class LegacyLoggingConfig(_PermissiveModel):
    sheets_id: str = ""


class LegacyAgentForgeConfigModel(_PermissiveModel):
    telegram: LegacyTelegramConfig
    claude: LegacyClaudeConfig
    threads: dict[str, Any] = Field(default_factory=dict)
    heartbeat: LegacyHeartbeatConfig = Field(default_factory=LegacyHeartbeatConfig)
    logging: LegacyLoggingConfig = Field(default_factory=LegacyLoggingConfig)


def _read_json(path: str | Path) -> dict[str, Any]:
    with Path(path).open(encoding="utf-8") as handle:
        return json.load(handle)


def load_agent_runtime_config(path: str | Path) -> AgentRuntimeConfig:
    data = _read_json(path)
    return AgentRuntimeConfig.model_validate(data)


def load_cron_task_config(path: str | Path) -> CronTaskConfig:
    data = _read_json(path)
    return CronTaskConfig.model_validate(data)


def load_command_config(path: str | Path) -> CommandConfig:
    data = _read_json(path)
    return CommandConfig.model_validate(data)


def load_legacy_global_config(path: str | Path) -> LegacyAgentForgeConfigModel:
    data = _read_json(path)
    return LegacyAgentForgeConfigModel.model_validate(data)


__all__ = [
    "AgentRuntimeConfig",
    "CommandConfig",
    "CronTaskConfig",
    "LegacyAgentForgeConfigModel",
    "ModelTargetConfig",
    "ValidationError",
    "load_agent_runtime_config",
    "load_command_config",
    "load_cron_task_config",
    "load_legacy_global_config",
]
