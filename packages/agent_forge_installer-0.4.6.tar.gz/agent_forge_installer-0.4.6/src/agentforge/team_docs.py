"""Helpers for generated shared team docs."""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from agentforge.config_models import ValidationError, load_legacy_global_config
from agentforge.paths import resolve_root, resolve_vault_root


TEAM_CLAUDE_DEFAULT = """# Team Rules

These rules apply to every agent on this instance.

## Communication

- Respond in the same language as the user.
- If a message appears to be Siri dictation with minor errors, infer the intent when the meaning is clear.
- If meaning is ambiguous, state the interpretation briefly and ask for confirmation.

## Collaboration

- Delegate directly via each agent's Telegram bot for 1:1 handoffs; use project topics only for shared multi-agent coordination.
- Do not claim a delegation happened unless the task command was actually executed.
- Keep shared rules here short; move procedures and reference material into `_team/*.md` pages.

## Verification

- For questions about models, routing, recent-context behavior, memory layers, available scripts/tools, or runtime behavior, verify against `vault/Agents/_team/system-state.md`, `ARCHITECTURE.md`, or live code/config before answering.
- If docs and code disagree, say so explicitly and prefer the live code/config.
- Do not present legacy per-agent `context.messages` values as current interactive runtime truth unless you verified the code path.

## Memory Discipline

- Keep injected memory files compact and durable.
- Daily notes are for consolidation input, not default prompt context.
- Move large shared procedures into handbook pages and retrieve them when needed.
"""

TEAM_CLAUDE_VERIFICATION_LINES = [
    "- For questions about models, routing, recent-context behavior, memory layers, available scripts/tools, or runtime behavior, verify against `vault/Agents/_team/system-state.md`, `ARCHITECTURE.md`, or live code/config before answering.",
    "- If docs and code disagree, say so explicitly and prefer the live code/config.",
    "- Do not present legacy per-agent `context.messages` values as current interactive runtime truth unless you verified the code path.",
]


def _resolve_root(root: str | Path | None = None) -> Path:
    return resolve_root(root)


def _resolve_config_path(root: Path, config_path: str | None = None) -> Path:
    if config_path:
        return Path(config_path)
    return root / "bot" / "config.json"


def _load_global_config(root: Path, config_path: str | None = None) -> dict[str, Any]:
    path = _resolve_config_path(root, config_path)
    if not path.exists():
        return {}
    try:
        return load_legacy_global_config(path).model_dump()
    except ValidationError:
        return json.loads(path.read_text(encoding="utf-8"))


def _load_agent_runtime_config(agent_dir: Path) -> dict[str, Any]:
    config_path = agent_dir / "config.json"
    if not config_path.exists():
        return {}
    try:
        return json.loads(config_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def _extract_model_chain(source: dict[str, Any], *, default_model: str = "") -> list[str]:
    raw_models = source.get("models")
    if isinstance(raw_models, list) and raw_models:
        chain: list[str] = []
        for item in raw_models:
            if not isinstance(item, dict):
                continue
            backend = str(item.get("backend") or "claude")
            model = str(item.get("model") or default_model or "?")
            chain.append(f"{backend}/{model}")
        if chain:
            return chain
    raw_model = str(source.get("model") or default_model or "")
    if raw_model:
        backend = str(source.get("backend") or "claude")
        return [f"{backend}/{raw_model}"]
    return []


def _format_model_chain(chain: list[str]) -> str:
    return " -> ".join(chain) if chain else "?"


def _discover_agents(root: Path, config: dict[str, Any]) -> list[dict[str, Any]]:
    agents: dict[str, dict[str, Any]] = {}

    for thread_id, thread_cfg in config.get("threads", {}).items():
        if thread_id == "default":
            continue
        name = str(thread_cfg.get("name") or "").strip().lower()
        if not name:
            continue
        agent = agents.setdefault(name, {"name": name, "thread_ids": []})
        agent["thread_ids"].append(str(thread_id))
        thread_chain = _extract_model_chain(thread_cfg, default_model="sonnet")
        if thread_chain:
            agent["thread_models"] = thread_chain
        agent["thread_context_messages"] = thread_cfg.get("context", {}).get("messages")
        agent["thread_context_hours"] = thread_cfg.get("context", {}).get("hours")
        agent["thread_context_hours_legacy"] = thread_cfg.get("context_hours")

    agents_dir = root / "agents"
    if agents_dir.exists():
        for agent_dir in agents_dir.iterdir():
            if not agent_dir.is_dir() or agent_dir.name.startswith("_") or agent_dir.name == "shared":
                continue
            name = agent_dir.name.lower()
            agent = agents.setdefault(name, {"name": name, "thread_ids": []})
            runtime_cfg = _load_agent_runtime_config(agent_dir)
            claude_cfg = runtime_cfg.get("claude", {})
            context_cfg = runtime_cfg.get("context", {})
            telegram_cfg = runtime_cfg.get("telegram", {})
            runtime_chain = _extract_model_chain(claude_cfg, default_model="sonnet")
            if runtime_chain:
                agent["runtime_models"] = runtime_chain
            if context_cfg:
                agent["runtime_context_messages"] = context_cfg.get("messages")
                agent["runtime_context_hours"] = context_cfg.get("hours")
            topics = telegram_cfg.get("topics", {})
            if topics:
                agent["topic_ids"] = sorted(str(value) for value in topics.values())

    topic_map = config.get("telegram", {}).get("topics", {})
    for name, topic_id in topic_map.items():
        agent = agents.setdefault(str(name).lower(), {"name": str(name).lower(), "thread_ids": []})
        agent.setdefault("topic_ids", [])
        agent["topic_ids"].append(str(topic_id))

    return sorted(agents.values(), key=lambda item: item["name"])


def ensure_team_claude_guidance(*, root: str | Path | None = None, printer=print) -> Path:
    """Ensure the canonical shared team CLAUDE.md exists and includes verification guidance."""
    root_path = _resolve_root(root)
    team_claude = resolve_vault_root(root_path) / "Agents" / "_team" / "CLAUDE.md"
    team_claude.parent.mkdir(parents=True, exist_ok=True)

    if not team_claude.exists():
        team_claude.write_text(TEAM_CLAUDE_DEFAULT, encoding="utf-8")
        printer("  wrote vault/Agents/_team/CLAUDE.md")
        return team_claude

    existing = team_claude.read_text(encoding="utf-8")
    missing_lines = [line for line in TEAM_CLAUDE_VERIFICATION_LINES if line not in existing]
    if not missing_lines:
        return team_claude

    appendix = [
        "",
        "## Verification",
        "",
        *missing_lines,
        "",
    ]
    team_claude.write_text(existing.rstrip() + "\n" + "\n".join(appendix), encoding="utf-8")
    printer("  updated vault/Agents/_team/CLAUDE.md")
    return team_claude


def render_system_state_markdown(
    *,
    root: str | Path | None = None,
    config_path: str | None = None,
    now: datetime | None = None,
) -> str:
    """Render the generated shared system state note."""
    root_path = _resolve_root(root)
    config = _load_global_config(root_path, config_path)
    generated_at = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    agents = _discover_agents(root_path, config)

    lines: list[str] = [
        "# System State",
        "",
        "_Generated from live config and code-oriented defaults. Read-only; regenerate instead of editing manually._",
        "",
        f"- Generated at: `{generated_at.strftime('%Y-%m-%d %H:%M:%SZ')}`",
        f"- Root: `{root_path}`",
        "",
        "## Verification Rules",
        "",
        "- For questions about models, routing, recent-context behavior, memory layers, available tools/scripts, or runtime behavior, verify against this note and code/config before answering.",
        "- If this note and live code disagree, prefer live code/config and say that explicitly.",
        "",
        "## Runtime Facts",
        "",
        "- Interactive/API recent conversation context is dynamic: last 4 hours, capped at 20 messages, with backfill to 3 messages when the 4-hour window is sparse.",
        "- That dynamic selector is currently hardcoded in the interactive/API path; do not treat legacy per-agent `context.messages` values as the current runtime truth unless code changed.",
        "- Shared injected team guidance lives in `vault/Agents/_team/CLAUDE.md`.",
        "- Shared injected team memory lives in `vault/Agents/_team/memory.md`.",
        "- Reference pages under `vault/Agents/_team/*.md` are handbook material, not automatically injected memory unless code explicitly loads them.",
        "",
        "## Known Agents",
        "",
        "| Agent | Models | Topics/threads | Per-agent config context | Notes |",
        "|---|---|---|---|---|",
    ]

    if not agents:
        lines.append("| _(none discovered)_ | - | - | - | No agents discovered from config or `agents/` directory. |")
    else:
        for agent in agents:
            model = _format_model_chain(agent.get("runtime_models") or agent.get("thread_models") or [])
            route_ids = sorted(set(agent.get("topic_ids", []) + agent.get("thread_ids", [])))
            route_label = ", ".join(route_ids) if route_ids else "-"

            runtime_messages = agent.get("runtime_context_messages")
            runtime_hours = agent.get("runtime_context_hours")
            if runtime_messages is not None or runtime_hours is not None:
                context_label = f"`messages={runtime_messages if runtime_messages is not None else '?'}; hours={runtime_hours if runtime_hours is not None else '?'}`"
            else:
                context_label = "-"

            notes: list[str] = []
            if agent.get("runtime_context_messages") is not None or agent.get("runtime_context_hours") is not None:
                notes.append("per-agent config present")
            if agent.get("thread_context_hours_legacy") is not None:
                notes.append(f"legacy thread `context_hours={agent['thread_context_hours_legacy']}`")
            if not notes:
                notes.append("runtime uses shared dynamic interactive context")

            lines.append(
                f"| `{agent['name']}` | `{model}` | `{route_label}` | {context_label} | {'; '.join(notes)} |"
            )

    lines.extend(
        [
            "",
            "## Regeneration",
            "",
            "- Run `agentforge agent sync-system-state` after config or architecture changes that agents should be aware of.",
        ]
    )
    return "\n".join(lines) + "\n"


def write_system_state_note(
    *,
    root: str | Path | None = None,
    config_path: str | None = None,
    printer=print,
) -> Path:
    """Write `vault/Agents/_team/system-state.md` and return its path."""
    root_path = _resolve_root(root)
    dest = resolve_vault_root(root_path) / "Agents" / "_team" / "system-state.md"
    dest.parent.mkdir(parents=True, exist_ok=True)
    content = render_system_state_markdown(root=root_path, config_path=config_path)
    existing = dest.read_text(encoding="utf-8") if dest.exists() else None
    if existing != content:
        dest.write_text(content, encoding="utf-8")
        printer("  wrote vault/Agents/_team/system-state.md")
    else:
        printer("  kept vault/Agents/_team/system-state.md (unchanged)")
    return dest
