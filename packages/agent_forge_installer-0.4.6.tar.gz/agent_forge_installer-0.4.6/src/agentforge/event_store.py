"""SQLite-backed event store for event-driven agent triggers."""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class EventRecord:
    event_id: str
    agent: str
    source: str
    event_type: str
    status: str
    external_key: str
    prompt_ref: str
    payload: dict[str, Any]
    created_at: str
    updated_at: str
    processed_at: str | None = None
    failure_count: int = 0
    retry_after: str | None = None
    last_error: str = ""


def initialize_event_store(db_path: str | Path) -> None:
    """Create the event store database and schema if missing."""
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    try:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS events (
                event_id TEXT PRIMARY KEY,
                agent TEXT NOT NULL,
                source TEXT NOT NULL,
                event_type TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'open',
                external_key TEXT NOT NULL,
                prompt_ref TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                processed_at TEXT,
                failure_count INTEGER NOT NULL DEFAULT 0,
                retry_after TEXT,
                last_error TEXT NOT NULL DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS idx_events_agent_status_created
                ON events(agent, status, created_at);
            CREATE INDEX IF NOT EXISTS idx_events_source_type_status
                ON events(source, event_type, status);
            """
        )
        conn.commit()
    finally:
        conn.close()


class EventStore:
    """Minimal event persistence for polling and execution workers."""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        initialize_event_store(self.db_path)

    def create_event(
        self,
        *,
        event_id: str,
        agent: str,
        source: str,
        event_type: str,
        external_key: str,
        prompt_ref: str,
        payload: dict[str, Any],
        created_at: str,
    ) -> None:
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO events (
                    event_id,
                    agent,
                    source,
                    event_type,
                    status,
                    external_key,
                    prompt_ref,
                    payload_json,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, 'open', ?, ?, ?, ?, ?)
                """,
                (
                    event_id,
                    agent,
                    source,
                    event_type,
                    external_key,
                    prompt_ref,
                    json.dumps(payload, ensure_ascii=False, sort_keys=True),
                    created_at,
                    created_at,
                ),
            )
            conn.commit()

    def list_open_events(self, agent: str, *, limit: int = 10) -> list[EventRecord]:
        with sqlite3.connect(str(self.db_path)) as conn:
            rows = conn.execute(
                """
                SELECT
                    event_id,
                    agent,
                    source,
                    event_type,
                    status,
                    external_key,
                    prompt_ref,
                    payload_json,
                    created_at,
                    updated_at,
                    processed_at,
                    failure_count,
                    retry_after,
                    last_error
                FROM events
                WHERE agent = ? AND status = 'open'
                ORDER BY created_at ASC
                LIMIT ?
                """,
                (agent, limit),
            ).fetchall()
        return [
            EventRecord(
                event_id=row[0],
                agent=row[1],
                source=row[2],
                event_type=row[3],
                status=row[4],
                external_key=row[5],
                prompt_ref=row[6],
                payload=json.loads(row[7]),
                created_at=row[8],
                updated_at=row[9],
                processed_at=row[10],
                failure_count=int(row[11]),
                retry_after=row[12],
                last_error=row[13],
            )
            for row in rows
        ]

    def mark_processed(self, event_id: str, *, processed_at: str) -> None:
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.execute(
                """
                UPDATE events
                SET status = 'processed',
                    processed_at = ?,
                    updated_at = ?
                WHERE event_id = ?
                """,
                (processed_at, processed_at, event_id),
            )
            conn.commit()


__all__ = ["EventRecord", "EventStore", "initialize_event_store"]
