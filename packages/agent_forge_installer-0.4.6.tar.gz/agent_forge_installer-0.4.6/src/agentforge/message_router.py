"""Message routing — thread config resolution, @mention parsing, project topics."""

from __future__ import annotations

import re
from typing import Any


def _default_models(config: dict) -> list[dict]:
    claude_cfg = config.get("claude", {})
    return claude_cfg.get("models") or [{
        "backend": claude_cfg.get("backend", ""),
        "model": claude_cfg.get("model", "sonnet"),
    }]


def _with_primary_model_fields(cfg: dict, config: dict) -> dict:
    result = dict(cfg)
    models = result.get("models")
    if not models:
        models = _default_models(config)
        result["models"] = models
    if models:
        primary = models[0]
        if isinstance(primary, dict):
            result.setdefault("backend", primary.get("backend", ""))
            result.setdefault("model", primary.get("model", "sonnet"))
    return result


def get_thread_config(thread_id: int | None, config: dict) -> dict:
    """Return model/config for a given thread_id."""
    threads = config.get("threads", {})
    if thread_id and str(thread_id) in threads:
        return _with_primary_model_fields(threads[str(thread_id)], config)
    default = threads.get("default", {})
    result = {
        "models": default.get("models", _default_models(config)),
    }
    # Preserve fields like 'name', 'soul_file', 'context_hours' from the default
    for key in ("name", "soul_file", "context_hours"):
        if key in default:
            result[key] = default[key]
    return _with_primary_model_fields(result, config)


def get_project_topic_config(thread_id: int | None, config: dict) -> dict | None:
    """Return project topic config if this thread_id is a project topic, else None."""
    if thread_id is None:
        return None
    return config.get("project_topics", {}).get(str(thread_id))


def get_agent_thread_config(agent_name: str, config: dict) -> dict:
    """Find the thread config dict for a given agent name."""
    for tid, tcfg in config.get("threads", {}).items():
        if tid == "default":
            continue
        if tcfg.get("name") == agent_name:
            return _with_primary_model_fields(tcfg, config)
    # Fallback: build config from defaults
    default = config.get("threads", {}).get("default", {})
    return _with_primary_model_fields({
        "name": agent_name,
        "models": default.get("models", _default_models(config)),
    }, config)


def parse_mention(text: str, project_cfg: dict) -> tuple[str, str]:
    """
    Parse @agentname mention from message text.
    Returns (resolved_agent_name, cleaned_text).
    Falls back to project default_agent if no match found.
    """
    allowed = project_cfg.get("agents", [])
    allowed_lower = [a.lower() for a in allowed]
    default = project_cfg.get("default_agent", "clawdia")

    match = re.search(r"@(\w+)", text)
    if match:
        mentioned = match.group(1).lower()
        # Exact match first (e.g. @victor)
        if mentioned in allowed_lower:
            agent_name = next(a for a in allowed if a.lower() == mentioned)
            cleaned = re.sub(r"@" + re.escape(match.group(1)) + r"\s*", "", text).strip()
            return agent_name, cleaned or text
        # Prefix match: @VictorClawdiaBot → victor (Telegram bot username)
        for agent in allowed:
            if mentioned.startswith(agent.lower()):
                cleaned = re.sub(r"@" + re.escape(match.group(1)) + r"\s*", "", text).strip()
                return agent, cleaned or text
    return default, text


def build_topic_context(project_cfg: dict, target_agent: str) -> str:
    """Build the topic context string injected into the prompt."""
    topic_label = project_cfg.get("label", project_cfg.get("name", ""))
    other_agents = [a for a in project_cfg.get("agents", []) if a != target_agent]
    others_str = ", ".join(f"@{a}" for a in other_agents)
    return (
        f"Tu réponds dans le topic projet **{topic_label}**. "
        f"D'autres agents participent aussi à ce topic : {others_str}. "
        f"Martin peut mentionner un agent spécifique avec @nom pour lui adresser un message directement."
    )
