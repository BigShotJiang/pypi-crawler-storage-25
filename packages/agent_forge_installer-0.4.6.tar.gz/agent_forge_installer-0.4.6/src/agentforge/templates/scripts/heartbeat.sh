#!/usr/bin/env bash
# heartbeat.sh — Dynamic multi-agent cron runner
# Discovers agents from agents/*/ and runs their scheduled cron tasks.
# Called by the heartbeat timer every 10 minutes.
# The only supported per-agent cron is heartbeat; work selection comes from 2Do.
set -euo pipefail
export TZ=America/Montreal

AGENTFORGE_ROOT="${AGENTFORGE_ROOT:?AGENTFORGE_ROOT is not set}"
LOG="$AGENTFORGE_ROOT/logs/heartbeat.log"
TODAY=$(date +%Y-%m-%d)
NOW=$(date +%H:%M)

# Global heartbeat interval — all agents share this value.
# Per-agent interval_minutes in cron/heartbeat/config.json is ignored.
HEARTBEAT_INTERVAL_MINUTES=10

mkdir -p "$AGENTFORGE_ROOT/logs"
echo "[$TODAY $NOW] === Heartbeat starting ===" >> "$LOG"

# Source environment
[ -f "$AGENTFORGE_ROOT/.env" ] && set -a && source "$AGENTFORGE_ROOT/.env" && set +a

PYTHON_BIN="$AGENTFORGE_RUNTIME_ROOT/.venv/bin/python3"
[ -x "$PYTHON_BIN" ] || PYTHON_BIN="python3"

# ---------------------------------------------------------------------------
# Helper: build prompt stack and invoke claude for a cron task
# ---------------------------------------------------------------------------
run_cron_task() {
    local agent_dir="$1"
    local task_md="$2"
    local model="${3:-haiku}"
    local max_budget="${4:-0.5}"
    local agent_name
    agent_name=$(basename "$agent_dir")
    local agent_vault_dir="$AGENTFORGE_ROOT/vault/Agents/$agent_name"
    local soul_file="$agent_vault_dir/soul.md"
    local memory_file="$agent_vault_dir/memory.md"
    local daily_dir="$agent_vault_dir/daily"
    [ -f "$soul_file" ] || { [ -f "$agent_dir/soul.md" ] && soul_file="$agent_dir/soul.md"; }
    [ -f "$memory_file" ] || { [ -f "$agent_dir/memory.md" ] && memory_file="$agent_dir/memory.md"; }
    [ -d "$daily_dir" ] || { [ -d "$agent_dir/daily" ] && daily_dir="$agent_dir/daily"; }

    mkdir -p "$agent_dir/logs" "$daily_dir"

    local log_file="$agent_dir/logs/cron.log"

    # Derive config_file from task_md location
    local config_file
    config_file="$(dirname "$task_md")/config.json"

    local task_prompt=""
    [ -f "$task_md" ] && task_prompt+=$'## TÂCHE À EXÉCUTER\n\n'"$(cat "$task_md")"$'\n\n**Exécute immédiatement et complètement les instructions ci-dessus. Ne réponds pas de manière conversationnelle. Ne demande pas de confirmation. Effectue toutes les étapes.**'

    local cron_name
    cron_name=$(basename "$(dirname "$task_md")")

    # Inject at most one structured 2Do task into the heartbeat cron.
    # The wrapper owns state transitions based on TASK_DONE / TASK_SKIP / TASK_FAIL.
    if [ "$cron_name" = "heartbeat" ]; then
        local heartbeat_tasks
        heartbeat_tasks=$("$PYTHON_BIN" -m agentforge.todo_cli due \
            --root "$AGENTFORGE_ROOT" --agent "$agent_name" \
            --format heartbeat --limit 1 2>/dev/null || true)
        if [ -n "$heartbeat_tasks" ]; then
            task_prompt+=$'\n\n'"$heartbeat_tasks"
        fi
    fi

    # Inject agent env vars
    export AGENT_NAME="$agent_name"
    export AGENT_DIR="$agent_dir"
    export HOME="$AGENTFORGE_RUNTIME_ROOT"

    echo "[$TODAY $NOW] Running cron $cron_name for $agent_name (model=$model)" >> "$log_file"

    local response
    local prompt_file
    prompt_file=$(mktemp)
    printf "%s" "$task_prompt" > "$prompt_file"
    response=$("$PYTHON_BIN" -m agentforge.cron_runner \
        --root "$AGENTFORGE_ROOT" \
        --agent-name "$agent_name" \
        --config "$config_file" \
        --prompt-file "$prompt_file" 2>&1) || true
    rm -f "$prompt_file"

    echo "[$TODAY $NOW] Response: ${response:0:500}" >> "$log_file"
    echo "---" >> "$log_file"

    # Check for Claude quota exhaustion — auto-defer injected task instead of silently failing.
    # Symptom: response contains the quota-hit message instead of task signals.
    if echo "$response" | grep -qi "you.ve hit your limit\|usage limit exceeded\|upgrade your plan\|claude.ai/upgrade"; then
        echo "[$TODAY $NOW] QUOTA EXHAUSTED: $agent_name/$cron_name — auto-deferring task" >> "$log_file"
        # Defer the injected 2Do task so it retries next heartbeat
        if [ -n "${heartbeat_tasks:-}" ]; then
            _quota_tid=$(printf '%s' "$heartbeat_tasks" | "$PYTHON_BIN" -c "
import re, sys
m = re.search(r'TASK[_ ]([a-f0-9]{16,})', sys.stdin.read())
print(m.group(1) if m else '')
" 2>/dev/null || true)
            if [ -n "$_quota_tid" ]; then
                "$PYTHON_BIN" -m agentforge.todo_cli defer \
                    --root "$AGENTFORGE_ROOT" --task-id "$_quota_tid" 2>>"$log_file" || true
                echo "[$TODAY $NOW] QUOTA_SKIP: deferred $_quota_tid (quota exhausted)" >> "$log_file"
            fi
        fi
        "$AGENTFORGE_RUNTIME_ROOT/scripts/telegram_send.sh" heartbeat \
            "⚠️ Quota Claude épuisée ($agent_name) — tâche différée, réessai au prochain heartbeat" 2>/dev/null || true
        return 0
    fi

    # Write canary output — proof that this cron ran successfully
    local canary_file="$agent_dir/cron/$cron_name/.canary"
    mkdir -p "$(dirname "$canary_file")"
    echo "$(date --iso-8601=seconds) $cron_name OK" >> "$canary_file"

    # Process structured task signals. One heartbeat may execute at most one task.
    while IFS= read -r _hb_line; do
        if [[ "$_hb_line" =~ TASK_DONE[[:space:]]+([a-f0-9]{16,}) ]]; then
            _hb_tid="${BASH_REMATCH[1]}"
            "$PYTHON_BIN" -m agentforge.todo_cli complete \
                --root "$AGENTFORGE_ROOT" --task-id "$_hb_tid" 2>>"$log_file" || true
            echo "[$TODAY $NOW] TASK_DONE: completed $_hb_tid" >> "$log_file"
        elif [[ "$_hb_line" =~ TASK_SKIP[[:space:]]+([a-f0-9]{16,}) ]]; then
            _hb_tid="${BASH_REMATCH[1]}"
            "$PYTHON_BIN" -m agentforge.todo_cli defer \
                --root "$AGENTFORGE_ROOT" --task-id "$_hb_tid" 2>>"$log_file" || true
            echo "[$TODAY $NOW] TASK_SKIP: deferred $_hb_tid" >> "$log_file"
        elif [[ "$_hb_line" =~ TASK_FAIL[[:space:]]+([a-f0-9]{16,}) ]]; then
            _hb_tid="${BASH_REMATCH[1]}"
            _hb_error=$(printf '%s\n' "$response" | sed -n "s/^TASK_ERROR[[:space:]]\\+$_hb_tid[[:space:]]\\+//p" | head -1)
            _hb_fail_json=$("$PYTHON_BIN" -m agentforge.todo_cli fail \
                --root "$AGENTFORGE_ROOT" --task-id "$_hb_tid" --error "$_hb_error" 2>>"$log_file" || true)
            echo "[$TODAY $NOW] TASK_FAIL: recorded failure for $_hb_tid" >> "$log_file"
            if [ -n "$_hb_fail_json" ]; then
                _hb_daily_msg=$(printf '%s' "$_hb_fail_json" | python3 -c '
import json, sys
try:
    d = json.load(sys.stdin)
except Exception:
    print("")
else:
    parts = [
        f"Task failed for @{d.get(\"assignee_id\") or sys.argv[1]}",
        f"Title: {d.get(\"title\",\"\")}",
        f"Task ID: {d.get(\"task_id\",\"\")}",
        f"Failure count: {d.get(\"failure_count\",\"\")}",
        f"Retry after: {d.get(\"retry_after\",\"\")}",
    ]
    err = d.get("last_error")
    if err:
        parts.append(f"Error: {err}")
    esc = d.get("escalation_task_id")
    if d.get("escalated") and esc:
        parts.append(f"Architect task created: {esc}")
    print("\\n".join(parts))
' "$agent_name")
                if [ -n "$_hb_daily_msg" ]; then
                    "$AGENTFORGE_RUNTIME_ROOT/scripts/telegram_send.sh" Daily "$_hb_daily_msg" 2>/dev/null || true
                fi
            fi
        fi
    done <<< "$response"

    # Alert if Claude flagged an issue
    if echo "$response" | grep -q "⚠️ ALERTE:"; then
        local alert_detail
        alert_detail=$(echo "$response" | grep -o "⚠️ ALERTE:.*" | head -1)
        "$AGENTFORGE_RUNTIME_ROOT/scripts/telegram_send.sh" heartbeat "$alert_detail" 2>/dev/null || true
        echo "[$TODAY $NOW] Alert sent: $alert_detail" >> "$log_file"
    fi

    # Delivery confirmation: alert on silent failure if expected
    if [ -f "$config_file" ]; then
        local expects_signal
        expects_signal=$(python3 -c "
import json
try:
    d = json.load(open('$config_file'))
    print(str(d.get('expects_completion_signal', False)).lower())
except: print('false')
" 2>/dev/null || echo "false")
        if [ "$expects_signal" = "true" ]; then
            if ! echo "$response" | grep -qE "TASK_DONE|TASK_SKIP|TASK_FAIL"; then
                local fail_msg="⚠️ Silent failure: $agent_name/$cron_name — no TASK_DONE/TASK_SKIP/TASK_FAIL signal received. Response: ${response:0:300}"
                "$AGENTFORGE_RUNTIME_ROOT/scripts/telegram_send.sh" dev "$fail_msg" 2>/dev/null || true
                echo "[$TODAY $NOW] SILENT FAILURE: no completion signal for $cron_name" >> "$log_file"
            fi
        fi
    fi
}

# ---------------------------------------------------------------------------
# Helper: check if a scheduled cron should run now
# schedule format: "MINUTE HOUR DOM MON DOW" (standard cron)
# Returns 0 (should run) or 1 (skip)
# Uses a .last_run file per agent to avoid duplicate execution within the same minute
# ---------------------------------------------------------------------------
cron_schedule_matches() {
    local cron_dir="$1"
    local agent_name="$2"
    local snapshot_min="${3:-$(date +%Y%m%d%H%M)}"
    local snapshot_iso="${4:-$(date '+%Y-%m-%d %H:%M')}"
    local config_file="$cron_dir/config.json"

    [ -f "$config_file" ] || return 1

    # Check enabled
    local enabled
    enabled=$(python3 -c "
import json, sys
try:
    d = json.load(open('$config_file'))
    print(str(d.get('enabled', True)).lower())
except: print('false')
" 2>/dev/null || echo "false")
    [ "$enabled" = "true" ] || return 1

    # Get schedule
    local schedule
    schedule=$(python3 -c "
import json
try:
    d = json.load(open('$config_file'))
    print(d.get('schedule', ''))
except: print('')
" 2>/dev/null || echo "")
    [ -n "$schedule" ] || return 1

    # Check last run to avoid duplicate execution per agent
    local last_run_file="$cron_dir/.last_run.$agent_name"
    local current_min="$snapshot_min"
    if [ -f "$last_run_file" ] && [ "$(cat "$last_run_file")" = "$current_min" ]; then
        return 1
    fi

    # Check if schedule matches current time
    local matches
    matches=$(python3 - << PYEOF
from datetime import datetime
import sys

schedule = "$schedule"
now = datetime.strptime("$snapshot_iso", "%Y-%m-%d %H:%M")
parts = schedule.split()
if len(parts) != 5:
    print("no")
    sys.exit(0)

def field_match(field, value, max_val=None):
    if field == '*':
        return True
    if field.startswith('*/'):
        step = int(field[2:])
        return value % step == 0
    try:
        return int(field) == value
    except:
        return False

minute_s, hour_s, dom_s, mon_s, dow_s = parts
# cron dow: 0=Sunday, 1=Monday... 6=Saturday
# Python weekday: 0=Monday... 6=Sunday → convert: Sun=0
py_dow = (now.weekday() + 1) % 7  # Mon=1, ..., Sat=6, Sun=0

ok = (field_match(minute_s, now.minute) and
      field_match(hour_s, now.hour) and
      field_match(dom_s, now.day) and
      field_match(mon_s, now.month) and
      field_match(dow_s, py_dow))

print("yes" if ok else "no")
PYEOF
)
    [ "$matches" = "yes" ] || return 1

    # Mark as ran this minute
    echo "$current_min" > "$last_run_file"
    return 0
}

# ---------------------------------------------------------------------------
# Helper: check if heartbeat (interval-based) should run
# config uses interval_minutes instead of schedule
# ---------------------------------------------------------------------------
heartbeat_should_run() {
    local cron_dir="$1"
    local agent_name="$2"
    local config_file="$cron_dir/config.json"

    [ -f "$config_file" ] || return 1

    local enabled
    enabled=$(python3 -c "
import json
try:
    d = json.load(open('$config_file'))
    print(str(d.get('enabled', True)).lower())
except: print('false')
" 2>/dev/null || echo "false")
    [ "$enabled" = "true" ] || return 1

    # Use global interval — per-agent interval_minutes in config.json is ignored.
    local interval_minutes=$HEARTBEAT_INTERVAL_MINUTES

    # Check last run (per-agent)
    local last_run_file="$cron_dir/.last_run.$agent_name"
    local now_epoch
    now_epoch=$(date +%s)

    if [ -f "$last_run_file" ]; then
        local last_epoch
        last_epoch=$(cat "$last_run_file" 2>/dev/null || echo "0")
        local elapsed=$(( (now_epoch - last_epoch) / 60 ))
        if [ "$elapsed" -lt "$interval_minutes" ]; then
            return 1
        fi
    fi

    # Mark as ran now
    echo "$now_epoch" > "$last_run_file"
    return 0
}

# ---------------------------------------------------------------------------
# Helper: get a string config value from JSON
# ---------------------------------------------------------------------------
get_json_str() {
    local file="$1"
    local key="$2"
    local default="$3"
    python3 -c "
import json
try:
    print(json.load(open('$file')).get('$key', '$default'))
except: print('$default')
" 2>/dev/null || echo "$default"
}

get_primary_model() {
    local file="$1"
    local default="$2"
    python3 -c "
import json
try:
    d = json.load(open('$file'))
    models = d.get('models') or [{'model': d.get('model', '$default')}]
    print(models[0].get('model', '$default'))
except: print('$default')
" 2>/dev/null || echo "$default"
}

# ---------------------------------------------------------------------------
# Main: iterate over all agents
# ---------------------------------------------------------------------------
# Snapshot the current time before iterating so all agents use the same minute.
# Without this, agents processed after a slow task (e.g. archie at 03:00)
# see a later minute and miss their scheduled crons.
HEARTBEAT_SNAPSHOT_MIN=$(date +%Y%m%d%H%M)
HEARTBEAT_SNAPSHOT_ISO=$(date '+%Y-%m-%d %H:%M')

for agent_dir in "$AGENTFORGE_ROOT/agents/"/*/; do
    agent_name=$(basename "$agent_dir")

    # Skip special dirs
    case "$agent_name" in
        shared|_template) continue ;;
    esac

    # Skip if no config (not a real agent)
    [ -f "$agent_dir/config.json" ] || continue

    # Skip deactivated agents.
    # Checks (in priority order):
    #   1. data/state.json  — written by /active Telegram command at runtime
    #   2. config.json      — static flag for permanently disabled agents
    agent_active=$(python3 -c "
import json, os
state_file = os.path.join('${agent_dir}', 'data', 'state.json')
config_file = os.path.join('${agent_dir}', 'config.json')
try:
    print(str(json.load(open(state_file)).get('active', True)).lower())
except Exception:
    try:
        print(str(json.load(open(config_file)).get('active', True)).lower())
    except Exception:
        print('true')
" 2>/dev/null || echo "true")
    if [ "$agent_active" = "false" ]; then
        echo "[$TODAY $NOW] Agent $agent_name is deactivated — skipping" >> "$LOG"
        continue
    fi

    echo "[$TODAY $NOW] Processing agent: $agent_name" >> "$LOG"

    # 1. Run ROOT built-in crons (apply to ALL agents)
    if [ -d "$AGENTFORGE_ROOT/cron" ]; then
        for root_cron_dir in "$AGENTFORGE_ROOT/cron/"/*/; do
            cron_name=$(basename "$root_cron_dir")
            task_md="$root_cron_dir/task.md"
            [ -f "$task_md" ] || continue

            # Check for per-agent config override
            agent_override="$agent_dir/cron/$cron_name/config.json"
            if [ -f "$agent_override" ]; then
                effective_config_dir="$agent_dir/cron/$cron_name"
            else
                effective_config_dir="$root_cron_dir"
            fi

            if cron_schedule_matches "$effective_config_dir" "$agent_name" "$HEARTBEAT_SNAPSHOT_MIN" "$HEARTBEAT_SNAPSHOT_ISO"; then
                model=$(get_primary_model "$effective_config_dir/config.json" "haiku")
                budget=$(get_json_str "$effective_config_dir/config.json" "max_budget_usd" "0.5")
                echo "[$TODAY $NOW] Root cron: $cron_name for $agent_name" >> "$LOG"
                run_cron_task "$agent_dir" "$task_md" "$model" "$budget"
            fi
        done
    fi

    # 2. Run per-agent crons (heartbeat + instance-defined crons)
    if [ -d "$agent_dir/cron" ]; then
        for cron_dir in "$agent_dir/cron/"/*/; do
            cron_name=$(basename "$cron_dir")
            task_md="$cron_dir/task.md"
            config_file="$cron_dir/config.json"

            [ -f "$config_file" ] || continue

            # Heartbeat uses interval_minutes; other crons use schedule
            if [ "$cron_name" = "heartbeat" ]; then
                if heartbeat_should_run "$cron_dir" "$agent_name"; then
                    # Skip Claude call if no actionable tasks — zero cost when idle
                    _hb_due=$("$PYTHON_BIN" -m agentforge.todo_cli due \
                        --root "$AGENTFORGE_ROOT" --agent "$agent_name" \
                        --format heartbeat --limit 1 2>/dev/null || true)
                    if [ -z "$_hb_due" ]; then
                        echo "[$TODAY $NOW] Heartbeat: no pending tasks for $agent_name — skipping Claude call" >> "$LOG"
                    else
                        model=$(get_primary_model "$config_file" "haiku")
                        budget=$(get_json_str "$config_file" "max_budget_usd" "0.5")
                        run_cron_task "$agent_dir" "$task_md" "$model" "$budget"
                    fi
                fi
            else
                [ -f "$task_md" ] || continue
                if cron_schedule_matches "$cron_dir" "$agent_name" "$HEARTBEAT_SNAPSHOT_MIN" "$HEARTBEAT_SNAPSHOT_ISO"; then
                    model=$(get_primary_model "$config_file" "haiku")
                    budget=$(get_json_str "$config_file" "max_budget_usd" "0.5")
                    run_cron_task "$agent_dir" "$task_md" "$model" "$budget"
                fi
            fi
        done
    fi
done

echo "[$TODAY $NOW] === Heartbeat done ===" >> "$LOG"
