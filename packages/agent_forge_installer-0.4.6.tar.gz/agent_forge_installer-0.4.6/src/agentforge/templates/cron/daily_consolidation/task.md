# Daily Memory Consolidation

**Executes every night at 03:00.**

Objective: distill yesterday's daily note into compact durable facts for `memory.md`.

## Instructions

1. Review the injected daily note content when present.
2. Extract only durable facts worth keeping in long-term memory.
3. Ignore transient chatter, duplicated notes, and low-value details.
4. Output only one of:
   - A markdown bullet list of facts, one fact per `- ` line
   - `CONSOLIDATION_OK (nothing new)` if nothing durable should be added
   - `CONSOLIDATION_SKIP` if no daily note was available
5. Do not send Telegram notifications for routine consolidation.
