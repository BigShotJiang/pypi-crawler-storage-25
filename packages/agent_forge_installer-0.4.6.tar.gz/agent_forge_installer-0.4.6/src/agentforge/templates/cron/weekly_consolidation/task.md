# Weekly Memory Consolidation

**Executes every Sunday at 23:00.**

Objective: review the recent daily notes and compact memory for patterns that should persist.

## Instructions

1. Review the last week's daily notes and current `memory.md`.
2. Merge repeated or related facts into clearer long-term memory.
3. Remove or rewrite outdated, contradictory, or redundant entries when appropriate.
4. Keep `memory.md` compact and durable rather than verbose.
5. Reply with `WEEKLY_CONSOLIDATION_OK` when complete.
