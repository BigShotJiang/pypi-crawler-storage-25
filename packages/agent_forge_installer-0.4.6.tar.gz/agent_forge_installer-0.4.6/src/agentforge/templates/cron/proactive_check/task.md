# Proactive Check

Review your pending todos and delegated tasks (injected above by heartbeat.sh).

## Instructions

1. Scan the injected todos and tasks for anything actionable **right now** (time-sensitive, unblocked, ready).
2. For each actionable item: execute it. Use available tools (telegram_send.sh, gog, gh, etc.).
3. If an item is NOT actionable right now (waiting for something, not urgent, already done): skip it.
4. After processing all items:
   - If you acted on at least one item → output `TASK_DONE`
   - If nothing was actionable → output `TASK_SKIP`

## Constraints
- Do NOT send Telegram notifications for routine or trivial items.
- Do NOT spam Martin. Only notify if something important was done or needs attention.
- Do NOT re-do completed items.
- Max 2-3 actions per run to avoid overwhelming.
