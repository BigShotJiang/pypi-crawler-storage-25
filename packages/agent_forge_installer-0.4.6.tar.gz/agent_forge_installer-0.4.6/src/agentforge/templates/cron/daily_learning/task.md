# Daily Learning Extraction

**Executes every night at 01:00.**

Objective: write a compact daily note with the day's notable learnings.

## Instructions

1. Review today's conversations and recent work for this agent.
2. Capture notable learnings, decisions, blockers, and context changes.
3. Write or update today's note in `vault/Agents/$AGENT_NAME/daily/YYYY-MM-DD.md`.
4. Keep the note concise and useful for later consolidation.
5. If little happened, still create a minimal note instead of skipping.
6. Reply with `LEARNING_OK` when complete.
