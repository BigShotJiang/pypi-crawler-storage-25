#!/usr/bin/env bash
set -euo pipefail

AGENTFORGE_ROOT="${AGENTFORGE_ROOT:?AGENTFORGE_ROOT is not set}"
exec "$AGENTFORGE_RUNTIME_ROOT/scripts/todo_command.sh" "todo-goals" "$@"
