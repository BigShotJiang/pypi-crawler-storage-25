"""Runtime cleanup helpers for AgentForge installs and upgrades."""

from __future__ import annotations

import json
import os
import pwd
import signal
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable


Printer = Callable[[str], None]

LEGACY_AGENT_UNITS: dict[str, str] = {
    "agentforge.service": "clawdia",
    "agentforge-archie.service": "archie",
    "agentforge-architect.service": "architect",
    "agentforge-catherine.service": "catherine",
    "agentforge-christophe.service": "christophe",
    "agentforge-porter.service": "porter",
    "agentforge-victor.service": "victor",
}

PROCESS_PATTERNS = (
    "agentforge bot",
    "/agentforge bot",
)


@dataclass
class CleanupResult:
    active_agents: set[str] = field(default_factory=set)
    inactive_agents: set[str] = field(default_factory=set)
    stopped_processes: list[int] = field(default_factory=list)
    disabled_units: list[str] = field(default_factory=list)
    stale_cron_lines: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def read_agent_states(root: Path) -> tuple[set[str], set[str]]:
    """Return active and inactive agents from live state files."""
    active: set[str] = set()
    inactive: set[str] = set()
    agents_dir = root / "agents"
    if not agents_dir.exists():
        return active, inactive

    for agent_dir in sorted(agents_dir.iterdir()):
        if not agent_dir.is_dir() or agent_dir.name in {"shared", "_template"}:
            continue
        if not (agent_dir / "config.json").exists():
            continue
        state_path = agent_dir / "data" / "state.json"
        try:
            state = json.loads(state_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            state = {}
        except Exception:
            state = {}
        if state.get("active", True):
            active.add(agent_dir.name)
        else:
            inactive.add(agent_dir.name)
    return active, inactive


def find_manual_bot_processes(root: Path) -> list[int]:
    """Find manually launched AgentForge bot processes for this instance root."""
    current = {os.getpid(), os.getppid()}
    try:
        proc = subprocess.run(
            ["ps", "-eo", "pid=,ppid=,cmd="],
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError:
        return []

    if proc.returncode != 0:
        return []

    root_text = str(root)
    process_table: dict[int, tuple[int, str]] = {}
    for line in proc.stdout.splitlines():
        parts = line.strip().split(None, 2)
        if len(parts) < 3:
            continue
        try:
            pid = int(parts[0])
            ppid = int(parts[1])
        except ValueError:
            continue
        process_table[pid] = (ppid, parts[2])

    matches: list[int] = []
    for pid, (_ppid, cmd) in process_table.items():
        if pid in current:
            continue
        if root_text not in cmd:
            continue
        if "systemctl --user" in cmd:
            continue
        if _has_systemd_user_ancestor(pid, process_table):
            continue
        if any(pattern in cmd for pattern in PROCESS_PATTERNS):
            matches.append(pid)
    return sorted(set(matches))


def _has_systemd_user_ancestor(pid: int, process_table: dict[int, tuple[int, str]]) -> bool:
    seen: set[int] = set()
    current = pid
    while current in process_table and current not in seen:
        seen.add(current)
        ppid, cmd = process_table[current]
        if "systemd --user" in cmd or "/systemd --user" in cmd:
            return True
        current = ppid
    return False


def stop_processes(pids: list[int], *, dry_run: bool = False) -> list[int]:
    """Terminate processes, escalating to SIGKILL if needed."""
    if dry_run:
        return pids

    stopped: list[int] = []
    for pid in pids:
        try:
            os.kill(pid, signal.SIGTERM)
            stopped.append(pid)
        except ProcessLookupError:
            stopped.append(pid)
        except PermissionError:
            continue

    deadline = time.time() + 3
    while time.time() < deadline:
        remaining = [pid for pid in stopped if _process_exists(pid)]
        if not remaining:
            break
        time.sleep(0.1)

    for pid in stopped:
        if not _process_exists(pid):
            continue
        try:
            os.kill(pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
    return stopped


def _process_exists(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def enabled_agent_units(
    service_dir: Path,
    *,
    inactive_agents: set[str],
) -> list[str]:
    wants_dir = service_dir / "default.target.wants"
    enabled: list[str] = []
    for unit, agent in LEGACY_AGENT_UNITS.items():
        if agent not in inactive_agents:
            continue
        enabled_link = wants_dir / unit
        if enabled_link.exists() or enabled_link.is_symlink():
            enabled.append(unit)
    return enabled


def disable_units(units: list[str], *, dry_run: bool = False) -> list[str]:
    disabled: list[str] = []
    for unit in units:
        if not dry_run:
            try:
                subprocess.run(
                    ["systemctl", "--user", "disable", "--now", unit],
                    capture_output=True,
                    text=True,
                    check=False,
                )
            except FileNotFoundError:
                pass
        disabled.append(unit)
    return disabled


def stale_crontab_lines(root: Path) -> list[str]:
    """Return cron lines that still execute mutable root scripts for this instance."""
    try:
        proc = subprocess.run(
            ["crontab", "-l"],
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError:
        return []
    if proc.returncode != 0:
        return []

    root_scripts = str(root / "scripts")
    needles = (
        f"{root_scripts}/heartbeat.sh",
        f"{root_scripts}/healthcheck.sh",
        f"{root_scripts}/telegram_send.sh",
        f"{root_scripts}/memory_consolidation.sh",
        f"{root_scripts}/monitoring_heartbeat.sh",
    )
    stale: list[str] = []
    for line in proc.stdout.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if any(needle in stripped for needle in needles):
            stale.append(stripped)
    return stale


def cleanup_runtime(
    root: Path,
    *,
    dry_run: bool = False,
    printer: Printer | None = None,
) -> CleanupResult:
    """Clean old process managers that commonly duplicate AgentForge actions."""
    root = root.resolve()
    printer = printer or (lambda _msg: None)
    result = CleanupResult()
    result.active_agents, result.inactive_agents = read_agent_states(root)

    pids = find_manual_bot_processes(root)
    if pids:
        printer(f"manual bot processes: {', '.join(str(pid) for pid in pids)}")
        result.stopped_processes = stop_processes(pids, dry_run=dry_run)

    service_dir = _service_dir_for_root(root)
    units = enabled_agent_units(service_dir, inactive_agents=result.inactive_agents)
    if units:
        printer(f"inactive-agent units: {', '.join(units)}")
        if dry_run or _current_user_owns_root(root):
            result.disabled_units = disable_units(units, dry_run=dry_run)
        else:
            warning = (
                "cannot disable inactive-agent units from this user; "
                f"run cleanup as {service_dir.parent.parent.parent.name}"
            )
            result.warnings.append(warning)
            printer(warning)

    result.stale_cron_lines = stale_crontab_lines(root)
    for line in result.stale_cron_lines:
        printer(f"stale cron entry still points at root scripts: {line}")

    if not result.stopped_processes and not result.disabled_units and not result.stale_cron_lines:
        printer("runtime cleanup: no old process managers found")
    return result


def _service_dir_for_root(root: Path) -> Path:
    try:
        owner_home = Path(pwd.getpwuid(root.stat().st_uid).pw_dir)
    except Exception:
        owner_home = Path.home()
    return owner_home / ".config" / "systemd" / "user"


def _current_user_owns_root(root: Path) -> bool:
    try:
        return os.getuid() == root.stat().st_uid
    except Exception:
        return True
