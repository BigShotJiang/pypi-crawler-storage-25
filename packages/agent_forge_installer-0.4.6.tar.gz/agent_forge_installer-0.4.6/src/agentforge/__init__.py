from importlib.metadata import PackageNotFoundError, version


try:
    __version__ = version("agent-forge-installer")
except PackageNotFoundError:
    __version__ = "0.4.0"
