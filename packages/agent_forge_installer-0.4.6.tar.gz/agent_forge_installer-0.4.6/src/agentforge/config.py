"""AgentForge configuration module.

Two config types:
- AgentForgeConfig: global config loaded from bot/config.json (legacy) or env
- AgentConfig: per-agent config loaded from agents/<name>/config.json (new)
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any

from agentforge.config_models import (
    AgentRuntimeConfig,
    ModelTargetConfig,
    ValidationError,
    load_agent_runtime_config,
    load_cron_task_config,
    load_legacy_global_config,
)
from agentforge.llm_backends import resolve_backend


class ConfigError(Exception):
    """Raised when the config is missing required keys or is invalid."""


@dataclass
class ModelTarget:
    backend: str
    model: str


# ---------------------------------------------------------------------------
# Typed sub-configs (legacy global config)
# ---------------------------------------------------------------------------

@dataclass
class TelegramConfig:
    token: str
    allowed_chat_ids: list[int]
    topics: dict[str, int]


@dataclass
class ClaudeConfig:
    models: list[ModelTarget]
    max_budget_usd: float
    monthly_budget_usd: float = 20.0

    @property
    def backend(self) -> str:
        return self.models[0].backend

    @property
    def model(self) -> str:
        return self.models[0].model


@dataclass
class HeartbeatConfig:
    interval_minutes: int
    max_budget_usd: float


@dataclass
class LoggingConfig:
    sheets_id: str


# ---------------------------------------------------------------------------
# Per-agent config (new structure)
# ---------------------------------------------------------------------------

@dataclass
class AgentTelegramConfig:
    token_env_var: str
    allowed_chat_ids: list[str]
    private_chat_id: str
    poll_interval_seconds: int = 2
    max_message_length: int = 4096
    group_chat_id: str = ""
    bot_username: str = ""
    topics: dict[str, int] = field(default_factory=dict)


@dataclass
class AgentClaudeConfig:
    models: list[ModelTarget]
    max_budget_usd: float = 5.0
    monthly_budget_usd: float = 20.0
    working_directory: str = ""

    @property
    def backend(self) -> str:
        return self.models[0].backend

    @property
    def model(self) -> str:
        return self.models[0].model


@dataclass
class AgentContextConfig:
    messages: int = 20
    hours: int = 24


@dataclass
class AgentEventSourceConfig:
    enabled: bool = True
    source: str = ""
    event_type: str = ""
    prompt_ref: str = ""
    label: str = ""
    repo: str = ""
    mailbox: str = ""
    query: str = ""
    poll_interval_minutes: int = 5


@dataclass
class AgentEventsConfig:
    db_path: str = "data/events.db"
    sources: list[AgentEventSourceConfig] = field(default_factory=list)


def _normalize_model_targets(
    entries: list[ModelTargetConfig | dict[str, Any]] | None,
    *,
    backend: str = "",
    model: str = "",
    default_model: str,
) -> list[ModelTarget]:
    normalized: list[ModelTarget] = []
    for entry in entries or []:
        if isinstance(entry, ModelTargetConfig):
            raw_backend = entry.backend
            raw_model = entry.model
        else:
            raw_backend = str(entry.get("backend", ""))
            raw_model = str(entry.get("model", ""))
        resolved_model = raw_model.strip() or default_model
        normalized.append(
            ModelTarget(
                backend=resolve_backend(raw_backend, resolved_model),
                model=resolved_model,
            )
        )
    if normalized:
        return normalized

    resolved_model = (model or "").strip() or default_model
    return [
        ModelTarget(
            backend=resolve_backend(backend, resolved_model),
            model=resolved_model,
        )
    ]


@dataclass
class AgentConfig:
    """Per-agent config loaded from agents/<name>/config.json."""
    name: str
    telegram: AgentTelegramConfig
    claude: AgentClaudeConfig
    context: AgentContextConfig
    events: AgentEventsConfig
    agent_dir: str = ""  # absolute path to agents/<name>/

    @classmethod
    def from_dict(cls, data: dict[str, Any], agent_dir: str = "") -> "AgentConfig":
        try:
            model = AgentRuntimeConfig.model_validate(data)
        except ValidationError as exc:
            raise ConfigError(f"Invalid agent config: {exc}") from exc
        name = model.name or os.path.basename(agent_dir)
        telegram = AgentTelegramConfig(
            token_env_var=model.telegram.token_env_var,
            allowed_chat_ids=[str(x) for x in model.telegram.allowed_chat_ids],
            private_chat_id=str(model.telegram.private_chat_id),
            poll_interval_seconds=int(model.telegram.poll_interval_seconds),
            max_message_length=int(model.telegram.max_message_length),
            group_chat_id=str(model.telegram.group_chat_id),
            bot_username=model.telegram.bot_username,
            topics=model.telegram.topics,
        )
        claude = AgentClaudeConfig(
            models=_normalize_model_targets(
                model.claude.models,
                backend=model.claude.backend,
                model=model.claude.model,
                default_model="sonnet",
            ),
            max_budget_usd=float(model.claude.max_budget_usd),
            monthly_budget_usd=float(model.claude.monthly_budget_usd),
            working_directory=model.claude.working_directory,
        )
        context = AgentContextConfig(
            messages=int(model.context.messages),
            hours=int(model.context.hours),
        )
        events = AgentEventsConfig(
            db_path=str(model.events.db_path),
            sources=[
                AgentEventSourceConfig(
                    enabled=bool(source.enabled),
                    source=str(source.source),
                    event_type=str(source.event_type),
                    prompt_ref=str(source.prompt_ref),
                    label=str(source.label),
                    repo=str(source.repo),
                    mailbox=str(source.mailbox),
                    query=str(source.query),
                    poll_interval_minutes=int(source.poll_interval_minutes),
                )
                for source in model.events.sources
            ],
        )
        return cls(
            name=name,
            telegram=telegram,
            claude=claude,
            context=context,
            events=events,
            agent_dir=agent_dir,
        )

    @classmethod
    def from_dir(cls, agent_dir: str) -> "AgentConfig":
        """Load agent config from agents/<name>/config.json."""
        config_path = os.path.join(agent_dir, "config.json")
        try:
            model = load_agent_runtime_config(config_path)
        except ValidationError as exc:
            raise ConfigError(f"Invalid config at {config_path}: {exc}") from exc
        data = model.model_dump()
        return cls.from_dict(data, agent_dir=agent_dir)

    @classmethod
    def from_env(cls) -> "AgentConfig":
        """Load agent config using AGENT_DIR env var."""
        agent_dir = os.environ.get("AGENT_DIR", "")
        if agent_dir:
            return cls.from_dir(agent_dir)
        raise ConfigError("AGENT_DIR env var not set and no agent_dir provided")

    def get_token(self) -> str:
        """Resolve the Telegram token from environment."""
        return os.environ.get(self.telegram.token_env_var, "")

    def get_state_path(self) -> str:
        """Path to agent's state.json (Telegram polling offset)."""
        return os.path.join(self.agent_dir, "data", "state.json")

    def get_log_path(self) -> str:
        """Path to agent's telegram.log."""
        return os.path.join(self.agent_dir, "logs", "telegram.log")

    def get_soul_path(self) -> str:
        return os.path.join(self.agent_dir, "soul.md")

    def get_memory_path(self) -> str:
        return os.path.join(self.agent_dir, "memory.md")


@dataclass
class CronConfig:
    """Config for a cron task (schedule or interval_minutes)."""
    enabled: bool = True
    models: list[ModelTarget] = field(default_factory=lambda: [ModelTarget(backend="claude", model="haiku")])
    max_budget_usd: float = 0.5
    label: str = ""
    schedule: str = ""          # cron expression: "55 9 * * *"
    interval_minutes: int = 0   # for heartbeat-style interval

    @property
    def backend(self) -> str:
        return self.models[0].backend

    @property
    def model(self) -> str:
        return self.models[0].model

    @classmethod
    def from_dir(cls, cron_dir: str) -> "CronConfig":
        config_path = os.path.join(cron_dir, "config.json")
        try:
            data = load_cron_task_config(config_path)
        except ValidationError as exc:
            raise ConfigError(f"Invalid cron config at {config_path}: {exc}") from exc
        return cls(
            enabled=bool(data.enabled),
            models=_normalize_model_targets(
                data.models,
                model=data.model,
                default_model="haiku",
            ),
            max_budget_usd=float(data.max_budget_usd),
            label=str(data.label),
            schedule=str(data.schedule),
            interval_minutes=int(data.interval_minutes),
        )


# ---------------------------------------------------------------------------
# Legacy global config (kept for backward compat)
# ---------------------------------------------------------------------------

@dataclass
class AgentForgeConfig:
    telegram: TelegramConfig
    claude: ClaudeConfig
    threads: dict[str, Any]  # keyed by thread id (str), values are agent dicts
    heartbeat: HeartbeatConfig
    logging: LoggingConfig

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AgentForgeConfig":
        tg = data.get("telegram", {})
        if not tg.get("allowed_chat_ids"):
            raise ConfigError("Missing required key: telegram.allowed_chat_ids")
        cl = data.get("claude", {})
        if not cl.get("model") and not cl.get("models"):
            raise ConfigError("Missing required key: claude.models")

        telegram = TelegramConfig(
            token=tg.get("token", ""),
            allowed_chat_ids=tg.get("allowed_chat_ids", []),
            topics=tg.get("topics", {}),
        )
        claude = ClaudeConfig(
            models=_normalize_model_targets(
                cl.get("models"),
                backend=cl.get("backend", ""),
                model=cl.get("model", ""),
                default_model="sonnet",
            ),
            max_budget_usd=float(cl.get("max_budget_usd", 0.5)),
            monthly_budget_usd=float(cl.get("monthly_budget_usd", 20.0)),
        )
        hb = data.get("heartbeat", {})
        heartbeat = HeartbeatConfig(
            interval_minutes=int(hb.get("interval_minutes", 60)),
            max_budget_usd=float(hb.get("max_budget_usd", 0.1)),
        )
        lg = data.get("logging", {})
        logging_cfg = LoggingConfig(
            sheets_id=lg.get("sheets_id", ""),
        )
        return cls(
            telegram=telegram,
            claude=claude,
            threads=data.get("threads", {}),
            heartbeat=heartbeat,
            logging=logging_cfg,
        )

    @classmethod
    def load(cls, path: str | None = None) -> "AgentForgeConfig":
        if path is None:
            path = os.environ.get("AGENTFORGE_CONFIG")
        if path is None:
            root = os.environ.get("AGENTFORGE_ROOT", os.path.expanduser("~"))
            path = os.path.join(root, "bot", "config.json")
        try:
            model = load_legacy_global_config(path)
        except ValidationError as exc:
            raise ConfigError(f"Invalid config at {path}: {exc}") from exc
        return cls.from_dict(model.model_dump())


# ---------------------------------------------------------------------------
# Singleton (legacy)
# ---------------------------------------------------------------------------

_instance: AgentForgeConfig | None = None


def get_config(path: str | None = None) -> AgentForgeConfig:
    """Return the singleton AgentForgeConfig, loading it on first call."""
    global _instance
    if _instance is None:
        _instance = AgentForgeConfig.load(path)
    return _instance


def reset_config() -> None:
    """Reset the singleton (useful for tests)."""
    global _instance
    _instance = None
