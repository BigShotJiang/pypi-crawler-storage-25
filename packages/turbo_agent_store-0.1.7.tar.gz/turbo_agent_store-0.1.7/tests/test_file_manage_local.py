# coding=utf-8
from __future__ import annotations

import os
from pathlib import Path
from tempfile import NamedTemporaryFile

import pytest

os.environ.setdefault("DATABASE_URL", "sqlite:///test.db")

from turbo_agent_store.files.file_manage import FileMoveTarget, LocalFileManageStore, ResourceFileSpec, StorageLocator


def _write_temp_file(payload: bytes, suffix: str) -> str:
    with NamedTemporaryFile(delete=False, suffix=suffix) as temp_file:
        temp_file.write(payload)
        return temp_file.name


@pytest.fixture
def local_store(tmp_path: Path) -> LocalFileManageStore:
    return LocalFileManageStore(base_path=str(tmp_path / "file-manage"))


@pytest.mark.asyncio
async def test_local_space_avatar_uses_public_root(local_store: LocalFileManageStore):
    temp_path = _write_temp_file(b"space-avatar", ".png")
    try:
        result = await local_store.create_space_file(
            space_id="001",
            spec=ResourceFileSpec(resource_id="", file_type="png", role="avatar", variant="raw"),
            local_file_path=temp_path,
        )
    finally:
        os.remove(temp_path)

    assert "/public/" in result.descriptor.uri
    assert result.descriptor.object_key == "resources/space_001/meta/avatar/raw/origin.png"
    assert Path(result.descriptor.uri.removeprefix("file://")).read_bytes() == b"space-avatar"


@pytest.mark.asyncio
async def test_local_avatar_uses_public_root(local_store: LocalFileManageStore):
    temp_path = _write_temp_file(b"avatar", ".png")
    try:
        result = await local_store.create_agent_file(
            space_id="001",
            project_id="001",
            spec=ResourceFileSpec(resource_id="agent_001", file_type="png", role="avatar", variant="raw"),
            local_file_path=temp_path,
        )
    finally:
        os.remove(temp_path)

    assert "/public/" in result.descriptor.uri
    assert result.descriptor.object_key == "resources/space_001/project_001/agent/agent_001/avatar/raw/origin.png"
    assert Path(result.descriptor.uri.removeprefix("file://")).read_bytes() == b"avatar"


@pytest.mark.asyncio
async def test_local_ensure_space_storage_returns_space_prefix(local_store: LocalFileManageStore):
    locator = await local_store.ensure_space_storage("001")

    assert locator.bucket == "private"
    assert locator.prefix == "resources/space_001/"


@pytest.mark.asyncio
async def test_local_temp_file_stays_private_and_can_be_read(local_store: LocalFileManageStore):
    temp_path = _write_temp_file(b"pdf-data", ".pdf")
    try:
        result = await local_store.create_temp_file(
            space_id="001",
            spec=ResourceFileSpec(resource_id="temp_001", file_type="pdf", variant="raw"),
            local_file_path=temp_path,
        )
    finally:
        os.remove(temp_path)

    assert "/private/" in result.descriptor.uri
    payload = await local_store.read_temp_file(result.descriptor.uri)
    assert payload == b"pdf-data"


@pytest.mark.asyncio
async def test_local_move_temp_resource_with_locator(local_store: LocalFileManageStore):
    temp_path = _write_temp_file(b"pdf-data", ".pdf")
    try:
        temp_file = await local_store.create_temp_file(
            space_id="001",
            spec=ResourceFileSpec(resource_id="temp_001", file_type="pdf", variant="raw"),
            local_file_path=temp_path,
        )
    finally:
        os.remove(temp_path)

    moved = await local_store.move_temp_resource(
        source_uri=temp_file.descriptor.uri,
        target=FileMoveTarget(
            locator=StorageLocator(bucket="private", prefix="resources/space_001/project_001/knowledge_file/knowledge_001/"),
            relative_path="raw/origin.pdf",
        ),
    )

    assert moved.descriptor.object_key == "resources/space_001/project_001/knowledge_file/knowledge_001/raw/origin.pdf"
    assert Path(moved.descriptor.uri.removeprefix("file://")).read_bytes() == b"pdf-data"
    assert not Path(temp_file.descriptor.uri.removeprefix("file://")).exists()


@pytest.mark.asyncio
async def test_local_generate_secure_link_returns_file_uri_in_desktop_mode(local_store: LocalFileManageStore):
    temp_path = _write_temp_file(b"hello", ".md")
    try:
        result = await local_store.create_knowledge_file(
            space_id="001",
            project_id="001",
            spec=ResourceFileSpec(resource_id="knowledge_001", file_type="md", variant="raw"),
            local_file_path=temp_path,
        )
    finally:
        os.remove(temp_path)

    link = await local_store.generate_secure_link(result.descriptor.uri, variant="raw")

    assert link.url == result.descriptor.uri
    assert link.access_mode.value == "public"


@pytest.mark.asyncio
async def test_local_generate_secure_link_uses_external_url_for_private_files(tmp_path: Path):
    store = LocalFileManageStore(
        base_path=str(tmp_path / "file-manage"),
        external_base_url="https://files.example.com",
        external_path_prefix="/local-files",
    )
    temp_path = _write_temp_file(b"hello", ".md")
    try:
        result = await store.create_knowledge_file(
            space_id="001",
            project_id="001",
            spec=ResourceFileSpec(resource_id="knowledge_001", file_type="md", variant="raw"),
            local_file_path=temp_path,
        )
    finally:
        os.remove(temp_path)

    link = await store.generate_secure_link(result.descriptor.uri, variant="raw", revision="rev1")

    assert link.access_mode.value == "presigned"
    assert link.url.startswith("https://files.example.com/local-files/private/resources/space_001/project_001/knowledge_file/knowledge_001/raw/origin.md")
    assert "rev=rev1" in link.url
    assert "expires=" in link.url


@pytest.mark.asyncio
async def test_local_generate_secure_link_adds_nginx_secure_link_signature(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr("turbo_agent_store.files.file_manage.local_store.settings.TA_STORE_SECURE_LINK_SECRET", "local-sign-secret")

    store = LocalFileManageStore(
        base_path=str(tmp_path / "file-manage"),
        external_base_url="https://files.example.com",
        external_path_prefix="/local-files",
    )
    temp_path = _write_temp_file(b"hello", ".md")
    try:
        result = await store.create_knowledge_file(
            space_id="001",
            project_id="001",
            spec=ResourceFileSpec(resource_id="knowledge_001", file_type="md", variant="raw"),
            local_file_path=temp_path,
        )
    finally:
        os.remove(temp_path)

    link = await store.generate_secure_link(result.descriptor.uri, variant="raw")

    assert "expires=" in link.url
    assert "sig=" in link.url


@pytest.mark.asyncio
async def test_local_create_temp_file_rejects_role(local_store: LocalFileManageStore):
    temp_path = _write_temp_file(b"pdf-data", ".pdf")
    try:
        with pytest.raises(ValueError, match="临时文件.*不允许提供 role"):
            await local_store.create_temp_file(
                space_id="001",
                spec=ResourceFileSpec(resource_id="temp_001", file_type="pdf", role="avatar", variant="raw"),
                local_file_path=temp_path,
            )
    finally:
        os.remove(temp_path)


@pytest.mark.asyncio
async def test_local_create_knowledge_file_rejects_role(local_store: LocalFileManageStore):
    temp_path = _write_temp_file(b"hello", ".md")
    try:
        with pytest.raises(ValueError, match="知识资源文件.*不允许提供 role"):
            await local_store.create_knowledge_file(
                space_id="001",
                project_id="001",
                spec=ResourceFileSpec(resource_id="knowledge_001", file_type="md", role="avatar", variant="raw"),
                local_file_path=temp_path,
            )
    finally:
        os.remove(temp_path)