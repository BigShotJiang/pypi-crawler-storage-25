# coding=utf-8
from __future__ import annotations

import pytest

from turbo_agent_core.schema.enums import ConversationStatus
from turbo_agent_core.schema.events import (
    ContentActionDeltaEvent,
    ContentActionDeltaPayload,
    ContentActionEndEvent,
    ContentActionEndPayload,
    ContentActionResultEndEvent,
    ContentActionResultEndPayload,
    ContentActionResultStartEvent,
    ContentActionResultStartPayload,
    ContentActionStartEvent,
    ContentActionStartPayload,
    ContentTextDeltaEvent,
    ContentTextDeltaPayload,
    ContentTextEndEvent,
    ContentTextEndPayload,
    ContentTextStartEvent,
    ContentTextStartPayload,
    ExecutorMetadata,
    RunLifecycleCompletedEvent,
    RunLifecycleCompletedPayload,
    RunLifecycleCreatedEvent,
    RunLifecycleCreatedPayload,
    UserInfo,
)

from turbo_agent_core.schema.states import Conversation
from turbo_agent_store.stream import DataStreamConsumer
from turbo_agent_store.data.cache.state import InMemoryStateStore


@pytest.mark.asyncio
async def test_data_stream_consumer_dispatch_to_execution_store():
    store = InMemoryStateStore()
    react_id = "react-r1-1"
    await store.save_conversation(
        Conversation(id="c1", title="test", status=ConversationStatus.pending)
    )

    created = RunLifecycleCreatedEvent(
        trace_id="t1",
        run_id="r1",
        executor_id="AGENT:test@demo",
        executor_metadata=ExecutorMetadata(id="AGENT:test@demo", name="test"),
        user_metadata=UserInfo(id="u1"),
        payload=RunLifecycleCreatedPayload(input_data={"conversation_id": "c1", "user_id": "u1"}),
    )

    consumer = DataStreamConsumer(
        redis=None,  # type: ignore[arg-type]
        trace_id="t1",
        state_store=store,
        initial_created=created,
        start_stream_id=None,
    )

    await consumer.handle_event(created)
    await consumer.flush_now()
    assert "c1" in store.conversations

    await consumer.handle_event(
        ContentTextStartEvent(trace_id="t1", run_id="r1", executor_id="AGENT:test@demo", react_id=react_id, payload=ContentTextStartPayload(format="plain"))
    )
    await consumer.handle_event(
        ContentTextDeltaEvent(trace_id="t1", run_id="r1", executor_id="AGENT:test@demo", react_id=react_id, payload=ContentTextDeltaPayload(delta="你"))
    )
    await consumer.handle_event(
        ContentTextDeltaEvent(trace_id="t1", run_id="r1", executor_id="AGENT:test@demo", react_id=react_id, payload=ContentTextDeltaPayload(delta="好"))
    )
    await consumer.handle_event(
        ContentTextEndEvent(trace_id="t1", run_id="r1", executor_id="AGENT:test@demo", react_id=react_id, payload=ContentTextEndPayload(full_text="你好"))
    )

    # Action
    await consumer.handle_event(
        ContentActionStartEvent(
            trace_id="t1",
            run_id="r1",
            executor_id="AGENT:test@demo",
            react_id=react_id,
            action_id="a1",
            payload=ContentActionStartPayload(name="search"),
        )
    )
    await consumer.handle_event(
        ContentActionDeltaEvent(
            trace_id="t1",
            run_id="r1",
            executor_id="AGENT:test@demo",
            react_id=react_id,
            action_id="a1",
            payload=ContentActionDeltaPayload(part="args", delta="{\"q\":\"x\"}"),
        )
    )
    await consumer.handle_event(
        ContentActionEndEvent(
            trace_id="t1",
            run_id="r1",
            executor_id="AGENT:test@demo",
            react_id=react_id,
            action_id="a1",
            payload=ContentActionEndPayload(arguments={"q": "x"}),
        )
    )

    # Action result
    await consumer.handle_event(
        ContentActionResultStartEvent(
            trace_id="t1",
            run_id="r1",
            executor_id="AGENT:test@demo",
            react_id=react_id,
            action_id="a1",
            payload=ContentActionResultStartPayload(record_id="tc1", status="success"),
        )
    )
    await consumer.handle_event(
        ContentActionResultEndEvent(
            trace_id="t1",
            run_id="r1",
            executor_id="AGENT:test@demo",
            react_id=react_id,
            action_id="a1",
            payload=ContentActionResultEndPayload(full_result={"ok": True}, status="success"),
        )
    )

    await consumer.handle_event(
        RunLifecycleCompletedEvent(
            trace_id="t1",
            run_id="r1",
            executor_id="AGENT:test@demo",
            payload=RunLifecycleCompletedPayload(output={"ok": True}),
        )
    )
    await consumer.flush_now()

    assert "t1" in store.messages
    assert store.messages["t1"].content == "你好"
    assert "a1" in store.actions
    assert store.actions["a1"].input == {"q": "x"}
    assert "tc1" in store.tool_call_records
