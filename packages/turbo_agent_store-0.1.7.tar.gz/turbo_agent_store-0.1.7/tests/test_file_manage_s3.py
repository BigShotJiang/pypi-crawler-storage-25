# coding=utf-8
from __future__ import annotations

import os
from pathlib import Path
from tempfile import NamedTemporaryFile

import pytest

os.environ.setdefault("DATABASE_URL", "sqlite:///test.db")

from turbo_agent_store.files.file_manage import (
    FileMoveTarget,
    ResourceFileSpec,
    S3FileManageStore,
    StorageLocator,
)
from turbo_agent_store.settings import settings


class _FakeS3Body:
    def __init__(self, payload: bytes):
        self._payload = payload

    def read(self) -> bytes:
        return self._payload


class _FakeS3Client:
    def __init__(self):
        self.upload_calls: list[dict[str, str]] = []
        self.copy_calls: list[dict[str, str]] = []
        self.delete_calls: list[tuple[str, str]] = []
        self.get_calls: list[tuple[str, str]] = []
        self.responses: dict[tuple[str, str], bytes] = {}
        self.prefix_counts: dict[str, int] = {}

    def head_bucket(self, Bucket: str):
        return {"Bucket": Bucket}

    def create_bucket(self, **kwargs):
        return kwargs

    def upload_file(self, Filename: str, Bucket: str, Key: str, ExtraArgs: dict[str, str]):
        self.upload_calls.append(
            {
                "bucket": Bucket,
                "object_name": Key,
                "content_type": ExtraArgs["ContentType"],
                "payload": Path(Filename).read_text(encoding="utf-8", errors="ignore"),
            }
        )

    def head_object(self, Bucket: str, Key: str):
        return {"ETag": '"etag-put"'}

    def get_object(self, Bucket: str, Key: str):
        self.get_calls.append((Bucket, Key))
        return {"Body": _FakeS3Body(self.responses[(Bucket, Key)])}

    def generate_presigned_url(self, **kwargs):
        return "https://example.com/presigned"

    def list_objects_v2(self, Bucket: str, Prefix: str, MaxKeys: int = 1000, ContinuationToken: str | None = None):
        del Bucket, MaxKeys, ContinuationToken
        count = self.prefix_counts.get(Prefix, 0)
        return {"KeyCount": count, "IsTruncated": False}

    def copy_object(self, Bucket: str, Key: str, CopySource: dict[str, str]):
        self.copy_calls.append(
            {
                "bucket": Bucket,
                "object_name": Key,
                "source_bucket": CopySource["Bucket"],
                "source_object": CopySource["Key"],
            }
        )
        return {"CopyObjectResult": {"ETag": '"etag-copy"'}, "VersionId": "v2"}

    def delete_object(self, Bucket: str, Key: str):
        self.delete_calls.append((Bucket, Key))


@pytest.fixture
def s3_store(monkeypatch: pytest.MonkeyPatch) -> tuple[S3FileManageStore, _FakeS3Client]:
    fake_client = _FakeS3Client()

    monkeypatch.setattr(settings, "TA_STORE_S3_ENDPOINT", "s3.example.com")
    monkeypatch.setattr(settings, "TA_STORE_S3_REGION", "us-east-1")
    monkeypatch.setattr(settings, "TA_STORE_S3_ACCESS_KEY_ID", "access")
    monkeypatch.setattr(settings, "TA_STORE_S3_SECRET_ACCESS_KEY", "secret")
    monkeypatch.setattr(settings, "TA_STORE_S3_SESSION_TOKEN", "")
    monkeypatch.setattr(settings, "TA_STORE_S3_SECURE", False)
    monkeypatch.setattr(settings, "TA_STORE_S3_ADDRESSING_STYLE", "path")
    monkeypatch.setattr(settings, "TA_STORE_S3_PRIVATE_BUCKET", "private-bucket")
    monkeypatch.setattr(settings, "TA_STORE_S3_PUBLIC_BUCKET", "public-bucket")
    monkeypatch.setattr(settings, "TA_STORE_EXTERNAL_BASE_URL", "")
    monkeypatch.setattr(settings, "TA_STORE_EXTERNAL_PATH_PREFIX", "")
    monkeypatch.setattr(settings, "TA_STORE_CACHE_TTL_META_AVATAR_SECONDS", 604800)
    monkeypatch.setattr(settings, "TA_STORE_CACHE_TTL_OTHER_IMAGE_SECONDS", 86400)
    monkeypatch.setattr(settings, "TA_STORE_CACHE_TTL_DEFAULT_SECONDS", 3600)

    store = S3FileManageStore(client=fake_client)
    return store, fake_client


def _write_temp_file(payload: bytes, suffix: str) -> str:
    with NamedTemporaryFile(delete=False, suffix=suffix) as temp_file:
        temp_file.write(payload)
        return temp_file.name


@pytest.mark.asyncio
async def test_create_space_avatar_uses_public_bucket_and_origin_name(s3_store: tuple[S3FileManageStore, _FakeS3Client]):
    store, client = s3_store

    temp_path = _write_temp_file(b"avatar", ".png")
    try:
        result = await store.create_space_file(
            space_id="space_001",
            spec=ResourceFileSpec(resource_id="", file_type="png", role="avatar", variant="raw"),
            local_file_path=temp_path,
        )
    finally:
        os.remove(temp_path)

    assert client.upload_calls[0]["bucket"] == "public-bucket"
    assert client.upload_calls[0]["object_name"] == "resources/space_001/meta/avatar/raw/origin.png"
    assert result.descriptor.uri == "s3://public-bucket/resources/space_001/meta/avatar/raw/origin.png"


@pytest.mark.asyncio
async def test_create_agent_avatar_uses_public_bucket_and_origin_name(s3_store: tuple[S3FileManageStore, _FakeS3Client]):
    store, client = s3_store

    temp_path = _write_temp_file(b"avatar", ".png")
    try:
        result = await store.create_agent_file(
            space_id="space_001",
            project_id="project_001",
            spec=ResourceFileSpec(resource_id="agent_001", file_type="png", role="avatar", variant="raw"),
            local_file_path=temp_path,
        )
    finally:
        os.remove(temp_path)

    assert client.upload_calls[0]["bucket"] == "public-bucket"
    assert client.upload_calls[0]["object_name"] == "resources/space_001/project_001/agent/agent_001/avatar/raw/origin.png"
    assert result.descriptor.uri == "s3://public-bucket/resources/space_001/project_001/agent/agent_001/avatar/raw/origin.png"


@pytest.mark.asyncio
async def test_ensure_space_storage_returns_space_prefix(s3_store: tuple[S3FileManageStore, _FakeS3Client]):
    store, _client = s3_store

    locator = await store.ensure_space_storage("001")

    assert locator.bucket == "private-bucket"
    assert locator.prefix == "resources/space_001/"


@pytest.mark.asyncio
async def test_create_and_read_temp_file_use_private_bucket(s3_store: tuple[S3FileManageStore, _FakeS3Client]):
    store, client = s3_store

    temp_path = _write_temp_file(b"pdf-bytes", ".pdf")
    try:
        result = await store.create_temp_file(
            space_id="001",
            spec=ResourceFileSpec(resource_id="temp_res_1", file_type="pdf", variant="raw"),
            local_file_path=temp_path,
        )
    finally:
        os.remove(temp_path)

    assert client.upload_calls[0]["bucket"] == "private-bucket"
    assert client.upload_calls[0]["object_name"].startswith("temp/space_001/")
    assert client.upload_calls[0]["object_name"].endswith("temp_res_1/raw/origin.pdf")

    client.responses[("private-bucket", client.upload_calls[0]["object_name"])] = b"pdf-bytes"
    payload = await store.read_temp_file(result.descriptor.uri)
    assert payload == b"pdf-bytes"


@pytest.mark.asyncio
async def test_create_temp_file_rejects_role(s3_store: tuple[S3FileManageStore, _FakeS3Client]):
    store, _client = s3_store

    temp_path = _write_temp_file(b"pdf-bytes", ".pdf")
    try:
        with pytest.raises(ValueError, match="临时文件.*不允许提供 role"):
            await store.create_temp_file(
                space_id="001",
                spec=ResourceFileSpec(resource_id="temp_res_1", file_type="pdf", role="avatar", variant="raw"),
                local_file_path=temp_path,
            )
    finally:
        os.remove(temp_path)


@pytest.mark.asyncio
async def test_delete_temp_file_deletes_exact_object(s3_store: tuple[S3FileManageStore, _FakeS3Client]):
    store, client = s3_store

    uri = "s3://private-bucket/temp/space_001/2026_bucket_0/temp_res_1/raw/origin.txt"
    result = await store.delete_temp_file(uri)

    assert client.delete_calls == [("private-bucket", "temp/space_001/2026_bucket_0/temp_res_1/raw/origin.txt")]
    assert result.deleted is True
    assert result.descriptor.uri == uri


@pytest.mark.asyncio
async def test_move_temp_resource_supports_locator_target(s3_store: tuple[S3FileManageStore, _FakeS3Client]):
    store, client = s3_store

    result = await store.move_temp_resource(
        source_uri="s3://private-bucket/temp/space_001/2026_bucket_0/temp_res_1/raw/origin.pdf",
        target=FileMoveTarget(
            locator=StorageLocator(bucket="private-bucket", prefix="resources/space_001/project_001/knowledge_file/knowledge_001/"),
            relative_path="raw/origin.pdf",
        ),
    )

    assert client.copy_calls == [
        {
            "bucket": "private-bucket",
            "object_name": "resources/space_001/project_001/knowledge_file/knowledge_001/raw/origin.pdf",
            "source_bucket": "private-bucket",
            "source_object": "temp/space_001/2026_bucket_0/temp_res_1/raw/origin.pdf",
        }
    ]
    assert client.delete_calls == [("private-bucket", "temp/space_001/2026_bucket_0/temp_res_1/raw/origin.pdf")]
    assert result.descriptor.uri == "s3://private-bucket/resources/space_001/project_001/knowledge_file/knowledge_001/raw/origin.pdf"


@pytest.mark.asyncio
async def test_move_temp_resource_supports_uri_target(s3_store: tuple[S3FileManageStore, _FakeS3Client]):
    store, client = s3_store

    result = await store.move_temp_resource(
        source_uri="s3://private-bucket/temp/space_001/2026_bucket_0/temp_res_1/raw/origin.png",
        target=FileMoveTarget(uri="s3://public-bucket/resources/space_001/project_001/agent/agent_001/avatar/raw/origin.png"),
    )

    assert client.copy_calls[0]["bucket"] == "public-bucket"
    assert client.copy_calls[0]["object_name"] == "resources/space_001/project_001/agent/agent_001/avatar/raw/origin.png"
    assert result.descriptor.uri == "s3://public-bucket/resources/space_001/project_001/agent/agent_001/avatar/raw/origin.png"


@pytest.mark.asyncio
async def test_allocate_temp_bucket_rolls_when_prefix_is_full(s3_store: tuple[S3FileManageStore, _FakeS3Client]):
    store, client = s3_store
    client.prefix_counts["temp/space_001/2026_bucket_0/"] = 1000
    client.prefix_counts["temp/space_001/2026_bucket_1/"] = 12

    allocation = await store.allocate_temp_bucket("001", 2026)

    assert allocation.bucket_index == 1
    assert allocation.bucket_prefix == "temp/space_001/2026_bucket_1/"