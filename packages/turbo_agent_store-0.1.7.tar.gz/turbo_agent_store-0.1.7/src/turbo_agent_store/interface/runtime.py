# coding=utf-8
"""运行时实体获取接口。

RuntimeStore 为 job 编排层提供统一的"鉴权 + 获取 runnable 实体"抽象。
与 TurboEntityStore（面向 CRUD）不同，RuntimeStore：
- 支持 ID / Detail DTO 多种输入形式
- 内嵌权限校验（无权访问时抛出 PermissionError）
- 隐藏后端特有参数（如 litellm 同步等由实现方透明处理）

实现方：
- cloud 模块提供基于 Prisma 的实现（PrismaRuntimeStore）
- standalone 模块可提供基于 SQLite/YAML 的轻量实现
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional, Union

from turbo_agent_core.schema.agents import Agent, Character
from turbo_agent_core.schema.agents import LLMModel
from turbo_agent_core.schema.detail_agent import LLMModelDetail, ToolDetail
from turbo_agent_core.schema.agents import Tool
from turbo_agent_core.schema.refs import BusinessSettingRef
from turbo_agent_core.schema.resources import BusinessSetting


class RuntimeStore(ABC):
    """运行时实体获取接口：返回鉴权后的 runnable 级别实体。"""

    @abstractmethod
    async def get_runnable_executor(
        self,
        executor_id: str,
        user_id: str,
    ) -> Union[Agent, Character]:
        """按 executor_id 获取完整可运行 Agent/Character（含递归解析工具/模型/角色）。

        参数:
            executor_id: 执行器 ID（格式：origin:type:scoped_id[:version]）
            user_id: 发起请求的用户 ID，用于权限校验

        返回:
            完整可运行的 Agent 或 Character

        异常:
            PermissionError: 用户无权访问该执行器
            ValueError: 执行器不存在
        """
        ...

    @abstractmethod
    async def get_runnable_model(
        self,
        model_ref: Union[LLMModelDetail, str],
        user_id: str,
    ) -> Optional[LLMModel]:
        """按引用/ID 获取可运行模型（含鉴权）。

        参数:
            model_ref: LLMModelDetail DTO 或模型 ID 字符串
            user_id: 发起请求的用户 ID

        返回:
            可运行的 LLMModel，或 None（若引用为空）

        异常:
            PermissionError: 用户无权访问该模型
        """
        ...

    @abstractmethod
    async def get_runnable_tool(
        self,
        tool_ref: Union[ToolDetail, str],
        user_id: str,
    ) -> Optional[Tool]:
        """按引用/ID 获取可运行工具（含鉴权）。

        参数:
            tool_ref: ToolDetail DTO 或工具 ID 字符串
            user_id: 发起请求的用户 ID

        返回:
            可运行的 Tool，或 None（若引用为空）

        异常:
            PermissionError: 用户无权访问该工具
        """
        ...

    @abstractmethod
    async def get_runnable_setting(
        self,
        setting_ref: Union[BusinessSettingRef, BusinessSetting, str],
        user_id: str,
    ) -> Optional[BusinessSetting]:
        """按引用/ID/实例获取业务设定（含鉴权）。

        参数:
            setting_ref: BusinessSettingRef / BusinessSetting 实例 / 设定 ID 字符串
            user_id: 发起请求的用户 ID

        返回:
            BusinessSetting 实例，或 None

        异常:
            PermissionError: 用户无权访问该设定
        """
        ...

    async def ensure_connected(self) -> None:
        """确保底层存储连接可用（供需要连接管理的实现使用）。

        默认实现为空操作，Prisma 等需要连接管理的实现应覆盖此方法。
        """
