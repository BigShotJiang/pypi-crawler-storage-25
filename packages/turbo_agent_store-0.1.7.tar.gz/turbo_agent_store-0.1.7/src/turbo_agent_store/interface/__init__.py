"""
Core 模块存储抽象层

提供各类存储的抽象接口，包括：
- TurboEntityStore: TurboEntity 继承类（Agent, Character, Tool, LLMModel）的配置存储
  资源定位方式：belongToProjectId + name_id
- JobStore: 任务作业类（Job, JobTask, TaskSpec）的配置存储
- ResourceEntityStore: 资源类（Project, KnowledgeResource, Workset, BusinessSetting, Secret, ModelInstance）的配置存储
- StateStore: 状态类（Conversation, Message, Action, ReActRound, ToolCallRecord, JobTaskState）的配置存储
- ExternalStore: 外部服务类（Platform, AuthMethod, McpServerSpec, McpResourceDescriptor）的配置存储
- ResourceStore: KnowledgeResource 文件存储抽象
- ResourceInfo: 资源文件信息数据类
"""

from .assembler import TurboEntityAssembler
from .entity import TurboEntityLocator, TurboEntityStore
from .external import ExternalStore
from .file import BaseFileStore
from .job import JobStore
from .permission import PermissionStore
from .persistence import (
  BasePersistence,
  BindingRelation,
)
from .resource import KnowledgeResourceStorageKind, KnowledgeResourceUploadSpec, ResourceEntityStore, ResourceInfo, ResourceStore
from .runtime import RuntimeStore
from .state import StateStore

__all__ = [
  "BasePersistence",
  "BindingRelation",
  "TurboEntityAssembler",
  "BaseFileStore",
  "ExternalStore",
  "JobStore",
  "PermissionStore",
  "KnowledgeResourceStorageKind",
  "KnowledgeResourceUploadSpec",
  "ResourceEntityStore",
  "ResourceInfo",
  "ResourceStore",
  "RuntimeStore",
  "StateStore",
  "TurboEntityLocator",
  "TurboEntityStore",
]
