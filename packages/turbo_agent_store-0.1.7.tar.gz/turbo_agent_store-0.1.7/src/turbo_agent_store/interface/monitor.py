"""
Runtime 监控器抽象接口 (BaseRuntimeMonitor)

定义了 Runtime 事件监控器的统一接口，所有具体实现（Redis/Direct）均须继承此基类。

核心方法：
  - start(): 启动监控器（初始化后台写入协程等）
  - close(): 关闭监控器（排空队列、释放资源）
  - write(event): 非阻塞写入单个事件
  - monitor_stream(factory): 便捷方法，包装流式工厂函数，自动拦截每个 yield 的事件
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import AsyncIterator, Callable

from turbo_agent_core.schema.events import BaseEvent


class BaseRuntimeMonitor(ABC):
    """Runtime 监控器抽象基类。

    实现者：
      - RedisRuntimeMonitor：事件写入 Redis Stream（供云端消费者归档）
      - DirectRuntimeMonitor：事件直接写入 StateStore（本地/轻量场景）
    """
    
    @abstractmethod
    def start(self) -> None:
        """启动监控器（初始化后台写入协程等资源）。"""
        ...
    
    @abstractmethod
    async def close(self) -> None:
        """关闭监控器（排空队列、取消后台任务、释放资源）。"""
        ...
    
    @abstractmethod
    def write(self, event: BaseEvent) -> None:
        """非阻塞写入单个事件。"""
        ...

    def monitor_stream(
        self,
        factory: Callable[..., AsyncIterator[BaseEvent]],
    ) -> Callable[..., AsyncIterator[BaseEvent]]:
        """便捷方法：包装一个流式工厂函数，自动拦截每个 yield 的事件并写入监控器。"""
        async def wrapped(*args, **kwargs) -> AsyncIterator[BaseEvent]:
            async for event in factory(*args, **kwargs):
                self.write(event)
                yield event

        return wrapped
