"""
Redis Stream 运行时事件监控器 (RedisRuntimeMonitor)

基于 Redis Stream 实现的事件写入器，将 runtime 产生的事件写入 Redis Stream，
供下游的 EventStreamConsumer 消费并归档落库。

事件写入策略：
  - 每个事件写入 trace 专属流：ta.result.lifecycle.{trace_id}
  - 根级生命周期事件（run.lifecycle.*）额外镜像写入全局发现流：ta.result.lifecycle
  - 异步队列模式：事件先进入内存队列，由后台 writer 循环写入 Redis
"""
from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from typing import Optional

from loguru import logger
from redis.asyncio import Redis

from turbo_agent_core.schema.events import BaseEvent
from turbo_agent_store.interface.monitor import BaseRuntimeMonitor

from .constants import GLOBAL_LIFECYCLE_STREAM_KEY, trace_lifecycle_stream_key


@dataclass
class MonitorConfig:
    """RuntimeMonitor 配置，定义 Redis Stream key 的命名规则。"""

    # 全局发现流 key，用于发现新的 trace
    global_lifecycle_stream_key: str = GLOBAL_LIFECYCLE_STREAM_KEY
    # trace 专属流 key 生成函数
    trace_lifecycle_stream_key_fn = staticmethod(trace_lifecycle_stream_key)


@dataclass
class _PendingWrite:
    """待写入的事件包装，缓存在内存队列中等待异步写入 Redis。"""
    stream: str       # 目标 Redis Stream key
    event_json: str   # 序列化后的事件 JSON 字符串


class RedisRuntimeMonitor(BaseRuntimeMonitor):
    """基于 Redis Stream 的 Runtime 事件监控器。

    采用生产者-消费者模式：
      - write() 同步将事件放入内存队列（非阻塞）
      - _writer_loop() 后台协程循环从队列取出事件并通过 XADD 写入 Redis Stream
    """

    def __init__(self, redis_client: Redis, queue_maxsize: int = 5000, config: Optional[MonitorConfig] = None):
        self._redis = redis_client
        self._queue: asyncio.Queue[_PendingWrite] = asyncio.Queue(maxsize=queue_maxsize)  # 内存缓冲队列
        self._writer_task: Optional[asyncio.Task[None]] = None  # 后台写入协程
        self._config = config or MonitorConfig()

    def start(self) -> None:
        """启动后台写入协程（幂等，可安全重复调用）。"""
        if self._writer_task is None or self._writer_task.done():
            self._writer_task = asyncio.create_task(self._writer_loop())

    async def close(self) -> None:
        """关闭监控器：等待队列排空（最多 5 秒），然后取消写入协程。"""
        if self._writer_task is None:
            return

        try:
            await asyncio.wait_for(self._queue.join(), timeout=5.0)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            logger.warning("RedisRuntimeMonitor close timeout, some events might be lost")

        self._writer_task.cancel()
        try:
            await self._writer_task
        except asyncio.CancelledError:
            pass

    async def _writer_loop(self) -> None:
        """后台写入循环：从内存队列取出事件，通过 XADD 写入 Redis Stream。"""
        while True:
            item = await self._queue.get()
            try:
                msg_id = await self._redis.xadd(item.stream, {"event": item.event_json})
                logger.info(
                    "[RedisRuntimeMonitor] 成功写入事件到 Redis: stream={} msg_id={} event_json={}",
                    item.stream,
                    msg_id,
                    item.event_json,
                )
            except Exception as e:
                logger.warning("RuntimeMonitor 写入 Redis Stream 失败：stream={}, 错误={}", item.stream, e)
            finally:
                self._queue.task_done()

    def _enqueue(self, stream: str, event: BaseEvent) -> None:
        """将事件序列化并放入内存队列，队列满时丢弃事件并警告。"""
        try:
            payload = json.dumps(event.model_dump(mode="json"), ensure_ascii=False)
            self._queue.put_nowait(_PendingWrite(stream=stream, event_json=payload))
            logger.info("[RedisRuntimeMonitor] Enqueued event: type={} trace_id={} stream={}", event.type, event.trace_id, stream)
        except asyncio.QueueFull:
            logger.warning("RuntimeMonitor 写入队列已满，丢弃事件：type={}, trace_id={}", event.type, event.trace_id)

    def write(self, event: BaseEvent) -> None:
        """写入事件到监控器（非阻塞）。

        路由策略：
          1. 所有事件 → trace 专属流 ta.result.lifecycle.{trace_id}
          2. 根级生命周期事件（无 trace_path） → 额外镜像到全局发现流
        """
        self.start()
        self._enqueue(self._config.trace_lifecycle_stream_key_fn(event.trace_id), event)
        if str(event.type).startswith("run.lifecycle") and not event.trace_path:
            self._enqueue(self._config.global_lifecycle_stream_key, event)