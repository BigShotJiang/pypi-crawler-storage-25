# coding=utf-8
"""
Redis Stream key 常量定义。

定义了流式归档链路中所有 Redis Stream 的 key 命名规则：
  - 全局发现流：ta.result.lifecycle
    用于 EventStreamConsumer 发现新 trace（仅包含 run.lifecycle.created 事件）
  - trace 专属流：ta.result.lifecycle.{trace_id}
    包含该 trace 的所有事件，由 DataStreamConsumer 消费
"""

from __future__ import annotations

# 全局生命周期事件流 key：仅镜像根级 run.lifecycle.* 事件，用于发现新 trace
GLOBAL_LIFECYCLE_STREAM_KEY = "ta.result.lifecycle"


def trace_lifecycle_stream_key(trace_id: str) -> str:
    """生成 trace 专属的 Redis Stream key，包含该 trace 的所有事件。"""
    return f"ta.result.lifecycle.{trace_id}"