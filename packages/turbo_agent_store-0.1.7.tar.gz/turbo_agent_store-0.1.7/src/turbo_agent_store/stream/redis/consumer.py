# coding=utf-8
"""
Redis Stream 事件消费器模块 (Event Stream Consumer)

本模块实现了流式归档链路的消费端，从 Redis Stream 中读取 runtime worker
产生的事件，通过 ExecutionArchiver 聚合并落库到 StateStore。

架构位置：
  runtime worker → RedisRuntimeMonitor → Redis Stream
                                                  ↓
  EventStreamConsumer (监听全局流) → 发现新 trace
    ↓
  DataStreamConsumer (监听 trace 专属流) → ExecutionArchiver → StateStore

核心设计：
  - 两级消费者结构：EventStreamConsumer 为主消费者，监听全局发现流；
    发现新 trace 后拉起 DataStreamConsumer 子消费者单独消费该 trace 的事件流
  - 分布式锁：通过 Redis key 实现 trace 级别的分布式锁，避免多实例重复处理
  - 消费者组：使用 Redis XREADGROUP + ConsumerGroup 保证消息不丢失
  - Pending 恢复：启动时自动处理未 ACK 的历史消息，并通过 XAUTOCLAIM 认领超时消息
"""
from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional, Set
from uuid import uuid4

from loguru import logger
from redis.asyncio import Redis
from redis.exceptions import ResponseError

from turbo_agent_core.schema.events import BaseEvent
from turbo_agent_store.interface import StateStore
from turbo_agent_store.stream.execution import ExecutionArchiver

from .constants import GLOBAL_LIFECYCLE_STREAM_KEY, trace_lifecycle_stream_key


def _trace_lock_key(trace_id: str) -> str:
    """生成 trace 级别分布式锁的 Redis key。"""
    return f"ta.store.lock.trace.{trace_id}"


# Lua 脚本：原子性续期分布式锁（仅当锁值匹配时刷新 TTL）
_LOCK_RENEW_LUA = """
if redis.call('GET', KEYS[1]) == ARGV[1] then
    return redis.call('PEXPIRE', KEYS[1], ARGV[2])
else
    return 0
end
"""

# Lua 脚本：原子性释放分布式锁（仅当锁值匹配时删除）
_LOCK_RELEASE_LUA = """
if redis.call('GET', KEYS[1]) == ARGV[1] then
    return redis.call('DEL', KEYS[1])
else
    return 0
end
"""


def _parse_event(fields: Dict[Any, Any]) -> Optional[BaseEvent]:
    """从 Redis Stream 消息的 fields 中解析出 BaseEvent 对象。

    fields 中的 "event" 字段存储了序列化的 JSON 字符串，
    该函数负责解码和 schema 校验。
    """
    raw = fields.get("event")
    if raw is None:
        raw = fields.get(b"event")
    if raw is None:
        return None

    if isinstance(raw, (bytes, bytearray)):
        raw = raw.decode("utf-8", errors="ignore")

    try:
        data = json.loads(raw)
    except Exception as e:
        logger.warning("事件 JSON 解析失败：{}", e)
        return None

    try:
        return BaseEvent.model_validate(data)
    except Exception as e:
        logger.warning("事件 schema 校验失败：{}", e)
        return None


def _normalize_stream_id(value: Any) -> str:
    """将 Redis 返回的 stream ID 统一转为字符串格式（处理 bytes/None 情况）。"""
    if isinstance(value, (bytes, bytearray)):
        return value.decode("utf-8", errors="ignore")
    if value is None:
        return ""
    return str(value)


async def _ensure_consumer_group(redis: Redis, stream: str, group: str) -> None:
    """确保 Redis Stream 的消费者组存在，从 stream 起始位置开始消费。"""
    await _ensure_consumer_group_from(redis=redis, stream=stream, group=group, start_id="0")


async def _ensure_consumer_group_from(*, redis: Redis, stream: str, group: str, start_id: str) -> None:
    """确保 Redis Stream 的消费者组存在，从指定 ID 开始消费。

    BUSYGROUP 错误表示组已存在，属于正常情况，静默忽略。
    """
    try:
        await redis.xgroup_create(name=stream, groupname=group, id=start_id, mkstream=True)
        logger.info("已创建消费者组：stream={}, group={}", stream, group)
    except ResponseError as e:
        if "BUSYGROUP" in str(e):
            return
        raise


@dataclass
class ConsumerConfig:
    """事件流消费者配置。"""
    group: str = "ta.store.archive"           # Redis 消费者组名
    consumer: str = ""                        # 消费者名称（空则自动生成）
    consumer_prefix: str = "consumer"         # 自动生成消费者名的前缀
    consumer_instance_id: str = ""            # 实例 ID（空则使用随机 UUID 片段）
    lock_owner: str = ""                      # 分布式锁的拥有者标识
    block_ms: int = 1000                      # XREADGROUP 阻塞等待时间（毫秒）
    count: int = 100                          # 每次读取的最大消息数
    flush_interval_s: float = 2.0             # 归档器节流间隔（秒）
    pending_check_interval_s: float = 30.0    # Pending 消息检查间隔（秒）
    trace_lock_ttl_ms: int = 5 * 60 * 1000    # trace 分布式锁 TTL（5 分钟）
    trace_lock_renew_s: float = 10.0          # trace 锁续期间隔（秒）


def _resolve_consumer_name(config: ConsumerConfig) -> str:
    """解析消费者名称：若未显式配置，则按 '{prefix}-{instance_id}' 格式自动生成。"""
    if config.consumer:
        return config.consumer

    instance_id = config.consumer_instance_id or uuid4().hex[:8]
    prefix = config.consumer_prefix or "consumer"
    return f"{prefix}-{instance_id}"


class EventStreamConsumer:
    """主消费者：监听全局发现流，发现新 trace_id 后拉起 DataStreamConsumer 子消费者。

    工作流程：
      1. 监听全局流 ta.result.lifecycle，等待 run.lifecycle.created 事件
      2. 收到新 trace 后尝试获取分布式锁（避免多实例重复处理）
      3. 获锁成功后创建 DataStreamConsumer 异步任务，独立消费该 trace 的事件流
      4. 子消费者完成后自动 ACK 全局流消息并更新锁状态

    容错机制：
      - 启动时先处理当前消费者的 Pending 消息（重启恢复）
      - 定期通过 XAUTOCLAIM 认领其他实例超时未 ACK 的消息（故障转移）
      - suspended 状态的 trace 锁允许被其他实例重新获取
    """

    def __init__(self, redis: Redis, state_store: StateStore, config: Optional[ConsumerConfig] = None):
        self.redis = redis
        self.state_store = state_store
        self.config = config or ConsumerConfig()
        if not self.config.consumer:
            self.config.consumer = _resolve_consumer_name(self.config)

        self._running = False
        self._trace_tasks: Dict[str, asyncio.Task[None]] = {}           # trace_id -> DataStreamConsumer 异步任务
        self._known_traces: Set[str] = set()                            # 已知的 trace 集合（避免重复拉起）
        self._trace_locks: Dict[str, str] = {}                          # trace_id -> lock_value 映射
        self._trace_created_message_ids: Dict[str, str] = {}            # trace_id -> 全局流中 created 消息的 ID
        self._last_pending_check_mono: float = 0.0                      # 上次 Pending 检查的单调时钟

    async def run(self) -> None:
        """启动主消费循环：初始化消费者组 → 处理历史 Pending → 持续监听新事件。"""
        self._running = True
        stream = GLOBAL_LIFECYCLE_STREAM_KEY
        await _ensure_consumer_group(self.redis, stream, self.config.group)

        if hasattr(self.state_store, "connect"):
            await self.state_store.connect()

        logger.info(
            "EventStreamConsumer 启动：stream={}, group={}, consumer={}",
            stream,
            self.config.group,
            self.config.consumer,
        )

        await self._log_group_state(stream, stage="startup")

        logger.info("[EventStreamConsumer] 开始处理历史 Pending/可认领消息：stream={}", stream)
        await self._drain_pending(stream)
        logger.info("[EventStreamConsumer] 历史 Pending/可认领消息处理完成：stream={}", stream)

        while self._running:
            try:
                logger.debug(
                    "[EventStreamConsumer] 等待全局流事件：stream={}, group={}, consumer={}",
                    stream,
                    self.config.group,
                    self.config.consumer,
                )
                items = await self.redis.xreadgroup(
                    groupname=self.config.group,
                    consumername=self.config.consumer,
                    streams={stream: ">"},
                    count=self.config.count,
                    block=self.config.block_ms,
                )
                if not items:
                    if self._should_run_pending_check():
                        logger.debug("[EventStreamConsumer] 本轮未收到新事件，转入 Pending 检查")
                        await self._drain_pending(stream)
                    continue

                logger.info("[EventStreamConsumer] xreadgroup 收到 {} 个流的数据", len(items))

                for _stream_name, messages in items:
                    for message_id, fields in messages:
                        should_ack = True
                        event = _parse_event(fields)
                        if event is None:
                            logger.warning("[EventStreamConsumer] 无法解析事件: msg_id={}", message_id)
                            await self.redis.xack(stream, self.config.group, message_id)
                            continue

                        logger.info("[EventStreamConsumer] 处理事件: type={} trace_id={}", event.type, event.trace_id)

                        if event.type == "run.lifecycle.created":
                            lifecycle = event
                            try:
                                if getattr(lifecycle, "trace_path", None):
                                    await self.redis.xack(stream, self.config.group, message_id)
                                    continue

                                start_id = None
                                try:
                                    if isinstance(message_id, (bytes, bytearray)):
                                        start_id = message_id.decode("utf-8", errors="ignore")
                                    elif isinstance(message_id, str):
                                        start_id = message_id
                                except Exception:
                                    start_id = None

                                lock_value = await self._try_acquire_trace_lock(trace_id=lifecycle.trace_id)
                                if not lock_value:
                                    logger.info("trace 正在被其他实例处理，稍后重试：trace_id={}", lifecycle.trace_id)
                                    should_ack = False
                                    continue

                                await self._start_trace_consumer(
                                    trace_id=lifecycle.trace_id,
                                    initial_created=lifecycle,
                                    start_stream_id=start_id,
                                    lock_value=lock_value,
                                    global_created_message_id=(
                                        message_id.decode("utf-8", errors="ignore")
                                        if isinstance(message_id, (bytes, bytearray))
                                        else str(message_id)
                                    ),
                                )
                                should_ack = False
                            except Exception as e:
                                logger.error("处理 created 事件失败，保留 Pending：trace_id={}, 错误={}", lifecycle.trace_id, e)
                                should_ack = False
                                continue

                        if should_ack:
                            await self.redis.xack(stream, self.config.group, message_id)
            except Exception as e:
                logger.error("EventStreamConsumer 循环异常: {}", e)
                await asyncio.sleep(1)

    def _should_run_pending_check(self) -> bool:
        """判断是否到达 Pending 消息检查的时间间隔。"""
        interval = max(1.0, float(getattr(self.config, "pending_check_interval_s", 30.0)))
        now = time.monotonic()
        if (now - self._last_pending_check_mono) < interval:
            return False
        self._last_pending_check_mono = now
        return True

    async def _log_group_state(self, stream: str, *, stage: str) -> None:
        """记录当前消费者组状态（用于调试和运维监控）。"""
        try:
            groups = await self.redis.xinfo_groups(stream)
            logger.info(
                "[EventStreamConsumer] 消费组状态 stage={} stream={} groups={}",
                stage,
                stream,
                groups,
            )
        except Exception as e:
            logger.warning(
                "[EventStreamConsumer] 读取消费组状态失败 stage={} stream={} error={}",
                stage,
                stream,
                e,
            )

    async def stop(self) -> None:
        """停止主消费者：取消所有子任务、释放分布式锁、断开 StateStore 连接。"""
        self._running = False
        for task in list(self._trace_tasks.values()):
            task.cancel()
        await asyncio.gather(*self._trace_tasks.values(), return_exceptions=True)
        self._trace_tasks.clear()
        for trace_id, lock_value in list(self._trace_locks.items()):
            try:
                await self._release_trace_lock(trace_id=trace_id, lock_value=lock_value)
            except Exception:
                pass
        self._trace_locks.clear()
        if hasattr(self.state_store, "disconnect"):
            await self.state_store.disconnect()

    async def _start_trace_consumer(
        self,
        *,
        trace_id: str,
        initial_created: BaseEvent,
        start_stream_id: Optional[str],
        lock_value: str,
        global_created_message_id: str,
    ) -> None:
        """为新发现的 trace 拉起一个 DataStreamConsumer 子消费者异步任务。

        子任务完成后通过 _cleanup 回调自动执行清理：
          - 成功：ACK 全局流消息，更新锁状态为 completed
          - 失败：更新锁状态为 failed
          - 取消：更新锁状态为 suspended，允许其他实例重新获取
        """
        if trace_id in self._known_traces:
            return
        self._known_traces.add(trace_id)

        self._trace_locks[trace_id] = lock_value
        self._trace_created_message_ids[trace_id] = global_created_message_id

        consumer = DataStreamConsumer(
            redis=self.redis,
            trace_id=trace_id,
            state_store=self.state_store,
            initial_created=initial_created,
            start_stream_id=start_stream_id,
            lock_value=lock_value,
            config=self.config,
            parent=self,
        )
        task = asyncio.create_task(consumer.run(), name=f"data-consumer-{trace_id}")

        def _cleanup(_t: asyncio.Task[None]) -> None:
            async def _finalize() -> None:
                final_status = "completed"
                try:
                    if _t.cancelled():
                        final_status = "suspended"
                        logger.warning("Trace {} consumer task cancelled (suspended).", trace_id)
                    elif _t.exception():
                        final_status = "failed"
                        logger.error("Trace {} consumer task failed: {}", trace_id, _t.exception())

                    if final_status == "completed":
                        created_mid = self._trace_created_message_ids.get(trace_id)
                        if created_mid:
                            await self.redis.xack(GLOBAL_LIFECYCLE_STREAM_KEY, self.config.group, created_mid)
                except Exception as e:
                    logger.error("Error during trace cleanup: {}", e)
                finally:
                    await self._update_trace_lock_status(trace_id=trace_id, status=final_status)

                    self._trace_created_message_ids.pop(trace_id, None)
                    self._trace_locks.pop(trace_id, None)
                    if self._trace_tasks.get(trace_id) == _t:
                        self._trace_tasks.pop(trace_id, None)

                    if final_status == "suspended":
                        self._known_traces.discard(trace_id)

            asyncio.create_task(_finalize())

        task.add_done_callback(_cleanup)
        self._trace_tasks[trace_id] = task
        logger.info("已拉起 DataStreamConsumer：trace_id={}", trace_id)

    async def _try_acquire_trace_lock(self, *, trace_id: str) -> str:
        """尝试获取 trace 级别的分布式锁。

        锁结构为 JSON，包含 consumer、owner、timestamp、status 字段。
        若锁已存在且状态为 suspended，允许删除后重新获取（故障恢复场景）。
        返回锁值字符串（获取成功）或空字符串（获取失败）。
        """
        lock_key = _trace_lock_key(trace_id)

        existing_lock = await self.redis.get(lock_key)
        if existing_lock:
            try:
                lock_data = json.loads(existing_lock)
                lock_status = lock_data.get("status", "processing")

                if lock_status == "suspended":
                    logger.info("[锁状态] Trace {} 状态为 suspended，允许重新获取锁", trace_id)
                    await self.redis.delete(lock_key)
                else:
                    logger.debug("[锁状态] Trace {} 状态为 {}，拒绝获取锁", trace_id, lock_status)
                    return ""
            except (json.JSONDecodeError, Exception) as e:
                logger.warning("[锁状态] 锁格式错误，删除重试: {}", e)
                await self.redis.delete(lock_key)

        lock_data = {
            "consumer": self.config.consumer,
            "owner": self.config.lock_owner or self.config.consumer,
            "timestamp": int(time.time() * 1000),
            "status": "processing",
        }
        lock_value = json.dumps(lock_data)
        ttl_ms = int(getattr(self.config, "trace_lock_ttl_ms", 5 * 60 * 1000))

        ok = await self.redis.set(lock_key, lock_value, nx=True, px=ttl_ms)
        return lock_value if ok else ""

    async def _update_trace_lock_status(self, *, trace_id: str, status: str) -> None:
        """更新 trace 锁的状态字段（如 completed / failed / suspended）。

        completed/suspended 状态的锁 TTL 延长到 24 小时（防止被误认为可用）。
        """
        lock_key = _trace_lock_key(trace_id)
        existing_lock = await self.redis.get(lock_key)
        if existing_lock:
            try:
                lock_data = json.loads(existing_lock)
                lock_data["status"] = status
                lock_data["updated_at"] = int(time.time() * 1000)
                if status in ("completed", "suspended"):
                    ttl_ms = 24 * 60 * 60 * 1000
                else:
                    ttl_ms = await self.redis.pttl(lock_key)
                    if ttl_ms <= 0:
                        ttl_ms = 5 * 60 * 1000
                await self.redis.set(lock_key, json.dumps(lock_data), px=ttl_ms)
                logger.info("[锁状态] 更新 Trace {} 锁状态为: {}, TTL: {}ms", trace_id, status, ttl_ms)
            except Exception as e:
                logger.warning("[锁状态] 更新锁状态失败: {}", e)

    async def _release_trace_lock(self, *, trace_id: str, lock_value: str) -> None:
        """释放 trace 分布式锁（通过 Lua 脚本保证原子性）。"""
        lock_key = _trace_lock_key(trace_id)
        try:
            await self.redis.eval(_LOCK_RELEASE_LUA, 1, lock_key, lock_value)
        finally:
            if self._trace_locks.get(trace_id) == lock_value:
                self._trace_locks.pop(trace_id, None)

    async def _drain_pending(self, stream: str) -> None:
        """处理当前消费者的 Pending 消息和认领其他消费者超时未 ACK 的消息。

        分两个阶段：
          1. XREADGROUP 读取本消费者的 Pending 消息（id='0'）
          2. XAUTOCLAIM 认领其他消费者超过 60 秒未 ACK 的消息
        """
        try:
            logger.debug(
                "[EventStreamConsumer] 检查当前消费者 Pending：stream={}, group={}, consumer={}",
                stream,
                self.config.group,
                self.config.consumer,
            )
            items = await self.redis.xreadgroup(
                groupname=self.config.group,
                consumername=self.config.consumer,
                streams={stream: "0"},
                count=self.config.count,
                block=1,
            )
            pending_count = sum(len(messages) for _stream_name, messages in (items or []))
            if pending_count:
                logger.info(
                    "[EventStreamConsumer] 当前消费者 Pending 检查完成：stream={} pending_count={}",
                    stream,
                    pending_count,
                )
            for _stream_name, messages in items or []:
                for message_id, fields in messages:
                    await self._process_pending_msg(stream, message_id, fields)
        except Exception as e:
            logger.warning("Drain pending (self) failed: {}", e)

        start_id = "0-0"
        while True:
            try:
                normalized_start_id = _normalize_stream_id(start_id) or "0-0"
                res = await self.redis.xautoclaim(
                    name=stream,
                    groupname=self.config.group,
                    consumername=self.config.consumer,
                    min_idle_time=60000,
                    start_id=normalized_start_id,
                    count=self.config.count,
                )
                if not isinstance(res, (list, tuple)) or len(res) < 2:
                    break

                next_start_id = _normalize_stream_id(res[0]) or "0-0"
                raw_messages = res[1] or []

                if raw_messages:
                    logger.info(
                        "[EventStreamConsumer] XAUTOCLAIM 认领到 {} 条消息：stream={}, start_id={}",
                        len(raw_messages),
                        stream,
                        normalized_start_id,
                    )

                for mid, fields in raw_messages:
                    await self._process_pending_msg(stream, mid, fields)

                if not raw_messages and (next_start_id == "0-0" or next_start_id == normalized_start_id):
                    break
                start_id = next_start_id
            except Exception as e:
                logger.warning("Drain pending (autoclaim) failed: {}", e)
                break

    async def _process_pending_msg(self, stream: str, message_id: Any, fields: Dict[Any, Any]) -> None:
        """处理单条 Pending 消息：仅处理 run.lifecycle.created 事件，其余直接 ACK。"""
        event = _parse_event(fields)
        if event is None:
            await self.redis.xack(stream, self.config.group, message_id)
            return

        logger.info(
            "[EventStreamConsumer] 处理 Pending 消息：msg_id={} type={} trace_id={}",
            message_id,
            event.type,
            event.trace_id,
        )

        if event.type != "run.lifecycle.created":
            await self.redis.xack(stream, self.config.group, message_id)
            return

        lifecycle = event
        if getattr(lifecycle, "trace_path", None):
            await self.redis.xack(stream, self.config.group, message_id)
            return

        if lifecycle.trace_id in self._trace_tasks and not self._trace_tasks[lifecycle.trace_id].done():
            logger.info("[EventStreamConsumer] Trace {} 正在处理中 (local)，视为重复消息并 ACK: {}", lifecycle.trace_id, message_id)
            await self.redis.xack(stream, self.config.group, message_id)
            return

        lock_value = await self._try_acquire_trace_lock(trace_id=lifecycle.trace_id)
        if not lock_value:
            logger.debug("[EventStreamConsumer] 无法获取锁，ACK 消息: trace_id={}", lifecycle.trace_id)
            await self.redis.xack(stream, self.config.group, message_id)
            return

        start_id = None
        try:
            if isinstance(message_id, (bytes, bytearray)):
                start_id = message_id.decode("utf-8", errors="ignore")
            elif isinstance(message_id, str):
                start_id = message_id
        except Exception:
            start_id = None

        await self._start_trace_consumer(
            trace_id=lifecycle.trace_id,
            initial_created=lifecycle,
            start_stream_id=start_id,
            lock_value=lock_value,
            global_created_message_id=(
                message_id.decode("utf-8", errors="ignore")
                if isinstance(message_id, (bytes, bytearray))
                else str(message_id)
            ),
        )


class DataStreamConsumer:
    """子消费者：消费单个 Trace 的 Redis 事件流，并通过 ExecutionArchiver 落库。

    每个 DataStreamConsumer 对应一个 trace_id，由 EventStreamConsumer 拉起。

    工作流程：
      1. 初始化时创建 ExecutionArchiver（持有 EventTreeAggregator）
      2. 先处理 initial_created 事件（创建根节点）
      3. 处理 Pending 消息（恢复场景）
      4. 持续监听 trace 专属流 ta.result.lifecycle.{trace_id}
      5. 每条事件送入 archiver.on_event()，由归档器决定何时落库
      6. 检测到根节点 is_closed 时结束消费，强制 flush 保证数据完整

    分布式锁续期：
      后台协程定期续期 trace 锁，防止长时间任务导致锁超时被其他实例抢占。
    """

    def __init__(
        self,
        redis: Redis,
        trace_id: str,
        state_store: StateStore,
        initial_created: BaseEvent,
        start_stream_id: Optional[str],
        lock_value: str = "",
        config: Optional[ConsumerConfig] = None,
        parent: Optional[EventStreamConsumer] = None,
    ):
        self.redis = redis
        self.trace_id = trace_id
        self.state_store = state_store
        self.config = config or ConsumerConfig()
        self.parent = parent
        if not self.config.consumer:
            self.config.consumer = _resolve_consumer_name(self.config)

        self._running = False
        self._start_stream_id = start_stream_id             # 起始 stream ID（可能从全局流消息 ID 推导）
        self._initial_created = initial_created             # 触发此消费者的 run.lifecycle.created 事件
        self._lock_key = _trace_lock_key(trace_id)          # 分布式锁的 Redis key
        self._lock_value = lock_value                       # 分布式锁值（用于续期和释放）
        self._lock_renew_task: Optional[asyncio.Task[None]] = None  # 锁续期后台协程

        # 创建归档器，负责事件聚合和按节流策略落库
        self.archiver = ExecutionArchiver(
            trace_id=trace_id,
            state_store=state_store,
            flush_interval_s=self.config.flush_interval_s,
        )
        # 共享归档器的聚合器引用，便于外部查看聚合状态
        self.aggregator = self.archiver.aggregator

        self._stream_name: Optional[str] = None

    async def run(self) -> None:
        """启动子消费器主循环：初始化 → 处理 Pending → 持续消费 trace 专属流。"""
        self._running = True
        stream = trace_lifecycle_stream_key(self.trace_id)
        self._stream_name = stream

        # 启动分布式锁续期后台协程
        if self.redis is not None and self._lock_value:
            self._lock_renew_task = asyncio.create_task(self._renew_lock_loop(), name=f"trace-lock-renew-{self.trace_id}")

        # 计算消费者组的起始位置：从全局流消息 ID 推导出对应的毫秒时间戳
        start_id = "0"
        if self._start_stream_id:
            try:
                ms = str(self._start_stream_id).split("-", 1)[0]
                start_id = f"{ms}-0"
            except Exception:
                start_id = "0"

        await _ensure_consumer_group_from(redis=self.redis, stream=stream, group=self.config.group, start_id=start_id)

        try:
            await self.handle_event(self._initial_created)
        except Exception as e:
            logger.error("initial_created 处理失败：trace_id={}, 错误={}", self.trace_id, e)

        await self._drain_pending(stream)

        try:
            while self._running:
                try:
                    items = await self.redis.xreadgroup(
                        groupname=self.config.group,
                        consumername=self.config.consumer,
                        streams={stream: ">"},
                        count=self.config.count,
                        block=self.config.block_ms,
                    )
                    if not items:
                        continue

                    for _stream_name, messages in items:
                        for message_id, fields in messages:
                            logger.info("DataStreamConsumer 收到事件: trace_id={}, message_id={}", self.trace_id, fields)
                            trace_completed = await self._process_message(stream, message_id, fields, check_completion=True)
                            if trace_completed:
                                self._running = False
                                break
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    logger.error("Trace loop error: {}", e)
                    if self.parent is not None:
                        try:
                            await self.parent._update_trace_lock_status(trace_id=self.trace_id, status="failed")
                        except Exception:
                            pass
                    await asyncio.sleep(1)
        finally:
            logger.info("DataStreamConsumer flushing on exit: trace_id={}", self.trace_id)
            await self.archiver.force_flush()

            if self._lock_renew_task:
                self._lock_renew_task.cancel()
                await asyncio.gather(self._lock_renew_task, return_exceptions=True)

    async def _process_message(self, stream: str, message_id: Any, fields: Dict[str, Any], *, check_completion: bool = False) -> bool:
        """处理单条事件消息：解析 → 送入归档器 → ACK → 检查是否 trace 已完成。

        check_completion=True 时，归档后检查根节点是否已关闭，若已完成则返回 True 触发消费器退出。
        """
        event = _parse_event(fields)
        if event is None:
            await self.redis.xack(stream, self.config.group, message_id)
            return False

        try:
            logger.info("Processing event: trace_id={}, type={}, event={}", self.trace_id, event.type, event)
            await self.handle_event(event)
        except Exception as e:
            logger.error("事件 handle 失败：trace_id={}, type={}, 错误={}", self.trace_id, event.type, e)

        await self._ack_message(message_id)

        if check_completion:
            root_snapshot = self.archiver.aggregator.snapshot_root()
            if root_snapshot and root_snapshot.is_closed:
                logger.info("Trace Completed: trace_id={}", self.trace_id)

                final_status = getattr(root_snapshot, "status", "completed")
                if self.parent is not None:
                    if str(final_status) == "suspended":
                        await self.parent._update_trace_lock_status(trace_id=self.trace_id, status="suspended")
                    elif str(final_status) in ["failed", "error"]:
                        await self.parent._update_trace_lock_status(trace_id=self.trace_id, status="failed")
                    else:
                        await self.parent._update_trace_lock_status(trace_id=self.trace_id, status="completed")

                return True
        return False

    async def _drain_pending(self, stream: str) -> None:
        try:
            items = await self.redis.xreadgroup(
                groupname=self.config.group,
                consumername=self.config.consumer,
                streams={stream: "0"},
                count=self.config.count,
                block=1,
            )
        except Exception:
            return

        for _stream_name, messages in items or []:
            for message_id, fields in messages:
                await self._process_message(stream, message_id, fields, check_completion=False)

    async def handle_event(self, event: BaseEvent) -> None:
        """将事件送入归档器处理，并打印各节点的聚合状态（调试用）。"""
        await self.archiver.on_event(event)
        for node in self.aggregator.iter_nodes_post_order():
            logger.debug(
                "事件处理结束 handled: trace_id={}, type={} node_id={} snapshot={}",
                self.trace_id,
                event.type,
                node.trace_id,
                node.snapshot(),
            )

    async def _ack_message(self, message_id: Any) -> None:
        """确认消息已处理（XACK），从消费者组的 Pending 列表中移除。"""
        if self.redis is not None and self._stream_name:
            await self.redis.xack(self._stream_name, self.config.group, message_id)

    async def flush_now(self) -> None:
        """立即强制归档器落库（供外部调用）。"""
        await self.archiver.force_flush()

    async def _renew_lock_loop(self) -> None:
        """后台协程：定期续期 trace 分布式锁，防止长时间任务导致锁超时。"""
        interval = float(getattr(self.config, "trace_lock_renew_s", 10.0))
        ttl_ms = str(int(getattr(self.config, "trace_lock_ttl_ms", 5 * 60 * 1000)))
        while self._running:
            try:
                await self.redis.eval(_LOCK_RENEW_LUA, 1, self._lock_key, self._lock_value, ttl_ms)
            except Exception:
                pass
            await asyncio.sleep(interval)