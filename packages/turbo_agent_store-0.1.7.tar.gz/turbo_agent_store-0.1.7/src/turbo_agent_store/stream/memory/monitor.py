"""
直连 Store 的 Runtime 事件监控器 (DirectRuntimeMonitor)

不经过 Redis，直接将事件写入 StateStore 的内存模式监控器。
适用于桌面应用、具身客户端等无 Redis 的轻量化部署场景。

工作流程：
  1. 事件通过 write() 放入内存队列
  2. 后台协程从队列取出事件，按 trace_id 分发到对应的 ExecutionArchiver
  3. 归档器聚合后直接 flush 到 StateStore（每条事件都立即 flush）
"""
from __future__ import annotations

import asyncio
from typing import Dict, Optional

from loguru import logger

from turbo_agent_core.schema.events import BaseEvent
from turbo_agent_store.interface import StateStore
from turbo_agent_store.interface.monitor import BaseRuntimeMonitor

from turbo_agent_store.stream.execution import ExecutionArchiver


class DirectRuntimeMonitor(BaseRuntimeMonitor):
    """直接写入 Store 的 Runtime 事件监控器。

    与 RedisRuntimeMonitor 的对比：
      - RedisRuntimeMonitor：事件 → Redis Stream → EventStreamConsumer → ExecutionArchiver → StateStore
      - DirectRuntimeMonitor：事件 → 内存队列 → ExecutionArchiver → StateStore（跳过 Redis）

    每个 trace_id 自动创建独立的 ExecutionArchiver 实例。
    """

    def __init__(self, state_store: StateStore, queue_maxsize: int = 5000):
        self._state_store = state_store
        self._queue: asyncio.Queue[BaseEvent] = asyncio.Queue(maxsize=queue_maxsize)  # 内存事件队列
        self._writer_task: Optional[asyncio.Task[None]] = None  # 后台写入协程
        self._archivers: Dict[str, ExecutionArchiver] = {}  # trace_id -> 归档器实例

    def start(self) -> None:
        if self._writer_task is None or self._writer_task.done():
            self._writer_task = asyncio.create_task(self._writer_loop())

    async def close(self) -> None:
        for archiver in self._archivers.values():
            try:
                await archiver.flush()
            except Exception as e:
                logger.warning("DirectRuntimeMonitor 关闭前 flush 失败：错误={}", e)
        if self._writer_task is None:
            return
        self._writer_task.cancel()
        try:
            await self._writer_task
        except asyncio.CancelledError:
            pass

    async def _writer_loop(self) -> None:
        """后台写入循环：按 trace_id 分发事件到对应的归档器，每条事件立即 flush。"""
        while True:
            event = await self._queue.get()
            try:
                trace_id = event.trace_path[0] if event.trace_path else event.trace_id
                if trace_id not in self._archivers:
                    self._archivers[trace_id] = ExecutionArchiver(trace_id=trace_id, state_store=self._state_store)

                archiver = self._archivers[trace_id]
                await archiver.on_event(event)
                await archiver.flush()
            except Exception as e:
                logger.warning("DirectRuntimeMonitor 写入 Store 失败：trace_id={}, 错误={}", event.trace_id, e)
            finally:
                self._queue.task_done()

    def write(self, event: BaseEvent) -> None:
        """写入事件到监控器内存队列（非阻塞），队列满时丢弃并警告。"""
        self.start()
        try:
            self._queue.put_nowait(event)
        except asyncio.QueueFull:
            logger.warning("DirectRuntimeMonitor 写入队列已满，丢弃事件：type={}, trace_id={}", event.type, event.trace_id)