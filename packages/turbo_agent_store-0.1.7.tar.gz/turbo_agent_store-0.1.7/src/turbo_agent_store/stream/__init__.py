# coding=utf-8

"""事件流能力导出。

本包统一导出流式归档链路的所有公开组件：
  - 监控器 (Monitor)：负责拦截 runtime 产出的事件并写入目标通道
  - 消费者 (Consumer)：从 Redis Stream 读取事件并归档落库
  - 常量 (Constants)：Redis Stream key 命名规则
"""

from .redis import GLOBAL_LIFECYCLE_STREAM_KEY, trace_lifecycle_stream_key
from .redis import ConsumerConfig, DataStreamConsumer, EventStreamConsumer
from .monitor import (
    DirectRuntimeMonitor,
    MonitorConfig,
    RedisRuntimeMonitor,
    RuntimeMonitor,
    get_monitor,
    init_direct_monitor,
    init_runtime_monitor,
    monitor_class,
    monitor_execution,
    monitor_object,
    set_monitor_context,
)

__all__ = [
    "GLOBAL_LIFECYCLE_STREAM_KEY",
    "trace_lifecycle_stream_key",
    "ConsumerConfig",
    "EventStreamConsumer",
    "DataStreamConsumer",
    "MonitorConfig",
    "RedisRuntimeMonitor",
    "DirectRuntimeMonitor",
    "RuntimeMonitor",
    "init_runtime_monitor",
    "init_direct_monitor",
    "set_monitor_context",
    "get_monitor",
    "monitor_execution",
    "monitor_class",
    "monitor_object",
]