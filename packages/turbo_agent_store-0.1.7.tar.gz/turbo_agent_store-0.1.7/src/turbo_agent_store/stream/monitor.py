"""
Runtime 事件监控门面模块 (Monitor Facade)

本模块提供统一的 Runtime 监控器初始化、获取和装饰器 API，
是 runtime worker 侧拦截事件流并写入 Redis Stream / 直接写入 Store 的入口。

核心职责：
  1. 全局监控器管理：init_runtime_monitor (Redis) / init_direct_monitor (直连 Store)
  2. 上下文级监控器：通过 ContextVar 支持协程级别切换
  3. 装饰器 API：monitor_execution / monitor_class / monitor_object
     自动拦截 TurboEntity 的 stream/a_stream 方法，将产出的事件写入监控器

架构位置：
  runtime (执行智能体) → monitor_object/monitor_class 装饰 → _monitor_stream_wrapper
    → 拦截每个 BaseEvent → monitor.write(event) → Redis Stream / Store
"""
from __future__ import annotations

import functools
import inspect
import uuid
from contextvars import ContextVar
from datetime import datetime
from typing import Any, AsyncIterator, Awaitable, Callable, Dict, Optional, Type, TypeVar, Union

from loguru import logger
from redis.asyncio import Redis

from turbo_agent_core.schema.events import BaseEvent, UserInfo
from turbo_agent_store.interface import StateStore
from turbo_agent_store.interface.monitor import BaseRuntimeMonitor

from .memory.monitor import DirectRuntimeMonitor
from .redis.monitor import MonitorConfig, RedisRuntimeMonitor


T = TypeVar("T")

# 默认监控器类型为 Redis 模式
RuntimeMonitor = RedisRuntimeMonitor


# 全局单例监控器（进程级别，Worker 启动时初始化）
_monitor_global: Optional[BaseRuntimeMonitor] = None
# 协程上下文级监控器（支持每个协程/任务使用不同的监控器）
_monitor_ctx: ContextVar[Optional[BaseRuntimeMonitor]] = ContextVar("runtime_monitor", default=None)


def init_runtime_monitor(redis_url: str, config: Optional[MonitorConfig] = None) -> None:
    """在 Worker 启动时初始化全局监控器（Redis 模式）。"""
    global _monitor_global
    redis_client = Redis.from_url(redis_url, decode_responses=False)
    _monitor_global = RedisRuntimeMonitor(redis_client, config=config)
    _monitor_global.start()


def init_direct_monitor(state_store: StateStore) -> None:
    """初始化全局监控器（Direct 模式）。"""
    global _monitor_global
    _monitor_global = DirectRuntimeMonitor(state_store)
    _monitor_global.start()


def set_monitor_context(monitor: BaseRuntimeMonitor) -> None:
    """设置当前上下文的 Monitor。"""
    _monitor_ctx.set(monitor)


def get_monitor() -> BaseRuntimeMonitor:
    """获取当前可用的监控器实例。

    优先级：协程上下文级 > 全局级。若两者均未初始化则抛出 RuntimeError。
    """
    monitor = _monitor_ctx.get()
    if monitor is not None:
        return monitor
    if _monitor_global is not None:
        return _monitor_global
    raise RuntimeError("RuntimeMonitor 未初始化，请先调用 init_runtime_monitor 或 init_direct_monitor")


def monitor_execution(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
    """监控一个协程函数的执行。"""

    @functools.wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> T:
        run_id = str(uuid.uuid4())
        start_time = datetime.now()
        try:
            result = await func(*args, **kwargs)
            _ = (run_id, start_time)
            return result
        except Exception:
            _ = (run_id, start_time)
            raise

    return wrapper


def monitor_class(cls: Optional[Type] = None, *, user_info: Optional[Union[UserInfo, Dict[str, Any]]] = None) -> Any:
    """类装饰器：自动为 TurboEntity 的 stream/a_stream 方法添加监控拦截。

    使用方式：
      @monitor_class
      class MyAgent(TurboEntity): ...

      @monitor_class(user_info={"id": "..."})
      class MyAgent(TurboEntity): ...
    """

    def _process(inner_cls: Type) -> Type:
        parsed_user = None
        if user_info:
            if isinstance(user_info, UserInfo):
                parsed_user = user_info
            elif isinstance(user_info, dict):
                try:
                    parsed_user = UserInfo.model_validate(user_info)
                except Exception:
                    pass

        for name, method in inspect.getmembers(inner_cls):
            if name in {"stream", "a_stream"} and (inspect.isfunction(method) or inspect.iscoroutinefunction(method)):
                setattr(inner_cls, name, _monitor_stream_wrapper(method, bound_user_info=parsed_user))
        return inner_cls

    if cls is None:
        return _process
    return _process(cls)


def monitor_object(
    obj: Any,
    user_info: Optional[Union[UserInfo, Dict[str, Any]]] = None,
    override_trace_id: Optional[str] = None,
) -> Any:
    """对象级装饰器：在运行时动态为已创建的实体对象添加 stream/a_stream 监控。

    与 monitor_class 的区别在于：此函数作用于已实例化的对象，
    适用于无法在类定义时添加装饰器的场景（如动态构造的 Agent）。

    参数：
      obj: 需要监控的 TurboEntity 实例
      user_info: 可选的用户信息，注入到生命周期事件中
      override_trace_id: 可选，强制覆盖事件的 trace_id
    """
    parsed_user = None
    if user_info:
        if isinstance(user_info, UserInfo):
            parsed_user = user_info
        elif isinstance(user_info, dict):
            try:
                parsed_user = UserInfo.model_validate(user_info)
            except Exception:
                pass

    for name in {"stream", "a_stream"}:
        if hasattr(obj, name):
            method = getattr(obj, name)
            if inspect.ismethod(method) or inspect.isfunction(method) or inspect.iscoroutinefunction(method):
                wrapped = _monitor_stream_wrapper(
                    method,
                    bound_user_info=parsed_user,
                    override_trace_id=override_trace_id,
                )
                object.__setattr__(obj, name, wrapped)
    return obj


def _monitor_stream_wrapper(
    func: Callable[..., AsyncIterator[BaseEvent]],
    bound_user_info: Optional[UserInfo] = None,
    override_trace_id: Optional[str] = None,
) -> Callable[..., AsyncIterator[BaseEvent]]:
    """流式方法包装器：拦截 stream/a_stream 产出的每个事件并写入监控器。

    核心逻辑：
      1. 获取当前监控器（可能为空，此时仅透传事件）
      2. 尝试从 kwargs 中提取 user_info（用于生命周期事件的用户标注）
      3. 逐个 yield 原始事件，同时调用 monitor.write(event) 侧写到 Redis/Store
      4. 若指定了 override_trace_id，则覆盖事件的 trace_id（用于 job 场景统一标识）
    """
    @functools.wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> AsyncIterator[BaseEvent]:
        monitor = None
        try:
            monitor = get_monitor()
        except RuntimeError:
            pass

        logger.info(f"[_monitor_stream_wrapper] START wrapper for {func.__name__}, monitor={monitor}")

        user_info_obj: Optional[UserInfo] = None
        try:
            # 优先从 kwargs 中获取 user_info，其次从 config.user_info 获取
            raw_user = kwargs.get("user_info")
            if not raw_user:
                config = kwargs.get("config")
                if config and isinstance(config, dict):
                    raw_user = config.get("user_info")

            if raw_user:
                if isinstance(raw_user, UserInfo):
                    user_info_obj = raw_user
                elif isinstance(raw_user, dict):
                    user_info_obj = UserInfo.model_validate(raw_user)

            if not user_info_obj and bound_user_info:
                user_info_obj = bound_user_info
        except Exception:
            pass

        async for event in func(*args, **kwargs):
            # 若指定了 override_trace_id，强制覆盖事件的 trace_id
            if override_trace_id:
                object.__setattr__(event, "trace_id", override_trace_id)

            if monitor:
                try:
                    # 为生命周期事件注入用户信息（便于归档时识别用户）
                    if user_info_obj and str(event.type).startswith("run.lifecycle"):
                        if hasattr(event, "user_metadata"):
                            setattr(event, "user_metadata", user_info_obj)
                        elif hasattr(event, "user_info"):
                            setattr(event, "user_info", user_info_obj)

                    logger.info(f"[_monitor_stream_wrapper] Writing event to monitor: {event.type}")
                    monitor.write(event)
                except Exception as e:
                    logger.warning(f"RuntimeMonitor write failed: {e}")
            yield event

    return wrapper