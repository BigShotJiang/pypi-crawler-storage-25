# coding=utf-8
"""
流式归档执行器模块 (Execution Archiver)

本模块是流式归档链路的核心组件，负责将 Runtime 产生的事件流聚合为结构化状态，
并按节流策略（flush interval）批量写入持久存储（StateStore）。

整体架构位置：
  runtime worker → Redis Stream → EventStreamConsumer → DataStreamConsumer → ExecutionArchiver → StateStore

核心职责：
  1. 接收 BaseEvent 事件，通过 EventTreeAggregator 聚合为树形状态结构
  2. 根据节流间隔（flush_interval_s）判断何时触发落库
  3. 将聚合后的 Message / ReActRound / Action / ToolCallRecord 分别写入 StateStore
  4. 维护会话（Conversation）的消息树结构

关键设计：
  - 分层 Writer 模式：每种状态类型（Message/ReActRound/Action/ToolCallRecord）
    各有独立的 Writer，支持独立的节流与写入逻辑
  - strip_nested 策略：写入父级时剥离嵌套子对象，避免重复存储
  - 后序遍历落库：先写子节点再写父节点，保证引用完整性
"""
from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Optional

from loguru import logger

from turbo_agent_core.schema.events import BaseEvent
from turbo_agent_core.schema.enums import ConversationStatus, MessageStatus
from turbo_agent_core.schema.states import Action, Message, ReActRound, ToolCallRecord
from turbo_agent_core.utils.aggregators import ActionAggregate, EventTreeAggregator, ReActFlow, TraceAggregationResult, TraceEventAggregator
from turbo_agent_store.interface import StateStore


def _extract_root_input_data(aggregator: EventTreeAggregator) -> Dict[str, Any]:
	"""从事件树聚合器的根节点快照中提取原始输入数据。

	根节点的 input_data 通常包含 conversation_id、user_id、leaf_message_id 等
	任务提交时传入的上下文信息，供后续归档流程使用。
	"""
	root_snapshot = aggregator.snapshot_root()
	if root_snapshot and isinstance(root_snapshot.input_data, dict):
		return root_snapshot.input_data
	return {}


def _resolve_conversation_id(root_input_data: Dict[str, Any]) -> Optional[str]:
	"""从根输入数据中解析会话 ID。

	支持两种格式：
	  - root_input_data["conversation"]["id"]（嵌套对象格式）
	  - root_input_data["conversation_id"]（扁平字段格式）
	"""
	conversation_val = root_input_data.get("conversation")
	if isinstance(conversation_val, dict):
		return conversation_val.get("id")
	return root_input_data.get("conversation_id")


def _resolve_owner_id(message: Message, root_input_data: Dict[str, Any]) -> Optional[str]:
	"""解析消息所有者 ID，优先级：消息自身的 root_user_id > 输入数据的 user_id > 输入数据的 user.id。"""
	return message.root_user_id or root_input_data.get("user_id") or (root_input_data.get("user") or {}).get("id")


def _resolve_tool_root_user_id(record: ToolCallRecord, root_input_data: Dict[str, Any]) -> Optional[str]:
	"""解析工具调用记录的根用户 ID，逻辑同 _resolve_owner_id。"""
	return record.root_user_id or root_input_data.get("user_id") or (root_input_data.get("user") or {}).get("id")


def _normalize_timestamp(ts: Optional[float]) -> Optional[float]:
	"""统一时间戳为秒级精度。

	若值超过 1e11（即毫秒级时间戳），自动除以 1000 转换为秒。
	此处理涵盖了 runtime 侧可能传入毫秒时间戳的场景。
	"""
	if ts is None:
		return None
	value = float(ts)
	if value > 1e11:
		return value / 1000.0
	return value


@dataclass(slots=True)
class MessageArchiveContext:
	"""消息归档上下文，携带写入消息所需的关联信息。"""
	conversation_id: Optional[str]   # 所属会话 ID
	owner_id: Optional[str]          # 消息所有者用户 ID
	leaf_message_id: Optional[str]   # 会话树中的叶子消息 ID（用于维护父子关系）
	strip_nested: bool = True        # 写入时是否剥离嵌套的 reactRounds/actions


@dataclass(slots=True)
class ToolCallArchiveContext:
	"""工具调用记录归档上下文。"""
	root_user_id: Optional[str]      # 触发此次工具调用的根用户 ID


@dataclass(slots=True)
class ActionArchiveContext:
	"""动作（Action）归档上下文，携带写入动作所需的关联信息。"""
	message_id: str                  # 所属消息 ID
	react_round_id: Optional[str]    # 所属 ReAct 轮次 ID
	root_user_id: Optional[str]      # 根用户 ID
	strip_records: bool = True       # 写入时是否剥离嵌套的 ToolCallRecord


@dataclass(slots=True)
class ReActRoundArchiveContext:
	"""ReAct 轮次归档上下文。"""
	message_id: str                  # 所属消息 ID
	root_user_id: Optional[str]      # 根用户 ID
	strip_actions: bool = True       # 写入时是否剥离嵌套的 actions


class BaseExecutionWriter(ABC):
	"""单节点 Writer 抽象基类，负责单类状态的写入节流与落库。

	每种状态类型（Message/ReActRound/Action/ToolCallRecord）都有对应的 Writer 子类。
	Writer 通过 should_flush() 判断是否需要写入，通过 flush() 执行实际写入。

	节流策略：
	  - 节点从未写入过（is_stored=False 且 stored_at=None）→ 立即写入
	  - 节点已关闭（is_closed=True）→ 立即写入
	  - 距上次写入超过 min_flush_interval_s → 写入中间状态
	  - 节点已写入且已关闭，但 finished_at 晚于 stored_at → 写入最终状态
	"""

	def __init__(self, min_flush_interval_s: float = 2.0):
		self.min_flush_interval_s = max(0.0, float(min_flush_interval_s))

	def should_flush(self, node: TraceEventAggregator, now: float) -> bool:
		"""判断该节点当前是否需要落库。"""
		snapshot = node.snapshot()
		if not snapshot:
			return False
		stored_at = _normalize_timestamp(node.stored_at)
		finished_at = _normalize_timestamp(snapshot.finished_at)
		if not node.is_stored:
			# 从未写入 → 立即写入
			if stored_at is None:
				return True
			# 已关闭 → 立即写入最终状态
			if snapshot.is_closed:
				return True
			# 超过节流间隔 → 写入中间状态
			return (now - stored_at) >= self.min_flush_interval_s
		# 节点已完成但最终状态尚未落库
		if snapshot.is_closed and finished_at and (stored_at or 0) < finished_at:
			return True
		return False

	@abstractmethod
	async def flush(self, node: TraceEventAggregator, state_obj: Any, context: Any) -> bool:
		"""写入单个节点的状态到 StateStore，返回是否写入成功。"""


class MessageStateWriter(BaseExecutionWriter):
	"""消息状态写入器：将聚合后的 Message 写入 StateStore。

	写入前会深拷贝消息对象，并可选地剥离嵌套的 reactRounds 和 actions，
	避免与子级 Writer 重复存储。
	"""

	def __init__(self, state_store: StateStore, min_flush_interval_s: float = 2.0):
		super().__init__(min_flush_interval_s=min_flush_interval_s)
		self.state_store = state_store

	async def flush(self, node: TraceEventAggregator, state_obj: Message, context: MessageArchiveContext) -> bool:
		if not context.conversation_id:
			logger.debug("[ExecutionArchiver] 缺少 conversation_id，跳过消息写入: trace_id={}", node.trace_id)
			return False
		message_to_save = state_obj.model_copy(deep=True)
		if context.strip_nested:
			message_to_save.reactRounds = []
			message_to_save.actions = []
		await self.state_store.save_message(
			message_to_save,
			conversation_id=context.conversation_id,
			owner_id=context.owner_id,
		)
		return True


class ReActRoundStateWriter(BaseExecutionWriter):
	"""ReAct 轮次状态写入器：将聚合后的 ReActRound 写入 StateStore。

	ReActRound 基于 ReActFlow 聚合器，其节流判断逻辑使用 updated_at 而非 finished_at，
	因为 ReAct 轮次在运行过程中会被多次更新（每次 action 完成时更新一次）。
	"""

	def __init__(self, state_store: StateStore, min_flush_interval_s: float = 2.0):
		super().__init__(min_flush_interval_s=min_flush_interval_s)
		self.state_store = state_store

	def should_flush(self, node, now: float) -> bool:
		stored_at = _normalize_timestamp(node.stored_at)
		updated_at = _normalize_timestamp(node.updated_at)
		if not node.is_stored:
			if stored_at is None:
				return True
			if node.is_closed:
				return True
			return (now - stored_at) >= self.min_flush_interval_s
		if node.is_closed and updated_at and (stored_at or 0) < updated_at:
			return True
		return False

	async def flush(self, node: ReActFlow, state_obj: ReActRound, context: ReActRoundArchiveContext) -> bool:
		react_round_to_save = state_obj.model_copy(deep=True)
		if context.strip_actions:
			react_round_to_save.actions = []
		await self.state_store.save_react_round(
			react_round_to_save,
			message_id=context.message_id,
			owner_id=context.root_user_id,
		)
		return True


class ActionStateWriter(BaseExecutionWriter):
	"""动作状态写入器：将聚合后的 Action 写入 StateStore。

	Action 代表 ReAct 循环中的一次工具调用动作，包含思考（thought）、
	工具选择（tool）和工具调用记录（records）。写入时可选地剥离 records。
	"""

	def __init__(self, state_store: StateStore, min_flush_interval_s: float = 2.0):
		super().__init__(min_flush_interval_s=min_flush_interval_s)
		self.state_store = state_store

	def should_flush(self, node, now: float) -> bool:
		stored_at = _normalize_timestamp(node.stored_at)
		finished_at = _normalize_timestamp(node.finished_at)
		if not node.is_stored:
			if stored_at is None:
				return True
			if node.is_closed:
				return True
			return (now - stored_at) >= self.min_flush_interval_s
		if node.is_closed and finished_at and (stored_at or 0) < finished_at:
			return True
		return False

	async def flush(self, node: ActionAggregate, state_obj: Action, context: ActionArchiveContext) -> bool:
		if not state_obj.root_user_id and context.root_user_id:
			state_obj.root_user_id = context.root_user_id
		action_to_save = state_obj.model_copy(deep=True)
		if context.strip_records:
			action_to_save.records = []
		await self.state_store.save_action(
			action_to_save,
			message_id=context.message_id,
			react_round_id=context.react_round_id,
			owner_id=context.root_user_id,
		)
		return True


class ToolCallRecordStateWriter(BaseExecutionWriter):
	"""工具调用记录写入器：将 ToolCallRecord 写入 StateStore。

	工具调用记录是最底层的状态单元，记录单次工具调用的输入、输出和耗时信息。
	不含嵌套结构，写入逻辑最为简单。
	"""

	def __init__(self, state_store: StateStore, min_flush_interval_s: float = 2.0):
		super().__init__(min_flush_interval_s=min_flush_interval_s)
		self.state_store = state_store

	async def flush(self, node: Any, state_obj: ToolCallRecord, context: ToolCallArchiveContext) -> bool:
		if not state_obj.root_user_id and context.root_user_id:
			state_obj.root_user_id = context.root_user_id
		await self.state_store.save_tool_call_record(state_obj, root_user_id=context.root_user_id)
		return True


class ExecutionArchiver:
	"""流式归档执行器：接收事件 → 聚合状态树 → 按节流策略批量落库。

	这是流式归档链路的核心入口，由 DataStreamConsumer 持有并驱动。

	工作流程：
	  1. on_event(event) 接收每个事件并送入 EventTreeAggregator 聚合
	  2. 标记受影响的节点为“未存储”（_mark_unstored）
	  3. 根据节流间隔判断是否需要落库（flush_if_needed）
	  4. flush() 时后序遍历所有节点，逐一判断并写入

	聚合结构（由 EventTreeAggregator 维护）：
	  Trace Root
	    └─ Message (TraceEventAggregator)
	         ├─ ReActRound (ReActFlow)
	         │    ├─ Action (ActionAggregate)
	         │    │    └─ ToolCallRecord
	         │    └─ Action ...
	         └─ ReActRound ...

	每层状态都有对应的 Writer 负责独立写入和节流。
	"""

	def __init__(
		self,
		trace_id: str,
		state_store: StateStore,
		*,
		flush_interval_s: float = 2.0,
		message_writer: Optional[MessageStateWriter] = None,
		react_round_writer: Optional[ReActRoundStateWriter] = None,
		action_writer: Optional[ActionStateWriter] = None,
		tool_call_writer: Optional[ToolCallRecordStateWriter] = None,
	):
		self.trace_id = trace_id
		self.state_store = state_store
		self.flush_interval_s = max(0.0, float(flush_interval_s))
		# 事件树聚合器：将零散事件聚合为 Message → ReActRound → Action → ToolCallRecord 的树形结构
		self.aggregator = EventTreeAggregator(root_trace_id=trace_id)
		# 四个分层 Writer，分别负责各层级状态的写入
		self.message_writer = message_writer or MessageStateWriter(state_store, min_flush_interval_s=self.flush_interval_s)
		self.react_round_writer = react_round_writer or ReActRoundStateWriter(state_store, min_flush_interval_s=self.flush_interval_s)
		self.action_writer = action_writer or ActionStateWriter(state_store, min_flush_interval_s=self.flush_interval_s)
		self.tool_call_writer = tool_call_writer or ToolCallRecordStateWriter(state_store, min_flush_interval_s=self.flush_interval_s)
		self._last_flush_mono: float = time.monotonic()  # 上次 flush 的单调时钟（用于节流）
		self._dirty = False  # 是否有新事件尚未落库

	async def on_event(self, event: BaseEvent) -> None:
		"""处理单个事件：聚合 → 标记脏位 → 按需落库。"""
		self.aggregator.on_event(event)
		self._mark_unstored(event)
		self._dirty = True
		await self.flush_if_needed()

	async def flush_if_needed(self) -> bool:
		"""检查节流间隔，若已超时则触发 flush。"""
		if not self._dirty:
			return False

		now = time.monotonic()
		if (now - self._last_flush_mono) < self.flush_interval_s:
			return False

		await self.flush(force=False)
		return True

	async def force_flush(self) -> bool:
		"""强制落库：不受节流间隔限制，在消费者退出前调用以确保数据完整。"""
		had_dirty = self._dirty
		if self._dirty:
			await self.flush(force=True)
		await self._touch_conversation_updated_at()
		return had_dirty

	async def flush(self, *, force: bool = False) -> bool:
		"""执行实际的落库操作：后序遍历所有聚合节点，逐一判断并写入。

		后序遍历保证子节点先于父节点写入，维护数据库中的引用完整性。
		对每个节点调用 to_state() 转为状态对象，根据类型分发给对应 Writer。
		"""
		if not self._dirty:
			return False

		root_input_data = _extract_root_input_data(self.aggregator)
		now = time.time()

		for node in self.aggregator.iter_nodes_post_order():
			try:
				state_obj = node.to_state(include_nested=False)
			except Exception as exc:
				logger.warning("[ExecutionArchiver] to_state 失败，已跳过: trace_id={}, error={}", node.trace_id, exc)
				continue

			if not state_obj:
				continue

			if isinstance(state_obj, Message):
				if force or self.message_writer.should_flush(node, now):
					written = await self._archive_message_node(node=node, message=state_obj, root_input_data=root_input_data, now=now, force=force)
					if written:
						node.set_stored(True, now)
			elif isinstance(state_obj, ToolCallRecord):
				if force or self.tool_call_writer.should_flush(node, now):
					written = await self._archive_tool_node(node=node, record=state_obj, root_input_data=root_input_data)
					if written:
						node.set_stored(True, now)

		self._dirty = False
		self._last_flush_mono = time.monotonic()
		return True

	def snapshot_root(self) -> Optional[TraceAggregationResult]:
		"""获取根节点的聚合快照，用于外部判断 trace 是否已完成（is_closed）。"""
		return self.aggregator.snapshot_root()

	async def _touch_conversation_updated_at(self) -> None:
		"""更新会话的 updated_at 时间戳，使前端能感知到会话的最新活动。"""
		if not hasattr(self.state_store, "touch_conversation"):
			return
		root_input_data = _extract_root_input_data(self.aggregator)
		conversation_id = _resolve_conversation_id(root_input_data)
		if not conversation_id:
			return
		await self.state_store.touch_conversation(conversation_id)

	async def _update_conversation_status(self, status: ConversationStatus) -> None:
		"""更新会话状态（如 finished），在消息完成时调用。"""
		root_input_data = _extract_root_input_data(self.aggregator)
		conversation_id = _resolve_conversation_id(root_input_data)
		if not conversation_id:
			return
		await self.state_store.update_conversation_status(conversation_id, status)

	@staticmethod
	def _is_terminal_run_event(event: BaseEvent) -> bool:
		return event.type in {"run.lifecycle.completed", "run.lifecycle.failed", "run.lifecycle.cancelled"}

	def _mark_terminal_descendants_unstored(self, *, node: TraceEventAggregator, ts: float) -> None:
		"""在 run 终结时，将其下所有 react/action 标记为最终待落库。"""
		for run in node.runs.values():
			for flow in run.react_flows.values():
				flow.set_closed(True)
				flow.set_stored(False, ts)
				for aggregate in flow.actions.values():
					aggregate.set_closed(True)
					aggregate.set_stored(False, ts)

	def _mark_unstored(self, event: BaseEvent) -> None:
		"""将事件涉及的所有聚合节点标记为“未存储”，触发后续 flush 时重新写入。

		一个事件可能影响多个节点（通过 trace_path 追溯祖先链），
		同时还需标记事件关联的 ReActFlow 和 ActionAggregate。
		"""
		trace_path = getattr(event, "trace_path", None) or []
		event_ts = float(event.timestamp)
		is_terminal_run_event = self._is_terminal_run_event(event)
		for trace_id in [*trace_path, event.trace_id]:
			node = self.aggregator.nodes.get(trace_id)
			if node is not None:
				node.set_stored(False, event_ts)
				if is_terminal_run_event:
					self._mark_terminal_descendants_unstored(node=node, ts=event_ts)
				if event.react_id is not None:
					for run in node.runs.values():
						flow = run.react_flows.get(event.react_id)
						if flow is not None:
							flow.set_stored(False, event_ts)
				if event.action_id:
					self._mark_action_unstored(node=node, action_id=event.action_id, ts=event_ts)

	async def _archive_message_node(
		self,
		*,
		node: TraceEventAggregator,
		message: Message,
		root_input_data: Dict[str, Any],
		now: float,
		force: bool,
	) -> bool:
		"""归档单个消息节点：维护会话树 → 写入消息 → 写入子组件（ReAct/Action/ToolCall）。"""
		conversation_id = _resolve_conversation_id(root_input_data)
		owner_id = _resolve_owner_id(message, root_input_data)
		leaf_message_id = root_input_data.get("leaf_message_id")

		if conversation_id:
			await self._maintain_message_tree(
				conversation_id=conversation_id,
				message=message,
				leaf_message_id=leaf_message_id,
			)
		logger.debug("准备归档 Message: message_id={}, conversation_id={}, trace_id={}, message_content={}", message.id, conversation_id, node.trace_id, message)
		written = await self.message_writer.flush(
			node,
			message,
			MessageArchiveContext(
				conversation_id=conversation_id,
				owner_id=owner_id,
				leaf_message_id=leaf_message_id,
				strip_nested=True,
			),
		)
		if not written:
			return False
		await self._archive_components_from_trace(node=node, message=message, root_input_data=root_input_data, now=now, force=force)
		if message.status == MessageStatus.finished:
			await self._update_conversation_status(ConversationStatus.finished)
		return True

	async def _archive_tool_node(self, *, node: TraceEventAggregator, record: ToolCallRecord, root_input_data: Dict[str, Any]) -> bool:
		"""归档独立的工具调用节点（不属于某个 Action 的顶层工具调用）。"""
		return await self.tool_call_writer.flush(
			node,
			record,
			ToolCallArchiveContext(
				root_user_id=_resolve_tool_root_user_id(record, root_input_data),
			),
		)

	async def _archive_components_from_trace(
		self,
		*,
		node: TraceEventAggregator,
		message: Message,
		root_input_data: Dict[str, Any],
		now: float,
		force: bool,
	) -> None:
		"""归档消息下的所有子组件：遍历每个 run 的 ReActFlow 和 ActionAggregate。"""
		for run_id in node.run_order:
			run = node.runs.get(run_id)
			if run is None:
				continue
			logger.debug("[ExecutionArchiver] 处理react_flows: trace_id={}, message_id={},  run.react_flows.items()={}", node.trace_id, message.id, run.react_flows.items())
			for react_id, flow in run.react_flows.items():
				await self._archive_react_flow(
					trace_id=node.trace_id,
					flow=flow,
					message_id=message.id,
					root_input_data=root_input_data,
					now=now,
					force=force,
				)
				for aggregate in flow.actions.values():
					await self._archive_action_aggregate(
						aggregate=aggregate,
						message_id=message.id,
						react_round_id=(flow.react_id or f"react_{message.id}_default") if react_id is not None else None,
						root_input_data=root_input_data,
						now=now,
						force=force,
					)

	async def _archive_react_flow(
		self,
		*,
		trace_id: str,
		flow: ReActFlow,
		message_id: str,
		root_input_data: Dict[str, Any],
		now: float,
		force: bool,
	) -> None:
		"""归档单个 ReAct 流程轮次（ReActFlow → ReActRound）。"""
		if flow.react_id is None:
			return
		if not force and not self.react_round_writer.should_flush(flow, now):
			return
		react_round = flow.to_state(message_id, include_actions=False, include_action_records=False)
		logger.debug("准备归档 ReActRound: react_id={}, message_id={}, trace_id={}, react_content={}", flow.react_id, message_id, trace_id, react_round)
		root_user_id = react_round.root_user_id or root_input_data.get("user_id") or (root_input_data.get("user") or {}).get("id")
		written = await self.react_round_writer.flush(
			flow,
			react_round,
			ReActRoundArchiveContext(
				message_id=message_id,
				root_user_id=root_user_id,
				strip_actions=True,
			),
		)
		if written:
			flow.set_stored(True, now)

	async def _archive_action_aggregate(
		self,
		*,
		aggregate: ActionAggregate,
		message_id: str,
		react_round_id: Optional[str],
		root_input_data: Dict[str, Any],
		now: float,
		force: bool,
	) -> None:
		"""归档单个动作聚合体（ActionAggregate → Action + ToolCallRecord）。"""
		if not force and not self.action_writer.should_flush(aggregate, now):
			return

		action = aggregate.to_state(include_records=False)
		root_user_id = action.root_user_id or root_input_data.get("user_id") or (root_input_data.get("user") or {}).get("id")
		logger.debug("准备归档 Action: action_id={}, message_id={}, react_round_id={}, trace_id={}, action_content={}", aggregate.action_id, message_id, react_round_id, aggregate.trace_id, action)
		written = await self.action_writer.flush(
			aggregate,
			action,
			ActionArchiveContext(
				message_id=message_id,
				react_round_id=react_round_id,
				root_user_id=root_user_id,
				strip_records=True,
			),
		)
		if not written:
			return
		record = aggregate.to_tool_call_record_state()
		logger.debug("准备归档 ToolCallRecord: action_id={}, message_id={}, react_round_id={}, trace_id={}, record_content={}", aggregate.action_id, message_id, react_round_id, aggregate.trace_id, record)
		await self.tool_call_writer.flush(
			aggregate,
			record,
			ToolCallArchiveContext(root_user_id=_resolve_tool_root_user_id(record, root_input_data)),
		)
		aggregate.set_stored(True, now)

	def _find_action_aggregate(self, *, node: TraceEventAggregator, action_id: str):
		"""在节点的所有 run/react_flow 中查找指定 action_id 对应的 ActionAggregate。"""
		for run in node.runs.values():
			for flow in run.react_flows.values():
				aggregate = flow.actions.get(action_id)
				if aggregate is not None:
					return aggregate
		return None

	def _mark_action_unstored(self, *, node: TraceEventAggregator, action_id: str, ts: float) -> None:
		"""将指定 Action 及其所属 ReActFlow 标记为“未存储”。"""
		aggregate = self._find_action_aggregate(node=node, action_id=action_id)
		if aggregate is not None:
			aggregate.set_stored(False, ts)
			for run in node.runs.values():
				for flow in run.react_flows.values():
					if flow.actions.get(action_id) is aggregate:
						flow.set_stored(False, ts)
						return

	async def _maintain_message_tree(
		self,
		*,
		conversation_id: str,
		message: Message,
		leaf_message_id: Optional[str],
	) -> None:
		"""维护会话的消息树结构。

		将新消息插入会话的消息树，建立父子关系。新消息的父节点优先取
		leaf_message_id（任务提交时指定的叶子消息），否则取会话中最后一条消息。
		若父消息的 children 列表发生变化，还需将父消息重新保存一次。
		"""
		conversation = await self.state_store.get_conversation(conversation_id)
		if not conversation:
			return

		had_messages_before = bool(conversation.messages)
		existing_message = next((item for item in conversation.messages if item.id == message.id), None)
		if existing_message is not None:
			return

		parent_id = leaf_message_id
		if not parent_id and conversation.messages:
			parent_id = conversation.messages[-1].id

		try:
			conversation.add_child(message, parent_id=parent_id)
		except Exception as exc:
			logger.error(
				"[ExecutionArchiver] 会话树结构计算失败，消息将按当前状态落库: conversation_id={}, message_id={}, error={}",
				conversation_id,
				message.id,
				exc,
			)
			return

		if message.ancestors:
			parent_message_id = message.ancestors[-1]
			parent_msg = next((item for item in conversation.messages if item.id == parent_message_id), None)
			if parent_msg and conversation_id:
				await self.state_store.save_message(parent_msg, conversation_id=conversation_id)

		if not had_messages_before:
			await self.state_store.save_conversation(conversation)


__all__ = ["ExecutionArchiver"]