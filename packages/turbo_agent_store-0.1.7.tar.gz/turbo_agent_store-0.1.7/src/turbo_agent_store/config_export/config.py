"""
YAMLConfigStore - 基于 YAML Package 的 Store 接口完整实现

提供对 TurboEntityStore 和 ExternalStore 接口的完整实现，
数据来源为 YAML 导出包（ZIP 文件或目录结构）。

核心能力：
- 从 export.yaml / 目录结构加载全部实体到内存
- 基于 PackageLoader 的两遍扫描算法重建依赖关系
- 支持实体的 CRUD 操作（数据保存回 YAML 目录）
- 提供 brief/detail/runnable 三态读取
- 支持 Agent 绑定管理

适用场景：
- Worker 节点基于 YAML 配置快速拉起
- 桌面/具身客户端本地配置管理
- 配置备份/恢复/迁移
- 单元测试的轻量级 Store Mock

使用示例:
    # 从 ZIP 包加载
    store = YAMLConfigStore.from_zip("export.zip")

    # 从目录加载
    store = YAMLConfigStore.from_dir("./my_config")

    # 从空白创建
    store = YAMLConfigStore()

    # 读取 Agent
    agent = await store.get_agent_runnable(locator)
"""

import os
import uuid
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, Union

import yaml
from loguru import logger

from turbo_agent_core.schema.agents import (
    Agent,
    APITool,
    AgentTool,
    BasicAgent,
    Character,
    LLMModel,
    LLMTool,
    Tool,
)
from turbo_agent_core.schema.basic import (
    BriefTurboEntity,
    DetailTurboEntity,
    Endpoint,
    ModelInstance,
    ModelSeries,
    Space,
    TurboEntity,
)
from turbo_agent_core.schema.brief_agent import (
    AgentBrief,
    CharacterBrief,
    LLMModelBrief,
    ToolBrief,
)
from turbo_agent_core.schema.detail_agent import (
    AgentDetail,
    CharacterDetail,
    LLMModelDetail,
    ModelInstanceDetail,
    ToolDetail,
)
from turbo_agent_core.schema.enums import SpaceType
from turbo_agent_core.schema.external import (
    AuthMethod,
    McpResourceDescriptor,
    McpServerSpec,
    Platform,
    Secret,
)
from turbo_agent_core.schema.refs import (
    CharacterRef,
    EndpointRef,
    ModelInstanceRef,
    ModelRef,
    PlatformRef,
    SecretRef,
    ToolRef,
)
from turbo_agent_core.schema.resources import BusinessSetting, KnowledgeResource, Project, Workset

from turbo_agent_store.dtos import SubjectResourceType, SubjectType
from turbo_agent_store.interface.entity import TurboEntityLocator, TurboEntityStore
from turbo_agent_store.interface.external import ExternalStore
from turbo_agent_store.interface.resource import KnowledgeResourceUploadSpec, ResourceEntityStore
from turbo_agent_store.services.package_loader import PackageLoader


# ==================== 辅助函数 ====================


def _make_belong_to(space_name: str, project_name_id: Optional[str]) -> str:
    """构造 belong_to_project_path 格式。"""
    if project_name_id:
        return f"{space_name}/{project_name_id}"
    return space_name


def _match_locator(entity: TurboEntity, locator: TurboEntityLocator) -> bool:
    """检查实体是否匹配 locator 定位条件。"""
    if locator.space_name and entity.space_name != locator.space_name:
        return False
    if locator.project_name_id and entity.project_name_id != locator.project_name_id:
        return False
    if locator.name_id and entity.name_id != locator.name_id:
        return False
    if locator.version_tag and hasattr(entity, "version_tag"):
        if getattr(entity, "version_tag", None) != locator.version_tag:
            return False
    if locator.series_name and hasattr(entity, "series_name"):
        if getattr(entity, "series_name", None) != locator.series_name:
            return False
    return True


def _to_ref(entity: TurboEntity, ref_cls: type) -> Any:
    """将实体转换为引用对象。"""
    return ref_cls(
        id=entity.id,
        name=entity.name,
        name_en=getattr(entity, "name_id", None),
        space=getattr(entity, "space_name", None),
        belong_to_project_path=getattr(entity, "belong_to_project_path", None),
        description=getattr(entity, "description", None),
        avatar_url=getattr(entity, "avatar_uri", None),
    )


def _agent_to_brief(agent: Agent) -> AgentBrief:
    """将 Agent 转换为 AgentBrief。"""
    return AgentBrief(
        id=agent.id,
        name=agent.name,
        name_id=agent.name_id,
        belong_to_project_path=agent.belong_to_project_path or "",
        space=agent.space_name,
        project_name_id=agent.project_name_id or "",
        description=agent.description,
        avatar_url=agent.avatar_uri,
        model=_to_ref(agent.model, ModelRef) if agent.model else None,
        tools=[_to_ref(t, ToolRef) for t in (agent.tools or [])],
        act_as_characters=[_to_ref(c, CharacterRef) for c in (getattr(agent, "actAsCharacters", None) or [])],
        secrets=[_to_ref(s, SecretRef) for s in (getattr(agent, "accountSecrets", None) or [])],
    )


def _agent_to_detail(agent: Agent) -> AgentDetail:
    """将 Agent 转换为 AgentDetail。"""
    return AgentDetail(
        id=agent.id,
        name=agent.name,
        name_id=agent.name_id,
        space=agent.space_name,
        belong_to_project_path=agent.belong_to_project_path or "",
        description=agent.description,
        avatar_url=agent.avatar_uri,
        has_memory=getattr(agent, "hasMemory", False),
        expose_inner_thought=getattr(agent, "expose_inner_thought", True),
        model=_to_ref(agent.model, ModelRef) if agent.model else None,
        model_parameters=getattr(agent, "modelParameter", None),
        setting=getattr(agent, "setting", None),
        tools=[_to_ref(t, ToolRef) for t in (agent.tools or [])],
        characters=[_to_ref(c, CharacterRef) for c in (getattr(agent, "actAsCharacters", None) or [])],
        secrets=[_to_ref(s, SecretRef) for s in (getattr(agent, "accountSecrets", None) or [])],
    )


def _tool_to_brief(tool: Tool) -> ToolBrief:
    """将 Tool 转换为 ToolBrief。"""
    platform_ref = None
    if isinstance(tool, APITool) and tool.platform:
        platform_ref = _to_ref(tool.platform, PlatformRef)
    return ToolBrief(
        id=tool.id,
        name=tool.name,
        name_id=tool.name_id,
        belong_to_project_path=tool.belong_to_project_path or "",
        space=tool.space_name,
        project_name_id=tool.project_name_id or "",
        description=tool.description,
        avatar_url=tool.avatar_uri,
        version_tag=getattr(tool, "version_tag", None),
        platform=platform_ref,
    )


def _tool_to_detail(tool: Tool) -> ToolDetail:
    """将 Tool 转换为 ToolDetail。"""
    return ToolDetail(
        id=tool.id,
        name=tool.name,
        name_id=tool.name_id,
        space=tool.space_name,
        belong_to_project_path=tool.belong_to_project_path or "",
        description=tool.description,
        avatar_url=tool.avatar_uri,
        version_tag=getattr(tool, "version_tag", None),
        input=getattr(tool, "input", []),
        output=getattr(tool, "output", []),
        input_schema=getattr(tool, "input_schema", {}),
        output_schema=getattr(tool, "output_schema", {}),
        model=_to_ref(tool.model, ModelRef) if hasattr(tool, "model") and tool.model else None,
        model_parameters=getattr(tool, "modelParameter", None),
        setting=getattr(tool, "setting", None),
    )


def _character_to_brief(char: Character) -> CharacterBrief:
    """将 Character 转换为 CharacterBrief。"""
    return CharacterBrief(
        id=char.id,
        name=char.name,
        name_id=char.name_id,
        belong_to_project_path=char.belong_to_project_path or "",
        space=char.space_name,
        project_name_id=char.project_name_id or "",
        description=char.description,
        avatar_url=char.avatar_uri,
        version_tag=getattr(char, "version_tag", None),
        model=_to_ref(char.model, ModelRef) if char.model else None,
        tools=[_to_ref(t, ToolRef) for t in (char.tools or [])],
    )


def _character_to_detail(char: Character) -> CharacterDetail:
    """将 Character 转换为 CharacterDetail。"""
    return CharacterDetail(
        id=char.id,
        name=char.name,
        name_id=char.name_id,
        space=char.space_name,
        belong_to_project_path=char.belong_to_project_path or "",
        description=char.description,
        avatar_url=char.avatar_uri,
        version_tag=getattr(char, "version_tag", None),
        model=_to_ref(char.model, ModelRef) if char.model else None,
        model_parameters=getattr(char, "modelParameter", None),
        setting=getattr(char, "setting", None),
        tools=[_to_ref(t, ToolRef) for t in (char.tools or [])],
    )


def _model_to_brief(model: LLMModel) -> LLMModelBrief:
    """将 LLMModel 转换为 LLMModelBrief。"""
    return LLMModelBrief(
        id=model.id,
        name=model.name,
        name_id=model.name_id,
        belong_to_project_path=model.belong_to_project_path or "",
        space=model.space_name,
        project_name_id=model.project_name_id or "",
        description=model.description,
        avatar_url=model.avatar_uri,
        series_name=model.series_name,
        model_type=getattr(model, "model_type", None),
        thinking_model=getattr(model, "thinking_model", False),
    )


def _model_to_detail(model: LLMModel) -> LLMModelDetail:
    """将 LLMModel 转换为 LLMModelDetail。"""
    return LLMModelDetail(
        id=model.id,
        name=model.name,
        name_id=model.name_id,
        space=model.space_name,
        belong_to_project_path=model.belong_to_project_path or "",
        description=model.description,
        avatar_url=model.avatar_uri,
        series_name=model.series_name,
        model_type=getattr(model, "model_type", None),
        thinking_model=getattr(model, "thinking_model", False),
        default_parameters=getattr(model, "defaultParameters", None),
    )


def _endpoint_to_ref(endpoint: Endpoint) -> EndpointRef:
    """将 Endpoint 转换为 EndpointRef。"""
    return EndpointRef(
        id=endpoint.id,
        name=getattr(endpoint, "name", None) or endpoint.id,
        description=getattr(endpoint, "url", None) or getattr(endpoint, "baseURL", None),
    )


def _match_model_instance_locator(
    locator: TurboEntityLocator,
    instance: Optional[ModelInstance],
) -> bool:
    """检查 ModelInstance 的定位信息是否匹配。"""
    if instance is None:
        return False
    if locator.space_name and locator.space_name != instance.space_name:
        return False
    if locator.project_name_id and locator.project_name_id != getattr(instance, "project_name_id", None):
        return False
    if locator.name_id and locator.name_id != instance.model_name:
        return False
    if locator.version_tag and locator.version_tag != instance.version:
        return False
    if locator.series_name and locator.series_name != instance.series_name:
        return False
    return True


def _model_instance_to_ref(
    instance: ModelInstance,
) -> ModelInstanceRef:
    """将 ModelInstance 转换为 ModelInstanceRef。"""
    return ModelInstanceRef(
        id=instance.id,
        name=instance.label,
        name_en=instance.model_name,
        space=instance.space_name,
        belong_to_project_path=_make_belong_to(instance.space_name, getattr(instance, "project_name_id", None)),
        version=instance.version,
        description=instance.description,
    )


def _model_instance_to_detail(
    instance: ModelInstance,
) -> ModelInstanceDetail:
    """将 ModelInstance 转换为 ModelInstanceDetail。"""
    return ModelInstanceDetail(
        id=instance.id,
        label=instance.label,
        space_name=instance.space_name,
        project_name_id=getattr(instance, "project_name_id", None),
        series_name=instance.series_name,
        model_name=instance.model_name,
        version=instance.version,
        description=instance.description,
        request_model_id=instance.request_model_id,
        is_active=instance.is_active,
        provider=instance.provider,
        endpoint=_endpoint_to_ref(instance.endpoint) if instance.endpoint else None,
        token_cost_input=instance.token_cost_input,
        token_cost_output=instance.token_cost_output,
        concurrent_limit=instance.concurrent_limit,
        rpm_limit=instance.rpm_limit,
        tpm_limit=instance.tpm_limit,
        request_params=instance.request_params,
    )


# ==================== YAMLConfigStore 主类 ====================


class YAMLConfigStore(TurboEntityStore, ExternalStore, ResourceEntityStore):
    """
    基于 YAML Package 的 Store 完整实现。

    实现 TurboEntityStore、ExternalStore、ResourceEntityStore 接口，
    所有数据存储在内存中，并可持久化到 YAML 文件。
    """

    def __init__(self, data_dir: Optional[str] = None):
        """
        初始化 YAMLConfigStore。

        Args:
            data_dir: 数据目录路径。若指定，CRUD 操作将持久化到该目录。
        """
        self._data_dir = data_dir

        # 内存索引：id -> 实体对象
        self._agents: Dict[str, Agent] = {}
        self._characters: Dict[str, Character] = {}
        self._tools: Dict[str, Tool] = {}
        self._models: Dict[str, LLMModel] = {}
        self._platforms: Dict[str, Platform] = {}
        self._auth_methods: Dict[str, AuthMethod] = {}
        self._secrets: Dict[str, Secret] = {}
        self._knowledge_resources: Dict[str, KnowledgeResource] = {}
        self._business_settings: Dict[str, BusinessSetting] = {}
        self._projects: Dict[str, Project] = {}
        self._spaces: Dict[str, Space] = {}
        self._mcp_servers: Dict[str, McpServerSpec] = {}
        self._mcp_resources: Dict[str, McpResourceDescriptor] = {}
        self._worksets: Dict[str, Workset] = {}
        self._endpoints: Dict[str, Endpoint] = {}
        self._model_instances: Dict[str, ModelInstance] = {}
        self._model_series: Dict[str, ModelSeries] = {}

    # ==================== 工厂方法 ====================

    @classmethod
    def from_zip(cls, zip_path: str, data_dir: Optional[str] = None) -> "YAMLConfigStore":
        """从 ZIP 包加载数据创建 Store。"""
        loader = PackageLoader()
        entities = loader.load(zip_path)

        store = cls(data_dir=data_dir)
        store._load_entities(entities)
        try:
            with zipfile.ZipFile(zip_path, "r") as zip_file:
                if "export.yaml" in zip_file.namelist():
                    raw_data = yaml.safe_load(zip_file.read("export.yaml").decode("utf-8")) or {}
                    store._load_supplemental_entities_from_raw(raw_data)
        except Exception as exc:
            logger.warning(f"读取 ZIP 扩展资源失败，忽略: {exc}")
        logger.info(f"从 ZIP 包加载完成: {zip_path}，共 {len(entities)} 个实体")
        return store

    @classmethod
    def from_dir(cls, dir_path: str) -> "YAMLConfigStore":
        """
        从 YAML 目录结构加载数据创建 Store。

        支持两种目录结构：
        1. 包含 export.yaml 的统一清单
        2. 按类型分目录的结构（agents/, tools/, ...）
        """
        store = cls(data_dir=dir_path)
        export_yaml = Path(dir_path) / "export.yaml"

        if export_yaml.exists():
            # 模式 1：统一清单
            with open(export_yaml, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
            loader = PackageLoader()
            loader._instantiate_entities(data)
            loader._hydrate_dependencies()
            store._load_entities(list(loader._entity_map.values()))
            store._load_supplemental_entities_from_raw(data or {})
        else:
            # 模式 2：分目录加载
            store._load_from_directory(dir_path)

        logger.info(f"从目录加载完成: {dir_path}")
        return store

    @classmethod
    def from_entities(cls, entities: List[Any], data_dir: Optional[str] = None) -> "YAMLConfigStore":
        """从已有实体列表创建 Store。"""
        store = cls(data_dir=data_dir)
        store._load_entities(entities)
        return store

    # ==================== 数据加载 ====================

    def _load_entities(self, entities: list):
        """将实体列表加载到内存索引。"""
        for entity in entities:
            if isinstance(entity, Agent):
                self._agents[entity.id] = entity
            elif isinstance(entity, Character):
                self._characters[entity.id] = entity
            elif isinstance(entity, LLMModel):
                self._models[entity.id] = entity
            elif isinstance(entity, Tool):
                self._tools[entity.id] = entity
            elif isinstance(entity, Platform):
                self._platforms[entity.id] = entity
            elif isinstance(entity, AuthMethod):
                self._auth_methods[entity.id] = entity
            elif isinstance(entity, Secret):
                self._secrets[entity.id] = entity
            elif isinstance(entity, KnowledgeResource):
                self._knowledge_resources[entity.id] = entity
            elif isinstance(entity, BusinessSetting):
                self._business_settings[entity.id] = entity
            elif isinstance(entity, Project):
                self._projects[entity.id] = entity
            elif isinstance(entity, McpServerSpec):
                self._mcp_servers[entity.id] = entity
            elif isinstance(entity, McpResourceDescriptor):
                self._mcp_resources[entity.id] = entity
            elif isinstance(entity, Workset):
                self._worksets[entity.id] = entity
            elif isinstance(entity, Endpoint):
                self._endpoints[entity.id] = entity
            elif isinstance(entity, ModelInstance):
                self._model_instances[entity.id] = entity
            elif isinstance(entity, ModelSeries):
                self._model_series[entity.series_name] = entity

    def _load_supplemental_entities_from_raw(self, data: Dict[str, Any]):
        """加载 PackageLoader 未覆盖的补充资源实体。"""
        for item in data.get("spaces", []) or []:
            space = Space.model_validate(item)
            self._spaces[space.space_name] = space

        for item in data.get("worksets", []) or []:
            workset = Workset.model_validate(item)
            self._worksets[workset.id] = workset

        for item in data.get("endpoints", []) or []:
            endpoint = Endpoint.model_validate(item)
            self._endpoints[endpoint.id] = endpoint

        for item in data.get("model_instances", []) or []:
            instance = ModelInstance.model_validate(item)
            self._model_instances[instance.id] = instance

        for item in data.get("model_series", []) or []:
            series = ModelSeries.model_validate(item)
            self._model_series[series.series_name] = series

    def _load_from_directory(self, dir_path: str):
        """从分类目录结构加载 YAML 文件。"""
        base = Path(dir_path)
        loader = PackageLoader()
        all_data: Dict[str, Any] = {}

        # 按依赖顺序扫描子目录
        type_dirs = [
            ("projects", "projects"),
            ("spaces", "spaces"),
            ("knowledge_resources", "knowledge_resources"),
            ("business_settings", "business_settings"),
            ("worksets", "worksets"),
            ("platforms", "platforms"),
            ("auth_methods", "auth_methods"),
            ("secrets", "secrets"),
            ("mcp_servers", "mcp_servers"),
            ("mcp_resources", "mcp_resources"),
            ("endpoints", "endpoints"),
            ("model_series", "model_series"),
            ("model_instances", "model_instances"),
            ("models", "models"),
            ("tools", "tools"),
            ("characters", "characters"),
            ("agents", "agents"),
        ]

        for dir_name, yaml_key in type_dirs:
            type_dir = base / dir_name
            if not type_dir.exists():
                continue
            items = []
            for yaml_file in sorted(type_dir.glob("*.yaml")):
                with open(yaml_file, "r", encoding="utf-8") as f:
                    item_data = yaml.safe_load(f)
                if item_data:
                    items.append(item_data)
            for yaml_file in sorted(type_dir.glob("*.yml")):
                with open(yaml_file, "r", encoding="utf-8") as f:
                    item_data = yaml.safe_load(f)
                if item_data:
                    items.append(item_data)
            if items:
                all_data[yaml_key] = items

        # 使用 PackageLoader 的两遍扫描算法
        loader._instantiate_entities(all_data)
        loader._hydrate_dependencies()
        self._load_entities(list(loader._entity_map.values()))
        self._load_supplemental_entities_from_raw(all_data)

    # ==================== 持久化辅助 ====================

    def _persist_entity(self, type_name: str, entity_id: str, data: Dict[str, Any]):
        """将单个实体持久化到 YAML 文件。"""
        if not self._data_dir:
            return
        type_dir = Path(self._data_dir) / type_name
        type_dir.mkdir(parents=True, exist_ok=True)
        file_name = data.get("name_id", entity_id)
        file_path = type_dir / f"{file_name}.yaml"
        with open(file_path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, allow_unicode=True, sort_keys=False, default_flow_style=False)

    def _delete_entity_file(self, type_name: str, entity: Any):
        """删除实体对应的 YAML 文件。"""
        if not self._data_dir:
            return
        name_id = getattr(entity, "name_id", None) or entity.id
        file_path = Path(self._data_dir) / type_name / f"{name_id}.yaml"
        if file_path.exists():
            file_path.unlink()

    def _entity_dump(self, entity: Any) -> Dict[str, Any]:
        """将实体序列化为字典。"""
        if hasattr(entity, "model_dump"):
            return entity.model_dump(mode="json", exclude_none=True)
        if hasattr(entity, "dict"):
            return entity.dict(exclude_none=True)
        return {}

    def _persist_model_instance(self, instance: ModelInstance):
        """持久化 ModelInstance。"""
        self._persist_entity("model_instances", instance.id, self._entity_dump(instance))

    def _find_model_instance_by_locator(self, locator: TurboEntityLocator) -> Optional[ModelInstance]:
        """根据 locator 查找 ModelInstance。"""
        for instance in self._model_instances.values():
            if _match_model_instance_locator(locator, instance):
                return instance
        return None

    # ==================== 查找辅助 ====================

    def _find_entity(
        self,
        collection: Dict[str, Any],
        locator: TurboEntityLocator,
    ) -> Optional[Any]:
        """根据 locator 在集合中查找实体。"""
        for entity in collection.values():
            if _match_locator(entity, locator):
                return entity
        return None

    def _filter_by_space_project(
        self,
        collection: Dict[str, Any],
        space_name: Optional[str] = None,
        project_name_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
    ) -> list:
        """按空间/项目过滤并分页。"""
        results = []
        for entity in collection.values():
            if space_name and entity.space_name != space_name:
                continue
            if project_name_id and entity.project_name_id != project_name_id:
                continue
            results.append(entity)
        return results[skip: skip + limit]

    # ================================================================
    # TurboEntityStore 实现
    # ================================================================

    # ========== 三态读取 - Agent ==========

    async def get_agent_brief(self, locator: TurboEntityLocator, **kwargs) -> Optional[AgentBrief]:
        agent = self._find_entity(self._agents, locator)
        if agent:
            return _agent_to_brief(agent)
        return None

    async def get_agent_detail(self, locator: TurboEntityLocator, **kwargs) -> Optional[AgentDetail]:
        agent = self._find_entity(self._agents, locator)
        if agent:
            return _agent_to_detail(agent)
        return None

    async def get_agent_runnable(
        self,
        locator: TurboEntityLocator,
        user_id: Optional[str] = None,
        **kwargs,
    ) -> Optional[Agent]:
        return self._find_entity(self._agents, locator)

    # ========== 三态读取 - Character ==========

    async def get_character_brief(self, locator: TurboEntityLocator, **kwargs) -> Optional[CharacterBrief]:
        char = self._find_entity(self._characters, locator)
        if char:
            return _character_to_brief(char)
        return None

    async def get_character_detail(self, locator: TurboEntityLocator, **kwargs) -> Optional[CharacterDetail]:
        char = self._find_entity(self._characters, locator)
        if char:
            return _character_to_detail(char)
        return None

    async def get_character_runnable(
        self,
        locator: TurboEntityLocator,
        user_id: Optional[str] = None,
        **kwargs,
    ) -> Optional[Character]:
        return self._find_entity(self._characters, locator)

    # ========== 三态读取 - Tool ==========

    async def get_tool_brief(self, locator: TurboEntityLocator, **kwargs) -> Optional[ToolBrief]:
        tool = self._find_entity(self._tools, locator)
        if tool:
            return _tool_to_brief(tool)
        return None

    async def get_tool_detail(self, locator: TurboEntityLocator, **kwargs) -> Optional[ToolDetail]:
        tool = self._find_entity(self._tools, locator)
        if tool:
            return _tool_to_detail(tool)
        return None

    async def get_tool_runnable(
        self,
        locator: TurboEntityLocator,
        user_id: Optional[str] = None,
        **kwargs,
    ) -> Optional[Tool]:
        return self._find_entity(self._tools, locator)

    # ========== 三态读取 - LLMModel ==========

    async def get_model_brief(self, locator: Optional[TurboEntityLocator] = None, **kwargs) -> Optional[LLMModelBrief]:
        if locator is None:
            return None
        model = self._find_entity(self._models, locator)
        if model:
            return _model_to_brief(model)
        return None

    async def get_model_detail(self, locator: Optional[TurboEntityLocator] = None, **kwargs) -> Optional[LLMModelDetail]:
        if locator is None:
            return None
        model = self._find_entity(self._models, locator)
        if model:
            return _model_to_detail(model)
        return None

    async def get_model_runnable(
        self,
        locator: Optional[TurboEntityLocator] = None,
        user_id: Optional[str] = None,
        **kwargs,
    ) -> Optional[LLMModel]:
        if locator is None:
            return None
        return self._find_entity(self._models, locator)

    # ========== Agent CRUD ==========

    async def get_agent(self, locator: TurboEntityLocator, **kwargs) -> Optional[Agent]:
        return self._find_entity(self._agents, locator)

    async def save_agent(self, agent: Agent, **kwargs) -> str:
        if not agent.id:
            agent.id = str(uuid.uuid4())
        self._agents[agent.id] = agent
        self._persist_entity("agents", agent.id, self._entity_dump(agent))
        return agent.id

    async def list_agents(
        self,
        space_name: Optional[str] = None,
        project_name_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[AgentBrief]:
        entities = self._filter_by_space_project(self._agents, space_name, project_name_id, skip, limit)
        return [_agent_to_brief(e) for e in entities]

    async def list_available_agents(
        self,
        space_name: Optional[str] = None,
        project_name_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List[AgentDetail]:
        # Package 模式下不做权限过滤，返回全部可见
        entities = self._filter_by_space_project(self._agents, space_name, project_name_id, skip, limit)
        return [_agent_to_detail(e) for e in entities]

    async def delete_agent(self, locator: TurboEntityLocator, **kwargs) -> bool:
        agent = self._find_entity(self._agents, locator)
        if agent:
            self._delete_entity_file("agents", agent)
            del self._agents[agent.id]
            return True
        return False

    # ========== Agent 绑定管理 ==========

    async def bind_agent_character(
        self,
        agent_locator: TurboEntityLocator,
        character_locator: TurboEntityLocator,
        **kwargs,
    ) -> bool:
        agent = self._find_entity(self._agents, agent_locator)
        char = self._find_entity(self._characters, character_locator)
        if not agent or not char:
            return False
        chars = getattr(agent, "actAsCharacters", None) or []
        if not any(c.id == char.id for c in chars):
            chars.append(char)
            agent.actAsCharacters = chars
            self._persist_entity("agents", agent.id, self._entity_dump(agent))
        return True

    async def unbind_agent_character(
        self,
        agent_locator: TurboEntityLocator,
        character_locator: TurboEntityLocator,
        **kwargs,
    ) -> bool:
        agent = self._find_entity(self._agents, agent_locator)
        char = self._find_entity(self._characters, character_locator)
        if not agent or not char:
            return False
        chars = getattr(agent, "actAsCharacters", None) or []
        agent.actAsCharacters = [c for c in chars if c.id != char.id]
        self._persist_entity("agents", agent.id, self._entity_dump(agent))
        return True

    async def bind_agent_tool(
        self,
        agent_locator: TurboEntityLocator,
        tool_locator: TurboEntityLocator,
        **kwargs,
    ) -> bool:
        agent = self._find_entity(self._agents, agent_locator)
        tool = self._find_entity(self._tools, tool_locator)
        if not agent or not tool:
            return False
        tools = agent.tools or []
        if not any(t.id == tool.id for t in tools):
            tools.append(tool)
            agent.tools = tools
            self._persist_entity("agents", agent.id, self._entity_dump(agent))
        return True

    async def unbind_agent_tool(
        self,
        agent_locator: TurboEntityLocator,
        tool_locator: TurboEntityLocator,
        **kwargs,
    ) -> bool:
        agent = self._find_entity(self._agents, agent_locator)
        tool = self._find_entity(self._tools, tool_locator)
        if not agent or not tool:
            return False
        agent.tools = [t for t in (agent.tools or []) if t.id != tool.id]
        self._persist_entity("agents", agent.id, self._entity_dump(agent))
        return True

    async def bind_agent_secret(
        self,
        agent_locator: TurboEntityLocator,
        secret_id: str,
        **kwargs,
    ) -> bool:
        agent = self._find_entity(self._agents, agent_locator)
        secret = self._secrets.get(secret_id)
        if not agent or not secret:
            return False
        secrets = getattr(agent, "accountSecrets", None) or []
        if not any(s.id == secret_id for s in secrets):
            secrets.append(secret)
            agent.accountSecrets = secrets
            self._persist_entity("agents", agent.id, self._entity_dump(agent))
        return True

    async def unbind_agent_secret(
        self,
        agent_locator: TurboEntityLocator,
        secret_id: str,
        **kwargs,
    ) -> bool:
        agent = self._find_entity(self._agents, agent_locator)
        if not agent:
            return False
        secrets = getattr(agent, "accountSecrets", None) or []
        agent.accountSecrets = [s for s in secrets if s.id != secret_id]
        self._persist_entity("agents", agent.id, self._entity_dump(agent))
        return True

    async def list_agent_characters(
        self,
        agent_locator: TurboEntityLocator,
        **kwargs,
    ) -> List[Character]:
        agent = self._find_entity(self._agents, agent_locator)
        if not agent:
            return []
        return getattr(agent, "actAsCharacters", None) or []

    async def list_agent_tools(
        self,
        agent_locator: TurboEntityLocator,
        **kwargs,
    ) -> List[Tool]:
        agent = self._find_entity(self._agents, agent_locator)
        if not agent:
            return []
        return agent.tools or []

    # ========== Character CRUD ==========

    async def get_character(self, locator: TurboEntityLocator, **kwargs) -> Optional[Character]:
        return self._find_entity(self._characters, locator)

    async def save_character(self, character: Character, **kwargs) -> str:
        if not character.id:
            character.id = str(uuid.uuid4())
        self._characters[character.id] = character
        self._persist_entity("characters", character.id, self._entity_dump(character))
        return character.id

    async def list_characters(
        self,
        space_name: Optional[str] = None,
        project_name_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[CharacterBrief]:
        entities = self._filter_by_space_project(self._characters, space_name, project_name_id, skip, limit)
        return [_character_to_brief(e) for e in entities]

    async def list_available_characters(
        self,
        space_name: Optional[str] = None,
        project_name_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List[CharacterDetail]:
        entities = self._filter_by_space_project(self._characters, space_name, project_name_id, skip, limit)
        return [_character_to_detail(e) for e in entities]

    async def delete_character(self, locator: TurboEntityLocator, **kwargs) -> bool:
        char = self._find_entity(self._characters, locator)
        if char:
            self._delete_entity_file("characters", char)
            del self._characters[char.id]
            return True
        return False

    # ========== Tool CRUD ==========

    async def get_tool(self, locator: TurboEntityLocator, **kwargs) -> Optional[Tool]:
        return self._find_entity(self._tools, locator)

    async def save_tool(self, tool: Tool, **kwargs) -> str:
        if not tool.id:
            tool.id = str(uuid.uuid4())
        self._tools[tool.id] = tool
        self._persist_entity("tools", tool.id, self._entity_dump(tool))
        return tool.id

    async def list_tools(
        self,
        space_name: Optional[str] = None,
        project_name_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[ToolBrief]:
        entities = self._filter_by_space_project(self._tools, space_name, project_name_id, skip, limit)
        return [_tool_to_brief(e) for e in entities]

    async def list_available_tools(
        self,
        space_name: Optional[str] = None,
        project_name_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List[ToolDetail]:
        entities = self._filter_by_space_project(self._tools, space_name, project_name_id, skip, limit)
        return [_tool_to_detail(e) for e in entities]

    async def delete_tool(self, locator: TurboEntityLocator, **kwargs) -> bool:
        tool = self._find_entity(self._tools, locator)
        if tool:
            self._delete_entity_file("tools", tool)
            del self._tools[tool.id]
            return True
        return False

    # ========== LLMModel CRUD ==========

    async def get_model(self, locator: Optional[TurboEntityLocator] = None, **kwargs) -> Optional[LLMModel]:
        if locator is None:
            return None
        return self._find_entity(self._models, locator)

    async def save_model(self, model: LLMModel, **kwargs) -> str:
        if not model.id:
            model.id = str(uuid.uuid4())
        self._models[model.id] = model
        self._persist_entity("models", model.id, self._entity_dump(model))
        return model.id

    async def list_models(
        self,
        space_name: str,
        skip: int = 0,
        limit: int = 20,
        project_name_id: Optional[str] = None,
        **kwargs,
    ) -> List[LLMModelBrief]:
        entities = self._filter_by_space_project(self._models, space_name, project_name_id, skip, limit)
        return [_model_to_brief(e) for e in entities]

    async def list_available_models(
        self,
        space_name: Optional[str] = None,
        project_name_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List[LLMModelDetail]:
        if space_name:
            entities = self._filter_by_space_project(self._models, space_name, project_name_id, skip, limit)
        else:
            entities = list(self._models.values())[skip: skip + limit]
        return [_model_to_detail(e) for e in entities]

    async def check_and_unbind_resource_dependencies(
        self,
        resource_type: str,
        locator: Optional[TurboEntityLocator] = None,
        resource_id: Optional[str] = None,
        execute_unbind: bool = False,
        **kwargs,
    ) -> dict:
        """检查资源依赖并按需解绑。Package 模式下简化实现。"""
        dependencies: Dict[str, List[str]] = {}

        # 查找 model 被引用
        if resource_type == "model" and resource_id:
            for agent_id, agent in self._agents.items():
                if agent.model and agent.model.id == resource_id:
                    dependencies.setdefault("agents", []).append(agent_id)
                    if execute_unbind:
                        agent.model = None
            for tool_id, tool in self._tools.items():
                if isinstance(tool, LLMTool) and tool.model and tool.model.id == resource_id:
                    dependencies.setdefault("tools", []).append(tool_id)
                    if execute_unbind:
                        tool.model = None

        return {"resource_type": resource_type, "dependencies": dependencies, "unbound": execute_unbind}

    async def delete_model(self, locator: TurboEntityLocator, **kwargs) -> bool:
        model = self._find_entity(self._models, locator)
        if model:
            self._delete_entity_file("models", model)
            del self._models[model.id]
            return True
        return False

    # ========== Space 管理 ==========

    async def get_space(self, space_name: str, **kwargs) -> Optional[Space]:
        return self._spaces.get(space_name)

    async def create_space(self, space: Space, **kwargs) -> str:
        self._spaces[space.space_name] = space
        return space.space_name

    async def update_space(self, space_name: str, space: Space, **kwargs) -> bool:
        if space_name in self._spaces:
            self._spaces[space_name] = space
            return True
        return False

    async def delete_space(self, space_name: str, **kwargs) -> bool:
        if space_name in self._spaces:
            del self._spaces[space_name]
            return True
        return False

    async def list_spaces(
        self,
        space_type: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[Space]:
        results = list(self._spaces.values())
        if space_type:
            results = [s for s in results if s.type == space_type]
        return results[skip: skip + limit]

    # ================================================================
    # ExternalStore 实现
    # ================================================================

    # ========== Platform CRUD ==========

    async def get_platform(self, platform_id: str, **kwargs) -> Optional[Platform]:
        return self._platforms.get(platform_id)

    async def get_platform_by_name_en(
        self,
        project_id: str,
        name_en: str,
        **kwargs,
    ) -> Optional[Platform]:
        for p in self._platforms.values():
            if getattr(p, "name_en", None) == name_en:
                return p
            # 兼容 name 字段匹配
            if p.name == name_en:
                return p
        return None

    async def save_platform(self, platform: Platform, **kwargs) -> str:
        if not platform.id:
            platform.id = str(uuid.uuid4())
        self._platforms[platform.id] = platform
        self._persist_entity("platforms", platform.id, self._entity_dump(platform))
        return platform.id

    async def list_platforms(self, skip: int = 0, limit: int = 20, **kwargs) -> List[Platform]:
        return list(self._platforms.values())[skip: skip + limit]

    async def list_available_platforms(
        self,
        project_id: str,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List[Platform]:
        # Package 模式下不做权限过滤
        return list(self._platforms.values())[skip: skip + limit]

    async def delete_platform(self, platform_id: str, **kwargs) -> bool:
        if platform_id in self._platforms:
            self._delete_entity_file("platforms", self._platforms[platform_id])
            del self._platforms[platform_id]
            return True
        return False

    # ========== AuthMethod CRUD ==========

    async def get_auth_method(self, method_id: str, **kwargs) -> Optional[AuthMethod]:
        return self._auth_methods.get(method_id)

    async def create_auth_method(
        self,
        platform_id: str,
        data: Dict[str, Any],
        creator_id: str,
        **kwargs,
    ) -> AuthMethod:
        method_id = str(uuid.uuid4())
        data["id"] = method_id
        data["platformId"] = platform_id
        method = AuthMethod.model_validate(data)
        self._auth_methods[method_id] = method
        self._persist_entity("auth_methods", method_id, self._entity_dump(method))
        return method

    async def update_auth_method(
        self,
        method_id: str,
        data: Dict[str, Any],
        **kwargs,
    ) -> Optional[AuthMethod]:
        existing = self._auth_methods.get(method_id)
        if not existing:
            return None
        updated_data = self._entity_dump(existing)
        updated_data.update(data)
        method = AuthMethod.model_validate(updated_data)
        self._auth_methods[method_id] = method
        self._persist_entity("auth_methods", method_id, self._entity_dump(method))
        return method

    async def save_auth_method(self, auth_method: AuthMethod, **kwargs) -> str:
        if not auth_method.id:
            auth_method.id = str(uuid.uuid4())
        self._auth_methods[auth_method.id] = auth_method
        self._persist_entity("auth_methods", auth_method.id, self._entity_dump(auth_method))
        return auth_method.id

    async def list_auth_methods(
        self,
        platform_id: str,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[AuthMethod]:
        results = [m for m in self._auth_methods.values() if getattr(m, "platformId", None) == platform_id]
        return results[skip: skip + limit]

    async def delete_auth_method(self, method_id: str, **kwargs) -> bool:
        if method_id in self._auth_methods:
            self._delete_entity_file("auth_methods", self._auth_methods[method_id])
            del self._auth_methods[method_id]
            return True
        return False

    # ========== McpServerSpec CRUD ==========

    async def get_mcp_server(self, server_id: str, **kwargs) -> Optional[McpServerSpec]:
        return self._mcp_servers.get(server_id)

    async def save_mcp_server(self, server: McpServerSpec, **kwargs) -> str:
        if not server.id:
            server.id = str(uuid.uuid4())
        self._mcp_servers[server.id] = server
        self._persist_entity("mcp_servers", server.id, self._entity_dump(server))
        return server.id

    async def list_mcp_servers(self, skip: int = 0, limit: int = 20, **kwargs) -> List[McpServerSpec]:
        return list(self._mcp_servers.values())[skip: skip + limit]

    async def delete_mcp_server(self, server_id: str, **kwargs) -> bool:
        if server_id in self._mcp_servers:
            self._delete_entity_file("mcp_servers", self._mcp_servers[server_id])
            del self._mcp_servers[server_id]
            return True
        return False

    # ========== McpResourceDescriptor CRUD ==========

    async def get_mcp_resource(self, resource_id: str, **kwargs) -> Optional[McpResourceDescriptor]:
        return self._mcp_resources.get(resource_id)

    async def save_mcp_resource(self, resource: McpResourceDescriptor, **kwargs) -> str:
        if not resource.id:
            resource.id = str(uuid.uuid4())
        self._mcp_resources[resource.id] = resource
        self._persist_entity("mcp_resources", resource.id, self._entity_dump(resource))
        return resource.id

    async def list_mcp_resources(
        self,
        server_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[McpResourceDescriptor]:
        results = list(self._mcp_resources.values())
        if server_id:
            results = [r for r in results if getattr(r, "server_id", None) == server_id]
        return results[skip: skip + limit]

    async def delete_mcp_resource(self, resource_id: str, **kwargs) -> bool:
        if resource_id in self._mcp_resources:
            self._delete_entity_file("mcp_resources", self._mcp_resources[resource_id])
            del self._mcp_resources[resource_id]
            return True
        return False

    # ================================================================
    # ResourceEntityStore 实现
    # ================================================================

    async def get_project(self, project_id: str, **kwargs) -> Optional[Project]:
        return self._projects.get(project_id)

    async def save_project(self, project: Project, **kwargs) -> str:
        if not project.id:
            project.id = str(uuid.uuid4())
        self._projects[project.id] = project
        self._persist_entity("projects", project.id, self._entity_dump(project))
        return project.id

    async def list_projects(
        self,
        org_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[Project]:
        results = list(self._projects.values())
        if org_id:
            results = [project for project in results if getattr(project, "orgProjectId", None) == org_id]
        return results[skip: skip + limit]

    async def delete_project(self, project_id: str, **kwargs) -> bool:
        if project_id in self._projects:
            self._delete_entity_file("projects", self._projects[project_id])
            del self._projects[project_id]
            return True
        return False

    async def upload_knowledge_resource(
        self,
        spec: KnowledgeResourceUploadSpec,
        **kwargs,
    ) -> KnowledgeResource:
        resource = KnowledgeResource(
            id=spec.resource_id,
            belong_to_project_path=spec.project_id or spec.space_id,
            name=spec.name,
            type=spec.knowledge_type,
            status="uploaded",
            fileType=spec.file_type,
            filename=spec.filename,
            uri=spec.local_file_uri,
            mime_type=spec.mime_type,
        )
        await self.save_knowledge_resource(resource, **kwargs)
        return resource

    async def get_knowledge_resource(self, resource_id: str, **kwargs) -> Optional[KnowledgeResource]:
        return self._knowledge_resources.get(resource_id)

    async def save_knowledge_resource(self, resource: KnowledgeResource, **kwargs) -> str:
        if not resource.id:
            resource.id = str(uuid.uuid4())
        self._knowledge_resources[resource.id] = resource
        self._persist_entity("knowledge_resources", resource.id, self._entity_dump(resource))
        return resource.id

    async def list_knowledge_resources(
        self,
        project_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[KnowledgeResource]:
        results = list(self._knowledge_resources.values())
        if project_id:
            results = [item for item in results if getattr(item, "belong_to_project_path", None) == project_id]
        return results[skip: skip + limit]

    async def delete_knowledge_resource(self, resource_id: str, **kwargs) -> bool:
        if resource_id in self._knowledge_resources:
            self._delete_entity_file("knowledge_resources", self._knowledge_resources[resource_id])
            del self._knowledge_resources[resource_id]
            return True
        return False

    async def bind_knowledge_resources_to_setting(
        self,
        setting_id: str,
        knowledge_ids: List[str],
        **kwargs,
    ) -> bool:
        setting = self._business_settings.get(setting_id)
        if not setting:
            return False
        knowledges = [self._knowledge_resources[knowledge_id] for knowledge_id in knowledge_ids if knowledge_id in self._knowledge_resources]
        setting.knowledges = knowledges
        self._persist_entity("business_settings", setting.id, self._entity_dump(setting))
        return True

    async def get_workset(self, workset_id: str, **kwargs) -> Optional[Workset]:
        return self._worksets.get(workset_id)

    async def save_workset(self, workset: Workset, **kwargs) -> str:
        if not workset.id:
            workset.id = str(uuid.uuid4())
        self._worksets[workset.id] = workset
        self._persist_entity("worksets", workset.id, self._entity_dump(workset))
        return workset.id

    async def list_worksets(
        self,
        project_id: Optional[str] = None,
        owner_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[Workset]:
        results = list(self._worksets.values())
        if project_id:
            results = [item for item in results if getattr(item, "belong_to_project_path", None) == project_id]
        if owner_id:
            results = [item for item in results if getattr(item, "ownerId", None) == owner_id]
        return results[skip: skip + limit]

    async def delete_workset(self, workset_id: str, **kwargs) -> bool:
        if workset_id in self._worksets:
            self._delete_entity_file("worksets", self._worksets[workset_id])
            del self._worksets[workset_id]
            return True
        return False

    async def get_business_settings(self, setting_ids: List[str], **kwargs) -> List[BusinessSetting]:
        return [self._business_settings.get(setting_id) for setting_id in setting_ids if setting_id in self._business_settings]

    async def save_business_setting(self, setting: BusinessSetting, **kwargs) -> str:
        if not setting.id:
            setting.id = str(uuid.uuid4())
        self._business_settings[setting.id] = setting
        self._persist_entity("business_settings", setting.id, self._entity_dump(setting))
        return setting.id

    async def list_business_settings(
        self,
        locator: Optional[TurboEntityLocator] = None,    
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[BusinessSetting]:
        results = list(self._business_settings.values())
        project_path = locator.space_name+"/"+locator.project_name_id if locator and locator.space_name and locator.project_name_id else None
        if project_path:
            results = [item for item in results if getattr(item, "belong_to_project_path", None) == project_path]
        return results[skip: skip + limit]

    async def list_available_business_settings(
        self,
        locator: Optional[TurboEntityLocator] = None,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List[BusinessSetting]:
        return await self.list_business_settings(locator=locator, skip=skip, limit=limit, **kwargs)

    async def delete_business_setting(self, setting_id: str, **kwargs) -> bool:
        if setting_id in self._business_settings:
            self._delete_entity_file("business_settings", self._business_settings[setting_id])
            del self._business_settings[setting_id]
            return True
        return False

    async def get_secret(self, secret_id: str, **kwargs) -> Optional[Secret]:
        return self._secrets.get(secret_id)

    async def save_secret(self, secret: Secret, **kwargs) -> str:
        if not secret.id:
            secret.id = str(uuid.uuid4())
        self._secrets[secret.id] = secret
        self._persist_entity("secrets", secret.id, self._entity_dump(secret))
        return secret.id

    async def list_secrets(
        self,
        platform_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[Secret]:
        results = list(self._secrets.values())
        if platform_id:
            results = [item for item in results if getattr(item, "platformId", None) == platform_id]
        return results[skip: skip + limit]

    async def list_available_secrets(
        self,
        platform_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List[Secret]:
        return await self.list_secrets(platform_id=platform_id, skip=skip, limit=limit, **kwargs)

    async def delete_secret(self, secret_id: str, **kwargs) -> bool:
        if secret_id in self._secrets:
            self._delete_entity_file("secrets", self._secrets[secret_id])
            del self._secrets[secret_id]
            return True
        return False

    async def get_endpoint(self, endpoint_id: str, **kwargs) -> Optional[Endpoint]:
        return self._endpoints.get(endpoint_id)

    async def save_endpoint(self, endpoint: Endpoint, **kwargs) -> str:
        if not endpoint.id:
            endpoint.id = str(uuid.uuid4())
        self._endpoints[endpoint.id] = endpoint
        self._persist_entity("endpoints", endpoint.id, self._entity_dump(endpoint))
        return endpoint.id

    async def delete_endpoint(self, endpoint_id: str, **kwargs) -> bool:
        if endpoint_id in self._endpoints:
            self._delete_entity_file("endpoints", self._endpoints[endpoint_id])
            del self._endpoints[endpoint_id]
            return True
        return False

    async def list_model_instance_endpoints(
        self,
        locator: Optional[TurboEntityLocator] = None,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[EndpointRef]:
        if locator is None:
            endpoints = list(self._endpoints.values())
        else:
            endpoint_ids = {
                instance.endpoint.id
                for instance in self._model_instances.values()
                if instance.endpoint and _match_model_instance_locator(locator, instance)
            }
            endpoints = [self._endpoints[endpoint_id] for endpoint_id in endpoint_ids if endpoint_id in self._endpoints]
        return [_endpoint_to_ref(endpoint) for endpoint in endpoints[skip: skip + limit]]

    async def get_model_instance_brief(
        self,
        locator: TurboEntityLocator,
        **kwargs,
    ) -> Optional[ModelInstanceRef]:
        instance = self._find_model_instance_by_locator(locator)
        if instance is None:
            return None
        return _model_instance_to_ref(instance)

    async def get_model_instance_detail(
        self,
        locator: TurboEntityLocator,
        **kwargs,
    ) -> Optional[ModelInstanceDetail]:
        instance = self._find_model_instance_by_locator(locator)
        if instance is None:
            return None
        return _model_instance_to_detail(instance)

    async def get_model_instance_runnable(
        self,
        locator: TurboEntityLocator,
        **kwargs,
    ) -> Optional[ModelInstance]:
        return self._find_model_instance_by_locator(locator)

    async def get_model_instance(self, instance_id: str, **kwargs) -> Optional[ModelInstance]:
        return self._model_instances.get(instance_id)

    async def save_model_instance(
        self,
        instance: ModelInstance,
        locator: TurboEntityLocator,
        **kwargs,
    ) -> str:
        if not instance.id:
            instance.id = str(uuid.uuid4())
        if locator.space_name and locator.space_name != instance.space_name:
            raise ValueError("locator.space_name 与 instance.space_name 不一致")
        if locator.project_name_id and locator.project_name_id != getattr(instance, "project_name_id", None):
            raise ValueError("locator.project_name_id 与 instance.project_name_id 不一致")
        if locator.series_name and locator.series_name != instance.series_name:
            raise ValueError("locator.series_name 与 instance.series_name 不一致")
        if locator.name_id and locator.name_id != instance.model_name:
            raise ValueError("locator.name_id 与 instance.model_name 不一致")
        if locator.version_tag and locator.version_tag != instance.version:
            raise ValueError("locator.version_tag 与 instance.version 不一致")
        self._model_instances[instance.id] = instance
        self._persist_model_instance(instance)
        return instance.id

    async def delete_model_instance(self, instance_id: str, **kwargs) -> bool:
        if instance_id in self._model_instances:
            self._delete_entity_file("model_instances", self._model_instances[instance_id])
            del self._model_instances[instance_id]
            return True
        return False

    async def list_model_instances(
        self,
        locator: Optional[TurboEntityLocator] = None,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[ModelInstanceRef]:
        results: List[ModelInstanceRef] = []
        for instance in self._model_instances.values():
            if locator and not _match_model_instance_locator(locator, instance):
                continue
            results.append(_model_instance_to_ref(instance))
        return results[skip: skip + limit]

    async def update_model_instance(
        self,
        locator: TurboEntityLocator,
        instance: ModelInstance,
        **kwargs,
    ) -> bool:
        existing = self._find_model_instance_by_locator(locator)
        if existing is None:
            return False
        instance.id = existing.id
        if locator.project_name_id and locator.project_name_id != getattr(instance, "project_name_id", None):
            raise ValueError("locator.project_name_id 与 instance.project_name_id 不一致")
        self._model_instances[existing.id] = instance
        self._persist_model_instance(instance)
        return True

    async def create_model_series(
        self,
        series: ModelSeries,
        creator_id: str,
        **kwargs,
    ) -> str:
        self._model_series[series.series_name] = series
        self._persist_entity("model_series", series.series_name, self._entity_dump(series))
        return series.series_name

    async def get_model_series(self, series_name: str, **kwargs) -> Optional[ModelSeries]:
        return self._model_series.get(series_name)

    async def update_model_series(
        self,
        series_name: str,
        series: ModelSeries,
        **kwargs,
    ) -> bool:
        if series_name not in self._model_series:
            return False
        self._model_series[series.series_name] = series
        if series.series_name != series_name:
            self._model_series.pop(series_name, None)
        self._persist_entity("model_series", series.series_name, self._entity_dump(series))
        return True

    async def delete_model_series(self, series_name: str, **kwargs) -> bool:
        if series_name in self._model_series:
            series = self._model_series[series_name]
            self._delete_entity_file("model_series", series)
            del self._model_series[series_name]
            return True
        return False

    async def list_model_series(
        self,
        user_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[ModelSeries]:
        return list(self._model_series.values())[skip: skip + limit]

    async def list_available_model_series(
        self,
        space_name: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List[ModelSeries]:
        return await self.list_model_series(skip=skip, limit=limit, **kwargs)

    # ================================================================
    # 便捷方法
    # ================================================================

    def get_all_entities(self) -> List[Any]:
        """获取所有已加载的实体。"""
        all_entities: List[Any] = []
        all_entities.extend(self._projects.values())
        all_entities.extend(self._platforms.values())
        all_entities.extend(self._auth_methods.values())
        all_entities.extend(self._secrets.values())
        all_entities.extend(self._knowledge_resources.values())
        all_entities.extend(self._business_settings.values())
        all_entities.extend(self._mcp_servers.values())
        all_entities.extend(self._mcp_resources.values())
        all_entities.extend(self._worksets.values())
        all_entities.extend(self._endpoints.values())
        all_entities.extend(self._model_instances.values())
        all_entities.extend(self._model_series.values())
        all_entities.extend(self._models.values())
        all_entities.extend(self._tools.values())
        all_entities.extend(self._characters.values())
        all_entities.extend(self._agents.values())
        return all_entities

    def get_summary(self) -> Dict[str, int]:
        """获取各类实体数量摘要。"""
        return {
            "agents": len(self._agents),
            "characters": len(self._characters),
            "tools": len(self._tools),
            "models": len(self._models),
            "platforms": len(self._platforms),
            "auth_methods": len(self._auth_methods),
            "secrets": len(self._secrets),
            "knowledge_resources": len(self._knowledge_resources),
            "business_settings": len(self._business_settings),
            "projects": len(self._projects),
            "spaces": len(self._spaces),
            "mcp_servers": len(self._mcp_servers),
            "mcp_resources": len(self._mcp_resources),
            "worksets": len(self._worksets),
            "endpoints": len(self._endpoints),
            "model_instances": len(self._model_instances),
            "model_series": len(self._model_series),
        }

