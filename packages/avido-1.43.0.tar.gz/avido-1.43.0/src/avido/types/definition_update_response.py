# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .eval_definition import EvalDefinition

__all__ = ["DefinitionUpdateResponse"]


class DefinitionUpdateResponse(BaseModel):
    """Response containing an eval definition"""

    data: EvalDefinition
