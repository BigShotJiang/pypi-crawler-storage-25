# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from . import eval_definition as _eval_definition
from .._models import BaseModel

__all__ = ["Topic", "AssignedUser", "EvalDefinition", "EvalDefinitionConfig"]


class AssignedUser(BaseModel):
    """Information about the assigned user"""

    id: str
    """User ID"""

    email: str
    """User email"""

    name: str
    """User full name"""

    image: Optional[str] = None
    """User profile image URL"""


class EvalDefinitionConfig(BaseModel):
    expected: Union[str, List[str]]


class EvalDefinition(BaseModel):
    eval_definition: _eval_definition.EvalDefinition = FieldInfo(alias="evalDefinition")

    topic_id: str = FieldInfo(alias="topicId")

    config: Optional[EvalDefinitionConfig] = None


class Topic(BaseModel):
    """Details about a single Topic"""

    id: str
    """Unique identifier of the topic"""

    baseline: Optional[float] = None
    """Optional baseline score for this topic"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the topic was created"""

    is_documents_verified: bool = FieldInfo(alias="isDocumentsVerified")
    """Whether all documents assigned to the topic are signed off"""

    is_tasks_verified: bool = FieldInfo(alias="isTasksVerified")
    """Whether all tasks in the topic are verified (excludes deduced tasks)"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the topic was last modified"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns this topic"""

    status: Literal["DRAFT", "ACTIVE"]
    """Status of the topic (DRAFT or ACTIVE)"""

    title: str
    """Title of the topic"""

    application_id: Optional[str] = FieldInfo(alias="applicationId", default=None)
    """Optional application ID this topic belongs to"""

    assigned_to: Optional[str] = FieldInfo(alias="assignedTo", default=None)
    """User ID of the assigned user"""

    assigned_user: Optional[AssignedUser] = FieldInfo(alias="assignedUser", default=None)
    """Information about the assigned user"""

    eval_definitions: Optional[List[EvalDefinition]] = FieldInfo(alias="evalDefinitions", default=None)
    """Evaluation definitions linked to this topic"""
