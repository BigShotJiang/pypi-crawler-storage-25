# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ..._models import BaseModel
from .document_version import DocumentVersion

__all__ = ["VersionListResponse", "Document", "DocumentScrapeJob", "DocumentScrapeJobPage"]


class DocumentScrapeJobPage(BaseModel):
    url: str
    """The URL of the page"""

    category: Optional[str] = None
    """The category of the page"""

    description: Optional[str] = None
    """The description of the page"""

    title: Optional[str] = None
    """The title of the page"""


class DocumentScrapeJob(BaseModel):
    """Optional scrape job that generated this document"""

    id: str
    """The unique identifier of the scrape job"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the scrape job was created"""

    initiated_by: str = FieldInfo(alias="initiatedBy")
    """User ID who initiated the scrape job"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the scrape job was last modified"""

    name: str
    """The name/title of the scrape job"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns the scrape job"""

    quickstart_status: Literal["PROCESSING", "REVIEW", "COMPLETED", "NOT_ASSOCIATED"] = FieldInfo(
        alias="quickstartStatus"
    )
    """The quickstart association status of the scrape job"""

    status: Literal["MAPPING", "PENDING", "IN_PROGRESS", "COMPLETED", "FAILED"]
    """Current status of the scrape job"""

    url: str
    """The URL that was scraped"""

    application_id: Optional[str] = FieldInfo(alias="applicationId", default=None)
    """Optional application ID this scrape job belongs to"""

    pages: Optional[List[DocumentScrapeJobPage]] = None
    """The pages scraped from the URL"""


class Document(BaseModel):
    """
    A Core Document represents a piece of content that can be organized hierarchically with parent-child relationships and supports versioning
    """

    id: str
    """Unique identifier of the document"""

    assignee: str
    """User ID of the person assigned to this document"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the document was created"""

    is_verified: bool = FieldInfo(alias="isVerified")
    """Whether the document has been signed off during quickstart review"""

    modified_at: datetime = FieldInfo(alias="modifiedAt")
    """When the document was last modified"""

    optimized: bool
    """Whether the document has been optimized"""

    org_id: str = FieldInfo(alias="orgId")
    """Organization ID that owns this document"""

    type: Literal["KNOWLEDGE", "POLICY"]
    """Type of the document. Valid options: KNOWLEDGE, POLICY."""

    application_id: Optional[str] = FieldInfo(alias="applicationId", default=None)
    """Optional application ID this document belongs to"""

    scrape_job: Optional[DocumentScrapeJob] = FieldInfo(alias="scrapeJob", default=None)
    """Optional scrape job that generated this document"""

    scrape_job_id: Optional[str] = FieldInfo(alias="scrapeJobId", default=None)
    """Optional ID of the scrape job that generated this document"""

    topic_id: Optional[str] = FieldInfo(alias="topicId", default=None)
    """Optional ID of the topic this document belongs to"""


class VersionListResponse(BaseModel):
    """Response containing all versions of a document"""

    document: Document
    """
    A Core Document represents a piece of content that can be organized
    hierarchically with parent-child relationships and supports versioning
    """

    versions: List[DocumentVersion]
