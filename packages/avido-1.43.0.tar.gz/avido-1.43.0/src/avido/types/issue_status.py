# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["IssueStatus"]

IssueStatus: TypeAlias = Literal["OPEN", "RESOLVED", "REJECTED"]
