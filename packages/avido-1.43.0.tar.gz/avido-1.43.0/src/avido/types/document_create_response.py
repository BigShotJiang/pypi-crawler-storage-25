# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel
from .document import Document

__all__ = ["DocumentCreateResponse"]


class DocumentCreateResponse(BaseModel):
    """Successful response containing the document data"""

    document: Document
