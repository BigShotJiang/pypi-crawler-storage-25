# mcp-server-pp

MCP server for PharmaPendium data extraction — converts extraction results to XLSX and uploads to Azure Blob Storage.

## Tool

### `save_extraction`

Converts a JSON array of extraction results into an XLSX file, uploads it to Azure Blob Storage, and returns a download URL (valid 7 days).

If the user provided corrections or new rules during the extraction session, pass them in `notes` — they are saved as a separate **Notes** sheet inside the XLSX for traceability.

**Parameters:**
- `json_data` (required): JSON array string — extraction results, one object per row
- `file_name` (optional): Output filename (with or without `.xlsx`). Defaults to `extraction_results.xlsx`
- `notes` (optional): User corrections, comments, or new rules applied in this session

**Required environment variable:** `AZURE_STORAGE_CONNECTION_STRING`

## Usage

### With uvx (no installation needed)

```bash
uvx mcp-server-pp@1.0.1
```

### MCP client config (e.g. Codemie, Claude Desktop)

```json
{
  "mcpServers": {
    "pp-tools": {
      "command": "uvx",
      "args": ["mcp-server-pp@1.0.1"],
      "env": {
        "AZURE_STORAGE_CONNECTION_STRING": "${AZURE_STORAGE_CONNECTION_STRING}"
      }
    }
  }
}
```
