"""
MCP server providing tools for PharmaPendium data extraction workflows.

Tools:
  - save_extraction: Convert a JSON array into an XLSX file, upload to Azure
                     Blob Storage, and return a download link. Optionally
                     saves user corrections/notes as a separate sheet.

Environment variables (required):
  - AZURE_STORAGE_CONNECTION_STRING: connection string for the storage account.
  - OUTPUT_CONTAINER: blob container name (default: "codemie-output").

Usage:
  uvx mcp-server-pp          # install from PyPI and run (stdio)
  mcp-server-pp              # run directly if installed
  python -m mcp_server_pp    # run as module
"""

import io
import json
import os
from datetime import datetime, timezone

import pandas as pd
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    TextContent,
    Tool,
)

server = Server("mcp-server-pp")

XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _json_to_dataframe(json_str: str) -> pd.DataFrame | str:
    """Parse JSON string into a DataFrame. Returns error string on failure."""
    try:
        data = json.loads(json_str)
    except json.JSONDecodeError as e:
        return f"Invalid JSON: {e}"

    if not isinstance(data, list):
        return "json_data must be a JSON array"

    if len(data) == 0:
        return "JSON array is empty, nothing to convert"

    return pd.DataFrame(data)


def _dataframe_to_xlsx_bytes(df: pd.DataFrame, notes: str | None = None) -> bytes:
    """Convert DataFrame to XLSX bytes. Optionally adds a Notes sheet."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Data")
        if notes:
            notes_ws = writer.book.create_sheet("Notes")
            notes_ws["A1"] = "Extraction Notes"
            for i, line in enumerate(notes.splitlines(), start=2):
                notes_ws.cell(row=i, column=1, value=line)
    buf.seek(0)
    return buf.read()


def _ensure_xlsx_ext(name: str) -> str:
    return name if name.endswith(".xlsx") else name + ".xlsx"


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="save_extraction",
            description=(
                "Convert extraction results (JSON array of objects) into an XLSX file, "
                "upload it to Azure Blob Storage, and return a download URL. "
                "Use this as the mandatory final step of every extraction. "
                "If the user provided corrections, comments, or new rules in this session, "
                "pass them in the notes parameter — they will be saved as a Notes sheet "
                "inside the XLSX for traceability. To apply a correction: update the "
                "json_data to reflect the fix, then call this tool again with the corrected "
                "data and the correction description in notes."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "json_data": {
                        "type": "string",
                        "description": (
                            "A JSON array of extraction result objects. "
                            "Example: '[{\"col1\": \"val1\", \"col2\": 2}, ...]'"
                        ),
                    },
                    "file_name": {
                        "type": "string",
                        "description": (
                            "Output filename (with or without .xlsx extension). "
                            "Defaults to 'extraction_results'."
                        ),
                        "default": "extraction_results",
                    },
                    "notes": {
                        "type": "string",
                        "description": (
                            "Optional. User corrections, comments, or new rules applied "
                            "to this extraction. Saved as a Notes sheet in the XLSX. "
                            "Example: 'User correction: row 3 dose changed from 10mg to 5mg. "
                            "New rule: always use mg/L for plasma concentration units.'"
                        ),
                    },
                },
                "required": ["json_data"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list:
    if name == "save_extraction":
        return _handle_save_extraction(arguments)
    else:
        raise ValueError(f"Unknown tool: {name}")


# ---------------------------------------------------------------------------
# Tool handler
# ---------------------------------------------------------------------------

def _handle_save_extraction(arguments: dict) -> list:
    from azure.storage.blob import BlobSasPermissions, ContentSettings, generate_blob_sas
    from azure.storage.blob import BlobServiceClient

    conn_str = os.environ.get("AZURE_STORAGE_CONNECTION_STRING", "")
    if not conn_str:
        return [TextContent(
            type="text",
            text="Error: AZURE_STORAGE_CONNECTION_STRING environment variable is not set.",
        )]

    container_name = os.environ.get("OUTPUT_CONTAINER", "codemie-output")
    json_str = arguments["json_data"]
    file_name = _ensure_xlsx_ext(arguments.get("file_name", "extraction_results"))
    notes = arguments.get("notes")

    result = _json_to_dataframe(json_str)
    if isinstance(result, str):
        return [TextContent(type="text", text=result)]

    df = result
    xlsx_bytes = _dataframe_to_xlsx_bytes(df, notes=notes)

    # Build blob path: YYMMDD-HHMMSS/filename.xlsx
    timestamp = datetime.now(timezone.utc).strftime("%y%m%d-%H%M%S")
    blob_path = f"{timestamp}/{file_name}"

    # Upload to Azure Blob Storage
    blob_service = BlobServiceClient.from_connection_string(conn_str)
    blob_client = blob_service.get_blob_client(container=container_name, blob=blob_path)
    blob_client.upload_blob(
        xlsx_bytes,
        content_settings=ContentSettings(content_type=XLSX_MIME),
        overwrite=True,
    )

    # Generate SAS download URL (valid for 7 days)
    from datetime import timedelta
    account_name = blob_service.account_name
    account_key = blob_service.credential.account_key

    sas_token = generate_blob_sas(
        account_name=account_name,
        container_name=container_name,
        blob_name=blob_path,
        account_key=account_key,
        permission=BlobSasPermissions(read=True),
        expiry=datetime.now(timezone.utc) + timedelta(days=7),
    )

    download_url = f"https://{account_name}.blob.core.windows.net/{container_name}/{blob_path}?{sas_token}"

    notes_line = "\n\nNotes recorded: yes (see Notes sheet in the file)." if notes else ""

    return [
        TextContent(
            type="text",
            text=(
                f"Created {file_name} with {len(df)} rows and {len(df.columns)} columns."
                f"{notes_line}\n\n"
                f"Uploaded to: `{container_name}/{blob_path}`\n\n"
                f"Download link (valid 7 days): {download_url}"
            ),
        ),
    ]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    import asyncio

    async def _run():
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )

    asyncio.run(_run())
