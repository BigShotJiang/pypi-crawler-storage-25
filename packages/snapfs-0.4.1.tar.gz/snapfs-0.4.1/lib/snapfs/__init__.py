#!/usr/bin/env python3
#
# Copyright (c) 2025 SnapFS, LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

__author__ = "Ryan Galloway <ryan@rsg.io>"
__prog__ = "snapfs"
__version__ = "0.4.1"
__doc__ = """
Intelligent filesystem indexing and deduplication for massive data sets
"""

from .client import SnapFS
from .gateway import GatewayClient

__all__ = ["SnapFS", "GatewayClient"]
