"""Bulk-decompile binaries via Ghidra into a browsable source tree."""

__version__ = "0.2.0"
