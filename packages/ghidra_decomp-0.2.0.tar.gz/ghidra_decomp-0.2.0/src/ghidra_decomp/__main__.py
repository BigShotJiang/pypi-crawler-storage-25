"""Allow running as python -m ghidra_decomp."""

from .cli import main

main()
