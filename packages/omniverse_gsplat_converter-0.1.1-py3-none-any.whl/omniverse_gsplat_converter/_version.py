# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

__all__ = [
    "__version__",
    "get_version",
]

__version__ = "0.1.1"


def get_version():
    """Returns the version of this module."""
    return __version__
