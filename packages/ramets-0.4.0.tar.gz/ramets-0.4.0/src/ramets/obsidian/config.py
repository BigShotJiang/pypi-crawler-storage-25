"""3D graph plugin configuration for Obsidian."""

from __future__ import annotations

# Placeholder for v0.3.0 — 3D graph plugin configuration
# Will generate config for the "New 3D Graph" plugin (Apoo711/obsidian-3d-graph)
