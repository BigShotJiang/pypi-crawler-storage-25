"""Obsidian vault generation with branch layers and 3D graph."""
