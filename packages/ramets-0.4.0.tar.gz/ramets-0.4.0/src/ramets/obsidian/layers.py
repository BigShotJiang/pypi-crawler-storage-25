"""Branch layer rendering for Obsidian vault.

Generates per-branch folders showing only delta nodes (what changed).
"""

from __future__ import annotations

# Placeholder for v0.2.0 — branch layer rendering
# Will create branch--feat--xyz/ folders with only delta nodes
