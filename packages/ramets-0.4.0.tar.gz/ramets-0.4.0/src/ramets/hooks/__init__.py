"""Hook generators — git hooks and Claude Code hooks."""
