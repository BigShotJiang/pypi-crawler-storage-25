"""Allow running as `python -m ramets`."""

from ramets.cli import main

main()
