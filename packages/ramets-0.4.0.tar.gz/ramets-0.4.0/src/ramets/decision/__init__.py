"""Decision tracking — structured record of AI suggestions and user choices."""
