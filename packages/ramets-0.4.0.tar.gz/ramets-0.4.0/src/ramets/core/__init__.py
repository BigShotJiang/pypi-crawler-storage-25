"""Core storage and graph operations."""
