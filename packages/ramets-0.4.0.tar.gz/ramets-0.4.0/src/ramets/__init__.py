"""ramets — Per-branch AI coding context.

Your codebase is one organism. Each branch is a ramet.

Named after Pando (Populus tremuloides), the world's largest organism —
a single aspen clone where individual trunks (ramets) share one root system (genet).

- Genet: the shared base knowledge graph (common ancestor of all branches)
- Ramets: per-branch delta-encoded graphs (individual trunks from the shared root)
- Decisions: structured tracking of AI suggestions and user choices
"""

__version__ = "0.4.0"
