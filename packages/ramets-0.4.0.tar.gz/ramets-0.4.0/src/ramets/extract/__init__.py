"""AST extraction — thin wrapper around graphify."""
