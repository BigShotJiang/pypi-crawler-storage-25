"""MCP server — 15 tools for AI coding assistants."""
