import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import App from "./App";
import type {
  AccessSummary,
  AuditEvent,
  ConfigSummary,
  DebugTrace,
  ModelSummary,
  Overview,
  PolicySummary,
  ProviderSummary,
  SessionSummary,
  SystemSummary,
} from "./types";

const api = vi.hoisted(() => ({
  fetchAccess: vi.fn(),
  fetchConfig: vi.fn(),
  fetchDebugTrace: vi.fn(),
  fetchEvent: vi.fn(),
  fetchEvents: vi.fn(),
  fetchModels: vi.fn(),
  fetchOverview: vi.fn(),
  fetchPolicy: vi.fn(),
  fetchProviders: vi.fn(),
  fetchSession: vi.fn(),
  fetchSystem: vi.fn(),
  loginSession: vi.fn(),
  logoutSession: vi.fn(),
}));

vi.mock("./api", () => ({
  ApiError: class ApiError extends Error {
    status: number;
    code: string | null;

    constructor(path: string, status: number, message?: string, code?: string | null) {
      super(message ?? `Request failed for ${path}: ${status}`);
      this.name = "ApiError";
      this.status = status;
      this.code = code ?? null;
    }
  },
  ...api,
}));

const sessionFixture: SessionSummary = {
  viewer: {
    user: "operator",
    roles: ["admin"],
  },
  auth_mode: "session",
  access_mode: "loopback",
  trace_access: true,
  trace_allowed_roles: ["admin"],
  content_trace_enabled: true,
  device_id: null,
  trusted_proxy_login: null,
  session_secure_cookies: false,
};

const overviewFixture: Overview = {
  total_requests: 42,
  masked_requests: 21,
  blocked_requests: 3,
  route_local_requests: 1,
  rehydrated_responses: 19,
  error_requests: 2,
  provider_counts: { openai: 42 },
  detector_counts: { pii: 7 },
  action_counts: { mask: 5 },
  last_event_at: "2026-04-03T18:00:00Z",
  gateway: {
    schema_version: "gateway/v2",
    artifact_dir: "/tmp/generated",
    warnings: ["doctor warning"],
    provider_summary: {
      ready: 1,
      total: 2,
      last_materialized_at: "2026-04-03T17:59:00Z",
    },
    model_summary: {
      ready: 2,
      total: 3,
      recommended_models: ["stronk-lm-hot"],
    },
    doctor: {
      status: "ready",
      private_surface_posture: "sealed",
      bundle_version: "stronk-gateway-deploy.bundle/v1alpha1",
    },
    hermes: {
      public_base_url: "https://gateway.example.com",
      recommended_models: ["stronk-lm-hot"],
      credential_flow: "cli_only",
      copy_snippets: [
        {
          label: "Hermes",
          snippet: "hermes login",
        },
      ],
    },
  },
};

const overviewUnsafeSnippetFixture: Overview = {
  ...overviewFixture,
  gateway: {
    ...overviewFixture.gateway,
    hermes: {
      ...overviewFixture.gateway.hermes,
      copy_snippets: [
        {
          label: "Hermes",
          snippet:
            'export HERMES_API_KEY="sk-live-secret"\ncurl -H "Authorization: Bearer sk-live-secret" https://gateway.example.com',
        },
      ],
    },
  },
};

const configFixture: ConfigSummary = {
  app_name: "Stronk Gateway",
  app_env: "test",
  proxy_surfaces: ["public"],
  control_plane: {
    admin_api_enabled: true,
    admin_ui_enabled: true,
    audit_storage_enabled: true,
    ui_built: true,
    content_trace_enabled: true,
    content_trace_ttl_seconds: 300,
  },
  upstreams: {
    openai_host: "api.openai.com",
    anthropic_host: "api.anthropic.com",
    allow_insecure_upstreams: false,
    allow_nonstandard_upstream_hosts: false,
  },
  policy_actions: {
    email: "mask",
  },
  auth: {
    auth_mode: "session",
    allowed_roles: ["admin"],
    trace_allowed_roles: ["admin"],
    session_cookie_name: "stronk_admin_session",
    session_secure_cookies: false,
    viewer: {
      user: "operator",
      roles: ["admin"],
    },
    trace_access: true,
  },
  access: {
    mode: "loopback",
    http_bind: "127.0.0.1",
    http_port: 8790,
    allowed_origins: ["http://localhost:4173"],
    trusted_proxy_mode: "off",
    enrollment_required: false,
  },
  gateway_artifacts: {
    artifact_dir: "/tmp/generated",
    schema_version: "gateway/v2",
    warnings: [],
  },
  warnings: ["config warning"],
  recent_access: [],
};

const providersFixture: ProviderSummary = {
  schema_version: "gateway/v2",
  artifact_dir: "/tmp/generated",
  materialization_required: false,
  last_materialized_at: "2026-04-03T17:59:00Z",
  last_doctor_generated_at: "2026-04-03T17:59:30Z",
  last_doctor_status: "ready",
  warnings: ["provider warning"],
  items: [
    {
      label: "OpenAI Production",
      readiness_posture: "ready",
      auth_source_type: "env",
      materialized_at: "2026-04-03T17:59:00Z",
    },
  ],
};

const modelsFixture: ModelSummary = {
  schema_version: "gateway/v2",
  artifact_dir: "/tmp/generated",
  materialization_required: false,
  last_materialized_at: "2026-04-03T17:59:00Z",
  recommended_models: ["stronk-lm-hot"],
  warnings: ["model warning"],
  items: [
    {
      client_model: "stronk-lm-hot",
      backend_id: "openai-production",
      endpoint_id: "chat",
      readiness_posture: "ready",
      fallback_note: null,
      recommended_for_hermes: true,
    },
  ],
};

const policyFixture: PolicySummary = {
  warnings: ["policy warning"],
  detector_readiness: {
    presidio_enabled: true,
    languages: ["en"],
    score_threshold: 0.5,
    english_model: "en_core_web_lg",
    chinese_model: "zh_core_web_lg",
  },
  fail_closed_actions: {
    email: "block",
  },
  endpoint_posture: [
    {
      client_model: "stronk-lm-hot",
      privacy_policy_id: "default",
      backend_linkage: "openai/chat",
    },
  ],
};

const accessFixture: AccessSummary = {
  mode: "loopback",
  viewer: {
    user: "operator",
    roles: ["admin"],
  },
  trace_allowed_roles: ["admin"],
  session_posture: {
    cookie_name: "stronk_admin_session",
    secure_cookies: false,
    idle_timeout_seconds: 900,
    absolute_timeout_seconds: 28800,
    csrf_same_origin_required: true,
    login_attempt_limit: 5,
    login_attempt_window_seconds: 300,
  },
  remote_access: {
    allowed_origins: ["http://localhost:4173"],
    trusted_proxy_mode: "off",
    enrollment_required: false,
  },
  enrollment: {
    approved: 1,
    pending: 0,
    revoked: 0,
    active_device: null,
    recent: [],
  },
};

const systemFixture: SystemSummary = {
  schema_version: "gateway/v2",
  artifact_dir: "/tmp/generated",
  bundle_version: "stronk-gateway-deploy.bundle/v1alpha1",
  generated_at: "2026-04-03T18:00:00Z",
  private_surface_posture: "sealed",
  check_status: "ready",
  checks: [
    {
      name: "doctor",
      status: "ready",
      message: "all checks passed",
      evidence_ref: null,
    },
  ],
  image_pins: {
    "stronk-gateway": "ghcr.io/eyycheev/stronk-gateway@sha256:123",
  },
  topology: {
    browser_admin_runtime: "stronk-gateway-admin",
    public_runtime: "stronk-gateway",
    private_backplane: "docker",
    browser_direct_cliproxyapi: false,
    supported_access_modes: ["loopback"],
    current_access_mode: "loopback",
  },
  warnings: ["system warning"],
};

const eventFixture: AuditEvent = {
  request_id: "req-123",
  created_at: "2026-04-03T18:00:00Z",
  provider: "openai",
  endpoint: "chat",
  model: "gpt-4.1",
  stream: false,
  outcome: "masked",
  status_code: 200,
  latency_ms: 150,
  detection_count: 2,
  detection_types: {
    email: 2,
  },
  actions: {
    mask: 2,
  },
  placeholder_count: 2,
  rehydration_count: 1,
  masked_paths: ["input.messages[0].content"],
  blocked: false,
  route_local: false,
};

const debugTraceFixture: DebugTrace = {
  request_id: "req-123",
  created_at: "2026-04-03T18:00:00Z",
  provider: "openai",
  endpoint: "chat",
  model: "gpt-4.1",
  stream: false,
  outcome: "masked",
  status_code: 200,
  request_original: { text: "secret" },
  request_masked: { text: "<EMAIL_1>" },
  response_upstream: { text: "ok" },
  response_rehydrated: { text: "ok" },
};

function primeAuthenticatedMocks() {
  api.fetchSession.mockResolvedValue(sessionFixture);
  api.fetchOverview.mockResolvedValue(overviewFixture);
  api.fetchConfig.mockResolvedValue(configFixture);
  api.fetchProviders.mockResolvedValue(providersFixture);
  api.fetchModels.mockResolvedValue(modelsFixture);
  api.fetchPolicy.mockResolvedValue(policyFixture);
  api.fetchAccess.mockResolvedValue(accessFixture);
  api.fetchSystem.mockResolvedValue(systemFixture);
  api.fetchEvents.mockResolvedValue({ items: [eventFixture] });
  api.fetchEvent.mockResolvedValue(eventFixture);
  api.fetchDebugTrace.mockResolvedValue(debugTraceFixture);
}

describe("App", () => {
  beforeEach(() => {
    vi.resetAllMocks();
    const storage = new Map<string, string>();
    Object.defineProperty(window, "localStorage", {
      writable: true,
      value: {
        getItem: vi.fn((key: string) => storage.get(key) ?? null),
        setItem: vi.fn((key: string, value: string) => {
          storage.set(key, value);
        }),
        removeItem: vi.fn((key: string) => {
          storage.delete(key);
        }),
        clear: vi.fn(() => {
          storage.clear();
        }),
      },
    });
    window.history.pushState({}, "", "/");
    Object.defineProperty(window, "matchMedia", {
      writable: true,
      value: vi.fn().mockImplementation((query: string) => ({
        matches: false,
        media: query,
        onchange: null,
        addListener: vi.fn(),
        removeListener: vi.fn(),
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
        dispatchEvent: vi.fn(),
      })),
    });
  });

  afterEach(() => {
    cleanup();
  });

  it("renders the login shell when the session is unresolved as unauthenticated", async () => {
    api.fetchSession.mockResolvedValue(null);

    render(<App />);

    expect(await screen.findByRole("button", { name: "Open operator console" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Stronk Gateway Admin" })).toBeInTheDocument();
    expect(api.fetchOverview).not.toHaveBeenCalled();
    expect(api.fetchConfig).not.toHaveBeenCalled();
  });

  it("renders the overview and read-only posture guidance", async () => {
    primeAuthenticatedMocks();

    render(<App />);

    expect(await screen.findByRole("heading", { name: "Overview" })).toBeInTheDocument();
    expect(await screen.findByText("https://gateway.example.com")).toBeInTheDocument();
    expect(screen.getByText("Read-only operator shell")).toBeInTheDocument();
    expect(screen.getByText(/Use the active deployment profile workflow/i)).toBeInTheDocument();
    expect(screen.queryByText("Setup wizard")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Add provider/i })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Apply staged config/i })).not.toBeInTheDocument();
    expect(screen.getByText("Request river")).toBeInTheDocument();
  });

  it("loads a direct request detail route and preserves back-navigation to the requests page", async () => {
    primeAuthenticatedMocks();
    window.history.pushState({}, "", "/requests/req-123");

    render(<App />);

    expect(await screen.findByRole("heading", { name: "Request Detail" })).toBeInTheDocument();
    expect(await screen.findByRole("heading", { name: "req-123" })).toBeInTheDocument();
    await waitFor(() => {
      expect(api.fetchEvent).toHaveBeenCalledWith("req-123");
      expect(api.fetchDebugTrace).toHaveBeenCalledWith("req-123");
    });

    fireEvent.click(screen.getByRole("button", { name: "Back to Requests" }));

    expect(await screen.findByRole("heading", { name: "Requests" })).toBeInTheDocument();
    expect(window.location.pathname).toBe("/requests");
  });

  it("keeps the global error banner outside the animated route frame", async () => {
    api.fetchSession.mockResolvedValue(sessionFixture);
    api.fetchOverview.mockRejectedValue(new Error("Failed to load control plane data."));
    api.fetchConfig.mockResolvedValue(configFixture);
    api.fetchProviders.mockResolvedValue(providersFixture);
    api.fetchModels.mockResolvedValue(modelsFixture);
    api.fetchPolicy.mockResolvedValue(policyFixture);
    api.fetchAccess.mockResolvedValue(accessFixture);
    api.fetchSystem.mockResolvedValue(systemFixture);
    api.fetchEvents.mockResolvedValue({ items: [eventFixture] });

    const { container } = render(<App />);

    expect(await screen.findByText("Failed to load control plane data.")).toBeInTheDocument();
    expect(container.querySelector(".console-workspace > .error-banner")).not.toBeNull();
    expect(container.querySelector(".route-frame .error-banner")).toBeNull();
  });

  it("redacts unsafe Hermes helper snippet values before rendering them", async () => {
    primeAuthenticatedMocks();
    api.fetchOverview.mockResolvedValue(overviewUnsafeSnippetFixture);

    render(<App />);

    const snippetCard = (await screen.findByText("Hermes")).closest(".snippet-card");
    expect(snippetCard).not.toBeNull();
    expect(snippetCard).toHaveTextContent(/<redacted>/);
    expect(snippetCard?.textContent).toContain("Authorization:");
    expect(screen.queryByText(/sk-live-secret/)).not.toBeInTheDocument();
  });
});
