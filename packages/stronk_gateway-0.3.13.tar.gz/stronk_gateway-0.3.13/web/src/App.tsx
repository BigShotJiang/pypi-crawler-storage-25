import { useEffect, useMemo, useState } from "react";

import {
  ApiError,
  fetchAccess,
  fetchConfig,
  fetchDebugTrace,
  fetchEvent,
  fetchEvents,
  fetchModels,
  fetchOverview,
  fetchPolicy,
  fetchProviders,
  fetchSession,
  fetchSystem,
  loginSession,
  logoutSession,
} from "./api";
import {
  AccessPage,
  buildRouteWarnings,
  ConsoleShell,
  ConsoleRoute,
  getRouteDescription,
  getRouteTitle,
  LoadingShell,
  LoginShell,
  ModelsPage,
  OverviewPage,
  parseRoute,
  PolicyPage,
  ProvidersPage,
  RequestsPage,
  SystemPage,
  ThemeMode,
} from "./pages";
import type {
  AccessSummary,
  AuditEvent,
  ConfigSummary,
  DebugTrace,
  ModelSummary,
  Overview,
  PolicySummary,
  ProviderSummary,
  SessionSummary,
  SystemSummary,
} from "./types";

const THEME_KEY = "stronk-gateway-theme";
const REFRESH_MS = 8000;

function isUnauthorized(error: unknown): error is ApiError {
  return error instanceof ApiError && error.status === 401;
}

export default function App() {
  const [theme, setTheme] = useState<ThemeMode>(() => {
    const stored = window.localStorage.getItem(THEME_KEY);
    if (stored === "light" || stored === "dark") {
      return stored;
    }
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  });
  const [route, setRoute] = useState<ConsoleRoute>(() => parseRoute(window.location.pathname));
  const [session, setSession] = useState<SessionSummary | null>(null);
  const [authResolved, setAuthResolved] = useState(false);
  const [loginBusy, setLoginBusy] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [overview, setOverview] = useState<Overview | null>(null);
  const [config, setConfig] = useState<ConfigSummary | null>(null);
  const [providers, setProviders] = useState<ProviderSummary | null>(null);
  const [models, setModels] = useState<ModelSummary | null>(null);
  const [policy, setPolicy] = useState<PolicySummary | null>(null);
  const [access, setAccess] = useState<AccessSummary | null>(null);
  const [system, setSystem] = useState<SystemSummary | null>(null);
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<AuditEvent | null>(null);
  const [selectedDebugTrace, setSelectedDebugTrace] = useState<DebugTrace | null>(null);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    window.localStorage.setItem(THEME_KEY, theme);
  }, [theme]);

  useEffect(() => {
    const handlePopState = () => {
      setRoute(parseRoute(window.location.pathname));
    };
    window.addEventListener("popstate", handlePopState);
    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, []);

  useEffect(() => {
    let active = true;
    void fetchSession()
      .then((payload) => {
        if (!active) {
          return;
        }
        setSession(payload);
        setAuthResolved(true);
      })
      .catch((loadError) => {
        if (!active) {
          return;
        }
        setLoginError(loadError instanceof Error ? loadError.message : "Failed to resolve the admin session.");
        setAuthResolved(true);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!session) {
      setOverview(null);
      setConfig(null);
      setProviders(null);
      setModels(null);
      setPolicy(null);
      setAccess(null);
      setSystem(null);
      setEvents([]);
      setSelectedEvent(null);
      setSelectedDebugTrace(null);
      setError(null);
      return;
    }

    let active = true;

    async function load() {
      try {
        const [
          overviewPayload,
          configPayload,
          providersPayload,
          modelsPayload,
          policyPayload,
          accessPayload,
          systemPayload,
          eventsPayload,
        ] = await Promise.all([
          fetchOverview(),
          fetchConfig(),
          fetchProviders(),
          fetchModels(),
          fetchPolicy(),
          fetchAccess(),
          fetchSystem(),
          fetchEvents(),
        ]);
        if (!active) {
          return;
        }
        setOverview(overviewPayload);
        setConfig(configPayload);
        setProviders(providersPayload);
        setModels(modelsPayload);
        setPolicy(policyPayload);
        setAccess(accessPayload);
        setSystem(systemPayload);
        setEvents(eventsPayload.items);
        setError(null);
      } catch (loadError) {
        if (!active) {
          return;
        }
        if (isUnauthorized(loadError)) {
          setSession(null);
          setLoginError("Your admin session expired. Sign in again to continue.");
          return;
        }
        setError(loadError instanceof Error ? loadError.message : "Failed to load control plane data.");
      }
    }

    void load();
    const timer = window.setInterval(() => {
      void load();
    }, REFRESH_MS);
    return () => {
      active = false;
      window.clearInterval(timer);
    };
  }, [session]);

  useEffect(() => {
    if (!session || route.key !== "requestDetail") {
      setSelectedEvent(null);
      setSelectedDebugTrace(null);
      setError(null);
      return;
    }

    let active = true;
    const contentTraceEnabled = config?.control_plane.content_trace_enabled ?? session.content_trace_enabled;
    const traceAccess = config?.auth.trace_access ?? session.trace_access;
    setSelectedEvent(null);
    setSelectedDebugTrace(null);
    setError(null);

    void Promise.all([
      fetchEvent(route.requestId),
      contentTraceEnabled && traceAccess ? fetchDebugTrace(route.requestId) : Promise.resolve(null),
    ])
      .then(([eventPayload, debugTracePayload]) => {
        if (!active) {
          return;
        }
        setSelectedEvent(eventPayload);
        setSelectedDebugTrace(debugTracePayload);
        setError(null);
      })
      .catch((loadError) => {
        if (!active) {
          return;
        }
        if (isUnauthorized(loadError)) {
          setSession(null);
          setLoginError("Your admin session expired. Sign in again to continue.");
          return;
        }
        setSelectedEvent(null);
        setSelectedDebugTrace(null);
        setError(loadError instanceof Error ? loadError.message : "Failed to load selected request.");
      });

    return () => {
      active = false;
    };
  }, [config?.auth.trace_access, config?.control_plane.content_trace_enabled, route, session]);

  const viewer = config?.auth.viewer ?? session?.viewer ?? null;
  const traceAccess = config?.auth.trace_access ?? session?.trace_access ?? false;
  const contentTraceEnabled =
    config?.control_plane.content_trace_enabled ?? session?.content_trace_enabled ?? false;
  const currentTitle = getRouteTitle(route);
  const currentDescription = getRouteDescription(route);
  const routeWarnings = buildRouteWarnings(route, overview, config, providers, models, policy, system);
  const recentRequests = useMemo(() => events.slice(0, 6), [events]);

  async function handleLogin(username: string, password: string) {
    setLoginBusy(true);
    setLoginError(null);
    try {
      const nextSession = await loginSession(username, password);
      setSession(nextSession);
    } catch (loginFailure) {
      if (loginFailure instanceof ApiError && loginFailure.status === 401) {
        setLoginError("Invalid username or password.");
        return;
      }
      setLoginError(loginFailure instanceof Error ? loginFailure.message : "Failed to sign in.");
    } finally {
      setLoginBusy(false);
    }
  }

  async function handleLogout() {
    try {
      await logoutSession();
    } finally {
      setSession(null);
      setLoginError(null);
    }
  }

  function navigateTo(path: string) {
    if (window.location.pathname === path) {
      return;
    }
    window.history.pushState({}, "", path);
    setRoute(parseRoute(path));
  }

  if (!authResolved) {
    return <LoadingShell theme={theme} onToggleTheme={() => setTheme(theme === "dark" ? "light" : "dark")} />;
  }

  if (!session) {
    return (
      <LoginShell
        theme={theme}
        loginBusy={loginBusy}
        error={loginError}
        onSubmit={handleLogin}
        onToggleTheme={() => setTheme(theme === "dark" ? "light" : "dark")}
      />
    );
  }

  return (
    <ConsoleShell
      theme={theme}
      route={route}
      viewerUser={viewer?.user ?? "operator"}
      viewerRoles={viewer?.roles ?? ["admin"]}
      traceAccess={traceAccess}
      session={session}
      overview={overview}
      currentTitle={currentTitle}
      currentDescription={currentDescription}
      error={error}
      routeWarnings={routeWarnings}
      onToggleTheme={() => setTheme(theme === "dark" ? "light" : "dark")}
      onLogout={handleLogout}
      onNavigate={navigateTo}
    >
      {route.key === "overview" ? (
        <OverviewPage
          overview={overview}
          config={config}
          recentRequests={recentRequests}
          onOpenRequest={(requestId) => navigateTo(`/requests/${encodeURIComponent(requestId)}`)}
          onOpenProviders={() => navigateTo("/providers")}
          onOpenModels={() => navigateTo("/models")}
        />
      ) : null}

      {route.key === "requests" || route.key === "requestDetail" ? (
        <RequestsPage
          route={route}
          events={events}
          selectedEvent={selectedEvent}
          selectedDebugTrace={selectedDebugTrace}
          traceAccess={traceAccess}
          contentTraceEnabled={contentTraceEnabled}
          onOpenRequest={(requestId) => navigateTo(`/requests/${encodeURIComponent(requestId)}`)}
          onBackToRequests={() => navigateTo("/requests")}
        />
      ) : null}

      {route.key === "providers" ? <ProvidersPage summary={providers} /> : null}
      {route.key === "models" ? <ModelsPage summary={models} onOpenProviders={() => navigateTo("/providers")} /> : null}
      {route.key === "policy" ? <PolicyPage policy={policy} /> : null}
      {route.key === "access" ? <AccessPage access={access} /> : null}
      {route.key === "system" ? <SystemPage system={system} config={config} /> : null}
    </ConsoleShell>
  );
}
