import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";

import { ProvidersPage } from "./ProvidersPage";
import type { ProviderSummary } from "../types";

const runtimeSummaryFixture: ProviderSummary = {
  schema_version: "gateway/v2",
  artifact_dir: "/tmp/generated",
  materialization_required: false,
  last_materialized_at: "2026-04-03T17:59:00Z",
  last_doctor_generated_at: "2026-04-03T17:59:30Z",
  last_doctor_status: "ready",
  warnings: [],
  items: [
    {
      label: "OpenAI Production",
      readiness_posture: "ready",
      auth_source_type: "env",
      materialized_at: "2026-04-03T17:59:00Z",
    },
  ],
};

describe("ProvidersPage", () => {
  afterEach(() => {
    cleanup();
  });

  it("renders a read-only provider posture snapshot", () => {
    render(<ProvidersPage summary={runtimeSummaryFixture} />);

    expect(screen.getByText("Runtime provider posture")).toBeInTheDocument();
    expect(screen.getByText("Read-only provider snapshot")).toBeInTheDocument();
    expect(screen.getByText("OpenAI Production")).toBeInTheDocument();
    expect(screen.getByText("runtime ready")).toBeInTheDocument();
    expect(screen.getByText("env")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Add provider/i })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Verify/i })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Apply staged config/i })).not.toBeInTheDocument();
  });

  it("shows a degraded state when no providers are materialized", () => {
    render(
      <ProvidersPage
        summary={{
          ...runtimeSummaryFixture,
          materialization_required: true,
          items: [],
          last_materialized_at: null,
        }}
      />,
    );

    expect(screen.getByText("No materialized providers")).toBeInTheDocument();
    expect(screen.getByText(/Materialize the active deployment profile/i)).toBeInTheDocument();
  });
});
