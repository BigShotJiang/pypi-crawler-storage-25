import type { ModelSummary } from "../types";
import { DegradedStatePanel } from "./DegradedStatePanel";
import { KeyValueGrid, MetricCard, SectionCard, StatusBadge, toneForStatus } from "./shared";

function countReadyModels(items: ModelSummary["items"]): number {
  return items.filter((item) => toneForStatus(item.readiness_posture) === "accent").length;
}

export function ModelsPage({
  summary,
  onOpenProviders,
}: {
  summary: ModelSummary | null;
  onOpenProviders: () => void;
}) {
  const items = summary?.items ?? [];
  const readyCount = countReadyModels(items);

  return (
    <div className="route-grid route-grid-config">
      <SectionCard eyebrow="Models" title="Runtime model posture" actionLabel="Providers" onAction={onOpenProviders}>
        <div className="metric-grid">
          <MetricCard value={`${readyCount}/${items.length}`} label="Models ready" tone="accent" />
          <MetricCard
            value={summary?.recommended_models.join(", ") || "Pending"}
            label="Hermes suggestions"
            tone="warning"
          />
          <MetricCard
            value={summary?.materialization_required ? "required" : "current"}
            label="Materialization state"
            tone={summary?.materialization_required ? "warning" : "neutral"}
          />
        </div>
        <div className="callout">
          <strong>Read-only model mapping snapshot</strong>
          <p>
            Client model values and backend linkage are managed in the active deployment profile
            workflow. Use this page to confirm what the current runtime exposes to Hermes and other
            clients.
          </p>
        </div>
        <KeyValueGrid
          rows={[
            ["Artifact schema", summary?.schema_version ?? "Unavailable"],
            ["Artifact mount", summary?.artifact_dir ?? "Not configured"],
            ["Last materialized", summary?.last_materialized_at ?? "Materialization required"],
            ["Recommended models", summary?.recommended_models.join(", ") || "Pending"],
          ]}
        />
      </SectionCard>

      <SectionCard eyebrow="Snapshot" title="Client model values">
        {items.length ? (
          <div className="card-grid">
            {items.map((item) => (
              <article key={`${item.client_model}-${item.backend_id}`} className="posture-card">
                <div className="posture-card-head">
                  <strong>{item.client_model}</strong>
                  <StatusBadge
                    label={item.readiness_posture}
                    tone={toneForStatus(item.readiness_posture)}
                  />
                </div>
                <div className="provider-card-body">
                  <div className="keyvalue-row">
                    <span>Backend</span>
                    <strong>{item.backend_id}</strong>
                  </div>
                  <div className="keyvalue-row">
                    <span>Endpoint</span>
                    <strong>{item.endpoint_id}</strong>
                  </div>
                  <div className="keyvalue-row">
                    <span>Hermes</span>
                    <strong>{item.recommended_for_hermes ? "recommended" : "not recommended"}</strong>
                  </div>
                  {item.fallback_note ? (
                    <div className="keyvalue-row">
                      <span>Fallback</span>
                      <strong>{item.fallback_note}</strong>
                    </div>
                  ) : null}
                </div>
              </article>
            ))}
          </div>
        ) : (
          <DegradedStatePanel
            title="No materialized models"
            body="No client model values are present in the current runtime snapshot. Materialize the active deployment profile, then refresh this shell."
          />
        )}
      </SectionCard>
    </div>
  );
}
