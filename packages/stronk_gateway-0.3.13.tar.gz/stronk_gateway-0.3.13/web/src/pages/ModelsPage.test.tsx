import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { ModelsPage } from "./ModelsPage";
import type { ModelSummary } from "../types";

const runtimeSummaryFixture: ModelSummary = {
  schema_version: "gateway/v2",
  artifact_dir: "/tmp/generated",
  materialization_required: false,
  last_materialized_at: "2026-04-03T17:59:00Z",
  recommended_models: ["stronk-lm-hot"],
  warnings: [],
  items: [
    {
      client_model: "stronk-lm-hot",
      backend_id: "openai-production",
      endpoint_id: "chat",
      readiness_posture: "ready",
      fallback_note: null,
      recommended_for_hermes: true,
    },
  ],
};

describe("ModelsPage", () => {
  afterEach(() => {
    cleanup();
  });

  it("renders a read-only model posture snapshot", () => {
    const onOpenProviders = vi.fn();

    render(<ModelsPage summary={runtimeSummaryFixture} onOpenProviders={onOpenProviders} />);

    expect(screen.getByRole("heading", { name: "Runtime model posture" })).toBeInTheDocument();
    expect(screen.getByText("Read-only model mapping snapshot")).toBeInTheDocument();
    expect(screen.getAllByText("stronk-lm-hot").length).toBeGreaterThan(0);
    expect(screen.getByText("openai-production")).toBeInTheDocument();
    expect(screen.getByText("recommended")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Discover models/i })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Save model draft/i })).not.toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Providers" }));
    expect(onOpenProviders).toHaveBeenCalled();
  });

  it("shows a degraded state when no models are materialized", () => {
    render(
      <ModelsPage
        summary={{
          ...runtimeSummaryFixture,
          materialization_required: true,
          recommended_models: [],
          items: [],
          last_materialized_at: null,
        }}
        onOpenProviders={vi.fn()}
      />,
    );

    expect(screen.getByText("No materialized models")).toBeInTheDocument();
    expect(screen.getByText(/Materialize the active deployment profile/i)).toBeInTheDocument();
  });
});
