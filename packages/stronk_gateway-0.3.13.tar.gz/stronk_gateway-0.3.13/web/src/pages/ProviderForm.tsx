export function ProviderForm() {
  return (
    <div className="form-stack">
      <div className="callout">
        <strong>Provider edits moved out of the browser</strong>
        <p>
          This admin UI stays read-only. Use the active deployment profile workflow to add, replace, or
          remove providers, then return here to inspect the materialized runtime.
        </p>
      </div>
    </div>
  );
}
