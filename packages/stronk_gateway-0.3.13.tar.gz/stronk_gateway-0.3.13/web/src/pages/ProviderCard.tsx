import type { ProviderSummary } from "../types";
import { formatTimestamp, StatusBadge, toneForStatus } from "./shared";

export function ProviderCard({
  provider,
}: {
  provider: ProviderSummary["items"][number];
}) {
  return (
    <article className="posture-card provider-card">
      <div className="posture-card-head">
        <strong>{provider.label}</strong>
        <StatusBadge
          label={`runtime ${provider.readiness_posture}`}
          tone={toneForStatus(provider.readiness_posture)}
        />
      </div>
      <div className="provider-card-body">
        <div className="keyvalue-row">
          <span>Auth source</span>
          <strong>{provider.auth_source_type}</strong>
        </div>
        <div className="keyvalue-row">
          <span>Last materialization</span>
          <strong>{provider.materialized_at ? formatTimestamp(provider.materialized_at) : "Pending"}</strong>
        </div>
      </div>
    </article>
  );
}
