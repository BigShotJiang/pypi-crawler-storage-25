import type { ProviderSummary } from "../types";
import { DegradedStatePanel } from "./DegradedStatePanel";
import { ProviderCard } from "./ProviderCard";
import { KeyValueGrid, MetricCard, SectionCard, toneForStatus } from "./shared";

function countReadyProviders(items: ProviderSummary["items"]): number {
  return items.filter((item) => toneForStatus(item.readiness_posture) === "accent").length;
}

export function ProvidersPage({
  summary,
}: {
  summary: ProviderSummary | null;
}) {
  const items = summary?.items ?? [];
  const readyCount = countReadyProviders(items);

  return (
    <div className="route-grid route-grid-config">
      <SectionCard eyebrow="Providers" title="Runtime provider posture">
        <div className="metric-grid">
          <MetricCard value={`${readyCount}/${items.length}`} label="Providers ready" tone="accent" />
          <MetricCard
            value={summary?.materialization_required ? "required" : "current"}
            label="Materialization state"
            tone={summary?.materialization_required ? "warning" : "neutral"}
          />
          <MetricCard value={summary?.last_doctor_status ?? "unknown"} label="Doctor status" tone="warning" />
        </div>
        <div className="callout">
          <strong>Read-only provider snapshot</strong>
          <p>
            Provider changes are no longer handled in-browser. Manage providers in the active
            deployment profile workflow, then use this page to confirm runtime readiness and
            materialization timestamps.
          </p>
        </div>
        <KeyValueGrid
          rows={[
            ["Artifact schema", summary?.schema_version ?? "Unavailable"],
            ["Artifact mount", summary?.artifact_dir ?? "Not configured"],
            ["Last materialized", summary?.last_materialized_at ?? "Materialization required"],
            ["Last doctor report", summary?.last_doctor_generated_at ?? "Pending"],
          ]}
        />
      </SectionCard>

      <SectionCard eyebrow="Snapshot" title="Materialized providers">
        {items.length ? (
          <div className="card-grid">
            {items.map((provider) => (
              <ProviderCard key={provider.label} provider={provider} />
            ))}
          </div>
        ) : (
          <DegradedStatePanel
            title="No materialized providers"
            body="No providers are present in the current runtime snapshot. Materialize the active deployment profile, then refresh this shell."
          />
        )}
      </SectionCard>
    </div>
  );
}
