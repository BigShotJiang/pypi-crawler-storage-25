import type { AuditEvent, ConfigSummary, Overview } from "../types";
import {
  EmptyPanel,
  formatTimestamp,
  KeyValueGrid,
  MetricCard,
  SectionCard,
  SnippetBlock,
  StatusBadge,
  toneForOutcome,
  toneForStatus,
} from "./shared";

export function OverviewPage({
  overview,
  config,
  recentRequests,
  onOpenRequest,
  onOpenProviders,
  onOpenModels,
}: {
  overview: Overview | null;
  config: ConfigSummary | null;
  recentRequests: AuditEvent[];
  onOpenRequest: (requestId: string) => void;
  onOpenProviders: () => void;
  onOpenModels: () => void;
}) {
  return (
    <div className="route-grid route-grid-overview">
      <SectionCard
        eyebrow="Hermes connect"
        title="Public endpoint and model handoff"
        aside={<StatusBadge label={overview?.gateway.hermes.credential_flow ?? "cli_only"} tone="warning" />}
      >
        <div className="hero-stack">
          <MetricCard
            value={overview?.gateway.hermes.public_base_url ?? "Not materialized"}
            label="Public base URL"
            tone="neutral"
          />
          <MetricCard
            value={overview?.gateway.model_summary.recommended_models.join(", ") || "Pending"}
            label="Suggested model values"
            tone="accent"
          />
          <div className="callout">
            <strong>Credential flow: CLI only</strong>
            <p>
              The browser never carries the Hermes key value. Use the surfaced base URL and set the
              staged public API key outside the browser when configuring Hermes or other clients.
            </p>
          </div>
          {overview?.gateway.hermes.copy_snippets.length ? (
            <div className="snippet-grid">
              {overview.gateway.hermes.copy_snippets.map((snippet, index) => (
                <SnippetBlock
                  key={`${snippet.label ?? "snippet"}-${index}`}
                  label={snippet.label ?? `Snippet ${index + 1}`}
                  snippet={snippet.snippet ?? ""}
                />
              ))}
            </div>
          ) : (
            <EmptyPanel
              title="Hermes snippet metadata pending"
              body="Materialize the bundle to refresh the Hermes metadata and placeholder client-model snippets."
              compact
            />
          )}
        </div>
      </SectionCard>

      <SectionCard eyebrow="Profile workflow" title="Read-only operator shell" actionLabel="View providers" onAction={onOpenProviders}>
        <div className="callout">
          <strong>Provider and model ownership moved out of the browser</strong>
          <p>
            This admin UI stays read-only. Use the active deployment profile workflow to add, replace,
            or materialize providers and models, then return here to confirm runtime posture, Hermes
            handoff values, and request behavior.
          </p>
        </div>
        <KeyValueGrid
          rows={[
            ["Ownership posture", "Read-only in browser"],
            ["Operator workflow", "Active deployment profile"],
            [
              "Last materialization",
              overview?.gateway.provider_summary.last_materialized_at
                ? formatTimestamp(overview.gateway.provider_summary.last_materialized_at)
                : "Materialization required",
            ],
            ["Doctor status", overview?.gateway.doctor.status ?? "unknown"],
          ]}
        />
        <div className="wizard-actions">
          <button className="inline-button" type="button" onClick={onOpenProviders}>
            Review providers
          </button>
          <button className="inline-button" type="button" onClick={onOpenModels}>
            Review models
          </button>
        </div>
      </SectionCard>

      <SectionCard eyebrow="Bundle posture" title="Gateway-backed readiness" actionLabel="Providers" onAction={onOpenProviders}>
        <div className="metric-grid">
          <MetricCard
            value={`${overview?.gateway.provider_summary.ready ?? 0}/${overview?.gateway.provider_summary.total ?? 0}`}
            label="Providers ready"
            tone="accent"
          />
          <MetricCard
            value={`${overview?.gateway.model_summary.ready ?? 0}/${overview?.gateway.model_summary.total ?? 0}`}
            label="Models ready"
            tone="warning"
          />
          <MetricCard
            value={overview?.gateway.doctor.status ?? "unknown"}
            label="Doctor status"
            tone={toneForStatus(overview?.gateway.doctor.status ?? "unknown")}
          />
          <MetricCard
            value={overview?.gateway.doctor.private_surface_posture ?? "unknown"}
            label="Private surface posture"
            tone="neutral"
          />
        </div>
        <KeyValueGrid
          rows={[
            ["Bundle version", overview?.gateway.doctor.bundle_version ?? "Unavailable"],
            [
              "Last materialization",
              overview?.gateway.provider_summary.last_materialized_at
                ? formatTimestamp(overview.gateway.provider_summary.last_materialized_at)
                : "Materialization required",
            ],
            ["Artifact schema", overview?.gateway.schema_version ?? "Unavailable"],
            ["Artifact mount", overview?.gateway.artifact_dir ?? "Not configured"],
          ]}
        />
      </SectionCard>

      <SectionCard eyebrow="Recent activity" title="Request river" actionLabel="Models" onAction={onOpenModels}>
        {recentRequests.length ? (
          <div className="request-list compact-list">
            {recentRequests.map((event) => (
              <button
                key={event.request_id}
                type="button"
                className="request-row"
                onClick={() => onOpenRequest(event.request_id)}
              >
                <div className="request-row-heading">
                  <StatusBadge label={event.outcome} tone={toneForOutcome(event.outcome)} />
                  <span>{event.provider}</span>
                  <span>{event.stream ? "stream" : "json"}</span>
                </div>
                <strong>{event.model ?? "model pending"}</strong>
                <span>{formatTimestamp(event.created_at)}</span>
              </button>
            ))}
          </div>
        ) : (
          <EmptyPanel
            title="No traffic yet"
            body="Request monitoring stays available even when gateway bundle updates are handled outside the browser."
          />
        )}
      </SectionCard>

      <SectionCard eyebrow="Policy" title="Current edge posture">
        <KeyValueGrid
          rows={[
            ["Content trace capture", config?.control_plane.content_trace_enabled ? "enabled" : "disabled"],
            ["Trace TTL", `${config?.control_plane.content_trace_ttl_seconds ?? 0}s`],
            ["Admin access mode", config?.access.mode ?? "loopback"],
            ["Session auth", config?.auth.auth_mode ?? "session"],
          ]}
        />
      </SectionCard>
    </div>
  );
}
