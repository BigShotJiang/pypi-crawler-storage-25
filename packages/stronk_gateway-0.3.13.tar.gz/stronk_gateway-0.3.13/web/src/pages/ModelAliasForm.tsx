export function ModelAliasForm() {
  return (
    <div className="form-stack alias-form">
      <div className="callout">
        <strong>Model edits moved out of the browser</strong>
        <p>
          Client model values are managed in the active deployment profile workflow. This shell only
          reports the materialized runtime posture after that workflow completes.
        </p>
      </div>
    </div>
  );
}
