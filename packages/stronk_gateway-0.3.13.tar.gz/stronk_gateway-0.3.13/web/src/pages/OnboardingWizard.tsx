import { SectionCard } from "./shared";

export function OnboardingWizard() {
  return (
    <SectionCard eyebrow="Profile workflow" title="Browser onboarding removed">
      <div className="callout">
        <strong>The admin shell no longer provisions providers or models</strong>
        <p>
          First-time setup now happens in the active deployment profile workflow. Return to the
          browser after materialization to review provider posture, client model values, and Hermes
          handoff metadata.
        </p>
      </div>
    </SectionCard>
  );
}
