import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";

import { ProviderForm } from "./ProviderForm";

describe("ProviderForm", () => {
  afterEach(() => {
    cleanup();
  });

  it("renders provider ownership guidance without editable controls", () => {
    render(<ProviderForm />);

    expect(screen.getByText("Provider edits moved out of the browser")).toBeInTheDocument();
    expect(screen.getByText(/active deployment profile/i)).toBeInTheDocument();
    expect(screen.queryByRole("textbox")).not.toBeInTheDocument();
    expect(screen.queryByRole("button")).not.toBeInTheDocument();
  });
});
