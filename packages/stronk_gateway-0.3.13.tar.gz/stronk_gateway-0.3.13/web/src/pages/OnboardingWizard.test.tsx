import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";

import { OnboardingWizard } from "./OnboardingWizard";

describe("OnboardingWizard", () => {
  afterEach(() => {
    cleanup();
  });

  it("renders a phase 6 read-only notice instead of setup controls", () => {
    render(<OnboardingWizard />);

    expect(screen.getByText("Browser onboarding removed")).toBeInTheDocument();
    expect(screen.getByText(/active deployment profile/i)).toBeInTheDocument();
    expect(screen.queryByRole("button")).not.toBeInTheDocument();
    expect(screen.queryByLabelText("Label")).not.toBeInTheDocument();
    expect(screen.queryByLabelText("Client model value")).not.toBeInTheDocument();
  });
});
