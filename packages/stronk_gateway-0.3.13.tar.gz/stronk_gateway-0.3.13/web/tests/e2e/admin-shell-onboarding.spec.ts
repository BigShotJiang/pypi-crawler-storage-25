import { expect, test } from "@playwright/test";

import type {
  AccessSummary,
  ConfigSummary,
  ModelSummary,
  Overview,
  PolicySummary,
  ProviderSummary,
  SessionSummary,
  SystemSummary,
} from "../../src/types";

const SESSION_USERNAME = "operator";
const LIVE_TIME = "2026-04-03T18:10:00Z";

function buildSession(): SessionSummary {
  return {
    viewer: {
      user: SESSION_USERNAME,
      roles: ["admin"],
    },
    auth_mode: "session",
    access_mode: "loopback",
    trace_access: true,
    trace_allowed_roles: ["admin"],
    content_trace_enabled: true,
    device_id: null,
    trusted_proxy_login: null,
    session_secure_cookies: false,
  };
}

function buildConfig(): ConfigSummary {
  return {
    app_name: "Stronk Gateway",
    app_env: "e2e",
    proxy_surfaces: ["admin-ui", "hermes"],
    control_plane: {
      admin_api_enabled: true,
      admin_ui_enabled: true,
      audit_storage_enabled: true,
      ui_built: true,
      content_trace_enabled: true,
      content_trace_ttl_seconds: 300,
    },
    upstreams: {
      openai_host: "https://api.openai.com",
      anthropic_host: "https://api.anthropic.com",
      allow_insecure_upstreams: false,
      allow_nonstandard_upstream_hosts: false,
    },
    policy_actions: {
      redact: "Redact content in-place",
      block: "Block the request",
    },
    auth: {
      auth_mode: "session",
      allowed_roles: ["admin"],
      trace_allowed_roles: ["admin"],
      session_cookie_name: "stronk_admin_session",
      session_secure_cookies: false,
      viewer: {
        user: SESSION_USERNAME,
        roles: ["admin"],
      },
      trace_access: true,
    },
    access: {
      mode: "loopback",
      http_bind: "127.0.0.1",
      http_port: 8080,
      allowed_origins: ["http://127.0.0.1:8788"],
      trusted_proxy_mode: "disabled",
      enrollment_required: false,
    },
    gateway_artifacts: {
      artifact_dir: "/var/lib/stronk-gateway",
      schema_version: "2026-04-03",
      warnings: [],
    },
    warnings: [],
    recent_access: [],
  };
}

function buildProviderSummary(): ProviderSummary {
  return {
    schema_version: "2026-04-03",
    artifact_dir: "/var/lib/stronk-gateway",
    materialization_required: false,
    last_materialized_at: LIVE_TIME,
    last_doctor_generated_at: LIVE_TIME,
    last_doctor_status: "ready",
    warnings: [],
    items: [
      {
        label: "OpenAI Production",
        readiness_posture: "ready",
        auth_source_type: "env",
        materialized_at: LIVE_TIME,
      },
    ],
  };
}

function buildModelSummary(): ModelSummary {
  return {
    schema_version: "2026-04-03",
    artifact_dir: "/var/lib/stronk-gateway",
    materialization_required: false,
    last_materialized_at: LIVE_TIME,
    recommended_models: ["stronk-lm-hot"],
    warnings: [],
    items: [
      {
        client_model: "stronk-lm-hot",
        backend_id: "openai-production",
        endpoint_id: "chat",
        readiness_posture: "ready",
        fallback_note: null,
        recommended_for_hermes: true,
      },
    ],
  };
}

function buildOverview(): Overview {
  return {
    total_requests: 0,
    masked_requests: 0,
    blocked_requests: 0,
    route_local_requests: 0,
    rehydrated_responses: 0,
    error_requests: 0,
    provider_counts: {},
    detector_counts: {},
    action_counts: {},
    last_event_at: null,
    gateway: {
      schema_version: "2026-04-03",
      artifact_dir: "/var/lib/stronk-gateway",
      warnings: [],
      provider_summary: {
        ready: 1,
        total: 1,
        last_materialized_at: LIVE_TIME,
      },
      model_summary: {
        ready: 1,
        total: 1,
        recommended_models: ["stronk-lm-hot"],
      },
      doctor: {
        status: "healthy",
        private_surface_posture: "sealed",
        bundle_version: "e2e-bundle-1",
      },
      hermes: {
        public_base_url: "https://gateway.example.com",
        recommended_models: ["stronk-lm-hot"],
        credential_flow: "cli_only",
        copy_snippets: [],
      },
    },
  };
}

function buildPolicy(): PolicySummary {
  return {
    warnings: [],
    detector_readiness: {
      presidio_enabled: true,
      languages: ["en"],
      score_threshold: 0.85,
      english_model: "en_core_web_sm",
      chinese_model: "zh_core_web_sm",
    },
    fail_closed_actions: {
      redact: "Redact content in-place",
      block: "Block the request",
    },
    endpoint_posture: [],
  };
}

function buildAccess(): AccessSummary {
  return {
    mode: "loopback",
    viewer: {
      user: SESSION_USERNAME,
      roles: ["admin"],
    },
    trace_allowed_roles: ["admin"],
    session_posture: {
      cookie_name: "stronk_admin_session",
      secure_cookies: false,
      idle_timeout_seconds: 1800,
      absolute_timeout_seconds: 7200,
      csrf_same_origin_required: true,
      login_attempt_limit: 5,
      login_attempt_window_seconds: 300,
    },
    remote_access: {
      allowed_origins: ["http://127.0.0.1:8788"],
      trusted_proxy_mode: "disabled",
      enrollment_required: false,
    },
    enrollment: {
      approved: 1,
      pending: 0,
      revoked: 0,
      active_device: null,
      recent: [],
    },
  };
}

function buildSystem(): SystemSummary {
  return {
    schema_version: "2026-04-03",
    artifact_dir: "/var/lib/stronk-gateway",
    bundle_version: "bundle-1",
    generated_at: LIVE_TIME,
    private_surface_posture: "sealed",
    check_status: "ready",
    checks: [
      {
        name: "doctor",
        status: "ready",
        message: "all checks passed",
        evidence_ref: null,
      },
    ],
    image_pins: {},
    topology: {
      browser_admin_runtime: "admin",
      public_runtime: "public",
      private_backplane: "docker",
      browser_direct_cliproxyapi: false,
      supported_access_modes: ["loopback"],
      current_access_mode: "loopback",
    },
    warnings: [],
  };
}

test("renders the phase 6 admin shell as read-only and avoids ownership endpoints", async ({ page }) => {
  const requests: Array<{ method: string; path: string }> = [];

  await page.route("**/api/**", async (route) => {
    const request = route.request();
    const url = new URL(request.url());
    requests.push({ method: request.method(), path: url.pathname });

    const fulfill = async (status: number, body: unknown) =>
      route.fulfill({
        status,
        contentType: "application/json",
        body: JSON.stringify(body),
      });

    if (url.pathname === "/api/session") {
      await fulfill(200, buildSession());
      return;
    }
    if (url.pathname === "/api/overview") {
      await fulfill(200, buildOverview());
      return;
    }
    if (url.pathname === "/api/config") {
      await fulfill(200, buildConfig());
      return;
    }
    if (url.pathname === "/api/providers") {
      await fulfill(200, buildProviderSummary());
      return;
    }
    if (url.pathname === "/api/models") {
      await fulfill(200, buildModelSummary());
      return;
    }
    if (url.pathname === "/api/policy") {
      await fulfill(200, buildPolicy());
      return;
    }
    if (url.pathname === "/api/access") {
      await fulfill(200, buildAccess());
      return;
    }
    if (url.pathname === "/api/system") {
      await fulfill(200, buildSystem());
      return;
    }
    if (url.pathname === "/api/events") {
      await fulfill(200, { items: [] });
      return;
    }

    throw new Error(`Unexpected API request: ${request.method()} ${url.pathname}`);
  });

  await page.goto("/", { waitUntil: "domcontentloaded" });

  await expect(page.getByText("Read-only operator shell")).toBeVisible();
  await expect(page.getByText(/Use the active deployment profile workflow/i)).toBeVisible();
  await expect(page.getByText("https://gateway.example.com")).toBeVisible();
  await expect(page.getByText("Setup wizard")).toHaveCount(0);
  await expect(page.getByRole("button", { name: /Add provider/i })).toHaveCount(0);
  await expect(page.getByRole("button", { name: /Apply staged config/i })).toHaveCount(0);

  const primaryNav = page.getByRole("navigation", { name: "Primary" });

  await primaryNav.getByRole("button", { name: /^Providers/ }).click();
  await expect(page.getByText("Runtime provider posture")).toBeVisible();
  await expect(page.getByText("OpenAI Production")).toBeVisible();
  await expect(page.getByRole("button", { name: /Verify/i })).toHaveCount(0);

  await primaryNav.getByRole("button", { name: /^Models/ }).click();
  await expect(page.getByText("Runtime model posture")).toBeVisible();
  await expect(page.getByText("stronk-lm-hot").first()).toBeVisible();
  await expect(page.getByRole("button", { name: /Save model draft/i })).toHaveCount(0);

  const forbiddenPatterns = [
    /^\/api\/operator-state$/,
    /^\/api\/apply(?:\/|$)/,
    /^\/api\/providers\/[^/]+\/(?:discover|test)(?:$|\/)/,
  ];
  expect(
    requests.filter((request) => forbiddenPatterns.some((pattern) => pattern.test(request.path))),
  ).toEqual([]);
  expect(requests.every((request) => request.method === "GET")).toBe(true);
});
