import { expect, test } from "@playwright/test";

import {
  loginViaApi,
  readLivePassword,
} from "./live-bundle-helpers";

const baseURL = process.env.BASE_URL ?? "http://127.0.0.1:8788";

test.describe("@live overview posture shell", () => {
  test.skip(!process.env.LIVE_ADMIN_PASSWORD_FILE, "LIVE_ADMIN_PASSWORD_FILE is required for live bundle e2e");

  test("shows read-only phase 6 guidance on the overview route", async ({ browser }) => {
    const adminPassword = readLivePassword();
    const apiUrls: string[] = [];

    const context = await browser.newContext({ baseURL });
    await loginViaApi(context, baseURL, adminPassword);

    const page = await context.newPage();
    page.on("request", (request) => {
      if (request.url().includes("/api/") && !request.url().includes("/api/session/login")) {
        apiUrls.push(request.url());
      }
    });

    await page.goto(baseURL, { waitUntil: "domcontentloaded" });
    await expect(page.getByText("Read-only operator shell")).toBeVisible();
    await expect(page.getByText(/Use the active deployment profile workflow/i)).toBeVisible();
    await expect(page.getByText("Setup wizard")).toHaveCount(0);
    await expect(page.getByRole("button", { name: /Add provider/i })).toHaveCount(0);
    await expect(page.getByRole("button", { name: /Apply staged config/i })).toHaveCount(0);
    await expect(page.getByLabel("Label")).toHaveCount(0);
    await expect(page.getByLabel("Client model value")).toHaveCount(0);

    const forbiddenPatterns = [
      /\/api\/operator-state$/,
      /\/api\/apply(?:\/|$)/,
      /\/api\/providers\/[^/]+\/(?:discover|test)(?:$|\/)/,
    ];
    expect(apiUrls.filter((url) => forbiddenPatterns.some((pattern) => pattern.test(url)))).toEqual([]);

    await context.close();
  });
});
