"""stronk-gateway package."""

__all__ = ["__version__"]

__version__ = "0.3.13"
