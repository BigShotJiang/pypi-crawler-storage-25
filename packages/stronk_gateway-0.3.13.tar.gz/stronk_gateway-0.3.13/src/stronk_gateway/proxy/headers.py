from __future__ import annotations

import re
from dataclasses import dataclass
from collections.abc import Mapping, Set
from urllib.parse import urlparse

from stronk_gateway.config import STANDARD_PROVIDER_HOSTS, Settings
from stronk_gateway.providers import ProviderSpec

HOP_BY_HOP_HEADERS = {
    "connection",
    "content-length",
    "host",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade",
}
OPAQUE_REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
CALLER_AUTH_HEADERS = frozenset({"authorization", "x-api-key"})
GATEWAY_ONLY_RUNTIME_PROFILE = "gateway-only"
BACKPLANE_RUNTIME_PROFILE = "gateway+CLIProxyAPI"
GATEWAY_PUBLIC_AUTH_INVALID = "gateway_public_auth_invalid"
GATEWAY_OPENAI_UPSTREAM_UNCONFIGURED = "gateway_openai_upstream_unconfigured"
GATEWAY_ANTHROPIC_UPSTREAM_UNCONFIGURED = "gateway_anthropic_upstream_unconfigured"


@dataclass(frozen=True)
class PublicRouteResolution:
    upstream_url: str
    injected_auth_headers: dict[str, str]
    runtime_profile: str


class PublicRouteError(ValueError):
    def __init__(self, *, status_code: int, machine_code: str, message: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.machine_code = machine_code
        self.message = message


def sanitize_request_headers(
    headers: Mapping[str, str],
    spec: ProviderSpec,
    *,
    proxy_request_id: str | None = None,
    injected_headers: Mapping[str, str] | None = None,
) -> dict[str, str]:
    return sanitize_allowed_request_headers(
        headers,
        spec.request_headers,
        proxy_request_id=proxy_request_id,
        injected_headers=injected_headers,
    )


def sanitize_allowed_request_headers(
    headers: Mapping[str, str],
    allowed_headers: Set[str],
    *,
    proxy_request_id: str | None = None,
    default_accept: str | None = "application/json",
    default_content_type: str | None = "application/json",
    injected_headers: Mapping[str, str] | None = None,
) -> dict[str, str]:
    forwarded: dict[str, str] = {}
    for key, value in headers.items():
        lowered = key.lower()
        if lowered in CALLER_AUTH_HEADERS:
            continue
        if lowered in allowed_headers:
            if lowered in {"x-codex-turn-metadata", "x-codex-turn-state"}:
                continue
            if lowered == "x-request-id":
                normalized = value.strip()
                if OPAQUE_REQUEST_ID_RE.fullmatch(normalized):
                    forwarded[key] = normalized
                elif proxy_request_id is not None:
                    forwarded[key] = proxy_request_id
                continue
            forwarded[key] = value
    if default_accept is not None and "Accept" not in forwarded and "accept" not in forwarded:
        forwarded["Accept"] = default_accept
    if (
        default_content_type is not None
        and "Content-Type" not in forwarded
        and "content-type" not in forwarded
    ):
        forwarded["Content-Type"] = default_content_type
    if injected_headers is not None:
        for key, value in injected_headers.items():
            forwarded[key] = value
    return forwarded


def sanitize_response_headers(headers: Mapping[str, str]) -> dict[str, str]:
    sanitized: dict[str, str] = {}
    for key, value in headers.items():
        if key.lower() in HOP_BY_HOP_HEADERS:
            continue
        sanitized[key] = value
    return sanitized


def resolve_upstream_url(settings: Settings, spec: ProviderSpec) -> str:
    return resolve_provider_upstream_url(
        settings,
        provider=spec.name,
        upstream_path=spec.upstream_path,
    )


def resolve_provider_upstream_url(
    settings: Settings,
    *,
    provider: str,
    upstream_path: str,
) -> str:
    base_url = settings.provider_base_url(provider).rstrip("/")
    if not base_url:
        raise ValueError(f"Missing upstream base URL for provider {provider}")
    parsed = urlparse(base_url)
    if parsed.scheme not in {"https", "http"}:
        raise ValueError(f"Unsupported upstream scheme for {base_url}")
    if parsed.scheme != "https" and not settings.allow_insecure_upstreams:
        raise ValueError(f"Insecure upstream blocked by default: {base_url}")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError(f"Unsafe upstream URL shape blocked by default: {base_url}")
    if not settings.allow_nonstandard_upstream_hosts:
        hostname = parsed.hostname or ""
        if hostname not in STANDARD_PROVIDER_HOSTS[provider]:
            raise ValueError(f"Non-standard upstream host blocked by default: {base_url}")
    if base_url.endswith("/v1") and upstream_path.startswith("/v1/"):
        return f"{base_url}{upstream_path[3:]}"
    return f"{base_url}{upstream_path}"


def validate_public_request_auth(headers: Mapping[str, str], settings: Settings) -> None:
    expected_public_api_key = settings.public_api_key_value
    bearer_value = _extract_bearer_token(headers.get("authorization"))
    api_key_value = (headers.get("x-api-key") or "").strip()
    if expected_public_api_key and (
        secrets_compare(bearer_value, expected_public_api_key)
        or secrets_compare(api_key_value, expected_public_api_key)
    ):
        return
    raise PublicRouteError(
        status_code=401,
        machine_code=GATEWAY_PUBLIC_AUTH_INVALID,
        message="Missing or invalid public API key.",
    )


def resolve_public_route(settings: Settings, *, provider: str, upstream_path: str) -> PublicRouteResolution:
    runtime_profile = settings.runtime_profile.strip()
    if runtime_profile == GATEWAY_ONLY_RUNTIME_PROFILE:
        if not settings.direct_family_configured(provider):
            raise _missing_family_error(provider)
        if provider == "openai":
            token = (settings.openai_upstream_auth_token or "").strip()
            injected_auth_headers = {"Authorization": f"Bearer {token}"}
        else:
            token = (settings.anthropic_upstream_auth_token or "").strip()
            injected_auth_headers = {"X-API-Key": token}
    elif runtime_profile == BACKPLANE_RUNTIME_PROFILE:
        if not settings.backplane_family_configured(provider):
            raise _missing_family_error(provider)
        token = settings.backplane_auth_token_value
        if not token:
            raise _missing_family_error(provider)
        injected_auth_headers = {"Authorization": f"Bearer {token}"}
    else:
        raise ValueError(f"Unsupported runtime profile: {runtime_profile}")
    return PublicRouteResolution(
        upstream_url=resolve_provider_upstream_url(
            settings,
            provider=provider,
            upstream_path=upstream_path,
        ),
        injected_auth_headers=injected_auth_headers,
        runtime_profile=runtime_profile,
    )


def _extract_bearer_token(raw_authorization: str | None) -> str:
    if raw_authorization is None:
        return ""
    scheme, _, token = raw_authorization.partition(" ")
    if scheme.lower() != "bearer":
        return ""
    return token.strip()


def _missing_family_error(provider: str) -> PublicRouteError:
    if provider == "openai":
        return PublicRouteError(
            status_code=503,
            machine_code=GATEWAY_OPENAI_UPSTREAM_UNCONFIGURED,
            message="OpenAI-compatible upstream is not configured for the active runtime profile.",
        )
    return PublicRouteError(
        status_code=503,
        machine_code=GATEWAY_ANTHROPIC_UPSTREAM_UNCONFIGURED,
        message="Anthropic-compatible upstream is not configured for the active runtime profile.",
    )


def secrets_compare(left: str, right: str) -> bool:
    if not left or not right:
        return False
    import secrets

    return secrets.compare_digest(left, right)
