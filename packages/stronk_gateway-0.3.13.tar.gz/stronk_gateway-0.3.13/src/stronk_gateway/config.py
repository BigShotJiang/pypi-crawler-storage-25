from __future__ import annotations

from pathlib import Path
from urllib.parse import urlparse

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


STANDARD_PROVIDER_HOSTS = {
    "anthropic": frozenset({"api.anthropic.com"}),
    "openai": frozenset({"api.openai.com"}),
}


class Settings(BaseSettings):
    """Runtime settings for the proxy."""

    app_name: str = "Stronk Gateway"
    app_env: str = "development"
    log_level: str = "INFO"
    runtime_profile: str = "gateway+CLIProxyAPI"
    public_api_key: str | None = None
    openai_upstream_base_url: str = Field(
        default="https://api.openai.com",
        description="Upstream OpenAI-compatible base URL.",
    )
    anthropic_upstream_base_url: str = Field(
        default="https://api.anthropic.com",
        description="Upstream Anthropic-compatible base URL.",
    )
    openai_upstream_auth_token: str | None = None
    anthropic_upstream_auth_token: str | None = None
    backplane_auth_token: str | None = None
    request_timeout_seconds: float = Field(default=30.0, gt=0.0, le=120.0)
    upstream_max_connections: int = Field(default=128, ge=1, le=2_048)
    upstream_max_keepalive_connections: int = Field(default=32, ge=0, le=2_048)
    max_request_body_bytes: int = Field(default=1_048_576, gt=0)
    websocket_frame_byte_cap: int = Field(default=65_536, ge=1_024, le=2_097_152)
    websocket_idle_timeout_seconds: float = Field(default=30.0, gt=0.0, le=600.0)
    websocket_message_limit: int = Field(default=64, ge=1, le=10_000)
    websocket_consecutive_error_limit: int = Field(default=8, ge=1, le=100)
    websocket_turn_state_max_length: int = Field(default=128, ge=16, le=512)
    websocket_active_session_cap: int = Field(default=512, ge=1, le=10_000)
    allow_insecure_upstreams: bool = False
    allow_nonstandard_upstream_hosts: bool = False
    enable_debug_mask_endpoint: bool = False
    local_route_enabled: bool = False
    local_route_base_url: str | None = None
    audit_storage_enabled: bool = False
    audit_db_path: str | None = None
    audit_max_events: int = Field(default=2_000, ge=100, le=100_000)
    audit_prune_interval: int = Field(default=64, ge=1, le=4_096)
    audit_queue_maxsize: int = Field(default=2_048, ge=1, le=100_000)
    enable_admin_api: bool = False
    enable_admin_ui: bool = False
    admin_auth_mode: str = "session"
    admin_bootstrap_user: str | None = None
    admin_bootstrap_password_hash: str | None = None
    admin_bootstrap_roles: str = "admin,operator"
    admin_trace_allowed_roles: str = "admin,operator"
    admin_access_mode: str = "loopback"
    admin_http_bind: str = "127.0.0.1"
    admin_http_port: int = Field(default=8788, ge=1, le=65_535)
    admin_allowed_origins: str = ""
    admin_trusted_proxy_mode: str = "off"
    admin_enrollment_required: bool = False
    admin_session_cookie_name: str = "stronk_admin_session"
    admin_session_idle_ttl_seconds: int = Field(default=1_800, ge=60, le=86_400)
    admin_session_absolute_ttl_seconds: int = Field(default=43_200, ge=300, le=604_800)
    admin_session_secure_cookies: bool = False
    admin_login_attempt_limit: int = Field(default=5, ge=1, le=100)
    admin_login_attempt_window_seconds: int = Field(default=900, ge=30, le=86_400)
    admin_tailscale_socket_path: str = "/var/run/tailscale/tailscaled.sock"
    enable_unsafe_debug_view: bool = False
    unsafe_debug_max_entries: int = Field(default=25, ge=1, le=500)
    unsafe_debug_ttl_seconds: int = Field(default=900, ge=30, le=86_400)
    unsafe_debug_stream_tail_bytes: int = Field(default=16_384, ge=256, le=1_048_576)
    unsafe_debug_body_capture_bytes: int = Field(default=16_384, ge=256, le=1_048_576)
    unsafe_debug_gateway_secret: str | None = None
    admin_debug_bridge_base_url: str = "http://stronk-gateway-proxy:8789"
    admin_user_header: str = "X-Stronk-Admin-User"
    admin_roles_header: str = "X-Stronk-Admin-Roles"
    admin_allowed_roles: str = "admin,operator,auditor"
    admin_proxy_secret_header: str = "X-Stronk-Admin-Proxy-Secret"
    admin_proxy_secret: str | None = None
    admin_access_log_max_entries: int = Field(default=500, ge=50, le=100_000)
    admin_ui_dir: str | None = None
    admin_public_healthcheck_base_url: str | None = None
    admin_config_dir: str | None = None
    admin_generated_artifacts_dir: str | None = None

    presidio_enabled: bool = True
    presidio_supported_languages: str = "en,zh"
    presidio_score_threshold: float = Field(default=0.7, ge=0.0, le=1.0)
    presidio_english_model: str = "en_core_web_sm"
    presidio_chinese_model: str = "zh_core_web_sm"

    email_action: str = "mask"
    phone_action: str = "mask"
    business_id_action: str = "mask"
    person_name_action: str = "mask"
    organization_action: str = "mask"
    address_action: str = "mask"
    api_key_action: str = "block"
    bearer_token_action: str = "block"
    jwt_action: str = "block"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_prefix="STRONK_GATEWAY_",
        extra="ignore",
    )

    @model_validator(mode="after")
    def validate_local_route(self) -> Settings:
        allowed_runtime_profiles = {"gateway-only", "gateway+CLIProxyAPI"}
        allowed_auth_modes = {"session", "trusted_headers", "hybrid"}
        allowed_access_modes = {"loopback", "ssh-forward", "tailscale-serve"}
        allowed_trusted_proxy_modes = {"off", "tailscale"}
        if self.runtime_profile not in allowed_runtime_profiles:
            raise ValueError(
                "STRONK_GATEWAY_RUNTIME_PROFILE must be one of: "
                "gateway-only, gateway+CLIProxyAPI."
            )
        if self.admin_auth_mode not in allowed_auth_modes:
            raise ValueError(
                "STRONK_GATEWAY_ADMIN_AUTH_MODE must be one of: session, trusted_headers, hybrid."
            )
        if self.admin_access_mode not in allowed_access_modes:
            raise ValueError(
                "STRONK_GATEWAY_ADMIN_ACCESS_MODE must be one of: "
                "loopback, ssh-forward, tailscale-serve."
            )
        if self.admin_trusted_proxy_mode not in allowed_trusted_proxy_modes:
            raise ValueError(
                "STRONK_GATEWAY_ADMIN_TRUSTED_PROXY_MODE must be one of: off, tailscale."
            )
        if self.upstream_max_keepalive_connections > self.upstream_max_connections:
            raise ValueError(
                "STRONK_GATEWAY_UPSTREAM_MAX_KEEPALIVE_CONNECTIONS must be less than or equal "
                "to STRONK_GATEWAY_UPSTREAM_MAX_CONNECTIONS."
            )
        if self.local_route_enabled and not self.local_route_base_url:
            raise ValueError(
                "STRONK_GATEWAY_LOCAL_ROUTE_BASE_URL is required when local routing is enabled."
            )
        if (self.audit_storage_enabled or self.enable_admin_api or self.enable_admin_ui) and (
            not self.audit_db_path
        ):
            raise ValueError(
                "STRONK_GATEWAY_AUDIT_DB_PATH is required when audit storage "
                "or admin surfaces are enabled."
            )
        if self.enable_admin_api and not self.audit_storage_enabled:
            raise ValueError(
                "STRONK_GATEWAY_AUDIT_STORAGE_ENABLED must be true when admin API is enabled."
            )
        if self.enable_admin_ui and not self.enable_admin_api:
            raise ValueError(
                "STRONK_GATEWAY_ENABLE_ADMIN_API must be true when admin UI is enabled."
            )
        if self.enable_admin_api and self.admin_auth_mode in {"session", "hybrid"}:
            if not self.admin_bootstrap_user:
                raise ValueError(
                    "STRONK_GATEWAY_ADMIN_BOOTSTRAP_USER is required when "
                    "session-based admin auth is enabled."
                )
            if not self.admin_bootstrap_password_hash:
                raise ValueError(
                    "STRONK_GATEWAY_ADMIN_BOOTSTRAP_PASSWORD_HASH is required "
                    "when session-based admin auth is enabled."
                )
        if self.enable_admin_api and self.admin_auth_mode in {"trusted_headers", "hybrid"}:
            if not self.admin_proxy_secret:
                raise ValueError(
                    "STRONK_GATEWAY_ADMIN_PROXY_SECRET is required when "
                    "trusted-header admin auth is enabled."
                )
        if self.admin_trusted_proxy_mode != "off" and self.admin_access_mode != "tailscale-serve":
            raise ValueError(
                "STRONK_GATEWAY_ADMIN_TRUSTED_PROXY_MODE may only be enabled "
                "for tailscale-serve access."
            )
        if self.admin_http_bind not in {"127.0.0.1", "::1", "localhost"}:
            raise ValueError(
                "STRONK_GATEWAY_ADMIN_HTTP_BIND must remain loopback-bound for "
                "supported admin access modes."
            )
        if self.admin_enrollment_required and self.admin_access_mode != "tailscale-serve":
            raise ValueError(
                "STRONK_GATEWAY_ADMIN_ENROLLMENT_REQUIRED may only be enabled "
                "for tailscale-serve access."
            )
        if self.admin_access_mode == "tailscale-serve":
            if not self.admin_allowed_origin_set:
                raise ValueError(
                    "STRONK_GATEWAY_ADMIN_ALLOWED_ORIGINS is required when "
                    "tailscale-serve access is enabled."
                )
            if self.admin_trusted_proxy_mode != "tailscale":
                raise ValueError(
                    "STRONK_GATEWAY_ADMIN_TRUSTED_PROXY_MODE must be tailscale "
                    "when tailscale-serve access is enabled."
                )
            if not self.admin_enrollment_required:
                raise ValueError(
                    "STRONK_GATEWAY_ADMIN_ENROLLMENT_REQUIRED must be true when "
                    "tailscale-serve access is enabled."
                )
            if not self.admin_session_secure_cookies:
                raise ValueError(
                    "STRONK_GATEWAY_ADMIN_SESSION_SECURE_COOKIES must be true "
                    "when tailscale-serve access is enabled."
                )
        if self.enable_unsafe_debug_view:
            if not self.audit_storage_enabled:
                raise ValueError(
                    "STRONK_GATEWAY_AUDIT_STORAGE_ENABLED must be true when unsafe debug "
                    "view is enabled."
                )
            if not self.unsafe_debug_gateway_secret:
                raise ValueError(
                    "STRONK_GATEWAY_UNSAFE_DEBUG_GATEWAY_SECRET is required when unsafe debug "
                    "view is enabled."
                )
            if (
                self.admin_auth_mode in {"trusted_headers", "hybrid"}
                and not self.admin_proxy_secret
            ):
                raise ValueError(
                    "STRONK_GATEWAY_ADMIN_PROXY_SECRET is required when unsafe "
                    "debug view uses trusted-header admin auth."
                )
        return self

    @property
    def admin_allowed_role_set(self) -> frozenset[str]:
        return frozenset(
            role.strip().lower() for role in self.admin_allowed_roles.split(",") if role.strip()
        )

    @property
    def admin_bootstrap_role_set(self) -> frozenset[str]:
        return frozenset(
            role.strip().lower() for role in self.admin_bootstrap_roles.split(",") if role.strip()
        )

    @property
    def admin_trace_allowed_role_set(self) -> frozenset[str]:
        return frozenset(
            role.strip().lower()
            for role in self.admin_trace_allowed_roles.split(",")
            if role.strip()
        )

    @property
    def admin_allowed_origin_set(self) -> frozenset[str]:
        return frozenset(
            origin.strip().rstrip("/")
            for origin in self.admin_allowed_origins.split(",")
            if origin.strip()
        )

    @property
    def presidio_language_list(self) -> tuple[str, ...]:
        return tuple(
            language.strip().lower()
            for language in self.presidio_supported_languages.split(",")
            if language.strip()
        )

    @property
    def admin_config_path(self) -> Path | None:
        return _resolve_optional_path(self.admin_config_dir)

    @property
    def admin_bundle_root(self) -> Path | None:
        config_path = self.admin_config_path
        if config_path is None:
            return None
        return config_path.parent

    @property
    def admin_generated_artifacts_path(self) -> Path | None:
        explicit_path = _resolve_optional_path(self.admin_generated_artifacts_dir)
        if explicit_path is not None:
            return explicit_path
        bundle_root = self.admin_bundle_root
        if bundle_root is None:
            return None
        return bundle_root / "generated"

    @property
    def admin_bundle_env_path(self) -> Path | None:
        bundle_root = self.admin_bundle_root
        if bundle_root is None:
            return None
        return bundle_root / ".env"

    @property
    def admin_secrets_path(self) -> Path | None:
        bundle_root = self.admin_bundle_root
        if bundle_root is None:
            return None
        return bundle_root / "secrets"

    def validate_runtime_contract(self) -> None:
        public_api_key = self.public_api_key_value
        if not public_api_key:
            raise ValueError(
                "STRONK_GATEWAY_PUBLIC_API_KEY is required for all runtime profiles."
            )
        credential_pairs = (
            ("STRONK_GATEWAY_OPENAI_UPSTREAM_AUTH_TOKEN", (self.openai_upstream_auth_token or "").strip()),
            (
                "STRONK_GATEWAY_ANTHROPIC_UPSTREAM_AUTH_TOKEN",
                (self.anthropic_upstream_auth_token or "").strip(),
            ),
            ("STRONK_GATEWAY_BACKPLANE_AUTH_TOKEN", self.backplane_auth_token_value),
        )
        for env_name, credential in credential_pairs:
            if credential and credential == public_api_key:
                raise ValueError(
                    f"{env_name} must not equal STRONK_GATEWAY_PUBLIC_API_KEY."
                )
        if self.runtime_profile == "gateway-only":
            if not (
                self.direct_family_configured("openai")
                or self.direct_family_configured("anthropic")
            ):
                raise ValueError(
                    "STRONK_GATEWAY_RUNTIME_PROFILE=gateway-only requires at least one fully "
                    "configured direct upstream family."
                )
            return
        if self.runtime_profile == "gateway+CLIProxyAPI":
            if not self.backplane_auth_token_value:
                raise ValueError(
                    "STRONK_GATEWAY_BACKPLANE_AUTH_TOKEN is required for "
                    "STRONK_GATEWAY_RUNTIME_PROFILE=gateway+CLIProxyAPI."
                )
            if not (
                self.backplane_family_configured("openai")
                or self.backplane_family_configured("anthropic")
            ):
                raise ValueError(
                    "STRONK_GATEWAY_RUNTIME_PROFILE=gateway+CLIProxyAPI requires at least one "
                    "private backplane family base URL."
                )
            return
        raise ValueError(
            "STRONK_GATEWAY_RUNTIME_PROFILE must be one of: gateway-only, gateway+CLIProxyAPI."
        )

    @property
    def public_api_key_value(self) -> str:
        return (self.public_api_key or "").strip()

    @property
    def backplane_auth_token_value(self) -> str:
        return (self.backplane_auth_token or "").strip()

    def provider_base_url(self, provider: str) -> str:
        if provider == "openai":
            return self.openai_upstream_base_url.strip()
        if provider == "anthropic":
            return self.anthropic_upstream_base_url.strip()
        raise ValueError(f"Unsupported provider: {provider}")

    def direct_family_configured(self, provider: str) -> bool:
        base_url = self.provider_base_url(provider)
        if not base_url:
            return False
        if provider == "openai":
            return bool((self.openai_upstream_auth_token or "").strip())
        return bool((self.anthropic_upstream_auth_token or "").strip())

    def backplane_family_configured(self, provider: str) -> bool:
        base_url = self.provider_base_url(provider)
        if not base_url:
            return False
        hostname = (urlparse(base_url).hostname or "").lower()
        if not hostname:
            return False
        return hostname not in STANDARD_PROVIDER_HOSTS[provider]


def get_settings() -> Settings:
    return Settings()


def _resolve_optional_path(value: str | None) -> Path | None:
    if value is None:
        return None
    cleaned = value.strip()
    if not cleaned:
        return None
    return Path(cleaned).expanduser()
