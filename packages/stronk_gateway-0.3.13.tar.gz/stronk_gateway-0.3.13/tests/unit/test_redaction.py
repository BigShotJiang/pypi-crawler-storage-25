from __future__ import annotations

import json

from stronk_gateway.config import Settings
from stronk_gateway.policy.engine import PolicyEngine
from stronk_gateway.redaction.models import DetectorType
from stronk_gateway.redaction.pipeline import RedactionEngine


def build_engine(**overrides: object) -> RedactionEngine:
    settings = Settings(**overrides)
    return RedactionEngine(policy=PolicyEngine.from_settings(settings), settings=settings)


def test_redacts_mixed_english_and_chinese_sensitive_values() -> None:
    engine = build_engine()
    payload = {
        "message": (
            "please contact Alice Johnson at alice@example.com or 415-555-0101. "
            "客户姓名张三，公司是北京字节科技公司，地址在上海市浦东新区世纪大道100号。"
        )
    }

    result = engine.redact_payload(payload)
    masked = str(result.payload)

    assert "Alice Johnson" not in masked
    assert "alice@example.com" not in masked
    assert "415-555-0101" not in masked
    assert "张三" not in masked
    assert "北京字节科技公司" not in masked
    assert "上海市浦东新区世纪大道100号" not in masked
    assert len(result.masked) >= 6


def test_blocks_api_keys_bearer_tokens_and_jwts_by_default() -> None:
    engine = build_engine()
    payload = {
        "message": (
            "sk-proj-abcdefghijklmnopqrstuvwxyz123456 "
            "sk-ant-api03-abcdefghijklmnopqrstuvwxyz123456 "
            "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
            "eyJzdWIiOiIxMjM0NTY3ODkwIn0.signaturepart123456"
        )
    }

    result = engine.redact_payload(payload)
    masked_message = result.payload["message"]  # type: ignore[index]

    blocked_types = {item.detector for item in result.blocked}
    assert DetectorType.API_KEY in blocked_types
    assert DetectorType.BEARER_TOKEN in blocked_types
    assert "sk-proj-" not in masked_message
    assert "Bearer eyJ" not in masked_message
    assert "[[API_KEY_1]]" in masked_message
    assert "[[BEARER_TOKEN_1]]" in masked_message


def test_placeholders_are_request_scoped_and_stable_within_one_payload() -> None:
    engine = build_engine()
    payload = {"message": "email alice@example.com and again alice@example.com"}

    first = engine.redact_payload(payload)
    second = engine.redact_payload(payload)

    first_placeholders = {item.placeholder for item in first.masked}
    second_placeholders = {item.placeholder for item in second.masked}
    assert len(first_placeholders) == 1
    placeholder = next(iter(first_placeholders))
    assert placeholder == "[[EMAIL_1]]"
    assert second_placeholders == {"[[EMAIL_1]]"}


def test_embedded_json_arguments_are_masked_and_rehydrated() -> None:
    engine = build_engine()
    payload = {
        "tool_calls": [
            {
                "function": {
                    "arguments": json.dumps(
                        {"email": "alice@example.com", "person": "Alice Johnson"},
                        ensure_ascii=False,
                    )
                }
            }
        ]
    }

    result = engine.redact_payload(payload)
    arguments = result.payload["tool_calls"][0]["function"]["arguments"]  # type: ignore[index]

    assert "alice@example.com" not in arguments
    assert "Alice Johnson" not in arguments
    assert "[[EMAIL_1]]" in arguments
    assert "[[PERSON_1]]" in arguments
    restored = engine.rehydrate_payload(result.payload, result.vault)

    restored_arguments = restored["tool_calls"][0]["function"]["arguments"]  # type: ignore[index]
    assert "alice@example.com" not in restored_arguments
    assert "Alice Johnson" not in restored_arguments
    assert "[[EMAIL_1]]" in restored_arguments
    assert "[[PERSON_1]]" in restored_arguments


def test_generated_placeholder_never_collides_with_existing_literal() -> None:
    engine = build_engine()
    payload = {
        "message": "literal [[EMAIL_1]] and alice@example.com",
    }

    result = engine.redact_payload(payload)
    placeholder = next(iter({item.placeholder for item in result.masked if item.placeholder}))

    assert placeholder == "[[EMAIL_2]]"
    restored = result.vault.rehydrate_text(result.payload["message"])  # type: ignore[index]
    assert restored == "literal [[EMAIL_1]] and alice@example.com"


def test_placeholder_generation_skips_reserved_typed_indices() -> None:
    engine = build_engine()
    payload = {
        "message": (
            "reserved [[EMAIL_1]] [[EMAIL_2]] [[EMAIL_3]] "
            "plus alice@example.com and bob@example.com"
        )
    }

    result = engine.redact_payload(payload)
    placeholders = sorted(
        item.placeholder for item in result.masked if item.detector is DetectorType.EMAIL
    )

    assert placeholders == ["[[EMAIL_4]]", "[[EMAIL_5]]"]


def test_split_secret_with_zero_width_character_is_detected() -> None:
    engine = build_engine()
    payload = {"message": "token sk-\u200babcdefghijklmnopqrstuvwxyz123456"}

    result = engine.redact_payload(payload)

    assert any(item.detector is DetectorType.API_KEY for item in result.blocked)


def test_english_name_detection_avoids_common_false_positives_in_sentences() -> None:
    engine = build_engine()
    payload = {
        "message": (
            "Repeat exactly this line and nothing else: Contact Alice Johnson at "
            "alice.johnson@example.com or +1 (415) 555-0123 for ACME Robotics, "
            "123 Market Street, San Francisco, CA 94105."
        )
    }

    result = engine.redact_payload(payload)
    masked_message = result.payload["message"]  # type: ignore[index]
    person_name_decisions = [
        item for item in result.masked if item.detector is DetectorType.PERSON_NAME
    ]

    assert len(person_name_decisions) == 1
    assert "Alice Johnson" not in masked_message
    assert "Contact" in masked_message
    assert "San Francisco" in masked_message


def test_standalone_english_name_value_is_masked() -> None:
    engine = build_engine()
    payload = {"person": "Alice Johnson"}

    result = engine.redact_payload(payload)

    assert any(item.detector is DetectorType.PERSON_NAME for item in result.masked)
    assert result.payload["person"] == "[[PERSON_1]]"  # type: ignore[index]


def test_multiple_detector_types_get_typed_placeholders_with_per_type_counters() -> None:
    engine = build_engine()
    payload = {
        "first_email": "alice@example.com",
        "second_email": "bob@example.com",
        "contact_name": "Alice Johnson",
        "company": "北京字节科技公司",
    }

    result = engine.redact_payload(payload)
    masked_payload = json.dumps(result.payload, ensure_ascii=False)

    assert "[[EMAIL_1]]" in masked_payload
    assert "[[EMAIL_2]]" in masked_payload
    assert "[[PERSON_1]]" in masked_payload
    assert "[[ORG_1]]" in masked_payload


def test_pdf_like_tax_letter_masks_precise_org_person_and_business_ids() -> None:
    engine = build_engine()
    payload = {
        "message": (
            "委托书\n"
            "委托方：EYYCHEEV GAMES INC.\n"
            "纳税编码：780304507\n"
            "受托方：佛山市川东磁电股份有限公司\n"
            "统一信用代码：914406007375904397\n"
            "EYYCHEEV GAMES INC.为加拿大非居民企业，现为佛山市川东磁电股份有限公司提"
            "供产品全生命周期管理系统开发服务，委托佛山市川东磁电股份有限公司代办理税务事宜。\n"
            "委托人（签字）：YAN YI MIN, Director\n"
        )
    }

    result = engine.redact_payload(payload)
    masked_message = result.payload["message"]  # type: ignore[index]
    decisions = {(item.detector, item.placeholder) for item in result.masked}

    assert "EYYCHEEV GAMES INC." not in masked_message
    assert "佛山市川东磁电股份有限公司" not in masked_message
    assert "YAN YI MIN" not in masked_message
    assert "914406007375904397" not in masked_message
    assert "780304507" not in masked_message
    assert (DetectorType.ORGANIZATION, "[[ORG_1]]") in decisions
    assert any(item[0] is DetectorType.PERSON_NAME for item in decisions)
    assert any(item[0] is DetectorType.BUSINESS_ID for item in decisions)


def test_top_level_tools_are_scanned_for_sensitive_content() -> None:
    engine = build_engine()
    payload = {
        "model": "gpt-4.1",
        "tools": [
            {
                "type": "function",
                "name": "notion_search",
                "description": (
                    "Example email debug@example.com, page id "
                    "a1b2c3d4-e5f6-7890-abcd-ef1234567890."
                ),
            }
        ],
        "input": [
            {
                "role": "user",
                "content": [
                    {"type": "input_text", "text": "Please email alice@example.com today."}
                ],
            }
        ],
    }

    result = engine.redact_payload(payload)
    masked_payload = json.dumps(result.payload, ensure_ascii=False)

    assert "debug@example.com" not in masked_payload
    assert "alice@example.com" not in masked_payload
    assert {decision.path for decision in result.decisions} == {
        "/tools/0/description",
        "/input/0/content/0/text",
    }
    assert {decision.path for decision in result.blocked} == {"/tools/0/description"}


def test_openai_responses_masks_developer_messages_and_instructions() -> None:
    engine = build_engine()
    payload = {
        "instructions": "System note about alice@example.com.",
        "input": [
            {
                "type": "message",
                "role": "developer",
                "content": [{"type": "input_text", "text": "Developer dev@example.com"}],
            },
            {
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": "Email user@example.com"}],
            },
        ],
    }

    result = engine.redact_payload(payload)

    masked_payload = json.dumps(result.payload, ensure_ascii=False)
    assert "alice@example.com" not in masked_payload
    assert "dev@example.com" not in masked_payload
    assert "user@example.com" not in masked_payload
    assert {decision.path for decision in result.masked} == {
        "/instructions",
        "/input/0/content/0/text",
        "/input/1/content/0/text",
    }


def test_openai_responses_masks_untyped_developer_and_system_messages() -> None:
    engine = build_engine()
    payload = {
        "input": [
            {
                "role": "developer",
                "content": [{"type": "input_text", "text": "Developer dev@example.com"}],
            },
            {
                "role": "system",
                "content": [{"type": "input_text", "text": "System sys@example.com"}],
            },
            {
                "role": "user",
                "content": [{"type": "input_text", "text": "Email user@example.com"}],
            },
        ]
    }

    result = engine.redact_payload(payload)

    masked_payload = json.dumps(result.payload, ensure_ascii=False)
    assert "dev@example.com" not in masked_payload
    assert "sys@example.com" not in masked_payload
    assert "user@example.com" not in masked_payload
    assert {decision.path for decision in result.masked} == {
        "/input/0/content/0/text",
        "/input/1/content/0/text",
        "/input/2/content/0/text",
    }


def test_redaction_skips_path_like_strings_even_when_they_contain_names() -> None:
    engine = build_engine()
    text = (
        "Open /Users/eyy/Downloads/李琳-重点项目进度12月份.xlsx and email alice@example.com "
        "to EYYCHEEV GAMES INC."
    )

    result = engine.redact_text(text)

    assert "/Users/eyy/Downloads/李琳-重点项目进度12月份.xlsx" in result.payload
    assert "alice@example.com" not in result.payload
    assert "EYYCHEEV GAMES INC." not in result.payload
    assert len(result.masked) == 2
    assert {decision.detector for decision in result.masked} == {
        DetectorType.EMAIL,
        DetectorType.ORGANIZATION,
    }


def test_redaction_skips_machine_identifier_fields_in_structured_payloads() -> None:
    engine = build_engine()
    payload = {
        "previous_response_id": "resp_1",
        "input": [
            {
                "type": "message",
                "id": "msg_2",
                "content": [{"type": "input_text", "text": "Email alice@example.com"}],
            }
        ],
    }

    result = engine.redact_payload(payload)

    assert result.payload["previous_response_id"] == "resp_1"  # type: ignore[index]
    assert result.payload["input"][0]["id"] == "msg_2"  # type: ignore[index]
    assert "alice@example.com" not in json.dumps(result.payload["input"][0], ensure_ascii=False)  # type: ignore[index]
    assert len(result.masked) == 1
    assert result.masked[0].path == "/input/0/content/0/text"


def test_redaction_preserves_top_level_model_while_masking_other_fields() -> None:
    engine = build_engine()
    payload = {
        "model": "gpt-4.1-mini",
        "message": "Email alice@example.com",
    }

    result = engine.redact_payload(payload)

    assert result.payload["model"] == "gpt-4.1-mini"  # type: ignore[index]
    assert result.payload["message"] != "Email alice@example.com"  # type: ignore[index]
    assert "alice@example.com" not in str(result.payload["message"])  # type: ignore[index]
    assert len(result.masked) == 1
    assert result.masked[0].path == "/message"


def test_redaction_keeps_nested_model_fields_redactable() -> None:
    engine = build_engine()
    secret_like_model = "sk-proj-abcdefghijklmnopqrstuvwxyz123456"
    payload = {
        "metadata": {
            "model": secret_like_model,
        }
    }

    result = engine.redact_payload(payload)

    assert result.payload["metadata"]["model"] != secret_like_model  # type: ignore[index]
    assert any(item.detector is DetectorType.API_KEY for item in result.blocked)
