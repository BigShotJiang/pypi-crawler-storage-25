from __future__ import annotations

import tomllib
from pathlib import Path

import pytest

from stronk_gateway.config import Settings
from stronk_gateway.policy.engine import PolicyEngine
from stronk_gateway.redaction.models import DetectorType, PolicyAction


def test_settings_defaults_are_privacy_preserving() -> None:
    settings = Settings()

    assert settings.app_name == "Stronk Gateway"
    assert settings.runtime_profile == "gateway+CLIProxyAPI"
    assert settings.public_api_key is None
    assert settings.allow_insecure_upstreams is False
    assert settings.enable_debug_mask_endpoint is False
    assert settings.enable_unsafe_debug_view is False
    assert settings.api_key_action == "block"
    assert settings.email_action == "mask"
    assert settings.business_id_action == "mask"
    assert settings.presidio_enabled is True
    assert settings.presidio_language_list == ("en", "zh")
    assert settings.admin_access_mode == "loopback"
    assert settings.admin_http_bind == "127.0.0.1"
    assert settings.admin_session_absolute_ttl_seconds == 43_200
    assert settings.admin_login_attempt_limit == 5
    assert settings.admin_login_attempt_window_seconds == 900


def test_runtime_contract_requires_public_api_key_on_startup() -> None:
    settings = Settings(
        runtime_profile="gateway-only",
        openai_upstream_base_url="http://openai.test",
        openai_upstream_auth_token="openai-direct-token",
        allow_insecure_upstreams=True,
        allow_nonstandard_upstream_hosts=True,
    )

    with pytest.raises(ValueError, match="STRONK_GATEWAY_PUBLIC_API_KEY"):
        settings.validate_runtime_contract()


def test_gateway_only_runtime_contract_requires_a_fully_configured_direct_family() -> None:
    settings = Settings(
        runtime_profile="gateway-only",
        public_api_key="public-key",
    )

    with pytest.raises(ValueError, match="at least one fully configured direct upstream family"):
        settings.validate_runtime_contract()


def test_backplane_runtime_contract_requires_a_private_backplane_family_url() -> None:
    settings = Settings(
        runtime_profile="gateway+CLIProxyAPI",
        public_api_key="public-key",
        backplane_auth_token="backplane-token",
    )

    with pytest.raises(ValueError, match="private backplane family base URL"):
        settings.validate_runtime_contract()


def test_backplane_runtime_contract_accepts_private_backplane_urls() -> None:
    settings = Settings(
        runtime_profile="gateway+CLIProxyAPI",
        public_api_key="public-key",
        openai_upstream_base_url="http://cliproxyapi.internal/v1",
        backplane_auth_token="backplane-token",
        allow_insecure_upstreams=True,
        allow_nonstandard_upstream_hosts=True,
    )

    settings.validate_runtime_contract()


def test_runtime_contract_requires_private_credentials_to_differ_from_public_api_key() -> None:
    with pytest.raises(
        ValueError,
        match="STRONK_GATEWAY_OPENAI_UPSTREAM_AUTH_TOKEN must not equal STRONK_GATEWAY_PUBLIC_API_KEY",
    ):
        Settings(
            runtime_profile="gateway-only",
            public_api_key="shared-key",
            openai_upstream_base_url="http://openai.test",
            openai_upstream_auth_token="shared-key",
            allow_insecure_upstreams=True,
            allow_nonstandard_upstream_hosts=True,
        ).validate_runtime_contract()

    with pytest.raises(
        ValueError,
        match="STRONK_GATEWAY_BACKPLANE_AUTH_TOKEN must not equal STRONK_GATEWAY_PUBLIC_API_KEY",
    ):
        Settings(
            runtime_profile="gateway+CLIProxyAPI",
            public_api_key="shared-key",
            openai_upstream_base_url="http://cliproxyapi.internal/v1",
            backplane_auth_token="shared-key",
            allow_insecure_upstreams=True,
            allow_nonstandard_upstream_hosts=True,
        ).validate_runtime_contract()


def test_policy_engine_respects_route_local_override() -> None:
    settings = Settings(phone_action="route_local")
    policy = PolicyEngine.from_settings(settings)

    assert policy.decide(DetectorType.PHONE, "/messages/0/content") is PolicyAction.ROUTE_LOCAL


def test_policy_engine_supports_business_id_action() -> None:
    settings = Settings(business_id_action="block")
    policy = PolicyEngine.from_settings(settings)

    assert policy.decide(DetectorType.BUSINESS_ID, "/message") is PolicyAction.BLOCK


def test_local_route_requires_base_url() -> None:
    with pytest.raises(ValueError):
        Settings(local_route_enabled=True)


def test_keepalive_connections_cannot_exceed_total_upstream_connections() -> None:
    with pytest.raises(ValueError):
        Settings(
            upstream_max_connections=8,
            upstream_max_keepalive_connections=9,
        )


def test_admin_api_requires_audit_storage() -> None:
    with pytest.raises(ValueError):
        Settings(enable_admin_api=True, audit_db_path="/tmp/stronk-gateway-audit.sqlite3")


def test_admin_ui_requires_admin_api() -> None:
    with pytest.raises(ValueError):
        Settings(
            audit_storage_enabled=True,
            audit_db_path="/tmp/stronk-gateway-audit.sqlite3",
            enable_admin_ui=True,
        )


def test_admin_api_requires_bootstrap_credentials_in_session_mode() -> None:
    with pytest.raises(ValueError):
        Settings(
            audit_storage_enabled=True,
            audit_db_path="/tmp/stronk-gateway-audit.sqlite3",
            enable_admin_api=True,
        )


def test_admin_api_requires_proxy_secret_in_trusted_header_mode() -> None:
    with pytest.raises(ValueError):
        Settings(
            audit_storage_enabled=True,
            audit_db_path="/tmp/stronk-gateway-audit.sqlite3",
            enable_admin_api=True,
            admin_auth_mode="trusted_headers",
        )


def test_unsafe_debug_view_requires_audit_storage() -> None:
    with pytest.raises(ValueError):
        Settings(
            enable_unsafe_debug_view=True,
            admin_bootstrap_user="operator",
            admin_bootstrap_password_hash="hash",
            unsafe_debug_gateway_secret="gateway-secret",
        )


def test_unsafe_debug_view_requires_gateway_secret() -> None:
    with pytest.raises(ValueError):
        Settings(
            enable_unsafe_debug_view=True,
            audit_storage_enabled=True,
            audit_db_path="/tmp/stronk-gateway-audit.sqlite3",
            admin_bootstrap_user="operator",
            admin_bootstrap_password_hash="hash",
        )


def test_invalid_admin_auth_mode_is_rejected() -> None:
    with pytest.raises(ValueError):
        Settings(admin_auth_mode="nope")


def test_invalid_runtime_profile_is_rejected() -> None:
    with pytest.raises(ValueError):
        Settings(runtime_profile="invalid-profile")


def test_invalid_admin_access_mode_is_rejected() -> None:
    with pytest.raises(ValueError):
        Settings(admin_access_mode="nope")


def test_admin_http_bind_must_remain_loopback_bound() -> None:
    with pytest.raises(ValueError):
        Settings(admin_http_bind="0.0.0.0")


def test_trusted_proxy_mode_is_rejected_outside_tailscale_serve() -> None:
    with pytest.raises(ValueError):
        Settings(admin_trusted_proxy_mode="tailscale")


def test_enrollment_requirement_is_rejected_outside_tailscale_serve() -> None:
    with pytest.raises(ValueError):
        Settings(admin_enrollment_required=True)


def test_tailscale_serve_requires_origins_trusted_proxy_enrollment_and_secure_cookies() -> None:
    with pytest.raises(ValueError):
        Settings(admin_access_mode="tailscale-serve")

    with pytest.raises(ValueError):
        Settings(
            admin_access_mode="tailscale-serve",
            admin_allowed_origins="https://admin.example.ts.net",
        )

    with pytest.raises(ValueError):
        Settings(
            admin_access_mode="tailscale-serve",
            admin_allowed_origins="https://admin.example.ts.net",
            admin_trusted_proxy_mode="tailscale",
        )

    with pytest.raises(ValueError):
        Settings(
            admin_access_mode="tailscale-serve",
            admin_allowed_origins="https://admin.example.ts.net",
            admin_trusted_proxy_mode="tailscale",
            admin_enrollment_required=True,
        )


def test_tailscale_serve_accepts_the_locked_phase_two_contract() -> None:
    settings = Settings(
        audit_storage_enabled=True,
        audit_db_path="/tmp/stronk-gateway-audit.sqlite3",
        enable_admin_api=True,
        admin_bootstrap_user="operator",
        admin_bootstrap_password_hash="hash",
        admin_access_mode="tailscale-serve",
        admin_allowed_origins="https://admin.example.ts.net",
        admin_trusted_proxy_mode="tailscale",
        admin_enrollment_required=True,
        admin_session_secure_cookies=True,
    )

    assert settings.admin_access_mode == "tailscale-serve"
    assert settings.admin_allowed_origin_set == frozenset({"https://admin.example.ts.net"})


def test_runtime_dependencies_include_websocket_backend() -> None:
    pyproject_path = Path(__file__).resolve().parents[2] / "pyproject.toml"
    data = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
    dependencies = data["project"]["dependencies"]

    assert any(
        dependency.startswith("websockets")
        or dependency.startswith("wsproto")
        or dependency.startswith("uvicorn[standard]")
        for dependency in dependencies
    )


def test_compose_proxy_includes_debug_admin_and_gateway_secrets() -> None:
    compose_path = Path(__file__).resolve().parents[2] / "compose" / "docker-compose.yml"
    compose_text = compose_path.read_text(encoding="utf-8")

    assert "STRONK_GATEWAY_ADMIN_BOOTSTRAP_PASSWORD_HASH" in compose_text
    assert "STRONK_GATEWAY_UNSAFE_DEBUG_GATEWAY_SECRET" in compose_text


def test_env_example_requires_scrypt_admin_hash_guidance() -> None:
    env_example_path = Path(__file__).resolve().parents[2] / "config" / ".env.example"
    env_example_text = env_example_path.read_text(encoding="utf-8")

    assert "STRONK_GATEWAY_ADMIN_BOOTSTRAP_USER=" in env_example_text
    assert "STRONK_GATEWAY_ADMIN_BOOTSTRAP_PASSWORD_HASH=" in env_example_text
    assert "STRONK_GATEWAY_ADMIN_BOOTSTRAP_ROLES=" in env_example_text
    assert "scrypt hash" in env_example_text
    assert "STRONK_GATEWAY_ADMIN_USER=" not in env_example_text
    assert "STRONK_GATEWAY_ADMIN_PASSWORD_HASH=" not in env_example_text
    assert "caddy-bcrypt" not in env_example_text
    assert "$2a$" not in env_example_text


def test_admin_bundle_paths_are_derived_from_admin_config_dir() -> None:
    settings = Settings(admin_config_dir="/tmp/stronk-gateway/config")

    assert settings.admin_config_path == Path("/tmp/stronk-gateway/config")
    assert settings.admin_bundle_root == Path("/tmp/stronk-gateway")
    assert settings.admin_generated_artifacts_path == Path("/tmp/stronk-gateway/generated")
    assert settings.admin_bundle_env_path == Path("/tmp/stronk-gateway/.env")
    assert settings.admin_secrets_path == Path("/tmp/stronk-gateway/secrets")


def test_explicit_generated_artifacts_dir_overrides_bundle_default() -> None:
    settings = Settings(
        admin_config_dir="/tmp/stronk-gateway/config",
        admin_generated_artifacts_dir="/tmp/custom-generated",
    )

    assert settings.admin_generated_artifacts_path == Path("/tmp/custom-generated")
