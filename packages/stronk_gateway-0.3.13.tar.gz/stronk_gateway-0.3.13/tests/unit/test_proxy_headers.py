from __future__ import annotations

import pytest

from stronk_gateway.config import Settings
from stronk_gateway.proxy.headers import (
    GATEWAY_ANTHROPIC_UPSTREAM_UNCONFIGURED,
    GATEWAY_OPENAI_UPSTREAM_UNCONFIGURED,
    GATEWAY_PUBLIC_AUTH_INVALID,
    PublicRouteError,
    resolve_public_route,
    resolve_upstream_url,
    sanitize_request_headers,
    validate_public_request_auth,
)
from stronk_gateway.providers import ANTHROPIC_MESSAGES, OPENAI_CHAT_COMPLETIONS


def test_request_header_allowlist_strips_caller_auth_and_injects_gateway_owned_auth() -> None:
    headers = sanitize_request_headers(
        {
            "Authorization": "Bearer public-key",
            "X-API-Key": "public-key",
            "Cookie": "session=1",
            "X-Forwarded-For": "1.1.1.1",
            "Content-Type": "application/json",
        },
        OPENAI_CHAT_COMPLETIONS,
        injected_headers={"Authorization": "Bearer openai-direct-token"},
    )

    assert headers["Authorization"] == "Bearer openai-direct-token"
    assert "Cookie" not in headers
    assert "X-Forwarded-For" not in headers
    assert "X-API-Key" not in headers


def test_public_request_auth_accepts_bearer_and_x_api_key() -> None:
    settings = Settings(public_api_key="public-key")

    validate_public_request_auth({"authorization": "Bearer public-key"}, settings)
    validate_public_request_auth({"x-api-key": "public-key"}, settings)


def test_public_request_auth_rejects_missing_or_invalid_key() -> None:
    settings = Settings(public_api_key="public-key")

    with pytest.raises(PublicRouteError) as missing_error:
        validate_public_request_auth({}, settings)
    assert missing_error.value.status_code == 401
    assert missing_error.value.machine_code == GATEWAY_PUBLIC_AUTH_INVALID

    with pytest.raises(PublicRouteError) as invalid_error:
        validate_public_request_auth({"authorization": "Bearer wrong-key"}, settings)
    assert invalid_error.value.status_code == 401
    assert invalid_error.value.machine_code == GATEWAY_PUBLIC_AUTH_INVALID


def test_resolve_public_route_uses_direct_openai_auth_in_gateway_only() -> None:
    settings = Settings(
        runtime_profile="gateway-only",
        openai_upstream_base_url="http://openai.test/v1",
        openai_upstream_auth_token="openai-direct-token",
        allow_insecure_upstreams=True,
        allow_nonstandard_upstream_hosts=True,
    )

    route = resolve_public_route(
        settings,
        provider="openai",
        upstream_path=OPENAI_CHAT_COMPLETIONS.upstream_path,
    )

    assert route.upstream_url == "http://openai.test/v1/chat/completions"
    assert route.injected_auth_headers == {"Authorization": "Bearer openai-direct-token"}


def test_resolve_public_route_uses_backplane_auth_in_backplane_profile() -> None:
    settings = Settings(
        runtime_profile="gateway+CLIProxyAPI",
        anthropic_upstream_base_url="http://cliproxyapi.internal",
        backplane_auth_token="backplane-token",
        allow_insecure_upstreams=True,
        allow_nonstandard_upstream_hosts=True,
    )

    route = resolve_public_route(
        settings,
        provider="anthropic",
        upstream_path=ANTHROPIC_MESSAGES.upstream_path,
    )

    assert route.upstream_url == "http://cliproxyapi.internal/v1/messages"
    assert route.injected_auth_headers == {"Authorization": "Bearer backplane-token"}


def test_resolve_public_route_treats_public_provider_defaults_as_unconfigured_in_backplane_profile() -> None:
    settings = Settings(
        runtime_profile="gateway+CLIProxyAPI",
        backplane_auth_token="backplane-token",
    )

    with pytest.raises(PublicRouteError) as error:
        resolve_public_route(
            settings,
            provider="openai",
            upstream_path=OPENAI_CHAT_COMPLETIONS.upstream_path,
        )

    assert error.value.status_code == 503
    assert error.value.machine_code == GATEWAY_OPENAI_UPSTREAM_UNCONFIGURED


def test_resolve_public_route_rejects_unconfigured_family_with_gateway_owned_machine_codes() -> None:
    openai_settings = Settings(runtime_profile="gateway-only")
    with pytest.raises(PublicRouteError) as openai_error:
        resolve_public_route(
            openai_settings,
            provider="openai",
            upstream_path=OPENAI_CHAT_COMPLETIONS.upstream_path,
        )
    assert openai_error.value.status_code == 503
    assert openai_error.value.machine_code == GATEWAY_OPENAI_UPSTREAM_UNCONFIGURED

    anthropic_settings = Settings(runtime_profile="gateway-only")
    with pytest.raises(PublicRouteError) as anthropic_error:
        resolve_public_route(
            anthropic_settings,
            provider="anthropic",
            upstream_path=ANTHROPIC_MESSAGES.upstream_path,
        )
    assert anthropic_error.value.status_code == 503
    assert anthropic_error.value.machine_code == GATEWAY_ANTHROPIC_UPSTREAM_UNCONFIGURED


def test_resolve_upstream_url_accepts_existing_v1_base() -> None:
    settings = Settings(
        runtime_profile="gateway-only",
        openai_upstream_base_url="http://openai.test/v1",
        allow_insecure_upstreams=True,
        allow_nonstandard_upstream_hosts=True,
    )

    assert resolve_upstream_url(settings, OPENAI_CHAT_COMPLETIONS) == (
        "http://openai.test/v1/chat/completions"
    )


def test_resolve_upstream_url_rejects_insecure_by_default() -> None:
    settings = Settings(
        runtime_profile="gateway-only",
        openai_upstream_base_url="http://openai.test",
    )

    with pytest.raises(ValueError):
        resolve_upstream_url(settings, OPENAI_CHAT_COMPLETIONS)


def test_resolve_upstream_url_rejects_nonstandard_host_by_default() -> None:
    settings = Settings(
        runtime_profile="gateway-only",
        openai_upstream_base_url="https://evil.example",
    )

    with pytest.raises(ValueError):
        resolve_upstream_url(settings, OPENAI_CHAT_COMPLETIONS)


def test_resolve_upstream_url_rejects_userinfo_tricks() -> None:
    settings = Settings(
        runtime_profile="gateway-only",
        openai_upstream_base_url="https://api.openai.com@evil.example",
        allow_nonstandard_upstream_hosts=True,
    )

    with pytest.raises(ValueError):
        resolve_upstream_url(settings, OPENAI_CHAT_COMPLETIONS)
