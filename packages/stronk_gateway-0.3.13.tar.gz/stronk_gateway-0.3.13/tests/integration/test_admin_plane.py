from __future__ import annotations

import asyncio
import json
from contextlib import contextmanager
from pathlib import Path

import httpx
from fastapi.testclient import TestClient

import stronk_gateway.admin.auth as admin_auth
from stronk_gateway.admin import AuditStore, hash_admin_password
from stronk_gateway.admin_app import create_app as create_admin_app
from stronk_gateway.app import build_runtime_apps
from stronk_gateway.config import Settings
from tests.helpers import RecordingTransport, build_bundle_root, build_test_client, eventually

DEBUG_GATEWAY_SECRET = "test-unsafe-debug-gateway-secret"
ADMIN_USER = "operator"
ADMIN_PASSWORD = "stronk-admin-password"
COOKIE_NAME = "stronk_admin_session"


def build_admin_settings(db_path: Path, **overrides: object) -> Settings:
    settings_kwargs: dict[str, object] = {
        "runtime_profile": "gateway-only",
        "public_api_key": "test-public-key",
        "openai_upstream_base_url": "http://openai.test",
        "openai_upstream_auth_token": "openai-direct-token",
        "anthropic_upstream_base_url": "http://anthropic.test",
        "anthropic_upstream_auth_token": "anthropic-direct-token",
        "allow_insecure_upstreams": True,
        "allow_nonstandard_upstream_hosts": True,
        "audit_storage_enabled": True,
        "audit_db_path": str(db_path),
        "enable_admin_api": True,
        "admin_auth_mode": "session",
        "admin_bootstrap_user": ADMIN_USER,
        "admin_bootstrap_password_hash": hash_admin_password(ADMIN_PASSWORD),
        "unsafe_debug_gateway_secret": DEBUG_GATEWAY_SECRET,
    }
    settings_kwargs.update(overrides)
    return Settings(**settings_kwargs)


def build_admin_client(
    db_path: Path,
    *,
    debug_bridge_transport: httpx.AsyncBaseTransport | None = None,
    base_url: str = "http://testserver",
    client: tuple[str, int] = ("testclient", 50000),
    headers: dict[str, str] | None = None,
    **overrides: object,
) -> TestClient:
    settings = build_admin_settings(db_path, **overrides)
    return TestClient(
        create_admin_app(settings=settings, debug_bridge_transport=debug_bridge_transport),
        base_url=base_url,
        client=client,
        headers=headers,
    )


def write_gateway_artifacts(
    root: Path,
    *,
    materialization: dict[str, object] | None = None,
    hermes: dict[str, object] | None = None,
    doctor: dict[str, object] | None = None,
) -> Path:
    generated_dir = root / "generated"
    generated_dir.mkdir()
    (generated_dir / "materialization-summary.json").write_text(
        json.dumps(
            materialization
            or {
                "schema_version": "stronk.gateway/v1",
                "generated_at": "2026-04-02T20:00:00Z",
                "providers": [
                    {
                        "readiness_posture": "ready",
                        "auth_source_type": "env",
                        "materialized_at": "2026-04-02T19:59:00Z",
                    }
                ],
                "models": [
                    {
                        "client_model": "stronk-lm",
                        "public_alias": "stronk-lm",
                        "backend_id": "openai-chat-first-slice",
                        "endpoint_id": "public-openai-chat",
                        "readiness_posture": "ready",
                        "fallback_note": "none",
                    }
                ],
                "endpoints": [
                    {
                        "client_model": "stronk-lm",
                        "public_alias": "stronk-lm",
                        "privacy_policy_id": "default-openai-chat",
                        "backend_linkage": "openai-chat-first-slice",
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    (generated_dir / "hermes-connect.json").write_text(
        json.dumps(
            hermes
            or {
                "schema_version": "stronk.gateway/v1",
                "public_base_url": "https://stronk.example.test/v1",
                "recommended_model_aliases": ["stronk-lm"],
                "recommended_models": ["stronk-lm"],
                "credential_flow": "cli_only",
                "copy_snippets": [
                    {
                        "label": "Hermes env",
                        "snippet": 'OPENAI_BASE_URL="https://stronk.example.test/v1"',
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    (generated_dir / "doctor-report.json").write_text(
        json.dumps(
            doctor
            or {
                "schema_version": "stronk.gateway/v1",
                "generated_at": "2026-04-02T20:01:00Z",
                "checks": [
                    {
                        "name": "cliproxy-private-surface",
                        "status": "pass",
                        "message": "CLIProxyAPI is private only.",
                        "evidence_ref": "docker-compose-config",
                    }
                ],
                "private_surface_posture": "private_only",
                "bundle_version": "2026.04.02",
                "image_pins": {
                    "stronk-gateway": "ghcr.io/eyycheev/stronk-gateway:2026.04.02",
                    "cliproxyapi": "ghcr.io/eyycheev/stronk-cliproxyapi:2026.04.02",
                },
            }
        ),
        encoding="utf-8",
    )
    return generated_dir


def login_admin(
    client: TestClient,
    *,
    username: str = ADMIN_USER,
    password: str = ADMIN_PASSWORD,
    origin: str = "http://testserver",
    extra_payload: dict[str, object] | None = None,
) -> httpx.Response:
    payload: dict[str, object] = {"username": username, "password": password}
    if extra_payload:
        payload.update(extra_payload)
    response = client.post(
        "/api/session/login",
        json=payload,
        headers={"Origin": origin},
    )
    assert response.status_code == 200
    return response


def trusted_proxy_headers(
    login: str,
    *,
    client_ip: str = "100.64.0.8",
    host: str = "admin.example.ts.net",
) -> dict[str, str]:
    return {
        "tailscale-user-login": login,
        "x-forwarded-for": client_ip,
        "x-forwarded-host": host,
        "x-forwarded-proto": "https",
    }


@contextmanager
def build_admin_and_runtime_clients(
    db_path: Path,
    handler,
    **overrides: object,
):
    settings = build_admin_settings(
        db_path,
        enable_unsafe_debug_view=True,
        admin_trace_allowed_roles="admin,operator",
        **overrides,
    )
    transport = RecordingTransport(handler)
    runtime = build_runtime_apps(settings=settings, upstream_transport=transport)
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(runtime.proxy_service.startup())
    debug_transport = httpx.ASGITransport(
        app=runtime.debug_app,
        client=("127.0.0.1", 8791),
    )
    try:
        with (
            TestClient(runtime.public_app) as public_client,
            TestClient(
                create_admin_app(
                    settings=settings,
                    debug_bridge_transport=debug_transport,
                )
            ) as admin_client,
        ):
            if settings.public_api_key:
                public_client.headers["Authorization"] = f"Bearer {settings.public_api_key}"
            yield public_client, admin_client, settings, transport
    finally:
        loop.run_until_complete(runtime.proxy_service.shutdown())
        asyncio.set_event_loop(None)
        loop.close()


@contextmanager
def build_split_admin_and_runtime_clients(
    *,
    admin_settings: Settings,
    runtime_settings: Settings,
    handler,
    admin_base_url: str = "http://testserver",
    admin_client: tuple[str, int] = ("testclient", 50000),
    admin_headers: dict[str, str] | None = None,
):
    transport = RecordingTransport(handler)
    runtime = build_runtime_apps(settings=runtime_settings, upstream_transport=transport)
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(runtime.proxy_service.startup())
    debug_transport = httpx.ASGITransport(
        app=runtime.debug_app,
        client=("127.0.0.1", 8791),
    )
    try:
        with (
            TestClient(runtime.public_app) as public_client,
            TestClient(
                create_admin_app(
                    settings=admin_settings,
                    debug_bridge_transport=debug_transport,
                ),
                base_url=admin_base_url,
                client=admin_client,
                headers=admin_headers,
            ) as admin_app_client,
        ):
            if runtime_settings.public_api_key:
                public_client.headers["Authorization"] = (
                    f"Bearer {runtime_settings.public_api_key}"
                )
            yield public_client, admin_app_client, transport
    finally:
        loop.run_until_complete(runtime.proxy_service.shutdown())
        asyncio.set_event_loop(None)
        loop.close()


def test_admin_api_requires_session_login(tmp_path: Path) -> None:
    client = build_admin_client(tmp_path / "audit.sqlite3")

    unauthorized_session = client.get("/api/session")
    unauthorized_overview = client.get("/api/overview")
    failed_login = client.post(
        "/api/session/login",
        json={"username": ADMIN_USER, "password": "wrong-password"},
        headers={"Origin": "http://testserver"},
    )

    assert unauthorized_session.status_code == 401
    assert unauthorized_overview.status_code == 401
    assert failed_login.status_code == 401

    login_admin(client)
    session = client.get("/api/session")

    assert session.status_code == 200
    assert session.json()["viewer"]["user"] == ADMIN_USER
    assert session.json()["trace_access"] is True


def test_admin_api_reads_sanitized_proxy_events(tmp_path: Path) -> None:
    db_path = tmp_path / "audit.sqlite3"

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        masked_text = json.loads(body)["messages"][0]["content"]
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-1",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": masked_text},
                        "finish_reason": "stop",
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    proxy_client, _ = build_test_client(
        handler,
        audit_storage_enabled=True,
        audit_db_path=str(db_path),
    )
    original = "Please contact Alice Johnson at alice@example.com"

    proxy_response = proxy_client.post(
        "/v1/chat/completions",
        json={"model": "gpt-4.1", "messages": [{"role": "user", "content": original}]},
        headers={"Authorization": "Bearer upstream-token"},
    )

    assert proxy_response.status_code == 200

    admin_client = build_admin_client(db_path)
    login_admin(admin_client)
    overview = eventually(
        lambda: admin_client.get("/api/overview"),
        predicate=lambda response: (
            response.status_code == 200 and response.json()["total_requests"] == 1
        ),
    )
    events = eventually(
        lambda: admin_client.get("/api/events"),
        predicate=lambda response: response.status_code == 200 and bool(response.json()["items"]),
    )
    config = admin_client.get("/api/config")

    assert overview.status_code == 200
    assert overview.json()["total_requests"] == 1
    assert overview.json()["masked_requests"] == 1

    assert events.status_code == 200
    payload = events.json()["items"][0]
    assert payload["endpoint"] == "/v1/chat/completions"
    assert payload["masked_paths"] == ["/messages/#/content"]
    assert payload["actions"] == {"mask": 2}
    assert "Alice Johnson" not in events.text
    assert "alice@example.com" not in events.text
    assert "Authorization" not in events.text

    assert config.status_code == 200
    assert config.json()["upstreams"]["openai_host"] == "openai.test"
    assert config.json()["auth"]["viewer"]["user"] == ADMIN_USER
    assert config.json()["auth"]["auth_mode"] == "session"
    assert config.json()["control_plane"]["content_trace_enabled"] is False


def test_admin_api_config_hides_upstream_userinfo(tmp_path: Path) -> None:
    client = build_admin_client(
        tmp_path / "audit.sqlite3",
        openai_upstream_base_url="https://alice:super-secret@openai.test:8443/v1",
    )
    login_admin(client)

    response = client.get("/api/config")

    assert response.status_code == 200
    assert response.json()["upstreams"]["openai_host"] == "openai.test:8443"
    assert "alice" not in response.text
    assert "super-secret" not in response.text


def test_admin_api_aggregates_gateway_artifacts_without_leaking_extra_fields(
    tmp_path: Path,
) -> None:
    generated_dir = write_gateway_artifacts(
        tmp_path,
        materialization={
            "schema_version": "stronk.gateway/v1",
            "generated_at": "2026-04-02T20:00:00Z",
            "providers": [
                {
                    "label": "Provider A",
                    "readiness_posture": "ready",
                    "auth_source_type": "env",
                    "materialized_at": "2026-04-02T19:59:00Z",
                    "provider_secret_value": "top-secret-provider-key",
                }
            ],
            "models": [
                {
                    "client_model": "stronk-lm",
                    "public_alias": "stronk-lm",
                    "backend_id": "openai-chat-first-slice",
                    "endpoint_id": "public-openai-chat",
                    "readiness_posture": "ready",
                    "fallback_note": "none",
                    "raw_management_url": "http://cliproxyapi.internal/v0/management",
                }
            ],
            "endpoints": [
                {
                    "client_model": "stronk-lm",
                    "public_alias": "stronk-lm",
                    "privacy_policy_id": "default-openai-chat",
                    "backend_linkage": "openai-chat-first-slice",
                }
            ],
        },
        hermes={
            "schema_version": "stronk.gateway/v1",
            "public_base_url": "https://stronk.example.test/v1",
            "recommended_models": ["stronk-lm"],
            "credential_flow": "cli_only",
            "copy_snippets": {
                "Hermes env": 'OPENAI_BASE_URL="https://stronk.example.test/v1"',
            },
            "public_api_key_value": "should-not-leak",
        },
        doctor={
            "schema_version": "stronk.gateway/v1",
            "generated_at": "2026-04-02T20:01:00Z",
            "checks": [
                {
                    "name": "cliproxy-private-surface",
                    "status": "pass",
                    "message": "CLIProxyAPI is private only.",
                    "evidence_ref": "docker-compose-config",
                    "raw_socket_dump": "should-not-leak",
                }
            ],
            "private_surface_posture": "private_only",
            "bundle_version": "2026.04.02",
            "image_pins": {
                "stronk-gateway": "ghcr.io/eyycheev/stronk-gateway:2026.04.02",
            },
            "exposed_ports": ["8317:8317"],
        },
    )
    client = build_admin_client(
        tmp_path / "audit.sqlite3",
        admin_generated_artifacts_dir=str(generated_dir),
    )
    login_admin(client)

    overview = client.get("/api/overview")
    providers = client.get("/api/providers")
    models = client.get("/api/models")
    policy = client.get("/api/policy")
    access = client.get("/api/access")
    system = client.get("/api/system")

    assert overview.status_code == 200
    assert overview.json()["gateway"]["provider_summary"]["ready"] == 1
    assert overview.json()["gateway"]["hermes"]["public_base_url"] == "https://stronk.example.test/v1"

    assert providers.status_code == 200
    assert providers.json()["items"][0]["label"] == "Provider A"
    assert providers.json()["last_doctor_status"] == "pass"

    assert models.status_code == 200
    assert models.json()["items"][0]["recommended_for_hermes"] is True
    assert models.json()["items"][0]["client_model"] == "stronk-lm"

    assert policy.status_code == 200
    assert policy.json()["endpoint_posture"][0]["privacy_policy_id"] == "default-openai-chat"
    assert policy.json()["endpoint_posture"][0]["client_model"] == "stronk-lm"

    assert access.status_code == 200
    assert access.json()["mode"] == "loopback"
    assert access.json()["session_posture"]["csrf_same_origin_required"] is True

    assert system.status_code == 200
    assert system.json()["private_surface_posture"] == "private_only"
    assert system.json()["image_pins"]["stronk-gateway"] == "ghcr.io/eyycheev/stronk-gateway:2026.04.02"
    assert system.json()["topology"]["browser_admin_runtime"] == "stronk-gateway-admin"
    assert system.json()["topology"]["public_runtime"] == "stronk-gateway"
    assert system.json()["topology"]["browser_direct_cliproxyapi"] is False

    combined = (
        overview.text
        + providers.text
        + models.text
        + policy.text
        + access.text
        + system.text
    )
    assert "top-secret-provider-key" not in combined
    assert "should-not-leak" not in combined
    assert "http://cliproxyapi.internal/v0/management" not in combined


def test_admin_api_gateway_artifact_routes_degrade_when_files_are_missing(
    tmp_path: Path,
) -> None:
    generated_dir = tmp_path / "generated"
    generated_dir.mkdir()
    client = build_admin_client(
        tmp_path / "audit.sqlite3",
        admin_generated_artifacts_dir=str(generated_dir),
    )
    login_admin(client)

    overview = client.get("/api/overview")
    providers = client.get("/api/providers")
    models = client.get("/api/models")
    system = client.get("/api/system")

    assert overview.status_code == 200
    assert overview.json()["gateway"]["provider_summary"]["total"] == 0
    assert overview.json()["gateway"]["warnings"]

    assert providers.status_code == 200
    assert providers.json()["materialization_required"] is True
    assert providers.json()["items"] == []

    assert models.status_code == 200
    assert models.json()["materialization_required"] is True
    assert models.json()["items"] == []

    assert system.status_code == 200
    assert system.json()["check_status"] == "unknown"
    assert system.json()["warnings"]


def test_admin_api_read_only_posture_routes_do_not_depend_on_operator_state_files(
    tmp_path: Path,
) -> None:
    artifacts_root = tmp_path / "artifacts-root"
    artifacts_root.mkdir()
    generated_dir = write_gateway_artifacts(
        artifacts_root,
        materialization={
            "schema_version": "stronk.gateway/v1",
            "generated_at": "2026-04-02T20:00:00Z",
            "providers": [
                {
                    "label": "Provider A",
                    "readiness_posture": "ready",
                    "auth_source_type": "env",
                    "materialized_at": "2026-04-02T19:59:00Z",
                }
            ],
            "models": [
                {
                    "client_model": "gpt-4.1-mini",
                    "backend_id": "openai-direct",
                    "endpoint_id": "public-openai-chat",
                    "readiness_posture": "ready",
                    "fallback_note": None,
                }
            ],
            "endpoints": [
                {
                    "client_model": "gpt-4.1-mini",
                    "privacy_policy_id": "default-openai-chat",
                    "backend_linkage": "openai-direct",
                }
            ],
        },
        hermes={
            "schema_version": "stronk.gateway/v1",
            "public_base_url": "https://gateway.example.test/v1",
            "recommended_models": ["gpt-4.1-mini"],
            "credential_flow": "cli_only",
            "copy_snippets": [],
        },
        doctor={
            "schema_version": "stronk.gateway/v1",
            "generated_at": "2026-04-02T20:01:00Z",
            "checks": [
                {
                    "name": "cliproxy-private-surface",
                    "status": "pass",
                    "message": "CLIProxyAPI is private only.",
                    "evidence_ref": "docker-compose-config",
                }
            ],
            "private_surface_posture": "private_only",
            "bundle_version": "2026.04.02",
            "image_pins": {
                "stronk-gateway": "ghcr.io/eyycheev/stronk-gateway:2026.04.02",
            },
        },
    )
    bundle_root = tmp_path / "bundle"
    build_bundle_root(bundle_root)
    (bundle_root / "config" / "operator-objects.json").unlink(missing_ok=True)
    draft_path = bundle_root / "config" / "operator-objects.draft.json"
    if draft_path.exists():
        draft_path.unlink()
    client = build_admin_client(
        tmp_path / "audit.sqlite3",
        admin_config_dir=str(bundle_root / "config"),
        admin_generated_artifacts_dir=str(generated_dir),
    )
    login_admin(client)

    overview = client.get("/api/overview")
    providers = client.get("/api/providers")
    models = client.get("/api/models")
    policy = client.get("/api/policy")
    access = client.get("/api/access")
    system = client.get("/api/system")
    retired = client.get("/api/operator-state")

    assert overview.status_code == 200
    assert providers.status_code == 200
    assert providers.json()["items"][0]["label"] == "Provider A"
    assert models.status_code == 200
    assert models.json()["items"][0]["client_model"] == "gpt-4.1-mini"
    assert policy.status_code == 200
    assert access.status_code == 200
    assert system.status_code == 200
    assert system.json()["private_surface_posture"] == "private_only"
    assert retired.status_code == 410


def test_admin_api_access_counts_all_enrollments_not_just_recent_window(
    tmp_path: Path,
    monkeypatch,
) -> None:
    db_path = tmp_path / "audit.sqlite3"
    monkeypatch.setattr(
        admin_auth,
        "_tailscale_whois_login",
        lambda client_ip, settings: "user-00@example.ts.net",
    )
    client = build_admin_client(
        db_path,
        base_url="https://admin.example.ts.net",
        client=("127.0.0.1", 50004),
        headers=trusted_proxy_headers(
            "user-00@example.ts.net",
            client_ip="100.64.0.10",
        ),
        admin_access_mode="tailscale-serve",
        admin_allowed_origins="https://admin.example.ts.net",
        admin_trusted_proxy_mode="tailscale",
        admin_enrollment_required=True,
        admin_session_secure_cookies=True,
    )
    seeded_store = AuditStore(str(db_path))

    for index in range(15):
        device_id = f"device-{index:02d}"
        tailscale_login = f"user-{index:02d}@example.ts.net"
        browser_public_key = f"pubkey-{index:02d}"
        seeded_store.upsert_enrollment_request(
            device_id=device_id,
            tailscale_login=tailscale_login,
            browser_public_key=browser_public_key,
            last_seen_at=f"2026-04-02T20:{index:02d}:00Z",
        )
        if index < 6:
            seeded_store.approve_enrollment(
                device_id=device_id,
                approved_role="admin" if index == 0 else "operator",
                approved_at=f"2026-04-02T21:{index:02d}:00Z",
            )
        elif index < 10:
            seeded_store.approve_enrollment(
                device_id=device_id,
                approved_role="auditor",
                approved_at=f"2026-04-02T21:{index:02d}:00Z",
            )
            seeded_store.revoke_enrollment(
                device_id=device_id,
                revoked_at=f"2026-04-02T22:{index:02d}:00Z",
            )

    login_admin(
        client,
        origin="https://admin.example.ts.net",
        extra_payload={
            "device_id": "device-00",
            "browser_public_key": "pubkey-00",
        },
    )
    access = client.get("/api/access")

    assert access.status_code == 200
    assert access.json()["enrollment"]["approved"] == 6
    assert access.json()["enrollment"]["pending"] == 5
    assert access.json()["enrollment"]["revoked"] == 4
    assert len(access.json()["enrollment"]["recent"]) == 12


def test_admin_api_surfaces_upstream_rejection_without_raw_leaks(tmp_path: Path) -> None:
    db_path = tmp_path / "audit.sqlite3"

    proxy_client, _ = build_test_client(
        lambda request, body: httpx.Response(
            429,
            json={"error": {"message": "rate limited"}},
            headers={"content-type": "application/json"},
        ),
        audit_storage_enabled=True,
        audit_db_path=str(db_path),
    )

    response = proxy_client.post(
        "/v1/chat/completions",
        json={
            "model": "gpt-4.1",
            "messages": [{"role": "user", "content": "Alice Johnson alice@example.com"}],
        },
        headers={"Authorization": "Bearer upstream-token"},
    )

    assert response.status_code == 429

    admin_client = build_admin_client(db_path)
    login_admin(admin_client)
    events = eventually(
        lambda: admin_client.get("/api/events"),
        predicate=lambda result: result.status_code == 200 and bool(result.json()["items"]),
    )

    assert events.status_code == 200
    payload = events.json()["items"][0]
    assert payload["outcome"] == "upstream_rejection"
    assert payload["masked_paths"] == ["/messages/#/content"]
    assert "Alice Johnson" not in events.text
    assert "alice@example.com" not in events.text


def test_admin_ui_serves_index_when_built_without_login(tmp_path: Path) -> None:
    ui_dir = tmp_path / "ui"
    ui_dir.mkdir()
    index = ui_dir / "index.html"
    index.write_text("<!doctype html><html><body>control plane</body></html>", encoding="utf-8")

    client = build_admin_client(
        tmp_path / "audit.sqlite3",
        enable_admin_ui=True,
        admin_ui_dir=str(ui_dir),
    )

    assert client.app.title == "Stronk Gateway Admin"
    response = client.get("/")

    assert response.status_code == 200
    assert "control plane" in response.text


def test_admin_ui_serves_index_for_route_based_console_paths(tmp_path: Path) -> None:
    ui_dir = tmp_path / "ui-routes"
    ui_dir.mkdir()
    index = ui_dir / "index.html"
    index.write_text("<!doctype html><html><body>route control plane</body></html>", encoding="utf-8")

    client = build_admin_client(
        tmp_path / "audit.sqlite3",
        enable_admin_ui=True,
        admin_ui_dir=str(ui_dir),
    )

    response = client.get("/providers")

    assert response.status_code == 200
    assert "route control plane" in response.text


def test_admin_ui_serves_index_when_ui_dir_is_relative(tmp_path: Path, monkeypatch) -> None:
    ui_dir = tmp_path / "ui-relative"
    ui_dir.mkdir()
    index = ui_dir / "index.html"
    index.write_text(
        "<!doctype html><html><body>relative control plane</body></html>",
        encoding="utf-8",
    )

    monkeypatch.chdir(tmp_path)
    client = build_admin_client(
        tmp_path / "audit.sqlite3",
        enable_admin_ui=True,
        admin_ui_dir="ui-relative",
    )

    response = client.get("/")

    assert response.status_code == 200
    assert "relative control plane" in response.text


def test_admin_api_config_surfaces_content_trace_warning(tmp_path: Path) -> None:
    client = build_admin_client(
        tmp_path / "audit.sqlite3",
        enable_unsafe_debug_view=True,
    )
    login_admin(client)

    response = client.get("/api/config")

    assert response.status_code == 200
    assert response.json()["control_plane"]["content_trace_enabled"] is True
    assert any(
        "Content trace monitoring is enabled." in warning
        for warning in response.json()["warnings"]
    )


def test_admin_login_rate_limit_is_keyed_by_ip_and_username(tmp_path: Path) -> None:
    client = build_admin_client(tmp_path / "audit.sqlite3")

    for _ in range(5):
        response = client.post(
            "/api/session/login",
            json={"username": ADMIN_USER, "password": "wrong-password"},
            headers={"Origin": "http://testserver"},
        )
        assert response.status_code == 401

    different_user = client.post(
        "/api/session/login",
        json={"username": "auditor", "password": "wrong-password"},
        headers={"Origin": "http://testserver"},
    )
    limited = client.post(
        "/api/session/login",
        json={"username": ADMIN_USER, "password": "wrong-password"},
        headers={"Origin": "http://testserver"},
    )

    assert different_user.status_code == 401
    assert limited.status_code == 429


def test_admin_login_sets_loopback_cookie_flags_and_rotates_previous_session(
    tmp_path: Path,
) -> None:
    client = build_admin_client(tmp_path / "audit.sqlite3")

    first = login_admin(client)
    first_cookie = first.cookies.get(COOKIE_NAME)
    assert first_cookie is not None
    assert "HttpOnly" in first.headers["set-cookie"]
    assert "SameSite=strict" in first.headers["set-cookie"]
    assert "Secure" not in first.headers["set-cookie"]

    second = login_admin(client)
    second_cookie = second.cookies.get(COOKIE_NAME)
    assert second_cookie is not None
    assert second_cookie != first_cookie

    stale = client.get("/api/session", cookies={COOKIE_NAME: first_cookie})
    current = client.get("/api/session")

    assert stale.status_code == 401
    assert current.status_code == 200


def test_ssh_forward_mode_uses_loopback_cookie_policy(tmp_path: Path) -> None:
    client = build_admin_client(
        tmp_path / "audit.sqlite3",
        admin_access_mode="ssh-forward",
    )

    response = login_admin(client)
    session = client.get("/api/session")

    assert response.status_code == 200
    assert "HttpOnly" in response.headers["set-cookie"]
    assert "SameSite=strict" in response.headers["set-cookie"]
    assert "Secure" not in response.headers["set-cookie"]
    assert session.status_code == 200
    assert session.json()["access_mode"] == "ssh-forward"


def test_ssh_forward_trace_proxy_accepts_shared_loopback_session_binding(
    tmp_path: Path,
) -> None:
    db_path = tmp_path / "audit.sqlite3"

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["messages"][0]["content"]
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-ssh-forward",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": f"Echo: {masked_text}"},
                        "finish_reason": "stop",
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    with build_admin_and_runtime_clients(
        db_path,
        handler,
        admin_access_mode="ssh-forward",
    ) as (public_client, admin_client, _, _):
        proxy_response = public_client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4.1",
                "messages": [{"role": "user", "content": "ssh-forward trace probe"}],
            },
        )
        assert proxy_response.status_code == 200

        login_admin(admin_client)
        traces = eventually(
            lambda: admin_client.get("/api/debug/traces"),
            predicate=lambda result: result.status_code == 200 and bool(result.json()["items"]),
        )

        assert traces.status_code == 200


def test_ssh_forward_trace_proxy_uses_authenticated_bridge_headers(
    tmp_path: Path,
) -> None:
    db_path = tmp_path / "audit.sqlite3"

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["messages"][0]["content"]
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-ssh-forward-bridge",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": f"Echo: {masked_text}"},
                        "finish_reason": "stop",
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    bridge_secret = "test-admin-proxy-secret"
    admin_settings = build_admin_settings(
        db_path,
        enable_unsafe_debug_view=True,
        admin_trace_allowed_roles="admin,operator",
        admin_access_mode="ssh-forward",
        admin_proxy_secret=bridge_secret,
    )
    runtime_settings = build_admin_settings(
        db_path,
        enable_unsafe_debug_view=True,
        admin_trace_allowed_roles="admin,operator",
        admin_auth_mode="trusted_headers",
        admin_proxy_secret=bridge_secret,
    )

    with build_split_admin_and_runtime_clients(
        admin_settings=admin_settings,
        runtime_settings=runtime_settings,
        handler=handler,
    ) as (public_client, admin_client, _):
        proxy_response = public_client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4.1",
                "messages": [{"role": "user", "content": "ssh-forward header bridge probe"}],
            },
        )
        assert proxy_response.status_code == 200

        login_admin(admin_client)
        traces = eventually(
            lambda: admin_client.get("/api/debug/traces"),
            predicate=lambda result: result.status_code == 200 and bool(result.json()["items"]),
        )

        assert traces.status_code == 200


def test_tailscale_trace_proxy_uses_authenticated_bridge_headers(
    tmp_path: Path,
    monkeypatch,
) -> None:
    db_path = tmp_path / "audit.sqlite3"
    monkeypatch.setattr(
        admin_auth,
        "_tailscale_whois_login",
        lambda client_ip, settings: "admin@example.com",
    )

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["messages"][0]["content"]
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-tailscale",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": f"Echo: {masked_text}"},
                        "finish_reason": "stop",
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    bridge_secret = "test-admin-proxy-secret"
    seeded_store = AuditStore(str(db_path))
    seeded_store.upsert_enrollment_request(
        device_id="device-admin",
        tailscale_login="admin@example.com",
        browser_public_key="browser-key-admin",
        last_seen_at="2026-03-30T22:15:00Z",
    )
    seeded_store.approve_enrollment(
        device_id="device-admin",
        approved_role="admin",
        approved_at="2026-03-30T22:16:00Z",
    )

    admin_settings = build_admin_settings(
        db_path,
        enable_unsafe_debug_view=True,
        admin_trace_allowed_roles="admin,operator",
        admin_access_mode="tailscale-serve",
        admin_allowed_origins="https://admin.example.ts.net",
        admin_trusted_proxy_mode="tailscale",
        admin_enrollment_required=True,
        admin_session_secure_cookies=True,
        admin_proxy_secret=bridge_secret,
    )
    runtime_settings = build_admin_settings(
        db_path,
        enable_unsafe_debug_view=True,
        admin_trace_allowed_roles="admin,operator",
        admin_auth_mode="trusted_headers",
        admin_proxy_secret=bridge_secret,
    )

    with build_split_admin_and_runtime_clients(
        admin_settings=admin_settings,
        runtime_settings=runtime_settings,
        handler=handler,
        admin_base_url="https://admin.example.ts.net",
        admin_client=("127.0.0.1", 50003),
        admin_headers=trusted_proxy_headers(
            "admin@example.com",
            client_ip="100.64.0.10",
        ),
    ) as (public_client, admin_client, _):
        proxy_response = public_client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4.1",
                "messages": [{"role": "user", "content": "tailscale bridge trace probe"}],
            },
        )
        assert proxy_response.status_code == 200

        login = login_admin(
            admin_client,
            origin="https://admin.example.ts.net",
            extra_payload={
                "device_id": "device-admin",
                "browser_public_key": "browser-key-admin",
            },
        )
        assert "Secure" in login.headers["set-cookie"]

        traces = eventually(
            lambda: admin_client.get("/api/debug/traces"),
            predicate=lambda result: result.status_code == 200 and bool(result.json()["items"]),
        )
        request_id = traces.json()["items"][0]["request_id"]
        detail = admin_client.get(f"/api/debug/traces/{request_id}")

        assert traces.status_code == 200
        assert detail.status_code == 200


def test_tailscale_auditor_login_succeeds_but_raw_traces_remain_forbidden(
    tmp_path: Path,
    monkeypatch,
) -> None:
    db_path = tmp_path / "audit.sqlite3"
    monkeypatch.setattr(
        admin_auth,
        "_tailscale_whois_login",
        lambda client_ip, settings: "admin@example.com",
    )

    seeded_store = AuditStore(str(db_path))
    seeded_store.upsert_enrollment_request(
        device_id="device-auditor",
        tailscale_login="admin@example.com",
        browser_public_key="browser-key-auditor",
        last_seen_at="2026-03-30T22:17:00Z",
    )
    seeded_store.approve_enrollment(
        device_id="device-auditor",
        approved_role="auditor",
        approved_at="2026-03-30T22:18:00Z",
    )

    client = build_admin_client(
        db_path,
        base_url="https://admin.example.ts.net",
        client=("127.0.0.1", 50004),
        headers=trusted_proxy_headers(
            "admin@example.com",
            client_ip="100.64.0.10",
        ),
        admin_access_mode="tailscale-serve",
        admin_allowed_origins="https://admin.example.ts.net",
        admin_trusted_proxy_mode="tailscale",
        admin_enrollment_required=True,
        admin_session_secure_cookies=True,
    )

    login = login_admin(
        client,
        origin="https://admin.example.ts.net",
        extra_payload={
            "device_id": "device-auditor",
            "browser_public_key": "browser-key-auditor",
        },
    )
    session = client.get("/api/session")
    traces = client.get("/api/debug/traces")

    assert "Secure" in login.headers["set-cookie"]
    assert session.status_code == 200
    assert session.json()["viewer"]["roles"] == ["auditor"]
    assert session.json()["trace_access"] is False
    assert traces.status_code == 403


def test_admin_logout_invalidates_previous_session(tmp_path: Path) -> None:
    client = build_admin_client(tmp_path / "audit.sqlite3")
    login_admin(client)
    session_cookie = client.cookies.get(COOKIE_NAME)
    assert session_cookie is not None

    logout = client.post("/api/session/logout", headers={"Origin": "http://testserver"})
    stale = client.get("/api/session", cookies={COOKIE_NAME: session_cookie})

    assert logout.status_code == 204
    assert stale.status_code == 401


def test_password_hash_change_invalidates_existing_session(tmp_path: Path) -> None:
    db_path = tmp_path / "audit.sqlite3"
    client = build_admin_client(db_path)
    login_admin(client)
    session_cookie = client.cookies.get(COOKIE_NAME)
    assert session_cookie is not None

    rotated_client = build_admin_client(
        db_path,
        admin_bootstrap_password_hash=hash_admin_password("new-admin-password"),
    )
    stale = rotated_client.get("/api/session", cookies={COOKIE_NAME: session_cookie})
    fresh = rotated_client.post(
        "/api/session/login",
        json={"username": ADMIN_USER, "password": "new-admin-password"},
        headers={"Origin": "http://testserver"},
    )

    assert stale.status_code == 401
    assert fresh.status_code == 200


def test_cross_origin_admin_state_change_is_rejected(tmp_path: Path) -> None:
    client = build_admin_client(tmp_path / "audit.sqlite3")

    response = client.post(
        "/api/session/login",
        json={"username": ADMIN_USER, "password": ADMIN_PASSWORD},
        headers={"Origin": "http://evil.example"},
    )

    assert response.status_code == 403


def test_admin_trace_proxy_exposes_raw_content_only_through_authenticated_admin_lane(
    tmp_path: Path,
) -> None:
    db_path = tmp_path / "audit.sqlite3"

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["messages"][0]["content"]
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-1",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": f"Echo: {masked_text}"},
                        "finish_reason": "stop",
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    original = "<svg onload=alert(1)> Alice alice@example.com"

    with build_admin_and_runtime_clients(db_path, handler) as (public_client, admin_client, _, _):
        proxy_response = public_client.post(
            "/v1/chat/completions",
            json={"model": "gpt-4.1", "messages": [{"role": "user", "content": original}]},
        )
        assert proxy_response.status_code == 200

        login_admin(admin_client)
        traces = eventually(
            lambda: admin_client.get("/api/debug/traces"),
            predicate=lambda result: result.status_code == 200 and bool(result.json()["items"]),
        )
        request_id = traces.json()["items"][0]["request_id"]
        detail = admin_client.get(f"/api/debug/traces/{request_id}")

        assert detail.status_code == 200
        assert detail.headers["content-security-policy"].startswith("default-src 'self'")
        assert detail.headers["x-content-type-options"] == "nosniff"
        payload = detail.json()
        assert payload["request_original"]["messages"][0]["content"] == original
        assert "<svg onload=alert(1)>" in payload["request_original"]["messages"][0]["content"]
        assert original.encode("utf-8") not in db_path.read_bytes()


def test_auditor_cannot_access_raw_trace_proxy(tmp_path: Path) -> None:
    db_path = tmp_path / "audit.sqlite3"

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["messages"][0]["content"]
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-1",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": masked_text},
                        "finish_reason": "stop",
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    with build_admin_and_runtime_clients(
        db_path,
        handler,
        admin_bootstrap_roles="auditor",
    ) as (public_client, admin_client, _, _):
        proxy_response = public_client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4.1",
                "messages": [{"role": "user", "content": "alice@example.com"}],
            },
        )
        assert proxy_response.status_code == 200

        login_admin(admin_client)
        session = admin_client.get("/api/session")
        traces = admin_client.get("/api/debug/traces")

        assert session.status_code == 200
        assert session.json()["trace_access"] is False
        assert traces.status_code == 403


def test_tailscale_serve_requires_origin_for_state_changes(
    tmp_path: Path,
    monkeypatch,
) -> None:
    db_path = tmp_path / "audit.sqlite3"
    monkeypatch.setattr(
        admin_auth,
        "_tailscale_whois_login",
        lambda client_ip, settings: "alice@example.com",
    )
    client = build_admin_client(
        db_path,
        base_url="https://admin.example.ts.net",
        client=("127.0.0.1", 50000),
        headers=trusted_proxy_headers("alice@example.com"),
        admin_access_mode="tailscale-serve",
        admin_allowed_origins="https://admin.example.ts.net",
        admin_trusted_proxy_mode="tailscale",
        admin_enrollment_required=True,
        admin_session_secure_cookies=True,
    )

    response = client.post(
        "/api/enrollment/request",
        json={
            "username": ADMIN_USER,
            "password": ADMIN_PASSWORD,
            "device_id": "device-alice",
            "browser_public_key": "browser-key-alice",
        },
    )

    assert response.status_code == 403


def test_tailscale_enrollment_flow_requires_approval_and_revokes_active_sessions(
    tmp_path: Path,
    monkeypatch,
) -> None:
    db_path = tmp_path / "audit.sqlite3"
    whois_map = {
        "100.64.0.10": "admin@example.com",
        "100.64.0.20": "operator@example.com",
    }
    monkeypatch.setattr(
        admin_auth,
        "_tailscale_whois_login",
        lambda client_ip, settings: whois_map[client_ip],
    )

    seeded_store = AuditStore(str(db_path))
    seeded_store.upsert_enrollment_request(
        device_id="device-admin",
        tailscale_login="admin@example.com",
        browser_public_key="browser-key-admin",
        last_seen_at="2026-03-30T20:00:00Z",
    )
    seeded_store.approve_enrollment(
        device_id="device-admin",
        approved_role="admin",
        approved_at="2026-03-30T20:01:00Z",
    )

    common_overrides = {
        "admin_access_mode": "tailscale-serve",
        "admin_allowed_origins": "https://admin.example.ts.net",
        "admin_trusted_proxy_mode": "tailscale",
        "admin_enrollment_required": True,
        "admin_session_secure_cookies": True,
    }

    admin_client = build_admin_client(
        db_path,
        base_url="https://admin.example.ts.net",
        client=("127.0.0.1", 50001),
        headers=trusted_proxy_headers(
            "admin@example.com",
            client_ip="100.64.0.10",
        ),
        **common_overrides,
    )
    operator_client = build_admin_client(
        db_path,
        base_url="https://admin.example.ts.net",
        client=("127.0.0.1", 50002),
        headers=trusted_proxy_headers(
            "operator@example.com",
            client_ip="100.64.0.20",
        ),
        **common_overrides,
    )

    admin_login = login_admin(
        admin_client,
        origin="https://admin.example.ts.net",
        extra_payload={
            "device_id": "device-admin",
            "browser_public_key": "browser-key-admin",
        },
    )
    assert "HttpOnly" in admin_login.headers["set-cookie"]
    assert "SameSite=strict" in admin_login.headers["set-cookie"]
    assert "Secure" in admin_login.headers["set-cookie"]

    denied_login = operator_client.post(
        "/api/session/login",
        json={
            "username": ADMIN_USER,
            "password": ADMIN_PASSWORD,
            "device_id": "device-operator",
            "browser_public_key": "browser-key-operator",
        },
        headers={"Origin": "https://admin.example.ts.net"},
    )
    requested = operator_client.post(
        "/api/enrollment/request",
        json={
            "username": ADMIN_USER,
            "password": ADMIN_PASSWORD,
            "device_id": "device-operator",
            "browser_public_key": "browser-key-operator",
        },
        headers={"Origin": "https://admin.example.ts.net"},
    )
    approved = admin_client.post(
        "/api/enrollments/device-operator/approve",
        json={"role": "operator"},
        headers={"Origin": "https://admin.example.ts.net"},
    )
    operator_login = login_admin(
        operator_client,
        origin="https://admin.example.ts.net",
        extra_payload={
            "device_id": "device-operator",
            "browser_public_key": "browser-key-operator",
        },
    )
    operator_cookie = operator_login.cookies.get(COOKIE_NAME)
    assert operator_cookie is not None

    session_before_revoke = operator_client.get("/api/session")
    revoked = admin_client.post(
        "/api/enrollments/device-operator/revoke",
        headers={"Origin": "https://admin.example.ts.net"},
    )
    session_after_revoke = operator_client.get(
        "/api/session",
        cookies={COOKIE_NAME: operator_cookie},
    )
    relogin_after_revoke = operator_client.post(
        "/api/session/login",
        json={
            "username": ADMIN_USER,
            "password": ADMIN_PASSWORD,
            "device_id": "device-operator",
            "browser_public_key": "browser-key-operator",
        },
        headers={"Origin": "https://admin.example.ts.net"},
    )

    assert denied_login.status_code == 403
    assert denied_login.json()["error"]["code"] == "admin_enrollment_required"
    assert requested.status_code == 202
    assert approved.status_code == 200
    assert operator_login.status_code == 200
    assert session_before_revoke.status_code == 200
    assert session_before_revoke.json()["viewer"]["user"] == "operator@example.com"
    assert revoked.status_code == 200
    assert session_after_revoke.status_code == 401
    assert relogin_after_revoke.status_code == 403
