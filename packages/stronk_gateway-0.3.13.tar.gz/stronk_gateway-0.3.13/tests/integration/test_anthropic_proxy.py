from __future__ import annotations

import json

import httpx

from tests.helpers import (
    ANTHROPIC_DIRECT_TEST_API_KEY,
    StaticAsyncByteStream,
    build_test_client,
    contains_placeholder,
)


def test_anthropic_messages_masks_upstream_and_rehydrates_response() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_system = payload["system"]
        masked_text = payload["messages"][0]["content"]
        return httpx.Response(
            200,
            json={
                "id": "msg_1",
                "type": "message",
                "role": "assistant",
                "content": [{"type": "text", "text": f"{masked_system} {masked_text}"}],
            },
            headers={"content-type": "application/json"},
        )

    client, transport = build_test_client(handler)
    system_text = "客户地址：上海市浦东新区世纪大道100号"
    user_text = "请联系北京字节科技公司负责人张三"

    response = client.post(
        "/anthropic/v1/messages",
        json={
            "model": "claude-3-7-sonnet",
            "system": system_text,
            "messages": [{"role": "user", "content": user_text}],
        },
        headers={"X-API-Key": "anthropic-upstream-key", "anthropic-version": "2023-06-01"},
    )

    assert response.status_code == 200
    body = transport.requests[0]["body"].decode("utf-8")
    assert "上海市浦东新区世纪大道100号" not in body
    assert "北京字节科技公司" not in body
    assert "张三" not in body
    upstream_headers = {key.lower(): value for key, value in transport.requests[0]["headers"].items()}
    assert upstream_headers["x-api-key"] == ANTHROPIC_DIRECT_TEST_API_KEY
    assert "authorization" not in upstream_headers
    assert response.json()["content"][0]["text"] == f"{system_text} {user_text}"


def test_anthropic_messages_returns_gateway_owned_503_when_family_is_unconfigured() -> None:
    client, transport = build_test_client(
        lambda request, body: httpx.Response(200, json={"unexpected": True}),
        anthropic_upstream_auth_token=None,
    )

    response = client.post(
        "/anthropic/v1/messages",
        json={
            "model": "claude-3-7-sonnet",
            "messages": [{"role": "user", "content": "hello"}],
        },
        headers={"anthropic-version": "2023-06-01"},
    )

    assert response.status_code == 503
    assert response.json()["error"]["type"] == "gateway_anthropic_upstream_unconfigured"
    assert transport.requests == []


def test_anthropic_streaming_rehydrates_split_placeholders() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["messages"][0]["content"]
        half = len(masked_text) // 2
        chunks = [
            b"event: content_block_delta\n",
            (
                "data: "
                + json.dumps(
                    {"type": "content_block_delta", "delta": {"text": masked_text[:half]}},
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            (
                "event: content_block_delta\n"
                + "data: "
                + json.dumps(
                    {
                        "type": "content_block_delta",
                        "delta": {"text": f"{masked_text[half:]} done"},
                    },
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
        ]
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(chunks),
        )

    client, transport = build_test_client(handler)
    original = "请联系张三，邮箱是 zhangsan@example.com"

    response = client.post(
        "/anthropic/v1/messages",
        json={
            "model": "claude-3-7-sonnet",
            "stream": True,
            "messages": [{"role": "user", "content": original}],
        },
        headers={"X-API-Key": "anthropic-upstream-key", "anthropic-version": "2023-06-01"},
    )

    delta_text = "".join(
        json.loads(line.removeprefix("data: "))["delta"]["text"]
        for line in response.iter_lines()
        if line.startswith("data: {")
    )
    assert _response_request_headers(transport).get("x-api-key") == ANTHROPIC_DIRECT_TEST_API_KEY
    assert delta_text == f"{original} done"
    assert not contains_placeholder(delta_text)


def _response_request_headers(transport) -> dict[str, str]:
    return {key.lower(): value for key, value in transport.requests[0]["headers"].items()}
