from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from tests.helpers import build_admin_client, build_bundle_root, login_admin


def snapshot_bundle(bundle_root: Path) -> dict[str, str]:
    return {
        str(path.relative_to(bundle_root)): path.read_text(encoding="utf-8")
        for path in sorted(bundle_root.rglob("*"))
        if path.is_file()
    }


def assert_retired(response, *, code: str) -> None:
    assert response.status_code == 410
    assert response.json() == {
        "error": {
            "message": "Gateway-owned provider/model setup has been retired. Use the deploy/materialization workflow instead.",
            "type": "admin_validation_error",
            "code": code,
        }
    }


def test_provider_and_model_write_routes_return_410_and_leave_bundle_untouched(
    tmp_path: Path,
) -> None:
    bundle_root = build_bundle_root(tmp_path / "bundle")
    before = snapshot_bundle(bundle_root)
    client = build_admin_client(bundle_root, tmp_path / "audit.sqlite3")
    login_admin(client)

    responses = [
        client.get("/api/operator-state"),
        client.post(
            "/api/providers",
            json={
                "label": "OpenAI Production",
                "kind": "openai_compat",
                "base_url": "https://api.openai.com/v1",
                "secret_ref": "PROVIDER_DEFAULT_API_KEY",
            },
            headers={"Origin": "http://testserver"},
        ),
        client.put(
            "/api/providers/openai-production",
            json={"label": "OpenAI Production Prime"},
            headers={"Origin": "http://testserver"},
        ),
        client.delete(
            "/api/providers/openai-production",
            headers={"Origin": "http://testserver"},
        ),
        client.post(
            "/api/providers/openai-production/models",
            json={
                "upstream_id": "gpt-4.1-mini",
                "public_alias": "stronk-lm",
                "privacy_policy_id": "default-openai-chat",
            },
            headers={"Origin": "http://testserver"},
        ),
        client.put(
            "/api/providers/openai-production/models/gpt-4.1-mini",
            json={"public_alias": "stronk-lm-hot"},
            headers={"Origin": "http://testserver"},
        ),
        client.delete(
            "/api/providers/openai-production/models/gpt-4.1-mini",
            headers={"Origin": "http://testserver"},
        ),
    ]

    assert_retired(responses[0], code="admin_operator_state_retired")
    for response in responses[1:]:
        assert_retired(response, code="admin_provider_model_ownership_retired")

    assert snapshot_bundle(bundle_root) == before
    assert not (bundle_root / "config" / "operator-objects.draft.json").exists()
    assert sorted(path.relative_to(bundle_root) for path in bundle_root.rglob("*.bak.*")) == []


def test_probe_and_apply_routes_return_410_and_do_not_start_jobs(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(tmp_path / "bundle")
    before = snapshot_bundle(bundle_root)
    client = build_admin_client(bundle_root, tmp_path / "audit.sqlite3")
    login_admin(client)

    responses = [
        client.post(
            "/api/providers/openai-production/test",
            json={},
            headers={"Origin": "http://testserver"},
        ),
        client.post(
            "/api/providers/openai-production/discover",
            json={},
            headers={"Origin": "http://testserver"},
        ),
        client.post("/api/apply", json={}, headers={"Origin": "http://testserver"}),
        client.get("/api/apply/apply-0001"),
        client.post(
            "/api/apply/apply-0001/rollback",
            json={},
            headers={"Origin": "http://testserver"},
        ),
    ]

    assert_retired(responses[0], code="admin_provider_model_ownership_retired")
    assert_retired(responses[1], code="admin_provider_model_ownership_retired")
    for response in responses[2:]:
        assert_retired(response, code="admin_apply_retired")

    assert snapshot_bundle(bundle_root) == before
    assert not hasattr(client.app.state, "apply_manager") or client.app.state.apply_manager is None
    assert sorted(path.relative_to(bundle_root) for path in bundle_root.rglob("*.bak.*")) == []
