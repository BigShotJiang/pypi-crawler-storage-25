"""Tests for the highlight TS emitter."""
from recipe_dsl.highlight.emitter import CLASS_ORDER, emit_ts
from recipe_dsl.highlight.token_entry import TokenEntry


def _bare(cls, pattern, *, priority=0):
    return TokenEntry(prism_class=cls, pattern=pattern, priority=priority)


def test_class_order_constant():
    assert CLASS_ORDER == [
        "comment",
        "hurl-block",
        "sql-string",
        "css-string",
        "regex-string",
        "string",
        "function",
        "keyword",
        "operator",
        "punctuation",
        "number",
        "variable",
    ]


def test_emit_ts_includes_banner_and_imports():
    out = emit_ts({"keyword": [_bare("keyword", r"\bPIPELINE\b")]})
    assert "AUTO-GENERATED" in out
    assert "import type { Grammar } from 'prismjs'" in out
    assert "interface PrismLike" in out
    assert "export function registerRecipeDsl" in out


def test_emit_ts_assigns_to_languages_key():
    out = emit_ts({"keyword": [_bare("keyword", r"\bPIPELINE\b")]})
    assert "Prism.languages['recipe-dsl']" in out


def test_emit_ts_single_bare_regex_class():
    out = emit_ts({"keyword": [_bare("keyword", r"\bPIPELINE\b")]})
    assert "keyword: /\\bPIPELINE\\b/," in out


def test_emit_ts_multiple_bare_regexes_collapse_to_alternation():
    token_map = {
        "keyword": [
            _bare("keyword", r"\bPIPELINE\b", priority=2),
            _bare("keyword", r"\bSTEP\b", priority=1),
        ]
    }
    out = emit_ts(token_map)
    keyword_line = next(line for line in out.splitlines() if line.strip().startswith("keyword:"))
    assert "PIPELINE" in keyword_line
    assert "STEP" in keyword_line
    assert keyword_line.count(": /") == 1


def test_emit_ts_empty_class_skipped():
    out = emit_ts({"keyword": [_bare("keyword", r"\bPIPELINE\b")], "function": []})
    assert "function:" not in out


def test_emit_ts_class_order_respected():
    token_map = {
        "variable": [_bare("variable", r"[a-z]+")],
        "comment": [_bare("comment", r"--[^\n]*")],
    }
    out = emit_ts(token_map)
    comment_pos = out.index("comment:")
    variable_pos = out.index("variable:")
    assert comment_pos < variable_pos


def test_emit_ts_token_object_with_inside_and_alias():
    entry = TokenEntry(
        prism_class="sql-string",
        pattern=r'"[^"]*"',
        greedy=True,
        inside_lang="sql",
        alias="string",
    )
    out = emit_ts({"sql-string": [entry]})
    assert "'sql-string':" in out
    assert "pattern:" in out
    assert "greedy: true" in out
    assert "inside: Prism.languages['sql'] ?? undefined" in out
    assert "alias: 'string'" in out


def test_emit_ts_token_object_with_lookbehind():
    entry = TokenEntry(
        prism_class="comment",
        pattern=r"--[^\n]*",
        lookbehind=True,
    )
    out = emit_ts({"comment": [entry]})
    assert "lookbehind: true" in out


def test_emit_ts_string_class_emits_token_object_with_greedy():
    entry = TokenEntry(
        prism_class="string",
        pattern=r'"[^"]*"',
        greedy=True,
    )
    out = emit_ts({"string": [entry]})
    assert "string: {" in out
    assert "greedy: true" in out


def test_emit_ts_within_class_higher_priority_first():
    high = _bare("operator", "==", priority=2)
    low = _bare("operator", "=", priority=1)
    out = emit_ts({"operator": [low, high]})
    operator_line = next(
        line for line in out.splitlines() if line.strip().startswith("operator:")
    )
    assert operator_line.index("==") < operator_line.rindex("=")


def test_emit_ts_within_class_length_tiebreak():
    a = _bare("operator", "<=", priority=1)
    b = _bare("operator", "<", priority=1)
    out = emit_ts({"operator": [b, a]})
    operator_line = next(
        line for line in out.splitlines() if line.strip().startswith("operator:")
    )
    assert operator_line.index("<=") < operator_line.rindex("<")


def test_emit_ts_mixed_class_token_object_form_when_any_entry_needs_it():
    bare = _bare("string", r'"[^"]*"')
    token_obj = TokenEntry(
        prism_class="string",
        pattern=r"'[^']*'",
        greedy=True,
    )
    out = emit_ts({"string": [bare, token_obj]})
    assert "string:" in out
    assert "greedy: true" in out
