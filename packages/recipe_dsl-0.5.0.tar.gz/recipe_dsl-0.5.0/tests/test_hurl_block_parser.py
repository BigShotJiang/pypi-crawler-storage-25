"""Tests for src/recipe_dsl/grammar/hurl_block.py."""
import pytest

from recipe_dsl.grammar.hurl_block import strip_triple_quotes_and_dedent


def test_strip_basic():
    raw = '"""\n    GET /foo\n    [Headers]\n    A: B\n    """'
    assert strip_triple_quotes_and_dedent(raw) == "GET /foo\n[Headers]\nA: B"


def test_strip_no_indent():
    raw = '"""GET /foo"""'
    assert strip_triple_quotes_and_dedent(raw) == "GET /foo"


def test_strip_preserves_blank_lines_inside():
    raw = '"""\n    GET /foo\n\n    {"x": 1}\n    """'
    assert strip_triple_quotes_and_dedent(raw) == 'GET /foo\n\n{"x": 1}'


def test_strip_rejects_non_triple_quoted():
    with pytest.raises(ValueError):
        strip_triple_quotes_and_dedent('"GET /foo"')


def test_parser_accepts_request_with_hurl_block():
    """Smoke: parser builds a RequestStatement from a HURL_BLOCK token."""
    from recipe_dsl.grammar.parser import Parser

    src = '''PIPELINE p:
  REQUEST """
GET https://example.com
""" INTO response
  OUTPUT response
'''
    ast = Parser().parse(src)
    assert ast is not None


def test_parse_simple_get():
    from recipe_dsl.grammar.hurl_block import parse_hurl_block
    block = "GET https://example.com"
    parsed = parse_hurl_block(block)
    assert parsed.request_line == "GET https://example.com"
    assert parsed.inline_headers == ()
    assert parsed.sections == ()
    assert parsed.body is None


def test_parse_with_headers_and_query():
    from recipe_dsl.grammar.hurl_block import parse_hurl_block
    block = """GET https://example.com
Authorization: Bearer abc
[Query]
foo: bar"""
    parsed = parse_hurl_block(block)
    assert parsed.inline_headers == ("Authorization: Bearer abc",)
    assert len(parsed.sections) == 1
    assert parsed.sections[0].name == "Query"
    assert parsed.sections[0].lines == ("foo: bar",)


def test_parse_with_json_body():
    from recipe_dsl.grammar.hurl_block import parse_hurl_block
    block = '''POST https://example.com
Content-Type: application/json

{"x": 1}'''
    parsed = parse_hurl_block(block)
    assert parsed.body_kind == "json"
    assert parsed.body == '{"x": 1}'


def test_parse_with_xml_body():
    from recipe_dsl.grammar.hurl_block import parse_hurl_block
    block = """POST https://example.com
Content-Type: application/xml

<root><a/></root>"""
    parsed = parse_hurl_block(block)
    assert parsed.body_kind == "xml"


def test_parse_empty_block_raises():
    import pytest
    from recipe_dsl.grammar.hurl_block import parse_hurl_block
    with pytest.raises(ValueError):
        parse_hurl_block("")
    with pytest.raises(ValueError):
        parse_hurl_block("   \n   \n")


def test_extract_skeleton_basic():
    from recipe_dsl.grammar.hurl_block import parse_hurl_block, extract_skeleton
    block = """POST https://example.com
Authorization: Bearer abc
[Query]
foo: bar
[Cookies]
session: xyz"""
    parsed = parse_hurl_block(block)
    skel = extract_skeleton(parsed)
    assert skel.method == "POST"
    assert skel.section_names == ("Query", "Cookies")
    assert skel.inline_header_keys == ("Authorization",)
    assert skel.section_keys == (("foo",), ("session",))
    assert skel.body_present is False


def test_extract_skeleton_with_body():
    from recipe_dsl.grammar.hurl_block import parse_hurl_block, extract_skeleton
    block = '''POST https://example.com
Content-Type: application/json

{"x": 1}'''
    parsed = parse_hurl_block(block)
    skel = extract_skeleton(parsed)
    assert skel.body_present is True
    assert skel.body_kind == "json"


def test_parse_body_without_inline_headers():
    """C1 regression: POST + blank line + body must yield body, not headers."""
    from recipe_dsl.grammar.hurl_block import parse_hurl_block
    block = 'POST https://example.com\n\n{"x": 1}'
    parsed = parse_hurl_block(block)
    assert parsed.inline_headers == ()
    assert parsed.body == '{"x": 1}'
    assert parsed.body_kind == "json"


def test_parse_blank_line_between_sections():
    """C2 regression: blank line between two sections must keep both sections."""
    from recipe_dsl.grammar.hurl_block import parse_hurl_block
    block = "GET https://example.com\n[Query]\nfoo: bar\n\n[Cookies]\nsession: xyz"
    parsed = parse_hurl_block(block)
    assert len(parsed.sections) == 2
    assert parsed.sections[0].name == "Query"
    assert parsed.sections[1].name == "Cookies"
    assert parsed.body is None


def test_parse_section_then_blank_then_body():
    """A section followed by a blank line then a body must detect both."""
    from recipe_dsl.grammar.hurl_block import parse_hurl_block
    block = 'POST https://example.com\n[Query]\nfoo: bar\n\n{"x": 1}'
    parsed = parse_hurl_block(block)
    assert len(parsed.sections) == 1
    assert parsed.sections[0].name == "Query"
    assert parsed.body == '{"x": 1}'
    assert parsed.body_kind == "json"


def test_skeleton_is_hashable():
    """Frozen dataclass invariant: HurlSkeleton must be hashable."""
    from recipe_dsl.grammar.hurl_block import parse_hurl_block, extract_skeleton
    parsed = parse_hurl_block("GET https://example.com\n[Query]\nfoo: bar")
    skel = extract_skeleton(parsed)
    hash(skel)  # must not raise


def test_parser_rejects_forbidden_section_at_parse_time():
    """Phase 1 fires at parse time for forbidden sections."""
    import pytest
    from recipe_dsl.grammar.parser import Parser
    from recipe_dsl.errors.exceptions import CompilerError
    src = '''PIPELINE p:
  REQUEST """
GET https://example.com
[Asserts]
status == 200
""" INTO response
  OUTPUT response
'''
    with pytest.raises(CompilerError) as ei:
        Parser().parse(src)
    err = ei.value
    assert err.error_code == "E_HURL_PHASE1"
    assert "[Asserts]" in err.message


def test_parser_rejects_forbidden_option_at_parse_time():
    """Phase 1 catches forbidden [Options] sub-keys at parse time."""
    import pytest
    from recipe_dsl.grammar.parser import Parser
    from recipe_dsl.errors.exceptions import CompilerError
    src = '''PIPELINE p:
  REQUEST """
GET https://example.com
[Options]
output: /tmp/leak
""" INTO response
  OUTPUT response
'''
    with pytest.raises(CompilerError) as ei:
        Parser().parse(src)
    err = ei.value
    assert err.error_code == "E_HURL_PHASE1"
    assert "output" in err.message


def test_parser_rejects_empty_hurl_block_with_compiler_error():
    """parse_hurl_block ValueErrors are wrapped as CompilerError."""
    import pytest
    from recipe_dsl.grammar.parser import Parser
    from recipe_dsl.errors.exceptions import CompilerError
    src = '''PIPELINE p:
  REQUEST """
""" INTO response
  OUTPUT response
'''
    with pytest.raises(CompilerError) as ei:
        Parser().parse(src)
    assert ei.value.error_code == "E_HURL_PARSE"


def test_parser_populates_block_skeleton():
    """Phase 1 success populates block_skeleton on the RequestStatement."""
    from recipe_dsl.grammar.parser import Parser
    from recipe_dsl.ast.nodes import RequestStatement

    src = '''PIPELINE p:
  REQUEST """
POST https://example.com
Authorization: Bearer x
[Query]
foo: bar
""" INTO response
  OUTPUT response
'''
    ast = Parser().parse(src)

    # Walk the AST to find the RequestStatement
    found = _find_request_stmt(ast)
    assert found is not None
    assert found.block_skeleton is not None
    assert found.block_skeleton.method == "POST"
    assert found.block_skeleton.section_names == ("Query",)
    assert found.block_skeleton.inline_header_keys == ("Authorization",)


def _find_request_stmt(ast):
    """Walk the AST to find any RequestStatement node (depth-first)."""
    from recipe_dsl.ast.nodes import RequestStatement
    if isinstance(ast, RequestStatement):
        return ast
    for attr in ("steps", "body", "items", "children", "pipelines", "operation"):
        v = getattr(ast, attr, None)
        if isinstance(v, (list, tuple)):
            for item in v:
                r = _find_request_stmt(item)
                if r is not None:
                    return r
        elif v is not None:
            r = _find_request_stmt(v)
            if r is not None:
                return r
    # Try generic vars-based introspection as a fallback
    if hasattr(ast, "__dict__"):
        for v in ast.__dict__.values():
            if isinstance(v, (list, tuple)):
                for item in v:
                    r = _find_request_stmt(item)
                    if r is not None:
                        return r
    return None


def test_oneline_body_kind():
    from recipe_dsl.grammar.hurl_block import parse_hurl_block
    block = "POST https://example.com\n\n`hello world`\n"
    p = parse_hurl_block(block)
    assert p.body_kind == "oneline"


@pytest.mark.parametrize("lang,expected", [
    ("json", "multiline_json"),
    ("xml", "multiline_xml"),
    ("graphql", "multiline_graphql"),
    ("raw", "multiline_raw"),
    ("", "multiline_plain"),
])
def test_multiline_body_subkind(lang, expected):
    from recipe_dsl.grammar.hurl_block import parse_hurl_block
    block = f'POST https://example.com\n\n```{lang}\nx\n```\n'
    p = parse_hurl_block(block)
    assert p.body_kind == expected, (lang, p.body_kind)
