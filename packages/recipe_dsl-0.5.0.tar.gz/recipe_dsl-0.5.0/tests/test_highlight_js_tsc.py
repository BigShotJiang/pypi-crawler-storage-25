"""TS-side validation: generated file passes tsc --noEmit."""
import subprocess
from pathlib import Path

from recipe_dsl.highlight import generate


def test_generated_ts_passes_tsc(js_harness_dir: Path):
    tmp_dir = js_harness_dir / ".tmp"
    tmp_dir.mkdir(exist_ok=True)
    out_file = tmp_dir / "grammar.gen.ts"
    out_file.write_text(generate(), encoding="utf-8")

    result = subprocess.run(
        ["npx", "tsc", "--noEmit", str(out_file.relative_to(js_harness_dir))],
        cwd=js_harness_dir,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, (
        f"tsc --noEmit failed:\nSTDOUT: {result.stdout}\nSTDERR: {result.stderr}"
    )
