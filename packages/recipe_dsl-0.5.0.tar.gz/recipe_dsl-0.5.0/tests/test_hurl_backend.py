"""Tests for HurlBackend with mocked subprocess."""
from __future__ import annotations
import json
import os
import subprocess
import uuid
from subprocess import CompletedProcess
from unittest.mock import patch, MagicMock

import pytest

from recipe_dsl.runtime.backends.hurl import HurlBackend
from recipe_dsl.errors import RequestRuntimeError, RequestTransportError


def _fake_hurl_run(tempdir, *, status=200, body_text='{"ok":true}',
                   headers=None, url="https://example.com",
                   body_filename=None):
    """Write a fake report.json + body file under tempdir as Hurl 8.0 would."""
    headers = headers if headers is not None else [
        {"name": "Content-Type", "value": "application/json"}
    ]
    if body_filename is None:
        body_filename = f"store/{uuid.uuid4().hex}_response.json"
    full_body_path = os.path.join(tempdir, body_filename)
    os.makedirs(os.path.dirname(full_body_path), exist_ok=True)
    with open(full_body_path, "w", encoding="utf-8") as f:
        f.write(body_text)
    report = [{
        "filename": "request.hurl",
        "entries": [{
            "calls": [{
                "request": {"url": url},
                "response": {
                    "status": status,
                    "headers": headers,
                    "body": body_filename,
                },
            }],
            "time": 42,
        }],
    }]
    with open(os.path.join(tempdir, "report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f)


def _make_subprocess_mock(*, status=200, body_text='{"ok":true}',
                          headers=None, url="https://example.com",
                          returncode=0):
    def side_effect(cmd, *args, **kwargs):
        # Short-circuit version check.
        if "--version" in cmd:
            return CompletedProcess(args=cmd, returncode=0,
                                    stdout="hurl 8.0.1\n", stderr="")
        try:
            i = cmd.index("--report-json")
            tempdir = cmd[i + 1]
        except (ValueError, IndexError):
            raise AssertionError(f"unexpected hurl cmd: {cmd}")
        _fake_hurl_run(tempdir, status=status, body_text=body_text,
                       headers=headers, url=url)
        return CompletedProcess(args=cmd, returncode=returncode, stdout="", stderr="")
    return side_effect


def test_request_returns_envelope():
    backend = HurlBackend(binary_path="/usr/bin/hurl")
    with patch("subprocess.run", side_effect=_make_subprocess_mock()):
        env = backend.request("GET https://example.com")
    assert env["status"] == 200
    assert env["body"] == '{"ok":true}'
    assert env["time_ms"] == 42
    assert env["url"] == "https://example.com"
    assert env["headers"] == {"content-type": "application/json"}


def test_redirect_chain_envelope_uses_final_hop():
    """With [Options] location: true, hurl emits multiple calls per
    entry — one per redirect hop. The envelope must reflect the final
    hop's response (status, headers, body, url), not the first hop."""
    backend = HurlBackend(binary_path="/usr/bin/hurl")

    def side_effect(cmd, *args, **kwargs):
        if "--version" in cmd:
            return CompletedProcess(args=cmd, returncode=0,
                                    stdout="hurl 8.0.1\n", stderr="")
        i = cmd.index("--report-json")
        tempdir = cmd[i + 1]
        # Body for the final hop only.
        body_filename = "store/final.json"
        full = os.path.join(tempdir, body_filename)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as f:
            f.write('{"final": "step3"}')
        report = [{
            "filename": "request.hurl",
            "entries": [{
                "calls": [
                    {
                        "request": {"url": "https://example.com/step1"},
                        "response": {
                            "status": 301,
                            "headers": [{"name": "Location", "value": "/step2"}],
                            "body": "",
                        },
                    },
                    {
                        "request": {"url": "https://example.com/step2"},
                        "response": {
                            "status": 301,
                            "headers": [{"name": "Location", "value": "/step3"}],
                            "body": "",
                        },
                    },
                    {
                        "request": {"url": "https://example.com/step3"},
                        "response": {
                            "status": 200,
                            "headers": [{"name": "Content-Type", "value": "application/json"}],
                            "body": body_filename,
                        },
                    },
                ],
                "time": 42,
            }],
        }]
        with open(os.path.join(tempdir, "report.json"), "w", encoding="utf-8") as f:
            json.dump(report, f)
        return CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

    with patch("subprocess.run", side_effect=side_effect):
        env = backend.request("GET https://example.com/step1\n[Options]\nlocation: true")
    assert env["status"] == 200
    assert env["body"] == '{"final": "step3"}'
    assert env["url"] == "https://example.com/step3"
    assert env["headers"] == {"content-type": "application/json"}


def test_request_lowercases_header_keys_and_last_wins_on_duplicates():
    backend = HurlBackend(binary_path="/usr/bin/hurl")
    headers = [
        {"name": "X-Foo", "value": "first"},
        {"name": "X-FOO", "value": "second"},
    ]
    with patch("subprocess.run",
               side_effect=_make_subprocess_mock(headers=headers, body_text="")):
        env = backend.request("GET https://example.com")
    assert env["headers"] == {"x-foo": "second"}


def test_request_raises_runtime_error_on_malformed_report_json():
    """A report.json that isn't valid JSON surfaces as RequestRuntimeError."""
    backend = HurlBackend(binary_path="/usr/bin/hurl")

    def side_effect(cmd, *args, **kwargs):
        if "--version" in cmd:
            return CompletedProcess(args=cmd, returncode=0,
                                    stdout="hurl 8.0.1\n", stderr="")
        i = cmd.index("--report-json")
        tempdir = cmd[i + 1]
        with open(os.path.join(tempdir, "report.json"), "w", encoding="utf-8") as f:
            f.write("not json")
        return CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

    with patch("subprocess.run", side_effect=side_effect):
        with pytest.raises(RequestRuntimeError):
            backend.request("GET https://example.com")


def test_request_raises_transport_when_report_missing():
    """If hurl exits nonzero and writes no report.json, we get a transport error."""
    backend = HurlBackend(binary_path="/usr/bin/hurl")

    def side_effect(cmd, *args, **kwargs):
        if "--version" in cmd:
            return CompletedProcess(args=cmd, returncode=0,
                                    stdout="hurl 8.0.1\n", stderr="")
        # Don't write report.json.
        return CompletedProcess(args=cmd, returncode=6, stdout="",
                                stderr="Could not resolve host")

    with patch("subprocess.run", side_effect=side_effect):
        with pytest.raises(RequestTransportError):
            backend.request("GET https://nonexistent.local")


def test_request_raises_transport_on_timeout():
    backend = HurlBackend(binary_path="/usr/bin/hurl")

    def side_effect(cmd, *args, **kwargs):
        if "--version" in cmd:
            return CompletedProcess(args=cmd, returncode=0,
                                    stdout="hurl 8.0.1\n", stderr="")
        raise subprocess.TimeoutExpired(cmd="hurl", timeout=60)

    with patch("subprocess.run", side_effect=side_effect):
        with pytest.raises(RequestTransportError):
            backend.request("GET https://example.com")


def test_envelope_raises_on_empty_entries():
    """report.json with empty entries list raises RequestRuntimeError."""
    backend = HurlBackend(binary_path="/usr/bin/hurl")

    def side_effect(cmd, *args, **kwargs):
        if "--version" in cmd:
            return CompletedProcess(args=cmd, returncode=0,
                                    stdout="hurl 8.0.1\n", stderr="")
        i = cmd.index("--report-json")
        tempdir = cmd[i + 1]
        report = [{"filename": "request.hurl", "entries": []}]
        with open(os.path.join(tempdir, "report.json"), "w", encoding="utf-8") as f:
            json.dump(report, f)
        return CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

    with patch("subprocess.run", side_effect=side_effect):
        with pytest.raises(RequestRuntimeError, match="entries"):
            backend.request("GET https://example.com")


def test_envelope_raises_when_body_path_missing():
    """report.json response without body field raises RequestRuntimeError."""
    backend = HurlBackend(binary_path="/usr/bin/hurl")

    def side_effect(cmd, *args, **kwargs):
        if "--version" in cmd:
            return CompletedProcess(args=cmd, returncode=0,
                                    stdout="hurl 8.0.1\n", stderr="")
        i = cmd.index("--report-json")
        tempdir = cmd[i + 1]
        report = [{
            "filename": "request.hurl",
            "entries": [{
                "calls": [{
                    "request": {"url": "https://example.com"},
                    "response": {"status": 200, "headers": []},
                }],
                "time": 1,
            }],
        }]
        with open(os.path.join(tempdir, "report.json"), "w", encoding="utf-8") as f:
            json.dump(report, f)
        return CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

    with patch("subprocess.run", side_effect=side_effect):
        with pytest.raises(RequestRuntimeError, match="body.*missing"):
            backend.request("GET https://example.com")


def test_envelope_raises_when_body_file_unreadable():
    """report.json body path pointing at nonexistent file raises RequestRuntimeError."""
    backend = HurlBackend(binary_path="/usr/bin/hurl")

    def side_effect(cmd, *args, **kwargs):
        if "--version" in cmd:
            return CompletedProcess(args=cmd, returncode=0,
                                    stdout="hurl 8.0.1\n", stderr="")
        i = cmd.index("--report-json")
        tempdir = cmd[i + 1]
        report = [{
            "filename": "request.hurl",
            "entries": [{
                "calls": [{
                    "request": {"url": "https://example.com"},
                    "response": {
                        "status": 200,
                        "headers": [],
                        "body": "store/missing.json",
                    },
                }],
                "time": 1,
            }],
        }]
        with open(os.path.join(tempdir, "report.json"), "w", encoding="utf-8") as f:
            json.dump(report, f)
        return CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

    with patch("subprocess.run", side_effect=side_effect):
        with pytest.raises(RequestRuntimeError, match="cannot read response body"):
            backend.request("GET https://example.com")


def test_interpreter_lazy_creates_hurl_backend(monkeypatch):
    """The interpreter creates a HurlBackend on first REQUEST execution."""
    from recipe_dsl.runtime.interpreter import Interpreter
    # Ensure binary discovery succeeds without a real hurl install.
    monkeypatch.setenv("RECIPE_DSL_HURL_BINARY", "/usr/bin/hurl")
    interp = Interpreter()
    assert interp._hurl_backend is None
    backend = interp._ensure_hurl_backend()
    assert backend is interp._hurl_backend
    # Second call returns the same instance.
    assert interp._ensure_hurl_backend() is backend


def test_default_throw_on_404_via_interpreter():
    """Non-2xx response triggers RequestStatusError at the interpreter layer."""
    from recipe_dsl.grammar.parser import Parser
    from recipe_dsl.runtime.interpreter import Interpreter
    from recipe_dsl.errors import RequestStatusError

    class _FakeBackend:
        def request(self, block):
            return {"status": 404, "headers": {"x-foo": "y"}, "body": "nope",
                    "time_ms": 1, "url": "x"}
        def close(self):
            pass

    src = '''PIPELINE p:
  REQUEST """
GET https://example.com/missing
""" INTO response
  OUTPUT response
'''
    ast = Parser().parse(src)
    interp = Interpreter()
    interp._hurl_backend = _FakeBackend()
    with pytest.raises(RequestStatusError) as ei:
        interp.execute(ast)
    assert ei.value.status == 404
    assert ei.value.body == "nope"
    assert ei.value.headers == {"x-foo": "y"}


def test_full_request_smoke_parse_validate_backend():
    """End-to-end: parse → Phase 1 → execute → Phase 2 → mocked backend → envelope stored."""
    from recipe_dsl.grammar.parser import Parser
    from recipe_dsl.runtime.interpreter import Interpreter

    class _OK:
        def __init__(self):
            self.calls = []
        def request(self, block):
            self.calls.append(block)
            return {"status": 200, "headers": {"content-type": "application/json"},
                    "body": '{"items": [1, 2]}', "time_ms": 12, "url": "https://example.com/"}
        def close(self):
            pass

    src = '''PIPELINE p:
  REQUEST """
GET https://example.com
""" INTO response
  OUTPUT response
'''
    ast = Parser().parse(src)
    interp = Interpreter()
    backend = _OK()
    interp._hurl_backend = backend
    interp.execute(ast)
    # Backend was called exactly once
    assert len(backend.calls) == 1
    # Envelope was stored
    response = interp._scalars.get("response")
    assert response is not None
    assert response["status"] == 200
    assert response["body"] == '{"items": [1, 2]}'
    assert response["time_ms"] == 12
