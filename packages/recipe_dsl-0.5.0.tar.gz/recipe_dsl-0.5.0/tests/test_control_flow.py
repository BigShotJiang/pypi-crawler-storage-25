"""Tests for Control Flow features (SET, IF/ELSE, FOR_EACH, etc.)."""

import pytest

from recipe_dsl.grammar.parser import Parser
from recipe_dsl.runtime.interpreter import Interpreter


@pytest.fixture
def parser() -> Parser:
    """Create a parser instance."""
    return Parser()


@pytest.fixture
def interpreter() -> Interpreter:
    """Create an interpreter instance."""
    return Interpreter()


class TestSetStatement:
    """Tests for SET statement."""

    def test_set_number(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test SET with numeric value."""
        source = '''
        PIPELINE set_num_test:
            SET counter = 42

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("counter") == 42

    def test_set_decimal(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test SET with decimal value."""
        source = '''
        PIPELINE set_dec_test:
            SET rate = 3.14

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("rate") == 3.14

    def test_set_string(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test SET with string value."""
        source = '''
        PIPELINE set_str_test:
            SET name = "hello"

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("name") == "hello"

    def test_set_true(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test SET with true value."""
        source = '''
        PIPELINE set_bool_test:
            SET flag = true

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("flag") is True

    def test_set_false(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test SET with false value."""
        source = '''
        PIPELINE set_bool_test:
            SET flag = false

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("flag") is False

    def test_set_arithmetic(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test SET with arithmetic expression."""
        source = '''
        PIPELINE set_arith_test:
            SET result = 10 + 5 * 2

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("result") == 20

    def test_set_update_variable(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test SET can update existing variable."""
        source = '''
        PIPELINE update_test:
            SET counter = 1
            SET counter = 2

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("counter") == 2

    def test_set_from_variable(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test SET from another variable."""
        source = '''
        PIPELINE copy_test:
            SET a = 100
            SET b = a

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("a") == 100
        assert interpreter.get_scalar("b") == 100

    def test_get_scalars(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test getting all scalar variables."""
        source = '''
        PIPELINE scalars_test:
            SET a = 1
            SET b = "two"
            SET c = true

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        scalars = interpreter.get_scalars()
        assert scalars["a"] == 1
        assert scalars["b"] == "two"
        assert scalars["c"] is True


class TestIfStatement:
    """Tests for IF/ELSE statement."""

    def test_if_true(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test IF with true condition."""
        source = '''
        PIPELINE if_true_test:
            SET value = 10

            IF value > 5:
                SET result = "big"
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("result") == "big"

    def test_if_false(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test IF with false condition (no else)."""
        source = '''
        PIPELINE if_false_test:
            SET value = 3
            SET result = "default"

            IF value > 5:
                SET result = "big"
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("result") == "default"

    def test_if_else_true_branch(
        self, parser: Parser, interpreter: Interpreter
    ) -> None:
        """Test IF/ELSE where condition is true."""
        source = '''
        PIPELINE if_else_test:
            SET value = 10

            IF value > 5:
                SET result = "big"
            ELSE:
                SET result = "small"
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("result") == "big"

    def test_if_else_false_branch(
        self, parser: Parser, interpreter: Interpreter
    ) -> None:
        """Test IF/ELSE where condition is false."""
        source = '''
        PIPELINE if_else_test:
            SET value = 3

            IF value > 5:
                SET result = "big"
            ELSE:
                SET result = "small"
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("result") == "small"

    def test_if_else_if(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test IF/ELSE IF chain."""
        source = '''
        PIPELINE if_else_if_test:
            SET value = 5

            IF value > 10:
                SET result = "large"
            ELSE:
                IF value > 3:
                    SET result = "medium"
                ELSE:
                    SET result = "small"
                END
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("result") == "medium"

    def test_if_with_equality(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test IF with equality comparison."""
        source = '''
        PIPELINE if_eq_test:
            SET status = "active"

            IF status == "active":
                SET result = 1
            ELSE:
                SET result = 0
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("result") == 1

    def test_nested_if(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test nested IF statements."""
        source = '''
        PIPELINE nested_if_test:
            SET a = 10
            SET b = 5

            IF a > 5:
                IF b > 3:
                    SET result = "both"
                ELSE:
                    SET result = "a_only"
                END
            ELSE:
                SET result = "neither"
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("result") == "both"

    def test_if_multiple_statements(
        self, parser: Parser, interpreter: Interpreter
    ) -> None:
        """Test IF with multiple statements in body."""
        source = '''
        PIPELINE if_multi_test:
            SET flag = true

            IF flag == true:
                SET a = 1
                SET b = 2
                SET c = 3
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("a") == 1
        assert interpreter.get_scalar("b") == 2
        assert interpreter.get_scalar("c") == 3


class TestForEachStatement:
    """Tests for FOR_EACH statement."""

    def test_for_each_counter(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test FOR_EACH to count items."""
        source = '''
        PIPELINE for_each_count_test:
            SET count = 0

            FOR_EACH row IN data:
                SET count = count + 1
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [
            {"value": 10},
            {"value": 20},
            {"value": 30}
        ]})

        assert interpreter.get_scalar("count") == 3

    def test_for_each_nested(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test nested FOR_EACH loops."""
        source = '''
        PIPELINE nested_for_each_test:
            SET count = 0

            FOR_EACH o IN outer:
                FOR_EACH i IN inner:
                    SET count = count + 1
                END
            END

            OUTPUT outer
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {
            "outer": [{"x": 1}, {"x": 2}],
            "inner": [{"y": 1}, {"y": 2}, {"y": 3}]
        })

        assert interpreter.get_scalar("count") == 6  # 2 * 3

    def test_for_each_set_last_value(
        self, parser: Parser, interpreter: Interpreter
    ) -> None:
        """Test FOR_EACH setting a value each iteration."""
        source = '''
        PIPELINE for_each_last_test:
            SET last_index = 0

            FOR_EACH row IN data:
                SET last_index = last_index + 1
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [
            {"value": 10},
            {"value": 20}
        ]})

        assert interpreter.get_scalar("last_index") == 2


class TestWhileStatement:
    """Tests for WHILE statement."""

    def test_while_countdown(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test WHILE loop with countdown."""
        source = '''
        PIPELINE while_countdown_test:
            SET counter = 5
            SET sum = 0

            WHILE counter > 0:
                SET sum = sum + counter
                SET counter = counter - 1
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("counter") == 0
        assert interpreter.get_scalar("sum") == 15  # 5+4+3+2+1

    def test_while_false_from_start(
        self, parser: Parser, interpreter: Interpreter
    ) -> None:
        """Test WHILE that never executes."""
        source = '''
        PIPELINE while_never_test:
            SET counter = 0
            SET executed = false

            WHILE counter > 0:
                SET executed = true
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("executed") is False

    def test_while_with_if(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test WHILE with IF inside."""
        source = '''
        PIPELINE while_if_test:
            SET n = 10
            SET even_count = 0

            WHILE n > 0:
                IF n > 5:
                    SET even_count = even_count + 1
                END
                SET n = n - 1
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("n") == 0
        assert interpreter.get_scalar("even_count") == 5  # 10,9,8,7,6 > 5

    def test_while_string_condition(
        self, parser: Parser, interpreter: Interpreter
    ) -> None:
        """Test WHILE with string comparison."""
        source = '''
        PIPELINE while_string_test:
            SET status = "running"
            SET iterations = 0

            WHILE status == "running":
                SET iterations = iterations + 1
                IF iterations > 3:
                    SET status = "done"
                END
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("status") == "done"
        assert interpreter.get_scalar("iterations") == 4


class TestReturnStatement:
    """Tests for RETURN statement."""

    def test_return_early_exit(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test RETURN exits pipeline early."""
        source = '''
        PIPELINE return_early_test:
            SET result = "before"

            RETURN

            SET result = "after"

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        # Result should be "before" since RETURN exits before the second SET
        assert interpreter.get_scalar("result") == "before"

    def test_return_in_if(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test RETURN inside IF statement."""
        source = '''
        PIPELINE return_if_test:
            SET value = 10
            SET result = "initial"

            IF value > 5:
                SET result = "big"
                RETURN
            END

            SET result = "should_not_reach"

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("result") == "big"


class TestBreakStatement:
    """Tests for BREAK statement."""

    def test_break_in_for_each(
        self, parser: Parser, interpreter: Interpreter
    ) -> None:
        """Test BREAK exits FOR_EACH loop."""
        source = '''
        PIPELINE break_foreach_test:
            SET count = 0

            FOR_EACH row IN data:
                SET count = count + 1
                IF count == 2:
                    BREAK
                END
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [
            {"value": 1}, {"value": 2}, {"value": 3}, {"value": 4}, {"value": 5}
        ]})

        assert interpreter.get_scalar("count") == 2

    def test_break_in_while(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test BREAK exits WHILE loop."""
        source = '''
        PIPELINE break_while_test:
            SET counter = 0
            SET sum = 0

            WHILE counter < 100:
                SET counter = counter + 1
                SET sum = sum + counter
                IF counter == 5:
                    BREAK
                END
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("counter") == 5
        assert interpreter.get_scalar("sum") == 15  # 1+2+3+4+5

    def test_break_nested_loop(
        self, parser: Parser, interpreter: Interpreter
    ) -> None:
        """Test BREAK only exits innermost loop."""
        source = '''
        PIPELINE break_nested_test:
            SET outer_count = 0
            SET inner_count = 0

            FOR_EACH o IN outer:
                SET outer_count = outer_count + 1
                FOR_EACH i IN inner:
                    SET inner_count = inner_count + 1
                    IF inner_count == 2:
                        BREAK
                    END
                END
            END

            OUTPUT outer
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {
            "outer": [{"x": 1}, {"x": 2}],
            "inner": [{"y": 1}, {"y": 2}, {"y": 3}]
        })

        assert interpreter.get_scalar("outer_count") == 2
        # First outer: inner_count goes 1, 2 (break when ==2)
        # Second outer: inner_count is 2, goes to 3, 4, 5 (no break since never ==2 again)
        # Total: 1, 2(break), 3, 4, 5 = 5
        assert interpreter.get_scalar("inner_count") == 5


class TestContinueStatement:
    """Tests for CONTINUE statement."""

    def test_continue_in_for_each(
        self, parser: Parser, interpreter: Interpreter
    ) -> None:
        """Test CONTINUE skips to next iteration in FOR_EACH."""
        source = '''
        PIPELINE continue_foreach_test:
            SET sum = 0
            SET count = 0

            FOR_EACH row IN data:
                SET count = count + 1
                IF count == 2:
                    CONTINUE
                END
                SET sum = sum + count
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [
            {"value": 1}, {"value": 2}, {"value": 3}
        ]})

        # sum = 1 + 3 = 4 (skipped count 2)
        assert interpreter.get_scalar("sum") == 4
        assert interpreter.get_scalar("count") == 3

    def test_continue_in_while(
        self, parser: Parser, interpreter: Interpreter
    ) -> None:
        """Test CONTINUE skips to next iteration in WHILE."""
        source = '''
        PIPELINE continue_while_test:
            SET counter = 0
            SET sum = 0

            WHILE counter < 5:
                SET counter = counter + 1
                IF counter == 3:
                    CONTINUE
                END
                SET sum = sum + counter
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [{"x": 1}]})

        assert interpreter.get_scalar("counter") == 5
        # sum = 1 + 2 + 4 + 5 = 12 (skipped 3)
        assert interpreter.get_scalar("sum") == 12

    def test_continue_early_in_body(
        self, parser: Parser, interpreter: Interpreter
    ) -> None:
        """Test CONTINUE at start of loop body."""
        source = '''
        PIPELINE continue_early_test:
            SET count = 0
            SET processed = 0

            FOR_EACH row IN data:
                SET count = count + 1
                CONTINUE
                SET processed = processed + 1
            END

            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": [
            {"value": 1}, {"value": 2}, {"value": 3}
        ]})

        assert interpreter.get_scalar("count") == 3
        assert interpreter.get_scalar("processed") == 0
