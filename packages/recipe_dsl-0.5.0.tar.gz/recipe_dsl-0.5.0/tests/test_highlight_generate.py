"""Tests for the highlight pipeline orchestrator."""
from recipe_dsl.highlight import generate


def test_generate_returns_string():
    out = generate()
    assert isinstance(out, str)


def test_generate_includes_banner_and_function():
    out = generate()
    assert "AUTO-GENERATED" in out
    assert "export function registerRecipeDsl" in out
    assert "Prism.languages['recipe-dsl']" in out


def test_generate_includes_core_classes():
    out = generate()
    assert "comment:" in out
    assert "function:" in out
    assert "variable:" in out


def test_generate_includes_embed_classes_with_inside():
    out = generate()
    assert "'sql-string':" in out
    assert "'css-string':" in out
    assert "'regex-string':" in out
    assert "Prism.languages['sql'] ?? undefined" in out
    assert "Prism.languages['css'] ?? undefined" in out
    assert "Prism.languages['regex'] ?? undefined" in out


def test_generate_no_runtime_prismjs_import():
    out = generate()
    runtime_imports = [
        line
        for line in out.splitlines()
        if line.strip().startswith("import ") and "type" not in line
    ]
    assert runtime_imports == []
