"""Tests for the TokenEntry intermediate type."""
from recipe_dsl.highlight.token_entry import EMBED_PREFIX_LANG, TokenEntry


def test_token_entry_minimal():
    entry = TokenEntry(prism_class="keyword", pattern=r"\bPIPELINE\b")
    assert entry.prism_class == "keyword"
    assert entry.pattern == r"\bPIPELINE\b"
    assert entry.flags == ""
    assert entry.priority == 0
    assert entry.greedy is False
    assert entry.lookbehind is False
    assert entry.inside_lang is None
    assert entry.alias is None


def test_token_entry_with_embed_metadata():
    entry = TokenEntry(
        prism_class="sql-string",
        pattern=r'"[^"]*"|\'[^\']*\'',
        greedy=True,
        inside_lang="sql",
        alias="string",
    )
    assert entry.prism_class == "sql-string"
    assert entry.greedy is True
    assert entry.inside_lang == "sql"
    assert entry.alias == "string"


def test_token_entry_is_hashable():
    entry = TokenEntry(prism_class="keyword", pattern=r"\bX\b")
    assert hash(entry) is not None


def test_embed_prefix_lang_map():
    assert EMBED_PREFIX_LANG == {
        "SQL_": "sql",
        "CSS_": "css",
        "REGEX_": "regex",
        "HURL_": "hurl-mini",
    }
