"""Class-membership sanity tests against the generated TS output."""
import re

import pytest

from recipe_dsl.highlight import generate

_BARE_RE = re.compile(r"^\s*'?([\w-]+)'?:\s*/(.+)/([gimsuy]*),\s*$")
_OBJ_PATTERN_RE = re.compile(r"^\s*pattern:\s*/(.+)/([gimsuy]*),\s*$")


@pytest.fixture(scope="module")
def class_patterns() -> dict[str, list[str]]:
    """Return {class_name: [regex_source, ...]} parsed from the TS output."""
    out = generate()
    patterns: dict[str, list[str]] = {}
    inside_token_object: str | None = None
    for line in out.splitlines():
        stripped = line.strip()
        if inside_token_object is not None:
            mp = _OBJ_PATTERN_RE.match(line)
            if mp:
                patterns.setdefault(inside_token_object, []).append(mp.group(1))
            if stripped == "},":
                inside_token_object = None
            continue
        if stripped.endswith(": {"):
            cls = stripped[: stripped.index(":")].strip().strip("'")
            inside_token_object = cls
            continue
        m = _BARE_RE.match(line)
        if m:
            cls, pattern, _flags = m.group(1), m.group(2), m.group(3)
            patterns.setdefault(cls, []).append(pattern)
    return patterns


def _matches_any(regex_list, sample):
    return any(re.search(p, sample) for p in regex_list)


@pytest.mark.parametrize(
    "lexeme",
    ["PIPELINE", "STEP", "FILTER", "IF", "ELSE", "FOR_EACH"],
)
def test_keyword_lexemes(class_patterns, lexeme):
    assert _matches_any(class_patterns.get("keyword", []), lexeme)


@pytest.mark.parametrize("lexeme", ["UPPER", "CONCAT", "COUNT", "NOW"])
def test_function_lexemes(class_patterns, lexeme):
    assert _matches_any(class_patterns.get("function", []), f"{lexeme}(")


@pytest.mark.parametrize("lexeme", ["==", "!=", "<=", "+", "*"])
def test_operator_lexemes(class_patterns, lexeme):
    assert _matches_any(class_patterns.get("operator", []), lexeme)


@pytest.mark.parametrize("lexeme", [",", ":", "(", ")"])
def test_punctuation_lexemes(class_patterns, lexeme):
    assert _matches_any(class_patterns.get("punctuation", []), lexeme)


@pytest.mark.parametrize("lexeme", ['"hello"', "'hello'"])
def test_string_lexemes(class_patterns, lexeme):
    assert _matches_any(class_patterns.get("string", []), lexeme)


@pytest.mark.parametrize(
    "sample",
    [
        'QUERY "db" "SELECT * FROM t"',
        "QUERY conn 'SELECT * FROM t'",
    ],
)
def test_sql_string_lexemes(class_patterns, sample):
    # SQL-string regex requires the surrounding QUERY context to fire.
    assert _matches_any(class_patterns.get("sql-string", []), sample)


@pytest.mark.parametrize(
    "sample",
    [
        'CSS "div.title"',
        "CSS 'div.title'",
    ],
)
def test_css_string_lexemes(class_patterns, sample):
    assert _matches_any(class_patterns.get("css-string", []), sample)


@pytest.mark.parametrize(
    "sample",
    [
        'REGEX "^[A-Z]+$"',
        "REGEX '^[A-Z]+$'",
        'MATCHES(field, "^X")',
    ],
)
def test_regex_string_lexemes(class_patterns, sample):
    assert _matches_any(class_patterns.get("regex-string", []), sample)


@pytest.mark.parametrize("lexeme", ["42", "-3.14", "0", "100.5"])
def test_number_lexemes(class_patterns, lexeme):
    assert _matches_any(class_patterns.get("number", []), lexeme)


def test_comment_lexeme(class_patterns):
    assert _matches_any(class_patterns.get("comment", []), "-- a comment line")


@pytest.mark.parametrize("lexeme", ["users", "enriched", "my_var"])
def test_variable_lexemes(class_patterns, lexeme):
    assert _matches_any(class_patterns.get("variable", []), lexeme)
