"""End-to-end check: JOIN is both a keyword (op) and a function (call)."""
import re

from recipe_dsl.highlight import generate

_BARE_RE = re.compile(r"^\s*'?([\w-]+)'?:\s*/(.+)/([gimsuy]*),\s*$")
_OBJ_PATTERN_RE = re.compile(r"^\s*pattern:\s*/(.+)/([gimsuy]*),\s*$")


def _class_patterns() -> dict[str, list[str]]:
    out = generate()
    patterns: dict[str, list[str]] = {}
    inside_token_object: str | None = None
    for line in out.splitlines():
        stripped = line.strip()
        if inside_token_object is not None:
            mp = _OBJ_PATTERN_RE.match(line)
            if mp:
                patterns.setdefault(inside_token_object, []).append(mp.group(1))
            if stripped == "},":
                inside_token_object = None
            continue
        if stripped.endswith(": {"):
            cls = stripped[: stripped.index(":")].strip().strip("'")
            inside_token_object = cls
            continue
        m = _BARE_RE.match(line)
        if m:
            cls, pattern, _flags = m.group(1), m.group(2), m.group(3)
            patterns.setdefault(cls, []).append(pattern)
    return patterns


def test_join_bare_matches_keyword_only():
    patterns = _class_patterns()
    sample = "JOIN users WITH roles"

    keyword_match = any(re.search(p, sample) for p in patterns.get("keyword", []))
    function_match = any(re.search(p, sample) for p in patterns.get("function", []))

    assert keyword_match, "bare JOIN must match a keyword regex"
    assert not function_match, "bare JOIN must NOT match function regex"


def test_join_call_form_matches_function():
    patterns = _class_patterns()
    sample = "JOIN(items, ',')"

    function_match = any(re.search(p, sample) for p in patterns.get("function", []))
    assert function_match, "JOIN( must match function regex via lookahead"
