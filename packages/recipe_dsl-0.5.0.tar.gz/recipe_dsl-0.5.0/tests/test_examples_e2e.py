"""End-to-end tests for RecipeDSL example files."""

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

from tests.e2e_fixtures.api_server import start_api_server
from tests.e2e_fixtures.seed_data import (
    create_analytics_db,
    create_customers_db,
    create_employees_db,
    create_products_db,
    create_users_db,
)

EXAMPLES_DIR = Path(__file__).resolve().parent.parent / "examples"


@pytest.fixture(scope="session")
def api_server():
    """Start Flask API server for the test session."""
    server, port = start_api_server()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


@pytest.fixture
def tmp_dir():
    """Temporary directory for test artifacts."""
    with tempfile.TemporaryDirectory() as td:
        yield Path(td)


def run_recipe(recipe_path: str, env: dict, input_file: str = None) -> dict:
    """Run a recipe via CLI subprocess, return parsed result."""
    cmd = [sys.executable, "-m", "recipe_dsl.cli", "run", str(recipe_path), "--json"]
    if input_file:
        cmd.extend(["--input-file", str(input_file)])
    full_env = os.environ.copy()
    full_env.update(env)
    result = subprocess.run(cmd, capture_output=True, text=True, env=full_env, timeout=30)
    output = None
    if result.returncode == 0 and result.stdout.strip():
        try:
            output = json.loads(result.stdout)
        except json.JSONDecodeError:
            pass
    return {
        "returncode": result.returncode,
        "output": output,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }


class TestSalesReport:
    """Tests for examples/sales_report.rdsl."""

    def test_sales_report(self):
        recipe = EXAMPLES_DIR / "sales_report.rdsl"
        input_file = EXAMPLES_DIR / "sales_data.json"
        result = run_recipe(recipe, env={}, input_file=str(input_file))

        assert result["returncode"] == 0, f"Recipe failed: {result['stderr']}"
        assert result["output"] is not None, f"No JSON output. stdout={result['stdout']!r}"

        rows = result["output"]
        assert len(rows) == 3, f"Expected 3 rows, got {len(rows)}"

        # Top row should be Thingamajig (2*50=100)
        assert rows[0]["product"] == "Thingamajig"
        assert rows[0]["total"] == 100

        # Second row should be Gadget (3*25=75)
        assert rows[1]["product"] == "Gadget"
        assert rows[1]["total"] == 75

        # Third row should be Widget or Doohickey (both 50)
        assert rows[2]["total"] == 50
        assert rows[2]["product"] in ("Widget", "Doohickey")

        # Each row should have exactly product and total
        for row in rows:
            assert set(row.keys()) == {"product", "total"}


class TestCrossDbReport:
    """Tests for examples/cross_db_report.rdsl."""

    def test_cross_db_report(self, tmp_dir):
        customers_url = create_customers_db(tmp_dir / "customers.db")
        analytics_url = create_analytics_db(tmp_dir / "analytics.db")

        recipe = EXAMPLES_DIR / "cross_db_report.rdsl"
        env = {"DB_PRODUCTION": customers_url, "DB_ANALYTICS": analytics_url}
        result = run_recipe(recipe, env=env)

        assert result["returncode"] == 0, f"Recipe failed: {result['stderr']}"
        assert result["output"] is not None, f"No JSON output. stdout={result['stdout']!r}"

        rows = result["output"]
        assert len(rows) == 2, f"Expected 2 rows, got {len(rows)}: {rows}"

        # Sorted by total_spend DESC: Acme Corp (50000), Initech (15000)
        assert rows[0]["name"] == "Acme Corp"
        assert rows[0]["total_spend"] == 50000
        assert rows[1]["name"] == "Initech"
        assert rows[1]["total_spend"] == 15000


class TestValidateAndExport:
    """Tests for examples/validate_and_export.rdsl."""

    def test_validate_and_export(self, tmp_dir):
        db_url = create_employees_db(tmp_dir / "employees.db")
        output_dir = tmp_dir / "output"
        output_dir.mkdir()

        recipe = EXAMPLES_DIR / "validate_and_export.rdsl"
        env = {"DB_URL": db_url, "OUTPUT_DIR": str(output_dir)}
        result = run_recipe(recipe, env=env)

        assert result["returncode"] == 0, f"Recipe failed: {result['stderr']}"
        assert result["output"] is not None, f"No JSON output. stdout={result['stdout']!r}"

        rows = result["output"]
        # Bob (no @ in email) should be filtered out, leaving 3
        assert len(rows) == 3, f"Expected 3 rows, got {len(rows)}: {rows}"

        # All rows should have display_name
        for row in rows:
            assert "display_name" in row, f"Missing display_name in {row}"

        # Check export file exists
        export_file = output_dir / "employees.json"
        assert export_file.exists(), "Export file was not created"


class TestFetchSql:
    """Tests for examples/fetch_sql.rdsl."""

    def test_fetch_sql(self, tmp_dir, api_server):
        db_url = create_users_db(tmp_dir / "users.db")

        recipe = EXAMPLES_DIR / "fetch_sql.rdsl"
        env = {"DB_URL": db_url, "API_BASE": api_server}
        result = run_recipe(recipe, env=env)

        assert result["returncode"] == 0, f"Recipe failed: {result['stderr']}"
        assert result["output"] is not None, f"No JSON output. stdout={result['stdout']!r}"

        rows = result["output"]
        # Active users: Alice(1), Bob(2), Diana(4)
        # Roles: user_id 1=admin, 2=editor, 3=viewer
        # JOIN on id==user_id: Alice(admin), Bob(editor). Diana(id=4) has no role match.
        assert len(rows) == 2, f"Expected 2 rows, got {len(rows)}: {rows}"

        names = {r["name"] for r in rows}
        assert names == {"Alice", "Bob"}, f"Expected Alice and Bob, got {names}"

        # Verify role assignments
        by_name = {r["name"]: r for r in rows}
        assert by_name["Alice"]["role_name"] == "admin"
        assert by_name["Bob"]["role_name"] == "editor"

        # Each row should have name, email, role_name
        for row in rows:
            assert set(row.keys()) == {"name", "email", "role_name"}


class TestFetchRest:
    """Tests for examples/fetch_rest.rdsl."""

    def test_fetch_rest(self, api_server):
        recipe = EXAMPLES_DIR / "fetch_rest.rdsl"
        env = {"API_BASE": api_server}
        result = run_recipe(recipe, env=env)

        assert result["returncode"] == 0, f"Recipe failed: {result['stderr']}"
        assert result["output"] is not None, f"No JSON output. stdout={result['stdout']!r}"

        rows = result["output"]
        assert len(rows) == 3, f"Expected 3 rows, got {len(rows)}: {rows}"

        names = {r["name"] for r in rows}
        assert names == {"Widget", "Gadget", "Gizmo"}

        # Each row should have id and name
        for row in rows:
            assert set(row.keys()) == {"id", "name"}


class TestPaginatedApi:
    """Tests for examples/paginated_api.rdsl."""

    def test_paginated_api(self, api_server):
        recipe = EXAMPLES_DIR / "paginated_api.rdsl"
        env = {"API_BASE": api_server}
        result = run_recipe(recipe, env=env)

        assert result["returncode"] == 0, f"Recipe failed: {result['stderr']}"
        assert result["output"] is not None, f"No JSON output. stdout={result['stdout']!r}"

        rows = result["output"]
        # 2 categories: electronics (items 1,2,5 → count=3, total=100+200+150=450)
        #               books (items 3,4 → count=2, total=15+25=40)
        assert len(rows) == 2, f"Expected 2 rows, got {len(rows)}: {rows}"

        # Sorted by total_value DESC: electronics first
        assert rows[0]["category"] == "electronics"
        assert rows[0]["count"] == 3
        assert rows[0]["total_value"] == 450

        assert rows[1]["category"] == "books"
        assert rows[1]["count"] == 2
        assert rows[1]["total_value"] == 40


class TestApplyConfig:
    """Tests for examples/apply_config.rdsl."""

    def test_apply_config(self, tmp_dir):
        db_url = create_products_db(tmp_dir / "products.db")
        config_dir = tmp_dir / "config"
        config_dir.mkdir()
        output_dir = tmp_dir / "output"
        output_dir.mkdir()

        # Write pricing rules config
        pricing_rules = [
            {"category": "electronics", "multiplier": 1.2},
            {"category": "books", "multiplier": 0.9},
            {"category": "home", "multiplier": 1.0},
        ]
        (config_dir / "pricing_rules.json").write_text(json.dumps(pricing_rules))

        recipe = EXAMPLES_DIR / "apply_config.rdsl"
        env = {
            "DB_URL": db_url,
            "CONFIG_DIR": str(config_dir),
            "OUTPUT_DIR": str(output_dir),
        }
        result = run_recipe(recipe, env=env)

        assert result["returncode"] == 0, f"Recipe failed: {result['stderr']}"
        assert result["output"] is not None, f"No JSON output. stdout={result['stdout']!r}"

        rows = result["output"]
        assert len(rows) == 4, f"Expected 4 rows, got {len(rows)}: {rows}"

        # Build lookup by product name
        by_name = {r["name"]: r for r in rows}
        assert set(by_name.keys()) == {"Laptop", "Headphones", "Python Cookbook", "Desk Lamp"}

        # Verify final prices: base_price * multiplier
        assert by_name["Laptop"]["final_price"] == pytest.approx(1200.0)        # 1000 * 1.2
        assert by_name["Headphones"]["final_price"] == pytest.approx(60.0)       # 50 * 1.2
        assert by_name["Python Cookbook"]["final_price"] == pytest.approx(36.0)   # 40 * 0.9
        assert by_name["Desk Lamp"]["final_price"] == pytest.approx(30.0)        # 30 * 1.0

        # Each row should have name, category, base_price, final_price
        for row in rows:
            assert set(row.keys()) == {"name", "category", "base_price", "final_price"}

        # Check export file exists
        export_file = output_dir / "priced_products.json"
        assert export_file.exists(), "Export file was not created"
