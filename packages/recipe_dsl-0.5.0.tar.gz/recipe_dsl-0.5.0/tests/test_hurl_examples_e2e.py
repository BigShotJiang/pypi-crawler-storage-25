"""End-to-end tests for the upstream-Hurl examples corpus.

Each test runs one ``examples/http_*.rdsl`` recipe against the local Flask
fixture (``tests/e2e_fixtures/api_server.py`` + ``hurl_endpoints.py``)
and asserts on the recipe's stdout JSON. New tests are added in lockstep
with new recipes during the Phase P walkthrough — see
``docs/2026-05-02-resumption.md`` §4.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from tests.e2e_fixtures.api_server import start_api_server


EXAMPLES_DIR = Path(__file__).resolve().parent.parent / "examples"


@pytest.fixture(scope="session")
def api_server():
    """Session-scoped Flask server, yields the base URL string."""
    server, port = start_api_server()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


def assert_scalar_output(result: dict, expected) -> None:
    """Assert a scalar OUTPUT recipe produced ``expected``.

    Scalar ``OUTPUT`` auto-wraps to a single-element list in --json mode
    (interpreter.py:execute). This helper unwraps the list before
    comparing so test bodies stay readable when the recipe ends with
    ``OUTPUT some_string`` or ``OUTPUT some_int``.
    """
    assert result["returncode"] == 0, (
        f"recipe failed: stderr={result['stderr']!r}"
    )
    assert result["output"] is not None, (
        f"no JSON on stdout: {result['stdout']!r} stderr={result['stderr']!r}"
    )
    assert isinstance(result["output"], list) and len(result["output"]) == 1, (
        f"expected single-element list (scalar OUTPUT), got {result['output']!r}"
    )
    assert result["output"][0] == expected, (
        f"unexpected scalar output: {result['output'][0]!r} (expected {expected!r})"
    )


def run_recipe(name: str, env: dict) -> dict:
    """Run ``examples/<name>.rdsl`` via the CLI; return parsed result.

    The returned dict has keys ``returncode``, ``stdout``, ``stderr``, and
    ``output`` (the JSON-decoded stdout, or ``None`` if decoding fails).
    """
    recipe = EXAMPLES_DIR / f"{name}.rdsl"
    cmd = [sys.executable, "-m", "recipe_dsl.cli", "run", str(recipe), "--json"]
    full_env = os.environ.copy()
    full_env.update(env)
    proc = subprocess.run(
        cmd, capture_output=True, text=True, env=full_env, timeout=30
    )
    output = None
    if proc.returncode == 0 and proc.stdout.strip():
        try:
            output = json.loads(proc.stdout)
        except json.JSONDecodeError:
            pass
    return {
        "returncode": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
        "output": output,
    }


# ── HTTP Headers (samples.html h3 #1) ─────────────────────────────────────


def test_http_headers(api_server):
    """The recipe sends the headers from the upstream sample; the /news
    endpoint echoes them back; we assert the User-Agent round-trips."""
    result = run_recipe("http_headers", env={"API_BASE": api_server})
    assert_scalar_output(result, "Mozilla/5.0")


# ── Query Params (samples.html h3 #2) ─────────────────────────────────────


def test_http_query_params(api_server):
    """The recipe sends three [Query] params; /news echoes them back as
    a "query" object; we assert the "search" param round-trips with
    spaces preserved (the upstream sample's 'something to search')."""
    result = run_recipe("http_query_params", env={"API_BASE": api_server})
    assert_scalar_output(result, "something to search")


# ── Basic Authentication (samples.html h3 #3) ─────────────────────────────


def test_http_basic_auth(api_server):
    """The recipe sends Basic auth credentials (bob:secret) to /protected
    via the [BasicAuth] section. /protected echoes back the username on
    success; we assert the 'user' field round-trips as 'bob'."""
    result = run_recipe("http_basic_auth", env={"API_BASE": api_server})
    assert_scalar_output(result, "bob")


# ── Passing Data between Requests (samples.html h3 #4) ────────────────────


def test_http_pass_data_between_requests(api_server):
    """First REQUEST POSTs /orders, capturing order.id via EXTRACT_FIELD.
    Second REQUEST GETs /orders/${order_id}. The recipe outputs the id
    that the second response carries, asserting the chained request
    saw the same order the POST created."""
    result = run_recipe(
        "http_pass_data_between_requests", env={"API_BASE": api_server}
    )
    assert_scalar_output(result, "ORD-1001")


# ── Sending HTML Form Data (samples.html h3 #5) ───────────────────────────


def test_http_form_post(api_server):
    """The recipe POSTs four [Form] fields to /contact (one of which
    interpolates a SET-bound token, replacing the upstream {{token}}
    template per G1). /contact echoes them; we assert the email field
    round-trips."""
    result = run_recipe("http_form_post", env={"API_BASE": api_server})
    assert_scalar_output(result, "john.doe@rookie.org")


# ── Sending Multipart Form Data (samples.html h3 #6) ──────────────────────


def test_http_multipart_upload(api_server):
    """The recipe POSTs two text [Multipart] fields to /upload. /upload
    echoes them. We assert field1 round-trips. (File-attachment fields
    are deferred — see the recipe header comment.)"""
    result = run_recipe("http_multipart_upload", env={"API_BASE": api_server})
    assert_scalar_output(result, "value1")


# ── Posting a JSON Body (samples.html h3 #7) ──────────────────────────────


def test_http_json_post(api_server):
    """The recipe POSTs an inline JSON body ({"id":"456","evaluate":true})
    to /api/tests; the endpoint echoes the parsed body; we assert the
    id round-trips as '456'."""
    result = run_recipe("http_json_post", env={"API_BASE": api_server})
    assert_scalar_output(result, "456")


# ── Templating a JSON Body (samples.html h3 #8) ───────────────────────────


def test_http_template_json_body(api_server):
    """The recipe PUTs a JSON body whose four values are substituted from
    SET'd RecipeDSL variables (replacing the upstream {{var}} forms).
    /api/hits echoes the parsed body; we assert key0 (the string slot)
    round-trips as 'apple'."""
    result = run_recipe("http_template_json_body", env={"API_BASE": api_server})
    assert_scalar_output(result, "apple")


# ── Templating an XML Body (samples.html h3 #9) ───────────────────────────


def test_http_template_xml_body(api_server):
    """The recipe POSTs an XML body inside a ```xml multiline fence;
    {{login}}/{{password}} from the upstream sample become ${login}/
    ${password} bound via SET. /echo/post/xml parses the XML and returns
    the Login text; we assert it round-trips as 'alice'."""
    result = run_recipe("http_template_xml_body", env={"API_BASE": api_server})
    assert_scalar_output(result, "alice")


# ── Using GraphQL Query (samples.html h3 #10) ─────────────────────────────


def test_http_graphql(api_server):
    """The recipe POSTs a GraphQL query inside a ```graphql multiline
    fence to /starwars/graphql; endpoint returns a canned star-wars
    response; we assert data.human.name round-trips as 'Luke Skywalker'."""
    result = run_recipe("http_graphql", env={"API_BASE": api_server})
    assert_scalar_output(result, "Luke Skywalker")


# ── Testing Status Code (samples.html h3 #12) ─────────────────────────────


def test_http_status_check(api_server):
    """The recipe GETs /order/435; auto-throw-on-non-2xx means OUTPUT
    only runs on a 2xx response, so successful completion implicitly
    asserts the status code. We assert order_id round-trips as 435."""
    result = run_recipe("http_status_check", env={"API_BASE": api_server})
    assert_scalar_output(result, 435)


# ── Testing REST APIs (samples.html h3 #14) ───────────────────────────────


def test_http_rest_api_check(api_server):
    """The recipe GETs /order, EXTRACT_FIELD calls three body fields
    (validated, userInfo.firstName, hasDevice), ASSERTs on them, and
    OUTPUTs userInfo.firstName. Failure of any ASSERT makes the recipe
    exit non-zero (no JSON output)."""
    result = run_recipe("http_rest_api_check", env={"API_BASE": api_server})
    assert_scalar_output(result, "Franck")


# ── Checking Full Body (samples.html h3 #19) ──────────────────────────────


def test_http_full_body_check(api_server):
    """The recipe GETs /api/cats/123, EXTRACT_FIELD calls three body fields
    (name, species, birthYear), ASSERTs on each, OUTPUTs name."""
    result = run_recipe("http_full_body_check", env={"API_BASE": api_server})
    assert_scalar_output(result, "Purrsloud")


# ── Testing Redirections (samples.html h3 #20) ────────────────────────────


def test_http_redirects_auto(api_server):
    """Recipe GETs /step1 with [Options] location: true; hurl auto-
    follows 301 → /step2 → 301 → /step3 → 200. Final body's 'final'
    field is OUTPUTed."""
    result = run_recipe("http_redirects_auto", env={"API_BASE": api_server})
    assert_scalar_output(result, "step3")


# ── Verbose Mode (samples.html h3 #21) ────────────────────────────────────


def test_http_verbose(api_server):
    """Recipe GETs /api/cats/123 with [Options] very-verbose: true.
    Verbose mode toggles hurl stderr output but doesn't change the
    response envelope; we assert the body field round-trips."""
    result = run_recipe("http_verbose", env={"API_BASE": api_server})
    assert_scalar_output(result, "Purrsloud")


# ── Polling and Retry (samples.html h3 #33) ───────────────────────────────


def test_http_polling_retry(api_server):
    """POST /jobs creates a job. GET /jobs/<id> returns state=PENDING
    twice, then state=COMPLETED. Recipe polls via WHILE + SLEEP +
    EXTRACT_FIELD; we assert the loop terminates with state==COMPLETED."""
    result = run_recipe("http_polling_retry", env={"API_BASE": api_server})
    assert_scalar_output(result, "COMPLETED")


# ── Testing Response Headers (samples.html h3 #13) ────────────────────────


def test_http_response_headers_check(api_server):
    """GET /index.html. Server sets X-Recipe-Marker. Recipe reads it via
    EXTRACT_FIELD ... PATH "@headers.x-recipe-marker"; we assert it
    round-trips. (Demonstrates envelope-mode access enabled by the
    @-prefix on EXTRACT_FIELD.)"""
    result = run_recipe(
        "http_response_headers_check", env={"API_BASE": api_server}
    )
    assert_scalar_output(result, "from-flask")


# ── Testing Set-Cookie Attributes (samples.html h3 #16) ───────────────────


def test_http_set_cookie_attrs(api_server):
    """GET /home. Server sets one Set-Cookie with Value + Expires +
    Secure + HttpOnly + SameSite. Recipe reads the raw header via
    @headers.set-cookie, asserts the JSESSIONID value and several
    attribute substrings (CONTAINS), and OUTPUTs the cookie value
    extracted with INDEX_OF + SUBSTRING. We assert the JSESSIONID
    value round-trips."""
    result = run_recipe("http_set_cookie_attrs", env={"API_BASE": api_server})
    assert_scalar_output(result, "8400BAFE2F66443613DC38AE3D9D6239")


# ── Delaying Requests (samples.html h3 #34) ───────────────────────────────


def test_http_delay(api_server):
    """Recipe GETs /api/cats/123 with [Options] delay: 50ms. Hurl waits
    50ms before sending; response is unchanged. We assert the body
    field round-trips (proving the request still completed)."""
    result = run_recipe("http_delay", env={"API_BASE": api_server})
    assert_scalar_output(result, "Purrsloud")


# ── Testing Endpoint Performance (samples.html h3 #36) ────────────────────


def test_http_performance_check(api_server):
    """Recipe GETs /api/cats/123, reads @time_ms via envelope-mode
    EXTRACT_FIELD, ASSERTs the response was under 5000ms (loose bound
    for CI), OUTPUTs the body field. We assert OUTPUT round-trips."""
    result = run_recipe("http_performance_check", env={"API_BASE": api_server})
    assert_scalar_output(result, "Purrsloud")


# ── Using SOAP APIs (samples.html h3 #37) ─────────────────────────────────


def test_http_soap_request(api_server):
    """Recipe POSTs the upstream SOAP envelope verbatim to /InStock with
    Content-Type and SOAPAction headers. Endpoint returns a SOAP 200.
    Recipe reads @status via envelope mode; OUTPUTs the integer.
    (SOAP-response XML parsing is out of scope — Hurl-mini envelope
    only.)"""
    result = run_recipe("http_soap_request", env={"API_BASE": api_server})
    assert_scalar_output(result, 200)


# ── Capturing and Using a CSRF Token (samples.html h3 #38) ────────────────


def test_http_csrf_token(api_server):
    """First REQUEST GETs /csrf to capture a token (upstream xpath
    transformed to JSON_EXTRACT-able body). Second REQUEST POSTs
    /login?user=toto&password=1234 with the captured X-CSRF-TOKEN
    header. We assert the login response's user round-trips as 'toto'."""
    result = run_recipe("http_csrf_token", env={"API_BASE": api_server})
    assert_scalar_output(result, "toto")
