"""Tests for REQUEST and EXTRACT_FIELD operations.

The REQUEST statement now uses the Hurl-mini block form (a triple-quoted
string after REQUEST); the legacy ``REQUEST <url> METHOD "<verb>"`` form
was removed in Phase J. Coverage of the Hurl-mini parser + backend lives
in:

  - tests/test_hurl_block_parser.py -- parser-level tests.
  - tests/test_hurl_backend.py -- mocked-subprocess backend tests.
  - tests/test_hurl_examples_e2e.py -- end-to-end tests.

This file keeps the EXTRACT_FIELD parser + execution unit tests, which
remain independent of the REQUEST surface change.
"""

from recipe_dsl.ast.nodes import ExtractFieldStatement
from recipe_dsl.grammar.parser import Parser
from recipe_dsl.runtime.interpreter import Interpreter


class TestExtractFieldParsing:
    """Test EXTRACT_FIELD statement parsing."""

    def test_extract_field_simple(self):
        parser = Parser()
        source = '''
PIPELINE test:
  EXTRACT_FIELD response PATH "data.items" INTO items
  OUTPUT results
'''
        ast = parser.parse(source)
        stmt = ast.body[0]
        assert isinstance(stmt, ExtractFieldStatement)
        assert stmt.source.name == "response"
        assert stmt.path.value == "data.items"
        assert stmt.target.name == "items"


class TestExtractFieldExecution:
    """Test EXTRACT_FIELD statement execution (body-mode)."""

    def test_extract_field_execution(self):
        source = '''
PIPELINE test:
  SET json_str = '{"data": {"items": [{"id": 1, "name": "foo"}]}}'
  EXTRACT_FIELD json_str PATH "data.items" INTO items
  OUTPUT items
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        result = interpreter.execute(ast)
        assert result is not None
        assert len(result) == 1
        assert result[0]["id"] == 1
        assert result[0]["name"] == "foo"
