"""Snapshot test: generated TS output matches the committed golden file."""
from pathlib import Path

from recipe_dsl.highlight import generate

GOLDEN_PATH = Path(__file__).parent / "data" / "recipe-dsl.gen.golden.ts"


def test_ts_output_matches_golden():
    actual = generate()
    expected = GOLDEN_PATH.read_text(encoding="utf-8")
    assert actual == expected, (
        "Generated highlight output drifted from golden. "
        "If the change is intentional, regenerate with: "
        "make update-highlight-snapshot"
    )
