"""Tests for EXTRACT operation — regex and CSS modes."""

import pytest
from recipe_dsl.grammar.parser import Parser
from recipe_dsl.runtime.interpreter import Interpreter


class TestExtractParsing:
    """Test parsing of EXTRACT statements."""

    def test_parse_extract_regex_group(self):
        source = '''
PIPELINE test:
  SET page = "ID: 42"
  EXTRACT page MATCH REGEX "ID: (\\d+)" GROUP 1 INTO extracted_id
  OUTPUT extracted_id
'''
        parser = Parser()
        ast = parser.parse(source)
        assert ast.name.name == "test"

    def test_parse_extract_regex_fields(self):
        source = '''
PIPELINE test:
  SET page = "http://example.com/123.htm"
  EXTRACT page MATCH REGEX "http://example\\.com/(\\d+)\\.htm" FIELDS id INTO book_list
  OUTPUT book_list
'''
        parser = Parser()
        ast = parser.parse(source)
        assert ast is not None

    def test_parse_extract_css(self):
        source = '''
PIPELINE test:
  NAVIGATE "http://example.com"
  GET_CONTENT INTO page
  EXTRACT page MATCH CSS "a.link" ATTR "href" INTO links
  OUTPUT links
'''
        parser = Parser()
        ast = parser.parse(source)
        assert ast is not None

    def test_parse_extract_css_no_attr(self):
        """CSS extraction without ATTR returns text content."""
        source = '''
PIPELINE test:
  SET page = "<p>text</p>"
  EXTRACT page MATCH CSS "p" INTO items
  OUTPUT items
'''
        parser = Parser()
        ast = parser.parse(source)
        assert ast is not None


class TestExtractRegexExecution:
    """Test EXTRACT with regex modes."""

    def test_extract_single_value_group(self):
        """EXTRACT ... GROUP N extracts a single value."""
        source = '''
PIPELINE test:
  SET page = "Book ID: **42** found"
  EXTRACT page MATCH REGEX "Book ID: \\*\\*(\\d+)\\*\\*" GROUP 1 INTO book_id
  OUTPUT book_id
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        interpreter.execute(ast)
        assert interpreter.get_scalar("book_id") == "42"

    def test_extract_single_value_group_0(self):
        """GROUP 0 extracts the whole match."""
        source = '''
PIPELINE test:
  SET page = "Price: $99.99 USD"
  EXTRACT page MATCH REGEX "\\$[\\d.]+" GROUP 0 INTO price
  OUTPUT price
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        interpreter.execute(ast)
        assert interpreter.get_scalar("price") == "$99.99"

    def test_extract_list_mode_fields(self):
        """EXTRACT ... FIELDS extracts all matches as a list of records."""
        source = '''
PIPELINE test:
  SET page = "Links: http://example.com/k1.htm and http://example.com/k2.htm and http://example.com/k3.htm"
  EXTRACT page MATCH REGEX "http://example\\.com/k(\\d+)\\.htm" FIELDS id INTO books
  OUTPUT books
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        interpreter.execute(ast)
        books = interpreter.get_scalar("books")
        assert isinstance(books, list)
        assert len(books) == 3
        assert books[0] == {"id": "1"}
        assert books[1] == {"id": "2"}
        assert books[2] == {"id": "3"}

    def test_extract_no_match_group_returns_none(self):
        """If regex doesn't match, GROUP mode stores None."""
        source = '''
PIPELINE test:
  SET page = "no match here"
  EXTRACT page MATCH REGEX "(\\d+)" GROUP 1 INTO result
  OUTPUT result
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        interpreter.execute(ast)
        assert interpreter.get_scalar("result") is None

    def test_extract_no_match_fields_returns_empty_list(self):
        """If regex doesn't match, FIELDS mode stores empty list."""
        source = '''
PIPELINE test:
  SET page = "no urls here"
  EXTRACT page MATCH REGEX "http://example\\.com/(\\d+)" FIELDS id INTO results
  OUTPUT results
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        interpreter.execute(ast)
        results = interpreter.get_scalar("results")
        assert isinstance(results, list)
        assert len(results) == 0


class TestExtractCssExecution:
    """Test EXTRACT with CSS selector mode."""

    def test_extract_css_attr(self, httpx_mock):
        """CSS + ATTR extracts attribute values from matching elements."""
        httpx_mock.add_response(
            url="http://example.com",
            html='<div><a href="/page1">Link1</a><a href="/page2">Link2</a></div>',
        )
        source = '''
PIPELINE test:
  NAVIGATE "http://example.com"
  GET_CONTENT INTO page
  EXTRACT page MATCH CSS "a" ATTR "href" INTO links
  OUTPUT links
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        interpreter.execute(ast)
        links = interpreter.get_scalar("links")
        assert isinstance(links, list)
        assert "/page1" in links
        assert "/page2" in links

    def test_extract_css_text(self, httpx_mock):
        """CSS without ATTR extracts text content."""
        httpx_mock.add_response(
            url="http://example.com",
            html='<ul><li>Item A</li><li>Item B</li></ul>',
        )
        source = '''
PIPELINE test:
  NAVIGATE "http://example.com"
  GET_CONTENT INTO page
  EXTRACT page MATCH CSS "li" INTO items
  OUTPUT items
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        interpreter.execute(ast)
        items = interpreter.get_scalar("items")
        assert isinstance(items, list)
        assert len(items) == 2
        assert "Item A" in items[0]
        assert "Item B" in items[1]
