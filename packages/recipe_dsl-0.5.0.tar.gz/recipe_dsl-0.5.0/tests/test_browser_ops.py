"""Tests for browser operations — CLICK, TYPE, WAIT_FOR, SCROLL.

These tests verify grammar/parsing and interpreter dispatch with a mock backend.
Actual Playwright integration is not tested here.
"""

import pytest
from unittest.mock import MagicMock, patch
from recipe_dsl.grammar.parser import Parser
from recipe_dsl.runtime.interpreter import Interpreter


class TestBrowserOpsParsing:
    """Test parsing of browser operation statements."""

    def test_parse_click(self):
        source = '''
PIPELINE test:
  NAVIGATE "http://example.com"
  CLICK CSS ".btn-submit"
  OUTPUT page
'''
        parser = Parser()
        ast = parser.parse(source)
        assert ast.name.name == "test"

    def test_parse_type(self):
        source = '''
PIPELINE test:
  NAVIGATE "http://example.com"
  TYPE CSS "#search" "hello world"
  OUTPUT page
'''
        parser = Parser()
        ast = parser.parse(source)
        assert ast is not None

    def test_parse_type_with_variable(self):
        source = '''
PIPELINE test:
  SET query = "test"
  NAVIGATE "http://example.com"
  TYPE CSS "#search" query
  OUTPUT page
'''
        parser = Parser()
        ast = parser.parse(source)
        assert ast is not None

    def test_parse_wait_for(self):
        source = '''
PIPELINE test:
  NAVIGATE "http://example.com"
  WAIT_FOR CSS ".results"
  OUTPUT page
'''
        parser = Parser()
        ast = parser.parse(source)
        assert ast is not None

    def test_parse_scroll_down(self):
        source = '''
PIPELINE test:
  NAVIGATE "http://example.com"
  SCROLL DOWN
  OUTPUT page
'''
        parser = Parser()
        ast = parser.parse(source)
        assert ast is not None

    def test_parse_scroll_bottom(self):
        source = '''
PIPELINE test:
  NAVIGATE "http://example.com"
  SCROLL BOTTOM
  OUTPUT page
'''
        parser = Parser()
        ast = parser.parse(source)
        assert ast is not None

    def test_parse_combined_browser_ops(self):
        """A pipeline using multiple browser operations."""
        source = '''
PIPELINE test:
  NAVIGATE "http://example.com"
  WAIT_FOR CSS "#search"
  TYPE CSS "#search" "query"
  CLICK CSS ".submit"
  WAIT_FOR CSS ".results"
  SCROLL DOWN
  GET_CONTENT INTO page
  OUTPUT page
'''
        parser = Parser()
        ast = parser.parse(source)
        assert ast is not None
        # Should have 7 body items
        assert len(ast.body) == 7


class TestBackendAutoSelection:
    """Test that the interpreter auto-selects browser backend when needed."""

    def test_needs_browser_with_click(self):
        """Pipelines with CLICK should require browser backend."""
        from recipe_dsl.ast.nodes import (
            ClickStatement, Pipeline, Identifier, Output, SourceLocation
        )
        from recipe_dsl.runtime.interpreter import Interpreter

        interpreter = Interpreter()
        # The _needs_browser method should detect ClickStatement
        loc = SourceLocation(line=1, column=1)
        body = [ClickStatement(source_location=loc, selector=None)]
        assert interpreter._needs_browser(body)

    def test_no_browser_without_ops(self):
        """Pipelines without browser ops should not require browser backend."""
        from recipe_dsl.ast.nodes import (
            SetStatement, Identifier, Literal, SourceLocation
        )
        from recipe_dsl.runtime.interpreter import Interpreter

        interpreter = Interpreter()
        loc = SourceLocation(line=1, column=1)
        body = [SetStatement(
            source_location=loc,
            variable=Identifier(source_location=loc, name="x"),
            value=Literal(source_location=loc, value=1, literal_type="NUMBER"),
        )]
        assert not interpreter._needs_browser(body)
