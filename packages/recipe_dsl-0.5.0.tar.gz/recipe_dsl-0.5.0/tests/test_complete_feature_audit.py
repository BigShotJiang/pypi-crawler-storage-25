"""Comprehensive Feature Audit for RecipeDSL.

This test file verifies EVERY feature in RecipeDSL works correctly.
Each feature is tested in isolation and in combination with others.
"""

import pytest
from recipe_dsl.grammar.parser import Parser
from recipe_dsl.runtime.interpreter import Interpreter


def parse(code: str):
    """Helper function to parse RecipeDSL code."""
    parser = Parser()
    return parser.parse(code)


def run(code: str, inputs: dict = None):
    """Helper to parse and execute RecipeDSL code, returning interpreter."""
    parser = Parser()
    ast = parser.parse(code)
    interpreter = Interpreter()
    interpreter.execute(ast, inputs=inputs or {})
    return interpreter


class TestMathFunctions:
    """Test all math functions."""

    def test_abs_function(self) -> None:
        """Test ABS function."""
        interp = run('''
        PIPELINE test:
            SET result = ABS(-5)
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 5

    def test_round_function(self) -> None:
        """Test ROUND function."""
        interp = run('''
        PIPELINE test:
            SET result = ROUND(3.14159, 2)
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 3.14

    def test_floor_function(self) -> None:
        """Test FLOOR function."""
        interp = run('''
        PIPELINE test:
            SET result = FLOOR(3.7)
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 3

    def test_ceil_function(self) -> None:
        """Test CEIL function."""
        interp = run('''
        PIPELINE test:
            SET result = CEIL(3.2)
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 4

    def test_mod_function(self) -> None:
        """Test MOD function."""
        interp = run('''
        PIPELINE test:
            SET result = MOD(10, 3)
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 1

    def test_power_function(self) -> None:
        """Test POWER function."""
        interp = run('''
        PIPELINE test:
            SET result = POWER(4, 2)
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 16

    def test_sqrt_function(self) -> None:
        """Test SQRT function."""
        interp = run('''
        PIPELINE test:
            SET result = SQRT(16)
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 4.0

    def test_sign_function(self) -> None:
        """Test SIGN function."""
        interp = run('''
        PIPELINE test:
            SET result = SIGN(-5)
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == -1

    def test_trunc_function(self) -> None:
        """Test TRUNC function."""
        interp = run('''
        PIPELINE test:
            SET result = TRUNC(-3.7)
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == -3

    def test_min_max_val_functions(self) -> None:
        """Test MIN_VAL and MAX_VAL functions."""
        interp = run('''
        PIPELINE test:
            SET min_val = MIN_VAL(5, 10)
            SET max_val = MAX_VAL(5, 10)
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("min_val") == 5
        assert interp.get_scalar("max_val") == 10

    def test_negative_numbers(self) -> None:
        """Test negative number literals."""
        interp = run('''
        PIPELINE test:
            SET result = 20 + -5
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 15


class TestStringFunctions:
    """Test all string functions."""

    def test_upper_function(self) -> None:
        """Test UPPER function."""
        interp = run('''
        PIPELINE test:
            SET result = UPPER("hello")
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == "HELLO"

    def test_lower_function(self) -> None:
        """Test LOWER function."""
        interp = run('''
        PIPELINE test:
            SET result = LOWER("HELLO")
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == "hello"

    def test_trim_function(self) -> None:
        """Test TRIM function."""
        interp = run('''
        PIPELINE test:
            SET result = TRIM("  hello  ")
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == "hello"

    def test_length_function(self) -> None:
        """Test LENGTH function."""
        interp = run('''
        PIPELINE test:
            SET result = LENGTH("hello")
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 5

    def test_substring_function(self) -> None:
        """Test SUBSTRING function."""
        interp = run('''
        PIPELINE test:
            SET result = SUBSTRING("hello", 0, 3)
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == "hel"

    def test_replace_all_function(self) -> None:
        """Test REPLACE_ALL function."""
        interp = run('''
        PIPELINE test:
            SET result = REPLACE_ALL("hello world", "o", "0")
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == "hell0 w0rld"

    def test_concat_function(self) -> None:
        """Test CONCAT function."""
        interp = run('''
        PIPELINE test:
            SET first = "John"
            SET last = "Doe"
            SET result = CONCAT(first, " ", last)
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == "John Doe"

    def test_pad_left_function(self) -> None:
        """Test PAD_LEFT function."""
        interp = run('''
        PIPELINE test:
            SET result = PAD_LEFT("42", 5, "0")
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == "00042"


class TestTypeCasting:
    """Test type casting functions."""

    def test_to_int_function(self) -> None:
        """Test TO_INT function."""
        interp = run('''
        PIPELINE test:
            SET result = TO_INT("42")
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 42
        assert isinstance(interp.get_scalar("result"), int)

    def test_to_string_function(self) -> None:
        """Test TO_STRING function."""
        interp = run('''
        PIPELINE test:
            SET result = TO_STRING(42)
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == "42"

    def test_to_decimal_function(self) -> None:
        """Test TO_DECIMAL function."""
        interp = run('''
        PIPELINE test:
            SET result = TO_DECIMAL("3.14")
            OUTPUT data
        ''', {"data": []})
        assert abs(interp.get_scalar("result") - 3.14) < 0.001

    def test_to_bool_function(self) -> None:
        """Test TO_BOOL function."""
        interp = run('''
        PIPELINE test:
            SET result = TO_BOOL("true")
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") is True


class TestControlFlow:
    """Test control flow statements."""

    def test_set_statement_with_booleans(self) -> None:
        """Test SET with TRUE/FALSE."""
        interp = run('''
        PIPELINE test:
            SET is_active = TRUE
            SET is_deleted = FALSE
            SET count = 0
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("is_active") is True
        assert interp.get_scalar("is_deleted") is False
        assert interp.get_scalar("count") == 0

    def test_if_else_statement(self) -> None:
        """Test IF/ELSE statement."""
        interp = run('''
        PIPELINE test:
            SET count = 5
            SET result = 0
            IF count > 3:
                SET result = 1
            ELSE:
                SET result = 2
            END
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 1

    def test_for_each_statement(self) -> None:
        """Test FOR_EACH loop."""
        interp = run('''
        PIPELINE test:
            SET total = 0
            FOR_EACH item IN data:
                SET total = total + 1
            END
            OUTPUT data
        ''', {"data": [{"id": 1}, {"id": 2}, {"id": 3}]})
        assert interp.get_scalar("total") == 3

    def test_while_statement(self) -> None:
        """Test WHILE loop."""
        interp = run('''
        PIPELINE test:
            SET counter = 0
            WHILE counter < 5:
                SET counter = counter + 1
            END
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("counter") == 5

    def test_break_statement(self) -> None:
        """Test BREAK in loop."""
        interp = run('''
        PIPELINE test:
            SET counter = 0
            WHILE counter < 100:
                SET counter = counter + 1
                IF counter == 3:
                    BREAK
                END
            END
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("counter") == 3

    def test_continue_statement(self) -> None:
        """Test CONTINUE in loop."""
        interp = run('''
        PIPELINE test:
            SET sum = 0
            SET counter = 0
            WHILE counter < 5:
                SET counter = counter + 1
                IF counter == 3:
                    CONTINUE
                END
                SET sum = sum + counter
            END
            OUTPUT data
        ''', {"data": []})
        # sum = 1 + 2 + 4 + 5 = 12 (skipping 3)
        assert interp.get_scalar("sum") == 12

    def test_return_statement(self) -> None:
        """Test RETURN statement."""
        interp = run('''
        PIPELINE test:
            SET x = 1
            RETURN data
            SET x = 2
            OUTPUT data
        ''', {"data": [{"id": 1}]})
        assert interp.get_scalar("x") == 1


class TestPrintAndLog:
    """Test PRINT and LOG statements."""

    def test_print_statement(self) -> None:
        """Test PRINT statement."""
        run('''
        PIPELINE test:
            PRINT "Hello World"
            PRINT 42
            OUTPUT data
        ''', {"data": []})

    def test_log_statements(self) -> None:
        """Test LOG_INFO, LOG_WARN, LOG_ERROR, LOG_DEBUG."""
        run('''
        PIPELINE test:
            LOG_INFO "Info message"
            LOG_WARN "Warning message"
            LOG_ERROR "Error message"
            LOG_DEBUG "Debug message"
            OUTPUT data
        ''', {"data": []})


class TestComments:
    """Test comment syntax."""

    def test_single_line_comments(self) -> None:
        """Test -- comments are ignored."""
        interp = run('''
        -- This is a comment
        PIPELINE test:
            -- Another comment
            SET x = 5
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("x") == 5


class TestArithmetic:
    """Test arithmetic operations."""

    def test_addition(self) -> None:
        """Test + operator."""
        interp = run('''
        PIPELINE test:
            SET result = 20 + 10
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 30

    def test_subtraction(self) -> None:
        """Test - operator."""
        interp = run('''
        PIPELINE test:
            SET result = 20 - 5
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 15

    def test_multiplication(self) -> None:
        """Test * operator."""
        interp = run('''
        PIPELINE test:
            SET result = 20 * 2
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 40

    def test_division(self) -> None:
        """Test / operator."""
        interp = run('''
        PIPELINE test:
            SET result = 20 / 2
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 10

    def test_arithmetic_with_parentheses(self) -> None:
        """Test parentheses in arithmetic."""
        interp = run('''
        PIPELINE test:
            SET result = (5 + 10) * 2
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 30


class TestEdgeCases:
    """Test edge cases and boundary conditions."""

    def test_large_numbers(self) -> None:
        """Test with large numbers."""
        interp = run('''
        PIPELINE test:
            SET result = 1000000000000000 * 2
            OUTPUT data
        ''', {"data": []})
        assert interp.get_scalar("result") == 2 * 10**15

    def test_decimal_precision(self) -> None:
        """Test decimal precision in calculations."""
        interp = run('''
        PIPELINE test:
            SET result = ROUND(10.0 / 3, 4)
            OUTPUT data
        ''', {"data": []})
        assert abs(interp.get_scalar("result") - 3.3333) < 0.0001
