"""Tests for the regex translator (Python re -> JS regex)."""
import re

import pytest

from recipe_dsl.highlight.errors import UnsupportedRegexError
from recipe_dsl.highlight.regex_translator import translate


def test_identity_on_simple_regex():
    js_src, js_flags = translate("NAME", r"[a-zA-Z_][a-zA-Z0-9_]*", flags=())
    assert js_src == r"[a-zA-Z_][a-zA-Z0-9_]*"
    assert js_flags == ""


def test_ignorecase_flag_translates_to_i():
    _src, js_flags = translate("FAKE", r"foo", flags=(re.IGNORECASE,))
    assert js_flags == "i"


def test_multiline_flag_translates_to_m():
    _src, js_flags = translate("FAKE", r"foo", flags=(re.MULTILINE,))
    assert js_flags == "m"


def test_dotall_flag_translates_to_s():
    _src, js_flags = translate("FAKE", r"foo", flags=(re.DOTALL,))
    assert js_flags == "s"


def test_multiple_flags_concat():
    _src, js_flags = translate("FAKE", r"foo", flags=(re.IGNORECASE, re.DOTALL))
    assert sorted(js_flags) == ["i", "s"]


def test_unrecognized_flag_raises():
    with pytest.raises(UnsupportedRegexError) as exc:
        translate("FAKE", r"foo", flags=(re.UNICODE,))
    assert "FAKE" in str(exc.value)


def test_named_group_rewritten_to_js_form():
    src, _ = translate("FAKE", r"(?P<word>\w+)", flags=())
    assert src == r"(?<word>\w+)"


def test_named_backreference_rewritten():
    src, _ = translate("FAKE", r"(?P<x>\w+)\s+(?P=x)", flags=())
    assert src == r"(?<x>\w+)\s+\k<x>"


def test_anchor_a_rewritten_to_caret():
    src, _ = translate("FAKE", r"\Afoo", flags=())
    assert src == r"^foo"


def test_anchor_z_rewritten_to_dollar():
    src, _ = translate("FAKE", r"foo\Z", flags=())
    assert src == r"foo$"


def test_inline_comment_stripped():
    src, _ = translate("FAKE", r"foo(?# this is a comment)bar", flags=())
    assert src == r"foobar"


def test_posix_alpha_rewritten():
    src, _ = translate("FAKE", r"[[:alpha:]]+", flags=())
    assert src == r"[A-Za-z]+"


def test_posix_digit_rewritten():
    src, _ = translate("FAKE", r"[[:digit:]]+", flags=())
    assert src == r"[0-9]+"


def test_posix_alnum_rewritten():
    src, _ = translate("FAKE", r"[[:alnum:]]+", flags=())
    assert src == r"[A-Za-z0-9]+"


def test_verbose_flag_strips_whitespace_and_comments():
    src, flags_out = translate(
        "FAKE",
        r"""
        foo   # this is a comment
        bar
        """,
        flags=(re.VERBOSE,),
    )
    assert src == r"foobar"
    assert flags_out == ""


def test_unknown_posix_class_raises():
    with pytest.raises(UnsupportedRegexError) as exc:
        translate("FAKE", r"[[:weird:]]", flags=())
    assert "weird" in str(exc.value).lower() or "posix" in str(exc.value).lower()
