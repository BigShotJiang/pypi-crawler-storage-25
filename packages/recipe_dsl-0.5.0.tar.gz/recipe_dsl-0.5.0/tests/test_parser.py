"""Tests for the RecipeDSL parser."""

import pytest
from lark.exceptions import LarkError

from recipe_dsl.ast.nodes import (
    Identifier,
    Output,
    Pipeline,
)
from recipe_dsl.grammar.parser import Parser


class TestParserBasic:
    """Basic parser functionality tests."""

    def test_parse_minimal_pipeline(self) -> None:
        """Parse a minimal pipeline from string."""
        parser = Parser()
        source = """
        PIPELINE minimal:
            OUTPUT foo
        """
        ast = parser.parse(source)

        assert isinstance(ast, Pipeline)
        assert ast.name.name == "minimal"
        assert len(ast.inputs) == 0

    def test_parse_pipeline_with_set(self) -> None:
        """Parse a pipeline with SET statement."""
        parser = Parser()
        source = """
        PIPELINE test_set:
            SET result = 42
            OUTPUT data
        """
        ast = parser.parse(source)

        assert isinstance(ast, Pipeline)
        assert len(ast.body) == 1

    def test_parse_pipeline_with_if(self) -> None:
        """Parse a pipeline with IF statement."""
        parser = Parser()
        source = """
        PIPELINE test_if:
            SET x = 10
            IF x > 5:
                SET y = 1
            END
            OUTPUT data
        """
        ast = parser.parse(source)

        assert isinstance(ast, Pipeline)
        assert len(ast.body) == 2  # SET + IF


class TestParserSourceLocations:
    """Source location tracking tests."""

    def test_pipeline_has_location(self) -> None:
        """Pipeline nodes should have source locations."""
        parser = Parser()
        source = "PIPELINE test:\n    OUTPUT x"
        ast = parser.parse(source)

        assert ast.source_location.line == 1

    def test_identifier_has_location(self) -> None:
        """Identifiers should have source locations."""
        parser = Parser()
        source = "PIPELINE test:\n    OUTPUT x"
        ast = parser.parse(source)

        assert ast.name.source_location.line == 1


class TestParserErrors:
    """Parser error handling tests."""

    def test_missing_output(self) -> None:
        """Pipeline without OUTPUT should fail to parse."""
        parser = Parser()
        source = """
        PIPELINE broken:
        """
        with pytest.raises(LarkError):
            parser.parse(source)

    def test_invalid_syntax(self) -> None:
        """Invalid syntax should raise a parse error."""
        parser = Parser()
        with pytest.raises(LarkError):
            parser.parse("THIS IS NOT VALID")
