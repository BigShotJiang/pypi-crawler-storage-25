"""Tests for the SLEEP statement."""
import time

from recipe_dsl.ast.nodes import SleepStatement
from recipe_dsl.grammar.parser import Parser
from recipe_dsl.runtime.interpreter import Interpreter


def test_sleep_parses_ms():
    src = """
PIPELINE p:
  SET x = 1
  SLEEP 50ms
  OUTPUT x
"""
    ast = Parser().parse(src)
    sleeps = [s for s in ast.body if isinstance(s, SleepStatement)]
    assert len(sleeps) == 1
    assert sleeps[0].duration_ms == 50


def test_sleep_parses_s():
    src = """
PIPELINE p:
  SET x = 1
  SLEEP 2s
  OUTPUT x
"""
    ast = Parser().parse(src)
    sleeps = [s for s in ast.body if isinstance(s, SleepStatement)]
    assert sleeps[0].duration_ms == 2000


def test_sleep_executes_for_at_least_the_requested_duration():
    src = """
PIPELINE p:
  SET x = 1
  SLEEP 50ms
  OUTPUT x
"""
    ast = Parser().parse(src)
    interp = Interpreter()
    t0 = time.monotonic()
    interp.execute(ast)
    elapsed = time.monotonic() - t0
    assert elapsed >= 0.04, f"sleep was too short: {elapsed*1000:.0f}ms"
