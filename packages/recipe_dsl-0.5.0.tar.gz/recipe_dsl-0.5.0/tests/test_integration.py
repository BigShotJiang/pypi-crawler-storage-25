"""Integration tests — parse and execute complete recipe examples."""

from pathlib import Path

import pytest
from recipe_dsl.grammar.parser import Parser
from recipe_dsl.runtime.interpreter import Interpreter

EXAMPLES_DIR = Path(__file__).parent.parent / "examples"


class TestInlineRecipes:
    """Test complete inline recipes covering multiple operations."""

    def test_navigate_extract_pipeline(self, httpx_mock):
        """Full pipeline: NAVIGATE -> GET_CONTENT -> EXTRACT -> OUTPUT."""
        httpx_mock.add_response(
            url="http://example.com/catalog",
            html="""
            <html><body>
            <a href="/item/100">Item A</a>
            <a href="/item/200">Item B</a>
            <a href="/item/300">Item C</a>
            </body></html>
            """,
        )
        source = '''
PIPELINE scrape_catalog:
  NAVIGATE "http://example.com/catalog"
  GET_CONTENT INTO page
  EXTRACT page
    MATCH REGEX "/item/(\\d+)"
    FIELDS id
    INTO items
  OUTPUT items
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        result = interpreter.execute(ast)
        assert result is not None
        assert len(result) == 3
        assert result[0] == {"id": "100"}
        assert result[1] == {"id": "200"}
        assert result[2] == {"id": "300"}

    def test_filter_tabular_data(self):
        """FILTER with tabular input data."""
        source = '''
PIPELINE filter_range:
  STEP do_filter:
    FILTER data
    WHERE x > 3
    INTO filtered
  OUTPUT filtered
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={"data": [{"x": 1}, {"x": 2}, {"x": 3}, {"x": 4}, {"x": 5}]},
        )
        assert result is not None
        assert len(result) == 2
        assert result[0] == {"x": 4}
        assert result[1] == {"x": 5}

    def test_extract_regex_pipeline(self, httpx_mock):
        """Extract list via regex, output directly."""
        httpx_mock.add_response(
            url="http://example.com/links",
            html='<p>Files: http://dl.example.com/a.pdf and http://dl.example.com/b.epub</p>',
        )
        source = '''
PIPELINE extract_downloads:
  NAVIGATE "http://example.com/links"
  GET_CONTENT INTO page
  EXTRACT page
    MATCH REGEX "http://dl\\.example\\.com/([^\\s.]+)\\.(pdf|epub)"
    FIELDS name, ext
    INTO downloads
  OUTPUT downloads
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        result = interpreter.execute(ast)
        assert result is not None
        assert len(result) == 2
        assert result[0]["name"] == "a"
        assert result[0]["ext"] == "pdf"
        assert result[1]["name"] == "b"
        assert result[1]["ext"] == "epub"

    def test_css_extract_integration(self, httpx_mock):
        """CSS selector extraction in an end-to-end pipeline."""
        httpx_mock.add_response(
            url="http://example.com/page",
            html='<ul><li><a href="/p/1">Page 1</a></li><li><a href="/p/2">Page 2</a></li></ul>',
        )
        source = '''
PIPELINE css_extract:
  NAVIGATE "http://example.com/page"
  GET_CONTENT INTO page
  EXTRACT page MATCH CSS "a" ATTR "href" INTO links
  OUTPUT links
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        result = interpreter.execute(ast)
        assert result is not None
        assert len(result) == 2
        assert result[0] == "/p/1"
        assert result[1] == "/p/2"
