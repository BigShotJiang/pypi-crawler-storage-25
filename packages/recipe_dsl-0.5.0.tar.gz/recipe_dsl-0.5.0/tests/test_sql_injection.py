"""SQL injection protection tests for QUERY.

These tests exercise the safety boundary added in
docs/2026-05-02-sql-injection-protection-design.md.
"""

import pytest
from sqlalchemy import create_engine, text

from recipe_dsl.grammar.parser import Parser
from recipe_dsl.runtime.interpreter import Interpreter
from recipe_dsl.runtime.interpreter import RuntimeError as InterpreterRuntimeError


def _seed_users(db_url: str) -> None:
    """Create a `users` table with a benign and an admin row."""
    engine = create_engine(db_url)
    with engine.begin() as conn:
        conn.execute(text(
            "CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, role TEXT)"
        ))
        conn.execute(
            text("INSERT INTO users (id, name, role) VALUES (:id, :name, :role)"),
            [
                {"id": 1, "name": "alice", "role": "user"},
                {"id": 2, "name": "admin", "role": "admin"},
            ],
        )
    engine.dispose()


def test_injection_via_embedded_quote_does_not_leak_admin_row(tmp_path):
    """A target value containing `' OR name='admin` must not leak the admin row.

    Pre-fix: the auto-quote wrapper does not escape embedded single quotes,
    so the substituted SQL becomes
        WHERE name = 'x' OR name='admin'
    and the admin row is returned.

    Post-fix: the value is bound as an opaque string; no row matches.
    """
    db_path = tmp_path / "users.db"
    db_url = f"sqlite:///{db_path}"
    _seed_users(db_url)

    source = '''
PIPELINE test:
  SET target = "x' OR name='admin"
  QUERY db_url "SELECT id, name FROM users WHERE name = ${target}" INTO results
  OUTPUT results
'''
    parser = Parser()
    ast = parser.parse(source)
    interpreter = Interpreter()
    result = interpreter.execute(ast, inputs={"db_url": db_url})

    assert result == [], (
        f"SQL injection leaked unauthorized rows: {result}. "
        f"Expected empty result for non-matching target string."
    )


def test_embedded_quote_in_benign_value_matches(tmp_path):
    """A benign value like `O'Brien` must match the row exactly."""
    db_path = tmp_path / "users.db"
    db_url = f"sqlite:///{db_path}"
    engine = create_engine(db_url)
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE people (name TEXT)"))
        conn.execute(
            text("INSERT INTO people (name) VALUES (:n)"),
            [{"n": "O'Brien"}, {"n": "Smith"}],
        )
    engine.dispose()

    source = '''
PIPELINE test:
  SET who = "O'Brien"
  QUERY db_url "SELECT name FROM people WHERE name = ${who}" INTO results
  OUTPUT results
'''
    parser = Parser()
    ast = parser.parse(source)
    interpreter = Interpreter()
    result = interpreter.execute(ast, inputs={"db_url": db_url})

    assert result == [{"name": "O'Brien"}]


def test_none_value_binds_as_sql_null(tmp_path):
    """A None scalar must bind as SQL NULL, not the string 'None'."""
    db_path = tmp_path / "n.db"
    db_url = f"sqlite:///{db_path}"
    engine = create_engine(db_url)
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE t (v TEXT)"))
        conn.execute(text("INSERT INTO t (v) VALUES (NULL), ('None'), ('x')"))
    engine.dispose()

    source = '''
PIPELINE test:
  QUERY db_url "SELECT v FROM t WHERE v IS ${probe} OR v = ${probe}" INTO results
  OUTPUT results
'''
    parser = Parser()
    ast = parser.parse(source)
    interpreter = Interpreter()
    result = interpreter.execute(
        ast, inputs={"db_url": db_url, "probe": None}
    )

    # The NULL row matches `v IS :probe` (NULL IS NULL).
    # The literal 'None' row must NOT match.
    assert {row["v"] for row in result} == {None}


def test_int_and_float_values_bind_correctly(tmp_path):
    """Numeric scalars round-trip through the bind path."""
    db_path = tmp_path / "n2.db"
    db_url = f"sqlite:///{db_path}"
    engine = create_engine(db_url)
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE m (i INTEGER, f REAL)"))
        conn.execute(text("INSERT INTO m (i, f) VALUES (1, 1.5), (2, 2.5)"))
    engine.dispose()

    source = '''
PIPELINE test:
  SET wanted = 2
  QUERY db_url "SELECT i, f FROM m WHERE i = ${wanted}" INTO results
  OUTPUT results
'''
    parser = Parser()
    ast = parser.parse(source)
    interpreter = Interpreter()
    result = interpreter.execute(ast, inputs={"db_url": db_url})
    assert result == [{"i": 2, "f": 2.5}]


def test_list_value_expands_for_in_clause(tmp_path):
    """A list scalar must bind as an expanding parameter, usable in IN."""
    db_path = tmp_path / "in.db"
    db_url = f"sqlite:///{db_path}"
    engine = create_engine(db_url)
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE items (id INTEGER, label TEXT)"))
        conn.execute(text(
            "INSERT INTO items (id, label) VALUES (1, 'a'), (2, 'b'), (3, 'c')"
        ))
    engine.dispose()

    # Grammar does not support inline list literals (SET ids = [1, 3] fails to
    # parse), so the list is supplied via inputs= and referenced directly.
    source = '''
PIPELINE test:
  QUERY db_url "SELECT id, label FROM items WHERE id IN ${ids} ORDER BY id" INTO results
  OUTPUT results
'''
    parser = Parser()
    ast = parser.parse(source)
    interpreter = Interpreter()
    result = interpreter.execute(ast, inputs={"db_url": db_url, "ids": [1, 3]})

    assert result == [
        {"id": 1, "label": "a"},
        {"id": 3, "label": "c"},
    ]


def test_structural_position_raises_wrapped_error(tmp_path):
    """${var} in a table-name position must raise a RuntimeError with hint."""
    db_path = tmp_path / "s.db"
    db_url = f"sqlite:///{db_path}"
    engine = create_engine(db_url)
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE legit (x INTEGER)"))
    engine.dispose()

    source = '''
PIPELINE test:
  SET tbl = "legit"
  QUERY db_url "SELECT * FROM ${tbl}" INTO results
  OUTPUT results
'''
    parser = Parser()
    ast = parser.parse(source)
    interpreter = Interpreter()

    with pytest.raises(RuntimeError) as excinfo:
        interpreter.execute(ast, inputs={"db_url": db_url})

    msg = str(excinfo.value)
    assert "QUERY execution failed" in msg
    assert "structural positions" in msg
    assert "IF/ELSE" in msg


def test_dict_value_raises_unsupported_type(tmp_path):
    """A dict scalar must raise a clear unsupported-type error."""
    db_path = tmp_path / "d.db"
    db_url = f"sqlite:///{db_path}"
    engine = create_engine(db_url)
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE t (x INTEGER)"))
    engine.dispose()

    source = '''
PIPELINE test:
  QUERY db_url "SELECT * FROM t WHERE x = ${blob}" INTO results
  OUTPUT results
'''
    parser = Parser()
    ast = parser.parse(source)
    interpreter = Interpreter()

    with pytest.raises(InterpreterRuntimeError) as excinfo:
        interpreter.execute(ast, inputs={"db_url": db_url, "blob": {"k": 1}})
    assert "unsupported type dict" in str(excinfo.value)


def test_missing_variable_message_unchanged(tmp_path):
    """The pre-existing missing-variable error message is preserved."""
    db_path = tmp_path / "m.db"
    db_url = f"sqlite:///{db_path}"
    engine = create_engine(db_url)
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE t (x INTEGER)"))
    engine.dispose()

    source = '''
PIPELINE test:
  QUERY db_url "SELECT * FROM t WHERE x = ${unknown}" INTO results
  OUTPUT results
'''
    parser = Parser()
    ast = parser.parse(source)
    interpreter = Interpreter()

    with pytest.raises(InterpreterRuntimeError) as excinfo:
        interpreter.execute(ast, inputs={"db_url": db_url})
    assert "Variable 'unknown' not found for query interpolation" in str(excinfo.value)


def test_repeated_reference_binds_once(tmp_path):
    """A var referenced twice in the same SQL is bound once and reused."""
    db_path = tmp_path / "r.db"
    db_url = f"sqlite:///{db_path}"
    engine = create_engine(db_url)
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE t (a INTEGER, b INTEGER)"))
        conn.execute(text("INSERT INTO t (a, b) VALUES (5, 9), (5, 5), (1, 5)"))
    engine.dispose()

    source = '''
PIPELINE test:
  SET v = 5
  QUERY db_url "SELECT a, b FROM t WHERE a = ${v} OR b = ${v} ORDER BY a, b" INTO results
  OUTPUT results
'''
    parser = Parser()
    ast = parser.parse(source)
    interpreter = Interpreter()
    result = interpreter.execute(ast, inputs={"db_url": db_url})
    assert result == [
        {"a": 1, "b": 5},
        {"a": 5, "b": 5},
        {"a": 5, "b": 9},
    ]


def test_connection_string_interpolation_unchanged(tmp_path):
    """${VAR} in the connection-string position still works as text interpolation."""
    db_path = tmp_path / "c.db"
    db_url = f"sqlite:///{db_path}"
    engine = create_engine(db_url)
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE t (x INTEGER)"))
        conn.execute(text("INSERT INTO t (x) VALUES (42)"))
    engine.dispose()

    source = '''
PIPELINE test:
  QUERY "${DB_URL}" "SELECT x FROM t" INTO results
  OUTPUT results
'''
    parser = Parser()
    ast = parser.parse(source)
    interpreter = Interpreter()
    result = interpreter.execute(ast, inputs={"DB_URL": db_url})
    assert result == [{"x": 42}]
