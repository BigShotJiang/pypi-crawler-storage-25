"""Tests for NAVIGATE and GET_CONTENT operations."""

import pytest
from recipe_dsl.grammar.parser import Parser
from recipe_dsl.runtime.interpreter import Interpreter


class TestNavigateParsing:
    """Test parsing of NAVIGATE and GET_CONTENT statements."""

    def test_parse_navigate_with_string(self):
        source = '''
PIPELINE test:
  NAVIGATE "http://example.com"
  GET_CONTENT INTO page
  OUTPUT page
'''
        parser = Parser()
        ast = parser.parse(source)
        assert ast.name.name == "test"

    def test_parse_navigate_with_variable(self):
        source = '''
PIPELINE test:
  SET my_url = "http://example.com"
  NAVIGATE my_url
  GET_CONTENT INTO page
  OUTPUT page
'''
        parser = Parser()
        ast = parser.parse(source)
        assert ast is not None


class TestNavigateExecution:
    """Test execution of NAVIGATE and GET_CONTENT with mocked HTTP."""

    def test_navigate_and_get_content(self, httpx_mock):
        httpx_mock.add_response(
            url="http://example.com",
            html="<h1>Hello</h1><p>World</p>",
        )
        source = '''
PIPELINE test:
  NAVIGATE "http://example.com"
  GET_CONTENT INTO page
  OUTPUT page
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        interpreter.execute(ast)
        page = interpreter.get_scalar("page")
        assert "Hello" in page
        assert "World" in page

    def test_navigate_with_variable_url(self, httpx_mock):
        httpx_mock.add_response(
            url="http://example.com/test",
            html="<h1>Test Page</h1>",
        )
        source = '''
PIPELINE test:
  SET target = "http://example.com/test"
  NAVIGATE target
  GET_CONTENT INTO page
  OUTPUT page
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        interpreter.execute(ast)
        page = interpreter.get_scalar("page")
        assert "Test Page" in page

    def test_navigate_converts_html_to_markdown(self, httpx_mock):
        httpx_mock.add_response(
            url="http://example.com",
            html="<h1>Title</h1><ul><li>Item 1</li><li>Item 2</li></ul>",
        )
        source = '''
PIPELINE test:
  NAVIGATE "http://example.com"
  GET_CONTENT INTO page
  OUTPUT page
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        interpreter.execute(ast)
        page = interpreter.get_scalar("page")
        # markdownify should produce markdown-style output
        assert "Title" in page
        assert "Item 1" in page

    def test_navigate_stores_last_html(self, httpx_mock):
        """GET_CONTENT returns markdown, but the raw HTML is preserved internally."""
        httpx_mock.add_response(
            url="http://example.com",
            html="<div class='content'><p>Raw HTML</p></div>",
        )
        source = '''
PIPELINE test:
  NAVIGATE "http://example.com"
  GET_CONTENT INTO page
  OUTPUT page
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        interpreter.execute(ast)
        # The backend should have stored the raw HTML
        assert interpreter._backend is not None
        assert "<div" in interpreter._backend.get_html()
