"""Tests for highlight-generator exception types."""
import pytest

from recipe_dsl.highlight.errors import (
    EmptyGrammarError,
    HighlightError,
    UnsupportedRegexError,
)


def test_unsupported_regex_error_message_includes_terminal_and_construct():
    err = UnsupportedRegexError("FAKE", "named group")
    assert "FAKE" in str(err)
    assert "named group" in str(err)


def test_unsupported_regex_error_with_detail():
    err = UnsupportedRegexError("FAKE", "named group", "use unnamed group")
    s = str(err)
    assert "FAKE" in s
    assert "named group" in s
    assert "use unnamed group" in s


def test_unsupported_regex_error_is_highlight_error():
    assert issubclass(UnsupportedRegexError, HighlightError)


def test_empty_grammar_error_is_highlight_error():
    assert issubclass(EmptyGrammarError, HighlightError)


def test_unsupported_regex_error_can_be_raised():
    with pytest.raises(UnsupportedRegexError):
        raise UnsupportedRegexError("FAKE", "POSIX class")
