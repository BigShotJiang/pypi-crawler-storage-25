"""Tests for the named-terminal extractor."""
from recipe_dsl.highlight.loader import load_grammar
from recipe_dsl.highlight.named_terminals import (
    NAMED_TERMINAL_CLASS,
    extract_named_terminals,
)


def test_extracts_name_as_variable():
    parser = load_grammar()
    entries = extract_named_terminals(parser)
    name_entries = [e for e in entries if e.prism_class == "variable"]
    assert len(name_entries) == 1
    import re
    assert re.fullmatch(name_entries[0].pattern, "users")


def test_extracts_quoted_string_as_string_with_greedy():
    parser = load_grammar()
    entries = extract_named_terminals(parser)
    string_entries = [
        e for e in entries
        if e.prism_class == "string" and e.inside_lang is None
    ]
    assert len(string_entries) == 1
    assert string_entries[0].greedy is True


def test_extracts_number_and_signed_number_as_number():
    parser = load_grammar()
    entries = extract_named_terminals(parser)
    number_entries = [e for e in entries if e.prism_class == "number"]
    # NUMBER, SIGNED_NUMBER, DURATION (e.g. `100ms`, `5s`).
    assert len(number_entries) == 3


def test_extracts_comment_as_comment():
    parser = load_grammar()
    entries = extract_named_terminals(parser)
    comment_entries = [e for e in entries if e.prism_class == "comment"]
    assert len(comment_entries) == 1


def test_extracts_sql_string_with_embed_metadata():
    parser = load_grammar()
    entries = extract_named_terminals(parser)
    sql_entries = [e for e in entries if e.prism_class == "sql-string"]
    assert len(sql_entries) == 1
    e = sql_entries[0]
    assert e.inside_lang == "sql"
    assert e.alias == "string"
    assert e.greedy is True


def test_extracts_css_string_with_embed_metadata():
    parser = load_grammar()
    entries = extract_named_terminals(parser)
    css_entries = [e for e in entries if e.prism_class == "css-string"]
    assert len(css_entries) == 1
    e = css_entries[0]
    assert e.inside_lang == "css"
    assert e.alias == "string"
    assert e.greedy is True


def test_extracts_regex_string_with_embed_metadata():
    parser = load_grammar()
    entries = extract_named_terminals(parser)
    regex_entries = [e for e in entries if e.prism_class == "regex-string"]
    assert len(regex_entries) == 1
    e = regex_entries[0]
    assert e.inside_lang == "regex"
    assert e.alias == "string"


def test_named_terminal_class_map_is_explicit():
    assert NAMED_TERMINAL_CLASS["NAME"] == "variable"
    assert NAMED_TERMINAL_CLASS["NUMBER"] == "number"
    assert NAMED_TERMINAL_CLASS["SIGNED_NUMBER"] == "number"
    assert NAMED_TERMINAL_CLASS["QUOTED_STRING"] == "string"
    assert NAMED_TERMINAL_CLASS["COMMENT"] == "comment"


def test_unknown_named_terminal_warns_and_skips(capsys):
    class FakePattern:
        def __init__(self, value):
            self.type = "re"
            self.value = value
            self.flags = ()

    class FakeTerminal:
        def __init__(self, name, value):
            self.name = name
            self.pattern = FakePattern(value)
            self.priority = 0

    class FakeParser:
        terminals = [FakeTerminal("UNKNOWN_FOO", r"\d+")]

    entries = extract_named_terminals(FakeParser())
    assert all(e.prism_class != "UNKNOWN_FOO" for e in entries)
    captured = capsys.readouterr()
    assert "UNKNOWN_FOO" in captured.err
