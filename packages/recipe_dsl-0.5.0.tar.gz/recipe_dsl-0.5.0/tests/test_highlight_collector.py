"""Tests for the highlight literal collector."""
from recipe_dsl.highlight.collector import LiteralUsage, collect_literals
from recipe_dsl.highlight.loader import load_grammar


def test_collects_pipeline_keyword():
    parser = load_grammar()
    literals = collect_literals(parser)
    assert "PIPELINE" in literals
    assert literals["PIPELINE"].bareword_form is True
    assert literals["PIPELINE"].function_call_form is False


def test_collects_upper_as_function_call_form():
    parser = load_grammar()
    literals = collect_literals(parser)
    assert "UPPER" in literals
    assert literals["UPPER"].function_call_form is True


def test_collects_join_with_both_forms():
    parser = load_grammar()
    literals = collect_literals(parser)
    assert "JOIN" in literals
    assert literals["JOIN"].function_call_form is True
    assert literals["JOIN"].bareword_form is True


def test_collects_open_paren_punctuation():
    parser = load_grammar()
    literals = collect_literals(parser)
    assert "(" in literals
    assert literals["("].bareword_form is True


def test_does_not_emit_named_terminal_regex_as_literal():
    parser = load_grammar()
    literals = collect_literals(parser)
    assert "NAME" not in literals
    assert "QUOTED_STRING" not in literals


def test_literal_usage_carries_originating_rules():
    parser = load_grammar()
    literals = collect_literals(parser)
    usage = literals["FILTER"]
    assert isinstance(usage, LiteralUsage)
    assert "filter_op" in usage.rules
