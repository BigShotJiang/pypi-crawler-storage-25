"""Tests for the highlight grammar loader."""
from lark import Lark

from recipe_dsl.highlight.loader import load_grammar


def test_load_grammar_returns_lark_parser():
    parser = load_grammar()
    assert isinstance(parser, Lark)


def test_load_grammar_has_named_terminals():
    parser = load_grammar()
    terminal_names = {t.name for t in parser.terminals}
    assert "NAME" in terminal_names
    assert "NUMBER" in terminal_names
    assert "QUOTED_STRING" in terminal_names


def test_load_grammar_has_embed_terminals():
    parser = load_grammar()
    terminal_names = {t.name for t in parser.terminals}
    assert "SQL_STRING" in terminal_names
    assert "CSS_STRING" in terminal_names
    assert "REGEX_STRING" in terminal_names


def test_load_grammar_has_rules():
    parser = load_grammar()
    rule_origins = {r.origin.name for r in parser.rules}
    assert "pipeline" in rule_origins
    assert "query_stmt" in rule_origins
