"""Smoke tests for the recipe-dsl-highlight CLI."""
from click.testing import CliRunner

from recipe_dsl.highlight.cli import main


def test_cli_help_runs():
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "--output" in result.output


def test_cli_default_output_to_stdout():
    runner = CliRunner()
    result = runner.invoke(main, [])
    assert result.exit_code == 0
    assert "AUTO-GENERATED" in result.output
    assert "export function registerRecipeDsl" in result.output


def test_cli_output_writes_to_file(tmp_path):
    out_file = tmp_path / "grammar.gen.ts"
    runner = CliRunner()
    result = runner.invoke(main, ["--output", str(out_file)])
    assert result.exit_code == 0
    assert result.output.strip() == ""
    contents = out_file.read_text(encoding="utf-8")
    assert "AUTO-GENERATED" in contents
    assert "export function registerRecipeDsl" in contents


def test_main_cli_does_not_import_highlight():
    """Importing recipe_dsl.cli must not pull in recipe_dsl.highlight.*."""
    import subprocess
    import sys
    import textwrap

    code = textwrap.dedent(
        """
        import sys
        import recipe_dsl.cli  # noqa: F401
        leaked = [m for m in sys.modules if m.startswith('recipe_dsl.highlight')]
        if leaked:
            raise SystemExit('leaked modules: ' + ','.join(leaked))
        """
    )
    result = subprocess.run(
        [sys.executable, "-c", code],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
