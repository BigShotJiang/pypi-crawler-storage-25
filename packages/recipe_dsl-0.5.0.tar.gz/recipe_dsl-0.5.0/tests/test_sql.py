"""Tests for SQL QUERY operation."""

import pytest

from recipe_dsl.ast.nodes import QueryStatement, Literal, Identifier
from recipe_dsl.grammar.parser import Parser
from recipe_dsl.runtime.interpreter import Interpreter


class TestQueryParsing:
    """Test QUERY statement parsing."""

    def test_query_with_literal_connection(self):
        parser = Parser()
        source = '''
PIPELINE test:
  QUERY "sqlite:///test.db" "SELECT * FROM users" INTO results
  OUTPUT results
'''
        ast = parser.parse(source)
        query_stmt = ast.body[0]
        assert isinstance(query_stmt, QueryStatement)
        assert isinstance(query_stmt.connection, Literal)
        assert query_stmt.connection.value == "sqlite:///test.db"
        assert isinstance(query_stmt.query, Literal)
        assert query_stmt.query.value == "SELECT * FROM users"
        assert isinstance(query_stmt.target, Identifier)
        assert query_stmt.target.name == "results"

    def test_query_with_variable_connection(self):
        parser = Parser()
        source = '''
PIPELINE test:
  QUERY db_url "SELECT 1" INTO results
  OUTPUT results
'''
        ast = parser.parse(source)
        query_stmt = ast.body[0]
        assert isinstance(query_stmt, QueryStatement)
        assert isinstance(query_stmt.connection, Identifier)
        assert query_stmt.connection.name == "db_url"

    def test_query_without_into(self):
        parser = Parser()
        source = '''
PIPELINE test:
  QUERY "sqlite:///test.db" "SELECT 1"
  OUTPUT results
'''
        ast = parser.parse(source)
        query_stmt = ast.body[0]
        assert isinstance(query_stmt, QueryStatement)
        assert query_stmt.target is None


class TestQueryExecution:
    """Test QUERY statement execution."""

    def test_query_execution(self):
        source = '''
PIPELINE test:
  QUERY db_url "SELECT 1 AS id, 'hello' AS name" INTO results
  OUTPUT results
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        result = interpreter.execute(ast, inputs={"db_url": "sqlite:///:memory:"})
        assert result is not None
        assert len(result) == 1
        assert result[0]["id"] == 1
        assert result[0]["name"] == "hello"

    def test_query_with_interpolation(self):
        source = '''
PIPELINE test:
  SET target_name = "alice"
  QUERY db_url "SELECT 1 AS id WHERE 'alice' = ${target_name}" INTO results
  OUTPUT results
'''
        parser = Parser()
        ast = parser.parse(source)
        interpreter = Interpreter()
        result = interpreter.execute(ast, inputs={"db_url": "sqlite:///:memory:"})
        assert result is not None
        assert len(result) == 1
        assert result[0]["id"] == 1
