"""Phase 1 validation tests."""
import pytest

from recipe_dsl.grammar.hurl_validator import validate_phase1


def test_valid_simple_get():
    errors = validate_phase1("GET https://example.com")
    assert errors == []


def test_valid_full_block():
    block = """POST https://example.com
Authorization: Bearer abc
[Query]
foo: bar
[Options]
retry: 3

{"x": 1}"""
    errors = validate_phase1(block)
    assert errors == []


def test_forbidden_section_asserts():
    block = """GET https://example.com
[Asserts]
status == 200"""
    errors = validate_phase1(block)
    assert any("[Asserts]" in e.message for e in errors)


def test_forbidden_section_captures():
    block = """GET https://example.com
[Captures]
foo: jsonpath \"$\""""
    errors = validate_phase1(block)
    assert any("[Captures]" in e.message for e in errors)


def test_forbidden_option_output():
    block = """GET https://example.com
[Options]
output: /tmp/x"""
    errors = validate_phase1(block)
    assert any("output" in e.message for e in errors)


def test_forbidden_response_status_line():
    block = """GET https://example.com

HTTP 200"""
    errors = validate_phase1(block)
    assert any("status line" in e.message for e in errors)


def test_forbidden_hurl_templating():
    block = """GET https://example.com
X-Foo: {{evil}}"""
    errors = validate_phase1(block)
    assert any("templating" in e.message for e in errors)


def test_hurl_templating_in_body_is_rejected():
    """Per addendum E, {{var}} is forbidden everywhere including the body
    region. Single interpolation layer: only RecipeDSL ${var}."""
    block = 'POST https://example.com\nContent-Type: application/json\n\n{"x": "{{evil}}"}\n'
    errors = validate_phase1(block)
    assert any("{{" in e.message or "templating" in e.message
               for e in errors), errors


def test_unsupported_method():
    errors = validate_phase1("FOO https://example.com")
    assert any("method 'FOO'" in e.message for e in errors)


def test_template_in_body_with_blank_lines_is_rejected():
    """Body containing {{ }} on multiple lines (with blanks between) is
    flagged on every occurrence — addendum E."""
    block = """POST https://example.com
Content-Type: text/plain

before {{still in body}}

after {{also in body}}"""
    errors = validate_phase1(block)
    assert any("templating" in e.message for e in errors)


def test_forbidden_close_template_brace():
    """Bare }} outside body must be flagged (spec parity with {{)."""
    block = """GET https://example.com
X-Foo: abc }} more"""
    errors = validate_phase1(block)
    assert any("templating" in e.message for e in errors)


def test_follow_redirect_is_rejected_use_location_instead():
    """follow-redirect was a fabrication of the original spec; the real
    Hurl 8.x key is `location`. Validator must reject the old name."""
    block = "GET https://example.com\n[Options]\nfollow-redirect: true\n"
    errors = validate_phase1(block)
    assert any(
        "follow-redirect" in e.message and "not allowed" in e.message
        for e in errors
    ), errors


def test_location_option_is_allowed():
    block = "GET https://example.com\n[Options]\nlocation: true\n"
    errors = validate_phase1(block)
    assert errors == []


NEWLY_ALLOWED_OPTION_KEYS = [
    "aws-sigv4", "digest", "ntlm", "negotiate",
    "limit-rate", "location-trusted", "max-filesize",
    "no-cookie-store", "no-proxy", "pinnedpubkey",
    "ssl-no-revoke", "verbosity",
]


@pytest.mark.parametrize("key", NEWLY_ALLOWED_OPTION_KEYS)
def test_newly_allowed_option_keys_accepted(key):
    block = f"GET https://example.com\n[Options]\n{key}: x\n"
    errors = validate_phase1(block)
    assert errors == [], (key, errors)


def test_secret_option_is_rejected():
    """`secret` defines a redacted Hurl variable; conflicts with the
    single-interpolation-layer rule and is forbidden."""
    block = "GET https://example.com\n[Options]\nsecret: api_key=xyz\n"
    errors = validate_phase1(block)
    assert any("secret" in e.message and "not allowed" in e.message
               for e in errors), errors
