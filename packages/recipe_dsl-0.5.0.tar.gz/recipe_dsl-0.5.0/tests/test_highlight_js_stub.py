"""JS-side validation: registerRecipeDsl populates a stub Prism instance."""
import subprocess
from pathlib import Path

from recipe_dsl.highlight import generate


def test_register_recipe_dsl_populates_stub(js_harness_dir: Path):
    tmp_dir = js_harness_dir / ".tmp"
    tmp_dir.mkdir(exist_ok=True)
    src_file = tmp_dir / "grammar.gen.ts"
    src_file.write_text(generate(), encoding="utf-8")

    compile_result = subprocess.run(
        ["npx", "tsc"],
        cwd=js_harness_dir,
        capture_output=True,
        text=True,
    )
    assert compile_result.returncode == 0, (
        f"tsc failed:\nSTDOUT: {compile_result.stdout}\nSTDERR: {compile_result.stderr}"
    )

    run_result = subprocess.run(
        ["node", "run-stub.mjs"],
        cwd=js_harness_dir,
        capture_output=True,
        text=True,
    )
    assert run_result.returncode == 0, (
        f"run-stub.mjs failed:\nSTDOUT: {run_result.stdout}\nSTDERR: {run_result.stderr}"
    )
    assert "OK" in run_result.stdout


def test_hurl_mini_prism_grammar_smoke(js_harness_dir: Path):
    """Smoke-test the emitted Hurl-mini Prism grammar via Node.js.

    Positive cases assert that representative Hurl-mini blocks produce the
    expected token classes; negative cases assert that forbidden constructs
    (e.g. ``[Asserts]``, ``{{...}}``) do NOT receive a special class.
    """
    tmp_dir = js_harness_dir / ".tmp"
    tmp_dir.mkdir(exist_ok=True)
    src_file = tmp_dir / "grammar.gen.ts"
    src_file.write_text(generate(), encoding="utf-8")

    compile_result = subprocess.run(
        ["npx", "tsc"],
        cwd=js_harness_dir,
        capture_output=True,
        text=True,
    )
    assert compile_result.returncode == 0, (
        f"tsc failed:\nSTDOUT: {compile_result.stdout}\nSTDERR: {compile_result.stderr}"
    )

    run_result = subprocess.run(
        ["node", "run-hurl-grammar.mjs"],
        cwd=js_harness_dir,
        capture_output=True,
        text=True,
        timeout=120,
    )
    assert run_result.returncode == 0, (
        f"run-hurl-grammar.mjs failed:\n"
        f"STDOUT: {run_result.stdout}\nSTDERR: {run_result.stderr}"
    )
    assert "OK" in run_result.stdout
