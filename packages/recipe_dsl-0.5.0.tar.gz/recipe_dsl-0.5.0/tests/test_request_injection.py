"""Phase 2 / shape-diff tests — TDD-style.

Each test asserts that when a malicious variable value is substituted
into a valid Hurl-mini template, validate_phase2 raises RequestValidationError.
The Hurl subprocess must NOT be invoked at any point.
"""
from __future__ import annotations

import pytest

from recipe_dsl.errors import RequestValidationError
from recipe_dsl.grammar.hurl_validator import validate_phase2
from recipe_dsl.grammar.hurl_block import parse_hurl_block, extract_skeleton


def _skeleton_of(template: str):
    """Helper: parse a template and return its structural skeleton."""
    return extract_skeleton(parse_hurl_block(template))


def test_inject_asserts_via_header_value():
    """Variable value containing newline + [Asserts] must be rejected."""
    template = "GET https://example.com\nAuthorization: Bearer ${token}"
    skeleton = _skeleton_of(template)
    substituted_vars = {"token": "abc\n[Asserts]\nstatus == 200"}
    substituted = "GET https://example.com\nAuthorization: Bearer abc\n[Asserts]\nstatus == 200"
    with pytest.raises(RequestValidationError) as ei:
        validate_phase2(substituted, skeleton, substituted_vars=substituted_vars)
    assert "[Asserts]" in str(ei.value) or "Asserts" in str(ei.value)


def test_inject_captures_via_url_piece():
    """C2: Variable in URL containing newline + [Captures] must be rejected."""
    template = "GET https://example.com/users/${id}"
    skeleton = _skeleton_of(template)
    bad = '1\n[Captures]\nfoo: jsonpath "$"'
    substituted = f"GET https://example.com/users/{bad}"
    with pytest.raises(RequestValidationError) as ei:
        validate_phase2(substituted, skeleton, substituted_vars={"id": bad})
    assert "[Captures]" in str(ei.value) or "Captures" in str(ei.value)


def test_inject_response_status_line():
    """C3: Variable containing newline + HTTP 200 must be rejected."""
    template = "GET https://example.com\nUser-Agent: ${ua}"
    skeleton = _skeleton_of(template)
    bad = "Foo\nHTTP 200"
    substituted = f"GET https://example.com\nUser-Agent: {bad}"
    with pytest.raises(RequestValidationError) as ei:
        validate_phase2(substituted, skeleton, substituted_vars={"ua": bad})
    assert "status line" in str(ei.value).lower()


def test_inject_hurl_templating():
    """C4: Variable containing {{...}} must be rejected."""
    template = "GET https://example.com\nX-Trace: ${trace_id}"
    skeleton = _skeleton_of(template)
    bad = "abc{{evil}}"
    substituted = f"GET https://example.com\nX-Trace: {bad}"
    with pytest.raises(RequestValidationError) as ei:
        validate_phase2(substituted, skeleton, substituted_vars={"trace_id": bad})
    assert "templating" in str(ei.value).lower() or "{{" in str(ei.value)


def test_inject_forbidden_option_via_options_value():
    """C5: Variable in [Options] value containing forbidden sub-key must be rejected."""
    template = "GET https://example.com\n[Options]\nretry: ${retry_count}"
    skeleton = _skeleton_of(template)
    bad = "3\noutput: /tmp/leak"
    substituted = f"GET https://example.com\n[Options]\nretry: {bad}"
    with pytest.raises(RequestValidationError) as ei:
        validate_phase2(substituted, skeleton, substituted_vars={"retry_count": bad})
    assert "output" in str(ei.value)


def test_inject_allowed_section_via_header_value():
    """C6: Variable injecting an allowlisted section ([Query]) is structural injection.

    The validator must catch this via shape-diff (template vs substituted skeleton).
    """
    template = "GET https://example.com\nAuthorization: Bearer ${token}"
    skeleton = _skeleton_of(template)
    bad = "abc\n[Query]\nspy: 1"
    substituted = f"GET https://example.com\nAuthorization: Bearer {bad}"
    with pytest.raises(RequestValidationError) as ei:
        validate_phase2(substituted, skeleton, substituted_vars={"token": bad})
    msg = str(ei.value).lower()
    assert "structural" in msg or "section" in msg


def test_inject_colonless_line_in_header_region():
    """C2 regression: smuggled colonless line in inline-header region is caught."""
    template = "GET https://example.com\nFoo: ${v}"
    skeleton = _skeleton_of(template)
    bad = "bar\nbaz-no-colon"
    substituted = f"GET https://example.com\nFoo: {bad}"
    with pytest.raises(RequestValidationError):
        validate_phase2(substituted, skeleton, substituted_vars={"v": bad})


def test_inject_colonless_line_in_query_section():
    """C2 regression: smuggled colonless line in [Query] is caught."""
    template = "GET https://example.com\n[Query]\nfoo: ${v}"
    skeleton = _skeleton_of(template)
    bad = "1\nrandom-no-colon"
    substituted = f"GET https://example.com\n[Query]\nfoo: {bad}"
    with pytest.raises(RequestValidationError):
        validate_phase2(substituted, skeleton, substituted_vars={"v": bad})


def test_inject_url_query_string_via_path_var():
    """C1 regression: variable injecting a query string into a path is caught."""
    template = "GET https://example.com/api/${path}"
    skeleton = _skeleton_of(template)
    bad = "users?admin=true"
    substituted = f"GET https://example.com/api/{bad}"
    with pytest.raises(RequestValidationError) as ei:
        validate_phase2(substituted, skeleton, substituted_vars={"path": bad})
    assert "URL" in str(ei.value) or "query" in str(ei.value).lower()


def test_inject_url_extra_segments_via_path_var():
    """C1 regression: variable injecting extra path segments is caught."""
    template = "GET https://example.com/api/${id}"
    skeleton = _skeleton_of(template)
    bad = "1/admin/secrets"
    substituted = f"GET https://example.com/api/{bad}"
    with pytest.raises(RequestValidationError) as ei:
        validate_phase2(substituted, skeleton, substituted_vars={"id": bad})
    assert "segment" in str(ei.value).lower()


def test_legitimate_url_path_value_passes():
    """Asymmetry: a single-segment path value substitution must NOT trigger shape-diff."""
    template = "GET https://example.com/api/${id}"
    skeleton = _skeleton_of(template)
    substituted = "GET https://example.com/api/12345"
    # Should not raise.
    validate_phase2(substituted, skeleton, substituted_vars={"id": "12345"})


def test_legitimate_base_url_var_passes():
    """A leading ${VAR}/path template matches its substituted ``http://host/path`` form.
    Both shapes have one path segment ('news') after the host slot."""
    template = "GET ${API_BASE}/news"
    skeleton = _skeleton_of(template)
    substituted = "GET http://127.0.0.1:33165/news"
    # Should not raise.
    validate_phase2(substituted, skeleton, substituted_vars={"API_BASE": "http://127.0.0.1:33165"})


def test_inject_extra_segments_via_base_url_var():
    """Asymmetry sibling: a malicious ${API_BASE} substitute that hides extra
    path segments inside the value must still trip shape-diff. Template has
    one path segment ('news'); evil substituted URL exposes three."""
    template = "GET ${API_BASE}/news"
    skeleton = _skeleton_of(template)
    bad = "http://evil.com/admin/secrets"
    substituted = f"GET {bad}/news"
    with pytest.raises(RequestValidationError):
        validate_phase2(substituted, skeleton, substituted_vars={"API_BASE": bad})


def test_inject_new_inline_header():
    """C7: Variable adding a new inline header line is caught (inline_header_keys differs)."""
    template = "GET https://example.com\nUser-Agent: ${ua}"
    skeleton = _skeleton_of(template)
    bad = "Foo\nX-Spy: hidden"
    substituted = f"GET https://example.com\nUser-Agent: {bad}"
    with pytest.raises(RequestValidationError) as ei:
        validate_phase2(substituted, skeleton, substituted_vars={"ua": bad})
    assert "header" in str(ei.value).lower() or "structural" in str(ei.value).lower()


def test_inject_extra_option_key():
    """C8: Variable adding an extra [Options] sub-key is caught (section_keys differs)."""
    template = "GET https://example.com\n[Options]\nretry: ${count}"
    skeleton = _skeleton_of(template)
    bad = "3\nmax-redirs: 5"
    substituted = f"GET https://example.com\n[Options]\nretry: {bad}"
    with pytest.raises(RequestValidationError) as ei:
        validate_phase2(substituted, skeleton, substituted_vars={"count": bad})
    msg = str(ei.value).lower()
    assert "structural" in msg or "section keys" in msg


def test_inject_request_line_tampering():
    """C9: Variable in URL containing newlines that introduce a second pseudo-request."""
    template = "GET https://example.com/${path}"
    skeleton = _skeleton_of(template)
    bad = "users\n\nGET /admin"
    substituted = f"GET https://example.com/{bad}"
    with pytest.raises(RequestValidationError):
        validate_phase2(substituted, skeleton, substituted_vars={"path": bad})


def test_inject_body_breakout_json():
    """C10: Variable in JSON body that closes the JSON early and adds structural lines."""
    template = '''POST https://example.com
Content-Type: application/json

{"comment": "${comment}"}'''
    skeleton = _skeleton_of(template)
    bad = 'evil"}\n[Query]\nx: 1'
    substituted = ('POST https://example.com\nContent-Type: application/json\n\n'
                   '{"comment": "evil"}\n[Query]\nx: 1')
    # Variable substitution into body is opaque to skeleton (body_kind stays JSON,
    # body_present stays True). This is a known residual gap (see C6 review I2).
    # If the validator catches this, great. If not, the test is xfail and documents
    # the gap; do NOT modify the validator just to make this pass — the spec
    # explicitly classifies body content as Hurl's responsibility.
    try:
        validate_phase2(substituted, skeleton, substituted_vars={"comment": bad})
        # Validator passed (residual gap per design). xfail-style: skip.
        pytest.skip("body content opacity is by design — Hurl is responsible")
    except RequestValidationError:
        pass  # Caught; better than expected.


def test_inject_via_query_value():
    """C11: Variable in [Query] value adding a second key is caught."""
    template = "GET https://example.com\n[Query]\nname: ${name}"
    skeleton = _skeleton_of(template)
    bad = "ok\nadmin: true"
    substituted = f"GET https://example.com\n[Query]\nname: {bad}"
    with pytest.raises(RequestValidationError):
        validate_phase2(substituted, skeleton, substituted_vars={"name": bad})


def test_inject_via_form_value():
    """C12: Variable in [Form] value adding a second key is caught."""
    template = "POST https://example.com\n[Form]\nfield: ${value}"
    skeleton = _skeleton_of(template)
    bad = "a\nadmin: true"
    substituted = f"POST https://example.com\n[Form]\nfield: {bad}"
    with pytest.raises(RequestValidationError):
        validate_phase2(substituted, skeleton, substituted_vars={"value": bad})


def test_legitimate_value_with_special_chars_passes():
    """C13: Multi-line JSON body fragment is a legitimate use of newlines.
    Asymmetry check: shape-diff must NOT false-positive on legitimate values."""
    template = '''POST https://example.com
Content-Type: application/json

${json_payload}'''
    skeleton = _skeleton_of(template)
    payload = '{\n  "name": "alice",\n  "items": [1, 2, 3]\n}'
    substituted = f'POST https://example.com\nContent-Type: application/json\n\n{payload}'
    # Should not raise.
    validate_phase2(substituted, skeleton, substituted_vars={"json_payload": payload})


def test_legitimate_header_value_with_colon_passes():
    """Asymmetry check: colon in a header value (e.g., a JWT) must not trip shape-diff."""
    template = "GET https://example.com\nAuthorization: Bearer ${token}"
    skeleton = _skeleton_of(template)
    jwt = "eyJhbG.eyJzdWI:1234.signature"
    substituted = f"GET https://example.com\nAuthorization: Bearer {jwt}"
    # Should not raise.
    validate_phase2(substituted, skeleton, substituted_vars={"token": jwt})


def test_interpreter_phase2_blocks_injection_before_backend():
    """End-to-end: a recipe that substitutes a malicious value into a header
    must raise RequestValidationError before any backend call.
    The backend is mocked to record calls — it must NOT be invoked."""
    from recipe_dsl.grammar.parser import Parser
    from recipe_dsl.runtime.interpreter import Interpreter

    class _RecordingBackend:
        def __init__(self):
            self.calls = []

        def request(self, block):
            self.calls.append(block)
            return {"status": 200, "headers": {}, "body": "{}", "time_ms": 1, "url": "x"}

        def close(self):
            pass

    src = '''PIPELINE p:
  REQUEST """
GET https://example.com
Authorization: Bearer ${token}
""" INTO response
  OUTPUT response
'''
    ast = Parser().parse(src)
    interp = Interpreter()
    backend = _RecordingBackend()
    interp._hurl_backend = backend

    # Inject the malicious value as a real scalar (with real newlines)
    # via the inputs dict — DSL string literals do not interpret \n escapes.
    malicious = "abc\n[Asserts]\nstatus == 200"
    with pytest.raises(RequestValidationError):
        interp.execute(ast, inputs={"token": malicious})
    assert backend.calls == [], "Backend was called despite validation failure"


def test_request_raises_on_missing_var():
    """Missing ${var} in a REQUEST block must raise (matching SQL/string substitution)."""
    from recipe_dsl.grammar.parser import Parser
    from recipe_dsl.runtime.interpreter import Interpreter
    from recipe_dsl.runtime.interpreter import RuntimeError as InterpRuntimeError

    class _StubBackend:
        def __init__(self):
            self.calls = []

        def request(self, block):
            self.calls.append(block)
            return {"status": 200, "headers": {}, "body": "", "time_ms": 0, "url": ""}

        def close(self):
            pass

    src = '''PIPELINE p:
  REQUEST """
GET https://example.com
Authorization: Bearer ${missing_var}
""" INTO response
  OUTPUT response
'''
    ast = Parser().parse(src)
    interp = Interpreter()
    backend = _StubBackend()
    interp._hurl_backend = backend
    with pytest.raises(InterpRuntimeError) as ei:
        interp.execute(ast)
    msg = str(ei.value).lower()
    assert "missing_var" in str(ei.value)
    assert "not found" in msg or "undefined" in msg
    assert backend.calls == [], "Backend was called despite missing variable"
