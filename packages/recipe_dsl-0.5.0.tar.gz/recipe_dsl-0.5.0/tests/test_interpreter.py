"""Tests for the RecipeDSL interpreter."""

from pathlib import Path

import pytest

from recipe_dsl.grammar.parser import Parser
from recipe_dsl.runtime.interpreter import Interpreter
from recipe_dsl.runtime.interpreter import RuntimeError as AnkaRuntimeError


class TestInterpreterBasic:
    """Basic interpreter tests."""

    def test_interpreter_initializes(self) -> None:
        """Interpreter should initialize without error."""
        interpreter = Interpreter()
        assert interpreter is not None

    def test_execute_passthrough_no_steps(self) -> None:
        """Execute pipeline with no steps returns input directly."""
        parser = Parser()
        source = """
        PIPELINE passthrough:
            OUTPUT data
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        test_data = [{"x": 1}, {"x": 2}]
        result = interpreter.execute(ast, inputs={"data": test_data})

        assert result == test_data

    def test_execute_no_inputs_no_output(self) -> None:
        """Execute with no inputs returns None for missing output."""
        parser = Parser()
        source = """
        PIPELINE test:
            OUTPUT data
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        with pytest.raises(AnkaRuntimeError):
            interpreter.execute(ast)


class TestInterpreterFilter:
    """Tests for FILTER operation execution."""

    def test_filter_greater_than(self) -> None:
        """Test FILTER with > operator."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_pos:
                FILTER data
                WHERE x > 0
                INTO positive
            OUTPUT positive
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 5}, {"x": -3}, {"x": 10}, {"x": 0}]}
        )

        assert result == [{"x": 5}, {"x": 10}]

    def test_filter_less_than(self) -> None:
        """Test FILTER with < operator."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_neg:
                FILTER data
                WHERE x < 0
                INTO negative
            OUTPUT negative
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 5}, {"x": -3}, {"x": 10}, {"x": -7}]}
        )

        assert result == [{"x": -3}, {"x": -7}]

    def test_filter_greater_than_or_equal(self) -> None:
        """Test FILTER with >= operator."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_step:
                FILTER data
                WHERE x >= 5
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 4}, {"x": 5}, {"x": 6}]}
        )

        assert result == [{"x": 5}, {"x": 6}]

    def test_filter_less_than_or_equal(self) -> None:
        """Test FILTER with <= operator."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_step:
                FILTER data
                WHERE x <= 5
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 4}, {"x": 5}, {"x": 6}]}
        )

        assert result == [{"x": 4}, {"x": 5}]

    def test_filter_equal(self) -> None:
        """Test FILTER with == operator."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_step:
                FILTER data
                WHERE x == 5
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 4}, {"x": 5}, {"x": 6}, {"x": 5}]}
        )

        assert result == [{"x": 5}, {"x": 5}]

    def test_filter_not_equal(self) -> None:
        """Test FILTER with != operator."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_step:
                FILTER data
                WHERE x != 5
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 4}, {"x": 5}, {"x": 6}]}
        )

        assert result == [{"x": 4}, {"x": 6}]

    def test_filter_with_string(self) -> None:
        """Test FILTER with string comparison."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_active:
                FILTER data
                WHERE status == "active"
                INTO active
            OUTPUT active
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"status": "active"},
                    {"status": "inactive"},
                    {"status": "active"},
                ]
            },
        )

        assert result == [{"status": "active"}, {"status": "active"}]

    def test_filter_with_decimal(self) -> None:
        """Test FILTER with decimal comparison."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_cheap:
                FILTER data
                WHERE price < 100.0
                INTO cheap
            OUTPUT cheap
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [{"price": 50.0}, {"price": 150.0}, {"price": 99.99}]
            },
        )

        assert result == [{"price": 50.0}, {"price": 99.99}]

    def test_filter_no_matches(self) -> None:
        """Test FILTER that matches no rows."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_step:
                FILTER data
                WHERE x > 100
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 1}, {"x": 2}, {"x": 3}]}
        )

        assert result == []

    def test_filter_all_match(self) -> None:
        """Test FILTER that matches all rows."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_step:
                FILTER data
                WHERE x > 0
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        input_data = [{"x": 1}, {"x": 2}, {"x": 3}]
        result = interpreter.execute(ast, inputs={"data": input_data})

        assert result == input_data

    def test_filter_empty_input(self) -> None:
        """Test FILTER with empty input."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_step:
                FILTER data
                WHERE x > 0
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(ast, inputs={"data": []})

        assert result == []


class TestInterpreterMultipleSteps:
    """Tests for pipelines with multiple steps."""

    def test_multiple_steps_chained(self) -> None:
        """Test multiple steps that chain together."""
        parser = Parser()
        source = """
        PIPELINE multi_step:
            STEP step1:
                FILTER data
                WHERE x > 0
                INTO positive_x
            STEP step2:
                FILTER positive_x
                WHERE y > 0
                INTO positive_both
            OUTPUT positive_both
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"x": 5, "y": 1},
                    {"x": -3, "y": 2},
                    {"x": 10, "y": -1},
                    {"x": 7, "y": 3},
                ]
            },
        )

        assert result == [{"x": 5, "y": 1}, {"x": 7, "y": 3}]

    def test_hello_anka_example(self) -> None:
        """Test the hello.anka example from the documentation."""
        parser = Parser()
        source = """
        PIPELINE hello:
            STEP filter_positive:
                FILTER data
                WHERE x > 0
                INTO positive_data
            OUTPUT positive_data
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"x": 5, "y": 1},
                    {"x": -3, "y": 2},
                    {"x": 10, "y": 3},
                ]
            },
        )

        assert result == [{"x": 5, "y": 1}, {"x": 10, "y": 3}]


class TestInterpreterErrors:
    """Tests for interpreter error handling."""

    def test_missing_source_data(self) -> None:
        """Test error when source data is not found."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_step:
                FILTER other_data
                WHERE x > 0
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        with pytest.raises(AnkaRuntimeError, match="Source 'other_data' not found"):
            interpreter.execute(ast, inputs={"data": [{"x": 1}]})

    def test_missing_output(self) -> None:
        """Test error when output variable is not found."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_step:
                FILTER data
                WHERE x > 0
                INTO result
            OUTPUT missing_output
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        with pytest.raises(
            AnkaRuntimeError, match="Output 'missing_output' not found"
        ):
            interpreter.execute(ast, inputs={"data": [{"x": 1}]})

    def test_missing_field_returns_false(self) -> None:
        """Test that missing field in row returns False (row excluded)."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_step:
                FILTER data
                WHERE x > 0
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        # Row with missing 'x' field should be excluded
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 5}, {"y": 10}, {"x": 3}]}
        )

        assert result == [{"x": 5}, {"x": 3}]


class TestInterpreterMultipleFields:
    """Tests for rows with multiple fields."""

    def test_preserves_all_fields(self) -> None:
        """Test that filtering preserves all fields in matching rows."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_large:
                FILTER orders
                WHERE amount > 1000
                INTO large_orders
            OUTPUT large_orders
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "orders": [
                    {"id": 1, "customer": "Alice", "amount": 500},
                    {"id": 2, "customer": "Bob", "amount": 1500},
                    {"id": 3, "customer": "Charlie", "amount": 2000},
                ]
            },
        )

        assert result == [
            {"id": 2, "customer": "Bob", "amount": 1500},
            {"id": 3, "customer": "Charlie", "amount": 2000},
        ]


class TestInterpreterSelect:
    """Tests for SELECT operation execution."""

    def test_select_single_column(self) -> None:
        """Test SELECT with one column."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP pick:
                SELECT x
                FROM data
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 1, "y": 10}, {"x": 2, "y": 20}]}
        )

        assert result == [{"x": 1}, {"x": 2}]

    def test_select_multiple_columns(self) -> None:
        """Test SELECT with multiple columns."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP pick_cols:
                SELECT customer, amount
                FROM orders
                INTO summary
            OUTPUT summary
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "orders": [
                    {"order_id": 1, "customer": "Alice", "amount": 100},
                    {"order_id": 2, "customer": "Bob", "amount": 200},
                ]
            },
        )

        assert result == [
            {"customer": "Alice", "amount": 100},
            {"customer": "Bob", "amount": 200},
        ]

    def test_select_preserves_column_order(self) -> None:
        """Test that SELECT preserves column order in output."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP reorder:
                SELECT c, a
                FROM data
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"a": 1, "b": 2, "c": 3}]}
        )

        # Check that both columns are present
        assert result == [{"c": 3, "a": 1}]
        # Check column order is preserved (c before a)
        assert list(result[0].keys()) == ["c", "a"]

    def test_select_missing_column_error(self) -> None:
        """Test that SELECT raises error for non-existent column."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP pick:
                SELECT x, missing_col
                FROM data
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        with pytest.raises(
            AnkaRuntimeError, match="Column 'missing_col' not found"
        ):
            interpreter.execute(ast, inputs={"data": [{"x": 1}]})

    def test_select_missing_source_error(self) -> None:
        """Test that SELECT raises error for non-existent source."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP pick:
                SELECT x
                FROM missing_source
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        with pytest.raises(
            AnkaRuntimeError, match="Source 'missing_source' not found"
        ):
            interpreter.execute(ast, inputs={"data": [{"x": 1}]})

    def test_select_empty_input(self) -> None:
        """Test SELECT with empty input."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP pick:
                SELECT x
                FROM data
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(ast, inputs={"data": []})

        assert result == []


class TestInterpreterFilterThenSelect:
    """Tests for combined FILTER and SELECT operations."""

    def test_filter_then_select(self) -> None:
        """Test a pipeline with FILTER followed by SELECT."""
        parser = Parser()
        source = """
        PIPELINE summarize_orders:
            STEP filter_large:
                FILTER orders
                WHERE amount > 1000
                INTO large_orders
            STEP pick_columns:
                SELECT customer, amount
                FROM large_orders
                INTO summary
            OUTPUT summary
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "orders": [
                    {"order_id": 1, "customer": "Alice", "amount": 1500, "status": "active"},
                    {"order_id": 2, "customer": "Bob", "amount": 500, "status": "pending"},
                    {"order_id": 3, "customer": "Carol", "amount": 2000, "status": "active"},
                ]
            },
        )

        assert result == [
            {"customer": "Alice", "amount": 1500},
            {"customer": "Carol", "amount": 2000},
        ]

    def test_select_then_filter(self) -> None:
        """Test a pipeline with SELECT followed by FILTER."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP pick_cols:
                SELECT x, y
                FROM data
                INTO subset
            STEP filter_pos:
                FILTER subset
                WHERE x > 0
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"x": 5, "y": 1, "z": 100},
                    {"x": -3, "y": 2, "z": 200},
                    {"x": 10, "y": 3, "z": 300},
                ]
            },
        )

        assert result == [{"x": 5, "y": 1}, {"x": 10, "y": 3}]


class TestInterpreterMap:
    """Tests for MAP operation execution."""

    def test_map_field_copy(self) -> None:
        """Test MAP with simple field reference."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP copy:
                MAP data
                WITH y => x
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(ast, inputs={"data": [{"x": 1}, {"x": 2}]})

        assert result == [{"x": 1, "y": 1}, {"x": 2, "y": 2}]

    def test_map_multiplication(self) -> None:
        """Test MAP with multiplication."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP calc:
                MAP data
                WITH total => quantity * price
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"quantity": 5, "price": 10.0},
                    {"quantity": 3, "price": 25.0},
                ]
            },
        )

        assert result == [
            {"quantity": 5, "price": 10.0, "total": 50.0},
            {"quantity": 3, "price": 25.0, "total": 75.0},
        ]

    def test_map_complex_expression(self) -> None:
        """Test MAP with complex arithmetic expression."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP calc:
                MAP data
                WITH score => (a + b) * 2
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"a": 3, "b": 7}]}
        )

        assert result == [{"a": 3, "b": 7, "score": 20}]

    def test_map_with_literal(self) -> None:
        """Test MAP with literal in expression."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP bonus:
                MAP data
                WITH total => salary + 1000
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"salary": 5000}]}
        )

        assert result == [{"salary": 5000, "total": 6000}]

    def test_map_missing_field_error(self) -> None:
        """Test MAP with missing field raises error."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP calc:
                MAP data
                WITH y => missing_field
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        with pytest.raises(AnkaRuntimeError, match="Field 'missing_field' not found"):
            interpreter.execute(ast, inputs={"data": [{"x": 1}]})


class TestInterpreterSort:
    """Tests for SORT operation execution."""

    def test_sort_asc(self) -> None:
        """Test SORT with ASC order."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP order:
                SORT data
                BY x ASC
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 3}, {"x": 1}, {"x": 2}]}
        )

        assert result == [{"x": 1}, {"x": 2}, {"x": 3}]

    def test_sort_desc(self) -> None:
        """Test SORT with DESC order."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP order:
                SORT data
                BY amount DESC
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={"data": [{"amount": 100}, {"amount": 300}, {"amount": 200}]},
        )

        assert result == [{"amount": 300}, {"amount": 200}, {"amount": 100}]

    def test_sort_strings(self) -> None:
        """Test SORT with string values."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP order:
                SORT data
                BY name ASC
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={"data": [{"name": "Charlie"}, {"name": "Alice"}, {"name": "Bob"}]},
        )

        assert result == [{"name": "Alice"}, {"name": "Bob"}, {"name": "Charlie"}]

    def test_sort_missing_key_error(self) -> None:
        """Test SORT with missing key raises error."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP order:
                SORT data
                BY missing_key ASC
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        with pytest.raises(AnkaRuntimeError, match="Sort key 'missing_key' not found"):
            interpreter.execute(ast, inputs={"data": [{"x": 1}]})

    def test_sort_nulls_last_asc(self) -> None:
        """Test SORT ASC with NULLS_LAST puts nulls at end."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP order:
                SORT data
                BY price ASC NULLS_LAST
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"id": 1, "price": 30.0},
                    {"id": 2, "price": None},
                    {"id": 3, "price": 10.0},
                    {"id": 4, "price": 20.0},
                ]
            },
        )

        assert result == [
            {"id": 3, "price": 10.0},
            {"id": 4, "price": 20.0},
            {"id": 1, "price": 30.0},
            {"id": 2, "price": None},
        ]

    def test_sort_nulls_first_asc(self) -> None:
        """Test SORT ASC with NULLS_FIRST puts nulls at start."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP order:
                SORT data
                BY price ASC NULLS_FIRST
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"id": 1, "price": 30.0},
                    {"id": 2, "price": None},
                    {"id": 3, "price": 10.0},
                ]
            },
        )

        assert result == [
            {"id": 2, "price": None},
            {"id": 3, "price": 10.0},
            {"id": 1, "price": 30.0},
        ]

    def test_sort_default_null_handling_asc(self) -> None:
        """Test SORT ASC without NULLS clause defaults to nulls at end."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP order:
                SORT data
                BY price ASC
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"id": 1, "price": 30.0},
                    {"id": 2, "price": None},
                    {"id": 3, "price": 10.0},
                ]
            },
        )

        # Default for ASC: nulls at end (like SQL NULLS LAST)
        assert result == [
            {"id": 3, "price": 10.0},
            {"id": 1, "price": 30.0},
            {"id": 2, "price": None},
        ]

    def test_sort_nulls_last_desc(self) -> None:
        """Test SORT DESC with NULLS_LAST puts nulls at end."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP order:
                SORT data
                BY price DESC NULLS_LAST
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"id": 1, "price": 30.0},
                    {"id": 2, "price": None},
                    {"id": 3, "price": 10.0},
                ]
            },
        )

        assert result == [
            {"id": 1, "price": 30.0},
            {"id": 3, "price": 10.0},
            {"id": 2, "price": None},
        ]


class TestInterpreterLimit:
    """Tests for LIMIT operation execution."""

    def test_limit_basic(self) -> None:
        """Test LIMIT takes correct count."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP take:
                LIMIT data
                COUNT 2
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 1}, {"x": 2}, {"x": 3}, {"x": 4}]}
        )

        assert result == [{"x": 1}, {"x": 2}]

    def test_limit_more_than_available(self) -> None:
        """Test LIMIT with count greater than rows returns all."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP take:
                LIMIT data
                COUNT 10
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 1}, {"x": 2}]}
        )

        assert result == [{"x": 1}, {"x": 2}]

    def test_limit_zero(self) -> None:
        """Test LIMIT with count 0 returns empty."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP take:
                LIMIT data
                COUNT 0
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 1}, {"x": 2}]}
        )

        assert result == []


class TestInterpreterSkip:
    """Tests for SKIP operation execution."""

    def test_skip_basic(self) -> None:
        """Test SKIP removes first N rows."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP do_skip:
                SKIP data
                COUNT 2
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 1}, {"x": 2}, {"x": 3}, {"x": 4}]}
        )

        assert result == [{"x": 3}, {"x": 4}]

    def test_skip_more_than_available(self) -> None:
        """Test SKIP with count greater than rows returns empty."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP do_skip:
                SKIP data
                COUNT 10
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 1}, {"x": 2}]}
        )

        assert result == []

    def test_skip_zero(self) -> None:
        """Test SKIP with count 0 returns all."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP do_skip:
                SKIP data
                COUNT 0
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 1}, {"x": 2}]}
        )

        assert result == [{"x": 1}, {"x": 2}]

    def test_skip_then_limit(self) -> None:
        """Test SKIP followed by LIMIT for pagination."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP do_skip:
                SKIP data
                COUNT 2
                INTO skipped
            STEP do_limit:
                LIMIT skipped
                COUNT 2
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 1}, {"x": 2}, {"x": 3}, {"x": 4}, {"x": 5}]}
        )

        assert result == [{"x": 3}, {"x": 4}]


class TestInterpreterDistinct:
    """Tests for DISTINCT operation execution."""

    def test_distinct_single_key(self) -> None:
        """Test DISTINCT removes duplicates by single key."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP dedup:
                DISTINCT data
                BY category
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"category": "A", "value": 1},
                    {"category": "B", "value": 2},
                    {"category": "A", "value": 3},
                    {"category": "C", "value": 4},
                    {"category": "B", "value": 5},
                ]
            },
        )

        # Keeps first occurrence of each category
        assert result == [
            {"category": "A", "value": 1},
            {"category": "B", "value": 2},
            {"category": "C", "value": 4},
        ]

    def test_distinct_multiple_keys(self) -> None:
        """Test DISTINCT with multiple key columns."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP dedup:
                DISTINCT data
                BY x, y
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"x": 1, "y": 2, "z": 10},
                    {"x": 1, "y": 3, "z": 20},
                    {"x": 1, "y": 2, "z": 30},
                ]
            },
        )

        assert result == [
            {"x": 1, "y": 2, "z": 10},
            {"x": 1, "y": 3, "z": 20},
        ]

    def test_distinct_all_unique(self) -> None:
        """Test DISTINCT with all unique rows returns all."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP dedup:
                DISTINCT data
                BY x
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        input_data = [{"x": 1}, {"x": 2}, {"x": 3}]
        result = interpreter.execute(ast, inputs={"data": input_data})

        assert result == input_data

    def test_distinct_all_same(self) -> None:
        """Test DISTINCT with all identical rows returns one."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP dedup:
                DISTINCT data
                BY x
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 1}, {"x": 1}, {"x": 1}]}
        )

        assert result == [{"x": 1}]

    def test_distinct_empty_input(self) -> None:
        """Test DISTINCT with empty input."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP dedup:
                DISTINCT data
                BY x
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(ast, inputs={"data": []})

        assert result == []


class TestInterpreterAggregate:
    """Tests for AGGREGATE operation execution."""

    def test_aggregate_count(self) -> None:
        """Test AGGREGATE with COUNT."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP agg:
                AGGREGATE data
                COMPUTE COUNT(x) AS total_count
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 1}, {"x": 2}, {"x": 3}]}
        )

        assert result == [{"total_count": 3}]

    def test_aggregate_sum(self) -> None:
        """Test AGGREGATE with SUM."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP agg:
                AGGREGATE data
                COMPUTE SUM(amount) AS total
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"amount": 10}, {"amount": 20}, {"amount": 30}]}
        )

        assert result == [{"total": 60}]

    def test_aggregate_avg(self) -> None:
        """Test AGGREGATE with AVG."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP agg:
                AGGREGATE data
                COMPUTE AVG(score) AS average
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"score": 10.0}, {"score": 20.0}, {"score": 30.0}]}
        )

        assert result == [{"average": 20.0}]

    def test_aggregate_min(self) -> None:
        """Test AGGREGATE with MIN."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP agg:
                AGGREGATE data
                COMPUTE MIN(price) AS lowest
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"price": 30}, {"price": 10}, {"price": 20}]}
        )

        assert result == [{"lowest": 10}]

    def test_aggregate_max(self) -> None:
        """Test AGGREGATE with MAX."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP agg:
                AGGREGATE data
                COMPUTE MAX(price) AS highest
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"price": 30}, {"price": 10}, {"price": 20}]}
        )

        assert result == [{"highest": 30}]

    def test_aggregate_with_group_by(self) -> None:
        """Test AGGREGATE with GROUP_BY."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP agg:
                AGGREGATE data
                GROUP_BY category
                COMPUTE SUM(amount) AS total
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"category": "A", "amount": 10},
                    {"category": "B", "amount": 20},
                    {"category": "A", "amount": 30},
                    {"category": "B", "amount": 40},
                ]
            },
        )

        # Sort results by category for deterministic comparison
        result.sort(key=lambda r: r["category"])
        assert result == [
            {"category": "A", "total": 40},
            {"category": "B", "total": 60},
        ]

    def test_aggregate_multiple_computations(self) -> None:
        """Test AGGREGATE with multiple aggregate functions."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP agg:
                AGGREGATE data
                COMPUTE COUNT(value) AS cnt, SUM(value) AS total, AVG(value) AS average
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"value": 10}, {"value": 20}, {"value": 30}]}
        )

        assert result == [{"cnt": 3, "total": 60, "average": 20.0}]

    def test_aggregate_empty_input(self) -> None:
        """Test AGGREGATE with empty input."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP agg:
                AGGREGATE data
                COMPUTE COUNT(x) AS cnt
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(ast, inputs={"data": []})

        # One group (empty) with count = 0
        assert result == [{"cnt": 0}]


class TestInterpreterJoin:
    """Tests for JOIN operation execution."""

    def test_join_basic(self) -> None:
        """Test basic inner JOIN."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP do_join:
                JOIN orders WITH customers
                ON orders.customer_id == customers.customer_id
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "orders": [
                    {"order_id": 1, "customer_id": 10, "amount": 100},
                    {"order_id": 2, "customer_id": 20, "amount": 200},
                ],
                "customers": [
                    {"customer_id": 10, "name": "Alice"},
                    {"customer_id": 20, "name": "Bob"},
                ],
            },
        )

        assert len(result) == 2
        assert result[0]["order_id"] == 1
        assert result[0]["name"] == "Alice"
        assert result[1]["order_id"] == 2
        assert result[1]["name"] == "Bob"

    def test_join_no_match(self) -> None:
        """Test JOIN with no matching rows."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP do_join:
                JOIN left WITH right
                ON left.id == right.id
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "left": [{"id": 1, "val": "a"}],
                "right": [{"id": 2, "info": "b"}],
            },
        )

        assert result == []

    def test_join_one_to_many(self) -> None:
        """Test JOIN with one-to-many relationship."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP do_join:
                JOIN categories WITH products
                ON categories.cat_id == products.cat_id
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "categories": [
                    {"cat_id": 1, "cat_name": "Electronics"},
                ],
                "products": [
                    {"prod_id": 100, "cat_id": 1, "name": "Phone"},
                    {"prod_id": 101, "cat_id": 1, "name": "Laptop"},
                ],
            },
        )

        assert len(result) == 2
        assert result[0]["cat_name"] == "Electronics"
        assert result[0]["name"] == "Phone"
        assert result[1]["cat_name"] == "Electronics"
        assert result[1]["name"] == "Laptop"

    def test_join_missing_table_error(self) -> None:
        """Test JOIN with missing table raises error."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP do_join:
                JOIN left WITH missing_table
                ON left.id == missing_table.id
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        with pytest.raises(AnkaRuntimeError, match="Right table 'missing_table' not found"):
            interpreter.execute(ast, inputs={"left": [{"id": 1}]})


class TestInterpreterTryOnError:
    """Tests for TRY/ON_ERROR error handling."""

    def test_try_success(self) -> None:
        """Test TRY block when no error occurs."""
        parser = Parser()
        source = """
        PIPELINE test:
            TRY:
                STEP do_filter:
                    FILTER data
                    WHERE x > 0
                    INTO result
            ON_ERROR:
                SET error_flag = TRUE
            END
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast, inputs={"data": [{"x": 1}, {"x": -2}, {"x": 3}]}
        )

        assert result == [{"x": 1}, {"x": 3}]

    def test_try_error_handled(self) -> None:
        """Test TRY block when error occurs — ON_ERROR runs."""
        parser = Parser()
        source = """
        PIPELINE test:
            SET error_flag = FALSE
            TRY:
                STEP do_filter:
                    FILTER nonexistent_source
                    WHERE x > 0
                    INTO result
            ON_ERROR:
                SET error_flag = TRUE
            END
            OUTPUT data
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        interpreter.execute(
            ast, inputs={"data": [{"x": 1}]}
        )

        assert interpreter.get_scalar("error_flag") is True


class TestInterpreterFullPipeline:
    """Tests for full pipelines with all operations."""

    def test_sales_report_pipeline(self) -> None:
        """Test the complete sales report pipeline."""
        parser = Parser()
        recipe_path = Path(__file__).resolve().parent.parent / "examples" / "sales_report.rdsl"
        ast = parser.parse_file(recipe_path)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "sales": [
                    {"product": "Widget", "quantity": 5, "price": 10.0},
                    {"product": "Gadget", "quantity": 3, "price": 25.0},
                    {"product": "Gizmo", "quantity": 0, "price": 15.0},
                    {"product": "Doohickey", "quantity": 10, "price": 5.0},
                    {"product": "Thingamajig", "quantity": 2, "price": 50.0},
                ]
            },
        )

        # Expected: filtered (quantity > 0), computed total, sorted DESC, top 3, selected columns
        # Widget: 5 * 10 = 50
        # Gadget: 3 * 25 = 75
        # Doohickey: 10 * 5 = 50
        # Thingamajig: 2 * 50 = 100
        # Sorted DESC: 100, 75, 50, 50 -> top 3 = 100, 75, 50
        assert result == [
            {"product": "Thingamajig", "total": 100.0},
            {"product": "Gadget", "total": 75.0},
            {"product": "Widget", "total": 50.0},
        ]

    def test_filter_map_sort_limit_select(self) -> None:
        """Test full pipeline: FILTER -> MAP -> SORT -> LIMIT -> SELECT."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_pos:
                FILTER data
                WHERE x > 0
                INTO positive
            STEP add_sum:
                MAP positive
                WITH sum => x + y
                INTO with_sum
            STEP order:
                SORT with_sum
                BY sum DESC
                INTO sorted
            STEP take:
                LIMIT sorted
                COUNT 2
                INTO top
            STEP pick:
                SELECT x, sum
                FROM top
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"x": 5, "y": 1},    # sum = 6
                    {"x": -3, "y": 10},  # filtered out
                    {"x": 10, "y": 5},   # sum = 15
                    {"x": 2, "y": 3},    # sum = 5
                ]
            },
        )

        # After filter: (5,1), (10,5), (2,3)
        # After map: sums = 6, 15, 5
        # After sort DESC: 15, 6, 5
        # After limit 2: 15, 6
        # After select: x and sum only
        assert result == [
            {"x": 10, "sum": 15},
            {"x": 5, "sum": 6},
        ]

    def test_filter_distinct_aggregate(self) -> None:
        """Test pipeline: FILTER -> DISTINCT -> AGGREGATE."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP filter_active:
                FILTER data
                WHERE status == "active"
                INTO active
            STEP dedup:
                DISTINCT active
                BY category
                INTO unique_cats
            STEP count_them:
                AGGREGATE unique_cats
                COMPUTE COUNT(category) AS cat_count
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"category": "A", "status": "active", "amount": 10},
                    {"category": "B", "status": "inactive", "amount": 20},
                    {"category": "A", "status": "active", "amount": 30},
                    {"category": "C", "status": "active", "amount": 40},
                ]
            },
        )

        # After filter: A(active), A(active), C(active)
        # After distinct by category: A, C
        # After count: 2
        assert result == [{"cat_count": 2}]

    def test_sort_skip_limit(self) -> None:
        """Test pipeline: SORT -> SKIP -> LIMIT (pagination)."""
        parser = Parser()
        source = """
        PIPELINE test:
            STEP order:
                SORT data
                BY score DESC
                INTO sorted
            STEP skip_first:
                SKIP sorted
                COUNT 2
                INTO skipped
            STEP take_page:
                LIMIT skipped
                COUNT 2
                INTO result
            OUTPUT result
        """
        ast = parser.parse(source)

        interpreter = Interpreter()
        result = interpreter.execute(
            ast,
            inputs={
                "data": [
                    {"name": "A", "score": 50},
                    {"name": "B", "score": 90},
                    {"name": "C", "score": 70},
                    {"name": "D", "score": 80},
                    {"name": "E", "score": 60},
                ]
            },
        )

        # Sorted DESC: B(90), D(80), C(70), E(60), A(50)
        # Skip 2: C(70), E(60), A(50)
        # Limit 2: C(70), E(60)
        assert result == [
            {"name": "C", "score": 70},
            {"name": "E", "score": 60},
        ]
