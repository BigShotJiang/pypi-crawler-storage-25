"""Tests for String operations (functions and checks)."""

import pytest

from recipe_dsl.grammar.parser import Parser
from recipe_dsl.runtime.interpreter import Interpreter


@pytest.fixture
def parser() -> Parser:
    """Create a parser instance."""
    return Parser()


@pytest.fixture
def interpreter() -> Interpreter:
    """Create an interpreter instance."""
    return Interpreter()


class TestStringFunctions:
    """Tests for string functions in SET expressions."""

    def test_upper(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test UPPER function."""
        source = '''
        PIPELINE upper_test:
            SET result = UPPER("alice")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "ALICE"

    def test_lower(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test LOWER function."""
        source = '''
        PIPELINE lower_test:
            SET result = LOWER("ALICE")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "alice"

    def test_trim(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test TRIM function."""
        source = '''
        PIPELINE trim_test:
            SET result = TRIM("  hello  ")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "hello"

    def test_ltrim(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test LTRIM function."""
        source = '''
        PIPELINE ltrim_test:
            SET result = LTRIM("  hello  ")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "hello  "

    def test_rtrim(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test RTRIM function."""
        source = '''
        PIPELINE rtrim_test:
            SET result = RTRIM("  hello  ")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "  hello"

    def test_length(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test LENGTH function."""
        source = '''
        PIPELINE length_test:
            SET result = LENGTH("hello")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == 5

    def test_reverse(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test REVERSE function."""
        source = '''
        PIPELINE reverse_test:
            SET result = REVERSE("hello")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "olleh"

    def test_substring(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test SUBSTRING function."""
        source = '''
        PIPELINE substring_test:
            SET result = SUBSTRING("hello world", 0, 5)
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "hello"

    def test_left_func(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test LEFT function."""
        source = '''
        PIPELINE left_test:
            SET result = LEFT("hello world", 5)
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "hello"

    def test_right_func(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test RIGHT function."""
        source = '''
        PIPELINE right_test:
            SET result = RIGHT("hello world", 5)
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "world"

    def test_index_of(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test INDEX_OF function."""
        source = '''
        PIPELINE index_of_test:
            SET result = INDEX_OF("hello world", "world")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == 6

    def test_replace(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test REPLACE function (first occurrence only)."""
        source = '''
        PIPELINE replace_test:
            SET result = REPLACE("hello hello", "hello", "world")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "world hello"

    def test_replace_all(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test REPLACE_ALL function."""
        source = '''
        PIPELINE replace_all_test:
            SET result = REPLACE_ALL("hello hello", "hello", "world")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "world world"

    def test_pad_left(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test PAD_LEFT function."""
        source = '''
        PIPELINE pad_left_test:
            SET result = PAD_LEFT("42", 5, "0")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "00042"

    def test_pad_right(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test PAD_RIGHT function."""
        source = '''
        PIPELINE pad_right_test:
            SET result = PAD_RIGHT("42", 5, "0")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "42000"

    def test_repeat(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test REPEAT function."""
        source = '''
        PIPELINE repeat_test:
            SET result = REPEAT("ab", 3)
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "ababab"

    def test_concat(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test CONCAT function."""
        source = '''
        PIPELINE concat_test:
            SET first = "John"
            SET last = "Doe"
            SET result = CONCAT(first, " ", last)
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "John Doe"

    def test_split(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test SPLIT function."""
        source = '''
        PIPELINE split_test:
            SET result = SPLIT("a,b,c", ",")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == ["a", "b", "c"]

    def test_join_func(self, parser: Parser, interpreter: Interpreter) -> None:
        """Test JOIN function."""
        source = '''
        PIPELINE join_test:
            SET parts = SPLIT("a,b,c", ",")
            SET result = JOIN(parts, "-")
            OUTPUT data
        '''
        ast = parser.parse(source)
        interpreter.execute(ast, {"data": []})
        assert interpreter.get_scalar("result") == "a-b-c"
