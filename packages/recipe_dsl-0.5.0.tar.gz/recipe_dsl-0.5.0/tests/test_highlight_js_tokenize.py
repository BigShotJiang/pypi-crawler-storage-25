"""JS-side validation: SQL/CSS strings tokenize to nested sub-language tokens."""
import subprocess
from pathlib import Path

from recipe_dsl.highlight import generate


def test_sample_recipe_tokenizes_with_nested_subtokens(js_harness_dir: Path):
    tmp_dir = js_harness_dir / ".tmp"
    tmp_dir.mkdir(exist_ok=True)
    src_file = tmp_dir / "grammar.gen.ts"
    src_file.write_text(generate(), encoding="utf-8")

    compile_result = subprocess.run(
        ["npx", "tsc"],
        cwd=js_harness_dir,
        capture_output=True,
        text=True,
    )
    assert compile_result.returncode == 0, compile_result.stderr

    run_result = subprocess.run(
        ["node", "run-tokenize.mjs"],
        cwd=js_harness_dir,
        capture_output=True,
        text=True,
    )
    assert run_result.returncode == 0, (
        f"run-tokenize.mjs failed:\nSTDOUT: {run_result.stdout}\nSTDERR: {run_result.stderr}"
    )
    assert "OK" in run_result.stdout
