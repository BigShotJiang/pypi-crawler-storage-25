"""Tests for the highlight classifier."""
from recipe_dsl.highlight.classifier import OPERATOR_SET, classify
from recipe_dsl.highlight.collector import LiteralUsage


def _usage(literal, *, function=False, bareword=False, priority=0):
    return LiteralUsage(
        literal=literal,
        function_call_form=function,
        bareword_form=bareword,
        priority=priority,
    )


def test_keyword_alpha_literal_bareword():
    entries = classify({"PIPELINE": _usage("PIPELINE", bareword=True)})
    classes = {e.prism_class for e in entries}
    assert "keyword" in classes
    keyword_entry = next(e for e in entries if e.prism_class == "keyword")
    assert keyword_entry.pattern == r"\bPIPELINE\b"


def test_function_alpha_literal_call_form():
    entries = classify({"UPPER": _usage("UPPER", function=True)})
    function_entries = [e for e in entries if e.prism_class == "function"]
    assert len(function_entries) == 1
    assert "(?=" in function_entries[0].pattern
    assert "UPPER" in function_entries[0].pattern


def test_operator_symbol_literal():
    entries = classify({"==": _usage("==", bareword=True)})
    assert any(e.prism_class == "operator" for e in entries)


def test_punctuation_symbol_literal():
    entries = classify({",": _usage(",", bareword=True)})
    assert any(e.prism_class == "punctuation" for e in entries)


def test_priority_propagated_to_token_entry():
    entries = classify({"PIPELINE": _usage("PIPELINE", bareword=True, priority=5)})
    assert entries[0].priority == 5


def test_operator_set_is_explicit():
    assert "==" in OPERATOR_SET
    assert "!=" in OPERATOR_SET
    assert "<" in OPERATOR_SET
    assert "<=" in OPERATOR_SET
    assert "+" in OPERATOR_SET
    assert "/" in OPERATOR_SET
    assert "=>" in OPERATOR_SET
    assert "," not in OPERATOR_SET
    assert ":" not in OPERATOR_SET
    assert "(" not in OPERATOR_SET


def test_collision_emits_two_entries():
    entries = classify(
        {"JOIN": _usage("JOIN", function=True, bareword=True)}
    )
    classes = [e.prism_class for e in entries]
    assert classes.count("function") == 1
    assert classes.count("keyword") == 1


def test_collision_function_entry_uses_lookahead():
    entries = classify(
        {"JOIN": _usage("JOIN", function=True, bareword=True)}
    )
    function_entries = [e for e in entries if e.prism_class == "function"]
    assert len(function_entries) == 1
    assert "(?=" in function_entries[0].pattern
    assert "JOIN" in function_entries[0].pattern


def test_collision_keyword_entry_uses_word_boundary():
    entries = classify(
        {"JOIN": _usage("JOIN", function=True, bareword=True)}
    )
    keyword_entries = [e for e in entries if e.prism_class == "keyword"]
    assert len(keyword_entries) == 1
    assert keyword_entries[0].pattern == r"\bJOIN\b"
