"""Setuptools build hook so wheel ships docs/ and examples/ from repo root.

Project layout keeps canonical docs and example recipes at the repo root
(<repo>/docs/, <repo>/examples/) — standard Python project shape, single
source of truth, GitHub displays them at familiar paths. The wheel needs
those files inside the ``recipe_dsl`` package so installed users can call
``recipe-dsl explain`` without a checkout. ``CopyExtraData`` is a
``build_py`` override that copies them into the build tree under
``recipe_dsl/docs/`` and ``recipe_dsl/examples/`` after standard
package_py processing.

Editable installs (``pip install -e .``) don't run build_py, so the
pkg-side copies never materialise. ``recipe_dsl.cli`` falls back to the
repo-root paths when the packaged copies are absent.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py


class CopyExtraData(build_py):
    """build_py that mirrors <repo>/docs/*.md and <repo>/examples/*
    into <build_lib>/recipe_dsl/docs/ and .../examples/."""

    # Files shipped with the wheel. Explicit allowlist so dated design
    # docs (2026-NN-NN-*.md) and stray notes don't pad the install.
    DOCS = (
        "syntax-guide.md",
        "hurl-mini-reference.md",
        "gotchas.recipe-dsl.md",
        "gotchas.hurl-mini.md",
    )
    EXAMPLES_PATTERNS = ("*.rdsl", "*.json")

    def run(self) -> None:
        super().run()
        repo = Path(__file__).resolve().parent
        docs_dest = Path(self.build_lib) / "recipe_dsl" / "docs"
        if docs_dest.exists():
            for stale in docs_dest.glob("*.md"):
                stale.unlink()
        docs_dest.mkdir(parents=True, exist_ok=True)
        for name in self.DOCS:
            src = repo / "docs" / name
            if src.is_file():
                shutil.copy2(src, docs_dest / name)
        examples_dest = Path(self.build_lib) / "recipe_dsl" / "examples"
        if examples_dest.exists():
            for stale in examples_dest.iterdir():
                if stale.is_file():
                    stale.unlink()
        examples_dest.mkdir(parents=True, exist_ok=True)
        examples_src = repo / "examples"
        if examples_src.is_dir():
            for pattern in self.EXAMPLES_PATTERNS:
                for f in examples_src.glob(pattern):
                    if f.is_file():
                        shutil.copy2(f, examples_dest / f.name)


setup(cmdclass={"build_py": CopyExtraData})
