"""End-to-end pipeline for the Prism highlight generator."""
from __future__ import annotations

from typing import Dict, List

from recipe_dsl.highlight.classifier import classify
from recipe_dsl.highlight.collector import collect_literals
from recipe_dsl.highlight.emitter import emit_ts
from recipe_dsl.highlight.errors import EmptyGrammarError
from recipe_dsl.highlight.loader import load_grammar
from recipe_dsl.highlight.named_terminals import extract_named_terminals
from recipe_dsl.highlight.token_entry import TokenEntry


def _build_token_map() -> Dict[str, List[TokenEntry]]:
    parser = load_grammar()
    literals = collect_literals(parser)
    if not literals:
        raise EmptyGrammarError("no string literals collected from grammar")

    classified = classify(literals)
    named = extract_named_terminals(parser)

    buckets: Dict[str, List[TokenEntry]] = {}
    for entry in classified:
        buckets.setdefault(entry.prism_class, []).append(entry)
    for entry in named:
        buckets.setdefault(entry.prism_class, []).append(entry)
    return buckets


def generate() -> str:
    """Run the full pipeline and return the emitted TS source."""
    return emit_ts(_build_token_map())
