"""Prism highlighter generator for RecipeDSL.

Generates a prism-react-renderer-compatible TypeScript module from the
canonical recipe_dsl.lark grammar at runtime.
"""
from recipe_dsl.highlight.generate import generate

__all__ = ["generate"]
