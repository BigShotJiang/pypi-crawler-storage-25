"""Translate Python re regexes into JS-compatible regex sources."""
from __future__ import annotations

import re
from typing import Iterable, Tuple

from recipe_dsl.highlight.errors import UnsupportedRegexError

_FLAG_MAP: dict[int, str] = {
    re.IGNORECASE: "i",
    re.MULTILINE: "m",
    re.DOTALL: "s",
}

_POSIX_CLASS_MAP: dict[str, str] = {
    "alpha": "A-Za-z",
    "digit": "0-9",
    "alnum": "A-Za-z0-9",
    "space": r"\s",
    "upper": "A-Z",
    "lower": "a-z",
    "xdigit": "0-9A-Fa-f",
    "punct": r"!-/:-@\[-`{-~",
}

_NAMED_GROUP_RE = re.compile(r"\(\?P<")
_NAMED_BACKREF_RE = re.compile(r"\(\?P=([^)]+)\)")
_INLINE_COMMENT_RE = re.compile(r"\(\?#[^)]*\)")
_POSIX_CLASS_RE = re.compile(r"\[:([a-z]+):\]")
_ANCHOR_A_RE = re.compile(r"\\A")
_ANCHOR_Z_RE = re.compile(r"\\Z")
_VERBOSE_COMMENT_RE = re.compile(r"#[^\n]*")
_VERBOSE_WS_RE = re.compile(r"\s+")


def _rewrite_named_groups(src: str) -> str:
    return _NAMED_GROUP_RE.sub("(?<", src)


def _rewrite_named_backrefs(src: str) -> str:
    return _NAMED_BACKREF_RE.sub(r"\\k<\1>", src)


def _strip_inline_comments(src: str) -> str:
    return _INLINE_COMMENT_RE.sub("", src)


def _rewrite_anchors(src: str) -> str:
    src = _ANCHOR_A_RE.sub("^", src)
    src = _ANCHOR_Z_RE.sub("$", src)
    return src


def _rewrite_posix_classes(terminal_name: str, src: str) -> str:
    def _replace(match: re.Match[str]) -> str:
        name = match.group(1)
        if name not in _POSIX_CLASS_MAP:
            raise UnsupportedRegexError(
                terminal_name, f"POSIX character class [:{name}:]"
            )
        return _POSIX_CLASS_MAP[name]

    return _POSIX_CLASS_RE.sub(_replace, src)


def _strip_verbose(src: str) -> str:
    src = _VERBOSE_COMMENT_RE.sub("", src)
    src = _VERBOSE_WS_RE.sub("", src)
    return src


def translate(
    terminal_name: str, regex_src: str, flags: Iterable[int]
) -> Tuple[str, str]:
    """Translate a Python re regex into a JS-compatible (source, flags) pair.

    Applies, in order:
      1. Strip insignificant whitespace + `#` comments if VERBOSE flag set.
      2. Rewrite anchors `\\A` -> `^`, `\\Z` -> `$`.
      3. Strip inline comments `(?#...)`.
      4. Rewrite POSIX classes `[:name:]` -> JS char-class equivalents.
      5. Rewrite named groups `(?P<n>...)` -> `(?<n>...)`.
      6. Rewrite named backreferences `(?P=n)` -> `\\k<n>`.
      7. Map flags (IGNORECASE/MULTILINE/DOTALL); reject others.

    Raises UnsupportedRegexError for unrecognized flags or unknown POSIX
    classes.
    """
    flags_list = list(flags)
    src = regex_src
    if re.VERBOSE in flags_list:
        src = _strip_verbose(src)

    src = _rewrite_anchors(src)
    src = _strip_inline_comments(src)
    src = _rewrite_posix_classes(terminal_name, src)
    src = _rewrite_named_groups(src)
    src = _rewrite_named_backrefs(src)

    js_flags: list[str] = []
    for flag in flags_list:
        if flag == re.VERBOSE:
            continue
        if flag in _FLAG_MAP:
            js_flags.append(_FLAG_MAP[flag])
            continue
        raise UnsupportedRegexError(
            terminal_name, f"unrecognized regex flag {flag!r}"
        )
    return src, "".join(js_flags)
