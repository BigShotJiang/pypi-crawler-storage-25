"""Classify literals into Prism token classes."""
from __future__ import annotations

import re
from typing import List

from recipe_dsl.highlight.collector import LiteralUsage
from recipe_dsl.highlight.token_entry import TokenEntry

OPERATOR_SET: frozenset[str] = frozenset(
    {"<", ">", "<=", ">=", "==", "!=", "+", "-", "*", "/", "=>"}
)


def _is_alpha_literal(literal: str) -> bool:
    return literal.isalpha() or (
        literal != ""
        and literal[0].isalpha()
        and literal.replace("_", "").isalnum()
    )


def _word_boundary_pattern(literal: str) -> str:
    return r"\b" + re.escape(literal) + r"\b"


def _function_lookahead_pattern(literal: str) -> str:
    return r"\b" + re.escape(literal) + r"(?=\s*\()"


def _symbol_pattern(literal: str) -> str:
    return re.escape(literal)


def _classify_bareword(literal: str, priority: int) -> TokenEntry:
    if _is_alpha_literal(literal):
        return TokenEntry(
            prism_class="keyword",
            pattern=_word_boundary_pattern(literal),
            priority=priority,
        )
    if literal in OPERATOR_SET:
        return TokenEntry(
            prism_class="operator",
            pattern=_symbol_pattern(literal),
            priority=priority,
        )
    return TokenEntry(
        prism_class="punctuation",
        pattern=_symbol_pattern(literal),
        priority=priority,
    )


def classify(literals: dict[str, LiteralUsage]) -> List[TokenEntry]:
    """Apply the heuristic and return classified TokenEntries.

    Handles JOIN-style collisions (literal in both function-call and
    bareword form) by emitting two entries -- a function entry with a
    lookahead pattern and a bareword entry classified normally.
    """
    entries: List[TokenEntry] = []
    for literal, usage in literals.items():
        is_collision = usage.function_call_form and usage.bareword_form

        if is_collision:
            entries.append(
                TokenEntry(
                    prism_class="function",
                    pattern=_function_lookahead_pattern(literal),
                    priority=usage.priority,
                )
            )
            entries.append(_classify_bareword(literal, usage.priority))
            continue

        if usage.function_call_form:
            entries.append(
                TokenEntry(
                    prism_class="function",
                    pattern=_function_lookahead_pattern(literal),
                    priority=usage.priority,
                )
            )
            continue

        entries.append(_classify_bareword(literal, usage.priority))
    return entries
