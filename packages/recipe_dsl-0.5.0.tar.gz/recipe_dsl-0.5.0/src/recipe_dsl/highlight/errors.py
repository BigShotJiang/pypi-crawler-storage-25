"""Exceptions raised by the highlight generator."""
from __future__ import annotations


class HighlightError(Exception):
    """Base class for highlight-generator errors."""


class UnsupportedRegexError(HighlightError):
    """Raised when a Python regex construct cannot be translated to JS."""

    def __init__(self, terminal_name: str, construct: str, detail: str = "") -> None:
        self.terminal_name = terminal_name
        self.construct = construct
        msg = (
            f"terminal {terminal_name!r}: unsupported regex construct "
            f"{construct!r}"
        )
        if detail:
            msg = f"{msg}: {detail}"
        super().__init__(msg)


class EmptyGrammarError(HighlightError):
    """Raised when no string literals could be collected from the grammar."""
