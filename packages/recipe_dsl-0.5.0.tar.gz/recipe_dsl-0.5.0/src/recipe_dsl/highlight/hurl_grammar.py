"""Hurl-mini Prism token grammar — emitted to TS by the highlight generator.

The grammar is hand-written rather than derived from a .lark file because
Hurl-mini is small, externally defined, and locked to a known subset.
Reviewed when we bump the minimum Hurl version.
"""
from __future__ import annotations

# Sub-allowlist mirror of validator's [Options] keys — single source of
# truth is recipe_dsl.grammar.hurl_validator.ALLOWED_OPTIONS. We sort
# longest-first so the regex alternation does not let a shorter prefix
# (e.g. "location", "verbose", "retry", "connect-to") shadow a longer
# match ("location-trusted", "verbosity"/"very-verbose", "retry-interval",
# "connect-timeout"). Entries are re.escape'd because some keys contain
# regex metacharacters (e.g. "http1.0").
import re as _re

from recipe_dsl.grammar.hurl_validator import ALLOWED_OPTIONS as _VALIDATOR_OPTIONS

_ALLOWED_OPTIONS: tuple[str, ...] = tuple(
    sorted(_VALIDATOR_OPTIONS, key=lambda k: (-len(k), k))
)

ALLOWED_OPTIONS_PATTERN = "|".join(_re.escape(k) for k in _ALLOWED_OPTIONS)

# Each entry is a (token_name, spec_dict). The emitter serializes this
# to TypeScript. Pattern strings here are JS-regex source — emitted
# verbatim as TS regex literals.
HURL_MINI_GRAMMAR: list[tuple[str, dict]] = [
    ("comment", {"pattern": "#.*$", "flags": "m"}),
    ("section-header", {
        "pattern": r"\[(?:Query|Form|Multipart|Cookies|BasicAuth|Options)\]",
    }),
    ("request-line", {
        "pattern": r"^(?:GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+\S+",
        "flags": "m",
        "inside": {
            "method": r"^[A-Z]+",
            "url": r"\S+$",
        },
    }),
    ("interpolation", {
        "pattern": r"\$\{[^}]+\}",
        "inside": {
            "punctuation": r"[$\{\}]",
            "variable": r"[a-zA-Z_]\w*",
        },
    }),
    ("option-key", {
        "pattern": rf"^(?:{ALLOWED_OPTIONS_PATTERN})(?=\s*:)",
        "flags": "m",
        "alias": "property",
    }),
    ("header-name", {
        "pattern": r"^[A-Za-z][\w-]*(?=\s*:)",
        "flags": "m",
        "alias": "property",
    }),
    ("string", {"pattern": r'"(?:\\.|[^"\\])*"'}),
    ("punctuation", {"pattern": r"[:,]"}),
]
