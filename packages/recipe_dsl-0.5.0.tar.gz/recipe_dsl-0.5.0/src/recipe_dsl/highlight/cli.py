"""Click CLI for recipe-dsl-highlight."""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import click


@click.command()
@click.option(
    "--output",
    "output_path",
    type=click.Path(dir_okay=False, writable=True, path_type=Path),
    default=None,
    help="Write output to file instead of stdout.",
)
def main(output_path: Optional[Path]) -> None:
    """Generate the Prism highlight TypeScript module for RecipeDSL.

    Output goes to stdout by default; --output redirects to a file.
    """
    from recipe_dsl.highlight.errors import (
        EmptyGrammarError,
        UnsupportedRegexError,
    )
    from recipe_dsl.highlight.generate import generate

    try:
        rendered = generate()
    except UnsupportedRegexError as exc:
        click.echo(f"error: {exc}", err=True)
        sys.exit(2)
    except EmptyGrammarError as exc:
        click.echo(f"error: {exc}", err=True)
        sys.exit(2)
    except FileNotFoundError as exc:
        click.echo(f"error: cannot load grammar: {exc}", err=True)
        sys.exit(2)

    if output_path is None:
        click.echo(rendered, nl=False)
    else:
        output_path.write_text(rendered, encoding="utf-8")


if __name__ == "__main__":
    main()
