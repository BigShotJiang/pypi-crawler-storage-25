"""Extract Prism class regexes from named (non-anonymous) terminals."""
from __future__ import annotations

import sys
from typing import List, Optional

from lark import Lark

from recipe_dsl.highlight.regex_translator import translate
from recipe_dsl.highlight.token_entry import EMBED_PREFIX_LANG, TokenEntry

NAMED_TERMINAL_CLASS: dict[str, str] = {
    "NAME": "variable",
    "NUMBER": "number",
    "SIGNED_NUMBER": "number",
    "QUOTED_STRING": "string",
    "COMMENT": "comment",
    "DURATION": "number",
}

# Terminals that exist in the grammar but should never be highlighted
# (whitespace separators, internal lexer tokens). Skipped silently.
_SILENT_SKIP_TERMINALS = {"WS"}

_GREEDY_CLASSES = {"string"}

# Context prefixes that anchor where each embed-string terminal can
# appear in the source, encoded as JS regex sources. Used to construct
# a Prism `lookbehind: true` pattern that lets the embed strings be
# disambiguated from plain `string` matches at the regex level. The
# Lark-level terminal split is invisible to Prism, which only sees
# regex; we have to re-encode the rule context here.
EMBED_CONTEXT_PATTERNS: dict[str, str] = {
    "SQL_STRING": r"\bQUERY\s+(?:\"[^\"]*\"|\w+)\s+",
    "CSS_STRING": r"\bCSS\s+",
    "REGEX_STRING": r"\bREGEX\s+|\bMATCHES\s*\(\s*\w+\s*,\s*",
    "HURL_BLOCK": r"\bREQUEST\s+",
}

# Embed terminals whose delimiter is a triple-quote rather than a
# single quote pair. The body regex and inside-punctuation rule emitted
# downstream both depend on this.
_TRIPLE_QUOTE_TERMINALS: frozenset[str] = frozenset({"HURL_BLOCK"})


def _kebab(name: str) -> str:
    """Convert SQL_STRING -> sql-string."""
    return name.lower().replace("_", "-")


def _embed_prefix_match(name: str) -> Optional[str]:
    for prefix, lang in EMBED_PREFIX_LANG.items():
        if name.startswith(prefix):
            return lang
    return None


def extract_named_terminals(parser: Lark) -> List[TokenEntry]:
    """Pull Prism-mapped TokenEntries from named (regex) terminals.

    Three branches per terminal:
      1. Embed-prefix (SQL_*, CSS_*, REGEX_*): emit TokenEntry with
         inside_lang, alias='string', greedy=True. Class derived as
         kebab-case of the name.
      2. Standard named terminal in NAMED_TERMINAL_CLASS: emit with the
         hardcoded class. Strings get greedy=True.
      3. Unknown named regex terminal: stderr warning, skip.
    """
    out: List[TokenEntry] = []
    for term in parser.terminals:
        name = term.name
        if name.startswith("__ANON_") or name.startswith("ANON"):
            continue
        if name in _SILENT_SKIP_TERMINALS:
            continue
        pattern = term.pattern
        if getattr(pattern, "type", None) != "re":
            continue

        flags = tuple(getattr(pattern, "flags", ()) or ())
        priority = getattr(term, "priority", 0) or 0
        js_pattern, js_flags = translate(name, pattern.value, flags)

        embed_lang = _embed_prefix_match(name)
        if embed_lang is not None:
            # Override the grammar-derived pattern with a lazy multiline
            # form so the body can span newlines and the closing quote is
            # always paired with the opening one. Required for the
            # nested `inside` grammar emitter wraps around it (which
            # peels outer quotes via `punctuation` and runs the
            # sub-language on the body).
            triple = name in _TRIPLE_QUOTE_TERMINALS
            if triple:
                embed_body_pattern = r'"""[\s\S]*?"""'
            else:
                embed_body_pattern = r'"[\s\S]*?"|' + r"'[\s\S]*?'"
            context = EMBED_CONTEXT_PATTERNS.get(name)
            if context is None:
                # Without a context anchor, the emitted pattern collides
                # with the plain `string` rule in Prism (Prism is not
                # context-aware). Surface this loudly so a developer who
                # adds a new entry to EMBED_PREFIX_LANG without also
                # adding an EMBED_CONTEXT_PATTERNS entry sees the gap at
                # generation time.
                print(
                    f"warning: embed terminal {name!r} has no entry in "
                    f"EMBED_CONTEXT_PATTERNS; emitting without lookbehind "
                    f"anchor (will shadow plain string matches)",
                    file=sys.stderr,
                )
                anchored_pattern = embed_body_pattern
                lookbehind = False
            else:
                anchored_pattern = f"({context})({embed_body_pattern})"
                lookbehind = True
            out.append(
                TokenEntry(
                    prism_class=_kebab(name),
                    pattern=anchored_pattern,
                    flags=js_flags,
                    priority=priority,
                    greedy=True,
                    lookbehind=lookbehind,
                    inside_lang=embed_lang,
                    alias="string",
                    triple_quote=triple,
                )
            )
            continue

        if name in NAMED_TERMINAL_CLASS:
            cls = NAMED_TERMINAL_CLASS[name]
            entry = TokenEntry(
                prism_class=cls,
                pattern=js_pattern,
                flags=js_flags,
                priority=priority,
                greedy=cls in _GREEDY_CLASSES,
            )
            out.append(entry)
            continue

        print(
            f"warning: terminal {name} not in highlight map, skipping",
            file=sys.stderr,
        )
    return out
