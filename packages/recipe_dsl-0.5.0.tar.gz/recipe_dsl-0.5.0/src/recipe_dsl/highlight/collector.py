"""Collect string-literal usages from a Lark grammar."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Set

from lark import Lark
from lark.grammar import Terminal


@dataclass
class LiteralUsage:
    """How a string literal is used across the grammar."""

    literal: str
    function_call_form: bool = False
    bareword_form: bool = False
    rules: Set[str] = field(default_factory=set)
    priority: int = 0


def collect_literals(parser: Lark) -> dict[str, LiteralUsage]:
    """Walk the parser's rules and collect all string-literal usages.

    A string literal is a TerminalDef whose pattern type is "str".
    For each literal we record:
      - rules where it appears,
      - whether it appears in function-call form (next symbol is `(`),
      - whether it appears in bareword form (anywhere else),
      - Lark's terminal priority (used for emit-order tiebreaking).
    """
    literal_by_terminal_name: dict[str, str] = {}
    priority_by_terminal_name: dict[str, int] = {}
    for term in parser.terminals:
        pattern = term.pattern
        if getattr(pattern, "type", None) == "str":
            literal_by_terminal_name[term.name] = pattern.value
            priority_by_terminal_name[term.name] = getattr(term, "priority", 0) or 0

    open_paren_terminal_names = {
        name for name, lit in literal_by_terminal_name.items() if lit == "("
    }

    usages: dict[str, LiteralUsage] = {}

    for rule in parser.rules:
        rule_name = rule.origin.name
        expansion = rule.expansion
        for i, sym in enumerate(expansion):
            if not isinstance(sym, Terminal):
                continue
            if sym.name not in literal_by_terminal_name:
                continue
            literal = literal_by_terminal_name[sym.name]
            usage = usages.setdefault(literal, LiteralUsage(literal=literal))
            usage.rules.add(rule_name)
            usage.priority = max(
                usage.priority, priority_by_terminal_name[sym.name]
            )

            next_sym = expansion[i + 1] if i + 1 < len(expansion) else None
            if (
                isinstance(next_sym, Terminal)
                and next_sym.name in open_paren_terminal_names
            ):
                usage.function_call_form = True
            else:
                usage.bareword_form = True

    return usages
