"""Load the canonical recipe_dsl.lark grammar for highlight generation."""
from __future__ import annotations

from pathlib import Path

from lark import Lark

GRAMMAR_PATH: Path = (
    Path(__file__).resolve().parent.parent / "grammar" / "recipe_dsl.lark"
)


def load_grammar() -> Lark:
    """Load the bundled RecipeDSL grammar and return a Lark parser instance.

    Uses LALR (matches the runtime parser configuration) so the contextual
    lexer is active for terminal disambiguation.
    """
    grammar_text = GRAMMAR_PATH.read_text(encoding="utf-8")
    return Lark(
        grammar_text,
        start="start",
        parser="lalr",
        propagate_positions=False,
    )
