"""Intermediate token representation shared by the highlight pipeline."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

# Prefix-to-language map for embed-string terminals. A grammar terminal
# whose name starts with one of these prefixes is assigned the matching
# Prism class (kebab-case of the terminal name) with `inside:
# Prism.languages.<lang>` set in the emitted TS module.
#
# Adding a new entry here ALSO requires an entry in
# `named_terminals.EMBED_CONTEXT_PATTERNS` — Prism's regex matcher is not
# context-aware, so each embed terminal needs a lookbehind anchor encoding
# the surrounding rule context. The named_terminals extractor emits a
# stderr warning at generation time if a terminal is in this map but
# missing from EMBED_CONTEXT_PATTERNS.
EMBED_PREFIX_LANG: dict[str, str] = {
    "SQL_": "sql",
    "CSS_": "css",
    "REGEX_": "regex",
    "HURL_": "hurl-mini",
}


@dataclass(frozen=True)
class TokenEntry:
    """A regex-and-metadata bundle assigned to a Prism token class."""

    prism_class: str
    pattern: str
    flags: str = ""
    priority: int = 0
    greedy: bool = False
    lookbehind: bool = False
    inside_lang: Optional[str] = None
    alias: Optional[str] = None
    # When true, the embedded string is delimited by triple quotes
    # (e.g. HURL_BLOCK's `"""..."""`). The emitter then emits an inside
    # grammar that strips three quote characters at each end instead of
    # one. Only meaningful with `inside_lang`.
    triple_quote: bool = False
