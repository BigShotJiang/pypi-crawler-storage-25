"""Exceptions raised by REQUEST-related validation and execution.

All four concrete classes inherit from `RequestError`, so a single
`except RequestError` covers the whole REQUEST surface.
"""
from __future__ import annotations

from typing import Any, Optional


class RequestError(Exception):
    """Base class for all REQUEST-related failures.

    Provides the shared `recipe_location` attribute used by all subclasses.
    """
    def __init__(self, message: str, recipe_location: Optional[str] = None):
        super().__init__(message)
        self.recipe_location = recipe_location


class RequestValidationError(RequestError):
    """Phase 2 (runtime) validation failed.

    Raised when ${var} substitution introduced a forbidden construct
    or a structural change to the Hurl-mini block.
    """
    def __init__(self, message: str, recipe_location: Optional[str] = None,
                 culprit_var: Optional[str] = None):
        super().__init__(message, recipe_location=recipe_location)
        self.culprit_var = culprit_var


class RequestTransportError(RequestError):
    """Transport-level failure: DNS, TLS, connection refused, timeout, etc."""
    pass


class RequestStatusError(RequestError):
    """HTTP request returned a non-2xx status (default-throw)."""
    def __init__(self, status: int, envelope: dict[str, Any],
                 recipe_location: Optional[str] = None):
        super().__init__(f"HTTP {status}", recipe_location=recipe_location)
        self.status = status
        self.envelope = envelope

    @property
    def headers(self) -> dict[str, str]:
        return self.envelope.get("headers", {})

    @property
    def body(self) -> str:
        return self.envelope.get("body", "")


class RequestRuntimeError(RequestError):
    """Hurl invocation failure: binary missing, malformed JSON, schema mismatch."""
    pass
