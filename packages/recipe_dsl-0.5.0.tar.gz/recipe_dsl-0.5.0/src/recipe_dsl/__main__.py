"""Entry point for python -m recipe-dsl."""

from recipe_dsl.cli import main

if __name__ == "__main__":
    main()
