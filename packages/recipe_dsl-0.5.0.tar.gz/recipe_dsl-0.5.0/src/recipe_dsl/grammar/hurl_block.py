"""Section-aware parsing helpers for Hurl-mini blocks.

The full ParsedHurlBlock and HurlSkeleton dataclasses live here too;
they're added in Task B1. This file starts as just the dedent helper.
"""
from __future__ import annotations

import textwrap


def strip_triple_quotes_and_dedent(raw_token: str) -> str:
    """Given a HURL_BLOCK lexer token (still wrapped in '\"\"\"'),
    strip the surrounding triple-quotes and apply textwrap.dedent.

    Order of operations:
      1. Strip surrounding triple-quotes.
      2. textwrap.dedent (removes common leading whitespace from non-blank lines).
      3. Strip a single leading newline (so the first content line is line 1).
      4. Strip a single trailing newline (so the closing-quote line doesn't add a blank line).

    Steps 3+4 must run AFTER dedent because the closing \"\"\" may sit on a line
    of indent-only whitespace; dedent reduces that to an empty string, leaving
    a trailing newline that step 4 then trims.
    """
    if not (raw_token.startswith('"""') and raw_token.endswith('"""')):
        raise ValueError(f"Not a triple-quoted token: {raw_token[:20]!r}...")
    inner = raw_token[3:-3]
    inner = textwrap.dedent(inner)
    if inner.startswith("\n"):
        inner = inner[1:]
    if inner.endswith("\n"):
        inner = inner[:-1]
    return inner


from dataclasses import dataclass
from typing import Literal, Optional


@dataclass(frozen=True)
class Section:
    name: str           # "Query", "Form", "Multipart", "Cookies", "BasicAuth", "Options"
    lines: tuple[str, ...]  # raw "key: value" lines
    line_range: tuple[int, int]  # (start, end), 1-indexed lines in the dedented block


BodyKind = Literal[
    "json", "xml",
    "multiline_json", "multiline_xml", "multiline_graphql", "multiline_raw", "multiline_plain",
    "oneline",
    "file_ref", "base64", "hex", "text",
]


@dataclass(frozen=True)
class ParsedHurlBlock:
    request_line: str
    inline_headers: tuple[str, ...]   # bare "K: V" lines between request line and first section
    sections: tuple[Section, ...]
    body: Optional[str]
    body_kind: Optional[BodyKind]
    body_line_range: Optional[tuple[int, int]] = None  # (start, end) 1-indexed in dedented block; None if no body


@dataclass(frozen=True)
class HurlSkeleton:
    """Structural skeleton used by Phase 2 shape-diff.

    Captures only structure, never values. Two skeletons are considered
    structurally equal iff every field is equal.
    """
    method: str
    url_segment_count: int    # number of '/' separated segments after host
    url_has_query: bool       # presence of '?' in the URL
    url_has_fragment: bool    # presence of '#' in the URL
    section_names: tuple[str, ...]
    section_keys: tuple[tuple[str, ...], ...]   # parallel to section_names; per-section list of keys
    inline_header_keys: tuple[str, ...]
    body_present: bool
    body_kind: Optional[BodyKind]


import re

_SECTION_RE = re.compile(r'^\[([A-Za-z]+)\]\s*$')
_REQUEST_LINE_RE = re.compile(r'^\s*([A-Z]+)\s+(\S+)\s*$')


def parse_hurl_block(block: str) -> ParsedHurlBlock:
    """Parse a dedented Hurl-mini block into a structured form.

    Does NOT enforce the allowlist — that's hurl_validator's job. This
    parser is permissive: it accepts any [Section] header and any line
    shapes. The validator runs after.

    Body region: everything after the last recognized section. Body kind
    is heuristic on the first non-blank char.
    """
    lines = block.splitlines()
    # Strip trailing blank lines
    while lines and not lines[-1].strip():
        lines.pop()
    if not lines:
        raise ValueError("Empty Hurl-mini block")

    # First non-comment, non-blank line is the request line.
    i = 0
    while i < len(lines) and (not lines[i].strip() or lines[i].lstrip().startswith("#")):
        i += 1
    if i >= len(lines):
        raise ValueError("No request line found")
    request_line = lines[i].strip()
    i += 1

    inline_headers: list[str] = []
    sections: list[Section] = []
    body_lines: list[str] = []
    body_kind: Optional[BodyKind] = None
    body_start_line: Optional[int] = None
    body_end_line: Optional[int] = None

    # Inline-header region: until first [Section] or first body marker.
    while i < len(lines):
        line = lines[i]
        if _SECTION_RE.match(line.strip()):
            break
        if not line.strip():
            i += 1
            break
        if line.lstrip().startswith("#"):
            i += 1
            continue
        inline_headers.append(line.strip())
        i += 1

    # Section + body region
    cur_section_name: Optional[str] = None
    cur_section_lines: list[str] = []
    cur_section_start = i + 1

    def flush_section():
        nonlocal cur_section_name, cur_section_lines, cur_section_start
        if cur_section_name is not None:
            sections.append(Section(
                name=cur_section_name,
                lines=tuple(cur_section_lines),
                line_range=(cur_section_start, i),
            ))
        cur_section_name = None
        cur_section_lines = []

    in_body = False
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        m = _SECTION_RE.match(stripped)
        if m and not in_body:
            flush_section()
            cur_section_name = m.group(1)
            cur_section_start = i + 1
            i += 1
            continue
        if not stripped and cur_section_name is not None and not in_body:
            # End the current section but don't decide body-vs-next-section yet.
            flush_section()
            i += 1
            continue
        if cur_section_name is not None:
            cur_section_lines.append(stripped)
            i += 1
            continue
        if not stripped:
            i += 1
            continue
        # First non-blank, non-section line outside a section -> body.
        in_body = True
        if body_start_line is None:
            body_start_line = i + 1  # 1-indexed
        body_end_line = i + 1
        body_lines.append(line)
        i += 1
    flush_section()

    body: Optional[str] = "\n".join(body_lines) if body_lines else None
    if body:
        body_stripped = body.lstrip()
        if body_stripped.startswith("{") or body_stripped.startswith("["):
            body_kind = "json"
        elif body_stripped.startswith("<"):
            body_kind = "xml"
        elif body_stripped.startswith("```"):
            # Multiline body — sub-kind from the language identifier on the
            # opening fence (next non-newline characters after ``` until newline
            # or whitespace). Empty identifier means raw multiline_plain.
            rest = body_stripped[3:]
            fence_lang = ""
            for ch in rest:
                if ch in "\r\n":
                    break
                if ch.isspace():
                    break
                fence_lang += ch
            fence_lang = fence_lang.lower()
            if fence_lang == "json":
                body_kind = "multiline_json"
            elif fence_lang == "xml":
                body_kind = "multiline_xml"
            elif fence_lang == "graphql":
                body_kind = "multiline_graphql"
            elif fence_lang == "raw":
                body_kind = "multiline_raw"
            elif fence_lang == "":
                body_kind = "multiline_plain"
            else:
                # Unknown language identifier — accept as multiline_plain rather
                # than rejecting at parse time (validator decides if it cares).
                body_kind = "multiline_plain"
        elif body_stripped.startswith("`"):
            # oneline body — single-backtick fenced, new in Hurl 8.x.
            body_kind = "oneline"
        elif body_stripped.startswith("file,"):
            body_kind = "file_ref"
        elif body_stripped.startswith("base64,"):
            body_kind = "base64"
        elif body_stripped.startswith("hex,"):
            body_kind = "hex"
        else:
            body_kind = "text"

    return ParsedHurlBlock(
        request_line=request_line,
        inline_headers=tuple(inline_headers),
        sections=tuple(sections),
        body=body,
        body_kind=body_kind,
        body_line_range=(body_start_line, body_end_line) if body_start_line else None,
    )


def extract_skeleton(parsed: ParsedHurlBlock) -> HurlSkeleton:
    """Derive a structural skeleton from a parsed block.

    All lines (including colonless ones) are represented as keys so that
    smuggling a stray colonless line via ${var} substitution is caught
    by shape-diff. A colonless line shows up as the empty-string key '',
    so a template that legitimately has no such lines diffs against any
    substitution that introduces one.
    """
    m = _REQUEST_LINE_RE.match(parsed.request_line)
    method = m.group(1) if m else ""
    inline_keys = tuple(_line_key(h) for h in parsed.inline_headers)
    section_names = tuple(s.name for s in parsed.sections)
    section_keys = tuple(
        tuple(_line_key(line) for line in s.lines)
        for s in parsed.sections
    )
    url_segment_count, url_has_query, url_has_fragment = _url_shape(parsed.request_line)
    return HurlSkeleton(
        method=method,
        url_segment_count=url_segment_count,
        url_has_query=url_has_query,
        url_has_fragment=url_has_fragment,
        section_names=section_names,
        section_keys=section_keys,
        inline_header_keys=inline_keys,
        body_present=parsed.body is not None,
        body_kind=parsed.body_kind,
    )


def _line_key(line: str) -> str:
    """Return the key (left of first ':') of a header/section line.
    Colonless lines yield '' so they're still represented in the skeleton.
    """
    if ":" in line:
        return line.split(":", 1)[0].strip()
    return ""


def _url_shape(request_line: str) -> tuple[int, bool, bool]:
    """Return (segment_count, has_query, has_fragment) for the URL on the request line.
    Falls back to (0, False, False) on malformed request lines.

    Two URL prefix shapes are recognised as "host" prefixes that contribute
    no path segments:

      * a literal scheme: ``http://host[:port]`` / ``https://host[:port]``
      * a leading ``${VAR}`` placeholder used as a base-URL stand-in,
        e.g. ``${API_BASE}/news`` — the ``${VAR}`` is treated as the host
        slot, so only segments after the next ``/`` are counted.

    The placeholder normalisation lets a template URL of the form
    ``${API_BASE}/path`` shape-match its substituted form
    ``http://host:port/path`` (both end up with the same path segment
    count). Malicious substitution that injects extra path segments still
    fails the diff because the substituted URL exposes them past the host.
    """
    parts = request_line.split(None, 1)
    if len(parts) < 2:
        return (0, False, False)
    url = parts[1].strip()
    has_query = "?" in url
    has_fragment = "#" in url
    # Strip a host prefix (literal scheme OR leading ${VAR} placeholder)
    # so that segment counting only sees the path.
    path_part = url
    for prefix in ("https://", "http://"):
        if path_part.startswith(prefix):
            rest = path_part[len(prefix):]
            slash = rest.find("/")
            path_part = rest[slash:] if slash >= 0 else "/"
            break
    else:
        if path_part.startswith("${"):
            close = path_part.find("}")
            if close >= 0:
                tail = path_part[close + 1:]
                slash = tail.find("/")
                path_part = tail[slash:] if slash >= 0 else "/"
    # Strip query/fragment for segment counting.
    for sep in ("?", "#"):
        idx = path_part.find(sep)
        if idx >= 0:
            path_part = path_part[:idx]
    if not path_part or path_part == "/":
        return (0, has_query, has_fragment)
    segments = [s for s in path_part.split("/") if s]
    return (len(segments), has_query, has_fragment)
