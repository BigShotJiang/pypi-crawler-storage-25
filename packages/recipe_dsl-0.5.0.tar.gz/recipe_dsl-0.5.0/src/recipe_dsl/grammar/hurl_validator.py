"""Phase 1 (template-time) and Phase 2 (runtime) validation for Hurl-mini blocks.

Phase 1 runs at recipe parse time on the raw template. It enforces:
  - Section name allowlist
  - [Options] sub-key allowlist
  - Inline pattern denylist (HTTP <num>, {{ outside body)
  - Request line well-formedness

Phase 2 runs at execution time on the substituted block. It re-runs Phase 1
checks on the substituted form AND performs structural shape-diff against
the template skeleton. Phase 2 is the injection-prevention barrier and is
implemented in Phase C of the plan.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from recipe_dsl.grammar.hurl_block import ParsedHurlBlock, parse_hurl_block

ALLOWED_SECTIONS = frozenset({
    "Query", "Form", "Multipart", "Cookies", "BasicAuth", "Options",
})

# Deliberately forbidden in Hurl-mini (rejected by allowlist):
#   output, variable, skip, repeat, secret
# `secret` (new in 8.x) defines a Hurl variable redacted in output;
# it conflicts with the single-interpolation-layer rule (RecipeDSL ${var}
# is the only interpolation; Hurl {{var}} is forbidden everywhere).
# Deferred (file-based auth, niche): netrc, netrc-file, netrc-optional.
ALLOWED_OPTIONS = frozenset({
    "aws-sigv4", "cacert", "cert", "compressed",
    "connect-timeout", "connect-to",
    "delay", "digest", "header",
    "http1.0", "http1.1", "http2", "http3",
    "insecure", "ipv4", "ipv6",
    "key", "limit-rate", "location", "location-trusted",
    "max-filesize", "max-redirs", "max-time",
    "negotiate", "no-cookie-store", "no-proxy",
    "ntlm", "path-as-is",
    "pinnedpubkey", "proxy", "resolve", "retry", "retry-interval",
    "ssl-no-revoke", "unix-socket", "user", "verbose",
    "verbosity", "very-verbose",
})

ALLOWED_METHODS = frozenset({
    "GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS",
})

_RESPONSE_STATUS_RE = re.compile(r'^HTTP\s+\d+', re.MULTILINE)
_HURL_TEMPLATE_RE = re.compile(r'\{\{|\}\}')


@dataclass
class ValidationError:
    message: str
    block_line: int  # 1-indexed line in the dedented block; 0 if block-wide


def validate_phase1(block: str, parsed: ParsedHurlBlock | None = None) -> list[ValidationError]:
    """Run Phase 1 checks. Returns list of errors (empty == valid)."""
    if parsed is None:
        parsed = parse_hurl_block(block)
    errors: list[ValidationError] = []

    # 1. Request line method check
    parts = parsed.request_line.split(None, 1)
    if len(parts) < 2:
        errors.append(ValidationError("malformed request line (need METHOD URL)", 1))
    else:
        method = parts[0]
        if method not in ALLOWED_METHODS:
            errors.append(ValidationError(f"unsupported HTTP method '{method}'", 1))

    # 2. Section allowlist
    for s in parsed.sections:
        if s.name not in ALLOWED_SECTIONS:
            errors.append(ValidationError(
                f"section [{s.name}] not in allowed Hurl-mini surface",
                s.line_range[0],
            ))

    # 3. [Options] sub-allowlist
    for s in parsed.sections:
        if s.name != "Options":
            continue
        for offset, line in enumerate(s.lines):
            if ":" not in line:
                continue
            key = line.split(":", 1)[0].strip()
            if key not in ALLOWED_OPTIONS:
                errors.append(ValidationError(
                    f"option '{key}' not allowed in [Options]",
                    s.line_range[0] + 1 + offset,
                ))

    # 4. Inline pattern denylist (response status line, Hurl templating)
    # Response status lines (HTTP <num>) are forbidden anywhere in the block:
    # in real Hurl they start the response section, so a body that begins with
    # such a line would be misread as a response by a Hurl runner. Templating
    # ({{...}}) is checked only outside the body region — body content is opaque.
    for m in _RESPONSE_STATUS_RE.finditer(block):
        line_no = block[:m.start()].count("\n") + 1
        errors.append(ValidationError(
            "response status line not allowed in Hurl-mini; RecipeDSL handles status",
            line_no,
        ))
    for m in _HURL_TEMPLATE_RE.finditer(block):
        line_no = block[:m.start()].count("\n") + 1
        errors.append(ValidationError(
            "Hurl variable templating ({{...}}) not allowed; use RecipeDSL ${var} instead",
            line_no,
        ))

    return errors


from recipe_dsl.errors.request_errors import RequestValidationError
from recipe_dsl.grammar.hurl_block import HurlSkeleton, extract_skeleton


def validate_phase2(
    substituted_block: str,
    template_skeleton: HurlSkeleton,
    substituted_vars: dict[str, str] | None = None,
    recipe_location: str | None = None,
) -> None:
    """Phase 2 validation. Raises RequestValidationError if the substituted
    block contains forbidden constructs OR differs structurally from the
    template skeleton.

    Part A: re-run Phase 1 checks on the substituted block.
    Part B: structural shape-diff against the template skeleton.
    """
    parsed = parse_hurl_block(substituted_block)

    # Part A: re-run Phase 1
    errors = validate_phase1(substituted_block, parsed)
    if errors:
        culprit = _identify_culprit(errors[0].message, substituted_vars or {})
        msg = errors[0].message
        if culprit:
            msg += f" (likely culprit: ${{{culprit}}})"
        raise RequestValidationError(
            msg, recipe_location=recipe_location, culprit_var=culprit
        )

    # Part B: structural shape-diff
    actual_skeleton = extract_skeleton(parsed)
    diff = _skeleton_diff(template_skeleton, actual_skeleton)
    if diff:
        culprit = _identify_culprit_by_newline(substituted_vars or {})
        msg = (f"Variable substitution introduced a structural change: {diff}. "
               f"Template structure differs from substituted structure.")
        if culprit:
            msg += f" (likely culprit: ${{{culprit}}})"
        raise RequestValidationError(
            msg, recipe_location=recipe_location, culprit_var=culprit
        )


def _skeleton_diff(template: HurlSkeleton, actual: HurlSkeleton) -> str | None:
    """Return a one-line description of the first structural difference,
    or None if the skeletons are equal."""
    if template.method != actual.method:
        return f"method changed from {template.method!r} to {actual.method!r}"
    if template.url_segment_count != actual.url_segment_count:
        return (f"URL segment count changed from {template.url_segment_count} "
                f"to {actual.url_segment_count}")
    if template.url_has_query != actual.url_has_query:
        return f"URL query presence changed from {template.url_has_query} to {actual.url_has_query}"
    if template.url_has_fragment != actual.url_has_fragment:
        return (f"URL fragment presence changed from {template.url_has_fragment} "
                f"to {actual.url_has_fragment}")
    if template.section_names != actual.section_names:
        return (f"section list changed from {list(template.section_names)} "
                f"to {list(actual.section_names)}")
    if template.section_keys != actual.section_keys:
        return (f"section keys changed from {[list(k) for k in template.section_keys]} "
                f"to {[list(k) for k in actual.section_keys]}")
    if template.inline_header_keys != actual.inline_header_keys:
        return (f"inline header keys changed from {list(template.inline_header_keys)} "
                f"to {list(actual.inline_header_keys)}")
    if template.body_present != actual.body_present:
        return (f"body presence changed from {template.body_present} "
                f"to {actual.body_present}")
    # Skip body_kind check when template is 'text' (catch-all kind, typically
    # a bare ${var} placeholder). Once the template commits to a specific kind
    # via a literal body prefix ({, [, <, ```, file,, base64,, hex,), kind
    # transitions remain real structural changes.
    if template.body_kind != "text" and template.body_kind != actual.body_kind:
        return f"body kind changed from {template.body_kind!r} to {actual.body_kind!r}"
    return None


def _identify_culprit_by_newline(substituted_vars: dict[str, str]) -> str | None:
    """If exactly one variable's value contains a newline, that's the likely culprit."""
    candidates = [k for k, v in substituted_vars.items() if "\n" in v]
    return candidates[0] if len(candidates) == 1 else None


def _identify_culprit(error_message: str, substituted_vars: dict[str, str]) -> str | None:
    """Best-effort: find the variable whose value contains the offending substring."""
    needles: list[str] = []
    if "[Asserts]" in error_message:
        needles.append("[Asserts]")
    if "[Captures]" in error_message:
        needles.append("[Captures]")
    if "templating" in error_message:
        needles.append("{{")
        needles.append("}}")
    if "status line" in error_message:
        needles.append("HTTP ")
    if "option" in error_message and "not allowed" in error_message:
        import re
        m = re.search(r"option '(\S+)'", error_message)
        if m:
            needles.append(m.group(1))
    if "section [" in error_message:
        import re
        m = re.search(r"section \[([A-Za-z]+)\]", error_message)
        if m:
            needles.append(f"[{m.group(1)}]")
    for var, value in substituted_vars.items():
        for needle in needles:
            if needle in value:
                return var
    return None
