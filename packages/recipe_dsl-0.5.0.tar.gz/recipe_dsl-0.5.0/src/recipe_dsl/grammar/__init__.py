"""RecipeDSL grammar module."""

from recipe_dsl.grammar.parser import Parser

__all__ = ["Parser"]
