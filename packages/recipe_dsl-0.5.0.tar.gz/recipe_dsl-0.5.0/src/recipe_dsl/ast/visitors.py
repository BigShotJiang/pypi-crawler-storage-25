"""Visitor pattern for AST traversal."""

from typing import Any, TypeVar

from recipe_dsl.ast.nodes import (
    ArithmeticOp,
    ASTNode,
    BinaryOp,
    FieldDef,
    Identifier,
    Input,
    Literal,
    Output,
    Pipeline,
    TableType,
    TypeName,
)

T = TypeVar("T")


class ASTVisitor:
    """Base visitor class for traversing the AST.

    Subclass this and override visit_* methods for specific node types.
    Default behavior is to visit all children.
    """

    def visit(self, node: ASTNode) -> Any:
        """Dispatch to the appropriate visit method based on node type."""
        method_name = f"visit_{type(node).__name__}"
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node: ASTNode) -> None:
        """Default visitor that does nothing.

        Override this to change default behavior for unhandled node types.
        """

    def visit_Pipeline(self, node: Pipeline) -> Any:
        """Visit a Pipeline node."""
        self.visit(node.name)
        for input_node in node.inputs:
            self.visit(input_node)
        for body_item in node.body:
            if isinstance(body_item, ASTNode):
                self.visit(body_item)
        if node.outputs:
            self.visit(node.outputs)

    def visit_Input(self, node: Input) -> Any:
        """Visit an Input node."""
        self.visit(node.name)
        self.visit(node.type_expr)

    def visit_Output(self, node: Output) -> Any:
        """Visit an Output node."""
        self.visit(node.name)

    def visit_ArithmeticOp(self, node: ArithmeticOp) -> Any:
        """Visit an ArithmeticOp node."""
        self.visit(node.left)
        self.visit(node.right)

    def visit_BinaryOp(self, node: BinaryOp) -> Any:
        """Visit a BinaryOp node."""
        self.visit(node.left)
        self.visit(node.right)

    def visit_Literal(self, node: Literal) -> Any:
        """Visit a Literal node."""
        self.generic_visit(node)

    def visit_TableType(self, node: TableType) -> Any:
        """Visit a TableType node."""
        for field_node in node.fields:
            self.visit(field_node)

    def visit_FieldDef(self, node: FieldDef) -> Any:
        """Visit a FieldDef node."""
        self.visit(node.name)
        self.visit(node.type_name)

    def visit_Identifier(self, node: Identifier) -> Any:
        """Visit an Identifier node."""
        self.generic_visit(node)

    def visit_TypeName(self, node: TypeName) -> Any:
        """Visit a TypeName node."""
        self.generic_visit(node)


class ASTPrinter(ASTVisitor):
    """Visitor that prints the AST in a readable format."""

    def __init__(self) -> None:
        """Initialize the printer with zero indentation."""
        self._indent = 0
        self._output: list[str] = []

    def _emit(self, text: str) -> None:
        """Emit a line with current indentation."""
        self._output.append("  " * self._indent + text)

    def get_output(self) -> str:
        """Get the accumulated output as a string."""
        return "\n".join(self._output)

    def visit_Pipeline(self, node: Pipeline) -> None:
        """Print a Pipeline node."""
        self._emit(f"Pipeline: {node.name.name}")
        self._indent += 1
        self._emit("Inputs:")
        self._indent += 1
        for input_node in node.inputs:
            self.visit(input_node)
        self._indent -= 1
        if node.body:
            self._emit("Body:")
            self._indent += 1
            for body_item in node.body:
                if isinstance(body_item, ASTNode):
                    self.visit(body_item)
            self._indent -= 1
        if node.outputs:
            self._emit("Output:")
            self._indent += 1
            self.visit(node.outputs)
            self._indent -= 1
        self._indent -= 1

    def visit_Input(self, node: Input) -> None:
        """Print an Input node."""
        self._emit(f"Input: {node.name.name}")
        self._indent += 1
        self.visit(node.type_expr)
        self._indent -= 1

    def visit_Output(self, node: Output) -> None:
        """Print an Output node."""
        self._emit(f"Output: {node.name.name}")

    def _format_arith(self, node: Any) -> str:
        """Format an arithmetic expression as a string."""
        if isinstance(node, ArithmeticOp):
            left = self._format_arith(node.left)
            right = self._format_arith(node.right)
            return f"({left} {node.operator} {right})"
        elif isinstance(node, Identifier):
            return node.name
        elif isinstance(node, Literal):
            return str(node.value)
        return str(node)

    def visit_BinaryOp(self, node: BinaryOp) -> None:
        """Print a BinaryOp node."""
        self._emit(f"{node.left.name} {node.operator} {node.right.value}")

    def visit_TableType(self, node: TableType) -> None:
        """Print a TableType node."""
        self._emit("TableType:")
        self._indent += 1
        for field_node in node.fields:
            self.visit(field_node)
        self._indent -= 1

    def visit_FieldDef(self, node: FieldDef) -> None:
        """Print a FieldDef node."""
        self._emit(f"Field: {node.name.name}: {node.type_name.name}")
