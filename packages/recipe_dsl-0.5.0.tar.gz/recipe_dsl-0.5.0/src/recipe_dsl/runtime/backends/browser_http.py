"""Browser-flavored HTTP backend used by NAVIGATE / GET_CONTENT.

REQUEST is now handled by HurlBackend (runtime/backends/hurl.py).
"""
from __future__ import annotations

import time

import httpx
from markdownify import markdownify


class BrowserHttpBackend:
    """Synchronous HTTP backend using httpx for page-style fetches."""

    def __init__(self, delay: float = 1.5) -> None:
        self._client: httpx.Client | None = None
        self._delay = delay
        self._call_count = 0
        self._last_html: str = ""

    def open(self) -> "BrowserHttpBackend":
        self._client = httpx.Client(
            follow_redirects=True,
            timeout=30,
            headers={"User-Agent": "RecipeDSL/0.1"},
        )
        return self

    def close(self) -> None:
        if self._client:
            self._client.close()
            self._client = None

    def __enter__(self) -> "BrowserHttpBackend":
        return self.open()

    def __exit__(self, *exc: object) -> None:
        self.close()

    def navigate(self, url: str) -> None:
        if self._client is None:
            self.open()
        self._call_count += 1
        if self._call_count > 1:
            time.sleep(self._delay)
        resp = self._client.get(url)
        resp.raise_for_status()
        self._last_html = resp.text

    def get_content(self) -> str:
        return markdownify(self._last_html)

    def get_html(self) -> str:
        return self._last_html
