"""SQLAlchemy backend for RecipeDSL — read-only SQL query execution."""

from typing import Any

from sqlalchemy import bindparam, create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.exc import SQLAlchemyError


class SqlBackend:
    """SQLAlchemy Core backend for executing read-only SQL queries."""

    def __init__(self) -> None:
        self._engines: dict[str, Engine] = {}

    def _get_engine(self, connection_string: str) -> Engine:
        """Get or create a SQLAlchemy engine for the given connection string."""
        if connection_string not in self._engines:
            try:
                self._engines[connection_string] = create_engine(connection_string)
            except Exception as e:
                raise RuntimeError(
                    f"Could not parse SQLAlchemy URL from: {repr(connection_string)}. "
                    f"Error: {e}"
                ) from e
        return self._engines[connection_string]

    def close(self) -> None:
        """Dispose all engines."""
        for engine in self._engines.values():
            engine.dispose()
        self._engines.clear()

    def query(
        self,
        connection_string: str,
        sql: str,
        params: dict[str, Any],
        expanding: set[str],
    ) -> list[dict[str, Any]]:
        """Execute a read-only SQL query with bound parameters.

        Args:
            connection_string: SQLAlchemy connection string.
            sql: SQL text with `:name` bind placeholders.
            params: Mapping of bind name to Python value.
            expanding: Subset of `params` keys whose values are sequences
                and should be bound as expanding parameters (for `IN`).

        Returns:
            List of dicts, each representing a row.
        """
        connection_string = connection_string.strip()
        engine = self._get_engine(connection_string)

        stmt = text(sql)
        if expanding:
            stmt = stmt.bindparams(
                *[bindparam(n, expanding=True) for n in expanding]
            )

        try:
            with engine.connect() as conn:
                result = conn.execute(stmt, params)
                return [dict(row) for row in result.mappings()]
        except SQLAlchemyError as e:
            raise RuntimeError(
                f"QUERY execution failed: {e}. "
                f"Hint: ${{var}} substitutes data only — structural positions "
                f"(table, column, ORDER BY) require RecipeDSL IF/ELSE."
            ) from e
