"""HurlBackend — REQUEST execution via the Hurl CLI subprocess."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
from typing import Any

from recipe_dsl.errors.request_errors import (
    RequestRuntimeError, RequestTransportError,
)


class HurlBackend:
    """Drives `hurl --report-json <tempdir> <tempfile>` and maps output
    to the RecipeDSL envelope. Body bytes live in <tempdir>/store/ and
    are read after subprocess exit."""

    DEFAULT_TIMEOUT_SECONDS = 60

    def __init__(self, binary_path: str | None = None,
                 min_version: tuple[int, int] = (8, 0),
                 timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS):
        self._binary = binary_path or self._discover_binary()
        self._min_version = min_version
        self._timeout = timeout_seconds
        self._version_checked = False

    @staticmethod
    def _discover_binary() -> str:
        env = os.environ.get("RECIPE_DSL_HURL_BINARY")
        if env:
            return env
        path = shutil.which("hurl")
        if not path:
            raise RequestRuntimeError(
                "Hurl binary not found. Install hurl >= 8.0 (8.0.1+ recommended), "
                "or set RECIPE_DSL_HURL_BINARY. See docs/hurl-mini-reference.md."
            )
        return path

    def _check_version_once(self) -> None:
        if self._version_checked:
            return
        self._version_checked = True
        try:
            res = subprocess.run(
                [self._binary, "--version"],
                capture_output=True, text=True, timeout=5,
            )
            line = (res.stdout or res.stderr).splitlines()[0] if (res.stdout or res.stderr) else ""
            import re
            m = re.search(r'(\d+)\.(\d+)\.(\d+)', line)
            if m:
                ver = (int(m.group(1)), int(m.group(2)))
                if ver < self._min_version:
                    import warnings
                    warnings.warn(
                        f"hurl version {line.strip()} below minimum "
                        f"{self._min_version[0]}.{self._min_version[1]}; "
                        f"behavior may differ.",
                        RuntimeWarning,
                    )
        except Exception:
            # Don't fail on version-check errors; tests will surface real schema issues.
            pass

    def request(self, block: str) -> dict[str, Any]:
        self._check_version_once()

        with tempfile.TemporaryDirectory(prefix="recipe_dsl_hurl_") as tempdir:
            hurl_file = os.path.join(tempdir, "request.hurl")
            with open(hurl_file, "w", encoding="utf-8") as f:
                f.write(block)

            try:
                res = subprocess.run(
                    [self._binary,
                     "--report-json", tempdir,
                     "--no-color", "--error-format", "short",
                     hurl_file],
                    capture_output=True, text=True, timeout=self._timeout,
                )
            except subprocess.TimeoutExpired as e:
                raise RequestTransportError(f"hurl invocation timed out: {e}") from e
            except FileNotFoundError as e:
                raise RequestRuntimeError(f"hurl binary not executable: {e}") from e

            report_path = os.path.join(tempdir, "report.json")
            if not os.path.exists(report_path):
                raise RequestTransportError(
                    f"hurl exited with code {res.returncode}: {res.stderr.strip()}"
                )

            try:
                with open(report_path, "r", encoding="utf-8") as rf:
                    data = json.load(rf)
            except (OSError, json.JSONDecodeError) as e:
                raise RequestRuntimeError(
                    f"could not read/parse hurl report.json: {e}; "
                    f"stderr={res.stderr!r}"
                ) from e

            return self._envelope_from_json(data, tempdir)

    @staticmethod
    def _envelope_from_json(data: Any, tempdir: str) -> dict[str, Any]:
        """Map hurl --report-json schema to the RecipeDSL envelope.

        The Hurl 8.0+ report.json is a top-level list of run records, each
        with entries → calls → request/response. The response body is a
        relative path under tempdir (typically `store/<uuid>_response.<ext>`)
        which we read as UTF-8 text.

        Raises RequestRuntimeError on schema mismatch.
        """
        try:
            if not isinstance(data, list) or not data:
                raise ValueError("report.json must be a non-empty list")
            run = data[0]
            entries = run.get("entries") or []
            if not entries:
                raise ValueError("report.json run has no entries")
            entry = entries[0]
            calls = entry.get("calls") or []
            if not calls:
                raise ValueError("report.json entry has no calls")
            # When [Options] location: true follows redirects, hurl emits
            # one call per hop in calls[]. The final hop's response is the
            # one the recipe sees as `response`. With no redirects, len(calls)
            # is 1 and calls[-1] == calls[0], so this works in both cases.
            call = calls[-1]
            resp = call["response"]
            status = int(resp["status"])

            raw_headers = resp.get("headers", []) or []
            headers: dict[str, str] = {}
            for h in raw_headers:
                k = h["name"].lower()
                v = h["value"]
                headers[k] = v  # last wins on duplicates

            body_path = resp.get("body")
            if not body_path:
                raise ValueError("response.body path missing from report.json")
            body_file = os.path.join(tempdir, body_path)
            try:
                with open(body_file, "r", encoding="utf-8") as bf:
                    body = bf.read()
            except UnicodeDecodeError as e:
                raise RequestRuntimeError(
                    f"response body is not valid UTF-8 ({e}); binary bodies "
                    f"are deferred — see hurl-mini-reference 'What we don't handle'."
                ) from e
            except OSError as e:
                raise RequestRuntimeError(f"cannot read response body file {body_file}: {e}") from e

            time_ms = int(entry.get("time", 0))
            url = call.get("request", {}).get("url", "")
        except (KeyError, IndexError, TypeError, ValueError) as e:
            raise RequestRuntimeError(
                f"hurl --report-json schema mismatch ({e}); is the installed Hurl "
                f">= 8.0 as configured?"
            ) from e

        return {
            "status": status,
            "headers": headers,
            "body": body,
            "time_ms": time_ms,
            "url": url,
        }

    def close(self) -> None:
        """No persistent state to close; subprocess per request."""
        pass
