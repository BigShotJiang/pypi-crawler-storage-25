"""Playwright browser backend for RecipeDSL — JS-heavy site support."""

from markdownify import markdownify


class BrowserBackend:
    """Synchronous Playwright backend for browser interaction."""

    def __init__(self) -> None:
        self._playwright = None
        self._browser = None
        self._page = None
        self._last_html: str = ""

    def open(self) -> "BrowserBackend":
        from playwright.sync_api import sync_playwright

        self._playwright = sync_playwright().start()
        self._browser = self._playwright.chromium.launch(headless=True)
        self._page = self._browser.new_page()
        return self

    def close(self) -> None:
        if self._browser:
            self._browser.close()
            self._browser = None
        if self._playwright:
            self._playwright.stop()
            self._playwright = None
        self._page = None

    def __enter__(self) -> "BrowserBackend":
        return self.open()

    def __exit__(self, *exc: object) -> None:
        self.close()

    def navigate(self, url: str) -> None:
        self._page.goto(url, wait_until="domcontentloaded")
        self._last_html = self._page.content()

    def get_content(self) -> str:
        self._last_html = self._page.content()
        return markdownify(self._last_html)

    def get_html(self) -> str:
        self._last_html = self._page.content()
        return self._last_html

    def click(self, selector: str) -> None:
        self._page.click(selector)

    def type_text(self, selector: str, text: str) -> None:
        self._page.fill(selector, text)

    def wait_for(self, selector: str) -> None:
        self._page.wait_for_selector(selector)

    def scroll(self, direction: str) -> None:
        if direction == "DOWN":
            self._page.evaluate("window.scrollBy(0, window.innerHeight)")
        elif direction == "UP":
            self._page.evaluate("window.scrollBy(0, -window.innerHeight)")
        elif direction == "BOTTOM":
            self._page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        elif direction == "TOP":
            self._page.evaluate("window.scrollTo(0, 0)")
