"""RecipeDSL: LLM-optimized DSL for data transformations."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("recipe-dsl")
except PackageNotFoundError:
    __version__ = "0.0.0+dev"
