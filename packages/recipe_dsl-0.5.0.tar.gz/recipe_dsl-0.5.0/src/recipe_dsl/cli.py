"""Command-line interface for RecipeDSL."""

import json
import sys
from pathlib import Path
from typing import Any, Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax

from recipe_dsl import __version__
from recipe_dsl.ast.visitors import ASTPrinter
from recipe_dsl.grammar.parser import Parser
from recipe_dsl.runtime.interpreter import Interpreter
from recipe_dsl.runtime.interpreter import RuntimeError as RecipeDSLRuntimeError

console = Console()
error_console = Console(stderr=True)


def _resolve_data_dir(subdir: str, marker: str) -> Path:
    """Return the directory that holds packaged data files (docs/examples).

    Wheel install: files live under recipe_dsl/<subdir>/ (copied in by
    setup.py's build_py override). PyInstaller --onefile: data added via
    --add-data lives under sys._MEIPASS/recipe_dsl/<subdir>/. Editable
    install: setup hook didn't run, so fall back to the repo-root sibling
    at <repo>/<subdir>/. The *marker* is one filename whose presence
    proves the directory is populated.
    """
    if getattr(sys, "frozen", False):
        meipass = Path(getattr(sys, "_MEIPASS", ""))
        frozen = meipass / "recipe_dsl" / subdir
        if (frozen / marker).is_file():
            return frozen
    pkg = Path(__file__).resolve().parent / subdir
    if (pkg / marker).is_file():
        return pkg
    return Path(__file__).resolve().parents[2] / subdir


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="recipe-dsl")
@click.option("--repl", is_flag=True, help="Start interactive REPL")
@click.pass_context
def main(ctx: click.Context, repl: bool) -> None:
    """RecipeDSL: LLM-optimized DSL for tabular data transformations.

    Run a RecipeDSL file or start the interactive REPL.

    Examples:
        recipe-dsl run program.rdsl --input-file data.json      # Execute with JSON input
        recipe-dsl run program.rdsl                             # Execute (env vars auto-loaded)
        recipe-dsl parse program.rdsl                           # Parse and show AST
        recipe-dsl check program.rdsl                           # Check for errors
        recipe-dsl --repl                                       # Start interactive REPL
    """
    if repl:
        run_repl()
    elif ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def run_file(path: str, input_file: Optional[str] = None) -> None:
    """Parse and optionally execute a RecipeDSL file.

    Args:
        path: Path to the .rdsl file.
        input_file: Optional path to JSON file with input data.
    """
    try:
        parser = Parser()
        ast = parser.parse_file(path)

        if input_file:
            # Execute the pipeline with input data
            inputs = load_input_data(input_file)
            interpreter = Interpreter()
            result = interpreter.execute(ast, inputs)

            # Print the result as JSON
            console.print(Panel(
                f"[bold]Pipeline:[/bold] {ast.name.name}",
                title="[bold blue]Execution Result[/bold blue]",
                border_style="blue",
            ))
            console.print_json(data=result)
        else:
            # Just print the AST
            printer = ASTPrinter()
            printer.visit(ast)

            console.print(Panel(
                printer.get_output(),
                title=f"[bold green]AST for {Path(path).name}[/bold green]",
                border_style="green",
            ))

    except FileNotFoundError:
        error_console.print(f"[red]Error:[/red] File not found: {path}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        error_console.print(f"[red]JSON Error:[/red] {e}")
        sys.exit(1)
    except RecipeDSLRuntimeError as e:
        error_console.print(f"[red]Runtime Error:[/red] {e.message}")
        sys.exit(1)
    except Exception as e:
        error_console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


def load_input_data(input_file: str) -> dict[str, list[dict[str, Any]]]:
    """Load input data from a JSON file.

    Args:
        input_file: Path to JSON file.

    Returns:
        Dictionary mapping input names to table data.

    Raises:
        json.JSONDecodeError: If JSON is invalid.
        FileNotFoundError: If file doesn't exist.
    """
    with open(input_file, encoding="utf-8") as f:
        return json.load(f)  # type: ignore[no-any-return]


def run_repl() -> None:
    """Start the interactive REPL."""
    console.print(Panel(
        f"RecipeDSL REPL v{__version__}\n"
        "Type 'exit' or 'quit' to exit, 'help' for help.",
        title="[bold blue]Welcome to RecipeDSL[/bold blue]",
        border_style="blue",
    ))

    parser = Parser()
    buffer: list[str] = []

    while True:
        try:
            prompt = "... " if buffer else ">>> "
            line = console.input(f"[bold cyan]{prompt}[/bold cyan]")

            # Handle commands
            if not buffer:
                if line.lower() in ("exit", "quit"):
                    console.print("[dim]Goodbye![/dim]")
                    break
                if line.lower() == "help":
                    print_help()
                    continue
                if line.lower() == "clear":
                    console.clear()
                    continue
                if not line.strip():
                    continue

            buffer.append(line)

            # Try to parse if we have a complete pipeline
            source = "\n".join(buffer)
            if "OUTPUT" in source:
                try:
                    ast = parser.parse(source)
                    printer = ASTPrinter()
                    printer.visit(ast)
                    console.print()
                    console.print(Syntax(printer.get_output(), "yaml", theme="monokai"))
                    console.print()
                    buffer = []
                except Exception:
                    # Not complete yet, keep buffering
                    pass

        except KeyboardInterrupt:
            console.print("\n[dim]Use 'exit' to quit[/dim]")
            buffer = []
        except EOFError:
            console.print("\n[dim]Goodbye![/dim]")
            break


def print_help() -> None:
    """Print REPL help message."""
    help_text = """
[bold]Commands:[/bold]
  exit, quit  Exit the REPL
  help        Show this help message
  clear       Clear the screen

[bold]Example:[/bold]
  >>> PIPELINE hello:
  ...   SET greeting = "Hello world"
  ...   OUTPUT greeting

[bold]The AST will be printed when a complete pipeline is entered.[/bold]
"""
    console.print(Panel(help_text, title="[bold]Help[/bold]", border_style="yellow"))


@main.command()
@click.argument("file", type=click.Path(exists=True))
def parse(file: str) -> None:
    """Parse a RecipeDSL file and print the AST."""
    run_file(file)


@main.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--json", "json_output", is_flag=True, help="Output errors as JSON")
def check(file: str, json_output: bool) -> None:
    """Check a RecipeDSL file for errors (parsing only for now)."""
    try:
        parser = Parser()
        parser.parse_file(file)
        if json_output:
            print(json.dumps({"status": "ok", "errors": []}))
        else:
            console.print(f"[green]OK:[/green] {file}")
    except Exception as e:
        if json_output:
            # Try to extract line/column from Lark errors
            error_info = {"message": str(e), "line": 1, "column": 1}
            error_str = str(e)
            # Lark errors often contain "at line X, column Y"
            import re
            line_match = re.search(r"line (\d+)", error_str)
            col_match = re.search(r"column (\d+)", error_str)
            if line_match:
                error_info["line"] = int(line_match.group(1))
            if col_match:
                error_info["column"] = int(col_match.group(1))
            print(json.dumps({"status": "error", "errors": [error_info]}))
        else:
            error_console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@main.command()
def explain() -> None:
    """Show the full syntax guide, Hurl-mini reference, all example recipes, and the gotchas log."""
    docs = _resolve_data_dir("docs", "syntax-guide.md")
    examples_dir = _resolve_data_dir("examples", "sales_report.rdsl")

    # Print syntax guide
    try:
        print((docs / "syntax-guide.md").read_text(encoding="utf-8"))
    except (FileNotFoundError, ModuleNotFoundError):
        error_console.print("[red]Error:[/red] docs/syntax-guide.md not found")
        sys.exit(1)

    # Hurl-mini reference (between syntax-guide and examples).
    print()
    print("## Hurl-mini Reference")
    print()
    try:
        print((docs / "hurl-mini-reference.md").read_text(encoding="utf-8"))
    except (FileNotFoundError, ModuleNotFoundError):
        error_console.print("[red]Error:[/red] docs/hurl-mini-reference.md not found")
        sys.exit(1)

    print()
    print("## Further examples")
    print()

    try:
        for example in sorted(examples_dir.glob("*.rdsl")):  # type: ignore[attr-defined]
            print(f"### {example.name}")
            print()
            print("```rdsl")
            print(example.read_text(encoding="utf-8").rstrip())
            print("```")
            print()
    except (FileNotFoundError, ModuleNotFoundError):
        error_console.print("[red]Error:[/red] examples/ directory not found")
        sys.exit(1)

    for name in ("gotchas.recipe-dsl.md", "gotchas.hurl-mini.md"):
        try:
            print()
            print((docs / name).read_text(encoding="utf-8"))
        except (FileNotFoundError, ModuleNotFoundError):
            error_console.print(f"[red]Error:[/red] docs/{name} not found")
            sys.exit(1)


@main.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--input-file", "input_file", type=click.Path(exists=True), help="JSON file with input data")
@click.option("--json", "json_output", is_flag=True, help="Output raw JSON only")
def run(file: str, input_file: Optional[str], json_output: bool) -> None:
    """Execute a RecipeDSL file.

    Environment variables and .env file values are automatically available
    as scalar variables in the pipeline. Use --input-file to pass table data.
    """
    try:
        parser = Parser()
        ast = parser.parse_file(file)

        inputs: Optional[dict[str, Any]] = None
        if input_file:
            inputs = load_input_data(input_file)

        interpreter = Interpreter()
        result = interpreter.execute(ast, inputs)

        if json_output:
            print(json.dumps(result, default=str))
        else:
            console.print(Panel(
                f"[bold]Pipeline:[/bold] {ast.name.name}",
                title="[bold blue]Execution Result[/bold blue]",
                border_style="blue",
            ))
            console.print_json(data=result)

    except FileNotFoundError:
        error_console.print(f"[red]Error:[/red] File not found: {file}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        error_console.print(f"[red]JSON Error:[/red] {e}")
        sys.exit(1)
    except RecipeDSLRuntimeError as e:
        error_console.print(f"[red]Runtime Error:[/red] {e.message}")
        sys.exit(1)
    except Exception as e:
        error_console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
