![RecipeDSL](https://raw.githubusercontent.com/deai-network/recipe-dsl/main/images/RecipeDSL.jpeg)

# RecipeDSL

A domain-specific language for data gathering and transformations, designed for LLM code generation accuracy.

RecipeDSL combines data from multiple sources — SQL databases, REST APIs, local files, and web pages — then transforms it using tabular operations. Its constrained, explicit syntax reduces common LLM errors when generating data pipelines.

## Origin

RecipeDSL is forked from [Anka](https://github.com/BleBlo/Anka), a DSL that outperforms Python on multi-step data transformation tasks (+40% accuracy on complex pipelines). See the paper: [Anka: A Domain-Specific Language for Reliable LLM Code Generation](https://arxiv.org/abs/2512.23214).

We extend Anka with bridge operations for SQL databases, REST APIs, and web scraping, while preserving its tabular transformation core.

## Example

```rdsl
PIPELINE enrich_users_from_api:
  -- Query a database
  QUERY "${DB_URL}" "SELECT id, name, email FROM users WHERE active = 1" INTO users

  -- Fetch data from a REST API
  REQUEST CONCAT("${API_BASE}", "/roles") METHOD "GET" INTO response
  EXTRACT_FIELD response PATH "data" INTO roles

  -- Join the two sources — something SQL alone can't do
  STEP enrich:
    JOIN users WITH roles
    ON users.id == roles.user_id
    INTO enriched

  STEP select_fields:
    SELECT name, email, role_name FROM enriched INTO results

  OUTPUT results
```

Configuration comes from environment variables or a `.env` file. No input declarations needed.

## Install

Prerequisites:
- Python 3.11 or later
- [hurl](https://hurl.dev/docs/installation.html) >= 8.0 (8.0.1+ recommended) — required for HTTP recipe blocks

```bash
pip install recipe-dsl
```

For MSSQL (SQL Server) support:
```bash
pip install "recipe-dsl[mssql]"
```

For everything (kitchensink):
```bash
pip install "recipe-dsl[all]"
```

## Run

```bash
# Execute a recipe
DB_URL=sqlite:///mydata.db recipe-dsl run my_recipe.rdsl

# Output raw JSON
DB_URL=sqlite:///mydata.db recipe-dsl run my_recipe.rdsl --json
```

## Documentation

- **[Syntax Guide](docs/syntax-guide.md)** — Complete language reference
- **[Architecture Decisions](docs/architecture-decisions/)** — Design rationale
- **[Examples](examples/)** — Working recipes with end-to-end tests

## License

MIT — see [LICENSE](LICENSE) for details.
