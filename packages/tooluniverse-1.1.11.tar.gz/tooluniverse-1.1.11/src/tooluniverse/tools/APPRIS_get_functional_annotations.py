"""
APPRIS_get_functional_annotations

Get detailed functional annotations for gene isoforms from APPRIS, including structural domains (...
"""

from typing import Any, Optional, Callable
from ._shared_client import get_shared_client


def APPRIS_get_functional_annotations(
    gene_id: str,
    species: Optional[str] = "homo_sapiens",
    methods: Optional[str] = None,
    transcript_id: Optional[str] = None,
    *,
    stream_callback: Optional[Callable[[str], None]] = None,
    use_cache: bool = False,
    validate: bool = True,
) -> dict[str, Any]:
    """
    Get detailed functional annotations for gene isoforms from APPRIS, including structural domains (...

    Parameters
    ----------
    gene_id : str
        Ensembl gene ID (e.g., ENSG00000141510 for TP53).
    species : str
        Species name (e.g., homo_sapiens).
    methods : str
        Comma-separated analysis methods to retrieve (e.g., 'firestar,spade,corsair')...
    transcript_id : str
        Optional Ensembl transcript ID to filter results for a specific isoform (e.g....
    stream_callback : Callable, optional
        Callback for streaming output
    use_cache : bool, default False
        Enable caching
    validate : bool, default True
        Validate parameters

    Returns
    -------
    dict[str, Any]
    """
    # Handle mutable defaults to avoid B006 linting error

    # Strip None values so optional parameters don't trigger schema validation errors
    _args = {
        k: v
        for k, v in {
            "gene_id": gene_id,
            "species": species,
            "methods": methods,
            "transcript_id": transcript_id,
        }.items()
        if v is not None
    }
    return get_shared_client().run_one_function(
        {
            "name": "APPRIS_get_functional_annotations",
            "arguments": _args,
        },
        stream_callback=stream_callback,
        use_cache=use_cache,
        validate=validate,
    )


__all__ = ["APPRIS_get_functional_annotations"]
