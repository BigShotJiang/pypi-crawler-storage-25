# -*- coding: utf-8 -*-
"""
Created on Fri Apr 03 17:11:27 2026

Copyright (C) 2023 
@author: Anthony Jeseněk

Downloads the database of cross sections separately from the project hosted on codeberg.org
"""

import os
import urllib.request
import zipfile
import tarfile
import warnings
import logging
import shutil
from pathlib import Path
import site
from setuptools import setup
from setuptools.command.install import install

DATA_URL = "https://codeberg.org/jesenek/elmolcs/archive/main:Data.zip"

def download_data(data_dir):

    # Download and extract the data
    zip_path = data_dir / "Data.zip"

    
    print(f"Downloading data to {data_dir}    ...",end='\t')
    urllib.request.urlretrieve(DATA_URL, zip_path)
    try: # Attempt zip
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(data_dir)
    except zipfile.BadZipFile:
        os.remove(zip_path)
        zip_path = data_dir / "Data.tar.gz"
        warnings.warn(".zip url broken, attempting .tar.gz")
        urllib.request.urlretrieve(DATA_URL.replace('zip','tar.gz'), zip_path)
        try: # Attempt tar.gz
            with tarfile.open(zip_path, 'r:gz') as tar_ref:
                tar_ref.extractall(data_dir)
        except tarfile.TarError:
            logging.error(f".tar.gz file is not valid, try downloading manually: {DATA_URL}")
        except Exception as e:
            logging.error(f"An error occurred: {e}, could not download database, try manually: {DATA_URL}")      
        finally:
            os.remove(zip_path)
    except Exception as e:
        logging.error(f"An error occurred: {e}, could not download database, try manually: {DATA_URL}")
        return

    # The extracted files are in data_dir/elmolcs/
    extracted_elmolcs_dir = data_dir / "elmolcs"

    # Move all contents of extracted_elmolcs_dir to data_dir
    for item in extracted_elmolcs_dir.iterdir():
        shutil.move(str(item), str(data_dir))
    os.rmdir(extracted_elmolcs_dir)

    print("Downloaded.")

class CustomInstallCommand(install):
    def run(self):
        install.run(self)  # Run the standard install first

        # Define the data directory (cross-platform)
        # site_packages = site.getsitepackages()
        # found = False
        # for site_package in site_packages:
        #     if 'site-packages' in site_package: 
        #         found=True
        #         break
        # if not found: warnings.warn("The directory for the cross sections data could possibly be different from where elmolcs is installed")
        # zip_dir =  Path(site_package)

        zip_dir = Path(self.install_lib)
        package_dir = zip_dir / "elmolcs"
        data_dir = package_dir / "Data"
        data_dir.mkdir(parents=True, exist_ok=True)
        # Call your function to download the data
        download_data(data_dir)

setup(
    cmdclass={
        'install': CustomInstallCommand,
    },
)