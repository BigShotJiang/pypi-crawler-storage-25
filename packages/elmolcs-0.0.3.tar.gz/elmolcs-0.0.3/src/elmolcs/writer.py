# -*- coding: utf-8 -*-
"""
Created on Fri May 1 23:36:07 2026

Copyright (C) 2026
@author: Anthony Jeseněk



"""
import constants as co
import numpy as np
import os
import re
from datetime import datetime

me = co.me
ma = co.ma
header = '{1:s}\n{0:s} -> {0:s}{4:s}\n {2:.5e} \nSPECIES: e / {0:s}\nPROCESS: E + {0:s} -> E + {0:s}{4:s}, {3:s}\nPARAM.: {5:s}\nCOMMENT: {1:s} {3:s} : {0:s}{4:s}  | based on {7:s} \nUPDATED: {8:s}\nCOLUMNS: {6:s}\n'
headertabata = '{1:s}\n{0:s} -> {0:s}{4:s}\n {2:.5f} \nSPECIES: e / {0:s}\nPROCESS: E + {0:s} -> E + {0:s}{4:s}, {3:s}\nPARAM.: Eth = {2:.5f} eV, {5:s}\nCOMMENT: {1:s} {3:s} : {4:s}  | Tabata et al. (2006) \nUPDATED: %s\nCOLUMNS: {6:s}\n'%str(datetime(2006,4,26))
HEADER = {0:'%s',1:'%s','SPECIES': 'e / %s','PROCESS': 'e + {0:s} -> e + {0:s}{1:s}','PARAM.':'%s','COMMENT':'%s','UPDATED':'%s','COLUMNS': '%s'}
# (specie, kind, threshold, subkind, final, params, columns, source, updated)

def writeproc_(file,proc): # Only for Tabata et al.
    with open(file,'at',encoding='utf8') as rf:
        for p in proc:
            final = p['final']
            if(final!=''):
                if(p['kind']=='IONIZATION'):
                    final='+'
                else:
                    final = '*(%s)'%p['final']
            chunk = headertabata.format(p['target'],p['kind'],p['threshold'],p['subkind'].capitalize(),final,p['param'],' | '.join(map(lambda i:'a'+str(i),range(1,len(p['data'])+1))))
            dat = ' \t'.join(map(lambda s :'%.3e'%s,p['data']))
            chunk += '-'*(len(dat)+5)+'\n'
            chunk+= dat+'\n'
            chunk+= '-'*(len(dat)+5)+'\n'*3
            rf.write(chunk)

def writeproc(file,proc,format='table'): # format = 'table', 'param' or 'sql'
    if format=='sql':
        writesql(file,proc)
    else:
        with open(file,'at',encoding='utf8') as rf:
            for p in proc:
                final = p['final']
                if(final!=''):
                    if(p['kind']=='IONIZATION'):
                        final='+'
                    else:
                        final = '(%s)'%p['final']
                        if(p['final']!=co.Constants.GND_MOLC[p['target']]): # excited state
                            final = '*'+final
                param = p['param'].copy()
                param['Eth'] = '%g eV'%(p['threshold'])
                targetmass = co.Constants.MASS_MOLC[p['target']]
                pm = p['threshold'] if (p['threshold']!=0) else param.get('m/M',me/(targetmass*ma+me))
                param.pop('E',0)
                if('fitparams' in p):
                    param.update(p['fitparams'])
                param = '; '.join(map(lambda t: '%s=%s'%t,param.items()))
                if(format=='table'):
                    if p['subkind'] == 'ROTATIONAL': #there is a special format for bolsig+
                        chunk = header.format(p['target'],'ROTATION',0,p['subkind'].capitalize(),final,param,' Energy (eV) | Cross Section (m2)',p['source'],str(datetime.today().date()))
                        chunk = chunk.replace('0.00000e+00','{0:.5f}    {1:d}\n{2:.5f}    {3:d}'.format(p['level'],p['g0'],p['level']+p['threshold'],p['gexc']))
                    else:
                        chunk = header.format(p['target'],p['kind'],pm,p['subkind'].capitalize(),final,param,' Energy (eV) | Cross Section (m2)',p['source'],str(datetime.today().date()))
                    dat = p['data'].iloc[:,:1].to_string(index=True,header=False,index_names=False)
                elif(format=='param'):
                    c = p['fitparams']['c']
                    chunk = header.format(p['target'],p['kind'],pm,p['subkind'].capitalize(),final,p['param'],' | '.join(map(lambda i:'a'+str(i+1),range(len(c)))),p['source'],str(datetime.today().date()))
                    dat = ' \t'.join(map(lambda s :'%.3e'%s,c))
                else:
                    raise ValueError('Unknown format %s'%format)
                chunk+= '-'*(len(dat.partition('\n')[0])+5)+'\n'
                chunk+= dat+'\n'
                chunk+= '-'*(len(dat.partition('\n')[0])+5)+'\n'*3
                rf.write(chunk)

def writesql(file,proc,i0=0):
    sqlhead = "INSERT INTO `IAA__elec_cs` (`TARGET SPECIES`, `FINAL STATE`, `COMPLETE SET`, `TYPE OF DATA`, `MASS RATIO (m/M)`, `THRESHOLD ENERGY (E) in eV`, `STAT WEIGHT RATIO (g1/g0)`, `GROUP LABEL`, `THIS DATA COMMENT`, `DATA`, `LAST UPDATE`, `ID (AUTO)`) VALUES"
    sql_kinds = {'MOMENTUM':'ELASTIC','TOTAL':'EFFECTIVE'}
    asymp2deg = {0:'optically-allowed ~ lnε/ε',1:'dipole-forbidden ~ 1/ε',2:'magnetic-dipole-forbidden ~ 1/ε²',3:'spin-forbidden ~ 1/ε³'}
    kind2comment = {'INTEGRAL':'Integral elastic cross section (integrated from differential)','MOMENTUM':'Elastic momentum-transfer cross section','':'Total scattering cross section','RESIDUAL':'Residual elastic cross section (after subtracting all inelastic CS, except rotational exc., from total CS)','TOTAL':'Total ionisation CS based on the RBEQ* model','DISSOCIATIVE':'Dissociative attachment CS','ELECTRONIC':'Electronic excitation CS','DISSOCIATION':'Dissociative excitation CS','VIBRATIONALLY':'','ROTATIONALLY':''}
    items = []
    for i,p in enumerate(proc):
        if p['kind'] == 'BREMSSTRAHLUNG' or p['subkind'] == 'SUM': continue #skip these processes, do not write them
        target = p['target']
        # param = p['param'].copy()

        #Final state
        final = p['final']
        if(final!=''):
            if(p['kind']=='IONIZATION'):
                final=target+'+'
            else:
                if p['kind']!='DISSOCIATION':
                    final = '(%s)'%p['final']
                    if(p['final']!=co.Constants.GND_MOLC[p['target']]): # excited state
                        final = target+'*'+final
                else:
                    final = p['final']
        # completeness
        complete = True
        m_M = None
        group = None

        # stat weight
        g = p['g'][1]/p['g'][0]
        if g%1==0: g = int(g)
        print(p['g'],g)

        # kind
        subkind = p['subkind']
        if subkind in ('VIBRATIONAL','ROTATIONAL'):
            kind = subkind+': eV | m2'
            comment = subkind.capitalize() + f" excitation : {target}({p['initial']}) -> {re.sub('(?<==)[0-9]+-','',final)}"
            final = re.sub('(?<=[0-9])-','->',final) # remove the initial state, unnecessary
            if subkind=='ROTATIONAL':
                group = 'ROTATIONAL'
        else:

            if '+' in subkind: subkind = subkind.split('+')[0]
            comment = kind2comment[subkind]
            kind = sql_kinds.get(p['kind'],p['kind'])+': eV | m2'
            if p['kind'] in ('TOTAL','ELASTIC'):
                group = subkind if p['kind']!='TOTAL' else 'TOTAL'
                complete = False
                m_M = p['mass_ratio']
                g = None
                final = target
            else:
                comment+=f": {target}({p['initial']}) -> {final}"
        # threshold
        thres = p['threshold']
        if thres == 0: thres= None
        else: thres = np.round(thres,4)

        # comment
        if 'fitparams' in p:
            # if 'asymp' in p['fitparams']:
            comment = comment.replace('excitation','(%s) excitation'%asymp2deg[p['asymp']])
            comment+= ' | Fitted with the parameters: c=%s'%str(p['fitparams']['c'])
        comment+=' | Source: '+p['source']

        # data
        data = p['data'].to_string(columns=['CS'],header=False,index_names=False)# '\n'.join(map('\t'.join,p['data'].astype(str))) # that's for numpy

        item = (p['target'],final,complete,kind,m_M,thres,g,group,comment,data,datetime.now().isoformat(' ', 'seconds'),i0+i)
        stritem = repr(item).replace('None','NULL').replace('False',"'NO'").replace('True',"'YES'")+',\n'
        items.append(stritem)
    items[-1] = items[-1][:-2]+';'
    if not os.path.exists(file):
        with open(file,'xt',encoding='utf8') as rf:
            rf.write(sqlhead+'\n')
            rf.writelines(items)
    else:
        with open(file,'at',encoding='utf8') as rf:
            rf.writelines(items)

    return items
