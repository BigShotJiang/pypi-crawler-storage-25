
# tests/test_preprocess.py
from unittest.mock import patch
import pytest
from berna_tjgo_diacde_lib import ProcessLinked, ProcessPipeline # Import the module
# Import text_utils if needed for comparison or specific checks, but not essential for these tests.
# from berna_tjgo_diacde_lib.src import text_utils 

# --- Tests for ProcessLinked ---

def test_preprocess_string_init_type_error():
    with pytest.raises(TypeError, match="Input must be a string"):
        ProcessLinked(123)

def test_preprocess_string_filter_special_characters():
    text = "Hello, world!"
    expected = "Helloworld"
    processor = ProcessLinked(text)
    result = processor.filter_special_characters().as_str()
    assert result == expected

def test_preprocess_string_filter_spaces():
    text = "This   has    extra   spaces.   "
    expected = "This has extra spaces."
    processor = ProcessLinked(text)
    result = processor.filter_spaces().as_str()
    assert result == expected

def test_preprocess_string_filter_numbers():
    text = "There are 123 numbers here 456."
    expected = "There are  numbers here ."
    processor = ProcessLinked(text)
    result = processor.filter_numbers().as_str()
    assert result == expected

def test_preprocess_string_chaining():
    text = "  Test, 123.  "
    # Should remove spaces, numbers, and punctuation
    expected = "Test"
    processor = ProcessLinked(text)
    result = processor.filter_spaces().filter_numbers().filter_special_characters().as_str()
    assert result == expected

def test_preprocess_string_str_representation():
    text = "Sample text"
    processor = ProcessLinked(text)
    assert str(processor) == text
    assert processor.as_str() == text

def test_preprocess_string_filter_with_change_for():
    text = "Hello world"
    expected = "Hello world" # No punctuation, so no change
    processor = ProcessLinked(text)
    result = processor.filter_special_characters(change_for="_").as_str() 
    assert result == expected

    text_with_punct = "Hello, world!"
    expected_with_punct = "Hello_world_"
    processor_punct = ProcessLinked(text_with_punct)
    result_punct = processor_punct.filter_special_characters(change_for="_").as_str()
    assert result_punct == expected_with_punct

# --- Tests for ProcessPipeline ---

@pytest.fixture
def sample_text():
    return "  Este é um teste com números 123. E e-mail: test@example.com.  "

# --- Valid Pipeline Tests ---

def test_text_processor_single_step_pipeline(sample_text):
    pipeline = [{"name": "filter_spaces"}]
    processor = ProcessPipeline(pipeline)
    expected = "Este é um teste com números 123. E e-mail: test@example.com."
    assert processor.process(sample_text) == expected

def test_text_processor_multiple_steps_pipeline_regex_only(sample_text):
    # Pipeline using only regex-based filters available in text_utils
    pipeline_regex_only = [
        {"name": "filter_spaces"},
        {"name": "filter_numbers", "change_for": "*"},
        {"name": "filter_email"},
        {"name": "filter_special_characters"},
    ]
    processor = ProcessPipeline(pipeline_regex_only)
    # Input: "  Este é um teste com números 123. E e-mail: test@example.com.  "
    # 1. filter_spaces: "Este é um teste com números 123. E e-mail: test@example.com."
    # 2. filter_numbers("*"): "Este é um teste com números ***. E e-mail: test@example.com."
    # 3. filter_special_characters(): "Este é um teste com números  E email testexamplecom" (Note: filter_special_characters also removes periods)
    # 4. filter_email(): "Este é um teste com números  E email "
    expected_regex_only = "Este é um teste com números  E email "
    assert processor.process(sample_text) == expected_regex_only

def test_text_processor_pipeline_with_args(sample_text):
    pipeline = [
        {"name": "filter_spaces", "change_for": "_"},
        {"name": "filter_numbers", "change_for": "#"},
    ]
    processor = ProcessPipeline(pipeline)
    # Input: "  Este é um teste com números 123. E e-mail: test@example.com.  "
    # 1. filter_spaces("_"): "Este_é_um_teste_com_números_123._E_e-mail:_test@example.com."
    # 2. filter_numbers("#"): "Este_é_um_teste_com_números_###._E_e-mail:_test@example.com."
    expected = "Este_é_um_teste_com_números_###._E_e-mail:_test@example.com."
    assert processor.process(sample_text) == expected

def test_text_processor_empty_input_string():
    pipeline = [{"name": "filter_spaces"}]
    processor = ProcessPipeline(pipeline)
    assert processor.process("") == ""

def test_text_processor_pipeline_results_in_empty_string():
    pipeline = [{"name": "filter_numbers", "change_for": ""}]
    processor = ProcessPipeline(pipeline)
    assert processor.process("12345") == ""

def test_text_processor_invalid_method_name_exception():
    pipeline = [{"name": "non_existent_method"}]
    processor = ProcessPipeline(pipeline)
    
    # Expecting an Exception because the method is not in PROCESS_METHODS
    with pytest.raises(Exception, match="non_existent_method is not a existing preprocessing method."):
        processor.process("some text")

def test_text_processor_method_exists_but_not_in_textutils(monkeypatch):
    # This test simulates a scenario where a method is listed in PROCESS_METHODS
    # but is missing from the actual TextUtils class.
    
    # Create a minimal mock TextUtils class
    class MockTextUtils:
        @staticmethod
        def a_real_method(txt: str) -> str: return txt
        
    # Temporarily patch TextUtils and the PROCESS_METHODS list
    with patch('berna_tjgo_diacde_lib.src.text_utils.TextUtils', MockTextUtils), \
        patch('berna_tjgo_diacde_lib.src.text_utils.PROCESS_METHODS', ["a_real_method", "missing_method_in_class"]):
        
        pipeline_missing_class = [{"name": "missing_method_in_class"}]
        processor = ProcessPipeline(pipeline_missing_class)
        
        # This should raise "Bad pipeline format." because getattr will return None.
        with pytest.raises(Exception, match="Bad pipeline format."):
            processor.process("some text")

def test_text_processor_pipeline_with_invalid_argument_type():
    # This test aims to verify that ProcessPipeline correctly passes arguments
    # and that underlying TextUtils methods would raise errors if argument types are wrong.
    # For the current TextUtils methods using re.sub, type errors for 'change_for' are unlikely.
    # Instead, we test a scenario where a *missing* argument that *is* required might cause issues,
    # or confirm correct argument passing.
    
    # Test that correct arguments are passed to TextUtils methods.
    # filter_special_characters accepts 'change_for'. Let's pass a string.
    text = "abc"
    pipeline = [{"name": "filter_special_characters", "change_for": "***"}]
    processor = ProcessPipeline(pipeline)
    # The method call becomes TextUtils.filter_special_characters("abc", change_for="***")
    # which should replace 'a', 'b', 'c' with '*'. (Note: filter_special_characters removes non-alphanumeric, so it becomes "***")
    assert processor.process(text) == "***" 

    # To truly test invalid argument *type* panics from ProcessPipeline's perspective,
    # we would need a TextUtils method that strictly validates argument types.
    # For example, if a method expected `change_for: int`, passing `"***"` would fail.
    # The current code structure relies on `re.sub`'s flexibility.

# Test for input that becomes empty after processing
def test_text_processor_pipeline_results_in_empty_string_with_args():
    pipeline = [
        {"name": "filter_spaces", "change_for": ""},
        {"name": "filter_numbers", "change_for": ""},
        {"name": "filter_special_characters", "change_for": ""}
    ]
    processor = ProcessPipeline(pipeline)
    assert processor.process("   123!@#   ") == ""