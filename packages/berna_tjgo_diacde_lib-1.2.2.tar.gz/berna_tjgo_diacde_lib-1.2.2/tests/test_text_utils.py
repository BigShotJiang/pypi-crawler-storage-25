
# tests/test_text_utils.py
import pytest
import re
from unittest.mock import patch, MagicMock

# Assumindo que o pacote está disponível
# Se sua estrutura for diferente, ajuste o caminho de importação.
# Ex: from ..src import text_utils
from berna_tjgo_diacde_lib.src import text_utils

# --- Mocking NLTK, spaCy, and BeautifulSoup for unit tests ---

# Mock para stopwords
@pytest.fixture
def mock_nltk_stopwords():
    with patch('berna_tjgo_diacde_lib.src.text_utils.stopwords.words') as mock_words:
        mock_words.return_value = ["o", "a", "os", "as", "um", "uma", "uns", "umas", "é", "em", "de", "do", "da", "dos", "das", "para", "por", "com", "sem", "mas", "ou", "e", "ao", "à", "aos", "às", "ele", "ela", "eles", "elas", "me", "te", "se", "nos", "vos", "lhe", "lhes", "mim", "ti", "si", "nós", "vós", "comigo", "contigo", "consigo", "conosco", "convosco", "meu", "minha", "meus", "minhas", "teu", "tua", "teus", "tuas", "seu", "sua", "seus", "suas", "nosso", "nossa", "nossos", "nossas", "vosso", "vossa", "vossos", "vossas", "isto", "isso", "aquilo", "este", "esta", "estes", "estas", "esse", "essa", "esses", "essas", "aquele", "aquela", "aqueles", "aquelas"]
        return mock_words

@pytest.fixture
def mock_nltk_download():
    with patch('berna_tjgo_diacde_lib.src.text_utils.nltk.download') as mock_download:
        yield mock_download

# Mock para spaCy
@pytest.fixture
def mock_spacy():
    mock_nlp_instance = MagicMock()
    
    def get_lemma(token_text):
        lemmas = {
            "correndo": "correr", "andando": "andar", "rapidamente": "rapidamente",
            "gato": "gato", "cachorro": "cachorro", "é": "ser", "um": "um", "teste": "teste", "com": "com", "números": "número", "e": "e", "email": "email",
            "visita": "visitar", "site": "site", "exemplo": "exemplo", "contato": "contato", "suporte": "suporte",
            "meu": "meu", "é": "ser", "o": "o", "telefone": "telefone", "chamada": "chamada"
        }
        return lemmas.get(token_text.lower(), token_text)

    def create_mock_token(text):
        mock_token = MagicMock()
        mock_token.text = text
        mock_token.lemma_ = get_lemma(text)
        return mock_token

    def mock_nlp_call(text):
        tokens_text = [t for t in text.lower().split() if t] 
        mock_doc_instance = MagicMock()
        mock_doc_instance.__iter__.return_value = iter([create_mock_token(t) for t in tokens_text])
        return mock_doc_instance

    mock_nlp_instance.side_effect = mock_nlp_call

    with patch('berna_tjgo_diacde_lib.src.text_utils.spacy.load', return_value=mock_nlp_instance) as mock_load:
        yield mock_load, mock_nlp_instance

# Mock para BeautifulSoup import error
@pytest.fixture
def mock_bs4_import_error():
    with patch('berna_tjgo_diacde_lib.src.text_utils.BeautifulSoup') as mock_bs:
        mock_bs.side_effect = ImportError("BeautifulSoup is required for remove_html. Please install it: pip install beautifulsoup4")
        yield mock_bs

# --- Tests for TextUtils ---

# Filter Tests - using parametrized tests for common patterns
@pytest.mark.parametrize("input_text, expected_text, filter_method", [
    ("Hello, world!", "Helloworld", text_utils.TextUtils.filter_special_characters),
    ("This   has    extra   spaces.   ", "This has extra spaces.", text_utils.TextUtils.filter_spaces),
    ("There are 123 numbers here 456.", "There are  numbers here .", text_utils.TextUtils.filter_numbers),
    ("Visit http://example.com or www.google.com for info.", "Visit  or  for info.", text_utils.TextUtils.filter_links),
    ("Contact test@example.com or support.me+alias@domain.co.uk.", "Contact  or .", text_utils.TextUtils.filter_email),
    ("CNPJ: 12.345.678/0001-90, another: 00.000.000/0001-00", "CNPJ: , another: ", text_utils.TextUtils.filter_cnpj),
    ("CPF: 123.456.789-00. Another: 987.654.321-00", "CPF: . Another: ", text_utils.TextUtils.filter_cpf),
    ("RG: 123456789. Another: 987654321", "RG: . Another: ", text_utils.TextUtils.filter_rg),
    ("CEP: 00000-000. Or: 12345000", "CEP: . Or: ", text_utils.TextUtils.filter_cep),
    ("OAB/SP 123.456. Another: RJ-98765", "OAB/SP . Another: ", text_utils.TextUtils.filter_oab),
    ("Tel: (11) 98765-4321. Other: 21 99999-8888. Num: 3112345678", "Tel: . Other: . Num: ", text_utils.TextUtils.filter_telefone),
    ("", "", text_utils.TextUtils.filter_special_characters), # Empty string
    ("   ", "", text_utils.TextUtils.filter_spaces), # Only spaces
    ("!@#$%", "", text_utils.TextUtils.filter_special_characters), # Only punctuation
    ("12345", "", text_utils.TextUtils.filter_numbers), # Only numbers
])
def test_text_utils_filters_parametrized(input_text, expected_text, filter_method):
    assert filter_method(input_text) == expected_text

# Test with change_for parameter
def test_text_utils_filter_special_characters_with_change_for():
    input_text = "Hello, world!"
    expected_text = "Hello_world_"
    assert text_utils.TextUtils.filter_special_characters(input_text, change_for="_") == expected_text

def test_text_utils_filter_numbers_with_change_for():
    input_text = "123abc456"
    expected_text = "###abc###"
    assert text_utils.TextUtils.filter_numbers(input_text, change_for="#") == expected_text

# Stopwords Tests
def test_remove_stopwords_portuguese(mock_nltk_stopwords, mock_nltk_download):
    text = "este é um teste de remoção de stopwords em português"
    expected = "teste remoção stopwords português"
    assert text_utils.TextUtils.remove_stopwords(text, language="portuguese") == expected
    mock_nltk_download.assert_not_called()

def test_remove_stopwords_english_no_effect_with_mock(mock_nltk_stopwords, mock_nltk_download):
    text = "this is a test of stopword removal in english"
    expected = "this is a test of stopword removal in english" # No English stopwords in mock
    assert text_utils.TextUtils.remove_stopwords(text, language="english") == expected
    mock_nltk_download.assert_not_called()

# HTML Tests - Now using BeautifulSoup
def test_remove_html_with_beautifulsoup():
    html_content = "<h1>Título Principal</h1><p>Este é um parágrafo com <strong>texto em negrito</strong>.</p><a href='#'>Link</a>"
    expected_text = "Título PrincipalEste é um parágrafo com texto em negrito.Link"
    assert text_utils.TextUtils.remove_html(html_content) == expected_text

def test_remove_html_empty_string():
    assert text_utils.TextUtils.remove_html("") == ""

def test_remove_html_no_html_tags():
    text_without_html = "This is plain text."
    assert text_utils.TextUtils.remove_html(text_without_html) == text_without_html

def test_remove_html_with_script_and_style_tags():
    html_with_tags = "<script>alert('hello');</script><style>.red { color: red; }</style><p>Some text.</p><div>More text.</div>"
    expected_text = "Some text.More text." # BeautifulSoup's get_text() should strip script/style content
    assert text_utils.TextUtils.remove_html(html_with_tags) == expected_text

def test_remove_html_beautifulsoup_import_error(mock_bs4_import_error):
    # This test ensures the ImportError is raised correctly if BeautifulSoup is not installed.
    with pytest.raises(ImportError, match="BeautifulSoup is required for remove_html. Please install it: pip install beautifulsoup4"):
        text_utils.TextUtils.remove_html("<html><body>Any HTML</body></html>")

# Stemming (Incomplete method)
def test_stemming_incomplete():
    text = "running running running"
    # Current implementation just returns the text
    assert text_utils.TextUtils.stemming(text) == text

# Lemmatize Tests
def test_lemmatize_portuguese(mock_spacy):
    mock_load, mock_nlp_instance = mock_spacy
    text = "Correndo e andando rapidamente."
    expected = "correr e andar rapidamente." 
    assert text_utils.TextUtils.lemmatize(text, core='pt_core_news_sm') == expected
    mock_load.assert_called_once_with('pt_core_news_sm')

def test_lemmatize_model_not_found(mock_spacy):
    mock_load, _ = mock_spacy
    mock_load.side_effect = OSError("SpaCy model to pt_core_news_sm not found. Download it: python -m spacy download pt_core_news_sm")
    text = "some text"
    with pytest.raises(OSError, match="SpaCy model to pt_core_news_sm not found."):
        text_utils.TextUtils.lemmatize(text, core='pt_core_news_sm')

def test_lemmatize_empty_text(mock_spacy):
    mock_load, mock_nlp_instance = mock_spacy
    assert text_utils.TextUtils.lemmatize("", core='pt_core_news_sm') == ""
