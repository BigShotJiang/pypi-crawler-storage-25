from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ChatRequest(_message.Message):
    __slots__ = ("input", "user", "session_id", "metadata")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    INPUT_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    input: str
    user: str
    session_id: str
    metadata: _containers.ScalarMap[str, str]
    def __init__(self, input: _Optional[str] = ..., user: _Optional[str] = ..., session_id: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ...) -> None: ...

class EmotionalState(_message.Message):
    __slots__ = ("primary", "secondary", "intensity")
    PRIMARY_FIELD_NUMBER: _ClassVar[int]
    SECONDARY_FIELD_NUMBER: _ClassVar[int]
    INTENSITY_FIELD_NUMBER: _ClassVar[int]
    primary: str
    secondary: str
    intensity: float
    def __init__(self, primary: _Optional[str] = ..., secondary: _Optional[str] = ..., intensity: _Optional[float] = ...) -> None: ...

class RiskSignal(_message.Message):
    __slots__ = ("level", "category", "trajectory", "urgency_score")
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    TRAJECTORY_FIELD_NUMBER: _ClassVar[int]
    URGENCY_SCORE_FIELD_NUMBER: _ClassVar[int]
    level: int
    category: str
    trajectory: str
    urgency_score: float
    def __init__(self, level: _Optional[int] = ..., category: _Optional[str] = ..., trajectory: _Optional[str] = ..., urgency_score: _Optional[float] = ...) -> None: ...

class Explanation(_message.Message):
    __slots__ = ("summary", "why")
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    WHY_FIELD_NUMBER: _ClassVar[int]
    summary: str
    why: str
    def __init__(self, summary: _Optional[str] = ..., why: _Optional[str] = ...) -> None: ...

class Confidence(_message.Message):
    __slots__ = ("data_confidence", "model_confidence")
    DATA_CONFIDENCE_FIELD_NUMBER: _ClassVar[int]
    MODEL_CONFIDENCE_FIELD_NUMBER: _ClassVar[int]
    data_confidence: float
    model_confidence: float
    def __init__(self, data_confidence: _Optional[float] = ..., model_confidence: _Optional[float] = ...) -> None: ...

class InferenceOutput(_message.Message):
    __slots__ = ("emotional_state", "risk_signal", "explanation", "contributing_factors", "confidence", "historical_alignment", "flags")
    EMOTIONAL_STATE_FIELD_NUMBER: _ClassVar[int]
    RISK_SIGNAL_FIELD_NUMBER: _ClassVar[int]
    EXPLANATION_FIELD_NUMBER: _ClassVar[int]
    CONTRIBUTING_FACTORS_FIELD_NUMBER: _ClassVar[int]
    CONFIDENCE_FIELD_NUMBER: _ClassVar[int]
    HISTORICAL_ALIGNMENT_FIELD_NUMBER: _ClassVar[int]
    FLAGS_FIELD_NUMBER: _ClassVar[int]
    emotional_state: EmotionalState
    risk_signal: RiskSignal
    explanation: Explanation
    contributing_factors: _containers.RepeatedScalarFieldContainer[str]
    confidence: Confidence
    historical_alignment: float
    flags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, emotional_state: _Optional[_Union[EmotionalState, _Mapping]] = ..., risk_signal: _Optional[_Union[RiskSignal, _Mapping]] = ..., explanation: _Optional[_Union[Explanation, _Mapping]] = ..., contributing_factors: _Optional[_Iterable[str]] = ..., confidence: _Optional[_Union[Confidence, _Mapping]] = ..., historical_alignment: _Optional[float] = ..., flags: _Optional[_Iterable[str]] = ...) -> None: ...

class ChatResponse(_message.Message):
    __slots__ = ("chunk", "is_last", "inference_output")
    CHUNK_FIELD_NUMBER: _ClassVar[int]
    IS_LAST_FIELD_NUMBER: _ClassVar[int]
    INFERENCE_OUTPUT_FIELD_NUMBER: _ClassVar[int]
    chunk: str
    is_last: bool
    inference_output: InferenceOutput
    def __init__(self, chunk: _Optional[str] = ..., is_last: bool = ..., inference_output: _Optional[_Union[InferenceOutput, _Mapping]] = ...) -> None: ...

class CreateSessionRequest(_message.Message):
    __slots__ = ("user", "metadata")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    USER_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    user: str
    metadata: _containers.ScalarMap[str, str]
    def __init__(self, user: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ...) -> None: ...

class CreateSessionResponse(_message.Message):
    __slots__ = ("_id", "user", "summary", "scoreLevel", "createdAt", "updatedAt")
    _ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    SCORELEVEL_FIELD_NUMBER: _ClassVar[int]
    CREATEDAT_FIELD_NUMBER: _ClassVar[int]
    UPDATEDAT_FIELD_NUMBER: _ClassVar[int]
    _id: str
    user: str
    summary: str
    scoreLevel: int
    createdAt: str
    updatedAt: str
    def __init__(self, _id: _Optional[str] = ..., user: _Optional[str] = ..., summary: _Optional[str] = ..., scoreLevel: _Optional[int] = ..., createdAt: _Optional[str] = ..., updatedAt: _Optional[str] = ...) -> None: ...
