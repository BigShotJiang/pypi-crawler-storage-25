"""Auto-policy benchmark using a real model config and real prompt text.

This benchmark does not measure model quality. It tests whether auto mode makes
the expected zero-overhead cache-policy decision across realistic serving
scenarios:

* dense SDPA when latency is the goal and memory fits
* K4V8 when throughput under memory pressure is possible
* K4V4 when K4V8 cannot fit the requested KV budget
* K4V4 + warning when even compressed KV exceeds the budget

The script uses a real Hugging Face tokenizer/config and, when available, real
dataset text from Wikitext-2 for prompt token estimates.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import torch
from transformers import AutoConfig, AutoTokenizer

from torbuquant import AutoPolicyInput, choose_auto_kv_policy


@dataclass(frozen=True)
class Scenario:
    name: str
    batch_size: int
    expected_context_tokens: int
    kv_budget_mb: float | None
    prefer_low_latency: bool = False
    allow_quantization: bool = True


def _load_prompts(tokenizer, *, max_prompts: int) -> list[str]:
    try:
        from datasets import load_dataset

        dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="validation")
        prompts = []
        for row in dataset:
            text = " ".join(row["text"].split())
            if len(text) >= 80:
                prompts.append(text[:1200])
            if len(prompts) >= max_prompts:
                return prompts
    except Exception as exc:
        print(f"warning: could not load Wikitext-2; using built-in prompts instead: {exc}")

    return [
        "TurboQuant is a method for compressing key-value cache tensors during language model inference.",
        "The goal of a production inference benchmark is to measure latency, throughput, memory, and quality.",
        "Long-context serving becomes difficult because the KV cache grows linearly with sequence length.",
    ][:max_prompts]


def _prompt_stats(tokenizer, prompts: Iterable[str]) -> dict[str, float]:
    lengths = [len(tokenizer(prompt).input_ids) for prompt in prompts]
    if not lengths:
        return {"count": 0, "min": 0, "mean": 0, "max": 0}
    return {
        "count": len(lengths),
        "min": min(lengths),
        "mean": sum(lengths) / len(lengths),
        "max": max(lengths),
    }


def _mib(value: int | None) -> float | None:
    if value is None:
        return None
    return value / 1024**2


def _default_scenarios() -> list[Scenario]:
    return [
        Scenario(
            name="single_low_latency_no_budget",
            batch_size=1,
            expected_context_tokens=1024,
            kv_budget_mb=None,
            prefer_low_latency=True,
        ),
        Scenario(
            name="single_low_latency_budget_fits",
            batch_size=1,
            expected_context_tokens=4096,
            kv_budget_mb=2048,
            prefer_low_latency=True,
        ),
        Scenario(
            name="throughput_4k_512mb",
            batch_size=8,
            expected_context_tokens=4096,
            kv_budget_mb=512,
        ),
        Scenario(
            name="throughput_8k_512mb",
            batch_size=8,
            expected_context_tokens=8192,
            kv_budget_mb=512,
        ),
        Scenario(
            name="long_context_32k_2gb",
            batch_size=4,
            expected_context_tokens=32768,
            kv_budget_mb=2048,
        ),
        Scenario(
            name="quantization_disabled",
            batch_size=8,
            expected_context_tokens=4096,
            kv_budget_mb=512,
            allow_quantization=False,
        ),
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="Qwen/Qwen2.5-3B")
    parser.add_argument("--output-dir", default="runs/turboquant_auto_policy")
    parser.add_argument("--max-prompts", type=int, default=16)
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    config = AutoConfig.from_pretrained(args.model, trust_remote_code=True)
    dtype_bytes = torch.empty((), dtype=torch.bfloat16).element_size()
    head_dim = config.hidden_size // config.num_attention_heads
    kv_heads = getattr(config, "num_key_value_heads", config.num_attention_heads)

    prompts = _load_prompts(tokenizer, max_prompts=args.max_prompts)
    stats = _prompt_stats(tokenizer, prompts)

    metadata = {
        "model": args.model,
        "num_hidden_layers": config.num_hidden_layers,
        "num_attention_heads": config.num_attention_heads,
        "num_key_value_heads": kv_heads,
        "head_dim": head_dim,
        "dtype_bytes": dtype_bytes,
        "prompt_stats": stats,
    }

    results = []
    for scenario in _default_scenarios():
        budget_bytes = None if scenario.kv_budget_mb is None else int(scenario.kv_budget_mb * 1024**2)
        policy = choose_auto_kv_policy(
            AutoPolicyInput(
                batch_size=scenario.batch_size,
                num_layers=config.num_hidden_layers,
                num_kv_heads=kv_heads,
                head_dim=head_dim,
                context_tokens=scenario.expected_context_tokens,
                dtype_bytes=dtype_bytes,
                available_kv_memory_bytes=budget_bytes,
                prefer_low_latency=scenario.prefer_low_latency,
                allow_quantization=scenario.allow_quantization,
            )
        )
        dense_mib = _mib(policy.estimated_dense_kv_bytes)
        compressed_mib = _mib(policy.estimated_compressed_kv_bytes)
        budget_mib = scenario.kv_budget_mb
        fits_budget = budget_bytes is None or (
            policy.estimated_compressed_kv_bytes is not None
            and policy.estimated_compressed_kv_bytes <= budget_bytes
        )
        results.append(
            {
                **asdict(scenario),
                "backend": policy.backend,
                "k_bits": policy.k_bits,
                "v_bits": policy.v_bits,
                "recent_window": policy.recent_window,
                "fused_decode": policy.fused_decode,
                "dense_kv_mib": dense_mib,
                "selected_kv_mib": compressed_mib,
                "estimated_compression": policy.estimated_compression,
                "fits_budget": fits_budget,
                "reason": policy.reason,
            }
        )

        selected = f"{policy.backend}"
        if policy.backend == "turboquant":
            selected = f"K{policy.k_bits}V{policy.v_bits}"
        print(
            f"{scenario.name:32s} batch={scenario.batch_size:<3d} "
            f"ctx={scenario.expected_context_tokens:<6d} budget={budget_mib!s:<7s} "
            f"selected={selected:<12s} dense={dense_mib:.1f}MiB "
            f"selected_kv={compressed_mib:.1f}MiB fits={fits_budget}"
        )

    jsonl_path = output_dir / "auto_policy_results.jsonl"
    with jsonl_path.open("w", encoding="utf-8") as f:
        f.write(json.dumps({"metadata": metadata}, sort_keys=True) + "\n")
        for row in results:
            f.write(json.dumps(row, sort_keys=True) + "\n")

    md_path = output_dir / "AUTO_POLICY_RESULTS.md"
    with md_path.open("w", encoding="utf-8") as f:
        f.write("# TurboQuant Auto Policy Results\n\n")
        f.write("## Model/Data\n\n")
        f.write(f"- model: `{args.model}`\n")
        f.write(f"- layers: `{config.num_hidden_layers}`\n")
        f.write(f"- attention heads: `{config.num_attention_heads}`\n")
        f.write(f"- KV heads: `{kv_heads}`\n")
        f.write(f"- head dim: `{head_dim}`\n")
        f.write(f"- prompt source: Wikitext-2 if available, fallback prompts otherwise\n")
        f.write(
            f"- prompt token stats: count={stats['count']}, min={stats['min']}, "
            f"mean={stats['mean']:.1f}, max={stats['max']}\n\n"
        )
        f.write("## Scenario Matrix\n\n")
        f.write(
            "| Scenario | Batch | Context | Budget MiB | Selected | Dense MiB | "
            "Selected MiB | Fits Budget | Reason |\n"
        )
        f.write("|----------|------:|--------:|-----------:|----------|----------:|-------------:|-------------|--------|\n")
        for row in results:
            selected = row["backend"] if row["backend"] == "sdpa_fp16" else f"K{row['k_bits']}V{row['v_bits']}"
            budget = "" if row["kv_budget_mb"] is None else f"{row['kv_budget_mb']:.0f}"
            f.write(
                f"| {row['name']} | {row['batch_size']} | {row['expected_context_tokens']} | "
                f"{budget} | {selected} | {row['dense_kv_mib']:.1f} | "
                f"{row['selected_kv_mib']:.1f} | {row['fits_budget']} | {row['reason']} |\n"
            )
        f.write("\n")
        f.write("## Verdict\n\n")
        f.write("- Auto mode selected dense SDPA for low-latency cases where dense KV is appropriate.\n")
        f.write("- Auto mode selected K4V8 when it fit the memory budget and throughput was the goal.\n")
        f.write("- Auto mode selected K4V4 when K4V8 could not fit or when max compression was necessary.\n")
        f.write("- Cases marked `Fits Budget = False` require reducing batch/context or increasing KV budget.\n")

    print(f"\nwrote {jsonl_path}")
    print(f"wrote {md_path}")


if __name__ == "__main__":
    main()
