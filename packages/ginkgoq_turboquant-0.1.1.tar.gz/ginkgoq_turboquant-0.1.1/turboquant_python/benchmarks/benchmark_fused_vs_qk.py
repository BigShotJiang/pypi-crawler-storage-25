"""Benchmark: QK-only scoring vs Full Fused Attention.

This benchmark compares:
1. Current approach: direct_score -> softmax -> V matmul (separate ops)
2. Superior approach: fused_attention (one kernel, online softmax)

The fused approach should be faster because:
- No intermediate scores tensor
- Online softmax avoids extra passes
- V dequant happens inside weighted sum
"""

import gc
import time
import torch

from torbuquant.quantizers import TurboQuantMSE, HAS_TRITON
from torbuquant.fused_attention import (
    FusedTurboQuantAttention,
    quantize_values_uniform,
    fused_attention_pytorch,
    online_softmax_update,
    finalize_online_softmax,
)


def reset_gpu():
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()


def benchmark_current_approach(
    query: torch.Tensor,      # (B, H, 1, D)
    keys: torch.Tensor,       # (B, H, N, D)
    values: torch.Tensor,     # (B, H, N, D)
    quantizer: TurboQuantMSE,
    scale: float,
    num_iters: int = 30,
) -> dict:
    """Current approach: QK score -> softmax -> V matmul."""
    device = query.device

    # Quantize K
    k_quantized = quantizer.quantize(keys)

    # Pre-rotate query
    B, H, Q, D = query.shape
    q = query.squeeze(2)
    q_rot = quantizer.rotate_query(q.reshape(-1, D)).reshape(B, H, D)

    # Warmup
    for _ in range(5):
        scores = quantizer.direct_score(q_rot.unsqueeze(2), k_quantized, scale=scale)
        weights = torch.softmax(scores.squeeze(2), dim=-1)
        output = torch.einsum('bhn,bhnd->bhd', weights, values)
        if device.type == "cuda":
            torch.cuda.synchronize()

    # Reset memory
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()

    # Benchmark
    if device.type == "cuda":
        torch.cuda.synchronize()

    start = time.perf_counter()
    for _ in range(num_iters):
        # Step 1: Compute QK scores from compressed K
        scores = quantizer.direct_score(q_rot.unsqueeze(2), k_quantized, scale=scale)

        # Step 2: Softmax (creates intermediate tensor)
        weights = torch.softmax(scores.squeeze(2), dim=-1)  # (B, H, N)

        # Step 3: Weighted sum with V (V is still dense here)
        output = torch.einsum('bhn,bhnd->bhd', weights, values)

        if device.type == "cuda":
            torch.cuda.synchronize()

    elapsed = (time.perf_counter() - start) / num_iters * 1000

    if device.type == "cuda":
        peak_memory = torch.cuda.max_memory_allocated() / (1024 * 1024)
    else:
        peak_memory = 0

    return {
        "time_ms": elapsed,
        "peak_memory_mb": peak_memory,
    }


def benchmark_fused_pytorch(
    query: torch.Tensor,      # (B, H, 1, D)
    keys: torch.Tensor,       # (B, H, N, D)
    values: torch.Tensor,     # (B, H, N, D)
    quantizer: TurboQuantMSE,
    scale: float,
    num_iters: int = 30,
    block_size: int = 64,
) -> dict:
    """Fused approach with online softmax (PyTorch reference)."""
    device = query.device

    # Quantize K
    k_quantized = quantizer.quantize(keys)

    # Quantize V (simpler uniform)
    v_q, v_scales, v_zeros = quantize_values_uniform(values, bits=8, group_size=-1)

    # Pre-rotate query
    B, H, Q, D = query.shape
    N = keys.shape[2]
    q = query.squeeze(2)
    q_rot = quantizer.rotate_query(q.reshape(-1, D)).reshape(B, H, D)

    # Warmup
    for _ in range(3):
        output = fused_attention_pytorch(
            query, k_quantized.indices, k_quantized.norms,
            quantizer.centroids, quantizer.rotation,
            v_q, v_scales, v_zeros,
            quantizer.bits, 8, D, scale, block_size,
            use_rht=False
        )
        if device.type == "cuda":
            torch.cuda.synchronize()

    # Reset memory
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()

    # Benchmark
    if device.type == "cuda":
        torch.cuda.synchronize()

    start = time.perf_counter()
    for _ in range(num_iters):
        output = fused_attention_pytorch(
            query, k_quantized.indices, k_quantized.norms,
            quantizer.centroids, quantizer.rotation,
            v_q, v_scales, v_zeros,
            quantizer.bits, 8, D, scale, block_size,
            use_rht=False
        )
        if device.type == "cuda":
            torch.cuda.synchronize()

    elapsed = (time.perf_counter() - start) / num_iters * 1000

    if device.type == "cuda":
        peak_memory = torch.cuda.max_memory_allocated() / (1024 * 1024)
    else:
        peak_memory = 0

    return {
        "time_ms": elapsed,
        "peak_memory_mb": peak_memory,
    }


def benchmark_fused_highlevel(
    query: torch.Tensor,      # (B, H, 1, D)
    keys: torch.Tensor,       # (B, H, N, D)
    values: torch.Tensor,     # (B, H, N, D)
    k_bits: int,
    scale: float,
    num_iters: int = 30,
) -> dict:
    """Fused approach using FusedTurboQuantAttention API."""
    device = query.device
    D = query.shape[-1]

    # Create fused attention module
    fused_attn = FusedTurboQuantAttention(
        dim=D,
        k_bits=k_bits,
        v_bits=8,
        rotation_type="dense",
        device=device,
    )

    # Quantize K/V
    compressed = fused_attn.quantize_kv(keys, values)

    # Warmup
    for _ in range(3):
        output = fused_attn(query, compressed, scale)
        if device.type == "cuda":
            torch.cuda.synchronize()

    # Reset memory
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()

    # Benchmark
    if device.type == "cuda":
        torch.cuda.synchronize()

    start = time.perf_counter()
    for _ in range(num_iters):
        output = fused_attn(query, compressed, scale)
        if device.type == "cuda":
            torch.cuda.synchronize()

    elapsed = (time.perf_counter() - start) / num_iters * 1000

    if device.type == "cuda":
        peak_memory = torch.cuda.max_memory_allocated() / (1024 * 1024)
    else:
        peak_memory = 0

    return {
        "time_ms": elapsed,
        "peak_memory_mb": peak_memory,
    }


def main():
    print("=" * 80)
    print("QK-Only vs Full Fused Attention Benchmark")
    print("=" * 80)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    print(f"Triton available: {HAS_TRITON}")
    print()

    # Configuration
    B, H = 1, 8  # batch, heads
    D = 128      # head dim
    bits = 4     # Use 4-bit for production
    scale = 1.0 / (D ** 0.5)

    print(f"Config: B={B}, H={H}, D={D}, bits={bits}")
    print()

    print(f"{'Seq Len':<10} {'Current QK-only':<20} {'Fused PyTorch':<20} {'Fused API':<20} {'Speedup':<10}")
    print("-" * 90)

    for seq_len in [256, 512, 1024, 2048, 4096, 8192]:
        reset_gpu()

        # Create test data
        query = torch.randn(B, H, 1, D, device=device)
        keys = torch.randn(B, H, seq_len, D, device=device)
        values = torch.randn(B, H, seq_len, D, device=device)

        # Create quantizer
        quantizer = TurboQuantMSE(D, bits, device=device)

        # Benchmark current approach
        reset_gpu()
        try:
            current = benchmark_current_approach(query, keys, values, quantizer, scale)
        except Exception as e:
            current = {"time_ms": float('nan'), "peak_memory_mb": float('nan')}

        # Benchmark fused PyTorch
        reset_gpu()
        try:
            fused_pt = benchmark_fused_pytorch(query, keys, values, quantizer, scale)
        except Exception as e:
            fused_pt = {"time_ms": float('nan'), "peak_memory_mb": float('nan')}

        # Benchmark fused high-level API
        reset_gpu()
        try:
            fused_api = benchmark_fused_highlevel(query, keys, values, bits, scale)
        except Exception as e:
            fused_api = {"time_ms": float('nan'), "peak_memory_mb": float('nan')}

        # Calculate speedup
        speedup = current["time_ms"] / fused_pt["time_ms"] if fused_pt["time_ms"] > 0 else 0

        print(f"{seq_len:<10} {current['time_ms']:<20.3f} {fused_pt['time_ms']:<20.3f} {fused_api['time_ms']:<20.3f} {speedup:<10.2f}x")

        # Cleanup
        del query, keys, values, quantizer
        reset_gpu()

    print()
    print("=" * 80)
    print("Analysis")
    print("=" * 80)
    print()
    print("Current QK-only approach:")
    print("  1. direct_score(Q, compressed_K) -> scores tensor")
    print("  2. softmax(scores) -> weights tensor")
    print("  3. weights @ V -> output")
    print("  Problem: Creates intermediate scores and weights tensors")
    print()
    print("Fused approach:")
    print("  1. Process K/V in blocks with online softmax")
    print("  2. Never materialize full scores tensor")
    print("  3. Dequantize V inside weighted sum")
    print("  Benefit: Less memory, potentially faster")


if __name__ == "__main__":
    main()
