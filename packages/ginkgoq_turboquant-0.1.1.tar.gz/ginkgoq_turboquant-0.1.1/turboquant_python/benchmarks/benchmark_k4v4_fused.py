"""Synchronized microbenchmark for SDPA vs fused TurboQuant K4V8/K4V4.

This is a single-request decode latency benchmark. It is intentionally not a
serving-throughput benchmark. Use it to guard kernel regressions and to keep
single-token claims honest.
"""

from __future__ import annotations

import math
import time

import torch

from torbuquant.fused_attention import FusedTurboQuantAttention


def _bench(fn, *, iters: int = 100, warmup: int = 20) -> float:
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(iters):
        fn()
    torch.cuda.synchronize()
    return (time.perf_counter() - start) * 1000.0 / iters


def main() -> None:
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")

    device = torch.device("cuda")
    batch, heads, dim = 1, 32, 128
    print(f"GPU: {torch.cuda.get_device_name(0)}")
    print(f"Config: B={batch}, H={heads}, D={dim}")
    print(f"{'N':>6} {'SDPA':>10} {'K4V8':>10} {'K4V4':>10} {'K4V4/SDPA':>12} {'K4V4 comp':>10}")

    for seq_len in [512, 1024, 2048, 4096, 8192]:
        query = torch.randn(batch, heads, 1, dim, device=device, dtype=torch.float16)
        keys = torch.randn(batch, heads, seq_len, dim, device=device, dtype=torch.float16)
        values = torch.randn(batch, heads, seq_len, dim, device=device, dtype=torch.float16)
        scale = 1.0 / math.sqrt(dim)

        sdpa_ms = _bench(
            lambda: torch.nn.functional.scaled_dot_product_attention(
                query, keys, values, is_causal=False
            )
        )

        k4v8 = FusedTurboQuantAttention(dim, k_bits=4, v_bits=8, device=device, dtype=torch.float32)
        compressed_8 = k4v8.quantize_kv(keys, values)
        k4v8_ms = _bench(lambda: k4v8(query, compressed_8, scale=scale))

        k4v4 = FusedTurboQuantAttention(dim, k_bits=4, v_bits=4, device=device, dtype=torch.float32)
        compressed_4 = k4v4.quantize_kv(keys, values)
        k4v4_ms = _bench(lambda: k4v4(query, compressed_4, scale=scale))

        dense_bytes = keys.nelement() * keys.element_size() + values.nelement() * values.element_size()
        compression = dense_bytes / compressed_4.memory_bytes()["total"]

        print(
            f"{seq_len:6d} {sdpa_ms:10.4f} {k4v8_ms:10.4f} {k4v4_ms:10.4f} "
            f"{k4v4_ms / sdpa_ms:12.2f} {compression:10.2f}x"
        )


if __name__ == "__main__":
    main()
